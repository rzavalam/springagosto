// Creaci�n del m�dulo
//var SolicitudPostLevanteApp = angular.module('SolicitudPostLevanteApp', ['ngRoute']);
var SolicitudPostLevanteApp = angular.module('SolicitudPostLevanteApp', []);
SolicitudPostLevanteApp.config(['$routeProvider', function($routes) {

    $routes
        .when('/form_busquedadeclaracion', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/postlevante/solicitud/components/FormBusquedaDeclaracion.html',
            controller 	: 'BusquedaDeclaracionController'
        })
        .when('/form_solicitudpostlevante', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/postlevante/solicitud/components/FormSolicitudPostLevante.html',
            controller 	: 'SolicitudPostLevanteController'
        })
        .otherwise({
            redirectTo: '/form_busquedadeclaracion'
        });

}]);







