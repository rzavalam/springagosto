'use strict';
/**
 * Created by amancillaa on 18/04/2016.
 */
function BusquedaDeclaracionController($scope, $http,$location) {    
    
    $scope.cargarRegimenes = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G100.json').then(function(response){
            $scope.regimenes = response.data;	        
        })
    }
    $scope.cargarAduanas = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G139.json').then(function(response){
            $scope.aduanas = response.data;
        })
    }

    $scope.cargarDefaultDatosFormBusquedaDeclaracion = function(){              
	    $http.get('./cargar_defaultdatosformbusquedadeclaracion?rnd='+new Date().getTime())
            .then(function(res){							
                $scope.declaracion = res.data;	                 
	        });
    }

    $scope.submitForm  = function() {
        if ($scope.busquedaDeclaracionForm.$valid) {                     
			$http.post('./validar_aprobacion',$scope.declaracion)
                .success(function(res) {
                    if(angular.isDefined(res.msjError)){
                        $scope.mostrarMsj = true;
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.mostrarFormAprobacionPostLevante();					
					}
                });
        }
    };

    $scope.mostrarFormAprobacionPostLevante = function () {
        $location.path("/form_aprobacionpostlevante");
    };

    $scope.cargarDefaultDatosFormBusquedaDeclaracion();	
    $scope.cargarRegimenes();
    $scope.cargarAduanas();
}