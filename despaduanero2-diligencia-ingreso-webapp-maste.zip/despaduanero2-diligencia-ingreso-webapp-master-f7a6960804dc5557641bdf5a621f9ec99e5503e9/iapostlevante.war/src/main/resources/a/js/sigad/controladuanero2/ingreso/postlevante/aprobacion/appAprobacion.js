// Creaci�n del m�dulo
'use strict';
var AprobacionPostLevanteApp = angular.module('AprobacionPostLevanteApp', []);
AprobacionPostLevanteApp.config(['$routeProvider', function($routes) {

    $routes
        .when('/form_busquedadeclaracion', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/postlevante/aprobacion/components/FormBusquedaDeclaracion.html',
            controller 	: 'BusquedaDeclaracionController'
        })
        .when('/form_aprobacionpostlevante', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/postlevante/aprobacion/components/FormAprobacionPostLevante.html',
            controller 	: 'AprobacionPostLevanteController'
        })
        .otherwise({
            redirectTo: '/form_busquedadeclaracion'
        });

}]);







