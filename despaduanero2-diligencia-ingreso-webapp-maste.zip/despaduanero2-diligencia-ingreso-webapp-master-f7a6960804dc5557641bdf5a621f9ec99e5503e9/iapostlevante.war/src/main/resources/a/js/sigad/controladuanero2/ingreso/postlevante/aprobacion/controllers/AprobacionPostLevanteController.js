'use strict';
/**
 * Created by amancillaa on 18/04/2016.
 */
function AprobacionPostLevanteController($scope, $http,$location,$timeout) {       

    $scope.cargarRegimenes = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G100.json').then(function(response){
            $scope.regimenes = response.data;
        })
    }
    $scope.cargarAduanas = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G139.json').then(function(response){
            $scope.aduanas = response.data;
        })
    }
	
	 $scope.cargarModalidades = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/306.json').then(function(response){
            $scope.modalidades = response.data;
        })
    }
	
	 $scope.cargarCanales = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/AR.json').then(function(response){
            $scope.canales = response.data;
        })
    }

	 $scope.cargarEstados = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/335.json').then(function(response){
            $scope.estados = response.data;
        })
    }
	
    $scope.cargarFormSolicitudPostLevante = function(){
        $http.get('./cargar_datosformsolicitudpostlevante?rnd='+new Date().getTime())
            .then(function(res){                
                $scope.postlevante = res.data;										
            });
		
        $('.panel-collapse').collapse('show');		
    }

    $scope.aceptar  = function() {           
			$http.post('./aceptar_solicitudpostlevante',$scope.postlevante)
                .success(function(res,status) {
					$scope.mostrarMsj = true;
                    if(angular.isDefined(res.msjError)){                      
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.msjValidacion = "La solicitud Post-Levante fue aceptado correctamente.";	
						alert($scope.msjValidacion);	
                        $scope.mostrarFormBusquedaDeclaracion();						
					}
            }).error(function (data, status) {
				$scope.mostrarMsj = true;
                $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";						
            });
    };

	
	$scope.rechazar = function () {       
	   $http.post('./rechazar_solicitudpostlevante',$scope.postlevante)
                .success(function(res,status) {
					$scope.mostrarMsj = true;
                    if(angular.isDefined(res.msjError)){                      
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.msjValidacion = "La solicitud Post-Levante fue rechazado correctamente.";	
						alert($scope.msjValidacion);
						$scope.mostrarFormBusquedaDeclaracion();
					}
            }).error(function (data, status) {
				$scope.mostrarMsj = true;
                $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";						
            });			
    };


	$scope.salir = function () {
        $scope.mostrarFormBusquedaDeclaracion();
    };

	$scope.mostrarFormBusquedaDeclaracion = function () {		
        $location.path("/form_busquedadeclaracion");
    };
	
    $scope.cargarRegimenes();
    $scope.cargarAduanas();
	$scope.cargarModalidades();
	$scope.cargarCanales();
	$scope.cargarEstados();	
	$scope.cargarFormSolicitudPostLevante();
};


