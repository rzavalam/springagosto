'use strict';
/**
 * Created by amancillaa on 18/04/2016.
 */
 //amancilla sintaxis nueva no funciona para IE8 cuando sera el dia que cambien el navegador
//SolicitudPostLevanteApp.controller('BusquedaDeclaracionController', function($scope, $http,$location) {

function BusquedaDeclaracionController($scope, $http,$location) {    

    
    $scope.cargarRegimenes = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G100.json').then(function(response){
            $scope.regimenes = response.data;	        
        })
    }
    $scope.cargarAduanas = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G139.json').then(function(response){
            $scope.aduanas = response.data;
        })
    }

    $scope.cargarDefaultDatosFormBusquedaDeclaracion = function(){              
	    $http.get('./cargar_defaultdatosformbusquedadeclaracion?rnd='+new Date().getTime())
            .then(function(res){							
                $scope.declaracion = res.data;	                 
	        });
    }

    $scope.submitForm  = function() {
        if ($scope.busquedaDeclaracionForm.$valid) {                     
			//$http.post('./postlevante/validar_declaracion',$scope.declaracion)
			$http.post('./validar_solicitud',$scope.declaracion)
                .success(function(res) {
                    if(angular.isDefined(res.msjError)){
                        $scope.mostrarMsj = true;
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.mostrarFormSolicitudPostLevante();					
					}
                });
        }
    };

    $scope.mostrarFormSolicitudPostLevante = function () {
        $location.path("/form_solicitudpostlevante");
    };

    $scope.cargarDefaultDatosFormBusquedaDeclaracion();	
    $scope.cargarRegimenes();
    $scope.cargarAduanas();
	
//});
}