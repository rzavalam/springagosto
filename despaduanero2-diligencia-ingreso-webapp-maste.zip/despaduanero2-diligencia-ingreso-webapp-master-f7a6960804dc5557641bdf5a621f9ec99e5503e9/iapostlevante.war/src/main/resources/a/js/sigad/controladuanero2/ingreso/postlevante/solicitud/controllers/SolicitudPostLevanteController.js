/**
 * Created by amancillaa on 18/04/2016.
 */
//SolicitudPostLevanteApp.controller('BusquedaDeclaracionController', function($scope, $http,$location) {

function SolicitudPostLevanteController($scope, $http,$location,$timeout) {       


    $scope.postlevanteBD= {};

    $scope.cargarRegimenes = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G100.json').then(function(response){
            $scope.regimenes = response.data;
        })
    }
    $scope.cargarAduanas = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/G139.json').then(function(response){
            $scope.aduanas = response.data;
        })
    }
	
	 $scope.cargarModalidades = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/306.json').then(function(response){
            $scope.modalidades = response.data;
        })
    }
	
	 $scope.cargarCanales = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/AR.json').then(function(response){
            $scope.canales = response.data;
        })
    }

	 $scope.cargarEstados = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/postlevante/json/335.json').then(function(response){
            $scope.estados = response.data;
        })
    }
		
    $scope.cargarFormSolicitudPostLevante = function(){    
		$http.get('./cargar_datosformsolicitudpostlevante?rnd='+new Date().getTime())
            .then(function(res){                
                $scope.postlevante = res.data;						
				$scope.postlevanteBD = angular.copy(res.data);
				if(res.data.accion=='N'){
					$scope.disabledGrabar   = false; 	
					$scope.disabledModificar= true; 	
					$scope.disabledEliminar = true;
				}				
				if(res.data.accion=='M'){
					$scope.disabledGrabar   = true; 	
					$scope.disabledModificar= false; 	
					$scope.disabledEliminar = false;
					
				}				
				if(res.data.accion=='R'){
					$scope.disabledGrabar   = true; 	
					$scope.disabledModificar= true; 	
					$scope.disabledEliminar = true;	
					$scope.mostrarMsj = true;
					$scope.msjValidacion = res.data.msjError;
				}
            });
		
        $('.panel-collapse').collapse('show');		
    }

    $scope.grabar  = function() {

        if($scope.tieneAlMenosUnaOpcionMarcada()){
            $scope.postlevante.accion = 'N';						
			$http.post('./grabar_solicitudpostlevante',$scope.postlevante)
                .success(function(res,status) {
					$scope.mostrarMsj = true;
                    if(angular.isDefined(res.msjError)){                      
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
							$scope.msjValidacion = "La solicitud Post-Levante fue grabado correctamente.";	
						alert($scope.msjValidacion);	
                        $scope.mostrarFormBusquedaDeclaracion();						
					}
            }).error(function (data, status) {
				$scope.mostrarMsj = true;
                $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";						
            });
        }else{
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "Debe seleccionar por lo menos un motivo.";
        }
    };


	$scope.mostrarFormBusquedaDeclaracion = function () {		
        $location.path("/form_busquedadeclaracion");
    };
	
	$scope.modificar = function () {
        if($scope.tieneAlMenosUnaOpcionMarcada()){
       $scope.postlevante.accion = 'M';	   	   
	   $http.post('./grabar_solicitudpostlevante',$scope.postlevante)
                .success(function(res,status) {
					$scope.mostrarMsj = true;
                    if(angular.isDefined(res.msjError)){                      
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.msjValidacion = "La solicitud Post-Levante fue modificado correctamente.";	
						alert($scope.msjValidacion);
						$scope.mostrarFormBusquedaDeclaracion();
					}
            }).error(function (data, status) {
				$scope.mostrarMsj = true;
                $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";						
            });			
        }else{
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "Debe seleccionar por lo menos un motivo.";
        }
    };

	$scope.eliminar = function () {
       $scope.postlevante.accion = 'E';	   	   
	   $http.post('./grabar_solicitudpostlevante',$scope.postlevante)
                .success(function(res,status) {
					$scope.mostrarMsj = true;
                    if(angular.isDefined(res.msjError)){                      
						$scope.msjValidacion = res.msjError;						
                    }else{													   					
						$scope.msjValidacion = "La solicitud de Post-Levante fue eliminado correctamente.";												
					    alert($scope.msjValidacion);						
						$scope.mostrarFormBusquedaDeclaracion();
					}
            }).error(function (data, status) {
				$scope.mostrarMsj = true;
                $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";						
            });			
    };
	
	$scope.salir = function () {
        $scope.mostrarFormBusquedaDeclaracion();
    };

    $scope.maximoCaracteres = function (maxLength) {
        if ($scope.postlevante.sustentoPostLevante.length > maxLength) {
            $scope.postlevante.sustentoPostLevante = $scope.postlevante.sustentoPostLevante.substring(0, maxLength);
        }
    };

    $scope.tieneAlMenosUnaOpcionMarcada = function () {
        var rspta=false;
        angular.forEach($scope.postlevante.lstMotivos, function (motivo) {
            if(motivo.checked) rspta = true;
        });
        return rspta;
    };

	$scope.habilitarBoton = function() {
		if($scope.disabledModificar==false){
		 if(angular.equals($scope.postlevante, $scope.postlevanteBD)){
			return true; //se deshabilita el boton
		  }else{
			return false; //se habilita el boton
          }		
		}else{
			return true; //se deshabilita el boton
		}          
    };    
	

	
    $scope.cargarRegimenes();
    $scope.cargarAduanas();
	$scope.cargarModalidades();
	$scope.cargarCanales();
	$scope.cargarEstados();	
	$scope.cargarFormSolicitudPostLevante();
};


