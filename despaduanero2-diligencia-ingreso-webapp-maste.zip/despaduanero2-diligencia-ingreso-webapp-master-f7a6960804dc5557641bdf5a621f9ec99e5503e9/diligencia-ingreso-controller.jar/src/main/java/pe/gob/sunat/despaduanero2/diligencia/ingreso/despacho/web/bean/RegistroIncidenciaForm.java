package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.bean;



import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;


public class RegistroIncidenciaForm extends Incidencia {

    private static final long serialVersionUID = -3860433275869453718L;


	private String codIncidenciaDescrip;
    private boolean chkSeleccionado;
    private boolean chkHabilitarPatronSeries;
    private String patronSeriesAfectados;



    public boolean isChkSeleccionado() {
        return chkSeleccionado;
    }

    public void setChkSeleccionado(boolean chkSeleccionado) {
        this.chkSeleccionado = chkSeleccionado;
    }

    public boolean isChkHabilitarPatronSeries() {
        return chkHabilitarPatronSeries;
    }

    public void setChkHabilitarPatronSeries(boolean chkHabilitarPatronSeries) {
        this.chkHabilitarPatronSeries = chkHabilitarPatronSeries;
    }

    public String getPatronSeriesAfectados() {
        return patronSeriesAfectados;
    }

    public void setPatronSeriesAfectados(String patronSeriesAfectados) {
        this.patronSeriesAfectados = patronSeriesAfectados;
    }


    public String getCodIncidenciaDescrip() {
		return codIncidenciaDescrip;
	}

	public void setCodIncidenciaDescrip(String codIncidenciaDescrip) {
		this.codIncidenciaDescrip = codIncidenciaDescrip;
	}



}
