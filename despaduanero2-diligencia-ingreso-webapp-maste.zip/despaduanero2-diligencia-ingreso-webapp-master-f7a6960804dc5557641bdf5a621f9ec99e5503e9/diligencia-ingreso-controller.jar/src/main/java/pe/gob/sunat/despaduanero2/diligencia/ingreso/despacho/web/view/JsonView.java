package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.view;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.core.UniqueIdGenerator;
import net.sf.sojo.core.filter.ClassPropertyFilter;
import net.sf.sojo.core.filter.ClassPropertyFilterHandlerImpl;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.view.AbstractView;

public class JsonView extends AbstractView {
	protected final Log log = LogFactory.getLog(getClass());

	private static String[] FILTERED_ATTRS = {UniqueIdGenerator.UNIQUE_ID_PROPERTY,"class"};//new String[]{"class", UniqueIdGenerator.UNIQUE_ID_PROPERTY}
	private String formatoFechaDefault = "dd/MM/yyyy HH:mm:ss";
	private String formatoFecha;

	protected void renderMergedOutputModel(Map map, HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		Object model = null;

		log.debug("Convirtiendo a JSON el Bean: " + this.getBeanName() + " data " + map);
		model = map.get("datamodel");

		String customizeDateFormat = (String)map.get("formatoFecha");
		if(StringUtils.isBlank(customizeDateFormat)){
			customizeDateFormat = getFormatoFecha();
		}
		//ya no tiene utilidad
		map.remove("formatoFecha");
		List<Class> listClasesTofilterId = null;
		ClassPropertyFilterHandlerImpl filterHandler = null;

		try{
			listClasesTofilterId = (List<Class> )map.get("listClasesTofilterId");
			filterHandler = createFilterHandle(listClasesTofilterId);
		}catch(Exception e){
			//no se hace nada solo es para filtar los id de la lista de clases
		}
		//ya no tiene utilidad
		map.remove("listClasesTofilterId");

		JsonSerializer serializer = new JsonSerializer();
		serializer.getObjectUtil().addFormatterForType(new SimpleDateFormat(customizeDateFormat), java.sql.Date.class);
		serializer.getObjectUtil().addFormatterForType(new SimpleDateFormat(customizeDateFormat), java.util.Date.class);


		// set the handler to the Serializer
		if(filterHandler != null){
			serializer.setClassPropertyFilterHandler(filterHandler);
		}




		String serialized = null;
		if(model != null) {
		  serialized = (String) serializer.serialize(model);
		}	else {
		  serialized = (String) serializer.serialize(map);
		}

		if(StringUtils.isEmpty(getContentType())) {
			setContentType("text/plain;charset=utf-8");
		}

		response.setContentType(getContentType());
		response.setHeader("Cache-Control", "no-cache");

		response.getWriter().write(serialized);
		log.debug("Devolviendo : JSON=" + serialized);
	}

	/**
	 * Crea el filtro para eliminar lso id de las claes en la lista
	 * @param listClasesTofilterId
	 * @return
	 */
	private ClassPropertyFilterHandlerImpl createFilterHandle(
			List<Class> listClasesTofilterId) {

		// create a handler for the filter (this is the jdk 1.4 handler)
		ClassPropertyFilterHandlerImpl handler = new ClassPropertyFilterHandlerImpl();
		for (Class class1 : listClasesTofilterId) {

			ClassPropertyFilter classPropertyFilter = new ClassPropertyFilter(class1);

			classPropertyFilter.addProperties(FILTERED_ATTRS);//   y(UniqueIdGenerator.UNIQUE_ID_PROPERTY);
			handler.addClassPropertyFilter(classPropertyFilter);

		}

		ClassPropertyFilter classPropertyFilter = new ClassPropertyFilter(pe.gob.sunat.framework.spring.util.bean.MensajeBean.class);

		classPropertyFilter.addProperties(FILTERED_ATTRS);//   y(UniqueIdGenerator.UNIQUE_ID_PROPERTY);
		handler.addClassPropertyFilter(classPropertyFilter);



		return handler;
	}

	public String getFormatoFecha() {
		if(this.formatoFecha==null){
			return this.formatoFechaDefault;
		}
		return formatoFecha;
	}

	public void setFormatoFecha(String formatoFecha) {
		this.formatoFecha = formatoFecha;
	}
}
