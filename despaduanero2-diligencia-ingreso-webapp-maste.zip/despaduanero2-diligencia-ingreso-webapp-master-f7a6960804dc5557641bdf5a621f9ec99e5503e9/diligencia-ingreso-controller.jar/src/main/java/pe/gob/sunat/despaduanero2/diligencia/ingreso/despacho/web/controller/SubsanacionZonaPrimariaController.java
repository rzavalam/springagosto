package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SubsanacionZonaPrimariaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.model.Spr;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

/**
 * <p>Title: SubsanacionZonaPrimariaController</p>
 * <p>Description: Clase Control para la Subsanacion de Observacion ZPAE</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public class SubsanacionZonaPrimariaController extends AbstractDespachoController {

	        
	private SubsanacionZonaPrimariaService subsanacionZonaPrimariaService;
	
	private BindingResult errors;
	
	protected void bind(HttpServletRequest request, Object command) throws Exception {
        ServletRequestDataBinder binder = createBinder(request, command);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy"); 
        CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
        binder.registerCustomEditor(Date.class, editor);
        binder.bind(request);
        errors = binder.getBindingResult();
    }
	
	/**
	 * Carga la p�gina incial de b�squeda de declaraci�n
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return Vista de b�squeda de declaraci�n
	 * @author gbecerrav
	 */
	public ModelAndView cargarBusquedaDeclaracion (HttpServletRequest request, HttpServletResponse response) throws Exception {	
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);	
			request.setAttribute("titulo", "Subsanaci�n de Observaci�n ZPAE");
			request.setAttribute("codigoDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			//request.setAttribute("aduana", this.obtenerAduana(usuario));
			Map<String, String> params = new HashMap<String, String>();
			String aduana=this.obtenerAduana(usuario);
			params.put("aduana", aduana);
			List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", aduana);
			params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
			
			ModelAndView res = new ModelAndView("/ZPAE/BusqDeclaracion", "params", params);
			return res;
			
			//return new ModelAndView("/ZPAE/BusqDeclaracion");
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
		    return showErrorPagM(e.getMessage());
		}
	}
	
	/**
	 * Busca declaraci�n y sobre esta realiza 
	 * las validaciones para el proceso de subsanacion ZPAE
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return Error de validaci�n de b�squeda de declaraci�n
	 * @author gbecerrav
	 */
	public ModelAndView buscarDeclaracion (HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> modelo = new HashMap<String, Object>();
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);	
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String aduana = webRequest.getParameter("sel_cod_aduana");		
			String anio = webRequest.getParameter("anioDeclaracion");
			String regimen = webRequest.getParameter("codRegimen");
			String numero = webRequest.getParameter("numDeclaracion");
			
			//Validar la declaracion para el proceso de subsanacion de obs zpae, si todo ok obtiene declaracion
			ObjectResponseUtil rpta = this.subsanacionZonaPrimariaService.validarDeclaracion(aduana, anio != null ? Integer.parseInt(anio) : null, regimen, numero != null ? Integer.parseInt(numero) : null, usuario);
				
			if(!rpta.isRespuesta()){
				modelo.put("Error", rpta.getMensajes().get(0));
				return new ModelAndView("jsonView", modelo);
			}
			
			//Seteamos los datos a session
			WebUtils.setSessionAttribute(request, "dua", (DUA)rpta.getDatos().get("dua"));
			WebUtils.setSessionAttribute(request, "incidencia", (Incidencia)rpta.getDatos().get("incidencia"));
			WebUtils.setSessionAttribute(request, "expediente", (Expedi)rpta.getDatos().get("expediente"));
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		return new ModelAndView("jsonView", modelo);
	}

	/**
	 * Carga la p�gina para iniciar la diligencia previa
	 * @param request
	 * @param response
	 * @return Vista de Iniciar Diligencia Previa
	 * @author gbecerrav
	 */
	public ModelAndView cargarRegistrarSubsanacionObsZPAE(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			DUA dua = (DUA)WebUtils.getSessionAttribute(request, "dua");
			
			//Obtenemos los datos adicionales de la declaracion
			this.subsanacionZonaPrimariaService.adicionarDatosDeclaracion(dua);
			
			//Obtenemos establecimiento
			Spr establecimiento = this.subsanacionZonaPrimariaService.obtenerEstablecimiento(dua);
			request.setAttribute("establecimiento", establecimiento);
			
			return new ModelAndView("/ZPAE/RegSubsanacionObsZPAE");
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		}
	}
	
	/**
	 * Registra Diligencia Previa 
	 * (Diligencia Previa - Seccion 02)
	 * @param request
	 * @param response
	 * @return Error en el proceso o mensaje ok
	 * @author gbecerrav
	 */
	public ModelAndView registrarSubsanacionObsZPAE(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		try {
			UsuarioBean usuario = this.verificarAutenticacion(request);
			UserNameHolder.set(usuario.getNroRegistro());
			
			DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
			Incidencia incidencia = (Incidencia) WebUtils.getSessionAttribute(request, "incidencia");
			Expedi expediente = (Expedi) WebUtils.getSessionAttribute(request, "expediente");
			
			//Registramos la subsanacion de observacion ZPAE
			SolicitudSubsanacion solicitudSubsanacion = new SolicitudSubsanacion();
			//Seteamos valor de formulario
			bind(request, solicitudSubsanacion);
			
			//Seteamos otros valores
			solicitudSubsanacion.setIncidencia(incidencia);
			solicitudSubsanacion.setExpediente(expediente);
			this.subsanacionZonaPrimariaService.grabarSubsnacionObsZPAE(solicitudSubsanacion, dua);
			
			return new ModelAndView("jsonView", new HashMap<String, Object>()); //rpta ok?
						
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
	}

	/**
	 * Carga la p�gina de consulta de subsanacion de observacion ZPAE
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return Vista de consulta de subsanacion de observacion ZPAE
	 * @author gbecerrav
	 */
	public ModelAndView cargarConsultaSubsanacionObsZPAE(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		try {
			UsuarioBean usuario = this.verificarAutenticacion(request);	
			//request.setAttribute("aduana", this.obtenerAduana(usuario));
			
			//return new ModelAndView("ConsultaSubsnacionObsZPAE");
			
			Map<String, String> params = new HashMap<String, String>();
			String aduana=this.obtenerAduana(usuario);
			params.put("aduana", aduana);
			List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", aduana);
			params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
			
			ModelAndView res = new ModelAndView("ConsultaSubsnacionObsZPAE", "params", params);
			return res;
			
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
		    return showErrorPagM(e.getMessage());
		}
	}

	/**
	 * Busca declaraci�n y sobre esta realiza 
	 * las validaciones para el proceso de subsanacion ZPAE
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return Error de validaci�n de b�squeda de declaraci�n
	 * @author gbecerrav
	 */
	public ModelAndView consultarSubsanacionObsZPAE(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			this.verificarAutenticacion(request);
			Map<String, Object> modelo = new HashMap<String, Object>();
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			
			String aduanaDeclaracion = webRequest.getParameter("codAduana");
			String regimenDeclaracion = webRequest.getParameter("codRegimen");
			String anioDeclaracion = webRequest.getParameter("anioDeclaracion");
			String numeroDeclaracion = webRequest.getParameter("numDeclaracion");
			String numeroExpediente = webRequest.getParameter("numExpediente");
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("aduanaDeclaracion", aduanaDeclaracion);
			params.put("regimenDeclaracion", !StringUtils.isEmpty(regimenDeclaracion) ? regimenDeclaracion : null);
			params.put("anioDeclaracion", !StringUtils.isEmpty(anioDeclaracion) ? Integer.parseInt(anioDeclaracion) : null);
			params.put("numeroDeclaracion", !StringUtils.isEmpty(numeroDeclaracion) ? Integer.parseInt(numeroDeclaracion) : null);
			params.put("numeroExpediente", !StringUtils.isEmpty(numeroExpediente) ? Integer.parseInt(numeroExpediente) : null);
			
			String fechaInicio = webRequest.getParameter("fechaInicio");
			String fechaFin = webRequest.getParameter("fechaFin");

			if (!StringUtils.isEmpty(fechaInicio) && !StringUtils.isEmpty(fechaFin)) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
				
				fechaInicio += " 00:00:00";
				params.put("fechaInicio", dateFormat.parse(fechaInicio));
					
				fechaFin += " 23:59:59";
				params.put("fechaFin", dateFormat.parse(fechaFin));	
					
				params.put("rangoFecha", true);
				
			} else {
				params.put("rangoFecha", false);
			}
				
			//Realizamos la consulta
			List<SolicitudSubsanacion> lista = this.subsanacionZonaPrimariaService.consultarSubsanacionObsZPAE(params);
			modelo.put("items", lista);
			return new ModelAndView("jsonView", modelo);
			
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
	}

	/**
	 * @return the subsanacionZonaPrimariaService
	 */
	public SubsanacionZonaPrimariaService getSubsanacionZonaPrimariaService() {
		return subsanacionZonaPrimariaService;
	}

	/**
	 * @param subsanacionZonaPrimariaService the subsanacionZonaPrimariaService to set
	 */
	public void setSubsanacionZonaPrimariaService(
			SubsanacionZonaPrimariaService subsanacionZonaPrimariaService) {
		this.subsanacionZonaPrimariaService = subsanacionZonaPrimariaService;
	}

	/**
	 * @return the errors
	 */
	public BindingResult getErrors() {
		return errors;
}
	
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(BindingResult errors) {
		this.errors = errors;
	}
}
