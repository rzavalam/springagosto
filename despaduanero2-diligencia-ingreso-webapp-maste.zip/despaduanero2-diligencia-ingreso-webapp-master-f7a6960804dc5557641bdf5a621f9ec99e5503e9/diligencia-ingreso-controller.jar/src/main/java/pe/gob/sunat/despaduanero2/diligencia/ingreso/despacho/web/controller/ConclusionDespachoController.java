package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;


import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.ACTA_INCAUTACION;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.ACTA_INMOVILIZACION;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_DOCUMENTO_ADUANERO;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.SecuenciaDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.ValidaContingentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidacionGeneralService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.SolicitudRecepcion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.recepcion.service.RecepcionDocumentosService;
import pe.gob.sunat.despaduanero2.declaracion.recepcion.util.ConstantesDeclaracion;
import pe.gob.sunat.despaduanero2.declaracion.service.ObservacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ResponseBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFleteYPesoPorDocTransporteBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.descrminima.web.controller.BytesObjectUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.bean.RegistroIncidenciaForm;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionCalculoDeDatosService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaException;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaSimplificadaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.GetDeclaracionHashMapToDeclaracionObjectHelper;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.IncidenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.OrquestadorDiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteAvisosService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ValidaDiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.StringUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.WUtil;
import pe.gob.sunat.despaduanero2.entradasalida.service.EntradaSalidaService;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.SoliProrroga;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.SoliProrrogaDAO;
import pe.gob.sunat.despaduanero2.service.SolicitudService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.prevcontrabando2.ace.util.ConstantesACE;
import pe.gob.sunat.prevcontrabando2.ace.util.Util;
import pe.gob.sunat.recauda2.garantia.service.PadronUsuarioService;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.sigad.sini.service.SiniConsultaService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;//P24-II

public class ConclusionDespachoController extends AbstractDespachoController
{
	public static final String DOCUMENTO_DETERMINACION = "D";
	protected final Log          log                  = LogFactory.getLog(getClass());

  private DeclaracionService   declaracionService;

  private DiligenciaService    diligenciaService;

  //private CatalogoAyudaService catalogoAyudaService;

  private SoporteService soporteService;

  private FormatoValorService   formatoValorService;

  private String               jsonView;

  private SerieService        serieService;
  // hsaenz: 10/09/2014:
  private FabricaDeServicios fabricaDeServicios;
  // Fin hsaenz: 10/09/2014

  String lisdatoMsj = new String();
  private String indValorProvisional = "";

  private static final String COD_TIPO_DILIGENCIA_CONCLUSION = "05";
  private static final String REGIMEN_PRECEDENTE_CETICO = "91";
  private static final String IND_REGISTRO_GRABADO = "0";

  private static final String FORMAT_ddMMyyyy = "dd/MM/yyyy";

  private static final String NRO_TRANSACCION = "1012";
  private static final String DEFAULT_TIPO_DOC = "01"; //P24-II

  private DiligenciaSimplificadaService diligenciaSimplificadaService;
  private RectificacionService rectificacionService; //P24-II

	/**
	 * Carga la busqueda de la declaraci�n para la conclusi�n
   * @param request HttpServletRequest
   * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
   * */
  public ModelAndView cargarBusqDeclaracion(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  try {
	      UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      if(userSession!=null){
	      userSession.setNroRegistro(userSession.getNroRegistro().trim());
	      WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
		  }else{
	        return new ModelAndView("PagM", "message", "Usuario no logueado");
	      }

	      Utilidades.inicializarMapasSesion(request);
	      UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());

	      ServletWebRequest webRequest = new ServletWebRequest(request);
	      String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : soporteService
	              .obtenerAduana(request);
	      String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String
	              .valueOf(Calendar.getInstance().get(Calendar.YEAR));
	      String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
	      String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
	          .getParameter("numDeclaracion") : "";
		  String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";

	      Map<String, String> params = new HashMap<String, String>();


	      params.put("cod_aduana", codAduana);
	      params.put("ann_presen", annPresen);
	      params.put("cod_regimen", codRegimen);
	      //params.put("num_declaracion", numDeclaracion);
		  params.put("num_declaracion", numDecla);
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      params.put("esPostLevante",webRequest.getParameter("hdn_Post_Levante") != null ? webRequest.getParameter("hdn_Post_Levante"):"");//adicionado por PAS20165E220200032
	      /*ModelAndView res = new ModelAndView("BusqDeclaracionConcl");
	      res.addObject("params", params);
	      res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));

	      List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
	      for (Map<String, String> map : lstAduana)
	      {
	        map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
	        if (((String) map.get("cod_datacat")).equals(codAduana)){
	        	params.put("des_aduana", (map.get("cod_datacat").toString()).concat("-").concat(map.get("des_corta").toString()));
	        }
	      }
	      res.addObject("lstAduana", SojoUtil.toJson(lstAduana));

	      return res;*/
		  List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		  params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

		  ModelAndView res = new ModelAndView("BusqDeclaracionConcl", "params", params);
		  res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));
	      return res;


	    }
	    catch (Exception e)
	    {
	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView("PagM", "Error", rBean);
	    }
  }
  	//PAS20155E220200101-Inicio
	/**
	 * Carga la busqueda de la declaraci�n para la prorroga de la conclusion
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
	 * */
  	public ModelAndView cargarBusqDeclaParaProrrogaConcl(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  try {
	      UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      if(userSession!=null){
	      userSession.setNroRegistro(userSession.getNroRegistro().trim());
	      WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
		  }else{
	        return new ModelAndView("PagM", "message", "Usuario no logueado");
	      }

	      Utilidades.inicializarMapasSesion(request);
	      UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());

	      ServletWebRequest webRequest = new ServletWebRequest(request);
	      String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : soporteService
	              .obtenerAduana(request);
	      String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String
	              .valueOf(Calendar.getInstance().get(Calendar.YEAR));
	      String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
	      String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
	          .getParameter("numDeclaracion") : "";
		  String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
	      Map<String, String> params = new HashMap<String, String>();


	      params.put("cod_aduana", codAduana);
	      params.put("ann_presen", annPresen);
	      params.put("cod_regimen", codRegimen);
	      params.put("num_declaracion", numDeclaracion);
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

	      /*ModelAndView res = new ModelAndView("BusqDeclaProrrogaConclusion");
	      res.addObject("params", params);
	      res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));

	      List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
	      for (Map<String, String> map : lstAduana)
	      {
	        map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
	        if (((String) map.get("cod_datacat")).equals(codAduana)){
	        	params.put("des_aduana", (map.get("cod_datacat").toString()).concat("-").concat(map.get("des_corta").toString()));
	        }
	      }
	      res.addObject("lstAduana", SojoUtil.toJson(lstAduana));*/
		  List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		  params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

		  ModelAndView res = new ModelAndView("BusqDeclaProrrogaConclusion", "params", params);
		  res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));
	      return res;

	    }
	    catch (Exception e)
	    {
	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView("PagM", "Error", rBean);
	    }
  	}
//PAS20155E220200101-Fin


  	/**Inicio  pase PAS20165E220200032
	 * Carga la busqueda de la declaraci�n para Post Levante
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
	 * */
  public ModelAndView cargarBusqDeclaracionPostLevante(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  try {
	      UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      if(userSession!=null){
	      userSession.setNroRegistro(userSession.getNroRegistro().trim());
	      WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
		  }else{
	        return new ModelAndView("PagM", "message", "Usuario no logueado");
	      }

	      Utilidades.inicializarMapasSesion(request);
	      UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());

	      ServletWebRequest webRequest = new ServletWebRequest(request);
	      String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : soporteService
	              .obtenerAduana(request);
	      String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String
	              .valueOf(Calendar.getInstance().get(Calendar.YEAR));
	      String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
	     /* String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
	          .getParameter("numDeclaracion") : "";*/
	      String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
	      Map<String, String> params = new HashMap<String, String>();


	      params.put("cod_aduana", codAduana);
	      params.put("ann_presen", annPresen);
	      params.put("cod_regimen", codRegimen);
	      //params.put("num_declaracion", numDeclaracion);
		  params.put("num_declaracion", numDecla);
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      params.put("esPostLevante","1");//para cambiar las etiquetas

	      /*ModelAndView res = new ModelAndView("BusqDeclaracionConcl");
	      res.addObject("params", params);
	      res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));

	      List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
	      for (Map<String, String> map : lstAduana)
	      {
	        map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
	        if (((String) map.get("cod_datacat")).equals(codAduana)){
	        	params.put("des_aduana", (map.get("cod_datacat").toString()).concat("-").concat(map.get("des_corta").toString()));
	        }
	      }
	      res.addObject("lstAduana", SojoUtil.toJson(lstAduana));

	      return res;*/
		  List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		  params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

		  ModelAndView res = new ModelAndView("BusqDeclaracionConcl", "params", params);
		  res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));
	      return res;

	    }
	    catch (Exception e)
	    {
	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView("PagM", "Error", rBean);
	    }
  }



     /**
	 * Carga la busqueda de la declaraci�n para la prorroga de Post Levante
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
	 * */
	public ModelAndView cargarBusqDeclaParaProrrogaPostL(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  try {
	      UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      if(userSession!=null){
	      userSession.setNroRegistro(userSession.getNroRegistro().trim());
	      WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
		  }else{
	        return new ModelAndView("PagM", "message", "Usuario no logueado");
	      }

	      Utilidades.inicializarMapasSesion(request);
	      UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());

	      ServletWebRequest webRequest = new ServletWebRequest(request);
	      String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : soporteService
	              .obtenerAduana(request);
	      String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String
	              .valueOf(Calendar.getInstance().get(Calendar.YEAR));
	      String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
	      String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
	          .getParameter("numDeclaracion") : "";
		  String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
	      Map<String, String> params = new HashMap<String, String>();


	      params.put("cod_aduana", codAduana);
	      params.put("ann_presen", annPresen);
	      params.put("cod_regimen", codRegimen);
	      params.put("num_declaracion", numDeclaracion);
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      params.put("esPostLevante","1");//para cambiar las etiquetas

	      /*ModelAndView res = new ModelAndView("BusqDeclaProrrogaConclusion");
	      res.addObject("params", params);


	      List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
	      for (Map<String, String> map : lstAduana)
	      {
	        map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
	        if (((String) map.get("cod_datacat")).equals(codAduana)){
	        	params.put("des_aduana", (map.get("cod_datacat").toString()).concat("-").concat(map.get("des_corta").toString()));
	        }
	      }
	      res.addObject("lstAduana", SojoUtil.toJson(lstAduana));

	      return res;*/
		  List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		  params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

		  ModelAndView res = new ModelAndView("BusqDeclaProrrogaConclusion", "params", params);
		  res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));
	      return res;
	    }
	    catch (Exception e)
	    {
	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView("PagM", "Error", rBean);
	    }
	}

  /**
   * M�todo q determina si existe una diligencia de conclusion ya almacenada
   * @param request
   * @param response
   * @return
   * @throws Exception
   */
  public ModelAndView validarActualizacionConclusion(HttpServletRequest request, HttpServletResponse response)
          throws Exception
  {
		Utilidades.limpiarMapasSesion(request);

		Map<String, Object> params = new HashMap<String, Object>();
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		params.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
		params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
		params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
		params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
		params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
		params.put("COD_TIPDILIGENCIA",  Constantes.DILIG_CONCLUSION_DESPACHO);
        params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

		Object objRes = null;
		String objName = "validaActualizacionMap";
		try
		{
			 Map<String,Object> declaracion = declaracionService.obtenerDeclaracion(params);
			 params.put("declaracion", declaracion);//adicionado por PAS20165E220200032

			if(declaracion != null && Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals(declaracion.get("COD_ESTDUA").toString())){
				params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
				params.put("FEC_CONCLUSION", declaracion.get("FEC_CONCLUSION"));
				params.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));//adicionado por PAS20165E220200032
				params.put("NUM_CTACTE", declaracion.get("NUM_CTACTE"));//adicionado por PAS20165E220200032
				params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));//adicionado por PAS20165E220200032
				Map<String,Object> validaActualizacion = diligenciaService.validarActualizacionConclusion(params);
				if((Boolean)validaActualizacion.get("regOK")){
						WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
						WebUtils.setSessionAttribute(request, "cabDiligenciaActualizar", (Map)validaActualizacion.get("CAB_DILIGENCIA"));
						WebUtils.setSessionAttribute(request, "hdn_Post_Levante", request.getParameter("hdn_Post_Levante"));
				}
					objName = "validaActualizacion";
					objRes = validaActualizacion;

			}

		} catch (DiligenciaException e){
			log.error("*** error validarExisteDiligencia ***", e);
			objRes = "Ocurrio un error por facor comuniquese con el administrador.";
			objName = "msjError";
		}
		return new ModelAndView(this.jsonView,objName, objRes);
  }


  /**
   * Realiza las validaciones para la conclusi�n de despacho
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @throws Exception
   */
  public ModelAndView validarDeclaParaConclucionDespacho(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);

    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
      params.put("codigoFuncionario", bUsuario.getNroRegistro());
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("txt_ann_presen"));
      params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
      params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
      params.put("caduana", request.getParameter("hdn_cod_aduana"));
      params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

      Map<String, Object> declaracion = declaracionService.validarDeclaParaConclucionDespacho(params);
      if(declaracion.get("existeDua").equals(true)&&MapUtils.esValorMapaNuloOVacio(declaracion, "error")){

    	  String tituloDiligencia = "Conclusi�n de Despacho";
    	  /**Inicio de cambios por PAS20165E220200032**/
			if(request.getParameter("hdn_Post_Levante")!=null && request.getParameter("hdn_Post_Levante").toString().equals("1")){
				tituloDiligencia=(String) catalogoAyudaService.getElementoCat(Constantes.CAT_TIPO_DILIGENCIA, COD_TIPO_DILIGENCIA_CONCLUSION).get("des_corta");
			}
			/**Fin de cambios por PAS20165E220200032**/
    	  declaracion.put("tituloDiligencia", tituloDiligencia);

    	  WebUtils.setSessionAttribute(request, "tipoDiligencia", COD_TIPO_DILIGENCIA_CONCLUSION);
    	  WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
    	  res.addObject("resOk", true);
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror((String) declaracion.get("error"));
        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
        log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : "
            + rBean.getMensajeerror());
        res.addObject("beanM", rBean);
      }

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : " + e.getMessage());
      res.addObject("beanM", rBean);
    }

    return res;
  }

  //PAS20155E220200101 - Inicio
  /**
   * Realiza las validaciones para la prorroga de conclusi�n
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @throws Exception
   */
  public ModelAndView validarDeclaParaProrrogaDeConclucion(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);

    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
      params.put("codigoFuncionario", bUsuario.getNroRegistro());
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("txt_ann_presen"));
      params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
      params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
      params.put("caduana", request.getParameter("hdn_cod_aduana"));
      params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

      Map<String, Object> declaracion = declaracionService.validarDeclaParaProrrogaConclusion(params);

      if(declaracion.get("existeDua").equals(true)&&MapUtils.esValorMapaNuloOVacio(declaracion, "error")){
    	  WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
    	  res.addObject("resOk", true);
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror((String) declaracion.get("error"));
        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
        log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : "
            + rBean.getMensajeerror());
        res.addObject("beanM", rBean);
      }

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : " + e.getMessage());
      res.addObject("beanM", rBean);
    }

    return res;
  }

  //PAS20155E220200101 - Fin

  public ModelAndView buscarAdvertenciasDeclaracion(HttpServletRequest request, HttpServletResponse response){
	  ModelAndView res = new ModelAndView(this.jsonView);
	  try{
		  Map<String,Object> declaracion = (Map<String,Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
		  if(declaracion != null && declaracion.get("existeDua").equals(true)&&MapUtils.esValorMapaNuloOVacio(declaracion, "error"))
	      {
		      res.addObject( "estadoTexto", declaracion.get("FLAG_NUMERO"));
		      //parametros para advertencias
		      Map<String, Object> mapPkManifiesto = new HashMap<String, Object>();
		      mapPkManifiesto.put("COD_ADUAMANIFIESTO", declaracion.get("COD_ADUAMANIFIESTO").toString());
		      mapPkManifiesto.put("ANN_MANIFIESTO", declaracion.get("ANN_MANIFIESTO").toString());
		      mapPkManifiesto.put("NUM_MANIFIESTO", declaracion.get("NUM_MANIFIESTO").toString());
		      mapPkManifiesto.put("COD_VIATRANS", declaracion.get("COD_VIATRANS").toString());

		      Map<String, Object> mapPkDua = new HashMap<String, Object>();
		      mapPkDua.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
		      mapPkDua.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
		      mapPkDua.put("ANN_PRESEN", declaracion.get("ANN_PRESEN"));
		      mapPkDua.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));

		      String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();


		      Map<String,Object> mapAdvertencias = new HashMap<String,Object>();
		      mapAdvertencias.put("listExpediDua",obtenerExpedientes(declaracion));
		      mapAdvertencias.putAll(soporteService.obtenerTodasActasConclusionDespacho(numCorreDoc,mapPkManifiesto,mapPkDua));


		      List<Map<String, Object>> lstAdvertencias = formatearDataAdvertenciasForJSP(mapAdvertencias);


		      Map<String,Object> indCambio=lstAdvertencias.get(lstAdvertencias.size()-1);
		      int indicadorCambio=(Integer) indCambio.get("indCambio");

		      lstAdvertencias.remove(lstAdvertencias.size()-1);
		      /*inicio-p14*/
				List<ComunicacionDescripcion> listaComunicacionesPendientes = null;
				int numeroComunicacionesPendientes = 0;
			  //amancilla LGA
				//if(declaracion.get("COD_ESTDUA_DESC").toString().equals(Constantes.ESTADO_NOTIFICADO_CONCLUSION_DESC)){
			   if(Constantes.ESTADO_CONCLU_NOTIFICADO.equals(declaracion.get("COD_ESTDUA").toString())){
				listaComunicacionesPendientes = diligenciaService.obtenerComunicacionesPendientes(Long.parseLong(numCorreDoc));
				numeroComunicacionesPendientes = listaComunicacionesPendientes.size();
				}
		      /*fin-p14*/
		      res.addObject( "lstAdvertencias", lstAdvertencias);
		      res.addObject( "indicadorCambio", indicadorCambio);
		      res.addObject( "numeroComunicacionesPendientes", numeroComunicacionesPendientes);
		      res.addObject("resOk", true);
	      }
		  else{
	          MensajeBean rBean = new MensajeBean();
	          rBean.setError(true);
	          rBean.setMensajeerror((String) declaracion.get("error"));
	          rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	          log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : "
	              + rBean.getMensajeerror());
	          res.addObject("beanM", rBean);
	        }
	  }
	  catch (Exception e)
	  {
	    MensajeBean rBean = new MensajeBean();
	    rBean.setError(true);
	    rBean.setMensajeerror(e.getMessage());
	    rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	    log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : " + e.getMessage());
	    res.addObject("beanM", rBean);
	  }

	  return res;

  }

  public ModelAndView declaracionTieneDudaRazonable(HttpServletRequest request, HttpServletResponse response){
	  ModelAndView res = new ModelAndView(this.jsonView);
	  Map<String,Object> declaracion = (Map<String,Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	  Boolean tieneDuda = declaracionService.duaTieneNotificacionDudaRazonable(declaracion);
	  if(tieneDuda){
		  res.addObject("tieneDuda",true);
		  res.addObject("MensajeError","Duda Razonable asociada a la declaraci�n, verifique.");
	  }
	  else{
		  res.addObject("tieneDuda",false);
        }
	  return res;
  }

  private List<Map<String, Object>> formatearDataAdvertenciasForJSP(Map<String, Object> mapAdvertencias){

	    List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> listExpediDua = (List)mapAdvertencias.get("listExpediDua");
	    List<Map<String, Object>> listActasDua = (List)mapAdvertencias.get("listActasDua");
	    List<Map<String, Object>> listAceDua = (List)mapAdvertencias.get("listAceDua");
	    List<Map<String, Object>> listActasVerificacionConDua = (List)mapAdvertencias.get("listActasVerificacionConDua");
	    List<Map<String, Object>> listBoletinesQuimicosRatificadoNoRatificado = (List)mapAdvertencias.get("listBoletinesQuimicosRatificadoNoRatificado");
	    Map<String, Object> mapActasAceAsociadosDocTransporte = (Map<String, Object>) mapAdvertencias.get("mapActasAceAsociadosDocTransporte");
	    List<Map<String, Object>> listActasDocTransporte = (List)mapActasAceAsociadosDocTransporte.get("listManifiestoActas");
	    List<Map<String, Object>> listAvisosInspeccion = (List)mapActasAceAsociadosDocTransporte.get("listAvisosIspeccion");

	    Map<String, Object> indicadorCambio = new HashMap<String, Object>();
	    boolean listOtrasAlertas=false;
	    boolean listAlertasBoletin=false;
	    int indCambio=0;


	    if (!CollectionUtils.isEmpty(listExpediDua)) {
	      for (Map<String, Object> mapAgregar: listExpediDua) {
	        Map mapFila = new HashMap<String, Object>();
	        mapFila.put("DOCUMENTO", "DUA cuenta con Expediente:");
	        mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO"));
	        mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
	        mapFila.put("ESTADO", "");
	        mapFila.put("SERIE",  "");
	        lstRspta.add(mapFila);
	      }

	      listOtrasAlertas=true;
	    }

	    if (!CollectionUtils.isEmpty(listActasDua)) {
	      for (Map<String, Object> mapAgregar: listActasDua) {
	        Map mapFila = new HashMap<String, Object>();

	        String codTipActa = StringUtil.defaultSiEsVacio(mapAgregar.get("CTIPO_ACTA").toString());
	        if(ACTA_INMOVILIZACION.equals(codTipActa))
	        {
	          mapFila.put("DOCUMENTO", "DUA cuenta con Acta de Inmovilizaci�n:");
	        }
	        else if(ACTA_INCAUTACION.equals(codTipActa))
	        {
	          mapFila.put("DOCUMENTO", "DUA cuenta con Acta de Incautaci�n:");
	        }
	        else
	        {
	          mapFila.put("DOCUMENTO", "DUA cuenta con Acta:");
	        }
	        mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO"));
	        mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
	        mapFila.put("ESTADO", "");
	        mapFila.put("SERIE",  "");
	        lstRspta.add(mapFila);
	      }
	      listOtrasAlertas=true;
	    }

	    if (!CollectionUtils.isEmpty(listAceDua)) {
	      for (Map<String, Object> mapAgregar: listAceDua) {

	        String acta = Util.obtenerPkConcatenado(mapAgregar,ConstantesACE.TIPO_CONCATENACION_ACTA);
	        FechaBean fbRegistro = new FechaBean(mapAgregar.get("FECHA_REGIS").toString(),"yyyyMMdd");
	        Map mapFila = new HashMap<String, Object>();
	        mapFila.put("DOCUMENTO", "DUA cuenta con Acci�n de Control Extraordinario:");
	        mapFila.put("NRODOCUMENTO", acta);
	        mapFila.put("FECHA", fbRegistro.getFormatDate("dd/MM/yyyy").toString());
	        mapFila.put("ESTADO", "");
	        mapFila.put("SERIE",  "");
	        lstRspta.add(mapFila);
	      }
	      listOtrasAlertas=true;
	    }


	    if (!CollectionUtils.isEmpty(listActasDocTransporte)) {
	      for (Map<String, Object> mapAgregar: listActasDocTransporte) {
	        Map mapFila = new HashMap<String, Object>();

	        String codTipActa = StringUtil.defaultSiEsVacio(mapAgregar.get("CTIPO_ACTA").toString());
	        if(ACTA_INMOVILIZACION.equals(codTipActa))
	        {
	          mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta de Inmovilizaci�n:");
	        }else if(ACTA_INCAUTACION.equals(codTipActa))
	        {
	          mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta de Incautaci�n:");
	        }else
	        {
	          mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta:");
	        }

	        mapFila.put("NRODOCUMENTO", mapAgregar.get("NROFULL"));
	        mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
	        mapFila.put("ESTADO", "");
	        mapFila.put("SERIE",  "");
	        lstRspta.add(mapFila);
	      }
	      listOtrasAlertas=true;
	    }


	    if (!CollectionUtils.isEmpty(listAvisosInspeccion)) {
	      for (Map<String, Object> mapAgregar: listAvisosInspeccion) {
	        Map mapFila = new HashMap<String, Object>();
	        mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Aviso de Inspecci�n:");
	        mapFila.put("NRODOCUMENTO",  mapAgregar.get("NROFULL"));
	        mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
	        mapFila.put("ESTADO", "");
	        mapFila.put("SERIE",  "");
	        lstRspta.add(mapFila);
	      }
	      listOtrasAlertas=true;
	    }

	    if (!CollectionUtils.isEmpty(listActasVerificacionConDua)) {
		      for (Map<String, Object> mapAgregar: listActasVerificacionConDua) {
		    	FechaBean fbRegistro = new FechaBean(mapAgregar.get("FECHA_HORA").toString(),"yyyyMMdd");
		        Map mapFila = new HashMap<String, Object>();
		        mapFila.put("DOCUMENTO", "DUA cuenta con Acta de Separaci�n:");
		        mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO").toString());
		        mapFila.put("FECHA", fbRegistro.getFormatDate("dd/MM/yyyy").toString());
		        mapFila.put("ESTADO", "");
		        mapFila.put("SERIE",  "");
		        lstRspta.add(mapFila);
		      }

		      listOtrasAlertas=true;
		    }



	    if (!CollectionUtils.isEmpty(listBoletinesQuimicosRatificadoNoRatificado)) {
		      for (Map<String, Object> mapAgregar: listBoletinesQuimicosRatificadoNoRatificado) {
		        Map mapFila = new HashMap<String, Object>();
		        mapFila.put("DOCUMENTO", "Boletin Quimico");
		        mapFila.put("NRODOCUMENTO", mapAgregar.get("NCORR_SOLBQ").toString());
		        mapFila.put("ESTADO", mapAgregar.get("SESTA_ANALIS_DESC").toString());
			    mapFila.put("SERIE",  mapAgregar.get("NSERIE_DUA").toString().trim());
			    mapFila.put("FECHA", "");
		        lstRspta.add(mapFila);
		      }

		      listAlertasBoletin=true;

		    }

	    if (listOtrasAlertas && listAlertasBoletin) {indicadorCambio.put("indCambio",3);  }
	    else if (listAlertasBoletin){	indicadorCambio.put("indCambio",2);}
	    else {indicadorCambio.put("indCambio",1);  }

	    lstRspta.add(indicadorCambio);

	    return lstRspta;

	  }


	//PAS20155E220200101 - Inicio

	/**
	 * Realiza la carga de la pantalla de prorroga de conclusion
	 *
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
	 */
	public ModelAndView iniciarProrrogaConclusion(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{

		ModelAndView res = null;

		UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

		if (userSession == null)
		{
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror("Usuario no logueado");
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error(this.toString().concat(" validarDeclaParaRectificacion - ERROR : ").concat("Usuario no logueado"));
			return new ModelAndView("PagM", "beanM", rBean);
		}
		UserNameHolder.set(userSession.getNroRegistro());
		Map<String, Object> declaracion;
		try
		{
			Map<String, Object> params = new HashMap<String, Object>();
			UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
			params.put("codigoFuncionario", bUsuario.getNroRegistro());
			params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
			params.put("ann_presen", request.getParameter("txt_ann_presen"));
			params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
			params.put("des_regimen", request.getParameter("hdn_des_regimen"));
			params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
			params.put("caduana", soporteService.obtenerAduana(request));
			params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

			declaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

			if(MapUtils.esMapaNuloOVacio(declaracion)){
				MensajeBean rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror("La declaracion no ha sido cargada en memoria.");
				rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : "
						+ rBean.getMensajeerror());
				res = new ModelAndView("PagM", "beanM", rBean);
			}

			String pagRes = "";
			if (!(Constantes.ESTADO_CONCLU_PROCESO.equals((String) declaracion.get("COD_ESTDUA"))  || Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals((String) declaracion.get("COD_ESTDUA"))))
			{
				pagRes = "IniciarProrrogaConclusion";
			}
			res = new ModelAndView(pagRes);

			/**Inicio de cambios por PAS20165E220200032**/
			String invocador="C";
			if(params.get("esPostLevante")!=null && params.get("esPostLevante").toString().equals("1")){
				invocador="L";
			}
			/**Fin de cambios por PAS20165E220200032**/
			//declaracion.put("COD_REGIMEN_DESC", request.getParameter("hdn_des_regimen"));//esta de mas.
			declaracion.put("tituloDiligencia", declaracionService.
					obtenerTituloDiligencia((String) declaracion.get("COD_CANAL"), invocador));//actualizado por PAS20165E220200032

			Map<String, Object> declaracionActual = new HashMap<String, Object>();
			declaracionActual.putAll(declaracion);

			WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
			WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);


			res.addObject("declaracion", declaracion);
			res.addObject("acceso", Constantes.TIPO_ACCESO_CONCLUSION);
			res.addObject("params", params);
		}
		catch (Exception e)
		{
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : " + e.getMessage());
			res = new ModelAndView("PagM", "beanM", rBean);
		}

		return res;
	}

  /**
   * Realiza la carga de la pantalla de conclusion correspondiente de acuerdo al
   * estado de la DUA
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @throws Exception
   */
  public ModelAndView iniciarConclusionDespacho(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {

    ModelAndView res = null;

    UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

    if (userSession == null)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror("Usuario no logueado");
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error(this.toString().concat(" validarDeclaParaRectificacion - ERROR : ").concat("Usuario no logueado"));
      return new ModelAndView("PagM", "beanM", rBean);
    }
    UserNameHolder.set(userSession.getNroRegistro());
    Map<String, Object> declaracion;
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
      params.put("codigoFuncionario", bUsuario.getNroRegistro());
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("txt_ann_presen"));
      params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
      params.put("des_regimen", request.getParameter("hdn_des_regimen"));
      params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
      params.put("caduana", soporteService.obtenerAduana(request));
      params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

      declaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

      if(MapUtils.esMapaNuloOVacio(declaracion)){
	        MensajeBean rBean = new MensajeBean();
	        rBean.setError(true);
	        rBean.setMensajeerror("La declaracion no ha sido cargada en memoria.");
	        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	        log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : "
	            + rBean.getMensajeerror());
	        res = new ModelAndView("PagM", "beanM", rBean);
      }

      //Se a�ade codigo cuando existe deposito aduanero
//      if(declaracion.get("NUM_DOCIDENT_PDD") != null ){
//    	  Map<String,Object> paramsAnexo = new HashMap<String,Object>();
//    	  paramsAnexo.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
//    	  Map<String,Object> anexo2 = declaracionService.obtenerAnexo2(paramsAnexo);
//    	  declaracion.put("COD_LOCALANEXO2",anexo2.get("COD_LOCALANEXO"));
//    	  declaracion.put("COD_LOCALANEXO2_DESC", anexo2.get("DIRECCION_ANEXO"));
//      }
      String pagRes = "";
      if (Constantes.ESTADO_CONCLU_PROCESO.equals((String) declaracion.get("COD_ESTDUA"))  || Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals((String) declaracion.get("COD_ESTDUA")))
      {
        WebUtils.setSessionAttribute(request, "tipoDiligencia", "05");
        return cargarRegEnProcesoConclusion(request, response);
      }
      else
      {
        pagRes = "IniciarConclusionDespacho";
      }

      res = new ModelAndView(pagRes);

      /**Inicio de cambios por PAS20165E220200032**/
		String invocador="C";
		if(params.get("esPostLevante")!=null && params.get("esPostLevante").toString().equals("1")){
			invocador="L";
		}
		/**Fin de cambios por PAS20165E220200032**/
     // declaracion.put("COD_REGIMEN_DESC", request.getParameter("hdn_des_regimen"));//p14-diligencia de conbclusion de despacho
      declaracion.put("tituloDiligencia", declaracionService.
          obtenerTituloDiligencia((String) declaracion.get("COD_CANAL"), invocador)); //modificado por PAS20165E220200032

      Map<String, Object> declaracionActual = new HashMap<String, Object>();
      declaracionActual.putAll(declaracion);

      WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);


      res.addObject("declaracion", declaracion);
      res.addObject("acceso", Constantes.TIPO_ACCESO_CONCLUSION);
      res.addObject("params", params);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("ConclusionDespachoController validarDeclaParaConclucionDespacho - ERROR : " + e.getMessage());
      res = new ModelAndView("PagM", "beanM", rBean);
    }

    return res;
  }

  //PAS20155E220200101 - Fin

  /**
   * Carga el proceso de conclusi�n de despacho
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @throws Exception
   */
  public ModelAndView cargarRegConclusionDespacho(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {
    ModelAndView res = new ModelAndView("RegDiligenciaDespacho");

    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
    UserNameHolder.set(bUsuario.getNroRegistro());
    try
    {
      Map<String, Object> decla = (HashMap<String, Object>)
          WebUtils.getSessionAttribute(request, "mapCabDeclara");
      Map<String, Object> declaAct = (HashMap<String, Object>)
          WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      WebUtils.setSessionAttribute(request, "tipoDiligencia", "05");

      decla.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_PROCESO);

		//amancilla LGA error debido a que jala el estado 11 sin validar la fecha de vigencia
		//por siaca he copiado el codigo de Anita no me juzguen
      //decla.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_PROCESO));

		Date fechadeclaracion = decla.get("FEC_DECLARACION")!=null && decla.get("FEC_DECLARACION").toString()!=" "?
				SunatDateUtils.getDateFromUnknownFormat(decla.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
		String descripEstado = (catalogoAyudaService.getDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_PROCESO, fechadeclaracion).getDesDatacat().toUpperCase());
		decla.put("COD_ESTDUA_DESC", descripEstado);

		//fin cambi amancilla

      declaAct.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_PROCESO);
      declaAct.put("COD_ESTDUA_DESC", decla.get("COD_ESTDUA_DESC"));


      Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
      paramDeclaracion.put("NUM_CORREDOC", decla.get("NUM_CORREDOC"));
      paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_PROCESO);
      this.declaracionService.updateDeclaracion(paramDeclaracion);

      Map<String, Object> diligencia = new HashMap<String, Object>();
      diligencia.put("IND_INCIDENCIA", "");
      diligencia.put("IND_MULTA", "");
      diligencia.put("DES_RESULTADO", "");
      WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);


		/**Inicio de cambios por PAS20165E220200032**/
		String invocador="C";
		if(request.getParameter("hdn_Post_Levante")!=null && request.getParameter("hdn_Post_Levante").toString().equals("1")){
			invocador="L";
		}
		/**Fin de cambios por PAS20165E220200032**/

      decla.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia((String) decla.get("COD_CANAL"), invocador));//modificado por PAS20165E220200032

      WebUtils.setSessionAttribute(request, "mapCabDeclara", decla);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaAct);

      res.addObject("declaracion", decla);
      res.addObject("diligencia", null);
      res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
      res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
      res.addObject("modulo", "C");

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error(this.toString().concat(" cargarRegConclusionDespacho - ERROR : ").concat(e.getMessage()));
      res = new ModelAndView("PagM", "beanM", rBean);
    }
    return res;

  }

  @SuppressWarnings("unchecked")
  public ModelAndView enviaNotificacion(HttpServletRequest request, HttpServletResponse response)
  	      throws Exception
  	  {
	      request.setCharacterEncoding("ISO-8859-1");
          ModelAndView res = new ModelAndView(this.jsonView);

  	    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
  	    UserNameHolder.set(bUsuario.getNroRegistro());

  	    try
  	    {
  	      Map<String, Object> decla = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
  	      //graba el texto

  	      Map<String, Object> params = new HashMap<String, Object>();
  	      FechaBean fecActual = new FechaBean();
  	      String descComunicacion = SunatStringUtils.convertirCaracteresEspecialesAHtml(request.getParameter("txtEnvio"));
  	      params.put("num_corredoc",  decla.get("NUM_CORREDOC"));
  	      params.put("des_nota",descComunicacion);
  	      params.put("cod_nota",  "e");
  	      params.put("cod_usuregis", bUsuario.getNroRegistro());
  	      params.put("fec_regis", fecActual.getTimestamp());
  	      params.put("cod_tipdiligencia", "04");

  	      // inserta la comunicacion con el portal
  	      diligenciaService.grabarComunicacion(params);
            //envia Notificacion a la bandeja sol del importador y despachador

  	        Map mapCabDeclaraActual = (Map) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
  	        String codAduana = mapCabDeclaraActual.get("COD_ADUANA").toString();
  	        String annPresen = mapCabDeclaraActual.get("ANN_PRESEN").toString();
  	        String codRegimen = mapCabDeclaraActual.get("COD_REGIMEN").toString();
  	        String numDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION").toString();
  	        String codCanal = mapCabDeclaraActual.get("COD_CANAL").toString();

  	          diligenciaService.notificarObservacion(
  	                                                 descComunicacion,
  	                                                 codAduana,
  	                                                 annPresen,
  	                                                 codRegimen,
  	                                                 numDeclaracion,
  	                                                 SunatStringUtils.convertirCaracteresEspecialesAHtml(bUsuario.getNombreCompleto()),
  	                                                 new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString() },
  	                                                 Constantes.COD_PL_NOTI_DILIG_CONCLUSION,
  	                                                 Constantes.CODIGO_NOTIFICACION,
  	                                                 Constantes.CONTRIBUYENTE,
  	                                                 "PIM");

  	          diligenciaService.notificarObservacion(
  	                                                 descComunicacion,
  	                                                 codAduana,
  	                                                 annPresen,
  	                                                 codRegimen,
  	                                                 numDeclaracion,
  	                                                 SunatStringUtils.convertirCaracteresEspecialesAHtml(bUsuario.getNombreCompleto()),
  	                                                 new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString() },
  	                                                 Constantes.COD_PL_NOTI_DILIG_CONCLUSION,
  	                                                 Constantes.CODIGO_NOTIFICACION,
  	                                                 Constantes.CONTRIBUYENTE,
  	                                                 "PDE");


  	        // ACTUALIZAR ESTADO DE LA DUA A 16, DURANTE LA NOTIFICACION DE
  	      Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
  	      paramDeclaracion.put("NUM_CORREDOC", decla.get("NUM_CORREDOC"));
  	      paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_NOTIFICADO);
  	      this.declaracionService.updateDeclaracion(paramDeclaracion);
  	      res.addObject("resOk", true);


  	    }
  	    catch (Exception e)
  	    {
  	      MensajeBean rBean = new MensajeBean();
  	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
  	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
  	      log.error(this.toString().concat(" cargarRegConclusionDespacho - ERROR : ").concat(e.getMessage()));
  	      res = new ModelAndView("PagM", "beanM", rBean);
  	    }

  	    return res;

  	  }

  /**
   * Valida informacion ingresada para solicitud de prorroga de conclusion
   * @author hsaenz
   * @param request
   * @param response
   * @return
   */
  // hsaenz: 10/09/2014
  @SuppressWarnings("unchecked")
  public ModelAndView validaPreviaSolProrrogaConclusion(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  Date fechaDeclaracion;
	  Date fechaVencimientoConclusion;
	  Date fechaVencimientoConclusion12;
	  int numcorredoc;
	  Map<String, Object> mapDeclaracion;
	  Map<String, Object> objRes = new HashMap<String,Object>();
	  Map <String, Object> param;
	  Map <String, Object> parametros = new HashMap<String, Object>();
	  MensajeBean rBean = null;
	  String objName = "beanM";
	  UsuarioBean userSession;

	  if(log.isDebugEnabled())
			log.debug("Inicio: validaPreviaSolProrrogaConclusion");

	  //Verifica que se tenga sesion con informacion del usuario
	  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  if (userSession == null) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Usuario no logueado");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  } else {
		  UserNameHolder.set(userSession.getNroRegistro());
	  }
	  ///////////////////
	  //Empiezan validaciones con obtenci�n de informaci�n
	  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      //rBean.setMensajeerror(StringEscapeUtils.escapeHtml("No se ha encontrado declaraci�n en sesi�n"));
	      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  }


	  /**Inicio de cambios de PAS20165E220200032**/
	  Boolean ingresoPorPostLevante = request.getParameter("hdn_Post_Levante")!=null && "1".equals(request.getParameter("hdn_Post_Levante").toString())?true:false;
	  String nombreDiligencia="conclusi\u00f3n de despacho";
	  if(ingresoPorPostLevante){
		  nombreDiligencia="Post Levante";
	  }
	  /**Fin de cambios de PAS20165E220200032**/

	  numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
	  //Verifica que el estado de la declaracion sea 10=Asignado a conclusion, 11=en revision conclusion, o 16=notificado en conclusion
	  if (!mapDeclaracion.get("COD_ESTDUA").equals("10")
			  && !mapDeclaracion.get("COD_ESTDUA").equals("11")
			  && !mapDeclaracion.get("COD_ESTDUA").equals("16")) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Declaraci\u00f3n "
	    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
	    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
	    		  + ", no se encuentra en estados 10, 11, o 16");
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }
	  //Valida que no existan dos solicitudes de prorroga aprobadas
	  param = new HashMap<String, Object>();
	  param.put("NUM_CORREDOC", numcorredoc);
	  param.put("CNT_PLZOTORGADO", 0);

	  int numeroSoliProrrogaAprob = ((BigDecimal) ((SoliProrrogaDAO) fabricaDeServicios.getService("despaduanero2.soliProrrogaDAO")).findContarSolicitudesProrrogaConclusion(param).get("CANT")).intValue();
	  if (numeroSoliProrrogaAprob >= 2) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Declaraci\u00f3n "
	    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
	    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
	    		  + ", tiene dos (2) solicitudes de pr\u00f3rroga de "+nombreDiligencia+" aprobadas. No puede ser prorrogada nuevamente");//modificado por PAS20165E220200032
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }

	  //Valida que no hayan solicitudes de prorroga pendientes de aprobar o rechazar
	  param.clear();
	  param.put("NUM_CORREDOC", numcorredoc);
	  int numeroSoliProrroga = ((BigDecimal) ((SolicitudService) fabricaDeServicios.getService("despaduanero2.solicitudService")).buscarSoliProrrogaConclusion(param).get("CANT")).intValue();
	  if (numeroSoliProrroga > 0) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Declaraci\u00f3n "
	    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
	    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
	    		  + ", tiene solicitud de pr\u00f3rroga de "+nombreDiligencia+" en bandeja pendiente del jefe. No se puede ingresar nueva solicitud");//modificado por PAS20165E220200032
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }

	  //Valida que la fecha de vencimiento de la conclusion, no corresponda al plazo maximo permitido
	  fechaDeclaracion = (Date) mapDeclaracion.get("FEC_DECLARACION");
	  fechaVencimientoConclusion = (Date) mapDeclaracion.get("FEC_VENCONCLU");
	  parametros = (Map<String, Object>) ((ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice")).obtFechaConclusionDespacho(parametros, fechaDeclaracion, 12);
	  if(parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
		  //
		  fechaVencimientoConclusion12 = (Date) parametros.get("fechaConclusionDespa");
		  //
		  if (fechaVencimientoConclusion.equals(fechaVencimientoConclusion12)
				  || fechaVencimientoConclusion.after(fechaVencimientoConclusion12)) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Declaraci\u00f3n "
		    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
		    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
		    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
		    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
		    		  + ", no puede prorrogarse m\u00e1s all\u00e1 del plazo m\u00e1ximo de "+nombreDiligencia+" "+ SunatDateUtils.getFormatDate(fechaVencimientoConclusion12, "dd/MM/yyyy"));//modificado por PAS20165E220200032
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
	  }

	  if(log.isDebugEnabled())
			log.debug("Fin: validaPreviaSolProrrogaConclusion");
	  //Retorna en caso de que no hayan errores
	  ModelAndView view = new ModelAndView(this.jsonView, objName, objRes);
	  return view;
  }

  /**
   * Carga informacion que se mostrara en formulario para solicitud de prorroga de conclusion
   * @author hsaenz
   * @param request
   * @param response
   * @return
   */
  // hsaenz: 10/09/2014
  @SuppressWarnings("unchecked")
  public ModelAndView cargarSolProrrogaConclusion(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  List<Map<String, Object>> lista;
	  Date fecha;
	  FechaBean fechaBean = new FechaBean();
	  String fechaSB = fechaBean.getFormatDate("dd/MM/yyyy");
	  Map<String, Object> mapDeclaracion;
	  Map<String, Object> mapProrrogaConclusion = new HashMap<String, Object>();
	  Map<String, Object> params = new HashMap<String, Object>();
	  MensajeBean rBean = null;
	  UsuarioBean userSession;
	  //
	  if(log.isDebugEnabled())
			log.debug("Inicio: cargarSolProrrogaConclusion");
	  //
	  //Verifica que se tenga sesion con informacion del usuario
	  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  if (userSession == null) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Usuario no logueado");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  } else {
		  UserNameHolder.set(userSession.getNroRegistro());
	  }
	  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  }

	  params.put("type", "AyudaJSON");
	  params.put("catalogoID", "357");
	  params.put("codTipoDes", "");
	  params.put("fechaVigencia", SunatDateUtils.getCurrentDate());
	  params.put("codEstado", "01");
	  //amancilla lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogoImpl) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(params);
	  lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogo) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(params);
	  //
	  /***Inicio de cambios por PAS20165E220200032***/
	  Boolean ingresoPorPostLevante = request.getParameter("hdn_Post_Levante")!=null && "1".equals(request.getParameter("hdn_Post_Levante").toString())?true:false;//adicionado por PAS20165E220200032

	  if(ingresoPorPostLevante){
	  List<Map<String, String>> listaMotPostLevante = catalogoAyudaService.getListaElementosGrupo("714");
	  List<Map<String, Object>> listMotivosPostLevante = new ArrayList<Map<String, Object>>();
	  	for (Map<String, Object> itemMotivo :  lista){

		  for (Map<String, String> motPostLevante : listaMotPostLevante){
			    if(itemMotivo.get("cod_datacat").toString().equals(motPostLevante.get("cod_datacat"))) {
			    	listMotivosPostLevante.add(itemMotivo);
			    }
		  }
	  	}
	  	lista=new ArrayList<Map<String, Object>>();
	  	lista.addAll(listMotivosPostLevante);
	  }
	  /***Fin de cambios PAS20165E220200032***/
	  ModelAndView view = new ModelAndView("SolicitudProrrogaConclusion");
	  view.addObject("cod_aduana", mapDeclaracion.get("COD_ADUANA"));
	  view.addObject("ann_presen", mapDeclaracion.get("ANN_PRESEN").toString());
	  view.addObject("num_declaracion", mapDeclaracion.get("NUM_DECLARACION").toString());
	  view.addObject("num_corredoc", mapDeclaracion.get("NUM_CORREDOC").toString());
	  view.addObject("cod_regimen", mapDeclaracion.get("COD_REGIMEN"));
	  view.addObject("des_regimen", mapDeclaracion.get("COD_REGIMEN_DESC"));
	  fecha = (Date) mapDeclaracion.get("FEC_DECLARACION");
	  view.addObject("fec_declaracion", SunatDateUtils.getFormatDate(fecha, "dd/MM/yyyy"));
	  fecha = (Date) mapDeclaracion.get("FEC_VENCONCLU");
	  view.addObject("fec_venconclu", SunatDateUtils.getFormatDate(fecha, "dd/MM/yyyy"));
	  view.addObject("listaMotivoSolicitud", lista);
	  //
	  mapProrrogaConclusion.put("txt_codUsuario", "");
	  mapProrrogaConclusion.put("txt_numCorredoc", "");
	  mapProrrogaConclusion.put("txt_fecProrroga", fechaSB);
	  mapProrrogaConclusion.put("sel_cod_motivoSolicitud_new", "");
	  mapProrrogaConclusion.put("txt_sustentoProrroga", "");
	  mapProrrogaConclusion.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032
	  view.addObject("prorrogaConclusion", mapProrrogaConclusion);
	  view.addObject("hdn_es_aprobacion", "0");
	  //
	  if(log.isDebugEnabled())
			log.debug("Fin: cargarSolProrrogaConclusion");
	  //
	  return view;
  }

  /**
   * Valida la informacion ingresada en solicitud de prorroga de conclusion
   * @author hsaenz
   * @param request
   * @param response
   * @return
   */
  // hsaenz: 10/09/2014
  @SuppressWarnings("unchecked")
  public ModelAndView validaSolProrrogaConclusion(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  request.setCharacterEncoding("ISO-8859-1");
	  Date fechaDeclaracion;
	  Date fechaVencimientoConclusion;
	  Date fechaVencimientoConclusion12 = new Date();
	  Date fechaSolicitudProrroga;
	  Date fechaVencRegimen;
	  //Date fechaVctoConclu;
	  int numcorredoc;
	  Map<String, Object> mapDeclaracion;
	  Map<String, Object> objRes = new HashMap<String,Object>();
	  Map <String, Object> param;
	  Map <String, Object> parametros = new HashMap<String, Object>();
	  MensajeBean rBean = null;
	  ServletWebRequest webRequest = new ServletWebRequest(request);
	  String objName = "beanM";
	  UsuarioBean userSession;

	  if(log.isDebugEnabled())
			log.debug("Inicio: validaSolProrrogaConclusion");

	  //Verifica que se tenga sesion con informacion del usuario
	  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  if (userSession == null) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error: Usuario no logueado");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  } else {
		  UserNameHolder.set(userSession.getNroRegistro());
	  }
	  ///////////////////
	  //Empiezan validaciones con obtenciÃ³n de informaciÃ³n
	  /**Inicio de cambios por PAS20165E220200032**/
	  String nombreDiligencia="conclusi\u00f3n de Despacho";
	  if (webRequest.getParameter("hdn_Post_Levante") != null && webRequest.getParameter("hdn_Post_Levante").toString().equals("1")) {
		  nombreDiligencia="Diligencia Post Levante";
	  }
	  /**Fin de cambios por PAS20165E220200032**/

	  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
	      log.error(rBean.getMensajeerror());
	      //
		  return new ModelAndView(this.jsonView, "error", rBean);
	  }

	  numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
	  //Verifica que el estado de la declaracion sea 10=Asignado a conclusion, 11=en revision conclusion, o 16=notificado en conclusion
	  if (!mapDeclaracion.get("COD_ESTDUA").equals("10")
			  && !mapDeclaracion.get("COD_ESTDUA").equals("11")
			  && !mapDeclaracion.get("COD_ESTDUA").equals("16")) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error: Declaraci\u00f3n "
	    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
	    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
	    		  + ", no se encuentra en estados 10, 11, o 16");
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }
	  //Valida que no existan dos solicitudes de prorroga aprobadas
	  param = new HashMap<String, Object>();
	  param.put("NUM_CORREDOC", numcorredoc);
	  param.put("CNT_PLZOTORGADO", 0);

	  int numeroSoliProrroga = ((BigDecimal) ((SoliProrrogaDAO) fabricaDeServicios.getService("despaduanero2.soliProrrogaDAO")).findContarSolicitudesProrrogaConclusion(param).get("CANT")).intValue();
	  if (numeroSoliProrroga >= 2) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error: Declaraci\u00f3n "
	    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
	    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
	    		  + ", tiene dos (2) solicitudes de pr\u00f3rroga de "+nombreDiligencia+" aprobadas. No puede ser prorrogada nuevamente");//actualizado por PAS20165E220200032
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }

	  //Valida que la fecha de vencimiento de la conclusion, no corresponda al plazo maximo permitido
	  fechaDeclaracion = (Date) mapDeclaracion.get("FEC_DECLARACION");
	  //fechaVctoConclu = (Date) mapDeclaracion.get("FEC_VENCONCLU");
	  fechaVencimientoConclusion = (Date) mapDeclaracion.get("FEC_VENCONCLU");
	  parametros = (Map<String, Object>) ((ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice")).obtFechaConclusionDespacho(parametros, fechaDeclaracion, 12);
	  if(parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
		  //
		  fechaVencimientoConclusion12 = (Date) parametros.get("fechaConclusionDespa");
		  //
		  if (fechaVencimientoConclusion.equals(fechaVencimientoConclusion12)
				  || fechaVencimientoConclusion.after(fechaVencimientoConclusion12)) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: Declaraci\u00f3n "
		    		  + mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
		    		  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
		    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
		    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim() + " "
		    		  + ", no puede prorrogarse m\u00e1s all\u00e1 del plazo m\u00e1ximo de "+nombreDiligencia+ SunatDateUtils.getFormatDate(fechaVencimientoConclusion12, "dd/MM/yyyy"));
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
	  } else {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error interno de la aplicaci\u00f3n");
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }
	  //------------------------------
	  //Validaciones antes de guardar
	  //-------------------------------
	  if (webRequest.getParameter("fec_prorroga") == null || webRequest.getParameter("fec_prorroga").toString().isEmpty()) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error: No se ha ingresado la fecha de pr\u00f3rroga");
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  } else {
		  fechaSolicitudProrroga = FechaBean.getDate(webRequest.getParameter("fec_prorroga").toString(), "dd/MM/yyyy");
		  //Verifica que la fecha de prorroga tome el siguiente dia habil en caso de ser feriado
		  parametros.clear();
		  parametros = (Map<String, Object>) ((ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice")).obtFechaConclusionDespacho(parametros, fechaSolicitudProrroga, 0);
		  if(parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
			  fechaSolicitudProrroga = (Date) parametros.get("fechaConclusionDespa");
		  }
		  //
		  if (fechaSolicitudProrroga.after(fechaVencimientoConclusion12)) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la "+nombreDiligencia+" consignada excede el plazo de los 12 meses de numerada la declaraci\u00f3n");//modificado por PAS20165E220200032
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
		  //
		  if (fechaSolicitudProrroga.before(fechaVencimientoConclusion)
				  || fechaSolicitudProrroga.equals(fechaVencimientoConclusion)) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la "+nombreDiligencia+" registrada debe ser mayor a la fecha actual de vencimiento de la conclusi\u00f3n de la declaraci\u00f3n");//modificado por PAS20165E220200032
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
		  //
		  if (mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("20")
				  || mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("21")
				  || mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("70")) {
			  //
			  if (!mapDeclaracion.get("FEC_VENREGIMEN").toString().equals("01/01/0001")) {
				  fechaVencRegimen = FechaBean.getDate(mapDeclaracion.get("FEC_VENREGIMEN").toString(), "dd/MM/yyyy");
				  if (fechaVencRegimen.before(fechaSolicitudProrroga) ) {
					  rBean = new MensajeBean();
				      rBean.setError(true);
				      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la "+nombreDiligencia+" consignada excede la fecha de vencimiento del r\u00e9gimen");//modificado por PAS20165E220200032
				      log.error(rBean.getMensajeerror());
				      //
				      return new ModelAndView(this.jsonView, "error", rBean);
				  }
			  } else {
				  rBean = new MensajeBean();
			      rBean.setError(true);
			      rBean.setMensajeerror("Error: Fecha de vencimiento de r\u00e9gimen es igual a: " + mapDeclaracion.get("FEC_VENREGIMEN").toString());
			      log.error(rBean.getMensajeerror());
			      //
			      return new ModelAndView(this.jsonView, "error", rBean);
			  }
		  }
	  }

	  //
	  if (webRequest.getParameter("cod_motivosolicitud") == null || webRequest.getParameter("cod_motivosolicitud").toString().isEmpty()) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Error: No se ha ingresado el motivo de la solicitud de pr\u00f3rroga");
	      log.error(rBean.getMensajeerror());
	      //
	      return new ModelAndView(this.jsonView, "error", rBean);
	  }
	  //*********************************************
	  //Si todo es correcto y se ha enviado el paramero para guardar datos, procede a guardar la informacion
	  //*********************************************
	  if (webRequest.getParameter("guardaDatos") != null && !webRequest.getParameter("cod_motivosolicitud").toString().isEmpty()) {
		  Map<String, Object> mapDatosIngresados = new HashMap<String,Object>();
		  if (webRequest.getParameter("guardaDatos").toString().equals("1")) {
			  mapDatosIngresados.put("fec_prorroga", SunatDateUtils.getFormatDate(fechaSolicitudProrroga, "dd/MM/yyyy"));
			  mapDatosIngresados.put("cod_motivosolicitud", webRequest.getParameter("cod_motivosolicitud"));
			  mapDatosIngresados.put("sustento_prorroga", webRequest.getParameter("sustento_prorroga"));
			  mapDatosIngresados.put("hdn_Post_Levante", webRequest.getParameter("hdn_Post_Levante")!=null?webRequest.getParameter("hdn_Post_Levante").toString():" ");//adicionado por PAS20165E220200032
			  //
			  return guardaSolProrrogaConclusion(mapDeclaracion, mapDatosIngresados);
		  }
	  }
	  //
	  if(log.isDebugEnabled())
			log.debug("Fin: validaSolProrrogaConclusion");
	  //Retorna en caso de que no hayan errores
	  ModelAndView view = new ModelAndView(this.jsonView, objName, objRes);
	  return view;
  }

  /**
   * Guarda solicitud de prorroga de conclusion
   * @author hsaenz
   * @param request
   * @param response
   * @return
   */
  // hsaenz: 10/09/2014:
  @SuppressWarnings("unchecked")
  private ModelAndView guardaSolProrrogaConclusion(Map<String, Object> mapDeclaracion, Map<String, Object> mapDatosIngresados) throws Exception {
	  boolean guardoInformacion = false;
	  List <Map<String, Object>> listCodigosJefes;
	  List <Map<String, Object>> lista;
	  Map <String, Object> mapRoles = new HashMap <String, Object>();
	  Map <String, Object> param;
	  MensajeBean rBean = null;
	  String objName;
	  String objRes;

	  if(log.isDebugEnabled())
			log.debug("Inicio: guardaSolProrrogaConclusion - o postLevante");

	  /**Inicio de cambios por PAS20165E220200032**/
	  Boolean ingresoPostLevante = mapDatosIngresados.get("hdn_Post_Levante")!=null && mapDatosIngresados.get("hdn_Post_Levante").toString().equals("1")?true:false;
	  String nombreDiligencia="ConclusionDespacho";
	  if(ingresoPostLevante){
		  nombreDiligencia="PostLevante";
	  }
	  /**Fin de cambios por PAS20165E220200032**/

	  ///////////////////
	  //Empieza proceso de guardar datos
	  ///////////////////
	  ModelAndView view;
	  try {
		  // crear un numero de solicitud, con el tipo 92 (prorroga de conclusion) y para la aduana especificada
		  Long nroSolicitud = ((SecuenciaDeclaracionService) fabricaDeServicios.getService("secuenciaPerdidaService")).obtenerCorrelativo(SunatStringUtils.toStringObj(mapDeclaracion.get("COD_ADUANA")), "92");
		  //para roles
		  	/*mapRoles.put("Z01", "CONCLUSION.IMPO");
			mapRoles.put("Z02", "CONCLUSION.ADM.REEXPO");
			mapRoles.put("Z03", "CONCLUSION.ADM.PERF");
			mapRoles.put("Z04", "CONCLUSION.DEPO");
			mapRoles.put("Z05", "JEFE.CONCLUSION");
			mapRoles.put("Z06", "CONCLUSION.COMPLENTARIO");*/
		  param = new HashMap<String, Object>();
		  param.put("type", "AyudaJSON");
		  param.put("catalogoID", "516");
		  param.put("codTipoDes", "");
		  param.put("fechaVigencia", SunatDateUtils.getCurrentDate());
		  param.put("codEstado", "01");
		  //amancilla lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogoImpl) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(param);
		  lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogo) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(param);

		  for (Map <String, Object> mapaRol:lista) {
			  mapRoles.put(mapaRol.get("cod_datacat").toString(), mapaRol.get("des_datacat").toString());
		  }
			//Obtener los codigos de los jefes asociados a los roles.
			String [] arrayRoles = mapRoles.values().toArray(new String[0]);

			if(log.isDebugEnabled())log.debug("procesar"+nombreDiligencia+" - arrayRoles:" + arrayRoles + "*******");//cambios PAS20165E220200032

			String declaracion = mapDeclaracion.get("COD_ADUANA").toString() + "-" + mapDeclaracion.get("ANN_PRESEN").toString()
					+ "-" + mapDeclaracion.get("COD_REGIMEN").toString() + "-" + mapDeclaracion.get("NUM_DECLARACION").toString();
			param = new HashMap<String, Object>();
			param.put("cod_aduana", mapDeclaracion.get("COD_ADUANA"));
			param.put("declaracion", declaracion);
			listCodigosJefes = ((ConsultaService) fabricaDeServicios.getService("diligencia.ingreso.consultaService")).obtenerJefesGrupo(param, arrayRoles);
			//
			String codigoJefe = "";

			if (listCodigosJefes != null && !listCodigosJefes.isEmpty()) {
				for(Map<String, Object> mapCodigoJefe :listCodigosJefes) {
					if(mapCodigoJefe.get("cod_pers") == null) {
						break;
					}
					if(!codigoJefe.contains(mapCodigoJefe.get("cod_pers").toString())) {
						codigoJefe += mapCodigoJefe.get("cod_pers").toString() + ",";
					}
				}

				if(log.isDebugEnabled())log.debug("procesar"+nombreDiligencia+" - DECLARACION: " +
						declaracion+ ", CODIGO DE JEFE:" + codigoJefe + "*******");//cambios PAS20165E220200032
				//
				guardoInformacion = ((SolicitudService) fabricaDeServicios.getService("despaduanero2.solicitudService")).guardarSolicitudProrroga(mapDeclaracion, mapDatosIngresados, nroSolicitud, codigoJefe);
			} else {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror("No se ha encontrado lista de jefes o es nula. DECLARACION: " + declaracion + ", ADUANA: " + mapDeclaracion.get("COD_ADUANA") + ",  ROLES: " + Arrays.toString(arrayRoles));
				rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

				log.error("guardaSolProrrogaConclusion ("+nombreDiligencia+") - No se ha encontrado lista de jefes o es nula. DECLARACION: "
				+ declaracion + ", ADUANA: " + mapDeclaracion.get("COD_ADUANA") + ",  ROLES: " + arrayRoles);//modificado por PAS20165E220200032
				objName = "error";
				view = new ModelAndView(this.jsonView, objName, rBean);
				return view;
			}
	  } catch(Exception e) {
		  rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror("Ha ocurrido un error interno en la aplicaci\u00f3n. El error es: " + e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("guardaSolProrrogaConclusion ("+nombreDiligencia+") - ERROR : El error es: " + e.getMessage(), e);//modificado por PAS20165E220200032
	      objName = "error";
	      view = new ModelAndView(this.jsonView, objName, rBean);
	      return view;
	  }

	  //Retorna en caso de que no hayan errores
	  if (guardoInformacion == true) {
		  objRes = "Se guardo la informaci\u00f3n ingresada";
		  objName = "beanM";
		  view = new ModelAndView(this.jsonView, objName, objRes);
	  } else {
		  rBean = new MensajeBean();
		  rBean.setError(true);
		  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n");
		  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
		  log.error(rBean.getMensajeerror());
		  objName = "error";
		  view = new ModelAndView(this.jsonView, objName, rBean);
	  }

	  if(log.isDebugEnabled())
			log.debug("Fin: guardaSolProrrogaConclusion ("+nombreDiligencia+")");//modificado por PAS20165E220200032

	  return view;
  }

	/**
	 * Carga la busqueda de la declaracion para la prorroga de conclusion
	 * @author hsaenz
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ModelAndView
	 * @throws Exception
	 */
  	// hsaenz: 10/09/2014
	public ModelAndView cargarBusqDeclaracionProrroga(HttpServletRequest request, HttpServletResponse response) throws Exception{
	  ModelAndView res = new ModelAndView("BusqDeclaracionConclProrroga");
	  UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  if (userSession == null) {
	    return new ModelAndView("PagM", "message", "Usuario no logueado");
	  }

	  try {
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    String codAduana = WUtil.getParam(webRequest, "codAduana", soporteService.obtenerAduana(request));
	    String annPresen = WUtil.getParam(webRequest, "annPresen",
	        String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
	    String codRegimen = WUtil.getParam(webRequest, "codRegimen");
	    String numDeclaracion = WUtil.getParam(webRequest, "numDeclaracion");
	    //System.out.println(codAduana + ", " + annPresen + ", " + codRegimen + ", " + numDeclaracion);
		  String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
	    Map<String, String> params = new HashMap<String, String>();

	    params.put("cod_aduana", codAduana);
	    params.put("ann_presen", annPresen);
	    params.put("cod_regimen", codRegimen);
	    params.put("num_declaracion", numDeclaracion);
	    params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	    params.put("numPase", Constantes.NUM_PASE);
	    params.put("cAduana", soporteService.obtenerAduana(request));

	    WebUtils.setSessionAttribute(request, "mapCabDeclara", null);
	    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", null);
	    WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
	    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
	    WebUtils.setSessionAttribute(request, "lstIncidencias", null);
	    WebUtils.setSessionAttribute(request, "lstDocuPreceDua", null);
	    WebUtils.setSessionAttribute(request, "lstDocuPreceDuaActual", null);
	    WebUtils.setSessionAttribute(request, "lstFacturasSerie", null);
	    WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", null);

	    List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

	    res.addObject("params", params);

	  } catch (Exception e) {
	    MensajeBean rBean = new MensajeBean();
	    rBean.setError(true);
	    rBean.setMensajeerror("Ha ocurrido un error en la aplicaci\u00f3n. El error es: " + e.getMessage());
	    rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	    log.error("cargarBusqDeclaracionProrroga - Error: El error es: " + e.getMessage(), e);
	    res = new ModelAndView("PagM", "beanM", rBean);
	  }

	  return res;
	}


	/**
	 * Creado para PAS20165E220200032
	 */
	public ModelAndView cargarBusqDeclaracionProrrogaPostL(HttpServletRequest request, HttpServletResponse response) throws Exception{
	  ModelAndView res = new ModelAndView("BusqDeclaracionConclProrroga");
	  UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  if (userSession == null) {
	    return new ModelAndView("PagM", "message", "Usuario no logueado");
	  }

	  try {
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    String codAduana = WUtil.getParam(webRequest, "codAduana", soporteService.obtenerAduana(request));
	    String annPresen = WUtil.getParam(webRequest, "annPresen",
	        String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
	    String codRegimen = WUtil.getParam(webRequest, "codRegimen");
	    String numDeclaracion = WUtil.getParam(webRequest, "numDeclaracion");
		//String numDecla = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
	    Map<String, String> params = new HashMap<String, String>();

	    params.put("cod_aduana", codAduana);
	    params.put("ann_presen", annPresen);
	    params.put("cod_regimen", codRegimen);
	    params.put("num_declaracion", numDeclaracion);
	    params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	    params.put("numPase", Constantes.NUM_PASE);
	    params.put("cAduana", soporteService.obtenerAduana(request));
        params.put("esPostLevante","1");//para cambiar las etiquetas

	    WebUtils.setSessionAttribute(request, "mapCabDeclara", null);
	    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", null);
	    WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
	    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
	    WebUtils.setSessionAttribute(request, "lstIncidencias", null);
	    WebUtils.setSessionAttribute(request, "lstDocuPreceDua", null);
	    WebUtils.setSessionAttribute(request, "lstDocuPreceDuaActual", null);
	    WebUtils.setSessionAttribute(request, "lstFacturasSerie", null);
	    WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", null);

		  List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		  params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));

		  //ModelAndView res = new ModelAndView("BusqDeclaracionConclProrroga", "params", params);



	    res.addObject("params", params);

	  } catch (Exception e) {
	    MensajeBean rBean = new MensajeBean();
	    rBean.setError(true);
	    rBean.setMensajeerror("Ha ocurrido un error en la aplicaci\u00f3n. El error es: " + e.getMessage());
	    rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	    log.error("cargarBusqDeclaracionProrroga - Error: El error es: " + e.getMessage(), e);
	    res = new ModelAndView("PagM", "beanM", rBean);
	  }

	  return res;
	}
	  /**
	   * Valida informacion ingresada para solicitud de prorroga de conclusion
	   * @author hsaenz
	   * @param request
	   * @param response
	   * @return
	   */
	  // hsaenz: 10/09/2014
	  @SuppressWarnings("unchecked")
	  public ModelAndView validaPreviaAprobacionProrrogaConcl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		  List <SoliProrroga> listaSoliProrroga;
		  Map<String, Object> mapDeclaracion;
		  boolean objRes = false;
		  Map<String, Object> params = new HashMap<String, Object>();
		  Map mapRoles = new HashMap();
		  MensajeBean rBean = null;
		  String objName = "BeanM";
		  UsuarioBean userSession;

		  if(log.isDebugEnabled())
				log.debug("Inicio: validaPreviaAprobacionProrrogaConcl");

		  //Verifica que se tenga sesion con informacion del usuario
		  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  if (userSession == null) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Usuario no logueado");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "beanM", rBean);
		  } else {
			  UserNameHolder.set(userSession.getNroRegistro());
		  }
		  ///////////////////
		  //Empiezan validaciones con obtenci�n de informaci�n
		  boolean rolValido = false;

		  params = new HashMap<String, Object>();
	      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
	      params.put("codigoFuncionario", bUsuario.getNroRegistro());
	      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
	      params.put("ann_presen", request.getParameter("txt_ann_presen"));
	      params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
	      params.put("des_regimen", request.getParameter("hdn_des_regimen"));
	      params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
	      params.put("caduana", soporteService.obtenerAduana(request));
	      params.put("esProrrogaConclusion", "1");
	      params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032
	      Boolean ingresoPorPostLevante =request.getParameter("hdn_Post_Levante")!=null && (request.getParameter("hdn_Post_Levante").toString()).equals("1")?true:false;//adicionado por PAS20165E220200032

	      Map<String, Object> declaracion = declaracionService.validarDeclaSoliProrrogaConclDespacho(params);

	      if(MapUtils.esValorMapaNuloOVacio(declaracion, "error")){
	    	  WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
	      } else {
	    	  rBean = new MensajeBean();
	          rBean.setError(true);
	          rBean.setMensajeerror((String) declaracion.get("error"));
	          rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	          log.error("ConclusionDespachoController: validaPreviaAprobacionProrrogaConcl - ERROR : "
	              + rBean.getMensajeerror());
	          return new ModelAndView(this.jsonView, "beanM", rBean);
	      }

	      mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
		  //numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
		  String declaracionCadena = mapDeclaracion.get("COD_ADUANA").toString().trim() + "-"
				  + mapDeclaracion.get("ANN_PRESEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("COD_REGIMEN").toString().trim() + "-"
	    		  + mapDeclaracion.get("NUM_DECLARACION").toString().trim();

		  //Verifica que el usuario pertenezca al rol que pueda atender la declaracion
		  mapRoles = (Map) userSession.getMap().get("roles");
		  rolValido = ((AsignacionService) fabricaDeServicios.getService("Asignacion.asignacionService")).validaUsuarioRolProrrogaConclusion(mapDeclaracion, mapRoles.values().toArray());
		  //comentarlo
		  //rolValido = true;

		  if (!rolValido) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Rol " + mapRoles.values().toString() + " no permite atender declaraci\u00f3n "
		    		  + declaracionCadena);
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "beanM", rBean);
		  }

		  //

		  params.clear();
		  params = new HashMap<String,Object>();
		  params.put("NUM_CORREDOC", mapDeclaracion.get("NUM_CORREDOC").toString());
		  listaSoliProrroga = (ArrayList<SoliProrroga>) ((SoliProrrogaDAO) fabricaDeServicios.getService("despaduanero2.soliProrrogaDAO")).findSolicitudesProrrogaConclusion(params);
		  if (listaSoliProrroga.isEmpty()) {
			  WebUtils.setSessionAttribute(request, "lstSoliprorroga", null);
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      String nomb_diligencia="conclusi\u00f3n";
		      if(ingresoPorPostLevante){//PAS20165E220200032
		    	  nomb_diligencia="Post Levante";
		      }
		      rBean.setMensajeerror("No existe solicitud de pr\u00f3rroga de "+nomb_diligencia+" pendiente de evaluar para la declaraci\u00f3n: "
		    		  + declaracionCadena);
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "beanM", rBean);
		  } else {
			  WebUtils.setSessionAttribute(request, "lstSoliprorroga", listaSoliProrroga);
			  objName = "resOk";
			  objRes = true;
		  }

		  if(log.isDebugEnabled())
				log.debug("Fin: validaPreviaAprobacionProrrogaConcl");
		  //Retorna en caso de que no hayan errores
		  ModelAndView view = new ModelAndView(this.jsonView, objName, objRes);
		  return view;
	  }

	  /**
	   * Carga informacion que se mostrara en formulario para aprobacion de prorroga de conclusion
	   * @author hsaenz
	   * @param request
	   * @param response
	   * @return
	   */
	  // hsaenz: 10/09/2014
	  @SuppressWarnings("unchecked")
	  public ModelAndView cargarAprobacionProrrogaConcl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		  Date fecha;
		  FechaBean fechaBean = new FechaBean();
		  String fechaSB = fechaBean.getFormatDate("dd/MM/yyyy");
		  List <SoliProrroga> listaSoliProrroga;
		  List<Map<String, Object>> lista;
		  List<Map<String, Object>> listRRHH;
		  Map<String, Object> mapDeclaracion;
		  Map<String, Object> mapProrrogaConclusion = new HashMap<String, Object>();
		  Map<String, Object> params = new HashMap<String, Object>();
		  MensajeBean rBean = null;
		  UsuarioBean userSession;
		  //
		  if(log.isDebugEnabled())
				log.debug("Inicio: cargarAprobacionProrrogaConcl");
		  //
		  //Verifica que se tenga sesion con informacion del usuario
		  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  if (userSession == null) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Usuario no logueado");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "error", rBean);
		  } else {
			  UserNameHolder.set(userSession.getNroRegistro());
		  }
		  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
		  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "error", rBean);
		  }

		  params.put("type", "AyudaJSON");
		  params.put("catalogoID", "357");
		  params.put("codTipoDes", "");
		  params.put("fechaVigencia", SunatDateUtils.getCurrentDate());
		  params.put("codEstado", "01");
		  params.put("esPostLevante", request.getParameter("hdn_Post_Levante"));//adicionado por PAS20165E220200032

		  //amancilla lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogoImpl) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(params);
		  lista = (ArrayList<Map<String, Object>>) ((AyudaServiceDataCatalogo) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).buscar(params);
		  //
		  ModelAndView view = new ModelAndView("SolicitudProrrogaConclusion");
		  view.addObject("cod_aduana", mapDeclaracion.get("COD_ADUANA"));
		  view.addObject("ann_presen", mapDeclaracion.get("ANN_PRESEN").toString());
		  view.addObject("num_declaracion", mapDeclaracion.get("NUM_DECLARACION").toString());
		  view.addObject("num_corredoc", mapDeclaracion.get("NUM_CORREDOC").toString());
		  view.addObject("cod_regimen", mapDeclaracion.get("COD_REGIMEN"));
		  view.addObject("des_regimen", mapDeclaracion.get("COD_REGIMEN_DESC"));
		  fecha = (Date) mapDeclaracion.get("FEC_DECLARACION");
		  view.addObject("fec_declaracion", SunatDateUtils.getFormatDate(fecha, "dd/MM/yyyy"));
		  fecha = (Date) mapDeclaracion.get("FEC_VENCONCLU");
		  view.addObject("fec_venconclu", SunatDateUtils.getFormatDate(fecha, "dd/MM/yyyy"));
		  view.addObject("listaMotivoSolicitud", lista);

		  Boolean ingresoPorPostLevante = params.get("esPostLevante")!=null && "1".equals(params.get("esPostLevante").toString())?true:false;//PAS20165E220200032
		  String esPostlevante = params.get("esPostLevante")!=null ? params.get("esPostLevante").toString():" ";//PAS20165E220200032
		  // Se obtiene informacion de la solicitud de prorroga de conclusion
		  params.clear();
		  params.put("NUM_CORREDOC", mapDeclaracion.get("NUM_CORREDOC").toString());
		  listaSoliProrroga = (ArrayList<SoliProrroga>) ((SoliProrrogaDAO) fabricaDeServicios.getService("despaduanero2.soliProrrogaDAO")).findSolicitudesProrrogaConclusion(params);


		  /**Inicio de cambios PAS20165E220200032***/
			String nombreDiligencia = "Diligencia de Post Levante";
			/*GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
			Date fechadeclaracion = mapDeclaracion.get("FEC_DECLARACION")!=null && mapDeclaracion.get("FEC_DECLARACION").toString()!=" "?
					(Date) mapDeclaracion.get("FEC_DECLARACION"):SunatDateUtils.getDefaultDate();
			//RF01 - Bloqueo para diligencia de conclusion E1
			if(!ingresoPorPostLevante && getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
				declaracion.put("error", "No corresponde el registro de Diligencia de Conclusión para la Declaración numerada posterior a la vigencia del DL 1235");
				return  declaracion;
			}*/
			Date fechaDiligencia=(Date) mapDeclaracion.get("FEC_DECLARACION");//aca numerac
			if(ingresoPorPostLevante){
				fechaDiligencia = this.declaracionService.obtenerFechaOrigenPostLevante(mapDeclaracion.get("NUM_CORREDOC").toString(),fechaDiligencia);
			}
			view.addObject("fec_diligencia",fechaDiligencia);
			/**Fin de cambios PAS20165E220200032***/

		  for(SoliProrroga soliProrroga: listaSoliProrroga) {
			  mapProrrogaConclusion.put("txt_numCorredoc", Long.toString(soliProrroga.getNumeroCorrelativo()));
			  mapProrrogaConclusion.put("txt_codUsuario", soliProrroga.getUsuarioRegistro());

			  String nombreUsuario = ((RecepcionDocumentosService) fabricaDeServicios.getService("declaracion.service.RecepcionDocumentosService")).obtenerNombrePersonal(soliProrroga.getUsuarioRegistro());
			  if (!nombreUsuario.isEmpty()) {
				  mapProrrogaConclusion.put("txt_nomUsuario", nombreUsuario);
			  } else {
				  mapProrrogaConclusion.put("txt_nomUsuario", " ");
			  }
			  /*params.clear();
			  params.put("cod_pers", soliProrroga.getUsuarioRegistro());
			  listRRHH = ((ConsultaService) fabricaDeServicios.getService("rrhh2.service.consultaService")).consultarPersonal(params);
			  if (listRRHH != null && !listRRHH.isEmpty()) {
				  nombreUsuario = (HashMap<String, Object>) listRRHH.get(0);
				  mapProrrogaConclusion.put("txt_nomUsuario", nombreUsuario.get("t02nombres").toString() + " " + nombreUsuario.get("t02ap_pate").toString() + " " + nombreUsuario.get("t02ap_mate").toString());
			  } else {
				  mapProrrogaConclusion.put("txt_nomUsuario", " ");
			  }*/

			  fechaBean.setFecha(soliProrroga.getFechaPropuesta());
			  fechaSB = fechaBean.getFormatDate("dd/MM/yyyy");
			  mapProrrogaConclusion.put("txt_fecProrroga", fechaSB);
			  //deserializamos
			  JsonSerializer jsonSerializer = new JsonSerializer();
			  Map <String, Object> mapaDeserializar = (Map<String, Object>) jsonSerializer.deserialize(soliProrroga.getCodigosMotivos());
			  List <Map<String, Object>> listaAmoti = (List<Map<String, Object>>) mapaDeserializar.get("amoti");
			  String codigosMotivos = "";
			  for(Map <String, Object> mapaMotivos: listaAmoti) {
				  if (!codigosMotivos.trim().isEmpty()) {
					  codigosMotivos = codigosMotivos + ",";
				  }
				  codigosMotivos = codigosMotivos + "\"" + mapaMotivos.get("c").toString() + "\"";
			  }
			  mapProrrogaConclusion.put("sel_cod_motivoSolicitud_new", codigosMotivos);
			  mapProrrogaConclusion.put("txt_sustentoProrroga", soliProrroga.getDescripcionSustento());

			  mapProrrogaConclusion.put("esPostLevante",esPostlevante);//PAS20165E220200032
		  }
		  //
		  view.addObject("prorrogaConclusion", mapProrrogaConclusion);
		  view.addObject("hdn_es_aprobacion", "1");
		  //
		  if(log.isDebugEnabled())
				log.debug("Fin: cargarAprobacionProrrogaConcl");
		  //
		  return view;
	  }

	  /**
	   * Valida la informacion ingresada en aprobacion de solicitud de prorroga de conclusion
	   * @author hsaenz
	   * @param request
	   * @param response
	   * @return
	   */
	  // hsaenz: 10/09/2014
	  @SuppressWarnings("unchecked")
	  public ModelAndView validaSolAprobacionProrrogaConcl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		  Date fechaDeclaracion;
		  Date fechaVencimientoConclusion12 = new Date();
		  Date fechaSolicitudProrroga;
		  //Date fechaSolicitadaProrroga;
		  Date fechaVctoConclu;
		  Date fechaVencRegimen;
		  Map<String, Object> mapDeclaracion;
		  //Map<String, Object> objRes = new HashMap<String,Object>();
		  Map <String, Object> parametros = new HashMap<String, Object>();
		  MensajeBean rBean = null;
		  ServletWebRequest webRequest = new ServletWebRequest(request);
		  String objName = "beanM";
		  String objRes = "No se ha guardado la informaci\u00f3n";
		  UsuarioBean userSession;

		  if(log.isDebugEnabled()) log.debug("Inicio: validaSolProrrogaConclusion");

		  //Verifica que se tenga sesion con informacion del usuario
		  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  if (userSession == null) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: Usuario no logueado");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "error", rBean);
		  } else {
			  UserNameHolder.set(userSession.getNroRegistro());
		  }
		  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
		  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "error", rBean);
		  }
		  //numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
		  request.setCharacterEncoding("ISO-8859-1");
		  //Valida que la fecha de vencimiento de la conclusion, no corresponda al plazo maximo permitido
		  fechaDeclaracion = (Date) mapDeclaracion.get("FEC_DECLARACION");
		  fechaVctoConclu = (Date) mapDeclaracion.get("FEC_VENCONCLU");
		  parametros = (Map<String, Object>) ((ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice")).obtFechaConclusionDespacho(parametros, fechaDeclaracion, 12);
		  if(parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
			  //
			  fechaVencimientoConclusion12 = (Date) parametros.get("fechaConclusionDespa");
		  } else {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error interno de la aplicaci\u00f3n");
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
		  //------------------------------
		  //Validaciones antes de guardar
		  //-------------------------------

		  /**Inicio cambios PAS20165E220200032**/
		  Boolean ingresoPostLevante = webRequest.getParameter("hdn_Post_Levante") != null
				  && webRequest.getParameter("hdn_Post_Levante").toString().equals("1")?true:false;//PAS20165E220200032

		  String nom_diligencia="conclusi\u00f3n";
		  if(ingresoPostLevante){
			  nom_diligencia="Post Levante";
		  }
		  /**Fin cambios PAS20165E220200032**/

		  if ((webRequest.getParameter("fec_prorroga") == null || webRequest.getParameter("fec_prorroga").toString().isEmpty())
				  && (webRequest.getParameter("hdn_fec_prorroga") == null || webRequest.getParameter("hdn_fec_prorroga").toString().isEmpty())) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: No se ha ingresado la fecha de pr\u00f3rroga");
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  } else {
			  fechaSolicitudProrroga = FechaBean.getDate(webRequest.getParameter("fec_prorroga").toString(), "dd/MM/yyyy");
			  //fechaSolicitadaProrroga = FechaBean.getDate(webRequest.getParameter("hdn_fec_prorroga").toString(), "dd/MM/yyyy");
			  parametros.clear();
			  parametros = (Map<String, Object>) ((ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice")).obtFechaConclusionDespacho(parametros, fechaSolicitudProrroga, 0);
			  if(parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
				  fechaSolicitudProrroga = (Date) parametros.get("fechaConclusionDespa");
			  }
			  //
			  if (fechaSolicitudProrroga.after(fechaVencimientoConclusion12)) {
				  rBean = new MensajeBean();
			      rBean.setError(true);
			      //rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la conclusi\u00f3n consignada excede el plazo de los 12 meses de numerada la declaraci\u00f3n");
			      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de "+nom_diligencia+
			    		  " consignada excede el plazo de los 12 meses de numerada la declaraci\u00f3n");//PAS20165E220200032
			      log.error(rBean.getMensajeerror());
			      //
			      return new ModelAndView(this.jsonView, "error", rBean);
			  }
			  //
			  if (fechaSolicitudProrroga.before(fechaVctoConclu)
					  || fechaSolicitudProrroga.equals(fechaVctoConclu)) {
				  rBean = new MensajeBean();
			      rBean.setError(true);
			      //rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la conclusi\u00f3n registrada debe ser mayor a la fecha actual de vencimiento de la conclusi\u00f3n de la declaraci\u00f3n");
			      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de "+nom_diligencia+
			    		  " registrada debe ser mayor a la fecha actual de vencimiento de "+nom_diligencia+" de la declaraci\u00f3n");//PAS20165E220200032
			      log.error(rBean.getMensajeerror());
			      //
			      return new ModelAndView(this.jsonView, "error", rBean);
			  }
			  //
			  if (mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("20")
					  || mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("21")
					  || mapDeclaracion.get("COD_REGIMEN").toString().trim().equals("70")) {
				  //
				  if (!mapDeclaracion.get("FEC_VENREGIMEN").toString().equals("01/01/0001")) {
					  fechaVencRegimen = FechaBean.getDate(mapDeclaracion.get("FEC_VENREGIMEN").toString(), "dd/MM/yyyy");
					  if (fechaVencRegimen.before(fechaSolicitudProrroga) ) {
						  rBean = new MensajeBean();
					      rBean.setError(true);
					      //rBean.setMensajeerror("Error: La nueva fecha de vencimiento de la conclusi\u00f3n consignada excede la fecha de vencimiento del r\u00e9gimen");
					      rBean.setMensajeerror("Error: La nueva fecha de vencimiento de "+nom_diligencia+" consignada excede la fecha de vencimiento del r\u00e9gimen");//PAS20165E220200032
					      log.error(rBean.getMensajeerror());
					      //
					      return new ModelAndView(this.jsonView, "error", rBean);
					  }
				  } else {
					  rBean = new MensajeBean();
				      rBean.setError(true);
				      rBean.setMensajeerror("Error: Fecha de vencimiento de r\u00e9gimen es igual a: " + mapDeclaracion.get("FEC_VENREGIMEN").toString());
				      log.error(rBean.getMensajeerror());
				      //
				      return new ModelAndView(this.jsonView, "error", rBean);
				  }
			  }
		  }

		  //
		  if (webRequest.getParameter("cod_motivosolicitud") == null || webRequest.getParameter("cod_motivosolicitud").toString().isEmpty()) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: No se ha ingresado el motivo de la solicitud de pr\u00f3rroga");
		      log.error(rBean.getMensajeerror());
		      //
		      return new ModelAndView(this.jsonView, "error", rBean);
		  }
		  //*********************************************
		  //Si todo es correcto y se ha enviado el paramero para guardar datos, procede a guardar la informacion
		  //*********************************************
		  if (webRequest.getParameter("guardaDatos") != null && !webRequest.getParameter("cod_motivosolicitud").toString().isEmpty()) {
			  Map<String, Object> mapDatosIngresados = new HashMap<String,Object>();
			  if (webRequest.getParameter("guardaDatos").toString().equals("2")) {
				  mapDatosIngresados.put("num_corredoc", webRequest.getParameter("hdn_num_corredocsol"));
				  mapDatosIngresados.put("fec_prorroga", SunatDateUtils.getFormatDate(fechaSolicitudProrroga, "dd/MM/yyyy"));
				  mapDatosIngresados.put("cod_motivosolicitud", webRequest.getParameter("cod_motivosolicitud"));
				  mapDatosIngresados.put("sustento_prorroga", webRequest.getParameter("sustento_prorroga"));
				  mapDatosIngresados.put("ingresoPostLevante", webRequest.getParameter("hdn_Post_Levante") != null?
						   webRequest.getParameter("hdn_Post_Levante").toString():" " );//PAS20165E220200032
				  //
				  if(log.isDebugEnabled())
					  log.debug("Fin: validaSolProrrogaConclusion");
				  //
				  return guardaAprobacionProrrogaConcl(mapDeclaracion, mapDatosIngresados, userSession);
			  } else {
				  rBean = new MensajeBean();
				  rBean.setError(true);
				  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n. El error es: No se env\u00eda informaci\u00f3n para aceptar solicitud de pr\u00f3rroga de conclusi\u00f3n");
				  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				  log.error(rBean.getMensajeerror());
				  objName = "error";
				  return new ModelAndView(this.jsonView, "error", rBean);
			  }
		  } else {
			  rBean = new MensajeBean();
			  rBean.setError(true);
			  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n. El error es no se env\u00eda informaci\u00f3n para aceptar solicitud de pr\u00f3rroga de conclusi\u00f3n");
			  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			  log.error(rBean.getMensajeerror());
			  objName = "error";
			  return new ModelAndView(this.jsonView, "error", rBean);
		  }
	  }

	  /**
	   * Guarda aprobacion de solicitud de prorroga de conclusion
	   * @author hsaenz
	   * @param request
	   * @param response
	   * @return
	   */
	  // hsaenz: 10/09/2014:
	  @SuppressWarnings("unchecked")
	  private ModelAndView guardaAprobacionProrrogaConcl(Map<String, Object> mapDeclaracion, Map<String, Object> mapDatosIngresados, UsuarioBean userSession) throws Exception {
		  boolean guardoInformacion = false;
		  int numcorredoc;
		  List <Map<String, Object>> listFuncionarios;
		  Map <String, Object> param = new HashMap<String, Object>();
		  MensajeBean rBean = null;
		  String objName;
		  String objRes;

		  if(log.isDebugEnabled())
				log.debug("Inicio: guardaAprobacionProrrogaConcl");

		  ///////////////////
		  //Empieza proceso de guardar datos
		  ///////////////////
		  ModelAndView view;
		  try {
			  long nroCorrelativoSolicitud = Long.parseLong(mapDatosIngresados.get("num_corredoc").toString());
			  //para roles
				// Para busqueda de funcionario aduanero
				numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
				param.clear();
				param = new HashMap<String, Object>();

				param.put("NUM_CORREDOC", numcorredoc);
				listFuncionarios = (List<Map<String, Object>>) ((EspeDocuDAO) fabricaDeServicios.getService("asignacion.espeDocuDAO")).findFuncionarioAduaneroAsignadaSolicitud(param);
				//
			  guardoInformacion = ((SolicitudService) fabricaDeServicios.getService("despaduanero2.solicitudService")).actualizarAprobarSolicitudProrroga(mapDeclaracion, mapDatosIngresados, nroCorrelativoSolicitud, listFuncionarios, userSession.getNroRegistro());
		  } catch(Exception e) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error interno en la aplicaci\u00f3n. El error es: " + e.getMessage());
		      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
		      log.error("guardaAprobacionProrrogaConcl - ERROR : El error es: " + e.getMessage(), e);
		      objName = "error";
		      view = new ModelAndView(this.jsonView, objName, rBean);
		      return view;
		  }

		  //Retorna en caso de que no hayan errores
		  if (guardoInformacion == true) {
			  objRes = "Se guard\u00f3 la informaci\u00f3n ingresada";
			  objName = "beanM";
			  view = new ModelAndView(this.jsonView, objName, objRes);
		  } else {
			  rBean = new MensajeBean();
			  rBean.setError(true);
			  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n");
			  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			  log.error(rBean.getMensajeerror());
			  objName = "error";
			  view = new ModelAndView(this.jsonView, objName, rBean);
		  }

		  if(log.isDebugEnabled())
				log.debug("Fin: guardaAprobacionProrrogaConcl");

		  return view;
	  }

	  /**
	   * Guarda rechazo de solicitud de prorroga de conclusion
	   * @author hsaenz
	   * @param request
	   * @param response
	   * @return
	   */
	  // hsaenz: 10/09/2014
	  @SuppressWarnings("unchecked")
	  public ModelAndView guardaRechazoProrrogaConcl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		  int numcorredoc;
		  List <Map<String, Object>> listFuncionarios;
		  long nroCorrelativoSolicitud;
		  Map<String, Object> mapDeclaracion;
		  //Map<String, Object> objRes = new HashMap<String,Object>();
		  Map <String, Object> param;
		  MensajeBean rBean = null;
		  ModelAndView view = null;
		  ServletWebRequest webRequest = new ServletWebRequest(request);
		  String objName = "beanM";
		  String objRes = "No se ha procesado";
		  UsuarioBean userSession;


		  if(log.isDebugEnabled())
				log.debug("Inicio: guardaRechazoProrrogaConcl");

		  //Verifica que se tenga sesion con informacion del usuario
		  userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  if (userSession == null) {
			  rBean = new MensajeBean();
		      rBean.setError(true);
		      rBean.setMensajeerror("Error: Usuario no logueado");
		      log.error(rBean.getMensajeerror());
		      //
			  return new ModelAndView(this.jsonView, "error", rBean);
		  } else {
			  UserNameHolder.set(userSession.getNroRegistro());
		  }

		  /**Inicio cambios PAS20165E220200032**/
		  String ingresoPostLevante = webRequest.getParameter("hdn_Post_Levante") != null?webRequest.getParameter("hdn_Post_Levante").toString():" ";
		  /**Fin cambios PAS20165E220200032**/

		  //*********************************************
		  //Si todo es correcto y se ha enviado el parametro para guardar datos, procede a guardar la informacion
		  //*********************************************
		  if (webRequest.getParameter("guardaDatos") != null) {
			  if (webRequest.getParameter("guardaDatos").toString().equals("3")) {
				  try {
					  mapDeclaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
					  if (mapDeclaracion == null || mapDeclaracion.isEmpty()) {
						  rBean = new MensajeBean();
					      rBean.setError(true);
					      rBean.setMensajeerror("No se ha encontrado declaraci\u00f3n en sesi\u00f3n");
					      log.error(rBean.getMensajeerror());
					      //
						  return new ModelAndView(this.jsonView, "error", rBean);
					  }

					  numcorredoc = Integer.parseInt(SunatStringUtils.toStringObj(mapDeclaracion.get("NUM_CORREDOC")));
					  nroCorrelativoSolicitud = Long.parseLong(webRequest.getParameter("hdn_num_corredocsol").toString());
					  //
					  param = new HashMap<String, Object>();
					  param.put("NUM_CORREDOC", numcorredoc);
					  listFuncionarios = (List<Map<String, Object>>) ((EspeDocuDAO) fabricaDeServicios.getService("asignacion.espeDocuDAO")).findFuncionarioAduaneroAsignadaSolicitud(param);
					  //
					  mapDeclaracion.put("ingresoPostLevante", ingresoPostLevante);//PAS20165E220200032
					  ((SolicitudService) fabricaDeServicios.getService("despaduanero2.solicitudService")).actualizarRechazarSolicitudProrroga(mapDeclaracion, nroCorrelativoSolicitud, listFuncionarios, userSession.getNroRegistro());
					  //.actualizarAprobarSolicitudProrroga(mapDeclaracion, mapDatosIngresados, nroCorrelativoSolicitud, listFuncionarios, userSession.getNroRegistro());
					  objRes = "Se guard\u00f3 la informaci\u00f3n ingresada";
					  objName = "beanM";
					  //
					  if(log.isDebugEnabled())
							log.debug("Fin: guardaRechazoProrrogaConcl");
					  //
					  //Retorna en caso de que no hayan errores
					  return new ModelAndView(this.jsonView, objName, objRes);
				  } catch (Exception e) {
					  rBean = new MensajeBean();
					  rBean.setError(true);
					  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n. El error es" + e.getMessage());
					  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
					  log.error("guardaRechazoProrrogaConcl - Error: El error es" + e.getMessage(), e);
					  objName = "error";
					  return new ModelAndView(this.jsonView, objName, rBean);
				  }
			  } else {
				  rBean = new MensajeBean();
				  rBean.setError(true);
				  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n. El error es: No se env\u00eda informaci\u00f3n para rechazar solicitud de pr\u00f3rroga de conclusi\u00f3n");
				  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				  log.error(rBean.getMensajeerror());
				  objName = "error";
				  return new ModelAndView(this.jsonView, objName, rBean);
			  }
		  } else {
			  rBean = new MensajeBean();
			  rBean.setError(true);
			  rBean.setMensajeerror("Error: No se ha guardado la informaci\u00f3n. El error es: No se env\u00eda informaci\u00f3n para rechazar solicitud de pr\u00f3rroga de conclusi\u00f3n");
			  rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			  log.error(rBean.getMensajeerror());
			  objName = "error";
			  return new ModelAndView(this.jsonView, objName, rBean);
		  }
	  }


	  public ModelAndView iniciarDeclaracionConclusion(HttpServletRequest request, HttpServletResponse response)
              throws Exception
		{

			ModelAndView modelView = null;
			Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,
			                     "mapCabDeclaraActual");
			String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
			String acceso = "";


			String modifDilig = request.getParameter("hdn_modifDilig") != null ? request.getParameter("hdn_modifDilig") : "";

			acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";
			//amancilla RIN13FSW Bug19128 se comenta el estado notificado no debe pasar por este codigo
			if (!(acceso.equals("00")) && Constantes.ESTADO_CONCLU_REVISION.equals(codigoEstadoDUA))
			//|| codigoEstadoDUA.equals(Constantes.ESTADO_NOTIFICADO))
			{

				WebUtils.setSessionAttribute(request, "tipoDiligencia", "01"); // en revision
				modelView = cargarRegRevisionConclusion(request, response);

			}
			else if (modifDilig.equals("MOD") || acceso.equals("00")
			|| Constantes.ESTADO_CONCLU_PROCESO.equals(codigoEstadoDUA))
			{
				modelView = cargarRegEnProcesoConclusion(request, response);

			}
			else
			{
				String msjValid = this.declaracionService.validarFechaRecepcion(mapCabDeclaraActual);

				Map<String, String> params = new HashMap<String, String>();
				params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
				params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
				params.put("ann_presen", request.getParameter("txt_ann_presen"));
				params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
				params.put("des_regimen", request.getParameter("hdn_des_regimen"));
				params.put("num_declaracion", request.getParameter("txt_num_declaracion"));
				params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
				params.put("msjValid", msjValid);

				modelView = new ModelAndView("IniciarDiligenciaConclusion", "params", params);

			}
			return modelView;
		}

	  private Map<String, Object> valorProvisional(HttpServletRequest request,Map<String,Object> declaracion,Map<String, Object> params, String tipoRegimen){
		 ServletWebRequest webRequest = new ServletWebRequest(request);
	//  <RIN10> 3014 ERUESTAA
	    String flag = "";
		  flag = WUtil.getParam(request,"hdn_flag");
		  if(flag=="" ||flag.isEmpty()){
			  flag = "-1";
		  	}
	//	</RIN10> 3014 ERUESTAA
	//    <RIN10> 3014 ERUESTAA
		  Map<String, Object> tieneVP = new HashMap<String, Object>();
	      tieneVP = null;
	      Map<String, Object> paramsValidador = new HashMap<String, Object>();
	      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
	      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014); //Consultar si valor provisional aplica a conclusion
	      boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
	      if(indicadorDUAValorProvActivo){
	      //Fin RIN10 mpoblete refactor
	    	  if(flag!="-1" && flag.equals("1")){
		      	  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
		     		    String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
			      	  	verificarValorProvisional(params,declaracion);
			      	  	declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
			      	  	paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
			      	  	tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
		      	  }
			    }else if(flag!="-1" ||flag.equals("2")){
			      	 if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10	        	 
				             tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
			      	 }
			    }
	      }
		    double mtoMonto = 0.0;
		    Map<String, String> PkSerie = new HashMap<String, String>();
		    List<Map<String, Object>> listaItems = null;
		    /*apra la verificacion de que  cuenta con el indicador de valor provisional*/
		    if((!org.apache.commons.collections.MapUtils.isEmpty(tieneVP) || tieneVP!=null) &&
		    		tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
		  	  String numCorreDocConsultado = webRequest.getParameter("hdn_num_corredoc")!=null?webRequest.getParameter("hdn_num_corredoc"):"";
		  	  if(SunatStringUtils.isEmpty(numCorreDocConsultado) || "undefined".equals(numCorreDocConsultado)){
		  	        Map<String, Object> mapCabDeclaracion = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");

		  	        numCorreDocConsultado = mapCabDeclaracion.get("NUM_CORREDOC").toString();
		  	      }
		  	      PkSerie.put("NUM_CORREDOC", numCorreDocConsultado);
		  	      PkSerie.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie") != null ? webRequest.getParameter("hdn_num_secserie"):"");

		  	      // para los casos de series agregadas que estan en memoria

		  	      Map<String, String> mapNuevaSerieSerieBase = (Map<String, String>) WebUtils.getSessionAttribute(request, "mapNuevaSerieSerieBase");
		  	      if (mapNuevaSerieSerieBase != null && mapNuevaSerieSerieBase.size() > 0){
		  	        String serieBase = mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) != null ? mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) : "";
		  	        if (!serieBase.equals("")){
		  	          PkSerie.put("NUM_SECSERIE", serieBase);
		  	        }
		  	      }

		  	      listaItems = formatoValorService.obtenerFVItem(PkSerie);
		  	      Set<Integer> seriesUnicos = new HashSet<Integer>();
		  		  int numeroSerieActual = 0;

		  		  List<Map<String, Object>>  listaSeriesMonto = new ArrayList<Map<String,Object>>();

		  	      for (int j = 0; j < listaItems.size(); j++){
			    	  numeroSerieActual = Integer.parseInt(listaItems.get(j).get("cod_secserie").toString());
			    	  seriesUnicos.add(numeroSerieActual);
		  	      }

		  	  	for (int  j : seriesUnicos) {
		  	  		double montoTotalItemSerie = 0.0;
		  	  		Map<String, Object> datoMapeados  = new HashMap<String, Object>();
		  	  		for (Map item : listaItems) {
		  	  			if(j==Integer.valueOf(item.get("cod_secserie").toString())) {
		      	  			montoTotalItemSerie = montoTotalItemSerie+Double.valueOf(item.get("mto_monto").toString()).doubleValue();
		                  }
		              }

		  	  		datoMapeados.put("NUM_SECSERIE",j);
		  	  		datoMapeados.put("MONTO_TOTAL_ITEM_SERIE",String.valueOf(montoTotalItemSerie));
		  	  		listaSeriesMonto.add(datoMapeados);
		  	      }

		        WebUtils.setSessionAttribute(request, "listaSeriesMonto", listaSeriesMonto);
		        indValorProvisional = "SI";
		    }

		      List<Map<String, Object>> lstDetDeclaraActualVPFB = new ArrayList<Map<String,Object>>();
		      List<Map<String, Object>> lstDetDeclaraActualVPFA = new ArrayList<Map<String,Object>>();
		      WebUtils.setSessionAttribute(request, "lstDetDeclaraActualVPFB", lstDetDeclaraActualVPFB);
		      WebUtils.setSessionAttribute(request, "lstDetDeclaraActualVPFA", lstDetDeclaraActualVPFA);
	//  	</RIN10> 3014/3006 ERUESTAA
		      return tieneVP;
	}





    @SuppressWarnings({ "rawtypes", "unchecked" })
	public ModelAndView cargarRegEnProcesoConclusion(HttpServletRequest request, HttpServletResponse response)throws Exception{

    	WebUtils.setSessionAttribute(request, "tipoDiligencia", Constantes.COD_TIPO_DILIGENCIA_CONCLUSION);

    	Map<String, Object> params = new HashMap<String, Object>();
	    String modifDilig = WUtil.getParam(request, "hdn_modifDilig");
	    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	    UserNameHolder.set(bUsuario.getNroRegistro());
	    ServletWebRequest webRequest = new ServletWebRequest(request);

	    params.put("NUM_DECLARACION", WUtil.getParam(webRequest, "hdn_num_declaracion", webRequest.getParameter("txt_num_declaracion")));
	    params.put("COD_ADUANA", WUtil.getParam(webRequest, "hdn_cod_aduana", webRequest.getParameter("txt_cod_aduana")));
	    params.put("ANN_PRESEN", WUtil.getParam(webRequest, "hdn_ann_presen", webRequest.getParameter("txt_ann_presen")));
	    params.put("COD_REGIMEN", WUtil.getParam(webRequest, "hdn_cod_regimen", webRequest.getParameter("sel_cod_regimen")));
	    params.put("EN_PROCESO", "1");
	    params.put("esPostLevante",WUtil.getParam(webRequest, "hdn_Post_Levante", webRequest.getParameter("hdn_Post_Levante")));//adicionado por PAS20165E220200032

	    String tipoRegimen = (String) params.get("COD_REGIMEN");//<RIN 10 /> ERUESTAA

	    try
	    {
	      Map<String, Object> declaracion = this.declaracionService.obtenerDeclaracion(params); //error no se mostraba la descripcion de la garantia
	      String tituloDiligencia = "Conclusi�n de Despacho";
	      /**Inicio de cambios por PAS20165E220200032**/
			if(request.getParameter("hdn_Post_Levante")!=null && request.getParameter("hdn_Post_Levante").toString().equals("1")){
				tituloDiligencia=(String) catalogoAyudaService.getElementoCat(Constantes.CAT_TIPO_DILIGENCIA, COD_TIPO_DILIGENCIA_CONCLUSION).get("des_corta");
			}
			/**Fin de cambios por PAS20165E220200032**/
	      declaracion.put("tituloDiligencia", tituloDiligencia);

	      //Llena los datos relacionados a la declaracion
	      //LstDetDeclara
	      List lstDetDeclara       = (List)WebUtils.getSessionAttribute(request, "lstDetDeclara");
		  if(lstDetDeclara==null || lstDetDeclara.isEmpty()){
		    	    Map<String, String> paramsSerie = new HashMap<String, String>();
		    	    paramsSerie.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
		    	    paramsSerie.put("num_corredoc",declaracion.get("NUM_CORREDOC").toString().trim());
		    	    paramsSerie.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString());
		    	    paramsSerie.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
		    	    paramsSerie.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
		    	    paramsSerie.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());
		    	    paramsSerie.put("estadoDUA", declaracion.get("COD_ESTDUA").toString());
		    	    lstDetDeclara = serieService.obtenerListadoSeries(paramsSerie);
		    	    WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
			  		WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", Utilidades.copiarLista(lstDetDeclara));
		      }


	      //LstSerieItems
	      List<Map<String, Object>> lstSeriesItems  = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItem");

			if (CollectionUtils.isEmpty(lstSeriesItems)){ // si esta vacio o null obtener de BD
				params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString().trim());
				lstSeriesItems = formatoValorService.obtenerFormatoBCorrelaciones(params);
				WebUtils.setSessionAttribute(request, "lstSeriesItem", lstSeriesItems);
			}




	      /* inicio ehumareda rin10 */
	      FechaBean fechaFinProvicional= new FechaBean();
	      String fecha = (new FechaBean(declaracion.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd").getFormatDate("dd/MM/yyyy"));
	      fechaFinProvicional.setFecha(fecha,FechaBean.FORMATO_DEFAULT );
	      FechaBean fechaDefault= new FechaBean();
	      fechaDefault.setFecha("31/12/9999", FechaBean.FORMATO_DEFAULT);
	      /* fin ehumareda rin10 */

	      //Se saca a funcion independiente
	      Map<String, Object> tieneVP = valorProvisional(request,declaracion,params, tipoRegimen);

	      Long numeroCorrelativo=new Long(0);
	  	  Map<String, Object> mapaSolicitudes=new HashMap();
	      if(declaracion != null){
		       numeroCorrelativo = new Long(declaracion.get("NUM_CORREDOC").toString());
		      /** inicio EJHM **/
		      RecepcionDocumentosService recepcionDocumentosService = fabricaDeServicios.getService("declaracion.service.RecepcionDocumentosService1");
		      List<SolicitudRecepcion> solicitudesRecepciones = recepcionDocumentosService.buscarSolicitudPorDeclaracion(numeroCorrelativo, "",false, "");
			  mapaSolicitudes = recepcionDocumentosService.listarRecepcionesConsultaDUA(solicitudesRecepciones);
				/** fin EJHM **/

	      if (!Constantes.ESTADO_CONCLU_PROCESO.equals(declaracion.get("COD_ESTDUA")) && !Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals(declaracion.get("COD_ESTDUA"))){
	        declaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_PROCESO);
	        Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
		    paramDeclaracion.put("NUM_CORREDOC", numeroCorrelativo);
	        paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_PROCESO);

	        declaracionService.updateDeclaracion(paramDeclaracion);
	      }

			  //amancilla LGA error debido a que jala el estado 11 sin validar la fecha de vigencia
			  //por siaca he copiado el codigo de Anita no me juzguen
	      //declaracion.put("COD_ESTDUA_DESC",catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, declaracion.get("COD_ESTDUA").toString().trim()));

			  Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
					  SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
			  String descripEstado = (catalogoAyudaService.getDataCatalogo(Constantes.CAT_ESTADO_DUA, declaracion.get("COD_ESTDUA").toString().trim(), fechadeclaracion).getDesDatacat().toUpperCase());
			  declaracion.put("COD_ESTDUA_DESC", descripEstado);

			  //fin cambi amancilla


	      if (declaracion.get("COD_MODALIDAD").equals(Constantes.MODALIDAD_ANTICIPADO) &&
	          declaracion.get("COD_INDICADOR").equals(Constantes.IND_DUA_REQ_REGULARIZ)){
	        StringBuffer codModalidadDesc = new StringBuffer();
	        codModalidadDesc
	                        .append(declaracion.get("COD_MODALIDAD_DESC"))
	                        .append(MapUtils.getMapValor(declaracion, "ANTIC_REGU_DESC"));
	        declaracion.put("COD_MODALIDAD_DESC", codModalidadDesc.toString());

	      }

	      //long inicioDatosAnexoDeclaracion
	      // participante 31 deposito temporal
	      String numDocIdentPdf = MapUtils.getMapValor(declaracion, "NUM_DOCIDENT_PDF");
	      String codLocalAnexo = MapUtils.getMapValor(declaracion, "COD_LOCALANEXO");
	      String direccionLocalAnexo = "";
	      if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf)){
	        direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
	        if (SunatStringUtils.isEmpty(direccionLocalAnexo)){ // si no esta registrado el local
	          direccionLocalAnexo = "No registrado";
	        }
	      }else{
	        direccionLocalAnexo = "No registrado";
	      }
	      declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
	      String numDocIdentPdd =
	                              declaracion.get("NUM_DOCIDENT_PDD") != null
	                                                                         ? (String) declaracion.get("NUM_DOCIDENT_PDD")
	                                                                         : "";
	      String codLocalAnexoDeposito =
	                                     declaracion.get("COD_LOCALANEXODEPOSITO") != null
	                                                                                      ? (String) declaracion.get("COD_LOCALANEXODEPOSITO")
	                                                                                      : "";
	      String direccionLocalAnexoDeposito = "";
	      if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd))
	      {
	        direccionLocalAnexoDeposito =
	                                      declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd,
	                                                                                      codLocalAnexoDeposito);
	        if (SunatStringUtils.isEmpty(direccionLocalAnexoDeposito))
	        { // si no esta registrado el local
	          direccionLocalAnexoDeposito = " No registrado";
	        }
	      }
	      else
	      {
	        direccionLocalAnexoDeposito = "No registrado";
	      }

	      declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);

	      //Inicio declaracion Actual
	      Map<String, Object> declaracionActual = new HashMap<String, Object>();
	      /*INICIO P46 KAH --3014*/
	      ValTratamientoDonacionService valTratamientoDonacion = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");
	      valTratamientoDonacion.validarIndicadorDuaenDonacion(declaracion);
	      /*FIN P46 KAH --3014*/
	      if (!CollectionUtils.isEmpty(declaracion)){
	        declaracionActual.putAll(declaracion);
	      }
	      Map diligencia = new HashMap();
	      diligencia.put("IND_INCIDENCIA", "");
	      diligencia.put("IND_MULTA", "");
	      diligencia.put("DES_RESULTADO", "");

	      Map<String, String> mapPk = new HashMap<String, String>();
		  mapPk.put("NUM_CORREDOC", numeroCorrelativo.toString());
	      mapPk.put("IND_DEL", "0");

	      // Datos de Documentos Autorizantes, Asociados y Certificados de Origen
	      if (CollectionUtils.isEmpty((List) declaracion.get("lstDocAutAsociado"))){
	        List<Map<String, Object>> listaDocAsoc = declaracionService.obtenerDocAutAsociados(mapPk);
	        if (!CollectionUtils.isEmpty(listaDocAsoc)){
	          declaracion.put("lstDocAutAsociado", Utilidades.copiarLista((List) listaDocAsoc));
	          declaracionActual.put("lstDocAutAsociado", listaDocAsoc);
	        }
	      }
	      if (null == request.getSession().getAttribute("incrementalDocumentosAsociados")){
	        request.getSession().setAttribute(
	                                          "incrementalDocumentosAsociados",
	                                          declaracionService.obtenerMaxCorrelativoDocAutAsociado(mapPk));
	      }
	      if (CollectionUtils.isEmpty((List) declaracion.get("lstCabCertiOrigen"))){
	        List<Map<String, Object>> listaCabCerti = declaracionService.obtenerCertOrigen(mapPk);
	        if (!CollectionUtils.isEmpty(listaCabCerti)){
	          declaracion.put("lstCabCertiOrigen", Utilidades.copiarLista((List) listaCabCerti));
	          declaracionActual.put("lstCabCertiOrigen", listaCabCerti);
	        }
	      }
	      if (CollectionUtils.isEmpty((List) declaracion.get("lstDetAutorizacion"))){
	    	mapPk.put("verEliminadoDocAutoriz", "1");
	        List<Map<String, Object>> listaDetAut = serieService.obtenerDetAutorizacion(mapPk);
	        if (!CollectionUtils.isEmpty(listaDetAut)){
	          declaracion.put("lstDetAutorizacion", Utilidades.copiarLista((List) listaDetAut));
	          declaracionActual.put("lstDetAutorizacion", listaDetAut);
	        }
	      }
	       int countDoc = declaracion.get("lstDocAutAsociado")!=null?((List)declaracion.get("lstDocAutAsociado")).size():0;
	       if( countDoc > 0 ){
	        declaracionActual.put("IND_DOCAUT_ASOCIADOS", "1");
	      }else{
	    	  declaracionActual.put("IND_DOCAUT_ASOCIADOS", "0");
	      }
	      WebUtils.setSessionAttribute(request, "mapCabDeclaraActualNew", declaracionActual);
	      //este metodo debera cargar on demanda revisar....
	      cargaFormatoBCompletoNew(declaracion, declaracionActual, request);



	      Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
		  paramsDiligencia.put("NUM_CORREDOC", numeroCorrelativo.toString());
	      paramsDiligencia.put("COD_TIPDILIGENCIA",
	                           new String[] { Constantes.DILIG_REV_DOCUMENTARIA, Constantes.DILIG_REC_FISICO });
	      ValidaDiligenciaService validaDiligenciaService = fabricaDeServicios.getService("diligencia.ingreso.validaDiligenciaService");
	      Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(
	                                                                                             paramsDiligencia,
	                                                                                             declaracionActual);
	      String ultimaDiligencia = SojoUtil.toJson(mapUltimaDiligencia);

	    DUA adiDeclara = new DUA();
	    adiDeclara = null;
	    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){
	    	Map<String, Object> paramsFilterDatosAdicionalesDuaByPk = new HashMap<String, Object>();
	    	paramsFilterDatosAdicionalesDuaByPk.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));//usado con obtenerDatosAdicionalesDuaByPk
	    	adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsFilterDatosAdicionalesDuaByPk);
	    }
	    String fecRegulaValProvDDMMYY = "31/12/9999";
	    String fecRegOfiValProvDDMMYY = "31/12/9999";
	    Date fecRegulaValProv = null;
	    Date fecRegOfiValProv = null;
	    if (adiDeclara != null){
				 fecRegulaValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegulaValProv());
				 fecRegulaValProv = adiDeclara.getFecRegulaValProv();
				 fecRegOfiValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegOfiValProv());
				 fecRegOfiValProv = adiDeclara.getFecRegOfiValProv();
	    }
	    declaracionActual.put("FEC_FINPROVSIONAL", declaracion.get("FEC_FINPROVSIONAL"));
	    declaracionActual.put("FECHA_REGVP_DDMMYY", fecRegulaValProvDDMMYY);
	    declaracionActual.put("FECHA_REGOFVP_DDMMYY", fecRegOfiValProvDDMMYY);
	    declaracionActual.put("FECHA_REGVP", fecRegulaValProv);
	    declaracionActual.put("FECHA_REGOFVP", fecRegOfiValProv);
     	declaracionActual.put("IND_VALOR_PROV", "0");
	    ModelAndView res = new ModelAndView("RegDiligenciaConclusion");

	       //P24-II - Inicio
			mapaSolicitudes = recepcionDocumentosService.listarRecepcionesConsultaDUA(solicitudesRecepciones);
			SolicitudRecepcion solicitudRecepcion = null;
			declaracionActual.put("bandera", 0);
			declaracionActual.put("FEC_RECEP1", null);
			declaracionActual.put("NUMEROCORRELATIVO1", null);
			declaracionActual.put("NUMGED1", null);
			declaracionActual.put("FEC_RECHA1", null);
			declaracionActual.put("FEC_RECEP2", null);
			declaracionActual.put("NUMEROCORRELATIVO2", null);
			declaracionActual.put("NUMGED2", null);
			declaracionActual.put("FEC_RECHA2", null);
			if (!mapaSolicitudes.get("existesolicitudes").toString()
					.equals(ConstantesDeclaracion.NO_EXISTE_SOLICITUD)) {
				if (mapaSolicitudes.get("solicitudPrimeraRecepcion") != null) {
					res.addObject("modulo", "R"); // regularizacion
					solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
							.get("solicitudPrimeraRecepcion");
					declaracionActual.put("FEC_RECEP1",
							solicitudRecepcion.getFechaRecepcion());
					declaracionActual.put("NUMEROCORRELATIVO1",
							solicitudRecepcion.getNumeroCorrelativo());
					declaracionActual.put("NUMGED1",
							solicitudRecepcion.getNumGed());
				}
				if (mapaSolicitudes.get("solicitudPrimeraRecepcionRechazada") != null) {
					solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
							.get("solicitudPrimeraRecepcionRechazada");
					declaracionActual.put("FEC_RECEP_RECHA1",
							solicitudRecepcion.getFechaRecepcion());
					declaracionActual.put("FEC_RECHA1",
							solicitudRecepcion.getFechaRechazo());
					declaracionActual.put("NUMEROCORRELATIVORECHA1",
							solicitudRecepcion.getNumeroCorrelativo());
				}
				if (mapaSolicitudes.get("solicitudSegundaRecepcion") != null) {
					solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
							.get("solicitudSegundaRecepcion");
					declaracionActual.put("FEC_RECEP2",
							solicitudRecepcion.getFechaRecepcion());
					declaracionActual.put("NUMEROCORRELATIVO2",
							solicitudRecepcion.getNumeroCorrelativo());
					declaracionActual.put("NUMGED2",
							solicitudRecepcion.getNumGed());
				}
				if (mapaSolicitudes.get("solicitudSegundaRecepcionRechazada") != null) {
					solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
							.get("solicitudSegundaRecepcionRechazada");
					declaracionActual.put("FEC_RECEP_RECHA2",
							solicitudRecepcion.getFechaRecepcion());
					declaracionActual.put("FEC_RECHA2",
							solicitudRecepcion.getFechaRechazo());
					declaracionActual.put("NUMEROCORRELATIVORECHA2",
							solicitudRecepcion.getNumeroCorrelativo());
				}
				declaracionActual.put("bandera", 1);
			} else {
				declaracionActual.put("bandera", 0);
			}

		      if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){
		      	//Inicio RIN10 mpoblete refactor
		      	Map<String, Object> paramsFilterDatosAdicionalesDuaByPk = new HashMap<String, Object>();
		      	paramsFilterDatosAdicionalesDuaByPk.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));//usado con obtenerDatosAdicionalesDuaByPk
		      	//adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsValidador);
		      	adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsFilterDatosAdicionalesDuaByPk);
		      	//Fin RIN10 mpoblete refactor
		      }
		      if (adiDeclara != null){
		      	if (adiDeclara.getFecRegulaValProv()!=null)
		      	{
		  			 fecRegulaValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegulaValProv());
		  			 fecRegulaValProv = adiDeclara.getFecRegulaValProv();
		      	}
		      	if (adiDeclara.getFecRegOfiValProv() != null)
		      	{
		  			 fecRegOfiValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegOfiValProv());
		  			 fecRegOfiValProv = adiDeclara.getFecRegOfiValProv();
		      	}
		      }
		      declaracionActual.put("FECHA_REGVP_DDMMYY", fecRegulaValProvDDMMYY);
		      declaracionActual.put("FECHA_REGOFVP_DDMMYY", fecRegOfiValProvDDMMYY);
		      declaracionActual.put("FECHA_REGVP", fecRegulaValProv);
		      declaracionActual.put("FECHA_REGOFVP", fecRegOfiValProv);

		     // Date fechaLlegada = (Date)declaracion.get("FEC_LLEGADA");
		     // if(SunatDateUtils.isDefaultDate(fechaLlegada)){
		     //	  declaracionActual.put("FEC_LLEGADA", null);
		     // }
		      String codigoPropiedad = (String)declaracionActual.get("COD_PROPIEDAD");
		      String codigoPropiedadDesc =this.catalogoAyudaService.getDescripcionDataCatalogo("63",codigoPropiedad);
		      Map<String, Object> mapaSINI = obtenerDatosLevanteDuaSini(declaracionActual);
		      Map<String, Object> mapaEstadoRegu = determinarEstadoRegularizacion(declaracionActual);
		      declaracionActual.putAll(mapaEstadoRegu);
		      declaracionActual.putAll(mapaSINI);
		      declaracionActual.put("ENDOSE_DESC", codigoPropiedad + " - " + codigoPropiedadDesc);

		      //P24 - PAS20165E220200099
		      ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
		      Observacion observacion = new Observacion();
		      observacion.setNumcorredoc(SunatNumberUtils.toLong(declaracionActual.get("NUM_CORREDOC")));
		      observacion.setCodtipobserva("01"); //solo las observaciones de datos generales, si se requiere para otro formulario se deber� filtrar por JSP y colocar null en tipo de obs
		      List<Observacion> listaObservaciones = observacionService.buscarObservacion(observacion);
		      if(CollectionUtils.isEmpty(listaObservaciones)){
		    	  declaracionActual.put("OBSERVACIONES", null);
		    	  declaracionActual.put("CANT_OBS", 1);
		      }else{
		    	  String descCodObs;
		    	  for(Observacion obs : listaObservaciones){
		    		  descCodObs =this.catalogoAyudaService.getDescripcionDataCatalogo("369",obs.getCodtipobserva());
		    		  obs.setCodtipobserva(obs.getCodtipobserva().concat(" - ").concat((descCodObs!=null?descCodObs:"")));
		    	  }
		    	  declaracionActual.put("OBSERVACIONES", listaObservaciones);
		    	  declaracionActual.put("CANT_OBS", listaObservaciones.size());
		      }

		      String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613
		      String flag = "";
			  flag = WUtil.getParam(request,"hdn_flag");
			  if(flag==""){
			  	flag = "-1";
			  }
		      Map<String, Object> paramsValidador = new HashMap<String, Object>();
		      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
		      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
		      boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
		      if(indicadorDUAValorProvActivo){
		      //Fin RIN10 mpoblete refactor
		      if(flag!="-1" && flag.equals("1")){
		      	  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
		     		    String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
		      	     	//verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
		      	  	declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
		      	  	paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
		      	  	tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
		     		    //Inicio RIN10 BUG 22611,22613
		     		    if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
		     		    	verificarValorProvisional(params,declaracion);
		     		    	indicadorVFobProvVP = "SI";
		     		    }
		     		    //Fin RIN10 BUG 22611,22613
		      	  }
			    }else if(flag!="-1" ||flag.equals("2")){
			      	 if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
				             tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
				             //Inicio RIN10 BUG 22611,22613
				             if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
				            	 indicadorVFobProvVP = "SI";
				     		 }
				             //Fin RIN10 BUG 22611,22613
			      	 }
			    }
		      }//RIN10 mpoblete refactor

		      if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
		     	//Fin RIN10 BUG 22611,22613
		  		declaracionActual.put("IND_VALOR_PROV", "1");
		  	  }else{
		  		declaracionActual.put("IND_VALOR_PROV", "0");
		  	  }

		      String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracionActual, DEFAULT_TIPO_DOC);
		      WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);


		   	  if(declaracion.get("FEC_AUTLEVANTE")!=null && !SunatDateUtils.isDefaultDate((Date)declaracion.get("FEC_AUTLEVANTE"))){
		   		  declaracionActual.put("AUTLEVANTE_DESC","LEVANTE AUTORIZADO");
		   	  }else{
		   		  declaracionActual.put("AUTLEVANTE_DESC",null);
		   	  }

		      String FEC_FINPROVSIONAL_DDMMYY = null;
		  	  if (declaracion.get("FEC_FINPROVSIONAL")!=null){
		  		FEC_FINPROVSIONAL_DDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(declaracion.get("FEC_FINPROVSIONAL"));
		  	  }
		  	  declaracionActual.put("FEC_FINPROVSIONAL_DDMMYY", FEC_FINPROVSIONAL_DDMMYY);

		  	  	//P24-II - Fin

			  	//P24-II - Inicio

		  	  String numCorreDoc = numeroCorrelativo.toString();
		  	  Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
		  	  List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);
		  	  List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);
		  	  List<Map<String, Object>> listaElemEquipamiento = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_EQUIPAMIENTO);
		  	  List<Map<String, Object>> listaElemDocAsociado = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCAUT_ASOCIADO);
		  	  List<Map<String, Object>> listaElemDetAut =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_AUTORIZACION);
		  	  List<Map<String, Object>> listaElemCertOrigen =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_CERTIORIGEN);
		  	  List<Map<String, Object>> listaElemRegPrecedente =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCUPRECE_DUA);
		  	  List<Map<String, Object>> listaElemFormatoBDAV =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMB_PROVEEDOR);
		  	  List<Map<String, Object>> listaElemFormatoBFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);
		  	  List<Map<String, Object>> listaElemFormatoBItemFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_ITEM_FACTURA);
		  	  List<Map<String, Object>> listaElemSeriesItem =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_SERIES_ITEM);
		  	  List<Map<String, Object>> listaElemConvenioSerie =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CONVENIO_SERIE);
		  	  List<Map<String, Object>> listaElemFacturasSeries =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU);
		  	  List<Map<String, Object>> listaElemObservacion =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);
		  	  List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
		  	  if (!CollectionUtils.isEmpty(listaElemConvenioSerie)){
		  		  listaElemDetDeclara.addAll(listaElemConvenioSerie);
		  	  }
		  	  if (!CollectionUtils.isEmpty(listaElemDocAsociado)){
		  		  listaElemDetDeclara.addAll(listaElemDetAut);
		  	  }
		  	  List<Map<String, Object>> listaElemObservacionDecla       = new ArrayList();
		  	  if (!CollectionUtils.isEmpty(listaElemObservacion)){
		  		  for (Map<String, Object> mapObs : listaElemObservacion){
		  			  String codTipObs = mapObs.get("PK").toString();
		  			  if(codTipObs.startsWith("01")){
		  				  listaElemObservacionDecla.add(mapObs);
		  			  }
		  		  }
		  	  }

		  	  listaElemCabDeclara.addAll(listaElemObservacionDecla);
		  	  listaElemCabDeclara.addAll(listaElemParticipantesDUA);
		  	  WebUtils.setSessionAttribute(request,"camposModificadosDUA",(!CollectionUtils.isEmpty(listaElemCabDeclara) ? SojoUtil.toJson(listaElemCabDeclara): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosSERIE",(!CollectionUtils.isEmpty(listaElemDetDeclara) ? SojoUtil.toJson(listaElemDetDeclara): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosEquipamiento ",(!CollectionUtils.isEmpty(listaElemEquipamiento) ? SojoUtil.toJson(listaElemEquipamiento): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosDocAsociado",(!CollectionUtils.isEmpty(listaElemDocAsociado) ? SojoUtil.toJson(listaElemDocAsociado): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosCertOrigen",(!CollectionUtils.isEmpty(listaElemCertOrigen) ? SojoUtil.toJson(listaElemCertOrigen): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosRegPrecedente",(!CollectionUtils.isEmpty(listaElemRegPrecedente) ? SojoUtil.toJson(listaElemRegPrecedente): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBDAV",(!CollectionUtils.isEmpty(listaElemFormatoBDAV) ? SojoUtil.toJson(listaElemFormatoBDAV): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBFactura",(!CollectionUtils.isEmpty(listaElemFormatoBFactura) ? SojoUtil.toJson(listaElemFormatoBFactura): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBItemFactura",(!CollectionUtils.isEmpty(listaElemFormatoBItemFactura) ? SojoUtil.toJson(listaElemFormatoBItemFactura): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosSeriesItem",(!CollectionUtils.isEmpty(listaElemSeriesItem) ? SojoUtil.toJson(listaElemSeriesItem): "[]"));
		  	  WebUtils.setSessionAttribute(request,"camposModificadosFacturasSeries",(!CollectionUtils.isEmpty(listaElemFacturasSeries) ? SojoUtil.toJson(listaElemFacturasSeries): "[]"));
		  	//P24-II - Fin

			//inicio P24-II
			  if(declaracionActual.get("COD_REGIMEN").toString().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO) && declaracionActual.get("COD_TIPTRATMERC").toString().equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
					boolean esDonacionRegularizada = true;
					CabAdiImpoConsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("diligencia.rectificacion.cabAdiImpoConsuDef_xa");
		      	    Map<String, Object> mapCabAdiImpoconsu = new HashMap<String, Object>();
			    	mapCabAdiImpoconsu.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
			    	List<Map<String, Object>> selecCabAdiImpoconsu = cabAdiImpoconsuDAO.select(mapCabAdiImpoconsu);
					if(selecCabAdiImpoconsu.isEmpty()){
						esDonacionRegularizada = false;
					}
					else{
						if(selecCabAdiImpoconsu.get(0).get("FEC_REGULARIZACION") != null){ //PAS20165E220200036 - sol SIGESI INC 2016-031776
						if(SunatDateUtils.isDefaultDate(DateUtil.stringToDate(selecCabAdiImpoconsu.get(0).get("FEC_REGULARIZACION").toString(),"yyyy-MM-dd hh:mm:ss.S"))){
							esDonacionRegularizada = false;
						}
					}
						else{
							esDonacionRegularizada = false;
						}
					}
					if (esDonacionRegularizada){
						declaracionActual.put("INDICADOR_DONACION", ConstantesDataCatalogo.IND_DONACION_REGULARIZADA.toUpperCase());
					}
			  }
			//Fin P24-II

	      String fechaFinValorProvisional=declaracionActual.get("FEC_FINPROVSIONAL").toString().trim();
	      String[] fecTerminoTmp = declaracionActual.get("FEC_TERM").toString().split("-");
	      FechaBean fecTerm = new FechaBean(fecTerminoTmp[2].substring(0,2)+"/"+fecTerminoTmp[1]+"/"+fecTerminoTmp[0]);
	      declaracionActual.put("FEC_TERM",fecTerm.getSQLDate() );
	      String[] obtenerddmmyyyyfechaFinValorProvisional = fechaFinValorProvisional.toString().split("-");
	      FechaBean fechaFinValorProvisionalFormateada=new FechaBean(obtenerddmmyyyyfechaFinValorProvisional[2].substring(0,2)+"/"+obtenerddmmyyyyfechaFinValorProvisional[1]+"/"+obtenerddmmyyyyfechaFinValorProvisional[0]);
	      declaracionActual.put("FEC_FINPROVSIONAL", fechaFinValorProvisionalFormateada.getSQLDate());
		  if(tieneVP!=null && tieneVP.get("mesagges")!=null){
			res.addObject("mesagges",tieneVP.get("mesagges"));
		  }
	      res.addObject("list", lisdatoMsj);
	      res.addObject("indValorProvisional", indValorProvisional);
	      WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
	      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
	      WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);

	      res.addObject("esPostLevante",params.get("esPostLevante"));//agregado por PAS20165E220200032
	      res.addObject("declaracion", declaracionActual);
	      res.addObject("diligencia", mapUltimaDiligencia);
	      res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
	      res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      res.addObject("ultimaDiligencia", ultimaDiligencia);

	      res.addObject("modifDilig", modifDilig);
	      return res;
	      }else{
	    	  throw new Exception("Declaraci�n no encontrada");
	      }
	    }
	    catch (ServiceException e)
	    {

	      MensajeBean mensajeBean = new MensajeBean();
	      mensajeBean.setMensajeerror(e.getMessage());
	      return new ModelAndView("PagM", "Error", mensajeBean);
	    }
	    catch (Throwable e)
	    {
	      log.error("error", e);
	      MensajeBean mensajeBean = new MensajeBean();
	      mensajeBean.setMensajeerror("Ocurrio un error al cargar los datos de la dua.");

	      return new ModelAndView("PagM", "Error", mensajeBean);
	    }

 }
    //p14-inicio diligencia de conclusion se hizo un merge con diligencia de despacho.
    /**
     * Carga la revision de conclusion
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return ModelAndView
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public ModelAndView cargarRegRevisionConclusion(HttpServletRequest request, HttpServletResponse response)
        throws Exception
    {
  	  ModelAndView res = new ModelAndView("RegDiligenciaRevision");
    	indValorProvisional = "";

    	try {

        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> params = new HashMap<String, Object>();
    		params.put(
	                 "NUM_DECLARACION",
	                 StringUtils.defaultIfEmpty(
	                                            webRequest.getParameter("hdn_num_declaracion"),
	                                            webRequest.getParameter("txt_num_declaracion")));
    		params.put(
	                 "COD_ADUANA",
	                 StringUtils.defaultIfEmpty(
	                                            webRequest.getParameter("hdn_cod_aduana"),
	                                            webRequest.getParameter("txt_cod_aduana")));
    		params.put(
	                 "ANN_PRESEN",
	                 StringUtils.defaultIfEmpty(
	                                            webRequest.getParameter("hdn_ann_presen"),
	                                            webRequest.getParameter("txt_ann_presen")));
    		params.put(
	                 "COD_REGIMEN",
	                 StringUtils.defaultIfEmpty(
	                                            webRequest.getParameter("hdn_cod_regimen"),
	                                            webRequest.getParameter("sel_cod_regimen")));
        params.put("EN_PROCESO", "0");

    		Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");  // SAU20153D211000706 error deserializar  tipo doc pasaporte
    		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        FechaBean fecActual = new FechaBean();
        UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());
        Map<String, Object> declaracion = this.declaracionService.obtenerDeclaracion(params);
  	  String tipoRegimen = (String) params.get("COD_REGIMEN");

        FechaBean fechaFinProvicional= new FechaBean();
    		/*para la verificacion de que  cuenta con el indicador de valor provisional*/

        String fecha = (new FechaBean(declaracion.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd").getFormatDate("dd/MM/yyyy"));
        fechaFinProvicional.setFecha(fecha,FechaBean.FORMATO_DEFAULT );
        FechaBean fechaDefault= new FechaBean();
        fechaDefault.setFecha("31/12/9999", FechaBean.FORMATO_DEFAULT);

    		boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);

        if (indicadorDUAValorProvActivo && tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10

  		  Map<String, Object> paramsValidador = new HashMap<String, Object>();
  	      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
  	      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
  	      Map<String, Object> tieneValorP = new HashMap<String, Object>();
  	      tieneValorP = this.declaracionService.validarValorProvisional(paramsValidador);

  	      String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
    			String indicadorVFobProvVP = (!CollectionUtils.isEmpty(tieneValorP) && tieneValorP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneValorP.get("indicadorVFobProvValorProvisional"))) ?"SI":"";

    			if(!CollectionUtils.isEmpty(tieneValorP) &&  "SI".equals(indicadorVFobProvVP) && tieneValorP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
  	    	  indValorProvisional = "SI";
  	      	  verificarValorProvisional(params,declaracion);
  	    	  if(tieneValorP.get("mesagges")!=null){
  	    	  	res.addObject("mesagges",tieneValorP.get("mesagges"));
  	    	  }
  	      }
  	      declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
        }

    		String numDocIdentPdf = declaracion.get("NUM_DOCIDENT_PDF") != null ? (String) declaracion.get("NUM_DOCIDENT_PDF") : "";
  			String codLocalAnexo  = declaracion.get("COD_LOCALANEXO")!=null?(String) declaracion.get("COD_LOCALANEXO"):"";
        String direccionLocalAnexo = "";

  			if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf)){
          direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
  				if(SunatStringUtils.isEmpty(direccionLocalAnexo)){ //si no esta registrado el local
            direccionLocalAnexo = "No registrado";
          }
  			}else{
          direccionLocalAnexo = "No registrado";
        }

        declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
  			String numDocIdentPdd = declaracion.get("NUM_DOCIDENT_PDD")!=null?(String) declaracion.get("NUM_DOCIDENT_PDD"):"";
  			String codLocalAnexoDeposito  = declaracion.get("COD_LOCALANEXODEPOSITO")!=null?(String) declaracion.get("COD_LOCALANEXODEPOSITO"):"";
        String direccionLocalAnexoDeposito = "";

  			if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd)){
  				direccionLocalAnexoDeposito = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd,codLocalAnexoDeposito);
  				if(SunatStringUtils.isEmpty(direccionLocalAnexoDeposito)){ //si no esta registrado el local
            direccionLocalAnexoDeposito = "No registrado";
          }
  			}else{
          direccionLocalAnexoDeposito = "No registrado";
        }
        declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);
        Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
        paramDeclaracion.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        paramDeclaracion.put("COD_USUMODIF", bUsuario.getNroRegistro());
        paramDeclaracion.put("FEC_MODIF", fecActual.getTimestamp());
        if (!declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_CONCLU_REVISION))
        {
            declaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_REVISION);
			//amancilla LGA error debido a que jala el estado 11 sin validar la fecha de vigencia
			//por siaca he copiado el codigo de Anita no me juzguen
			//declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_REVISION));
			Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
					SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
			String descripEstado = (catalogoAyudaService.getDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_REVISION, fechadeclaracion).getDesDatacat().toUpperCase());

			declaracion.put("COD_ESTDUA_DESC", descripEstado);
            //fin amancilla copy paste del codigo de Anita.

			paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_REVISION);
			declaracionService.updateDeclaracion(paramDeclaracion);

        }
        	 Map<String, Object> diligencia = new HashMap();
             diligencia.put("IND_INCIDENCIA", webRequest.getParameter("incidencia"));
             diligencia.put("IND_MULTA", webRequest.getParameter("multa"));
             diligencia.put("DES_RESULTADO", webRequest.getParameter("resultado"));
             diligencia.put("COD_TIPDILIGENCIA", Constantes.COD_TIPO_REVISION_CONCLUSION);
             diligencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
             diligencia.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());

             Map<String, Object> paramsDiligencia = new HashMap();
             paramsDiligencia.put("mapCabDiligenciaActual", diligencia);

             diligenciaService.grabarDiligenciaByInicioRevision(paramsDiligencia);



		 /* if (!Constantes.ESTADO_CONCLU_NOTIFICADO.equals(declaracion.get("COD_ESTDUA"))){
  				declaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_REVISION);
				declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_REVISION));
  				paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_REVISION);
  	      }else{
				declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_CONCLU_NOTIFICADO));
				paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_NOTIFICADO);
  	      }*/


        String numCorredoc= request.getParameter("hdn_num_corredoc") != null ? request.getParameter("hdn_num_corredoc") : "";
        String tieneDiligencia="";
        boolean descargaParcial = declaracionService.tieneDescargaParcial(numCorredoc);
        boolean continuacionDespacho=declaracionService.tieneDescargaParcial(numCorredoc);

  	      if(descargaParcial&&continuacionDespacho){
  	    	  tieneDiligencia="SI";
  	      }else{
  	    	  tieneDiligencia="NO";
  	      }
        declaracion.put("tieneDiligencia", tieneDiligencia);

			//if ("08".equals((String) declaracion.get("COD_INDICADOR"))){
				//declaracion.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia("F"));
			//} else {
				//declaracion.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia((String) declaracion.get("COD_CANAL")));
			//}
			String tituloDiligencia = "Conclusi�n de Despacho";
			 /**Inicio de cambios por PAS20165E220200032**/
			if(request.getParameter("hdn_Post_Levante")!=null && request.getParameter("hdn_Post_Levante").toString().equals("1")){
				tituloDiligencia=(String) catalogoAyudaService.getElementoCat(Constantes.CAT_TIPO_DILIGENCIA, COD_TIPO_DILIGENCIA_CONCLUSION).get("des_corta");

			}
			/**Fin de cambios por PAS20165E220200032**/
			declaracion.put("tituloDiligencia",tituloDiligencia);

        ValTratamientoDonacionService valTratamientoDonacion = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");
        valTratamientoDonacion.validarIndicadorDuaenDonacion(declaracion);
        Map<String, Object> declaracionActual = new HashMap<String, Object>();

			if (declaracion != null && declaracion.size() > 0){
          declaracionActual.putAll(declaracion);
        }

        //Map diligencia = new HashMap(); se duplica
        diligencia.put("IND_INCIDENCIA", "");
        diligencia.put("IND_MULTA", "");
        diligencia.put("DES_RESULTADO", "");

			if ( this.isImportadorFrecuente(new Long(numCorredoc)) ) {
				declaracionActual.put("impFrecuente", "Importador Frecuente");
			} else {
				declaracionActual.put("impFrecuente", " ");
			}
			//region amancillaa SDA2-RIN18-PAS20171U220200035
			String etiquetaImportadorOEA = declaracionActual.get("impFrecuente").toString();
			Long numeroCorrelativoDUA = SunatNumberUtils.getLongFromString(declaracion.get("NUM_CORREDOC").toString());
			declaracionActual.put("impFrecuente",etiquetaImportadorOEA.concat(this.obtenerEtiquetaOEA(numeroCorrelativoDUA)));
			//endregion amancillaa
		       //P24-II - Inicio
		    DUA adiDeclara = new DUA();
		    adiDeclara = null;
		    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){
		    	Map<String, Object> paramsFilterDatosAdicionalesDuaByPk = new HashMap<String, Object>();
		    	paramsFilterDatosAdicionalesDuaByPk.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));//usado con obtenerDatosAdicionalesDuaByPk
		    	adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsFilterDatosAdicionalesDuaByPk);
		    }
		    String fecRegulaValProvDDMMYY = "31/12/9999";
		    String fecRegOfiValProvDDMMYY = "31/12/9999";
		    Date fecRegulaValProv = null;
		    Date fecRegOfiValProv = null;
		    if (adiDeclara != null){
					 fecRegulaValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegulaValProv());
					 fecRegulaValProv = adiDeclara.getFecRegulaValProv();
					 fecRegOfiValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegOfiValProv());
					 fecRegOfiValProv = adiDeclara.getFecRegOfiValProv();
		    }
		    declaracionActual.put("FEC_FINPROVSIONAL", declaracion.get("FEC_FINPROVSIONAL"));
		    declaracionActual.put("FECHA_REGVP_DDMMYY", fecRegulaValProvDDMMYY);
		    declaracionActual.put("FECHA_REGOFVP_DDMMYY", fecRegOfiValProvDDMMYY);
		    declaracionActual.put("FECHA_REGVP", fecRegulaValProv);
		    declaracionActual.put("FECHA_REGOFVP", fecRegOfiValProv);
	     	declaracionActual.put("IND_VALOR_PROV", "0");

				Long numeroCorrelativo=new Long(0);
				numeroCorrelativo = new Long(declaracion.get("NUM_CORREDOC").toString());
				RecepcionDocumentosService recepcionDocumentosService = fabricaDeServicios.getService("declaracion.service.RecepcionDocumentosService1");
				Map<String, Object> mapaSolicitudes=new HashMap();
				List<SolicitudRecepcion> solicitudesRecepciones = recepcionDocumentosService.buscarSolicitudPorDeclaracion(numeroCorrelativo, "",false, "");
				mapaSolicitudes = recepcionDocumentosService.listarRecepcionesConsultaDUA(solicitudesRecepciones);
				SolicitudRecepcion solicitudRecepcion = null;
				declaracionActual.put("bandera", 0);
				declaracionActual.put("FEC_RECEP1", null);
				declaracionActual.put("NUMEROCORRELATIVO1", null);
				declaracionActual.put("NUMGED1", null);
				declaracionActual.put("FEC_RECHA1", null);
				declaracionActual.put("FEC_RECEP2", null);
				declaracionActual.put("NUMEROCORRELATIVO2", null);
				declaracionActual.put("NUMGED2", null);
				declaracionActual.put("FEC_RECHA2", null);
				if (!mapaSolicitudes.get("existesolicitudes").toString()
						.equals(ConstantesDeclaracion.NO_EXISTE_SOLICITUD)) {
					if (mapaSolicitudes.get("solicitudPrimeraRecepcion") != null) {
						res.addObject("modulo", "R"); // regularizacion
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudPrimeraRecepcion");
						declaracionActual.put("FEC_RECEP1",
								solicitudRecepcion.getFechaRecepcion());
						declaracionActual.put("NUMEROCORRELATIVO1",
								solicitudRecepcion.getNumeroCorrelativo());
						declaracionActual.put("NUMGED1",
								solicitudRecepcion.getNumGed());
					}
					if (mapaSolicitudes.get("solicitudPrimeraRecepcionRechazada") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudPrimeraRecepcionRechazada");
						declaracionActual.put("FEC_RECEP_RECHA1",
								solicitudRecepcion.getFechaRecepcion());
						declaracionActual.put("FEC_RECHA1",
								solicitudRecepcion.getFechaRechazo());
						declaracionActual.put("NUMEROCORRELATIVORECHA1",
								solicitudRecepcion.getNumeroCorrelativo());
					}
					if (mapaSolicitudes.get("solicitudSegundaRecepcion") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudSegundaRecepcion");
						declaracionActual.put("FEC_RECEP2",
								solicitudRecepcion.getFechaRecepcion());
						declaracionActual.put("NUMEROCORRELATIVO2",
								solicitudRecepcion.getNumeroCorrelativo());
						declaracionActual.put("NUMGED2",
								solicitudRecepcion.getNumGed());
					}
					if (mapaSolicitudes.get("solicitudSegundaRecepcionRechazada") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudSegundaRecepcionRechazada");
						declaracionActual.put("FEC_RECEP_RECHA2",
								solicitudRecepcion.getFechaRecepcion());
						declaracionActual.put("FEC_RECHA2",
								solicitudRecepcion.getFechaRechazo());
						declaracionActual.put("NUMEROCORRELATIVORECHA2",
								solicitudRecepcion.getNumeroCorrelativo());
					}
					declaracionActual.put("bandera", 1);
				} else {
					declaracionActual.put("bandera", 0);
				}

			      if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){
			      	//Inicio RIN10 mpoblete refactor
			      	Map<String, Object> paramsFilterDatosAdicionalesDuaByPk = new HashMap<String, Object>();
			      	paramsFilterDatosAdicionalesDuaByPk.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));//usado con obtenerDatosAdicionalesDuaByPk
			      	//adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsValidador);
			      	adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsFilterDatosAdicionalesDuaByPk);
			      	//Fin RIN10 mpoblete refactor
			      }
			      if (adiDeclara != null){
			      	if (adiDeclara.getFecRegulaValProv()!=null)
			      	{
			  			 fecRegulaValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegulaValProv());
			  			 fecRegulaValProv = adiDeclara.getFecRegulaValProv();
			      	}
			      	if (adiDeclara.getFecRegOfiValProv() != null)
			      	{
			  			 fecRegOfiValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegOfiValProv());
			  			 fecRegOfiValProv = adiDeclara.getFecRegOfiValProv();
			      	}
			      }
			      declaracionActual.put("FECHA_REGVP_DDMMYY", fecRegulaValProvDDMMYY);
			      declaracionActual.put("FECHA_REGOFVP_DDMMYY", fecRegOfiValProvDDMMYY);
			      declaracionActual.put("FECHA_REGVP", fecRegulaValProv);
			      declaracionActual.put("FECHA_REGOFVP", fecRegOfiValProv);

			     // Date fechaLlegada = (Date)declaracion.get("FEC_LLEGADA");
			     // if(SunatDateUtils.isDefaultDate(fechaLlegada)){
			    //	  declaracionActual.put("FEC_LLEGADA", null);
			     // }
			      String codigoPropiedad = (String)declaracionActual.get("COD_PROPIEDAD");
			      String codigoPropiedadDesc =this.catalogoAyudaService.getDescripcionDataCatalogo("63",codigoPropiedad);
			      Map<String, Object> mapaSINI = obtenerDatosLevanteDuaSini(declaracionActual);
			      Map<String, Object> mapaEstadoRegu = determinarEstadoRegularizacion(declaracionActual);
			      declaracionActual.putAll(mapaEstadoRegu);
			      declaracionActual.putAll(mapaSINI);
			      declaracionActual.put("ENDOSE_DESC", codigoPropiedad + " - " + codigoPropiedadDesc);

			      //P24 - PAS20165E220200099
			      ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
			      Observacion observacion = new Observacion();
			      observacion.setNumcorredoc(SunatNumberUtils.toLong(declaracionActual.get("NUM_CORREDOC")));
			      observacion.setCodtipobserva("01"); //solo las observaciones de datos generales, si se requiere para otro formulario se deber� filtrar por JSP y colocar null en tipo de obs
			      List<Observacion> listaObservaciones = observacionService.buscarObservacion(observacion);
			      if(CollectionUtils.isEmpty(listaObservaciones)){
			    	  declaracionActual.put("OBSERVACIONES", null);
			    	  declaracionActual.put("CANT_OBS", 1);
			      }else{
			    	  String descCodObs;
			    	  for(Observacion obs : listaObservaciones){
			    		  descCodObs =this.catalogoAyudaService.getDescripcionDataCatalogo("369",obs.getCodtipobserva());
			    		  obs.setCodtipobserva(obs.getCodtipobserva().concat(" - ").concat((descCodObs!=null?descCodObs:"")));
			    	  }
			    	  declaracionActual.put("OBSERVACIONES", listaObservaciones);
			    	  declaracionActual.put("CANT_OBS", listaObservaciones.size());
			      }

			      String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613

			      String flag = "";
				  flag = WUtil.getParam(request,"hdn_flag");
				  if(flag==""){
				  	flag = "-1";
				  }
			      Map<String, Object> paramsValidador = new HashMap<String, Object>();
			      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
			      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
			      Map<String, Object> tieneVP = valorProvisional(request,declaracion,params, tipoRegimen);
			      if(indicadorDUAValorProvActivo){
			      //Fin RIN10 mpoblete refactor
			      if(flag!="-1" && flag.equals("1")){
			      	  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
			     		    String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
			      	     	//verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
			      	  	declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
			      	  	paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);


			     		    //Inicio RIN10 BUG 22611,22613
			     		    if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
			     		    	verificarValorProvisional(params,declaracion);
			     		    	indicadorVFobProvVP = "SI";
			     		    }
			     		    //Fin RIN10 BUG 22611,22613
			      	  }
				    }else if(flag!="-1" ||flag.equals("2")){
				      	 if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
					             tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
					             //Inicio RIN10 BUG 22611,22613
					             if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
					            	 indicadorVFobProvVP = "SI";
					     		 }
					             //Fin RIN10 BUG 22611,22613
				      	 }
				    }
			      }//RIN10 mpoblete refactor

			      if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
			     	//Fin RIN10 BUG 22611,22613
			  		declaracionActual.put("IND_VALOR_PROV", "1");
			  	  }else{
			  		declaracionActual.put("IND_VALOR_PROV", "0");
			  	  }

			      String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracionActual, DEFAULT_TIPO_DOC);
			      WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);


			   	  if(declaracion.get("FEC_AUTLEVANTE")!=null && !SunatDateUtils.isDefaultDate((Date)declaracion.get("FEC_AUTLEVANTE"))){
			   		  declaracionActual.put("AUTLEVANTE_DESC","LEVANTE AUTORIZADO");
			   	  }else{
			   		  declaracionActual.put("AUTLEVANTE_DESC",null);
			   	  }

			      String FEC_FINPROVSIONAL_DDMMYY = null;
			  	  if (declaracion.get("FEC_FINPROVSIONAL")!=null){
			  		FEC_FINPROVSIONAL_DDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(declaracion.get("FEC_FINPROVSIONAL"));
			  	  }
			  	  declaracionActual.put("FEC_FINPROVSIONAL_DDMMYY", FEC_FINPROVSIONAL_DDMMYY);

				//P24-II - Fin
			  	//P24-II - Inicio

			  	  String numCorreDoc = numeroCorrelativo.toString();
			  	  Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
			  	  List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);
			  	  List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);
			  	  List<Map<String, Object>> listaElemEquipamiento = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_EQUIPAMIENTO);
			  	  List<Map<String, Object>> listaElemDocAsociado = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCAUT_ASOCIADO);
			  	  List<Map<String, Object>> listaElemDetAut =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_AUTORIZACION);
			  	  List<Map<String, Object>> listaElemCertOrigen =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_CERTIORIGEN);
			  	  List<Map<String, Object>> listaElemRegPrecedente =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCUPRECE_DUA);
			  	  List<Map<String, Object>> listaElemFormatoBDAV =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMB_PROVEEDOR);
			  	  List<Map<String, Object>> listaElemFormatoBFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);
			  	  List<Map<String, Object>> listaElemFormatoBItemFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_ITEM_FACTURA);
			  	  List<Map<String, Object>> listaElemSeriesItem =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_SERIES_ITEM);
			  	  List<Map<String, Object>> listaElemConvenioSerie =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CONVENIO_SERIE);
			  	  List<Map<String, Object>> listaElemFacturasSeries =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU);
			  	  List<Map<String, Object>> listaElemObservacion =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);
			  	  List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
			  	  if (!CollectionUtils.isEmpty(listaElemConvenioSerie)){
			  		  listaElemDetDeclara.addAll(listaElemConvenioSerie);
			  	  }
			  	  if (!CollectionUtils.isEmpty(listaElemDocAsociado)){
			  		  listaElemDetDeclara.addAll(listaElemDetAut);
			  	  }
			  	  List<Map<String, Object>> listaElemObservacionDecla       = new ArrayList();
			  	  if (!CollectionUtils.isEmpty(listaElemObservacion)){
			  		  for (Map<String, Object> mapObs : listaElemObservacion){
			  			  String codTipObs = mapObs.get("PK").toString();
			  			  if(codTipObs.startsWith("01")){
			  				  listaElemObservacionDecla.add(mapObs);
			  			  }
			  		  }
			  	  }

			  	  listaElemCabDeclara.addAll(listaElemObservacionDecla);
			  	  listaElemCabDeclara.addAll(listaElemParticipantesDUA);
			  	  WebUtils.setSessionAttribute(request,"camposModificadosDUA",(!CollectionUtils.isEmpty(listaElemCabDeclara) ? SojoUtil.toJson(listaElemCabDeclara): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosSERIE",(!CollectionUtils.isEmpty(listaElemDetDeclara) ? SojoUtil.toJson(listaElemDetDeclara): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosEquipamiento ",(!CollectionUtils.isEmpty(listaElemEquipamiento) ? SojoUtil.toJson(listaElemEquipamiento): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosDocAsociado",(!CollectionUtils.isEmpty(listaElemDocAsociado) ? SojoUtil.toJson(listaElemDocAsociado): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosCertOrigen",(!CollectionUtils.isEmpty(listaElemCertOrigen) ? SojoUtil.toJson(listaElemCertOrigen): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosRegPrecedente",(!CollectionUtils.isEmpty(listaElemRegPrecedente) ? SojoUtil.toJson(listaElemRegPrecedente): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBDAV",(!CollectionUtils.isEmpty(listaElemFormatoBDAV) ? SojoUtil.toJson(listaElemFormatoBDAV): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBFactura",(!CollectionUtils.isEmpty(listaElemFormatoBFactura) ? SojoUtil.toJson(listaElemFormatoBFactura): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosFormatoBItemFactura",(!CollectionUtils.isEmpty(listaElemFormatoBItemFactura) ? SojoUtil.toJson(listaElemFormatoBItemFactura): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosSeriesItem",(!CollectionUtils.isEmpty(listaElemSeriesItem) ? SojoUtil.toJson(listaElemSeriesItem): "[]"));
			  	  WebUtils.setSessionAttribute(request,"camposModificadosFacturasSeries",(!CollectionUtils.isEmpty(listaElemFacturasSeries) ? SojoUtil.toJson(listaElemFacturasSeries): "[]"));
			  	//P24-II - Fin

					//inicio P24-II
				  if(declaracionActual.get("COD_REGIMEN").toString().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO) && declaracionActual.get("COD_TIPTRATMERC").toString().equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
						boolean esDonacionRegularizada = true;
						CabAdiImpoConsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("diligencia.rectificacion.cabAdiImpoConsuDef_xa");
			      	    Map<String, Object> mapCabAdiImpoconsu = new HashMap<String, Object>();
				    	mapCabAdiImpoconsu.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
				    	List<Map<String, Object>> selecCabAdiImpoconsu = cabAdiImpoconsuDAO.select(mapCabAdiImpoconsu);
						if(selecCabAdiImpoconsu.isEmpty()){
							esDonacionRegularizada = false;
						}
						else{
							if(selecCabAdiImpoconsu.get(0).get("FEC_REGULARIZACION") != null){ //PAS20165E220200036 - sol SIGESI INC 2016-031776
							if(SunatDateUtils.isDefaultDate(DateUtil.stringToDate(selecCabAdiImpoconsu.get(0).get("FEC_REGULARIZACION").toString(),"yyyy-MM-dd hh:mm:ss.S"))){
								esDonacionRegularizada = false;
							}
						}
							else{
								esDonacionRegularizada = false;
							}
						}
						if (esDonacionRegularizada){
							declaracionActual.put("INDICADOR_DONACION", ConstantesDataCatalogo.IND_DONACION_REGULARIZADA.toUpperCase());
						}
				  }
				//Fin P24-II


			// Guardamos en sesion los datos de la declaracion e invocamos el jsp correspondiente
        WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
        WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);

        String fechaFinValorProvisional=declaracionActual.get("FEC_FINPROVSIONAL").toString().trim();
        String[] obtenerddmmyyyyfechaFinValorProvisional = fechaFinValorProvisional.toString().split("-");
        FechaBean fechaFinValorProvisionalFormateada=new FechaBean(obtenerddmmyyyyfechaFinValorProvisional[2].substring(0,2)+"/"+obtenerddmmyyyyfechaFinValorProvisional[1]+"/"+obtenerddmmyyyyfechaFinValorProvisional[0]);
        declaracionActual.put("FEC_FINPROVSIONAL", fechaFinValorProvisionalFormateada.getSQLDate());

			   // SAU20153D211000706 error deserializar  tipo doc pasaporte
		      if (declaracionActual.get("NOM_RAZONSOCIAL_PIM").equals(null)||declaracionActual.get("NOM_RAZONSOCIAL_PIM").equals(""))
		      {
		    	  declaracionActual.put("NOM_RAZONSOCIAL_PIM", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM"));
		      }


        res.addObject("declaracion", declaracionActual);
			res.addObject("declaracionP14", declaracionActual);//para temas de  compatibilidad  de mapa y objeto
        res.addObject("diligencia", declaracionActual);
        res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
        res.addObject("esPostLevante", request.getParameter("hdn_Post_Levante"));

        List lstRevFisica = catalogoAyudaService.getElementosCat(ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO);
        List lstNuevaRevFisica = new ArrayList();
			if (!CollectionUtils.isEmpty(lstRevFisica)) {
          Iterator i1 = lstRevFisica.iterator();
				// Se adciona tipo de asignacion de especialista que no se registran en la revision
				while (i1.hasNext()){
            Map<String, Object> mapa = (Map<String, Object>) i1.next();
            Map<String, Object> mapacatalogo = new HashMap();
            mapacatalogo.put("cod_datacat", (String)mapa.get("cod_datacat"));
            mapacatalogo.put("des_corta", (String) mapa.get("cod_datacat") + " " + (String) mapa.get("des_corta"));
  	      String cod_datacat = StringUtils.trimToEmpty( MapUtils.getMapValor(mapa, "cod_datacat"));

  	      if(declaracion.get("COD_CANAL").equals(Constantes.CANAL_ROJO) && tieneDiligencia.equals("NO"))	{
						if (ArrayUtils.contains(new String[] {
								ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_INCONCLUSO,
  	      					ConstantesDataCatalogo.DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
  	             		  ConstantesDataCatalogo.DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
								ConstantesDataCatalogo.INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
								ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DE_OFICIO}, cod_datacat)){
  	           	         lstNuevaRevFisica.add(mapacatalogo);
  	               }

  	      	}else if(declaracion.get("COD_CANAL").equals(Constantes.CANAL_NARANJA)) {
						if (ArrayUtils.contains(new String[] {
								ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_INCONCLUSO,
  	             		  ConstantesDataCatalogo.DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
  	             		  ConstantesDataCatalogo.DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
  	             		  ConstantesDataCatalogo.INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
  	             		  ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL,
  	             		  ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_CON_CONTINUACION }, cod_datacat)){
							lstNuevaRevFisica.add(mapacatalogo);
						}

						//ggranados 179
						if (Constantes.IND_CAMBIO_REC_FISICO.equals((String) declaracion.get("COD_INDICADOR"))){
							if(ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DE_OFICIO.equals(cod_datacat)){
  	           	         lstNuevaRevFisica.add(mapacatalogo);
  	               }
						}

          }
          }
        }

        Ordenador.sortDesc(lstNuevaRevFisica, "cod_datacat", Ordenador.ASC);
        res.addObject("lstMotivoRevFisico", lstNuevaRevFisica);
        res.addObject("list", lisdatoMsj);
  	  res.addObject("indValorProvisional", indValorProvisional);
        return res;
		} catch (ServiceException e) {
        MensajeBean mensajeBean = new MensajeBean();
        mensajeBean.setMensajeerror(e.getMessage());
        return new ModelAndView("PagM", "Error", mensajeBean);
		} catch (Throwable e) {
        log.error("error", e);
        MensajeBean mensajeBean = new MensajeBean();
        mensajeBean.setMensajeerror("Ocurrio un error al realizar la diligencia en Revision");

        return new ModelAndView("PagM", "Error", mensajeBean);
      }
  }
    //p14-fin diligencia de conclusion

  /**
   * M�todo que realiza las validaciones de la declaraci�n para el proceso de
   * conclusi�n
   *
   * @param declaracion
   * @return String
   * @author gbecerra
   * @throws ServiceException
   */
  public String validarDeclaracion(Map<String, Object> declaracion)
  {
    String msjValid = "";

    List<Map<String, Object>> lstSol = (List) declaracion.get("lstSol");
    if (lstSol != null && lstSol.size() > 0)
    {
      for (Map<String, Object> mapa : lstSol)
      {
        if (mapa.get("COD_CATESTADO").equals(Constantes.CAT_ESTADO_SOLICITUD_RECTIFICACION))
          msjValid += "La declaracion tiene solicitud rectificacion pendiente de evaluacion. \n";
        else
          msjValid += "La declaracion tiene solicitud regularizacion pendiente de evaluacion. \n";
      }
    }
    if (declaracion.get("tieneDudaRazonable") != null
        && ((Boolean) declaracion.get("tieneDudaRazonable")).booleanValue())
    {
      msjValid += "La declaracion tiene duda razonable pendiente de evaluacion. \n";
    }
    if (declaracion.get("lstTabBolQuimSC") != null && ((ArrayList) declaracion.get("lstTabBolQuimSC")).size() > 0)
    {
      msjValid += "La declaracion tiene boletin quimico sin concluir. \n";
    }
    if (declaracion.get("lstCabActasSC") != null && ((ArrayList) declaracion.get("lstCabActasSC")).size() > 0)
    {
      msjValid += "La declaracion tiene actas sin concluir. \n";
    }
    return msjValid;
  }

  /**
   * Realiza las validaciones desde la revision para ir al proceso de conclusi�n
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @author gbecerra
   * @throws Exception
   */
  public ModelAndView validaFromRevisionToProceso(HttpServletRequest request, HttpServletResponse response)
  {
    ModelAndView res = new ModelAndView(this.jsonView);
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      params.put("codigoFuncionario", bUsuario.getNroRegistro());
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
      params.put("caduana", soporteService.obtenerAduana(request));

      Map<String, Object> declaracion = declaracionService.validarDeclaParaConclucionDespacho(params);

      if(MapUtils.esValorMapaNuloOVacio(declaracion, "error"))
      {
        res.addObject("res", validarDeclaracion(declaracion));
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror((String) declaracion.get("error"));
        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
        log.error("ConclusionDespachoController validaFromRevisionToProceso - ERROR : " + rBean.getMensajeerror());
        res = new ModelAndView("PagM", "beanM", rBean);
      }

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error(this.toString() + " validaFromRevisionToProceso - ERROR : " + e.getMessage());
      res.addObject("beanM", rBean);
    }
    return res;
  }

  /**
   * Realiza las validaciones para ir al proceso de conclusi�n
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return ModelAndView
   * @author gbecerra
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public ModelAndView revisionToProceso(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {
    ModelAndView modelView = null;
    Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
    if (Constantes.ESTADO_CONCLU_REVISION.equals(codigoEstadoDUA))
    {
      modelView = this.cargarRegConclusionDespacho(request, response);
    }
    else
    {
      modelView = this.cargarRegRevisionConclusion(request, response);
    }
    return modelView;
  }

  /**
   * 24/02/2010: Metodo para validar que pueda realizar la ampliacion de la
   * fecha de conclusi�n.
   *
   * @param request y response
   * @return ModelAndView
   * @exception PagM
   * @see F2ingresoDiligencia20091124.doc CUR 11.03 Ampliar plazo de Conclusi�n
   *      de Despacho
   */
  public ModelAndView validarAmpliacionConclusion(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {
    if (log.isInfoEnabled())
      log.info("INICIO validarAmpliacionConclusion");
    ModelAndView modelView = new ModelAndView(this.jsonView);
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
      Map<String, Object> mapDeclara = diligenciaService.tieneConclusionEnProceso(params);
      modelView.addObject("mapDeclara", mapDeclara);
      if (!mapDeclara.get("FEC_DECLARACION").equals("NO_FOUND"))
      {
        modelView.addObject("lstMotivosAmpliacion",
            catalogoAyudaService.getElementosCat(Constantes.CAT_MOTIVO_AMPLIACION));
        Map<String, Object> mapAmpliacion = diligenciaService.tieneAmpliacionPlazo(params);
        modelView.addObject("mapAmpliacion", mapAmpliacion);
        modelView.addObject("codCatalogo", Constantes.CAT_MOTIVO_AMPLIACION);
      }

      if (log.isDebugEnabled())
        log.info("params = " + params);
      return modelView;
    }
    catch (Exception e)
    {
      e.printStackTrace();
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error(this.toString().concat(" validarDeclaracionSolicitud - ERROR : ").concat(e.getMessage()));
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }

  /**
   * 25/02/2010: Metodo grabar la ampliaci�n del plazo de conclusi�n.
   *
   * @param request y response
   * @return ModelAndView
   * @exception PagM
   * @see F2ingresoDiligencia20091124.doc CUR 11.03 Ampliar plazo de Conclusi�n
   *      de Despacho
   */
  public ModelAndView grabarAmpliacionConclusion(HttpServletRequest request, HttpServletResponse response)
      throws Exception
  {
    if (log.isInfoEnabled())
      log.info("INICIO grabarAmpliacionConclusion");
    ModelAndView modelView = new ModelAndView(this.jsonView);
    try
    {
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      FechaBean fecActual = new FechaBean();

      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
      params.put("TIPO_OPERACION", request.getParameter("tipo_operacion_ampl"));
      params.put("COD_TIPDILIGENCIA", Constantes.SOLI_AMPLI_PLAZO);
      params.put("COD_CATALOGO", request.getParameter("cod_catalogo_ampl"));
      params.put("COD_MOTIVO", request.getParameter("selMotivoAmpliacion"));
      params.put("DES_RESULTADO", request.getParameter("hdn_des_respuesta_ampl"));
      params.put("FEC_CONCLUSION",
          new FechaBean(request.getParameter("new_fec_conclusion"), "yyyy-MM-dd").getTimestamp());
      params.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
      params.put("FEC_DILIGENCIA", fecActual.getTimestamp());
      params.put("COD_USUREGIS", bUsuario.getNroRegistro());
      params.put("FEC_REGIS", fecActual.getTimestamp());
      params.put("COD_USUMODIF", bUsuario.getNroRegistro());
      params.put("FEC_MODIF", fecActual.getTimestamp());

      diligenciaService.grabarAmpliacionPlazo(params);
      return modelView;
    }
    catch (Exception e)
    {
      e.printStackTrace();
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error(this.toString().concat(" validarDeclaracionSolicitud - ERROR : ").concat(e.getMessage()));
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }



  /**
   * Metodo que permite obtener los datos de los catalogos a usar dentro de la
   * edicion de la declaracion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView declaracionEnProceso(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

    // se actualiza los datos iniciales de la serieOrigen

    HttpSession session = request.getSession();
    Map<String, String> params = new HashMap<String, String>();
    params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
    params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString());
    params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString());
    params.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
    params.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
    params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());
    params.put("acceso", "");

    request.setAttribute("params", params);
    // Para Declaracion en Proceso se filtran las Series
    params.put("estadoDUA", declaracion.get("COD_ESTDUA").toString());


    List lstDetDeclara =  (List) WebUtils.getSessionAttribute(request, "lstDetDeclara");
    if(lstDetDeclara == null || lstDetDeclara.isEmpty()){
    	lstDetDeclara = serieService.obtenerListadoSeries(params);
    	session.setAttribute("lstDetDeclara", lstDetDeclara);
    }

    ModelAndView res = new ModelAndView("RegDiligenciaConclusion", "declaracion", declaracion);
    res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
    res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

    /*RIN13FSW-INICIO*/
    List<String> lstObservacionesSeries = (List<String>) WebUtils.getSessionAttribute(request,"observacionesSeries");
    if(lstObservacionesSeries != null && lstObservacionesSeries.size()>0){
    	 res.addObject("observacionesSeries",lstObservacionesSeries);
       }
    /*RIN13FSW-FIN*/
    return res;

  }

  /**
   * lalberti : Incidencias
   */

  /* amancilla Rin13FSW se cambia para que no ejecuto varias veces el preliquida no tiene sentido dao que ya se ejecuto*/
  private void setearIncidenciasAutomaticas(HttpServletRequest request) throws Exception {

	  IncidenciaService incidenciaService =  fabricaDeServicios.getService("diligencia.ingreso.incidenciaService");

      List<RegistroIncidenciaForm> lstIncidenciasAutomaticas = new ArrayList<RegistroIncidenciaForm>();

      Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      boolean tieneIncidencia = declaracionActual.get("tieneIncTrib")!=null && "S".equals(declaracionActual.get("tieneIncTrib").toString())?true:false;

          Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");

          MovCabliqdilig movCabliqdilig = (MovCabliqdilig) declaracionActual.get("movCabliqdilig");
          List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
          List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
          List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
          List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");

          HttpSession session = request.getSession();

          if (CollectionUtils.isEmpty(lstSeriesItemActual)){
          	 Map<String, Object> param = new HashMap<String, Object>();
          	  Long numCorredoc = new Long(declaracionActual.get("NUM_CORREDOC").toString());
               param.put("NUM_CORREDOC", numCorredoc);

               lstSeriesItem = serieService.obtenerSeriesItem(param);
               lstSeriesItemActual = Utilidades.copiarLista((List)lstSeriesItem);
          }

          // validamos los datos principales
          if (!org.springframework.util.CollectionUtils.isEmpty(declaracionActual)
          		&& !CollectionUtils.isEmpty(lstDetDeclaraActual)) {

              Map<String, Object> params = new HashMap<String, Object>();
              params.put("declaracionActual", declaracionActual);
              params.put("declaracion", declaracion);
              params.put("lstDetDeclaraActual", lstDetDeclaraActual);
              params.put("lstDetDeclaraAnt", lstDetDeclara);
              params.put("lstSeriesItemActual", lstSeriesItemActual);
              params.put("lstSeriesItem", lstSeriesItem);
              params.put("movCabliqdilig", movCabliqdilig);
              params.put("tieneIncidencia", tieneIncidencia);

          // crear una nueva lista agrupada especial para la vista
          List<Incidencia> incidencias  = incidenciaService.obtenerIncidenciaAutomatica(params);
          //esto es lo que se debe grabar en session
          WebUtils.setSessionAttribute(request, "incidenciasAuto", incidencias);

      }
    }

  private List<Incidencia> obtenerIncidencias (HttpServletRequest request) throws Exception
  {
    List<Incidencia> incidencias = new ArrayList();
    List<Incidencia> incidenciasA = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasAuto");
    List<Incidencia> incidenciasM = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasManu");

      //se ejecuta solo si no se ejecuto la priemra vez
    if(CollectionUtils.isEmpty(incidenciasA)){
	  this.setearIncidenciasAutomaticas(request);
    }

      incidenciasA = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasAuto");

    if(!CollectionUtils.isEmpty(incidenciasA)) {
      incidencias.addAll(incidenciasA);
    }
    if(!CollectionUtils.isEmpty(incidenciasM)) {
      incidencias.addAll(incidenciasM);
    }

    return incidencias;
  }

  public ModelAndView verificarIncidencias(HttpServletRequest request,HttpServletResponse response) throws ServiceException{
	   ModelAndView res = new ModelAndView(this.jsonView);
	   List<Incidencia> listado =new ArrayList<Incidencia>();
	   res.addObject("success", false);
	try {
		listado = this.obtenerIncidencias(request);
	} catch (Exception e) {

	}
	   if(listado.size()>0){
		   res.addObject("success", true);
	   }
	   return res;
  }

  /* fin incidencias */
  /* Multas   */
  /**
   * Metodo que permite realizar la liquidacion de la declaracion.
   * RIN13 SWF
   */
  public ModelAndView liquidaDeclaracion(HttpServletRequest request , HttpServletResponse response) throws Exception
  {

		ModelAndView res = new ModelAndView(this.jsonView);
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    Map resulPreliq = new HashMap();
	    resulPreliq.put("ERROR", "NO");
	    Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	    List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

	    if (CollectionUtils.isEmpty(listDetDeclara))
	    {
	  	Map<String, String> params = new HashMap<String, String>();
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      params.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
	      params.put("num_declaracion", declaracionActual.get("NUM_DECLARACION").toString());
	      params.put("cod_aduana", declaracionActual.get("COD_ADUANA").toString());
	      params.put("ann_presen", declaracionActual.get("ANN_PRESEN").toString());
	      params.put("cod_regimen", declaracionActual.get("COD_REGIMEN").toString());

	      listDetDeclara = serieService.obtenerListadoSeries(params);

	        //limpia la variable de session
	        WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
	        WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
	        List<Map<String, Object>> lstSerieOld= new ArrayList<Map<String, Object>>();
	        lstSerieOld.addAll(Utilidades.copiarLista((List)listDetDeclara));

	        List<Map<String, Object>> lstSerieNew= new ArrayList<Map<String, Object>>();
	        lstSerieNew.addAll(Utilidades.copiarLista((List)listDetDeclara));

	        WebUtils.setSessionAttribute(request, "lstDetDeclara", lstSerieOld);
	        WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSerieNew);
	        listDetDeclara = new ArrayList(lstSerieOld);

	        if (CollectionUtils.isEmpty(listDetDeclara))
	        {
	        	log.debug("ERROR-No se han cargado las series");
	          //return rspta;
	        }
	    }

	    List listParticipanteDoc = new ArrayList();
	    // Obtenemos de cabDeclara (importador y agente)
		  if (declaracionActual.get("COD_TIPDOC_PIM") != null){
		      Map mapImport = new HashMap();
		      mapImport.put("COD_TIPPARTIC", "45");
		      mapImport.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
		      mapImport.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
		      listParticipanteDoc.add(mapImport);
		  }
		  if (declaracionActual.get("NUM_DOCIDENT_PDE") != null){
		      Map mapAgent = new HashMap();
		      mapAgent.put("COD_TIPPARTIC", "41");
		      mapAgent.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
		      mapAgent.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
		      listParticipanteDoc.add(mapAgent);
		  }

		  if (listParticipanteDoc.isEmpty()){
		      log.debug("ERROR-No existe lista de Participantes");
		  }

		  UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

		  List listConvenioSerie = new ArrayList();
		  List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
		  Map<String, Object> serieEliminada = null;
		  for (Map<String, Object> detDeclaraMap : listDetDeclara){
		      if ("1".equals(detDeclaraMap.get("IND_DEL"))){
		          serieEliminada = detDeclaraMap;
		          listaSerieEliminada.add(serieEliminada);
		          continue;
		      }
		      if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie"))){
		          detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
		      }
		      if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
		      {
		          List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
		          for (int i = 0; i < lstConvenioSerie.size(); i++)
		          {
		              HashMap convenio = (HashMap) lstConvenioSerie.get(i);
		              if (!"1".equals(convenio.get("IND_DEL")))
		              {
		                  // en la rectificacion no se agrega el ind_eliminado a los nuevos
		                  // convenios
		                  listConvenioSerie.add(convenio);
		              }
		          }
		      }
		  }
		  for (Map<String, Object> mapEliminar : listaSerieEliminada)
		  {
		      listDetDeclara.remove(mapEliminar);
		  }

		  List listDocupreceDua = (ArrayList) WebUtils.getSessionAttribute(request, "lstDocuPreceDuaActual");
		    HashMap paramDocLiq = new HashMap();
		    paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
		    paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
		    paramDocLiq.put("cabDeclara", declaracionActual);
		    paramDocLiq.put("listDetDeclara", listDetDeclara);
		    paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
		    paramDocLiq.put("listConvenioSerie", listConvenioSerie);
		    paramDocLiq.put("listDocupreceDua", listDocupreceDua);
		    paramDocLiq.put("listaSerieEliminada", listaSerieEliminada);
		    paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
		    LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
		    resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);

		    if ("NO".equals(resulPreliq.get("ERROR"))) {

			    declaracionActual.put("caduana", soporteService.obtenerAduana(request));
			    Map parametros = new HashMap();
			    declaracionActual.put("resulPreliq", resulPreliq);
			    parametros.put("mapCabDeclaraActual", declaracionActual);
			      parametros.put("lstMultaDua", WebUtils.getSessionAttribute(request, "lstMultas"));
			    liquidaDeclaracionService.liquidaDiligencia(parametros);
			    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

		    }

	    return res;
  }
  /* fin multas */
  /**
   * Metodo que da inicio a la grabacion de Diligencia de Conclusion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView grabarDiligenciaConclusion (HttpServletRequest request, HttpServletResponse response) throws Exception{

	ModelAndView res = new ModelAndView(this.jsonView);
    try{

      ServletWebRequest webRequest = new ServletWebRequest(request);
      Map<String, Object> diligencia = new HashMap();
      Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      String tipDilig = WebUtils.getSessionAttribute(request, "tipoDiligencia").toString().trim();
      String ingresoPostLevante = request.getParameter("ingresaPostLevante")!=null?request.getParameter("ingresaPostLevante").toString():" ";//adicionado por PAS20165E220200032
      //Multas
      Map<String, Object> generacionLCMulta = new HashMap<String, Object>();
      generacionLCMulta.put("generarLC003", WebUtils.getSessionAttribute(request, "generarLC003"));
      generacionLCMulta.put("generarLCMulta", WebUtils.getSessionAttribute(request, "generarLCMulta"));
      generacionLCMulta.put("datosMulta", WebUtils.getSessionAttribute(request, "datosMulta"));
      generacionLCMulta.put("lstAutoliquidacionesMulta", WebUtils.getSessionAttribute(request, "lstAutoliquidacionesMulta"));

      UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

      String numCorreDoc =   declaracionActual.get("NUM_CORREDOC")!=null?declaracionActual.get("NUM_CORREDOC").toString():"";
      String mensajeExiteDiligencia = validaExisteDiligencia(numCorreDoc, tipDilig);

      if(!StringUtils.isEmpty(mensajeExiteDiligencia)){
	        List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
	        res.addObject("recOk", false);
	        res.addObject("mensajeRespuesta", mensajeExiteDiligencia);
	        res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
	        return res;
      }

      Map<String, Object> lstValidacion = new HashMap<String, Object>();
	  List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
	  Map<String, Object> resultado = new HashMap<String, Object>();
	  Map declaracion = (HashMap) WebUtils.getSessionAttribute(request,"mapCabDeclara");
	  List<Liquida> lstliquidaMarcadas = (List<Liquida>) WebUtils.getSessionAttribute(request, "lstliquidaMarcadas");

		//Facturas
        List lstFacturasSerieBD = new ArrayList();
        if (WebUtils.getSessionAttribute(request, "lstFacturasSerie") == null)
        {
          HashMap<String, Object> mapaNumCorreDoc = new HashMap<String, Object>();
          mapaNumCorreDoc.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
          lstFacturasSerieBD = formatoValorService.obtenerFacturasSerie(mapaNumCorreDoc);
          WebUtils.setSessionAttribute(request, "lstFacturasSerie", lstFacturasSerieBD);
        }

        if (WebUtils.getSessionAttribute(request, "lstFacturasSerieActual") == null
            && (lstFacturasSerieBD != null && lstFacturasSerieBD.size() > 0)){
          WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieBD);
        }

        declaracionActual.put("lstFacturasSerieAnt", (ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerie"));
        declaracionActual.put("lstFacturasSerieActual",(ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerieActual"));


        List<Map<String, Object>> multas = WebUtils.getSessionAttribute(request, "lstMultaDua")==null?new ArrayList<Map<String, Object>>():(List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstMultaDua");
        if(!multas.isEmpty()){
        	for(Map<String,Object> multa:multas){
       			multa.put("NUM_CORREDOC",numCorreDoc);
       			multa.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_CONCLUSION);
        	}
        }

        List<Map<String, Object>> lstAutoliquidacionesMulta = WebUtils.getSessionAttribute(request, "lstAutoliquidacionesMulta")==null?new ArrayList<Map<String, Object>>():(List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstAutoliquidacionesMulta");


		List<Incidencia>  lstIncidencias = obtenerIncidencias(request);

		//Datos de la Diligencia
		diligencia.put("IND_INCIDENCIA", lstIncidencias == null|| lstIncidencias.isEmpty() ? "N" : "S");
		diligencia.put("DES_RESULTADO",	webRequest.getParameter("resultado"));
		diligencia.put("COD_TIPDILIGENCIA", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
		diligencia.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
		diligencia.put("FEC_DILIGENCIA", new FechaBean().getTimestamp());

		//Resolucion de la multa
		diligencia.put("IND_MULTA",	multas == null || multas.isEmpty() ? "N" : "S");
		ResCabBean resolucionMulta=(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionMulta");
		boolean isResolucionMulta = resolucionMulta!=null ? true:false;
		log.debug("isResolucionMulta:" + isResolucionMulta );
		if (diligencia.get("IND_MULTA").equals("S")  && isResolucionMulta) {
			//Grabando la Resoluci�n de Determinaci�n de Multas para la Diligencia.
				diligencia.put("COD_TIPDOCDILI", resolucionMulta.getCodTipDocDili().getCodTipDocSustento());
				diligencia.put("COD_ADUADOCSUST",resolucionMulta.getCodAduanaDocSust());
				diligencia.put("COD_TIPDOCSUST", resolucionMulta.getCodTipDocSust());
				diligencia.put("COD_AREADOCSUST",resolucionMulta.getCodAreaDocSust());
				diligencia.put("ANN_DOCSUST",    resolucionMulta.getAnnDocSust());
				diligencia.put("NUM_DOCSUST",    resolucionMulta.getNumDocSust());
			}



		//AMANCILLA
		Map<String, Object> generacionLCTributo = new HashMap<String, Object>();
		generacionLCTributo.put("generarLC010", WebUtils.getSessionAttribute(request, "generarLC010"));
		generacionLCTributo.put("resolucionTributo", WebUtils.getSessionAttribute(request, "resolucionTributo"));
		//generacionLCTributo.put("tributosLiquidaciones", WebUtils.getSessionAttribute(request,"tributosLiquidaciones"));//setean los valores segun datacatalogo T32
		generacionLCTributo.put("totalTributosLiquidaciones", WebUtils.getSessionAttribute(request,"totalTributosLiquidaciones"));
		Map<String, Object> tributosLiquidaciones = new HashMap<String, Object>();
		HashMap<String,Object> tributosForDetLiquida = (HashMap<String,Object>) WebUtils.getSessionAttribute(request,"tributosLiquidaciones");
		if(tributosForDetLiquida!=null){
		    tributosLiquidaciones.put("ADVALOREM", tributosForDetLiquida.get("0001").toString());
			tributosLiquidaciones.put("IGV",tributosForDetLiquida.get("0002").toString());
			tributosLiquidaciones.put("ISC",tributosForDetLiquida.get("0003").toString());
			tributosLiquidaciones.put("IPM",tributosForDetLiquida.get("0014").toString());
			tributosLiquidaciones.put("DERECHO ESPECIFICO", tributosForDetLiquida.get("0021").toString());
			tributosLiquidaciones.put("ANTIDUMPING",tributosForDetLiquida.get("0050").toString());
			tributosLiquidaciones.put("SOBRETASA ADICIONAL",tributosForDetLiquida.get("0062").toString());
			tributosLiquidaciones.put("INTERESES",tributosForDetLiquida.get("0059").toString());
			tributosLiquidaciones.put("IPM ADICIONAL",tributosForDetLiquida.get("0054").toString());
			tributosLiquidaciones.put("SERVICIO DE DESPACHO ADUANERO",tributosForDetLiquida.get("0007").toString());
		}
		generacionLCTributo.put("tributosLiquidaciones",tributosLiquidaciones);

		//amancilla P21-P22 TODO: problema si registran resolucion por Multa y por LC el modelo de datos cual prevalece
		ResCabBean resolucionTributo =(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionTributo");
		if(resolucionTributo!=null){
			diligencia.put("COD_TIPDOCDILI", DOCUMENTO_DETERMINACION); //
			diligencia.put("COD_ADUADOCSUST",resolucionTributo.getCodAduanaDocSust());
			diligencia.put("COD_TIPDOCSUST", resolucionTributo.getCodTipDocSust());
			diligencia.put("COD_AREADOCSUST",resolucionTributo.getCodAreaDocSust());
			diligencia.put("ANN_DOCSUST",    resolucionTributo.getAnnDocSust());
			diligencia.put("NUM_DOCSUST",    resolucionTributo.getNumDocSust());

			generacionLCTributo.put("numeroResolucion",resolucionTributo.getNumeroResolucion().toString());
		}


		List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
        List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");


        Map<String, Object> params = new HashMap();
        params.put("mapCabDiligenciaActual", diligencia);
        params.put("mapCabDeclaraActual", declaracionActual);
		params.put("lstliquidaMarcadas", lstliquidaMarcadas);
		params.put("lstDetDeclaraActual", lstDetDeclara);
        params.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
        params.put("lstSeriesItemActual", lstSeriesItemActual);
        params.put("lstSeriesItem", lstSeriesItem);
        params.put("caduana", soporteService.obtenerAduana(request));
        params.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));
        params.put("lstIncidencias", WebUtils.getSessionAttribute(request, "lstIncidencias"));
        params.put("cod_funcionario", bUsuario.getNroRegistro().trim());

        actualizandoSerieAndSeriesItem(params);
        if("0".equals(declaracionActual.get("IND_FORMBPROVEEDOR").toString())){
        	this.actualizarIdDeItemFactura(params);
        	declaracionActual = this.restaurarCantidadYFobItemEliminado(params);
        }

		lstSeriesItemActual = (List<Map<String, Object>>)params.get("lstSeriesItemActual");

        params.put("caduana", soporteService.obtenerAduana(request));
		params.put("lstMultaDua", multas);
		params.put("mapCabDeclara",WebUtils.getSessionAttribute(request, "mapCabDeclara"));
		params.put("lstIncidencias", lstIncidencias);
        params.put("cod_funcionario", bUsuario.getNroRegistro().trim());


        Map prmtVal = new HashMap();

        prmtVal.put("mapCabDeclara", declaracionActual);
        prmtVal.put("lstDetDeclara", WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
        prmtVal.put("lstFacturasSerie", WebUtils.getSessionAttribute(request, "lstFacturasSerieActual"));
        //amancilla P21-P22
        String codTransaccionGrabado = "11";
        prmtVal.put("codTransaccion",declaracionActual.get("COD_REGIMEN").toString() + codTransaccionGrabado);
        prmtVal.put("lstSeriesItemActual", lstSeriesItemActual);
        prmtVal.put("lstDocAutAsociado", declaracionActual.get("lstDocAutAsociado"));
        prmtVal.put("lstDetAutorizacion", declaracionActual.get("lstDetAutorizacion"));

        GetDeclaracionHashMapToDeclaracionObjectHelper transformHelper = fabricaDeServicios.getService("diligencia.ingreso.transformHelper");
        Declaracion decla = transformHelper.transformDiligenciaConclusionDespacho(prmtVal);
        OrquestadorDiligenciaService orquestadorService = fabricaDeServicios.getService("diligencia.ingreso.orquestadorService");
        orquestadorService.setDeclaracion(decla);
        lstValidacion = new HashMap();

        lstValidacion = orquestadorService.diligenciaDespachoDeclaracion(bUsuario);




        listaErrores.addAll((List) lstValidacion.get("listaErrores"));
        resultado = (Map<String, Object>) lstValidacion.get("resultado");

        boolean estaVigentePSF10= PackageGeneral.getVigenciaCambio("983", "10", "PSF10", "001078", SunatDateUtils.getCurrentDate())>0;
        //es r�gimen de importaci�n y est� vigente PSF para dicho r�gimen
        if (decla.getDua().getCodregimen().equals("10") && estaVigentePSF10)
        {
        	//el m�todo devuelve dos mapas; un mapa para el error general y otro con las series de partidas
        	//sensibles encontradas

        	ValNegocNumeracFormA valNegocNumeracFormA = fabricaDeServicios.getService("diligencia.ingreso.valNegocNumeracFormA");

	        Map<String, Object> lstPartSens= valNegocNumeracFormA.listaPartidasSensibles(decla, lstSeriesItemActual);
	        List listaErrorPS= (List) lstPartSens.get("lstErrorPS");
	        List listaSerieSensible= (List) lstPartSens.get("lstSeries");
	        if (listaErrorPS != null && listaErrorPS.size() > 0)
	        {
	        	resultado.put("mensajeRespuesta", "La operaci�n no pudo realizarse debido a que se encontraron errores.");
	        	resultado.put("recOk", false);
	        	listaErrores.addAll(listaErrorPS);
	        	if (listaSerieSensible != null && listaSerieSensible.size() > 0)
	            {
	            	res.addObject("tienePartSensible", true);
	            	res.addObject("ListPartSensible", SojoUtil.toJson(listaSerieSensible));
	            }
	        	else res.addObject("tienePartSensible", false);
	        }
        }

      //RSV CCONTINGENTES
        Map<String, Object> variablesIngreso = new HashMap();

        List listConvenioSerie = new ArrayList();
        List<Map<String, Object>> lstDetDeclaraActualConvenio =
                (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                                                                         request,
                                                                         "lstDetDeclaraActual");
        for (Map<String, Object> detDeclaraMap : lstDetDeclaraActualConvenio)
        {
            if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
            {
                detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
            }
            if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
            {
                List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
                for (int i = 0; i < lstConvenioSerie.size(); i++)
                {
                    HashMap convenio = (HashMap) lstConvenioSerie.get(i);
                    listConvenioSerie.add(convenio);
                }
            }
        }


        //RSV CCONTINGENTES
        variablesIngreso.put("listConvenioSerie", listConvenioSerie);
        int nroErrores =0;
      		  if( !CollectionUtils.isEmpty(listaErrores))
      			  nroErrores =listaErrores.size();

        ValidaContingentesService validaContingenteService = fabricaDeServicios.getService("declaracion.validaContingentesService");
      //RSV PAS20165E220200076
        List lstErroConclu = validaContingenteService.procesarDiligencia(decla, variablesIngreso , 0);
        if (lstErroConclu.size() > 0)
        {
          /*res.addObject("recOk", false);
          res.addObject("mensajeRespuesta", "No se registro la diligencia");
          res.addObject("resValidacion", SojoUtil.toJson(lstErroConclu));
          return res;
          */
	      	resultado.put("mensajeRespuesta", "La operaci�n no pudo realizarse debido a que se encontraron errores.");
	      	resultado.put("recOk", false);
	      	listaErrores.addAll(lstErroConclu);

        }
      //RSV CCONTINGENTES

        if((Boolean) resultado.get("recOk"))
        {
          params.put("cb_liqsol", webRequest.getParameter("cb_liqsol")!=null?webRequest.getParameter("cb_liqsol"):"");
          params.put("cb_liqdol", webRequest.getParameter("cb_liqdol")!=null?webRequest.getParameter("cb_liqdol"):"");
          params.put("tipDilig", tipDilig);
          params.put("generacionLCMulta", generacionLCMulta);
          //params.put("lstMultaDuaLC003", WebUtils.getSessionAttribute(request, "lstMultaDuaLC003"));
		  params.put("lstMultaDuaOkResolucion", WebUtils.getSessionAttribute(request, "lstMultaDuaOkResolucion")); //bug21603
		  //AMANCILLA p21-p22
		  params.put("generacionLCTributo", generacionLCTributo);
		  //RSV PARA CONTINGENTE CONCLUSION
		  params.put("objDeclaracion", decla);
		  params.put("ingresoPostLevante",ingresoPostLevante);//adicionado por PAS20165E220200032
 		  diligenciaService.grabarConclusionDespacho(params);
          declaracion.putAll(declaracionActual);
          WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
          res.addObject("recOk", true);
          res.addObject("mensajeRespuesta", "Se ha grabado satisfactoriamente la diligencia de Conclusi�n de Despacho");//P24-II
          res.addObject("resValidacion", SojoUtil.toJson(listaErrores));//poner esta variable si no se va caer el jsp.

			/* AMANCILLA P21-P22
          if (params != null && params.size() > 0 && params.get("mensaje") != null){
	          List<Map<String, String>> mensaje= (List<Map<String, String>>) params.get("mensaje"); //MOL PASE280
	          listaErrores.addAll(mensaje);
          }

          res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
          */
          Utilidades.limpiarMapasSesion(request);
        }
        else
        {
          res.addObject("recOk", false);
          res.addObject("mensajeRespuesta", resultado.get("mensajeRespuesta"));
          res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
        }
    }
    catch (DiligenciaException e){
      log.warn("*** multiples sessiones grabado diligencia ***", e);
      //amanacilla verifica si ya grabo la diligencia en una anterior session
        List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
        res.addObject("recOk", false);
        res.addObject("mensajeRespuesta", "Diligencia de conclusion ya se encuentra registrada.");
        res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
      //fin amancilla pase
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      res.addObject("beanM", rBean);
    }
    finally
    {
      return res;
    }

  }


  //Metodo traido de la diligencia de despacho
  private void actualizandoSerieAndSeriesItem(Map<String, Object> params) throws Exception{
	    List<Map<String, Object>> lstDetDeclara = params.get("lstDetDeclaraActual") != null ? (ArrayList) params.get("lstDetDeclaraActual") : new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> lstDetDeclaraAnt = null != params.get("lstDetDeclaraAnt") ? (ArrayList) params.get("lstDetDeclaraAnt") : new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> lstSeriesItemActual = null != params.get("lstSeriesItemActual") ? (ArrayList) params.get("lstSeriesItemActual") : new ArrayList<Map<String, Object>>();

	    Map cabDeclara = (HashMap) params.get("mapCabDeclaraActual");
	    List<Map<String, Object>> lstDetAutorizacionActual = new ArrayList<Map<String, Object>>();

	    if (!CollectionUtils.isEmpty(cabDeclara))
	    {
	      lstDetAutorizacionActual = cabDeclara.get("lstDetAutorizacion") != null ? (ArrayList) cabDeclara.get("lstDetAutorizacion") : new ArrayList<Map<String, Object>>();
	    }

	    String IND_REGISTRO_PENDIENTE = "1";

	    // contador maximo
	    String numCorreDocDua = cabDeclara.get("NUM_CORREDOC").toString();
	    int contadorMax = serieService.getSgteNumSecSerie(numCorreDocDua);

	    // removiendo los pendientes, eliminados; por registrar
	    if (lstDetDeclara != null && !lstDetDeclara.isEmpty())
	    {
	      for (Iterator it = lstDetDeclara.iterator(); it.hasNext();)
	      {
	        Map serie = (HashMap) it.next();
	        // ESTADO_REGISTRO =1 :pendiente de registro en BD.
	        if (serie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE) ||
	            (serie.get("ESTADO_REGISTRO").toString().equals("1") &&
	            serie.get("IND_DEL").toString().equals("1")))
	        {
	          // Listas fuera de la serie que poseen relacion
	          // lstSeriesItem
	          for (Iterator itSI = lstSeriesItemActual.iterator(); itSI.hasNext();)
	          {
	            Map seriesItem = (HashMap) itSI.next();
	            if (seriesItem.get("NUM_SECSERIE").toString().equals(serie.get("NUM_SECSERIE").toString()))
	            {
	            	itSI.remove();
	            }
	          }

	          // lstDetAutorizacion
	          for (Iterator itDetAut = lstDetAutorizacionActual.iterator(); itDetAut.hasNext();)
	          {
	            Map detAutorizacion = (HashMap) itDetAut.next();
	            if (detAutorizacion.get("NUM_SECSERIE").toString().equals(serie.get("NUM_SECSERIE").toString()))
	            {
	              itDetAut.remove();
	            }
	          }
	          it.remove();
	        }
	      }
	    }
	    // asignando numero de serie nuevo quitando los datos de baja
	    if (lstDetDeclara != null && !lstDetDeclara.isEmpty())
	    {
	      for (Map<String, Object> serie : lstDetDeclara)
	      {
	        String num_secSerieAnt = serie.get("NUM_SECSERIE").toString();
	        // solo se consideran a los activos las series eliminadas y no
	        // recuepradas no se consideran
	        // para evitar se creen huecos de numeracion
	        if (serie != null && serie.get("ESTADO_REGISTRO").toString().equals("1")
	            && serie.get("IND_DEL").toString().equals("0"))
	        {

	          serie.put("NUM_SECSERIE", contadorMax);
	          // Asignamos nuevo NUM_SECSERIE A LISTAS DENTRO DE SERIE
	          // lstFacturaSerie
	          List<Map> lstFacturaSerie = (List) serie.get("lstFacturaSerie");
	          if (!CollectionUtils.isEmpty(lstFacturaSerie))
	          {
	            for (Map mapFactuSerie : lstFacturaSerie)
	            {
	              mapFactuSerie.put("NUM_SECSERIE", contadorMax);
	            }
	          }
	          // lstConvenio
	          List<Map> lstConvenioSerie = (List) serie.get("lstConvenioSerie");
	          if (!CollectionUtils.isEmpty(lstConvenioSerie))
	          {
	            for (Map mapConvenioSerie : lstConvenioSerie)
	            {
	              mapConvenioSerie.put("NUM_SECSERIE", contadorMax);
	            }
	          }
	          // lstDocuPreceDua
	          List<Map> lstDocuPreceDua = (List) serie.get("lstDocuPreceDua");
	          if (!CollectionUtils.isEmpty(lstDocuPreceDua))
	          {
	            for (Map mapDocuPreceDua : lstDocuPreceDua)
	            {
	              mapDocuPreceDua.put("NUM_SECSERIE", contadorMax);
	            }
	          }
	          // lista Series Item
	          if (lstSeriesItemActual != null)
	          {
	            for (Map<String, Object> serieItem : lstSeriesItemActual)
	            {
	              if (num_secSerieAnt.equals(serieItem.get("NUM_SECSERIE").toString()))
	              {
	                serieItem.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
	              }
	            }
	          }
	          // lista de DetAutorizantes
	          if (lstDetAutorizacionActual != null)
	          {
	            for (Map<String, Object> detAutorizacion : lstDetAutorizacionActual)
	            {
	              if (num_secSerieAnt.equals(detAutorizacion.get("NUM_SECSERIE").toString()))
	              {
	                detAutorizacion.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
	              }
	            }
	          }
	          // sgte correlativo de la serie
	          contadorMax++;
	        }
	      }
	    }

	    if (!CollectionUtils.isEmpty(cabDeclara))
	    {
	      cabDeclara.put("lstDetAutorizacion", lstDetAutorizacionActual);
	    }

	    params.put("mapCabDeclaraActual", cabDeclara);
	    params.put("lstDetDeclaraActual", lstDetDeclara);
	    params.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
	    params.put("lstSeriesItemActual", lstSeriesItemActual);
  }

  /** M�todo que actualiza el Id de los items adicionados(copiados que no existe en base de datos) al ser eliminado alg�n item adicionado,
   *  remueve items eliminados y sus correlaciones (los adicionados no existentes en base de datos),
   *  actualiza el id del item en sus listas asociadas
   * @param params
   * @throws Exception
   */
   public void actualizarIdDeItemFactura(Map<String, Object> params) throws Exception{
 	  log.debug("-->INICIO - actualizarIdDeItemFactura");
 		    Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
 		    List<Map<String, Object>> lstSeriesItemActual = null != params.get("lstSeriesItemActual") ? (ArrayList) params.get("lstSeriesItemActual") : new ArrayList<Map<String, Object>>();
 		    List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>)params.get("lstDetDeclaraActual");
 		    List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)params.get("lstSeriesItem");

 		    //Remover correlaciones temporales eliminados (de una serie registrada en Base de Datos que fue eliminada durante la diligencia)
 		    for(Map<String, Object> serie : lstDetDeclaraActual){

 		      if("1".equals(serie.get("IND_DEL").toString()) && serie.get("ESTADO_REGISTRO").toString().equals("0")){

 			    for (Iterator itSI = lstSeriesItemActual.iterator(); itSI.hasNext();){
 		            Map seriesItem = (HashMap) itSI.next();

 		            if(serie.get("NUM_SECSERIE").toString().equals(seriesItem.get("NUM_SECSERIE").toString())
 		            	&& "1".equals(seriesItem.get("IND_DEL").toString())){
 			            Map<String,Object> keys = new HashMap<String,Object>();
 			            keys.put("NUM_SECSERIE", seriesItem.get("NUM_SECSERIE"));
 			            keys.put("NUM_SECITEM", seriesItem.get("NUM_SECITEM"));


 			            Map<String,Object> serieItemAnt = Utilidades.obtenerElemento(lstSeriesItemAnt, keys);

 			            if(serieItemAnt == null || serieItemAnt.isEmpty()){

 				              itSI.remove();
 			            }
 		            }
 		    	}
 		       }
 		    }

 		    String IND_REGISTRO_PENDIENTE = "1";

 			//Obtener el Primer Item eliminado para ordenar los Id a partir de ese Item
 		    List<Map<String, Object>> listaTotalItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(mapCabDeclaraActual);
 			Ordenador.sortDesc(listaTotalItemFactura, "NUM_SECITEM", Ordenador.ASC);

 			String primerItemEliminado = "";
 			for(Map<String, Object> itemFactura : listaTotalItemFactura){
 				if(("1".equals(itemFactura.get("IND_DEL").toString()) &&  "1".equals(itemFactura.get("ESTADO_REGISTRO").toString()))
 					|| IND_REGISTRO_PENDIENTE.equals(itemFactura.get("IND_TIPO_REGISTRO"))){
 					primerItemEliminado = itemFactura.get("NUM_SECITEM").toString();
 					break;
 				}
 			}


 		    List<Map<String,Object>> listaItemFactura = new ArrayList<Map<String,Object>>();
 		    // removiendo los pendientes, adicionados que fueron eliminados
 		    List<Map<String, Object>> listProveedores = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
 		    for (Map<String, Object> mapa : listProveedores){
 		       List<Map<String, Object>> lstFactura = (List<Map<String, Object>>) mapa.get("lstComproBPago");

 		         for (Map<String, Object> mapaFactura : lstFactura){
 		           listaItemFactura = (List<Map<String,Object>>)mapaFactura.get("lstItemFactura");

 		          if(!CollectionUtils.isEmpty(listaItemFactura)){

 		            for (Iterator it = listaItemFactura.iterator(); it.hasNext();){
 		               Map item = (HashMap) it.next();

 		              if (item.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE) ||
 		            	 (item.get("ESTADO_REGISTRO").toString().equals("1") && item.get("IND_DEL").toString().equals("1") )){

 		            	  it.remove();
 		              }
 		            }
 		          }
 		       }

 		    }

 		    //Actualiza la lista de Correlaciones asociadas por Item de acuerdo a la lista general de correlaciones "lstSeriesItemActual"
 		    boolean encontrado = false;
 		    for (Map<String, Object> mapa : listProveedores){

 	        	List<Map<String, Object>> lstFacturaComp = (List<Map<String, Object>>) mapa.get("lstComproBPago");
 	             for (Map<String, Object> factura : lstFacturaComp){

 	            	 listaItemFactura = (List<Map<String,Object>>)factura.get("lstItemFactura");

 	            	 if(!CollectionUtils.isEmpty(listaItemFactura)){
 	            	    for(Map<String, Object> item : listaItemFactura){

 	            			 //serieItems por Item
 	            			 if( item.get("lstSeriesItem")!= null && !item.get("lstSeriesItem").toString().isEmpty()){
 		            			 List<Map<String,Object>> lstSeriesItem = (List<Map<String,Object>>)item.get("lstSeriesItem");

 			      		         for(Iterator itera = lstSeriesItem.iterator(); itera.hasNext();){
 			      		             Map serieItem = (HashMap) itera.next();

 			      		             encontrado = false;
 		            				 for(Map<String,Object> serieItemAct: lstSeriesItemActual){
 		            					 if(serieItem.get("NUM_SECITEM").toString().equals(serieItemAct.get("NUM_SECITEM").toString())
 		            					    && serieItem.get("NUM_SECSERIE").toString().equals(serieItemAct.get("NUM_SECSERIE").toString())){

 		            						 encontrado = true;
 		            						 break;
 		            					 }
 		            				 }
 		            				 if(!encontrado){
 		            					 itera.remove();
 		            				 }
 		            			 }
 	            			 }

 	            	    }
 	            	 }
 	             }
 		    }

 		    List<Map<String, Object>> listaTotalItemFacturaNueva = new ArrayList<Map<String, Object>>();
 		    if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor"))) {
 		    	  List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
 			        for (Map<String, Object> mapa : lstForBProveedor){
 			        	List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
 			             for (Map<String, Object> mapaFactura : lstComproBPago){

 			               List lstItemFactua = (List)mapaFactura.get("lstItemFactura");
 			            	if(!CollectionUtils.isEmpty(lstItemFactua)){
 			            		listaTotalItemFacturaNueva.addAll((List)mapaFactura.get("lstItemFactura"));
 			               }
 			             }
 			         }
 			 }

 			//primerItemEliminado
 		    if(!primerItemEliminado.isEmpty()){
 			Integer numItem = Integer.valueOf(primerItemEliminado);
 			for(Map<String, Object> item : listaTotalItemFacturaNueva){
 				if("0".equals(item.get("IND_TIPO_REGISTRO").toString())
 					&& "1".equals(item.get("ESTADO_REGISTRO").toString())
 					&& (Integer.valueOf(item.get("NUM_SECITEM").toString())).intValue() > numItem.intValue() ) {

 					String num_secItemAnt = item.get("NUM_SECITEM").toString();
 					item.put("NUM_SECITEM", numItem);

        			 //serieItems por Item
        			 if( item.get("lstSeriesItem")!= null && !item.get("lstSeriesItem").toString().isEmpty()){
            			 List<Map<String,Object>> lstSeriesItem = (List<Map<String,Object>>)item.get("lstSeriesItem");
            			 for(Map<String,Object> serieItem : lstSeriesItem){
            				 serieItem.put("NUM_SECITEM", numItem);
            			 }
            			Ordenador.sortDesc(lstSeriesItem, "NUM_SECSERIE", Ordenador.ASC);
        			 }

        			 if(item.get("lstVfobProvisional")!=null && !item.get("lstVfobProvisional").toString().isEmpty()){
        				 List<Map<String,Object>> lstVfobProvisional = (List<Map<String,Object>>)item.get("lstVfobProvisional");
        				 for(Map<String,Object> vfobProv : lstVfobProvisional){
        					 vfobProv.put("NUM_SECITEM", numItem);
        				 }
        			 }

        			 if(item.get("lstDecrMinima")!=null && !item.get("lstDecrMinima").toString().isEmpty()){
        				 List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>)item.get("lstDecrMinima");
        				 for(Map<String,Object> formBitemDes : lstDecrMinima){
        					 formBitemDes.put("NUM_SECITEM", numItem);
        				 }
        			 }

        			 if(item.get("lstReferenciaDuda")!=null && !item.get("lstReferenciaDuda").toString().isEmpty()){
        				 List<Map<String,Object>> lstReferenciaDuda = (List<Map<String,Object>>)item.get("lstReferenciaDuda");
        				 for(Map<String,Object> refDuda : lstReferenciaDuda){
        					 refDuda.put("NUM_SECITEM", numItem);
        				 }
        			 }

        			if(!CollectionUtils.isEmpty(lstSeriesItemActual)){
        			 Ordenador.sortDesc(lstSeriesItemActual, "NUM_SECITEM", Ordenador.ASC);
     	            for (Map<String, Object> serieItem : lstSeriesItemActual)
     	            {
     	              if (num_secItemAnt.equals(serieItem.get("NUM_SECITEM").toString()))
     	              {
     	                serieItem.put("NUM_SECITEM", numItem);
     	              }
     	            }

     	         }

 				 numItem++;

 				}
 			}

 		    //actualizar items en la declaracion
 		    if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor"))) {
 		    	  List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
 			        for (Map<String, Object> mapa : lstForBProveedor){
 			        	List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
 			             for (Map<String, Object> mapaFactura : lstComproBPago){

 			            	    List<Map<String,Object>> itemFactura = new ArrayList<Map<String,Object>>();
 			            		for(Map<String, Object> item : listaTotalItemFacturaNueva){
 			            			if(mapaFactura.get("num_secfact").toString().equals(item.get("NUM_SECFACT").toString())
 			            			   && mapaFactura.get("num_secprove").toString().equals(item.get("NUM_SECPROVE").toString())
 			            			   && mapaFactura.get("num_corredoc").toString().equals(item.get("NUM_CORREDOC").toString())){

 			            				itemFactura.add(item);
 			            			}
 			            		}
 			            		Ordenador.sortDesc(itemFactura, "NUM_SECITEM", Ordenador.ASC);
 			            		this.colocarLstItemFacturas(mapCabDeclaraActual,itemFactura,mapaFactura.get("num_secprove").toString(),
 				            			mapaFactura.get("num_secfact").toString());
 			             }
 			         }
 			 }

 		    }

 		    Ordenador.sortDesc(lstSeriesItemActual, "NUM_SECSERIE", Ordenador.ASC);
 		    params.put("mapCabDeclaraActual", mapCabDeclaraActual);
 		    params.put("lstSeriesItemActual", lstSeriesItemActual);

     }

   /**
    * Metodo que agrage la lista de Items Factura en el Objeto de la Declaracion
    * para en la seccion de Proveedor y Factura correspondiente.
    *
    * @param declaracion
    *          the declaracion
    * @param lstItemFacturas
    *          the lst item facturas
    * @param num_secprove
    *          the num_secprove
    * @param num_secfact
    *          the num_secfact
    */
   private void colocarLstItemFacturas(Map declaracion, List lstItemFacturas, String num_secprove, String num_secfact)
   {
 	  log.debug("-->INICIO - colocarLstItemFacturas");
     if (declaracion != null && declaracion.size() > 0)
     {
       List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

       String codProv;
       String secFact;
       List lstItemfactAsig = new ArrayList();
       for (Map prov : lstProve)
       {
         codProv = prov.get("num_secprove").toString().trim();
         if (codProv.equals(num_secprove))
         {
           List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
           for (Map comPago : lstComproBPago)
           {
             secFact = comPago.get("num_secfact").toString().trim();
             if (secFact.equals(num_secfact))
             {
               lstItemfactAsig = Utilidades.copiarLista(lstItemFacturas);
               comPago.put("lstItemFactura", lstItemfactAsig);
               break;
             }
           }

         }
       }

     }
   }

   /** Restaura la cantidad unitaria del item (preexistente) cuando se elimina la totalidad del item
    * El m�todo es invocado al grabar la diligencia
    * @param declaracionActual
    * @param request
    * @return
    */
    private Map<String,Object> restaurarCantidadYFobItemEliminado(Map<String, Object> params){

  	Map mapCabDeclara = (HashMap) params.get("mapCabDeclara");
  	Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
      List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
      List<Map<String,Object>> lstForBProveedorAnt = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
      for (Map<String, Object> mapa : lstForBProveedor){

      	Map fbKeys = new HashMap<String, Object>();
          fbKeys.put("num_corredoc", mapa.get("num_corredoc"));
          fbKeys.put("num_secprove", mapa.get("num_secprove"));
          Map<String,Object> mapProveedorAnt = Utilidades.obtenerElemento(lstForBProveedorAnt, fbKeys);

      	List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
      	List<Map<String,Object>> lstComproBPagoAnt = (List<Map<String, Object>>) mapProveedorAnt.get("lstComproBPago");

      	if(!CollectionUtils.isEmpty(lstComproBPago) && !CollectionUtils.isEmpty(lstComproBPagoAnt)){
           for (Map<String, Object> mapaFactura : lstComproBPago){

          	 if(mapaFactura.get("lstItemFactura")!=null && !mapaFactura.get("lstItemFactura").toString().isEmpty()){
          		List<Map<String,Object>> lstItemFactura = (List<Map<String,Object>>)mapaFactura.get("lstItemFactura");
   	            fbKeys.put("num_secfact", mapaFactura.get("num_secfact"));
  	            fbKeys.put("num_secprove", mapaFactura.get("num_secprove"));
  	            fbKeys.put("num_corredoc", mapaFactura.get("num_corredoc"));
  	            Map<String,Object> mapaFacturaAnt = Utilidades.obtenerElemento(lstComproBPagoAnt, fbKeys);
          		List<Map<String,Object>> lstItemFacturaAnt = (List<Map<String,Object>>)mapaFacturaAnt.get("lstItemFactura");

              	 for (Map<String, Object> item : lstItemFactura){
  	            	 if("0".equals(item.get("ESTADO_REGISTRO").toString())
  	            	    && ("1").equals(item.get("IND_DEL").toString())){

  				            Map<String,Object> keys = new HashMap<String,Object>();
  				            keys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
  				            keys.put("NUM_SECITEM", item.get("NUM_SECITEM"));


  				            Map<String,Object> itemAnt = Utilidades.obtenerElemento(lstItemFacturaAnt, keys);
  				            if(itemAnt !=null && itemAnt.get("IND_DEL").toString().equals("0")){
  				            	item.put("CNT_UNI", itemAnt.get("CNT_UNI"));
  				            	item.put("MTO_FOBITEM", itemAnt.get("MTO_FOBITEM"));
  				            	item.put("MTO_FOBUNITARIO", itemAnt.get("MTO_FOBUNITARIO"));
  				            }
  	            	 }
              	 }
          	 }
           }
        }
      }

      return  (HashMap)params.get("mapCabDeclaraActual");
     }

  private String validaExisteDiligencia(String numCorreDoc, String tipDilig){
    String rspta = "";
    if (Constantes.DILIG_CONCLUSION_DESPACHO.equals(tipDilig)){
      Map<String,Object> params = new HashMap<String,Object>();
      params.put("numcorredoc", numCorreDoc);
      params.put("codtipdiligencia", tipDilig);
      Integer la = diligenciaService.count(params);
      boolean tieneDiligenciaYaRegistrada = la>0?true:false;

      if(tieneDiligenciaYaRegistrada){
        rspta = "Diligencia de conclusion ya se encuentra registrada.";
      }
    }
    return rspta;
  }

  //Inicio RIN10 mpoblete REFACTOR
  private boolean duaTieneIndicadorDUAValorProvActivo(Map<String,Object> declaracion){
	  DatoIndicadores indicadorDUA = new DatoIndicadores();

	  indicadorDUA =  obtenerIndicadorDUAVP(declaracion.get("NUM_CORREDOC").toString());


	  return (indicadorDUA!=null);

  }
  private DatoIndicadores obtenerIndicadorDUAVP(String numCorredoc){
	  DatoIndicadores indicadorDUA = new DatoIndicadores();
	  indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(numCorredoc, pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
	  return indicadorDUA;
  }

  private void  verificarValorProvisional(Map<String, Object> params,Map<String, Object> declaracion) {
  	  DataCatalogo dataCatalogo = RectificacionServiceImpl.getInstance().getDataCatalogoDAO().buscarDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP, ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP);
  	  String numero = dataCatalogo.getDesCorta();
  	  if(StringUtils.isEmpty(numero)){
  		  numero="0";
  	  }
  	  BigDecimal porcentajeBaseImponible = new BigDecimal(numero);
  	  BigDecimal datoDefault = new BigDecimal("0");
  	  int evaluacion = porcentajeBaseImponible.compareTo(datoDefault);
  	  Map<String,Object> paramPadUsuGar = new HashMap<String, Object>();
  	  paramPadUsuGar.put("NUMRUC", declaracion.get("COD_RUCLUGRECEP").toString());
  	  paramPadUsuGar.put("IND_USUACTIVO", "1");
  	  paramPadUsuGar.put("IND_LCVP", "1");
  	  declaracion.put("ANN_PRESEN", declaracion.get("ANN_PRESEN").toString().substring(2));
  	  boolean tieneRucImportador = validarRucImportadorTieneLC(paramPadUsuGar);
  	  if(evaluacion==1 && tieneRucImportador){
  		  if(verificarDeclaracionConLCGenerada(declaracion)){
  			  //Inicio RIN10 mpoblete BUG 22018
  			  boolean liquidacionEstaGarantizada = liquidacionCobranzaGarantizada(declaracion);
  			  boolean duaTieneGarantia160 = declaracionGarantia160(declaracion);
  			  if(duaTieneGarantia160 && liquidacionEstaGarantizada){verificarDeclaracionAfectadaCtaCte(declaracion);}
  			  //Fin RIN10 mpoblete BUG 22018
  		  }
  	  }
  }
  private boolean  validarRucImportadorTieneLC(Map<String,Object> params){
	  	PadronUsuarioService padronUsuarioService = fabricaDeServicios.getService("padronUsuarioService");
	  	 return  padronUsuarioService.findByNumRucExiste(params);

  }
  private boolean verificarDeclaracionConLCGenerada(Map<String, Object> declaracion){
	  LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
	  Map<String,Object> declaracionLocal = declaracion;

	  boolean tieneLCVPGenerado = liquidaDeclaracionService.verificarDeclaracionConLCGenerada(declaracionLocal);

	  if(!tieneLCVPGenerado){
		  lisdatoMsj = lisdatoMsj+" *DUA NO CUENTA CON LC(VP) SIRVASE GENERARLA <BR>";
		  return false;
	  }

	  return true;
  }

  private boolean liquidacionCobranzaGarantizada(Map<String, Object> declaracion) {
	    LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
	  	/** Inicio mpoblete RIN10 **/
		Map<String,Object> declaracionLocal = declaracion;
	  	declaracionLocal.put("tipoLiquidacion", Constantes.COD_TIPLIQ);
	  	/** Fin mpoblete RIN10 **/
	    //Inicio RIN10 mpoblete BUG 21917
	  	//boolean result = liquidaDeclaracionService.verificarDeclaracionConLCGeneradaGarantizada(declaracionLocal);
		boolean result = liquidaDeclaracionService.tieneDeclaracionLCVPGarantizadaImpugnada(declaracionLocal);


		//boolean duaConGarantia160 = declaracionGarantia160(declaracionLocal);
		//result = (result && duaConGarantia160);
		//Fin RIN10 mpoblete BUG 21917

	  	if(!result)
	  		 lisdatoMsj = lisdatoMsj+" *LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA, NOTIFICAR AL IMPORTADOR  <BR>";
	  	return result;
	  }

  private boolean declaracionGarantia160(Map<String, Object> declaracion) {
	     //Inicio RIN10 mpoblete BUG 22163
		 String numCtaCte = (String) declaracion.get("NUM_CTACTE");
		 numCtaCte = numCtaCte.trim();
		 boolean tieneGarantia160 = (!StringUtils.isEmpty(numCtaCte));
	  	 //if(declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE")){
	  	 if(tieneGarantia160){
	  	 //Fin RIN10 mpoblete BUG 22163
	  		 return true;
	  	 }
	  	 return false;
	  }

  private void verificarDeclaracionAfectadaCtaCte(Map<String, Object> declaracion) {
	  //Inicio RIN10 mpoblete BUG 22125
	  //boolean estado = liquidaDeclaracionService.verificarDeclaracionAfectadaCtaCte(declaracion);
	  LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
	  boolean estado = liquidaDeclaracionService.ctaCteGaraAfectadaPorLiquidaVP(declaracion);
	  //Fin RIN10 mpoblete BUG 22125
	  if(!estado){
		  lisdatoMsj = lisdatoMsj+ " LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO HA AFECTADO LA CTA CTE DE LA GARANTIA <BR>";
	  }
  }
  //fin Inicio RIN10 mpoblete REFACTOR

//P13 JMCV - INICIO
  /**
   * Metodo que valida el paso del estado de la DUA de Revision a en Proceso.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  	public ModelAndView validarCambioRevisionAProceso(HttpServletRequest request, HttpServletResponse response) {
  		ModelAndView res = new ModelAndView(this.jsonView);
  		try {
  			Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
  			String validacionFecha =  this.declaracionService.validarFechaRecepcion(mapCabDeclaraActual);
  			String validacionManifiesto="";

      //juazor RIN13    correccion amancilla
      String modalidad = (String)mapCabDeclaraActual.get("COD_MODALIDAD");
      String num_manifiesto=(String) mapCabDeclaraActual.get("NUM_MANIFIESTO");

      if(!StringUtils.isEmpty(num_manifiesto.trim()) && ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(modalidad)){

          //este codigo tambiene sta por mejorar
          String numeroManifiesto = StringUtils.leftPad((String)mapCabDeclaraActual.get("NUM_MANIFIESTO"), 6, ' ');
          Object oAnioManifiesto = mapCabDeclaraActual.get("ANN_MANIFIESTO");
          Integer anioManifiesto = oAnioManifiesto != null ? Integer.valueOf(oAnioManifiesto.toString()) : null;
          String codigoAduana = (String)mapCabDeclaraActual.get("COD_ADUAMANIFIESTO");
          String tipoManifiesto = (String)mapCabDeclaraActual.get("COD_TIPMANIFIESTO");
          String viaTransporte = (String)mapCabDeclaraActual.get("COD_VIATRANS");

          Long numeroCorrelativo = ((BigDecimal)mapCabDeclaraActual.get("NUM_CORREDOC")).longValue();

          Object oNumeroDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION");
          Integer numeroDeclaracion = oNumeroDeclaracion != null ? Integer.parseInt(oNumeroDeclaracion.toString()) : null;
          Object oAnioDeclaracion = mapCabDeclaraActual.get("ANN_PRESEN");
          String anioDeclaracion =  oAnioDeclaracion != null ? oAnioDeclaracion.toString() : null;
          String regimenDeclaracion = (String)mapCabDeclaraActual.get("COD_REGIMEN");
          String aduanaDeclaracion = (String)mapCabDeclaraActual.get("COD_ADUANA");
          Date fechaDeclaracion =  (Date) mapCabDeclaraActual.get("FEC_DECLARACION");

          String mensaje = declaracionService.isPlazoMercanciaArriboDespachoAnticipado(numeroDeclaracion, anioDeclaracion, regimenDeclaracion, aduanaDeclaracion, fechaDeclaracion, numeroManifiesto, anioManifiesto, codigoAduana, tipoManifiesto, viaTransporte,numeroCorrelativo);
          //amancilla FSW se cambio por otro servicio por mala implementacion
    	  //boolean validarDespachoAnticipado= diligenciaService.validarDespachoAnticipado(mapCabDeclaraActual);
    	 // if (!validarDespachoAnticipado){
          if (!mensaje.equals("ok")){
    		//si retorna falso graba comunicaicon y envia notificacion...

    		  	UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
    		  	SoporteAvisosService soporteAvisosService = fabricaDeServicios.getService("diligencia.ingreso.soporteAvisosService");
    		    String numCorreDoc = request.getParameter("hdn_num_corredoc") != null ? request.getParameter("hdn_num_corredoc") : " ";
  					String descComunicacion = "MERCANCIA ARRIBO FUERA DEL PLAZO ESTABLECIDO EN EL ARTICULO 130� DE LA LEY GENERAL DE ADUANAS, Declaracion requiere cambio de modalidad de Despacho Anticipado a Diferido.";
  					String descNotificacion = "Mediante la presente se le notifica que la mercancia amparada en la declaracion de la referencia ha arribado " +
  							"fuera del plazo previsto en el Articulo 130 de la Ley General de Aduanas.";
    		    String flag = request.getParameter("flag") != null ? request.getParameter("flag") : " ";

    		      Map<String, Object> params = new HashMap<String, Object>();
    		      FechaBean fecActual = new FechaBean();
    		      //parametros para grabar la comunicaicon
    		      params.put("flag", flag);
    		      params.put("num_corredoc", numCorreDoc);
    		      params.put("des_nota", descComunicacion);
    		      params.put("des_noti", descNotificacion);
    		      params.put("cod_usuregis", bUsuario.getNroRegistro());
    		      params.put("fec_regis", fecActual.getTimestamp());
    		      params.put("codAduana", mapCabDeclaraActual.get("COD_ADUANA").toString());
    		      params.put("annPresen", mapCabDeclaraActual.get("ANN_PRESEN").toString());
    		      params.put("codRegimen", mapCabDeclaraActual.get("COD_REGIMEN").toString());
    		      params.put("numDeclaracion", mapCabDeclaraActual.get("NUM_DECLARACION").toString());
    		      params.put("codCanal", mapCabDeclaraActual.get("COD_CANAL").toString());
    		      params.put("num_docident_pim", mapCabDeclaraActual.get("NUM_DOCIDENT_PIM"));
    		      params.put("num_docident_pde", mapCabDeclaraActual.get("NUM_DOCIDENT_PDE"));

    		      params.put("DES_CONSIGNATARIO", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM"));
    		      params.put("DES_AGENCIA_ADUANAS", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PDE"));

    		      soporteAvisosService.grabarComunicacionNotificacion(params);
    		      validacionManifiesto="1";

   			}

      }
      res.addObject("res", "");
      res.addObject("validacionManifiesto",validacionManifiesto);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      res.addObject("beanM", rBean);
    }

    return res;
  }
//P13 JMCV - FIN
  private List<Map<String, Object>> obtenerListaModificaciones(Map<String, Object> mapaRSPTADatosModificados,
          String codTablaCabDeclara){

	  return mapaRSPTADatosModificados.get(codTablaCabDeclara)!=null?
              (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados.get(codTablaCabDeclara):
              new ArrayList<Map<String, Object>>();
  }

  /*inicio gdlr399*/
  public void cargaFormatoBCompletoNew(Map<String, Object> declaracion, Map<String, Object> declaracionActual, HttpServletRequest request) {
	  log.debug("-->INICIO - cargaFormatoBCompletoNew");

	  //Las tablas consultadas son 9: FORMBPROVEEDOR, FORMBMONTO, CONDICION_TRANSA, COMPROB_PAGO, ITEMFACTURA, VFOBPROVISIONAL, SERIES_ITEM, FACTUSUCE, FORMBITEMDESCRI
	  //Al parecer no es necesario consultar independientemente la tabla OBSERVACION... se reduce la cantidad de querys a 9
	  //Obtenemos una sola vez el num_corredoc del map declaracionActual
	  Object numeroCorrelativoAsObject = declaracionActual.get("NUM_CORREDOC");
	  if (numeroCorrelativoAsObject == null || numeroCorrelativoAsObject.toString().isEmpty()) {
		  //lanzariamos excepcion?
		  return;
	  }
	  //glazaror... se separa logica de carga de formato B en un metodo independiente para mejorar mantenibilidad
	  Map<String, Object> cacheListas = cargarInformacionFormatoB(numeroCorrelativoAsObject, declaracionActual, request);
	  //extraemos las listas necesarias para trabajarlos mas adelante
	  List<Map> proveedores = (List<Map>) cacheListas.get("proveedores");
	  Map<String, List<Map<String, Object>>> cacheItemFactura = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheItemFactura");
	  Map<String, List<Map<String, Object>>> cacheFobProvisional = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFobProvisional");
	  Map<String, List<Map<String, Object>>> cacheSeriesItem = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheSeriesItem");
	  Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheDescripcionesMinimas");
	  Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturasSucesivas");

	  Map<String, Map<String, Object>> cacheMontos = (Map<String, Map<String, Object>>) cacheListas.get("cacheMontos");
	  Map<String, Map<String, Object>> cacheCondicionesTransaccion = (Map<String, Map<String, Object>>) cacheListas.get("cacheCondicionesTransaccion");
	  Map<String, List<Map<String, Object>>> cacheFacturas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturas");

      //empezamos a trabajar con las listas obtenidas anteriormente
      //declaracion.put("lstFormBProveedor", proveedores);
      //declaracionActual.put("lstFormBProveedor", lstActualProveedor);

      if (proveedores != null && proveedores.size() > 0) {
          declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
      } else {
          declaracionActual.put("IND_FORMBPROVEEDOR", "1");
      }

      if (proveedores != null) {
    	  for (Map<String, Object> proveedor : proveedores) {
    		  Object numeroSecuenciaProveedor = getValue(proveedor, "num_secprove");//al parecer esta en minusculas
    		  String key = numeroSecuenciaProveedor.toString();

    		  Map<String, Object> montosByProveedor = cacheMontos.get(key);
    		  Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(key);
    		  List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(key);

			  //carga montos asociados a cada proveedor
    		  if (montosByProveedor != null && !montosByProveedor.isEmpty()) {
    			  proveedor.put("mapFormBMonto", montosByProveedor);
    		  }
			  //carga condiciones de transaccion asociados a cada proveedor
    		  if (condicionesTransaccionByProveedor != null && !condicionesTransaccionByProveedor.isEmpty()) {
    			  proveedor.put("mapCondicionTransa", condicionesTransaccionByProveedor);
    		  }
			  //carga facturas asociadas a cada proveedor
    		  if (facturasByProveedor != null && !facturasByProveedor.isEmpty()) {
    			  proveedor.put("lstComproBPago", facturasByProveedor);
    		  }
    	  }
    	  for (Map<String, Object> proveedor : proveedores) {
    		  List<Map<String, Object>> facturasByProveedor = (List<Map<String,Object>>) proveedor.get("lstComproBPago");
    		  //verificamos si es que el proveedor tiene facturas asociadas
    		  if (facturasByProveedor != null) {
    		  for (Map<String, Object> factura : facturasByProveedor) {
				  Object numeroSecuenciaProveedorByFactura = getValue(factura, "NUM_SECPROVE");
				  Object numeroSecuenciaFactura = getValue(factura, "NUM_SECFACT");

					  String keyFactura = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
					  List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(keyFactura);
					  factura.put("lstItemFactura", itemsFacturaByFactura);

					  //verificamos si es que la factura tiene items asociados
					  if (itemsFacturaByFactura != null && !itemsFacturaByFactura.isEmpty()) {
				  //inicio carga itemsfactura por cada factura de proveedor
						  for (Map<String, Object> itemFactura : itemsFacturaByFactura) {
					  Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
					  Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");
					  Object numeroItemByItem = getValue(itemFactura, "NUM_SECITEM");

						  //formateamos el numero de secuencia de observacion y la observacion
						  Object observacionAsObject = getValue(itemFactura, "OBSERVACION");
						  if (observacionAsObject != null) {
							  String[] observacionSplit = observacionAsObject.toString().split("-");
							  String secuenciaObservacion = observacionSplit[0];
							  String observacion = observacionSplit[1];
							  itemFactura.put("OBSERVACION", observacion);
							  itemFactura.put("NUM_SECOBS", secuenciaObservacion);//averiguar en que formato lo usan... por el momento se llena como string...
						  }
						  //inicio copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional
						  String IND_REGISTRO_GRABADO = "0";
						  String DES_REGISTRO_GRABADO = "Adicionado";
						  itemFactura.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);//valor: "0" (Adicionado)
						  itemFactura.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);//valor: "Adicionado"
						  itemFactura.put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
						  itemFactura.put("IND_DESCMANTITEM", "0");//valor: "0" (no muestra descripcion)
						  if (itemFactura.get("IND_DEL").equals("1")) {
							  itemFactura.put("ELIMINADO_PERMANENTE", "BD");
						  } else {
							  itemFactura.put("ELIMINADO_PERMANENTE", "");
						  }
						  //fin copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional

							  String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem + "-" + numeroItemByItem;
							  List<Map<String, Object>> registrosFobProvisionalByItemFactura = cacheFobProvisional.get(key);
							  List<Map<String, Object>> seriesItemsByItemFactura = cacheSeriesItem.get(key);
							  List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);

						  //carga vfobprovisional, seriesItems y descripciones minimas por itemfactura
							  cargarDatosItemFacturaEnLista(itemFactura, registrosFobProvisionalByItemFactura, "lstVfobProvisional");
							  cargarDatosItemFacturaEnLista(itemFactura, seriesItemsByItemFactura, "lstSeriesItem");
							  cargarDatosItemFacturaEnLista(itemFactura, descripcionesMinimasByItemFactura, "lstDecrMinima");

						  //carga referenciaDuda por itemfactura.... pendiente... al parecer ya se quito la consulta a referenciaDuda en el pase 399... verificar
					  }
				  }
				  //fin carga itemsfactura por cada factura de proveedor

				  //carga facturas sucesivas
			          String key = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
					  List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
					  cargarDatosFacturaEnLista(factura, facturasSucesivasByFactura, "lstFactuSucesivas");
	    		  }
    		  }
		  }
      }
      if (proveedores != null) {
    	 // List<Map> lstActualProveedor = Utilidades.copiarLista(proveedores);
          //amancilla
          List<Map<String, Object>> dstList1 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
          List<Map<String, Object>> dstList2 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
          declaracion.put("lstFormBProveedor", dstList1);
          declaracionActual.put("lstFormBProveedor", dstList2);
      }
      //gdlr: se carga en sesion un indicador de formato b cargado
      WebUtils.setSessionAttribute(request, "formatoBCargado", true);
      log.info("Fin metodo cargaFormatoBCompletoNew");
  }

  /**
   * Carga la informacion de formato B de forma optimizada.
   * @param numeroCorrelativoAsObject numero correlativo de la dua
   * @param declaracionActual map con los datos de dua
   * @param request objeto request
   * @return informacion cargada de formato B en un HashMap
   */
  private Map<String, Object> cargarInformacionFormatoB(Object numeroCorrelativoAsObject, Map<String, Object> declaracionActual, HttpServletRequest request) {
	  Long numeroCorrelativo = new Long(numeroCorrelativoAsObject.toString());
	  boolean mostrarItemsEliminados = validarMostrarItemsEliminados(declaracionActual, request);

	  //Unico map de parametros con el NUM_CORREDOC
	  Map<String, Object> parametros = new HashMap<String, Object>();
	  parametros.put("NUM_CORREDOC", numeroCorrelativo);

	  Map<String, Object> parametrosItemFactura = new HashMap<String, Object>();
	  parametrosItemFactura.put("NUM_CORREDOC", numeroCorrelativo);
	  if (mostrarItemsEliminados) {
		  parametrosItemFactura.put("incluirEliminados", "true");
	  }
	  //1. FORMBPROVEEDOR
	  List<Map> proveedores = formatoValorService.obtenerFVProveedores(parametros);

	  //2. FORMBMONTO
	  List<Map<String,Object>> montos = formatoValorService.obtenerMontosFormBByDocumento(parametros);
	  //3. CONDICION_TRANSA
	  List<Map<String,Object>> condicionesTransaccion  = formatoValorService.obtenerCondicionTransaccionFormBByDocumento(parametros);
	  //4. COMPROB_PAGO
	  List<Map<String, Object>> facturas = formatoValorService.obtenerFacturasProveedor(parametros);
	  //5. ITEMFACTURA
	  List<Map<String, Object>> itemsFactura = formatoValorService.obtenerItemsFacturaByDocumento(parametrosItemFactura);
	  //6. OBSERVACION... no es necesario
	  //parametros.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
	  //List<Map<String, Object>> observaciones = null;
	  //7. VFOBPROVISIONAL
	  List<Map<String, Object>> registrosFobProvisional = formatoValorService.obtenerFobProvisionalByDocumento(parametros);
	  //8. SERIES_ITEM
	  List<Map<String, Object>> seriesItems = serieService.obtenerSeriesItemByDocumento(parametros);
	  //9. FACTUSUCE
	  List<Map<String, Object>> facturasSucesivas = formatoValorService.selectFactuSuce(parametros);
	  //10. FORMBITEMDESCRI
	  List<Map<String, Object>> descripcionesMinimas = formatoValorService.selectFormbItemDescri(parametros);
      logger.info("realizadas todas las consultas");

      //glazaror... inicio agrupamiento
      //1. Agrupamos la lista itemsFactura por factura... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheItemFactura = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> itemFactura : itemsFactura) {
		  Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
		  Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");

		  String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem;
		  List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(key);
		  if (itemsFacturaByFactura == null) {
			  itemsFacturaByFactura = new ArrayList<Map<String, Object>>();
			  cacheItemFactura.put(key, itemsFacturaByFactura);
		  }
		  itemsFacturaByFactura.add(itemFactura);
      }
      //2. Agrupamos la lista registrosFobProvisional por itemfactura... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheFobProvisional = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> registro : registrosFobProvisional) {
    	  Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
          Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
          Object numeroItem = registro.get("NUM_SECITEM");

          String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
		  List<Map<String, Object>> fobsProvisionalByItemFactura = cacheFobProvisional.get(key);
		  if (fobsProvisionalByItemFactura == null) {
			  fobsProvisionalByItemFactura = new ArrayList<Map<String, Object>>();
			  cacheFobProvisional.put(key, fobsProvisionalByItemFactura);
		  }
		  fobsProvisionalByItemFactura.add(registro);
      }
      //3. Agrupamos la lista seriesItems por itemfactura... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheSeriesItem = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> registro : seriesItems) {
    	  Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
          Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
          Object numeroItem = registro.get("NUM_SECITEM");

          String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
		  List<Map<String, Object>> seriesItemByItemFactura = cacheSeriesItem.get(key);
		  if (seriesItemByItemFactura == null) {
			  seriesItemByItemFactura = new ArrayList<Map<String, Object>>();
			  cacheSeriesItem.put(key, seriesItemByItemFactura);
		  }
		  seriesItemByItemFactura.add(registro);
      }
      //4. Agrupamos la lista descripcionesMinimas por itemfactura... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> registro : descripcionesMinimas) {
    	  Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
          Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
          Object numeroItem = registro.get("NUM_SECITEM");

          String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
		  List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);
		  if (descripcionesMinimasByItemFactura == null) {
			  descripcionesMinimasByItemFactura = new ArrayList<Map<String, Object>>();
			  cacheDescripcionesMinimas.put(key, descripcionesMinimasByItemFactura);
		  }
		  descripcionesMinimasByItemFactura.add(registro);
      }
      //5. Agrupamos la lista facturasSucesivas por factura... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> registro : facturasSucesivas) {
                   Object numeroSecuenciaProveedorPorRegistro = registro.get("NUM_SECPROVE");
                   Object numeroSecuenciaFacturaPorRegistro = registro.get("NUM_SECFACT");

          String key = numeroSecuenciaProveedorPorRegistro + "-" + numeroSecuenciaFacturaPorRegistro;
		  List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
		  if (facturasSucesivasByFactura == null) {
			  facturasSucesivasByFactura = new ArrayList<Map<String, Object>>();
			  cacheFacturasSucesivas.put(key, facturasSucesivasByFactura);
		  }
		  facturasSucesivasByFactura.add(registro);
      }
      //6. Agrupamos la lista montos por proveedor... solo recorremos una vez la lista
      Map<String, Map<String, Object>> cacheMontos = new HashMap<String, Map<String, Object>>();
      for (Map<String, Object> registro : montos) {
          String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
          Map<String, Object> montosByProveedor = cacheMontos.get(numeroSecuenciaProveedor);
		  if (montosByProveedor == null) {
			  montosByProveedor = new HashMap<String, Object>();
			  cacheMontos.put(numeroSecuenciaProveedor, montosByProveedor);
		  }
		  montosByProveedor.put(getValue(registro, "COD_MONTO").toString().trim(), getValue(registro, "MTO_VALOR"));
      }
      //7. Agrupamos la lista condicionesTransaccion por proveedor... solo recorremos una vez la lista
      Map<String, Map<String, Object>> cacheCondicionesTransaccion = new HashMap<String, Map<String, Object>>();
      for (Map<String, Object> registro : condicionesTransaccion) {
          String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
          Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(numeroSecuenciaProveedor);
		  if (condicionesTransaccionByProveedor == null) {
			  condicionesTransaccionByProveedor = new HashMap<String, Object>();
			  cacheCondicionesTransaccion.put(numeroSecuenciaProveedor, condicionesTransaccionByProveedor);
                          }
		  condicionesTransaccionByProveedor.put(getValue(registro, "COD_INDTRANSACCION").toString().trim(), getValue(registro, "IND_TRANSACCION"));
                   }
      //8. Agrupamos la lista facturas por proveedor... solo recorremos una vez la lista
      Map<String, List<Map<String, Object>>> cacheFacturas = new HashMap<String, List<Map<String, Object>>>();
      for (Map<String, Object> registro : facturas) {
          String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
          List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(numeroSecuenciaProveedor);
		  if (facturasByProveedor == null) {
			  facturasByProveedor = new ArrayList<Map<String, Object>>();
			  cacheFacturas.put(numeroSecuenciaProveedor, facturasByProveedor);
            }
		  facturasByProveedor.add(registro);
      }
      //glazaror... fin agrupamiento

      //salvamos en un map la informacion agrupada
      Map<String, Object> cacheListas = new HashMap<String, Object>();
      cacheListas.put("proveedores", proveedores);
      cacheListas.put("cacheItemFactura", cacheItemFactura);
      cacheListas.put("cacheFobProvisional", cacheFobProvisional);
      cacheListas.put("cacheSeriesItem", cacheSeriesItem);
      cacheListas.put("cacheDescripcionesMinimas", cacheDescripcionesMinimas);
      cacheListas.put("cacheFacturasSucesivas", cacheFacturasSucesivas);
      cacheListas.put("cacheMontos", cacheMontos);
      cacheListas.put("cacheCondicionesTransaccion", cacheCondicionesTransaccion);
      cacheListas.put("cacheFacturas", cacheFacturas);

      return cacheListas;
  }

  public ModelAndView actualizarEstadoDeclaracion(HttpServletRequest request, HttpServletResponse response){
	  ModelAndView res = new ModelAndView("jsonView");
	  String codNuevoEstadoDeclaracion = (String)request.getParameter("codNuevoEstadoDeclaracion");
		try{
			Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
			params.put("COD_ESTDUA", codNuevoEstadoDeclaracion);
			declaracionService.updateDeclaracion(params);
			res.addObject("result","OK");
		} catch (Exception e) {
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			res.addObject("beanM", rBean);
		}
		return res;

  }


  /**
   * Pre-Condicion : Registro de datos de la Diligencia (Multas,Incidencias,etc)
   * y Click Boton Grabado de la Diligencia. Proceso : Metodo que realiza la
   * validacion previa al grabado de la DILIGENCIA
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView(this.jsonView)
   */
  public ModelAndView evalEjecVerificacion(HttpServletRequest request, HttpServletResponse response){
    ModelAndView res = new ModelAndView(this.jsonView);
    Map dataForm = new HashMap();
    try
    {
    	Map<String, Object> declaracionActual = (Map<String, Object>)WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    	// Agregado para reorden de series
    	Map<String, Object> parametros = new HashMap();
    	parametros.put("mapCabDeclaraActual", declaracionActual);
    	// quitar pendientes,eliminados detDeclara
    	List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
    	List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
    	List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
    	List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
    	List<Map<String, Object>> lstFacturasSerie = (ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerie");
    	List<Map<String, Object>> lstFacturasSerieActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerieActual");

	  	//inicio gdlr: verificamos si es que formato b ya ha sido cargado
	  	if (!isFormatoBCargado(request)) {
	  		Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	  		cargaFormatoBCompletoNew(declaracion, declaracionActual, request);
	  	}

	    if(CollectionUtils.isEmpty(lstDetDeclara)){
	        cargarSeriesSesion(request);
	        lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
	    	lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");

	    }



	    if(CollectionUtils.isEmpty(lstSeriesItemActual)){
	    	lstSeriesItemActual = Utilidades.copiarLista((List) lstSeriesItem);
	    }

	    if (lstFacturasSerie == null){
			HashMap<String, Object> mapaNumCorreDoc = new HashMap<String, Object>();
			mapaNumCorreDoc.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
			lstFacturasSerie = formatoValorService.obtenerFacturasSerie(mapaNumCorreDoc);
			WebUtils.setSessionAttribute(request, "lstFacturasSerie", lstFacturasSerie);
        }

        if (WebUtils.getSessionAttribute(request, "lstFacturasSerieActual") == null &&
            !CollectionUtils.isEmpty(lstFacturasSerie)){
        	WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerie);
        }


	    parametros.put("lstDetDeclaraActual", lstDetDeclara);
	    parametros.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
	    parametros.put("lstSeriesItemActual", lstSeriesItemActual);
	    parametros.put("lstSeriesItem", lstSeriesItem);
	    parametros.put("caduana", soporteService.obtenerAduana(request));
	    parametros.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));

	    actualizandoSerieAndSeriesItem(parametros);

	    if("0".equals(declaracionActual.get("IND_FORMBPROVEEDOR").toString())){
    	  this.actualizarIdDeItemFactura(parametros);
	    }

	    //lalberti verificar este valor si se usa
	   /* Date fecha=null;
	    try {
			String fechaDiligencia = request.getParameter("fechaValido");
			if(fechaDiligencia!=null){
				fecha = new Date(fechaDiligencia);
			}else{
				fecha = new Date();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}*/

	    /* amancilla no seva usar
	    Map<String, Object> paramsDua = new HashMap<String, Object>();
	    paramsDua.put("codigoAduana", declaracionActual.get("COD_ADUANA").toString());
	    paramsDua.put("annoPresentacion", declaracionActual.get("ANN_PRESEN").toString());
	    paramsDua.put("codigoRegimen", declaracionActual.get("COD_REGIMEN").toString());
	    paramsDua.put("numeroDeclaracion", declaracionActual.get("NUM_DECLARACION").toString());
	    DUA datosDUA = declaracionService.buscarDUA(paramsDua);
	    res.addObject("success", false);
	    //Verifica si es regimen 20 o 21
	    if(esRegimenValidoModiFechaVencRegimen(declaracionActual.get("COD_REGIMEN").toString())){
	  	  if(!validarFechaVencimientoRegimen(datosDUA, fecha).isEmpty()){
	  		  res.addObject("messagesRtc", validarFechaVencimientoRegimen(datosDUA, fecha));//Elvbis fecha diligencia
	      	  res.addObject("success", true);
	      	  return res;
	  	  }

	    }else if("70".equals(declaracionActual.get("COD_REGIMEN").toString())){//regimen  70
	      String tiempoPlazo = request.getParameter("tiempoPlazo");
	      Integer plazo = Integer.parseInt(request.getParameter("plazo").toString());
	  	  if(!validarFechaNumeracionDeclaracion(datosDUA, fecha , plazo , tiempoPlazo).isEmpty()){
	      	  res.addObject("messagesRtc", validarFechaNumeracionDeclaracion(datosDUA, fecha , plazo , tiempoPlazo));
	      	  res.addObject("success", true);
	      	  return res;
	  	  }

	    }*/
	    //fin lalberti


	    /*No se valida la via de transporte porque es campo no editable
	    if(!declaracionActual.get("COD_VIATRANS").equals("0")){
	    	mensajeDif= diligenciaService.validarViaTranspDiferentePostal(declaracionActual,lstDetDeclara);
	    }else{
	    	declaracionActual.put("mapCabDeclaraActual", declaracionActual);
	    	declaracionActual.put("lstDetDeclaraActual", lstDetDeclara);
	    	mensajeIgu =  diligenciaService.validarViaTranspIgualPostal(declaracionActual);
	    }
	    */


      request.getSession().setAttribute("mapCabDeclaraActual", parametros.get("mapCabDeclaraActual"));
      request.getSession().setAttribute("lstDetDeclaraActual", parametros.get("lstDetDeclaraActual"));
      request.getSession().setAttribute("lstSeriesItemActual", parametros.get("lstSeriesItemActual"));


      DeclaracionCalculoDeDatosService declaracionCalculoDeDatos = fabricaDeServicios.getService("diligencia.DeclaracionCalculoDeDatosService");
      List<Map<String, Object>> lstDocTransporteProrratear = declaracionCalculoDeDatos.obtenerDocTransporteAProrratearDesdeSeries((List) lstDetDeclara);
      request.setAttribute("lstDocTransporteProrratear", lstDocTransporteProrratear);
      String resValidacion = this.validaGrabaDeclaSesion(request, dataForm, declaracionActual, true); //RIN-13

      if (SunatStringUtils.isEmpty(resValidacion)){
        List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");

          Map prmtVal = new HashMap();
          prmtVal.put("mapCabDeclara", declaracionActual);
          prmtVal.put("lstDetDeclara", lstDetDeclaraActual);
          prmtVal.put("lstFacturasSerie", WebUtils.getSessionAttribute(request, "lstFacturasSerieActual")); //se trae todas las facturas (BD + agregadas/modificadas)
          prmtVal.put("codTransaccion",
                      declaracionActual.get("COD_REGIMEN").toString().trim() + ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION);
          GetDeclaracionHashMapToDeclaracionObjectHelper transformHelper = fabricaDeServicios.getService("diligencia.ingreso.transformHelper");
          Declaracion decla = transformHelper.transformDiligenciaConclusionDespacho(prmtVal);
          Map<String, Object> variablesIngreso = new HashMap();

          List listConvenioSerie = new ArrayList();
          List<Map<String, Object>> lstDetDeclaraActualConvenio =
                  (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                                                                           request,
                                                                           "lstDetDeclaraActual");
          for (Map<String, Object> detDeclaraMap : lstDetDeclaraActualConvenio)
          {
              if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
              {
                  detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
              }
              if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
              {
                  List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
                  for (int i = 0; i < lstConvenioSerie.size(); i++)
                  {
                      HashMap convenio = (HashMap) lstConvenioSerie.get(i);
                      listConvenioSerie.add(convenio);
                  }
              }
          }

          variablesIngreso.put("listConvenioSerie", listConvenioSerie);
          variablesIngreso.put("codTransaccion", "12");


          ValidaContingentesService validaContingenteService = fabricaDeServicios.getService("declaracion.validaContingentesService");
          //RSV PAS20165E220200076
          List lstValidacion = validaContingenteService.procesarDiligencia(decla, variablesIngreso , 0);
          if (lstValidacion == null || lstValidacion.size() == 0)
          {
            declaracionActual.putAll(dataForm);
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

            if (Constantes.REGIMEN_70_DEPOSITO.equals((String) declaracion.get("COD_REGIMEN")))
            {
              res.addObject("validar", false);
            }
            else
            {
              res.addObject("validar", true);
            }


            Map<String, Object> params = new HashMap();
            params.put("lstDetDeclaraActual", lstDetDeclaraActual);
            params.put("lstDetDeclara",
                       (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclara"));
            serieService.cargarSubElementosSerie(params);
            WebUtils.setSessionAttribute(request, "lstDetDeclara", params.get("lstDetDeclara"));
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", params.get("lstDetDeclaraActual"));
          }
          else
          {
        	  MensajeBean rBean = new MensajeBean();
              rBean.setError(true);
              rBean.setMensajeerror(SojoUtil.toJson(lstValidacion));
              rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
              log.error(this.toString() + " evalEjecVerificacion - ERROR : " + resValidacion);

              res.addObject("recOk", false);
              res.addObject("mensajeRespuesta", "No se registro la diligencia");
              res.addObject("resValidacion", SojoUtil.toJson(lstValidacion));

          }
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror(resValidacion);
        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
        log.error(this.toString() + " evalEjecVerificacion - ERROR : " + resValidacion);
        res.addObject("beanM", rBean);
      }
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      res.addObject("beanM", rBean);
    }
    finally
    {
      return res;
    }

  }

  private void cargarSeriesSesion(HttpServletRequest request)
  {
    // Cargamos las series en sesion
    List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                                                                                                       "lstDetDeclaraActual");

    if (CollectionUtils.isEmpty(lstDetDeclara))
    { // si esta vacio o null obtener de BD
      Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      Map<String, String> params = new HashMap<String, String>();
      params.put("documentoAduanero", COD_DOCUMENTO_ADUANERO);
      params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString().trim());
      params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString().trim());
      params.put("cod_aduana", declaracion.get("COD_ADUANA").toString().trim());
      params.put("ann_presen", declaracion.get("ANN_PRESEN").toString().trim());
      params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString().trim());
      params.put("acceso", "");
      lstDetDeclara = serieService.obtenerListadoSeries(params);

      WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
      List lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
      lstDetDeclaraActual = Utilidades.copiarLista((List) lstDetDeclara);
      WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
    }
  }

	private boolean esRegimenValidoModiFechaVencRegimen(String tipoRegimen){
	  String[] regimenValidos = { "20", "21" };
	  return Arrays.asList(regimenValidos).contains(tipoRegimen);
	}

	 /**
	 * Valida los datos de la declaracion validaciones: el datado, las sumatoria de
	 * los series con la cabecera, y llena Map dataForm con los datos actualizados.
	 * el metodo es invocado al momento de grabar la diligencia se ejecuta el
	 * proceso de prorrateo de flete y seguro nuevamente se supone que si se realizo
	 * este proceso en la declaracion los datos de la listado de series ya esta
	 * cuadrados pero si fueron directamente a grabar la diligencia se espera que
	 * este metodo valide y prorrate
	   *
	   * @param request
	   *          the request
	   * @param dataForm
	   *          the data form
	   * @return String mensaje de validacion
	   * @throws ServletException
	   *           the servlet exception
	   * @throws IOException
	   *           Signals that an I/O exception has occurred.
	   * @version 1.0
	   */
	  private String validaGrabaDeclaSesion(HttpServletRequest request, Map dataForm, Map<String, Object> declaracionActual, boolean isGrabadoDiligencia) throws ServletException, IOException
	  {

	    String res = "";
	    // Obtenemos los cambios en la declaracion
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    if (null == dataForm)
	    {
	      dataForm = new HashMap();
	    }

	    dataForm.put(
	        "MTO_TOTFOBDOL",
	        new Double(("".equals(webRequest.getParameter("txt_mto_totfobdol").toString().trim()) ? "0" : webRequest
	                                                                                                                  .getParameter("txt_mto_totfobdol"))));
	    dataForm.put(
	        "MTO_TOTFLETEDOL",
	        new Double(("".equals(webRequest.getParameter("txt_mto_totfletedol").toString().trim()) ? "0" : webRequest
	                                                                                                                    .getParameter("txt_mto_totfletedol"))));
	    dataForm.put("MTO_TOTSEGDOL", new Double(("".equals(webRequest.getParameter("txt_mto_totsegdol")) ? "0"
	                                                                                    : webRequest.getParameter("txt_mto_totsegdol"))));
	    dataForm.put(
	        "MTO_TOTAJUSTESDOL",
	        new Double(("".equals(webRequest.getParameter("txt_mto_totajustesdol").toString().trim()) ? "0" : webRequest
	                                                                                                                      .getParameter("txt_mto_totajustesdol"))));
	    dataForm.put(
	        "MTO_TOTOTROSAJUSTE",
	        new Double(("".equals(webRequest.getParameter("txt_mto_tototrosajuste").toString().trim()) ? "0" : webRequest
	                                                                                                                       .getParameter("txt_mto_tototrosajuste"))));
	    dataForm.put(
	        "MTO_TOTVALORADU",
	        new Double(("".equals(webRequest.getParameter("txt_mto_totvaloradu").toString().trim()) ? "0" : webRequest
	                                                                                                                    .getParameter("txt_mto_totvaloradu"))));
	    dataForm.put(
	                 "CNT_PESONETO_TOTAL",
	        new Double(("".equals(webRequest.getParameter("txt_cnt_pesoneto_total").toString().trim()) ? "0" : webRequest
	                                                                                                                       .getParameter("txt_cnt_pesoneto_total"))));
	    dataForm.put(
	                 "CNT_PESOBRUTO_TOTAL",
	        new Double(("".equals(webRequest.getParameter("txt_cnt_pesobruto_total").toString().trim()) ? "0" : webRequest
	                                                                                                                        .getParameter("txt_cnt_pesobruto_total"))));
	    dataForm.put(
	                 "CNT_TOTBULTOS",
	        new Double(("".equals(webRequest.getParameter("txt_cnt_totbultos").toString().trim()) ? "0" : webRequest
	                                                                                                                  .getParameter("txt_cnt_totbultos"))));
	    dataForm.put(
	                 "CNT_TQUNIFIS",
	        new Double(("".equals(webRequest.getParameter("txt_cnt_tqunifis").toString().trim()) ? "0" : webRequest
	                                                                                                                 .getParameter("txt_cnt_tqunifis"))));
	    dataForm.put(
	                 "CNT_TQUNICOM",
	        new Double(("".equals(webRequest.getParameter("txt_cnt_tqunicom").toString().trim()) ? "0" : webRequest
	                                                                                                                 .getParameter("txt_cnt_tqunicom"))));

	    //dataForm.put("IND_SOCORRO", webRequest.getParameter("chk_ind_socorro") != null ? "S" : "N");
	    Map declaracionInicial = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	      if (!CollectionUtils.isEmpty(declaracionInicial) && !SunatStringUtils.isEmpty((String) declaracionInicial.get("IND_SOCORRO")))
	      {
	        dataForm.put("IND_SOCORRO",
	                     webRequest.getParameter("chk_ind_socorro") != null ? webRequest.getParameter("chk_ind_socorro")
	                                                                       : declaracionInicial.get("IND_SOCORRO"));
	      }


	    dataForm.put("COD_FERIA",
	                 webRequest.getParameter("txt_cod_feria") != null ? webRequest.getParameter("txt_cod_feria") : null);
	    dataForm.put("COD_FERIA_DESC",
	        webRequest.getParameter("txt_cod_feria_desc") != null ? webRequest.getParameter("txt_cod_feria_desc") : null);

	    dataForm.put("OBS_OBS", webRequest.getParameter("taObsObs") != null ? webRequest.getParameter("taObsObs") : null);

	    dataForm.put("COD_ADUDEST", webRequest.getParameter("sel_cod_adudest") != null && !webRequest.getParameter("sel_cod_adudest").equals("")  ? webRequest.getParameter("sel_cod_adudest") : " ");

	    if (webRequest.getParameter("sel_cod_tiptratmerc") != null)
	    {
	      dataForm.put(
	                   "COD_TIPTRATMERC",
	          webRequest.getParameter("sel_cod_tiptratmerc").isEmpty() ? " " : webRequest
	                                                                                       .getParameter("sel_cod_tiptratmerc"));
	    }

	  //P46 EJHM 3006 (modificaciones al listado de indicadores de impugnacion)
	    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals((String) declaracionActual.get("COD_REGIMEN"))  &&
		   (Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) dataForm.get("COD_TIPTRATMERC")) ||
		    Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracionActual.get("COD_TIPTRATMERC"))) ){
	          List<Map<String, Object>> listaIndicador=(List) declaracionActual.get("LIST_INDICADORES_DUA");
	          String sel_indicador_dua="";
	          if(webRequest.getParameter("sel_indicador_dua")!=null && (webRequest.getParameter("sel_indicador_dua").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL)
	        	|| webRequest.getParameter("sel_indicador_dua").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL))){
	        	  sel_indicador_dua=webRequest.getParameter("sel_indicador_dua").toString();
	          }
	          else{
	        	  sel_indicador_dua="00";
	          }
	          dataForm.put("COD_INDICADOR_DONACION", sel_indicador_dua);
		      boolean soloUnoActivo=false;
		      boolean soloInactivo=false;
		           if (!CollectionUtils.isEmpty(listaIndicador) ){

		          		  for (Map<String, Object> indicador : listaIndicador) {
		          			if( !sel_indicador_dua.equals(indicador.get("COD_INDICADOR").toString()) )	{
		          				if (indicador.get("COD_INDICADOR").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL) ){
									if(sel_indicador_dua.equals("00")){ // se elimina logicamente
									indicador.put("IND_ACTIVO", 0);
									soloInactivo=true;
									} else{
									if(!soloUnoActivo){  // se invierte
									indicador.put("COD_INDICADOR", sel_indicador_dua);
		          					indicador.put("COD_INDICADOR_DESC", ConstantesDataCatalogo.IND_DONACION_IMPUGNACION_TOTAL);
									indicador.put("IND_ACTIVO",1);
									soloUnoActivo=true;
									}
									}
		          					break;
			          			    }
			          			  if (indicador.get("COD_INDICADOR").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL) ){
								     if(sel_indicador_dua.equals("00")){
									indicador.put("IND_ACTIVO", 0);
									soloInactivo=true;
									} else {
									if(!soloUnoActivo){

									 indicador.put("COD_INDICADOR", sel_indicador_dua);
		          					 indicador.put("COD_INDICADOR_DESC", ConstantesDataCatalogo.IND_DONACION_IMPUGNACION_PARCIAL);
									 indicador.put("IND_ACTIVO",1);
									 soloUnoActivo=true;
									}
			          				break;
			          			   }
		          			}

		            }
		          	else
		          	if( sel_indicador_dua.equals(indicador.get("COD_INDICADOR").toString()) && indicador.get("IND_ACTIVO").toString().equals("1"))	{
		          			soloUnoActivo=true;
		          	}

	             }
		       }
		        if(!soloUnoActivo && !soloInactivo  && !sel_indicador_dua.equals("00")){ // es un indicador nuevo
		        	listaIndicador=listaIndicador==null? new ArrayList<Map<String, Object>>():listaIndicador;
		        	Map<String, Object> indicador= new  HashMap<String, Object>();
		        	indicador.put("COD_INDICADOR", sel_indicador_dua);
		        	indicador.put("codTiporegistro", "P");
		        	indicador.put("IND_ACTIVO",1);
		        	listaIndicador.add(indicador);
		        }

	   } else { // porsiacaso le seteamos 00
		   dataForm.put("COD_INDICADOR_DONACION", "00");
	   }

	  //FIN P46 EJHM

	    if (webRequest.getParameter("sel_cod_produrgente") != null)
	    {
	      dataForm.put(
	                   "COD_PRODURGENTE",
	          webRequest.getParameter("sel_cod_produrgente").isEmpty() ? " " : webRequest
	                                                                                       .getParameter("sel_cod_produrgente"));
	    }
	    //RIN-13
	    /*if (webRequest.getParameter("txt_cod_tiplugarrecep") != null)
	    {
	      dataForm.put(
	                   "COD_TIPLUGARRECEP",
	          webRequest.getParameter("txt_cod_tiplugarrecep").isEmpty() ? " " : webRequest
	                                                                                         .getParameter("txt_cod_tiplugarrecep"));
	    }*/
	    dataForm.put("COD_MODALIDAD", webRequest.getParameter("sel_cod_modalidad") != null ? webRequest.getParameter("sel_cod_modalidad"): " ");

	    /*if (webRequest.getParameter("sel_cod_tipdesp") != null)
	    {
	    	dataForm.put("COD_TIPDESP", (webRequest.getParameter("sel_cod_tipdesp").isEmpty()) ? " " : webRequest.getParameter("sel_cod_tipdesp"));
	    }*/

	    if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals((String) declaracionActual.get("COD_REGIMEN"))
	            || Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals((String) declaracionActual.get("COD_REGIMEN"))) {
	          if (webRequest.getParameter("sel_cod_tipdesp") != null)
	            dataForm.put("COD_TIPDESP", webRequest.getParameter("sel_cod_tipdesp"));
	          if (webRequest.getParameter("hdn_cod_tipdesp_desc") != null)
	            dataForm.put("COD_TIPDESP_DESC", webRequest.getParameter("hdn_cod_tipdesp_desc"));
		}

	    dataForm.put("COD_TIPLUGARRECEP", webRequest.getParameter("sel_cod_tiplugarrecep") != null ? webRequest.getParameter("sel_cod_tiplugarrecep") : " ");

	    String codigoLugarRecep = webRequest.getParameter("sel_cod_lugarrecep");

	    if(StringUtils.isNotEmpty(codigoLugarRecep)){
	    	dataForm.put("COD_LUGARRECEP", codigoLugarRecep);
	    	//pase 15-252
//	        if("6".equals(codigoLugarRecep) || "2".equals(codigoLugarRecep) || "1".equals(codigoLugarRecep) || "3".equals(codigoLugarRecep)){ //31 Deposito Temporal � 32 Deposito Aduanero
	    		String numeroDocumentoIdentidad = webRequest.getParameter("txt_num_docident_pdf_31") != null ? webRequest.getParameter("txt_num_docident_pdf_31") : " ";
	    		dataForm.put("COD_RUCLUGRECEP", numeroDocumentoIdentidad);
	    		dataForm.put("NUM_DOCIDENT_PDF", numeroDocumentoIdentidad);
//	    	}else{
	    		//codigoLugarRecep:  9
//	    		dataForm.put("COD_RUCLUGRECEP", declaracionActual.get("NUM_DOCIDENT_PIM")); //45 Importador
//	    	}

	    }else{
	    	dataForm.put("COD_LUGARRECEP", " ");
	    }
	    //dataForm.put("COD_LUGARRECEP", (webRequest.getParameter("sel_cod_lugarrecep") != null) ? webRequest.getParameter("sel_cod_lugarrecep") : " ");
	    dataForm.put("COD_LOCALANEXO", webRequest.getParameter("txt_cod_localanexo") != null ? webRequest.getParameter("txt_cod_localanexo") : " ");
	    //RIN-13

	    String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);



	    //Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual"); //RIN-13
	    List<String> lstSeriesRecti = declaracionActual.get("lstSeriesRecti") != null ? ((ArrayList<String>) declaracionActual
	                                                                                                                         .get("lstSeriesRecti"))
	                                                                                 : null;
	    /*RIN-13 como ya se esta invocando a servicios de validaci�n verificar si a�n corresponde realizar las sgtes validaciones:*/
	    if (!isGrabadoDiligencia) //RIN-13 se quito del grabado final de la diligencia de despacho porque la validaci�n ya se realiza por servicio
	    {
		    if ("".equals(res))
		    {
		      res = validaSeriesItemsFactura(declaracionActual,
		                                          (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
		    }
	    }
	    if ("".equals(res))
	    {
	      res = validaSeriesCambioEstadoMercancia(declaracionActual,
	                                                   (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara"),
	                                                   (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
	    }

	    if ("".equals(res))
	    {
	      res = this.validaSeries(
	                              dataForm,
	                              (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"),
	                              lstSeriesRecti,
	                              request);
	    }
	    if ("".equals(res))
	    {
	    	MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");
	    	res = mercanciaRestringidaEntidadService.validaRucDocAutorizaIQBF(declaracionActual);
	    }

	    return res;
	  }


	  /**
	   * Metodo que valida los datos de las series.
	   *
	   * @param newData
	   *          datos de la cabecera formulario declaracion
	   * @param lstSeries
	   *          the lst series
	   * @param lstSeriesRecti
	   *          the lst series recti
	   * @param request
	   *          the request
	   * @return the string
	   */
	  private String validaSeries(Map<String, Object> newData,List<Map<String, Object>> lstSeries,List<String> lstSeriesRecti,HttpServletRequest request)
	  {
	    StringBuilder res = new StringBuilder("");
	    DeclaracionCalculoDeDatosService declaracionCalculoDeDatos = fabricaDeServicios.getService("diligencia.DeclaracionCalculoDeDatosService");

	    if (!CollectionUtils.isEmpty(lstSeries))
	    {
	      Map mapSerie;
	      double dbl_mto_fobdol = 0;
	      double dbl_mto_fletedol = 0;
	      double dbl_mto_segdol = 0;
	      double dbl_mto_ajuste = 0;
	      double dbl_mto_ajuste_otr = 0;
	      double dbl_mto_valoradu = 0;
	      double dbl_cnt_peso_neto = 0;
	      double dbl_cnt_peso_bruto = 0;
	      double dbl_cnt_bulto = 0;
	      double dbl_cnt_unifis = 0;
	      double dbl_cnt_comer = 0;

	      //ESTE DATO VIENE DEL ITENFACTURA O DE CAB_DECLARA
	      List<Map<String, Object>> lstDocTransporteProrratear =request.getAttribute("lstDocTransporteProrratear")!=null?(ArrayList) request.getAttribute("lstDocTransporteProrratear"):null;

	      List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte =new ArrayList<SumaFleteYPesoPorDocTransporteBean>();
	      // los valores de la cabcera PASE578
	      //solo si tiene datos prorratea en la cabcecera prorratea solo sio hay cambios en el MTO_TOTFLETE DEL CAB_DECLARA
	      //Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	      if (!CollectionUtils.isEmpty(lstDocTransporteProrratear))
	      {
	          SumaFleteYPesoPorDocTransporteBean tablaFletePeso;
	          String docTransporte;
	          BigDecimal sumaFleteAProrratear;
	          for (Map docTransporteProrratear : lstDocTransporteProrratear)
	          {
	            docTransporte = docTransporteProrratear.get("docTransporte").toString();
	            sumaFleteAProrratear = Utilidades.toBigDecimal(docTransporteProrratear.get("sumaFleteAProrratear"));

	            tablaFletePeso = new SumaFleteYPesoPorDocTransporteBean(docTransporte, sumaFleteAProrratear);
	            lstSumaFleteYPesoPorDocTransporte.add(tablaFletePeso);
	          }
	          lstSeries = declaracionCalculoDeDatos.prorratearFlete(lstSeries, lstSumaFleteYPesoPorDocTransporte);
	       }
	        BigDecimal mtoTotalFOBDolDeLaDeclaracion = Utilidades.toBigDecimal(newData.get("MTO_TOTFOBDOL"));
	        BigDecimal mtoSeguroProrratear = Utilidades.toBigDecimal(newData.get("MTO_TOTSEGDOL"));

	        Map mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	        Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION")
	                                                                                         .toString());

	        lstSeries = declaracionCalculoDeDatos.prorratearMtoSeguroEnLasSeries(mtoSeguroProrratear,
	                                                                             mtoTotalFOBDolDeLaDeclaracion,
	                                                                             fechaVigenciaPartida,
	                                                                             lstSeries);

	      int contadorSeriesActivas = 0;

	      for (int i = 0; i < lstSeries.size(); i++)
	      {
	        mapSerie = (HashMap) lstSeries.get(i);

	        // debido a que prorrrateo en esta parte el valor en aduanas de las
	        // serie no sera el valor correcto
	        // por ello recalculo y lo seteo para el caso de las eliminadas tambien
	        double bd_mto_fobdol1 = Double.valueOf(mapSerie.get("MTO_FOBDOL").toString());
	        double bd_mto_fletedol1 = Double.valueOf(mapSerie.get("MTO_FLETEDOL").toString());
	        double bd_mto_segdol1 = Double.valueOf(mapSerie.get("MTO_SEGDOL").toString());
	        double bd_mto_ajuste1 = Double.valueOf(mapSerie.get("MTO_AJUSTE").toString());
	        double bd_mto_ajuste_otr1 = Double.valueOf(mapSerie.get("MTO_OTROSAJUSTES").toString());

	        BigDecimal bd_mto_valoraduProrrateado = SunatNumberUtils.scaleHalfUp(new BigDecimal(bd_mto_fobdol1
	            + bd_mto_fletedol1 + bd_mto_segdol1 + bd_mto_ajuste1 + bd_mto_ajuste_otr1), 3);
	        mapSerie.put("MTO_VALORADU", bd_mto_valoraduProrrateado);

	        if ((Integer.parseInt(mapSerie.get("IND_DEL").toString())) == 0
	            && mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_GRABADO))
	        {

	          dbl_mto_fobdol = dbl_mto_fobdol + Double.valueOf(mapSerie.get("MTO_FOBDOL").toString());
	          dbl_mto_fletedol = dbl_mto_fletedol + Double.valueOf(mapSerie.get("MTO_FLETEDOL").toString());
	          dbl_mto_segdol = dbl_mto_segdol + Double.valueOf(mapSerie.get("MTO_SEGDOL").toString());
	          dbl_mto_ajuste = dbl_mto_ajuste + Double.valueOf(mapSerie.get("MTO_AJUSTE").toString());
	          dbl_mto_ajuste_otr = dbl_mto_ajuste_otr + Double.valueOf(mapSerie.get("MTO_OTROSAJUSTES").toString());

	          dbl_mto_valoradu = dbl_mto_valoradu + Double.valueOf(mapSerie.get("MTO_VALORADU").toString());
	          dbl_cnt_peso_neto = dbl_cnt_peso_neto + Double.valueOf(mapSerie.get("CNT_PESO_NETO").toString());
	          dbl_cnt_peso_bruto = dbl_cnt_peso_bruto + Double.valueOf(mapSerie.get("CNT_PESO_BRUTO").toString());
	          dbl_cnt_bulto = dbl_cnt_bulto + Double.valueOf(mapSerie.get("CNT_BULTO").toString());
	          dbl_cnt_unifis = dbl_cnt_unifis + Double.valueOf(mapSerie.get("CNT_UNIFIS").toString());
	          dbl_cnt_comer = dbl_cnt_comer + Double.valueOf(mapSerie.get("CNT_COMER").toString());
	          contadorSeriesActivas++;
	        }
	      }


	      // validamos si la cantidad de series activas es la mismas
	      String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);

	      // Validamos las cantidades y montos
	      double dif_mto_fobdol = Double.valueOf(newData.get("MTO_TOTFOBDOL").toString()) - dbl_mto_fobdol;
	      BigDecimal bd_dif_mto_fobdol = new BigDecimal(dif_mto_fobdol);
	      bd_dif_mto_fobdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fobdol, 3);

	      double dif_mto_fletedol = Double.valueOf(newData.get("MTO_TOTFLETEDOL").toString()) - dbl_mto_fletedol;
	      BigDecimal bd_dif_mto_fletedol = new BigDecimal(dif_mto_fletedol);
	      bd_dif_mto_fletedol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fletedol, 3);

	      double dif_mto_segdol = Double.valueOf(newData.get("MTO_TOTSEGDOL").toString()) - dbl_mto_segdol;
	      BigDecimal bd_dif_mto_segdol = new BigDecimal(dif_mto_segdol);
	      bd_dif_mto_segdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_segdol, 3);

	      double dif_mto_ajuste = Double.valueOf(newData.get("MTO_TOTAJUSTESDOL").toString()) - dbl_mto_ajuste;
	      BigDecimal bd_dif_mto_ajuste = new BigDecimal(dif_mto_ajuste);
	      bd_dif_mto_ajuste = SunatNumberUtils.scaleHalfUp(bd_dif_mto_ajuste, 3);

	      double dif_mto_ajuste_otr = Double.valueOf(newData.get("MTO_TOTOTROSAJUSTE").toString()) - dbl_mto_ajuste_otr;
	      BigDecimal bd_dif_mto_ajuste_otr = new BigDecimal(dif_mto_ajuste_otr);
	      bd_dif_mto_ajuste_otr = SunatNumberUtils.scaleHalfUp(bd_dif_mto_ajuste_otr, 3);

	      double dif_mto_valoradu = Double.valueOf(newData.get("MTO_TOTVALORADU").toString()) - dbl_mto_valoradu;
	      BigDecimal bd_dif_mto_valoradu = new BigDecimal(dif_mto_valoradu);
	      bd_dif_mto_valoradu = SunatNumberUtils.scaleHalfUp(bd_dif_mto_valoradu, 3);

	      double dif_cnt_peso_neto = Double.valueOf(newData.get("CNT_PESONETO_TOTAL").toString()) - dbl_cnt_peso_neto;
	      BigDecimal bd_dif_cnt_peso_neto = new BigDecimal(dif_cnt_peso_neto);
	      bd_dif_cnt_peso_neto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_peso_neto, 3);

	      double dif_cnt_peso_bruto = Double.valueOf(newData.get("CNT_PESOBRUTO_TOTAL").toString()) - dbl_cnt_peso_bruto;
	      BigDecimal bd_dif_cnt_peso_bruto = new BigDecimal(dif_cnt_peso_bruto);
	      bd_dif_cnt_peso_bruto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_peso_bruto, 3);

	      double dif_cnt_bulto = Double.valueOf(newData.get("CNT_TOTBULTOS").toString()) - dbl_cnt_bulto;
	      BigDecimal bd_dif_cnt_bulto = new BigDecimal(dif_cnt_bulto);
	      bd_dif_cnt_bulto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_bulto, 3);

	      double dif_cnt_unifis = Double.valueOf(newData.get("CNT_TQUNIFIS").toString()) - dbl_cnt_unifis;
	      BigDecimal bd_dif_cnt_unifis = new BigDecimal(dif_cnt_unifis);
	      bd_dif_cnt_unifis = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_unifis, 3);

	      double dif_cnt_comer = Double.valueOf(newData.get("CNT_TQUNICOM").toString()) - dbl_cnt_comer;
	      BigDecimal bd_dif_cnt_comer = new BigDecimal(dif_cnt_comer);
	      bd_dif_cnt_comer = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_comer, 3);

	      double diferenciaMaximaMonto;
	      double diferenciaMaximaPeso;
	      double diferenciaMaximaCantidad;

	      diferenciaMaximaMonto = Double.valueOf(Constantes.DIF_MAX_MTO);
	      diferenciaMaximaPeso = Double.valueOf(Constantes.DIF_MAX_PESO);
	      diferenciaMaximaCantidad = Double.valueOf(Constantes.DIF_MAX_CANT);



	      if (Math.abs(dif_mto_fobdol) > diferenciaMaximaMonto)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_fobdol)
	           .append(
	                   " entre el monto fob consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_fobdol), 3) + ").");

	      }
	      else if (Math.abs(dif_mto_fletedol) > diferenciaMaximaMonto)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_fletedol)
	           .append(
	                   " entre el monto del flete consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_fletedol), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_mto_segdol) > Constantes.DIF_MAX_MTO)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_segdol)
	           .append(
	                   " entre el monto del seguro consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_segdol), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_mto_ajuste) > diferenciaMaximaMonto)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_ajuste)
	           .append(
	                   " entre el monto de los ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_ajuste), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_mto_ajuste_otr) > Constantes.DIF_MAX_MTO)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_ajuste_otr)
	           .append(
	                   " entre el monto de otros ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_ajuste_otr), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_mto_valoradu) > diferenciaMaximaMonto)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_mto_valoradu)
	           .append(
	                   " entre el valor aduana consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_valoradu), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_cnt_peso_neto) > diferenciaMaximaPeso)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_cnt_peso_neto)
	           .append(
	                   " entre el peso neto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_peso_neto), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_cnt_peso_bruto) > diferenciaMaximaPeso)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_cnt_peso_bruto)
	           .append(
	                   " entre el peso bruto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_peso_bruto), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_cnt_bulto) > diferenciaMaximaCantidad)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_cnt_bulto)
	           .append(
	                   " entre la cantidad de bultos consignada en la diligencia y la acumulada en las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_bulto), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_cnt_unifis) > diferenciaMaximaCantidad)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_cnt_unifis)
	           .append(
	                   " entre la cantidad de unidades fisicas consignada en la diligencia y la acumulada en las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_unifis), 3)
	                       + ").");

	      }
	      else if (Math.abs(dif_cnt_comer) > diferenciaMaximaCantidad)
	      {
	        res.append("Hay una diferencia de ")
	           .append(bd_dif_cnt_comer)
	           .append(
	                   " entre la cantidad de unidades comerciales consignada en la diligencia y la acumulada en las series (sumatoria de series "
	                       + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_comer), 3)
	                       + ").");
	      }

	      if (!"".equals(res.toString().trim()) && lstSeriesRecti != null && lstSeriesRecti.size() > 0)
	      {
	        res.append("\n").append("Se le sugiere revisar y/o confirmar los datos rectificado(s) de la(s) serie(s) : ");

	        for (String codSerie : lstSeriesRecti)
	        {
	          res.append(codSerie).append(", ");
	        }
	        res = new StringBuilder(res.toString().trim().substring(0, (res.toString().trim().length() - 1)));
	      }

	    }
	    else
	    {
	      res.append("No se ha registrado informacion de las series");
	    }

	    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSeries);
	    return (res.toString().trim());
	  }

	  /**
	   * Validar el cambio de estado de mercanc�a de las series.
	   *
	   * @param declaracionActual
	   *          the declaracion actual
	   * @param lstDetDeclara
	   *          the lst det declara
	   * @param lstDetDeclaraActual
	   *          the lst det declara actual
	   * @return String
	   * @author olunar
	   */
	  public String validaSeriesCambioEstadoMercancia(Map declaracionActual, List<Map<String, Object>> lstDetDeclara,
	                                                  List<Map<String, Object>> lstDetDeclaraActual)
	  {
	    String respuesta = "";
	    // Solo para el r�gimen 10
	    if (declaracionActual.get("COD_REGIMEN").toString().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO))
	    {
	      StringBuilder mensaje = new StringBuilder("");
	      String strCapitulo = "";
	      boolean tieneRegPreCeticos;
	      int j = 0;
	      Map<String, Object> serieActual = new HashMap<String, Object>();
	      Map<String, Object> serie = new HashMap<String, Object>();
	      ArrayList<Map> listaRegPre = new ArrayList<Map>();
	      for (int i = 0; i < lstDetDeclaraActual.size(); i++){
	        serieActual = lstDetDeclaraActual.get(i);

	        tieneRegPreCeticos = false;
	        // Para las series modificadas, no las agregadas
	        if (i <= lstDetDeclara.size() - 1){
	          serie = lstDetDeclara.get(i);
	          // Si estado es usado
	          if (SunatStringUtils.isStringInList(serieActual.get("COD_ESTMERC").toString(), "20,21")){
	            // Estado inicial fue nuevo
	            if (SunatStringUtils.isStringInList(serie.get("COD_ESTMERC").toString(), "10,11,12,14,15,16,17")){
	              strCapitulo = SunatStringUtils.lpad(serieActual.get("NUM_PARTNANDI").toString(), 10, '0');
	              strCapitulo = strCapitulo.substring(0, 2);
	              // Si pertenece al cap�tulo 87 de veh�culos
	              if (strCapitulo.equals("87")){
	                listaRegPre = (ArrayList<Map>) serieActual.get("lstDocuPreceDua");
	                // Tiene r�gimen precedente
	                if (!CollectionUtils.isEmpty(listaRegPre)){
	                  for (Map<String, Object> regPre : listaRegPre){
	                    // R�gimen precedente CETICO
	                    if (regPre.get("COD_REGIMENPRE").toString().equals(REGIMEN_PRECEDENTE_CETICO)){
	                      tieneRegPreCeticos = true;
	                    }
	                  }
	                }
	                if (!tieneRegPreCeticos){
	                  // TNAN corresponde no registrado
	                  if (serieActual.get("COD_TIPTASAAPLICAR").toString().trim().equals("")){
	                    if (j > 0)
	                      mensaje.append(", ");
	                    mensaje.append(serie.get("NUM_SECSERIE"));
	                    j++;
	                  }
	                }
	              }
	            }
	          }
	        }
	      }
	      if (j >= 1)
	        respuesta = "Debe registrar el valor del  TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN para la(s) serie(s) ";

	      if (j > 0)
	        respuesta = respuesta + mensaje.toString() + ".";
	    }
	    return respuesta;
	  }

	  /**
	   * Valida datos de �tems asociados a una serie
	   *
	   * olunar - 30-05-2012.
	   *
	   * @param mapCabDeclaraActual
	   *          the map cab declara actual
	   * @param lstDetDeclaraActual
	   *          the lst det declara actual
	   * @return String
	   */
	  private String validaSeriesItemsFactura(Map<String, Object> mapCabDeclaraActual, List<Map<String, Object>> lstDetDeclaraActual)
	  {
	    log.debug("-->INICIO - validaSeriesItemsFactura");
		StringBuilder res = new StringBuilder("");
	    String numSerie = "";
	    String numSerieItem = "";


	    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
	    List<Map<String, Object>> listaItemFacturas = null;
	    List<Map<String, Object>> lstSeriesItem = null;

	    if (lstFormBProveedor != null)
	    {
	      for (Map<String, Object> serie : lstDetDeclaraActual)
	      {
	        numSerie = serie.get("NUM_SECSERIE").toString();
	        //List<String> lstItemsErr = new ArrayList<String>(); //RIN13
	        for (Map<String, Object> proveedor : lstFormBProveedor)
	        {
	          if (proveedor.get("lstComproBPago") != null)
	          {
	            for (Map<String, Object> factura : (List<Map<String, Object>>) proveedor.get("lstComproBPago"))
	            {
	              listaItemFacturas = factura.get("lstItemFactura")!=null?(List<Map<String, Object>>) factura.get("lstItemFactura"):new ArrayList<Map<String, Object>>();

	              for (Map<String, Object> itemFactura : listaItemFacturas)
	              {
	                lstSeriesItem = (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
	                if (lstSeriesItem != null)
	                {
	                  for (Map<String, Object> itemSerie : lstSeriesItem)
	                  {
	                	if(itemSerie.get("IND_DEL").toString().equals("0")){
	                    numSerieItem = itemSerie.get("NUM_SECSERIE").toString();
	                    if (numSerieItem.equals(numSerie))
	                    {
	                      if (!serie.get("COD_ESTMERC").toString().equals(itemFactura.get("COD_ESTMERC").toString()))
	                      {
	                    	res.append("NUMERO SERIE: " + numSerie + ", NUMERO ITEM:" + itemFactura.get("NUM_SECITEM").toString() + " MENSAJE: ESTADO DE LA MERCANCIA DEL FORMATO A " + serie.get("COD_ESTMERC").toString() + " ES DIFERENTE AL ESTADO DEL ITEM CORRELACIONADO DEL FORMATO B " + itemFactura.get("COD_ESTMERC").toString());
	                  		res.append("\n");
	                      }
	                    }
	                	}
	                  }
	                }
	              }
	            }
	          }
	        }
	      }
	    }
	    return res.toString();
	  }

	/**
	  *
	   * M�todo para validar fecha de vencimiento de regimen.
	  * 10/05/2010
	  * Para el regimen 20 y 21
	  * @param dua
	  * @return mensaje
	  */
	  private String validarFechaVencimientoRegimen(DUA dua,Date fechaReferencia){//fecfinacoregimen
		  String mensaje = "";
	      if (! (SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen())>SunatDateUtils.getIntegerFromDate(fechaReferencia))){// Si no es mayor a la fecha de numeracion
	             mensaje=   "La fecha de vencimiento del r�gimen debe ser mayor a la fecha de registro de la diligencia.";
	      }
	      return mensaje;
	  }

	  private String validarFechaNumeracionDeclaracion(DUA datosDUA, Date fecha , Integer plazo , String tiempoPlazo) {
		  String mensaje  ="";
		  Date fechaDeclaracion = datosDUA.getFecdeclaracion();
		  if(tiempoPlazo.equals("D")){//Elvbis dias :Dise�o
			  fechaDeclaracion = SunatDateUtils.addDay(fechaDeclaracion, (Integer) ObjectUtils.defaultIfNull(plazo, 0));
		  }
		  if(tiempoPlazo.equals("M")){//Elvbis meses :Dise�o
			  fechaDeclaracion = SunatDateUtils.addMonth(fechaDeclaracion, (Integer) ObjectUtils.defaultIfNull(plazo, 0));
		  }
		// Si la suma de la fecha de la declaracion mas el tiempo de plazo (meses o dias) es menor a la Fecha de reconocimiento f�sico ingresada por el usuario
		  if ((SunatDateUtils.getIntegerFromDate(fechaDeclaracion)<SunatDateUtils.getIntegerFromDate(fecha))){
	     	 mensaje=   "El plazo de vencimiento del r�gimen 70 debe ser mayor a la fecha de registro de la diligencia";
	      }

		return mensaje;
	}

  /** Retorna un boolean que indica si los items eliminados se van a incluir en la consulta (de acuerdo al estado de la declaraci�n)
   * @param declaracionActual
   * @param request
   * @return
   */
  private boolean validarMostrarItemsEliminados(Map<String, Object> declaracionActual, HttpServletRequest request){

	  boolean indMostrarEliminados = true;
	  String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
	  String estadoDua = declaracionActual.get("COD_ESTDUA").toString();
	  String estadoRectiOficio = "";
    if ("10".equals(tipoDiligencia))
    {
      if (declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
          && "EN_PROCESO".equals(declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
       {
      	estadoRectiOficio = "EN_PROCESO";
       }

    }

    if ((Constantes.ESTADO_RECTI_PROCESO.equals(estadoDua) || "EN_PROCESO".equals(estadoRectiOficio))
  		  && !(tipoDiligencia.equals(Constantes.MODO_DILIGENCIA_CONSULTA))) {

  	  indMostrarEliminados = false;
    }

    return indMostrarEliminados;
}

  private Object getValue(Map<String, Object> datos, String nombre) {
         Object value = datos.get(nombre.toUpperCase());
         if (value == null) {
               value = datos.get(nombre.toLowerCase());
         }
         return value;
  }

  private void cargarDatosItemFacturaEnLista(Map<String, Object> itemFactura, List<Map<String, Object>> registros, String nombreMapa) {
      if (registros != null && !registros.isEmpty()) {
            //si es que existen registros entonces
    	  itemFactura.put(nombreMapa, registros);
      }
  }

  private void cargarDatosFacturaEnLista(Map<String, Object> factura, List<Map<String, Object>> registros, String nombreMapa) {
      if (registros != null && !registros.isEmpty()) {
     	 factura.put(nombreMapa, registros);
      }
  }

//crear el nuevo metodo:
	private boolean isFormatoBCargado(HttpServletRequest request) {
		Boolean formatoBCargado = (Boolean) WebUtils.getSessionAttribute(request, "formatoBCargado");
		return (formatoBCargado != null);
	}

	@Override
	protected String getTipoDiligencia(HttpServletRequest request) {
		return super.getTipoDiligencia(request);
	}

	public ModelAndView actualizarDiligenciaConclusion(HttpServletRequest request, HttpServletResponse response) throws Exception{
		ModelAndView res = new ModelAndView(this.jsonView);
		ServletWebRequest webRequest = new ServletWebRequest(request);
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());
		Map<String,Object> diligenciaActual = (Map<String,Object>)WebUtils.getSessionAttribute(request, "cabDiligenciaActualizar");
		log.info("## diligenciaActual : " + diligenciaActual);
		String descripcion = webRequest.getParameter("txt_des_resultado");
		String esPostLevante = webRequest.getParameter("hdn_Post_Levante")!=null?webRequest.getParameter("hdn_Post_Levante").toString():" ";//adicionado por PAS20165E220200032
		log.info("## descripcion : " + descripcion);
		diligenciaActual.put("DES_RESULTADO", descripcion);

		diligenciaService.insertarDiligencia(diligenciaActual);

		/**Inicio de cambios PAS20165E220200032***/
		String nombDiligencia ="diligencia de Conclusi�n de Despacho";
		if(esPostLevante.equals("1")){
			nombDiligencia ="diligencia de Post Levante";
		}
		/**Fin de cambios PAS20165E220200032***/
		ResponseBean respuesta = new ResponseBean();
		respuesta.setEstadoExitoso(true);
		//respuesta.setMensaje("Se actualizó correctamente el resultado de la Diligencia de Conclusión.");
		respuesta.setMensaje("Se actualiz� correctamente el resultado de la "+nombDiligencia);//modificado por PAS20165E220200032
		res.addObject(respuesta);

		return res;
}

public ModelAndView tieneDiligenciaConclusion(HttpServletRequest request, HttpServletResponse response) throws Exception{
	  ModelAndView res = new ModelAndView("jsonView");
	  UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  Map<String, Object> declaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

	     String mensaje="";
	     if(declaracion.get("FLAG_NUMERO")=="N"){
	 			mensaje = "Diligencia de Conclusi�n fue modificada anteriormente, s�lo puede modificarse una vez ";
	 			res.addObject( "mensaje", mensaje);
	 			return res;
	     }
	     if(declaracion.get("mensaje")!=""){
	 			mensaje = declaracion.get("mensaje").toString();
	 			return res;
	    }

		if (!declaracion.get("codFunTextoModif").equals(bUsuario.getNroRegistro())) {
			 ModelAndView resn = new ModelAndView(this.jsonView);
			mensaje = "Diligencia de Conclusi�n de Despacho s�lo puede ser modificada por el funcionario que la registr�";
			resn.addObject( "mensaje", mensaje);
			return res;
		}
		res.addObject( "mensaje", "OK");
		return res;
}

	private List<Map<String,Object>> obtenerExpedientes(Map<String,Object> declaracion){
		String regimen = declaracion.get("COD_REGIMEN").toString();
		String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();
		String oTipo = new String();

		Map<String, Object> mapPkDua = new HashMap<String, Object>();
	    mapPkDua.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
	    mapPkDua.put("ANN_PRESEN", declaracion.get("ANN_PRESEN"));
	    mapPkDua.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));
	    mapPkDua.put("codi_aduan", declaracion.get("COD_ADUANA"));

	    if(regimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
	    	oTipo = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_DEFINITIVA;
	    }else if(regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)){
	    	oTipo = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_TEMPORAL;
	    }else if(regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)){
	    	oTipo = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_ADMISION_TEMPORAL;
	    }else if(regimen.equals(ConstantesDataCatalogo.REG_DEPOSITO)){
	    	oTipo = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_DEPOSITO;
	    }
	    //Se setea en el mapa el equivalente al regimen en traite documentario
	    mapPkDua.put("COD_REGIMEN", oTipo);
	    return soporteService.findExpediDocAsociado(mapPkDua);
	}

  /**
   * Valida si es una diligencia simplificada (mayor a 200 series)
   * @param request
   * @param response
   * @return true o false
   * @author gbecerrav
   */
  @SuppressWarnings("unchecked")
  public ModelAndView isDiligenciaSimplificada(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  if (log.isDebugEnabled()) {
		  log.debug("Inicio - isDiligenciaSimplificada");
	  }

	  Map<String, Object> modelo = new HashMap<String, Object>();

	  try{
		  Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");
		 boolean isDiligenciaSimplificada = false;

		  Object flagNumero = mapCabDeclara.get("FLAG_NUMERO");
		  if(flagNumero == null || !Constantes.FLAG_ACTUALIZACION_2.equals(flagNumero.toString())){ //Si ya tiene diligencia de conclusion en la simplificada no puede modificar
			  //Se comenta x mientras debido a que a�n no hay diligencia de conclusion de despacho en producci�n
			  //Se verifica si corresponde a una diligencia simplificada
			  Long numeroCorrelativo = SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC"));
			  isDiligenciaSimplificada = this.diligenciaSimplificadaService.isDiligenciaSimplificada(numeroCorrelativo);
			  if(isDiligenciaSimplificada){
				  isDiligenciaSimplificada = true;
			  }
		  }
		  modelo.put("rpta", isDiligenciaSimplificada);

		  //Almacenamos en memoria para saber en el boton en Proceso
		  WebUtils.setSessionAttribute(request, "isDiligenciaSimplificada", isDiligenciaSimplificada); //a�n no esta implementada en el bot�n "EN PROCESO"

	  }catch (ServiceException e) {
		  log.error("**** ERROR ****:", e);
		  return showErrorJSON(e.getMessage());
	  }catch (Exception e){
		  log.error("**** ERROR ****:", e);
		  return showErrorJSON(e.getMessage());
	  }
	  if (log.isDebugEnabled()) {
		  log.debug("Fin - isDiligenciaSimplificada");
	  }

	  return new ModelAndView("jsonView", modelo);
  }

 /**
   * Carga la p�gina para registrar diligencia de conclusion con proceso simplificado
   * @param request
   * @param response
   * @return Vista de Registro de Diligencia de Conclucion Simplificada
   * @author gbecerrav
   */
  @SuppressWarnings("unchecked")
  public ModelAndView iniciarDiligenciaSimplificada(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  if (log.isDebugEnabled()) {
		  log.debug("Inicio - iniciarDiligenciaSimplificada");
	  }

	  ModelAndView modelo = new ModelAndView("RegDiligConclusionSimplificada");

	  try{
		  Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

			/**Inicio de cambios por PAS20165E220200032**/
			String invocador="C";
			if(request.getParameter("hdn_Post_Levante")!=null && request.getParameter("hdn_Post_Levante").toString().equals("1")){
				invocador="L";
			}
			/**Fin de cambios por PAS20165E220200032**/
		  //T�tulo
	      String tituloDiligencia = declaracionService.obtenerTituloDiligencia((String)mapCabDeclara.get("COD_CANAL"), invocador) +
	    		  " de " + Constantes.COD_DOCUMENTO_ADUANERO + "-" +
	    		  (String)mapCabDeclara.get("COD_ADUANA") + "-" + mapCabDeclara.get("ANN_PRESEN") + "-" + (String)mapCabDeclara.get("COD_REGIMEN") + "-" + mapCabDeclara.get("NUM_DECLARACION");

	      modelo.addObject("tituloDiligencia", tituloDiligencia);
	      modelo.addObject("esPostLevante",request.getParameter("hdn_Post_Levante") );//adicionado  por PAS20165E220200032
	      mapCabDeclara.put("esPostLevante", request.getParameter("hdn_Post_Levante"));

	  }catch (Exception e){
		  log.error("**** ERROR ****:", e);
		  return showErrorPagM(e.getMessage());
	  }

	  if (log.isDebugEnabled()) {
		  log.debug("Fin - iniciarDiligenciaSimplificada");
	  }
	  return modelo;
  }

/**
   * Registra Diligencia de Conclusi�n de Despacho con proceso Simplificado
   * @param request
   * @param response
   * @return Error en el proceso o mensaje ok
   * @author gbecerrav
   */
  @SuppressWarnings("unchecked")
  public ModelAndView registrarDiligenciaSimplificada(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  if (log.isDebugEnabled()) {
		  log.debug("Inicio - registrarDiligenciaSimplificada");
	  }

	  /**Inicio de cambios PAS20165E220200032**/
	  String ingresoPostLevante= (String) (WebUtils.getSessionAttribute(request, "hdn_Post_Levante")!=null?WebUtils.getSessionAttribute(request, "hdn_Post_Levante"):" ");

	  try{
		  UsuarioBean usuario = this.verificarAutenticacion(request);

		  //Seteamos valor de formulario - Diligencia
		  Diligencia diligencia = new Diligencia();
		  bindToCommand(request, diligencia);

		  //Seteamos otros valores - Diligencia
		  Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

		  /**Inicio de cambios PAS20165E220200032**/
		  //String ingresoPostLevante= (String) (WebUtils.getSessionAttribute(request, "hdn_Post_Levante")!=null?WebUtils.getSessionAttribute(request, "hdn_Post_Levante"):" ");
		  if(ingresoPostLevante.equals(" ")){
			  ingresoPostLevante = mapCabDeclara.get("esPostLevante")!=null? mapCabDeclara.get("esPostLevante").toString():" ";
		  }
		  Date fechadeclaracion = mapCabDeclara.get("FEC_DECLARACION")!=null && mapCabDeclara.get("FEC_DECLARACION").toString()!=" "?
					SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
		  /**Fin de cambios PAS20165E220200032**/

		  diligencia.setNumeroCorrelativo(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC")));
		  diligencia.setCodigoTipoDiligencia(Constantes.DILIG_CONCLUSION_DESPACHO);
		  diligencia.setCodigoFuncionario(usuario.getNroRegistro().trim());
		  /**Inicio cambios por PAS20165E220200032***/
		  diligencia.setAnnPresen((java.lang.String)  mapCabDeclara.get("ANN_PRESEN").toString());
		  diligencia.setCodRegimen((java.lang.String)  mapCabDeclara.get("COD_REGIMEN")  );
		  diligencia.setCodAduana((java.lang.String)  mapCabDeclara.get("COD_ADUANA")  );
		  diligencia.setNumDeclaracion( SunatStringUtils.toStringObj( mapCabDeclara.get("NUM_DECLARACION")  ) );
		  /**Fin cambios por PAS20165E220200032***/
		  //Fecha y Hora de Diligencia
		  diligencia.setFechaDiligencia(new Date());
		  /*//Se coge del formulario
		  String horaDiligencia = request.getParameter("horaDiligencia");
		  Calendar c = Calendar.getInstance();
		  c.setTime(diligencia.getFechaDiligencia());
		  c.set(Calendar.HOUR_OF_DAY, new Integer(horaDiligencia.substring(1, 3)));
		  c.set(Calendar.MINUTE, new Integer(horaDiligencia.substring(4, 6)));
		  c.set(Calendar.SECOND, 0);
		  diligencia.setFechaDiligencia(c.getTime());*/
		  diligencia.setIndicadorMulta("N");
		  diligencia.setIndicarIncidencia("N");
		  diligencia.setIndicadorGrabado("S");
		  //Registramos Diligencia
		  this.diligenciaSimplificadaService.grabarDiligenciaConclusionSimplificada(diligencia);

		  /**Inicio de cambios PAS20165E220200032**/
		  if(ingresoPostLevante.equals("1")){
			  this.diligenciaSimplificadaService.grabarIndicadorPostLevante(mapCabDeclara.get("NUM_CORREDOC").toString(), fechadeclaracion);
		  }
		  /**Inicio de cambios PAS20165E220200032**/

		  //Eliminamos variable session
		  WebUtils.setSessionAttribute(request, "mapCabDeclara", null);
		  //WebUtils.setSessionAttribute(request, "isDiligenciaSimplificada", null); //a�n no esta implementada en el bot�n "EN PROCESO"

	  }catch (ServiceException e) {
		  log.error("**** ERROR ****:", e);
		  return showErrorJSON(e.getMessage());
	  }catch (Exception e){
		  log.error("**** ERROR ****:", e);
		  return showErrorJSON(e.getMessage());
	  }

	  if (log.isDebugEnabled()) {
		  log.debug("Inicio - registrarDiligenciaSimplificada");
	  }

	  return new ModelAndView("jsonView", "rpta", "1".equals(ingresoPostLevante)?"Diligencia de Post-Levante grabada satisfactoriamente.":"Diligencia de Conclusi\u00f3n de Despacho grabada satisfactoriamente.");
  }


	 //P24-II - Inicio
	  public Map<String, Object> obtenerDatosLevanteDuaSini(Map<String, Object> declaracionDua) throws ServiceException {
			Map<String, Object> rspta = new HashMap<String, Object>();
	          String aduana=declaracionDua.get("COD_ADUAMANIFIESTO").toString();
	          String codRegimen=declaracionDua.get("COD_REGIMEN").toString();
				if(aduana.equals("118")){
					String[] regimenTMP = new String[] {"10","20" ,"21","70"};
					if (Arrays.asList(regimenTMP).contains(codRegimen)) {
	              Map<String, Object> parametro = new HashMap<String, Object>();
	              Map<String, Object> parametros = new HashMap<String, Object>();
	              List<Map<String,Object>> listAuxiliar = new ArrayList<Map<String,Object>> ();

	              parametros.put("cod_regimen", declaracionDua.get("COD_REGIMEN").toString());
	              parametros.put("codigoAduana", declaracionDua.get("COD_ADUAMANIFIESTO").toString());
	              parametros.put("anioDocumento", declaracionDua.get("ANN_PRESEN").toString());
	              parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(),6, " "));
	              parametros.put("codigoViaTransporte", declaracionDua.get("COD_VIATRANS").toString());
	              parametros.put("numdua", declaracionDua.get("NUM_DECLARACION").toString());//pruiz
	              parametros.put("numdua", StringUtils.leftPad(declaracionDua.get("NUM_DECLARACION").toString(),6,"0"));


	              SiniConsultaService siniConsultaService =fabricaDeServicios.getService("sigad.sini.SiniConsultaService");
	              List<Map<String,Object>> listSini= siniConsultaService.evaluarContenedorSINIxDAM(parametros);
	              String etiquetaSini=null;

	              if (!CollectionUtils.isEmpty(listSini)){
	                 if(listSini.size()>0){

	                  etiquetaSini=	String.valueOf(listSini.get(0).get("DES_ESTADO"));
	              	rspta.put("COD_ESTADO_SINI", listSini.get(0).get("COD_ESTADO"));

		                }else{
		                	//se obtiene los datos de la dua

		                    parametro.put("numeroCorrelativoDua", declaracionDua.get("NUM_CORREDOC").toString());
		                    parametros.put("anioManifiesto", declaracionDua.get("ANN_MANIFIESTO").toString());
		                    parametros.put("codigoTipoManifiesto", declaracionDua.get("COD_TIPMANIFIESTO").toString());
		                    EntradaSalidaService entradaSalidaService =  fabricaDeServicios.getService("declaracion.entradasalida.EntradaSalidaService");
		                    List<Manifiesto> lstManifiesto = entradaSalidaService.obtenerManifiesto(parametros);
		                    Long numeroCorrelativoManif = lstManifiesto.get(0).getNumeroCorrelativo();
		                    parametro.put("numeroCorrelativoManif", numeroCorrelativoManif);
		                    //Obtenemos Contenedores Declarados
		                    listAuxiliar=entradaSalidaService.obtenerContenedoresDeclarados(parametro);
		                    if (!listAuxiliar.isEmpty() && listAuxiliar!=null){
		                    	List<String> listaEquipaminetos = new ArrayList<String>();
		 	                    for(Map<String, Object> mapCon :listAuxiliar){
		 	                    	listaEquipaminetos.add((String)mapCon.get("numeroEquipamiento"));
		 	    				}

		 	                   parametros.put("listContenedores", listaEquipaminetos);

		 	                    List<Map<String,Object>> listSiniManif= siniConsultaService.evaluarContenedorSINISinDestinar(parametros);
		 	                    if(!listSiniManif.isEmpty()){
		 	                    etiquetaSini=	String.valueOf(listSiniManif.get(0).get("DES_ESTADO"));
		 	                	rspta.put("COD_ESTADO_SINI", listSiniManif.get(0).get("COD_ESTADO"));
		 	                    }

		 	                }

		                  }
					}

	             	   rspta.put("DES_ESTADO_SINI", etiquetaSini);

	                }
	             }


			return rspta;
		}

	  private Map<String, Object> determinarEstadoRegularizacion(Map<String, Object> declaracion){
			// obtiene el mensaje del levante - mensaje regularizacion
			// RIN16
		  	HashMap rspta = new HashMap();
			if(declaracion.get("COD_ESTDUA").toString().equals("08") || declaracion.get("COD_MODALIDAD").toString().equals("00")){  // SI LA DUA ESTA LEGAJADA O LA DUA ES MODALIDAD EXCEPCIONAL NO DEBE TENER MENSAJE DE REGULARIZACION
				rspta.put("MsjRegularizacion", null);
				rspta.put("fecSolicitud", " ");
				rspta.put("horSolicitud", " ");
			} else {

				/*Inicio f2_3014_req_RIN16_Regularizacion - PLMR */

				if (org.springframework.util.StringUtils.hasText((String)declaracion.get("COD_ESTREGUL"))) {
					if(declaracion.get("COD_ESTREGUL").toString().equals("07")){
						rspta.put("MsjRegularizacion", null);
						rspta.put("fecSolicitud", " ");
						rspta.put("horSolicitud", " ");
					}
					else{
						if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"01", "02", "03" })){//sin Regularizacion aceptada
							rspta.put("MsjRegularizacion","PENDIENTE DE REGULARIZAR");
							rspta.put("horSolicitud", " ");
							rspta.put("fecSolicitud", " ");
						}
						else if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"04", "05", "06"})){//con Regularizacion aceptada
							rspta.put("MsjRegularizacion","REGULARIZADO");
							Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
							rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
							rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
						}
					}
				}
				/*Fin f2_3014_req_RIN16_Regularizacion - PLMR */
				else{
				// RIN16
					String MsjRegularizacion = null;
					HashMap params = new HashMap();
					// se obtiene fecha de solicitud, regularizacion - urgentes
					params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
					params.put("COD_TIPSOL", "11");
					RelacionDocDAO relacionDocDAO = fabricaDeServicios.getService("relaciondocDAO");
					List<Map<String,Object>> relacionSolicitudes = relacionDocDAO.findSolicitudesByDocumento(params);
					Date fecSolicitud = SunatDateUtils.getDefaultDate();
					if(!org.apache.commons.collections.CollectionUtils.isEmpty(relacionSolicitudes)){
						Map<String, Object> solicitud = relacionSolicitudes.get(0);
						fecSolicitud = (Date)(solicitud.get("FEC_SOLICITUD"));
					}
					// se obtiene fecha de recepcion de documentos, regularizacion - urgentes
					Date fecRecepcionDoc = (Date) declaracion.get("FEC_REREG");
					// se obtiene fecha de regularizacion de la dua - anticipados
					Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");

					//Se evalua si tiene expediente 1606 para identificar el tipo de mensaje de regularizacion a mostrar
					Map<String,Object> paramsExpedi = new HashMap<String,Object>();
					paramsExpedi.put("PROCEDIM", 		"1606");
					paramsExpedi.put("COD_ADUANA",  	declaracion.get("COD_ADUANA"));
					paramsExpedi.put("COD_REGIMEN", 	declaracion.get("COD_REGIMEN"));
					paramsExpedi.put("ANN_PRESEN",  	declaracion.get("ANN_PRESEN").toString());
					paramsExpedi.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));

				if (declaracion.get("COD_MODALIDAD").equals("01")) { // 01 urgente
					// Modificado Daniel Zavaleta C. 10/10/2012 INI
					if(SunatDateUtils.isDefaultDate(fecSolicitud) || SunatDateUtils.isDefaultDate(fecRecepcionDoc) || SunatDateUtils.isDefaultDate(fecRegulariza)){
					//   Fin
						MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
					}else{
						MsjRegularizacion = "REGULARIZADO";
						fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
						rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
						rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
					}
				} else if (declaracion.get("COD_MODALIDAD").equals("10")) { // 10 anticipado
					Map<String, Object> paramIndLev = new HashMap<String, Object>();
					paramIndLev.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
					paramIndLev.put("cod_indicador", "02"); // 302 datacatalogo
					paramIndLev.put("ind_activo", "1");
					IndicadorDUADAO indicadorDuaDAO = fabricaDeServicios.getService("indicadorDUADAO");
					Map<String, Object> mapIndLev = indicadorDuaDAO.findByDocumentoAndValor(paramIndLev);
					if (mapIndLev != null && mapIndLev.size() > 0) { // tiene indicador 02
						if(SunatDateUtils.isDefaultDate(fecRegulariza)){
							MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
						}else{
							MsjRegularizacion = "REGULARIZADO";
							fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
							rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
							rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
						}
					}
				}
				rspta.put("MsjRegularizacion", MsjRegularizacion);
				}
			}// RIN16
			return rspta;
	  }

	 //P24-II - Fin

  /***********************SET DE SPRING **********************************/

  public void setDeclaracionService(DeclaracionService declaracionService)
  {
    this.declaracionService = declaracionService;
  }

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  public void setJsonView(String jsonView)
  {
    this.jsonView = jsonView;
  }

  public void setDiligenciaService(DiligenciaService diligenciaService)
  {
    this.diligenciaService = diligenciaService;
  }

  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }



	public SerieService getSerieService() {
	return serieService;
	}

	public void setSerieService(SerieService serieService) {
		this.serieService = serieService;
	}

	/**
	 * @author hsaenz
	 * @return the fabricaDeServicios
	 */
	// hsaenz: 10/09/2014
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	/**
	 * @author hsaenz
	 * @param fabricaDeServicios the fabricaDeServicios to set
	 */
	// hsaenz: 10/09/2014
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public FormatoValorService getFormatoValorService() {
		return formatoValorService;
	}

	public void setFormatoValorService(FormatoValorService formatoValorService) {
		this.formatoValorService = formatoValorService;
	}

        public DiligenciaSimplificadaService getDiligenciaSimplificadaService() {
		return diligenciaSimplificadaService;
	}

	public void setDiligenciaSimplificadaService(
			DiligenciaSimplificadaService diligenciaSimplificadaService) {
		this.diligenciaSimplificadaService = diligenciaSimplificadaService;
	}


    public RectificacionService getRectificacionService() {
    	return rectificacionService;
    }

    public void setRectificacionService(RectificacionService rectificacionService) {
    	this.rectificacionService = rectificacionService;
    }


		 //p14 - pase 108 copia de PAS20155E220000521 se factoriza la l�gica de obtener el flag de Indicador Frecuente
		 private boolean isImportadorFrecuente(Long numCorreDoc){
			List<IndicadorDeclaracionDescripcion> listaIndicadorDuaDesc = this.declaracionService.obtenerIndicadoresDuaAll(numCorreDoc);
				  if (listaIndicadorDuaDesc != null) {
						for (IndicadorDeclaracionDescripcion indicadorDuaDesc : listaIndicadorDuaDesc) {
							  if(indicadorDuaDesc.getCodigoIndicador().equals("05")){//es decir cuenta con el indicador 05 Importador Frecuente
								  return true;
							  }
						}
				  }
			return false;
		 }

	//region amancillaa SDA2-RIN18-PAS20171U220200035
	private String obtenerEtiquetaOEA(Long numCorreDoc){

		String oea ="";
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
		DatoIndicadores indicadorFrecuente = indicadorDuaService.obtenerIndicadorDeclaracion(numCorreDoc.toString(), ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
		if(indicadorFrecuente!=null && indicadorFrecuente.getIndicadorActivo().equals(ConstantesDataCatalogo.IND_ACTIVO)){
			oea = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_DE_DATOS_INDICADORES, ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA).getDesDatacat();
		}

		return oea;
	}

	//endregion amancillaa
}