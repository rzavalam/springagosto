package pe.gob.sunat.controladuanero2.ingreso.postlevante.web.bean;


import org.apache.commons.lang.StringUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * Created by amancillaa on 29/03/2016.
 */
public class FormBusquedaDeclaracion implements Serializable {


    private static final long serialVersionUID = 5087423679494510265L;

    private String codAduana;
    private String annPresen;
    private String codRegimen;
    private String numDeclaracion;
	private List<Map<String, String>> lstAduanasDependencies;
    private String msjError;



    public FormBusquedaDeclaracion() {
        super();
    }

    public FormBusquedaDeclaracion(String codAduana, String annPresen, String codRegimen, String numDeclaracion) {

        this.codAduana      = StringUtils.isNotEmpty(codAduana)?codAduana:"118";
        this.annPresen           = StringUtils.isNotEmpty(annPresen)?annPresen:String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        this.codRegimen     = StringUtils.isNotEmpty(codRegimen)?codRegimen: Constantes.COD_REGIMEN_IMPORTACION_CONSUMO;
        this.numDeclaracion = numDeclaracion!=null?numDeclaracion:"";
    }

	public FormBusquedaDeclaracion(String codAduana, String annPresen, String codRegimen, String numDeclaracion,
								   List<Map<String, String>> lstAduanasDependencies) {
    	this.lstAduanasDependencies = lstAduanasDependencies;
		this.codAduana      = StringUtils.isNotEmpty(codAduana)?codAduana:"118";
		this.annPresen           = StringUtils.isNotEmpty(annPresen)?annPresen:String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
		this.codRegimen     = StringUtils.isNotEmpty(codRegimen)?codRegimen: Constantes.COD_REGIMEN_IMPORTACION_CONSUMO;
		this.numDeclaracion = numDeclaracion!=null?numDeclaracion:"";
	}

    public String getCodAduana() {
        return codAduana;
    }

    public void setCodAduana(String codAduana) {
        this.codAduana = codAduana;
    }

    public String getAnnPresen() {
        return annPresen;
    }

    public void setAnnPresen(String annPresen) {
        this.annPresen = annPresen;
    }

    public String getCodRegimen() {
        return codRegimen;
    }

    public void setCodRegimen(String codRegimen) {
        this.codRegimen = codRegimen;
    }

    public String getNumDeclaracion() {
        return numDeclaracion;
    }

    public void setNumDeclaracion(String numDeclaracion) {
        this.numDeclaracion = numDeclaracion;
    }

    public String getMsjError() {
        return msjError;
    }

    public void setMsjError(String msjError) {
        this.msjError = msjError;
    }

	public List<Map<String, String>> getLstAduanasDependencies() {
		return lstAduanasDependencies;
	}

	public void setLstAduanasDependencies(List<Map<String, String>> lstAduanasDependencies) {
		this.lstAduanasDependencies = lstAduanasDependencies;
	}
}
