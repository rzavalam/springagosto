package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.text.SimpleDateFormat; //P24 pase99
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ParameterMode;

import com.fasterxml.jackson.annotation.JsonInclude; //P24 pase99
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;//P14
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

public class NotificacionController extends AbstractDespachoController {

	private FabricaDeServicios  fabricaDeServicios;
	private DeclaracionService  declaracionService;
	private SoporteService  soporteService;
	
	/** M�todo que llama al servicio para actualizar una declaraci�n 
	 * @author lrodriguezc
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	public void actualizarEstadoDeclaracion(HttpServletRequest request, HttpServletResponse response)
		throws Exception{
		
		ModelAndView res = new ModelAndView(this.jsonView);
		String codNuevoEstadoDeclaracion = (String)request.getParameter("codNuevoEstadoDeclaracion");
		
		try{
			//Inicio RIN10
			UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
			//Fin RIN10
			Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
			params.put("COD_ESTDUA", codNuevoEstadoDeclaracion);
			declaracionService.updateDeclaracion(params);
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			res.addObject("beanM", rBean);
			
		}
		
	}
	
	/** Inicia la p�gina de busqueda de declaraciones con notificaci�n para ser respondidas
	 * @author lrodriguezc
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView cargarBusqRespuestaNotificacion (HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		try {
			
			UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			if (userSession == null) {
				
				return new ModelAndView("PagM", "message", "Usuario no logueado");
				
			}
			
			Utilidades.inicializarMapasSesion(request);
			UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : soporteService.obtenerAduana(request);
			String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
			String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
			String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
			List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
			
			Map<String, String> params = new HashMap<String, String>();
			
			params.put("cod_aduana", codAduana);
			params.put("ann_presen", annPresen);
			params.put("cod_regimen", codRegimen);
			params.put("num_declaracion", numDeclaracion);
			params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			params.put("numPase", Constantes.NUM_PASE);
			params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
			
			ModelAndView res = new ModelAndView("/Notificacion/BusqDeclaracionRespNotificacion");
			
			res.addObject("params", params);
			res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));
			
			List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
			
			for (Map<String, String> map : lstAduana) {
				
				map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
				
				if (((String) map.get("cod_datacat")).equals(codAduana)) {
					
					params.put("des_aduana", (String) map.get("des_corta"));
					
				}
				
			}
			
			res.addObject("lstAduana", SojoUtil.toJson(lstAduana));
			
			return res;
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);
			
		}
		
	}
	
	/** Valida la declaraci�n para su futura respuesta a su notificaci�n
	 * @author lrodriguezc
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView validarRecepcionRespuestaNotificacion (HttpServletRequest request, HttpServletResponse response) throws Exception{
		/*inicio mpoblete BUG*/
		Map<String, Object> declaracion = new HashMap<String, Object>();
		
		ModelAndView vista = new ModelAndView(this.jsonView);
		/*fin mpoblete BUG*/
		try {//POB
			
			UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			Map<String, Object> params = new HashMap<String, Object>();
			/*inicio mpoblete BUG*/
			/*Map<String, Object> declaracion = new HashMap<String, Object>();
			
			ModelAndView vista = new ModelAndView(this.jsonView);*/
			/*fin mpoblete BUG*/
			
			params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
			params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
			params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
			params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
			
			declaracion = declaracionService.validarRecepcionRespuestaNotificacion(params, userSession);
			
			if (declaracion.get("COD_ESTDUA")!= null && Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE.equals(declaracion.get("COD_ESTDUA"))) {
				//pase81 por Hcastillo
				enviarCorreoElectronicoMercanciaConReporte(request, response, declaracion, userSession);
				
			}
			
			vista.addObject("declaracion",declaracion);
			
			return vista;
			
		} catch (Exception e) {
			/*inicio mpoblete BUG*/
			/*MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);*/
			
			log.error(this,e);
			log.debug(this,e);
			declaracion = new HashMap<String, Object>();
			declaracion.put("error",Constantes.PAGM_MSJ_ERROR.concat(Constantes.SALTO_LINEA).concat(Constantes.PAGM_MSJ_SOL));
			vista = new ModelAndView(this.jsonView);
			vista.addObject("declaracion",declaracion);
			return vista;	
			/*fin mpoblete BUG*/
		}
		
	}
	
	

	/** Inicia la p�gina de respuesta a la notificaci�n de la declaraci�n seleccionada
	 * @author lrodriguezc
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView iniciarRespuestaNotificacion (HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		try {
			
			String declaracionCadena = request.getParameter("declaracion");
			ModelAndView resultado = new ModelAndView("/Notificacion/RecepcionRespuestaNotificacion");
			//gmontoya inicio Pase 99 2016
//			HashMap<String, Object> declaracion = (HashMap<String, Object>) new JsonSerializer().deserialize(declaracionCadena, HashMap.class);

			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm a");
			mapper.setDateFormat(sdf);
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			HashMap<String, Object> declaracion = (HashMap<String, Object>)mapper.readValue(declaracionCadena, HashMap.class);
			//gmontoya fin Pase 99 2016

			if (declaracion == null) {
				
				throw new IllegalArgumentException("Declaracion es null, no se pudo deserializar");
				
			}
			
			resultado.addObject("declaracion", declaracion);
			resultado.addObject("declaracionCadena", declaracionCadena);
			
			return resultado;
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);
			
		}
		
	}
	
	/** Graba la respuesta de la notificaci�n de la declaraci�n seleccionada
	 * @author lrodriguezc
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView grabarRespuestaNotificacion (HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		try {
			/*inicio mpoblete BUG*/
			UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			inicializarParametrosAuditoriaPortalEspecialista(bUsuario, request);
			/*fin mpoblete BUG*/
			String declaracionCadena = request.getParameter("declaracion");
			String numeroFolios = request.getParameter("numFolios");
			String observaciones = request.getParameter("observaciones");
			
			//gmontoya inicio Pase 99 2016
//			HashMap<String, Object> declaracion = (HashMap<String, Object>) new JsonSerializer().deserialize(declaracionCadena, HashMap.class);

			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm a");
			mapper.setDateFormat(sdf);
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			HashMap<String, Object> declaracion = (HashMap<String, Object>)mapper.readValue(declaracionCadena, HashMap.class);
			//gmontoya fin Pase 99 2016
			Map<String, Object> ultimaComunicacion = new HashMap<String, Object>();
			Map<String, Object> comunicacion = new HashMap<String, Object>();
			FechaBean fecActual = new FechaBean();
			Map<String, Object> params = new HashMap<String, Object>();
			
			if (declaracion == null) {
				throw new IllegalArgumentException("Declaracion es null, no se pudo deserializar");		
			}
			
			ultimaComunicacion = (Map<String, Object>) declaracion.get("ultimaComunicacion");
			
			comunicacion.put("num_nota", ultimaComunicacion.get("numNota"));
			comunicacion.put("num_folios", numeroFolios);
			comunicacion.put("observaciones", observaciones);
			comunicacion.put("fec_respuesta", fecActual.getTimestamp());
			
			diligenciaService.actualizarRespuestaComunicacionNotificacion(comunicacion);
			
			params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			if(declaracion.get("COD_ESTDUA").toString().equals(Constantes.ESTADO_CONCLU_NOTIFICADO) ){//p14-diligencia de conclusion
				params.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_REVISION);
			} 
			//PAS20165E220200056 RSERRANO Solo debe cambiar el estado cuando esta con estado notificado
			if(declaracion.get("COD_ESTDUA").toString().equals(Constantes.ESTADO_NOTIFICADO) ){//diligencia de despacho notificado
				params.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			} 
			/*else{
				params.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			}
			*/
			//PAS20165E220200056 RSERRANO Solo debe cambiar el estado cuando esta con estado notificado
			
			//PAS20165E220200056 RSERRANO Solo debe cambiar el estado cuando esta con estado notificado
			//if(!ultimaComunicacion.get("codTiDiligencia").equals(Constantes.DILIG_REGU_REVISION) && (
			//PAS20165E220200056 RSERRANO Solo debe cambiar el estado cuando esta con estado notificado
			//TODO: amancilla SE ENCONTRO UN ERROR DE PROGRAMACION EL GRABADO NO ES TRANSACCIONABLE OCACIONANDO SIGESI
			//ESTA PARTE DEBERIA ESTAR EN UN SERVICIO ATOMICO Y NO PARTIDO EN VARIOS SERVICIOS ALGUN DIA ALGUIEN SE ANIMARA A CAMBIARLO ????
			if (declaracion.get("COD_ESTDUA").toString().equals(Constantes.ESTADO_CONCLU_NOTIFICADO) ||
					declaracion.get("COD_ESTDUA").toString().equals(Constantes.ESTADO_NOTIFICADO)  ){
				declaracionService.updateDeclaracion(params);
			}
			return new ModelAndView(this.jsonView);
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);
			
		}
		
	}
	
	/* P14 - 3006 - dhernandezv - Inicio */
	private HashMap<String,Object> generarNotificacionPDF(HttpServletRequest request,HttpServletResponse response, 
									Integer codPlantilla, HashMap<String,Object> detalleComunicacion,String tipo) throws Exception {
		HashMap<String,Object> rutas = new HashMap<String, Object>();
		try {
			request.setCharacterEncoding("ISO-8859-1");
			
			
			Map mapCabDeclaraActual= null;
			
			if(codPlantilla == Constantes.COD_PL_NOTI_DECLA1||codPlantilla == Constantes.COD_PL_NOTI_DECLA2||codPlantilla == Constantes.COD_PL_NOTI_DECLA3||codPlantilla == Constantes.COD_PL_NOTI_DECLA4)
				mapCabDeclaraActual = (Map) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");				
			else if(codPlantilla == Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL) 
				mapCabDeclaraActual = (Map) detalleComunicacion.get("DECLARACION");
			
			String codAduana = mapCabDeclaraActual.get("COD_ADUANA").toString();
			String annPresen = mapCabDeclaraActual.get("ANN_PRESEN").toString();
			String codRegimen = mapCabDeclaraActual.get("COD_REGIMEN").toString();
			String numDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION").toString();

			ArrayList fields = new ArrayList();
			Map<String, Object> fila = new HashMap<String, Object>();
//			<EHR>
			
			Map<String, Object> paramsCons = new HashMap<String, Object>();
			paramsCons.put("COD_ADUANA", codAduana);
			paramsCons.put("ANN_PRESEN", annPresen);
			paramsCons.put("COD_REGIMEN", codRegimen);
			paramsCons.put("NUM_DECLARACION", numDeclaracion);
			if(tipo.equals("PDE")){
				
				paramsCons.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
				
			}else if(tipo.equals("PIN")){
				paramsCons.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE);
				
			}
			
			Map<String, String> cabecera = new HashMap<String, String>();
//			cabecera.put("numfor", codPlantilla.toString());
			FechaBean fechaPublicacion = new FechaBean();
			String consignatario = diligenciaService.obtenerConsignatario(paramsCons);
			
			String intendencia =  catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana);
			String elaboradoPor= diligenciaService.obtenerElaborado(codAduana);
			String fechaEmision =  fechaPublicacion.getDia().toString()+ "/" + fechaPublicacion.getMes().toString() + "/"+ fechaPublicacion.getAnho().toString();	
			List<Map> lista = new ArrayList();
			
//			</EHR>
			
			fila.put("COD_ADUANA", codAduana);
			fila.put("ANN_PRESEN", annPresen);
			fila.put("COD_REGIMEN", codRegimen);
			fila.put("NUM_DECLARACION", numDeclaracion);
			fila.put("DES_INTENDENCIA", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));
			//fila.put("DES_CONSIGNATARIO", diligenciaService.obtenerConsignatario(codAduana, annPresen, codRegimen, numDeclaracion, null));
			fila.put("ELABORADO_POR", diligenciaService.obtenerElaborado(codAduana));
			
			Map<String, Object> filaDetalle;
			
			//Para la plantilla 100159 
			if(codPlantilla == Constantes.COD_PL_NOTI_DECLA1||codPlantilla == Constantes.COD_PL_NOTI_DECLA2||codPlantilla == Constantes.COD_PL_NOTI_DECLA3||codPlantilla == Constantes.COD_PL_NOTI_DECLA4){
				if(!detalleComunicacion.isEmpty())
				{
					fila.put("COD_MOTIVO_NOTI", detalleComunicacion.get("COD_MOTIVO_NOTI"));
					fila.put("CAB_DETALLE", detalleComunicacion.get("CAB_DETALLE"));
					fila.put("PIE_DETALLE", detalleComunicacion.get("PIE_DETALLE"));
					
					if(detalleComunicacion.get("DET_NOTIFICACION")!=null){					
						List<HashMap<String, Object>>  detalleNotificacion= (List<HashMap<String, Object>>) detalleComunicacion.get("DET_NOTIFICACION");
						
						for (HashMap<String, Object> map : detalleNotificacion) {
							filaDetalle = new HashMap<String, Object>();
							filaDetalle.put("SERIE"					, map.get("serie"));
							filaDetalle.put("VALOR_OBSERVADO_UNIDAD", map.get("valor_observado_por_unidad"));
							filaDetalle.put("REFERENCIA"			, map.get("referencia"));
							filaDetalle.put("SUB_NACIONAL_DECLARADA", map.get("subpartida_nacional_declarada"));
							filaDetalle.put("SUB_NACIONAL_PROPUESTA", map.get("subpartida_nacional_propuesta"));
							filaDetalle.put("SUB_NACIONAL"			, map.get("subpartida_nacional"));
							filaDetalle.put("DERECHO_ANTIDUMPING"	, map.get("derecho_antidumping"));
							filaDetalle.put("SEC_AUTORIZA_INGRESO"	, map.get("sector_autoriza_ingreso"));
							filaDetalle.put("DOCUMENTO"				, map.get("documento"));
							
							lista.add(filaDetalle);
						}
					}
				}
				
			//Para la plantilla 100160
			}else if(codPlantilla == Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL) 
			{
				if(!detalleComunicacion.isEmpty()){					
					fila.put("CAB_DETALLE", detalleComunicacion.get("CAB_DETALLE"));					
					
					if(detalleComunicacion.get("DET_NOTIFICACION")!=null){					
						List<HashMap<String, Object>>  detalleNotificacion= (List<HashMap<String, Object>>) detalleComunicacion.get("DET_NOTIFICACION");
						
						for (HashMap<String, Object> map : detalleNotificacion) {
							filaDetalle = new HashMap<String, Object>();
							filaDetalle.put("TIPO_DOC_DISP_MERC", map.get("tipo_doc_disp_merc"));
							filaDetalle.put("DOC_DISP_MERC"		, map.get("doc_disp_merc"));
//							<EHR>
							filaDetalle.put("FEC_EMISION_DOC"		, map.get("fec_emision_doc"));
							filaDetalle.put("CAB_DETALLE", detalleComunicacion.get("CAB_DETALLE")); //pase81
							filaDetalle.put("COD_ADUANA", codAduana);
							filaDetalle.put("ANN_PRESEN", annPresen);
							filaDetalle.put("COD_REGIMEN", codRegimen);
							filaDetalle.put("NUM_DECLARACION", numDeclaracion);
							filaDetalle.put("DES_CONSIGNATARIO", consignatario);
							filaDetalle.put("DES_INTENDENCIA", intendencia);
							filaDetalle.put("ELABORADO_POR", elaboradoPor);
							filaDetalle.put("FECHA_EMISION", fechaEmision);
//							</EHR>
							lista.add(filaDetalle);
						}
					}
				}
			}
			Map<String, Object> mapJson = new HashMap();
		    mapJson.put("cabecera", cabecera);   
		    mapJson.put("detalle", lista);
		    Integer iddoc = new Integer(codPlantilla);//Debe ser una constante
		    JsonSerializer s = new JsonSerializer();
			String json = s.serialize(mapJson).toString();
			
			try{
				Service service = new Service();
				Call call = (Call) service.createCall();
				//<EHR>P14 </EHR>
				String urlServiceGenerarPDF = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_GENERADOR_PDF, ConstantesDataCatalogo.COD_DATACATALOGO_GENERADOR_PDF);
				
				call.setTargetEndpointAddress(new java.net.URL(urlServiceGenerarPDF));
				call.setOperationName("genera");
				call.addParameter("iddoc", XMLType.XSD_INT, ParameterMode.IN);
				call.addParameter("datos", XMLType.XSD_STRING, ParameterMode.IN);
				call.addParameter("tipo", XMLType.XSD_STRING, ParameterMode.IN);
				call.addParameter("modelo", XMLType.XSD_INT, ParameterMode.IN);
				call.setReturnClass(int.class);
				Object[] data = new Object[]{iddoc,json,"pdf",new Integer(1000)};
			    int id = new Integer(call.invoke(data).toString()).intValue();
				rutas.put("num_pdf", id);
		    }catch(Exception e){
		        e.printStackTrace();
		    }
			return rutas;
		} catch (Exception e) {
			Map<String, Object> error = handleError(e);
			log.info(error.get("msgLog"));
			return  (HashMap<String, Object>) error;
		}
		//return resultadoGeneracionPDF;
	}

	private Map<String, Object> handleError(Exception e) {

		// seteando el mensaje de tipo de error (para aclarar el log)
		String tipoError = null;
		if (e instanceof ServiceException) {
			tipoError = "**** ERROR DE NEGOCIO ****";
		} else if (e instanceof IllegalArgumentException) {
			tipoError = "**** ERROR DE NEGOCIO ****";
		} else if (e instanceof Exception) {
			tipoError = "**** ERROR DE APLICACION ****";
		}

		// seteando el mensaje de error
		String msgError = "" + ((e == null || e instanceof NullPointerException) ? "Null Pointer Exception" : e.getMessage());
		if (e != null && e.getCause() != null) {
			msgError = msgError + ", CAUSA: " + e.getCause().getMessage();
		}

		// seteando el bean de error standard
		MensajeBean beanM = new MensajeBean();
		beanM.setError(true);
		beanM.setMensajeerror(msgError);
		beanM.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

		// seteando el objeto result
		HashMap<String, Object> result = new HashMap<String, Object>();
		result.put("msgError", msgError);
		result.put("viewError", new ModelAndView("PagM").addObject("beanM", beanM));
		result.put("msgLog", tipoError + ": " + msgError);
		result.put("msgSol", beanM.getMensajesol());

		return result;
	}
	
	private void enviarCorreoElectronicoMercanciaConReporte( HttpServletRequest request, HttpServletResponse response, Map<String, Object> declaracion,
			UsuarioBean userSession) throws Exception {		
		String tipoPDE = "PDE";
		String tipoPIN="PIN";
		//evitar los errores de auditoria
		  UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean"); 
		  UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr()); 
		  
		if(Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE.equals(declaracion.get("COD_ESTDUA")))
		{
			//HashMap<String, Object> mapaDetalleNotificacionPDF = new HashMap<String, Object>();
			//String cabDetallePDF = "Mediante el presente se le comunica que las mercanc�as consignadas en la declaraci�n de la referencia han sido dispuestas totalmente de acuerdo al art�culo 180� de la Ley General de Aduanas aprobada por Decreto Legislativo N� 1053, motivo por el cual no es posible recepcionar la respuesta a la notificaci�n efectuada.";
			
	//		mapaDetalleNotificacionPDF.put("CAB_DETALLE", cabDetallePDF);
		//	mapaDetalleNotificacionPDF.put("DET_NOTIFICACION", diligenciaService.obtenerDetalleDocumentosAsociadosParaReporte(declaracion.get("NUM_CORREDOC").toString()));
			//mapaDetalleNotificacionPDF.put("DECLARACION", declaracion);
			

			//agencia de aduana	
		diligenciaService.notificarObserMercaDispuesta(null,
				declaracion.get("COD_ADUANA").toString(), 
				declaracion.get("ANN_PRESEN").toString(), 
				declaracion.get("COD_REGIMEN").toString(), 
				declaracion.get("NUM_DECLARACION").toString(),
				"PDE",
					new String[] { declaracion.get("NUM_DOCIDENT_PDE").toString()},
				Constantes.COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL, 
				Constantes.CODIGO_NOTIFICACION,
				Constantes.CONTRIBUYENTE, 
				(String) declaracion.get("COD_TIPDOC_PDE") );
		// importador consignatario
		//rutaPDF = null;
		 //rutaPDF = generarNotificacionPDF(request, response, Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL, mapaDetalleNotificacionPDF, tipoPIN);
		
		diligenciaService.notificarObserMercaDispuesta(null,
				declaracion.get("COD_ADUANA").toString(), 
				declaracion.get("ANN_PRESEN").toString(), 
				declaracion.get("COD_REGIMEN").toString(), 
				declaracion.get("NUM_DECLARACION").toString(),
				"PIM",
				new String[] { declaracion.get("NUM_DOCIDENT_PIM").toString()},
				Constantes.COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL, 
				Constantes.CODIGO_NOTIFICACION,
				Constantes.CONTRIBUYENTE, 
				(String) declaracion.get("COD_TIPDOC_PIM"));
	}
			
	/*		HashMap<String, Object> rutaPDF = generarNotificacionPDF(request, response, Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL, mapaDetalleNotificacionPDF, tipoPDE);
				//agencia de aduana	
			diligenciaService.notificarObservacionReporteAdjunto(null,
					declaracion.get("COD_ADUANA").toString(), 
					declaracion.get("ANN_PRESEN").toString(), 
					declaracion.get("COD_REGIMEN").toString(), 
					declaracion.get("NUM_DECLARACION").toString(),
					userSession.getNombreCompleto(),
					new String[] { declaracion.get("NUM_DOCIDENT_PDE").toString()}, 
					Constantes.COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL, 
					Constantes.CODIGO_NOTIFICACION,
					Constantes.CONTRIBUYENTE, 
					Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE,
					rutaPDF,tipoPDE);
			// importador consignatario
			rutaPDF = null;
			 rutaPDF = generarNotificacionPDF(request, response, Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL, mapaDetalleNotificacionPDF, tipoPIN);
			
			diligenciaService.notificarObservacionReporteAdjunto(null,
					declaracion.get("COD_ADUANA").toString(), 
					declaracion.get("ANN_PRESEN").toString(), 
					declaracion.get("COD_REGIMEN").toString(), 
					declaracion.get("NUM_DECLARACION").toString(),
					userSession.getNombreCompleto(),
					new String[] { declaracion.get("NUM_DOCIDENT_PIM").toString()}, 
					Constantes.COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL, 
					Constantes.CODIGO_NOTIFICACION,
					Constantes.CONTRIBUYENTE, 
					Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE,
					rutaPDF,tipoPIN);
					*/
		//}
	}
	/* P14 - 3006 - dhernandezv - Fin */
	 /**
 	 * m�todo para inicializar parametros que necesita el modulo de auditoria
 	 * @param request
 	 * @param response
 	 */
 	private void inicializarParametrosAuditoriaPortalEspecialista(UsuarioBean usuarioBean,HttpServletRequest request){
 		UserNameHolder.set(usuarioBean.getNroRegistro(), request.getRemoteAddr());
 		log.info("PortalEspecialista usuario: "+usuarioBean.getNroRegistro()+ " ip: "+request.getRemoteAddr());
 					
 	}
	/*Set para Inyeccion*/
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}
	
	
}
