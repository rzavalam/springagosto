package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;//P28-PAS20155E410000032
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;//P28-PAS20155E410000032
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class FormatoBController extends AbstractDespachoController
{

  private static final String PAGINA_PRINCIPAL_DETALLE  = "oficio/RegSerieOficio";

  private FormatoValorService                            formatoValorService;
  private SerieService                                   serieService;
  
  /** Genera una copia del �tem base seleccionado (incluyendo sus listas asociadas: observaci�n, referenciaDuda, VfobProvisional, DecrMinima)
  * y lo agrega a la declaraci�n en sesi�n "mapCabDeclaraActual", actualiza el monto de la factura
  * @param request
  * @param response
  * @return
  * @throws Exception
  */
  public ModelAndView copiarItemSesion(HttpServletRequest request, HttpServletResponse response) throws Exception{
	ServletWebRequest webRequest = new ServletWebRequest(request);
    HttpSession session = request.getSession();
    Map<String, Object> params = new HashMap<String, Object>();
    List<Map<String, Object>> lstItemsTotalActual = null;
    List lstItems = new ArrayList();
    
    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
    FechaBean fecActual = new FechaBean();
    
    params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
    params.put("NUM_SECITEM", request.getParameter("item_base"));
    params.put("COD_USUREGIS", bUsuario.getNroRegistro());
    params.put("FEC_REGIS", fecActual.getTimestamp());
    Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    
	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
	if (CollectionUtils.isEmpty(lstSeriesItemActual)){
		Map<String, Object> paramSerieItem = new HashMap<String, Object>();
		paramSerieItem.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
		List lstSeriesItem = serieService.obtenerSeriesItem(paramSerieItem);
		lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
	}

    //Lista de Items de la Factura seleccionada
    List<Map<String, Object>> listaItemsPorFacturaSeleccionada = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstItemFactura");

    lstItemsTotalActual = formatoValorService.obtenerListaItemsDeclaracionActual(mapCabDeclaraActual);

    for(Map<String, Object> map : lstItemsTotalActual){
    	for(Map<String, Object> item: listaItemsPorFacturaSeleccionada){
    		if(map.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())){
    			lstItems.add(map);
    		}
    	}
    }
      List<Map<String, Object>>lstItemsPorFactura = (List<Map<String, Object>>)Utilidades.copiarLista(lstItems);
    
      List<Map<String, Object>> nuevaLstItemPorFactura = formatoValorService.obtenerListaItemsIncluidoItemCopiado(params,
    		  lstItemsPorFactura, lstItemsTotalActual);

      session.setAttribute("lstItemFactura", nuevaLstItemPorFactura);
      
      //Agrega el nuevo Items(incluida dentro de la nueva lista) a la factura de la declaraci�n 
      String numSecFact = webRequest.getParameter("hdn_num_secfact");
      String numSecProve = webRequest.getParameter("hdn_num_secprove");
      this.colocarLstItemFacturas(mapCabDeclaraActual, nuevaLstItemPorFactura, numSecProve, numSecFact);
      
      //Actualiza cantidad de Items de Factura
  	  Map<String, Object> parametro = new HashMap<String,Object>();
	  parametro.put("EST_ITEM", "0");
	  parametro.put("NUM_SECFACT", numSecFact);
	  parametro.put("NUM_SECPROVE", numSecProve);
	  parametro.put("lstSeriesItemActual", lstSeriesItemActual);
      
      //Actualiza Monto de la Factura
      List<Map<String, Object>> lstFormBProveedor = (ArrayList) mapCabDeclaraActual.get("lstFormBProveedor");
      this.actualizarMtoFactura(lstFormBProveedor, parametro, lstSeriesItemActual);
      
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
      
      return new ModelAndView(
                            this.jsonView,
                            "OK",
                            "Se creo correctamente la copia. Por favor modifique los datos del item generado");
  }

  /** Retorna la lista de items(en sesi�n) asociados a la factura seleccionada previamente
  * @param request
  * @param response
  * @return
  * @throws Exception
  */
  public ModelAndView obtenerListadoItemsSesion(HttpServletRequest request, HttpServletResponse response)
	          throws Exception{
		
		HttpSession session = request.getSession();
		List<Map<String, Object>> nuevaLstItemFactura = (List<Map<String, Object>>) session.getAttribute("lstItemFactura");

	    return new ModelAndView(this.jsonView, "itemFactura", nuevaLstItemFactura);
  }
	
  /** Agrega la lista (actualizada) de �tems a la factura
  * @param declaracion [Map] Declaraci�n
  * @param lstItemFacturas [List] Lista de items actualizada
  * @param num_secprove [String] Numero secuencial del proveedor
  * @param num_secfact [String] N�mero secuencial de la factura
  */
  private void colocarLstItemFacturas(Map declaracion, List lstItemFacturas, String num_secprove, String num_secfact){
    if (declaracion != null && declaracion.size() > 0)
    {
      List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

      String codProv;
      String secFact;
      List lstItemfactAsig = new ArrayList();
      for (Map prov : lstProve)
      {
        codProv = prov.get("num_secprove").toString().trim();
        if (codProv.equals(num_secprove))
        {
          List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
          for (Map comPago : lstComproBPago)
          {
            secFact = comPago.get("num_secfact").toString().trim();
            if (secFact.equals(num_secfact))
            {
              lstItemfactAsig = Utilidades.copiarLista(lstItemFacturas);
              comPago.put("lstItemFactura", lstItemfactAsig);
              break;
            }
          }

        }
      }

    }
  }
  
  /** Valida si el �tem que se quiere eliminar se encuentra correlacionado a una serie, 
  * en caso tenga correlaci�n activa muestra un mensaje de alerta  
  * @param request
  * @param response
  * @return
  * @throws Exception
  */
  public ModelAndView validarExisteCorrelacionSerieItem(HttpServletRequest request, HttpServletResponse response)
  throws Exception{
	HttpSession session = request.getSession();
	ServletWebRequest webRequest = new ServletWebRequest(request);
	String num_corredoc = webRequest.getParameter("hdn_num_corredoc");
	String num_secitem = request.getParameter("num_secitem");
	
	Map<String, Object> param = new HashMap<String, Object>();
	param.put("NUM_CORREDOC", num_corredoc);

	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
	                    request,
	                    "lstSeriesItemActual");
	if (CollectionUtils.isEmpty(lstSeriesItemActual)){
		List lstSeriesItem = serieService.obtenerSeriesItem(param);
		lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
		session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
	}
	
	//Validaci�n correlaciones desactivar item
	boolean existe = false;
	String seriesRelacionadas = "";
	Map<String, String> mensajeResult = null;
	seriesRelacionadas = "";
	
	for(Map<String, Object> serieItem : lstSeriesItemActual){			    		
		if(serieItem.get("NUM_CORREDOC").toString().equals(num_corredoc)
		&& serieItem.get("NUM_SECITEM").toString().equals(num_secitem)
		&& serieItem.get("IND_DEL").toString().equals("0")){
			existe = true;
			seriesRelacionadas = seriesRelacionadas + (seriesRelacionadas.equals("")?"":", ")+ serieItem.get("NUM_SECSERIE").toString();
		}
	}
	
	if(existe){
		String mensaje = "El �tem "+num_secitem+" a eliminar tambi�n se encuentra correlacionado a la(s) serie(s) "+seriesRelacionadas;
		mensajeResult = new HashMap<String,String>();
		mensajeResult.put("desError", mensaje);
		
	}
	
	ModelAndView view = new ModelAndView(this.jsonView, "mensajeResult", mensajeResult);
	return view;
  }
  
  /** Actualiza el estado(eliminar/recuperar) del item a nivel de sesi�n "mapCabDeclaraActual"
 	* @param request
	* @param response
	* @throws Exception
	*/
    public void actualizarEstadoItemSesion(HttpServletRequest request, HttpServletResponse response)
	throws Exception{
	ServletWebRequest webRequest = new ServletWebRequest(request);
	HttpSession session = request.getSession();
	Map<String, Object> param = new HashMap<String, Object>();
	param.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
	String est_item = request.getParameter("est_item");
	String num_item = request.getParameter("num_item");
	
	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
	if (CollectionUtils.isEmpty(lstSeriesItemActual)){
		List lstSeriesItem = serieService.obtenerSeriesItem(param);
		lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
	}
	
	Map<String, Object> parametro = new HashMap<String,Object>();
	parametro.put("NUM_SECITEM", num_item);
	parametro.put("NUM_CORREDOC", param.get("NUM_CORREDOC"));
	parametro.put("EST_ITEM", est_item);
	parametro.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
	parametro.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
	parametro.put("lstSeriesItemActual", lstSeriesItemActual);
	Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	
	//Actualiza estado del Item y listas asociadas
	formatoValorService.actualizarEstadoItemSesion(mapCabDeclaraActual, parametro);
	session.setAttribute("lstSeriesItemActual", parametro.get("lstSeriesItemActual"));
	
	//Actualiza Monto Factura
	List<Map<String, Object>> lstFormBProveedor = (ArrayList) mapCabDeclaraActual.get("lstFormBProveedor");
	this.actualizarMtoFactura(lstFormBProveedor, parametro, lstSeriesItemActual);//contando solo la parte correlacionada de los items
	List<Map<String, Object>> lstItemFactura = this.obtenerlstItemsDeFactura(mapCabDeclaraActual, parametro);
	
	session.setAttribute("mapCabDeclaraActual", mapCabDeclaraActual);
	session.setAttribute("lstItemFactura", lstItemFactura);
	session.setAttribute("lstSeriesItemActual", (List<Map<String, Object>>)parametro.get("lstSeriesItemActual"));
	
    }

    /** Obtiene la lista de �tems de una factura
     * @param mapCabDeclaraActual
     * @param parametro
     * @return
     */
    private List<Map<String,Object>> obtenerlstItemsDeFactura(Map<String, Object> mapCabDeclaraActual, Map<String, Object> parametro){
    	
    	List<Map<String, Object>> lstItemFactura = null;
    	
        if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor")))
        {
          for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor"))
          {

            if (parametro.get("NUM_SECPROVE").toString().trim().equals(mapa.get("num_secprove").toString().trim()))
            {
              if (!CollectionUtils.isEmpty((List) mapa.get("lstComproBPago")))
              {
                for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapa.get("lstComproBPago"))
                {
                  if (parametro.get("NUM_SECFACT").toString().trim().equals(mapaFactura.get("num_secfact").toString().trim()))
                  {
                    lstItemFactura = (List<Map<String, Object>>) mapaFactura.get("lstItemFactura");
                   
                  }
                }
              }
            }
          }
        }

        return lstItemFactura;
    }
  
  /************************************ Correlaci�n ********************/
  
   /** Busca el(los) item(s) de una serie
    * @param request
 	* @param response
 	* @return
 	* @throws Exception
 	*/
    public ModelAndView obtenerItemsDisponibles(HttpServletRequest request, HttpServletResponse response) throws Exception{
	  
	  HttpSession session = request.getSession();
	  String num_secserie =  request.getParameter("txt_serie")==null ? "":request.getParameter("txt_serie");
	  String num_secitem = request.getParameter("txt_item")==null ? "":request.getParameter("txt_item");
	  
	  List<Map<String, Object>> lstItemsDisponibles = new ArrayList<Map<String,Object>>();
	  Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	  List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual");
	  String msgSerieValida = this.validarSerieAcorrelacionar(num_secserie, lstDetDeclaraActual);
	  String msgItem = "";
	  
	  if(msgSerieValida.isEmpty()){
		  
	      this.buscarItemsDisponibles(request, lstItemsDisponibles, declaracionActual);	
	      
	      session.setAttribute("lstItemsDisponibles", lstItemsDisponibles);    

	      if(CollectionUtils.isEmpty(lstItemsDisponibles)){
	    	  msgItem = this.validaItem(num_secserie, num_secitem, declaracionActual, request);
	      }

	  }	
	    ModelAndView view = new ModelAndView(this.jsonView, "lstItemsDisponibles", lstItemsDisponibles);
	    view.addObject("msgSerieValida", msgSerieValida);
	    view.addObject("msgItem", msgItem);
	    
	    return view;
  }

   /** Valida y retorna un mensaje si el �tem ya est� correlacionado a la serie, si no existe o est� en estado pendiente de grabar
    * @param num_secserie [String]
  	* @param num_secitem [String]
  	* @param declaracionActual [Map<String, Object>]
 	* @param request
  	* @return String Mensaje
  	* @throws Exception
   */
   public String validaItem(String num_secserie, String num_secitem, Map<String, Object> declaracionActual,
		   									HttpServletRequest request) throws Exception{

	   String msgItem = "";
	   if(!num_secitem.isEmpty() && isNumeric(num_secitem)){
		   
		List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
		List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>) 
											WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");
    	List<Map<String, Object>> listaItemFactura = new ArrayList<Map<String, Object>>();

	    List<Map<String,Object>> lstCorrelacionUnion = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);
	    boolean indItemCorrelacionado = false;
	    boolean indItemExiste = false;
	    boolean indItemPendiente = false;
	    
	    for(Map<String,Object> serieItem : lstCorrelacionUnion){
	    	
	    	if(serieItem.get("NUM_SECSERIE").toString().equals(num_secserie)
	    	   && serieItem.get("NUM_SECITEM").toString().equals(num_secitem)
	    	   && serieItem.get("IND_DEL").toString().equals("0")){
	    		
	    		indItemCorrelacionado = true;
	    		break;
	    	}
	    }
	    if(indItemCorrelacionado){
	    	msgItem = "�tem ya se encuentra correlacionado a la serie buscada";
	    }else{
	    	listaItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
	    	for(Map<String, Object> item : listaItemFactura){
	    		if(item.get("NUM_SECITEM").toString().equals(num_secitem)
	    		   && item.get("IND_DEL").toString().equals("0")
	    		   ){
	    			
	    			indItemExiste = true;
	    			if(item.get("IND_TIPO_REGISTRO").toString().equals("1") && item.get("ESTADO_REGISTRO").toString().equals("1")){//Pendiente
	    				indItemPendiente = true;
	    				break;
	    			}
	    			
	    		}
	    	}
	    	if(indItemExiste && indItemPendiente){
	    		msgItem = "El �tem se encuentra en estado Pendiente de grabar.";
	    	}else if(!indItemExiste){
	    		msgItem = "Ingrese �tem v�lido.";
	    	}
	    	
	    }
	    
	   }
	    return msgItem;
   }
    
  	/** Agrupa la lista de correlaciones en sesion "lstSeriesItemActual" y la lista de correlaciones temporales 
  	*  que a�n no est�n en la sesion "lstSeriesItemActual"
  	* @param lstSeriesItemActual
 	* @param lstCorrelacionTemporal
 	* @return
 	*/
    private List<Map<String,Object>> agruparListasCorrelacion(List<Map<String, Object>> lstSeriesItemActual, 
		  					List<Map<String, Object>> lstCorrelacionTemporal){
	  
	  //Une la lista de correlaci�n actual y la lista de correlaci�n temporal para mostrar en la columna "series correlacionadas al item"
	  List<Map<String,Object>> unionListaSerieItem = Utilidades.copiarLista((List)lstSeriesItemActual);
	  Map<String,Object> keys = null;
	  if(!CollectionUtils.isEmpty(lstCorrelacionTemporal)) {
		  for(Map<String,Object> serieItemTemp : lstCorrelacionTemporal){
			  
			  keys = new HashMap<String,Object>();
			  keys.put("NUM_SECITEM", serieItemTemp.get("NUM_SECITEM"));
			  keys.put("NUM_SECSERIE", serieItemTemp.get("NUM_SECSERIE"));
			  
			  Map<String,Object> serieItem = Utilidades.obtenerElemento(lstSeriesItemActual, keys);
				  
			  if(serieItem == null || serieItem.isEmpty()){
				  unionListaSerieItem.add(serieItemTemp);
			  }else{
				  int index = 0;
				 for(Map<String,Object> serieItemTp : unionListaSerieItem){
					 if(serieItemTemp.get("NUM_SECITEM").toString().equals(serieItemTp.get("NUM_SECITEM").toString())
					    && serieItemTemp.get("NUM_SECSERIE").toString().equals(serieItemTp.get("NUM_SECSERIE").toString())){
						 
						 unionListaSerieItem.set(index, serieItemTemp);
					 }
					 index++;
				 }
			  }
			  
		  }
	  }
	  return unionListaSerieItem;
  }
  
  /** Valida si un dato ingresado es n�merico
   * @param [String] cadena
   * @return boolean
   */
  private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
  
  /** retorna una lista de items(disponibles) no correlacionados a la serie buscada
 * @param request
 * @param lstItemsDisponibles [List<Map<String, Object>>]
 * @param declaracionActual [Map<String, Object>]
 */
  private void buscarItemsDisponibles(HttpServletRequest request, List<Map<String, Object>> lstItemsDisponibles,
		  							Map<String, Object> declaracionActual){
  	
	HttpSession session = request.getSession();
	List<Map<String, Object>> listaItemFactura = new ArrayList<Map<String, Object>>();
	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
	List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>) 
										WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");

	String num_secitem = request.getParameter("txt_item")==null ? "":request.getParameter("txt_item");
	String num_secserie = request.getParameter("txt_serie")==null ? "":request.getParameter("txt_serie"); 
	  	
	List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual");
	String serieValida = this.validarSerieAcorrelacionar(num_secserie, lstDetDeclaraActual);
    List<Map<String,Object>> lstCorrelacionUnion = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);
		  
	if(serieValida.isEmpty()){
			  
	    listaItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
    
	    //b�squeda por serie, lista todos los items no correlacionados a la serie buscada
	    if(num_secitem.equals("")){
			  for(Map<String, Object> item: listaItemFactura){
				 
				  this.cargarItemsDisponibles(num_secserie, item, lstItemsDisponibles, lstCorrelacionUnion);
				 
			  } 
				         
		//b�squeda por item y serie, lista el item no correlacionado a la serie
		}else if(!num_secitem.equals("")){
			  for(Map<String, Object> item: listaItemFactura){
				 
				  if(item.get("NUM_SECITEM").toString().equals(num_secitem)){
					  
					  this.cargarItemsDisponibles(num_secserie, item, lstItemsDisponibles, lstCorrelacionUnion);
					  break;
				  }
			  }
		}
		}

		this.actualizarCampoSeriesCorrelacionadas(lstItemsDisponibles, lstCorrelacionUnion);
		Ordenador.sortDesc(lstItemsDisponibles, "NUM_SECITEM", Ordenador.ASC);
		
  } 

	/** Filtra los �tems(disponibles) no correlacionados a la serie buscada
	 * @param num_secserie [String]
	 * @param item [Map<String, Object>]
	 * @param lstItemsDisponibles [List<Map<String, Object>>]
	 * @param lstSeriesItemActual [List<Map<String, Object>>]
	 */
	public void cargarItemsDisponibles(String num_secserie, 
			  Map<String, Object> item, List<Map<String, Object>> lstItemsDisponibles, 
			  List<Map<String, Object>> lstSeriesItemActual){
		  
	
		  boolean itemCorrelacionado = false;
		  Map itemCopia = new HashMap();
		  
		  for(Map<String, Object> serieItem : lstSeriesItemActual){
	
					if(num_secserie.equals(serieItem.get("NUM_SECSERIE").toString())
								&& item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
								&& item.get("NUM_CORREDOC").toString().equals(serieItem.get("NUM_CORREDOC").toString())
								&& !item.get("IND_DEL").toString().equals("1")
								&& serieItem.get("IND_DEL").toString().equals("0")
								&& item.get("NUM_SECFACT").toString().equals(serieItem.get("NUM_SECFACT").toString())
								&& item.get("NUM_SECPROVE").toString().equals(serieItem.get("NUM_SECPROVE").toString())){
								    		
						itemCorrelacionado = true;
						break;		    
					}
		  }
				
		  //valida si el item activo(y no correlacionado) est� en BD o en la sesion temporal, no se consideran los pendientes de grabar
		  if(!itemCorrelacionado
				&& ((item.get("ESTADO_REGISTRO").toString().equals("0") && item.get("IND_DEL").toString().equals("0"))//En BD
				|| (item.get("IND_TIPO_REGISTRO").toString().equals("0") && !item.get("IND_DEL").toString().equals("1")//Adicionado
				&&  item.get("ESTADO_REGISTRO").toString().equals("1")))) {
					 
					itemCopia = Utilidades.copiarMapa(item);
					lstItemsDisponibles.add(itemCopia);
						    	
		  }
	}
	
	/** Valida el estado de la serie buscada
	 * @param num_secserie [String]
	 * @param lstDetDeclaraActual [List<Map<String,Object>>]
	 * @return [String] Mensaje de validaci�n
	 */
	private String validarSerieAcorrelacionar(String num_secserie, List<Map<String,Object>> lstDetDeclaraActual){
		
	    String mensaje = "";
	    boolean indicador = false;
	    if(isNumeric(num_secserie)){
			for(Map<String, Object> serie : lstDetDeclaraActual){
				if(serie.get("NUM_SECSERIE").toString().equals(num_secserie) 
					&& "0".equals(serie.get("IND_DEL").toString()) ){
					
					indicador = true;
					if("1".equals(serie.get("IND_TIPO_REGISTRO"))){
						mensaje = "La Serie se encuentra en estado pendiende de Grabar";
					}
				}
			}
	    }
	    if(!indicador){
			mensaje = "Ingrese serie v�lida";
		}
	    
	    return mensaje;
	}

	/** Limpia las correlaciones temporales
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView limpiarCorrelacionesTemporales(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		List<Map<String, Object>> lstCorrelacionTemporal = new ArrayList<Map<String,Object>>(); 
		WebUtils.setSessionAttribute(request, "lstCorrelacionTemporal", lstCorrelacionTemporal);
		
		ModelAndView view = new ModelAndView(this.jsonView);

		return view;
	}
	
	/** Muestra una lista de items correlacionados a la serie buscada, 
	 *  muestra en otra lista los items no correlacionados(disponibles) a la serie buscada 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView obtenerDatosCorrelacionSerieItem(HttpServletRequest request, HttpServletResponse response) throws Exception{
		  
	  	HttpSession session = request.getSession();

		List<Map<String, Object>> lstItemsSerie = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> lstItemsDisponibles = new ArrayList<Map<String,Object>>();

		List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
		Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

		this.limpiarCorrelacionesTemporales(request, response);
		
		BigDecimal cantComerTemp = BigDecimal.ZERO;
		BigDecimal fobSerieTemp = BigDecimal.ZERO;
		    
		String num_secserie = request.getParameter("txt_serie");    
		Map<String,Object> mapItemCorrelacionado = new HashMap<String,Object>();
		List<Map<String, Object>> listaItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
		
		List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual");

		String msgSerieValida = "";
		
		if(isNumeric(num_secserie)){
			msgSerieValida = this.validarSerieAcorrelacionar(num_secserie, lstDetDeclaraActual);
			
		}
		
		if(!num_secserie.isEmpty() && msgSerieValida.isEmpty()){
			
		    for(Map<String, Object> item: listaItemFactura){
			    for(Map<String, Object> serieItemBus : lstSeriesItemActual){
			    		 
			     	mapItemCorrelacionado = new HashMap<String,Object>();

				    if(num_secserie.equals(serieItemBus.get("NUM_SECSERIE").toString())
				       && item.get("NUM_SECITEM").toString().equals(serieItemBus.get("NUM_SECITEM").toString())
				       && item.get("NUM_CORREDOC").toString().equals(serieItemBus.get("NUM_CORREDOC").toString())
				       && item.get("NUM_SECFACT").toString().equals(serieItemBus.get("NUM_SECFACT").toString())
				       && item.get("NUM_SECPROVE").toString().equals(serieItemBus.get("NUM_SECPROVE").toString())
				       && !item.get("IND_DEL").toString().equals("1")
				       && serieItemBus.get("IND_DEL").toString().equals("0")
				       && ((item.get("ESTADO_REGISTRO").toString().equals("0") && item.get("IND_DEL").toString().equals("0"))//En BD
				       || (item.get("IND_TIPO_REGISTRO").toString().equals("0") && !item.get("IND_DEL").toString().equals("1")//Adicionado
				       &&     item.get("ESTADO_REGISTRO").toString().equals("1")) )
					 ){
				     			
				     	  mapItemCorrelacionado.put("NUM_SECITEM", item.get("NUM_SECITEM").toString());
				     	  mapItemCorrelacionado.put("NUM_SECSERIE", serieItemBus.get("NUM_SECSERIE").toString());
				     	  mapItemCorrelacionado.put("NUM_SECFACT", item.get("NUM_SECFACT").toString());
				     	  mapItemCorrelacionado.put("NUM_SECPROVE", item.get("NUM_SECPROVE").toString());
				     	  mapItemCorrelacionado.put("DES_TIPO_REGISTRO", item.get("DES_TIPO_REGISTRO"));
				     	  mapItemCorrelacionado.put("NUM_CORREDOC", item.get("NUM_CORREDOC").toString());
				     	  mapItemCorrelacionado.put("NUM_PARARANCEL", item.get("NUM_PARARANCEL").toString());
				     	  mapItemCorrelacionado.put("IND_DESCMANTITEM", item.get("IND_DESCMANTITEM").toString());
				     	  mapItemCorrelacionado.put("DES_CARACTERISTICAS", item.get("DES_CARACTERISTICAS").toString());
				     	  mapItemCorrelacionado.put("COD_UNICOMER", item.get("COD_UNICOMER").toString());
				     	  mapItemCorrelacionado.put("CNT_MERC", serieItemBus.get("CNT_MERC"));
				     	  mapItemCorrelacionado.put("MTO_FOB", serieItemBus.get("MTO_FOB"));
				     	  mapItemCorrelacionado.put("IND_DEL", "0");
				     			
				     	  lstItemsSerie.add(mapItemCorrelacionado);
				     	  cantComerTemp = cantComerTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItemBus.get("CNT_MERC")));
				     	  fobSerieTemp = fobSerieTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItemBus.get("MTO_FOB")));
				     	  break;
				     	}
			    	}
		    	 }
		    	 
		      Ordenador.sortDesc(lstItemsSerie, "NUM_SECITEM", Ordenador.ASC);
		      this.actualizarCampoSeriesCorrelacionadas(lstItemsSerie, lstSeriesItemActual);
		 }
		
		 
		 session.setAttribute("lstItemsSerie", lstItemsSerie); 
		    
		 this.buscarItemsDisponibles(request, lstItemsDisponibles, declaracionActual); 
		 session.setAttribute("lstItemsDisponibles", lstItemsDisponibles);
		    
		 ModelAndView view = new ModelAndView(this.jsonView, "lstItemsSerie", lstItemsSerie);
		 view.addObject("lstItemsDisponibles",lstItemsDisponibles);
		 view.addObject("cantComerSerie",cantComerTemp.toString());
		 view.addObject("fobSerie",fobSerieTemp.toString());
		 view.addObject("msgSerieValida", msgSerieValida);
		    
		 return view;
	}
	
    /** actualiza el campo "LST_SERIES_CORR" (contiene las series a las que se encuentra correlacionado el item)
	 * de la lista de �tems que se ingresa como par�metro 
	 * @param listItems [List<Map<String, Object>>] lista de �tems
	 * @param lstSeriesItemActual [List<Map<String, Object>>] lista de correlaciones
	*/
	private void actualizarCampoSeriesCorrelacionadas(List<Map<String, Object>> listItems, List<Map<String, Object>> lstSeriesItemActual){
		  
		  List<Map<String,Object>> listSeriesCorrelacionadas = new ArrayList<Map<String,Object>>();
		  Map<String,Object> mapSerie = new HashMap<String,Object>();
		  String serieCorrelacionado = "";	
		  for(Map<String, Object> item: listItems){
				serieCorrelacionado = "";	
				listSeriesCorrelacionadas = new ArrayList<Map<String,Object>>();
			    for(Map<String, Object> serieItem : lstSeriesItemActual){
			    	if(item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
			    		&& item.get("NUM_CORREDOC").toString().equals(serieItem.get("NUM_CORREDOC").toString())
			    		&& serieItem.get("IND_DEL").toString().equals("0")
			    		&& item.get("IND_DEL").toString().equals("0")
			    		&& item.get("NUM_SECFACT").toString().equals(serieItem.get("NUM_SECFACT").toString())
			    		&& item.get("NUM_SECPROVE").toString().equals(serieItem.get("NUM_SECPROVE").toString())){
			    		
			    		mapSerie = new HashMap<String,Object>();
			    		mapSerie.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE"));
			    		listSeriesCorrelacionadas.add(mapSerie);
			    	}
			    }
			    
			    Ordenador.sortDesc(listSeriesCorrelacionadas, "NUM_SECSERIE", Ordenador.ASC);
			    for(Map<String,Object> serie : listSeriesCorrelacionadas){
			    	serieCorrelacionado = serieCorrelacionado + (serieCorrelacionado.equals("")?"":", ")+ serie.get("NUM_SECSERIE").toString();
			    }
			    item.put("LST_SERIES_CORR", serieCorrelacionado);
		  }
	} 
	
	/** agrega(Inserta/actualiza) una correlaci�n(serieItem) sobre lista de correlaciones temporales "lstCorrelacionTemporal".
	 *  Actualiza las 2 listas: items correlacionados a la serie y lista de items no correlacionados(disponibles) a la serie
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	*/
	public ModelAndView agregarCorrelacion(HttpServletRequest request, HttpServletResponse response) throws Exception{
		  
		  HttpSession session = request.getSession();
		  JSONArray array1 = JSONArray.fromObject(request.getParameter("hdn_lstSeriesItemPorItem"));
		  List<Map<String,Object>> lstSeriesItemPorItem = (List<Map<String, Object>>) JSONArray.toCollection(array1, Map.class);
		  List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
		  List<Map<String, Object>> lstItemsDisponibles = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstItemsDisponibles");
		  List<Map<String, Object>> lstItemsSerie = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstItemsSerie");
		  List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>) 
																WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");
		  
		  UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  FechaBean fecActual = new FechaBean();
		  
		  BigDecimal cantComerTemp = BigDecimal.ZERO;
		  BigDecimal fobSerieTemp = BigDecimal.ZERO;

		  String num_secitem = request.getParameter("num_item");  
	      String num_secserie = request.getParameter("txt_serie"); 

	      Map<String,Object> serieItemSearch = new HashMap<String, Object>();
	      Map<String,Object> serieItemNew = new HashMap<String, Object>();
	      Map<String,Object> serieItemActual = new HashMap<String, Object>();
	      Map<String,Object> itemNuevoCorrelacionado = new HashMap<String, Object>();
	      
	      if (CollectionUtils.isEmpty(lstCorrelacionTemporal)) {
	    	  lstCorrelacionTemporal = new ArrayList<Map<String,Object>>(); 
		  }
	 	  for(Map<String,Object> serieItem : lstSeriesItemPorItem){
	 		 serieItemSearch = new HashMap<String, Object>();
	 				
		 			Map<String, Object> fbKeys = new HashMap<String, Object>();
		 			fbKeys.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE").toString());
		 			fbKeys.put("NUM_SECITEM", serieItem.get("NUM_SECITEM").toString());
		 			
		 			serieItemSearch = (Map<String, Object>)Utilidades.obtenerElemento(lstSeriesItemActual, fbKeys);
		 			
	 				 //Agrega
		 			 if(serieItemSearch==null || serieItemSearch.isEmpty()){
		 				
		 				serieItemNew = Utilidades.copiarMapa(serieItem);
		 				serieItemNew.put("IND_DEL", "0");
		 				serieItemNew.put("COD_USUREGIS", bUsuario.getNroRegistro());
		 				serieItemNew.put("FEC_REGIS", fecActual.getTimestamp());
		 				serieItemNew.put("IND_CORRELACION_REMOVIDA", "0");
		 				serieItemNew.put("IND_DEL_ITEM", "0");
		 				lstCorrelacionTemporal = this.cargarCambiosCorrelacionTemp(lstCorrelacionTemporal, serieItemNew);
		 				
			 			    
			 		 }else{
			 			 
			 			 //Actualiza
			 				serieItemActual = Utilidades.copiarMapa(serieItemSearch);
			 				serieItemActual.put("CNT_MERC", serieItem.get("CNT_MERC"));
			 				serieItemActual.put("MTO_FOB", serieItem.get("MTO_FOB"));  
			 				serieItemActual.put("MTO_AJUSTE", serieItem.get("MTO_AJUSTE"));  
			 				serieItemActual.put("IND_DEL", "0");
			 				serieItemActual.put("COD_USUMODIF", bUsuario.getNroRegistro());
			 				serieItemActual.put("FEC_MODIF",fecActual.getTimestamp());
			 				serieItemActual.put("IND_CORRELACION_REMOVIDA", "0");
			 				serieItemActual.put("IND_DEL_ITEM", "0");
			 				lstCorrelacionTemporal = this.cargarCambiosCorrelacionTemp(lstCorrelacionTemporal, serieItemActual);
	 			   }
		  }
	 		session.setAttribute("lstCorrelacionTemporal", lstCorrelacionTemporal);

	 	  
		  //Remueve un item de la lista de Items disponibles
		  for(Map<String, Object> itemsDis : lstItemsDisponibles){
			  if(num_secitem.equals(itemsDis.get("NUM_SECITEM").toString())){
				  itemNuevoCorrelacionado = Utilidades.copiarMapa(itemsDis);
				  lstItemsDisponibles.remove(itemsDis);
				  break;
			  }
		  }	  
		  
		  //En lstSeriesItemPorItem est�n todas las correlaciones del item seleccionado
		  //Se agrega el nuevo Item a la lista de items correlacionados por serie
		  Map<String,Object> mapItemCorrelacionado = new HashMap<String,Object>();
		  for(Map<String,Object> serieItem : lstSeriesItemPorItem){
			  if(num_secitem.equals(serieItem.get("NUM_SECITEM").toString())
			     && num_secserie.equals(serieItem.get("NUM_SECSERIE").toString())){
				  
			    mapItemCorrelacionado = new HashMap<String,Object>();
		   		mapItemCorrelacionado.put("NUM_SECITEM", itemNuevoCorrelacionado.get("NUM_SECITEM").toString());
				mapItemCorrelacionado.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE").toString());
				mapItemCorrelacionado.put("DES_TIPO_REGISTRO", itemNuevoCorrelacionado.get("DES_TIPO_REGISTRO"));
				mapItemCorrelacionado.put("NUM_SECFACT", itemNuevoCorrelacionado.get("NUM_SECFACT").toString());
				mapItemCorrelacionado.put("NUM_SECPROVE", itemNuevoCorrelacionado.get("NUM_SECPROVE").toString());
				mapItemCorrelacionado.put("NUM_CORREDOC", itemNuevoCorrelacionado.get("NUM_CORREDOC").toString());
				mapItemCorrelacionado.put("NUM_PARARANCEL", itemNuevoCorrelacionado.get("NUM_PARARANCEL").toString());
				mapItemCorrelacionado.put("IND_DESCMANTITEM", itemNuevoCorrelacionado.get("IND_DESCMANTITEM").toString());
				mapItemCorrelacionado.put("DES_CARACTERISTICAS", itemNuevoCorrelacionado.get("DES_CARACTERISTICAS").toString());
				mapItemCorrelacionado.put("COD_UNICOMER", itemNuevoCorrelacionado.get("COD_UNICOMER").toString());
				mapItemCorrelacionado.put("CNT_MERC", serieItem.get("CNT_MERC"));
				mapItemCorrelacionado.put("MTO_FOB", serieItem.get("MTO_FOB"));
				mapItemCorrelacionado.put("IND_DEL", "0");
				break;
			  }
		  }
		  lstItemsSerie.add(mapItemCorrelacionado);
		  Ordenador.sortDesc(lstItemsSerie, "NUM_SECITEM", Ordenador.ASC);
		  
		  
		  //Une la lista de correlaci�n actual y la lista de correlaci�n temporal para mostrar en la columna "series correlacionadas al item"
		  List<Map<String,Object>> lstCorrelacionUnion = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);
		  this.actualizarCampoSeriesCorrelacionadas(lstItemsSerie, lstCorrelacionUnion);
		  
		  //calcular Cantidad Comercial y Fob de la serie
		  for(Map<String,Object> serieItem : lstItemsSerie){
 			cantComerTemp = cantComerTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")));
			fobSerieTemp = fobSerieTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("MTO_FOB")));
		  }
		  
		  session.setAttribute("lstItemsDisponibles", lstItemsDisponibles);
		  session.setAttribute("lstItemsSerie", lstItemsSerie);
	  	  
		  ModelAndView view = new  ModelAndView(this.jsonView, "lstItemsDisponibles", lstItemsDisponibles);
		  view.addObject("lstItemsSerie", lstItemsSerie);
		  view.addObject("cantComerSerie", cantComerTemp.toString());
		  view.addObject("fobSerie", fobSerieTemp.toString());
		  
		  return view; 

	}

	/** Actualiza/Inserta la correlacion sobre lista de correlaciones temporales
	 * @param lstCorrelacionTemporal [List<Map<String, Object>>]
	 * @param serieItem [Map<String,Object>]
	 * @return [List<Map<String, Object>>] lista de correlaciones actualizada
	*/
	private List<Map<String, Object>> cargarCambiosCorrelacionTemp(List<Map<String, Object>> lstCorrelacionTemporal, Map<String,Object> serieItem){
		  
	    int index = 0;
	   
	      
		Map<String, Object> fbKeys = new HashMap<String, Object>();
		fbKeys.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE").toString());
		fbKeys.put("NUM_SECITEM", serieItem.get("NUM_SECITEM").toString());
		
		if (CollectionUtils.isEmpty(lstCorrelacionTemporal)) {
			lstCorrelacionTemporal = new ArrayList<Map<String,Object>>(); 
		}

		Map<String,Object> serieItemSearch = (Map<String, Object>)Utilidades.obtenerElemento(lstCorrelacionTemporal, fbKeys);
		  
		//Agrega
		if(serieItemSearch==null || serieItemSearch.isEmpty()){
			lstCorrelacionTemporal.add(serieItem);
				 
		}else{
		//Actualiza
 			index = 0;
 			
 				for(Map<String, Object> correlacion : lstCorrelacionTemporal){
	 				if(correlacion.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
	 					&& correlacion.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())){
	 					  
	 					lstCorrelacionTemporal.set(index, serieItem);
	 					
	 					break;
	 				}
	 				index++;
 				}  
		}

		return lstCorrelacionTemporal;
	  }	  
	
	/** Quita una correlaci�n(serieItem) sobre lista de correlaciones temporales "lstCorrelacionTemporal".
	 *  Actualiza las 2 listas: items correlacionados a la serie y lista de items no correlacionados(disponibles) a la serie
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView quitarCorrelacion(HttpServletRequest request, HttpServletResponse response) throws Exception{
		  
		  HttpSession session = request.getSession();
		  List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) 
				  											WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
		  List<Map<String, Object>> lstItemsSerie = (List<Map<String, Object>>) 
				  									WebUtils.getSessionAttribute(request,"lstItemsSerie");
		  List<Map<String, Object>> lstItemsDisponibles = (List<Map<String, Object>>) 
				  											WebUtils.getSessionAttribute(request,"lstItemsDisponibles");
		  List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>) 
				  													WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");
		  UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		  
		  FechaBean fecActual = new FechaBean();
		  Map<String, Object> serieItemCopia = null;
		  Map<String, Object> serieItemSearch = null;
		  BigDecimal cantComerTemp = BigDecimal.ZERO;
		  BigDecimal fobSerieTemp = BigDecimal.ZERO;

		  String num_secitem = request.getParameter("num_item");  
		  String num_secprove = request.getParameter("num_secprove");  
		  String num_secfact = request.getParameter("num_secfact");  
		  String num_corredoc = request.getParameter("num_corredoc");  
	      String num_secserie = request.getParameter("num_serie"); 

	      //Remueve item de la lista de correlacion(de la serie buscada), remueve o inactiva de la lista Temporal "lstCorrelacionTemporal"
	      if (CollectionUtils.isEmpty(lstCorrelacionTemporal)) {
	    	  lstCorrelacionTemporal = new ArrayList<Map<String,Object>>(); 
		  }
	      for(Map<String, Object> itemCorr : lstItemsSerie){
	    	  if(itemCorr.get("NUM_SECITEM").toString().equals(num_secitem)
	    		 && itemCorr.get("NUM_SECSERIE").toString().equals(num_secserie)){
	    		  
	    		  Map<String, Object> fbKeys = new HashMap<String, Object>();
				  serieItemSearch = new HashMap<String, Object>();
				  fbKeys.put("NUM_SECSERIE", num_secserie);
				  fbKeys.put("NUM_SECITEM", num_secitem);
					
				  serieItemSearch = (Map<String, Object>)Utilidades.obtenerElemento(lstSeriesItemActual, fbKeys);
				  //Agregar a la lista de correlacion temporal
				  if(serieItemSearch != null && !serieItemSearch.isEmpty()){

					  serieItemCopia = Utilidades.copiarMapa(serieItemSearch);
					  serieItemCopia.put("IND_DEL", "1");
					  serieItemCopia.put("COD_USUMODIF", bUsuario.getNroRegistro());
					  serieItemCopia.put("FEC_MODIF", fecActual.getTimestamp());
					  serieItemCopia.put("IND_CORRELACION_REMOVIDA", "1");
					 
						  lstCorrelacionTemporal = this.cargarCambiosCorrelacionTemp(lstCorrelacionTemporal, serieItemCopia);
					  
				  }else{
					//Remover de la  Correlaci�n temporal
					  for (Iterator itSI = lstCorrelacionTemporal.iterator(); itSI.hasNext();){
						  Map serieItem = (HashMap) itSI.next();
						  if(serieItem.get("NUM_SECITEM").toString().equals(num_secitem)){
				            
				            itSI.remove();
					      }
					  }      
				  }
				  
	    		  lstItemsSerie.remove(itemCorr);
	    		  break;
	    	  }
	      }
	      session.setAttribute("lstItemsSerie", lstItemsSerie);
	      session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
	      session.setAttribute("lstCorrelacionTemporal", lstCorrelacionTemporal);
	      
		  List<Map<String,Object>> lstCorrelacionUnion = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);

	      //Repone items correlacionados a la lista de items Disponibles
		  Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	      List<Map<String, Object>> listaItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
	      
	      Map<String,Object> itemCopia = new HashMap<String,Object>();
	      Map<String,Object> itemDisponibleSearch = null;
	      for(Map<String, Object> item : listaItemFactura){
	    	  if(item.get("NUM_SECITEM").toString().equals(num_secitem)
	    		 && item.get("NUM_CORREDOC").toString().equals(num_corredoc)
	    		 && item.get("NUM_SECPROVE").toString().equals(num_secprove)
	    		 && item.get("NUM_SECFACT").toString().equals(num_secfact)){
	    		  
	    		  Map<String,Object> keys = new HashMap<String,Object>();
	    		  keys.put("NUM_SECITEM", item.get("NUM_SECITEM"));
	    		  itemDisponibleSearch = Utilidades.obtenerElemento(lstItemsDisponibles, keys);
	    		  if(itemDisponibleSearch == null || itemDisponibleSearch.isEmpty()){
		    		  itemCopia = Utilidades.copiarMapa(item);
		    		  lstItemsDisponibles.add(itemCopia);
	    		  }
	    		  break;
	    	  }
	      }
		  this.actualizarCampoSeriesCorrelacionadas(lstItemsDisponibles, lstCorrelacionUnion);

		  //calcular Cantidad Comercial y Fob de la serie
		  for(Map<String,Object> serieItem : lstItemsSerie){
   			cantComerTemp = cantComerTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")));
 			fobSerieTemp = fobSerieTemp.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("MTO_FOB")));
		  }
		  
		  if(CollectionUtils.isEmpty(lstItemsSerie)){
			 cantComerTemp = BigDecimal.ZERO;
			 fobSerieTemp = BigDecimal.ZERO;
		  }
		  Ordenador.sortDesc(lstItemsDisponibles, "NUM_SECITEM", Ordenador.ASC);
		  session.setAttribute("lstItemsDisponibles", lstItemsDisponibles);
		  
		  ModelAndView view = new  ModelAndView(this.jsonView, "lstItemsSerie", lstItemsSerie);
		  view.addObject("lstItemsDisponibles", lstItemsDisponibles);
		  view.addObject("cantComerSerie", cantComerTemp.toString());
		  view.addObject("fobSerie", fobSerieTemp.toString());
		  

		  
		  return view; 
		  
	  }
	  
	  /** lista las correlaciones(seriesItem) asociadas al item
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	  public ModelAndView obtenerSeriesItemPorItem(HttpServletRequest request, HttpServletResponse response) throws Exception{
			  
			   	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
				List<Map<String, Object>> lstItemsDisponibles = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstItemsDisponibles");
				 List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>)
						 WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");

			  	String num_secserie = request.getParameter("txt_serie");    

			   	List<Map<String, Object>> lstSeriesItemPorItem = new ArrayList<Map<String, Object>>();
			   	Map<String, Object> itemFactura = new HashMap<String, Object>();
			   	
			   	String num_item = request.getParameter("num_item");  
			   	String num_corredoc = request.getParameter("num_corredoc");  
			   	String num_secprove = request.getParameter("num_secprove");  
			   	String num_secfact = request.getParameter("num_secfact");  
			   	
			    List<Map<String,Object>> lstCorrelacionUnion = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);

			   	if(lstItemsDisponibles!=null){
			   	for(Map<String, Object> itemDis : lstItemsDisponibles){
				   	if(itemDis.get("NUM_SECITEM").toString().equals(num_item)
				   	   && itemDis.get("NUM_CORREDOC").toString().equals(num_corredoc)){
				   		itemFactura = itemDis;
				   		break;
				   	}
			   	}
			   	}
			   	for(Map<String, Object> serieItem : lstCorrelacionUnion){
			   		if(serieItem.get("NUM_SECITEM").toString().equals(num_item)
			   		   && serieItem.get("NUM_CORREDOC").toString().equals(num_corredoc) 
			   		   && serieItem.get("IND_DEL").toString().equals("0")
			   		   && serieItem.get("NUM_SECPROVE").toString().equals(num_secprove)
			   		   && serieItem.get("NUM_SECFACT").toString().equals(num_secfact)
			   		   ){
			   			
			   			lstSeriesItemPorItem.add(serieItem);
			   		}
			   		
			   	}
				 
			   	Map<String, Object> serieItemNew = new HashMap<String, Object>();
			   	serieItemNew.put("NUM_CORREDOC", itemFactura.get("NUM_CORREDOC"));
			   	serieItemNew.put("NUM_SECITEM", itemFactura.get("NUM_SECITEM"));
			   	serieItemNew.put("NUM_SECSERIE", num_secserie);
			   	serieItemNew.put("NUM_SECFACT", itemFactura.get("NUM_SECFACT"));
			   	serieItemNew.put("NUM_SECPROVE", itemFactura.get("NUM_SECPROVE"));
			   	serieItemNew.put("NUM_PARARANCEL",itemFactura.get("NUM_PARARANCEL"));
			   	serieItemNew.put("MTO_FOB", "0");
			   	serieItemNew.put("MTO_AJUSTE", "0");
			   	serieItemNew.put("CNT_MERC", "0");
			   	serieItemNew.put("IND_DEL", "0");

				lstSeriesItemPorItem.add(serieItemNew);
				
				Ordenador.sortDesc(lstSeriesItemPorItem, "NUM_SECSERIE", Ordenador.ASC);
			   	
			    Map<String, Object> view = new HashMap<String, Object>();
			    view.put("lstSeriesItemPorItem", lstSeriesItemPorItem);
			    view.put("itemFactura", itemFactura);
			    
			    return new ModelAndView(this.jsonView, "data", view);

	  }

	 /** Valida los montos que el �tem distribuir� a las series con las cuales se correlacionar�
	  * @param request
	  * @param response
	  * @return
	  * @throws Exception
	 */
     public ModelAndView validarCorrelacionSerieItem(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
     	 JSONArray array1 = JSONArray.fromObject(request.getParameter("hdn_lstSeriesItemPorItem"));
    	 List<Map<String,Object>> lstSeriesItemPorItem = (List<Map<String, Object>>) JSONArray.toCollection(array1, Map.class);
			    
		List<Map<String, Object>> lstItemsDisponibles = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstItemsDisponibles");
		
		Map<String, String> mensajeResult = null;
		Map<String, Object> itemFactura = new HashMap<String, Object>();
		String displayBtnAgregarCorrelacion = "1";
		BigDecimal redistribuirFaltante = BigDecimal.ZERO;
		BigDecimal cntMerc = BigDecimal.ZERO;
		boolean validaInicial = false;
		
		String num_item = request.getParameter("num_secitem");  
		String num_corredoc = request.getParameter("numcorredoc");  
		BigDecimal cntMercItem = BigDecimal.ZERO;
			   	
		for(Map<String, Object> itemDis : lstItemsDisponibles){
			if(itemDis.get("NUM_SECITEM").toString().equals(num_item)
			  && itemDis.get("NUM_CORREDOC").toString().equals(num_corredoc)){
				   	itemFactura = itemDis;
				   	break;
			}
		}
			     	
		for(Map<String,Object> serieItem : lstSeriesItemPorItem){
			    
			if(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")).compareTo(BigDecimal.ZERO) == -1
				|| Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")).compareTo(BigDecimal.ZERO) == 0){
				mensajeResult = new HashMap<String,String>();
				mensajeResult.put("desError", "Ingrese Cantidad diferente de cero. Si desea eliminar la correlaci�n utilice la opci�n Quitar.");
				
				validaInicial = true;
				break;
			}
				
			   cntMercItem = Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC"));
			   cntMerc = cntMerc.add(cntMercItem);     	
		}
		
		if(!validaInicial){
			BigDecimal cntUniItem = Utilidades.validaVacioRetornaBigDecimal(itemFactura.get("CNT_UNI"));
			if(cntMerc.compareTo(cntUniItem) == -1 || cntMerc.compareTo(cntUniItem) == 0){
	
				if(cntMerc.compareTo(cntUniItem) == -1){
					  redistribuirFaltante = cntUniItem.subtract(cntMerc);
					  String mensaje = " Existe una diferencia de "+redistribuirFaltante.toString()+" por distribuir �Desea continuar?";
					  mensajeResult = new HashMap<String, String>(); 
					  mensajeResult.put("desError", mensaje);
	
					  displayBtnAgregarCorrelacion = "0";
					  
				}
			}else{
				
				String mensaje = "La cantidad a redistribuir debe ser menor o igual a la cantidad del �tem";
				mensajeResult = new HashMap<String, String>(); 
				mensajeResult.put("desError", mensaje);
				  
			}	
		}
	
		ModelAndView view = new ModelAndView(this.jsonView, "mensajeResult", mensajeResult);
		view.addObject("displayBtnAgregarCorrelacion", displayBtnAgregarCorrelacion);
		
		return view;
	}

	/** Obtiene la lista de correlaciones temporales
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView obtenerCorrelacionTemporal(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>)WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");
		 
		ModelAndView view = new  ModelAndView(this.jsonView, "lstCorrelacionTemporal", lstCorrelacionTemporal);
		String msjCorrelacionPendiente = "";
		if(!CollectionUtils.isEmpty(lstCorrelacionTemporal)){
			msjCorrelacionPendiente = "Existen correlaciones pendientes de grabar. Se perder\u00e1n los cambios.\n\u00bfDesea descartar las correlaciones?";
		} 
		view.addObject("msjCorrelacionPendiente",msjCorrelacionPendiente);
			 
		return view;

	}
	
	/** Carga en sesion la serie a la cual se actualiz� correlaciones, actualiza el monto Fob y la Cantidad de Mercancia de las series 
	 *  asociadas a las correlaciones actualizadas
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView cargarListaSerieDesdeCorrelacionTemp(HttpServletRequest request, HttpServletResponse response) throws Exception{
		  
		HttpSession session = request.getSession();
		List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>)
				 											WebUtils.getSessionAttribute(request, "lstCorrelacionTemporal");

		List<Map<String, Object>> lstSeriesCorrelacion = new ArrayList<Map<String,Object>>();
		String numSecserie = request.getParameter("txt_serie");
		if(!CollectionUtils.isEmpty(lstCorrelacionTemporal)){
				 
		     List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");
		     List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");

		     List<Map<String, Object>> lstDetDeclaraActualBack = Utilidades.copiarLista((List)lstDetDeclaraActual);
			  
		     session.setAttribute("lstDetDeclaraActualBack", lstDetDeclaraActualBack);
		    
			 //Uni�n de la lista de correlaciones "lstSeriesItemActual" y la lista de correlaciones temporales "lstCorrelacionTemporal"
		     List<Map<String,Object>> lstUnionSeriesItemActual = this.agruparListasCorrelacion(lstSeriesItemActual, lstCorrelacionTemporal);
		     
			 Map<String, Object> serieValidar = null;
		     BigDecimal fobSerie = null;
		     BigDecimal cantComerSerie = null;      
		     
		     List<Map<String,Object>> lstFiltroSeries = this.filtrarSeries(lstCorrelacionTemporal);
		     
		     if (!CollectionUtils.isEmpty(lstUnionSeriesItemActual)){
			  for(Map<String,Object> serie : lstFiltroSeries){
				  
				      
				   for(Map<String,Object> detDeclaraMap : lstDetDeclaraActual){				      
					   fobSerie = BigDecimal.ZERO;
					   cantComerSerie = BigDecimal.ZERO;

					   if(detDeclaraMap.get("NUM_SECSERIE").toString().equals(serie.get("NUM_SECSERIE").toString())){
					    	
						   for(Map<String,Object> itemSerie : lstUnionSeriesItemActual){
			
					    		  if (detDeclaraMap.get("NUM_SECSERIE").toString().equals(itemSerie.get("NUM_SECSERIE").toString())	  
					    			  && detDeclaraMap.get("NUM_CORREDOC").toString().equals(itemSerie.get("NUM_CORREDOC").toString())
						        	  && itemSerie.get("IND_DEL").toString().equals("0")
						        	  ) {
						         
						        	  cantComerSerie = cantComerSerie.add(Utilidades.validaVacioRetornaBigDecimal(itemSerie.get("CNT_MERC")));
						        	  fobSerie = fobSerie.add(Utilidades.validaVacioRetornaBigDecimal(itemSerie.get("MTO_FOB")));
						        	  
						          }
					    	 }
					    	
					    	detDeclaraMap.put("CNT_COMER", cantComerSerie);
						    detDeclaraMap.put("MTO_FOBDOL", fobSerie);
						    if(this.validarCorrelacionSerie(detDeclaraMap, lstUnionSeriesItemActual)){
						    	detDeclaraMap.put("IND_SERIE_CORRELACIONADA", "0");
						    }else{
						    	detDeclaraMap.put("IND_SERIE_CORRELACIONADA", "1");
						    }
						    
						    serieValidar = new HashMap();
						    serieValidar.put("NUM_SECSERIE", detDeclaraMap.get("NUM_SECSERIE"));
						    lstSeriesCorrelacion.add(serieValidar);
					   }
				   }
			  }   
				       
			}
		     
			session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);
			session.setAttribute("lstSeriesCorrelacion", lstSeriesCorrelacion);
			
			session.setAttribute("serieCorrelacion", numSecserie);
		    }
		    
			ModelAndView view = new  ModelAndView(this.jsonView, "lstSeriesValidar", lstSeriesCorrelacion);
			view.addObject("serieCorrelacion", numSecserie);
			 
			return view;
   }
   
   /** Valida si la serie tiene correlaci�n activa
   * @param detDeclaraMap [Map<String,Object>] serie
   * @param listaSeriesItemActual [List<Map<String, Object>>] lista de correlaciones
   * @return [boolean]
   */
   private boolean validarCorrelacionSerie(Map<String,Object> detDeclaraMap, List<Map<String, Object>> listaSeriesItemActual){
		   
		   boolean indicadorCorrelacion = false; 
		   for(Map<String, Object> serieItem : listaSeriesItemActual){
			   if(serieItem.get("NUM_SECSERIE").toString().equals(detDeclaraMap.get("NUM_SECSERIE").toString())
				  && "0".equals(detDeclaraMap.get("IND_DEL").toString())
				  && "0".equals(serieItem.get("IND_DEL").toString())){
				   
				   indicadorCorrelacion = true; 
				   break;
			   }
		   }
		   return indicadorCorrelacion;
   }
	  
   /** retorna una lista de series(sin repetici�n) a partir de una lista de correlaciones
   * @param lstSeriesItem [List<Map<String, Object>>] lista de correlaciones
   * @return [List<Map<String,Object>>] lista de series
   */
   private List<Map<String,Object>> filtrarSeries(List<Map<String, Object>> lstSeriesItem){
	   
		  Map<String,Object> serie = null;
		  Map<String,Object> serieResult = null;
		  List<Map<String,Object>> lstFiltroSeries = new ArrayList<Map<String,Object>>();
		  int index = 0;
		  for(Map<String,Object> serieItem : lstSeriesItem){
			  serie = new HashMap<String,Object>();
			  if(index == 0){
				  serie.put("NUM_CORREDOC", serieItem.get("NUM_CORREDOC"));
				  serie.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE"));

				  lstFiltroSeries.add(serie);
			  }
			  index++;
			  serie = new HashMap<String,Object>();
			  serie.put("NUM_CORREDOC", serieItem.get("NUM_CORREDOC"));
			  serie.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE"));
			  
			  serieResult = Utilidades.obtenerElemento(lstFiltroSeries,serie);
			  if(serieResult==null || serieResult.isEmpty()){
				  lstFiltroSeries.add(serie);
			  }
		  }
		  
		  return lstFiltroSeries;
   }
	 

   /** Actualiza el monto de la factura en base a sus items activos correlacionados
    * @param lstFormBProveedor [List<Map<String, Object>>] lista de proveedores de la declaraci�n
    * @param mapPkSelecionadosParaModificar [Map<String, Object>] par�metros que incluyen id de proveedor y factura
    * @param lstSeriesItemActual [List<Map<String, Object>>]  lista de correlaciones
   */
   private void actualizarMtoFactura(List<Map<String, Object>> lstFormBProveedor,
                                           Map<String, Object> mapPkSelecionadosParaModificar, 
                                           List<Map<String, Object>> lstSeriesItemActual)
	{
	
	 if (!CollectionUtils.isEmpty(lstFormBProveedor)
	     && !CollectionUtils.isEmpty(mapPkSelecionadosParaModificar))
	 {
	
	   String numSecProveSelec = mapPkSelecionadosParaModificar.get("NUM_SECPROVE").toString().trim();
	   String numSecFactSelec = mapPkSelecionadosParaModificar.get("NUM_SECFACT").toString().trim();
	
	   for (Map<String, Object> mapProveedor : lstFormBProveedor)
	   {
	     String numSecProve = mapProveedor.get("num_secprove").toString().trim();
	     List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) mapProveedor.get("lstComproBPago");
	     if (numSecProveSelec.equals(numSecProve) && !CollectionUtils.isEmpty(lstComproBPago))
	     {
	
	       for (Map<String, Object> factura : lstComproBPago)
	       {
	         BigDecimal bgFacturaFobAcum = BigDecimal.ZERO;
	         List<Map<String, Object>> listaItemFacturas = (List<Map<String, Object>>) factura.get("lstItemFactura");
	
	         String numSecFact = factura.get("num_secfact").toString();
	         if (numSecFactSelec.equals(numSecFact) && !CollectionUtils.isEmpty(listaItemFacturas))
	         {
	           for (Map<String, Object> itemFactura : listaItemFacturas)
	           {
	              if(itemFactura.get("IND_DEL").toString().equals("0")){

		                if (!CollectionUtils.isEmpty(lstSeriesItemActual))
		                {
		                   for (Map<String, Object> itemSerie : lstSeriesItemActual)
		                   {
		                	 if(itemSerie.get("IND_DEL").toString().equals("0")
		                	 	&& itemSerie.get("NUM_SECITEM").toString().equals(itemFactura.get("NUM_SECITEM").toString())
		                	 	&& itemSerie.get("NUM_SECFACT").toString().equals(itemFactura.get("NUM_SECFACT").toString())
		                	 	&& itemSerie.get("NUM_SECPROVE").toString().equals(itemFactura.get("NUM_SECPROVE").toString())
		                	 	&& itemSerie.get("NUM_CORREDOC").toString().equals(itemFactura.get("NUM_CORREDOC").toString())){
		                		 
			                    BigDecimal bgFobItemSerie = new BigDecimal(itemSerie.get("MTO_FOB").toString());
			                    bgFacturaFobAcum = bgFacturaFobAcum.add(bgFobItemSerie);
		                     }
		                   }
		                }
	              }
	           }
	           factura.put("mto_fact", bgFacturaFobAcum);
	         }
	       }
	     }
	   }
	 }
	
	}
 
   /** Valida que el �tem que se va agregar a la serie sea de la misma unidad comercial y estado mercanc�a que la serie
    * @param request
    * @param response
    * @return
    * @throws Exception
   */
   public ModelAndView validarItemAagregar(HttpServletRequest request, HttpServletResponse response) throws Exception{

		String num_corredoc = request.getParameter("num_corredoc");
		String txt_serie = request.getParameter("txt_serie");
		String num_secprove = request.getParameter("num_secprove");
		String num_secfact = request.getParameter("num_secfact");
		String num_item = request.getParameter("num_item");
		
		String codUniComerItem = "";
		String codEstMercanciaItem = "";

		Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
		List<Map<String, Object>> listaItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
		for(Map<String, Object> item : listaItemFactura){
			if(item.get("NUM_SECITEM").toString().equals(num_item) 
				&& item.get("NUM_SECPROVE").toString().equals(num_secprove)
				&& item.get("NUM_SECFACT").toString().equals(num_secfact)
				&& item.get("NUM_CORREDOC").toString().equals(num_corredoc)){
				
				codUniComerItem = item.get("COD_UNICOMER").toString();
				codEstMercanciaItem = item.get("COD_ESTMERC").toString();
				break;
			}
		}

	    boolean indIgualUnidadComercial = false;
	    boolean indIgualEstadoMercancia = false;
	    StringBuilder mensaje = new StringBuilder();
	    String codUniComerSerie = "";
	    String codEstMercanciaSerie = "";
	    
		List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>)  WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
		for(Map<String, Object> serie : lstDetDeclaraActual){
			if(txt_serie.equals(serie.get("NUM_SECSERIE").toString())
		       && num_corredoc.toString().equals(serie.get("NUM_CORREDOC").toString()) ){
				
				codUniComerSerie = Utilidades.validarNuloOVacioRetornaString(serie.get("COD_UNICOMER"));
				codEstMercanciaSerie = Utilidades.validarNuloOVacioRetornaString(serie.get("COD_ESTMERC").toString());
				break;
			}
		}
		
	    if(codUniComerSerie.trim().equalsIgnoreCase(codUniComerItem.trim())){
	    	
	    	indIgualUnidadComercial = true;
	    }else{
	    	mensaje.append("El tipo de unidad comercial del �tem debe de ser igual al tipo de unidad comercial de la serie ("
	    					+codUniComerSerie+") para que pueda ser agregado");
	    }
	 
	    if(indIgualUnidadComercial){
 	    if(codEstMercanciaSerie.trim().equalsIgnoreCase(codEstMercanciaItem.trim())){
	    	
 	    	indIgualEstadoMercancia = true;
	    }else{
	    	mensaje.append("El tipo de estado mercancia del �tem debe de ser igual al tipo de estado mercancia de la serie ("
	    					+codEstMercanciaSerie+") para que pueda ser agregado");
	    }
	    }
	    
	    
		ModelAndView view = new  ModelAndView(this.jsonView, "indIgualUnidadComercial", indIgualUnidadComercial);
		view.addObject("mensaje", mensaje.toString());
		view.addObject("indIgualEstadoMercancia", indIgualEstadoMercancia);
		
		return view;
  }
   
	/** Remueve la sesi�n de correlaciones temporales "lstCorrelacionTemporal"
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ModelAndView cargaPaginaCorrelacion(HttpServletRequest request, HttpServletResponse response) throws Exception{
			 
	    Map<String, String> params = new HashMap<String, String>();
		   
	      params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	      params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
	      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
	      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
	      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
	      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
	      params.put("acceso", request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "");
	      request.setAttribute("params", params);
	      
		ModelAndView view = new ModelAndView(PAGINA_PRINCIPAL_DETALLE); 

		//inicio P28-PAS20155E410000032-[jlunah] Jira 3350
		view.addObject("lTipoRegularizacionDonacion",
        		SojoUtil.toJson(catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.TIPO_REGULARIZACION_DONACION)));
        //fin P28-PAS20155E410000032-[jlunah]


		return view;

	}

	/** Retorna un indicador para visualizar la p�gina de correlaci�n
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception
	 */
	public ModelAndView indicadorPaginaCorrelacion(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		List<Map<String, Object>> lstCorrelacionTemporal = new ArrayList<Map<String,Object>>(); 
		WebUtils.setSessionAttribute(request, "lstCorrelacionTemporal", lstCorrelacionTemporal);
		String indPagina = request.getParameter("indPagina").toString();
		WebUtils.setSessionAttribute(request, "flgPaginaSerieCorrelacion", indPagina);

		ModelAndView view = new  ModelAndView(this.jsonView);
			 
		return view;

	}
	
  /**
   * Sets the formato valor service.
   *
   * @param formatoValorService
   *          the new formato valor service
   */
  public void setFormatoValorService(FormatoValorService formatoValorService)
  {
    this.formatoValorService = formatoValorService;
  }


  /**
   *
   * @param serieService
   */
  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }
  
}