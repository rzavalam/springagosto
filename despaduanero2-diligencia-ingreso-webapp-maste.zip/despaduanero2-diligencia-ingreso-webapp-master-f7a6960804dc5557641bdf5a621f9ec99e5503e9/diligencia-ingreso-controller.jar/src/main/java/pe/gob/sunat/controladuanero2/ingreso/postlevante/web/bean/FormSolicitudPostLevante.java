package pe.gob.sunat.controladuanero2.ingreso.postlevante.web.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by amancillaa on 26/04/2016.
 */
public class FormSolicitudPostLevante implements Serializable {

    private static final long serialVersionUID = 6947090951865977853L;


    private String codAduana;
    private String annPresen;
    private String codRegimen;
    private String numDeclaracion;
    private String msjError;

    private String numOrden;
    private String codModalidad;
    private String razonSocial;
    private String ruc;
    private String garantia;
    private String fechaNumeracion;
    private String codCanal;
    private String codEstado;

    private String accion;
    private String numCorrelDeclaracion;
    private String numCorrelSolicitud;
    @JsonProperty("lstMotivos")
    private List<FormMotivo> lstMotivos;
    private String sustentoPostLevante;

    /************************** CONSTRUCTORES ******************************/

    public FormSolicitudPostLevante() {
        super();
        lstMotivos = new ArrayList<FormMotivo>();
    }

    public void cargarDefaultaCodigos(){
        lstMotivos = new ArrayList<FormMotivo>();
        lstMotivos.add(new FormMotivo("01","Boletin Quimico"));
        lstMotivos.add(new FormMotivo("02","Duda Razonable"));
        lstMotivos.add(new FormMotivo("03","Peco Amazonia"));
        lstMotivos.add(new FormMotivo("04","Indicadores de Riesgo Aduana Operativa"));
    }

    @JsonProperty("lstMotivos")
    public List<FormMotivo> getLstMotivos() {
        return lstMotivos;
    }
    @JsonProperty("lstMotivos")
    public void setLstMotivos(List<FormMotivo> lstMotivos) {
        this.lstMotivos = lstMotivos;
    }

    /**************************** SET AND GET *****************************************/

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getNumCorrelSolicitud() {
        return numCorrelSolicitud;
    }


    public void setNumCorrelSolicitud(String numCorrelSolicitud) {
        this.numCorrelSolicitud = numCorrelSolicitud;
    }

    public String getNumCorrelDeclaracion() {
        return numCorrelDeclaracion;
    }

    public void setNumCorrelDeclaracion(String numCorrelDeclaracion) {
        this.numCorrelDeclaracion = numCorrelDeclaracion;
    }

    public String getCodAduana() {
        return codAduana;
    }

    public void setCodAduana(String codAduana) {
        this.codAduana = codAduana;
    }

    public String getAnnPresen() {
        return annPresen;
    }

    public void setAnnPresen(String annPresen) {
        this.annPresen = annPresen;
    }

    public String getCodRegimen() {
        return codRegimen;
    }

    public void setCodRegimen(String codRegimen) {
        this.codRegimen = codRegimen;
    }

    public String getNumDeclaracion() {
        return numDeclaracion;
    }

    public void setNumDeclaracion(String numDeclaracion) {
        this.numDeclaracion = numDeclaracion;
    }

    public String getMsjError() {
        return msjError;
    }

    public void setMsjError(String msjError) {
        this.msjError = msjError;
    }

    public String getNumOrden() {
        return numOrden;
    }

    public void setNumOrden(String numOrden) {
        this.numOrden = numOrden;
    }

    public String getCodModalidad() {
        return codModalidad;
    }

    public void setCodModalidad(String codModalidad) {
        this.codModalidad = codModalidad;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getGarantia() {
        return garantia;
    }

    public void setGarantia(String garantia) {
        this.garantia = garantia;
    }

    public String getFechaNumeracion() {
        return fechaNumeracion;
    }

    public void setFechaNumeracion(String fechaNumeracion) {
        this.fechaNumeracion = fechaNumeracion;
    }

    public String getCodCanal() {
        return codCanal;
    }

    public void setCodCanal(String codCanal) {
        this.codCanal = codCanal;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado;
    }

    public String getSustentoPostLevante() {
        return sustentoPostLevante;
    }

    public void setSustentoPostLevante(String sustentoPostLevante) {
        this.sustentoPostLevante = sustentoPostLevante;
    }
}
