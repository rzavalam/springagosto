package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroEspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.service.EspecialistaService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DetalleComunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.FiltroDeclaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ReconocimientoFisicoOficio;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetalleComunicacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class SolicitudDespachoController extends MultiActionController {

	protected final Log log = LogFactory.getLog(getClass());
	private String jsonView;
	private CatalogoAyudaService catalogoAyudaService;
	private GetDeclaracionService getDeclaracionService;
	private ConsultaService consultaService;
	private SolicitudService solicitudService;
	private EspecialistaService especialistaService;
	//ggranados 179
	private FabricaDeServicios fabricaDeServicios;
	public static final String GRUPO_GER = "GER";

	/**
	 * Muestra la interfaz de b�squeda de Solicitudes de Reconocimiento F�sico
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView mostrarBusquedaSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) {
		FiltroDeclaracion filtroDeclaracion = new FiltroDeclaracion();
		filtroDeclaracion.setCodDocumentoAduanero(Constantes.COD_DOCUMENTO_ADUANERO);
		ServletWebRequest webRequest = new ServletWebRequest(request);
		String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : this.obtenerAduana(request);
		String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String.valueOf(Calendar.getInstance().get(
				Calendar.YEAR));
		String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
		String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion") : "";
		List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);
		Map<String, String> params = new HashMap<String, String>();
		params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map mapRoles = (Map)bUsuario.getMap().get("roles");
		if(mapRoles == null || !mapRoles.containsKey("JEFE.GRUPO.DOCUMENTARIO")){
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean.setMensajeerror("El Usuario no posee el rol Jefe de Grupo Documentario.");			
			return new ModelAndView("PagM", "beanM", mensajeBean);
		}	
		filtroDeclaracion.setCodAduana(codAduana);
		filtroDeclaracion.setAnnPresen(new Long(annPresen));
		filtroDeclaracion.setCodRegimen(codRegimen);
		filtroDeclaracion.setStrNumDeclaracion(numDeclaracion);
		ModelAndView view = new ModelAndView("BusqSolicitudReconFisico");
		view.addObject("params", params);
		view.addObject("filtroDeclaracion", filtroDeclaracion);
		return view;
	}

	/**
	 * Muestra la interfaz con el listado de Solicitudes de Reconocimiento
	 * F�sico
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView mostrarListadoSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) {
		ServletWebRequest webRequest = new ServletWebRequest(request);
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		Consulta filtroConsulta = new Consulta();
		if (dua != null && dua.getNumcorredoc() != null)// Dua en sessi�n
			filtroConsulta.setNumcorredoc(dua.getNumcorredoc());
		else {// Viene como parametro el numcorredoc
			String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
			filtroConsulta.setNumcorredoc(new Long(strNumcorredoc));
			dua = getDeclaracionService.getCabDUA(new Long(strNumcorredoc));
			WebUtils.setSessionAttribute(request, "dua", dua);

		}
		filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
		DataCatalogo catalogoMotivos = new DataCatalogo();
		catalogoMotivos.setCodCatalogo(Constantes.CAT_MOTIVO_DUA_NARANJA);
		filtroConsulta.setCatalogoMotivos(catalogoMotivos);
		filtroConsulta.setNumcorredocSol(new Long(0));
		List<Consulta> listSolicitudesReconFisico = consultaService.buscarConsulta(filtroConsulta);
		// Formateando fechas
		for (Consulta consulta : listSolicitudesReconFisico) {
			consulta.setStrFechaRegistro(SunatDateUtils.getFormatDate(consulta.getFechaRegistro(), "dd/MM/yyyy HH:mm"));
			consulta.setStrFechaRespuesta(SunatDateUtils.getFormatDate(consulta.getFechaRespuesta(), "dd/MM/yyyy HH:mm"));
		}
		ModelAndView view = new ModelAndView("ListSolicitudReconFisico");
		view.addObject("listSolicitudesReconFisico", listSolicitudesReconFisico);
		return view;
	}

	/**
	 * Realiza validaciones antes de mostrar la secci�n de resultado de la
	 * revisi�n en la diligencia.
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView validarSolicitudReconFisicoParaRevision(HttpServletRequest request, HttpServletResponse response) {
		ServletWebRequest webRequest = new ServletWebRequest(request);
		MensajeBean rBean = new MensajeBean();
		String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
		// Tiene solicitud de reconocimiento f�sico evaluada
		Consulta filtroConsulta = new Consulta();
		filtroConsulta.setNumcorredoc(new Long(strNumcorredoc));
		filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
		filtroConsulta.setIndicadorRespuesta("1");
		List<Consulta> listConsultasEvaluadas = consultaService.buscarConsulta(filtroConsulta);
		if (listConsultasEvaluadas.size() > 0) {
			rBean.setError(true);
			rBean.setMensajeerror("La declaraci�n ya posee una solicitud aceptada.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		ModelAndView view = new ModelAndView(jsonView, "beanM", rBean);
		return view;
	}

	/**
	 * Valida si la declaraci�n cuenta con solicitudes rechazadas
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView validarSolicitudRechazadas(HttpServletRequest request, HttpServletResponse response) {
		ServletWebRequest webRequest = new ServletWebRequest(request);
		MensajeBean rBean = new MensajeBean();
		String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
		// Tiene solicitud de reconocimiento f�sico evaluada
		Consulta filtroConsulta = new Consulta();
		filtroConsulta.setNumcorredoc(new Long(strNumcorredoc));
		filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
		filtroConsulta.setIndicadorRespuesta("0");
		List<Consulta> listConsultasEvaluadas = consultaService.buscarConsulta(filtroConsulta);
		if (listConsultasEvaluadas.size() >= 2) {
			rBean.setError(true);
			rBean.setMensajeerror("Declaraci�n cuenta con dos (2) solicitudes de pase a reconocimiento f�sico rechazadas.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		ModelAndView view = new ModelAndView(jsonView, "beanM", rBean);
		return view;
	}

	/**
	 * Grabar la solicitud de pase a reconocimiento f�sico
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception 
	 */
	@SuppressWarnings("finally")
	public ModelAndView grabarSolicitudReconocimientoFisico(HttpServletRequest request, HttpServletResponse response) throws Exception {
        /* olunar 83 */
        request.setCharacterEncoding("ISO-8859-1");
        /* fin */
		ServletWebRequest webRequest = new ServletWebRequest(request);
		MensajeBean rBean = new MensajeBean();
		JsonSerializer serializer = new JsonSerializer();
		String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
		String strDescResultado = webRequest.getParameter("txt_des_resultado");
		String strMotivo = webRequest.getParameter("selMotivo");
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

		ArrayList<String> listaMotivos = new ArrayList<String>();
		Map<String, ArrayList<String>> mapMotivos = new HashMap<String, ArrayList<String>>();
		listaMotivos.add(strMotivo);
		mapMotivos.put("amoti", listaMotivos);
		Consulta consulta = new Consulta();
		consulta.setNumcorredoc(new Long(strNumcorredoc));
		consulta.setNumcorredocSol(new Long(0));
		consulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
		consulta.getFuncionario().setCodPers(bUsuario.getNroRegistro());
		consulta.getFuncionario().setApPate(bUsuario.getApePaterno());
		consulta.getFuncionario().setApMate(bUsuario.getApeMaterno());
		consulta.getFuncionario().setNombres(bUsuario.getNombres());
		consulta.setDescripcion(strDescResultado);
		consulta.setStrMotivos(serializer.serialize(mapMotivos).toString());
		consulta.getCatalogoMotivos().setCodCatalogo(Constantes.CAT_MOTIVO_DUA_NARANJA);
		// try {
		consultaService.grabarSolicitudReconFisico(dua, consulta);
		/*
		 * } catch (ServiceException e) { rBean.setError(true);
		 * rBean.setMensajeerror(e.getMessage()); rBean.setMensajesol(
		 * "Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador."
		 * ); log.error(this.toString().concat(
		 * " grabarSolicitudReconocimientoFisico - ERROR : "
		 * ).concat(e.getMessage())); } catch (Exception e) {
		 * rBean.setError(true); rBean.setMensajeerror(e.getMessage());
		 * rBean.setMensajesol(
		 * "Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador."
		 * ); log.error(this.toString().concat(
		 * " grabarSolicitudReconocimientoFisico - ERROR : "
		 * ).concat(e.getMessage())); } finally {
		 */
		return new ModelAndView(this.jsonView, "beanM", rBean);
		/* } */
	}

	/**
	 * Validar la b�squeda de solicitudes para reconocimiento f�sico
	 * 
	 * @author olunar
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView validarBusquedaSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) {

		ServletWebRequest webRequest = new ServletWebRequest(request);
		// Recoger par�metros
		String codAduana = webRequest.getParameter("txt_cod_aduana") != null ? webRequest.getParameter("txt_cod_aduana").toString() : "";
		String annPresen = webRequest.getParameter("txt_ann_presen") != null ? webRequest.getParameter("txt_ann_presen") : String.valueOf(Calendar
				.getInstance().get(Calendar.YEAR));
		String codRegimen = webRequest.getParameter("sel_cod_regimen") != null ? webRequest.getParameter("sel_cod_regimen") : "";
		String numDeclaracion = webRequest.getParameter("txt_num_declaracion") != null ? webRequest.getParameter("txt_num_declaracion") : "";
		DUA dua = getDeclaracionService.getCabDUA(codAduana, numDeclaracion, annPresen, codRegimen);
		MensajeBean rBean = new MensajeBean();
		// Existe dua
		if (dua == null) {
			rBean.setError(true);
			rBean.setMensajeerror("La Declaraci�n no existe.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		// Tiene canal naranja
		if (!dua.getCodCanal().equals(Constantes.CANAL_NARANJA)) {
			rBean.setError(true);
			rBean.setMensajeerror("La Declaraci�n no tiene canal naranja.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		// Tiene solicitud de reconocimiento f�sico pendiente
		Consulta filtroConsulta = new Consulta();
		filtroConsulta.setNumcorredoc(dua.getNumcorredoc());
		filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
		filtroConsulta.setIndicadorRespuesta(" ");
		filtroConsulta.setFlagMotivos(true);
		List<Consulta> listConsulta = consultaService.buscarConsulta(filtroConsulta);
		if (listConsulta.size() == 0) {
			rBean.setError(true);
			rBean.setMensajeerror("la Declaraci�n no cuenta con solicitud de pase a Reconocimiento F�sico pendiente.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		Consulta consulta = (Consulta) listConsulta.get(0);
		if (consulta.getFechaRegistro() != null)
			consulta.setStrFechaRegistro(SunatDateUtils.getFormatDate(consulta.getFechaRegistro(), "dd/MM/yyyy HH:mm"));
		consulta.setFuncionario(solicitudService.getFuncionarioByCodPers(consulta.getFuncionario().getCodPers()));
		ModelAndView view = new ModelAndView(jsonView, "beanM", rBean);
		WebUtils.setSessionAttribute(request, "dua", dua);
		WebUtils.setSessionAttribute(request, "consulta", consulta);
		return view;
	}

	/**
	 * Mostrar la solicitud de reconocimiento f�sico
	 * 
	 * @author olunar
	 * 
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView mostrarSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) {

		ServletWebRequest webRequest = new ServletWebRequest(request);
		ModelAndView view = new ModelAndView("SolicitudReconFisico");
		Consulta consulta = new Consulta();
		String strConsulta = webRequest.getParameter("hdnConsulta") != null ? webRequest.getParameter("hdnConsulta") : "";
		// Viene como par�metro (invocado por el listado desolicitudes)
		if (!strConsulta.equals("")) {
			consulta = (Consulta) SojoUtil.fromJson(strConsulta);
			// Agregar nombre funcionario
			consulta.setFuncionario(solicitudService.getFuncionarioByCodPers(consulta.getFuncionario().getCodPers()));
			// Agregando descripci�n motivos
			JsonSerializer serializer = new JsonSerializer();
			Map<String, ArrayList<String>> mapIdMotivos = new HashMap<String, ArrayList<String>>();
			ArrayList<String> listaIdMotivos = new ArrayList<String>();
			mapIdMotivos = (Map<String, ArrayList<String>>) serializer.deserialize(consulta.getStrMotivos().trim(), HashMap.class);
			listaIdMotivos = (ArrayList<String>) mapIdMotivos.get("amoti");
			ArrayList<DataCatalogo> listaDataCatalogo = new ArrayList<DataCatalogo>();
			for (int j = 0; j < listaIdMotivos.size(); j++) {
				DataCatalogo motivo = new DataCatalogo();
				motivo.setCodDatacat(listaIdMotivos.get(j).toString());
				motivo.setDesDatacat(catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_MOTIVO_DUA_NARANJA, listaIdMotivos.get(j).toString()));
				listaDataCatalogo.add(motivo);
			}
			consulta.setMotivos(listaDataCatalogo);
			view.addObject("modo", "consulta");
		} else // Si viene por sesi�n (invocado por la b�squeda de solicitudes)
		{
			consulta = (Consulta) WebUtils.getSessionAttribute(request, "consulta");
			view.addObject("modo", "edicion");
		}
		WebUtils.setSessionAttribute(request, "consulta", consulta);
		return view;
	}

	/**
	 * Grabar la aceptacion de la solicitud de roconocimento f�sico
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception 
	 */
	@SuppressWarnings("finally")
	public ModelAndView grabarAceptacionSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) throws Exception {
        /* olunar 83 */
        request.setCharacterEncoding("ISO-8859-1");
        /* fin */
		MensajeBean rBean = new MensajeBean();
		ServletWebRequest webRequest = new ServletWebRequest(request);
		Consulta consulta = (Consulta) WebUtils.getSessionAttribute(request, "consulta");
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		// setear valores consulta
		String strObservacion = StringUtils.hasText(webRequest.getParameter("txtObservacion")) ? webRequest.getParameter("txtObservacion") : " ";
		consulta.setDescripcionRespuesta(strObservacion);
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		consulta.getAprobador().setCodPers(bUsuario.getNroRegistro());
		try {
			solicitudService.grabarAceptacionSolicitudReconFisico(dua, consulta);
		} catch (ServiceException e) {
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error(this.toString().concat(" grabarAceptacionSolicitudReconFisico - ERROR : ").concat(e.getMessage()));
		} catch (Exception e) {
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error(this.toString().concat(" grabarAceptacionSolicitudReconFisico - ERROR : ").concat(e.getMessage()));
		} finally {
			return new ModelAndView(this.jsonView, "beanM", rBean);
		}
	}

	/**
	 * Realizar la grabaci�n del rechazo de la solicitud
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 * @throws Exception 
	 */
	public ModelAndView grabarRechazoSolicitudReconFisico(HttpServletRequest request, HttpServletResponse response) throws Exception {
        /* olunar 83 */
        request.setCharacterEncoding("ISO-8859-1");
        /* fin */		
		MensajeBean rBean = new MensajeBean();
		ServletWebRequest webRequest = new ServletWebRequest(request);
		Consulta consulta = (Consulta) WebUtils.getSessionAttribute(request, "consulta");
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		// setear valores consulta
		String strObservacion = webRequest.getParameter("txtObservacion") != null ? webRequest.getParameter("txtObservacion") : " ";
		consulta.setDescripcionRespuesta(strObservacion);
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		consulta.getAprobador().setCodPers(bUsuario.getNroRegistro());
		consulta.getAprobador().setApPate(bUsuario.getApePaterno());
		consulta.getAprobador().setApMate(bUsuario.getApeMaterno());
		consulta.getAprobador().setNombres(bUsuario.getNombres());
		try {
			solicitudService.grabarRechazoSolicitudReconFisico(dua, consulta);
		} catch (ServiceException e) {
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error(this.toString().concat(" grabarAceptacionSolicitudReconFisico - ERROR : ").concat(e.getMessage()));
		} catch (Exception e) {
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error(this.toString().concat(" grabarAceptacionSolicitudReconFisico - ERROR : ").concat(e.getMessage()));
		}
		return new ModelAndView(this.jsonView, "beanM", rBean);
	}

	/**
	 * Realizar validaciones necesarias antes de efectuar rechazo de solicitud
	 * 
	 * @author olunar
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView validarRechazoSolicitud(HttpServletRequest request, HttpServletResponse response) {
		MensajeBean rBean = new MensajeBean();
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		//String nroRegistro = request.getParameter("codPers") != null ? request.getParameter("codPers") : " ";
		// Validar especialista
		FiltroEspeDispo filtroEspeDispo = new FiltroEspeDispo();
		//filtroEspeDispo.setCodPers(nroRegistro);
		filtroEspeDispo.setCodGrupoTrabajo(GRUPO_GER);
		filtroEspeDispo.setCodAduana(dua.getCodaduanaorden());
		filtroEspeDispo.setCodRegimen(dua.getCodregimen());
		// filtroEspeDispo.setCodTurno("");
		filtroEspeDispo.setIndicadorSoloVigente(1);
		ArrayList<EspeDispo> listaEspeDispo = (ArrayList<EspeDispo>) especialistaService.buscarEspeDispoSimple(filtroEspeDispo);
		if (CollectionUtils.isEmpty(listaEspeDispo)) {
			rBean.setError(true);
			rBean.setMensajeerror("S�rvase asignar la declaraci�n, el funcionario aduanero no se encuentra vigente.");
			return new ModelAndView(jsonView, "beanM", rBean);
		}
		return new ModelAndView(this.jsonView, "beanM", rBean);
	}

	/**
	 * Obtiene la aduana del usuario autenticado
	 * 
	 * @param request
	 * @return String
	 */
	private String obtenerAduana(HttpServletRequest request) {
		String res = "000";

		if (WebUtils.getSessionAttribute(request, "cAduana") != null) {
			res = (String) WebUtils.getSessionAttribute(request, "cAduana");
		} else {
			UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			Map adu = catalogoAyudaService.getTabdep(bUsuario.getCodUO());
			/*
			 * if (log.isDebugEnabled()) { log.debug("obtenerAduana : " + adu);
			 * }
			 */

			if (adu != null && adu.size() > 0) {
				if (adu.get("aduana") != null) {
					res = (String) adu.get("aduana");
				}
			}

			WebUtils.setSessionAttribute(request, "cAduana", res);
		}
		return res;
	}
	
	//ggranados 179 -Inicio
	/**
	 * Muestra la interfaz con la declaracion de Reconocimiento Fisico de Oficio
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView mostrarDeclaracionReconocimientoFisicoOficio(HttpServletRequest request, HttpServletResponse response) {
		ServletWebRequest webRequest = new ServletWebRequest(request);
		DUA dua = (DUA) WebUtils.getSessionAttribute(request, "dua");
		if (dua == null || dua.getNumcorredoc() == null){// Dua en sessi�n
			String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
			dua = getDeclaracionService.getCabDUA(new Long(strNumcorredoc));
		}
		
		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
		CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService"); 
		Map<String, Object> mapDeclRecFisOficio = new HashMap<String, Object>();
		Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
		String drfo_fecha = SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION").toString()), "dd/MM/yyyy HH:mm:ss");
		String drfo_modalidad = mapCabDeclara.get("COD_MODALIDAD").toString();
		String drfo_canal = mapCabDeclara.get("COD_CANAL_DESC").toString();
		String drfo_garantia = SunatStringUtils.isEmptyTrim(mapCabDeclara.get("NUM_CTACTE").toString()) ? "NO" : "SI";
  	  	DataCatalogo datacatalogoModalidad= catalogoAyuda.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_MODALIDAD_DESPACHO, drfo_modalidad);//306-Catalogo de modalidades
  	    drfo_modalidad = mapCabDeclara.get("COD_MODALIDAD").toString().concat(" - ").concat(datacatalogoModalidad.getDesCorta().toString());
  	    
  	    mapDeclRecFisOficio.put("drfo_fecha", drfo_fecha);
		mapDeclRecFisOficio.put("drfo_modalidad", drfo_modalidad);
		mapDeclRecFisOficio.put("drfo_canal", drfo_canal);
		mapDeclRecFisOficio.put("drfo_garantia", drfo_garantia);
		
		Map<String, Object> mapParticipante = new HashMap<String, Object>();
		mapParticipante.put("numeroCorrelativo", mapCabDeclara.get("NUM_CORREDOC").toString());
		mapParticipante.put("tipoDocumentoIdentidad", Constantes.TIPO_DOC_RUC);
		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_DEPOSITO_TEMPORAL);
		List<Participante> participante = participanteService.listarByParameterMap(mapParticipante);
		String drfo_deposito = " ";
		if(!CollectionUtils.isEmpty(participante)){
			drfo_deposito = "RUC: ".concat(participante.get(0).getNumeroDocumentoIdentidad().trim()).concat(" - ").concat(participante.get(0).getNombreRazonSocial().trim());
		}
		mapDeclRecFisOficio.put("drfo_deposito", drfo_deposito);
		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
		String drfo_importador = " ";
		participante = participanteService.listarByParameterMap(mapParticipante);
		if(!CollectionUtils.isEmpty(participante)){
			drfo_importador = "RUC: ".concat(participante.get(0).getNumeroDocumentoIdentidad().trim()).concat(" - ").concat(participante.get(0).getNombreRazonSocial().trim());
		}		
		mapDeclRecFisOficio.put("drfo_importador", drfo_importador);
		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);
		String drfo_agencia = " ";
		participante = participanteService.listarByParameterMap(mapParticipante);
		if(!CollectionUtils.isEmpty(participante)){
			drfo_agencia = "RUC: ".concat(participante.get(0).getNumeroDocumentoIdentidad().trim()).concat(" - ").concat(participante.get(0).getNombreRazonSocial().trim());
		}		
		mapDeclRecFisOficio.put("drfo_agencia", drfo_agencia);
		
		Map<String, Object> mapDetalle = new HashMap<String, Object>();
		mapDetalle.put("numCorredoc", mapCabDeclara.get("NUM_CORREDOC").toString().trim());
		mapDetalle.put("detDescnoti", "1");
		mapDetalle.put("tipoDiligencia", "01");
		DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
		List<DetalleComunicacion> lstDetalleNotificacion = detalleComunicacionDAO.findDetalleComunicacionNotificacionParaDeclaracionOficio(mapDetalle);
		if(!lstDetalleNotificacion.isEmpty()){
			for(DetalleComunicacion deNot : lstDetalleNotificacion){
				//HashMap<String, Object> detalleNotificacion = (HashMap<String, Object>) new JsonSerializer().deserialize(deNot.getDesDetalle(), HashMap.class);
				if (SojoUtil.fromJson(deNot.getDesDetalle()) instanceof ReconocimientoFisicoOficio){
					ReconocimientoFisicoOficio detalleNotificacion = (ReconocimientoFisicoOficio) SojoUtil.fromJson(deNot.getDesDetalle());
					mapDeclRecFisOficio.put("drfo_funcionario", detalleNotificacion.getFuncionarioRecFisicioOficio());
					mapDeclRecFisOficio.put("drfo_fecha_reconocimiento", SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(detalleNotificacion.getFechaRecFisicoOficio()), "dd/MM/yyyy"));
					mapDeclRecFisOficio.put("drfo_hora_reconocimiento", SunatStringUtils.substring(detalleNotificacion.getHoraRecFisicoOficio(), 1, 6));
					mapDeclRecFisOficio.put("drfo_lugar_reconocimiento", detalleNotificacion.getReferenciaRecFisicoOficio());
					mapDeclRecFisOficio.put("drfo_descripcion", detalleNotificacion.getDescripcionRecFisicioOficio());
					mapDeclRecFisOficio.put("drfo_copia", detalleNotificacion.getRaEnvioConsig());
					mapDeclRecFisOficio.put("drfo_fecha_registro", SunatDateUtils.getFormatDate(detalleNotificacion.getFecRegis(), "dd/MM/yyyy HH:mm"));
					break;
				}
				
				/*if (detalleNotificacion.containsKey("ind_recfisicooficio")){
					mapDeclRecFisOficio.put("drfo_funcionario", detalleNotificacion.get("funcionarioRecFisicioOficio"));
					mapDeclRecFisOficio.put("drfo_fecha_reconocimiento", detalleNotificacion.get("fechaRecFisicoOficio"));
					mapDeclRecFisOficio.put("drfo_hora_reconocimiento", detalleNotificacion.get("horaRecFisicoOficio"));
					mapDeclRecFisOficio.put("drfo_lugar_reconocimiento", detalleNotificacion.get("referenciaRecFisicoOficio"));
					mapDeclRecFisOficio.put("drfo_descripcion", detalleNotificacion.get("descripcionRecFisicioOficio"));
					mapDeclRecFisOficio.put("drfo_copia", detalleNotificacion.get("raEnvioConsig"));
					mapDeclRecFisOficio.put("drfo_fecha_registro", detalleNotificacion.get("fec_regis"));
					break;
				}*/
			}
		}
		ModelAndView view = new ModelAndView("DeclReconFisicOficio"); 
		view.addObject("mapDeclRecFisOficio", mapDeclRecFisOficio);
		return view;
	}	
	//ggranados 179 -Fin

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void setGetDeclaracionService(GetDeclaracionService getDeclaracionService) {
		this.getDeclaracionService = getDeclaracionService;
	}

	public void setConsultaService(ConsultaService consultaService) {
		this.consultaService = consultaService;
	}

	public void setSolicitudService(SolicitudService solicitudService) {
		this.solicitudService = solicitudService;
	}

	public void setEspecialistaService(EspecialistaService especialistaService) {
		this.especialistaService = especialistaService;
	}
	
	//ggranados 179
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

}
