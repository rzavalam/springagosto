package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.declaracion.model.SolicitudRecepcion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;//P14
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaPreviaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.entradasalida.service.EntradaSalidaService;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
//VRD-PAS20165E220200048
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.sigad.sini.service.SiniConsultaService;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.WUtil;//P24
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ValidaDiligenciaService;//P24
import pe.gob.sunat.despaduanero2.declaracion.recepcion.service.RecepcionDocumentosService;//PAS20165E220200099
import pe.gob.sunat.despaduanero2.declaracion.model.SolicitudRecepcion;//PAS20165E220200099
import pe.gob.sunat.despaduanero2.declaracion.recepcion.util.ConstantesDeclaracion;//PAS20165E220200099
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;

public class DiligenciaPreviaController extends AbstractDespachoController {
	private DiligenciaPreviaService diligenciaPreviaService;
	
//	<EHR>P14
	private DeclaracionService declaracionService;
//	</EHR>
	private BindingResult errors;
	private FabricaDeServicios fabricaDeServicios;//VRD-PAS20165E220200048
	private ValidaDiligenciaService validaDiligenciaService;//P24
	private static final String DEFAULT_TIPO_DOC = "01"; //p24 PAS20165E220200099
	private SolicitudRecepcion solicitudRecepcion; //p24 PAS20165E220200099	
	private RectificacionService rectificacionService;
	private static final String FORMAT_ddMMyyyy = "dd/MM/yyyy"; //p24 PAS20165E220200099
	
	protected void bind(HttpServletRequest request, Object command) throws Exception {
        ServletRequestDataBinder binder = createBinder(request, command);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
        binder.registerCustomEditor(Date.class, editor);
        binder.bind(request);
        errors = binder.getBindingResult();
    }
	
	/**
	 * Carga la p�gina incial de b�squeda de declaraci�n
	 * @param request
	 * @param response
	 * @return Vista de b�squeda de declaraci�n
	 * @author gbecerrav
	 */
	public ModelAndView cargarBusquedaDeclaracion(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - cargarBusquedaDeclaracion");
		}
		
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);	
			WebUtils.setSessionAttribute(request, "codigoDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			//request.setAttribute("aduana", this.obtenerAduana(usuario));
			Map<String, String> params = new HashMap<String, String>();
			String aduana=this.obtenerAduana(usuario);
			params.put("aduana", aduana);
			List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", aduana);
			params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
			
			ModelAndView res = new ModelAndView("/DiligenciaPrevia/BusqDeclaracion", "params", params);
			return res;
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
		    return showErrorPagM(e.getMessage());
		}
		
		//if (log.isDebugEnabled()) {
		//	log.debug("Fin - cargarBusquedaDeclaracion");
		//}
		
		//return new ModelAndView("/DiligenciaPrevia/BusqDeclaracion");
	}
	
	/**
	 * Busca la declaraci�n y sobre esta realiza 
	 * las validaciones para el proceso de diligencia previa
	 * @param request
	 * @param response
	 * @return Error de validaci�n de b�squeda de declaraci�n � vacio
	 * @author gbecerrav
	 */
	public ModelAndView buscarDeclaracion(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - buscarDeclaracion");
		}
		
		Map<String, Object> modelo = new HashMap<String, Object>();
		
		try{
			
			UsuarioBean usuario = this.verificarAutenticacion(request);	
			
			UserNameHolder.set(usuario.getNroRegistro(), request.getRemoteAddr());
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String aduana = webRequest.getParameter("hdn_cod_aduana");		
			String anio = webRequest.getParameter("anioDeclaracion");
			String regimen = webRequest.getParameter("codRegimen");
			String numero = webRequest.getParameter("numDeclaracion");
			
			//Validar la declaracion para el proceso de diligencia previa, si todo ok obtiene declaracion
			ObjectResponseUtil rpta = this.diligenciaPreviaService.validarDeclaracion(aduana, anio != null ? Integer.parseInt(anio) : null, regimen, numero != null ? Integer.parseInt(numero) : null, usuario);
			modelo.put("tieneDiligencia", rpta.getDatos()!=null?rpta.getDatos().get("regOK"):"");//P24	
			if(!rpta.isRespuesta()){
				modelo.put("Error", rpta.getMensajes().get(rpta.getMensajes().size()-1));
				return new ModelAndView("jsonView", modelo);
			}
			
			//Obtenemos los datos adicionales de la declaracion
			Declaracion declaracion = (Declaracion)rpta.getDatos().get("declaracion");
			//PAS20145E220000427 - mtorralba 20150922 - Inicio
			//ggranados diligencia previa sigesi
			if(!CollectionUtils.isEmpty(rpta.getMensajes())) {
				modelo.put("advertencia", rpta.getMensajes().get(0));
			}
			//PAS20145E220000427 - mtorralba 20150922 - Fin
			this.diligenciaPreviaService.adicionarDatosDeclaracion(declaracion);
			WebUtils.setSessionAttribute(request, "declaracion", declaracion);
			
			
						
			 //inicio mostrar datos rectificados

			
	    	  String numCorreDoc = declaracion.getDua().getNumcorredoc().toString();	    	  
	    	  Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
	    	  List<Map<String, Object>> listaElemObservacion =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);
	    	// en el JSP RegDiligenciaDespacho estan estos 2 listas
	          List<Map<String, Object>> listaElemObservacionDecla       = new ArrayList();
	         // List<Map<String, Object>> listaElemObservacionItemFactura = new ArrayList();

	          if (!CollectionUtils.isEmpty(listaElemObservacion))
	          {
	            for (Map<String, Object> mapObs : listaElemObservacion)
	            {

	              String codTipObs = mapObs.get("PK").toString();
	              if(codTipObs.startsWith("01"))
	              {
	                listaElemObservacionDecla.add(mapObs);
	              }
	              /* NO SE MUESTRA ESTE CAMPO EN LA CONSULTAS PERO CUANDO SE MUESTRE HABILITAR
	              else if(codTipObs.startsWith("03"))
	              {
	                listaElemObservacionItemFactura.add(mapObs);
	              }*/
	            }
	          }
	    	  List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);
	    	  List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
	    	  listaElemCabDeclara.addAll(listaElemObservacionDecla);
	          listaElemCabDeclara.addAll(listaElemParticipantesDUA);   
	          List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);
		      List<Map<String, Object>> listaElemFacturasSeries = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU);//PAS20175E220200035
		      List<Map<String, Object>> listaElemComprobantePago = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);//PAS20175E220200035
		      List<Map<String, Object>> listaElemFacturaSuce = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FACTUSUCE);//PAS20175E220200035
		      listaElemDetDeclara.addAll(listaElemFacturaSuce);//PAS20175E220200035
		      listaElemDetDeclara.addAll(listaElemComprobantePago);//PAS20175E220200035 
		      
     
	    		        WebUtils.setSessionAttribute(request,
	                            "camposModificadosDUA",
	                            (!CollectionUtils.isEmpty(listaElemCabDeclara)
	                                                                          ? SojoUtil.toJson(listaElemCabDeclara)
	                                                                          : "[]"));
	    		        WebUtils.setSessionAttribute(request,
                            "camposModificadosSERIE",
                            (!CollectionUtils.isEmpty(listaElemDetDeclara)
                                                                          ? SojoUtil.toJson(listaElemDetDeclara)
                                                                          : "[]"));
	    		        
	    		        WebUtils.setSessionAttribute(request,
                                "camposModificadosFacturasSeries",
                                (!CollectionUtils.isEmpty(listaElemFacturasSeries) 
                                                                              ? SojoUtil.toJson(listaElemFacturasSeries)
                                                                              : "[]")); //PAS20175E220200035
	    		        WebUtils.setSessionAttribute(request,
                                "camposModificadosComprobantePago",
                                (!CollectionUtils.isEmpty(listaElemComprobantePago)
                                                                              ? SojoUtil.toJson(listaElemComprobantePago)
                                                                              : "[]"));	//PAS20175E220200035   	
	    		        
	    		        WebUtils.setSessionAttribute(request,
                                "camposModificadosFacturaSuce",
                                (!CollectionUtils.isEmpty(listaElemFacturaSuce)
                                                                              ? SojoUtil.toJson(listaElemFacturaSuce)
                                                                              : "[]"));	//PAS20175E220200035    		        
	    		        
	    	  
	    		   if (!declaracion.getDua().getCodEstdua().toString().equals("03")){
	    			   WebUtils.setSessionAttribute(request,"camposModificadosSERIE","[]");
	    		   }
			 //fin motrar datos rectificados
					
			
			
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		if (log.isDebugEnabled()) {
			log.debug("Fin - buscarDeclaracion");
		}
		
		return new ModelAndView("jsonView", modelo);
	}

	
	/**
	 * @author jlunah
	 * */
	private List<Map<String, Object>> obtenerListaModificaciones(
			Map<String, Object> mapaRSPTADatosModificados,
			String codTablaCabDeclara) {

		return mapaRSPTADatosModificados.get(codTablaCabDeclara) != null ? (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados
				.get(codTablaCabDeclara) : new ArrayList<Map<String, Object>>();
	}
	
	/**
	 * Carga la p�gina para iniciar la diligencia previa
	 * @param request
	 * @param response
	 * @return Vista de Iniciar Diligencia Previa
	 * @author gbecerrav
	 */
	public ModelAndView cargarIniciarDiligenciaPrevia(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
		String modifDilig = request.getParameter("hdn_modifDilig")!=null?request.getParameter("hdn_modifDilig"):"";//P24
		WebUtils.setSessionAttribute(request, "modifDilig", modifDilig);//P24
		if(ConstantesDataCatalogo.COD_DUA_ASIGNADA.equals(declaracion.getDua().getCodEstdua())){
			return new ModelAndView("/DiligenciaPrevia/IniciarDiligenciaPrevia");
		}
		else{
			try{
				UsuarioBean usuario = this.verificarAutenticacion(request);
				//Se actualiza la declaracion a estado de revision
				//Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
				if(ConstantesDataCatalogo.COD_DUA_ENREVISION.equals(declaracion.getDua().getCodEstdua()) && modifDilig.isEmpty()){//P24 Pase 134 2016
					this.diligenciaPreviaService.actualizarDeclaracionEnRevision(declaracion, usuario);
				}
			      //PAS20155E220000521
			      if ( this.isImportadorFrecuente(declaracion.getDua().getNumcorredoc()) ) {
			    	  WebUtils.setSessionAttribute(request, "indImportadofrecuente", "Importador Frecuente");
			      } else {
			    	  WebUtils.setSessionAttribute(request, "indImportadofrecuente", " ");  
			      }
			     //PAS20155E220000521   
				
				Map<String, Object> paramsDua = new HashMap<String, Object>();
				paramsDua.put("NUM_DECLARACION", declaracion.getDua().getNumdocumento());  
				paramsDua.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden());  
				paramsDua.put("ANN_PRESEN", declaracion.getDua().getAnnpresen());  
				paramsDua.put("COD_REGIMEN", declaracion.getDua().getCodregimen());
				paramsDua.put("EN_PROCESO", "0");
				Map<String, Object> paramsDeclaracion = declaracionService.obtenerDeclaracion(paramsDua);
				
				//PAS20165E220200099-Inicio
				Map<String, Object> mapaEstadoRegu = determinarEstadoRegularizacion(paramsDeclaracion); 
				paramsDeclaracion.putAll(mapaEstadoRegu);	 	
				
				Long numeroCorrelativo = new Long(paramsDeclaracion.get("NUM_CORREDOC").toString());
				RecepcionDocumentosService recepcionDocumentosService = fabricaDeServicios.getService("declaracion.service.RecepcionDocumentosService1");
				List<SolicitudRecepcion> solicitudesRecepciones = recepcionDocumentosService.buscarSolicitudPorDeclaracion(numeroCorrelativo, "",false, "");
				Map<String, Object> mapaSolicitudes = recepcionDocumentosService.listarRecepcionesConsultaDUA(solicitudesRecepciones);
				paramsDeclaracion.put("bandera", 0);
				paramsDeclaracion.put("FEC_RECEP1", null);
				paramsDeclaracion.put("NUMEROCORRELATIVO1", null);
				paramsDeclaracion.put("NUMGED1", null);
				paramsDeclaracion.put("FEC_RECHA1", null);
				paramsDeclaracion.put("FEC_RECEP2", null);
				paramsDeclaracion.put("NUMEROCORRELATIVO2", null);
				paramsDeclaracion.put("NUMGED2", null);
				paramsDeclaracion.put("FEC_RECHA2", null);
				if (!mapaSolicitudes.get("existesolicitudes").toString().equals(ConstantesDeclaracion.NO_EXISTE_SOLICITUD)) {
					if (mapaSolicitudes.get("solicitudPrimeraRecepcion") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudPrimeraRecepcion");
						paramsDeclaracion.put("FEC_RECEP1",
								solicitudRecepcion.getFechaRecepcion()); 
						paramsDeclaracion.put("NUMEROCORRELATIVO1",
								solicitudRecepcion.getNumeroCorrelativo());
						paramsDeclaracion.put("NUMGED1",
								solicitudRecepcion.getNumGed());
					}
					if (mapaSolicitudes.get("solicitudPrimeraRecepcionRechazada") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudPrimeraRecepcionRechazada");
						paramsDeclaracion.put("FEC_RECEP_RECHA1",
								solicitudRecepcion.getFechaRecepcion());
						paramsDeclaracion.put("FEC_RECHA1",
								solicitudRecepcion.getFechaRechazo());
						paramsDeclaracion.put("NUMEROCORRELATIVORECHA1",
								solicitudRecepcion.getNumeroCorrelativo());
					}
					if (mapaSolicitudes.get("solicitudSegundaRecepcion") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudSegundaRecepcion");
						paramsDeclaracion.put("FEC_RECEP2",
								solicitudRecepcion.getFechaRecepcion());
						paramsDeclaracion.put("NUMEROCORRELATIVO2",
								solicitudRecepcion.getNumeroCorrelativo());
						paramsDeclaracion.put("NUMGED2",
								solicitudRecepcion.getNumGed());
					}
					if (mapaSolicitudes.get("solicitudSegundaRecepcionRechazada") != null) {
						solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
								.get("solicitudSegundaRecepcionRechazada");
						paramsDeclaracion.put("FEC_RECEP_RECHA2",
								solicitudRecepcion.getFechaRecepcion()); 
						paramsDeclaracion.put("FEC_RECHA2",
								solicitudRecepcion.getFechaRechazo());
						paramsDeclaracion.put("NUMEROCORRELATIVORECHA2",
								solicitudRecepcion.getNumeroCorrelativo()); 
					}  
				} 				 
				
				try{
					WebUtils.setSessionAttribute(request, "tipoDiligencia", ConstantesDataCatalogo.COD_DILIG_REV_PREVIA);	
					
				}catch (Exception e){
					log.error("**** ERROR ****:", e);
				    return showErrorPagM(e.getMessage());
				}				
				
				//PAS20165E220200099-Fin
			      Map<String, Object> tieneVP = new HashMap<String, Object>();
			      String tipoRegimen = (String) paramsDua.get("COD_REGIMEN");
			      DUA adiDeclara = new DUA();
			      tieneVP = null;				
			      String indicadorVFobProvVP = "NO";
			      boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
				  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10	        	 
				      Map<String, Object> paramsValidador = new HashMap<String, Object>(); 
				      paramsValidador.put("NUM_CORREDOC", paramsDeclaracion.get("NUM_CORREDOC").toString());//usado con validarValorProvisional
				      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);					  
					  paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
					  tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
		             if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
		            	 indicadorVFobProvVP = "SI";
		             }
		      	 }
			    adiDeclara = null;
			    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){
			    	//Inicio RIN10 mpoblete refactor
			    	Map<String, Object> paramsFilterDatosAdicionalesDuaByPk = new HashMap<String, Object>(); 
			    	paramsFilterDatosAdicionalesDuaByPk.put("numCorreDoc", paramsDeclaracion.get("NUM_CORREDOC").toString());	
			    	//adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsValidador);
			    	adiDeclara = declaracionService.obtenerDatosAdicionalesDuaByPk(paramsFilterDatosAdicionalesDuaByPk);
			    	//Fin RIN10 mpoblete refactor
			    }				
			    String fecRegulaValProvDDMMYY = "31/12/9999";
			    String fecRegOfiValProvDDMMYY = "31/12/9999";
			    Date fecRegulaValProv = null;
			    Date fecRegOfiValProv = null;
			    if (adiDeclara != null){
			    	if (adiDeclara.getFecRegulaValProv()!=null)
			    	{
						 fecRegulaValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegulaValProv());
						 fecRegulaValProv = adiDeclara.getFecRegulaValProv();
			    	}
			    	if (adiDeclara.getFecRegOfiValProv() != null)
			    	{
						 fecRegOfiValProvDDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(adiDeclara.getFecRegOfiValProv());
						 fecRegOfiValProv = adiDeclara.getFecRegOfiValProv();
			    	}
			    }
			    //P24-PAS20165E220200099 - Inicio
			    String FEC_FINPROVSIONAL_DDMMYY = null;
				if (declaracion.getDua().getFecfinprovsional()!=null)
				{
					FEC_FINPROVSIONAL_DDMMYY = new SimpleDateFormat(FORMAT_ddMMyyyy).format(declaracion.getDua().getFecfinprovsional());
				}    
				paramsDeclaracion.put("FEC_FINPROVSIONAL_DDMMYY", FEC_FINPROVSIONAL_DDMMYY);
				//P24-PAS20165E220200099 - Fin
				paramsDeclaracion.put("FEC_FINPROVSIONAL", declaracion.getDua().getFecfinprovsional());
				paramsDeclaracion.put("FECHA_REGVP_DDMMYY", fecRegulaValProvDDMMYY);
				paramsDeclaracion.put("FECHA_REGOFVP_DDMMYY", fecRegOfiValProvDDMMYY);
				paramsDeclaracion.put("FECHA_REGVP", fecRegulaValProv);
				paramsDeclaracion.put("FECHA_REGOFVP", fecRegOfiValProv);

			     //Inicio RIN10 BUG 22611,22613
			    //if((!org.apache.commons.collections.MapUtils.isEmpty(tieneVP) || tieneVP!=null) && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
			    //amancilla P24 el codigo VP es el mas monse que hi visto no pasa nada se parcha
			    
			    //if( !CollectionUtils.isEmpty(tieneVP) && "SI".equals(indicadorVFobProvVP) && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){	
			    if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
			    
			   	//Fin RIN10 BUG 22611,22613			
			    	paramsDeclaracion.put("IND_VALOR_PROV", "1");
				  }else{
					  paramsDeclaracion.put("IND_VALOR_PROV", "0");
				  }				

			      String codigoPropiedad = (String)paramsDeclaracion.get("COD_PROPIEDAD");
			      String codigoPropiedadDesc =this.catalogoAyudaService.getDescripcionDataCatalogo("63",codigoPropiedad); 
			      String desotraaduana=this.catalogoAyudaService.getDescripcionDataCatalogo("00",declaracion.getDua().getOtraAduana().getCodopadusal().toString()).toString();			      
			      Map<String, Object> mapaSINI = obtenerDatosLevanteDuaSini(paramsDeclaracion);
			      paramsDeclaracion.putAll(mapaEstadoRegu); 
			      paramsDeclaracion.putAll(mapaSINI); 
			      paramsDeclaracion.put("ENDOSE_DESC", codigoPropiedad + " - " + codigoPropiedadDesc);		 	    
			      paramsDeclaracion.put("desotraaduana", desotraaduana);
				
				WebUtils.setSessionAttribute(request, "mapCabDeclara", paramsDeclaracion);
				WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", paramsDeclaracion);
			    WebUtils.setSessionAttribute(request, "declaracionP14", paramsDeclaracion);
			    WebUtils.setSessionAttribute(request, "declaracion", declaracion);
			}catch (ServiceException e) {
				log.error("**** ERROR ****:", e);
				return showErrorJSON(e.getMessage());
			}catch (Exception e){
				log.error("**** ERROR ****:", e);
				return showErrorJSON(e.getMessage());
			}
		    /*Inicio P24-PAS20165E220200099*/
			Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
		    String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(mapCabDeclaraActual, DEFAULT_TIPO_DOC);
		    WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
			if(!modifDilig.isEmpty() && modifDilig.equals("MOD")){//P24 Pase 134 2016
				return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPrevia");//P24 Pase 134 2016
			}else {//P24 Pase 134 2016
		    if(ConstantesDataCatalogo.COD_DUA_ENREVISION.equals(declaracion.getDua().getCodEstdua())){
		    	return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPreviaRevision");
				} else {
					return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPrevia");
		    }
		    }
			/*Fin P24-PAS20165E220200099*/
		}
	}
	
	/**
	 * Actualiza el estado de la declaracion a revision 
	 * @param request
	 * @param response
	 * @return Error en el proceso o vacio
	 * @author gbecerrav
	 */
	public ModelAndView actualizarDeclaracionEnRevision(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		if (log.isDebugEnabled()) {
			log.debug("Inicio - actualizarDeclaracionEnRevision");
		}
		
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);
			
			//Se actualiza la declaracion a estado de revision
			Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
			this.diligenciaPreviaService.actualizarDeclaracionEnRevision(declaracion, usuario);
//			<EHR>P14
			//...............se  esta  reutilizando un jsp, pero la estructura no soporta para este jsp por eso se crea con formato mapa...............
			
		      //PAS20155E220000521
		      if ( this.isImportadorFrecuente(declaracion.getDua().getNumcorredoc()) ) {
		    	  WebUtils.setSessionAttribute(request, "indImportadofrecuente", "Importador Frecuente");
		      } else {
		    	  WebUtils.setSessionAttribute(request, "indImportadofrecuente", " ");  
		      }
		     //PAS20155E220000521   
			
			Map<String, Object> paramsDua = new HashMap<String, Object>();
			paramsDua.put("NUM_DECLARACION", declaracion.getDua().getNumdocumento()); 
			paramsDua.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden()); 
			paramsDua.put("ANN_PRESEN", declaracion.getDua().getAnnpresen()); 
			paramsDua.put("COD_REGIMEN", declaracion.getDua().getCodregimen());
			paramsDua.put("EN_PROCESO", "0");
			Map<String, Object> paramsDeclaracion = declaracionService.obtenerDeclaracion(paramsDua);
			//...............para diligencia Previa se hace referencia  a mapCabDeclaraActual es por ello que se sube a la session
			//...............para el caso de mapCapDeclara lo mismo  ocurre cuando al incio  tiene que cargar por lo que se considera, el metodo que se invoca necesita de ello...
			WebUtils.setSessionAttribute(request, "mapCabDeclara", paramsDeclaracion);
			WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", paramsDeclaracion);
		    WebUtils.setSessionAttribute(request, "declaracionP14", paramsDeclaracion);
//			</EHR>
		    WebUtils.setSessionAttribute(request, "declaracion", declaracion);
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - actualizarDeclaracionEnRevision");
		}
		
		return new ModelAndView("jsonView");
		//return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPreviaRevision");
	}
	
	/**
	 * Carga la p�gina para registrar diligencia previa revisi�n
	 * @param request
	 * @param response
	 * @return Vista de Registro de Diligencia Previa Revisi�n
	 * @author gbecerrav
	 */
	public ModelAndView cargarDiligenciaPreviaRevision(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - cargarDiligenciaPreviaRevision");
		}
		
		try{
			WebUtils.setSessionAttribute(request, "tipoDiligencia", ConstantesDataCatalogo.COD_DILIG_REV_PREVIA);	
			
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
		    return showErrorPagM(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - cargarDiligenciaPreviaRevision");
		}

	    /*Inicio P24-PAS20165E220200099*/
		Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion"); 
		Map<String, Object> paramsDua = new HashMap<String, Object>(); 
		paramsDua.put("NUM_DECLARACION", declaracion.getDua().getNumdocumento());  
		paramsDua.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden());  
		paramsDua.put("ANN_PRESEN", declaracion.getDua().getAnnpresen()); 
		paramsDua.put("COD_REGIMEN", declaracion.getDua().getCodregimen());
		paramsDua.put("EN_PROCESO", "0");
		Map<String, Object> paramsDeclaracion = declaracionService.obtenerDeclaracion(paramsDua);
		//Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
	    String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(paramsDeclaracion, DEFAULT_TIPO_DOC);
	    WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
	    /*Fin P24-PAS20165E220200099*/		
		
		return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPreviaRevision");
	}
	
	/**
	 * Registra comunicacion 
	 * (Diligencia Previa Revision - Seccion 02)
	 * @param request
	 * @param response
	 * @return Error en el proceso o mensaje ok
	 * @author gbecerrav
	 */
	public ModelAndView registrarComunicacion(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		if (log.isDebugEnabled()) {
			log.debug("Inicio - registrarComunicacion");
		}
		
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);
			Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
			
			//Seteamos valor de formulario - Comunicacion
			Comunicacion comunicacion = new Comunicacion(true);
			bind(request, comunicacion);
			
			//Seteamos otros valores - Comunicacion
			comunicacion.getDiligencia().setNumeroCorrelativo(declaracion.getDua().getNumcorredoc());
			comunicacion.getDiligencia().setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV_PREVIA);
			
			//Registramos Comunicacion
			this.diligenciaPreviaService.grabarComunicacion(comunicacion, declaracion, usuario);
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - registrarComunicacion");
		}
		
		return new ModelAndView("jsonView", "rpta", "La comunicaci�n se grab� satisfactoriamente.");
	}
	
	/**
	 * Actualiza el estado de la declaracion a proceso y 
	 * Carga la p�gina para registrar diligencia previa proceso
	 * @param request
	 * @param response
	 * @return Vista de Diligencia Previa en Proceso
	 * @author gbecerrav
	 */
	public ModelAndView actualizarDeclaracionEnProceso(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		if (log.isDebugEnabled()) {
			log.debug("Inicio - actualizarDeclaracionEnProceso");
		}
		
		try{
			this.verificarAutenticacion(request);	
			Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
			this.diligenciaPreviaService.actualizarDeclaracionEnProceso(declaracion);
			WebUtils.setSessionAttribute(request, "declaracion", declaracion);
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - actualizarDeclaracionEnProceso");
		}
		
		return new ModelAndView("jsonView");
		//return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPrevia");
	}
	
	/**
	 * Carga la p�gina para registrar diligencia previa proceso
	 * @param request
	 * @param response
	 * @return Vista de Registro de Diligencia Previa proceso
	 * @author gbecerrav
	 */
	public ModelAndView cargarDiligenciaPreviaProceso(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - cargarDiligenciaPreviaProceso");
		}
		
		try{
			WebUtils.setSessionAttribute(request, "tipoDiligencia", ConstantesDataCatalogo.COD_DILIG_PREVIA);			
			
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
		    return showErrorPagM(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - cargarDiligenciaPreviaProceso");
		}
		String modifDilig = request.getParameter("hdn_modifDilig");//P24
		WebUtils.setSessionAttribute(request, "modifDilig", modifDilig);//P24
		return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPrevia");
	}
	
	/**
	 * Registra Diligencia Previa 
	 * (Diligencia Previa - Seccion 02)
	 * @param request
	 * @param response
	 * @return Error en el proceso o mensaje ok
	 * @author gbecerrav
	 */
	public ModelAndView registrarDiligenciaPrevia(HttpServletRequest request, HttpServletResponse response) throws Exception {	
		Date fechaLlegada = null;//VRD-PAS20165E220200048 
		if (log.isDebugEnabled()) {
			log.debug("Inicio - registrarDiligenciaPrevia");
		}
		
		try{
			UsuarioBean usuario = this.verificarAutenticacion(request);
			
			//Seteamos valor de formulario - Diligencia
			Diligencia diligencia = new Diligencia();
			bind(request, diligencia);
					
			//Seteamos otros valores - Diligencia
			Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
			diligencia.setNumeroCorrelativo(declaracion.getDua().getNumcorredoc());
			diligencia.setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_PREVIA);
			diligencia.setCodigoFuncionario(usuario.getNroRegistro().trim());
			diligencia.setFechaDiligencia(new Date());
			
			//Registramos Diligencia
				this.diligenciaPreviaService.grabarDiligenciaPrevia(diligencia,declaracion); // jreynoso pase 563
			
				//INICIO VRD-PAS20165E220200048 		
				ManifiestoService manifiestoService = this.fabricaDeServicios.getService("manifiesto.manifiestoService");				
	    		Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(
	    				declaracion.getDua().getManifiesto().getCodtipomanif().toString(),
	    				declaracion.getDua().getManifiesto().getCodmodtransp(),
	    				declaracion.getDua().getManifiesto().getCodaduamanif(),
	    				Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().toString()),
	    				declaracion.getDua().getManifiesto().getNummanif(),
	    				false);	    		
	    				              
	    		if(manifiesto!=null){
	    		if(manifiesto.getFechaEfectivaDeLlegada()!=null && !SunatDateUtils.isDefaultDate(manifiesto.getFechaEfectivaDeLlegada())){
	    			fechaLlegada =manifiesto.getFechaEfectivaDeLlegada();
	    		}
	    		}	
	    		//FIN VRD-PAS20165E220200048	
				
				
			//Eliminamos variable session
			WebUtils.setSessionAttribute(request, "declaracion", null);
			
		}catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}catch (Exception e){
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		
		if (log.isDebugEnabled()) {
			log.debug("Inicio - registrarDiligenciaPrevia");
		}
		
		//return new ModelAndView("jsonView", "rpta", "Se ha grabado satisfactoriamente la diligencia previa."); //VRD-PAS20165E220200048
		//return new ModelAndView("jsonView", new HashMap<String, Object>()); //rpta ok?
		//return new ModelAndView("/DiligenciaPrevia/RegDiligenciaPreviaRevision");
		//INICIO VRD-PAS20165E220200048
		 ModelAndView res = new ModelAndView("jsonView", "rpta", "Se ha grabado satisfactoriamente la diligencia previa.");
		   if (fechaLlegada!=null)
			{
			   res.addObject("mensaje", "Mercanc�as se encuentran arribadas, declaraci�n ser� enviada al �nfora de Canal Rojo Anticipado.");	         
			}
		   else 
		   {
			   res.addObject("mensaje", "Mercanc�as no se encuentran arribadas, declaraci�n ser� enviada al �nfora de Canal Rojo Anticipado .");	         
			}
	
		   return res;
		 //FIN VRD-PAS20165E220200048
	}
	
	//P24 INICIO
	
	/**
	   * Grabar modificacion diligencia.
	   *
	   * @param request
	   *          the request
	   * @param response
	   *          the response
	   * @return the model and view
	   * @throws Exception
	   *           the exception
	   */
	  public ModelAndView grabarModificacionDiligencia(HttpServletRequest request, HttpServletResponse response)
	                                                                                            throws Exception
	  {
	    String numCorreDoc = request.getParameter("numCorreDoc") != null ? request.getParameter("numCorreDoc") : " ";
	    String resultado = request.getParameter("resultado") != null ? request.getParameter("resultado") : " ";
	    ModelAndView res = new ModelAndView(this.jsonView);

	    Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
	    paramsDiligencia.put("NUM_CORREDOC", numCorreDoc);
	    paramsDiligencia.put("COD_TIPDILIGENCIA", new String[]
	    { ConstantesDataCatalogo.COD_DILIG_PREVIA.toString() });
	    // en este caso no se necesita pasar el mapa de la declaracion pq obtiene
	    // los datos solo de la diligencia
	    Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(
	                                                                                           paramsDiligencia,
	                                                                                           new HashMap());
	    mapUltimaDiligencia.put("DES_RESULTADO", resultado); 
	    mapUltimaDiligencia.put(
	                            "NUM_CORREDOC_SOL",
	                            Long.parseLong(mapUltimaDiligencia.get("NUM_CORREDOC_SOL").toString()) + 1);

	    try
	    {
	      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	      UserNameHolder.set(bUsuario.getNroRegistro());
	      diligenciaService.grabarModificacionDiligencia(mapUltimaDiligencia);
	      res.addObject("recOK", true);
	    }
	    catch (Exception e)
	    {

	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      res.addObject("beanM", rBean);
	    }

	    return res;
	  }	
	  
	  //P24 FIN
	
	//P24-PAS20165E220200099
	 private boolean isImportadorFrecuente(Long numCorreDoc){
			List<IndicadorDeclaracionDescripcion> listaIndicadorDuaDesc = this.declaracionService.obtenerIndicadoresDuaAll(numCorreDoc);
				  if (listaIndicadorDuaDesc != null) {
						for (IndicadorDeclaracionDescripcion indicadorDuaDesc : listaIndicadorDuaDesc) {
							  if(indicadorDuaDesc.getCodigoIndicador().equals("05")){//es decir cuenta con el indicador 05 Importador Frecuente
								  return true;
							  }
						}
				  }
			return false;
		 }	
	 
	//P24-PAS20165E220200099
	private Map<String, Object> determinarEstadoRegularizacion(Map<String, Object> declaracion){
			// obtiene el mensaje del levante - mensaje regularizacion
			// RIN16
		  	HashMap rspta = new HashMap();
			if(declaracion.get("COD_ESTDUA").toString().equals("08") || declaracion.get("COD_MODALIDAD").toString().equals("00")){  // SI LA DUA ESTA LEGAJADA O LA DUA ES MODALIDAD EXCEPCIONAL NO DEBE TENER MENSAJE DE REGULARIZACION
				rspta.put("MsjRegularizacion", null);
				rspta.put("fecSolicitud", " ");
				rspta.put("horSolicitud", " ");
			} else {			
				
				/*Inicio f2_3014_req_RIN16_Regularizacion - PLMR */
				
				if (org.springframework.util.StringUtils.hasText((String)declaracion.get("COD_ESTREGUL"))) {
					if(declaracion.get("COD_ESTREGUL").toString().equals("07")){
						rspta.put("MsjRegularizacion", null);
						rspta.put("fecSolicitud", " ");
						rspta.put("horSolicitud", " ");
					}
					else{
						if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"01", "02", "03" })){//sin Regularizacion aceptada
							rspta.put("MsjRegularizacion","PENDIENTE DE REGULARIZAR");
							rspta.put("horSolicitud", " ");
							rspta.put("fecSolicitud", " ");
						}					
						else if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"04", "05", "06"})){//con Regularizacion aceptada
							rspta.put("MsjRegularizacion","REGULARIZADO");
							Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
							rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
							rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
						}
					}
				}
				/*Fin f2_3014_req_RIN16_Regularizacion - PLMR */
				else{
				// RIN16	
					String MsjRegularizacion = null;
					HashMap params = new HashMap();
					// se obtiene fecha de solicitud, regularizacion - urgentes
					params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
					params.put("COD_TIPSOL", "11");
					RelacionDocDAO relacionDocDAO = fabricaDeServicios.getService("relaciondocDAO");
					List<Map<String,Object>> relacionSolicitudes = relacionDocDAO.findSolicitudesByDocumento(params);
					Date fecSolicitud = SunatDateUtils.getDefaultDate();
					if(!org.apache.commons.collections.CollectionUtils.isEmpty(relacionSolicitudes)){
						Map<String, Object> solicitud = relacionSolicitudes.get(0);
						fecSolicitud = (Date)(solicitud.get("FEC_SOLICITUD"));
					}
					// se obtiene fecha de recepcion de documentos, regularizacion - urgentes
					Date fecRecepcionDoc = (Date) declaracion.get("FEC_REREG");
					// se obtiene fecha de regularizacion de la dua - anticipados
					Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
		
					//Se evalua si tiene expediente 1606 para identificar el tipo de mensaje de regularizacion a mostrar
					Map<String,Object> paramsExpedi = new HashMap<String,Object>();
					paramsExpedi.put("PROCEDIM", 		"1606");
					paramsExpedi.put("COD_ADUANA",  	declaracion.get("COD_ADUANA"));
					paramsExpedi.put("COD_REGIMEN", 	declaracion.get("COD_REGIMEN"));
					paramsExpedi.put("ANN_PRESEN",  	declaracion.get("ANN_PRESEN").toString());
					paramsExpedi.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));
					
				if (declaracion.get("COD_MODALIDAD").equals("01")) { // 01 urgente
					// Modificado Daniel Zavaleta C. 10/10/2012 INI
					if(SunatDateUtils.isDefaultDate(fecSolicitud) || SunatDateUtils.isDefaultDate(fecRecepcionDoc) || SunatDateUtils.isDefaultDate(fecRegulariza)){
					//   Fin
						MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
					}else{
						MsjRegularizacion = "REGULARIZADO";
						fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
						rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
						rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
					}
				} else if (declaracion.get("COD_MODALIDAD").equals("10")) { // 10 anticipado
					Map<String, Object> paramIndLev = new HashMap<String, Object>();
					paramIndLev.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
					paramIndLev.put("cod_indicador", "02"); // 302 datacatalogo
					paramIndLev.put("ind_activo", "1");
					IndicadorDUADAO indicadorDuaDAO = fabricaDeServicios.getService("indicadorDUADAO");
					Map<String, Object> mapIndLev = indicadorDuaDAO.findByDocumentoAndValor(paramIndLev);
					if (mapIndLev != null && mapIndLev.size() > 0) { // tiene indicador 02
						if(SunatDateUtils.isDefaultDate(fecRegulariza)){
							MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
						}else{
							MsjRegularizacion = "REGULARIZADO";
							fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
							rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
							rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
						}
					}
				}
				rspta.put("MsjRegularizacion", MsjRegularizacion);
				}
			}// RIN16
			return rspta;
	  }	 
	
	//PAS20165E220200099
	  public Map<String, Object> obtenerDatosLevanteDuaSini(Map<String, Object> declaracionDua) throws ServiceException {
			Map<String, Object> rspta = new HashMap<String, Object>();
	          String aduana=declaracionDua.get("COD_ADUAMANIFIESTO").toString();
	          String codRegimen=declaracionDua.get("COD_REGIMEN").toString();
				if(aduana.equals("118")){
					String[] regimenTMP = new String[] {"10","20" ,"21","70"};
					if (Arrays.asList(regimenTMP).contains(codRegimen)) {
	              Map<String, Object> parametro = new HashMap<String, Object>();
	              Map<String, Object> parametros = new HashMap<String, Object>();
	              List<Map<String,Object>> listAuxiliar = new ArrayList<Map<String,Object>> ();
	              
	              parametros.put("cod_regimen", declaracionDua.get("COD_REGIMEN").toString());
	              parametros.put("codigoAduana", declaracionDua.get("COD_ADUAMANIFIESTO").toString());
	              parametros.put("anioDocumento", declaracionDua.get("ANN_PRESEN").toString());
	              parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(),6, " "));
	              parametros.put("codigoViaTransporte", declaracionDua.get("COD_VIATRANS").toString());
	              parametros.put("numdua", declaracionDua.get("NUM_DECLARACION").toString());//pruiz
	              parametros.put("numdua", StringUtils.leftPad(declaracionDua.get("NUM_DECLARACION").toString(),6,"0"));
	              
	              
	              SiniConsultaService siniConsultaService =fabricaDeServicios.getService("sigad.sini.SiniConsultaService");
	              List<Map<String,Object>> listSini= siniConsultaService.evaluarContenedorSINIxDAM(parametros);
	              String etiquetaSini=null;
	           
	              if (!CollectionUtils.isEmpty(listSini)){
	                 if(listSini.size()>0){
	              	
	                  etiquetaSini=	String.valueOf(listSini.get(0).get("DES_ESTADO"));
	              	rspta.put("COD_ESTADO_SINI", listSini.get(0).get("COD_ESTADO"));
	               
		                }else{
		                	//se obtiene los datos de la dua
		                    
		                    parametro.put("numeroCorrelativoDua", declaracionDua.get("NUM_CORREDOC").toString());
		                    parametros.put("anioManifiesto", declaracionDua.get("ANN_MANIFIESTO").toString());
		                    parametros.put("codigoTipoManifiesto", declaracionDua.get("COD_TIPMANIFIESTO").toString());
		                    EntradaSalidaService entradaSalidaService =  fabricaDeServicios.getService("declaracion.entradasalida.EntradaSalidaService");
		                    List<Manifiesto> lstManifiesto = entradaSalidaService.obtenerManifiesto(parametros);
		                    Long numeroCorrelativoManif = lstManifiesto.get(0).getNumeroCorrelativo();                                                                
		                    parametro.put("numeroCorrelativoManif", numeroCorrelativoManif);
		                    //Obtenemos Contenedores Declarados
		                    listAuxiliar=entradaSalidaService.obtenerContenedoresDeclarados(parametro);
		                    if (!listAuxiliar.isEmpty() && listAuxiliar!=null){
		                    	List<String> listaEquipaminetos = new ArrayList<String>();
		 	                    for(Map<String, Object> mapCon :listAuxiliar){
		 	                    	listaEquipaminetos.add((String)mapCon.get("numeroEquipamiento"));
		 	    				}
		 	                   
		 	                   parametros.put("listContenedores", listaEquipaminetos);
		 	            
		 	                    List<Map<String,Object>> listSiniManif= siniConsultaService.evaluarContenedorSINISinDestinar(parametros);
		 	                    if(!listSiniManif.isEmpty()){
		 	                    etiquetaSini=	String.valueOf(listSiniManif.get(0).get("DES_ESTADO"));
		 	                	rspta.put("COD_ESTADO_SINI", listSiniManif.get(0).get("COD_ESTADO"));
		 	                    }
		 	                   
		 	                }
		                 
		                  }
					}
		                   
	             	   rspta.put("DES_ESTADO_SINI", etiquetaSini);

	                }
	             }

			
			return rspta;
		}	
	public ModelAndView cargarFormularioImpresion(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		try {

			SolicitudRecepcion solicitudBusqueda = new SolicitudRecepcion();
			solicitudBusqueda.setNumeroCorrelativo(Long.parseLong(request.getParameter("numeroCorrelativoSolicitud")));
			RecepcionDocumentosService recepcionDocumentosService = fabricaDeServicios.getService("declaracion.service.RecepcionDocumentosService1");
			Map<String, Object> paramsRec = recepcionDocumentosService.obtenerDatosRecepcion(solicitudBusqueda);
			SolicitudRecepcion solicitud = (SolicitudRecepcion) paramsRec.get("solicitud");
			String recepcion = paramsRec.get("recepcion").toString();
			// cadenaDocReg

			paramsRec
					.put("tipoRecepcion",
							recepcion
									.equals(ConstantesDeclaracion.PRIMERA_RECEPCION) ? "1ra. Recepcion"
									: "2da. Recepcion");
			paramsRec.put("numeroCorrelativoSol",
					solicitud.getNumeroCorrelativo());
			paramsRec.put("numeroCorrelativoDua", solicitud.getDeclaracion()
					.getDua().getNumcorredoc());
			paramsRec.put("tipoGeg", solicitud.getTipoGed().getCodDatacat());
			paramsRec.put("des_aduana", null);

			recepcionDocumentosService.obtenerDatosDeclaracionparaVista(
					paramsRec, solicitud.getDeclaracion());
			ModelAndView view = new ModelAndView(
					"frmImpresionDocumentosRecepcionados");

			WebUtils.setSessionAttribute(request, "params", paramsRec);
			return view;
		} catch (Exception e) {
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol(" Error al Registrar la Pagina");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);
		}
	}
	
	  private boolean duaTieneIndicadorDUAValorProvActivo(Declaracion declaracion){
		  DatoIndicadores indicadorDUA = new DatoIndicadores();
	      //(RIN10 mpoblete BUG 21916)indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(declaracion.get("NUM_CORREDOC").toString(), pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
		  indicadorDUA =  obtenerIndicadorDUAVP(declaracion.getDua().getNumcorredoc().toString()); 
	      //Inicio RIN10 mpoblete BUG 21738
	      //return (indicadorDUA!=null && "1".equals(indicadorDUA.getIndicadorActivo()));	  
	      return (indicadorDUA!=null);
	      //Fin RIN10 mpoblete BUG 21738
	  }
	  
	  private DatoIndicadores obtenerIndicadorDUAVP(String numCorredoc){
		  DatoIndicadores indicadorDUA = new DatoIndicadores();
		  indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(numCorredoc, pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
		  return indicadorDUA;
	  }	  
	
	/**
	 * @return the diligenciaPreviaService
	 */
	public DiligenciaPreviaService getDiligenciaPreviaService() {
		return diligenciaPreviaService;
	}

	/**
	 * @param diligenciaPreviaService the diligenciaPreviaService to set
	 */
	public void setDiligenciaPreviaService(DiligenciaPreviaService diligenciaPreviaService) {
		this.diligenciaPreviaService = diligenciaPreviaService;
	}
	//P24
	public void setValidaDiligenciaService(ValidaDiligenciaService validaDiligenciaService) {
		this.validaDiligenciaService = validaDiligenciaService;
	}	

	/**
	 * @return the errors
	 */
	public BindingResult getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(BindingResult errors) {
		this.errors = errors;
	}
	/**
	*	Para P14
	*/
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}
	
	//INICIO VRD-PAS20165E220200048
		/**
		   * Sets the fabrica de servicios.
		   *
		   * @param fabricaDeServicios
		   *          the new fabrica de servicios
		   */
		  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
		  {
		    this.fabricaDeServicios = fabricaDeServicios;
		  }
	
		  public FabricaDeServicios getFabricaDeServicios()
			{
				return this.fabricaDeServicios;
			}		  
		//FIN VRD-PAS20165E220200048
			/**
			 * Sets the rectificacion service.
			 * 
			 * @param rectificacionService
			 *            the new rectificacion service
			 */
			public void setRectificacionService(
					RectificacionService rectificacionService) {
				this.rectificacionService = rectificacionService;
			}

}
