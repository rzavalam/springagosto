package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.text.DateFormat;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.sojo.interchange.json.JsonSerializer;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;
import pe.gob.sunat.administracion2.tramite.model.DocumentoSustento;
import pe.gob.sunat.administracion2.tramite.model.DocumentoSustentoFactory;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.descrminima.web.controller.BytesObjectUtils;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.StringUtil;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDeclaranImpl;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaCulminacionPecoService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteComparadorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ValidaDiligenciaService;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.*;
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO; //P24 pase99
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;//P34
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;//P46-PAS20155E410000032
import pe.gob.sunat.prevcontrabando2.ace.util.ConstantesACE;
import pe.gob.sunat.prevcontrabando2.ace.util.Util;
import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;//P46-PAS20155E410000032
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;//P46-PAS20155E410000032
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidacionOEAService;

//import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ResolucionMulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;

/**
 * <p>
 * Titulo: Controlador Web para proceso de Rectificacion de Oficio
 * </p>
 * <p>
 * Descripcion: Controlador que administra las funcionalidades de la
 * Rectificacion de Oficio
 * </p>
 * <p>
 * Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.web.controller.
 * RectificacionOficioController.java
 * </p>
 *
 * @author  amancilla
 * @version 1.0
 * @since   Aug 27, 2012
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class DiligenciaCulminacionPecoController extends AbstractDespachoController {
    private final static String			PAGINA_INICIAL				= "/peco/BusqDeclaracionPeco";
    private final static String			PAGINA_RECUPERACION_DATOS_TMP	= "/peco/RecuperarDatosTMP";
    private final static String			PAGINA_PRINCIPAL_EN_REVISION			= "/peco/RevisionDiligCulminacionPeco";
    private final static String     PAGINA_PRINCIPAL_EN_PROCESO      = "/peco/RegDiligCulminacionPeco";
    private final static String			PAGINA_PRINCIPAL_DETALLE	= "/peco/RegSeriePeco";
    private static final String DEFAULT_TIPO_DOC = "01"; //P24 pase99
    @Autowired
    @Qualifier("diligencia.rectificacionOficio.rectificacionOficioService")
    private RectificacionOficioService	rectificacionOficioService;
    @Autowired
    @Qualifier("diligencia.culminacionPeco.diligenciaCulminacionPecoService")
    private DiligenciaCulminacionPecoService	diligenciaCulminacionPecoService;
    @Autowired
    @Qualifier("diligencia.ingreso.validaDiligenciaService")
    private ValidaDiligenciaService		validaDiligenciaService;
    @Autowired
    @Qualifier("diligencia.ingreso.declaracionService")
    private DeclaracionService			declaracionService;
    @Autowired
    @Qualifier("diligencia.ingreso.soporteService")
    private SoporteService				soporteService;
    @Autowired
    @Qualifier("diligencia.ingreso.serieService")
    private SerieService  serieService;
    @Autowired
    @Qualifier("Ayuda.operadorAyudaService")
    private OperadorAyudaService		operadorAyudaService;
    @Autowired
    @Qualifier("diligencia.ingreso.formatoValorService")
    private FormatoValorService			formatoValorService;
    @Autowired
    @Qualifier("Ayuda.ayudaServiceDeclaran")
    private AyudaServiceDeclaranImpl	ayudaServiceDeclaranImpl;
    @Autowired
    @Qualifier("diligencia.soporteComparadorService")
    private SoporteComparadorService    soporteComparadorService;
    @Autowired
    @Qualifier("tramite.ResolucionService")
    private ResolucionService    resolucionService;
    //Ini P46-PAS20155E410000032
    @Autowired
    @Qualifier("diligencia.ingreso.liquidaDeclaracionService")
    private LiquidaDeclaracionService liquidaDeclaracionService;

    @Autowired
    @Qualifier("diligencia.ingreso.deudaDeclaracionService")
    private DeudaDeclaracionService deudaDeclaracionService;

    @Autowired
    @Qualifier("validacion.ingreso.IndicadorDuaService")
    private IndicadorDuaService indicadorDuaService;

    @Autowired
    @Qualifier("diligencia.ingreso.fabricaDeServiciosData")
    private FabricaDeServicios fabricaDeServicios;//P46-PAS20155E410000032-jlunah
    //Fin P46-PAS20155E410000032


    @Autowired
    @Qualifier("ValidacionOEAService")
    private ValidacionOEAService validacionOEAService;//

    /**
     * Pre-Condicion : Especialista tenga acceso a opcion.
     * Proceso       : Metodo carga la pantalla de busqueda de la declaracion
     * Post-Condicion:
     * Invocaciones  : Inicio del Flujo Basico del Caso de Uso
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return ModelAndView PAGINA_INICIAL o PagM
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView cargarBusqDeclaracion(HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if(userSession!=null){
                userSession.setNroRegistro(userSession.getNroRegistro().trim());
                WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
            }

            if (userSession == null)
            {
                return new ModelAndView("PagM", "message", "Usuario no logueado");
            }
            Utilidades.inicializarMapasSesion(request);
            UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
            setVariableSesion(request, EnumVariablesSession.SALIR_RECTI_OFICIO, "NO");
            // invocacion del controller por metodo GET para ser invocado desde otros
            // modulos
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana")
                    : this.obtenerAduana(request);
            String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen")
                    : String.valueOf(Calendar.getInstance()
                    .get(Calendar.YEAR));
            String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen")
                    : "";
            String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest.getParameter("numDeclaracion")
                    : "";
            Map<String, String> params = new HashMap<String, String>();
            params.put("COD_ADUANA", codAduana);
            params.put("ANN_PRESEN", annPresen);
            params.put("COD_REGIMEN", codRegimen);
            params.put("NUM_DECLARACION", numDeclaracion);
            params.put("COD_DOCUMENTOADUANERO", COD_DOCUMENTO_ADUANERO);
            params.put("numPase", NUM_PASE);
            params.put("TITULO", "DILIGENCIA DE CULMINACION DE PECO AMAZONIA");
            //params.put("TITULO", getTituloModuloEnJSP(MODULO_RECTIFICACION_OFICIO, new HashMap()));
            //amancilla PAS20165E220200099

            List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
            for (Map<String, String> map : lstAduana)
            {
                map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
                if (((String) map.get("cod_datacat")).equals(codAduana)){
                    params.put("des_aduana", (map.get("cod_datacat").toString()).concat("-").concat(map.get("des_corta").toString()));
                    break;
                }
            }
            //fin amancilla PAS20165E220200099
            List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", params.get("COD_ADUANA").toString());
            params.put("aduanaDependencyList", SojoUtil.toJson(aduanaDependencyList));
            return new ModelAndView(PAGINA_INICIAL, "data", params);
        }
        catch (ServiceException e)
        {
            return showErrorPagM(e.getMessage());
        }
        catch (Exception e)
        {
            log.error("**** ERROR ****:", e);
            return showErrorPagM("");
        }
    }
    /**
     * Pre-Condicion : Ejecutar metodo cargarBusqDeclaracion
     * Proceso       : Validar la declaracion cumple con los requisitos para la rectificacion de oficio.
     * Post-Condicion: envia JSON lstAdvertencias
     * Invocaciones  : btnBuscar PAGINA_INICIAL
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] jsonView o PagM.jsp
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView procesarDuaParaDiligenciaCulminacionPeco(HttpServletRequest request, HttpServletResponse response){
        BusquedaDua paramsBusqDua = new BusquedaDua();
        try {
            bindToCommand(request, paramsBusqDua);
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("COD_ADUANA", paramsBusqDua.getCodAduana());
            params.put("ANN_PRESEN", paramsBusqDua.getAnnoPresenta());
            params.put("COD_REGIMEN", paramsBusqDua.getCodRegimen());
            params.put("NUM_DECLARACION", paramsBusqDua.getNumDeclaracion());
            params.put("tipoDiligencia", MODULO_CULMINACION_PECO);
            params.put("numeroDeclaracionTitulo", "27");
            //INICIO EJHM -P34
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if (userSession == null)
            {
                return new ModelAndView("PagM", "message", "Usuario no logueado");
            }
            UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
            //amancilla P34 no es necesario paramsBusqDua.setUsuarioSesion(userSession.getNroRegistro());
            //FIN P34
          /*INICIO-P34 FSW AFMA*/
            paramsBusqDua.setRegistroUsuarioLogeado(userSession.getNroRegistro());
          /*FIN-P34 FSW AFMA*/
            // validacion de la DUA y obtienen los datos de la declaracion
            ObjectResponseUtil responseUtil = diligenciaCulminacionPecoService.validarDeclaParaCulminacionPeco(paramsBusqDua);
            if(responseUtil.poseeError()){
                //muestra las validaciones de negocio
                List<MensajeBean> listValidaciones = responseUtil.getMensajes();
                String msgValidacion =  listValidaciones.get(0).getMensajeerror();
                log.info(this.toString().concat("metodo:validarDeclaParaDiligenciaCulminacionPeco()"+
                        " dua:"+params+" validacion:").concat(msgValidacion));
                return showAvisoJSON(msgValidacion,"Por favor verifique");
            }
            //muestra las advertencias de negocio
            Map<String, Object> mapDatos   = (Map<String, Object>)responseUtil.getDatos();
            Map<String, Object> declaracion = (Map<String, Object>)mapDatos.get("mapDeclara");

            //PAS20171U220200005 - mtorralba 20170822 - Inicio
            List<Map<String, Object>> lstAdvertencias = new ArrayList<Map<String, Object>>();
            List<Map<String, Object>> lstAdvertMercanciaVigente = new ArrayList<Map<String, Object>>();

            String codcanal = declaracion.get("COD_CANAL")==null ? "" : declaracion.get("COD_CANAL").toString();
            if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_VERDE)) {
                //Se evalua si tiene expediente 3092. Para determinar si un expediente est� concluido como PROCEDENTE, este debe tener tipo de conclusi�n 5.
                Map<String,Object> paramsExpedi = new HashMap<String,Object>();
                paramsExpedi.put("PROCEDIM", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO);
                paramsExpedi.put("COD_ADUANA", paramsBusqDua.getCodAduana());
                paramsExpedi.put("COD_REGIMEN", paramsBusqDua.getCodRegimen());
                paramsExpedi.put("ANN_PRESEN",  paramsBusqDua.getAnnoPresenta());
                paramsExpedi.put("NUM_DECLARACION", paramsBusqDua.getNumDeclaracion());
                paramsExpedi.put("TIPO_CONC", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO_PROCEDENTE_Y_CONCLUIDO);

                ExpedienteService expedienteService = (ExpedienteService)fabricaDeServicios.getService("tramite.ExpedienteService");
                List<Map<String,Object>> expedis = expedienteService.findByDocumentoOrigen(paramsExpedi);
                if(!CollectionUtils.isEmpty(expedis)){
                    Map mapFila = new HashMap<String, Object>();
                    mapFila.put("DOCUMENTO", "�Desea registrar Mercanc�a Vigente a la presente Declaraci�n?");
                    lstAdvertMercanciaVigente.add(mapFila);
                }
            } //Final codCanal VRTYR

            if( lstAdvertMercanciaVigente.isEmpty() ) {  //Si no existe advertencia por Mercancia Vigente

                lstAdvertencias = obtenerListadoAdvertencia(declaracion);
                // rin08 inicio
                Map<String, Object> PkDocu = new HashMap();

                String [] diligenciasEvaluadas = {Constantes.DILIG_ADUANA_DESTINO,Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO,Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO};//vienen ordenadas por fecha de registro

                PkDocu.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
                PkDocu.put("LISTA_TIPDILIGENCIA", diligenciasEvaluadas);
                List <Map<String, Object>>listadoDiligenciaDespacho = diligenciaService.selectDiligencia(PkDocu);

                if(listadoDiligenciaDespacho != null)

                    if (listadoDiligenciaDespacho.size() > 0) { //Entonces evaluo
                        int i = 0;
                        for(Map<String,Object> diligencia : listadoDiligenciaDespacho){

                            if(diligencia.get("COD_TIPDILIGENCIA").equals(Constantes.DILIG_ADUANA_DESTINO)){//cuando el primer valor es una diligencia en aduana de destino
                                boolean tieneDiligenciaDestino = true;
                                if(tieneDiligenciaDestino){ // si no le precede una rectificacion entonces envia mensaje
                                    Map mapFila = new HashMap<String, Object>();
                                    //mapFila.put("DOCUMENTO", "La declaracin cuenta con diligencia en aduana de Destino pendiente de aprobacin");
                                    mapFila.put("DOCUMENTO", "La declaracin PECO y/o AMAZONIA cuenta con diligencia en aduana de destino. Si continua con la rectificacin de oficio confirmara esa diligencia y efectuar las reliquidaciones correspondientes");
                                    mapFila.put("NRODOCUMENTO", paramsBusqDua.getCodAduana()+ "-"+ paramsBusqDua.getAnnoPresenta()+"-"+paramsBusqDua.getCodRegimen()+"-"+  paramsBusqDua.getNumDeclaracion());
                                    mapFila.put("FECHA", "");
                                    //comentado csantillan PAS20181U220200069 evitar el mensaje de advertencia declaracin PECO y/o AMAZONIA
//                                    lstAdvertencias.add(mapFila);
                                    break;
                                }
                            }

                            if(diligencia.get("COD_TIPDILIGENCIA").equals(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO)){//cuando el primer valor es una diligencia de rectificacion de oficio
                                break;
                            }//pase PAS20181U220200069
                            if(diligencia.get("COD_TIPDILIGENCIA").equals(Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO)){//cuando el primer valor es una diligencia de CULMINACION DE PECO
                                break;
                            }
                            if(diligencia.get("COD_TIPDILIGENCIA").equals(Constantes.COD_TIPO_DILIGENCIA_ADUANA_DESTINO)){//cuando el primer valor es una diligencia de CULMINACION DE PECO
                                break;
                            }

                            i++;
                        }//Final FOR
                    }
            }


            if (lstAdvertMercanciaVigente.isEmpty()) {

                String seriesNoRatificadas = diligenciaCulminacionPecoService.validarBoletinQuimicoNoRatificado(declaracion);
                if (!seriesNoRatificadas.trim().isEmpty()){
                    Map mapFila = new HashMap<String, Object>();
                    mapFila.put("DOCUMENTO", "Declaraci�n con Bolet�n Qu�mico No Ratificado para las series[".concat(seriesNoRatificadas).concat("]"));
                    mapFila.put("NRODOCUMENTO", paramsBusqDua.getCodAduana()+ "-"+ paramsBusqDua.getAnnoPresenta()+"-"+paramsBusqDua.getCodRegimen()+"-"+  paramsBusqDua.getNumDeclaracion());
                    mapFila.put("FECHA", "");
                    lstAdvertencias.add(mapFila);
                }
            }

            //Final definivo

         /*Adicionamos la advertencia de invitado oea:
          * PAS20181U220200022
          * */
            List<Map<String, String>> listErrorGarNominal = null;
            Long numcorredoc = new Long(declaracion.get("NUM_CORREDOC").toString());
            String codregimen = declaracion.get("COD_REGIMEN").toString();
            String numCtacteEval = declaracion.get("NUM_CTACTE")!=null?declaracion.get("NUM_CTACTE").toString():"";
            String numRucBeneficiarioEval = declaracion.get("NUM_DOCIDENT_PIM").toString();
            Date fechaReferencia =  Utilidades.toDate(declaracion.get("FEC_DECLARACION").toString());

            listErrorGarNominal = validacionOEAService.validarGarNominalIncumplimientoPorParametros(fechaReferencia, false, numRucBeneficiarioEval, numCtacteEval,
                    "1018" ,numcorredoc, codregimen);

            if(!CollectionUtils.isEmpty(listErrorGarNominal) && listErrorGarNominal.size()>0){
                Map mapFila = new HashMap<String, Object>();
                mapFila.put("DOCUMENTO",listErrorGarNominal.get(0).get("desError").toString());
                mapFila.put("NRODOCUMENTO","CTA CTE: "+numCtacteEval);
                mapFila.put("FECHA",fechaReferencia.toString());
                lstAdvertencias.add(mapFila);
            }



            // rin08 fin.
            // la declaracion se envia a session siempre tendra el titulo en el JSP
            declaracion.put("tituloDiligencia", getTituloModuloEnJSP(MODULO_CULMINACION_PECO, params));
            Map<String, Object> declaracionActual = new HashMap<String, Object>();
            declaracionActual = Utilidades.copiarMapa(declaracion);
            limpiarVariablesSesion(request);
            String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracion, DEFAULT_TIPO_DOC);
            WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
            params.put("numeroDeclaracionTitulo", declaracion.get("numeroDeclaracionTitulo"));
            String tituloPeco= "DILIGENCIA DE CULMINACION DE PECO AMAZONIA - " + declaracion.get("numeroDeclaracionTitulo");
            params.put("tituloDiligencia", tituloPeco);
            declaracion.put("tituloDiligencia", tituloPeco);
            declaracionActual.put("tituloDiligencia", tituloPeco);
            // INICIO DE ENVIO DE VARIABLES EN SESSION
            String numCorreDocDua = declaracionActual.get("NUM_CORREDOC").toString();
            paramsBusqDua.setNumCorreDoc(new Long(numCorreDocDua));
            setVariableSesion(request, EnumVariablesSession.PARAMS_BUSQUEDA_DUA, paramsBusqDua);
            setVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA, MODULO_CULMINACION_PECO);
            setVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW, declaracionActual);
            setVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_OLD, declaracion);
            //se carga las series para que despues no se tenga problemas en la comparaciones
            //despacho controller usa la serie cargada de iniciodeBD y esta solo carga la serie y no los otros
            //datos que son importantes evaluar si tambien esto aplica para otros mapas
            if (CollectionUtils.isEmpty((List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual")))
            {
                cargarSeriesSesion(request);
            }
          /*Inicio P24-PAS20165E220200099*/

            //*Fin P24-PARTE II*/
           /* boolean tieneAdvertenciaMercDisp = false;
            String msgAdvertenciaMercDisp = rectificacionOficioService.validarAdvertenciaOficio(paramsBusqDua);
            if(!SunatStringUtils.isEmptyTrim(msgAdvertenciaMercDisp)){
                tieneAdvertenciaMercDisp = true;
            }*/
            //amancilla PAS20155E220200035  -- PARA PECO AMAZONIA SE DEBERIA CAMBIAR A  diligenciaCulminacionPecoService.
            //boolean estadoRectiOficio = rectificacionOficioService.tieneRectificacionOficioEnProceso(numCorreDocDua);
            boolean estadoDiligenciaCulminacionPecoAmazonia = diligenciaCulminacionPecoService.tieneCulminacionPecoAmazoniaEnProceso(numCorreDocDua);
            ModelAndView res = new ModelAndView(jsonView);
            //res.addObject("tieneAdvertenciaMercDisp",tieneAdvertenciaMercDisp);
            // res.addObject("msgAdvertenciaMercDisp",msgAdvertenciaMercDisp);
            res.addObject("lstAdvertencias",lstAdvertencias);
            res.addObject("estadoPecoAmazonia",estadoDiligenciaCulminacionPecoAmazonia);
            //PAS20171U220200005 - mtorralba 20170818 - Solo a�ade Advertencia de Mercancias Vigentes si cumple las condiciones
            if( !lstAdvertMercanciaVigente.isEmpty()) res.addObject("lstAdvertMercanciaVigente",lstAdvertMercanciaVigente);

            //PAS20155E220200035 return new ModelAndView(jsonView, "lstAdvertencias", lstAdvertencias);
            return res;
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorJSON(e.getMessage());
        }
    }
    /**
     * Obtener listado advertencia.
     *
     * @param declaracion the declaracion
     * @return list
     */
    private List<Map<String, Object>> obtenerListadoAdvertencia(Map<String, Object> declaracion){
        Map<String, Object> mapPkManifiesto = new HashMap<String, Object>();
        mapPkManifiesto.put("COD_ADUAMANIFIESTO", declaracion.get("COD_ADUAMANIFIESTO").toString());
        mapPkManifiesto.put("ANN_MANIFIESTO", declaracion.get("ANN_MANIFIESTO").toString());
        mapPkManifiesto.put("NUM_MANIFIESTO", declaracion.get("NUM_MANIFIESTO").toString());
        mapPkManifiesto.put("COD_VIATRANS", declaracion.get("COD_VIATRANS").toString());
        Map<String, Object> mapPkDua = new HashMap<String, Object>();
        mapPkDua.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
        mapPkDua.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
        mapPkDua.put("ANN_PRESEN", declaracion.get("ANN_PRESEN"));
        mapPkDua.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));
        String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();
        Map<String, Object> mapAdvertencias = soporteService.getAllActasAndExpedientes(numCorreDoc,
                mapPkManifiesto,mapPkDua);
        List<Map<String, Object>> lstAdvertencias = formatearDataAdvertenciasForJSP(mapAdvertencias);
        return lstAdvertencias;
    }
    public ModelAndView revertirEstadoEnProceso(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
        String numCorreDoc = declaracionActual.get("NUM_CORREDOC") != null ? declaracionActual.get("NUM_CORREDOC").toString() : "";
        if (!SunatStringUtils.isEmpty(numCorreDoc)) {
            //quitamos el indicador de en proceso
            declaracionService.updateIndicadorDua(numCorreDoc, Constantes.INDICADOR_RECTIFICACION_OFICIO_EN_PROCESO, Constantes.IND_DUA_P_ESP, Constantes.INDICADOR_DUA_INACTIVO);
        }
        return cargarBusqDeclaracion(request, response);
    }

    //Ini P46-PAS20155E410000032
    /**
     * Metodo que permite determinar si se debe consultar al usuario si
     * se desea regularizar la donacion despues del levante
     *
     * @param declaracionActual
     * @return
     */
    public ModelAndView consultarRegularizarDonacion(HttpServletRequest request, HttpServletResponse response) {
        try {
            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);

            Declaracion declaracion = new Declaracion();
            declaracion.setDua(new DUA());
            declaracion.getDua().setNumcorredoc(SunatNumberUtils.toLong(mapCabDeclaraActual.get("NUM_CORREDOC")));

            boolean realizarConsulta = false;
            if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(mapCabDeclaraActual.get("COD_REGIMEN")) //declaracion de regimen 10
                    && ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION.equals(mapCabDeclaraActual.get("COD_TIPTRATMERC")) //es una declaracion de donacion
                    && !SunatDateUtils.isDefaultDate((Date)mapCabDeclaraActual.get("FEC_AUTLEVANTE")) //despues del levante
                    && liquidaDeclaracionService.declaracionTieneIndicadorImpugnacionDonacion(mapCabDeclaraActual) //tiene indicador de impugnacion de donacion
                    && deudaDeclaracionService.estaImpugnadaDeudaPorDonacion(declaracion)) { //tiene tipo de cancelacion 73
                realizarConsulta = true;
            }
            ModelAndView res = new ModelAndView(jsonView);
            res.addObject("consultarRegularizarDonacion", realizarConsulta);
            return res;
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorPagM(e.getMessage());
        }
    }
    /**
     * Metodo que permite eliminar el indicador de impugnacion de donacion
     * para pode regularizar la donacion
     *
     * @param request
     * @param response
     * @return
     */
    public ModelAndView eliminarIndicadorImpugnacionDonacion(HttpServletRequest request, HttpServletResponse response) {
        try {
            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);


            List<String> lIndImpugDonac = new ArrayList<String>();
            lIndImpugDonac.add(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
            lIndImpugDonac.add(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL);

            List<Map<String, Object>> lIndicadorDua = indicadorDuaService.obtenerListadoIndicadoresEnSesion(mapCabDeclaraActual);

            for(Map<String,Object> indicadorDua : lIndicadorDua) {
                if(lIndImpugDonac.contains(SunatStringUtils.trim((String)indicadorDua.get("COD_INDICADOR")))
                        && !"0".equals(SunatStringUtils.trim((String)indicadorDua.get("IND_ACTIVO")))) {
                    indicadorDua.put("IND_ACTIVO", "0");
                }
            }

            if(lIndImpugDonac.contains(mapCabDeclaraActual.get("COD_INDICADOR_DONACION"))) {
                mapCabDeclaraActual.put("COD_INDICADOR_DONACION", "00");
            }

            //registrarCodLibeDonacion: true - indica que el usuario esta obligado a
            //registrar un codigo liberatorio de donacion (debe regularizar la donacion)
            mapCabDeclaraActual.put("registrarCodLibeDonacion", true);

            return new ModelAndView(jsonView);
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorPagM(e.getMessage());
        }
    }
    //Fin P46-PAS20155E410000032
    /**
     * Pre-Condicion 	: procesarDuaParaRectificacionOficio()
     * Metodo        	: carga los datos necesarios para iniciar la rectificacion de oficio.
     * Post-Condicion	: Carga la pantalla PAGINA_PRINCIPAL
     * Invocaciones  	: btnIngresar en PAGINA_INICIAL
     * Flujo Alternativo: Si contiene datos temporales muestra la pantalla
     *                    PAGINA_RECUPERACION_DILIGENCIA_TMP
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] PAGINA_PRINCIPAL o RECUPERACION_DILIGENCIA_TMP
     * @autor: amancillaa
     */
    public ModelAndView ingresarDiligenciaCulminacionPeco(HttpServletRequest request, HttpServletResponse response)
    {
        UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        if (userSession == null)
        {
            return new ModelAndView("PagM", "message", "Usuario no logueado");
        }
        UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
        ServletWebRequest webRequest = new ServletWebRequest(request);
        ModelAndView res = new ModelAndView();
        try
        {
            String salirDelSistema = (String) getVariableSesion(request, EnumVariablesSession.SALIR_RECTI_OFICIO);
            if(salirDelSistema!=null && "SI".equals(salirDelSistema))
            {
            /*INICIO-P34 FSW AFMA*/
                Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
                //RMC RIN-P47 Se corrige el orden pues trataba de convertir a string un valor nulo
                String numCorreDoc = (declaracionActual == null || declaracionActual.get("NUM_CORREDOC")==null)? "" :declaracionActual.get("NUM_CORREDOC").toString();
                if(!SunatStringUtils.isEmpty(numCorreDoc)){
                    //quitamos el indicador de en proceso
                    declaracionService.updateIndicadorDua(numCorreDoc, Constantes.INDICADOR_RECTIFICACION_OFICIO_EN_PROCESO, Constantes.IND_DUA_P_ESP, Constantes.INDICADOR_DUA_INACTIVO);
                }
            /*FIN-P34 FSW AFMA*/
                return cargarBusqDeclaracion(request,response);
            }

            //jenciso Inicio - carga los datos del formatoB en session
            Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> mapCabDeclara         = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            //P34 amancilla se comenta para tomar el nuevo servicio de cargado me las juego ojala funque jajaja
            //this.cargaFormatoBCompleto(mapCabDeclara);
            //this.cargaFormatoBCompleto(mapCabDeclaraActual);
            cargaFormatoBCompletoNew(mapCabDeclara, mapCabDeclaraActual, request);
            //P34 amancilla casu errores WebUtils.setSessionAttribute(request, "formatoBCargado", true);
            //jenciso Fin
            // inicio cus 14.15
            String indproveedor= mapCabDeclaraActual.get("IND_FORMBPROVEEDOR")!=null?mapCabDeclaraActual.get("IND_FORMBPROVEEDOR").toString():"";
            if(indproveedor.equals("0")){
                WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
            }
            // String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracion, DEFAULT_TIPO_DOC);
           // WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
            //this.cargarDocumentosDeclaracion(request); se comenta por pase 69
            //fin cus 14.15
            // dato enviado desde pagina PAGINA_RECUPERACION_DILIGENCIA_TMP
            String rsptaRecuperarDatosTMP =webRequest.getParameter("recuperarDatos") != null?webRequest.getParameter("recuperarDatos"): "";
            String activarSeccion02 =webRequest.getParameter("activarSeccion02") != null?webRequest.getParameter("activarSeccion02"): "NO";
            Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
            String numCorreDoc = declaracionActual.get("NUM_CORREDOC").toString();
            List<Map<String, Object>> lstTmpDetOfiRecti = (List) getVariableSesion(request, EnumVariablesSession.DATOS_TMP);
            /** Inicio RIN14 - fcastillo**/
            Map pkDocu = new HashMap();
            pkDocu.put("NUM_CORREDOC", numCorreDoc);
            /** Fin RIN14 - fcastillo**/
            //Ini P46-PAS20155E410000032
            if(!"".equals(SunatStringUtils.trimNotNull(webRequest.getParameter("registrarCodLibeDonacion")))
                    && mapCabDeclaraActual.get("registrarCodLibeDonacion") == null) {
                //registrarCodLibeDonacion: false - indica que el usuario NO debe registrar
                //un codigo liberatorio de donacion (no puede regularizar la donacion)
                mapCabDeclaraActual.put("registrarCodLibeDonacion", false);
            }
            //fin P46-PAS20155E410000032

            if ("SI".equals(rsptaRecuperarDatosTMP))
            {
                // envia a session los mapas que usa diligencia actualizados con los
                // datos temporales
                mergeDatosTMPtoMapasActuales(request, lstTmpDetOfiRecti);
                // actualizo los datos modificados
                res = mostrarRectificacionOficioEnProceso(request);
                // activar para pruebas
                // rectificacionOficioService.borrarDatosTMP(numCorreDoc);
            }
            else if ("NO".equals(rsptaRecuperarDatosTMP))
            {
                rectificacionOficioService.borrarDatosTMP(numCorreDoc);
                res = mostrarRectificacionOficioEnProceso(request);
            }
            else if ("EN_PROCESO".equals(rsptaRecuperarDatosTMP))
            {
                this.removerItemsEliminados(mapCabDeclara, request);
                this.removerItemsEliminados(mapCabDeclaraActual, request);
                BusquedaDua busquedaDua = new BusquedaDua(declaracionActual);
                //P34 3018 JMCV INICIO //se comenta por no ser parte de esta diligencia pruizcr peco 2018
                //rectificacionOficioService.actualizarEstadoRectificacionOficio(busquedaDua);
                //P34 3018 JMCV FIN
                List<Map<String, Object>> lstDatosTMP = new ArrayList<Map<String, Object>>();
                Map<String, Object> mapDatosGrabadosTemporalmente = new HashMap<String, Object>();
                // verificando si tienes datos rectificados grabados temporalmente
                if (CollectionUtils.isEmpty(lstTmpDetOfiRecti))
                {// busco en BD
                    // returna [lstTmpDetOfiRecti,lstCambios]
                    mapDatosGrabadosTemporalmente =rectificacionOficioService.obtenerDatosGrabadosTemporalmente(numCorreDoc,MODULO_CULMINACION_PECO);
                    if (!CollectionUtils.isEmpty((List<Map<String, Object>>) mapDatosGrabadosTemporalmente.get("lstCambios")))
                    {
                        lstDatosTMP = (List<Map<String, Object>>) mapDatosGrabadosTemporalmente.get("lstCambios");
                    }
                }
             /*INICIO-P34 FSW AFMA*/
                //antes de cargar los datos temporales verificamos si es el mismo usuario si no se eleimina
                String usuarioQueRegistroDatosBorrador = mapDatosGrabadosTemporalmente.get("USUARIO").toString();
                if(StringUtils.isBlank(usuarioQueRegistroDatosBorrador) && !userSession.getNroRegistro().equals(usuarioQueRegistroDatosBorrador)){
                    rectificacionOficioService.borrarDatosTMP(numCorreDoc);
                    lstDatosTMP = new ArrayList<Map<String, Object>>();
                }
             /*FIN-P34 FSW AFMA*/
                // evaluo que pantalla mostrar
                if (CollectionUtils.isEmpty(lstDatosTMP))
                {
                    res = mostrarRectificacionOficioEnProceso(request);
                }
                else
                {
                    //GGRANADOS OFICIO
                    Map<String, Object> indicadorDuaRectiOfi = declaracionService.obtenerIndicadorDuaByPk(numCorreDoc, Constantes.IND_DUA_RECTI_OFICIO);
                    if(indicadorDuaRectiOfi!=null && indicadorDuaRectiOfi.get("FEC_MODIF")!=null)
                    {
                        Date fecMaxRegisIndicador = SunatDateUtils.addDay((Date)indicadorDuaRectiOfi.get("FEC_MODIF"), 10);
                        Date fechaHoy = SunatDateUtils.getCurrentDate();
                        if(SunatDateUtils.esFecha1MayorQueFecha2(fechaHoy, fecMaxRegisIndicador, SunatDateUtils.COMPARA_SOLO_FECHA)){
                            res = mostrarRectificacionOficioEnProceso(request);
                        }
                        //P34 3018 JMCV INICIO
                        else {
                            //P34 AFMA FSWif (userSession.getNroRegistro().equals(indicadorDuaRectiOfi.get("COD_USUREGIS"))) {
                            if (userSession.getNroRegistro().equals(indicadorDuaRectiOfi.get("COD_USUMODIF"))) {
                                res = mostrarDatosTMP(request, mapDatosGrabadosTemporalmente);
                            }
                            else {
                                rectificacionOficioService.borrarDatosTMP(numCorreDoc);
                                res = mostrarRectificacionOficioEnProceso(request);
                            }
                        }
                        //P34 3018 JMCV FIN
                    }
                    else
                    {
                        res = mostrarDatosTMP(request, mapDatosGrabadosTemporalmente);
                    }
                }
                /** Inicio RIN14 - fcastillo**/
                List<Map<String, Object>> lstDocAsociados = declaracionService.obtenerDocAutAsociados(pkDocu);
                List<Map<String, Object>> lstDetAutorizacion = serieService.obtenerDetAutorizacion(pkDocu);


                declaracionActual.put("lstDocAutAsociado", Utilidades.copiarLista((List) lstDocAsociados));
                declaracionActual.put("lstDetAutorizacion", Utilidades.copiarLista((List) lstDetAutorizacion));

                mapCabDeclara.put("lstDocAutAsociado", Utilidades.copiarLista((List) lstDocAsociados));
                mapCabDeclara.put("lstDetAutorizacion", Utilidades.copiarLista((List) lstDetAutorizacion));
                /** Fin RIN14 - fcastillo**/
            }
            else if ("EN_PROCESO_SERIES".equals(rsptaRecuperarDatosTMP))
            {
                res = mostrarRectificacionOficioEnProceso(request);
            }
            else if ("EN_REVISION".equals(rsptaRecuperarDatosTMP))
            { // flujo por BASICO 1er envio
                res = mostrarRectificacionOficioEnRevision(request);
            }

            res.addObject("activarSeccion02", activarSeccion02);
            return res;
        }
        catch (ServiceException e)
        {
            return showErrorPagM(e.getMessage());
        }
        catch (Exception e)
        {
            log.error("**** ERROR ****:", e);
            return showErrorPagM("");
        }
    }
    private boolean isFormatoBCargado(HttpServletRequest request) {
        Boolean formatoBCargado = (Boolean) WebUtils.getSessionAttribute(request, "formatoBCargado");
        return (formatoBCargado != null);
    }
    /*inicio gdlr399*/
    public void cargaFormatoBCompletoNew(Map<String, Object> declaracion, Map<String, Object> declaracionActual, HttpServletRequest request) {
        log.debug("-->INICIO - cargaFormatoBCompletoNew");
        //amancilla si ya esta cargado no lo vuelve hacer
        if (isFormatoBCargado(request)) {
            return;
        }
        //Las tablas consultadas son 9: FORMBPROVEEDOR, FORMBMONTO, CONDICION_TRANSA, COMPROB_PAGO, ITEMFACTURA, VFOBPROVISIONAL, SERIES_ITEM, FACTUSUCE, FORMBITEMDESCRI
        //Al parecer no es necesario consultar independientemente la tabla OBSERVACION... se reduce la cantidad de querys a 9
        //Obtenemos una sola vez el num_corredoc del map declaracionActual
        Object numeroCorrelativoAsObject = declaracionActual.get("NUM_CORREDOC");
        if (numeroCorrelativoAsObject == null || numeroCorrelativoAsObject.toString().isEmpty()) {
            //lanzariamos excepcion?
            return;
        }
        //glazaror... se separa logica de carga de formato B en un metodo independiente para mejorar mantenibilidad
        Map<String, Object> cacheListas = cargarInformacionFormatoB(numeroCorrelativoAsObject, declaracionActual, request);
        //extraemos las listas necesarias para trabajarlos mas adelante
        List<Map> proveedores = (List<Map>) cacheListas.get("proveedores");
        Map<String, List<Map<String, Object>>> cacheItemFactura = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheItemFactura");
        Map<String, List<Map<String, Object>>> cacheFobProvisional = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFobProvisional");
        Map<String, List<Map<String, Object>>> cacheSeriesItem = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheSeriesItem");
        Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheDescripcionesMinimas");
        Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturasSucesivas");
        Map<String, Map<String, Object>> cacheMontos = (Map<String, Map<String, Object>>) cacheListas.get("cacheMontos");
        Map<String, Map<String, Object>> cacheCondicionesTransaccion = (Map<String, Map<String, Object>>) cacheListas.get("cacheCondicionesTransaccion");
        Map<String, List<Map<String, Object>>> cacheFacturas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturas");
        //empezamos a trabajar con las listas obtenidas anteriormente
        //declaracion.put("lstFormBProveedor", proveedores);
        //declaracionActual.put("lstFormBProveedor", lstActualProveedor);
        if (proveedores != null && proveedores.size() > 0) {
            declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
        } else {
            declaracionActual.put("IND_FORMBPROVEEDOR", "1");
        }
        if (proveedores != null) {
            for (Map<String, Object> proveedor : proveedores) {
                Object numeroSecuenciaProveedor = getValue(proveedor, "num_secprove");//al parecer esta en minusculas
                String key = numeroSecuenciaProveedor.toString();
                Map<String, Object> montosByProveedor = cacheMontos.get(key);
                Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(key);
                List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(key);
                //carga montos asociados a cada proveedor
                if (montosByProveedor != null && !montosByProveedor.isEmpty()) {
                    proveedor.put("mapFormBMonto", montosByProveedor);
                }
                //carga condiciones de transaccion asociados a cada proveedor
                if (condicionesTransaccionByProveedor != null && !condicionesTransaccionByProveedor.isEmpty()) {
                    proveedor.put("mapCondicionTransa", condicionesTransaccionByProveedor);
                }
                //carga facturas asociadas a cada proveedor
                if (facturasByProveedor != null && !facturasByProveedor.isEmpty()) {
                    proveedor.put("lstComproBPago", facturasByProveedor);
                }
            }
            for (Map<String, Object> proveedor : proveedores) {
                List<Map<String, Object>> facturasByProveedor = (List<Map<String,Object>>) proveedor.get("lstComproBPago");
                //verificamos si es que el proveedor tiene facturas asociadas
                if (facturasByProveedor != null) {
                    for (Map<String, Object> factura : facturasByProveedor) {
                        Object numeroSecuenciaProveedorByFactura = getValue(factura, "NUM_SECPROVE");
                        Object numeroSecuenciaFactura = getValue(factura, "NUM_SECFACT                                                                                                                                                                                                                                                                                                                                                     ");
                        String keyFactura = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
                        List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(keyFactura);
                        factura.put("lstItemFactura", itemsFacturaByFactura);
                        //verificamos si es que la factura tiene items asociados
                        if (itemsFacturaByFactura != null && !itemsFacturaByFactura.isEmpty()) {
                            //inicio carga itemsfactura por cada factura de proveedor
                            for (Map<String, Object> itemFactura : itemsFacturaByFactura) {
                                Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
                                Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");
                                Object numeroItemByItem = getValue(itemFactura, "NUM_SECITEM");
                                //formateamos el numero de secuencia de observacion y la observacion
                                Object observacionAsObject = getValue(itemFactura, "OBSERVACION");
                                if (observacionAsObject != null) {
                                    String[] observacionSplit = observacionAsObject.toString().split("-");
                                    String secuenciaObservacion = observacionSplit[0];
                                    String observacion = observacionSplit.length>1?observacionSplit[1]:"";//INC 2016-166552 observacion tipo 03 obs_obs con null
                                    itemFactura.put("OBSERVACION", observacion);
                                    itemFactura.put("NUM_SECOBS", secuenciaObservacion);//averiguar en que formato lo usan... por el momento se llena como string...
                                }
                                //inicio copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional
                                String IND_REGISTRO_GRABADO = "0";
                                String DES_REGISTRO_GRABADO = "Adicionado";
                                itemFactura.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);//valor: "0" (Adicionado)
                                itemFactura.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);//valor: "Adicionado"
                                itemFactura.put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
                                itemFactura.put("IND_DESCMANTITEM", "0");//valor: "0" (no muestra descripcion)
                                if (itemFactura.get("IND_DEL").equals("1")) {
                                    itemFactura.put("ELIMINADO_PERMANENTE", "BD");
                                } else {
                                    itemFactura.put("ELIMINADO_PERMANENTE", "");
                                }
                                //fin copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional
                                String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem + "-" + numeroItemByItem;
                                List<Map<String, Object>> registrosFobProvisionalByItemFactura = cacheFobProvisional.get(key);
                                List<Map<String, Object>> seriesItemsByItemFactura = cacheSeriesItem.get(key);
                                List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);
                                //carga vfobprovisional, seriesItems y descripciones minimas por itemfactura
                                cargarDatosItemFacturaEnLista(itemFactura, registrosFobProvisionalByItemFactura, "lstVfobProvisional");
                                cargarDatosItemFacturaEnLista(itemFactura, seriesItemsByItemFactura, "lstSeriesItem");
                                cargarDatosItemFacturaEnLista(itemFactura, descripcionesMinimasByItemFactura, "lstDecrMinima");
                                //carga referenciaDuda por itemfactura.... pendiente... al parecer ya se quito la consulta a referenciaDuda en el pase 399... verificar
                            }
                        }
                        //fin carga itemsfactura por cada factura de proveedor
                        //carga facturas sucesivas
                        String key = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
                        List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
                        cargarDatosFacturaEnLista(factura, facturasSucesivasByFactura, "lstFactuSucesivas");
                    }
                }
            }
        }
        if (proveedores != null) {
            // List<Map> lstActualProveedor = Utilidades.copiarLista(proveedores);
            //amancilla
            List<Map<String, Object>> dstList1 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
            List<Map<String, Object>> dstList2 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
            declaracion.put("lstFormBProveedor", dstList1);
            declaracionActual.put("lstFormBProveedor", dstList2);
        }
        //gdlr: se carga en sesion un indicador de formato b cargado
        WebUtils.setSessionAttribute(request, "formatoBCargado", true);
        log.info("Fin metodo cargaFormatoBCompletoNew");
    }
    /**
     * Carga la informacion de formato B de forma optimizada.
     * @param numeroCorrelativoAsObject numero correlativo de la dua
     * @param declaracionActual map con los datos de dua
     * @param request objeto request
     * @return informacion cargada de formato B en un HashMap
     */
    private Map<String, Object> cargarInformacionFormatoB(Object numeroCorrelativoAsObject, Map<String, Object> declaracionActual, HttpServletRequest request) {
        Long numeroCorrelativo = new Long(numeroCorrelativoAsObject.toString());
        boolean mostrarItemsEliminados = validarMostrarItemsEliminados(declaracionActual, request);
        //Unico map de parametros con el NUM_CORREDOC
        Map<String, Object> parametros = new HashMap<String, Object>();
        parametros.put("NUM_CORREDOC", numeroCorrelativo);
        Map<String, Object> parametrosItemFactura = new HashMap<String, Object>();
        parametrosItemFactura.put("NUM_CORREDOC", numeroCorrelativo);
        if (mostrarItemsEliminados) {
            parametrosItemFactura.put("incluirEliminados", "true");
        }
        //1. FORMBPROVEEDOR
        List<Map> proveedores = formatoValorService.obtenerFVProveedores(parametros);
        //2. FORMBMONTO
        List<Map<String,Object>> montos = formatoValorService.obtenerMontosFormBByDocumento(parametros);
        //3. CONDICION_TRANSA
        List<Map<String,Object>> condicionesTransaccion  = formatoValorService.obtenerCondicionTransaccionFormBByDocumento(parametros);
        //4. COMPROB_PAGO
        List<Map<String, Object>> facturas = formatoValorService.obtenerFacturasProveedor(parametros);
        //5. ITEMFACTURA
        List<Map<String, Object>> itemsFactura = formatoValorService.obtenerItemsFacturaByDocumento(parametrosItemFactura);
        //6. OBSERVACION... no es necesario
        //parametros.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
        //List<Map<String, Object>> observaciones = null;
        //7. VFOBPROVISIONAL
        List<Map<String, Object>> registrosFobProvisional = formatoValorService.obtenerFobProvisionalByDocumento(parametros);
        //8. SERIES_ITEM
        List<Map<String, Object>> seriesItems = serieService.obtenerSeriesItemByDocumento(parametros);
        //9. FACTUSUCE
        List<Map<String, Object>> facturasSucesivas = formatoValorService.selectFactuSuce(parametros);
        //10. FORMBITEMDESCRI
        List<Map<String, Object>> descripcionesMinimas = formatoValorService.selectFormbItemDescri(parametros);
        logger.info("realizadas todas las consultas");
        //glazaror... inicio agrupamiento
        //1. Agrupamos la lista itemsFactura por factura... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheItemFactura = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> itemFactura : itemsFactura) {
            Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
            Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");
            String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem;
            List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(key);
            if (itemsFacturaByFactura == null) {
                itemsFacturaByFactura = new ArrayList<Map<String, Object>>();
                cacheItemFactura.put(key, itemsFacturaByFactura);
            }
            itemsFacturaByFactura.add(itemFactura);
        }

        //2. Agrupamos la lista registrosFobProvisional por itemfactura... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheFobProvisional = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> registro : registrosFobProvisional) {
            Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
            Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
            Object numeroItem = registro.get("NUM_SECITEM");
            String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
            List<Map<String, Object>> fobsProvisionalByItemFactura = cacheFobProvisional.get(key);
            if (fobsProvisionalByItemFactura == null) {
                fobsProvisionalByItemFactura = new ArrayList<Map<String, Object>>();
                cacheFobProvisional.put(key, fobsProvisionalByItemFactura);
            }
            fobsProvisionalByItemFactura.add(registro);
        }
        //3. Agrupamos la lista seriesItems por itemfactura... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheSeriesItem = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> registro : seriesItems) {
            Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
            Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
            Object numeroItem = registro.get("NUM_SECITEM");
            String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
            List<Map<String, Object>> seriesItemByItemFactura = cacheSeriesItem.get(key);
            if (seriesItemByItemFactura == null) {
                seriesItemByItemFactura = new ArrayList<Map<String, Object>>();
                cacheSeriesItem.put(key, seriesItemByItemFactura);
            }
            seriesItemByItemFactura.add(registro);
        }
        //4. Agrupamos la lista descripcionesMinimas por itemfactura... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> registro : descripcionesMinimas) {
            Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
            Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
            Object numeroItem = registro.get("NUM_SECITEM");
            String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
            List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);
            if (descripcionesMinimasByItemFactura == null) {
                descripcionesMinimasByItemFactura = new ArrayList<Map<String, Object>>();
                cacheDescripcionesMinimas.put(key, descripcionesMinimasByItemFactura);
            }
            descripcionesMinimasByItemFactura.add(registro);
        }
        //5. Agrupamos la lista facturasSucesivas por factura... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> registro : facturasSucesivas) {
            Object numeroSecuenciaProveedorPorRegistro = registro.get("NUM_SECPROVE");
            Object numeroSecuenciaFacturaPorRegistro = registro.get("NUM_SECFACT");
            String key = numeroSecuenciaProveedorPorRegistro + "-" + numeroSecuenciaFacturaPorRegistro;
            List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
            if (facturasSucesivasByFactura == null) {
                facturasSucesivasByFactura = new ArrayList<Map<String, Object>>();
                cacheFacturasSucesivas.put(key, facturasSucesivasByFactura);
            }
            facturasSucesivasByFactura.add(registro);
        }
        //6. Agrupamos la lista montos por proveedor... solo recorremos una vez la lista
        Map<String, Map<String, Object>> cacheMontos = new HashMap<String, Map<String, Object>>();
        for (Map<String, Object> registro : montos) {
            String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
            Map<String, Object> montosByProveedor = cacheMontos.get(numeroSecuenciaProveedor);
            if (montosByProveedor == null) {
                montosByProveedor = new HashMap<String, Object>();
                cacheMontos.put(numeroSecuenciaProveedor, montosByProveedor);
            }
            montosByProveedor.put(getValue(registro, "COD_MONTO").toString().trim(), getValue(registro, "MTO_VALOR"));
        }
        //7. Agrupamos la lista condicionesTransaccion por proveedor... solo recorremos una vez la lista
        Map<String, Map<String, Object>> cacheCondicionesTransaccion = new HashMap<String, Map<String, Object>>();
        for (Map<String, Object> registro : condicionesTransaccion) {
            String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
            Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(numeroSecuenciaProveedor);
            if (condicionesTransaccionByProveedor == null) {
                condicionesTransaccionByProveedor = new HashMap<String, Object>();
                cacheCondicionesTransaccion.put(numeroSecuenciaProveedor, condicionesTransaccionByProveedor);
            }
            condicionesTransaccionByProveedor.put(getValue(registro, "COD_INDTRANSACCION").toString().trim(), getValue(registro, "IND_TRANSACCION"));
        }
        //8. Agrupamos la lista facturas por proveedor... solo recorremos una vez la lista
        Map<String, List<Map<String, Object>>> cacheFacturas = new HashMap<String, List<Map<String, Object>>>();
        for (Map<String, Object> registro : facturas) {
            String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
            List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(numeroSecuenciaProveedor);
            if (facturasByProveedor == null) {
                facturasByProveedor = new ArrayList<Map<String, Object>>();
                cacheFacturas.put(numeroSecuenciaProveedor, facturasByProveedor);
            }
            facturasByProveedor.add(registro);
        }
        //glazaror... fin agrupamiento
        //salvamos en un map la informacion agrupada
        Map<String, Object> cacheListas = new HashMap<String, Object>();
        cacheListas.put("proveedores", proveedores);
        cacheListas.put("cacheItemFactura", cacheItemFactura);
        cacheListas.put("cacheFobProvisional", cacheFobProvisional);
        cacheListas.put("cacheSeriesItem", cacheSeriesItem);
        cacheListas.put("cacheDescripcionesMinimas", cacheDescripcionesMinimas);
        cacheListas.put("cacheFacturasSucesivas", cacheFacturasSucesivas);
        cacheListas.put("cacheMontos", cacheMontos);
        cacheListas.put("cacheCondicionesTransaccion", cacheCondicionesTransaccion);
        cacheListas.put("cacheFacturas", cacheFacturas);
        return cacheListas;
    }
    //este metodo fue creado temporalmente... luego revisar los nombres exactos (mayusculas o minusculas)
    private Object getValue(Map<String, Object> datos, String nombre) {
        Object value = datos.get(nombre.toUpperCase());
        if (value == null) {
            value = datos.get(nombre.toLowerCase());
        }
        return value;
    }
    private void cargarDatosFacturaEnLista(Map<String, Object> factura, List<Map<String, Object>> registros, String nombreMapa) {
        if (registros != null && !registros.isEmpty()) {
            factura.put(nombreMapa, registros);
        }
    }
    private void cargarDatosItemFacturaEnLista(Map<String, Object> itemFactura, List<Map<String, Object>> registros, String nombreMapa) {
        if (registros != null && !registros.isEmpty()) {
            //si es que existen registros entonces
            itemFactura.put(nombreMapa, registros);
        }
    }
    /** Retorna un boolean que indica si los items eliminados se van a incluir en la consulta (de acuerdo al estado de la declaracin)
     * @param declaracionActual
     * @param request
     * @return
     */
    private boolean validarMostrarItemsEliminados(Map<String, Object> declaracionActual, HttpServletRequest request){
        boolean indMostrarEliminados = true;
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
        String estadoDua = declaracionActual.get("COD_ESTDUA").toString();
        String estadoPecoAmazonia = "";
        if ("10".equals(tipoDiligencia))
        {
            if (declaracionActual.get("COD_ESTADO_CULMINACION_PECO")!=null
                    && "EN_PROCESO".equals(declaracionActual.get("COD_ESTADO_CULMINACION_PECO").toString()))
            {
                estadoPecoAmazonia = "EN_PROCESO";
            }
        }
        if ((Constantes.ESTADO_RECTI_PROCESO.equals(estadoDua) || "EN_PROCESO".equals(estadoPecoAmazonia))
                && !(tipoDiligencia.equals(Constantes.MODO_DILIGENCIA_CONSULTA))) {
            indMostrarEliminados = false;
        }
        return indMostrarEliminados;
    }
    /**
     * Metodo que persiste temporalmente en formato JSON los datos del Formato A y Formato B
     * Implementado en:
     * - Rectificacion de Oficio.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @throws Exception the exception
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView grabarTMP(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView res = new ModelAndView(this.jsonView);
        try {
            UsuarioBean userSession = (UsuarioBean) getVariableSesion(request, EnumVariablesSession.USUARIO_LOGEADO);
            // grabado en las tablas del usuario de auditoria
            UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            List<Map<String, Object>> lstFacturasSerieActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerieActual");
            List<Map<String, Object>> lstFacturasSerie = (ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerie");
            String numCorreDoc = declaracionActual.get("NUM_CORREDOC").toString();
            // validamos los datos principales
            if (!CollectionUtils.isEmpty(declaracionActual) && !CollectionUtils.isEmpty(lstDetDeclaraActual)) {
                Map<String, Object> params = new HashMap<String, Object>();
                declaracionActual.put("tipdilig", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
                params.put("mapCabDeclaraActual", declaracionActual);
                params.put("lstDetDeclaraActual", lstDetDeclaraActual);
                params.put("lstDetDeclaraAnt", lstDetDeclara);
                params.put("lstSeriesItemActual", lstSeriesItemActual);
                params.put("lstSeriesItem", lstSeriesItem);
                params.put("lstFacturasSerieActual", lstFacturasSerieActual);
                params.put("lstFacturasSerie", lstFacturasSerie);
                params.put("caduana", this.obtenerAduana(request));
                params.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));
                params.put("cod_funcionario", userSession.getNroRegistro().trim());
                // TODO: EVALUAR SI ES NECESARIO OJO QUE ADICION Y ELIMINACION SI VA actualizandoSerieAndSeriesItem(params);
                rectificacionOficioService.grabarTMP(params);
                //Integer plazoMaximo = 0;
                Map<String, Object> indicadorDuaRectiOfi = declaracionService.obtenerIndicadorDuaByPk(numCorreDoc,
                        Constantes.IND_DUA_RECTI_OFICIO);
                if(CollectionUtils.isEmpty(indicadorDuaRectiOfi)){
                    declaracionService.insertarIndicadorDua(numCorreDoc, Constantes.IND_DUA_RECTI_OFICIO,Constantes.IND_DUA_P_ESP);
                }
                //  plazoMaximo = 10;
                    /*}else{
                        Date fecRegisIndicador = SunatDateUtils.addDay((Date)indicadorDuaRectiOfi.get("FEC_MODIF"), 11);
                        Date fechaHoy = SunatDateUtils.getCurrentDate();
                        plazoMaximo = SunatDateUtils.getDifference(fecRegisIndicador, fechaHoy, Calendar.DATE).intValue();
                    }
                   */
                // Limpiamos los objetos de sesion
                // Utilidades.limpiarMapasSesion(request);
                // se debe de reinicializa la pantalla a la opcion de busqueda de la declaracion
                // La grabacin temporal de los datos se realiz correctamente por un plazo mximo de 10 das calendario, contados desde el da en que se efectu el primer guardado temporal
                //Los datos rectificados en la declaracin se grabaron temporalmente
                res.addObject("msjOK", "Los datos rectificados en la declaraci\u00f3n se grabaron temporalmente");
            } else {
                res.addObject("msjOK", "No Existen cambios en los datos");
            }
            res.addObject("transaccionOK", true);
            return res;
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorJSON("");
        }
    }

    //p34



    /**
     * Actualiza los Mapas de SESSION que se usan en DILIGENCIA
     * con los datos temporales guardados
     *
     * @param request [HttpServletRequest] request
     * @param lstTmpDetOfirecti [List<Map<String,Object>>] Lista de datos registrados en TmpDetOfirecti o DetOfiRecti.
     * @throws Exception
     */
    private void mergeDatosTMPtoMapasActuales(HttpServletRequest request, List<Map<String, Object>> lstTmpDetOfirecti) throws Exception{
        JsonSerializer serializer = new JsonSerializer();
        if (!CollectionUtils.isEmpty(lstTmpDetOfirecti))
        {
            //recorro la lista de datos registrados en cualquier forma de DetOfiRecti
            Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> declaracion         = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            //limpiar
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", null);
            WebUtils.setSessionAttribute(request, "mapCabDeclara", null);
            Map<String, Object> mapCabDeclaraNew= new HashMap<String, Object>();
            Map<String, Object> mapCabDeclaraOld= new HashMap<String, Object>();
            mapCabDeclaraNew.putAll(Utilidades.copiarMapa(mapCabDeclaraActual));
            mapCabDeclaraOld.putAll(Utilidades.copiarMapa(declaracion));
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraNew);
            WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclaraOld);
            List<Map<String, Object>> lstFormBProveedorActual = (List<Map<String, Object>>) mapCabDeclaraNew.get("lstFormBProveedor");
              /*
              if (CollectionUtils.isEmpty(lstFormBProveedorActual))
              {
                mapCabDeclaraNew = cargaFormatoBCompleto(mapCabDeclaraNew);
                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraNew);
              }*/
            List<Map<String, Object>> lstFormBProveedorInicial = (List<Map<String, Object>>) mapCabDeclaraOld.get("lstFormBProveedor");
              /*/
              if (CollectionUtils.isEmpty(lstFormBProveedorInicial))
              {
                mapCabDeclaraOld = cargaFormatoBCompleto(mapCabDeclaraOld);
                WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclaraOld);
              }*/
            for (Map<String, Object> mapDatosTMP : lstTmpDetOfirecti)
            {
                //obtenemos los datos por cada tabla
                String codTabla = mapDatosTMP.get("COD_TABLA").toString();
                Map<String, Object> mapDesData1 = (Map) serializer.deserialize(mapDatosTMP.get("DES_DATA1"));
                Map<String, Object> mapDesClave = (Map) serializer.deserialize(mapDatosTMP.get("DES_CLAVE"));
                EnumTablaModel enumTablaModel = EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla);
                if (StringUtils.contains(enumTablaModel.getNombreVariableSessionOld(), "map")) {
                    Map<String, Object> mapDatosTablaBD = (Map) getVariableSesion(request,enumTablaModel, VAR_NEW);
                    setValorNuevo(mapDatosTablaBD, mapDesData1);
                    //se guada en SESSION el mapa actualizado
                    setVariableSesion(request,enumTablaModel, VAR_NEW,mapDatosTablaBD);
                } else if (StringUtils.contains(enumTablaModel.getNombreVariableSessionOld(), "lst")) {
                    List<Map<String, Object>> lstDatosTablaBD = (List) getVariableSesion(request,enumTablaModel, VAR_NEW);
                    Map<String, Object> mapDatosTablaBD = soporteComparadorService.obtenerElementoMapXPkTabla(lstDatosTablaBD, mapDesClave, enumTablaModel);
                    if (!CollectionUtils.isEmpty(mapDatosTablaBD)) {
                        lstDatosTablaBD.remove(mapDatosTablaBD);
                        setValorNuevo(mapDatosTablaBD, mapDesData1);
                        //se guada en SESSION el mapa actualizado
                        lstDatosTablaBD.add(mapDatosTablaBD);
                        setVariableSesion(request,enumTablaModel, VAR_NEW,lstDatosTablaBD);
                    }
                }
                //participantes
                if("T0070".equals(codTabla))
                {
                    Map<String, Object> mapCabDeclaraActual1 = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual1.get("lstFormBProveedor");
                    if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
                    {
                        Map keys = new HashMap();
                        keys.put("NUM_CORREDOC", mapDesClave.get("NUM_CORREDOC"));
                        keys.put("NUM_SECPROVE", mapDesClave.get("NUM_SECPROVE"));
                        Map mapDatosTablaBD = Utilidades.obtenerElemento(lstFormBProveedor, keys);
                        Map mapDatoMod = new HashMap();

                        if (!CollectionUtils.isEmpty(mapDatosTablaBD)) {
                            lstFormBProveedor.remove(mapDatosTablaBD);
                            setValorNuevo(mapDatoMod, Utilidades.convertKeyMapToLowerCase(mapDesData1));
                            if(mapDatoMod.get("NOM_CARGO")!=null){
                                mapDatosTablaBD.put("nom_cargo",mapDatoMod.get("NOM_CARGO"));
                                mapDatosTablaBD.put("mod_borrador","T");
                            }
                            lstFormBProveedor.add(mapDatosTablaBD);
                            WebUtils.setSessionAttribute(request, "mapDatoModProv", mapDatoMod);
                        }
                    }
                }
                if("T0038".equals(codTabla))
                {
                    Map<String, Object> mapCabDeclaraActual2       = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String, Object>> lstActualProveedor = (List<Map<String, Object>>) mapCabDeclaraActual2.get("lstFormBProveedor");
                    for (Map prov : lstActualProveedor)
                    {
                        String num_secprove = prov.get("num_secprove").toString();
                        List<Map<String,Object>> lstFacturas =  (List<Map<String,Object>>)prov.get("lstComproBPago");
                        if (lstFacturas != null && lstFacturas.size() > 0)
                        {
                            Map<String, Object> mapDatosTablaBD = soporteComparadorService.obtenerElementoMapXPkTabla(lstFacturas, Utilidades.convertKeyMapToLowerCase(mapDesClave), enumTablaModel);
                            if (!CollectionUtils.isEmpty(mapDatosTablaBD)) {
                                lstFacturas.remove(mapDatosTablaBD);
                                setValorNuevo(mapDatosTablaBD, mapDesData1);
                                //se guada en SESSION el mapa actualizado
                                lstFacturas.add(mapDatosTablaBD);
                                colocarLstFacturas(mapCabDeclaraActual2, lstFacturas, num_secprove);
                                //se guada en SESSION el mapa actualizado
                                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual2);
                            }
                        }
                    }
                }
                if("T0078".equals(codTabla))
                {
                    Map<String, Object> mapCabDeclaraActual3 = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String, Object>> lstActualProveedor = (List<Map<String, Object>>) mapCabDeclaraActual3.get("lstFormBProveedor");
                    for (Map prov : lstActualProveedor)
                    {
                        String num_secprove = prov.get("num_secprove").toString();
                        List<Map<String,Object>> lstFacturas =  (List<Map<String,Object>>)prov.get("lstComproBPago");
                        if (lstFacturas != null && lstFacturas.size() > 0)
                        {
                            for (Map compPag : lstFacturas)
                            {
                                String num_secfact = compPag.get("num_secfact").toString();
                                List<Map<String, Object>> lstItemFactura = (ArrayList) compPag.get("lstItemFactura");
                                if (lstItemFactura != null && lstItemFactura.size() > 0)
                                {
                                    Map keys = new HashMap();
                                    keys.put("NUM_CORREDOC", mapDesClave.get("NUM_CORREDOC"));
                                    keys.put("NUM_SECITEM", mapDesClave.get("NUM_SECITEM"));
                                    Map<String, Object> mapDatosTablaBD = Utilidades.obtenerElemento(lstItemFactura, keys);
                                    //Map<String, Object> mapDatosTablaBD = soporteComparadorService.obtenerElementoMapXPkTabla(lstItemFactura, mapDesClave, enumTablaModel);
                                    if (!CollectionUtils.isEmpty(mapDatosTablaBD)) {
                                        lstItemFactura.remove(mapDatosTablaBD);
                                        setValorNuevo(mapDatosTablaBD, mapDesData1);
                                        //se guada en SESSION el mapa actualizado
                                        lstItemFactura.add(mapDatosTablaBD);
                                        Ordenador.sortDesc(lstItemFactura, "NUM_SECITEM", Ordenador.ASC);
                                        colocarLstItemFacturas(mapCabDeclaraActual3, lstItemFactura, num_secprove, num_secfact);
                                        //se guada en SESSION el mapa actualizado
                                        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual3);
                                    }
                                }
                            }
                        }
                    }
                }

                if("T0087".equals(codTabla))
                {
                    Map<String, Object> mapCabDeclaraActual1 = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual1.get("lstFormBProveedor");
                    if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
                    {
                        Map keys = new HashMap();

                        String numSecParticipante =  mapDesClave.get("NUM_SECPARTIC").toString();
                        keys.put("NUM_SECPARTIC", numSecParticipante);
                        Map mapDatosTablaBD = Utilidades.obtenerElemento(lstFormBProveedor, keys);

                        Map mapDatoMod = new HashMap();
                        if (!CollectionUtils.isEmpty(mapDatosTablaBD)) {
                            lstFormBProveedor.remove(mapDatosTablaBD);
                            setValorNuevo(mapDatoMod, Utilidades.convertKeyMapToLowerCase(mapDesData1));

                            if(mapDatoMod.get("COD_TIPDOC")!=null){
                                mapDatosTablaBD.put("cod_tipdoc_prd",mapDatoMod.get("COD_TIPDOC"));
                            }
                            if(mapDatoMod.get("NOM_RAZONSOCIAL")!=null){
                                mapDatosTablaBD.put("nom_razonsocial_prd",mapDatoMod.get("NOM_RAZONSOCIAL"));
                            }if(mapDatoMod.get("NUM_DOCIDENT")!=null){
                                mapDatosTablaBD.put("num_docident_prd",mapDatoMod.get("NUM_DOCIDENT"));
                            }if(mapDesClave.get("NUM_SECPARTIC")!=null){
                                mapDatosTablaBD.put("num_secdeclarante",mapDesClave.get("NUM_SECPARTIC"));
                                mapDatosTablaBD.put("mod_borrador","T");
                            }
                            lstFormBProveedor.add(mapDatosTablaBD);
                            WebUtils.setSessionAttribute(request, "mapDatoMod", mapDatoMod);
                            //se guada en SESSION el mapa actualizado
                            mapCabDeclaraActual1.put("lstFormBProveedor",lstFormBProveedor);
                            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual1);
                        }else{

                            Map  mapParticipante = diligenciaService.obtenerParticipante(numSecParticipante);

                            String codTipParticipante = mapParticipante.get("COD_TIPPARTIC")!=null?mapParticipante.get("COD_TIPPARTIC").toString():"";
                            if("45".equals(codTipParticipante)){

                                //String codTipDoc = mapDesData1.get("COD_TIPDOC").toString();
                                String numDocIdent = mapDesData1.get("NUM_DOCIDENT").toString();
                                String nomRazonSocial = mapDesData1.get("NOM_RAZONSOCIAL").toString();
                                String direcc = mapDesData1.get("DIR_PARTIC").toString();

                                // mapCabDeclaraActual1.put("COD_TIPDOC_PIM", codTipDoc);
                                mapCabDeclaraActual1.put("NUM_DOCIDENT_PIM", numDocIdent);
                                mapCabDeclaraActual1.put("COD_TIPPARTIC_PIM", codTipParticipante);
                                mapCabDeclaraActual1.put("NOM_RAZONSOCIAL_PIM", nomRazonSocial);
                                mapCabDeclaraActual1.put("DIR_PARTIC_PIM", direcc);

                                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual1);
                            }

                        }

                        //P34 amancilla



                    }
                }

                //jenciso Inicio se agrega las tablas vehi_cetico y monto_gasto y docuprece_dua
                if(COD_TABLA_DOCUPRECE_DUA.equals(codTabla)){
                    Map<String, Object> mapCabDeclaraActualAux = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String,Object>> lstDetDeclaraActual = (ArrayList<Map<String,Object>>)WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
                    for(Map<String, Object> mapSerie: lstDetDeclaraActual){
                        //String num_secserie = mapSerie.get("").toString();
                        List<Map<String,Object>> lstDocuPreceDua = (ArrayList<Map<String,Object>>)mapSerie.get("lstDocuPreceDua");
                        if(!CollectionUtils.isEmpty(lstDocuPreceDua)){
                            Map keys = new HashMap();
                            keys.put("NUM_CORREDOC", mapDesClave.get("NUM_CORREDOC"));
                            keys.put("NUM_SECSERIE", mapDesClave.get("NUM_SECSERIE"));
                            keys.put("NUM_SECSERIEPRE", mapDesClave.get("NUM_SECSERIEPRE"));
                            keys.put("COD_ADUANAPRE", mapDesClave.get("COD_ADUANAPRE"));
                            keys.put("ANN_PRESENPRE", mapDesClave.get("ANN_PRESENPRE"));
                            keys.put("COD_REGIMENPRE", mapDesClave.get("COD_REGIMENPRE"));
                            keys.put("NUM_DECLARACIONPRE", mapDesClave.get("NUM_DECLARACIONPRE"));
                            Map<String, Object> mapDatosTablaBD = Utilidades.obtenerElemento(lstDocuPreceDua, keys);
                            if(!CollectionUtils.isEmpty(mapDatosTablaBD)){
                                lstDocuPreceDua.remove(mapDatosTablaBD);
                                setValorNuevo(mapDatosTablaBD, mapDesData1);
                                lstDocuPreceDua.add(mapDatosTablaBD);
                                mapSerie.put("lstDocuPreceDua", lstDocuPreceDua);
                                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);

                            }
                        }

                    }
                }
                if(COD_TABLA_VEHI_CETICO.equals(codTabla)){
                    Map<String, Object> mapCabDeclaraActualAux = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    List<Map<String,Object>> lstDetDeclaraActual = (ArrayList<Map<String,Object>>)WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
                    for(Map<String, Object> mapSerie: lstDetDeclaraActual){
                        //String num_secserie = mapSerie.get("").toString();
                        List<Map<String,Object>> lstDatoVehiculo = (ArrayList<Map<String,Object>>)mapSerie.get("lstDatoVehiculo");
                        if(!CollectionUtils.isEmpty(lstDatoVehiculo)){
                            Map keys = new HashMap();
                            keys.put("NUM_CORREDOC", mapDesClave.get("NUM_CORREDOC"));
                            keys.put("NUM_SECSERIE", mapDesClave.get("NUM_SECSERIE"));

                            Map<String, Object> mapDatosTablaBD = Utilidades.obtenerElemento(lstDatoVehiculo, keys);
                            if(!CollectionUtils.isEmpty(mapDatosTablaBD)){
                                lstDatoVehiculo.remove(mapDatosTablaBD);
                                setValorNuevo(mapDatosTablaBD, mapDesData1);
                                lstDatoVehiculo.add(mapDatosTablaBD);
                                mapSerie.put("lstDatoVehiculo", lstDatoVehiculo);
                                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);

                            }
                        }

                    }
                }

                if(COD_TABLA_MONTO_GASTO.equals(codTabla)){
                    List<Map<String,Object>> lstDetDeclaraActual = (ArrayList<Map<String,Object>>)WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
                    for(Map<String, Object> mapSerie: lstDetDeclaraActual){
                        //String num_secserie = mapSerie.get("").toString();
                        List<Map<String,Object>> lstDatoMontoGasto = (ArrayList<Map<String,Object>>)mapSerie.get("lstDatoMontoGasto");
                        if(!CollectionUtils.isEmpty(lstDatoMontoGasto)){
                            Map keys = new HashMap();
                            keys.put("NUM_CORREDOC", mapDesClave.get("NUM_CORREDOC"));
                            keys.put("NUM_SECSERIE", mapDesClave.get("NUM_SECSERIE"));
                            keys.put("COD_CPTOGASTOS", mapDesClave.get("COD_CPTOGASTOS"));
                            Map<String, Object> mapDatosTablaBD = Utilidades.obtenerElemento(lstDatoMontoGasto, keys);
                            if(!CollectionUtils.isEmpty(mapDatosTablaBD)){
                                lstDatoMontoGasto.remove(mapDatosTablaBD);
                                setValorNuevo(mapDatosTablaBD, mapDesData1);
                                lstDatoMontoGasto.add(mapDatosTablaBD);
                                mapSerie.put("lstDatoMontoGasto", lstDatoMontoGasto);
                                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
                            }else{//se trata de nuevo registro
                                Map<String,Object> mapDatosNew = new HashMap<String, Object>();
                                mapDatosNew.putAll(keys);
                                setValorNuevo(mapDatosNew,mapDesData1);//agrega los campos faltantes
                                lstDatoMontoGasto.add(mapDatosNew);
                                mapSerie.put("lstDatoMontoGasto", lstDatoMontoGasto);
                                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
                            }
                        }

                    }
                }
                //jenciso Fin
                    /*INICIO-P34 FSW AFMA*/
                //DILIGENCIA
                if("T0061".equals(codTabla)){
                    String resultado = "";
                    for (Entry<String, Object> entrada: mapDesData1.entrySet()) {
                        if("DES_RESULTADO".equals(entrada.getKey().toUpperCase())){
                            resultado = entrada.getValue().toString();
                            Map<String, Object> mapCabDeclaraActualAux = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                            mapCabDeclaraActualAux.put("DES_RESULTADO",resultado);
                            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActualAux);
                        }
                    }
                }
                    /*FIN-P34 FSW AFMA*/
            }
        }
        // remuevo los datos temporales.
        removerVariableSesion(request, EnumVariablesSession.DATOS_TMP);
    }
    /**
     * Pre-Condicion : haber ejecutado el metodo obtenerListadoSeries Proceso :
     * Metodo permite regresa a la pantalla principal de la rectificacion de
     * oficio permite la navegavilidad sin perder la informacion grabada en
     * session es invocado desde la pagina de Series para regresar al registro
     * de la declaracion Post-Condicion: Invocaciones : opcion de regreso de la
     * PAGINA_PRINCIPAL_DETALLE a la PAGINA_PRINCIPAL.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @throws Exception the exception
     * @autor: amancillaa
     */
    public ModelAndView irDiligenciaCulminacionPeco(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        try {
            //	String tipDilig = dataConstante.getDiligenciaRectificacionOficio();
            Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList<Map<String, Object>>) WebUtils
                    .getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstSeriesItemActual = (ArrayList<Map<String, Object>>) WebUtils
                    .getSessionAttribute(request, "lstSeriesItemActual");
            List<Map<String, Object>> lstFacturasSerieActual = (ArrayList<Map<String, Object>>) WebUtils
                    .getSessionAttribute(request, "lstFacturasSerieActual");
            // este dato fue seteado al inicio de cargar la declaracion
            List<Map<String, Object>> lstDetOfiRecti = (ArrayList<Map<String, Object>>) WebUtils.getSessionAttribute(
                    request, "lstDetOfiRecti");
            ServletWebRequest webRequest = new ServletWebRequest(request);
            Object condDiligTemp = webRequest.getParameter("condDiligTemp");
            // pinta los datos modificados de la declaracion siempre que estos
            // hallan sido
            // grabados en session si no se pierde
            ModelAndView res = new ModelAndView(PAGINA_PRINCIPAL_EN_PROCESO, "declaracion", declaracionActual);
          /*TODO: prox pase usar catalogo */
            List listTipoResolucion = this.resolucionService.obtenerTiposResoluciones();
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            String codDependencia = bUsuario.getCodUO().substring(0, 2);
            res.addObject("lstTiposResolucionJSON",
                    !CollectionUtils.isEmpty(listTipoResolucion) ? SojoUtil.toJson(listTipoResolucion) : "[]");
            res.addObject("lstDatosTmpGuardados", "[]"); // se envia vacio pq
            // solo se debe
            // cargar al inicio
            res.addObject("listExpedientesAndActas", "[]"); // se envia vacio pq
            // solo se debe
            // cargar al inicio
            //RIN08 INICIO
            Map<String, Object> mapCabDeclara= (HashMap)WebUtils.getSessionAttribute(request, "mapCabDeclara");
            Map<String, Object> PkDocu = new HashMap();
            PkDocu.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
            PkDocu.put("COD_TIPDILIGENCIA", "22"); //constantes.DILIG_ADUANA_DESTINO
            List <Map<String, Object>>listadoDiligenciaDespacho = diligenciaService.selectDiligencia(PkDocu);
            if (listadoDiligenciaDespacho.size()>0){
                request.setAttribute("diligencia", "SI");
            }else{
                request.setAttribute("diligencia", "NO");
            }
            //RIN08 FIN
          /*INICIO-P34 FSW AFMA*/
            res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
          /*FIN-P34 FSW AFMA*/
            return res;
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorPagM("");
        }
    }
    /********************SECCION CARGA DE OPCIONES DE LA DECLARACION ****************/
    public ModelAndView validarCambioDeFechaDescarga(HttpServletRequest request, HttpServletResponse response)
    {
        String msjValidacion ="";
        try{
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String fechaDescarga = webRequest.getParameter("txt_fec_term") != null
                    ? webRequest.getParameter("txt_fec_term") : "";
            String codModalidad =  webRequest.getParameter("sel_cod_modalidad") != null ? webRequest.getParameter("sel_cod_modalidad") : "";
            String codAduanaManifiesto = webRequest.getParameter("txt_aduamanifiesto") != null ? webRequest.getParameter("txt_aduamanifiesto") : "";
            String annManifiesto = webRequest.getParameter("txt_annmanifiesto") != null ? webRequest.getParameter("txt_annmanifiesto") : "";
            String numManifiesto = webRequest.getParameter("txt_num_manifiesto") != null ? webRequest.getParameter("txt_num_manifiesto") : "";
            String codViaTrans = webRequest.getParameter("sel_cod_viatrans") != null ? webRequest.getParameter("sel_cod_viatrans") : "";
             /*P34 AMANCILLA inicio*/
            boolean bloquearOpcionGrabado=false;
            //validacion de data previa Bug23737
            if(SunatStringUtils.isEmpty(fechaDescarga) && SunatStringUtils.isEmpty(codModalidad) &&
                    SunatStringUtils.isEmpty(codAduanaManifiesto) &&  SunatStringUtils.isEmpty(annManifiesto) &&
                    SunatStringUtils.isEmpty(numManifiesto) &&  SunatStringUtils.isEmpty(codViaTrans)){
                return new ModelAndView(jsonView, "msjValidacion", "");
            }
             /*P34 AMANCILLA fin*/
            Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
            Date fechaDescargaModificado = Utilidades.toDate(fechaDescarga);
            Date fechaTermDeclaracionInicial = Utilidades.toDate(declaracionActual.get("FEC_TERM").toString());
    /*P34 AMANCILLA
             if(!SunatDateUtils.sonIguales(fechaDescargaModificado, fechaTermDeclaracionInicial, SunatDateUtils.COMPARA_SOLO_FECHA)
                 && !SunatDateUtils.sonIguales(fechaDescargaModificado, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))
             {*/
            String codTipManifiesto = declaracionActual.get("COD_TIPMANIFIESTO").toString();
            Map<String, Object> params= new HashMap<String, Object>();
            params.put("codModalidad", codModalidad);
            params.put("codAduanaManifiesto", codAduanaManifiesto);
            params.put("annManifiesto", annManifiesto);
            params.put("numManifiesto", numManifiesto);
            params.put("codViaTrans", codViaTrans);
            params.put("fechaDescargaModificado", fechaDescargaModificado);
            params.put("codTipManifiesto", codTipManifiesto);
            msjValidacion = validaDiligenciaService.validarCambioDeFechaDescarga(params);
            return new ModelAndView(jsonView, "msjValidacion", msjValidacion);
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorJSON(e.getMessage());
        }
    }
    public ModelAndView validarCambioDeModalidad(HttpServletRequest request, HttpServletResponse response) {
        try{
            ServletWebRequest webRequest = new ServletWebRequest(request);
            //Map<String, Object> mapDatosValidar = new HashMap<String, Object>();
            String codModalidad         =  webRequest.getParameter("sel_cod_modalidad") != null ? webRequest.getParameter("sel_cod_modalidad") : "";
            String codAduanaManifiesto = webRequest.getParameter("txt_aduamanifiesto") != null ? webRequest.getParameter("txt_aduamanifiesto") : "";
            String annManifiesto = webRequest.getParameter("txt_annmanifiesto") != null ? webRequest.getParameter("txt_annmanifiesto") : "";
            String numManifiesto = webRequest.getParameter("txt_num_manifiesto") != null ? webRequest.getParameter("txt_num_manifiesto") : "";
            String codViaTrans = webRequest.getParameter("sel_cod_viatrans") != null ? webRequest.getParameter("sel_cod_viatrans") : "";
            Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
            Date fechaDeclaracion = Utilidades.toDate(declaracionActual.get("FEC_DECLARACION"));
            String codTipManifiesto = declaracionActual.get("COD_TIPMANIFIESTO").toString();
            Map<String, Object> params= new HashMap<String, Object>();
            String codModalidadBD = declaracionActual.get("COD_MODALIDAD").toString();
            params.put("codModalidadBD", codModalidadBD);
            params.put("codModalidad", codModalidad);
            params.put("codAduanaManifiesto", codAduanaManifiesto);
            params.put("annManifiesto", annManifiesto);
            params.put("numManifiesto", numManifiesto);
            params.put("codViaTrans", codViaTrans);
            params.put("fechaDeclaracion", fechaDeclaracion);
            params.put("codTipManifiesto", codTipManifiesto);
            Map<String,String> msjValidacion = validaDiligenciaService.validarCambioDeModalidad(params);
            ModelAndView view = new ModelAndView("jsonView", "msjValModalidad", msjValidacion.get("msjValAnticipado")!=null?msjValidacion.get("msjValAnticipado"):"");
            view.addObject("msjValManif", msjValidacion.get("msjValManif")!=null?msjValidacion.get("msjValManif"):"");
            view.addObject("esAnticipado", msjValidacion.get("esAnticipado")!=null
                    && msjValidacion.get("esAnticipado").toString().equals("SI")?"SI":"NO");
            return view;
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorJSON(e.getMessage());
        }
    }
    public ModelAndView validarCambioDeDeclarante(HttpServletRequest request, HttpServletResponse response) {
        try{
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String tipoDocIdentidad   =  webRequest.getParameter("tipoDocIdentidad") != null ? webRequest.getParameter("tipoDocIdentidad") : "";
            String numeroDocIdentidad = webRequest.getParameter("numeroDocIdentidad") != null ? webRequest.getParameter("numeroDocIdentidad").toString().trim() : "";
            String mtoTotFobDol       = webRequest.getParameter("montoFOBFormulario") != null ? webRequest.getParameter("montoFOBFormulario") : "0";
            Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
            List<Map> lstDetDeclaraActual = (List<Map>) getVariableSesion(request, EnumTablaModel.DET_DECLARA, VAR_NEW);
            Map<String, Object> params= new HashMap<String, Object>();
            params.put("mapCabDeclaraActual", declaracionActual);
            params.put("lstDetDeclaraActual", lstDetDeclaraActual);
            params.put("tipoDocIdentidad", tipoDocIdentidad);
            params.put("numeroDocIdentidad", numeroDocIdentidad);
            params.put("mtoTotFobDol", mtoTotFobDol);
            declaracionActual.put("COD_TIPDOC_PIM", tipoDocIdentidad);
            declaracionActual.put("NUM_DOCIDENT_PIM",numeroDocIdentidad );
            String msjValidacion = validaDiligenciaService.validarCambioDeDeclarante(params);
            return new ModelAndView(jsonView, "msjValidacion", msjValidacion);
        } catch (ServiceException e) {
            return showErrorPagM(e.getMessage());
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorJSON(e.getMessage());
        }
    }
    // FORMATO A - INICIO
    /**
     * Metodo que nos permite obtener los Items de una Serie.
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     *
     */
    public ModelAndView cargarMantDVItem(HttpServletRequest request, HttpServletResponse response) {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        if (log.isDebugEnabled()) {
            log.debug(this.toString().concat(" cargarConsultaDVItem() - INICIO"));
        }
        List<Map<String, Object>> listaItems = null;
        Map mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");  // Pase PAS20165E220200138
        Map<String, String> PkSerie = new HashMap<String, String>();
        try {
            PkSerie.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
            PkSerie.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
            // amancilla pase 578 para los casos de series agregadas que estan
            // en memoria
            Map<String, String> mapNuevaSerieSerieBase = (Map<String, String>) WebUtils.getSessionAttribute(request,
                    "mapNuevaSerieSerieBase");
            if (mapNuevaSerieSerieBase != null && mapNuevaSerieSerieBase.size() > 0) {
                String serieBase = mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) != null ? mapNuevaSerieSerieBase
                        .get((String) webRequest.getParameter("hdn_num_secserie")) : "";
                if (!serieBase.equals("")) {
                    PkSerie.put("NUM_SECSERIE", serieBase);
                }
            }
            // Pase PAS20165E220200138
            if(mapCabDeclara!=null)
            {
                PkSerie.put("FEC_DECLARACION",  mapCabDeclara.get("FEC_DECLARACION").toString());
            }
            listaItems = formatoValorService.obtenerFVItem(PkSerie);
        } catch (ServiceException e) {
            log.error(this.toString() + " ERROR : " + e.getMessage());
            return new ModelAndView("PagM", "message", e.getMessage());
        } catch (Exception e) {
            log.error(this.toString() + " ERROR : " + e.getMessage());
            return new ModelAndView("PagM", "message", e.getMessage());
        } finally {
        }
        if (log.isDebugEnabled()) {
            log.debug(this.toString().concat(" cargarConsultaDVItem() - FIN"));
        }
        ModelAndView view = new ModelAndView("consultaDVItem", "listaItems", SojoUtil.toJson(listaItems));
        view.addObject("datamodel", listaItems);
        // Datos de formulario
        view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
        view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
        view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
        view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
        view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
        view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));
        return view;
    }
    /**
     * obtiene datos via AJAX para llenar el campo de AREA-RESOLUCIONES
     *
     * invocado: Registro sustento rectificacion de Oficio
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] JSON
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView cargarAreasDocumentoSustento(HttpServletRequest request, HttpServletResponse response){
        ModelAndView view = new ModelAndView(jsonView);
        ServletWebRequest webRequest = new ServletWebRequest(request);
        String filtro = webRequest.getParameter("filtro");
        String tipoDocSustentatorio = webRequest.getParameter("tipoDocSustentatorio");
        List<Map<String, Object>> lstAreas = new ArrayList();
        if("R".equals(tipoDocSustentatorio))
        {
            lstAreas = this.soporteService.obtenerAreasParaResoluciones(filtro);
        }
        else if ("V".equals(tipoDocSustentatorio))
        {
            lstAreas = this.soporteService.obtenerAreasParaActasVerificacion(filtro);
        }
        view.addObject("lstData", formatoCatalogo(lstAreas));
        return view;
    }
    private List<Map<String, Object>> formatoCatalogo(List<Map<String, Object>> lstDatos){
        List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
        Map catalogo;
        StringBuilder sb;
        //TODO: falta independizar de valor codigo y depen
        if (!CollectionUtils.isEmpty(lstDatos)) {
            for (Map<String, Object> mapDato: lstDatos) {
                catalogo = new HashMap();
                sb = new StringBuilder();
                sb.append(mapDato.get("codigo"));
                catalogo.put("c",sb.toString());
                sb.append("-");
                sb.append(mapDato.get("depen"));
                catalogo.put("n", sb.toString());
                lstRspta.add(catalogo);
            }
        }
        return lstRspta;
    }
    /**
     * Metodo que valida Existencia de Expediente.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @throws Exception the exception
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView validarDocumentoSustentatorio(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try {
            DocumentoSustento documentoSustentoForm = new DocumentoSustento();
            bindToCommand(request, documentoSustentoForm);
            documentoSustentoForm = DocumentoSustentoFactory.crearDocumentoSustento(documentoSustentoForm);
            DocumentoSustento documentoValidado = this.validaDiligenciaService.obtenerDocumentoSustentatorio(documentoSustentoForm);
            if(documentoValidado!=null)
            {
                res.addObject("documentoValidado", documentoValidado);
            }
            return res;
        }
        catch (Exception e)
        {
            log.error("**** ERROR ****:", e);
            return showErrorJSON("");
        }
    }


    /**
     * Metodo que obtiene los cambios relizados en los datos del Formato A Y
     * Formato B y los muestra en un JSP resumen para su confirmacion antes del
     * Grabado de la diligencia esta implementado: - Rectificacion de Oficio.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView obtenerDatosModificados(HttpServletRequest request, HttpServletResponse response){
        try {
            // devulevo la lista de cambios
            List<DatoModificadoBean> listaCambiosFomatoAyB = new ArrayList<DatoModificadoBean>();
            // obtiene los datos de la Sesssion
            Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            //List<Map<String, Object>> lstFacturasSerieActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstFacturasSerieActual");
            //List<Map<String, Object>> lstFacturasSerie = (ArrayList) WebUtils.getSessionAttribute(request,"lstFacturasSerie");
            // verifico si tiene datos para transformar los datos principales
            // if (!CollectionUtils.isEmpty(mapCabDeclaraActual) &&
            // !CollectionUtils.isEmpty(lstDetDeclaraActual)) {
            if (!CollectionUtils.isEmpty(mapCabDeclaraActual)) {
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("mapCabDeclaraActual", mapCabDeclaraActual);
                params.put("mapCabDeclara", mapCabDeclara);
                params.put("lstDetDeclaraActual", lstDetDeclaraActual);
                params.put("lstDetDeclara", lstDetDeclara);
                params.put("lstSeriesItemActual", lstSeriesItemActual);
                params.put("lstSeriesItem", lstSeriesItem);
                //params.put("lstFacturasSerieActual", lstFacturasSerieActual);
                //params.put("lstFacturasSerie", lstFacturasSerie);
                listaCambiosFomatoAyB = rectificacionOficioService.obtenerCambiosDeclaracion(params);
                /*INICIO-P34 FSW AFMA*/
                String des_resultado = request.getParameter("des_resultado") != null ? request.getParameter("des_resultado") : "";
                if(!StringUtils.isEmpty(des_resultado)){
                    //se quita por que afecta diligencia aduana destino edu lo detecto
                 /*DatoModificadoBean datoModificadoBean = new DatoModificadoBean();
                  datoModificadoBean.setDatoAntiguo("");
                  datoModificadoBean.setDatoNuevo(des_resultado);
                  datoModificadoBean.setDescripcionIdentificadorCampo("");
                  datoModificadoBean.setDescripcionSecccion("Datos de la Rectificacion Oficio");
                  datoModificadoBean.setDescripcionNombreCampo("Sustento");*/
                    //P34 AFMA mapCabDeclaraActual.put("DES_RESULTADO",datoModificadoBean);
                    mapCabDeclaraActual.put("DES_RESULTADO",des_resultado);
                    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
                    //listaCambiosFomatoAyB.add(datoModificadoBean);
                }
                //PAS20171U220200056 AFMA
                if(tieneIncidenciaF121(request)){
                    DatoModificadoBean datoModificadoBean = new DatoModificadoBean();
                    datoModificadoBean.setDatoAntiguo("");
                    datoModificadoBean.setDatoNuevo("F121");
                    datoModificadoBean.setDescripcionIdentificadorCampo("");
                    datoModificadoBean.setDescripcionSecccion("Mercancia Vigente");
                    datoModificadoBean.setDescripcionNombreCampo("Incidencia");
                    listaCambiosFomatoAyB.add(datoModificadoBean);
                }
                String tiempoPlazoNew = "";
                String tipoPlazoNew = request.getParameter("tiempoPlazo") != null ? request.getParameter("tiempoPlazo") : "";
                if("M".equals(tipoPlazoNew)){
                    tiempoPlazoNew="1-Meses";
                }
                else if("D".equals(tipoPlazoNew)){
                    tiempoPlazoNew="2-Dias";
                }else{
                    tiempoPlazoNew="";
                }

                String tiempoPlazoOld = "";
                String tipoPlazoOld = mapCabDeclaraActual.get("COD_TIPOPLAZO")!=null?mapCabDeclaraActual.get("COD_TIPOPLAZO").toString():"";
                if("1".equals(tipoPlazoOld)){
                    tiempoPlazoOld="1-Meses";
                }
                else if("2".equals(tipoPlazoOld)){
                    tiempoPlazoOld="2-Dias";
                }else{
                    tiempoPlazoOld="";
                }
                String plazoNew = request.getParameter("plazo") != null ? request.getParameter("plazo") : "";
                String plazoOld = mapCabDeclaraActual.get("NUM_PLAZOSOL")!=null?mapCabDeclaraActual.get("NUM_PLAZOSOL").toString():"";


                if(!StringUtils.isEmpty(tiempoPlazoNew) && !tiempoPlazoNew.equals(tiempoPlazoOld)){



                    DatoModificadoBean datoModificadoBean = new DatoModificadoBean();
                    datoModificadoBean.setDatoAntiguo(tiempoPlazoOld);
                    datoModificadoBean.setDatoNuevo(tiempoPlazoNew);
                    datoModificadoBean.setDescripcionIdentificadorCampo("");
                    datoModificadoBean.setDescripcionSecccion("PLAZO");
                    datoModificadoBean.setDescripcionNombreCampo("Tipo de Plazo");
                    listaCambiosFomatoAyB.add(datoModificadoBean);
                }
                if(!StringUtils.isEmpty(plazoNew) && !plazoNew.equals(plazoOld)){
                    DatoModificadoBean datoModificadoBean = new DatoModificadoBean();
                    datoModificadoBean.setDatoAntiguo(plazoOld);
                    datoModificadoBean.setDatoNuevo(plazoNew);
                    datoModificadoBean.setDescripcionIdentificadorCampo("");
                    datoModificadoBean.setDescripcionSecccion("PLAZO");
                    datoModificadoBean.setDescripcionNombreCampo("Duracion del Plazo");
                    listaCambiosFomatoAyB.add(datoModificadoBean);
                }
                /*FIN-P34 FSW AFMA*/
                if (!CollectionUtils.isEmpty(listaCambiosFomatoAyB))
                {
                    int num = 0;
                    for (DatoModificadoBean bean : listaCambiosFomatoAyB)
                    {
                        num++;
                        bean.setCorrelativo(num);
                    }
                }
            }
            ModelAndView res = new ModelAndView(this.jsonView);
            res.addObject("lstData", listaCambiosFomatoAyB);
            return res;
        } catch (Exception e) {
            log.error("**** ERROR ****:", e);
            return showErrorPagM("");
        }
    }

    private boolean tieneIncidenciaF121(HttpServletRequest request) {

        boolean tieneIncidenciaF121 = false;
        List<Incidencia> lstIncidencias = (List<Incidencia>) WebUtils.getSessionAttribute(request, "incidenciasManu");
        if (!CollectionUtils.isEmpty(lstIncidencias)) {
            for (Incidencia mapaIncidencia : lstIncidencias) {
                if (mapaIncidencia.getCodIncidencia().equals("F121")) {
                    tieneIncidenciaF121 = true;
                    break;
                }
            }
        }
        return tieneIncidenciaF121;
    }

    /**
     * <p>
     * Permite consultar via ajax local anexo
     * </p>.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView consultarLocalAnexo(HttpServletRequest request, HttpServletResponse response){
        if (log.isDebugEnabled())
            log.debug("method:consultarPersonal");
        ModelAndView view = new ModelAndView(jsonView);
        MensajeBean mensajeBean = new MensajeBean();
        try {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String ruc = webRequest.getParameter("txt_codigo");
            List<Map<String, Object>> lstLocalAnexo = soporteService.obtenerLocaAnexo(ruc);
            //P34 AFMA Bug 22834
            if (CollectionUtils.isEmpty(lstLocalAnexo)) {
                Map<String, Object> mapAnexo = new HashMap<String, Object>();
                mapAnexo.put("codLocalAnexo", "0000");
                mapAnexo.put("direccion", "");
                lstLocalAnexo.add(mapAnexo);
            }
            view.addObject("lstLocalAnexo", lstLocalAnexo);
        } catch (Exception ex) {
            log.error("**** ERROR ****", ex);
            mensajeBean.setError(true);
            mensajeBean.setMensajeerror("Se ha producido un error " + ex.getMessage());
        } finally {
            view.addObject(mensajeBean);
        }
        return view;
    }
    /**
     * <p>
     * Permite consultar via ajax al Participante
     * </p>.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [ModelAndView] model and view
     * @author  amancilla
     * @version 1.0
     */
    public ModelAndView consultarParticipante(HttpServletRequest request, HttpServletResponse response){
        if (log.isDebugEnabled())
            log.debug("method:consultarParticipante");
        ModelAndView view = new ModelAndView(jsonView);
        MensajeBean mensajeBean = new MensajeBean();
        try {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String ruc = webRequest.getParameter("txt_ruc");
            String numeroDocumento = webRequest.getParameter("txt_documento");
            String rasonSocial = webRequest.getParameter("txt_razonsocial");
            String codTipoOperador = webRequest.getParameter("tipoParticipante");
            String codtipoDocumento = webRequest.getParameter("tipoDocumento");
            //P34 AFMA
            String codTipoOperadorSegunCodigoLugarRecepcion="";
            String codigoLugarRecepcion = webRequest.getParameter("codigoLugarRecepcion")!=null?webRequest.getParameter("codigoLugarRecepcion").toString():"";
            List<Map<String, String>> lstOperador = new ArrayList<Map<String, String>>();
            // se agrega el tipo 45
            if (!COD_TIPO_PARTICIPANTE_IMPORTADOR.equals(codTipoOperador)) {
                //P34 AFMA
                codTipoOperadorSegunCodigoLugarRecepcion = Utilidades.obtenerTipoOperadorSegunCodigoLugarRecepcion(codigoLugarRecepcion);
                String codTipoOperadorDesc = catalogoAyudaService.getDescripcionDataCatalogo(
                        CAT_PARTICIPANTES, codTipoOperadorSegunCodigoLugarRecepcion);
                lstOperador = operadorAyudaService.getListaOperadores(codTipoOperadorSegunCodigoLugarRecepcion, ruc, rasonSocial);
                for (Map<String, String> mapOperador : lstOperador) {
                    mapOperador.put("codTipoOperador", codTipoOperador);
                    mapOperador.put("codTipoOperadorDesc", codTipoOperadorDesc);
                }
                if(org.springframework.util.StringUtils.isEmpty(codTipoOperadorSegunCodigoLugarRecepcion.trim()) && ArrayUtils.contains(new String[] { "9", "6","2" }, codigoLugarRecepcion)){
                    Map<String, Object> mapRspta = soporteService.obtenerPerNatJur("4", ruc);
                    if (!CollectionUtils.isEmpty(mapRspta)) {
                        Map<String, String> mapItem = new HashMap<String, String>();
                        mapItem.put("num_ruc", (String) mapRspta.get("codigo"));
                        mapItem.put("des_razsocial", (String) mapRspta.get("nombre"));
                        mapItem.put("codTipoOperador", " ");
                        mapItem.put("codTipoOperadorDesc", " ");
                        lstOperador.add(mapItem);
                    }
                }
                // se agrega el tipo 12
                if (COD_TIPO_PARTICIPANTE_TRANSPORTISTA.equals(codTipoOperador)) {
                    String codTipoOperador12Desc = catalogoAyudaService.getDescripcionDataCatalogo(
                            CAT_PARTICIPANTES, COD_TIPO_PARTICIPANTE_REPRESENTANTE);
                    List<Map<String, String>> lstOperador12 = operadorAyudaService.getListaOperadores(
                            COD_TIPO_PARTICIPANTE_REPRESENTANTE, ruc, rasonSocial);
                    for (Map<String, String> mapOperador12 : lstOperador12) {
                        Map<String, String> mapOperador = new HashMap<String, String>(mapOperador12);
                        mapOperador.put("codTipoOperador", COD_TIPO_PARTICIPANTE_REPRESENTANTE);
                        mapOperador.put("codTipoOperadorDesc", codTipoOperador12Desc);
                        lstOperador.add(mapOperador);
                    }
                }
            } else { // 45
                Map<String, Object> mapBusqueda = new HashMap<String, Object>();
                Map<String, Object> mapRspta = new HashMap<String, Object>();
                Map<String, String> mapItem = new HashMap<String, String>();
                if (ArrayUtils.contains(new String[] { "3", "4" }, codtipoDocumento)) {
                    mapRspta = soporteService.obtenerPerNatJur(codtipoDocumento, numeroDocumento);
                    if (!CollectionUtils.isEmpty(mapRspta)) {
                        mapItem.put("numeroDocumento", (String) mapRspta.get("codigo"));
                        mapItem.put("razonSocial", (String) mapRspta.get("nombre"));
                        mapItem.put("direccion", (String) mapRspta.get("direccion"));
                        lstOperador.add(mapItem);
                    }
                } else { // busca tabla declaran
                    mapBusqueda.put("codTipoDocum", codtipoDocumento);
                    mapBusqueda.put("numDocum", numeroDocumento);
                    List<Map<String, Object>> lstRspta = ayudaServiceDeclaranImpl.buscar(mapBusqueda);
                    if (!CollectionUtils.isEmpty(lstRspta)) {
                        mapItem.put("numeroDocumento", (String) lstRspta.get(0).get("cdocumen"));
                        mapItem.put("razonSocial", (String) lstRspta.get(0).get("dnombre"));
                        mapItem.put("direccion", (String) lstRspta.get(0).get("ddirecc"));
                        lstOperador.add(mapItem);
                    }
                }
            }
            view.addObject("lstOperador", lstOperador);
        } catch (Exception ex) {
            log.error("**** ERROR ****", ex);
            mensajeBean.setError(true);
            mensajeBean.setMensajeerror("Se ha producido un error " + ex.getMessage());
        } finally {
            view.addObject(mensajeBean);
        }
        return view;
    }
    /*********************************************SECCION DE METODOS PRIVADOS***************************/
    /**
     * Metodo que procesa la Validacion de Regimenes de Precedencia.
     *
     * @param request [HttpServletRequest] request
     * @param response [HttpServletResponse] response
     * @return  [String] string
     * @author  amancilla
     * @version 1.0
     */
    private String procesaValidacionTieneRegPrecedencia(HttpServletRequest request, HttpServletResponse response){
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
        params.put("COD_TIPCONVENIO_TPN", webRequest.getParameter("cod_tipconvenio_tpn"));
        params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        return this.validaDiligenciaService.validaTieneRegPrecedencia(params);
    }
    /**
     * Permite poblar al mapa mapDatosResultado con los valores del mapa mapDatosNuevos.
     *
     * @param mapDatosResultado [Map<String,Object>] mapa que quiero poblar con los datos nuevos
     * @param mapDatosNuevos [Map<String,Object>] map datos nuevos
     */
    private void setValorNuevo(Map<String, Object> mapDatosResultado, Map<String, Object> mapDatosNuevos){
        for (Entry<String, Object> entrada: mapDatosNuevos.entrySet()) {
            //se actualiza el mapa
            mapDatosResultado.put(entrada.getKey().toUpperCase(), entrada.getValue());
        }
    }
    /**
     *
     * Mostrar rectificacion oficio.
     *
     * @param request [HttpServletRequest] request
     * @return  [ModelAndView] PAGINA_PRINCIPAL
     * @author  amancilla
     * @version 1.0
     * @throws Exception
     */
    private ModelAndView mostrarRectificacionOficioEnProceso(HttpServletRequest request) throws Exception{
        //ya no se va usar
        removerVariableSesion(request,EnumVariablesSession.DATOS_TMP);
        Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
        //con este dato DESbloqueamos la pantalla de series el boton editar de solo consulta
        declaracionActual.put("COD_ESTADO_CULMINACION_PECO","EN_PROCESO");
        setVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW, declaracionActual);
        // envio de listas de expedientes y Resoluciones
        List listTipoResolucion = this.resolucionService.obtenerTiposResoluciones();
        ModelAndView res = new ModelAndView(PAGINA_PRINCIPAL_EN_PROCESO);

            /*inicio P46-PAS20155E410000032-[jlunah] BUG 25055*/
        boolean habilitarIngresoDeIndicadorDonacion = habilitarIngresoDeIndicadorDonacion(request,declaracionActual);
        declaracionActual.put("HABILITAR_INGRESO_DE_INDICADOR_DONACION", habilitarIngresoDeIndicadorDonacion);
            /*fin P46-PAS20155E410000032-[jlunah] BUG 25055*/

        res.addObject("declaracion", declaracionActual);
        // TODO: evaluar para que valla en session se repite en
        // irRectificacionOficio
        res.addObject("lstTiposResolucionJSON",
                !CollectionUtils.isEmpty(listTipoResolucion) ? SojoUtil.toJson(listTipoResolucion) : "[]");
        //lo usan las consultas enlaces como consulta rectificaciones
        res.addObject("codDocumentoAduanero", COD_DOCUMENTO_ADUANERO);
        //RIN08 INICIO
        Map<String, Object> mapCabDeclara= (HashMap)WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, Object> PkDocu = new HashMap();
        PkDocu.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
        PkDocu.put("COD_TIPDILIGENCIA", "22"); //constantes.DILIG_ADUANA_DESTINO
        List <Map<String, Object>>listadoDiligenciaDespacho = diligenciaService.selectDiligencia(PkDocu);
        if (listadoDiligenciaDespacho.size()>0){
            request.setAttribute("diligenciaAduanaDestino", "SI");
            WebUtils.setSessionAttribute(request, "diligenciaAduanaDestino", "SI");
        }else{
            request.setAttribute("diligenciaAduanaDestino", "NO");
            WebUtils.setSessionAttribute(request, "diligenciaAduanaDestino", "NO");
        }
        //RIN08 FIN
          /*INICIO-P34 FSW AFMA*/
        res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
          /*FIN-P34 FSW AFMA*/
        return res;
    }
    /*inicio P46-PAS20155E410000032-[jlunah]*/
        /*retornara true en caso cumpla :
         * -No tenga canal
         * -Declaracion no este cancelada
         * -Tipo de tratamiento diferente a 4
         * */
    private boolean habilitarIngresoDeIndicadorDonacion(HttpServletRequest request, Map <String,Object> declaracionActual){

        Map<String, Object> params = new HashMap<String, Object>();
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        params.put("documentoAduanero", "DUA");
        params.put("codigoFuncionario", bUsuario.getNroRegistro());
        params.put("cod_aduana", declaracionActual.get("COD_ADUANA"));
        params.put("ann_presen", declaracionActual.get("ANN_PRESEN"));
        params.put("cod_regimen", declaracionActual.get("COD_REGIMEN"));
        params.put("des_regimen", declaracionActual.get("COD_REGIMEN_DESC"));
        params.put("num_declaracion", declaracionActual.get("NUM_DECLARACION"));
        params.put("MapDeclaraActual", declaracionActual);

        ValTratamientoDonacionService valTratamientoDonacion = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");

        return valTratamientoDonacion.habilitarIngresoDeIndicadorDonacion(params);

    }
        /*fin P46-PAS20155E410000032-[jlunah]*/

    private void cargarSeriesSesion(HttpServletRequest request)
    {
        // Cargamos las series en sesion
        List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                "lstDetDeclaraActual");
        if (CollectionUtils.isEmpty(lstDetDeclara))
        { // si esta vacio o null obtener de BD
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, String> params = new HashMap<String, String>();
            params.put("documentoAduanero", COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString().trim());
            params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString().trim());
            params.put("cod_aduana", declaracion.get("COD_ADUANA").toString().trim());
            params.put("ann_presen", declaracion.get("ANN_PRESEN").toString().trim());
            params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString().trim());
            params.put("acceso", "");
            lstDetDeclara = serieService.obtenerListadoSeries(params);
            WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
            List lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
            lstDetDeclaraActual = Utilidades.copiarLista((List) lstDetDeclara);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
        }
    }
    private ModelAndView mostrarRectificacionOficioEnRevision(HttpServletRequest request) throws Exception{
        Map declaracionActual = (HashMap) getVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW);
        //con este dato bloqueamos la pantalla de series el boton editar de solo consulta
        declaracionActual.put("COD_ESTADO_CULMINACION_PECO","EN_REVISION");
        setVariableSesion(request, EnumTablaModel.CAB_DECLARA, VAR_NEW, declaracionActual);
        ModelAndView res = new ModelAndView(PAGINA_PRINCIPAL_EN_REVISION);

          /*inicio P46-PAS20155E410000032-[jlunah] BUG 25257*/
        boolean habilitarIngresoDeIndicadorDonacion = habilitarIngresoDeIndicadorDonacion(request,declaracionActual);
        declaracionActual.put("HABILITAR_INGRESO_DE_INDICADOR_DONACION", habilitarIngresoDeIndicadorDonacion);
          /*fin P46-PAS20155E410000032-[jlunah] BUG 25257*/

        res.addObject("declaracion", declaracionActual);
        //lo usan las consultas enlaces como consulta rectificaciones
        res.addObject("codDocumentoAduanero", COD_DOCUMENTO_ADUANERO);
        return res;
    }
    /**
     * Mostrar datos tmp.
     *
     * @param request [HttpServletRequest] request
     * @param lstDatosTMP [List] lst datos tmp
     * @return  [ModelAndView] PAGINA_RECUPERACION_DATOS_TMP
     * @author  amancilla
     * @version 1.0
     */
    private ModelAndView mostrarDatosTMP(HttpServletRequest request, Map<String, Object> mapDatosGrabadosTemporalmente){
        List lstDatosTMP       = (List<Map<String, Object>>) mapDatosGrabadosTemporalmente.get("lstCambios");
        List lstTmpDetOfiRecti = (List<Map<String, Object>>) mapDatosGrabadosTemporalmente.get("lstTmpDetOfiRecti");
        //asigna a session los datos tempoales
        setVariableSesion(request, EnumVariablesSession.DATOS_TMP, lstTmpDetOfiRecti);
        ModelAndView res = new ModelAndView(PAGINA_RECUPERACION_DATOS_TMP);
        res.addObject("lstDatosTmpGuardados",!CollectionUtils.isEmpty(lstDatosTMP) ? SojoUtil.toJson(lstDatosTMP) : "");
        return res;
    }
    /**
     *
     *
     * @param mapAdvertencias [Map<String,Object>] map advertencias
     * @return  [List<Map<String,Object>>] list
     * @author  amancilla
     * @version 1.0
     */
    private List<Map<String, Object>> formatearDataAdvertenciasForJSP(Map<String, Object> mapAdvertencias){
        List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listExpediDua = (List)mapAdvertencias.get("listExpediDua");
        List<Map<String, Object>> listActasDua = (List)mapAdvertencias.get("listActasDua");
        List<Map<String, Object>> listAceDua = (List)mapAdvertencias.get("listAceDua");
        List<Map<String, Object>> lstAvisosInspeccionDocTransporte = (List)mapAdvertencias.get("lstAvisosInspeccionDocTransporte");
        List<Map<String, Object>> listActasDocTransporte = (List)mapAdvertencias.get("listActasDocTransporte");
        List<Map<String, Object>> listAceDocTransporte = (List)mapAdvertencias.get("listAceDocTransporte");
        if (!CollectionUtils.isEmpty(listExpediDua)) {
            for (Map<String, Object> mapAgregar: listExpediDua) {
                Map mapFila = new HashMap<String, Object>();
                mapFila.put("DOCUMENTO", "DUA cuenta con Expediente:");
                mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO"));
                mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
                lstRspta.add(mapFila);
            }
        }
        if (!CollectionUtils.isEmpty(listActasDua)) {
            for (Map<String, Object> mapAgregar: listActasDua) {
                Map mapFila = new HashMap<String, Object>();
                String codTipActa = StringUtil.defaultSiEsVacio(mapAgregar.get("CTIPO_ACTA").toString());
                if(ACTA_INMOVILIZACION.equals(codTipActa))
                {
                    mapFila.put("DOCUMENTO", "DUA cuenta con Acta de Inmovilizaci�n:");
                }
                else if(ACTA_INCAUTACION.equals(codTipActa))
                {
                    mapFila.put("DOCUMENTO", "DUA cuenta con Acta de Incautaci�n:");
                }
                else
                {
                    mapFila.put("DOCUMENTO", "DUA cuenta con Acta:");
                }
                mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO"));
                mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
                lstRspta.add(mapFila);
            }
        }
        if (!CollectionUtils.isEmpty(listAceDua)) {
            for (Map<String, Object> mapAgregar: listAceDua) {
                String acta = Util.obtenerPkConcatenado(mapAgregar,ConstantesACE.TIPO_CONCATENACION_ACTA);
                FechaBean fbRegistro = new FechaBean(mapAgregar.get("FECHA_REGIS").toString(),"yyyyMMdd");
                Map mapFila = new HashMap<String, Object>();
                mapFila.put("DOCUMENTO", "DUA cuenta con Accin de Control Extraordinario:");
                mapFila.put("NRODOCUMENTO", acta);
                mapFila.put("FECHA", fbRegistro.getFormatDate("dd/MM/yyyy").toString());
                lstRspta.add(mapFila);
            }
        }
        if (!CollectionUtils.isEmpty(lstAvisosInspeccionDocTransporte)) {
            for (Map<String, Object> mapAgregar: lstAvisosInspeccionDocTransporte) {
                Map mapFila = new HashMap<String, Object>();
                mapFila.put("DOCUMENTO", "DUA cuenta con Aviso de Inspecci�n:");
                mapFila.put("NRODOCUMENTO", mapAgregar.get("NRO"));
                mapFila.put("FECHA", "");
                lstRspta.add(mapFila);
            }
        }
        if (!CollectionUtils.isEmpty(listActasDocTransporte)) {
            for (Map<String, Object> mapAgregar: listActasDocTransporte) {
                Map mapFila = new HashMap<String, Object>();
                String codTipActa = StringUtil.defaultSiEsVacio(mapAgregar.get("CTIPO_ACTA").toString());
                if(ACTA_INMOVILIZACION.equals(codTipActa))
                {
                    mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta de Inmovilizaci�n:");
                }else if(ACTA_INCAUTACION.equals(codTipActa))
                {
                    mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta de Incautaci�n:");
                }else
                {
                    mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acta:");
                }
                mapFila.put("NRODOCUMENTO", mapAgregar.get("NUMERO"));
                mapFila.put("FECHA", mapAgregar.get("FECHA_HORA"));
                lstRspta.add(mapFila);
            }
        }
        if (!CollectionUtils.isEmpty(listAceDocTransporte)) {
            for (Map<String, Object> mapAgregar: listAceDocTransporte) {
                String acta = Util.obtenerPkConcatenado(mapAgregar,ConstantesACE.TIPO_CONCATENACION_ACTA);
                FechaBean fbRegistro = new FechaBean(mapAgregar.get("FECHA_REGIS").toString(),"yyyyMMdd");
                Map mapFila = new HashMap<String, Object>();
                mapFila.put("DOCUMENTO", "Doc.Transporte cuenta con Acci�n de Control Extraordinario:");
                mapFila.put("NRODOCUMENTO", acta);
                mapFila.put("FECHA", fbRegistro.getFormatDate("dd/MM/yyyy").toString());
                lstRspta.add(mapFila);
            }
        }
        return lstRspta;
    }
    public Map<String, Object> cargaFormatoBCompleto(Map<String, Object> declaracionActual)
    {
        List<Map> lstActualProveedor = new ArrayList();
        List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
        if (lstFormBProveedor == null)
        {
            Map<String, Object> pFormBP = new HashMap<String, Object>();
            pFormBP.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
            lstFormBProveedor = this.formatoValorService.obtenerFVProveedores(pFormBP);
            if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
            {
                for (Map prov : lstFormBProveedor)
                {
                    prov.put("num_corredoc", declaracionActual.get("NUM_CORREDOC"));
                }
            }
            lstActualProveedor = Utilidades.copiarLista(lstFormBProveedor);
            declaracionActual.put("lstFormBProveedor", lstActualProveedor);
        }
        if (!CollectionUtils.isEmpty(lstFormBProveedor))
            declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
        else
            declaracionActual.put("IND_FORMBPROVEEDOR", "1");
        if (!CollectionUtils.isEmpty(lstActualProveedor))
        {
            for (Map prov : lstActualProveedor)
            {
                Map<String, Object> params = new HashMap<String, Object>();
                String num_secprove = prov.get("num_secprove").toString();
                params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
                params.put("NUM_SECPROVE", num_secprove);
                //jenciso Inicio - ceticos parte1 agregamos montos por cada proveedor
                Map<String,Object> listMontos = new HashMap<String, Object>();
                listMontos = (Map<String,Object>)prov.get("mapFormBMonto");
                if(CollectionUtils.isEmpty(listMontos)){
                    listMontos = this.formatoValorService.obtenerMontosFormBByDAV(declaracionActual.get("NUM_CORREDOC").toString(), num_secprove);
                    if(!CollectionUtils.isEmpty(listMontos)){
                        colocarLstMontosByDAV(declaracionActual,listMontos,num_secprove);
                    }
                }
                //jenciso Fin
                List<Map> lstFacturas = (List) prov.get("lstComproBPago");
                if (lstFacturas == null || lstFacturas.size() == 0)
                {
                    lstFacturas = this.formatoValorService.obtenerFacturasProveedor(params);
                    if (lstFacturas != null && lstFacturas.size() > 0)
                    {
                        colocarLstFacturas(declaracionActual, lstFacturas, num_secprove);
                    }
                }
                Map<String, Object> mapa = null;
                for (Map compPag : lstFacturas)
                {
                    String num_secfact = compPag.get("num_secfact").toString();
                    params.remove("NUM_SECITEM");
                    params.put("NUM_SECFACT", num_secfact);
                    List<Map<String, Object>> lstItemFactura = (ArrayList) compPag.get("lstItemFactura");
                    if (lstItemFactura == null)
                    {
                        Map<String, String> pkFact = new HashMap<String, String>();
                        pkFact.put("NUM_CORREDOC", params.get("NUM_CORREDOC").toString());
                        pkFact.put("NUM_SECPROVE", params.get("NUM_SECPROVE").toString());
                        pkFact.put("NUM_SECFACT", params.get("NUM_SECFACT").toString());
                        pkFact.put("caduana", declaracionActual.get("COD_ADUANA").toString());
                        //CUS 14.15
                        pkFact.put("incluirEliminados", "true");
                        //fin CUS 14.15
                        mapa = formatoValorService.obtenerFormatoBItem(pkFact);
                        lstItemFactura = (List<Map<String, Object>>) mapa.get("lstItemFactura");
                        colocarLstItemFacturas(declaracionActual, lstItemFactura, num_secprove, num_secfact);
                    }
                    //jenciso Inicio - se cargan las facturas sucesivas
                    List<Map<String,Object>> lstFactuSucesivas = (ArrayList<Map<String,Object>>)compPag.get("lstFactuSucesivas");
                    if(CollectionUtils.isEmpty(lstFactuSucesivas)){
                        lstFactuSucesivas = formatoValorService.selectFactuSuce(params);
                        if(!CollectionUtils.isEmpty(lstFactuSucesivas)){
                            colocarLstFactuSucesivas(declaracionActual, lstFactuSucesivas, num_secprove, num_secfact);
                        }
                    }
                    //jenciso Fin
                    ////****
                    if (!CollectionUtils.isEmpty(lstItemFactura))
                    {
                        for (Map mpItem : lstItemFactura)
                        {
                            String num_secItem = mpItem.get("NUM_SECITEM").toString();
                            params.put("NUM_SECITEM", num_secItem);
                            List lstSeriesItem = (ArrayList) mpItem.get("lstSeriesItem");
                            if (lstSeriesItem == null)
                            {
                                lstSeriesItem = serieService.obtenerSeriesItem(params);
                                colocarLstSerieItem(declaracionActual, lstSeriesItem, num_secprove, num_secfact, num_secItem);
                            }

                            //jenciso Inicio obtiene las descripciones minimas por ItemFactura
                            List<Map<String,Object>> lstDecrMinima = (ArrayList<Map<String,Object>>)mpItem.get("lstDecrMinima");
                            if(lstDecrMinima == null){
                                lstDecrMinima = formatoValorService.selectFormbItemDescri(params);
                                colocarLstDecrMinima(declaracionActual, lstDecrMinima, num_secprove, num_secfact, num_secItem);
                            }
                            //jenciso Fin
                            List<Map<String, Object>> lstReferenciaDuda = null;
                            lstReferenciaDuda = (List<Map<String, Object>>) mapa.get("lstReferenciaDuda");
                            if (lstReferenciaDuda != null && lstReferenciaDuda.size() > 0)
                            {
                                for (Map<String, Object> mapaReferencia : lstReferenciaDuda)
                                {
                                    // LA serie es la misma de la lista de items
                                    if (mpItem.get("NUM_SECITEM").toString().trim().equals(mapaReferencia.get("NUM_SECITEM").toString().trim()))
                                    {
                                        // No se posee lista de Series Item
                                        if (mpItem.get("lstReferenciaDuda") == null)
                                        {
                                            mpItem.put("lstReferenciaDuda", new ArrayList<Map<String, Object>>());
                                            ((List<Map<String, Object>>) mpItem.get("lstReferenciaDuda")).add(mapaReferencia);
                                        }
                                        else
                                        {
                                            ((List<Map<String, Object>>) mpItem.get("lstReferenciaDuda")).add(mapaReferencia);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    ///***
                }
            }
        }
        return declaracionActual;
    }
    private void colocarLstSerieItem(
            Map declaracion,
            List lstSerieItem,
            String num_secprove,
            String num_secfact,
            String num_secitem)
    {
        if (declaracion != null && declaracion.size() > 0)
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            String secFact;
            String sectItem;
            List lstSerieItemfactAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago)
                    {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact))
                        {
                            List<Map> lstItemfact = (ArrayList<Map>) comPago.get("lstItemFactura");
                            for (Map item : lstItemfact)
                            {
                                sectItem = item.get("NUM_SECITEM").toString().trim();
                                if (sectItem.equals(num_secitem))
                                {
                                    lstSerieItemfactAsig = Utilidades.copiarLista(lstSerieItem);
                                    item.put("lstSeriesItem", lstSerieItemfactAsig);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @author jenciso
     * Metodo que agrage la lista de descripciones minimas en el Objeto de la Declaracion
     * para un proveedor , factura e item correspondiente.
     * @param declaracion declaracion
     * @param lstDecrMinima lstDecrMinima
     * @param num_secprove num_secprove
     * @param num_secfact num_secfact
     * @param num_secitem num_secitem
     */
    private void colocarLstDecrMinima(Map declaracion, List lstDecrMinima,
                                      String num_secprove, String num_secfact, String num_secitem) {
        if (declaracion != null && declaracion.size() > 0) {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            String secFact;
            String sectItem;
            List lstDecriMinimaItemfactAsig = new ArrayList();
            for (Map prov : lstProve) {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove)) {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov
                            .get("lstComproBPago");
                    for (Map comPago : lstComproBPago) {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact)) {
                            List<Map> lstItemfact = (ArrayList<Map>) comPago
                                    .get("lstItemFactura");
                            for (Map item : lstItemfact) {
                                sectItem = item.get("NUM_SECITEM").toString()
                                        .trim();
                                if (sectItem.equals(num_secitem)) {
                                    lstDecriMinimaItemfactAsig = Utilidades
                                            .copiarLista(lstDecrMinima);
                                    item.put("lstDecrMinima",
                                            lstDecriMinimaItemfactAsig);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    private void colocarLstItemFacturas(Map declaracion, List lstItemFacturas, String num_secprove, String num_secfact)
    {
        if (declaracion != null && declaracion.size() > 0)
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            String secFact;
            List lstItemfactAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago)
                    {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact))
                        {
                            lstItemfactAsig = Utilidades.copiarLista(lstItemFacturas);
                            comPago.put("lstItemFactura", lstItemfactAsig);
                            break;
                        }
                    }
                }
            }
        }
    }
    private void colocarLstFacturas(Map declaracion, List lstFacturas, String num_secprove)
    {
        if (!CollectionUtils.isEmpty(declaracion))
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            List factAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    factAsig = Utilidades.copiarLista(lstFacturas);
                    prov.put("lstComproBPago", factAsig);
                    break;
                }
            }
        }
    }

    /**
     * Coloca los montos de un DAV en la declaracion
     * @author jenciso
     * @param declaracion
     * @param lstMontos
     * @param num_secprove
     */
    private void colocarLstMontosByDAV(Map declaracion, Map<String,Object> lstMontos, String num_secprove)
    {
        if (!CollectionUtils.isEmpty(declaracion))
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            Map<String,Object> factAsig = new HashMap<String, Object>();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    factAsig.putAll(lstMontos);
                    prov.put("mapFormBMonto", factAsig);
                    break;
                }
            }
        }
    }

    /**
     * Coloca las Facturas sucesivas en las Facturas de la declaracion
     * @author jenciso
     * @param declaracion
     * @param lstFactuSucesivas
     * @param num_secprove
     * @param num_secfact
     */
    private void colocarLstFactuSucesivas(Map declaracion, List<Map<String,Object>> lstFactuSucesivas, String num_secprove, String num_secfact){

        if (!CollectionUtils.isEmpty(declaracion)){
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            String secFact;
            List lstFactuSucesivasAsig = new ArrayList();
            for (Map prov : lstProve){

                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove)) {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago) {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact)) {
                            lstFactuSucesivasAsig = Utilidades.copiarLista((List)lstFactuSucesivas);
                            comPago.put("lstFactuSucesivas", lstFactuSucesivasAsig);
                            break;
                        }
                    }
                }
            }
        }
    }

    /** Remueve de la sesin los tems regitrados como eliminados en base de datos
     * @param mapCabDeclara
     * @param request
     */
    private void removerItemsEliminados(Map<String, Object> mapCabDeclara,HttpServletRequest request){


        if (mapCabDeclara != null && mapCabDeclara.size() > 0) {
            if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstFormBProveedor"))){
                for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor")){
                    if (!CollectionUtils.isEmpty((List) mapa.get("lstComproBPago"))){
                        for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapa.get("lstComproBPago")){
                            if(!CollectionUtils.isEmpty((List<Map<String, Object>>) mapaFactura.get("lstItemFactura"))){

                                List<Map<String,Object>> lstItemFactura = (List<Map<String, Object>>) mapaFactura.get("lstItemFactura");
                                for(int i = lstItemFactura.size() - 1; i >= 0; i--) {
                                    Map<String, Object> itemActual = lstItemFactura.get(i);

                                    String claveCampo = "ELIMINADO_PERMANENTE";

                                    if(itemActual.containsKey(claveCampo) && "BD".equals(itemActual.get(claveCampo))) {
                                        lstItemFactura.remove(i);
                                    }
                                }
                                Ordenador.sortDesc(lstItemFactura, "NUM_SECITEM", Ordenador.ASC);
                            }
                        }
                    }
                }
            }

        }

    }

    /** En caso la declaracin no tubiera cargados los Documentos Autorizantes, Asociados y Certificados de Origen, los busca en
     * base de datos y los agrega a la sessin de la declaracin
     * @param request
     */
    private void cargarDocumentosDeclaracion(HttpServletRequest request){

        Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, String> mapPk = new HashMap<String, String>();
        mapPk.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC").toString());
        mapPk.put("IND_DEL", "0");
        // Documentos Autorizantes, Asociados y Certificados de Origen
        if (CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")))
        {
            List<Map<String, Object>> listaDocAsoc = declaracionService.obtenerDocAutAsociados(mapPk);
            if (!CollectionUtils.isEmpty(listaDocAsoc))
            {
                mapCabDeclara.put("lstDocAutAsociado", Utilidades.copiarLista((List) listaDocAsoc));
                mapCabDeclaraActual.put("lstDocAutAsociado", listaDocAsoc);
            }
        }
        if (null == request.getSession().getAttribute("incrementalDocumentosAsociados"))
        {
            request.getSession().setAttribute(
                    "incrementalDocumentosAsociados",
                    declaracionService.obtenerMaxCorrelativoDocAutAsociado(mapPk));
        }
        if (CollectionUtils.isEmpty((List) mapCabDeclara.get("lstCabCertiOrigen")))
        {
            List<Map<String, Object>> listaCabCerti = declaracionService.obtenerCertOrigen(mapPk);
            if (!CollectionUtils.isEmpty(listaCabCerti))
            {
                mapCabDeclara.put("lstCabCertiOrigen", Utilidades.copiarLista((List) listaCabCerti));
                mapCabDeclaraActual.put("lstCabCertiOrigen", listaCabCerti);
            }
        }
        if (CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDetAutorizacion")))
        {
            List<Map<String, Object>> listaDetAut = serieService.obtenerDetAutorizacion(mapPk);
            if (!CollectionUtils.isEmpty(listaDetAut))
            {
                mapCabDeclara.put("lstDetAutorizacion", Utilidades.copiarLista((List) listaDetAut));
                mapCabDeclaraActual.put("lstDetAutorizacion", listaDetAut);
            }
        }
        WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
    }
}