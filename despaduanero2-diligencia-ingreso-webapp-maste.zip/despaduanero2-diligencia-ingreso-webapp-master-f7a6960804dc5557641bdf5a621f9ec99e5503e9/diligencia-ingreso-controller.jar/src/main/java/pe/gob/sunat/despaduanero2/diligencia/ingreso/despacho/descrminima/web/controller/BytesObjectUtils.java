package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.descrminima.web.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.commons.io.IOUtils;

/**
 * @author JcFR
 * 
 */
public class BytesObjectUtils {

	/**
	 * @author JcFR
	 * @param object
	 *            objeto a clonar
	 * @return el objecto clonado, o null si ocurrio algun error
	 */
	public static Object clone(Object object) {
		byte[] bytes = toBytes(object);
		return fromBytes(bytes);
	}

	/**
	 * @author JcFR
	 * @param object
	 *            objeto a serializar
	 * @return el arreglo de bytes del objecto serializado, o null si ocurrio
	 *         error
	 */
	public static byte[] toBytes(Object object) {

		if (object == null)
			return null;

		ByteArrayOutputStream bytesOut = null;
		ObjectOutputStream objectOut = null;

		try {

			bytesOut = new ByteArrayOutputStream();

			objectOut = new ObjectOutputStream(bytesOut);

			objectOut.writeObject(object);

			return bytesOut.toByteArray();

		} catch (Exception sos) {

			return null;

		} finally {

			IOUtils.closeQuietly(objectOut);
			IOUtils.closeQuietly(bytesOut);

		}

	}

	/**
	 * @author JcFR
	 * @param object
	 *            arreglo de bytes del objeto serializado
	 * @return el objeto serializado o null si ocurrio un error
	 */
	public static Object fromBytes(byte[] object) {

		if (object == null || object.length == 0)
			return null;

		ByteArrayInputStream bytesIn = null;
		ObjectInputStream objectIn = null;

		try {

			bytesIn = new ByteArrayInputStream(object);

			objectIn = new ObjectInputStream(bytesIn);

			return objectIn.readObject();

		} catch (Exception sos) {

			return null;

		} finally {

			IOUtils.closeQuietly(objectIn);
			IOUtils.closeQuietly(bytesIn);

		}

	}

}
