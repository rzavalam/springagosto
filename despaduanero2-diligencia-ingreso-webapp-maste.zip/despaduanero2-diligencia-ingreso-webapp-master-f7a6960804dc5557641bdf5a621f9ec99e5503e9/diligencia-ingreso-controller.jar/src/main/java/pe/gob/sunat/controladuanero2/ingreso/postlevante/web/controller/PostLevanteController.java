package pe.gob.sunat.controladuanero2.ingreso.postlevante.web.controller;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.web.bind.annotation.*;


import org.springframework.web.servlet.ModelAndView;

import org.springframework.web.util.WebUtils;
import pe.gob.sunat.controladuanero2.ingreso.postlevante.service.SolicitudPostLevanteService;
import pe.gob.sunat.controladuanero2.ingreso.postlevante.web.bean.*;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;

import pe.gob.sunat.despaduanero2.model.MotivoSolicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudPostLevante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;


import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;


import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * Created by amancillaa on 28/03/2016.
 */

@Controller
public class PostLevanteController {

    public static final String TIPO_MOTIVO_SOLICITUD = "564";
    public static final String MOTIVO_NECESITA_APROBACION_JEFE = "04";
    public static final String CATALOGO_565_ESTADO_GENERADO = "00";
    public static final String CATALOGO_565_ESTADO_APROBADO = "01";

    @Autowired
    private FabricaDeServicios fabricaDeServicios;

    @Autowired
    private SolicitudPostLevanteService solicitudPostLevanteService;

    private final Log logger = LogFactory.getLog(getClass());


    @RequestMapping(value = "/postlevante/solicitud", method = RequestMethod.GET)
    public ModelAndView cargarJSPParaGenerarSolicitud()
    {

        logger.info("---cargar JSP:SolicitudPostLevante.jsp---");
        return new ModelAndView("SolicitudPostLevante");
    }

    @RequestMapping(value = "/postlevante/aprobacion", method = RequestMethod.GET)
    public ModelAndView cargarJSPParaGenerarAprobacion()
    {

        logger.info("---cargar JSP:SolicitudPostLevante.jsp---");
        return new ModelAndView("AprobacionPostLevante");
    }

    @RequestMapping(value = "/postlevante/cargar_defaultdatosformbusquedadeclaracion", method = RequestMethod.GET)
    @ResponseBody
    public FormBusquedaDeclaracion cargarDefaultDatosFormBusquedaDeclaracion(@RequestParam(value = "codAduana", required = false) String codAduana,
                                                                             @RequestParam(value = "annPresen", required = false) String annPresen,
                                                                             @RequestParam(value = "codRegimen", required = false) String codRegimen,
                                                                             @RequestParam(value = "numDeclaracion", required = false) String numDeclaracion,
                                                                             HttpServletRequest request)  throws Exception
    {

        logger.info("---cargarDefaultDatosFormBusquedaDeclaracion---");

        FormBusquedaDeclaracion declaracion = new FormBusquedaDeclaracion();
        try
        {
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if(userSession!=null){
                userSession.setNroRegistro(userSession.getNroRegistro().trim());
                WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
            }else{
                declaracion.setMsjError("Usuario no logeado.");
            }

            //esta definido solo para regimen 10
            if(StringUtils.isNotEmpty(codRegimen)){

                if(!Constantes.COD_REGIMEN_IMPORTACION_CONSUMO.equals(codRegimen)){
                    declaracion.setMsjError("R\u00e9gimen:"+codRegimen+" No autorizado para Post-Levante.");
                }
            }

            if(StringUtils.isEmpty(declaracion.getMsjError())){

                if(StringUtils.isEmpty(codAduana)){
                    SoporteService soporteService = fabricaDeServicios.getService("diligencia.ingreso.soporteService");
                    codAduana = soporteService.obtenerAduana(request);
                }

				CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				List<Map<String, String>> aduanaDependencyList = catalogoAyudaService.getListaElementosAsoc("031", "C", codAduana);

                declaracion = new FormBusquedaDeclaracion(codAduana,annPresen,codRegimen,numDeclaracion, aduanaDependencyList);
            }
        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            declaracion.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }

        return declaracion;
    }

    @RequestMapping(value = "/postlevante/validar_solicitud", method = RequestMethod.POST)
    @ResponseBody
    public FormBusquedaDeclaracion validarFormBusquedaSolicitud(@RequestBody FormBusquedaDeclaracion form, HttpServletRequest request)
    {
        logger.info("---validarFormBusquedaSolicitud---");

        try {

            String msjValidacion = "";
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if (userSession != null) {

                ObjectResponseUtil rpta = solicitudPostLevanteService.validarDeclaracion(form.getCodAduana(), form.getAnnPresen(), form.getCodRegimen(), form.getNumDeclaracion(), userSession);

                if (!rpta.isRespuesta() && CollectionUtils.isNotEmpty(rpta.getMensajes())) {

                    msjValidacion = ((MensajeBean) rpta.getMensajes().get(0)).getMensajeerror();


                } else { // si no hay errores

                    Declaracion declaracion = (Declaracion) rpta.getDatos().get("declaracion");

                    FormSolicitudPostLevante formLevante = new FormSolicitudPostLevante();
                    formLevante.cargarDefaultaCodigos();
                    formLevante.setNumDeclaracion(form.getNumDeclaracion());
                    formLevante.setAnnPresen(form.getAnnPresen());
                    formLevante.setCodAduana(form.getCodAduana());
                    formLevante.setCodRegimen(form.getCodRegimen());

                    formLevante.setCodCanal(declaracion.getDua().getCodCanal());
                    formLevante.setCodEstado(declaracion.getDua().getCodEstdua());
                    formLevante.setCodModalidad(declaracion.getDua().getCodmodalidad());
                    formLevante.setFechaNumeracion(SunatDateUtils.getFormatDate(declaracion.getDua().getFecdeclaracion(), "dd/MM/yyyy"));
                    formLevante.setGarantia("Art.160D.Leg");
                    formLevante.setNumOrden(declaracion.getDua().getNumorden());

                    String ruc = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() != null ? declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() : "";
                    formLevante.setRuc(ruc);
                    if (StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDeclarante().getNombreRazonSocial()))) {
                        String tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
                        if (!StringUtils.isEmpty(StringUtils.trim(tipoDocumento)) && !StringUtils.isEmpty(StringUtils.trim(ruc))) {
                            OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaServicePrincipal");
                            Map<String, Object> mapImportador = operadorAyudaService.getDeclarante(ruc, tipoDocumento);
                            formLevante.setRazonSocial(mapImportador.get("nombre") != null ? (String) mapImportador.get("nombre") : "");
                        }
                    }

                    formLevante.setNumCorrelDeclaracion(declaracion.getDua().getNumcorredoc().toString());

                    SolicitudPostLevante solicitud = rpta.getDatos().get("solicitud") != null ? (SolicitudPostLevante) rpta.getDatos().get("solicitud") : null;
                    if (solicitud != null) {
                        formLevante.setNumCorrelSolicitud(solicitud.getNumeroCorrelativo().toString());
                        //se quita los espacios a fin de que la vista pueda reconocer cambios en el sustento
                        formLevante.setSustentoPostLevante(solicitud.getSustento().trim());

                        if (StringUtils.isNotEmpty(solicitud.getEstadoSolicitud())) {
                            if ("00".equals(solicitud.getEstadoSolicitud())) {
                                formLevante.setAccion("M"); //SE HABILITA BOTON MODIFICAR Y ELIMINAR
                            } else if ("01".equals(solicitud.getEstadoSolicitud()) || "02".equals(solicitud.getEstadoSolicitud())) {
                                formLevante.setAccion("R"); //CON RESULTADO NO SE MODIFICA NADA SOLO LO MUESTRO
                                String estado = "01".equals(solicitud.getEstadoSolicitud()) ? "APROBADO" : "RECHAZADO";
                                formLevante.setMsjError("Solicitud Post-Levante con estado: " + estado + " no es posible modificarlo.");
                            }
                           /* se filtra estado anulado 99 desde un inicio } else if ("99".equals(solicitud.getEstadoSolicitud())) { //anulado
                                formLevante.setAccion("N"); //NO EXISTE SOLICITUD puede generar otra
                            }*/
                        } else {
                            formLevante.setAccion("M"); //SE HABILITA BOTON MODIFICAR Y ELIMINAR
                        }

                        if (CollectionUtils.isNotEmpty(solicitud.getLsMotivos())) {
                            for (MotivoSolicitud motiSoli : solicitud.getLsMotivos()) {
                                for (FormMotivo frmMotivo : formLevante.getLstMotivos()) {
                                    if (frmMotivo.getCodigo().equals(motiSoli.getCodMotivo()) && "0".equals(motiSoli.getIndDel())) {
                                        frmMotivo.setChecked(true);
                                    }
                                }
                            }
                        }
                    } else {
                        formLevante.setAccion("N"); //NO EXISTE SOLICITUD
                    }

                    WebUtils.setSessionAttribute(request, "formSolicitudPostLevante", formLevante);
                }


            } else {
                msjValidacion = "Usuario no logeado.";
            }

            if (StringUtils.isNotEmpty(msjValidacion)) {
                form.setMsjError(msjValidacion);
            }

        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }
        return form;
    }


    @RequestMapping(value = "/postlevante/validar_aprobacion", method = RequestMethod.POST)
    @ResponseBody
    public FormBusquedaDeclaracion validarFormBusquedaAprobacion(@RequestBody FormBusquedaDeclaracion form, HttpServletRequest request)
    {
        logger.info("---validarFormBusquedaAprobacion---");

        try {

            String msjValidacion = "";
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if (userSession != null) {

                ObjectResponseUtil rpta = solicitudPostLevanteService.validarAprobacionSolicitud(form.getCodAduana(), form.getAnnPresen(), form.getCodRegimen(), form.getNumDeclaracion(), userSession);

                if (CollectionUtils.isNotEmpty(rpta.getMensajes())) {
                    msjValidacion = ((MensajeBean) rpta.getMensajes().get(0)).getMensajeerror();

                } else { // si no hay errores

                    Declaracion declaracion = (Declaracion) rpta.getDatos().get("declaracion");

                    FormSolicitudPostLevante formLevante = new FormSolicitudPostLevante();
                    formLevante.cargarDefaultaCodigos();
                    formLevante.setNumDeclaracion(form.getNumDeclaracion());
                    formLevante.setAnnPresen(form.getAnnPresen());
                    formLevante.setCodAduana(form.getCodAduana());
                    formLevante.setCodRegimen(form.getCodRegimen());

                    formLevante.setCodCanal(declaracion.getDua().getCodCanal());
                    formLevante.setCodEstado(declaracion.getDua().getCodEstdua());
                    formLevante.setCodModalidad(declaracion.getDua().getCodmodalidad());
                    formLevante.setFechaNumeracion(SunatDateUtils.getFormatDate(declaracion.getDua().getFecdeclaracion(), "dd/MM/yyyy"));
                    formLevante.setGarantia("Art.160D.Leg");
                    formLevante.setNumOrden(declaracion.getDua().getNumorden());

                    String ruc = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() != null ? declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() : "";
                    formLevante.setRuc(ruc);
                    if (StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDeclarante().getNombreRazonSocial()))) {
                        String tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
                        if (!StringUtils.isEmpty(StringUtils.trim(tipoDocumento)) && !StringUtils.isEmpty(StringUtils.trim(ruc))) {
                            OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaServicePrincipal");
                            Map<String, Object> mapImportador = operadorAyudaService.getDeclarante(ruc, tipoDocumento);
                            formLevante.setRazonSocial(mapImportador.get("nombre") != null ? (String) mapImportador.get("nombre") : "");
                        }
                    }

                    formLevante.setNumCorrelDeclaracion(declaracion.getDua().getNumcorredoc().toString());

                    SolicitudPostLevante solicitud = rpta.getDatos().get("solicitud") != null ? (SolicitudPostLevante) rpta.getDatos().get("solicitud") : null;
                    if (solicitud != null) {
                        formLevante.setNumCorrelSolicitud(solicitud.getNumeroCorrelativo().toString());
                        formLevante.setSustentoPostLevante(solicitud.getSustento());

                        if (CollectionUtils.isNotEmpty(solicitud.getLsMotivos())) {
                            for (MotivoSolicitud motiSoli : solicitud.getLsMotivos()) {
                                for (FormMotivo frmMotivo : formLevante.getLstMotivos()) {
                                    if (frmMotivo.getCodigo().equals(motiSoli.getCodMotivo()) && "0".equals(motiSoli.getIndDel())) {
                                        frmMotivo.setChecked(true);
                                    }
                                }
                            }
                        }
                    }

                    WebUtils.setSessionAttribute(request, "formSolicitudPostLevante", formLevante);
                }

            } else {
                msjValidacion = "Usuario no logeado.";
            }

            if (StringUtils.isNotEmpty(msjValidacion)) {
                form.setMsjError(msjValidacion);
            }

        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }
        return form;
    }

    @RequestMapping(value = "/postlevante/cargar_datosformsolicitudpostlevante", method = RequestMethod.GET)
    @ResponseBody
    public FormSolicitudPostLevante cargarDatosFormSolicitudPostLevante(HttpServletRequest request)  throws Exception
    {

        logger.info("---cargarDatosFormSolicitudPostLevante---");
        FormSolicitudPostLevante form = new FormSolicitudPostLevante();

        try
        {
            form = (FormSolicitudPostLevante) WebUtils.getSessionAttribute(request, "formSolicitudPostLevante");
            if(form==null){
                form.setMsjError("Usuario no logeado.");
            }
        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }

        return form;
    }


    @RequestMapping(value = "/postlevante/grabar_solicitudpostlevante", method = RequestMethod.POST)
    @ResponseBody
    public FormSolicitudPostLevante grabarSolicitudPostLevante(@RequestBody FormSolicitudPostLevante form, HttpServletRequest request)
    {
        logger.info("---garbarSolicitudPostLevante---");
        try{

            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro());

            if("N".equals(form.getAccion()) || StringUtils.isEmpty(form.getNumCorrelSolicitud())){

                SolicitudPostLevante solicitud = new SolicitudPostLevante();
                solicitud.setCodAduana(form.getCodAduana());
                solicitud.setAnnoSolicitud(new Integer(form.getAnnPresen()));
                solicitud.setNumeroCorrelativo(new Long(form.getNumCorrelDeclaracion())); //se le envia el numcorredo declar
                solicitud.setSustento(form.getSustentoPostLevante());

                List<MotivoSolicitud> lsMotivos = new ArrayList<MotivoSolicitud>();
                MotivoSolicitud motivo;
                for(FormMotivo frmMotivo: form.getLstMotivos()){
                    //que inserte por defecto los 4
                    //if(frmMotivo.isChecked()){
                        motivo = new MotivoSolicitud();
                        motivo.setCodMotivo(frmMotivo.getCodigo());
                        motivo.setCodCatalogoDelMotivo(TIPO_MOTIVO_SOLICITUD);
                        motivo.setIndDel(frmMotivo.isChecked()?"0":"1");
                        lsMotivos.add(motivo);
                    //}

                    if("03".equals(frmMotivo.getCodigo()) && frmMotivo.isChecked()){
                        if(noTienePECO(form)){
                            form.setMsjError("Declaraci\u00f3n no corresponde a PECO-Amazon\u00eda.");
                            return form;
                        }
                    }
                }
                solicitud.setLsMotivos(lsMotivos);
                solicitud.setSustento(form.getSustentoPostLevante());
                solicitud.setRegimen(form.getCodRegimen()); //post levante es solo para 10
                solicitud.setNumeroDiligencia(new Integer(form.getNumDeclaracion()));  //se reusa este campo para enviar num_declaracion
                solicitudPostLevanteService.insertarSolicitud(solicitud);

            }else if("M".equals(form.getAccion())){

                SolicitudPostLevante solicitud = new SolicitudPostLevante();
                solicitud.setNumeroCorrelativo(new Long(form.getNumCorrelSolicitud()));
                solicitud.setSustento(form.getSustentoPostLevante());

                List<MotivoSolicitud> lsMotivos = new ArrayList<MotivoSolicitud>();
                MotivoSolicitud motivo;

                for(FormMotivo frmMotivo: form.getLstMotivos()){
                    motivo = new MotivoSolicitud();
                    motivo.setCodMotivo(frmMotivo.getCodigo());
                    motivo.setCodCatalogoDelMotivo(TIPO_MOTIVO_SOLICITUD);
                    motivo.setNumCorrelativo(new Long(form.getNumCorrelSolicitud()));
                    motivo.setIndDel(frmMotivo.isChecked()?"0":"1");
                    lsMotivos.add(motivo);
                    if("03".equals(frmMotivo.getCodigo()) && frmMotivo.isChecked()){
                        if(noTienePECO(form)){
                            form.setMsjError("Declaraci\u00f3n no corresponde a PECO-Amazon\u00eda.");
                            return form;
                        }
                    }
                }
                solicitud.setLsMotivos(lsMotivos);
                solicitud.setSustento(form.getSustentoPostLevante());
                solicitudPostLevanteService.modificarSolicitud(solicitud);

            }else if("E".equals(form.getAccion())){

                SolicitudPostLevante solicitud = new SolicitudPostLevante();
                solicitud.setNumeroCorrelativo(new Long(form.getNumCorrelSolicitud()));
                solicitud.setIndDel("1");
                solicitudPostLevanteService.eliminarSolicitud(solicitud);
            }

        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }
        return form;
    }

    private boolean noTienePECO(FormSolicitudPostLevante form) {

        return !solicitudPostLevanteService.tienePECO(new Long(form.getNumCorrelDeclaracion()));
    }


    @RequestMapping(value = "/postlevante/aceptar_solicitudpostlevante", method = RequestMethod.POST)
    @ResponseBody
    public FormSolicitudPostLevante aceptarSolicitudPostLevante(@RequestBody FormSolicitudPostLevante form, HttpServletRequest request)
    {
        logger.info("---aceptarSolicitudPostLevante---");
        try{

            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro());

            SolicitudPostLevante solicitud = new SolicitudPostLevante();
            solicitud.setNumeroCorrelativo(new Long(form.getNumCorrelSolicitud()));
            solicitudPostLevanteService.aceptarSolicitud(solicitud);
        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }
        return form;
    }


    @RequestMapping(value = "/postlevante/rechazar_solicitudpostlevante", method = RequestMethod.POST)
    @ResponseBody
    public FormSolicitudPostLevante rechazarSolicitudPostLevante(@RequestBody FormSolicitudPostLevante form, HttpServletRequest request)
    {
        logger.info("---aceptarSolicitudPostLevante---");
        try{

            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro());

            SolicitudPostLevante solicitud = new SolicitudPostLevante();
            solicitud.setNumeroCorrelativo(new Long(form.getNumCorrelSolicitud()));
            solicitudPostLevanteService.rechazarSolicitud(solicitud);
        }catch (Exception e){
            logger.error("***********ERROR**************",e);
            form.setMsjError("Ocurrio un error en la aplicaci\u00f3n.");
        }
        return form;
    }

}

