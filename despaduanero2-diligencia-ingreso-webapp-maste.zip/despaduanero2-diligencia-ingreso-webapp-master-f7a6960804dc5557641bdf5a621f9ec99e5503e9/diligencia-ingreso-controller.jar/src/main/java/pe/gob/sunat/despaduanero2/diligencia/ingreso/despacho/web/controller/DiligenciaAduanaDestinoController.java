package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.IncidenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.VehiCeticoService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;//PAS20181U220200054

/**
 * <p>
 * Titulo: Controlador que agrupa las consultas de cualquier tipo de diligencia
 * </p>
 * <p>
 * Descripcion: Controlador que administra las consultas para Fomato A y Formato
 * B
 * </p>
 *
 * @author rmontes,rdelosreyes,wmostacero,lsuclupe,tomas,scallata
 * @since 08-sep-09
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DiligenciaAduanaDestinoController extends AbstractDespachoController
{


  private FormatoValorService       formatoValorService;

  private DeclaracionService        declaracionService;

  private SoporteService            soporteService;

  private SolicitudService          solicitudService;

  FabricaDeServicios                fabricaDeServicios;

  private LiquidaDeclaracionService liquidaDeclaracionService;

  private RectificacionService      rectificacionService;

  private IncidenciaService         incidenciaService;

  private DeudaService deudaService;

  private SerieService                    serieService;
  
  /* olunar - 309 */
  private ConsultaService consultaService;
  /* fin */
  
  private VehiCeticoService   	vehiCeticoService;//jenciso

  /**
   * Metodo que nos permite obtener los Items de una Serie.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cargarConsultaDVItem(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);

    List<Map<String, Object>> listaItems = null;
    Map<String, String> PkSerie = new HashMap<String, String>();
    String numCorreDocConsultado = webRequest.getParameter("hdn_num_corredoc")!=null?webRequest.getParameter("hdn_num_corredoc"):"";
    try
    {
    
      Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclara");
      
      if(SunatStringUtils.isEmpty(numCorreDocConsultado) || "undefined".equals(numCorreDocConsultado))
      {
        numCorreDocConsultado = mapCabDeclara.get("NUM_CORREDOC").toString();
      }

      PkSerie.put("NUM_CORREDOC", numCorreDocConsultado);
      PkSerie.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));

      // para los casos de series agregadas que estan en memoria

      Map<String, String> mapNuevaSerieSerieBase = (Map<String, String>) WebUtils.getSessionAttribute(
          request,
            "mapNuevaSerieSerieBase");
      if (mapNuevaSerieSerieBase != null && mapNuevaSerieSerieBase.size() > 0)
      {
        String serieBase = mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) != null ? mapNuevaSerieSerieBase
            .get((String) webRequest.getParameter("hdn_num_secserie")) : "";
        if (!serieBase.equals(""))
        {
          PkSerie.put("NUM_SECSERIE", serieBase);
        }
      }

      listaItems = formatoValorService.obtenerFVItem(PkSerie);
      
      listaItems = this.colocarEstadoItem(listaItems, mapCabDeclara);
      
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }


    ModelAndView view = new ModelAndView("consultaDVItem", "listaItems", SojoUtil.toJson(listaItems));
    view.addObject("datamodel", listaItems);

    view.addObject("hdn_num_corredoc", numCorreDocConsultado);
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));
    return view;
  }

  /**
   * Metodo que nos permite obtener las Diligencias de un documento exacto es
   * invocado tambien desde la consulta de la DUA y diligencia de despacho.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cargarConsultaIntervenciones(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);

    List<Map<String, Object>> listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal = null;
    List<Map<String, Object>> listDiligenciasConSustentoModificado = null;
    Map PkDocu = new HashMap<String, String>();
	/* olunar - 309 */
	boolean tieneSolReconFisico = false;
	/* fin */
    try
    {
      PkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      // mostar las diligencias de revision
      PkDocu.put("viewRevision", "false");
      PkDocu.put("agrupaTipoDiligencia", "S");

      listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal = diligenciaService.obtenerDiligencias(PkDocu);

      //PkDocu.remove("agrupaTipoDiligencia");
      listDiligenciasConSustentoModificado = diligenciaService.obtenerDiligenciaDespachoSustentoModificado(PkDocu);
      /* olunar - 309 Verificar que existe solicitud de reconocimiento f�sico */
      Consulta filtroConsulta = new Consulta();
	  filtroConsulta.setNumcorredoc(new Long(PkDocu.get("NUM_CORREDOC").toString()));
	  filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
	  // Consultas aprobadas
	  filtroConsulta.setIndicadorRespuesta("1");
	  ArrayList<Consulta> listaSolReconFisico = (ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta);
	  // Consultas rechazadas
	  filtroConsulta.setIndicadorRespuesta("0");
	  listaSolReconFisico.addAll((ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta));
	  if(!CollectionUtils.isEmpty(listaSolReconFisico))
	  tieneSolReconFisico = true;			
	  /* fin */
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }

    String array = SojoUtil.toJson(listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal);
    String diligenciaTotal = SojoUtil.toJson(listDiligenciasConSustentoModificado);
    ModelAndView view = new ModelAndView("ConsultaIntervenciones", "intervenciones", array);
	// Datos de formulario
	/* olunar - 309 */
	view.addObject("tieneSolReconFisico", new Boolean(tieneSolReconFisico));
	/* fin */
    view.addObject("diligenciaTotal", diligenciaTotal);
    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;

  }

  /**
   * Metodo que nos permite obtener las Incidencias de una determinada
   * Diligencia.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView obtenerIncidencias(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map PkDili = new HashMap<String, String>();

    try
    {
      PkDili.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      PkDili.put("COD_TIPDILIGENCIA", webRequest.getParameter("hdn_cod_tipdiligencia"));
      listado = incidenciaService.obtenerIncidencias(PkDili);
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    return new ModelAndView(this.jsonView, "datamodel", listado);
  }

  /**
   * Metodo que nos permite recibir los datos de los proveedores y numero de
   * facturas por DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaFormatoValor(HttpServletRequest request, HttpServletResponse response)
  {

    List<Map<String, Object>> listado = null;
    Map PkDocu = new HashMap<String, String>();
    Map<String, Object> mapCabDeclara = new HashMap<String, Object>();
    try
    {
      String hdn_acceso = ObjectUtils.toString(request.getParameter("hdn_acceso"), "");
      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
      PkDocu.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
      if (hdn_acceso.equals("00"))
      {
        PkDocu.put("IND_DEL", "0");
      }
      listado = formatoValorService.obtenerFVProveedores(PkDocu);

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("ConsultaFormatoValor", "proveedor", SojoUtil.toJson(listado));

    view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
    view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
    view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
    view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
    view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
    view.addObject("hdn_cod_estdua", mapCabDeclara.get("COD_ESTDUA").toString());
    return view;
  }

  /**
   * Metodo que nos permite recibir los items de las factura de un proveedor de
   * una determinada DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarFVFacturas(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkFactu = new HashMap<String, String>();
    try
    {
      pkFactu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkFactu.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      listado = formatoValorService.obtenerFVFacturas(pkFactu);
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }

    return new ModelAndView(this.jsonView, "datamodel", listado);
  }

  /**
   * Metodo que nos permite oibtener el detalle de Formato de Valor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarDetFormatoValor(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapDetFormatoValor = new HashMap<String, Object>();
    Map pkSerie = new HashMap<String, String>();
    try
    {
      pkSerie.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkSerie.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      pkSerie.put("NUM_FACTURA", webRequest.getParameter("hdn_num_factura"));
      pkSerie.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
      pkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));

      mapDetFormatoValor = formatoValorService.obtenerFVDetalle(pkSerie);
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("destino/DetFormatoValor", "mapDetDeclaracionValor",
        SojoUtil.toJson(mapDetFormatoValor));
    view.addAllObjects(mapDetFormatoValor);
    view.addObject(mapDetFormatoValor);
    view.addObject("series", SojoUtil.toJson(mapDetFormatoValor.get("listSeries")));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secitem", webRequest.getParameter("hdn_num_secitem"));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
    view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
    view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));

    return view;
  }

  /**
   * Metodo que permite obtener los riesgos de la declaracion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaRiesgo(HttpServletRequest request, HttpServletResponse response)
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listaEventos = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaHerraFraudSeries = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaCanalesEvento = new ArrayList<Map<String, Object>>();
    Map pkDocu = new HashMap<String, String>();
    Map<String, Object> mapResultado = new HashMap<String, Object>();

    MensajeBean rBean = null;
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkDocu.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
      pkDocu.put("ANN_DECLARA", webRequest.getParameter("hdn_ann_presen"));
      pkDocu.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
      pkDocu.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
      pkDocu.put(
          "COD_CANAL",
            webRequest.getParameter("hdn_cod_canal") != null ? webRequest.getParameter("hdn_cod_canal") : "");
      pkDocu.put(
          "COD_MOTIVOCANALASIG",
            webRequest.getParameter("hdn_cod_motivocanalasig") != null ? webRequest
                .getParameter("hdn_cod_motivocanalasig") : "");
      pkDocu.put(
          "COD_CANAL_DESC",
            webRequest.getParameter("hdn_cod_canal_desc") != null ? webRequest.getParameter("hdn_cod_canal_desc") : "");
      mapResultado = declaracionService.obtenerRiesgos(pkDocu);
      listaEventos = (ArrayList<Map<String, Object>>) mapResultado.get("listaEventos");
      listaHerraFraudSeries = (ArrayList<Map<String, Object>>) mapResultado.get("listaHerraFraudSeries");
      listaCanalesEvento = (ArrayList<Map<String, Object>>) mapResultado.get("listaCanalesEvento");

    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaRiesgo");
    // DATOS DE LA DECLARACION PARA MOSTRAR EL CANAL
    view.addObject("listaEventos", SojoUtil.toJson(listaEventos));
    view.addObject("listaHerraFraudSeries", SojoUtil.toJson(listaHerraFraudSeries));
    view.addObject("listaCanalesEvento", SojoUtil.toJson(listaCanalesEvento));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;
  }

  /**
   * Metodo que nos permite obtener los documentos de referencia de una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaDocRef(HttpServletRequest request, HttpServletResponse response)
  {

    List<Map<String, Object>> listadoDocumentos = null;
    Map<String, Object> pkDecla = new HashMap<String, Object>();
    MensajeBean rBean = null;
    ServletWebRequest webRequest = new ServletWebRequest(request);

    try
    {
      pkDecla.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
      pkDecla.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
      pkDecla.put("NUM_DECLARACION", SunatStringUtils.lpad(webRequest.getParameter("hdn_num_declaracion"), 6, '0'));
      pkDecla.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
     // pkDecla.put("caduana", soporteService.obtenerAduana(request));
      
      pkDecla.put("caduana", webRequest.getParameter("hdn_cod_aduana"));
      
      listadoDocumentos = soporteService.obtenerDocRef(pkDecla);
      if (CollectionUtils.isEmpty(listadoDocumentos))
      {
        rBean = new MensajeBean();
        rBean.setMensajeerror("No se encontraron datos de documentos de referencia.");
        rBean.setMensajesol("");
        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("consultaDocRef", "documentos", SojoUtil.toJson(listadoDocumentos));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));

    return view;
  }

  /**
   * Metodo que permite consultar la ultima reliquidacion de la DUA ya sea en el
   * proceso de numeracion, recticaciones, regularizaciones, diligencias.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView 2 opciones: si es correcto:
   *         ConsultaUltimaLiquidacion.jsp si hay error : PagM.jsp
   */
  public ModelAndView cargarConsultaUltimaLiquidacion(HttpServletRequest request, HttpServletResponse response)
  {

    try
    {

      MovCabliqdilig movCabliqdiligRspta = new MovCabliqdilig();

      MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
      List<MovCabliqdilig> lstMovCabliqdilig = new ArrayList<MovCabliqdilig>();
      ModelAndView view = new ModelAndView("ConsultaUltimaLiquidacion");
      String codTipdiligencia = "";
      String codTipLiqui = "";

      String[] regimen1070 = new String[]
      { "10", "70" };
      String[] tipoMonentoAutomatico = new String[]
      { "02", "03" };

      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", -1);

      Map<String, Object> declaracion = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      String numCorreDoc = SunatStringUtils.toStringObj(declaracion.get("NUM_CORREDOC"));

      tmpMovCabliqdilig.setAnnDocliq(declaracion.get("ANN_PRESEN").toString());
      tmpMovCabliqdilig.setAnnOrden(declaracion.get("ANN_ORDEN").toString());
      tmpMovCabliqdilig.setCodAduDocliq(declaracion.get("COD_ADUANA").toString());
      tmpMovCabliqdilig.setCodRegDocliq(declaracion.get("COD_REGIMEN").toString());
      String lcNum_Declaracion = Cadena.padLeft(declaracion.get("NUM_DECLARACION").toString().trim(), 6, '0');
      tmpMovCabliqdilig.setNumDocliq(lcNum_Declaracion);
      tmpMovCabliqdilig.setNumOrden(declaracion.get("NUM_ORDEN").toString());


      lstMovCabliqdilig = liquidaDeclaracionService.obtenerMontosCalculadosDeLaLiquidacion(
          tmpMovCabliqdilig,
            numCorreDoc);
      // sabemos que devuelve en forma descendente
      for (MovCabliqdilig movCabliqdilig : lstMovCabliqdilig)
      {
        // obtenego los datos
        codTipdiligencia = movCabliqdilig.getCodTipdiligencia();
        codTipLiqui = movCabliqdilig.getCodTipLiqui();

        // este codigo esta por demas pq en el JSP solo invoca para reg20 y 21
        if (Arrays.asList(regimen1070).contains(declaracion.get("COD_REGIMEN").toString()))
        {
          // buscamos en deuda_docum si encontramos registro entonces mostramos
          // quiere decir que el recalculo fue para menos entonces mostramos
          // ceros
          if (!deudaService.tieneMontosLiquidadosParaDiligencia(numCorreDoc, movCabliqdilig))
          {
            // seteamos cero los valores
            movCabliqdilig = new MovCabliqdilig();
          }
        }

        if (Arrays.asList(tipoMonentoAutomatico).contains(codTipLiqui))
        {
          // debo verificar si la regu y la recti han sido grabadas

          if (!rectificacionService.rectificacionTieneResultado(numCorreDoc, codTipLiqui))
          {
            continue;
          }
        }

        // 04 RELIQUIDACION ( R )
        if ("04".equals(codTipLiqui))
        {
          continue;
        }
        movCabliqdiligRspta = movCabliqdilig;
        break;
      }

      StringBuilder sbMomentoLiquidacion = new StringBuilder();
      if ("01".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("NUMERACION");
      }
      else if ("02".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("RECTIFICACION-AUTOMATICA");
      }
      else if ("03".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("REGULARIZACION-AUTOMATICA");
      }
      else if ("05".equals(codTipLiqui))
      {// diligencias cat 375

        sbMomentoLiquidacion.append("DILIGENCIA - ");
        sbMomentoLiquidacion.append(catalogoAyudaService
            .getDescripcionDataCatalogo("356", codTipdiligencia)
            .toUpperCase());
      }

      view.addObject("movCabliqdilig", movCabliqdiligRspta);
      view.addObject("hdn_cod_aduana", declaracion.get("COD_ADUANA"));
      view.addObject("hdn_ann_presen", declaracion.get("ANN_PRESEN").toString());
      view.addObject("hdn_cod_regimen", declaracion.get("COD_REGIMEN"));
      view.addObject("hdn_num_declaracion", Cadena.padLeft(declaracion.get("NUM_DECLARACION").toString(), 6, '0'));
      view.addObject("codTipdiligencia", codTipdiligencia);
      view.addObject("momentoLiquidacion", sbMomentoLiquidacion.toString());

      return view;

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror("Error en la obtencion de la consulta.");
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
  }

  /**
   * Metodo que permite consultar los tributos de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaTributoCargo(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    MensajeBean rBean = null;
    Map<String, Object> mapDetalleDeuda = null;
    Map<String, String> pkDocu = new HashMap<String, String>();
    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
    try
    {

      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      mapDetalleDeuda = deudaService.obtenerDeudaTributaria(pkDocu);
      listaTipoDeuda = getListTipoDeuda(mapDetalleDeuda);
      List<Map<String, Object>> lstTributos = (List<Map<String, Object>>) mapDetalleDeuda.get("listaTributos");
      if (CollectionUtils.isEmpty(lstTributos) || CollectionUtils.isEmpty(listaTipoDeuda))
      {
        rBean = new MensajeBean();
        rBean.setMensajeerror("No se encontraron tributos para la Serie.");
        rBean.setMensajesol("");
        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaTributoCargo", "deudaDocumento", SojoUtil.toJson(mapDetalleDeuda));
    view.addObject("listaTipoDeuda", listaTipoDeuda);

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;
  }

  /**
   * Metodo que nos permite obtener los tipos de deudas filtradas.
   *
   * @param mapa
   *          the mapa
   * @return the list tipo deuda
   */
  private ArrayList<Map<String, String>> getListTipoDeuda(Map<String, Object> mapa)
  {
    List<Map<String, Object>> listaTributos = (ArrayList<Map<String, Object>>) mapa.get("listaTributos");
    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
    boolean banderaComparaTipoDeuda = false;
    for (int i = 0; i < listaTributos.size(); i++)
    {
      // no mostrar deudas de tipo 02 LC
      if (!((String) listaTributos.get(i).get("cod_tipdeuda")).equals("02"))
      {
        if (i == 0)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
          continue;
        }
        banderaComparaTipoDeuda = true;
        for (int j = 0; j < listaTipoDeuda.size(); j++)
        {
          if (listaTipoDeuda.get(j).get("cod_tipdeuda").equals((String) listaTributos.get(i).get("cod_tipdeuda")))
          {
            banderaComparaTipoDeuda = false;
            break;
          }
        }
        if (banderaComparaTipoDeuda)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
        }
      }
    }
    return listaTipoDeuda;
  }

  /**
   * Metodo que permite mostrar la consulta del Manifiesto y su detalle de una
   * determinada DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
	public ModelAndView cargarConsultaManifiesto(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)request.getSession().getAttribute("mapCabDeclaraActual");
    List<Map<String, Object>> listado = null;
    ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		Manifiesto manifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(mapCabDeclaraActual.get("COD_TIPMANIFIESTO").toString(),
          mapCabDeclaraActual.get("COD_VIATRANS").toString(),
          mapCabDeclaraActual.get("COD_ADUAMANIFIESTO").toString(),
          ((BigDecimal) mapCabDeclaraActual.get("ANN_MANIFIESTO")).intValue(),
				mapCabDeclaraActual.get("NUM_MANIFIESTO").toString(),true);
		if(manifiesto!=null) {
			Map<String, Object> pkDocu = new HashMap<String, Object>();
      pkDocu.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC").toString());
			//listado = declaracionService.obtenerDatado(pkDocu);
			listado = declaracionService.obtenerDatado(pkDocu, manifiesto);
		}else {
      MensajeBean rBean = null;
      rBean = new MensajeBean();
      rBean.setMensajeerror("No se encontraron datos del Manifiesto.");
      rBean.setMensajesol("");
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("ConsultaManifiesto", "datado", SojoUtil.toJson(listado));
    view.addObject("mapCabDeclaraActual", mapCabDeclaraActual);
    view.addObject("manifiesto", manifiesto);

    mapCabDeclaraActual = null;
    return view;
  }



  /**
   * Permite ver la consulta de los contenedores asociados a una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaContenedores(HttpServletRequest request, HttpServletResponse response)
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkDocu = new HashMap<String, String>();
    MensajeBean rBean = null;
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      listado = declaracionService.obtenerContenedores(pkDocu);
      if (CollectionUtils.isEmpty(listado))
      {
        rBean = new MensajeBean();
        rBean.setMensajeerror("No se encontraron datos de contenedores asociados.");
        rBean.setMensajesol("");
        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaContenedor", "contenedor", SojoUtil.toJson(listado));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;
  }

  /**
   * Metodo que obtiene los documentos asociados y autorizantes segun sea la
   * invocacion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaDocAutorizaSerie(HttpServletRequest request, HttpServletResponse response)
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);


    String acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

    List<Map<String, Object>> listado2 = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listadoDocAsociado = null;
    List<Map<String, Object>> listadoDetAutorizacion = null;

    // para deshabilitar boton de grabado del JSP
    Boolean banderaEdicion = false;
    boolean banderaExiste = false;
    String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? (String) WebUtils
        .getSessionAttribute(request, "tipoDiligencia") : "";
    String serieSeleccionada = webRequest.getParameter("hdn_num_secserie") != null ? (String) webRequest
        .getParameter("hdn_num_secserie") : "";

    // datos de la session
    Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
    Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
    List<Map<String, Object>> lstDetDeclaraAnt = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
        request,
          "lstDetDeclaraActual");

    String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();

    if (!SunatStringUtils.isEmpty((String) mapCabDeclara.get("COD_ESTDUA"))
        && (webRequest.getParameter("banderaEdicion") != null ? Boolean.valueOf(webRequest.getParameter(
            "banderaEdicion").toString()) : false))
    {
      // comparamos con tipo de diligencia 01 y 04, segun catalogo 356
      if (!("01".equals(tipoDiligencia) && "04".equals(tipoDiligencia)))
      {
        banderaEdicion = true;
      }
    }

    // obtenemos los datos
    if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")))
    {
      listadoDocAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
      listadoDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
    }
    else
    { // obtenemos de la BD

      Map<String, String> pkDocu = new HashMap<String, String>();
      pkDocu.put("NUM_CORREDOC", numCorreDoc);

      // Para consulta por SERIE.
      if (!SunatStringUtils.isEmpty(serieSeleccionada))
      {
        pkDocu.put("NUM_SECSERIE", serieSeleccionada);
        pkDocu.put("fortipoopedif", "1");// activar diferencia
        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
      }
      else
      { // consulta por DUA
        pkDocu.put("fortipoopedif", "1");// activar diferencia
        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
      }
      // jala solo los activos
      pkDocu.put("IND_DEL", "0");

      Map<String, Object> mapDatos = solicitudService.obtenerDocAutoriza(pkDocu);

      listadoDocAsociado = (List<Map<String, Object>>) mapDatos.get("lstDocAutAsociado");
      listadoDetAutorizacion = (List<Map<String, Object>>) mapDatos.get("lstDetAutorizacion");
      // ponemos en session los datos de la BD a session como datos ant
      mapCabDeclaraAnt.put("lstDocAutAsociado", Utilidades.copiarLista((List) listadoDocAsociado));
      mapCabDeclaraAnt.put("lstDetAutorizacion", Utilidades.copiarLista((List) listadoDetAutorizacion));
      request.getSession().setAttribute("mapCabDeclara", mapCabDeclaraAnt);
    }

    // Si tenemos series nuevas recogemos sus docautorizantes
    if (!SunatStringUtils.isEmpty(serieSeleccionada))
    { // consulta por serie
      // Agregado los documentos autorizantes de Series con estado
      // IND_TIPO_REGISTRO = '1'
      Map key = new HashMap();
      key.put("NUM_CORREDOC", numCorreDoc);
      key.put("NUM_SECSERIE", serieSeleccionada);
      Map<String, Object> mapDetDeclaraSerieSeleccionada = Utilidades.obtenerElemento(lstDetDeclaraAnt, key);

      // si la serie seleccionada esta eliminada //ESTADO_REGISTRO 0 REGISTRADO
      // EN BD, 1 PENDIENTE DE REGISTRO EN BD
      if (!CollectionUtils.isEmpty(mapDetDeclaraSerieSeleccionada)
          && SunatStringUtils.isEmpty((String) mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO"))
          && "1".equals(mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO").toString()))
      {

        List<Map<String, Object>> listaAdicional = (List<Map<String, Object>>) mapDetDeclaraSerieSeleccionada
            .get("lstDetAutorizacion");

        listaAdicional = (listaAdicional != null) ? listaAdicional : new ArrayList<Map<String, Object>>();
        listadoDetAutorizacion.addAll(Utilidades.copiarLista((List) listaAdicional));

      }

      for (Map<String, Object> mapa1 : listadoDetAutorizacion)
      {
        if (serieSeleccionada.equals(mapa1.get("NUM_SECSERIE").toString().trim()))
        {
          for (Map<String, Object> mapa2 : listadoDocAsociado)
          {
            banderaExiste = false;
            if (mapa1.get("NUM_SECDOC").toString().trim().equals(mapa2.get("NUM_SECDOC").toString().trim())
                && mapa1.get("COD_TIPOPER").toString().trim().equals(mapa2.get("COD_TIPOPER").toString().trim())
                && !mapa1.get("COD_TIPOPER").toString().trim().equals("C"))
            {
              for (Map<String, Object> mapa3 : listado2)
              {
                if (mapa2.get("NUM_SECDOC").toString().trim().equals(mapa3.get("NUM_SECDOC").toString().trim())
                    && mapa2.get("COD_TIPOPER").toString().trim().equals(mapa3.get("COD_TIPOPER").toString().trim()))
                {
                  banderaExiste = true;
                  break;
                }
              }
              if (!banderaExiste && "0".equals(mapa2.get("IND_DEL")))
              {
                listado2.add(mapa2);
              }
            }
          }
        }
      }

    }
    else
    { // para consulta por DUA
      for (Map mapa : listadoDocAsociado)
      {
        Map mapClave = new HashMap<String, Object>();
        mapClave.put("NUM_CORREDOC", mapa.get("NUM_CORREDOC"));
        mapClave.put("NUM_SECDOC", mapa.get("NUM_SECDOC"));
        mapClave.put("COD_TIPOPER", mapa.get("COD_TIPOPER"));
        // solo muestra activos
        if ("0".equals(mapa.get("IND_DEL")) && null != Utilidades.obtenerElemento(listadoDetAutorizacion, mapClave))
        {
          listado2.add(mapa);
        }
      }
    }
    // actualizo los datos en session de la declaracion actual
    mapCabDeclara.put("lstDocAutAsociado", listadoDocAsociado);
    mapCabDeclara.put("lstDetAutorizacion", listadoDetAutorizacion);
    request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

    if (CollectionUtils.isEmpty(listado2))
    {
      banderaEdicion = false;
    }


    ModelAndView view = new ModelAndView("destino/ConsultaDocAutorizaSerie");

    if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))
    {
      // para poner el titulo
      view.addObject("documentos", !CollectionUtils.isEmpty(listado2) ? SojoUtil.toJson(listado2) : "[]");
      view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
      view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
      view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
      view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
      // tambien se consulta desde la declaracion entonces esteparametro es vaicio o null
      view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));

    }
    else
    {
      // Datos de formulario
      String documento = SojoUtil.toJson(listado2).replaceAll("null", "\"\"");

      if ("10".equals(tipoDiligencia))
      {
        if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()) && !CollectionUtils.isEmpty(listado2))
         {
           banderaEdicion = true;
         }
         else
         {
           banderaEdicion = false;
         }
      }



      view.addObject("documentos", documento);
      view.addObject("bEdicion", banderaEdicion);
      view.addObject("hdn_num_corredoc", numCorreDoc);
      view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
      view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
      view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
      view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
      view.addObject("hdn_num_secserie", serieSeleccionada);

      List<Map<String, String>> lstTipoOperacion = this.catalogoAyudaService.getElementosCat("327");
      if (!CollectionUtils.isEmpty(lstTipoOperacion))
      {
        Iterator it = lstTipoOperacion.iterator();
        while (it.hasNext())
        {
          Map<String, String> mp = (Map<String, String>) it.next();
          if (mp.get("cod_datacat").equals("C"))
            it.remove();
        }
      }

      view.addObject("lstTipoOperacion", SojoUtil.toJson(lstTipoOperacion));
      view.addObject("lstEntidad", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("49")));
      view.addObject("lstTipoDocumento", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("367")));

    }

    return view;
  }

  /**
   * Metodo que modifica los documentos asociados en session.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView modificarDocumentoAsociadoSession(HttpServletRequest request, HttpServletResponse response)
  {
    MensajeBean rBean = null;
    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapCabDeclara = null;
    List<Map<String, Object>> lstDocumentoAsociado = null;
    boolean existe = false;
    Map<String, Object> mDetAutBase;
    try
    {

      JSONArray array1 = JSONArray.fromObject(webRequest.getParameter("hdn_lstDocumentoAsociado"));

      lstDocumentoAsociado = (List<Map<String, Object>>) Utilidades.toCollection(array1, Map.class);

      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado"))
      {
        existe = false;
        for (int i = 0; i < lstDocumentoAsociado.size(); i++)
        {
          if (mapa
              .get("NUM_SECDOC")
              .toString()
              .trim()
              .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("NUM_SECDOC").toString().trim())
              &&
              mapa
                  .get("COD_TIPOPER")
                  .toString()
                  .trim()
                  .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("COD_TIPOPER").toString().trim()))
          {
            existe = false;
            break;
          }
          else
            existe = true;
        }
        if (existe)
        {
          lstDocumentoAsociado.add(mapa);
        }
      }

      // agregar a la un nuevo det autoriza
      for (int i = 0; i < lstDocumentoAsociado.size(); i++)
      {
        existe = true;
        for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion"))
        {
          if (mapa
              .get("NUM_SECDOC")
              .toString()
              .trim()
              .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("NUM_SECDOC").toString().trim())
              &&
              mapa
                  .get("COD_TIPOPER")
                  .toString()
                  .trim()
                  .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("COD_TIPOPER").toString().trim()))
          {
            existe = false;
            break;
          }
          else
            existe = true;
        }

        if (existe)
        {
          mDetAutBase = new HashMap<String, Object>()
          {

            private static final long serialVersionUID = -3103099312904419163L;

            {
              put("NUM_CORREDOC", "");
              put("NUM_SECSERIE", "");
              put("NUM_SECDOC", "");
              put("IND_DEL", "");
              put("COD_USUREGIS", "");
              put("FEC_REGIS", "");
              put("COD_USUMODIF", "");
              put("COD_IDENT_DESC", "");
              put("COD_TIPDOC_DESC", "");
              put("COD_LUGAR_DESC", "");
              put("FEC_MODIF", "");
              put("COD_TIPOPER", "");
              put("NUM_CORREDOC", "");
              put("COD_TIPDOCASO_DESC", "");
              put("COD_ENTI_DESC", "");
            }
          };
          mDetAutBase.put("NUM_CORREDOC", lstDocumentoAsociado.get(i).get("NUM_CORREDOC"));
          mDetAutBase.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
          mDetAutBase.put("NUM_SECDOC", lstDocumentoAsociado.get(i).get("NUM_SECDOC"));
          mDetAutBase.put("IND_DEL", "0");
          mDetAutBase.put("COD_USUREGIS", "");
          mDetAutBase.put("FEC_REGIS", "");
          mDetAutBase.put("COD_USUMODIF", "");
          mDetAutBase.put("FEC_MODIF", "");
          mDetAutBase.put("COD_TIPOPER", lstDocumentoAsociado.get(i).get("COD_TIPOPER"));
          ((List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion")).add(mDetAutBase);
        }
      }
      mapCabDeclara.put("lstDocAutAsociado", lstDocumentoAsociado);
      mapCabDeclara.put("lstDetAutorizacion", ((List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion")));
      request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView(jsonView, "Error", rBean);
    }
    return new ModelAndView(jsonView, "resultado", "ok");
  }



  /**
   * Metodo que que captura la acci�n de validar las declaraci�nes con
   * solicitudes realizadas por el especialista.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView validarDeclaracionSolicitud(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
      params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
      params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
      params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("tipo_diligencia"));
      Map<String, Object> mapCabDiligencia = solicitudService.validarDeclaConSolicitudXEspecialista(params);
      modelView = new ModelAndView(this.jsonView, "mapCabDiligencia", mapCabDiligencia);
      return modelView;
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }

  /**
   * Metodo para cargar el formulario se solicitud realizado por el
   * especialista.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView cargarSolicitudEspecialista(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
      params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
      params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
      params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("tipo_diligencia"));
      params.put("num_corredoc", request.getParameter("num_corredoc"));
      params.put("cod_tipdiligencia", request.getParameter("cod_tipdiligencia"));
      params.put("cod_motivo", request.getParameter("cod_motivo"));
      params.put("fec_diligencia", request.getParameter("fec_diligencia"));
      params.put("cod_funcionario", request.getParameter("cod_funcionario"));
      params.put("cod_catalogo", request.getParameter("cod_catalogo"));
      params.put("fec_conclusion", request.getParameter("fec_conclusion"));
      params.put("fec_declaracion", request.getParameter("fec_declaracion"));
      Map<String, Object> mapCabDiligencia = solicitudService.validarDeclaConSolicitudXEspecialista(params);
      if (!mapCabDiligencia.get("COD_TIPDILIGENCIA").equals("NO_FOUND"))
      {
        params.put("FEC_REGIS", mapCabDiligencia.get("FEC_REGIS"));
        params.put("respuesta", "TRUE");
        // Agregamos la descripci�n del motivo
        DataCatalogo dataCatalogo = this.catalogoAyudaService.getDataCatalogo(
            (String) params.get("cod_catalogo"),
              (String) params.get("cod_motivo"));
        params.put("des_motivo", (dataCatalogo != null) ? dataCatalogo.getDesCorta() : " ");
        FiltroCatEmpleado filtro = new FiltroCatEmpleado();
        filtro.setCodPers((String) params.get("cod_funcionario"));
        // Agregamos la descripci�n del funcionario
        Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
        CatEmpleado catEmpleadoTemp = (CatEmpleado) mapCatEmpleado.get(params.get("cod_funcionario"));
        params.put("des_funcionario", (catEmpleadoTemp != null) ?
            catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " " + catEmpleadoTemp.getNombres() : " ");
      }
      else
      {
        params.put("respuesta", "FALSE");
      }
      modelView = new ModelAndView("destino/SolicitudEspecialista", "mapCabDiligencia", params);
      return modelView;
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "Error", rBean);
    }
  }

  /**
   * Metodo para responder a la solicitud del especialista, es decir registra la
   * respuesta final de aprobaci�n del supervisor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView actualizarSolicitudEspecialista(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      FechaBean fecActual = new FechaBean();
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", request.getParameter("num_corredoc"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("cod_tipdiligencia"));
      params.put("IND_RESPUESTA", request.getParameter("ind_respuesta"));
      params.put("DES_RESPUESTA", request.getParameter("des_respuesta"));
      params.put("FEC_RESPUESTA", fecActual.getTimestamp());
      params.put("COD_USUMODIF", bUsuario.getNroRegistro());
      params.put("FEC_MODIF", fecActual.getTimestamp());
      if (params.get("COD_TIPDILIGENCIA").equals(Constantes.SOLI_AMPLI_PLAZO))
      {
        params
            .put("FEC_CONCLUSION", new FechaBean(request.getParameter("fec_conclusion"), "yyyy-MM-dd").getTimestamp());
      }
      Map<String, Object> mapRes = solicitudService.registrarRespuestaSolEspecialista(params);
      modelView = new ModelAndView(this.jsonView, "mapRes", mapRes);

      return modelView;
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }

  /**
   * Metodo para cargar la ventana de mensajes de la tabla comunicaciones.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see
   */
  public ModelAndView cargarComunicaciones(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ModelAndView modelAndView = new ModelAndView("destino/MensajesComunicacion");
    Map<String, Object> mapCabDeclara = null;
    try
    {
      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));

      List<Map<String, Object>> lstComunicacion = diligenciaService.obtenerComunicaciones(params);

      if (!CollectionUtils.isEmpty(lstComunicacion))
      {
        // Obtenemos la descripci
        for (int i = 0; i < lstComunicacion.size(); i++)
        {
          // Colocando la descripcion del usuario
          FiltroCatEmpleado filtro = new FiltroCatEmpleado();
          filtro.setCodPers(lstComunicacion.get(i).get("COD_USUREGIS").toString());
          Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
          CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(lstComunicacion.get(i).get("COD_USUREGIS"));
          lstComunicacion.get(i).put(
              "DES_USUREGIS",
                (catEmpleadoTemp != null) ?
                    catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " "
                        + catEmpleadoTemp.getNombres() : " ");
        }
      }
      modelAndView.addObject("lstComunicacionFinal", lstComunicacion);

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    return modelAndView;
  }

  /**
   * Metodo que nos permite obtener los vehiculos (Placas) y su empresa de
   * transporte segun una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaVehiculos(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkDocu = new HashMap<String, String>();
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      listado = declaracionService.obtenerVehiculos(pkDocu);
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    return new ModelAndView("ConsultaVehiculos", "vehiculos", SojoUtil.toJson(listado));
  }

  /**
   * Metodo que nos permite obtener los Plazos segun una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarPlazosProceso(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkDocu = new HashMap<String, String>();
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      listado = declaracionService.obtenerPlazosProceso(pkDocu);
      if (CollectionUtils.isEmpty(listado))
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror("El registro no contiene una lista de plazos asociados.");

        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    return new ModelAndView("ConsultaPlazosProceso", "plazos", SojoUtil.toJson(listado));
  }

  /**
   * Cargar consulta asignaciones.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaAsignaciones(HttpServletRequest request, HttpServletResponse response)
  {

    Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
    List<Map<String, Object>> lstAsignaciones = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> lstReasignaciones = new ArrayList<Map<String, Object>>();
    Long numCorredoc = ((BigDecimal) mapCabDeclara.get("NUM_CORREDOC")).longValue();

    try
    {
      lstAsignaciones = solicitudService.getDuayReguAsignaciones(numCorredoc);
      lstReasignaciones = solicitudService.getReasignaciones(numCorredoc);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a " +
          "intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }


    ModelAndView view = new ModelAndView("ConsultaAsignaciones");

    view.addObject("asignaciones", lstAsignaciones);
    view.addObject("reasignaciones", lstReasignaciones);
    view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
    view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
    view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
    view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
    view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
    mapCabDeclara = null;
    return view;
  }


  /***********************SET DE SPRING **********************************/


  /**
   * obtiene los datos de los Reg de Precedencia de la serie seleccionada y los
   * muestra en la consulta.
   *
   * @param request
   * @param response
   */
  public ModelAndView cargarConsultaRegPrecedencia(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    List listaRegPrecedenciaActual = new ArrayList();
    
    List<Map<String,Object>> listaDatoVehiculo = null;
    List<DatoMontoGasto> lstDatoMontoGastoObj = null;
    List<Map<String,Object>> listaDatoMontoGasto = null;
    List<Map<String, String>> lstMtoGasto = null;
    DatoVehiculo datoVehiculo = null;
    Map<String,Object> datoVehiculoMap = null;

    try {

      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
      params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
      params.put("num_secserie", request.getParameter("hdn_num_secserie"));
      
      Long numCorreDoc = Long.parseLong(request.getParameter("hdn_num_corredoc"));
      Long numSecSerie = Long.parseLong(request.getParameter("hdn_num_secserie"));

      List<Map<String, Object>> lstDetDeclaraActual = (ArrayList<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
      Map<String, Object> mapaKeySerieSelec = new HashMap<String, Object>();
      mapaKeySerieSelec.put("NUM_CORREDOC", params.get("num_corredoc"));
      mapaKeySerieSelec.put("NUM_SECSERIE", params.get("num_secserie"));

      // Obtenemos la serie actual seleccionada
      Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, mapaKeySerieSelec);
      // Si la serie en session tiene datos de reg de precedencia
      if (!CollectionUtils.isEmpty((List) serieAct.get("lstDocuPreceDua"))) {
        listaRegPrecedenciaActual = (ArrayList) serieAct.get("lstDocuPreceDua");
      }else{
        // cargo los datos de la BD
        listaRegPrecedenciaActual = serieService.obtenerRegPrecedencia(mapaKeySerieSelec);
      }
      String numPartNandi = serieAct.get("NUM_PARTNANDI").toString();
	  params.put("num_partnandi", numPartNandi);

      //jenciso Inicio consulta hoja de gastos para ceticos
      if(!CollectionUtils.isEmpty(listaRegPrecedenciaActual)){
    	  
    	  Map<String,Object> mapPrecedencia = (Map<String,Object>)listaRegPrecedenciaActual.get(0);
    	  
    	  String regimenPrecedencia = mapPrecedencia.get("COD_REGIMENPRE")!=null?mapPrecedencia.get("COD_REGIMENPRE").toString():""; 
    	  if (regimenPrecedencia.equals("91") && (numPartNandi.equals("8701200000") 
                  || SunatStringUtils.isStringInList(numPartNandi.substring(0, 4), "8702,8703,8704,8705"))){
    		  //se carga info de los veh�culos.
    		  
    		  lstMtoGasto = catalogoAyudaService.getElementosCat("331");
              if (lstMtoGasto != null)
              {
                lstMtoGasto = ordenaMontoGasto(lstMtoGasto);
              }
              listaDatoVehiculo = (ArrayList)serieAct.get("lstDatoVehiculo");
              if(listaDatoVehiculo!=null && !listaDatoVehiculo.isEmpty())            	
              	datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap((Map<String,Object>)listaDatoVehiculo.get(0));
              listaDatoMontoGasto = (ArrayList)serieAct.get("lstDatoMontoGasto");
              if(listaDatoVehiculo == null || listaDatoVehiculo.isEmpty() || listaDatoMontoGasto == null || listaDatoMontoGasto.isEmpty()){
              	Map<String, Object> paramsVehiCeti = new HashMap<String, Object>();
//                  paramsVehiCeti.put("numcorredoc", numCorreDoc);
//                  paramsVehiCeti.put("numserie", numSecSerie);
//                  paramsVehiCeti.put("inddel", 0);
//                  List<DatoVehiculo> lstDatoVehiculo = diligenciaService.findVehiculoByMap(paramsVehiCeti);
              	paramsVehiCeti.put("NUM_CORREDOC", numCorreDoc);
              	paramsVehiCeti.put("NUM_SECSERIE", numSecSerie);
              	paramsVehiCeti.put("IND_DEL", "0");
              	listaDatoVehiculo = vehiCeticoService.selectVehiCetico(paramsVehiCeti);
              	
                  if (listaDatoVehiculo != null && listaDatoVehiculo.size() > 0)
                  {
                    datoVehiculoMap = new HashMap<String, Object>();
                    datoVehiculoMap = listaDatoVehiculo.get(0);
                    //serieAct.put("datoVehiculo", datoVehiculo);
                    datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap(datoVehiculoMap);
                    //serieAct.put("lstDatoVehiculo", listaDatoVehiculo);//se guarda en lista para que no afecte en la comparacion de mapas
                  }
                  //lstDatoMontoGasto = diligenciaService.findMontoGastoByMap(paramsVehiCeti);
                  listaDatoMontoGasto = vehiCeticoService.selectMontoGasto(paramsVehiCeti);
                  //serieAct.put("lstDatoMontoGasto", listaDatoMontoGasto);
              }
              lstDatoMontoGastoObj= Utilidades.obtenerListDatoMontoGastoFromListMap(listaDatoMontoGasto);
    		  
    	  }
      }
      //jenciso Fin
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);

    }

    ModelAndView view = new ModelAndView("ConsultaRegPrecedencia");

    //PAS20181U220200054
	ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
	Date fechaHoy = SunatDateUtils.getCurrentDate();
	boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;
	if(esVigenteRIN31) {
		view.addObject("vigenciaZofra", "1");
	}
	else {
		view.addObject("vigenciaZofra", "0");
	}

    view.addObject("params", params);
    view.addObject("lstDocuPreceDuaActual", !CollectionUtils.isEmpty(listaRegPrecedenciaActual) ? SojoUtil.toJson(listaRegPrecedenciaActual) : "[]");
    view.addObject("lstMtoGasto", lstMtoGasto);
    view.addObject("datoVehiculo", datoVehiculo);
    view.addObject("lstDatoMontoGasto", lstDatoMontoGastoObj);
    
    return view;
  }
  
  
  /**
   * Ordena monto gasto.
   *
   * @param lista
   *          the lista
   * @return the list
   */
  public List<Map<String, String>> ordenaMontoGasto(List<Map<String, String>> lista)
  {
    String[] keyList = new String[lista.size()];
    for (int i = 0; i < lista.size(); i++)
    {
      keyList[i] = lista.get(i).get("cod_datacat").toString();
    }
    Arrays.sort(keyList);
    List<Map<String, String>> orderList = new ArrayList<Map<String, String>>();
    for (int i = 0; i < keyList.length; i++)
    {
      for (int j = 0; j < lista.size(); j++)
      {
        if (lista.get(j).get("cod_datacat").equals(keyList[i]))
        {
          orderList.add(lista.get(j));
        }
      }
    }
    return orderList;
  }

  /**
   * obtiene los datos de la factura serie de la serie seleccionada y los
   * muestra en la consulta.
   *
   * @param request
   * @param response
   * @return
   */
  public ModelAndView cargarConsultaFacturaSerie(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    List listaFacturaSerieActual = new ArrayList();
    try {

      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
      params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
      params.put("num_secserie", request.getParameter("hdn_num_secserie"));

      List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
      Map<String, Object> mapaKeySerieSelec = new HashMap<String, Object>();
      mapaKeySerieSelec.put("NUM_CORREDOC", params.get("num_corredoc"));
      mapaKeySerieSelec.put("NUM_SECSERIE", params.get("num_secserie"));

      // Obtenemos la serie actual seleccionada
      Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, mapaKeySerieSelec);
      // si la lista actua de la serie tiene datos de reg de precedencia
      if (!CollectionUtils.isEmpty((List) serieAct.get("lstFacturaSerie"))) {
        listaFacturaSerieActual = (ArrayList) serieAct.get("lstFacturaSerie");
      } else {
        // cargo los datos de la BD los datos de la serie seleccionada
        listaFacturaSerieActual = this.formatoValorService.obtenerFacturasSerie(mapaKeySerieSelec);
      }
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);

    }

    ModelAndView view = new ModelAndView("ConsultaFacturasSerie");
    view.addObject("params", params);
    view.addObject("lstFacturasSerieActual", !CollectionUtils.isEmpty(listaFacturaSerieActual) ? SojoUtil.toJson(listaFacturaSerieActual) : "[]");
    return view;

  }

  /**
   * Metodo que nos permite Obtener y mostrar los datos del Certificado de
   * Origen de una determinada Serie.
   *
   * @param request
   * @param response
   */
  public ModelAndView cargarConsultaCertOrigen(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    Map<String, Object> mapCabCertiOrigenRSPTA = new HashMap<String, Object>();

    Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
    List<Map<String, Object>> lstCabCertiOrigenActual = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listadoDetAutorizacionActual = new ArrayList<Map<String, Object>>();

    try {

      // para que se pueda invoar via GET
      String codAduana = request.getParameter("hdn_cod_aduana") != null ? request.getParameter("hdn_cod_aduana") : this.obtenerAduana(request);
      String annPresen = request.getParameter("hdn_ann_presen") != null ? request.getParameter("hdn_ann_presen") : String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
      String codRegimen = request.getParameter("hdn_cod_regimen") != null ? request.getParameter("hdn_cod_regimen") : "";
      String numDeclaracion = request.getParameter("hdn_num_declaracion") != null ? request.getParameter("hdn_num_declaracion") : "";
      String numCorredoc = request.getParameter("hdn_num_corredoc") != null ? request.getParameter("hdn_num_corredoc") : "";
      String numSecSerie = request.getParameter("hdn_num_secserie") != null ? request.getParameter("hdn_num_secserie") : "";

      // seteamos los valores a Params
      params.put("cod_aduana", codAduana);
      params.put("ann_presen", annPresen);
      params.put("cod_regimen", codRegimen);
      params.put("num_declaracion", numDeclaracion);

      // buscamos en session si existe el certiorigen
      mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      // lstDocAutAsociado y lstCabCertiOrigen estan relacionadas
      if (!CollectionUtils.isEmpty(mapCabDeclaraActual) && !CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstDocAutAsociado"))
          && !CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstCabCertiOrigen"))) {

        listadoDetAutorizacionActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstDetAutorizacion");

        String nunSecDoc = ""; // dato necesario para encontrar CertOrigen de la Session
        for (Map<String, Object> mapa : listadoDetAutorizacionActual) {
          if (numSecSerie.trim().equals(mapa.get("NUM_SECSERIE").toString().trim()) && mapa.get("COD_TIPOPER").toString().trim().equals("C")) {
            nunSecDoc = mapa.get("NUM_SECDOC").toString();

          }
        }

       Map<String, Object> mapaPkCertiOrigen = new HashMap<String, Object>();
        mapaPkCertiOrigen.put("NUM_CORREDOC", numCorredoc);
        mapaPkCertiOrigen.put("NUM_SECDOC", nunSecDoc);
        mapaPkCertiOrigen.put("COD_TIPOPER", "C");

        // esta lista obtiene todos los certificados de la declaracion
        lstCabCertiOrigenActual = (List) mapCabDeclaraActual.get("lstCabCertiOrigen");
        // Obtenemos la serie actual seleccionada
        mapCabCertiOrigenRSPTA = Utilidades.obtenerElemento(lstCabCertiOrigenActual, mapaPkCertiOrigen);

      } else {
        Map mapaPkSerie = new HashMap<String, String>();
        mapaPkSerie.put("NUM_CORREDOC", numCorredoc);
        mapaPkSerie.put("NUM_SECSERIE", numSecSerie);
        // obtiene certificado de origen de la serie de la BD obtiene una lista de 1
        // elemento
        lstCabCertiOrigenActual = this.declaracionService.obtenerCertOrigen(mapaPkSerie);
        if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual)) {
          mapCabCertiOrigenRSPTA = lstCabCertiOrigenActual.get(0);
        }
      }
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);
    }


    ModelAndView view =null;
    if(!CollectionUtils.isEmpty(mapCabCertiOrigenRSPTA)){
    String numSecDoc = mapCabCertiOrigenRSPTA.get("NUM_SECDOC").toString();
    String codTipOper = (String) mapCabCertiOrigenRSPTA.get("COD_TIPOPER");

    view = new ModelAndView("ConsultaCertOrigen");
    view.addObject("dua", Utilidades.obtenerTituloDUA(params));
    view.addObject("existeCertificado", mapCabCertiOrigenRSPTA.size() > 0 ? "1" : "0");
    view.addObject("certificadoOrigen", mapCabCertiOrigenRSPTA);
    view.addObject("pk", SojoUtil.toJson(numSecDoc.concat(codTipOper)));
    }else{
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("No tiene certificado de origen");
      return new ModelAndView("PagM", "beanM", mensajeBean);
    }

    return view;
  }

  /** Coloca el estado "Adicionado" a los items que fueron agregados mediante la copia de items
  * @param listaItems
  * @param mapCabDeclara
  * @return [List<Map<String, Object>>]
  * @throws Exception
  */
  private List<Map<String, Object>> colocarEstadoItem(List<Map<String, Object>> listaItems, 
		  													Map<String, Object> mapCabDeclara) throws Exception{
	  
	  if(!CollectionUtils.isEmpty(listaItems)){
		for(Map<String, Object> item : listaItems){

			if(item.get("ind_del").toString().equals("1")){
				item.put("ESTADO", "Eliminado");
			}else{
				Date fechRegisDeclaracion = null;
				if(mapCabDeclara.get("FEC_REGIS")!=null){
					
					fechRegisDeclaracion = Utilidades.toDate(mapCabDeclara.get("FEC_REGIS"));
				}
				Date fechRegItem = Utilidades.toDate(item.get("fec_regis"));

				if(fechRegItem.compareTo(fechRegisDeclaracion) == 1){
					
					long fechItem = fechRegItem.getTime();
					long fechDeclaracion = fechRegisDeclaracion.getTime();
					long diff = fechItem - fechDeclaracion;

					long diffHours = diff / (60 * 60 * 1000);
   
					if(diffHours > Constantes.CANT_HORAS_ITEM_ADICION){
						item.put("ESTADO", "Adicionado");
					}else{
						item.put("ESTADO", "");
					}
				}else{
					item.put("ESTADO", "");
				}
			}
		}  
	  }
	  return listaItems;
  }

  /**
   * Sets the formato valor service.
   *
   * @param formatoValorService
   *          the new formato valor service
   */
  public void setFormatoValorService(FormatoValorService formatoValorService)
  {
    this.formatoValorService = formatoValorService;
  }



  /**
   * Sets the declaracion service.
   *
   * @param declaracionService
   *          the new declaracion service
   */
  public void setDeclaracionService(DeclaracionService declaracionService)
  {
    this.declaracionService = declaracionService;
  }

  /**
   * Sets the soporte service.
   *
   * @param soporteService
   *          the new soporte service
   */
  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

  /**
   * Sets the solicitud service.
   *
   * @param solicitudService
   *          the new solicitud service
   */
  public void setSolicitudService(SolicitudService solicitudService)
  {
    this.solicitudService = solicitudService;
  }

  /**
   * Sets the fabrica de servicios.
   *
   * @param fabricaDeServicios
   *          the new fabrica de servicios
   */
  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }

  /**
   * Sets the liquida declaracion service.
   *
   * @param liquidaDeclaracionService
   *          the new liquida declaracion service
   */
  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }

  /**
   * Sets the rectificacion service.
   *
   * @param rectificacionService
   *          the new rectificacion service
   */
  public void setRectificacionService(RectificacionService rectificacionService)
  {
    this.rectificacionService = rectificacionService;
  }

  public void setIncidenciaService(IncidenciaService incidenciaService)
  {
    this.incidenciaService = incidenciaService;
  }

  public void setDeudaService(DeudaService deudaService)
  {
    this.deudaService = deudaService;
  }

  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }

  /* olunar 309 */
  public void setConsultaService(ConsultaService consultaService) {
	this.consultaService = consultaService;
  }
  /* fin */

public void setVehiCeticoService(VehiCeticoService vehiCeticoService) {
	this.vehiCeticoService = vehiCeticoService;
}
}
