package pe.gob.sunat.controladuanero2.ingreso.postlevante.ws.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by amancillaa on 28/03/2016.
 */

@Controller
public class SolicitudPostLevanteRestController {



}
