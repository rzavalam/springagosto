package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.bean;

import org.apache.commons.lang.builder.ToStringBuilder;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DetIncidenciaBean;

public class DetIncidenciaVistaBean extends DetIncidenciaBean {

    private static final long serialVersionUID = -3860433275869453718L;

    private String codIncidenciaDescrip;
    private String seriesDescrip;

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getCodIncidenciaDescrip() {
        return codIncidenciaDescrip;
    }

    public void setCodIncidenciaDescrip(String codIncidenciaDescrip) {
        this.codIncidenciaDescrip = codIncidenciaDescrip;
    }

    public String getSeriesDescrip() {
        return seriesDescrip;
    }

    public void setSeriesDescrip(String seriesDescrip) {
        this.seriesDescrip = seriesDescrip;
    }

}
