package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService; //RIN08
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;//RIN08
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService; //P46-PAS20155E410000032
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.genadeudo.model.Detaliq;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
//import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;
//import pe.gob.sunat.recauda2.genadeudo.service.DeudaTributariaAduaneraService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_DILIG_REC_FIS;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_DILIG_REV_DOC;

//import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.Garantia160Service;

/**
 * <p>
 * Titulo: Controlador Web para Liquidacion
 * </p>
 * <p>
 * Descripcion: Controlador que administra las funcionalidades de Liquidacion
 * para la Declaracion.
 * </p>
 *
 * @author jcanchucaja
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class LiquidacionCulminacionPecoController extends MultiActionController
{

  protected final Log               log = LogFactory.getLog(getClass());

  private LiquidaDeclaracionService liquidaDeclaracionService;

  private SerieService              serieService;

  private SoporteService              soporteService;

  private FabricaDeServicios fabricaDeServicios;
//rin08
  private DiligenciaService         diligenciaService;
  
/*RIN13FSW-INICIO*/
  // HAGAPITO
  protected String               jsonView;

  private CatalogoAyudaService catalogoAyudaService;

  // HAGAPITO  
  public void setJsonView(String jsonView) {
	this.jsonView = jsonView;
}
/*RIN13FSW-FIN*/
  /**
   * Metodo que realiza la Liquidacion de Declaracion.
   *
   * @param request
   *          the request
   * @throws Exception
   *           the exception
   */
  public void liquidarDeclaracion(HttpServletRequest request) throws Exception
  { //Rin08
	 WebUtils.setSessionAttribute(request, "acogimientoPostNumPecoAmazonia", "NO");//rin08 inicializamos la condicion
      
    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map resulPreliq = new HashMap();
    resulPreliq.put("ERROR", "NO");
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
    params.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
    params.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
    params.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));

    /**Inicia cambio de PAS20155E220200192 RSV **/
    String indicador15 = null;
    /**Inicia cambio de PAS20155E220200192 RSV **/


    Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map<String, Object> declaracionOld = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");//P46-PAS20155E410000032-[jlunah] BUG 24889
    List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

    if (listDetDeclara.isEmpty())
    {
      resulPreliq.put("ERROR", "No se han cargado las series");
      declaracionActual.put("resulPreliq", resulPreliq);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
      return;
    }

    List listParticipanteDoc = new ArrayList();
    // Obtenemos de cabDeclara (importador y agente)
    if (declaracionActual.get("COD_TIPDOC_PIM") != null)
    {
      Map mapImport = new HashMap();
      mapImport.put("COD_TIPPARTIC", "45");
      mapImport.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
      mapImport.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
      listParticipanteDoc.add(mapImport);
    }

    if (declaracionActual.get("NUM_DOCIDENT_PDE") != null)
    {
      Map mapAgent = new HashMap();
      mapAgent.put("COD_TIPPARTIC", "41");
      mapAgent.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
      mapAgent.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
      listParticipanteDoc.add(mapAgent);
    }

    if (listParticipanteDoc.isEmpty())
    {
      resulPreliq.put("ERROR", "No existe lista de Participantes");
      declaracionActual.put("resulPreliq", resulPreliq);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
      return;
    }

    /**Inicia cambio de PAS20155E220200192 RSV **/
    List<Map<String,Object>> listIndicadoresNEW = new ArrayList<Map<String,Object>>();
    String codIndicador = "";
    String indActivo = "";
    /**Fin cambio de PAS20155E220200192 RSV **/
    
    listIndicadoresNEW = declaracionActual.get("LIST_INDICADORES_DUA")!=null? (ArrayList<Map<String,Object>>) declaracionActual.get("LIST_INDICADORES_DUA"):new ArrayList<Map<String,Object>>();
    if(!CollectionUtils.isEmpty(listIndicadoresNEW)){
    	for(Map<String,Object> datoIndicadorNEW: listIndicadoresNEW){
    		String codIndicadortmp = datoIndicadorNEW.get("COD_INDICADOR")!=null?datoIndicadorNEW.get("COD_INDICADOR").toString().trim():"";
    		indActivo = datoIndicadorNEW.get("IND_ACTIVO")!=null?datoIndicadorNEW.get("IND_ACTIVO").toString().trim():"";
    		/**Inicia cambio de PAS20155E220200192 RSV **/
    		if(SunatStringUtils.isEqualTo("15", codIndicadortmp)   && !SunatStringUtils.isEqualTo("0", indActivo)){
    			indicador15 = codIndicadortmp;
    			break;
    		}       		
    		/**Fin cambio de PAS20155E220200192 RSV **/
		}
	}
    
    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
    UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

    List listConvenioSerie = new ArrayList();
    List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
    Map<String, Object> serieEliminada = null;
    for (Map<String, Object> detDeclaraMap : listDetDeclara)
    {
      if ("1".equals(detDeclaraMap.get("IND_DEL")))
      {
        serieEliminada = detDeclaraMap;
        listaSerieEliminada.add(serieEliminada);
        continue;
      }
      if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
      {
        detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
      }
      if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
      {
        List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
        for (int i = 0; i < lstConvenioSerie.size(); i++)
        {
          HashMap convenio = (HashMap) lstConvenioSerie.get(i);
          if (!"1".equals(convenio.get("IND_DEL")))
          {
            // en la rectificacion no se agrega el ind_eliminado a los nuevos
            // convenios
            listConvenioSerie.add(convenio);
          }
        }
      }
    }
    for (Map<String, Object> mapEliminar : listaSerieEliminada)
    {
      listDetDeclara.remove(mapEliminar);
    }

    List listDocupreceDua = (ArrayList) WebUtils.getSessionAttribute(request, "lstDocuPreceDuaActual");
    HashMap paramDocLiq = new HashMap();
    paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
    paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
    paramDocLiq.put("cabDeclara", declaracionActual);
    paramDocLiq.put("listDetDeclara", listDetDeclara);
    paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
    paramDocLiq.put("listConvenioSerie", listConvenioSerie);
    paramDocLiq.put("listDocupreceDua", listDocupreceDua);
    paramDocLiq.put("listaSerieEliminada", listaSerieEliminada);
    paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
	//P46 KMORAN
    paramDocLiq.put("lstIndicadorDua", declaracionActual.get("LIST_INDICADORES_DUA"));
	  // FIN P46 KMORAN
     // INI rin08
    List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
    Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute( request, "mapCabDeclaraActual");
    String aduanaDestino=mapCabDeclaraActual.get("COD_ADUDEST").toString();
    Map<String, Object> detDeclaraMapActual;
    List<Map<String, Object>> lstConvenioSerie;
    Map<String, Object> convenio;
    boolean isPeco=false;
    boolean isAmazonia=false;
    /**Inicia cambio de PAS20155E220200192 RSV **/
    boolean isTPILC0010=false;  
    String tipoMargen=null;  
    boolean generarLC15_NO_9 = false;   
    boolean generarLC15_SI_9 = false;  
    /**Fin cambio de PAS20155E220200192 RSV **/
  
    String rpta="0";
    for (int i = 0; i < lstDetDeclaraActual.size(); i++) {
		  detDeclaraMapActual = lstDetDeclaraActual.get(i);
		  if (!"1".equals(detDeclaraMapActual.get("IND_DEL"))){
			  
			  
			  /**Inicia cambio de PAS20155E220200192 RSV **/
				tipoMargen = detDeclaraMapActual.get("COD_TIPMARGEN") == null?" ":detDeclaraMapActual.get("COD_TIPMARGEN").toString().trim() ;
				/**Fin cambio de PAS20155E220200192 RSV **/
				
			  lstConvenioSerie=(List<Map<String, Object>>)detDeclaraMapActual.get("lstConvenioSerie");
			  if (lstConvenioSerie!=null){
				  for (int j = 0; j<lstConvenioSerie.size(); j++) {
					  convenio=lstConvenioSerie.get(j);
					  
					  //20150222 - Se adiciona la validacion del flag IND_del de eliminacion
					  if ((ConstantesDataCatalogo.COD_TIP_34.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")) && !"1".equals(convenio.get("IND_DEL"))  && pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo.ADUANA_IQUITOS.equals(aduanaDestino)) || 
						  (ConstantesDataCatalogo.COD_TIP_35.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")) && !"1".equals(convenio.get("IND_DEL")) && pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo.ADUANA_PUCALLPA.equals(aduanaDestino)) ||
						  (ConstantesDataCatalogo.COD_TIP_36.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")) && !"1".equals(convenio.get("IND_DEL")) && pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo.ADUANA_TARAPOTO.equals(aduanaDestino))) {
						
						  isPeco=true;
					  }
					  
					  if ( ConstantesDataCatalogo.COD_TIP_4438.equals(convenio.get("COD_CONVENIO").toString().trim()) && "C".equals(convenio.get("COD_TIPCONVENIO")) && !"1".equals(convenio.get("IND_DEL")) ) {
						  isAmazonia=true;
					  }
					  
					  
				  }
			  }
			  
			  
			  /**Inicia cambio de PAS20155E220200192 RSV **/
			  if(indicador15!=null){
					//todos margen =9
					if( tipoMargen!=null && tipoMargen.equals("9")){
						generarLC15_SI_9 = true;
					}
					
				}
			  /**Fin cambio de PAS20155E220200192 RSV **/			  
		  } 
	  }
    
      if (isPeco && ! isAmazonia) {
		  rpta="1";
	  }
	  if (!isPeco && isAmazonia) {
		  rpta="2";
	  }

	  if (isPeco &&  isAmazonia) {
		  rpta="3";
	  }
	  
	  
	    String tienePecoAmazoniaBD="NO";
	    Map<String, Object> detDeclaraMapBD;
	    
	    String rptaBD="0";
	    boolean isPecoBD=false;
	    boolean isAmazoniaBD=false;
	    /**Inicia cambio de PAS20155E220200192 RSV **/
	    String tipoMargenBD=null;  
	    /**Inicia cambio de PAS20155E220200192 RSV **/
	    
	    List<Map<String, Object>> lstDetDeclaraBD = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
	    for (int i = 0; i < lstDetDeclaraBD.size(); i++) {
	    	detDeclaraMapBD = lstDetDeclaraBD.get(i);
	    	
	    	/**Inicia cambio de PAS20155E220200192 RSV **/
			tipoMargenBD = detDeclaraMapBD.get("COD_TIPMARGEN") == null?" ":detDeclaraMapBD.get("COD_TIPMARGEN").toString().trim() ;
			/**Fin cambio de PAS20155E220200192 RSV **/
			
			  lstConvenioSerie=(List<Map<String, Object>>)detDeclaraMapBD.get("lstConvenioSerie");
			  if (lstConvenioSerie!=null){
				  for (int j = 0; j<lstConvenioSerie.size(); j++) {
					  convenio=lstConvenioSerie.get(j);
					  if ( (ConstantesDataCatalogo.COD_TIP_34.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")) ) || 
					       (ConstantesDataCatalogo.COD_TIP_35.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")) ) ||
					       (ConstantesDataCatalogo.COD_TIP_36.equals(convenio.get("COD_CONVENIO").toString().trim())  && "I".equals(convenio.get("COD_TIPCONVENIO")))) {

						  tienePecoAmazoniaBD="SI";
						  isPecoBD=true;
						  //break;
					  }
					  
					  if ( ConstantesDataCatalogo.COD_TIP_4438.equals(convenio.get("COD_CONVENIO").toString().trim()) && "C".equals(convenio.get("COD_TIPCONVENIO"))) {
     						  tienePecoAmazoniaBD="SI";
     						 isAmazoniaBD=true;
							  //break;
					  }
					  
					 
				  }//for
			  }
			  /*if (tienePecoAmazoniaBD.equals("SI")){
				  break;
			  }*/
			  
			  /**Inicia cambio de PAS20155E220200192 RSV **/
			  if(indicador15!=null){
					//todos margen =9
					if( tipoMargenBD!=null && tipoMargenBD.equals("9")){
						generarLC15_SI_9 = true;
					}
					
				}
			  /**Fin cambio de PAS20155E220200192 RSV **/
	   }
 
	    if (isPecoBD && ! isAmazoniaBD) {
	    	rptaBD="1";
		 }
		 if (!isPecoBD && isAmazoniaBD) {
			 rptaBD="2";
		 }

		 if (isPecoBD &&  isAmazoniaBD) {
			 rptaBD="3";
		 }
	    
    paramDocLiq.put("generaLC0006",isPeco||isAmazonia?"SI":"NO" );
    paramDocLiq.put("acogimientoPostNumPecoAmazonia",(tienePecoAmazoniaBD.equals("SI") || !rpta.equals("0"))? "SI":"NO");
    paramDocLiq.put("esPecoAmazonia",rpta);
    paramDocLiq.put("esPecoAmazoniaBD",rptaBD);
    
    /**Inicia cambio de PAS20155E220200192 RSV **/ 
    paramDocLiq.put("generarLC15_SI_9",generarLC15_SI_9?"SI":"NO" );
    paramDocLiq.put("generarLC15_NO_9",generarLC15_NO_9?"SI":"NO" );
    paramDocLiq.put("certiOrigen"," certiOrigen " );
    /**Fin cambio de PAS20155E220200192 RSV **/
    
    String resultadoDiligenciaAduanaDestino="00";
    //pase 69
    if  ( Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(paramDocLiq.get("codTipdiligencia"))||Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(paramDocLiq.get("codTipdiligencia"))){
	    //validar en el caso sea rectificacion de oficio y qye cuente con diligencia en aduana de destino tipo =21
	     Map<String, Object> mapCabDeclara= (HashMap)WebUtils.getSessionAttribute(request, "mapCabDeclara");
	    Map<String, Object> PkDocu = new HashMap();
	    PkDocu.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
	    PkDocu.put("COD_TIPDILIGENCIA", "22"); //constantes.DILIG_ADUANA_DESTINO
	    List <Map<String, Object>>listadoDiligenciaDespacho = diligenciaService.selectDiligencia(PkDocu);
	    if (listadoDiligenciaDespacho.size()>0){
	    	resultadoDiligenciaAduanaDestino=listadoDiligenciaDespacho.get(0).get("DES_RESULTADO").toString().substring(0, 2);
	    	paramDocLiq.put("generaLC0006", "NO" ); //re- evaluamos el parametro de liq. ya que depende del resultado de la mercancia como llego en aduana de destino
	    }
    }else{
    	if(Constantes.COD_TIPO_DILIGENCIA_ADUANA_DESTINO.equals(paramDocLiq.get("codTipdiligencia"))){
    	resultadoDiligenciaAduanaDestino= (String) WebUtils.getSessionAttribute(request, "resultadoDiligenciaAduanaDestino");
    	}
    }   
        
    paramDocLiq.put("resultadoDiligenciaAduanaDestino",resultadoDiligenciaAduanaDestino);
    //END rin08
    resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);
    declaracionActual.put("caduana", soporteService.obtenerAduana(request));
    Map parametros = new HashMap();
    declaracionActual.put("resulPreliq", resulPreliq);
    parametros.put("mapCabDeclaraActual", declaracionActual);
    parametros.put("lstMultaDua", WebUtils.getSessionAttribute(request, "lstMultas"));
     // INI rin08
     parametros.put("esPecoAmazonia",rpta);
     parametros.put("esPecoAmazoniaBD",rptaBD);
 	if (resultadoDiligenciaAduanaDestino.equals("01")){
 		parametros.put("acogimientoPostNumPecoAmazonia", "SI");
 	}else{
 		parametros.put("acogimientoPostNumPecoAmazonia",(tienePecoAmazoniaBD.equals("SI") || !rpta.equals("0"))? "SI":"NO");
 	}
    
    //si es desistimiento de pecoamazonia mordonez PAS201830001100016
 	if(!rptaBD.equals("0") && rpta.equals("0")){
 		parametros.put("acogimientoPostNumPecoAmazonia","NO");
 	}
    
    parametros.put("resultadoDiligenciaAduanaDestino",resultadoDiligenciaAduanaDestino);
    //endrin08
    
    /*inicio P46-PAS20155E410000032-[jlunah] BUG 24889*/
    /*evalua caso si fue donacion y ahora ya no */
    String tipoTratamientoActual = (String) declaracionActual.get("COD_TIPTRATMERC");
	String tipoTratamientoOld = (String) declaracionOld.get("COD_TIPTRATMERC");
	
	parametros.put("deTratamientoConDonacionATratamientoSinDonacion",false);
	
	if(tipoTratamientoOld.equals( ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)
			&& !tipoTratamientoActual.equals( ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){/*Si antes fue tratamiento donacion y ahora ya no lo es*/
		
		parametros.put("deTratamientoConDonacionATratamientoSinDonacion", true);
		
	}
    /*fin P46-PAS20155E410000032-[jlunah] BUG 24889*/
    

    /*** Inicio Cambio PAS20155E220200192 RSV **/
    //preliquidacion   resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);  aqui se guarda el monto
    WebUtils.setSessionAttribute(request, "generarLC15_SI_9",  generarLC15_SI_9?"SI":"NO" );
   WebUtils.setSessionAttribute(request, "generarLC15_NO_9",  generarLC15_NO_9?"SI":"NO");
   /*** Finn Cambio PAS20155E220200192 **/
    
    this.liquidaDeclaracionService.liquidaDiligencia(parametros);
    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

    //incio rin08
    WebUtils.setSessionAttribute(request, "acogimientoPostNumPecoAmazonia",  parametros.get("acogimientoPostNumPecoAmazonia"));
    WebUtils.setSessionAttribute(request, "resultadoDiligenciaAduanaDestino",  parametros.get("resultadoDiligenciaAduanaDestino"));
    //fin rin08
    


  }


//INICIO-FSW
  /* jzevallosv inicio 28.02.14 branch-2014-003-SWF */
  public ModelAndView getDetalleLiq(HttpServletRequest request, HttpServletResponse response) 
  {
	  String[] params=request.getParameter("hdn_cod").split("-");
	  String moneda = request.getParameter("hdn_moneda");
	  Map<String, Object> paramsDetLiqui = new HashMap<String, Object>();
	  paramsDetLiqui.put("rdaduana", params[0]);
	  paramsDetLiqui.put("rdano", params[1]);
	  paramsDetLiqui.put("rdnroliq", params[2]);
//	  List<Detaliq> lstFiltrada = pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl.getInstance().getDetaliqDAO().listByParameterMap(paramsDetLiqui);
//	  swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + params[0]));
//	  List<Detaliq> lstFiltrada = rectificacionServiceImpl.getDetaliqDAO().listByParameterMap(paramsDetLiqui);
	  
	  List<Detaliq> lstFiltrada = liquidaDeclaracionService.getDetalleLiqByParams(paramsDetLiqui);
	  
	  String codCatalogoTrib="TRI";
	  List<HashMap<String,Object>> listaDol = new ArrayList<HashMap<String,Object>>();
      HashMap<String, Object> MapNewD = new HashMap<String, Object>();
      for (int i=0;i<lstFiltrada.size();i++){
    	  String codRub = lstFiltrada.get(i).getRdcodrub().toString()+moneda;
    	  
		  // se comenta pq no funciona DataCatalogo datacatalogoTributo= rectificacionServiceImpl.getCatalogoayudaservice().getDataCatalogo(codCatalogoTrib, codRub);
    	  CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");    		
    	  DataCatalogo datacatalogoTributo= catalogoAyuda.getDataCatalogo(codCatalogoTrib, codRub);
    	  
		  String codtrib = codRub;
		  String descorta = datacatalogoTributo.getDesCorta();
    	  MapNewD = new HashMap<String, Object>();
    	  MapNewD.put("codtrib",codtrib);
    	  MapNewD.put("Concepto",descorta);
    	  MapNewD.put("Monto",lstFiltrada.get(i).getRdmondet());
    	  listaDol.add(MapNewD);
      }	  
	  
	  Map<String,Object> jsonObject1 = new HashMap<String,Object>();
	  if (listaDol.size()>0){
	    		jsonObject1.put("success", true);
	    		jsonObject1.put("items",listaDol);
	    		jsonObject1.put("totalCount",listaDol.size());
	      		}else{
	      			jsonObject1.put("success", false);
	      			jsonObject1.put("items",listaDol);
	      			jsonObject1.put("totalCount",0);	        
	    		}

	  return new ModelAndView("jsonView", jsonObject1);
	  }

  public ModelAndView esValidoGrabarCambios(HttpServletRequest request, HttpServletResponse response){

	  Declaracion declaracion = new Declaracion();
	  Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	  Map deudaDiferencial = (Map)mapCabDeclaraActual.get("diferenciaTributos");
	  declaracion = (Declaracion) liquidaDeclaracionService.convertirMapToObjecto(mapCabDeclaraActual);

	  //pase280 mordonezl
	  boolean tieneGarantia =false;
	  if(declaracion.getDua()!=null && declaracion.getDua().getPago()!=null && declaracion.getDua().getPago().getPagoDeclaracion() != null && !(SunatStringUtils.isEmptyTrim(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia())) ){
		  tieneGarantia = true;

	  }
	  //fin mordonezl

	  // Inicio P46 - 3006
	  String codTipdiligencia = (String)WebUtils.getSessionAttribute(request, "tipoDiligencia");
	  
	  if(esDiligenciaDespacho(codTipdiligencia) // se valida que sea la diligencia de despacho
			  && liquidaDeclaracionService.declaracionTieneTratamientoDonacion(mapCabDeclaraActual) // que la declaracion pertenezca al regimen 10 y tratamiento 4
			  && liquidaDeclaracionService.declaracionTieneIndicadorImpugnacionDonacion(mapCabDeclaraActual)) { // que tenga indicador 06 o 07 (sin documento autorizante)
		  Map<String,Object> model = new HashMap<String,Object>();
		  model.put("message", " ");

		  return new ModelAndView("jsonView", model);
	  }
	  // Fin P46 - 3006
	  
	  //RIN08
	  String acogimientoPostNumPecoAmazonia = (String)WebUtils.getSessionAttribute(request, "acogimientoPostNumPecoAmazonia");
	  //Diligencia de despacho con garantia 160 Debe continuar
	  //Diligencia de despacho con garantia 160 pero ya no cuenta con Peco Amazonia, 
	  if(esDiligenciaDespacho(codTipdiligencia)  && SunatStringUtils.isEqualTo(acogimientoPostNumPecoAmazonia,"SI")){ 
		  if (tieneGarantia){ // || SunatStringUtils.isEqualTo(esPecoAmazonia,"0"){
			  Map<String,Object> model = new HashMap<String,Object>();
			  model.put("message", " ");
			  return new ModelAndView("jsonView", model);
		  }
	  }
	  

	  	  
	  

	  String[] liqSol = {};
	  String[] liqDol = {};

	  if(!request.getParameter("txt_liq_sol").equals(" ") && !request.getParameter("txt_liq_sol").equals(null) && !request.getParameter("txt_liq_sol").equals("")){

		  liqSol=request.getParameter("txt_liq_sol").split(",");  
	  }

	  if(!request.getParameter("txt_liq_dol").equals(" ") && !request.getParameter("txt_liq_dol").equals(null) && !request.getParameter("txt_liq_dol").equals("")){
		  liqDol = request.getParameter("txt_liq_dol").split(",");
	  }

	  List<HashMap<String,Object>> listaDeudaDol = new ArrayList<HashMap<String,Object>>();
	  List<HashMap<String,Object>> listaDeudaSol = new ArrayList<HashMap<String,Object>>();

	  listaDeudaDol.addAll(listaTributosDolares(request,  response));
	  listaDeudaSol.addAll(listaTributosSoles(request,  response));
	  /*RIN13INSI*/
	  // String mensaje = " ";
	  //pase280 mordonezl
	  String   mensaje=" ";//debe ser en blanco el default para que las diligencias no boten error vacio pase192
	  /*RIN08 agreg� && esDiligenciaDespacho(codTipdiligencia)*/
	  	/*INICIO-P34 FSW AFMA*/
	  	if(tieneGarantia && Utilidades.esDiligenciaDespacho(codTipdiligencia)){
		  mensaje = " DUA cuenta con garant�a del art�culo 160�, incidencia debe registrarse en la Conclusi�n del Despacho. \n\r";
	  }
	  	/*INICIO-P34 FSW AFMA*/
	  //fin mordonezl
		      
	  //para dolares	  
	  for(Map<String, Object> dato : listaDeudaDol){

		  String codigoTributo = dato.get("codigo").toString();
		  BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
		  BigDecimal montoAcumuladoTributo = new BigDecimal(0);

		  if(!codigoTributo.equals(" ")){
			  for(int i = 0;i<liqDol.length;i++){

				  String[] datosLiq = liqDol[i].split("-");
				  String codDua = datosLiq[0];
				  String anioDua = datosLiq[1];
				  String nroLiq = datosLiq[2];
				  Detaliq detalleLiq = new Detaliq();
				  detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
				  if(!(detalleLiq == null)){
					  if(!detalleLiq.equals(null)){

						  montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());
					  }
				  }
			  }

			  if(SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)){
				  //pase280
				  Map<String,Object> jsonObject1 = new HashMap<String,Object>();
				  mensaje = mensaje + "Las LC seleccionadas no cubren la deuda en Dolares"; //pase280 mordonezl
				  jsonObject1.put("message", mensaje);
				  //fin 280
				  return new ModelAndView("jsonView", jsonObject1);
			  }
		  }
	  }/*fin for dolares*/


	  //para soles
	  for(Map<String, Object> dato : listaDeudaSol){

		  String codigoTributo = dato.get("codigo").toString();
		  BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
		  BigDecimal montoAcumuladoTributo = new BigDecimal(0);
		  if(!codigoTributo.equals(" ")){
			  for(int i = 0;i<liqSol.length;i++){

				  String[] datosLiq = liqSol[i].split("-");
				  String codDua = datosLiq[0];
				  String anioDua = datosLiq[1];
				  String nroLiq = datosLiq[2];
				  Detaliq detalleLiq = new Detaliq();
				  detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
				  if(!(detalleLiq == null)){
					  if(!detalleLiq.equals(null)){

						  montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());

					  }
				  }
			  }

			  if(SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)){
				  Map<String,Object> jsonObject1 = new HashMap<String,Object>();
				  //pase280
				  mensaje = mensaje + "Las LC seleccionadas no cubren la deuda en Soles"; //pase280 mordonezl
				  jsonObject1.put("message", mensaje);
				  //fin pase280
				  return new ModelAndView("jsonView", jsonObject1);
			  }
		  }
	  }/*fin for soles*/


	  Map<String,Object> jsonObject1 = new HashMap<String,Object>();
	  jsonObject1.put("message", mensaje);//cambio del pase 60 para mostrar mensaje
	  return new ModelAndView("jsonView", jsonObject1);
  }
  
  //Ini P46-PAS20155E410000032
  private void obtieneTributosLiquidaciones(List<HashMap<String,Object>> listaDeudaDol,String[] liqDol,HttpServletRequest request){
	  
	//Dolares
	  Map<String,Object> tributosLiquidaciones = new HashMap<String, Object>();
	  BigDecimal totalTributosLiquidaciones = new BigDecimal(0);
	      //para dolares
	      for(Map<String, Object> dato : listaDeudaDol){
	    	  String codigoTributo = dato.get("codigo").toString();
	    	  String conceptoTributo = dato.get("concepto").toString();
	    	  BigDecimal montoTributo = new BigDecimal(Double.parseDouble(dato.get("monto").toString()));
	    	  BigDecimal montoAcumuladoTributo = new BigDecimal(0);
	    	  if(!codigoTributo.equals(" ")){
		    	  for(int i = 0;i<liqDol.length;i++){
		    		  String[] datosLiq = liqDol[i].split("-");
		    		  String codDua = datosLiq[0];
		    		  String anioDua = datosLiq[1];
		    		  String nroLiq = datosLiq[2];
		    		  Detaliq detalleLiq = new Detaliq();
		    		  detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
		    		  if(!(detalleLiq == null)){
			    		  if(!detalleLiq.equals(null)){
			    			  montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());     
			    		  }
		    		    }
		    	      }
		    		  if(SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)){
		    			  BigDecimal diferenciaTributosLiquidaciones = montoTributo.subtract(montoAcumuladoTributo);
		    			  tributosLiquidaciones.put(conceptoTributo, diferenciaTributosLiquidaciones);
		    			  totalTributosLiquidaciones =  SunatNumberUtils.sum(totalTributosLiquidaciones, diferenciaTributosLiquidaciones);
		    	     }
		    	 }
	    	  }
	     //fin for dolares
    	  WebUtils.setSessionAttribute(request,"tributosLiquidaciones",tributosLiquidaciones);
    	  WebUtils.setSessionAttribute(request,"totalTributosLiquidaciones",totalTributosLiquidaciones);
	  
  }
  //fin P46-PAS20155E410000032

  /*INICIO-P34 FSW AFMA*/

  public ModelAndView esValidoGrabarCambiosParaRectiOficio(HttpServletRequest request, HttpServletResponse response){


    Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map deudaDiferencial = (Map)mapCabDeclaraActual.get("diferenciaTributos");
    Declaracion declaracion = (Declaracion) liquidaDeclaracionService.convertirMapToObjecto(mapCabDeclaraActual);

    //ini P46-PAS20155E410000032 - no se exigen LCs si la donacion esta impugnada en la rectificacion de oficio
    Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
    boolean tieneTratamientoDonacion=liquidaDeclaracionService.declaracionTieneTratamientoDonacion(mapCabDeclaraActual);
    boolean seRetiroTratamientoDonacion= ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(mapCabDeclaraActual.get("COD_REGIMEN")) && !Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) mapCabDeclaraActual.get("COD_TIPTRATMERC"))  &&  Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) mapCabDeclara.get("COD_TIPTRATMERC"));
    ValTratamientoDonacionService valTratamientoDonacion = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");
    boolean notieneCancelacion_0_74_75= !valTratamientoDonacion.declaTieneTipoCancelacion(declaracion);
    boolean registrarCodLibeDonacion = mapCabDeclaraActual.containsKey("registrarCodLibeDonacion")?Boolean.valueOf(mapCabDeclaraActual.get("registrarCodLibeDonacion").toString()):false;
	if(tieneTratamientoDonacion // que la declaracion pertenezca al regimen 10 y tratamiento 4
			&& liquidaDeclaracionService.declaracionTieneIndicadorImpugnacionDonacion(mapCabDeclaraActual)) { // que tenga indicador 06 o 07 (sin documento autorizante)
		Map<String,Object> model = new HashMap<String,Object>();
		model.put("message", " ");
		
		return new ModelAndView("jsonView", model);
	}
	//fin P46-PAS20155E410000032

    String[] liqSol = {};
    String[] liqDol = {};

    if(!request.getParameter("txt_liq_sol").equals(" ") && !request.getParameter("txt_liq_sol").equals(null) && !request.getParameter("txt_liq_sol").equals("")){

      liqSol=request.getParameter("txt_liq_sol").split(",");
    }

    if(!request.getParameter("txt_liq_dol").equals(" ") && !request.getParameter("txt_liq_dol").equals(null) && !request.getParameter("txt_liq_dol").equals("")){
      liqDol = request.getParameter("txt_liq_dol").split(",");
    }

    List<HashMap<String,Object>> listaDeudaDol = new ArrayList<HashMap<String,Object>>();
    List<HashMap<String,Object>> listaDeudaSol = new ArrayList<HashMap<String,Object>>();

    listaDeudaDol.addAll(listaTributosDolares(request,  response));
    listaDeudaSol.addAll(listaTributosSoles(request,  response));

    String   mensaje="";

    //para dolares
    List<Map<String, Object>> lstResumenD = new ArrayList<Map<String, Object>>();
    Map registro = new HashMap();

    BigDecimal montoTotalLiquidadoD = new BigDecimal(0);
    BigDecimal montoTotalLiberadoD = new BigDecimal(0);
    BigDecimal montoTotalPagarD = new BigDecimal(0);
   //Ini P46-PAS20155E410000032
    if(tieneTratamientoDonacion){
    	obtieneTributosLiquidaciones(listaDeudaDol,liqDol,request);	
    }
  //fin P46-PAS20155E410000032
    
    /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
    boolean noCubreDeudaDolaresDonaciones = false;
    String mensajeTributosPendienteCancelacionDolares = "Diferencia de tributos pendiente de cancelaci�n: ";
    /*fin P46-PAS20155E410000032-[jlunah] BUG 24971*/
    
    for(Map<String, Object> dato : listaDeudaDol){

      registro = new HashMap();
      String codigoTributo = dato.get("codigo").toString();
      String nombreTributo = dato.get("concepto").toString();//P46-PAS20155E410000032-[jlunah] BUG 24971
      BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
      BigDecimal montoAcumuladoTributo = new BigDecimal(0);



      if(!codigoTributo.equals(" ")){
        registro.put("codigo", codigoTributo);
        registro.put("concepto", dato.get("concepto").toString());
        for(int i = 0;i<liqDol.length;i++){

          String[] datosLiq = liqDol[i].split("-");
          String codDua = datosLiq[0];
          String anioDua = datosLiq[1];
          String nroLiq = datosLiq[2];
          Detaliq detalleLiq = new Detaliq();
          detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
          if(!(detalleLiq == null)){
            if(!detalleLiq.equals(null)){

              montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());
            }
          }
        }

       // if(SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)){
          //Ini P46-PAS20155E410000032 se agrega validacion de donaciones
          boolean LCsNoCubreDeudaDol=SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo);
          registro.put("liquidacion", montoTributo);
          registro.put("liberacion", montoAcumuladoTributo);
          //registro.put("pagar", SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          registro.put("pagar", LCsNoCubreDeudaDol?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          boolean terminarFlujo=false;
          Map<String,Object> jsonObject1 = new HashMap<String,Object>();
          jsonObject1.put("message"," ");
          if(LCsNoCubreDeudaDol && tieneTratamientoDonacion && registrarCodLibeDonacion){
        	  terminarFlujo=true;
        	  jsonObject1.put("mostrarPantallaResolucion",true);
          } else
          if(LCsNoCubreDeudaDol && (tieneTratamientoDonacion  && notieneCancelacion_0_74_75 )){
        	  /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
        	  noCubreDeudaDolaresDonaciones = true;
        	  mensajeTributosPendienteCancelacionDolares = mensajeTributosPendienteCancelacionDolares + "["+nombreTributo+"]: "+montoTributo+", ";
        	  /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
        	} else
          
          if(LCsNoCubreDeudaDol && seRetiroTratamientoDonacion){
        	  terminarFlujo=true;
			  jsonObject1.put("mostrarPantallaResolucion",true);
          } 
          if(terminarFlujo){
        	  return new ModelAndView("jsonView", jsonObject1);  
          }
        //fin P46-PAS20155E410000032  
          
          lstResumenD.add(registro);

          montoTotalLiquidadoD = SunatNumberUtils.sum(montoTotalLiquidadoD,montoTributo);
          montoTotalLiberadoD = SunatNumberUtils.sum(montoTotalLiberadoD,montoAcumuladoTributo);
          montoTotalPagarD = SunatNumberUtils.sum(montoTotalPagarD, SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
                    
          //return new ModelAndView("jsonView", "lstResumenD", lstResumenD);

        //}
      }else{/*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
    	  
          if(noCubreDeudaDolaresDonaciones){//si se termino de evaluar todos los tibrutos en dolares
        	  Map<String,Object> jsonObjectDonaciones = new HashMap<String,Object>();
        	  jsonObjectDonaciones.put("message"," ");
        	  jsonObjectDonaciones.put("messageValidacion",mensajeTributosPendienteCancelacionDolares.substring(0, mensajeTributosPendienteCancelacionDolares.length()-2)); 
        	  return new ModelAndView("jsonView", jsonObjectDonaciones); 
          }
          /*fin P46-PAS20155E410000032-[jlunah] BUG 24971*/
      }
    }/*fin for dolares*/


    //para soles
    List<Map<String, Object>> lstResumenS = new ArrayList<Map<String, Object>>();

    BigDecimal montoTotalLiquidadoS = new BigDecimal(0);
    BigDecimal montoTotalLiberadoS = new BigDecimal(0);
    BigDecimal montoTotalPagarS = new BigDecimal(0);

    /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
    boolean noCubreDeudaSolesDonaciones = false;
    String mensajeTributosPendienteCancelacionSoles = "Diferencia de tributos pendiente de cancelaci�n: ";
    /*fin P46-PAS20155E410000032-[jlunah] BUG 24971*/
    
    for(Map<String, Object> dato : listaDeudaSol){

      registro = new HashMap();
      String codigoTributo = dato.get("codigo").toString();
      String nombreTributo = dato.get("concepto").toString();//P46-PAS20155E410000032-[jlunah] BUG 24971
      BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
      BigDecimal montoAcumuladoTributo = new BigDecimal(0);
      if(!codigoTributo.equals(" ")){
        registro.put("codigo", codigoTributo);
        registro.put("concepto", dato.get("concepto").toString());
        for(int i = 0;i<liqSol.length;i++){

          String[] datosLiq = liqSol[i].split("-");
          String codDua = datosLiq[0];
          String anioDua = datosLiq[1];
          String nroLiq = datosLiq[2];
          Detaliq detalleLiq = new Detaliq();
          detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
          if(!(detalleLiq == null)){
            if(!detalleLiq.equals(null)){

              montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());

            }
          }
        }

       // if(SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)){
        //Ini P46-PAS20155E410000032  se agrega validacion de donaciones
        boolean LCsNoCubreDeudaSol=SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo);

          registro.put("liquidacion", montoTributo);
          registro.put("liberacion", montoAcumuladoTributo);
          //registro.put("pagar", SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          registro.put("pagar", LCsNoCubreDeudaSol?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          lstResumenS.add(registro);
          montoTotalLiquidadoS = SunatNumberUtils.sum(montoTotalLiquidadoS,montoTributo);
          montoTotalLiberadoS = SunatNumberUtils.sum(montoTotalLiberadoS,montoAcumuladoTributo);
          montoTotalPagarS = SunatNumberUtils.sum(montoTotalPagarS,SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          boolean terminarFlujo=false;
          Map<String,Object> jsonObject1 = new HashMap<String,Object>();
          jsonObject1.put("message"," ");
          if(LCsNoCubreDeudaSol && tieneTratamientoDonacion && registrarCodLibeDonacion){
        	  terminarFlujo=true;
        	  jsonObject1.put("mostrarPantallaResolucion",true);
          } else
          if(LCsNoCubreDeudaSol && (tieneTratamientoDonacion  && notieneCancelacion_0_74_75 )){
        	  /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
        	  noCubreDeudaSolesDonaciones = true;
        	  mensajeTributosPendienteCancelacionSoles = mensajeTributosPendienteCancelacionSoles + "["+nombreTributo+"]: "+montoTributo+", ";
        	  /*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
          } else
          if(LCsNoCubreDeudaSol && seRetiroTratamientoDonacion){
        	  terminarFlujo=true;
			  jsonObject1.put("mostrarPantallaResolucion",true);
          } 
          if(terminarFlujo){
        	  return new ModelAndView("jsonView", jsonObject1);  
          }
        //fin P46-PAS20155E410000032  


          //return new ModelAndView("jsonView", jsonObject1);
        //}
      }else{/*inicio P46-PAS20155E410000032-[jlunah] BUG 24971*/
    	  
          if(noCubreDeudaSolesDonaciones){//si se termino de evaluar todos los tibrutos en dolares
        	  Map<String,Object> jsonObjectDonaciones = new HashMap<String,Object>();
        	  jsonObjectDonaciones.put("message"," ");
        	  jsonObjectDonaciones.put("messageValidacion",mensajeTributosPendienteCancelacionSoles.substring(0, mensajeTributosPendienteCancelacionSoles.length()-2)); 
        	  return new ModelAndView("jsonView", jsonObjectDonaciones); 
          }
          /*fin P46-PAS20155E410000032-[jlunah] BUG 24971*/
      }
    }/*fin for soles*/


    if(montoTotalPagarS.compareTo(BigDecimal.ZERO)>0 || montoTotalPagarD.compareTo(BigDecimal.ZERO)>0){

      Map registroS = new HashMap();
      registroS.put("codigo", "9999");
      registroS.put("concepto", "TOTAL.........:");
      registroS.put("liquidacion", montoTotalLiquidadoS);
      registroS.put("liberacion", montoTotalLiberadoS);
      registroS.put("pagar", montoTotalPagarS);

      lstResumenS.add(registroS);

      Map registroD = new HashMap();
      registroD.put("codigo", "9999");
      registroD.put("concepto", "TOTAL.........:");
      registroD.put("liquidacion", montoTotalLiquidadoD);
      registroD.put("liberacion", montoTotalLiberadoD);
      registroD.put("pagar", montoTotalPagarD);
      lstResumenD.add(registroD);

      ModelAndView res = new ModelAndView(this.jsonView);
      res.addObject("lstResumenD", lstResumenD);
      res.addObject("lstResumenS", lstResumenS);
      
      
      return res;
      
    } else{
      mapCabDeclaraActual.put("grabaPago", "S");
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
      Map<String,Object> jsonObject1 = new HashMap<String,Object>();
      jsonObject1.put("message", " ");
      return new ModelAndView("jsonView", jsonObject1);
    }

  }


  public ModelAndView esValidoGrabarCambiosParaConclusion(HttpServletRequest request, HttpServletResponse response){


    Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map deudaDiferencial = (Map)mapCabDeclaraActual.get("diferenciaTributos");
    Declaracion declaracion = (Declaracion) liquidaDeclaracionService.convertirMapToObjecto(mapCabDeclaraActual);


    String[] liqSol = {};
    String[] liqDol = {};

    if(!request.getParameter("txt_liq_sol").equals(" ") && !request.getParameter("txt_liq_sol").equals(null) && !request.getParameter("txt_liq_sol").equals("")){

      liqSol=request.getParameter("txt_liq_sol").split(",");
    }

    if(!request.getParameter("txt_liq_dol").equals(" ") && !request.getParameter("txt_liq_dol").equals(null) && !request.getParameter("txt_liq_dol").equals("")){
      liqDol = request.getParameter("txt_liq_dol").split(",");
    }

    List<HashMap<String,Object>> listaDeudaDol = new ArrayList<HashMap<String,Object>>();
    List<HashMap<String,Object>> listaDeudaSol = new ArrayList<HashMap<String,Object>>();

    listaDeudaDol.addAll(listaTributosDolares(request,  response));
    listaDeudaSol.addAll(listaTributosSoles(request,  response));

    String   mensaje="";

    //para dolares
    List<Map<String, Object>> lstResumenD = new ArrayList<Map<String, Object>>();
    Map registro = new HashMap();

    BigDecimal montoTotalLiquidadoD = new BigDecimal(0);
    BigDecimal montoTotalLiberadoD = new BigDecimal(0);
    BigDecimal montoTotalPagarD = new BigDecimal(0);

	  //amancilla P21 P22
	  Map<String,Object> detalleLC0010ParaGenerar = new HashMap<String, Object>();

    for(Map<String, Object> dato : listaDeudaDol){

      registro = new HashMap();
      String codigoTributo = dato.get("codigo").toString();
      BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
      BigDecimal montoAcumuladoTributo = new BigDecimal(0);

      if(!codigoTributo.equals(" ")){
        registro.put("codigo", codigoTributo);
        registro.put("concepto", dato.get("concepto").toString());
        for(int i = 0;i<liqDol.length;i++){

          String[] datosLiq = liqDol[i].split("-");
          String codDua = datosLiq[0];
          String anioDua = datosLiq[1];
          String nroLiq = datosLiq[2];
          Detaliq detalleLiq = new Detaliq();
          detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
          if(!(detalleLiq == null)){
            if(!detalleLiq.equals(null)){

              montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());

            }
          }
        }


          registro.put("liquidacion", montoTributo);
          registro.put("liberacion", montoAcumuladoTributo);
          registro.put("pagar", SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          
          lstResumenD.add(registro);

		  //amanncilla P21-P22 tomado de pase 166
		  detalleLC0010ParaGenerar.put(codigoTributo, SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);

          montoTotalLiquidadoD = SunatNumberUtils.sum(montoTotalLiquidadoD,montoTributo);
          montoTotalLiberadoD = SunatNumberUtils.sum(montoTotalLiberadoD,montoAcumuladoTributo);
          montoTotalPagarD = SunatNumberUtils.sum(montoTotalPagarD, SunatNumberUtils.isGreaterThanParam(montoTributo, montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);



      }
    }/*fin for dolares*/


    //para soles
    List<Map<String, Object>> lstResumenS = new ArrayList<Map<String, Object>>();

    BigDecimal montoTotalLiquidadoS = new BigDecimal(0);
    BigDecimal montoTotalLiberadoS = new BigDecimal(0);
    BigDecimal montoTotalPagarS = new BigDecimal(0);

    for(Map<String, Object> dato : listaDeudaSol){

      registro = new HashMap();
      String codigoTributo = dato.get("codigo").toString();
      BigDecimal montoTributo = Utilidades.toBigDecimal(dato.get("monto").toString());
      BigDecimal montoAcumuladoTributo = new BigDecimal(0);
      if(!codigoTributo.equals(" ")){
        registro.put("codigo", codigoTributo);
        registro.put("concepto", dato.get("concepto").toString());
        for(int i = 0;i<liqSol.length;i++){

          String[] datosLiq = liqSol[i].split("-");
          String codDua = datosLiq[0];
          String anioDua = datosLiq[1];
          String nroLiq = datosLiq[2];
          Detaliq detalleLiq = new Detaliq();
          detalleLiq = liquidaDeclaracionService.getDetalleLiqByPrimaryKey(codDua, anioDua, codigoTributo, nroLiq);
          if(!(detalleLiq == null)){
            if(!detalleLiq.equals(null)){

              montoAcumuladoTributo = SunatNumberUtils.sum(montoAcumuladoTributo, detalleLiq.getRdmondet());

            }
          }
        }



          registro.put("liquidacion", montoTributo);
          registro.put("liberacion", montoAcumuladoTributo);
          registro.put("pagar", SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);
          lstResumenS.add(registro);
          montoTotalLiquidadoS = SunatNumberUtils.sum(montoTotalLiquidadoS,montoTributo);
          montoTotalLiberadoS = SunatNumberUtils.sum(montoTotalLiberadoS,montoAcumuladoTributo);
          montoTotalPagarS = SunatNumberUtils.sum(montoTotalPagarS,SunatNumberUtils.isGreaterThanParam(montoTributo,montoAcumuladoTributo)?montoTributo.subtract(montoAcumuladoTributo):BigDecimal.ZERO);

      }
    }/*fin for soles*/


    if(montoTotalPagarS.compareTo(BigDecimal.ZERO)>0 || montoTotalPagarD.compareTo(BigDecimal.ZERO)>0){

      Map registroS = new HashMap();
      registroS.put("codigo", "9999");
      registroS.put("concepto", "TOTAL.........:");
      registroS.put("liquidacion", montoTotalLiquidadoS);
      registroS.put("liberacion", montoTotalLiberadoS);
      registroS.put("pagar", montoTotalPagarS);

      lstResumenS.add(registroS);

      Map registroD = new HashMap();
      registroD.put("codigo", "9999");
      registroD.put("concepto", "TOTAL.........:");
      registroD.put("liquidacion", montoTotalLiquidadoD);
      registroD.put("liberacion", montoTotalLiberadoD);
      registroD.put("pagar", montoTotalPagarD);
      lstResumenD.add(registroD);

		//amancilla si ha seleccionado documento de determinacion de guarda el monto en session (solo lo hicieron para tributos en dolares) paso piola asi por el momento lo copiamos tal cual
		WebUtils.setSessionAttribute(request,"totalTributosLiquidaciones",montoTotalPagarD);
		WebUtils.setSessionAttribute(request,"tributosLiquidaciones",detalleLC0010ParaGenerar);

      ModelAndView res = new ModelAndView(this.jsonView);
      res.addObject("lstResumenD", lstResumenD);
      res.addObject("lstResumenS", lstResumenS);
      
      
      return res;
      
    } else{
      mapCabDeclaraActual.put("grabaPago", "S");
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
      Map<String,Object> jsonObject1 = new HashMap<String,Object>();
      jsonObject1.put("message", " ");
      return new ModelAndView("jsonView", jsonObject1);
    }

  }

  /*FIN-P34 FSW AFMA*/
  public ModelAndView acumulaChek(HttpServletRequest request, HttpServletResponse response) 
  {
	  String[] params=request.getParameter("hdn_cod").split("-");
	  String moneda = request.getParameter("hdn_moneda");
	  Map<String, Object> paramsDetLiqui = new HashMap<String, Object>();
	  paramsDetLiqui.put("rdaduana", params[0]);
	  paramsDetLiqui.put("rdano", params[1]);
	  paramsDetLiqui.put("rdnroliq", params[2]);
	  //List<Detaliq> lstFiltrada = pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl.getInstance().getDetaliqDAO().listByParameterMap(paramsDetLiqui);
	  List<Detaliq> lstFiltrada = liquidaDeclaracionService.getDetalleLiqByParams(paramsDetLiqui);
	  
	  String codCatalogoTrib="TRI";
	  List<HashMap<String,Object>> listaDol = new ArrayList<HashMap<String,Object>>();
      HashMap<String, Object> MapNewD = new HashMap<String, Object>();
      for (int i=0;i<lstFiltrada.size();i++){
    	  String codRub = lstFiltrada.get(i).getRdcodrub().toString()+moneda;

    	  CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");    
    	  DataCatalogo datacatalogoTributo= catalogoAyuda.getDataCatalogo(codCatalogoTrib, codRub);
    	  
		  String codtrib = codRub;
		  String descorta = datacatalogoTributo.getDesCorta();
    	  MapNewD = new HashMap<String, Object>();
    	  MapNewD.put("codtrib",codtrib);
    	  MapNewD.put("Concepto",descorta);
    	  MapNewD.put("Monto",lstFiltrada.get(i).getRdmondet());
    	  listaDol.add(MapNewD);
      }

	  
	  Map<String,Object> jsonObject1 = new HashMap<String,Object>();
	  if (listaDol.size()>0){
	    		jsonObject1.put("success", true);
	    		jsonObject1.put("items",listaDol);
	    		jsonObject1.put("totalCount",listaDol.size());
	      		}else{
	      			jsonObject1.put("success", false);
	      			jsonObject1.put("items",listaDol);
	      			jsonObject1.put("totalCount",0);	        
	    		}

	  return new ModelAndView("jsonView", jsonObject1);
	  }
  
  public static String stringDDMMYYYYToDate(String fecha){
	  String resultado = fecha.substring(6, 8)+"-"+fecha.substring(4, 6)+"-"+fecha.substring(0, 4);
	  return resultado;
  }
  /**
   * Metodo que permite mostrar la PreLiquidacion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView mostrarLiquidacion(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    // Validamos la liquidacion
    try
    {

      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", -1);

      this.liquidarDeclaracion(request);

      // Cargamos la ventana de confirmacion
      Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
      List listaAutoliquidaciones = (List) declaracionActual.get("lstAutoliquidaciones");
      List<Map<String, Object>> lstGarantias = (List<Map<String, Object>>) declaracionActual.get("lstGarantias");
      MovCabliqdilig movCabliqdilig = (MovCabliqdilig) declaracionActual.get("movCabliqdilig");
      // 10 y 70,muestra liquidacion, 20 y 21 muestra liquidacion con garantia
      String paginaLiquida = SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "10,70") ?
          "MuestraLiquidacionPeco" : "MuestraLiquidacionGarantia";
      //String paginaLiquida = SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "10,70") ?
//                "MuestraLiquidacionPeco" : "MuestraLiquidacionGarantiaPeco";
      // Se obtiene el resultado de la Preliquidaci�n

      //String sCodTipDiligencia = declaracionActual.get("codTipdiligencia").toString(); //RIN13?
      log.debug("-->declaracionActual: " + declaracionActual);
      log.debug("-->declaracionActual.codTipdiligencia: " + declaracionActual.get("codTipdiligencia"));
      String sCodTipDiligencia = (String)WebUtils.getSessionAttribute(request, "tipoDiligencia");
      log.debug("-->sCodTipDiligencia: " + sCodTipDiligencia);
      if (SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "20,21")
          && CollectionUtils.isNotEmpty(lstGarantias)
          && SunatStringUtils.isStringInList(sCodTipDiligencia, "02,03"))
      {

        Map<String, Object> mapCabAdiDiligVinc = new HashMap<String, Object>();

        String sCodTipGaranVinc = "";
        BigDecimal bMtoGarantiaVinc = new BigDecimal(0);
        for (Map<String, Object> mapGarantia : lstGarantias)
        {
          sCodTipGaranVinc = mapGarantia.get("CTIPO_GLOESP").toString();
          bMtoGarantiaVinc = bMtoGarantiaVinc.add(new BigDecimal(Double.parseDouble(mapGarantia
              .get("VTVINCU_DOCAFI")
              .toString())));
        }
        mapCabAdiDiligVinc.put("COD_TIPGARANVINC", sCodTipGaranVinc);
        mapCabAdiDiligVinc.put("MTO_GARANTIAVINC", bMtoGarantiaVinc);

        WebUtils.setSessionAttribute(request, "mapCabAdiDiligVinc", mapCabAdiDiligVinc);
      }

      Map resulPreliq = (Map) declaracionActual.get("resulPreliq");
      if ("NO".equals(resulPreliq.get("ERROR")))
      {
        ModelAndView view = new ModelAndView(paginaLiquida, "diferenciaTributos", diferenciaTributos);
        view.addObject("listaAutoliquidaciones", listaAutoliquidaciones);
        view.addObject("movCabliqdilig", movCabliqdilig);
        view.addObject("lstGarantias", lstGarantias);
        view.addObject("hdn_cod_aduana", declaracionActual.get("COD_ADUANA"));
        view.addObject("hdn_ann_presen", declaracionActual.get("ANN_PRESEN").toString());
        view.addObject("hdn_cod_regimen", declaracionActual.get("COD_REGIMEN"));
        view.addObject("grabaLC", declaracionActual.get("grabaLC"));
        view.addObject("habilitarBotonAceptar", declaracionActual.get("habilitarBotonAceptar"));/*PAS20175E220200033*/
        view.addObject("grabaPago", declaracionActual.get("grabaPago"));

        view.addObject("tieneIncTrib", declaracionActual.get("tieneIncTrib"));
        //MOL PASE280
        view.addObject("tieneIncTribMenor", declaracionActual.get("tieneIncTribMenor"));
        //fin
        view.addObject("codTipdiligencia", declaracionActual.get("codTipdiligencia"));

        view.addObject(
            "hdn_num_declaracion",
              Cadena.padLeft(declaracionActual.get("NUM_DECLARACION").toString(), 6, '0'));
        view.addObject(
            "msgActGarantia",
              declaracionActual.get("msgActGarantia") != null ? declaracionActual.get("msgActGarantia") : "");
                 //INICIO-FSW amancilla
/*RIN13INSI*/
          //boolean existeIncidenciaTributaria = declaracionActual.containsKey("tieneIncTrib")?declaracionActual.get("tieneIncTrib").equals("S"):false;
        /*INICIO-P34 FSW AFMA*/
        //if(esDiligenciaDespacho(sCodTipDiligencia) && SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "10,70")){
         if(SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "10,70")){
        /*FIN-P34 FSW AFMA*/

              //view = validacionDiferenciaTributaria(request, response, declaracionActual, view);
        	  view = procesarDatosConIncidenciaTributaria(request, response, declaracionActual,listaAutoliquidaciones, view);
		  //RIN08 INICIO	  
          }else{
        	  if ("10".equals(sCodTipDiligencia)){//si es rectificacion de oficio rin08
        		  view = procesarDatosConIncidenciaTributaria(request, response, declaracionActual,listaAutoliquidaciones, view);
        	  }
          //RIN08 FIN
          }
        return view;
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror(resulPreliq.get("ERROR").toString());
        rBean.setMensajesol("Verificar");
        return new ModelAndView("PagM", "beanM", rBean);
      }

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
  }

  /**
   * Metodo que permite realizar validacion de cruce de Autoliquidaciones vs incidencia tributaria
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return boolean
   * @throws Exception
   *           the exception
   * @author HAGAPITO
   */


public ModelAndView validaAutoliqVsIncTributaria(HttpServletRequest request, HttpServletResponse response) throws Exception{
	  ModelAndView res = new ModelAndView(this.jsonView);
	  ServletWebRequest webRequest = new ServletWebRequest(request);
	  String stliq = webRequest.getParameter("strliq");
	  Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
      String sCodTipDiligencia = declaracionActual.get("codTipdiligencia").toString();
      boolean respuesta = false;
      boolean bpercep   = false;
      String strNomTrib = "";
      String[] strliq = stliq.split(";");
      List lstLiqMarcadas = new ArrayList();
      BigDecimal montoDol = BigDecimal.ZERO;
      BigDecimal montoSol = BigDecimal.ZERO;
      try {
	      for (int i = 0; i < strliq.length; i++){ 
	    	  Map mapLiq = new HashMap();
	    	  //if(!mapLiq.isEmpty()){
	    		  //mapLiq.clear();
	    	  //}
	    	  mapLiq.put("RLADUANA", (String) strliq[i].substring(0, 3));
	    	  mapLiq.put("RLANO", (String) strliq[i].substring(4, 6));
	    	  mapLiq.put("RLNROLIQ", (String) strliq[i].substring(7));
	          //System.out.println(strliq[i].substring(0, 3));
	          //System.out.println(strliq[i].substring(4, 6));
	          //System.out.println(strliq[i].substring(7));
	          lstLiqMarcadas.add(mapLiq);
	          
	      }
	      
	      //inicio hagapito Obtiene datos completos de las liquidaciones marcadas para luego setearlo en session
	      List<Liquida> lstliquidaMarcadas = this.liquidaDeclaracionService.obtieneLiquidacionesMarcadas(lstLiqMarcadas);
	      
	      WebUtils.setSessionAttribute(request, "lstliquidaMarcadas", lstliquidaMarcadas);
	      // fin hagapito

	      List lstAutoliqVsIncidenciaTrib = this.liquidaDeclaracionService.autoliquidacionesCubrenTributosProductoDeDiligencia(declaracionActual, diferenciaTributos, sCodTipDiligencia, lstLiqMarcadas);
		  
	      if(lstliquidaMarcadas.size() == 1){
	    	  for (int i = 0; i < lstliquidaMarcadas.size(); i++) {
	    		Liquida liq =  lstliquidaMarcadas.get(i);
	    		if(liq.getRltipliq().equals("0038")){
	    			bpercep = true;
	    		}
	    	  }
	      }
	      
	      if(lstAutoliqVsIncidenciaTrib != null){
		     if(lstAutoliqVsIncidenciaTrib.size() > 0){
			    respuesta = true;
			    for (int i = 0; i < lstAutoliqVsIncidenciaTrib.size(); i++) {
			    	Map diferenciaAutoliq = new HashMap();
			    	diferenciaAutoliq = (Map) lstAutoliqVsIncidenciaTrib.get(i);
			    	strNomTrib = (String) diferenciaAutoliq.get("NOMBRE");
			    	if("S".equals(((String)diferenciaAutoliq.get("MONEDA")))){
			    		montoSol = montoSol.add((BigDecimal) diferenciaAutoliq.get("DIFERENCIA"));
			    	}
			    	if("D".equals(((String)diferenciaAutoliq.get("MONEDA")))){
			    		montoDol = montoDol.add((BigDecimal) diferenciaAutoliq.get("DIFERENCIA"));
			    	}
				}
			 }
		  }
      }catch (Exception e){
         e.printStackTrace();
      }
      res.addObject("validar", respuesta);
      if(bpercep){
    	  res.addObject("nombre", strNomTrib);  	  
      }else{
    	  res.addObject("nombre", "");
      }
      res.addObject("montoDol", montoDol);
      res.addObject("montoSol", montoSol);
      return res;
  }

/*RIN13INSI*/
    /*private  ModelAndView validacionDiferenciaTributaria(HttpServletRequest request,
                                                               HttpServletResponse response, Map declaracionActual, ModelAndView view)
    {

        String grabaPago = declaracionActual.get("grabaPago")!=null?declaracionActual.get("grabaPago").toString():"";

        String error ="";
        if("N".equals(grabaPago)){ //si no graab es que no cubre por algun tributo
            error =  validaPercecpionIVG (declaracionActual);

            view.addObject("mensajeDiferencia",error);
        }


        return view;
    }*/


    private boolean esDiligenciaDespacho(String codTipdiligencia){

        return (codTipdiligencia.equals(COD_DILIG_REV_DOC) || codTipdiligencia.equals(COD_DILIG_REC_FIS))?true:false;
    }
  //RIN13
  public String validaPercecpionIVG (Map<String, Object> declaracionActual){
	  String mensaje="";
	  	  
	  HashMap diferenciaTributos =(HashMap) declaracionActual.get("diferenciaTributos");
	  List lstAutoliquidaciones = (List) declaracionActual.get("lstAutoliquidaciones");
	  
	  //boolean faltaCancelar = false;
	  BigDecimal montoTotal = new BigDecimal(0);
	  BigDecimal montoPercepcion = (BigDecimal)diferenciaTributos.get("MPERCEP");
	  
	  BigDecimal montoDiferenciTributos = (BigDecimal)diferenciaTributos.get("MTO_TOTAL");
	  
	  
	  if (CollectionUtils.isEmpty(lstAutoliquidaciones)){
	        mensaje= "Diferencia de tributos pendientes de cancelar";		
	  }else{
		  if (tieneLCPercepcion(lstAutoliquidaciones) && montoPercepcion.compareTo(BigDecimal.ZERO) > 0)
	  {
		   for (int i = 0; i<lstAutoliquidaciones.size(); i++){
				Liquida liquida = (Liquida)lstAutoliquidaciones.get(i);
				//falta agregar la 26 0096
				if (liquida.getRltipliq().equals("0038") && liquida.getRlcodmon().equals("S"))  {
					montoTotal = montoTotal.add(liquida.getRlsmontot());
			   }
		   }

		   if (montoPercepcion.compareTo(montoTotal) > 0)
		   {
			   mensaje= "Monto autoliquidado no cubre el diferencial de tributos por percepci�n, el monto faltante es:  "+ montoPercepcion.subtract(montoTotal)+ "  nuevos soles";
				   			
			   }		 		
		   }
		  		  
		  BigDecimal montoTotalAutoliquidacionTributo = obtenerMonto(lstAutoliquidaciones);
		  
		  if (montoDiferenciTributos.compareTo(montoTotalAutoliquidacionTributo) > 0){

			  if(!SunatStringUtils.isEmptyTrim(mensaje)){
				  mensaje= mensaje+"\nMonto autoliquidado no cubre el diferencial de tributos, el monto faltante es: "+montoDiferenciTributos.subtract(montoTotalAutoliquidacionTributo)+" dolares";  
			  }else{
				  mensaje= "Monto autoliquidado no cubre el diferencial de tributos, el monto faltante es: "+montoDiferenciTributos.subtract(montoTotalAutoliquidacionTributo)+" dolares";
			  }
			  
		  }
		  
		  /*
		  else{    	
	    	mensaje = "Monto autoliquidado no cubre el diferencial de tributos";
	    }*/
  		  
    }

    return mensaje;
}
  private BigDecimal obtenerMonto(List listaAutoliquidaciones){
  
  
	 BigDecimal totalAutoliqDolares = BigDecimal.ZERO;
	 
     
     
      if (listaAutoliquidaciones.size()>0) {
        for (int i=0; i<listaAutoliquidaciones.size(); i++) {
                       Liquida liquida = (Liquida) listaAutoliquidaciones.get(i);
                       if(!liquida.getRltipliq().equals("0027")){
                                       if (liquida.getRlcodmon().equals("D")) {
                                                       totalAutoliqDolares = totalAutoliqDolares.add(liquida.getRldmontot());
                                       }
                       }
        }
     } 

      return totalAutoliqDolares;
	  
  }
  private boolean tieneLCPercepcion(List lstAutoliquidaciones){
	  boolean rspta= false;
	  
	  if (CollectionUtils.isEmpty(lstAutoliquidaciones)){
		  return false;
		  
	  }
	  
	  for (int i = 0; i<lstAutoliquidaciones.size(); i++){
			Liquida liquida = (Liquida)lstAutoliquidaciones.get(i);
			if (liquida.getRltipliq().equals("0038") && liquida.getRlcodmon().equals("S"))  {
				rspta=true;
				break;
		   }
	   }
	  
	  return rspta;
  }
	//INICIO-FSW
private  ModelAndView procesarDatosConIncidenciaTributaria(HttpServletRequest request,
		HttpServletResponse response, Map declaracionActual,
		List listaAutoliquidaciones, ModelAndView view) 
{
	    	   
	    	//Juan zevallos
	        List<HashMap<String,Object>> listaDeudaDol = new ArrayList<HashMap<String,Object>>();
	        List<HashMap<String,Object>> listaDeudaSol = new ArrayList<HashMap<String,Object>>();
	        
	        listaDeudaDol.addAll(listaTributosDolares(request,  response));
	        listaDeudaSol.addAll(listaTributosSoles(request,  response));
	        
	
	        //envia las autolIquidaciones soles rlcodmon S � D		        		       
		        BigDecimal totalAutoliqDolares = BigDecimal.ZERO;
		    	BigDecimal totalAutoliqSoles = BigDecimal.ZERO;
		        
		        List<Liquida> lista = listaAutoliquidaciones;
		        List<Liquida> listaD = new ArrayList<Liquida>();
		        List<Liquida> listaS = new ArrayList<Liquida>();
		        List<Liquida> lista027S = new ArrayList<Liquida>();
		        List<Liquida> lista027D = new ArrayList<Liquida>();
	    	Date fecLevante=declaracionActual.containsKey("FEC_AUTLEVANTE")?(Date)declaracionActual.get("FEC_AUTLEVANTE"):null;//adicionado por bug 18768 
		        
		        for (int j=0;j<lista.size();j++){
			       	if (!lista.get(j).getRltipliq().equals("0027")){
				        String moneda=lista.get(j).getRlcodmon();
				        if (moneda.equals("D")){
				        	totalAutoliqDolares = totalAutoliqDolares.add(lista.get(j).getRldmontot());
				        	listaD.add(lista.get(j));				        	
				        }
				        else{
					        	if(fecLevante!=null && !SunatDateUtils.sonIguales(fecLevante, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
					        		if(!lista.get(j).getRltipliq().equals("0096")){
				        	listaS.add(lista.get(j));
				        	totalAutoliqSoles = totalAutoliqSoles.add(lista.get(j).getRlsmontot());
				        }
					        	}else{
					        		listaS.add(lista.get(j));
					        		totalAutoliqSoles = totalAutoliqSoles.add(lista.get(j).getRlsmontot());
					        	}
					        }	 
			        }
			       	else{
			       		//tipo 27
			       		String moneda=lista.get(j).getRlcodmon();
			       		if (moneda.equals("D")){
				        	lista027D.add(lista.get(j));
				        	totalAutoliqDolares = totalAutoliqDolares.add(lista.get(j).getRldmontot());
				        }
				        else{
				        	lista027S.add(lista.get(j));
				        	totalAutoliqSoles = totalAutoliqSoles.add(lista.get(j).getRlsmontot());
				        }
			       	}
		        }
	
		        view.addObject("totalAutoliqDolares", totalAutoliqDolares);
		        view.addObject("totalAutoliqSoles", totalAutoliqSoles);//pruizcr peco 2018 se valida la llegada de valores nulos.
		        String habilitarBotonOK = declaracionActual.get("habilitarBotonAceptar")!=null?declaracionActual.get("habilitarBotonAceptar").toString():"";
		        boolean habilitarBotonAceptar = (habilitarBotonOK.equals("true") ? true : false);
		        
		        /*inicio P28-PAS20155E410000032-[jlunah] */
		        //Caso BUG 3348 en Jira
		        boolean cubreDeudaDolares = false;
		        boolean cubreDeudaSoles = false;
		        
		        if(!habilitarBotonAceptar){
		        	//Evaluamos si las LCs tanto en dolares como en soles cubren la deuda. (A nivel de cabecera - tabla liquida)
		        	//Para dolares
		        	BigDecimal totalDeudaDolares = BigDecimal.ZERO;
		        	for(Map <String,Object> deudaDol : listaDeudaDol){
		        		if(deudaDol.get("codigo").toString().trim().equals("") && deudaDol.get("concepto").toString().equals("TOTAL")){//cuando el codigo es igual a "" entonces este contiene la suma de toda la deuda en su moneda
		        			totalDeudaDolares = new BigDecimal(deudaDol.get("monto").toString());
		        		}
		        	}
		        	if(totalAutoliqDolares.compareTo(totalDeudaDolares) >= 0){//quiere decir que las LCs en dolares cubre total de deuda en dolares
		        		cubreDeudaDolares = true;
		        	}
		        	
		        	//Para soles
		        	BigDecimal totalDeudaSoles = BigDecimal.ZERO;
		        	for(Map <String,Object> deudaSol : listaDeudaSol){
		        		if(deudaSol.get("codigo").toString().trim().equals("") && deudaSol.get("concepto").toString().equals("TOTAL")){//cuando el codigo es igual a "" entonces este contiene la suma de toda la deuda en su moneda
		        			totalDeudaSoles = new BigDecimal(deudaSol.get("monto").toString());
		        		}
		        	}
		        	if(totalAutoliqSoles.compareTo(totalDeudaSoles) >= 0){//quiere decir que las LCs en soles cubre total de deuda en soles
		        		cubreDeudaSoles = true;
		        	}
		        	
		        	if(cubreDeudaDolares && cubreDeudaSoles){
		        		habilitarBotonAceptar = true;
		        	}
		        }
		        /*fin P28-PAS20155E410000032-[jlunah] */
		        
		        view.addObject("habilitarBotonAceptar", habilitarBotonAceptar);
		        
		        String mensajeDiferencia =   declaracionActual.get("mensajeDiferenciaTributos")!=null?declaracionActual.get("mensajeDiferenciaTributos").toString():"";

                /*INICIO-P34 FSW AFMA*/
                 view.addObject("indicadorReliquidacion",declaracionActual.get("indicadorReliquidacion")!=null?declaracionActual.get("indicadorReliquidacion").toString():"N");
                /*FIN-P34 FSW AFMA*/

                 /*inicio P46-PAS20155E410000032[jlunah] BUG 3793*/
                 view.addObject("seRetiroTratamientoDonacion", seRetiroTratamientoDonacion(request,response));
                 /*fin P46-PAS20155E410000032[jlunah] BUG 3793*/
                 //P_SNADE008-3821 - Para Caso IV, si la declaraci�n cuenta con tipo de cancelaci�n �73�, cuenta con levante
    			 //y se haya eliminado el Tipo de Indicador de Impugnaci�n �06� o �07�...aca tambien debe ver documento de determinacion si asi fuera

        		//registrarCodLibeDonacion: si es true implica que la declaracion es de regimen 10, de donacion,
        		//estuvo impugnada, tiene levante, tiene cancelacion 73 y el usuario quiere regularizar la donacion
          		boolean registrarCodLibeDonacion = declaracionActual.get("registrarCodLibeDonacion") != null && (Boolean)declaracionActual.get("registrarCodLibeDonacion");
     			if(registrarCodLibeDonacion){
                	 view.addObject("seRetiroTratamientoDonacion", true);
                 }
		        view.addObject("mensajeDiferencia",SojoUtil.toJson(mensajeDiferencia.trim()));	 
		    view.addObject("jsonViewLCSol",obtenerJson(listaS,"S"));		      			      	
		    view.addObject("jsonViewLCDol",obtenerJson(listaD,"D"));		        		
	      	view.addObject("jsonViewDeudaDol",obtenerJsonLista(listaDeudaDol));	      		      		      	
	      	view.addObject("jsonViewDeudaSol",obtenerJsonLista(listaDeudaSol));

			//PAS20155E220000166 - Inicio
			Garantia160Service garantia160Service = fabricaDeServicios.getService("diligencia.ingreso.garantia160Service");
			Declaracion declaracion = new Declaracion();
			Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
			declaracion = (Declaracion) liquidaDeclaracionService.convertirMapToObjecto(mapCabDeclaraActual);
			view.addObject("tieneGarantia", garantia160Service.duaSiTieneGarantia160(declaracion));
			Map<String, Object> map = (HashMap) declaracionActual.get("diferenciaTributos");
			view.addObject("diferenciaTributosMayor", map.get("diferenciaTributosMayor"));
			view.addObject("tieneAutoliquidacionesD", listaD.isEmpty()?false:true);
			view.addObject("tieneAutoliquidacionesS", listaS.isEmpty()?false:true);
			//PAS20155E220000166 - Fin

	 return view;     	
}

//INICIO-FSW
private String obtenerJson(List<Liquida> listaLiquida,String tipoModeda){
	
	
    List<HashMap<String,Object>> lista = new ArrayList<HashMap<String,Object>>();
    HashMap<String, Object> MapNew = new HashMap<String, Object>();
    
    for (int i=0;i<listaLiquida.size();i++){
    	MapNew = new HashMap<String, Object>();
    	MapNew.put("numero",listaLiquida.get(i).getRladuana()+"-"+listaLiquida.get(i).getRlano()+"-"+listaLiquida.get(i).getRlnroliq());
    	MapNew.put("tipliq",listaLiquida.get(i).getRltipliq());
    	MapNew.put("fecliq",stringDDMMYYYYToDate(String.valueOf(listaLiquida.get(i).getRlfecliq())));
    	if(listaLiquida.get(i).getRlfeccan()!=null && !listaLiquida.get(i).getRlfeccan().equals(0)){
      	MapNew.put("feccan",stringDDMMYYYYToDate(String.valueOf(listaLiquida.get(i).getRlfeccan())));
    	}else{
    	  MapNew.put("feccan"," ");
    	}
    	MapNew.put("monpagso",("D".equals(tipoModeda))?listaLiquida.get(i).getRldmontot():listaLiquida.get(i).getRlsmontot());
    	lista.add(MapNew);
    }  
	  	  	 	
	 return obtenerJsonLista(lista); 
}
private String obtenerJsonLista(List<HashMap<String,Object>> lista){
		
			  
	Map<String,Object> jsonObject1 = new HashMap<String,Object>();
 	
	if(lista.size()>0){
		jsonObject1.put("success", true);
		jsonObject1.put("items",lista);
		jsonObject1.put("totalCount",lista.size());
 		}else{
 			jsonObject1.put("success", false);
 			jsonObject1.put("items",lista);
 			jsonObject1.put("totalCount",0);	        
		}
	
	 return SojoUtil.toJson(jsonObject1); 
}
private List<HashMap<String,Object>> listaTributosDolares(HttpServletRequest request, HttpServletResponse response){
	  
	  Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
    
	  List<HashMap<String,Object>> listaDeudaDol = new ArrayList<HashMap<String,Object>>();
   
	        HashMap<String,Object> MapDeuda = new HashMap<String,Object>();	
	    	//amancilla parche
	        CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");    
	        List<Map<String,String>> catalogoTributos=catalogoAyuda.getElementosCat("TRI");
	        
	        
	        MapDeuda.put("concepto","ADVALOREM");
	        MapDeuda.put("monto", diferenciaTributos.get("MADV").toString());
			MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MADV"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "ISC");
	        MapDeuda.put("monto", diferenciaTributos.get("MISC").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MISC"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "IGV");
	        MapDeuda.put("monto", diferenciaTributos.get("MIGV").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MIGV"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "IPM");
	        MapDeuda.put("monto", diferenciaTributos.get("MIPM").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MIPM"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "DERECHO ESPECIFICO");
	        MapDeuda.put("monto", diferenciaTributos.get("MDES").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MDES"));
	        listaDeudaDol.add(MapDeuda);
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "ANTIDUMPING");
	        MapDeuda.put("monto", diferenciaTributos.get("MADUM").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MADUM"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "SERVICIO DE DESPACHO ADUANERO");
	        MapDeuda.put("monto", diferenciaTributos.get("MTSERV").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MTSERV"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "IPM ADICIONAL");
	        MapDeuda.put("monto", diferenciaTributos.get("MIPMA").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MIPMA"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "SOBRETASA ADICIONAL");
	        MapDeuda.put("monto", diferenciaTributos.get("MSAD").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MSAD"));
	        listaDeudaDol.add(MapDeuda);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "INTERESES");
	        MapDeuda.put("monto", diferenciaTributos.get("MINTE").toString());
	        MapDeuda.put("codigo", obtieneCodigoTributo(catalogoTributos, "MINTE"));
	        listaDeudaDol.add(MapDeuda);
	           
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "TOTAL");
	        MapDeuda.put("monto", diferenciaTributos.get("MTO_TOTAL").toString());
	        MapDeuda.put("codigo", " ");
	        listaDeudaDol.add(MapDeuda);
	        
	        return listaDeudaDol;
	        
}
private List<HashMap<String,Object>> listaTributosSoles(HttpServletRequest request, HttpServletResponse response){
	  
	  Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
    
    List<HashMap<String,Object>> listaDeudaSol = new ArrayList<HashMap<String,Object>>();
   
	        HashMap<String,Object> MapDeuda = new HashMap<String,Object>();	
	        
	        //amancilla parche
	        CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");    
	        List<Map<String,String>> catalogoTributos=catalogoAyuda.getElementosCat("TRI");

	        //Conceptos en deudas en soles
	        HashMap<String,Object> MapDeudaS = new HashMap<String,Object>();
	        MapDeudaS.put("concepto","PERCEPCION DEL IGV");
	        MapDeudaS.put("monto", diferenciaTributos.get("MPERCEP").toString());
	        MapDeudaS.put("codigo", obtieneCodigoTributo(catalogoTributos, "MPERCEP"));
	        listaDeudaSol.add(MapDeudaS);
	        
	        MapDeudaS = new HashMap<String,Object>();	
	        MapDeudaS.put("concepto",  "IGV");
	        MapDeudaS.put("monto", diferenciaTributos.get("MSIGV").toString());
	        MapDeudaS.put("codigo", obtieneCodigoTributo(catalogoTributos, "MSIGV"));
	        listaDeudaSol.add(MapDeudaS);
	        
	        MapDeudaS = new HashMap<String,Object>();	
	        MapDeudaS.put("concepto",  "ISC");
	        MapDeudaS.put("monto", diferenciaTributos.get("MSISC").toString());
	        MapDeudaS.put("codigo", obtieneCodigoTributo(catalogoTributos, "MSISC"));
	        listaDeudaSol.add(MapDeudaS);
	        
	        MapDeudaS = new HashMap<String,Object>();	
	        MapDeudaS.put("concepto",  "IPM");
	        MapDeudaS.put("monto", diferenciaTributos.get("MSIPM").toString());
	        MapDeudaS.put("codigo", obtieneCodigoTributo(catalogoTributos, "MSIPM"));
	        listaDeudaSol.add(MapDeudaS);
	        
	        MapDeuda = new HashMap<String,Object>();	
	        MapDeuda.put("concepto",  "TOTAL");
	        MapDeuda.put("monto", diferenciaTributos.get("MTO_TOTAL_SOL").toString());
	        MapDeuda.put("codigo", " ");
	        listaDeudaSol.add(MapDeuda);
	        
	        return listaDeudaSol;
	        
}

private String obtieneCodigoTributo(List<Map<String, String>> catalogoTributos, String  descripCorta){
	  
	  for(Map<String,String> tributoBD:catalogoTributos){
			if(tributoBD.get("des_corta").equals(descripCorta)){
				//String tipoMoneda = tributoBD.get("cod_datacat").substring(4, 5);		//Ejm : D
				String codigoTributo = tributoBD.get("cod_datacat").substring(0, 4); //Ejm : 0001
				return codigoTributo;
			}
		}
	  
	  return " ";
}
  /***********************SET DE SPRING **********************************/
    /*inicio P46-PAS20155E410000032[jlunah] BUG 3793*/
	public boolean seRetiroTratamientoDonacion(HttpServletRequest request, HttpServletResponse response){

	    Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	    Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
	    boolean seRetiroTratamientoDonacion= ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(mapCabDeclaraActual.get("COD_REGIMEN")) && !Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) mapCabDeclaraActual.get("COD_TIPTRATMERC"))  &&  Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) mapCabDeclara.get("COD_TIPTRATMERC"));
		return seRetiroTratamientoDonacion; 
  }
   /*fin P46-PAS20155E410000032[jlunah] BUG 3793*/



  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }

  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }
  
  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
	this.fabricaDeServicios = fabricaDeServicios;
  }

//RIN08 INICIO
public void setDiligenciaService(DiligenciaService diligenciaService) {
	this.diligenciaService = diligenciaService;
}
//RIN08 FIN

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

}
