/* P14 - 3006 - Inicio - lrodriguezc */
/* CUS: 3006-02 - Migrado - Rin 13 - Inicio - lrodriguezc */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP; //p24-PAS20165E220200099
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP; //p24-PAS20165E220200099

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl; //p24-PAS20165E220200099
import pe.gob.sunat.despaduanero2.declaracion.model.DUA; 
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores; //p24-PAS20165E220200099
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SeriesProrrateadasBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFleteYPesoPorDocTransporteBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionCalculoDeDatosService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ValidaDiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.WUtil;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo; //p24-PAS20165E220200099
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.declaracion.service.ObservacionService;//p24-PAS20165E220200099
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;//p24-PAS20165E220200099
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;//p24-PAS20165E220200099
import pe.gob.sunat.recauda2.garantia.service.PadronUsuarioService;//RIN 10 ERUESTAA - p24-PAS20165E220200099
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService; //p24-PAS20165E220200099
/**
 * <p>
 * Titulo: Controlador Web para el mantenimiento de la declaracion,
 * series,facturas e item de factura
 * </p>
 * <p>
 * Descripcion: Controlador que administra las funcionalidades de mantenimiento
 * para Fomato A y Formato B
 * </p>
 * 
 * @author rmontes,rdelosreyes,wmostacero,lsuclupe,tomas,scallata
 * @since 08-sep-09
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DescargaParcialDespachoController extends AbstractDespachoController {

	private static final String IND_REGISTRO_GRABADO = "0";

	private DeclaracionService declaracionService;

	private SoporteService soporteService;

	private FormatoValorService formatoValorService;

	private ValidaDiligenciaService validaDiligenciaService;

	private RectificacionService rectificacionService;

	private SerieService serieService;

	private DeclaracionCalculoDeDatosService declaracionCalculoDeDatos;
		
	/* pase 309 */
	private GetDeclaracionService getDeclaracionService;
	/* fin */
	// PAS20144E620000103 - cpuente

	private static final String PAGINA_PRINCIPAL_DETALLE = "oficio/RegSerieOficio";
	
	private PadronUsuarioService padronUsuarioService; //P24 - PAS20165E220200099
	private LiquidaDeclaracionService liquidaDeclaracionService; //P24 - PAS20165E220200099
	String lisdatoMsj = new String();
	FabricaDeServicios fabricaDeServicios; //p24-PAS20165E220200099

	/**
	 * Metodo que carga la informacion completa de la Dua de Session y la Dua
	 * Original.
	 * 
	 * @param declaracion
	 *            the declaracion
	 * @param declaracionActual
	 *            the declaracion actual
	 * @author jlunah
	 */
	public void cargaFormatoBCompleto(Map<String, Object> declaracion,
			Map<String, Object> declaracionActual) {

		List<Map> lstActualProveedor = new ArrayList();
		List<Map> lstFormBProveedor = (ArrayList) declaracionActual
				.get("lstFormBProveedor");
		if (lstFormBProveedor == null) {
			Map<String, Object> pFormBP = new HashMap<String, Object>();
			pFormBP.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
			lstFormBProveedor = this.formatoValorService
					.obtenerFVProveedores(pFormBP);
			if (lstFormBProveedor != null && lstFormBProveedor.size() > 0) {
				for (Map prov : lstFormBProveedor) {
					prov.put("num_corredoc",
							declaracionActual.get("NUM_CORREDOC"));
				}
			}

			lstActualProveedor = Utilidades.copiarLista(lstFormBProveedor);
			declaracion.put("lstFormBProveedor", lstFormBProveedor);
			declaracionActual.put("lstFormBProveedor", lstActualProveedor);
		}

		if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
			declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
		else
			declaracionActual.put("IND_FORMBPROVEEDOR", "1");

		if (lstActualProveedor != null) {
			for (Map prov : lstActualProveedor) {
				Map<String, Object> params = new HashMap<String, Object>();
				String num_secprove = prov.get("num_secprove").toString();
				params.put("NUM_CORREDOC",
						declaracionActual.get("NUM_CORREDOC"));
				params.put("NUM_SECPROVE", num_secprove);

				List<Map> lstFacturas = (List) prov.get("lstComproBPago");
				if (lstFacturas == null || lstFacturas.size() == 0) {
					lstFacturas = this.formatoValorService
							.obtenerFacturasProveedor(params);

					if (lstFacturas != null && lstFacturas.size() > 0) {
						colocarLstFacturas(declaracion, lstFacturas,
								num_secprove);
						colocarLstFacturas(declaracionActual, lstFacturas,
								num_secprove);
					}
				}

				Map<String, Object> mapa = null;
				for (Map compPag : lstFacturas) {
					String num_secfact = compPag.get("num_secfact").toString();
					params.remove("NUM_SECITEM");
					params.put("NUM_SECFACT", num_secfact);
					List<Map<String, Object>> lstItemFactura = (ArrayList) compPag
							.get("lstItemFactura");
					if (lstItemFactura == null) {
						Map<String, String> pkFact = new HashMap<String, String>();
						pkFact.put("NUM_CORREDOC", params.get("NUM_CORREDOC")
								.toString());
						pkFact.put("NUM_SECPROVE", params.get("NUM_SECPROVE")
								.toString());
						pkFact.put("NUM_SECFACT", params.get("NUM_SECFACT")
								.toString());
						pkFact.put("caduana", declaracion.get("COD_ADUANA")
								.toString());

						mapa = formatoValorService.obtenerFormatoBItem(pkFact);
						lstItemFactura = (List<Map<String, Object>>) mapa
								.get("lstItemFactura");

						colocarLstItemFacturas(declaracion, lstItemFactura,
								num_secprove, num_secfact);
						colocarLstItemFacturas(declaracionActual,
								lstItemFactura, num_secprove, num_secfact);
					}

					for (Map mpItem : lstItemFactura) {
						String num_secItem = mpItem.get("NUM_SECITEM")
								.toString();
						params.put("NUM_SECITEM", num_secItem);
						List lstSeriesItem = (ArrayList) mpItem
								.get("lstSeriesItem");
						if (lstSeriesItem == null) {
							lstSeriesItem = serieService
									.obtenerSeriesItem(params);
							colocarLstSerieItem(declaracion, lstSeriesItem,
									num_secprove, num_secfact, num_secItem);
							colocarLstSerieItem(declaracionActual,
									lstSeriesItem, num_secprove, num_secfact,
									num_secItem);
						}

						List<Map<String, Object>> lstReferenciaDuda = null;
						lstReferenciaDuda = (List<Map<String, Object>>) mapa
								.get("lstReferenciaDuda");
						if (lstReferenciaDuda != null
								&& lstReferenciaDuda.size() > 0) {
							for (Map<String, Object> mapaReferencia : lstReferenciaDuda) {
								// LA serie es la misma de la lista de items
								if (mpItem
										.get("NUM_SECITEM")
										.toString()
										.trim()
										.equals(mapaReferencia
												.get("NUM_SECITEM").toString()
												.trim())) {
									// No se posee lista de Series Item
									if (mpItem.get("lstReferenciaDuda") == null) {
										mpItem.put(
												"lstReferenciaDuda",
												new ArrayList<Map<String, Object>>());
										((List<Map<String, Object>>) mpItem
												.get("lstReferenciaDuda"))
												.add(mapaReferencia);
									} else {
										((List<Map<String, Object>>) mpItem
												.get("lstReferenciaDuda"))
												.add(mapaReferencia);
									}
								}
							}
						}

					}

				}

			}
		}

	}

	/**
	 * Metodo que agrage la lista de Serie Items en el Objeto de la Declaracion
	 * para un proveedor , factura e item correspondiente.
	 * 
	 * @param declaracion
	 *            the declaracion
	 * @param lstSerieItem
	 *            the lst serie item
	 * @param num_secprove
	 *            the num_secprove
	 * @param num_secfact
	 *            the num_secfact
	 * @param num_secitem
	 *            the num_secitem
	 * @author jlunah
	 */
	private void colocarLstSerieItem(Map declaracion, List lstSerieItem,
			String num_secprove, String num_secfact, String num_secitem) {
		if (declaracion != null && declaracion.size() > 0) {
			List<Map> lstProve = (ArrayList) declaracion
					.get("lstFormBProveedor");

			String codProv;
			String secFact;
			String sectItem;
			List lstSerieItemfactAsig = new ArrayList();
			for (Map prov : lstProve) {
				codProv = prov.get("num_secprove").toString().trim();
				if (codProv.equals(num_secprove)) {
					List<Map> lstComproBPago = (ArrayList<Map>) prov
							.get("lstComproBPago");
					for (Map comPago : lstComproBPago) {
						secFact = comPago.get("num_secfact").toString().trim();
						if (secFact.equals(num_secfact)) {
							List<Map> lstItemfact = (ArrayList<Map>) comPago
									.get("lstItemFactura");
							for (Map item : lstItemfact) {
								sectItem = item.get("NUM_SECITEM").toString()
										.trim();
								if (sectItem.equals(num_secitem)) {
									lstSerieItemfactAsig = Utilidades
											.copiarLista(lstSerieItem);
									item.put("lstSeriesItem",
											lstSerieItemfactAsig);
									break;
								}
							}
						}
					}

				}
			}

		}
	}

	/**
	 * Metodo que agrage la lista de Items Factura en el Objeto de la
	 * Declaracion para en la seccion de Proveedor y Factura correspondiente.
	 * 
	 * @param declaracion
	 *            the declaracion
	 * @param lstItemFacturas
	 *            the lst item facturas
	 * @param num_secprove
	 *            the num_secprove
	 * @param num_secfact
	 *            the num_secfact
	 * @author jlunah
	 */
	private void colocarLstItemFacturas(Map declaracion, List lstItemFacturas,
			String num_secprove, String num_secfact) {
		if (declaracion != null && declaracion.size() > 0) {
			List<Map> lstProve = (ArrayList) declaracion
					.get("lstFormBProveedor");

			String codProv;
			String secFact;
			List lstItemfactAsig = new ArrayList();
			for (Map prov : lstProve) {
				codProv = prov.get("num_secprove").toString().trim();
				if (codProv.equals(num_secprove)) {
					List<Map> lstComproBPago = (ArrayList<Map>) prov
							.get("lstComproBPago");
					for (Map comPago : lstComproBPago) {
						secFact = comPago.get("num_secfact").toString().trim();
						if (secFact.equals(num_secfact)) {
							lstItemfactAsig = Utilidades
									.copiarLista(lstItemFacturas);
							comPago.put("lstItemFactura", lstItemfactAsig);
							break;
						}
					}

				}
			}

		}
	}

	/**
	 * Metodo que consulta la declaracion, dando inicio a la Diligencia con
	 * continuacion de despacho.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @version 1.0
	 * @author jlunah
	 */
	public ModelAndView cargaDeclaracionDescargaParcial(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		String acceso = WUtil.getParam(request, "hdn_acceso");
		String modifDilig = WUtil.getParam(request, "hdn_modifDilig");
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(
				request, "usuarioBean");
		UserNameHolder.set(bUsuario.getNroRegistro());
		boolean actualizarEstadoDua = true;
		ServletWebRequest webRequest = new ServletWebRequest(request);

		params.put(
				"NUM_DECLARACION",
				WUtil.getParam(webRequest, "hdn_num_declaracion",
						webRequest.getParameter("txt_num_declaracion")));
		params.put(
				"COD_ADUANA",
				WUtil.getParam(webRequest, "hdn_cod_aduana",
						webRequest.getParameter("txt_cod_aduana")));
		params.put(
				"ANN_PRESEN",
				WUtil.getParam(webRequest, "hdn_ann_presen",
						webRequest.getParameter("txt_ann_presen")));
		params.put(
				"COD_REGIMEN",
				WUtil.getParam(webRequest, "hdn_cod_regimen",
						webRequest.getParameter("sel_cod_regimen")));
		params.put("EN_PROCESO", "1");

		try {
			Map<String, Object> declaracion = this.declaracionService
					.obtenerDeclaracion(params);

			if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)) {
				params.put("OBS_IND_DEL", "0");
			}

			if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)
					|| modifDilig.equals(Constantes.MODO_DILIGENCIA_MODIFICA)) {
				actualizarEstadoDua = false;
			}

			if (actualizarEstadoDua) {
				declaracion.put("COD_ESTDUA", Constantes.ESTADO_DILIG_PROCESO);

				Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
				paramDeclaracion.put("NUM_CORREDOC",
						declaracion.get("NUM_CORREDOC"));
				paramDeclaracion.put("COD_ESTDUA",
						Constantes.ESTADO_DILIG_PROCESO);
				declaracionService.updateDeclaracion(paramDeclaracion);
			}

			declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService
					.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA,
							declaracion.get("COD_ESTDUA").toString().trim()));

			if (Constantes.IND_CAMBIO_REC_FISICO.equals((String) declaracion
					.get("COD_INDICADOR"))) {
				declaracion.put("tituloDiligencia", declaracionService
						.obtenerTituloDiligencia(Constantes.CANAL_ROJO));
			} else {
				declaracion.put("tituloDiligencia", declaracionService
						.obtenerTituloDiligencia((String) declaracion
								.get("COD_CANAL")));
			}
			if (Constantes.CANAL_ROJO.equals((String) declaracion
					.get("COD_CANAL"))
					|| Constantes.IND_CAMBIO_REC_FISICO
							.equals((String) declaracion.get("COD_INDICADOR"))) {
				WebUtils.setSessionAttribute(request, "tipoDiligencia",
						Constantes.DILIG_REC_FISICO);
			} else if (Constantes.CANAL_NARANJA.equals((String) declaracion
					.get("COD_CANAL"))) {
				WebUtils.setSessionAttribute(request, "tipoDiligencia",
						Constantes.DILIG_REV_DOCUMENTARIA);
			} else {
				WebUtils.setSessionAttribute(request, "tipoDiligencia", "00");
			}

			if (declaracion.get("COD_MODALIDAD").equals(
					Constantes.MODALIDAD_ANTICIPADO)
					&& declaracion.get("COD_INDICADOR").equals(
							Constantes.IND_DUA_REQ_REGULARIZ)) {
				StringBuffer codModalidadDesc = new StringBuffer();
				codModalidadDesc.append(declaracion.get("COD_MODALIDAD_DESC"))
						.append(MapUtils.getMapValor(declaracion,
								"ANTIC_REGU_DESC"));
				declaracion.put("COD_MODALIDAD_DESC",
						codModalidadDesc.toString());

			}
			// Verificamos si debe registrar la fecha de reconocimiento f�sico
			Map prmtReconoc = new HashMap();
			prmtReconoc.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
			prmtReconoc.put("cod_canal",
					MapUtils.getMapValor(declaracion, "COD_CANAL"));
			declaracion
					.put("registra_fecrecfis", this.declaracionService
							.valRegistraFecReconFis(prmtReconoc));
			// participante 31 deposito temporal
			String numDocIdentPdf = MapUtils.getMapValor(declaracion,
					"NUM_DOCIDENT_PDF");
			String codLocalAnexo = MapUtils.getMapValor(declaracion,
					"COD_LOCALANEXO");
			String direccionLocalAnexo = "";
			if (!SunatStringUtils.isEmpty(codLocalAnexo)
					&& !SunatStringUtils.isEmpty(numDocIdentPdf)) {
				direccionLocalAnexo = declaracionService
						.obtenerLocalAnexoDeclaracion(numDocIdentPdf,
								codLocalAnexo);
				if (SunatStringUtils.isEmpty(direccionLocalAnexo)) { // si no
																		// esta
																		// registrado
																		// el
																		// local
					direccionLocalAnexo = "No registrado";
				}
			} else {
				direccionLocalAnexo = "No registrado";
			}
			declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
			String numDocIdentPdd = declaracion.get("NUM_DOCIDENT_PDD") != null ? (String) declaracion
					.get("NUM_DOCIDENT_PDD") : "";
			String codLocalAnexoDeposito = declaracion
					.get("COD_LOCALANEXODEPOSITO") != null ? (String) declaracion
					.get("COD_LOCALANEXODEPOSITO") : "";
			String direccionLocalAnexoDeposito = "";
			if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito)
					&& !SunatStringUtils.isEmpty(numDocIdentPdd)) {
				direccionLocalAnexoDeposito = declaracionService
						.obtenerLocalAnexoDeclaracion(numDocIdentPdd,
								codLocalAnexoDeposito);
				if (SunatStringUtils.isEmpty(direccionLocalAnexoDeposito)) { // si
																				// no
																				// esta
																				// registrado
																				// el
																				// local
					direccionLocalAnexoDeposito = " No registrado";
				}
			} else {
				direccionLocalAnexoDeposito = "No registrado";
			}

			declaracion.put("COD_LOCALANEXODEPOSITO_DESC",
					direccionLocalAnexoDeposito);
			Map<String, Object> declaracionActual = new HashMap<String, Object>();
			if (!CollectionUtils.isEmpty(declaracion)) {
				declaracionActual.putAll(declaracion);
			}
			Map diligencia = new HashMap();
			diligencia.put("IND_INCIDENCIA", "");
			diligencia.put("IND_MULTA", "");
			diligencia.put("DES_RESULTADO", "");
			// Datos para obtener los documentos
			Map<String, String> mapPk = new HashMap<String, String>();
			mapPk.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC")
					.toString());
			mapPk.put("IND_DEL", "0");
			// Datos de Documentos Autorizantes, Asociados y Certificados de
			// Origen
			if (CollectionUtils.isEmpty((List) declaracion
					.get("lstDocAutAsociado"))) {
				List<Map<String, Object>> listaDocAsoc = declaracionService
						.obtenerDocAutAsociados(mapPk);
				if (!CollectionUtils.isEmpty(listaDocAsoc)) {
					declaracion.put("lstDocAutAsociado",
							Utilidades.copiarLista((List) listaDocAsoc));
					declaracionActual.put("lstDocAutAsociado", listaDocAsoc);
				}
			}
			if (null == request.getSession().getAttribute(
					"incrementalDocumentosAsociados")) {
				request.getSession().setAttribute(
						"incrementalDocumentosAsociados",
						declaracionService
								.obtenerMaxCorrelativoDocAutAsociado(mapPk));
			}
			if (CollectionUtils.isEmpty((List) declaracion
					.get("lstCabCertiOrigen"))) {
				List<Map<String, Object>> listaCabCerti = declaracionService
						.obtenerCertOrigen(mapPk);
				if (!CollectionUtils.isEmpty(listaCabCerti)) {
					declaracion.put("lstCabCertiOrigen",
							Utilidades.copiarLista((List) listaCabCerti));
					declaracionActual.put("lstCabCertiOrigen", listaCabCerti);
				}
			}
			if (CollectionUtils.isEmpty((List) declaracion
					.get("lstDetAutorizacion"))) {
				List<Map<String, Object>> listaDetAut = serieService
						.obtenerDetAutorizacion(mapPk);
				if (!CollectionUtils.isEmpty(listaDetAut)) {
					declaracion.put("lstDetAutorizacion",
							Utilidades.copiarLista((List) listaDetAut));
					declaracionActual.put("lstDetAutorizacion", listaDetAut);
				}
			}

			// Guardamos en sesion los datos de la declaracion e invocamos el
			// jsp
			// correspondiente
			WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
			WebUtils.setSessionAttribute(request, "mapCabDeclaraActual",
					declaracionActual);
			WebUtils.setSessionAttribute(request, "mapCabDiligencia",
					diligencia);

			// Si se tiene Doc Aut/Asoc
			Map<String, String> mapIbatis = new HashMap<String, String>();
			mapIbatis.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC")
					.toString());
			declaracionActual.put("IND_DOCAUT_ASOCIADOS", "0");
			if ((declaracionService.obtenerDocAutAsociados(mapIbatis)).size() > 0) {
				// seteamos vamor en session para recoger en vista y darle el
				// tratamiento
				declaracionActual.put("IND_DOCAUT_ASOCIADOS", "1");
			}

			cargaFormatoBCompleto(declaracion, declaracionActual);
			
		      //P24-PAS20165E220200099 - Inicio
		      Map<String, Object> tieneVP = new HashMap<String, Object>();
		      String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613
		      boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
		      String tipoRegimen = (String) params.get("COD_REGIMEN");		      
		      tieneVP = null;
		      String flag = "";
			  flag = WUtil.getParam(request,"hdn_flag");
			  if(flag==""){
			  	flag = "-1";
			  }
		      Map<String, Object> paramsValidador = new HashMap<String, Object>(); 
		      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
		      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
		      if(indicadorDUAValorProvActivo){
		      //Fin RIN10 mpoblete refactor 	  
		      if(flag!="-1" && flag.equals("1")){
		      	  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
		     		    String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();        		  
		      	     	//verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
		      	  	declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
		      	  	paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
		      	  	tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
		     		    //Inicio RIN10 BUG 22611,22613
		     		    if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
		     		    	verificarValorProvisional(params,declaracion);
		     		    	indicadorVFobProvVP = "SI";
		     		    }
		     		    //Fin RIN10 BUG 22611,22613
		      	  }
			    }else if(flag!="-1" ||flag.equals("2")){        	 
			      	 if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10	        	 
				             tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
				             //Inicio RIN10 BUG 22611,22613
				             if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
				            	 indicadorVFobProvVP = "SI";
				     		 }
				             //Fin RIN10 BUG 22611,22613
			      	 }
			    }
		      }//RIN10 mpoblete refactor		      
		      
		      if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
		     	//Fin RIN10 BUG 22611,22613			
		  		declaracionActual.put("IND_VALOR_PROV", "1"); 
		  	  }else{
		  		declaracionActual.put("IND_VALOR_PROV", "0"); 
		  	  }
		      //P24-PAS20165E220200099 - Fin			
			

			Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
			paramsDiligencia.put("NUM_CORREDOC", declaracion
					.get("NUM_CORREDOC").toString());
			paramsDiligencia.put("COD_TIPDILIGENCIA", new String[] {
					Constantes.DILIG_REV_DOCUMENTARIA,
					Constantes.DILIG_REC_FISICO });

			Map<String, Object> mapUltimaDiligencia = validaDiligenciaService
					.findUltimaDiligencia(paramsDiligencia, declaracionActual);
			String ultimaDiligencia = SojoUtil.toJson(mapUltimaDiligencia);

			ModelAndView res = new ModelAndView("RegDiligenciaDescargaParcialDespacho");
			res.addObject("declaracion", declaracionActual);
			res.addObject("diligencia", mapUltimaDiligencia);
			res.addObject("lstUndTmp", this.catalogoAyudaService
					.getElementosCat(Constantes.CAT_UND_TMP));
			res.addObject("codDocumentoAduanero",
					Constantes.COD_DOCUMENTO_ADUANERO);
			res.addObject("ultimaDiligencia", ultimaDiligencia);

			res.addObject("modifDilig", modifDilig);
			res.addObject("modulo", Constantes.CANAL_NARANJA); // regularizacion BUGP14:54-Refactorizacion

			/* JLUNAH RIN13 */
			if (declaracion.get("COD_MODALIDAD").equals(Constantes.MODALIDAD_ANTICIPADO)) {//BUGP14:54-Refactorizacion
				List<Map<String, Object>> lstIndicadorDua = new ArrayList<Map<String, Object>>();
				boolean flagConclusionAutomatica = false;
				// consultar indicador
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				param.put("COD_TIPOREGISTRO", Constantes.IND_DUA_T_AUT);
				lstIndicadorDua = this.declaracionService
						.obtenerIndicadoresDua(param);

				for (Map<String, Object> indicadorDua : lstIndicadorDua) {//BUGP14:54-Refactorizacion
					if (indicadorDua.get("COD_INDICADOR").equals(Constantes.IND_DUA_REQ_REGULARIZ)) {// es
																			// decir
																			// cuenta
																			// con
																			// el
																			// indicador
																			// 02
																			// regularizable
						flagConclusionAutomatica = true;
					}
				}
				res.addObject("flagConclusionAutomatica",
						flagConclusionAutomatica);
			} else {
				res.addObject("flagConclusionAutomatica", false);
			}
			/* FIN */

			// solo para la consulta debo cargar los Datos modificados en
			// cualquier diligencia
			if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)) {
				String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();
				Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService
						.obtenerDatosModificadosEnDiligencias(numCorreDoc);
				List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_CAB_DECLARA);

				List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_DET_DECLARA);

				List<Map<String, Object>> listaElemEquipamiento = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_EQUIPAMIENTO);

				List<Map<String, Object>> listaElemDocAsociado = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_DOCAUT_ASOCIADO);

				List<Map<String, Object>> listaElemDetAut = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_DET_AUTORIZACION);
				List<Map<String, Object>> listaElemCertOrigen = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_CAB_CERTIORIGEN);
				List<Map<String, Object>> listaElemRegPrecedente = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_DOCUPRECE_DUA);
				List<Map<String, Object>> listaElemFormatoBDAV = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_FORMB_PROVEEDOR);
				List<Map<String, Object>> listaElemFormatoBFactura = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_COMPROBPAGO);
				List<Map<String, Object>> listaElemFormatoBItemFactura = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_ITEM_FACTURA);
				List<Map<String, Object>> listaElemSeriesItem = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_SERIES_ITEM);
				List<Map<String, Object>> listaElemConvenioSerie = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_CONVENIO_SERIE);
				List<Map<String, Object>> listaElemFacturasSeries = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_FORMA_FACTU);
				List<Map<String, Object>> listaElemObservacion = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_OBSERVACION);

				List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(
						mapaRSPTADatosModificados,
						Constantes.COD_TABLA_PARTICIPANTE_DOC);

				// las listas de convenio tienen el mismo PK que det_serie y se
				// muestran en el mismo JSP
				// por ello se agrega a la lista
				if (!CollectionUtils.isEmpty(listaElemConvenioSerie)) {
					listaElemDetDeclara.addAll(listaElemConvenioSerie);
				}
				// en el JSP COnsultaDocAutorizaSerie estan estos 2 listas
				if (!CollectionUtils.isEmpty(listaElemDocAsociado)) {
					listaElemDetDeclara.addAll(listaElemDetAut);
				}

				// en el JSP RegDiligenciaDespacho estan estos 2 listas
				List<Map<String, Object>> listaElemObservacionDecla = new ArrayList();
				// List<Map<String, Object>> listaElemObservacionItemFactura =
				// new ArrayList();

				if (!CollectionUtils.isEmpty(listaElemObservacion)) {
					for (Map<String, Object> mapObs : listaElemObservacion) {

						String codTipObs = mapObs.get("PK").toString();
						if (codTipObs.startsWith("01")) {
							listaElemObservacionDecla.add(mapObs);
						}
						/*
						 * NO SE MUESTRA ESTE CAMPO EN LA CONSULTAS PERO CUANDO
						 * SE MUESTRE HABILITAR else
						 * if(codTipObs.startsWith("03")) {
						 * listaElemObservacionItemFactura.add(mapObs); }
						 */
					}
				}

				listaElemCabDeclara.addAll(listaElemObservacionDecla);
				listaElemCabDeclara.addAll(listaElemParticipantesDUA);
				// se agrega las obseravciones del itemfcatura activar cuando se
				// muestre la obseravcion en itemfacturas
				// listaElemFormatoBItemFactura.addAll(listaElemObservacionItemFactura);

				// Guardamos en sesion los datos de la declaracion e invocamos
				// el jsp
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosDUA",
						(!CollectionUtils.isEmpty(listaElemCabDeclara) ? SojoUtil
								.toJson(listaElemCabDeclara) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosSERIE",
						(!CollectionUtils.isEmpty(listaElemDetDeclara) ? SojoUtil
								.toJson(listaElemDetDeclara) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosEquipamiento ",
						(!CollectionUtils.isEmpty(listaElemEquipamiento) ? SojoUtil
								.toJson(listaElemEquipamiento) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosDocAsociado",
						(!CollectionUtils.isEmpty(listaElemDocAsociado) ? SojoUtil
								.toJson(listaElemDocAsociado) : "[]"));
				// WebUtils.setSessionAttribute(request,
				// "camposModificadosDetAut",
				// (!CollectionUtils.isEmpty(listaElemDetAut)?SojoUtil.toJson(listaElemDetAut):"[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosCertOrigen",
						(!CollectionUtils.isEmpty(listaElemCertOrigen) ? SojoUtil
								.toJson(listaElemCertOrigen) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosRegPrecedente",
						(!CollectionUtils.isEmpty(listaElemRegPrecedente) ? SojoUtil
								.toJson(listaElemRegPrecedente) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosFormatoBDAV",
						(!CollectionUtils.isEmpty(listaElemFormatoBDAV) ? SojoUtil
								.toJson(listaElemFormatoBDAV) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosFormatoBFactura",
						(!CollectionUtils.isEmpty(listaElemFormatoBFactura) ? SojoUtil
								.toJson(listaElemFormatoBFactura) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosFormatoBItemFactura",
						(!CollectionUtils.isEmpty(listaElemFormatoBItemFactura) ? SojoUtil
								.toJson(listaElemFormatoBItemFactura) : "[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosSeriesItem",
						(!CollectionUtils.isEmpty(listaElemSeriesItem) ? SojoUtil
								.toJson(listaElemSeriesItem) : "[]"));
				// WebUtils.setSessionAttribute(request,
				// "camposModificadosConvenioSerie",
				// (!CollectionUtils.isEmpty(listaElemConvenioSerie)?SojoUtil.toJson(listaElemConvenioSerie):"[]"));
				WebUtils.setSessionAttribute(
						request,
						"camposModificadosFacturasSeries",
						(!CollectionUtils.isEmpty(listaElemFacturasSeries) ? SojoUtil
								.toJson(listaElemFacturasSeries) : "[]"));
				// WebUtils.setSessionAttribute(request,"camposModificadosObservacion",(!CollectionUtils.isEmpty(listaElemObservacion)
				// ? SojoUtil.toJson(listaElemObservacion) : "[]"));

			}
			return res;
		} catch (ServiceException e) {

			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean.setMensajeerror(e.getMessage());
			return new ModelAndView("PagM", "Error", mensajeBean);
		} catch (Throwable e) {
			log.error("error", e);
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean
					.setMensajeerror("Ocurrio un error al cargar los datos de la dua.");

			return new ModelAndView("PagM", "Error", mensajeBean);
		}

	}


	/**
	 * @author jlunah
	 * */
	private List<Map<String, Object>> obtenerListaModificaciones(
			Map<String, Object> mapaRSPTADatosModificados,
			String codTablaCabDeclara) {

		return mapaRSPTADatosModificados.get(codTablaCabDeclara) != null ? (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados
				.get(codTablaCabDeclara) : new ArrayList<Map<String, Object>>();
	}

	/**
	 * Metodo que permite la grabacion en session de los cambios realizados a la
	 * declaracion, tomar encuenta que es un metodo reutilizado
	 * 
	 * Invocaciones: Diligencia Despacho, Regularizacion, Rectificacion de
	 * Oficio.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @author jlunah
	 */
	public ModelAndView grabarDeclaSession(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		MensajeBean rBean;
		Object objRes = null;
		String objName = "resultado";
		try {
			Map<String, Object> declaracion = (HashMap) WebUtils
					.getSessionAttribute(request, "mapCabDeclara");
			Map<String, Object> declaracionActual = (HashMap) WebUtils
					.getSessionAttribute(request, "mapCabDeclaraActual");
			Map dataForm = new HashMap();
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String hdn_docTransporteProrratear = webRequest
					.getParameter("hdn_docTransporteProrratear") != null ? webRequest
					.getParameter("hdn_docTransporteProrratear") : "";
			List<Map<String, Object>> lstDocTransporteProrratear = new ArrayList();
			if (StringUtils.isNotEmpty(hdn_docTransporteProrratear)) {
				JSONArray arrayDocTransporteProrratear = JSONArray
						.fromObject(hdn_docTransporteProrratear);
				lstDocTransporteProrratear = (List<Map<String, Object>>) JSONArray
						.toCollection(arrayDocTransporteProrratear, Map.class);
			}
			List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear = new ArrayList();
			lstBLProrratear = verificarDocTransporteAProrratear(request);
			// pase153

			BigDecimal mtoFleteTotalActual = Utilidades.toBigDecimal(webRequest
					.getParameter("txt_mto_totfletedol"));
			BigDecimal mtoFleteTotalBD = Utilidades.toBigDecimal(declaracion
					.get("MTO_TOTFLETEDOL"));
			if (mtoFleteTotalActual.compareTo(mtoFleteTotalBD) != 0) {
				if (cumpleConValidacionesProrrateoBL(lstBLProrratear,
						lstDocTransporteProrratear)) {
					if (lstBLProrratear.size() == 1) {
						Map<String, Object> registroProrrateo = new HashMap();
						registroProrrateo.put("docTransporte", lstBLProrratear
								.get(0).getDocTransporte());
						registroProrrateo.put("sumaFleteInicial",
								lstBLProrratear.get(0).getSumaFleteInicial());
						BigDecimal bdMtoTotFleteDUA = BigDecimal.ZERO;
						bdMtoTotFleteDUA = Utilidades.toBigDecimal(webRequest
								.getParameter("txt_mto_totfletedol"));
						registroProrrateo.put("sumaFleteAProrratear",
								bdMtoTotFleteDUA);
						lstDocTransporteProrratear.add(registroProrrateo);
					}
					request.setAttribute("lstDocTransporteProrratear",
							lstDocTransporteProrratear);
				} else {
					objRes = lstBLProrratear;
					objName = "lstBLProrratear";
					return new ModelAndView(this.jsonView, objName, objRes);
				}
			}
			// ojo que si request.setAttribute("lstDocTransporteProrratear",
			// lstDocTransporteProrratear); sera null
			// si no debe prorratear flete

			// fin pase153
			// if (cumpleConValidacionesProrrateoBL(lstBLProrratear,
			// lstDocTransporteProrratear))
			// {

			String resValidacion = validaGrabaDeclaSesion(request, dataForm);

			// si no tiene ninguna restriccion actualiza los datos
			if (SunatStringUtils.isEmpty(resValidacion)) {

				dataForm.put("OBS_OBS", webRequest.getParameter("taObsObs"));
				if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO
						.equals((String) declaracion.get("COD_REGIMEN"))
						|| Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO
								.equals((String) declaracion.get("COD_REGIMEN"))) {
					if (webRequest.getParameter("sel_cod_tipdesp") != null)
						dataForm.put("COD_TIPDESP",
								webRequest.getParameter("sel_cod_tipdesp"));
					if (webRequest.getParameter("hdn_cod_tipdesp_desc") != null)
						dataForm.put("COD_TIPDESP_DESC",
								webRequest.getParameter("hdn_cod_tipdesp_desc"));
				}

				declaracionActual.putAll(dataForm);

				Map<String, Object> res = new HashMap();

				/* INICIO-PAS20134E610000153 */
				/*
				 * boolean indActualizacionAutomaticaFlete =
				 * declaracionActual.get("IND_MTO_TOTFLETEDOL") != null ?
				 * (Boolean) declaracionActual.get("IND_MTO_TOTFLETEDOL") :
				 * false; boolean indActualizacionAutomaticaValorAduanas =
				 * declaracionActual.get("IND_MTO_TOTVALORADU") != null ?
				 * (Boolean) declaracionActual.get("IND_MTO_TOTVALORADU") :
				 * false; StringBuilder sbRspta = new
				 * StringBuilder("Se grabaron los datos correctamente"); if
				 * (indActualizacionAutomaticaFlete == true) { sbRspta.append(
				 * " ,el sistema prorrateo el Monto Flete en las series");
				 * declaracionActual.put("MTO_TOTFLETEDOL",
				 * declaracionActual.get("MTO_TOTFLETEDOL2"));
				 * declaracionActual.remove("IND_MTO_TOTFLETEDOL");
				 * declaracionActual.remove("MTO_TOTFLETEDOL2"); } if
				 * (indActualizacionAutomaticaValorAduanas == true) {
				 * sbRspta.append(
				 * " ,el sistema actualizo el Valor Aduanas segun los datos de la series."
				 * ); declaracionActual.put("MTO_TOTVALORADU",
				 * declaracionActual.get("MTO_TOTVALORADU2"));
				 * declaracionActual.remove("IND_MTO_TOTVALORADU");
				 * declaracionActual.remove("MTO_TOTVALORADU2"); }
				 */
				/* FIN-PAS20134E610000153 */
				StringBuilder sbRspta = new StringBuilder(
						"Se grabaron los datos correctamente");
				WebUtils.setSessionAttribute(request, "mapCabDeclaraActual",
						declaracionActual);
				res.put("res_ok", sbRspta.toString());
				res.put("declaracion", declaracionActual);
				List<SeriesProrrateadasBean> lstSeriesProrrateadas = new ArrayList();
				lstSeriesProrrateadas = obtenerSeriesProrratedas(request);
				res.put("lstSeriesProrrateadas", lstSeriesProrrateadas);
				objRes = res;
			} else {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror(resValidacion);
				rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				objName = "beanM";
				objRes = rBean;
				log.error(this.toString()
						.concat(" grabarDeclaSession - ERROR : ")
						.concat("No se encontro el dato buscado"));
			}
			// }
			/*
			 * else { objRes = lstBLProrratear; objName = "lstBLProrratear"; }
			 */
		} catch (ServiceException e) {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			log.error("error", e);
			objName = "beanM";
			objRes = rBean;
		} catch (Throwable e) {
			log.error("*** ERROR ***", e);
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurrio un error inesperado al grabar los datos de la declaracion.");
			objName = "beanM";
			objRes = rBean;
		}

		return new ModelAndView(this.jsonView, objName, objRes);
	}

	/**
	 * Obtener series ha ser pror.
	 * 
	 * @param request
	 *            [HttpServletRequest] request
	 * @return [List<SeriesProrrateadasBean>] list
	 * @version 1.0
	 * @author jlunah
	 */
	private List<SeriesProrrateadasBean> obtenerSeriesProrratedas(
			HttpServletRequest request) {
		List<SeriesProrrateadasBean> lstSeriesProrrateadas = new ArrayList();

		List<Map> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(
				request, "lstDetDeclaraActual");
		List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils
				.getSessionAttribute(request, "lstDetDeclara");

		SeriesProrrateadasBean serieBean;
		Map seriePk;
		Map serieAnt;
		if (!CollectionUtils.isEmpty(lstDetDeclara)) {
			for (Map serie : lstDetDeclara) {
				if (!Utilidades.esUnaRegistroMarcadaParaEliminar(serie)) {
					seriePk = new HashMap();
					seriePk.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
					seriePk.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
					serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt,
							seriePk);

					String mtoFleteAnt = "0";
					String mtoSeguroAnt = "0";
					if (serieAnt != null) {
						mtoFleteAnt = serieAnt.get("MTO_FLETEDOL") != null ? serieAnt
								.get("MTO_FLETEDOL").toString() : "0";
						mtoSeguroAnt = serieAnt.get("MTO_SEGDOL") != null ? serieAnt
								.get("MTO_SEGDOL").toString() : "0";
					}

					serieBean = new SeriesProrrateadasBean();
					serieBean.setNumSecSerie(Utilidades.toLong(serie
							.get("NUM_SECSERIE")));
					serieBean.setMtoFleteInicial(Utilidades
							.toBigDecimal(mtoFleteAnt));

					String tipoFlete = serie.get("COD_TIPFLETE").toString();
					String tipoFleteDesc = "";
					if ("1".equals(tipoFlete)) {
						tipoFleteDesc = "No se prorratea";
					} else {
						tipoFleteDesc = catalogoAyudaService
								.getDescripcionDataCatalogo("368", tipoFlete);
					}

					serieBean.setTipoProrrateo(tipoFlete + "-" + tipoFleteDesc);
					serieBean.setMtoFleteProrrateado(Utilidades
							.toBigDecimal(serie.get("MTO_FLETEDOL")));

					serieBean.setMtoSeguroInicial(Utilidades
							.toBigDecimal(mtoSeguroAnt));

					String tipoSeguro = serie.get("COD_TIPSEG").toString();
					String tipoSeguroDesc = catalogoAyudaService
							.getDescripcionDataCatalogo("62", tipoSeguro);
					serieBean.setTipoSeguro(tipoSeguro + "-" + tipoSeguroDesc);
					serieBean.setMtoSeguroProrrateado(Utilidades
							.toBigDecimal(serie.get("MTO_SEGDOL")));

					lstSeriesProrrateadas.add(serieBean);
				}
			}
		}

		return lstSeriesProrrateadas;
	}

	/**
	 * Cumple con validaciones prorrateo bl.
	 * 
	 * @param lstBLProrratear
	 *            [List<SumaFleteYPesoPorDocTransporteBean>] lst bl prorratear
	 * @param lstDocTransporteProrratear
	 *            [List<Map<String,Object>>] lst doc transporte prorratear
	 * @return true, if successful
	 * @author jlunah
	 */
	private boolean cumpleConValidacionesProrrateoBL(
			List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear,
			List<Map<String, Object>> lstDocTransporteProrratear)

	{
		// solo es false si ha cambiado el monto de flete
		// despues es llenado por el valor de la cabecera
		if (lstBLProrratear.size() == 1 || lstBLProrratear.size() == 0) {
			return true;
		} else if (lstBLProrratear.size() > 1
				&& org.apache.commons.collections.CollectionUtils
						.isNotEmpty(lstDocTransporteProrratear)
				&& lstDocTransporteProrratear.size() == lstBLProrratear.size()) {
			return true;
		}

		return false;
	}

	/**
	 * Valida los datos de la declaracion validaciones: el datado, las sumatoria
	 * de los series con la cabecera, y llena Map dataForm con los datos
	 * actualizados. el metodo es invocado al momento de grabar la diligencia se
	 * ejecuta el proceso de prorrateo de flete y seguro nuevamente se supone
	 * que si se realizo este proceso en la declaracion los datos de la listado
	 * de series ya esta cuadrados pero si fueron directamente a grabar la
	 * diligencia se espera que este metodo valide y prorrate
	 * 
	 * @param request
	 *            the request
	 * @param dataForm
	 *            the data form
	 * @return String mensaje de validacion
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @version 1.0
	 * @author jlunah
	 */
	private String validaGrabaDeclaSesion(HttpServletRequest request,
			Map dataForm) throws ServletException, IOException {

		String res = "";
		// Obtenemos los cambios en la declaracion
		ServletWebRequest webRequest = new ServletWebRequest(request);
		if (null == dataForm) {
			dataForm = new HashMap();
		}

		dataForm.put(
				"MTO_TOTFOBDOL",
				new Double(
						("".equals(webRequest.getParameter("txt_mto_totfobdol")
								.toString().trim()) ? "0" : webRequest
								.getParameter("txt_mto_totfobdol"))));
		dataForm.put(
				"MTO_TOTFLETEDOL",
				new Double(
						("".equals(webRequest
								.getParameter("txt_mto_totfletedol").toString()
								.trim()) ? "0" : webRequest
								.getParameter("txt_mto_totfletedol"))));
		dataForm.put(
				"MTO_TOTSEGDOL",
				new Double(("".equals(webRequest
						.getParameter("txt_mto_totsegdol")) ? "0" : webRequest
						.getParameter("txt_mto_totsegdol"))));
		dataForm.put(
				"MTO_TOTAJUSTESDOL",
				new Double(("".equals(webRequest
						.getParameter("txt_mto_totajustesdol").toString()
						.trim()) ? "0" : webRequest
						.getParameter("txt_mto_totajustesdol"))));
		dataForm.put(
				"MTO_TOTOTROSAJUSTE",
				new Double(("".equals(webRequest
						.getParameter("txt_mto_tototrosajuste").toString()
						.trim()) ? "0" : webRequest
						.getParameter("txt_mto_tototrosajuste"))));
		dataForm.put(
				"MTO_TOTVALORADU",
				new Double(
						("".equals(webRequest
								.getParameter("txt_mto_totvaloradu").toString()
								.trim()) ? "0" : webRequest
								.getParameter("txt_mto_totvaloradu"))));
		dataForm.put(
				"CNT_PESONETO_TOTAL",
				new Double(("".equals(webRequest
						.getParameter("txt_cnt_pesoneto_total").toString()
						.trim()) ? "0" : webRequest
						.getParameter("txt_cnt_pesoneto_total"))));
		dataForm.put(
				"CNT_PESOBRUTO_TOTAL",
				new Double(("".equals(webRequest
						.getParameter("txt_cnt_pesobruto_total").toString()
						.trim()) ? "0" : webRequest
						.getParameter("txt_cnt_pesobruto_total"))));
		dataForm.put(
				"CNT_TOTBULTOS",
				new Double(
						("".equals(webRequest.getParameter("txt_cnt_totbultos")
								.toString().trim()) ? "0" : webRequest
								.getParameter("txt_cnt_totbultos"))));
		dataForm.put(
				"CNT_TQUNIFIS",
				new Double(
						("".equals(webRequest.getParameter("txt_cnt_tqunifis")
								.toString().trim()) ? "0" : webRequest
								.getParameter("txt_cnt_tqunifis"))));
		dataForm.put(
				"CNT_TQUNICOM",
				new Double(
						("".equals(webRequest.getParameter("txt_cnt_tqunicom")
								.toString().trim()) ? "0" : webRequest
								.getParameter("txt_cnt_tqunicom"))));
		dataForm.put("IND_SOCORRO", webRequest.getParameter("chk_ind_socorro"));
		dataForm.put(
				"COD_FERIA",
				webRequest.getParameter("txt_cod_feria") != null ? webRequest
						.getParameter("txt_cod_feria") : null);
		dataForm.put(
				"COD_FERIA_DESC",
				webRequest.getParameter("txt_cod_feria_desc") != null ? webRequest
						.getParameter("txt_cod_feria_desc") : null);

		dataForm.put(
				"OBS_OBS",
				webRequest.getParameter("taObsObs") != null ? webRequest
						.getParameter("taObsObs") : null);

		if (webRequest.getParameter("sel_cod_tiptratmerc") != null) {
			dataForm.put(
					"COD_TIPTRATMERC",
					webRequest.getParameter("sel_cod_tiptratmerc").isEmpty() ? " "
							: webRequest.getParameter("sel_cod_tiptratmerc"));
		}
		if (webRequest.getParameter("sel_cod_produrgente") != null) {
			dataForm.put(
					"COD_PRODURGENTE",
					webRequest.getParameter("sel_cod_produrgente").isEmpty() ? " "
							: webRequest.getParameter("sel_cod_produrgente"));
		}
		if (webRequest.getParameter("txt_cod_tiplugarrecep") != null) {
			dataForm.put(
					"COD_TIPLUGARRECEP",
					webRequest.getParameter("txt_cod_tiplugarrecep").isEmpty() ? " "
							: webRequest.getParameter("txt_cod_tiplugarrecep"));
		}

		String tipoDiligencia = (String) getVariableSesion(request,
				EnumVariablesSession.TIP_DILIGENCIA);
		if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia)) {
			// completo los nuevos campos habilitados en la Recti.Oficio
			dataForm.put(
					"COD_MODALIDAD",
					webRequest.getParameter("sel_cod_modalidad") != null ? webRequest
							.getParameter("sel_cod_modalidad") : " ");
			dataForm.put(
					"COD_TIPDESP",
					webRequest.getParameter("sel_cod_tipdesp") != null ? webRequest
							.getParameter("sel_cod_tipdesp") : " ");
			dataForm.put(
					"COD_LUGARRECEP",
					webRequest.getParameter("sel_cod_lugarrecep") != null ? webRequest
							.getParameter("sel_cod_lugarrecep") : " ");
			dataForm.put(
					"COD_LOCALANEXO",
					webRequest.getParameter("txt_cod_localanexo") != null ? webRequest
							.getParameter("txt_cod_localanexo") : " ");
			// dataForm.put("COD_TIPADUDEST",
			// webRequest.getParameter("txt_cod_tipadudest") !=null ?
			// webRequest.getParameter("txt_cod_tipadudest"):" ");

			dataForm.put(
					"COD_ADUDEST",
					webRequest.getParameter("sel_cod_adudest") != null ? webRequest
							.getParameter("sel_cod_adudest") : " ");
			dataForm.put(
					"CNT_TOTSERIES",
					new Double(("".equals(webRequest
							.getParameter("txt_cnt_totseries").toString()
							.trim()) ? "0" : webRequest
							.getParameter("txt_cnt_totseries"))));
			dataForm.put(
					"COD_MODPAGO",
					webRequest.getParameter("sel_cod_modpago") != null ? webRequest
							.getParameter("sel_cod_modpago") : " ");
			dataForm.put(
					"COD_ENTIPAGO",
					webRequest.getParameter("sel_cod_entipago") != null ? webRequest
							.getParameter("sel_cod_entipago") : " ");
			dataForm.put(
					"COD_TIPTRATMERC",
					webRequest.getParameter("sel_cod_tiptratmerc") != null ? webRequest
							.getParameter("sel_cod_tiptratmerc") : " ");
			dataForm.put(
					"COD_VIATRANS",
					webRequest.getParameter("sel_cod_viatrans") != null ? webRequest
							.getParameter("sel_cod_viatrans") : " ");

			String fecTerm = webRequest.getParameter("txt_fec_term");
			if (!SunatStringUtils.isEmpty(fecTerm)) {
				dataForm.put("FEC_TERM", Utilidades.crearObjetoDesdeCadena(
						fecTerm, new Timestamp(0)));
			}
			/*
			 * String fecIniEmbarque =
			 * webRequest.getParameter("txt_fec_iniembarque"); if
			 * (!SunatStringUtils.isEmpty(fecIniEmbarque)) {
			 * dataForm.put("FEC_INIEMBARQUE",
			 * crearObjetoDesdeCadena(fecIniEmbarque,new Timestamp(0))); }
			 */
			// se quito dataForm.put("COD_PUER_DESP",
			// webRequest.getParameter("txt_cod_puer_desp")
			// !=null ? webRequest.getParameter("txt_cod_puer_desp"):" ");
			// debe grabar o modificar en participantes
			dataForm.put(
					"NUM_DOCIDENT_PDF",
					webRequest.getParameter("txt_num_docident_pdf_31") != null ? webRequest
							.getParameter("txt_num_docident_pdf_31") : " ");
			dataForm.put(
					"ANN_MANIFIESTO",
					webRequest.getParameter("txt_annmanifiesto") != null ? webRequest
							.getParameter("txt_annmanifiesto") : " ");
			dataForm.put(
					"NUM_MANIFIESTO",
					webRequest.getParameter("txt_num_manifiesto") != null ? webRequest
							.getParameter("txt_num_manifiesto") : " ");
			dataForm.put(
					"MTO_FOBFACTU",
					new Double((""
							.equals(webRequest.getParameter("txt_mto_fobfactu")
									.toString().trim()) ? "0" : webRequest
							.getParameter("txt_mto_fobfactu"))));

			String fecCarcr = webRequest.getParameter("txt_fec_carcr");
			if (!SunatStringUtils.isEmpty(fecCarcr)) {
				dataForm.put("FEC_CARCR", Utilidades.crearObjetoDesdeCadena(
						fecCarcr, new Timestamp(0)));
			}
			/*
			 * String fecLlegada = webRequest.getParameter("txt_fec_llegada");
			 * if (!SunatStringUtils.isEmpty(fecLlegada)) {
			 * dataForm.put("FEC_LLEGADA", crearObjetoDesdeCadena(fecLlegada,new
			 * Timestamp(0))); }
			 */
			// debe grabar o modificar en participantes empresa de transportes
			dataForm.put(
					"NUM_DOCIDENT_PTR",
					webRequest.getParameter("txt_num_docident_ptr_11") != null ? webRequest
							.getParameter("txt_num_docident_ptr_11") : " ");
			dataForm.put(
					"COD_TIPPARTIC_PTR",
					webRequest.getParameter("hdm_txt_codTipoOperador_11") != null ? webRequest
							.getParameter("hdm_txt_codTipoOperador_11") : " ");

			// siempre aparece N a " "
			Map declaracionInicial = (HashMap) WebUtils.getSessionAttribute(
					request, "mapCabDeclara");
			if (!CollectionUtils.isEmpty(declaracionInicial)
					&& !SunatStringUtils.isEmpty((String) declaracionInicial
							.get("IND_SOCORRO"))) {
				dataForm.put(
						"IND_SOCORRO",
						webRequest.getParameter("chk_ind_socorro") != null ? webRequest
								.getParameter("chk_ind_socorro")
								: declaracionInicial.get("IND_SOCORRO"));
			}

			// se agrego importador
			String numCntaCte = webRequest.getParameter("hdn_numcntacte") != null ? webRequest
					.getParameter("hdn_numcntacte") : "";
			if (StringUtils.isNotEmpty(numCntaCte)) { // numCntaCte no vacio
				dataForm.put(
						"NUM_DOCIDENT_PIM",
						webRequest.getParameter("txt_num_docident_pim_45") != null ? webRequest
								.getParameter("txt_num_docident_pim_45") : " ");
				dataForm.put(
						"NOM_RAZONSOCIAL_PIM",
						webRequest.getParameter("txt_nom_razonsocial_pim_45") != null ? webRequest
								.getParameter("txt_nom_razonsocial_pim_45")
								: " ");
				dataForm.put(
						"COD_TIPDOC_PIM",
						webRequest.getParameter("sel_cod_tipdoc_pim_45") != null ? webRequest
								.getParameter("sel_cod_tipdoc_pim_45") : " ");
				dataForm.put(
						"DIR_PARTIC_PIM",
						webRequest.getParameter("txt_dir_partic_pim_45") != null ? webRequest
								.getParameter("txt_dir_partic_pim_45") : " ");
			}

		}

		if (CollectionUtils.isEmpty((List) WebUtils.getSessionAttribute(
				request, "lstDetDeclaraActual"))) {
			cargarSeriesSesion(request);
		}

		Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request,
				"mapCabDeclaraActual");
		List<String> lstSeriesRecti = declaracionActual.get("lstSeriesRecti") != null ? ((ArrayList<String>) declaracionActual
				.get("lstSeriesRecti")) : null;

		if ("".equals(res)) {
			res = this.validaSeriesItemsFactura(declaracionActual,
					(ArrayList) WebUtils.getSessionAttribute(request,
							"lstDetDeclaraActual"));
		}

		if ("".equals(res)) {
			res = this.validaSeriesCambioEstadoMercancia(declaracionActual,
					(ArrayList) WebUtils.getSessionAttribute(request,
							"lstDetDeclara"),
					(ArrayList) WebUtils.getSessionAttribute(request,
							"lstDetDeclaraActual"));
		}

		if ("".equals(res)) {
			res = this.validaSeries(dataForm, (ArrayList) WebUtils
					.getSessionAttribute(request, "lstDetDeclaraActual"),
					lstSeriesRecti, request);
		}

		return res;
	}

	/**
	 * Validar el cambio de estado de mercanc�a de las series.
	 * 
	 * @param declaracionActual
	 *            the declaracion actual
	 * @param lstDetDeclara
	 *            the lst det declara
	 * @param lstDetDeclaraActual
	 *            the lst det declara actual
	 * @return String
	 * @author jlunah
	 */
	public String validaSeriesCambioEstadoMercancia(Map declaracionActual,
			List<Map<String, Object>> lstDetDeclara,
			List<Map<String, Object>> lstDetDeclaraActual) {
		String respuesta = "";
		// Solo para el r�gimen 10
		if (declaracionActual.get("COD_REGIMEN").toString()
				.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)) {
			StringBuilder mensaje = new StringBuilder("");
			String strCapitulo = "";
			boolean tieneRegPreCeticos;
			int j = 0;
			Map<String, Object> serieActual = new HashMap<String, Object>();
			Map<String, Object> serie = new HashMap<String, Object>();
			ArrayList<Map> listaRegPre = new ArrayList<Map>();
			for (int i = 0; i < lstDetDeclaraActual.size(); i++) {
				serieActual = lstDetDeclaraActual.get(i);

				tieneRegPreCeticos = false;
				// Para las series modificadas, no las agregadas
				if (i <= lstDetDeclara.size() - 1) {
					serie = lstDetDeclara.get(i);
					// Si estado es usado
					if (SunatStringUtils.isStringInList(
							serieActual.get("COD_ESTMERC").toString(), ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO+","+ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_ARMADO)) {
						// Estado inicial fue nuevo
						if (SunatStringUtils.isStringInList(
								serie.get("COD_ESTMERC").toString(),
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_ARMADO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_DESARMADO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_SEMI_ARMADO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_SINIESTRADO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_AVERIADO+","+
								ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_NUEVO_RECONSTRUIDO)) {
							strCapitulo = SunatStringUtils.lpad(serieActual
									.get("NUM_PARTNANDI").toString(), 10, '0');
							strCapitulo = strCapitulo.substring(0, 2);
							// Si pertenece al cap�tulo 87 de veh�culos
							if (strCapitulo.equals("87")) {
								listaRegPre = (ArrayList<Map>) serieActual
										.get("lstDocuPreceDua");
								// Tiene r�gimen precedente
								if (!CollectionUtils.isEmpty(listaRegPre)) {
									for (Map<String, Object> regPre : listaRegPre) {
										// R�gimen precedente CETICO
										if (regPre
												.get("COD_REGIMENPRE")
												.toString()
												.equals(ConstantesDataCatalogo.REGIMEN_PRECEDENTE_CETICO)) {
											tieneRegPreCeticos = true;
										}
									}
								}
								if (!tieneRegPreCeticos) {
									// TNAN corresponde no registrado
									if (serieActual.get("COD_TIPTASAAPLICAR")
											.toString().trim().equals("")) {
										if (j > 0)
											mensaje.append(", ");
										mensaje.append(serie
												.get("NUM_SECSERIE"));
										j++;
									}

								}
							}
						}
					}
				}
			}
			if (j >= 1)
				respuesta = "Debe registrar el valor del  TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN para la(s) serie(s) ";

			// "Debe modificarse adem�s el TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN para las series ";
			if (j > 0)
				respuesta = respuesta + mensaje.toString() + ".";
		}
		return respuesta;
	}

	/**
	 * Metodo que valida los datos de las series.
	 * 
	 * @param newData
	 *            datos de la cabecera formulario declaracion
	 * @param lstSeries
	 *            the lst series
	 * @param lstSeriesRecti
	 *            the lst series recti
	 * @param request
	 *            the request
	 * @return the string
	 * @author jlunah
	 */
	private String validaSeries(Map<String, Object> newData,
			List<Map<String, Object>> lstSeries, List<String> lstSeriesRecti,
			HttpServletRequest request) {
		StringBuilder res = new StringBuilder("");
		// String IND_REGISTRO_GRABADO = IND_REGISTRO_GRABADO;

		if (!CollectionUtils.isEmpty(lstSeries)) {
			Map mapSerie;
			double dbl_mto_fobdol = 0;
			double dbl_mto_fletedol = 0;
			double dbl_mto_segdol = 0;
			double dbl_mto_ajuste = 0;
			double dbl_mto_ajuste_otr = 0;
			double dbl_mto_valoradu = 0;
			double dbl_cnt_peso_neto = 0;
			double dbl_cnt_peso_bruto = 0;
			double dbl_cnt_bulto = 0;
			double dbl_cnt_unifis = 0;
			double dbl_cnt_comer = 0;

			// ESTE DATO VIENE DEL ITENFACTURA O DE CAB_DECLARA
			List<Map<String, Object>> lstDocTransporteProrratear = request
					.getAttribute("lstDocTransporteProrratear") != null ? (ArrayList) request
					.getAttribute("lstDocTransporteProrratear") : null;

			List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte = new ArrayList<SumaFleteYPesoPorDocTransporteBean>();
			// los valores de la cabcera PASE578
			// solo si tiene datos prorratea en la cabcecera prorratea solo sio
			// hay cambios en el MTO_TOTFLETE DEL CAB_DECLARA
			// Map<String, Object> declaracion = (HashMap)
			// WebUtils.getSessionAttribute(request, "mapCabDeclara");
			if (!CollectionUtils.isEmpty(lstDocTransporteProrratear)) {
				// pase153
				// BigDecimal mtoFleteTotalActual =
				// Utilidades.toBigDecimal(newData.get("MTO_TOTFLETEDOL"));
				// BigDecimal mtoFleteTotalBD =
				// Utilidades.toBigDecimal(declaracion.get("MTO_TOTFLETEDOL"));
				// if(mtoFleteTotalActual.compareTo(mtoFleteTotalBD) != 0)
				// {
				SumaFleteYPesoPorDocTransporteBean tablaFletePeso;
				String docTransporte;
				BigDecimal sumaFleteAProrratear;
				for (Map docTransporteProrratear : lstDocTransporteProrratear) {
					docTransporte = docTransporteProrratear
							.get("docTransporte").toString();
					sumaFleteAProrratear = Utilidades
							.toBigDecimal(docTransporteProrratear
									.get("sumaFleteAProrratear"));

					tablaFletePeso = new SumaFleteYPesoPorDocTransporteBean(
							docTransporte, sumaFleteAProrratear);
					lstSumaFleteYPesoPorDocTransporte.add(tablaFletePeso);
				}
				lstSeries = declaracionCalculoDeDatos.prorratearFlete(
						lstSeries, lstSumaFleteYPesoPorDocTransporte);
				// }
			}
			// prorrateo de seguro
			// BigDecimal mtoSeguroTotalActual =
			// Utilidades.toBigDecimal(newData.get("MTO_TOTSEGDOL"));
			// BigDecimal mtoSeguroTotalBD =
			// Utilidades.toBigDecimal(declaracion.get("MTO_TOTSEGDOL"));
			// if(mtoSeguroTotalActual.compareTo(mtoSeguroTotalBD) != 0)
			// {

			BigDecimal mtoTotalFOBDolDeLaDeclaracion = Utilidades
					.toBigDecimal(newData.get("MTO_TOTFOBDOL"));
			BigDecimal mtoSeguroProrratear = Utilidades.toBigDecimal(newData
					.get("MTO_TOTSEGDOL"));

			Map mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request,
					"mapCabDeclaraActual");
			Date fechaVigenciaPartida = SunatDateUtils
					.getDateFromUnknownFormat(mapCabDeclara.get(
							"FEC_DECLARACION").toString());

			lstSeries = declaracionCalculoDeDatos
					.prorratearMtoSeguroEnLasSeries(mtoSeguroProrratear,
							mtoTotalFOBDolDeLaDeclaracion,
							fechaVigenciaPartida, lstSeries);
			// }

			int contadorSeriesActivas = 0;

			for (int i = 0; i < lstSeries.size(); i++) {
				mapSerie = (HashMap) lstSeries.get(i);

				// debido a que prorrrateo en esta parte el valor en aduanas de
				// las
				// serie no sera el valor correcto
				// por ello recalculo y lo seteo para el caso de las eliminadas
				// tambien
				double bd_mto_fobdol1 = Double.valueOf(mapSerie.get(
						"MTO_FOBDOL").toString());
				double bd_mto_fletedol1 = Double.valueOf(mapSerie.get(
						"MTO_FLETEDOL").toString());
				double bd_mto_segdol1 = Double.valueOf(mapSerie.get(
						"MTO_SEGDOL").toString());
				double bd_mto_ajuste1 = Double.valueOf(mapSerie.get(
						"MTO_AJUSTE").toString());
				double bd_mto_ajuste_otr1 = Double.valueOf(mapSerie.get(
						"MTO_OTROSAJUSTES").toString());

				BigDecimal bd_mto_valoraduProrrateado = SunatNumberUtils
						.scaleHalfUp(new BigDecimal(bd_mto_fobdol1
								+ bd_mto_fletedol1 + bd_mto_segdol1
								+ bd_mto_ajuste1 + bd_mto_ajuste_otr1), 3);
				mapSerie.put("MTO_VALORADU", bd_mto_valoraduProrrateado);

				if ((Integer.parseInt(mapSerie.get("IND_DEL").toString())) == 0
						&& mapSerie.get("IND_TIPO_REGISTRO").toString()
								.equals(IND_REGISTRO_GRABADO)) {

					dbl_mto_fobdol = dbl_mto_fobdol
							+ Double.valueOf(mapSerie.get("MTO_FOBDOL")
									.toString());
					dbl_mto_fletedol = dbl_mto_fletedol
							+ Double.valueOf(mapSerie.get("MTO_FLETEDOL")
									.toString());
					dbl_mto_segdol = dbl_mto_segdol
							+ Double.valueOf(mapSerie.get("MTO_SEGDOL")
									.toString());
					dbl_mto_ajuste = dbl_mto_ajuste
							+ Double.valueOf(mapSerie.get("MTO_AJUSTE")
									.toString());
					dbl_mto_ajuste_otr = dbl_mto_ajuste_otr
							+ Double.valueOf(mapSerie.get("MTO_OTROSAJUSTES")
									.toString());

					dbl_mto_valoradu = dbl_mto_valoradu
							+ Double.valueOf(mapSerie.get("MTO_VALORADU")
									.toString());
					dbl_cnt_peso_neto = dbl_cnt_peso_neto
							+ Double.valueOf(mapSerie.get("CNT_PESO_NETO")
									.toString());
					dbl_cnt_peso_bruto = dbl_cnt_peso_bruto
							+ Double.valueOf(mapSerie.get("CNT_PESO_BRUTO")
									.toString());
					dbl_cnt_bulto = dbl_cnt_bulto
							+ Double.valueOf(mapSerie.get("CNT_BULTO")
									.toString());
					dbl_cnt_unifis = dbl_cnt_unifis
							+ Double.valueOf(mapSerie.get("CNT_UNIFIS")
									.toString());
					dbl_cnt_comer = dbl_cnt_comer
							+ Double.valueOf(mapSerie.get("CNT_COMER")
									.toString());
					contadorSeriesActivas++;
				}
			}

			// validamos si la cantidad de series activas es la mismas
			String tipoDiligencia = (String) getVariableSesion(request,
					EnumVariablesSession.TIP_DILIGENCIA);
			if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia)) {
				double diferenciaSeries = Double.valueOf(newData.get(
						"CNT_TOTSERIES").toString())
						- contadorSeriesActivas;

				if (Math.abs(diferenciaSeries) > 0
						|| contadorSeriesActivas < Double.valueOf(newData.get(
								"CNT_TOTSERIES").toString())) {

					res.append("Hay una diferencia de ")
							.append(diferenciaSeries)
							.append(" Series registrados en la cabecera:"
									+ Double.valueOf(newData.get(
											"CNT_TOTSERIES").toString())
									+ " y el numero de las series registradas en el detalle:"
									+ contadorSeriesActivas + ".");
				}
			}

			// Validamos las cantidades y montos
			double dif_mto_fobdol = Double.valueOf(newData.get("MTO_TOTFOBDOL")
					.toString()) - dbl_mto_fobdol;
			BigDecimal bd_dif_mto_fobdol = new BigDecimal(dif_mto_fobdol);
			bd_dif_mto_fobdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fobdol,
					3);

			double dif_mto_fletedol = Double.valueOf(newData.get(
					"MTO_TOTFLETEDOL").toString())
					- dbl_mto_fletedol;
			BigDecimal bd_dif_mto_fletedol = new BigDecimal(dif_mto_fletedol);
			bd_dif_mto_fletedol = SunatNumberUtils.scaleHalfUp(
					bd_dif_mto_fletedol, 3);

			double dif_mto_segdol = Double.valueOf(newData.get("MTO_TOTSEGDOL")
					.toString()) - dbl_mto_segdol;
			BigDecimal bd_dif_mto_segdol = new BigDecimal(dif_mto_segdol);
			bd_dif_mto_segdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_segdol,
					3);

			double dif_mto_ajuste = Double.valueOf(newData.get(
					"MTO_TOTAJUSTESDOL").toString())
					- dbl_mto_ajuste;
			BigDecimal bd_dif_mto_ajuste = new BigDecimal(dif_mto_ajuste);
			bd_dif_mto_ajuste = SunatNumberUtils.scaleHalfUp(bd_dif_mto_ajuste,
					3);

			double dif_mto_ajuste_otr = Double.valueOf(newData.get(
					"MTO_TOTOTROSAJUSTE").toString())
					- dbl_mto_ajuste_otr;
			BigDecimal bd_dif_mto_ajuste_otr = new BigDecimal(
					dif_mto_ajuste_otr);
			bd_dif_mto_ajuste_otr = SunatNumberUtils.scaleHalfUp(
					bd_dif_mto_ajuste_otr, 3);

			double dif_mto_valoradu = Double.valueOf(newData.get(
					"MTO_TOTVALORADU").toString())
					- dbl_mto_valoradu;
			BigDecimal bd_dif_mto_valoradu = new BigDecimal(dif_mto_valoradu);
			bd_dif_mto_valoradu = SunatNumberUtils.scaleHalfUp(
					bd_dif_mto_valoradu, 3);

			double dif_cnt_peso_neto = Double.valueOf(newData.get(
					"CNT_PESONETO_TOTAL").toString())
					- dbl_cnt_peso_neto;
			BigDecimal bd_dif_cnt_peso_neto = new BigDecimal(dif_cnt_peso_neto);
			bd_dif_cnt_peso_neto = SunatNumberUtils.scaleHalfUp(
					bd_dif_cnt_peso_neto, 3);

			double dif_cnt_peso_bruto = Double.valueOf(newData.get(
					"CNT_PESOBRUTO_TOTAL").toString())
					- dbl_cnt_peso_bruto;
			BigDecimal bd_dif_cnt_peso_bruto = new BigDecimal(
					dif_cnt_peso_bruto);
			bd_dif_cnt_peso_bruto = SunatNumberUtils.scaleHalfUp(
					bd_dif_cnt_peso_bruto, 3);

			double dif_cnt_bulto = Double.valueOf(newData.get("CNT_TOTBULTOS")
					.toString()) - dbl_cnt_bulto;
			BigDecimal bd_dif_cnt_bulto = new BigDecimal(dif_cnt_bulto);
			bd_dif_cnt_bulto = SunatNumberUtils
					.scaleHalfUp(bd_dif_cnt_bulto, 3);

			double dif_cnt_unifis = Double.valueOf(newData.get("CNT_TQUNIFIS")
					.toString()) - dbl_cnt_unifis;
			BigDecimal bd_dif_cnt_unifis = new BigDecimal(dif_cnt_unifis);
			bd_dif_cnt_unifis = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_unifis,
					3);

			double dif_cnt_comer = Double.valueOf(newData.get("CNT_TQUNICOM")
					.toString()) - dbl_cnt_comer;
			BigDecimal bd_dif_cnt_comer = new BigDecimal(dif_cnt_comer);
			bd_dif_cnt_comer = SunatNumberUtils
					.scaleHalfUp(bd_dif_cnt_comer, 3);

			// implementacion 0.01 para rectificacion de oficio

			double diferenciaMaximaMonto;
			double diferenciaMaximaPeso;
			double diferenciaMaximaCantidad;

			if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia)) {
				diferenciaMaximaMonto = Double
						.valueOf(Constantes.DIFERENCIA_MAX_MONTO);
				diferenciaMaximaPeso = Double
						.valueOf(Constantes.DIFERENCIA_MAX_PESO);
				diferenciaMaximaCantidad = Double
						.valueOf(Constantes.DIFERENCIA_MAX_CANTIDAD);
			} else {
				diferenciaMaximaMonto = Double.valueOf(Constantes.DIF_MAX_MTO);
				diferenciaMaximaPeso = Double.valueOf(Constantes.DIF_MAX_PESO);
				diferenciaMaximaCantidad = Double
						.valueOf(Constantes.DIF_MAX_CANT);

			}

			if (Math.abs(dif_mto_fobdol) > diferenciaMaximaMonto) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_fobdol)
						.append(" entre el monto fob consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_fobdol), 3) + ").");

			} else if (Math.abs(dif_mto_fletedol) > diferenciaMaximaMonto) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_fletedol)
						.append(" entre el monto del flete consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_fletedol), 3) + ").");

			} else if (Math.abs(dif_mto_segdol) > Constantes.DIF_MAX_MTO) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_segdol)
						.append(" entre el monto del seguro consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_segdol), 3) + ").");

			} else if (Math.abs(dif_mto_ajuste) > diferenciaMaximaMonto) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_ajuste)
						.append(" entre el monto de los ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_ajuste), 3) + ").");

			} else if (Math.abs(dif_mto_ajuste_otr) > Constantes.DIF_MAX_MTO) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_ajuste_otr)
						.append(" entre el monto de otros ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_ajuste_otr), 3) + ").");

			} else if (Math.abs(dif_mto_valoradu) > diferenciaMaximaMonto) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_mto_valoradu)
						.append(" entre el valor aduana consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_mto_valoradu), 3) + ").");

			} else if (Math.abs(dif_cnt_peso_neto) > diferenciaMaximaPeso) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_cnt_peso_neto)
						.append(" entre el peso neto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_cnt_peso_neto), 3) + ").");

			} else if (Math.abs(dif_cnt_peso_bruto) > diferenciaMaximaPeso) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_cnt_peso_bruto)
						.append(" entre el peso bruto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_cnt_peso_bruto), 3) + ").");

			} else if (Math.abs(dif_cnt_bulto) > diferenciaMaximaCantidad) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_cnt_bulto)
						.append(" entre la cantidad de bultos consignada en la diligencia y la acumulada en las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_cnt_bulto), 3) + ").");

			} else if (Math.abs(dif_cnt_unifis) > diferenciaMaximaCantidad) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_cnt_unifis)
						.append(" entre la cantidad de unidades fisicas consignada en la diligencia y la acumulada en las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_cnt_unifis), 3) + ").");

			} else if (Math.abs(dif_cnt_comer) > diferenciaMaximaCantidad) {
				res.append("Hay una diferencia de ")
						.append(bd_dif_cnt_comer)
						.append(" entre la cantidad de unidades comerciales consignada en la diligencia y la acumulada en las series (sumatoria de series "
								+ SunatNumberUtils.scaleHalfUp(new BigDecimal(
										dbl_cnt_comer), 3) + ").");
			}

			if (!"".equals(res.toString().trim()) && lstSeriesRecti != null
					&& lstSeriesRecti.size() > 0) {
				res.append("\n")
						.append("Se le sugiere revisar y/o confirmar los datos rectificado(s) de la(s) serie(s) : ");

				for (String codSerie : lstSeriesRecti) {
					res.append(codSerie).append(", ");
				}
				res = new StringBuilder(res.toString().trim()
						.substring(0, (res.toString().trim().length() - 1)));
			}

		} else {
			res.append("No se ha registrado informacion de las series");
		}

		WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSeries);
		return (res.toString().trim());
	}

	/**
	 * Valida datos de �tems asociados a una serie
	 * 
	 * olunar - 30-05-2012.
	 * 
	 * @param mapCabDeclaraActual
	 *            the map cab declara actual
	 * @param lstDetDeclaraActual
	 *            the lst det declara actual
	 * @return String
	 * @author jlunah
	 */
	private String validaSeriesItemsFactura(
			Map<String, Object> mapCabDeclaraActual,
			List<Map<String, Object>> lstDetDeclaraActual) {
		StringBuilder res = new StringBuilder("");
		String numSerie = "";
		String numSerieItem = "";

		List<String> lstSeriesErr = new ArrayList<String>();
		List<List<String>> lstSerieItemErr = new ArrayList<List<String>>();
		List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual
				.get("lstFormBProveedor");
		List<Map<String, Object>> listaItemFacturas = null;
		List<Map<String, Object>> lstSeriesItem = null;

		if (lstFormBProveedor != null) {
			for (Map<String, Object> serie : lstDetDeclaraActual) {
				numSerie = serie.get("NUM_SECSERIE").toString();
				List<String> lstItemsErr = new ArrayList<String>();
				for (Map<String, Object> proveedor : lstFormBProveedor) {
					if (proveedor.get("lstComproBPago") != null) {
						for (Map<String, Object> factura : (List<Map<String, Object>>) proveedor
								.get("lstComproBPago")) {
							listaItemFacturas = factura.get("lstItemFactura") != null ? (List<Map<String, Object>>) factura
									.get("lstItemFactura")
									: new ArrayList<Map<String, Object>>();

							for (Map<String, Object> itemFactura : listaItemFacturas) {
								lstSeriesItem = (List<Map<String, Object>>) itemFactura
										.get("lstSeriesItem");
								if (lstSeriesItem != null) {
									for (Map<String, Object> itemSerie : lstSeriesItem) {
										numSerieItem = itemSerie.get(
												"NUM_SECSERIE").toString();
										if (numSerieItem.equals(numSerie)) {
											if (!serie
													.get("COD_ESTMERC")
													.toString()
													.equals(itemFactura.get(
															"COD_ESTMERC")
															.toString())) {
												lstItemsErr.add(itemFactura
														.get("NUM_SECITEM")
														.toString());
											}
										}
									}
								}
							}
						}
					}
				}
				if (!CollectionUtils.isEmpty(lstItemsErr)) {
					lstSeriesErr.add(numSerie);
					lstSerieItemErr.add(lstItemsErr);
				}
			}
		}
		if (!CollectionUtils.isEmpty(lstSerieItemErr)) {
			for (int i = 0; i < lstSeriesErr.size(); i++) {
				if (lstSerieItemErr.get(i).size() > 1)
					res.append("Estado de la mercanc�a de los �tems");
				else
					res.append("Estado de la mercanc�a del �tem");
				for (int j = 0; j < lstSerieItemErr.get(i).size(); j++) {
					res.append(" " + lstSerieItemErr.get(i).get(j));
					if (j < lstSerieItemErr.get(i).size() - 1)
						res.append(",");
				}
				if (lstSerieItemErr.get(i).size() > 1)
					res.append(" son diferentes a su correlaci�n con la serie "
							+ lstSeriesErr.get(i) + ".");
				else
					res.append(" es diferente a su correlaci�n con la serie "
							+ lstSeriesErr.get(i) + ".");
				res.append("\n");
			}
		}
		return res.toString();
	}

	/**
	 * Metodo que permite colocar a un proveedor su lista de facturas.
	 * 
	 * @param declaracion
	 *            the declaracion
	 * @param lstFacturas
	 *            the lst facturas
	 * @param num_secprove
	 *            the num_secprove
	 * @author jlunah
	 */
	private void colocarLstFacturas(Map declaracion, List<Map> lstFacturas,
			String num_secprove) {
		if (!CollectionUtils.isEmpty(declaracion)) {
			List<Map> lstProve = (ArrayList) declaracion
					.get("lstFormBProveedor");
			String codProv;
			List factAsig = new ArrayList();
			for (Map prov : lstProve) {
				codProv = prov.get("num_secprove").toString().trim();
				if (codProv.equals(num_secprove)) {
					factAsig = Utilidades.copiarLista(lstFacturas);
					prov.put("lstComproBPago", factAsig);
					break;
				}
			}
		}
	}


	/**
	 * Metodo que permite cargar en Session las series de determinada DUA.
	 * 
	 * @param request
	 *            the request
	 * @author jlunah
	 */
	private void cargarSeriesSesion(HttpServletRequest request) {
		// Cargamos las series en sesion
		List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) WebUtils
				.getSessionAttribute(request, "lstDetDeclaraActual");

		if (CollectionUtils.isEmpty(lstDetDeclara)) { // si esta vacio o null
														// obtener de BD
			Map declaracion = (HashMap) WebUtils.getSessionAttribute(request,
					"mapCabDeclaraActual");
			Map<String, String> params = new HashMap<String, String>();
			params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			params.put("num_corredoc", declaracion.get("NUM_CORREDOC")
					.toString().trim());
			params.put("num_declaracion", declaracion.get("NUM_DECLARACION")
					.toString().trim());
			params.put("cod_aduana", declaracion.get("COD_ADUANA").toString()
					.trim());
			params.put("ann_presen", declaracion.get("ANN_PRESEN").toString()
					.trim());
			params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString()
					.trim());
			params.put("acceso", "");
			lstDetDeclara = serieService.obtenerListadoSeries(params);

			WebUtils.setSessionAttribute(request, "lstDetDeclara",
					lstDetDeclara);
			List lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
			lstDetDeclaraActual = Utilidades.copiarLista((List) lstDetDeclara);
			WebUtils.setSessionAttribute(request, "lstDetDeclaraActual",
					lstDetDeclaraActual);
		}
	}

	/**
	 * Metodo que valida el paso del estado de la DUA de Revision a en Proceso.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @author jlunah
	 */
	public ModelAndView validaFromRevisionToProceso(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView res = new ModelAndView(this.jsonView);
		try {
			Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(
					request, "mapCabDeclaraActual");
			String validacion = this.declaracionService
					.validarFechaRecepcion(mapCabDeclaraActual);
			res.addObject("res", validacion);
		} catch (Exception e) {
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			res.addObject("beanM", rBean);
		}

		return res;
	}

	/**
	 * Permite mostrar pantalla de Busqueda de Declaracion para la Consulta de
	 * la DUA y la Diligencia con Continuacion de Despacho.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @author jlunah
	 */
	public ModelAndView cargarBusqDeclaracionDescargaParcial(
			HttpServletRequest request, HttpServletResponse response) {

		try {

			UsuarioBean userSession = (UsuarioBean) WebUtils
					.getSessionAttribute(request, "usuarioBean");
			if (userSession == null) {
				return new ModelAndView("PagM", "message",
						"Usuario no logueado");
			}

			Utilidades.inicializarMapasSesion(request);
			UserNameHolder.set(userSession.getNroRegistro(),
					request.getRemoteAddr());

			ServletWebRequest webRequest = new ServletWebRequest(request);
			String codAduana = webRequest.getParameter("codAduana") != null ? webRequest
					.getParameter("codAduana") : soporteService
					.obtenerAduana(request);
			String annPresen = webRequest.getParameter("annPresen") != null ? webRequest
					.getParameter("annPresen") : String.valueOf(Calendar
					.getInstance().get(Calendar.YEAR));
			String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest
					.getParameter("codRegimen") : "";
			String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
					.getParameter("numDeclaracion") : "";
			Map<String, String> params = new HashMap<String, String>();

			params.put("cod_aduana", codAduana);
			params.put("ann_presen", annPresen);
			params.put("cod_regimen", codRegimen);
			params.put("num_declaracion", numDeclaracion);
			params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			params.put("numPase", Constantes.NUM_PASE);

			ModelAndView res = new ModelAndView("BusqDeclaracionDescargaParcial");
			res.addObject("params", params);
			res.addObject("lstRegimenes",
					catalogoAyudaService.getListaElementosGrupo("100"));

			List<Map<String, String>> lstAduana = catalogoAyudaService
					.getListaElementosGrupo("139");
			for (Map<String, String> map : lstAduana) {
				map.put("cod_des_corta", ((String) map.get("cod_datacat"))
						.concat("-").concat((String) map.get("des_corta")));
				if (((String) map.get("cod_datacat")).equals(codAduana)) {
					params.put("des_aduana", (String) map.get("des_corta"));
				}
			}
			res.addObject("lstAduana", SojoUtil.toJson(lstAduana));

			return res;

		} catch (Exception e) {
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "Error", rBean);
		}
	}

	/**
	 * Metodo que valida la Declaracion con continuacion de despacho.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 * 
	 */
	public ModelAndView validarDeclaParaDescargaParcial(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		Utilidades.limpiarMapasSesion(request);

		ModelAndView modelView = new ModelAndView();
		Map<String, Object> params = new HashMap<String, Object>();
		UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(
				request, "usuarioBean");
		params.put("documentoAduanero",
				request.getParameter("hdn_documentoAduanero"));
		params.put("codigoFuncionario", bUsuario.getNroRegistro());
		params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
		params.put("ann_presen", request.getParameter("txt_ann_presen"));
		params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
		params.put("des_regimen", request.getParameter("hdn_des_regimen"));
		params.put("num_declaracion",
				request.getParameter("txt_num_declaracion"));

		params.put(
				"acceso",
				request.getParameter("hdn_acceso") != null ? request
						.getParameter("hdn_acceso") : "");
		Map<String, Object> mapCabDeclara = null;
		mapCabDeclara = declaracionService.validarDeclaParaDescargaParcial(params);

		/* olunar 309 - Obtener DUA en objetos */
		DUA dua = getDeclaracionService.getCabDUA(params.get("cod_aduana")
				.toString(), params.get("num_declaracion").toString(), params
				.get("ann_presen").toString(), params.get("cod_regimen")
				.toString());
		WebUtils.setSessionAttribute(request, "dua", dua);
		/* fin */
		WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
		Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
		mapCabDeclaraActual.putAll(mapCabDeclara);
		WebUtils.setSessionAttribute(request, "mapCabDeclaraActual",
				mapCabDeclaraActual);
		modelView = new ModelAndView(this.jsonView, "mapCabDeclaraActual",
				mapCabDeclaraActual);
		return modelView;
	}


	/**
	 * Iniciar declaracion con continuacion de despacho.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView iniciarDeclaracionDescargaParcial(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ModelAndView modelView = null;
		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
		String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
		String acceso = "";
		
		String modifDilig = request.getParameter("hdn_modifDilig") != null ? request.getParameter("hdn_modifDilig") : "";
		
		acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";
		if (!(acceso.equals("00")) && Constantes.ESTADO_DECLARACION_REVISION.equals(codigoEstadoDUA) || codigoEstadoDUA.equals(Constantes.ESTADO_NOTIFICADO)) {
			
			WebUtils.setSessionAttribute(request, "tipoDiligencia", "01"); 
			
			// en revision
			modelView = declaracionDescargaParcialEnRevision(request, response);

		} else if (modifDilig.equals("MOD") || acceso.equals("00")
				|| Constantes.ESTADO_DILIG_PROCESO.equals(codigoEstadoDUA)) {
			modelView = cargaDeclaracionDescargaParcial(request, response);
		} else {
			modelView = declaracionDescargaParcialEnRevision(request, response);
		}
		return modelView;
	}

	/**
	 * Metodo que realiza el cambio de estado en la DUA a "En proceso".
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView revisionToProceso(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView modelView = null;
		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils
				.getSessionAttribute(request, "mapCabDeclaraActual");
		String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
		if (Constantes.ESTADO_DECLARACION_REVISION.equals(codigoEstadoDUA)) {
			modelView = this.cargaDeclaracionDescargaParcial(request, response);
		} else {
			modelView = this.declaracionDescargaParcialEnRevision(request,
					response);
		}
		return modelView;
	}

	/**
	 * Metodo que obtiene el listado de Series invocado se la opcion se Series
	 * de la consulta de DUA acceso="00".
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView obtenerListadoSeries(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession();
		Map<String, String> params = new HashMap<String, String>();
		try {
			params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
			params.put("num_declaracion",
					request.getParameter("hdn_num_declaracion"));
			params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
			params.put("ann_presen", request.getParameter("hdn_ann_presen"));
			params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
			params.put(
					"acceso",
					request.getParameter("hdn_acceso") != null ? request
							.getParameter("hdn_acceso") : "");
			Map<String, Object> mapCabDeclara = (Map<String, Object>) session
					.getAttribute("mapCabDeclaraActual");
			request.setAttribute("params", params);
			// Para Declaracion en Proceso se filtran las Series
			params.put("estadoDUA", mapCabDeclara.get("COD_ESTDUA").toString());

			String tipoDiligencia = (String) getVariableSesion(request,
					EnumVariablesSession.TIP_DILIGENCIA);
			if ("10".equals(tipoDiligencia)) {
				if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null
						&& "EN_PROCESO".equals(mapCabDeclara.get(
								"COD_ESTADO_RECTIFICACION_OFICIO").toString())) {
					params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
				}

			}

			List lstDetDeclara = serieService.obtenerListadoSeries(params);
			session.setAttribute("lstDetDeclara", lstDetDeclara);
			List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session
					.getAttribute("lstDetDeclaraActual");
			if (CollectionUtils.isEmpty(lstDetDeclaraActual)) {

				List<Map<String, Object>> lstDetDeclaraActualTmp = new ArrayList<Map<String, Object>>();
				lstDetDeclaraActualTmp = Utilidades.copiarLista(lstDetDeclara);
				/* jlunah */
				for (Map<String, Object> serieDet : lstDetDeclaraActualTmp) {
					serieDet.put("OBSERVACION", "observacion por defecto");
				}
				/* fin */
				session.setAttribute("lstDetDeclaraActual",
						lstDetDeclaraActualTmp);
				lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
				lstDetDeclaraActual.addAll(lstDetDeclaraActualTmp);
				
				 Map<String, Object> param = new HashMap<String, Object>();
			        param.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
			        List lstSeriesItem = serieService.obtenerSeriesItem(param);
			        session.setAttribute("lstSeriesItem", lstSeriesItem);
				
				 List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                         request,
                         "lstSeriesItemActual");
				 if (CollectionUtils.isEmpty(lstSeriesItemActual))
			        {
			          lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
			          session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
			        }
				
				 List lstItemFactura = declaracionService.obtenerItemFactura(param);
			        session.setAttribute("lstItemFacturaActual", lstItemFactura);
				
				/**Inicio de cambios P24 -bug24642***/ 
		        List lstItemVehic = new ArrayList<Map<String, Object>>();
		      
		        
		        if(!CollectionUtils.isEmpty(lstItemFactura)){
					for(int j=0; j<lstItemFactura.size(); j++){
						Map<String,Object> mapDatosVehic = new HashMap<String, Object>() ;
						Map<String, Object> mapItemFactura=	(Map<String, Object>) lstItemFactura.get(j);
						String descripcion =  mapItemFactura.get("COD_TIPDESCRMIN")!=null?mapItemFactura.get("COD_TIPDESCRMIN").toString():" ";
						if("01".equals(descripcion)){//es vehiculos
		    				mapDatosVehic.put("NUM_SECITEM", mapItemFactura.get("NUM_SECITEM"));
		    				mapDatosVehic.put("ANN_FABRICACION", mapItemFactura.get("ANN_FABRICACION"));
		    			}
						if(!CollectionUtils.isEmpty(mapDatosVehic)){
							lstItemVehic.add(mapDatosVehic);
						}
					}
		        }
		        /**Fin de cambios P24 -bug24642***/ 
		        
		        /**Inicio de cambios P24 -bug24639***/
		        for (Map<String , Object> map : lstDetDeclaraActual){
		        	int totalItemsSerie = 0;
		        	String ann_fabric = "0"; 
		        	ArrayList<String> lstItemsSerie;
		        	String num_serie =  map.get("NUM_SECSERIE").toString();
		        	if(!CollectionUtils.isEmpty(lstSeriesItem)){
			        	for (int i=0 ; i <lstSeriesItem.size(); i++){  
			        		Map<String, Object> mapSerieItem=	(Map<String, Object>) lstSeriesItem.get(i);
			        		String num_secSerie = mapSerieItem.get("NUM_SECSERIE").toString();
			        		String num_secItem = mapSerieItem.get("NUM_SECITEM").toString();
			        		if(num_serie.equals(num_secSerie)){
			        			totalItemsSerie=totalItemsSerie+1;
			        			if(!CollectionUtils.isEmpty(lstItemVehic)){
			        				for(int j=0; j<lstItemVehic.size(); j++){
			        					Map<String, Object> mapItemVehic =	(Map<String, Object>) lstItemVehic.get(j);
			        					String num_item = mapItemVehic.get("NUM_SECITEM").toString();
			        					if(num_secItem.equals(num_item)){	        						 
			        	        				ann_fabric = mapItemVehic.get("ANN_FABRICACION")!=null?mapItemVehic.get("ANN_FABRICACION").toString():"0";
			        	        				break;//solo hay un vehiculo por serie
				        				}
				        			}
			        			}
			        			
			        		}
			        	}
		        	}
		        	map.put("tot_items", totalItemsSerie);
		        	map.put("annFabricVehic",ann_fabric);
		        } /**Fin de cambios P24 -bug24639***/
				
			}

			// tiene formato B,seteando los datos en session de la serie-item y
			// item-factura
			if (mapCabDeclara.get("IND_FORMBPROVEEDOR").equals("0")) {
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
				List lstSeriesItem = serieService.obtenerSeriesItem(param);
				session.setAttribute("lstSeriesItem", lstSeriesItem);
				List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils
						.getSessionAttribute(request, "lstSeriesItemActual");
				if (CollectionUtils.isEmpty(lstSeriesItemActual)) {
					lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
					session.setAttribute("lstSeriesItemActual",
							lstSeriesItemActual);
				}
				List lstItemFactura = declaracionService
						.obtenerItemFactura(param);
				session.setAttribute("lstItemFacturaActual", lstItemFactura);
			}

			if (!("00".equals(params.get("acceso")))) {
				request.setAttribute("lstMonedas",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_MONEDAS));
				request.setAttribute("lstIncidadoresSENASA",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_INDICADOR_SERVICIO_CUSTODIA_SENASA));
				request.setAttribute("lstExoneraciones",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_EXONERACION_CIS));
				request.setAttribute("lstPaises",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_PAISES_NUEVA_CODIFICACION));
				request.setAttribute("lstUnidadesMedida",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_UNIDADES_MEDIDA));
				request.setAttribute("lstUnidadesMercancia",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_UNIDADES_MERCANCIA));
				request.setAttribute("lstTiposMercanciaRestringida",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_TIPO_MERCANCIAS_RESTRINGIDAS));
				request.setAttribute("lstUsosGuardiaCustodia",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_USO_GUARDA_CUSTODIA));
				request.setAttribute("lstTiposDocSoporteAsociado",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_TIPO_DOCUMENTO_SOPORTE_ASOCIADO));
				request.setAttribute("lstTiposProrrateoFlete",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_TIPO_PRORRATEO_FLETES));
				request.setAttribute("lstTiposConoSada",
						catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_DESCRIPCION_SADA));

				// Obtener catalogo 25 y agregar el c�digo a la descripci�n
				List<Map<String, String>> lstEstadosMercancia = catalogoAyudaService
						.getElementosCat(ConstantesDataCatalogo.COD_CATALOGO_ESTADO_MERCANCIA,
								"cod_datacat");
				for (Map<String, String> estadoMerc : lstEstadosMercancia) {
					estadoMerc.put("des_corta", estadoMerc.get("cod_datacat")
							+ " " + estadoMerc.get("des_corta"));
				}

				request.setAttribute("lstEstadosMercancia",
						SojoUtil.toJson(lstEstadosMercancia));

				Map<String, Object> mapTabLibe = new HashMap<String, Object>();

				FechaBean fechaBean = new FechaBean(
						(Timestamp) mapCabDeclara.get("FEC_DECLARACION"));

				mapTabLibe.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
				mapTabLibe.put("fechaDeclaracion",
						Long.valueOf(fechaBean.getFormatDate("yyyyMMdd")));
				mapTabLibe.put("tlib", "I");

				request.setAttribute("lstTPI",
						soporteService.obtenerTabLibeByParams(mapTabLibe));
				mapTabLibe.put("tlib", "T");

				request.setAttribute("lstTPN",
						soporteService.obtenerTabLibeByParams(mapTabLibe));
				mapTabLibe.put("tlib", "C");

				request.setAttribute("lstCodigoLiberatorio",
						soporteService.obtenerTabLibeByParams(mapTabLibe));
			}

			/*
			 * solo para la consulta se verifica el historico de las series
			 * adicionadas o eliminadas pero solo muestra la ultima para el caso
			 * de una seria adicionada en P.A y despues eliminada muestra el
			 * evento mas reciente
			 */
			if ("00".equals(params.get("acceso"))) {

				String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC")
						.toString();
				List<Map<String, Object>> listaSeriesADDyDEL = rectificacionService
						.obtenerDatosAnuladosOAdicionados(numCorreDoc, "T0052");

				// agrega la columna estado en la lista y la pone en session
				for (Map mapDatosModificados : listaSeriesADDyDEL) {
					String numSecSerie = (String) mapDatosModificados.get("PK");

					// agrego los campos a la serie
					for (Map mapDetDeclaraActual : lstDetDeclaraActual) {
						if (numSecSerie.equals((mapDetDeclaraActual
								.get("NUM_SECSERIE").toString()))) {
							mapDetDeclaraActual.putAll(mapDatosModificados);
						}
					}
				}
			}

			ModelAndView res;

			if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO
					.equals(getTipoDiligencia(request))) {

				if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null
						&& "EN_PROCESO".equals(mapCabDeclara.get(
								"COD_ESTADO_RECTIFICACION_OFICIO").toString())) {
					lstDetDeclaraActual = Utilidades
							.quitarRegistrosMarcadaParaEliminar(lstDetDeclaraActual);
					Ordenador.sortDesc(lstDetDeclaraActual, "NUM_SECSERIE",
							Ordenador.ASC);
					session.setAttribute("lstDetDeclaraActual",
							lstDetDeclaraActual);
				}

				res = new ModelAndView(PAGINA_PRINCIPAL_DETALLE,
						"detDeclaraViewListJson",
						SojoUtil.toJson(lstDetDeclaraActual));
			} else {
				res = new ModelAndView("RegSerieDescargaParcial",
						"detDeclaraViewListJson",
						SojoUtil.toJson(lstDetDeclaraActual));
			}

			res.addObject("COD_ESTDUA", (String) ((HashMap) session
					.getAttribute("mapCabDeclaraActual")).get("COD_ESTDUA"));
			res.addObject("acceso", (String) params.get("acceso"));
			return res;
		} catch (ServiceException e) {
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean.setMensajeerror(e.getMessage());

			return new ModelAndView("PagM", "Error-Controllador:", mensajeBean);
		} catch (Throwable e) {
			log.error("error", e);
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean
					.setMensajeerror("Ocurrio un error al obtener el listados de la series de la dua.");
			return new ModelAndView("PagM", "Error-Controllador:", mensajeBean);
		}
	}

	/**
	 * Editar serie session.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView editarSerieSession(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
		params.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
		// valido este campo no es enviado por RegSerie de la regularizacion 664
		params.put(
				"NUM_OPERACION",
				request.getParameter("hdn_num_operacion") != null ? request
						.getParameter("hdn_num_operacion") : "");

		List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils
				.getSessionAttribute(request, "lstDetDeclaraActual");
		Map<String, Object> detDeclaraViewMap = serieService
				.obtenerSerieSession(params, detDeclaraViewList);
		// /*jlunah*/
		// detDeclaraViewMap.put("OBSERVACION", "observacion por defecto");
		// /*fin*/
		Map mapCabDeclaraActual = (Map<String, Object>) WebUtils
				.getSessionAttribute(request, "mapCabDeclaraActual");

		String numPartida = detDeclaraViewMap.get("NUM_PARTNANDI") != null ? detDeclaraViewMap
				.get("NUM_PARTNANDI").toString() : "";
		String fechaDeclaracion = SunatDateUtils.getFormatDate(SunatDateUtils
				.getDateFromUnknownFormat(mapCabDeclaraActual.get(
						"FEC_DECLARACION").toString()), "yyyyMMdd");

		List lstTNAN = new ArrayList();
		lstTNAN = soporteService
				.obtenerLstTasaNAN(numPartida, fechaDeclaracion);

		ModelAndView view = new ModelAndView(this.jsonView,
				"detDeclaraViewMap", detDeclaraViewMap);
		view.addObject("lstTNAN", lstTNAN);

		return view;
	}

	/**
	 * @author jlunah
	 * */
	private BigDecimal obtenerFobBD(Map<String, Object> seriePk) {

		BigDecimal fob = BigDecimal.ZERO;
		List<Map<String, Object>> lst = serieService.select(seriePk);
		if (!CollectionUtils.isEmpty(lst)) {
			fob = Utilidades.toBigDecimal(lst.get(0).get("MTO_FOBDOL"));
		}

		return fob;
	}

	/**
	 * <p>
	 * permit actualizar los datos de la SERIE en session
	 * </p>
	 * .
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return modelView (this.jsonView)
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView grabarSerieSession(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView modelView = null;
		try {
			Map<String, Object> requestParameterMap = new HashMap<String, Object>();
			HttpSession session = request.getSession();
			requestParameterMap.putAll(request.getParameterMap());
			List lstDetDeclaraActual = (List) session
					.getAttribute("lstDetDeclaraActual");
			Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils
					.getSessionAttribute(request, "mapCabDeclaraActual");
			List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils
					.getSessionAttribute(request, "lstSeriesItemActual");

			// TODO: esta funcionalidad hay que activarla pero en la cabecera y
			// que
			// sea condicional
			// Actualizar la Dua con las Modificaciones de la Serie
			String numSecSerieModificada = Utilidades
					.crearCadenaDesdeObjeto(requestParameterMap
							.get("hdn_num_secserie"));
			Map<String, Object> seriePk = new HashMap();
			seriePk.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
			seriePk.put("NUM_SECSERIE", numSecSerieModificada);
			BigDecimal mtoFobItemOld = obtenerFobBD(seriePk);

			/*
			 * Map mapSerieOld = ((lstDetDeclaraActual != null) ?
			 * Utilidades.obtenerElemento((List<Map<String, Object>>)
			 * lstDetDeclaraActual,seriePk) : null); if (mapSerieOld != null &&
			 * mapSerieOld.size() > 0 && mapSerieOld.get("MTO_FOBDOL") != null)
			 * { mtoFobItemOld =
			 * Utilidades.toBigDecimal(mapSerieOld.get("MTO_FOBDOL")); }
			 */
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("IND_FORMBPROVEEDOR",
					mapCabDeclaraActual.get("IND_FORMBPROVEEDOR"));
			params.put("requestParameterMap", requestParameterMap);
			params.put("lstDetDeclaraActual",
					Utilidades.copiarLista(lstDetDeclaraActual));
			params.put("lstSeriesItemActual", lstSeriesItemActual);
			List<Map<String, Object>> detDeclaraViewList = serieService
					.grabarSerie(params);

			BigDecimal mtoFobItemNew = BigDecimal.ZERO;
			Map mapSerieNew = ((detDeclaraViewList != null) ? Utilidades
					.obtenerElemento(
							(List<Map<String, Object>>) detDeclaraViewList,
							seriePk) : null);
			if (mapSerieNew != null && mapSerieNew.size() > 0
					&& mapSerieNew.get("MTO_FOBDOL") != null) {
				mtoFobItemNew = Utilidades.toBigDecimal(mapSerieNew
						.get("MTO_FOBDOL"));
			}

			// verificamos que hay cambios en el FOB o que la serie sea nueva
			if (mtoFobItemOld.compareTo(mtoFobItemNew) != 0
					|| esUnaSerieNueva(seriePk)) {
				// reutilizamos este metodo pero le enviamos el ArrayList vacio
				// para que
				// solo ejecute
				// el prorrateo de seguro
				// actualizarSeriesconFormatoBSession(mapCabDeclaraActual,
				// detDeclaraViewList, new ArrayList());
				// los calculo se hacen sobre la lista actualizada con los datos
				// del formulario
				BigDecimal newMtoTotalFOBDolSumaSeries = Utilidades
						.sumarPorCampo(detDeclaraViewList, "MTO_FOBDOL");
				BigDecimal newMtoSeguroProrratearSumaSeries = Utilidades
						.sumarPorCampo(detDeclaraViewList, "MTO_SEGDOL");
				Date fechaVigenciaPartida = SunatDateUtils
						.getDateFromUnknownFormat(mapCabDeclaraActual.get(
								"FEC_DECLARACION").toString());
				detDeclaraViewList = declaracionCalculoDeDatos
						.prorratearMtoSeguroEnLasSeries(
								newMtoSeguroProrratearSumaSeries,
								newMtoTotalFOBDolSumaSeries,
								fechaVigenciaPartida, detDeclaraViewList);
				if (seriesTieneAlgunTipoProrrateoDeFleteTipo2(detDeclaraViewList)) {
					detDeclaraViewList = declaracionCalculoDeDatos
							.prorratearFlete(detDeclaraViewList);
				}
				actualizarDUAconSeriesSession(mapCabDeclaraActual,
						detDeclaraViewList);
				session.setAttribute("mapCabDeclaraActual", mapCabDeclaraActual);
			}

			for (Map<String, Object> mapSerie : detDeclaraViewList) {
				if (mapSerie.get("NUM_SECSERIE").equals(numSecSerieModificada)) {
					BigDecimal mto_fobdol = Utilidades.toBigDecimal(mapSerie
							.get("MTO_FOBDOL"));
					BigDecimal mto_fletedol = Utilidades.toBigDecimal(mapSerie
							.get("MTO_FLETEDOL"));
					BigDecimal mto_segdol = Utilidades.toBigDecimal(mapSerie
							.get("MTO_SEGDOL"));
					BigDecimal mto_ajuste = Utilidades.toBigDecimal(mapSerie
							.get("MTO_AJUSTE"));
					BigDecimal mto_ajuste_otr = Utilidades
							.toBigDecimal(mapSerie.get("MTO_OTROSAJUSTES"));

					BigDecimal bdValorAduana = declaracionCalculoDeDatos
							.calcularMtoValorAduana(mto_fobdol, mto_fletedol,
									mto_segdol, mto_ajuste, mto_ajuste_otr);
					mapSerie.put("MTO_VALORADU", bdValorAduana);
				}
			}
			session.setAttribute("lstDetDeclaraActual", detDeclaraViewList);
			modelView = new ModelAndView(this.jsonView, "OK",
					"Se ha guardado satisfactoriamente la informaci\u00f3n");
		} catch (Exception e) {
			log.error("*** ERROR ***", e);
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Corrija el problema de validacion y vuelva a intentar grabar la serie.");

			modelView = new ModelAndView(this.jsonView, "beanM", rBean);
		}

		return modelView;
	}

	/**
	 * Es una serie nueva, verifica si la serie existe en base de datos.
	 * 
	 * @param seriePk
	 *            [Map<String,Object>] serie pk
	 * @return true, if successful
	 * @author jlunah
	 */
	private boolean esUnaSerieNueva(Map<String, Object> seriePk) {
		List<Map<String, Object>> lst = serieService.select(seriePk);
		return CollectionUtils.isEmpty(lst) ? true : false;
	}

	/**
	 * Metodo que permite obtener los datos de los catalogos a usar dentro de la
	 * edicion de la declaracion.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView declaracionEnProceso(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Map declaracion = (HashMap) WebUtils.getSessionAttribute(request,
				"mapCabDeclaraActual");

		// se actualiza los datos iniciales de la serieOrigen

		HttpSession session = request.getSession();
		Map<String, String> params = new HashMap<String, String>();
		params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
		params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString());
		params.put("num_declaracion", declaracion.get("NUM_DECLARACION")
				.toString());
		params.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
		params.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
		params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());
		params.put("acceso", "");

		request.setAttribute("params", params);
		// Para Declaracion en Proceso se filtran las Series
		params.put("estadoDUA", declaracion.get("COD_ESTDUA").toString());
		List lstDetDeclara = serieService.obtenerListadoSeries(params);

		session.setAttribute("lstDetDeclara", lstDetDeclara);

		ModelAndView res = new ModelAndView("RegDiligenciaDescargaParcialDespacho",
				"declaracion", declaracion);
		res.addObject("lstUndTmp", this.catalogoAyudaService
				.getElementosCat(Constantes.CAT_UND_TMP));
		res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

		res.addObject("existeIncid", existenIncidencias(request));
		res.addObject("existeMulta", existenMultas(request));

		/* JLUNAH RIN13 */
		res.addObject("flagConclusionAutomatica", false);
		/* FIN */

		return res;

	}

	/**
	 * Metodo que valida si existen Incidencias, 0: No existen, 1: Si existen.
	 * 
	 * @param request
	 *            the request
	 * @return the string
	 * @author jlunah
	 */
	private String existenIncidencias(HttpServletRequest request) {
		String res = "0";
		List<IncidenciaBean> lstIncidencias = (ArrayList) WebUtils
				.getSessionAttribute(request, "lstIncidencias");
		if (!CollectionUtils.isEmpty(lstIncidencias)) {
			for (IncidenciaBean incidBean : lstIncidencias) {
				if (incidBean.getFlagIncidencia()) {
					res = "1";
					break;
				}
			}
		}
		return res;
	}

	/**
	 * Metodo que evalua si existen Multas, 0: No existen, 1: Si existen.
	 * 
	 * @param request
	 *            the request
	 * @return the string
	 * @author jlunah
	 */
	private String existenMultas(HttpServletRequest request) {
		List lstMultaDua = (ArrayList) WebUtils.getSessionAttribute(request,
				"lstMultaDua");

		return (!CollectionUtils.isEmpty(lstMultaDua)) ? "1" : "0";
	}

	/**
	 * Metodo que permite actulizar la Diligencia y la Declaracion en Revision,
	 * asi como recuperar los catalogos a usar.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the model and view
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	public ModelAndView declaracionDescargaParcialEnRevision(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		try {
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_DECLARACION", StringUtils.defaultIfEmpty(webRequest.getParameter("hdn_num_declaracion"), webRequest.getParameter("txt_num_declaracion")));
			params.put("COD_ADUANA", StringUtils.defaultIfEmpty(webRequest.getParameter("hdn_cod_aduana"), webRequest.getParameter("txt_cod_aduana")));
			params.put("ANN_PRESEN", StringUtils.defaultIfEmpty(webRequest.getParameter("hdn_ann_presen"), webRequest.getParameter("txt_ann_presen")));
			params.put("COD_REGIMEN", StringUtils.defaultIfEmpty(webRequest.getParameter("hdn_cod_regimen"), webRequest.getParameter("sel_cod_regimen")));
			params.put("EN_PROCESO", "0");
			
			UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			FechaBean fecActual = new FechaBean();
			UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());
			
			Map<String, Object> declaracion = this.declaracionService.obtenerDeclaracion(params);
			
			String numDocIdentPdf = declaracion.get("NUM_DOCIDENT_PDF") != null ? (String) declaracion.get("NUM_DOCIDENT_PDF") : "";
			String codLocalAnexo = declaracion.get("COD_LOCALANEXO") != null ? (String) declaracion.get("COD_LOCALANEXO") : "";
			String direccionLocalAnexo = "";
			
			if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf)) {
				
				direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
				
				if (SunatStringUtils.isEmpty(direccionLocalAnexo)) { 
					
					// si no esta registrado el local
					direccionLocalAnexo = "No registrado";
					
				}
				
			} else {
				
				direccionLocalAnexo = "No registrado";
				
			}
			
			declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
			
			String numDocIdentPdd = declaracion.get("NUM_DOCIDENT_PDD") != null ? (String) declaracion.get("NUM_DOCIDENT_PDD") : "";
			String codLocalAnexoDeposito = declaracion.get("COD_LOCALANEXODEPOSITO") != null ? (String) declaracion.get("COD_LOCALANEXODEPOSITO") : "";
			String direccionLocalAnexoDeposito = "";
			
			if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd)) {
				
				direccionLocalAnexoDeposito = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd, codLocalAnexoDeposito);
				
				if (SunatStringUtils.isEmpty(direccionLocalAnexoDeposito)) { 
					
					// si no esta registrado el local
					direccionLocalAnexoDeposito = "No registrado";
					
				}
				
			} else {
				
				direccionLocalAnexoDeposito = "No registrado";
				
			}
			
			declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);
			
			if (!declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_DECLARACION_REVISION)) {
				
				Map<String, Object> diligencia = new HashMap();
				// Obtenemos los datos para registrar los plazos del proceso
				// Obtenemos los parametros de request
				diligencia.put("IND_INCIDENCIA", webRequest.getParameter("incidencia"));
				diligencia.put("IND_MULTA", webRequest.getParameter("multa"));
				diligencia.put("DES_RESULTADO", webRequest.getParameter("resultado"));
				diligencia.put("COD_TIPDILIGENCIA", "01");
				diligencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				diligencia.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
				
				Map<String, Object> paramsDiligencia = new HashMap();
				paramsDiligencia.put("mapCabDiligenciaActual", diligencia);
				
				diligenciaService.grabarDiligenciaByInicioRevision(paramsDiligencia);
				
			}
			
			Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
			
			/* P14 - 3006 - Inicio - lrodriguezc */
			
			/*
			declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_DECLARACION_REVISION));
			*/
			
			/* P14 - 3006 - Final - lrodriguezc */
			
			paramDeclaracion.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			
			/* P14 - 3006 - Inicio - lrodriguezc */
			
			/*
			paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			*/
			
			/* P14 - 3006 - Final - lrodriguezc */
			
			paramDeclaracion.put("COD_USUMODIF", bUsuario.getNroRegistro());
			paramDeclaracion.put("FEC_MODIF", fecActual.getTimestamp());
			
			/* P14 - 3006 - Inicio - lrodriguezc */
			
			if (!Constantes.ESTADO_NOTIFICADO.equals(declaracion.get("COD_ESTDUA"))){
				
				declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
				declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_DECLARACION_REVISION));
				paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
				
			}else{
				
				declaracion.put("COD_ESTDUA_DESC", catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA, Constantes.ESTADO_NOTIFICADO));
				paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_NOTIFICADO);
				
			}
			
			/* P14 - 3006 - Final - lrodriguezc */
			
			declaracionService.updateDeclaracion(paramDeclaracion);
			
			// 27.05.2010 BIM para DUA's forzadas a reconocimiento físico
			if ("08".equals((String) declaracion.get("COD_INDICADOR"))) {
				
				declaracion.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia("F"));
				
			} else {
				
				declaracion.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia((String) declaracion.get("COD_CANAL")));
				
			}
			
			Map<String, Object> declaracionActual = new HashMap<String, Object>();
			
			if (declaracion != null && declaracion.size() > 0) {
				
				declaracionActual.putAll(declaracion);
				
			}
			
			Map diligencia = new HashMap();
			diligencia.put("IND_INCIDENCIA", "");
			diligencia.put("IND_MULTA", "");
			diligencia.put("DES_RESULTADO", "");
			
		      //P24 - PAS20165E220200099
		      ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
		      Observacion observacion = new Observacion();
		      observacion.setNumcorredoc(SunatNumberUtils.toLong(declaracionActual.get("NUM_CORREDOC")));
		      observacion.setCodtipobserva("01"); //solo las observaciones de datos generales, si se requiere para otro formulario se deber� filtrar por JSP y colocar null en tipo de obs
		      List<Observacion> listaObservaciones = observacionService.buscarObservacion(observacion);
		      if(CollectionUtils.isEmpty(listaObservaciones)){
		    	  declaracionActual.put("OBSERVACIONES", null);
		    	  declaracionActual.put("CANT_OBS", 1);
		      }else{
		    	  String descCodObs;
		    	  for(Observacion obs : listaObservaciones){
		    		  descCodObs =this.catalogoAyudaService.getDescripcionDataCatalogo("369",obs.getCodtipobserva());
		    		  obs.setCodtipobserva(obs.getCodtipobserva().concat(" - ").concat((descCodObs!=null?descCodObs:"")));
		    	  }
		    	  declaracionActual.put("OBSERVACIONES", listaObservaciones);
		    	  declaracionActual.put("CANT_OBS", listaObservaciones.size());
		      }		  			
			
		      //P24-PAS20165E220200099 - Inicio
		      
		      Map<String, Object> tieneVP = new HashMap<String, Object>();
		      String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613
		      boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
		      String tipoRegimen = (String) params.get("COD_REGIMEN");			      
		      tieneVP = null;
		      String flag = "";
			  flag = WUtil.getParam(request,"hdn_flag");
			  if(flag==""){
			  	flag = "-1";
			  }
		      Map<String, Object> paramsValidador = new HashMap<String, Object>(); 
		      paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
		      paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
		      if(indicadorDUAValorProvActivo){
		      //Fin RIN10 mpoblete refactor 	  
		      if(flag!="-1" && flag.equals("1")){
		      	  if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
		     		    String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();        		  
		      	     	//verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
		      	  	declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
		      	  	paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
		      	  	tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
		     		    //Inicio RIN10 BUG 22611,22613
		     		    if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
		     		    	verificarValorProvisional(params,declaracion);
		     		    	indicadorVFobProvVP = "SI";
		     		    }
		     		    //Fin RIN10 BUG 22611,22613
		      	  }
			    }else if(flag!="-1" ||flag.equals("2")){        	 
			      	 if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10	        	 
				             tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
				             //Inicio RIN10 BUG 22611,22613
				             if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
				            	 indicadorVFobProvVP = "SI";
				     		 }
				             //Fin RIN10 BUG 22611,22613
			      	 }
			    }
		      }//RIN10 mpoblete refactor		      
		      
		      if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
		     	//Fin RIN10 BUG 22611,22613			
		  		declaracionActual.put("IND_VALOR_PROV", "1"); 
		  	  }else{
		  		declaracionActual.put("IND_VALOR_PROV", "0"); 
		  	  }
		      //P24-PAS20165E220200099 - Fin	 		      
		      
			// Guardamos en sesion los datos de la declaracion e invocamos el jsp correspondiente
			WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
			WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
			WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);
			
			ModelAndView res = new ModelAndView("RegDiligenciaDescargaParcialRevision");
			res.addObject("declaracion", declaracionActual);
			res.addObject("declaracionP14", declaracionActual);//por  diferencia de claves
			res.addObject("diligencia", declaracionActual);
			res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			
			List lstRevFisica = catalogoAyudaService.getElementosCat(Constantes.CAT_ESTADOS_ASIGNACION);
			List lstNuevaRevFisica = new ArrayList();
			
			if (!CollectionUtils.isEmpty(lstRevFisica)) {
				
				Iterator i1 = lstRevFisica.iterator();
				// Se adciona tipo de asignación de especialista que no se registran en la revision
				while (i1.hasNext()) {
					
					Map<String, Object> mapa = (Map<String, Object>) i1.next();
					
					if (!mapa.get("cod_datacat").equals("01") && !mapa.get("cod_datacat").equals("04")
							&& !mapa.get("cod_datacat").equals("06") && !mapa.get("cod_datacat").equals("08")
							&& !mapa.get("cod_datacat").equals("10")) {
						
						lstNuevaRevFisica.add(mapa);
						
					}
					
				}
				
			}
			
			res.addObject("lstMotivoRevFisico", lstNuevaRevFisica);
			
			return res;
			
		} catch (ServiceException e) {
			
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean.setMensajeerror(e.getMessage());
			return new ModelAndView("PagM", "Error", mensajeBean);
			
		} catch (Throwable e) {
			
			log.error("error", e);
			MensajeBean mensajeBean = new MensajeBean();
			mensajeBean.setMensajeerror("Ocurrio un error al realizar la diligencia en Revision");
			
			return new ModelAndView("PagM", "Error", mensajeBean);
			
		}
		
	}
	
	/**
	 * Series tiene algun tipo prorrateo de flete tipo2.
	 * 
	 * @param lstDetDeclaraActual
	 *            [List] lst det declara actual
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 * @author jlunah
	 */
	private boolean seriesTieneAlgunTipoProrrateoDeFleteTipo2(
			List lstDetDeclaraActual) throws Exception {
		Map filtros = new HashMap();
		filtros.put("COD_TIPFLETE", "2");
		Long cntTipoFlete2 = Utilidades.contarPorCampoFiltradoANDCriterios(
				lstDetDeclaraActual, filtros);

		return cntTipoFlete2.intValue() > 0 ? true : false;
	}

	/**
	 * <p>
	 * Actualiza los datos de montos de la DUA con la sumatoria de la todas las
	 * series
	 * </p>
	 * .
	 * 
	 * @param mapCabDeclara
	 *            <code>java.util.Map</code> Datos en session de la DUA
	 * @param lstDetDeclaraActual
	 *            <code>java.util.List</code> Lista de todas las series
	 *            agregadas, eliminadas o recuperadas
	 * @author jlunah
	 */
	private void actualizarDUAconSeriesSession(
			Map<String, Object> mapCabDeclara,
			List<Map<String, Object>> lstDetDeclaraActual) {

		BigDecimal bgFobCabeceraAcum = BigDecimal.ZERO;
		BigDecimal bgSeguroCabeceraAcum = BigDecimal.ZERO;
		BigDecimal bgFleteCabeceraAcum = BigDecimal.ZERO;
		BigDecimal bgAjusteCabeceraAcum = BigDecimal.ZERO;
		BigDecimal bgOtroAjusteCabeceraAcum = BigDecimal.ZERO;
		BigDecimal bgValoAduanaCabeceraAcum = BigDecimal.ZERO;

		// calcula los montos de todas las series
		for (Map<String, Object> serie : lstDetDeclaraActual) {

			BigDecimal bgFobSerie = BigDecimal.ZERO;
			BigDecimal bgSeguroSerie = BigDecimal.ZERO;
			BigDecimal bgFleteSerie = BigDecimal.ZERO;
			BigDecimal bgAjusteSerie = BigDecimal.ZERO;
			BigDecimal bgOtroAjusteSerie = BigDecimal.ZERO;
			BigDecimal bgAduanaSerie = BigDecimal.ZERO;

			if ("0".equals(serie.get("IND_DEL").toString())) {

				bgFobSerie = new BigDecimal(serie.get("MTO_FOBDOL").toString());
				bgSeguroSerie = new BigDecimal(serie.get("MTO_SEGDOL")
						.toString());
				bgFleteSerie = new BigDecimal(serie.get("MTO_FLETEDOL")
						.toString());
				bgAjusteSerie = new BigDecimal(serie.get("MTO_AJUSTE")
						.toString());
				bgOtroAjusteSerie = new BigDecimal(serie
						.get("MTO_OTROSAJUSTES").toString());
				bgAduanaSerie = new BigDecimal(serie.get("MTO_VALORADU")
						.toString());
			}

			bgFobCabeceraAcum = bgFobCabeceraAcum.add(bgFobSerie);
			bgSeguroCabeceraAcum = bgSeguroCabeceraAcum.add(bgSeguroSerie);
			bgFleteCabeceraAcum = bgFleteCabeceraAcum.add(bgFleteSerie);
			bgAjusteCabeceraAcum = bgAjusteCabeceraAcum.add(bgAjusteSerie);
			bgOtroAjusteCabeceraAcum = bgOtroAjusteCabeceraAcum
					.add(bgOtroAjusteSerie);
			bgAduanaSerie = bgFobSerie.add(bgSeguroSerie).add(bgFleteSerie)
					.add(bgAjusteSerie).add(bgOtroAjusteSerie);
			bgValoAduanaCabeceraAcum = bgValoAduanaCabeceraAcum
					.add(bgAduanaSerie);
			serie.put("MTO_VALORADU", bgAduanaSerie);
		}
		// actualiza el mapa de la DUA con los datos de la serie
		mapCabDeclara.put("MTO_TOTFOBDOL", bgFobCabeceraAcum);
		mapCabDeclara.put("MTO_TOTSEGDOL", bgSeguroCabeceraAcum);
		mapCabDeclara.put("MTO_TOTFLETEDOL", bgFleteCabeceraAcum);
		mapCabDeclara.put("MTO_TOTAJUSTESDOL", bgAjusteCabeceraAcum);
		mapCabDeclara.put("MTO_TOTOTROSAJUSTE", bgOtroAjusteCabeceraAcum);
		mapCabDeclara.put("MTO_TOTVALORADU", bgValoAduanaCabeceraAcum);

	}

	/**
	 * Verificar doc transporte a prorratear.
	 * 
	 * @param request
	 *            [HttpServletRequest] request
	 * @return [List<SumaFleteYPesoPorDocTransporteBean>] list
	 * @throws Exception
	 *             the exception
	 * @author amancillaa
	 * @version 1.0
	 * @author jlunah
	 */
	private List<SumaFleteYPesoPorDocTransporteBean> verificarDocTransporteAProrratear(
			HttpServletRequest request) throws Exception {

		List<Map> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(
				request, "lstDetDeclaraActual");
		if (CollectionUtils.isEmpty((List) lstDetDeclara)) {
			cargarSeriesSesion(request);
			lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request,
					"lstDetDeclaraActual");
		}

		List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear = new ArrayList();
		lstBLProrratear = declaracionCalculoDeDatos
				.obtenerDocTransporteAProrratear(lstDetDeclara);

		return lstBLProrratear;

	}
	
	
	  //P24-PAS20165E220200099
	   private boolean duaTieneIndicadorDUAValorProvActivo(Map<String,Object> declaracion){
			  DatoIndicadores indicadorDUA = new DatoIndicadores();
		      //(RIN10 mpoblete BUG 21916)indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(declaracion.get("NUM_CORREDOC").toString(), pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
			  indicadorDUA =  obtenerIndicadorDUAVP(declaracion.get("NUM_CORREDOC").toString()); 
		      //Inicio RIN10 mpoblete BUG 21738
		      //return (indicadorDUA!=null && "1".equals(indicadorDUA.getIndicadorActivo()));	  
		      return (indicadorDUA!=null);
		      //Fin RIN10 mpoblete BUG 21738
		  }
	   private DatoIndicadores obtenerIndicadorDUAVP(String numCorredoc){
			  DatoIndicadores indicadorDUA = new DatoIndicadores();
			  indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(numCorredoc, pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
			  return indicadorDUA;
		  }
	   private void  verificarValorProvisional(Map<String, Object> params,Map<String, Object> declaracion) {
		  	  DataCatalogo dataCatalogo = RectificacionServiceImpl.getInstance().getDataCatalogoDAO().buscarDataCatalogo(COD_CATALOGO_PORCENTAJE_BIVP, COD_DATACAT_VALOR_PORCENTAJE_BIVP);
		  	  String numero = dataCatalogo.getDesCorta();
		  	  if(StringUtils.isEmpty(numero)){
		  		  numero="0";
		  	  }
		  	  BigDecimal porcentajeBaseImponible = new BigDecimal(numero);
		  	  BigDecimal datoDefault = new BigDecimal("0");
		  	  int evaluacion = porcentajeBaseImponible.compareTo(datoDefault);  	  
		  	  Map<String,Object> paramPadUsuGar = new HashMap<String, Object>();
		  	  paramPadUsuGar.put("NUMRUC", declaracion.get("COD_RUCLUGRECEP").toString());
		  	  paramPadUsuGar.put("IND_USUACTIVO", "1");
		  	  paramPadUsuGar.put("IND_LCVP", "1");
		  	  //declaracion.put("ANN_PRESEN", declaracion.get("ANN_PRESEN").toString().substring(2));
		  	  boolean tieneRucImportador = validarRucImportadorTieneLC(paramPadUsuGar); 
		  	  if(evaluacion==1 && tieneRucImportador){
		  		  if(verificarDeclaracionConLCGenerada(declaracion)){
		  			  //Inicio RIN10 mpoblete BUG 22018
		  			  boolean liquidacionEstaGarantizada = liquidacionCobranzaGarantizada(declaracion);
		  			  boolean duaTieneGarantia160 = declaracionGarantia160(declaracion);
		  			  if(duaTieneGarantia160 && liquidacionEstaGarantizada){verificarDeclaracionAfectadaCtaCte(declaracion);}
		  			  //Fin RIN10 mpoblete BUG 22018
		  		  }
		  	  }
		  }
	   
	   private boolean  validarRucImportadorTieneLC(Map<String,Object> params){
		  	 return  padronUsuarioService.findByNumRucExiste(params);
		  	 
		   }    
	   
	   private boolean verificarDeclaracionConLCGenerada(Map<String, Object> declaracion){
			  Map<String,Object> declaracionLocal = declaracion;  
			  
			  boolean tieneLCVPGenerado = liquidaDeclaracionService.verificarDeclaracionConLCGenerada(declaracionLocal);
			  
			  if(!tieneLCVPGenerado){
				  lisdatoMsj = lisdatoMsj+" *DUA NO CUENTA CON LC(VP) SIRVASE GENERARLA <BR>";
				  return false;
			  }
			  
			  return true;	  
		  }
	   
	   private boolean liquidacionCobranzaGarantizada(Map<String, Object> declaracion) {
		  	
		  	/** Inicio mpoblete RIN10 **/
			Map<String,Object> declaracionLocal = declaracion;
		  	declaracionLocal.put("tipoLiquidacion", Constantes.COD_TIPLIQ);
		  	/** Fin mpoblete RIN10 **/
		    //Inicio RIN10 mpoblete BUG 21917
		  	//boolean result = liquidaDeclaracionService.verificarDeclaracionConLCGeneradaGarantizada(declaracionLocal);
			boolean result = liquidaDeclaracionService.tieneDeclaracionLCVPGarantizadaImpugnada(declaracionLocal);
			
			
			//boolean duaConGarantia160 = declaracionGarantia160(declaracionLocal);
			//result = (result && duaConGarantia160);
			//Fin RIN10 mpoblete BUG 21917
			
		  	if(!result)
		  		 lisdatoMsj = lisdatoMsj+" *LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA, NOTIFICAR AL IMPORTADOR  <BR>";
		  	return result;
		  }
	   
	   private boolean declaracionGarantia160(Map<String, Object> declaracion) {
		     //Inicio RIN10 mpoblete BUG 22163
			 String numCtaCte = (String) declaracion.get("NUM_CTACTE");	 
			 numCtaCte = numCtaCte.trim();
			 boolean tieneGarantia160 = (!StringUtils.isEmpty(numCtaCte)); 
		  	 //if(declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE")){	 
		  	 if(tieneGarantia160){	 
		  	 //Fin RIN10 mpoblete BUG 22163	 
		  		 return true;
		  	 }
		  	 return false;
		  }
	   
	   private void verificarDeclaracionAfectadaCtaCte(Map<String, Object> declaracion) {
			  //Inicio RIN10 mpoblete BUG 22125
			  //boolean estado = liquidaDeclaracionService.verificarDeclaracionAfectadaCtaCte(declaracion);
			  boolean estado = liquidaDeclaracionService.ctaCteGaraAfectadaPorLiquidaVP(declaracion);
			  //Fin RIN10 mpoblete BUG 22125
			  if(!estado){
				  lisdatoMsj = lisdatoMsj+ " LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO HA AFECTADO LA CTA CTE DE LA GARANTIA <BR>";		  
			  }
		  }    	

	/*********************** SET DE SPRING **********************************/

	/**
	 * Sets the declaracion service.
	 * 
	 * @param declaracionService
	 *            the new declaracion service
	 */
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	/**
	 * Sets the soporte service.
	 * 
	 * @param soporteService
	 *            the new soporte service
	 */
	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}

	/**
	 * Sets the formato valor service.
	 * 
	 * @param formatoValorService
	 *            the new formato valor service
	 */
	public void setFormatoValorService(FormatoValorService formatoValorService) {
		this.formatoValorService = formatoValorService;
	}

	/**
	 * Sets the valida diligencia service.
	 * 
	 * @param validaDiligenciaService
	 *            the new valida diligencia service
	 */
	public void setValidaDiligenciaService(
			ValidaDiligenciaService validaDiligenciaService) {
		this.validaDiligenciaService = validaDiligenciaService;
	}

	/**
	 * Sets the rectificacion service.
	 * 
	 * @param rectificacionService
	 *            the new rectificacion service
	 */
	public void setRectificacionService(
			RectificacionService rectificacionService) {
		this.rectificacionService = rectificacionService;
	}

	/**
	 * 
	 * @param declaracionCalculoDeDatos
	 */
	public void setDeclaracionCalculoDeDatos(
			DeclaracionCalculoDeDatosService declaracionCalculoDeDatos) {
		this.declaracionCalculoDeDatos = declaracionCalculoDeDatos;
	}

	/**
	 * 
	 * @param serieService
	 */
	public void setSerieService(SerieService serieService) {
		this.serieService = serieService;
	}

	/* olunar 873 */
	public void setGetDeclaracionService(
			GetDeclaracionService getDeclaracionService) {
		this.getDeclaracionService = getDeclaracionService;
	}

	/* fin */

	
}

/* CUS: 3006-02 - Migrado - Rin 13 - Final - lrodriguezc */
/* P14 - 3006 - Final - lrodriguezc */