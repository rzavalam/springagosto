package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOLUCION_DEVOLUCION; //PAS20181U220200069 CSANTILLAN
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.CODIGO_PROCESO_SOPORTE; //PAS20181U220200069 CSANTILLAN

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.model.DocumentoSustento;
import pe.gob.sunat.administracion2.tramite.model.DocumentoSustentoFactory;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.administracion2.tramite.service.SolicitudPecoService;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
//import pe.gob.sunat.despaduanero2.declaracion.bean.DUAsXVencerBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ResolucionMulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.administracion2.tramite.model.Dipolsolpeco;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.ValidaContingentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PecoAmazoniaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
//import pe.gob.sunat.despaduanero2.declaracion.bean.FormRegistroSolicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudPecoAmazonia;
import pe.gob.sunat.despaduanero2.service.SolicitudPecoAmazoniaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NandTasa;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.declaracion.service.DocAutAsociadoService;// pase 69 csantillan
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;//p24 pase 99
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SeriesProrrateadasBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFleteYPesoPorDocTransporteBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.bean.RegistroIncidenciaForm;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionCalculoDeDatosService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaException;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.GetDeclaracionHashMapToDeclaracionObjectHelper;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.IncidenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.OrquestadorDiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudRectificacionesService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ValidaDiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.VehiCeticoService;
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.CollectionUtil;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.WUtil;
import pe.gob.sunat.despaduanero2.entradasalida.service.EntradaSalidaService;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;

import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.GarantiaOperativaService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado; //p24 pase 99
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;//p24 pase 99
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionManualService;
import pe.gob.sunat.tecnologia2.generadoc.service.JasperService;
import pe.gob.sunat.despaduanero2.declaracion.recepcion.service.RecepcionDocumentosService;
import pe.gob.sunat.despaduanero2.declaracion.model.SolicitudRecepcion;
import pe.gob.sunat.despaduanero2.declaracion.recepcion.util.ConstantesDeclaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO; //p24 pase 99
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.sigad.sini.service.SiniConsultaService;
import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.service.SolicitudPecoAmazoniaService;
import pe.gob.sunat.despaduanero2.model.DetEvaluacion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.RelacionDocumento;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudPecoAmazonia;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO; //p24 pase 99
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.ObservacionService; //p24-PAS20165E220200099
import pe.gob.sunat.recauda2.garantia.service.PadronUsuarioService;//RIN 10 ERUESTAA - p24-PAS20165E220200099



/**
 * <p>
 * Titulo: Controlador Web para el mantenimiento de la declaracion,
 * series,facturas e item de factura
 * </p>
 * <p>
 * Descripcion: Controlador que administra las funcionalidades de mantenimiento
 * para Fomato A y Formato B
 * </p>
 *
 * @author
 * @since 2014-09-02
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DespachoAduanaDestinoController extends AbstractDespachoController
{

    private static final String IND_REGISTRO_GRABADO = "0";

    private DeclaracionService                             declaracionService;
    private SolicitudService                               solicitudService;

    //private ResolucionService resolucionService;//P69-II

    private SoporteService                                 soporteService;
    private FormatoValorService                            formatoValorService;
    private LiquidaDeclaracionService                      liquidaDeclaracionService;
    private IncidenciaService                              incidenciaService;
    private AsignacionManualService 						 asignacionManualService;
    private ValidaDiligenciaService                        validaDiligenciaService;
    private GetDeclaracionHashMapToDeclaracionObjectHelper transformHelper;
    private ValidaContingentesService                      validaContingenteService;
    FabricaDeServicios                                     fabricaDeServicios;
    private SolicitudRectificacionesService                solicitudRectificacionesService;
    private OrquestadorDiligenciaService                   orquestadorService;
    private RectificacionService                           rectificacionService;
    private SerieService                                   serieService;
    private DeclaracionCalculoDeDatosService               declaracionCalculoDeDatos;
    private GetDeclaracionService 						 getDeclaracionService;
    private ProveedorFuncionesService  					funcionesService;
    private VehiCeticoService  							vehiCeticoService;
    private DocAutAsociadoService						docAutAsociadoService;
    private DiligenciaService							diligenciaService;
    private AduanaRol aduanaRol;
    private static final String                            PAGINA_PRINCIPAL_DETALLE  = "oficio/RegSerieOficio";
    private static final String                            REGIMEN_PRECEDENTE_CETICO = "91";
    private static final String                            CATALOGO_ESTADO_MERCANCIA = "25";
    private SolicitudRecepcion solicitudRecepcion;
    private RecepcionDocumentosService recepcionDocumentosService;
    private JasperService jasperService;
    private PublicacionAvisoService publicacionAvisoService;
    private static final String DEFAULT_TIPO_DOC = "01"; //p24 pase 99
    private PadronUsuarioService padronUsuarioService; //P24 - PAS20165E220200099
    String lisdatoMsj = new String();
    private Dipolsolpeco dipolsolpeco;
    /**
     * Metodo que consulta la declaracion, dando inicio a la Diligencia.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     * @version 1.0
     */
    public ModelAndView cargaDeclaracion(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        Map<String, Object> params = new HashMap<String, Object>();
        String acceso = WUtil.getParam(request, "hdn_acceso");
        String modifDilig = WUtil.getParam(request, "hdn_modifDilig");
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        UserNameHolder.set(bUsuario.getNroRegistro());
        boolean actualizarEstadoDua = true;
        ServletWebRequest webRequest = new ServletWebRequest(request);

        params.put("NUM_DECLARACION", WUtil.getParam(webRequest, "hdn_num_declaracion", webRequest.getParameter("txt_num_declaracion")));
        params.put("COD_ADUANA", WUtil.getParam(webRequest, "hdn_cod_aduana", webRequest.getParameter("txt_cod_aduana")));
        params.put("ANN_PRESEN", WUtil.getParam(webRequest, "hdn_ann_presen", webRequest.getParameter("txt_ann_presen")));
        params.put("COD_REGIMEN", WUtil.getParam(webRequest, "hdn_cod_regimen", webRequest.getParameter("sel_cod_regimen")));
        params.put("EN_PROCESO", "1");

        try
        {
            Map<String, Object> declaracion = this.declaracionService.obtenerDeclaracion(params);

            if(acceso.toString().isEmpty() && (declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_DECLARACION_REVISION)||declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO))){//PAS20175E220200035
                acceso = Constantes.MODO_DILIGENCIA_CONSULTA;
            }

            /** inicio EJHM **/
            Long numeroCorrelativo = new Long(declaracion.get("NUM_CORREDOC")
                    .toString());
            List<SolicitudRecepcion> solicitudesRecepciones = recepcionDocumentosService
                    .buscarSolicitudPorDeclaracion(numeroCorrelativo, "",
                            false, "");
            Map<String, Object> mapaSolicitudes = recepcionDocumentosService
                    .listarRecepcionesConsultaDUA(solicitudesRecepciones);
            /** fin EJHM **/

            if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))
            {
                params.put("OBS_IND_DEL", "0");
            }

            declaracion.put(
                    "COD_ESTDUA_DESC",
                    catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA,
                            declaracion.get("COD_ESTDUA").toString().trim()));

            //rin08
            WebUtils.setSessionAttribute(request, "tipoDiligencia", Constantes.DILIG_ADUANA_DESTINO);//22



            if (declaracion.get("COD_MODALIDAD").equals(Constantes.MODALIDAD_ANTICIPADO) &&
                    declaracion.get("COD_INDICADOR").equals(Constantes.IND_DUA_REQ_REGULARIZ))
            {
                StringBuffer codModalidadDesc = new StringBuffer();
                codModalidadDesc
                        .append(declaracion.get("COD_MODALIDAD_DESC"))
                        .append(MapUtils.getMapValor(declaracion, "ANTIC_REGU_DESC"));
                declaracion.put("COD_MODALIDAD_DESC", codModalidadDesc.toString());

            }
            // Verificamos si debe registrar la fecha de reconocimiento f�sico
            Map prmtReconoc = new HashMap();
            prmtReconoc.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
            prmtReconoc.put("cod_canal", MapUtils.getMapValor(declaracion, "COD_CANAL"));
            declaracion.put("registra_fecrecfis", true);
            // participante 31 deposito temporal
            String numDocIdentPdf = MapUtils.getMapValor(declaracion, "NUM_DOCIDENT_PDF");
            String codLocalAnexo = MapUtils.getMapValor(declaracion, "COD_LOCALANEXO");
            String direccionLocalAnexo = "";
            if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf))
            {
                direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
                if (SunatStringUtils.isEmpty(direccionLocalAnexo))
                { // si no esta registrado el local
                    direccionLocalAnexo = "No registrado";
                }
            }
            else
            {
                direccionLocalAnexo = "No registrado";
            }
            declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
            String numDocIdentPdd =
                    declaracion.get("NUM_DOCIDENT_PDD") != null
                            ? (String) declaracion.get("NUM_DOCIDENT_PDD")
                            : "";
            String codLocalAnexoDeposito =
                    declaracion.get("COD_LOCALANEXODEPOSITO") != null
                            ? (String) declaracion.get("COD_LOCALANEXODEPOSITO")
                            : "";
            String direccionLocalAnexoDeposito = "";
            if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd))
            {
                direccionLocalAnexoDeposito =
                        declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd,
                                codLocalAnexoDeposito);
                if (SunatStringUtils.isEmpty(direccionLocalAnexoDeposito))
                { // si no esta registrado el local
                    direccionLocalAnexoDeposito = " No registrado";
                }
            }
            else
            {
                direccionLocalAnexoDeposito = "No registrado";
            }

            declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);
            Map<String, Object> declaracionActual = new HashMap<String, Object>();
            if (!CollectionUtils.isEmpty(declaracion))
            {
                declaracionActual.putAll(declaracion);
            }
            Map diligencia = new HashMap();
            diligencia.put("IND_INCIDENCIA", "");
            diligencia.put("IND_MULTA", "");
            diligencia.put("DES_RESULTADO", "");
            // Datos para obtener los documentos
            Map<String, String> mapPk = new HashMap<String, String>();
            mapPk.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
            mapPk.put("IND_DEL", "0");
            // Datos de Documentos Autorizantes, Asociados y Certificados de Origen
            if (CollectionUtils.isEmpty((List) declaracion.get("lstDocAutAsociado")))
            {
                List<Map<String, Object>> listaDocAsoc = declaracionService.obtenerDocAutAsociados(mapPk);
                if (!CollectionUtils.isEmpty(listaDocAsoc))
                {
                    declaracion.put("lstDocAutAsociado", Utilidades.copiarLista((List) listaDocAsoc));
                    declaracionActual.put("lstDocAutAsociado", listaDocAsoc);
                }
            }
            if (null == request.getSession().getAttribute("incrementalDocumentosAsociados"))
            {
                request.getSession().setAttribute(
                        "incrementalDocumentosAsociados",
                        declaracionService.obtenerMaxCorrelativoDocAutAsociado(mapPk));
            }
            if (CollectionUtils.isEmpty((List) declaracion.get("lstCabCertiOrigen")))
            {
                List<Map<String, Object>> listaCabCerti = declaracionService.obtenerCertOrigen(mapPk);
                if (!CollectionUtils.isEmpty(listaCabCerti))
                {
                    declaracion.put("lstCabCertiOrigen", Utilidades.copiarLista((List) listaCabCerti));
                    declaracionActual.put("lstCabCertiOrigen", listaCabCerti);
                }
            }
            if (CollectionUtils.isEmpty((List) declaracion.get("lstDetAutorizacion")))
            {
                List<Map<String, Object>> listaDetAut = serieService.obtenerDetAutorizacion(mapPk);
                if (!CollectionUtils.isEmpty(listaDetAut))
                {
                    declaracion.put("lstDetAutorizacion", Utilidades.copiarLista((List) listaDetAut));
                    declaracionActual.put("lstDetAutorizacion", listaDetAut);
                }
            }


            //rin08
            declaracionActual.put("tituloDiligencia", "Diligencia en Aduana de Destino");
            //

            // Guardamos en sesion los datos de la declaracion e invocamos el jsp
            // correspondiente
            WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
            WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);



            // Si se tiene Doc Aut/Asoc
            Map<String, String> mapIbatis = new HashMap<String, String>();
            mapIbatis.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
            declaracionActual.put("IND_DOCAUT_ASOCIADOS", "0");
            if ((declaracionService.obtenerDocAutAsociados(mapIbatis)).size() > 0)
            {
                // seteamos vamor en session para recoger en vista y darle el
                // tratamiento
                declaracionActual.put("IND_DOCAUT_ASOCIADOS", "1");
            }


            /*INICIO P24-II PAS20165E220200099*/
            Map<String, Object> mapaSINI = obtenerDatosLevanteDuaSini(declaracionActual);
            declaracionActual.putAll(mapaSINI);
            /*FIN - PAS20165E220200099*/

            //P24-PAS20165E220200099 - Inicio
            Map<String, Object> tieneVP = new HashMap<String, Object>();
            String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613
            boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
            String tipoRegimen = (String) params.get("COD_REGIMEN");
            tieneVP = null;
            String flag = "";
            flag = WUtil.getParam(request,"hdn_flag");
            if(flag==""){
                flag = "1";
            }
            Map<String, Object> paramsValidador = new HashMap<String, Object>();
            paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
            paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
            if(indicadorDUAValorProvActivo){
                //Fin RIN10 mpoblete refactor
                if(flag!="-1" && flag.equals("1")){
                    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
                        String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
                        //verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
                        declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
                        paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
                        tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
                        //Inicio RIN10 BUG 22611,22613
                        if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
                            verificarValorProvisional(params,declaracion);
                            indicadorVFobProvVP = "SI";
                        }
                        //Fin RIN10 BUG 22611,22613
                    }
                }else if(flag!="-1" ||flag.equals("2")){
                    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
                        tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
                        //Inicio RIN10 BUG 22611,22613
                        if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
                            indicadorVFobProvVP = "SI";
                        }
                        //Fin RIN10 BUG 22611,22613
                    }
                }
            }//RIN10 mpoblete refactor

            if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
                //Fin RIN10 BUG 22611,22613
                declaracionActual.put("IND_VALOR_PROV", "1");
            }else{
                declaracionActual.put("IND_VALOR_PROV", "0");
            }
            //P24-PAS20165E220200099 - Fin

            //p24 pase 129
            Map<String, Object> mapaEstReg = determinarEstadoRegularizacion(declaracionActual);
            declaracionActual.putAll(mapaEstReg);

            cargaFormatoBCompleto(declaracion, declaracionActual, request);

            Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
            paramsDiligencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
            //paramsDiligencia.put("COD_TIPDILIGENCIA", new String[] { Constantes.DILIG_REV_DOCUMENTARIA, Constantes.DILIG_REC_FISICO });
            //rin08
            paramsDiligencia.put("COD_TIPDILIGENCIA", new String[] { Constantes.DILIG_ADUANA_DESTINO});

            Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(
                    paramsDiligencia,
                    declaracionActual);
            String ultimaDiligencia = SojoUtil.toJson(mapUltimaDiligencia);

            ModelAndView res = new ModelAndView("destino/RegDiligenciaDespacho");
            /**
             * inicio EJHM , Validar las fechas correctas de acuerdo a la
             * recepcion ?
             **/
            ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");
            List listTipoResolucion = resolucionService.obtenerTiposResoluciones();

            res.addObject("lstTiposResolucionJSON",!CollectionUtils.isEmpty(listTipoResolucion)?SojoUtil.toJson(listTipoResolucion) : "[]");

            SolicitudRecepcion solicitudRecepcion = null;
            declaracionActual.put("bandera", 0);
            declaracionActual.put("FEC_RECEP1", null);
            declaracionActual.put("NUMEROCORRELATIVO1", null);
            declaracionActual.put("NUMGED1", null);
            declaracionActual.put("FEC_RECHA1", null);
            declaracionActual.put("FEC_RECEP2", null);
            declaracionActual.put("NUMEROCORRELATIVO2", null);
            declaracionActual.put("NUMGED2", null);
            declaracionActual.put("FEC_RECHA2", null);
            if (!mapaSolicitudes.get("existesolicitudes").toString()
                    .equals(ConstantesDeclaracion.NO_EXISTE_SOLICITUD)) {
                if (mapaSolicitudes.get("solicitudPrimeraRecepcion") != null) {
                    res.addObject("modulo", "R"); // regularizacion
                    solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
                            .get("solicitudPrimeraRecepcion");
                    declaracionActual.put("FEC_RECEP1",
                            solicitudRecepcion.getFechaRecepcion());
                    declaracionActual.put("NUMEROCORRELATIVO1",
                            solicitudRecepcion.getNumeroCorrelativo());
                    declaracionActual.put("NUMGED1",
                            solicitudRecepcion.getNumGed());
                }
                if (mapaSolicitudes.get("solicitudPrimeraRecepcionRechazada") != null) {
                    solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
                            .get("solicitudPrimeraRecepcionRechazada");
                    declaracionActual.put("FEC_RECEP_RECHA1",
                            solicitudRecepcion.getFechaRecepcion());
                    declaracionActual.put("FEC_RECHA1",
                            solicitudRecepcion.getFechaRechazo());
                    declaracionActual.put("NUMEROCORRELATIVORECHA1",
                            solicitudRecepcion.getNumeroCorrelativo());
                }
                if (mapaSolicitudes.get("solicitudSegundaRecepcion") != null) {
                    solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
                            .get("solicitudSegundaRecepcion");
                    declaracionActual.put("FEC_RECEP2",
                            solicitudRecepcion.getFechaRecepcion());
                    declaracionActual.put("NUMEROCORRELATIVO2",
                            solicitudRecepcion.getNumeroCorrelativo());
                    declaracionActual.put("NUMGED2",
                            solicitudRecepcion.getNumGed());
                }
                if (mapaSolicitudes.get("solicitudSegundaRecepcionRechazada") != null) {
                    solicitudRecepcion = (SolicitudRecepcion) mapaSolicitudes
                            .get("solicitudSegundaRecepcionRechazada");
                    declaracionActual.put("FEC_RECEP_RECHA2",
                            solicitudRecepcion.getFechaRecepcion());
                    declaracionActual.put("FEC_RECHA2",
                            solicitudRecepcion.getFechaRechazo());
                    declaracionActual.put("NUMEROCORRELATIVORECHA2",
                            solicitudRecepcion.getNumeroCorrelativo());
                }
                declaracionActual.put("bandera", 1);
            } else {
                declaracionActual.put("bandera", 0);
            }

            //P24 - PAS20165E220200099
            String codigoPropiedad = (String)declaracionActual.get("COD_PROPIEDAD");
            String codigoPropiedadDesc =this.catalogoAyudaService.getDescripcionDataCatalogo("63",codigoPropiedad);
            declaracionActual.put("ENDOSE_DESC", codigoPropiedad + " - " + codigoPropiedadDesc);

            ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
            Observacion observacion = new Observacion();
            observacion.setNumcorredoc(SunatNumberUtils.toLong(declaracionActual.get("NUM_CORREDOC")));
            observacion.setCodtipobserva("01"); //solo las observaciones de datos generales, si se requiere para otro formulario se deber� filtrar por JSP y colocar null en tipo de obs
            List<Observacion> listaObservaciones = observacionService.buscarObservacion(observacion);
            if(CollectionUtils.isEmpty(listaObservaciones)){
                declaracionActual.put("OBSERVACIONES", null);
                declaracionActual.put("CANT_OBS", 1);
            }else{
                String descCodObs;
                for(Observacion obs : listaObservaciones){
                    descCodObs =this.catalogoAyudaService.getDescripcionDataCatalogo("369",obs.getCodtipobserva());
                    obs.setCodtipobserva(obs.getCodtipobserva().concat(" - ").concat((descCodObs!=null?descCodObs:"")));
                }
                declaracionActual.put("OBSERVACIONES", listaObservaciones);
                declaracionActual.put("CANT_OBS", listaObservaciones.size());
            }

            //INICIO GMONTOYA P24-PAS20165E220200099
            if(declaracion.get("FEC_AUTLEVANTE")!=null && !SunatDateUtils.isDefaultDate((Date)declaracion.get("FEC_AUTLEVANTE"))){
                declaracionActual.put("AUTLEVANTE_DESC","LEVANTE AUTORIZADO");
            }else{
                declaracionActual.put("AUTLEVANTE_DESC",null);
            }
            //FIN GMONTOYA P24-PAS20165E220200099
            /** fin EJHM **/
            res.addObject("declaracion", declaracionActual);
            res.addObject("diligencia", mapUltimaDiligencia);
            res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
            res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            res.addObject("ultimaDiligencia", ultimaDiligencia);

            res.addObject("modifDilig", modifDilig);
            
            //csantillan PAS20181U220200069: Vigencia PECO / Amazonia
            ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
    		Date fechaDeclaracion = (Date) declaracion.get("FEC_REGIS");
    	    boolean esVigentePecoAmazoniaSegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigentePecoAmazoniaSegundaParte(fechaDeclaracion):false;
        	
    	    res.addObject("vigenciaPECOAmazonia", esVigentePecoAmazoniaSegundaParte);
            
            //Fin csantillan PAS20181U220200069
            
            // inicio EJHM
            // res.addObject("modulo", "D"); // regularizacion
            // fin EJHM

            // solo para la consulta debo cargar los Datos modificados en
            // cualquier diligencia
            if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))
            {
                String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();
                Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
                List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);

                List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);

                List<Map<String, Object>> listaElemEquipamiento = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_EQUIPAMIENTO);

                List<Map<String, Object>> listaElemDocAsociado = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCAUT_ASOCIADO);

                List<Map<String, Object>> listaElemDetAut =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_AUTORIZACION);
                List<Map<String, Object>> listaElemCertOrigen =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_CERTIORIGEN);
                List<Map<String, Object>> listaElemRegPrecedente =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCUPRECE_DUA);
                List<Map<String, Object>> listaElemFormatoBDAV =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMB_PROVEEDOR);
                List<Map<String, Object>> listaElemFormatoBFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);
                List<Map<String, Object>> listaElemFormatoBItemFactura =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_ITEM_FACTURA);
                List<Map<String, Object>> listaElemSeriesItem =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_SERIES_ITEM);
                List<Map<String, Object>> listaElemConvenioSerie =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CONVENIO_SERIE);
                List<Map<String, Object>> listaElemFacturasSeries =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU);
                List<Map<String, Object>> listaElemObservacion =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);

                List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
                List<Map<String, Object>> listaElemFacturaSuce = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FACTUSUCE);//PAS20175E220200035
                // las listas de convenio tienen el mismo PK que det_serie y se
                // muestran en el mismo JSP
                // por ello se agrega a la lista
                if (!CollectionUtils.isEmpty(listaElemConvenioSerie))
                {
                    listaElemDetDeclara.addAll(listaElemConvenioSerie);
                }
                // en el JSP COnsultaDocAutorizaSerie estan estos 2 listas
                if (!CollectionUtils.isEmpty(listaElemDocAsociado))
                {
                    listaElemDetDeclara.addAll(listaElemDetAut);
                }

                // en el JSP RegDiligenciaDespacho estan estos 2 listas
                List<Map<String, Object>> listaElemObservacionDecla       = new ArrayList();
                // List<Map<String, Object>> listaElemObservacionItemFactura = new ArrayList();

                if (!CollectionUtils.isEmpty(listaElemObservacion))
                {
                    for (Map<String, Object> mapObs : listaElemObservacion)
                    {

                        String codTipObs = mapObs.get("PK").toString();
                        if(codTipObs.startsWith("01"))
                        {
                            listaElemObservacionDecla.add(mapObs);
                        }
										/* NO SE MUESTRA ESTE CAMPO EN LA CONSULTAS PERO CUANDO SE MUESTRE HABILITAR
            else if(codTipObs.startsWith("03"))
            {
              listaElemObservacionItemFactura.add(mapObs);
            }*/
                    }
                }

                listaElemCabDeclara.addAll(listaElemObservacionDecla);
                listaElemCabDeclara.addAll(listaElemParticipantesDUA);

                listaElemDetDeclara.addAll(listaElemFacturaSuce);//PAS20175E220200035
                listaElemDetDeclara.addAll(listaElemFormatoBFactura);//PAS20175E220200035
                //se agrega las obseravciones del itemfcatura activar cuando se muestre la obseravcion en itemfacturas
                // listaElemFormatoBItemFactura.addAll(listaElemObservacionItemFactura);

                // Guardamos en sesion los datos de la declaracion e invocamos
                // el jsp
                WebUtils.setSessionAttribute(request,
                        "camposModificadosDUA",
                        (!CollectionUtils.isEmpty(listaElemCabDeclara)
                                ? SojoUtil.toJson(listaElemCabDeclara)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosSERIE",
                        (!CollectionUtils.isEmpty(listaElemDetDeclara)
                                ? SojoUtil.toJson(listaElemDetDeclara)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosEquipamiento ",
                        (!CollectionUtils.isEmpty(listaElemEquipamiento)
                                ? SojoUtil.toJson(listaElemEquipamiento)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosDocAsociado",
                        (!CollectionUtils.isEmpty(listaElemDocAsociado)
                                ? SojoUtil.toJson(listaElemDocAsociado)
                                : "[]"));
                // WebUtils.setSessionAttribute(request,
                // "camposModificadosDetAut",
                // (!CollectionUtils.isEmpty(listaElemDetAut)?SojoUtil.toJson(listaElemDetAut):"[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosCertOrigen",
                        (!CollectionUtils.isEmpty(listaElemCertOrigen)
                                ? SojoUtil.toJson(listaElemCertOrigen)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosRegPrecedente",
                        (!CollectionUtils.isEmpty(listaElemRegPrecedente)
                                ? SojoUtil.toJson(listaElemRegPrecedente)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosFormatoBDAV",
                        (!CollectionUtils.isEmpty(listaElemFormatoBDAV)
                                ? SojoUtil.toJson(listaElemFormatoBDAV)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosComprobantePago",
                        (!CollectionUtils.isEmpty(listaElemFormatoBFactura)
                                ? SojoUtil.toJson(listaElemFormatoBFactura)
                                : "[]"));//PAS20175E220200035
                WebUtils.setSessionAttribute(request,
                        "camposModificadosFormatoBItemFactura",
                        (!CollectionUtils.isEmpty(listaElemFormatoBItemFactura)
                                ? SojoUtil.toJson(listaElemFormatoBItemFactura)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosSeriesItem",
                        (!CollectionUtils.isEmpty(listaElemSeriesItem)
                                ? SojoUtil.toJson(listaElemSeriesItem)
                                : "[]"));
                // WebUtils.setSessionAttribute(request,
                // "camposModificadosConvenioSerie",
                // (!CollectionUtils.isEmpty(listaElemConvenioSerie)?SojoUtil.toJson(listaElemConvenioSerie):"[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosFacturasSeries",
                        (!CollectionUtils.isEmpty(listaElemFacturasSeries)
                                ? SojoUtil.toJson(listaElemFacturasSeries)
                                : "[]"));
                // WebUtils.setSessionAttribute(request,"camposModificadosObservacion",(!CollectionUtils.isEmpty(listaElemObservacion)
                // ? SojoUtil.toJson(listaElemObservacion) : "[]"));

            }
            else
            {  //inicio mostrar datos rectificados


                String numCorreDoc = numeroCorrelativo.toString();

                Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
                List<Map<String, Object>> listaElemObservacion =obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);
                // en el JSP RegDiligenciaDespacho estan estos 2 listas
                List<Map<String, Object>> listaElemObservacionDecla       = new ArrayList();
                // List<Map<String, Object>> listaElemObservacionItemFactura = new ArrayList();

                if (!CollectionUtils.isEmpty(listaElemObservacion))
                {
                    for (Map<String, Object> mapObs : listaElemObservacion)
                    {

                        String codTipObs = mapObs.get("PK").toString();
                        if(codTipObs.startsWith("01"))
                        {
                            listaElemObservacionDecla.add(mapObs);
                        }
						  /* NO SE MUESTRA ESTE CAMPO EN LA CONSULTAS PERO CUANDO SE MUESTRE HABILITAR
						  else if(codTipObs.startsWith("03"))
						  {
							listaElemObservacionItemFactura.add(mapObs);
						  }*/
                    }
                }
                List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);
                List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
                listaElemCabDeclara.addAll(listaElemObservacionDecla);
                listaElemCabDeclara.addAll(listaElemParticipantesDUA);
                List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);
                WebUtils.setSessionAttribute(request,
                        "camposModificadosDUA",
                        (!CollectionUtils.isEmpty(listaElemCabDeclara)
                                ? SojoUtil.toJson(listaElemCabDeclara)
                                : "[]"));
                WebUtils.setSessionAttribute(request,
                        "camposModificadosSERIE",
                        (!CollectionUtils.isEmpty(listaElemDetDeclara)
                                ? SojoUtil.toJson(listaElemDetDeclara)
                                : "[]"));
                //fin motrar datos rectificados
            }
            return res;
        }
        catch (ServiceException e)
        {

            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror(e.getMessage());
            return new ModelAndView("PagM", "Error", mensajeBean);
        }
        catch (Throwable e)
        {
            log.error("error", e);
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror("Ocurrio un error al cargar los datos de la dua.");

            return new ModelAndView("PagM", "Error", mensajeBean);
        }

    }

    //p24 PAS20165E220200099
    //inicio gmontoya P24
    public Map<String, Object> obtenerDatosLevanteDuaSini(Map<String, Object> declaracionDua) throws ServiceException {
        Map<String, Object> rspta = new HashMap<String, Object>();
        String aduana=declaracionDua.get("COD_ADUAMANIFIESTO").toString();
        String codRegimen=declaracionDua.get("COD_REGIMEN").toString();
        if(aduana.equals("118")){
            String[] regimenTMP = new String[] {"10","20" ,"21","70"};
            if (Arrays.asList(regimenTMP).contains(codRegimen)) {
                Map<String, Object> parametro = new HashMap<String, Object>();
                Map<String, Object> parametros = new HashMap<String, Object>();
                List<Map<String,Object>> listAuxiliar = new ArrayList<Map<String,Object>> ();

                parametros.put("cod_regimen", declaracionDua.get("COD_REGIMEN").toString());
                parametros.put("codigoAduana", declaracionDua.get("COD_ADUAMANIFIESTO").toString());
                parametros.put("anioDocumento", declaracionDua.get("ANN_PRESEN").toString());
                parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(),6, " "));
                parametros.put("codigoViaTransporte", declaracionDua.get("COD_VIATRANS").toString());
                parametros.put("numdua", declaracionDua.get("NUM_DECLARACION").toString());//pruiz
                parametros.put("numdua", StringUtils.leftPad(declaracionDua.get("NUM_DECLARACION").toString(),6,"0"));


                SiniConsultaService siniConsultaService =fabricaDeServicios.getService("sigad.sini.SiniConsultaService");
                List<Map<String,Object>> listSini= siniConsultaService.evaluarContenedorSINIxDAM(parametros);
                String etiquetaSini=null;

                if (!CollectionUtils.isEmpty(listSini)){
                    if(listSini.size()>0){

                        etiquetaSini=	String.valueOf(listSini.get(0).get("DES_ESTADO"));
                        rspta.put("COD_ESTADO_SINI", listSini.get(0).get("COD_ESTADO"));

                    }else{
                        //se obtiene los datos de la dua

                        parametro.put("numeroCorrelativoDua", declaracionDua.get("NUM_CORREDOC").toString());
                        parametros.put("anioManifiesto", declaracionDua.get("ANN_MANIFIESTO").toString());
                        parametros.put("codigoTipoManifiesto", declaracionDua.get("COD_TIPMANIFIESTO").toString());
                        EntradaSalidaService entradaSalidaService =  fabricaDeServicios.getService("declaracion.entradasalida.EntradaSalidaService");
                        List<Manifiesto> lstManifiesto = entradaSalidaService.obtenerManifiesto(parametros);
                        Long numeroCorrelativoManif = lstManifiesto.get(0).getNumeroCorrelativo();
                        parametro.put("numeroCorrelativoManif", numeroCorrelativoManif);
                        //Obtenemos Contenedores Declarados
                        listAuxiliar=entradaSalidaService.obtenerContenedoresDeclarados(parametro);
                        if (!listAuxiliar.isEmpty() && listAuxiliar!=null){
                            List<String> listaEquipaminetos = new ArrayList<String>();
                            for(Map<String, Object> mapCon :listAuxiliar){
                                listaEquipaminetos.add((String)mapCon.get("numeroEquipamiento"));
                            }

                            parametros.put("listContenedores", listaEquipaminetos);

                            List<Map<String,Object>> listSiniManif= siniConsultaService.evaluarContenedorSINISinDestinar(parametros);
                            if(!listSiniManif.isEmpty()){
                                etiquetaSini=	String.valueOf(listSiniManif.get(0).get("DES_ESTADO"));
                                rspta.put("COD_ESTADO_SINI", listSiniManif.get(0).get("COD_ESTADO"));
                            }

                        }

                    }
                }

                rspta.put("DES_ESTADO_SINI", etiquetaSini);

            }
        }


        return rspta;
    }

    private Map<String, Object> determinarEstadoRegularizacion(Map<String, Object> declaracion){
        // obtiene el mensaje del levante - mensaje regularizacion
        // RIN16
        HashMap rspta = new HashMap();
        if(declaracion.get("COD_ESTDUA").toString().equals("08") || declaracion.get("COD_MODALIDAD").toString().equals("00")){  // SI LA DUA ESTA LEGAJADA O LA DUA ES MODALIDAD EXCEPCIONAL NO DEBE TENER MENSAJE DE REGULARIZACION
            rspta.put("MsjRegularizacion", null);
            rspta.put("fecSolicitud", " ");
            rspta.put("horSolicitud", " ");
        } else {

            /*Inicio f2_3014_req_RIN16_Regularizacion - PLMR */

            if (org.springframework.util.StringUtils.hasText((String)declaracion.get("COD_ESTREGUL"))) {
                if(declaracion.get("COD_ESTREGUL").toString().equals("07")){
                    rspta.put("MsjRegularizacion", null);
                    rspta.put("fecSolicitud", " ");
                    rspta.put("horSolicitud", " ");
                }
                else{
                    if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"01", "02", "03" })){//sin Regularizacion aceptada
                        rspta.put("MsjRegularizacion","PENDIENTE DE REGULARIZAR");
                        rspta.put("horSolicitud", " ");
                        rspta.put("fecSolicitud", " ");
                    }
                    else if(SunatStringUtils.include(declaracion.get("COD_ESTREGUL").toString(),new String[]{"04", "05", "06"})){//con Regularizacion aceptada
                        rspta.put("MsjRegularizacion","REGULARIZADO");
                        Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
                        rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
                        rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
                    }
                }
            }
            /*Fin f2_3014_req_RIN16_Regularizacion - PLMR */
            else{
                // RIN16
                String MsjRegularizacion = null;
                HashMap params = new HashMap();
                // se obtiene fecha de solicitud, regularizacion - urgentes
                params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
                params.put("COD_TIPSOL", "11");
                RelacionDocDAO relacionDocDAO = fabricaDeServicios.getService("relaciondocDAO");
                List<Map<String,Object>> relacionSolicitudes = relacionDocDAO.findSolicitudesByDocumento(params);
                Date fecSolicitud = SunatDateUtils.getDefaultDate();
                if(!org.apache.commons.collections.CollectionUtils.isEmpty(relacionSolicitudes)){
                    Map<String, Object> solicitud = relacionSolicitudes.get(0);
                    fecSolicitud = (Date)(solicitud.get("FEC_SOLICITUD"));
                }
                // se obtiene fecha de recepcion de documentos, regularizacion - urgentes
                Date fecRecepcionDoc = (Date) declaracion.get("FEC_REREG");
                // se obtiene fecha de regularizacion de la dua - anticipados
                Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");

                //Se evalua si tiene expediente 1606 para identificar el tipo de mensaje de regularizacion a mostrar
                Map<String,Object> paramsExpedi = new HashMap<String,Object>();
                paramsExpedi.put("PROCEDIM", 		"1606");
                paramsExpedi.put("COD_ADUANA",  	declaracion.get("COD_ADUANA"));
                paramsExpedi.put("COD_REGIMEN", 	declaracion.get("COD_REGIMEN"));
                paramsExpedi.put("ANN_PRESEN",  	declaracion.get("ANN_PRESEN").toString());
                paramsExpedi.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));

                if (declaracion.get("COD_MODALIDAD").equals("01")) { // 01 urgente
                    // Modificado Daniel Zavaleta C. 10/10/2012 INI
                    if(SunatDateUtils.isDefaultDate(fecSolicitud) || SunatDateUtils.isDefaultDate(fecRecepcionDoc) || SunatDateUtils.isDefaultDate(fecRegulariza)){
                        //   Fin
                        MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
                    }else{
                        MsjRegularizacion = "REGULARIZADO";
                        fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
                        rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
                        rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
                    }
                } else if (declaracion.get("COD_MODALIDAD").equals("10")) { // 10 anticipado
                    Map<String, Object> paramIndLev = new HashMap<String, Object>();
                    paramIndLev.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
                    paramIndLev.put("cod_indicador", "02"); // 302 datacatalogo
                    paramIndLev.put("ind_activo", "1");
                    IndicadorDUADAO indicadorDuaDAO = fabricaDeServicios.getService("indicadorDUADAO");
                    Map<String, Object> mapIndLev = indicadorDuaDAO.findByDocumentoAndValor(paramIndLev);
                    if (mapIndLev != null && mapIndLev.size() > 0) { // tiene indicador 02
                        if(SunatDateUtils.isDefaultDate(fecRegulariza)){
                            MsjRegularizacion = "PENDIENTE DE REGULARIZAR";
                        }else{
                            MsjRegularizacion = "REGULARIZADO";
                            fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
                            rspta.put("horSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "HH:mm:ss"));
                            rspta.put("fecSolicitud", SunatDateUtils.getFormatDate(fecRegulariza, "dd/MM/yyyy"));
                        }
                    }
                }
                rspta.put("MsjRegularizacion", MsjRegularizacion);
            }
        }// RIN16
        return rspta;
    }


//inicio gmontoya P24 II
    /** Metodo que nos permite Obtener y mostrar las notificaciones
     * de una determinada declaracion
     *
     * @param request
     * @param response
     */
    public ModelAndView cargarNotificaciones(HttpServletRequest request, HttpServletResponse response){

        ModelAndView modelAndView = new ModelAndView("ConsultaNotificacion");
        Map<String, Object> mapCabDeclara  = null;
        SimpleDateFormat formatoRevisa = new SimpleDateFormat("dd/MM/yyyy");
        final String fechaDefecto = "01/01/0001";
        SimpleDateFormat formatoDestino = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        String detalleNotificacion;

        try {

            mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclara");
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));

            List<ComunicacionDescripcion> listNotificaciones = diligenciaService.obtenerNotificaciones(params);
            List<Map<String, Object>> listNotificacionesMap =new ArrayList<Map<String,Object>>();

            String notificacionElaboradaPor = "";
            String codAduana= mapCabDeclara.get("COD_ADUANA")!=null? mapCabDeclara.get("COD_ADUANA").toString():"" ;


            if(!CollectionUtils.isEmpty(listNotificaciones)){

                for (ComunicacionDescripcion comunicacion : listNotificaciones) {

                    Map<String,Object> mapComunicacion = new HashMap<String, Object>();
                    mapComunicacion.put("COD_USUREGIS", comunicacion.getCodUsuRegistro());
                    mapComunicacion.put("COD_MOTNOTI", comunicacion.getCodMotNoti());
                    mapComunicacion.put("DES_NOTA", comunicacion.getDesNota());
                    mapComunicacion.put("NUM_NOTA", comunicacion.getNumNota());

                    FiltroCatEmpleado filtro = new FiltroCatEmpleado();

                    filtro.setCodPers(mapComunicacion.get("COD_USUREGIS").toString());

                    Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
                    CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(mapComunicacion.get("COD_USUREGIS"));

                    mapComunicacion.put("FUNCIONARIO_ADUANERO",  (catEmpleadoTemp != null) ?
                            catEmpleadoTemp.getCodPers() + " - " + catEmpleadoTemp.getApPate()  + " " +
                                    catEmpleadoTemp.getApMate()  + " " + catEmpleadoTemp.getNombres() : " ");

                    if(mapComunicacion.get("COD_MOTNOTI")!=null){

                        detalleNotificacion = catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_MOTIVOS_NOTIFICACION, mapComunicacion.get("COD_MOTNOTI").toString());
                        mapComunicacion.put("DES_MOTNOTI", detalleNotificacion);

                    }else{
                        mapComunicacion.put("COD_MOTNOTI", "");
                        mapComunicacion.put("DES_MOTNOTI", "");
                    }
                    //<EHR>
                    //String duasConFeschaNotificacionVacio = (String) ObjectUtils.defaultIfNull(comunicacion.getFeRecRespNoti(), "");
                    log.debug("fecha  	que me trae verificamos ------------->"+comunicacion.getFeRecRespNoti());
                    if(comunicacion.getFeRecRespNoti()==null){
                        mapComunicacion.put("FEC_RECRESPNOTI", "-");
                    }else{

                        if (fechaDefecto.equals(formatoRevisa.format(comunicacion.getFeRecRespNoti()))) {
                            mapComunicacion.put("FEC_RECRESPNOTI", "-");
                        } else {
                            mapComunicacion.put("FEC_RECRESPNOTI", formatoDestino.format(comunicacion.getFeRecRespNoti()));
                        }
                    }
                    //</EHR>

					/*
					if(comunicacion.getFeRecRespNoti()!= null) {
						mapComunicacion.put("FEC_RECRESPNOTI", formatoDestino.format(comunicacion.getFeRecRespNoti()));
					} else {
						mapComunicacion.put("FEC_RECRESPNOTI", "-");
					}
					*/
                    if(comunicacion.getFeRegistro()!= null) {
                        mapComunicacion.put("FEC_REGIS", formatoDestino.format(comunicacion.getFeRegistro()));
                    } else {
                        mapComunicacion.put("FEC_REGIS", "-");
                    }

                    listNotificacionesMap.add(mapComunicacion);
                }

                notificacionElaboradaPor = diligenciaService.obtenerElaborado(codAduana);
            }
            if(!CollectionUtils.isEmpty(listNotificacionesMap)){
                Collections.reverse(listNotificacionesMap);
            }
            modelAndView.addObject("listNotificaciones",!CollectionUtils.isEmpty(listNotificacionesMap) ? SojoUtil.toJson(listNotificacionesMap) : "");
            modelAndView.addObject("notificacionElaborada",notificacionElaboradaPor);

        } catch (Exception e) {

            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);

        } finally {

        }

        return modelAndView;

    }




    private List<Map<String, Object>> obtenerListaModificaciones(Map<String, Object> mapaRSPTADatosModificados,
                                                                 String codTablaCabDeclara)
    {

        return mapaRSPTADatosModificados.get(codTablaCabDeclara)!=null?
                (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados.get(codTablaCabDeclara):
                new ArrayList<Map<String, Object>>();
    }

    /**
     * Metodo que consulta la lista de indicadores de la DUA y la actualiza en
     * declaracion y declaracionActual.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarConsultaIndicadorDua(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        try
        {
            Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            List<Map<String, Object>> lstIndicadorDua = (List<Map<String, Object>>) declaracion.get("lstIndicadorDua");
            if (CollectionUtils.isEmpty(lstIndicadorDua))
            {
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
                params.put("COD_TIPOREGISTRO", Constantes.IND_DUA_T_AUT);
                lstIndicadorDua = this.declaracionService.obtenerIndicadoresDua(params);
                declaracion.put("lstIndicadorDua", lstIndicadorDua);
                declaracionActual.put("lstIndicadorDua", lstIndicadorDua);
                WebUtils.setSessionAttribute(request, "declaracion", declaracionActual);
            }
            return new ModelAndView("ConsultaIndicadorDua", "data", SojoUtil.toJson(lstIndicadorDua));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);
        }
    }



    /**
     * Metodo que permite la grabacion en session de los cambios realizados a la
     * declaracion, tomar encuenta que es un metodo reutilizado
     *
     * Invocaciones: Diligencia Despacho, Regularizacion, Rectificacion de Oficio.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView grabarDeclaSession(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        MensajeBean rBean;
        Object objRes = null;
        String objName = "resultado";
        try
        {
            Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map dataForm = new HashMap();
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String hdn_docTransporteProrratear = webRequest.getParameter("hdn_docTransporteProrratear")!=null?webRequest.getParameter("hdn_docTransporteProrratear"):"";
            List<Map<String, Object>> lstDocTransporteProrratear = new ArrayList();
            if (StringUtils.isNotEmpty(hdn_docTransporteProrratear))
            {
                JSONArray arrayDocTransporteProrratear = JSONArray.fromObject(hdn_docTransporteProrratear);
                lstDocTransporteProrratear = (List<Map<String, Object>>) JSONArray.toCollection(arrayDocTransporteProrratear, Map.class);
            }
            List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear = new ArrayList();
            lstBLProrratear = verificarDocTransporteAProrratear(request);
            //pase153

            BigDecimal mtoFleteTotalActual = Utilidades.toBigDecimal(webRequest.getParameter("txt_mto_totfletedol"));
            BigDecimal mtoFleteTotalBD     = Utilidades.toBigDecimal(declaracion.get("MTO_TOTFLETEDOL"));
            if(mtoFleteTotalActual.compareTo(mtoFleteTotalBD) != 0)
            {
                if (cumpleConValidacionesProrrateoBL(lstBLProrratear, lstDocTransporteProrratear))
                {
                    if (lstBLProrratear.size() == 1)
                    {
                        Map<String, Object> registroProrrateo = new HashMap();
                        registroProrrateo.put("docTransporte", lstBLProrratear.get(0).getDocTransporte());
                        registroProrrateo.put("sumaFleteInicial", lstBLProrratear.get(0).getSumaFleteInicial());
                        BigDecimal bdMtoTotFleteDUA = BigDecimal.ZERO;
                        bdMtoTotFleteDUA = Utilidades.toBigDecimal(webRequest.getParameter("txt_mto_totfletedol"));
                        registroProrrateo.put("sumaFleteAProrratear", bdMtoTotFleteDUA);
                        lstDocTransporteProrratear.add(registroProrrateo);
                    }
                    request.setAttribute("lstDocTransporteProrratear", lstDocTransporteProrratear);
                }
                else
                {
                    objRes = lstBLProrratear;
                    objName = "lstBLProrratear";
                    return new ModelAndView(this.jsonView, objName, objRes);
                }
            }

            String resValidacion = validaGrabaDeclaSesion(request, dataForm);

            // si no tiene ninguna restriccion actualiza los datos
            if (SunatStringUtils.isEmpty(resValidacion))
            {

                dataForm.put("OBS_OBS", webRequest.getParameter("taObsObs"));
                if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals((String) declaracion.get("COD_REGIMEN"))
                        || Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals((String) declaracion.get("COD_REGIMEN")))
                {
                    if (webRequest.getParameter("sel_cod_tipdesp") != null)
                        dataForm.put("COD_TIPDESP", webRequest.getParameter("sel_cod_tipdesp"));
                    if (webRequest.getParameter("hdn_cod_tipdesp_desc") != null)
                        dataForm.put("COD_TIPDESP_DESC", webRequest.getParameter("hdn_cod_tipdesp_desc"));
                }

                declaracionActual.putAll(dataForm);

                Map<String, Object> res = new HashMap();


                StringBuilder sbRspta = new StringBuilder("Se grabaron los datos correctamente");
                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                res.put("res_ok", sbRspta.toString());
                res.put("declaracion", declaracionActual);
                List<SeriesProrrateadasBean> lstSeriesProrrateadas = new ArrayList();
                lstSeriesProrrateadas = obtenerSeriesProrratedas(request);
                res.put("lstSeriesProrrateadas", lstSeriesProrrateadas);
                objRes = res;
            }
            else
            {
                rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajeerror(resValidacion);
                rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
                objName = "beanM";
                objRes = rBean;
                log.error(this.toString().concat(" grabarDeclaSession - ERROR : ").concat("No se encontro el dato buscado"));
            }
        }
        catch (ServiceException e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            log.error("error", e);
            objName = "beanM";
            objRes = rBean;
        }
        catch (Throwable e)
        {
            log.error("*** ERROR ***", e);
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Ocurrio un error inesperado al grabar los datos de la declaracion.");
            objName = "beanM";
            objRes = rBean;
        }

        return new ModelAndView(this.jsonView, objName, objRes);
    }

    /**
     * Obtener series ha ser pror.
     *
     * @param request
     *          [HttpServletRequest] request
     * @return [List<SeriesProrrateadasBean>] list
     * @version 1.0
     */
    private List<SeriesProrrateadasBean> obtenerSeriesProrratedas(HttpServletRequest request)
    {
        List<SeriesProrrateadasBean> lstSeriesProrrateadas = new ArrayList();

        List<Map> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");

        SeriesProrrateadasBean serieBean;
        Map seriePk;
        Map serieAnt;
        if (!CollectionUtils.isEmpty(lstDetDeclara))
        {
            for (Map serie : lstDetDeclara)
            {
                if (!Utilidades.esUnaRegistroMarcadaParaEliminar(serie))
                {
                    seriePk = new HashMap();
                    seriePk.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                    seriePk.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
                    serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt, seriePk);

                    String mtoFleteAnt ="0";
                    String mtoSeguroAnt="0";
                    if (serieAnt != null)
                    {
                        mtoFleteAnt  = serieAnt.get("MTO_FLETEDOL")!=null?serieAnt.get("MTO_FLETEDOL").toString():"0";
                        mtoSeguroAnt = serieAnt.get("MTO_SEGDOL")!=null?serieAnt.get("MTO_SEGDOL").toString():"0";
                    }

                    serieBean = new SeriesProrrateadasBean();
                    serieBean.setNumSecSerie(Utilidades.toLong(serie.get("NUM_SECSERIE")));
                    serieBean.setMtoFleteInicial(Utilidades.toBigDecimal(mtoFleteAnt));

                    String tipoFlete = serie.get("COD_TIPFLETE").toString();
                    String tipoFleteDesc = "";
                    if ("1".equals(tipoFlete))
                    {
                        tipoFleteDesc = "No se prorratea";
                    }
                    else
                    {
                        tipoFleteDesc = catalogoAyudaService.getDescripcionDataCatalogo("368", tipoFlete);
                    }

                    serieBean.setTipoProrrateo(tipoFlete + "-" + tipoFleteDesc);
                    serieBean.setMtoFleteProrrateado(Utilidades.toBigDecimal(serie.get("MTO_FLETEDOL")));

                    serieBean.setMtoSeguroInicial(Utilidades.toBigDecimal(mtoSeguroAnt));

                    String tipoSeguro = serie.get("COD_TIPSEG").toString();
                    String tipoSeguroDesc = catalogoAyudaService.getDescripcionDataCatalogo("62", tipoSeguro);
                    serieBean.setTipoSeguro(tipoSeguro + "-" + tipoSeguroDesc);
                    serieBean.setMtoSeguroProrrateado(Utilidades.toBigDecimal(serie.get("MTO_SEGDOL")));

                    lstSeriesProrrateadas.add(serieBean);
                }
            }
        }

        return lstSeriesProrrateadas;
    }


    /**
     * Cumple con validaciones prorrateo bl.
     *
     * @param lstBLProrratear
     *          [List<SumaFleteYPesoPorDocTransporteBean>] lst bl prorratear
     * @param lstDocTransporteProrratear
     *          [List<Map<String,Object>>] lst doc transporte prorratear
     * @return true, if successful
     */
    private boolean cumpleConValidacionesProrrateoBL(
            List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear,
            List<Map<String, Object>> lstDocTransporteProrratear)

    {
        //solo es false si ha cambiado el monto de flete
        //despues es llenado por el valor de la cabecera
        if (lstBLProrratear.size() == 1 || lstBLProrratear.size() == 0)
        {
            return true;
        }
        else if (lstBLProrratear.size() > 1
                && org.apache.commons.collections.CollectionUtils.isNotEmpty(lstDocTransporteProrratear)
                && lstDocTransporteProrratear.size() == lstBLProrratear.size())
        {
            return true;
        }

        return false;
    }

    /**
     * Valida los datos de la declaracion validaciones: el datado, las sumatoria de
     * los series con la cabecera, y llena Map dataForm con los datos actualizados.
     * el metodo es invocado al momento de grabar la diligencia se ejecuta el
     * proceso de prorrateo de flete y seguro nuevamente se supone que si se realizo
     * este proceso en la declaracion los datos de la listado de series ya esta
     * cuadrados pero si fueron directamente a grabar la diligencia se espera que
     * este metodo valide y prorrate
     *
     * @param request
     *          the request
     * @param dataForm
     *          the data form
     * @return String mensaje de validacion
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     * @version 1.0
     */
    private String validaGrabaDeclaSesion(HttpServletRequest request, Map dataForm) throws ServletException, IOException
    {

        String res = "";
        // Obtenemos los cambios en la declaracion
        ServletWebRequest webRequest = new ServletWebRequest(request);
        if (null == dataForm)
        {
            dataForm = new HashMap();
        }

        dataForm.put("MTO_TOTFOBDOL",	new Double(("".equals(webRequest.getParameter("txt_mto_totfobdol").toString().trim()) ? "0" : webRequest.getParameter("txt_mto_totfobdol"))));
        dataForm.put("MTO_TOTFLETEDOL", new Double(("".equals(webRequest.getParameter("txt_mto_totfletedol").toString().trim()) ? "0" : webRequest.getParameter("txt_mto_totfletedol"))));
        dataForm.put("MTO_TOTSEGDOL", new Double(("".equals(webRequest.getParameter("txt_mto_totsegdol")) ? "0" : webRequest.getParameter("txt_mto_totsegdol"))));
        dataForm.put("MTO_TOTAJUSTESDOL", new Double(("".equals(webRequest.getParameter("txt_mto_totajustesdol").toString().trim()) ? "0" : webRequest.getParameter("txt_mto_totajustesdol"))));
        dataForm.put("MTO_TOTOTROSAJUSTE",new Double(("".equals(webRequest.getParameter("txt_mto_tototrosajuste").toString().trim()) ? "0" : webRequest.getParameter("txt_mto_tototrosajuste"))));
        dataForm.put("MTO_TOTVALORADU", new Double(("".equals(webRequest.getParameter("txt_mto_totvaloradu").toString().trim()) ? "0" : webRequest.getParameter("txt_mto_totvaloradu"))));
        dataForm.put("CNT_PESONETO_TOTAL", new Double(("".equals(webRequest.getParameter("txt_cnt_pesoneto_total").toString().trim()) ? "0" : webRequest.getParameter("txt_cnt_pesoneto_total"))));
        dataForm.put("CNT_PESOBRUTO_TOTAL",new Double(("".equals(webRequest.getParameter("txt_cnt_pesobruto_total").toString().trim()) ? "0" : webRequest.getParameter("txt_cnt_pesobruto_total"))));
        dataForm.put("CNT_TOTBULTOS", new Double(("".equals(webRequest.getParameter("txt_cnt_totbultos").toString().trim()) ? "0" : webRequest.getParameter("txt_cnt_totbultos"))));
        dataForm.put("CNT_TQUNIFIS",new Double(("".equals(webRequest.getParameter("txt_cnt_tqunifis").toString().trim()) ? "0" : webRequest.getParameter("txt_cnt_tqunifis"))));
        dataForm.put("CNT_TQUNICOM",new Double(("".equals(webRequest.getParameter("txt_cnt_tqunicom").toString().trim()) ? "0" : webRequest.getParameter("txt_cnt_tqunicom"))));
        dataForm.put("IND_SOCORRO", webRequest.getParameter("chk_ind_socorro") != null ? webRequest.getParameter("chk_ind_socorro") : " ");
        dataForm.put("COD_FERIA",webRequest.getParameter("txt_cod_feria") != null ? webRequest.getParameter("txt_cod_feria") : null);
        dataForm.put("COD_FERIA_DESC",webRequest.getParameter("txt_cod_feria_desc") != null ? webRequest.getParameter("txt_cod_feria_desc") : null);
        dataForm.put("OBS_OBS", webRequest.getParameter("taObsObs") != null ? webRequest.getParameter("taObsObs") : null);
        dataForm.put("COD_ADUDEST", webRequest.getParameter("sel_cod_adudest") != null && !webRequest.getParameter("sel_cod_adudest").equals("")   ? webRequest.getParameter("sel_cod_adudest") : " ");
        if (webRequest.getParameter("sel_cod_tiptratmerc") != null)	{
            dataForm.put("COD_TIPTRATMERC",webRequest.getParameter("sel_cod_tiptratmerc").isEmpty() ? " " : webRequest.getParameter("sel_cod_tiptratmerc"));
        }
        if (webRequest.getParameter("sel_cod_produrgente") != null) {
            dataForm.put("COD_PRODURGENTE",webRequest.getParameter("sel_cod_produrgente").isEmpty() ? " " : webRequest.getParameter("sel_cod_produrgente"));
        }
        if (webRequest.getParameter("txt_cod_tiplugarrecep") != null){
            dataForm.put("COD_TIPLUGARRECEP",webRequest.getParameter("txt_cod_tiplugarrecep").isEmpty() ? " " : webRequest.getParameter("txt_cod_tiplugarrecep"));
        }

        String fecCarcr = webRequest.getParameter("txt_fec_carcr");
        if (!SunatStringUtils.isEmpty(fecCarcr))
        {
            dataForm.put("FEC_CARCR", Utilidades.crearObjetoDesdeCadena(fecCarcr, new Timestamp(0)));
        }
        /*
         * String fecLlegada = webRequest.getParameter("txt_fec_llegada"); if
         * (!SunatStringUtils.isEmpty(fecLlegada)) { dataForm.put("FEC_LLEGADA",
         * crearObjetoDesdeCadena(fecLlegada,new Timestamp(0))); }
         */
        // debe grabar o modificar en participantes empresa de transportes
        dataForm.put("NUM_DOCIDENT_PTR",
                webRequest.getParameter("txt_num_docident_ptr_11") != null
                        ? webRequest.getParameter("txt_num_docident_ptr_11")
                        : " ");
        dataForm.put("COD_TIPPARTIC_PTR",
                webRequest.getParameter("hdm_txt_codTipoOperador_11") != null
                        ? webRequest.getParameter("hdm_txt_codTipoOperador_11")
                        : " ");

        // siempre aparece N a " "
        Map declaracionInicial = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        if (!CollectionUtils.isEmpty(declaracionInicial) && !SunatStringUtils.isEmpty((String) declaracionInicial.get("IND_SOCORRO")))
        {
            dataForm.put("IND_SOCORRO",
                    webRequest.getParameter("chk_ind_socorro") != null ? webRequest.getParameter("chk_ind_socorro")
                            : declaracionInicial.get("IND_SOCORRO"));
        }

        // se agrego importador
        String numCntaCte =
                webRequest.getParameter("hdn_numcntacte") != null ? webRequest.getParameter("hdn_numcntacte")
                        : "";
        if (StringUtils.isNotEmpty(numCntaCte))
        { // numCntaCte no vacio
            dataForm.put("NUM_DOCIDENT_PIM",
                    webRequest.getParameter("txt_num_docident_pim_45") != null
                            ? webRequest.getParameter("txt_num_docident_pim_45")
                            : " ");
            dataForm.put("NOM_RAZONSOCIAL_PIM",
                    webRequest.getParameter("txt_nom_razonsocial_pim_45") != null
                            ? webRequest.getParameter("txt_nom_razonsocial_pim_45")
                            : " ");
            dataForm.put("COD_TIPDOC_PIM",
                    webRequest.getParameter("sel_cod_tipdoc_pim_45") != null
                            ? webRequest.getParameter("sel_cod_tipdoc_pim_45")
                            : " ");
            dataForm.put("DIR_PARTIC_PIM",
                    webRequest.getParameter("txt_dir_partic_pim_45") != null
                            ? webRequest.getParameter("txt_dir_partic_pim_45")
                            : " ");
        }




        if (CollectionUtils.isEmpty((List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual")))
        {
            cargarSeriesSesion(request);
        }


        Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        List<String> lstSeriesRecti = declaracionActual.get("lstSeriesRecti") != null ? ((ArrayList<String>) declaracionActual
                .get("lstSeriesRecti"))
                : null;

        if ("".equals(res))
        {
            res = this.validaSeriesItemsFactura(
                    declaracionActual,
                    (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
        }

        if ("".equals(res))
        {
            res = this.validaSeriesCambioEstadoMercancia(declaracionActual, (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara"),
                    (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
        }

        if ("".equals(res))
        {
            res = this.validaSeries(
                    dataForm,
                    (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"),
                    lstSeriesRecti,
                    request);
        }

        return res;
    }
    //pase PAS20181U220200069
    public ModelAndView validarDocumentoSustentatorio(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try {
            DocumentoSustento documentoSustentoForm = new DocumentoSustento();
            bindToCommand(request, documentoSustentoForm);
            documentoSustentoForm = DocumentoSustentoFactory.crearDocumentoSustento(documentoSustentoForm);
            DocumentoSustento documentoValidado = this.validaDiligenciaService.obtenerDocumentoSustentatorio(documentoSustentoForm);
            if(documentoValidado!=null)
            {
                res.addObject("documentoValidado", documentoValidado);
            }
            return res;
        }
        catch (Exception e)
        {
            log.error("**** ERROR ****:", e);
            return showErrorJSON("");
        }
    }


    /* PAS20181U220200069 INICIO */
    //Usado para generar LC010 para documento Determinacion
    public ModelAndView validarResolucionTributos(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView view = new ModelAndView(this.jsonView);
        //cargar parametros
        ResolucionMulta resolucionMulta = new ResolucionMulta();
        bindToCommand(request, resolucionMulta);

        ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");
        DocumentoSustento documentoSustentoForm = new DocumentoSustento();
        bindToCommand(request, documentoSustentoForm);
        documentoSustentoForm = DocumentoSustentoFactory.crearDocumentoSustento(documentoSustentoForm);
        DocumentoSustento documentoValidado = this.validaDiligenciaService.obtenerDocumentoSustentatorio(documentoSustentoForm);
        if(documentoValidado!=null)
        {
            view.addObject("documentoValidado", documentoValidado);
            //resolucionMulta.setCodAduanaMulta(documentoSustentoForm.getCodAduanaDocSust);
        }

        Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
        ResCabBean resolucionMulta2=(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionMulta");
        boolean isResolucionMulta = resolucionMulta2!=null ? true:false;
        log.debug("isResolucionMulta:" + isResolucionMulta );
        Map resolucionMap = new HashMap<String, String>();
        //Grabando la Resoluci�n de Determinaci�n de Multas para la Diligencia.
        String tipoResol=documentoValidado.getCodTipDocDili().getCodTipDocSustento()!=null?documentoValidado.getCodTipDocDili().getCodTipDocSustento().toString():"";
        resolucionMap.put("codAduanaResol", documentoValidado.getCodAduanaDocSust());
        resolucionMap.put("codTipoDocResol",tipoResol=="R"?2:0);
        resolucionMap.put("codAreaResol", documentoValidado.getCodAreaDocSust());
        resolucionMap.put("annoResol", documentoValidado.getAnnDocSust());
        resolucionMap.put("numeroResol", documentoValidado.getNumDocSust());
		/*resolucionMap.put("codAduanaResol", documentoValidado.getCodiAdua());
		resolucionMap.put("codTipoDocResol", documentoValidado.getCodTipDocDili().getCodTipDocSustento());
		resolucionMap.put("codAreaResol", documentoValidado.getDresArea());
		resolucionMap.put("annoResol", documentoValidado.getDresAnno());
		resolucionMap.put("numeroResol", documentoValidado.getDresNro());*/
        //resolucionMap.put("fechaEmisionResol", documentoSustentoForm.getCodTipDocSust());
        //buscar
        List<ResCabBean> lstResoluciones = resolucionService.buscarResolucionesByPk(resolucionMap);
        //List<ResCabBean> lstResoluciones = resolucionService.buscarResolucionesByPk(resolucionMulta2.convertirAMapa(resolucionMulta2));
        mapCabDeclara.put("fecha_resolucion",request.getSession().getAttribute("fecEmision "));
        mapCabDeclara.put("fecha_rec_fisico",request.getSession().getAttribute("txt_fec_diligencia"));
        //validar resolucion
        ObjectResponseUtil rptaValidaResolucion = diligenciaService.validarResolucion(lstResoluciones, mapCabDeclara);
        //mapResolucion.get("mensaje");

        if(rptaValidaResolucion.poseeError()){
            WebUtils.setSessionAttribute(request, "generarLC010", false);
            view.addObject("mesanjeValResolucion", rptaValidaResolucion.getMensajes().get(0).getMensajeerror());
            view.addObject("success", false);
            return view;
        }
        WebUtils.setSessionAttribute(request, "generarLC010", true);
        WebUtils.setSessionAttribute(request, "resolucionTributo", lstResoluciones.get(0));
        //WebUtils.setSessionAttribute(request, "resolucionDeterminacionTributo", lstResoluciones.get(0));
        view.addObject("success", true);
        return view;
    }


    /**
     * Metodo que valida los datos de las series.
     *
     * @param newData
     *          datos de la cabecera formulario declaracion
     * @param lstSeries
     *          the lst series
     * @param lstSeriesRecti
     *          the lst series recti
     * @param request
     *          the request
     * @return the string
     */
    private String validaSeries(
            Map<String, Object> newData,
            List<Map<String, Object>> lstSeries,
            List<String> lstSeriesRecti,
            HttpServletRequest request)
    {
        StringBuilder res = new StringBuilder("");
        //String IND_REGISTRO_GRABADO = IND_REGISTRO_GRABADO;

        if (!CollectionUtils.isEmpty(lstSeries))
        {
            Map mapSerie;
            double dbl_mto_fobdol = 0;
            double dbl_mto_fletedol = 0;
            double dbl_mto_segdol = 0;
            double dbl_mto_ajuste = 0;
            double dbl_mto_ajuste_otr = 0;
            double dbl_mto_valoradu = 0;
            double dbl_cnt_peso_neto = 0;
            double dbl_cnt_peso_bruto = 0;
            double dbl_cnt_bulto = 0;
            double dbl_cnt_unifis = 0;
            double dbl_cnt_comer = 0;

            //ESTE DATO VIENE DEL ITENFACTURA O DE CAB_DECLARA
            List<Map<String, Object>> lstDocTransporteProrratear =request.getAttribute("lstDocTransporteProrratear")!=null?(ArrayList) request.getAttribute("lstDocTransporteProrratear"):null;

            List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte =new ArrayList<SumaFleteYPesoPorDocTransporteBean>();
            // los valores de la cabcera PASE578
            //solo si tiene datos prorratea en la cabcecera prorratea solo sio hay cambios en el MTO_TOTFLETE DEL CAB_DECLARA
            //Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            if (!CollectionUtils.isEmpty(lstDocTransporteProrratear))
            {
                //pase153
                // BigDecimal mtoFleteTotalActual = Utilidades.toBigDecimal(newData.get("MTO_TOTFLETEDOL"));
                // BigDecimal mtoFleteTotalBD     = Utilidades.toBigDecimal(declaracion.get("MTO_TOTFLETEDOL"));
                // if(mtoFleteTotalActual.compareTo(mtoFleteTotalBD) != 0)
                // {
                SumaFleteYPesoPorDocTransporteBean tablaFletePeso;
                String docTransporte;
                BigDecimal sumaFleteAProrratear;
                for (Map docTransporteProrratear : lstDocTransporteProrratear)
                {
                    docTransporte = docTransporteProrratear.get("docTransporte").toString();
                    sumaFleteAProrratear = Utilidades.toBigDecimal(docTransporteProrratear.get("sumaFleteAProrratear"));

                    tablaFletePeso = new SumaFleteYPesoPorDocTransporteBean(docTransporte, sumaFleteAProrratear);
                    lstSumaFleteYPesoPorDocTransporte.add(tablaFletePeso);
                }
                lstSeries = declaracionCalculoDeDatos.prorratearFlete(lstSeries, lstSumaFleteYPesoPorDocTransporte);
                // }
            }
            //prorrateo de seguro
            //BigDecimal mtoSeguroTotalActual = Utilidades.toBigDecimal(newData.get("MTO_TOTSEGDOL"));
            //BigDecimal mtoSeguroTotalBD     = Utilidades.toBigDecimal(declaracion.get("MTO_TOTSEGDOL"));
            //if(mtoSeguroTotalActual.compareTo(mtoSeguroTotalBD) != 0)
            // {

            BigDecimal mtoTotalFOBDolDeLaDeclaracion = Utilidades.toBigDecimal(newData.get("MTO_TOTFOBDOL"));
            BigDecimal mtoSeguroProrratear = Utilidades.toBigDecimal(newData.get("MTO_TOTSEGDOL"));

            Map mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION")
                    .toString());

            lstSeries = declaracionCalculoDeDatos.prorratearMtoSeguroEnLasSeries(mtoSeguroProrratear,
                    mtoTotalFOBDolDeLaDeclaracion,
                    fechaVigenciaPartida,
                    lstSeries);
            //}

            int contadorSeriesActivas = 0;

            for (int i = 0; i < lstSeries.size(); i++)
            {
                mapSerie = (HashMap) lstSeries.get(i);

                // debido a que prorrrateo en esta parte el valor en aduanas de las
                // serie no sera el valor correcto
                // por ello recalculo y lo seteo para el caso de las eliminadas tambien
                double bd_mto_fobdol1 = Double.valueOf(mapSerie.get("MTO_FOBDOL").toString());
                double bd_mto_fletedol1 = Double.valueOf(mapSerie.get("MTO_FLETEDOL").toString());
                double bd_mto_segdol1 = Double.valueOf(mapSerie.get("MTO_SEGDOL").toString());
                double bd_mto_ajuste1 = Double.valueOf(mapSerie.get("MTO_AJUSTE").toString());
                double bd_mto_ajuste_otr1 = Double.valueOf(mapSerie.get("MTO_OTROSAJUSTES").toString());

                BigDecimal bd_mto_valoraduProrrateado = SunatNumberUtils.scaleHalfUp(new BigDecimal(bd_mto_fobdol1
                        + bd_mto_fletedol1 + bd_mto_segdol1 + bd_mto_ajuste1 + bd_mto_ajuste_otr1), 3);
                mapSerie.put("MTO_VALORADU", bd_mto_valoraduProrrateado);

                if ((Integer.parseInt(mapSerie.get("IND_DEL").toString())) == 0
                        && mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_GRABADO))
                {

                    dbl_mto_fobdol = dbl_mto_fobdol + Double.valueOf(mapSerie.get("MTO_FOBDOL").toString());
                    dbl_mto_fletedol = dbl_mto_fletedol + Double.valueOf(mapSerie.get("MTO_FLETEDOL").toString());
                    dbl_mto_segdol = dbl_mto_segdol + Double.valueOf(mapSerie.get("MTO_SEGDOL").toString());
                    dbl_mto_ajuste = dbl_mto_ajuste + Double.valueOf(mapSerie.get("MTO_AJUSTE").toString());
                    dbl_mto_ajuste_otr = dbl_mto_ajuste_otr + Double.valueOf(mapSerie.get("MTO_OTROSAJUSTES").toString());

                    dbl_mto_valoradu = dbl_mto_valoradu + Double.valueOf(mapSerie.get("MTO_VALORADU").toString());
                    dbl_cnt_peso_neto = dbl_cnt_peso_neto + Double.valueOf(mapSerie.get("CNT_PESO_NETO").toString());
                    dbl_cnt_peso_bruto = dbl_cnt_peso_bruto + Double.valueOf(mapSerie.get("CNT_PESO_BRUTO").toString());
                    dbl_cnt_bulto = dbl_cnt_bulto + Double.valueOf(mapSerie.get("CNT_BULTO").toString());
                    dbl_cnt_unifis = dbl_cnt_unifis + Double.valueOf(mapSerie.get("CNT_UNIFIS").toString());
                    dbl_cnt_comer = dbl_cnt_comer + Double.valueOf(mapSerie.get("CNT_COMER").toString());
                    contadorSeriesActivas++;
                }
            }


            // validamos si la cantidad de series activas es la mismas
            String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
            if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia))
            {
                double diferenciaSeries = Double.valueOf(newData.get("CNT_TOTSERIES").toString()) - contadorSeriesActivas;

                if (Math.abs(diferenciaSeries) > 0 || contadorSeriesActivas < Double.valueOf(newData.get("CNT_TOTSERIES")
                        .toString()))
                {

                    res.append("Hay una diferencia de ")
                            .append(diferenciaSeries)
                            .append(" Series registrados en la cabecera:" + Double.valueOf(newData.get("CNT_TOTSERIES").toString())
                                    + " y el numero de las series registradas en el detalle:"
                                    + contadorSeriesActivas
                                    + ".");
                }
            }


            // Validamos las cantidades y montos
            double dif_mto_fobdol = Double.valueOf(newData.get("MTO_TOTFOBDOL").toString()) - dbl_mto_fobdol;
            BigDecimal bd_dif_mto_fobdol = new BigDecimal(dif_mto_fobdol);
            bd_dif_mto_fobdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fobdol, 3);

            double dif_mto_fletedol = Double.valueOf(newData.get("MTO_TOTFLETEDOL").toString()) - dbl_mto_fletedol;
            BigDecimal bd_dif_mto_fletedol = new BigDecimal(dif_mto_fletedol);
            bd_dif_mto_fletedol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fletedol, 3);

            double dif_mto_segdol = Double.valueOf(newData.get("MTO_TOTSEGDOL").toString()) - dbl_mto_segdol;
            BigDecimal bd_dif_mto_segdol = new BigDecimal(dif_mto_segdol);
            bd_dif_mto_segdol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_segdol, 3);

            double dif_mto_ajuste = Double.valueOf(newData.get("MTO_TOTAJUSTESDOL").toString()) - dbl_mto_ajuste;
            BigDecimal bd_dif_mto_ajuste = new BigDecimal(dif_mto_ajuste);
            bd_dif_mto_ajuste = SunatNumberUtils.scaleHalfUp(bd_dif_mto_ajuste, 3);

            double dif_mto_ajuste_otr = Double.valueOf(newData.get("MTO_TOTOTROSAJUSTE").toString()) - dbl_mto_ajuste_otr;
            BigDecimal bd_dif_mto_ajuste_otr = new BigDecimal(dif_mto_ajuste_otr);
            bd_dif_mto_ajuste_otr = SunatNumberUtils.scaleHalfUp(bd_dif_mto_ajuste_otr, 3);

            double dif_mto_valoradu = Double.valueOf(newData.get("MTO_TOTVALORADU").toString()) - dbl_mto_valoradu;
            BigDecimal bd_dif_mto_valoradu = new BigDecimal(dif_mto_valoradu);
            bd_dif_mto_valoradu = SunatNumberUtils.scaleHalfUp(bd_dif_mto_valoradu, 3);

            double dif_cnt_peso_neto = Double.valueOf(newData.get("CNT_PESONETO_TOTAL").toString()) - dbl_cnt_peso_neto;
            BigDecimal bd_dif_cnt_peso_neto = new BigDecimal(dif_cnt_peso_neto);
            bd_dif_cnt_peso_neto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_peso_neto, 3);

            double dif_cnt_peso_bruto = Double.valueOf(newData.get("CNT_PESOBRUTO_TOTAL").toString()) - dbl_cnt_peso_bruto;
            BigDecimal bd_dif_cnt_peso_bruto = new BigDecimal(dif_cnt_peso_bruto);
            bd_dif_cnt_peso_bruto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_peso_bruto, 3);

            double dif_cnt_bulto = Double.valueOf(newData.get("CNT_TOTBULTOS").toString()) - dbl_cnt_bulto;
            BigDecimal bd_dif_cnt_bulto = new BigDecimal(dif_cnt_bulto);
            bd_dif_cnt_bulto = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_bulto, 3);

            double dif_cnt_unifis = Double.valueOf(newData.get("CNT_TQUNIFIS").toString()) - dbl_cnt_unifis;
            BigDecimal bd_dif_cnt_unifis = new BigDecimal(dif_cnt_unifis);
            bd_dif_cnt_unifis = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_unifis, 3);

            double dif_cnt_comer = Double.valueOf(newData.get("CNT_TQUNICOM").toString()) - dbl_cnt_comer;
            BigDecimal bd_dif_cnt_comer = new BigDecimal(dif_cnt_comer);
            bd_dif_cnt_comer = SunatNumberUtils.scaleHalfUp(bd_dif_cnt_comer, 3);

            // implementacion 0.01 para rectificacion de oficio

            double diferenciaMaximaMonto;
            double diferenciaMaximaPeso;
            double diferenciaMaximaCantidad;

            if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia))
            {
                diferenciaMaximaMonto = Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO);
                diferenciaMaximaPeso = Double.valueOf(Constantes.DIFERENCIA_MAX_PESO);
                diferenciaMaximaCantidad = Double.valueOf(Constantes.DIFERENCIA_MAX_CANTIDAD);
            }
            else
            {
                diferenciaMaximaMonto = Double.valueOf(Constantes.DIF_MAX_MTO);
                diferenciaMaximaPeso = Double.valueOf(Constantes.DIF_MAX_PESO);
                diferenciaMaximaCantidad = Double.valueOf(Constantes.DIF_MAX_CANT);

            }

            if (Math.abs(dif_mto_fobdol) > diferenciaMaximaMonto)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_fobdol)
                        .append(
                                " entre el monto fob consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_fobdol), 3) + ").");

            }
            else if (Math.abs(dif_mto_fletedol) > diferenciaMaximaMonto)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_fletedol)
                        .append(
                                " entre el monto del flete consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_fletedol), 3)
                                        + ").");

            }
            else if (Math.abs(dif_mto_segdol) > Constantes.DIF_MAX_MTO)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_segdol)
                        .append(
                                " entre el monto del seguro consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_segdol), 3)
                                        + ").");

            }
            else if (Math.abs(dif_mto_ajuste) > diferenciaMaximaMonto)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_ajuste)
                        .append(
                                " entre el monto de los ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_ajuste), 3)
                                        + ").");

            }
            else if (Math.abs(dif_mto_ajuste_otr) > Constantes.DIF_MAX_MTO)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_ajuste_otr)
                        .append(
                                " entre el monto de otros ajustes consignados en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_ajuste_otr), 3)
                                        + ").");

            }
            else if (Math.abs(dif_mto_valoradu) > diferenciaMaximaMonto)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_mto_valoradu)
                        .append(
                                " entre el valor aduana consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_valoradu), 3)
                                        + ").");

            }
            else if (Math.abs(dif_cnt_peso_neto) > diferenciaMaximaPeso)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_cnt_peso_neto)
                        .append(
                                " entre el peso neto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_peso_neto), 3)
                                        + ").");

            }
            else if (Math.abs(dif_cnt_peso_bruto) > diferenciaMaximaPeso)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_cnt_peso_bruto)
                        .append(
                                " entre el peso bruto total consignado en la diligencia y el acumulado de las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_peso_bruto), 3)
                                        + ").");

            }
            else if (Math.abs(dif_cnt_bulto) > diferenciaMaximaCantidad)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_cnt_bulto)
                        .append(
                                " entre la cantidad de bultos consignada en la diligencia y la acumulada en las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_bulto), 3)
                                        + ").");

            }
            else if (Math.abs(dif_cnt_unifis) > diferenciaMaximaCantidad)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_cnt_unifis)
                        .append(
                                " entre la cantidad de unidades fisicas consignada en la diligencia y la acumulada en las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_unifis), 3)
                                        + ").");

            }
            else if (Math.abs(dif_cnt_comer) > diferenciaMaximaCantidad)
            {
                res.append("Hay una diferencia de ")
                        .append(bd_dif_cnt_comer)
                        .append(
                                " entre la cantidad de unidades comerciales consignada en la diligencia y la acumulada en las series (sumatoria de series "
                                        + SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_cnt_comer), 3)
                                        + ").");
            }

            if (!"".equals(res.toString().trim()) && lstSeriesRecti != null && lstSeriesRecti.size() > 0)
            {
                res.append("\n").append("Se le sugiere revisar y/o confirmar los datos rectificado(s) de la(s) serie(s) : ");

                for (String codSerie : lstSeriesRecti)
                {
                    res.append(codSerie).append(", ");
                }
                res = new StringBuilder(res.toString().trim().substring(0, (res.toString().trim().length() - 1)));
            }

        }
        else
        {
            res.append("No se ha registrado informacion de las series");
        }

        WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSeries);
        return (res.toString().trim());
    }

    /**
     * Valida datos de �tems asociados a una serie
     *
     * olunar - 30-05-2012.
     *
     * @param mapCabDeclaraActual
     *          the map cab declara actual
     * @param lstDetDeclaraActual
     *          the lst det declara actual
     * @return String
     */
    private String validaSeriesItemsFactura(
            Map<String, Object> mapCabDeclaraActual,
            List<Map<String, Object>> lstDetDeclaraActual)
    {
        StringBuilder res = new StringBuilder("");
        String numSerie = "";
        String numSerieItem = "";

        List<String> lstSeriesErr = new ArrayList<String>();
        List<List<String>> lstSerieItemErr = new ArrayList<List<String>>();
        List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual
                .get("lstFormBProveedor");
        List<Map<String, Object>> listaItemFacturas = null;
        List<Map<String, Object>> lstSeriesItem = null;

        if (lstFormBProveedor != null)
        {
            for (Map<String, Object> serie : lstDetDeclaraActual)
            {
                numSerie = serie.get("NUM_SECSERIE").toString();
                List<String> lstItemsErr = new ArrayList<String>();
                for (Map<String, Object> proveedor : lstFormBProveedor)
                {
                    if (proveedor.get("lstComproBPago") != null)
                    {
                        for (Map<String, Object> factura : (List<Map<String, Object>>) proveedor.get("lstComproBPago"))
                        {
                            listaItemFacturas = factura.get("lstItemFactura")!=null?(List<Map<String, Object>>) factura.get("lstItemFactura"):new ArrayList<Map<String, Object>>();

                            for (Map<String, Object> itemFactura : listaItemFacturas)
                            {
                                lstSeriesItem = (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
                                if (lstSeriesItem != null)
                                {
                                    for (Map<String, Object> itemSerie : lstSeriesItem)
                                    {
                                        if(itemSerie.get("IND_DEL").toString().equals("0")){
                                            numSerieItem = itemSerie.get("NUM_SECSERIE").toString();
                                            if (numSerieItem.equals(numSerie))
                                            {
                                                if (!serie.get("COD_ESTMERC").toString().equals(itemFactura.get("COD_ESTMERC").toString()))
                                                {
                                                    lstItemsErr.add(itemFactura.get("NUM_SECITEM").toString());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (!CollectionUtils.isEmpty(lstItemsErr))
                {
                    lstSeriesErr.add(numSerie);
                    lstSerieItemErr.add(lstItemsErr);
                }
            }
        }
        if (!CollectionUtils.isEmpty(lstSerieItemErr))
        {
            for (int i = 0; i < lstSeriesErr.size(); i++)
            {
                if (lstSerieItemErr.get(i).size() > 1)
                    res.append("Estado de la mercanc�a de los �tems");
                else
                    res.append("Estado de la mercanc�a del �tem");
                for (int j = 0; j < lstSerieItemErr.get(i).size(); j++)
                {
                    res.append(" " + lstSerieItemErr.get(i).get(j));
                    if (j < lstSerieItemErr.get(i).size() - 1)
                        res.append(",");
                }
                if (lstSerieItemErr.get(i).size() > 1)
                    res.append(" son diferentes a su correlaci�n con la serie " + lstSeriesErr.get(i) + ".");
                else
                    res.append(" es diferente a su correlaci�n con la serie " + lstSeriesErr.get(i) + ".");
                res.append("\n");
            }
        }
        return res.toString();
    }

    /**
     * Validar el cambio de estado de mercanc�a de las series.
     *
     * @param declaracionActual
     *          the declaracion actual
     * @param lstDetDeclara
     *          the lst det declara
     * @param lstDetDeclaraActual
     *          the lst det declara actual
     * @return String
     * @author olunar
     */
    public String validaSeriesCambioEstadoMercancia(Map declaracionActual, List<Map<String, Object>> lstDetDeclara,
                                                    List<Map<String, Object>> lstDetDeclaraActual)
    {
        String respuesta = "";
        // Solo para el r�gimen 10
        if (declaracionActual.get("COD_REGIMEN").toString().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO))
        {
            StringBuilder mensaje = new StringBuilder("");
            String strCapitulo = "";
            boolean tieneRegPreCeticos;
            int j = 0;
            Map<String, Object> serieActual = new HashMap<String, Object>();
            Map<String, Object> serie = new HashMap<String, Object>();
            ArrayList<Map> listaRegPre = new ArrayList<Map>();
            for (int i = 0; i < lstDetDeclaraActual.size(); i++)
            {
                serieActual = lstDetDeclaraActual.get(i);

                tieneRegPreCeticos = false;
                // Para las series modificadas, no las agregadas
                if (i <= lstDetDeclara.size() - 1)
                {
                    serie = lstDetDeclara.get(i);
                    // Si estado es usado
                    if (SunatStringUtils.isStringInList(serieActual.get("COD_ESTMERC").toString(), "20,21"))
                    {
                        // Estado inicial fue nuevo
                        if (SunatStringUtils.isStringInList(serie.get("COD_ESTMERC").toString(), "10,11,12,14,15,16,17"))
                        {
                            strCapitulo = SunatStringUtils.lpad(serieActual.get("NUM_PARTNANDI").toString(), 10, '0');
                            strCapitulo = strCapitulo.substring(0, 2);
                            // Si pertenece al cap�tulo 87 de veh�culos
                            if (strCapitulo.equals("87"))
                            {
                                listaRegPre = (ArrayList<Map>) serieActual.get("lstDocuPreceDua");
                                // Tiene r�gimen precedente
                                if (!CollectionUtils.isEmpty(listaRegPre))
                                {
                                    for (Map<String, Object> regPre : listaRegPre)
                                    {
                                        // R�gimen precedente CETICO
                                        if (regPre.get("COD_REGIMENPRE").toString().equals(REGIMEN_PRECEDENTE_CETICO))
                                        {
                                            tieneRegPreCeticos = true;
                                        }
                                    }
                                }
                                if (!tieneRegPreCeticos)
                                {
                                    // TNAN corresponde no registrado
                                    if (serieActual.get("COD_TIPTASAAPLICAR").toString().trim().equals(""))
                                    {
                                        if (j > 0)
                                            mensaje.append(", ");
                                        mensaje.append(serie.get("NUM_SECSERIE"));
                                        j++;
                                    }

                                }
                            }
                        }
                    }
                }
            }
            if (j >= 1)
                respuesta = "Debe registrar el valor del  TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN para la(s) serie(s) ";

            // "Debe modificarse adem�s el TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN para las series ";
            if (j > 0)
                respuesta = respuesta + mensaje.toString() + ".";
        }
        return respuesta;
    }

    /**
     * Metodo que permite obtener los boletines quimicos.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView cargarBoletinQuimico(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        try
        {
            ModelAndView res = null;

            Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> params = new HashMap();
            params.put("CADUA_DUA", declaracionActual.get("COD_ADUANA"));
            params.put("NANNO_DUA", declaracionActual.get("ANN_PRESEN"));
            params.put("CREG_DUA", declaracionActual.get("COD_REGIMEN"));
            params.put("NCORR_DUA", declaracionActual.get("NUM_DECLARACION"));
            List lstTabBolQuim = (ArrayList) declaracionActual.get("lstTabBolQuim");
            if (CollectionUtils.isEmpty(lstTabBolQuim))
            {
                params.put("caduana", soporteService.obtenerAduana(request));
                lstTabBolQuim = this.soporteService.obtenerBoletinQuimico(params);
                if (!CollectionUtils.isEmpty(lstTabBolQuim))
                {
                    List lstTabBolQuimActual = Utilidades.copiarLista(lstTabBolQuim);
                    declaracion.put("lstTabBolQuim", lstTabBolQuim);
                    declaracionActual.put("lstTabBolQuim", lstTabBolQuimActual);
                    WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
                    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                    res = new ModelAndView("BoletinQuimico", "data", SojoUtil.toJson(lstTabBolQuim));
                }
                else
                {
                    MensajeBean rBean = new MensajeBean();
                    rBean.setError(true);
                    rBean.setMensajeerror("El registro no contiene una lista de boletines quimicos asociados.");
                    rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
                    res = new ModelAndView("PagM", "beanM", rBean);
                }
            }
            else
            {
                res = new ModelAndView("BoletinQuimico", "data", SojoUtil.toJson(lstTabBolQuim));
            }
            return res;
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);
        }
    }

    /**
     * Metodo que permite procesar los boletines quimicos.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView procesarBoletinQuimico(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        try
        {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            List lstTabBolQuim = (ArrayList) declaracionActual.get("lstTabBolQuim");
            String[] seleccionados = null;
            seleccionados = webRequest.getParameter("hdn_confirmados").split(Constantes.SEPARADOR1);
            Map<String, Object> fila = null;
            String[] key;
            boolean booEncontrado;
            if (!CollectionUtils.isEmpty(lstTabBolQuim))
            {
                for (int i = 0; i < lstTabBolQuim.size(); i++)
                {
                    booEncontrado = false;
                    fila = (HashMap) lstTabBolQuim.get(i);
                    // Si el estado de analisis es "NO RATIFICADO" (4)
                    if (Constantes.ESTADO_BQ_NO_RATIF.equals(fila.get("SESTA_ANALIS")))
                    {
                        if (seleccionados.length > 0)
                        {
                            for (int x = 0; x < seleccionados.length; x++)
                            {
                                key = seleccionados[x].split(Constantes.SEPARADOR2);
                                if (key[0].equals((String) fila.get("CADUA_SOLBQ"))
                                        && key[1].equals(fila.get("NANNO_SOLBQ").toString())
                                        && key[2].equals((String) fila.get("NCORR_SOLBQ")))
                                {

                                    fila.put("COD_ESTDILIG", Constantes.ESTADO_DILIG_ASIGNADA);
                                    fila.put("CPART_NANDI", fila.get("CPART_RESUL"));
                                    booEncontrado = true;
                                    break;
                                }
                            }
                        }
                        // Si antes estaba confirmado y fue deseleccionado
                        if (!booEncontrado && Constantes.ESTADO_DILIG_ASIGNADA.equals(fila.get("COD_ESTDILIG")))
                        {
                            fila.put("COD_ESTDILIG", Constantes.ESTADO_DECLARACION_NUMERADO);
                        }
                    }
                }
            }
            declaracionActual.put("lstTabBolQuim", lstTabBolQuim);
            WebUtils.setSessionAttribute(request, "declaracion", declaracionActual);
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
            return new ModelAndView(this.jsonView, "data", SojoUtil.toJson(lstTabBolQuim));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(this.jsonView, "beanM", rBean);
        }
    }

    /**
     * Proceso: Metodo que obtiene el FormatoB Invocado:desde Rectificacion de
     * Oficio, Diligencia despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarFormatoB(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> params = new HashMap();
        params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
        List lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
        ServletWebRequest webRequest = new ServletWebRequest(request);
        // Si no se ha cargado antes la lista de formb
        if (CollectionUtils.isEmpty(lstFormBProveedor))
        { // si es null o vacio obtener de BD
            lstFormBProveedor = this.formatoValorService.obtenerFVProveedores(params);
            declaracion.put("lstFormBProveedor", lstFormBProveedor);
            List lstActual = new ArrayList();
            if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
            {
                for (int i = 0; i < lstFormBProveedor.size(); i++)
                {
                    lstActual.add(Utilidades.copiarMapa((Map) lstFormBProveedor.get(i)));
                }
            }
            declaracionActual.put("lstFormBProveedor", lstActual);
        }

        if (!CollectionUtils.isEmpty(lstFormBProveedor))
        {
            WebUtils.setSessionAttribute(request, "declaracion", declaracionActual);

            Map declaShort = new HashMap();
            declaShort.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
            declaShort.put("COD_ADUANA", declaracionActual.get("COD_ADUANA"));
            declaShort.put("ANN_PRESEN", declaracionActual.get("ANN_PRESEN"));
            declaShort.put("NUM_DECLARACION", declaracionActual.get("NUM_DECLARACION"));
            declaShort.put("COD_REGIMEN", declaracionActual.get("COD_REGIMEN"));

            ModelAndView view = new ModelAndView("FormatoB");
            view.addObject("dataProveedores", SojoUtil.toJson(lstFormBProveedor));
            view.addObject("declaracion", declaShort);
            view.addObject("acceso", webRequest.getParameter("hdn_acceso"));
            view.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            return view;

        }
        else
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror("No existe registro para el Formato B");
            rBean.setMensajesol("La opcion no esta habilitada para declaraciones sin Formato B.");
            return new ModelAndView("PagM", "beanM", rBean);
        }
    }

    /**
     * Permite cargar la Declaracion de Valor.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarDAV(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ModelAndView res = null;
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> datosTMP = (HashMap) WebUtils.getSessionAttribute(request, "mapDatoMod");
        Map<String, Object> datosTMProv = (HashMap) WebUtils.getSessionAttribute(request, "mapDatoModProv");
        ServletWebRequest webRequest = new ServletWebRequest(request);
        try
        {
            String num_correDoc = (declaracionActual.get("NUM_CORREDOC") != null) ? declaracionActual
                    .get("NUM_CORREDOC")
                    .toString() : "";
            String num_secProve = webRequest.getParameter("hdn_num_secprove");
            Map<String, Object> mapFormBProveedor = null;
            boolean booError = false;
            List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
            if (!CollectionUtils.isEmpty(lstFormBProveedor))
            {
                Map tmpMap;
                for (int i = 0; i < lstFormBProveedor.size(); i++)
                {
                    tmpMap = (HashMap) lstFormBProveedor.get(i);
                    if (num_secProve.equals(tmpMap.get("num_secprove").toString().trim()))
                    {
                        mapFormBProveedor = tmpMap;
                        break;
                    }
                }
                if (!CollectionUtils.isEmpty(mapFormBProveedor))
                {
                    if (null == mapFormBProveedor.get("mod_edicion"))
                    {
                        mapFormBProveedor = this.formatoValorService.obtenerDetalleDAV(num_correDoc, num_secProve);
                        mapFormBProveedor.put("mod_edicion", "");

                        if(datosTMP!=null){
                            if(datosTMP.get("COD_TIPDOC")!=null){
                                mapFormBProveedor.put("cod_tipdoc_prd",datosTMP.get("COD_TIPDOC"));
                            }if(datosTMP.get("NOM_RAZONSOCIAL")!=null){
                                mapFormBProveedor.put("nom_razonsocial_prd",datosTMP.get("NOM_RAZONSOCIAL"));
                            }if(datosTMP.get("NUM_DOCIDENT")!=null){
                                mapFormBProveedor.put("num_docident_prd",datosTMP.get("NUM_DOCIDENT"));
                            }
                            HttpSession session = request.getSession();
                            session.removeAttribute("mapDatoMod");
                        }

                        if(datosTMProv!=null){
                            if(datosTMProv.get("NOM_CARGO")!=null){
                                mapFormBProveedor.put("nom_cargo",datosTMProv.get("NOM_CARGO"));
                            }
                            HttpSession session = request.getSession();
                            session.removeAttribute("mapDatoModProv");
                        }

                        declaracionActual.put("lstFormBProveedor", lstFormBProveedor);
                        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

                        Map tmpMap2;
                        Map tmpMap3=new HashMap();
                        List lstTmp = (ArrayList) declaracion.get("lstFormBProveedor");
                        for (int i = 0; i < lstTmp.size(); i++)
                        {
                            tmpMap2 = (HashMap) lstTmp.get(i);
                            tmpMap3.put("cod_tipdoc_prd",tmpMap2.get("cod_tipdoc_prd"));
                            tmpMap3.put("nom_razonsocial_prd",tmpMap2.get("nom_razonsocial_prd"));
                            tmpMap3.put("num_docident_prd",tmpMap2.get("num_docident_prd"));
                            tmpMap3.put("nom_cargo",tmpMap2.get("nom_cargo"));

                            if (num_secProve.equals(tmpMap2.get("num_secprove").toString().trim()))
                            {
                                tmpMap2.putAll(Utilidades.copiarMapa(mapFormBProveedor));
                                tmpMap2.put("cod_tipdoc_prd",tmpMap3.get("cod_tipdoc_prd"));
                                tmpMap2.put("nom_razonsocial_prd",tmpMap3.get("nom_razonsocial_prd"));
                                tmpMap2.put("num_docident_prd",tmpMap3.get("num_docident_prd"));
                                tmpMap2.put("nom_cargo",tmpMap3.get("nom_cargo"));

                                break;
                            }
                        }
                        declaracion.put("lstFormBProveedor", lstTmp);
                        WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);


                    }


                    mapFormBProveedor = (Map<String, Object>) SojoUtil.fromJson(SojoUtil.toJson(mapFormBProveedor).replaceAll("null", "\"\""));
                    res = new ModelAndView("FormatoBDAV", "mapFormBProveedor", mapFormBProveedor);
                    res.addObject("declaracion", declaracionActual);
                    res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
                    // Adaptacion para la regularizacion
                    Map datosRecti = (HashMap) WebUtils.getSessionAttribute(request, "mapDatosRectificados");
                    if (!CollectionUtils.isEmpty(datosRecti))
                    {
                        List<Map<String, Object>> lstFormatoBDAV = (datosRecti.get(Constantes.COD_TABLA_FORMB_PROVEEDOR) != null && ((ArrayList) datosRecti
                                .get(Constantes.COD_TABLA_FORMB_PROVEEDOR)).size() > 0) ? (ArrayList<Map<String, Object>>) ((ArrayList<Map<String, Object>>) datosRecti
                                .get(Constantes.COD_TABLA_FORMB_PROVEEDOR)).get(0) : null;

                        if (!CollectionUtils.isEmpty(lstFormatoBDAV))
                        {
                            List arrayProveedor = new ArrayList();

                            for (Map<String, Object> element : lstFormatoBDAV)
                            {
                                if (num_secProve.equals(element.get("PK").toString().trim()))
                                {
                                    arrayProveedor.add(element);
                                }
                            }
                            res.addObject("arrayProveedor", SojoUtil.toJson(arrayProveedor));
                        }
                    }
                    res.addObject("acceso", webRequest.getParameter("hdn_acceso"));
                    // Fin de la adaptacion para la regularizacion
                }
                else
                {
                    booError = true;
                }
            }
            else
            {
                booError = true;
            }
            if (booError)
            {
                MensajeBean rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajeerror("No se encontro el dato buscado");
                rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
                log.error(this.toString().concat(" cargarDAV - ERROR : ").concat("No se encontro el dato buscado"));
                return new ModelAndView("PagM", "beanM", rBean);
            }


        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);
        }
        return res;
    }

    /**
     * Metodo que modifica la DAV en session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView modificarDAVSession(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ModelAndView res = null;
        try
        {
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            ServletWebRequest webRequest = new ServletWebRequest(request);
            List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
            String num_secProve = webRequest.getParameter("hdn_num_secprove");
            Map<String, Object> mapFormBProveedor = null;
            if (!CollectionUtils.isEmpty(lstFormBProveedor))
            {
                Map tmpMap;
                for (int i = 0; i < lstFormBProveedor.size(); i++)
                {
                    tmpMap = (HashMap) lstFormBProveedor.get(i);

                    if (num_secProve.equals(tmpMap.get("num_secprove").toString().trim()))
                    {
                        mapFormBProveedor = tmpMap;
                        mapFormBProveedor.put("cod_nivelcomer_desc", webRequest.getParameter("hdn_cod_nivelcomer_desc"));
                        mapFormBProveedor.put("cod_nivelcomer", webRequest.getParameter("sel_cod_nivelcomer"));
                        mapFormBProveedor.put("nom_razonsocial_prv", webRequest.getParameter("txt_nom_razonsocial_prv"));
                        mapFormBProveedor.put("cod_condprove_desc", webRequest.getParameter("hdn_cod_condprove_desc"));
                        mapFormBProveedor.put("cod_condprove", webRequest.getParameter("sel_cod_condprove"));
                        mapFormBProveedor.put("dir_partic_prv", webRequest.getParameter("txt_dir_partic_prv"));
                        mapFormBProveedor.put("des_ubigeociudad_prv", webRequest.getParameter("txt_des_ubigeociudad_prv"));
                        mapFormBProveedor.put("cod_paisorigen_prv", webRequest.getParameter("sel_cod_paisorigen_prv"));
                        mapFormBProveedor.put("cod_paisorigen_pri", webRequest.getParameter("sel_cod_paisorigen_pri"));
                        mapFormBProveedor.put("num_fax_prv", webRequest.getParameter("txt_num_fax_prv"));
                        mapFormBProveedor.put("num_telefono_prv", webRequest.getParameter("txt_num_telefono_prv"));
                        mapFormBProveedor.put("nom_paginaweb_prv", webRequest.getParameter("txt_nom_paginaweb_prv"));
                        StringBuilder sEmailProv = new StringBuilder();
                        if (!StringUtils.isEmpty(webRequest.getParameter("txt_nom_email_prv")))
                        {
                            if (webRequest.getParameter("txt_nom_email_prv").trim().length() > 0)
                            {
                                sEmailProv.append(webRequest.getParameter("txt_nom_email_prv").trim());
                            }
                            else
                            {
                                sEmailProv.append(" ");
                            }
                        }
                        else
                        {
                            sEmailProv.append(" ");
                        }


                        String codDocProvLc = webRequest.getParameter("txt_cod_docidentprovloc")!=null?webRequest.getParameter("txt_cod_docidentprovloc"):"";
                        //valor seteado por el formato se le poner ""
                        if("0".equals(codDocProvLc))
                        {
                            codDocProvLc="";
                        }
                        mapFormBProveedor.put("nom_email_prv", sEmailProv.toString());
                        mapFormBProveedor.put("nom_razonsocial_prl", webRequest.getParameter("txt_nom_razonsocial_prl"));
                        mapFormBProveedor.put("cod_docprovlocal", webRequest.getParameter("sel_cod_docprovlocal"));
                        mapFormBProveedor.put("cod_docidentprovloc", codDocProvLc);
                        mapFormBProveedor.put("cod_natutrans_desc", webRequest.getParameter("hdn_cod_natutrans_desc"));
                        mapFormBProveedor.put("cod_natutrans", webRequest.getParameter("sel_cod_natutrans"));
                        mapFormBProveedor.put("cod_formaenvio", webRequest.getParameter("sel_cod_formaenvio"));
                        mapFormBProveedor.put("num_envio", webRequest.getParameter("txt_num_envio"));
                        //INICIO SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a
                        mapFormBProveedor.put("cod_medio_pago_desc", webRequest.getParameter("hdn_cod_medio_pago_desc"));
                        mapFormBProveedor.put("cod_medio_pago", webRequest.getParameter("sel_cod_medio_pago"));
                        mapFormBProveedor.put("cod_enti_financ_desc", webRequest.getParameter("hdn_cod_enti_financ_desc"));
                        mapFormBProveedor.put("cod_enti_financ", webRequest.getParameter("sel_cod_enti_financ"));
                        mapFormBProveedor.put("cod_ident_pago", webRequest.getParameter("txt_ident_pago"));
                        //FIN SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a
                        //2 indica que no esta el check 1 que si esta marcado
                        mapFormBProveedor.put("ind_intemediario", webRequest.getParameter("cbx_ind_intermediario") != null ? "1" : "2");
                        mapFormBProveedor.put("num_secintermediario", webRequest.getParameter("hdn_num_secintermediario"));
                        mapFormBProveedor.put("dir_partic_pri", webRequest.getParameter("txt_dir_partic_pri"));
                        mapFormBProveedor.put("nom_razonsocial_pri", webRequest.getParameter("txt_nom_razonsocial_pri"));
                        mapFormBProveedor.put("des_ubigeociudad_pri", webRequest.getParameter("txt_des_ubigeociudad_pri"));
                        mapFormBProveedor.put("cod_tipinterm", webRequest.getParameter("sel_cod_tipinterm"));
                        mapFormBProveedor.put("cod_tipdoc_prd", webRequest.getParameter("sel_cod_tipdoc_prd"));
                        mapFormBProveedor.put("num_docident_prd", webRequest.getParameter("txt_num_docident_prd"));
                        mapFormBProveedor.put("num_secdeclarante", webRequest.getParameter("hdn_num_secdeclarante"));
                        mapFormBProveedor.put("nom_razonsocial_prd", webRequest.getParameter("txt_nom_razonsocial_prd"));
                        mapFormBProveedor.put("dir_partic_prd", webRequest.getParameter("hdn_dir_partic_prd"));
                        mapFormBProveedor.put("nom_cargo", webRequest.getParameter("txt_nom_cargo"));
                        mapFormBProveedor.put("mod_edicion", Constantes.MODO_EDICION_ACTUALIZADO);
                        this.obtenerMapasFormB(webRequest, mapFormBProveedor);
                        declaracionActual.put("lstFormBProveedor", lstFormBProveedor);
                        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                        break;
                    }
                }
            }
            Map dataBasicaDec = new HashMap();
            dataBasicaDec.put("COD_ADUANA", declaracionActual.get("COD_ADUANA"));
            dataBasicaDec.put("ANN_PRESEN", declaracionActual.get("ANN_PRESEN"));
            dataBasicaDec.put("NUM_DECLARACION", declaracionActual.get("NUM_DECLARACION"));
            dataBasicaDec.put("FEC_DECLARACION", declaracionActual.get("FEC_DECLARACION"));
            // Volvemos a la pantalla inicial del Formato B
            res = new ModelAndView("FormatoB");
            res.addObject("dataProveedores", SojoUtil.toJson(lstFormBProveedor));
            res.addObject("declaracion", dataBasicaDec);
            res.addObject("acceso", webRequest.getParameter("hdn_acceso"));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

            res = new ModelAndView("PagM", "beanM", rBean);
        }

        return res;
    }

    /**
     * Metodo que modifica las facturas en Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView modificarFacturaSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        ModelAndView res = null;
        try
        {
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            ServletWebRequest webRequest = new ServletWebRequest(request);
            String num_secProve = webRequest.getParameter("hdn_num_secprove");
            String num_secFact = webRequest.getParameter("hdn_num_secfact");
            Map provActual = obtenerMapProveedor(declaracionActual, num_secProve);
            List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
            List<Map> lstComprobPago = (ArrayList) provActual.get("lstComproBPago");
            Map<String, Object> mapComprobPago = null;
            if (!CollectionUtils.isEmpty(lstComprobPago))
            {
                Map tmpMap;

                for (int i = 0; i < lstComprobPago.size(); i++)
                {
                    tmpMap = (HashMap) lstComprobPago.get(i);

                    if (num_secFact.equals(tmpMap.get("num_secfact").toString().trim()))
                    {
                        mapComprobPago = tmpMap;

                        mapComprobPago.put("num_fact", webRequest.getParameter("txt_num_fact"));
                        mapComprobPago.put("fec_fact", webRequest.getParameter("txt_fec_fact"));
                        mapComprobPago.put("cod_incoterm_desc", webRequest.getParameter("hdn_cod_incoterm_desc"));
                        mapComprobPago.put("cod_incoterm", webRequest.getParameter("sel_cod_incoterm"));
                        mapComprobPago.put("dir_lugartrans", webRequest.getParameter("txt_lugar"));
                        mapComprobPago.put("cod_paisembarque_desc", webRequest.getParameter("hdn_cod_pais_desc"));
                        mapComprobPago.put("cod_paisembarque", webRequest.getParameter("sel_cod_paisembarque"));
                        mapComprobPago.put("cod_moneda_desc", webRequest.getParameter("hdn_cod_moneda_desc"));
                        mapComprobPago.put("cod_moneda", webRequest.getParameter("sel_cod_moneda"));
                        mapComprobPago.put("mto_fact", webRequest.getParameter("txt_total"));
                        colocarLstFacturas(declaracionActual, lstComprobPago, num_secProve);
                        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                        break;
                    }
                }
            }

            Map dataBasicaDec = new HashMap();
            dataBasicaDec.put("COD_ADUANA", declaracionActual.get("COD_ADUANA"));
            dataBasicaDec.put("ANN_PRESEN", declaracionActual.get("ANN_PRESEN"));
            dataBasicaDec.put("NUM_DECLARACION", declaracionActual.get("NUM_DECLARACION"));
            dataBasicaDec.put("FEC_DECLARACION", declaracionActual.get("FEC_DECLARACION"));
            // Volvemos a la pantalla inicial del Formato B
            res = new ModelAndView("FormatoB");
            res.addObject("dataProveedores", SojoUtil.toJson(lstFormBProveedor));
            res.addObject("declaracion", dataBasicaDec);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

            res = new ModelAndView("PagM", "beanM", rBean);
        }

        return res;
    }

    /**
     * Metodo que permite obtener para el Formato B los datos de Condicion Transa
     * y Monto Formato B.
     *
     * @param webRequest
     *          the web request
     * @param res
     *          the res
     */
    private void obtenerMapasFormB(ServletWebRequest webRequest, Map res)
    {
        Map values = (Map) webRequest.getParameterMap();
        Object[] ctrNames = values.keySet().toArray();
        Map<String, Object> mapCondicionTransa = new HashMap<String, Object>();
        Map<String, Object> mapFormBMonto = new HashMap<String, Object>();
        if (!CollectionUtils.isEmpty(values))
        {
            for (int i = 0; i < values.size(); i++)
            {
                // Obtenemos los checkbox de condiciones de la transaccion
                if (ctrNames[i].toString().startsWith("cbx_cond_trans_"))
                {
                    mapCondicionTransa.put(ctrNames[i].toString().trim().substring(15), "1");
                }
                // Obtenemos los montos del Formato B
                if (ctrNames[i].toString().startsWith("txt_fbmto_"))
                {
                    if ((((String[]) values.get(ctrNames[i].toString()))[0]).trim().equals(""))
                    {
                        mapFormBMonto.put(ctrNames[i].toString().trim().substring(10), "0");
                    }
                    else
                    {
                        mapFormBMonto.put(
                                ctrNames[i].toString().trim().substring(10),
                                ((String[]) values.get(ctrNames[i].toString()))[0]);
                    }
                }
            }
        }
        res.put("mapCondicionTransa", mapCondicionTransa);
        res.put("mapFormBMonto", mapFormBMonto);
    }



    /**
     * Permite obtener las Facturas para la declaracion por un numero de
     * proveedor.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView obtenerFacturasProv(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
        params.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
        Map prov = obtenerMapProveedor(declaracionActual, webRequest.getParameter("hdn_num_secprove"));
        List res = (List) prov.get("lstComproBPago");
        if (CollectionUtils.isEmpty(res))
        {
            res = this.formatoValorService.obtenerFacturasProveedor(params);
            if (!CollectionUtils.isEmpty(res))
            {
                colocarLstFacturas(declaracion, res, webRequest.getParameter("hdn_num_secprove"));
                colocarLstFacturas(declaracionActual, res, webRequest.getParameter("hdn_num_secprove"));
            }
        }
        WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
        return new ModelAndView(this.jsonView, "data", SojoUtil.toJson(res));
    }

    /**
     * Metodo que permite colocar a un proveedor su lista de facturas.
     *
     * @param declaracion
     *          the declaracion
     * @param lstFacturas
     *          the lst facturas
     * @param num_secprove
     *          the num_secprove
     */
    private void colocarLstFacturas(Map declaracion, List<Map> lstFacturas, String num_secprove)
    {
        if (!CollectionUtils.isEmpty(declaracion))
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            List factAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    factAsig = Utilidades.copiarLista(lstFacturas);
                    prov.put("lstComproBPago", factAsig);
                    break;
                }
            }
        }
    }

    /**
     * Metodo que permite obtener los Items de una determinada factura.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView obtenerItemsFact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
        params.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
        params.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
        List res = this.formatoValorService.obtenerItemsFactura(params);
        return new ModelAndView(this.jsonView, "data", SojoUtil.toJson(res));
    }

    /**
     * Metodo que permite obtener las facturas para el formatoB.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarFormatoBFactura(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // Obtenemos la declaracion de sesion
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        // Obtenemos los parametros de request
        ServletWebRequest webRequest = new ServletWebRequest(request);
        String num_corredoc = webRequest.getParameter("num_corredoc");
        String num_secprove = webRequest.getParameter("hdn_num_secprove");

        List<Map> lstComprobPago = null;
        Map proveedorActual = obtenerMapProveedor(declaracionActual, num_secprove);
        lstComprobPago = (ArrayList) proveedorActual.get("lstComproBPago");
        if (!CollectionUtils.isEmpty(proveedorActual))
        {
            // si no se ha cargado antes la lista de formb
            if (CollectionUtils.isEmpty(lstComprobPago))
            { // si es null o vacio obtener de BD

                Map params = new HashMap();
                params.put("NUM_CORREDOC", num_corredoc);
                params.put("NUM_SECPROVE", num_secprove);
                lstComprobPago = this.formatoValorService.obtenerFacturasProveedor(params);
                List lstTmp = new ArrayList();
                lstTmp = Utilidades.copiarLista(lstComprobPago);

                // Actualizamos la lista de comprobantes de pago para el proveedor de
                // mapCabDeclara
                Map proveedor = obtenerMapProveedor(declaracion, num_secprove);
                proveedor.put("lstComproBPago", lstComprobPago);

                // Actualizamos la lista de comprobantes de pago para el proveedor de
                // mapCabDeclaraActual
                proveedorActual.put("lstComproBPago", lstTmp);

                // Actualizamos los mapas de declaracion
                WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
                WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
            }
            ModelAndView res = new ModelAndView("FormatoBFactura", "data", SojoUtil.toJson(lstComprobPago));
            res.addObject("num_secprove", num_secprove);
            return res;
        }
        else
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror("No ha sido posible encontrar los datos del proveedor para obtener la factura indicada");
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

            return new ModelAndView("FormatoBFactura", "beanM", rBean);
        }

    }

    /**
     * Permite obtener los datos de un proveedor dado su numero de proveedor
     * dentro de la declaracion.
     *
     * @param declaracion
     *          the declaracion
     * @param num_secprove
     *          the num_secprove
     * @return the map
     */
    private Map obtenerMapProveedor(Map declaracion, String num_secprove)
    {
        Map res = null;
        List<Map> lstProv = (ArrayList) declaracion.get("lstFormBProveedor");
        String codProve = "";
        for (Map proveedor : lstProv)
        {
            codProve = proveedor.get("num_secprove").toString().trim();
            if (codProve.equals(num_secprove))
            {
                res = proveedor;
                break;
            }
        }
        return res;
    }

    /**
     * Permite cargar los datos del FormatoB y sus catalogos a usar.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarFormatoBDetFactura(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        ModelAndView res = null;

        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        ServletWebRequest webRequest = new ServletWebRequest(request);
        try
        {
            String num_secfac = webRequest.getParameter("num_secfac");
            String num_secprove = webRequest.getParameter("num_secprove");
            Map<String, Object> mapComprobPago = null;
            boolean booError = false;
            Map provActual = obtenerMapProveedor(declaracionActual, num_secprove);
            List<Map> lstComprobPago = (ArrayList) provActual.get("lstComproBPago");
            if (!CollectionUtils.isEmpty(lstComprobPago))
            {
                Map tmpMap;

                for (int i = 0; i < lstComprobPago.size(); i++)
                {
                    tmpMap = (HashMap) lstComprobPago.get(i);

                    if (num_secfac.equals(tmpMap.get("num_secfact").toString().trim()))
                    {
                        mapComprobPago = tmpMap;
                        break;
                    }
                }
                if (!CollectionUtils.isEmpty(mapComprobPago))
                {
                    if (null == mapComprobPago.get("mod_edicion"))
                    {
                        mapComprobPago.put("mod_edicion", "");

                        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                    }

                    res = new ModelAndView("FormatoBDetFactura", "mapComprobPago", mapComprobPago);

                    res.addObject("mapFormBProveedor", provActual);
                    res.addObject("declaracion", declaracionActual);

                }
                else
                {
                    booError = true;
                }
            }
            else
            {
                booError = true;
            }
            if (booError)
            {
                MensajeBean rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajeerror("No se encontro el dato buscado");
                rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
                log.error(this.toString().concat(" cargarDAV - ERROR : ").concat("No se encontro el dato buscado"));
                res = new ModelAndView("PagM", "beanM", rBean);
            }
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res = new ModelAndView("PagM", "beanM", rBean);
        }

        return res;
    }

    /**
     * Permite obtener los datos d euna persona natural o juridica, segun los
     * parametros "tip_doc"y "cod_busq" invocaciones: FormatoBDAV.jsp
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws ServletException
     *           the servlet exception
     * @throws IOException
     *           Signals that an I/O exception has occurred.
     */
    public ModelAndView busqDatosPers(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException
    {
        try
        {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            Map<String, Object> res = this.soporteService.obtenerPerNatJur(
                    webRequest.getParameter("tip_doc"),
                    webRequest.getParameter("cod_busq"));
            return new ModelAndView(this.jsonView, "data", res);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(this.jsonView, "beanM", rBean);
        }
    }

    /**
     * Metodo que da inicio a la grabacion de Diligencia de Despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    /**
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public ModelAndView grabarDiligenciaDespacho(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {


            ServletWebRequest webRequest = new ServletWebRequest(request);
            Map<String, Object> diligencia = new HashMap();
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            //ORDONEZ_P24
            Map<String, Object> generacionLCMulta = new HashMap<String, Object>();
            generacionLCMulta.put("generarLC003", WebUtils.getSessionAttribute(request, "generarLC003"));
            generacionLCMulta.put("generarLCMulta", WebUtils.getSessionAttribute(request, "generarLCMulta"));
            generacionLCMulta.put("datosMulta", WebUtils.getSessionAttribute(request, "datosMulta"));

            String tipDilig = WebUtils.getSessionAttribute(request, "tipoDiligencia").toString().trim();

            UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());


            List lstFacturasSerieBD = new ArrayList();
            if (WebUtils.getSessionAttribute(request, "lstFacturasSerie") == null)
            {

                HashMap<String, Object> mapaNumCorreDoc = new HashMap<String, Object>();
                mapaNumCorreDoc.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
                lstFacturasSerieBD = formatoValorService.obtenerFacturasSerie(mapaNumCorreDoc);
                WebUtils.setSessionAttribute(request, "lstFacturasSerie", lstFacturasSerieBD);
            }
            if (WebUtils.getSessionAttribute(request, "lstFacturasSerieActual") == null
                    && (lstFacturasSerieBD != null && lstFacturasSerieBD.size() > 0))
            {
                WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieBD);
            }
            //ORDONEZ_P24
            List<Incidencia>  lstIncidencias = obtenerIncidencias(request);
            diligencia.put("IND_INCIDENCIA", lstIncidencias == null|| lstIncidencias.isEmpty() ? "N" : "S");

            List<Map<String, Object>> multas = new ArrayList<Map<String, Object>>();
            multas = (List<Map<String, Object>>) WebUtils
                    .getSessionAttribute(request, "lstMultaDua");
            diligencia.put("IND_MULTA",	multas == null || multas.isEmpty() ? "N" : "S");// RIN13

            ResCabBean resolucionMulta=(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionMulta");
            boolean isResolucionMulta = resolucionMulta!=null ? true:false;
            log.debug("isResolucionMulta:" + isResolucionMulta );
            if (diligencia.get("IND_MULTA").equals("S")  && isResolucionMulta) {
                //Grabando la Resoluci�n de Determinaci�n de Multas para la Diligencia.
                diligencia.put("COD_TIPDOCDILI", resolucionMulta.getCodTipDocDili().getCodTipDocSustento());
                diligencia.put("COD_ADUADOCSUST", resolucionMulta.getCodAduanaDocSust());
                diligencia.put("COD_TIPDOCSUST", resolucionMulta.getCodTipDocSust());
                diligencia.put("COD_AREADOCSUST", resolucionMulta.getCodAreaDocSust());
                diligencia.put("ANN_DOCSUST", resolucionMulta.getAnnDocSust());
                diligencia.put("NUM_DOCSUST", resolucionMulta.getNumDocSust());
            }
            Date fechaDeclaracion = (Date) declaracionActual.get("FEC_DECLARACION");
            ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
    		    	    boolean esVigentePecoAmazoniaSegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigentePecoAmazoniaSegundaParte(fechaDeclaracion):false;
        	
            /*grabar en dipolsolpeco pase 69*/
            ResCabBean resolucionTributo=(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionTributo");
            boolean isResolucionTributo = resolucionTributo!=null ? true:false;
            log.debug("isResolucionTributo:" + resolucionTributo );
            Dipolsolpeco resDipolsolpeco = new Dipolsolpeco();
            bindToCommand(request, resDipolsolpeco);
            String codiAduana=declaracionActual.get("COD_ADUANA").toString()!=null?declaracionActual.get("COD_ADUANA").toString():" ";
            String anoPrese=declaracionActual.get("ANN_PRESEN").toString()!=null?declaracionActual.get("ANN_PRESEN").toString():" ";
            String numeroDam=declaracionActual.get("NUM_DECLARACION").toString()!=null?declaracionActual.get("NUM_DECLARACION").toString():" ";
            String codRegimen=declaracionActual.get("COD_REGIMEN").toString()!=null?declaracionActual.get("COD_REGIMEN").toString():" ";
            if (isResolucionTributo) {
            	Map<String, Object> mapaSolicitud = new HashMap<String, Object>();
            	mapaSolicitud.put("numCorreDocPre", declaracionActual.get("NUM_CORREDOC").toString() );
        		mapaSolicitud.put("codTipSol", new String[] {ConstantesDataCatalogo.TIPO_SOLICITUD_RECONOCIMIENTO_FISICO});
        		SolicitudDAO solicitudDAO = fabricaDeServicios.getService("despaduanero2.solicitudDAO");
        		List<Solicitud> solReguReconFisico =  solicitudDAO.buscarSolicitudesAsociadasDAMs(mapaSolicitud);
            	
        		 codiAduana=declaracionActual.get("COD_ADUANA").toString()!=null?declaracionActual.get("COD_ADUANA").toString():" ";
                 anoPrese=resolucionTributo.getAnnoDocReferencia()!=null?resolucionTributo.getAnnoDocReferencia().toString():" ";
                 numeroDam=resolucionTributo.getNroDocReferencia().toString();
                
            	if (solReguReconFisico != null){
                //Grabando la Resoluci�n de Determinaci�n de Multas para la Diligencia.
                String aduanasolicitud=declaracionActual.get("COD_ADUANA").toString();
                String anioSolicitud=solReguReconFisico.get(0).getAnnoSolicitud().toString();
                String numeroSolicitud =  solReguReconFisico.get(0).getNumeroSolicitud().toString();
                String numeroResolucion=request.getParameter("numDocSust")!=null?request.getParameter("numDocSust"):" ";
                if(numeroResolucion.length()>15){
                    numeroResolucion=numeroResolucion.substring(0,14);
                }
                
                Date fechaResolucion1=resolucionTributo.getFechaEmision();
                Integer fechaResolucion=SunatDateUtils.getIntegerFromDate(fechaResolucion1);
                Integer fechaSolicitud1=resolucionTributo.getFresol();
                Integer fechaSolicitud=SunatDateUtils.getIntegerFromDate(fechaSolicitud1);
                //Integer fechaSolicitud=0;
                if(fechaSolicitud1==null){
                    fechaSolicitud=0;
                }else{
                    fechaSolicitud=SunatDateUtils.getIntegerFromDate(fechaSolicitud1);
                }

                resDipolsolpeco.setAduanaSolicitud(aduanasolicitud);
                resDipolsolpeco.setAnioSolicitud(anioSolicitud);
                resDipolsolpeco.setNumeroSolicitud(SunatStringUtils.lpad(numeroSolicitud,6,'0'));
                resDipolsolpeco.setFechaSolicitud(SunatNumberUtils.toInteger(fechaSolicitud)); 
                
                resDipolsolpeco.setNumeroDam(SunatStringUtils.lpad(numeroDam,6,'0'));               
                resDipolsolpeco.setAduanaDam(codiAduana);
                resDipolsolpeco.setAnioDam(anoPrese);
                              
                //Buscar solicitud en dipolsolpeco
  				 SolicitudPecoService solicitudPecoService = (SolicitudPecoService) fabricaDeServicios.getService("tramite.SolicitudPecoService");
  				 Dipolsolpeco  dipolsolEncontrada =   solicitudPecoService.buscarSolicitudesResolucionesNotasCredito(resDipolsolpeco);

                /* traer el servicio de administracion para grabar la resolucion*/

                
				 //Si no existe Grabar solicitud en dipolsolpeco 
				 if (dipolsolEncontrada==null){
					 solicitudPecoService.grabarDipolsolpeco(resDipolsolpeco, declaracionActual.get("NUM_CORREDOC").toString());							 
					  }else {
					 resDipolsolpeco.setNumeroResolucion(numeroResolucion);
		             resDipolsolpeco.setFechaResolucion(SunatNumberUtils.toInteger(fechaResolucion));
					 solicitudPecoService.modificarDipolsolpeco(resDipolsolpeco);	
					 
				 }
            	}
            }else
            {

                SolicitudPecoAmazoniaService solicitudPecoAmazoniaService = fabricaDeServicios.getService("despaduanero2.solicitudPecoAmazoniaService");
                SolicitudPecoAmazonia solicitud = new SolicitudPecoAmazonia();

//            		userSession.setNroRegistro(userSession.getNroRegistro().trim());
//					  WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
//					  UserNameHolder.set(userSession.getLogin(), request.getRemoteAddr());
                String numCorreDoc =  declaracionActual.get("NUM_CORREDOC").toString();
                Map<String,Object> datosDeclaracion = new HashMap<String,Object>();
                datosDeclaracion=solicitudPecoAmazoniaService.cargarDatos(numCorreDoc);


                /*cargar la solicitud*/
                String rucConsignatario =  datosDeclaracion.get("ConsignatarioRuc").toString();
                String rucAgente = 	datosDeclaracion.get("AgenteAduanaRuc").toString();



                SolicitudPecoAmazonia solicitudPecoAmazonia = new SolicitudPecoAmazonia();
                Participante consignatario = completarParticipanteBD(rucConsignatario, ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC ,ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO, numCorreDoc);
                Participante despachador = completarParticipanteBD(rucAgente, ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC, ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA, numCorreDoc);

                RelacionDocumento declaracionAsociada = new RelacionDocumento();
                declaracionAsociada.setCodAduana(codiAduana);
                declaracionAsociada.setRegimen(codRegimen);
                declaracionAsociada.setNumeroDeclaracion(new Integer(numeroDam));
                declaracionAsociada.setAnnoPresentacion(new Integer(anoPrese));
                declaracionAsociada.setNumeroCorrelativoPrecedente(new Long(numCorreDoc));

                DetEvaluacion evaluacion = new DetEvaluacion();
                solicitudPecoAmazonia.setConsignatario(consignatario);
                solicitudPecoAmazonia.setDespachador(despachador);
                solicitudPecoAmazonia.setEvaluacion(evaluacion);
                solicitudPecoAmazonia.setDeclaracionAsociada(declaracionAsociada);

                // inicio setea algunos datos que se van usar
                DataCatalogo catAduana = new DataCatalogo();
                catAduana.setCodDatacat(codiAduana);
                solicitudPecoAmazonia.setAduana(catAduana);
                solicitudPecoAmazonia.getDeclaracionAsociada().setAduana(catAduana);
                solicitudPecoAmazonia.setCodAduana(codiAduana);
                solicitudPecoAmazonia.setRegimen(codRegimen);
                solicitudPecoAmazonia.setEstadoSolicitud("01");

                // fin
                Date fechaRegistro= new Date(System.currentTimeMillis());
                solicitudPecoAmazonia.setFechaRegistro(fechaRegistro);
                // solicitudPecoAmazonia.setUsuarioRegistra(userSession.getNroRegistro().trim());
                //solicitudPecoAmazonia.getEvaluacion().setObsObs("REGISTRAR SOLICITUD DE REGULARIZACION/RECONOCIMIENTO FISICO");
                Solicitud solicitudGrabada = solicitudPecoAmazoniaService.registrarSolicitudReconocimientoFisico(solicitudPecoAmazonia) ;
                if (solicitudGrabada!=null){

                    Dipolsolpeco Dipolsolpeco = new Dipolsolpeco();
                    Dipolsolpeco.setAduanaSolicitud(solicitudGrabada.getCodAduana());
                    Dipolsolpeco.setAnioSolicitud(solicitudGrabada.getAnnoSolicitud().toString());
                    Dipolsolpeco.setNumeroSolicitud(SunatStringUtils.lpad(String.valueOf(solicitudGrabada.getNumeroSolicitud()),6,'0'));
                    //Buscar solicitud en dipolsolpeco
                    SolicitudPecoService solicitudPecoService = (SolicitudPecoService) fabricaDeServicios.getService("tramite.SolicitudPecoService");
                    Dipolsolpeco  dipolsolEncontrada =   solicitudPecoService.buscarSolicitudesResolucionesNotasCredito(Dipolsolpeco);

                    //Si no existe Grabar solicitud en dipolsolpeco
                    if (dipolsolEncontrada==null){
                        Dipolsolpeco.setFechaResolucion(0);
                        Dipolsolpeco.setNumeroResolucion(" ");
                        Dipolsolpeco.setFechaSolicitud(DateUtil.dateToInteger(solicitudGrabada.getFechaSolicitud()));
                        Dipolsolpeco.setHoraSolicitud(Integer.valueOf(DateUtil.dateToString(solicitudGrabada.getFechaSolicitud(), "HHmmss")));  
                        Dipolsolpeco.setAduanaDam(solicitudGrabada.getCodAduana());
			             Dipolsolpeco.setAnioDam(solicitudGrabada.getAnnoSolicitud().toString());
			             Dipolsolpeco.setNumeroDam(SunatStringUtils.lpad(String.valueOf(numeroDam),6,'0'));
                        solicitudPecoService.grabarDipolsolpeco(Dipolsolpeco,numCorreDoc);

                        
                    }else {
                        Dipolsolpeco.setFechaResolucion(0);
                        Dipolsolpeco.setFechaSolicitud(DateUtil.dateToInteger(solicitudGrabada.getFechaSolicitud()));
                        solicitudPecoService.modificarDipolsolpeco(Dipolsolpeco);

                    }


                    try{
                        // enviara notificacion
                        solicitudPecoAmazoniaService.enviarNotificacionesPecoAmazonia(solicitudPecoAmazonia,"01", numCorreDoc);
                    }catch (Exception e) {
                        logger.error("***********ERROR enviarNotificacionesPecoAmazonia**************",e);
                    }
                }
            }


            declaracionActual.put("lstFacturasSerieAnt",(ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerie"));
            declaracionActual.put("lstFacturasSerieActual",(ArrayList) WebUtils.getSessionAttribute(request, "lstFacturasSerieActual"));
            // Obtenemos los parametros de request
            //diligencia.put("IND_INCIDENCIA", webRequest.getParameter("incidencia"));
            //diligencia.put("IND_MULTA", webRequest.getParameter("multa"));

            //rin08
            String resultadoDilig=((String)WebUtils.getSessionAttribute(request,"estadoResultadoAduanaDestinoMercancia")).concat( ":").concat(
                    (String)WebUtils.getSessionAttribute(request,"resultadoAduanaDestinoMercancia")).concat("\n").concat(webRequest.getParameter("resultado"));
            diligencia.put("DES_RESULTADO", resultadoDilig);
            diligencia.put("estadoResultadoAduanaDestinoMercancia", (String)WebUtils.getSessionAttribute(request,"estadoResultadoAduanaDestinoMercancia"));
            //end


            diligencia.put("COD_TIPDILIGENCIA", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
            diligencia.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
            diligencia.put("CNT_BULTOSRECON", new Double(((webRequest.getParameter("txt_cnt_bultosrecon") == null || "".equals(webRequest.getParameter("txt_cnt_bultosrecon").toString().trim())) ? "0" : webRequest.getParameter("txt_cnt_bultosrecon"))));

            FechaBean fDilig = null;
            if (!SunatStringUtils.isEmpty(webRequest.getParameter("fDilig")))
            {
                if (Constantes.ESTADO_CONCLU_PROCESO.equals(declaracionActual.get("COD_ESTDUA").toString().trim()))
                {
                    fDilig = new FechaBean(webRequest.getParameter("fDilig"), "dd/MM/yyyy_hh:mm:ss");
                }
                else
                {
                    fDilig = new FechaBean(webRequest.getParameter("fDilig"));
                }
            }
            else
            {
                fDilig = new FechaBean();
            }
            diligencia.put("FEC_DILIGENCIA", fDilig.getTimestamp());
            Map<String, Object> params = new HashMap();
            params.put("mapCabDiligenciaActual", diligencia);
            params.put("mapCabDeclaraActual", declaracionActual);

            // quitar pendientes,eliminados detDeclara
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils
                    .getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");

            params.put("lstDetDeclaraActual", lstDetDeclara);
            params.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
            params.put("lstSeriesItemActual", lstSeriesItemActual);
            params.put("lstSeriesItem", lstSeriesItem);
            params.put("caduana", soporteService.obtenerAduana(request));
            params.put("lstMultaDua", (ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDua"));
            params.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));
            //params.put("lstIncidencias", WebUtils.getSessionAttribute(request, "lstIncidencias"));
            params.put("totalAutoliqDolares", WebUtils.getSessionAttribute(request, "totalAutoliqDolares"));
            params.put("totalAutoliqSoles", WebUtils.getSessionAttribute(request, "totalAutoliqSoles"));
            
            params.put("lstIncidencias", lstIncidencias);
            params.put("cod_funcionario", bUsuario.getNroRegistro());

            actualizandoSerieAndSeriesItem(params);
            //inicio CU 14.21
            if(declaracionActual.get("IND_FORMBPROVEEDOR")!= null && "0".equals(declaracionActual.get("IND_FORMBPROVEEDOR").toString())){
                this.actualizarIdDeItemFactura(params);
                declaracionActual = this.restaurarCantidadYFobItemEliminado(params);
            }
            lstSeriesItemActual = (List<Map<String, Object>>)params.get("lstSeriesItemActual");
            //finc CU 14.21

            //ya esta arriba
            //params.put("caduana", soporteService.obtenerAduana(request));
            //params.put("lstMultaDua", (ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDua"));
            //params.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));
            //params.put("lstIncidencias", WebUtils.getSessionAttribute(request, "lstIncidencias"));
            //params.put("cod_funcionario", bUsuario.getNroRegistro());
            //fin ya esta arriba
            params.put("generacionLCMulta", generacionLCMulta);
            //params.put("lstMultaDuaLC003", WebUtils.getSessionAttribute(request, "lstMultaDuaLC003"));
            params.put("lstMultaDuaOkResolucion", WebUtils.getSessionAttribute(request, "lstMultaDuaOkResolucion")); //bug21603

            params.put( "mapCabAdiDiligVinc", (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabAdiDiligVinc"));


            Map prmtVal = new HashMap();
            String codTransaccion = tipDilig == ConstantesDataCatalogo.COD_DILIG_REGULAR?Constants.COD_TRANSAC_DILIGENCIAREGUL:Constants.COD_TRANSAC_DILIGENCIADESPA;
            prmtVal.put("mapCabDeclara", declaracionActual);
            prmtVal.put("lstDetDeclara", WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));
            prmtVal.put("lstFacturasSerie", WebUtils.getSessionAttribute(request, "lstFacturasSerie"));
            prmtVal.put("codTransaccion", declaracionActual.get("COD_REGIMEN").toString().trim() + codTransaccion);
            prmtVal.put("lstSeriesItemActual", lstSeriesItemActual);

            List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
            Declaracion decla = transformHelper.transform(prmtVal);
            params.put("objDeclaracion", decla);
            params.put("objUsuario", bUsuario);
            
            this.diligenciaService.grabarDiligenciaDespachoAduanaDestino(params);
            /* aqui se graba en la tabla dipolsolpeco pase 69 */

            //Grabar resolucion de devolucion csantillan PAS20181U220200069
            String valResolucion = request.getParameter("validacionResol");
            if (tipDilig.equals(Constantes.COD_TIPO_DILIGENCIA_ADUANA_DESTINO) && !valResolucion.isEmpty()){

                String nroCorrelativoDUA = declaracionActual.get("NUM_CORREDOC").toString();
                String codTipOper = TIPO_DOC_ASOCIADO_RESOLUCION_DEVOLUCION;
                String codTipDocAso = CODIGO_PROCESO_SOPORTE;
                String numeroResolucion =request.getParameter("numDocSust");
                String aduanaResolucion =request.getParameter("codAduanaDocSust");
                String anioResolucion =request.getParameter("annDocSust");
                String fechaFinResolucion = "31/12/9999";
                String fechaIniResolucion = SunatStringUtils.trimNotNull(request.getParameter("fecEmision").replace("-", "")); // formato entero
                String codAreaResolucion = request.getParameter("codAreaDocSust");

                this.diligenciaService.insertarResolucion(nroCorrelativoDUA,codTipOper,codTipDocAso,numeroResolucion,aduanaResolucion,anioResolucion,fechaIniResolucion,fechaFinResolucion,codAreaResolucion);

            }
            
            boolean bandejaJefeDAM = (Boolean) (params.get("bandejaJefeDAM")!=null?params.get("bandejaJefeDAM"):true);
            if(bandejaJefeDAM && esVigentePecoAmazoniaSegundaParte){
            Long numCorredoc=(new Long(declaracionActual.get("NUM_CORREDOC").toString()));
            this.diligenciaService.actualizarDiligenciaDuaJefeDestino(numCorredoc);
            }
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            declaracion.putAll(declaracionActual);
            WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
            enviarAlertaCorreo(request);
            res.addObject("recOk", true);
            res.addObject("mensajeRespuesta", "");//res.addObject("mensajeRespuesta", resultado.get("mensajeRespuesta").toString());
            res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
            // mol PAS20181U220200069
            if (params != null && params.size() > 0 && params.get("mensaje") != null){
                List<Map<String, String>> mensaje= (List<Map<String, String>>) params.get("mensaje"); //MOL PASE280
                listaErrores.addAll(mensaje); //MOL PASE280
            }

            res.addObject("resValidacion", SojoUtil.toJson(listaErrores));
            Utilidades.limpiarMapasSesion(request);

        }
        catch (Exception e)
        {

            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        finally
        {

            return res;
        }

    }
    
	 public Participante completarParticipanteBD(String numRuc, String tipoDoc, String tipoParticipante, String numCorredocDeclaracion){
		 Map<String,Object> params = new HashMap<String, Object>();
		params.put("numeroCorrelativo", numCorredocDeclaracion);
		params.put("codTipoParticipante", tipoParticipante);
		params.put("tipoDocumentoIdentidad", tipoDoc);
		params.put("numeroDocumentoIdentidad", numRuc);		
		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
		List<Participante> listParticipante = participanteService.obtenerParticipanteByParameterMap(params);
		
		Participante participanteBD = new Participante();
		participanteBD = listParticipante.get(0);
		
		return participanteBD;
	 }

    //ORDONEZ_P24
    private List<Incidencia> obtenerIncidencias (HttpServletRequest request) throws Exception
    {
        List<Incidencia> incidencias = new ArrayList();
        List<Incidencia> incidenciasA = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasAuto");
        List<Incidencia> incidenciasM = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasManu");

        //se ejecuta solo si no se ejecuto la priemra vez
        if(CollectionUtils.isEmpty(incidenciasA)){
            this.setearIncidenciasAutomaticas(request);
        }

        incidenciasA = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasAuto");

        if(!CollectionUtils.isEmpty(incidenciasA)) {
            incidencias.addAll(incidenciasA);
        }
        if(!CollectionUtils.isEmpty(incidenciasM)) {
            incidencias.addAll(incidenciasM);
        }

        return incidencias;
    }

    private void setearIncidenciasAutomaticas(HttpServletRequest request) throws Exception {

        List<RegistroIncidenciaForm> lstIncidenciasAutomaticas = new ArrayList<RegistroIncidenciaForm>();

        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        boolean tieneIncidencia = declaracionActual.get("tieneIncTrib")!=null && "S".equals(declaracionActual.get("tieneIncTrib").toString())?true:false;

        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");

        MovCabliqdilig movCabliqdilig = (MovCabliqdilig) declaracionActual.get("movCabliqdilig");
        List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
        List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");

        HttpSession session = request.getSession();

        if (CollectionUtils.isEmpty(lstSeriesItemActual)){
            Map<String, Object> param = new HashMap<String, Object>();
            Long numCorredoc = new Long(declaracionActual.get("NUM_CORREDOC").toString());
            param.put("NUM_CORREDOC", numCorredoc);

            lstSeriesItem = serieService.obtenerSeriesItem(param);
            lstSeriesItemActual = Utilidades.copiarLista((List)lstSeriesItem);
        }

        // validamos los datos principales
        if (!org.springframework.util.CollectionUtils.isEmpty(declaracionActual)
                && !CollectionUtils.isEmpty(lstDetDeclaraActual)) {

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("declaracionActual", declaracionActual);
            params.put("declaracion", declaracion);
            params.put("lstDetDeclaraActual", lstDetDeclaraActual);
            params.put("lstDetDeclaraAnt", lstDetDeclara);
            params.put("lstSeriesItemActual", lstSeriesItemActual);
            params.put("lstSeriesItem", lstSeriesItem);
            params.put("movCabliqdilig", movCabliqdilig);
            params.put("tieneIncidencia", tieneIncidencia);

            // crear una nueva lista agrupada especial para la vista
            List<Incidencia> incidencias  = incidenciaService.obtenerIncidenciaAutomatica(params);
            //esto es lo que se debe grabar en session
            WebUtils.setSessionAttribute(request, "incidenciasAuto", incidencias);

        }
    }
    /**
     * Es regimen valido modi fecha venc regimen.
     *
     * @param tipoRegimen
     *          the tipo regimen
     * @return true, if successful
     */
    private boolean esRegimenValidoModiFechaVencRegimen(String tipoRegimen)
    {

        String[] regimenValidos = { "20", "21" };

        return Arrays.asList(regimenValidos).contains(tipoRegimen);
    }

    /**
     * Es regimen valido modi plazos.
     *
     * @param tipoRegimen
     *          the tipo regimen
     * @return true, if successful
     */
    private boolean esRegimenValidoModiPlazos(String tipoRegimen)
    {

        String[] regimenValidos = { "70" };

        return Arrays.asList(regimenValidos).contains(tipoRegimen);
    }

    /**
     * Actualizando serie and series item.
     *
     * @param params
     *          the params
     * @throws Exception
     *           the exception
     */
    public void actualizandoSerieAndSeriesItem(Map<String, Object> params) throws Exception
    {
        // Variables para intercambio de series
        // temporal del numero de serie, se incrementa en medida que sea serie
        // valida a conservar
        // Se conservan las series que existan en BD, es decir en la lista anterior
        // de series y
        // las nuevas series que no tengan estado IND_DEL = 1, solo se conservan las
        // IND_DEL = 0
        // Integer numSecSerieTemp = 0;

        List<Map<String, Object>> lstDetDeclara = params.get("lstDetDeclaraActual") != null ? (ArrayList) params.get("lstDetDeclaraActual") : new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDetDeclaraAnt = null != params.get("lstDetDeclaraAnt") ? (ArrayList) params.get("lstDetDeclaraAnt") : new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItemActual = null != params.get("lstSeriesItemActual") ? (ArrayList) params.get("lstSeriesItemActual") : new ArrayList<Map<String, Object>>();

        Map cabDeclara = (HashMap) params.get("mapCabDeclaraActual");
        List<Map<String, Object>> lstDetAutorizacionActual = new ArrayList<Map<String, Object>>();

        if (!CollectionUtils.isEmpty(cabDeclara))
        {
            lstDetAutorizacionActual = cabDeclara.get("lstDetAutorizacion") != null ? (ArrayList) cabDeclara.get("lstDetAutorizacion") : new ArrayList<Map<String, Object>>();
        }

        String IND_REGISTRO_PENDIENTE = "1";

        // contador maximo
        String numCorreDocDua = cabDeclara.get("NUM_CORREDOC").toString();
        int contadorMax = serieService.getSgteNumSecSerie(numCorreDocDua);

        // removiendo los pendientes, eliminados; por registrar
        if (lstDetDeclara != null)
        {
            for (Iterator it = lstDetDeclara.iterator(); it.hasNext();)
            {
                Map serie = (HashMap) it.next();
                // ESTADO_REGISTRO =1 :pendiente de registro en BD.
                if (serie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE) ||
                        (serie.get("ESTADO_REGISTRO").toString().equals("1") &&
                                serie.get("IND_DEL").toString().equals("1")))
                {
                    // Listas fuera de la serie que poseen relacion
                    // lstSeriesItem
                    for (Iterator itSI = lstSeriesItemActual.iterator(); itSI.hasNext();)
                    {
                        Map seriesItem = (HashMap) itSI.next();
                        if (seriesItem.get("NUM_SECSERIE").toString().equals(serie.get("NUM_SECSERIE").toString()))
                        {
                            itSI.remove();
                        }
                    }

                    // lstDetAutorizacion
                    for (Iterator itDetAut = lstDetAutorizacionActual.iterator(); itDetAut.hasNext();)
                    {
                        Map detAutorizacion = (HashMap) itDetAut.next();
                        if (detAutorizacion.get("NUM_SECSERIE").toString().equals(serie.get("NUM_SECSERIE").toString()))
                        {
                            itDetAut.remove();
                        }
                    }
                    it.remove();
                }
            }
        }
        // asignando numero de serie nuevo quitando los datos de baja
        if (lstDetDeclara != null)
        {
            for (Map<String, Object> serie : lstDetDeclara)
            {
                String num_secSerieAnt = serie.get("NUM_SECSERIE").toString();
                // solo se consideran a los activos las series eliminadas y no
                // recuepradas no se consideran
                // para evitar se creen huecos de numeracion
                if (serie != null && serie.get("ESTADO_REGISTRO").toString().equals("1")
                        && serie.get("IND_DEL").toString().equals("0"))
                {

                    serie.put("NUM_SECSERIE", contadorMax);
                    // Asignamos nuevo NUM_SECSERIE A LISTAS DENTRO DE SERIE
                    // lstFacturaSerie
                    List<Map> lstFacturaSerie = (List) serie.get("lstFacturaSerie");
                    if (!CollectionUtils.isEmpty(lstFacturaSerie))
                    {
                        for (Map mapFactuSerie : lstFacturaSerie)
                        {
                            mapFactuSerie.put("NUM_SECSERIE", contadorMax);
                        }
                    }
                    // lstConvenio
                    List<Map> lstConvenioSerie = (List) serie.get("lstConvenioSerie");
                    if (!CollectionUtils.isEmpty(lstConvenioSerie))
                    {
                        for (Map mapConvenioSerie : lstConvenioSerie)
                        {
                            mapConvenioSerie.put("NUM_SECSERIE", contadorMax);
                        }
                    }
                    // lstDocuPreceDua
                    List<Map> lstDocuPreceDua = (List) serie.get("lstDocuPreceDua");
                    if (!CollectionUtils.isEmpty(lstDocuPreceDua))
                    {
                        for (Map mapDocuPreceDua : lstDocuPreceDua)
                        {
                            mapDocuPreceDua.put("NUM_SECSERIE", contadorMax);
                        }
                    }
                    // lista Series Item
                    if (lstSeriesItemActual != null)
                    {
                        for (Map<String, Object> serieItem : lstSeriesItemActual)
                        {
                            if (num_secSerieAnt.equals(serieItem.get("NUM_SECSERIE").toString()))
                            {
                                serieItem.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
                            }
                        }
                    }
                    // lista de DetAutorizantes
                    if (lstDetAutorizacionActual != null)
                    {
                        for (Map<String, Object> detAutorizacion : lstDetAutorizacionActual)
                        {
                            if (num_secSerieAnt.equals(detAutorizacion.get("NUM_SECSERIE").toString()))
                            {
                                detAutorizacion.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
                            }
                        }
                    }
                    // sgte correlativo de la serie
                    contadorMax++;
                }
            }
        }

        if (!CollectionUtils.isEmpty(cabDeclara))
        {
            cabDeclara.put("lstDetAutorizacion", lstDetAutorizacionActual);
        }

        params.put("mapCabDeclaraActual", cabDeclara);
        params.put("lstDetDeclaraActual", lstDetDeclara);
        params.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
        params.put("lstSeriesItemActual", lstSeriesItemActual);
    }

    /**
     * Permite validar plazos para la declaracion.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView validarDuracion(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        try
        {
            Map params = new HashMap();
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            params.put("tipoOperDespacho", declaracion.get("COD_TIPDESP"));
            params.put("fecInicial", declaracion.get("FEC_DECLARACION"));

            ServletWebRequest webRequest = new ServletWebRequest(request);
            if ("1".equals((String) webRequest.getParameter("undMed")))
            {

                params.put("fecEvaluada", new FechaBean(new Timestamp(SunatDateUtils.addMonth(
                        (Timestamp) declaracion.get("FEC_DECLARACION"),
                        Integer.parseInt((String) webRequest.getParameter("cntDur"))).getTime())));

            }
            else if ("2".equals((String) webRequest.getParameter("undMed")))
            {

                String cFechaNumeracion = new SimpleDateFormat("dd/MM/yyyy").format(declaracion.get("FEC_DECLARACION"));

                params.put("fecEvaluada", new FechaBean(new Timestamp(Utilidades.addUtilDay(cFechaNumeracion,
                        Integer.parseInt((String) webRequest.getParameter("cntDur"))).getTime())));

            }

            res.addObject("fecOk", this.diligenciaService.validarPlazo(params));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        finally
        {

        }
        return res;
    }


    public ModelAndView cerrarBeneficio(HttpServletRequest request, HttpServletResponse response)
    {   ModelAndView res = new ModelAndView(this.jsonView);
        try
        {

            //Map<String, Object> parametros = new HashMap();
            // quitar pendientes,eliminados detDeclara
            List<Map<String, Object>>  lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            //List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
            //List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            //parametros.put("lstDetDeclaraActual", lstDetDeclara);
            //parametros.put("lstSeriesItemActual", lstSeriesItemActual);
            //parametros.put("lstSeriesItem", lstSeriesItem);

            Map<String, Object> mapCabDeclara;
            mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            Map<String, String> params = new HashMap<String, String>();
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
            params.put("num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
            params.put("cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
            params.put("ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
            params.put("cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());

            lstDetDeclara = serieService.obtenerListadoSeries(params);

            //limpia la variable de session
            WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
            List<Map<String, Object>> lstSerieOld= new ArrayList<Map<String, Object>>();
            lstSerieOld.addAll(Utilidades.copiarLista((List)lstDetDeclara));
            WebUtils.setSessionAttribute(request, "lstDetDeclara", lstSerieOld);


            if (lstDetDeclaraActual != null)
            {
                for (Iterator it = lstDetDeclaraActual.iterator(); it.hasNext();)
                {
                    Map serie = (HashMap) it.next();

                    if (serie.get("IND_DEL")==null || !serie.get("IND_DEL").toString().equals("1"))
                    {
//							if(!"".equals(serie.get("COD_CONVENIO_CC").toString().trim())){
//								serie.put("COD_CONVENIO_CC", " ");
//							}
//							if(!"".equals(serie.get("COD_CONVENIO_CI").toString().trim())){
//								serie.put("COD_CONVENIO_CI", " ");
//							}

                        // lstConvenio quitar acogimiento peco y/o amazonia
                        List<Map> lstConvenioSerie = (List) serie.get("lstConvenioSerie");
                        if (!CollectionUtils.isEmpty(lstConvenioSerie))
                        {
                            String[] lstpecoAmazonia = Constantes.LISTA_PECO_AMAZONIA; //peco y/o ley amazonia aduana de destino

                            for (Map mapConvenioSerie : lstConvenioSerie)
                            {
                                if( mapConvenioSerie.get("COD_CONVENIO") !=null && ArrayUtils.contains(lstpecoAmazonia, mapConvenioSerie.get("COD_CONVENIO").toString().trim())){
                                    mapConvenioSerie.put("IND_DEL","1");
                                }
                            }
                        }



                    }
                }
            }
            List<Incidencia> incidenciasA = (List<Incidencia>)WebUtils.getSessionAttribute(request, "incidenciasAuto");
            setearIncidenciasAutomaticas(request);
            res.addObject("resultadoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO);
            WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Mercancia no llego a Destino");
            WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO);
            //  WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclara);

            res.addObject("cerrarBeneficio", true);

        }
        catch (Exception e)
        {  res.addObject("cerrarBeneficio", false);
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        finally
        {
            return res;
        }
    }
    /**
     * Pre-Condicion : Registro de datos de la Diligencia (Multas,Incidencias,etc)
     * y Click Boton Grabado de la Diligencia. Proceso : Metodo que realiza la
     * validacion previa al grabado de la DILIGENCIA Post-Condicion: Invocaciones
     * : RegRegularizacion.jsp, RegDiligenciaDespacho.jsp
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return ModelAndView(this.jsonView)
     * @autor: amancillaa
     */
    public ModelAndView evalEjecVerificacion(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        Map dataForm = new HashMap();
        try
        {
            Map<String, Object> declaracionActual = (Map<String, Object>)WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            // Agregado para reorden de series
            Map<String, Object> parametros = new HashMap();
            parametros.put("mapCabDeclaraActual",declaracionActual);

            // quitar pendientes,eliminados detDeclara
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils
                    .getSessionAttribute(request, "lstDetDeclaraActual");
            Date varfechaDiligencia = new Date(request.getParameter("fechaValido")) ;

            //Date varfechaDiligencia = SunatDateUtils.getDate(request.getParameter("fechaValido"));

            List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(
                    request,
                    "lstSeriesItemActual");
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            parametros.put("lstDetDeclaraActual", lstDetDeclara);
            parametros.put("lstDetDeclaraAnt", lstDetDeclaraAnt);
            parametros.put("lstSeriesItemActual", lstSeriesItemActual);
            parametros.put("lstSeriesItem", lstSeriesItem);
            parametros.put("caduana", soporteService.obtenerAduana(request));
            parametros.put("mapCabDeclara", WebUtils.getSessionAttribute(request, "mapCabDeclara"));
            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            actualizandoSerieAndSeriesItem(parametros);

            if(declaracionActual.get("IND_FORMBPROVEEDOR")!= null && "0".equals(declaracionActual.get("IND_FORMBPROVEEDOR").toString())){
                this.actualizarIdDeItemFactura(parametros);
            }
            request.getSession().setAttribute("mapCabDeclaraActual", parametros.get("mapCabDeclaraActual"));
            request.getSession().setAttribute("lstDetDeclaraActual", parametros.get("lstDetDeclaraActual"));
            request.getSession().setAttribute("lstSeriesItemActual", parametros.get("lstSeriesItemActual"));

            // si es null o vacio obtener de BD
            if (CollectionUtils.isEmpty(lstDetDeclara))
            {
                // Cargar series
                cargarSeriesSesion(request);
                lstDetDeclara = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

            }
            List<Map<String, Object>> lstDocTransporteProrratear =declaracionCalculoDeDatos.obtenerDocTransporteAProrratearDesdeSeries((List) lstDetDeclara);
            request.setAttribute("lstDocTransporteProrratear", lstDocTransporteProrratear);
            String resValidacion = this.validaGrabaDeclaSesion(request, dataForm);

            if (SunatStringUtils.isEmpty(resValidacion))
            {
                List<Map<String, Object>> lstDetDeclaraActual =	(List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");

                String tipDilig = WebUtils.getSessionAttribute(request, "tipoDiligencia").toString().trim();
                // if (Constantes.DILIG_ADUANA_DESTINO.equals(tipDilig) )//21
                // {
                Map prmtVal = new HashMap();
                prmtVal.put("mapCabDeclara", declaracionActual);
                prmtVal.put("lstDetDeclara", lstDetDeclaraActual);
                prmtVal.put("lstFacturasSerie", WebUtils.getSessionAttribute(request, "lstFacturasSerie"));
                prmtVal.put("codTransaccion",
                        declaracionActual.get("COD_REGIMEN").toString().trim() + Constants.COD_TRANSAC_DILIGENCIADESPA);
                Declaracion decla = transformHelper.transform(prmtVal);
                // List lstValidacion = validaContingenteService.procesarDiligencia(decla);
                //RSV PAS20165E220200076
                Map<String, Object> variablesIngreso = new HashMap();

                variablesIngreso.put("codTransaccion",
                        declaracionActual.get("COD_REGIMEN").toString().trim() + Constants.COD_TRANSAC_DILIGENCIADESPA);

                List lstValidacion = validaContingenteService.procesarDiligencia(decla, variablesIngreso , 0);
                if (lstValidacion == null || lstValidacion.size() == 0)
                {
                    declaracionActual.putAll(dataForm);
                    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
                    //Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                    if (CollectionUtils.isEmpty(lstDetDeclaraActual)){
                        cargarSeriesSesion(request);
                    }

                    // Cargamos los datos adicionales (regimenes de precedencia) de la
                    // serie
                    Map<String, Object> params = new HashMap();
                    params.put("lstDetDeclaraActual", lstDetDeclaraActual);
                    params.put("lstDetDeclara",
                            (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclara"));
                    serieService.cargarSubElementosSerie(params);
                    WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclaraAnt); // se cambia por que se esta chancando las series que vienen de base de datos
                    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", params.get("lstDetDeclaraActual"));
                    String resultadoAduanaDestinoMercancia = SunatStringUtils.toStringObj(WebUtils.getSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia"));
                    resValidacion = validarDiligenciaAduanaDestino(declaracionActual,resultadoAduanaDestinoMercancia );
                    String ctacte = (String) declaracionActual.get("NUM_CTACTE")!=null?(String)declaracionActual.get("NUM_CTACTE"):"";
                    Date fechaDeclaracion = (Date) declaracionActual.get("FEC_DECLARACION");
                    Date fechaDocumentoRecFisico = (Date) (declaracionActual.get("fechaDocumentoRecFisico")!=null? declaracionActual.get("fechaDocumentoRecFisico"): SunatDateUtils.getDefaultDate());
                    String validarPlazo = validarPlazoReconocimientoFisico(declaracionActual.get("COD_ADUANA").toString(), declaracionActual.get("COD_REGIMEN").toString(),declaracionActual.get("ANN_PRESEN").toString(),declaracionActual.get("NUM_DECLARACION").toString(),fechaDeclaracion,ctacte,fechaDocumentoRecFisico,varfechaDiligencia);
                    res.addObject("validacion",resValidacion);
                    res.addObject("validarPlazo",validarPlazo);
                    if(resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO)){
                        res.addObject("resultadoMercancia","MERCANCIA NO LLEGO A DESTINO");
                    }
                    else if(resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO)){
                        res.addObject("resultadoMercancia","CONFORME");
                    }
                    else if(resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO)){
                        res.addObject("resultadoMercancia","MERCANC�A LLEG� PARCIALMENTE A DESTINO");
                    }
                    WebUtils.setSessionAttribute(request, "resultadoDiligenciaAduanaDestino",  resultadoAduanaDestinoMercancia);
                }
                else
                {
                    res.addObject("recOk", false);
                    res.addObject("resValidacion", SojoUtil.toJson(lstValidacion));
                }
            }
            else
            {
                MensajeBean rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajeerror(resValidacion);
                rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
                log.error(this.toString() + " evalEjecVerificacion - ERROR : " + resValidacion);
                res.addObject("beanM", rBean);
            }
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        finally
        {
            return res;
        }

    }
    /**
     * Metodo que permite cargar en Session las series de determinada DUA.
     *
     * @param request
     *          the request
     */
    private void cargarSeriesSesion(HttpServletRequest request)
    {
        // Cargamos las series en sesion
        List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                "lstDetDeclaraActual");

        if (CollectionUtils.isEmpty(lstDetDeclara))
        { // si esta vacio o null obtener de BD
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, String> params = new HashMap<String, String>();
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString().trim());
            params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString().trim());
            params.put("cod_aduana", declaracion.get("COD_ADUANA").toString().trim());
            params.put("ann_presen", declaracion.get("ANN_PRESEN").toString().trim());
            params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString().trim());
            params.put("acceso", "");
            lstDetDeclara = serieService.obtenerListadoSeries(params);

            WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
            List lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
            lstDetDeclaraActual = Utilidades.copiarLista((List) lstDetDeclara);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
        }
    }



    /**
     * Metodo que permite Validar el Incentivo migratorio.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView validaIncentivoMigrat(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            res.addObject("res", this.procesaValidacionIncentivoMigrat(request, response));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }

    /**
     * Metodo que procesa la validacion de incentivo Migratorio.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesaValidacionIncentivoMigrat(HttpServletRequest request, HttpServletResponse response)
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map params = new HashMap();
        params.put("caduana", soporteService.obtenerAduana(request));
        params.put("IND_ACOGCODLIBER",
                StringUtils.defaultIfEmpty(webRequest.getParameter("ind_acogcodliber"), Constantes.FLAG_INDICADOR_DESMARCADO));
        params.put("COD_EXONMERC", webRequest.getParameter("cod_exonmerc"));
        params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        params.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
        params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
        params.put("CODI_ADUAN", declaracion.get("COD_ADUANA"));
        params.put("CTIPODOC", declaracion.get("COD_TIPDOC_PIM"));
        params.put("CDOCUMEN", declaracion.get("NUM_DOCIDENT_PIM"));
        params.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));
        return this.validaDiligenciaService.validaIncentivoMigrat(params);
    }

    /**
     * Metodo que permite procesar la validacion de TPN ...
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionTPN212_208(HttpServletRequest request, HttpServletResponse response)
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map params = new HashMap();
        params.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
        params.put("CTIPODOC", declaracion.get("COD_TIPDOC_PIM"));
        params.put("CDOCUMEN", declaracion.get("NUM_DOCIDENT_PIM"));
        params.put("FEC_EVAL", declaracion.get("FEC_DECLARACION"));
        params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
        params.put("TLIB", webRequest.getParameter("cod_tipconvenio"));
        params.put("CLIB", webRequest.getParameter("cod_convenio"));
        return this.validaDiligenciaService.validaTPN212_208(params);
    }

    /**
     * Metodo que Valida la Ultractividad Fec.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionUltractividadFec(HttpServletRequest request, HttpServletResponse response)
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map params = new HashMap();
        params.put("COD_ULTRACTIVIDAD", webRequest.getParameter("cod_ultractividad"));
        params.put("FEC_CARCR", declaracion.get("FEC_CARCR"));
        params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
        return this.validaDiligenciaService.validaUltractividadFec(params);
    }

    /**
     * Valida Ultractividad precedente.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView validarUltractividadPrece(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            res.addObject("res", this.procesarValidacionUltractividadPrece(request, response));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;

    }

    /**
     * Metodo procesa laultractividad Precedente.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionUltractividadPrece(HttpServletRequest request, HttpServletResponse response)
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map params = new HashMap();
        params.put("COD_ULTRACTIVIDAD", webRequest.getParameter("cod_ultractividad"));
        params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        params.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
        params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
        return this.validaDiligenciaService.validaUltractividadPrece(params);
    }

    /**
     * Metodo que valida TLC.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionTLC(HttpServletRequest request, HttpServletResponse response)
    {
        String res = "";
        ServletWebRequest webRequest = new ServletWebRequest(request);
        if (!SunatStringUtils.isEmpty(webRequest.getParameter("cod_tipconvenio_tpi").trim()))
        {
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(
                    request,
                    "mapCabDeclaraActual");

            FechaBean fechaBean = new FechaBean((java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
            params.put("caduana", mapCabDeclara.get("COD_ADUANA"));
            params.put("NUM_PARTNANDI", request.getParameter("num_partnandi"));
            params.put("FEC_DECLARACION", fechaBean.getFormatDate("yyyyMMdd"));
            params.put("TLIB", "I");
            params.put("CLIB", webRequest.getParameter("cod_tipconvenio_tpi"));

            params.put("COD_PAISORIGEN", webRequest.getParameter("cod_paisorigen"));
            params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
            res = this.validaDiligenciaService.validarTLC(params);
        }
        return res;
    }



    /**
     * Metodo que procesa la validacion de la Mercancia de Ayuda Humanitaria.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionMercAyudaHuman(HttpServletRequest request, HttpServletResponse response)
    {
        String res = "";
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map params = new HashMap();
        params.put("COD_PART", webRequest.getParameter("num_parnabandina"));
        params.put("COD_TIPTRATMERC", declaracion.get("COD_TIPTRATMERC"));
        params.put("FEC_EVAL", new FechaBean((Timestamp) declaracion.get("FEC_DECLARACION")).getFormatDate("yyyyMMdd"));
        params.put("caduana", soporteService.obtenerAduana(request));
        res = this.validaDiligenciaService.validarMercAyudaHuman(params);
        return res;
    }

    /**
     * Metodo que agrega alerta.
     *
     * @param lstAlertas
     *          the lst alertas
     * @param alerta
     *          the alerta
     */
    private void agregarAlerta(List lstAlertas, String alerta)
    {
        if (!"".equals(alerta.trim()))
        {
            Map res = new HashMap();
            res.put(ResponseMapManager.KEY_CODIGO, "");
            res.put(ResponseMapManager.KEY_DESCRIPCION, alerta);
            res.put(ResponseMapManager.KEY_TIPO_ALERTA, ResponseMapManager.VALUE_TIPO_ALERTA_ERROR);
            lstAlertas.add(res);
        }
    }

    /**
     * Metodo que valida la Grabacion de Series.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the list
     */
    private List validaGrabacionSeries(HttpServletRequest request, HttpServletResponse response)
    {
        List res = new ArrayList();


        this.agregarAlerta(res, this.procesaValidacionIncentivoMigrat(request, response));

        this.agregarAlerta(res, this.procesarValidacionTPN212_208(request, response));

        this.agregarAlerta(res, this.procesarValidacionUltractividadFec(request, response));

        this.agregarAlerta(res, this.procesarValidacionUltractividadPrece(request, response));

        //RIN08
        Map<String, Object> requestParameterMap = new HashMap<String, Object>();
        requestParameterMap.putAll(request.getParameterMap());


        //int tipoConvDecSerModif=this.tipoConvenioDeclaracionSerieModificada(requestParameterMap).intValue();

        //if (tipoConvDecSerModif!=1 &&  tipoConvDecSerModif!=3) {
        // this.agregarAlerta(res, this.procesarValidacionTLC(request, response));
        //}


        List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
        String numSerie=request.getParameter("hdn_num_secserie");
        Map<String, Object> mapSerie;

        for (int i = 0; i < lstDetDeclaraAnt.size(); i++) {
            mapSerie = lstDetDeclaraAnt.get(i);
            if (mapSerie.get("NUM_SECSERIE").toString().equals(numSerie)){
                if ( Double.parseDouble(mapSerie.get("CNT_COMER").toString())< Double.parseDouble(request.getParameter("cnt_comer")) ||
                        Double.parseDouble(mapSerie.get("CNT_BULTO").toString())< Double.parseDouble(request.getParameter("cnt_bulto")) ||
                        Double.parseDouble(mapSerie.get("CNT_PESO_NETO").toString())< Double.parseDouble(request.getParameter("cnt_peso_neto"))||
                        Double.parseDouble(mapSerie.get("CNT_PESO_BRUTO").toString())< Double.parseDouble(request.getParameter("cnt_peso_bruto")) ||
                        Double.parseDouble(mapSerie.get("CNT_UNIFIS").toString())< Double.parseDouble(request.getParameter("cnt_unifis"))
                ){
                    this.agregarAlerta(res, "Las cantidades, pesos o bultos deben ser menores o iguales a los declarados en la serie antes de la diligencia en aduana de destino");
                    break;

                }
            }

        }

        //FIN

        this.agregarAlerta(res, this.procesarValidacionMercAyudaHuman(request, response));

        // Agregamos las validaciones de seida
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        Map prmtVal = new HashMap();
        prmtVal.put("mapCabDeclara", declaracionActual);

        prmtVal.put("lstDocuPreceDua", WebUtils.getSessionAttribute(request, "lstDocuPreceDua"));
        prmtVal.put("lstFacturasSerie", WebUtils.getSessionAttribute(request, "lstFacturasSerie"));
        prmtVal.put("codTransaccion", declaracionActual.get("COD_REGIMEN").toString().trim() + "01");

        this.agregarAlerta(res, this.procesarValidacionMtoFleteCeroTipoProrrateo01(request, response));

        return res;
    }

    /**
     * valida el monto del flete acumulado de la series activas sea igual a la
     * cabecera de no ser iguales muestra la diferencia y no permite grabar la
     * serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionMtoFleteCeroTipoProrrateo01(HttpServletRequest request, HttpServletResponse response)
    {

        Map<String, Object> requestParameterMap = new HashMap<String, Object>();

        requestParameterMap.putAll(request.getParameterMap());

        // monto_flete modificados
        double mtoFleteDolModificada = Double.valueOf(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("mto_fletedol")));
        String codTipFleteModificada = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipflete"));

        String msgValidacionFlete = "";
        String IND_REGISTRO_PENDIENTE = "1"; // nuevos serie agregada y pendientes
        // de grabado
        List<Map<String, Object>> lstDetDeclaraActual = new ArrayList<Map<String, Object>>();

        // obtiene los datos de la session
        lstDetDeclaraActual = (List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        if (CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            cargarSeriesSesion(request);
        }

        lstDetDeclaraActual = (List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclaraActualCopia = new ArrayList<Map<String, Object>>();
        lstDetDeclaraActualCopia.addAll(Utilidades.copiarLista((List) lstDetDeclaraActual));

        if (!CollectionUtils.isEmpty(lstDetDeclaraActualCopia))
        {

            Map mapSerie;
            int contadorNuevos = 0;
            for (int i = 0; i < lstDetDeclaraActualCopia.size(); i++)
            {

                mapSerie = (HashMap) lstDetDeclaraActualCopia.get(i);

                // muestra el mensaje de validacion para cuando se adiciona una serie ya
                // sea que esta este pendiente de grabado como cuando
                // ya fue agregado y sale como adicionado
                if (mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE)
                        || mapSerie.get("IND_DESCMANTSERIE").toString().equals("1"))
                {
                    contadorNuevos++;
                }
            }

            if (contadorNuevos > 0 && ArrayUtils.contains(new String[]{ "1" }, codTipFleteModificada) && mtoFleteDolModificada <= 0)
            { // solo valida si hay nuevos registros
                msgValidacionFlete = "Advertencia: Tipo de flete 01:NO prorrateable. Registre el monto del flete de la presente serie.";
            }
        }

        return msgValidacionFlete;
    }

    /**
     * valida el monto del flete acumulado de la series activas sea igual a la
     * cabecera de no ser iguales muestra la diferencia y no permite grabar la
     * serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the string
     */
    private String procesarValidacionMtoFlete(HttpServletRequest request, HttpServletResponse response)
    {

        Map<String, Object> requestParameterMap = new HashMap<String, Object>();

        requestParameterMap.putAll(request.getParameterMap());

        // monto_flete modificados
        String numSecSerieModificada = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("hdn_num_secserie"));

        double mtoFleteDolModificada = Double.valueOf(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("mto_fletedol")));

        String msgValidacionFlete = "";
        String IND_REGISTRO_PENDIENTE = "1"; // nuevos serie agregada y pendientes
        // de grabado
        List<Map<String, Object>> lstDetDeclaraActual = new ArrayList<Map<String, Object>>();

        // obtiene los datos de la session
        lstDetDeclaraActual = (List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        if (CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            cargarSeriesSesion(request); // cargamos de BD
        }

        lstDetDeclaraActual = (List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        List<Map<String, Object>> lstDetDeclaraActualCopia = new ArrayList<Map<String, Object>>();

        lstDetDeclaraActualCopia.addAll(Utilidades.copiarLista((List) lstDetDeclaraActual));

        if (!CollectionUtils.isEmpty(lstDetDeclaraActualCopia) && !CollectionUtils.isEmpty(declaracion))
        {

            Map mapSerie;
            double dbl_mto_fletedol = 0;
            int contadorNuevos = 0;
            for (int i = 0; i < lstDetDeclaraActualCopia.size(); i++)
            {

                mapSerie = (HashMap) lstDetDeclaraActualCopia.get(i);

                if (numSecSerieModificada.equals(mapSerie.get("NUM_SECSERIE").toString()))
                {
                    mapSerie.put("MTO_FLETEDOL", mtoFleteDolModificada);
                }
                // solo considero series activas
				/*        if ((Integer.parseInt(mapSerie.get("IND_DEL").toString())) == 0
            || mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE))*/
                if ( (((Integer.parseInt(mapSerie.get("IND_DEL").toString())) == 0
                        || mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE))
                        && "1".equals(Utilidades.validarNuloOVacioRetornaString(mapSerie.get("IND_DECLARACION_FORMATOB"))))
                        || !Utilidades.esUnaRegistroMarcadaParaEliminar(mapSerie))
                {

                    dbl_mto_fletedol = dbl_mto_fletedol + Double.valueOf(mapSerie.get("MTO_FLETEDOL").toString());
                }
                // muestra el mensaje de validacion para cuando se adiciona una serie ya
                // sea que esta este pendiente de grabado como cuando
                // ya fue agregado y sale como adicionado
                if (mapSerie.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE)
                        || mapSerie.get("IND_DESCMANTSERIE").toString().equals("1"))
                {
                    contadorNuevos++;
                }
            }

            if (contadorNuevos > 0)
            {
                double mtoFleteDolDeclaracion = Double.valueOf(declaracion.get("MTO_TOTFLETEDOL").toString());

                double dif_mto_fletedol = mtoFleteDolDeclaracion - dbl_mto_fletedol;
                BigDecimal bd_dif_mto_fletedol = new BigDecimal(dif_mto_fletedol);
                bd_dif_mto_fletedol = SunatNumberUtils.scaleHalfUp(bd_dif_mto_fletedol, 3);


                String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
                double diferenciaMaximaMonto;
                double diferenciaMaximaPeso;
                double diferenciaMaximaCantidad;

                if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia))
                {
                    diferenciaMaximaMonto = Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO);
                    diferenciaMaximaPeso = Double.valueOf(Constantes.DIFERENCIA_MAX_PESO);
                    diferenciaMaximaCantidad = Double.valueOf(Constantes.DIFERENCIA_MAX_CANTIDAD);
                }
                else
                {
                    diferenciaMaximaMonto = Double.valueOf(Constantes.DIF_MAX_MTO);
                    diferenciaMaximaPeso = Double.valueOf(Constantes.DIF_MAX_PESO);
                    diferenciaMaximaCantidad = Double.valueOf(Constantes.DIF_MAX_CANT);

                }
                String correlacion = "";
                if(declaracion.get("IND_FORMBPROVEEDOR")!= null && "0".equals(declaracion.get("IND_FORMBPROVEEDOR").toString())){
                    correlacion = "correlacionadas";
                }
                if (Math.abs(dif_mto_fletedol) > diferenciaMaximaMonto)
                {
                    StringBuilder res = new StringBuilder("");
                    res.append("Advertencia: Monto de Flete de la Declaracion: ")
                            .append(
                                    SunatNumberUtils.scaleHalfUp(new BigDecimal(mtoFleteDolDeclaracion), 3));
                    res.append(" Sumatoria de monto de Flete de las Series ").append(correlacion)
                            .append(":")
                            .append(
                                    SunatNumberUtils.scaleHalfUp(new BigDecimal(dbl_mto_fletedol), 3));
                    res.append("\nHay una diferencia de: ").append(bd_dif_mto_fletedol);

                    msgValidacionFlete = res.toString();
                }
            }
        }

        return msgValidacionFlete;

    }


    //P13 JMCV - INICIO
    /**
     * Metodo que valida el paso del estado de la DUA de Revision a en Proceso.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    //P13 F2 JMCV - INICIO
    public ModelAndView validaFromRevisionToProceso(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            String validacion = this.declaracionService.validarFechaRecepcion(mapCabDeclaraActual);

            if (StringUtils.EMPTY.equals(validacion)){
                //P13 F2 JMCV - INICIO
                validacion = diligenciaService.validarRevisionToProcesoDeInmovilizacionTotalDeLaMercancia(mapCabDeclaraActual);
                //P13 F2 JMCV - FIN
            }
            res.addObject("res", validacion);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }
    //P13 JMCV - FIN


    /**
     * Metodo que obtiene las ferias a partir del hdn_dato_eval que debe poseer el
     * codigo de feria.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView obtenerFeriaDesc(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            Map params = new HashMap();
            params.put("COD_FERIA", request.getParameter("hdn_dato_eval"));
            res.addObject("res", this.declaracionService.obtenerFeriaDesc(params));
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }

    /**
     * Metodo que valida el Grabacdo de las Series.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validaGrabarSerie(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        List validacion = this.validaGrabacionSeries(request, response);
        if (CollectionUtils.isEmpty(validacion))
        {
            WebUtils.setSessionAttribute(request, "resValidacion", null);
            String validaFleteAviso = this.procesarValidacionMtoFlete(request, response);
            if (!"".equals(validaFleteAviso))
            {
                res.addObject("valido", "2");
                res.addObject("mensaje", validaFleteAviso);
            }
            else
            {
                res.addObject("valido", "1");
            }
        }
        else
        {
            WebUtils.setSessionAttribute(request, "resValidacion", validacion);
            res.addObject("valido", "0");
        }

        //CU 14.20
        if(!res.getModel().get("valido").toString().equals("1") && !res.getModel().get("valido").toString().equals("2")){
            this.revertirCambiosListaSerieCorrelacion(request, response);

        }
        return res;
    }

    /**
     * Metodo que permite la carga de Alertas de la Validacion.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarAlertasValidacion(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        return new ModelAndView("destino/AlertaGrabacion", "data", SojoUtil.toJson(WebUtils.getSessionAttribute(
                request,
                "resValidacion") != null ? (ArrayList) WebUtils.getSessionAttribute(request, "resValidacion")
                : new ArrayList()));
    }

    /**
     * Metodo que limpia el resultado de la validacion en Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @throws Exception
     *           the exception
     */
    public void limpiarResValidacion(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        WebUtils.setSessionAttribute(request, "resValidacion", null);
    }

    /**
     * Metodo que carga la busqueda para los documentos de transporte.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarBusquedaDocuTrans(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView res = new ModelAndView("BuscarDocTransporte");
        Map mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        StringBuffer manifiesto = new StringBuffer(mapCabDeclaraActual.get("COD_ADUANA").toString().trim())
                .append("-")
                .append(mapCabDeclaraActual.get("ANN_PRESEN").toString().trim())
                .append("-")
                .append(mapCabDeclaraActual.get("NUM_MANIFIESTO").toString().trim());

        res.addObject("manifiesto", manifiesto.toString());
        res.addObject("num_manifiesto", mapCabDeclaraActual.get("NUM_MANIFIESTO").toString().trim());
        return res;
    }

    /**
     * Metodoque realiza la busqueda de Documentos de Transporte.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView buscarDocuTrans(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            Map params = new HashMap();
            Map mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            params.put("numeroManifiesto", String.format("%1$6s", mapCabDeclaraActual.get("NUM_MANIFIESTO").toString()));

            List lstDocuTrans = this.soporteService.listarDocuTrans(params);

            res.addObject("listarDocuTrans", lstDocuTrans);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }

    /**
     * Permite mostrar pantalla de Busqueda de Declaracion para la Consulta de la
     * DUA y la Diligencia de Despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarBusqDeclaracion(HttpServletRequest request, HttpServletResponse response)
    {

        try
        {

            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            if(userSession!=null){
                userSession.setNroRegistro(userSession.getNroRegistro().trim());
                WebUtils.setSessionAttribute(request, "usuarioBean", userSession);
            }

            if (userSession == null)
            {
                return new ModelAndView("PagM", "message", "Usuario no logueado");
            }

            Utilidades.inicializarMapasSesion(request);
            UserNameHolder.set(userSession.getNroRegistro(), request.getRemoteAddr());

            String codAduanaUsuario = soporteService.obtenerAduana(request);

            ServletWebRequest webRequest = new ServletWebRequest(request);
            String codAduana = webRequest.getParameter("codAduana") != null ? webRequest.getParameter("codAduana") : codAduanaUsuario;
            String annPresen = webRequest.getParameter("annPresen") != null ? webRequest.getParameter("annPresen") : String
                    .valueOf(Calendar.getInstance().get(Calendar.YEAR));
            String codRegimen = webRequest.getParameter("codRegimen") != null ? webRequest.getParameter("codRegimen") : "";
            String numDeclaracion = webRequest.getParameter("numDeclaracion") != null ? webRequest
                    .getParameter("numDeclaracion") : "";
            Map<String, String> params = new HashMap<String, String>();

            String[] aduanasPecoLeyAmazonia = Constantes.LISTA_ADUANAS_PECO_LEY_AMAZONIA; //peco y/o ley amazonia aduana de destino
            if(!ArrayUtils.contains(aduanasPecoLeyAmazonia, codAduanaUsuario)){

                MensajeBean rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajesol("La Aduana del Usuario no corresponde para los casos de Peco y/o Ley Amazonia");
                ModelAndView res = new ModelAndView("PagM");
                res.addObject("beanM",rBean);
                return res;
                //return new ModelAndView("PagM", "Error", rBean);
            }

            params.put("cod_aduana", codAduana);
            params.put("ann_presen", annPresen);
            params.put("cod_regimen", codRegimen);
            params.put("num_declaracion", numDeclaracion);
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("numPase", Constantes.NUM_PASE);

            ModelAndView res = new ModelAndView("destino/BusqDeclaracion");
            res.addObject("params", params);
            res.addObject("lstRegimenes", catalogoAyudaService.getListaElementosGrupo("100"));

            List<Map<String, String>> lstAduana = catalogoAyudaService.getListaElementosGrupo("139");
            for (Map<String, String> map : lstAduana)
            {
                map.put("cod_des_corta", ((String) map.get("cod_datacat")).concat("-").concat((String) map.get("des_corta")));
                if (((String) map.get("cod_datacat")).equals(codAduana))
                {
                    params.put("des_aduana", (String) map.get("des_corta"));
                }
            }
            res.addObject("lstAduana", SojoUtil.toJson(lstAduana));

            return res;

        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "Error", rBean);
        }
    }



    /**
     * Grabar modificacion diligencia.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView grabarModificacionDiligencia(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String numCorreDoc = request.getParameter("numCorreDoc") != null ? request.getParameter("numCorreDoc") : " ";
        String resultado = request.getParameter("resultado") != null ? request.getParameter("resultado") : " ";
        String cntBultos = request.getParameter("cntBultos") != null ? request.getParameter("cntBultos") : "0";

        ModelAndView res = new ModelAndView(this.jsonView);

        Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
        paramsDiligencia.put("NUM_CORREDOC", numCorreDoc);
        paramsDiligencia.put("COD_TIPDILIGENCIA", new String[]
                { Constantes.DILIG_ADUANA_DESTINO });
        // en este caso no se necesita pasar el mapa de la declaracion pq obtiene
        // los datos solo de la diligencia
        Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(
                paramsDiligencia,
                new HashMap());
        //rin08
        String resultadoDilig=((String)WebUtils.getSessionAttribute(request,"estadoResultadoAduanaDestinoMercancia")).concat( ":").concat(
                (String)WebUtils.getSessionAttribute(request,"resultadoAduanaDestinoMercancia")).concat("\n").concat(resultado);
        mapUltimaDiligencia.put("DES_RESULTADO", resultadoDilig);
        //end
        //mapUltimaDiligencia.put("DES_RESULTADO", resultado);
        mapUltimaDiligencia.put("CNT_BULTOSRECON", cntBultos);
        mapUltimaDiligencia.put(
                "NUM_CORREDOC_SOL",
                Long.parseLong(mapUltimaDiligencia.get("NUM_CORREDOC_SOL").toString()) + 1);

        try
        {
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro());
            diligenciaService.grabarModificacionDiligencia(mapUltimaDiligencia);
            /*SE GRABA LOS DATOS DE NOTA DE CREDITO PAS20181U220200069*/
//            SolicitudPecoService solicitudPecoService = fabricaDeServicios.getService("tramite.SolicitudPecoService");
//            solicitudPecoService.insert(dipolsolpeco);

            res.addObject("recOK", true);
        }
        catch (Exception e)
        {

            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }

    /**
     * Verifica si tiene registrado una diligencia de despacho
     *
     * invocacion: Ajax desde BusqDdeclaracion.jsp
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarExisteDiligencia(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        Utilidades.limpiarMapasSesion(request);

        Map<String, Object> params = new HashMap<String, Object>();

        // obtener correlativo de la DUA
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        params.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
        params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
        params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
        params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
        params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
        params.put("COD_TIPDILIGENCIA",  Constantes.DILIG_ADUANA_DESTINO);

        Object objRes = null;
        String objName = "validaActualizacionMap";
        try
        {
            Map<String,Object> declaracion = declaracionService.obtenerDeclaracion(params);

            if(declaracion != null ){
                params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
                params.put("FEC_CONCLUSION", declaracion.get("FEC_CONCLUSION"));
                Map<String,Object> validaActualizacion = diligenciaService.validarActualizacionDestino(params);
                if((Boolean)validaActualizacion.get("regOK")){
                    WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
                    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracion);//P24-PAS20165E220200099
                    WebUtils.setSessionAttribute(request, "cabDiligenciaActualizar", (Map)validaActualizacion.get("CAB_DILIGENCIA"));
                }
                objName = "validaActualizacion";
                objRes = validaActualizacion;

            }

        } catch (DiligenciaException e){
            log.error("*** error validarExisteDiligencia ***", e);
            objRes = "Ocurrio un error por facor comuniquese con el administrador.";
            objName = "msjError";
        }
        return new ModelAndView(this.jsonView,objName, objRes);
    }

    /**
     * Validar medida preventiva.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarMedidaPreventiva(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

        Map<String, Object> mapParametros = new HashMap<String, Object>();
        mapParametros.put("NUM_CORREDOC",
                mapCabDeclara.get("NUM_CORREDOC") != null ? mapCabDeclara
                        .get("NUM_CORREDOC")
                        .toString() : " ");
        mapParametros.put(
                "COD_ADUAMANIFIESTO",
                mapCabDeclara.get("COD_ADUAMANIFIESTO") != null ? mapCabDeclara.get("COD_ADUAMANIFIESTO").toString() : " ");
        mapParametros.put(
                "ANN_MANIFIESTO",
                mapCabDeclara.get("ANN_MANIFIESTO") != null ? mapCabDeclara.get("ANN_MANIFIESTO").toString() : " ");
        mapParametros.put(
                "NUM_MANIFIESTO",
                mapCabDeclara.get("NUM_MANIFIESTO") != null ? mapCabDeclara.get("NUM_MANIFIESTO").toString() : " ");
        mapParametros.put("COD_VIATRANS", mapCabDeclara.get("COD_VIATRANS") != null ? mapCabDeclara
                .get("COD_VIATRANS")
                .toString() : " ");
        mapParametros.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA") != null ? mapCabDeclara
                .get("COD_ADUANA")
                .toString() : " ");
        mapParametros.put("COD_REGIMEN", mapCabDeclara.get("COD_REGIMEN") != null ? mapCabDeclara
                .get("COD_REGIMEN")
                .toString() : " ");
        mapParametros.put("ANN_PRESEN", mapCabDeclara.get("ANN_PRESEN") != null ? mapCabDeclara
                .get("ANN_PRESEN")
                .toString() : " ");
        mapParametros.put(
                "NUM_DECLARACION",
                mapCabDeclara.get("NUM_DECLARACION") != null ? mapCabDeclara.get("NUM_DECLARACION").toString() : " ");

        Map<String, Object> mapAces = declaracionService.obtenerACE(mapParametros);

        return new ModelAndView(this.jsonView, "mapAces", mapAces);

    }

    /**
     * Valida la dua bajo ciertas condiciones si es factible modificar la
     * diligencia de despacho.
     *
     * invocacion: Ajax desde BusqDdeclaracion.jsp
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return model and view
     * @throws Exception
     *           the exception
     */
    @Deprecated
    public ModelAndView validarDUAParaModificacionDiligencia(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        String numCorreDoc = request.getParameter("numCorreDoc");
        Map<String, Object> mapCabDeclara = null;

        Map<String, Object> mapPrimeraDiligencia = declaracionService.obtenerPrimeraDiligencia(numCorreDoc);

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
        params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
        params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
        params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
        params.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());
        params.put("FEC_DILIGENCIA", mapPrimeraDiligencia.get("FEC_REGIS"));

        mapCabDeclara = declaracionService.validaModificacionDiligencia(params);
        WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
        Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
        mapCabDeclaraActual.putAll(mapCabDeclara);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);

        return new ModelAndView(this.jsonView, "mapCabDeclaraActual", mapCabDeclaraActual);
    }



    /**
     * Metodo que valida la Declaracion de Despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarDeclaracionDespacho(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {


        Utilidades.limpiarMapasSesion(request);

        ModelAndView modelView = new ModelAndView();
        Map<String, Object> params = new HashMap<String, Object>();
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
        params.put("codigoFuncionario", bUsuario.getNroRegistro());
        params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
        params.put("ann_presen", request.getParameter("txt_ann_presen"));
        params.put("cod_regimen", request.getParameter("sel_cod_regimen"));
        params.put("des_regimen", request.getParameter("hdn_des_regimen"));
        params.put("num_declaracion", request.getParameter("txt_num_declaracion"));

        params.put("acceso", request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "");
        Map<String, Object> mapCabDeclara = null;
        mapCabDeclara = declaracionService.validarDeclaParaDespachoAduanaDestino(params);
        /* olunar 309 - Obtener DUA en objetos */
        DUA dua = getDeclaracionService.getCabDUA(params.get("cod_aduana").toString(), params.get("num_declaracion").toString(), params.get("ann_presen").toString(), params.get("cod_regimen").toString());
        WebUtils.setSessionAttribute(request, "dua", dua);
        /* fin */
        WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
        Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
        mapCabDeclaraActual.putAll(mapCabDeclara);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
        modelView = new ModelAndView(this.jsonView, "mapCabDeclaraActual", mapCabDeclaraActual);
        return modelView;
    }

    /**
     * Iniciar declaracion despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView iniciarDeclaracionDespacho(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        ModelAndView modelView = null;  /*Inicio PAS20165E220200099*/
        Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
        //String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
        //String acceso = "";
        //String modifDilig = request.getParameter("hdn_modifDilig") != null ? request.getParameter("hdn_modifDilig") : "";
        //acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

        /*Inicio PAS20165E220200099*/
        String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(mapCabDeclaraActual, DEFAULT_TIPO_DOC);
        WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
        /*Fin PAS20165E220200099*/
        modelView = cargaDeclaracion(request, response);
        return modelView;
    }

    public ModelAndView tieneDiligenciaDestino(HttpServletRequest request, HttpServletResponse response) throws Exception{
        ModelAndView res = new ModelAndView("jsonView");
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        Map<String, Object> declaracion = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclara");

        String mensaje="";
        if(declaracion.get("FLAG_NUMERO")=="N"){
            mensaje = "Diligencia de Aduana de Destino fue modificada anteriormente, s�lo puede modificarse una vez ";
            res.addObject( "mensaje", mensaje);
            return res;
        }
        if(declaracion.get("mensaje")!=""){
            mensaje = declaracion.get("mensaje").toString();
            return res;
        }

        if (!declaracion.get("codFunTextoModif").equals(bUsuario.getNroRegistro())) {
            ModelAndView resn = new ModelAndView(this.jsonView);
            mensaje = "Diligencia de Aduana de Destino s�lo puede ser modificada por el funcionario que la registr�";
            resn.addObject( "mensaje", mensaje);
            return res;
        }
        res.addObject( "mensaje", "OK");
        return res;
    }

    /**
     * Metodo que realiza el cambio de estado en la DUA a "En proceso".
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView revisionToProceso(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        ModelAndView modelView = null;
        Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,
                "mapCabDeclaraActual");
        String codigoEstadoDUA = (String) mapCabDeclaraActual.get("COD_ESTDUA");
        if (Constantes.ESTADO_DECLARACION_REVISION.equals(codigoEstadoDUA))
        {
            modelView = this.cargaDeclaracion(request, response);
        }
        else
        {
            modelView = this.declaracionEnRevision(request, response);
        }
        return modelView;
    }

    /**
     * Metodo que obtiene el listado de Series invocado se la opcion se Series de
     * la consulta de DUA acceso="00".
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerListadoSeries(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        HttpSession session = request.getSession();
        Map<String, String> params = new HashMap<String, String>();
        try
        {
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
            params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
            params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
            params.put("ann_presen", request.getParameter("hdn_ann_presen"));
            params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
            params.put("acceso", request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "");
            Map<String, Object> mapCabDeclara = (Map<String, Object>) session.getAttribute("mapCabDeclaraActual");
            request.setAttribute("params", params);
            // Para Declaracion en Proceso se filtran las Series
            params.put("estadoDUA", mapCabDeclara.get("COD_ESTDUA").toString());

            String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
            if ("10".equals(tipoDiligencia))
            {
                if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                        && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
                {
                    params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
                }

            }

            List lstDetDeclara = serieService.obtenerListadoSeries(params);
            session.setAttribute("lstDetDeclara", lstDetDeclara);
            List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual");
            if (CollectionUtils.isEmpty(lstDetDeclaraActual))
            {

                List<Map<String, Object>> lstDetDeclaraActualTmp = new ArrayList<Map<String, Object>>();
                lstDetDeclaraActualTmp = Utilidades.copiarLista(lstDetDeclara);
                /*RIN13FSW-INICIO*/
                /*jlunah*/
                for(Map <String,Object> serieDet : lstDetDeclaraActualTmp ){
                    //serieDet.put("OBSERVACION", "observacion por defecto");
                    serieDet.put("OBSERVACION", serieDet.containsKey("OBS_SERIE") == true ? serieDet.get("OBS_SERIE") : ""); //RIN08 AGREGO serieDet.containsKey("obs_serie") == true ? serieDet.get("obs_serie") : ""
                }
                /*fin*/
                /*RIN13FSW-FIN*/
                session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActualTmp);
                lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
                lstDetDeclaraActual.addAll(lstDetDeclaraActualTmp);

            }

            // tiene formato B,seteando los datos en session de la serie-item y
            // item-factura
            //if (mapCabDeclara.get("IND_FORMBPROVEEDOR").equals("0"))
            if (mapCabDeclara.get("IND_FORMBPROVEEDOR") != null && mapCabDeclara.get("IND_FORMBPROVEEDOR").equals("0"))
            {
                Map<String, Object> param = new HashMap<String, Object>();
                param.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
                List lstSeriesItem = serieService.obtenerSeriesItem(param);
                session.setAttribute("lstSeriesItem", lstSeriesItem);
                List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                        request,
                        "lstSeriesItemActual");
                if (CollectionUtils.isEmpty(lstSeriesItemActual))
                {
                    lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
                    session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
                }
                List lstItemFactura = declaracionService.obtenerItemFactura(param);
                session.setAttribute("lstItemFacturaActual", lstItemFactura);
                /**Inicio de cambios P24 -bug24642***/
                List lstItemVehic = new ArrayList<Map<String, Object>>();


                if(!CollectionUtils.isEmpty(lstItemFactura)){
                    for(int j=0; j<lstItemFactura.size(); j++){
                        Map<String,Object> mapDatosVehic = new HashMap<String, Object>() ;
                        Map<String, Object> mapItemFactura=	(Map<String, Object>) lstItemFactura.get(j);
                        String descripcion =  mapItemFactura.get("COD_TIPDESCRMIN")!=null?mapItemFactura.get("COD_TIPDESCRMIN").toString():" ";
                        if("01".equals(descripcion)){//es vehiculos
                            mapDatosVehic.put("NUM_SECITEM", mapItemFactura.get("NUM_SECITEM"));
                            mapDatosVehic.put("ANN_FABRICACION", mapItemFactura.get("ANN_FABRICACION"));
                        }
                        if(!CollectionUtils.isEmpty(mapDatosVehic)){
                            lstItemVehic.add(mapDatosVehic);
                        }
                    }
                }
                /**Fin de cambios P24 -bug24642***/

                /**Inicio de cambios P24 -bug24639***/
                for (Map<String , Object> map : lstDetDeclaraActual){
                    int totalItemsSerie = 0;
                    String ann_fabric = "0";
                    ArrayList<String> lstItemsSerie;
                    String num_serie =  map.get("NUM_SECSERIE").toString();
                    if(!CollectionUtils.isEmpty(lstSeriesItem)){
                        for (int i=0 ; i <lstSeriesItem.size(); i++){
                            Map<String, Object> mapSerieItem=	(Map<String, Object>) lstSeriesItem.get(i);
                            String num_secSerie = mapSerieItem.get("NUM_SECSERIE").toString();
                            String num_secItem = mapSerieItem.get("NUM_SECITEM").toString();
                            if(num_serie.equals(num_secSerie)){
                                totalItemsSerie=totalItemsSerie+1;
                                if(!CollectionUtils.isEmpty(lstItemVehic)){
                                    for(int j=0; j<lstItemVehic.size(); j++){
                                        Map<String, Object> mapItemVehic =	(Map<String, Object>) lstItemVehic.get(j);
                                        String num_item = mapItemVehic.get("NUM_SECITEM").toString();
                                        if(num_secItem.equals(num_item)){
                                            ann_fabric = mapItemVehic.get("ANN_FABRICACION")!=null?mapItemVehic.get("ANN_FABRICACION").toString():"0";
                                            break;//solo hay un vehiculo por serie
                                        }
                                    }
                                }

                            }
                        }
                    }
                    map.put("tot_items", totalItemsSerie);
                    map.put("annFabricVehic",ann_fabric);
                } /**Fin de cambios P24 -bug24639***/
            }

            if (!("00".equals(params.get("acceso"))))
            {
                request.setAttribute("lstMonedas", catalogoAyudaService.getElementosCat("J1"));
                request.setAttribute("lstIncidadoresSENASA", catalogoAyudaService.getElementosCat("324"));
                request.setAttribute("lstExoneraciones", catalogoAyudaService.getElementosCat("18"));
                request.setAttribute("lstPaises", catalogoAyudaService.getElementosCat("J2"));
                request.setAttribute("lstUnidadesMedida", catalogoAyudaService.getElementosCat("29"));
                request.setAttribute("lstUnidadesMercancia", catalogoAyudaService.getElementosCat("16"));
                request.setAttribute("lstTiposMercanciaRestringida", catalogoAyudaService.getElementosCat("333"));
                request.setAttribute("lstUsosGuardiaCustodia", catalogoAyudaService.getElementosCat("326"));
                request.setAttribute("lstTiposDocSoporteAsociado", catalogoAyudaService.getElementosCat("367"));
                request.setAttribute("lstTiposProrrateoFlete", catalogoAyudaService.getElementosCat("368"));
                request.setAttribute("lstTiposConoSada", catalogoAyudaService.getElementosCat("TP"));

                // Obtener catalogo 25 y agregar el c�digo a la descripci�n
                List<Map<String, String>> lstEstadosMercancia = catalogoAyudaService.getElementosCat(
                        CATALOGO_ESTADO_MERCANCIA,
                        "cod_datacat");
                for (Map<String, String> estadoMerc : lstEstadosMercancia)
                {
                    estadoMerc.put("des_corta", estadoMerc.get("cod_datacat") + " " + estadoMerc.get("des_corta"));
                }

                request.setAttribute("lstEstadosMercancia", SojoUtil.toJson(lstEstadosMercancia));


                Map<String, Object> mapTabLibe = new HashMap<String, Object>();

                FechaBean fechaBean = new FechaBean((Timestamp) mapCabDeclara.get("FEC_DECLARACION"));

                mapTabLibe.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
                mapTabLibe.put("fechaDeclaracion", Long.valueOf(fechaBean.getFormatDate("yyyyMMdd")));
                mapTabLibe.put("tlib", "I");

                request.setAttribute("lstTPI", soporteService.obtenerTabLibeByParams(mapTabLibe));
                mapTabLibe.put("tlib", "T");

                request.setAttribute("lstTPN", soporteService.obtenerTabLibeByParams(mapTabLibe));
                mapTabLibe.put("tlib", "C");

                request.setAttribute("lstCodigoLiberatorio", soporteService.obtenerTabLibeByParams(mapTabLibe));
            }

            /*
             * solo para la consulta se verifica el historico de las series adicionadas
             * o eliminadas pero solo muestra la ultima para el caso de una seria
             * adicionada en P.A y despues eliminada muestra el evento mas reciente
             */
            if ("00".equals(params.get("acceso")))
            {

                String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();
                List<Map<String, Object>> listaSeriesADDyDEL = rectificacionService.obtenerDatosAnuladosOAdicionados(
                        numCorreDoc,
                        "T0052");

                // agrega la columna estado en la lista y la pone en session
                for (Map mapDatosModificados : listaSeriesADDyDEL)
                {
                    String numSecSerie = (String) mapDatosModificados.get("PK");

                    // agrego los campos a la serie
                    for (Map mapDetDeclaraActual : lstDetDeclaraActual)
                    {
                        if (numSecSerie.equals((mapDetDeclaraActual.get("NUM_SECSERIE").toString())))
                        {
                            mapDetDeclaraActual.putAll(mapDatosModificados);
                        }
                    }
                }
            }

            ModelAndView res;

            if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(getTipoDiligencia(request)))
            {



                if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                        && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
                {
                    //          lstDetDeclaraActual = Utilidades.quitarRegistrosMarcadaParaEliminar(lstDetDeclaraActual);//comentado por CU 14.16
                    Utilidades.removerRegistrosEliminadosPermanentemente(lstDetDeclaraActual);

                    Ordenador.sortDesc(lstDetDeclaraActual, "NUM_SECSERIE", Ordenador.ASC);
                    session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);
                }

                res =new ModelAndView(PAGINA_PRINCIPAL_DETALLE, "detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclaraActual));
            }
            else
            {
                res = new ModelAndView("destino/RegSerie", "detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclaraActual));
            }


            res.addObject("COD_ESTDUA", (String) ((HashMap) session.getAttribute("mapCabDeclaraActual")).get("COD_ESTDUA"));
            res.addObject("acceso", (String) params.get("acceso"));
            return res;
        }
        catch (ServiceException e)
        {
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror(e.getMessage());

            return new ModelAndView("PagM", "Error-Controllador:", mensajeBean);
        }
        catch (Throwable e)
        {
            log.error("error", e);
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror("Ocurrio un error al obtener el listados de la series de la dua.");
            return new ModelAndView("PagM", "Error-Controllador:", mensajeBean);
        }
    }

    /**
     * Obtiene el listado de series desde la session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerListadoSeriesSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        HttpSession session = request.getSession();
        List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) session
                .getAttribute("lstDetDeclaraActual");

        return new ModelAndView(this.jsonView, "detDeclaraViewListJson", lstDetDeclaraActual);
    }

    /**
     * Obtener detalle serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerDetalleSerie(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        HttpSession session = request.getSession();
        Map<String, String> params = new HashMap<String, String>();
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("num_secserie", request.getParameter("hdn_num_secserie"));
        Map<String, Object> data = serieService.obtenerDetalleSerie(params);
        request.setAttribute("data", data);
        session.setAttribute("detDeclara", data);
        return new ModelAndView("Prueba", "data", data);
    }

    /**
     * Editar serie session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView editarSerieSession(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
        params.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
        // valido este campo no es enviado por RegSerie de la regularizacion 664
        params.put(
                "NUM_OPERACION",
                request.getParameter("hdn_num_operacion") != null ? request.getParameter("hdn_num_operacion") : "");

        List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                "lstDetDeclaraActual");
        Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);
        Map mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        String numPartida = detDeclaraViewMap.get("NUM_PARTNANDI")!=null?detDeclaraViewMap.get("NUM_PARTNANDI").toString():"";
        String fechaDeclaracion = SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclaraActual.get("FEC_DECLARACION").toString()),"yyyyMMdd");

        List lstTNAN = new ArrayList();
        lstTNAN = soporteService.obtenerLstTasaNAN(numPartida, fechaDeclaracion);

        //P24-PAS20165E220200099
        ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
        Observacion observacion = new Observacion();
        observacion.setNumcorredoc(SunatNumberUtils.toLong(request.getParameter("hdn_num_corredoc")));
        observacion.setNumsecitem(Integer.parseInt(request.getParameter("hdn_num_secserie")));
        List<String> lstCodTipoObserva = new ArrayList<String>();
        lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO);
        lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_DILIG_DESCARGA_PARCIAL);
        lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE);
        lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_FORMATOA);  //TICKET INC 2015-027983
        //observacion.setCodtipobserva(Constantes.TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO);
        observacion.setLstCodTipObserva(lstCodTipoObserva);
        List<Observacion> lstObservaciones = observacionService.findObservacion(observacion);
        //NRO_OBS, TIPO_OBS, OBS_OBS
        if(!CollectionUtils.isEmpty(lstObservaciones)){
            detDeclaraViewMap.put("lstObservacionesSerie", lstObservaciones);
        }
        //P24-PAS20165E220200099

        ModelAndView view = new ModelAndView(this.jsonView, "detDeclaraViewMap", detDeclaraViewMap);
        view.addObject("lstTNAN", lstTNAN);

        return view;
    }

    /**
     * Metodo que permite obtener el nuevo monto del seguro de una serie producto
     * de cambios: valor FOB de la serie y de la dua, tipo se partida de la serie,
     * tipo se seguro de la serie.
     *
     * @param request
     *          [HttpServletRequest] request
     * @param response
     *          [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @throws Exception
     *           the exception
     * @author amancillaa
     * @version 1.0
     */
    public ModelAndView obtenerNuevoMtoSeguro(HttpServletRequest request,
                                              HttpServletResponse response) throws Exception
    {

        ServletWebRequest webRequest = new ServletWebRequest(request);

        BigDecimal newMtoSeguroSerie = new BigDecimal(0);
        String numSecSerie = webRequest.getParameter("numSecSerie");
        String codTipSegSerie = webRequest.getParameter("tipoSeguroSerie");
        BigDecimal mtoFobDolSerie = Utilidades.toBigDecimal(webRequest.getParameter("mtoFobSerie"));
        BigDecimal mtoAjusteSerie = new BigDecimal(0);
        Long numPartNandiSerie = Utilidades.toLong(webRequest.getParameter("numPartida"));

        Map mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        String numCorredoc = mapCabDeclara.get("NUM_CORREDOC").toString();

        boolean cumpleValProrrateoSeguroTipo1   = false;
        boolean cumpleValProrrateoSeguroTipo2Y3 = false;
        if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(getTipoDiligencia(request)))
        {
            cumpleValProrrateoSeguroTipo1   = ("1".equals(codTipSegSerie) && numPartNandiSerie > 0)?true:false;
            cumpleValProrrateoSeguroTipo2Y3 = ("3".equals(codTipSegSerie) || "2".equals(codTipSegSerie))?true:false;
        }
        else
        {
            cumpleValProrrateoSeguroTipo1   = ("1".equals(codTipSegSerie) && numPartNandiSerie > 0
                    && aCambiadoLosDatos(mtoFobDolSerie, mtoAjusteSerie,
                    numPartNandiSerie, codTipSegSerie,
                    numSecSerie,numCorredoc, request))?true:false;

            cumpleValProrrateoSeguroTipo2Y3 = (("3".equals(codTipSegSerie)
                    || "2".equals(codTipSegSerie))
                    && aCambiadoLosDatos(mtoFobDolSerie,mtoAjusteSerie,
                    codTipSegSerie,numSecSerie,
                    numCorredoc,request))?true:false;
        }


        if (cumpleValProrrateoSeguroTipo1)
        {

            Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION").toString());
            newMtoSeguroSerie = declaracionCalculoDeDatos.calcularMtoSeguroDeLaSerieTipo1(mtoFobDolSerie,
                    mtoAjusteSerie,
                    numPartNandiSerie,
                    fechaVigenciaPartida);

        }
        else if (cumpleValProrrateoSeguroTipo2Y3)
        {

            // ESTA LISTA ES TEMPORAL SOLO PARA CALCULAR EL MONTO DE PRORRATEO DE
            // SEGURO YA QUE SE NECESITA CONSIDERAR
            // MONTO TOTAL DE LA DUA
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");

            if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
            {
                // LISTA ACTUALIZADA
                for (Map serie : lstDetDeclaraActual)
                {
                    if (numSecSerie.equals(serie.get("NUM_SECSERIE").toString()))
                    {
                        serie.put("MTO_FOBDOL", mtoFobDolSerie);
                        // cuando hay cambios del tipo de seguro se pone el ingresado
                        serie.put("COD_TIPSEG", codTipSegSerie);
                    }
                }

                newMtoSeguroSerie = obtenerMontoSeguroSerieTipo2Y3DeLaSerie(lstDetDeclaraActual, numCorredoc, numSecSerie);
            }

        }
        else
        { // el mismo valor de la session

            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,
                    "lstDetDeclaraActual");
            Map filtro;
            if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
            {
                filtro = new HashMap();
                filtro.put("NUM_CORREDOC", numCorredoc);
                filtro.put("NUM_SECSERIE", numSecSerie);
                Map serie = Utilidades.obtenerElemento(lstDetDeclaraActual, filtro);
                newMtoSeguroSerie = Utilidades.toBigDecimal(serie.get("MTO_SEGDOL"));
            }
        }

        return new ModelAndView(this.jsonView, "newMtoSeguro", newMtoSeguroSerie);
    }



    /**
     * A cambiado los datos.
     *
     * @param mtoFobDolSerie
     *          [BigDecimal] mto fob dol serie
     * @param mtoAjusteSerie
     *          [BigDecimal] mto ajuste serie
     * @param codTipSegSerie
     *          [String] cod tip seg serie
     * @param numSecSerie
     *          [String] num sec serie
     * @param numCorredoc
     *          [String] num corredoc
     * @param request
     *          [HttpServletRequest] request
     * @return true, if successful
     */
    private boolean aCambiadoLosDatos(BigDecimal mtoFobDolSerie,
                                      BigDecimal mtoAjusteSerie,
                                      String codTipSegSerie,
                                      String numSecSerie,
                                      String numCorredoc,
                                      HttpServletRequest request)
    {
        List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,
                "lstDetDeclaraActual");
        Map filtro;
        if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            filtro = new HashMap();
            filtro.put("NUM_CORREDOC", numCorredoc);
            filtro.put("NUM_SECSERIE", numSecSerie);
            Map serie = Utilidades.obtenerElemento(lstDetDeclaraActual, filtro);
            BigDecimal mtoFobDolSerieAnt = Utilidades.toBigDecimal(serie.get("MTO_FOBDOL"));
            BigDecimal mtoAjusteSerieAnt = Utilidades.toBigDecimal(serie.get("MTO_AJUSTE"));
            String codTipSegSerieAnt = serie.get("COD_TIPSEG").toString();

            if (mtoFobDolSerieAnt.setScale(3, BigDecimal.ROUND_HALF_UP)
                    .compareTo(mtoFobDolSerie.setScale(3, BigDecimal.ROUND_HALF_UP)) != 0
                    || mtoAjusteSerieAnt.setScale(3, BigDecimal.ROUND_HALF_UP)
                    .compareTo(mtoAjusteSerie.setScale(3, BigDecimal.ROUND_HALF_UP)) != 0
                    || !codTipSegSerie.equals(codTipSegSerieAnt))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * A cambiado los datos.
     *
     * @param mtoFobDolSerie
     *          [BigDecimal] mto fob dol serie
     * @param mtoAjusteSerie
     *          [BigDecimal] mto ajuste serie
     * @param numPartNandiSerie
     *          [Long] num part nandi serie
     * @param codTipSegSerie
     *          [String] cod tip seg serie
     * @param numSecSerie
     *          [String] num sec serie
     * @param numCorredoc
     *          [String] num corredoc
     * @param request
     *          [HttpServletRequest] request
     * @return true, if successful
     */
    private boolean aCambiadoLosDatos(BigDecimal mtoFobDolSerie,
                                      BigDecimal mtoAjusteSerie,
                                      Long numPartNandiSerie,
                                      String codTipSegSerie,
                                      String numSecSerie,
                                      String numCorredoc,
                                      HttpServletRequest request)
    {
        List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,
                "lstDetDeclaraActual");
        Map filtro;
        if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            filtro = new HashMap();
            filtro.put("NUM_CORREDOC", numCorredoc);
            filtro.put("NUM_SECSERIE", numSecSerie);
            Map serie = Utilidades.obtenerElemento(lstDetDeclaraActual, filtro);
            BigDecimal mtoFobDolSerieAnt = Utilidades.toBigDecimal(serie.get("MTO_FOBDOL"));
            //BigDecimal mtoSegDolSerieInicial = Utilidades.toBigDecimal(serie.get("MTO_SEGDOL"));
            BigDecimal mtoAjusteSerieAnt = Utilidades.toBigDecimal(serie.get("MTO_AJUSTE"));
            Long numPartNandiSerieAnt = Utilidades.toLong(serie.get("NUM_PARTNANDI"));
            String codTipSegSerieAnt = serie.get("COD_TIPSEG").toString();


            if (mtoFobDolSerieAnt.compareTo(mtoFobDolSerie) != 0
                    || mtoAjusteSerieAnt.compareTo(mtoAjusteSerie) != 0
                    || numPartNandiSerieAnt.compareTo(numPartNandiSerie) != 0
                    || !codTipSegSerie.equals(codTipSegSerieAnt))
            {
                return true;
            }
        }
        return false;
    }
    /**
     * Metodo que permite obtener las tasas por Partida.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerTasaByPartida(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(
                request,
                "mapCabDeclaraActual");
        FechaBean fechaBean = new FechaBean((java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
        params.put("cnan", request.getParameter("num_partnandi"));
        params.put("ffintas", fechaBean.getFormatDate("yyyyMMdd"));
        NandTasa nandTasa = soporteService.obtenerTasaNandinaByPartida(params);

        return new ModelAndView(this.jsonView, "nandTasa", nandTasa);
    }

    /**
     * Metodo que permite validar una Partida NANDINA.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarPartidaNandina(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(
                request,
                "mapCabDeclaraActual");
        FechaBean fechaBean = new FechaBean((java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
        params.put("partida", request.getParameter("num_partnandi"));
        params.put("finicio", fechaBean.getFormatDate("yyyyMMdd"));
        params.put("ffin", fechaBean.getFormatDate("yyyyMMdd"));
        int existePartida = soporteService.existePartidaNandina(params);
        List lstTNAN = new ArrayList();

        if (existePartida == 1)// si existe
        {
            String numPartida = request.getParameter("num_partnandi");
            lstTNAN = soporteService.obtenerLstTasaNAN(numPartida, fechaBean.getFormatDate("yyyyMMdd"));
        }

        ModelAndView view = new ModelAndView(this.jsonView, "existePartida", existePartida);
        view.addObject("lstTNAN", lstTNAN);
        return view;
    }

    /**
     * Metodo que valida las Unidades Fisicas por Partida.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarUnidadesFisicasByPartida(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(
                request,
                "mapCabDeclaraActual");
        String COD_TIPTASAAPLICAR=" ";
        List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        if (!listDetDeclara.isEmpty())
        {
            for (Map<String, Object> detDeclaraMap : listDetDeclara)
            {
                COD_TIPTASAAPLICAR= detDeclaraMap.get("COD_TIPTASAAPLICAR")!=null?detDeclaraMap.get("COD_TIPTASAAPLICAR").toString():"";
            }
        }
        FechaBean fechaBean = new FechaBean((java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
        params.put("CNAN", request.getParameter("num_partnandi"));
        params.put("UNI", request.getParameter("cod_unifisica"));
        params.put("FEC_DECLARACION", fechaBean.getFormatDate("yyyyMMdd"));
        params.put("COD_UNIFISICA", request.getParameter("cod_unifisica"));
        params.put("CNT_UNIFIS", request.getParameter("cnt_unifis"));
        params.put("CNT_PESO_NETO", request.getParameter("cnt_peso_neto"));
        params.put("COD_TIPTASAAPLICAR",COD_TIPTASAAPLICAR);
        //params.put("COD_TIPTASAAPLICAR",dojo.byId("sel_cod_tiptasaaplicar").value);

        Map<String, Object> validaPartida = soporteService.validaUnidadMedidaFisicas(params);
        ModelAndView view = new ModelAndView(this.jsonView, "existePartida", validaPartida);
        view.addObject("mensaje", validaPartida.get("mensaje").toString());
        view.addObject("validaUnidadFisica", validaPartida.get("validaUnidadFisica").toString());

        return view;
    }

    /**
     * <p>
     * permit actualizar los datos de la SERIE en session
     * </p>
     * .
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return modelView (this.jsonView)
     * @throws Exception
     *           the exception
     */
    /**
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public ModelAndView grabarSerieSession(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        ModelAndView modelView = null;
        try
        {
            Map<String, Object> requestParameterMap = new HashMap<String, Object>();
            HttpSession session = request.getSession();
            requestParameterMap.putAll(request.getParameterMap());
            List lstDetDeclaraActual = (List) session.getAttribute("lstDetDeclaraActual");
            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
            List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");


            // TODO: esta funcionalidad hay que activarla pero en la cabecera y que
            // sea condicional
            // Actualizar la Dua con las Modificaciones de la Serie
            String numSecSerieModificada = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("hdn_num_secserie"));
            Map<String, Object> seriePk = new HashMap();
            seriePk.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
            seriePk.put("NUM_SECSERIE", numSecSerieModificada);
            BigDecimal mtoFobItemOld = obtenerFobBD(seriePk);

			/*
      Map mapSerieOld = ((lstDetDeclaraActual != null) ? Utilidades.obtenerElemento((List<Map<String, Object>>) lstDetDeclaraActual,seriePk) : null);
      if (mapSerieOld != null && mapSerieOld.size() > 0 && mapSerieOld.get("MTO_FOBDOL") != null)
      {
        mtoFobItemOld = Utilidades.toBigDecimal(mapSerieOld.get("MTO_FOBDOL"));
      }
			 */
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("IND_FORMBPROVEEDOR", mapCabDeclaraActual.get("IND_FORMBPROVEEDOR"));
            params.put("requestParameterMap", requestParameterMap);
            params.put("lstDetDeclaraActual", Utilidades.copiarLista(lstDetDeclaraActual));
            params.put("lstSeriesItemActual", lstSeriesItemActual);
            List<Map<String, Object>> detDeclaraViewList = serieService.grabarSerie(params);



            BigDecimal mtoFobItemNew = BigDecimal.ZERO;
            Map mapSerieNew = ((detDeclaraViewList != null) ? Utilidades.obtenerElemento((List<Map<String, Object>>) detDeclaraViewList,seriePk) : null);
            if (mapSerieNew != null && mapSerieNew.size() > 0 && mapSerieNew.get("MTO_FOBDOL") != null)
            {
                mtoFobItemNew = Utilidades.toBigDecimal(mapSerieNew.get("MTO_FOBDOL"));
            }


            //verificamos que hay cambios en el FOB o que la serie sea nueva
            if (mtoFobItemOld.compareTo(mtoFobItemNew) != 0
                    || esUnaSerieNueva(seriePk))
            {
                prorratearDatos(detDeclaraViewList, mapCabDeclaraActual, session);
            }

            for (Map<String, Object> mapSerie : detDeclaraViewList)
            {
                if(mapSerie.get("NUM_SECSERIE").equals(numSecSerieModificada) && !Utilidades.esUnaRegistroMarcadaParaEliminar(mapSerie))//CU 14.20
                {
                    BigDecimal mto_fobdol = Utilidades.toBigDecimal(mapSerie.get("MTO_FOBDOL"));
                    BigDecimal mto_fletedol= Utilidades.toBigDecimal(mapSerie.get("MTO_FLETEDOL"));
                    BigDecimal mto_segdol = Utilidades.toBigDecimal(mapSerie.get("MTO_SEGDOL"));
                    BigDecimal mto_ajuste = Utilidades.toBigDecimal(mapSerie.get("MTO_AJUSTE"));
                    BigDecimal mto_ajuste_otr = Utilidades.toBigDecimal(mapSerie.get("MTO_OTROSAJUSTES"));

                    BigDecimal bdValorAduana =  declaracionCalculoDeDatos.calcularMtoValorAduana(mto_fobdol,mto_fletedol,mto_segdol,mto_ajuste,mto_ajuste_otr);
                    mapSerie.put("MTO_VALORADU",bdValorAduana);
                }
            }
            session.setAttribute("lstDetDeclaraActual", detDeclaraViewList);
            modelView = new ModelAndView(this.jsonView, "OK", "Se ha guardado satisfactoriamente la informaci\u00f3n");
        }
        catch (Exception e)
        {
            log.error("*** ERROR ***", e);
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Corrija el problema de validacion y vuelva a intentar grabar la serie.");

            modelView = new ModelAndView(this.jsonView, "beanM", rBean);
        }

        return modelView;
    }

    /**
     * Metodo que prorratea el flete y el seguro
     *
     * @param detDeclaraViewList
     * @param mapCabDeclaraActual
     * @param session
     * @throws Exception
     */
    private void prorratearDatos(List<Map<String, Object>> detDeclaraViewList,
                                 Map<String, Object> mapCabDeclaraActual, HttpSession session) throws Exception {
        // reutilizamos este metodo pero le enviamos el ArrayList vacio para que
        // solo ejecute
        // el prorrateo de seguro
        // actualizarSeriesconFormatoBSession(mapCabDeclaraActual,
        // detDeclaraViewList, new ArrayList());
        //los calculo se hacen sobre la lista actualizada con los datos del formulario

        BigDecimal newMtoTotalFOBDolSumaSeries = Utilidades.sumarPorCampo(detDeclaraViewList, "MTO_FOBDOL");
        BigDecimal newMtoSeguroProrratearSumaSeries = Utilidades.sumarPorCampo(detDeclaraViewList, "MTO_SEGDOL");
        Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclaraActual.get("FEC_DECLARACION")
                .toString());
        detDeclaraViewList = declaracionCalculoDeDatos.prorratearMtoSeguroEnLasSeries(newMtoSeguroProrratearSumaSeries,
                newMtoTotalFOBDolSumaSeries,
                fechaVigenciaPartida,
                detDeclaraViewList);
        if (seriesTieneAlgunTipoProrrateoDeFleteTipo2y3(detDeclaraViewList))
        {
            detDeclaraViewList = declaracionCalculoDeDatos.prorratearFlete(detDeclaraViewList);
        }
        actualizarDUAconSeriesSession(mapCabDeclaraActual, detDeclaraViewList);
        this.calcularDatosAdicionalesDUA(mapCabDeclaraActual, detDeclaraViewList);

        session.setAttribute("mapCabDeclaraActual", mapCabDeclaraActual);
    }

    private BigDecimal obtenerFobBD(Map<String, Object> seriePk)
    {

        BigDecimal fob = BigDecimal.ZERO;
        List<Map<String, Object>> lst= serieService.select(seriePk);
        if (!CollectionUtils.isEmpty(lst))
        {
            fob = Utilidades.toBigDecimal(lst.get(0).get("MTO_FOBDOL"));
        }

        return fob;
    }

    /**
     * Es una serie nueva, verifica si la serie existe en base de datos.
     *
     * @param seriePk
     *          [Map<String,Object>] serie pk
     * @return true, if successful
     */
    private boolean esUnaSerieNueva(Map<String, Object> seriePk)
    {
        List<Map<String, Object>> lst= serieService.select(seriePk);
        return CollectionUtils.isEmpty(lst)?true:false;
    }

    /**
     * Metodo que graba las comunicaciones.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView grabarComunicacion(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        ModelAndView modelView = null;
        try
        {

            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            String numCorreDoc = request.getParameter("hdn_num_corredoc") != null ? request.getParameter("hdn_num_corredoc")
                    : " ";
            String tipoComunicacion = request.getParameter("rad_cod_nota") != null ? request.getParameter("rad_cod_nota")
                    : " ";
            String descComunicacion = request.getParameter("hdn_des_nota") != null ? request.getParameter("hdn_des_nota")
                    : " ";
            String flag = request.getParameter("flag") != null ? request.getParameter("flag") : " ";

            Map<String, Object> params = new HashMap<String, Object>();
            FechaBean fecActual = new FechaBean();
            params.put("num_corredoc", numCorreDoc);
            params.put("des_nota", descComunicacion);
            params.put("cod_nota", tipoComunicacion);
            params.put("cod_usuregis", bUsuario.getNroRegistro());
            params.put("fec_regis", fecActual.getTimestamp());

            if (!flag.equals("C"))
            {
                params.put("cod_tipdiligencia", "01");
            }
            else
            {
                params.put("cod_tipdiligencia", "04");
            }
            // inserta la comunicacion con el portal
            diligenciaService.grabarComunicacion(params);

            // si es comunicacion con el portal envia una notificacion
            if (tipoComunicacion.trim().equals("e"))
            {

                Map mapCabDeclaraActual = (Map) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
                String codAduana = mapCabDeclaraActual.get("COD_ADUANA").toString();
                String annPresen = mapCabDeclaraActual.get("ANN_PRESEN").toString();
                String codRegimen = mapCabDeclaraActual.get("COD_REGIMEN").toString();
                String numDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION").toString();
                String codCanal = mapCabDeclaraActual.get("COD_CANAL").toString();

                if (codCanal.equals(Constantes.CANAL_ROJO))
                {
                    diligenciaService.notificarObservacion(
                            descComunicacion,
                            codAduana,
                            annPresen,
                            codRegimen,
                            numDeclaracion,
                            bUsuario.getNombreCompleto(),
                            new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString() },
                            Constantes.COD_PL_NOTI_OBS_REC_FISICO,
                            Constantes.CODIGO_NOTIFICACION,
                            Constantes.CONTRIBUYENTE,
                            "PIM");

                    diligenciaService.notificarObservacion(
                            descComunicacion,
                            codAduana,
                            annPresen,
                            codRegimen,
                            numDeclaracion,
                            bUsuario.getNombreCompleto(),
                            new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString() },
                            Constantes.COD_PL_NOTI_OBS_REC_FISICO,
                            Constantes.CODIGO_NOTIFICACION,
                            Constantes.CONTRIBUYENTE,
                            "PDE");
                }
                else if (codCanal.equals(Constantes.CANAL_NARANJA))
                {
                    diligenciaService.notificarObservacion(
                            descComunicacion,
                            codAduana,
                            annPresen,
                            codRegimen,
                            numDeclaracion,
                            bUsuario.getNombreCompleto(),
                            new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString() },
                            Constantes.COD_PL_NOTI_OBS_REV_DOCUMENTARIA,
                            Constantes.CODIGO_NOTIFICACION,
                            Constantes.CONTRIBUYENTE,
                            "PIM");

                    diligenciaService.notificarObservacion(
                            descComunicacion,
                            codAduana,
                            annPresen,
                            codRegimen,
                            numDeclaracion,
                            bUsuario.getNombreCompleto(),
                            new String[] { mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString() },
                            Constantes.COD_PL_NOTI_OBS_REV_DOCUMENTARIA,
                            Constantes.CODIGO_NOTIFICACION,
                            Constantes.CONTRIBUYENTE,
                            "PDE");
                }

                // ACTUALIZAR ESTADO DE LA DUA A 15, DURANTE LA NOTIFICACION DE
                // OBSERVACIONES
                Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
                paramDeclaracion.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                paramDeclaracion.put("COD_ESTDUA", "15");
                declaracionService.updateDeclaracion(paramDeclaracion);
            }


            modelView = new ModelAndView(this.jsonView, "OK", "La comunicacion se grabo con Exito");
        }
        catch (Exception e)
        {
            modelView = new ModelAndView(this.jsonView, "ERROR", e.getMessage());
        }

        return modelView;
    }

    //P13 JMCV - INCIO
    /**
     * Metodo que muestra mensajes de estados de acuerdo a 6 validaciones del Resultado del Reconocimiento F�sico de mercanc�as.
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView validarRevision(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ModelAndView modelView = new ModelAndView(this.jsonView);

        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

        String mensaje 		= StringUtils.EMPTY;
        String pregunta 	= StringUtils.EMPTY;

        String cod_estrev 		= "";
        String cod_canal 		= "";

        cod_estrev = StringUtils.trimToEmpty(request.getParameter("selMotivo"));
        cod_canal  = StringUtils.trimToEmpty(request.getParameter("hdn_cod_canal"));

        Map<String, Object> mapDeclaracionActual = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        mapDeclaracionActual.put("COD_CANAL",StringUtils.trimToEmpty(request.getParameter("hdn_cod_canal")));
        mapDeclaracionActual.put("COD_ESTREV",StringUtils.trimToEmpty(request.getParameter("selMotivo")));

        mensaje = diligenciaService.validarReconocimientoFisico(mapDeclaracionActual);

        modelView = new ModelAndView(this.jsonView, "tieneObservacion", mensaje);
        return  modelView;

    }
    public ModelAndView grabarRevision(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        ModelAndView modelView = null;
        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

            UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

            Map<String, Object> mapDeclaracionActual = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

            mapDeclaracionActual.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
            mapDeclaracionActual.put("COD_REGIMEN", request.getParameter("hdn_cod_regimen"));
            mapDeclaracionActual.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
            mapDeclaracionActual.put("ANN_PRESEN", request.getParameter("hdn_ann_presen"));
            mapDeclaracionActual.put("NUM_DECLARACION", request.getParameter("hdn_num_declaracion"));
            mapDeclaracionActual.put("EN_PROCESO", "0");

            mapDeclaracionActual.put("cod_indicador_dua",request.getParameter("hdn_cod_indicador_dua"));
            mapDeclaracionActual.put("COD_CANAL",request.getParameter("hdn_cod_canal"));
            mapDeclaracionActual.put("COD_ESTREV",request.getParameter("selMotivo"));
            mapDeclaracionActual.put("cod_funcionario", bUsuario.getNroRegistro());

            modelView = new ModelAndView(this.jsonView,"OK", diligenciaService.grabarRevisionReconocimientoFisico(mapDeclaracionActual));

        }
        catch (Exception e)
        {
            log.error("*** ERROR ***", e);
            modelView = new ModelAndView(this.jsonView, "ERROR", e.getMessage());
        }

        return modelView;
    }
    //P13 JMCV - FIN

    /**
     * Metodo que permite obtener los datos de los catalogos a usar dentro de la
     * edicion de la declaracion.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView declaracionEnProceso(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        // se actualiza los datos iniciales de la serieOrigen

        HttpSession session = request.getSession();
        Map<String, String> params = new HashMap<String, String>();
        params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
        params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString());
        params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString());
        params.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
        params.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
        params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());
        params.put("acceso", "");

        request.setAttribute("params", params);
        // Para Declaracion en Proceso se filtran las Series
        params.put("estadoDUA", declaracion.get("COD_ESTDUA").toString());
        List lstDetDeclara = serieService.obtenerListadoSeries(params);

        session.setAttribute("lstDetDeclara", lstDetDeclara);

        ModelAndView res = new ModelAndView("destino/RegDiligenciaDespacho", "declaracion", declaracion);
        res.addObject("lstUndTmp", this.catalogoAyudaService.getElementosCat(Constantes.CAT_UND_TMP));
        res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

        res.addObject("existeIncid", existenIncidencias(request));
        res.addObject("existeMulta", existenMultas(request));

        ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");
        List listTipoResolucion = resolucionService.obtenerTiposResoluciones();

        res.addObject("lstTiposResolucionJSON",!CollectionUtils.isEmpty(listTipoResolucion)?SojoUtil.toJson(listTipoResolucion) : "[]");
        //En el caso que haya agregado series se setea la nueva cantidad en la cabecera y esta se muestre en el formulario
        List<Map> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        int cont=0;

        if(lstDetDeclaraActual!=null){//PAS20175E220200035
            for (Map mapa:lstDetDeclaraActual){
                if (mapa.get("IND_DEL")!=null && "0".equals(mapa.get("IND_DEL").toString())){
                    cont++;
                }
            }
        }

        declaracion.put("CNT_TOTSERIES", cont);
        //
        
        //csantillan PAS20181U220200069: Vigencia PECO / Amazonia  // BUG P_SNAA0004-15004
        ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaDeclaracion = (Date) declaracion.get("FEC_REGIS");
	    boolean esVigentePecoAmazoniaSegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigentePecoAmazoniaSegundaParte(fechaDeclaracion):false;
    	
	    res.addObject("vigenciaPECOAmazonia", esVigentePecoAmazoniaSegundaParte);
        
        //Fin csantillan PAS20181U220200069

        return res;

    }

    /**
     * Metodo que valida si existen Incidencias, 0: No existen, 1: Si existen.
     *
     * @param request
     *          the request
     * @return the string
     */
    private String existenIncidencias(HttpServletRequest request)
    {
        String res = "0";
        List<IncidenciaBean> lstIncidencias = (ArrayList) WebUtils.getSessionAttribute(request, "lstIncidencias");
        if (!CollectionUtils.isEmpty(lstIncidencias))
        {
            for (IncidenciaBean incidBean : lstIncidencias)
            {
                if (incidBean.getFlagIncidencia())
                {
                    res = "1";
                    break;
                }
            }
        }
        return res;
    }

    /**
     * Metodo que evalua si existen Multas, 0: No existen, 1: Si existen.
     *
     * @param request
     *          the request
     * @return the string
     */
    private String existenMultas(HttpServletRequest request)
    {
        List lstMultaDua = (ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDua");

        return (!CollectionUtils.isEmpty(lstMultaDua)) ? "1" : "0";
    }

    /**
     * Metodo que obtiene la cantidad de registros incidencias.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cantidadRegistroIncidencia(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        // indica si tiene incidencias marcadas
        res.addObject("cantidadIncidencia", existenIncidencias(request));
        List<Map<String, Object>> listaSeries = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List lstSerieSinEliminar = new ArrayList();
        int numSerieNOElim = 10; // caso en la que aun no has cargado las series
        if (!CollectionUtils.isEmpty(listaSeries))
        {
            for (Map mapSerie : listaSeries)
            {
                if ("0".equals(mapSerie.get("IND_DEL").toString()))
                {
                    lstSerieSinEliminar.add(mapSerie);
                }
            }
            numSerieNOElim = lstSerieSinEliminar.size();
        }
        res.addObject("cantidadSerie", numSerieNOElim);
        return res;
    }

    /**
     * Metodo que permite actulizar la Diligencia y la Declaracion en Revision,
     * asi como recuperar los catalogos a usar.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView declaracionEnRevision(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        try
        {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            Map<String, Object> params = new HashMap<String, Object>();
            params.put(
                    "NUM_DECLARACION",
                    StringUtils.defaultIfEmpty(
                            webRequest.getParameter("hdn_num_declaracion"),
                            webRequest.getParameter("txt_num_declaracion")));
            params.put(
                    "COD_ADUANA",
                    StringUtils.defaultIfEmpty(
                            webRequest.getParameter("hdn_cod_aduana"),
                            webRequest.getParameter("txt_cod_aduana")));
            params.put(
                    "ANN_PRESEN",
                    StringUtils.defaultIfEmpty(
                            webRequest.getParameter("hdn_ann_presen"),
                            webRequest.getParameter("txt_ann_presen")));
            params.put(
                    "COD_REGIMEN",
                    StringUtils.defaultIfEmpty(
                            webRequest.getParameter("hdn_cod_regimen"),
                            webRequest.getParameter("sel_cod_regimen")));
            params.put("EN_PROCESO", "0");
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            FechaBean fecActual = new FechaBean();
            UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());
            Map<String, Object> declaracion = this.declaracionService.obtenerDeclaracion(params);
            String numDocIdentPdf = declaracion.get("NUM_DOCIDENT_PDF") != null ? (String) declaracion
                    .get("NUM_DOCIDENT_PDF") : "";
            String codLocalAnexo  = declaracion.get("COD_LOCALANEXO")!=null?(String) declaracion.get("COD_LOCALANEXO"):"";
            String direccionLocalAnexo = "";
            if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf)){
                direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
                if(SunatStringUtils.isEmpty(direccionLocalAnexo)){ //si no esta registrado el local
                    direccionLocalAnexo = "No registrado";
                }
            }else{
                direccionLocalAnexo = "No registrado";
            }
            declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
            String numDocIdentPdd = declaracion.get("NUM_DOCIDENT_PDD")!=null?(String) declaracion.get("NUM_DOCIDENT_PDD"):"";
            String codLocalAnexoDeposito  = declaracion.get("COD_LOCALANEXODEPOSITO")!=null?(String) declaracion.get("COD_LOCALANEXODEPOSITO"):"";
            String direccionLocalAnexoDeposito = "";
            if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd)){
                direccionLocalAnexoDeposito = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd,codLocalAnexoDeposito);
                if(SunatStringUtils.isEmpty(direccionLocalAnexoDeposito)){ //si no esta registrado el local
                    direccionLocalAnexoDeposito = "No registrado";
                }
            }else{
                direccionLocalAnexoDeposito = "No registrado";
            }
            declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);
            if (!declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_DECLARACION_REVISION))
            {
                Map<String, Object> diligencia = new HashMap();
                // Obtenemos los datos para registrar los plazos del proceso
                // Obtenemos los parametros de request
                diligencia.put("IND_INCIDENCIA", webRequest.getParameter("incidencia"));
                diligencia.put("IND_MULTA", webRequest.getParameter("multa"));
                diligencia.put("DES_RESULTADO", webRequest.getParameter("resultado"));
                diligencia.put("COD_TIPDILIGENCIA", "01");
                diligencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
                diligencia.put("COD_FUNCIONARIO", bUsuario.getNroRegistro());

                Map<String, Object> paramsDiligencia = new HashMap();
                paramsDiligencia.put("mapCabDiligenciaActual", diligencia);

                diligenciaService.grabarDiligenciaByInicioRevision(paramsDiligencia);


            }

            Map<String, Object> paramDeclaracion = new HashMap<String, Object>();

            declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
            declaracion.put(
                    "COD_ESTDUA_DESC",
                    catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_ESTADO_DUA,
                            Constantes.ESTADO_DECLARACION_REVISION));

            paramDeclaracion.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

            paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
            paramDeclaracion.put("COD_USUMODIF", bUsuario.getNroRegistro());
            paramDeclaracion.put("FEC_MODIF", fecActual.getTimestamp());

            declaracionService.updateDeclaracion(paramDeclaracion);

            // 27.05.2010 BIM para DUA's forzadas a reconocimiento físico
            if ("08".equals((String) declaracion.get("COD_INDICADOR")))
            {
                declaracion.put("tituloDiligencia", declaracionService.obtenerTituloDiligencia("F"));
            }
            else
            {
                declaracion.put("tituloDiligencia",
                        declaracionService.obtenerTituloDiligencia((String) declaracion.get("COD_CANAL")));
            }

            Map<String, Object> declaracionActual = new HashMap<String, Object>();
            if (declaracion != null && declaracion.size() > 0)
            {
                declaracionActual.putAll(declaracion);
            }

            Map diligencia = new HashMap();
            diligencia.put("IND_INCIDENCIA", "");
            diligencia.put("IND_MULTA", "");
            diligencia.put("DES_RESULTADO", "");

            //P24 - PAS20165E220200099
            ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
            Observacion observacion = new Observacion();
            observacion.setNumcorredoc(SunatNumberUtils.toLong(declaracionActual.get("NUM_CORREDOC")));
            observacion.setCodtipobserva("01"); //solo las observaciones de datos generales, si se requiere para otro formulario se deber� filtrar por JSP y colocar null en tipo de obs
            List<Observacion> listaObservaciones = observacionService.buscarObservacion(observacion);
            if(CollectionUtils.isEmpty(listaObservaciones)){
                declaracionActual.put("OBSERVACIONES", null);
                declaracionActual.put("CANT_OBS", 1);
            }else{
                String descCodObs;
                for(Observacion obs : listaObservaciones){
                    descCodObs =this.catalogoAyudaService.getDescripcionDataCatalogo("369",obs.getCodtipobserva());
                    obs.setCodtipobserva(obs.getCodtipobserva().concat(" - ").concat((descCodObs!=null?descCodObs:"")));
                }
                declaracionActual.put("OBSERVACIONES", listaObservaciones);
                declaracionActual.put("CANT_OBS", listaObservaciones.size());
            }

            //P24-PAS20165E220200099 - Inicio
            Map<String, Object> tieneVP = new HashMap<String, Object>();
            String indicadorVFobProvVP = "NO";//RIN10 BUG 22611,22613
            tieneVP = null;
            String flag = "";
            flag = WUtil.getParam(request,"hdn_flag");
            if(flag==""){
                flag = "1";
            }
            Map<String, Object> paramsValidador = new HashMap<String, Object>();
            paramsValidador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));//usado con validarValorProvisional
            paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23014);
            boolean indicadorDUAValorProvActivo = duaTieneIndicadorDUAValorProvActivo(declaracion);
            String tipoRegimen = (String) params.get("COD_REGIMEN");
            if(indicadorDUAValorProvActivo){
                //Fin RIN10 mpoblete refactor
                if(flag!="-1" && flag.equals("1")){
                    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
                        String ANNPRESENORIGINAL = declaracion.get("ANN_PRESEN").toString();
                        //verificarValorProvisional(params,declaracion);RIN10 BUG 22611,22613
                        declaracion.put("ANN_PRESEN", ANNPRESENORIGINAL);
                        paramsValidador.put("COD_PROCESO", Constantes.COD_PROCESO_F23006);
                        tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
                        //Inicio RIN10 BUG 22611,22613
                        if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
                            verificarValorProvisional(params,declaracion);
                            indicadorVFobProvVP = "SI";
                        }
                        //Fin RIN10 BUG 22611,22613
                    }
                }else if(flag!="-1" ||flag.equals("2")){
                    if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){//A�adir mas regimenes si fuere el caso, por ahora solo se valida el valor prov si el regimen es 10
                        tieneVP = this.declaracionService.validarValorProvisional(paramsValidador);
                        //Inicio RIN10 BUG 22611,22613
                        if(!CollectionUtils.isEmpty(tieneVP) && tieneVP.containsKey("indicadorVFobProvValorProvisional") && "SI".equals(tieneVP.get("indicadorVFobProvValorProvisional"))){
                            indicadorVFobProvVP = "SI";
                        }
                        //Fin RIN10 BUG 22611,22613
                    }
                }
            }//RIN10 mpoblete refactor

            if( !CollectionUtils.isEmpty(tieneVP) && indicadorDUAValorProvActivo && tieneVP.get("Excepcion1").toString()==Constantes.ESPACIO_BLANCO){
                //Fin RIN10 BUG 22611,22613
                declaracionActual.put("IND_VALOR_PROV", "1");
            }else{
                declaracionActual.put("IND_VALOR_PROV", "0");
            }
            //P24-PAS20165E220200099 - Fin

            String codigoPropiedad = (String)declaracionActual.get("COD_PROPIEDAD");
            String codigoPropiedadDesc =this.catalogoAyudaService.getDescripcionDataCatalogo("63",codigoPropiedad);
            declaracionActual.put("ENDOSE_DESC", codigoPropiedad + " - " + codigoPropiedadDesc);

            // Guardamos en sesion los datos de la declaracion e invocamos el jsp
            // correspondiente
            WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
            WebUtils.setSessionAttribute(request, "mapCabDiligencia", diligencia);

            ModelAndView res = new ModelAndView("destino/RegDiligenciaRevision");
            res.addObject("declaracion", declaracionActual);
            res.addObject("declaracionP14", declaracionActual);//para temas de  compatibilidad de jsp importado
            res.addObject("diligencia", declaracionActual);
            res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

            //P13 JMCV - INICIO
            List lstRevFisica = catalogoAyudaService.getElementosCat(ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO);
            //P13 JMCV � FIN
            List lstNuevaRevFisica = new ArrayList();
            if (!CollectionUtils.isEmpty(lstRevFisica))
            {
                Iterator i1 = lstRevFisica.iterator();
                // Se adciona tipo de asignacion de especialista que no
                // se registran en la revision
                while (i1.hasNext())
                {
                    Map<String, Object> mapa = (Map<String, Object>) i1.next();
                    //P13 JMCV INICIO
                    //Map mapacatalogo = new HashMap();
                    Map<String, Object> mapacatalogo = new HashMap();
                    mapacatalogo.put("cod_datacat", (String)mapa.get("cod_datacat"));
                    //mapacatalogo.put("des_corta", new StringBuilder().append((String)mapa.get("cod_datacat")).append(" ").append((String)mapa.get("des_corta")).toString());
                    mapacatalogo.put("des_corta", (String) mapa.get("cod_datacat") + " " + (String) mapa.get("des_corta"));
                    String cod_datacat = StringUtils.trimToEmpty( MapUtils.getMapValor(mapa, "cod_datacat"));
                    //Se Modifico por la P13
                    //       if (!mapa.get("cod_datacat").equals("01") && !mapa.get("cod_datacat").equals("04")
                    //       && !mapa.get("cod_datacat").equals("06") && !mapa.get("cod_datacat").equals("08")
                    //       && !mapa.get("cod_datacat").equals("10"))
                    //   {
                    if (ArrayUtils.contains(new String[]
                            { ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_INCONCLUSO,
                                    ConstantesDataCatalogo.DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
                                    ConstantesDataCatalogo.DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
                                    ConstantesDataCatalogo.INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
                                    ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL,
                                    ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_CON_CONTINUACION }, cod_datacat)){

                        lstNuevaRevFisica.add(mapacatalogo);
                    }

                }
            }
            // P13 JMCV INICIO
            Ordenador.sortDesc(lstNuevaRevFisica, "cod_datacat", Ordenador.ASC);
            // P13 JMCV FIN
            res.addObject("lstMotivoRevFisico", lstNuevaRevFisica);

            return res;
        }

        catch (ServiceException e)
        {
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror(e.getMessage());
            return new ModelAndView("PagM", "Error", mensajeBean);
        }
        catch (Throwable e)
        {
            log.error("error", e);
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror("Ocurrio un error al realizar la diligencia en Revision");

            return new ModelAndView("PagM", "Error", mensajeBean);
        }
    }

    /**
     * Despachador no se presento.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView despachadorNoSePresento(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("cod_documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
        params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
        params.put("ann_presen", request.getParameter("hdn_ann_presen"));
        params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
        params
                .put("cod_funcionario", ((UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean")).getNroRegistro());

        params.put("cod_tipasig", "R");


        Map mapCabDeclaraActual = (Map) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        params.put("num_docident_pim", mapCabDeclaraActual.get("NUM_DOCIDENT_PIM"));
        params.put("num_docident_pde", mapCabDeclaraActual.get("NUM_DOCIDENT_PDE"));

        Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
        paramDeclaracion.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));

        solicitudService.reasignarDocumentos(params);

        paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_RECEPCIONADO);
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

        declaracionService.updateDeclaracion(paramDeclaracion);

        Map<String, Object> data = new HashMap<String, Object>();
        data = new HashMap<String, Object>();
        data.put("mensaje", "Se registr� el resultado de la DUA asignada a reconocimiento f�sico");
        request.setAttribute("data", data);
        return new ModelAndView(this.jsonView, "data", data);
    }

    /**
     * Mostrar incidencias.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView mostrarIncidencias(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Map<String, String> params = new HashMap<String, String>();
        params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
        params.put("ann_presen", request.getParameter("hdn_ann_presen"));
        params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
        params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
        params.put("cod_tiplugarrecep", request.getParameter("hdn_cod_tiplugarrecep"));

        List<IncidenciaBean> lstIncidencias = null;

        IncidenciaBean incidenciaBean = new IncidenciaBean();
        HttpSession session = request.getSession();
        incidenciaBean.setCabAnteriorMap((Map<String, Object>) session.getAttribute("mapCabDeclara"));
        incidenciaBean.setCabActualMap((Map<String, Object>) session.getAttribute("mapCabDeclaraActual"));
        incidenciaBean.setDetAnteriorList((List<Map<String, Object>>) session.getAttribute("lstDetDeclara"));
        incidenciaBean.setDetActualList((List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual"));
        incidenciaBean.setEntidadMaestro("CAB_DECLARA");
        incidenciaBean.setEntidadDetalle("DET_DECLARA");
        lstIncidencias = incidenciaService.asignarIncidencia(incidenciaBean);
        String[] codIncidenciasAuto = (String[]) WebUtils.getSessionAttribute(request, "codIncidenciasAuto");

        if (codIncidenciasAuto != null)
        {
            for (int i = 0; i < codIncidenciasAuto.length; i++)
            {
                for (int j = 0; j < lstIncidencias.size(); j++)
                {
                    IncidenciaBean incidenciaView = (IncidenciaBean) lstIncidencias.get(j);
                    if (codIncidenciasAuto[i].equals((String) incidenciaView.getCod_incidencia()))
                    {
                        incidenciaView.setFlagIncidencia(true);
                        break;
                    }
                }
            }
        }
        WebUtils.setSessionAttribute(request, "lstIncidencias", lstIncidencias);

        request.setAttribute("lstIncidencias", lstIncidencias);
        request.setAttribute("params", params);

        return new ModelAndView("DetIncidencia", "lstIncidencias", lstIncidencias);
    }

    /**
     * Metodo que permite grabar las incidencias en Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView grabarIncidenciasSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        ModelAndView res = new ModelAndView(this.jsonView);
        boolean error = false;
        MensajeBean rBean = new MensajeBean();
        Map<String, String> params = new HashMap<String, String>();
        params.put("documentoAduanero", request.getParameter("hdn_documentoAduanero"));
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
        params.put("ann_presen", request.getParameter("hdn_ann_presen"));
        params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
        params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
        params.put("cod_tiplugarrecep", request.getParameter("hdn_cod_tiplugarrecep"));
        List<IncidenciaBean> lstIncidencias = (List<IncidenciaBean>) WebUtils
                .getSessionAttribute(request, "lstIncidencias");
        String[] selecciones = request.getParameterValues("chk_seleccione");
        for (IncidenciaBean incidenciaBean : lstIncidencias)
        {
            incidenciaBean.setFlagIncidencia(false);
        }
        // Para tipo de incidencia 44
        if (selecciones != null && selecciones.length > 0)
        {
            for (String seleccion : selecciones)
            {
                int secuencia = Integer.parseInt(seleccion) - 1;
                IncidenciaBean incidenciaBean = lstIncidencias.get(secuencia);

                if (!params.get("cod_tiplugarrecep").equals("04"))
                {
                    if (incidenciaBean.getCod_incidencia().equals("44"))
                    {
                        lstIncidencias.get(secuencia).setFlagIncidencia(false);
                        rBean.setError(true);
                        rBean
                                .setMensajeerror("La incidencia 44 solo es permitida para el tipo de recepcion 04:Extension de Zona Primaria");
                        rBean.setMensajesol("Por favor vuelva a seleccionar.");
                        error = true;
                    }
                    else
                    {
                        lstIncidencias.get(secuencia).setFlagIncidencia(true);
                    }
                }
                else
                {
                    lstIncidencias.get(secuencia).setFlagIncidencia(true);
                }
            }
        }
        if (error)
        {
            res.addObject("beanM", rBean);
        }
        else
        {
            res.addObject("recOk", true);
        }
        request.setAttribute("lstIncidencias", lstIncidencias);
        request.setAttribute("params", params);
        return res;

    }

    /**
     * Permite cargar la interfaz con los datos de factura formato A.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarMantFactura(HttpServletRequest request, HttpServletResponse response)
    {


        List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstFacturasSerieActual");
        List lstFacturasSerie = (List) WebUtils.getSessionAttribute(request, "lstFacturasSerie");
        List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

        Map<String, Object> params = new HashMap<String, Object>();

        String codAduana = request.getParameter("hdn_cod_aduana");
        String annPresen = request.getParameter("hdn_ann_presen");
        String codRegimen = request.getParameter("hdn_cod_regimen");
        String codDeclaracion = request.getParameter("hdn_num_declaracion");
        String numCorredoc = request.getParameter("hdn_num_corredoc");
        String numSerieSeleccinada = request.getParameter("hdn_num_secserie");

        // params mapa de datos que necesita el JSP
        params.put("cod_aduana", codAduana);
        params.put("ann_presen", annPresen);
        params.put("cod_regimen", codRegimen);
        params.put("num_declaracion", codDeclaracion);
        params.put("num_corredoc", numCorredoc);
        params.put("num_secserie", numSerieSeleccinada);

        Map<String, Object> mapKeyDet = new HashMap<String, Object>();
        mapKeyDet.put("NUM_CORREDOC", numCorredoc);
        mapKeyDet.put("NUM_SECSERIE", numSerieSeleccinada);

        Map mapDetActual = Utilidades.obtenerElemento(lstDetDeclara, mapKeyDet);
        // verificamos si es agregado y posee lasfacturas series
        // eso quiere decir que en la adicion eliminacion de series lstFacturaSerie
        // esta en esta lstDetDeclara
        if (null != mapDetActual.get("ESTADO_REGISTRO")
                && !CollectionUtils.isEmpty((ArrayList) mapDetActual.get("lstFacturaSerie")))
        {
            lstFacturasSerieActual = (ArrayList) mapDetActual.get("lstFacturaSerie");
        }

        // verificamos si los datos estan llenos si no lo estan obstenemos de BD
        if (CollectionUtils.isEmpty(lstFacturasSerieActual))
        {
            // obtiene todas las facturas de la serie seleeccionado
            lstFacturasSerieActual = formatoValorService.obtenerFacturasSerie(params);
        }
        if (CollectionUtils.isEmpty(lstFacturasSerie) && !CollectionUtils.isEmpty(lstFacturasSerieActual))
        {
            lstFacturasSerie = new ArrayList();
            lstFacturasSerie.addAll(Utilidades.copiarLista((List) lstFacturasSerieActual));
        }

        JsonSerializer serializer = new JsonSerializer();
        String arrayFacturas = (String) request.getSession().getAttribute("arrayFacturas");
        List<Map<String, Object>> lstFacturas = (List<Map<String, Object>>) serializer.deserialize(arrayFacturas);
        Map mKey1 = new HashMap();
        Map mKey2 = new HashMap();

        if (WebUtils.getSessionAttribute(request, "first_time_Fact") == null)
        {
            if (!CollectionUtils.isEmpty(lstFacturas))
            {
                for (Map mFactura : lstFacturas)
                {
                    mKey1 = (Map) serializer.deserialize(mFactura.get("DES_CLAVE").toString());
                    Map mapFacturaExists = Utilidades.obtenerElemento(lstFacturasSerieActual, mKey1);

                    if (mapFacturaExists == null && mFactura.get("IND_RECTIFICA").toString().equals("N"))
                    {
                        Map<String, Object> mapFactura = new HashMap<String, Object>();
                        for (Map mFacturaNew : lstFacturas)
                        {
                            mKey2 = (Map) serializer.deserialize(mFacturaNew.get("DES_CLAVE").toString());
                            if (mKey1.get("NUM_CORREDOC").toString().equals(mKey2.get("NUM_CORREDOC").toString())
                                    && mKey1.get("NUM_SECFACT").toString().equals(mKey2.get("NUM_SECFACT").toString()))
                            {

                                mapFactura.put(mFacturaNew.get("CAMPO").toString(), mFacturaNew.get("VALOR2R"));

                            }
                        }
                        mapFactura.putAll(mKey1);
                        mapFactura.put("NUM_SECFACT", mKey1.get("NUM_SECFACT").toString());
                        lstFacturasSerieActual.add(mapFactura);
                    }
                    else
                    {
                        if (mapFacturaExists != null && mFactura.get("IND_RECTIFICA").toString().equals("R"))
                        {
                            for (Map mFacturaAct : lstFacturasSerieActual)
                            {
                                if (mKey1.get("NUM_CORREDOC").toString().equals(mFacturaAct.get("NUM_CORREDOC").toString())
                                        && mKey1.get("NUM_SECFACT").toString().equals(mFacturaAct.get("NUM_SECFACT").toString()))
                                {

                                    mFacturaAct.put(mFactura.get("CAMPO").toString(), mFactura.get("VALOR2R"));
                                    break;

                                }
                            }
                        }
                    }
                }
            }
            WebUtils.setSessionAttribute(request, "first_time_Fact", "false");
        }

        // seteamos los valor obtenidos a session
        WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieActual);
        WebUtils.setSessionAttribute(request, "lstFacturasSerie", lstFacturasSerie);

        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute(
                "mapCabDeclaraActual");
        params.put("fec_declaracion", df.format(mapCabDeclaraActual.get("FEC_DECLARACION")));

        // seleccinamos la serie para mostrar en el JSP
        List<Map<String, Object>> lstFacturasSerieMostrar = new ArrayList<Map<String, Object>>();
        if (!CollectionUtils.isEmpty(lstFacturasSerieActual))
        {
            for (Map<String, Object> mapa : lstFacturasSerieActual)
            {
                if (mapa.get("NUM_SECSERIE").toString().equals(numSerieSeleccinada))
                {
                    lstFacturasSerieMostrar.add(mapa);
                }
            }
        }

        request.setAttribute("params", params);

        /* INICIO-PAS20134E610000153 */
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
        Boolean banderaEdicion = true;
        if ("10".equals(tipoDiligencia))
        {
            if (mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                    && "EN_PROCESO".equals(mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
            {
                banderaEdicion = true;
            }
            else
            {
                banderaEdicion = false;
            }
        }

        ModelAndView view = new ModelAndView("MantFacturasSerie");
        view.addObject("lstFacturasSerieJson", SojoUtil.toJson(lstFacturasSerieMostrar));
        view.addObject("bEdicion", banderaEdicion);
        return view;
        /*FIN-PAS20134E610000153*/
    }

    /**
     * Obtener facturas session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerFacturasSession(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        HttpSession session = request.getSession();
        List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) session
                .getAttribute("lstFacturasSerieActual");

        List<Map<String, Object>> lstFacturasSerieMostrar = new ArrayList<Map<String, Object>>();
        if (!CollectionUtils.isEmpty(lstFacturasSerieActual))
        {
            for (Map<String, Object> mapa : lstFacturasSerieActual)
            {
                if (mapa.get("NUM_SECSERIE").toString().equals(request.getParameter("hdn_num_secserie")))
                {
                    lstFacturasSerieMostrar.add(mapa);
                }
            }
        }

        return new ModelAndView(this.jsonView, "lstFacturasSerieActualJSON", lstFacturasSerieMostrar);
    }

    /**
     * Permite seleccionar una factura serie desde la session segun los parametros
     * hdn_num_secserie, hdn_num_secfact y hdn_num_corredoc.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView seleccionarFacturaSession(HttpServletRequest request, HttpServletResponse response)
    {

        HttpSession session = request.getSession();
        Map<String, String> params = new HashMap<String, String>();
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("num_secserie", request.getParameter("hdn_num_secserie"));
        params.put("num_secfact", request.getParameter("hdn_num_secfact"));

        params.put("index", request.getParameter("index"));
        List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) session
                .getAttribute("lstFacturasSerieActual");

        Map<String, Object> mapFacturasSerie = declaracionService.seleccionarFacturaSession(params, lstFacturasSerieActual);
        return new ModelAndView(this.jsonView, "mapFacturasSerie", mapFacturasSerie);
    }

    /**
     * Metodo que permite guardar las facturas en Session para una determinada
     * Serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView grabarFacturaSession(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView modelView = null;
        try
        {
            HttpSession session = request.getSession();
            Map<String, String> params = new HashMap<String, String>();
            params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
            params.put("num_secserie", request.getParameter("hdn_num_secserie"));
            params.put("num_secfact", request.getParameter("hdn_num_secfact"));
            params.put("num_fact", request.getParameter("txt_num_fact"));
            params.put("fec_fact", request.getParameter("txt_fec_fact"));

            params.put("index", request.getParameter("hdn_index"));

            String accion = request.getParameter("accion");
            List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) session.getAttribute("lstFacturasSerieActual");
            //este mapa no se usa solo hay que quitarlos de la interface
            //no se quita pq debe de hacerse en ambos ears
            List<Map<String, Object>> lstFacturasSerieAnt = (List<Map<String, Object>>) session.getAttribute("lstFacturasSerie");
            if ("M".equals(accion))
            {
                lstFacturasSerieActual = declaracionService.grabarFacturaSession(
                        params,
                        lstFacturasSerieActual,
                        lstFacturasSerieAnt);
            }
            else if ("A".equals(accion))
            {
                declaracionService.adicionarFacturaSession(params, lstFacturasSerieActual, lstFacturasSerieAnt);
            }
            WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieActual);

            //coloca la facturaSerie en la lista de series actuales

            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclaraBD = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            //limpiar
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
            WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
            List<Map<String, Object>> lstSerieNew= new ArrayList<Map<String, Object>>();
            List<Map<String, Object>> lstSerieOld= new ArrayList<Map<String, Object>>();
            lstSerieNew.addAll(Utilidades.copiarLista((List)lstDetDeclaraActual));
            lstSerieOld.addAll(Utilidades.copiarLista((List)lstDetDeclaraBD));

            Map seriePk = new HashMap();
            seriePk.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
            seriePk.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));

            for (Map<String, Object> mapSerie : lstSerieNew)
            {
                if(mapSerie.get("NUM_CORREDOC").toString().equals(request.getParameter("hdn_num_corredoc").toString())
                        && mapSerie.get("NUM_SECSERIE").toString().equals(request.getParameter("hdn_num_secserie").toString()))
                {
                    mapSerie.put("lstFacturaSerie", Utilidades.copiarLista((List)lstFacturasSerieActual));
                }
            }
			/*
      for (Map<String, Object> mapSerie : lstSerieOld)
      {
        if(mapSerie.get("NUM_CORREDOC").toString().equals(request.getParameter("hdn_num_corredoc").toString())
            && mapSerie.get("NUM_SECSERIE").toString().equals(request.getParameter("hdn_num_secserie").toString()))
        {
          mapSerie.put("lstFacturaSerie", Utilidades.copiarLista((List)lstFacturasSerieAnt));
        }
      }
			 */
            WebUtils.setSessionAttribute(request, "lstDetDeclara", lstSerieOld);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSerieNew);
            //fin de colocacion

            if ("M".equals(accion))
            {
                modelView = new ModelAndView(this.jsonView, "OK", "La factura fue modificada correctamente");
            }
            else if ("A".equals(accion))
            {
                modelView = new ModelAndView(this.jsonView, "OK", "La factura fue agregada correctamente");
            }

        }
        catch (Exception e)
        {

            modelView = new ModelAndView(this.jsonView, "ERROR", e.getMessage());
        }
        return modelView;
    }

    /**
     * Eliminar factura session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView eliminarFacturaSession(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView modelView = null;
        try
        {
            String numSecSerie = request.getParameter("hdn_num_secserie");
            String numSecFacSeleccionado = request.getParameter("hdn_num_secfact");
            String index = request.getParameter("hdn_index");
            HttpSession session = request.getSession();

            List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) session
                    .getAttribute("lstFacturasSerieActual");

            if (!CollectionUtils.isEmpty(lstFacturasSerieActual))
            {
                for (Map<String, Object> mapFacturasSerieActual : lstFacturasSerieActual)
                {
                    if (StringUtils.isEmpty(numSecFacSeleccionado))
                    {
                        if (mapFacturasSerieActual.get("NUM_SECSERIE").toString().equals(numSecSerie)
                                && mapFacturasSerieActual.get("NUM_SECFACT").toString().equals(numSecFacSeleccionado)
                                && mapFacturasSerieActual.get("INDEX").toString().equals(index))
                        {

                            mapFacturasSerieActual.put("IND_DEL", "1"); // eliminado logico
                            break;
                        }
                    }
                    else
                    {
                        if (mapFacturasSerieActual.get("NUM_SECSERIE").toString().equals(numSecSerie)
                                && mapFacturasSerieActual.get("NUM_SECFACT").toString().equals(numSecFacSeleccionado))
                        {

                            mapFacturasSerieActual.put("IND_DEL", "1"); // eliminado logico
                            break;
                        }
                    }
                }
            }
            WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieActual);

            modelView = new ModelAndView(this.jsonView, "OK", "La factura fue eliminada correctamente");
        }
        catch (Exception e)
        {

            modelView = new ModelAndView(this.jsonView, "ERROR", e.getMessage());
        }
        return modelView;
    }

    /**
     * Metodo que nos permite Obtener y mostrar los datos del Certificado de
     * Origen de una determinada Serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarMantCertOrigen(HttpServletRequest request, HttpServletResponse response)
    {

        String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? WebUtils
                .getSessionAttribute(request, "tipoDiligencia")
                .toString() : "";
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> mapCabDeclara = null;
        Map<String, Object> mapCabDeclaraActual = null;
        Map<String, Object> mapCabCertiOrigen = null;

        List<Map<String, Object>> lstCabCertiOrigen = null;
        List<Map<String, Object>> lstDetAutorizacion = null;
        List<Map<String, Object>> lstDocAutAsociado = null;
        Map pkDoc = new HashMap<String, String>();
        Map pkCabCertiOrigen = new HashMap<String, String>();
        Boolean banderaEdicion = false;
        MensajeBean rBean = null;
        StringBuilder acceso = new StringBuilder();
        Date minFec = null;
        List<Map<String, Object>> lstFacturasSerieActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstFacturasSerieActual");
        try
        {
            pkDoc.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));

            pkCabCertiOrigen.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
            pkCabCertiOrigen.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
            acceso.append(webRequest.getParameter("hdn_acceso") != null ? webRequest.getParameter("hdn_acceso").trim() : "");
            mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
            mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            lstCabCertiOrigen = mapCabDeclaraActual.get("lstCabCertiOrigen") != null ? (List<Map<String, Object>>) mapCabDeclaraActual
                    .get("lstCabCertiOrigen") : null;
            lstDetAutorizacion = mapCabDeclaraActual.get("lstDetAutorizacion") != null ? (List<Map<String, Object>>) mapCabDeclaraActual
                    .get("lstDetAutorizacion") : null;
            lstDocAutAsociado = mapCabDeclaraActual.get("lstDocAutAsociado") != null ? (List<Map<String, Object>>) mapCabDeclaraActual
                    .get("lstDocAutAsociado") : null;

            if (CollectionUtils.isEmpty(lstDetAutorizacion))
            {
                // Si no se tienen los DET_AUTORIZACION, obtenemos
                lstDetAutorizacion = serieService.obtenerDetAutorizacion(pkDoc);
                mapCabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
                List<Map<String, Object>> lstDetAutorizacionActual = new ArrayList<Map<String, Object>>();
                if (!CollectionUtils.isEmpty(lstDetAutorizacion))
                {
                    for (Map<String, Object> mapDetAutoriza : lstDetAutorizacion)
                    {
                        lstDetAutorizacionActual.add(Utilidades.copiarMapa(mapDetAutoriza));
                    }
                }
                mapCabDeclaraActual.put("lstDetAutorizacion", lstDetAutorizacionActual);
            }
            else
            {
                boolean existe = false;
                for (Map mapa : lstDetAutorizacion)
                {
                    if (Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN.equals(mapa.get("COD_TIPOPER").toString().trim()))
                    {
                        existe = true;
                        break;
                    }
                }
                if (!existe)
                {
                    List<Map<String, Object>> lista = serieService.obtenerDetAutorizacion(pkDoc);
                    for (Map mapaAux : lista)
                    {
                        Map mapClave = new HashMap();
                        mapClave.put("NUM_CORREDOC", mapaAux.get("NUM_CORREDOC"));
                        mapClave.put("NUM_SECDOC", mapaAux.get("NUM_SECDOC"));
                        mapClave.put("COD_TIPOPER", mapaAux.get("COD_TIPOPER"));
                        // si no esta elelemento se agrega al listado de
                        // documentos autorizantes
                        if (CollectionUtils.isEmpty(Utilidades.obtenerElemento(lstDetAutorizacion, mapClave)))
                        {
                            lstDetAutorizacion.add(mapaAux);
                        }
                    }
                }
            }
            if (CollectionUtils.isEmpty(lstDocAutAsociado))
            {
                // Si no se tienen los DET_AUTORIZACION, obtenemos
                lstDocAutAsociado = declaracionService.obtenerDocAutAsociados(pkDoc);
                mapCabDeclara.put("lstDocAutAsociado", Utilidades.copiarLista((List) lstDocAutAsociado));

                List<Map<String, Object>> lstDocAutAsociadoActual = new ArrayList<Map<String, Object>>();
                if (!CollectionUtils.isEmpty(lstDocAutAsociado))
                {
                    for (Map<String, Object> mapAsocia : lstDocAutAsociado)
                    {
                        lstDocAutAsociadoActual.add(Utilidades.copiarMapa(mapAsocia));
                    }
                }
                mapCabDeclaraActual.put("lstDocAutAsociado", lstDocAutAsociadoActual);
            }
            else
            {
                boolean existe = false;
                for (Map mapa : lstDocAutAsociado)
                {
                    if (Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN.equals(mapa.get("COD_TIPOPER")))
                    {
                        existe = true;
                        break;
                    }
                }
                if (!existe)
                {
                    List<Map<String, Object>> lista = declaracionService.obtenerDocAutAsociados(pkDoc);
                    for (Map mapaAux : lista)
                    {
                        Map mapClave = new HashMap();
                        mapClave.put("NUM_CORREDOC", mapaAux.get("NUM_CORREDOC"));
                        mapClave.put("NUM_SECDOC", mapaAux.get("NUM_SECDOC"));
                        mapClave.put("COD_TIPOPER", mapaAux.get("COD_TIPOPER"));
                        // si no esta elelemento se agrega al listado de
                        // documentos asociados
                        if (CollectionUtils.isEmpty(Utilidades.obtenerElemento(lstDocAutAsociado, mapClave)))
                        {
                            lstDocAutAsociado.add(mapaAux);
                        }
                    }
                }
            }
            if (CollectionUtils.isEmpty(lstCabCertiOrigen))
            {
                // Si no se tienen los CAB_CERTIORIGEN, obtenemos
                lstCabCertiOrigen = declaracionService.obtenerCertOrigen(pkDoc, lstDetAutorizacion);
                mapCabDeclara.put("lstCabCertiOrigen", lstCabCertiOrigen);
                List<Map<String, Object>> lstCabCertiOrigenActual = new ArrayList<Map<String, Object>>();
                if (!CollectionUtils.isEmpty(lstCabCertiOrigen))
                {
                    for (Map<String, Object> mapCerti : lstCabCertiOrigen)
                    {
                        lstCabCertiOrigenActual.add(Utilidades.copiarMapa(mapCerti));
                    }
                }
                mapCabDeclaraActual.put("lstCabCertiOrigen", lstCabCertiOrigenActual);
            }
            if (CollectionUtils.isEmpty(mapCabCertiOrigen))
                mapCabCertiOrigen = obtenerCertificado(
                        (List) mapCabDeclaraActual.get("lstCabCertiOrigen"),
                        (List) mapCabDeclaraActual.get("lstDetAutorizacion"),
                        webRequest.getParameter("hdn_num_secserie"));
            // Seteamos los valores
            request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclaraActual);
            request.getSession().setAttribute("mapCabDeclara", mapCabDeclara);
            // ubicamos mapcabcertiorigen a mostrar

            // Para los estados 04 y 12 de la DUA se podra modificar los Certificados
            // de Origen
            if (mapCabDeclaraActual.get("COD_ESTDUA") != null
                    && ("04".equals(mapCabDeclaraActual.get("COD_ESTDUA").toString().trim()) || "12".equals(mapCabDeclaraActual
                    .get("COD_ESTDUA").toString().trim()))
                    || Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(WebUtils.getSessionAttribute(request, "tipoDiligencia")))
            {
                banderaEdicion = true;
            }
            if ("00".equals(acceso.toString()))
            {
                banderaEdicion = false;
            }
            if (tipoDiligencia.equals("06") || tipoDiligencia.equals("07"))
            {

                JsonSerializer serializer = new JsonSerializer();
                String arrayDETAUTORIZACION = (String) request.getSession().getAttribute("arrayDETAUTORIZACION");
                String arrayDOCASOCIADOS = (String) request.getSession().getAttribute("arrayDOCASOCIADOS");
                String arrayCertOrigen = (String) request.getSession().getAttribute("arrayCertOrigen");
                List<Map<String, Object>> lstDETAUTORIZACION = (List<Map<String, Object>>) serializer
                        .deserialize(arrayDETAUTORIZACION);
                List<Map<String, Object>> lstDOCASOCIADOS = (List<Map<String, Object>>) serializer
                        .deserialize(arrayDOCASOCIADOS);
                List<Map<String, Object>> lstCertOrigen = (List<Map<String, Object>>) serializer.deserialize(arrayCertOrigen);
                Map mKey1 = new HashMap();
                Map mKey2 = new HashMap();
                List<Map<String, Object>> lstCabCertiOrigenActual = (List<Map<String, Object>>) mapCabDeclaraActual
                        .get("lstCabCertiOrigen");
                List<Map<String, Object>> lstDetAutorizacionActual = (List<Map<String, Object>>) mapCabDeclaraActual
                        .get("lstDetAutorizacion");
                List<Map<String, Object>> lstDocAutAsociadoActual = (List<Map<String, Object>>) mapCabDeclaraActual
                        .get("lstDocAutAsociado");

                if (WebUtils.getSessionAttribute(request, "first_time_CO") == null)
                {
                    if (!CollectionUtils.isEmpty(lstCertOrigen))
                    {
                        for (Map mCertOrig : lstCertOrigen)
                        {
                            mKey1 = (Map) serializer.deserialize(mCertOrig.get("DES_CLAVE").toString());
                            Map mapCertOrigExists = Utilidades.obtenerElemento(lstCabCertiOrigenActual, mKey1);

                            if (mapCertOrigExists == null && mCertOrig.get("IND_RECTIFICA").toString().equals("N")
                                    && mKey1.get("COD_TIPOPER").toString().equals("C"))
                            {
                                Map<String, Object> mapCertOrigen = new HashMap<String, Object>();
                                for (Map mCertOrigNew : lstCertOrigen)
                                {
                                    mKey2 = (Map) serializer.deserialize(mCertOrigNew.get("DES_CLAVE").toString());
                                    if (mKey1.get("NUM_CORREDOC").toString().equals(mKey2.get("NUM_CORREDOC").toString()) &&
                                            mKey1.get("COD_TIPOPER").toString().equals(mKey2.get("COD_TIPOPER").toString()) &&
                                            mKey1.get("NUM_SECDOC").toString().equals(mKey2.get("NUM_SECDOC").toString()))
                                    {
                                        mapCertOrigen.put(mCertOrigNew.get("CAMPO").toString(), mCertOrigNew.get("VALOR2R"));
                                    }
                                }
                                mapCertOrigen.putAll(mKey1);
                                mapCertOrigen.put("NUM_SECDOC", mKey1.get("NUM_SECDOC").toString());
                                lstCabCertiOrigenActual.add(mapCertOrigen);
                            }
                            else
                            {
                                if (mapCertOrigExists != null && mCertOrig.get("IND_RECTIFICA").toString().equals("R")
                                        && mKey1.get("COD_TIPOPER").toString().equals("C"))
                                {
                                    for (Map mCertOrigAct : lstCabCertiOrigenActual)
                                    {
                                        if (mKey1.get("NUM_CORREDOC").toString().equals(mCertOrigAct.get("NUM_CORREDOC").toString()) &&
                                                mKey1.get("COD_TIPOPER").toString().equals(mCertOrigAct.get("COD_TIPOPER").toString()) &&
                                                mKey1.get("NUM_SECDOC").toString().equals(mCertOrigAct.get("NUM_SECDOC").toString()))
                                        {
                                            mCertOrigAct.put(mCertOrig.get("CAMPO").toString(), mCertOrig.get("VALOR2R"));
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(lstDOCASOCIADOS))
                    {
                        for (Map mDocAsoc : lstDOCASOCIADOS)
                        {
                            mKey1 = (Map) serializer.deserialize(mDocAsoc.get("DES_CLAVE").toString());
                            Map mapDocAsocExists = Utilidades.obtenerElemento(lstDocAutAsociadoActual, mKey1);
                            if (mapDocAsocExists == null && mDocAsoc.get("IND_RECTIFICA").toString().equals("N"))
                            {
                                Map<String, Object> mapDocAsoc = new HashMap<String, Object>();
                                for (Map mDocAsocNew : lstDOCASOCIADOS)
                                {
                                    mKey2 = (Map) serializer.deserialize(mDocAsocNew.get("DES_CLAVE").toString());
                                    if (mKey1.get("NUM_CORREDOC").toString().equals(mKey2.get("NUM_CORREDOC").toString()) &&
                                            mKey1.get("COD_TIPOPER").toString().equals(mKey2.get("COD_TIPOPER").toString()) &&
                                            mKey1.get("NUM_SECDOC").toString().equals(mKey2.get("NUM_SECDOC").toString()))
                                    {
                                        mapDocAsoc.put(mDocAsocNew.get("CAMPO").toString(), mDocAsocNew.get("VALOR2R"));
                                    }
                                }
                                mapDocAsoc.putAll(mKey1);
                                lstDocAutAsociadoActual.add(mapDocAsoc);
                            }
                            else
                            {
                                if (!CollectionUtils.isEmpty(mapDocAsocExists)
                                        && Constantes.COD_RECTI_RECTIFICA.equals(mDocAsoc.get("IND_RECTIFICA").toString()))
                                {
                                    for (Map mDocAsocAct : lstDocAutAsociadoActual)
                                    {
                                        if (mKey1.get("NUM_CORREDOC").toString().equals(mDocAsocAct.get("NUM_CORREDOC").toString()) &&
                                                mKey1.get("COD_TIPOPER").toString().equals(mDocAsocAct.get("COD_TIPOPER").toString()) &&
                                                mKey1.get("NUM_SECDOC").toString().equals(mDocAsocAct.get("NUM_SECDOC").toString()))
                                        {
                                            mDocAsocAct.put(mDocAsoc.get("CAMPO").toString(), mDocAsoc.get("VALOR2R"));
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(lstDETAUTORIZACION))
                    {
                        for (Map mDetAut : lstDETAUTORIZACION)
                        {
                            mKey1 = (Map) serializer.deserialize(mDetAut.get("DES_CLAVE").toString());
                            Map mapCertOrigExists = Utilidades.obtenerElemento(lstDetAutorizacionActual, mKey1);
                            if (CollectionUtils.isEmpty(mapCertOrigExists)
                                    && Constantes.COD_RECTI_NUEVO.equals(mDetAut.get("IND_RECTIFICA").toString()))
                            {
                                lstDetAutorizacionActual.add(mKey1);
                            }
                        }
                    }
                }
                mapCabCertiOrigen = obtenerCertificado(
                        lstCabCertiOrigenActual,
                        lstDetAutorizacionActual,
                        webRequest.getParameter("hdn_num_secserie"));
            }
            if (CollectionUtils.isEmpty(mapCabCertiOrigen))
            {
                rBean = new MensajeBean();
                rBean.setMensajeerror("No se encontraron datos de Certificado de Origen asociado a la Serie.");
                rBean.setMensajesol("");
                if (banderaEdicion)
                {
                    // es edicion, se muestra el mensaje en la pagina de
                    // mantenimiento de certificado
                    mapCabCertiOrigen = new HashMap<String, Object>();
                }
                else
                {
                    // No es edicion se muestra la ventana de mensajes
                    return new ModelAndView("PagM", "beanM", rBean);
                }
            }
            else
            {
                // muestro las series relacionadas al certificado de origen, pero solo
                // las que estan activas
                // en det_autorizacion
                String seriesAsociadas = "";
                StringBuilder seriesEliminadas = new StringBuilder();
                StringBuilder seriesActivas = new StringBuilder();
                for (Map<String, Object> mapaDet : lstDetAutorizacion)
                {
                    if (Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN.equals(mapaDet.get("COD_TIPOPER").toString())
                            && mapCabCertiOrigen.get("NUM_SECDOC").toString().equals(mapaDet.get("NUM_SECDOC").toString()))
                    {
                        // relaciones activas
                        if ("0".equals(mapaDet.get("IND_DEL") != null ? mapaDet.get("IND_DEL").toString() : "0"))
                        {
                            if (0 == seriesActivas.toString().trim().length())
                            {
                                seriesActivas.append(mapaDet.get("NUM_SECSERIE").toString());
                            }
                            else
                            {
                                seriesActivas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());
                            }
                        }
                        else
                        {// eliminadas
                            if (0 == seriesEliminadas.toString().trim().length())
                            {
                                seriesEliminadas.append(mapaDet.get("NUM_SECSERIE").toString());
                            }
                            else
                            {
                                seriesEliminadas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());

                            }

                        }

                    }
                }
                if (seriesActivas.toString().trim().length() > 0)
                {
                    seriesAsociadas = seriesAsociadas + "Activas:".concat(seriesActivas.toString());
                }
                if (seriesEliminadas.toString().trim().length() > 0)
                {
                    seriesAsociadas = seriesAsociadas + " Eliminadas:".concat(seriesEliminadas.toString());

                }
                mapCabCertiOrigen.put("SERIES", seriesAsociadas);
            }

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cod_aduana", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_ADUANA").toString() : "");
            params.put("ann_presen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("ANN_PRESEN").toString() : "");
            params.put("cod_regimen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_REGIMEN").toString() : "");
            params.put("num_declaracion", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("NUM_DECLARACION").toString()
                    : "");
            params.put("num_corredoc", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("NUM_CORREDOC").toString() : "");
            params.put("num_secserie", webRequest.getParameter("hdn_num_secserie"));
            if (CollectionUtils.isEmpty(lstFacturasSerieActual))
            {
                List lstFacturasSerie = formatoValorService.obtenerFacturasSerie(params);
                WebUtils.setSessionAttribute(request, "lstFacturasSerie", lstFacturasSerie);
                lstFacturasSerieActual = new ArrayList<Map<String, Object>>();
                if (!CollectionUtils.isEmpty(lstFacturasSerie))
                {
                    lstFacturasSerieActual.addAll(Utilidades.copiarLista(lstFacturasSerie));
                }
                WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", lstFacturasSerieActual);
            }
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

            if (!CollectionUtils.isEmpty(lstFacturasSerieActual))
            {
                if (lstFacturasSerieActual.get(0).get("FEC_FACT").getClass().getName().equals("java.lang.String"))
                {
                    Date fecha = Utilidades.convertirFormatoStringToDate(lstFacturasSerieActual.get(0).get("FEC_FACT").toString());
                    String fechStr = df.format(fecha);
                    minFec = df.parse(fechStr);
                }
                else
                {
                    minFec = (Date) lstFacturasSerieActual.get(0).get("FEC_FACT");
                }
                Date temp;
                for (Map mapFactura : lstFacturasSerieActual)
                {
                    if (mapFactura.get("FEC_FACT").getClass().getName().equals("java.lang.String"))
                    {
                        Date fecha = Utilidades.convertirFormatoStringToDate(mapFactura.get("FEC_FACT").toString());
                        String fechStr = df.format(fecha);
                        temp = df.parse(fechStr);

                    }
                    else
                    {
                        temp = (Date) mapFactura.get("FEC_FACT");
                    }
                    if (temp.before(minFec))
                    {
                        minFec = (Date) mapFactura.get("FEC_FACT");
                    }
                }
            }
            else
            {
                minFec = (Date) df.parse("01/01/0001");
            }

        }
        catch (ServiceException e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean
                    .setMensajesol("Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean
                    .setMensajesol("Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }


        /* INICIO-PAS20134E610000153 */
        if ("10".equals(tipoDiligencia))
        {

            if (mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                    && "EN_PROCESO".equals(mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
            {
                banderaEdicion = true;
            }
            else
            {
                banderaEdicion = false;
            }
        }

        /*FIN-PAS20134E610000153*/


        ModelAndView view = banderaEdicion == true ? new ModelAndView("MantCertOrigen", "certificadoOrigenJSON", SojoUtil
                .toJson(mapCabCertiOrigen)) : new ModelAndView("MantCertOrigenNoEdicion", "certificadoOrigenJSON", SojoUtil
                .toJson(mapCabCertiOrigen));
        view.addObject("tipoCertificadoOrigen", SojoUtil.toJson(catalogoAyudaService.getElementosCat("1H")));
        view.addObject("tipoEmisorCertificadoOrigen", SojoUtil.toJson(catalogoAyudaService.getElementosCat("1I")));
        view.addObject("criterioOrigenCertificado", SojoUtil.toJson(catalogoAyudaService.getElementosCat("1J")));
        view.addObject("certificadoOrigen", mapCabCertiOrigen);

        view.addObject("hdn_num_corredoc", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("NUM_CORREDOC").toString()
                : "");
        view.addObject("hdn_cod_aduana", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_ADUANA").toString()
                : "");
        view.addObject("hdn_ann_presen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("ANN_PRESEN").toString()
                : "");
        view.addObject("hdn_cod_regimen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_REGIMEN").toString()
                : "");
        view.addObject("hdn_num_declaracion", mapCabDeclaraActual != null ? mapCabDeclaraActual
                .get("NUM_DECLARACION")
                .toString() : "");
        view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));
        view.addObject("existeCertificado", mapCabCertiOrigen.size() > 0 ? "1" : "0");

        // validacion fe fechas en el formulario para todas las diligencias
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        view.addObject("fec_declaracion", df.format(mapCabDeclaraActual.get("FEC_DECLARACION")));
        view.addObject("min_fec_facturas", df.format(minFec));
        WebUtils.setSessionAttribute(request, "first_time_CO", "false");

        if (rBean != null)
        {
            view.addObject("beanM", rBean);
        }

        return view;
    }


    /** DZC ISC Licores
     * Validacion de ISC Licores.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarTnanByPartida(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(
                request,
                "mapCabDeclaraActual");
        FechaBean fechaBean = new FechaBean((java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));

        String tnan=request.getParameter("sel_cod_tiptasaaplicar").toString();
        String num_partnandi=request.getParameter("num_partnandi").toString();
        Map<String, Object> mapResultado = new HashMap<String, Object>();

        if (tnan==null) tnan="";
        //Revisa si la partida es de Licores e ISC
        Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION")
                .toString());
        String regimen=mapCabDeclara.get("COD_REGIMEN").toString();
        boolean EsLicores=validaContingenteService.EsPartidaLicores(num_partnandi,fechaVigenciaPartida,regimen);
        String error="";
        mapResultado.put("mensaje","");

        if(EsLicores)
        {
            if (tnan.equals(""))
            {
                mapResultado.put("mensaje", "Partida "+num_partnandi+" corresponde a licores. Debe declarar el Tipo de Tasa a Aplicar (TNAN) 01, 02 o 03");
                error="1";
            }
            else
            {
                if(!(tnan.equals("01") || tnan.equals("02") || tnan.equals("03")))
                {
                    mapResultado.put("mensaje", "Partida"+num_partnandi+"Partida "+num_partnandi+" corresponde a licores. Debe declarar el Tipo de Tasa a Aplicar (TNAN) 01, 02 o 03. Valor declarado :"+tnan);
                    error="1";
                }
            }

        }

        ModelAndView view = new ModelAndView(this.jsonView, "existeTnan", mapResultado);
        view.addObject("mensaje", mapResultado.get("mensaje").toString());
        view.addObject("validaTnan", error);

        return view;
    }


    /**  DZC ISC Licores
     * Metodo que nos permite Obtener y mostrar los datos del Certificado de
     * Origen de una determinada Serie.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */

    public ModelAndView cargarMantTnan(HttpServletRequest request, HttpServletResponse response)
    {

        MensajeBean rBean = null;
        Map<String, Object> maptnan = new HashMap();
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map mapCabDeclaraActual = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        String fechaDeclaracion="";
        String numPartida="";
        double Pventa=0.0;
        String strtnan="";
        //string Pventa="0.0";

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
            params.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));

            numPartida=request.getParameter("txt_num_partnandi").toString();

            List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                    "lstDetDeclaraActual");
            Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);

            //numPartida = detDeclaraViewMap.get("NUM_PARTNANDI")!=null?detDeclaraViewMap.get("NUM_PARTNANDI").toString():"";
            Pventa = detDeclaraViewMap.get("MTO_PVPMONNAC")!=null?Double.valueOf(detDeclaraViewMap.get("MTO_PVPMONNAC").toString()):0.0;
            strtnan=(String) request.getParameter("hdn_tnan");
            //Revisa si la partida es de Licores e ISC
            Map mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION")
                    .toString());

            String regimen=mapCabDeclara.get("COD_REGIMEN").toString();

            boolean EsLicores=validaContingenteService.EsPartidaLicores(numPartida,fechaVigenciaPartida,regimen);
            //EsLicores=true;
            if(!EsLicores)
            {
                rBean = new MensajeBean();
                rBean.setError(true);
                rBean.setMensajeerror("La partida No es de Licores");
                rBean.setMensajesol("La partida No es de Licores");
                return new ModelAndView("PagM", "beanM", rBean);

            }


        }
        catch (ServiceException e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean
                    .setMensajesol("Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean
                    .setMensajesol("Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }

        maptnan.put("TNAN", strtnan);
        maptnan.put("RANGO", "02");
        maptnan.put("PVENTA", Pventa);

        ModelAndView view = new ModelAndView("MantTnan", "MantTnanJson",  SojoUtil.toJson(maptnan));


        view.addObject("hdn_num_corredoc", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("NUM_CORREDOC").toString()
                : "");
        view.addObject("hdn_cod_aduana", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_ADUANA").toString()
                : "");
        view.addObject("hdn_ann_presen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("ANN_PRESEN").toString()
                : "");
        view.addObject("hdn_cod_regimen", mapCabDeclaraActual != null ? mapCabDeclaraActual.get("COD_REGIMEN").toString()
                : "");
        view.addObject("hdn_num_declaracion", mapCabDeclaraActual != null ? mapCabDeclaraActual
                .get("NUM_DECLARACION")
                .toString() : "");
        view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));

        view.addObject("tnan", maptnan);

        view.addObject("strtnan", strtnan);
        view.addObject("strpartida", numPartida);

        return view;
    }


    /**  DZC ISC Licores
     * Metodo que nos permite actualizar los valores de Certificados de Origen y
     * las listas involucradas dentro de session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView modificarPventaSession(HttpServletRequest request, HttpServletResponse response)
    {

        MensajeBean rBean;
        Object objRes = null;
        String objName = "resultado";
        Map<String, Object> res = new HashMap();
        String strpventa="";
        HttpSession session = request.getSession();

        try
        {

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
            params.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
            List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                    "lstDetDeclaraActual");
            Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);

            // Seteamos el valor en el mapa
            strpventa=(String) request.getParameter("hdn_pventa");
            detDeclaraViewMap.put("MTO_PVPMONNAC", strpventa);

            String numserie=(String)request.getParameter("hdn_num_secserie").toString();
            int i=0;
            for (Map<String, Object> mapSerie : detDeclaraViewList)
            {
                String numserieEjec=(String)mapSerie.get("NUM_SECSERIE").toString();
                if(numserieEjec.trim().equals(numserie.trim()))
                {
                    detDeclaraViewList.get(i).put("MTO_PVPMONNAC", strpventa);
                }
                i=i+1;
            }

            session.setAttribute("lstDetDeclaraActual", detDeclaraViewList);

            res.put("res_ok", "La transacci�n se realiz� correctamente");
            objRes = res;
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            objName = "beanM";
            objRes = rBean;
        }
        finally
        {
        }
        return new ModelAndView(this.jsonView, objName, objRes);
    }



    /**
     * Metodo que obtiene el certificado a mostrar en base a una Serie, se
     * mantiene el criterio de una serie a un certificado.
     *
     * @param lstCertificados
     *          the lst certificados
     * @param lstDetAutoriza
     *          the lst det autoriza
     * @param sSerie
     *          the s serie
     * @return the map
     */
    private Map<String, Object> obtenerCertificado(
            List<Map<String, Object>> lstCertificados,
            List<Map<String, Object>> lstDetAutoriza,
            String sSerie)
    {

        Map<String, Object> mapCertificado = new HashMap<String, Object>();
        Map<String, Object> mapClave = new HashMap<String, Object>();
        boolean banderaEs = false;
        // Seteamos Key para CabCertiOrigen
        mapClave.put("NUM_CORREDOC", "");
        mapClave.put("NUM_SECDOC", "");
        mapClave.put("COD_TIPOPER", "");
        // obtenemos pk en base a la serie, se mantiene que serie es a un
        // certificado solamente.
        for (Map<String, Object> mapa : lstDetAutoriza)
        {

            if (sSerie.trim().equals(mapa.get("NUM_SECSERIE").toString().trim())
                    && mapa.get("COD_TIPOPER").toString().trim().equals(Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN))
            {

                for (Entry<String, Object> entrada : mapClave.entrySet())
                {
                    mapClave.put(entrada.getKey(), mapa.get(entrada.getKey()));
                }
            }
        }
        // obtenemos certificado a mostrar
        for (Map<String, Object> mapa : lstCertificados)
        {
            for (Entry<String, Object> entrada : mapClave.entrySet())
            {
                if (entrada.getValue().toString().trim().equals(mapa.get(entrada.getKey()).toString().trim()))
                {
                    banderaEs = true;
                }
                else
                {
                    banderaEs = false;
                    break;
                }
            }
            if (banderaEs)
            {
                mapCertificado.clear();
                mapCertificado.putAll(mapa);
                banderaEs = false;
                break;
            }
            banderaEs = false;
        }


        return mapCertificado;
    }

    /**
     * Metodo que nos permite actualizar los valores de Certificados de Origen y
     * las listas involucradas dentro de session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView modificarCertOrigenSession(HttpServletRequest request, HttpServletResponse response)
    {

        MensajeBean rBean;
        Object objRes = null;
        String objName = "resultado";
        Map<String, Object> res = new HashMap();
        try
        {
            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute(
                    "mapCabDeclaraActual");

            List<Map<String, Object>> lstCabCertificados = (List<Map<String, Object>>) mapCabDeclaraActual
                    .get("lstCabCertiOrigen");
            Map<String, Object> mapCetificadoEnviado = this.setearCertificado(request);
            for (int i = 0; i < lstCabCertificados.size(); i++)
            {
                Map<String, Object> mapCabCertificado = lstCabCertificados.get(i);
                if (mapCetificadoEnviado.get("NUM_CORREDOC").toString().trim().equals(
                        mapCabCertificado.get("NUM_CORREDOC").toString().trim())
                        && mapCetificadoEnviado.get("NUM_SECDOC").toString().trim().equals(
                        mapCabCertificado.get("NUM_SECDOC").toString().trim())
                        && mapCetificadoEnviado.get("COD_TIPOPER").toString().trim().equals(
                        mapCabCertificado.get("COD_TIPOPER").toString().trim()))
                {

                    lstCabCertificados.get(i).putAll(mapCetificadoEnviado);
                }
            }
            res.put("res_ok", "La transacci�n se realiz� correctamente");
            objRes = res;
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            objName = "beanM";
            objRes = rBean;
        }
        finally
        {
        }
        return new ModelAndView(this.jsonView, objName, objRes);
    }

    /**
     * Metodo que nos permite setear en Map los valores del certificado enviado y
     * setea los IND_DEL segun el tipo de eliminacion. Se registra los datos
     * eliminados tanto en lstDetAutorizacion como en lstDocuAutAsociado.
     *
     * @param request
     *          the request
     * @return the map
     */
    private Map<String, Object> setearCertificado(HttpServletRequest request)
    {

        Map<String, Object> mapClave = new HashMap<String, Object>();
        Map<String, Object> mapCertificadoActual = new HashMap<String, Object>();
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        mapClave.put("NUM_SECDOC", request.getParameter("hdn_num_secdoc"));
        mapClave.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
        mapClave.put("COD_TIPOPER", request.getParameter("hdn_cod_tipoper"));
        mapCertificadoActual.putAll(mapClave);
        // cuando es modificar
        if ("0".equals(request.getParameter("eliminaFull")))
        {

            mapCertificadoActual.put("IND_DEL", "0");
            mapCertificadoActual.put("NUM_CERTIFICADO", request.getParameter("txt_numCertorigen"));
            mapCertificadoActual.put("FEC_CERTIFICADO", request.getParameter("txt_fechaEmision"));
            mapCertificadoActual.put("COD_TIPCERTIFICADO", request.getParameter("txt_codTipoCO"));
            mapCertificadoActual.put("FEC_INIPERIODOEMB", request.getParameter("txt_inicioEmbar"));
            mapCertificadoActual.put("FEC_FINPEREMB", request.getParameter("txt_terminoEmbar"));
            mapCertificadoActual.put("COD_EMISCERT", request.getParameter("txt_tipoemisor"));
            mapCertificadoActual.put("NOM_EMISCERTIF", request.getParameter("txt_nombreEmisor"));
            mapCertificadoActual.put("COD_CRITERIOORIGEN", request.getParameter("txt_criterioorigen"));
            mapCertificadoActual.put("NOM_PRODMERC", request.getParameter("txt_nombreProductor"));
            mapCertificadoActual.put("NOM_PROVE", request.getParameter("txt_nombreProveedor"));
            mapCertificadoActual.put("FEC_EMBORIGEN", request.getParameter("txt_fechaEmbar"));

            // parche momentanea para CertOrigen de la diligencia no para
            // regularizacion
            if ("1".equals(request.getParameter("diligenciaDespacho")))
            {

                mapCertificadoActual.put("FEC_CERTIFICADO", request.getParameter("fechaEmision"));
                mapCertificadoActual.put("FEC_INIPERIODOEMB", request.getParameter("inicioEmbar"));
                mapCertificadoActual.put("FEC_FINPEREMB", request.getParameter("terminoEmbar"));
                mapCertificadoActual.put("FEC_EMBORIGEN", request.getParameter("fechaEmbar"));
            }

            // TERCER PAIS
            mapCertificadoActual.put("IND_PROCETERCERPAIS", "1");
            if (request.getParameter("txt_otroPais") != null && "on".equals(request.getParameter("txt_otroPais")))
            {
                mapCertificadoActual.put("IND_PROCETERCERPAIS", "2");
            }
            if ("".equals(request.getParameter("hdn_num_secdoc")))
            {
                mapCertificadoActual.put("COD_FFCO", bUsuario.getNroRegistro());

                String VARIABLE_INCREMENTAL = "incrementalDocumentosAsociados";

                String VARIABLE_INICIO_INCREMENTAL = String.valueOf(((List<Map<String, Object>>) ((Map<String, Object>) request
                        .getSession()
                        .getAttribute("mapCabDeclaraActual")).get("lstCabCertiOrigen")).size());

                String sIncremental = request.getSession().getAttribute(VARIABLE_INCREMENTAL) != null ? request
                        .getSession()
                        .getAttribute(VARIABLE_INCREMENTAL)
                        .toString() : VARIABLE_INICIO_INCREMENTAL;
                int incremental = Integer.parseInt(sIncremental) + 1;
                request.getSession().setAttribute(VARIABLE_INCREMENTAL, incremental + "");
                mapCertificadoActual.put("NUM_SECDOC", incremental + "");


                ((List<Map<String, Object>>) ((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual"))
                        .get("lstCabCertiOrigen")).add(mapCertificadoActual);

                Map<String, Object> mapDocAutAsociado = new HashMap<String, Object>();
                // Seteamos a la clave si no no hya relacion entre los documentos.
                mapClave.put("NUM_SECDOC", incremental + "");
                mapDocAutAsociado.putAll(mapClave);
                mapDocAutAsociado.put("IND_DEL", "0");


                if (((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual")).get("lstDocAutAsociado") == null)
                {
                    ((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual")).put(
                            "lstDocAutAsociado",
                            new ArrayList<Map<String, Object>>());
                }
                ((List<Map<String, Object>>) ((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual"))
                        .get("lstDocAutAsociado")).add(mapDocAutAsociado);

                Map<String, Object> mapDetAutorizacion = new HashMap<String, Object>();
                mapDetAutorizacion.putAll(mapClave);
                mapDetAutorizacion.put("IND_DEL", "0");
                mapDetAutorizacion.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
                if (((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual")).get("lstDetAutorizacion") == null)
                {
                    ((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual")).put(
                            "lstDetAutorizacion",
                            new ArrayList<Map<String, Object>>());
                }

                ((List<Map<String, Object>>) ((Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual"))
                        .get("lstDetAutorizacion")).add(mapDetAutorizacion);
            }

        }
        else
        {
            // Para "2": "Elimina Todas" se coloca al Certificado en Eliminado,
            // para "1" se verificara si es el unico certificado en caso ser unico se
            // coloca IND_DEL en "1"

            mapCertificadoActual.put("IND_DEL", "1");
            if ("1".equals(request.getParameter("eliminaFull")))
            {

                boolean banderaUnico = true;
                int contadorCertificados = 0;
                // Verificamos si en DET_AUTORIZACION existen mas de un vinculo con las
                // series para el certificado mediante la
                // PK de docAutAsociado y que no este eliminado.

                for (Map<String, Object> mapa : (List<Map<String, Object>>) ((Map<String, Object>) request.getSession()
                        .getAttribute("mapCabDeclaraActual")).get("lstDetAutorizacion"))
                {

                    if (mapCertificadoActual.get("NUM_SECDOC").toString().trim().equals(mapa.get("NUM_SECDOC").toString().trim())
                            && mapCertificadoActual
                            .get("NUM_CORREDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && mapCertificadoActual
                            .get("COD_TIPOPER")
                            .toString()
                            .trim()
                            .equals(mapa.get("COD_TIPOPER").toString().trim())
                            && "0".equals(mapa.get("IND_DEL") == null ? "0" : mapa.get("IND_DEL").toString().trim()))
                    {
                        contadorCertificados++;
                        if (contadorCertificados >= 2)
                        {
                            banderaUnico = false;
                            break;
                        }
                    }
                }

                if (!banderaUnico)
                {
                    // si tiene mas de 2 relaciones activas no borro el certificado
                    mapCertificadoActual.put("IND_DEL", "0");

                }
                else
                {// si es unico debo borrar certificado y DOCAUT_ASOCIADO
                    mapCertificadoActual.put("IND_DEL", "1");

                    // DOCAUT_ASOCIADO
                    for (Map<String, Object> mapa : ((List<Map<String, Object>>) ((Map<String, Object>) request
                            .getSession()
                            .getAttribute(
                                    "mapCabDeclaraActual")).get("lstDocAutAsociado")))
                    {
                        // Se compara la clave de DET_AUTORIZACION y que no este eliminada,
                        // se setea a "1" el registro que cumple, no es necesario la SERIE
                        if (mapCertificadoActual
                                .get("NUM_CORREDOC")
                                .toString()
                                .trim()
                                .equals(mapa.get("NUM_CORREDOC").toString().trim())
                                && mapCertificadoActual
                                .get("NUM_SECDOC")
                                .toString()
                                .trim()
                                .equals(mapa.get("NUM_SECDOC").toString().trim())
                                && mapCertificadoActual
                                .get("COD_TIPOPER")
                                .toString()
                                .trim()
                                .equals(mapa.get("COD_TIPOPER").toString().trim())
                                && "0".equals(mapa.get("IND_DEL") == null ? "0" : mapa.get("IND_DEL").toString().trim()))
                        {
                            mapa.put("IND_DEL", "1");
                        }
                    }

                }
                // pero si debo borrar la relacion en DET_AUTORIZACION se ha unico o no
                for (Map<String, Object> mapa : ((List<Map<String, Object>>) ((Map<String, Object>) request
                        .getSession()
                        .getAttribute(
                                "mapCabDeclaraActual")).get("lstDetAutorizacion")))
                {
                    // Se compara la clave de DET_AUTORIZACION y que no este eliminada,
                    // se setea a "1" el registro que cumple
                    if (mapCertificadoActual
                            .get("NUM_CORREDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && mapCertificadoActual
                            .get("NUM_SECDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_SECDOC").toString().trim())
                            && request.getParameter("hdn_num_secserie").trim().equals(mapa.get("NUM_SECSERIE").toString().trim())
                            && mapCertificadoActual
                            .get("COD_TIPOPER")
                            .toString()
                            .trim()
                            .equals(mapa.get("COD_TIPOPER").toString().trim())
                            && "0".equals(mapa.get("IND_DEL") == null ? "0" : mapa.get("IND_DEL").toString().trim()))
                    {
                        mapa.put("IND_DEL", "1");
                        break;// es unico
                    }
                }
            }
            else if ("2".equals(request.getParameter("eliminaFull")))
            {

                // Si es eliminacion FULL se realiza en DET_AUTORIZACION y
                // DOCAUT_ASOCIADO
                // DET_AUTORIZACION
                for (Map<String, Object> mapa : ((List<Map<String, Object>>) ((Map<String, Object>) request
                        .getSession()
                        .getAttribute(
                                "mapCabDeclaraActual")).get("lstDetAutorizacion")))
                {
                    // Se compara la clave de DET_AUTORIZACION y que no este eliminada,
                    // se setea a "1" el registro que cumple, no es necesario la SERIE
                    if (mapCertificadoActual
                            .get("NUM_CORREDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && mapCertificadoActual
                            .get("NUM_SECDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_SECDOC").toString().trim())
                            && mapCertificadoActual
                            .get("COD_TIPOPER")
                            .toString()
                            .trim()
                            .equals(mapa.get("COD_TIPOPER").toString().trim())
                            && "0".equals(mapa.get("IND_DEL") == null ? "0" : mapa.get("IND_DEL").toString().trim()))
                    {
                        mapa.put("IND_DEL", "1");
                    }
                }
                // DOCAUT_ASOCIADO
                for (Map<String, Object> mapa : ((List<Map<String, Object>>) ((Map<String, Object>) request
                        .getSession()
                        .getAttribute(
                                "mapCabDeclaraActual")).get("lstDocAutAsociado")))
                {
                    // Se compara la clave de DET_AUTORIZACION y que no este eliminada,
                    // se setea a "1" el registro que cumple, no es necesario la SERIE
                    if (mapCertificadoActual
                            .get("NUM_CORREDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && mapCertificadoActual
                            .get("NUM_SECDOC")
                            .toString()
                            .trim()
                            .equals(mapa.get("NUM_SECDOC").toString().trim())
                            && mapCertificadoActual
                            .get("COD_TIPOPER")
                            .toString()
                            .trim()
                            .equals(mapa.get("COD_TIPOPER").toString().trim())
                            && "0".equals(mapa.get("IND_DEL") == null ? "0" : mapa.get("IND_DEL").toString().trim()))
                    {
                        mapa.put("IND_DEL", "1");
                    }
                }
            }
        }

        return mapCertificadoActual;
    }

    /**
     * Metodo que nos permite obtener los items de un documento determinado.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarFormatoBItem(HttpServletRequest request, HttpServletResponse response)
    {

        ServletWebRequest webRequest = new ServletWebRequest(request);
        List<Map<String, Object>> lstItemFactura = null;
        List<Map<String, Object>> lstReferenciaDuda = null;
        List<Map<String, Object>> lstSeriesItem = null;

        Map<String, Object> mapCabDeclara = null;
        //Map<String, Object> mapCabDeclaraActual = null;
        Map PkFact = new HashMap<String, String>();
        StringBuilder sNumeroFactura = new StringBuilder();

        StringBuilder sCodAduana = new StringBuilder();
        StringBuilder sAnnPresen = new StringBuilder();
        StringBuilder sCodRegimen = new StringBuilder();
        StringBuilder sNumDeclaracion = new StringBuilder();

        MensajeBean rBean = null;
        try
        {
            PkFact.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
            PkFact.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
            PkFact.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));

            //mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            mapCabDeclara       = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            if (mapCabDeclara != null && mapCabDeclara.size() > 0)
            {

                sCodAduana.append(mapCabDeclara.get("COD_ADUANA").toString().trim());
                sAnnPresen.append(mapCabDeclara.get("ANN_PRESEN").toString().trim());
                sCodRegimen.append(mapCabDeclara.get("COD_REGIMEN").toString().trim());
                sNumDeclaracion.append(mapCabDeclara.get("NUM_DECLARACION").toString().trim());

                // if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor")))
                if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstFormBProveedor")))
                {

                    for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor"))
                    {

                        if (PkFact.get("NUM_SECPROVE").toString().trim().equals(mapa.get("num_secprove").toString().trim()))
                        {
                            if (!CollectionUtils.isEmpty((List) mapa.get("lstComproBPago")))
                            {
                                for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapa.get("lstComproBPago"))
                                {
                                    if (PkFact.get("NUM_SECFACT").toString().trim().equals(mapaFactura.get("num_secfact").toString().trim()))
                                    {
                                        lstItemFactura = (List<Map<String, Object>>) mapaFactura.get("lstItemFactura");
                                        sNumeroFactura.append(mapaFactura.get("num_fact").toString().trim());
                                    }
                                }
                            }
                            else
                            {
                                // No existen facturas
                                rBean = new MensajeBean();
                                rBean.setMensajeerror("No se encontraron Facturas en session.");
                                rBean.setMensajesol("");
                                return new ModelAndView("PagM", "beanM", rBean);
                            }
                        }
                    }
                }
                else
                {
                    // No existen proveedores en session
                    rBean = new MensajeBean();
                    rBean.setMensajeerror("No se encontraron Proveedores en session.");
                    rBean.setMensajesol("");
                    return new ModelAndView("PagM", "beanM", rBean);
                }
            }

            //si es vacio el item seleccionado lo carga de BD solo lo carga la primera vez y lo pone en memoria
            if (CollectionUtils.isEmpty(lstItemFactura))
            {

                PkFact.put("caduana", soporteService.obtenerAduana(request));
                Map<String, Object> mapa = formatoValorService.obtenerFormatoBItem(PkFact);
                lstItemFactura = (List<Map<String, Object>>) mapa.get("lstItemFactura");
                lstReferenciaDuda = (List<Map<String, Object>>) mapa.get("lstReferenciaDuda");
                lstSeriesItem = (List<Map<String, Object>>) mapa.get("lstSeriesItem");
                List lstItemFacturaAnterior = new ArrayList<Map<String, Object>>();
                for (int i = 0; i < lstItemFactura.size(); i++)
                {

                    lstItemFacturaAnterior.add(Utilidades.copiarMapa(lstItemFactura.get(i)));
                    for (Map<String, Object> mapaSerie : lstSeriesItem)
                    {
                        // LA serie es la misma de la lista de items
                        if (lstItemFactura.get(i).get("NUM_SECITEM").toString().trim()
                                .equals(
                                        mapaSerie.get("NUM_SECITEM").toString().trim()))
                        {
                            // No se posee lista de Series Item
                            if (CollectionUtils.isEmpty((List) lstItemFactura.get(i).get("lstSeriesItem")))
                            {
                                lstItemFactura.get(i).put("lstSeriesItem", new ArrayList<Map<String, Object>>());
                                ((List<Map<String, Object>>) lstItemFactura.get(i).get("lstSeriesItem")).add(mapaSerie);
                            }
                            else
                            {
                                // Si se posee entonces se compara con las
                                // No hay duplicados se setea directo
                                ((List<Map<String, Object>>) lstItemFactura.get(i).get("lstSeriesItem")).add(mapaSerie);

                            }
                        }
                    }
                    for (Map<String, Object> mapaReferencia : lstReferenciaDuda)
                    {
                        // LA serie es la misma de la lista de items
                        if (lstItemFactura.get(i).get("NUM_SECITEM").toString().trim()
                                .equals(
                                        mapaReferencia.get("NUM_SECITEM").toString().trim()))
                        {
                            // No se posee lista de Series Item
                            if (CollectionUtils.isEmpty((List) lstItemFactura.get(i).get("lstReferenciaDuda")))
                            {
                                lstItemFactura.get(i).put("lstReferenciaDuda", new ArrayList<Map<String, Object>>());
                                ((List<Map<String, Object>>) lstItemFactura.get(i).get("lstReferenciaDuda")).add(mapaReferencia);
                            }
                            else
                            {
                                ((List<Map<String, Object>>) lstItemFactura.get(i).get("lstReferenciaDuda")).add(mapaReferencia);
                            }
                        }
                    }
                }
                // //Si se posee entonces se compara con las
                for (Map<String, Object> mapaTemp : (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor"))
                {
                    if (PkFact.get("NUM_SECPROVE").toString().trim().equals(mapaTemp.get("num_secprove").toString().trim()))
                    {
                        if (mapaTemp.get("lstComproBPago") != null && ((List<Map<String, Object>>) mapaTemp.get("lstComproBPago")).size() > 0)
                        {
                            for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapaTemp.get("lstComproBPago"))
                            {
                                if (PkFact.get("NUM_SECFACT").toString().trim()
                                        .equals(mapaFactura.get("num_secfact").toString().trim()))
                                {
                                    mapaFactura.put("lstItemFactura", lstItemFacturaAnterior);
                                }
                            }
                        }
                        else
                        {
                            rBean = new MensajeBean();
                            rBean.setMensajeerror("No se encontraron Facturas en session.");
                            rBean.setMensajesol("");
                            return new ModelAndView("PagM", "beanM", rBean);
                        }
                    }
                }

                //pase153
                //cargar los item de donde lo saco para un segundo vez se carggue completo
                if (mapCabDeclara != null && mapCabDeclara.size() > 0)
                {
                    //if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor")))
                    if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstFormBProveedor")))
                    {
                        for (Map<String, Object> mapa1 : (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor"))
                        {
                            if (PkFact.get("NUM_SECPROVE").toString().trim().equals(mapa1.get("num_secprove").toString().trim()))
                            {
                                if (!CollectionUtils.isEmpty((List) mapa1.get("lstComproBPago")))
                                {
                                    for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapa1.get("lstComproBPago"))
                                    {
                                        if (PkFact.get("NUM_SECFACT").toString().trim().equals(mapaFactura.get("num_secfact").toString().trim()))
                                        {
                                            mapaFactura.put("lstItemFactura",lstItemFactura);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //fin de poner factura a la lista
                request.getSession().setAttribute("mapCabDeclaraActual",mapCabDeclara);

            }

            request.getSession().setAttribute("lstItemFactura", lstItemFactura);
            if (CollectionUtils.isEmpty((List) lstItemFactura))
            {
                rBean = new MensajeBean();
                rBean.setMensajeerror("No se encontraron Items para la Factura seleccionada.");
                rBean.setMensajesol("");
                return new ModelAndView("PagM", "beanM", rBean);
            }
        }
        catch (ServiceException e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);

            return new ModelAndView("PagM", "beanM", rBean);
        }
        finally
        {
        }
        String array = SojoUtil.toJson(lstItemFactura);// listado
        ModelAndView view = new ModelAndView("FormatoBItem", "itemFactura", array.replaceAll("null", "\"\""));


        // Obtener catalogo 25 y agregar el c�digo a la descripci�n
        List<Map<String, String>> listaEstadosMerc = catalogoAyudaService.getElementosCat(
                CATALOGO_ESTADO_MERCANCIA,
                "cod_datacat");
        for (Map<String, String> estadoMerc : listaEstadosMerc)
        {
            estadoMerc.put("des_corta", estadoMerc.get("cod_datacat") + " " + estadoMerc.get("des_corta"));
        }
        view.addObject("listaEstadosMerc", SojoUtil.toJson(listaEstadosMerc));

        view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
        view.addObject("hdn_cod_aduana", sCodAduana.toString());
        view.addObject("hdn_ann_presen", sAnnPresen.toString());
        view.addObject("hdn_cod_regimen", sCodRegimen.toString());
        view.addObject("hdn_num_declaracion", sNumDeclaracion.toString());
        view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
        view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
        view.addObject("hdn_num_fact", sNumeroFactura.toString());
        view.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);

        // Adaptacion para la regularizacion
        view.addObject("acceso", webRequest.getParameter("hdn_acceso"));

        return view;
    }

    /**
     * Metodo que nos permite obtener las series asociadas y las referencias a aun
     * determinado ITEM de FACTURA.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarDetalleFormatoBItem(HttpServletRequest request, HttpServletResponse response)
    {

        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map PkItem = new HashMap<String, String>();
        MensajeBean rBean = null;
        Map<String, Object> mapDetalleFormatoValorItem = null;
        Map<String, Object> mapResultado = new HashMap<String, Object>();
        Map<String, Object> mapCabDeclara = null;
        List<Map<String, Object>> lstSeriesItem = null;
        List<Map<String, Object>> lstReferenciaDuda = null;
        try
        {
            PkItem.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
            PkItem.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
            PkItem.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
            PkItem.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));
            mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            if (webRequest.getParameter("hdn_num_secitem") != null && !webRequest.getParameter("hdn_num_secitem").equals(""))
            {
                for (Map<String, Object> mapaProveedor : (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor"))
                {
                    if (webRequest.getParameter("hdn_num_secprove").trim()
                            .equalsIgnoreCase(
                                    mapaProveedor.get("num_secprove").toString()))
                    {
                        for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapaProveedor.get("lstComproBPago"))
                        {
                            if (webRequest.getParameter("hdn_num_secfact").trim()
                                    .equalsIgnoreCase(
                                            mapaProveedor.get("num_secfact").toString()))
                            {
                                for (Map<String, Object> mapaItem : (List<Map<String, Object>>) mapaFactura.get("lstItemFactura"))
                                {
                                    if (webRequest.getParameter("hdn_num_secitem").trim()
                                            .equalsIgnoreCase(
                                                    mapaItem.get("NUM_SECITEM").toString()))
                                    {
                                        lstSeriesItem = (List<Map<String, Object>>) mapaItem.get("lstSeriesItem");
                                        lstReferenciaDuda = (List<Map<String, Object>>) mapaItem.get("lstReferenciaDuda");
                                    }
                                }
                            }

                        }
                    }

                }
                if (!CollectionUtils.isEmpty(lstSeriesItem))
                {
                    mapResultado.put("lstSeriesItem", lstSeriesItem);
                }
                if (!CollectionUtils.isEmpty(lstReferenciaDuda))
                {
                    mapResultado.put("lstReferenciaDuda", lstReferenciaDuda);
                }
                if (CollectionUtils.isEmpty(lstSeriesItem) || CollectionUtils.isEmpty(lstReferenciaDuda))
                {
                    mapDetalleFormatoValorItem = formatoValorService.obtenerAsociadasReferenciaDUDAFormatoBItem(PkItem);
                    if (CollectionUtils.isEmpty((List) mapResultado.get("lstSeriesItem")))
                    {
                        mapResultado.put("lstSeriesItem", mapDetalleFormatoValorItem.get("lstSeriesItem"));
                    }
                    if (CollectionUtils.isEmpty((List) mapResultado.get("lstReferenciaDuda")))
                    {
                        mapResultado.put("lstReferenciaDuda", mapDetalleFormatoValorItem.get("lstReferenciaDuda"));
                    }
                }
            }

            request.getSession().setAttribute("lstSeriesAsociadas", mapDetalleFormatoValorItem.get("lstSeriesAsociadas"));
        }
        catch (ServiceException e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(jsonView, "beanM", rBean);
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(jsonView, "beanM", rBean);
        }

        return new ModelAndView(this.jsonView, "datamodel", mapResultado);
    }

    /* INICIO-PAS20134E610000153 */

    /**
     * Metodo que nos permite actualizar los datos modificados del ITEMFACTURA en
     * SESSION.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView modificarItemFacturaSession(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView view = new ModelAndView(jsonView, "resultado", "ok");
        ServletWebRequest webRequest = new ServletWebRequest(request);

        Map<String, Object> mapCabDeclara;
        List<Map<String, Object>> lstFormBProveedor;

        Map<String, Object> mapPkSelecionadosParaModificar = new HashMap<String, Object>();

        // ACTUALES
        List<Map<String, Object>> lstItemFacturaActual = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItemActual = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstReferenciaDudaActual = new ArrayList<Map<String, Object>>();
        try
        {

            String numCorredoc = webRequest.getParameter("hdn_num_corredoc");
            String numSecFact = webRequest.getParameter("hdn_num_secfact");
            String numSecProve = webRequest.getParameter("hdn_num_secprove");
            String numSecItem = webRequest.getParameter("hdn_num_secitem");

            mapPkSelecionadosParaModificar.put("NUM_CORREDOC", numCorredoc);
            mapPkSelecionadosParaModificar.put("NUM_SECFACT", numSecFact);
            mapPkSelecionadosParaModificar.put("NUM_SECPROVE", numSecProve);
            mapPkSelecionadosParaModificar.put("NUM_SECITEM", numSecItem);

            if(!webRequest.getParameter("hdn_lstReferenciaDUDA").toString().equalsIgnoreCase("undefined")){
                lstReferenciaDudaActual =
                        (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_lstReferenciaDUDA"));
            }
            lstSeriesItemActual =
                    (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_lstCorrelacion"));

            lstItemFacturaActual =
                    (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_lstItemFactura"));

            //inicio CU 14.15
            //Actualiza el estado del Item seleccionado, de pendiente pasa a Adicionado
            lstItemFacturaActual = formatoValorService.cambiarIndTipRegItemSesion(lstItemFacturaActual, mapPkSelecionadosParaModificar);
            List<Map<String,Object>> lstDetDeclaraViewActual = (List<Map<String,Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String,Object>> lstDetDeclaraViewActualCopia = new ArrayList<Map<String,Object>>();

            if(CollectionUtils.isEmpty(lstDetDeclaraViewActual)){
                lstDetDeclaraViewActualCopia = buscarListadoSeries(request);
            }else{
                lstDetDeclaraViewActualCopia = Utilidades.copiarLista((List)lstDetDeclaraViewActual);
            }
            //fin CU 14.15

            // OBTENEMOS los datos modificados en lso JSP del FORMATOA y FOMMATOB
            mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
            lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
            // recalculamos los valores de SERIES_ITEM.MTO_FOB con los valores
            // de ITEMFACTURA.MTO_FOBITEM
            // a?adimos todas la informacion actual de
            // SERIES_ITEM(lstSeriesItemActual) a la LISTA lstItemFacturaActual

            List<Integer> lstSeriesAfectadasActualizarFOB = new ArrayList<Integer>();

            for (Map ItemFacturaActual : lstItemFacturaActual)
            {
                if (ItemFacturaActual.get("lstSeriesItem") != null)
                {
                    if(ItemFacturaActual.get("lstSeriesItem").toString().isEmpty()) {
                        ItemFacturaActual.put("lstSeriesItem", null);
                    } else {
                        ItemFacturaActual.put("lstSeriesItem",
                                JSONArray.toCollection(
                                        JSONArray.fromObject(ItemFacturaActual.get("lstSeriesItem")),
                                        Map.class));
                    }


                }

                for (Map<String, Object> mapa : lstSeriesItemActual)
                {
                    if (ItemFacturaActual.get("NUM_CORREDOC").toString().trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && ItemFacturaActual.get("NUM_SECPROVE").toString().trim()
                            .equals(mapa.get("NUM_SECPROVE").toString().trim())
                            && ItemFacturaActual.get("NUM_SECFACT").toString().trim()
                            .equals(mapa.get("NUM_SECFACT").toString().trim())
                            && ItemFacturaActual.get("NUM_SECITEM").toString().trim()
                            .equals(mapa.get("NUM_SECITEM").toString().trim()))
                    {

                        if(mapa.get("IND_DEL").toString().equals("0")
                                && this.validarSerieActiva(request, mapa, lstDetDeclaraViewActualCopia)){

                            if(lstSeriesItemActual.size()==1){
                                // limpiampos la lista de relacion Item Serie para
                                // volverla a llenar
                                String montFobItem = ItemFacturaActual.get("MTO_FOBITEM").toString();
                                mapa.put("MTO_FOB", montFobItem);

                            }else{
                                BigDecimal mtoFob = Utilidades.toBigDecimal(ItemFacturaActual.get("MTO_FOBUNITARIO"))
                                        .multiply(Utilidades.toBigDecimal(mapa.get("CNT_MERC")));
                                mapa.put("MTO_FOB", mtoFob);
                            }
                        }
                        // a?adimos todas la informacion actual de
                        // SERIES_ITEM(lstSeriesItemActual) a la LISTA
                        // lstItemFacturaActual
                        ItemFacturaActual.put("lstSeriesItem", lstSeriesItemActual);
                        if(mapa.get("IND_DEL").toString().equals("0")
                                && this.validarSerieActiva(request, mapa, lstDetDeclaraViewActualCopia)){

                            Integer numSecSerie = new Integer(mapa.get("NUM_SECSERIE").toString());
                            lstSeriesAfectadasActualizarFOB.add(numSecSerie);
                        }
                    }
                }
            }
            //inicio CU 14.20
            //Sincroniza la session "lstSeriesItemActual" general con la lista de correlaciones asociadas al item ("lstSerieItem")
            this.actualizarLstSeriesItemActualDesdeItem(lstSeriesItemActual, request);
            //fin CU 14.20

            // cogemos de DUDAREFERENCIAL hacia ITEMFACTURA
            for (Map ItemFacturaActual : lstItemFacturaActual)
            {
                if (ItemFacturaActual.get("lstReferenciaDuda") != null)
                {
                    if(ItemFacturaActual.get("lstReferenciaDuda").toString().isEmpty()) {
                        ItemFacturaActual.put("lstReferenciaDuda", null);
                    }else{
                        ItemFacturaActual.put("lstReferenciaDuda",
                                JSONArray.toCollection(
                                        JSONArray.fromObject(ItemFacturaActual.get("lstReferenciaDuda")),
                                        Map.class));
                    }
                }
                for (Map<String, Object> mapa : lstReferenciaDudaActual)
                {
                    if (ItemFacturaActual.get("NUM_CORREDOC").toString().trim()
                            .equals(mapa.get("NUM_CORREDOC").toString().trim())
                            && ItemFacturaActual.get("NUM_SECPROVE").toString().trim()
                            .equals(mapa.get("NUM_SECPROVE").toString().trim())
                            && ItemFacturaActual.get("NUM_SECFACT").toString().trim()
                            .equals(mapa.get("NUM_SECFACT").toString().trim())
                            && ItemFacturaActual.get("NUM_SECITEM").toString().trim()
                            .equals(mapa.get("NUM_SECITEM").toString().trim()))
                    {
                        ItemFacturaActual.put("lstReferenciaDuda", lstReferenciaDudaActual);
                    }
                }
            }

            lstFormBProveedor = ponerLstItemFacturaActualizadaALaLstFomBProveedor(lstFormBProveedor,
                    lstItemFacturaActual,
                    mapPkSelecionadosParaModificar);

            BigDecimal mtoFobItem = Utilidades.toBigDecimal(webRequest.getParameter("mtoFobItem"));
            Map declaracionAnt = (Map) WebUtils.getSessionAttribute(request, "mapCabDeclara");
            List lstFormBProveedorAnt = (List) declaracionAnt.get("lstFormBProveedor");

            Map keys = new HashMap();
            keys.put("NUM_CORREDOC", numCorredoc);
            keys.put("NUM_SECPROVE", numSecProve);
            Map fBItem = new HashMap();
            Map fBFactAnt = new HashMap();
            Map fBProveAnt = ((lstFormBProveedorAnt != null) ? Utilidades.obtenerElemento(lstFormBProveedorAnt, keys) : null);
            BigDecimal mtoFobItemAnt = BigDecimal.ZERO;
            if (fBProveAnt != null && fBProveAnt.size() > 0)
            {
                List lstComproBPagoAnt = (ArrayList) fBProveAnt.get("lstComproBPago");
                keys = new HashMap();
                keys.put("NUM_SECFACT", numSecFact);
                fBFactAnt = ((lstComproBPagoAnt != null) ? Utilidades.obtenerElemento(lstComproBPagoAnt, keys) : null);
            }
            if (fBFactAnt != null && fBFactAnt.size() > 0)
            {
                List lstItemFactura = (ArrayList) fBFactAnt.get("lstItemFactura");
                keys = new HashMap();
                keys.put("NUM_SECITEM", numSecItem);
                fBItem = ((lstItemFactura != null) ? Utilidades.obtenerElemento(lstItemFactura, keys) : null);
            }
            if (fBItem != null && fBItem.size() > 0)
            {
                mtoFobItemAnt = Utilidades.toBigDecimal(fBItem.get("MTO_FOBITEM"));
            }
            List<Map<String, Object>> lstDetDeclaraActual = new ArrayList();
            List<Map<String, Object>> lstDetDeclara = new ArrayList();
            lstDetDeclara       = (List<Map<String, Object>>) request.getSession().getAttribute("lstDetDeclara");
            lstDetDeclaraActual = (List<Map<String, Object>>) request.getSession().getAttribute("lstDetDeclaraActual");
            if (CollectionUtils.isEmpty(lstDetDeclara))
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
                params.put("num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
                params.put("num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
                params.put("cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
                params.put("ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
                params.put("cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());

                lstDetDeclara = serieService.obtenerListadoSeries(params);

                //limpia la variable de session
                WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
                List<Map<String, Object>> lstSerieOld= new ArrayList<Map<String, Object>>();
                lstSerieOld.addAll(Utilidades.copiarLista((List)lstDetDeclara));
                WebUtils.setSessionAttribute(request, "lstDetDeclara", lstSerieOld);
                lstDetDeclara = new ArrayList(lstSerieOld);
            }

            if (CollectionUtils.isEmpty(lstDetDeclaraActual))
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
                params.put("num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
                params.put("num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
                params.put("cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
                params.put("ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
                params.put("cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());

                lstDetDeclaraActual = serieService.obtenerListadoSeries(params);

                //limpia la variable de session
                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
                List<Map<String, Object>> lstSerieNew= new ArrayList<Map<String, Object>>();
                lstSerieNew.addAll(Utilidades.copiarLista((List)lstDetDeclaraActual));
                WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSerieNew);
                lstDetDeclaraActual = new ArrayList(lstSerieNew);
            }

            if (mtoFobItem.compareTo(mtoFobItemAnt) != 0)
            {

                // actualiza COMPROB_PAGO.MTO_FACT =
                lstFormBProveedor = actualizarMtoFactConLosDatosItemFactura(lstFormBProveedor, mapPkSelecionadosParaModificar);
                // SUMATORIA(ITEMFACTURA.MTO_FOBUNITARIO)
                // actualizado
                // actualiza las cantidades de las Series con el Cambio del Item
                // DET_DECLARA.MTO_FOBDOL = SUMATORIA(SERIES_ITEM.MTO_FOB)
                actualizarMtoFOBDOLDeLaSeriesAfectadasConLosDatosSeriesItemActualizado(lstDetDeclaraActual, lstFormBProveedor,
                        lstSeriesAfectadasActualizarFOB);
                // ejecuta el prorrateo de flete

                /* ejecuctar la formula de prorrateo de seguro */
                Date fechaVigenciaPartida =
                        SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_DECLARACION")
                                .toString());

                lstDetDeclaraActual = declaracionCalculoDeDatos.prorratearMtoSeguroDesdeItemsFactura(lstDetDeclaraActual,
                        fechaVigenciaPartida);
                if (seriesTieneAlgunTipoProrrateoDeFleteTipo2y3(lstDetDeclaraActual))
                {
                    lstDetDeclaraActual = declaracionCalculoDeDatos.prorratearFlete(lstDetDeclaraActual);
                }

                actualizarDUAconSeriesSession(mapCabDeclara, lstDetDeclaraActual);
                // Actualizamos el mapCabDeclara con los datos modificados en los
                // JSP y los RECALCULOS
                request.getSession().setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);
            }
            // actualiza los datos del formulario
            mapCabDeclara.put("lstFormBProveedor", lstFormBProveedor);
            // Actualiza las series con datos modificados del items formato B
            String mensaje = actualizarSeriesConFormatoBItemsSession(request,
                    mapCabDeclara,
                    lstDetDeclara,
                    lstDetDeclaraActual,
                    lstFormBProveedor,
                    mapPkSelecionadosParaModificar);

            if ("".equals(mensaje))
                mensaje =
                        this.validaSeriesItemsFactura(mapCabDeclara,
                                (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual"));

            view.addObject("mensaje", mensaje);
            request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
        }
        catch (ServiceException e)
        {
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror(e.getMessage());
            log.error("*** ERROR ***", e);

            return new ModelAndView(jsonView, "Error", mensajeBean);
        }
        catch (Throwable e)
        {
            log.error("error", e);
            MensajeBean mensajeBean = new MensajeBean();
            mensajeBean.setMensajeerror("Ocurrio un error al realizar el registro del item de la factura");

            return new ModelAndView(jsonView, "Error", mensajeBean);
        }

        return view;
    }



    /**
     * Metodo que actualiza los montos de las Serie en base a los Montos del Item
     * del Formato B.
     *
     * @param lstDetDeclaraActual
     *          [List<Map<String,Object>>] lst det declara actual
     * @param lstFormBProveedor
     *          [List<Map<String,Object>>] lst form b proveedor
     * @throws Exception
     *           the exception
     */
    private void
    actualizarMtoFOBDOLDeLaSeriesAfectadasConLosDatosSeriesItemActualizado(
            List<Map<String, Object>> lstDetDeclaraActual,
            List<Map<String, Object>> lstFormBProveedor,
            List<Integer> lstSeriesAfectadasActualizarFOB)
            throws Exception
    {

        if (!CollectionUtils.isEmpty(lstDetDeclaraActual)
                && !CollectionUtils.isEmpty(lstFormBProveedor))
        {

            // reconstruye por cada serie el FOB con los datos del itemserie
            for (Map<String, Object> serie : lstDetDeclaraActual)
            {

                String numSerie = serie.get("NUM_SECSERIE").toString();

                Integer numSecSerie = new Integer(numSerie);

                if (lstSeriesAfectadasActualizarFOB.contains(numSecSerie))
                {

                    BigDecimal bgSerieFobAcum = BigDecimal.ZERO;
                    for (Map<String, Object> proveedor : lstFormBProveedor)
                    {
                        List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) proveedor.get("lstComproBPago");
                        if (!CollectionUtils.isEmpty(lstComproBPago))
                        {
                            for (Map<String, Object> factura : lstComproBPago)
                            {
                                List<Map<String, Object>> listaItemFacturas = (List<Map<String, Object>>) factura.get("lstItemFactura");
                                if (!CollectionUtils.isEmpty(listaItemFacturas))
                                {
                                    for (Map<String, Object> itemFactura : listaItemFacturas)
                                    {
                                        if(itemFactura.get("IND_DEL").toString().equals("0")){ //CU 14.20

                                            List<Map<String, Object>> lstSeriesItem =
                                                    (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
                                            if (!CollectionUtils.isEmpty(lstSeriesItem))
                                            {
                                                for (Map<String, Object> itemSerie : lstSeriesItem)
                                                {
                                                    if(itemSerie.get("IND_DEL").toString().equals("0")){//CU 14.20

                                                        String numSerieItem = itemSerie.get("NUM_SECSERIE").toString();
                                                        if (numSerieItem.equals(numSerie))
                                                        {
                                                            BigDecimal bgFobItemSerie = new BigDecimal(itemSerie.get("MTO_FOB").toString());
                                                            bgSerieFobAcum = bgSerieFobAcum.add(bgFobItemSerie);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    serie.put("MTO_FOBDOL", bgSerieFobAcum);
                }
            }
        }
    }

    /* FIN-PAS20134E610000153 */

    /* INICIO-PAS20134E610000153 */
    /**
     * Metodo que actualiza el monto de la Factura en base a los montos
     * modificados de la FobItem. solo de la factura que le corresponde
     *
     * Cada factura pude tener varios item
     *
     * @param lstFormBProveedor
     *          [List<Map<String,Object>>] lst form b proveedor
     */
    private List<Map<String, Object>>
    actualizarMtoFactConLosDatosItemFactura(List<Map<String, Object>> lstFormBProveedor,
                                            Map<String, Object> mapPkSelecionadosParaModificar)
    {

        if (!CollectionUtils.isEmpty(lstFormBProveedor)
                && !CollectionUtils.isEmpty(mapPkSelecionadosParaModificar))
        {

            String numSecProveSelec = mapPkSelecionadosParaModificar.get("NUM_SECPROVE").toString().trim();
            String numSecFactSelec = mapPkSelecionadosParaModificar.get("NUM_SECFACT").toString().trim();

            for (Map<String, Object> mapProveedor : lstFormBProveedor)
            {
                String numSecProve = mapProveedor.get("num_secprove").toString().trim();
                List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) mapProveedor.get("lstComproBPago");
                if (numSecProveSelec.equals(numSecProve) && !CollectionUtils.isEmpty(lstComproBPago))
                {

                    for (Map<String, Object> factura : lstComproBPago)
                    {
                        BigDecimal bgFacturaFobAcum = BigDecimal.ZERO;
                        List<Map<String, Object>> listaItemFacturas = (List<Map<String, Object>>) factura.get("lstItemFactura");

                        String numSecFact = factura.get("num_secfact").toString();
                        if (numSecFactSelec.equals(numSecFact) && !CollectionUtils.isEmpty(listaItemFacturas))
                        {
                            for (Map<String, Object> itemFactura : listaItemFacturas)
                            {
                                if(itemFactura.get("IND_DEL").toString().equals("0")){// CU 14.2O
                                    List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
                                    if (!CollectionUtils.isEmpty(lstSeriesItem))
                                    {
                                        for (Map<String, Object> itemSerie : lstSeriesItem)
                                        {
                                            if(itemSerie.get("IND_DEL").toString().equals("0")){// CU 14.2O
                                                BigDecimal bgFobItemSerie = new BigDecimal(itemSerie.get("MTO_FOB").toString());
                                                bgFacturaFobAcum = bgFacturaFobAcum.add(bgFobItemSerie);
                                            }
                                        }
                                    }
                                }
                            }
                            factura.put("mto_fact", bgFacturaFobAcum);
                        }
                    }
                }
            }
        }

        return lstFormBProveedor;
    }

    /* FIN-PAS20134E610000153 */

    /**
     * Poner lst item factura actualizada a la lst fom b proveedor.
     *
     *
     * @param lstFormBProveedor
     *          [List<Map<String,Object>>] lst form b proveedor
     * @param lstItemFacturaActual
     *          [List<Map<String,Object>>] lst item factura actual
     * @param mapPkSelecionadosParaModificar
     *          [Map<String,Object>] map pk selecionados para modificar
     * @return [List<Map<String,Object>>] list
     * @author amancillaa
     * @version 1.0
     */
    private List<Map<String, Object>>
    ponerLstItemFacturaActualizadaALaLstFomBProveedor(
            List<Map<String, Object>> lstFormBProveedor,
            List<Map<String, Object>> lstItemFacturaActual,
            Map<String, Object> mapPkSelecionadosParaModificar)

    {

        boolean banderaItem = false;

        if (!CollectionUtils.isEmpty(lstFormBProveedor)
                && !CollectionUtils.isEmpty(lstItemFacturaActual)
                && !CollectionUtils.isEmpty(mapPkSelecionadosParaModificar))
        {
            String numSecProveSelec = mapPkSelecionadosParaModificar.get("NUM_SECPROVE").toString().trim();
            String numSecFactSelec = mapPkSelecionadosParaModificar.get("NUM_SECFACT").toString().trim();

            for (Map<String, Object> mapProveedor : lstFormBProveedor)
            {
                String numSecProve = mapProveedor.get("num_secprove").toString().trim();
                List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) mapProveedor.get("lstComproBPago");
                if (numSecProveSelec.equals(numSecProve) && !CollectionUtils.isEmpty(lstComproBPago))
                {
                    for (Map<String, Object> mapComproBPago : lstComproBPago)
                    {
                        String numSecFact = mapComproBPago.get("num_secfact").toString();
                        if (numSecFactSelec.equals(numSecFact))
                        {
                            mapComproBPago.put("lstItemFactura", lstItemFacturaActual);
                            banderaItem = true;
                            break;
                        }
                    }
                }
                if (banderaItem)
                {
                    break;
                }
            }
        }

        return lstFormBProveedor;
    }

    /**
     * Series tiene algun tipo prorrateo de flete tipo2.
     *
     * @param lstDetDeclaraActual
     *          [List] lst det declara actual
     * @return true, if successful
     * @throws Exception
     *           the exception
     */
    private boolean seriesTieneAlgunTipoProrrateoDeFleteTipo2y3(List lstDetDeclaraActual) throws Exception
    {
        Map filtros = new HashMap();
        filtros.put("COD_TIPFLETE", "2");
        Long cntTipoFlete2 = Utilidades.contarPorCampoFiltradoANDCriterios(lstDetDeclaraActual, filtros);

        filtros.put("COD_TIPFLETE", "3");
        Long cntTipoFlete3 = Utilidades.contarPorCampoFiltradoANDCriterios(lstDetDeclaraActual, filtros);

        return (cntTipoFlete2.intValue() + cntTipoFlete3.intValue()) > 0 ? true : false;
    }

    /* INICIO-PAS20134E610000153 */
    /**
     * M�todo para actualizar datos modificados de los �tems del Formato B en las
     * series.
     *
     * @param request
     *          the request
     * @param mapCabDeclara
     *          the map cab declara
     * @param lstDetDeclara
     *          the lst det declara
     * @param lstDetDeclaraActual
     *          the lst det declara actual
     * @param lstFormBProveedor
     *          the lst form b proveedor
     * @param mapEnvioData
     *          the map envio data
     * @return List<Map<String, Object>>
     * @author olunar
     */
    private String actualizarSeriesConFormatoBItemsSession(
            HttpServletRequest request,
            Map<String, Object> mapCabDeclara,
            List<Map<String, Object>> lstDetDeclara,
            List<Map<String, Object>> lstDetDeclaraActual,
            List<Map<String, Object>> lstFormBProveedor,
            Map<String, Object> mapEnvioData)
    {

        String numSerie = "";
        String numSerieItem = "";
        String mensaje = "";
        String strCapitulo = "";
        ArrayList<Map> listaRegPre = new ArrayList<Map>();
        boolean tieneRegPreCeticos;
        String strItem = mapEnvioData.get("NUM_SECITEM").toString();
        List<Map<String, Object>> listaItemFacturas = null;
        List<Map<String, Object>> lstSeriesItem = null;
        Map<String, Object> serie = new HashMap<String, Object>();
        Map<String, Object> serieActual = new HashMap<String, Object>();
        for (int i = 0; i < lstDetDeclaraActual.size(); i++)
        {
            serieActual = lstDetDeclaraActual.get(i);
            if(i < lstDetDeclara.size()){
                serie = lstDetDeclara.get(i);
            }
            numSerie = serieActual.get("NUM_SECSERIE").toString();
            for (Map<String, Object> proveedor : lstFormBProveedor)
            {
                List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>)proveedor.get("lstComproBPago");
                if (!CollectionUtils.isEmpty(lstComproBPago))
                {
                    for (Map<String, Object> factura : lstComproBPago)
                    {
                        listaItemFacturas = (List<Map<String, Object>>) factura.get("lstItemFactura");
                        if (!CollectionUtils.isEmpty(listaItemFacturas))
                        {
                            for (Map<String, Object> itemFactura : listaItemFacturas)
                            {
                                lstSeriesItem = (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
                                if (lstSeriesItem != null)
                                {
                                    for (Map<String, Object> itemSerie : lstSeriesItem)
                                    {
                                        numSerieItem = itemSerie.get("NUM_SECSERIE").toString();
                                        if (numSerieItem.equals(numSerie) && itemSerie.get("NUM_SECITEM").toString().equals(strItem))
                                        {
                                            serieActual.put("COD_ESTMERC", itemFactura.get("COD_ESTMERC").toString());
                                            // Validar cambio de estado nuevo a usado
                                            tieneRegPreCeticos = false;
                                            if (serie != null && !serie.isEmpty())
                                            { // Si estado es usado
                                                if (SunatStringUtils.isStringInList(serieActual.get("COD_ESTMERC").toString(), "20,21"))
                                                {
                                                    // Estado inicial fue nuevo
                                                    if (SunatStringUtils.isStringInList(serie.get("COD_ESTMERC").toString(), "10,11,12,14,15,16,17"))
                                                    {
                                                        strCapitulo = SunatStringUtils.lpad(serieActual.get("NUM_PARTNANDI").toString(), 10, '0');
                                                        strCapitulo = strCapitulo.substring(0, 2);
                                                        // Si pertenece al cap�tulo 87 de veh�culos
                                                        if (strCapitulo.equals("87"))
                                                        {
                                                            listaRegPre = (ArrayList<Map>) serieActual.get("lstDocuPreceDua");
                                                            // Tiene r�gimen precedente
                                                            if (!CollectionUtils.isEmpty(listaRegPre))
                                                            {
                                                                for (Map<String, Object> regPre : listaRegPre)
                                                                {
                                                                    // R�gimen precedente CETICO
                                                                    if (regPre.get("COD_REGIMENPRE").toString().equals(REGIMEN_PRECEDENTE_CETICO))
                                                                    {
                                                                        tieneRegPreCeticos = true;
                                                                        continue;
                                                                    }
                                                                }
                                                            }
                                                            if (!tieneRegPreCeticos)
                                                            {
                                                                // Limpiar TNAN
                                                                serieActual.put("COD_TIPTASAAPLICAR", "");
                                                                mensaje =
                                                                        "Debe modificarse en la serie, adem�s el TNAN que corresponda de acuerdo al estado de la mercanc�a seg�n SPN.";
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        request.getSession().setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);
        return mensaje;
    }

    /* FIN-PAS20134E610000153 */

    /**
     * Metodo que permite realisar la liquidacion de la declaracion.
     *
     * @param request
     *          the request
     * @throws Exception
     *           the exception
     */
    public void liquidarDeclaracion(HttpServletRequest request) throws Exception
    {

        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
        params.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
        params.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
        params.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

        List listParticipanteDoc = new ArrayList();
        // Obtenemos de cabDeclara (importador y agente)
        Map partic = new HashMap();
        partic.put("COD_TIPPARTIC", "45");
        partic.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
        partic.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
        listParticipanteDoc.add(partic);
        partic = new HashMap();
        partic.put("COD_TIPPARTIC", "41");
        partic.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
        partic.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
        listParticipanteDoc.add(partic);

        List listConvenioSerie = new ArrayList();
        List listDocupreceDua = new ArrayList();

        HashMap paramDocLiq = new HashMap();
        paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
        paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
        paramDocLiq.put("cabDeclara", declaracionActual);
        paramDocLiq.put("listDetDeclara", listDetDeclara);
        paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
        paramDocLiq.put("listConvenioSerie", listConvenioSerie);
        paramDocLiq.put("listDocupreceDua", listDocupreceDua);
        paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
        Map resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);
        declaracionActual.put("caduana", soporteService.obtenerAduana(request));
        Map parametros = new HashMap();
        declaracionActual.put("resulPreliq", resulPreliq);
        parametros.put("mapCabDeclaraActual", declaracionActual);
        parametros.put("lstMultas", WebUtils.getSessionAttribute(request, "lstMultaDua"));
        this.liquidaDeclaracionService.liquidaDiligencia(parametros);

        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

    }

    /**
     * Metodo que permite realisar la Validacion de la Diligencia de Despacho.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView validarDiligenciaDespacho(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        // Validamos la liquidacion
        try
        {

            this.liquidarDeclaracion(request);
            // Cargamos la ventana de confirmacion
            Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
            List listaAutoliquidaciones = (List) declaracionActual.get("listaAutoliquidaciones");
            ModelAndView view = new ModelAndView("MuestraLiquidacion", "diferenciaTributos", diferenciaTributos);
            view.addObject("listaAutoliquidaciones", listaAutoliquidaciones);
            view.addObject("hdn_cod_aduana", declaracionActual.get("COD_ADUANA"));
            view.addObject("hdn_ann_presen", declaracionActual.get("ANN_PRESEN").toString());
            view.addObject("hdn_cod_regimen", declaracionActual.get("COD_REGIMEN"));
            view.addObject("grabaLC", declaracionActual.get("grabaLC"));
            view.addObject("grabaPago", declaracionActual.get("grabaPago"));
            view
                    .addObject("hdn_num_declaracion", Cadena.padLeft(declaracionActual.get("NUM_DECLARACION").toString(), 6, '0'));

            return view;
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);
        }
    }



    /**
     * Ordena monto gasto.
     *
     * @param lista
     *          the lista
     * @return the list
     */
    public List<Map<String, String>> ordenaMontoGasto(List<Map<String, String>> lista)
    {
        String[] keyList = new String[lista.size()];
        for (int i = 0; i < lista.size(); i++)
        {
            keyList[i] = lista.get(i).get("cod_datacat").toString();
        }
        Arrays.sort(keyList);
        List<Map<String, String>> orderList = new ArrayList<Map<String, String>>();
        for (int i = 0; i < keyList.length; i++)
        {
            for (int j = 0; j < lista.size(); j++)
            {
                if (lista.get(j).get("cod_datacat").equals(keyList[i]))
                {
                    orderList.add(lista.get(j));
                }
            }
        }
        return orderList;
    }

    /**
     * Cargar mant reg precedencia.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView cargarMantRegPrecedencia(HttpServletRequest request, HttpServletResponse response)
    {
        MensajeBean rBean;
        Long numCorreDoc = Long.parseLong(request.getParameter("hdn_num_corredoc"));
        Long numSecSerie = Long.parseLong(request.getParameter("hdn_num_secserie"));
        String numPartNandi = request.getParameter("txt_num_partnandi");
        List<Map<String, String>> lstRegAsoc = catalogoAyudaService.getListaElementosAsocJSON("002", "C", request
                .getParameter("hdn_cod_regimen")
                .toString());
        List<Map<String, String>> lstMtoGasto = null;
        List<DatoMontoGasto> lstDatoMontoGastoObj = null;
        List<Map<String,Object>> listaDatoMontoGasto = null;
        DatoVehiculo datoVehiculo = null;
        Map<String,Object> datoVehiculoMap = null;
        List<DatoVehiculo> listaDatoVehiculoObj = null;
        List<Map<String,Object>> listaDatoVehiculo = null;
        Map<String,Object> mapCabDeclaracion = null; //jenciso
        Long SPN_correlacionada = null;
        Integer fechaDeclaracion = null;
        String autorizaDatoPublicacion = "" ;
        String existeDatoVehiculo = "";
        try
        {
            //jenciso se obtiene la fecha de numeracion de la declaracion para determinar la SPN correlacionada.
            mapCabDeclaracion = (Map<String,Object>)WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
            fechaDeclaracion =mapCabDeclaracion!=null && mapCabDeclaracion.get("FEC_DECLARACION") !=null?SunatDateUtils.getIntegerFromDate(mapCabDeclaracion.get("FEC_DECLARACION")):0;
            SPN_correlacionada = funcionesService.getCorrelPartida(8701200000L, 0L, fechaDeclaracion);

            WebUtils.setSessionAttribute(request, "SPN_correlacionada", String.valueOf(SPN_correlacionada));

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
            params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
            params.put("ann_presen", request.getParameter("hdn_ann_presen"));
            params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
            params.put("num_corredoc", numCorreDoc);
            params.put("num_secserie", numSecSerie);
            params.put("txt_num_partnandi", numPartNandi);

            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(
                    request,
                    "lstDetDeclaraActual");
            Map<String, Object> fbKeys = new HashMap<String, Object>();
            fbKeys.put("NUM_CORREDOC", params.get("num_corredoc"));
            fbKeys.put("NUM_SECSERIE", params.get("num_secserie"));

            // Obtenemos la serie seleccionada
            Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, fbKeys);
            if (null != serieAct.get("lstDocuPreceDua") && 0 < ((List) serieAct.get("lstDocuPreceDua")).size())
            {
                List lstDocuPreceDuaActual = (ArrayList) serieAct.get("lstDocuPreceDua");
                // Si la lista de documentos de precedencia no existe en el mapa de la
                // serie...
                if (lstDocuPreceDuaActual == null || lstDocuPreceDuaActual.size() == 0)
                {

                    lstDocuPreceDuaActual = serieService.obtenerRegPrecedencia(params);
                    serieAct.put("lstDocuPreceDua", lstDocuPreceDuaActual);

                    List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
                    Map serie = Utilidades.obtenerElemento(lstDetDeclara, fbKeys);
                    List<Map<String, Object>> lstDocuPreceDuaAnt = new ArrayList();
                    lstDocuPreceDuaAnt.addAll(Utilidades.copiarLista(lstDocuPreceDuaActual));
                    serie.put("lstDocuPreceDua", lstDocuPreceDuaAnt);

                    WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
                    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
                }
                // Si existe regimen precedente y la partida corresponde a
                // VEHICULO_CETICO, se carga los datos de publicacion y monto de costeo
                if (lstDocuPreceDuaActual != null && lstDocuPreceDuaActual.size() > 0)
                {
                    if (numPartNandi.equals("8701200000") || numPartNandi.equals( String.valueOf(SPN_correlacionada))
                            || SunatStringUtils.isStringInList(numPartNandi.substring(0, 4), "8702,8703,8704,8705"))
                    {
                        autorizaDatoPublicacion = "OK";
                        lstMtoGasto = catalogoAyudaService.getElementosCat("331");
                        if (lstMtoGasto != null)
                        {
                            lstMtoGasto = ordenaMontoGasto(lstMtoGasto);
                        }
                        listaDatoVehiculo = (ArrayList)serieAct.get("lstDatoVehiculo");
                        if(listaDatoVehiculo!=null && !listaDatoVehiculo.isEmpty())  {
                            datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap((Map<String,Object>)listaDatoVehiculo.get(0));
                            existeDatoVehiculo= "OK";
                        }
                        listaDatoMontoGasto = (ArrayList)serieAct.get("lstDatoMontoGasto");
                        if(listaDatoVehiculo == null || listaDatoVehiculo.isEmpty() || listaDatoMontoGasto == null || listaDatoMontoGasto.isEmpty()){
                            Map<String, Object> paramsVehiCeti = new HashMap<String, Object>();
                            //                paramsVehiCeti.put("numcorredoc", numCorreDoc);
                            //                paramsVehiCeti.put("numserie", numSecSerie);
                            //                paramsVehiCeti.put("inddel", 0);
                            //                List<DatoVehiculo> lstDatoVehiculo = diligenciaService.findVehiculoByMap(paramsVehiCeti);
                            paramsVehiCeti.put("NUM_CORREDOC", numCorreDoc);
                            paramsVehiCeti.put("NUM_SECSERIE", numSecSerie);
                            paramsVehiCeti.put("IND_DEL", "0");
                            listaDatoVehiculo = vehiCeticoService.selectVehiCetico(paramsVehiCeti);

                            if (listaDatoVehiculo != null && listaDatoVehiculo.size() > 0)
                            {
                                datoVehiculoMap = new HashMap<String, Object>();
                                datoVehiculoMap = listaDatoVehiculo.get(0);
                                //serieAct.put("datoVehiculo", datoVehiculo);
                                datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap(datoVehiculoMap);
                                existeDatoVehiculo= "OK";
                                serieAct.put("lstDatoVehiculo", listaDatoVehiculo);//se guarda en lista para que no afecte en la comparacion de mapas
                            }
                            //lstDatoMontoGasto = diligenciaService.findMontoGastoByMap(paramsVehiCeti);
                            listaDatoMontoGasto = vehiCeticoService.selectMontoGasto(paramsVehiCeti);
                            serieAct.put("lstDatoMontoGasto", listaDatoMontoGasto);
                        }
                        lstDatoMontoGastoObj= Utilidades.obtenerListDatoMontoGastoFromListMap(listaDatoMontoGasto);

                    }
                }

                List<Map<String,Object>> lstDocuPreceDuaActualMostrar = new ArrayList<Map<String,Object>>();
                for(Map regPre: (ArrayList<Map>)lstDocuPreceDuaActual){
                    Map mapAux = new HashMap<String, Object>();
                    mapAux.putAll(regPre);
                    mapAux.put("FEC_VENCREGPRE",  DateUtil.dateToString((Date)mapAux.get("FEC_VENCREGPRE"), "dd/MM/yyyy") );
                    lstDocuPreceDuaActualMostrar.add(mapAux);
                }

                request.setAttribute("params", params);
                //request.setAttribute("lstDocuPreceDuaActual", lstDocuPreceDuaActual);
                request.setAttribute("lstDocuPreceDuaActual", lstDocuPreceDuaActualMostrar);
            }
            else
            {
                rBean = new MensajeBean();
                rBean.setMensajeerror("No se encontraron reg&iacute;menes de precedencia para la serie.");
                rBean.setMensajesol("");
                return new ModelAndView("PagM", "beanM", rBean);
            }
        }
        catch (Exception e)
        {
            rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            return new ModelAndView("PagM", "beanM", rBean);

        }




        /* INICIO-PAS20134E610000153 */
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
        Boolean banderaEdicion = true;
        if ("10".equals(tipoDiligencia))
        {

            Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute(
                    "mapCabDeclaraActual");

            if (mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                    && "EN_PROCESO".equals(mapCabDeclaraActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
            {
                banderaEdicion = true;
            }
            else
            {
                banderaEdicion = false;
            }
        }
        /*FIN-PAS20134E610000153*/


        ModelAndView mv = new ModelAndView("MantRegPrecedencia");
        mv.addObject("bEdicion", banderaEdicion); //pase153
        mv.addObject("lstRegAsoc", lstRegAsoc);
        mv.addObject("lstMtoGasto", lstMtoGasto);
        mv.addObject("datoVehiculo", datoVehiculo);
        mv.addObject("existeDatoVehiculo", existeDatoVehiculo);
        mv.addObject("lstDatoMontoGasto", lstDatoMontoGastoObj);
        mv.addObject("autorizaDatoPublicacion", autorizaDatoPublicacion);

        return mv;
    }

    /**
     * Metodo que permite modificar los Regimenes de Precedencia en Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView modificarRegPrecedenciaSession(HttpServletRequest request, HttpServletResponse response)
    {

        ModelAndView res = new ModelAndView(this.jsonView);

        try
        {
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,
                    "lstDetDeclaraActual");
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Long numcorredoc = null;
            Integer numserie = null;

            if (lstDetDeclaraActual != null && lstDetDeclaraActual.size() > 0)
            {
                Map<String, Object> fbKeys = new HashMap<String, Object>();
                fbKeys.put("NUM_CORREDOC", ((Map) lstDetDeclaraActual.get(0)).get("NUM_CORREDOC"));
                fbKeys.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
                numcorredoc = new Long(((Map) lstDetDeclaraActual.get(0)).get("NUM_CORREDOC").toString());
                numserie = new Integer(request.getParameter("hdn_num_secserie"));

                Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, fbKeys);
                List<Map<String, Object>> lstDocuPreceDuaActual = (List<Map<String, Object>>) serieAct.get("lstDocuPreceDua");

                if (lstDocuPreceDuaActual != null && lstDocuPreceDuaActual.size() > 0)
                {
                    if (request.getParameter("hdn_reg_modif").trim().equals(""))
                    {

                        // Se valida el r�gimen precedente
                        validaRegPrecedencia(request, declaracionActual, lstDetDeclaraActual, serieAct);

                        ServletWebRequest webRequest = new ServletWebRequest(request);

                        fbKeys.put("NUM_SECSERIEPRE", webRequest.getParameter("txt_num_secseriepre"));
                        fbKeys.put("COD_ADUANAPRE", webRequest.getParameter("sel_cod_aduanapre"));
                        fbKeys.put("ANN_PRESENPRE", webRequest.getParameter("txt_ann_presenpre"));
                        fbKeys.put("COD_REGIMENPRE", webRequest.getParameter("sel_cod_regimenpre"));
                        fbKeys.put("NUM_DECLARACIONPRE", webRequest.getParameter("txt_num_declaracionpre"));
                        // Se quita estos dos elementos para que no afecte la b�squeda.
                        fbKeys.remove("NUM_CORREDOC");
                        fbKeys.remove("NUM_SECSERIE");
                        Map<String, Object> regPrece = Utilidades.obtenerElemento(lstDocuPreceDuaActual, fbKeys);

                        if (regPrece != null && regPrece.size() > 0)
                        {
                            //              regPrece.put("FEC_VENCREGPRE",
                            //                           (new FechaBean(webRequest.getParameter("txtFec_Venc"), "yyyy-MM-dd")).getFormatDate("dd/MM/yyyy"));

                            String fecha = (new FechaBean(webRequest.getParameter("txtFec_Venc"), "yyyy-MM-dd")).getFormatDate("dd/MM/yyyy");

                            FechaBean fb = new FechaBean(fecha, "dd/MM/yyyy");
                            regPrece.put("FEC_VENCREGPRE",fb.getTimestamp());

                            serieAct.put("lstDocuPreceDua", lstDocuPreceDuaActual);
                            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);

                            res.addObject("recOk", true);
                        }
                        else
                        {


                            MensajeBean rBean = new MensajeBean();
                            rBean.setError(true);
                            rBean.setMensajeerror("El regimen de precedencia a modificar no ha sido encontrado.");
                            rBean
                                    .setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

                            res.addObject("recOk", false);
                            res.addObject("beanM", rBean);
                        }
                    }
                    else
                    {


                        // Se valida el r�gimen precedente
                        validaRegPrecedencia(request, declaracionActual, lstDetDeclaraActual, serieAct);

                        // Llamamos a eliminar el registro
                        this.eliminarRegPrecedencia(request);
                        // Llamamos a crear el registro
                        lstDocuPreceDuaActual = this.crearRegPrecedencia(request, lstDetDeclaraActual, serieAct);

                        // Actualizamos el estado de la grabacion
                        res.addObject("recOk", true);
                    }
                    List<Map<String,Object>> lstDocuPreceDuaActualMostrar = new ArrayList<Map<String,Object>>();
                    for(Map regPre: lstDocuPreceDuaActual){
                        Map mapAux = new HashMap<String, Object>();
                        mapAux.putAll(regPre);
                        mapAux.put("FEC_VENCREGPRE",  DateUtil.dateToString((Date)mapAux.get("FEC_VENCREGPRE"), "dd/MM/yyyy") );
                        lstDocuPreceDuaActualMostrar.add(mapAux);
                    }

                    //res.addObject("lstRegPrece", SojoUtil.toJson(lstDocuPreceDuaActual));// se envia fecha formateada
                    res.addObject("lstRegPrece", SojoUtil.toJson(lstDocuPreceDuaActualMostrar));

                    //jenciso Inicia modificacion de Datos del vehiculo
                    Map<String,Object> mapCabDeclaracion = null;
                    Integer fechaDeclaracion = null;
                    mapCabDeclaracion = (Map<String,Object>)WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
                    fechaDeclaracion =mapCabDeclaracion!=null && mapCabDeclaracion.get("FEC_DECLARACION") !=null?SunatDateUtils.getIntegerFromDate(mapCabDeclaracion.get("FEC_DECLARACION")):0;
                    List<DatoMontoGasto> lstDatoMontoGasto = new ArrayList<DatoMontoGasto>();
                    String regPre = request.getParameter("sel_cod_regimenpre");
                    String numPartNandi = serieAct.get("NUM_PARTNANDI").toString();
                    Long SPN_correlacionada = funcionesService.getCorrelPartida(8701200000L, 0L, fechaDeclaracion);
                    if(regPre.equals("91") && (numPartNandi.equals("8701200000") || numPartNandi.equals( String.valueOf(SPN_correlacionada))
                            || SunatStringUtils.isStringInList(numPartNandi.substring(0, 4), "8702,8703,8704,8705"))){

                        DatoVehiculo datoVehiculo = new DatoVehiculo();
                        datoVehiculo.setNumcorredoc(numcorredoc);
                        datoVehiculo.setNumserie(numserie);
                        datoVehiculo.setNomlibro(request.getParameter("txt_nombre_publi"));
                        String ejemplar = request.getParameter("txt_ejem_publi");
                        if(!ejemplar.trim().isEmpty())datoVehiculo.setCodejempl(ejemplar);
                        String anho = request.getParameter("txt_ano_publi");
                        String mes = Cadena.padLeft(request.getParameter("txt_mes_publi"), 2, '0');
                        if(!anho.trim().isEmpty() && !mes.trim().equals("00"))
                            datoVehiculo.setAnnmespubli(anho.concat(mes));
                        String numPag = request.getParameter("txt_numpagi_publi");
                        if(!numPag.trim().isEmpty())datoVehiculo.setNumpagin(Integer.parseInt(numPag));
                        String numFactorConv = request.getParameter("txt_fconver_publi");
                        if(!numFactorConv.trim().isEmpty())datoVehiculo.setNumfactconve(new BigDecimal(numFactorConv));
                        int max = 37;
                        for (int i= 1; i<=max ;i++ ){
                            String nombreCampo = "txt_fconver_publi"+Cadena.padLeft(String.valueOf(i), 2, '0');
                            String valorCampo = request.getParameter(nombreCampo);
                            if (valorCampo.trim().isEmpty() || valorCampo.trim().equals("0"))
                                continue;
                            DatoMontoGasto montoGasto = new DatoMontoGasto();
                            montoGasto.setTipmonto(Cadena.padLeft(String.valueOf(i), 2, '0'));
                            montoGasto.setValmonto(new BigDecimal(valorCampo));
                            montoGasto.setNumcorredoc(numcorredoc);
                            montoGasto.setNumserie(numserie);
                            montoGasto.setIndicadorEliminacion(Constants.INDICADOR_NO_ELIMINADO);
                            lstDatoMontoGasto.add(montoGasto);
                        }
                        List<DatoVehiculo> lstDatoVehiculo = new ArrayList<DatoVehiculo>();
                        lstDatoVehiculo.add(datoVehiculo);
                        List<Map<String,Object>> listaDatoVehiculo = new ArrayList<Map<String,Object>>();
                        listaDatoVehiculo.add(Utilidades.obtenerMapFromObjectDatoVehiculo(datoVehiculo));
                        //serieAct.put("lstDatoMontoGasto", lstDatoMontoGasto);
                        //serieAct.put("lstDatoVehiculo", lstDatoVehiculo);
                        serieAct.put("lstDatoMontoGasto", Utilidades.obtenerListMapFromListObjectDatoMontoGasto(lstDatoMontoGasto));
                        serieAct.put("lstDatoVehiculo", listaDatoVehiculo);
                        res.addObject("lstDatoMontoGasto", lstDatoMontoGasto);
                        res.addObject("datoVehiculo", datoVehiculo);
                        res.addObject("containsVehiCetico", "OK");

                        res.addObject("recOk", true);


                    }



                    //jenciso Fin modificacion de Datos del vehiculo
                }
            }

        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage()!=null?e.getMessage():"Ocurrio un error al intentar grabar el regimen de precedencia, por favor intentelo nuevamente");
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");


            res.addObject("beanM", rBean);
            res.addObject("recOk", false);
        }

        return res;
    }

    /**
     * Metodo que realiza la eliminacion en Session de Regimen de precedencia.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView eliminarRegPrecedenciaSession(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);
        try
        {
            List lstRegPrece = this.eliminarRegPrecedencia(request);
            res.addObject("recOk", true);
            res.addObject("lstRegPrece", lstRegPrece);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
            res.addObject("recOk", false);
        }
        return res;
    }

    /**
     * Metodo que permite realisar la adicion de un Regimen de Precedencia.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView adicionarRegPrecedenciaSession(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        try{

            List<Map<String,Object>> lstDocuPreceDuaActualMostrar = new ArrayList<Map<String,Object>>();
            List<Map> lstRegPrece = this.crearRegPrecedencia(request);

            for(Map regPre: lstRegPrece){
                Map mapAux = new HashMap<String, Object>();
                mapAux.putAll(regPre);
                mapAux.put("FEC_VENCREGPRE",  DateUtil.dateToString((Date)mapAux.get("FEC_VENCREGPRE"), "dd/MM/yyyy") );
                lstDocuPreceDuaActualMostrar.add(mapAux);
            }
            res.addObject("recOk", true);
            //res.addObject("lstRegPrece", SojoUtil.toJson(lstRegPrece));
            res.addObject("lstRegPrece", SojoUtil.toJson(lstDocuPreceDuaActualMostrar));

        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

            res.addObject("beanM", rBean);
            res.addObject("recOk", false);
        }
        return res;
    }

    /**
     * Metodo que permite la creacion de un Regimen de Precedencia.
     *
     * @param request
     *          the request
     * @return the list
     * @throws Exception
     *           the exception
     */
    private List crearRegPrecedencia(HttpServletRequest request) throws Exception
    {
        return crearRegPrecedencia(request, null, null);
    }

    /**
     * Metodo que crea un nuevo Regimen de Precedencia.
     *
     * @param request
     *          the request
     * @param lstDetDeclaraActual
     *          the lst det declara actual
     * @param serieAct
     *          the serie act
     * @return the list
     * @throws Exception
     *           the exception
     */
    private List crearRegPrecedencia(HttpServletRequest request, List lstDetDeclaraActual, Map serieAct) throws Exception
    {
        List res;
        List lstDocuPreceDuaActual;
        if (CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
            {
                Map<String, Object> fbKeys = new HashMap<String, Object>();
                fbKeys.put("NUM_CORREDOC", ((Map) lstDetDeclaraActual.get(0)).get("NUM_CORREDOC"));
                fbKeys.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
                serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, fbKeys);
            }
        }
        if (!CollectionUtils.isEmpty(serieAct))
        {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            // Se valida el r�gimen precedente
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            validaRegPrecedencia(request, declaracionActual, lstDetDeclaraActual, serieAct);
            Map<String, Object> reg = new HashMap();
            reg.put("NUM_CORREDOC", serieAct.get("NUM_CORREDOC"));
            reg.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
            reg.put("NUM_SECSERIEPRE", webRequest.getParameter("txt_num_secseriepre"));
            reg.put("COD_ADUANAPRE", webRequest.getParameter("sel_cod_aduanapre"));
            reg.put("ANN_PRESENPRE", webRequest.getParameter("txt_ann_presenpre"));
            reg.put("COD_REGIMENPRE", webRequest.getParameter("sel_cod_regimenpre"));
            reg.put("NUM_DECLARACIONPRE", webRequest.getParameter("txt_num_declaracionpre"));
            //      reg.put("FEC_VENCREGPRE", (new FechaBean(webRequest.getParameter("txtFec_Venc"), "yyyy-MM-dd"))
            //                                                                                   .getFormatDate("dd/MM/yyyy"));
            //jenciso se guarda en formato timestamp
            String fecha = (new FechaBean(webRequest.getParameter("txtFec_Venc"), "yyyy-MM-dd")).getFormatDate("dd/MM/yyyy");
            FechaBean fb = new FechaBean(fecha, "dd/MM/yyyy");
            reg.put("FEC_VENCREGPRE",fb.getTimestamp());
            //jenciso fin

            reg.put("IND_DEL", "0");
            reg.put("IND_NUEVO", "1");

            lstDocuPreceDuaActual = (List<Map<String, Object>>) serieAct.get("lstDocuPreceDua");

            if (lstDocuPreceDuaActual == null)
            {
                lstDocuPreceDuaActual = new ArrayList();
            }
            lstDocuPreceDuaActual.add(reg);
            serieAct.put("lstDocuPreceDua", lstDocuPreceDuaActual);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
            res = lstDocuPreceDuaActual;
        }
        else
        {
            throw new Exception("No se han encontrado los datos de la serie a asignar el regimen de precedencia.");
        }
        return res;
    }

    /**
     * Metodo que pemrite la eliminacion de un regimen de precedencia.
     *
     * @param request
     *          the request
     * @return the list
     * @throws Exception
     *           the exception
     */
    private List eliminarRegPrecedencia(HttpServletRequest request) throws Exception
    {
        List res = null;
        List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(
                request,
                "lstDetDeclaraActual");
        if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            Map<String, Object> fbKeys = new HashMap<String, Object>();
            fbKeys.put("NUM_CORREDOC", ((Map) lstDetDeclaraActual.get(0)).get("NUM_CORREDOC"));
            fbKeys.put("NUM_SECSERIE", request.getParameter("hdn_num_secserie"));
            Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, fbKeys);
            List<Map<String, Object>> lstDocuPreceDuaActual = (List<Map<String, Object>>) serieAct.get("lstDocuPreceDua");
            if (!CollectionUtils.isEmpty(lstDocuPreceDuaActual))
            {
                String[] clave_reg = request.getParameter("hdn_reg_modif").split(Constantes.SEPARADOR1);
                boolean encontrado = false;
                if (clave_reg.length > 0)
                {
                    for (Map<String, Object> regPrece : lstDocuPreceDuaActual)
                    {

                        if (regPrece.get("NUM_SECSERIE").toString().equals(clave_reg[0])
                                && regPrece.get("NUM_SECSERIEPRE").toString().equals(clave_reg[1])
                                && regPrece.get("COD_ADUANAPRE").toString().trim().equals(clave_reg[2])
                                && regPrece.get("ANN_PRESENPRE").toString().equals(clave_reg[3])
                                && regPrece.get("COD_REGIMENPRE").toString().trim().equals(clave_reg[4])
                                && regPrece.get("NUM_DECLARACIONPRE").toString().equals(clave_reg[5]))
                        {

                            if (regPrece.get("IND_NUEVO") != null && regPrece.get("IND_NUEVO").toString().trim().equals("1"))
                            {
                                lstDocuPreceDuaActual.remove(regPrece);
                            }
                            else
                            {
                                regPrece.put("IND_DEL", "1");
                            }
                            encontrado = true;
                            break;
                        }
                    }
                    if (encontrado)
                    {
                        serieAct.put("lstDocuPreceDua", lstDocuPreceDuaActual);
                        res = lstDocuPreceDuaActual;
                        WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActual);
                    }
                    else
                    {
                        throw new Exception("El regimen de precedencia a eliminar no ha sido encontrado en la lista");
                    }
                }
                else
                {
                    throw new Exception("No se han enviado los datos del regimen de precedencia a eliminar.");
                }
            }
            else
            {
                throw new Exception("La lista de regimenes de precedencia no ha sido cargada a sesion.");
            }
        }
        return res;
    }

    // TODO: Revisar funcionalidad no esta realizando nada solo pasa datos a un
    // Map el cual no se usa para ninguna accion.
    /**
     * Metodo que valida los Regimenes de Precendecia.
     *
     * @param request
     *          the request
     * @param declaracionActual
     *          the declaracion actual
     * @param lstDetDeclaraActual
     *          the lst det declara actual
     * @param serieAct
     *          the serie act
     * @throws Exception
     *           the exception
     */
    private void validaRegPrecedencia(
            HttpServletRequest request,
            Map<String, Object> declaracionActual,
            List lstDetDeclaraActual,
            Map serieAct) throws Exception
    {
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map mapDeclaRegpre = new HashMap();
        mapDeclaRegpre.put("COD_ADUANAPRE", webRequest.getParameter("sel_cod_aduanapre"));
        mapDeclaRegpre.put("COD_REGIMENPRE", webRequest.getParameter("sel_cod_regimenpre"));
        mapDeclaRegpre.put("ANN_PRESENPRE", webRequest.getParameter("txt_ann_presenpre"));
        mapDeclaRegpre.put("NUM_DECLARACIONPRE", webRequest.getParameter("txt_num_declaracionpre"));
        mapDeclaRegpre.put("NUM_SECSERIEPRE", webRequest.getParameter("txt_num_secseriepre"));
        mapDeclaRegpre.put(
                "FEC_VENCREGPRE",
                (new FechaBean(webRequest.getParameter("txtFec_Venc"), "yyyy-MM-dd")).getFormatDate("dd/MM/yyyy"));
        mapDeclaRegpre.put("COD_ADUANA", declaracionActual.get("COD_ADUANA"));
        mapDeclaRegpre.put("NUM_DECLARACION", declaracionActual.get("NUM_DECLARACION"));
        mapDeclaRegpre.put("ANN_PRESEN", declaracionActual.get("ANN_PRESEN"));
        mapDeclaRegpre.put("COD_REGIMEN", declaracionActual.get("COD_REGIMEN"));
        mapDeclaRegpre.put("NUM_SECSERIE", serieAct.get("NUM_SECSERIE"));
        mapDeclaRegpre.put("CNT_PESO_BRUTO", serieAct.get("CNT_PESO_BRUTO"));
        mapDeclaRegpre.put("CNT_UNIFIS", serieAct.get("CNT_UNIFIS"));
    }

    /**
     * Metodo que muestra la interfaz de Busqueda de Puertos.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView cargarBuscarPuertos(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return new ModelAndView("BuscarPuerto");
    }

    /**
     * Metodo que permite la copia de una serie en Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView copiarSerieSession(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        HttpSession session = request.getSession();
        Map<String, Object> params = new HashMap<String, Object>();
        List<Map<String, Object>> lstSeriesItemIngresados = null;
        List<Map<String, Object>> lstSeriesItemActual = null;
        params.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));
        params.put("NUM_SECSERIE", request.getParameter("_serie_base"));
        params.put("NUM_OPERACION", request.getParameter("hdn_num_operacion"));
        params.put("NUM_CANTIDAD", "1");

        String itemBaseSeleccionada = request.getParameter("_serie_item");
        String serieBaseSeleccionada = request.getParameter("_serie_base");

        List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstDetDeclaraActual");
        // obtengo indicador si tiene formato B
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        params.put("IND_FORMBPROVEEDOR", declaracionActual.get("IND_FORMBPROVEEDOR").toString());


        int cantToatlSeriesLstDetDeclaraInicial = getCantTotalSeriesActivas(detDeclaraViewList);

        // actualiza en session la nueva cantidad de series
        // declaracionActual.put("CNT_TOTSERIES", "")
        // se incrementa en 1 por la nueva copia generada
        cantToatlSeriesLstDetDeclaraInicial++;
        declaracionActual.put("CNT_TOTSERIES", cantToatlSeriesLstDetDeclaraInicial);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

        params.put("lstSeriesItemActual", lstSeriesItemActual);
        params.put("lstSeriesItem", lstSeriesItemIngresados);
        params.put("_serie_item", itemBaseSeleccionada);
        params.put("_serie_base", serieBaseSeleccionada);


        // obtiene la nueva serie generado producto de la re-distribucion
        List<Map<String, Object>> nuevaListDetDeclara = serieService.obtenerListSeriesSession(params,
                detDeclaraViewList);

        session.setAttribute("lstDetDeclaraActual", nuevaListDetDeclara);
        // Para certificado de origen
        Map<String, Object> nuevaMapDeclara = (Map<String, Object>) request
                .getSession()
                .getAttribute("mapCabDeclaraActual");
        List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) nuevaMapDeclara
                .get("lstDetAutorizacion");
        List<Map<String, Object>> lstTemp = new ArrayList<Map<String, Object>>();
        if (!CollectionUtils.isEmpty(lstDetAutorizacion))
        {
            for (Map<String, Object> mapa : lstDetAutorizacion)
            {
                if (request.getParameter("_serie_base").equals(mapa.get("NUM_SECSERIE").toString()))
                {
                    Map<String, Object> mapaDuplicado = new HashMap<String, Object>();
                    mapaDuplicado = Utilidades.copiarMapa(mapa);
                    mapaDuplicado.put("NUM_SECSERIE", params.get("ULTIMA_SERIE"));
                    lstTemp.add(mapaDuplicado);
                }
            }
            if (!CollectionUtils.isEmpty(lstTemp))
            {
                lstDetAutorizacion.addAll(Utilidades.copiarLista((List) lstTemp));
            }
        }
        List<Map<String, Object>> lstCabCertiOrigen = nuevaMapDeclara.get("lstCabCertiOrigen") != null ? (List<Map<String, Object>>) nuevaMapDeclara
                .get("lstCabCertiOrigen") : null;

        if (lstCabCertiOrigen != null && lstCabCertiOrigen.size() > 0)
        {
            for (Map<String, Object> mapaCerti : lstCabCertiOrigen)
            {
                if (SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(mapaCerti.get("NUM_SECSERIE")),
                        SunatStringUtils.toStringObj(params.get("NUM_CORREDOC").toString())))
                {
                    mapaCerti.put("SERIES", mapaCerti.get("SERIES").toString() + ", " + params.get("ULTIMA_SERIE"));

                }
            }
        }

        nuevaMapDeclara.put("lstCabCertiOrigen", lstCabCertiOrigen);
        nuevaMapDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
        session.setAttribute("mapCabDeclaraActual", nuevaMapDeclara);
        return new ModelAndView(
                this.jsonView,
                "OK",
                "Se creo correctamente la copia. Por favor modifique los datos de la serie generada");
    }

    /**
     * cant total series activas.
     *
     * @param detDeclaraViewList
     *          the det declara view list
     * @return the cant total series activas
     */
    private int getCantTotalSeriesActivas(List<Map<String, Object>> detDeclaraViewList)
    {

        int numeroSerie = 0;
        for (Map<String, Object> detDeclaraViewMap : detDeclaraViewList)
        {
            if ("0".equals(detDeclaraViewMap.get("IND_DEL")))
            {
                numeroSerie++;
            }
        }
        return numeroSerie;
    }

    /**
     * Actualiza estado serie session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView actualizaEstadoSerieSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        HttpSession session = request.getSession();

        List lstDetDeclaraActual = (List) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        List lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        // la serie es marcada para eliminar se recalcula la cantidad
        // de series en la cabecera
        // de la declaracion
        Integer cantSeries = SunatNumberUtils.toInteger(declaracionActual.get("CNT_TOTSERIES"));
        if (request.getParameter("est_serie").equals("1"))
        {
            cantSeries--;
        }
        else if (request.getParameter("est_serie").equals("0"))
        {
            cantSeries++;
        }
        declaracionActual.put("CNT_TOTSERIES", cantSeries);
        WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_SECSERIE", request.getParameter("num_serie"));
        params.put("EST_SECSERIE", request.getParameter("est_serie"));
        params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
        params.put("lstDetDeclaraActual", Utilidades.copiarLista(lstDetDeclaraActual));
        params.put("lstSeriesItemActual", Utilidades.copiarLista(lstSeriesItemActual));
        params.put("declaracion", declaracionActual);

        //inicio CU 14.16 par�metros para actualizar itemFactura
        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        if(declaracionActual.get("IND_FORMBPROVEEDOR")!= null && declaracionActual.get("IND_FORMBPROVEEDOR").toString().equals("0")){
            JSONArray arrayItemsCheck = JSONArray.fromObject(request.getParameter("hdn_lstItemsEstCheck"));
            List<Map<String,Object>> lstItemEstCheck = (List<Map<String, Object>>) JSONArray.toCollection(arrayItemsCheck, Map.class);
            params.put("lstItemEstCheck", lstItemEstCheck);
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            params.put("lstSeriesItem", lstSeriesItem);
            params.put("usuario", bUsuario.getNroRegistro());
        }
        //fin CU 14.16

        Map<String, Object> mreturn = serieService.actualizaEstadoSerieSession(params);
        List<Map<String, Object>> lstDetDeclaraActualP = (List) mreturn.get("lstDetDeclaraActual");
        Map<String, Object> mapCabDeclaraActualP = (Map) mreturn.get("declaracion");
        actualizarDUAconSeriesSession(mapCabDeclaraActualP, lstDetDeclaraActualP);
        session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActualP);
        session.setAttribute("lstSeriesItemActual", (List<Map<String, Object>>) mreturn.get("lstSeriesItemActual"));
        session.setAttribute("mapCabDeclaraActual", mapCabDeclaraActualP);


        ModelAndView view = new ModelAndView(this.jsonView, "detDeclaraViewListJson", (List<Map<String,Object>>)mreturn.get("lstDetDeclaraActual"));

        if(params.get("EST_SECSERIE").toString().equals("0") && declaracionActual.get("IND_FORMBPROVEEDOR").toString().equals("0")){
            view.addObject("itemsRecuperados", mreturn.get("itemsRecuperados"));
        }

        return view;
    }

    /**
     * Metodo que obtiene las Series Item de Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerSeriesItemSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        Map<String, Object> params = new HashMap<String, Object>();
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItemNew = new ArrayList<Map<String, Object>>();
        String num_secserie = request.getParameter("num_secserie");
        String num_corredoc = declaracion.get("NUM_CORREDOC").toString();
        String ind_del = request.getParameter("ind_del");
        Map<String, Object> fbKeys = new HashMap<String, Object>();
        fbKeys.put("NUM_SECSERIE", num_secserie);
        List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        Map serie = Utilidades.obtenerElemento(lstDetDeclara, fbKeys);
        if (lstSeriesItemActual != null && lstSeriesItemActual.size() > 0)
        {
            for (Map<String, Object> seriesItemActual : lstSeriesItemActual)
            {
                if (seriesItemActual.get("NUM_SECSERIE").toString().equals(num_secserie)
                        && seriesItemActual.get("IND_DEL").toString().equals(ind_del))
                {
                    lstSeriesItemNew.add(seriesItemActual);
                }
            }
        }
        Ordenador.sortDesc(lstSeriesItemNew, "NUM_SECITEM", Ordenador.ASC);
        String itemsDeLaSerie = "";
        for(Map<String,Object> serieItem : lstSeriesItemNew){
            itemsDeLaSerie = itemsDeLaSerie + (itemsDeLaSerie.equals("")?"":", ")+ serieItem.get("NUM_SECITEM").toString();
        }
        ModelAndView view = new ModelAndView(this.jsonView, "lstSeriesItem", lstSeriesItemNew);
        params.put("num_secserie", num_secserie);
        params.put("num_corredoc", num_corredoc);
        params.put("ind_del", ind_del);
        params.put("lstDetAutorizacion", declaracion.get("lstDetAutorizacion"));
        params.put("serieAct", serie);
        view.addObject("mapDocumentos", this.obtenerRelacionDocumentoSerie(params));
        view.addObject("itemsDeLaSerie",itemsDeLaSerie);
        return view;
    }

    /**
     * Obtener relacion documento serie.
     *
     * @param params
     *          the params
     * @return the map
     */
    private Map<String, Object> obtenerRelacionDocumentoSerie(Map<String, Object> params)
    {
        Integer contadorCertificado = 0;
        Integer contadorDocAsociado = 0;
        String estado = (String) params.get("ind_del");
        String num_secserie = (String) params.get("num_secserie");

        List<Map> lstDetAutorizacion = (List) params.get("lstDetAutorizacion");
        List<Map> lstDocPrecentes = null;
        List<Map> lstFacturaSerie = null;
        Map mapResumen = new HashMap();

        if (!CollectionUtils.isEmpty(lstDetAutorizacion))
        {
            for (Map mapDetAut : lstDetAutorizacion)
            {
                if (num_secserie.equals(mapDetAut.get("NUM_SECSERIE").toString()) &&
                        estado.equals(mapDetAut.get("IND_DEL").toString()))
                {
                    if (Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN.equals(mapDetAut.get("COD_TIPOPER").toString()))
                    {
                        contadorCertificado++;
                    }
                    else
                    {
                        contadorDocAsociado++;
                    }
                }
            }
        }

        Map serieAct = (Map) params.get("serieAct");

        Integer contadorRegPrecedente = 0;
        // Precedentes
        lstDocPrecentes = (ArrayList) serieAct.get("lstDocuPreceDua");
        if (!CollectionUtils.isEmpty(lstDocPrecentes))
        {
            for (Map mapDetAut : lstDocPrecentes)
            {
                if (num_secserie.equals(mapDetAut.get("NUM_SECSERIE").toString()) &&
                        estado.equals(mapDetAut.get("IND_DEL").toString()))
                {
                    contadorRegPrecedente++;
                    break;
                }
            }
        }
        Integer contadorFacturaSerie = 0;
        // factura serie
        lstFacturaSerie = (List<Map>) serieAct.get("lstFacturaSerie");
        if (!CollectionUtils.isEmpty(lstFacturaSerie))
        {
            for (Map mapFactura : lstFacturaSerie)
            {
                if (num_secserie.equals(mapFactura.get("NUM_SECSERIE").toString()) &&
                        (SunatStringUtils.isEmpty((String) mapFactura.get("IND_DEL")) ||
                                (!SunatStringUtils.isEmpty((String) mapFactura.get("IND_DEL")) &&
                                        estado.equals(mapFactura.get("IND_DEL").toString()))))
                {
                    contadorFacturaSerie++;
                    break;
                }
            }
        }
        Integer contadorConvenioSerie = 0;
        // convenios
        List<Map> lstConvenioSerie = (List<Map>) serieAct.get("lstConvenioSerie");
        if (!CollectionUtils.isEmpty(lstConvenioSerie))
        {
            for (Map mapConvenio : lstConvenioSerie)
            {
                if (num_secserie.equals(mapConvenio.get("NUM_SECSERIE").toString()) &&
                        estado.equals(mapConvenio.get("IND_DEL").toString()))
                {
                    contadorConvenioSerie++;
                    break;
                }
            }
        }
        mapResumen.put("contadorCertificado", contadorCertificado);
        mapResumen.put("contadorDocAsociado", contadorDocAsociado);
        mapResumen.put("contadorRegPrecedente", contadorRegPrecedente);
        mapResumen.put("contadorFacturaSerie", contadorFacturaSerie);
        mapResumen.put("contadorConvenioSerie", contadorConvenioSerie);
        return mapResumen;
    }

    /**
     * Metodoq ue obtiene las Series Item para una Serie desde Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerSeriesItem(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        String tipoRelacion = "0"; // tipo1 rrelacion 1 a 1, tipo2 de 1 a N
        int contado = 0;

        List<Map<String, Object>> lstSeriesItem = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstSeriesItemActual");
        if (lstSeriesItemActual != null && lstSeriesItemActual.size() > 0)
            for (Map<String, Object> seriesItem : lstSeriesItemActual)
            {
                if (seriesItem.get("NUM_SECSERIE").toString().equals(request.getParameter("_serie_base")) &&
                        seriesItem.get("IND_DEL").toString().equals("0"))
                {

                    contado++;
                    lstSeriesItem.add(Utilidades.copiarMapa(seriesItem));
                    tipoRelacion = "1";
                }

            }
        if (contado > 1)
        {
            tipoRelacion = "0";
        }

        ModelAndView view = new ModelAndView(this.jsonView, "lstSeriesItem", lstSeriesItem);
        view.addObject("tipoRelacion", tipoRelacion);
        return view;
    }

    /**
     * Metodo que obtiene la lista de Series Item de Session.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView obtenerLstSeriesItem(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Map<String, Object> params = new HashMap<String, Object>();
        Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");

        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) (WebUtils.getSessionAttribute(
                request,
                "lstSeriesItemActual"));
        List<Map<String, Object>> lstItemFacturaActual = (List<Map<String, Object>>) (WebUtils.getSessionAttribute(
                request,
                "lstItemFacturaActual"));

        params.put("NUM_SECITEM", request.getParameter("_serie_item"));
        params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        params.put("IND_DEL", "0");
        List<Map<String, Object>> lstSeriesItemRes = new ArrayList<Map<String, Object>>();
        if (lstSeriesItemActual != null)
            for (Map<String, Object> seriesItemActual : lstSeriesItemActual)
            {
                if (seriesItemActual.get("NUM_SECITEM").toString().equals(request.getParameter("_serie_item"))
                        && seriesItemActual.get("IND_DEL").toString().equals("0"))
                {
                    lstSeriesItemRes.add(seriesItemActual);
                }

            }

        Map<String, Object> itemFactura = new HashMap();
        if (lstItemFacturaActual != null)
            for (Map<String, Object> itemFacturaActual : lstItemFacturaActual)
            {
                if (itemFacturaActual.get("NUM_SECITEM").toString().equals(request.getParameter("_serie_item"))
                        && itemFacturaActual.get("IND_DEL").toString().equals("0"))
                {
                    itemFactura = itemFacturaActual;
                    break;
                }

            }

        Map<String, Object> ret = new HashMap<String, Object>();
        ret.put("lstSeriesItem", lstSeriesItemRes);
        String numCorreDocDua = declaracion.get("NUM_CORREDOC").toString();

        List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,
                "lstDetDeclaraActual");
        ret.put("numSecSerie", serieService.getSgteNumSecSerie(numCorreDocDua, detDeclaraViewList));
        ret.put("itemFactura", itemFactura);
        return new ModelAndView(this.jsonView, "data", ret);
    }


    /**
     * <p>
     * Actualiza los datos de montos de la DUA con la sumatoria de la todas las
     * series
     * </p>
     * .
     *
     * @param mapCabDeclara
     *          <code>java.util.Map</code> Datos en session de la DUA
     * @param lstDetDeclaraActual
     *          <code>java.util.List</code> Lista de todas las series agregadas,
     *          eliminadas o recuperadas
     */
    private void actualizarDUAconSeriesSession(
            Map<String, Object> mapCabDeclara,
            List<Map<String, Object>> lstDetDeclaraActual)
    {

        BigDecimal bgFobCabeceraAcum = BigDecimal.ZERO;
        BigDecimal bgSeguroCabeceraAcum = BigDecimal.ZERO;
        BigDecimal bgFleteCabeceraAcum = BigDecimal.ZERO;
        BigDecimal bgAjusteCabeceraAcum = BigDecimal.ZERO;
        BigDecimal bgOtroAjusteCabeceraAcum = BigDecimal.ZERO;
        BigDecimal bgValoAduanaCabeceraAcum = BigDecimal.ZERO;

        // calcula los montos de todas las series
        for (Map<String, Object> serie : lstDetDeclaraActual)
        {

            BigDecimal bgFobSerie = BigDecimal.ZERO;
            BigDecimal bgSeguroSerie = BigDecimal.ZERO;
            BigDecimal bgFleteSerie = BigDecimal.ZERO;
            BigDecimal bgAjusteSerie = BigDecimal.ZERO;
            BigDecimal bgOtroAjusteSerie = BigDecimal.ZERO;
            BigDecimal bgAduanaSerie = BigDecimal.ZERO;

            if("0".equals(serie.get("IND_DEL").toString()) && !Utilidades.esUnaRegistroMarcadaParaEliminar(serie))
            {

                bgFobSerie = new BigDecimal(serie.get("MTO_FOBDOL").toString());
                bgSeguroSerie = new BigDecimal(serie.get("MTO_SEGDOL").toString());
                bgFleteSerie = new BigDecimal(serie.get("MTO_FLETEDOL").toString());
                bgAjusteSerie = new BigDecimal(serie.get("MTO_AJUSTE").toString());
                bgOtroAjusteSerie = new BigDecimal(serie.get("MTO_OTROSAJUSTES").toString());
                bgAduanaSerie = new BigDecimal(serie.get("MTO_VALORADU").toString());
            }

            bgFobCabeceraAcum = bgFobCabeceraAcum.add(bgFobSerie);
            bgSeguroCabeceraAcum = bgSeguroCabeceraAcum.add(bgSeguroSerie);
            bgFleteCabeceraAcum = bgFleteCabeceraAcum.add(bgFleteSerie);
            bgAjusteCabeceraAcum = bgAjusteCabeceraAcum.add(bgAjusteSerie);
            bgOtroAjusteCabeceraAcum = bgOtroAjusteCabeceraAcum.add(bgOtroAjusteSerie);
            bgAduanaSerie = bgFobSerie.add(bgSeguroSerie).add(bgFleteSerie).add(bgAjusteSerie).add(bgOtroAjusteSerie);
            bgValoAduanaCabeceraAcum = bgValoAduanaCabeceraAcum.add(bgAduanaSerie);
            serie.put("MTO_VALORADU", bgAduanaSerie);
        }
        // actualiza el mapa de la DUA con los datos de la serie
        //mapCabDeclara.put("MTO_TOTFOBDOL", bgFobCabeceraAcum);
        //mapCabDeclara.put("MTO_TOTSEGDOL", bgSeguroCabeceraAcum);
        //mapCabDeclara.put("MTO_TOTFLETEDOL", bgFleteCabeceraAcum);
        //mapCabDeclara.put("MTO_TOTAJUSTESDOL", bgAjusteCabeceraAcum);
        //mapCabDeclara.put("MTO_TOTOTROSAJUSTE", bgOtroAjusteCabeceraAcum);
        //mapCabDeclara.put("MTO_TOTVALORADU", bgValoAduanaCabeceraAcum);

    }
    /**
     * Permite obtener datos de Participante Importador de una Declaracion.
     *
     * @param request
     *          [HttpServletRequest] request
     * @param response
     *          [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @author amancillaa
     * @version 1.0
     */
    public ModelAndView cargarAnexo2(HttpServletRequest request, HttpServletResponse response)
    {

        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));


        Map<String, Object> mapaAnexo2 = declaracionService.obtenerAnexo2(params);

        if (mapaAnexo2 != null)
        {
            mapaAnexo2.put("NOM_RAZONSOCIAL_PIM", declaracionActual.get("NOM_RAZONSOCIAL_PIM") != null ? declaracionActual
                    .get("NOM_RAZONSOCIAL_PIM") : "");
            mapaAnexo2.put("NUM_DOCIDENT_PIM", declaracionActual.get("NUM_DOCIDENT_PIM") != null ? declaracionActual
                    .get("NUM_DOCIDENT_PIM") : "");
            mapaAnexo2.put("DIR_PARTIC_PIM", declaracionActual.get("DIR_PARTIC_PIM") != null ? declaracionActual
                    .get("DIR_PARTIC_PIM") : "");
        }

        ModelAndView view = new ModelAndView("FinUbicacion", "anexo2", mapaAnexo2);

        return view;
    }

    /**
     * Validar fecha vencimiento.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     */
    public ModelAndView validarFechaVencimiento(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map<String, Object> resultado = null;
        try
        {
            String fecVenRegimen = webRequest.getParameter("fecVenRegimen");

            GarantiaOperativaService garantiaService = fabricaDeServicios.getService("recauda.diligencia.garantiaService");
            Map<String, Object> mapGarantiaParam = new HashMap<String, Object>();
            mapGarantiaParam.put("PREGIMEN", declaracionActual.get("COD_REGIMEN"));
            mapGarantiaParam.put("PADUANA", declaracionActual.get("COD_ADUANA"));
            mapGarantiaParam.put("PANO", declaracionActual.get("ANN_PRESEN"));
            mapGarantiaParam.put(
                    "PNUMERO",
                    SunatStringUtils.lpad(declaracionActual.get("NUM_DECLARACION").toString(), 6, '0'));
            mapGarantiaParam.put("PBENEFICI", declaracionActual.get("NUM_DOCIDENT_PIM"));

            List<Map<String, Object>> lstGarantias = garantiaService.getGarantiaOperativa(mapGarantiaParam);
            // Se comparan las fechas de las garantias presentadas para obtener
            // la de menor vigencia
            Date fecGarantia = soporteService.getMinDateFromList(lstGarantias, "FFIN_DOCAFI");

            if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals(declaracionActual.get("COD_REGIMEN"))
                    || Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals(declaracionActual.get("COD_REGIMEN")))
            {
                resultado = diligenciaService.validarFechaVencimiento(
                        (String) declaracionActual.get("COD_REGIMEN"),
                        (String) declaracionActual.get("COD_ADUANA"),
                        (String) declaracionActual.get("COD_TIPDESP"),
                        SunatDateUtils.getDate(fecVenRegimen, "dd/MM/yyyy"),
                        (Date) declaracionActual.get("FEC_DECLARACION"),
                        fecGarantia);
            }

            if (resultado.get("fechaVencimientoError") == null && resultado.get("fechaUtilRegimen") != null)
            {
                declaracionActual.put("FEC_VENREGIMEN", resultado.get("fechaUtilRegimen"));
            }

            res.addObject("resFechaUtil", resultado);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;
    }

    /**
     * Metodo que consulta las solucitudes de rectificacion de una dua.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return json con la lista de solicitudes de rectificacion y el numero de la
     *         dua
     * @throws Exception
     *           the exception
     */
    public ModelAndView consultaEstadoRectificaciones(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        MensajeBean rBean = new MensajeBean();
        try
        {
            ServletWebRequest webRequest = new ServletWebRequest(request);
            UsuarioBean userSession = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(userSession == null ? "user" : userSession.getLogin(), request.getRemoteAddr());
            if (userSession == null)
            {
                rBean.setError(true);
                rBean.setMensajeerror("Usuario no logueado");
                rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

                return new ModelAndView(jsonView, "beanM", rBean);
            }

            BigDecimal numeroCorrelativoDua = new BigDecimal(ObjectUtils.toString(
                    webRequest.getParameter("hdn_num_corredoc"), "0"));
            List<SolicitudRectifica> listaSolicituRectifica = solicitudRectificacionesService
                    .listSolicitudesRectificaByDua(numeroCorrelativoDua);
            // ordenar de forma ascedente
            Collections.sort(listaSolicituRectifica, new Comparator()
            {
                public int compare(Object objSolicitudRectifica1, Object objSolicitudRectifica2)
                {
                    SolicitudRectifica solicitudRectifica1 = (SolicitudRectifica) objSolicitudRectifica1;
                    SolicitudRectifica solicitudRectifica2 = (SolicitudRectifica) objSolicitudRectifica2;
                    return solicitudRectifica1.getFechaSolicitud().compareTo(solicitudRectifica2.getFechaSolicitud());
                }
            });

            Map<String, Object> dataResponse = new HashMap<String, Object>();
            dataResponse.put("lstSolicitudRecfificacion", listaSolicituRectifica);

            rBean.setData(dataResponse);
            return new ModelAndView(jsonView, "beanM", rBean);
        }
        catch (RuntimeException e)
        {
            rBean.setError(true);
            rBean.setMensajeerror("Error de Aplicacion.");
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(jsonView, "beanM", rBean);
        }
    }

    /**
     * Inits the consulta estado rectificaciones.
     *
     * @param request
     *          the request
     * @param response
     *          the response
     * @return the model and view
     * @throws Exception
     *           the exception
     */
    public ModelAndView initConsultaEstadoRectificaciones(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("controllerName", "Declaracion.htm");
        ModelAndView view = new ModelAndView("consultaEstadoRectificaciones", params);
        return view;

    }


    /**
     * Metodo que carga la informacion completa de la Dua de Session y la Dua
     * Original.
     *
     * @param declaracion
     *          the declaracion
     * @param declaracionActual
     *          the declaracion actual
     */
    public void cargaFormatoBCompleto(Map<String, Object> declaracion, Map<String, Object> declaracionActual, HttpServletRequest request)
    {

        List<Map> lstActualProveedor = new ArrayList();
        List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
        if (lstFormBProveedor == null)
        {
            Map<String, Object> pFormBP = new HashMap<String, Object>();
            pFormBP.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
            lstFormBProveedor = this.formatoValorService.obtenerFVProveedores(pFormBP);
            if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
            {
                for (Map prov : lstFormBProveedor)
                {
                    prov.put("num_corredoc", declaracionActual.get("NUM_CORREDOC"));
                }
            }

            lstActualProveedor = Utilidades.copiarLista(lstFormBProveedor);
            declaracion.put("lstFormBProveedor", lstFormBProveedor);
            declaracionActual.put("lstFormBProveedor", lstActualProveedor);
        }

        if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
            declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
        else
            declaracionActual.put("IND_FORMBPROVEEDOR", "1");

        if (lstActualProveedor != null)
        {
            for (Map prov : lstActualProveedor)
            {
                Map<String, Object> params = new HashMap<String, Object>();
                String num_secprove = prov.get("num_secprove").toString();
                params.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
                params.put("NUM_SECPROVE", num_secprove);

                //jenciso Inicio - ceticos parte1 agregamos montos por cada proveedor
                Map<String,Object> listMontos = new HashMap<String, Object>();
                listMontos = (Map<String,Object>)prov.get("mapFormBMonto");
                if(CollectionUtils.isEmpty(listMontos)){
                    listMontos = this.formatoValorService.obtenerMontosFormBByDAV(declaracionActual.get("NUM_CORREDOC").toString(), num_secprove);
                    if(!CollectionUtils.isEmpty(listMontos)){
                        colocarLstMontosByDAV(declaracion,listMontos,num_secprove);
                        colocarLstMontosByDAV(declaracionActual,listMontos,num_secprove);
                    }
                }
                //jenciso Fin

                List<Map> lstFacturas = (List) prov.get("lstComproBPago");
                if (lstFacturas == null || lstFacturas.size() == 0)
                {
                    lstFacturas = this.formatoValorService.obtenerFacturasProveedor(params);

                    if (lstFacturas != null && lstFacturas.size() > 0)
                    {
                        colocarLstFacturas(declaracion, lstFacturas, num_secprove);
                        colocarLstFacturas(declaracionActual, lstFacturas, num_secprove);
                    }
                }

                Map<String, Object> mapa = null;
                for (Map compPag : lstFacturas)
                {
                    String num_secfact = compPag.get("num_secfact").toString();
                    params.remove("NUM_SECITEM");
                    params.put("NUM_SECFACT", num_secfact);
                    List<Map<String, Object>> lstItemFactura = (ArrayList) compPag.get("lstItemFactura");
                    if (lstItemFactura == null)
                    {
                        Map<String, String> pkFact = new HashMap<String, String>();
                        pkFact.put("NUM_CORREDOC", params.get("NUM_CORREDOC").toString());
                        pkFact.put("NUM_SECPROVE", params.get("NUM_SECPROVE").toString());
                        pkFact.put("NUM_SECFACT", params.get("NUM_SECFACT").toString());
                        pkFact.put("caduana", declaracion.get("COD_ADUANA").toString());

                        if(this.validarMostrarItemsEliminados(declaracionActual, request)){
                            pkFact.put("incluirEliminados", "true");
                        }
                        mapa = formatoValorService.obtenerFormatoBItem(pkFact);
                        lstItemFactura = (List<Map<String, Object>>) mapa.get("lstItemFactura");

                        colocarLstItemFacturas(declaracion, lstItemFactura, num_secprove, num_secfact);
                        colocarLstItemFacturas(declaracionActual, lstItemFactura, num_secprove, num_secfact);
                    }
                    //jenciso Inicio - se cargan las facturas sucesivas
                    List<Map<String,Object>> lstFactuSucesivas = (ArrayList<Map<String,Object>>)compPag.get("lstFactuSucesivas");
                    if(CollectionUtils.isEmpty(lstFactuSucesivas)){
                        lstFactuSucesivas = formatoValorService.selectFactuSuce(params);
                        if(!CollectionUtils.isEmpty(lstFactuSucesivas)){
                            colocarLstFactuSucesivas(declaracion, lstFactuSucesivas, num_secprove, num_secfact);
                            colocarLstFactuSucesivas(declaracionActual, lstFactuSucesivas, num_secprove, num_secfact);
                        }
                    }
                    //jenciso Fin

                    for (Map mpItem : lstItemFactura)
                    {
                        String num_secItem = mpItem.get("NUM_SECITEM").toString();
                        params.put("NUM_SECITEM", num_secItem);
                        List lstSeriesItem = (ArrayList) mpItem.get("lstSeriesItem");
                        if (lstSeriesItem == null)
                        {
                            lstSeriesItem = serieService.obtenerSeriesItem(params);
                            colocarLstSerieItem(declaracion, lstSeriesItem, num_secprove, num_secfact, num_secItem);
                            colocarLstSerieItem(declaracionActual, lstSeriesItem, num_secprove, num_secfact, num_secItem);
                        }

                        //jenciso Inicio obtiene las descripciones minimas por ItemFactura
                        List<Map<String,Object>> lstDecrMinima = (ArrayList<Map<String,Object>>)mpItem.get("lstDecrMinima");
                        if(lstDecrMinima == null){
                            lstDecrMinima = formatoValorService.selectFormbItemDescri(params);
                            colocarLstDecrMinima(declaracion, lstDecrMinima, num_secprove, num_secfact, num_secItem);
                            colocarLstDecrMinima(declaracionActual, lstDecrMinima, num_secprove, num_secfact, num_secItem);
                        }
                        //jenciso Fin

                        List<Map<String, Object>> lstReferenciaDuda = null;
                        lstReferenciaDuda = (List<Map<String, Object>>) mapa.get("lstReferenciaDuda");
                        if (lstReferenciaDuda != null && lstReferenciaDuda.size() > 0)
                        {
                            for (Map<String, Object> mapaReferencia : lstReferenciaDuda)
                            {
                                // LA serie es la misma de la lista de items
                                if (mpItem
                                        .get("NUM_SECITEM")
                                        .toString()
                                        .trim()
                                        .equals(mapaReferencia.get("NUM_SECITEM").toString().trim()))
                                {
                                    // No se posee lista de Series Item
                                    if (mpItem.get("lstReferenciaDuda") == null)
                                    {
                                        mpItem.put("lstReferenciaDuda", new ArrayList<Map<String, Object>>());
                                        ((List<Map<String, Object>>) mpItem.get("lstReferenciaDuda")).add(mapaReferencia);
                                    }
                                    else
                                    {
                                        ((List<Map<String, Object>>) mpItem.get("lstReferenciaDuda")).add(mapaReferencia);
                                    }
                                }
                            }
                        }

                    }

                }

            }
        }

    }

    /**
     * Coloca los montos de un DAV en la declaracion
     * @author jenciso
     * @param declaracion
     * @param lstMontos
     * @param num_secprove
     */
    private void colocarLstMontosByDAV(Map declaracion, Map<String,Object> lstMontos, String num_secprove)
    {
        if (!CollectionUtils.isEmpty(declaracion))
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");
            String codProv;
            Map<String,Object> factAsig = new HashMap<String, Object>();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    factAsig.putAll(lstMontos);
                    prov.put("mapFormBMonto", factAsig);
                    break;
                }
            }
        }
    }

    /**
     * Coloca las Facturas sucesivas en las Facturas de la declaracion
     * @author jenciso
     * @param declaracion
     * @param lstFactuSucesivas
     * @param num_secprove
     * @param num_secfact
     */
    private void colocarLstFactuSucesivas(Map declaracion, List<Map<String,Object>> lstFactuSucesivas, String num_secprove, String num_secfact){

        if (!CollectionUtils.isEmpty(declaracion)){
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

            String codProv;
            String secFact;
            List lstFactuSucesivasAsig = new ArrayList();
            for (Map prov : lstProve){

                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove)) {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago) {

                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact)) {
                            lstFactuSucesivasAsig = Utilidades.copiarLista((List)lstFactuSucesivas);
                            comPago.put("lstFactuSucesivas", lstFactuSucesivasAsig);
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * Metodo que agrage la lista de Items Factura en el Objeto de la Declaracion
     * para en la seccion de Proveedor y Factura correspondiente.
     *
     * @param declaracion
     *          the declaracion
     * @param lstItemFacturas
     *          the lst item facturas
     * @param num_secprove
     *          the num_secprove
     * @param num_secfact
     *          the num_secfact
     */
    private void colocarLstItemFacturas(Map declaracion, List lstItemFacturas, String num_secprove, String num_secfact)
    {
        if (declaracion != null && declaracion.size() > 0)
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

            String codProv;
            String secFact;
            List lstItemfactAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago)
                    {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact))
                        {
                            lstItemfactAsig = Utilidades.copiarLista(lstItemFacturas);
                            comPago.put("lstItemFactura", lstItemfactAsig);
                            break;
                        }
                    }

                }
            }

        }
    }

    /**
     * Metodo que agrage la lista de Serie Items en el Objeto de la Declaracion
     * para un proveedor , factura e item correspondiente.
     *
     * @param declaracion
     *          the declaracion
     * @param lstSerieItem
     *          the lst serie item
     * @param num_secprove
     *          the num_secprove
     * @param num_secfact
     *          the num_secfact
     * @param num_secitem
     *          the num_secitem
     */
    private void colocarLstSerieItem(
            Map declaracion,
            List lstSerieItem,
            String num_secprove,
            String num_secfact,
            String num_secitem)
    {
        if (declaracion != null && declaracion.size() > 0)
        {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

            String codProv;
            String secFact;
            String sectItem;
            List lstSerieItemfactAsig = new ArrayList();
            for (Map prov : lstProve)
            {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove))
                {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
                    for (Map comPago : lstComproBPago)
                    {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact))
                        {
                            List<Map> lstItemfact = (ArrayList<Map>) comPago.get("lstItemFactura");
                            for (Map item : lstItemfact)
                            {
                                sectItem = item.get("NUM_SECITEM").toString().trim();
                                if (sectItem.equals(num_secitem))
                                {
                                    lstSerieItemfactAsig = Utilidades.copiarLista(lstSerieItem);
                                    item.put("lstSeriesItem", lstSerieItemfactAsig);
                                    break;
                                }
                            }
                        }
                    }

                }
            }

        }
    }


    /**
     * @author jenciso
     * Metodo que agrage la lista de descripciones minimas en el Objeto de la Declaracion
     * para un proveedor , factura e item correspondiente.
     * @param declaracion declaracion
     * @param lstDecrMinima lstDecrMinima
     * @param num_secprove num_secprove
     * @param num_secfact num_secfact
     * @param num_secitem num_secitem
     */
    private void colocarLstDecrMinima(Map declaracion, List lstDecrMinima,
                                      String num_secprove, String num_secfact, String num_secitem) {
        if (declaracion != null && declaracion.size() > 0) {
            List<Map> lstProve = (ArrayList) declaracion.get("lstFormBProveedor");

            String codProv;
            String secFact;
            String sectItem;
            List lstDecriMinimaItemfactAsig = new ArrayList();
            for (Map prov : lstProve) {
                codProv = prov.get("num_secprove").toString().trim();
                if (codProv.equals(num_secprove)) {
                    List<Map> lstComproBPago = (ArrayList<Map>) prov
                            .get("lstComproBPago");
                    for (Map comPago : lstComproBPago) {
                        secFact = comPago.get("num_secfact").toString().trim();
                        if (secFact.equals(num_secfact)) {
                            List<Map> lstItemfact = (ArrayList<Map>) comPago
                                    .get("lstItemFactura");
                            for (Map item : lstItemfact) {
                                sectItem = item.get("NUM_SECITEM").toString()
                                        .trim();
                                if (sectItem.equals(num_secitem)) {
                                    lstDecriMinimaItemfactAsig = Utilidades
                                            .copiarLista(lstDecrMinima);
                                    item.put("lstDecrMinima",
                                            lstDecriMinimaItemfactAsig);
                                    break;
                                }
                            }
                        }
                    }

                }
            }

        }
    }




    /**
     * Cargar pantalla prorrateo.
     *
     * @param request
     *          [HttpServletRequest] request
     * @param response
     *          [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @throws Exception
     *           the exception
     * @author amancillaa
     * @version 1.0
     */
    public ModelAndView cargarPantallaProrrateo(HttpServletRequest request,
                                                HttpServletResponse response) throws Exception
    {
        List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear = new ArrayList();
        lstBLProrratear = verificarDocTransporteAProrratear(request);

        return new ModelAndView(this.jsonView, "lstBLProrratear", lstBLProrratear);
    }


    private BigDecimal obtenerMontoSeguroSerieTipo2Y3DeLaSerie(List<Map<String, Object>> lstDetDeclaraActual,
                                                               String numCorredoc,
                                                               String numSecSerie)
    {

        // actuliza el monto FOB y SEG
        BigDecimal mtoTotFobDolDua = Utilidades.sumarPorCampo(lstDetDeclaraActual, "MTO_FOBDOL");
        BigDecimal mtoTotSegDolDua = Utilidades.sumarPorCampo(lstDetDeclaraActual, "MTO_SEGDOL");

        BigDecimal NewMtoFobDolSeriePedida = new BigDecimal(0);

        for (Map serie : lstDetDeclaraActual)
        {

            String codTipSegSerie = serie.get("COD_TIPSEG").toString();
            String[] arrayTipoSeguro =  { "2", "3" };

            if (Arrays.asList(arrayTipoSeguro).contains(codTipSegSerie))
            {
                BigDecimal mtoFobDolSerie = Utilidades.toBigDecimal(serie.get("MTO_FOBDOL").toString());
                BigDecimal mtoAjusteSerie = Utilidades.toBigDecimal(serie.get("MTO_AJUSTE").toString());
                if (!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(serie.get("IND_PRORRATEO")),"1")){
                    BigDecimal NewMtoFobDolSerie = declaracionCalculoDeDatos.calcularMtoSeguroDeLaSerieTipo2y3(mtoFobDolSerie,
                            mtoAjusteSerie,
                            mtoTotFobDolDua,
                            mtoTotSegDolDua);
                    serie.put("MTO_SEGDOL", NewMtoFobDolSerie);
                }
            }
        }

        Map<String, Object> mapKeyDet = new HashMap<String, Object>();
        mapKeyDet.put("NUM_CORREDOC", numCorredoc);
        mapKeyDet.put("NUM_SECSERIE", numSecSerie);
        Map mapDetActual = Utilidades.obtenerElemento(lstDetDeclaraActual, mapKeyDet);
        NewMtoFobDolSeriePedida = Utilidades.toBigDecimal(mapDetActual.get("MTO_SEGDOL"));

        return NewMtoFobDolSeriePedida;
    }



    /**
     * Verificar doc transporte a prorratear.
     *
     * @param request [HttpServletRequest] request
     * @return [List<SumaFleteYPesoPorDocTransporteBean>] list
     * @throws Exception the exception
     * @author amancillaa
     * @version 1.0
     */
    private List<SumaFleteYPesoPorDocTransporteBean>
    verificarDocTransporteAProrratear(HttpServletRequest request) throws Exception
    {

        List<Map> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        if (CollectionUtils.isEmpty((List) lstDetDeclara))
        {
            cargarSeriesSesion(request);
            lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
        }

        List<SumaFleteYPesoPorDocTransporteBean> lstBLProrratear = new ArrayList();
        lstBLProrratear = declaracionCalculoDeDatos.obtenerDocTransporteAProrratear(lstDetDeclara);

        return lstBLProrratear;

    }


    /**
     * Validar Datos del Declarante
     *
     * @param request   [HttpServletRequest] request
     * @param response  [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @author wtaco
     * @version 1.0
     *
     */
    public ModelAndView validarDatosDeclarante(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView res = new ModelAndView(this.jsonView);

        try
        {
            Map params = new HashMap();
            ServletWebRequest webRequest = new ServletWebRequest(request);
            Map declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

            params.put("tipo_documento", webRequest.getParameter("tip_doc"));
            params.put("numero_documento", webRequest.getParameter("cod_busq"));
            params.put("nom_declarante", webRequest.getParameter("nom_declarante"));
            params.put("fec_referencia", declaracion.get("FEC_DECLARACION"));


            Map<String, Object> mapResultado = this.validaDiligenciaService.validarDatosDeclarante(params);
            return new ModelAndView(this.jsonView, "data", mapResultado);
        }
        catch (Exception e)
        {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        finally
        {

        }
        return res;
    }
    // inicio EJHM
    /**
     * Cargar Formulario de Impresion
     *
     * @param request
     *            [HttpServletRequest] request
     * @param response
     *            [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @author wtaco
     * @version 1.0
     *
     */
    public ModelAndView cargarFormularioImpresion(HttpServletRequest request,
                                                  HttpServletResponse response) throws Exception {

        try {

            SolicitudRecepcion solicitudBusqueda = new SolicitudRecepcion();
            solicitudBusqueda.setNumeroCorrelativo(Long.parseLong(request
                    .getParameter("numeroCorrelativoSolicitud")));
            Map<String, Object> paramsRec = recepcionDocumentosService.obtenerDatosRecepcion(solicitudBusqueda);
            SolicitudRecepcion solicitud = (SolicitudRecepcion) paramsRec.get("solicitud");
            String recepcion = paramsRec.get("recepcion").toString();
            // cadenaDocReg

            paramsRec
                    .put("tipoRecepcion",
                            recepcion
                                    .equals(ConstantesDeclaracion.PRIMERA_RECEPCION) ? "1ra. Recepcion"
                                    : "2da. Recepcion");
            paramsRec.put("numeroCorrelativoSol",
                    solicitud.getNumeroCorrelativo());
            paramsRec.put("numeroCorrelativoDua", solicitud.getDeclaracion()
                    .getDua().getNumcorredoc());
            paramsRec.put("tipoGeg", solicitud.getTipoGed().getCodDatacat());
            paramsRec.put("des_aduana", null);

            recepcionDocumentosService.obtenerDatosDeclaracionparaVista(
                    paramsRec, solicitud.getDeclaracion());
            ModelAndView view = new ModelAndView(
                    "frmImpresionDocumentosRecepcionados");

            WebUtils.setSessionAttribute(request, "params", paramsRec);
            return view;
        } catch (Exception e) {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol(" Error al Registrar la Pagina");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "Error", rBean);
        }
    }

    /**
     * Imprimir PDF
     *
     * @param request
     *            [HttpServletRequest] request
     *            [HttpServletResponse] response
     * @return [ModelAndView] model and view
     * @author wtaco
     * @version 1.0
     *
     */
    public ModelAndView imprimirGuiaEntregaDocumentos(
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MensajeBean mensajeBean = new MensajeBean();
        ModelAndView model = null;
        try {
            Map<String, Object> paramsRec = (Map<String, Object>) WebUtils
                    .getSessionAttribute(request, "params");
            Map<String, Object> parametrosReporte = new HashMap<String, Object>();
            String formato = request.getParameter("formato") == null ? ConstantesDeclaracion.FORMATO_EXCEL
                    : ConstantesDeclaracion.FORMATO_PDF;
            String tipoRecepcion = request.getParameter("hdn_recepcion");
            String descTipoRecep = "";
            if (tipoRecepcion.equals(ConstantesDeclaracion.COD_GED_PRIMERA_RECEP)) {
                descTipoRecep = "1ra Recepci�n";
            } else {
                descTipoRecep = "2da Recepci�n";
            }
            parametrosReporte.put("descDeclaracion",paramsRec.get("descDeclaracion"));
            parametrosReporte.put("fechaDeclaracion",paramsRec.get("fechaDeclaracion"));
            parametrosReporte.put("modalidad", paramsRec.get("des_modalidad"));
            parametrosReporte.put("des_canal", paramsRec.get("des_canal"));
            parametrosReporte.put("garantia",paramsRec.get("des_garantia_art_160"));
            String importador = "RUC:".concat(paramsRec.get("ruc_importador").toString()).concat("-").concat(paramsRec.get("razon_soc_importador").toString());
            String agenciaAduanera = "RUC:".concat(paramsRec.get("ruc_agencia").toString()).concat("-").concat(paramsRec.get("razon_soc_agencia").toString());
            parametrosReporte.put("importador", importador);
            parametrosReporte.put("agenciaaduanera", agenciaAduanera);
            parametrosReporte.put("tiporecepcion", descTipoRecep);
            parametrosReporte.put("fechaRecepcion",
                    paramsRec.get("fechaRecepcion"));
            parametrosReporte.put("recepcionadopor",
                    paramsRec.get("recepcionadopor"));
            parametrosReporte.put("funcionarioaduanero",
                    paramsRec.get("funcioncionarioasig"));
            //parametrosReporte.put("requerimientos_adm", StringUtil.retirarSaltosCadena(request.getParameter("ta_requerimientos")));
            parametrosReporte.put("descEstadoDua",paramsRec.get("descEstadoDua"));
            if (paramsRec.get("fechaRechazo") != null) {
                parametrosReporte.put("fechaRechazo",paramsRec.get("fechaRechazo"));
                parametrosReporte.put("sustento", paramsRec.get("sustento"));
                parametrosReporte.put("reimpresion",
                        ConstantesDeclaracion.COD_REPORTE_RECHAZO);
            } else {
                parametrosReporte.put("reimpresion",
                        ConstantesDeclaracion.COD_REPORTE_REIMPRESION);
            }

            parametrosReporte.put("observaciones",
                    paramsRec.get("observaciones"));
            String desc_aduana = "";
            desc_aduana = desc_aduana.concat("INTENDENCIA DE ADUANA DE ")
                    .concat(paramsRec.get("des_aduana").toString()
                            .toUpperCase());
            parametrosReporte.put("desAduana", desc_aduana);
            String extension = ConstantesDeclaracion.FORMATO_EXCEL
                    .equals(formato) ? ConstantesDeclaracion.EXTENSION_EXCEL
                    : ConstantesDeclaracion.EXTENSION_PDF;
            FechaBean fechaHoy = new FechaBean();
            Map<String, Object> config = new HashMap<String, Object>();
            config.put("attachment", false);
            config.put("plantillaID", new Integer(
                    ConstantesDeclaracion.COD_REPORTE_RECEP));
            config.put(
                    "filename",
                    "guiaEntregaDocumentos"
                            + fechaHoy.getFormatDate("yyyyMMddHHmmss")
                            + extension);
            config.put(ConstantesDeclaracion.REPORT_LOCALE,
                    new java.util.Locale(ConstantesDeclaracion.FORMATO_LOCAL));
            Map<String, Object> parametros = new HashMap<String, Object>();
            List<Map<String, Object>> row = new ArrayList<Map<String, Object>>();
            List<Map<String, String>> listaDocumentos = recepcionDocumentosService.getCadenaDocumentosRecepcionadosPDF(paramsRec.get(
                    "cadenaDocReg").toString());
            List<Observacion> listaAlertas = paramsRec.get("listaObservaciones") == null ? new ArrayList<Observacion>(4)
                    : (List<Observacion>) paramsRec.get("listaObservaciones");
            if (listaAlertas.isEmpty()) {
                Observacion observacion = new Observacion();
                observacion.setObsdeclaracion("NO DATA");
                listaAlertas.add(observacion);
            }
            Map<String, Object> registro = new HashMap<String, Object>();
            registro.put("listaDocumentos", listaDocumentos);
            registro.put("listaAlertas", listaAlertas);
            row.add(registro);
            model = jasperService.generarPdf(config, row, parametrosReporte,
                    this.getApplicationContext());
        } catch (Exception ex) {
            log.error("**** ERROR ****", ex);
            mensajeBean.setError(true);
            mensajeBean
                    .setMensajeerror("Se ha producido un error inesperador al mostrar "
                            + ex.getMessage());
            model = new ModelAndView("PagM", "beanM", mensajeBean);
        }
        return model;

    }

    // fin EJHM

    /**************************************************************/

    /** M�todo que guarda/actualiza las correlaciones modificadas de las series desde la p�gina de correlaciones
     * @param request
     * @param response
     * @return ModelAndView
     * @throws Exception
     */
    public ModelAndView guardarCorrelacionSesion(HttpServletRequest request, HttpServletResponse response) throws Exception{

        ModelAndView modelView = null;
        try{

            HttpSession session = request.getSession();

            //contiene los seriesItem nuevos y actualizados en la correlaci�n nueva
            List<Map<String, Object>> lstCorrelacionTemporal = (List<Map<String, Object>>)
                    WebUtils.getSessionAttribute(request,"lstCorrelacionTemporal");
            List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>)
                    WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
            List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                    request,"lstDetDeclaraActual");


            //Actualiza correlaciones (sesi�n SeriesItemActual)
            lstSeriesItemActual = this.actualizarSerieItemActual(lstSeriesItemActual, lstCorrelacionTemporal);
            List<Map<String,Object>> lstFactura = this.filtrarFacturas(lstCorrelacionTemporal);

            Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request,"mapCabDeclaraActual");
            prorratearDatos(lstDetDeclaraActual, mapCabDeclaraActual, session);

            //Actualiza Lista SerieItem asociada por cada Item de Factura en la declaraci�n
            this.actualizaSerieItemsPorItemDeFactura(mapCabDeclaraActual, lstSeriesItemActual);

            //recalcular cantidad comercial para la declaraci�n
            this.calcularDatosAdicionalesDUA(mapCabDeclaraActual, lstDetDeclaraActual);

            //Actualiza Monto Fob de la Factura
            List<Map<String, Object>> lstFormBProveedor = (ArrayList) mapCabDeclaraActual.get("lstFormBProveedor");
            for(Map<String,Object> factura : lstFactura){
                lstFormBProveedor = actualizarMtoFactConLosDatosItemFactura(lstFormBProveedor, factura);
            }

            //Remueve las correlaciones que fueron Quitadas desde la pantalla de Correlaci�n, solo aquellas que no est�n registradas en bd
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");
            Map<String, Object> params = new HashMap<String,Object>();
            params.put("mapCabDeclaraActual", mapCabDeclaraActual);
            params.put("lstSeriesItemActual", lstSeriesItemActual);
            params.put("lstSeriesItem", lstSeriesItem);
            this.removerCorrelacionesQuitadas(params);
            //***

            session.setAttribute("mapCabDeclaraActual", (Map<String, Object>)params.get("mapCabDeclaraActual"));
            session.setAttribute("lstSeriesItemActual", (List<Map<String, Object>>)params.get("lstSeriesItemActual"));
            session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);

            session.removeAttribute("lstDetDeclaraActualBack");
            session.removeAttribute("lstCorrelacionTemporal");

            modelView = new ModelAndView(this.jsonView, "OK", "Se ha guardado satisfactoriamente la informaci\u00f3n");

        }catch (Exception e) {
            log.error("*** ERROR ***", e);
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Corrija el problema de validacion y vuelva a intentar grabar la serie.");

            modelView = new ModelAndView(this.jsonView, "beanM", rBean);
        }

        return modelView;
    }

    /** Agrupa la lista de correlaciones generales de session y la lista de correlaciones temporales
     * @param lstSeriesItemActual
     * @param lstSerieItemCorrelacion
     * @return List<Map<String,Object>>
     * @throws Exception
     */
    private List<Map<String,Object>> actualizarSerieItemActual( List<Map<String,Object>> lstSeriesItemActual,
                                                                List<Map<String, Object>> lstSerieItemCorrelacion)throws Exception{

        List<Map<String,Object>> listaSerieItemActualCopia = (List<Map<String,Object>>)Utilidades.copiarLista((List)lstSeriesItemActual);
        int index = 0;
        for(Map<String,Object> nuevaCorrelacion : lstSerieItemCorrelacion){
            index = 0;
            for(Map<String,Object> serieItem : listaSerieItemActualCopia){

                if(serieItem.get("NUM_SECITEM").toString().equals(nuevaCorrelacion.get("NUM_SECITEM").toString())
                        && serieItem.get("NUM_SECSERIE").toString().equals(nuevaCorrelacion.get("NUM_SECSERIE").toString())){

                    lstSeriesItemActual.set(index, nuevaCorrelacion);
                    break;
                }
                index++;
            }

            Map<String, Object> fbKeys = new HashMap<String, Object>();
            Map<String, Object> serieItemNueva = new HashMap<String, Object>();
            fbKeys.put("NUM_SECSERIE", nuevaCorrelacion.get("NUM_SECSERIE").toString());
            fbKeys.put("NUM_SECITEM", nuevaCorrelacion.get("NUM_SECITEM").toString());

            serieItemNueva = (Map<String, Object>)Utilidades.obtenerElemento(lstSeriesItemActual, fbKeys);

            if(serieItemNueva==null || serieItemNueva.isEmpty()){
                lstSeriesItemActual.add(nuevaCorrelacion);
            }
        }
        return lstSeriesItemActual;
    }

    /** Recalcula datos de la cabecera de la Dua
     * @param mapCabDeclaraActual
     * @param detDeclaraViewList
     */
    private void calcularDatosAdicionalesDUA(Map mapCabDeclaraActual, List<Map<String, Object>> detDeclaraViewList){
        BigDecimal cantComer = BigDecimal.ZERO;
        BigDecimal totalCantComer = BigDecimal.ZERO;

        for(Map<String, Object> serie : detDeclaraViewList){

            if("0".equals(serie.get("IND_DEL").toString()) && !Utilidades.esUnaRegistroMarcadaParaEliminar(serie)){
                cantComer = Utilidades.validaVacioRetornaBigDecimal(serie.get("CNT_COMER"));
                totalCantComer = totalCantComer.add(cantComer);

            }
        }
        mapCabDeclaraActual.put("CNT_TQUNICOM", totalCantComer);
    }

    /** Revierte los cambios(rollBack) de la lista de series en session
     * @param request
     * @param response
     * @return ModelAndView
     * @throws Exception
     */
    public ModelAndView revertirCambiosListaSerieCorrelacion(HttpServletRequest request, HttpServletResponse response) throws Exception{

        HttpSession session = request.getSession();
        List<Map<String, Object>> lstDetDeclaraActualBack = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActualBack");

        if(!CollectionUtils.isEmpty(lstDetDeclaraActualBack)){
            session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActualBack);
        }
        ModelAndView view = new ModelAndView(this.jsonView);
        return view;
    }

    /** M�todo que actualiza el Id de los items adicionados(copiados que no existe en base de datos) al ser eliminado alg�n item adicionado,
     *  remueve items eliminados y sus correlaciones (los adicionados no existentes en base de datos),
     *  actualiza el id del item en sus listas asociadas
     * @param params
     * @throws Exception
     */
    public void actualizarIdDeItemFactura(Map<String, Object> params) throws Exception{

        Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
        List<Map<String, Object>> lstSeriesItemActual = null != params.get("lstSeriesItemActual") ? (ArrayList) params.get("lstSeriesItemActual") : new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>)params.get("lstDetDeclaraActual");
        List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)params.get("lstSeriesItem");

        //Remover correlaciones temporales eliminados (de una serie registrada en Base de Datos que fue eliminada durante la diligencia)
        for(Map<String, Object> serie : lstDetDeclaraActual){

            if("1".equals(serie.get("IND_DEL").toString()) && serie.get("ESTADO_REGISTRO").toString().equals("0")){

                for (Iterator itSI = lstSeriesItemActual.iterator(); itSI.hasNext();){
                    Map seriesItem = (HashMap) itSI.next();

                    if(serie.get("NUM_SECSERIE").toString().equals(seriesItem.get("NUM_SECSERIE").toString())
                            && "1".equals(seriesItem.get("IND_DEL").toString())){
                        Map<String,Object> keys = new HashMap<String,Object>();
                        keys.put("NUM_SECSERIE", seriesItem.get("NUM_SECSERIE"));
                        keys.put("NUM_SECITEM", seriesItem.get("NUM_SECITEM"));


                        Map<String,Object> serieItemAnt = Utilidades.obtenerElemento(lstSeriesItemAnt, keys);

                        if(serieItemAnt == null || serieItemAnt.isEmpty()){

                            itSI.remove();
                        }
                    }
                }
            }
        }

        String IND_REGISTRO_PENDIENTE = "1";

        //Obtener el Primer Item eliminado para ordenar los Id a partir de ese Item
        List<Map<String, Object>> listaTotalItemFactura = formatoValorService.obtenerListaItemsDeclaracionActual(mapCabDeclaraActual);
        Ordenador.sortDesc(listaTotalItemFactura, "NUM_SECITEM", Ordenador.ASC);

        String primerItemEliminado = "";
        for(Map<String, Object> itemFactura : listaTotalItemFactura){
            if(("1".equals(itemFactura.get("IND_DEL").toString()) &&  "1".equals(itemFactura.get("ESTADO_REGISTRO").toString()))
                    || IND_REGISTRO_PENDIENTE.equals(itemFactura.get("IND_TIPO_REGISTRO"))){
                primerItemEliminado = itemFactura.get("NUM_SECITEM").toString();
                break;
            }
        }


        List<Map<String,Object>> listaItemFactura = new ArrayList<Map<String,Object>>();
        // removiendo los pendientes, adicionados que fueron eliminados
        List<Map<String, Object>> listProveedores = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
        for (Map<String, Object> mapa : listProveedores){
            List<Map<String, Object>> lstFactura = (List<Map<String, Object>>) mapa.get("lstComproBPago");

            for (Map<String, Object> mapaFactura : lstFactura){
                listaItemFactura = (List<Map<String,Object>>)mapaFactura.get("lstItemFactura");

                if(!CollectionUtils.isEmpty(listaItemFactura)){

                    for (Iterator it = listaItemFactura.iterator(); it.hasNext();){
                        Map item = (HashMap) it.next();

                        if (item.get("IND_TIPO_REGISTRO").toString().equals(IND_REGISTRO_PENDIENTE) ||
                                (item.get("ESTADO_REGISTRO").toString().equals("1") && item.get("IND_DEL").toString().equals("1") )){

                            it.remove();
                        }
                    }
                }
            }

        }

        //Actualiza la lista de Correlaciones asociadas por Item de acuerdo a la lista general de correlaciones "lstSeriesItemActual"
        boolean encontrado = false;
        for (Map<String, Object> mapa : listProveedores){

            List<Map<String, Object>> lstFacturaComp = (List<Map<String, Object>>) mapa.get("lstComproBPago");
            for (Map<String, Object> factura : lstFacturaComp){

                listaItemFactura = (List<Map<String,Object>>)factura.get("lstItemFactura");

                if(!CollectionUtils.isEmpty(listaItemFactura)){
                    for(Map<String, Object> item : listaItemFactura){

                        //serieItems por Item
                        if( item.get("lstSeriesItem")!= null && !item.get("lstSeriesItem").toString().isEmpty()){
                            List<Map<String,Object>> lstSeriesItem = (List<Map<String,Object>>)item.get("lstSeriesItem");

                            for(Iterator itera = lstSeriesItem.iterator(); itera.hasNext();){
                                Map serieItem = (HashMap) itera.next();

                                encontrado = false;
                                for(Map<String,Object> serieItemAct: lstSeriesItemActual){
                                    if(serieItem.get("NUM_SECITEM").toString().equals(serieItemAct.get("NUM_SECITEM").toString())
                                            && serieItem.get("NUM_SECSERIE").toString().equals(serieItemAct.get("NUM_SECSERIE").toString())){

                                        encontrado = true;
                                        break;
                                    }
                                }
                                if(!encontrado){
                                    itera.remove();
                                }
                            }
                        }

                    }
                }
            }
        }

        List<Map<String, Object>> listaTotalItemFacturaNueva = new ArrayList<Map<String, Object>>();
        if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor"))) {
            List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
            for (Map<String, Object> mapa : lstForBProveedor){
                List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
                for (Map<String, Object> mapaFactura : lstComproBPago){

                    List lstItemFactua = (List)mapaFactura.get("lstItemFactura");
                    if(!CollectionUtils.isEmpty(lstItemFactua)){
                        listaTotalItemFacturaNueva.addAll((List)mapaFactura.get("lstItemFactura"));
                    }
                }
            }
        }

        //primerItemEliminado
        if(!primerItemEliminado.isEmpty()){
            Integer numItem = Integer.valueOf(primerItemEliminado);
            for(Map<String, Object> item : listaTotalItemFacturaNueva){
                if("0".equals(item.get("IND_TIPO_REGISTRO").toString())
                        && "1".equals(item.get("ESTADO_REGISTRO").toString())
                        && (Integer.valueOf(item.get("NUM_SECITEM").toString())).intValue() > numItem.intValue() ) {

                    String num_secItemAnt = item.get("NUM_SECITEM").toString();
                    item.put("NUM_SECITEM", numItem);

                    //serieItems por Item
                    if( item.get("lstSeriesItem")!= null && !item.get("lstSeriesItem").toString().isEmpty()){
                        List<Map<String,Object>> lstSeriesItem = (List<Map<String,Object>>)item.get("lstSeriesItem");
                        for(Map<String,Object> serieItem : lstSeriesItem){
                            serieItem.put("NUM_SECITEM", numItem);
                        }
                        Ordenador.sortDesc(lstSeriesItem, "NUM_SECSERIE", Ordenador.ASC);
                    }

                    if(item.get("lstVfobProvisional")!=null && !item.get("lstVfobProvisional").toString().isEmpty()){
                        List<Map<String,Object>> lstVfobProvisional = (List<Map<String,Object>>)item.get("lstVfobProvisional");
                        for(Map<String,Object> vfobProv : lstVfobProvisional){
                            vfobProv.put("NUM_SECITEM", numItem);
                        }
                    }

                    if(item.get("lstDecrMinima")!=null && !item.get("lstDecrMinima").toString().isEmpty()){
                        List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>)item.get("lstDecrMinima");
                        for(Map<String,Object> formBitemDes : lstDecrMinima){
                            formBitemDes.put("NUM_SECITEM", numItem);
                        }
                    }

                    if(item.get("lstReferenciaDuda")!=null && !item.get("lstReferenciaDuda").toString().isEmpty()){
                        List<Map<String,Object>> lstReferenciaDuda = (List<Map<String,Object>>)item.get("lstReferenciaDuda");
                        for(Map<String,Object> refDuda : lstReferenciaDuda){
                            refDuda.put("NUM_SECITEM", numItem);
                        }
                    }

                    if(!CollectionUtils.isEmpty(lstSeriesItemActual)){
                        Ordenador.sortDesc(lstSeriesItemActual, "NUM_SECITEM", Ordenador.ASC);
                        for (Map<String, Object> serieItem : lstSeriesItemActual)
                        {
                            if (num_secItemAnt.equals(serieItem.get("NUM_SECITEM").toString()))
                            {
                                serieItem.put("NUM_SECITEM", numItem);
                            }
                        }

                    }

                    numItem++;

                }
            }

            //actualizar items en la declaracion
            if (!CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstFormBProveedor"))) {
                List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
                for (Map<String, Object> mapa : lstForBProveedor){
                    List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
                    for (Map<String, Object> mapaFactura : lstComproBPago){

                        List<Map<String,Object>> itemFactura = new ArrayList<Map<String,Object>>();
                        for(Map<String, Object> item : listaTotalItemFacturaNueva){
                            if(mapaFactura.get("num_secfact").toString().equals(item.get("NUM_SECFACT").toString())
                                    && mapaFactura.get("num_secprove").toString().equals(item.get("NUM_SECPROVE").toString())
                                    && mapaFactura.get("num_corredoc").toString().equals(item.get("NUM_CORREDOC").toString())){

                                itemFactura.add(item);
                            }
                        }
                        Ordenador.sortDesc(itemFactura, "NUM_SECITEM", Ordenador.ASC);
                        this.colocarLstItemFacturas(mapCabDeclaraActual,itemFactura,mapaFactura.get("num_secprove").toString(),
                                mapaFactura.get("num_secfact").toString());
                    }
                }
            }

        }

        Ordenador.sortDesc(lstSeriesItemActual, "NUM_SECSERIE", Ordenador.ASC);
        params.put("mapCabDeclaraActual", mapCabDeclaraActual);
        params.put("lstSeriesItemActual", lstSeriesItemActual);

    }

    /**Remueve las correlaciones de la lista de correlaciones totales y de la lista de correlaciones asociada por Item,
     * solo remueve las correlaciones que no est�n registradas en Base de datos y que fueron quitadas desde la opci�n "Quitar" de la p�gina de correlaciones.
     * @param params
     * @throws Exception
     */
    private void removerCorrelacionesQuitadas(Map<String, Object> params) throws Exception{

        Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
        List<Map<String, Object>> lstSeriesItemActual = null != params.get("lstSeriesItemActual") ? (ArrayList) params.get("lstSeriesItemActual") : new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listProveedores = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");

        List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)params.get("lstSeriesItem");

        List<Map<String,Object>> listaItemFactura = new ArrayList<Map<String,Object>>();

        for (Map<String, Object> mapa : listProveedores){

            List<Map<String, Object>> lstFacturaComp = (List<Map<String, Object>>) mapa.get("lstComproBPago");
            for (Map<String, Object> factura : lstFacturaComp){

                listaItemFactura = (List<Map<String,Object>>)factura.get("lstItemFactura");

                if(!CollectionUtils.isEmpty(listaItemFactura)){
                    for(Map<String, Object> item : listaItemFactura){

                        //serieItems por Item
                        if( item.get("lstSeriesItem")!= null && !item.get("lstSeriesItem").toString().isEmpty()){
                            List<Map<String,Object>> lstSeriesItem = (List<Map<String,Object>>)item.get("lstSeriesItem");


                            for (Iterator it = lstSeriesItem.iterator(); it.hasNext();)
                            {
                                Map serieItem = (HashMap) it.next();

                                if("1".equals(serieItem.get("IND_CORRELACION_REMOVIDA")) && serieItem.get("IND_DEL").toString().equals("1")
                                        && !this.indicarCorrelacionPreExistente(serieItem, lstSeriesItemAnt)){

                                    it.remove();
                                }
                            }

                        }

                        // lista SeriesItem general
                        if(!CollectionUtils.isEmpty(lstSeriesItemActual)){

                            for (Iterator it = lstSeriesItemActual.iterator(); it.hasNext();)
                            {
                                Map serieItem = (HashMap) it.next();

                                if("1".equals(serieItem.get("IND_CORRELACION_REMOVIDA")) && serieItem.get("IND_DEL").toString().equals("1")
                                        && !this.indicarCorrelacionPreExistente(serieItem, lstSeriesItemAnt)){

                                    it.remove();
                                }
                            }
                        }
                    }
                }
            }
        }

        params.put("mapCabDeclaraActual", mapCabDeclaraActual);
        params.put("lstSeriesItemActual", lstSeriesItemActual);

    }


    /** Valida si una correlaci�n existe en base de datos(serieItemAnt = la lista de correlaciones antigua)
     * @param seriesItem
     * @param lstSeriesItemAnt
     * @return [boolean]
     */
    private boolean indicarCorrelacionPreExistente(Map<String,Object> seriesItem, List<Map<String, Object>> lstSeriesItemAnt){

        boolean indicador = false;
        for(Map<String, Object> serieItemAnt : lstSeriesItemAnt){
            if(serieItemAnt.get("NUM_SECITEM").toString().equals(seriesItem.get("NUM_SECITEM").toString())
                    && serieItemAnt.get("NUM_SECSERIE").toString().equals(seriesItem.get("NUM_SECSERIE").toString())){

                indicador = true;
                break;
            }
        }

        return indicador;

    }

    /** Valida si el item marcado para eliminar tambi�n se encuentra correlacionado
     *  a otra serie diferente a la serie marcada para eliminar
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public ModelAndView validarExistenCorrelacionesSerieItem(HttpServletRequest request, HttpServletResponse response)
            throws Exception{

        JSONArray arrayItemsCheck = JSONArray.fromObject(request.getParameter("hdn_lstItemsEstCheck"));
        List<Map<String,Object>> lstItemEstCheck = (List<Map<String, Object>>) JSONArray.toCollection(arrayItemsCheck, Map.class);
        List<Map<String, Object>> listaItemFactura = new ArrayList<Map<String, Object>>();
        ServletWebRequest webRequest = new ServletWebRequest(request);
        String num_serie = request.getParameter("num_serie");
        String num_corredoc = webRequest.getParameter("hdn_num_corredoc");

        List<Map<String, Object>> listaSeriesItem = (List<Map<String, Object>>) request.getSession().getAttribute("lstSeriesItemActual");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        listaItemFactura =  formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);

        //Validaci�n correlaciones desactivar item
        boolean existe = false;
        String seriesRelacionadas = "";
        List<Map<String, String>> mensajeResult = new ArrayList<Map<String,String>>();

        for(Map<String,Object> itemEstCheck : lstItemEstCheck){
            for(Map<String,Object> item : listaItemFactura){
                if(num_corredoc.equals(item.get("NUM_CORREDOC").toString())
                        && itemEstCheck.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())) {
                    existe = false;
                    seriesRelacionadas = "";
                    for(Map<String, Object> serieItem : listaSeriesItem){

                        if(num_corredoc.equals(serieItem.get("NUM_CORREDOC").toString())
                                && !num_serie.equals(serieItem.get("NUM_SECSERIE").toString())
                                && serieItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())
                                && serieItem.get("IND_DEL").toString().equals("0")
                                && Boolean.parseBoolean(itemEstCheck.get("EST_CHECK").toString())){
                            existe = true;

                            seriesRelacionadas = seriesRelacionadas + (seriesRelacionadas.equals("")?"":", ")+ serieItem.get("NUM_SECSERIE").toString();
                        }
                    }

                    if(existe){
                        String mensaje = "El Item " + item.get("NUM_SECITEM").toString() +" a eliminar tambi�n se encuentra correlacionado a la(s) serie(s) "+seriesRelacionadas+".";
                        Map<String, String> mapMensje = new HashMap<String, String>();
                        mapMensje.put("desError", mensaje);
                        mensajeResult.add(mapMensje);

                    }
                }
            }
        }

        if(!CollectionUtils.isEmpty(mensajeResult)){
            String msg = "Al eliminar el/los �tem(s) solo se descontar�(n) la(s) cantidad(es) comercial(es) correlacionada a la serie eliminada. ";
            Map<String, String> mapMensje = new HashMap<String, String>();
            mapMensje.put("desError", msg);
            mensajeResult.add(mapMensje);
        }

        boolean indicadorItemsSinMarcar = false;
        for(Map<String,Object> itemEstCheck : lstItemEstCheck){

            if(Boolean.parseBoolean(itemEstCheck.get("EST_CHECK").toString())){
                indicadorItemsSinMarcar = true;
            }
        }
        String indicadorNumCorrelaciones = "";
        List<Map<String, Object>> lstSeriesItemNew = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> seriesItemActual : listaSeriesItem)
        {
            if (seriesItemActual.get("NUM_SECSERIE").toString().equals(num_serie)
                    && seriesItemActual.get("IND_DEL").toString().equals("0"))
            {
                lstSeriesItemNew.add(seriesItemActual);
                indicadorNumCorrelaciones = String.valueOf(lstSeriesItemNew.size());
            }
        }

        Ordenador.sortDesc(lstSeriesItemNew, "NUM_SECITEM", Ordenador.ASC);
        String itemsDeLaSerie = "";
        for(Map<String,Object> serieItem : lstSeriesItemNew){
            itemsDeLaSerie = itemsDeLaSerie + (itemsDeLaSerie.equals("")?"":", ")+ serieItem.get("NUM_SECITEM").toString();
        }

        ModelAndView view = new ModelAndView(this.jsonView, "mensajeResult", mensajeResult);
        view.addObject("itemsDeLaSerie", itemsDeLaSerie);
        view.addObject("indicadorItemsSinMarcar", indicadorItemsSinMarcar);
        view.addObject("indicadorNumCorrelaciones", indicadorNumCorrelaciones);
        return view;
    }


    /** Inserta/actualiza las listas de correlaci�n(seriesItem) asociadas por item de acuerdo a la lista
     *  de correlaciones generales en session "lstSeriesItemActual" para mantenerlas sincronizadas
     * @param mapCabDeclaraActual
     * @param lstSeriesItemActual
     */
    private void actualizaSerieItemsPorItemDeFactura(Map<String, Object> mapCabDeclaraActual, List<Map<String,
            Object>> lstSeriesItemActual){

        List<Map<String, Object>> lstItemFactura = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItem = new ArrayList<Map<String, Object>>();
        Map<String, Object> serieItemCopia = new HashMap<String, Object>();

        int index = 0;
        List<Map> lstProve = (ArrayList) mapCabDeclaraActual.get("lstFormBProveedor");

        for(Map<String, Object> serieItemActual : lstSeriesItemActual){

            for (Map prov : lstProve){
                String codProv = prov.get("num_secprove").toString().trim();

                if (codProv.equals(serieItemActual.get("NUM_SECPROVE").toString())){
                    List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");

                    for (Map comPago : lstComproBPago){
                        String secFact = comPago.get("num_secfact").toString().trim();

                        if (secFact.equals(serieItemActual.get("NUM_SECFACT").toString())){

                            lstItemFactura = (List<Map<String, Object>>)comPago.get("lstItemFactura");
                            if(!CollectionUtils.isEmpty(lstItemFactura)){
                                for(Map<String, Object> item : lstItemFactura){

                                    if(item.get("NUM_SECITEM").toString().equals(serieItemActual.get("NUM_SECITEM").toString())){

                                        //Actualizar
                                        lstSeriesItem = (List<Map<String, Object>>)item.get("lstSeriesItem");

                                        if(!CollectionUtils.isEmpty(lstSeriesItem)){
                                            index = 0;
                                            for(Map<String, Object> serieItem : lstSeriesItem){

                                                serieItemCopia = new HashMap<String, Object>();
                                                if(serieItem.get("NUM_SECITEM").toString().equals(serieItemActual.get("NUM_SECITEM").toString())
                                                        && serieItem.get("NUM_SECSERIE").toString().equals(serieItemActual.get("NUM_SECSERIE").toString())){

                                                    serieItemCopia = Utilidades.copiarMapa(serieItemActual);
                                                    lstSeriesItem.set(index, serieItemCopia);
                                                    break;
                                                }
                                                index++;
                                            }
                                        }

                                        //Insertar
                                        Map<String, Object> fbKeys = new HashMap<String, Object>();
                                        Map<String, Object> serieItemSearch = new HashMap<String, Object>();
                                        fbKeys.put("NUM_SECSERIE", serieItemActual.get("NUM_SECSERIE").toString());
                                        fbKeys.put("NUM_SECITEM", serieItemActual.get("NUM_SECITEM").toString());

                                        serieItemSearch = (Map<String, Object>)Utilidades.obtenerElemento(lstSeriesItem, fbKeys);

                                        if(serieItemSearch==null || serieItemSearch.isEmpty()){
                                            if(CollectionUtils.isEmpty(lstSeriesItem)){
                                                lstSeriesItem = new ArrayList<Map<String, Object>>();
                                            }
                                            lstSeriesItem.add(serieItemActual);

                                            item.put("lstSeriesItem", lstSeriesItem);

                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**Lista las facturas (sin repetir) a partir de una lista ingresada como par�metro
     * @param lstLista
     * @return List<Map<String,Object>>
     */
    private List<Map<String,Object>> filtrarFacturas(List<Map<String, Object>> lstLista){

        List<Map<String,Object>> lstFactura = new ArrayList<Map<String,Object>>();
        Map<String,Object> factura = null;
        Map<String,Object> factResult = null;
        int index = 0;
        for(Map<String,Object> item : lstLista){
            factura = new HashMap<String,Object>();
            if(index == 0){
                factura.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
                factura.put("NUM_SECFACT", item.get("NUM_SECFACT"));
                factura.put("NUM_SECPROVE", item.get("NUM_SECPROVE"));
                lstFactura.add(factura);
            }
            index++;
            factura = new HashMap<String,Object>();
            factura.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
            factura.put("NUM_SECFACT", item.get("NUM_SECFACT"));
            factura.put("NUM_SECPROVE", item.get("NUM_SECPROVE"));

            factResult = Utilidades.obtenerElemento(lstFactura,factura);
            if(factResult==null || factResult.isEmpty()){
                lstFactura.add(factura);
            }
        }

        return lstFactura;
    }


    /** M�todo que retorna el listado de series, es invocado cuando a�n no se carg� la lista de series en sessi�n
     * @param request
     * @return List<Map<String, Object>>
     */
    private List<Map<String, Object>> buscarListadoSeries(HttpServletRequest request){

        HttpSession session = request.getSession();
        Map<String,String> params = new HashMap<String,String>();
        params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
        params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
        params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
        params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
        params.put("ann_presen", request.getParameter("hdn_ann_presen"));
        params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
        params.put("acceso", tipoDiligencia != null ? tipoDiligencia : "");
        Map<String, Object> mapCabDeclara = (Map<String, Object>) session.getAttribute("mapCabDeclaraActual");

        // Para Declaracion en Proceso se filtran las Series
        params.put("estadoDUA", mapCabDeclara.get("COD_ESTDUA").toString());

        if ("10".equals(tipoDiligencia))
        {
            if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                    && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
            {
                params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
            }

        }

        List<Map<String, Object>> lstDetDeclara = serieService.obtenerListadoSeries(params);

        return lstDetDeclara;
    }

    /** M�todo que valida cantidad, montos y correspondencia de series e items cuando la declaraci�n es del formato B
     * @param request
     * @param response
     * @return ModelAndView
     */
    public ModelAndView validarDatosCorrelacion(HttpServletRequest request, HttpServletResponse response){

        List<Map<String,Object>> lstMsgValidaciones = new ArrayList<Map<String,Object>>();
        List<Map<String, Object>> detDeclaraViewListCopia = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>)
                WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");

        if (CollectionUtils.isEmpty(lstSeriesItemActual)){
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC"));
            List lstSeriesItem = serieService.obtenerSeriesItem(param);

            lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
        }

        List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
                request,"lstDetDeclaraActual");
        if(CollectionUtils.isEmpty(detDeclaraViewList)){

            detDeclaraViewListCopia = buscarListadoSeries(request);
        }else{
            detDeclaraViewListCopia = Utilidades.copiarLista((List)detDeclaraViewList);
        }

        List<Map<String, Object>> lstItemsTotalActual = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);


        if(!CollectionUtils.isEmpty(detDeclaraViewListCopia)){

            if(declaracionActual.get("IND_FORMBPROVEEDOR") != null && declaracionActual.get("IND_FORMBPROVEEDOR").toString().equals("0")){

                this.validarSerieCorrelacionada(detDeclaraViewListCopia, lstSeriesItemActual, lstMsgValidaciones);

                if(CollectionUtils.isEmpty(lstMsgValidaciones)){
                    this.validarItemCorrelacionado(lstItemsTotalActual, lstSeriesItemActual, lstMsgValidaciones);
                }

                if(CollectionUtils.isEmpty(lstMsgValidaciones)){
                    this.validarFobYCntUniDelItem(lstSeriesItemActual, lstMsgValidaciones, lstItemsTotalActual);
                }

                if(CollectionUtils.isEmpty(lstMsgValidaciones)){
                    this.validarFobYCntComerDeSerie(detDeclaraViewListCopia, lstMsgValidaciones, lstSeriesItemActual);
                }

				/* amancilla se quita ya lo valida el sedia
			if(CollectionUtils.isEmpty(lstMsgValidaciones)){
			  this.validarMtoFactura(declaracionActual, lstMsgValidaciones, lstSeriesItemActual);
			}*/

            }
        }

        return new ModelAndView(this.jsonView, "lstMsgValidaciones", lstMsgValidaciones);

    }

    /** Valida si la cantidad comercial de la serie es diferente al acumulado en sus correlaciones
     * valida si el monto fobDol de la serie es diferente al acumulado en sus correlaciones
     * @param detDeclaraViewList
     * @param lstMsgValidaciones
     * @param lstSeriesItemActual
     */
    private void validarFobYCntComerDeSerie(List<Map<String,Object>> detDeclaraViewList, List<Map<String,Object>> lstMsgValidaciones,
                                            List<Map<String, Object>> lstSeriesItemActual){

        //Valida CNT_COMER(serie) igual a suma de CNT_MER(serieItem),
        //MTO_FOBDOL igual a sumatoria de MTO_FOB(serieItem)  sin considerar series pendientes y eliminados

        StringBuilder mensaje = new StringBuilder("");
        BigDecimal sumCntMer = BigDecimal.ZERO;
        BigDecimal sumMtoFob = BigDecimal.ZERO;
        Map<String,Object> msgValidacion = new HashMap<String,Object>();
        for(Map<String,Object> serie : detDeclaraViewList){
            sumCntMer = BigDecimal.ZERO;
            sumMtoFob = BigDecimal.ZERO;
            if(!Utilidades.esUnaRegistroMarcadaParaEliminar(serie) && !serie.get("IND_TIPO_REGISTRO").toString().equals("1")){
                for(Map<String,Object> serieItem : lstSeriesItemActual){
                    if(serie.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())){
                        if(serieItem.get("IND_DEL").toString().equals("0")){
                            sumCntMer = sumCntMer.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")));
                            sumMtoFob = sumMtoFob.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("MTO_FOB")));
                        }
                    }
                }

                //amancilla se sube el margen  BigDecimal margen = new BigDecimal(Constantes.DIF_MAX_CANT.toString());
                BigDecimal margen = new BigDecimal(0.1);
                BigDecimal dif = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(serie.get("CNT_COMER")), sumCntMer);
                if (!SunatNumberUtils.isLessOrEqualsThanParam(dif, margen)) {
                    BigDecimal difCantComer = SunatNumberUtils.scaleHalfUp(dif, 3);
                    msgValidacion = new HashMap<String,Object>();
                    mensaje.append("Hay una diferencia de "+difCantComer.toString()
                            + " entre la cantidad comercial de la serie "+serie.get("NUM_SECSERIE").toString()
                            + " y el acumulado en sus correlaciones (sumatoria de cantidades en correlaciones asociadas: "
                            + SunatNumberUtils.scaleHalfUp(sumCntMer, 3).toString()+").");

                    msgValidacion.put("validacion", mensaje.toString());
                    lstMsgValidaciones.add(msgValidacion);
                    break;
                }


                //amancilla BigDecimal margenMonto = new BigDecimal(Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO));
                BigDecimal margenMonto = new BigDecimal(1);
                BigDecimal difMonto = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(serie.get("MTO_FOBDOL")), sumMtoFob);
                if (!SunatNumberUtils.isLessOrEqualsThanParam(dif, margenMonto)) {
                    BigDecimal difMtofobDol = SunatNumberUtils.scaleHalfUp(difMonto, 3);
                    msgValidacion = new HashMap<String,Object>();
                    mensaje.append("Hay una diferencia de "+difMtofobDol.toString()
                            + " entre el Monto FobDol de la serie "+serie.get("NUM_SECSERIE").toString()
                            + " y el acumulado en sus correlaciones (sumatoria de Monto FobDol en correlaciones asociadas: "
                            + SunatNumberUtils.scaleHalfUp(sumMtoFob, 3).toString()+").");

                    msgValidacion.put("validacion", mensaje.toString());
                    lstMsgValidaciones.add(msgValidacion);
                    break;
                }

            }
        }

    }

    /** Valida si hay diferencia entre la cantidad unitaria del item y el acumulado es sus correlaciones,
     *  valida si hay diferencia entre el monto Fob del �tem y el acumulado es sus correlaciones
     *  (mediante la correlaci�n del item con sus series asociadas)
     * @param lstSeriesItemActual
     * @param lstMsgValidaciones
     * @param lstItemsTotalActual
     */
    private void validarFobYCntUniDelItem(List<Map<String, Object>> lstSeriesItemActual, List<Map<String,Object>> lstMsgValidaciones,
                                          List<Map<String, Object>> lstItemsTotalActual){

        //Valida CNT_UNI(item) igual a suma de CNT_MER(serieItem),
        //MTO_FOBITEM(item) igual a sumatoria de MTO_FOB(serieItem)  sin considerar los pendientes y eliminados
        BigDecimal sumCntMer = BigDecimal.ZERO;
        BigDecimal sumMtoFob = BigDecimal.ZERO;
        StringBuilder mensaje = new StringBuilder("");
        Map<String,Object> msgValidacion = new HashMap<String,Object>();
        for(Map<String,Object> item : lstItemsTotalActual){
            sumCntMer = BigDecimal.ZERO;
            sumMtoFob = BigDecimal.ZERO;
            if(item.get("IND_DEL").toString().equals("0") && !item.get("IND_TIPO_REGISTRO").toString().equals("1")){
                for(Map<String,Object> serieItem : lstSeriesItemActual){
                    if(item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())){
                        if(serieItem.get("IND_DEL").toString().equals("0")){
                            sumCntMer = sumCntMer.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("CNT_MERC")));
                            sumMtoFob = sumMtoFob.add(Utilidades.validaVacioRetornaBigDecimal(serieItem.get("MTO_FOB")));
                        }
                    }
                }
                //amancilla BigDecimal margen = new BigDecimal(Constantes.DIF_MAX_CANT.toString());
                BigDecimal margen = new BigDecimal(0.1);
                BigDecimal dif = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(item.get("CNT_UNI")), sumCntMer);
                if (!SunatNumberUtils.isLessOrEqualsThanParam(dif, margen)) {
                    BigDecimal difCntUni = SunatNumberUtils.scaleHalfUp(dif, 3);
                    msgValidacion = new HashMap<String,Object>();
                    mensaje.append("Hay una diferencia de "+difCntUni.toString()
                            + " entre la Cantidad Unitaria del �tem "+item.get("NUM_SECITEM").toString()
                            + " y el acumulado en sus correlaciones (sumatoria de cantidad comercial en correlaciones asociadas: "
                            + SunatNumberUtils.scaleHalfUp(sumCntMer, 3).toString()+",\n"
                            + "cantidad unitaria del �tem: "+item.get("CNT_UNI").toString()+").");

                    msgValidacion.put("validacion", mensaje.toString());
                    lstMsgValidaciones.add(msgValidacion);
                    break;
                }


                //amancilla BigDecimal margenMonto = new BigDecimal(Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO));
                BigDecimal margenMonto = new BigDecimal(1);
                BigDecimal difMonto = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(item.get("MTO_FOBITEM")), sumMtoFob);
                if (!SunatNumberUtils.isLessOrEqualsThanParam(difMonto, margenMonto)) {
                    BigDecimal difMtofob = SunatNumberUtils.scaleHalfUp(difMonto, 3);
                    msgValidacion = new HashMap<String,Object>();
                    mensaje.append("Hay una diferencia de "+difMtofob.toString()
                            + " entre el Monto FobItem del �tem "+item.get("NUM_SECITEM").toString()
                            + " y el acumulado en sus correlaciones (sumatoria de Monto Fob de correlaciones asociadas al �tem: "
                            + SunatNumberUtils.scaleHalfUp(sumMtoFob, 3).toString()+").");

                    msgValidacion.put("validacion", mensaje.toString());
                    lstMsgValidaciones.add(msgValidacion);
                    break;
                }

            }
        }

    }

    /** M�todo que valida si hay diferencia entre el monto de la factura y el acumulado en su detalle
     * @param declaracionActual
     * @param lstMsgValidaciones
     * @param lstSeriesItemActual
     */
    @Deprecated
    /** amancilla se quita ya esta validando un servicio
     private void validarMtoFactura(Map<String, Object> declaracionActual, List<Map<String,Object>> lstMsgValidaciones,
     List<Map<String, Object>> lstSeriesItemActual){

     //Monto FOB de la factura debe ser igual a la sumatoria de su detalle
     Map<String,Object> msgValidacion = new HashMap<String,Object>();
     BigDecimal montoFactura = BigDecimal.ZERO;
     StringBuilder mensaje = new StringBuilder("");
     List<Map> lstProve = (ArrayList) declaracionActual.get("lstFormBProveedor");
     boolean indicador = false;
     for (Map prov : lstProve){

     List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
     for (Map comPago : lstComproBPago){

     montoFactura = Utilidades.validaVacioRetornaBigDecimal(comPago.get("mto_fact"));

     BigDecimal sumMontoFactEnItem = BigDecimal.ZERO;
     List<Map<String, Object>> lstItem = (List<Map<String, Object>>) comPago.get("lstItemFactura");
     if(!CollectionUtils.isEmpty(lstItem)){
     for(Map<String, Object> itemFactura : lstItem){

     if(itemFactura.get("IND_DEL").toString().equals("0")){
     if (!CollectionUtils.isEmpty(lstSeriesItemActual)){
     for (Map<String, Object> itemSerie : lstSeriesItemActual){
     if(itemSerie.get("IND_DEL").toString().equals("0")
     && itemSerie.get("NUM_SECITEM").toString().equals(itemFactura.get("NUM_SECITEM").toString())
     && itemSerie.get("NUM_SECFACT").toString().equals(itemFactura.get("NUM_SECFACT").toString())
     && itemSerie.get("NUM_SECPROVE").toString().equals(itemFactura.get("NUM_SECPROVE").toString())
     && itemSerie.get("NUM_CORREDOC").toString().equals(itemFactura.get("NUM_CORREDOC").toString())){

     BigDecimal bgFobItemSerie = new BigDecimal(itemSerie.get("MTO_FOB").toString());
     sumMontoFactEnItem = sumMontoFactEnItem.add(bgFobItemSerie);
     }
     }
     }
     }
     }

     BigDecimal margen = new BigDecimal(Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO));
     BigDecimal dif = SunatNumberUtils.absoluteDiference(montoFactura, sumMontoFactEnItem);
     if (!SunatNumberUtils.isLessOrEqualsThanParam(dif, margen)) {
     BigDecimal difMtofob = SunatNumberUtils.scaleHalfUp(dif, 3);
     msgValidacion = new HashMap<String,Object>();
     mensaje.append("Hay una diferencia de "+difMtofob.toString()
     + " entre el Monto Fob de la factura "+comPago.get("num_secfact").toString()+" (correspondiente al proveedor "
     + comPago.get("num_secprove").toString()+ ") y el acumulado en sus items activos "
     + "(sumatoria monto fobItem de sus items: "+ SunatNumberUtils.scaleHalfUp(sumMontoFactEnItem, 3).toString()+").");

     msgValidacion.put("validacion", mensaje.toString());
     lstMsgValidaciones.add(msgValidacion);
     indicador = true;
     break;
     }
     }
     }
     if(indicador){
     break;
     }
     }

     }*/

    /** M�todo que valida si una serie tieme correlaci�n
     * @param detDeclaraViewList
     * @param lstSeriesItemActual
     * @param lstMsgValidaciones
     */
    private void validarSerieCorrelacionada(List<Map<String, Object>> detDeclaraViewList, List<Map<String, Object>> lstSeriesItemActual,
                                            List<Map<String,Object>> lstMsgValidaciones){

        boolean encontrado = false;
        String serieNoCorrelacionada = "";
        Map<String,Object> msgValidacion = new HashMap<String,Object>();

        for(Map<String, Object> serie : detDeclaraViewList){
            if(serie.get("IND_DEL").toString().equals("0")){
                encontrado = false;
                for(Map<String, Object> serieItem : lstSeriesItemActual){
                    if(serie.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())
                            && "0".equals(serie.get("IND_DEL").toString())
                            && serieItem.get("IND_DEL").toString().equals("0")){
                        encontrado = true;
                        break;
                    }
                }
                if(!encontrado){
                    serieNoCorrelacionada = serieNoCorrelacionada + (serieNoCorrelacionada.equals("")?"":", ")+ serie.get("NUM_SECSERIE").toString();
                }
            }
        }
        if(!serieNoCorrelacionada.isEmpty()){
            msgValidacion.put("validacion", "La(s) Serie(s) "+serieNoCorrelacionada+ " no se encuentra(n) correlacionada(s)");
            lstMsgValidaciones.add(msgValidacion);
        }
    }

    /** M�todo que valida si un �tem tieme correlaci�n
     * @param lstItemsTotalActual
     * @param lstSeriesItemActual
     * @param lstMsgValidaciones
     */
    private void validarItemCorrelacionado(List<Map<String, Object>> lstItemsTotalActual, List<Map<String, Object>> lstSeriesItemActual,
                                           List<Map<String,Object>> lstMsgValidaciones){

        List<Map<String,Object>> lstItemsNoCorrelacionados = new ArrayList<Map<String,Object>>();
        boolean encontrado = false;
        String itemNoCorrelacionado = "";
        Map<String,Object> msgValidacion = new HashMap<String,Object>();


        for(Map<String, Object> item : lstItemsTotalActual){
            if(item.get("IND_DEL").toString().equals("0")){
                encontrado = false;
                for(Map<String, Object> serieItem : lstSeriesItemActual){
                    if(item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
                            && serieItem.get("IND_DEL").toString().equals("0")){
                        encontrado = true;
                        break;
                    }
                }
                if(!encontrado){
                    lstItemsNoCorrelacionados.add(item);
                }
            }
        }

        List<Map<String,Object>> lstFactura = this.filtrarFacturas(lstItemsNoCorrelacionados);

        if(!CollectionUtils.isEmpty(lstFactura)){
            for(Map<String,Object> fact : lstFactura){
                itemNoCorrelacionado = "";
                msgValidacion = new HashMap<String,Object>();
                for(Map<String,Object> item : lstItemsNoCorrelacionados){
                    if(item.get("NUM_CORREDOC").toString().equals(fact.get("NUM_CORREDOC").toString())
                            && item.get("NUM_SECFACT").toString().equals(fact.get("NUM_SECFACT").toString())
                            && item.get("NUM_SECPROVE").toString().equals(fact.get("NUM_SECPROVE").toString()) ){

                        itemNoCorrelacionado = itemNoCorrelacionado + (itemNoCorrelacionado.equals("")?"":", ")+ item.get("NUM_SECITEM").toString();
                    }
                }
                msgValidacion.put("validacion", "El/Los �tem(s) "+itemNoCorrelacionado+
                        " correspondiente(s) a la factura "+fact.get("NUM_SECFACT").toString()+
                        ", que pertenece(n) al proveedor "+fact.get("NUM_SECPROVE").toString()+" no se encuentra(n) correlacionado(s)");
                lstMsgValidaciones.add(msgValidacion);
            }
        }
    }

    /** M�todo que actualiza la lista de correlaciones en sesion "lstSeriesItemActual"  de acuerdo a los cambios ingresados
     *  al �tem desde la pantalla de modificaci�n de �tems - secci�n Series asociadas por Item
     * @param lstSeriesItemPorItem
     * @param request
     */
    private void actualizarLstSeriesItemActualDesdeItem(List<Map<String, Object>> lstSeriesItemPorItem, HttpServletRequest request){

        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        FechaBean fecActual = new FechaBean();

        HttpSession session = request.getSession();
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("NUM_CORREDOC", request.getParameter("hdn_num_corredoc"));

        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,
                "lstSeriesItemActual");
        if (CollectionUtils.isEmpty(lstSeriesItemActual)){
            List lstSeriesItem = serieService.obtenerSeriesItem(param);

            lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);

        }

        int index = 0;
        if(!CollectionUtils.isEmpty(lstSeriesItemPorItem)){
            for(Map<String, Object> serieItem : lstSeriesItemPorItem){
                index = 0;
                for(Map<String, Object> serieItemAct : lstSeriesItemActual){
                    if(serieItem.get("NUM_SECITEM").toString().equals(serieItemAct.get("NUM_SECITEM").toString())
                            && serieItem.get("NUM_SECSERIE").toString().equals(serieItemAct.get("NUM_SECSERIE").toString())
                            && "0".equals(serieItem.get("IND_DEL").toString())){

                        serieItem.put("COD_USUMODIF", bUsuario.getNroRegistro());
                        serieItem.put("FEC_MODIF",fecActual.getTimestamp());
                        lstSeriesItemActual.set(index, serieItem);
                    }
                    index++;
                }
            }
            session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
        }
    }

    /** M�todo que valida si una serie puede ser recuperada, valida si los �tems de la serie tienen saldo suficiente a recuperar
     * @param request
     * @param response
     * @return
     */
    public ModelAndView validarRecuperacionSerie(HttpServletRequest request, HttpServletResponse response){

        ModelAndView view = new ModelAndView(this.jsonView);
        String mensaje = "";
        try{
            List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");


            if(request.getParameter("est_serie").toString().equals("0")
                    && declaracionActual.get("IND_FORMBPROVEEDOR").toString().equals("0")){

                String numSecSerie = request.getParameter("num_serie");

                StringBuilder msgBuilder = new StringBuilder();
                BigDecimal cantMercActiva = BigDecimal.ZERO;
                BigDecimal cantMercInactiva = BigDecimal.ZERO;

                List<Map<String,Object>> listItemsdeUnaSerie = new ArrayList<Map<String,Object>>();
                List<Map<String,Object>> itemsTotal = formatoValorService.obtenerListaItemsDeclaracionActual(declaracionActual);
                for(Map<String, Object> mapItem : itemsTotal){
                    for(Map mapSerie : lstSeriesItemActual){
                        if(mapSerie.get("NUM_SECSERIE").toString().equals(numSecSerie)
                                && mapSerie.get("NUM_SECITEM").toString().equals(mapItem.get("NUM_SECITEM").toString())){

                            listItemsdeUnaSerie.add(mapItem);
                            break;
                        }
                    }
                }

                for(Map<String,Object> item : listItemsdeUnaSerie){
                    cantMercActiva = BigDecimal.ZERO;
                    cantMercInactiva = BigDecimal.ZERO;
                    for(Map<String,Object> serieItem : lstSeriesItemActual){

                        if(item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
                                && serieItem.get("IND_DEL").toString().equals("0")){

                            cantMercActiva = cantMercActiva.add(Utilidades.toBigDecimal(serieItem.get("CNT_MERC")));
                        }

                        if(item.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
                                && serieItem.get("NUM_SECSERIE").toString().equals(numSecSerie)
                                && !"1".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_CORRELACION_REMOVIDA")))
                                && ("0".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_DEL_ITEM").toString()))
                                || "0".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_UNICA_CORRELACION").toString())))
                                && serieItem.get("IND_DEL").toString().equals("1")){

                            cantMercInactiva = Utilidades.toBigDecimal(serieItem.get("CNT_MERC"));
                        }
                    }

                    BigDecimal sumaCalculaCntUniMerc = cantMercActiva.add(cantMercInactiva);
                    if(Utilidades.toBigDecimal(item.get("CNT_UNI")).compareTo(sumaCalculaCntUniMerc) == -1){
                        BigDecimal dif = Utilidades.validaVacioRetornaBigDecimal(item.get("CNT_UNI")).subtract(sumaCalculaCntUniMerc);
                        BigDecimal difCntMerc = SunatNumberUtils.scaleHalfUp(dif, 3);
                        msgBuilder = new StringBuilder();

                        msgBuilder.append("El �tem "+item.get("NUM_SECITEM").toString()+ " no tiene saldo suficiente a recuperar."
                                +" Hay una diferencia de " + difCntMerc.toString() + " entre la cantidad a recuperar "
                                +" y la cantidad unitaria del �tem (cantidad Unitaria del Item: "+item.get("CNT_UNI").toString()+"). \n");
                        mensaje = mensaje + msgBuilder.toString();

                    }
                }

            }

        }catch (Exception e) {
            log.error("*** ERROR ***", e);
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

            view = new ModelAndView(this.jsonView, "beanM", rBean);
        }
        finally
        {
        }
        return new ModelAndView(this.jsonView, "msgRecuperacionSerie", mensaje);

    }

    /** M�todo que valida si la serie est� activa
     * @param request
     * @param serieItem
     * @param lstDetDeclaraViewActual
     * @return
     */
    private boolean validarSerieActiva(HttpServletRequest request, Map<String, Object> serieItem,
                                       List<Map<String,Object>> lstDetDeclaraViewActual){

        boolean indicador = false;
        for(Map<String,Object> serie : lstDetDeclaraViewActual){

            if(serie.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())
                    && serie.get("NUM_CORREDOC").toString().equals(serieItem.get("NUM_CORREDOC").toString())
                    && serie.get("IND_DEL").toString().equals("0")){

                indicador = true;
            }
        }

        return indicador;
    }


    /** Retorna un boolean que indica si los items eliminados se van a incluir en la consulta (de acuerdo al estado de la declaraci�n)
     * @param declaracionActual
     * @param request
     * @return
     */
    private boolean validarMostrarItemsEliminados(Map<String, Object> declaracionActual, HttpServletRequest request){

        boolean indMostrarEliminados = true;
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
        String estadoDua = declaracionActual.get("COD_ESTDUA").toString();
        String estadoRectiOficio = "";
        if ("10".equals(tipoDiligencia))
        {
            if (declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                    && "EN_PROCESO".equals(declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
            {
                estadoRectiOficio = "EN_PROCESO";
            }

        }

        if ((Constantes.ESTADO_RECTI_PROCESO.equals(estadoDua) || "EN_PROCESO".equals(estadoRectiOficio))
                && !(tipoDiligencia.equals(Constantes.MODO_DILIGENCIA_CONSULTA))) {

            indMostrarEliminados = false;
        }

        return indMostrarEliminados;
    }

    /** Restaura la cantidad unitaria del item (preexistente) cuando se elimina la totalidad del item
     * El m�todo es invocado al grabar la diligencia
     * @param declaracionActual
     * @param request
     * @return
     */
    private Map<String,Object> restaurarCantidadYFobItemEliminado(Map<String, Object> params){

        Map mapCabDeclara = (HashMap) params.get("mapCabDeclara");
        Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
        List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
        List<Map<String,Object>> lstForBProveedorAnt = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
        for (Map<String, Object> mapa : lstForBProveedor){

            Map fbKeys = new HashMap<String, Object>();
            fbKeys.put("num_corredoc", mapa.get("num_corredoc"));
            fbKeys.put("num_secprove", mapa.get("num_secprove"));
            Map<String,Object> mapProveedorAnt = Utilidades.obtenerElemento(lstForBProveedorAnt, fbKeys);

            List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");
            List<Map<String,Object>> lstComproBPagoAnt = (List<Map<String, Object>>) mapProveedorAnt.get("lstComproBPago");

            if(!CollectionUtils.isEmpty(lstComproBPago) && !CollectionUtils.isEmpty(lstComproBPagoAnt)){
                for (Map<String, Object> mapaFactura : lstComproBPago){

                    if(mapaFactura.get("lstItemFactura")!=null && !mapaFactura.get("lstItemFactura").toString().isEmpty()){
                        List<Map<String,Object>> lstItemFactura = (List<Map<String,Object>>)mapaFactura.get("lstItemFactura");
                        fbKeys.put("num_secfact", mapaFactura.get("num_secfact"));
                        fbKeys.put("num_secprove", mapaFactura.get("num_secprove"));
                        fbKeys.put("num_corredoc", mapaFactura.get("num_corredoc"));
                        Map<String,Object> mapaFacturaAnt = Utilidades.obtenerElemento(lstComproBPagoAnt, fbKeys);
                        List<Map<String,Object>> lstItemFacturaAnt = (List<Map<String,Object>>)mapaFacturaAnt.get("lstItemFactura");

                        for (Map<String, Object> item : lstItemFactura){
                            if("0".equals(item.get("ESTADO_REGISTRO").toString())
                                    && ("1").equals(item.get("IND_DEL").toString())){

                                Map<String,Object> keys = new HashMap<String,Object>();
                                keys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
                                keys.put("NUM_SECITEM", item.get("NUM_SECITEM"));


                                Map<String,Object> itemAnt = Utilidades.obtenerElemento(lstItemFacturaAnt, keys);
                                if(itemAnt !=null && itemAnt.get("IND_DEL").toString().equals("0")){
                                    item.put("CNT_UNI", itemAnt.get("CNT_UNI"));
                                    item.put("MTO_FOBITEM", itemAnt.get("MTO_FOBITEM"));
                                    item.put("MTO_FOBUNITARIO", itemAnt.get("MTO_FOBUNITARIO"));
                                }
                            }
                        }
                    }
                }
            }
        }

        return  (HashMap)params.get("mapCabDeclaraActual");
    }

    //RIN08
    public ModelAndView validarSeriePecoAmazoniaModificada(HttpServletRequest request, HttpServletResponse response)throws Exception{
        ModelAndView res = new ModelAndView(this.jsonView);
        String msg = "";
        MensajeBean rBean = new MensajeBean();
        boolean valorCondicion;
        Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) WebUtils
                .getSessionAttribute(request, "mapCabDeclaraActual");
        String aduanaDestino = mapCabDeclaraActual.get("COD_ADUDEST")
                .toString();
        Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils
                .getSessionAttribute(request, "mapCabDeclara");
        FechaBean fechaBean = new FechaBean(
                (java.sql.Timestamp) mapCabDeclara.get("FEC_DECLARACION"));
        Map<String, Object> requestParameterMap = new HashMap<String, Object>();
        requestParameterMap.putAll(request.getParameterMap());
        String num_secserie = Utilidades
                .crearCadenaDesdeObjeto(requestParameterMap
                        .get("hdn_num_secserie"));
        requestParameterMap.put("cod_adudest", aduanaDestino);
        requestParameterMap.put("num_secserie", num_secserie);
        requestParameterMap.put("cod_aduana", mapCabDeclara.get("COD_ADUANA"));
        requestParameterMap.put("fec_declaracion",
                fechaBean.getFormatDate("yyyyMMdd"));
        try {
            PecoAmazoniaService pecoAmazoniaService = fabricaDeServicios
                    .getService("pecoAmazoniaService");
            msg = pecoAmazoniaService
                    .validarSeriePecoAmazoniaModificada(requestParameterMap);
            res.addObject("validacion", msg);
        } catch (Exception e) {
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Error al efectuar la validacion de Peco Amazonia en la serie actual");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }
        return res;
    }



    public ModelAndView cargarComboAduanasDestino(HttpServletRequest request,HttpServletResponse response) throws Exception
    {
        log.debug("cargarComboAduanasDestino");
        log.debug("==========================================");

        Map<String, Object> m = new HashMap<String, Object>();
        Map<String, Object> modelo = new HashMap<String, Object>();

        List<Map<String, Object>> lst = new ArrayList<Map<String, Object>>();
        m.put("c", "118");
        m.put("n", "118-MARITIMA DEL CALLAO");
        lst.add(m);
        m= new HashMap<String, Object>();
        m.put("c", "046");
        m.put("n", "046-PAITA");
        lst.add(m);
        m= new HashMap<String, Object>();
        m.put("c", "235");
        m.put("n", "235-AEREA DEL CALLAO");
        lst.add(m);
        modelo.put("identifier", "c");
        modelo.put("label", "n");
        modelo.put("items", lst);
        return new ModelAndView("jsonView", modelo);

    }


    //public Map<String, Object> validarDiligenciaAduanaDestino(HttpServletRequest request, HttpServletResponse response) {
    public String validarDiligenciaAduanaDestino(Map<String, Object> mapCabDeclara, String resultadoAduanaDestinoMercancia) {
        Map<String, Object> res = new HashMap<String, Object>();
        String validacion="";
        //String rpta= (String) WebUtils.getSessionAttribute( request, "estadoResultadoAduanaDestinoMercancia");

        //Map<String, Object> mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute( request, "mapCabDeclara");
// validar expediente o solicitud para todos los casos
        //if (resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO) ||resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO)){
        String codProcedim [] = Constantes.LISTA_CODIGOS_PROCEDIM_PECO_AMAZONIA;
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("ANN_PRESEN", mapCabDeclara.get("ANN_PRESEN").toString());
        params.put("COD_ADUANA", mapCabDeclara.get("COD_ADUDEST"));
        params.put("NUM_DECLARACION",mapCabDeclara.get("NUM_DECLARACION") );
        params.put("O_TIPO", "17");//en el caso de regimen 10 impo en la tabla drefexp es 17
        params.put("CODPROCEDIM", codProcedim);
        params.put("COD_ADUANA_DECLA", mapCabDeclara.get("COD_ADUANA"));
        Expedi expediPecoAmazonia = declaracionService.findExpediDocAsociadoPecoAmazonia(params);//expediente de peco/amazonia
//MOL PAS20181U220200069
        Date fechaDocumentoRecFisico = SunatDateUtils.getDefaultDate();
        //El expediente se busca en la aduana de destino por lo tanto siempre sera el de la aduana
        //if (expediPecoAmazonia.getCodiAdua() != null &&  !expediPecoAmazonia.getCodiAdua().equals(mapCabDeclara.get("COD_ADUDEST"))){
        //  validacion="El c�digo de aduana del expediente de la Solicitud de regularizaci�n debe ser igual al c�digo de Aduana de Destino. \n \n";
        //}
        // PAS20181U220200069
        boolean tieneExpediente = true;
        if (expediPecoAmazonia.getCodiAdua() == null){
            validacion="No existe expediente de Regularizaci�n PECO/AMAZONIA. \n \n";
            tieneExpediente = false;
        }else{//MOL PAS20181U220200069
            fechaDocumentoRecFisico = SunatDateUtils.getDateFromInteger(expediPecoAmazonia.getFecexp());
            ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
            params= new HashMap<String, Object>();
            params.put("numeroCorrelativo", mapCabDeclara.get("NUM_CORREDOC"));
            params.put("codTipoParticipante", "45");
            List<Participante> listado=participanteService.obtenerParticipanteByParameterMap(params);
            if (listado.size()>0 &&  expediPecoAmazonia.getComitNro()!= null && !listado.get(0).getNumeroDocumentoIdentidad().trim().equals(expediPecoAmazonia.getComitNro().trim()) ){
                validacion="El expediente debe estar asociado al n�mero, r�gimen, a�o y RUC consignado en la declaraci�n. \n"+"RUC Importador No: "+listado.get(0).getNumeroDocumentoIdentidad().trim()+"\n"+ "RUC Expediente No: "+expediPecoAmazonia.getComitNro().trim();

            }
        }
        //MOL PAS20181U220200069
        boolean tieneSolicitudRenocimientoFisico = false;
        if(!tieneExpediente){
            validacion="";
            SolicitudPecoAmazoniaService solicitudPecoAmazoniaServiceImpl = fabricaDeServicios.getService("despaduanero2.solicitudPecoAmazoniaService");
            String numCorredocDam = (String) mapCabDeclara.get("NUM_CORREDOC").toString();
            Map<String, Object> mapaSolicitud = new HashMap<String, Object>();
            mapaSolicitud.put("codEstSol", new String[]{"01","02"});
            tieneSolicitudRenocimientoFisico = solicitudPecoAmazoniaServiceImpl.tieneSolicitudReconocimientoFisico( numCorredocDam, mapaSolicitud);
            fechaDocumentoRecFisico = (Date) mapaSolicitud.get("fechaSolicitud");
        }
        if (!(tieneExpediente||tieneSolicitudRenocimientoFisico)){
        	if (!resultadoAduanaDestinoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO)){ //BUG P_SNAA0004-14903
            validacion="No existe expediente de Regularizaci�n PECO/AMAZONIA � solicitud de Regularizaci�n/Reconocimiento F�sico. \n \n";
        	}
        }
        mapCabDeclara.put("fechaDocumentoRecFisico", fechaDocumentoRecFisico);

        //}
        //res.put("validacion",validacion);

        return validacion;
    }

    //MOL PAS20181U220200069
    private String validarPlazoReconocimientoFisico(String codAduana,String codRegimen, String annPresen, String numDeclaracion , Date fechaDeclaracion, String ctacte, Date fechaDocumentoRecFisico,Date varfechaDiligencia){
        Declaracion declaracion = new Declaracion() ;
        NumdeclRef numdeclRefParam = new NumdeclRef();
        numdeclRefParam.setCodaduana(codAduana);
        numdeclRefParam.setCodregimen(codRegimen);
        numdeclRefParam.setAnnprese(annPresen);
        numdeclRefParam.setNumcorre(numDeclaracion);
        declaracion.setNumdeclRef(numdeclRefParam);
        declaracion.setDua(new DUA());
        declaracion.getDua().setFecdeclaracion(fechaDeclaracion);
        declaracion.getDua().getPago().setPagoDeclaracion(new DatoPagoDecla());
        if("".equals(ctacte.trim())){
            declaracion.getDua().getPago().getPagoDeclaracion().setCodgarantia(null);
        }else{
            declaracion.getDua().getPago().getPagoDeclaracion().setCodgarantia(ctacte);
        }
        String mensaje = "";
        PecoAmazoniaService pecoAmazoniaService = fabricaDeServicios.getService("pecoAmazoniaService");
        boolean excedePlazoExpediente = pecoAmazoniaService.excedePlazoSolicitudRectificacion(declaracion,fechaDocumentoRecFisico);
        boolean excedePlazoDiligenciaDestino = pecoAmazoniaService.excedePlazoDiligenciaAduanaDestino(declaracion,varfechaDiligencia);
        if(excedePlazoDiligenciaDestino){
            mensaje = "Fecha de reconocimiento f�sico fuera del plazo. \n \n";

        }else{
            if(excedePlazoExpediente){
                mensaje = "Fecha de solicitud/expediente de regularizaci�n � la fecha de reconocimiento f�sico fuera del plazo, solo procede el retiro del beneficio PECO/ AMAZONIA. \n \n";
            }
        }


        return mensaje;
    }



    @SuppressWarnings("unused")
    private void  enviarAlertaCorreo (HttpServletRequest request){
        //codigo de plantilla=105350
        //Servicio Aviso Electronico =350
        Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        String tipoAviso = "0";
        StringBuffer data;
        JsonSerializer json;
        Map<String, Object> map;
        FechaBean fechaPublicacion =  new FechaBean();
        fechaPublicacion.getCalendar().add(Calendar.DATE, 2);
        FechaBean fechaVigencia = new FechaBean();
        fechaVigencia.getCalendar().add(Calendar.DATE, 2);

        //INICIO RIN08 24022015

        String declaracion = mapCabDeclara.get("COD_ADUANA")+"-"+mapCabDeclara.get("ANN_PRESEN")+"-"+mapCabDeclara.get("COD_REGIMEN")+"-"+mapCabDeclara.get("NUM_DECLARACION");

        Map<String, Object> DatosJefe =  new HashMap<String, Object>();
        DatosJefe.put("cod_aduana", mapCabDeclara.get("COD_ADUANA"));
        DatosJefe.put("declaracion",declaracion);

        List<Map<String, Object>> FindJefeGrupoJEC = asignacionManualService.ObtenerJefeGrupo(DatosJefe);
        ///FIN RIN08 24022015

        Map<String, Object> param=new  HashMap<String, Object>();
        param.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
        param.put("COD_GRUPO", pe.gob.sunat.despaduanero2.asignacion.util.Constantes.GRUPOESPE_CONCLUSION_DESPACHO);
        param.put("COD_ESTREV", pe.gob.sunat.despaduanero2.asignacion.util.Constantes.ESTADO_REVISION_ASIGNADO_CONCLUSION);


        List<Map<String, Object>> listaEspeAsig= asignacionManualService.obtenerEspecAsigDocumento(param);


        //INICIO RIN08 26022015
        boolean SitieneCodFuncionario = false;
        boolean SitieneCodJefe		   = false;

        if(!CollectionUtils.isEmpty(listaEspeAsig)){
            SitieneCodFuncionario = true;
        }else if(listaEspeAsig==null){
            SitieneCodFuncionario = false;
        }

        if(!CollectionUtils.isEmpty(FindJefeGrupoJEC)){
            SitieneCodJefe = true;
        }else if(listaEspeAsig==null){
            SitieneCodJefe = false;
        }
        if ((SitieneCodFuncionario) || (SitieneCodJefe) ) {

            map = new HashMap<String, Object>();
            if((SitieneCodJefe) && (SitieneCodFuncionario)){

                map.put("cod_usuario",new String[]{FindJefeGrupoJEC.get(0).get("cod_pers").toString() ,listaEspeAsig.get(0).get("COD_FUNCIONARIO").toString()});

            }else if(SitieneCodFuncionario) {

                map.put("cod_usuario",new String[]{listaEspeAsig.get(0).get("COD_FUNCIONARIO").toString()});

            }else if((SitieneCodJefe)){

                map.put("cod_usuario",new String[]{FindJefeGrupoJEC.get(0).get("cod_pers").toString()});

            }
            //FIN RIN08 26022015
            map.put("des_asunto", "Diligencia en Aduana de Destino");
            map.put("tip_usuario", "3");
            map.put("cod_aduana", mapCabDeclara.get("COD_ADUANA"));
            map.put("ann_prese", mapCabDeclara.get("ANN_PRESEN"));
            map.put("cod_regimen", mapCabDeclara.get("COD_REGIMEN") );
            map.put("num_declaracion", mapCabDeclara.get("NUM_DECLARACION") );
            map.put("fecha_emision", new FechaBean().getFormatDate("dd/MM/yyyy"));
            
            //PAS20181U220200069 - mtorralba 20190327 - Debe mostrar Aduana Origen 
            Map<String, Object> mapaCatalogo = catalogoAyudaService.getElementoCat("00", mapCabDeclara.get("COD_ADUANA").toString() );
      		String aduanaOrigen = SunatStringUtils.formatoMayusMinus(mapaCatalogo.get("des_datacat").toString());
      		map.put("des_intendencia", aduanaOrigen);

            /*
            switch (new Integer( soporteService.obtenerAduana(request))){
                case 226: map.put("des_intendencia", "Iquitos");
                    break;
                case 217:map.put("des_intendencia", "Pucallpa");
                    break;
                case 271:map.put("des_intendencia", "Tarapoto");
                    break;
                case 55:map.put("des_intendencia", "Chiclayo");
                    break;
                case 190:map.put("des_intendencia", "Cuzco");
                    break;
                case 118:map.put("des_intendencia", "Callao");
                    break;
                case 046:map.put("des_intendencia", "Paita");
                    break;
                case 127:map.put("des_intendencia", "Pisco");
                    break;
                case 280:map.put("des_intendencia", "Puerto Maldonado");
                    break;
                case 181:map.put("des_intendencia", "Puno");
                    break;
                case 82:map.put("des_intendencia", "Salaverry");
                    break;
                default:map.put("des_intendencia", "");

            }
            */

            json = new JsonSerializer();
            data =  new StringBuffer(json.serialize(map).toString());
            publicacionAvisoService.insert(new Integer(Constantes.AVISOS_CODIGO_SERVICIO_DILIGENCIA_DUA_ADUANA_DESTINO) , data, tipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());

        }
    }



    public ModelAndView procesarResultadoDiligencia(HttpServletRequest request, HttpServletResponse response)throws Exception{

        ModelAndView res = new ModelAndView(this.jsonView);
        MensajeBean rBean = new MensajeBean();

        try {
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
            /* PAS20181U220200069 - mtorralba 20190405 - Se comenta este bloque
			boolean tieneTpiLib=false;
            Map<String, Object> mapSerie;
            List<Map<String, Object>> lstConvenioSerie ;
            Map<String, Object> convenio;
            int contadorSerieTpiCodLibAct=0;
            int contadorSerieTpiCodLibAnt=0;
			*/
            if(lstDetDeclaraActual == null){

                HttpSession session = request.getSession();
                Map<String, String> params = new HashMap<String, String>();

                params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
                params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
                params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
                params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
                params.put("ann_presen", request.getParameter("hdn_ann_presen"));
                params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
                params.put("acceso", request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "");
                Map<String, Object> mapCabDeclara = (Map<String, Object>) session.getAttribute("mapCabDeclaraActual");
                request.setAttribute("params", params);
                // Para Declaracion en Proceso se filtran las Series
                params.put("estadoDUA", mapCabDeclara.get("COD_ESTDUA").toString());

                String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
                if ("10".equals(tipoDiligencia))
                {
                    if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
                            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
                    {
                        params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
                    }

                }

                List lstDetDeclara = serieService.obtenerListadoSeries(params);
                session.setAttribute("lstDetDeclara", lstDetDeclara);
                lstDetDeclaraActual = (List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual");
                if (CollectionUtils.isEmpty(lstDetDeclaraActual))
                {

                    List<Map<String, Object>> lstDetDeclaraActualTmp = new ArrayList<Map<String, Object>>();
                    lstDetDeclaraActualTmp = Utilidades.copiarLista(lstDetDeclara);
                    session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActualTmp);
                    lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
                    lstDetDeclaraAnt = new ArrayList<Map<String, Object>>();
                    lstDetDeclaraActual.addAll(lstDetDeclaraActualTmp);
                    lstDetDeclaraAnt.addAll(lstDetDeclaraActualTmp);

                }

            }

            if(lstDetDeclaraActual != null){
				/* PAS20181U220200069 - mtorralba 20190405 - Se comenta este bloque
                for (int i = 0; i < lstDetDeclaraActual.size(); i++) {
                    mapSerie = lstDetDeclaraActual.get(i);
                    lstConvenioSerie = (ArrayList) mapSerie.get("lstConvenioSerie");
                    tieneTpiLib=false;

                    for (int j=0; lstConvenioSerie!=null &&  j<lstConvenioSerie.size();j++){
                        convenio=lstConvenioSerie.get(j);
                        if  ((ConstantesDataCatalogo.COD_TIP_34.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_35.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_36.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_4438.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "C".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) )){

                            tieneTpiLib=true;
                            break;
                        }
                    }

                    if (tieneTpiLib){
                        contadorSerieTpiCodLibAct++;
                    }
                }


                for (int i = 0; i < lstDetDeclaraAnt.size(); i++) {
                    mapSerie = lstDetDeclaraAnt.get(i);
                    lstConvenioSerie = (ArrayList) mapSerie.get("lstConvenioSerie");
                    tieneTpiLib=false;

                    for (int j=0; lstConvenioSerie!=null &&  j<lstConvenioSerie.size();j++){
                        convenio=lstConvenioSerie.get(j);
                        if  ( (ConstantesDataCatalogo.COD_TIP_34.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_35.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_36.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "I".equals(convenio.get("COD_TIPCONVENIO")) ) ||
                                (ConstantesDataCatalogo.COD_TIP_4438.equals(convenio.get("COD_CONVENIO").toString().trim()) &&  "C".equals(convenio.get("COD_TIPCONVENIO")) )
                        ) {

                            tieneTpiLib=true;

                            break;
                        }
                    }

                    if (tieneTpiLib){
                        contadorSerieTpiCodLibAnt++;
                    }

                }


                if (contadorSerieTpiCodLibAct==0){
                    res.addObject("resultadoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO);
                    WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Mercancia no llego a Destino");
                    WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO);
                }else{

                    if (lstDetDeclaraActual.size()!= lstDetDeclaraAnt.size()|| (contadorSerieTpiCodLibAct!=contadorSerieTpiCodLibAnt)){
                        res.addObject("resultadoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO);
                        WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Mercanc�a lleg� parcialmente a destino");
                        WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO);
                    }else{
                        res.addObject("resultadoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO);
                        WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Conforme");
                        WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia",ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO);
                    }
                }
				*/

                String resultadoMercancia = obtenerResultadoDiligenciaDestino(lstDetDeclaraActual,lstDetDeclaraAnt);
                res.addObject("resultadoMercancia", resultadoMercancia);
                WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia", resultadoMercancia);
                if( resultadoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO))
                    WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Mercancia no llego a Destino");
                else if( resultadoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO))
                	WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Mercanc�a lleg� parcialmente a destino");
                else if( resultadoMercancia.equals(ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO))
                	WebUtils.setSessionAttribute(request, "resultadoAduanaDestinoMercancia","Conforme");

            }else{
                res.addObject("resultadoMercancia", "");
                WebUtils.setSessionAttribute(request, "estadoResultadoAduanaDestinoMercancia","");
            }

        }catch (Exception e){
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Error al efectuar la validacion de Peco Amazonia en la serie actual");
            log.error("*** ERROR ***", e);
            res.addObject("beanM", rBean);
        }

        return res;

    }

    //rin08

    //P24-PAS20165E220200099
    private boolean duaTieneIndicadorDUAValorProvActivo(Map<String,Object> declaracion){
        DatoIndicadores indicadorDUA = new DatoIndicadores();
        //(RIN10 mpoblete BUG 21916)indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(declaracion.get("NUM_CORREDOC").toString(), pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
        indicadorDUA =  obtenerIndicadorDUAVP(declaracion.get("NUM_CORREDOC").toString());
        //Inicio RIN10 mpoblete BUG 21738
        //return (indicadorDUA!=null && "1".equals(indicadorDUA.getIndicadorActivo()));
        return (indicadorDUA!=null);
        //Fin RIN10 mpoblete BUG 21738
    }
    private DatoIndicadores obtenerIndicadorDUAVP(String numCorredoc){
        DatoIndicadores indicadorDUA = new DatoIndicadores();
        indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(numCorredoc, pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP);
        return indicadorDUA;
    }
    private void  verificarValorProvisional(Map<String, Object> params,Map<String, Object> declaracion) {
        DataCatalogo dataCatalogo = RectificacionServiceImpl.getInstance().getDataCatalogoDAO().buscarDataCatalogo(COD_CATALOGO_PORCENTAJE_BIVP, COD_DATACAT_VALOR_PORCENTAJE_BIVP);
        String numero = dataCatalogo.getDesCorta();
        if(StringUtils.isEmpty(numero)){
            numero="0";
        }
        BigDecimal porcentajeBaseImponible = new BigDecimal(numero);
        BigDecimal datoDefault = new BigDecimal("0");
        int evaluacion = porcentajeBaseImponible.compareTo(datoDefault);
        Map<String,Object> paramPadUsuGar = new HashMap<String, Object>();
        paramPadUsuGar.put("NUMRUC", declaracion.get("COD_RUCLUGRECEP").toString());
        paramPadUsuGar.put("IND_USUACTIVO", "1");
        paramPadUsuGar.put("IND_LCVP", "1");
        //declaracion.put("ANN_PRESEN", declaracion.get("ANN_PRESEN").toString().substring(2));
        boolean tieneRucImportador = validarRucImportadorTieneLC(paramPadUsuGar);
        if(evaluacion==1 && tieneRucImportador){
            if(verificarDeclaracionConLCGenerada(declaracion)){
                //Inicio RIN10 mpoblete BUG 22018
                boolean liquidacionEstaGarantizada = liquidacionCobranzaGarantizada(declaracion);
                boolean duaTieneGarantia160 = declaracionGarantia160(declaracion);
                if(duaTieneGarantia160 && liquidacionEstaGarantizada){verificarDeclaracionAfectadaCtaCte(declaracion);}
                //Fin RIN10 mpoblete BUG 22018
            }
        }
    }

    private boolean  validarRucImportadorTieneLC(Map<String,Object> params){
        return  padronUsuarioService.findByNumRucExiste(params);

    }

    private boolean verificarDeclaracionConLCGenerada(Map<String, Object> declaracion){
        Map<String,Object> declaracionLocal = declaracion;

        boolean tieneLCVPGenerado = liquidaDeclaracionService.verificarDeclaracionConLCGenerada(declaracionLocal);

        if(!tieneLCVPGenerado){
            lisdatoMsj = lisdatoMsj+" *DUA NO CUENTA CON LC(VP) SIRVASE GENERARLA <BR>";
            return false;
        }

        return true;
    }

    private boolean liquidacionCobranzaGarantizada(Map<String, Object> declaracion) {

        /** Inicio mpoblete RIN10 **/
        Map<String,Object> declaracionLocal = declaracion;
        declaracionLocal.put("tipoLiquidacion", Constantes.COD_TIPLIQ);
        /** Fin mpoblete RIN10 **/
        //Inicio RIN10 mpoblete BUG 21917
        //boolean result = liquidaDeclaracionService.verificarDeclaracionConLCGeneradaGarantizada(declaracionLocal);
        boolean result = liquidaDeclaracionService.tieneDeclaracionLCVPGarantizadaImpugnada(declaracionLocal);


        //boolean duaConGarantia160 = declaracionGarantia160(declaracionLocal);
        //result = (result && duaConGarantia160);
        //Fin RIN10 mpoblete BUG 21917

        if(!result)
            lisdatoMsj = lisdatoMsj+" *LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA, NOTIFICAR AL IMPORTADOR  <BR>";
        return result;
    }

    private boolean declaracionGarantia160(Map<String, Object> declaracion) {
        //Inicio RIN10 mpoblete BUG 22163
        String numCtaCte = (String) declaracion.get("NUM_CTACTE");
        numCtaCte = numCtaCte.trim();
        boolean tieneGarantia160 = (!StringUtils.isEmpty(numCtaCte));
        //if(declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE")){
        if(tieneGarantia160){
            //Fin RIN10 mpoblete BUG 22163
            return true;
        }
        return false;
    }

    private void verificarDeclaracionAfectadaCtaCte(Map<String, Object> declaracion) {
        //Inicio RIN10 mpoblete BUG 22125
        //boolean estado = liquidaDeclaracionService.verificarDeclaracionAfectadaCtaCte(declaracion);
        boolean estado = liquidaDeclaracionService.ctaCteGaraAfectadaPorLiquidaVP(declaracion);
        //Fin RIN10 mpoblete BUG 22125
        if(!estado){
            lisdatoMsj = lisdatoMsj+ " LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO HA AFECTADO LA CTA CTE DE LA GARANTIA <BR>";
        }
    }

   
    //PAS20181U220200069 - mtorralba 20190405 - INICIO 
    private Map<String,Boolean> obtenerCambiosTPICodLib(List<Map<String, Object>> lstConvenioSerieActual, List<Map<String, Object>> lstConvenioSerieAnt) {
    	Map<String,Boolean> mapaResult = new HashMap<String,Boolean>();
    	String TPIActual = "";
    	String CodLibeActual = "";
    	String TPIAnt = "";
    	String CodLibeAnt = "";
        
    	for (Map<String,Object> convenio :  lstConvenioSerieActual){
            if( "I".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) 
            	TPIActual = convenio.get("COD_CONVENIO").toString().trim();
            if( "C".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) 
            	CodLibeActual = convenio.get("COD_CONVENIO").toString().trim();
        }

    	for (Map<String,Object> convenio :  lstConvenioSerieAnt){
            if( "I".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) 
            	TPIAnt = convenio.get("COD_CONVENIO").toString().trim();
            if( "C".equals(convenio.get("COD_TIPCONVENIO")) &&  !"1".equals(convenio.get("IND_DEL")) ) 
            	CodLibeAnt = convenio.get("COD_CONVENIO").toString().trim();
        }

    	mapaResult.put("existenCambios", (!TPIActual.equals(TPIAnt) || !CodLibeActual.equals(CodLibeAnt)) );
    	mapaResult.put("TPIActual", TPIActual.equals("") ? false : true );
    	mapaResult.put("TPIAnt", TPIAnt.equals("") ? false : true );
    	mapaResult.put("CodLibActual", CodLibeActual.equals("") ? false : true );
    	mapaResult.put("CodLibAnt", CodLibeAnt.equals("") ? false : true );
    	return mapaResult;
    }
    
    
    private String obtenerResultadoDiligenciaDestino(List<Map<String, Object>> lstDetDeclaraActual, List<Map<String, Object>> lstDetDeclaraAnt) {
	    //Resultados:  01-Mercancia no llego   02- Conforme  03 Llego parcialmente
    	String resultado = "00";
	    Map<String, Object> mapSerieActual;
	    Map<String, Object> mapSerieAnt;
	    List<Map<String, Object>> lstConvenioSerieActual ;
	    List<Map<String, Object>> lstConvenioSerieAnt = new ArrayList<Map<String,Object>>();
        int contadorTPIActual = 0;
        int contadorTPIAnt = 0;
        int contadorCodLibActual = 0;
        int contadorCodLibAnt = 0;
        boolean existenCambios = false;

	    for (int i = 0; i < lstDetDeclaraActual.size(); i++) {
	    	mapSerieActual = lstDetDeclaraActual.get(i);
	    	lstConvenioSerieActual = (ArrayList) mapSerieActual.get("lstConvenioSerie");
	    	
            for (int j = 0; j < lstDetDeclaraAnt.size(); j++) {
    	    	mapSerieAnt = lstDetDeclaraAnt.get(j);
    	    	
    	    	if( mapSerieAnt.get("NUM_SECSERIE").toString().equals(mapSerieActual.get("NUM_SECSERIE").toString())) {
    	    		lstConvenioSerieAnt = (ArrayList) mapSerieAnt.get("lstConvenioSerie");
    	    		break;
    	    	}
            }
            
            Map<String,Boolean> cambiosTPICodLib = obtenerCambiosTPICodLib(lstConvenioSerieActual, lstConvenioSerieAnt);
            
            contadorTPIActual    = contadorTPIActual + (cambiosTPICodLib.get("TPIActual") ? 1 : 0);  
            contadorTPIAnt       = contadorTPIAnt + (cambiosTPICodLib.get("TPIAnt") ? 1 : 0);
            contadorCodLibActual = contadorCodLibActual + (cambiosTPICodLib.get("CodLibActual") ? 1 : 0);
            contadorCodLibAnt    = contadorCodLibAnt + (cambiosTPICodLib.get("CodLibAnt") ? 1 : 0);
            if( cambiosTPICodLib.get("existenCambios") )  existenCambios = true;
            
	    } //Final FOR


	    if( !existenCambios ) {
	    	resultado = ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_CONFORME_DESTINO;
	    }
	    else {
	    	if( contadorTPIActual==0 && contadorCodLibActual==0 )
	    		resultado = ConstantesDataCatalogo.COD_DATACATALOGO_NO_LLEGO_DESTINO;
	    	else
	    		resultado = ConstantesDataCatalogo.COD_DATACATALOGO_LLEGO_PARCIAL_DESTINO;
	    }
        return resultado;
    
    } //Final funcion
    //PAS20181U220200069 - mtorralba 20190405 - FIN
    
    
    /*********************** SET DE SPRING **********************************/

    /**
     * Sets the declaracion service.
     *
     * @param declaracionService
     *          the new declaracion service
     */
    public void setDeclaracionService(DeclaracionService declaracionService)
    {
        this.declaracionService = declaracionService;
    }

    /**
     * Sets the solicitud service.
     *
     * @param solicitudService
     *          the new solicitud service
     */
    public void setSolicitudService(SolicitudService solicitudService)
    {
        this.solicitudService = solicitudService;
    }

    /**
     * Sets the soporte service.
     *
     * @param soporteService
     *          the new soporte service
     */
    public void setSoporteService(SoporteService soporteService)
    {
        this.soporteService = soporteService;
    }


    /**
     * Sets the formato valor service.
     *
     * @param formatoValorService
     *          the new formato valor service
     */
    public void setFormatoValorService(FormatoValorService formatoValorService)
    {
        this.formatoValorService = formatoValorService;
    }

    /**
     * Sets the liquida declaracion service.
     *
     * @param liquidaDeclaracionService
     *          the new liquida declaracion service
     */
    public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
    {
        this.liquidaDeclaracionService = liquidaDeclaracionService;
    }

    /**
     * Sets the incidencia service.
     *
     * @param incidenciaService
     *          the new incidencia service
     */
    public void setIncidenciaService(IncidenciaService incidenciaService)
    {
        this.incidenciaService = incidenciaService;
    }

    /**
     * Sets the valida diligencia service.
     *
     * @param validaDiligenciaService
     *          the new valida diligencia service
     */
    public void setValidaDiligenciaService(ValidaDiligenciaService validaDiligenciaService)
    {
        this.validaDiligenciaService = validaDiligenciaService;
    }


    /**
     * Sets the fabrica de servicios.
     *
     * @param fabricaDeServicios
     *          the new fabrica de servicios
     */
    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
    {
        this.fabricaDeServicios = fabricaDeServicios;
    }

    /**
     * Sets the solicitud rectificaciones service.
     *
     * @param solicitudRectificacionesService
     *          the new solicitud rectificaciones service
     */
    public void setSolicitudRectificacionesService(SolicitudRectificacionesService solicitudRectificacionesService)
    {
        this.solicitudRectificacionesService = solicitudRectificacionesService;
    }


    /**
     * Gets the valida contingente service.
     *
     * @return the valida contingente service
     */
    public ValidaContingentesService getValidaContingenteService()
    {
        return validaContingenteService;
    }

    /**
     * Sets the valida contingente service.
     *
     * @param validaContingenteService
     *          the new valida contingente service
     */
    public void setValidaContingenteService(
            ValidaContingentesService validaContingenteService)
    {
        this.validaContingenteService = validaContingenteService;
    }

    /**
     * Sets the rectificacion service.
     *
     * @param rectificacionService
     *          the new rectificacion service
     */
    public void setRectificacionService(RectificacionService rectificacionService)
    {
        this.rectificacionService = rectificacionService;
    }

    // inicio EJHM
    public void setJasperService(JasperService jasperService) {
        this.jasperService = jasperService;
    }

    public void setRecepcionDocumentosService(
            RecepcionDocumentosService recepcionDocumentosService) {
        this.recepcionDocumentosService = recepcionDocumentosService;
    }

    // fin EJHM
    /**
     * Sets the transform helper.
     *
     * @param transformHelper
     *          the new transform helper
     */
    public void setTransformHelper(
            GetDeclaracionHashMapToDeclaracionObjectHelper transformHelper)
    {
        this.transformHelper = transformHelper;
    }

    /**
     *
     * @param orquestadorService
     */
    public void setOrquestadorService(OrquestadorDiligenciaService orquestadorService)
    {
        this.orquestadorService = orquestadorService;
    }

    /**
     *
     * @param declaracionCalculoDeDatos
     */
    public void setDeclaracionCalculoDeDatos(DeclaracionCalculoDeDatosService declaracionCalculoDeDatos)
    {
        this.declaracionCalculoDeDatos = declaracionCalculoDeDatos;
    }

    /**
     *
     * @param serieService
     */
    public void setSerieService(SerieService serieService)
    {
        this.serieService = serieService;
    }

    /* olunar 873 */
    public void setGetDeclaracionService(GetDeclaracionService getDeclaracionService) {
        this.getDeclaracionService = getDeclaracionService;
    }
    /* fin */


    public void setFuncionesService(ProveedorFuncionesService funcionesService) {
        this.funcionesService = funcionesService;
    }

    public void setVehiCeticoService(VehiCeticoService vehiCeticoService) {
        this.vehiCeticoService = vehiCeticoService;
    }


    public void setAsignacionManualService(AsignacionManualService asignacionManualService) {
        this.asignacionManualService = asignacionManualService;
    }


    public void setDiligenciaService(DiligenciaService diligenciaService) {
        this.diligenciaService = diligenciaService;
    }

    public void setPublicacionAvisoService(
            PublicacionAvisoService publicacionAvisoService) {
        this.publicacionAvisoService = publicacionAvisoService;
    }
    //pase 69
	/*public void setResolucionService(ResolucionService resolucionService) {
		this.resolucionService = resolucionService;
	}

	public ResolucionService getResolucionService() {
		return resolucionService;
	}*/
    private String getTrimParam(HttpServletRequest request, String name) {
        // creado como wrapper para legibilidad del controller
        // recoge un atributo del request aplicando un trim
        return StringUtils.trimToEmpty(request.getParameter(name));
    }

}