package pe.gob.sunat.despaduanero2.multa.web.controller;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean; //PAS20155E220000054
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ParserUtil;
import pe.gob.sunat.despaduanero2.multa.service.MultaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


/**
 * The Class MultaController. Clase controller que permite mostrar la pantalla
 * de multas relacionadas a una
 *
 * @author Ruddy Cuellar Mayorga
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class MultaController extends MultiActionController
{

  protected final Log          log                  = LogFactory.getLog(getClass());

  private MultaService         multaService;

  private OperadorAyudaService operadorAyudaService;

  private SoporteService soporteService;

  private String               jsonView;
  private DeudaService deudaService; /*jlunah*/
  private CatalogoAyudaService catalogoAyudaService;/*jlunah*/
  private LiquidaDeclaracionService liquidaDeclaracionService; /*jlunah*/

  /**
   * Inicio prueba multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView inicioPruebaMultas(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return new ModelAndView("inicioPruebaMultas");
  }

  /**
   * Metodo que permite mostrar el listado de las multas agrupadas por
   * infractor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cargarListadoMultas(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    List<Map<String, Object>> listadoMultas = null;
    if (request.getSession().getAttribute("listadoMultas") == null)
    {
      try
      {
        Map<String, Object> paramsBusquedaMultas = new HashMap<String, Object>();

        Map declaracionMap = (Map) request.getSession().getAttribute("mapCabDeclaraActual");
        Date fechaDeclaracion = (Date) declaracionMap.get("FEC_DECLARACION");
        paramsBusquedaMultas.put("FEC_DECLARACION", fechaDeclaracion);
        paramsBusquedaMultas.put("caduana", soporteService.obtenerAduana(request));

        listadoMultas = multaService.obtenerCatMultas(paramsBusquedaMultas);

      }
      catch (ServiceException e)
      {
        log.error("*** ERROR ***", e);
        return new ModelAndView("PagE", "message", e.getMessage());
      }
      catch (Exception e)
      {
        log.error("*** ERROR ***", e);

        return new ModelAndView("PagM", "message", e.getMessage());
      }

      request.getSession().setAttribute("listadoMultas", listadoMultas);
    }
    else
    {
      listadoMultas = (List<Map<String, Object>>) request.getSession().getAttribute("listadoMultas");
    }
    String array = SojoUtil.toJson(listadoMultas);
    ModelAndView mv = new ModelAndView("ListadoMulta");
    mv.addObject("multas", array);

    return mv;
  }


  /**
   * Metodo que permite agregar en session los datos de una multa.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
   // RIN13
  public ModelAndView agregarMulta(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  
	  HashMap<String,Object> jsonObject = new HashMap<String, Object>();
	  ServletWebRequest webRequest = new ServletWebRequest(request);
    try {
    	Map declaracionActualMap = (HashMap) request.getSession().getAttribute("mapCabDeclaraActual");        
        
    	String infractor = webRequest.getParameter("tempComboInfractor");
    	String infraccion = webRequest.getParameter("tempComboInfraccion");
    	
    	String codInfractor = webRequest.getParameter("codInfractor");
    	String codInfraccion = webRequest.getParameter("codMulta");    	
    	String numCorredoc = webRequest.getParameter("numCorredoc");
    	
    	Map<String,Object> parametros = new HashMap<String, Object>();
    	parametros.put("codInfractor", codInfractor);
    	parametros.put("codInfraccion", codInfraccion);    	
    	parametros.put("numCorredoc", numCorredoc);
    	boolean flag = multaService.tieneInfraccionEnOtraDiligencia(parametros);
    	
    	if(flag){
    		throw new ServiceException(this, "Ya se ha aplicado la infracci\u00f3n ["+infraccion+"] al infractor ["+infractor+"] durante la diligencia de rectificaci\u00f3n.");
    	}    	
    	
    	jsonObject.put("success", true);
    } catch (ServiceException ex){
    	jsonObject.put("mensajeError", ex.getMessage());
		jsonObject.put("success", true);
    } catch (Exception e){
    	jsonObject.put("mensajeError", e.getMessage());
		jsonObject.put("success", true);
    }
    
    return new ModelAndView(jsonView, jsonObject);
  }

  /**
   * Metodo que permite eliminar de session los datos de una multa.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView eliminarMulta(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      List<Map<String, Object>> listaMultasSeleccionadas = (ArrayList) WebUtils.getSessionAttribute(
          request,
            "lstMultaDuaActual");


      String id = webRequest.getParameter("hdn_id");
      int indice = -1;
      boolean booEncontrado = false;
      if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
      {
        for (Map<String, Object> multa : listaMultasSeleccionadas)
        {
          indice += 1;
          if (multa.get(id) != null)
          {
            booEncontrado = true;
            break;
          }
        }

        if (booEncontrado)
        {
          listaMultasSeleccionadas.remove(indice);
          request.getSession().setAttribute("lstMultaDuaActual", listaMultasSeleccionadas);
        }
      }

      res.addObject("recOk", true);
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      res.addObject("beanM", rBean);
    }
    return res;
  }

  /**
   * Metodo que almacena en session los datos de las multas de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView guardarMultaSesion(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    if ((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual") != null)
      lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual"));
    WebUtils.setSessionAttribute(request, "lstMultaDua", lstEditada);
    res.addObject("ok", "ok");
    return res;
  }

  /**
   * Metodo que elimina de session los datos editados de las multas de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cancelarEdicion(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDua"));
    WebUtils.setSessionAttribute(request, "lstMultaDuaActual", lstEditada);
    res.addObject("ok", "ok");
    return res;
  }

  /**
   * Metodo que obtiene la cantidad de registros multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cantidadRegistroMulta(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    if ((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual") != null)
      lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual"));
    res.addObject("lstMultaDua", lstEditada.size());
    return res;
  }


  /**
   * Metodo que permite guardar en session los datos ingresados en la pantalla
   * de multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView guardar(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      Map parameterMap = webRequest.getParameterMap();

      Object[] ctrNames = parameterMap.keySet().toArray();

      List<Map<String, Object>> listaMultasSeleccionadas = (WebUtils.getSessionAttribute(request, "lstMultaDua") != null) ? (ArrayList) WebUtils
          .getSessionAttribute(request, "lstMultaDua")
          : new ArrayList<Map<String, Object>>();

      // Limpiamos los elementos de los infractores cargados
      List listadoMultas = (ArrayList) WebUtils.getSessionAttribute(request, "listadoMultas");
      String[] infractores = webRequest.getParameter("hdn_tabs_cargados").split(Constantes.SEPARADOR1);
      Map multaDat;
      Set multaKey;
      List<String> lstRemove;
      int itm;

      for (String infr : infractores)
      {
        if (listaMultasSeleccionadas.size() > 0)
        {
          multaDat = (HashMap) listadoMultas.get(Integer.parseInt(infr));
          itm = 0;
          lstRemove = new ArrayList<String>();
          for (Map<String, Object> multa : listaMultasSeleccionadas)
          {
            multaKey = multa.keySet();
            for (Object key : multaKey)
            {
              if (key.toString().startsWith("cbxSeleccion" + (multaDat.get("COD_INFRACTOR").toString())))
              {
                lstRemove.add("" + itm);
              }
            }
            itm += 1;
          }

          if (lstRemove.size() > 0)
          {
            for (int i = lstRemove.size() - 1; i >= 0; i--)
            {
              listaMultasSeleccionadas.remove(Integer.parseInt(lstRemove.get(i)));
            }
          }
        }
      }

      // Cargamos los elementos pintados en pantalla
      if (parameterMap != null && parameterMap.size() > 0)
      {
        String clave;
        for (int contValues = 0; contValues < parameterMap.size(); contValues++)
        {
          // Obtenemos los checkbox de las multas seleccionadas
          clave = ctrNames[contValues].toString();
          if (clave.startsWith("cbxSeleccion"))
          {
            Map<String, Object> multa = new TreeMap<String, Object>();
            multa.put(clave, clave.substring("cbxSeleccion".length(), clave.length()));
            listaMultasSeleccionadas.add(multa);
          }
        }

        // Asignamos los datos correspondientes a las multas (visibles)
        // seleccionadas
        String grupoMulta;
        for (Map<String, Object> multa : listaMultasSeleccionadas)
        {
          grupoMulta = (String) ((TreeMap<String, Object>) multa).firstEntry().getValue();
          if (webRequest.getParameter("selPctRebaja" + grupoMulta + "_aux") != null)
          {
            multa.put("selPctRebaja" + grupoMulta, webRequest.getParameter("selPctRebaja" + grupoMulta + "_aux"));
            multa.put("txtMonto" + grupoMulta, webRequest.getParameter("txtMonto" + grupoMulta));
            multa.put("txtMontoPag" + grupoMulta, webRequest.getParameter("txtMontoPag" + grupoMulta + "_aux"));
            multa.put("txtTipoMulta" + grupoMulta, webRequest.getParameter("txtTipoMulta" + grupoMulta));
            multa.put("txtMoneda" + grupoMulta, webRequest.getParameter("txtMoneda" + grupoMulta));
            multa.put("txtCodMulta" + grupoMulta, webRequest.getParameter("txtCodMulta" + grupoMulta));
            multa.put("txtNaturaleza" + grupoMulta, webRequest.getParameter("txtNaturaleza" + grupoMulta));
          }
        }
      }
      request.getSession().setAttribute("lstMultaDua", listaMultasSeleccionadas);
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }

    return null;
  }

  /**
   * Metodo temporal que llama al servicio de grabacion de multas. Luego la
   * llamada a este m�todo se hara desde el DiligenciaServiceImpl
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView grabarDatos(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    List<Map<String, Object>> listaMultasSeleccionadas = (List<Map<String, Object>>) request.getSession().getAttribute(
        "lstMultaDua");
    try
    {

      Map declaracionActualMap = (HashMap) request.getSession().getAttribute("mapCabDeclaraActual");
      Map declaracionMap = (HashMap) request.getSession().getAttribute("mapCabDeclara");
      String codDocumento = (String) declaracionActualMap.get("num_corredoc");
      String codTipoDiligencia = (String) declaracionMap.get("cod_canal");
      Date fechaDeclaracion = (Date) declaracionActualMap.get("FEC_DECLARACION");
      String tipoDocImp = (String) declaracionActualMap.get("COD_TIPDOC_PIM");
      String rucImp = (String) declaracionActualMap.get("NUM_DOCIDENT_PIM");
      String rucAgente = (String) declaracionActualMap.get("NUM_DOCIDENT_PDE");
      Map operador = (HashMap) operadorAyudaService.getOperadorPorCodAduanero(rucAgente, "41");
      String codAgente = (String) operador.get("COD_ANTADU");
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      Map paramMulta = new HashMap();
      paramMulta.put("COD_DOCUMENTO", codDocumento);
      paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
      paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
      paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
      paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
      paramMulta.put("NUM_REG_USUARIO", bUsuario.getNroRegistro());
      paramMulta.put("COD_ANTADU", codAgente);
      multaService.generarMulta(paramMulta, listaMultasSeleccionadas);

    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }

    return null;
  }
  /**
   * @author jlunah
   * */
  public ModelAndView cargarDatosParaRegistroMulta(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  ModelAndView view = new ModelAndView("RegistroMultas");
	  List <HashMap<String, Object>> listaDifTributosSerie = new ArrayList<HashMap<String,Object>>();
	  List lstAutoliquidaciones = new ArrayList();
	  List lstAutoliquidacionesTemp = new ArrayList();
	  List<Map<String, String>> listaCatalogoInfractor = new ArrayList<Map<String,String>>();
	  List<Map<String, String>> listaPorcentajeIncentivo = new ArrayList<Map<String,String>>();
	  
	  try {
		  //this.liquidarDeclaracion(request);		  
		  Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
		  
		  ServletWebRequest webRequest = new ServletWebRequest(request);
		  String numCorredoc = webRequest.getParameter("hdn_num_corredoc");
		  
		  //Diferencia de tributos por serie		  
		  // 1. Verificar si exite DIFERENCIA DE TRIBUTOS (TRUE o FALSE)
		  // 2. SI (TRUE) CALCULAR LA DIFERENCIA DE TRIBUTOS 
		  // 3. ENVIAR AL JSP (TRUE O FALSE segun el caso y Tambien enviar la lista)
		  
		  //List<Map<String,Object>> listadoDifTribTotalSeries = deudaService.obtenerListaDiferenciaTributosTodasLasSeries(numCorredoc); 
		  //listaDifTributosSerie = this.darFormatolistaDiferenciaTributos(listadoDifTribTotalSeries);
		  
		  		  
		  //String tieneIncidenciaTributaria = declaracionActual.get("tieneIncTrib").toString();		   
		  
		  //if(tieneIncidenciaTributaria.equalsIgnoreCase("S")){// Existe Incidencia Tributaria
			  
			  MovCabliqdilig params = new MovCabliqdilig();
			  
			  // params = declaracionActual
			  
			  List <HashMap<String, Object>> listaAuxiliar = liquidaDeclaracionService.obtenerDetalleTributoSerieCalculadoS(declaracionActual); 
			  listaDifTributosSerie = darFormatolistaDiferenciaTributos(listaAuxiliar);
			  log.debug("longitud - listaDifTributosSerie: "+listaDifTributosSerie.size());
		  //}
		  
//		  log.debug("getCodTipdiligencia: "+movCabliqdilig.getCodTipdiligencia());
//		  log.debug("tieneIncidenciaTributaria: "+tieneIncidenciaTributaria);
		  
		  //Se busca el cat�logo de infractores en la tabla datacatalogo donde cod_catalogo = '359' 
		  listaCatalogoInfractor = catalogoAyudaService.getElementosCat("359");
		  
		  // Se obtiene desde el catalogo, los Porcentajes de incentivos
		  listaPorcentajeIncentivo = catalogoAyudaService.getElementosCat("928");
		  
		  //Busca las autoliquidaciones tipo 027 canceladas no utilizadas para cruces en procesos anteriores a la diligencia de despacho
		  Map mapCabDeclaraActual = new HashMap();
		  mapCabDeclaraActual.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
		  mapCabDeclaraActual.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
		  mapCabDeclaraActual.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
		  mapCabDeclaraActual.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
		  mapCabDeclaraActual.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
		  //Pase 399
		  FechaBean fecha = new FechaBean((Timestamp)declaracionActual.get("FEC_DECLARACION"));
		  mapCabDeclaraActual.put("FECHA_DECLARACION", fecha.getFormatDate("dd/MM/yyyy"));
		  
		  		  
		  lstAutoliquidacionesTemp  =  liquidaDeclaracionService.obtenerAutoliquidaciones(mapCabDeclaraActual, "AUTOLIQ", "0027", " "); 
		  lstAutoliquidaciones  =  liquidaDeclaracionService.usarAutoliqNoUtilizadasEnOtroProceso(lstAutoliquidacionesTemp, numCorredoc);
		  
		  
		  view.addObject("listaDiferenciaTributos", SojoUtil.toJson(listaDifTributosSerie));
		  view.addObject("listaInfractores", this.darFormatoParaFilteringSelect(listaCatalogoInfractor));
		  
		  view.addObject("listaPorcentajeIncentivo", this.darFormatoParaFilteringSelectIncentivoPorcentaje(this.ordenarIncentivoPorcentaje(listaPorcentajeIncentivo)));
		  mapCabDeclaraActual.put("incidenciaTributaria", true);//tieneIncidenciaTributaria);
		  view.addObject("parametrosMapa", mapCabDeclaraActual);
		  view.addObject("listaAutoliquidacionesCanceladas", SojoUtil.toJson(this.darFormatoParaGrillaAutoliquidaciones(lstAutoliquidaciones)));
		  
	  }catch (ServiceException e){
	        log.error("*** ERROR ***", e);
	        return new ModelAndView("PagE", "message", e.getMessage());
	  } catch (Exception e){
	        log.error("*** ERROR ***", e);
	        return new ModelAndView("PagM", "message", e.getMessage());
	  }
	finally{
		 
	}
	return view;
  }
  
  public List<HashMap<String, Object>> darFormatolistaDiferenciaTributos(List<HashMap<String,Object>> listadoDifTribTotalSeries){	  
	  BigDecimal totalSoles = new BigDecimal(0);
	  BigDecimal totalDolares = new BigDecimal(0);
	  for (Map<String, Object> aux : listadoDifTribTotalSeries) {
		  totalSoles   = SunatNumberUtils.sum(totalSoles, 	(BigDecimal) aux.get("montoSoles"));
		  totalDolares = SunatNumberUtils.sum(totalDolares, (BigDecimal) aux.get("montoDolares"));
	  }
	  
	  Double soles = Double.valueOf(totalSoles.doubleValue());	  
	  Double dolares = Double.valueOf(totalDolares.doubleValue());	  
	  
	  HashMap<String, Object> mapDifTributos2 = new HashMap<String, Object>();
	  mapDifTributos2.put("serie", "Totales");
	  mapDifTributos2.put("montoSoles", ParserUtil.formatoDineroTresDecimales(soles.doubleValue()));
	  mapDifTributos2.put("montoDolares", ParserUtil.formatoDineroTresDecimales(dolares.doubleValue()));
	  listadoDifTribTotalSeries.add(mapDifTributos2);
	  return listadoDifTribTotalSeries;
  }
  
  public ModelAndView cargarJSP(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  ModelAndView vista = new ModelAndView("RegistroMultas");
	  try {
		  HashMap<String, String> parametros = new HashMap<String, String>();
		  
		  // Parte 1: Direfencia de Tributos
		  List<HashMap<String, Object>> listaDiferenciaTributos = new ArrayList<HashMap<String,Object>>();
		  for(int i = 0; i<3; i++){
			  HashMap<String, Object> mapDifTributos = new HashMap<String, Object>();
			  mapDifTributos.put("serie", i+1);
			  mapDifTributos.put("montoSoles", new BigDecimal(325.215));
			  mapDifTributos.put("montoDolares", new BigDecimal(263.7819));
			  listaDiferenciaTributos.add(mapDifTributos);
		  } 

		  BigDecimal totalSoles = new BigDecimal(0);
		  BigDecimal totalDolares = new BigDecimal(0);
		  for (HashMap<String, Object> aux : listaDiferenciaTributos) {
			  totalSoles   = SunatNumberUtils.sum(totalSoles, 	(BigDecimal) aux.get("montoSoles"));
			  totalDolares = SunatNumberUtils.sum(totalDolares, (BigDecimal) aux.get("montoDolares"));
		  }
		  
		  Double soles = Double.valueOf(totalSoles.doubleValue());	  
		  Double dolares = Double.valueOf(totalDolares.doubleValue());	  
		  
		  HashMap<String, Object> mapDifTributos2 = new HashMap<String, Object>();
		  mapDifTributos2.put("serie", "Totales");
		  mapDifTributos2.put("montoSoles", ParserUtil.formatoDineroTresDecimales(soles.doubleValue()));
		  mapDifTributos2.put("montoDolares", ParserUtil.formatoDineroTresDecimales(dolares.doubleValue()));
		  listaDiferenciaTributos.add(mapDifTributos2);
		  
		  //Parte 2: Registro de Multas
		  // Metodo: obtenerListadoInfractores()
		  List<Map<String, String>> listaCatalogoInfractor  = new ArrayList<Map<String,String>>();
		  //List<Map<String, String>> listaInfractores = new ArrayList<Map<String,String>>();
		  listaCatalogoInfractor  = catalogoAyudaService.getElementosCat("359");
		  //Collections.sort(listaCatalogoInfractor);
		  //listaInfractores = this.darFormatoFilteringSelect(listaCatalogoInfractor);
		  
		  // key:cod_datacat
		  // value: des_corta
		  parametros.put("dato", 12345679 + " Hola");
		  parametros.put("aduana", "18_");
		  parametros.put("annioAduana", "2014_");
		  parametros.put("numeroRegimen", "10_");
		  parametros.put("numeroDeclaracion", "100_");
		  vista.addObject("parametros" ,parametros);
		  vista.addObject("listaInfractores", this.darFormatoParaFilteringSelect(listaCatalogoInfractor));
		  vista.addObject("listaDiferenciaTributos", SojoUtil.toJson(listaDiferenciaTributos));
		  
	  } catch (ServiceException ex) {
		  //jsonObject.put("mensajeError", ex.getMessage());
		  //jsonObject.put("success", false);
	  } catch (Exception e) {
		  //jsonObject.put("mensajeError", e.getMessage());
		  //jsonObject.put("success", false);		
	  } finally {
		  log.debug("");
	  }
	  return vista;
  }
  
  /**
   * RIN13 SWF
   * */
  public ModelAndView cargarListadoInfraccionPorInfractor(HttpServletRequest request, HttpServletResponse response) throws ServiceException{	  
	  HashMap<String,Object> jsonObject = new HashMap<String, Object>() ;
	  
	  String codigoInfractor;
	  try {
		  codigoInfractor = request.getParameter("codigoInfractor");		  
	      Map declaracionMap = (Map) request.getSession().getAttribute("mapCabDeclaraActual");
	      Date fechaDeclaracion = (Date) declaracionMap.get("FEC_DECLARACION");      
	      
	      Map<String, Object> parametros = new HashMap<String, Object>();	      
	      parametros.put("COD_INFRACTOR", codigoInfractor);
	      parametros.put("FEC_DECLARACION_AUX", fechaDeclaracion);
	      
	      List<Map<String, Object>> listaCatMultasPorInfractor = new ArrayList<Map<String,Object>>();
	      
	      if(!codigoInfractor.equals("")){
	    	  listaCatMultasPorInfractor = multaService.obtenerListaCatMultasPorInfractor(parametros);  
	      }
	      
	      List<Map<String, String>> listRetorno = this.obtenerCodigoYDescripcionDeMultas(listaCatMultasPorInfractor);
	      
	      jsonObject.put("success", true);
	      jsonObject.put("listaCatMultasPorInfractor", this.obtenerCodigoYDescripcionDeMultas(listaCatMultasPorInfractor));
	      jsonObject.put("datosComboInfraccion", this.darFormatoParaFilteringSelect(listRetorno));
	  } catch (ServiceException ex) {
		  jsonObject.put("mensajeError", ex.getMessage());
		  jsonObject.put("success", false);
	  } catch (Exception e) {
		  jsonObject.put("success", false);
	  } finally {
		  log.debug("");
	  }	  
      
	  return new ModelAndView(jsonView, jsonObject);
  }
  
  /*
   * M�todo que retorna una lista, para hacer los calculos de la multa, incentivo y la moneda
   */
  private List<Map<String, String>> obtenerCodigoYDescripcionDeMultas(List<Map<String, Object>> listadoInicial) {	  
	  List<Map<String, String>> listaRetorno = new ArrayList<Map<String,String>>();
	  for (Map<String, Object> list : listadoInicial) {
		  HashMap<String, String> mapa = new HashMap<String, String>();
		  mapa.put("cod_datacat",   list.get("CODCONC") == null ? "":list.get("CODCONC").toString());
		  mapa.put("des_corta", 	list.get("DESCONC") == null ? "":list.get("DESCONC").toString());
		  mapa.put("moneda", 	list.get("CMONEDA_MUL") == null ? "":list.get("CMONEDA_MUL").toString());
		  mapa.put("multa", 		  list.get("MPAG") == null ? "":list.get("MPAG").toString());
		  mapa.put("incentivo", 	  list.get("MULTA") == null ? "":list.get("MULTA").toString());
		  mapa.put("naturaleza", 	  list.get("NATURALEZA") == null ? "":list.get("NATURALEZA").toString()); //PAS20155E220000054
		  listaRetorno.add(mapa);
	  }
	  return listaRetorno;
  }
    
  /*
   * M�todo que asigna formato al combo del Infractor
   */
  private List<Map<String, String>> darFormatoParaFilteringSelect(List<Map<String, String>> listaCatalogoInfractor) {	  
	  List<Map<String, String>> listaRetorno = new ArrayList<Map<String,String>>();
	  for (Map<String, String> list : listaCatalogoInfractor) {
		  HashMap<String, String> mapa = new HashMap<String, String>();
		  mapa.put("cod_datacat", list.get("cod_datacat"));
		  mapa.put("des_corta", list.get("cod_datacat")+" "+list.get("des_corta"));
		  mapa.put("formulaMulta",  list.get("multa") == null ? "":list.get("multa").toString());
		  mapa.put("naturaleza",  list.get("naturaleza") == null ? "":list.get("naturaleza").toString()); //PAS20155E220000054
		  listaRetorno.add(mapa);
	  }
	  return listaRetorno;
  }
  
  /*
   * M�todo que asigna Formato para el combo de Porcentajes
   */
  private List<Map<String, String>> darFormatoParaFilteringSelectIncentivoPorcentaje(List<Map<String, String>> listaCatalogoInfractor) {
	  List<Map<String, String>> listaRetorno = new ArrayList<Map<String,String>>();
	  for (Map<String, String> list : listaCatalogoInfractor) {
		  HashMap<String, String> mapa = new HashMap<String, String>();
		  if(list.get("cod_datacat").equals(0)){
			  mapa.put("cod_datacat", list.get("des_corta"));
			  mapa.put("des_corta", "No Aplica");
		  }else{
			  mapa.put("cod_datacat", list.get("des_corta"));
			  mapa.put("des_corta", list.get("des_corta") + "%");
		  }
		  listaRetorno.add(mapa);
	  }	  
	  return listaRetorno;
  }
  
  /*
   * M�todo que retorna un List<Map<String, String>> Ordenado. 
   */
  private List<Map<String, String>> ordenarIncentivoPorcentaje(List<Map<String, String>> listaCatalogoInfractor) {
	  
	  Map<Integer, String> mapaInicial = new HashMap<Integer, String>();
	  for (Map<String, String> map : listaCatalogoInfractor) {
		  mapaInicial.put(Integer.parseInt(map.get("des_corta").toString()),map.get("des_corta"));
	  }
	  	  
	  int[] arrayInicial = new int[listaCatalogoInfractor.size()];
	  int i = 0;
	  for ( Integer key : mapaInicial.keySet() ) {
			arrayInicial[i]=key;
			i++;
	  }
	  
	  int[] arrayOrdenado = ordenarArrayBurbuja(arrayInicial);
	  
	  List<Map<String, String>> listaFinal = new ArrayList<Map<String,String>>();
	  for (int array : arrayOrdenado) {
		  Map<String, String> mapa = new HashMap<String, String>();
		  mapa.put("cod_datacat", mapaInicial.get(array));
		  mapa.put("des_corta", mapaInicial.get(array));		  
		  listaFinal.add(mapa);
	  }	  
	  return listaFinal;
  }
	
  /*
   * M�todo que realiza el ordenamiento de un Arreglo
   */
  public int[] ordenarArrayBurbuja(int[] listArray) {
		int i, j, aux;
		for (i = 0; i < listArray.length - 1; i++)
			for (j = 0; j < listArray.length - i - 1; j++)
				if (listArray[j + 1] < listArray[j]) {
					aux = listArray[j + 1];
					listArray[j + 1] = listArray[j];
					listArray[j] = aux;
				}
		return listArray;
	}
	
  /***   --- CAMBIOS ---   ***/
  
  /**
   * Metodo que permite realizar la liquidacion de la declaracion.
   *
   * @param request
   *          the request
   * @throws Exception
   *           the exception
   */
  public void liquidarDeclaracion(HttpServletRequest request) throws Exception  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
    params.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
    params.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
    params.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
    Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");// NULL

    List listParticipanteDoc = new ArrayList();
    // Obtenemos de cabDeclara (importador y agente)
    Map partic = new HashMap();
    partic.put("COD_TIPPARTIC", "45");
    partic.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
    partic.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
    listParticipanteDoc.add(partic);
    partic = new HashMap();
    partic.put("COD_TIPPARTIC", "41");
    partic.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
    partic.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
    listParticipanteDoc.add(partic);

    List listConvenioSerie = new ArrayList();
    List listDocupreceDua = new ArrayList();

    HashMap paramDocLiq = new HashMap();
    paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
    paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
    paramDocLiq.put("cabDeclara", declaracionActual);
    paramDocLiq.put("listDetDeclara", listDetDeclara);
    paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
    paramDocLiq.put("listConvenioSerie", listConvenioSerie);// CLEAN
    paramDocLiq.put("listDocupreceDua", listDocupreceDua);// CLEAN
    paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
    Map resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);
    declaracionActual.put("caduana", soporteService.obtenerAduana(request));
    Map parametros = new HashMap();
    declaracionActual.put("resulPreliq", resulPreliq);
    parametros.put("mapCabDeclaraActual", declaracionActual);
    parametros.put("lstMultas", WebUtils.getSessionAttribute(request, "lstMultaDua"));
    this.liquidaDeclaracionService.liquidaDiligencia(parametros);

    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

  }
  /*
   * RIN13 SWF
   * M�todo que asigna formato a la lista de autoliquidaciones tipo 27 para ser mostrada en la grilla
   */
  private List<Map<String, Object>> darFormatoParaGrillaAutoliquidaciones(List autoliquidaciones) {
	  
	  List<Map<String, Object>> listaRetorno = new ArrayList<Map<String,Object>>();
	  if(autoliquidaciones!=null){
		  for (int i = 0; i < autoliquidaciones.size(); i++) {
			  Liquida liquidacion = new Liquida();
			  liquidacion = (Liquida) autoliquidaciones.get(i);
			  if(liquidacion!=null){
				  HashMap<String, Object> mapa = new HashMap<String, Object>();
				  mapa.put("numeroLiquiqGrilla", liquidacion.getRladuana() + "-" + liquidacion.getRlano() + "-" +liquidacion.getRlnroliq());
				  mapa.put("numeroLiquidacion", liquidacion.getRlnroliq());
				  mapa.put("aduana", liquidacion.getRladuana());
				  mapa.put("anyo", liquidacion.getRlano());
				  mapa.put("tipoLiquidacion", liquidacion.getRltipliq());
				  mapa.put("moneda", liquidacion.getRlcodmon());
				  mapa.put("descripMoneda", liquidacion.getRlcodmon().equals("S") ? "Soles" : "D\u00f3lares");
				  mapa.put("montoPagar", liquidacion.getRlcodmon().equals("S") ? liquidacion.getRlsmontot() : liquidacion.getRldmontot());
				  mapa.put("indicadorUsado", "N");
				  mapa.put("montoResto", "0");
				  
				  listaRetorno.add(mapa);
			  }
		  }
	  }
	  return listaRetorno;
  }
  
  /*
   *RIN13 SWF
   * */
  public ModelAndView grabarMultasEnSession(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  	
	  	ModelAndView view = new ModelAndView(this.jsonView);
	  	ServletWebRequest webRequest = new ServletWebRequest(request);
	  	
	  	List<Map<String, Object>> lstMultasRegistradas = new ArrayList<Map<String, Object>>();
	  	List<Map<String, Object>> lstAutoliq = new ArrayList<Map<String, Object>>(); 
	  	List<Map<String, Object>> multas = new ArrayList<Map<String, Object>>(); 
	  	
	  	Map<String, Object> declaracionMap = (Map<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	  	String numCtaCte = (String) declaracionMap.get("NUM_CTACTE");
	  	
	  	lstMultasRegistradas = (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_listaMultasInicial"));
	  	lstAutoliq = (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_listaAutoliqInicial"));
	  	
		/*PAS20155E220000501*/
	  	Map<String, Object> generarLCMulta =  (Map<String, Object>) WebUtils.getSessionAttribute(request, "generarLCMulta");
	  	if (generarLCMulta!=null) {
	  	generarLCMulta.clear(); 
	  	WebUtils.setSessionAttribute(request, "generarLCMulta", null);
	  	WebUtils.setSessionAttribute(request, "lstMultaDuaOkResolucion", null);
		WebUtils.setSessionAttribute(request, "generarLC003", null);
		WebUtils.setSessionAttribute(request, "resolucionMulta", null);
		WebUtils.setSessionAttribute(request, "datosMulta", null);
	  	}  	
	    /*PAS20155E220000501*/
	  	  	
	  	//String mensaje = "";
	  	
	  	//mensaje = multaService.validarMontoMultasVsMontoAutoliquidaciones(lstMultasRegistradas,lstAutoliq); 
	  	//INICIO PAS20155E220000054
	  	String tipDilig = WebUtils.getSessionAttribute(request, "tipoDiligencia").toString().trim();
	  	ObjectResponseUtil respuesta = multaService.validarMontoMultasVsMontoAutoliquidaciones(lstMultasRegistradas,lstAutoliq, numCtaCte,tipDilig);
	  	UsuarioBean bUsuario = ((UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean")); //PAS20155E220000054
	  	
	  	if(respuesta.poseeError()){
	  		view.addObject("ok", false);
	  		view.addObject("mensaje", respuesta.getMensajes().get(0).getMensajeerror());
	  	}else if(respuesta.isRespuesta()) {			
	  		view.addObject("ok", Constantes.BUSCAR_RESOLUCION_MULTA);
	  		view.addObject("generarLC", SojoUtil.toJson(respuesta.getDatos().get("generarLCMulta")));
	  		WebUtils.setSessionAttribute(request, "generarLCMulta", respuesta.getDatos().get("generarLCMulta"));
	  		WebUtils.setSessionAttribute(request, "lstMultaDua", lstMultasRegistradas);
			/*PAS20155E220000501*/
	  		WebUtils.setSessionAttribute(request, "lstAutoliquidacionesMulta", lstAutoliq);
			/*PAS20155E220000501*/
	  		
	  //FIN PAS20155E220000054
	  	}else{
	  		multas = armarDataParaGrabarEnSession(lstMultasRegistradas, lstAutoliq);
	  		WebUtils.setSessionAttribute(request, "lstMultaDua", multas);
	  		if(multas.isEmpty()){
		    	view.addObject("ok", false);
		    	view.addObject("mensaje", "");
		    }else{ 
		    	view.addObject("ok", true);
		    	view.addObject("mensaje", "");
		    	view.addObject("multas", multas);
		    }
	  	}
	  	
	  	/*if(mensaje.equals("")){
	  		multas = armarDataParaGrabarEnSession(lstMultasRegistradas,lstAutoliq);
	  		WebUtils.setSessionAttribute(request, "lstMultaDua", multas);
	  		if(multas.isEmpty()){
		    	view.addObject("ok", false);
		    	view.addObject("mensaje", "");
		    }else{
		    	view.addObject("ok", true);
		    	view.addObject("mensaje", "");
		    	view.addObject("multas", multas);
		    }
	  	}else{
	  		view.addObject("ok", false);
	  		view.addObject("mensaje", mensaje);
	  	}*/
	    
	    return view;
  }
  
  //INICIO PAS20155E220000054
  public ModelAndView generarMultasNoCubreAutoliquidaciones(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  	ModelAndView view = new ModelAndView(this.jsonView);
	  	
	  	List<Map<String, Object>> lstMultasRegistradas =  (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstMultaDua");
		/*PAS20155E220000501*/
	  	List<Map<String, Object>> lstAutoliquidacionesMulta = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstAutoliquidacionesMulta");
		/*PAS20155E220000501*/
	  	UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
	  	Map paramMulta = new HashMap();
	  	paramMulta.put("codUsuario", bUsuario.getNroRegistro());
	  	ResCabBean resolucionMulta=(ResCabBean) WebUtils.getSessionAttribute(request, "resolucionMulta");
	  	String resolucion=resolucionMulta.getNumeroResolucion();
	  	paramMulta.put("numeroResolucion", resolucion);	  	
	  	List<Map<String, Object>> multas = multaService.getListMultasNoCubreAutoliquidaciones(lstMultasRegistradas);
	  	
	  	WebUtils.setSessionAttribute(request, "datosMulta", paramMulta);
		/*PAS20155E220000501*/
  		WebUtils.setSessionAttribute(request, "lstAutoliquidacionesMulta", lstAutoliquidacionesMulta);
		/*PAS20155E220000501*/
	  	WebUtils.setSessionAttribute(request, "lstMultaDuaOkResolucion", multas);//bug21603
  		WebUtils.setSessionAttribute(request, "lstMultaDua", multas);
  		if(multas.isEmpty()){
	    	view.addObject("ok", false);
	    	view.addObject("mensaje", "");
	    }else{ 
	    	view.addObject("ok", true);
	    	view.addObject("mensaje", "");
	    	view.addObject("multas", multas);
	    }
  		
  	  return view;
  }
    //FIN PAS20155E220000054
  /*RIN13 SWF*/
  private List<Map<String, Object>> armarDataParaGrabarEnSession(List<Map<String, Object>> lstMultasRegistradas,List<Map<String, Object>> lstAutoliq){
	  	
		    List<Map<String,Object>> listaMulta = new ArrayList<Map<String,Object>>();//data que se envia al Controllador para grabar en session
			
			/*agrupamos por soles*/
			List<Map<String,Object>> multaSoles = new ArrayList<Map<String,Object>>(); 
			multaSoles = multaService.obtenerMultasPorMoneda(lstMultasRegistradas, "Soles");
			
			List<Map<String,Object>> autoliqSoles = new ArrayList<Map<String,Object>>(); 
			autoliqSoles = multaService.obtenerAutoliqPorMoneda(lstAutoliq , "S");
			
			listaMulta.addAll(multaService.asociarAutoliqConMultas(multaSoles,autoliqSoles, "S")); //	S = soles
			
			/*agrupamos por dolares*/
			List<Map<String,Object>> multaDolares = new ArrayList<Map<String,Object>>(); 
			multaDolares = multaService.obtenerMultasPorMoneda(lstMultasRegistradas , "Dolares");
			
			List<Map<String,Object>> autoliqDolares = new ArrayList<Map<String,Object>>(); 
			autoliqDolares = multaService.obtenerAutoliqPorMoneda(lstAutoliq , "D");
			
			listaMulta.addAll(multaService.asociarAutoliqConMultas(multaDolares,autoliqDolares, "D"));//	D = dolares
			
	  return listaMulta;
  }
  /**
   * RIN13
   * */
  
  public ModelAndView calcularMontoMulta(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  
	  ModelAndView view = new ModelAndView(this.jsonView);
	  ServletWebRequest webRequest = new ServletWebRequest(request);
	  
	  String codigoInfraccion = webRequest.getParameter("codigoInfraccion");
	  String formulaMulta = webRequest.getParameter("formulaMulta");
	  
	  BigDecimal montoMulta = new BigDecimal(0);
	  
	  String [] infracciones = Constantes.LISTA_INFRACCIONES_APTAS_PARA_CALCULO_AUTOMATICO_DE_MONTO; 
	  String [] noIncentivo  = Constantes.LISTA_INFRACCIONES_NO_APTAS_PARA_INCENTIVO;
	  
	  if(ArrayUtils.contains(noIncentivo,codigoInfraccion)){
		  view.addObject("incentivo", false);
	  }else{
		  view.addObject("incentivo", true);
	  }
	  
	  if(ArrayUtils.contains(infracciones,codigoInfraccion)){
		  //calculamos monto automatico
		  view.addObject("automatico", true);
		  montoMulta = multaService.calcularMontoMultaAutomatico(codigoInfraccion,formulaMulta);
	  }
	  else{
		  //regresamos y dejamos que el usuario ingrese el monto 
		  view.addObject("automatico", false);
	  }
	  
	  view.addObject("montoMulta", montoMulta);
	  
	  return view;
  }
  
  /**
   * RIN13 SWF
   * */
  public ModelAndView obtenerMultasGrabadasSession(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  
	  ModelAndView view = new ModelAndView(this.jsonView);
	  List<Map<String, Object>> multas = new ArrayList<Map<String, Object>>();
	  List<Map<String, Object>> datosAutoliq = new ArrayList<Map<String, Object>>();
	  List<Map<String, Object>> datosOriginalesMultas = new ArrayList<Map<String, Object>>();
	  multas = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstMultaDua");
	  
	  if(multas != null){
		  for(Map multa : multas){
			  Map<String,Object> datosLiquidaciones = new HashMap<String, Object>();
			  if(!multaExiste(multa,datosOriginalesMultas)){//solo agrega la multa si esque no se encuentra contenida en datosOriginalesMultas
				  if ( multa.get("DATOS_ORIGINALES")!=null){   //INICIO PAS20155E220000054
				  datosOriginalesMultas.add((Map<String, Object>) multa.get("DATOS_ORIGINALES"));  
			  }
			  }
			  datosLiquidaciones.put("NRO_LC", multa.get("NRO_LC"));
			  datosLiquidaciones.put("ADUANA_LC", multa.get("ADUANA_LC"));
			  datosLiquidaciones.put("ANN_LC", multa.get("ANN_LC"));
			  datosAutoliq.add(datosLiquidaciones);
		  } 
	  }
	  
	  if(multas != null && !multas.isEmpty()){
		  //entonces carga multas en grilla
		  if ( datosOriginalesMultas!=null){   //INICIO PAS20155E220000054
		  for(Map datoOriginal : datosOriginalesMultas){
//			  if(datoOriginal.get("moneda").equals("Soles")){
//				  datoOriginal.put("moneda", "S\u00f3les");
//			  }
			  if(datoOriginal.get("moneda").equals("Dolares")){
				  datoOriginal.put("moneda", "D\u00f3lares");
			  }
		  }
		  view.addObject("listaMultasSession", datosOriginalesMultas);
		  view.addObject("listaAutoliqSession", datosAutoliq);
		  view.addObject("indicadorMultasSession", true);
		  }
		  
	  }
	  else{
		  view.addObject("listaMultasSession", null);
		  view.addObject("listaAutoliqSession", null);
		  view.addObject("indicadorMultasSession", false);
	  }
	  
	  return view;
  }
  
  /**
   * RIN13 SWF
   * */
  public boolean multaExiste(Map<String,Object> multa, List<Map<String, Object>> datosOriginalesMultas){
	  
	  if(datosOriginalesMultas.isEmpty()){
		 
		  return false; 
		 
	  }else{
		  
		  for(Map datoMulta : datosOriginalesMultas){
			  
			  if(datoMulta.get("codMulta").toString().equals(multa.get("COD_MULTA").toString())){
				  
				  return true;
				  
			  }
		  }
		  
	  }
	  
	  return false;
	  
  }
  
  /**
   * RIN13 SWF
   * */
  public ModelAndView grabarMultasEnSessionTemp(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  
	  ModelAndView view = new ModelAndView(this.jsonView);
	  ServletWebRequest webRequest = new ServletWebRequest(request);
	  
	try {
		
		List<Map<String, Object>> lstMultasRegistradas = new ArrayList<Map<String, Object>>();			
    	lstMultasRegistradas = (List<Map<String, Object>>) SojoUtil.fromJson(webRequest.getParameter("hdn_listaMultasInicial"));
    	WebUtils.setSessionAttribute(request, "lstMultaDuaTemp", lstMultasRegistradas);
		
	} catch (Exception e) {
		
	}
	finally{
		
	}
	  return view;
  }
  
  /**
   * RIN13 SWF
   * */
  public ModelAndView eliminarMultasEnSession(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
	  
	  ModelAndView view = new ModelAndView(this.jsonView);
	  List<Map<String, Object>> multas = new ArrayList<Map<String, Object>>();
	  ServletWebRequest webRequest = new ServletWebRequest(request);
	  multas = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstMultaDua");
	  
	  String codMulta = webRequest.getParameter("codMulta");
	  if(multas != null){
		  //for(Map multa : multas){
		  boolean evaluoTodo = false;
		  while(!evaluoTodo){
			  for (int i = 0; i < multas.size(); i++) {
				  Map <String, Object> multa = multas.get(i);
		          if (multa.get("COD_MULTA").equals(codMulta)){
		        	  multas.remove(i);
			          request.getSession().setAttribute("lstMultaDua", multas);
			          evaluoTodo = false;
			          break;
		          }
		          evaluoTodo = true;
		          
			  }	  
		  } 
	  }
	  
	  WebUtils.setSessionAttribute(request, "lstMultaDua", multas);
	  
	  return view;
  }
/*PAS20155E220000501*/
 public ModelAndView cancelarEnvioMultasSession(HttpServletRequest request , HttpServletResponse response) throws Exception
  {
	  ModelAndView view = new ModelAndView(this.jsonView);	  
	  WebUtils.setSessionAttribute(request, "lstMultaDua", null);	  
	  return view;
  }
/*PAS20155E220000501*/
  /***********************SET DE SPRING **********************************/

  /**
   * Sets the json view.
   *
   * @param jsonView
   *          the new json view
   */
  public void setJsonView(String jsonView)
  {
    this.jsonView = jsonView;
  }

  /**
   * Sets the multa service.
   *
   * @param multaService
   *          the new multa service
   */
  public void setMultaService(MultaService multaService)
  {
    this.multaService = multaService;
  }

  /**
   * Sets the operador ayuda service.
   *
   * @param operadorAyudaService
   *          the new operador ayuda service
   */
  public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService)
  {
    this.operadorAyudaService = operadorAyudaService;
  }

  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }
  /*jlunah*/
  
  public void setDeudaService(DeudaService deudaService) {
		this.deudaService = deudaService;
	}
  
  /*jlunah*/

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
	this.catalogoAyudaService = catalogoAyudaService;
  }
  
  /*jlunah*/
  
  public void setLiquidaDeclaracionService(
		LiquidaDeclaracionService liquidaDeclaracionService) {
	this.liquidaDeclaracionService = liquidaDeclaracionService;
  }
  
}
