
package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP;//mpoblete rin10

import java.io.*;
import java.math.BigDecimal;
import java.text.DateFormat;
/* P14 - 3014 - Inicio - dhernandezv */
import java.text.SimpleDateFormat;
/* P14 - 3014 - Final - dhernandezv */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.MapUtils;//P34
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.Validate;
import org.springframework.util.CollectionUtils;
/* P14 - 3014 - Inicio - dhernandezv */
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/* P14 - 3014 - Final - dhernandezv */
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.WebUtils;

import org.apache.commons.io.IOUtils;

import java.io.IOException;

import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonAnyFormatVisitor;

import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.DirfCtaCte;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Repocer;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDocu;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroEspeDocu;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionManualService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;//RIN14
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.bean.DatoRectificado;
import pe.gob.sunat.despaduanero2.bean.UniqueKeyDua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PecoAmazoniaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DocAutAsociadoService;
import pe.gob.sunat.despaduanero2.declaracion.service.ObservacionService;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//P34
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.descrminima.web.controller.BytesObjectUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ComunicacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaRectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.IncidenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.VehiCeticoService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;//RIN14
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.WUtil;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.DocControlMercRestringidaVuce;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.ArchivoAnexoDocControlMR;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.DetEvaluacion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudAutorizacionZonaPrimaria;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;
import pe.gob.sunat.despaduanero2.service.SolicitudRectificaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.security.Coder;
import pe.gob.sunat.framework.security.cifrador.factory.HashFactory;
import pe.gob.sunat.framework.security.cifrador.interfaz.Hash;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.compression.ZipUtil;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.lang.Hex;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.GarantiaOperativaService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.sigad.ingreso.service.CertificadoReposicionService;
import pe.gob.sunat.sigad.ingreso.service.CuentaCorrienteReposicionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

import pe.gob.sunat.administracion2.tramite.model.ResCab;//P24
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService; //P24-II
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO; //PAS20175E220200035
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.model.SolicitudAutorizacionZonaPrimaria;//p24 pase 35
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;//p24 pase 35
import pe.gob.sunat.despaduanero2.service.DetEvaluacionService;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;//p24 pase 35
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;//PAS20181U220200054
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen.CertiOrigenElectronicoService;
/**
 * <p>
 * Titulo: Controlador que agrupa las consultas de cualquier tipo de diligencia
 * </p>
 * <p>
 * Descripcion: Controlador que administra las consultas para Fomato A y Formato
 * B
 * </p>
 *
 * @author rmontes,rdelosreyes,wmostacero,lsuclupe,tomas,scallata
 * @since 08-sep-09
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DiligenciaController extends AbstractDespachoController
{
  private JsonSerializer      serializer             = new JsonSerializer(); //P24
  
  private static final String MENSAJE_SOLUCION_ERROR ="Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador."; //P24
  
  private FormatoValorService       formatoValorService;

  private DeclaracionService        declaracionService;

  private SoporteService            soporteService;

  private SolicitudService          solicitudService;

  FabricaDeServicios                fabricaDeServicios;

  private LiquidaDeclaracionService liquidaDeclaracionService;

  private RectificacionService      rectificacionService;

  private IncidenciaService         incidenciaService;

  private DeudaService deudaService;

  private SerieService                    serieService;
  
  /* olunar - 309 */
  private ConsultaService consultaService;
  /* fin */
  
  private VehiCeticoService   	vehiCeticoService;//jenciso
  private ComunicacionService comunicacionService;

  private ResolucionService resolucionService;//P24-II
  
  private DeclaracionConsultaService declaracionConsultaService; //P24
  
  //EGH_INGRESO
  private static final String CODIGO_TRIBUTO_SOBRETASA_ADICIONAL ="0062";
  
  private static final String SI_RECLAMADA = "RECLAMADA"; //P24-II-PAS20165E220200152 
  private static final String NO_RECLAMADA = "NO RECLAMADA"; //P24-II-PAS20165E220200152
  private SolicitudDAO solicitudDAO;//p24 pase 35
  private ParticipanteService participanteService;//p24 pase 35

  private static final String COD_URL_CONSULTA_DUA = "/ol-ad-iadiligencia-consulta/Declaracion.htm?action=cargaDeclaracion";//PAS20171U220200005 //obtenerListadoSeries
	
  /**
   * Metodo que nos permite obtener los Items de una Serie.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cargarConsultaDVItem(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);

    List<Map<String, Object>> listaItems = null;
    int totalItemsporDUA=0; /*p24*/
    Map<String, String> PkSerie = new HashMap<String, String>();
    Map mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
    String numCorreDocConsultado = webRequest.getParameter("hdn_num_corredoc")!=null?webRequest.getParameter("hdn_num_corredoc"):"";
    /*P24*/
    String num_secItem = new String("0");
    String num_secSerie;
    /*P24 fin*/
    String indicadorDuaValorProvisional = "NO";//mpoblete RIN10    
    //String codMonedaTrans="";
    /*P24 Bug 24645*/
    Boolean isConsultaDValor = webRequest.getParameter("consultaDValor")!= null?true:false;
    /*fin P24 Bug 24645*/
    try
    {       
      if(SunatStringUtils.isEmpty(numCorreDocConsultado) || "undefined".equals(numCorreDocConsultado))
      {
        numCorreDocConsultado = mapCabDeclara.get("NUM_CORREDOC").toString();
      }
      PkSerie.put("NUM_CORREDOC", numCorreDocConsultado);
      
      /*inicio P24*/
      if(isConsultaDValor){
    	  PkSerie.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
    	  PkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));
      }else{ //Item Formato B
    	  PkSerie.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
      }
      /*fin P24*/
      
      // para los casos de series agregadas que estan en memoria
      Map<String, String> mapNuevaSerieSerieBase = (Map<String, String>) WebUtils.getSessionAttribute(request,"mapNuevaSerieSerieBase");
      
      if (mapNuevaSerieSerieBase != null && mapNuevaSerieSerieBase.size() > 0)
      {
        String serieBase = mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) != null ? mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) : "";           
		if (!serieBase.equals(""))
		{
		    PkSerie.put("NUM_SECSERIE", serieBase);
        }
      }

      /*P24 - PAS20175E220200035*/
      List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
      if (CollectionUtils.isEmpty(lstSeriesItemActual)){
          Map<String, Object> param = new HashMap<String, Object>();
          param.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
          List lstSeriesItem = serieService.obtenerSeriesItem(param);
          lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
      }
      totalItemsporDUA = lstSeriesItemActual!=null? lstSeriesItemActual.size():0;
      /*P24 - PAS20175E220200035*/
      // Pase PAS20165E220200138
      if(mapCabDeclara!=null)
      {
    		  PkSerie.put("FEC_DECLARACION",  mapCabDeclara.get("FEC_DECLARACION").toString());		
	  }      
      
      
      listaItems = formatoValorService.obtenerFVItem(PkSerie);
      
      listaItems = this.colocarEstadoItem(listaItems, mapCabDeclara);
      /** Inicio mpoblete RIN10**/
      indicadorDuaValorProvisional = duaTieneIndicadorVP(numCorreDocConsultado);
      /** Fin mpoblete RIN10**/   	  
      
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    /*P24*/
    if(isConsultaDValor){
    	num_secSerie = listaItems.get(0)!=null?listaItems.get(0).get("cod_secserie").toString():"";
    	num_secItem = webRequest.getParameter("hdn_num_secitem");
    }else{
    	num_secSerie = webRequest.getParameter("hdn_num_secserie").toString();
    }
    /*P24 fin*/    

    //Inicio p24-bug 24610 //
    Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDocConsultado);    
    List<Map<String, Object>> listaElemFormatoBItemFactura = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_ITEM_FACTURA);//inicio gmontoya Pase 35 2017
    listaElemFormatoBItemFactura.addAll(obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_VFOB_PROVISIONAL));
    listaElemFormatoBItemFactura.addAll(obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU)); //PAS20175E220200035
    //fin gmontoya Pase 35 2017
    //Fin P24-bug 24610//
    
    ModelAndView view = new ModelAndView("consultaDVItem", "listaItems", SojoUtil.toJson(listaItems));
    view.addObject("datamodel", listaItems);

    view.addObject("hdn_num_corredoc", numCorreDocConsultado);
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secserie", num_secSerie);  /*P24*/
    view.addObject("hdn_num_secitem", num_secItem);  /*P24*/
    view.addObject("indicadorDUAValorProvisional", indicadorDuaValorProvisional);//mpoblete RIN10
    view.addObject("camposModificadosFormatoBItemFactura",SojoUtil.toJson(listaElemFormatoBItemFactura));//P24 bug 24610    
    view.addObject("totalItemsporDUA", String.valueOf(totalItemsporDUA));//P24 bug 24960
   /*P24 Bug 24645*/
    view.addObject("isConsutaDValor", isConsultaDValor); 
   
    return view;
  }
//Inicio p24-bug 24610 //
  private List<Map<String, Object>> obtenerListaModificaciones(
			Map<String, Object> mapaRSPTADatosModificados,
			String codTablaCabDeclara) {

		return mapaRSPTADatosModificados.get(codTablaCabDeclara) != null ? (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados
				.get(codTablaCabDeclara) : new ArrayList<Map<String, Object>>();
	}
//Fin P24-bug 24610//
  /**
   * Metodo que nos permite obtener las Diligencias de un documento exacto es
   * invocado tambien desde la consulta de la DUA y diligencia de despacho.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  @Deprecated
  	public ModelAndView cargarConsultaIntervenciones(HttpServletRequest request, HttpServletResponse response) throws Exception {
  		
  		ServletWebRequest webRequest = new ServletWebRequest(request);
  		

  		List<Map<String, Object>> listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal = null;
  		List<Map<String, Object>> listDiligenciasConSustentoModificado = null;
  		List<Map<String, Object>> listadoTotal = null;
  		Map PkDocu = new HashMap<String, String>();
  		boolean tieneSolReconFisico = false;
  		boolean tieneReconFisicoOficio = false;//ggranados 179
  		try {
  			//mostar las diligencias de revision
  			PkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
  			PkDocu.put("viewRevision", "false");
  			PkDocu.put("agrupaTipoDiligencia", "S");

  			listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal = diligenciaService.obtenerDiligencias(PkDocu);
  			PkDocu.remove("agrupaTipoDiligencia");
			listadoTotal = diligenciaService.obtenerDiligencias(PkDocu);
  			listDiligenciasConSustentoModificado = diligenciaService.obtenerDiligenciaDespachoSustentoModificado(PkDocu);
      
  			Consulta filtroConsulta = new Consulta();
  			filtroConsulta.setNumcorredoc(new Long(PkDocu.get("NUM_CORREDOC").toString()));
  			filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
  			// Consultas aprobadas
  			filtroConsulta.setIndicadorRespuesta("1");
  			ArrayList<Consulta> listaSolReconFisico = (ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta);
  			//Consultas rechazadas
  			filtroConsulta.setIndicadorRespuesta("0");
  			listaSolReconFisico.addAll((ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta));
  			if(!CollectionUtils.isEmpty(listaSolReconFisico)){
  				tieneSolReconFisico = true;
  			}  			
  			//ggranados 179
  			IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
  			Map<String, Object> paramIndFisOfi = new HashMap<String, Object>();
  			paramIndFisOfi.put("num_corredoc", PkDocu.get("NUM_CORREDOC").toString());
  			paramIndFisOfi.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_RECONOCIMIENTO_FISICO_OFICIO); 
  			paramIndFisOfi.put("ind_activo", Constantes.INDICADOR_DUA_ACTIVO);
  			Map<String, Object> mapIndFisOfi = indicadorDUADAO.findByDocumentoAndValor(paramIndFisOfi);
  			if(!CollectionUtils.isEmpty(mapIndFisOfi)){
  				tieneReconFisicoOficio = true;
  			}
  		} catch (ServiceException e) {
  			log.error("*** ERROR ***", e);
  			return new ModelAndView("PagM", "message", e.getMessage());
  		} catch (Exception e) {
  			log.error("*** ERROR ***", e);
  			return new ModelAndView("PagM", "message", e.getMessage());
  		}

  		String array = SojoUtil.toJson(listadoAgrupadoParaDiligenciaDespachoOtrasDiligenciaNormal);
  		//String diligenciaTotal = SojoUtil.toJson(listDiligenciasConSustentoModificado);
  		String diligenciaTotal = SojoUtil.toJson(listadoTotal);
  		ModelAndView view = new ModelAndView("ConsultaIntervenciones", "intervenciones", array);
  		view.addObject("tieneSolReconFisico", new Boolean(tieneSolReconFisico));
  		view.addObject("tieneReconFisicoOficio", new Boolean(tieneReconFisicoOficio));//ggranados 179
	    view.addObject("diligenciaTotal", diligenciaTotal);
	    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
	    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
	    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
	    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
	    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));

	    return view;
  	}	

  /**
   * Metodo que nos permite obtener las Incidencias de una determinada
   * Diligencia.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView obtenerIncidencias(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map PkDili = new HashMap<String, String>();

    try
    {
      PkDili.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      PkDili.put("COD_TIPDILIGENCIA", webRequest.getParameter("hdn_cod_tipdiligencia"));
      /** P34 AMANCILLA**/
      String tipDilig = webRequest.getParameter("hdn_cod_tipdiligencia");
      if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)){
        PkDili.put("NUM_CORREDOC_SOL", webRequest.getParameter("hdn_num_corredoc_sol"));
      }

        if (Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(tipDilig)){
            PkDili.put("NUM_CORREDOC_SOL", webRequest.getParameter("hdn_num_corredoc_sol"));
        }
      listado = incidenciaService.obtenerIncidencias(PkDili);
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    return new ModelAndView(this.jsonView, "datamodel", listado);
  }

  /**
   * Metodo que nos permite recibir los datos de los proveedores y numero de
   * facturas por DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaFormatoValor(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  List<Map<String, Object>> listado = null;
	  Map<String, String> PkDocu = new HashMap<String, String>();
	    
	  try {
		  //RIN13
		  //gbecerrav
		  ServletWebRequest webRequest = new ServletWebRequest(request);
		  String hdn_acceso = ObjectUtils.toString(webRequest.getParameter("hdn_acceso"), "");
		  PkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
		  if (hdn_acceso.equals("00")) {
			  PkDocu.put("IND_DEL", "0");
		  }
		  listado = this.formatoValorService.obtenerFVProveedores(PkDocu);
			  
		  ModelAndView view = new ModelAndView("ConsultaFormatoValor", "proveedor", SojoUtil.toJson(listado));
	
		  view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
		  view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
		  view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
		  view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
		  view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
		  return view;
		  
	  } catch (ServiceException e) {
		  log.error("**** ERROR ****:", e);
		  return showErrorPagM(e.getMessage());
	  } catch (Exception e) {
		  log.error("**** ERROR ****:", e);
		  return showErrorPagM(e.getMessage());
	  }
  }
  /*public ModelAndView cargarConsultaFormatoValor(HttpServletRequest request, HttpServletResponse response)
  {

    List<Map<String, Object>> listado = null;
    Map PkDocu = new HashMap<String, String>();
    Map<String, Object> mapCabDeclara = new HashMap<String, Object>();
    try
    {
      String hdn_acceso = ObjectUtils.toString(request.getParameter("hdn_acceso"), "");
      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
      PkDocu.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
      if (hdn_acceso.equals("00"))
      {
        PkDocu.put("IND_DEL", "0");
      }
      listado = formatoValorService.obtenerFVProveedores(PkDocu);

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("ConsultaFormatoValor", "proveedor", SojoUtil.toJson(listado));

    view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
    view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
    view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
    view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
    view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
    view.addObject("hdn_cod_estdua", mapCabDeclara.get("COD_ESTDUA").toString());
    return view;
  }*/

//INICIO P34

  /**
   * Metodo que nos permite recibir los datos de los proveedores y numero de
   * facturas por DUA, para Formato B Inicial.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */// P34-3014 formatoB-Inicial
    public ModelAndView cargarConsultaFormatoValorInicial(HttpServletRequest request, HttpServletResponse response) {

         List<Map<String, Object>> listado = null;
         Map<String, Object> mapCabDeclara = null;

        try {

            mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");

            String hdn_num_corredoc = MapUtils.getString(mapCabDeclara, "NUM_CORREDOC");
            String hdn_cod_aduana = MapUtils.getString(mapCabDeclara, "COD_ADUANA");
            String hdn_ann_presen = MapUtils.getString(mapCabDeclara, "ANN_PRESEN");
            // String hdn_cod_regimen = MapUtils.getString(mapCabDeclara, "COD_REGIMEN"); 

            Declaracion declaracionInicialBean = formatoValorService.obtenerDeclaracionInicial(new Long(hdn_num_corredoc), hdn_cod_aduana, hdn_ann_presen);

            if (declaracionInicialBean == null) {
                throw new Exception("No se pudo recoger data de numeraci�n");
            }

            WebUtils.setSessionAttribute(request, "declaracionInicialBean", declaracionInicialBean);

            listado = new ArrayList<Map<String, Object>>();
            listado = formatoValorService.obtenerFVProveedoresInicial(declaracionInicialBean);
            

        } catch (Exception e) {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView("PagM", "beanM", rBean);
        }

        ModelAndView view = new ModelAndView("ConsultaFormatoValorInicial", "proveedor", SojoUtil.toJson(listado));

        view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
        view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
        view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
        view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
        view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
        view.addObject("hdn_cod_estdua", mapCabDeclara.get("COD_ESTDUA").toString());

        return view;
    }
	
//FIN P34
    
    //inicio gmontoya P24    
	public ModelAndView cargarFormatoBFactura(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ServletWebRequest webRequest = new ServletWebRequest(request);
		String num_corredoc = webRequest.getParameter("hdn_num_corredoc");
		String num_secprove = webRequest.getParameter("hdn_num_secprove");

		List<Map> lstComprobPago = null;

		Map params = new HashMap();
		params.put("NUM_CORREDOC", num_corredoc);
		params.put("NUM_SECPROVE", num_secprove);
		lstComprobPago = this.formatoValorService
				.obtenerFacturasProveedor(params);
		ModelAndView res = new ModelAndView(this.jsonView, "datamodel",
				lstComprobPago);
		return res;

	}
	
	
	public ModelAndView cargarCorrelacionItems(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ServletWebRequest webRequest = new ServletWebRequest(request);
		String num_corredoc = webRequest.getParameter("hdn_num_corredoc");
		String num_secitem = webRequest.getParameter("hdn_num_secitem");
		String num_secprove = webRequest.getParameter("hdn_num_secprove");
		String num_secfact = webRequest.getParameter("hdn_num_secfact");

		List<Map<String,Object>> lstCorrelaciones = null;

		Map params = new HashMap();
		params.put("NUM_CORREDOC", num_corredoc);
		params.put("NUM_SECPROVE", num_secprove);		
		params.put("NUM_SECFACT", num_secfact);
		params.put("NUM_SECITEM", num_secitem);		
		lstCorrelaciones = this.formatoValorService
				.obtenerFormatoBCorrelaciones(params);
		ModelAndView res = new ModelAndView(this.jsonView, "datamodel",
				lstCorrelaciones);
		return res;

	}
	

  public ModelAndView cargarCorrelacionItemsInicial(HttpServletRequest request,
                                             HttpServletResponse response) throws Exception {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    String num_corredoc = webRequest.getParameter("hdn_num_corredoc");
    String num_secitem = webRequest.getParameter("hdn_num_secitem");
    String num_secprove = webRequest.getParameter("hdn_num_secprove");
    String num_secfact = webRequest.getParameter("hdn_num_secfact");

    List<Map<String,Object>> lstCorrelaciones = null;

    Map params = new HashMap();
    params.put("NUM_CORREDOC", num_corredoc);
    params.put("NUM_SECPROVE", num_secprove);
    params.put("NUM_SECFACT", num_secfact);
    params.put("NUM_SECITEM", num_secitem);

    Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");


    lstCorrelaciones = formatoValorService.obtenerFormatoBCorrelacionesInicial(declaracionInicialBean,params);


    ModelAndView res = new ModelAndView(this.jsonView, "datamodel",
            lstCorrelaciones);
    return res;

  }
    //fin gmontoya P24
  
  /**
   * Metodo que nos permite recibir los items de las factura de un proveedor de
   * una determinada DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarFVFacturas(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkFactu = new HashMap<String, String>();
    try
    {
      pkFactu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkFactu.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      pkFactu.put("NUM_SECFACTURA", webRequest.getParameter("hdn_num_secfact"));
      
      listado = formatoValorService.obtenerFVFacturas(pkFactu);
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }

    return new ModelAndView(this.jsonView, "datamodel", listado);
  }

//INICIO P34
  
  /**
   * Metodo que nos permite recibir los items de las factura de un proveedor de
   * una determinada DUA, para Formato B Inicial.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */// P34-3014 formatoB-Inicial
    public ModelAndView cargarFVFacturasInicial(HttpServletRequest request, HttpServletResponse response) {
        // P34-3014 - inicial
        ServletWebRequest webRequest = new ServletWebRequest(request);
        List<Map<String, Object>> listado = null;
        Map pkFactu = new HashMap<String, String>();
       
        //p24  pruizcr
        Map<String, Object> mapa2 = null;
        Map<String, Object> mapCabDeclara = null;
        //fin 
        try {
            pkFactu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
            pkFactu.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
            
          //inicio p24 pruizcr
            pkFactu.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
            pkFactu.put("NUM_SECFACTURA", webRequest.getParameter("hdn_num_factura"));
            pkFactu.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));
            
           
            Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");
            
            if (declaracionInicialBean == null) {
            	 pkFactu.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
                 pkFactu.put("NUM_SECFACTURA", webRequest.getParameter("hdn_num_factura"));
                 pkFactu.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));
                
                 mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
                 String hdn_num_corredoc = MapUtils.getString(mapCabDeclara, "NUM_CORREDOC");
                 String hdn_cod_aduana = MapUtils.getString(mapCabDeclara, "COD_ADUANA");
                 String hdn_ann_presen = MapUtils.getString(mapCabDeclara, "ANN_PRESEN");
                 declaracionInicialBean = formatoValorService.obtenerDeclaracionInicial(new Long(hdn_num_corredoc), hdn_cod_aduana, hdn_ann_presen);
                 mapa2 = formatoValorService.obtenerDatosItemFactura(declaracionInicialBean, pkFactu);           
            }
            // fin  
            listado = formatoValorService.obtenerFVFacturasInicial(declaracionInicialBean, pkFactu);
            
        } catch (ServiceException e) {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(jsonView, "Error", rBean);
        } catch (Exception e) {
            MensajeBean rBean = new MensajeBean();
            rBean.setError(true);
            rBean.setMensajeerror(e.getMessage());
            rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
            log.error("*** ERROR ***", e);
            return new ModelAndView(jsonView, "Error", rBean);
        }
        //p24 pruizcr 
        
        //return new ModelAndView(this.jsonView, "datamodel", listado);
        ModelAndView view = new ModelAndView(this.jsonView, "datamodel", listado);
        
        view.addObject("itemfactura",SojoUtil.toJson(mapa2));
        view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_corredoc"));
        view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
        view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
        view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
        return view;
    }


  public ModelAndView cargarFVItemsFacturaIncial(HttpServletRequest request, HttpServletResponse response) {
    // P34-3014 - inicial
    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkFactu = new HashMap<String, String>();

    //p24  pruizcr
    Map<String, Object> mapa2 = null;
    Map<String, Object> mapCabDeclara = null;
    //fin
    try {
      pkFactu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkFactu.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));

      //inicio p24 pruizcr
      pkFactu.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
      pkFactu.put("NUM_SECFACTURA", webRequest.getParameter("hdn_num_factura"));
      pkFactu.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));


      Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");

      if (declaracionInicialBean == null) {
        pkFactu.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
        pkFactu.put("NUM_SECFACTURA", webRequest.getParameter("hdn_num_factura"));
        pkFactu.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));

        mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
        String hdn_num_corredoc = MapUtils.getString(mapCabDeclara, "NUM_CORREDOC");
        String hdn_cod_aduana = MapUtils.getString(mapCabDeclara, "COD_ADUANA");
        String hdn_ann_presen = MapUtils.getString(mapCabDeclara, "ANN_PRESEN");
        declaracionInicialBean = formatoValorService.obtenerDeclaracionInicial(new Long(hdn_num_corredoc), hdn_cod_aduana, hdn_ann_presen);
        //mapa2 = formatoValorService.obtenerDatosItemFactura(declaracionInicialBean, pkFactu);
      }
      // fin
      listado = formatoValorService.obtenerFVItemsFacturaIncial(declaracionInicialBean, pkFactu);

    } catch (ServiceException e) {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    } catch (Exception e) {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    //p24 pruizcr

    //return new ModelAndView(this.jsonView, "datamodel", listado);
    ModelAndView view = new ModelAndView(this.jsonView, "datamodel", listado);

   // view.addObject("itemfactura",SojoUtil.toJson(mapa2));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
    view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
    view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
    return view;
  }
//FIN P34
  
  /**
   * Metodo que nos permite oibtener el detalle de Formato de Valor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarDetFormatoValor(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapDetFormatoValor = new HashMap<String, Object>();
    Map pkSerie = new HashMap<String, String>();
    String indicadorDuaValorProvisional ="NO";//RIN10 mpoblete BUG21792
    try
    {
      pkSerie.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkSerie.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      pkSerie.put("NUM_FACTURA", webRequest.getParameter("hdn_num_factura"));
      pkSerie.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
      pkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));

      mapDetFormatoValor = formatoValorService.obtenerFVDetalle(pkSerie);
      /** Inicio mpoblete RIN10 BUG21792 **/
      indicadorDuaValorProvisional = duaTieneIndicadorVP(webRequest.getParameter("hdn_num_corredoc"));
      /** Fin mpoblete RIN10 BUG21792 **/   
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("DetFormatoValor", "mapDetDeclaracionValor",
        SojoUtil.toJson(mapDetFormatoValor));
    view.addAllObjects(mapDetFormatoValor);
    view.addObject(mapDetFormatoValor);
    view.addObject("series", SojoUtil.toJson(mapDetFormatoValor.get("listSeries")));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secitem", webRequest.getParameter("hdn_num_secitem"));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
    view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
    view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
    view.addObject("indicadorDUAValorProvisional",indicadorDuaValorProvisional);//RIN10 mpoblete BUG21792
    return view;
  }
 
//INICIO P34 
  /**
   * Metodo que nos permite obtener el detalle de Formato de Valor, para Formato B Inicial.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */// P34-3014 formatoB-Inicial
  public ModelAndView cargarDetFormatoValorInicial(HttpServletRequest request, HttpServletResponse response)
  {
	  
    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapDetFormatoValor = new HashMap<String, Object>();
    Map pkSerie = new HashMap<String, String>();
    try
    {
      pkSerie.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkSerie.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      pkSerie.put("NUM_FACTURA", webRequest.getParameter("hdn_num_factura"));
      pkSerie.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
      pkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));

      Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");

      //mapDetFormatoValor = formatoValorService.obtenerFVDetalleInicial(declaracionInicialBean, pkSerie);
      
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("ConsultaDetFormatoValorInicial", "mapDetDeclaracionValor",
        SojoUtil.toJson(mapDetFormatoValor));
    view.addAllObjects(mapDetFormatoValor);
    view.addObject(mapDetFormatoValor);
    view.addObject("series", SojoUtil.toJson(mapDetFormatoValor.get("listSeries")));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secitem", webRequest.getParameter("hdn_num_secitem"));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
    view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
    view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
    view.addObject("indicadorDUAValorProvisional",mapDetFormatoValor.get("indicadorDUAValorProvisional"));//P34

    return view;
  }
//FIN P34


//INICIO P34 
  /**
   * Metodo que nos permite obtener el detalle de Formato de Valor, para Formato B Inicial.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */// P34-3014 formatoB-Inicial
  public ModelAndView cargarConsultaDVItemInicial(HttpServletRequest request, HttpServletResponse response)
  {


    ServletWebRequest webRequest = new ServletWebRequest(request);

    List<Map<String, Object>> listaItems = null;
    int totalItemsporDUA=0; /*p24*/
    Map<String, String> PkSerie = new HashMap<String, String>();
    Map mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
    String numCorreDocConsultado = webRequest.getParameter("hdn_num_corredoc")!=null?webRequest.getParameter("hdn_num_corredoc"):"";
    /*P24*/
    String num_secItem = new String("0");
    String num_secSerie;
    /*P24 fin*/
    String indicadorDuaValorProvisional = "NO";//mpoblete RIN10
    //String codMonedaTrans="";
    /*P24 Bug 24645*/
    Boolean isConsultaDValor = webRequest.getParameter("consultaDValor")!= null?true:false;
    /*fin P24 Bug 24645*/

    try
    {
      if(SunatStringUtils.isEmpty(numCorreDocConsultado) || "undefined".equals(numCorreDocConsultado))
      {
        numCorreDocConsultado = mapCabDeclara.get("NUM_CORREDOC").toString();
      }
      PkSerie.put("NUM_CORREDOC", numCorreDocConsultado);

      /*inicio P24*/
      if(isConsultaDValor){
        PkSerie.put("NUM_SECFACT", webRequest.getParameter("hdn_num_secfact"));
        PkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));
        PkSerie.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));


      }else{ //Item Formato B
        PkSerie.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
      }
      /*fin P24*/

      // para los casos de series agregadas que estan en memoria
      Map<String, String> mapNuevaSerieSerieBase = (Map<String, String>) WebUtils.getSessionAttribute(request,"mapNuevaSerieSerieBase");

      if (mapNuevaSerieSerieBase != null && mapNuevaSerieSerieBase.size() > 0)
      {
        String serieBase = mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) != null ? mapNuevaSerieSerieBase.get((String) webRequest.getParameter("hdn_num_secserie")) : "";
        if (!serieBase.equals(""))
        {
          PkSerie.put("NUM_SECSERIE", serieBase);
        }
      }

      /*P24*/
      List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
      totalItemsporDUA = lstSeriesItemActual!=null? lstSeriesItemActual.size():0;
      /*P24*/


     //amancilla cambio listaItems = formatoValorService.obtenerFVItem(PkSerie);
      Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");


      listaItems = formatoValorService.obtenerFVDetalleInicial(declaracionInicialBean,PkSerie);

      //listaItems = this.colocarEstadoItem(listaItems, mapCabDeclara);
      /** Inicio mpoblete RIN10**/
      indicadorDuaValorProvisional = duaTieneIndicadorVP(numCorreDocConsultado);
      /** Fin mpoblete RIN10**/

    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    /*P24*/
  
      num_secItem = webRequest.getParameter("hdn_num_secitem");
 
    /*P24 fin*/

    //Inicio p24-bug 24610 //
    Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService
            .obtenerDatosModificadosEnDiligencias(numCorreDocConsultado);
    List<Map<String, Object>> listaElemFormatoBItemFactura = obtenerListaModificaciones(
            mapaRSPTADatosModificados,
            Constantes.COD_TABLA_ITEM_FACTURA);
    //Fin P24-bug 24610//

    ModelAndView view = new ModelAndView("ConsultaDVItemInicial", "listaItems", SojoUtil.toJson(listaItems));
    view.addObject("datamodel", listaItems);

    view.addObject("hdn_num_corredoc", numCorreDocConsultado);
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secserie", " ");  /*P24*/
    view.addObject("hdn_num_secitem", num_secItem);  /*P24*/
    view.addObject("indicadorDUAValorProvisional", indicadorDuaValorProvisional);//mpoblete RIN10
    view.addObject("camposModificadosFormatoBItemFactura",SojoUtil.toJson(listaElemFormatoBItemFactura));//P24 bug 24610
    view.addObject("totalItemsporDUA", String.valueOf(totalItemsporDUA));//P24 bug 24960
   /*P24 Bug 24645*/
    view.addObject("isConsutaDValor", isConsultaDValor);

    return view;

  }
//FIN P34


  /**
   * Metodo que permite obtener los riesgos de la declaracion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaRiesgo(HttpServletRequest request, HttpServletResponse response)
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listaEventos = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaHerraFraudSeries = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaCanalesEvento = new ArrayList<Map<String, Object>>();
    Map pkDocu = new HashMap<String, String>();
    Map<String, Object> mapResultado = new HashMap<String, Object>();

    MensajeBean rBean = null;
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkDocu.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
      pkDocu.put("ANN_DECLARA", webRequest.getParameter("hdn_ann_presen"));
      pkDocu.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
      pkDocu.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
      pkDocu.put(
          "COD_CANAL",
            webRequest.getParameter("hdn_cod_canal") != null ? webRequest.getParameter("hdn_cod_canal") : "");
      pkDocu.put(
          "COD_MOTIVOCANALASIG",
            webRequest.getParameter("hdn_cod_motivocanalasig") != null ? webRequest
                .getParameter("hdn_cod_motivocanalasig") : "");
      pkDocu.put(
          "COD_CANAL_DESC",
            webRequest.getParameter("hdn_cod_canal_desc") != null ? webRequest.getParameter("hdn_cod_canal_desc") : "");
      mapResultado = declaracionService.obtenerRiesgos(pkDocu);
      listaEventos = (ArrayList<Map<String, Object>>) mapResultado.get("listaEventos");
      listaHerraFraudSeries = (ArrayList<Map<String, Object>>) mapResultado.get("listaHerraFraudSeries");
      listaCanalesEvento = (ArrayList<Map<String, Object>>) mapResultado.get("listaCanalesEvento");

    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaRiesgo");
    // DATOS DE LA DECLARACION PARA MOSTRAR EL CANAL
    view.addObject("listaEventos", SojoUtil.toJson(listaEventos));
    view.addObject("listaHerraFraudSeries", SojoUtil.toJson(listaHerraFraudSeries));
    view.addObject("listaCanalesEvento", SojoUtil.toJson(listaCanalesEvento));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;
  }

  /**
   * Metodo que nos permite obtener los documentos de referencia de una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaDocRef(HttpServletRequest request, HttpServletResponse response)
  {

    List<Map<String, Object>> listadoDocumentos = null;
    Map<String, Object> pkDecla = new HashMap<String, Object>();
    MensajeBean rBean = null;
    ServletWebRequest webRequest = new ServletWebRequest(request);

    try
    {
      pkDecla.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
      pkDecla.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
      pkDecla.put("NUM_DECLARACION", SunatStringUtils.lpad(webRequest.getParameter("hdn_num_declaracion"), 6, '0'));
      pkDecla.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));
     // pkDecla.put("caduana", soporteService.obtenerAduana(request));
      pkDecla.put("caduana", webRequest.getParameter("hdn_cod_aduana"));
      listadoDocumentos = soporteService.obtenerDocRef(pkDecla);
      if (CollectionUtils.isEmpty(listadoDocumentos))
      {
        rBean = new MensajeBean();
        rBean.setMensajeerror("No se encontraron datos de documentos de referencia.");
        rBean.setMensajesol("");
        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("consultaDocRef", "documentos", SojoUtil.toJson(listadoDocumentos));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));

    return view;
  }

  /**
   * Metodo que permite consultar la ultima reliquidacion de la DUA ya sea en el
   * proceso de numeracion, recticaciones, regularizaciones, diligencias.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView 2 opciones: si es correcto:
   *         ConsultaUltimaLiquidacion.jsp si hay error : PagM.jsp
   */
  public ModelAndView cargarConsultaUltimaLiquidacion(HttpServletRequest request, HttpServletResponse response)
  {

    try
    {

      MovCabliqdilig movCabliqdiligRspta = new MovCabliqdilig();

      MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
      List<MovCabliqdilig> lstMovCabliqdilig = new ArrayList<MovCabliqdilig>();
      ModelAndView view = new ModelAndView("ConsultaUltimaLiquidacion");
      String codTipdiligencia = "";
      String codTipLiqui = "";

      String[] regimen1070 = new String[]
      { "10", "70" };
      String[] tipoMonentoAutomatico = new String[]
      { "02", "03" };

      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", -1);

      Map<String, Object> declaracion = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      String numCorreDoc = SunatStringUtils.toStringObj(declaracion.get("NUM_CORREDOC"));

      tmpMovCabliqdilig.setAnnDocliq(declaracion.get("ANN_PRESEN").toString());
      tmpMovCabliqdilig.setAnnOrden(declaracion.get("ANN_ORDEN").toString());
      tmpMovCabliqdilig.setCodAduDocliq(declaracion.get("COD_ADUANA").toString());
      tmpMovCabliqdilig.setCodRegDocliq(declaracion.get("COD_REGIMEN").toString());
      String lcNum_Declaracion = Cadena.padLeft(declaracion.get("NUM_DECLARACION").toString().trim(), 6, '0');
      tmpMovCabliqdilig.setNumDocliq(lcNum_Declaracion);
      tmpMovCabliqdilig.setNumOrden(declaracion.get("NUM_ORDEN").toString());


      lstMovCabliqdilig = liquidaDeclaracionService.obtenerMontosCalculadosDeLaLiquidacion(
          tmpMovCabliqdilig,
            numCorreDoc);
      // sabemos que devuelve en forma descendente
      for (MovCabliqdilig movCabliqdilig : lstMovCabliqdilig)
      {
        // obtenego los datos
        codTipdiligencia = movCabliqdilig.getCodTipdiligencia();
        codTipLiqui = movCabliqdilig.getCodTipLiqui();

        // este codigo esta por demas pq en el JSP solo invoca para reg20 y 21
        if (Arrays.asList(regimen1070).contains(declaracion.get("COD_REGIMEN").toString()))
        {
          // buscamos en deuda_docum si encontramos registro entonces mostramos
          // quiere decir que el recalculo fue para menos entonces mostramos
          // ceros
          if (!deudaService.tieneMontosLiquidadosParaDiligencia(numCorreDoc, movCabliqdilig))
          {
            // seteamos cero los valores
            movCabliqdilig = new MovCabliqdilig();
          }
        }

        if (Arrays.asList(tipoMonentoAutomatico).contains(codTipLiqui))
        {
          // debo verificar si la regu y la recti han sido grabadas

          if (!rectificacionService.rectificacionTieneResultado(numCorreDoc, codTipLiqui))
          {
            continue;
          }
        }

        // 04 RELIQUIDACION ( R )
        if ("04".equals(codTipLiqui))
        {
          continue;
        }
        movCabliqdiligRspta = movCabliqdilig;
        break;
      }

      StringBuilder sbMomentoLiquidacion = new StringBuilder();
      if ("01".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("NUMERACION");
      }
      else if ("02".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("RECTIFICACION-AUTOMATICA");
      }
      else if ("03".equals(codTipLiqui))
      {// diligencias cat 375
        sbMomentoLiquidacion.append("REGULARIZACION-AUTOMATICA");
      }
      else if ("05".equals(codTipLiqui))
      {// diligencias cat 375

        sbMomentoLiquidacion.append("DILIGENCIA - ");
        sbMomentoLiquidacion.append(catalogoAyudaService
            .getDescripcionDataCatalogo("356", codTipdiligencia)
            .toUpperCase());
      }

      view.addObject("movCabliqdilig", movCabliqdiligRspta);
      view.addObject("hdn_cod_aduana", declaracion.get("COD_ADUANA"));
      view.addObject("hdn_ann_presen", declaracion.get("ANN_PRESEN").toString());
      view.addObject("hdn_cod_regimen", declaracion.get("COD_REGIMEN"));
      view.addObject("hdn_num_declaracion", Cadena.padLeft(declaracion.get("NUM_DECLARACION").toString(), 6, '0'));
      view.addObject("codTipdiligencia", codTipdiligencia);
      view.addObject("momentoLiquidacion", sbMomentoLiquidacion.toString());

      return view;

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror("Error en la obtencion de la consulta.");
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
  }

  /**
   * Metodo que permite consultar los tributos de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaTributoCargo(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    MensajeBean rBean = null;
    Map<String, Object> mapDetalleDeuda = null;
    List<Map<String, Object>> listaLiquidacionesCobranza = new ArrayList<Map<String, Object>>(); //PASE 176
    List<Map<String, Object>> listaLiquidacionesCobranzaActual = new ArrayList<Map<String, Object>>();//PASE 176
    Map<String, String> pkDocu = new HashMap<String, String>();
    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
    //inicio gmontoya P24
    List<Map<String, Object>> listaDeudaGarantia159 = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaDeudaGarantia159Aux = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaDeudaGaranatia160 = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listaMovDeudaGaranatia160 = new ArrayList<Map<String, Object>>();
    String annPresenAfecta =  webRequest.getParameter("hdn_ann_presen");
    String esGarantia = "0";
    Boolean  tieneDiligenciaDestino =  false;
    String esPecoAmazonia = "0";
    
    //fin gmontoya P24
       
    try
    {
        Map PkDocu = new HashMap<String, String>();
        PkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
        PkDocu.put("viewRevision", "false");
    	PkDocu.put("agrupaTipoDiligencia", "S");
    	List<Map<String, Object>> listDiligencia = null;
    	listDiligencia = diligenciaService.obtenerDiligencias(PkDocu);	 	
    	  for (int i = 0; i < listDiligencia.size(); i++)
    	    {
    	      // no mostrar deudas de tipo 02 LC
    	      if (((String) listDiligencia.get(i).get("COD_TIPDILIGENCIA")).equals("22"))
    	      {
    	    	  tieneDiligenciaDestino = true;
    	      }
    	    }
    	
    	   PecoAmazoniaService pecoAmazoniaService =  fabricaDeServicios.getService("pecoAmazoniaService");
    	   long num_corredoc = new Long(webRequest.getParameter("hdn_num_corredoc").toString()) ;
    	   esPecoAmazonia  =  pecoAmazoniaService.esPecoAmazonia(num_corredoc);
    	   
      //INICIO PASE 176
      String numCtaCte =  webRequest.getParameter("hdn_num_ctacte");
      String numCtaCteDesc =  webRequest.getParameter("hdn_num_ctacte_desc");
      String numDeclaracion =  org.apache.commons.lang.StringUtils.leftPad(webRequest.getParameter("hdn_num_declaracion"), 6, "0");
  	  String codAduana =  webRequest.getParameter("hdn_cod_aduana");
  	  String codRegimen =  webRequest.getParameter("hdn_cod_regimen");
  	  String annPresen =  webRequest.getParameter("hdn_ann_presen");
      //FIN PASE 176	
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));        
      //INICIO PASE 176
      pkDocu.put("COD_ADUANA", codAduana);
      pkDocu.put("ANN_PRESEN", (webRequest.getParameter("hdn_ann_presen").toString().trim()).substring(2));
      pkDocu.put("NUM_DECLARACION", numDeclaracion);
      pkDocu.put("COD_REGIMEN", codRegimen);
      pkDocu.put("caduana", codAduana);      
      pkDocu.put("agregarCeros", "true");//PASE-0176
      // ****Liquidaciones de Cobranza      
      listaLiquidacionesCobranza = soporteService.obtenerLiquidacionesCobranza(pkDocu);
      
      //inicio gmontoya P24	      
	  listaDeudaGarantia159 = deudaService.obtenerGarantias159(numDeclaracion, codAduana, codRegimen, annPresen,"");
	  if(!CollectionUtils.isEmpty(listaDeudaGarantia159)){
		  esGarantia = "159";  
	  }
	  for(Map<String, Object> mapaLiqui : listaLiquidacionesCobranza){
		  String numeroLiquidacion = mapaLiqui!=null?(String)mapaLiqui.get("NUMERO"):"";
		  String[] valores = numeroLiquidacion.split("-");		  
		  String moneda=mapaLiqui.get("RLCODMON").toString();
		  listaDeudaGarantia159Aux = deudaService.obtenerGarantias159(valores[2], valores[0], null, "20".concat(valores[1]),moneda);
		  if(!CollectionUtils.isEmpty(listaDeudaGarantia159Aux)){
			  listaDeudaGarantia159.addAll(listaDeudaGarantia159Aux);
			  esGarantia = "159";  
		  }
	  }
	  if (numCtaCteDesc!=null){
		      if(!numCtaCteDesc.trim().isEmpty()){
		    	  Map<String, Object> params = new HashMap<String, Object>();
		    	  params.put("NUMCTACTE", numCtaCte);
		    	  listaDeudaGaranatia160 = deudaService.obtenerCabeceraGarantia160(numCtaCte);
		    	  if(!CollectionUtils.isEmpty(listaDeudaGaranatia160)){
		    		  esGarantia = esGarantia.equals("0")?"160":"319";
		    		  params.put("CODNUMAFECTA", numDeclaracion);
		    		  params.put("CODADUAFECTA", codAduana);
		    		  params.put("CODREGIAFECTA", codRegimen);
		    		  params.put("ANNANOAFECTA", annPresen);	    		  
		    		  params.put("DUAAFECTA", codAduana.concat(annPresen).concat(codRegimen).concat(numDeclaracion));
		    		  listaMovDeudaGaranatia160 = deudaService.obtenerMovGarantia160(params);
		    	  }
		      }
	  }

    //fin gmontoya P24
      // ****Actualizando datos Liquidaciones de Cobranza lc garantizados y sin garantiza       
      if(!CollectionUtils.isEmpty(listaLiquidacionesCobranza)){
    	  	listaLiquidacionesCobranzaActual = soporteService.obtenerLiquidacionesCobranzaGarantizadosSinGarantizar(annPresenAfecta,listaLiquidacionesCobranza,listaDeudaGarantia159,listaMovDeudaGaranatia160);
      }

      mapDetalleDeuda = deudaService.obtenerDeudaTributaria(pkDocu);
      listaTipoDeuda = getListTipoDeuda(mapDetalleDeuda);
      List<Map<String, Object>> lstTributos = (List<Map<String, Object>>) mapDetalleDeuda.get("listaTributos");
      //Inicio EGH_INGRESO
      Map<String, Object> detDeclaraMap = new HashMap<String, Object>();
      detDeclaraMap.put("NUM_CORREDOC", pkDocu.get("NUM_CORREDOC")); 
      List listConvenioSerie = serieService.obtenerConvenioSerieMap(detDeclaraMap);
      if(listConvenioSerie!=null && listConvenioSerie.size()>0)
    	  ordenarSobreTasaAdicional(lstTributos);
      //Fin EGH_INGRESO
      if ((CollectionUtils.isEmpty(lstTributos) || CollectionUtils.isEmpty(listaTipoDeuda)) && CollectionUtils.isEmpty(listaLiquidacionesCobranza) && esGarantia.equals("0"))//PSE 176
      {
        rBean = new MensajeBean();
        rBean.setMensajeerror("No se encontraron tributos para la Serie.");
        rBean.setMensajesol("");
        return new ModelAndView("PagM", "beanM", rBean);
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaTributoCargo", "deudaDocumento", SojoUtil.toJson(mapDetalleDeuda));
    view.addObject("listaTipoDeuda", listaTipoDeuda);
    view.addObject("tieneDiligenciaDestino", tieneDiligenciaDestino);
    view.addObject("esPecoAmazonia", esPecoAmazonia);
    
    view.addObject("listaLiquidacionesCobranza", SojoUtil.toJson(listaLiquidacionesCobranzaActual)); //pase 176
    //inicio gmontoya P24
	view.addObject("esGarantia", esGarantia);
    view.addObject("listaDeudaGarantia160", listaDeudaGaranatia160);
    view.addObject("listaMovDeudaGarantia160", listaMovDeudaGaranatia160);
    view.addObject("listaDeudaGarantia159", listaDeudaGarantia159);
    //fin gmontoya P24

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    return view;
  }
  
//Inicio EGH_INGRESO
  public void  ordenarSobreTasaAdicional(List<Map<String, Object>> lstTributos){
	   int ctaTributos = 0;
	   while(lstTributos!=null && lstTributos.size()>ctaTributos){
		   if(lstTributos.get(ctaTributos)!=null && (lstTributos.get(ctaTributos)).get("cod_tributo")!=null && (lstTributos.get(ctaTributos)).get("cod_tributo").toString().equals(this.CODIGO_TRIBUTO_SOBRETASA_ADICIONAL)){
			   String des_mto_valnorm = (lstTributos.get(ctaTributos)).get("des_mto_valnorm").toString();
			   String des_mto_valliber = (lstTributos.get(ctaTributos)).get("des_mto_valliber").toString();
			   double des_mto_valnorm_double = Double.parseDouble(des_mto_valnorm);
			   if(des_mto_valnorm_double>0){
				   int tamanhoMonto = des_mto_valnorm.length();
				   des_mto_valnorm = "-"+des_mto_valnorm.trim();
				   des_mto_valnorm = SunatStringUtils.lpad(des_mto_valnorm,tamanhoMonto,' ');
			   }
			   (lstTributos.get(ctaTributos)).put("des_mto_valnorm",des_mto_valliber);
			   (lstTributos.get(ctaTributos)).put("des_mto_valliber",des_mto_valnorm);
			   break;
		   }
		   ctaTributos++;
	   }
  }
  //Fin EGH_INGRESO
/*RIN13FSW-INICIO*/
  /**
   * Metodo que permite consultar los tributos por Serie.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @author jlunah
   */
  public ModelAndView consultarTributosPorSerie(HttpServletRequest request, HttpServletResponse response)
  {

    
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    MensajeBean rBean = null;	    
	    String numeroSerie = webRequest.getParameter("hdn_num_secserie");
	    String numCorreDoc = webRequest.getParameter("hdn_num_corredoc");
	    Map<String,Object> tributos = new HashMap<String, Object>();
	    
	    try
	    {
	    	tributos = deudaService.obtenerListaTributosPorSerie(numCorreDoc,numeroSerie);
	    	
	    	if (!tributos.get("ERROR").equals(""))
		      {
		        rBean = new MensajeBean();
		        rBean.setMensajeerror(tributos.get("ERROR").toString());
		        rBean.setMensajesol("");
		        return new ModelAndView("PagM", "beanM", rBean);
		      }
	      
	    }
	    catch (ServiceException e)
	    {
	      rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean
              .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView("PagM", "beanM", rBean);
	    }
	    
	    finally
	    {
	    	log.debug("end");
	    }	
	    
	    ModelAndView modelandview = new ModelAndView("ConsultaTributoSerie");
	    HashMap<String, String> parametros = new HashMap<String, String>();
	    parametros.put("numCorreDoc", webRequest.getParameter("hdn_num_corredoc"));
	    parametros.put("codAduana", webRequest.getParameter("hdn_cod_aduana"));
	    parametros.put("annPresen", webRequest.getParameter("hdn_ann_presen"));
	    parametros.put("codRegimen", webRequest.getParameter("hdn_cod_regimen"));
	    parametros.put("numDeclaracion", webRequest.getParameter("hdn_num_declaracion"));
	    parametros.put("serieDua", webRequest.getParameter("hdn_num_secserie"));
	    
	    modelandview.addObject("listadoReporte", SojoUtil.toJson(tributos.get("lista")));		
	    modelandview.addObject("params", parametros);
		
		return modelandview;
  }
  /*RIN13FSW-FIN*/
  /**
   * Metodo que nos permite obtener los tipos de deudas filtradas.
   *
   * @param mapa
   *          the mapa
   * @return the list tipo deuda
   */
  private ArrayList<Map<String, String>> getListTipoDeuda(Map<String, Object> mapa)
  {
    List<Map<String, Object>> listaTributos = (ArrayList<Map<String, Object>>) mapa.get("listaTributos");
    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
    boolean banderaComparaTipoDeuda = false;
    for (int i = 0; i < listaTributos.size(); i++)
    {
      // no mostrar deudas de tipo 02 LC
      if (!((String) listaTributos.get(i).get("cod_tipdeuda")).equals("02"))
      {
        if (i == 0)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
          continue;
        }
        banderaComparaTipoDeuda = true;
        for (int j = 0; j < listaTipoDeuda.size(); j++)
        {
          if (listaTipoDeuda.get(j).get("cod_tipdeuda").equals((String) listaTributos.get(i).get("cod_tipdeuda")))
          {
            banderaComparaTipoDeuda = false;
            break;
          }
        }
        if (banderaComparaTipoDeuda)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
        }
      }
    }
    return listaTipoDeuda;
  }

  /**
   * Metodo que permite mostrar la consulta del Manifiesto y su detalle de una
   * determinada DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  @Deprecated
	public ModelAndView cargarConsultaManifiesto(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)request.getSession().getAttribute("mapCabDeclaraActual");

		/*Inicio adecuaciones de PAS20191U220200011*/
		List<Map<String, Object>> listado = new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> listadoSimplificadas = null;
        List<Map<String, Object>> listadoDocuTrans =  new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listadoDocuTransreceptor = null;
 
	    Manifiesto manifiesto = null;
	    String codTipManifiesto = mapCabDeclaraActual.get("COD_TIPMANIFIESTO").toString();
	    String codigoViaTransporte = mapCabDeclaraActual.get("COD_VIATRANS").toString();
	    String codigoAduanaManifiesto = mapCabDeclaraActual.get("COD_ADUAMANIFIESTO").toString();
	    Integer anioManifiesto =  ((BigDecimal) mapCabDeclaraActual.get("ANN_MANIFIESTO")).intValue();
	    String numeroManifiesto = mapCabDeclaraActual.get("NUM_MANIFIESTO").toString();
		Date fecDeclaracion = (Date)mapCabDeclaraActual.get("FEC_DECLARACION")!=null?(Date)mapCabDeclaraActual.get("FEC_DECLARACION"):new Date();
	   
        ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
	    CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		Map<String, Object> vigenciaOtraVia = catalogoAyudaService.getElementoAsoc("455",codigoAduanaManifiesto,
				mapCabDeclaraActual.get("COD_REGIMEN").toString(),fecDeclaracion);
		
		if(!MapUtils.isEmpty(vigenciaOtraVia)){

			boolean evaluarEER = SunatStringUtils.toStringObj(mapCabDeclaraActual.get("COD_LUGARRECEP"))!=null
					&& SunatStringUtils.toStringObj(mapCabDeclaraActual.get("COD_LUGARRECEP")).equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codTipManifiesto,codigoViaTransporte, codigoAduanaManifiesto,
					anioManifiesto, numeroManifiesto,true, fecDeclaracion, evaluarEER);
		}else {
			manifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codTipManifiesto,codigoViaTransporte,codigoAduanaManifiesto,
					anioManifiesto,numeroManifiesto,true);
		}
		if(manifiesto!=null) {
			
			Map<String, Object> pkDocu = new HashMap<String, Object>();
			Map<String, Object> mapReceptor = new HashMap<String, Object>();
			Map<String, Object> pkDocuReceptor = new HashMap<String, Object>();
			

			pkDocu.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC").toString());
			 
			if(manifiesto.isEsSigad()) {
				
				manifiesto.setFechaEfectivaDeLlegada(manifiesto.getFechaProgramadaLlegada());
				if (manifiesto.getFechaTerminoDeDescargaAsInteger()!=null && manifiesto.getFechaTerminoDeDescargaAsInteger()!=0) {
					if(SunatDateUtils.getDateFromInteger(manifiesto.getFechaTerminoDeDescargaAsInteger())!=null){
					manifiesto.setFechaTerminoDeDescarga(SunatDateUtils.getDateFromInteger(manifiesto.getFechaTerminoDeDescargaAsInteger()));
					}else{
						manifiesto.setFechaTerminoDeDescarga( SunatDateUtils.getDefaultDate());
					}
				}
					
				 Map<String,Object> params = new HashMap<String, Object>();
			      params.put("numcorredoc", mapCabDeclaraActual.get("NUM_CORREDOC").toString());
			      DetDeclaraDAO detDeclaraDAO = ( DetDeclaraDAO)fabricaDeServicios.getService("detDeclaraDAO");
				  List<DatoDocTransporte> listDatoDocTransporte = detDeclaraDAO.findDocTransporteByMap(params);
				  ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
				  
				//se traen los docs de transporte desde el detdeclara para buscar el detalle en mcdeta:
				  for (DatoDocTransporte datoDocTransporte : listDatoDocTransporte) {
					   Map<String, Object> mapDocuTrans = new HashMap<String, Object>();
					  mapDocuTrans.put("NUM_DOCTRANSP",datoDocTransporte.getNumdoctransporte());
					  mapDocuTrans.put("COD_PUER_EMBAR",datoDocTransporte.getCodpuerto());					  
					  
						List<Mcdeta> listMcdeta  = manifiestoSigadService.getListMcdetaByClaveDeNegocio( manifiesto.getViaTransporte().getCodDatacat(), 
								mapCabDeclaraActual.get("COD_ADUAMANIFIESTO").toString(),
								((BigDecimal) mapCabDeclaraActual.get("ANN_MANIFIESTO")).intValue(),mapCabDeclaraActual.get("NUM_MANIFIESTO").toString(),
								datoDocTransporte.getNumdoctransporte(),datoDocTransporte.getCodpuerto(), "A");

					   //se jalan los datos de tarja y se completa el nro de detalle:
						if (!listMcdeta.isEmpty() || listMcdeta.size() > 0) {
							//FechaBean FechTarja = new FechaBean(listMcdeta.get(0).getDocumentoDeTransporte().getFechTarja().toString());
							mapDocuTrans.put("NUM_DETALLE",listMcdeta.get(0).getDocumentoDeTransporte().getNumeroDeDetalle());
							//SimpleDateFormat formatoFechaTemp = new SimpleDateFormat("yyyyMMdd");
						   
						   String strfecha =  listMcdeta.get(0).getDocumentoDeTransporte().getFechTarja().toString();
							if(strfecha.length()==8){
								String fechaTarja = strfecha.substring(0,4).concat("-").concat(strfecha.substring(4,6)).concat("-").concat(strfecha.substring(6,8));
							    mapDocuTrans.put("FECHATARJA",fechaTarja);
							}else{
								mapDocuTrans.put("FECHATARJA",null);
							}
							mapDocuTrans.put("FECHADETALLE",null);
							mapDocuTrans.put("CODTIPENVIO",listMcdeta.get(0).getDocumentoDeTransporte().getManifiesto().getViaTransporte().getCodDatacat());
							mapDocuTrans.put("DES_DATACAT","-");
							mapDocuTrans.put("COD_CATEGORIA",listMcdeta.get(0).getDocumentoDeTransporte().getCodCategoria().getCodDatacat());
							if (!listMcdeta.get(0).getDocumentoDeTransporte().getBultosRecibidos().equals(0) && !listMcdeta.get(0).getDocumentoDeTransporte().getPesoRecibido().equals(0)) {
								mapDocuTrans.put("FECHAICA",null);
							}
						}
						
						listadoDocuTrans.add(mapDocuTrans);
				  }
					  
				  //obtener el receptor de carga del asigad
				  pkDocuReceptor.put("anno", anioManifiesto);
				  pkDocuReceptor.put("codi_aduan", codigoAduanaManifiesto);
				  pkDocuReceptor.put("nume_mc", numeroManifiesto);
				  pkDocuReceptor.put("via_trans", manifiesto.getViaTransporte().getCodDatacat()); 
				  pkDocuReceptor.put("listadoDocuTrans", listadoDocuTrans);
				  listadoDocuTransreceptor = declaracionService.obtenerReceptorCargaDUAEnAsigad(pkDocuReceptor); 
				  if(!listadoDocuTransreceptor.isEmpty() && listadoDocuTransreceptor!=null){						 
				  	  mapReceptor.put("NOM_RAZONSOCIAL",listadoDocuTransreceptor.get(0).get("NOM_RAZONSOCIAL"));
				   	  mapReceptor.put("NUM_DOCIDENT",listadoDocuTransreceptor.get(0).get("NUM_DOCIDENT"));
				   	  listadoDocuTrans.add(mapReceptor);
				  }
				
			
			}else {
		  	
				manifiesto.setFechaTerminoDeDescarga(manifiesto.getFechaTerminoDeDescarga()!=null 
						&& !SunatDateUtils.isDefaultDate(manifiesto.getFechaTerminoDeDescarga())?manifiesto.getFechaTerminoDeDescarga():null);
		      
				listadoDocuTrans = declaracionService.obtenerDocumentosTransporteDUA(pkDocu);
		     pkDocuReceptor.put("NUM_CORREDOC",manifiesto.getNumeroCorrelativo());

				//datos del receptor SDA
		  	if(!CollectionUtils.isEmpty(listadoDocuTrans)){      
		      pkDocuReceptor.put("NUM_DETALLE", listadoDocuTrans.get(0).get("NUM_DETALLE").toString());
		      listadoDocuTransreceptor = declaracionService.obtenerReceptorCargaDUA(pkDocuReceptor);
		  	  
		      if(!listadoDocuTransreceptor.isEmpty() && listadoDocuTransreceptor!=null){
		    	  mapReceptor.put("NOM_RAZONSOCIAL",listadoDocuTransreceptor.get(0).get("NOM_RAZONSOCIAL"));
		    	  mapReceptor.put("NUM_DOCIDENT",listadoDocuTransreceptor.get(0).get("NUM_DOCIDENT"));
		    	  listadoDocuTrans.add(mapReceptor);
		      }
		    	}else {
					listadoDocuTrans = new ArrayList<Map<String,Object>>();
					listado = new ArrayList<Map<String,Object>>();
					listadoDocuTransreceptor  = new ArrayList<Map<String,Object>>();
				}
			}
		      if(!manifiesto.isEsSigad()){
					listado = declaracionService.obtenerDatadoDUA(pkDocu);
		      }else{
		    	 listado = declaracionService.obtenerDatadoDUASIGAD(pkDocu);
		      }

			/*Fin PAS20191U220200011 - ajustes de manif*/
			/*Inicio  PAS20191U220200011 - adicionar las simplificadas que se encuentren*/
			if(!CollectionUtils.isEmpty(listado)){

				for(int i=0; i<listado.size();i++) {
					Map<String, Object> datado = listado.get(i);
					if(datado.get("DUA").equals("---")) {
						listado.remove(i);//depurar las que no tienen detalle, abajo se vern
		  	}
				}
			}

			List<String> listRegDesti= new ArrayList<String>();
			listRegDesti.add(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
			listRegDesti.add(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ);
			listRegDesti.add(ConstantesDataCatalogo.REG_IMPO_COURIER_EER);
			pkDocu.put("listRegDesti",listRegDesti);
			pkDocu.put("numeroCorrelativo",pkDocu.get("NUM_CORREDOC"));
			pkDocu.put("codi_aduan",codigoAduanaManifiesto);
			pkDocu.put("nume_mc", SunatStringUtils.lpad(numeroManifiesto,5,' '));
			pkDocu.put("via_trans", codigoViaTransporte) ;
			pkDocu.put("anno", anioManifiesto);
			listadoSimplificadas = declaracionService.obtenerDatadoSimplificadaDUA(pkDocu);

			if(listadoSimplificadas!=null && !listadoSimplificadas.isEmpty()) {
					listado.addAll(listadoSimplificadas);
			}
		}else {
			listadoDocuTrans = new ArrayList<Map<String,Object>>();
			listado = new ArrayList<Map<String,Object>>();
			listadoDocuTransreceptor  = new ArrayList<Map<String,Object>>();
    }
	Map<String,Object> pesosBultos = new HashMap<String, Object>();

    ModelAndView view = new ModelAndView("ConsultaManifiesto", "datado", CollectionUtils.isEmpty(listado)?"[]" : SojoUtil.toJson(listado));//gmontoya P24
    view.addObject("mapCabDeclaraActual", mapCabDeclaraActual);
    view.addObject("manifiesto", manifiesto);
    view.addObject("docuTrans", CollectionUtils.isEmpty(listadoDocuTrans)?"[]" : SojoUtil.toJson(listadoDocuTrans));//gmontoya P24
    view.addObject("pesosBultos", CollectionUtils.isEmpty(pesosBultos)?"[]" : SojoUtil.toJson(pesosBultos));//gmontoya P24

    mapCabDeclaraActual = null;
    return view;
  }



  /**
   * Permite ver la consulta de los contenedores asociados a una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaContenedores(HttpServletRequest request, HttpServletResponse response)
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);
    //inicio gmontoya P24
    Map<String, Object> mapCabDeclaraActual = (Map<String, Object>)request.getSession().getAttribute("mapCabDeclaraActual");
    Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");//P24-PAS20165E220200099

    String codAduana = mapCabDeclaraActual.get("COD_ADUAMANIFIESTO")!=null?mapCabDeclaraActual.get("COD_ADUAMANIFIESTO").toString():"";
    String codRegimen = mapCabDeclaraAnt.get("COD_REGIMEN")!=null?mapCabDeclaraAnt.get("COD_REGIMEN").toString():"";//P24-PAS20165E220200099
    String anhoManifiesto = mapCabDeclaraActual.get("ANN_MANIFIESTO")!=null?String.valueOf(mapCabDeclaraActual.get("ANN_MANIFIESTO")).substring(2, 4):"";
	String cod_terminal = mapCabDeclaraActual.get("COD_ANT")!=null?mapCabDeclaraActual.get("COD_ANT").toString():"";
	String numDeclaracion = SunatStringUtils.lpad(String.valueOf(mapCabDeclaraActual.get("NUM_DECLARACION")),6,'0');	
	String url = "http://www.aduanet.gob.pe/ol-ad-itconsultadua/cntS01Alias?accion=ConsultaContenedor&codi_regi=".concat(codRegimen)
			.concat("&codi_aduan=").concat(codAduana).concat("&ano_prese=").concat(anhoManifiesto).concat("&nume_corre=").concat(numDeclaracion).concat("&nume_termi=").concat(cod_terminal);
    //fin gmontoya P24
    
    
    
    List<Map<String, Object>> listado = null;
    Map pkDocu = new HashMap<String, String>();
    MensajeBean rBean = null;
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      listado = declaracionService.obtenerContenedoresEvaluacionSINI(mapCabDeclaraActual,pkDocu);//gmontoya P24
//      if (CollectionUtils.isEmpty(listado))
//      {
//        rBean = new MensajeBean();
//        rBean.setMensajeerror("No se encontraron datos de contenedores asociados.");
//        rBean.setMensajesol("");
//        return new ModelAndView("PagM", "beanM", rBean);
//      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    ModelAndView view = new ModelAndView("ConsultaContenedor", "contenedor", SojoUtil.toJson(listado));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("URL_SINI", url);//gmontoya P24
    return view;
  }

  /**
   * Metodo que obtiene los documentos asociados y autorizantes segun sea la
   * invocacion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  @Deprecated
  public ModelAndView cargarConsultaDocAutorizaSerie(HttpServletRequest request, HttpServletResponse response)
  {
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    MensajeBean rBean = null;//P46-PAS20155E410000032-[jlunah]
	    ModelAndView view = new ModelAndView("ConsultaDocAutorizaSerie");//P46-PAS20155E410000032-[jlunah]

	    /*P46-PAS20155E410000032-[jlunah] se agrego try catch*/
	    try	{

	    String acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

	    List<Map<String, Object>> listado2 = new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> listadoDocAsociado = null;
	    List<Map<String, Object>> listadoDetAutorizacion = null;

	    // para deshabilitar boton de grabado del JSP
	    Boolean banderaEdicion = false;
	    boolean banderaExiste = false;
	    String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? (String) WebUtils
	        .getSessionAttribute(request, "tipoDiligencia") : "";
	    String serieSeleccionada = webRequest.getParameter("hdn_num_secserie") != null ? (String) webRequest
	        .getParameter("hdn_num_secserie") : "";

	    // datos de la session
	    Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
	    Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
	    List<Map<String, Object>> lstDetDeclaraAnt = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
	        request,
	          "lstDetDeclaraActual");

	    String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();
	    //inicio gmontoya P24
	    
	    String codAduana = String.valueOf(mapCabDeclara.get("COD_ADUANA"));
	    String anhoDua = String.valueOf(mapCabDeclara.get("ANN_PRESEN"));
		String codRegimen =	String.valueOf(mapCabDeclara.get("COD_REGIMEN"));
		String numDeclaracion = SunatStringUtils.lpad(String.valueOf(mapCabDeclara.get("NUM_DECLARACION")),6,'0');
		
		String url = "http://www.aduanet.gob.pe/servlet/CR10Inmoviliza?codi_aduan=".concat(codAduana)
				.concat("&ano_prese=").concat(anhoDua).concat("&nume_corre=").concat(numDeclaracion).concat("&regimen=").concat(codRegimen).concat("&wreg=").concat(codRegimen);
		
		
	    Map mapaDocumentosAsociados = soporteService.getDocumentosDUA(numCorreDoc, mapCabDeclara);
	            //P24-II Inicio
	    		ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("codiAdua", codAduana);
				params.put("codigoAduana", codAduana);
				params.put("dresAnno", anhoDua);
				params.put("dresNro", numDeclaracion);
				params.put("ldres_tip", new String[] {
						ConstantesDataCatalogo.COD_DOCUMENTO_TRAMITE_DOCUMENTO_RESOLUCION_DIVISION,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_INTENDENCIA,	
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_GERENCIA,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_SUPERINTENDENCIA,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_DE_INTENDENCIA_NACIONAL,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_JEFATURAL_143,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_DIRECTORAL_180,
						ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_JEFATURAL_186
						});

				List<Map<String, Object>> listaResol = resolucionService.obtenerResolucionConTransbordo(params);

				List<Map<String, Object>> listaResolFinal = new ArrayList<Map<String, Object>>();
				if(!CollectionUtils.isEmpty(listaResol)){
					for (Map<String, Object> resol :listaResol){
						Map<String,Object> mapaResol = new HashMap<String,Object>();
						mapaResol.put("TIPO_DOCUMENTO",resol.get("TIPO_DOCUMENTO"));
						mapaResol.put("NUMERO", resol.get("NUMERO"));
						mapaResol.put("FECHA_HORA", resol.get("FECHA_HORA")); //P24-II-PAS20165E220200152 
						Map<String, Object> paramsCab = new HashMap<String, Object>();
						String[] parts = resol.get("NUMERO").toString().split("-");
						paramsCab.put("codiAdua", parts[0].toString());
						paramsCab.put("dresTip", resol.get("CODIGO_TIPO_DOCUMENTO").toString());
						paramsCab.put("dresArea", parts[1].toString());
						paramsCab.put("dresAnno", parts[2].toString());
						paramsCab.put("dresNro", parts[3].toString());
						List<ResCab> listCabRes = resolucionService.find(paramsCab);
						if(!CollectionUtils.isEmpty(listCabRes)){
							if(listCabRes.get(0).getReclamada()==0){
								mapaResol.put("SITUACION", NO_RECLAMADA);
							}
							else{
								mapaResol.put("SITUACION", SI_RECLAMADA);
							}
						}else{
							mapaResol.put("SITUACION", "");
						}
						listaResolFinal.add(mapaResol);
					}
				}
	            //P24-II Fin
				
		       
	    Map<String, Object> pkDocuOtros = new HashMap<String, Object>();
	    pkDocuOtros.put("NUM_CORREDOC", numCorreDoc);
	    pkDocuOtros.put("listaCodTipOper",new String[]{"1","9","P","C"});//gmontoya P24 II
		
	  	Map<String, Object> mapDatosDocOtros = solicitudService.obtenerDocDUAOtros(pkDocuOtros);
	    //fin gmontoya P24
	    if (!SunatStringUtils.isEmpty((String) mapCabDeclara.get("COD_ESTDUA"))
	        && (webRequest.getParameter("banderaEdicion") != null ? Boolean.valueOf(webRequest.getParameter(
            "banderaEdicion").toString()) : false))
    {
	      // comparamos con tipo de diligencia 01 y 04, segun catalogo 356
      if (!("01".equals(tipoDiligencia) && "04".equals(tipoDiligencia)))
      {
	        banderaEdicion = true;
	      }
	    }

	    // obtenemos los datos
    if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")))
    {
	      listadoDocAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
	      listadoDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
    }
    else
    { // obtenemos de la BD

	      Map<String, String> pkDocu = new HashMap<String, String>();
	      pkDocu.put("NUM_CORREDOC", numCorreDoc);

	      // Para consulta por SERIE.
      if (!SunatStringUtils.isEmpty(serieSeleccionada))
      {
	        pkDocu.put("NUM_SECSERIE", serieSeleccionada);
	        pkDocu.put("fortipoopedif", "1");// activar diferencia
	        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
      }
      else
      { // consulta por DUA
	        pkDocu.put("fortipoopedif", "1");// activar diferencia
	        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
	      }
	      // jala solo los activos
	      pkDocu.put("IND_DEL", "0");

	      Map<String, Object> mapDatos = solicitudService.obtenerDocAutoriza(pkDocu);

	      listadoDocAsociado = (List<Map<String, Object>>) mapDatos.get("lstDocAutAsociado");
	      listadoDetAutorizacion = (List<Map<String, Object>>) mapDatos.get("lstDetAutorizacion");
	      // ponemos en session los datos de la BD a session como datos ant
	      mapCabDeclaraAnt.put("lstDocAutAsociado", Utilidades.copiarLista((List) listadoDocAsociado));
	      mapCabDeclaraAnt.put("lstDetAutorizacion", Utilidades.copiarLista((List) listadoDetAutorizacion));
	      request.getSession().setAttribute("mapCabDeclara", mapCabDeclaraAnt);
	    }

	    // Si tenemos series nuevas recogemos sus docautorizantes
    if (!SunatStringUtils.isEmpty(serieSeleccionada))
    { // consulta por serie
	      // Agregado los documentos autorizantes de Series con estado
	      // IND_TIPO_REGISTRO = '1'
	      Map key = new HashMap();
	      key.put("NUM_CORREDOC", numCorreDoc);
	      key.put("NUM_SECSERIE", serieSeleccionada);
	      Map<String, Object> mapDetDeclaraSerieSeleccionada = Utilidades.obtenerElemento(lstDetDeclaraAnt, key);

	      // si la serie seleccionada esta eliminada //ESTADO_REGISTRO 0 REGISTRADO
	      // EN BD, 1 PENDIENTE DE REGISTRO EN BD
	      if (!CollectionUtils.isEmpty(mapDetDeclaraSerieSeleccionada)
	          && SunatStringUtils.isEmpty((String) mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO"))
          && "1".equals(mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO").toString()))
      {

	        List<Map<String, Object>> listaAdicional = (List<Map<String, Object>>) mapDetDeclaraSerieSeleccionada
	            .get("lstDetAutorizacion");

	        listaAdicional = (listaAdicional != null) ? listaAdicional : new ArrayList<Map<String, Object>>();
	        listadoDetAutorizacion.addAll(Utilidades.copiarLista((List) listaAdicional));

	      }

      for (Map<String, Object> mapa1 : listadoDetAutorizacion)
      {
        if (mapaDocumentosContieneSerie(mapa1, serieSeleccionada))
        {
	        	String codTipOper1 = mapa1.get("COD_TIPOPER").toString().trim();
	        	
          for (Map<String, Object> mapa2 : listadoDocAsociado)
          {
	            banderaExiste = false;
	            String codTipOper2 = mapa2.get("COD_TIPOPER").toString().trim();
	            
	            if (mapa1.get("NUM_SECDOC").toString().trim().equals(mapa2.get("NUM_SECDOC").toString().trim()) 
	            		&& codTipOper1.equals(codTipOper2)
	                    && !codTipOper1.equals("C") && !codTipOper1.equals("P"))  //RIN14 - no se requiere que se muestren los documentos de control autorizantes
	                //&& mapa1.get("COD_TIPOPER").toString().trim().equals(mapa2.get("COD_TIPOPER").toString().trim())
	                //&& !mapa1.get("COD_TIPOPER").toString().trim().equals("C") && !mapa1.get("COD_TIPOPER").toString().trim().equals("P")) 
	            {
              for (Map<String, Object> mapa3 : listado2)
              {
	                if (mapa2.get("NUM_SECDOC").toString().trim().equals(mapa3.get("NUM_SECDOC").toString().trim())
	                    //&& mapa2.get("COD_TIPOPER").toString().trim().equals(mapa3.get("COD_TIPOPER").toString().trim()))
                	&& codTipOper2.equals(mapa3.get("COD_TIPOPER").toString().trim()))
                {
	                  banderaExiste = true;
	                  break;
	                }
	              }
              if (!banderaExiste && "0".equals(mapa2.get("IND_DEL")))
              {
	                listado2.add(mapa2);
	              }
	            }
	          }
	        }
	      }

    }
    else
    { // para consulta por DUA
    	for (Map mapa : listadoDocAsociado)
      	{
	        Map mapClave = new HashMap<String, Object>();
	        mapClave.put("NUM_CORREDOC", mapa.get("NUM_CORREDOC"));
	        mapClave.put("NUM_SECDOC", mapa.get("NUM_SECDOC"));
	        mapClave.put("COD_TIPOPER", mapa.get("COD_TIPOPER"));
	        // solo muestra activos
				//PAS20155E220000054
	        //amancilla se habilita para que se pueda editar solo las documentos asociados que no esten asociados a la ninguna serie
	        if ("0".equals(mapa.get("IND_DEL")) && CollectionUtils.isEmpty(Utilidades.obtenerElemento(listadoDetAutorizacion, mapClave)))
	        {
	          listado2.add(mapa);
	        }
	      }
	    }
	    // actualizo los datos en session de la declaracion actual
	    mapCabDeclara.put("lstDocAutAsociado", listadoDocAsociado);
	    mapCabDeclara.put("lstDetAutorizacion", listadoDetAutorizacion);
	    request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

	    if (CollectionUtils.isEmpty(listado2))
	    	{
		      banderaEdicion = false;
		    }
    	
    
	    /*se subio linea de codigo - P46-PAS20155E410000032-[jlunah]*/
	    //PAS20165E220200099 - Se saco afuera los seteos de documentos  
	    // para poner el titulo
	    view.addObject("documentos", !CollectionUtils.isEmpty(listado2) ? SojoUtil.toJson(listado2) : "[]");
	    //inicio gmontoya P24
	    List<Map<String,Object>> lista = mapaDocumentosAsociados.get("listExpediDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listExpediDua"):new ArrayList<Map<String,Object>>();
	    List<Map<String,Object>> listaOtros = mapDatosDocOtros.get("lstDocAutAsociado")!=null?(List<Map<String,Object>>)mapDatosDocOtros.get("lstDocAutAsociado"):new ArrayList<Map<String,Object>>();
	    lista.addAll(mapaDocumentosAsociados.get("listDocIntDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listDocIntDua"):new ArrayList<Map<String,Object>>());
	            lista.addAll(listaResolFinal != null ? listaResolFinal : new ArrayList<Map<String, Object>>());//P24-II
	    view.addObject("documentosTramite", !CollectionUtils.isEmpty(lista) ? SojoUtil.toJson(lista) : "[]");
	    view.addObject("documentosOtros", !CollectionUtils.isEmpty(listaOtros) ? SojoUtil.toJson(listaOtros) : "[]");
	    view.addObject("documentosActas", !CollectionUtils.isEmpty(mapaDocumentosAsociados.get("listActasDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listActasDua"):null) ? SojoUtil.toJson((List)mapaDocumentosAsociados.get("listActasDua")) : "[]");
	    view.addObject("URL_ACTAS", url);//gmontoya P24
	    //view.addObject("URL_TRAMITE", "http://www.aduanet.gob.pe/cl-ti-itsigad/sigadS02Alias");//gmontoya P24
	    view.addObject("URL_TRAMITE", "http://intranet/cl-ti-itsigad/sigadS02Alias?accion=detalleDoc");//P24-PAS20165E220200099
	    view.addObject("URL_DocReferencia", "http://intranet/cl-ti-itsigad/sigadS02Alias?accion=detalleExp");//vramosd P24
	    //fin gmontoya P24
	      //amancilla Bug
	      view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
	      view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
	      view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
	      view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
	      // tambien se consulta desde la declaracion entonces esteparametro es vaicio o null
	      view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));

    if (!acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))
    {
	      // Datos de formulario
	      String documento = SojoUtil.toJson(listado2).replaceAll("null", "\"\"");

      if ("10".equals(tipoDiligencia))
      {
	        if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()) && !CollectionUtils.isEmpty(listado2))
         {
	           banderaEdicion = true;
         }
         else
         {
	           banderaEdicion = false;
	         }
	      }

	      view.addObject("documentos", documento);
	      view.addObject("bEdicion", banderaEdicion);
	      view.addObject("hdn_num_corredoc", numCorreDoc);
	      //amancilla se agrego pq no pinta pase 54
//	      String codAduana = mapCabDeclara.get("COD_ADUANA").toString();//GMONTOYA P24
	      String anno = mapCabDeclara.get("ANN_PRESEN").toString();
//	      String codRegimen = mapCabDeclara.get("COD_REGIMEN").toString();//GMONTOYA P24
//	      String numDeclaracion = mapCabDeclara.get("NUM_DECLARACION").toString();//GMONTOYA P24
	      // fina amancilla
	      view.addObject("hdn_cod_aduana", codAduana);
	      view.addObject("hdn_ann_presen", anno);
	      view.addObject("hdn_cod_regimen", codRegimen);
	      view.addObject("hdn_num_declaracion", numDeclaracion);
	      view.addObject("hdn_num_secserie", serieSeleccionada);
	      if(lstDetDeclaraAnt != null){
	    	  view.addObject("hdn_total_series", lstDetDeclaraAnt.size());
	      }

	      List<Map<String, String>> lstTipoOperacion = this.catalogoAyudaService.getElementosCat("327");
      if (!CollectionUtils.isEmpty(lstTipoOperacion))
      {
	        Iterator it = lstTipoOperacion.iterator();
        while (it.hasNext())
        {
	          Map<String, String> mp = (Map<String, String>) it.next();
	          if (mp.get("cod_datacat").equals("C"))
	            it.remove();
	        }
	      }

	      view.addObject("lstTipoOperacion", SojoUtil.toJson(lstTipoOperacion));
	      view.addObject("lstEntidad", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("49")));
	      view.addObject("lstTipoDocumento", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("367")));

	    }
   }
    catch (ServiceException e) {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror(e.getMessage());
				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				return new ModelAndView("PagM", "beanM", rBean);
			} catch (Exception e) {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror(e.getMessage());
				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

				return new ModelAndView("PagM", "beanM", rBean);
			} finally {
			}
	    return view;
	  }


  	//PAS20181U220200069
    public ModelAndView cargarConsultaDocAutorizaPeco(HttpServletRequest request, HttpServletResponse response)
    {
        //ServletWebRequest webRequest = new ServletWebRequest(request);
        
        	Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
        	MensajeBean rBean = null;
        	ModelAndView view = new ModelAndView("ConsultaDocAutorizaPeco");
 
        	
        	try{
        	final String[] LISTA_ESTADOS_SOLICITUD_PECO = {"01","02","03","04"};
        	final String[] LISTA_COD_SOLICITUD = {ConstantesDataCatalogo.TIPO_SOLICITUD_RECONOCIMIENTO_FISICO};
        	/*---------Para Solicitudes--------*/
        	 Map<String, Object> mapaSolicitud = new HashMap<String, Object>();
       		mapaSolicitud.put("numCorreDocPre", mapCabDeclara.get("NUM_CORREDOC").toString());
    		mapaSolicitud.put("codTipSol", LISTA_COD_SOLICITUD);
    		mapaSolicitud.put("codEstSol",LISTA_ESTADOS_SOLICITUD_PECO);
    		
        	SolicitudDAO solicitudDAO = fabricaDeServicios.getService("despaduanero2.solicitudDAO");
    		List<Solicitud> solReguReconFisico = solicitudDAO.buscarSolicitudesAsociadasDAMs(mapaSolicitud);
    		
    		if (solReguReconFisico.size()!=0){
    		Long numCorreDocSol =solReguReconFisico.get(0).getNumeroCorrelativo();
    		   		
    		Map<String, Object> params = new HashMap<String, Object>();
    		params.put("NUM_CORREDOC",numCorreDocSol);
    		params.put("COD_RESULTADOEVAL",1);
    		DetEvaluacionService detEvaluacionService = (DetEvaluacionService) fabricaDeServicios.getService("despaduanero2.detEvaluacionService");
    		List<DetEvaluacion> detEvaluacion = detEvaluacionService.listDetEvaluacion(params);
    		
    		Date fecha = detEvaluacion.size()!=0?detEvaluacion.get(0).getFecEvaluacion():null;
    		String fecSolConfirmaLllegada =fecha!=null?DateUtil.dateToString(fecha,"dd/MM/yyyy"):"-";
    		String codAduanaIngreso = mapCabDeclara.get("COD_ADUDEST").toString(); //solReguReconFisico.get(0).getAduana().getCodDatacat().toString();
    		String annSolicitud = solReguReconFisico.get(0).getAnnoSolicitud().toString();
    		String codRegimen = solReguReconFisico.get(0).getRegimen().toString();
    		String numSolicitud = String.valueOf(solReguReconFisico.get(0).getNumeroSolicitud()) ;
    	 	String numSolReguReconFisico = codAduanaIngreso + "-" + annSolicitud + "-" + codRegimen + "-" + numSolicitud  ;
    	 	String fecSolReguReconFisico =solReguReconFisico.size()!=0?DateUtil.dateToString(solReguReconFisico.get(0).getFechaSolicitud(),"dd/MM/yyyy"):"-";
    	 	
    	 	DataCatalogoDAO dataCatalogoDAO = fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
			DataCatalogo dataCatalogo;
			dataCatalogo = dataCatalogoDAO.buscarDataCatalogo("525",solReguReconFisico.get(0).getEstadoSolicitud());
    	 	
    		view.addObject("fecSolConfirmaLllegada",fecSolConfirmaLllegada);
    	 	view.addObject("numSolReguReconFisico", numSolReguReconFisico);	
	    	view.addObject("fecSolReguReconFisico", fecSolReguReconFisico);	
	    	view.addObject("estSolReguReconFisico", dataCatalogo.getDesDatacat().toString());
    			}else {
    				view.addObject("fecSolConfirmaLllegada","-");	  
    		    	  view.addObject("numSolReguReconFisico", "-");	
    		    	  view.addObject("fecSolReguReconFisico", "-");	
    		    	  view.addObject("estSolReguReconFisico", "-");
    			}
    		/*---------Para Solicitudes Fin--------*/
    		
          /*---------Para las Resolucion---------*/
    		DocAutAsociadoService docAutAsociadoService = (DocAutAsociadoService) fabricaDeServicios
			        .getService("declaracion.docAutAsociadoService");
    		DatoOtroDocSoporte paramsDocAso = new DatoOtroDocSoporte();
    		
    		paramsDocAso.setNumcorredoc( ((BigDecimal) mapCabDeclara.get("NUM_CORREDOC")).longValue());
    		paramsDocAso.setCodtipodocasoc(ConstantesDataCatalogo.CODIGO_PROCESO_SOPORTE);
    		paramsDocAso.setCodtipoproceso(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOLUCION_DEVOLUCION);
    		
    		List<DatoOtroDocSoporte> docAsoDevoList = docAutAsociadoService.selectGeneral(paramsDocAso);
    		 if(docAsoDevoList.size()>0){
    			     		    			 
    			 String numResolDevolucion = docAsoDevoList.get(0).getCodigoAduanaAutoriza()+"-"+docAsoDevoList.get(0).getDesentidad()+"-"+docAsoDevoList.get(0).getAnndocasoc()+"-"+docAsoDevoList.get(0).getNumdocasoc();
    			 String fecResolDevolucion =DateUtil.dateToString(docAsoDevoList.get(0).getFecdocasoc(),"dd/MM/yyyy");
    			 
    			 view.addObject("numResolDevolucion", numResolDevolucion);
    			 view.addObject("fecResolDevolucion", fecResolDevolucion);   			 
    		 }else {
    			 view.addObject("numResolDevolucion", "-");
    			 view.addObject("fecResolDevolucion", "-");     			 
    		 }

    		 paramsDocAso.setCodtipoproceso(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOLUCION_DETERMINACION);
    		 List<DatoOtroDocSoporte> docAsoDeterList = docAutAsociadoService.selectGeneral(paramsDocAso);
    	
    		 if(docAsoDeterList.size()>0){
    			 
    			 String numResolDeterminacion =  docAsoDeterList.get(0).getCodigoAduanaAutoriza()+"-"+docAsoDeterList.get(0).getDesentidad()+"-"+docAsoDeterList.get(0).getAnndocasoc()+"-"+docAsoDeterList.get(0).getNumdocasoc();
    			 String fecResolDeterminacion = DateUtil.dateToString(docAsoDeterList.get(0).getFecdocasoc(),"dd/MM/yyyy");
    			 
    			 view.addObject("numResolDeterminacion", numResolDeterminacion);
    			 view.addObject("fecResolDeterminacion", fecResolDeterminacion);
    		 } else {   			 
    			 view.addObject("numResolDeterminacion", "-");
    			 view.addObject("fecResolDeterminacion", "-");
    		 }
    		
    			/*---------Para las Resolucion Fin---------*/

    	  //view.addObject("solicitudes",  SojoUtil.toJson(solReguReconFisico));
    	  //view.addObject("fecConfirmaLlegada", fecConfirmaLlegada);
	      view.addObject("numSolConfirmaLllegada", "-");
    	  view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
    	  view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
    	  view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
    	  view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
    	  view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
    	  mapCabDeclara = null;
        	}
        	 catch (ServiceException e) {
 				rBean = new MensajeBean();
 				rBean.setError(true);
 				rBean.setMensajeerror(e.getMessage());
 				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
 				return new ModelAndView("PagM", "beanM", rBean);
 			} catch (Exception e) {
 				rBean = new MensajeBean();
 				rBean.setError(true);
 				rBean.setMensajeerror(e.getMessage());
 				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

 				return new ModelAndView("PagM", "beanM", rBean);
 			} finally {
 			}
    	  return view;
    }
  //FIN PAS20181U220200069
  	// Inicio P46 3006
	/**
	* Metodo que obtiene los documentos autorizantes
	* 
	* @param request
	* @param response
	* @return ModelAndView
	*/
	public ModelAndView cargarConsultaDocAutorizanteDonacion(HttpServletRequest request, HttpServletResponse response) {
		ServletWebRequest webRequest = new ServletWebRequest(request);

		String acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

		List<Map<String, Object>> lstDocumentos = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> lstDocAutAsociado = null;
		List<Map<String, Object>> lstDetAutorizacion = null;

		// para deshabilitar boton de grabado del JSP
		Boolean banderaEdicionRectificacionOficio = false;
		
		String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? (String) WebUtils.getSessionAttribute(request, "tipoDiligencia") : "";
		String serieSeleccionada = webRequest.getParameter("hdn_num_secserie") != null ? (String) webRequest.getParameter("hdn_num_secserie") : "";
		
		// datos de la session
		Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
		Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
		List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");
		
		String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();
		
		// obtenemos los datos
		if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")) && !CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDetAutorizacion"))){
			lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
			lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
	    }else{ 
	    	// obtenemos de la BD
	    	Map<String, String> pkDocu = new HashMap<String, String>();
	    	pkDocu.put("NUM_CORREDOC", numCorreDoc);
//	    	pkDocu.put("COD_TIPOPER", "1"); // Se supone que eventualmente solo se mostraran tipo 1: DOCUMENTO DE DONACION
	    	
	      	Map<String, Object> mapDatos = solicitudService.obtenerDocAutoriza(pkDocu);
	      	
	      	lstDocAutAsociado = (List<Map<String, Object>>) mapDatos.get("lstDocAutAsociado");
	      	lstDetAutorizacion = (List<Map<String, Object>>) mapDatos.get("lstDetAutorizacion");
	      	// ponemos en session los datos de la BD 
	      	mapCabDeclaraAnt.put("lstDocAutAsociado", Utilidades.copiarLista((List) lstDocAutAsociado));
	      	mapCabDeclaraAnt.put("lstDetAutorizacion", Utilidades.copiarLista((List) lstDetAutorizacion));
	      	request.getSession().setAttribute("mapCabDeclara", mapCabDeclaraAnt);
	    }
		
		// Si tenemos series nuevas recogemos sus docautorizantes
		if (!SunatStringUtils.isEmpty(serieSeleccionada)) {
			// consulta por serie
			// Agregado los documentos autorizantes de Series con estado
			// IND_TIPO_REGISTRO = '1'
			Map key = new HashMap();
			key.put("NUM_CORREDOC", numCorreDoc);
			key.put("NUM_SECSERIE", serieSeleccionada);
			Map<String, Object> mapDetDeclaraSerieSeleccionada = Utilidades.obtenerElemento(lstDetDeclaraActual, key);
			
			// si la serie seleccionada esta eliminada
			// ESTADO_REGISTRO 0 REGISTRADO EN BD,
			// ESTADO_REGISTRO 1 PENDIENTE DE REGISTRO EN BD
			if (!CollectionUtils.isEmpty(mapDetDeclaraSerieSeleccionada) && SunatStringUtils.isEmpty((String) mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO"))
					&& "1".equals(mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO").toString())){
				List<Map<String, Object>> listaAdicional = (List<Map<String, Object>>) mapDetDeclaraSerieSeleccionada.get("lstDetAutorizacion");
				listaAdicional = (listaAdicional != null) ? listaAdicional : new ArrayList<Map<String, Object>>();
				lstDetAutorizacion.addAll(Utilidades.copiarLista((List) listaAdicional));
			}
			
			cargarDocumentosDonacion(serieSeleccionada, lstDetAutorizacion, lstDocAutAsociado, lstDocumentos);
		}
		
		// actualizo los datos en session de la declaracion actual
		mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
		mapCabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
		request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
		
		//ModelAndView view = new ModelAndView("ConsultaDocAutorizanteDonacionConsulta");
		ModelAndView view = null;//PAS20175E220200028
		
	    if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)) {
	    	if(banderaEdicionRectificacionOficio){ //PAS20175E220200028
            	view = new ModelAndView("ConsultaDocAutorizanteDonacion");
            }
            else{
            	view = new ModelAndView("ConsultaDocAutorizanteDonacionConsulta");
            }
	    	// para poner el titulo
	    	view.addObject("documentos", !CollectionUtils.isEmpty(lstDocumentos) ? SojoUtil.toJson(lstDocumentos) : "[]");
	    	view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
	    	view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
	    	view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
	    	view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
	    	// tambien se consulta desde la declaracion entonces este parametro es vacio o null
	    	view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));
	    	boolean esRectificacionOficio = false;
	    	if ("10".equals(tipoDiligencia)) {
	    		esRectificacionOficio = true;
	    		banderaEdicionRectificacionOficio = mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null
	    				&& "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString());
	    	}
	    	view.addObject("banderaEdicionRectificacionOficio", banderaEdicionRectificacionOficio);
            view.addObject("esRectificacionOficio", esRectificacionOficio);
	    } else {
    		banderaEdicionRectificacionOficio = mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null
    				&& "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()); //PAS20175E220200028
    		if(banderaEdicionRectificacionOficio){
    			view = new ModelAndView("ConsultaDocAutorizanteDonacion");//PAS20175E220200028
    		}
    		else{
    			view = new ModelAndView("ConsultaDocAutorizanteDonacionConsulta");//PAS20175E220200028	
    		}
	    	
	    	// Datos de formulario
	    	String documento = SojoUtil.toJson(lstDocumentos).replaceAll("null", "\"\"");
	    	
	    	boolean esRectificacionOficio = false;
	    	if ("10".equals(tipoDiligencia)) {
	    		esRectificacionOficio = true;
	    		//Ini P46-PAS20155E410000032
	    		banderaEdicionRectificacionOficio = mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null
	    				&& "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString());
	    		//Fin P46-PAS20155E410000032
	    	}
	    	
	    	view.addObject("documentos", documento);
	    	view.addObject("banderaEdicionRectificacionOficio", banderaEdicionRectificacionOficio);
	    	view.addObject("esRectificacionOficio", esRectificacionOficio);
	    	view.addObject("hdn_num_corredoc", numCorreDoc);
	    	view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
	    	view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
	    	view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
	    	view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
	    	view.addObject("hdn_num_secserie", serieSeleccionada);
	    }
	    
    	Map<String, Object> seriePk = new HashMap();
        seriePk.put("NUM_CORREDOC", numCorreDoc);
        seriePk.put("NUM_SECSERIE", serieSeleccionada);
        
    	Map<String, Object> mapaSerie = Utilidades.obtenerElemento((List<Map<String, Object>>) lstDetDeclaraActual, seriePk);
    	
    	String codigoLiberatorio = "";
    	
    	if(mapaSerie.containsKey("lstConvenioSerie") && mapaSerie.get("lstConvenioSerie") != null) {
    		List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>)mapaSerie.get("lstConvenioSerie");
    		
    		for(Map<String, Object> convenioSerie : lstConvenioSerie) {
    			if("0".equals(convenioSerie.get("IND_DEL")) && "C".equals(convenioSerie.get("COD_TIPCONVENIO"))) {
    				codigoLiberatorio = convenioSerie.get("COD_CONVENIO") == null ? "" : convenioSerie.get("COD_CONVENIO").toString();
    			}
    		}
    	}

    	view.addObject("lstTipoProceso", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("327")));
    	view.addObject("lstDocAsoc", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("75")));
    	view.addObject("lstTipoDocEntidad", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("27")));
    	view.addObject("lstCodTipoEntidad", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("334")));
    	view.addObject("codigoLiberatorio", codigoLiberatorio);
	    
	    return view;
	}
	
	/**
	 * Metodo que permite cargar la tabla que muestra los documentos autorizantes de donacion
	 * 
	 * @param serieSeleccionada
	 * @param lstDetAutorizacion
	 * @param lstDocAutAsociado
	 * @param lstACargar
	 */
	 //ini P46-PAS20155E410000032
	private void cargarDocumentosDonacion(String serieSeleccionada, List<Map<String, Object>> lstDetAutorizacion, 
			List<Map<String, Object>> lstDocAutAsociado, List<Map<String, Object>> lstACargar) {
		for (Map<String, Object> detAutorizacionTmp : lstDetAutorizacion) {
			if (mapaDocumentosContieneSerie(detAutorizacionTmp, serieSeleccionada)) {
				for (Map<String, Object> docAutAsociadoTmp : lstDocAutAsociado) {
					if (detAutorizacionTmp.get("NUM_SECDOC").toString().trim().equals(docAutAsociadoTmp.get("NUM_SECDOC").toString().trim())
							&& detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals(docAutAsociadoTmp.get("COD_TIPOPER").toString().trim())
							&& !detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals("C")
							&& !detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals("P")
							&& ("0".equals(docAutAsociadoTmp.get("IND_DEL"))
									|| ("1".equals(docAutAsociadoTmp.get("IND_DEL"))
											&& tieneClaveQueIndicaEliminacionRelacion(docAutAsociadoTmp)))){
						lstACargar.add(docAutAsociadoTmp);
					}
				}
			}
		}
	}
	
	private boolean tieneClaveQueIndicaEliminacionRelacion(Map<String, Object> docAutAsociadoTmp) {
		for(Map.Entry<String, Object> docAutAsociado : docAutAsociadoTmp.entrySet()) {
			String claveBuscada = "IND_DEL_NUM_SECDOC_";
			String claveEnDocAutAsociado = docAutAsociado.getKey();
			if(claveEnDocAutAsociado != null && claveEnDocAutAsociado.length() > claveBuscada.length()
					&& claveBuscada.equals(claveEnDocAutAsociado.substring(0, claveBuscada.length()))) {
				return true;
			}
		}
		return false;
	}
	//fin P46-PAS20155E410000032
	
	/**
	 * Metodo que permite validar y agregar temporalmente documentos autorizantes de tipo donacion
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView agregarDocAutorizanteDonacion(HttpServletRequest request, HttpServletResponse response){
		ModelAndView resultado = new ModelAndView(this.jsonView);  
		MensajeBean rBean = null;
		String resultadoValidacion = null;
	
		try{
			Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
			Map<String, Object> mapCabDeclaraOld = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");//P46-PAS20155E410000032-[jlunah] BUG 25055
			
			Map<String, Object> camposValidar = new HashMap<String, Object>();
			camposValidar.put("tipoProceso", request.getParameter("selTipoProceso"));
			camposValidar.put("tipoDocAsoc", request.getParameter("selTipDocAsoc"));
			camposValidar.put("nombreEntidadEmi", request.getParameter("txtNombreEntidad"));
			camposValidar.put("tipoDocEntidad", request.getParameter("selTipoDocEntidad"));
			camposValidar.put("numDocEntidad", request.getParameter("txtNumDocEntidad"));
			camposValidar.put("codTipoEntidad", request.getParameter("selCodTipoEntidad"));
			camposValidar.put("numDoc", request.getParameter("txtNumDoc"));
			camposValidar.put("fechaEmision", request.getParameter("txtFecEmis"));
			camposValidar.put("COD_TIPTRATMERC", mapCabDeclara.get("COD_TIPTRATMERC"));
			camposValidar.put("COD_REGIMEN", mapCabDeclara.get("COD_REGIMEN"));
			camposValidar.put("numSecSerie", request.getParameter("txtNum_secserie"));
			camposValidar.put("codigoLiberatorio", request.getParameter("codigoLiberatorio"));
			
			//INICIO PASE-153	
		
			if ("I".equals(request.getParameter("selTipoProceso"))){// Validadcion de documento de incentivo			
				resultadoValidacion =diligenciaService.validarDocAutorizanteIncentivoMigratorio(camposValidar);  
			}else{
				/*inicio P46-PAS20155E410000032-[jlunah] BUG 25055*/
				String tipoTratamientoActual = (String) mapCabDeclara.get("COD_TIPTRATMERC");
				String tipoTratamientoOld = (String) mapCabDeclaraOld.get("COD_TIPTRATMERC");
				List<Map<String,Object>> listIndicadoresDua = (List<Map<String, Object>>) mapCabDeclara.get("LIST_INDICADORES_DUA");
				boolean deTratamientoSinDonacionATratamientoConDonacion = false;
				
				
				if(!tipoTratamientoOld.equals( ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)
						&& tipoTratamientoActual.equals( ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
					for(Map indicador : listIndicadoresDua){
						if((indicador.get("COD_INDICADOR").equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL)
								|| indicador.get("COD_INDICADOR").equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL))){
							
							if(esNumericoIndicadorActivo(indicador)){
								if((Integer) indicador.get("IND_ACTIVO") == 1){
									deTratamientoSinDonacionATratamientoConDonacion = true;
								}
							}else{
								if(indicador.get("IND_ACTIVO").equals(ConstantesDataCatalogo.IND_ACTIVO)){
									deTratamientoSinDonacionATratamientoConDonacion = true;
								}
							}
							
						}
					}
				}
				
				if(deTratamientoSinDonacionATratamientoConDonacion){
					resultadoValidacion = diligenciaService.validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(camposValidar);
				}else{
			    resultadoValidacion = diligenciaService.validarDocAutorizanteDonacionDiligencia(camposValidar);
				}
				/*fin P46-PAS20155E410000032-[jlunah] BUG 25055*/
			}
			
			
			
			//FIN PASE-153
			
		} catch (Exception e) {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			
			return new ModelAndView(jsonView, "Error", rBean);
		}
		
		if("ok".equals(resultadoValidacion)){
			rBean = new MensajeBean();
			rBean.setError(false);
			resultado.addObject("Error", rBean);
			
			return resultado;
		} else {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(resultadoValidacion);
			resultado.addObject("Error", rBean);
			
			return resultado;
		}
	}
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25055*/
	private static boolean esNumericoIndicadorActivo(Map cadena){
		try {
			Integer.parseInt((String) cadena.get("IND_ACTIVO"));
			return false;
		} catch (Exception e){
			return true;
		}
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25055*/
	
	/**
	 * Metodo que permite agregar los documentos autorizantes de tipo donacion
	 * a las listas "lstDocAutAsociado" y "lstDetAutorizacion" que seran
	 * guardadas en base de datos cuando se realice la diligencia
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView guardarDocAutorizanteDonacion(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView resultado = new ModelAndView(this.jsonView);  
		MensajeBean rBean = null;
		ServletWebRequest webRequest = new ServletWebRequest(request);
		Map<String, Object> mapCabDeclara = null;
		List<Map<String, Object>> lstDocumentoAutorizanteNuevo = null;
		List<Map<String, Object>> lstDocAutAsociado = null;
		List<Map<String, Object>> lstDetAutorizacion = null;
		Integer numSecDoc = 0;
		
		try {
			lstDocumentoAutorizanteNuevo = (List<Map<String,Object>>)SojoUtil.fromJson(request.getParameter("documentosAutorizantes").toString());
			
			mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
			lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
			lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
			
			UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			for (Map<String, Object> documentoAutorizanteNuevo : lstDocumentoAutorizanteNuevo) {
				if(lstDocAutAsociado.size() > 0) {
					Ordenador.sortDesc(lstDocAutAsociado, "NUM_SECDOC", Ordenador.DESC);
					numSecDoc = Integer.parseInt(lstDocAutAsociado.get(0).get("NUM_SECDOC").toString());
				}
				
				FechaBean fechaEmision = new FechaBean(documentoAutorizanteNuevo.get("colFEmision").toString());
				
				Map<String, Object> mDocAutAsocBase = new HashMap<String, Object>();
				mDocAutAsocBase.put("NUM_CORREDOC", webRequest.getParameter("txtNum_corredoc").toString());
				mDocAutAsocBase.put("NUM_SECDOC", numSecDoc + 1);
				mDocAutAsocBase.put("COD_TIPOPER", documentoAutorizanteNuevo.get("colCodTipoProcesoDocAsoc").toString());
				mDocAutAsocBase.put("COD_TIPOPER_DESC", documentoAutorizanteNuevo.get("colTipoProcesoDocAsoc").toString());
				mDocAutAsocBase.put("COD_TIPDOCASO", documentoAutorizanteNuevo.get("colCodTipDocAsoc").toString());
				mDocAutAsocBase.put("COD_TIPDOCASO_DESC", documentoAutorizanteNuevo.get("colTipDocAsoc").toString());
				mDocAutAsocBase.put("COD_ADU_AUT", webRequest.getParameter("txt_cod_aduana").toString());
				mDocAutAsocBase.put("COD_TIPDOC", documentoAutorizanteNuevo.get("colCodTipDocEntidadEmi").toString());
				//inicio gmontoya Pase 153 2015 
				if(documentoAutorizanteNuevo.get("colCodTipoProcesoDocAsoc").equals("I")){
					mDocAutAsocBase.put("ANN_DOC", fechaEmision.getAnho());
				}else{
					mDocAutAsocBase.put("ANN_DOC", webRequest.getParameter("txt_ann_presen").toString());
				}
				//fin gmontoya Pase 153 2015
				mDocAutAsocBase.put("NUM_DOC", documentoAutorizanteNuevo.get("colNumDoc").toString());
				mDocAutAsocBase.put("COD_ENTI", documentoAutorizanteNuevo.get("colCodTipoEntidadEmi").toString());
				mDocAutAsocBase.put("COD_IDENT", documentoAutorizanteNuevo.get("colNumDocEntidadEmi").toString());
				mDocAutAsocBase.put("FEC_EMIS", fechaEmision.getTimestamp());
				mDocAutAsocBase.put("FEC_EMIS2", documentoAutorizanteNuevo.get("colFEmision").toString());
				mDocAutAsocBase.put("OBS_OBS", documentoAutorizanteNuevo.get("colEntidadEmisora").toString());
				mDocAutAsocBase.put("IND_DEL", "0");
				mDocAutAsocBase.put("COD_USUREGIS", bUsuario.getNroRegistro());
				mDocAutAsocBase.put("FEC_REGIS", new Date());
				mDocAutAsocBase.put("COD_USUMODIF", bUsuario.getNroRegistro());
				mDocAutAsocBase.put("FEC_MODIF", new Date());
				
				// inicio agregacion campos: campos que se agregan para evitar problemas con la RIN 14
				mDocAutAsocBase.put("FEC_VENC", "");
				mDocAutAsocBase.put("FEC_VENC2", "");
				// fin agregacion campos
				
				lstDocAutAsociado.add(mDocAutAsocBase);
				
				Map<String, Object> mDetAutBase = new HashMap<String, Object>();
				mDetAutBase.put("NUM_CORREDOC", webRequest.getParameter("txtNum_corredoc"));
				mDetAutBase.put("NUM_SECSERIE", webRequest.getParameter("txtNum_secserie"));
				mDetAutBase.put("NUM_SECDOC", numSecDoc + 1);
				mDetAutBase.put("IND_DEL", "0");
				mDetAutBase.put("COD_USUREGIS", bUsuario.getNroRegistro());
				mDetAutBase.put("FEC_REGIS", new Date());
				mDetAutBase.put("COD_USUMODIF", bUsuario.getNroRegistro());
				mDetAutBase.put("FEC_MODIF", new Date());
				mDetAutBase.put("COD_TIPOPER", documentoAutorizanteNuevo.get("colCodTipoProcesoDocAsoc").toString());
				
				lstDetAutorizacion.add(mDetAutBase);
			}
			
			mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
			mapCabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
			
			request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
			
			String serieSeleccionada = webRequest.getParameter("txtNum_secserie");
			
			List<Map<String, Object>> lstDocAsociadoAgregados = new ArrayList<Map<String, Object>>();
			
			cargarDocumentosDonacion(serieSeleccionada, lstDetAutorizacion, lstDocAutAsociado, lstDocAsociadoAgregados);
			
			resultado.addObject("lstDocAsociadoAgregados", SojoUtil.fromJson(SojoUtil.toJson(lstDocAsociadoAgregados)));
		} catch (Exception e) {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			
			return new ModelAndView(jsonView, "Error", rBean);
	   }
	   
	   rBean = new MensajeBean();
	   rBean.setError(false);
	   resultado.addObject("Error", rBean);
	   resultado.addObject("resultado", "ok");
	   
	   return resultado;
	}
	
	/**
	 * Metodo que permite realizar modificaciones a los documentos autorizantes de tipo donacion
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView editarDocAutorizanteDonacion(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView resultado = new ModelAndView(this.jsonView);
		MensajeBean rBean = null;
		String resultadoValidacion=""; 
		List<Map<String, Object>> lstDocAutAsociado = null;
		
		try {
			Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
			
			List<Map<String, Object>> lstDocumentoAutorizanteModificar = (List<Map<String,Object>>)SojoUtil.fromJson(request.getParameter("docAutorizanteModificar").toString());
			
			String tipoProceso = request.getParameter("selTipoProceso");
			String tipoDocAsoc = request.getParameter("selTipDocAsoc");
			String nombreEntidadEmi = request.getParameter("txtNombreEntidad");
			String tipoDocEntidad = request.getParameter("selTipoDocEntidad");
			String numDocEntidad = request.getParameter("txtNumDocEntidad");
			String codTipoEntidad = request.getParameter("selCodTipoEntidad");
			String numDoc = request.getParameter("txtNumDoc");
			String fechaEmision = request.getParameter("txtFecEmis");
			
			Map<String, Object> camposValidar = new HashMap<String, Object>();
			camposValidar.put("tipoProceso", tipoProceso);
			camposValidar.put("tipoDocAsoc", tipoDocAsoc);
			camposValidar.put("nombreEntidadEmi", nombreEntidadEmi);
			camposValidar.put("tipoDocEntidad", tipoDocEntidad);
			camposValidar.put("numDocEntidad", numDocEntidad);
			camposValidar.put("codTipoEntidad", codTipoEntidad);
			camposValidar.put("numDoc", numDoc);
			camposValidar.put("fechaEmision", fechaEmision);
			camposValidar.put("COD_TIPTRATMERC", mapCabDeclara.get("COD_TIPTRATMERC"));
			camposValidar.put("COD_REGIMEN", mapCabDeclara.get("COD_REGIMEN"));
			camposValidar.put("numSecSerie", request.getParameter("txtNum_secserie"));
			camposValidar.put("codigoLiberatorio", request.getParameter("codigoLiberatorio"));
			
			//INICIO PASE-153				
				/*INICIO-P34 PAS20165E220200126 AFMA*/
			if (("I").equals(tipoProceso))// Validadcion de documento de incentivo
            /*FIN-P34 PAS20165E220200126 AFMA*/
				resultadoValidacion =diligenciaService.validarDocAutorizanteIncentivoMigratorio(camposValidar);  
			else 
				resultadoValidacion = diligenciaService.validarDocAutorizanteDonacionDiligencia(camposValidar);
			
			//FIN PASE-153
			
			lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
	   	
			List<Map<String, Object>> listaDocumentosControlparaGrilla = new ArrayList<Map<String, Object>>();
			
			if("ok".equals(resultadoValidacion)) {
				List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
				
				List<Map<String, String>> lstTipoDocAsociado = this.catalogoAyudaService.getElementosCat("75");

				for (Map<String, Object> mapaDocAsociadoSesion : lstDocAutAsociado) {
					for (Map<String, Object> mapaDocAsociadoSeleccionado : lstDocumentoAutorizanteModificar) {
						if (mapaDocAsociadoSesion.get("NUM_SECDOC").toString().trim().equals(mapaDocAsociadoSeleccionado.get("NUM_SECDOC").toString().trim())
								&& mapaDocAsociadoSesion.get("COD_TIPOPER").toString().trim().equals(mapaDocAsociadoSeleccionado.get("COD_TIPOPER").toString().trim())) {
							String tipDocAsociadoDesc = "";
							
							for(Map<String, String> tipoDocAsociado : lstTipoDocAsociado) {
								if(tipoDocAsoc.equals(tipoDocAsociado.get("cod_datacat"))) {
									tipDocAsociadoDesc = tipoDocAsociado.get("des_corta");
									break;
								}
							}
							
							String[] arrFecEmision = fechaEmision.split("-");
							
							String fecEmis2 = arrFecEmision[2] + "/" + arrFecEmision[1] + "/" + arrFecEmision[0];
							
							FechaBean fechaEmisionBean = new FechaBean(fecEmis2);
							
							mapaDocAsociadoSesion.put("COD_TIPDOCASO_DESC", tipDocAsociadoDesc);
							mapaDocAsociadoSesion.put("COD_TIPDOCASO", tipoDocAsoc);
							mapaDocAsociadoSesion.put("OBS_OBS", nombreEntidadEmi);
							mapaDocAsociadoSesion.put("COD_TIPDOC", tipoDocEntidad);
							mapaDocAsociadoSesion.put("COD_ENTI", codTipoEntidad);
							mapaDocAsociadoSesion.put("COD_IDENT", numDocEntidad);
							mapaDocAsociadoSesion.put("NUM_DOC", numDoc);
							mapaDocAsociadoSesion.put("FEC_EMIS", fechaEmisionBean.getTimestamp());
							mapaDocAsociadoSesion.put("FEC_EMIS2", fecEmis2);
						}
					}
				}
				
				mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
				
				request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
				
				String serieSeleccionada = request.getParameter("txtNum_secserie");
				
				cargarDocumentosDonacion(serieSeleccionada, lstDetAutorizacion, lstDocAutAsociado, listaDocumentosControlparaGrilla);
			}
			
			resultado.addObject("resultado", resultadoValidacion);
			resultado.addObject("lstDocAsociadoModificados", SojoUtil.fromJson(SojoUtil.toJson(listaDocumentosControlparaGrilla)));
		} catch (Exception e) {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			
			resultado.addObject("Error", rBean);
		}
		
		rBean = new MensajeBean();
		rBean.setError(false);
		resultado.addObject("Error", rBean);
		
		return resultado;
	}
	
	/**
	 * Metodo que permite eliminar documentos autorizantes
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView eliminarDocAutorizanteDonacion(HttpServletRequest request, HttpServletResponse response){
		ModelAndView resultado = new ModelAndView(this.jsonView);
		MensajeBean rBean;
		
		try {
		         /*INICIO-P34 PAS20165E220200126 AFMA*/
			String serieSeleccionada = request.getParameter("txtNum_secserie")!=null?request.getParameter("txtNum_secserie"):"";
/*FIN-P34 PAS20165E220200126 AFMA*/
			Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
			List<Map<String, Object>> lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
			List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
			
			List<Map<String, Object>> lstDocAutAsociadoEliminar = (List<Map<String,Object>>)SojoUtil.fromJson(request.getParameter("docAutorizanteEliminar").toString());
			
			for (Map<String, Object> docAutAsociadoEliminar : lstDocAutAsociadoEliminar) {
				int numRelacionesActivas = 0;
				
				for (Map<String, Object> detAutorizacionTmp : lstDetAutorizacion) {
					if (detAutorizacionTmp.get("NUM_SECDOC").toString().trim().equals(docAutAsociadoEliminar.get("NUM_SECDOC").toString().trim())
							&& detAutorizacionTmp.get("COD_TIPOPER").toString().trim() .equals(docAutAsociadoEliminar.get("COD_TIPOPER").toString().trim())
							&& !detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals("C")
							&& !detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals("P")
							&& "0".equals(detAutorizacionTmp.get("IND_DEL").toString().trim())) {
						numRelacionesActivas++;
						
						if(mapaDocumentosContieneSerie(detAutorizacionTmp, serieSeleccionada)) {
							detAutorizacionTmp.put("IND_DEL", "1");
						}
					}
				}
				
				for (Map<String, Object> docAutAsociadoTmp : lstDocAutAsociado) {
					if (docAutAsociadoEliminar.get("NUM_SECDOC").toString().trim().equals(docAutAsociadoTmp.get("NUM_SECDOC").toString().trim())
							&& docAutAsociadoEliminar.get("COD_TIPOPER").toString().trim().equals(docAutAsociadoTmp.get("COD_TIPOPER").toString().trim())
							&& !docAutAsociadoTmp.get("COD_TIPOPER").toString().trim().equals("C")
							&& !docAutAsociadoTmp.get("COD_TIPOPER").toString().trim().equals("P")) {
						StringBuilder sbIndDel = new StringBuilder();
						sbIndDel.append("IND_DEL_");
						sbIndDel.append("NUM_SECDOC_").append(docAutAsociadoTmp.get("NUM_SECDOC").toString().trim()).append("_");
						sbIndDel.append("COD_TIPOPER_").append(docAutAsociadoTmp.get("COD_TIPOPER").toString().trim()).append("_");
						sbIndDel.append("SERIE_").append(serieSeleccionada);
						
						docAutAsociadoTmp.put(sbIndDel.toString(), "1");
						
						if(numRelacionesActivas == 1) {
							docAutAsociadoTmp.put("IND_DEL", "1");
						}
					}
				}
			}
			
			mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
			mapCabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
			request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
			
			List<Map<String, Object>> lstDocumentoAutorizanteGrilla = new ArrayList<Map<String, Object>>();
			
			cargarDocumentosDonacion(serieSeleccionada, lstDetAutorizacion, lstDocAutAsociado, lstDocumentoAutorizanteGrilla);
			
			resultado.addObject("lstDocAsociadoEliminado", SojoUtil.fromJson(SojoUtil.toJson(lstDocumentoAutorizanteGrilla)));
		} catch (Exception e) {
			rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			
			return new ModelAndView(jsonView, "Error", rBean);
		}
		
		rBean = new MensajeBean();
		rBean.setError(false);
		resultado.addObject("Error", rBean);
		resultado.addObject("resultado", "ok");
		
		return resultado;
	}
	//Fin P46 3006  
  
  /**INCIO - RIN14***/
  /**
   * Metodo que obtiene los documentos asociados y autorizantes segun sea la
   * invocacion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
	public ModelAndView cargarConsultaDocControlSerie(HttpServletRequest request, HttpServletResponse response){
    ServletWebRequest webRequest = new ServletWebRequest(request);

    String acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

    List<Map<String, Object>> listado2 = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listadoDocAsociado = null;
    List<Map<String, Object>> listadoDetAutorizacion = null;

    // para deshabilitar boton de grabado del JSP
   Boolean banderaEdicionRectificacionOficio = false;
     
   String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? (String) WebUtils.getSessionAttribute(request, "tipoDiligencia") : "";
   String serieSeleccionada = webRequest.getParameter("hdn_num_secserie") != null ? (String) webRequest.getParameter("hdn_num_secserie") : "";

    // datos de la session
   Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
   Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
   List<Map<String, Object>> lstDetDeclaraAnt = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");
   
   String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();

    
    // obtenemos los datos
    if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")) && !CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDetAutorizacion"))){
    	
      listadoDocAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
      listadoDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
      
    }else{ 
	      // obtenemos de la BD
	      Map<String, String> pkDocu = new HashMap<String, String>();
	      pkDocu.put("NUM_CORREDOC", numCorreDoc);
	      pkDocu.put("fortipoopedif", "0");// activar diferencia
	      pkDocu.put("COD_TIPOPER", "P");// P: DOCUMENTO DE AUTORIZACI�N
	      pkDocu.put("verEliminadoDocAutoriz", "1");// P: DOCUMENTO DE AUTORIZACI�N
      	  pkDocu.put("IND_DEL", "0");

      	Map<String, Object> mapDatos = solicitudService.obtenerDocAutoriza(pkDocu);

      	listadoDocAsociado = (List<Map<String, Object>>) mapDatos.get("lstDocAutAsociado");
      	listadoDetAutorizacion = (List<Map<String, Object>>) mapDatos.get("lstDetAutorizacion");
      	// ponemos en session los datos de la BD 
      	mapCabDeclaraAnt.put("lstDocAutAsociado", Utilidades.copiarLista((List) listadoDocAsociado));
      	mapCabDeclaraAnt.put("lstDetAutorizacion", Utilidades.copiarLista((List) listadoDetAutorizacion));
      	request.getSession().setAttribute("mapCabDeclara", mapCabDeclaraAnt);
    }

    // Si tenemos series nuevas recogemos sus docautorizantes
    if (!SunatStringUtils.isEmpty(serieSeleccionada)){ 
      // consulta por serie
      // Agregado los documentos autorizantes de Series con estado
      // IND_TIPO_REGISTRO = '1'
      Map key = new HashMap();
      key.put("NUM_CORREDOC", numCorreDoc);
      key.put("NUM_SECSERIE", serieSeleccionada);
      Map<String, Object> mapDetDeclaraSerieSeleccionada = Utilidades.obtenerElemento(lstDetDeclaraAnt, key);

      // si la serie seleccionada esta eliminada
      // ESTADO_REGISTRO 0 REGISTRADO EN BD,
      // ESTADO_REGISTRO 1 PENDIENTE DE REGISTRO EN BD
      if (!CollectionUtils.isEmpty(mapDetDeclaraSerieSeleccionada) && SunatStringUtils.isEmpty((String) mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO"))
          && "1".equals(mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO").toString())){

        List<Map<String, Object>> listaAdicional = (List<Map<String, Object>>) mapDetDeclaraSerieSeleccionada.get("lstDetAutorizacion");

        listaAdicional = (listaAdicional != null) ? listaAdicional : new ArrayList<Map<String, Object>>();
        listadoDetAutorizacion.addAll(Utilidades.copiarLista((List) listaAdicional));

      }

      for (Map<String, Object> mapa1 : listadoDetAutorizacion){
	    		if (mapaDocumentosContieneSerie(mapa1, serieSeleccionada)){
          for (Map<String, Object> mapa2 : listadoDocAsociado){
            if (mapa1.get("NUM_SECDOC").toString().trim().equals(mapa2.get("NUM_SECDOC").toString().trim())
                && mapa1.get("COD_TIPOPER").toString().trim().equals(mapa2.get("COD_TIPOPER").toString().trim())
                && mapa1.get("COD_TIPOPER").toString().trim().equals("P")){
            	//FCO - Cambio para mostrar la eliminacion de la relacion
	    					//mapa2.put("IND_DEL", mapa1.get("IND_DEL").toString());
	    					mapa2.put("IND_DEL_DET", mapa1.get("IND_DEL"));
                listado2.add(mapa2);
            }
          }
        }
      }

    }

    // actualizo los datos en session de la declaracion actual
    mapCabDeclara.put("lstDocAutAsociado", listadoDocAsociado);
    mapCabDeclara.put("lstDetAutorizacion", listadoDetAutorizacion);
    request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

    HashSet<Map<String, String>>  entidadesComboAuxiliar = new HashSet<Map<String,String>>();
    
	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");  
	
	List<Map<String, String>> lstEntidadCombo =  catalogoAyudaService.getListaAsociado("356",new Date());
    
    
	Iterator<Map<String, String>> listIteratorEntidad  = lstEntidadCombo.iterator();
	while (listIteratorEntidad.hasNext()) {
		  Map<String, String> entidadMapa = listIteratorEntidad.next();
		  entidadMapa.remove("cod_asoccat");
		  entidadMapa.remove("cod_estado");
		  entidadMapa.remove("cod_catalogo");
		  entidadMapa.remove("cod_catalogoasoc");
		  entidadMapa.remove("cod_datacatasoc");
		  entidadesComboAuxiliar.add(entidadMapa);  
	}
	
	  lstEntidadCombo.clear();
	  lstEntidadCombo.addAll(entidadesComboAuxiliar);
	  Collections.sort(lstEntidadCombo, new Comparator<Map<String, String>>() {
	      public int compare(final Map<String, String> o1, final Map<String, String> o2) {
	    	  return o1.get("cod_datacat").compareTo(o2.get("cod_datacat"));
	      }
	  });

    ModelAndView view = new ModelAndView("ConsultaDocControlSerie");

	    if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)){
      view.addObject("documentos", !CollectionUtils.isEmpty(listado2) ? SojoUtil.toJson(listado2) : "[]");
      view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
      view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
      view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
      view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
      view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));
      view.addObject("banderaEdicionRectificacionOficio", banderaEdicionRectificacionOficio); //p24 pase99
      view.addObject("lstEntidadCombo",SojoUtil.toJson(lstEntidadCombo));
	    } else {	    	
      // Datos de formulario
      String documento = SojoUtil.toJson(listado2).replaceAll("null", "\"\"");

	    	if ("10".equals(tipoDiligencia)){
        if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
	            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString())){
        	banderaEdicionRectificacionOficio = true;
	    		} else {
        	 banderaEdicionRectificacionOficio = false;
         }
      }
      view.addObject("lstEntidadCombo",SojoUtil.toJson(lstEntidadCombo));
      view.addObject("documentos", documento);
      view.addObject("banderaEdicionRectificacionOficio", banderaEdicionRectificacionOficio);
      view.addObject("hdn_num_corredoc", numCorreDoc);
      view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
      view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
      view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
      view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
      view.addObject("hdn_num_secserie", serieSeleccionada);
		    //gg vuce
		    view.addObject("hdn_total_series", lstDetDeclaraAnt.size());
    }
    return view;
   }  
  
  public ModelAndView cargarComboSubEntidad(HttpServletRequest request, HttpServletResponse response){
	  ModelAndView resultado = new ModelAndView(this.jsonView);
	  String codigoEntidad=request.getParameter("txtselectCodigoEntidad");
	  CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");  
	  List<Map<String, String>> lstSubEntidad =  catalogoAyudaService.getListaElementosAsoc("356", "C",codigoEntidad,new Date());
	  Collections.sort(lstSubEntidad, new Comparator<Map<String, String>>() {
	      public int compare(final Map<String, String> o1, final Map<String, String> o2) {
	    	  return o1.get("cod_datacat").compareTo(o2.get("cod_datacat"));
	      }
	  });
	  resultado.addObject("comboSubEntidad", SojoUtil.fromJson(SojoUtil.toJson(lstSubEntidad)));
	  return resultado;
  }
  
  public ModelAndView cargarComboDocumentoControl(HttpServletRequest request, HttpServletResponse response){
	  Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
	  String codigoRegimen=mapCabDeclara.get("COD_REGIMEN").toString();
	  ModelAndView resultado = new ModelAndView(this.jsonView);
	  String codigoSubEntidad=request.getParameter("txtselectCodigoSubEntidad");
	  CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");  
	  List<Map<String, String>> lstDocumentosControl =  catalogoAyudaService.getListaElementosAsoc("358", "C",codigoSubEntidad,new Date());
	  Collections.sort(lstDocumentosControl, new Comparator<Map<String, String>>() {
	      public int compare(final Map<String, String> o1, final Map<String, String> o2) {
	    	  return o1.get("cod_datacat").compareTo(o2.get("cod_datacat"));
	      }
	  });
	  
	  String entidad=codigoSubEntidad.substring(0,2);//obtener entidad
	  
	  Iterator<Map<String, String>> listIteratorDocControl  = lstDocumentosControl.iterator();
		while (listIteratorDocControl.hasNext()) {
			  Map<String, String> docControlMapa = listIteratorDocControl.next();
			  List<Map<String, String>> lstDocumentosControlAUX =  catalogoAyudaService.getListaElementosAsoc("357", "A",docControlMapa.get("cod_datacat"),new Date());
			  docControlMapa.put("COD_DOCCONTROL", lstDocumentosControlAUX.get(0).get("cod_datacat"));
			  //validacion de combo documento de control entidad 08 MTC
			  if(!SunatStringUtils.isEmptyTrim(entidad) && entidad.trim().equalsIgnoreCase("08")){
				  if(!SunatStringUtils.isEmptyTrim(codigoRegimen) && codigoRegimen.equalsIgnoreCase("10") && 
					(docControlMapa.get("cod_datacat").toString().equalsIgnoreCase("02") || docControlMapa.get("cod_datacat").toString().equalsIgnoreCase("03"))){
					  listIteratorDocControl.remove();
				  }else if(!SunatStringUtils.isEmptyTrim(codigoRegimen) && (codigoRegimen.equalsIgnoreCase("20") || codigoRegimen.equalsIgnoreCase("21"))
						  &&(docControlMapa.get("cod_datacat").toString().equalsIgnoreCase("01") || docControlMapa.get("cod_datacat").toString().equalsIgnoreCase("03"))){
					  listIteratorDocControl.remove();
				  }
			  }  
		}
	  resultado.addObject("comboDocControl", SojoUtil.fromJson(SojoUtil.toJson(lstDocumentosControl)));
	  return resultado;
  }
    
  public ModelAndView validarDocumentosControlAutorizantes(HttpServletRequest request, HttpServletResponse response){
	  ModelAndView resultado=new ModelAndView(this.jsonView);  
	  MensajeBean rBean = null;
	  String errorValidacion=null;
	  String fechaEmision = "";
	  String fechaVencimiento = "";
	  String codDocumentoControl = "";
	  boolean existeWarning = false;
	  String msgWarning = "";
	  try{
		  String codigoEntidad=request.getParameter("txtselectEntidad");
		  String codigoSubEntidad=request.getParameter("txtselectSubEntidad");
		  String codigoSubDocumentoControl=request.getParameter("txtselectDocControl");
		  String numeroDocumento=request.getParameter("txt_numeroDocumento");
		  fechaEmision=request.getParameter("txt_fechaEmision");
		  fechaVencimiento=request.getParameter("txt_fecVencimiento");
		  String num_corredoc=request.getParameter("txt_num_corredoc");
		  String cod_regimen=request.getParameter("txt_cod_regimen");
		  String serie=  request.getParameter("txt_num_secserie");
		  String cod_Aduana = request.getParameter("txt_cod_aduana"); 
		 
		  Date fechaInicioVuce=null;
		  Date fechaFinVuce= null;
		  
		  Map variablesValidacion = new HashMap();
		  variablesValidacion.put("codigoEntidad", codigoEntidad);
		  variablesValidacion.put("codigoSubEntidad", codigoSubEntidad);
		  if(!SunatStringUtils.isEmptyTrim(codigoSubDocumentoControl)){
			  List<Map<String, String>> tipoDocumentoControl =  catalogoAyudaService.getListaElementosAsoc("357", "A",codigoSubDocumentoControl,new Date());
			  variablesValidacion.put("codigoDocumentoControl", tipoDocumentoControl.get(0).get("cod_datacat"));
			  codDocumentoControl =  tipoDocumentoControl.get(0).get("cod_datacat");
		  }else{
			  variablesValidacion.put("codigoDocumentoControl","");
		  }
		  variablesValidacion.put("numeroDocumento", numeroDocumento);
		  variablesValidacion.put("fechaEmision", fechaEmision);
		  variablesValidacion.put("fechaVencimiento", fechaVencimiento);
		  variablesValidacion.put("num_corredoc", num_corredoc);
		  variablesValidacion.put("codRegimen", cod_regimen);
		  
		  errorValidacion=diligenciaService.validarDocumentosControlAutorizantes(variablesValidacion);
		  if(errorValidacion.trim().equalsIgnoreCase("ok") && !SunatStringUtils.isEmptyTrim(codDocumentoControl)){
			  if(codDocumentoControl.equals("21") || codDocumentoControl.equals("20") ){
				  DocControlMercRestringidaVuce docControlMercRestringidaVuce = new DocControlMercRestringidaVuce();
				  Date fechaReferencia = SunatDateUtils.getCurrentDate();		 
				  String codConvenio21 = "";
				  String regPrecedente70 =  "";
				  String num_declaracion = "";
				  String tipoDocumConsigNumeracion = "";
				  String numeDocumConsigNumeracion = "";
				    Map<String, Object> params = new HashMap<String, Object>();
				    params.put("NUM_CORREDOC", request.getParameter("txt_num_corredoc"));
				    params.put("NUM_SECSERIE", request.getParameter("txt_num_secserie"));
				    List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
				    Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);
				    String numPartida = detDeclaraViewMap.get("NUM_PARTNANDI")!=null?detDeclaraViewMap.get("NUM_PARTNANDI").toString():"";
					Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
					// Date fechaReferencia = (Date) mapCabDeclaraActual.get("FEC_DECLARACION");//se ajusta por bugs reportados de vigencia para dilig
					num_declaracion =  mapCabDeclaraActual.get("NUM_DECLARACION").toString();
					tipoDocumConsigNumeracion =  mapCabDeclaraActual.get("COD_TIPDOC_PIM").toString();
					numeDocumConsigNumeracion =  mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString(); //mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM").toString();
				          		
				   List<Map> lstConvenio = (List) detDeclaraViewMap.get("lstConvenioSerie"); 
			        if (!CollectionUtils.isEmpty(lstConvenio))
			        {
			        	for (Map mapCC : lstConvenio) { 
			        		Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;
			        		if (ind_del.equals(0)) {
				        		String tipoConvenio = mapCC.get("COD_TIPCONVENIO").toString();
				        		if(mapCC.get("COD_CONVENIO")!=null && mapCC.get("COD_CONVENIO").equals("21")){
				        			codConvenio21 = mapCC.get("COD_CONVENIO").toString().trim();
				        			break;
				        		}
			        		}
			        	}
			        }
			        if (!CollectionUtils.isEmpty(detDeclaraViewMap.get("lstDocuPreceDua")!=null?(List)detDeclaraViewMap.get("lstDocuPreceDua"): new ArrayList())){
			        	List<Map<String,Object>> lstDocuPreceDua = (ArrayList<Map<String,Object>>) detDeclaraViewMap.get("lstDocuPreceDua")==null ? new ArrayList<Map<String,Object>>() : (ArrayList<Map<String,Object>>) detDeclaraViewMap.get("lstDocuPreceDua") ;
						for(Map<String,Object> docuPreceDua: lstDocuPreceDua){
  						  if(SunatStringUtils.toStringObj(docuPreceDua.get("NUM_SECSERIE")).trim().equals(serie) &&
  								  SunatStringUtils.toStringObj(docuPreceDua.get("NUM_CORREDOC")).trim().equals(num_corredoc) &&
  								  SunatStringUtils.toStringObj(docuPreceDua.get("COD_REGIMENPRE")).trim().equals("70") &&
  								  SunatStringUtils.toStringObj(docuPreceDua.get("IND_DEL")).trim().equals("0")){
  							regPrecedente70= SunatStringUtils.toStringObj(docuPreceDua.get("COD_REGIMENPRE")).trim();
  							break;
  						  }
  				      }
			        }
			        		
				    
			  Map<String,Object> map = new HashMap();
		      map.put("regPrecedente70", regPrecedente70);
		      map.put("mercanciaSpn", numPartida);
		      map.put("numeroDocumentoVuce", numeroDocumento);
		      map.put("codigoEntidad", codigoEntidad);
		      map.put("codigoSubEntidad", codigoSubEntidad);
		      map.put("tipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		      map.put("tipoDocumConsigNumeracion", tipoDocumConsigNumeracion);
		      map.put("numeDocumConsigNumeracion", numeDocumConsigNumeracion);
		      map.put("mercanciaTPN21", codConvenio21);
		      map.put("codAduana", cod_Aduana);
		      map.put("numeroDeclaracion", num_declaracion);
		      map.put("fechaReferencia", fechaReferencia);
		      map.put("codRegimen",cod_regimen );//adicionado por P_SNADE046-1917
		      map.put("numCorredocDAM",num_corredoc);//P_SNADE046-2132
		      MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");
		      List<Map<String,String>> error =  mercanciaRestringidaEntidadService.validarGeneralVuce(codDocumentoControl, serie, map);
		      
		      List<Map<String,String>> warning  = new ArrayList<Map<String,String>>();
		      List<Map<String,String>> error2  = new ArrayList<Map<String,String>>();
		    
		    	if(!CollectionUtils.isEmpty(error) ){
		    		
		    		
		    		
		    		for (Map<String, String> mapaDocControl : error) {
		    			
		    			if(SunatStringUtils.isStringInList(mapaDocControl.get("codError"), "35720,35721,35725,35727")){
		    				warning.add(mapaDocControl);
		    			}else{
		    				error2.add(mapaDocControl);
		    			}
		    			
		    		}
		    		
		    		if(CollectionUtils.isEmpty(error2) && !CollectionUtils.isEmpty(warning)){
		    			msgWarning = warning.get(0).get("desError");
		    			existeWarning = true;
		    			if (map.get("docControlMercRestringidaVuce")!=null){
			    			
				    		  docControlMercRestringidaVuce = (DocControlMercRestringidaVuce) map.get("docControlMercRestringidaVuce");
				    		 //fechaInicioVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaInicioVigenciaVuce(),"dd/MM/yyyy");
				 			 // fechaFinVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaFinVigenciaVuce(),"dd/MM/yyyy");
                            if (docControlMercRestringidaVuce.getTipo().equals(Constantes.COD_TIPO_DOCUMENTO_SUCE)){
                                fechaEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaDocumento(), "dd/MM/yyyy");
                            } else {
                                fechaEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaInicioVigencia(), "dd/MM/yyyy");
                            }

				    		 fechaVencimiento=SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaFinVigencia(), "dd/MM/yyyy");
				    	}
		    		}else{		    		
		    		errorValidacion = error2.get(0).get("desError");
		    		}
		    	}else{
		    		if (map.get("docControlMercRestringidaVuce")!=null){
		    			
		    		  docControlMercRestringidaVuce = (DocControlMercRestringidaVuce) map.get("docControlMercRestringidaVuce");
		    		 //fechaInicioVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaInicioVigenciaVuce(),"dd/MM/yyyy");
		 			 // fechaFinVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaFinVigenciaVuce(),"dd/MM/yyyy");
                        if (docControlMercRestringidaVuce.getTipo().equals(Constantes.COD_TIPO_DOCUMENTO_SUCE)){
                            fechaEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaDocumento(), "dd/MM/yyyy");
                        } else {
                            fechaEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaInicioVigencia(), "dd/MM/yyyy");
                        }
		    		 fechaVencimiento=SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaFinVigencia(), "dd/MM/yyyy");
		    		}
		    	}	  
		    		 
		   }
		  }
		  
		 //List<Map<String,String>> error = mercanciaRestringidaEntidadService.validarg
		  
		  }catch (ServiceException e){
		    rBean = new MensajeBean();
		    rBean.setError(true);
		    rBean.setMensajeerror(e.getMessage());
		    rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
		    log.error("*** ERROR ***", e);
		    return new ModelAndView(jsonView, "Error", rBean);
		  }catch (Exception e){
		    rBean = new MensajeBean();
		    rBean.setError(true);
		    rBean.setMensajeerror(e.getMessage());
		    rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
		    log.error("*** ERROR ***", e);
		    return new ModelAndView(jsonView, "Error", rBean);
		  }
	  
		  if(errorValidacion.trim().equalsIgnoreCase("ok")){
			  rBean = new MensajeBean();
			  rBean.setError(false);
			  
			  if(!msgWarning.equals("")){
			  rBean.setMensajeerror(msgWarning);
			  }
			  //resultado.addObject("codDocumentoControl", codDocumentoControl);
			  resultado.addObject("Error", rBean);
			  resultado.addObject("existeWarning", existeWarning);
			  resultado.addObject("fechaEmision", fechaEmision);
			  resultado.addObject("fechaVencimiento", fechaVencimiento);
			  return resultado;
		  }else{
			  rBean = new MensajeBean();
			  rBean.setError(true);
			  rBean.setMensajeerror(errorValidacion);
			  resultado.addObject("Error", rBean);
			  return resultado;
		  }
  
  }
  
  	//gg vuce
  	public ModelAndView copiarDocumentoControlAutorizanteSession(HttpServletRequest request, 
  			HttpServletResponse response){
	ModelAndView resultado=new ModelAndView(this.jsonView);  
    MensajeBean rBean = null;
  		List<Map<String, Object>> lstDetAutorizacionACopiar = new ArrayList<Map<String,Object>>();

  		try{
	  		Long numCorreDoc = Long.parseLong(request.getParameter("numCorreDoc"));
	  		Integer numSecDoc = Integer.parseInt(request.getParameter("numSecDoc"));
	  		String codTipOper = request.getParameter("codTipOper");
			List<Long> lstSeriesCopiar = (List<Long>) SojoUtil
					.fromJson(request.getParameter("txtSeries").toString());  		
			Map<String, Object> cabDeclara = (Map<String, Object>) 
					request.getSession().getAttribute("mapCabDeclaraActual");
			List<Map<String, Object>> lstDetAux = (List<Map<String, Object>>) 
					cabDeclara.get("lstDetAutorizacion");		
			List<Map<String, Object>> lstDetAut = new ArrayList<Map<String, Object>>();
			lstDetAut = lstDetAux == null ? new ArrayList<Map<String, Object>>() : 
				Utilidades.copiarLista((List) lstDetAux);
      
			lstDetAutorizacionACopiar = diligenciaService.
					obtenerDocumentoControlAutorizanteSerieACopiar(numCorreDoc, numSecDoc, 
							codTipOper, lstSeriesCopiar);
      
			retirarDocumentosACopiarYaExistentes(lstDetAut, lstDetAutorizacionACopiar);
    	  
			lstDetAut.addAll(lstDetAutorizacionACopiar);

			cabDeclara.put("lstDetAutorizacion", lstDetAut);
		    request.getSession().setAttribute("mapCabDeclaraActual", cabDeclara);

  		} catch (Exception e) {
  			rBean = getMensajeBean(true, e.getMessage(), "Ocurri� un error, por favor vuelva a "
  					+ "intentarlo. De continuar el error comuniquese con el Administrador.");	      
  			log.error("*** copiarDocumentoControlAutorizanteSession Exception ***", e);
  			return new ModelAndView(jsonView, "Error", rBean);
            }
	    rBean = new MensajeBean();
	    rBean.setError(false);
	    resultado.addObject("Error", rBean);
	    resultado.addObject("resultado", "ok");
	    resultado.addObject("seriesConDocCopiado", diligenciaService.obtenerSeriesConCopiaDocAut(
	    		lstDetAutorizacionACopiar));
          
	    return resultado;
  	}
          
	private void retirarDocumentosACopiarYaExistentes(List<Map<String, Object>> lstDetAut,
			List<Map<String, Object>> lstDetAutorizacionACopiar) {
		for (Iterator<Map<String, Object>> iterator = lstDetAutorizacionACopiar.iterator(); 
				iterator.hasNext();) {
			Map<String, Object> detAutCopyMap = iterator.next();
			Long numSecSerie = (Long)detAutCopyMap.get("NUM_SECSERIE");
			for (Map<String, Object> detAutMap : lstDetAut){
				if (mapaDocumentosContieneSerie(detAutMap, numSecSerie.toString())){
					if (detDocAutAsociadoExisteSinFiltro(detAutMap, detAutCopyMap)){
						iterator.remove();
						break;
					}
				}
			}	    		
		}
          }
          
  	//gg vuce
  	public ModelAndView agregarDocumentoControlAutorizanteSession(HttpServletRequest request, 
  			HttpServletResponse response){
  		ModelAndView resultado=new ModelAndView(this.jsonView);  
  		MensajeBean rBean = null;
	    Map<String, Object> cabDeclara = null;
	    List<Map<String, Object>> lstDocControlAutNew = null;
	    List<Map<String, Object>> lstDocAutAsociado = new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> lstDetAutorizacion = new ArrayList<Map<String, Object>>();;
	    List<Map<String, Object>> lstDocControlGrilla = new ArrayList<Map<String, Object>>();
	    Map<String, Object> detAutNew;
	    Map<String, Object> docAutNew;
	    Integer numSecDoc=0;
	         
	    try {
	    	String serieSeleccionada = request.getParameter("txt_num_secserie");
			lstDocControlAutNew = (List<Map<String, Object>>) SojoUtil
					.fromJson(request.getParameter("documentoAutorizantes").toString());

	    	cabDeclara = (Map<String, Object>) request.getSession().
	    			getAttribute("mapCabDeclaraActual");
	    	List<Map<String, Object>> lstDocAutAsociadoAux=(List<Map<String, Object>>) 
	    			cabDeclara.get("lstDocAutAsociado");
	    	lstDocAutAsociado = CollectionUtils.isEmpty(lstDocAutAsociadoAux) ?
	    			new ArrayList<Map<String, Object>>() : 
	    				Utilidades.copiarLista((List) lstDocAutAsociadoAux);	      
	    	List<Map<String, Object>> lstDetAutorizacionAux=(List<Map<String, Object>>) 
	    			cabDeclara.get("lstDetAutorizacion");
	    	lstDetAutorizacion= CollectionUtils.isEmpty(lstDetAutorizacionAux) ?
	    			new ArrayList<Map<String, Object>>() :
	    				Utilidades.copiarLista((List) lstDetAutorizacionAux);

	    	for (Map<String, Object> mapaDocControl : lstDocControlAutNew) {
	    		if(!CollectionUtils.isEmpty(lstDocAutAsociado)){
	    			Ordenador.sortDesc(lstDocAutAsociado, "NUM_SECDOC", Ordenador.DESC);
	    			numSecDoc=Integer.parseInt(lstDocAutAsociado.get(0).get("NUM_SECDOC").
	    					toString());
	    		}	    	  
	    		docAutNew = new HashMap<String, Object>();
	    		docAutNew.put("NUM_CORREDOC", request.getParameter("txt_num_corredoc").toString());
	    		docAutNew.put("NUM_SECDOC", numSecDoc+1);
	    		docAutNew.put("COD_TIPOPER","P");
	    		docAutNew.put("COD_TIPDOCASO",mapaDocControl.get("codTipoDocumento").toString());
	    		docAutNew.put("COD_ADU_AUT", request.getParameter("txt_cod_aduana").toString());
				docAutNew.put("ANN_DOC", request.getParameter("txt_ann_presen").toString());
				docAutNew.put("NUM_DOC", mapaDocControl.get("colDocumento").toString());
				docAutNew.put("COD_ENTI", mapaDocControl.get("colCodEntidad").toString());
				docAutNew.put("COD_ENTI_DESC", mapaDocControl.get("colEntidad").toString());
				FechaBean fechaEmision=new FechaBean(mapaDocControl.get("colFEmision").toString());	          
	          	docAutNew.put("FEC_EMIS", fechaEmision.getTimestamp());
				if(!mapaDocControl.get("colFVencimiento").toString().equalsIgnoreCase("")){
	          		FechaBean fechaVencimiento=new FechaBean(
	          				mapaDocControl.get("colFVencimiento").toString());
	          		docAutNew.put("FEC_VENC",fechaVencimiento.getTimestamp());
	          		docAutNew.put("FEC_VENC2", mapaDocControl.get("colFVencimiento").toString());
	          	} else {
	          		docAutNew.put("FEC_VENC", "");
	          		docAutNew.put("FEC_VENC2", "");
           }
	          	docAutNew.put("FEC_EMIS2", mapaDocControl.get("colFEmision").toString());
	          	docAutNew.put("OBS_OBS", mapaDocControl.get("colEntidad").toString());
	          	docAutNew.put("IND_DEL", Constantes.IND_REGISTRO_ACTIVO);
				docAutNew.put("IND_CUSTODIA", "");
				docAutNew.put("COD_SUBENTI", mapaDocControl.get("colCodSubEntidad").toString());              
	          	docAutNew.put("COD_SUBTIPODOC",mapaDocControl.get("colCodSubDocumento").toString());
	          	docAutNew.put("NUM_ITEMDOC","0");      
				docAutNew.put("COD_TIPODOCAUTORIZANTE_DESC", 
	          			mapaDocControl.get("colCodigoDocumentoControl").toString());	          
	          	lstDocAutAsociado.add(docAutNew);	         
		
	          	detAutNew = new HashMap<String, Object>();
	          	detAutNew.put("NUM_CORREDOC", request.getParameter("txt_num_corredoc"));
	            detAutNew.put("NUM_SECSERIE", serieSeleccionada);
	            detAutNew.put("NUM_SECDOC", numSecDoc+1);
	            detAutNew.put("IND_DEL", Constantes.IND_REGISTRO_ACTIVO);
	            detAutNew.put("COD_TIPOPER", "P");          
	            lstDetAutorizacion.add(detAutNew);
      }
      
	    	cabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
	    	cabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
	    	request.getSession().setAttribute("mapCabDeclaraActual", cabDeclara);
      
	    	for (Map<String, Object> detAutMap : lstDetAutorizacion){
	    		if (mapaDocumentosContieneSerie(detAutMap, serieSeleccionada)){
	    			for (Map<String, Object> docAutMap : lstDocAutAsociado){
	    				if (detDocAutAsociadoExiste(detAutMap, docAutMap)){
	    					lstDocControlGrilla.add(docAutMap);
            }
          }
        }
      }
	    	resultado.addObject("lstDocAsociadoAgregados", 
	    			SojoUtil.fromJson(SojoUtil.toJson(lstDocControlGrilla)));
	    } catch (ServiceException e) {
	    	rBean = getMensajeBean(true, e.getMessage(), "Ocurri� un error, por favor vuelva a "
	    			+ "intentarlo. De continuar el error comuniquese con el Administrador.");
	    	log.error("*** agregarDocumentoControlAutorizanteSession ServiceException ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
	    } catch (Exception e) {
	    	rBean = getMensajeBean(true, e.getMessage(), "Ocurri� un error, por favor vuelva a "
	    			+ "intentarlo. De continuar el error comuniquese con el Administrador.");
	    	log.error("*** agregarDocumentoControlAutorizanteSession Exception ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    rBean = new MensajeBean();
    rBean.setError(false);
    resultado.addObject("Error", rBean);
    resultado.addObject("resultado", "ok");
    return resultado;
  }
  
	private boolean detDocAutAsociadoExiste(Map<String, Object> detSerieAutMap,
			Map<String, Object> docAutMap) {
		return (detSerieAutMap.get("NUM_SECDOC").toString().trim().equals(
				docAutMap.get("NUM_SECDOC").toString().trim()) && 
				detSerieAutMap.get("COD_TIPOPER").toString().trim().equals(
				docAutMap.get("COD_TIPOPER").toString().trim()) && 
				!detSerieAutMap.get("COD_TIPOPER").toString().trim().equals("C"));
	}
	
	private boolean detDocAutAsociadoExisteSinFiltro(Map<String, Object> detSerieAutMap,
			Map<String, Object> docAutMap) {
		return (detSerieAutMap.get("NUM_SECDOC").toString().trim().equals(
				docAutMap.get("NUM_SECDOC").toString().trim()) && 
				detSerieAutMap.get("COD_TIPOPER").toString().trim().equals(
				docAutMap.get("COD_TIPOPER").toString().trim()));
	}
	
	private boolean mapaDocumentosContieneSerie(Map<String, Object> detAut, String serie) {
		return serie.equals(detAut.get("NUM_SECSERIE").toString().trim());
	}
  	
  	//gg vuce
  	private MensajeBean getMensajeBean(boolean isError, String msgError, String msgSol){
  		MensajeBean msgBean = new MensajeBean();
  		msgBean.setError(isError);
  		msgBean.setMensajeerror(msgError);
  		msgBean.setMensajesol(msgSol);
  		return msgBean;
  		
  	}
  
  public ModelAndView modificarDocumentoControlAutorizanteSession(HttpServletRequest request, HttpServletResponse response)
  {
	ModelAndView resultado=new ModelAndView(this.jsonView);
    MensajeBean rBean = null;
    Map<String, Object> mapCabDeclara = null;
    List<Map<String, Object>> lstDocAutAsociado=null;
    List<Map<String, Object>> lstDetAutorizacion=null;
    List<Map<String, Object>> lstDocumentoControlAutorizantesModificar = null;
    List<Map<String, Object>> listaDocumentosControlparaGrilla = new ArrayList<Map<String, Object>>();
    boolean existeWarning = false;
    String fechEmision = "";
	String fechVencimiento = "";
	  String msgWarning = "";
    try
    {
    	lstDocumentoControlAutorizantesModificar=(List<Map<String,Object>>)SojoUtil.fromJson(request.getParameter("docControlModificar").toString());
    	
    	String serieSeleccionada = request.getParameter("txt_edit_num_secserie");
    	String txtSelectEntidadEditar=request.getParameter("txt_selectEntidadEditar");
    	String txtSelectSubEntidadEditar=request.getParameter("txt_selectSubEntidadEditar");
    	String txtSelectTipoDocumentoEditar=request.getParameter("txt_selectTipoDocumentoEditar");
    	String txtEditarNumDocumento=request.getParameter("txtEditarNumDocumento");
    	String txtEditarFecEmision=request.getParameter("txtEditarFecEmision");
    	String txtEditarFecVencimiento=request.getParameter("txtEditarFecVencimiento");
    	String txtEditarNumCorredoc=request.getParameter("txt_edit_num_corredoc");
    	String txtEditarCodRegimen=request.getParameter("txt_edit_cod_regimen");
    	String descripcionDocumentoControl=request.getParameter("selectTipoDocumentoEditar");
    	//String descripcionSubEntidad=request.getParameter("selectSubEntidadEditar");
    	String descripcionEntidad=request.getParameter("selectEntidadEditar");
    	
    	Map variablesValidacion = new HashMap();
	  	variablesValidacion.put("codigoEntidad", txtSelectEntidadEditar);
	  	variablesValidacion.put("codigoSubEntidad", txtSelectSubEntidadEditar);
	  	variablesValidacion.put("codigoDocumentoControl", txtSelectTipoDocumentoEditar);
	  	variablesValidacion.put("numeroDocumento", txtEditarNumDocumento);
	  	variablesValidacion.put("fechaEmision", txtEditarFecEmision);
	  	variablesValidacion.put("fechaVencimiento", txtEditarFecVencimiento);
	  	variablesValidacion.put("num_corredoc", txtEditarNumCorredoc);
	  	variablesValidacion.put("codRegimen", txtEditarCodRegimen);
	  	String codDocumentoControl= "";
	    if(!SunatStringUtils.isEmptyTrim(txtSelectTipoDocumentoEditar)){
			  List<Map<String, String>> tipoDocumentoControl =  catalogoAyudaService.getListaElementosAsoc("357", "A",txtSelectTipoDocumentoEditar,new Date());
			  variablesValidacion.put("codigoDocumentoControl", tipoDocumentoControl.get(0).get("cod_datacat"));
			  codDocumentoControl =  tipoDocumentoControl.get(0).get("cod_datacat");
		  }else{
			  variablesValidacion.put("codigoDocumentoControl","");
		  }
	  	
  	  
  	  String errorValidacion=diligenciaService.validarDocumentosControlAutorizantes(variablesValidacion);
  	  mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      List<Map<String, Object>> lstDocAutAsociadoAux=(List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
	  lstDocAutAsociado = new ArrayList<Map<String, Object>>();
	  lstDocAutAsociado= Utilidades.copiarLista((List) lstDocAutAsociadoAux) == null ? new ArrayList<Map<String, Object>>() : Utilidades.copiarLista((List) lstDocAutAsociadoAux);	      
	  List<Map<String, Object>> lstDetAutorizacionAux=(List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
	  lstDetAutorizacion = new ArrayList<Map<String, Object>>();
	  lstDetAutorizacion= Utilidades.copiarLista((List) lstDetAutorizacionAux) == null ? new ArrayList<Map<String, Object>>() : Utilidades.copiarLista((List) lstDetAutorizacionAux);	
	  if(errorValidacion.trim().equalsIgnoreCase("ok") && !SunatStringUtils.isEmptyTrim(txtEditarNumDocumento)){
		  
		//  String codDocumentoControl= "";
//		  if(!SunatStringUtils.isEmptyTrim(txtSelectTipoDocumentoEditar)){
//			  List<Map<String, String>> tipoDocumentoControl =  catalogoAyudaService.getListaElementosAsoc("357", "A",txtSelectTipoDocumentoEditar,new Date());
//			  variablesValidacion.put("codigoDocumentoControl", tipoDocumentoControl.get(0).get("cod_datacat"));
//			  codDocumentoControl =  tipoDocumentoControl.get(0).get("cod_datacat");
//		  }else{
//			  variablesValidacion.put("codigoDocumentoControl","");
//		  }
		  if(codDocumentoControl.equals("21") || codDocumentoControl.equals("20") ){
			  DocControlMercRestringidaVuce docControlMercRestringidaVuce = new DocControlMercRestringidaVuce();
			  Date fechaReferencia = SunatDateUtils.getCurrentDate();
			  String codConvenio21 = "";
			  String regPrecedente70 =  "";
			  String num_declaracion = ""; 
			  String tipoDocumConsigNumeracion = "";
			  String numeDocumConsigNumeracion = "";
			    Map<String, Object> params = new HashMap<String, Object>();
			    params.put("NUM_CORREDOC", request.getParameter("txt_edit_num_corredoc"));
			    params.put("NUM_SECSERIE", request.getParameter("txt_edit_num_secserie"));
			    List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
			    Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);
			    String numPartida = detDeclaraViewMap.get("NUM_PARTNANDI")!=null?detDeclaraViewMap.get("NUM_PARTNANDI").toString():"";
				Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
				//Date fechaReferencia = (Date) mapCabDeclaraActual.get("FEC_DECLARACION");//se cambia por bugs referidos a las vigencias
				num_declaracion =  mapCabDeclaraActual.get("NUM_DECLARACION").toString();
				tipoDocumConsigNumeracion =  mapCabDeclaraActual.get("COD_TIPDOC_PIM").toString();
				numeDocumConsigNumeracion =  mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString(); //mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM").toString();
			          		
			   List<Map> lstConvenio = (List) detDeclaraViewMap.get("lstConvenioSerie"); 
		        if (!CollectionUtils.isEmpty(lstConvenio))
		        {
		        	for (Map mapCC : lstConvenio) { 
		        		Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;
		        		if (ind_del.equals(0)) {
			        		String tipoConvenio = mapCC.get("COD_TIPCONVENIO").toString();
			        		if(mapCC.get("COD_CONVENIO")!=null && mapCC.get("COD_CONVENIO").equals("21")){
			        			codConvenio21 = mapCC.get("COD_CONVENIO").toString().trim();
			        			break;
			        		}
		        		}
		        	}
		        }
		        if (!CollectionUtils.isEmpty(detDeclaraViewMap.get("lstDocuPreceDua")!=null?(List)detDeclaraViewMap.get("lstDocuPreceDua"): new ArrayList())){
		        	List<Map<String,Object>> lstDocuPreceDua = (ArrayList<Map<String,Object>>) detDeclaraViewMap.get("lstDocuPreceDua")==null ? new ArrayList<Map<String,Object>>() : (ArrayList<Map<String,Object>>) detDeclaraViewMap.get("lstDocuPreceDua") ;
					for(Map<String,Object> docuPreceDua: lstDocuPreceDua){
						  if(SunatStringUtils.toStringObj(docuPreceDua.get("NUM_SECSERIE")).trim().equals(request.getParameter("txt_edit_num_secserie")) &&
								  SunatStringUtils.toStringObj(docuPreceDua.get("NUM_CORREDOC")).trim().equals(request.getParameter("txt_edit_num_corredoc")) &&
								  SunatStringUtils.toStringObj(docuPreceDua.get("COD_REGIMENPRE")).trim().equals("70") &&
								  SunatStringUtils.toStringObj(docuPreceDua.get("IND_DEL")).trim().equals("0")){
							regPrecedente70= SunatStringUtils.toStringObj(docuPreceDua.get("COD_REGIMENPRE")).trim();
							break;
						  }
				      }
		        }
		        		
			    
		  Map<String,Object> map = new HashMap();
	      map.put("regPrecedente70", regPrecedente70);
	      map.put("mercanciaSpn", numPartida);
	      map.put("numeroDocumentoVuce", txtEditarNumDocumento);
	      map.put("codigoEntidad", txtSelectEntidadEditar);
	      map.put("codigoSubEntidad", txtSelectSubEntidadEditar);
	      map.put("tipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
	      map.put("tipoDocumConsigNumeracion", tipoDocumConsigNumeracion);
	      map.put("numeDocumConsigNumeracion", numeDocumConsigNumeracion);
	      map.put("mercanciaTPN21", codConvenio21);
	      map.put("codAduana", request.getParameter("txt_edit_cod_aduana"));
	      map.put("numeroDeclaracion", num_declaracion);
	      map.put("fechaReferencia", fechaReferencia);
	      map.put("codRegimen",txtEditarCodRegimen );//adicionado por P_SNADE046-1917
	      map.put("numCorredocDAM",txtEditarNumCorredoc);//P_SNADE046-2132
	      MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");
	      List<Map<String,String>> error =  mercanciaRestringidaEntidadService.validarGeneralVuce(codDocumentoControl, request.getParameter("txt_edit_num_secserie"), map);
	      List<Map<String,String>> warning  = new ArrayList<Map<String,String>>();
	      List<Map<String,String>> error2  = new ArrayList<Map<String,String>>();
	      if(!CollectionUtils.isEmpty(error) ){
	    	  
	    	  for (Map<String, String> mapaDocControl : error) {
	    			
	    			if(SunatStringUtils.isStringInList(mapaDocControl.get("codError"), "35720,35721,35725,35727")){
	    				warning.add(mapaDocControl);
	    			}else{
	    				error2.add(mapaDocControl);
	    			}
	    			
	    		}
	    		
	    	  if(CollectionUtils.isEmpty(error2) && !CollectionUtils.isEmpty(warning)){
	    		  msgWarning = warning.get(0).get("desError");
	    			existeWarning = true;
	    			if (map.get("docControlMercRestringidaVuce")!=null){
		    			
	    				  docControlMercRestringidaVuce = (DocControlMercRestringidaVuce) map.get("docControlMercRestringidaVuce");
	    				  fechEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaInicioVigencia(), "dd/MM/yyyy");
	    				  fechVencimiento=SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaFinVigencia(), "dd/MM/yyyy");
			    	}
	    		}else{		   		
	    		errorValidacion = error2.get(0).get("desError");
	    		}
	    		
	    	}else{
	    		if (map.get("docControlMercRestringidaVuce")!=null){
	    			
	    		  docControlMercRestringidaVuce = (DocControlMercRestringidaVuce) map.get("docControlMercRestringidaVuce");
	    		 //fechaInicioVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaInicioVigenciaVuce(),"dd/MM/yyyy");
	 			 // fechaFinVuce=SunatDateUtils.getDate(docControlMercRestringidaVuce.getFechaFinVigenciaVuce(),"dd/MM/yyyy");
	    		  fechEmision= SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaInicioVigencia(), "dd/MM/yyyy");
	    		  fechVencimiento=SunatDateUtils.getFormatDate(docControlMercRestringidaVuce.getFechaFinVigencia(), "dd/MM/yyyy");
	    		}
	    	}	
	    	
	    	
			  resultado.addObject("fechaEmision", fechEmision);
			  resultado.addObject("fechaVencimiento", fechVencimiento);
	    		 
	   }
	  }
  	  
  	  if(errorValidacion.equals("ok")){
  		FechaBean fechaEmision ;
  		FechaBean fechaVencimiento ;
  		  if(fechEmision.equals("")){
  		  String[] obtenerddmmyyyyFechaEmision = txtEditarFecEmision.toString().split("-");
		   fechaEmision=new FechaBean(obtenerddmmyyyyFechaEmision[2]+"/"+obtenerddmmyyyyFechaEmision[1]+"/"+obtenerddmmyyyyFechaEmision[0]);
  		  }else{
  			 fechaEmision=new FechaBean(fechEmision);
  		  }
  		  if(fechVencimiento.equals("")){
		  String[] obtenerddmmyyyyFechaVencimiento = txtEditarFecVencimiento.toString().split("-");
		    fechaVencimiento=new FechaBean(obtenerddmmyyyyFechaVencimiento[2]+"/"+obtenerddmmyyyyFechaVencimiento[1]+"/"+obtenerddmmyyyyFechaVencimiento[0]);
  		  }else{
  			fechaVencimiento=new FechaBean(fechVencimiento);  
  		  }
  		for (Map<String, Object> mapaDocAsociadoSesion : lstDocAutAsociado)
        {
          for (Map<String, Object> mapaDocAsociadoSeleccionado : lstDocumentoControlAutorizantesModificar)
          {
            if (mapaDocAsociadoSesion.get("NUM_SECDOC").toString().trim().equals(mapaDocAsociadoSeleccionado.get("NUM_SECDOC").toString().trim())
                &&
                mapaDocAsociadoSesion.get("COD_TIPOPER").toString().trim().equals(mapaDocAsociadoSeleccionado.get("COD_TIPOPER").toString().trim()))
            	{
	          	  	mapaDocAsociadoSesion.put("COD_SUBENTI", txtSelectSubEntidadEditar);
	          	  	mapaDocAsociadoSesion.put("COD_SUBTIPODOC", txtSelectTipoDocumentoEditar);
	          	  	//Obtenemos el tipo por el subtipo
	          		List<Map<String, String>> lstSubTipoDocuPorTipo =  catalogoAyudaService
	        				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "A",txtSelectTipoDocumentoEditar);
	          		if (!CollectionUtils.isEmpty(lstSubTipoDocuPorTipo))
	          			mapaDocAsociadoSesion.put("COD_TIPDOCASO",lstSubTipoDocuPorTipo.get(0).get("cod_datacat"));
	          		//
	          	  	mapaDocAsociadoSesion.put("NUM_DOC", txtEditarNumDocumento);
	          	  	mapaDocAsociadoSesion.put("FEC_EMIS",fechaEmision.getTimestamp());
	          	  	mapaDocAsociadoSesion.put("FEC_VENC",fechaVencimiento.getTimestamp());
	          	    if(!fechEmision.equals("")){
		          	  	mapaDocAsociadoSesion.put("FEC_EMIS2",fechEmision);
		          	  
		          	  	}
		          	    if(!fechVencimiento.equals("")){
		          		mapaDocAsociadoSesion.put("FEC_VENC2",fechVencimiento);
		          	    }
	          	  	mapaDocAsociadoSesion.put("COD_TIPODOCAUTORIZANTE_DESC", descripcionDocumentoControl);
	          	  	if(mapaDocAsociadoSesion.get("COD_ENTI_DESC")==null || !mapaDocAsociadoSesion.get("COD_ENTI").toString().equalsIgnoreCase(txtSelectEntidadEditar)){
	          	  		mapaDocAsociadoSesion.put("COD_ENTI_DESC", descripcionEntidad);
	          	  	}
	          	  	mapaDocAsociadoSesion.put("COD_ENTI", txtSelectEntidadEditar);
            	}

          	}
        }
  		
        mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
        request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
        
      	for (Map<String, Object> mapa1 : lstDetAutorizacion)
        {
          if (mapaDocumentosContieneSerie(mapa1, serieSeleccionada))
          {
            for (Map<String, Object> mapa2 : lstDocAutAsociado)
            {

              if (detDocAutAsociadoExiste(mapa1, mapa2))
              {
                	listaDocumentosControlparaGrilla.add(mapa2);
              }
            }
          }
        }
      	
      	

  	  }  	  
  	resultado.addObject("existeWarning", existeWarning); 
  	resultado.addObject("resultado", errorValidacion);
  	resultado.addObject("lstDocAsociadoModificados", SojoUtil.fromJson(SojoUtil.toJson(listaDocumentosControlparaGrilla)));
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      resultado.addObject("Error", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      resultado.addObject("Error", rBean);
    }
    rBean = new MensajeBean();
    rBean.setError(false);
	 if(!msgWarning.equals("")){
		  rBean.setMensajeerror(msgWarning);
	 }
    resultado.addObject("Error", rBean);
    return resultado;
  }

  public ModelAndView eliminarDocumentoControlAutorizanteSession(HttpServletRequest request, HttpServletResponse response){
	  	ModelAndView resultado=new ModelAndView(this.jsonView);
	  	MensajeBean rBean = null;
	    Map<String, Object> mapCabDeclara = null;
	    List<Map<String, Object>> lstDocumentoControlEliminar = null;
	    List<Map<String, Object>> lstDocAutAsociado = null;
	    List<Map<String, Object>> lstDetAutorizacion = null;
	    List<Map<String, Object>> listaDocumentosControlparaGrilla = new ArrayList<Map<String, Object>>();
	    try
	    {
	      String serieSeleccionada = request.getParameter("txt_num_secserie");
	      lstDocumentoControlEliminar=(List<Map<String,Object>>)SojoUtil.fromJson(request.getParameter("docControlEliminar").toString());

	      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
	  	  List<Map<String, Object>> lstDocAutAsociadoAux=(List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
		  lstDocAutAsociado = new ArrayList<Map<String, Object>>();
		  lstDocAutAsociado= Utilidades.copiarLista((List) lstDocAutAsociadoAux) == null ? new ArrayList<Map<String, Object>>() : Utilidades.copiarLista((List) lstDocAutAsociadoAux);		      
		  List<Map<String, Object>> lstDetAutorizacionAux=(List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
		  lstDetAutorizacion = new ArrayList<Map<String, Object>>();
		  lstDetAutorizacion= Utilidades.copiarLista((List) lstDetAutorizacionAux) == null ? new ArrayList<Map<String, Object>>() : Utilidades.copiarLista((List) lstDetAutorizacionAux);		      
		  //FCO - Se comento debido a que la opcion solo deberia eliminar la relacion del documento con la serie
	      /*for (Map<String, Object> mapaDocumentoControlEliminar : lstDocumentoControlEliminar)
	      {
	        for (Map<String, Object> mapaDocumentoAsociado : lstDocAutAsociado)
	        {
	          if (mapaDocumentoControlEliminar.get("NUM_SECDOC").toString().trim().equals(mapaDocumentoAsociado.get("NUM_SECDOC").toString().trim())
	              &&
	              mapaDocumentoControlEliminar.get("COD_TIPOPER").toString().trim().equals(mapaDocumentoAsociado.get("COD_TIPOPER").toString().trim())
	              && 
	              !mapaDocumentoAsociado.get("COD_TIPOPER").toString().trim().equals("C"))
	          {
	        	  mapaDocumentoAsociado.put("IND_DEL", "1");
	          }

	        }
	      }*/


	      for (Map<String, Object> mapaDocumentoControlEliminar : lstDocumentoControlEliminar)
	      {
	        for (Map<String, Object> mapaDetAutorizacion : lstDetAutorizacion)
	        {
	          //FCO - Cambio para eliminar solo la relacion documento-serie
	          if (!mapaDocumentosContieneSerie(mapaDetAutorizacion, serieSeleccionada)) continue;
	          	
	          if (detDocAutAsociadoExiste(mapaDetAutorizacion, mapaDocumentoControlEliminar))
	          {
	        	  mapaDetAutorizacion.put("IND_DEL", "1");
	          }

	        }
	      }
	      mapCabDeclara.put("lstDocAutAsociado", lstDocAutAsociado);
	      mapCabDeclara.put("lstDetAutorizacion", lstDetAutorizacion);
	      request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);
	      
	      for (Map<String, Object> mapa1 : lstDetAutorizacion){
	          if (mapaDocumentosContieneSerie(mapa1, serieSeleccionada)){
	            for (Map<String, Object> mapa2 : lstDocAutAsociado){
                    if (detDocAutAsociadoExiste(mapa1, mapa2)){
	            	  	//FCO - Cambio para mostrar la eliminacion de la relacion documento-serie
                    	mapa2.put("IND_DEL_DET", mapa1.get("IND_DEL"));
                        if(!documentoAsociadoAOtrasSeries(mapa2, lstDetAutorizacion)) {
	            	  	mapa2.put("IND_DEL", mapa1.get("IND_DEL").toString());
                        }
	            	  	listaDocumentosControlparaGrilla.add(mapa2);
	              }

	            }
	          }
	        }
	      
	      
	      resultado.addObject("lstDocAsociadoEliminado", SojoUtil.fromJson(SojoUtil.toJson(listaDocumentosControlparaGrilla)));
	    }
	    catch (ServiceException e)
	    {
	      rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean
	          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      return new ModelAndView(jsonView, "Error", rBean);
	    }
	    catch (Exception e)
	    {
	      rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean
	          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);

	      return new ModelAndView(jsonView, "Error", rBean);
	    }
	    
	    rBean = new MensajeBean();
	    rBean.setError(false);
	    resultado.addObject("Error", rBean);
	    resultado.addObject("resultado", "ok");
	  return resultado;
  }

    private boolean documentoAsociadoAOtrasSeries(Map<String, Object> docAutorizante, List<Map<String, Object>> lstSeriesAsociadasDocumento){
        for (Map<String, Object> serieAsociadaDocumento : lstSeriesAsociadasDocumento){
            if(serieAsociadaDocumento.get("NUM_SECDOC").toString().trim().equals(docAutorizante.get("NUM_SECDOC").toString().trim()) &&
            serieAsociadaDocumento.get("COD_TIPOPER").toString().trim().equals(docAutorizante.get("COD_TIPOPER").toString().trim()) &&
            serieAsociadaDocumento.get("IND_DEL").toString().trim().equals(Constantes.IND_NO_ELIMINADO)){
                return true;
            }
        }
        return false;
    }

/**FIN - RIN14**/
  
  /**
   * Metodo que modifica los documentos asociados en session.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView modificarDocumentoAsociadoSession(HttpServletRequest request, HttpServletResponse response)
  {
    MensajeBean rBean = null;
    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapCabDeclara = null;
    List<Map<String, Object>> lstDocumentoAsociado = null;
    boolean existe = false;
    Map<String, Object> mDetAutBase;
    try
    {

      JSONArray array1 = JSONArray.fromObject(webRequest.getParameter("hdn_lstDocumentoAsociado"));

      lstDocumentoAsociado = (List<Map<String, Object>>) Utilidades.toCollection(array1, Map.class);

      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      for (Map<String, Object> mapa : (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado"))
      {
        existe = false;
        for (int i = 0; i < lstDocumentoAsociado.size(); i++)
        {
          if (mapa
              .get("NUM_SECDOC")
              .toString()
              .trim()
              .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("NUM_SECDOC").toString().trim())
              &&
              mapa
                  .get("COD_TIPOPER")
                  .toString()
                  .trim()
                  .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("COD_TIPOPER").toString().trim()))
          {
            existe = false;
            break;
          }
          else
            existe = true;
        }
        if (existe)
        {
          lstDocumentoAsociado.add(mapa);
        }
      }

      // agregar a la un nuevo det autoriza
      List<Map<String, Object>> lstDetAuto = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
      if(!CollectionUtils.isEmpty(lstDetAuto)){
      for (int i = 0; i < lstDocumentoAsociado.size(); i++)
      {
        existe = true;
       
		    for (Map<String, Object> mapa : lstDetAuto)
        {
          if (mapa
              .get("NUM_SECDOC")
              .toString()
              .trim()
              .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("NUM_SECDOC").toString().trim())
              &&
              mapa
                  .get("COD_TIPOPER")
                  .toString()
                  .trim()
                  .equals(((Map<String, Object>) lstDocumentoAsociado.get(i)).get("COD_TIPOPER").toString().trim()))
          {
            existe = false;
            break;
          }
          else
            existe = true;
        }
        if (existe)
        {
          mDetAutBase = new HashMap<String, Object>()
          {

            private static final long serialVersionUID = -3103099312904419163L;

            {
              put("NUM_CORREDOC", "");
              put("NUM_SECSERIE", "");
              put("NUM_SECDOC", "");
              put("IND_DEL", "");
              put("COD_USUREGIS", "");
              put("FEC_REGIS", "");
              put("COD_USUMODIF", "");
              put("COD_IDENT_DESC", "");
              put("COD_TIPDOC_DESC", "");
              put("COD_LUGAR_DESC", "");
              put("FEC_MODIF", "");
              put("COD_TIPOPER", "");
              put("NUM_CORREDOC", "");
              put("COD_TIPDOCASO_DESC", "");
              put("COD_ENTI_DESC", "");
            }
          };
          mDetAutBase.put("NUM_CORREDOC", lstDocumentoAsociado.get(i).get("NUM_CORREDOC"));
          mDetAutBase.put("NUM_SECSERIE", webRequest.getParameter("hdn_num_secserie"));
          mDetAutBase.put("NUM_SECDOC", lstDocumentoAsociado.get(i).get("NUM_SECDOC"));
          mDetAutBase.put("IND_DEL", "0");
          mDetAutBase.put("COD_USUREGIS", "");
          mDetAutBase.put("FEC_REGIS", "");
          mDetAutBase.put("COD_USUMODIF", "");
          mDetAutBase.put("FEC_MODIF", "");
          mDetAutBase.put("COD_TIPOPER", lstDocumentoAsociado.get(i).get("COD_TIPOPER"));
          ((List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion")).add(mDetAutBase);
        }
      }
      }
      mapCabDeclara.put("lstDocAutAsociado", lstDocumentoAsociado);
      mapCabDeclara.put("lstDetAutorizacion", ((List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion")));
      request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(jsonView, "Error", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      return new ModelAndView(jsonView, "Error", rBean);
    }
    return new ModelAndView(jsonView, "resultado", "ok");
  }



  /**
   * Metodo que que captura la acci�n de validar las declaraci�nes con
   * solicitudes realizadas por el especialista.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView validarDeclaracionSolicitud(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
      params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
      params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
      params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("tipo_diligencia"));
      Map<String, Object> mapCabDiligencia = solicitudService.validarDeclaConSolicitudXEspecialista(params);
      modelView = new ModelAndView(this.jsonView, "mapCabDiligencia", mapCabDiligencia);
      return modelView;
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }

  /**
   * Metodo para cargar el formulario se solicitud realizado por el
   * especialista.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView cargarSolicitudEspecialista(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("COD_ADUANA", request.getParameter("hdn_cod_aduana"));
      params.put("ANN_PRESEN", request.getParameter("txt_ann_presen"));
      params.put("COD_REGIMEN", request.getParameter("sel_cod_regimen"));
      params.put("NUM_DECLARACION", request.getParameter("txt_num_declaracion"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("tipo_diligencia"));
      params.put("num_corredoc", request.getParameter("num_corredoc"));
      params.put("cod_tipdiligencia", request.getParameter("cod_tipdiligencia"));
      params.put("cod_motivo", request.getParameter("cod_motivo"));
      params.put("fec_diligencia", request.getParameter("fec_diligencia"));
      params.put("cod_funcionario", request.getParameter("cod_funcionario"));
      params.put("cod_catalogo", request.getParameter("cod_catalogo"));
      params.put("fec_conclusion", request.getParameter("fec_conclusion"));
      params.put("fec_declaracion", request.getParameter("fec_declaracion"));
      Map<String, Object> mapCabDiligencia = solicitudService.validarDeclaConSolicitudXEspecialista(params);
      if (!mapCabDiligencia.get("COD_TIPDILIGENCIA").equals("NO_FOUND"))
      {
        params.put("FEC_REGIS", mapCabDiligencia.get("FEC_REGIS"));
        params.put("respuesta", "TRUE");
        // Agregamos la descripci�n del motivo
        DataCatalogo dataCatalogo = this.catalogoAyudaService.getDataCatalogo(
            (String) params.get("cod_catalogo"),
              (String) params.get("cod_motivo"));
        params.put("des_motivo", (dataCatalogo != null) ? dataCatalogo.getDesCorta() : " ");
        FiltroCatEmpleado filtro = new FiltroCatEmpleado();
        filtro.setCodPers((String) params.get("cod_funcionario"));
        // Agregamos la descripci�n del funcionario
        Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
        CatEmpleado catEmpleadoTemp = (CatEmpleado) mapCatEmpleado.get(params.get("cod_funcionario"));
        params.put("des_funcionario", (catEmpleadoTemp != null) ?
            catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " " + catEmpleadoTemp.getNombres() : " ");
      }
      else
      {
        params.put("respuesta", "FALSE");
      }
      modelView = new ModelAndView("SolicitudEspecialista", "mapCabDiligencia", params);
      return modelView;
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "Error", rBean);
    }
  }

  /**
   * Metodo para responder a la solicitud del especialista, es decir registra la
   * respuesta final de aprobaci�n del supervisor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 � ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public ModelAndView actualizarSolicitudEspecialista(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {

    ModelAndView modelView = new ModelAndView();
    try
    {
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      FechaBean fecActual = new FechaBean();
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", request.getParameter("num_corredoc"));
      params.put("COD_TIPDILIGENCIA", request.getParameter("cod_tipdiligencia"));
      params.put("IND_RESPUESTA", request.getParameter("ind_respuesta"));
      params.put("DES_RESPUESTA", request.getParameter("des_respuesta"));
      params.put("FEC_RESPUESTA", fecActual.getTimestamp());
      params.put("COD_USUMODIF", bUsuario.getNroRegistro());
      params.put("FEC_MODIF", fecActual.getTimestamp());
      if (params.get("COD_TIPDILIGENCIA").equals(Constantes.SOLI_AMPLI_PLAZO))
      {
        params
            .put("FEC_CONCLUSION", new FechaBean(request.getParameter("fec_conclusion"), "yyyy-MM-dd").getTimestamp());
      }
      Map<String, Object> mapRes = solicitudService.registrarRespuestaSolEspecialista(params);
      modelView = new ModelAndView(this.jsonView, "mapRes", mapRes);

      return modelView;
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView(this.jsonView, "Error", rBean);
    }
  }

  /**
   * Metodo para cargar la ventana de mensajes de la tabla comunicaciones.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return ModelAndView
   * @throws Exception
   *           the exception
   * @see
   */
  public ModelAndView cargarComunicaciones(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ModelAndView modelAndView = new ModelAndView("MensajesComunicacion");
    Map<String, Object> mapCabDeclara = null;
    try
    {
      mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));

      List<Map<String, Object>> lstComunicacion = diligenciaService.obtenerComunicaciones(params);

      if (!CollectionUtils.isEmpty(lstComunicacion))
      {
        // Obtenemos la descripci
        for (int i = 0; i < lstComunicacion.size(); i++)
        {
          // Colocando la descripcion del usuario
          FiltroCatEmpleado filtro = new FiltroCatEmpleado();
          filtro.setCodPers(lstComunicacion.get(i).get("COD_USUREGIS").toString());
          Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
          CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(lstComunicacion.get(i).get("COD_USUREGIS"));
          lstComunicacion.get(i).put(
              "DES_USUREGIS",
                (catEmpleadoTemp != null) ?
                    catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " "
                        + catEmpleadoTemp.getNombres() : " ");
        }
      }
      modelAndView.addObject("lstComunicacionFinal", lstComunicacion);

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    finally
    {
    }
    return modelAndView;
  }

  /**
   * Metodo que nos permite obtener los vehiculos (Placas) y su empresa de
   * transporte segun una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaVehiculos(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    List<Map<String, Object>> listado = null;
    Map pkDocu = new HashMap<String, String>();
    try
    {
      pkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      listado = declaracionService.obtenerVehiculos(pkDocu);
    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
          .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    return new ModelAndView("ConsultaVehiculos", "vehiculos", SojoUtil.toJson(listado));
  }

  /**
   * Metodo que nos permite obtener los Plazos segun una DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarPlazosProceso(HttpServletRequest request, HttpServletResponse response)
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    //inicio gmontoya P24
    Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");//GMONTOYA P24
    Long numCorredoc = ((BigDecimal) mapCabDeclara.get("NUM_CORREDOC")).longValue();
    
    String numeroRegimen = webRequest.getParameter("hdn_cod_regimen")!= null ? webRequest.getParameter("hdn_cod_regimen") : ""; //PAS20175E220200035
    
    Map pkDocu = new HashMap<String, String>();
    try
    {
      pkDocu.put("NUM_CORREDOC_PRE", webRequest.getParameter("hdn_num_corredoc"));
      
      SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
      
    ModelAndView model;
    Map mapRegularizacion = new HashMap();
    Map mapSolicitud  = new HashMap();  
    Date fechaNumeracioDUA = (Date)mapCabDeclara.get("FEC_DECLARACION");
    
    pe.gob.sunat.despaduanero2.service.SolicitudService solicitudServiceSol = fabricaDeServicios.getService("despaduanero2.solicitudService");
    mapSolicitud = solicitudServiceSol.buscarSoliProrrogaRegularizacion(pkDocu);
    if(mapSolicitud == null){
    	mapSolicitud = new HashMap();
    }
    Date fecTerm = mapCabDeclara.get("FEC_TERM")!=null?(Date)mapCabDeclara.get("FEC_TERM"):SunatDateUtils.getDefaultDate();
    Date fecVenRegu = mapCabDeclara.get("FEC_VENCREGULA")!=null?(Date)mapCabDeclara.get("FEC_VENCREGULA"):SunatDateUtils.getDefaultDate();
    Date fecSolicitud = mapSolicitud==null?SunatDateUtils.getDefaultDate():(mapSolicitud.get("FEC_SOLICITUD")!=null?(Date)mapSolicitud.get("FEC_SOLICITUD"):SunatDateUtils.getDefaultDate());//gmontoya Pase 97 2016
    Date fecRegu = mapCabDeclara.get("FEC_REGULARIZA")!=null?(Date)mapCabDeclara.get("FEC_REGULARIZA"):SunatDateUtils.getDefaultDate();
    if(mapCabDeclara.get("DES_ESTREGUL_DESC")!=null && !String.valueOf(mapCabDeclara.get("DES_ESTREGUL_DESC")).trim().isEmpty()){
    	String codigoModalidad =this.catalogoAyudaService.getDescripcionDataCatalogo("306",String.valueOf(mapCabDeclara.get("COD_MODALIDAD")));
    	String tipoRegularizacion = codigoModalidad.toUpperCase().concat(" - ");
    	if(codigoModalidad.compareToIgnoreCase("Urgente")==0){
    		if(SunatDateUtils.isDefaultDate(fecRegu)){    			
    			tipoRegularizacion = tipoRegularizacion.concat("PENDIENTE DE REGULARIZAR");
    			if(SunatDateUtils.isDefaultDate(fecSolicitud)){
    				tipoRegularizacion = tipoRegularizacion.concat(" SIN ");
    			}else{
    				tipoRegularizacion = tipoRegularizacion.concat(" CON ");
    			}
    			tipoRegularizacion = tipoRegularizacion.concat("TRANSMISI�N DE REGULARIZACI�N");
    		}else{
    			tipoRegularizacion = tipoRegularizacion.concat("REGULARIZADA");
    		}
    	}else{
    		if(SunatDateUtils.isDefaultDate(fecRegu)){  
    			tipoRegularizacion = tipoRegularizacion.concat("PENDIENTE DE REGULARIZAR");
    		}else{
    			tipoRegularizacion = tipoRegularizacion.concat("REGULARIZADA");
    		}
    	}
	    mapRegularizacion.put("TIPO",tipoRegularizacion);
		mapRegularizacion.put("FEC_DECLARACION", sd.format(fechaNumeracioDUA));	    
		mapRegularizacion.put("TERMINO_DESCARGA", SunatDateUtils.isDefaultDate(fecTerm)?"":sd.format(fecTerm));
		mapRegularizacion.put("PLAZO_VENCIMIENTO", SunatDateUtils.isDefaultDate(fecVenRegu)?"":sd.format(fecVenRegu));
		mapRegularizacion.put("SOLICITUD_REGULARIZACION", SunatDateUtils.isDefaultDate(fecSolicitud)?"":sd.format(fecSolicitud));
		mapRegularizacion.put("FECHA_REGULARIZACION", SunatDateUtils.isDefaultDate(fecRegu)?"":sd.format(fecRegu));	    
    }else{
    	mapRegularizacion = null;
    }
    
    Map<String,Object> mapa = new HashMap<String, Object>();
    mapa.put("NUM_CORREDOC_PRE", numCorredoc);
    List<Map<String,Object>> listaSolicitudesVP = solicitudServiceSol.obtenerSolicitudValorProvisional(mapa);    
	model = new ModelAndView("ConsultaPlazosProceso", "plazosRegularizacion", SojoUtil.toJson(mapRegularizacion));
    model.addObject("solicitudesValorProvisional",  (!CollectionUtils.isEmpty(listaSolicitudesVP)?SojoUtil.toJson(listaSolicitudesVP):"[]"));
    //Inicio - PAS20175E220200035
    model.addObject("numeroRegimen", numeroRegimen);
    Date aceptacion_garantia = SunatDateUtils.getDefaultDate();
    String aceptacion_garantia_string =" ";
    Date ini_plazo = SunatDateUtils.getDefaultDate();
    String ini_plazo_string = " ";
    Date venc_plazo = SunatDateUtils.getDefaultDate();
    String venc_plazo_string = " ";
    Date plazo_max = SunatDateUtils.getDefaultDate();
    String plazo_max_string = " ";
    Date venc_merc_perec = SunatDateUtils.getDefaultDate();    
    String venc_merc_perec_string = " ";
    if(!numeroRegimen.equalsIgnoreCase("10")){
        if(numeroRegimen.equalsIgnoreCase("20") || numeroRegimen.equalsIgnoreCase("21")){
			GarantiaOperativaService garantiaService = fabricaDeServicios.getService("recauda.diligencia.garantiaService");
			Map<String, Object> mapGarantiaParam = new HashMap<String, Object>();
			mapGarantiaParam.put("PREGIMEN", mapCabDeclara.get("COD_REGIMEN"));
			mapGarantiaParam.put("PADUANA", mapCabDeclara.get("COD_ADUANA"));
			mapGarantiaParam.put("PANO", mapCabDeclara.get("ANN_PRESEN"));
			mapGarantiaParam.put("PNUMERO", SunatStringUtils.lpad(mapCabDeclara.get("NUM_DECLARACION").toString(), 6, '0'));
			List<Map<String,Object>> lstGarantias = new ArrayList<Map<String,Object>>();
			lstGarantias =  garantiaService.getGarantiaOperativa(mapGarantiaParam);//Garantia Operativa
			if(lstGarantias.isEmpty()){
				String garantia_160 = mapCabDeclara.get("NUM_CTACTE").toString().trim();
				if(!garantia_160.isEmpty()){
					 Map<String, Object> paramsCtaCte = new HashMap<String, Object>();
					 paramsCtaCte.put("NUMCTACTE", garantia_160);
					 Map<String, Object> cabCtaCteGara = declaracionService.getCabCtaCteGara(paramsCtaCte);
					 aceptacion_garantia=DateUtil.stringToDate(cabCtaCteGara.get("FECREGIS").toString(),"yyyy-MM-dd hh:mm:ss.S");
		           	 SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd/MM/yyyy");
		           	 aceptacion_garantia_string = dFormatFinal.format(aceptacion_garantia); 					 
				}
			}
			else{
				for (Map<String, Object> garantia : lstGarantias) {
					aceptacion_garantia=DateUtil.stringToDate(garantia.get("FECHA_RECEP").toString(),"yyyyMMdd");
	           	 	SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd/MM/yyyy");
	           	 	aceptacion_garantia_string = dFormatFinal.format(aceptacion_garantia); 
				}
			}
			if(!SunatDateUtils.sonIguales((Date) mapCabDeclara.get("FEC_AUTLEVANTE"), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
	            ini_plazo = (Date) mapCabDeclara.get("FEC_AUTLEVANTE"); 
                SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
                ini_plazo_string = formatador.format(ini_plazo);
                if(numeroRegimen.equalsIgnoreCase("21")){
                	plazo_max = SunatDateUtils.addMonth(ini_plazo, 24);//(24) meses computados a partir de la fecha de levante.
                	 SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd/MM/yyyy");
                	 plazo_max_string = dFormatFinal.format(plazo_max);            	
                }                
			}
            if(!mapCabDeclara.get("FEC_VENREGIMEN").toString().equalsIgnoreCase("01/01/0001")){
                venc_plazo = new SimpleDateFormat("dd/MM/yyyy").parse(mapCabDeclara.get("FEC_VENREGIMEN").toString());
                venc_plazo_string =	mapCabDeclara.get("FEC_VENREGIMEN").toString();	
                }			
			
        }
        else { //Regimen 70
            ini_plazo = (Date) mapCabDeclara.get("FEC_DECLARACION"); 
            SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
            ini_plazo_string = formatador.format(ini_plazo);
            if(!mapCabDeclara.get("FEC_VENREGIMEN").toString().equalsIgnoreCase("01/01/0001")){
            venc_plazo = new SimpleDateFormat("dd/MM/yyyy").parse(mapCabDeclara.get("FEC_VENREGIMEN").toString());
            venc_plazo_string =	mapCabDeclara.get("FEC_VENREGIMEN").toString();	            
            }
            DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
			Map<String,String> params = new HashMap<String,String>();
			params.put("NUM_CORREDOC", numCorredoc.toString());
			params.put("COD_TIPDOCASO", "21");//21
			params.put("IND_DEL", "0");//0
			List<DatoOtroDocSoporte> listDocAutAsociadoSerie = docAutAsociadoDAO.find(params);
            Date fechavenc_menor_documentos = SunatDateUtils.getDefaultDate();
            Date venc_documento = SunatDateUtils.getDefaultDate();
            if(!CollectionUtils.isEmpty(listDocAutAsociadoSerie)){
            	for (DatoOtroDocSoporte docAutAsociadoSerie : listDocAutAsociadoSerie) {
            		venc_documento = (Date) docAutAsociadoSerie.getFecvencimiento();
            		if(!SunatDateUtils.sonIguales(venc_documento, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
            			fechavenc_menor_documentos = venc_documento;
            			break;
            		}
            	}
            }
            if(!CollectionUtils.isEmpty(listDocAutAsociadoSerie)){
            	for (DatoOtroDocSoporte docAutAsociadoSerie : listDocAutAsociadoSerie) {
            		venc_documento = (Date) docAutAsociadoSerie.getFecvencimiento();
            		if(!SunatDateUtils.sonIguales(venc_documento, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
            			if (SunatDateUtils.esFecha1MenorQueFecha2(venc_documento, fechavenc_menor_documentos, SunatDateUtils.COMPARA_SOLO_FECHA)){
            				fechavenc_menor_documentos = venc_documento;
            			}
            		}
            	}
            
                if(!mapCabDeclara.get("FEC_VENREGIMEN").toString().equalsIgnoreCase("01/01/0001")){//venc_plazo
            if(SunatDateUtils.esFecha1MenorIgualQueFecha2(venc_plazo, fechavenc_menor_documentos, SunatDateUtils.COMPARA_SOLO_FECHA)){
            	venc_merc_perec = venc_plazo;
            }
            else{
            	venc_merc_perec = fechavenc_menor_documentos;
            }
                	venc_merc_perec_string = venc_merc_perec.toString();
                }            	
            }

            plazo_max = SunatDateUtils.addMonth(ini_plazo, 12);//(12sw) meses computados a partir de la fecha de numercion.    
       	 	SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd/MM/yyyy");
       	 	plazo_max_string = dFormatFinal.format(plazo_max);               
        }
    }
    List<Map<String,Object>> listaPlazos = new ArrayList<Map<String,Object>>();
    Map<String,Object> plazo = new HashMap<String,Object>();
    plazo.put("aceptacion_garantia",aceptacion_garantia_string);
    plazo.put("ini_plazo",ini_plazo_string);
    plazo.put("venc_plazo",venc_plazo_string);
    plazo.put("plazo_max",plazo_max_string);
    plazo.put("venc_merc_perec",venc_merc_perec_string);
    listaPlazos.add(plazo);
    model.addObject("plazosRegimen",  (!CollectionUtils.isEmpty(listaPlazos)?SojoUtil.toJson(listaPlazos):"[]"));
    //Fin - PAS20175E220200035
    //Incio rin10
    List listado = null;

    Map pkDocuVP = new HashMap();
    MensajeBean rBean;
    try {
    	pkDocuVP.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));

    	pkDocuVP.put("FLAG_MOSTRAR_FECHA_FINAL_DEF_PRORROGA", Boolean.valueOf(true));

      listado = this.declaracionService.obtenerPlazosProceso(pkDocuVP);
      if (CollectionUtils.isEmpty(listado))
      {
        /*rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror("El registro no contiene una lista de plazos asociados.");

        return new ModelAndView("PagM", "beanM", rBean);*/
    	  model.addObject("plazos",  (!CollectionUtils.isEmpty(listado)?SojoUtil.toJson(listado):"[]"));

    	    return model;
        
      }
    }
    catch (ServiceException e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      this.log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      this.log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    //model.addObject("plazos",  SojoUtil.toJson(listado));
    model.addObject("plazos",  (!CollectionUtils.isEmpty(listado)?SojoUtil.toJson(listado):"[]"));
    
    //return new ModelAndView("ConsultaPlazosProceso", "plazos", SojoUtil.toJson(listado));
    //fin Rin10
    return model;
    
  }catch (Exception e)
  {
    MensajeBean rBean = new MensajeBean();
    rBean.setError(true);
    rBean.setMensajeerror(e.getMessage());
    rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
    log.error("*** ERROR ***", e);
    return new ModelAndView("PagM", "beanM", rBean);
  }
//fin gmontoya P24
  }

  /**
   * Carga consulta asignaciones y reasignaciones.
   *
   */
	public ModelAndView cargarConsultaAsignaciones(HttpServletRequest request, HttpServletResponse response){
		Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
    	List<Map<String, Object>> lstAsignaciones = new ArrayList<Map<String, Object>>();
    	List<Map<String, Object>> lstReasignaciones = new ArrayList<Map<String, Object>>();
    	Long numCorredoc = ((BigDecimal) mapCabDeclara.get("NUM_CORREDOC")).longValue();
    	try{
        	lstAsignaciones = solicitudService.getDuayReguAsignaciones(numCorredoc);
            lstReasignaciones = solicitudService.getReasignaciones(numCorredoc);
    	} catch (Exception e) {
    		MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Ocurri� un error, por favor vuelva a " +
			  "intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "beanM", rBean);
    	}

	  	ModelAndView view = new ModelAndView("ConsultaAsignaciones");

	  	view.addObject("asignaciones", lstAsignaciones);
	  	view.addObject("reasignaciones", lstReasignaciones);
	  	view.addObject("hdn_num_corredoc", mapCabDeclara.get("NUM_CORREDOC").toString());
	  	view.addObject("hdn_cod_aduana", mapCabDeclara.get("COD_ADUANA").toString());
	  	view.addObject("hdn_ann_presen", mapCabDeclara.get("ANN_PRESEN").toString());
	  	view.addObject("hdn_cod_regimen", mapCabDeclara.get("COD_REGIMEN").toString());
	  	view.addObject("hdn_num_declaracion", mapCabDeclara.get("NUM_DECLARACION").toString());
	  	mapCabDeclara = null;
	  	return view;
  }


  /**
   * Cargar consulta Mercancia Vigente.
   * PAS20171U220200005 se reordena y se considera los casos de indicador
   * contrato llave en mano y Maquinaria o Equipo arribado en Despachos Parciales
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   */
  public ModelAndView cargarConsultaMercanciaVigente(HttpServletRequest request, HttpServletResponse response)
  {  
   
    List<Map<String,Object>> listaPrece = new ArrayList<Map<String,Object>>();
    //BigDecimal cantUniComer = SunatNumberUtils.toBigDecimal(request.getParameter("hdn_cant_uni_comer"));//gmontoya P29 Pase94
    BigDecimal cantUniComer = SunatNumberUtils.toBigDecimal(request.getParameter("cnt_comer"));//En P29 lo cambiaron a esta casilla
    
    
    BigDecimal totalUnidadesComerciales = new BigDecimal(0);
    ModelAndView view = new ModelAndView("ConsultaMercanciaVigente"); 
    
    Map<String,Object> cabecera = new HashMap<String,Object>();
    String indicador = "";
    try
    {
        Long numCorreDoc = Long.parseLong(request.getParameter("hdn_num_corredoc"));
        Integer numSecSerie = Integer.parseInt(request.getParameter("hdn_num_secserie"));
       
        //Inicio PAS20171U220200005 solo si tiene indicador llave en mano o despachos parciales:
        ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService");
        indicador = valMercanciaVigenteService.indicadorLlaveMaquinariaPrevio(numCorreDoc,new String[]{ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO,
        		ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES});
        
        if(!StringUtils.isEmpty(indicador)){
               
        	Integer totalEnvios = 0;
        	Integer enviosRegistrados = 0;
        	
        	Long numcorredocPrimigenia = new Long(0);
        	Map<String,Object> params = new HashMap<String,Object>();
        	
        	if(valMercanciaVigenteService.esDeclaracionPrimigenia(numCorreDoc, indicador)){//si es la primigenia el total figura con ese ruc
        		numcorredocPrimigenia = numCorreDoc;        	        	
        		params.put("NUM_SERIEPRIMIGENIA",numSecSerie);//la serie es primigenia
        	}else{
        		numcorredocPrimigenia = valMercanciaVigenteService.obtenerNumcorredocPrimigeniaPorVigente(numCorreDoc, numSecSerie); 
        		params.put("NUM_SERIEVIGENTE",numSecSerie);//la serie es de una vigente
        	}
        	
    		totalEnvios = valMercanciaVigenteService.obtenerNumTotalEnvios(numcorredocPrimigenia);	
    		enviosRegistrados = valMercanciaVigenteService.obtenerEnviosRegistrados(numcorredocPrimigenia);
    		if(indicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO)){
    			indicador = indicador.concat("-").concat("Contrato Llave en Mano");
    		}else if(indicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES)){
    			indicador = indicador.concat("-").concat("M�quina o Equipo arribado en despachos parciales");
    		}
    		
    		cabecera.put("INDICADOR", indicador);
        	cabecera.put("NUM_TOTALENVIOS", totalEnvios);
        	cabecera.put("NUM_ENVIOS", enviosRegistrados);
        	cabecera.put("NUM_ENVIOSPENDIENTES", totalEnvios-enviosRegistrados);
        	    		
    		params.put("NUM_CORREDOC", numcorredocPrimigenia);
    		CabAdiImpoConsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("diligencia.rectificacion.cabAdiImpoConsuDef_xa");    	  
    		listaPrece = cabAdiImpoconsuDAO.selectAllEnvios(params);
    		if(CollectionUtils.isEmpty(listaPrece)){//P_SNADE054-1271 muestra la primigenia solamente si no hay data en relacion a los demas envios 
    			listaPrece = cabAdiImpoconsuDAO.selectEnvioInicial(params); 
    		}
    		//Fin PAS20171U220200005	
        	
        }else{//sino se muestra consulta anterior
        	DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
        	listaPrece = ctaCteService.obtenerDetalleCtaCte(numCorreDoc, numSecSerie);
           
        	//inicio gmontoya P29 Pase94
	      	cabecera = listaPrece.size()>0?listaPrece.get(0):new HashMap<String,Object>();
	      	if(!CollectionUtils.isEmpty(cabecera)){
	      	  cabecera.put("CNT_COMER", cantUniComer);
	        }
	      	//fin gmontoya P29 Pase94  	

	        //Inicio PAS20171U220200005 se incorpora la fila de totales en seccion descargo de vigencia
	      	 if(!CollectionUtils.isEmpty(listaPrece)){
	            	for(Map<String, Object> mapPrece : listaPrece){
	            		if(mapPrece.get("CNT_DESCARGADA")!=null){
	            			totalUnidadesComerciales = totalUnidadesComerciales.add(new BigDecimal(mapPrece.get("CNT_DESCARGADA").toString()));
	            		}
	            	}
	        }//Fin PAS20171U220200005	      	
        }
        
        
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Ocurri� un error, por favor vuelva a " +
          "intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }    
	  
	  view.addObject("hdn_num_secserie", request.getParameter("hdn_num_secserie"));//P24 	 
      view.addObject("cabeceractacte", cabecera);
	  view.addObject("detallectacte", listaPrece);
	  view.addObject("totalCtacte",totalUnidadesComerciales.toString());
	  view.addObject("indicador",indicador);
	  return view;
  }
  
 //PAS20171U220200005 para abrir la serie en consulta
  public ModelAndView cargaConsultaDeclaracion(HttpServletRequest request, HttpServletResponse response){

      ModelAndView view = null;

      try{
    	  	ServletWebRequest webRequest = new ServletWebRequest(request);
    	  	Map<String, Object> params = new HashMap<String, Object>();
    	    params.put("NUM_DECLARACION", WUtil.getParam(webRequest, "hdn_num_declaracion", webRequest.getParameter("txt_num_declaracion")));
    	    params.put("COD_ADUANA", WUtil.getParam(webRequest, "hdn_cod_aduana", webRequest.getParameter("txt_cod_aduana")));
    	    params.put("ANN_PRESEN", WUtil.getParam(webRequest, "hdn_ann_presen", webRequest.getParameter("txt_ann_presen")));
    	    params.put("COD_REGIMEN", WUtil.getParam(webRequest, "hdn_cod_regimen", webRequest.getParameter("sel_cod_regimen")));

    		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
    		Map<String, Object> mapDeclaracion = cabDeclaraDAO.findNumCorreDocAndNumOrdenByDeclaracion(params);
    		
    		Map<Object, Object> parametrosAdicionales = new HashMap<Object, Object>();
    		if(mapDeclaracion!=null){
    			parametrosAdicionales.put("hdn_num_corredoc", mapDeclaracion.get("NUM_CORREDOC").toString());
    		}
    		parametrosAdicionales.put("num_serieInit", webRequest.getParameter("hdn_serie"));//serie inicial seleccionada

    	    HttpSession session = request.getSession();
    	    parametrosAdicionales.put("mapCabDeclaraActual",session.getAttribute("mapCabDeclaraActual")); 
    	    
    		 
          view = generaInvocacion(((UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean")),
                  COD_URL_CONSULTA_DUA, request.getParameterMap(),parametrosAdicionales);
      } catch (Exception e){
          MensajeBean mensajeBean = new MensajeBean();
          mensajeBean.setMensajeerror("Ocurrio un error al cargar los datos de la dua.");
          mensajeBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
          view.addObject("beanM", mensajeBean);
      }

      return view;
  }
  
  private ModelAndView generaInvocacion(UsuarioBean ubean, String url, Map parametros, Map parametrosAdicionales)
          throws Exception {

      FechaBean ts = new FechaBean();
      Map addins = new HashMap();
      addins.put("vigInvocaDesde", new Long(ts.getCalendar().getTimeInMillis() - 30000L));
      ts.getCalendar().add(12, 10);
      addins.put("vigInvocaHasta", new Long(ts.getCalendar().getTimeInMillis())); 
      ubean.getMap().putAll(addins);
      
      if (this.log.isDebugEnabled()) {
          this.log.debug("usuarioBean.map.." + ubean.getMap());
      }
      UsuarioBean cloneBean = (UsuarioBean) BeanUtils.cloneBean(ubean);
      cloneBean.setTicket(String.valueOf(cloneBean.getMap().get("idMenu")).concat("-").concat(""));
      
      
      String encodeBase64 = null;
      ZipUtil zip = new ZipUtil();
      byte[] zipObject = zip.zipObject(cloneBean);
      encodeBase64 = new Coder().encodeBase64(zipObject);
      if (this.log.isDebugEnabled()) this.log.debug(encodeBase64);

      Hash hash = HashFactory.getHash(0, encodeBase64.getBytes());
      String sha = Hex.getByteToHex(hash.get());

      if (this.log.isDebugEnabled()) {
          this.log.debug(url);
      }
      ModelAndView urlView = new ModelAndView(new RedirectView(url, false));
      urlView.addObject("token", encodeBase64);
      urlView.addObject("hc", sha);
      //urlView.addObject("mapCabDeclaraActual", sesionActual.getAttribute("mapCabDeclaraActual")); 

      if (MapUtils.isNotEmpty(parametros)) {
          Set keySet = parametros.entrySet();
          Iterator iterator = keySet.iterator();
          Map.Entry key = null;
          while (iterator.hasNext()) {
              key = (Map.Entry)iterator.next();
              if (!"action".equals(key.getKey())) {
                  urlView.addObject((String)key.getKey(), key.getValue());
              }
          }
      }
      
      if (MapUtils.isNotEmpty(parametrosAdicionales)) {
          Set keySet = parametrosAdicionales.entrySet();
          Iterator iterator = keySet.iterator();
          Map.Entry key = null;
          while (iterator.hasNext()) {
              key = (Map.Entry)iterator.next();
              if (!"action".equals(key.getKey())) {
                  urlView.addObject((String)key.getKey(), key.getValue());
              }
          }
      }

      log.info("ACCESO|" + ubean.getMap().get("tipOrigen") + "|" +
              ubean.getLogin() + "|" + ubean.getTicket() + "|" + "(" + url + ")");

      return urlView;
  }
  
  

  
  /**PAS20171U220200005 se crea esta visualizacion exclusiva de series para cualquier diligencia que requiera 
   * consultar solo las series en el formato similar al de consulta dua - consulta series y mercancia dispuesta
	 * @param request
	 * @param response
   */    
  public ModelAndView cargarConsultaSerie(HttpServletRequest request, HttpServletResponse response){
  	
  	ModelAndView modelAndView = new ModelAndView("RegOtraSerieConsulta");
  	try {
  		
  		ServletWebRequest webRequest = new ServletWebRequest(request);
  	  	Map<String, Object> params = new HashMap<String, Object>();
  	    params.put("NUM_DECLARACION", WUtil.getParam(webRequest, "hdn_num_declaracion", webRequest.getParameter("txt_num_declaracion")));
  	    params.put("COD_ADUANA", WUtil.getParam(webRequest, "hdn_cod_aduana", webRequest.getParameter("txt_cod_aduana")));
  	    params.put("ANN_PRESEN", WUtil.getParam(webRequest, "hdn_ann_presen", webRequest.getParameter("txt_ann_presen")));
  	    params.put("COD_REGIMEN", WUtil.getParam(webRequest, "hdn_cod_regimen", webRequest.getParameter("sel_cod_regimen")));

  	    String serie = webRequest.getParameter("hdn_serie").toString();
  		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
  		Map<String, Object> mapDeclaracion = cabDeclaraDAO.findNumCorreDocAndNumOrdenByDeclaracion(params);
  		Map<Object, Object> parametrosAdicionales = new HashMap<Object, Object>();
  		if(mapDeclaracion!=null){
  			parametrosAdicionales.put("hdn_num_corredoc", mapDeclaracion.get("NUM_CORREDOC").toString());
  		 
	    	    
	    		Map<String, String> paramDecla = new HashMap<String, String>();
	    		paramDecla.put("num_declaracion", WUtil.getParam(webRequest, "hdn_num_declaracion", webRequest.getParameter("txt_num_declaracion")));
	    		paramDecla.put("cod_aduana", WUtil.getParam(webRequest, "hdn_cod_aduana", webRequest.getParameter("txt_cod_aduana")));
	    		paramDecla.put("ann_presen", WUtil.getParam(webRequest, "hdn_ann_presen", webRequest.getParameter("txt_ann_presen")));
	    		paramDecla.put("cod_regimen", WUtil.getParam(webRequest, "hdn_cod_regimen", webRequest.getParameter("sel_cod_regimen")));
	    		paramDecla.put("num_corredoc", mapDeclaracion.get("NUM_CORREDOC").toString()); 
	    	    
				SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
				List<Map<String, Object>>  lstDetDeclara = serieService.obtenerListadoSeries(paramDecla);
	    	    
	    		Map<String, Object> mapSerie = new HashMap<String, Object>();
	    		mapSerie.put("NUM_CORREDOC", mapDeclaracion.get("NUM_CORREDOC").toString());
	    		mapSerie.put("NUM_SECSERIE", serie); 
	    	    Map<String, Object>  detDeclaraViewMap = serieService.obtenerSerieSession(mapSerie,lstDetDeclara);
	    	    
	    	    
	    	    
	    	    List lstItemVehic = new ArrayList<Map<String, Object>>();    	      

	            Map<String, Object> mapDam = new HashMap<String, Object>();
	            mapDam.put("NUM_CORREDOC", mapDeclaracion.get("NUM_CORREDOC").toString());
	            
	            List lstItemFactura = declaracionService.obtenerItemFactura(mapDam); 
	    	    List lstSeriesItem = serieService.obtenerSeriesItem(mapDam);
	            
	            if(!CollectionUtils.isEmpty(lstItemFactura)){
	    			for(int j=0; j<lstItemFactura.size(); j++){
	    				Map<String,Object> mapDatosVehic = new HashMap<String, Object>() ;
	    				Map<String, Object> mapItemFactura=	(Map<String, Object>) lstItemFactura.get(j);
	    				String descripcion =  mapItemFactura.get("COD_TIPDESCRMIN")!=null?mapItemFactura.get("COD_TIPDESCRMIN").toString():" ";
	    				if("01".equals(descripcion)){//es vehiculos
	        				mapDatosVehic.put("NUM_SECITEM", mapItemFactura.get("NUM_SECITEM"));
	        				mapDatosVehic.put("ANN_FABRICACION", mapItemFactura.get("ANN_FABRICACION"));
	        			}
	    				if(!CollectionUtils.isEmpty(mapDatosVehic)){
	    					lstItemVehic.add(mapDatosVehic);
	    				}
	    			}
	            }
	    		
	    	    int totalItemsSerie = 0;
	        	String ann_fabric = "0"; 
	    	    if(!CollectionUtils.isEmpty(lstSeriesItem)){
		        	for (int i=0 ; i <lstSeriesItem.size(); i++){  
		        		Map<String, Object> mapSerieItem=	(Map<String, Object>) lstSeriesItem.get(i);
		        		String num_secSerie = mapSerieItem.get("NUM_SECSERIE").toString();
		        		String num_secItem = mapSerieItem.get("NUM_SECITEM").toString();
		        		if(serie.equals(num_secSerie)){
		        			totalItemsSerie=totalItemsSerie+1;
		        			if(!CollectionUtils.isEmpty(lstItemVehic)){
		        				for(int j=0; j<lstItemVehic.size(); j++){
		        					Map<String, Object> mapItemVehic =	(Map<String, Object>) lstItemVehic.get(j);
		        					String num_item = mapItemVehic.get("NUM_SECITEM").toString();
		        					if(num_secItem.equals(num_item)){	        						 
		        	        				ann_fabric = mapItemVehic.get("ANN_FABRICACION")!=null?mapItemVehic.get("ANN_FABRICACION").toString():"0";
		        	        				break;//solo hay un vehiculo por serie
			        				}
			        			}
		        			}
		        			
		        		}
		        	}
	        	}
	    	    detDeclaraViewMap.put("tot_items", totalItemsSerie);
	    	    detDeclaraViewMap.put("annFabricVehic",ann_fabric);
	    	    
				/**observaciones**/   
			    ObservacionService observacionService = fabricaDeServicios.getService("declaracion.observacionService");
			    Observacion observacion = new Observacion();
			    observacion.setNumcorredoc(SunatNumberUtils.toLong( mapDeclaracion.get("NUM_CORREDOC").toString()));
			    observacion.setNumsecitem(Integer.parseInt(serie));
			    List<String> lstCodTipoObserva = new ArrayList<String>();
			    lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO);
			    lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_DILIG_DESCARGA_PARCIAL);
			    lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE);
			    lstCodTipoObserva.add(Constantes.TIPO_OBSERVACION_SERIE_FORMATOA);   
			    observacion.setLstCodTipObserva(lstCodTipoObserva);
			    List<Observacion> lstObservaciones = observacionService.findObservacion(observacion); 
			    if(!CollectionUtils.isEmpty(lstObservaciones)){
			    	detDeclaraViewMap.put("lstObservacionesSerie", lstObservaciones);
			    } 
			    /**fin observaciones*/
				 
				boolean serieTieneVP = serieService.serieTieneValorProvisional(mapSerie); 
				String valorVP = (serieTieneVP?"SI":"NO");
				detDeclaraViewMap.put("TIENE_VP",valorVP);    
				
				mapSerie.put("COD_ADUANA", mapDeclaracion.get("NUM_CORREDOC").toString());
	    		mapSerie.put("ANN_PRESEN", webRequest.getParameter("hdn_serie").toString()); 
	    		mapSerie.put("COD_REGIMEN", webRequest.getParameter("hdn_serie").toString()); 
	    		mapSerie.put("NUM_DECLARACION", webRequest.getParameter("hdn_serie").toString());  
	    	   
				DeclaracionService declaracionService =(DeclaracionService)fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
			    Map<String, Object> declaracion =declaracionService.obtenerDeclaracion(params);
				final String DEFAULT_TIPO_DOC = "01"; 
			    String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracion, DEFAULT_TIPO_DOC); //P24
  
				
				modelAndView.addObject("detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclara));
				modelAndView.addObject("detDeclaraViewMap",  SojoUtil.toJson(detDeclaraViewMap));
				modelAndView.addObject("numeroDeclaracionTitulo",numeroDeclaracionTitulo);
				modelAndView.addObject("hdn_num_secserie",serie);
				
				
				/**datos para la seccion 3 mercancia dispuesta**/
				List<Map<String, Object>> listMercDispViewMap = null;
			    DisposicionMercanciaService disposicionMercanciaService = (DisposicionMercanciaService)fabricaDeServicios.getService("disposicionMercanciaService");
			    listMercDispViewMap=disposicionMercanciaService.consultarDatosMercanciaDispuestaBySerie(serie, mapDeclaracion.get("NUM_CORREDOC").toString());
			    if(!CollectionUtils.isEmpty(listMercDispViewMap)){
				    BigDecimal saldoCantUni= (BigDecimal) listMercDispViewMap.get(0).get("CNT_UNISALDO");
				    BigDecimal valorFobUnitario= (BigDecimal) listMercDispViewMap.get(0).get("MTO_PRECIOUNITARIO");
	
				    BigDecimal fobTotalDisponer = SunatNumberUtils.multiply(saldoCantUni, valorFobUnitario);
				    String fobTotalDisposicion=fobTotalDisponer.toString();
				    String NUM_DOCBENEF=listMercDispViewMap.get(0).get("NUM_DOCBENEF").toString();//nombre del beneficiario	    
				    String COD_TIPDOCBENEF=listMercDispViewMap.get(0).get("COD_TIPDOCBENEF").toString();
				    Map<String, Object> declaranddp1=  soporteService.obtenerPerNatJur(COD_TIPDOCBENEF, NUM_DOCBENEF);//no trae la data
				    String razonSocial = declaranddp1.get("nombre").toString();
				   
				    modelAndView.addObject("listMercDispViewMap", listMercDispViewMap); 
				    modelAndView.addObject("razonSocial", razonSocial);
				    modelAndView.addObject("MTO_FOBTOTALDISPOSICION",fobTotalDisposicion);
			    }
  		}
  	     
  	}catch (Exception e) {

			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);

			return new ModelAndView("PagM", "beanM", rBean);
		} finally {

		}
  	return modelAndView;
  }
  /***********************SET DE SPRING **********************************/


  /**
   * obtiene los datos de los Reg de Precedencia de la serie seleccionada y los
   * muestra en la consulta.
   *
   * @param request
   * @param response
   */
  public ModelAndView cargarConsultaRegPrecedencia(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    List listaRegPrecedenciaActual = new ArrayList();
    List<Map<String,Object>> listDetalleDuaPrecedente = null;    
    List<Map<String,Object>> listaDatoVehiculo = null;
    List<DatoMontoGasto> lstDatoMontoGastoObj = null;
    List<Map<String,Object>> listaDatoMontoGasto = null;
    List<Map<String, String>> lstMtoGasto = null;
    DatoVehiculo datoVehiculo = null;
    Map<String,Object> datoVehiculoMap = null;
    HttpSession session = request.getSession();
    String hdn_num_secserie = request.getParameter("hdn_num_secserie") != null ? request.getParameter("hdn_num_secserie") : ""; //P24-PAS20165E220200099
    String valorTPN = request.getParameter("cod_tipconvenio_tpn")!=null?request.getParameter("cod_tipconvenio_tpn"):"";//gmontoya Pase 99 2016
    try {

      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
      params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
      params.put("num_secserie", request.getParameter("hdn_num_secserie"));
      params.put("valorTPN",valorTPN.trim());//gmontoya Pase 99 2016
      Long numCorreDoc = Long.parseLong(request.getParameter("hdn_num_corredoc"));
      Long numSecSerie = Long.parseLong(request.getParameter("hdn_num_secserie"));

      List<Map<String, Object>> lstDetDeclaraActual = (ArrayList<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
      Map<String, Object> mapaKeySerieSelec = new HashMap<String, Object>();
      mapaKeySerieSelec.put("NUM_CORREDOC", params.get("num_corredoc"));
      mapaKeySerieSelec.put("NUM_SECSERIE", params.get("num_secserie"));
      mapaKeySerieSelec.put("IND_DEL", "0"); //No debe mostrar los anulados - PAS20181U220200054

      // Obtenemos la serie actual seleccionada
      Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, mapaKeySerieSelec);
      // Si la serie en session tiene datos de reg de precedencia
      if (!CollectionUtils.isEmpty((List) serieAct.get("lstDocuPreceDua"))) {
        listaRegPrecedenciaActual = (ArrayList) serieAct.get("lstDocuPreceDua");
        
        List<Map<String,Object>> lstDocuPreceDuaActualMostrar = new ArrayList<Map<String,Object>>();
        for(Map regPre: (ArrayList<Map>)listaRegPrecedenciaActual){
        	 if(!regPre.get("COD_REGIMENPRE").toString().equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){//P28 Part 2 	
             	  if(!"1".equalsIgnoreCase(regPre.get("COD_REGIMENPRE").toString())) { //Se adiciono por bug en proceso de conformidad - PAS20181U220200054
             	  Map mapAux = new HashMap<String, Object>();
             	  mapAux.putAll(regPre);
             	  mapAux.put("FEC_VENCREGPRE",  DateUtil.dateToString((Date)mapAux.get("FEC_VENCREGPRE"), "dd/MM/yyyy") );
             	  lstDocuPreceDuaActualMostrar.add(mapAux);
             	  	}
                 }//P28 Part 2
        }
        request.setAttribute("lstDocuPreceDuaActual", lstDocuPreceDuaActualMostrar);
        
      }else{
        // cargo los datos de la BD
        listaRegPrecedenciaActual = serieService.obtenerRegPrecedencia(mapaKeySerieSelec);
      }
      String numPartNandi = serieAct.get("NUM_PARTNANDI").toString();
	  params.put("num_partnandi", numPartNandi);

	  //P28
	  for(int i=0;i<listaRegPrecedenciaActual.size();i++){
		  Map<String,Object> temp = (Map<String,Object>)listaRegPrecedenciaActual.get(i);
		  String regimenPrece = temp.get("COD_REGIMENPRE")!=null?temp.get("COD_REGIMENPRE").toString():"";
		  if(regimenPrece.equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){
			  listaRegPrecedenciaActual.remove(temp);
		  }
	  }
	  
      //jenciso Inicio consulta hoja de gastos para ceticos
      if(!CollectionUtils.isEmpty(listaRegPrecedenciaActual)){    	 
    	  
    	  Map<String,Object> mapPrecedencia = (Map<String,Object>)listaRegPrecedenciaActual.get(0);
    	  
    	  String regimenPrecedencia = mapPrecedencia.get("COD_REGIMENPRE")!=null?mapPrecedencia.get("COD_REGIMENPRE").toString():""; 
    	  
    	  if (regimenPrecedencia.equals("91") && (numPartNandi.equals("8701200000") 
                  || SunatStringUtils.isStringInList(numPartNandi.substring(0, 4), "8702,8703,8704,8705"))){
    		  //se carga info de los veh�culos.
    		  
    		  lstMtoGasto = catalogoAyudaService.getElementosCat("331");
              if (lstMtoGasto != null)
              {
                lstMtoGasto = ordenaMontoGasto(lstMtoGasto);
              }
              listaDatoVehiculo = (ArrayList)serieAct.get("lstDatoVehiculo");
              if(listaDatoVehiculo!=null && !listaDatoVehiculo.isEmpty())            	
              	datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap((Map<String,Object>)listaDatoVehiculo.get(0));
              listaDatoMontoGasto = (ArrayList)serieAct.get("lstDatoMontoGasto");
              if(listaDatoVehiculo == null || listaDatoVehiculo.isEmpty() || listaDatoMontoGasto == null || listaDatoMontoGasto.isEmpty()){
              	Map<String, Object> paramsVehiCeti = new HashMap<String, Object>();
//                  paramsVehiCeti.put("numcorredoc", numCorreDoc);
//                  paramsVehiCeti.put("numserie", numSecSerie);
//                  paramsVehiCeti.put("inddel", 0);
//                  List<DatoVehiculo> lstDatoVehiculo = diligenciaService.findVehiculoByMap(paramsVehiCeti);
              	paramsVehiCeti.put("NUM_CORREDOC", numCorreDoc);
              	paramsVehiCeti.put("NUM_SECSERIE", numSecSerie);
              	paramsVehiCeti.put("IND_DEL", "0");
              	listaDatoVehiculo = vehiCeticoService.selectVehiCetico(paramsVehiCeti);
              	
                  if (listaDatoVehiculo != null && listaDatoVehiculo.size() > 0)
                  {
                    datoVehiculoMap = new HashMap<String, Object>();
                    datoVehiculoMap = listaDatoVehiculo.get(0);
                    //serieAct.put("datoVehiculo", datoVehiculo);
                    datoVehiculo = Utilidades.obtenerDatoVehiculoFromMap(datoVehiculoMap);
                    //serieAct.put("lstDatoVehiculo", listaDatoVehiculo);//se guarda en lista para que no afecte en la comparacion de mapas
                  }
                  //lstDatoMontoGasto = diligenciaService.findMontoGastoByMap(paramsVehiCeti);
                  listaDatoMontoGasto = vehiCeticoService.selectMontoGasto(paramsVehiCeti);
                  //serieAct.put("lstDatoMontoGasto", listaDatoMontoGasto);
              }
              lstDatoMontoGastoObj= Utilidades.obtenerListDatoMontoGastoFromListMap(listaDatoMontoGasto);
    		  
    	  }
      }
      //jenciso Fin
      
      //msancheza Inicio consulta TPN21
      if(!CollectionUtils.isEmpty(listaRegPrecedenciaActual)){    	 
    	  
    	  Map<String,Object> mapPrecedencia = (Map<String,Object>)listaRegPrecedenciaActual.get(0);
    	  String regimenPrecedencia = mapPrecedencia.get("COD_REGIMENPRE")!=null?mapPrecedencia.get("COD_REGIMENPRE").toString():""; 
    	  String nueDeclaracionPre = mapPrecedencia.get("NUM_DECLARACIONPRE")!=null?mapPrecedencia.get("NUM_DECLARACIONPRE").toString():""; 
    	  String numSecSeriePre = mapPrecedencia.get("NUM_SECSERIEPRE")!=null?mapPrecedencia.get("NUM_SECSERIEPRE").toString():""; 
    	  String codAduanaPre = mapPrecedencia.get("COD_ADUANAPRE")!=null?mapPrecedencia.get("COD_ADUANAPRE").toString():""; 
    	  String anioPrec = mapPrecedencia.get("ANN_PRESENPRE")!=null?mapPrecedencia.get("ANN_PRESENPRE").toString():""; 
    	  if (regimenPrecedencia.equals("10")){
    			Map<String, String> paramsDetDeclaracion = new HashMap<String, String>();
    			paramsDetDeclaracion.put("cod_aduana", codAduanaPre);
    			paramsDetDeclaracion.put("ann_presen", anioPrec);
    			paramsDetDeclaracion.put("cod_regimen", regimenPrecedencia);
    			paramsDetDeclaracion.put("num_declaracion", nueDeclaracionPre);
    			paramsDetDeclaracion.put("num_secserie", numSecSeriePre);	
    			listDetalleDuaPrecedente = serieService.selectDetalleDuaPrece(paramsDetDeclaracion);
    			if (!CollectionUtils.isEmpty(listDetalleDuaPrecedente)) {
    				session.setAttribute("lstDetPreceDuaActual", listDetalleDuaPrecedente);
    			}
          
    		  
    	  }
      }
      //msancheza Fin
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);

    }

    ModelAndView view = new ModelAndView("ConsultaRegPrecedencia");

    //PAS20181U220200054
	ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
	Date fechaHoy = SunatDateUtils.getCurrentDate();
	boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;
	if(esVigenteRIN31) {
		view.addObject("vigenciaZofra", "1");
	}
	else {
		view.addObject("vigenciaZofra", "0");
	}

    view.addObject("params", params);
    view.addObject("lstDocuPreceDuaActual", !CollectionUtils.isEmpty(listaRegPrecedenciaActual) ? SojoUtil.toJson(listaRegPrecedenciaActual) : "[]");
    view.addObject("lstDetPrece", !CollectionUtils.isEmpty(listDetalleDuaPrecedente) ? SojoUtil.toJson(listDetalleDuaPrecedente) : "[]");
    view.addObject("lstMtoGasto", lstMtoGasto);
    view.addObject("datoVehiculo", datoVehiculo);
    view.addObject("lstDatoMontoGasto", lstDatoMontoGastoObj);
    view.addObject("hdn_num_secserie", hdn_num_secserie);//P24-PAS20165E220200099
    
    return view;
  }
  
  
  /**
   * Ordena monto gasto.
   *
   * @param lista
   *          the lista
   * @return the list
   */
  public List<Map<String, String>> ordenaMontoGasto(List<Map<String, String>> lista)
  {
    String[] keyList = new String[lista.size()];
    for (int i = 0; i < lista.size(); i++)
    {
      keyList[i] = lista.get(i).get("cod_datacat").toString();
    }
    Arrays.sort(keyList);
    List<Map<String, String>> orderList = new ArrayList<Map<String, String>>();
    for (int i = 0; i < keyList.length; i++)
    {
      for (int j = 0; j < lista.size(); j++)
      {
        if (lista.get(j).get("cod_datacat").equals(keyList[i]))
        {
          orderList.add(lista.get(j));
        }
      }
    }
    return orderList;
  }

  /**
   * obtiene los datos de la factura serie de la serie seleccionada y los
   * muestra en la consulta.
   *
   * @param request
   * @param response
   * @return
   */
  public ModelAndView cargarConsultaFacturaSerie(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    List listaFacturaSerieActual = new ArrayList();
	List listaFacturaSerieActualNew = new ArrayList();//PAS20175E220200035
	Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");//PAS20175E220200035
	
    try {

      params.put("cod_aduana", request.getParameter("hdn_cod_aduana"));
      params.put("ann_presen", request.getParameter("hdn_ann_presen"));
      params.put("cod_regimen", request.getParameter("hdn_cod_regimen"));
      params.put("num_declaracion", request.getParameter("hdn_num_declaracion"));
      params.put("num_corredoc", request.getParameter("hdn_num_corredoc"));
      params.put("num_secserie", request.getParameter("hdn_num_secserie"));

      List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
      Map<String, Object> mapaKeySerieSelec = new HashMap<String, Object>();
      mapaKeySerieSelec.put("NUM_CORREDOC", params.get("num_corredoc"));
      mapaKeySerieSelec.put("NUM_SECSERIE", params.get("num_secserie"));

      // Obtenemos la serie actual seleccionada
      Map serieAct = Utilidades.obtenerElemento(lstDetDeclaraActual, mapaKeySerieSelec);
      // si la lista actua de la serie tiene datos de reg de precedencia
      if (!CollectionUtils.isEmpty((List) serieAct.get("lstFacturaSerie"))) {
        listaFacturaSerieActual = (ArrayList) serieAct.get("lstFacturaSerie");
      } else {
        // cargo los datos de la BD los datos de la serie seleccionada
        //amancilla P24
        listaFacturaSerieActual = this.formatoValorService.obtenerFacturasSerieAll(mapaKeySerieSelec);
      }
	            //Inicio - PAS20175E220200035 - Se llena valores faltantes de la factura
	            listaFacturaSerieActualNew = listaFacturaSerieActual;
	            Map<String, Object> paramsFact = new HashMap<String, Object>();
	            Map factura = new HashMap();
	            paramsFact.put("NUM_CORREDOC", params.get("num_corredoc"));
	            for(Object map : listaFacturaSerieActualNew){
	            	paramsFact.put("NUM_SECFACT", ((Map)map).get("NUM_SECFACT"));
	            	List<Map<String,Object>> listFactura = ((ComprobPagoDAO)fabricaDeServicios.getService("comprobPagoDAO")).select(paramsFact); 
	            	
	            	//((Map)map).put("FORM_PAGO_FACT", listFactura.get(0).get("COD_TIPCOMPROBANTE"));
	            	((Map)map).put("FORM_PAGO_FACT", declaracionActual.get("COD_MODPAGO")); //PAS20175E220200035
	            	((Map)map).put("TERM_PAGO_FACT", " ");
	            	//((Map)map).put("TERM_PAGO_FACT", listFactura.get(0).get(" "));
	            	((Map)map).put("LUG_ENTREG_FACT", listFactura.get(0).get("DIR_LUGARTRANS"));
	            	((Map)map).put("MON_FACT", listFactura.get(0).get("COD_MONEDA"));
	            	//((Map)map).put("PAIS_EMBAR_FACT", listFactura.get(0).get("COD_PAISEMBARQUE"));  
	            	((Map)map).put("PAIS_EMBAR_FACT", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, listFactura.get(0).get("COD_PAISEMBARQUE").toString()));
	            	
	            	((Map)map).put("FOB_FACT_SUC", listFactura.get(0).get("MTO_FACT"));
	            }
	            //Fin - PAS20175E220200035
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);

    }

    ModelAndView view = new ModelAndView("ConsultaFacturasSerie");
    view.addObject("params", params);
	        //view.addObject("lstFacturasSerieActual", !CollectionUtils.isEmpty(listaFacturaSerieActual) ? SojoUtil.toJson(listaFacturaSerieActual) : "[]");
	        view.addObject("lstFacturasSerieActual", !CollectionUtils.isEmpty(listaFacturaSerieActualNew) ? SojoUtil.toJson(listaFacturaSerieActualNew) : "[]"); //PAS20175E220200035
    return view;

  }

  /**
   * Metodo que nos permite Obtener y mostrar los datos del Certificado de
   * Origen de una determinada Serie.
   *
   * @param request
   * @param response
   */
  public ModelAndView cargarConsultaCertOrigen(HttpServletRequest request, HttpServletResponse response){

    Map<String, Object> params = new HashMap<String, Object>();
    Map<String, Object> mapCabCertiOrigenRSPTA = new HashMap<String, Object>();

    Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
    List<Map<String, Object>> lstCabCertiOrigenActual = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> listadoDetAutorizacionActual = new ArrayList<Map<String, Object>>();

    try {

      // para que se pueda invoar via GET
      String codAduana = request.getParameter("hdn_cod_aduana") != null ? request.getParameter("hdn_cod_aduana") : this.obtenerAduana(request);
      String annPresen = request.getParameter("hdn_ann_presen") != null ? request.getParameter("hdn_ann_presen") : String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
      String codRegimen = request.getParameter("hdn_cod_regimen") != null ? request.getParameter("hdn_cod_regimen") : "";
      String numDeclaracion = request.getParameter("hdn_num_declaracion") != null ? request.getParameter("hdn_num_declaracion") : "";
      String numCorredoc = request.getParameter("hdn_num_corredoc") != null ? request.getParameter("hdn_num_corredoc") : "";
      String numSecSerie = request.getParameter("hdn_num_secserie") != null ? request.getParameter("hdn_num_secserie") : "";

      // seteamos los valores a Params
      params.put("cod_aduana", codAduana);
      params.put("ann_presen", annPresen);
      params.put("cod_regimen", codRegimen);
      params.put("num_declaracion", numDeclaracion);

      // buscamos en session si existe el certiorigen
      mapCabDeclaraActual = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
      // lstDocAutAsociado y lstCabCertiOrigen estan relacionadas
      if (!CollectionUtils.isEmpty(mapCabDeclaraActual) && !CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstDocAutAsociado"))
          && !CollectionUtils.isEmpty((List) mapCabDeclaraActual.get("lstCabCertiOrigen"))) {

        listadoDetAutorizacionActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstDetAutorizacion");

        String nunSecDoc = ""; // dato necesario para encontrar CertOrigen de la Session
        for (Map<String, Object> mapa : listadoDetAutorizacionActual) {
          if (numSecSerie.trim().equals(mapa.get("NUM_SECSERIE").toString().trim()) && mapa.get("COD_TIPOPER").toString().trim().equals("C")) {
            nunSecDoc = mapa.get("NUM_SECDOC").toString();

          }
        }

       Map<String, Object> mapaPkCertiOrigen = new HashMap<String, Object>();
        mapaPkCertiOrigen.put("NUM_CORREDOC", numCorredoc);
        mapaPkCertiOrigen.put("NUM_SECDOC", nunSecDoc);
        mapaPkCertiOrigen.put("COD_TIPOPER", "C");

        // esta lista obtiene todos los certificados de la declaracion
        lstCabCertiOrigenActual = (List) mapCabDeclaraActual.get("lstCabCertiOrigen");
        // Obtenemos la serie actual seleccionada
        mapCabCertiOrigenRSPTA = Utilidades.obtenerElemento(lstCabCertiOrigenActual, mapaPkCertiOrigen);

        /**Adicionado por pase 42 bug 21558*/
        String seriesAsociadas = ""; 
//      StringBuilder seriesEliminadas = new StringBuilder();
        StringBuilder seriesActivas = new StringBuilder();
        if(!CollectionUtils.isEmpty(mapCabCertiOrigenRSPTA)){
        for (Map<String, Object> mapaDet : listadoDetAutorizacionActual)
        {
          if (Constantes.COD_TIPO_OPERACION_CERTI_ORIGEN.equals(mapaDet.get("COD_TIPOPER").toString())//)//corresponden todas las series que tengan el mismo n�mero de certificado PAS20155E220200192
              && mapCabCertiOrigenRSPTA.get("NUM_SECDOC").toString().equals(mapaDet.get("NUM_SECDOC").toString()))//pase192 dejar activo
          {
            // relaciones activas
             if ("0".equals(mapaDet.get("IND_DEL") != null ? mapaDet.get("IND_DEL").toString() : "0"))
            {
//              if (0 == seriesActivas.toString().trim().length())
//              {
                seriesActivas.append(mapaDet.get("NUM_SECSERIE").toString());
                seriesActivas.append("  ");
//              }
//              else
//              {
//                seriesActivas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());
//              }
            }
//            else
//            {// eliminadas
//              if (0 == seriesEliminadas.toString().trim().length())
//              {
//                seriesEliminadas.append(mapaDet.get("NUM_SECSERIE").toString());
//              }
//              else
//              {
//                seriesEliminadas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());
//
//              }
//
//            }

          }
        }
//        if (seriesActivas.toString().trim().length() > 0)
//        {
//          seriesAsociadas = seriesAsociadas + "Activas:".concat(seriesActivas.toString());
//        }
//        if (seriesEliminadas.toString().trim().length() > 0)
//        {
//          seriesAsociadas = seriesAsociadas + " Eliminadas:".concat(seriesEliminadas.toString());
//
//        }
        seriesAsociadas = seriesActivas.toString();
        mapCabCertiOrigenRSPTA.put("SERIES", seriesAsociadas);
        //PAS20191U220200027 - el pais se debe sacar del det_declara-COD_PAISORIGEN
            Map mapaPkSerie = new HashMap<String, String>();
            mapaPkSerie.put("NUM_CORREDOC", numCorredoc);
            mapaPkSerie.put("NUM_SECSERIE", numSecSerie);        	
            List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(mapaPkSerie, detDeclaraViewList);
            String paisEmbarqueOrigen = detDeclaraViewMap.get("COD_PAISORIGEN") != null ? detDeclaraViewMap.get("COD_PAISORIGEN").toString() : "";        	  
            mapCabCertiOrigenRSPTA.put("COD_PTOEMBORIGEN", paisEmbarqueOrigen);
        }
      /**Fin adicion por pase 42 bug 21558*/
      } else {
        Map mapaPkSerie = new HashMap<String, String>();
        mapaPkSerie.put("NUM_CORREDOC", numCorredoc);
        mapaPkSerie.put("NUM_SECSERIE", numSecSerie);
        // obtiene certificado de origen de la serie de la BD obtiene una lista de 1
        // elemento
        lstCabCertiOrigenActual = this.declaracionService.obtenerCertOrigen(mapaPkSerie);
        if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual)) {
          mapCabCertiOrigenRSPTA = lstCabCertiOrigenActual.get(0);
          //PAS20191U220200027 - el pais se debe sacar del det_declara-COD_PAISORIGEN
          List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
          Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(mapaPkSerie, detDeclaraViewList);
          String paisEmbarqueOrigen = detDeclaraViewMap.get("COD_PAISORIGEN") != null ? detDeclaraViewMap.get("COD_PAISORIGEN").toString() : "";        	  
          mapCabCertiOrigenRSPTA.put("COD_PTOEMBORIGEN", paisEmbarqueOrigen);
        }
      }
    } catch (Exception e) {
      log.error("**** ERROR ****", e);
      MensajeBean mensajeBean = new MensajeBean();
      mensajeBean.setError(true);
      mensajeBean.setMensajeerror("Se ha producido un error inesperador al iniciar la consulta. Por favor intente nuevamente");
      return new ModelAndView("PagM", "beanM", mensajeBean);
    }


    ModelAndView view =null;
    view = new ModelAndView("ConsultaCertOrigen");
    view.addObject("hdn_num_secserie", request.getParameter("hdn_num_secserie"));//p24-PAS20165E220200099
    if(!CollectionUtils.isEmpty(mapCabCertiOrigenRSPTA)){
    String numSecDoc = mapCabCertiOrigenRSPTA.get("NUM_SECDOC").toString();
    String codTipOper = (String) mapCabCertiOrigenRSPTA.get("COD_TIPOPER");

    view.addObject("dua", Utilidades.obtenerTituloDUA(params));
    view.addObject("existeCertificado", mapCabCertiOrigenRSPTA.size() > 0 ? "1" : "0");
    view.addObject("certificadoOrigen", mapCabCertiOrigenRSPTA);
    view.addObject("pk", SojoUtil.toJson(numSecDoc.concat(codTipOper)));
    }else{
    	//inicio gmontoya P24
//      MensajeBean mensajeBean = new MensajeBean();
//      mensajeBean.setError(true);
//      mensajeBean.setMensajeerror("No tiene certificado de origen asociado");//msj actualizado por pase 42 bug 21558
//      return new ModelAndView("PagM", "beanM", mensajeBean);
    	view.addObject("existeCertificado","0");
    	//fin gmontoya P24    	
    }

    return view;
  }

  /** Coloca el estado "Adicionado" a los items que fueron agregados mediante la copia de items
  * @param listaItems
  * @param mapCabDeclara
  * @return [List<Map<String, Object>>]
  * @throws Exception
  */
  private List<Map<String, Object>> colocarEstadoItem(List<Map<String, Object>> listaItems, 
		  													Map<String, Object> mapCabDeclara) throws Exception{
	  
	  if(!CollectionUtils.isEmpty(listaItems)){
		for(Map<String, Object> item : listaItems){

			if(item.get("ind_del").toString().equals("1")){
				item.put("ESTADO", "Eliminado");
			}else{
				Date fechRegisDeclaracion = null;
				if(mapCabDeclara.get("FEC_REGIS")!=null){
					
					fechRegisDeclaracion = Utilidades.toDate(mapCabDeclara.get("FEC_REGIS"));
				}
				Date fechRegItem = Utilidades.toDate(item.get("fec_regis"));

				if(fechRegisDeclaracion!=null){
				if(fechRegItem.compareTo(fechRegisDeclaracion) == 1){
					
					long fechItem = fechRegItem.getTime();
					long fechDeclaracion = fechRegisDeclaracion.getTime();
					long diff = fechItem - fechDeclaracion;

					long diffHours = diff / (60 * 60 * 1000);

					if(diffHours > Constantes.CANT_HORAS_ITEM_ADICION){
						item.put("ESTADO", "Adicionado");
					}else{
						item.put("ESTADO", "");
					}
				}else{
					item.put("ESTADO", "");
				  }
				}
			}
		}  
	  }
	  return listaItems;
  }

	/* P14 - 3014 - Inicio - dhernandezv */
	
	/** Metodo que nos permite Obtener y mostrar las notificaciones 
	 * de una determinada declaracion
	 *
	 * @param request
	 * @param response
	*/
	
	public ModelAndView cargarNotificaciones(HttpServletRequest request, HttpServletResponse response){
		
		ModelAndView modelAndView = new ModelAndView("ConsultaNotificacion");
		Map<String, Object> mapCabDeclara  = null;
		SimpleDateFormat formatoRevisa = new SimpleDateFormat("dd/MM/yyyy");
		final String fechaDefecto = "01/01/0001";
		SimpleDateFormat formatoDestino = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		//SimpleDateFormat formatoDestino = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		String detalleNotificacion;
		
		try {
			
			mapCabDeclara = (Map<String, Object>) WebUtils.getSessionAttribute(request,"mapCabDeclara");
			Map<String, Object> params = new HashMap<String, Object>();
			Map<String, Object> params1 = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC"));
			params1.put("desNota", mapCabDeclara.get("NUM_CORREDOC").toString());
			List<ComunicacionDescripcion> listNotificaciones = diligenciaService.obtenerNotificaciones(params);
			List<Map<String, Object>> listNotificacionesMap =new ArrayList<Map<String,Object>>();
			String notificacionElaboradaPor = "";
			String codAduana= mapCabDeclara.get("COD_ADUANA")!=null? mapCabDeclara.get("COD_ADUANA").toString():"" ;
			
			
			if(!CollectionUtils.isEmpty(listNotificaciones)){
				 
				for (ComunicacionDescripcion comunicacion : listNotificaciones) {
					String codigoNtoficacion= comunicacion.getCodMotNoti()!=null?comunicacion.getCodMotNoti().toString():"";
					if(!codigoNtoficacion.equals("11")){
										
					Map<String,Object> mapComunicacion = new HashMap<String, Object>();
					mapComunicacion.put("COD_USUREGIS", comunicacion.getCodUsuRegistro());
					mapComunicacion.put("COD_MOTNOTI", comunicacion.getCodMotNoti());
					mapComunicacion.put("DES_NOTA", comunicacion.getDesNota());
					mapComunicacion.put("NUM_NOTA", comunicacion.getNumNota());
					
					FiltroCatEmpleado filtro = new FiltroCatEmpleado();
					
					filtro.setCodPers(mapComunicacion.get("COD_USUREGIS").toString());
					
					Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
					CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(mapComunicacion.get("COD_USUREGIS"));
					
					mapComunicacion.put("FUNCIONARIO_ADUANERO",  (catEmpleadoTemp != null) ?
							catEmpleadoTemp.getCodPers() + " - " + catEmpleadoTemp.getApPate()  + " " +
							catEmpleadoTemp.getApMate()  + " " + catEmpleadoTemp.getNombres() : " ");
					
					if(mapComunicacion.get("COD_MOTNOTI")!=null){
						
						detalleNotificacion = catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_MOTIVOS_NOTIFICACION, mapComunicacion.get("COD_MOTNOTI").toString());
						mapComunicacion.put("DES_MOTNOTI", detalleNotificacion);
						
					}else{						
						mapComunicacion.put("COD_MOTNOTI", "");
						mapComunicacion.put("DES_MOTNOTI", "");						
					}
					//<EHR>
					//String duasConFeschaNotificacionVacio = (String) ObjectUtils.defaultIfNull(comunicacion.getFeRecRespNoti(), "");
					log.debug("fecha  	que me trae verificamos ------------->"+comunicacion.getFeRecRespNoti());
					if(comunicacion.getFeRecRespNoti()==null){
						mapComunicacion.put("FEC_RECRESPNOTI", "-");
					}else{
						
						if (fechaDefecto.equals(formatoRevisa.format(comunicacion.getFeRecRespNoti()))) {
							mapComunicacion.put("FEC_RECRESPNOTI", "-");
						} else {
							mapComunicacion.put("FEC_RECRESPNOTI", formatoDestino.format(comunicacion.getFeRecRespNoti()));
						}
					}
					//</EHR>
					
					/*
					if(comunicacion.getFeRecRespNoti()!= null) {
						mapComunicacion.put("FEC_RECRESPNOTI", formatoDestino.format(comunicacion.getFeRecRespNoti()));
					} else {
						mapComunicacion.put("FEC_RECRESPNOTI", "-");
					}
					*/
					if(comunicacion.getFeRegistro()!= null) {
						mapComunicacion.put("FEC_REGIS", formatoDestino.format(comunicacion.getFeRegistro()));
					} else {
						mapComunicacion.put("FEC_REGIS", "-");
					}
					
					listNotificacionesMap.add(mapComunicacion);
				 }
				}
				notificacionElaboradaPor = diligenciaService.obtenerElaborado(codAduana);
			}
			if(!CollectionUtils.isEmpty(listNotificacionesMap)){
				Collections.reverse(listNotificacionesMap);
			}
			Map<String,Object> mapComunicacionBuzonSol = new HashMap<String, Object>();
			int j = 0;
			
			modelAndView.addObject("listNotificaciones",!CollectionUtils.isEmpty(listNotificacionesMap) ? SojoUtil.toJson(listNotificacionesMap) : "");
			modelAndView.addObject("notificacionElaborada",notificacionElaboradaPor);
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			return new ModelAndView("PagM", "beanM", rBean);
			
		} finally {
			
		}
		
		return modelAndView;
		
	}
	
	/** Metodo que nos permite obtener el detalle de notificacion 
	 * de una determinada declaracion
	 *
	 * @param request
	 * @param response
	*/
	
	public ModelAndView cargarDetalleNotificacion(HttpServletRequest request, HttpServletResponse response){
		
		ModelAndView modelAndView = new ModelAndView("DetalleNotificacion");
		
		try {
			
			Map<String, Object> detalleNotificacion = new HashMap<String, Object>();
			
			detalleNotificacion.put("NUM_CORREDOC", request.getParameter("numCorreDoc") != null ? request.getParameter("numCorreDoc") : "");
			detalleNotificacion.put("NUM_NOTA", request.getParameter("numNota") != null ? request.getParameter("numNota") : "");
			Comunicacion comunicacion = comunicacionService.selectNotificacionByID(SunatNumberUtils.toLong(request.getParameter("numNota")));
			detalleNotificacion.put("DES_NOTA",diligenciaService.obtenerConsultaDetalleNotificacion(comunicacion)); //p14 se modifica descripcion de la nota para que se muestre con el detalle.
			String notificacionElaboradaPor = request.getParameter("notificacionElaborada") != null ? request.getParameter("notificacionElaborada") : "";
			detalleNotificacion.put("NRO_DETNOTIF", request.getParameter("nroDetNotif") != null ? request.getParameter("nroDetNotif") : "");
			detalleNotificacion.put("FEC_DETNOTIF", request.getParameter("fechaDetNotif") != null ? request.getParameter("fechaDetNotif") : "");
			detalleNotificacion.put("DES_MOTIDETNOTIF", request.getParameter("desMotiDetNotif") != null ? request.getParameter("desMotiDetNotif") : "");
			detalleNotificacion.put("FUNCIONARIO_DETNOTIF", request.getParameter("funcionarioDetNotif") != null ? request.getParameter("funcionarioDetNotif") : "");
			
			modelAndView.addObject("detalleNotificacion",!StringUtils.isEmpty(detalleNotificacion) ? SojoUtil.toJson(detalleNotificacion) : "");
			modelAndView.addObject("notificacionElaborada",notificacionElaboradaPor);
			
		} catch (Exception e) {
			
			MensajeBean rBean = new MensajeBean();
			rBean.setError(true);
			rBean.setMensajeerror(e.getMessage());
			rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
			log.error("*** ERROR ***", e);
			
			return new ModelAndView("PagM", "beanM", rBean);
		} finally {
			
		}
		
		return modelAndView;
		
	}
	

  /**
   * Sets the formato valor service.
   *
   * @param formatoValorService
   *          the new formato valor service
   */
  public void setFormatoValorService(FormatoValorService formatoValorService)
  {
    this.formatoValorService = formatoValorService;
  }



  /**
   * Sets the declaracion service.
   *
   * @param declaracionService
   *          the new declaracion service
   */
  public void setDeclaracionService(DeclaracionService declaracionService)
  {
    this.declaracionService = declaracionService;
  }

  /**
   * Sets the soporte service.
   *
   * @param soporteService
   *          the new soporte service
   */
  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

  /**
   * Sets the solicitud service.
   *
   * @param solicitudService
   *          the new solicitud service
   */
  public void setSolicitudService(SolicitudService solicitudService)
  {
    this.solicitudService = solicitudService;
  }

  /**
   * Sets the fabrica de servicios.
   *
   * @param fabricaDeServicios
   *          the new fabrica de servicios
   */
  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }

  /**
   * Sets the liquida declaracion service.
   *
   * @param liquidaDeclaracionService
   *          the new liquida declaracion service
   */
  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }

  /**
   * Sets the rectificacion service.
   *
   * @param rectificacionService
   *          the new rectificacion service
   */
  public void setRectificacionService(RectificacionService rectificacionService)
  {
    this.rectificacionService = rectificacionService;
  }

  public void setIncidenciaService(IncidenciaService incidenciaService)
  {
    this.incidenciaService = incidenciaService;
  }

  public void setDeudaService(DeudaService deudaService)
  {
    this.deudaService = deudaService;
  }

  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }

  /* olunar 309 */
  public void setConsultaService(ConsultaService consultaService) {
	this.consultaService = consultaService;
  }
  /* fin */
/*p24 pase 35*/
  public SolicitudDAO getSolicitudDAO() {
		return solicitudDAO;
	}
  
  public void setSolicitudDAO(SolicitudDAO solicitudDAO) {
		this.solicitudDAO = solicitudDAO;
	}
  /* p24 fin pase 35 */
  
/* P28 */
public ModelAndView obtenerItemsCertificadoReposicion(HttpServletRequest request, HttpServletResponse response) throws Exception
{
	
    String annPresen = request.getParameter("hdn_ann_presen") != null ? request.getParameter("hdn_ann_presen") : String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
		
	Map<String,Object> params=new HashMap<String, Object>();
	params.put("dicadu", request.getParameter("hdn_cod_aduana"));
	params.put("difano", annPresen);
	params.put("dindcl", SunatStringUtils.lpad(request.getParameter("hdn_num_declaracion"),6,'0')); //pase433 
	//params.put("dindcl", request.getParameter("hdn_num_declaracion"));	
	params.put("dinser", SunatStringUtils.lpad(request.getParameter("hdn_num_secserie"),4,' ')); // pase433
	//params.put("dinser", request.getParameter("hdn_num_secserie"));
	
	log.info("DICADU "+request.getParameter("hdn_cod_aduana")+", DIFANO "+annPresen+", DINDCL "+request.getParameter("hdn_num_declaracion")+", DINSER "+request.getParameter("hdn_num_secserie"));
	
    CuentaCorrienteReposicionService cuentaCorrienteReposicionService = fabricaDeServicios.getService("sigad.ingreso.CuentaCorrienteReposicionService");

	List<DirfCtaCte> cuentaCorriente=cuentaCorrienteReposicionService.listarCertificadoCuentaCorriente(params);
	
	ModelAndView view = new ModelAndView("ConsultaCertReposicion");
	if(cuentaCorriente.isEmpty()){
		//inicio gmontoya P24
//		MensajeBean mensajeBean = new MensajeBean();
//	    mensajeBean.setError(true);
//	    mensajeBean.setMensajeerror("No se ha encontrado informaci�n del Certificado de Reposici�n");
//	    return new ModelAndView("PagM", "beanM", mensajeBean);
		
		view.addObject("listItemsCertificado",new ArrayList());
		view.addObject("params", params);
		//fin gmontoya P24
	}else{	
		Map<String,Object> params2=new HashMap<String, Object>();		
		params2.put("cerCert", cuentaCorriente.get(0).getRfncer());
		params2.put("cerAdua", cuentaCorriente.get(0).getRfcadu());
		params2.put("cerAnce", cuentaCorriente.get(0).getRffano());
		params2.put("sceItem", cuentaCorriente.get(0).getRfnitem());
		 
		CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
		List<Repocer> listItemsCertificado=certificadoReposicionService.obtenerItemsCertificadoReposicion(params2);
		
		Map<String,Object> mapAduana=new HashMap<String, Object>();
		//P28 FSW
		mapAduana=FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService()
				.getElementoCat("00", SunatStringUtils.lpad(listItemsCertificado.get(0).getCerAdua().toString(), 3, '0') , "01", new Date());
		
		String aduanaDes = mapAduana.get("cod_datacat").toString()+"-"+mapAduana.get("des_datacat").toString();
		
		params.put("cerFvcto", SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromInteger(listItemsCertificado.get(0).getCerFvcto()), "dd/MM/yyyy"));
        //BUG 23498 FSW
        params.put("diElim", cuentaCorriente.get(0).getDiElim());
        params.put("cerNdoi", cuentaCorriente.get(0).getCerNdoi());
        params.put("cerAdua", cuentaCorriente.get(0).getRfcadu());
        params.put("cerCert", cuentaCorriente.get(0).getRfncer());
        params.put("cerAduaDesc", aduanaDes);//gmontoya Pase 99 2016

//		view = new ModelAndView("ConsultaCertReposicion");
        //params.putAll(params);
		view.addObject("listItemsCertificado",listItemsCertificado);
		view.addObject("params", params);
		
	}
	
  return view;
}

/* FIN P28 */
  
public void setVehiCeticoService(VehiCeticoService vehiCeticoService) {
	this.vehiCeticoService = vehiCeticoService;
}

/**
 * Editar serie session.
 *
 * @param request
 *          the request
 * @param response
 *          the response
 * @return the model and view
 * @throws Exception
 *           the exception
 */
public ModelAndView editarSeriePrecedenteSession(HttpServletRequest request, HttpServletResponse response) throws Exception
{
  //Map<String, Object> params = new HashMap<String, Object>();
  //HttpSession session = request.getSession();
  //List listDetalleDuaPrecedente = new ArrayList();
  
  //List lstDetDeclaraActual = (List) session.getAttribute("lstDetPreceDuaActual");

  List<Map<String, Object>> lstDetPreceDuaActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetPreceDuaActual");

  ModelAndView view = new ModelAndView(this.jsonView, "detDeclaraViewMap", lstDetPreceDuaActual);

  return view;
}

/*P24*/
public ModelAndView cargarConsultaProveedor(HttpServletRequest request, HttpServletResponse response) throws Exception{

    ModelAndView res = null;
    Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
    Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    Map<String, Object> datosTMP = (HashMap) WebUtils.getSessionAttribute(request, "mapDatoMod");
    Map<String, Object> datosTMProv = (HashMap) WebUtils.getSessionAttribute(request, "mapDatoModProv");
    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      String num_correDoc = (declaracionActual.get("NUM_CORREDOC") != null) ? declaracionActual
                                                                                               .get("NUM_CORREDOC")
                                                                                               .toString() : "";
      String num_secProve = webRequest.getParameter("hdn_num_secprove");
      Map<String, Object> mapFormBProveedor = null;
      boolean booError = false;
      List<Map> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");

      //amancilla PAS20155E220200089
      if (!isFormatoBCargado(request)) {
        cargaFormatoBCompletoNew(declaracion, declaracionActual, request);
        lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
      }
      //amancilla fin PAS20155E220200089

      if (!CollectionUtils.isEmpty(lstFormBProveedor))
      {
        Map tmpMap;
        for (int i = 0; i < lstFormBProveedor.size(); i++)
        {
          tmpMap = (HashMap) lstFormBProveedor.get(i);
          if (num_secProve.equals(tmpMap.get("num_secprove").toString().trim()))
          {
            mapFormBProveedor = tmpMap;
            break;
          }
        }
        if (!CollectionUtils.isEmpty(mapFormBProveedor))
        {
          if (null == mapFormBProveedor.get("mod_edicion"))
          {
            mapFormBProveedor = this.formatoValorService.obtenerDetalleDAV(num_correDoc, num_secProve);
            mapFormBProveedor.put("mod_edicion", "");

            if(datosTMP!=null){
            	if(datosTMP.get("COD_TIPDOC")!=null){
            		mapFormBProveedor.put("cod_tipdoc_prd",datosTMP.get("COD_TIPDOC"));
            	}if(datosTMP.get("NOM_RAZONSOCIAL")!=null){
            		mapFormBProveedor.put("nom_razonsocial_prd",datosTMP.get("NOM_RAZONSOCIAL"));
            	}if(datosTMP.get("NUM_DOCIDENT")!=null){
            		mapFormBProveedor.put("num_docident_prd",datosTMP.get("NUM_DOCIDENT"));
            	}             	
            	HttpSession session = request.getSession();
                session.removeAttribute("mapDatoMod");
            }
            
            if(datosTMProv!=null){
            	if(datosTMProv.get("NOM_CARGO")!=null){
            		mapFormBProveedor.put("nom_cargo",datosTMProv.get("NOM_CARGO"));
            	}
            	HttpSession session = request.getSession();
                session.removeAttribute("mapDatoModProv");
            }
            
            declaracionActual.put("lstFormBProveedor", lstFormBProveedor);
            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

            Map tmpMap2;
            Map tmpMap3=new HashMap();
            List lstTmp = (ArrayList) declaracion.get("lstFormBProveedor");
            for (int i = 0; i < lstTmp.size(); i++)
            {
              tmpMap2 = (HashMap) lstTmp.get(i);
              tmpMap3.put("cod_tipdoc_prd",tmpMap2.get("cod_tipdoc_prd"));
              tmpMap3.put("nom_razonsocial_prd",tmpMap2.get("nom_razonsocial_prd"));
              tmpMap3.put("num_docident_prd",tmpMap2.get("num_docident_prd"));
              tmpMap3.put("nom_cargo",tmpMap2.get("nom_cargo"));
              
              if (num_secProve.equals(tmpMap2.get("num_secprove").toString().trim()))
              {
                tmpMap2.putAll(Utilidades.copiarMapa(mapFormBProveedor));
                tmpMap2.put("cod_tipdoc_prd",tmpMap3.get("cod_tipdoc_prd"));
                tmpMap2.put("nom_razonsocial_prd",tmpMap3.get("nom_razonsocial_prd"));
                tmpMap2.put("num_docident_prd",tmpMap3.get("num_docident_prd"));
                tmpMap2.put("nom_cargo",tmpMap3.get("nom_cargo"));
                
                break;
              }
            }
            declaracion.put("lstFormBProveedor", lstTmp);
            WebUtils.setSessionAttribute(request, "mapCabDeclara", declaracion);
          
             
          }

          //RIN13
          String tipoIntermediario = (String)mapFormBProveedor.get("cod_tipinterm");
          if(tipoIntermediario != null && !"".equals(tipoIntermediario.trim())){
        	  mapFormBProveedor.put("cod_tipinterm", tipoIntermediario.trim());
          }
          
          //amancilla PAS20155E220200089

          String paginaDefault = "ConsultaDetFormatoValor";
          String estado = declaracionActual.get("COD_ESTDUA").toString();
          String esInvocadoDesdeConsulta = webRequest.getParameter("hdn_acceso")!=null?webRequest.getParameter("hdn_acceso").toString():"";

          if (Constantes.ESTADO_DILIG_PROCESO.equals(estado) && !Constantes.MODO_DILIGENCIA_CONSULTA.equals(esInvocadoDesdeConsulta)){
            paginaDefault = "DetFormatoValor";
          }

          //amancilla esto es para que levante la pantalla dado que es una variable de session que se usa de la consulta
          String camposModificadosFormatoBItemFacturaJSON =  (String) WebUtils.getSessionAttribute(request,"camposModificadosFormatoBItemFactura");
          WebUtils.setSessionAttribute(request,"camposModificadosFormatoBItemFactura",(!StringUtils.isEmpty(camposModificadosFormatoBItemFacturaJSON) ? camposModificadosFormatoBItemFacturaJSON : "[]"));
							
          mapFormBProveedor = (Map<String, Object>) SojoUtil.fromJson(SojoUtil.toJson(mapFormBProveedor).replaceAll("null", "\"\""));
          res = new ModelAndView(paginaDefault, "mapFormBProveedor", mapFormBProveedor);
          //amancilla fin PAS20155E220200089

          res.addObject("series", SojoUtil.toJson(mapFormBProveedor.get("listSeries")));
          res.addObject("declaracion", declaracionActual);
          res.addObject("codDocumentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
          res.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
          res.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
          res.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
          res.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
          // Adaptacion para la regularizacion
          Map datosRecti = (HashMap) WebUtils.getSessionAttribute(request, "mapDatosRectificados");
          if (!CollectionUtils.isEmpty(datosRecti))
          {
            List<Map<String, Object>> lstFormatoBDAV = (datosRecti.get(Constantes.COD_TABLA_FORMB_PROVEEDOR) != null && ((ArrayList) datosRecti
                .get(Constantes.COD_TABLA_FORMB_PROVEEDOR)).size() > 0) ? (ArrayList<Map<String, Object>>) ((ArrayList<Map<String, Object>>) datosRecti
                .get(Constantes.COD_TABLA_FORMB_PROVEEDOR)).get(0) : null;

            if (!CollectionUtils.isEmpty(lstFormatoBDAV))
            {
              List arrayProveedor = new ArrayList();

              for (Map<String, Object> element : lstFormatoBDAV)
              {
                if (num_secProve.equals(element.get("PK").toString().trim()))
                {
                  arrayProveedor.add(element);
                }
              }
              res.addObject("arrayProveedor", SojoUtil.toJson(arrayProveedor));
            }
          }
          res.addObject("acceso", webRequest.getParameter("hdn_acceso"));
          // Fin de la adaptacion para la regularizacion
        }
        else
        {
          booError = true;
        }
      }
      else
      {
        booError = true;
      }
      if (booError)
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror("No se encontro el dato buscado");
        rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
        log.error(this.toString().concat(" cargarDAV - ERROR : ").concat("No se encontro el dato buscado"));
        return new ModelAndView("PagM", "beanM", rBean);
      }
    
    
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
    return res;
}


  public ModelAndView cargarConsultaProveedorInicial(HttpServletRequest request, HttpServletResponse response)
          throws Exception{

    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map<String, Object> mapDetFormatoValor = new HashMap<String, Object>();
    Map pkSerie = new HashMap<String, String>();
    try
    {
      //pkSerie.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
      pkSerie.put("NUM_SECPROVE", webRequest.getParameter("hdn_num_secprove"));
      //pkSerie.put("NUM_FACTURA", webRequest.getParameter("hdn_num_factura"));
      pkSerie.put("NUM_SECFACT", webRequest.getParameter("num_secfac"));
      pkSerie.put("NUM_SECITEM", webRequest.getParameter("hdn_num_secitem"));

      Declaracion declaracionInicialBean = (Declaracion) WebUtils.getSessionAttribute(request, "declaracionInicialBean");

      mapDetFormatoValor = formatoValorService.obtenerFVDetalleInicialOriginal(declaracionInicialBean, pkSerie);

    }
    catch (ServiceException e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
              .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "beanM", rBean);
    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean
              .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }

    ModelAndView view = new ModelAndView("ConsultaDetFormatoValorInicial", "mapDetDeclaracionValor",
            SojoUtil.toJson(mapDetFormatoValor));
    view.addAllObjects(mapDetFormatoValor);
    view.addObject(mapDetFormatoValor);
    view.addObject("series", SojoUtil.toJson(mapDetFormatoValor.get("listSeries")));

    view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen"));
    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
    view.addObject("hdn_num_secitem", webRequest.getParameter("hdn_num_secitem"));
    view.addObject("hdn_num_secprove", webRequest.getParameter("hdn_num_secprove"));
    view.addObject("hdn_num_factura", webRequest.getParameter("hdn_num_factura"));
    view.addObject("hdn_num_secfact", webRequest.getParameter("hdn_num_secfact"));
    view.addObject("indicadorDUAValorProvisional",mapDetFormatoValor.get("indicadorDUAValorProvisional"));//P34

    return view;
  }





  //crear el nuevo metodo:
  private boolean isFormatoBCargado(HttpServletRequest request) {
    Boolean formatoBCargado = (Boolean) WebUtils.getSessionAttribute(request, "formatoBCargado");
    return (formatoBCargado != null);
  }


  /*inicio gdlr399*/
  public void cargaFormatoBCompletoNew(Map<String, Object> declaracion, Map<String, Object> declaracionActual, HttpServletRequest request) {
    log.debug("-->INICIO - cargaFormatoBCompletoNew");

    //Las tablas consultadas son 9: FORMBPROVEEDOR, FORMBMONTO, CONDICION_TRANSA, COMPROB_PAGO, ITEMFACTURA, VFOBPROVISIONAL, SERIES_ITEM, FACTUSUCE, FORMBITEMDESCRI
    //Al parecer no es necesario consultar independientemente la tabla OBSERVACION... se reduce la cantidad de querys a 9
    //Obtenemos una sola vez el num_corredoc del map declaracionActual
    Object numeroCorrelativoAsObject = declaracionActual.get("NUM_CORREDOC");
    if (numeroCorrelativoAsObject == null || numeroCorrelativoAsObject.toString().isEmpty()) {
      //lanzariamos excepcion?
      return;
    }
    //glazaror... se separa logica de carga de formato B en un metodo independiente para mejorar mantenibilidad
    Map<String, Object> cacheListas = cargarInformacionFormatoB(numeroCorrelativoAsObject, declaracionActual, request);
    //extraemos las listas necesarias para trabajarlos mas adelante
    List<Map> proveedores = (List<Map>) cacheListas.get("proveedores");
    Map<String, List<Map<String, Object>>> cacheItemFactura = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheItemFactura");
    Map<String, List<Map<String, Object>>> cacheFobProvisional = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFobProvisional");
    Map<String, List<Map<String, Object>>> cacheSeriesItem = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheSeriesItem");
    Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheDescripcionesMinimas");
    Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturasSucesivas");

    Map<String, Map<String, Object>> cacheMontos = (Map<String, Map<String, Object>>) cacheListas.get("cacheMontos");
    Map<String, Map<String, Object>> cacheCondicionesTransaccion = (Map<String, Map<String, Object>>) cacheListas.get("cacheCondicionesTransaccion");
    Map<String, List<Map<String, Object>>> cacheFacturas = (Map<String, List<Map<String, Object>>>) cacheListas.get("cacheFacturas");

    //empezamos a trabajar con las listas obtenidas anteriormente
    //declaracion.put("lstFormBProveedor", proveedores);
    //declaracionActual.put("lstFormBProveedor", lstActualProveedor);

    if (proveedores != null && proveedores.size() > 0) {
      declaracionActual.put("IND_FORMBPROVEEDOR", "0");// existe formato B
    } else {
      declaracionActual.put("IND_FORMBPROVEEDOR", "1");
    }

    if (proveedores != null) {
      for (Map<String, Object> proveedor : proveedores) {
        Object numeroSecuenciaProveedor = getValue(proveedor, "num_secprove");//al parecer esta en minusculas
        String key = numeroSecuenciaProveedor.toString();

        Map<String, Object> montosByProveedor = cacheMontos.get(key);
        Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(key);
        List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(key);

        //carga montos asociados a cada proveedor
        if (montosByProveedor != null && !montosByProveedor.isEmpty()) {
          proveedor.put("mapFormBMonto", montosByProveedor);
        }
        //carga condiciones de transaccion asociados a cada proveedor
        if (condicionesTransaccionByProveedor != null && !condicionesTransaccionByProveedor.isEmpty()) {
          proveedor.put("mapCondicionTransa", condicionesTransaccionByProveedor);
        }
        //carga facturas asociadas a cada proveedor
        if (facturasByProveedor != null && !facturasByProveedor.isEmpty()) {
          proveedor.put("lstComproBPago", facturasByProveedor);
        }
      }
      for (Map<String, Object> proveedor : proveedores) {
        List<Map<String, Object>> facturasByProveedor = (List<Map<String,Object>>) proveedor.get("lstComproBPago");
        //verificamos si es que el proveedor tiene facturas asociadas
        if (facturasByProveedor != null) {
          for (Map<String, Object> factura : facturasByProveedor) {
            Object numeroSecuenciaProveedorByFactura = getValue(factura, "NUM_SECPROVE");
            Object numeroSecuenciaFactura = getValue(factura, "NUM_SECFACT");

            String keyFactura = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
            List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(keyFactura);
            factura.put("lstItemFactura", itemsFacturaByFactura);

            //verificamos si es que la factura tiene items asociados
            if (itemsFacturaByFactura != null && !itemsFacturaByFactura.isEmpty()) {
              //inicio carga itemsfactura por cada factura de proveedor
              for (Map<String, Object> itemFactura : itemsFacturaByFactura) {
                Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
                Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");
                Object numeroItemByItem = getValue(itemFactura, "NUM_SECITEM");

                //formateamos el numero de secuencia de observacion y la observacion
                Object observacionAsObject = getValue(itemFactura, "OBSERVACION");
                if (observacionAsObject != null) {
                  String[] observacionSplit = observacionAsObject.toString().split("-");
                  String secuenciaObservacion = observacionSplit[0];
                  String observacion = observacionSplit[1];
                  itemFactura.put("OBSERVACION", observacion);
                  itemFactura.put("NUM_SECOBS", secuenciaObservacion);//averiguar en que formato lo usan... por el momento se llena como string...
                }
                //inicio copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional
                String IND_REGISTRO_GRABADO = "0";
                String DES_REGISTRO_GRABADO = "Adicionado";
                itemFactura.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);//valor: "0" (Adicionado)
                itemFactura.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);//valor: "Adicionado"
                itemFactura.put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
                itemFactura.put("IND_DESCMANTITEM", "0");//valor: "0" (no muestra descripcion)
                if (itemFactura.get("IND_DEL").equals("1")) {
                  itemFactura.put("ELIMINADO_PERMANENTE", "BD");
                } else {
                  itemFactura.put("ELIMINADO_PERMANENTE", "");
                }
                //fin copia de metodo: FormatoValorServiceImpl.agregarEstadosItemYlstProvicional

                String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem + "-" + numeroItemByItem;
                List<Map<String, Object>> registrosFobProvisionalByItemFactura = cacheFobProvisional.get(key);
                List<Map<String, Object>> seriesItemsByItemFactura = cacheSeriesItem.get(key);
                List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);

                //carga vfobprovisional, seriesItems y descripciones minimas por itemfactura
                cargarDatosItemFacturaEnLista(itemFactura, registrosFobProvisionalByItemFactura, "lstVfobProvisional");
                cargarDatosItemFacturaEnLista(itemFactura, seriesItemsByItemFactura, "lstSeriesItem");
                cargarDatosItemFacturaEnLista(itemFactura, descripcionesMinimasByItemFactura, "lstDecrMinima");

                //carga referenciaDuda por itemfactura.... pendiente... al parecer ya se quito la consulta a referenciaDuda en el pase 399... verificar
              }
            }
            //fin carga itemsfactura por cada factura de proveedor

            //carga facturas sucesivas
            String key = numeroSecuenciaProveedorByFactura + "-" + numeroSecuenciaFactura;
            List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
            cargarDatosFacturaEnLista(factura, facturasSucesivasByFactura, "lstFactuSucesivas");
          }
        }
      }
    }
    if (proveedores != null) {
      // List<Map> lstActualProveedor = Utilidades.copiarLista(proveedores);
      //amancilla
      List<Map<String, Object>> dstList1 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
      List<Map<String, Object>> dstList2 = (List<Map<String, Object>>) BytesObjectUtils.clone(proveedores);
      declaracion.put("lstFormBProveedor", dstList1);
      declaracionActual.put("lstFormBProveedor", dstList2);
    }
    //gdlr: se carga en sesion un indicador de formato b cargado
    WebUtils.setSessionAttribute(request, "formatoBCargado", true);
    log.info("Fin metodo cargaFormatoBCompletoNew");
  }
  //este metodo fue creado temporalmente... luego revisar los nombres exactos (mayusculas o minusculas)
  private Object getValue(Map<String, Object> datos, String nombre) {
    Object value = datos.get(nombre.toUpperCase());
    if (value == null) {
      value = datos.get(nombre.toLowerCase());
    }
    return value;
  }

  private void cargarDatosFacturaEnLista(Map<String, Object> factura, List<Map<String, Object>> registros, String nombreMapa) {
    if (registros != null && !registros.isEmpty()) {
      factura.put(nombreMapa, registros);
    }
  }


  /** Retorna un boolean que indica si los items eliminados se van a incluir en la consulta (de acuerdo al estado de la declaraci�n)
   * @param declaracionActual
   * @param request
   * @return
   */
  private boolean validarMostrarItemsEliminados(Map<String, Object> declaracionActual, HttpServletRequest request){

    boolean indMostrarEliminados = true;
    String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
    String estadoDua = declaracionActual.get("COD_ESTDUA").toString();
    String estadoRectiOficio = "";
    if ("10".equals(tipoDiligencia))
    {
      if (declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
              && "EN_PROCESO".equals(declaracionActual.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
      {
        estadoRectiOficio = "EN_PROCESO";
      }

    }

    if ((Constantes.ESTADO_RECTI_PROCESO.equals(estadoDua) || "EN_PROCESO".equals(estadoRectiOficio))
            && !(tipoDiligencia.equals(Constantes.MODO_DILIGENCIA_CONSULTA))) {

      indMostrarEliminados = false;
    }

    return indMostrarEliminados;
  }


  /**
   * Carga la informacion de formato B de forma optimizada.
   * @param numeroCorrelativoAsObject numero correlativo de la dua
   * @param declaracionActual map con los datos de dua
   * @param request objeto request
   * @return informacion cargada de formato B en un HashMap
   */
  private Map<String, Object> cargarInformacionFormatoB(Object numeroCorrelativoAsObject, Map<String, Object> declaracionActual, HttpServletRequest request) {
    Long numeroCorrelativo = new Long(numeroCorrelativoAsObject.toString());
    boolean mostrarItemsEliminados = validarMostrarItemsEliminados(declaracionActual, request);

    //Unico map de parametros con el NUM_CORREDOC
    Map<String, Object> parametros = new HashMap<String, Object>();
    parametros.put("NUM_CORREDOC", numeroCorrelativo);

    Map<String, Object> parametrosItemFactura = new HashMap<String, Object>();
    parametrosItemFactura.put("NUM_CORREDOC", numeroCorrelativo);
    if (mostrarItemsEliminados) {
      parametrosItemFactura.put("incluirEliminados", "true");
    }
    //1. FORMBPROVEEDOR
    List<Map> proveedores = formatoValorService.obtenerFVProveedores(parametros);

    //2. FORMBMONTO
    List<Map<String,Object>> montos = formatoValorService.obtenerMontosFormBByDocumento(parametros);
    //3. CONDICION_TRANSA
    List<Map<String,Object>> condicionesTransaccion  = formatoValorService.obtenerCondicionTransaccionFormBByDocumento(parametros);
    //4. COMPROB_PAGO
    List<Map<String, Object>> facturas = formatoValorService.obtenerFacturasProveedor(parametros);
    //5. ITEMFACTURA
    List<Map<String, Object>> itemsFactura = formatoValorService.obtenerItemsFacturaByDocumento(parametrosItemFactura);
    //6. OBSERVACION... no es necesario
    //parametros.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
    //List<Map<String, Object>> observaciones = null;
    //7. VFOBPROVISIONAL
    List<Map<String, Object>> registrosFobProvisional = formatoValorService.obtenerFobProvisionalByDocumento(parametros);
    //8. SERIES_ITEM
    List<Map<String, Object>> seriesItems = serieService.obtenerSeriesItemByDocumento(parametros);
    //9. FACTUSUCE
    List<Map<String, Object>> facturasSucesivas = formatoValorService.selectFactuSuce(parametros);
    //10. FORMBITEMDESCRI
    List<Map<String, Object>> descripcionesMinimas = formatoValorService.selectFormbItemDescri(parametros);
    logger.info("realizadas todas las consultas");

    //glazaror... inicio agrupamiento
    //1. Agrupamos la lista itemsFactura por factura... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheItemFactura = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> itemFactura : itemsFactura) {
      Object numeroSecuenciaProveedorByItem = getValue(itemFactura, "NUM_SECPROVE");
      Object numeroSecuenciaFacturaByItem = getValue(itemFactura, "NUM_SECFACT");

      String key = numeroSecuenciaProveedorByItem + "-" + numeroSecuenciaFacturaByItem;
      List<Map<String, Object>> itemsFacturaByFactura = cacheItemFactura.get(key);
      if (itemsFacturaByFactura == null) {
        itemsFacturaByFactura = new ArrayList<Map<String, Object>>();
        cacheItemFactura.put(key, itemsFacturaByFactura);
      }
      itemsFacturaByFactura.add(itemFactura);
    }
    //2. Agrupamos la lista registrosFobProvisional por itemfactura... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheFobProvisional = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> registro : registrosFobProvisional) {
      Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
      Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
      Object numeroItem = registro.get("NUM_SECITEM");

      String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
      List<Map<String, Object>> fobsProvisionalByItemFactura = cacheFobProvisional.get(key);
      if (fobsProvisionalByItemFactura == null) {
        fobsProvisionalByItemFactura = new ArrayList<Map<String, Object>>();
        cacheFobProvisional.put(key, fobsProvisionalByItemFactura);
      }
      fobsProvisionalByItemFactura.add(registro);
    }
    //3. Agrupamos la lista seriesItems por itemfactura... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheSeriesItem = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> registro : seriesItems) {
      Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
      Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
      Object numeroItem = registro.get("NUM_SECITEM");

      String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
      List<Map<String, Object>> seriesItemByItemFactura = cacheSeriesItem.get(key);
      if (seriesItemByItemFactura == null) {
        seriesItemByItemFactura = new ArrayList<Map<String, Object>>();
        cacheSeriesItem.put(key, seriesItemByItemFactura);
      }
      seriesItemByItemFactura.add(registro);
    }
    //4. Agrupamos la lista descripcionesMinimas por itemfactura... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheDescripcionesMinimas = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> registro : descripcionesMinimas) {
      Object numeroSecuenciaProveedor= registro.get("NUM_SECPROVE");
      Object numeroSecuenciaFactura = registro.get("NUM_SECFACT");
      Object numeroItem = registro.get("NUM_SECITEM");

      String key = numeroSecuenciaProveedor + "-" + numeroSecuenciaFactura + "-" + numeroItem;
      List<Map<String, Object>> descripcionesMinimasByItemFactura = cacheDescripcionesMinimas.get(key);
      if (descripcionesMinimasByItemFactura == null) {
        descripcionesMinimasByItemFactura = new ArrayList<Map<String, Object>>();
        cacheDescripcionesMinimas.put(key, descripcionesMinimasByItemFactura);
      }
      descripcionesMinimasByItemFactura.add(registro);
    }
    //5. Agrupamos la lista facturasSucesivas por factura... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheFacturasSucesivas = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> registro : facturasSucesivas) {
      Object numeroSecuenciaProveedorPorRegistro = registro.get("NUM_SECPROVE");
      Object numeroSecuenciaFacturaPorRegistro = registro.get("NUM_SECFACT");

      String key = numeroSecuenciaProveedorPorRegistro + "-" + numeroSecuenciaFacturaPorRegistro;
      List<Map<String, Object>> facturasSucesivasByFactura = cacheFacturasSucesivas.get(key);
      if (facturasSucesivasByFactura == null) {
        facturasSucesivasByFactura = new ArrayList<Map<String, Object>>();
        cacheFacturasSucesivas.put(key, facturasSucesivasByFactura);
      }
      facturasSucesivasByFactura.add(registro);
    }
    //6. Agrupamos la lista montos por proveedor... solo recorremos una vez la lista
    Map<String, Map<String, Object>> cacheMontos = new HashMap<String, Map<String, Object>>();
    for (Map<String, Object> registro : montos) {
      String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
      Map<String, Object> montosByProveedor = cacheMontos.get(numeroSecuenciaProveedor);
      if (montosByProveedor == null) {
        montosByProveedor = new HashMap<String, Object>();
        cacheMontos.put(numeroSecuenciaProveedor, montosByProveedor);
      }
      montosByProveedor.put(getValue(registro, "COD_MONTO").toString().trim(), getValue(registro, "MTO_VALOR"));
    }
    //7. Agrupamos la lista condicionesTransaccion por proveedor... solo recorremos una vez la lista
    Map<String, Map<String, Object>> cacheCondicionesTransaccion = new HashMap<String, Map<String, Object>>();
    for (Map<String, Object> registro : condicionesTransaccion) {
      String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
      Map<String, Object> condicionesTransaccionByProveedor = cacheCondicionesTransaccion.get(numeroSecuenciaProveedor);
      if (condicionesTransaccionByProveedor == null) {
        condicionesTransaccionByProveedor = new HashMap<String, Object>();
        cacheCondicionesTransaccion.put(numeroSecuenciaProveedor, condicionesTransaccionByProveedor);
      }
      condicionesTransaccionByProveedor.put(getValue(registro, "COD_INDTRANSACCION").toString().trim(), getValue(registro, "IND_TRANSACCION"));
    }
    //8. Agrupamos la lista facturas por proveedor... solo recorremos una vez la lista
    Map<String, List<Map<String, Object>>> cacheFacturas = new HashMap<String, List<Map<String, Object>>>();
    for (Map<String, Object> registro : facturas) {
      String numeroSecuenciaProveedor = getValue(registro, "NUM_SECPROVE").toString();
      List<Map<String, Object>> facturasByProveedor = cacheFacturas.get(numeroSecuenciaProveedor);
      if (facturasByProveedor == null) {
        facturasByProveedor = new ArrayList<Map<String, Object>>();
        cacheFacturas.put(numeroSecuenciaProveedor, facturasByProveedor);
      }
      facturasByProveedor.add(registro);
    }
    //glazaror... fin agrupamiento

    //salvamos en un map la informacion agrupada
    Map<String, Object> cacheListas = new HashMap<String, Object>();
    cacheListas.put("proveedores", proveedores);
    cacheListas.put("cacheItemFactura", cacheItemFactura);
    cacheListas.put("cacheFobProvisional", cacheFobProvisional);
    cacheListas.put("cacheSeriesItem", cacheSeriesItem);
    cacheListas.put("cacheDescripcionesMinimas", cacheDescripcionesMinimas);
    cacheListas.put("cacheFacturasSucesivas", cacheFacturasSucesivas);
    cacheListas.put("cacheMontos", cacheMontos);
    cacheListas.put("cacheCondicionesTransaccion", cacheCondicionesTransaccion);
    cacheListas.put("cacheFacturas", cacheFacturas);

    return cacheListas;
  }

  private void cargarDatosItemFacturaEnLista(Map<String, Object> itemFactura, List<Map<String, Object>> registros, String nombreMapa) {
    if (registros != null && !registros.isEmpty()) {
      //si es que existen registros entonces
      itemFactura.put(nombreMapa, registros);
    }
  }

/*P24 fin*/


//	<RIN10> 3014 ERUESTAA
/**
 * @author ERUESTAA
 * @param request
 * @param response
 * @return
 */
public ModelAndView cargarExpedientes(HttpServletRequest request, HttpServletResponse response){
	if(log.isDebugEnabled())log.debug("cLog: Inicio - Metodo para poblar grilla: cargarLCDUA ");
	ModelAndView result=new ModelAndView("consultaExpedientes");
	try{
		List<Map<String, Object>> listadoExpedientes = null;//velius
		ServletWebRequest webRequest = new ServletWebRequest(request);
		Map<String, Object> params = new HashMap<String, Object>();			
		
		params.put("numCorredoc", webRequest.getParameter("numCorredoc"));
		List<String> tiposSol=new ArrayList<String>(2);
		tiposSol.add(Constantes.COD_TIPO_SOLICITUD_PRORROGA);
		tiposSol.add(Constantes.COD_TIPO_SOLICITUD_AMPLIACION);
		params.put("tiposSol", tiposSol);
		
		if(log.isDebugEnabled())log.debug("Llamando al servicio: <declaracionService.listarExpedientes>");			
		if(log.isDebugEnabled())log.debug("Parametros: [("+webRequest.getParameter("numCorredoc")+"),("+Constantes.COD_TIPO_SOLICITUD_PRORROGA+"),("+Constantes.COD_TIPO_SOLICITUD_AMPLIACION+")]");
		listadoExpedientes = declaracionService.listarExpedientes(params);
		if(log.isDebugEnabled())log.debug("Listado : "+ SojoUtil.toJson(listadoExpedientes));
		result.addObject("listaresultados",SojoUtil.toJson(listadoExpedientes));		
	
	}catch (Exception e) {
		log.error(e,e);
		if(log.isDebugEnabled())log.debug("cxLog: Cayo el Controlador - Metodo: cargarExpedientes");
		log.error(e.getStackTrace());
	}
	if(log.isDebugEnabled())log.debug("cLog: Fin - Metodo : cargarExpedientes");
	return result;
}

	private String duaTieneIndicadorVP(String numCorreDocConsultado){
		DatoIndicadores indicadorDUA = new DatoIndicadores();
		indicadorDUA = declaracionService.obtenerIndicadorDeclaracion(numCorreDocConsultado, COD_INDICADOR_VP);
		String indicadorDuaValorProvisional = "NO";
		indicadorDuaValorProvisional = (indicadorDUA==null)?"NO":"SI";	
		return indicadorDuaValorProvisional;	
	}

	//ggranados pase comunicacion
	public void setComunicacionService(ComunicacionService comunicacionService) {
		this.comunicacionService = comunicacionService;
	}
	//P24 Inicio
	 /**
	   * <p>
	   * Iniciamos la consulta de rectificaciones de la dua.
	   * </P>
	   * <p>
	   * los parametros de ingreso son los datos de la dua en formato json
	   * {"codAduana":"046","anioDua":2012,"codRegimen":"10","numDeclaracion":45}.
	   * </p>
	   *
	   * @param request
	   *          [HttpServletRequest] request
	   * @param response
	   *          [HttpServletResponse] response
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  public ModelAndView initConsultaRectificacion(HttpServletRequest request, HttpServletResponse response)
	  {

	    ModelAndView view = new ModelAndView("ConsultaRectificacionesDAM");//gmontoya Pase 99 2016

	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    String uniqueKeyDuaAsJson = ObjectUtils.toString(webRequest.getParameter("uniqueKeyDua"), "");
	    Object numeroCorrelativoDua = webRequest.getParameter("numeroCorrelativoDua");    
	    
	    /*Inicio PAS20155E220200089*/
	    String numeroDeclaracionTitulo = webRequest.getParameter("numeroDeclaracionTitulo");
	    WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);
	    /*Fin PAS20155E220200089*/
	    try
	    {
	      validarUniqueKeyDua(uniqueKeyDuaAsJson);

	      Map data = new HashMap<String, Object>();
	      data.put("uniqueKeyDua", uniqueKeyDuaAsJson);
	      data.put("numeroCorrelativoDua", numeroCorrelativoDua);

	      return enviarData(view, data);
	    }
	    catch (IllegalArgumentException e)
	    {
	      view = new ModelAndView("PagM");
	      log.info("**** ERROR de Validacion ****", e);
	      return lanzarError(view, e.getMessage());
	    }
	    catch (Exception e)
	    {
	      view = new ModelAndView("PagM");
	      log.error("**** ERROR de aplicacion ****", e);
	      return lanzarError(view, "Ocurrio un error inesperado");
	    }

	  }
	 /**
	   * Consulta los datos rectificacods para una determinada Dua.
	   *
	   * @param request
	   *          [HttpServletRequest] request
	   * @param response
	   *          [HttpServletResponse] response
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  public ModelAndView consultaDatosRectificados(HttpServletRequest request, HttpServletResponse response)
	  {

	    ModelAndView view = new ModelAndView(jsonView);

	    ServletWebRequest webRequest = new ServletWebRequest(request);

	    String diligenciaJson = ObjectUtils.toString(webRequest.getParameter("diligencia"), "");
	    try
	    {
	      // validamos que se envie los parametros de busqueda
	      Diligencia diligencia = validarConsultaDetalle(diligenciaJson);
		  //Inicio: lmvr - Complemento de la diligencia de Rectificacion
	      Long numeroCorrelativoSolicitud = diligencia.getNumeroCorrelativoSolicitud();
	      SolicitudRectifica solicitudRectifica = new SolicitudRectifica();
	      solicitudRectifica.setNumeroCorrelativo(numeroCorrelativoSolicitud);
	      
	      SolicitudRectificaService solicitudRectificaService = fabricaDeServicios.getService("despaduanero2.solicitudRectificaService");
	      List<SolicitudRectifica> list=   solicitudRectificaService.findSolicitudRectificacion(solicitudRectifica);
	      List<DatoRectificado> lstDatoRectificado= null;
	      String codEstadorecti= list.get(0).getEstadoRectificacion();
    	  if("01".equals(codEstadorecti)||"02".equals(codEstadorecti)||"03".equals(codEstadorecti)||"04".equals(codEstadorecti)){//PAS20155E220200191  
	    	   //SolicitudRectificacionesService solicitudRectificacionesService = fabricaDeServicios.getService("solicitudRectificacionesService");
	           //lstDatoRectificado = solicitudRectificacionesService.listarDatosRectificadosBySolicitud(numeroCorrelativoSolicitud);
	           ConsultaRectificacionService consultaRectificacionService = fabricaDeServicios.getService("diligencia.rectificacion.consultaRectificacionService");
	           lstDatoRectificado = consultaRectificacionService.consultaDatosRectificacionAutomatica(numeroCorrelativoSolicitud);  
	      }else{
	          // buscamos en det ofirecti
	            ConsultaRectificacionService consultaRectificacionService = fabricaDeServicios.getService("diligencia.rectificacion.consultaRectificacionService");
	            lstDatoRectificado = consultaRectificacionService.consultaDatosRectificados(diligencia);  
	      }
		   //Fin: lmvr - Complemento de la diligencia de Rectificacion
	      Map data = new HashMap<String, Object>();
	      data.put("lstDatoRectificado", lstDatoRectificado);

	      List<Class> lsitClasesTofilterId = new ArrayList<Class>();
	      lsitClasesTofilterId.add(DatoRectificado.class);
	      return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm a");

	    }
	    catch (ServiceException e)
	    {
	      log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
	      return lanzarError(view, e.getMensaje().toString());
	    }
	    catch (IllegalArgumentException e)
	    {
	      log.error("**** ERROR de Validacion ****", e);
	      return lanzarError(view, e.getMessage());
	    }
	    catch (Exception e)
	    {
	      log.error("**** ERROR de aplicacion ****", e);
	      return lanzarError(view, "Ocurrio un error inesperado");
	    }

	  }
	 /**
	   * Consulta el detalle de la diligencia: codigo funcionario, descripcion del
	   * resultado, fecha de la diligencia.
	   *
	   * @param request
	   *          [HttpServletRequest] request
	   * @param response
	   *          [HttpServletResponse] response
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  public ModelAndView consultaDetalleDiligencia(HttpServletRequest request, HttpServletResponse response)
	  {
	    ModelAndView view = new ModelAndView(jsonView);

	    ServletWebRequest webRequest = new ServletWebRequest(request);

	    String diligenciaJson = ObjectUtils.toString(webRequest.getParameter("diligencia"), "");
	    try
	    {

	      Diligencia diligencia = validarConsultaDetalle(diligenciaJson);
			ConsultaRectificacionService consultaRectificacionService = fabricaDeServicios
					.getService("diligencia.rectificacion.consultaRectificacionService");
	      diligencia = consultaRectificacionService.consultaDiligencia(diligencia);

	      Map data = new HashMap<String, Object>();
	      data.put("diligencia", diligencia);
	      List<Class> lsitClasesTofilterId = new ArrayList<Class>();
	      lsitClasesTofilterId.add(Diligencia.class);
	      return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm a");

	    }
	    catch (ServiceException e)
	    {
	      log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
	      return lanzarError(view, e.getMensaje().toString());
	    }
	    catch (IllegalArgumentException e)
	    {
	      log.error("**** ERROR de Validacion ****", e);
	      return lanzarError(view, e.getMessage());
	    }
	    catch (Exception e)
	    {
	      log.error("**** ERROR de aplicacion ****", e);
	      return lanzarError(view, "Ocurrio un error inesperado");
	    }
	  }
	  /**
	   * <p>
	   * Busca las diligencias de rectificaciones realizadas a una dua.
	   * </P>
	   * <p>
	   * realiza la busqueda de rectificaciones y devuelve un json con las
	   * rectificaciones realidas a la DUA.
	   * </p>
	   * <p>
	   * los parametros de ingreso son los datos de la dua en formato json
	   * {"codAduana":"046","anioDua":2012,"codRegimen":"10","numDeclaracion":45}.
	   * </p>
	   *
	   * @param request
	   *          [HttpServletRequest] request
	   * @param response
	   *          [HttpServletResponse] response
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  public ModelAndView consultaRectificacion(HttpServletRequest request, HttpServletResponse response)
	  {

	    ModelAndView view = new ModelAndView(jsonView);

	    ServletWebRequest webRequest = new ServletWebRequest(request);

	    String uniqueKeyDuaAsJson = ObjectUtils.toString(webRequest.getParameter("uniqueKeyDua"), "");
	    try
	    {

	      // validamos que se envie los parametros de busqueda
	      UniqueKeyDua uniqueKeyDua = validarUniqueKeyDua(uniqueKeyDuaAsJson);
	      Map<String, Object> paramCab = uniqueKeyDua.toHasMap();
	      DUA dua = RectificacionServiceImpl.getInstance().getCabdeclaraDAO().findDUAByKeyMap(paramCab);
	      Validate.notNull(dua, " La dua no se encuentra registrada en el sistema");
	      Long numeroCorrelativoDua = dua.getNumcorredoc();// new
	                                                       // BigDecimal(ObjectUtils.toString(webRequest.getParameter("hdn_num_corredoc"),"0"));
	      Validate.notNull(numeroCorrelativoDua, " La dua no se encuentra registrada en el sistema");

	      ConsultaRectificacionService consultaRectificacionService = fabricaDeServicios.getService("diligencia.rectificacion.consultaRectificacionService");

	      List<SolicitudRectifica> lstRectificaciones = consultaRectificacionService.consultaDiligenciaRectificacion(numeroCorrelativoDua);

		  for (SolicitudRectifica solRecti :lstRectificaciones){
			    solRecti.setCodFuncionarioAsignado("");
				solRecti.setDescFuncionarioAsignado("");
				AsignacionManualService asignacionManualService = fabricaDeServicios.getService("Asignacion.asignacionManualService");
			    //EspeDocu espeDocu = new EspeDocu();
				//espeDocu.setNumCorreDoc(solRecti.getNumeroCorrelativo());
				//EspeDocuDAO espeDocuDAO = (EspeDocuDAO) fabricaDeServicios.getService("asignacion.espeDocuDAO");
				StringBuffer datosFuncionarioAsignado = new StringBuffer("");
				FiltroEspeDocu filtroDocu = new FiltroEspeDocu();
				filtroDocu.setNumCorreDoc(solRecti.getNumeroCorrelativo()); // NUM_CORREDOC de la rectificaci�n.
			    filtroDocu.setIndicadorUltimoRegistro(1);
			    EspeDocu listadoDocu = asignacionManualService.consultarEspeDocuSolRect(filtroDocu);
				
				if (listadoDocu != null && listadoDocu.getEspeDispo()!=null && listadoDocu.getEspeDispo().getEspeDespa()!=null && listadoDocu.getEspeDispo().getEspeDespa().getCatEmpleado()!=null) {
					//String codFuncionario = listadoDocu.getCodFuncionario();
					CatEmpleado catEmpleado = listadoDocu.getEspeDispo().getEspeDespa().getCatEmpleado();
					String codFuncionario = catEmpleado.getCodPers();
//					FiltroCatEmpleado filtro = new FiltroCatEmpleado();
//					filtro.setCodPers(codFuncionario);
//					CatEmpleadoDAO catEmpleadoDAO = (CatEmpleadoDAO) fabricaDeServicios.getService("asignacion.catEmpleadoDAO");
//					CatEmpleado catEmpleado = catEmpleadoDAO.consultarCatEmpleado(filtro);
					datosFuncionarioAsignado
					.append(catEmpleado.getApPate().trim())
					.append(" ")
					.append(catEmpleado.getApMate().trim())
					.append(", ")
					.append(catEmpleado.getNombres().trim());	
					
					solRecti.setCodFuncionarioAsignado(codFuncionario);
					solRecti.setDescFuncionarioAsignado(datosFuncionarioAsignado.toString());
					
					
				}
		  		
		 }		

	      Map data = new HashMap<String, Object>();
	      data.put("lstRectificaciones", lstRectificaciones);
	      data.put("numeroCorrelativoDua", numeroCorrelativoDua);

	      List<Class> lsitClasesTofilterId = new ArrayList<Class>();
	      lsitClasesTofilterId.add(SolicitudRectifica.class);
	      return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm:a");

	    }
	    catch (ServiceException e)
	    {
	      log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
	      return lanzarError(view, e.getMensaje().toString());
	    }
	    catch (IllegalArgumentException e)
	    {
	      log.error("**** ERROR de Validacion ****", e);
	      return lanzarError(view, e.getMessage());
	    }
	    catch (Exception e)
	    {
	      log.error("**** ERROR de aplicacion ****", e);
	      return lanzarError(view, "Ocurrio un error inesperado");
	    }

	  }
	  
	  /**
	   * Envia el response estandar haciendo uso de la clase MensajeBean si es que
	   * este se produce.
	   *
	   * @param view
	   *          [ModelAndView] view
	   * @param data
	   *          [Map<String,Object>] data
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  private ModelAndView enviarData(ModelAndView view, Map<String, Object> data)
	  {
	    MensajeBean rBean = new MensajeBean();
	    rBean.setError(false);
	    rBean.setData(data);

	    return view.addObject("beanM", rBean);
	  }

	  /**
	   * Retorna el json al cliente.
	   *
	   * @param data
	   *          data con la informacion a mostrar
	   * @param listClasesTofilterId
	   *          [List<Class>] list clases tofilter id
	   * @param dateFormat
	   *          formato de la fecha el cual tendran las clases de tipo date
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  private ModelAndView enviarJsonData(Map<String, Object> data, List<Class> listClasesTofilterId, String dateFormat)
	  {
	    ModelAndView view = new ModelAndView(jsonView);
	    view.addObject("listClasesTofilterId", listClasesTofilterId);
	    view.addObject("formatoFecha", dateFormat);
	    return enviarData(view, data);
	  }
	  /**
	   * Envia el error estandar haciendo uso de la clase MensajeBean si es que este
	   * se produce.
	   *
	   * @param view
	   *          [ModelAndView] view
	   * @param mensaje
	   *          [String] mensaje
	   * @return [ModelAndView] model and view
	   * @version 1.0
	   */
	  private ModelAndView lanzarError(ModelAndView view, String mensaje)
	  {
	    MensajeBean rBean = new MensajeBean();
	    rBean.setError(true);
	    rBean.setMensajeerror(mensaje);
	    rBean.setMensajesol(MENSAJE_SOLUCION_ERROR);
	    return view.addObject("beanM", rBean);
	  }
	  /**
	   * Validar consulta detalle.
	   *
	   * @param diligenciaJson
	   *          [String] diligencia json
	   * @return [Diligencia] diligencia
	   * @version 1.0
	   */
	  private Diligencia validarConsultaDetalle(String diligenciaJson)
	  {
	    // eliminamos los espacios en blanco
	    diligenciaJson = org.apache.commons.lang.StringUtils.remove(diligenciaJson, " ");
	    Validate.notEmpty(diligenciaJson, "los parametros de busqueda no deben de estar vacios");
	    Diligencia diligencia = (Diligencia) serializer.deserialize(diligenciaJson, Diligencia.class);
	    return diligencia;
	  }
	  /**
	   * Valida que los para metros de la busqueda sean los correctos de lo
	   * contrario lanza una RuntimeException.
	   *
	   * @param duaJson
	   *          [String] dua json
	   * @return retorna el UniqueKey validado
	   * @version 1.0
	   */
	  private UniqueKeyDua validarUniqueKeyDua(String duaJson)
	  {
	    // eliminamso los espacios en blanco
	    duaJson = org.apache.commons.lang.StringUtils.remove(duaJson, " ");
	    Validate.notEmpty(duaJson, "los parametros de busqueda no deben de estar vacios");
	    UniqueKeyDua uniqueKeyDua = (UniqueKeyDua) serializer.deserialize(duaJson, UniqueKeyDua.class);
	    String jsonRequerido = uniqueKeyDua.toString();
	    Validate.isTrue(jsonRequerido.toString().equals(duaJson),
	                    "los parametros enviamos no concuerdan con el formato requerido, enviado (" + duaJson
	                        + ") requerido ("
	                        + jsonRequerido
	                        + "), cambiar los valores null por el valor que se desea enviar.");
	    Validate.isTrue(uniqueKeyDua.isValidUniqueKey(), "los parametros unicos no deben de contener nulos: (" + duaJson
	                                                     + ")");

	    return uniqueKeyDua;
	  }
	  
	 public ModelAndView cargarPorrogas(HttpServletRequest request, HttpServletResponse response)
		  {
			 ServletWebRequest webRequest = new ServletWebRequest(request); 
			String strNumcorredoc = webRequest.getParameter("hdn_num_corredoc");
		    List<Map<String, Object>> listado = null;
		    Map pkDocu = new HashMap<String, String>();
		    try
		    {
		      pkDocu.put("NUM_CORREDOC_PRE", strNumcorredoc);
		      DeclaracionService declaracionService =(DeclaracionService)fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
		      listado = declaracionService.obtenerPlazosProcesoConclusion(pkDocu);
		      
		      SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
		      
		      if (!CollectionUtils.isEmpty(listado))
		      {
		    	  CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		    	  Map jsonMotivo ;    	  
		          for(Map<String,Object> map : listado){
		        	  String desMotivo = map.get("DES_MOTIVO")!=null?String.valueOf(map.get("DES_MOTIVO")):"";	        	  
		        	  jsonMotivo = (desMotivo.trim().isEmpty())?new HashMap():(Map)SojoUtil.fromJson(desMotivo);
		        	  String[] valores = jsonMotivo.get("amoti")!=null?String.valueOf(jsonMotivo.get("amoti")).split(","):new String[0];
		        	  String motivos = "";
		        	  for (String valor:valores){
		        		  valor = valor.substring(valor.indexOf("=")+1, valor.indexOf("=")+3);        		  
		        		  if(!motivos.isEmpty()){
		        			  motivos = motivos.concat(",");
		        		  }
		        		  motivos = motivos.concat(catalogoAyudaService.getDescripcionDataCatalogo("357", valor));
		        	  }
		        	  map.put("MOTIVOS", motivos);
		        	  
		        	  FiltroCatEmpleado filtro = new FiltroCatEmpleado();
		        	  filtro.setCodPers(String.valueOf(map.get("COD_USUREGIS")));	
		        	  Map<String, CatEmpleado> mapCatEmpleado = solicitudService.buscarMapCatEmpleado(filtro);
		        	  CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(String.valueOf(map.get("COD_USUREGIS")));	
		        	  map.put("FUNCIONARIO_ADUANERO", (catEmpleadoTemp != null) ? 
								catEmpleadoTemp.getCodPers() + " - " + catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " " + catEmpleadoTemp.getNombres() : " ");
		        	  
		        	  
		        	  map.put("FEC_REGIS",map.get("FEC_REGIS")!=null?sd.format((Date)map.get("FEC_REGIS")):"");
		        	  map.put("FEC_MODIF",map.get("FEC_APROBADA")!=null?sd.format((Date)map.get("FEC_APROBADA")):"");
		        	  map.put("FEC_PROPUESTA",map.get("FEC_PROPUESTA")!=null?sd.format((Date)map.get("FEC_PROPUESTA")):"");

		          }
		          
		      }
		    return new ModelAndView(this.jsonView, "datamodel", listado);
		  }catch (Exception e)
		  {
		    MensajeBean rBean = new MensajeBean();
		    rBean.setError(true);
		    rBean.setMensajeerror(e.getMessage());
		    rBean
		        .setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
		    log.error("*** ERROR ***", e);
		    return new ModelAndView("PagM", "beanM", rBean);
		  }		
		  }
		 
		 
		 /**
			 * Mostrar los datos de la conclusion de despacho
			 * 		 
			 * RIN P21-P22 
			 * @param request
			 * @param response
			 * @return ModelAndView
			 */
			  public ModelAndView cargarConsultaConclusionDespacho(HttpServletRequest request, HttpServletResponse response) throws Exception{
					ModelAndView modelAndView = new ModelAndView();
					final String DEFAULT_TIPO_DOC = "01"; //P24
					modelAndView = new ModelAndView("ConsultaDiligenciaConclusion");
					String numCorredocDesc = request.getParameter("num_corredoc");
				    String codAduana= request.getParameter("aduana");
				    String annPresen= request.getParameter("anio");
				    String codRegimen= request.getParameter("regimen");
				    String numDeclaracion= request.getParameter("numero");
				    String estadovisualNLGA= request.getParameter("estadovisualNLGA");//PAS20165E220200032
				        Map<String, Object> params = new HashMap<String, Object>();
						params.put("NUM_DECLARACION", numDeclaracion);
						params.put("COD_ADUANA", codAduana);
						params.put("ANN_PRESEN", annPresen);
						params.put("COD_REGIMEN", codRegimen);
						DeclaracionService declaracionService =(DeclaracionService)fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
					    Map<String, Object> declaracion =declaracionService.obtenerDeclaracion(params);
					    
					    String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracion, DEFAULT_TIPO_DOC); //P24
					    
					    
					try{
						estadovisualNLGA=estadovisualNLGA!=null?estadovisualNLGA:"1";			
						String num_corredoc = (String)request.getParameter("num_corredoc");				
						declaracion.put("estadovisualNLGA", estadovisualNLGA!=null?estadovisualNLGA:"1");//PAS20165E220200032 2-espostlevante 
						Map<String,Object> respuesta = declaracionConsultaService.obtenerDetalleConsultaConclusion(declaracion,num_corredoc);
						List<Map<String, Object>> listaProrroga =(List<Map<String, Object>>) respuesta.get("PRORROGAS_LISTA");
						
						modelAndView.addObject("detalleConclusionMap", respuesta);
						modelAndView.addObject("listaProrroga", listaProrroga);
						WebUtils.setSessionAttribute(request, "detalleConclusionMap", respuesta);
						WebUtils.setSessionAttribute(request, "numeroDeclaracionTitulo", numeroDeclaracionTitulo);//P24
						
		
					}catch(Exception e){
						MensajeBean mensajeBean = new MensajeBean();
						mensajeBean.setError(true);
						mensajeBean.setMensajeerror(e.getMessage());
						mensajeBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
						log.error("consultarPlazoConclusion - ERROR : " +e.getMessage());
						return new ModelAndView("PagM", "beanM", mensajeBean);
					}
									
					modelAndView.addObject("hdn_num_corredoc", numCorredocDesc);
					modelAndView.addObject("hdn_cod_aduana", codAduana);
					modelAndView.addObject("hdn_ann_presen", annPresen);
					modelAndView.addObject("hdn_cod_regimen", codRegimen);
					modelAndView.addObject("hdn_num_declaracion", numDeclaracion);
					
					if (log.isDebugEnabled()) {
						log.debug(this.toString().concat("- ConsultaConclusionDespacho() -FIN"));
					}
					
					modelAndView.addObject("estadovisualNLGA", estadovisualNLGA); //PAS20165E220200032
					WebUtils.setSessionAttribute(request, "estadovisualNLGA", estadovisualNLGA); //PAS20165E220200032					
					
					return modelAndView;
				}
	
		public DeclaracionConsultaService getDeclaracionConsultaService() {
			return declaracionConsultaService;
		}
		public void setDeclaracionConsultaService(
				DeclaracionConsultaService declaracionConsultaService) {
			this.declaracionConsultaService = declaracionConsultaService;
		}
		
		public ResolucionService getResolucionService() {
			return resolucionService;
		}

		public void setResolucionService(ResolucionService resolucionService) {
			this.resolucionService = resolucionService;
		}		
		
		//P24 Fin

	//PAS20155E410000032 - Inicio
	/**
	 * Verifica si una DAM tiene mercancia en franquicia
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView tieneMercanciaFranquicia(HttpServletRequest request, HttpServletResponse response){
		ModelAndView res = new ModelAndView(this.jsonView);
	    boolean damTieneMercanciaFranquicia = false;
	    
	    try {
	    	Map mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
	    	damTieneMercanciaFranquicia =  this.declaracionService.validarDamTieneMercanciaFranquicia(
	    			SunatNumberUtils.toLong(mapCabDeclaraActual.get("NUM_CORREDOC")));
	    } catch (Exception e) {
	    	
	      MensajeBean rBean = new MensajeBean();
	      rBean.setError(true);
	      rBean.setMensajeerror(e.getMessage());
	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
	      log.error("*** ERROR ***", e);
	      res.addObject("beanM", rBean);
	    }
	    
	    res.addObject("damTieneMercanciaFranquicia", damTieneMercanciaFranquicia);

	    return res;
	}
	//PAS20155E410000032 - Fin	

	//gg vuce
	public ModelAndView cargarConsultaDocumentoVuce(HttpServletRequest request, HttpServletResponse response){
		MercanciaRestringidaEntidadService restringidaService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");
		String codTipo = request.getParameter("codTipo");
        String codRegimen = request.getParameter("codRegimen");
        String numSecSerie = request.getParameter("numSecSerie");
        String numCorreDoc = request.getParameter("numCorreDoc");
		Long numDoc = SunatNumberUtils.toLong(request.getParameter("numDoc"));
        ModelAndView res = new ModelAndView(this.jsonView);

        try {
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());
            String rastro = bUsuario.getNombreCompleto()+" registro:"+bUsuario.getNroRegistro();
            DocControlMercRestringidaVuce docVuce = restringidaService.obtenerDocumentoVuce(numDoc, codTipo, rastro);

            /*adicionado por docs que no tienen razon social registrada*/
            if(docVuce != null && SunatStringUtils.isEmptyTrim(docVuce.getTitularDRVuce().getRazonSocial())){
                Map<String, Object> persona = new HashMap<String, Object>();
                persona = ((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur(docVuce.getTitularDRVuce().getTipoDocumento(), docVuce.getTitularDRVuce().getNumeroDocumento());
                if (!persona.get("nombre").toString().isEmpty()){
                    docVuce.getTitularDRVuce().setRazonSocial(persona.get("nombre").toString().trim());
                }
            }

            if (docVuce != null && !SunatStringUtils.isEmptyTrim(docVuce.getNroEntidadesByCutmayoraUno()) && SunatNumberUtils.toInteger(docVuce.getNroEntidadesByCutmayoraUno()) > 1){
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("NUM_CORREDOC", numCorreDoc);
                params.put("NUM_SECSERIE", numSecSerie);
                List<Map<String, Object>> detDeclaraViewList = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
                Map<String, Object> detDeclaraViewMap = serieService.obtenerSerieSession(params, detDeclaraViewList);
                String numPartida = detDeclaraViewMap.get("NUM_PARTNANDI") != null ? detDeclaraViewMap.get("NUM_PARTNANDI").toString() : "";

                List<String> listSubEntidadesMrestri = restringidaService.obtenerRegistrosPorBusquedaMrestri( numPartida , SunatDateUtils.getCurrentDate(), codRegimen, null);
                List<String> listSuEntidadesCut= restringidaService.obtenerSubentidadesPorCut(SunatStringUtils.toStringObj(docVuce.getNumeroCUT()), SunatDateUtils.getCurrentDate());
                String codSubEntidadMrestri = restringidaService.obtenerRegistroPorCut(listSuEntidadesCut, listSubEntidadesMrestri);
                docVuce.setSubEntidad(codSubEntidadMrestri);
                docVuce.setSubEntidadDesc(diligenciaService.obtenerDescripcionCatalogo(Constantes.COD_CATALOG_CODIGO_SUBENTIDAD, codSubEntidadMrestri));
            }

            /*adicionado por docs que no tienen razon social registrada*/
            res.addObject("docVuceJson", docVuce);

//region amancillaa VUCE-RIN04
           WebUtils.setSessionAttribute(request, "lstArchivosAnexos", docVuce.getLstArchivosAnexos());

          //endregion amancillaa
        } catch (Exception e) {
            log.error("cargarConsultaDocumentoVuce", e);
            MensajeBean mError = new MensajeBean();
            mError.setError(true);
            mError.setMensajeerror(e.getMessage());
            mError.setMensajesol("Ocurrio un error al obtener la informacion del documento de control autorizante, por favor vuelva a consultarlo.");
            res.addObject("error", mError);
        }
        return res;
	}

 public ModelAndView cargarPDFVUCE(HttpServletRequest request,
                                                    HttpServletResponse response){
	 	MercanciaRestringidaEntidadService restringidaService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");//carga a demanda

        try {
            List<ArchivoAnexoDocControlMR> lstArchivosAnexos = (ArrayList<ArchivoAnexoDocControlMR>) WebUtils.getSessionAttribute(request, "lstArchivosAnexos");
            String codigoIdDocAdjunto = request.getParameter("codigoIdDocAdjunto") != null ? request.getParameter("codigoIdDocAdjunto") : "";

            String numeroDocumentoControl = request.getParameter("numeroDocumentoControl") != null?
            		request.getParameter("numeroDocumentoControl").toString(): "";
            UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
            UserNameHolder.set(bUsuario.getNroRegistro());
            String rastro = bUsuario.getNombreCompleto() + " registro:" + bUsuario.getNroRegistro();
            File archivoPDF = null;
            for(ArchivoAnexoDocControlMR archivo:  lstArchivosAnexos){
                if (codigoIdDocAdjunto.equals(archivo.getCodigoIdDocAdjunto())) {
                    String rutaDestino = "/data1/vuce/envios/anexospdf/temporal/";
                    restringidaService.obtenerArchivoPDF(archivo, numeroDocumentoControl, rastro);
                    archivoPDF = Utilidades.grabarArchivoTemporal(archivo.getArchivoDocAdjunto(), rutaDestino);
                    break;
                }
            }
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + archivoPDF.getName() + "\"");

            InputStream is = new FileInputStream(archivoPDF.getAbsolutePath());
            IOUtils.copy(is, response.getOutputStream());
            response.flushBuffer();
            is.close();

        } catch (IOException ex) {
            log.error(ex);
        }

        return null;

    }

 //PAS20175E220200035

   //afma pase 56
    public ModelAndView cargarCOPDFVUCE(HttpServletRequest request,
                                      HttpServletResponse response){

        CertiOrigenElectronicoService certiOrigenElectronicoService = fabricaDeServicios.getService("certiOrigenElectronicoService");

        try {

            String numCertificadoOrigen = request.getParameter("numCertificadoOrigen") != null? request.getParameter("numCertificadoOrigen").toString(): "";
            String codigoPaisOrigen     = request.getParameter("codigoPaisOrigen") != null? request.getParameter("codigoPaisOrigen").toString().substring(0,2): "";

            String rutaDestino = "/data1/vuce/envios/anexospdf/temporal/";
            ArchivoAnexoDocControlMR archivo = certiOrigenElectronicoService.obtenerCertificadoOrigenPDF(numCertificadoOrigen,codigoPaisOrigen);

            File archivoPDF = Utilidades.grabarArchivoTemporalCO(archivo.getArchivoDocAdjunto(),rutaDestino);

            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + archivoPDF.getName() + "\"");

            InputStream is = new FileInputStream(archivoPDF.getAbsolutePath());
            IOUtils.copy(is, response.getOutputStream());
            response.flushBuffer();
            is.close();

        } catch (Exception ex) {
            log.error(ex);
        }

        return null;

    }

 private String obtenerDescripcionPorCatalogo(String codCatalogo, String codDatacat){
     
     String descripcionCorta = "";
     if(!Utilidades.esNuloOVacio(codDatacat)){
         DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(codCatalogo, codDatacat);
         descripcionCorta = dataCatalogo.getDesCorta();
     }
     return descripcionCorta;
 }	 
 

}