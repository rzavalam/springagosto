package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;




import java.beans.PropertyEditorSupport;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.model.TipoDocumentoSustentatorio;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession;

/**
 * Factoriza funcionalidad comun a los controladores
 * centraliza la gestion de errores, advertencias, avisos
 * gestion de variables en SESSION.
 *
 * @author  amancilla
 * @version 1.0
 * @since   Aug 27, 2012
 */
@SuppressWarnings("rawtypes")
public class AbstractDespachoController extends MultiActionController {

    protected final Log            log = LogFactory.getLog(getClass());

    protected DiligenciaService    diligenciaService;
    protected CatalogoAyudaService catalogoAyudaService;
    protected String               jsonView;




    protected String getTipoDiligencia(HttpServletRequest request){

        StringBuilder sbTipoDiligencia = new StringBuilder();
        sbTipoDiligencia.append(getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA));

        return sbTipoDiligencia.toString();
    }



    /**
     * Metodo que permite obtener la codigo de la aduana del usuario
     * logeado en el portal del especialista luego los guarda en el request.
     *
     * @param   request [HttpServletRequest] request
     * @return  codAduanaLogeada [String] codigo de la aduana por defecto 000
     * @author  amancilla
     * @version 1.0
     */
    protected String obtenerAduana(HttpServletRequest request){

        //se busca primero en session
        String codAduanaLogeada = (String) getVariableSesion(request, EnumVariablesSession.COD_ADUANA_LOGEADA);
        if (!SunatStringUtils.isEmpty(codAduanaLogeada)) {
            return codAduanaLogeada;
        }
        //obtiene el area del usuario logeado
        UsuarioBean bUsuario = (UsuarioBean) getVariableSesion(request, EnumVariablesSession.USUARIO_LOGEADO);
        Map mapTapdep = this.catalogoAyudaService.getTabdep(bUsuario.getCodUO());

        codAduanaLogeada = !CollectionUtils.isEmpty(mapTapdep) && mapTapdep.get("aduana") != null
                ? (String) mapTapdep.get("aduana")
                : Constantes.DEFAULT_COD_ADUANA;

        setVariableSesion(request, EnumVariablesSession.COD_ADUANA_LOGEADA, codAduanaLogeada);
        return codAduanaLogeada;
    }

/**INICIO-RIN13**/

    /**
     * Metodo que permite obtener el codigo de la aduana del usuario
     * logeado en el portal del especialista.
     *
     * @param   usuario [UsuarioBean] usuario logeado
     * @return  codAduanaLogeada [String] codigo de la aduana por defecto 000
     * @author  gbecerrav
     * @version 1.0
     */
    protected String obtenerAduana(UsuarioBean usuario){
        //Se obtiene el area del usuario logeado
        Map mapTapdep = this.catalogoAyudaService.getTabdep(usuario.getCodUO());

        String codAduanaLogeada = !CollectionUtils.isEmpty(mapTapdep) && mapTapdep.get("aduana") != null
                ? (String) mapTapdep.get("aduana")
                : Constantes.DEFAULT_COD_ADUANA;
        return codAduanaLogeada;
    }

/**FIN-RIN13**/
    /**
     * Permite mostrar el mensaje por eventos
     * que no permiten el flujo normal del programa:
     * caso 1 errores.
     * caso 2 validaciones controladas ejm usuario fuera de session.
     *
     * para el caso 1 el mensaje de ERROR se pinta en el LOG
     * y al usuario final un mensaje estandar.
     *
     * @param mensajeError [String] mensaje error
     * @return  [ModelAndView] PAGM.jsp
     * @author  amancilla
     * @version 1.0
     */
    protected ModelAndView showErrorPagM(String mensajeError){

        MensajeBean beanM = new MensajeBean();
        // para todos los casos es un ERROR
        beanM.setError(true);
        // setea los mensajes
        beanM.setMensajeerror(SunatStringUtils.isEmpty(mensajeError) ? Constantes.PAGM_MSJ_ERROR : mensajeError);
        beanM.setMensajesol(Constantes.PAGM_MSJ_SOL);
        ModelAndView modelAndView = new ModelAndView("PagM");
        modelAndView.addObject("beanM", beanM);

        return modelAndView;
    }
/**INICIO-RIN13**/
    /**
     * Permite mostrar el mensaje por eventos
     * que no permiten el flujo normal del programa:
     * caso 1 errores.
     * caso 2 validaciones controladas ejm usuario fuera de session.
     *
     * para el caso 1 el mensaje de ERROR se pinta en el LOG
     * y al usuario final un mensaje estandar.
     *
     * @param mensajeError  [String] mensaje error  detalle del mensaje
     * @param mensajeTitulo [String] mensaje titulo mostrado en una ventana emergente
     * @param tipoError [boolean] tipo error
     * <code>true</code>  para el caso 1
     * <code>false</code> para el caso 2
     * @return  [ModelAndView] PAGM.jsp
     * @author  gbecerrav
     * @version 1.0
     */
    protected ModelAndView showErrorPagM(String mensajeError, String mensajeTitulo, boolean tipoError){

        MensajeBean beanM = new MensajeBean();
        // para todos los casos es un ERROR
        beanM.setError(tipoError);
        // setea los mensajes
        beanM.setMensajeerror(SunatStringUtils.isEmpty(mensajeError) ? Constantes.PAGM_MSJ_ERROR : mensajeError);
        beanM.setMensajesol(SunatStringUtils.isEmpty(mensajeTitulo) ? Constantes.PAGM_MSJ_SOL : mensajeTitulo);
        ModelAndView modelAndView = new ModelAndView("PagM");
        modelAndView.addObject("beanM", beanM);

        return modelAndView;
    }

/**FIN-RIN13**/
    /**
     * Permite mostrar mensajes al evaluar un proceso:
     * caso 1 mensaje de validaciones no satisfactorias que no permiten
     * avanzar en el flujo del programa.
     * caso 2 mensaje de advertencias o alertas para el usuario,
     * que permiten continuar con el flujo del programa.
     *
     *
     * @param mensajeError  [String] mensaje error  detalle del mensaje
     * @param mensajeTitulo [String] mensaje titulo mostrado en una ventana emergente
     * @param tipoError [boolean] tipo error
     * <code>true</code>  para el caso 1
     * <code>false</code> para el caso 2
     * @return  [jsonView]
     * @author  amancilla
     * @version 1.0
     */
    protected ModelAndView showErrorJSON(String mensajeError, String mensajeTitulo, boolean tipoError){

        MensajeBean beanM = new MensajeBean();
        beanM.setError(tipoError);
        // setea los mensajes
        beanM.setMensajeerror(SunatStringUtils.isEmpty(mensajeError) ?
                Constantes.PAGM_MSJ_ERROR : mensajeError);
        beanM.setMensajesol(SunatStringUtils.isEmpty(mensajeTitulo) ?
                Constantes.PAGM_MSJ_SOL : mensajeTitulo);

        ModelAndView modelAndView = new ModelAndView(this.jsonView);
        modelAndView.addObject("Error", beanM);

        return modelAndView;
    }



    /**
     * para el caso 1.
     *
     * @return  [ModelAndView] model and view
     * @see showErrorJSON
     */
    protected ModelAndView showErrorJSON(){

        return showErrorJSON("", "", true);
    }

    /**
     * para el caso 1.
     *
     * @param mensajeError [String] mensaje error
     * @return  [ModelAndView] model and view
     * @see showErrorJSON
     */
    protected ModelAndView showErrorJSON(String mensajeError){

        return showErrorJSON(mensajeError, "", true);
    }

    /**
     * para el caso 1.
     *
     * @param mensajeError [String] mensaje error
     * @param mensajeTitulo [String] mensaje titulo
     * @return  [ModelAndView] model and view
     * @see showErrorJSON
     */
    protected ModelAndView showErrorJSON(String mensajeError, String mensajeTitulo){

        return showErrorJSON(mensajeError, mensajeTitulo, true);
    }

    /**
     * para el caso 2.
     *
     * @return  [ModelAndView] model and view
     * @see showErrorJSON
     */
    protected ModelAndView showAvisoJSON(){

        return showErrorJSON("", "", false);
    }

    /**
     * Show aviso json.
     *
     * @param mensajeError [String] mensaje error
     * @return  [ModelAndView] model and view
     * @author  amancilla
     * @version 1.0
     */
    protected ModelAndView showAvisoJSON(String mensajeError){

        return showErrorJSON(mensajeError, "", false);
    }

    /**
     * Show aviso json.
     *
     * @param mensajeError [String] mensaje error
     * @param mensajeTitulo [String] mensaje titulo
     * @return  [ModelAndView] model and view
     * @author  amancilla
     * @version 1.0
     */
    protected ModelAndView showAvisoJSON(String mensajeError, String mensajeTitulo){

        return showErrorJSON(mensajeError, mensajeTitulo, false);
    }



    /**
     * Obtiene el titulo a mostrar en los JSP.
     *
     * @param tipoDiligencia [String] tipo diligencia
     * @param dua [Map<String,Object>] (COD_ADUANA,ANN_PRESEN,COD_REGIMEN,NUM_DECLARACION)
     * @return String titulo a mostrar en el modulo.
     */
    protected String getTituloModuloEnJSP(String tipoDiligencia, Map<String, Object> dua){

        StringBuilder sbTituloModulo = new StringBuilder();
        if (Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia)) {
            sbTituloModulo.append("DILIGENCIA DE RECTIFICACION DE OFICIO ");
        }
        if (Constantes.MODULO_CULMINACION_PECO.equals(tipoDiligencia)) {
            sbTituloModulo.append("DILIGENCIA DE CULMINACION DE PECO AMAZONIA ");
        }
        String titulopeco=dua.get("numeroDeclaracionTitulo")!=null?dua.get("numeroDeclaracionTitulo").toString():"";

        if (!CollectionUtils.isEmpty(dua)) {
            StringBuilder sbDua = new StringBuilder();
            sbDua.append(titulopeco);
            sbDua.append("-");
            sbDua.append(dua.get("COD_ADUANA"));
            sbDua.append("-");
            sbDua.append(dua.get("ANN_PRESEN"));
            sbDua.append("-");
            sbDua.append(dua.get("COD_REGIMEN"));
            sbDua.append("-");
            sbDua.append(dua.get("NUM_DECLARACION"));
            //se quita pq no se envia este parametro sbDua.append(dua.get("numeroDeclaracionTitulo"));

            sbTituloModulo.append(sbDua);
        }

        return sbTituloModulo.toString();
    }


    /**
     * Limpiar variables sesion regitradas
     * caso 1 EnumTablaModel variables LISTAS y MAPAS de las tablas.
     * caso 2 EnumVariablesSession variables del modulo
     *
     * @param request [HttpServletRequest] request
     */
    protected void limpiarVariablesSesion(HttpServletRequest request){

        for (EnumTablaModel enumVariable : EnumTablaModel.values()) {
            removerVariableSesion(request,enumVariable.getNombreVariableSessionNew());
            removerVariableSesion(request,enumVariable.getNombreVariableSessionOld());
        }
        for (EnumVariablesSession enumVariable : EnumVariablesSession.values()) {
            removerVariableSesion(request,enumVariable.getNombreVariableSession());
        }

        //P34 AFMA se agrega otras que no estan registras que son bastantes no hya orden
        Utilidades.limpiarMapasSesion(request);
    }

    protected void removerVariableSesion(HttpServletRequest request, EnumVariablesSession enumVariable){

        removerVariableSesion(request, enumVariable.getNombreVariableSession());
    }


    /**
     * Remover variable de la sesion.
     *
     * @param request [HttpServletRequest] request
     * @param nombreVariable [String] nombre variable
     */
    protected void removerVariableSesion(HttpServletRequest request, String nombreVariable){
        if (!SunatStringUtils.isEmpty(nombreVariable) && !nombreVariable.equals("usuarioBean")) {

            HttpSession session = request.getSession();
            session.removeAttribute(nombreVariable);
            if (log.isDebugEnabled()) {
                log.debug("*** INICIO - REMOVER VARIABLE SESSION ***");
                log.debug("VARIABLE SESSION REMOVIDA:" + nombreVariable);
                log.debug("*** FIN - REMOVER VARIABLE SESSION    ***");
            }
        }
    }



    /**
     * Obtiene la variable sesion indicada en enumVariable.
     *
     * @param request [HttpServletRequest] request
     * @param enumVariable [EnumVariablesSession] Variable de session temporal
     * @return variable sesion
     */
    protected Object getVariableSesion(HttpServletRequest request, EnumVariablesSession enumVariable){

        Object variable = WebUtils.getSessionAttribute(request, enumVariable.getNombreVariableSession());
        if (log.isDebugEnabled()) {
            log.debug("*** INICIO-GET VARIABLE SESSION:"+enumVariable.getNombreVariableSession());
            log.debug("VALOR:" + SojoUtil.toJson(variable));
            log.debug("*** FIN-GET VARIABLE SESSION ***");
        }

        return variable;

    }


    protected Object getVariableSesion(HttpServletRequest request, EnumTablaModel enumVariable, String tipo) throws Exception {

        return getVariableSesion(request,enumVariable,tipo, true);
    }


    /**
     * Obtiene la variable sesion indicada en enumVariable.
     * si no esta cargada va la BD y carga la variable
     *
     * @param request [HttpServletRequest] request
     * @param enumVariable [EnumTablaModel] variable de session de persistencia de la tablas
     * @param tipo [String] tipo
     * <code>VAR_NEW</code> variable persiste datos actualizados por el usuario y sistema durante la session
     * <code>VAR_OLD</code> variable de SESSION con datos originales de la BD
     * @return  variable sesion
     * @throws Exception
     */
    protected Object getVariableSesion(HttpServletRequest request, EnumTablaModel enumVariable,
                                       String tipo, Boolean cargarDeBD) throws Exception{

        String nombreVariable       = "";
        String nombreVariableOpuesta = "";

        if (Constantes.VAR_NEW.equals(tipo)) {
            nombreVariable        = enumVariable.getNombreVariableSessionNew();
            nombreVariableOpuesta = enumVariable.getNombreVariableSessionOld();

        } else if (Constantes.VAR_OLD.equals(tipo)) {
            nombreVariable        = enumVariable.getNombreVariableSessionOld();
            nombreVariableOpuesta = enumVariable.getNombreVariableSessionNew();
        }

        Object variable = WebUtils.getSessionAttribute(request, nombreVariable);


        if (log.isDebugEnabled()) {
            log.debug("*** INICIO-GET VARIABLE SESSION TABLA:"+nombreVariable);
            log.debug("VALOR:" + SojoUtil.toJson(variable));
            log.debug("*** FIN-GET VARIABLE SESSION TABLA ***");
        }



        if (variable == null && cargarDeBD==true) {

            BusquedaDua busquedaDua = (BusquedaDua) getVariableSesion(request,EnumVariablesSession.PARAMS_BUSQUEDA_DUA);

            variable = diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,enumVariable);


            if (!CollectionUtils.isEmpty((List)variable)) {

                if (log.isDebugEnabled()) {
                    log.debug("*** INICIO-CARGANDO DE BD TABLA:"+nombreVariable);
                    log.debug("VALOR:" + SojoUtil.toJson(variable));
                    log.debug("*** FIN-CARGANDO DE BD  TABLA ***");
                }
                //para que no tomen la misma ubicacion de memoria y ambos se actulizen igual
                Object variableOpuesta = diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,enumVariable);
                if (Constantes.VAR_NEW.equals(tipo)) {
                    setVariableSesion(request,enumVariable, Constantes.VAR_NEW,variable);
                    if(!existeVarible(request, nombreVariableOpuesta)){

                        setVariableSesion(request,enumVariable, Constantes.VAR_OLD,variableOpuesta);
                    }

                } else if (Constantes.VAR_OLD.equals(tipo)) {
                    setVariableSesion(request,enumVariable, Constantes.VAR_OLD,variable);
                    if(!existeVarible(request, nombreVariableOpuesta)){
                        setVariableSesion(request,enumVariable, Constantes.VAR_NEW,variableOpuesta);
                    }
                }
            }else {
                log.debug("QUERY BD DE VARIABLE SESSION TABLA:"+nombreVariable+" NULL-SIN DATOS CHEKEEA");
                variable = null;
            }
        }

        return variable;
    }

    private boolean existeVarible(HttpServletRequest request, String nombreVariable){

        Object variable = WebUtils.getSessionAttribute(request, nombreVariable);
        return variable!=null?true:false;
    }

    /**
     * Seteo the variable sesion.
     *
     * @param request [HttpServletRequest] request
     * @param enumVariable [EnumTablaModel] enum variable
     * @param tipo [String] tipo
     * @param valor [Object] valor
     * @throws Exception
     */
    protected void setVariableSesion(HttpServletRequest request, EnumTablaModel enumVariable, String tipo, Object valor) throws Exception{

        String nombreVariable = "";

        if (Constantes.VAR_NEW.equals(tipo)) {
            nombreVariable = enumVariable.getNombreVariableSessionNew();
        } else if (Constantes.VAR_OLD.equals(tipo)) {
            nombreVariable = enumVariable.getNombreVariableSessionOld();
        }

        if (!SunatStringUtils.isEmpty(nombreVariable)) {
            //busco el valor original antes del cambio
            //se cruza y buelve lstSeries que ya esta en sesion a MAP por eso se comenta
            //Object variableOriginal = getVariableSesion(request,enumVariable,tipo,false);
            //TODO : usar el compardor para mostras las diferencias
            Object diferencias = new Object();
            if (log.isDebugEnabled()) {
                log.debug("*** INICIO-SET VARIABLE SESSION TABLA:"+nombreVariable);
                log.debug("NEW_VALOR  :" + SojoUtil.toJson(valor));
                //  log.debug("OLD_VALOR  :" + SojoUtil.toJson(variableOriginal));
                log.debug("DIFERENCIAS:" + SojoUtil.toJson(diferencias));
                log.debug("*** FIN-SET VARIABLE SESSION TABLA ***");
            }


            WebUtils.setSessionAttribute(request, nombreVariable, valor);
        }
    }

    /**
     * envia una variable en session.
     *
     * @param request [HttpServletRequest] request
     * @param enumVariable [EnumVariablesSession] enum variable
     * @param valor [Object] valor
     */
    protected void setVariableSesion(HttpServletRequest request, EnumVariablesSession enumVariable, Object valor){

        String nombreVariable = enumVariable.getNombreVariableSession();
        if (!SunatStringUtils.isEmpty(nombreVariable)) {

            //busco el valor original antes del cambio
            Object variableOriginal = getVariableSesion(request,enumVariable);

            if (log.isDebugEnabled()) {
                log.debug("*** INICIO-SET VARIABLE SESSION:"+nombreVariable);
                log.debug("NEW_VALOR  :" + SojoUtil.toJson(valor));
                log.debug("OLD_VALOR  :" + SojoUtil.toJson(variableOriginal));
                log.debug("*** FIN-SET VARIABLE SESSION ***");
            }
            WebUtils.setSessionAttribute(request, nombreVariable, valor);
        }
    }

    /**
     * Verificar autenticacion del usuario en session.
     *
     * @param request [HttpServletRequest] request
     * @return  [UsuarioBean] con los datos del usuario en session.
     * @throws ServiceException the service exception
     * @author  amancilla
     * @version 1.0
     */
    protected UsuarioBean verificarAutenticacion(HttpServletRequest request) throws ServiceException{

        UsuarioBean userSession = (UsuarioBean) getVariableSesion(request, EnumVariablesSession.USUARIO_LOGEADO);

        if (userSession == null) {
            throw new ServiceException(this, "Usuario no logueado � su sesi�n ha expirado."); //RIN13
        }

        return userSession;
    }

    /**
     * Permite pasar los parametros del request
     * a los atributos del objeto o bean.
     *
     * @param request [HttpServletRequest] request
     * @param command [Object] objeto que sera poblado con datos del request
     * @throws Exception the exception
     */
    protected void bindToCommand(HttpServletRequest request, Object command) throws Exception{

        ServletRequestDataBinder binder = createBinder(request, command);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
        binder.registerCustomEditor(Date.class, editor);


        binder.registerCustomEditor(TipoDocumentoSustentatorio.class, new PropertyEditorSupport() {

            @Override
            public void setAsText(String value) throws IllegalArgumentException {
                if(StringUtils.isBlank(value)) return;
                setValue(TipoDocumentoSustentatorio.get(value));
            }

            @Override
            public String getAsText() {
                return getValue() == null ? "" : ((TipoDocumentoSustentatorio) getValue()).name();
            }

        });

        binder.bind(request);
        if (log.isDebugEnabled()) {
            log.debug(" ******* bindToCommand:" + binder.getBindingResult());
        }
    }


    /************************ INYECCION POR SET ***************************************/


    public void setDiligenciaService(DiligenciaService diligenciaService){

        this.diligenciaService = diligenciaService;
    }

    public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService){

        this.catalogoAyudaService = catalogoAyudaService;
    }


    public void setJsonView(String jsonView){

        this.jsonView = jsonView;
    }

}
