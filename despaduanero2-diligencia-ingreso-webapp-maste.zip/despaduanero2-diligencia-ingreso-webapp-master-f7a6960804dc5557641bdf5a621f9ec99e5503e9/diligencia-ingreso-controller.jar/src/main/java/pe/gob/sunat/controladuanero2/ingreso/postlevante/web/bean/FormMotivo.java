package pe.gob.sunat.controladuanero2.ingreso.postlevante.web.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * Created by amancillaa on 28/04/2016.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "descripcion",
        "checked"
})
public class FormMotivo implements Serializable{



    private static final long serialVersionUID = -519198298325615385L;

    @JsonProperty("codigo")
    private String codigo;
    @JsonProperty("descripcion")
    private String descripcion;
    @JsonProperty("checked")
    private boolean checked;


    public FormMotivo() {
        super();
    }

    public FormMotivo(String codigo, String descripcion) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.checked = false;
    }

    @JsonProperty("checked")
    public boolean isChecked() {
        return checked;
    }


    @JsonProperty("checked")
    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @JsonProperty("descripcion")
    public String getDescripcion() {
        return descripcion;
    }

    @JsonProperty("descripcion")
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }
    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
