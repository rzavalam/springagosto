package pe.gob.sunat.despaduanero2.multa.web.controller;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.multa.service.MultaService;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


/**
 * The Class MultaController. Clase controller que permite mostrar la pantalla
 * de multas relacionadas a una
 *
 * @author Ruddy Cuellar Mayorga
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class MultaPecoAmazoniaController extends MultiActionController
{

  protected final Log          log                  = LogFactory.getLog(getClass());

  private MultaService         multaService;

  private OperadorAyudaService operadorAyudaService;

  private SoporteService soporteService;

  private String               jsonView;

  /**
   * Inicio prueba multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView inicioPruebaMultas(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return new ModelAndView("inicioPruebaMultas");
  }

  /**
   * Metodo que permite mostrar el listado de las multas agrupadas por
   * infractor.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cargarListadoMultas(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    List<Map<String, Object>> listadoMultas = null;
    if (request.getSession().getAttribute("listadoMultas") == null)
    {
      try
      {
        Map<String, Object> paramsBusquedaMultas = new HashMap<String, Object>();

        Map declaracionMap = (Map) request.getSession().getAttribute("mapCabDeclaraActual");
        Date fechaDeclaracion = (Date) declaracionMap.get("FEC_DECLARACION");
        paramsBusquedaMultas.put("FEC_DECLARACION", fechaDeclaracion);
        paramsBusquedaMultas.put("caduana", soporteService.obtenerAduana(request));

        listadoMultas = multaService.obtenerCatMultas(paramsBusquedaMultas);

      }
      catch (ServiceException e)
      {
        log.error("*** ERROR ***", e);
        return new ModelAndView("PagE", "message", e.getMessage());
      }
      catch (Exception e)
      {
        log.error("*** ERROR ***", e);

        return new ModelAndView("PagM", "message", e.getMessage());
      }

      request.getSession().setAttribute("listadoMultas", listadoMultas);
    }
    else
    {
      listadoMultas = (List<Map<String, Object>>) request.getSession().getAttribute("listadoMultas");
    }
    String array = SojoUtil.toJson(listadoMultas);
    ModelAndView mv = new ModelAndView("destino/ListadoMulta");
    mv.addObject("multas", array);

    return mv;
  }


  /**
   * Metodo que permite agregar en session los datos de una multa.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView agregarMulta(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      List<Map<String, Object>> listaMultasSeleccionadas = (WebUtils.getSessionAttribute(request, "lstMultaDuaActual") != null) ? (ArrayList) WebUtils
          .getSessionAttribute(request, "lstMultaDuaActual")
          : new ArrayList<Map<String, Object>>();


      String id = webRequest.getParameter("hdn_id");
      boolean booEncontrado = false;
      if (listaMultasSeleccionadas.size() > 0)
      {
        for (Map<String, Object> multa : listaMultasSeleccionadas)
        {
          if (multa.get(id) != null)
          {
            booEncontrado = true;
            multa.put("selPctRebaja" + id, webRequest.getParameter("hdn_pct_rebaja"));
            multa.put("txtMontoPag" + id, webRequest.getParameter("hdn_monto_pag"));
            multa.put("txtMonto" + id, webRequest.getParameter("hdn_monto"));


            break;
          }
        }
      }
      if (!booEncontrado)
      {
        Map multa = new HashMap();
        multa.put("cbxSeleccion" + id, id);
        multa.put("selPctRebaja" + id, webRequest.getParameter("hdn_pct_rebaja"));
        multa.put("txtCodMulta" + id, webRequest.getParameter("hdn_codigo"));
        multa.put("txtMoneda" + id, webRequest.getParameter("hdn_cod_moneda"));
        multa.put("txtMonto" + id, webRequest.getParameter("hdn_monto"));
        multa.put("txtMontoPag" + id, webRequest.getParameter("hdn_monto_pag"));
        multa.put("txtNaturaleza" + id, webRequest.getParameter("hdn_naturaleza"));
        multa.put("txtTipoMulta" + id, webRequest.getParameter("hdn_tmulta"));
        multa.put(id, id);

        listaMultasSeleccionadas.add(multa);

      }

      request.getSession().setAttribute("lstMultaDuaActual", listaMultasSeleccionadas);
      res.addObject("recOk", true);
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      res.addObject("beanM", rBean);
    }
    return res;
  }

  /**
   * Metodo que permite eliminar de session los datos de una multa.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView eliminarMulta(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      List<Map<String, Object>> listaMultasSeleccionadas = (ArrayList) WebUtils.getSessionAttribute(
          request,
            "lstMultaDuaActual");


      String id = webRequest.getParameter("hdn_id");
      int indice = -1;
      boolean booEncontrado = false;
      if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
      {
        for (Map<String, Object> multa : listaMultasSeleccionadas)
        {
          indice += 1;
          if (multa.get(id) != null)
          {
            booEncontrado = true;
            break;
          }
        }

        if (booEncontrado)
        {
          listaMultasSeleccionadas.remove(indice);
          request.getSession().setAttribute("lstMultaDuaActual", listaMultasSeleccionadas);
        }
      }

      res.addObject("recOk", true);
    }
    catch (Exception e)
    {

      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);

      res.addObject("beanM", rBean);
    }
    return res;
  }

  /**
   * Metodo que almacena en session los datos de las multas de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView guardarMultaSesion(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    if ((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual") != null)
      lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual"));
    WebUtils.setSessionAttribute(request, "lstMultaDua", lstEditada);
    res.addObject("ok", "ok");
    return res;
  }

  /**
   * Metodo que elimina de session los datos editados de las multas de la DUA.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cancelarEdicion(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDua"));
    WebUtils.setSessionAttribute(request, "lstMultaDuaActual", lstEditada);
    res.addObject("ok", "ok");
    return res;
  }

  /**
   * Metodo que obtiene la cantidad de registros multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView cantidadRegistroMulta(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    ModelAndView res = new ModelAndView(this.jsonView);
    List lstEditada = new ArrayList();
    if ((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual") != null)
      lstEditada.addAll((ArrayList) WebUtils.getSessionAttribute(request, "lstMultaDuaActual"));
    res.addObject("lstMultaDua", lstEditada.size());
    return res;
  }


  /**
   * Metodo que permite guardar en session los datos ingresados en la pantalla
   * de multas.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView guardar(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
    try
    {
      Map parameterMap = webRequest.getParameterMap();

      Object[] ctrNames = parameterMap.keySet().toArray();

      List<Map<String, Object>> listaMultasSeleccionadas = (WebUtils.getSessionAttribute(request, "lstMultaDua") != null) ? (ArrayList) WebUtils
          .getSessionAttribute(request, "lstMultaDua")
          : new ArrayList<Map<String, Object>>();

      // Limpiamos los elementos de los infractores cargados
      List listadoMultas = (ArrayList) WebUtils.getSessionAttribute(request, "listadoMultas");
      String[] infractores = webRequest.getParameter("hdn_tabs_cargados").split(Constantes.SEPARADOR1);
      Map multaDat;
      Set multaKey;
      List<String> lstRemove;
      int itm;

      for (String infr : infractores)
      {
        if (listaMultasSeleccionadas.size() > 0)
        {
          multaDat = (HashMap) listadoMultas.get(Integer.parseInt(infr));
          itm = 0;
          lstRemove = new ArrayList<String>();
          for (Map<String, Object> multa : listaMultasSeleccionadas)
          {
            multaKey = multa.keySet();
            for (Object key : multaKey)
            {
              if (key.toString().startsWith("cbxSeleccion" + (multaDat.get("COD_INFRACTOR").toString())))
              {
                lstRemove.add("" + itm);
              }
            }
            itm += 1;
          }

          if (lstRemove.size() > 0)
          {
            for (int i = lstRemove.size() - 1; i >= 0; i--)
            {
              listaMultasSeleccionadas.remove(Integer.parseInt(lstRemove.get(i)));
            }
          }
        }
      }

      // Cargamos los elementos pintados en pantalla
      if (parameterMap != null && parameterMap.size() > 0)
      {
        String clave;
        for (int contValues = 0; contValues < parameterMap.size(); contValues++)
        {
          // Obtenemos los checkbox de las multas seleccionadas
          clave = ctrNames[contValues].toString();
          if (clave.startsWith("cbxSeleccion"))
          {
            Map<String, Object> multa = new TreeMap<String, Object>();
            multa.put(clave, clave.substring("cbxSeleccion".length(), clave.length()));
            listaMultasSeleccionadas.add(multa);
          }
        }

        // Asignamos los datos correspondientes a las multas (visibles)
        // seleccionadas
        String grupoMulta;
        for (Map<String, Object> multa : listaMultasSeleccionadas)
        {
          grupoMulta = (String) ((TreeMap<String, Object>) multa).firstEntry().getValue();
          if (webRequest.getParameter("selPctRebaja" + grupoMulta + "_aux") != null)
          {
            multa.put("selPctRebaja" + grupoMulta, webRequest.getParameter("selPctRebaja" + grupoMulta + "_aux"));
            multa.put("txtMonto" + grupoMulta, webRequest.getParameter("txtMonto" + grupoMulta));
            multa.put("txtMontoPag" + grupoMulta, webRequest.getParameter("txtMontoPag" + grupoMulta + "_aux"));
            multa.put("txtTipoMulta" + grupoMulta, webRequest.getParameter("txtTipoMulta" + grupoMulta));
            multa.put("txtMoneda" + grupoMulta, webRequest.getParameter("txtMoneda" + grupoMulta));
            multa.put("txtCodMulta" + grupoMulta, webRequest.getParameter("txtCodMulta" + grupoMulta));
            multa.put("txtNaturaleza" + grupoMulta, webRequest.getParameter("txtNaturaleza" + grupoMulta));
          }
        }
      }
      request.getSession().setAttribute("lstMultaDua", listaMultasSeleccionadas);
    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);

      return new ModelAndView("PagM", "message", e.getMessage());
    }

    return null;
  }

  /**
   * Metodo temporal que llama al servicio de grabacion de multas. Luego la
   * llamada a este m�todo se hara desde el DiligenciaServiceImpl
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView grabarDatos(HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    List<Map<String, Object>> listaMultasSeleccionadas = (List<Map<String, Object>>) request.getSession().getAttribute(
        "lstMultaDua");
    try
    {

      Map declaracionActualMap = (HashMap) request.getSession().getAttribute("mapCabDeclaraActual");
      Map declaracionMap = (HashMap) request.getSession().getAttribute("mapCabDeclara");
      String codDocumento = (String) declaracionActualMap.get("num_corredoc");
      String codTipoDiligencia = (String) declaracionMap.get("cod_canal");
      Date fechaDeclaracion = (Date) declaracionActualMap.get("FEC_DECLARACION");
      String tipoDocImp = (String) declaracionActualMap.get("COD_TIPDOC_PIM");
      String rucImp = (String) declaracionActualMap.get("NUM_DOCIDENT_PIM");
      String rucAgente = (String) declaracionActualMap.get("NUM_DOCIDENT_PDE");
      Map operador = (HashMap) operadorAyudaService.getOperadorPorCodAduanero(rucAgente, "41");
      String codAgente = (String) operador.get("COD_ANTADU");
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      Map paramMulta = new HashMap();
      paramMulta.put("COD_DOCUMENTO", codDocumento);
      paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
      paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
      paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
      paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
      paramMulta.put("NUM_REG_USUARIO", bUsuario.getNroRegistro());
      paramMulta.put("COD_ANTADU", codAgente);
      multaService.generarMulta(paramMulta, listaMultasSeleccionadas);

    }
    catch (ServiceException e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "message", e.getMessage());
    }

    return null;
  }

  /***********************SET DE SPRING **********************************/

  /**
   * Sets the json view.
   *
   * @param jsonView
   *          the new json view
   */
  public void setJsonView(String jsonView)
  {
    this.jsonView = jsonView;
  }

  /**
   * Sets the multa service.
   *
   * @param multaService
   *          the new multa service
   */
  public void setMultaService(MultaService multaService)
  {
    this.multaService = multaService;
  }

  /**
   * Sets the operador ayuda service.
   *
   * @param operadorAyudaService
   *          the new operador ayuda service
   */
  public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService)
  {
    this.operadorAyudaService = operadorAyudaService;
  }

  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }


}
