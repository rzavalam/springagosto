package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;


/**
 * <p>
 * Titulo: Controlador Web para Liquidacion
 * </p>
 * <p>
 * Descripcion: Controlador que administra las funcionalidades de Liquidacion
 * para la Declaracion.
 * </p>
 *
 * @author jcanchucaja
 * @version 1.0
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class LiquidacionAduanaDestinoController extends MultiActionController
{

  protected final Log               log = LogFactory.getLog(getClass());

  private LiquidaDeclaracionService liquidaDeclaracionService;

  private SerieService              serieService;

  private SoporteService              soporteService;

  /**
   * Metodo que realiza la Liquidacion de Declaracion.
   *
   * @param request
   *          the request
   * @throws Exception
   *           the exception
   */
  public void liquidarDeclaracion(HttpServletRequest request) throws Exception
  {
    ServletWebRequest webRequest = new ServletWebRequest(request);
    Map resulPreliq = new HashMap();
    resulPreliq.put("ERROR", "NO");
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_DECLARACION", webRequest.getParameter("hdn_num_declaracion"));
    params.put("COD_ADUANA", webRequest.getParameter("hdn_cod_aduana"));
    params.put("ANN_PRESEN", webRequest.getParameter("hdn_ann_presen"));
    params.put("COD_REGIMEN", webRequest.getParameter("hdn_cod_regimen"));

    Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
    List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");

    if (listDetDeclara.isEmpty())
    {
      resulPreliq.put("ERROR", "No se han cargado las series");
      declaracionActual.put("resulPreliq", resulPreliq);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
      return;
    }

    List listParticipanteDoc = new ArrayList();
    // Obtenemos de cabDeclara (importador y agente)
    if (declaracionActual.get("COD_TIPDOC_PIM") != null)
    {
      Map mapImport = new HashMap();
      mapImport.put("COD_TIPPARTIC", "45");
      mapImport.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
      mapImport.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
      listParticipanteDoc.add(mapImport);
    }

    if (declaracionActual.get("NUM_DOCIDENT_PDE") != null)
    {
      Map mapAgent = new HashMap();
      mapAgent.put("COD_TIPPARTIC", "41");
      mapAgent.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
      mapAgent.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
      listParticipanteDoc.add(mapAgent);
    }

    if (listParticipanteDoc.isEmpty())
    {
      resulPreliq.put("ERROR", "No existe lista de Participantes");
      declaracionActual.put("resulPreliq", resulPreliq);
      WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);
      return;
    }

    UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
    UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

    List listConvenioSerie = new ArrayList();
    List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
    Map<String, Object> serieEliminada = null;
    for (Map<String, Object> detDeclaraMap : listDetDeclara)
    {
      if ("1".equals(detDeclaraMap.get("IND_DEL")))
      {
        serieEliminada = detDeclaraMap;
        listaSerieEliminada.add(serieEliminada);
        continue;
      }
      if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
      {
        detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
      }
      if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
      {
        List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
        for (int i = 0; i < lstConvenioSerie.size(); i++)
        {
          HashMap convenio = (HashMap) lstConvenioSerie.get(i);
          if (!"1".equals(convenio.get("IND_DEL")))
          {
            // en la rectificacion no se agrega el ind_eliminado a los nuevos
            // convenios
            listConvenioSerie.add(convenio);
          }
        }
      }
    }
    for (Map<String, Object> mapEliminar : listaSerieEliminada)
    {
      listDetDeclara.remove(mapEliminar);
    }

    List listDocupreceDua = (ArrayList) WebUtils.getSessionAttribute(request, "lstDocuPreceDuaActual");
    HashMap paramDocLiq = new HashMap();
    paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
    paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
    paramDocLiq.put("cabDeclara", declaracionActual);
    paramDocLiq.put("listDetDeclara", listDetDeclara);
    paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
    paramDocLiq.put("listConvenioSerie", listConvenioSerie);
    paramDocLiq.put("listDocupreceDua", listDocupreceDua);
    paramDocLiq.put("listaSerieEliminada", listaSerieEliminada);
    paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
    resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);
    declaracionActual.put("caduana", soporteService.obtenerAduana(request));
    Map parametros = new HashMap();
    declaracionActual.put("resulPreliq", resulPreliq);
    parametros.put("mapCabDeclaraActual", declaracionActual);
    parametros.put("lstMultaDua", WebUtils.getSessionAttribute(request, "lstMultas"));
    this.liquidaDeclaracionService.liquidaDiligencia(parametros);
    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

  }

  /**
   * Metodo que permite mostrar la PreLiquidacion.
   *
   * @param request
   *          the request
   * @param response
   *          the response
   * @return the model and view
   * @throws Exception
   *           the exception
   */
  public ModelAndView mostrarLiquidacion(HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    // Validamos la liquidacion
    try
    {

      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", -1);

      this.liquidarDeclaracion(request);

      // Cargamos la ventana de confirmacion
      Map declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      Map diferenciaTributos = (HashMap) declaracionActual.get("diferenciaTributos");
      List listaAutoliquidaciones = (List) declaracionActual.get("lstAutoliquidaciones");
      List<Map<String, Object>> lstGarantias = (List<Map<String, Object>>) declaracionActual.get("lstGarantias");
      MovCabliqdilig movCabliqdilig = (MovCabliqdilig) declaracionActual.get("movCabliqdilig");
      // 10 y 70,muestra liquidacion, 20 y 21 muestra liquidacion con garantia
      String paginaLiquida = SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "10,70") ?
          "destino/MuestraLiquidacion" : "destino/MuestraLiquidacionGarantia";
      // Se obtiene el resultado de la Preliquidaci�n

      String sCodTipDiligencia = declaracionActual.get("codTipdiligencia").toString();
      if (SunatStringUtils.isStringInList(declaracionActual.get("COD_REGIMEN").toString(), "20,21")
          && CollectionUtils.isNotEmpty(lstGarantias)
          && SunatStringUtils.isStringInList(sCodTipDiligencia, "02,03"))
      {

        Map<String, Object> mapCabAdiDiligVinc = new HashMap<String, Object>();

        String sCodTipGaranVinc = "";
        BigDecimal bMtoGarantiaVinc = new BigDecimal(0);
        for (Map<String, Object> mapGarantia : lstGarantias)
        {
          sCodTipGaranVinc = mapGarantia.get("CTIPO_GLOESP").toString();
          bMtoGarantiaVinc = bMtoGarantiaVinc.add(new BigDecimal(Double.parseDouble(mapGarantia
              .get("VTVINCU_DOCAFI")
              .toString())));
        }
        mapCabAdiDiligVinc.put("COD_TIPGARANVINC", sCodTipGaranVinc);
        mapCabAdiDiligVinc.put("MTO_GARANTIAVINC", bMtoGarantiaVinc);

        WebUtils.setSessionAttribute(request, "mapCabAdiDiligVinc", mapCabAdiDiligVinc);
      }

      Map resulPreliq = (Map) declaracionActual.get("resulPreliq");
      if ("NO".equals(resulPreliq.get("ERROR")))
      {
        ModelAndView view = new ModelAndView(paginaLiquida, "diferenciaTributos", diferenciaTributos);
        view.addObject("listaAutoliquidaciones", listaAutoliquidaciones);
        view.addObject("movCabliqdilig", movCabliqdilig);
        view.addObject("lstGarantias", lstGarantias);
        view.addObject("hdn_cod_aduana", declaracionActual.get("COD_ADUANA"));
        view.addObject("hdn_ann_presen", declaracionActual.get("ANN_PRESEN").toString());
        view.addObject("hdn_cod_regimen", declaracionActual.get("COD_REGIMEN"));
        view.addObject("grabaLC", declaracionActual.get("grabaLC"));
        view.addObject("grabaPago", declaracionActual.get("grabaPago"));

        view.addObject("tieneIncTrib", declaracionActual.get("tieneIncTrib"));
        view.addObject("codTipdiligencia", declaracionActual.get("codTipdiligencia"));

        view.addObject(
            "hdn_num_declaracion",
              Cadena.padLeft(declaracionActual.get("NUM_DECLARACION").toString(), 6, '0'));
        view.addObject(
            "msgActGarantia",
              declaracionActual.get("msgActGarantia") != null ? declaracionActual.get("msgActGarantia") : "");
        return view;
      }
      else
      {
        MensajeBean rBean = new MensajeBean();
        rBean.setError(true);
        rBean.setMensajeerror(resulPreliq.get("ERROR").toString());
        rBean.setMensajesol("Verificar");
        return new ModelAndView("PagM", "beanM", rBean);
      }

    }
    catch (Exception e)
    {
      MensajeBean rBean = new MensajeBean();
      rBean.setError(true);
      rBean.setMensajeerror(e.getMessage());
      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
      log.error("*** ERROR ***", e);
      return new ModelAndView("PagM", "beanM", rBean);
    }
  }



  /***********************SET DE SPRING **********************************/




  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }

  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }
  
  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

}