package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.bean.RegistroIncidenciaForm;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.IncidenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaCulminacionPecoService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService; 
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumVariablesSession; 
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ReflectionUtil;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by amancilla on 15/09/2014.
 */
public class IncidenciaController extends AbstractDespachoController {


    private LiquidaDeclaracionService liquidaDeclaracionService;

    private SerieService serieService;

    private SoporteService soporteService;

    private IncidenciaService incidenciaService;
 
    //PAS20171U220200005
	private FabricaDeServicios fabricaDeServicios;

    //P34 AFMA
    private RectificacionOficioService rectificacionOficioService;

   public void setRectificacionOficioService(RectificacionOficioService rectificacionOficioService) {
        this.rectificacionOficioService = rectificacionOficioService;
    }

    //P34 AFMA
    private DiligenciaCulminacionPecoService diligenciaCulminacionPecoService;

    public void setdiligenciaCulminacionPecoService(DiligenciaCulminacionPecoService diligenciaCulminacionPecoService) {
        this.diligenciaCulminacionPecoService = diligenciaCulminacionPecoService;
    }
    //fin P34 AFMA

    public ModelAndView cargarRegistroIncidencia(HttpServletRequest request, HttpServletResponse response) throws Exception
    {

    	try{
        //esto se setea en RegDdiligencia
        //params.put("cod_tiplugarrecep", request.getParameter("hdn_cod_tiplugarrecep"));

        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");



          Map<String, String> params = new HashMap<String, String>();
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
            params.put("num_declaracion", declaracionActual.get("NUM_DECLARACION").toString());
            params.put("cod_aduana", declaracionActual.get("COD_ADUANA").toString());
            params.put("ann_presen", declaracionActual.get("ANN_PRESEN").toString());
            params.put("cod_regimen", declaracionActual.get("COD_REGIMEN").toString());
            params.put("ind_mercavig", declaracionActual.get("IND_MERCANCIAVIGENTE").toString()); //PAS20171U220200005

        List<IncidenciaBean> lstIncidencias = null;

        IncidenciaBean incidenciaBean = new IncidenciaBean();
        HttpSession session = request.getSession();
        incidenciaBean.setCabAnteriorMap((Map<String, Object>) session.getAttribute("mapCabDeclara"));
        incidenciaBean.setCabActualMap((Map<String, Object>) session.getAttribute("mapCabDeclaraActual"));
        incidenciaBean.setDetAnteriorList((List<Map<String, Object>>) session.getAttribute("lstDetDeclara"));
        incidenciaBean.setDetActualList((List<Map<String, Object>>) session.getAttribute("lstDetDeclaraActual"));
        incidenciaBean.setEntidadMaestro("CAB_DECLARA");
        incidenciaBean.setEntidadDetalle("DET_DECLARA");
        lstIncidencias = incidenciaService.asignarIncidencia(incidenciaBean);
        String[] codIncidenciasAuto = (String[]) WebUtils.getSessionAttribute(request, "codIncidenciasAuto");

        if (codIncidenciasAuto != null)
        {
            for (int i = 0; i < codIncidenciasAuto.length; i++)
            {
                for (int j = 0; j < lstIncidencias.size(); j++)
                {
                    IncidenciaBean incidenciaView = (IncidenciaBean) lstIncidencias.get(j);
                    if (codIncidenciasAuto[i].equals((String) incidenciaView.getCod_incidencia()))
                    {
                        incidenciaView.setFlagIncidencia(true);
                        break;
                    }
                }
            }
        }
        WebUtils.setSessionAttribute(request, "lstIncidencias", lstIncidencias);

        //no se usa
        request.setAttribute("lstIncidencias", lstIncidencias);
        request.setAttribute("params", params);

        setearIncidenciasAutomaticas(request);
        setearIncidenciasManuales(request);

        //Inicio PAS20171U220200005 cargar totales de incidencia
        Map<String, Object> paramsInc = new HashMap<String, Object>(); 
        paramsInc.put("numCorredoc",declaracionActual.get("NUM_CORREDOC").toString());
    	DeclaracionCuentaCorrienteService declaracionCuentaCorrienteService= fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		List<CabCtacteRegimen>  lstCantUnidadReportada = declaracionCuentaCorrienteService.obtenerListaCantidadesReportadas(paramsInc); 
        List<Map<String, Object>> listCantidadesReportadas = new ArrayList<Map<String, Object>>(); 
        if(!CollectionUtils.isEmpty(lstCantUnidadReportada)) {
        	//List<Integer> listSerie = new ArrayList<Integer>();
        	for(CabCtacteRegimen datosRegistrados : lstCantUnidadReportada) {
        		//if(!listSerie.contains(datosRegistrados.getNumSerie())) {
        			 Map<String, Object> registro = new HashMap<String, Object>();
            		 registro.put("serie", datosRegistrados.getNumSerie() );
            		 registro.put("cantidadReportada", datosRegistrados.getCntUnidades()); 
            		 BigDecimal cntAfectadosBD = declaracionCuentaCorrienteService.verificarRelacionSeriesAfectadas(datosRegistrados);
            		 registro.put("cntAfectadaSerie", cntAfectadosBD);
            		// listSerie.add(datosRegistrados.getNumSerie());
            		 listCantidadesReportadas.add(registro);
        		//}        		
        	}
        }
         request.setAttribute("jsonListaCantReportada",listCantidadesReportadas!=null ? SojoUtil.toJson(listCantidadesReportadas):"[]");
        //Fin PAS20171U220200005 cargar totales de incidencia
       
        
        return new ModelAndView("RegistroIncidencia", "lstIncidencias", lstIncidencias);
        /*inicio P21-P22 se a�ade bloque try catch*/
    	}catch (Exception e){
    	      MensajeBean rBean = new MensajeBean();
    	      rBean.setError(true);
    	      rBean.setMensajeerror(e.getMessage());
    	      rBean.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
    	      //log.error("*** ERROR ***", e);
    	      return new ModelAndView("PagM", "beanM", rBean);
    	 }
    	/*P21-P22 fin*/
    }


    // RIN13
    private void setearIncidenciasManuales(HttpServletRequest request) throws Exception {

      List<RegistroIncidenciaForm> lstIncidenciasManuales = new ArrayList<RegistroIncidenciaForm>();

      lstIncidenciasManuales  = (ArrayList<RegistroIncidenciaForm>)WebUtils.getSessionAttribute(request, "lstIncidenciasManuales");

      if(CollectionUtils.isEmpty(lstIncidenciasManuales)) {

        lstIncidenciasManuales = new ArrayList<RegistroIncidenciaForm>();

        // se crearon los grupos 607,608
        List<Map<String,String>>  lstG607 = (List<Map<String,String>>)catalogoAyudaService.getListaElementosGrupo("607");

        List<Map<String,String>>  lstG608 = (List<Map<String,String>>)catalogoAyudaService.getListaElementosGrupo("608");

        RegistroIncidenciaForm incidencia;
        for(Map<String,String> map: lstG607) {
          incidencia = new RegistroIncidenciaForm();
          incidencia.setCodIncidencia(map.get("cod_datacat").toString());
          incidencia.setCodIncidenciaDescrip(map.get("des_corta").toString());
          incidencia.setChkSeleccionado(false);
          lstIncidenciasManuales.add(incidencia);
        }

        for(Map<String,String> map: lstG608) {
          incidencia = new RegistroIncidenciaForm();
          incidencia.setCodIncidencia(map.get("cod_datacat").toString());
          incidencia.setCodIncidenciaDescrip(map.get("des_corta").toString());
          incidencia.setChkSeleccionado(false);
          lstIncidenciasManuales.add(incidencia);
        }


        WebUtils.setSessionAttribute(request, "lstIncidenciasManuales", lstIncidenciasManuales);
      }


      JSONArray jsonObject = JSONArray.fromObject(lstIncidenciasManuales);
      request.setAttribute("jsonListaManuales", jsonObject);

    }

    // RIN13
    private void setearIncidenciasAutomaticas(HttpServletRequest request) throws Exception {

        List<RegistroIncidenciaForm> lstIncidenciasAutomaticas = new ArrayList<RegistroIncidenciaForm>();

        boolean tieneIncidencia = tieneIncidenciaTributaria(request);
     /*   if(tieneIncidenciaTributaria(request)){*/


            Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
            Map<String, Object> declaracion = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");

            MovCabliqdilig movCabliqdilig = (MovCabliqdilig) declaracionActual.get("movCabliqdilig");
            List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
            List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");

            List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
            List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");

            HttpSession session = request.getSession();

            if (CollectionUtils.isEmpty(lstSeriesItemActual)){
                Map<String, Object> param = new HashMap<String, Object>();
                Long numCorredoc = new Long(declaracionActual.get("NUM_CORREDOC").toString());
                param.put("NUM_CORREDOC", numCorredoc);

                lstSeriesItem = serieService.obtenerSeriesItem(param);
                lstSeriesItemActual = Utilidades.copiarLista((List)lstSeriesItem);
                // List lstSeriesItemBD = serieService.obtenerSeriesItem(param);
                //session.setAttribute("lstSeriesItem", lstSeriesItemBD);
                //lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItemBD);
                //session.setAttribute("lstSeriesItemActual", lstSeriesItemActual);
            }


            // validamos los datos principales
            if (!org.springframework.util.CollectionUtils.isEmpty(declaracionActual)
                    && !CollectionUtils.isEmpty(lstDetDeclaraActual)) {

                Map<String, Object> params = new HashMap<String, Object>();

                params.put("declaracionActual", declaracionActual);
                params.put("declaracion", declaracion);
                params.put("lstDetDeclaraActual", lstDetDeclaraActual);
                params.put("lstDetDeclaraAnt", lstDetDeclara);
                params.put("lstSeriesItemActual", lstSeriesItemActual);
                params.put("lstSeriesItem", lstSeriesItem);
                params.put("movCabliqdilig", movCabliqdilig);
                params.put("tieneIncidencia", tieneIncidencia);

            // crear una nueva lista agrupada especial para la vista
            List<Incidencia> incidencias  = incidenciaService.obtenerIncidenciaAutomatica(params);
            //esto es lo que se debe grabar en session
            WebUtils.setSessionAttribute(request, "incidenciasAuto", incidencias);
            //WebUtils.setSessionAttribute(request, "lstIncidenciasAutomaticas", incidencias);
            //siempre se pone lo ultimo por si a modificado algun dato
            lstIncidenciasAutomaticas =  armarListaIncidenciasAutomaticas(incidencias);

        }


        // mandar el json amancilla se corrige para cuando llega vacio            
       // JSONArray jsonObject = JSONArray.fromObject(lstIncidenciasAutomaticas);
        request.setAttribute("jsonListaAutomaticas", !CollectionUtils.isEmpty(lstIncidenciasAutomaticas) ?JSONArray.fromObject(lstIncidenciasAutomaticas):"[]");
     /* }else{

    	  request.setAttribute("jsonListaAutomaticas", "[]");
      }*/

    }




    // RIN13
    private List<RegistroIncidenciaForm> armarListaIncidenciasAutomaticas(List<Incidencia> lista) throws Exception {

        //Collections.sort(lista);
    	if (lista.size() > 0) {
    	    Collections.sort(lista, new Comparator<Incidencia>() {
    	        @Override
    	        public int compare(final Incidencia object1, final Incidencia object2) {
    	            //return object1.getName().compareTo(object2.getName());
    	        	final int BEFORE = -1;
    	            final int EQUAL = 0;
    	            final int AFTER = 1;

    	            int comparison = object1.getCodIncidencia().compareTo(object2.getCodIncidencia());
    	            if (comparison != EQUAL) return comparison;

    	            if (object1.getNumeroSerie() < object2.getNumeroSerie()) return BEFORE;
    	            if (object1.getNumeroSerie() > object2.getNumeroSerie()) return AFTER;

    	            return EQUAL;
    	        }
    	       } );
    	   }
    	
        List<RegistroIncidenciaForm> listaCompleta = new ArrayList<RegistroIncidenciaForm>();
        RegistroIncidenciaForm incidencia;
        Map itemCat;
        String primerCodigo = "";

        //A1,A2,B2,C4-> A {1,2}
        for(Incidencia incidenciaAuto: lista) {

          if(!primerCodigo.equals(incidenciaAuto.getCodIncidencia())) {
            incidencia = new RegistroIncidenciaForm();

            incidencia.setCodIncidencia(incidenciaAuto.getCodIncidencia());
            itemCat = catalogoAyudaService.getElementoCat("336", StringUtils.trimToEmpty(incidenciaAuto.getCodIncidencia()));
            incidencia.setCodIncidenciaDescrip(itemCat.get("des_corta").toString());

            listaCompleta.add(incidencia);
            primerCodigo = incidenciaAuto.getCodIncidencia();
          }
        }

        //lista llenada construyo el patron
        List<Integer> seriesXCodigo;
        for(RegistroIncidenciaForm incidenciaForm: listaCompleta) {

          List<Incidencia> lstIncidenciasXCodigoIncidencia = ReflectionUtil.getObjectFromList(lista, Incidencia.class, "codIncidencia",incidenciaForm.getCodIncidencia());

          String patron="";
          if (!CollectionUtils.isEmpty(lstIncidenciasXCodigoIncidencia)) {
            seriesXCodigo = new ArrayList<Integer>();
             for(Incidencia incidencia2: lstIncidenciasXCodigoIncidencia) {
                    if(incidencia2.getNumeroSerie()!=null && incidencia2.getNumeroSerie() > 0){
               seriesXCodigo.add(incidencia2.getNumeroSerie());
             }
                }
             Integer[] seriesArr = new Integer[seriesXCodigo.size()];
             seriesArr = seriesXCodigo.toArray(seriesArr);
             patron = obtenerPatronSerie(seriesArr);
          }

          incidenciaForm.setPatronSeriesAfectados(patron);
        }

        return listaCompleta;
    }



    private String obtenerPatronSerie(Integer[] series){

        if(series.length==0) return "";

        Arrays.sort(series);
        int min =series[0];
	        int max= series[series.length-1];	        
	        int rangoAnt=0,rangoNext =0;
	        int maxGrupo=0;
	        boolean grupo = false;
	        StringBuilder patron = new StringBuilder();

	        for (int i = 0; i < series.length; i ++){	       	        	
	        	rangoAnt  = series[i]-(series[i]!=min?series[i-1]:min);
	        	if(rangoAnt==0){
        patron.append(min);
	        		continue;
	        	}	        		
	        	rangoNext = (max!=series[i])?(series[i+1]-series[i]):0;
	        	if (rangoAnt ==1 && rangoNext==1){
	        		grupo = true;        		
	        	} 	        	
	        	if(grupo){	        		
                    patron.append("-");
	        		int indMaxGrupo = obtenerIndiceMaxGrupo(i,series);
	        		maxGrupo = series[indMaxGrupo];	        		
	        		patron.append(maxGrupo);
	        		i=indMaxGrupo;	        		
	        		grupo = false;  
	        		continue;
	        	}else{	        		
                patron.append(",");
	        		patron.append(series[i]);
	        		continue;
            }
        }

        return patron.toString();
    }

    private int obtenerIndiceMaxGrupo(int indiceActual, Integer[] series) {
		 
		 int max = 0;
		 int valor=0;
		 int valorsgte =0;
		 for (int i = indiceActual; i < series.length; i ++){
			 valor = series[i];
			 valorsgte =  (series[series.length-1]!=series[i])?series[i+1]:series[series.length-1];
			 if(valorsgte-valor==1){
				 max = i+1;
				 continue;
			 }else{
				break; 
			 }
		 }
		 
		return max;
	}
    /*
    public static boolean contenido(Integer[] arr, int targetValue) {
        return Arrays.asList(arr).contains(targetValue);
    }*/


    /**
     * Se adapta metodo liquidarDeclaracion  de LiquidcionCOntroller
     *  usado al grabar la diligencia para que retorne
     * Map parametros:
     * tieneIncTrib S o N
     **/
    private boolean tieneIncidenciaTributaria(HttpServletRequest request) throws Exception
    {

        boolean rspta = false;
        ServletWebRequest webRequest = new ServletWebRequest(request);
        Map resulPreliq = new HashMap();
        resulPreliq.put("ERROR", "NO");

        Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");


        //P34 afma mejora solo ejcuta preliquida si hay cambio de datos por el usuario
        //amancilla tambien se agrega que tenga canal sino la recti de oficio va mostrar indencia cuando el prooblema es que no ha pagado


        String canal =  declaracionActual.get("COD_CANAL")!=null?declaracionActual.get("COD_CANAL").toString():"";
        String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);

        if(Constantes.MODULO_RECTIFICACION_OFICIO.equals(tipoDiligencia) && (StringUtils.isBlank(canal) || noTieneDatosModificadosPorElUsuario(request))){
            return false;
        }
            //pase69
        if(Constantes.MODULO_CULMINACION_PECO.equals(tipoDiligencia) && (StringUtils.isBlank(canal) || noTieneDatosModificadosPorElUsuario(request))){
            return false;
        }

        if (CollectionUtils.isEmpty(listDetDeclara))
        {
        	Map<String, String> params = new HashMap<String, String>();
            params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
            params.put("num_corredoc", declaracionActual.get("NUM_CORREDOC").toString());
            params.put("num_declaracion", declaracionActual.get("NUM_DECLARACION").toString());
            params.put("cod_aduana", declaracionActual.get("COD_ADUANA").toString());
            params.put("ann_presen", declaracionActual.get("ANN_PRESEN").toString());
            params.put("cod_regimen", declaracionActual.get("COD_REGIMEN").toString());

            listDetDeclara = serieService.obtenerListadoSeries(params);

            //limpia la variable de session
            WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);
            List<Map<String, Object>> lstSerieOld= new ArrayList<Map<String, Object>>();
            lstSerieOld.addAll(Utilidades.copiarLista((List)listDetDeclara));

            List<Map<String, Object>> lstSerieNew= new ArrayList<Map<String, Object>>();
            lstSerieNew.addAll(Utilidades.copiarLista((List)listDetDeclara));

            WebUtils.setSessionAttribute(request, "lstDetDeclara", lstSerieOld);
            WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstSerieNew);
            listDetDeclara = new ArrayList(lstSerieOld);

            if (CollectionUtils.isEmpty(listDetDeclara))
            {
            	log.debug("ERROR-No se han cargado las series");
                return rspta;
            }
        }

        List listParticipanteDoc = new ArrayList();
        // Obtenemos de cabDeclara (importador y agente)
        if (declaracionActual.get("COD_TIPDOC_PIM") != null)
        {
            Map mapImport = new HashMap();
            mapImport.put("COD_TIPPARTIC", "45");
            mapImport.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PIM"));
            mapImport.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PIM"));
            listParticipanteDoc.add(mapImport);
        }

        if (declaracionActual.get("NUM_DOCIDENT_PDE") != null)
        {
            Map mapAgent = new HashMap();
            mapAgent.put("COD_TIPPARTIC", "41");
            mapAgent.put("COD_TIPDOC", declaracionActual.get("COD_TIPDOC_PDE"));
            mapAgent.put("NUM_DOCIDENT", declaracionActual.get("NUM_DOCIDENT_PDE"));
            listParticipanteDoc.add(mapAgent);
        }

        if (listParticipanteDoc.isEmpty())
        {
            log.debug("ERROR-No existe lista de Participantes");
            return rspta;
        }

        UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
        UserNameHolder.set(bUsuario.getNroRegistro(), request.getRemoteAddr());

        List listConvenioSerie = new ArrayList();
        List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
        Map<String, Object> serieEliminada = null;
        for (Map<String, Object> detDeclaraMap : listDetDeclara)
        {
            if ("1".equals(detDeclaraMap.get("IND_DEL")))
            {
                serieEliminada = detDeclaraMap;
                listaSerieEliminada.add(serieEliminada);
                continue;
            }
            if (CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
            {
                detDeclaraMap.put("lstConvenioSerie", serieService.obtenerConvenioSerieMap(detDeclaraMap));
            }
            if (!CollectionUtils.isEmpty((List) detDeclaraMap.get("lstConvenioSerie")))
            {
                List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) detDeclaraMap.get("lstConvenioSerie");
                for (int i = 0; i < lstConvenioSerie.size(); i++)
                {
                    HashMap convenio = (HashMap) lstConvenioSerie.get(i);
                    if (!"1".equals(convenio.get("IND_DEL")))
                    {
                        // en la rectificacion no se agrega el ind_eliminado a los nuevos
                        // convenios
                        listConvenioSerie.add(convenio);
                    }
                }
            }
        }
        for (Map<String, Object> mapEliminar : listaSerieEliminada)
        {
            listDetDeclara.remove(mapEliminar);
        }

        List listDocupreceDua = (ArrayList) WebUtils.getSessionAttribute(request, "lstDocuPreceDuaActual");
        HashMap paramDocLiq = new HashMap();
        paramDocLiq.put("codTipLiqui", ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA);
        paramDocLiq.put("codTipdiligencia", WebUtils.getSessionAttribute(request, "tipoDiligencia"));
        paramDocLiq.put("cabDeclara", declaracionActual);
        paramDocLiq.put("listDetDeclara", listDetDeclara);
        paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
        paramDocLiq.put("listConvenioSerie", listConvenioSerie);
        paramDocLiq.put("listDocupreceDua", listDocupreceDua);
        paramDocLiq.put("listaSerieEliminada", listaSerieEliminada);
        paramDocLiq.put("caduana", soporteService.obtenerAduana(request));
        resulPreliq = liquidaDeclaracionService.preliquidacion(paramDocLiq);

        if ("NO".equals(resulPreliq.get("ERROR"))) {

            declaracionActual.put("caduana", soporteService.obtenerAduana(request));
            Map parametros = new HashMap();
            declaracionActual.put("resulPreliq", resulPreliq);
            parametros.put("mapCabDeclaraActual", declaracionActual);
            parametros.put("lstMultaDua", WebUtils.getSessionAttribute(request, "lstMultas"));
            this.liquidaDeclaracionService.liquidaDiligencia(parametros);

            WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", declaracionActual);

            return declaracionActual.get("tieneIncTrib")!=null && "S".equals(declaracionActual.get("tieneIncTrib").toString())?true:false;

        }

       return rspta;
    }




  public ModelAndView
      grabarIncidenciasSession(HttpServletRequest request, HttpServletResponse response)
                                                                                        throws Exception
  {

    ServletWebRequest webRequest = new ServletWebRequest(request);
     String lstIncidenciasManualesString = webRequest.getParameter("lstIncidenciasManuales")!=null?webRequest.getParameter("lstIncidenciasManuales"):"";
      JSONArray arrayDocTransporteProrratear = JSONArray.fromObject(lstIncidenciasManualesString);
      List<RegistroIncidenciaForm> lstIncidenciasManuales = (List<RegistroIncidenciaForm>) JSONArray.toCollection(arrayDocTransporteProrratear, RegistroIncidenciaForm.class);

      Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
      Long numCorredoc = new Long(declaracionActual.get("NUM_CORREDOC").toString());
      List<Map<String, Object>> listDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
      ModelAndView res = new ModelAndView(this.jsonView);

      try{

    	  List<Incidencia> incidenciasManualesReales = armarListaIncidenciasManualesParaGrabar(lstIncidenciasManuales,listDetDeclara);

          //amancilla parche esta cayendose como canchita en pelicula no se pq ponen get(0) clasico error
          if(!org.springframework.util.CollectionUtils.isEmpty(incidenciasManualesReales)){
    	  if(incidenciasManualesReales.get(0).getCodIncidencia().equals("F121")){
    		  String lstSerieSaldos = webRequest.getParameter("ListaSeries")!=null?webRequest.getParameter("ListaSeries"):"";
    		  JSONArray arrayDocTransporteProrratearSaldo = JSONArray.fromObject(lstSerieSaldos); 
    		  
             List<RegistroIncidenciaForm> lstSeriesSaldo = (List<RegistroIncidenciaForm>) JSONArray.toCollection(arrayDocTransporteProrratearSaldo, RegistroIncidenciaForm.class);
    		  
    		 /*for (RegistroIncidenciaForm form : lstSeriesSaldo){
    			CabCtacteRegimen datosCtaCte = new CabCtacteRegimen();
    		    datosCtaCte.setNumCorredoc(numCorredoc); 
    		    datosCtaCte.setNumCtacte((long) 0);
    		    datosCtaCte.setNumSerie(form.getNumeroSerie());
    	        BigDecimal montoActual = new BigDecimal(form.getMontoActual());
    		    datosCtaCte.setCntUnidades(montoActual);
    		    BigDecimal montoCorregido = new BigDecimal(form.getMontoCorregido());
    		    datosCtaCte.setCntSaldoUnidad(montoCorregido);
    		    datosCtaCte.setCodTipoUnidad(form.getCodIncidencia());
    			declaracionCuentaCorrienteService.insertarCtacteRegimen(datosCtaCte,numCorredoc);  
    		  }*/
    		 WebUtils.setSessionAttribute(request, "lstSeriesSaldo", lstSeriesSaldo);
    		 
    	  }
          }

          WebUtils.setSessionAttribute(request, "incidenciasManu", incidenciasManualesReales);   //para el grabado             	      
          WebUtils.setSessionAttribute(request, "lstIncidenciasManuales", lstIncidenciasManuales);//para la vistas

    res.addObject("recOk", true);

      }catch(ServiceException e){
    	                               
          MensajeBean rBean = new MensajeBean();
          rBean.setError(true);
          rBean.setMensajeerror(e.getMessage());          
          res.addObject("beanM", rBean);
      }
      

    return res;


  }

  private List<Incidencia> armarListaIncidenciasManualesParaGrabar(List<RegistroIncidenciaForm> incidenciasForm,List<Map<String, Object>> listDetDeclara) throws Exception {

    List<Incidencia> lista = new ArrayList();

    Incidencia incidencia;
    for(RegistroIncidenciaForm form : incidenciasForm){
      if(form.isChkSeleccionado()) {
        if(StringUtils.isEmpty(form.getPatronSeriesAfectados())){
            incidencia = new Incidencia();
            incidencia.setCodIncidencia(form.getCodIncidencia());
            lista.add(incidencia);
        }else {
        	
          try{
        	  for(Integer serie:  obtenerSeriesDelPatron(form.getPatronSeriesAfectados(),listDetDeclara) ) {
            incidencia = new Incidencia();
            incidencia.setCodIncidencia(form.getCodIncidencia());
            incidencia.setNumeroSerie(serie);
            lista.add(incidencia);
          }
          }catch (ServiceException e){
        	  throw new ServiceException(this,"Serie(s) seleccionada(s) para la incidencia: "+form.getCodIncidencia()+"-"+form.getCodIncidenciaDescrip()+" no existen:"+e.getMessage());         	  
          }	
                    
        }
      }
    }

    return lista;
  }

  private List<Integer>  obtenerSeriesDelPatron(String patron,List<Map<String, Object>> listDetDeclara){

    List<Integer> series = new ArrayList();
    List<Integer> seriesInvalidas = new ArrayList();
    if(patron.contains(",")) {
      String[] splitComas = patron.split(",");
      for(String coma : splitComas) {
        if(coma.contains("-")) {
          String[] splitGuion = coma.split("-");
          int min = Integer.parseInt(splitGuion[0]);
          int max = Integer.parseInt(splitGuion[1]);
          for(int i=min; i<=max; i++){
            //series.add(i);
            agregarSerie(series,i,listDetDeclara,seriesInvalidas);
          }
        }else {
          int serie = Integer.parseInt(coma);
          agregarSerie(series,serie,listDetDeclara,seriesInvalidas);
          //series.add(serie);
        }
      }
    }else if(patron.contains("-")){
    	 String[] splitGuion = patron.split("-");
         int min = Integer.parseInt(splitGuion[0]);
         int max = Integer.parseInt(splitGuion[1]);
         for(int i=min; i<=max; i++){
           //series.add(i);
           agregarSerie(series,i,listDetDeclara,seriesInvalidas);
         }
    }else {
      //es un numero solo
      int serie = Integer.parseInt(patron);
      agregarSerie(series,serie,listDetDeclara,seriesInvalidas);
      //series.add(serie);
    }
    
    if(!CollectionUtils.isEmpty(seriesInvalidas)){
    	StringBuilder sb = new StringBuilder(); 
    	
    	for(Integer serie : seriesInvalidas){
    		sb.append(serie.toString()).append(",");    		
    	}  
    	
    	sb.deleteCharAt(sb.length()-1);//borra la ultima coma
    	
    	throw new ServiceException(this,sb.toString());
    }

    return series;
}

  private void agregarSerie( List<Integer> series,int serie,List<Map<String, Object>> listDetDeclara,List<Integer> seriesInvalidas){

	  boolean rspta = false;
	  
	  Map<String, Object> mapBuscar = new HashMap<String, Object>();
	  mapBuscar.put("NUM_SECSERIE", serie);
	  
      Map serieEncontrada = Utilidades.obtenerElemento(listDetDeclara, mapBuscar);
      if (!org.springframework.util.CollectionUtils.isEmpty(serieEncontrada))
      {    	       	  
    	  series.add(serie);
      }else{
    	  seriesInvalidas.add(serie);
      }         
  }
  
  

    //P34 AFMA INICIO

    private boolean noTieneDatosModificadosPorElUsuario(HttpServletRequest request){


        // devulevo la lista de cambios
        List<DatoModificadoBean> listaCambiosFomatoAyB = new ArrayList<DatoModificadoBean>();
        // obtiene los datos de la Sesssion
        Map<String, Object> mapCabDeclaraActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
        Map<String, Object> mapCabDeclara = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclara");
        List<Map<String, Object>> lstDetDeclaraActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclara = (ArrayList) WebUtils.getSessionAttribute(request, "lstDetDeclara");
        List<Map<String, Object>> lstSeriesItemActual = (ArrayList) WebUtils.getSessionAttribute(request,"lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItem = (ArrayList) WebUtils.getSessionAttribute(request, "lstSeriesItem");

        if (!org.springframework.util.CollectionUtils.isEmpty(mapCabDeclaraActual)) {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("mapCabDeclaraActual", mapCabDeclaraActual);
            params.put("mapCabDeclara", mapCabDeclara);
            params.put("lstDetDeclaraActual", lstDetDeclaraActual);
            params.put("lstDetDeclara", lstDetDeclara);
            params.put("lstSeriesItemActual", lstSeriesItemActual);
            params.put("lstSeriesItem", lstSeriesItem);
            //params.put("lstFacturasSerieActual", lstFacturasSerieActual);
            //params.put("lstFacturasSerie", lstFacturasSerie);
            listaCambiosFomatoAyB = rectificacionOficioService.obtenerCambiosDeclaracion(params);
        }

        return  CollectionUtils.isEmpty(listaCambiosFomatoAyB)?true:false;
    }



    //P34 AFMA FINAL


    public LiquidaDeclaracionService getLiquidaDeclaracionService() {
        return liquidaDeclaracionService;
    }

    public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
        this.liquidaDeclaracionService = liquidaDeclaracionService;
    }

    public SerieService getSerieService() {
        return serieService;
    }

    public void setSerieService(SerieService serieService) {
        this.serieService = serieService;
    }

    public SoporteService getSoporteService() {
        return soporteService;
    }

    public void setSoporteService(SoporteService soporteService) {
        this.soporteService = soporteService;
    }

    public IncidenciaService getIncidenciaService() {
        return incidenciaService;
    }

    public void setIncidenciaService(IncidenciaService incidenciaService) {
        this.incidenciaService = incidenciaService;
    }
    //PAS20171U220200005
    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
}
