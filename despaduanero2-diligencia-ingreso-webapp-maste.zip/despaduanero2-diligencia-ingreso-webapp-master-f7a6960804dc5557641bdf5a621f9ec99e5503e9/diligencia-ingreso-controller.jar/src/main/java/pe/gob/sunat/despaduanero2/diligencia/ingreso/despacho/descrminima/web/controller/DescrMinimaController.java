package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.descrminima.web.controller;

import java.util.*;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.despaduanero2.ayudas.bean.ResponseCatalogoRest;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.Example;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;//adicionado arey
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;//P24 PAS20175E220200035
import pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service.DescrMinimaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service.PlantillaFactory;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ModelFactory;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.DetalleSolicitudRectifica;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

@Controller
public class DescrMinimaController
{
	
  @Autowired
  private FabricaDeServicios fabricaDeServicios;
  
	private final Log logger = LogFactory.getLog(getClass());

	  @Autowired
	  @Qualifier("Ayuda.catalogoAyudaService")
	  private CatalogoAyudaService catalogoAyudaService;

	  @RequestMapping(value = "/consulta", method = RequestMethod.GET)
	  public ModelAndView cargarConsultaDescrMinima(@RequestParam(value = "numCorreDoc", required = true) Long numCorreDoc,
	                                          @RequestParam(value = "numSecItem", required = true) Long numSecItem)  throws Exception
      {
          String tipoDescrMinima="";
          String versionPlantilla="";//PAS20165E220200138
          logger.debug("cargarConsultaDescrMinima-numCorreDoc:"+numCorreDoc);
          logger.debug("cargarConsultaDescrMinima-numSecItem:"+numSecItem);
          ModelAndView model = new ModelAndView("consultaDescrMinima");

          Map<String, Object> mapDatosDescr=new HashMap<String, Object>();
          try{
              List listdetItem = poblarItemDescrMinima(numCorreDoc, numSecItem.intValue());

              if (!CollectionUtils.isEmpty(listdetItem))
              {
                  tipoDescrMinima = ((HashMap)listdetItem.get(0)).get("tipoDescrMnima").toString();

                  if(!SunatStringUtils.isEmpty(tipoDescrMinima))
                  {
                      mapDatosDescr.put("tipoDescrMinima",tipoDescrMinima);
                      mapDatosDescr.put("numCorreDoc", numCorreDoc);
                      mapDatosDescr.put("numSecItem", numSecItem);

                      //Inicio-PAS20165E220200138		  
            		  if(tipoDescrMinima!=null){		  
            				Enum<?> tipo = TipoDescrMinima.get(((HashMap)listdetItem.get(0)).get("tipoDescrMnima").toString());				
            				if(tipo!=null){					
                                // agregar version de plantilla
            					ModelAbstract objeto = ModelFactory.crearObjetoDescrMinima(tipo);
            					objeto.setFechaIniVigenciaValidador(SunatDateUtils.getDateFromUnknownFormat(((HashMap)listdetItem.get(0)).get("Fecdeclaracion").toString()));
            					PlantillaFactory plantillaFactory= fabricaDeServicios.getService("descripcionMinima.PlantillaFactory");
            					//validadorFactory.crearValidadorDescrMinima(objeto);
            					versionPlantilla=plantillaFactory.obtenerVersionEstrutura(objeto);
            					((HashMap)listdetItem.get(0)).put("VERSION_PLANTILLA",versionPlantilla);
            				}		
            		  }
            		  mapDatosDescr.put("versionPlantilla",versionPlantilla);
            		  mapDatosDescr.put("FechaIniVigenciaValidador",SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownObject(((HashMap)listdetItem.get(0)).get("Fecdeclaracion")), "yyyy-MM-dd"));
              	  	  //Fin-PAS20165E220200138
                      model.addObject("mapDatosDescr",SojoUtil.toJson(mapDatosDescr));
                  }
                  else
                  {
                      throw new ServiceException(this,"La declaracion no tiene descripciones minimas");
                  }
              }
              else
              {
                  throw new ServiceException(this,"La declaracion no tiene descripciones minimas");
              }


          }catch (Exception e){
        	  logger.info("Error en Consulta de descripcion minima",e);
              throw new ServiceException(this,"La declaracion no tiene descripciones minimas");
          }


	    logger.debug("entro consultarDescrMinima,"
	        + " numCorreDoc:"
	        + numCorreDoc
	        + " numSecItem:"
	        + numSecItem
	        + " codTipDesc:"
	        + tipoDescrMinima);
	    return  model;
	  }

	  @RequestMapping(value = "/{tipoDescrMinima}/{numCorredoc}/{numSecItem}",
	      method = RequestMethod.GET)
	  @ResponseBody
	  public
	  ModelAbstract obtenerDescrMinima(@PathVariable("tipoDescrMinima") String tipoDescrMinima,
			  @PathVariable("numCorredoc") long numCorreDoc,
			  @PathVariable("numSecItem") int numSecItem)
	  {
		  logger.debug("entro obtenerDescrMinima,"
			        + " numCorreDoc:"
			        + numCorreDoc
			        + " numSecItem:"
			        + numSecItem
			        + " tipoDescrMinima:"
			        + tipoDescrMinima);

	    Enum tipo = TipoDescrMinima.get(tipoDescrMinima);

	    logger.debug("servicio REST devuelve JSON");	    

	    ModelAbstract objeto = null;

	    if (tipo != null)
	    {
	      objeto = ModelFactory.crearObjetoDescrMinima(tipo);	      
	      objeto = poblarObjetoDescrMinimaMoock(numCorreDoc,numSecItem);
	      objeto.setTipoDescrMnima(tipoDescrMinima);
		  
		//Inicio P24 PAS20175E220200035 -se agrega para mostrar datos rectificados en minimas
				List<Map<String, String>> result = new ArrayList<Map<String, String>>();
				result = getDatosRectificadosDescrMinimas(numCorreDoc, numSecItem);
				if (result.size()>0)
					objeto.setDatosRectificados(result);
		//FIn P24 PAS20175E220200035
	    }
	    return objeto;
	    
	  }

	  @RequestMapping(value = "/{tipoDescrMinima}/{numCorredoc}/{numSecItem}/{indItem}",
		      method = RequestMethod.GET)
		  @ResponseBody
		  public
		  String obtenerItemDescrMinima(@PathVariable("tipoDescrMinima") String tipoDescrMinima,
				  @PathVariable("numCorredoc") long numCorreDoc,
				  @PathVariable("numSecItem") int numSecItem,
				  @PathVariable("indItem") String indItem)
		  {
			  logger.debug("entro obtenerDescrMinima,"
				        + " numCorreDoc:"
				        + numCorreDoc
				        + " numSecItem:"
				        + numSecItem
				        + " tipoDescrMinima:"
				        + tipoDescrMinima
				        + " indItem:"
				        + indItem);

		   Enum tipo = TipoDescrMinima.get(tipoDescrMinima);
		    logger.debug("servicio REST devuelve JSON");
		 
		    List listdetItem=null;
		    String itemDet="";		 
		    if (tipo != null && indItem.equals("1"))
		    {
		    	listdetItem = poblarItemDescrMinima(numCorreDoc,numSecItem);  
		     	itemDet=SojoUtil.toJson(listdetItem);
		    }
	        return itemDet;
		    
		  }

	  private ModelAbstract poblarObjetoDescrMinimaMoock( Long numCorreDoc, int numSecItem )
	  {
		 DescrMinimaService descrMinimaService= fabricaDeServicios.getService("descripcionMinima.DescrMinimaService");
		 ModelAbstract descrMinima = descrMinimaService.obtenerDescrMinima(numCorreDoc,numSecItem);
		 logger.debug("descrminima "+ descrMinima);
		 return descrMinima;
	  }

	  private List poblarItemDescrMinima( Long numCorreDoc, int numSecItem)
	  {
		  DescrMinimaService descrMinimaService= fabricaDeServicios.getService("descripcionMinima.DescrMinimaService");
		  List detItem =  descrMinimaService.obtenerItemDescrMinima(numCorreDoc,numSecItem);
		 
		   
	  	return detItem;
	  }




    //PASE42
    @RequestMapping(value = "/{tipoDescrMinima}/{numCorredoc}/{numSecItem}/{codTipDilgencia}/{numCorredocSol}",
  	      method = RequestMethod.GET)
  	  @ResponseBody
  	  public
  	  ModelAbstract obtenerDescrMinimaForRectificacion(@PathVariable("tipoDescrMinima") String tipoDescrMinima,
  			  @PathVariable("numCorredoc") long numCorreDoc,
  			  @PathVariable("numSecItem") int numSecItem,
  			  @PathVariable("codTipDilgencia") String codTipDilgencia,
  			  @PathVariable("numCorredocSol") String numCorredocSol)
            {

  	    Enum tipo = TipoDescrMinima.get(tipoDescrMinima);

  	    logger.debug("servicio REST devuelve JSON");	    

  	    ModelAbstract objeto = null;

  	    if (tipo != null)
            {
  	      objeto = ModelFactory.crearObjetoDescrMinima(tipo);	      
  	      objeto = poblarObjetoDescrMinimaMoock(numCorreDoc,numSecItem);
  	      objeto.setTipoDescrMnima(tipoDescrMinima);
            }
   	 	List<Map<String,String>> result = new ArrayList<Map<String,String>>(); 
  	    if(codTipDilgencia.equals(Constantes.TIPO_DILIG_ESTA_RECTIFICACION)){
  	    	 result = getDatosRectificacionDescrMinimas(numCorredocSol, numCorreDoc, numSecItem);
        }
  	    objeto.setDatosRectificados(result);

  	    return objeto;

    }

	/*INICIO-P34 PAS20165E220200137 AFMA*/

	//http://localhost:7070/ol-ad-iadiligencia-consulta/descrminima/titulo/500/TE0442/2016-12-03
	@RequestMapping(value = "/titulos/{codCatalogo}/{codDataCat}/{fecha}", method = RequestMethod.GET)
	@ResponseBody
	public
	DataCatalogo getTitulos(@PathVariable("codCatalogo") String codCatalogo,
					  @PathVariable("codDataCat") String codDataCat,
					  @PathVariable("fecha") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fecha)
            {

		logger.info("getTitulos(codCatalogo:" + codCatalogo + ",codDataCat:" + codDataCat + ",fechaReferencia:" + fecha);

		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
		DataCatalogo data =  catalogoAyudaService.getDataCatalogo(codCatalogo, codDataCat,fecha);

        return data;

    }

	//http://localhost:7070/ol-ad-iadiligencia-consulta/descrminima/titulo/500/TE0442/12547888888

	@RequestMapping(value = "/titulos2/{codCatalogo}/{codDataCat}/{fecha}", method = RequestMethod.GET)
	@ResponseBody
	public
	DataCatalogo getTitulos2(@PathVariable("codCatalogo") String codCatalogo,
							@PathVariable("codDataCat") String codDataCat,
							@PathVariable("fecha") String fecha)
    {

		logger.info("getTitulos(codCatalogo:" + codCatalogo + ",codDataCat:" + codDataCat + ",fechaReferencia:" + fecha);

		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
		long lfecha = Long.parseLong(fecha);

		Date dfecha =  new Date(lfecha);
		DataCatalogo data =  catalogoAyudaService.getDataCatalogo(codCatalogo, codDataCat,dfecha);

		return data;

        }




	@RequestMapping(value = "/catalogos/{codCatalogo}/{fecha}", method = RequestMethod.GET)
	@ResponseBody
	public
	ResponseCatalogoRest getCatalogos(@PathVariable("codCatalogo") String codCatalogo,
																				@PathVariable("fecha")
																				@DateTimeFormat(pattern = "yyyy-MM-dd") Date fecha)
    {

		logger.info("getCatalogos(codCatalogo:" + codCatalogo + ",fechaReferencia:"+fecha);

		AyudaServiceDataCatalogo ayudaServiceDataCatalogo= fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogoDM");

		List<pe.gob.sunat.despaduanero2.ayudas.model.min.DataCatalogo> lst = ayudaServiceDataCatalogo.listDataCatalogo(codCatalogo,fecha, null);

		ResponseCatalogoRest responseRest = new ResponseCatalogoRest();
		responseRest.setSuccessful(true);
		responseRest.setResponseAsJson((String) SojoUtil.toJson(lst));

		return responseRest;

        }


	@RequestMapping(value = "/catalogos2/{codCatalogo}/{fecha}", method = RequestMethod.GET)
  	  @ResponseBody
  	  public
	ResponseCatalogoRest getCatalogos2(@PathVariable("codCatalogo") String codCatalogo,
									  @PathVariable("fecha")
									  String fecha)
  	  {

		logger.info("getCatalogos(codCatalogo:" + codCatalogo + ",fechaReferencia:"+fecha);

		long lfecha = Long.parseLong(fecha);

		Date dfecha =  new Date(lfecha);

		AyudaServiceDataCatalogo ayudaServiceDataCatalogo= fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogoDM");
  	    
		List<pe.gob.sunat.despaduanero2.ayudas.model.min.DataCatalogo> lst = ayudaServiceDataCatalogo.listDataCatalogo(codCatalogo,dfecha, null);

		ResponseCatalogoRest responseRest = new ResponseCatalogoRest();
		responseRest.setSuccessful(true);
		responseRest.setResponseAsJson((String) SojoUtil.toJson(lst));

		return responseRest;
  	    
  	  }
    
	/*FIN-P34 PAS20165E220200137 AFMA*/
    //PASE42
    private List<Map<String,String>> getDatosRectificacionDescrMinimas(String numCorredocSol, long numCorreDoc, int numSecItem){
    	
    	 Map<String, Object> params = new HashMap<String, Object>();
    	 params.put("numeroCorrelativo", numCorredocSol);
    	 params.put("tabla", Constantes.COD_TABLA_FORMB_ITEM_DESCRI);

    	 DetSolRectiDAO detSolrectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");    	 
    	 List<DetalleSolicitudRectifica> lstdatosRectificados = detSolrectiDAO.listByParameterMap(params);
    	 
    	 List<Map<String,String>> datosRectificados = new ArrayList<Map<String,String>>();
    	 for(DetalleSolicitudRectifica rectificaItem:lstdatosRectificados){
    		 Map<String,String> rectificadosItem = new HashMap<String,String>(); 
    		 String clave = rectificaItem.getDescripcionClave();
    		 JsonSerializer serializer = new JsonSerializer();
             Map<String, Object> claveMap = (Map<String, Object>) serializer.deserialize(clave);
             if(claveMap.get("NUM_CORREDOC").equals(numCorreDoc) && 
    			claveMap.get("NUM_SECITEM").toString().equals(String.valueOf(numSecItem))){
            	 /**Inicio de cambios PASE20 arey**/
            	 Map<String,String> valorHMap = null ;
            	 Map<String,String> valorRMap = null ;
            	 if(!SunatStringUtils.isEmpty(rectificaItem.getDescripcionDataAnterior1())){
            		 valorHMap = (Map<String,String>) serializer.deserialize(rectificaItem.getDescripcionDataAnterior1());
            	 }
            	 if(!SunatStringUtils.isEmpty(rectificaItem.getDescripcionData1())){
            		 valorRMap = (Map<String,String>) serializer.deserialize(rectificaItem.getDescripcionData1());
            	 }
    			 rectificadosItem.put("PK", claveMap.get("COD_TIPDESC").toString());
    			 rectificadosItem.put("VALORR", !CollectionUtils.isEmpty(valorRMap)?valorRMap.get("DES_DESCRIPCION"):" ");
    			 rectificadosItem.put("VALORH", !CollectionUtils.isEmpty(valorHMap)?valorHMap.get("DES_DESCRIPCION"):" ");
    			 if(!CollectionUtils.isEmpty(valorRMap) && valorRMap.get("COD_TIPVALOR") != null){
    				 rectificadosItem.put("COD_TIPVALOR", valorRMap.get("COD_TIPVALOR").toString());
    			 }else{
    				 rectificadosItem.put("COD_TIPVALOR", rectificaItem.getTipoRectificacion());
    				 /**Inicio de ajustes de arey para mostrar valores anteriores en minimas**/
    				 if(rectificaItem.getTipoRectificacion().equals("A") && rectificadosItem.get("VALORH").equals(" ")){
    					 FormBItemDescriDAO formbItemdescriDAO = fabricaDeServicios.getService("formBItemDescriDAO");
    					    Map<String, Object> mapBusqueda=  new HashMap<String, Object>();
    					    mapBusqueda.put("NUM_CORREDOC", numCorreDoc);
    					    mapBusqueda.put("NUM_SECITEM", numSecItem);
    					    mapBusqueda.put("COD_TIPDESC",claveMap.get("COD_TIPDESC").toString());
							//amancilla inicio PAS20165E220200137  como se nota que nunca probaron el codigo se comenta
    					    //mapBusqueda.put("NUM_SECFACT",claveMap.get("NUM_SECFACT").toString());
    					    //mapBusqueda.put("NUM_SECPROVE",claveMap.get("NUM_SECPROVE").toString();
						    //amancilla fin PAS20165E220200137)
    					    mapBusqueda.put("COD_MERCANCIA", claveMap.get("COD_MERCANCIA").toString());
    					    List<Map<String, Object>> lstDatos = formbItemdescriDAO.selectByMap(mapBusqueda);
    					    String valorAnt =" ";
    					    String tipoValAnt =" ";
    					    if (!CollectionUtils.isEmpty(lstDatos))
    					    {
    					    	Map<String, Object> mapValoH=lstDatos.get(0);
    					        valorAnt=lstDatos.get(0).get("DES_DESCRIPCION").toString();
    					        tipoValAnt=lstDatos.get(0).get("COD_TIPVALOR").toString();
    					        rectificadosItem.put("VALORH", valorAnt);
    					    }
    				 }
    				 /**Fin de ajustes de arey**/
    			 }/**FIn de cambios PASE20 arey**/
    			 
    			 datosRectificados.add(rectificadosItem);
    		 }
    	 }
    	 return datosRectificados;
    }

	//Inicio P24 PAS20175E220200035 -se agrega para mostrar datos rectificados en minimas
	private List<Map<String,String>> getDatosRectificadosDescrMinimas(long numCorreDoc, int numSecItem){

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numcorredoc", numCorreDoc);


		RectiOficioDAO rectiOficioDAO = fabricaDeServicios.getService("diligencia.ingreso.rectiOficioDef");
		List<Map<String, Object>> lstdatosRectificados = rectiOficioDAO.findUltimaRectiOficioByParams(params);

		List<Map<String,String>> datosRectificados = new ArrayList<Map<String,String>>();
		for(Map listaRectificados : lstdatosRectificados){
			Map<String,String> rectificadosItem = new HashMap<String,String>();
			if (listaRectificados.get("codtabla").toString().equals(Constantes.COD_TABLA_FORMB_ITEM_DESCRI)) {
				String clave = listaRectificados.get("desclave").toString();
				JsonSerializer serializer = new JsonSerializer();
				Map<String, Object> claveMap = (Map<String, Object>) serializer.deserialize(clave);
				if (claveMap.get("NUM_CORREDOC").equals(numCorreDoc) &&
						claveMap.get("NUM_SECITEM").toString().equals(String.valueOf(numSecItem))) {

					Map<String, String> valorHMap = null;
					Map<String, String> valorRMap = null;
					if (!SunatStringUtils.isEmptyTrim(listaRectificados.get("desantdata1").toString())) {//PAS20171U220200010
						valorHMap = (Map<String, String>) serializer.deserialize(listaRectificados.get("desantdata1").toString());
					}
					if (!SunatStringUtils.isEmptyTrim(listaRectificados.get("desdata1").toString())) {
						valorRMap = (Map<String, String>) serializer.deserialize(listaRectificados.get("desdata1").toString());
					}
					if(valorHMap!=null){//PAS20171U220200010
						rectificadosItem.put("PK", claveMap.get("COD_TIPDESC").toString());
						rectificadosItem.put("VALORR", !CollectionUtils.isEmpty(valorRMap) ? valorRMap.get("DES_DESCRIPCION") : " ");
						rectificadosItem.put("VALORH", !CollectionUtils.isEmpty(valorHMap) ? valorHMap.get("DES_DESCRIPCION") : " ");
						rectificadosItem.put("USUARIO",!listaRectificados.get("codusumodif").toString().equals(" ") ? listaRectificados.get("codusumodif").toString():"---");
						rectificadosItem.put("TIPODILIGENCIA",listaRectificados.get("codtipdiligencia").toString()+"-"+catalogoAyudaService.getDescripcionDataCatalogo("356",listaRectificados.get("codtipdiligencia").toString()));
						rectificadosItem.put("FECMODIF",listaRectificados.get("fecmodif").toString());
	
						datosRectificados.add(rectificadosItem);
					}
				}
			}
		}
		return datosRectificados;
	}
	//Fin P24 PAS20175E220200035
}