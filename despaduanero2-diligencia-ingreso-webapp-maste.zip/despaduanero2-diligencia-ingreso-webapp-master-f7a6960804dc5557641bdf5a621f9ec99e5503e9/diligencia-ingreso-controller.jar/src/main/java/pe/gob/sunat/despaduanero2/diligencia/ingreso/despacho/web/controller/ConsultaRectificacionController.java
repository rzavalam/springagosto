package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import pe.gob.sunat.despaduanero2.bean.DatoRectificado;

import pe.gob.sunat.despaduanero2.bean.UniqueKeyDua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaRectificacionService;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class ConsultaRectificacionController extends MultiActionController {



	private static final String MENSAJE_SOLUCION_ERROR = "Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.";

	protected final Log log = LogFactory.getLog(getClass());

	private String jsonView;

	private JsonSerializer serializer = new JsonSerializer();

	private ConsultaRectificacionService consultaRectificacionService;

	/**
	 * <p>Iniciamos la consulta de rectificaciones de la dua.</P>
	 * <p> los parametros de ingreso son los datos de la dua en formato json {"codAduana":"046","anioDua":2012,"codRegimen":"10","numDeclaracion":45}.</p>
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView initConsultaRectificacion (HttpServletRequest request,HttpServletResponse response){

		ModelAndView view = new ModelAndView("ConsultaDiligenciaRectificacion");

		ServletWebRequest webRequest = new ServletWebRequest(request);
		String uniqueKeyDuaAsJson = ObjectUtils.toString(webRequest.getParameter("uniqueKeyDua"), "");
		Object numeroCorrelativoDua = webRequest.getParameter("numeroCorrelativoDua");
		try{
			validarUniqueKeyDua(uniqueKeyDuaAsJson);

			Map data = new HashMap<String, Object>();
			data.put("uniqueKeyDua", uniqueKeyDuaAsJson);
			data.put("numeroCorrelativoDua", numeroCorrelativoDua);

			return enviarData(view, data);
		}catch(IllegalArgumentException e) {
			view = new ModelAndView("PagM");
			log.info("**** ERROR de Validacion ****", e);
			return lanzarError(view, e.getMessage());
		}catch(Exception e) {
			view = new ModelAndView("PagM");
			log.error("**** ERROR de aplicacion ****", e);
			return lanzarError(view, "Ocurrio un error inesperado");
		}

	}

	/**
	 * <p>Valida que la dua exista.</P>
	 * <p> los parametros de ingreso son los datos de la dua en formato json {"codAduana":"046","anioDua":2012,"codRegimen":"10","numDeclaracion":45}.</p>
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView validarConsultaRectificacion (HttpServletRequest request,HttpServletResponse response){
		//validamso que la dua exista
		ModelAndView view = new ModelAndView(jsonView);

		ServletWebRequest webRequest = new ServletWebRequest(request);
		String uniqueKeyDuaAsJson = ObjectUtils.toString(webRequest.getParameter("uniqueKeyDua"), "");
		try{

			UniqueKeyDua uniqueKeyDua = validarUniqueKeyDua(uniqueKeyDuaAsJson);
			Map<String, Object> paramCab = uniqueKeyDua.toHasMap();
			DUA dua = RectificacionServiceImpl.getInstance().getCabdeclaraDAO().findDUAByKeyMap(paramCab);
			//numcorredoc pruebas = 111146996 DUA 145-2012-10-060949
			//{"codigoAduana":"145","annoPresentacion":2012,"codigoRegimen":"10","numeroDeclaracion":60949}
			Validate.notNull(dua, " La dua no se encuentra registrada en el sistema");
			Long numeroCorrelativoDua = dua.getNumcorredoc();

			Map data = new HashMap<String, Object>();
			data.put("uniqueKeyDua", uniqueKeyDuaAsJson);
			data.put("numeroCorrelativoDua", numeroCorrelativoDua);

			List<Class> lsitClasesTofilterId = new ArrayList<Class>();
			lsitClasesTofilterId.add(UniqueKeyDua.class);
			return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm:ss");

		}catch(ServiceException e) {
			log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
			return lanzarError(view, e.getMensaje().toString());
		}catch(IllegalArgumentException e) {
			log.error("**** ERROR de Validacion ****", e);
			return lanzarError(view, e.getMessage());
		}catch(Exception e) {
			log.error("**** ERROR de aplicacion ****", e);
			return lanzarError(view, "Ocurrio un error inesperado");
		}
	}

	/**
	 * <p>Busca las diligencias de rectificaciones realizadas a una dua.</P>
	 * <p>realiza la busqueda de rectificaciones y devuelve un json con las rectificaciones realidas a la DUA.</p>
	 * <p> los parametros de ingreso son los datos de la dua en formato json {"codAduana":"046","anioDua":2012,"codRegimen":"10","numDeclaracion":45}.</p>
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView consultaRectificacion (HttpServletRequest request,HttpServletResponse response){

		ModelAndView view = new ModelAndView(jsonView);

		ServletWebRequest webRequest = new ServletWebRequest(request);

		String uniqueKeyDuaAsJson = ObjectUtils.toString(webRequest.getParameter("uniqueKeyDua"), "");
		try{


			// validamos que se envie los parametros de busqueda
			UniqueKeyDua uniqueKeyDua = validarUniqueKeyDua(uniqueKeyDuaAsJson);
			Map<String, Object> paramCab = uniqueKeyDua.toHasMap();
			DUA dua = RectificacionServiceImpl.getInstance().getCabdeclaraDAO().findDUAByKeyMap(paramCab);
			Validate.notNull(dua, " La dua no se encuentra registrada en el sistema");
			Long numeroCorrelativoDua = dua.getNumcorredoc();//new BigDecimal(ObjectUtils.toString(webRequest.getParameter("hdn_num_corredoc"),"0"));
			Validate.notNull(numeroCorrelativoDua, " La dua no se encuentra registrada en el sistema");

			List<SolicitudRectifica> lstRectificaciones = consultaRectificacionService.consultaDiligenciaRectificacion(numeroCorrelativoDua);

			Map data = new HashMap<String, Object>();
			data.put("lstRectificaciones", lstRectificaciones);
			data.put("numeroCorrelativoDua", numeroCorrelativoDua);
			//p24-PAS20165E220200099
			List<Class> lsitClasesTofilterId = new ArrayList<Class>();
			lsitClasesTofilterId.add(SolicitudRectifica.class);
			return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy hh:mm:ss a");

		}catch(ServiceException e) {
			log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
			return lanzarError(view, e.getMensaje().toString());
		}catch(IllegalArgumentException e) {
			log.error("**** ERROR de Validacion ****", e);
			return lanzarError(view, e.getMessage());
		}catch(Exception e) {
			log.error("**** ERROR de aplicacion ****", e);
			return lanzarError(view, "Ocurrio un error inesperado");
		}

	}

	/**
	 * Consulta el detalle de la diligencia: codigo funcionario, descripcion del resultado, fecha de la diligencia
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView consultaDetalleDiligencia (HttpServletRequest request,HttpServletResponse response){
		ModelAndView view = new ModelAndView(jsonView);

		ServletWebRequest webRequest = new ServletWebRequest(request);

		String diligenciaJson = ObjectUtils.toString(webRequest.getParameter("diligencia"), "");
		try{

			Diligencia diligencia = validarConsultaDetalle(diligenciaJson);

			diligencia = consultaRectificacionService.consultaDiligencia(diligencia);

			Map data = new HashMap<String, Object>();
			data.put("diligencia", diligencia);

			List<Class> lsitClasesTofilterId = new ArrayList<Class>();
			lsitClasesTofilterId.add(Diligencia.class);
			return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm:ss");

		}catch(ServiceException e) {
			log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
			return lanzarError(view, e.getMensaje().toString());
		}catch(IllegalArgumentException e) {
			log.error("**** ERROR de Validacion ****", e);
			return lanzarError(view, e.getMessage());
		}catch(Exception e) {
			log.error("**** ERROR de aplicacion ****", e);
			return lanzarError(view, "Ocurrio un error inesperado");
		}
	}

	/**
	 * Consulta los datos rectificacods para una determinada Dua
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView consultaDatosRectificados (HttpServletRequest request,HttpServletResponse response){

		ModelAndView view = new ModelAndView(jsonView);

		ServletWebRequest webRequest = new ServletWebRequest(request);

		String diligenciaJson = ObjectUtils.toString(webRequest.getParameter("diligencia"), "");
		try{
			// validamos que se envie los parametros de busqueda
			Diligencia diligencia = validarConsultaDetalle(diligenciaJson);
			// buscamos en det ofirecti
			List<DatoRectificado> lstDatoRectificado = consultaRectificacionService.consultaDatosRectificados(diligencia);
			Map data = new HashMap<String, Object>();
			data.put("lstDatoRectificado", lstDatoRectificado);

			List<Class> lsitClasesTofilterId = new ArrayList<Class>();
			lsitClasesTofilterId.add(DatoRectificado.class);
			return enviarJsonData(data, lsitClasesTofilterId, "dd/MM/yyyy HH:mm:ss");

		}catch(ServiceException e) {
			log.info("**** ERROR DE NEGOCIO ****: " + e.getMensaje());
			return lanzarError(view, e.getMensaje().toString());
		}catch(IllegalArgumentException e) {
			log.error("**** ERROR de Validacion ****", e);
			return lanzarError(view, e.getMessage());
		}catch(Exception e) {
			log.error("**** ERROR de aplicacion ****", e);
			return lanzarError(view, "Ocurrio un error inesperado");
		}

	}



	/**
	 * Valida que los para metros de la busqueda sean los correctos de lo contrario lanza una RuntimeException
	 * @param duaJson
	 * @return retorna el UniqueKey validado
	 */
	private UniqueKeyDua validarUniqueKeyDua(String duaJson) {
		//eliminamso los espacios en blanco
		duaJson = StringUtils.remove (duaJson, " ");
		Validate.notEmpty(duaJson, "los parametros de busqueda no deben de estar vacios");
		UniqueKeyDua uniqueKeyDua = (UniqueKeyDua)serializer.deserialize(duaJson, UniqueKeyDua.class);
		String jsonRequerido = uniqueKeyDua.toString();
		Validate.isTrue(jsonRequerido.toString().equals(duaJson), "los parametros enviamos no concuerdan con el formato requerido, enviado (" + duaJson + ") requerido (" + jsonRequerido + "), cambiar los valores null por el valor que se desea enviar.");
		Validate.isTrue(uniqueKeyDua.isValidUniqueKey(),"los parametros unicos no deben de contener nulos: (" + duaJson + ")");

		return uniqueKeyDua;
	}

	private Diligencia validarConsultaDetalle(String diligenciaJson) {
		//eliminamos los espacios en blanco
		diligenciaJson = StringUtils.remove (diligenciaJson, " ");
		Validate.notEmpty(diligenciaJson, "los parametros de busqueda no deben de estar vacios");
		Diligencia diligencia = (Diligencia)serializer.deserialize(diligenciaJson, Diligencia.class);
		return diligencia;
	}

	/**
	 * Envia el error estandar haciendo uso de la clase MensajeBean si es que este se produce
	 * @param view
	 * @param mensaje
	 * @return
	 */
	private ModelAndView lanzarError(ModelAndView view, String mensaje) {
		MensajeBean rBean = new MensajeBean();
		rBean.setError(true);
		rBean.setMensajeerror(mensaje);
		rBean.setMensajesol(MENSAJE_SOLUCION_ERROR);
		return view.addObject("beanM", rBean);
	}

	/**
	 * Envia el response estandar haciendo uso de la clase MensajeBean si es que este se produce
	 * @param view
	 * @param data
	 * @return
	 */
	private ModelAndView enviarData(ModelAndView view, Map<String, Object> data) {
		MensajeBean rBean = new MensajeBean();
		rBean.setError(false);
		rBean.setData(data);

		return view.addObject("beanM", rBean);
	}



	/**
	 * Retorna el json al cliente
	 * @param data data con la informacion a mostrar
	 * @param filterIdClass clases a las cuales se les tiene que filtar en campo id (es necesario listar las que se usen en el retorno del
	 * 	json sino tendrian algun error no esperado en la presentacion )
	 * @param dateFormat formato de la fecha el cual tendran las clases de tipo date
	 * @return
	 */
	private ModelAndView enviarJsonData(Map<String, Object> data, List<Class> listClasesTofilterId, String dateFormat) {
		ModelAndView view = new ModelAndView(jsonView);
		view.addObject("listClasesTofilterId", listClasesTofilterId);
		view.addObject("formatoFecha", dateFormat);
		return enviarData(view, data);
	}

  /***********************SET DE SPRING **********************************/

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public void setConsultaRectificacionService(
			ConsultaRectificacionService consultaRectificacionService) {
		this.consultaRectificacionService = consultaRectificacionService;
	}


}
