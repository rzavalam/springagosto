package pe.gob.sunat.despaduanero2.diligencia.ingreso.despacho.web.controller;

import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.CAT_PARTICIPANTES;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_TIPO_PARTICIPANTE_REPRESENTANTE;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_TIPO_PARTICIPANTE_TRANSPORTISTA;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.administracion2.tramite.service.TabDepService;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ResolucionMulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.FormatoValorService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SolicitudService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.CollectionUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.security.Coder;
import pe.gob.sunat.framework.security.cifrador.factory.HashFactory;
import pe.gob.sunat.framework.security.cifrador.interfaz.Hash;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.compression.ZipUtil;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Hex;
import pe.gob.sunat.rrhh2.service.ConsultaService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class DiligenciaUtilController extends AbstractDespachoController {
	private ConsultaService consultaService;
	private FormatoValorService formatoValorService;
	private FabricaDeServicios fabricaDeServicios;
	private DeclaracionService declaracionService;
	private SolicitudService solicitudService;
	private SerieService serieService;
	private RectificacionService rectificacionService;
	private SoporteService soporteService;
	
	/**
	 * Busqueda de funcionario para mostrar su descripcion 
	 * @param request the request
	 * @param response the response
	 * @return funcionario
	 * @author gbecerrav
 	 */
	public ModelAndView obtenerEspecialista(HttpServletRequest request, HttpServletResponse response) throws Exception {
		log.debug("-->obtenerEspecialista<--");
		Map<String, Object> modelo = new HashMap<String, Object>();
		
		try {
			
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String codPers = webRequest.getParameter("hdnCodPers");
			log.debug("-->hdnCodPers: " + codPers);
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_pers", codPers);
			List<Map<String, Object>> listaEspecialistas = this.consultaService.consultarPersonal(params);
			modelo.put("especialista", listaEspecialistas.get(0));
			
			log.debug("especialista.t02cod_pers: " + listaEspecialistas.get(0).get("t02cod_pers"));
			log.debug("especialista.t02ap_pate: " + listaEspecialistas.get(0).get("t02ap_pate"));
			log.debug("especialista.t02ap_mate: " + listaEspecialistas.get(0).get("t02ap_mate"));
			log.debug("especialista.t02nombres: " + listaEspecialistas.get(0).get("t02nombres"));
			
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorJSON(e.getMessage());
		}
		return new ModelAndView("jsonView", modelo);
	}
	
	/**
	 * Metodo que nos permite recibir los datos de los proveedores y numero de
	 * facturas por DUA.
	 *
	 * @param request the request
	 * @param response the response
	 * @return the model and view
	 */
	/*@SuppressWarnings("unchecked")
	public ModelAndView cargarConsultaFormatoValor(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Map<String, Object>> listado = null;
		Map<String, String> PkDocu = new HashMap<String, String>();
	    
		try {
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String hdn_acceso = ObjectUtils.toString(webRequest.getParameter("hdn_acceso"), "");
			PkDocu.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));
			if (hdn_acceso.equals("00")) {
				PkDocu.put("IND_DEL", "0");
			}
			listado = this.formatoValorService.obtenerFVProveedores(PkDocu);
			  
			ModelAndView view = new ModelAndView("ConsultaFormatoValor", "proveedor", SojoUtil.toJson(listado));

			view.addObject("hdn_num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
			view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_num_corredoc"));
			view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_num_corredoc"));
			view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_num_corredoc"));
			view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_corredoc"));
			return view;
		  
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
		  	return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		}
	}*/
	  
	/**
	 * Metodo que permite mostrar la consulta del Manifiesto 
	 * y su detalle de una determinada DUA.
	 * 
	 * @param request the request
	 * @param response the response
	 * @return the model and view
	 */
	public ModelAndView cargarConsultaManifiesto(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			Declaracion declaracion = (Declaracion) WebUtils.getSessionAttribute(request, "declaracion");
					
	        List<Map<String, Object>> listado = null;
	        List<Map<String, Object>> listadoDocuTrans = null; //P24-PAS20165E220200099
	        List<Map<String, Object>> listadoDocuTransreceptor = null;
	        ManifiestoService manifiestoService = this.fabricaDeServicios.getService("manifiesto.manifiestoService");
	    	Manifiesto manifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(),
	    			declaracion.getDua().getManifiesto().getCodmodtransp(),
	    			declaracion.getDua().getManifiesto().getCodaduamanif(),
	    			Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()),
	    			declaracion.getDua().getManifiesto().getNummanif(), true);
	    	if(manifiesto != null) {
	    		Map<String, Object> pkDocu = new HashMap<String, Object>();
	    		Map<String, Object> mapReceptor = new HashMap<String, Object>();
	    		Map<String, Object> pkDocuReceptor = new HashMap<String, Object>();
	    		pkDocu.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
	    		//listado = this.declaracionService.obtenerDatado(pkDocu, manifiesto);
	    		listado = declaracionService.obtenerDatadoDUA(pkDocu);//P24-PAS20165E220200099
			    listadoDocuTrans = declaracionService.obtenerDocumentosTransporteDUA(pkDocu);//P24-PAS20165E220200099

		      pkDocuReceptor.put("NUM_CORREDOC",manifiesto.getNumeroCorrelativo());
		      pkDocuReceptor.put("NUM_DETALLE", listadoDocuTrans.get(0).get("NUM_DETALLE").toString());
		      listadoDocuTransreceptor = declaracionService.obtenerReceptorCargaDUA(pkDocuReceptor);
		      if(!listadoDocuTransreceptor.isEmpty() && listadoDocuTransreceptor!=null){
	    	  mapReceptor.put("NOM_RAZONSOCIAL",listadoDocuTransreceptor.get(0).get("NOM_RAZONSOCIAL"));
	    	  mapReceptor.put("NUM_DOCIDENT",listadoDocuTransreceptor.get(0).get("NUM_DOCIDENT"));
	    	  listadoDocuTrans.add(mapReceptor);
			      }
	    	}else {
	    		return showErrorPagM("No se encontraron datos del Manifiesto.", " ", true); 
	        }

	        ModelAndView view = new ModelAndView("ConsultaManifiesto", "datado", CollectionUtils.isEmpty(listado)?"[]" : SojoUtil.toJson(listado)); //P24-PAS20165E220200099 
	        //para que soporte la jsp construimos mapa en base a la declaracion
	        Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>();
	        mapCabDeclaraActual.put("NOM_RAZONSOCIAL_PTR", declaracion.getDua().getManifiesto().getEmpTransporte().getNombreRazonSocial());
	        mapCabDeclaraActual.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden());
	        mapCabDeclaraActual.put("ANN_PRESEN", declaracion.getDua().getAnnpresen());
	        mapCabDeclaraActual.put("COD_REGIMEN", declaracion.getDua().getCodregimen());
	        mapCabDeclaraActual.put("NUM_DECLARACION", declaracion.getDua().getNumdocumento());
	        view.addObject("mapCabDeclaraActual", mapCabDeclaraActual);
	        view.addObject("manifiesto", manifiesto);
	        view.addObject("docuTrans", CollectionUtils.isEmpty(listadoDocuTrans)?"[]" : SojoUtil.toJson(listadoDocuTrans));//P24-PAS20165E220200099
	        //mapCabDeclaraActual = null;
	        return view;
	    	    
	    } catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		}
	}

	/**
	 * Metodo que obtiene los documentos asociados 
	 * y autorizantes segun sea la invocacion.
 	 * 
	 * @param request the request
	 * @param response the response
	 * @return the model and view
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView cargarConsultaDocAutorizaSerie(HttpServletRequest request, HttpServletResponse response) throws Exception {
	    ServletWebRequest webRequest = new ServletWebRequest(request);
	    MensajeBean rBean = null;//P46-PAS20155E410000032-[jlunah]
	    ModelAndView view = new ModelAndView("ConsultaDocAutorizaSerie");//P46-PAS20155E410000032-[jlunah]

	    /*P46-PAS20155E410000032-[jlunah] se agrego try catch*/
	    try	{

	    String acceso = request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";

	    List<Map<String, Object>> listado2 = new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> listadoDocAsociado = null;
	    List<Map<String, Object>> listadoDetAutorizacion = null;

	    // para deshabilitar boton de grabado del JSP
	    Boolean banderaEdicion = false;
	    boolean banderaExiste = false;
	    String tipoDiligencia = WebUtils.getSessionAttribute(request, "tipoDiligencia") != null ? (String) WebUtils
	        .getSessionAttribute(request, "tipoDiligencia") : "";
	    String serieSeleccionada = webRequest.getParameter("hdn_num_secserie") != null ? (String) webRequest
	        .getParameter("hdn_num_secserie") : "";

	    // datos de la session
	    Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");
	    Map<String, Object> mapCabDeclaraAnt = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclara");
	    List<Map<String, Object>> lstDetDeclaraAnt = (List<Map<String, Object>>) WebUtils.getSessionAttribute(
	        request,
	          "lstDetDeclaraActual");

	    String numCorreDoc = mapCabDeclara.get("NUM_CORREDOC").toString();
	    //inicio gmontoya P24
	    
	    String codAduana = String.valueOf(mapCabDeclara.get("COD_ADUANA"));
	    String anhoDua = String.valueOf(mapCabDeclara.get("ANN_PRESEN"));
		String codRegimen =	String.valueOf(mapCabDeclara.get("COD_REGIMEN"));
		String numDeclaracion = SunatStringUtils.lpad(String.valueOf(mapCabDeclara.get("NUM_DECLARACION")),6,'0');
		
		String url = "http://www.aduanet.gob.pe/servlet/CR10Inmoviliza?codi_aduan=".concat(codAduana)
				.concat("&ano_prese=").concat(anhoDua).concat("&nume_corre=").concat(numDeclaracion).concat("&regimen=").concat(codRegimen).concat("&wreg=").concat(codRegimen);
		
		//p24 pase 35
		List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
        Map<String, Object> PkDecla = new HashMap<String, Object>();
  	  	PkDecla.put("tipodoc", ConstantesDataCatalogo.COD_DCTO_TRAMITE_ACTA_DE_SEPARACION); //062
  	  	PkDecla.put("codi_adua", codAduana);
		PkDecla.put("codigoAduana",  codAduana);
  	  	PkDecla.put("annoref", anhoDua);
  	  	PkDecla.put("numeref", numDeclaracion);
  	  	DocumentoInternoService documentoInternoService = fabricaDeServicios.getService("tramite.DocumentoInternoService");
  		List<Map<String, Object>> listActaVerificacionConDUA = documentoInternoService.obtenerDocInternoTransbordo(PkDecla);
        	if(listActaVerificacionConDUA !=null && listActaVerificacionConDUA.size() != 0){
        		lstRspta.addAll(listActaVerificacionConDUA);
        	}
		
	    Map mapaDocumentosAsociados = soporteService.getDocumentosDUA(numCorreDoc, mapCabDeclara);
	    Map<String, Object> pkDocuOtros = new HashMap<String, Object>();
	    pkDocuOtros.put("NUM_CORREDOC", numCorreDoc);
	    pkDocuOtros.put("listaCodTipOper",new String[]{"1","9","P","C"});//gmontoya P24 II
		
	  	Map<String, Object> mapDatosDocOtros = solicitudService.obtenerDocDUAOtros(pkDocuOtros);
	    //fin gmontoya P24
	    if (!SunatStringUtils.isEmpty((String) mapCabDeclara.get("COD_ESTDUA"))
	        && (webRequest.getParameter("banderaEdicion") != null ? Boolean.valueOf(webRequest.getParameter(
	            "banderaEdicion").toString()) : false))
	    {
	      // comparamos con tipo de diligencia 01 y 04, segun catalogo 356
	      if (!("01".equals(tipoDiligencia) && "04".equals(tipoDiligencia)))
	      {
	        banderaEdicion = true;
	      }
	    }

	    // obtenemos los datos
	    if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstDocAutAsociado")))
	    {
	      listadoDocAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
	      listadoDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
	    }
	    else
	    { // obtenemos de la BD

	      Map<String, String> pkDocu = new HashMap<String, String>();
	      pkDocu.put("NUM_CORREDOC", numCorreDoc);

	      // Para consulta por SERIE.
	      if (!SunatStringUtils.isEmpty(serieSeleccionada))
	      {
	        pkDocu.put("NUM_SECSERIE", serieSeleccionada);
	        pkDocu.put("fortipoopedif", "1");// activar diferencia
	        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
	      }
	      else
	      { // consulta por DUA
	        pkDocu.put("fortipoopedif", "1");// activar diferencia
	        pkDocu.put("COD_TIPOPER", "C");// CONSTANTE
	      }
	      // jala solo los activos
	      pkDocu.put("IND_DEL", "0");

	      Map<String, Object> mapDatos = solicitudService.obtenerDocAutoriza(pkDocu);

	      listadoDocAsociado = (List<Map<String, Object>>) mapDatos.get("lstDocAutAsociado");
	      listadoDetAutorizacion = (List<Map<String, Object>>) mapDatos.get("lstDetAutorizacion");
	      // ponemos en session los datos de la BD a session como datos ant
	      mapCabDeclaraAnt.put("lstDocAutAsociado", Utilidades.copiarLista((List) listadoDocAsociado));
	      mapCabDeclaraAnt.put("lstDetAutorizacion", Utilidades.copiarLista((List) listadoDetAutorizacion));
	      request.getSession().setAttribute("mapCabDeclara", mapCabDeclaraAnt);
	    }

	    // Si tenemos series nuevas recogemos sus docautorizantes
	    if (!SunatStringUtils.isEmpty(serieSeleccionada))
	    { // consulta por serie
	      // Agregado los documentos autorizantes de Series con estado
	      // IND_TIPO_REGISTRO = '1'
	      Map key = new HashMap();
	      key.put("NUM_CORREDOC", numCorreDoc);
	      key.put("NUM_SECSERIE", serieSeleccionada);
	      Map<String, Object> mapDetDeclaraSerieSeleccionada = Utilidades.obtenerElemento(lstDetDeclaraAnt, key);

	      // si la serie seleccionada esta eliminada //ESTADO_REGISTRO 0 REGISTRADO
	      // EN BD, 1 PENDIENTE DE REGISTRO EN BD
	      if (!CollectionUtils.isEmpty(mapDetDeclaraSerieSeleccionada)
	          && SunatStringUtils.isEmpty((String) mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO"))
	          && "1".equals(mapDetDeclaraSerieSeleccionada.get("ESTADO_REGISTRO").toString()))
	      {

	        List<Map<String, Object>> listaAdicional = (List<Map<String, Object>>) mapDetDeclaraSerieSeleccionada
	            .get("lstDetAutorizacion");

	        listaAdicional = (listaAdicional != null) ? listaAdicional : new ArrayList<Map<String, Object>>();
	        listadoDetAutorizacion.addAll(Utilidades.copiarLista((List) listaAdicional));

	      }

	      for (Map<String, Object> mapa1 : listadoDetAutorizacion)
	      {
	        if (serieSeleccionada.equals(mapa1.get("NUM_SECSERIE").toString().trim()))
	        {
	        	String codTipOper1 = mapa1.get("COD_TIPOPER").toString().trim();
	        	
	          for (Map<String, Object> mapa2 : listadoDocAsociado)
	          {
	            banderaExiste = false;
	            String codTipOper2 = mapa2.get("COD_TIPOPER").toString().trim();
	            
	            if (mapa1.get("NUM_SECDOC").toString().trim().equals(mapa2.get("NUM_SECDOC").toString().trim()) 
	            		&& codTipOper1.equals(codTipOper2)
	                    && !codTipOper1.equals("C") && !codTipOper1.equals("P"))  //RIN14 - no se requiere que se muestren los documentos de control autorizantes
	                //&& mapa1.get("COD_TIPOPER").toString().trim().equals(mapa2.get("COD_TIPOPER").toString().trim())
	                //&& !mapa1.get("COD_TIPOPER").toString().trim().equals("C") && !mapa1.get("COD_TIPOPER").toString().trim().equals("P")) 
	            {
	              for (Map<String, Object> mapa3 : listado2)
	              {
	                if (mapa2.get("NUM_SECDOC").toString().trim().equals(mapa3.get("NUM_SECDOC").toString().trim())
	                    //&& mapa2.get("COD_TIPOPER").toString().trim().equals(mapa3.get("COD_TIPOPER").toString().trim()))
	                	&& codTipOper2.equals(mapa3.get("COD_TIPOPER").toString().trim()))
	                {
	                  banderaExiste = true;
	                  break;
	                }
	              }
	              if (!banderaExiste && "0".equals(mapa2.get("IND_DEL")))
	              {
	                listado2.add(mapa2);
	              }
	            }
	          }
	        }
	      }

	    }
	    else
	    { // para consulta por DUA
	      for (Map mapa : listadoDocAsociado)
	      {
	        Map mapClave = new HashMap<String, Object>();
	        mapClave.put("NUM_CORREDOC", mapa.get("NUM_CORREDOC"));
	        mapClave.put("NUM_SECDOC", mapa.get("NUM_SECDOC"));
	        mapClave.put("COD_TIPOPER", mapa.get("COD_TIPOPER"));
	        // solo muestra activos
				//PAS20155E220000054
	        //amancilla se habilita para que se pueda editar solo las documentos asociados que no esten asociados a la ninguna serie
	        if ("0".equals(mapa.get("IND_DEL")) && CollectionUtils.isEmpty(Utilidades.obtenerElemento(listadoDetAutorizacion, mapClave)))
	        {
	          listado2.add(mapa);
	        }
	      }
	    }
	    // actualizo los datos en session de la declaracion actual
	    mapCabDeclara.put("lstDocAutAsociado", listadoDocAsociado);
	    mapCabDeclara.put("lstDetAutorizacion", listadoDetAutorizacion);
	    request.getSession().setAttribute("mapCabDeclaraActual", mapCabDeclara);

	    if (CollectionUtils.isEmpty(listado2))
	    {
	      banderaEdicion = false;
	    }

	    /*se subio linea de codigo - P46-PAS20155E410000032-[jlunah]*/
	    //PAS20165E220200099 - Se saco afuera los seteos de documentos  
	    // para poner el titulo
	    view.addObject("documentos", !CollectionUtils.isEmpty(listado2) ? SojoUtil.toJson(listado2) : "[]");
	    //inicio gmontoya P24
	    List<Map<String,Object>> lista = mapaDocumentosAsociados.get("listExpediDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listExpediDua"):new ArrayList<Map<String,Object>>();
	    lista.addAll(listActaVerificacionConDUA);//p24

	    
	    List<Map<String,Object>> listaOtros = mapDatosDocOtros.get("lstDocAutAsociado")!=null?(List<Map<String,Object>>)mapDatosDocOtros.get("lstDocAutAsociado"):new ArrayList<Map<String,Object>>();
	    lista.addAll(mapaDocumentosAsociados.get("listDocIntDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listDocIntDua"):new ArrayList<Map<String,Object>>());
	    view.addObject("documentosTramite", !CollectionUtils.isEmpty(lista) ? SojoUtil.toJson(lista) : "[]");
	    view.addObject("documentosOtros", !CollectionUtils.isEmpty(listaOtros) ? SojoUtil.toJson(listaOtros) : "[]");
	    view.addObject("documentosActas", !CollectionUtils.isEmpty(mapaDocumentosAsociados.get("listActasDua")!=null?(List<Map<String,Object>>)mapaDocumentosAsociados.get("listActasDua"):null) ? SojoUtil.toJson((List)mapaDocumentosAsociados.get("listActasDua")) : "[]");
	    view.addObject("URL_ACTAS", url);//gmontoya P24
	    view.addObject("URL_TRAMITE", "http://www.aduanet.gob.pe/cl-ti-itsigad/sigadS02Alias");//gmontoya P24
	    view.addObject("URL_DocReferencia", "http://intranet/cl-ti-itsigad/sigadS02Alias?accion=detalleExp");//vramosd P24 
	  //fin gmontoya P24
	    //amancilla Bug
	    view.addObject("hdn_cod_aduana", webRequest.getParameter("hdn_cod_aduana")); 
	    view.addObject("hdn_ann_presen", webRequest.getParameter("hdn_ann_presen")); 
	    view.addObject("hdn_cod_regimen", webRequest.getParameter("hdn_cod_regimen")); 
	    view.addObject("hdn_num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
	    // tambien se consulta desde la declaracion entonces esteparametro es vaicio o null
	    view.addObject("hdn_num_secserie", webRequest.getParameter("hdn_num_secserie"));    
	    
	    if (!acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))
	    {
	      // Datos de formulario
	      String documento = SojoUtil.toJson(listado2).replaceAll("null", "\"\"");

	      if ("10".equals(tipoDiligencia))
	      {
	        if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
	            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()) && !CollectionUtils.isEmpty(listado2))
	         {
	           banderaEdicion = true; 
	         }
	         else
	         {
	           banderaEdicion = false; 
	         }
	      }

	      view.addObject("documentos", documento);
	      view.addObject("bEdicion", banderaEdicion);
	      view.addObject("hdn_num_corredoc", numCorreDoc);
	      //amancilla se agrego pq no pinta pase 54
//	      String codAduana = mapCabDeclara.get("COD_ADUANA").toString();//GMONTOYA P24
	      String anno = mapCabDeclara.get("ANN_PRESEN").toString();
//	      String codRegimen = mapCabDeclara.get("COD_REGIMEN").toString();//GMONTOYA P24
//	      String numDeclaracion = mapCabDeclara.get("NUM_DECLARACION").toString();//GMONTOYA P24
	      // fina amancilla
	      view.addObject("hdn_cod_aduana", codAduana);
	      view.addObject("hdn_ann_presen", anno);
	      view.addObject("hdn_cod_regimen", codRegimen);
	      view.addObject("hdn_num_declaracion", numDeclaracion);
	      view.addObject("hdn_num_secserie", serieSeleccionada);

	      List<Map<String, String>> lstTipoOperacion = this.catalogoAyudaService.getElementosCat("327");
	      if (!CollectionUtils.isEmpty(lstTipoOperacion))
	      {
	        Iterator it = lstTipoOperacion.iterator();
	        while (it.hasNext())
	        {
	          Map<String, String> mp = (Map<String, String>) it.next();
	          if (mp.get("cod_datacat").equals("C"))
	            it.remove();
	        }
	      }

	      view.addObject("lstTipoOperacion", SojoUtil.toJson(lstTipoOperacion));
	      view.addObject("lstEntidad", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("49")));
	      view.addObject("lstTipoDocumento", SojoUtil.toJson(this.catalogoAyudaService.getElementosCat("367")));

	    }
	   }
	    catch (ServiceException e) {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror(e.getMessage());
				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");
				return new ModelAndView("PagM", "beanM", rBean);
			} catch (Exception e) {
				rBean = new MensajeBean();
				rBean.setError(true);
				rBean.setMensajeerror(e.getMessage());
				rBean.setMensajesol("Ocurri� un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

				return new ModelAndView("PagM", "beanM", rBean);
			} finally {
			}
	    return view;
	}
	
	/**
	 * Metodo para cargar la ventana de mensajes de la tabla comunicaciones.
	 * 
	 * @param request the request
	 * @param response the response
	 * @return ModelAndView
	 * @throws Exception the exception
	 */
	public ModelAndView cargarComunicaciones(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView modelAndView = new ModelAndView("MensajesComunicacion");
	    
	    try {
	    	ServletWebRequest webRequest = new ServletWebRequest(request);
	    	Map<String, Object> params = new HashMap<String, Object>();
	    	params.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc"));

	    	List<Map<String, Object>> lstComunicacion = diligenciaService.obtenerComunicaciones(params);

	    	if (!CollectionUtils.isEmpty(lstComunicacion)) {
	    		// Obtenemos la descripci
	    		for (int i = 0; i < lstComunicacion.size(); i++) {
	    			// Colocando la descripcion del usuario
	    			FiltroCatEmpleado filtro = new FiltroCatEmpleado();
	    			filtro.setCodPers(lstComunicacion.get(i).get("COD_USUREGIS").toString());
	    			Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
	    			CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(lstComunicacion.get(i).get("COD_USUREGIS"));
	    			lstComunicacion.get(i).put(
	    					"DES_USUREGIS",
	    					(catEmpleadoTemp != null) ?
	    							catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " "
	    							+ catEmpleadoTemp.getNombres() : " ");
	    		}
	    	}
	    	modelAndView.addObject("lstComunicacionFinal", lstComunicacion);
	    	
	    } catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} finally {
	    	
	    }
	    return modelAndView;
	}
	
	/**
	 * Metodo que consulta la lista de indicadores de la DUA y la actualiza en
	 * declaracion y declaracionActual.
	 *
	 * @param request the request
	 * @param response the response
	 * @return the model and view
	 * @throws Exception the exception
	 */
	public ModelAndView cargarConsultaIndicadorDua(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			ServletWebRequest webRequest = new ServletWebRequest(request);
			//PAS20155E220000418 - se corrige ya que se actualizo en la diligencia de despacho
			/*Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", webRequest.getParameter("hdn_num_corredoc")); //declaracion.get("NUM_CORREDOC"));
			params.put("COD_TIPOREGISTRO", Constantes.IND_DUA_T_AUT);
			List<Map<String, Object>> lstIndicadorDua = this.declaracionService.obtenerIndicadoresDua(params);*/
			
			Long numCorrelativo = Long.parseLong(webRequest.getParameter("hdn_num_corredoc"));
			List<IndicadorDeclaracionDescripcion> listaIndicadorDuaDesc = declaracionService.obtenerIndicadoresDuaAll(numCorrelativo);
			
			List<Map<String, Object>> lstIndicadorDua = new ArrayList<Map<String,Object>>();
			
			if (listaIndicadorDuaDesc != null) {
				for (IndicadorDeclaracionDescripcion indicadorDuaDesc : listaIndicadorDuaDesc) {
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("COD_INDICADOR", indicadorDuaDesc.getCodigoIndicador());
					params.put("COD_INDICADOR_DESC", indicadorDuaDesc.getDescCodigoIndicador());
					params.put("IND_ACTIVO_DESC", indicadorDuaDesc.getDescIndicadorActivo());
					lstIndicadorDua.add(params);
				}
			}
			return new ModelAndView("ConsultaIndicadorDua", "data", SojoUtil.toJson(lstIndicadorDua));
			
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} 
	}
	
	/**
	 * Permite obtener datos de Participante Importador de una Declaracion.
	 * 
	 * @param request [HttpServletRequest] request
	 * @param response [HttpServletResponse] response
	 * @return [ModelAndView] model and view
	 * @throws Exception the exception
	 */
	public ModelAndView cargarAnexo2(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		try{
			//Map<String, Object> declaracionActual = (HashMap) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
			Declaracion declaracion = (Declaracion)WebUtils.getSessionAttribute(request, "declaracion");
			  
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			Map<String, Object> mapaAnexo2 = this.declaracionService.obtenerAnexo2(params);

			if (mapaAnexo2 != null) {
				mapaAnexo2.put("NOM_RAZONSOCIAL_PIM", declaracion.getDua().getDeclarante().getNombreRazonSocial() != null ? declaracion.getDua().getDeclarante().getNombreRazonSocial() : ""); //declaracionActual.get("NOM_RAZONSOCIAL_PIM") != null ? declaracionActual.get("NOM_RAZONSOCIAL_PIM") : "");
				mapaAnexo2.put("NUM_DOCIDENT_PIM", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() != null ? declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() : ""); //declaracionActual.get("NUM_DOCIDENT_PIM") != null ? declaracionActual.get("NUM_DOCIDENT_PIM") : "");
				mapaAnexo2.put("DIR_PARTIC_PIM", declaracion.getDua().getDeclarante().getDireccion() != null ? declaracion.getDua().getDeclarante().getDireccion() : ""); //declaracionActual.get("DIR_PARTIC_PIM") != null ? declaracionActual.get("DIR_PARTIC_PIM") : "");
			}
			
			return new ModelAndView("FinUbicacion", "anexo2", mapaAnexo2);
		} catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} 
	}
	
	/**
	 * Metodo que obtiene el listado de Series invocado se la opcion se Series de
	 * la consulta de DUA acceso="00".
	 * 
	 * @param request the request
	 * @param response the response
	 * @return the model and view
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView obtenerListadoSeries(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//HttpSession session = request.getSession();
	    try {
	    	ServletWebRequest webRequest = new ServletWebRequest(request);
	    	
	    	String acceso = webRequest.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "";
	    	
	    	Map<String, String> params = new HashMap<String, String>();
	    	params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
	    	params.put("num_corredoc", webRequest.getParameter("hdn_num_corredoc"));
	    	params.put("num_declaracion", webRequest.getParameter("hdn_num_declaracion"));
	    	params.put("cod_aduana", webRequest.getParameter("hdn_cod_aduana"));
	    	params.put("ann_presen", webRequest.getParameter("hdn_ann_presen"));
	    	params.put("cod_regimen", webRequest.getParameter("hdn_cod_regimen"));
	    	params.put("acceso", acceso);
	    	//Map<String, Object> mapCabDeclara = (Map<String, Object>) session.getAttribute("mapCabDeclaraActual");
	    	Declaracion declaracion = (Declaracion) WebUtils.getSessionAttribute(request, "declaracion");
	    	request.setAttribute("params", params);
	    	// Para Declaracion en Proceso se filtran las Series
	    	params.put("estadoDUA", declaracion.getDua().getCodEstdua()); //mapCabDeclara.get("COD_ESTDUA").toString());

	    	/*String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
	    	if ("10".equals(tipoDiligencia)) {
	    		if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString())) {
	    			params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
	    		}
	    	}*/

	    	List lstDetDeclara = this.serieService.obtenerListadoSeries(params);
	    	//session.setAttribute("lstDetDeclara", lstDetDeclara);
	    	WebUtils.setSessionAttribute(request, "lstDetDeclara", lstDetDeclara);
	    	
	    	List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstDetDeclaraActual");
	    	if(CollectionUtils.isEmpty(lstDetDeclaraActual)) {
	    		List<Map<String, Object>> lstDetDeclaraActualTmp = new ArrayList<Map<String, Object>>();
	    		lstDetDeclaraActualTmp = Utilidades.copiarLista(lstDetDeclara);
	    		WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", lstDetDeclaraActualTmp); 
	    		lstDetDeclaraActual = new ArrayList<Map<String, Object>>();
	    		lstDetDeclaraActual.addAll(lstDetDeclaraActualTmp);
	    	}
	    	
	    	//tiene formato B,seteando los datos en session de la serie-item y
	    	//item-factura
	    	//if(mapCabDeclara.get("IND_FORMBPROVEEDOR").equals("0")) {
	    	if (!declaracion.isExoneradoFB()) {
	    		Map<String, Object> param = new HashMap<String, Object>();
	    		param.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc()); //mapCabDeclara.get("NUM_CORREDOC"));
	    		List lstSeriesItem = getSerieService().obtenerSeriesItem(param);
	    		WebUtils.setSessionAttribute(request, "lstSeriesItem", lstSeriesItem);
	    		List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) WebUtils.getSessionAttribute(request, "lstSeriesItemActual");
	    		if (CollectionUtils.isEmpty(lstSeriesItemActual)) {
	    			lstSeriesItemActual = Utilidades.copiarLista(lstSeriesItem);
	    			WebUtils.setSessionAttribute(request, "lstSeriesItemActual", lstSeriesItemActual);
	    		}
	    		List<Map<String, Object>> lstItemFactura = declaracionService.obtenerItemFactura(param);
	    		WebUtils.setSessionAttribute(request, "lstItemFacturaActual", lstItemFactura);
	    		
	    		/**Inicio de cambios P24 -bug24642***/ 
	            List lstItemVehic = new ArrayList<Map<String, Object>>();
	          
	            
	            if(!CollectionUtils.isEmpty(lstItemFactura)){
	    			for(int j=0; j<lstItemFactura.size(); j++){
	    				Map<String,Object> mapDatosVehic = new HashMap<String, Object>() ;
	    				Map<String, Object> mapItemFactura=	(Map<String, Object>) lstItemFactura.get(j);
	    				String descripcion =  mapItemFactura.get("COD_TIPDESCRMIN")!=null?mapItemFactura.get("COD_TIPDESCRMIN").toString():" ";
	    				if("01".equals(descripcion)){//es vehiculos
	        				mapDatosVehic.put("NUM_SECITEM", mapItemFactura.get("NUM_SECITEM"));
	        				mapDatosVehic.put("ANN_FABRICACION", mapItemFactura.get("ANN_FABRICACION"));
	        			}
	    				if(!CollectionUtils.isEmpty(mapDatosVehic)){
	    					lstItemVehic.add(mapDatosVehic);
	    				}
	    			}
	            }
	            /**Fin de cambios P24 -bug24642***/ 
	            
	            /**Inicio de cambios P24 -bug24639***/
	            for (Map<String , Object> map : lstDetDeclaraActual){
	            	int totalItemsSerie = 0;
	            	String ann_fabric = "0"; 
	            	ArrayList<String> lstItemsSerie;
	            	String num_serie =  map.get("NUM_SECSERIE").toString();
	            	if(!CollectionUtils.isEmpty(lstSeriesItem)){
	    	        	for (int i=0 ; i <lstSeriesItem.size(); i++){  
	    	        		Map<String, Object> mapSerieItem=	(Map<String, Object>) lstSeriesItem.get(i);
	    	        		String num_secSerie = mapSerieItem.get("NUM_SECSERIE").toString();
	    	        		String num_secItem = mapSerieItem.get("NUM_SECITEM").toString();
	    	        		if(num_serie.equals(num_secSerie)){
	    	        			totalItemsSerie=totalItemsSerie+1;
	    	        			if(!CollectionUtils.isEmpty(lstItemVehic)){
	    	        				for(int j=0; j<lstItemVehic.size(); j++){
	    	        					Map<String, Object> mapItemVehic =	(Map<String, Object>) lstItemVehic.get(j);
	    	        					String num_item = mapItemVehic.get("NUM_SECITEM").toString();
	    	        					if(num_secItem.equals(num_item)){	        						 
	    	        	        				ann_fabric = mapItemVehic.get("ANN_FABRICACION")!=null?mapItemVehic.get("ANN_FABRICACION").toString():"0";
	    	        	        				break;//solo hay un vehiculo por serie
	    		        				}
	    	}
	    	        			}
	    	        			
	    	        		}
	    	        	}
	            	}
	            	map.put("tot_items", totalItemsSerie);
	            	map.put("annFabricVehic",ann_fabric);
	            } /**Fin de cambios P24 -bug24639***/
	    	}
	    	
	    	
	    	

	    	/*if(!("00".equals(params.get("acceso")))) {
	    		request.setAttribute("lstMonedas", catalogoAyudaService.getElementosCat("J1"));
	    		request.setAttribute("lstIncidadoresSENASA", catalogoAyudaService.getElementosCat("324"));
	    		request.setAttribute("lstExoneraciones", catalogoAyudaService.getElementosCat("18"));
	    		request.setAttribute("lstPaises", catalogoAyudaService.getElementosCat("J2"));
	    		request.setAttribute("lstUnidadesMedida", catalogoAyudaService.getElementosCat("29"));
	    		request.setAttribute("lstUnidadesMercancia", catalogoAyudaService.getElementosCat("16"));
	    		request.setAttribute("lstTiposMercanciaRestringida", catalogoAyudaService.getElementosCat("333"));
	    		request.setAttribute("lstUsosGuardiaCustodia", catalogoAyudaService.getElementosCat("326"));
	    		request.setAttribute("lstTiposDocSoporteAsociado", catalogoAyudaService.getElementosCat("367"));
	    		request.setAttribute("lstTiposProrrateoFlete", catalogoAyudaService.getElementosCat("368"));
	    		request.setAttribute("lstTiposConoSada", catalogoAyudaService.getElementosCat("TP"));

	    		// Obtener catalogo 25 y agregar el c�digo a la descripci�n
	    		List<Map<String, String>> lstEstadosMercancia = catalogoAyudaService.getElementosCat(CATALOGO_ESTADO_MERCANCIA, "cod_datacat");
	    		
	    		for(Map<String, String> estadoMerc : lstEstadosMercancia) {
	    			estadoMerc.put("des_corta", estadoMerc.get("cod_datacat") + " " + estadoMerc.get("des_corta"));
	    		}

	    		request.setAttribute("lstEstadosMercancia", SojoUtil.toJson(lstEstadosMercancia));

	    		Map<String, Object> mapTabLibe = new HashMap<String, Object>();

	    		FechaBean fechaBean = new FechaBean((Timestamp) mapCabDeclara.get("FEC_DECLARACION"));

	    		mapTabLibe.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
	    		mapTabLibe.put("fechaDeclaracion", Long.valueOf(fechaBean.getFormatDate("yyyyMMdd")));
	    		mapTabLibe.put("tlib", "I");
	    		
	    		request.setAttribute("lstTPI", soporteService.obtenerTabLibeByParams(mapTabLibe));
	    		mapTabLibe.put("tlib", "T");
	    		
	    		request.setAttribute("lstTPN", soporteService.obtenerTabLibeByParams(mapTabLibe));
	    		mapTabLibe.put("tlib", "C");
	    		
	    		request.setAttribute("lstCodigoLiberatorio", soporteService.obtenerTabLibeByParams(mapTabLibe));
	    	}*/
	    	
	    	// Obtener catalogo 25 y agregar el c�digo a la descripci�n
    		List<Map<String, String>> lstEstadosMercancia = catalogoAyudaService.getElementosCat(ConstantesDataCatalogo.COD_CATALOGO_ESTADO_MERCANCIA, "cod_datacat");
    		for(Map<String, String> estadoMerc : lstEstadosMercancia) {
    			estadoMerc.put("des_corta", estadoMerc.get("cod_datacat") + " " + estadoMerc.get("des_corta"));
    		}
    		request.setAttribute("lstEstadosMercancia", SojoUtil.toJson(lstEstadosMercancia));

    		FechaBean fechaBean = new FechaBean(new Timestamp(declaracion.getDua().getFecdeclaracion().getTime()));
    		Map<String, Object> mapTabLibe = new HashMap<String, Object>();
    		mapTabLibe.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden());
    		mapTabLibe.put("fechaDeclaracion", Long.valueOf(fechaBean.getFormatDate("yyyyMMdd")));
    		mapTabLibe.put("tlib", "I");
    		request.setAttribute("lstTPI", this.soporteService.obtenerTabLibeByParams(mapTabLibe));
    		
    		mapTabLibe.put("tlib", "T");
    		request.setAttribute("lstTPN", this.soporteService.obtenerTabLibeByParams(mapTabLibe));
    		
    		mapTabLibe.put("tlib", "C");
    		request.setAttribute("lstCodigoLiberatorio", this.soporteService.obtenerTabLibeByParams(mapTabLibe));
    		
	    	/*
	    	 * solo para la consulta se verifica el historico de las series adicionadas
	    	 * o eliminadas pero solo muestra la ultima para el caso de una seria
	    	 * adicionada en P.A y despues eliminada muestra el evento mas reciente
	    	 */
	    	/*if ("00".equals(acceso)) {
	    		String numCorreDoc = declaracion.getDua().getNumcorredoc().toString(); //mapCabDeclara.get("NUM_CORREDOC").toString();
	    		List<Map<String, Object>> listaSeriesADDyDEL = this.rectificacionService.obtenerDatosAnuladosOAdicionados(numCorreDoc, "T0052");

	    		// agrega la columna estado en la lista y la pone en session
	    		for(Map<String, Object> mapDatosModificados : listaSeriesADDyDEL) {
	    			String numSecSerie = (String) mapDatosModificados.get("PK");
	    			
	    			// agrego los campos a la serie
	    			for(Map<String, Object> mapDetDeclaraActual : lstDetDeclaraActual) {
	    				if (numSecSerie.equals((mapDetDeclaraActual.get("NUM_SECSERIE").toString()))) {
	    					mapDetDeclaraActual.putAll(mapDatosModificados);
	    				}
	    			}
	    		}
	    	}*/

    		//Para que soporte la invocacion a las jsp que aun trabajan con mapas
	    	setearMapaSession(request, declaracion, acceso);
	    	
	    	/*ModelAndView res;

	    	if(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(getTipoDiligencia(request))) {
	    		if(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO") != null && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString())) {
	    			lstDetDeclaraActual = Utilidades.quitarRegistrosMarcadaParaEliminar(lstDetDeclaraActual);
	    			Ordenador.sortDesc(lstDetDeclaraActual, "NUM_SECSERIE", Ordenador.ASC);
	    			session.setAttribute("lstDetDeclaraActual", lstDetDeclaraActual);
	    		}
	    		res =new ModelAndView(PAGINA_PRINCIPAL_DETALLE, "detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclaraActual));
	    	} else {
	    		res = new ModelAndView("RegSerie", "detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclaraActual));
	    	}*/
	    	ModelAndView res = new ModelAndView("RegSerie", "detDeclaraViewListJson", SojoUtil.toJson(lstDetDeclaraActual));
	    	//res.addObject("COD_ESTDUA", (String) ((HashMap) session.getAttribute("mapCabDeclaraActual")).get("COD_ESTDUA"));
	    	res.addObject("COD_ESTDUA", declaracion.getDua().getCodEstdua());
	    	res.addObject("acceso", acceso); //(String) params.get("acceso"));
	    	return res;
	    	
	    } catch (ServiceException e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} catch (Exception e) {
			log.error("**** ERROR ****:", e);
			return showErrorPagM(e.getMessage());
		} 
	}

	/**
	 * Para que soporte la invocacion a las jsp que aun trabajan con mapas
	 */
	@Deprecated
	private void setearMapaSession(HttpServletRequest request, Declaracion declaracion, String acceso){
		log.debug("-->mapCabDeclaraActual");
		Map<String, Object> mapCabDeclaraActual = new HashMap<String, Object>(); 
		mapCabDeclaraActual.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		mapCabDeclaraActual.put("IND_FORMBPROVEEDOR", declaracion.isExoneradoFB() ? "1" : "0"); //1 = no tiene B 0 = si tiene B
		mapCabDeclaraActual.put("COD_ESTDUA", declaracion.getDua().getCodEstdua());
		if(declaracion.getDua().getCodmodalidad().equalsIgnoreCase(Constantes.MODALIDAD_ANTICIPADO) 
		  && declaracion.getDua().getCodCanal().equalsIgnoreCase(Constantes.CANAL_ROJO)){
			mapCabDeclaraActual.put("tituloDiligencia", "DILIGENCIA PREVIA"); //P24-PAS20165E220200099
		}else{
			mapCabDeclaraActual.put("tituloDiligencia", "DILIGENCIA"); ////??
		}
		mapCabDeclaraActual.put("FEC_DECLARACION", new Timestamp(declaracion.getDua().getFecdeclaracion().getTime()));
		log.debug("-->mapCabDeclaraActual: " + mapCabDeclaraActual);
		WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", mapCabDeclaraActual);
		
		Map<String, Object> mapCabDeclara = new HashMap<String, Object>(); 
		mapCabDeclara.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		WebUtils.setSessionAttribute(request, "mapCabDeclara", mapCabDeclara);
		
		// solo para la consulta debo cargar los Datos modificados en
	    // cualquier diligencia
		if (acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)) {
			String numCorreDoc = declaracion.getDua().getNumcorredoc().toString(); //declaracion.get("NUM_CORREDOC").toString();
	        Map<String, Object> mapaRSPTADatosModificados = this.rectificacionService.obtenerDatosModificadosEnDiligencias(numCorreDoc);
	        List<Map<String, Object>> listaElemCabDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_DECLARA);
	        List<Map<String, Object>> listaElemDetDeclara = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_DECLARA);
	        List<Map<String, Object>> listaElemEquipamiento = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_EQUIPAMIENTO);
	        List<Map<String, Object>> listaElemDocAsociado = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCAUT_ASOCIADO);
	        List<Map<String, Object>> listaElemDetAut = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DET_AUTORIZACION);
	        List<Map<String, Object>> listaElemCertOrigen = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CAB_CERTIORIGEN);
	        List<Map<String, Object>> listaElemRegPrecedente = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_DOCUPRECE_DUA);
	        List<Map<String, Object>> listaElemFormatoBDAV = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMB_PROVEEDOR);
	        List<Map<String, Object>> listaElemFormatoBFactura = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);
	        List<Map<String, Object>> listaElemFormatoBItemFactura = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_ITEM_FACTURA);
	        List<Map<String, Object>> listaElemSeriesItem = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_SERIES_ITEM);
	        List<Map<String, Object>> listaElemConvenioSerie = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_CONVENIO_SERIE);
	        List<Map<String, Object>> listaElemFacturasSeries = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FORMA_FACTU);
	        List<Map<String, Object>> listaElemObservacion = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_OBSERVACION);
	        List<Map<String, Object>> listaElemParticipantesDUA = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_PARTICIPANTE_DOC);
		    List<Map<String, Object>> listaElemComprobantePago = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_COMPROBPAGO);//PAS20175E220200035
		    List<Map<String, Object>> listaElemFacturaSuce = obtenerListaModificaciones(mapaRSPTADatosModificados,Constantes.COD_TABLA_FACTUSUCE);//PAS20175E220200035
	        
	        // las listas de convenio tienen el mismo PK que det_serie y se
	        // muestran en el mismo JSP
	        // por ello se agrega a la lista
	        if (!CollectionUtils.isEmpty(listaElemConvenioSerie))
	        {
	          listaElemDetDeclara.addAll(listaElemConvenioSerie);
	        }
	        // en el JSP COnsultaDocAutorizaSerie estan estos 2 listas
	        if (!CollectionUtils.isEmpty(listaElemDocAsociado))
	        {
	          listaElemDetDeclara.addAll(listaElemDetAut);
	        }

	        // en el JSP RegDiligenciaDespacho estan estos 2 listas
	        List<Map<String, Object>> listaElemObservacionDecla = new ArrayList<Map<String, Object>>();
	       // List<Map<String, Object>> listaElemObservacionItemFactura = new ArrayList();

		      listaElemDetDeclara.addAll(listaElemFacturaSuce);//PAS20175E220200035
		      listaElemDetDeclara.addAll(listaElemComprobantePago);//PAS20175E220200035 	        
	        
	        if (!CollectionUtils.isEmpty(listaElemObservacion))
	        {
	          for (Map<String, Object> mapObs : listaElemObservacion)
	          {

	            String codTipObs = mapObs.get("PK").toString();
	            if(codTipObs.startsWith("01"))
	            {
	              listaElemObservacionDecla.add(mapObs);
	            }
	            /* NO SE MUESTRA ESTE CAMPO EN LA CONSULTAS PERO CUANDO SE MUESTRE HABILITAR
	            else if(codTipObs.startsWith("03"))
	            {
	              listaElemObservacionItemFactura.add(mapObs);
	            }*/
	          }
	        }

	        listaElemCabDeclara.addAll(listaElemObservacionDecla);
	        listaElemCabDeclara.addAll(listaElemParticipantesDUA);
	        //se agrega las obseravciones del itemfcatura activar cuando se muestre la obseravcion en itemfacturas
	       // listaElemFormatoBItemFactura.addAll(listaElemObservacionItemFactura);

	        // Guardamos en sesion los datos de la declaracion e invocamos
	        // el jsp
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosDUA",
	                                     (!CollectionUtils.isEmpty(listaElemCabDeclara)
	                                                                                   ? SojoUtil.toJson(listaElemCabDeclara)
	                                                                                   : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosSERIE",
	                                     (!CollectionUtils.isEmpty(listaElemDetDeclara)
	                                                                                   ? SojoUtil.toJson(listaElemDetDeclara)
	                                                                                   : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosEquipamiento ",
	                                     (!CollectionUtils.isEmpty(listaElemEquipamiento)
	                                                                                     ? SojoUtil.toJson(listaElemEquipamiento)
	                                                                                     : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosDocAsociado",
	                                     (!CollectionUtils.isEmpty(listaElemDocAsociado)
	                                                                                    ? SojoUtil.toJson(listaElemDocAsociado)
	                                                                                    : "[]"));
	        // WebUtils.setSessionAttribute(request,
	        // "camposModificadosDetAut",
	        // (!CollectionUtils.isEmpty(listaElemDetAut)?SojoUtil.toJson(listaElemDetAut):"[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosCertOrigen",
	                                     (!CollectionUtils.isEmpty(listaElemCertOrigen)
	                                                                                   ? SojoUtil.toJson(listaElemCertOrigen)
	                                                                                   : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosRegPrecedente",
	                                     (!CollectionUtils.isEmpty(listaElemRegPrecedente)
	                                                                                      ? SojoUtil.toJson(listaElemRegPrecedente)
	                                                                                      : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosFormatoBDAV",
	                                     (!CollectionUtils.isEmpty(listaElemFormatoBDAV)
	                                                                                    ? SojoUtil.toJson(listaElemFormatoBDAV)
	                                                                                    : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosFormatoBFactura",
	                                     (!CollectionUtils.isEmpty(listaElemFormatoBFactura)
	                                                                                        ? SojoUtil.toJson(listaElemFormatoBFactura)
	                                                                                        : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosFormatoBItemFactura",
	                                     (!CollectionUtils.isEmpty(listaElemFormatoBItemFactura)
	                                                                                            ? SojoUtil.toJson(listaElemFormatoBItemFactura)
	                                                                                            : "[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosSeriesItem",
	                                     (!CollectionUtils.isEmpty(listaElemSeriesItem)
	                                                                                   ? SojoUtil.toJson(listaElemSeriesItem)
	                                                                                   : "[]"));
	        // WebUtils.setSessionAttribute(request,
	        // "camposModificadosConvenioSerie",
	        // (!CollectionUtils.isEmpty(listaElemConvenioSerie)?SojoUtil.toJson(listaElemConvenioSerie):"[]"));
	        WebUtils.setSessionAttribute(request,
	                                     "camposModificadosFacturasSeries",
	                                     (!CollectionUtils.isEmpty(listaElemFacturasSeries)
	                                                                                       ? SojoUtil.toJson(listaElemFacturasSeries)
	                                                                                       : "[]"));
	        // WebUtils.setSessionAttribute(request,"camposModificadosObservacion",(!CollectionUtils.isEmpty(listaElemObservacion)
	        // ? SojoUtil.toJson(listaElemObservacion) : "[]"));

	      }
	}
	
	@SuppressWarnings("unchecked")
	private List<Map<String, Object>> obtenerListaModificaciones(Map<String, Object> mapaRSPTADatosModificados, String codTablaCabDeclara) {
		return mapaRSPTADatosModificados.get(codTablaCabDeclara) != null ? (ArrayList<Map<String, Object>>) mapaRSPTADatosModificados.get(codTablaCabDeclara) : new ArrayList<Map<String, Object>>();
	}
	
	/**
	 * Permite consultar via ajax al Participante
	 * @param request [HttpServletRequest] request
	 * @param response [HttpServletResponse] response
	 * @return  [ModelAndView] model and view
	 * @version 1.0
	 * */
	public ModelAndView consultarParticipante(HttpServletRequest request, HttpServletResponse response){
		if (this.log.isDebugEnabled())
			log.debug("method:consultarParticipante");
	    
		ModelAndView view = new ModelAndView(this.jsonView);
	    MensajeBean mensajeBean = new MensajeBean();
	    
	    try
	    {
	    	ServletWebRequest webRequest = new ServletWebRequest(request);
	    	String ruc = webRequest.getParameter("txt_ruc");
	    	String numeroDocumento = webRequest.getParameter("txt_documento");
	    	String rasonSocial = webRequest.getParameter("txt_razonsocial");
	    	String codTipoOperador = webRequest.getParameter("tipoParticipante");
	    	String codtipoDocumento = webRequest.getParameter("tipoDocumento");

	    	List<Map<String, String>> lstOperador = new ArrayList<Map<String, String>>();
	    	
	    	// se agrega el tipo 45
	        if (!COD_TIPO_PARTICIPANTE_IMPORTADOR.equals(codTipoOperador)) {
	        	String codTipoOperadorDesc = catalogoAyudaService.getDescripcionDataCatalogo(CAT_PARTICIPANTES, codTipoOperador);
	        	OperadorAyudaService operadorAyudaService = (OperadorAyudaService)this.fabricaDeServicios.getService("Ayuda.operadorAyudaService");
	        	lstOperador = operadorAyudaService.getListaOperadores(codTipoOperador, ruc, rasonSocial);

	          for (Map<String, String> mapOperador : lstOperador) {
	            mapOperador.put("codTipoOperador", codTipoOperador);
	            mapOperador.put("codTipoOperadorDesc", codTipoOperadorDesc);
	          }

	          // se agrega el tipo 12
	          if (COD_TIPO_PARTICIPANTE_TRANSPORTISTA.equals(codTipoOperador)) {
	        	  String codTipoOperador12Desc = catalogoAyudaService.getDescripcionDataCatalogo(CAT_PARTICIPANTES, COD_TIPO_PARTICIPANTE_REPRESENTANTE);
	        	  List<Map<String, String>> lstOperador12 = operadorAyudaService.getListaOperadores(COD_TIPO_PARTICIPANTE_REPRESENTANTE, ruc, rasonSocial);

	        	  for (Map<String, String> mapOperador12 : lstOperador12) {
	        		  Map<String, String> mapOperador = new HashMap<String, String>(mapOperador12);
	        		  mapOperador.put("codTipoOperador", COD_TIPO_PARTICIPANTE_REPRESENTANTE);
	        		  mapOperador.put("codTipoOperadorDesc", codTipoOperador12Desc);
	        		  lstOperador.add(mapOperador);
	        	  }
	          }
	        } else { // 45
	            if (ArrayUtils.contains(new String[] { "3", "4" }, codtipoDocumento)) {
	            	Map<String, Object> mapRspta = new HashMap<String, Object>();
		            Map<String, String> mapItem = new HashMap<String, String>();

	            	mapRspta = soporteService.obtenerPerNatJur(codtipoDocumento, numeroDocumento);
	            	
	            	if (!CollectionUtils.isEmpty(mapRspta)) {
	            		mapItem.put("numeroDocumento", (String) mapRspta.get("codigo"));
	            		mapItem.put("razonSocial", (String) mapRspta.get("nombre"));
	            		mapItem.put("direccion", (String) mapRspta.get("direccion"));
	            		lstOperador.add(mapItem);
	            	}
	            } else { // busca tabla declaran
	            	Map<String, Object> mapBusqueda = new HashMap<String, Object>();
	            	mapBusqueda.put("ayudaID", "Declaran");
	            	mapBusqueda.put("codTipoDocum", codtipoDocumento);
	            	mapBusqueda.put("numDocum", numeroDocumento);
	            	AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
	            	List<Map<String, Object>> lstRspta = ayudaService.buscar(mapBusqueda);
	            	
	            	if (!CollectionUtils.isEmpty(lstRspta)) {
	            		Map<String, Object> mapRspta = lstRspta.get(0);
	            		
	            		Map<String, String> mapItem = new HashMap<String, String>();
	            		mapItem.put("numeroDocumento", (String) mapRspta.get("cdocumen"));
	            		mapItem.put("razonSocial", (String) mapRspta.get("dnombre"));
	            		mapItem.put("direccion", (String) mapRspta.get("ddirecc"));
	            		lstOperador.add(mapItem);
	            	}
	            }
	        }
	        view.addObject("lstOperador", lstOperador);
	    	
    	} catch (Exception ex) {
    		log.error("**** ERROR ****", ex);
    		mensajeBean.setError(true);
    		mensajeBean.setMensajeerror("Se ha producido un error " + ex.getMessage());
    	} finally {
    		view.addObject(mensajeBean);
    	}
    	return view;
	}

	/**
	 * Permite consultar via ajax local anexo
	 * @param request [HttpServletRequest] request
	 * @param response [HttpServletResponse] response
	 * @return  [ModelAndView] model and view
	 * @version 1.0
	 * */
	public ModelAndView consultarLocalAnexo(HttpServletRequest request, HttpServletResponse response){
		if (this.log.isDebugEnabled())
			log.debug("method:consultarLocalAnexo");
		
		ModelAndView view = new ModelAndView(this.jsonView);
		MensajeBean mensajeBean = new MensajeBean();
	    
		try
	    {
			ServletWebRequest webRequest = new ServletWebRequest(request);
			String ruc = webRequest.getParameter("txt_codigo");
			List<Map<String, Object>> lstLocalAnexo = this.soporteService.obtenerLocaAnexo(ruc);
			
			//RIN13-pase619
			if (CollectionUtils.isEmpty(lstLocalAnexo)) {
				Map<String, Object> mapAnexo = new HashMap<String, Object>();
                mapAnexo.put("codLocalAnexo", "0000");
                mapAnexo.put("direccion", "");
                lstLocalAnexo.add(mapAnexo);
	        }
			
			view.addObject("lstLocalAnexo", lstLocalAnexo);
	    
	    } catch (Exception ex) {
	    	log.error("**** ERROR ****", ex);
	    	mensajeBean.setError(true);
	    	mensajeBean.setMensajeerror("Se ha producido un error " + ex.getMessage());
	    } finally {
	    	view.addObject(mensajeBean);
	    }
		return view;
	}
	/* PAS20145E220000529 INICIO GGRANADOS */	
	public ModelAndView validarResolucionMulta(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView view = new ModelAndView(this.jsonView);
		
		Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");		
		ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");		
		
		//cargar parametros
		ResolucionMulta resolucionMulta = new ResolucionMulta();
		bindToCommand(request, resolucionMulta);
		
		//buscar resolucion
		List<ResCabBean> lstResoluciones = resolucionService.buscarResolucionesByPk(resolucionMulta.convertirAMapa(resolucionMulta));
		
		//validar resolucion
		ObjectResponseUtil rptaValidaResolucion = diligenciaService.validarResolucion(lstResoluciones, mapCabDeclara);
		//mapResolucion.get("mensaje");
		
		if(rptaValidaResolucion.poseeError()){
			WebUtils.setSessionAttribute(request, "generarLC003", false);
			//WebUtils.setSessionAttribute(request, "docDeterminacionMulta", docDeterminacionMulta);
			view.addObject("mesanjeValResolucion", rptaValidaResolucion.getMensajes().get(0).getMensajeerror());
			view.addObject("success", false);
			return view;
		}
		
		WebUtils.setSessionAttribute(request, "generarLC003", true);
		WebUtils.setSessionAttribute(request, "resolucionMulta", lstResoluciones.get(0));
		WebUtils.setSessionAttribute(request, "resolucionDeterminacion", lstResoluciones.get(0));//PAS20155E220000166
		view.addObject("success", true);
		return view;
	}
	
	/* PAS20155E220000166 INICIO */	
	//Usado para generar LC010 para documento Determinacion 
	public ModelAndView validarResolucionTributos(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView view = new ModelAndView(this.jsonView);
		
		Map<String, Object> mapCabDeclara = (Map<String, Object>) request.getSession().getAttribute("mapCabDeclaraActual");		
		ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");		
		
		//cargar parametros
		ResolucionMulta resolucionMulta = new ResolucionMulta();
		bindToCommand(request, resolucionMulta);		
		
		//buscar resolucion
		List<ResCabBean> lstResoluciones = resolucionService.buscarResolucionesByPk(resolucionMulta.convertirAMapa(resolucionMulta));
		
		//validar resolucion
		ObjectResponseUtil rptaValidaResolucion = diligenciaService.validarResolucion(lstResoluciones, mapCabDeclara);
		//mapResolucion.get("mensaje");
		
		if(rptaValidaResolucion.poseeError()){
			WebUtils.setSessionAttribute(request, "generarLC010", false);
			view.addObject("mesanjeValResolucion", rptaValidaResolucion.getMensajes().get(0).getMensajeerror());
			view.addObject("success", false);
			return view;
		}
		WebUtils.setSessionAttribute(request, "generarLC010", true);
		WebUtils.setSessionAttribute(request, "resolucionTributo", lstResoluciones.get(0));
		//WebUtils.setSessionAttribute(request, "resolucionDeterminacionTributo", lstResoluciones.get(0));
		view.addObject("success", true);
		return view;
	}
	
	public ModelAndView getListAreas(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String> params = new HashMap<String, String>();
		params.put("flag", "0");
		TabDepService tabDepService = (TabDepService) fabricaDeServicios.getService("tramite.tabDepService");
		List<Map<String, Object>> lstAreas = tabDepService.listarAreas(params);
		return new ModelAndView("jsonView", getMapFinal(lstAreas));
	}
	
	public ModelAndView getListTiposResoluciones(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ResolucionService resolucionService = (ResolucionService) fabricaDeServicios.getService("tramite.ResolucionService");
		List<Map<String, Object>> lstTiposResoluciones = resolucionService.obtenerTiposResoluciones();
		return new ModelAndView("jsonView", getMapFinal(lstTiposResoluciones));
	}

	private Map<String, Object> getMapFinal(List<Map<String, Object>> lst) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("identifier", "c");
		map.put("label", "n");
		map.put("items", lst);
		return map;
	}
	  
	private ModelAndView generaInvocacion(UsuarioBean ubean, String url, Map parametros)
            throws Exception {

        FechaBean ts = new FechaBean();
        Map addins = new HashMap();
        addins.put("vigInvocaDesde", new Long(ts.getCalendar().getTimeInMillis() - 30000L));
        ts.getCalendar().add(12, 10);
        addins.put("vigInvocaHasta", new Long(ts.getCalendar().getTimeInMillis()));
        ubean.getMap().putAll(addins);

        if (this.log.isDebugEnabled()) {
            this.log.debug("usuarioBean.map.." + ubean.getMap());
        }
        UsuarioBean cloneBean = (UsuarioBean) BeanUtils.cloneBean(ubean);
        cloneBean.setTicket(String.valueOf(cloneBean.getMap().get("idMenu")).concat("-").concat(""));

        String encodeBase64 = null;
        ZipUtil zip = new ZipUtil();
        byte[] zipObject = zip.zipObject(cloneBean);
        encodeBase64 = new Coder().encodeBase64(zipObject);
        if (this.log.isDebugEnabled()) this.log.debug(encodeBase64);

        Hash hash = HashFactory.getHash(0, encodeBase64.getBytes());
        String sha = Hex.getByteToHex(hash.get());

        if (this.log.isDebugEnabled()) {
            this.log.debug(url);
        }
        ModelAndView urlView = new ModelAndView(new RedirectView(url, false));
        urlView.addObject("token", encodeBase64);
        urlView.addObject("hc", sha);


        if (MapUtils.isNotEmpty(parametros)) {
            Set keySet = parametros.entrySet();
            Iterator iterator = keySet.iterator();
            Map.Entry key = null;
            while (iterator.hasNext()) {
                key = (Map.Entry)iterator.next();
                if (!"action".equals(key.getKey())) {
                    urlView.addObject((String)key.getKey(), key.getValue());
                }
            }
        }

        log.info("ACCESO|" + ubean.getMap().get("tipOrigen") + "|" +
                ubean.getLogin() + "|" + ubean.getTicket() + "|" + "(" + url + ")");

        return urlView;
    }
	
	
	/**
	 * @return the formatoValorService
	 */
	public FormatoValorService getFormatoValorService() {
		return formatoValorService;
	}

	/**
	 * @param formatoValorService the formatoValorService to set
	 */
	public void setFormatoValorService(FormatoValorService formatoValorService) {
		this.formatoValorService = formatoValorService;
	}

	/**
	 * @return the fabricaDeServicios
	 */
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	/**
	 * @param fabricaDeServicios the fabricaDeServicios to set
	 */
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	/**
	 * @return the declaracionService
	 */
	public DeclaracionService getDeclaracionService() {
		return declaracionService;
	}

	/**
	 * @param declaracionService the declaracionService to set
	 */
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	/**
	 * @return the solicitudService
	 */
	public SolicitudService getSolicitudService() {
		return solicitudService;
	}

	/**
	 * @param solicitudService the solicitudService to set
	 */
	public void setSolicitudService(SolicitudService solicitudService) {
		this.solicitudService = solicitudService;
	}

	/**
	 * @return the serieService
	 */
	public SerieService getSerieService() {
		return serieService;
	}

	/**
	 * @param serieService the serieService to set
	 */
	public void setSerieService(SerieService serieService) {
		this.serieService = serieService;
	}

	/**
	 * @return the rectificacionService
	 */
	public RectificacionService getRectificacionService() {
		return rectificacionService;
	}

	/**
	 * @param rectificacionService the rectificacionService to set
	 */
	public void setRectificacionService(RectificacionService rectificacionService) {
		this.rectificacionService = rectificacionService;
	}

	/**
	 * @return the soporteService
	 */
	public SoporteService getSoporteService() {
		return soporteService;
	}

	/**
	 * @param soporteService the soporteService to set
	 */
	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}
	
	/**
	 * @return the consultaService
	 */
	public ConsultaService getConsultaService() {
		return consultaService;
	}

	/**
	 * @param consultaService the consultaService to set
	 */
	public void setConsultaService(ConsultaService consultaService) {
		this.consultaService = consultaService;
	}
	
	
}
