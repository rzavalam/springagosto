package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.MedioTransDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;


/**
 * The Class SqlMapMedioTransDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapMedioTransDAO extends SqlMapDAOBase implements MedioTransDAO
{

  /**
   * {@inheritDoc}
   */
  public List<Map<String, String>> findByDocumento(Map<String, String> PkDocu)
  {
    return getSqlMapClientTemplate().queryForList("MedioTrans.findByDocumento", PkDocu);
  }
}