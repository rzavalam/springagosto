package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;

import java.util.List;
import java.util.Map;


import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.SoliSubsanacionDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;

public  class SqlMapSoliSubsanacionDAO extends SqlMapDAOBase implements SoliSubsanacionDAO
{
	 /**
	   * {@inheritDoc}
	   */
		public void insertSelective(SolicitudSubsanacion solicitudSubsanacion){
			this.getSqlMapClientTemplate().insert("SoliSubsanacion.insertSelective", solicitudSubsanacion);
		}
		
		/**
		   * {@inheritDoc}
		   */		
		public SolicitudSubsanacion getIncidenciaSubsanadaByParameterMap(Map<String, Object> params) {
			return (SolicitudSubsanacion) getSqlMapClientTemplate().queryForObject("SoliSubsanacion.getIncidenciaSubsanadaByParameterMap", params);
		}
		
		/**
		   * {@inheritDoc}
		   */
		public List<SolicitudSubsanacion> listConsultaSubsanacionObsZPAE(Map<String, Object> params){
			return (List<SolicitudSubsanacion>) getSqlMapClientTemplate().queryForList("SoliSubsanacion.listConsultaSubsanacionObsZPAE", params);
		}
}
