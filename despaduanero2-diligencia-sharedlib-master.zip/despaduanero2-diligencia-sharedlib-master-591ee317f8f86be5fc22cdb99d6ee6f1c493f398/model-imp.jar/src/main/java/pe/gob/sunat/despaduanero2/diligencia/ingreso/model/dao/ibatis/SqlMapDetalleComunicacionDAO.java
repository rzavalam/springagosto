/* Creado - P14 - 3014 - Inicio - dhernandezv */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DetalleComunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetalleComunicacionDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;

/**
 * The Class SqlMapDetalleComunicacionDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapDetalleComunicacionDAO extends SqlMapDAOBase implements DetalleComunicacionDAO
{

	@Override
	/**
	 * {@inheritDoc}
	 */
	public List<DetalleComunicacion> findDetalleComunicacionNotificacion(
			DetalleComunicacion params) {
		return getSqlMapClientTemplate().queryForList("DetalleComunicacion.obtenerDetalleNotificacion", params);		
	}
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	@Override
	public Long obtenerSiguienteCorrelativo(Map<String, Object> params) {
		
		return (Long) getSqlMapClientTemplate().queryForObject("DetalleComunicacion.obtenerSiguienteCorrelativo",params);//gmontoya anita la culpable
		
	}
	
	@Override
	public void insert(Map<String, Object> params) {
		
		this.getSqlMapClientTemplate().insert("DetalleComunicacion.insert", params);
		
	}
	
	//ggranados 179
	public void insertSelective(DetalleComunicacion notificacion){
		this.getSqlMapClientTemplate().insert("DetalleComunicacion.insertSelective", notificacion);
	}
	
	public List<DetalleComunicacion> findDetalleComunicacionNotificacionParaDeclaracionOficio(Map<String, Object> params) {
		return getSqlMapClientTemplate().queryForList("DetalleComunicacion.obtenerDetalleNotificacionParaDeclaracionOficio", params);		
	}
	
	//rtineo PAS20155E220400065
	public List<DetalleComunicacion> selectDetalleNotificacionesEER(Map<String,Object> params){
		return getSqlMapClientTemplate().queryForList("DetalleComunicacion.selectDetalleNotificacionesEER", params);
	}

}