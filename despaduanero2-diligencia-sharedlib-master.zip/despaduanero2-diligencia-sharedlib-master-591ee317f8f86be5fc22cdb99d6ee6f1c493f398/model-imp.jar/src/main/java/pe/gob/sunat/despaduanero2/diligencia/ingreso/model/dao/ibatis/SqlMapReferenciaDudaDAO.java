package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ReferenciaDudaDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;



/**
 * The Class SqlMapReferenciaDudaDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapReferenciaDudaDAO extends SqlMapDAOBase implements ReferenciaDudaDAO
{

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findByPkItem(Map<String, String> pkItem)
  {
    return getSqlMapClientTemplate().queryForList("ReferenciaDUDA.findByPkItem", pkItem);
  }

  /**
   * {@inheritDoc}
   */
  public void insert(Map<String, Object> mapReferenciaDuda)
  {
    getSqlMapClientTemplate().insert("ReferenciaDUDA.insert", mapReferenciaDuda);
  }
  
  public int getMaxNumSecRefDuda(Map<String,Object> numSecRef){
	  return ((Integer)getSqlMapClientTemplate().queryForObject("ReferenciaDUDA.getMaxNumSecRefDuda", numSecRef)).intValue();
  }
  
}
