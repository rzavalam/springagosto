package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabAdiDiligVincDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;

/**
 * The Class SqlMapCabAdiDiligVincDAO.
 */
@SuppressWarnings({"unchecked" })
public class SqlMapCabAdiDiligVincDAO extends SqlMapDAOBase implements CabAdiDiligVincDAO
{

  /**
   * {@inheritDoc}
   */
  public void insert(Map<String, Object> params)
  {
    getSqlMapClientTemplate().insert("CabAdiDiligVinc.insert", params);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> getByTipoDiligencia(Map<String, Object> params)
  {
    return (Map<String, Object>) getSqlMapClientTemplate()
        .queryForObject("CabAdiDiligVinc.getByTipoDiligencia", params);
  }


}
