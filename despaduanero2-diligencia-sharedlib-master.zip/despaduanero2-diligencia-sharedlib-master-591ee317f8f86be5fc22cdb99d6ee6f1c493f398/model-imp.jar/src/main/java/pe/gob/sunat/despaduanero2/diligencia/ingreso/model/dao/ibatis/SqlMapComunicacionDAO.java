package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.NotificacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ComunicacionDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;


/**
 * The Class SqlMapComunicacionDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapComunicacionDAO extends SqlMapDAOBase implements ComunicacionDAO {

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> findByDiligenciaAndTipo(Map<String, String> pkDocumento) {
		return getSqlMapClientTemplate().queryForList("Comunicacion.findByDiligenciaAndTipo", pkDocumento);
	}

	/**
	 * {@inheritDoc}
	 */
	public Integer obtenerSiguienteCorrelativo() {
		return (Integer) getSqlMapClientTemplate().queryForObject("Comunicacion.obtenerSiguienteCorrelativo");
	}

	/**
	 * {@inheritDoc}
	 */
	public Integer insertComunicacion(Map<String, Object> params) {
		return (Integer) getSqlMapClientTemplate().insert("Comunicacion.insertComunicacion", params);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> findByNumCorredoc(Map<String, Object> pkDocumento) {
		return getSqlMapClientTemplate().queryForList("Comunicacion.findByNumCorredoc", pkDocumento);
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> findNotificacionesByNumCorreDoc(Map<String, Object> PkDocu) {
		return getSqlMapClientTemplate().queryForList("Comunicacion.findNotificacionesByNumCorreDoc", PkDocu);
	}

	/**
	 * {@inheritDoc}
	 */
  	public String obtenerNumeroSecuenciaComunicacion(Map<String, Object> params){
  		return (String) getSqlMapClientTemplate().queryForObject("Comunicacion.obtenerNumeroSecuenciaComunicacion", params);
  	}

	/**
	 * Inserta un registro de comunicacion con campos selectivos
	 * 
	 * @param diligencia Comunicacion a registrar
	 * @return
	 * @author gbecerrav
	 */
  	public void insertSelective(Comunicacion comunicacion) {
	  	this.getSqlMapClientTemplate().insert("Comunicacion.insertSelective", comunicacion);
  	}
  
  	public List<Map<String, Object>> buscarNotificacionRespondida(Map<String, Object> params){
  		return getSqlMapClientTemplate().queryForList("Comunicacion.buscarNotificacionRespondida", params);
  	}
  
	public List<ComunicacionDescripcion> obtenerNotificaciones(Map<String, Object> params) {
		return getSqlMapClientTemplate().queryForList("Comunicacion.obtenerNotificaciones", params);
	}
	
	public List<ComunicacionDescripcion> findPendientesByNumCorreDoc(Long numCorreDoc){
		return getSqlMapClientTemplate().queryForList("Comunicacion.findPendientesByNumCorredoc", numCorreDoc);		
	}
	
	public void updateRespuestaComunicacionNotificacion(Map<String, Object> params){		
		this.getSqlMapClientTemplate().update("Comunicacion.updateRespuestaComunicacionNotificacionByPk", params);		
	}	
	
	//ggranados pase comunicacion
	public Comunicacion selectNotificacionByID(Long numNota){
		return (Comunicacion) getSqlMapClientTemplate().queryForObject("Comunicacion.selectNotificacionByID", numNota);
	}
	
	/**
	 * Obtiene el listado de notificaciones de acuerdo a los parametros enviados
	 * @param params
	 * @return
	 */
	public List<Comunicacion> listNotificaciones(Map<String,Object> params){
		return getSqlMapClientTemplate().queryForList("Comunicacion.listNotificaciones", params);		
	}
	
	public void updateComunicacion(Comunicacion comunicacion){
		this.getSqlMapClientTemplate().update("Comunicacion.updateComunicacion", comunicacion);
	}
	
	/**
	 * retorna el reporte de la notificacion eer
	 */
	public List<NotificacionBean> listConsultaNotificacionesEER(Map<String,Object> params){
		return getSqlMapClientTemplate().queryForList("Comunicacion.listConsultaNotificacionesEER", params);
	}
	
}