package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ConsultaDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;

/**
 * The Class SqlMapConsultaDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapConsultaDAO extends SqlMapDAOBase implements ConsultaDAO
{

  /**
   * {@inheritDoc}
   */
  public Integer insert(Map<String, Object> params) throws DataAccessException
  {
    return (Integer) getSqlMapClientTemplate().insert("Consulta.insert", params);
  }

  /**
   * {@inheritDoc}
   */
  public int update(Map<String, Object> params) throws DataAccessException
  {
    return getSqlMapClientTemplate().update("Consulta.update", params);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findByNumCorredocDiligencia(Map<String, Object> params)
  {
    return (Map<String, Object>) getSqlMapClientTemplate().queryForObject(
        "Consulta.selectByNumCorredocDiligencia", params);
  }


	public List<Map<String, Object>> findByNumCorredocDiligencia2(Map<String, Object> params)
	{
		return (List<Map<String, Object>>) getSqlMapClientTemplate().queryForList("Consulta.selectByNumCorredocDiligencia", params);
	}

	/* olunar 309 */
	@Override
	public Consulta findByPk(Consulta consulta) throws DataAccessException {
		return (Consulta) getSqlMapClientTemplate().queryForObject("Consulta.selectByPk", consulta);
	}

	//@SuppressWarnings("unchecked")
	@Override
	public List<Consulta> findByConsulta(Consulta consulta) throws DataAccessException {
		return (List<Consulta>) getSqlMapClientTemplate().queryForList("Consulta.selectByConsulta", consulta);
	}

	@Override
	public Integer selectMaxNumSec(Consulta consulta) throws DataAccessException {
		Integer maxNumSec = (Integer) getSqlMapClientTemplate().queryForObject("Consulta.selectMaxNumSecConsulta", consulta);
		return maxNumSec;
	}

	@Override
	public int update(Consulta consulta) throws DataAccessException {
		return getSqlMapClientTemplate().update("Consulta.updateSelective", consulta);
	}

	@Override
	public void insert(Consulta consulta) throws DataAccessException {
		getSqlMapClientTemplate().insert("Consulta.insertSelective", consulta);
	}
	/* fin */
}
