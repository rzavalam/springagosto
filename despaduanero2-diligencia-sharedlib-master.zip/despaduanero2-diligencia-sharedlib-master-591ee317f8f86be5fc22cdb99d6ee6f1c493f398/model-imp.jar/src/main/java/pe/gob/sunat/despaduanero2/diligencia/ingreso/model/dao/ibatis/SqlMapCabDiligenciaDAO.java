package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.Validate;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.AccionesDespachoBean;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.RegularizacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.salida.bean.UnidadSeleccionDiligenciaSalida;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
/**
 * The Class SqlMapCabDiligenciaDAO.
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SqlMapCabDiligenciaDAO extends SqlMapDAOBase implements
    CabDiligenciaDAO
{

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findByDocumento(Map<String, String> pkDocumento)
  {
    return getSqlMapClientTemplate().queryForList("CabDiligencia.findByDocumento", pkDocumento);
  }

  public List<Map<String, Object>> getDiligenciaDespachoSustentoModificado(Map<String, String> PkDocu)
  {
    return getSqlMapClientTemplate().queryForList("CabDiligencia.getDiligenciaDespachoSustentoModificado", PkDocu);
  }

  /**
   * {@inheritDoc}
   */
  public void insert(Map<String, Object> params)
  {
    this.getSqlMapClientTemplate().insert("CabDiligencia.insert", params);
  }

  /**
   * {@inheritDoc}
   */
  public void update(Map<String, Object> params)
  {
    this.getSqlMapClientTemplate().update("CabDiligencia.update", params);
  }

  /**
   * {@inheritDoc}
   */
  public Integer count(Map<String, Object> params)
  {
    return ((Integer) getSqlMapClientTemplate().queryForObject("CabDiligencia.count", params)).intValue();
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> tieneSolicitudesXEspecialista(Map<String, Object> params)
  {
    return (Map) getSqlMapClientTemplate().queryForObject("CabDiligencia.tieneSolicitudesXEspecialista", params);

  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findTieneAmpliacionPlazo(Map<String, Object> params)
  {
    return (Map) getSqlMapClientTemplate().queryForObject("CabDiligencia.findTieneAmpliacionPlazo", params);
  }



  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findDuaDiligenciada(String numCorredoc)
  {
    Map<String, Object> res = (Map) getSqlMapClientTemplate().queryForObject(
        "CabDiligencia.findDuaDiligenciada", numCorredoc);
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map> findPlazoConclusion(Map<String, Object> params)
  {
    return getSqlMapClientTemplate().queryForList("CabDiligencia.findPlazoConclusion", params);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findDuaRectificada(String numCorredoc)
  {
    Map<String, Object> res = (Map) getSqlMapClientTemplate().queryForObject(
        "CabDiligencia.findDuaRectificada", numCorredoc);
    return res;
  }


  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findPrimeraDiligencia(Map<String, Object> params)
  {
    return (Map) getSqlMapClientTemplate().queryForObject("CabDiligencia.findPrimeraDiligencia", params);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findUltimaDiligencia(Map<String, Object> params)
  {
    return (Map) getSqlMapClientTemplate().queryForObject("CabDiligencia.findUltimaDiligencia", params);
  }

    /**
   * {@inheritDoc}
   */
  public Diligencia findByPrimaryKey(Diligencia diligencia) {
    Validate.notNull(diligencia.getNumeroCorrelativo(), "El numero correlativo de la Dua no debe de ser nula");
    Diligencia res = (Diligencia)getSqlMapClientTemplate().queryForObject(
        "CabDiligencia.findDiligenciaByPK", diligencia);
    return res;
  }

/**
 * {@inheritDoc}
 */
  public String obtenerTipoDiligencia(Map<String, Object> mapa)
  {
    return (String) getSqlMapClientTemplate().queryForObject("CabDiligencia.obtenerTipoDiligencia", mapa);
  }

  /**
   * {@inheritDoc}
   */
    public Integer ultimoNumCorreDocSol(Map<String, Object> params) {

        return ((Integer)getSqlMapClientTemplate().queryForObject("CabDiligencia.ultimoNumCorreDocSol", params)).intValue();
    }

    /**
     * {@inheritDoc}
     */
  public Integer countMaxByNumCorreDocAndTipodAndDate(Map<String, Object> params){
        return ((Integer)getSqlMapClientTemplate().queryForObject("CabDiligencia.countMaxByNumCorreDocAndTipodAndDate", params)).intValue();
    }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> select(Map<String, Object> mapPK) {
      return getSqlMapClientTemplate().queryForList("CabDiligencia.select", mapPK);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findTieneDeclaracionDiligenciaTipo(Map<String, Object> params)
  {

    Map<String, Object> res = (Map) getSqlMapClientTemplate().queryForObject(
        "CabDiligencia.findTieneDeclaracionDiligenciaTipo", params);
    return res;
  }

/*INICIO-RIN13*/
  	/**
	 * Verifica si existe diligencia
	 * @param diligencia Diligencia a verificar
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */	
	public boolean hasDiligencia(Diligencia diligencia) {
		 Integer rpta = (Integer) getSqlMapClientTemplate().queryForObject("CabDiligencia.hasDiligencia", diligencia);
		 return rpta != null ? true : false;
	}

	/**
	 * Verifica si existe diligencia
	 * @param diligencia Diligencia a verificar
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */	
	public boolean hasDiligenciaByParameterMap(Map<String, Object> params) {
		 Integer rpta = (Integer) getSqlMapClientTemplate().queryForObject("CabDiligencia.hasDiligenciaByParameterMap", params);
		 return rpta != null ? true : false;
	}
	
	/**
	 * Inserta un registro de diligencia 
	 * con campos selectivos
	 * @param diligencia Diligencia a registrar
	 * @return 
	 * @author gbecerrav
	 */	
	public void insertSelective(Diligencia diligencia) {
		 this.getSqlMapClientTemplate().insert("CabDiligencia.insertSelective", diligencia);
	}
/*FIN-RIN13*/

  // FIXME: CUS110301 lpalominom [inicio]
  /**
   * {@inheritDoc}
   */
  public RegularizacionBean obtenerParametrosActualizacionRegularizacion(Map<String, Object> params){
	  return (RegularizacionBean) getSqlMapClientTemplate().queryForObject("CabDiligencia.obtenerParametrosActualizacionRegularizacion",params);
  }
  // FIXME: CUS110301 lpalominom [fin]
  
  /***** GGRANADOS RIN16PASE3 INI *****/
  public void insert(Diligencia diligencia){
	  this.getSqlMapClientTemplate().insert("CabDiligencia.insertDiligencia", diligencia);
  }
  /***** GGRANADOS RIN16PASE3 FIN *****/
  
  //RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
  public Map<String, Object> findUltimaDiligenciaConPlazoProceso(Map<String, Object> params)
  {
    return (Map) getSqlMapClientTemplate().queryForObject("CabDiligencia.findUltimaDiligenciaConPlazoProceso", params);
  }
  //RTINEO FIN

  /**** dsalcedov RIN7 PASE23 ***/
  public List<Diligencia> getAccionesDiligencia(Map<String, Object> params) {
	  return (List<Diligencia>)getSqlMapClientTemplate().queryForList("CabDiligencia.getAccionesDiligencia", params);

  }  
  
  public List<AccionesDespachoBean> getAccionesDespacho(String codigoNumeracionDAM) {
		Map<String,Object> params = new HashMap<String,Object>();
	   	params.put("codigoNumeracionDAM", codigoNumeracionDAM);
		return (List<AccionesDespachoBean>)getSqlMapClientTemplate().queryForList("CabDiligencia.getAccionesDespacho", params);
 }

  // rectificacion de diligencia
  @Override
  public List<UnidadSeleccionDiligenciaSalida> getUnidadesSeleccionDiligenciaSalida(Long numeroCorrelativoDAM) {
		Map<String,Object> params = new HashMap<String,Object>();
	   	params.put("numeroCorrelativoDAM", numeroCorrelativoDAM);
		return (List<UnidadSeleccionDiligenciaSalida>) getSqlMapClientTemplate().queryForList("CabDiligencia.getUnidadesSeleccionDiligenciaSalida", params);
  }
 
  /**PAS20181U220200073
   * Busca una diligencia por numCorredoc
   * o todas sus pk
   * @param diligencia
   * @return
   */ 
  public Diligencia findAllDiligenciaByPK(Map<String, Object> params){
	  return  (Diligencia)getSqlMapClientTemplate().queryForObject("CabDiligencia.findAllDiligenciaByPK", params);
  } 

}
