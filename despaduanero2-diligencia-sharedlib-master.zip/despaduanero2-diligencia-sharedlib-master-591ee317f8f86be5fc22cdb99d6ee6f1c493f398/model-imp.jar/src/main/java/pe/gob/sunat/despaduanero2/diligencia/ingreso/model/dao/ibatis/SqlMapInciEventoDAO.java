package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.InciEventoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EventoIncidencia;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;



/**
 * The Class SqlMapInciEventoDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapInciEventoDAO extends SqlMapDAOBase implements InciEventoDAO
{

  /**
   * {@inheritDoc}
   */
  public List<Map<String, String>> getInciEventoList(Map<String, Object> params) throws DataAccessException
  {
    return getSqlMapClientTemplate().queryForList("InciEvento.getInciEventoList", params);
  }

	// RIN13-SWF
    public List<EventoIncidencia> getLstInciEvento() throws DataAccessException{

        return getSqlMapClientTemplate().queryForList("InciEvento.getLstInciEvento");
    }

}
