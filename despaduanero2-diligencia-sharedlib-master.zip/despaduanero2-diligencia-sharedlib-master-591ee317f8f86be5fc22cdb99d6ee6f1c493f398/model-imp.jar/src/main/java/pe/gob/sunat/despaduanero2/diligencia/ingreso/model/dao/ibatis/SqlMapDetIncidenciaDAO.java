package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetIncidenciaDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;


/**
 * The Class SqlMapDetIncidenciaDAO.
 */
@SuppressWarnings({ "unchecked" })
public class SqlMapDetIncidenciaDAO extends SqlMapDAOBase implements DetIncidenciaDAO
{

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findByDiligencia(Map<String, String> pkDiligencia)
  {
    return getSqlMapClientTemplate().queryForList("DetIncidencia.findByDiligencia", pkDiligencia);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findAll(String num_corredoc)
  {
    return getSqlMapClientTemplate().queryForList("DetIncidencia.findAll", num_corredoc);
  }

  /**
   * {@inheritDoc}
   */
  public void insert(Map<String, Object> params)
  {
    this.getSqlMapClientTemplate().insert("DetIncidencia.insert", params);
  }
  
  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findByIncidencia(Map<String, Object> pkIncidencia)
  {
    return getSqlMapClientTemplate().queryForList("DetIncidencia.findByIncidencia", pkIncidencia);
  }

}
