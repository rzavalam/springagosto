package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ibatis;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;


import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.TabBolQuimDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;



/**
 * The Class SqlMapTabBolQuimDAO.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class SqlMapTabBolQuimDAO extends SqlMapDAOBase implements TabBolQuimDAO
{



  /**
   * {@inheritDoc}
   */
  public List<Map> joinDetDeclaraFindByDeclaracion(Map<String, Object> params)
  {
    return getSqlMapClientTemplate().queryForList("TabBolQuim.joinDetDeclaraFindByDeclaracion", params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> findByDeclaracion(Map<String, Object> pkDeclaracion)
      throws DataAccessException
  {
    return getSqlMapClientTemplate().queryForList("TabBolQuim.findByDeclaracion", pkDeclaracion);
  }


  /**
   * {@inheritDoc}
   */
  public List findPendConcluByDeclaracion(Map<String, Object> pkDeclaracion)
  {
    return getSqlMapClientTemplate().queryForList("TabBolQuim.findPendConcluByDeclaracion", pkDeclaracion);
  }

  /**
   * {@inheritDoc}
   */
  public void update(Map<String, Object> params)
  {
    this.getSqlMapClientTemplate().update("TabBolQuim.update", params);
  }

  public List<Map<String, Object>> findByDeclaracionForAsignacionAutomatica(Map<String, Object> PkDecla) throws DataAccessException {
    return getSqlMapClientTemplate().queryForList("TabBolQuim.findByDeclaracionForAsignacionAutomatica", PkDecla);
  }
  
  /** P44 - INI -JYC **/
  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> buscarFechaBoletinQuimicoConcluido(Map<String, Object> parametros) {
	return  getSqlMapClientTemplate().queryForList("TabBolQuim.buscarFechaBoletinQuimicoConcluido", parametros);
  }
  /** P44 - FIN -JYC **/
  
}
