package pe.gob.sunat.despaduanero2.multa.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.MultaDua;
import pe.gob.sunat.despaduanero2.multa.model.dao.MultaDuaDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Class SqlMapMultaDuaDAO.
 */
public class SqlMapMultaDuaDAO extends SqlMapDAOBase implements MultaDuaDAO
{


  /**
   * {@inheritDoc}
   */
  public void insertSelective(Map<String, Object> record)
  {
    getSqlMapClientTemplate().insert("MULTADUA.insertSelective", record);
  }

  	/* RIN15 - f2 3011 - Inicio - lrodriguezc */
	@Override
	public List<MultaDua> listMultaDUA(Map<String, Object> paramMulta) {

		return getSqlMapClientTemplate().queryForList("MULTADUA.listMultaDUA", paramMulta);

	}
	/* RIN15 - f2 3011 - Fin - lrodriguezc */
/*RIN13FSW*/
  /*jlunah*/
  public List<Map<String, Object>> buscaMismaInfraccionEnOtraDiligencia(Map<String, Object> parametros) throws ServiceException {	  
	  List<Map<String, Object>> listaRetorno = (List<Map<String,Object>>) this.getSqlMapClientTemplate().queryForList("MULTADUA.buscaMismaInfraccionEnOtraDiligencia",parametros); 
	  return listaRetorno;
  }

}