package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class FormBItemDescriRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 1289816017220658324L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstFormBItemDescri";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FormBItemDescriDAO  formBItemDescriDAO;

  //rtineo mejoras, grabacion en batch
  private FormBItemDescriBatchDAO formBItemDescriBatchDAO;

  public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO)
  {
    this.formBItemDescriDAO = formBItemDescriDAO;
  }

  public FormBItemDescriRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECITEM", "NUM_SECITEM");
    mapClave.put("COD_MERCANCIA", "COD_MERCANCIA");
    mapClave.put("COD_TIPDESC", "COD_TIPDESC");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FORMB_ITEM_DESCRI;
  }

  public DatoDescrMinima mapToObject(Map<String, Object> formBItemDescri)
  {
    DatoDescrMinima datoDescrMinima = new DatoDescrMinima();

    datoDescrMinima.setNumcorredoc(new Long(ObjectUtils.toString(formBItemDescri.get("NUM_CORREDOC"), "0")));
    datoDescrMinima.setNumsecprove(new Integer(ObjectUtils.toString(formBItemDescri.get("NUM_SECPROVE"), "0")));
    datoDescrMinima.setNumsecfact(new Integer(ObjectUtils.toString(formBItemDescri.get("NUM_SECFACT"), "0")));
    datoDescrMinima.setNumsecitem(new Integer(ObjectUtils.toString(formBItemDescri.get("NUM_SECITEM"), "0")));

    datoDescrMinima.setCodtipdescr(ObjectUtils.toString(formBItemDescri.get("COD_TIPDESC"), " "));
    datoDescrMinima.setValtipdescri(ObjectUtils.toString(formBItemDescri.get("DES_DESCRIPCION"), " "));
    datoDescrMinima.setCodmercancia(ObjectUtils.toString(formBItemDescri.get("COD_MERCANCIA"), " "));

    return datoDescrMinima;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    //return formBItemDescriDAO.selectByMap(mapParametros);//PAS20171U220200016: se comenta porque este con ind_del se usa para todas las consultas por todos lados
    return formBItemDescriDAO.selectByMapFindByPK(mapParametros);//se usa este Nuevo metodo
  }
  //rtineo mejoras, grabacion en batch
  public FormBItemDescriBatchDAO getFormBItemDescriBatchDAO() {
	return formBItemDescriBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFormBItemDescriBatchDAO(FormBItemDescriBatchDAO formBItemDescriBatchDAO) {
	this.formBItemDescriBatchDAO = formBItemDescriBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.formBItemDescriDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    updateRecordMap.put("rectificacion", "SI");
    formBItemDescriDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    this.formBItemDescriBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    updateRecordMap.put("rectificacion", "SI");
    formBItemDescriBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap));

}
}
