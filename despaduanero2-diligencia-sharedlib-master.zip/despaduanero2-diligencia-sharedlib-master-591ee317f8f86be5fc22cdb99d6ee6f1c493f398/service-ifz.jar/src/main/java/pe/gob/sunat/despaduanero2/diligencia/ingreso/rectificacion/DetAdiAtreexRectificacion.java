package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtreexBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtreexDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class DetAdiAtreexRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 1168638798206457637L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDetAdiAtreex";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private DetAdiAtreexDAO     detAdiAtreexDAO;
  //rtineo mejoras, grabacion en batch
  private DetAdiAtreexBatchDAO detAdiAtreexBatchDAO;

  public DetAdiAtreexRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DET_ADI_ATREEX;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return detAdiAtreexDAO.select(mapParametros);
  }

  public void setDetAdiAtreexDAO(DetAdiAtreexDAO detAdiAtreexDAO)
  {
    this.detAdiAtreexDAO = detAdiAtreexDAO;
  }

  //rtineo mejoras, grabacion batch
  public DetAdiAtreexBatchDAO getDetAdiAtreexBatchDAO() {
	return detAdiAtreexBatchDAO;
  }
  //rtineo mejoras, grabacion batch
  public void setDetAdiAtreexBatchDAO(DetAdiAtreexBatchDAO detAdiAtreexBatchDAO) {
	this.detAdiAtreexBatchDAO = detAdiAtreexBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    detAdiAtreexDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    detAdiAtreexDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapDetAdiAtreex);

  }

  //rtineo mejoras, grabacion batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    detAdiAtreexBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapDetAdiAtreex);

  }
  //rtineo mejoras, grabacion batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    detAdiAtreexBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }
}
