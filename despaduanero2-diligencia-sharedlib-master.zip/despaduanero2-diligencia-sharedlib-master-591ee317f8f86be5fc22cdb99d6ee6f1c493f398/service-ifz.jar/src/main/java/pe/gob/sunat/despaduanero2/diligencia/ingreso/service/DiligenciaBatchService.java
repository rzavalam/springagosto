package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

public interface DiligenciaBatchService {
	
	void iniciarRegistrarRectificacion();
	
	void procesarRegistrarRectificacion() throws Exception;
}
