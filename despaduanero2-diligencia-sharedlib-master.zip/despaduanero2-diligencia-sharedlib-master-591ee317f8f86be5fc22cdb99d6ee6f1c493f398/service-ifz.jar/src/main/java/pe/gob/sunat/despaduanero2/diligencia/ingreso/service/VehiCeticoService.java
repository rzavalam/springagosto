package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


public interface VehiCeticoService
{
  
	/**
	 * Inserta un vehiculo si no existe en BD caso contrario hace un update
	 * @author jenciso
	 * @param mapVehiculo	Map<String,Object>
	 */
	public void insertarVehiculoCeticos(Map<String,Object> mapVehiculo);
	
	/**
	 * Inserta un Concepto de gasto si no existe en BD caso contrario hace un update
	 * @author jenciso
	 * @param mapMontoGasto
	 */
	public void insertarMontoGasto(Map<String,Object> mapMontoGasto);
	
	/**
	 * Actualiza el indicador de eliminacion de todos los conceptos de gasto de una serie
	 * @author jenciso
	 * @param mapParams
	 */
	public void actualizarDatoEliminacionMontoGastoBySerie(Map<String,Object> mapParams);
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<DatoVehiculo> findVehiculoByMap(Map<String, Object> params) throws ServiceException;
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<Map<String,Object>> selectVehiCetico(Map<String, Object> params) throws ServiceException;
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<DatoMontoGasto> findMontoGastoByMap(Map<String, Object> params) throws ServiceException;
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<Map<String,Object>> selectMontoGasto(Map<String, Object> params) throws ServiceException;
	
}
