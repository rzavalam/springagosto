package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.sojo.interchange.json.JsonSerializer;

import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;


/**
 * Metodo encargado de ordenar una lista de HashMaps, de acuerdo a una campo.
 *
 */

@SuppressWarnings({ "rawtypes", "unchecked" })
public class HashMapComparator implements Comparator
{

  private String tipo;

  private String key;

  /**
   * Instantiates a new hash map comparator.
   *
   * @param key
   *          the key
   * @param tipo
   *          the tipo
   */
  public HashMapComparator(String key, String tipo)
  {
    this.tipo = tipo;
    this.key = key;

  }


  public int compare(Object object1, Object object2)
  {

    if ("1".equals(this.getTipo()))
    {
      Integer obj1Value = SunatNumberUtils.toInteger(((HashMap) object1).get(key));
      Integer obj2Value = SunatNumberUtils.toInteger(((HashMap) object2).get(key));

      return obj1Value.compareTo(obj2Value);
    }
    else
    {
      Integer obj1Value = SunatNumberUtils.toInteger(((HashMap) object1).get(key));
      Integer obj2Value = SunatNumberUtils.toInteger(((HashMap) object2).get(key));

      return obj2Value.compareTo(obj1Value);
    }
  }

  /**
   * Sets the key.
   *
   * @param key
   *          the new key
   */
  public void setKey(String key)
  {
    this.key = key;
  }

  /**
   * Gets the key.
   *
   * @return the key
   */
  public String getKey()
  {
    return key;
  }

  /**
   * Sets the tipo.
   *
   * @param tipo
   *          the new tipo
   */
  public void setTipo(String tipo)
  {
    this.tipo = tipo;
  }

  /**
   * Gets the tipo.
   *
   * @return the tipo
   */
  public String getTipo()
  {
    return tipo;
  }

  /**
   * Setea un Map de Rectificacion dentro de MapResultado, esto cuando sea solo
   * un elemento a rectificar de la misma tabla.
   *
   * @param mapa
   *          the mapa
   * @param mapResultado
   *          the map resultado
   * @return the map modificado 09-03-2010
   */
  public static Map<String, Object> setearMap(Map<String, Object> mapa, Map<String, Object> mapResultado)
  {
    // verifica si existe el map de nombre codigo de la tabla dentro de
    // mapResultado
    if (mapResultado.get(mapa.get("tabla").toString()) == null)
    {
      // si no existe se agrega los valores de CLAVE
      JsonSerializer serializer = new JsonSerializer();
      Map<String, Object> mapClave = (Map<String, Object>) serializer.deserialize(mapa.get("clave"));

      mapResultado.put(mapa.get("tabla").toString(), new HashMap<String, Object>());
      ((HashMap<String, Object>) mapResultado.get(mapa.get("tabla").toString())).putAll(mapClave);
    }
    // si es null o si existe se agrega los valores de campo e indica
    ((HashMap<String, Object>) mapResultado.get(mapa.get("tabla").toString())).put(mapa.get("campo").toString(), mapa
        .get("valor").toString());
    ((HashMap<String, Object>) mapResultado.get(mapa.get("tabla").toString())).put("indica", mapa.get("indica")
        .toString());
    return mapResultado;
  }


  /**
   * Setea un Map de Rectificacion dentro de un Map de una Lista que contenga
   * los valores de la CLAVE, la lista esta dentro de mapResultado.
   *
   * @param mapa
   *          the mapa
   * @param mapResultado
   *          the map resultado
   * @return modificado el 09-03-2010
   */
  public static Map<String, Object> setearMapList(Map<String, Object> mapa, Map<String, Object> mapResultado)
  {
    boolean bandera = false;
    boolean banderaNuevo = true;
    JsonSerializer serializer = new JsonSerializer();
    Map<String, Object> mapClave = (Map<String, Object>) serializer.deserialize(mapa.get("clave"));
    // existe el codigo de la tabla dentro de mapResultado
    String codTabla = mapa.get("tabla").toString();
    //PAS20155E220200139
    if(codTabla.equals("T0069")){
    	mapClave.remove("NUM_SECFACT"); //POR QUE HAY REGISTROS QUE HAN GRABADO COMO PK EL NUM_SECPROVE Y NUM_SECFACT EN DETSOLRECTI CUANDO NO DEBERIA 
    	mapClave.remove("NUM_SECPROVE");
    }
	//PAS20155E220200139
    if (mapResultado.get(codTabla) == null)
    {
      mapResultado.put(codTabla, new ArrayList<Map<String, Object>>());
      // Es el primer Map. 0
      mapClave.put(mapa.get("campo").toString(), mapa.get("valor"));
      mapClave.put("indica", mapa.get("indica").toString());
      ((ArrayList<Map<String, Object>>) mapResultado.get(codTabla)).add(mapClave);
    }
    else
    {
      banderaNuevo = true;
      // obtenemos la lista con nombre igual al codigo de la tabla
      List<Map<String, Object>> lista = (ArrayList<Map<String, Object>>) mapResultado.get(codTabla);
      // Recorremos Lista obtenida
      for (int i = 0; i < lista.size(); i++)
      {
        Map<String, Object> entrada = lista.get(i);
        bandera = true;
        // Comparamos CLAVE
        for (Entry<String, Object> entradaClave : mapClave.entrySet())
        {
          // obtenemos del i elemento de igual key de entrada con el valor.
          Object valueClave = entrada.get(entradaClave.getKey());
          if (valueClave == null)
          {
            throw new RuntimeException(
                "La clave de la rectificacion no concuerda con la clave proporcionada.  codigo de la tabla: "
                    + codTabla);
          }
          if (entrada.get(entradaClave.getKey()).toString().equals(entradaClave.getValue().toString()))
          {
            bandera = true;
          }
          else
          {
            bandera = false;
            break;
          }
        }
        // Si la Clave coincide se agrega los parametros
        if (bandera)
        {
          if (!(((ArrayList<Map<String, Object>>) mapResultado.get(codTabla)).get(i).get("indica").equals("N")
          && mapa.get("indica").toString().equals("A")))
          {
            ((ArrayList<Map<String, Object>>) mapResultado.get(codTabla)).get(i).put(
                mapa.get("campo").toString(), mapa.get("valor").toString());
            ((ArrayList<Map<String, Object>>) mapResultado.get(codTabla)).get(i).put("indica",
                mapa.get("indica").toString());
            banderaNuevo = false;
          }
        }
      }
      // Si nunca se grabo los datos, se crea un nuevo item dentro de la lista
      if (banderaNuevo)
      {
        mapClave.put(mapa.get("campo").toString(), mapa.get("valor").toString());
        mapClave.put("indica", mapa.get("indica").toString());
        ((ArrayList<Map<String, Object>>) mapResultado.get(codTabla)).add(mapClave);
      }
    }
    return mapResultado;
  }

}
