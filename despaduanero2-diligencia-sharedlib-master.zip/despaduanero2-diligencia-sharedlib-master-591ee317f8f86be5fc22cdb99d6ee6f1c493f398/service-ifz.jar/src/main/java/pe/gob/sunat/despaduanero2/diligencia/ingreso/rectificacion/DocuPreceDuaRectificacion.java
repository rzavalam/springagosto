package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class DocuPreceDuaRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -8832735450459793528L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDocuPreceDua";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private DocuPreceDuaDAO     docuPreceDuaDAO;
  //rtineo mejoras, grabacion en batch
  private DocuPreceDuaBatchDAO docuPreceDuaBatchDAO;

  public DocuPreceDuaRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");
    mapClave.put("NUM_DECLARACIONPRE", "NUM_DECLARACIONPRE");
    mapClave.put("ANN_PRESENPRE", "ANN_PRESENPRE");
    mapClave.put("COD_ADUANAPRE", "COD_ADUANAPRE");
    mapClave.put("COD_REGIMENPRE", "COD_REGIMENPRE");
    mapClave.put("NUM_SECSERIEPRE", "NUM_SECSERIEPRE");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DOCUPRECE_DUA;
  }

  // inicio gmontoya 2012
  /**
   * Meotodo que sirve para grabar la rectificacion
   * 
   * @param numCorredoc_sol
   *          numero correlativo de la solicitud que se guardara en el
   *          det_ofirecti
   * @param mapDatos
   *          datos a grabar para la rectificacion
   * @return
   */
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin
    Map<String, Object> mapDiferenciaGrabar;
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      cont = 0;

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {
        if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 1);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 0);
          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  insertRecordBatch(itemNew);
              }else{
            insertRecord(itemNew);
              }
              //rtineo mejoras, fin
            cont++;
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isWarnEnabled())
            {
              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
            }
            // Si el registro ya existe se activa el registro y se actualiza
            //rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	updateRecordBatch(itemNew);
            }else{
            updateRecord(itemNew);
          }
            //rtineo mejoras, fin
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());

          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, true);
          }
          //rtineo mejoras, fin
          continue;
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {

            if (Comparador.isKeyEqual(itemOld, itemNew, getMapClave()))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, getMapClave());
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")) || "1".equals(itemNew.get("IND_DEL")))
                {
                  mapDiferenciaGrabar.put("IND_DEL", 1);
                  Map<String, Object> declaracion = (HashMap) mapDatos.get("mapCabDeclaraActual");
                  declaracion.put("IND_DOCUPRECEDUA", false);
                }
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	updateRecordBatch(mapDiferenciaGrabar);
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                }else{
                updateRecord(mapDiferenciaGrabar);
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
                }
                //rtineo mejoras, fin
                cont++;
              }
            }
          }
        }
      }
    }
    return cont;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return docuPreceDuaDAO.select(mapParametros);
  }

  public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO)
  {
    this.docuPreceDuaDAO = docuPreceDuaDAO;
  }
  //rtineo mejoras, grabacion en batch
  public DocuPreceDuaBatchDAO getDocuPreceDuaBatchDAO() {
	return docuPreceDuaBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setDocuPreceDuaBatchDAO(DocuPreceDuaBatchDAO docuPreceDuaBatchDAO) {
	this.docuPreceDuaBatchDAO = docuPreceDuaBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    docuPreceDuaDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    docuPreceDuaDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    docuPreceDuaBatchDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  docuPreceDuaBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }
}
