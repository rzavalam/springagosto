package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;//RIN 14
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;//RIN 14
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;//RIN 14
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.HashMapComparator;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.DetalleSolicitudRectifica;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * <p>Clase que rectifica valores de una tabla del proceso de rectificaci�n.</p>
 * @author fjonislla
 *
 */
public abstract class RectificacionAbstract {

  protected static final boolean ACTIVAR_ENCONTRAR_DATOS_NUEVOS    = true;

  private final static String    TIPO_DILIGENCIA                   = "tipoDiligencia";

  private static final String    COD_TIPO_DILIGENCIA_RECTIFICACION = "06";

  protected static final String  INDICADOR_NUEVO_REGISTRO          = "N";

  protected static final String  INDICADOR_ELIMINAR_REGISTRO       = "A";

  protected static final String  COD_TRANSACCION_RECTIFICACION_ELECTRONICA = "1007";

  private RectiOficioDAO         rectiOficioDAO;

  private RectiOficioBatchDAO    rectiOficioBatchDAO;

  private DetSolRectiDAO         detSolRectiDAO;

  protected FabricaDeServicios   fabricaDeServicios                = null;

  protected SequenceDAO          sequenceDAO;

  protected Map<String, Object>  mapClave;

  protected Comparador           comparador                        = new Comparador();

  protected final Log            log                               = LogFactory.getLog(getClass());

  /**
   * <p>
   * Valida que se haya inicializado los nombres de las listas y el mapa que
   * contiene le PK de la tabla a ser rectificada.
   * </p>
   */
  @PostConstruct
  public void validateInitData()
  {
    if (StringUtils.isEmpty(getNombreListaOriginal()))
    {
      new RuntimeException(
          "El nombre de la lista Origanal no debe de ser nula o vacia, y debe de tener el formato (\"lst\"+[nombre de la tabla a rectificar en camel case]");
    }

    if (StringUtils.isEmpty(getNombreListaResultante()))
    {
      new RuntimeException(
          "El nombre de la lista resultante no debe de ser nula o vacia, y debe de tener el formato (\"lst\"+[nombre de la tabla a rectificar en camel case]+\"Actual\"");
    }

    if (StringUtils.isEmpty(getCodTablaRectificacion()))
    {
      new RuntimeException(
          "El codigo de la tabla no debe de ser nula o vacia, y se tiene que obtener de la clase Constantes");
    }
    if (MapUtils.isEmpty(getMapClave()))
    {
      new RuntimeException("La tabla con el PK de la tabla a rectificar debe tener por lo menos un campo");
    }
  }

	/**
	 * <p>Metodo que nos permite obtener los datos Iniciales de la Base de Datos de las tablas involucradas dentro de la
	 * Rectificaci�n.</p>
	 * @param mapResultado Mapa donde se almacenara el resultado de la consulta a la base de  datos
	 * @param mapValores Mapa con los valores necesarios para realizar al b�squeda de los datos actuales de la tabla a ser rectificada, 
	 * es necesario filtrar los par�metros de b�squeda para cada tabla. 
	 * @return
	 */
  protected abstract Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores);

	/**
	 * @param parametros la informacion contenida va a variar dependiendo de las necesidades de la tabla
	 * @return una lista de registros de la tabla asociadas a la dua que esta siendo rectificada
	 */
	protected abstract List<Map<String, Object>> getTablaBD(Map<String, Object> parametros);
	/**
	 *  Metodo que setea los valores de la RECTIFICACION sobre los recogidos de la BD, segun PK.
	 * @param mapInitialData
	 * @return
	 */
  public Map<String, Object> mergeDatosBDRectificacion(
      Map<String, Object> mapInitialData,
      Map<String, Object> mapValores)
  {
    // recuperamos valores actuales de la tabla(en BD) a rectificar
    Map mapResultado = new HashMap<String, Object>(mapInitialData);
    mapResultado = getDatosInicialesRectifacion(new HashMap<String, Object>(mapInitialData), mapValores);

    if (mapResultado.get(getCodTablaRectificacion()) != null)
    {

      List lstDatosOriginales = (List<Map<String, Object>>) mapResultado.get(getNombreListaOriginal());

      List lstDatosNuevos = (List<Map<String, Object>>) mapResultado.get(getCodTablaRectificacion());

      List lstResultante = Comparador.setearValoresListMap(lstDatosOriginales, lstDatosNuevos, getMapClave(),
          ACTIVAR_ENCONTRAR_DATOS_NUEVOS);

      mapResultado.put(getNombreListaResultante(), lstResultante);
    }
    else
    {
      // si no hay nada que rectificar retornamos los datos de la base de datos
      mapResultado.put(getNombreListaResultante(), mapResultado.get(getNombreListaOriginal()));// Si
                                                                                               // no
                                                                                               // existe
                                                                                               // para
      // rectificacion
    }

    return mapResultado;
  }

  /**
   * Meotodo que sirve para grabar la rectificacion
   * 
   * @param numCorredoc_sol
   *          numero correlativo de la solicitud que se guardara en el
   *          det_ofirecti
   * @param mapDatos
   *          datos a grabar para la rectificacion
   * @return
   */
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    int cont = 0;
    //rtineo mejoras
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";

    Map<String, Object> mapDiferenciaGrabar;
    
    //PAS20171U220200005
    ArrayList<Map<String, Object>> mapaData =  mapDatos.get(getNombreListaResultante())!=null?(ArrayList<Map<String, Object>>)  mapDatos.get(getNombreListaResultante()):null;
   // if (mapDatos.get(getNombreListaResultante()) != null)//PAS20171U220200005
    if(mapaData!=null && !mapaData.isEmpty())//PAS20171U220200005
    {
      cont = 0;
      //rtineo mejoras, ordenamos la lista en un hashMap de acuerdo al getMapClave
      Map<String,List<Map<String,Object>>> mapAgrupadoOrignal = new HashMap<String,List<Map<String,Object>>>();
      List<Map<String,Object>> listOriginal =(ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal());
      if(listOriginal != null && listOriginal.size()>0){
    	  for(Map<String,Object> mapOriginal : listOriginal){
    		  if(Comparador.iskeyMapValorInkeyMap(mapOriginal, getMapClave())){
        		  String identificador = Comparador.getIdentificador(mapOriginal, getMapClave());//debe estar compuesto por los valores de getMapClave
        		  List<Map<String,Object>> listGroupOriginal = mapAgrupadoOrignal.get(identificador);
        		  if(listGroupOriginal == null){
        			  listGroupOriginal = new ArrayList<Map<String,Object>>();
        			  mapAgrupadoOrignal.put(identificador, listGroupOriginal);
        		  }
        		  listGroupOriginal.add(mapOriginal);    			  
    		  }
    	  }
      }
      //rtineo fin
      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {
        if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 1);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 0);
          try
          {
        	//rtineo mejoras, grabacion para rectificacion desde web
        	if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        		insertRecordBatch(Utilidades.transformFieldsToRealFormat(itemNew));  
        	}else{
            insertRecord(Utilidades.transformFieldsToRealFormat(itemNew));
        	}
            
            cont++;
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isWarnEnabled())
            {
              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
            }
            // Si el registro ya existe se activa el registro y se actualiza
            //rtineo mejoras, grabacion para rectificacion desde web
        	if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        		updateRecordBatch(Utilidades.transformFieldsToRealFormat(itemNew));
        	}else{
            updateRecord(Utilidades.transformFieldsToRealFormat(itemNew));
          }
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());
                    
          //Inicio Rin14 CUS 06.01 - FCO          
          if (ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(getCodTablaRectificacion()) || ConstantesDataCatalogo.TABLA_DET_AUTORIZACION.equals(getCodTablaRectificacion()) ){
        	  Map<String, Object> mapDataOriginal= new HashMap<String, Object>(itemNew);
          	  MercanciaRestringidaEntidadService mRestriEntidadService = (MercanciaRestringidaEntidadService) fabricaDeServicios.getService("mercanciaRestringidaEntidadService");	       
    	      mRestriEntidadService.actualizarDocAutRectificacion(getCodTablaRectificacion(),mapTmpPK, mapDataOriginal,Constants.IND_REGISTRO_NUEVO);
          }
          //Fin Rin14 CUS 06.01 - FCO          
          
          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, true);
          }
          continue;
        }
        else
        {
          //rtineo mejoras, unicamente se recorre los valores que coinciden con el itemOld
          //for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          for (Map<String, Object> itemOld : (List<Map<String, Object>>) mapAgrupadoOrignal.get(Comparador.getIdentificador(itemNew, getMapClave())))
          {

            if (Comparador.isKeyEqual(itemOld, itemNew, getMapClave()))
            {  //mol por bug
            	if(ConstantesDataCatalogo.TABLA_FACTURA_SERIE.equals(getCodTablaRectificacion())){
            		// mol por bug estos campos no existe en FACTURA_SERIE se blanquea
            		itemOld.put("FEC_FACT","");
            		itemOld.put("NUM_FACT","");
            		itemNew.put("FEC_FACT","");
            		itemNew.put("NUM_FACT","");
            	}
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, getMapClave());
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
                {
                  mapDiferenciaGrabar.put("IND_DEL", 1);
                }
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //Inicio Rin14 CUS 06.01 - FCO 
                //if (itemOld.get("IND_DEL")!=null &&  itemNew.get("IND_DEL")!=null && 
                //		Constants.INDICADOR_NO_ELIMINADO.equals(itemOld.get("IND_DEL")) && Constants.INDICADOR_ELIMINADO.equals(itemNew.get("IND_DEL")))//Pase 399 nullpointer
                //tipoMod = Constants.IND_REGISTRO_ANULADO;
                
                String strModifi = "";
                
                if ((ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(getCodTablaRectificacion()) || 
                		ConstantesDataCatalogo.TABLA_DET_AUTORIZACION.equals(getCodTablaRectificacion())) && 
                		!Constants.INDICADOR_ELIMINADO.equals(itemNew.get("IND_DEL"))){                	
                	//if (tipoMod.equals(Constants.IND_REGISTRO_RECTIFICADO))
                	//	strModifi = Constants.IND_REGISTRO_NUEVO;
                	Map mapClave = (Map)mapDiferenciaGrabar.get("clave");
                	Map<String, Object> mapDataOriginal=(Map<String,Object>)mapDiferenciaGrabar.get("dataOriginal");
                	MercanciaRestringidaEntidadService mRestriEntidadService = (MercanciaRestringidaEntidadService) fabricaDeServicios.getService("mercanciaRestringidaEntidadService");	       
          	      	mRestriEntidadService.actualizarDocAutRectificacion(getCodTablaRectificacion(),mapClave, mapDataOriginal,Constants.IND_REGISTRO_ANULADO);
                }      	  
                //Fin Rin14 CUS 06.01 - FCO                      
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	//updateRecordBatch(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar)); //se comenta PAS20155E220000487
                	//Inicio PAS20155E220000487 - se requiere que cuando es IQBF la actualizaci�n sea inmediata
                	boolean isUpdateBatch = true;
                	
                	if (ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(getCodTablaRectificacion())){
                		if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(itemNew.get("COD_ENTI")) && 
            					Constants.COD_TIPO_DOCAUT_IQBF.equals(itemNew.get("COD_TIPDOCASO")) &&
            					(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(itemNew.get("COD_SUBENTI")) ||
            							Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(itemNew.get("COD_SUBENTI")))){
                			isUpdateBatch = false;
                		}
                	}
                	
                	if(isUpdateBatch){
                	updateRecordBatch(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                }else{
                updateRecord(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                }
                	//Fin PAS20155E220000487 - se requiere que cuando es IQBF la actualizaci�n sea inmediata
                }else{
                	updateRecord(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                }
                //Inicio Rin14 CUS 06.01 - FCO 
                if ((ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(getCodTablaRectificacion()) || 
                		ConstantesDataCatalogo.TABLA_DET_AUTORIZACION.equals(getCodTablaRectificacion()))){                	
                	Map mapClave = (Map)mapDiferenciaGrabar.get("clave");
                	Map<String, Object> mapDataOriginal=(Map<String,Object>)mapDiferenciaGrabar.get("dataOriginal");
                	
                	if (!Constants.INDICADOR_ELIMINADO.equals(itemNew.get("IND_DEL"))) {
                		MercanciaRestringidaEntidadService mRestriEntidadService = (MercanciaRestringidaEntidadService) fabricaDeServicios.getService("mercanciaRestringidaEntidadService");	       
              	      	mRestriEntidadService.actualizarDocAutRectificacion(getCodTablaRectificacion(),mapClave, mapDataOriginal,Constants.IND_REGISTRO_NUEVO);
                	} else{
                		MercanciaRestringidaEntidadService mRestriEntidadService = (MercanciaRestringidaEntidadService) fabricaDeServicios.getService("mercanciaRestringidaEntidadService");	       
              	      	mRestriEntidadService.actualizarDocAutRectificacion(getCodTablaRectificacion(),mapClave, mapDataOriginal,Constants.IND_REGISTRO_ANULADO);
                	}                	
                }  
                //Fin Rin14 CUS 06.01 - FCO  
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                }else{
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
                }
                cont++;
              }
            }
          }
        }
      }
    }
    return cont;
  }

  /*PAS20171U220200031*/
  public int grabarRectificacion2(String numCorredocSol, Map<String, Object> mapDatos,String tipoDiligencia)
  {
	  return 0;
  }
  /**
   * Metodo que sirve para insertar un nuevo registro de acuerdo al DAO de cada
   * tabla a ser modificada
   * 
   * @param newRecordMap
   *          registro con los datos a insertar
   */
  protected abstract void insertRecord(Map<String, Object> newRecordMap);

  /** rtineo, mejoras
   * Metodo que sirve para insertar un nuevo registro de acuerdo al DAO de cada
   * tabla a ser modificada, por Batch
   * 
   * @param newRecordMap
   *          registro con los datos a insertar
   */
  protected abstract void insertRecordBatch(Map<String, Object> newRecordMap);

  /**
   * Metodo que sirve para actualizar un registro de acuerdo al DAO de cada
   * tabla a ser modificada
   * 
   * @param updateRecordMap
   *          registro con los datos a modificar
   */
  protected abstract void updateRecord(Map<String, Object> updateRecordMap);

  /** rtineo mejoras
   * Metodo que sirve para actualizar un registro de acuerdo al DAO de cada
   * tabla a ser modificada
   * 
   * @param updateRecordMap
   *          registro con los datos a modificar
   */
  protected abstract void updateRecordBatch(Map<String, Object> updateRecordMap);
  
  /**
   * <p>
   * Metodo privado para insertar las rectificaciones
   * </p>
   * 
   * @param mapDiferenciaGrabar
   * @param numCorredocSol
   */
  protected void registrarRectiOficio(Map mapDiferenciaGrabar, String numCorredocSol, boolean isNewRecord)
  {
    mapDiferenciaGrabar.put(TIPO_DILIGENCIA, COD_TIPO_DILIGENCIA_RECTIFICACION);
    mapDiferenciaGrabar.put("NUM_SECCAMBIO", sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapDiferenciaGrabar.put("NUM_CORREDOC_SOL", numCorredocSol);
    mapDiferenciaGrabar.put("tabla", getCodTablaRectificacion());
    // eliminar los campos del pk antes de grabar an det_ofirecti
    rectiOficioDAO.insertMapComparadorAll(mapDiferenciaGrabar, isNewRecord);
  }
  
  // PAS20171U220200031
  protected void registrarRectiOficio2(Map mapDiferenciaGrabar, String numCorredocSol, boolean isNewRecord,String tipoDiligencia)
  {
    mapDiferenciaGrabar.put(TIPO_DILIGENCIA, tipoDiligencia);
    mapDiferenciaGrabar.put("NUM_SECCAMBIO", sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapDiferenciaGrabar.put("NUM_CORREDOC_SOL", numCorredocSol);
    mapDiferenciaGrabar.put("tabla", getCodTablaRectificacion());
    // eliminar los campos del pk antes de grabar an det_ofirecti
    rectiOficioDAO.insertMapComparadorAll(mapDiferenciaGrabar, isNewRecord);
  }
//PAS20171U220200031
  /** rtineo mejoras
   * <p>
   * Metodo privado para insertar las rectificaciones
   * </p>
   * 
   * @param mapDiferenciaGrabar
   * @param numCorredocSol
   */
  protected void registrarRectiOficioBatch(Map mapDiferenciaGrabar, String numCorredocSol, boolean isNewRecord)
  {
    mapDiferenciaGrabar.put(TIPO_DILIGENCIA, COD_TIPO_DILIGENCIA_RECTIFICACION);
    //rtineo mejoras, comentado se enviara secuencia en sentencia insert
    //mapDiferenciaGrabar.put("NUM_SECCAMBIO", sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapDiferenciaGrabar.put("NUM_CORREDOC_SOL", numCorredocSol);
    mapDiferenciaGrabar.put("tabla", getCodTablaRectificacion());
    // eliminar los campos del pk antes de grabar an det_ofirecti
    rectiOficioBatchDAO.insertMapComparadorAll(mapDiferenciaGrabar, isNewRecord);
  }
  
  /**
   * Retorna la lista de registros de la tabla en base de datos combinados con
   * los registros de det_solrecti
   * 
   * @param numeroCorrelativoSolicitud
   *          numero correlativo de la solicitud de rectificacion
   * @param numeroCorrelativoDua
   *          numero correlativo de la dua
   * @param mergeRectificado
   *          si es true se hace un merge de lo que se tiene en base de datos
   *          con lo que se tiene en det_solrecti (predomina lo que se optenie
   *          del det_solrecti)
   * @return lista con los datos rectificados combinados con los datos de la
   *         base de datos de la tabla
   */
  public List<Map<String, Object>> getTableRectificadoMergedBD(
      Map<String, Object> parametrosBd,
      Long numeroCorrelativoSolicitud,
      boolean mergeRectificados)
  {
    List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
    Map<String, Object> parametros = new HashMap<String, Object>();
    parametros.put("tabla", getCodTablaRectificacion());
    parametros.put("numeroCorrelativo", numeroCorrelativoSolicitud);
    List<DetalleSolicitudRectifica> listDetSolrectifica = detSolRectiDAO.listByParameterMap(parametros);

    // no procede para cab_declara por tener un tipo de retorno diferente
    List<Map<String, Object>> tablaBD = (List<Map<String, Object>>) getTablaBD(parametrosBd);

    for (Map<String, Object> map : tablaBD)
    {
      // transformamos en json y lo volvemos a convertir en Map para
      // aseguararnos que el json del det_solrecti
      // concuerde con la info optenida de base de datos
      String toJson = SojoUtil.toJson(map);
      Map<String, Object> tableMerged = (Map<String, Object>) SojoUtil.fromJson(toJson);

      for (DetalleSolicitudRectifica detSolRectifica : listDetSolrectifica)
      {
        // si es un nuevo registro no hacer nada
        if (INDICADOR_NUEVO_REGISTRO.equals(detSolRectifica.getTipoRectificacion()))
        {
          continue;
        }
        Map<String, Object> tablaRectiPk = (Map<String, Object>) SojoUtil.fromJson(detSolRectifica
            .getDescripcionClave());
        boolean isModificado = true;
        Iterator iterTablaRectiPk = tablaRectiPk.entrySet().iterator();
        while (iterTablaRectiPk.hasNext())
        {
          Map.Entry entryTablaRectiPk = (Entry) iterTablaRectiPk.next();
          String pkCampo = (String) entryTablaRectiPk.getKey(); // PkCampo del
                                                                // JSON

          Object campoPKValorRecti = entryTablaRectiPk.getValue(); // obtiene
                                                                   // valor del
                                                                   // dato
                                                                   // rectificado
          Object campoPKValorBD = tableMerged.get(pkCampo); // obtiene valor del
                                                            // dato actual de a
                                                            // BD
          // si todos son iguales entonces se encontro un registro en el
          // det_solrecti
          isModificado = isModificado && campoPKValorBD.equals(campoPKValorRecti);
        }
        // si es modificado agregamos el indicador de rectificacion
        if (isModificado && !INDICADOR_NUEVO_REGISTRO.equals(detSolRectifica.getTipoRectificacion()))
        {
          tableMerged.put("IND_RECTIFICA", detSolRectifica.getTipoRectificacion());
          // si se indica que se haga el merge de datos y el registro no es
          // eliminado hacemos el merge de datos
          if (mergeRectificados && !INDICADOR_ELIMINAR_REGISTRO.equals(detSolRectifica.getTipoRectificacion()))
          {
            String descripcionData = detSolRectifica.getDescripcionData1() + detSolRectifica.getDescripcionData2();
            try
            {
              Map<String, Object> tablaRectiData = (Map<String, Object>) SojoUtil.fromJson(descripcionData);
              tableMerged.putAll(tablaRectiData);
            }
            catch (Exception e)
            {
              // no hacemos nada
              if (log.isDebugEnabled())
              {
                log.debug("Ocurrio un error durante el merge de la tabla: " + getCodTablaRectificacion()
                    + " Metodo: getTableRectificadoMergedBD()");
              }

            }
          }
        }
      }
      result.add(tableMerged);
    }
    for (DetalleSolicitudRectifica detSolRectifica : listDetSolrectifica)
    {
      if (INDICADOR_NUEVO_REGISTRO.equals(detSolRectifica.getTipoRectificacion()))
      {
        Map<String, Object> tablaRectiPk = new HashMap<String, Object>();
        Map<String, Object> tablaRectiData = new HashMap<String, Object>();
        try
        {
          tablaRectiPk = (Map<String, Object>) SojoUtil.fromJson(detSolRectifica.getDescripcionClave());
        }
        catch (Exception e)
        {
          log.debug(e);
        }
        try
        {
          tablaRectiData = (Map<String, Object>) SojoUtil.fromJson(detSolRectifica.getDescripcionData1()
              + detSolRectifica.getDescripcionData2());
        }
        catch (Exception e)
        {
          log.debug(e);
        }

        tablaRectiPk.putAll(tablaRectiData);
        tablaRectiPk.put("IND_RECTIFICA", detSolRectifica.getTipoRectificacion());
        result.add(tablaRectiPk);
      }

    }

    return result;
  }

  /**
   * Busca un mapa dentro de una lista de mapas, los criterios de busqueda se
   * encuentran en el mapa primary
   * 
   * @param listOfMaps
   *          lista donde se realizara la busqueda
   * @param mapQueryParam
   *          mapa con la lista de parametros por el cual se realizara la
   *          busqueda (clave, valor)
   * @return
   */
  protected Map<String, Object> findInListMapByMapParam(
      List<Map<String, Object>> listOfMaps,
      final Map<String, Object> mapQueryParam)
  {
    Map<String, Object> resultFound = (Map<String, Object>) CollectionUtils.find(listOfMaps, new Predicate()
    {

      @Override
      public boolean evaluate(Object elmentAsObject)
      {
        Map<String, Object> elementAsMap = (Map<String, Object>) elmentAsObject;
        boolean isIgual = true;
        Iterator itQueryParam = mapQueryParam.entrySet().iterator();
        while (itQueryParam.hasNext())
        {
          Map.Entry entryQueryParam = (Entry) itQueryParam.next();
          String pkCampo = (String) entryQueryParam.getKey();
          String campoValorRecti = ObjectUtils.toString(entryQueryParam.getValue());
          String campoValorBD = ObjectUtils.toString(elementAsMap.get(pkCampo), "");
          isIgual = isIgual && campoValorBD.equals(campoValorRecti);
        }

        return isIgual;
      }
    });
    return resultFound;
  }

  /**
   * Retorna la lista de registros de la tabla combinados con los registros de
   * det_solrecti si es nuevo se inserta el nuevo registro, si es rectificado o
   * anulado solo se pone el indicador de anulado o rectificado
   * 
   * @param numeroCorrelativoSolicitud
   *          numero correlativo de la solicitud de rectificacion
   * @param numeroCorrelativoDua
   *          numero correlativo de la dua
   * @return lista con los datos rectificados combinados con los datos de la
   *         base de datos de la tabla
   */
  public List<Map<String, Object>> getTableRectificadoMergedBD(
      Map<String, Object> parametrosBd,
      Long numeroCorrelativoSolicitud)
  {

    return getTableRectificadoMergedBD(parametrosBd, numeroCorrelativoSolicitud, false);
  }

  /**
   * Setea un Map de Rectificacion dentro de MapResultado, esto cuando sea solo
   * un elemento a rectificar de la misma tabla.
   * 
   * @param mapa
   * @param mapResultado
   * @return
   * 
   *         modificado 09-03-2010
   */

  protected Map<String, Object> setearMap(Map<String, Object> mapa, Map<String, Object> mapResultado)
  {
    return HashMapComparator.setearMap(mapa, mapResultado);
  }

  /**
   * Setea un Map de Rectificacion dentro de un Map de una Lista que contenga
   * los valores de la CLAVE, la lista esta dentro de mapResultado.
   * 
   * @param mapa
   * @param mapResultado
   * @return modificado el 09-03-2010
   */
  public Map<String, Object> setearMapList(Map<String, Object> mapa, Map<String, Object> mapResultado)
  {

    return HashMapComparator.setearMapList(mapa, mapResultado);
  }

  /**
   * <p>
   * Nombre de la lista que contiene la data extra�da de la base de datos de la
   * tabla a ser rectificada.
   * </p>
   * 
   * @return
   */
  protected abstract String getNombreListaOriginal();

  /**
   * <p>
   * Nombre de la lista resultante luego de realizar el merge con los datos de
   * la base de datos con los obtenidos de la rectificaci�n.
   * </p>
   * 
   * @return
   */
  protected abstract String getNombreListaResultante();

  /**
   * <p>
   * C�digo de la tabla a ser rectificada obtenida de la clase constantes.
   * </p>
   * 
   * @return
   */
  protected abstract String getCodTablaRectificacion();

  /**
   * <p>
   * Mapa con los campos clave de la tabla a rectificar
   * </p>
   * 
   * @return
   */
  public Map<String, Object> getMapClave()
  {
    return mapClave;
  }

  public void setMapClave(Map<String, Object> mapClave)
  {
    this.mapClave = mapClave;
  }

  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {
    this.rectiOficioDAO = rectiOficioDAO;
  }

  public void setSequenceDAO(SequenceDAO sequenceDAO)
  {
    this.sequenceDAO = sequenceDAO;
  }

  public void setDetSolRectiDAO(DetSolRectiDAO detSolRectiDAO)
  {
    this.detSolRectiDAO = detSolRectiDAO;
  }

  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }
  public RectiOficioBatchDAO getRectiOficioBatchDAO() {
	return rectiOficioBatchDAO;
  }

  public void setRectiOficioBatchDAO(RectiOficioBatchDAO rectiOficioBatchDAO) {
	this.rectiOficioBatchDAO = rectiOficioBatchDAO;
  }
}
