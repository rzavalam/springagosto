package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.model.Spr;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * <p>Title: SubsanacionZonaPrimariaService</p>
 * <p>Description: Interface de Servicio para la Subsanacion de Observacion ZPAE</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public interface SubsanacionZonaPrimariaService {

	/**
	 * Valida la declaracion para el proceso 
	 * de subsanacion de ZPAE
	 * @param aduanaDeclaracion Aduana de la declaracion
	 * @param anioDeclaracion A�o de la declaracion
	 * @param regimenDeclaracion R�gimen de la declaracion
	 * @param numeroDeclaracion N�mero de la declaracion
	 * @param usuario Usuario logeado
	 * @return Error de validaci�n
	 * @author gbecerrav
	 */
	public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, Integer anioDeclaracion, 
			String regimenDeclaracion, Integer numeroDeclaracion, UsuarioBean usuario) throws ServiceException;
	
	/**
	 * Adiciona datos a la declaracion
	 * @param dua Declaracion
	 * @author 
	 */
	public void adicionarDatosDeclaracion(DUA dua) throws ServiceException;
	
	/**
	 * Obtener establecimientos de la declaracion 
	 * @param dua Declaracion
	 * @return lista de establecimientos
	 * @author 
	 */
	public Spr obtenerEstablecimiento(DUA dua) throws ServiceException;
	
	/**
	 * Registra subsanacion de observacion ZPAE 
	 * @param solicitudSubsanacion Solicitud Subsanacion
	 * @param dua Declaracion
	 * @author 
	 */
	public void grabarSubsnacionObsZPAE(SolicitudSubsanacion solicitudSubsanacion, DUA dua) throws ServiceException;
	
	/**
	 * Consulta de subsanacion de observacion ZPAE 
	 * @param params Par�metros de b�squeda
	 * @return lista de solicitudes de subsanacion
	 * @author gbecerrav
 	 */
	public List<SolicitudSubsanacion> consultarSubsanacionObsZPAE(Map<String, Object> params) throws ServiceException;
	
}
