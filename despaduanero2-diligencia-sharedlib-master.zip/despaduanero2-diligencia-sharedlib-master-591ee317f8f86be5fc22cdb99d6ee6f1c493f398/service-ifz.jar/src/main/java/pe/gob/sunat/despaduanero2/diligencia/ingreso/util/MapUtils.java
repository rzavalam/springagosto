package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.util.Map;


public final class MapUtils
{ 
  private static final String VALOR_VACIO_DEFECTO = "";
  
  private MapUtils()
  {
    //no se debe inicializar, es utilitario estatico
  }

  /**
   * Compara si el mapa enviado es nulo o vacio
   * @param mapa  : mapa a verificar
   * @return      : true si es nulo o vacio, caso contrario false.
   */
  public static boolean esMapaNuloOVacio(Map<?, ?> mapa)
  {
    return esMapaNulo(mapa) || mapa.isEmpty();
  }
  /**
   * Verificar si el mapa enviado es nulo
   * @param mapa  : mapa a verificar
   * @return      : true si es nulo, caso contrario false
   */
  public static boolean esMapaNulo(Map<?, ?> mapa)
  {
    return mapa == null;
  }
  /**
   * verificar si el valor enviado como parametro se encuentra en el mapa
   * @param mapa      : mapa donde se buscara el valor del parametro
   * @param claveMapa : parametro a buscar
   * @return  true si el valor del mapa es nulo o vacio, caso contrario false.
   */
  public static boolean esValorMapaNuloOVacio(Map<?, ?> mapa, String claveMapa){
    if(esMapaNulo(mapa)) return true;
    return esValorMapaNulo(mapa, claveMapa) || esValorMapaVacio(mapa, claveMapa);
  }
  /**
   * verifica si el valor del mapa encontrado es vacio.
   * @param mapa    : mapa donde se buscara el valor
   * @param claveMapa : parametro a buscar
   * @return true si el valor del mapa es vacio, caso contrario false.
   */
  public static boolean esValorMapaVacio(Map<?, ?> mapa, String claveMapa)
  {
    return (mapa.get(claveMapa).toString()).trim().isEmpty();
  }

  /**
   * verifica si el valor del parametro enviado para el mapa es nulo
   * @param mapa  : mapa a verificar
   * @param claveMapa : parametro a buscar
   * @return true si es nulo, caso contrario false.
   */
  public static boolean esValorMapaNulo(Map<?, ?> mapa, String claveMapa){
    return mapa.get(claveMapa) == null;
  }
  /**
   * busca el valor de claveMapa en el mapa
   * @param mapa  : mapa donde se buscara
   * @param claveMapa : parametro a buscar en el mapa
   * @return el valor del parametro en el mapa, de no encontrarse devuelve una cadena vacia.
   */
  public static String getMapValor(Map<?, ?> mapa, String claveMapa){
    return getMapValor(mapa, claveMapa, VALOR_VACIO_DEFECTO);
  }
  /**
   * busca el valor de claveMapa en el mapa verificando que no sea nulo
   * @param mapa  : mapa donde se buscara
   * @param claveMapa : parametro a buscar en el mapa
   * @param valorDefecto  : valor por defecto que retorna en caso de ser nulo
   * @return el valor del parametro en el mapa, de no encontrarse devuelve el valor por defecto.
   */
  public static String getMapValor(Map<?, ?> mapa, String claveMapa, String valorDefecto){
    if(esMapaNulo(mapa) || esValorMapaNulo(mapa, claveMapa)){
      return valorDefecto;
    }
    return getValor(mapa, claveMapa);    
  }
  /**
   * devuelve el valor de un parametro en el mapa
   * @param mapa  : mapa donde buscar
   * @param claveMapa : parametro a buscar
   * @return valor del parametro que se encuentra en el mapa
   */
  private static String getValor(Map<?, ?> mapa, String claveMapa){
    return mapa.get(claveMapa).toString();
  }

}
