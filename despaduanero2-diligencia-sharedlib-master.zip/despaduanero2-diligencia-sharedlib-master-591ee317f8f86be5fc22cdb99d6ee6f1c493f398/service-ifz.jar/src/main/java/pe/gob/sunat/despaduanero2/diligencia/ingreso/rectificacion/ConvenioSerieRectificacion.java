package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class ConvenioSerieRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID                     = -8624567227770819218L;

  private static final String NOMBRE_LISTA_ORIGINAL                = "lstConvenioSerie";

  private static final String NOMBRE_LISTA_RESULTANTE              = NOMBRE_LISTA_ORIGINAL + "Actual";

  private static final String NOMBRE_LISTA_DET_DECLARA_ORIGINAL    = "lstDetDeclara";

  private static final String NOMBRE_LISTA_DET_DECLARA__RESULTANTE = NOMBRE_LISTA_DET_DECLARA_ORIGINAL + "Actual";

  private ConvenioSerieDAO    convenioSerieDAO;

  //rtineo mejoras, grabacion en batch
  private ConvenioSerieBatchDAO convenioSerieBatchDAO;

  public ConvenioSerieRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");
    mapClave.put("COD_TIPCONVENIO", "COD_TIPCONVENIO");
    mapClave.put("COD_CONVENIO", "COD_CONVENIO");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_CONVENIO_SERIE;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return convenioSerieDAO.select(mapParametros);
  }

  public void setConvenioSerieDAO(ConvenioSerieDAO convenioSerieDAO)
  {
    this.convenioSerieDAO = convenioSerieDAO;
  }

  //rtineo mejoras, grabacion en batch
  public ConvenioSerieBatchDAO getConvenioSerieBatchDAO() {
	return convenioSerieBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setConvenioSerieBatchDAO(ConvenioSerieBatchDAO convenioSerieBatchDAO) {
	this.convenioSerieBatchDAO = convenioSerieBatchDAO;
  }
  
  /**
   * Metodo que setea los valores de la RECTIFICACION sobre los recogidos de la
   * BD, segun PK.
   * 
   * @param mapInitialData
   * @return
   */
  @Override
  public Map<String, Object> mergeDatosBDRectificacion(
      Map<String, Object> mapInitialData,
      Map<String, Object> mapValores)
  {
    // recuperamos valores actuales de la tabla(en BD) a rectificar
    Map mapResultado = new HashMap<String, Object>(mapInitialData);
    mapResultado = getDatosInicialesRectifacion(new HashMap<String, Object>(mapInitialData), mapValores);

    List<Map<String, Object>> lstConvenioSerieMerged = (List<Map<String, Object>>) mapResultado
        .get(getNombreListaOriginal());

    if (mapResultado.get(getCodTablaRectificacion()) != null)
    {

      List lstDatosOriginales = (List<Map<String, Object>>) mapResultado.get(getNombreListaOriginal());

      List lstDatosNuevos = (List<Map<String, Object>>) mapResultado.get(getCodTablaRectificacion());

      lstConvenioSerieMerged = Comparador.setearValoresListMap(lstDatosOriginales, lstDatosNuevos, getMapClave(),
          ACTIVAR_ENCONTRAR_DATOS_NUEVOS);
    }

    mapResultado.put(getNombreListaResultante(), lstConvenioSerieMerged);
    // agregamos los convenios a sus respectivas series
    addConvenioToSerie((List<Map<String, Object>>) mapResultado.get(NOMBRE_LISTA_DET_DECLARA__RESULTANTE),
        lstConvenioSerieMerged);

    return mapResultado;
  }

  /**
   * Metodo que agrega las convenios a las series. esta lista de convenniuos
   * dentro de las series servir� para la liquidacion. El nombre de la lsita de
   * convenios de la serie tendr� que ser:"lstDetDeclara"
   * 
   * @param lstSeries
   *          lista de series de la dua
   * @param lstConvenioSerieMerged
   *          lista de convenios qeu la dua
   */
  private void addConvenioToSerie(List<Map<String, Object>> lstSeries, List<Map<String, Object>> lstConvenioSerieMerged)
  {

    // si la lista de convenios se encuentra vacia salimos
    if (CollectionUtils.isEmpty(lstConvenioSerieMerged))
    {
      return;
    }
    // ordenamos la lista de convenios
    Collections.sort(lstConvenioSerieMerged, new Comparator<Map<String, Object>>()
    {
      @Override
      public int compare(Map<String, Object> o1, Map<String, Object> o2)
      {
        return Integer.parseInt(o1.get("NUM_SECSERIE").toString()) == Integer.parseInt(o2.get("NUM_SECSERIE").toString()) ? 0 :
        	(Integer.parseInt(o1.get("NUM_SECSERIE").toString()) > Integer.parseInt(o2.get("NUM_SECSERIE").toString()) ? 1 : -1);
      }
    });

    Map<String, Object> convenioSerie = lstConvenioSerieMerged.get(0);
    String numeroSerie = ObjectUtils.toString(convenioSerie.get("NUM_SECSERIE"), "0");
    List<Map> lstConvenioSerie = new ArrayList<Map>();
    // recorremos la lista de convenios
    for (Map itemConvenioSerie : lstConvenioSerieMerged)
    {
      if (numeroSerie.equals(ObjectUtils.toString(itemConvenioSerie.get("NUM_SECSERIE"))))
      {
        // si estamos en la misma serie llenamos el arraylist
        lstConvenioSerie.add(itemConvenioSerie);
//        numeroSerie = String.valueOf(Integer.parseInt(numeroSerie)+1); //gmontoya P29
      }
      else
      {
        // agrego la lista de convenios a la serie
        addConvenioToSerie(lstSeries, convenioSerie, lstConvenioSerie);

        // cambiamos de serie
        numeroSerie = ObjectUtils.toString(itemConvenioSerie.get("NUM_SECSERIE"), "0");
        convenioSerie = itemConvenioSerie;

        // creamos un nuevo arraylist y lo llenams con el convenio serie
        lstConvenioSerie = new ArrayList<Map>();
        lstConvenioSerie.add(itemConvenioSerie);
      }
    }

    // Repetimos para el ultimo registros de convenio serie
    addConvenioToSerie(lstSeries, convenioSerie, lstConvenioSerie);

  }

  /**
   * A�ade un lista de convenio ana serie de la lista
   * 
   * @param lstSeries
   *          lista de series de la dua
   * @param convenioSerie
   *          convenio serie actual
   * @param lstConvenioSerie
   *          lista de convenios
   */
  private void addConvenioToSerie(
      List<Map<String, Object>> lstSeries,
      Map<String, Object> convenioSerie,
      List<Map> lstConvenioSerie)
  {
    // de lo contrario
    // buscamos la serie
//    int idxSerie = Collections.binarySearch(lstSeries, convenioSerie, new Comparator<Map>()
//    {
//
//      @Override
//      public int compare(Map serie, Map convenioSerie)
//      {
//        return ObjectUtils.toString(serie.get("NUM_SECSERIE")).compareTo(
//            ObjectUtils.toString(convenioSerie.get("NUM_SECSERIE")));
//      }
//    });
    // y le agregamos la lista de convenios si la serie existe
//    if (idxSerie >= 0)
//    {
//      lstSeries.get(idxSerie).put(NOMBRE_LISTA_ORIGINAL, lstConvenioSerie);
//    }
	  
	  // se comento el anterior porque no funciona bien el  Collections.binarySearch
	  //cambio por SAU
	  Map<String, Object> mapKey = new HashMap<String, Object>();
	  mapKey.put("NUM_SECSERIE", convenioSerie.get("NUM_SECSERIE"));
	  Map<String, Object> mapSerie = Utilidades.obtenerElemento(lstSeries, mapKey);
	 	  
	  if (mapSerie!=null && !CollectionUtils.isEmpty(mapSerie)){
		  mapSerie.put(NOMBRE_LISTA_ORIGINAL, lstConvenioSerie);
    }
	  
  }

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
	Map<String, Object> mapDiferenciaGrabar;//adicionado pase399
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    boolean esNuevo = true; //pase 16 mordonezl
    //rtineo mejoras, fin 
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      int cont = 0;
      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {

        if (log.isDebugEnabled())
        {
          cont++;
          log.debug(cont + " CONVENIO_SERIE :" + itemNew);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {   //mordonezl pase 16 - inicio
        	Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, mapClave);        	 
            Map<String, Object> mapClave1 = new HashMap<String, Object>();
            mapClave1.put("NUM_CORREDOC", "NUM_CORREDOC");
            mapClave1.put("NUM_SECSERIE", "NUM_SECSERIE");
            mapClave1.put("COD_TIPCONVENIO", "COD_TIPCONVENIO"); 
            //cuando se modifica una de las PK de convenio serie es una rectificacion ya que existe en BD  
            for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
            {  
             if (Comparador.isKeyEqual(itemOld, itemNew, mapClave1))
               {      	  
	         	for (Entry<String, Object> entradaClave : mapClave.entrySet())
	      		{ 
	      			String valor = mapTmpPK.get(entradaClave.getKey()) == null ? "" : mapTmpPK
	      					.get(entradaClave.getKey())
	      					.toString()
	      					.trim();
	      			if (!(ObjectUtils.toString(itemOld.get(entradaClave.getKey())).trim().equals(valor)))
	      			{   
         	        		  mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave1);
	      	                  if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
	      	                      && Comparador.esDataCambiada(mapDiferenciaGrabar))
	      	                  {     esNuevo=false;
			      	                Map<String, Object> clave =  (Map<String, Object>) mapDiferenciaGrabar.get("clave");
			      	                clave.put("COD_CONVENIO", itemOld.get(entradaClave.getKey()));
	      	                	    if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
	      	                        	convenioSerieBatchDAO.update2(Utilidades.transformFieldsToRealFormat(itemNew));
	      	                            registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
	      	                        }else{
	      	                        convenioSerieDAO.update2(Utilidades.transformFieldsToRealFormat(itemNew));
	      	                        registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
	      	                        }
	      	                  }
	      	   
	      			}
	      		  } 
                }
            }
          //mordonezl pase 16 - fin
         if(esNuevo)  { 
          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  convenioSerieBatchDAO.insertMapSelectiveDBFormat(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            convenioSerieDAO.insertMapSelectiveDBFormat(Utilidades.transformFieldsToRealFormat(itemNew));
          }
              //rtineo mejoras, fin
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isInfoEnabled())
            {
              log.info("el convenio ya existe se procede a guardarlo con IND_DEL=0");
            }
            itemNew.put("IND_DEL", 0);
            //rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	convenioSerieBatchDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
            }else{
            convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
          }
            //rtineo mejoras, fin
          }
// se subio arriba
   //       Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, mapClave);

          itemNew.put("dataOriginal", mapTmpPK);
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, true);
          }
          //rtineo mejoras, fin
        }  
        }
        else
        {

          /*convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
          registrarRectiOficio(itemNew, numCorredocSol, false);*/
          /**Inicio de cambios del pase399*/
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {

            if (Comparador.isKeyEqual(itemOld, itemNew, mapClave))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
                {
                  mapDiferenciaGrabar.put("IND_DEL", 1);
                }
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	convenioSerieBatchDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                }else{
                convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
                }
                //rtineo mejoras, fin
                cont++;
              }
            }
          }  
          /**Fin de cambios del pase399*/ 
        }
      }
    }
    return 0;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // TODO Auto-generated method stub

  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // TODO Auto-generated method stub
  }
//rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // TODO Auto-generated method stub
  }
}
