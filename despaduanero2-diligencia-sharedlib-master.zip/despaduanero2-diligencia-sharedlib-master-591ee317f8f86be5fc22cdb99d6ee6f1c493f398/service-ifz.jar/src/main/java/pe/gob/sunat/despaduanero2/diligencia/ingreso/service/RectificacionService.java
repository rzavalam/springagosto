package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;//P34
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * Provee los servicios para las Rectificaciones y regularizaciones de la DUA.
 */
public interface RectificacionService
{

  /**
   *  Metodo que nos permite obtener los datos rectificados y regularizados por DUA.
   *
   * @param params
   *          paramsc<String, Object> mapTablas Mapa de las tablas con los valores historicos
   * @return the map retorna los valores rectificados de la forma Valor rectificado, valor Historico
   */
  public Map<String, Object> obtenerDatosRectificados(Map<String, Object> params);

  /**
   * Metodo: que nos permite obtener los datos anulados o agregados en cualquier
   * proceso de la DUA: Rectificaciones automaticas, diligencias Grabados en
   * det_solrecti y det_ofirecti
   *
   * Invocado: Consulta de la DUA.
   *
   * @param numCorreDoc
   *          correlativo de la dua
   * @param codTabla
   *          catalogo
   * @return Map<String, Object> retorna los valores modificados de la forma
   *         [PK,ESTADO,PROCESO,FECHAHORA,USUARIO]
   * @throws ServiceException
   *           the service exception
   * @autor: amancillaa
   */
  public List<Map<String, Object>> obtenerDatosAnuladosOAdicionados(String numCorreDoc, String codTabla)
    throws ServiceException;

  /**
   * verifica si la dua tiene una Rectificacion o regularizacion automatica.
   *
   * @param numCorreDocDua
   *          the num corre doc dua
   * @param tipoSolicitud
   *          the tipo solicitud
   * @return true
   */
  public boolean rectificacionTieneResultado(String numCorreDocDua, String tipoSolicitud);


    /**
     * Completa la informacion Bean
     * datos cambiados
     *
     */
    public List<DatoModificadoBean> obtenerDatosModificadosPorElUsuario(Map<String, Object> mapR,
            Map<String, Object> mapH, String tabla,
            Map<String, Object> mapKey);



    /**
     * Completa la informacion Bean
     * datos cambiados
     *
     */
    public List<DatoModificadoBean> obtenerDatosModificadosTmpOfiRecti(Map<String, Object> mapR,
            Map<String, Object> mapH, String tabla,
            Map<String, Object> mapKey) throws ServiceException;


    /**
     * Metodo: que nos permite obtener los datos modificados en cualquier tipo
     * diligencia y grabados en detOfiRecti.
     *
     *
     * Invocado: Consulta de la DUA.
     *
     * @autor: amancillaa
     *
     * @param numCorreDoc
     * @return Map<String, Object> retorna los valores modificados de la forma
     *         object = Lista[Valor rectificado, valor Historico,Tipo
     *         Diligencia,FechaHora, UsuarioRegis]
     */
    public Map<String, Object> obtenerDatosModificadosEnDiligencias(String numCorreDoc) throws ServiceException;

    //INICIO JAZB P34
    /**
     * Obtiene la lista de Solicitud de Rectificacion
     *
     * @param Mapa
     * 
     * @return lista de Solicitud de Rectificacion
     */
    public List<SolicitudRectifica> obtenerListaSolicitudRectificacion(Map<String, Object> params);
    //FIN JAZB
    //P32 amancilla
    
    /**
     * amancilla 
     * 
     * @param numCorreDocDUA
     * @param numCorreDocSOL
     * @return
     * @throws ServiceException
     */
    public List<Map<String, Object>> obtenerDatosRectificadosVsModificadosXEspecialista(Long numCorreDocDUA, Long numCorreDocSOL) throws ServiceException;

    /**
     * @author EHUMAREDA rin 10 3006
     * Metodo para afectar cuenta corriente  el cual ejecuta  un store procedure.
     * */
	public String afectarCtaCteGarantia(Map<String, Object> mapParam) throws ServiceException;
	
	/**
	 * author eruestaa rin 10 3006
	 * @param mapParam
	 * @return String con el numero de documento del agente desde la tabla participante 

	 * @throws ServiceException
	 */
	public List<Map<String, Object>> obtenerDatosParticipanteByParam(Map<String, Object> mapParam)
			throws ServiceException;
}
