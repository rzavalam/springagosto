package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TabLibe;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NandTasa;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;



/**
 * The Interface SoporteService
 * expone los servicio que involucran tablas del ASIGAD ,INFORMIX.
 *
 * @author rmontes
 */
@SuppressWarnings({ "rawtypes" })
public interface SoporteService
{

  /**
   * Permite obtener los boletines quimicos de una DUA.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerBoletinQuimico(Map<String, Object> params) throws ServiceException;

  /**
   * Permite obtener los datos de documento, nombre direccion y telefono de
   * una persona natural/juridica. "codigo","nombre","direccion","telefono"
   *
   * @param tipoDocumento
   *          the tip_doc
   * @param numDocumento
   *          the num_doc
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerPerNatJur(String tipoDocumento, String numDocumento) throws ServiceException;

  /**
   * Valida el documento pendiente de pago.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> validarDocPendPago(Map params) throws ServiceException;

  /**
   * Validar lc pend pago.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> validarLCPendPago(Map<String, Object> params) throws ServiceException;

  /**
   * Valida una Orden de Deposito Pendiente de pago.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> validarOrdeDepoPendPago(Map params) throws ServiceException;

  /**
   * Metodo que busca los boletines quimicos sin concluir.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerBolQuimicoSinConcluir(Map<String, Object> params) throws ServiceException;

  /**
   * Metodo que busca documentos pendientes de cancelar.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerActasSinConcluir(Map<String, Object> params) throws ServiceException;

  /**
   * Metodo que obtiene la lista de documentos de transporte mediante filtros
   * dinamicos.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List listarDocuTrans(Map params) throws ServiceException;

  /**
   * Metodo que permite obtener los documentos de Expedientes, Liquidaciones,
   * Boletin Quimico y Actas.
   *
   * @param pkDeclaracion
   *          the pk decla
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerDocRef(Map pkDeclaracion) throws ServiceException;
  //inicio PASE176
  /**
   * Metodo que permite obtener las Liquidaciones de Cobranza,
   * Boletin Quimico y Actas.
   *
   * @param pkDeclaracion
   *          the pk decla
   * @return the list
   * @throws ServiceException
   *           the service exception
   */

  public List<Map<String, Object>> obtenerLiquidacionesCobranza(Map PkDecla ) throws ServiceException;
  public List<Map<String, Object>> obtenerLiquidacionesCobranzaGarantizadosSinGarantizar(String annPresenAfecta,List<Map<String, Object>> listaLiquidacionesCobranza,List<Map<String, Object>> listaDeudaGarantia159,List<Map<String, Object>> listaDeudaGaranatia160 ) throws ServiceException;
  //fin PASE176

  /**
   * Si la unidad fca es KG entonces la unidad fca debe ser igual a peso neto
   * CNT_UNIFIS <> CNT_PESO_NETO Si la unidad fca es KG3 entonces la unidad fca
   * debe ser igual a peso neto ROUND(CNT_PESO_NETO/1000.000,3) Si la unidad fca
   * es KG6 entonces la unidad fca debe ser igual a peso neto
   * ROUND(CNT_PESO_NETO/millon,3)
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validaUnidadMedidaFisicas(Map<String, Object> params) throws ServiceException;


  /**
   * Obtener tasa nandina by partida.
   *
   * @param codAduanaSwapper
   *          [String] cod aduana swapper
   * @param numPartNandi
   *          [Long] num part nandi
   * @param fechaVigencia
   *          [Date] fecha vigencia
   * @return [NandTasa] nand tasa
   *
   * @author amancillaa
   * @version 1.0
   */
  public NandTasa obtenerTasaNandinaByPartida(String codAduanaSwapper,
                                              Long numPartNandi,
                                              Date fechaVigencia);

/*RIN13FSW-INICIO*/
  public NandTasa obtenerTasaNandinaByPartida(String codAduanaSwapper,
          Long numPartNandi,
          Date fechaVigencia, String tnan);
  /*RIN13FSW-FIN*/
  /**
   * Permite obtener la Tasa Nandina segun su partida..
   *
   * @param params
   *          the params
   * @return the nand tasa
   * @throws ServiceException
   *           the service exception
   */
  @Deprecated
  public NandTasa obtenerTasaNandinaByPartida(Map<String, Object> params) throws ServiceException;

  /**
   * Existe partida nandina.
   *
   * @param params
   *          the params
   * @return the int
   * @throws ServiceException
   *           the service exception
   */
  public int existePartidaNandina(Map<String, Object> params) throws ServiceException;

  /**
   * Obtener tab libe by params.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<TabLibe> obtenerTabLibeByParams(Map<String, Object> params) throws ServiceException;



  /**
   * Metodo para obtener los Expedientes asociados.
   *
   * @param pkDeclaracion
   *          the pk decla
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Expedi> obtenerExpedi(Map<String, Object> pkDeclaracion) throws ServiceException;

  /**
   * Validar expediente.
   *
   * @param params
   *          the params
   */
  public void validarExpediente(Map<String, Object> params);

  /**
   * Validacion para las acciones de Control Extraordinario ?Mercancia cuenta
   * con Acta de Inmovilizacion ?Mercancia cuenta con Acta de Incautacion
   * ?Mercancia cuenta con Aviso de Inspeccion
   *
   * @param parametros
   *          the parametros
   * @return the map
   */
  public Map<String, Object> obtenerAccionesDeControlExtraordinario(Map<String, Object> parametros);

  /**
   * Obtener sgte dia util.
   *
   * @param pkDeclaracion
   *          the pk decla
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String obtenerSgteDiaUtil(Map<String, Object> pkDeclaracion) throws ServiceException;

  /**
   * Gets the min date from list.
   *
   * @param lst
   *          the lst
   * @param field
   *          the field
   * @return the min date from list
   */
  public Date getMinDateFromList(List<Map<String, Object>> lst, String field);

  /**
   * Verifica que la dua tenga expediente de sustento de rectificacion.
   *
   * @param pkDecla
   *          mapa con los parametros de entrada, parametros obligatorios:
   *          COD_ADUANA -> codigo de la aduana de la dua COD_REGIMEN -> regimen
   *          de la dua segun los codigos de expedi ANN_PRESEN -> a�o de
   *          presentacion de la dua NUM_DECLARACION -> numero de la declaracion
   * @return true, if successful
   */
  public boolean tieneExpedienteSustentoRectificacion(Map<String, Object> pkDecla);

  /**
   * Obtener acciones de control extraordinario2.
   *
   * @param parametros
   *          the parametros
   * @return the map
   */
  public Map<String, Object> obtenerAccionesDeControlExtraordinario2(Map<String, Object> parametros);

  /**
   * Completa los datos del participante con respecto a razon social y direccion
   * del padron ruc y reniec.
   *
   * @param participante
   *          the participante
   * @return the participante
   */
  public Participante completarParticipante(Participante participante);

  /**
   * Obtener lst tasa nan.
   *
   * @param cnan
   *          [String] cnan
   * @param fechavigencia
   *          [String] fechavigencia
   * @return [List] list
   * @version 1.0
   */
  public List obtenerLstTasaNAN(String cnan, String fechavigencia);
/**INICIO-RIN13**/

  /**
   * Obtener lst tasa nan.
   *
   * @param cnan
   *          [String] cnan
   * @param fechavigencia
   *          [String] fechavigencia
   * @param codigoAduana Aduana operativa consulta
   * @return [List] list
   * @version 1.0
   */
  public List obtenerLstTasaNAN(String cnan, String fechavigencia, String codigoAduana);
/**FIN-RIN13**/

  /**
   * Verifica si la DUA esta exonerado de presentar formato B.
   *
   * @param params
   *          [Map<String,Object>] params
   * @return true, if is exonerado dua
   * @throws ServiceException
   *           the service exception
   */
  public boolean isExoneradoDua(Map<String, Object> params) throws ServiceException;

  /**
   * Permite Obtener la Aduana a partir de usuarioBean,
   * de no encontrar busca en la bd
   * @param request
   * @return
   */
  public String obtenerAduana(HttpServletRequest request);

  /**
   *
   * Tiene actas prev parcial.
   *
   * @param pkDecla
   * @return
   * @throws ServiceException
   */
  public boolean tieneActasPrevParcial(Map<String, Object> pkDecla) throws ServiceException;


	/**
	 * Permite obtener listado de diversos documentos asociados a la dua:
	 *
	 * 1-Expedientes asociado a la dua
	 * 2-Actas tipo AM y AC asociados a la (DUA y manifiesto - Documento Transporte)
	 * 3-Avisos de Inspecci�n asociados a la (DUA y manifiesto - Documento Transporte)
	 * 5-Accion de control NUEVO ACE asociados a la (DUA y manifiesto - Documento Transporte)
	 *
	 * @param params
	 * Mapa[NUM_MANIFIESTO,ANN_MANIFIESTO,COD_ADUAMANIFIESTO,NUM_DETALLE,NUM_DOCTRANSP],
	 * [COD_REGIMEN,COD_ADUANA,ANN_PRESEN,NUM_DECLARACION],NUM_CORREDOC
	 *
	 * @return Mapa o VACIO
	 * el Map contiene "listExpediDua","listActasDua","listAceDua",
	 * "lstAvisosInspeccionDocTransporte","listActasDocTransporte","listAceDocTransporte"
	 *
	 * @throws ServiceException
	 *
	 * @autor: amancillaa
	 */
	public Map<String, Object> getAllActasAndExpedientes(String numCorreDoc, Map<String, Object>
		mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException;

	/**
	 * Permite obtener listado de todas las actas asociadas a la dua:
	 *
	 * 1-Actas tipo AM y AC asociados a la (DUA y manifiesto - Documento Transporte)
	 * 2-Accion de control NUEVO ACE asociados a la (DUA y manifiesto - Documento Transporte)
	 *
	 * @param params
	 * Mapa[NUM_MANIFIESTO,ANN_MANIFIESTO,COD_ADUAMANIFIESTO,NUM_DETALLE,NUM_DOCTRANSP],
	 * [COD_REGIMEN,COD_ADUANA,ANN_PRESEN,NUM_DECLARACION],NUM_CORREDOC
	 *
	 * @return Mapa o VACIO
	 * el Map contiene "listActasDua","listAceDua", "listActasDocTransporte","listAceDocTransporte"
	 *
	 * @throws ServiceException
	 *
	 * @autor ttataje
	 * @version 1.0
	 */
    public Map<String, Object> getAllActasDuaManifiesto(String numCorreDoc,
            Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException;

	/**
   * Obtener areas para resoluciones.
   *
   * @param tipoResolucion
   *          [String] tipo resolucion
   * @return [List<Map<String,Object>>] list
   * @author amancillaa
   * @version 1.0
   */
	public List<Map<String, Object>> obtenerAreasParaResoluciones(String tipoResolucion);

	/**
   * Obtener areas para actas verificacion.
   *
   * @param tipoResolucion
   *          [String] tipo resolucion
   * @return [List<Map<String,Object>>] list
   * @author amancillaa
   * @version 1.0
   */
	public List<Map<String, Object>> obtenerAreasParaActasVerificacion(String tipoResolucion);

	/**
   * Obtener loca anexo.
   *
   * @param ruc
   *          [String] ruc
   * @return [List<Map<String,Object>>] list
   * @throws ServiceException
   *           the service exception
   * @author amancillaa
   * @version 1.0
   */
	public List<Map<String, Object>> obtenerLocaAnexo(String ruc) throws ServiceException;

	//INICIO - EJHM
	 /**
     * Proceso : Obtiene las NUEVAS ACES en cualquier estado y tipo
     * asociado a la DUA
     *
     * @param Map mapPkDua
     * @return List[Mapa[aces]]
     *
     * @autor: EJHM
     */
	public List<Map<String, Object>> getAceAsociadosDua(Map<String, Object> mapPkDua);
	
	  /**
	   * Gets the avisos inspeccion.
	   *
	   * @param listNumDoctrans
	   *          the list num doctrans
	   * @return the avisos inspeccion
	   * @autor: EJHM
	   */
	 public List<Map<String, Object>> getAvisosInspeccion(List<Map<String, Object>> listNumDoctrans);
	 
	 /**
	   * Gets the list doc transporte dua.
	   *
	   * @param numCorreDoc
	   *          the num corre doc
	   * @return the list doc transporte dua
	   * @autor: EJHM
	   */
	  public List<Map<String, Object>> getListDocTransporteDua(String numCorreDoc);
	//FIN - EJHM
// RIN16
    /**
     * Obtener los Boletines Quimicos de una declaracion, en la instancia operativa correspondiente.
     * @param params : recibe los siguientes datos
     * 	<br>- <strong>COD_ADUANA</strong> : Aduana a la que pertenece la declaracion
     * 	<br>- <strong>ANN_PRESEN</strong> : Anio de la declaracion
     * 	<br>- <strong>NUM_DECLARACION</strong> : Numero secuencial de negocio de la declaracion
     * 	<br>- <strong>COD_REGIMEN</strong> : Regimen al que pertenece la declaracion
     * 	<br>- <strong>IND_FINALIZADO</strong> [<i>OPCIONAL</i>] : (<strong>0</strong> - Finalizado) | (<strong>1</strong> - No Finalizado) 
     * @return
     */
    public List<Map<String, Object>> obtenerBoletinQuimicoPorDeclaracion(Map<String, Object> params);
    
    /**
     * Permite verificar si una Declaracion cuenta con Boletines Quimicos pendientes de Informe
     * @param declaracion
     * @return respuesta (boolean):
     * 	<br>[<strong>true</strong>]  : Si <u>existen</u> Boletines Pendientes de Informe
     * 	<br>[<strong>false</strong>] : Si <u>no tiene</u> Boletines Pendientes de Informe
     */
    public boolean tieneBoletinesQuimicosPendientes(Declaracion declaracion);
    //RIN16-CUS 11.03 - Inicio/ 
	public Map<String, Object> getAllActasAndExpedientesForDeclaParaRegul(String numCorreDoc, Map<String, Object>
	mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException;    
	//RIN16-CUS 11.03 - Fin/ 

/*RIN13FSW-INICIO*/	
	/**
	 * juazor RIN13
	 * @param mapPkDua
	 * @return
	 * @throws ServiceException
	 */
	public List<Map<String, Object>> getExpedientesAsociadoDua(Map<String, Object> mapPkDua)throws ServiceException;
	
	/**
	 * juazor RIN13
	 * @param PkDecla
	 * @return
	 * @throws ServiceException
	 */
	public List<Expedi> obtenerExpediSuspencionPlazo(Map<String, Object> PkDecla) throws ServiceException;

//	<EHR>
	/***
	 * Metodo para el envio de Notificaciones  enviamos el mensaje
	 * @param mapMensaje
	 * @return la serial de la notificacion
	 * @throws ServiceException
	 */
	public long emitirNotificacion(Map<String, Object> mapMensaje) throws ServiceException;

//	</EHR>
/*RIN13FSW-FIN*/

	/**
	 * Obtiene descripci�n de elemento de un cat�logo.
	 * 
	 * @param codigoCatalogo C�digo de Cat�logo
	 * @param codigoElementoCatalogo C�digo de Elemento de Cat�logo
	 * @return descripci�n de elemento de un cat�logo
	 * @author gbecerrav
	 */
	public String getDescripcionElementoCatalogo(String codigoCatalogo, String codigoElementoCatalogo) throws ServiceException; 

	/*P20*/	
	/**
	 * Metodo para obtener las Actas
	 * @param params
	 * @return
	 */
	public List<Map<String, Object>> obtenerCabActasForAsignacionAutomatica(Map<String,Object> params);
	/*FIN P20*/

	//inicio P21-P22
	public Map<String, Object> obtenerTodasActasConclusionDespacho(String numCorreDoc, Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException;
	public List<Map<String, Object>> validarLCPendPagoParaConclusionDespacho(Map<String, Object> params) throws ServiceException;
	public List<Map<String,Object>> findExpediDocAsociado(Map<String, Object> params);
	//fin P21-P22
	//P24
	public Map<String, Object> getDocumentosDUA(String numCorreDoc, Map<String, Object> mapPkDua) throws ServiceException; //gmontoya P24

	/**
	 * Obtiene las actas de inmovilizacion y/o incautacion asociados a la Declaraci�n
	 * @param params Parametros
	 * @return
	 */
	public List<Map>  obtenerActasByDua(Map<String, Object> params);
	//p24 pase PAS20165E220200099  
	public List<Map<String, Object>> getExpedientesAsociadoDuaPECO(Map<String, Object> mapPkDua);//gmontoya Pase 99 2016
}
