package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class DetAdiImpoConsuRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -1679326761445489116L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDetAdiImpoConsu";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private DetAdiImpoconsuDAO  detAdiImpoconsuDAO;

  //rtineo mejoras, grabacion en batch
  private DetAdiImpoconsuBatchDAO  detAdiImpoconsuBatchDAO;


  public DetAdiImpoConsuRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DET_ADI_IMPO_CONSU;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return detAdiImpoconsuDAO.select(mapParametros);
  }

  public void setDetAdiImpoconsuDAO(DetAdiImpoconsuDAO detAdiImpoconsuDAO)
  {
    this.detAdiImpoconsuDAO = detAdiImpoconsuDAO;
  }
  //rtineo, grabacion en batch
  public DetAdiImpoconsuBatchDAO getDetAdiImpoconsuBatchDAO() {
	return detAdiImpoconsuBatchDAO;
  }
  //rtineo, grabacion en batch
  public void setDetAdiImpoconsuBatchDAO(DetAdiImpoconsuBatchDAO detAdiImpoconsuBatchDAO) {
	this.detAdiImpoconsuBatchDAO = detAdiImpoconsuBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    detAdiImpoconsuDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    detAdiImpoconsuDAO.update(updateRecordMap);

  }
  //rtineo, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    detAdiImpoconsuBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    detAdiImpoconsuBatchDAO.update(updateRecordMap);

  }
}
