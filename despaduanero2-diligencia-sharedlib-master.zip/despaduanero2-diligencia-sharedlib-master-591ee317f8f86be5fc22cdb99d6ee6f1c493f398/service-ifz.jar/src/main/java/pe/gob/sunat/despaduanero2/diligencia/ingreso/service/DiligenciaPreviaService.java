package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * <p>Title: DiligenciaPreviaService</p>
 * <p>Description: Interface de Servicio para la Diligencia Previa</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public interface DiligenciaPreviaService {

	/**
	 * Valida la declaracion para el proceso 
	 * de registro de diligencia previa
	 * @param aduanaDeclaracion Aduana de la declaracion
	 * @param anioDeclaracion A�o de la declaracion
	 * @param regimenDeclaracion R�gimen de la declaracion
	 * @param numeroDeclaracion N�mero de la declaracion
	 * @param usuario Usuario logeado
	 * @return Error de validaci�n
	 * @author gbecerrav
	 */
	public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, Integer anioDeclaracion, 
			String regimenDeclaracion, Integer numeroDeclaracion, UsuarioBean usuario) throws ServiceException;
	
	/**
	 * Adiciona datos a la declaracion
	 * @param declaracion Declaracion
	 * @return
	 * @author gbecerrav
	 */
	public void adicionarDatosDeclaracion(Declaracion declaracion) throws ServiceException;
	
	/**
	 * Actualiza el estado de la declaracion a revision
	 * registra la diligencia previa en revision sino existe 
	 * @param declaracion Declaracion
	 * @param usuario Usuario logeado
	 * @return
	 * @author gbecerrav
	 */
	public void actualizarDeclaracionEnRevision(Declaracion declaracion, UsuarioBean usuario) throws ServiceException;
	
	/**
	 * Actualiza el estado de la declaracion a proceso
	 * @param declaracion Declaracion
	 * @return
	 * @author gbecerrav
	 */
	public void actualizarDeclaracionEnProceso(Declaracion declaracion) throws ServiceException;
	
	/**
	 * Registra una comunicacion
	 * @param comunicacion Comunicacion 
	 * @param declaracion Declaracion
	 * @param usuario Usuario logeado
	 * @return
	 * @author gbecerrav
	 */
	public void grabarComunicacion(Comunicacion comunicacion, Declaracion declaracion, UsuarioBean usuario) throws ServiceException;
	
	/**
	 * Registra una diligencia previa
	 * @param diligencia Diligencia
         * @param declaracion declaracion   
	 * @return
	 * @author gbecerrav ,jreynoso pase653
	 */
	public void grabarDiligenciaPrevia(Diligencia diligencia, Declaracion declaracion) throws ServiceException;
}
