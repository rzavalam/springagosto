package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;


/**
 * Muestra el LOG de entrada y salida de los metodos que se configuren. AOP se
 * debe activar en el archivo XML de transacciones
 *
 * Deberia de usarse solo para desarrollo, pero tambien es util activarlo en
 * produccion solo cuando hay errores teenr cuidado con el tama�o del archivo
 * LOG del aplicativo
 *
 * @author amancilla
 *
 */
public class AopLogger implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice
{

  private long                  startTime  = 0;
  private long                  finishTime = 0;
  protected static final Logger log        = Logger.getLogger(AopLogger.class);


  public void before(Method method, Object[] args, Object target) throws Throwable
  {

    if (log.isDebugEnabled())
    {
      startTime = System.currentTimeMillis();
      log.debug("(INICIO-METODO):" + target.getClass().getName() + "-" + method.getName());

      log.debug("PARAMETROS-METODO:" + SojoUtil.toJson(args));

    }
  }


  public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable
  {

    if (log.isDebugEnabled())
    {
      finishTime = System.currentTimeMillis();
      double totalDuration = finishTime - startTime;
      log.debug("(FINAL-METODO):" + " DURACION:" + totalDuration / 1000 + " Segundos. " + target.getClass().getName()
          + "-" + method.getName());
      log.debug("RETORNO-METODO:" + SojoUtil.toJson(returnValue));
    }
  }


  public void afterThrowing(Method method, Object[] args, Object target, Exception ex) throws Throwable
  {

    if (log.isDebugEnabled())
    {

      log.error("EXCEPCION-METODO[" + ex.getClass().getName() + "] THROWN POR LA CLASE ["
          + target.getClass().getName() + "] Y METODO[" + method.toString() + "]");

      log.error(getStackTrace(ex));

      throw ex;
    }
  }

  /**
   * Gets the stack trace.
   *
   * @param ex
   *          the ex
   * @return the stack trace
   */
  private String getStackTrace(Exception ex)
  {
    try
    {
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      ex.printStackTrace(pw);

      return sw.toString();
    }
    catch (Exception e)
    {
      return e.toString();
    }
  }
}
