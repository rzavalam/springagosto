package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.ModelAndView;

public interface ReporteJasperService
{
  @SuppressWarnings("rawtypes")
  public ModelAndView generarPdf(Map paramMap1, Collection paramCollection, Map paramMap2, ApplicationContext paramApplicationContext);

  @SuppressWarnings("rawtypes")
  public ModelAndView generarExcel(Map paramMap1, Collection paramCollection, Map paramMap2, ApplicationContext paramApplicationContext);

  @SuppressWarnings("rawtypes")
  public ModelAndView generarHtml(Map paramMap1, Collection paramCollection, Map paramMap2, ApplicationContext paramApplicationContext);

  
  @SuppressWarnings("rawtypes")
  public File generarReportePdf(InputStream paramInputStream, Map paramMap1, Collection paramCollection, Map paramMap2)
    throws Exception;
}