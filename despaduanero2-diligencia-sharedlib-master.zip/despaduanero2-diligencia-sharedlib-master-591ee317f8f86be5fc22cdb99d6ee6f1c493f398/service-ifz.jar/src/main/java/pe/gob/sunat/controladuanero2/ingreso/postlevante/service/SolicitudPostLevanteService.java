package pe.gob.sunat.controladuanero2.ingreso.postlevante.service;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudPostLevante;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * Created by amancillaa on 19/04/2016.
 */
public interface SolicitudPostLevanteService {

    public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, String anioDeclaracion,
                                                 String regimenDeclaracion, String numeroDeclaracion, UsuarioBean usuario) throws ServiceException;

    public ObjectResponseUtil validarAprobacionSolicitud(String aduanaDeclaracion, String anioDeclaracion,
                                                         String regimenDeclaracion, String numeroDeclaracion, UsuarioBean usuario) throws Exception;

    public SolicitudPostLevante obtenerSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public void insertarSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public void modificarSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public void eliminarSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public void aceptarSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public void rechazarSolicitud(SolicitudPostLevante solicitud) throws ServiceException;

    public boolean tienePECO(Long numCorredocDeclaracion) throws ServiceException;

}
