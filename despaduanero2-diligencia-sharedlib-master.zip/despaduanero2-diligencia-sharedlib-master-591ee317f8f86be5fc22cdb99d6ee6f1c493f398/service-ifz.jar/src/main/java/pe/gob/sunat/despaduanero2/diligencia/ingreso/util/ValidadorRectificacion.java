package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;


/*
 * Componente que contiene las validaciones de la Rectificacion.
 * VALIDACIONES PARA LA DECLARACION, SERIE, FACTURA e ITEM FACTURA con
 * CORRELACION DE SERIE ITEM
 */
/**
 * The Class ValidadorRectificacion.
 */
@SuppressWarnings({ "rawtypes" })
public class ValidadorRectificacion
{

  private static final Double DIFERENCIA_MAXIMA_MONTO    = 1.0;                                            // difMaxMto=1

  private static final Double DIFERENCIA_MAXIMA_PESO     = 1.0;                                            // difMaxPeso=1

  private static final Double DIFERENCIA_MAXIMA_CANTIDAD = 0.0009;                                         // difMaxCant=0.0009

  private static final int    INDICADOR_SERIE_ACTIVA     = 0;

  /**
   * 1. Metodo que permite validar el monto fob del item sea igual al producto
   * de cantidad de mercancias con el monto unitario del item.
   *
   * @param lstItemsFactura
   *          the lst items factura
   * @return MensajeBean : null si no existe errores, un MensajeBean con el
   *         mensaje de error y solucion a mostrar si existiese error.
   */
  public static MensajeBean validarFobItem(List<Map<String, Object>> lstItemsFactura)
  {

	    MensajeBean rBean = null;
	    BigDecimal producto = new BigDecimal(0);
	    BigDecimal division = new BigDecimal(0);
	    BigDecimal mtoUnitario = new BigDecimal(0);
	    BigDecimal margen = new BigDecimal(0.1);
	    List<Map<String, Object>> lstItemsFacturaAux = new ArrayList<Map<String,Object>>(lstItemsFactura);
	    
	    MathContext mc = new MathContext(6);
	    for (Map<String, Object> mapaItem : lstItemsFacturaAux)
	    {

          if(mapaItem.containsKey("CNT_UNI") && mapaItem.containsKey("MTO_FOBUNITARIO") && mapaItem.containsKey("MTO_FOBITEM") && mapaItem.containsKey("MTO_FOBUNITARIO") ){
	      producto = SunatNumberUtils.multiply(SunatNumberUtils.toBigDecimal(mapaItem.get("CNT_UNI")),
	          SunatNumberUtils.toBigDecimal(mapaItem.get("MTO_FOBUNITARIO")));
	      
	      BigDecimal mtoFobItem = SunatNumberUtils.toBigDecimal(mapaItem.get("MTO_FOBITEM"));
	       mtoUnitario = SunatNumberUtils.toBigDecimal(mapaItem.get("MTO_FOBUNITARIO"));
	      division = mtoFobItem.divide(SunatNumberUtils.toBigDecimal(mapaItem.get("CNT_UNI")),mc);
	      
	      BigDecimal dif1 = SunatNumberUtils.absoluteDiference(mtoFobItem.round(mc), producto.round(mc));
	      BigDecimal dif2 = SunatNumberUtils.absoluteDiference(mtoUnitario.round(mc), division.round(mc));
	      
	      if (!SunatNumberUtils.isLessThanParam(dif1, margen)   && !SunatNumberUtils.isLessThanParam(dif2, margen))
	      
	   //   if (!SunatNumberUtils.isEqual(mtoFobItem.round(mc), producto.round(mc)) && !SunatNumberUtils.isEqual(mtoUnitario.round(mc), SunatNumberUtils.scaleHalfUp(division,6)))
	      {
	        rBean = new MensajeBean();
	        rBean
	            .setMensajeerror("El valor del MONTO FOB del Item no es igual al producto de la Cantidad de Mercancia con el Monto Fob Unitario.");
	        rBean.setMensajesol("Verifique los datos de NUM_SECPROVE : " + mapaItem.get("NUM_SECPROVE").toString()
	            + " - NUM_SECFACT: " + mapaItem.get("NUM_SECPROVE").toString() + " - NUM_SECITEM: "
	            + mapaItem.get("NUM_SECITEM").toString());
	        return rBean;
	      }
	     } else{
	    	 lstItemsFactura.remove(mapaItem);
	     }
	    }
	    return rBean;
  }

  /*
   * 2. Metodo que valida si el valor absoluto entre el Fob de la factura y la
   * sumatoria de los Fob de los Item no sea mayor a 0.1.
   */
  /**
   * Validar fob factura vs sum fob item.
   *
   * @param lstFacturas
   *          the lst facturas
   * @param lstItem
   *          the lst item
   * @return the mensaje bean
   */
  public static MensajeBean validarFobFacturaVsSumFobItem(
      List<Map<String, Object>> lstFacturas,
      List<Map<String, Object>> lstItem)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal margen = new BigDecimal(0.1);
    MathContext mc = new MathContext(6);

    for (Map<String, Object> mapaFactura : lstFacturas)
    {
      // sumatoria de Fob Items
      sumatoria = new BigDecimal(0);
      for (Map<String, Object> mapaItem : lstItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils.toBigDecimal(mapaFactura.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaItem.get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaFactura.get("NUM_SECPROVE")),
                SunatNumberUtils.toBigDecimal(mapaItem.get("NUM_SECPROVE")))
            && SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaFactura.get("NUM_SECFACT")),
                SunatNumberUtils.toBigDecimal(mapaItem.get("NUM_SECFACT"))))
        {
          sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaItem.get("MTO_FOBITEM")));
        }
      }
      BigDecimal mtoFact = SunatNumberUtils.toBigDecimal(mapaFactura.get("MTO_FACT"));
      BigDecimal dif = SunatNumberUtils.absoluteDiference(sumatoria.round(mc), mtoFact.round(mc));
      if (!SunatNumberUtils.isLessThanParam(dif, margen))
      {
        rBean = new MensajeBean();
        rBean
            .setMensajeerror("El valor absoluto de la diferencia entre el valor Fob de la Factura y la sumatoria de los valores Fob de los Item son diferentes");
        rBean.setMensajesol("Verifique los datos de NUM_SECPROVE : " + mapaFactura.get("NUM_SECPROVE").toString()
            + " - NUM_SECFACT: " + mapaFactura.get("NUM_SECPROVE").toString());
        return rBean;
      }
    }
    return rBean;
  }

  /*
   * 3. Metodo que valida la cantidad de mercancias de la Serie sea igual a la
   * sumatoria de las cantidades registradas en el correlativo.
   */
  /**
   * Validar cantidad mercancia serie vs sum correlativos.
   *
   * @param lstSeries
   *          the lst series
   * @param lstSeriesItem
   *          the lst series item
   * @return the mensaje bean
   */
  public static MensajeBean validarCantidadMercanciaSerieVsSumCorrelativos(
    List<Map<String, Object>> lstSeries,
    List<Map<String, Object>> lstSeriesItem)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      // sumatoria de cantidades de correlativos
      sumatoria = new BigDecimal(0);
      for (Map<String, Object> mapaSerieItem : lstSeriesItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils
            .toBigDecimal(mapaSerie.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaSerieItem
                .get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(SunatNumberUtils
                .toBigDecimal(mapaSerie.get("NUM_SECSERIE")),
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECSERIE"))))
        {
          sumatoria = SunatNumberUtils.sum(sumatoria,
              SunatNumberUtils.toBigDecimal(mapaSerieItem.get("CNT_MERC")));
        }
      }
      if (!SunatNumberUtils.isEqual(sumatoria,
          SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_COMER"))))
      {
        rBean = new MensajeBean();
        rBean
            .setMensajeerror("La sumatoria de las cantidades de los correlativos no son iguales a la cantidad de mercancia registrada en la serie.");
        rBean.setMensajesol("Verifique los datos de NUM_SECSERIE : "
            + mapaSerie.get("NUM_SECSERIE").toString());
        rBean.setError(true);
        return rBean;
      }
    }
    return rBean;
  }

  /*
   * 4. Metodo que valida la cantidad de mercancias del Item sea igual a la
   * sumatoria de las cantidades registradas en el correlativo.
   */
  /**
   * Validar cantidad mercancia item vs sum correlativos.
   *
   * @param lstItemFactura
   *          the lst item factura
   * @param lstSeriesItem
   *          the lst series item
   * @return the mensaje bean
   */
  public static MensajeBean validarCantidadMercanciaItemVsSumCorrelativos(
    List<Map<String, Object>> lstItemFactura,
    List<Map<String, Object>> lstSeriesItem)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);

    for (Map<String, Object> mapaItemFactura : lstItemFactura)
    {
      // sumatoria de cantidades de correlativos
      sumatoria = new BigDecimal(0);
      for (Map<String, Object> mapaSerieItem : lstSeriesItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils
            .toBigDecimal(mapaSerieItem.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaItemFactura
                .get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECPROVE")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_SECPROVE")))
            && SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECFACT")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_SECFACT")))
            && SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECITEM")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_SECITEM"))))
        {
          sumatoria = SunatNumberUtils.sum(sumatoria,
              SunatNumberUtils.toBigDecimal(mapaSerieItem.get("CNT_MERC")));
        }
      }
      if (!SunatNumberUtils.isEqual(sumatoria,
          SunatNumberUtils.toBigDecimal(mapaItemFactura.get("CNT_UNI"))))
      {
        rBean = new MensajeBean();
        rBean
            .setMensajeerror("La sumatoria de las cantidades de los correlativos no son iguales a la cantidad de mercancia registrada en el ITEM.");
        rBean.setMensajesol("Verifique los datos de NUM_SECPROVE : "
            + mapaItemFactura.get("NUM_SECPROVE").toString()
            + " - NUM_SECFACT: "
            + mapaItemFactura.get("NUM_SECFACT").toString()
            + " - NUM_SECITEM: "
            + mapaItemFactura.get("NUM_SECITEM").toString());
        return rBean;
      }
    }
    return rBean;
  }

  /*
   * 5. Metodo que valida la sumatoria del producto de (monto de ajuste de Item
   * * (cantidad de mercancia en correlativo / cantidad de mercancias del Item))
   * sea igual al monto de ajuste de la serie. Margen de error no puede ser > 1.
   */
  /**
   * Validar ajuste serie vs sumatoria producto ajuste item cnt correlativo div
   * cant item relacionado.
   *
   * @param lstSeries
   *          the lst series
   * @param lstItemFactura
   *          the lst item factura
   * @param lstSeriesItem
   *          the lst series item
   * @return the mensaje bean
   */
  public static MensajeBean validarAjusteSerieVsSumatoriaProductoAjusteItemCntCorrelativoDivCantItemRelacionado(
    List<Map<String, Object>> lstSeries,
    List<Map<String, Object>> lstItemFactura,
    List<Map<String, Object>> lstSeriesItem)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal diferencia = new BigDecimal(0);
    BigDecimal margen = new BigDecimal(1);
    Map<String, Object> mapaItem = null;

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      // sumatoria de cantidades de correlativos
      sumatoria = new BigDecimal(0);
      for (Map<String, Object> mapaSerieItem : lstSeriesItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils
            .toBigDecimal(mapaSerie.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaSerieItem
                .get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(SunatNumberUtils
                .toBigDecimal(mapaSerie.get("NUM_SECSERIE")),
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECSERIE"))))
        {
          for (Map<String, Object> mapaItemFactura : lstItemFactura)
          {
            mapaItem = null;
            // Busqueda de Item que posea relacion con Correlativos
            if (SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_CORREDOC")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_CORREDOC")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECPROVE")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECPROVE")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECFACT")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECFACT")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECITEM")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECITEM"))))
            {
              mapaItem = new HashMap<String, Object>();
              mapaItem.putAll(mapaItemFactura);
              break;
            }
          }
          if (mapaItem != null)
          {
            sumatoria = SunatNumberUtils.sum(sumatoria,
                SunatNumberUtils.multiply(SunatNumberUtils.toBigDecimal(mapaItem
                    .get("MTO_AJUUNITARIO")),
                    ((SunatNumberUtils.toBigDecimal(mapaSerieItem
                        .get("CNT_MERC")))
                        .divide(SunatNumberUtils.toBigDecimal(mapaItem
                            .get("CNT_UNI"))))));
          }
        }
      }
      diferencia = SunatNumberUtils.absoluteDiference(sumatoria,
          SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_AJUSTE")));

      if (!SunatNumberUtils.isLessThanParam(diferencia, margen))
      {
        rBean = new MensajeBean();
        rBean
            .setMensajeerror("El monto de ajuste de la Serie no es igual a la sumatoria de los productos del monto de ajuste del Item por la relacion (Cantidad correlativa de la serie / Cantidad de mercancias del Item).");
        rBean.setMensajesol("Verifique los datos de NUM_SECSERIE : "
            + mapaSerie.get("NUM_SECSERIE").toString());
        return rBean;
      }
    }
    return rBean;
  }

  /*
   * 6. Metodo que valida Monto de Ajuste Formato A sumatoria del ajuste del
   * formato B (CNT_UNI * MTO_AJUUNITARIO).
   */

  /**
   * Validar valor absoluto sum ajuste a vs sum b.
   *
   * @param mapaDeclara
   *          the mapa declara
   * @param lstItemFactura
   *          the lst item factura
   * @return the mensaje bean
   */
  public static MensajeBean validarValorAbsolutoSumAjusteAVsSumB(
    Map<String, Object> mapaDeclara,
    List<Map<String, Object>> lstItemFactura)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);

    for (Map<String, Object> mapaItem : lstItemFactura)
    {
      // sumatoria de cantidades de correlativos
      if (SunatNumberUtils
          .isEqual(SunatNumberUtils.toBigDecimal(mapaDeclara
              .get("NUM_CORREDOC")), SunatNumberUtils
              .toBigDecimal(mapaItem.get("NUM_CORREDOC"))))
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils
            .multiply(SunatNumberUtils.toBigDecimal(mapaItem.get("MTO_AJUUNITARIO")),
                SunatNumberUtils.toBigDecimal(mapaItem.get("CNT_UNI"))));
      }
    }
    if (!SunatNumberUtils.isEqual(sumatoria,
        SunatNumberUtils.toBigDecimal(mapaDeclara.get("MTO_TOTAJUSTESDOL"))))
    {
      rBean = new MensajeBean();
      rBean
          .setMensajeerror("El monto total de ajuste de la Declaracion no es igual a la sumatoria del producto del monto de ajuste del Item por la Cantidad de mercancias del Item.");
      rBean
          .setMensajesol("Verifique los datos de los montos de Ajuste de la declaraci�n y los montos de ajuste de los Items del Formato B.");
      return rBean;
    }
    return rBean;
  }

  /*
   * 7. Metodo que valida que fob de la serie sea igual a la sumatoria del
   * producto de la cantidad de mercancias del correlativo por fob unitario de
   * cada item.
   */
  /**
   * Validar fob serie vs sum prod cant correlativos fob unitario item.
   *
   * @param lstSeries
   *          the lst series
   * @param lstItemFactura
   *          the lst item factura
   * @param lstSeriesItem
   *          the lst series item
   * @return the mensaje bean
   */
  public static MensajeBean validarFobSerieVsSumProdCantCorrelativosFobUnitarioItem(
    List<Map<String, Object>> lstSeries,
    List<Map<String, Object>> lstItemFactura,
    List<Map<String, Object>> lstSeriesItem)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    MathContext mc = new MathContext(3);
    Map<String, Object> mapaItem = null;

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      // sumatoria de cantidades de correlativos
      sumatoria = new BigDecimal(0);
      for (Map<String, Object> mapaSerieItem : lstSeriesItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils
            .toBigDecimal(mapaSerie.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaSerieItem
                .get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(SunatNumberUtils
                .toBigDecimal(mapaSerie.get("NUM_SECSERIE")),
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECSERIE"))))
        {
          for (Map<String, Object> mapaItemFactura : lstItemFactura)
          {
            mapaItem = null;
            // Busqueda de Item que posea relacion con Correlativos
            if (SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_CORREDOC")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_CORREDOC")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECPROVE")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECPROVE")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECFACT")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECFACT")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECITEM")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECITEM"))))
            {
              mapaItem = new HashMap<String, Object>();
              mapaItem.putAll(mapaItemFactura);
              break;
            }
          }
          if (mapaItem != null)
          {
            sumatoria = SunatNumberUtils.sum(sumatoria,
                SunatNumberUtils.multiply(SunatNumberUtils.toBigDecimal(mapaItem
                    .get("MTO_FOBUNITARIO")),
                    SunatNumberUtils.toBigDecimal(mapaSerieItem
                        .get("CNT_MERC"))));
          }
        }
      }
      BigDecimal mtoFobDolSerie = SunatNumberUtils.toBigDecimal(mapaSerie
          .get("MTO_FOBDOL"));
      if (!SunatNumberUtils.isEqual(sumatoria.round(mc),
          mtoFobDolSerie.round(mc)))
      {
        rBean = new MensajeBean();
        rBean
            .setMensajeerror("El monto Fob de la Serie no es igual a la sumatoria de las cantidades de los correlativos por el monto Fob Unitario de los Item asociados.");
        rBean.setMensajesol("Verifique los datos de NUM_SECSERIE : "
            + mapaSerie.get("NUM_SECSERIE").toString());
        return rBean;
      }
    }
    return rBean;
  }

  /*
   * 8. Metodo que valida que fob de la declaracion sea igual a la sumatoria del
   * fob de Serie.
   */
  /**
   * Validar fob declaracion vs sum fob serie.
   *
   * @param mapaDeclaracion
   *          the mapa declaracion
   * @param lstSeries
   *          the lst series
   * @return the mensaje bean
   */
  public static MensajeBean validarFobDeclaracionVsSumFobSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal fob = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("MTO_TOTFOBDOL"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_FOBDOL")));
      }
    }
    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, fob);
    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_MONTO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El monto Fob de la Declaracion " + fob
          + " no es igual a la sumatoria de los montos Fob "
          + sumatoria + " de Series.");
      rBean.setMensajesol("Verifique los datos del monto Fob de la declaraci�n y los montos Fob de las series.");
      return rBean;
    }
    return rBean;
  }


  /*
   * 10. Metodo que valida la correlacion de partidas entre Series e Items de
   * Facturas segun sus correlativos.
   */
  /**
   * Validar partidas.
   *
   * @param lstSeries
   *          the lst series
   * @param lstItemFactura
   *          the lst item factura
   * @param lstSeriesItem
   *          the lst series item
   * @return the mensaje bean
   */
  public static MensajeBean validarPartidas(
    List<Map<String, Object>> lstSeries,
    List<Map<String, Object>> lstItemFactura,
    List<Map<String, Object>> lstSeriesItem)
  {
    MensajeBean rBean = null;


    for (Map<String, Object> mapaSerie : lstSeries)
    {
      // sumatoria de cantidades de correlativos
      for (Map<String, Object> mapaSerieItem : lstSeriesItem)
      {
        if (SunatNumberUtils.isEqual(SunatNumberUtils
            .toBigDecimal(mapaSerie.get("NUM_CORREDOC")),
            SunatNumberUtils.toBigDecimal(mapaSerieItem
                .get("NUM_CORREDOC")))
            && SunatNumberUtils.isEqual(SunatNumberUtils
                .toBigDecimal(mapaSerie.get("NUM_SECSERIE")),
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_SECSERIE"))))
        {
          for (Map<String, Object> mapaItemFactura : lstItemFactura)
          {
            // Busqueda de Item que posea relacion con Correlativos
            if (SunatNumberUtils.isEqual(
                SunatNumberUtils.toBigDecimal(mapaSerieItem
                    .get("NUM_CORREDOC")), SunatNumberUtils
                    .toBigDecimal(mapaItemFactura
                        .get("NUM_CORREDOC")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECPROVE")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECPROVE")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECFACT")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECFACT")))
                && SunatNumberUtils.isEqual(SunatNumberUtils
                    .toBigDecimal(mapaSerieItem
                        .get("NUM_SECITEM")),
                    SunatNumberUtils
                        .toBigDecimal(mapaItemFactura
                            .get("NUM_SECITEM"))))
            {
              if (!(mapaSerie.get("NUM_PARTNANDI").toString()
                  .equals(mapaItemFactura.get(
                      "NUM_PARARANCEL").toString())))
              {
                rBean = new MensajeBean();
                rBean.setMensajeerror("Los c�digos de las partidas no coinciden.");
                rBean.setMensajesol("Verifique los datos de NUM_SECSERIE : "
                    + mapaSerie.get("NUM_SECSERIE")
                        .toString()
                    + " y el ITEM "
                    + mapaItemFactura.get("NUM_SECITEM"));
                return rBean;
              }

            }
          }
        }
      }
    }
    return rBean;
  }

  /**
   * Metodo que valida los valore4s de bultos de la declaracion sea igual a la
   * sumatoria de los valores de bulto de la Serie.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarBultosDeclaracionVsSumBultosSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal bulto = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("CNT_TOTBULTOS"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_BULTO")));
      }
    }
    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, bulto);

    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_CANTIDAD)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El valor Bulto de la Declaracion (" + bulto
          + ") no es igual a la sumatoria de los bultos ("
          + sumatoria + ") de Series.");
      rBean.setMensajesol("Verifique los datos del valor Bulto de la declaraci�n y los valores Bulto de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida los valores de peso bruto de la declaracion sea igual a
   * la sumatoria de los valores de peso bruto de la Serie.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarPesoBrutoDeclaracionVsSumPesoBrutoSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal pesoBruto = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("CNT_PESOBRUTO_TOTAL"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_PESO_BRUTO")));
      }
    }
    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, pesoBruto);

    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_PESO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El valor Peso bruto de la Declaracion ("
          + pesoBruto
          + ") no es igual a la sumatoria de los pesos brutos ("
          + sumatoria + ") de Series.");
      rBean
          .setMensajesol("Verifique los datos del valor Peso Bruto de la declaraci�n y los valores de peso Bruto de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida los valores de peso Neto de la declaracion sea igual a la
   * sumatoria de los valores de peso Neto de la Serie.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarPesoNetoDeclaracionVsSumPesoNetoSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal pesoNeto = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("CNT_PESONETO_TOTAL"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_PESO_NETO")));
      }
    }
    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, pesoNeto);

    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_PESO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El valor Peso Neto de la Declaracion ("
          + pesoNeto
          + ") no es igual a la sumatoria de los pesos Netos ("
          + sumatoria + ") de Series.");
      rBean
          .setMensajesol("Verifique los datos del valor Peso Neto de la declaraci�n y los valores Peso Neto de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida los valores de Flete de la declaracion sea igual a la
   * sumatoria de los valores de Flete de la Serie.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarFleteDeclaracionVsSumFleteSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal flete = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("MTO_TOTFLETEDOL"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_FLETEDOL")));
      }
    }
    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, flete);

    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_MONTO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El monto Flete de la Declaracion (" + flete
          + ") no es igual a la sumatoria de los Fletes (" + sumatoria
          + ") de Series.");
      rBean.setMensajesol("Verifique los datos del monto Flete de la declaraci�n y los montos Flete de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida los valores de Seguro de la declaracion sea igual a la
   * sumatoria de los valores de Seguro de la Serie.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarSeguroDeclaracionVsSumSeguroSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal seguro = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("MTO_TOTSEGDOL"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_SEGDOL")));
      }
    }

    BigDecimal diferencia = SunatNumberUtils.diference(sumatoria, seguro);

    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_MONTO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El monto Seguro de la Declaracion ("
          + seguro + ") no es igual a la sumatoria de los Seguro ("
          + sumatoria + ") de Series.");
      rBean.setMensajesol("Verifique los datos del monto Seguro de la declaraci�n y los montos Seguro de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida la cantidad de mercancias (Unidad Comercial) de la
   * declaracion sea igual a la sumatoria de las cantidades de mercancia de las
   * Series.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarCntComercialDeclaracionVsSumCntComercialSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal diferencia = new BigDecimal(0);
    BigDecimal undidadComercial = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("CNT_TQUNICOM"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_COMER")));
      }
    }

    diferencia = SunatNumberUtils.diference(sumatoria, undidadComercial);
    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_CANTIDAD)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("La cantidad de unidades de la declaracion (Unidad Comercial = " + undidadComercial
          + ") no es igual a la sumatoria de las unidades(Unidad Comercial = " + sumatoria + " ) de las Series.");
      rBean
          .setMensajesol("Verifique los datos de la cantidad Unidades de la declaraci�n y las cantidad unidades de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo que valida la cantidad de mercancias (Unidad Fisica) de la
   * declaracion sea igual a la sumatoria de las cantidades de mercancia de las
   * Series.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarCntFisicaDeclaracionVsSumCntFisicaSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal diferencia = new BigDecimal(0);
    BigDecimal undidadFisica = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("CNT_TQUNIFIS"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
        sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("CNT_UNIFIS")));
      }
    }

    diferencia = SunatNumberUtils.diference(sumatoria, undidadFisica);
    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_CANTIDAD)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("La cantidad de unidades de la declaracion (Unidad Fisica = " + undidadFisica
          + ") no es igual a la sumatoria de las unidades(Unidad Fisica = " + sumatoria + " ) de las Series.");
      rBean
          .setMensajesol("Verifique los datos de la cantidad Unidades de la declaraci�n y las cantidad unidades de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Valida que el monto del valor en aduanas de la declaracion sea igual a la
   * sumatoria de los Montos del valor en aduanas de las Series.
   *
   * @param mapaDeclaracion
   *          cabecera de la declaracion
   * @param lstSeries
   *          lista de series de la declaracion
   * @return the mensaje bean
   */
  private static MensajeBean validarMtoValorAduanasVsSumMtoValorAduanasSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries)
  {
    MensajeBean rBean = null;
    BigDecimal sumatoria = new BigDecimal(0);
    BigDecimal sumatoriaFob = new BigDecimal(0);
    BigDecimal sumatoriaFlete= new BigDecimal(0);
    BigDecimal sumatoriaSeguro = new BigDecimal(0);
    BigDecimal sumatoriaAjuste = new BigDecimal(0);
    BigDecimal sumatoriaAjusteOtros = new BigDecimal(0);
    BigDecimal diferencia = new BigDecimal(0);
    BigDecimal mtoTotalValorAduana = SunatNumberUtils.toBigDecimal(mapaDeclaracion.get("MTO_TOTVALORADU"));

    for (Map<String, Object> mapaSerie : lstSeries)
    {
      if ((Integer.parseInt(mapaSerie.get("IND_DEL") == null ? "0" : mapaSerie.get("IND_DEL").toString())) == INDICADOR_SERIE_ACTIVA)
      {
       // sumatoria = SunatNumberUtils.sum(sumatoria, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_VALORADU")));
        sumatoriaFob = SunatNumberUtils.sum(sumatoriaFob, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_FOBDOL")));
        sumatoriaFlete = SunatNumberUtils.sum(sumatoriaFlete, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_FLETEDOL")));
        sumatoriaSeguro = SunatNumberUtils.sum(sumatoriaSeguro, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_SEGDOL")));
        sumatoriaAjuste = SunatNumberUtils.sum(sumatoriaAjuste, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_AJUSTE")));
        sumatoriaAjusteOtros = SunatNumberUtils.sum(sumatoriaAjusteOtros, SunatNumberUtils.toBigDecimal(mapaSerie.get("MTO_OTROSAJUSTES")));
        
        sumatoria = sumatoriaFob.add(sumatoriaFlete).add(sumatoriaAjuste).add(sumatoriaSeguro).add(sumatoriaAjusteOtros);
      }
    }

    diferencia = SunatNumberUtils.diference(sumatoria, mtoTotalValorAduana);
    if (Math.abs(diferencia.doubleValue()) > DIFERENCIA_MAXIMA_MONTO)
    {
      rBean = new MensajeBean();
      rBean.setMensajeerror("El monto del valor en aduana (" + mtoTotalValorAduana
          + ") no es igual a la sumatoria de montos de valor en aduanas (" + sumatoria + " ) de las Series.");
      rBean
          .setMensajesol("Verifique los datos del monto Valor en Aduana de la declaraci�n y los montos Valor en Aduana de las series");
      return rBean;
    }
    return rBean;
  }

  /**
   * Metodo quqe valida las sumatorias de las series concuerden con los totales
   * de la declarcion.
   *
   * @param mapaDeclaracion
   *          the mapa declaracion
   * @param lstSeries
   *          the lst series
   * @return the mensaje bean
   */
  public static MensajeBean validarTotalDeclaracionVsSumasSerie(
    Map<String, Object> mapaDeclaracion,
    List<Map<String, Object>> lstSeries,
    List<Map<String, Object>> lstItemFactura,
    List<Map<String, Object>> lstSeriesItem)
 
  {


    MensajeBean rBean = null;

      //amancilla solo para difernete 70
      String codRegimen = mapaDeclaracion.get("COD_REGIMEN")!=null?mapaDeclaracion.get("COD_REGIMEN").toString():"";
      if("70".equals(codRegimen)){

          return rBean;
      }

    // Monto FOB
    rBean = validarFobDeclaracionVsSumFobSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // monto flete
    rBean = validarFleteDeclaracionVsSumFleteSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // monto seguro
    rBean = validarSeguroDeclaracionVsSumSeguroSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // peso neto
    rBean = validarPesoNetoDeclaracionVsSumPesoNetoSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // peso bruto
    rBean = validarPesoBrutoDeclaracionVsSumPesoBrutoSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // cantidad de bultos
    rBean = validarBultosDeclaracionVsSumBultosSerie(mapaDeclaracion, lstSeries);
    if (rBean != null)
    {
      return rBean;
    }
    // cantidades comerciales
    rBean = validarCntComercialDeclaracionVsSumCntComercialSerie(mapaDeclaracion, lstSeries);

    if (rBean != null)
    {
      return rBean;
    }
    // unidades fisicas
    rBean = validarCntFisicaDeclaracionVsSumCntFisicaSerie(mapaDeclaracion, lstSeries);

    if (rBean != null)
    {
      return rBean;
    }

    /**amancilla*/
    // unidades comerciales A y B
    
    
    rBean = validarFobItem(lstItemFactura);
    if (rBean != null)
    {
      return rBean;
    }
    
   /* rBean = validarCantidadMercanciaItemVsSumCorrelativos(lstItemFactura,lstSeriesItem);
    if (rBean != null)
    {
      return rBean;
    }
    
    rBean = validarCantidadMercanciaSerieVsSumCorrelativos(lstSeries,lstSeriesItem);
    if (rBean != null)
    {
      return rBean;
    }*/
    
          
    /*fin*/
    
    // Monto Valor en aduanas
    rBean = validarMtoValorAduanasVsSumMtoValorAduanasSerie(mapaDeclaracion, lstSeries);

    return rBean;
  }

 
public static MensajeBean validarTotalDeclaracionVsSumasSerie(
		Map<String, Object> mapaDeclaracion,
		ArrayList<Map<String, Object>> lstSeries) {
	  MensajeBean rBean = null;

    //amancilla solo para difernete 70
    String codRegimen = mapaDeclaracion.get("COD_REGIMEN")!=null?mapaDeclaracion.get("COD_REGIMEN").toString():"";
    if("70".equals(codRegimen)){

        return rBean;
    }

	    // Monto FOB
	    rBean = validarFobDeclaracionVsSumFobSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // monto flete
	    rBean = validarFleteDeclaracionVsSumFleteSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // monto seguro
	    rBean = validarSeguroDeclaracionVsSumSeguroSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // peso neto
	    rBean = validarPesoNetoDeclaracionVsSumPesoNetoSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // peso bruto
	    rBean = validarPesoBrutoDeclaracionVsSumPesoBrutoSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // cantidad de bultos
	    rBean = validarBultosDeclaracionVsSumBultosSerie(mapaDeclaracion, lstSeries);
	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // cantidades comerciales
	    rBean = validarCntComercialDeclaracionVsSumCntComercialSerie(mapaDeclaracion, lstSeries);

	    if (rBean != null)
	    {
	      return rBean;
	    }
	    // unidades fisicas
	    rBean = validarCntFisicaDeclaracionVsSumCntFisicaSerie(mapaDeclaracion, lstSeries);

	    if (rBean != null)
	    {
	      return rBean;
	    }

	  
	    
	    

	          
	 
	    
	    // Monto Valor en aduanas
	    rBean = validarMtoValorAduanasVsSumMtoValorAduanasSerie(mapaDeclaracion, lstSeries);

	    return rBean;
}


 

}
