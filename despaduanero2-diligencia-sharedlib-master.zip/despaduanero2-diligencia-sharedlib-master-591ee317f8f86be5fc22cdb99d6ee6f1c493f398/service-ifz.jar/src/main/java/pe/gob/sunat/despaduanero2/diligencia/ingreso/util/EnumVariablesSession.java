package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;


/**
 * Enum permite renombrar las variables de session que ya existian
 * con un nombre mas expresivo, ademas permite gestionar las variables
 * teniendolas registradas, se pueden quitar de session.
 * las variables de este ENUM complementa a las registradas
 * en la clase EnumTablaModel
 *
 *
 * @author amancilla
 * @version 1.0
 * @since Aug 26, 2012
 */
public enum EnumVariablesSession {

    /**LISTADO DE VARIABLES DE SESSION USADOS EN EL MODULO**/

    /**
     * aduana del usuario logeado.
     */
    COD_ADUANA_LOGEADA("cAduana"),

    /**
     * Objeto con los datos del usuario logeado.
     */
    USUARIO_LOGEADO("usuarioBean"),

    /**
     * tipo de Diligencia.
     */
    TIP_DILIGENCIA("tipoDiligencia"),

    /**
     * datos temporales recuperados para rectioficio
     * y despues realizar el Merge con los datos de la BD
     */
    DATOS_TMP("datosTMP"),


    PARAMS_BUSQUEDA_DUA("paramsBusquedaDua"),

    SALIR_RECTI_OFICIO("SI"),

     ;

    /**
     * el nombre variable session.
     */
    private String nombreVariableSession;

    /**
     * Permite inicializar una ENUN
     *
     * @param nombreVariableSession [String] nombre variable session
     */
    EnumVariablesSession(String nombreVariableSession) {

        this.nombreVariableSession = nombreVariableSession;
    }

    public void setNombreVariableSession(String nombreVariableSession) {

        this.nombreVariableSession = nombreVariableSession;
    }

    public String getNombreVariableSession() {

        return nombreVariableSession;
    }

}
