package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class FormaFactuRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 1289816017220658324L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstFormaFactu";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FormaFactuDAO       formaFactuDAO;
  //rtineo mejoras, grabacion en batch
  private FormaFactuBatchDAO formaFactuBatchDAO;

  public FormaFactuRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECFACT", "NUM_SECFACT");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FORMA_FACTU;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return formaFactuDAO.select(mapParametros);
  }

  public void setFormaFactuDAO(FormaFactuDAO formaFactuDAO)
  {
    this.formaFactuDAO = formaFactuDAO;
  }
  //rtineo mejoras, grabacion en batch
  public FormaFactuBatchDAO getFormaFactuBatchDAO() {
	return formaFactuBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFormaFactuBatchDAO(FormaFactuBatchDAO formaFactuBatchDAO) {
	this.formaFactuBatchDAO = formaFactuBatchDAO;
  }
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.formaFactuDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    formaFactuDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    this.formaFactuBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  formaFactuBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }
}
