package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiAdmTemBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiAdmTemDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class CabAdiAdmTemRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -8885006555520925306L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstCabAdiAdmTem";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private CabAdiAdmTemDAO     cabAdiAdmTemDAO;

  //rtineo mejoras, grabacion en batch
  private CabAdiAdmTemBatchDAO cabAdiAdmTemBatchDAO;

  public CabAdiAdmTemRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_CAB_ADI_ADM_TEM;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return cabAdiAdmTemDAO.select(mapParametros);

  }

  public void setCabAdiAdmTemDAO(CabAdiAdmTemDAO cabAdiAdmTemDAO)
  {
    this.cabAdiAdmTemDAO = cabAdiAdmTemDAO;
  }

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin
    //PAS20171U220200005
    ArrayList<Map<String, Object>>mapaData =  mapDatos.get(getNombreListaResultante())!=null?(ArrayList<Map<String, Object>>)mapDatos.get(getNombreListaResultante()):null;
    if (mapaData != null && !mapaData.isEmpty())//PAS20171U220200005
    {
      Map<String, Object> mapPK = new HashMap<String, Object>();

      mapPK.put("NUM_CORREDOC", "NUM_CORREDOC");
      for (Map<String, Object> mapCabAdiAdmTem : (ArrayList<Map<String, Object>>) mapDatos
          .get(getNombreListaResultante()))
      {
        if (log.isDebugEnabled())
        {
          cont++;
          if (log.isDebugEnabled())
            log.debug(cont + " Cab_Adi_AdmTem :" + mapCabAdiAdmTem);
        }
        for (Map<String, Object> mapCabAdiAdmTemAntes : (ArrayList<Map<String, Object>>) mapDatos
            .get(getNombreListaOriginal()))
        {
          if (mapCabAdiAdmTemAntes.get("NUM_CORREDOC").toString().trim()
              .equals(mapCabAdiAdmTem.get("NUM_CORREDOC").toString().trim()))
          {
            mapDiferenciaGrabar = this.comparador.comparaMap(mapCabAdiAdmTemAntes, mapCabAdiAdmTem, mapPK);
            if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                && Comparador.esDataCambiada(mapDiferenciaGrabar))
            {
              if (log.isDebugEnabled())
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  cabAdiAdmTemBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
            	  registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
              }else{
              cabAdiAdmTemDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));// mapCabAdiAdmTem
              registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
            }
              //rtineo mejoras, fin
            }
          }
        }
      }
    }
    
    return cont;
  }

  //rtineo mejoras, grabacion en batch
  public CabAdiAdmTemBatchDAO getCabAdiAdmTemBatchDAO() {
	return cabAdiAdmTemBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setCabAdiAdmTemBatchDAO(CabAdiAdmTemBatchDAO cabAdiAdmTemBatchDAO) {
	this.cabAdiAdmTemBatchDAO = cabAdiAdmTemBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // TODO Auto-generated method stub

  }

  //rtineo mejoras
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // TODO Auto-generated method stub
  }

  //rtineo mejoras
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // TODO Auto-generated method stub
  }
}
