package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * The Class Ordenador.
 */
@SuppressWarnings({ "unchecked" })
public class Ordenador
{

  public static String ASC  = "1";
  public static String DESC = "0";

  /**
   * Obtiene map ordenado.
   *
   * @param params
   *          the params
   * @return the map
   */
  public static Map<String, Object> obtieneMapOrdenado(Map<String, Object> params)
  {
    Map<String, Object> mapResultado = new HashMap<String, Object>();

    // cabdeclaraActual, este map ya contiene los datos de autoliquidaciones y
    // otros sobre pagos
    mapResultado.put("mapCabDeclara", params.get("mapCabDeclaraActual"));

    // lstDocAutAsociadoActual
    ((Map<String, Object>) mapResultado.get("mapCabDeclara")).put("lstDocAutAsociado", params
        .get("lstDocAutAsociadoActual"));
    // lstAutoliquidaciones
    ((Map<String, Object>) mapResultado.get("mapCabDeclara")).put("lstAutoliquidaciones", params
        .get("lstAutoliquidaciones"));
    // lstMultaDuas
    ((Map<String, Object>) mapResultado.get("mapCabDeclara")).put("lstMultaDua", params.get("lstMultaDua"));
    // diferenciaTributos
    ((Map<String, Object>) mapResultado.get("mapCabDeclara")).put("diferenciaTributos", params
        .get("diferenciaTributos"));

    mapResultado.put("lstDetDeclara", params.get("lstDetDeclaraActual"));
    mapResultado.put("lstDocuPreceDua", params.get("lstDocuPreceDuaActual"));
    mapResultado.put("lstFacturaSerie", params.get("lstFacturaSerieActual"));
    mapResultado.put("lstIncidencias", params.get("lstIncidencias"));
    mapResultado.put("lstCabAdiAdmTem", params.get("lstCabAdiAdmTemActual"));
    mapResultado.put("lstCabAdiImpoConsu", params.get("lstCabAdiImpoConsuActual"));
    mapResultado.put("lstConvenioSerie", params.get("lstConvenioSerieActual"));
    mapResultado.put("lstDetAduAtreex", params.get("lstDetAduAtreexActual"));
    mapResultado.put("lstEquipamiento", params.get("lstEquipamientoActual"));
    mapResultado.put("lstFinUbicacion", params.get("lstFinUbicacionActual"));
    mapResultado.put("lstFormaFactu", params.get("lstFormaFactuActual"));
    mapResultado.put("lstParticipanteDoc", params.get("lstParticipanteDocActual"));

    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) params.get("lstFormBProveedorActual");
    List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) params.get("lstComproBPagoActual");
    List<Map<String, Object>> lstItemFactura = (List<Map<String, Object>>) params.get("lstItemFacturaActual");
    List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) params.get("lstSeriesItemActual");

    for (int i = 0; i < lstItemFactura.size(); i++)
    {
      for (Map<String, Object> mapa : lstSeriesItem)
      {
        if (lstItemFactura.get(i).get("NUM_CORREDOC").toString().trim().equals(
            mapa.get("NUM_CORREDOC").toString().trim())
            && lstItemFactura.get(i).get("NUM_SECPROVE").toString().trim().equals(
                mapa.get("NUM_SECPROVE").toString().trim())
            && lstItemFactura.get(i).get("NUM_SECFACT").toString().trim().equals(
                mapa.get("NUM_SECFACT").toString().trim())
            && lstItemFactura.get(i).get("NUM_SECITEM").toString().trim().equals(
                mapa.get("NUM_SECITEM").toString().trim()))
        {
          if (lstItemFactura.get(i).get("lstSeriesItem") != null)
          {
            lstItemFactura.get(i).put("lstSeriesItem", new ArrayList<Map<String, Object>>());
          }
          ((ArrayList<Map<String, Object>>) lstItemFactura.get(i).get("lstSeriesItem")).add(mapa);
        }
      }
    }

    for (int i = 0; i < lstComproBPago.size(); i++)
    {
      for (Map<String, Object> mapa : lstItemFactura)
      {
        if (lstComproBPago.get(i).get("NUM_CORREDOC").toString().trim().equals(
            mapa.get("NUM_CORREDOC").toString().trim())
            && lstComproBPago.get(i).get("NUM_SECPROVE").toString().trim().equals(
                mapa.get("NUM_SECPROVE").toString().trim())
            && lstComproBPago.get(i).get("NUM_SECFACT").toString().trim().equals(
                mapa.get("NUM_SECFACT").toString().trim()))
        {
          if (lstComproBPago.get(i).get("lstItemFactura") != null)
          {
            lstComproBPago.get(i).put("lstItemFactura", new ArrayList<Map<String, Object>>());
          }
          ((ArrayList<Map<String, Object>>) lstComproBPago.get(i).get("lstItemFactura")).add(mapa);
        }
      }
    }


    for (int i = 0; i < lstFormBProveedor.size(); i++)
    {
      for (Map<String, Object> mapa : lstComproBPago)
      {
        if (lstFormBProveedor.get(i).get("NUM_CORREDOC").toString().trim().equals(
            mapa.get("NUM_CORREDOC").toString().trim())
            && lstFormBProveedor.get(i).get("NUM_SECPROVE").toString().trim().equals(
                mapa.get("NUM_SECPROVE").toString().trim()))
        {
          if (lstFormBProveedor.get(i).get("lstComproBPago") != null)
          {
            lstFormBProveedor.get(i).put("lstComproBPago", new ArrayList<Map<String, Object>>());
          }
          ((ArrayList<Map<String, Object>>) lstFormBProveedor.get(i).get("lstComproBPago")).add(mapa);
        }
      }
    }

    ((Map<String, Object>) mapResultado.get("mapCabDeclara")).put("lstFormBProveedor", params
        .get("lstFormBProveedorActual"));

    return mapResultado;
  }

  /**
   * amancillaa 14/06/2011 Metodo encargado de ordenar una lista de HashMaps, de
   * acuerdo a una campo.
   *
   * @param lista
   *          List. Listado de HashMaps a ordenar.
   * @param key
   *          String. Que contiene el campo para ordenar.
   * @param tipo
   *          (0 descendente y 1 ascendente)
   */
  public static void sortDesc(List<Map<String, Object>> lista, String key, String tipo)
  {
    Collections.sort(lista, new HashMapComparator(key, tipo));

  }

}
