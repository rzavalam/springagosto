package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;


public class MontoGastoRectificacion extends RectificacionAbstract
{

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstMontoGasto";

  public static final String  NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private MontoGastoDAO       montoGastoDAO;

  //rtineo mejoras, grabacion en batch
  private MontoGastoBatchDAO montoGastoBatchDAO;

  public MontoGastoRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");
    mapClave.put("COD_CPTOGASTOS", "COD_CPTOGASTOS");
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(NOMBRE_LISTA_ORIGINAL, getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  @Override
  public String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_MONTO_GASTO;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    List<Map<String, Object>> montoGastoRetrun = new ArrayList<Map<String, Object>>();
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("numcorredoc", parametros.get("NUM_CORREDOC").toString());
    List<DatoMontoGasto> lstDatoMontoGasto = montoGastoDAO.findMontoGastoByMap(mapParametros);

    for (DatoMontoGasto datoMontoGasto : lstDatoMontoGasto)
    {
      montoGastoRetrun.add(objectToMap(datoMontoGasto));
    }

    return montoGastoRetrun;
  }

  //rtineo mejoras, grabacion en batch
  public MontoGastoBatchDAO getMontoGastoBatchDAO() {
	return montoGastoBatchDAO;
  }

  public void setMontoGastoBatchDAO(MontoGastoBatchDAO montoGastoBatchDAO) {
	this.montoGastoBatchDAO = montoGastoBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    montoGastoDAO.insertSelective(newRecordMap);

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    montoGastoDAO.updateSelective(updateRecordMap);

  }

  //rtineo mejroas, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    montoGastoBatchDAO.insertSelective(newRecordMap);

  }
  //rtineo mejroas, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  montoGastoBatchDAO.updateSelective(updateRecordMap);

  }

  public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO)
  {
    this.montoGastoDAO = montoGastoDAO;
  }

  public DatoMontoGasto mapToObject(Map<String, Object> mapMontoGasto)
  {
    DatoMontoGasto datoMontoGasto = new DatoMontoGasto();
    datoMontoGasto.setNumcorredoc(SunatNumberUtils.toLong(mapMontoGasto.get("NUM_CORREDOC")));
    datoMontoGasto.setNumserie(SunatNumberUtils.toInteger(mapMontoGasto.get("NUM_SECSERIE")));
    datoMontoGasto.setTipmonto(ObjectUtils.toString(mapMontoGasto.get("COD_CPTOGASTOS"), null));
    datoMontoGasto.setValmonto(SunatNumberUtils.toBigDecimal(mapMontoGasto.get("MTO_GASTO")));
    return datoMontoGasto;
  }

  public Map<String, Object> objectToMap(DatoMontoGasto datoMontoGasto)
  {
    Map<String, Object> mapMontoGasto = new HashMap<String, Object>();
    mapMontoGasto.put("NUM_CORREDOC", datoMontoGasto.getNumcorredoc());
    mapMontoGasto.put("NUM_SECSERIE", datoMontoGasto.getNumserie());
    mapMontoGasto.put("COD_CPTOGASTOS", datoMontoGasto.getTipmonto());
    mapMontoGasto.put("MTO_GASTO", datoMontoGasto.getValmonto());
    return mapMontoGasto;
  }
}
