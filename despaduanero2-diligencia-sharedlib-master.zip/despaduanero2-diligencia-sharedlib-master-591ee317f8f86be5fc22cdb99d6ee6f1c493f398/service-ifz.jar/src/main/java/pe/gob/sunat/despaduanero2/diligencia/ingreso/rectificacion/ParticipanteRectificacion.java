package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.*;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocBatchDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

public class ParticipanteRectificacion extends RectificacionAbstract implements Serializable{
	
	/**
	 * 
	 */
  private static final long   serialVersionUID                     = 7714532212674933440L;

  public static final String  NOMBRE_LISTA_ORIGINAL                = "lstParticipante";

  public static final String  NOMBRE_LISTA_RESULTANTE              = NOMBRE_LISTA_ORIGINAL + "Actual";

  private static final String COD_TIPO_IMPORTADOR                  = "45";

  private static final String COD_TIPO_TRANSPORTISTA_LOCAL         = "11";

  private static final String COD_TIPO_TRANSPORTISTA_REPRESENTANTE = "12";

  private static final String COD_TIPO_DEPOSITO_TEMPORAL           = "31";

  private static final String COD_TIPO_AGENTE_ADUANA               = "41";

  private static final String NOMBRE_MAP_CAB_DECLARA_RESULTANTE    = CabDeclaraRectificacion.NOMBRE_MAPA_RESULTANTE;

  private ParticipanteDocDAO  participanteDocDAO;

  private FormBProveedorDAO   formBProveedorDAO;
  
  //rtineo mejoras, grabacion en batch
  private ParticipanteDocBatchDAO participanteDocBatchDAO;
  private FormBProveedorBatchDAO formBProveedorBatchDAO;
  
  private DdpDAOService ddpDAOService;


  public ParticipanteRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_SECPARTIC", "NUM_SECPARTIC");
    mapClave.put("COD_TIPPARTIC", "COD_TIPPARTIC");
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_PARTICIPANTE_DOC;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return participanteDocDAO.select(mapParametros);
  }

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#mergeDatosBDRectificacion(java.util.Map,
   * java.util.Map)
   */
  @Override
  public Map<String, Object> mergeDatosBDRectificacion(
      Map<String, Object> mapInitialData,
      Map<String, Object> mapValores)
  {
    // recuperamos valores actuales de la tabla(en BD) a rectificar
    Map mapResultado = new HashMap<String, Object>(mapInitialData);
    mapResultado = getDatosInicialesRectifacion(new HashMap<String, Object>(mapInitialData), mapValores);

    if (mapResultado.get(getCodTablaRectificacion()) != null)
    {

      List lstDatosOriginales = (List<Map<String, Object>>) mapResultado.get(getNombreListaOriginal());

      List lstDatosNuevos = (List<Map<String, Object>>) mapResultado.get(getCodTablaRectificacion());

      List lstResultante = Comparador.setearValoresListMap(lstDatosOriginales, lstDatosNuevos, getMapClave(),
          ACTIVAR_ENCONTRAR_DATOS_NUEVOS);

      mapResultado.put(getNombreListaResultante(), lstResultante);

      updateParticipanteInCabdeclaraActual((Map<String, Object>) mapResultado.get(NOMBRE_MAP_CAB_DECLARA_RESULTANTE),
          lstResultante);
    }
    else
    {
      // si no hay nada que rectificar retornamos los datos de la base de datos
      mapResultado.put(getNombreListaResultante(), mapResultado.get(getNombreListaOriginal()));// Si
                                                                                               // no
                                                                                               // existe
                                                                                               // para
      // rectificacion
    }

    return mapResultado;
  }

  public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO)
  {
    this.participanteDocDAO = participanteDocDAO;
  }

  /* olunar */
  public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
  {
    this.formBProveedorDAO = formBProveedorDAO;
  }

  /* fin */

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#grabarRectificacion(java.lang.String, java.util.Map)
   */

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin 
    Map<String, Object> mapDiferenciaGrabar;
    if (mapDatos.get(getNombreListaResultante()) != null)
    {

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {

        // agregamos razon social de la tabla ruc (tributos)
        obtenerRazonSocialParticipante(itemNew);
        if (log.isDebugEnabled())
        {
          cont++;
          log.debug(cont + " PARTICIPANTE_DOC :" + itemNew);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {

          Long codigoParticipante = new Long(ObjectUtils.toString(itemNew.get("NUM_SECPARTIC"), "0"));
          if (codigoParticipante.equals(0.0) || codigoParticipante.equals(new Long(0))) //cambio de german
          {
            String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
            codigoParticipante = sequenceDAO.getNextSequence(sequenceName);
            itemNew.put("NUM_SECPARTIC", codigoParticipante);
          }

          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  this.participanteDocBatchDAO.insertSelectiveMap(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            this.participanteDocDAO.insertSelectiveMap(Utilidades.transformFieldsToRealFormat(itemNew));
          }
              //rtineo mejoras, fin
          }
          catch (DataIntegrityViolationException e)
          {
            // itemNew.put("IND_DEL", 0);
        	//rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  this.participanteDocBatchDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            this.participanteDocDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
              }
            //rtineo mejoras, fin
            if (log.isWarnEnabled())
            {
              log.warn("El participante ya existe");
            }
          }
          /* olunar 009 - Actualizar en formbproveedor */
          Map<String, Object> pFormBP = new HashMap<String, Object>();
          pFormBP.put("numeroCorrelativo", itemNew.get("NUM_CORREDOC"));
          pFormBP.put("inddel", "0");
          pFormBP.put("NUM_SECINTERMEDIARIO", "0");
          List<DAV> listFormBP = formBProveedorDAO.findDAVByParams(pFormBP);
          if (listFormBP.size() > 0)
          {
            Map<String, Object> mapFormBProveedor = new HashMap();
            mapFormBProveedor.put("num_secintermediario", codigoParticipante);
            mapFormBProveedor.put("num_secprove", ((DAV) listFormBP.get(0)).getNumsecuprov());
            mapFormBProveedor.put("num_corredoc", itemNew.get("NUM_CORREDOC"));
        	//rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	formBProveedorBatchDAO.update(mapFormBProveedor);
            }else{
            formBProveedorDAO.update(mapFormBProveedor);
          }
            //rtineo mejoras, fin
          }
          /* fin */
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());
          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, true);
        }
          //rtineo mejoras, fin


          //region amancillaa SDA2-RIN18-PAS20171U220200035
          Map params = new HashMap();
          params.put("COD_TIPPARTIC",itemNew.get("COD_TIPPARTIC"));
          params.put("NUM_DOCIDENT",itemNew.get("NUM_DOCIDENT"));
          params.put("NUM_CORREDOC",itemNew.get("NUM_CORREDOC"));
          Map mapDeclara = ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual"));
          params.put("FEC_DECLARACION",mapDeclara.get("FEC_DECLARACION"));

          verificarCambioImportadorOEA(params);
          //endregion amancillaa
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {
            if (Comparador.isKeyEqual(itemOld, itemNew, mapClave))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //rtineo mejoras, grabacion para rectificacion desde web
                //region amancillaa SDA2-RIN18-PAS20171U220200035
                Map params = new HashMap();
                params.put("COD_TIPPARTIC",itemNew.get("COD_TIPPARTIC"));
                params.put("NUM_DOCIDENT",itemNew.get("NUM_DOCIDENT"));
                params.put("NUM_CORREDOC",itemNew.get("NUM_CORREDOC"));
                Map mapDeclara = ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual"));
                params.put("FEC_DECLARACION",mapDeclara.get("FEC_DECLARACION"));

                verificarCambioImportadorOEA(params);
                //endregion amancillaa
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	participanteDocBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                }else{
                participanteDocDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
              }
                //rtineo mejoras, fin
              }
            }
          }
        }
      }
    }
    return cont;
  }
  
  //PAS20171U220200031
  // grabar rectificacion del participante en ENDOSE (SE RECTIFICA AGENTE TIPO 41) 
  @Override
  public int grabarRectificacion2(String numCorredocSol, Map<String, Object> mapDatos,String tipoDiligencia)
  {
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin 
    Map<String, Object> mapDiferenciaGrabar;
    if (mapDatos.get(getNombreListaResultante()) != null)
    {

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {

        // agregamos razon social de la tabla ruc (tributos)
        obtenerRazonSocialParticipante(itemNew);
        if (log.isDebugEnabled())
        {
          cont++;
          log.debug(cont + " PARTICIPANTE_DOC :" + itemNew);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {

          Long codigoParticipante = new Long(ObjectUtils.toString(itemNew.get("NUM_SECPARTIC"), "0"));
          if (codigoParticipante.equals(0.0) || codigoParticipante.equals(new Long(0))) //cambio de german
          {
            String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
            codigoParticipante = sequenceDAO.getNextSequence(sequenceName);
            itemNew.put("NUM_SECPARTIC", codigoParticipante);
          }

          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  this.participanteDocBatchDAO.insertSelectiveMap(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            this.participanteDocDAO.insertSelectiveMap(Utilidades.transformFieldsToRealFormat(itemNew));
          }
              //rtineo mejoras, fin
          }
          catch (DataIntegrityViolationException e)
          {
            // itemNew.put("IND_DEL", 0);
        	//rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  this.participanteDocBatchDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            this.participanteDocDAO.update(Utilidades.transformFieldsToRealFormat(itemNew));
              }
            //rtineo mejoras, fin
            if (log.isWarnEnabled())
            {
              log.warn("El participante ya existe");
            }
          }
          /* olunar 009 - Actualizar en formbproveedor */
          Map<String, Object> pFormBP = new HashMap<String, Object>();
          pFormBP.put("numeroCorrelativo", itemNew.get("NUM_CORREDOC"));
          pFormBP.put("inddel", "0");
          pFormBP.put("NUM_SECINTERMEDIARIO", "0");
          List<DAV> listFormBP = formBProveedorDAO.findDAVByParams(pFormBP);
          if (listFormBP.size() > 0)
          {
            Map<String, Object> mapFormBProveedor = new HashMap();
            mapFormBProveedor.put("num_secintermediario", codigoParticipante);
            mapFormBProveedor.put("num_secprove", ((DAV) listFormBP.get(0)).getNumsecuprov());
            mapFormBProveedor.put("num_corredoc", itemNew.get("NUM_CORREDOC"));
        	//rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	formBProveedorBatchDAO.update(mapFormBProveedor);
            }else{
            formBProveedorDAO.update(mapFormBProveedor);
          }
            //rtineo mejoras, fin
          }
          /* fin */
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());
          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
          }else{
          registrarRectiOficio2(itemNew, numCorredocSol, true,tipoDiligencia);
        }
          //rtineo mejoras, fin
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {
            if (Comparador.isKeyEqual(itemOld, itemNew, mapClave))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	participanteDocBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                }else{
                participanteDocDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                registrarRectiOficio2(mapDiferenciaGrabar, numCorredocSol, false,tipoDiligencia);
              }
                //rtineo mejoras, fin
              }
            }
          }
        }
      }
    }
    return cont;
  }
  


  private void verificarCambioImportadorOEA(Map<String, Object> mapDiferenciaGrabar) {
    String codTipParticipante = mapDiferenciaGrabar.get("COD_TIPPARTIC")!=null?mapDiferenciaGrabar.get("COD_TIPPARTIC").toString():"";
    if("45".equals(codTipParticipante)){
      String numRuc = mapDiferenciaGrabar.get("NUM_DOCIDENT").toString().trim();

      Date fechaVigencia =   (Date) mapDiferenciaGrabar.get("FEC_DECLARACION");
     /// Date fechaVigencia =  new Date();  //fecha de evaluacion
      Long  numCorredocDua =   new Long(mapDiferenciaGrabar.get("NUM_CORREDOC").toString().trim());

      Map<String,Object> filter = new HashMap<String, Object>();
      filter.put("num_corredoc", numCorredocDua);
      filter.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);

      IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
      DatoIndicadores indicador = indicadorDUADAO.obtenerIndicadorDeclaracion(filter);

      if(((pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isOEA(numRuc,fechaVigencia)){

        if(indicador==null ){
          Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
          mapIndicadoresDUA.put("numCorredoc", numCorredocDua);
          mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
          mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);

          indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
          }else{

          if (ConstantesDataCatalogo.IND_INACTIVO.equals(indicador.getIndicadorActivo())){

            Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
            mapIndicadoresDUA.put("numCorredoc",numCorredocDua);
            mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
            mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);
            mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_ACTIVO);
            indicadorDUADAO.update(mapIndicadoresDUA);
        }
        }
                }else{
        if(indicador!=null && ConstantesDataCatalogo.IND_ACTIVO.equals(indicador.getIndicadorActivo())){

          Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
          mapIndicadoresDUA.put("numCorredoc",numCorredocDua);
          mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
          mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);
          mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_INACTIVO);
          indicadorDUADAO.update(mapIndicadoresDUA);
        }
      }
    }
  }
  
	/**
	 * verificamos que se este cambiando el numero de documento de identifdad "RUC" 
	 * si es asi verificar que exista dicho ruc en la tabla RUC informix si existe y no se envio la razon social agregar campo razon social
	 * @param objKey string en formato json donde se encuentra el pk del participante 
	 * @param objDatos datos a ser modificados en la tabal participante
	 * @return retorna la razon social del particiapnte de lo contrario retorna null
	 */
  private String obtenerRazonSocialParticipante(Map<String, Object> participanteModificado)
  {

    String razonSocial = null;

    Map rptaRuc = new HashMap();
    if ("4".equals(ObjectUtils.toString(participanteModificado.get("COD_TIPDOC"), "").trim()))
    {

      rptaRuc = new HashMap();
//      rptaRuc = pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl.getInstance()
//          .getDdpDAO().findByPK((String) participanteModificado.get("NUM_DOCIDENT"), true);// gmontoya
//                                                                                           // diligencia
//                                                                                           // 2012
      rptaRuc = ddpDAOService.findByPK((String) participanteModificado.get("NUM_DOCIDENT"), true);
      
      if (rptaRuc != null && !rptaRuc.isEmpty())
      {
        participanteModificado.put("NOM_RAZONSOCIAL", rptaRuc.get("ddp_nombre") != null ? rptaRuc.get("ddp_nombre")
            .toString() : participanteModificado.get("NOM_RAZONSOCIAL"));
        participanteModificado.put("DIR_PARTIC", rptaRuc.get("direccion_desc") != null ? rptaRuc.get("direccion_desc")
            .toString() : participanteModificado.get("DIR_PARTIC"));
        participanteModificado.put("DES_UBIGEOCIUDAD", rptaRuc.get("dist_desc") != null ? rptaRuc.get("dist_desc")
            .toString() : participanteModificado.get("DES_UBIGEOCIUDAD"));
      }
    }

    return razonSocial;
    /*
     * necesita mas coordinacion y trabajo
     * if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "92")){
     * actualizacionDinamica=true; for(DAV dav:declaracion.getListDAVs()){
     * if(dav.getPersonaDecl().getNumeroDocumentoIdentidad() !=null &&
     * SunatStringUtils
     * .isEqualTo(dav.getPersonaDecl().getNumeroDocumentoIdentidad(),
     * (String)key.get("NUM_DOCIDENT"))){
     * 
     * Map<String,Object> params=new HashMap<String, Object>();
     * params.put("NUM_CORREDOC",(String)key.get("NUM_CORREDOC"));
     * params.put("NUM_SECPROVE",dav.getNumsecuprov()); List<Map<String,Object>>
     * lstFormPrB= formBProveedorDAO.select(params); Map<String,Object>
     * mpFormProb=lstFormPrB.get(0);
     * 
     * key.put("NUM_SECPARTIC", mpFormProb.get("NUM_SECDECLARANTE").toString());
     * 
     * 
     * } }
     * 
     * }
     */

  }

  private void updateParticipanteInCabdeclaraActual(Map<String, Object> mapCabDeclara, List lstParticipante)
  {

    for (Object objParticipante : lstParticipante)
    {
      Map<String, Object> participante = (Map<String, Object>) objParticipante;
      String tipoDocValue = ObjectUtils.toString(participante.get("COD_TIPDOC"), "");
      String numDocValue = ObjectUtils.toString(participante.get("NUM_DOCIDENT"), "");
      ;
      // si el registro va a ser eliminado no se toma en cuenta
      if (!"1".equals(ObjectUtils.toString(participante.get("IND_DEL"), "0")))
      {

        if (COD_TIPO_IMPORTADOR.equals(ObjectUtils.toString(participante.get("COD_TIPPARTIC"), "")))
        {
          mapCabDeclara.put("COD_TIPDOC_PIM", tipoDocValue);
          mapCabDeclara.put("NUM_DOCIDENT_PIM", numDocValue);
        }

        if ((COD_TIPO_TRANSPORTISTA_LOCAL.equals(ObjectUtils.toString(participante.get("COD_TIPPARTIC"), "")))
            || (COD_TIPO_TRANSPORTISTA_REPRESENTANTE
                .equals(ObjectUtils.toString(participante.get("COD_TIPPARTIC"), ""))))
        {
          mapCabDeclara.put("COD_TIPDOC_PTR", tipoDocValue);
          mapCabDeclara.put("NUM_DOCIDENT_PTR", numDocValue);
        }

        if (COD_TIPO_DEPOSITO_TEMPORAL.equals(ObjectUtils.toString(participante.get("COD_TIPPARTIC"), "")))
        {
          mapCabDeclara.put("COD_TIPDOC_PDF", tipoDocValue);
          mapCabDeclara.put("NUM_DOCIDENT_PDF", numDocValue);
        }

        if (COD_TIPO_AGENTE_ADUANA.equals(ObjectUtils.toString(participante.get("COD_TIPPARTIC"), "")))
        {
          mapCabDeclara.put("COD_TIPDOC_PDE", tipoDocValue);
          mapCabDeclara.put("NUM_DOCIDENT_PDE", numDocValue);
        }
      }
    }

  }

	@Override
	protected void insertRecord(Map<String, Object> newRecordMap) {
		//participante doc tiene su propia implementacion de grabar rectificacion
		
	}

	@Override
	protected void updateRecord(Map<String, Object> updateRecordMap) {
		//participante doc tiene su propia implementacion de grabar rectificacion
		
	}

	@Override
	protected void insertRecordBatch(Map<String, Object> newRecordMap) {
		//participante doc tiene su propia implementacion de grabar rectificacion
		
	}

	@Override
	protected void updateRecordBatch(Map<String, Object> updateRecordMap) {
		//participante doc tiene su propia implementacion de grabar rectificacion
		
	}
	
	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
	//rtineo mejoras, grabacion en batch
	  public ParticipanteDocBatchDAO getParticipanteDocBatchDAO() {
		return participanteDocBatchDAO;
	  }
	
	  public void setParticipanteDocBatchDAO(
			ParticipanteDocBatchDAO participanteDocBatchDAO) {
		this.participanteDocBatchDAO = participanteDocBatchDAO;
	  }

	  public FormBProveedorBatchDAO getFormBProveedorBatchDAO() {
		return formBProveedorBatchDAO;
	  }

	  public void setFormBProveedorBatchDAO(
			FormBProveedorBatchDAO formBProveedorBatchDAO) {
		this.formBProveedorBatchDAO = formBProveedorBatchDAO;
	  }	
	  //rtineo mejoras, fin
}
