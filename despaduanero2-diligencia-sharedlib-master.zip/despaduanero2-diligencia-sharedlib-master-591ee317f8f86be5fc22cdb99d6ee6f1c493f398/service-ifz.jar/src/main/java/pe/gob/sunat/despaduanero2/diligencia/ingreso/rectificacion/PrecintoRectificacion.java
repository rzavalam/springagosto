package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.MovEquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.PrecintoDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;

public class PrecintoRectificacion extends RectificacionAbstract implements Serializable
{
	
	  private static final long   serialVersionUID        = 6617619894003418444L;

	  private static final String NOMBRE_LISTA_ORIGINAL   = "lstPrecinto";

	  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

	  private PrecintoDAO     precintoDAO;
	  
	  private MovEquipamientoDAO movEquipamientoDAO;
	  
	  private ParticipanteDocDAO   participanteDocDAO;

	public PrecintoRectificacion() {
		
		 mapClave = new HashMap<String, Object>();
		 mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
		 mapClave.put("NUM_EQUIPAMIENTO","NUM_EQUIPAMIENTO");
		 mapClave.put("NUM_PRECINTO", "NUM_PRECINTO");
		//INC 2017-044649 AMANCILLA
		 mapClave.put("COD_TIPMOV", "COD_TIPMOV");

	}

	
		  @Override
		  protected Map<String, Object> getDatosInicialesRectifacion(
		      Map<String, Object> mapResultado,
		      Map<String, Object> mapValores)
		  {
		    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
		    return mapResultado;
		  }

		  @Override
		  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
		  {
		    Map<String, Object> mapParametros = new HashMap<String, Object>();
		    // Se recupera por Documento los valores
		    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
			  //INC 2017-044649 AMANCILLA
			  mapParametros.put("COD_TIPMOV", "99");
		    return precintoDAO.select(parametros);
		   // return null;
		  }

		@Override
		protected void insertRecord(Map<String, Object> newRecordMap) {
			// TODO Auto-generated method stub
			precintoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
		}
	
		@Override
		protected void updateRecord(Map<String, Object> updateRecordMap) {
			// TODO Auto-generated method stub
			precintoDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));
			
			
		}

		@Override
		protected String getNombreListaOriginal() {
			// TODO Auto-generated method stub
			return NOMBRE_LISTA_ORIGINAL;
		}
	
		@Override
		protected String getNombreListaResultante() {
			// TODO Auto-generated method stub
			 return NOMBRE_LISTA_RESULTANTE;
		}
	
		@Override
		protected String getCodTablaRectificacion() {
			// TODO Auto-generated method stub
			 return Constantes.COD_TABLA_PRECINTO;
		}


		public PrecintoDAO getPrecintoDAO() {
			return precintoDAO;
		}


		public void setPrecintoDAO(PrecintoDAO precintoDAO) {
			this.precintoDAO = precintoDAO;
		}
		
		  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
		  {
		    int cont = 0;

		    Map<String, Object> mapDiferenciaGrabar;
		    if (mapDatos.get(getNombreListaResultante()) != null)
		    {
		      cont = 0;
		      List<Participante> listaConsignatario = null;
		      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
		      { 
		    	 
		        if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
		        {
		          itemNew.put("IND_DEL", 1);
		        }
		        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
		        {
		        	itemNew.put("IND_DEL", 0);
			          try
			          {
			        	  
			        	itemNew.put("COD_TIPMOV", 99);
			        	if(listaConsignatario==null){
			    		Map<String, Object> mapParticipante = new HashMap<String, Object>();
			    		mapParticipante.put("numeroCorrelativo", itemNew.get("NUM_CORREDOC"));
			    		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
			    		mapParticipante.put("tipoDocumentoIdentidad", Constantes.TIPO_DOC_RUC);
			    		listaConsignatario = this.participanteDocDAO.listByParameterMap(mapParticipante);
				    		if(listaConsignatario.size()>0){
				    			itemNew.put("NUM_SECPARTIC",listaConsignatario.get(0).getSecuenciaDeParticipantes());
				    		}
			        	}else{
			        		if(listaConsignatario.size()>0){
				    			itemNew.put("NUM_SECPARTIC",listaConsignatario.get(0).getSecuenciaDeParticipantes());
				    		}
			        	}
			    		
			        	movEquipamientoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(itemNew));
			            cont++;
			          }
			          catch (DataIntegrityViolationException e)
			          {
			            if (log.isWarnEnabled())
			            {
			              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
			            }
			            // Si el registro ya existe se activa el registro y se actualiza
			            movEquipamientoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(itemNew));
			          }
		        	
		        	
		          
		          try
		          {
		        	  
		        	  
		            insertRecord(Utilidades.transformFieldsToRealFormat(itemNew));
		            cont++;
		          }
		          catch (DataIntegrityViolationException e)
		          {
		            if (log.isWarnEnabled())
		            {
		              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
		            }
		            // Si el registro ya existe se activa el registro y se actualiza
		            updateRecord(Utilidades.transformFieldsToRealFormat(itemNew));
		          }
		          // grabamos en ofirecti
		          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());         
		          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
		          itemNew.put("clave", mapTmpPK);
		          registrarRectiOficio(itemNew, numCorredocSol, true);
		          continue;
		        }
		        else
		        {
		          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
		          {

		            if (Comparador.isKeyEqual(itemOld, itemNew, getMapClave()))
		            {
		              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, getMapClave());
		              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
		                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
		              {
		                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
		                {
		                  mapDiferenciaGrabar.put("IND_DEL", 1);
		                }
		                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
		                     
		                updateRecord(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
		                movEquipamientoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(itemNew));
		                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
		                cont++;
		              }
		            }
		          }
		        }
		      }
		    }
		    return cont;
		  }


		public MovEquipamientoDAO getMovEquipamientoDAO() {
			return movEquipamientoDAO;
		}


		public void setMovEquipamientoDAO(MovEquipamientoDAO movEquipamientoDAO) {
			this.movEquipamientoDAO = movEquipamientoDAO;
		}


		public ParticipanteDocDAO getParticipanteDocDAO() {
			return participanteDocDAO;
		}


		public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO) {
			this.participanteDocDAO = participanteDocDAO;
		}
	  

		@Override
		protected void insertRecordBatch(Map<String, Object> newRecordMap) {
			// TODO Auto-generated method stub
			
		}


		@Override
		protected void updateRecordBatch(Map<String, Object> updateRecordMap) {
			// TODO Auto-generated method stub
			
		}
	  

}
