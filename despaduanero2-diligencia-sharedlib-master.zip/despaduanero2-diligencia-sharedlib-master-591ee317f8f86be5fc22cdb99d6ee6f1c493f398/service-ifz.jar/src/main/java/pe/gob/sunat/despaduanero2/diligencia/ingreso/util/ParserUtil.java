package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;



import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * <p>Titulo: Clase Utilitaria ParserUtil.</p>
 * <p>Descripcion: Clase que nos permite cambiar los keys de los maps retirando los prefijos html, asi como casteo de objetos desde un String teniendo en cuenta un tipo de dato</p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ParserUtil.java</p>
 * <p>Copyright: SUNAT-2011</p>
 *
 * @version 1.0
 */
public class ParserUtil {


    /**
     * Permite retirar desde una cadena origen los prefijos HTML que posea
     * @param cadena
     * @return
     */
    public static String obtenerCadenaSinPrefijo(String cadenaOrigen){
        if(!StringUtils.isEmpty(cadenaOrigen) && cadenaOrigen.length()>3){
            String cadena = new String(cadenaOrigen);

            if(EnumPrefijoHTML.INPUT_TEXT.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_TEXT.getPrefijo().length()))){
                return cadena.toUpperCase().substring(EnumPrefijoHTML.INPUT_TEXT.getPrefijo().length());
            }
            if(EnumPrefijoHTML.INPUT_HIDDEN.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_HIDDEN.getPrefijo().length()))){
                return cadena.substring(EnumPrefijoHTML.INPUT_HIDDEN.getPrefijo().length());
            }
            if(EnumPrefijoHTML.INPUT_CHECKBOX.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_CHECKBOX.getPrefijo().length()))){
                return cadena.substring(EnumPrefijoHTML.INPUT_CHECKBOX.getPrefijo().length());
            }
            if(EnumPrefijoHTML.INPUT_TEXT_AREA.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_TEXT_AREA.getPrefijo().length()))){
                return cadena.substring(EnumPrefijoHTML.INPUT_TEXT_AREA.getPrefijo().length());
            }
            if(EnumPrefijoHTML.INPUT_RADIO.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_RADIO.getPrefijo().length()))){
                return cadena.substring(EnumPrefijoHTML.INPUT_RADIO.getPrefijo().length());
            }
            if(EnumPrefijoHTML.INPUT_SELECT.getPrefijo().toUpperCase().equals(cadena.toUpperCase().substring(0, EnumPrefijoHTML.INPUT_SELECT.getPrefijo().length()))){
                return cadena.substring(EnumPrefijoHTML.INPUT_SELECT.getPrefijo().length());
            }
        }
        return cadenaOrigen;
    }

    /**
     * Permite devolver el identificador concatenandolo con el prefijo Html a usar.
     * @param cadenaIdentificadorVista
     * @param enumPrefijoHTML
     * @return
     */
    public static String obtenerCadenaConPrefijo(String cadenaIdentificadorVista,EnumPrefijoHTML enumPrefijoHTML){
        if(!StringUtils.isEmpty(cadenaIdentificadorVista)){
            return new String(enumPrefijoHTML.getPrefijo().concat(cadenaIdentificadorVista));
        }
        return cadenaIdentificadorVista;
    }

    /**
     * Permite obtener un mapa con sus keys sin los prefijos html.
     *
     * @param mapOrigen [Map<String,Object>] map origen
     * @return  [Map<String,Object>] map
     * @author  amancilla
     * @version 1.0
     */
    public static Map<String, Object> obtenerMapSinPrefijo( Map<String, Object> mapOrigen){
        Map<String, Object> mapResultado= new HashMap<String, Object>();
        if(!CollectionUtils.isEmpty(mapOrigen)){
            for(Entry<String, Object> entrada: mapOrigen.entrySet()){
                mapResultado.put(obtenerCadenaSinPrefijo(entrada.getKey()), entrada.getValue());
            }
        }
        return mapResultado;
    }

    //Parseo Objetos Java

    /**
     * Metodo que obtiene un Objeto a partir del tipo de dato y un valor ambos en String
     * @param valorDato
     * @param tipoDato
     * @param formatoDato
     * @return
     */
  public static Object obtenerObjeto(Object valorDato, String tipoDato, String formatoDato) {
    Object valor = null;
    if (tipoDato.equals("java.lang.Integer")) {
      if (valorDato instanceof java.lang.Integer) {
        valor = new Integer((Integer) valorDato);
      } else {// if(valorDato instanceof java.lang.String){
        valor = new Integer(valorDato.toString().trim());
      }
    } else if (tipoDato.equals("java.lang.Long")) {
      if (valorDato instanceof java.lang.Long) {
        valor = new Long((Long) valorDato);
      }else{ //en los JSP los datos se envian con decimales instancias de BigDecimal por ello usamos SunatNumberUtils.toLong(
        valor = Utilidades.toLong(valorDato);
      }
    } else if (tipoDato.equals("java.lang.String")) {
      // Se agrego ante la casuistica que se recogia los datos del request tal cual y se envian al service sin
      // considerar que al usar la funcionalidad addAll(Map) los parametros del request eran considerados arrays de
      // String
      if (valorDato instanceof String[]) {
        valor = new String(((String[]) valorDato)[0]);
      } else {
        valor = new String(valorDato.toString());
      }
    } else if (tipoDato.equals("java.util.Date")) {
      if (StringUtils.isEmpty(formatoDato)) {
        // si no se posee formato se usa el por default de fechaBean
        if (valorDato instanceof java.util.Date) {
          valor = (java.util.Date) valorDato;
        } else {// if(valorDato instanceof java.lang.String){
          if(EnumTagsXmlMapping.SYSDATE.getIdentificadorXML().equals(valorDato.toString().trim())){
            valor = new java.util.Date();
          }else{
            valor = (java.util.Date)Utilidades.toDate(valorDato.toString().trim());
            //valor = new java.util.Date((new FechaBean(valorDato.toString().trim())).getSQLDate().getTime());
          }
        }
      } else {
        // consideramos el formato enviado
        if (valorDato instanceof java.util.Date) {
          valor = (java.util.Date) valorDato;
        } else {// if(valorDato instanceof java.lang.String){
          if(EnumTagsXmlMapping.SYSDATE.getIdentificadorXML().equals(valorDato.toString().trim())){
            valor = new java.util.Date();
          }else{
               //parche si viene del JSON de TMP_recti_oficio no soporta esta formato que es string 2013-07-15 00:00:00.0
            valor = (java.util.Date)Utilidades.toDate(valorDato.toString().trim());
            //valor = new Date((new FechaBean(valorDato.toString().trim(), formatoDato)).getSQLDate().getTime());
          }
        }
      }
    } else if (tipoDato.equals("java.sql.Date")) {
      if (StringUtils.isEmpty(formatoDato)) {
        // si no se posee formato se usa el por default de fechaBean
        if (valorDato instanceof java.sql.Date) {
          valor = (java.sql.Date) valorDato;
        } else {// if(valorDato instanceof java.lang.String){
          if(EnumTagsXmlMapping.SYSDATE.getIdentificadorXML().equals(valorDato.toString().trim())){
            valor = new java.sql.Date((new java.util.Date()).getTime());
          }else{
            valor = (new FechaBean(valorDato.toString().trim())).getSQLDate();
          }
        }
      } else {
        // consideramos el formato enviado
        if (valorDato instanceof java.sql.Date) {
          valor = (java.sql.Date) valorDato;
        } else {// if(valorDato instanceof java.lang.String){
          if(EnumTagsXmlMapping.SYSDATE.getIdentificadorXML().equals(valorDato.toString().trim())){
            valor = new java.sql.Date((new java.util.Date()).getTime());
          }else{
            valor = (new FechaBean(valorDato.toString().trim(), formatoDato)).getSQLDate();
          }
        }
      }
    } else if (tipoDato.equals("java.math.BigDecimal")) {
      if (valorDato instanceof java.math.BigDecimal) {
        valor = (BigDecimal) valorDato;
      } else {// if(valorDato instanceof java.lang.String){
        valor = Utilidades.toBigDecimal(valorDato);
      }
    } else if (tipoDato.equals("java.lang.Double")) {
      if (valorDato instanceof java.lang.Double) {
        valor = (Double) valorDato;
      } else {// if(valorDato instanceof java.lang.String){
        valor = new Double(valorDato.toString().trim());
      }
    } else if (tipoDato.equals("java.math.BigInteger")) {
      if (valorDato instanceof java.math.BigInteger) {
        valor = (BigInteger) valorDato;
      } else {// if(valorDato instanceof java.lang.String){
        valor = Utilidades.toBigDecimal(valorDato);
      }
    }
    return valor;
  }

/*RIN13FSW*/
  /**
   * Metodo que convierte el monto de dinero a TRES decimales.
   * @param monto
   * @return
   * @autor rcalles
   */
  public static String formatoDineroTresDecimales(double monto){	   
	DecimalFormatSymbols simbolos = new DecimalFormatSymbols();
	simbolos.setDecimalSeparator(Constantes.DECIMAL_SEPARADOR_PUNTO);
	simbolos.setGroupingSeparator(Constantes.GRUPO_SEPARADOR_COMA);
	DecimalFormat df = new DecimalFormat(",##0.000", simbolos);		
	return df.format(monto);
 }



}
