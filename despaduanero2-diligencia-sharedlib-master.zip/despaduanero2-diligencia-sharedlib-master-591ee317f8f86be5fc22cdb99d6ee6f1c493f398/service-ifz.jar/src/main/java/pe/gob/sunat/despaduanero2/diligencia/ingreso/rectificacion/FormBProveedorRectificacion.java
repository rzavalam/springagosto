package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DescripcionOtroCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescripOtrosDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.Participante;


/**
 * 
 * @author fjonislla
 * 
 */
public class FormBProveedorRectificacion extends RectificacionAbstract implements Serializable
{

  private static final String SUFIJO_CONSIGNATARIO    = "_PIM";

  private static final String SUFIJO_INTERMEDIARIO    = "_PRI";

  private static final String SUFIJO_DECLARANTE       = "_PRD";

  private static final String SUFIJO_PROVEEDOR_LOCAL  = "_PRL";

  private static final String SUFIJO_PROVEEDOR        = "_PRV";

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -636080152608393377L;

  public static final String  NOMBRE_LISTA_ORIGINAL   = "lstFormBProveedor";

  public static final String  NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FormBProveedorDAO   formBProveedorDAO;
  
//Hajalcri�a
  private DescripOtrosDAO descripOtrosDAO;

  //rtineo mejoras, grabacion en batch
  private FormBProveedorBatchDAO formBProveedorBatchDAO;

  public FormBProveedorRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return formBProveedorDAO.select(mapParametros);
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  @Override
  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FORMB_PROVEEDOR;
  }

  public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
  {
    this.formBProveedorDAO = formBProveedorDAO;
  }

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    Comparador comparador = new Comparador();
    Map<String, Object> mapDiferenciaGrabar;
    int count = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin  
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      for (Map<String, Object> mapFormBProveedor : (ArrayList<Map<String, Object>>) mapDatos
          .get(getNombreListaResultante()))
      {
//        if (log.isDebugEnabled())
//        {
//
//          log.debug(" mapFormBProveedor:" + mapFormBProveedor);
//        }
        if (INDICADOR_NUEVO_REGISTRO.equals(mapFormBProveedor.get("indica")))
        {

          try
          {
        	//rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  formBProveedorBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapFormBProveedor));
              }else{
            	  formBProveedorDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapFormBProveedor));
            	  if (mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO") != null) {
            		    DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
	              		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
	              		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
	              		descripcionOtroCatalogo.setCodTabla("T0070");
	              		descripcionOtroCatalogo.setCodCampo("COD_MEDIO_PAGO");
	              		descripcionOtroCatalogo.setCodCatalogo("147");
	              		descripcionOtroCatalogo.setCodValor("14");
	              		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO").toString());
	              		descripOtrosDAO.insert(descripcionOtroCatalogo);
            	  }
            	  if (mapFormBProveedor.get("DES_OTRO_ENTI_FINANC") != null) {
            		    DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
	              		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
	              		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
	              		descripcionOtroCatalogo.setCodTabla("T0070");
	              		descripcionOtroCatalogo.setCodCampo("COD_ENTI_FINANC");
	              		descripcionOtroCatalogo.setCodCatalogo("148");
	              		descripcionOtroCatalogo.setCodValor("99");
	              		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_ENTI_FINANC").toString());
	              		descripOtrosDAO.insert(descripcionOtroCatalogo);
            	  }
              }
              //rtineo mejoras, fin
            count++;
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isWarnEnabled())
            {
              log.warn("EL formBProveedor ya existe se procede a actualizarlo con IND_DEL=0");
            }

            mapFormBProveedor.put("IND_DEL", 0);
        	//rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	formBProveedorBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapFormBProveedor));
            }else{
            	formBProveedorDAO.update(Utilidades.transformFieldsToRealFormat(mapFormBProveedor));
            	// Grabacion de otro tipo de medio de pago
            	if (mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO") != null) {
            		descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
            		Map<String,Object> mapUpdate=new HashMap<String, Object>();
            		mapUpdate.put("NUM_CORREDOC",mapFormBProveedor.get("NUM_CORREDOC"));
            		mapUpdate.put("NUM_SECDOC",mapFormBProveedor.get("NUM_SECPROVE"));
            		mapUpdate.put("COD_TABLA","T0070");
            		mapUpdate.put("COD_CAMPO","COD_MEDIO_PAGO");
            		mapUpdate.put("COD_CATALOGO","147");
            		mapUpdate.put("COD_VALOR","14");
            		mapUpdate.put("DES_VALOR",mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO").toString());
            		List<Map<String, Object>> lstResulDescriOtros = descripOtrosDAO.select(mapUpdate);
            		if (lstResulDescriOtros == null || lstResulDescriOtros.size()==0) {
            			DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
                		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
                		descripcionOtroCatalogo.setCodTabla("T0070");
                		descripcionOtroCatalogo.setCodCampo("COD_MEDIO_PAGO");
                		descripcionOtroCatalogo.setCodCatalogo("147");
                		descripcionOtroCatalogo.setCodValor("14");
                		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO").toString());
                		descripOtrosDAO.insert(descripcionOtroCatalogo);
            		} else {
            			descripOtrosDAO.updateSelective(mapUpdate);
                	} 
            	}
            	if (mapFormBProveedor.get("DES_OTRO_ENTI_FINANC") != null) {
            		// Grabacion de otra entidad financiera
    	            descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
    	            Map<String,Object> mapUpdate2=new HashMap<String, Object>();
            		mapUpdate2.put("NUM_CORREDOC",mapFormBProveedor.get("NUM_CORREDOC"));
            		mapUpdate2.put("NUM_SECDOC",mapFormBProveedor.get("NUM_SECPROVE"));
            		mapUpdate2.put("COD_TABLA","T0070");
            		mapUpdate2.put("COD_CAMPO","COD_ENTI_FINANC");
            		mapUpdate2.put("COD_CATALOGO","148");
            		mapUpdate2.put("COD_VALOR","99");
            		mapUpdate2.put("DES_VALOR",mapFormBProveedor.get("DES_OTRO_ENTI_FINANC").toString());
            		List<Map<String, Object>> lstResulDescriOtros = descripOtrosDAO.select(mapUpdate2);
            		if (lstResulDescriOtros == null || lstResulDescriOtros.size()==0) {
            			DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
                		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
                		descripcionOtroCatalogo.setCodTabla("T0070");
                		descripcionOtroCatalogo.setCodCampo("COD_ENTI_FINANC");
                		descripcionOtroCatalogo.setCodCatalogo("148");
                		descripcionOtroCatalogo.setCodValor("99");
                		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_ENTI_FINANC").toString());
                		descripOtrosDAO.insert(descripcionOtroCatalogo);
            		} else {
            			descripOtrosDAO.updateSelective(mapUpdate2);
            		}
            	}
          }
            //rtineo mejoras, fin
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(mapFormBProveedor, getMapClave());
          mapFormBProveedor.put("dataOriginal", new HashMap<String, Object>(mapFormBProveedor));
          mapFormBProveedor.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(mapFormBProveedor, numCorredocSol, true);
          }else{
          registrarRectiOficio(mapFormBProveedor, numCorredocSol, true);
          }
          //rtineo mejoras, fin
          continue;
        }
        else
        {
          for (Map<String, Object> mapFormBProveedorAntes : (ArrayList<Map<String, Object>>) mapDatos
              .get(getNombreListaOriginal()))
          {
            if (mapFormBProveedorAntes.get("NUM_SECPROVE").toString().trim()
                .equals(mapFormBProveedor.get("NUM_SECPROVE").toString().trim()))
            {
              mapDiferenciaGrabar = comparador.comparaMap(mapFormBProveedorAntes, mapFormBProveedor, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                // insertamos el codigo de la tabla
                Map<String, Object> mapProvisional = new HashMap<String, Object>();
                for (Entry<String, Object> entrada : mapFormBProveedor.entrySet())
                {
                  mapProvisional.put(entrada.getKey().toLowerCase(), entrada.getValue());
                }
                // formBProveedorDAO.update(mapFormBProveedor); //habilitar
                // cuando DILIGENCIA cambie a mayusculas los parametros del
                // metodo UPDATE en el xml
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	formBProveedorBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapProvisional));
                    registrarRectiOficioBatch(mapFormBProveedor, numCorredocSol, false);
                }else{
                	formBProveedorDAO.update(Utilidades.transformFieldsToRealFormat(mapProvisional));
                	// Grabacion de otro tipo de medio de pago
                	if (mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO") != null) {
                		descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
                		Map<String,Object> mapUpdate=new HashMap<String, Object>();
                		mapUpdate.put("NUM_CORREDOC",mapFormBProveedor.get("NUM_CORREDOC"));
                		mapUpdate.put("NUM_SECDOC",mapFormBProveedor.get("NUM_SECPROVE"));
                		mapUpdate.put("COD_TABLA","T0070");
                		mapUpdate.put("COD_CAMPO","COD_MEDIO_PAGO");
                		mapUpdate.put("COD_CATALOGO","147");
                		mapUpdate.put("COD_VALOR","14");
                		mapUpdate.put("DES_VALOR",mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO").toString());
                		List<Map<String, Object>> lstResulDescriOtros = descripOtrosDAO.select(mapUpdate);
                		if (lstResulDescriOtros == null || lstResulDescriOtros.size()==0) {
                			DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                    		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
                    		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
                    		descripcionOtroCatalogo.setCodTabla("T0070");
                    		descripcionOtroCatalogo.setCodCampo("COD_MEDIO_PAGO");
                    		descripcionOtroCatalogo.setCodCatalogo("147");
                    		descripcionOtroCatalogo.setCodValor("14");
                    		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_MEDIO_PAGO").toString());
                    		descripOtrosDAO.insert(descripcionOtroCatalogo);
                		} else {
                			descripOtrosDAO.updateSelective(mapUpdate);
                    	} 
                	}
                	
    	            // Grabacion de otra entidad financiera
                	if (mapFormBProveedor.get("DES_OTRO_ENTI_FINANC") != null) {
                		descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
        	            Map<String,Object> mapUpdate2=new HashMap<String, Object>();
                		mapUpdate2.put("NUM_CORREDOC",mapFormBProveedor.get("NUM_CORREDOC"));
                		mapUpdate2.put("NUM_SECDOC",mapFormBProveedor.get("NUM_SECPROVE"));
                		mapUpdate2.put("COD_TABLA","T0070");
                		mapUpdate2.put("COD_CAMPO","COD_ENTI_FINANC");
                		mapUpdate2.put("COD_CATALOGO","148");
                		mapUpdate2.put("COD_VALOR","99");
                		mapUpdate2.put("DES_VALOR",mapFormBProveedor.get("DES_OTRO_ENTI_FINANC").toString());
                		List<Map<String, Object>> lstResulDescriOtros = descripOtrosDAO.select(mapUpdate2);
                		if (lstResulDescriOtros == null || lstResulDescriOtros.size()==0) {
                			DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                    		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(mapFormBProveedor.get("NUM_CORREDOC").toString()));
                    		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(mapFormBProveedor.get("NUM_SECPROVE").toString()));
                    		descripcionOtroCatalogo.setCodTabla("T0070");
                    		descripcionOtroCatalogo.setCodCampo("COD_ENTI_FINANC");
                    		descripcionOtroCatalogo.setCodCatalogo("148");
                    		descripcionOtroCatalogo.setCodValor("99");
                    		descripcionOtroCatalogo.setDesValor(mapFormBProveedor.get("DES_OTRO_ENTI_FINANC").toString());
                    		descripOtrosDAO.insert(descripcionOtroCatalogo);
                		} else {
                			descripOtrosDAO.updateSelective(mapUpdate2);
                		}
                	}
                	
                	registrarRectiOficio(mapFormBProveedor, numCorredocSol, false);
                }
                //rtineo mejoras, fin
                count++;
              }
              break;
            }
          }
        }
      }
    }
    return count;
  }

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#getTableRectificadoMergedBD(java.util.Map,
   * java.lang.Long, boolean)
   */
  // agregamos la razon socila del participante
  @Override
  public List<Map<String, Object>> getTableRectificadoMergedBD(
      Map<String, Object> parametrosBd,
      Long numeroCorrelativoSolicitud,
      boolean mergeRectificados)
  {
    List<Map<String, Object>> resultProveedor = super.getTableRectificadoMergedBD(parametrosBd,
        numeroCorrelativoSolicitud, mergeRectificados);

    RectificacionAbstract rectifiParticipante = fabricaDeServicios.getService("diligencia.rectificacion.codtabla."
        + Constantes.COD_TABLA_PARTICIPANTE_DOC);
    List<Map<String, Object>> lstParticipante = rectifiParticipante.getTableRectificadoMergedBD(parametrosBd,
        numeroCorrelativoSolicitud, mergeRectificados);
    // Agregamos la razon social al proveedor
    Iterator<Map<String, Object>> itLstProveedor = resultProveedor.iterator();
    while (itLstProveedor.hasNext())
    {
      Map<String, Object> proveedor = itLstProveedor.next();

      final Map<String, Object> participantePk = new HashMap<String, Object>();

      // buscamos la informacion del proveedor
      participantePk.put("NUM_SECPARTIC", proveedor.get("NUM_CODSECPROVE"));
      participantePk.put("NUM_CORREDOC", proveedor.get("NUM_CORREDOC"));
      Map<String, Object> mapProveedor = buscarParticipante(lstParticipante, participantePk, SUFIJO_PROVEEDOR);

      String indicadorRectificadoFormbProveedor = (String) proveedor.get("IND_RECTIFICA");
      String indicadorRectificadoProveedorParticipante = (String) mapProveedor.get("IND_RECTIFICA");

      // seteamos el indicador de rectificado
      setIndicadorRectificado(mapProveedor, indicadorRectificadoProveedorParticipante,
          indicadorRectificadoFormbProveedor);
      proveedor.putAll(mapProveedor);

      // buscamos la informacion del proveedor local
      participantePk.clear();
      participantePk.put("COD_TIPDOC", ObjectUtils.toString(proveedor.get("COD_DOCPROVLOCAL"), "").trim());
      participantePk.put("NUM_DOCIDENT", ObjectUtils.toString(proveedor.get("COD_DOCIDENTPROVLOC"), "").trim());
      participantePk.put("COD_TIPPARTIC", "91");
      participantePk.put("NUM_CORREDOC", proveedor.get("NUM_CORREDOC"));
      proveedor.putAll(buscarParticipante(lstParticipante, participantePk, SUFIJO_PROVEEDOR_LOCAL));

      // buscamos la informacion del declarante
      participantePk.clear();
      participantePk.put("NUM_SECPARTIC", ObjectUtils.toString(proveedor.get("NUM_SECDECLARANTE"), "").trim());
      participantePk.put("NUM_CORREDOC", proveedor.get("NUM_CORREDOC"));
      proveedor.putAll(buscarParticipante(lstParticipante, participantePk, SUFIJO_DECLARANTE));

      // buscamos la informacion del intermediario
      participantePk.clear();
      participantePk.put("NUM_SECPARTIC", ObjectUtils.toString(proveedor.get("NUM_SECINTERMEDIARIO"), "").trim());
      participantePk.put("NUM_CORREDOC", proveedor.get("NUM_CORREDOC"));
      proveedor.putAll(buscarParticipante(lstParticipante, participantePk, SUFIJO_INTERMEDIARIO));

      // buscamos la informacion del consignatario
      participantePk.clear();
      participantePk.put("COD_TIPPARTIC", "45");
      participantePk.put("NUM_CORREDOC", proveedor.get("NUM_CORREDOC"));
      proveedor.putAll(buscarParticipante(lstParticipante, participantePk, SUFIJO_CONSIGNATARIO));

    }
    return resultProveedor;
  }

  /**
   * Metodo que setea el indicador de rectificado
   * <p>
   * Si indicadorRectificadoProveedorParticipante <> vacio o null y
   * (indicadorRectificadoFormbProveedor == null)
   * </p>
   * 
   * @param indicadorRectificadoProveedorParticipante
   * @param indicadorRectificadoFormbProveedor
   */
  private void setIndicadorRectificado(
      Map<String, Object> mapProveedor,
      String indicadorRectificadoProveedorParticipante,
      String indicadorRectificadoFormbProveedor)
  {
    if (StringUtils.isBlank(indicadorRectificadoFormbProveedor)
        && StringUtils.isNotBlank(indicadorRectificadoProveedorParticipante))
    {
      mapProveedor.put("IND_RECTIFICA", "R");
      return;
    }
    try
    {
      mapProveedor.remove("IND_RECTIFICA");
    }
    catch (Exception e)
    {

    }
  }

  /**
   * Busca un participante de acuerdo a un determinado criterio
   * 
   * @param lstParticipante
   *          lista de participantes
   * @param participantePk
   * @return
   */
  private Map<String, Object> buscarParticipante(
      List<Map<String, Object>> lstParticipante,
      final Map<String, Object> participantePk,
      String sufijo)
  {
    Map<String, Object> proveedor = new HashMap<String, Object>();

    Map<String, Object> participante = findInListMapByMapParam(lstParticipante, participantePk);

    if (participante != null && !participante.isEmpty())
    {
      proveedor.put("NOM_RAZONSOCIAL" + sufijo, ObjectUtils.toString(participante.get("NOM_RAZONSOCIAL")));
      proveedor.put("DIR_PARTIC" + sufijo, ObjectUtils.toString(participante.get("DIR_PARTIC")));
      proveedor.put("DES_UBIGEOCIUDAD" + sufijo, ObjectUtils.toString(participante.get("DES_UBIGEOCIUDAD")));
      proveedor.put("COD_PAISORIGEN" + sufijo, ObjectUtils.toString(participante.get("COD_PAISORIGEN")));
      proveedor.put("NUM_TELEFONO" + sufijo, ObjectUtils.toString(participante.get("NUM_TELEFONO")));
      proveedor.put("COD_TIPDOC" + sufijo, ObjectUtils.toString(participante.get("COD_TIPDOC"), "").trim());
      proveedor.put("NUM_DOCIDENT" + sufijo, ObjectUtils.toString(participante.get("NUM_DOCIDENT"), "").trim());
      if (SUFIJO_PROVEEDOR.equals(sufijo) && StringUtils.isNotEmpty((String) participante.get("IND_RECTIFICA")))
      {
        proveedor.put("IND_RECTIFICA", "R");
      }

    }
    return proveedor;
  }

  public DAV mapToObject(Map<String, Object> mapProveedor)
  {
    DAV dav = new DAV();
    Participante proveedorLocal = new Participante();
    dav.setProveedorLocal(proveedorLocal);

    dav.setNumsecuprov(new Integer(ObjectUtils.toString(mapProveedor.get("NUM_SECPROVE"), "0")));
    dav.setNumenvio(new Integer(ObjectUtils.toString(mapProveedor.get("NUM_ENVIO"), "0")));
    dav.setCntfacturas(new Integer(ObjectUtils.toString(mapProveedor.get("CNT_FACT"), "0")));

    dav.setNumcorredoc(new Long(ObjectUtils.toString(mapProveedor.get("NUM_CORREDOC"), "0")));
    dav.setNumcodsecprove(new Long(ObjectUtils.toString(mapProveedor.get("NUM_CODSECPROVE"), "0")));
    dav.setNumsecintermediario(new Long(ObjectUtils.toString(mapProveedor.get("NUM_SECINTERMEDIARIO"), "0")));
    dav.setNumsecdeclarante(new Long(ObjectUtils.toString(mapProveedor.get("NUM_SECDECLARANTE"), "0")));

    dav.setCodproveedor(ObjectUtils.toString(mapProveedor.get("COD_PROVE"), " "));
    dav.setCodnivcomer(ObjectUtils.toString(mapProveedor.get("COD_NIVELCOMER"), " "));
    dav.setCodnatutrans(ObjectUtils.toString(mapProveedor.get("COD_NATUTRANS"), " "));
    dav.setCodformenvio(ObjectUtils.toString(mapProveedor.get("COD_FORMAENVIO"), " "));
    dav.setIndexisinter(ObjectUtils.toString(mapProveedor.get("IND_INTEMEDIARIO"), " "));
    dav.setCodcondprov(ObjectUtils.toString(mapProveedor.get("COD_CONDPROVE"), " "));
    dav.setCodtipinter(ObjectUtils.toString(mapProveedor.get("COD_TIPINTERM"), " "));
    dav.setNomcargdecla(ObjectUtils.toString(mapProveedor.get("NOM_CARGO"), " "));
    dav.setCodtipgrabado(ObjectUtils.toString(mapProveedor.get("COD_TIPGRABADO"), " "));

    dav.getProveedorLocal().getTipoDocumentoIdentidad()
        .setCodDatacat(ObjectUtils.toString(mapProveedor.get("COD_DOCPROVLOCAL"), " "));
    dav.getProveedorLocal().setNumeroDocumentoIdentidad(
        ObjectUtils.toString(mapProveedor.get("COD_DOCIDENTPROVLOC"), " "));
    return dav;
  }

  //rtineo mejoras, grabacion en batch
  public FormBProveedorBatchDAO getFormBProveedorBatchDAO() {
	return formBProveedorBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFormBProveedorBatchDAO(
		FormBProveedorBatchDAO formBProveedorBatchDAO) {
	this.formBProveedorBatchDAO = formBProveedorBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // Esta clase cuenta con su propia implementacion del metodo
    // grabarRectificacion

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // Esta clase cuenta con su propia implementacion del metodo
    // grabarRectificacion

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // Esta clase cuenta con su propia implementacion del metodo
    // grabarRectificacion

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // Esta clase cuenta con su propia implementacion del metodo
    // grabarRectificacion

  }
}
