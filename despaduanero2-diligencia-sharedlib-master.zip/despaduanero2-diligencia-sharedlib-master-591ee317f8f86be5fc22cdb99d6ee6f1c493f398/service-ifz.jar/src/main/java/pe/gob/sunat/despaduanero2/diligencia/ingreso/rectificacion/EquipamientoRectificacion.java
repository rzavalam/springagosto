package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoBatchDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


public class EquipamientoRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 6617619894003418843L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstEquipamiento";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private EquipamientoDAO     equipamientoDAO;
  private CabDeclaraDAO cabDeclaraDAO;
  //rtineo mejoras, grabacion en batch
  private EquipamientoBatchDAO equipamientoBatchDAO;

  public EquipamientoRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_EQUIPAMIENTO", "NUM_EQUIPAMIENTO");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_EQUIPAMIENTO;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return equipamientoDAO.select(mapParametros);
  }

  public void setEquipamientoDAO(EquipamientoDAO equipamientoDAO)
  {
    this.equipamientoDAO = equipamientoDAO;
  }
  //rtineo mejoras, grabacion en batch
  public EquipamientoBatchDAO getEquipamientoBatchDAO() {
	return equipamientoBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setEquipamientoBatchDAO(EquipamientoBatchDAO equipamientoBatchDAO) {
	this.equipamientoBatchDAO = equipamientoBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // aun no se impleneta el grabado de nuevos registros para equipamiento
	  equipamientoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    equipamientoDAO.update2(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapEquipamiento

  }

  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    int cont = 0;

    Map<String, Object> mapDiferenciaGrabar;
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      cont = 0;
      DUA dua = null;

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {
        if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 1);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 0);
          try
          {  if(dua==null){
        	      Map<String,Object> param = new HashMap<String, Object>();
        	      param.put("numeroCorrelativo", itemNew.get("NUM_CORREDOC")) ;
            	  dua= cabDeclaraDAO.selectByNumCorredoc(param);
            	   itemNew.put("COD_ADUANA", dua.getCodaduanaorden()) ; //dua.getManifiesto();
	           	   itemNew.put("ANN_MANIFIESTO", dua.getManifiesto().getAnnmanif()) ;
	           	   itemNew.put("NUM_MANIFIESTO",SunatStringUtils.lpad(dua.getManifiesto().getNummanif().toString().trim(), 6, ' ')) ;
	           	   itemNew.put("COD_TIP_MANIFIESTO", dua.getManifiesto().getCodtipomanif()) ;
	           	   itemNew.put("COD_VIA", dua.getManifiesto().getCodmodtransp()) ;
               }else{
            	   itemNew.put("COD_ADUANA", dua.getCodaduanaorden()) ; //dua.getManifiesto();
            	   itemNew.put("ANN_MANIFIESTO", dua.getManifiesto().getAnnmanif()) ;
            	   itemNew.put("NUM_MANIFIESTO", dua.getManifiesto().getNummanif()) ;
            	   itemNew.put("COD_TIP_MANIFIESTO", dua.getManifiesto().getCodtipomanif()) ;
            	   itemNew.put("COD_VIA", dua.getManifiesto().getCodmodtransp()) ;
            	   
               }
          
            insertRecord(Utilidades.transformFieldsToRealFormat(itemNew));
            cont++;
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isWarnEnabled())
            {
              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
            }
            // Si el registro ya existe se activa el registro y se actualiza
            updateRecord(Utilidades.transformFieldsToRealFormat(itemNew));
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());         
          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          registrarRectiOficio(itemNew, numCorredocSol, true);
          continue;
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {

            if (Comparador.isKeyEqual(itemOld, itemNew, getMapClave()))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, getMapClave());
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
                {
                  mapDiferenciaGrabar.put("IND_DEL", 1);
                }
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                     
                updateRecord(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
                cont++;
              }
            }
          }
        }
      }
    }
    return cont;
  }

public CabDeclaraDAO getCabDeclaraDAO() {
	return cabDeclaraDAO;
}

public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
	this.cabDeclaraDAO = cabDeclaraDAO;
}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // aun no se impleneta el grabado de nuevos registros para equipamiento

  }
//rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  //rtineo aun no esta implementado en equipamientoDAO.update
    //equipamientoBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapEquipamiento

}
}
