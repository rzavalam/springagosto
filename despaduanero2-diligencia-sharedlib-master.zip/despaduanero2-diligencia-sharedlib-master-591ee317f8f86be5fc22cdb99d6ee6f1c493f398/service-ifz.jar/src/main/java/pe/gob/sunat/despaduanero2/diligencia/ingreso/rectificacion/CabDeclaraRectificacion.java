package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


/**
 * 
 * @author fjonislla
 * 
 */
public class CabDeclaraRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID       = -5028000437570912546L;

  // la tabla CabDeclra devuelve un mapa mas no una lista por ello el nombre del
  // recipiente inicia con Map y no con List
  private static final String NOMBRE_MAPA_ORIGINAL   = "mapCabDeclara";

  static final String         NOMBRE_MAPA_RESULTANTE = NOMBRE_MAPA_ORIGINAL + "Actual";

  private DeclaracionService  declaracionService;

  private CabDeclaraDAO       cabDeclaraDAO;

  //rtineo mejoeras,grabacion en batch
  private CabDeclaraBatchDAO cabDeclaraBatchDAO;

  public CabDeclaraRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
  }

  /**
   * Metodo que setea los valores de la RECTIFICACION sobre los recogidos de la
   * BD, segun PK.
   * 
   * @param mapResultado
   * @return
   */
  @Override
  public Map<String, Object> mergeDatosBDRectificacion(
      Map<String, Object> mapInitialData,
      Map<String, Object> mapValores)
  {
    // recuperamos valores actuales de la tabla(en BD) a rectificar
    Map mapResultado = new HashMap<String, Object>(mapInitialData);
    mapResultado = getDatosInicialesRectifacion(mapInitialData, mapValores);

    if (mapResultado.get(getCodTablaRectificacion()) != null)
    {
      mapResultado.put(NOMBRE_MAPA_RESULTANTE, Comparador.setearValoresMap(
          (Map<String, Object>) mapResultado.get(NOMBRE_MAPA_ORIGINAL),
          (Map<String, Object>) mapResultado.get(getCodTablaRectificacion())));
    }
    else
    {
      mapResultado.put(NOMBRE_MAPA_RESULTANTE, mapResultado.get(NOMBRE_MAPA_ORIGINAL));// Si
                                                                                       // no
                                                                                       // existe
                                                                                       // para
                                                                                       // rectificacion
    }

    return mapResultado;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(NOMBRE_MAPA_ORIGINAL, declaracionService.obtenerDeclaracion(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
    result.add(declaracionService.obtenerDeclaracion(parametros));
    return result;
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_MAPA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_MAPA_RESULTANTE;
  }

  @Override
  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_CAB_DECLARA;
  }

  public void setDeclaracionService(DeclaracionService declaracionService)
  {
    this.declaracionService = declaracionService;
  }

  @Override
  public int grabarRectificacion(String numCorredoc, Map<String, Object> mapDatos)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int count = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin    
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      Map<String, Object> mapPK = new HashMap<String, Object>();

      log.debug("cab declara:" + mapDatos.get(getNombreListaResultante()));
      mapPK.put("NUM_CORREDOC", "NUM_CORREDOC");
      mapDiferenciaGrabar = this.comparador.comparaMap(
          (HashMap<String, Object>) mapDatos.get(getNombreListaOriginal()),
          (HashMap<String, Object>) mapDatos.get(getNombreListaResultante()), mapPK);
      if (Comparador.esDataCambiada(mapDiferenciaGrabar))
      {
        log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
        //rtineo mejoras, grabacion para rectificacion desde web
        if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            cabDeclaraBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
            // insertamos el codigo de la tabla
            mapDiferenciaGrabar.put("COD_TABLA", getCodTablaRectificacion());
            registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredoc, false);
        }else{
        cabDeclaraDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
        // insertamos el codigo de la tabla
        mapDiferenciaGrabar.put("COD_TABLA", getCodTablaRectificacion());
        registrarRectiOficio(mapDiferenciaGrabar, numCorredoc, false);
        }     
        count++;
      }
    }
    return count;
  }
  
  //PAS20171U220200031
  @Override
  public int grabarRectificacion2(String numCorredoc, Map<String, Object> mapDatos,String tipoDiligencia)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int count = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin    
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      Map<String, Object> mapPK = new HashMap<String, Object>();

      log.debug("cab declara:" + mapDatos.get(getNombreListaResultante()));
      mapPK.put("NUM_CORREDOC", "NUM_CORREDOC");
      mapDiferenciaGrabar = this.comparador.comparaMap(
          (HashMap<String, Object>) mapDatos.get(getNombreListaOriginal()),
          (HashMap<String, Object>) mapDatos.get(getNombreListaResultante()), mapPK);
      if (Comparador.esDataCambiada(mapDiferenciaGrabar))
      {
        log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
        //rtineo mejoras, grabacion para rectificacion desde web
        if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            cabDeclaraBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
            // insertamos el codigo de la tabla
            mapDiferenciaGrabar.put("COD_TABLA", getCodTablaRectificacion());
            registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredoc, false);
        }else{
        cabDeclaraDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
        // insertamos el codigo de la tabla
        mapDiferenciaGrabar.put("COD_TABLA", getCodTablaRectificacion());
        registrarRectiOficio2(mapDiferenciaGrabar, numCorredoc, false,tipoDiligencia);
        }     
        count++;
      }
    }
    return count;
  }
//PAS20171U220200031
  public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO)
  {
    this.cabDeclaraDAO = cabDeclaraDAO;
  }

  //rtineo mejoras, grabacion en batch
  public CabDeclaraBatchDAO getCabDeclaraBatchDAO() {
	return cabDeclaraBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setCabDeclaraBatchDAO(CabDeclaraBatchDAO cabDeclaraBatchDAO) {
	this.cabDeclaraBatchDAO = cabDeclaraBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // Esta tabla cuenta con su propio metodo grabarrectificacion

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // Esta tabla cuenta con su propio metodo grabarrectificacion

  }

  //rtineo mejoras, para grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // Esta tabla cuenta con su propio metodo grabarrectificacion

  }
//rtineo mejoras, para grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // Esta tabla cuenta con su propio metodo grabarrectificacion

  }

}
