package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;

public interface ComunicacionService {

	Comunicacion selectNotificacionByID(Long numNota);
	
	

}
