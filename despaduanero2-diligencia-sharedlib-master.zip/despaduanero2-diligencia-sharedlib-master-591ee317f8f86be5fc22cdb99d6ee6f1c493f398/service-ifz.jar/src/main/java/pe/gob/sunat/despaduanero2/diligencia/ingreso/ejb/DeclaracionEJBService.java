package pe.gob.sunat.despaduanero2.diligencia.ingreso.ejb;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;

import pe.gob.sunat.despaduanero2.declaracion.bean.ConsultaDocuTransManifiesto; //juazor
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.ReporteDeclaracionBloqueada;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/* P14 - 3014 - Inicio - lrodriguezc */
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
/* P14 - 3014 - Final - lrodriguezc */
/* P14 - 3006 - Inicio - lrodriguezc */
// RIN16
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * The Interface DeclaracionService.
 *
 * @author rmontes, rdelosreyes, wmostacero
 */
@Local
public abstract interface DeclaracionEJBService {

	/**
	 * Buscar documento.
	 *
	 * @param params
	 *            the params
	 * @return the string
	 * @throws ServiceException
	 *             the service exception
	 */
	public String buscarDocumento(Map<String, Object> params)
			throws ServiceException;

	/**
	 * Obtener item factura.
	 *
	 * @param params
	 *            the params
	 * @return the list
	 * @throws ServiceException
	 *             the service exception
	 */
	public List<Map<String, Object>> obtenerItemFactura(
			Map<String, Object> params) throws ServiceException;
	
	public DUA getDua(BusquedaDua busquedaDua);
	
	public List<Map<String, Object>> getListDatosValoracion (Map<String, Object> dam);
	
	public Integer getMaxNumSecItem (String numCorreDocDUA);
	
	/**
	 * 
	 * @param params
	 * @return
	 */
	public List<Map<String, Object>> getitemdescrijoindesposicionjoindatacatalogo(Map<String, Object> params);
	
	/**
	 * 
	 * @param params
	 * @return
	 */
	public List<Map<String, Object>> getitemdescrijoindatacatalogo(Map<String, Object> params);
}
