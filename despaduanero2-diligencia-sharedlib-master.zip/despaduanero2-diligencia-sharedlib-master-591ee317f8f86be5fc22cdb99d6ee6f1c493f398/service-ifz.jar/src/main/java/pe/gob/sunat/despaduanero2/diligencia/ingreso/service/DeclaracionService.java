package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

/** RIN10 - 3012 - RLCR - INICIO **/
import java.util.Date;
/** RIN10 - 3012 - RLCR - FIN **/

import java.util.List;
import java.util.Map;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.despaduanero2.declaracion.bean.ConsultaDocuTransManifiesto; //juazor
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.declaracion.model.ReporteDeclaracionBloqueada;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


/**
 * The Interface DeclaracionService.
 *
 * @author rmontes, rdelosreyes, wmostacero
 */
@SuppressWarnings({ "rawtypes" })
public interface DeclaracionService
{

  /**
   * Obtener declaracion.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerDeclaracion(Map<String, Object> params) throws ServiceException;

  /**
   * Obtener etiqueta oea.
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String obtenerEtiquetaOEA(Long numCorreDoc) throws ServiceException;
  /**
   * Obtener estados historicos.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   *VRD-PASE 179
   */
  public Map<String, Object> obtenerEstadosHistoricos(Map<String, Object> params) throws ServiceException;

  /**
   * Obtener feria desc.
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String obtenerFeriaDesc(Map<String, Object> params) throws ServiceException;

  /**
   * Buscar documento.
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String buscarDocumento(Map<String, Object> params) throws ServiceException;

  /**
   * Buscar dua.
   *
   * @param params
   *          the params
   * @return the dua
   * @throws ServiceException
   *           the service exception
   */
  public DUA buscarDUA(Map<String, Object> params) throws ServiceException;

  /**
   * Obtener indicadores dua.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerIndicadoresDua(Map<String, Object> params) throws ServiceException;



  /**
   * Validar decla para conclucion despacho.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaConclucionDespacho(Map<String, Object> params) throws ServiceException;

  //PAS20155E220200101
  /**
   * Validar decla para conclucion despacho.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaProrrogaConclusion(Map<String, Object> params) throws ServiceException;  
  
  /**
   * Validar decla para solicitud de prorroga de conclucion despacho.
   * @author hsaenz
   * @param params the params
   * @return the map
   * @throws ServiceException the service exception
   */
  // hsaenz: 10/09/2014
  public Map<String, Object> validarDeclaSoliProrrogaConclDespacho(Map<String, Object> params) throws ServiceException;

  /**
   * Validar decla para regularizacion.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaRegularizacion(Map<String, Object> params) throws ServiceException;

  /**
   * Val registra fec recon fis.
   *
   * @param params
   *          the params
   * @return the boolean
   * @throws ServiceException
   *           the service exception
   */
  public Boolean valRegistraFecReconFis(Map<String, Object> params) throws ServiceException;

  /**
   * Validar decla para despacho.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaDespacho(Map<String, Object> params) throws ServiceException;

  
/*RIN13FSW*/
  /**
   * Validar decla para continuacion de despacho.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   * @author jlunah
   */
  public Map<String, Object> validarDeclaParaContDespacho(Map<String, Object> params) throws ServiceException;
  
  
  /**
   * Update declaracion.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  public void updateDeclaracion(Map<String, Object> params) throws ServiceException;


  public void updateDeclaracionSinTXNewRequired(Map<String, Object> params) throws ServiceException;


  /**
   * Obtener titulo diligencia.
   *
   * @param codigoCanal
   *          the codigo canal
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String obtenerTituloDiligencia(String codigoCanal) throws ServiceException;

  /**
   * Obtener titulo diligencia.
   *
   * @param codigoCanal
   *          the codigo canal
   * @param invocador
   *          the invocador
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String obtenerTituloDiligencia(String codigoCanal, String invocador) throws ServiceException;

  /**
   * Seleccionar factura session.
   *
   * @param params
   *          the params
   * @param lstFacturasSerie
   *          the lst facturas serie
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> seleccionarFacturaSession(
    Map<String, String> params,
    List<Map<String, Object>> lstFacturasSerie)
      throws ServiceException;
  /**
   * Grabar factura session.
   *
   * @param params
   *          the params
   * @param lstFacturasSerie
   *          the lst facturas serie
   * @param lstFacturasSerieAnt
   *          the lst facturas serie ant
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> grabarFacturaSession(
    Map<String, String> params,
    List<Map<String, Object>> lstFacturasSerie,
    List<Map<String, Object>> lstFacturasSerieAnt)
      throws ServiceException;
  /**
   * Eliminar factura session.
   *
   * @param params
   *          the params
   * @param lstFacturasSerie
   *          the lst facturas serie
   * @throws ServiceException
   *           the service exception
   */
  public void eliminarFacturaSession(Map<String, String> params, List<Map<String, Object>> lstFacturasSerie)
      throws ServiceException;

  /**
   * Adicionar factura session.
   *
   * @param params
   *          the params
   * @param lstFacturasSerie
   *          the lst facturas serie
   * @param lstFacturasSerieAnt
   *          the lst facturas serie ant
   * @throws ServiceException
   *           the service exception
   */
  public void adicionarFacturaSession(
    Map<String, String> params,
    List<Map<String, Object>> lstFacturasSerie,
    List<Map<String, Object>> lstFacturasSerieAnt)
      throws ServiceException;

  /**
   * Obtener datado.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerDatado(Map PkDocu) throws ServiceException;

  /**
   * Obtiene el datado con parametro adicional del manifiesto referenciado
   * @param PkDocu
   * @param manifiesto
   * @return
   * @throws ServiceException
   */
  public List<Map<String, Object>>  obtenerDatado(Map<String, Object> PkDocu, Manifiesto manifiesto) throws ServiceException;

  /**
   * Obtener vehiculos.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerVehiculos(Map PkDocu) throws ServiceException;

  /**
   * Obtener cert origen.
   *
   * @param PkSerie
   *          the pk serie
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerCertOrigen(Map<String, String> PkSerie) throws ServiceException;

  /**
   * Obtener cert origen.
   *
   * @param PkSerie
   *          the pk serie
   * @param listaDetAutorizacion
   *          the lista det autorizacion
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerCertOrigen(
    Map<String, String> PkSerie,
    List<Map<String, Object>> listaDetAutorizacion) throws ServiceException;

  /**
   * Obtener contenedores.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerContenedores(Map<String, String> PkDocu) throws ServiceException;

  /**
   * Obtener Precintos.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerPrecintos(Map<String, String> PkDocu) throws ServiceException;


  /**
   * Obtener riesgos.
   *
   * @param pkDocu
   *          the pk docu
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerRiesgos(Map<String, String> pkDocu)
      throws ServiceException;
  /**
   * Obtener doc aut asociados.
   *
   * @param pkDoc
   *          the pk doc
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerDocAutAsociados(Map<String, String> pkDoc) throws ServiceException;

  /**
   * Obtener plazos proceso.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerPlazosProceso(Map params) throws ServiceException;

  /**
   * Obtener max correlativo doc aut asociado.
   *
   * @param pkDoc
   *          the pk doc
   * @return the integer
   * @throws ServiceException
   *           the service exception
   */
  public Integer obtenerMaxCorrelativoDocAutAsociado(Map<String, String> pkDoc)
      throws ServiceException;


  /**
   * Validar decla para rectificacion.
   *
   * @param pkDecla
   *          the pk decla
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaRectificacion(Map<String, Object> pkDecla) throws ServiceException;

  /**
   * Validar fecha recepcion.
   *
   * @param pkDecla
   *          the pk decla
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validarFechaRecepcion(Map<String, Object> pkDecla)
      throws ServiceException;


  /**
   * Obtener anexo2.
   *
   * @param pkDecla
   *          the pk decla
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerAnexo2(Map<String, Object> pkDecla) throws ServiceException;

  /**
   * Obtener anexo2 from fin ubicacion.
   *
   * @param finUbicacion
   *          registro con los datos de fin ubicacion
   * @return fin ubicacion con los datos completos para ser mostrados en
   *         pantalla
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerAnexo2FromFinUbicacion(Map<String, Object> finUbicacion) throws ServiceException;

  /**
   * Validar decla para rectificacion oficio.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaRectificacionOficio(Map<String, Object> params) throws ServiceException;


  /**
   * Validar decla para rectificacion oficio.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaDiligenciaCulminacionPeco(Map<String, Object> params) throws ServiceException;

  /**
   * Validar decla para rechazo.
   *
   * @param pkDecla
   *          the pk decla
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaRechazo(Map<String, Object> pkDecla) throws ServiceException;

  /**
   * Validar decla para recuperar.
   *
   * @param pkDecla
   *          the pk decla
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validarDeclaParaRecuperar(Map<String, Object> pkDecla) throws ServiceException;

  /**
   * Validar decla para modificar.
   *
   * @param params
   *          the params
   * @return the map
   */
  public Map<String, Object> validarDeclaParaModificar(Map<String, Object> params);

  /**
   * Obtener local anexo declaracion.
   *
   * @param ruc
   *          the ruc
   * @param codAnexo
   *          the cod anexo
   * @return the string
   */
  public String obtenerLocalAnexoDeclaracion(String ruc, String codAnexo);

  /**
   * metodo que obtiene los datos de la daclaracion a ser modificada.
   *
   * @param params
   *          Correlativo de la declaracion
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerDeclaracionMoficar(Map<String, Object> params)
      throws ServiceException;

  /**
   * Obtener item factura.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerItemFactura(Map<String, Object> params)
      throws ServiceException;


  /**
   * Prorrateo flete.
   *
   * @param lstDetDeclara
   *          the lst det declara
   * @return the list
   */
  @Deprecated
  public List<Map<String, Object>> prorrateoFlete(List<Map<String, Object>> lstDetDeclara);

  /**
   * Obtener observaciones.
   *
   * @param params
   *          the params
   * @return the list
   */
  public List obtenerObservaciones(Map<String, Object> params);

  /**
   * Obtener participantes map.
   *
   * @param params
   *          the params
   * @return the list
   */
  public List obtenerParticipantesMap(Map params);

  /**
   * Obtener v fob provisional.
   *
   * @param pkDocu
   *          the pk docu
   * @return the list
   */
  public List<Map<String, Object>> obtenerVFobProvisional(Map pkDocu);

  /**
   * Obtener primera diligencia.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerPrimeraDiligencia(String numCorreDoc)
      throws ServiceException;

  /**
   * Valida modificacion diligencia.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> validaModificacionDiligencia(Map<String, Object> params)
      throws ServiceException;
  /**
   * Obtener ace.
   *
   * @param mapParametros
   *          the map parametros
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerACE(Map<String, Object> mapParametros)
      throws ServiceException;

  /**
   * Obtener primera diligencia.
   * MATC-20130125
   * Se incluy? c?digo de canal como par?metro
   * @param numCorreDoc
   *          the num corre doc
   * @param codCanal
   *          the cod canal
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
	public Map<String, Object> obtenerPrimeraDiligencia(String numCorreDoc, String codCanal) throws ServiceException;  //MATC 20130125 - Se incluy? c?digo de canal como par?metro

	/**
	 * Inserta un nuevo tipo de indicador de la DUA.
	 * @param numCorreDoc
	 * @param codIndicador
	 * @return
	 */
	public Integer insertarIndicadorDua(String numCorreDoc, String codIndicador, String tipoRegistro);

	/**
	 * Obtiene un indicador de la DUA por su llave.
	 * @param numCorreDoc
	 * @param codIndicador
	 * @return
	 */
	public Map<String, Object> obtenerIndicadorDuaByPk(String numCorreDoc, String codIndicador);
	/* P14 - 3014 - Inicio - lrodriguezc */
	
	/** Devuelve los indicadores de la declaraci�n
	 * @author lrodriguezc
	 * @param params
	 * @return
	 */
	public List<IndicadorDeclaracionDescripcion> obtenerIndicadoresDuaAll(Long numCorrelativo); 
	
	/* P14 - 3014 - Final - lrodriguezc */
	
	/* P14 - 3007 - Inicio - dhernandezv */
	
	/**
	 * Valida que no tenga indicador de abandono voluntario.
	 *
	 * @param numCorredoc N�mero de documento, String
	*/
	public void validaNoTengaIndicadorAbandonoVoluntario(Long numCorreDoc); 
	
	/* P14 - 3007 - Fin - dhernandezv */
	
	/* P14 - 3014 - Inicio - lrodriguezc */
	/* CUS: 3004-01 - Inicio - lrodriguezc */
	
	/** Devuelve el indicador de la declaraci�n
	 * @author lrodriguezc
	 * @param params
	 * @return
	 */
	public DatoIndicadores obtenerIndicadorDeclaracion(String numCorreDoc, String codIndicador); 
	
	/* CUS: 3004-01 - Final - lrodriguezc */
	/* P14 - 3004 - Final - lrodriguezc */
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	/** Valida la recepci�n de la respuesta de notificaci�n
	 * @author lrodriguezc
	 * @param params
	 * @param usuarioBean
	 * @return
	 */
	public Map<String, Object> validarRecepcionRespuestaNotificacion(Map<String, Object> params, UsuarioBean usuarioBean);
	
	/* P14 - 3006 - Final - lrodriguezc */

/**INICIO-RIN13**/
	/**
	 * Buscar la DUA 
     * por su clave de negocio 
     * @param aduana Aduana de la declaraci�n
     * @param anio A�o de la declaraci�n
     * @param regimen R�gimen de la declaraci�n
     * @param numero N�mero de la declaraci�n
     * @return DUA
     * @author gbecerrav
	 */
	public DUA buscarDUAByClaveDeNegocio(String aduana, Integer anio, String regimen, Integer numero) throws ServiceException;
	
	/**
	 * Buscar la DUA 
     * su clave de negocio 
     * @param aduana Aduana de la declaraci�n
     * @param anio A�o de la declaraci�n
     * @param regimen R�gimen de la declaraci�n
     * @param numero N�mero de la declaraci�n
     * @return DUA
     * @author gbecerrav
	 */
	public DUA buscarDatosGeneralesDUAByClaveDeNegocio(String aduana, Integer anio, String regimen, Integer numero) throws ServiceException;
	
	/**
	 * Adiciona datos a la declaracion
	 * para el proceso de diligencia previa
	 * @param declaracion Declaracion
	 * @return 
	 * @author gbecerrav
	 */
	public void adicionarDatosDeclaracionParaDiligenciaPrevia(Declaracion declaracion) throws ServiceException;
	
	/**
	 * Actualiza selectivamente 
	 * un registro de declaracion 
	 * buscado por la clave primaria
	 * @param dua Declaracion a actualizar
	 * @return 
	 * @author gbecerrav
	 */
	public void actualizarDUAByPrimaryKey(DUA dua) throws ServiceException;
	
	
	//*FIN RIN13*/
	
	
	//inicio EJHM
	/**
	 * Obtiene un datos del participante
	 * Map<String, Object> res
	 * @tipoParticipante tipo de participante
	 * @return
	 */
	public void obtenerDatosParticipante(Map<String, Object> res, String tipoParticipante);
	/**
	 * Es un tipo de documento
	 * @tipoParticipante tipo de participante
	 */
	public boolean esTipoDocumentoDentroDeLista(String tipoDocumento, String ... listaDocumentos);
	/**
	 * Son validos parametros de Participante
	 * Map<String, Object> res
	 * @tipoParticipante tipo de participante
	 */
	public boolean sonValidosParametrosParticipante(Map<String, Object> res, String tipoParticipante);
	//INICIO RIN08
	 public Map<String, Object> validarDeclaParaDespachoAduanaDestino(Map<String, Object> params) throws ServiceException;
	 public List<Map<String, Object>> obtenerDeclaracionImportador(Map<String, Object> params) ;
	 
	 public  Expedi findExpediDocAsociadoPecoAmazonia(Map<String, Object> params) ;
	//FIN RIN08 
  //Lmvr- inicio - Complemento de rectificacion
   public List<Map<String, Object>> validarDeclaracionAnticipadaCanalVerde(Map<String, Object>  mapCabDeclara);
   
   public List<Map<String, Object>> validarSolicitudRectificacionUltimoExpediente(Map<String, Object>  mapCabDeclara);
   
   public List<Map<String, Object>> validarExpedienteAsociadoImportadorDeclaracion(Map<String, Object> mapaCabDeclara);
   
   public List<Map<String, Object>> validarFechaSolicitudRectificacion (Map<String, Object> params) throws Exception; 
	  //Lmvr- fin - Complemento de rectificacion
	
	// RIN16
	/**
	 * Permite Verificar si la declaracion cumple los requisitos para solicitar la conclusion automatica en la regularizacion
	 * <br> Condiciones a cumplir:
	 * <ul>
	 * 	<li>[<b>1</b>] : Que NO se haya registrado en estado [13 - Concluida] en algun momento</li>
	 * 	<li>[<b>2</b>] : Que NO tenga Asociada Boletines Quimicos pendientes de informe</li>
	 * 	<li>[<b>3</b>] : Que NO exista Duda Razonable pendiente [Notificacion Emitida y sin Diligencia de Duda Razonable]</li>
	 * </ul>
	 * @param declaracion
	 * @return
	 */
	public String verificarRegularizacionConclusionAutomatica(Declaracion declaracion);
	
	/**
	 * Permite realizar las validaciones necesarias para registrar una observacion en la declaracion
	 * @param params 
	 * @return
	 * @throws Exception 
	 */
	public Map<String, Object> validarDeclaracionParaObservar(Map<String, Object> params) throws Exception;
	
	/**
	   * Determina el Estado de Regularizacion a asignarse al momento de realizar la grabacion
	   * (Por defecto asigna tipoEstado con <b>Constantes.COD_MODALIDAD_URGENTE</b> : 01)
	   * @param declaracion
	   * @return
	   */
	  public String estadoDeRegularizacion(Declaracion declaracion);
	  
	/**
	   * Determina el Estado de Regularizacion a asignarse al momento de realizar la grabacion
	   * (si <b>tipoEstado</b> = <b>Constantes.COD_MODALIDAD_ANTICIPADO</b> : 10, entonces asigna a <b>fecSegundaRecepcion</b> la fecha del sistema)
	   * @param declaracion
	   * @return
	   */
	  public String estadoDeRegularizacion(Declaracion declaracion, String tipoEstado);
	
	/**********Inicio EGH_PASEINGRESO2****************************/
	/**
	 * Permite realizar las validaciones necesarias para registrar una regularizacion de oficio
	 * @param params 
	 * @return
	 * @throws Exception 
	 */
//	public Map<String, Object> validarDeclaracionRegularizacion(Map<String, Object> params,UsuarioBean usuario) throws Exception;
	/**********Fin EGH_PASEINGRESO2****************************/
	/**
	 * Permite registrar una declaracion con el estado Observada
	 * @return
	 */
	public Map<String, Object> guardarDeclaracionObservada(Map<String, Object> params);

	/***** GGRANADOS RIN16PASE3 INI *****/
	/********************************************************/
	/**
	 * Permite realizar las validaciones necesarias para registrar una regularizacion de oficio
	 * @return
	 */
//	public ObjectResponseUtil validarDeclaParaRegularizacionOficio(Map<String, Object> params) throws Exception;
	

	
	public boolean tieneIndicadorRegularizable(
			List<Map<String, Object>> lstIndicadorDua);
	

	public String procesarCambioModalidadRegularizacion(String codModalidad,
			String codModalidadActual, boolean tieneIndicadorRegularizable,
			boolean tieneIndicadorRegularizableActual);
	

	public Map<String, Object> getDatosParaEvaluarCambioModalidad(
			Map<String, Object> mapDatos);

	public Map<String, Object> getDatosParaEvaluarCambioModalidad(
			Declaracion declaracion, Declaracion declaracionBD);

	public void actualizarDatosRegularizacion(DUA dua);

	public void limpiarDatosRegularizacion(Long numCorreDoc);

//	public void actualizarDatosRegularizacion(Map<String, Object> declaracion);
	
	/***** GGRANADOS RIN16PASE3 FIN *****/

// FIXME: CUS110301 lpalominom [inicio]
	
	/**
	 * Permite verificar si es la primera vez que se va a actualizar de la descripcion de la diligencia de regularizacion
	 * @param parametros
	 * @return
	 */
	public Map<String,Object> validarBloqueoActualizacionDiligenciaRegularizacion(Map<String,Object> parametros);
	
	/**
	 * Permite verificar las reglas de negocio previas a la actualizacion de la descripcion de la diligencia de regularizacion
	 * @param parametros
	 * @return
	 */
	public Map<String,Object> validarActualizacionDiligenciaRegularizacion(Map<String,Object> parametros);
	

	  
	/* CUS: 3006-01 - Migrado - Rin 13 - Final - lrodriguezc */
	/* P14 - 3006 - Final - lrodriguezc */
	  
     // hosoriov rin 12
	  public boolean hasDocTransporteNotaTarja(Long numeroCorrelativo, String numeroManifiesto, 
			  Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte,Integer indCampoUsar);
	/* CUS: 3006-02 - Migrado - Rin 13 - Final - lrodriguezc */
	/* P14 - 3006 - Final - lrodriguezc */
	// rin 12 hosoriov
	public boolean hasDocTransporteNotaTarja(Long numeroCorrelativo, String numeroManifiesto, 
			  Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte);


	// INICIO RIN13
		    
	  /**
	   * Obtiene la lista de declaraciones con bloqueo de Salida.
	   * @param parametros: fechaDeBloqueoDesde, fechaDeBloqueoHasta, codigoAduana, regimen, codigoFuncionario
	   * @return
	   * @throws ServiceException
	   */
	  public List<ReporteDeclaracionBloqueada> buscaDeclaracionBloqueoSalida (Map<String, Object> parametros) throws ServiceException;
	  
	  /**
	   * juazor
	   * @param params
	   * @return
	   * @throws ServiceException
	   */
	  public Map<String, Object> validarDeclaParaDescargaParcial(Map<String, Object> params) throws ServiceException;
	  
	  /**
	   * juazor
	   * 
	   * */
	  public List<ConsultaDocuTransManifiesto> obtenerContenedoresDescargaParcial (Map<String, Object> params) throws ServiceException;
	  /***
	   *@author juazor
	   * 
	   */
	  public boolean obtenerRegistro(Map<String,Object> paramsDocTrans) throws ServiceException;
	  
	  
		/***
		 * juazor
		 * @param listaDocumentosDeTransporte
		 * @return
		 * @throws ServiceException
		 */
		public boolean seDescargaronTodosLosContenedores(List<Map<String, Object>> listaDocumentosDeTransporte) throws ServiceException;
		
		/**
		 * @author jlunah
		 * Verifica si la declaracion tiene alguna diligencia de descarga parcial
		 * */
		public boolean tieneDescargaParcial(String numCorredoc);
		
		/**
		   * @author jlunah
		   * obtiene la lista de los documentos de transporte de la declaracion
		   * */
		public List<Map<String,Object>> obtieneDocumentosDeTransporteDeLaDeclaracion(Map paramsDocTrans);
		
		/**
		 * juazor RIN13
		 */
		public boolean tieneContinuacionDespacho(String numCorredoc);
	  
//		<EHR>
		public String obtieneDocumentosDeTransporteDeLaDeclaracionValid(Map<String, Object> declaracion) throws ServiceException;
//		</EHR>
		
		
	// FIN RIN13

    //Rin13FSW amancilla correciones de valdiacion plaro de arribo

    public String isPlazoMercanciaArriboDespachoAnticipado(Integer numeroDeclaracion, String anioDeclaracion,
                                                           String regimenDeclaracion, String aduanaDeclaracion, Date fechaDeclaracion,
                                                           String numeroManifiesto, Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte, Long numeroCorrelativo);

	
    //DZC RIN 16
	public Map<String, Object> validarDeclaParaRegularizacionOficio(Map<String, Object> params,UsuarioBean usuario) throws Exception;

	/*INICIO - RIN 13*/  
	public Map<String, Object> validarAceDeclaracion(Map<String, Object> mapCabDeclara);
	/*FIN  - RIN 13*/
	
	//lmvr
	public boolean  buscarNotaTarjaSigad(DUA dua);
 // hosoriov rin 12 inicio
    public Map<String,Object> consultarDatosDUAParaCargaLaboral (Map<String ,Object> params);
    
    public boolean hasDocTransporteNotaTarjaConDetalle(Long numeroCorrelativo, String numeroManifiesto, 
  		  Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte);


  public boolean hasDocTransporteNotaTarjaConDetalle(Long numeroCorrelativo, String numeroManifiesto, 
  		  Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte,Integer indCampoUsar);

//hosoriov rin 12 fin
  
	//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	public Map<String, Object> buscarDUAconDiligenciaAsociada(Map<String, Object> params) throws ServiceException;
	//RTINEO: FIN
	
	/*inicio gdlr*/
	public String obtieneDocumentosDeTransporteDeLaDeclaracionValid(Map<String, Object> declaracion, List<Map<String, Object>> series) throws ServiceException;
	/*fin gdlr*/
	//	<RIN10> 3012 ERUESTAA
	/**
	 * @param params
	 * @return
	 */
	public Map<String, Object> validarValorProvisional(Map<String, Object> params);
	/**
	 * @param params
	 * @return
	 */
	public Map<String, Object>  getCabCtaCteGara(Map<String, Object> params);
	/**
	 * @param fechaHora
	 * @return
	 */
	public String fechaYhora_to_soloFecha(String fechaHora);
	/**
	 * @param fechaHora
	 * @return
	 */
	public String dateFechaYhora_to_soloFecha(Date fechaHora);
	/**
	 * @param mapWhere
	 * @return
	 */
	public List<Map<String,Object>> obtenerMovCtaCteGaraDeLC(Map<String,Object> mapWhere);
	/**
	 * @param paramUpdate
	 */
	public void actualizarMovCtaCteGarantia(Map<String, Object> paramUpdate);
	/**
	 * @param params
	 * @return
	 */
	public boolean isFechaHabil(Map<String, Object> params);
	/**
	 * @param params
	 * @return
	 */
	public Map<String, Object> validarValorProvisionalPO(Map<String, Object> params);
//	</RIN10> 3012 ERUESTAA
	
//	<RIN10> 3014 ERUESTAA
	/**obtiene listado de expedientes
	 * @param params
	 * @return
	 */
	public List<Map<String, Object>> listarExpedientes(Map<String, Object> params);
	
	/** obtiene los datos adicionales de una DUA
	 * @param params
	 * @return
	 */
	public DUA obtenerDatosAdicionalesDuaByPk(Map<String, Object> params);
//	</RIN10> 3014 ERUESTAA	
	
    //RIN10 mpoblete BUG 22178
	public List<Map<String, Object>> listaItemFacturaTieneValorProvisional(List<Map<String, Object>> lstItemFactura);
	
//	<EHR>RIN 10</EHR>
//amancilla inicio PAS20165E220200137
	public List<Map<String, Object>> listaItemFacturaTieneValorProvisional(List<Map<String, Object>> lstItemFactura, Map mapCabDeclaraActual);
//amancilla fin PAS20165E220200137
	/**
	 * para saber la rectificacion automatica de  una declaracion
	 * @param numCorredoc
	 * @return
	 * @throws ServiceException
	 */
	public  boolean tieneRectificacionAutomatica( String numCorredoc) throws ServiceException;

	/**
	 * Obtiene la cantidad de registros a mostrar en reporte de riesgos por declaracion
	 * @author hsaenz
	 * @param params
	 * @return
	 * @throws ServiceException
	 * @throws Exception
	 */
	// hsaenz: 12/05/2015
	public Integer contarRegistrosReporteRiesgos(Map<String, Object> params) throws ServiceException, Exception;
	
	/**
	 * Obtiene informacion para reporte de riesgos por declaracion
	 * @author hsaenz
	 * @return
	 * @throws ServiceException
	 * @throws Exception
	 */
	// hsaenz: 12/05/2015
	public List <Map<String, Object>> obtenerReporteRiesgos (Map<String, Object> params) throws ServiceException, Exception;

	/*INICIO-P34 INTEGRACION FSW AFMA*/
	public boolean tieneAsignadaDeclaracionOSolicitud(String numCorreDocDeclaracion,  String registroUsuarioLogeado);
	public void updateIndicadorDua(String numCorreDoc, String codIndicador, String tipoRegistro, String indActivo);
	/*FIN-P34 INTEGRACION FSW AFMA*/

	//inicio P21-P22
	public Boolean duaTieneNotificacionDudaRazonable(Map<String,Object> declaracion);
	//fin P21-P22

	public List obtenerPlazosProcesoConclusion(Map PkDecla) throws ServiceException; //gmontoya P24

	public List<Map<String, Object>> obtenerContenedoresEvaluacionSINI(Map<String, Object> declaracionDua, Map<String, String> PkDocu)throws ServiceException;//gmontoya P24

	public List obtenerDocumentosTransporteDUA(Map PkDocu);//gmontoya P24
	
	public List obtenerReceptorCargaDUA(Map PkDocu);//gmontoya P24

	public List<Map<String, Object>> obtenerDatadoDUA(Map<String, Object> pk);//gmontoya P24
	public List<Map<String, Object>> obtenerDatadoDUASIGAD(Map<String, Object> pk);
	
	public String adicionParametrosNumeroDeclaracion(Map<String, Object> declaracion, String DEFAULT_TIPO_DOC); //P24   

//amancilla PAS20155E220200089
  public String validarRectificacionesPendientes(String numCorredocDua);
  
  	/*PAS20145E220000427*/
	public String tieneMercanciaDispuestaParcial(Long numCorreDoc);

	boolean validarDamTieneMercanciaFranquicia(Long numCorreDoc); //PAS20155E410000032 - bug23610
	boolean esNuevaReglaLgaVigente(Date fechaReferencia);

	public Date obtenerFechaOrigenPostLevante(String numeCorredoc, Date fechaNumeracion); //PAS20155E410000032 
	
		/*INICIO PAS20155E220200129 - PAS20165E220200099*/
	public Map<String, Object> obtenerDatosLevanteDuaSini(Map<String, Object> declaracionDua) throws ServiceException; 
	
	public void generaCuentaCorriente(String codFuncionario, Map declaracion); /* PAS20175E220200051 */
	
	//PAS20181U220200073 funcionalidad trasladada
	public Map<String, Object> evalGrabarFechaPostLevante(Map<String, Object> declaracion, Date fechadeclaracion);

	/****
	 * Busca los datados asociados a la dam en el sigad PAS20191U220200011
	 * @param pk
	 * @return
	 */
	public List<Map<String, Object>> obtenerDatadoSimplificadaDUA(Map<String,Object> pk);
	public List<Map<String, Object>>  obtenerDatadoManifAsigad(Map<String, Object> pkDocu, Manifiesto manifiesto);
	public List<Map<String, Object>> obtenerDocumentosTransporteAsigad(String codigoViaTransporte,String  codigoAduana, Integer anioManifiesto,
			String numeroManifiesto, Long numcorredocDam);
	public List<Map<String, Object>>  obtenerReceptorCargaDUAEnAsigad(Map<String, Object> paramMap);
	public void obtenerFechaTarjaAsigad(Map<String, Object> paramMap);
	public void obtenerFechaIcaAsigad(Map<String, Object> paramMap);

}
