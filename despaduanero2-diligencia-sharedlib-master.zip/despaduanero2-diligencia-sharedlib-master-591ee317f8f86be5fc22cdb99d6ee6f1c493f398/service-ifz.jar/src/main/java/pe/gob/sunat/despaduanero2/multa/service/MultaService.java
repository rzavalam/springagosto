package pe.gob.sunat.despaduanero2.multa.service;


import java.math.BigDecimal;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* RIN15 - f2 3011 - Inicio - lrodriguezc */
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.MultaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
/*  RIN15 - f2 3011 - Fin - lrodriguezc */
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Interface MultaService.
 */
@SuppressWarnings({ "rawtypes" })
public interface MultaService
{

  /**
   * Obtener cat multas.
   *
   * @param params the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<Map<String, Object>> obtenerCatMultas(Map<String, Object> params) throws ServiceException;

  /**
   * Generar multa.
   *
   * @param paramMulta the param multa
   * @param multas the multas
   * @throws ServiceException
   *           the service exception
   */
  void generarMulta(Map paramMulta, List<Map<String, Object>> multas) throws ServiceException;

  /**
   * Generar multa.
   *
   * @param paramMulta the param multa
   * @param multas the multas
   * @param isgetfieldvalues the isgetfieldvalues
   * @throws ServiceException
   *           the service exception
   */
  void generarMulta(Map paramMulta, List<Map<String, Object>> multas, boolean isgetfieldvalues) throws ServiceException;

  /**
   * Crear multa maps.
   *
   * @param paramMulta the param multa
   * @param multas the multas
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<Map<String, Object>> crearMultaMaps(Map paramMulta, List<Map<String, Object>> multas) throws ServiceException;
	
	/* RIN15 - f2 3011 - Inicio - lrodriguezc */
	
	/**
	 * M�todo que devuelve un listado de multas por DUA
	 * 
	 * @author lrodriguezc
	 * @param paramMulta
	 *            Parametros de Busqueda para las Multas por DUA
	 * @return
	 * @throws ServiceException
	 */
	public List<MultaDua> listMultaDUA(Map paramMulta) throws ServiceException;
	
	/* RIN15 - f2 3011 - Fin - lrodriguezc */
/*RIN13FSW-INICIO*/	
 
  /**
   * Buscar cat�logo de infracciones vigentes que pertenezcan al infractor
   * @param FEC_DECLARACION y COD_INFRACTOR
   * @autor jlunah
   * @return
   * @throws ServiceException
   */
  List<Map<String, Object>> obtenerListaCatMultasPorInfractor(Map<String, Object> parametros) throws ServiceException;
  
  /**
   * @autor jlunah
   * @param 
   * @return
   * @throws ServiceException
   */
  public boolean tieneInfraccionEnOtraDiligencia(Map<String,Object> parametros) throws ServiceException;
  
  /**
   * RIN13 SWF
   * */
  public ObjectResponseUtil validarMontoMultasVsMontoAutoliquidaciones(List<Map<String,Object>> lstMultasRegistradas,List<Map<String,Object>> lstAutoliq, String numCtaCte, String TipDiligencia);
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String,Object>> asociarAutoliqConMultas(List<Map<String,Object>> multaSoles,List<Map<String,Object>> autoliqSoles, String moneda);
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String,Object>> obtenerMultasPorMoneda(List<Map<String,Object>> lstMultasRegistradas, String moneda);
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String,Object>> obtenerAutoliqPorMoneda(List<Map<String,Object>> lstAutoliq , String moneda);
  
  /**
   * RIN13 SWF
   * */
  public BigDecimal calcularMontoMultaAutomatico(String codigoInfraccion, String formulaMulta);
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String, Object>> armarMapaMultasParaRegistroDiligenciaDespacho(Map paramMulta,List<Map<String, Object>> multas) throws ServiceException;

  //Inicio PAS20155E220000054  
  public List<Map<String,Object>> getListMultasNoCubreAutoliquidaciones(List<Map<String,Object>> lstMultasRegistradas);
  //Fin PAS20155E220000054  
  
/*RIN13FSW-FIN*/
}
