package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


/**
 * Clase que sirve para realizar la rectificaci�n de la tabla FACTUSUCE
 * 
 * @author ggranados
 * 
 */
public class FactuSuceRectificacion extends RectificacionAbstract implements Serializable
{

  private static final long   serialVersionUID        = 8840125308628026022L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstFactuSuce";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FactuSuceDAO        factuSuceDAO;
  //rtineo mejoras, grabacion en batch
  private FactuSuceBatchDAO factuSuceBatchDAO;

  public FactuSuceRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");
    mapClave.put("NUM_SECFACT", "NUM_SECFACT");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FACTUSUCE;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return factuSuceDAO.selectFactuSuse(mapParametros);
  }

  public void setFactuSuceDAO(FactuSuceDAO factuSuceDAO)
  {
    this.factuSuceDAO = factuSuceDAO;
  }
  //rtineo mejoras, grabacion en batch
  public FactuSuceBatchDAO getFactuSuceBatchDAO() {
	return factuSuceBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFactuSuceBatchDAO(FactuSuceBatchDAO factuSuceBatchDAO) {
	this.factuSuceBatchDAO = factuSuceBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    factuSuceDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    factuSuceDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapDetAdiApta

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    factuSuceBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  factuSuceBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapDetAdiApta

  }
}
