package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUABatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.framework.spring.util.date.FechaBean;


public class IndicadorDuaRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -2859455397112485038L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstIndicadorDua";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private IndicadorDUADAO     indicadorDUADAO;

  private CabDeclaraDAO       cabDeclaraDAO;

  //rtineo mejoras, grabacion en batch
  private IndicadorDUABatchDAO indicadorDUABatchDAO;
  private CabDeclaraBatchDAO cabDeclaraBatchDAO;

  public IndicadorDuaRectificacion()
  {
    mapClave = new HashMap<String, Object>();

    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("COD_INDICADOR", "COD_INDICADOR");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_INDICADOR_DUA;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    mapParametros.put("COD_TIPOREGISTRO", "T");
    return indicadorDUADAO.findByDocumentoAndTipo(mapParametros);
  }

  public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO)
  {
    this.indicadorDUADAO = indicadorDUADAO;
  }

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin    
    if (mapDatos.get(getNombreListaResultante()) != null)
    {

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {
        if (log.isDebugEnabled())
        {
          cont++;
          log.debug(cont + " INDICADOR_DUA :" + itemNew);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("COD_TIPOREGISTRO", "T");
          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  indicadorDUABatchDAO.insert(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            indicadorDUADAO.insert(Utilidades.transformFieldsToRealFormat(itemNew));
          }
              //rtineo mejoras, fin
          }
          catch (DataIntegrityViolationException e)
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  indicadorDUABatchDAO.updateByPrimaryKeySelective(Utilidades.transformFieldsToRealFormat(itemNew));
              }else{
            indicadorDUADAO.updateByPrimaryKeySelective(Utilidades.transformFieldsToRealFormat(itemNew));
          }
              //rtineo mejoras, fin
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, getMapClave());
          itemNew.put("dataOriginal", new HashMap<String, Object>(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, false);
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, false);
        }
          //rtineo fin
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {
            if (Comparador.isKeyEqual(itemOld, itemNew, mapClave))
            {
              if ("1".equals(ObjectUtils.toString(itemNew.get("IND_DEL"))))
              {
                itemNew.put("IND_ACTIVO", "0");
              }
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                // si el registro es eliminado IND_DEL = 1 => IND_ACTIVO = 0
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	indicadorDUABatchDAO.updateByRectificacion(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, true);
                }else{
                indicadorDUADAO.updateByRectificacion(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, true);
                }
                //rtineo mejoras, fin
                if (itemNew.get("IND_ACTIVO").toString().equals("0")
                    && itemNew.get("COD_INDICADOR").toString().equals("02"))
                {// Si se elimina indicador de regularizaci�n, actualizar fecha
                 // de venc de regu en cabDeclara
                  Map<String, Object> mapCabDeclara = new HashMap<String, Object>();
                  FechaBean fecDefault = new FechaBean(Constantes.DEFAULT_FECHA_BD, "dd/MM/yyyy");
                  mapCabDeclara.put("FEC_VENCREGULA", fecDefault.getSQLDate());
                  mapCabDeclara.put("NUM_CORREDOC", itemNew.get("NUM_CORREDOC"));
                  //rtineo mejoras, grabacion para rectificacion desde web
                  if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	  cabDeclaraBatchDAO.update(mapCabDeclara);
                  }else{
                  cabDeclaraDAO.update(mapCabDeclara);
                }
                  //rtineo mejoras, fin
                }
              }
            }
          }
        }
      }
    }
    return cont;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // esta clase tiene su propia implemnetacion del metodo grabar rectificacion

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // esta clase tiene su propia implemnetacion del metodo grabar rectificacion

  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // esta clase tiene su propia implemnetacion del metodo grabar rectificacion

  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // esta clase tiene su propia implemnetacion del metodo grabar rectificacion

  }
  
  public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO)
  {
    this.cabDeclaraDAO = cabDeclaraDAO;
  }

  //rtineo mejoras, grabacion en batch
  public IndicadorDUABatchDAO getIndicadorDUABatchDAO() {
	return indicadorDUABatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setIndicadorDUABatchDAO(IndicadorDUABatchDAO indicadorDUABatchDAO) {
	this.indicadorDUABatchDAO = indicadorDUABatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public CabDeclaraBatchDAO getCabDeclaraBatchDAO() {
	return cabDeclaraBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setCabDeclaraBatchDAO(CabDeclaraBatchDAO cabDeclaraBatchDAO) {
	this.cabDeclaraBatchDAO = cabDeclaraBatchDAO;
  }

}
