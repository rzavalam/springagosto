package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;


import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * <p>Titulo: Clase Utilitaria Comparador.</p>
 * <p>Descripcion: Clase que nos permite comparar y obtener las diferencias
 * entre mapas y listas de mapas segun un enumerado.</p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ComparadorUtil.java</p>
 * <p>Copyright: SUNAT-2011</p>
 *
 * @version 1.0
 */
public interface SoporteComparadorService {

      /**
       * Permite comparar dos listas de mapas segun el enumerado.
       *
       * @param List lstActual   No debe de estar vacio
       * @param List lstHistorico puede ser que este VACIO
       * @param EnumTablaModel enumTablaModel
       * @return List lstResultado   2 opciones VACIO o con datos
       *
       * @throws ServiceException
       */
    public List<Map<String, Object>> comparaList(List<Map<String, Object>> lstActual,
            List<Map<String, Object>> lstHistorico, EnumTablaModel enumTablaModel) throws ServiceException;


      /**
       * Permite comparar dos mapas en base al valor de un enumerado.<br>
       * Se usa cuando se quiere comparar dos mapas de manera directa solo usando el enumerado.<br>
       * En caso de no poseer los datos registrado en el XML de la clave de la entidad
       * retorna un map VACIO.
       *
       * @param Map mapActual    (No debe de estar vacio)
       * @param Map mapHistorico (puede ser que este VACIO)
       * @param EnumTablaModel enumTablaModel
       * @return Map mapResultado SI (PK no registrado XML) return VACIO
       * @throws ServiceException
       */
    public Map<String, Object> comparaMap(Map<String, Object> mapActual,
            Map<String, Object> mapHistorico, EnumTablaModel enumTablaModel) throws ServiceException;



    public Map<String, Object> comparaMap(Map<String, Object> mapActual,
            Map<String, Object> mapHistorico,
            Map<String, Object> mapClave,
            String codTabla) throws ServiceException;


      /**
       * Metodo que nos determina si existen datos cambiados.
       *
       * @param mapRegistro
       * @return boolean (<code>true</code> si contiene datos en el KEY "dataOriginal"
       *                  false si mapRegistro esta VACIO o no contiene  KEY "dataOriginal"
       */
    public boolean esDataCambiada(Map<String, Object> mapRegistro) throws ServiceException;

    /**
     * Metodo de busqueda de elemento Map dentro de la lista <b>listData</b>
     * por el PK de la tabla.
     * Los valores y campos PK de la tabla dependera del <b>enumTablaModel</b>
     * y sera llenado con los datos del <b>mapDataBusqueda</b>
     *
     * @param listData
     * @param enumTablaModel
     * @return Map[String, Object]
     * @throws ServiceException
     *
     * @autor: amancillaa
     */
    public Map<String, Object> obtenerElementoMapXPkTabla(List<Map<String, Object>>
    	listData,Map<String, Object> mapDataBusqueda,EnumTablaModel enumTablaModel) throws ServiceException;


    /**
     * Validar map entidad.
     *
     * @param mapa
     *          [Map<String,Object>] mapa
     * @param codTabla
     *          [String] cod tabla
     * @return [Map<String,Object>] map
     * @throws ServiceException
     *           the service exception
     * @author amancillaa
     * @version 1.0
     */
    public Map<String, Object> validarMapEntidad(Map<String, Object> mapa, String codTabla) throws ServiceException;


    /**
     * Es campo clave.
     *
     * @param nombreTabla
     *          [String] nombre tabla
     * @param nomCampo
     *          [String] nom campo
     * @return true, if successful
     */
    public boolean esCampoClave(String nombreTabla,String nomCampo);

}
