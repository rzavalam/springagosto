package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;



import java.util.List;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.CampoXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * <p>Titulo: Clase Servicio que administra el MAPEO de datos XML y objeto EntidadXML</p>
 * <p>Descripcion: provee servicios de administracion de la estrutura de las Tablas
 *    campos, valores por defecto, errores por defecto registrados en el XML.
 * </p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.servicio.MapeoEntidadService.java</p>
 * <p>Copyright: SUNAT-2012</p>
 *
 * @author amancillaa
 * @version 1.0
 */
public interface SoporteMapeoTablasService {


        /**
         * Permite obtener una Entidad del XML de la lista de Entidades
         * Mapeadas a partir de un nombre.
         * ejemplo: <ent-nombre>cabDeclara</ent-nombre>
         *
         * @param String nombreEntidad
         * @return Entidad o null (si no existe)
         */
        public EntidadXml getEntidad(String nombreEntidad) throws ServiceException;

        /**
         * Metodo que obtiene el campo de una entidad a partir de los nombres
         * del campo y entidad
         *
         * @param String nombreCampo
         * @param String nombreEntidad
         * @return CampoXml o NULL si no lo encuentra o los parametros son NULL
         */
        public CampoXml getCampo(String nombreCampo,
                String nombreEntidad) throws ServiceException;

        /**
         * Metodo que obtiene el campo de una entidad a partir del nombre del
         * campo y su entidad
         *
         * @param String nombreCampo
         * @param EntidadXml entidad
         * @return CampoXml o NULL si no lo encuentra o los parametros son NULL
         * @throws ServiceException
         */
        public CampoXml getCampo(String nombreCampo,
                EntidadXml entidad) throws ServiceException;

        /**
         * Metodo que verifica el valor nombreCampo este registrado como
         * campo PK dentro XML mapping
         * ejemplo: <ent-clave>NUM_CORREDOC,NUM_SECSERIE</ent-clave>
         *
         * @param String nombreCampo
         * @param EntidadXml  entidad
         * @return boolean true SI nombreCampo es una campo clave registrado en el XML
         *                 false SI nombreCampo NO es una campo clave registrado en el XML
         * @throws ServiceException
         */
        public boolean esCampoClave(String nombreCampo, EntidadXml entidad) throws ServiceException;

        /**
         * Devuelve la lista de los campos registrados en el XML como PK de la entidad
         *
         * @param enumTablaModel
         * @return Lista si no esta registrado en el XML retorna List VACIA
         * @throws ServiceException
         */
        public List<String> getListaClave(EnumTablaModel enumTablaModel) throws ServiceException;


}
