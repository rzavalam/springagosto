package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

public interface ConsultaService {

	/**
	 * M�todo que permite obtener una Consulta
	 * 
	 * @author olunar
	 * @param consulta
	 * @return Consulta
	 * @throws ServiceException
	 */
	public Consulta obtenerConsulta(Consulta consulta) throws ServiceException;

	/**
	 * Obtiene una lista de consultas seg�n los par�metros de la consulta
	 * 
	 * @author olunar
	 * @param consulta
	 * @return List<Consulta>
	 * @throws ServiceException
	 */
	public List<Consulta> buscarConsulta(Consulta consulta) throws ServiceException;
	
	/**
	 * 
	 * @author olunar
	 * @param consulta
	 * @return List<Consulta>
	 * @throws ServiceException
	 */
	public List<Consulta> buscarConsultaSimple(Consulta consulta) throws ServiceException;
	
	/**
	 * Obtiene el n�mero m�ximo de secuencia de las consultas de un documento
	 * 
	 * @author olunar
	 * @param consulta
	 * @return Integer
	 * @throws ServiceException
	 */
	public Integer obtenerSecuenciaMaximaConsulta(Consulta consulta) throws ServiceException;
	
	/**
	 * Grabar una consulta
	 * 
	 * @author olunar
	 * @param consulta
	 */
	public void grabarConsulta(Consulta consulta);
	
	/**
	 * Grabar la solicitud de Reconocimiento F�sico
	 * 
	 * @author olunar
	 * @param dua
	 * @param consulta
	 */
	public void grabarSolicitudReconFisico(DUA dua, Consulta consulta);
	
	/**
	 * Obtener los jefes de reconocimiento f�sico
	 * 
	 * @author olunar
	 * @param params
	 * @return <List><Map<String, Object>> Lista de jefes de Reconocimiento F�sico
	 */
	public List<Map<String, Object>> obtenerJefesReconFisico(String codAduana, String codRegimen);
	
	/**
	 * Busca la relacion de jefes de acuerdo al perfil enviado
	 * @author hsaenz
	 * @param params
	 * @param roles
	 * @return
	 */
	// hsaenz: 10/09/2014
	public List<Map<String, Object>> obtenerJefesGrupo(Map<String, Object> params, String[] roles);
}
