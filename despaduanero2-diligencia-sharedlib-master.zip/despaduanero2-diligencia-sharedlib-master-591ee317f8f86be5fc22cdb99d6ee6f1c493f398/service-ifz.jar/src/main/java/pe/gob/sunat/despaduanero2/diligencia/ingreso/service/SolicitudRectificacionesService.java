package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.bean.DatoRectificado;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.DetalleSolicitudRectifica;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;



/**
 * Contiene los metodos auxiliares para las Solicitudes de Rectificaciones
 */
@SuppressWarnings({ "rawtypes"})
public interface SolicitudRectificacionesService
{

  /**
   * <p>
   * Metodo que obtiene los datos de la Rectificacion, de la BD y setea los
   * datos de Rectificacion en los Datos Actuales, Realiza la validacion 1 .. 9
   * y la correlacion de partidas tanto en Series como ITEMs.
   * </p>
   *
   * @param mapParametros
   *          the map parametros
   * @return <code>java.util.Map</code>
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerResultado(Map<String, Object> mapParametros) throws ServiceException;


  /**
   * <p>
   * Permite registrar los cambios cuando la solicitud es diligenciada como
   * procedente
   * </p>
   * .
   *
   * @param mapaDatos
   *          the mapa datos
   * @return the map
   */
  public Map<String, Object> grabarSolicitudRectificacion(Map<String, Object> mapaDatos);

  /**
   * <p>
   * Permite registrar los cambios cuando la solicitud es diligenciada como
   * improcedente
   * <p>
   * .
   *
   * @param params
   *          <code>java.util.Map</code>
   * @author fduartej
   * @since 17.05.2011
   */
  public void grabarSolicitudRectificacionImprocedente(Map params);

  /**
   * <p>
   * Metodo creado con el fin de poder obtener los datos completos de las
   * rectificaciones realizadas
   * </p>
   * .
   *
   * @param strJSONRecti
   *          the str json recti
   * @param strJSONRectiAll
   *          the str json recti all
   * @return String
   * @since 17.05.2011
   */
  public String obtenerRectificacionesDeJSONStrings(String strJSONRecti, String strJSONRectiAll);

  /**
   * <p>
   * Metodo para reasignar canal se factorizo porque el metodo realiza
   * operaciones con un pool diferente y las transacciones del cambio de la
   * rectificacion no se visualizan con la grabacion
   * </p>
   * .
   *
   * @param parametros
   *          the parametros
   */

  /**
   * @param parametros
   */
  public void modificarSolicitudRectificacion(Map<String, Object> parametros);

  /**
   * Devuelve una lista con las rectificaciones que pude tener la dua.
   *
   * @param numeroCorrelativoDua
   *          numcorredoc de la declaracion
   * @return lista de solictudes de rectificacion de la dua
   */
  List<SolicitudRectifica> listSolicitudesRectificaByDua(
    BigDecimal numeroCorrelativoDua);

  /**
   * Grabacion de la rectificaciones mediante objetos
   * @param variablesIngreso
   * @param declaracion
   * @return
   * @throws Exception
   */
  public Map<String, Object> grabarDiligenciaRectificacion(Map<String, Object> variablesIngreso, Declaracion declaracion) throws Exception;

  /**
   * Retorna la diligencia por num_corredoc y num_corredoc_sol
   * @param diligencia
   * @return
   */
  public Diligencia findDiligenciaByPk(Diligencia diligencia);



 /**
   * Merge datos bd and datos regularizados.
   *
   * @param mapParametros
   *          [Map<String,Object>] map parametros
   * @return [Map<String,Object>] map
   * @throws ServiceException
   *           the service exception
   * @author amancillaa
   * @version 1.0
   */
 public Map<String, Object> mergeDatosBDAndDatosRegularizados(Map<String, Object> mapParametros) throws ServiceException;

 /**@author mordonezl
  * @param solRec
  * @param paramEspecialista
  * @param mapDUA
  */
 public Map<String, Object> recuperarSolicitudRectificacionAnuladaRechazada(Map<String, Object> solRec, Map<String, Object> paramEspecialista,Map<String, Object> mapDUA);
 
  //Lmvr- inicio - Complemento de rectificacion
 public Map<String, Object> validarActualizacionFechaRegularizacion(Map<String, Object> mapParametros);
  //Lmvr- fin - Complemento de rectificacion

 /**
  * @author jzevallos
  * @param mapParametros
  * 		[Map<String,Object>] map parametros
  * @return [Map<String,Object>] map
  * */
 public List<Map<String,Object>> grabarSolicitudRectificacionConIncidencia(Map<String, Object> mapParametros);
 
    /**
     * FSW rin10 AFMA
     * @param mapVP
     * @return
     */
    public  boolean tieneLCValorProvionalParaGarantizar(Map mapVP);
  //Inicio RIN08	
  public Map<String, Object> obtenerDatosRectificacion(Map<String, Object> mapData);
  //Fin RIN08	
  
  public Map<String, Object> grabarReasignacionCanal(String numCorredocSol, Map<String, Object> declara);

  //RMC RIN-P47
  public void procesarContingente(Map prmContingente) throws ServiceException;
  
  //RMC RIN-P47
  public boolean validaRecuperaContingente(Map prmContingente) throws ServiceException;
  
  //PAS20171U220200005
  public void grabarNroEnvioParcialMercanciaVigente(String numCorredocDAM,   boolean esAcogidoAntes, boolean estaAcogidoRecien) ;
  
}
