package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;


public class DetAutorizacionRectificacion extends RectificacionAbstract
{

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDetAutorizacion";

  static final String         NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private SerieService  serieService;

  private DetAutorizacionDAO  detAutorizacionDAO;

  //rtineo mejoras, grabacion en batch
  private DetAutorizacionBatchDAO detAutorizacionBatchDAO;

  public DetAutorizacionRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");
    mapClave.put("COD_TIPOPER", "COD_TIPOPER");
    mapClave.put("NUM_SECDOC", "NUM_SECDOC");
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(NOMBRE_LISTA_ORIGINAL, getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, String> mapParametros = new HashMap<String, String>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    //return serieService.obtenerDetAutorizacion(mapParametros);//PAS20171U220200016: correspond�a la busqueda historica, no con data de cabecera
    return serieService.obtenerAllDetAutorizacion(mapParametros);
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  @Override
  public String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DET_AUTORIZACION;
  }

  public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO)
  {
    this.detAutorizacionDAO = detAutorizacionDAO;
  }
  //rtineo mejoras, grabacion en batch
  public DetAutorizacionBatchDAO getDetAutorizacionBatchDAO() {
	return detAutorizacionBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setDetAutorizacionBatchDAO(DetAutorizacionBatchDAO detAutorizacionBatchDAO) {
	this.detAutorizacionBatchDAO = detAutorizacionBatchDAO;
  }
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.detAutorizacionDAO.insertSelective(newRecordMap);

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    detAutorizacionDAO.update(updateRecordMap);

  }
  
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
	  detAutorizacionBatchDAO.insertSelective(newRecordMap);

  }

  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  detAutorizacionBatchDAO.update(updateRecordMap);

  }
  
  public void setSerieService(SerieService serieService)
  {
    this.serieService = serieService;
  }

}
