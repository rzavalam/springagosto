package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.Map;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Interface DudaRazonableService.
 */
@SuppressWarnings({ "rawtypes" })
public interface DudaRazonableService
{


  /**
   * M?todo que busca si tiene duda razonable por concluir
   * por defecto se le setea tipo_eval = " " significa que la duda esta sin concluir
   * @param params String COD_ADUANA,ANN_PRESEN,COD_REGIMEN,NUM_DECLARACION
   *
   * @return boolean (true - si tiene registrado Duda razonable)
   *                 (false - si NO tiene registrado Duda razonable)
   * @throws ServiceException
   *           the service exception
   */
  public Boolean tieneDudaRazonablePendPorConcluir(Map params) throws ServiceException;
  // RIN16
  /**
   * M�todo que busca si tiene duda razonable por concluir.
   * @param declaracion
   * @return boolean (true - si tiene registrado Duda razonable)
   *                 (false - si NO tiene registrado Duda razonable)
   * @throws ServiceException
   */
  public boolean tieneDudaRazonablePendPorConcluir(Declaracion declaracion);

  //inicio P21-P22
  public Boolean duaTieneNotificacionDudaRazonable(Map params) throws ServiceException;
  //fin P21-P22

}
