package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * Creador por amancillaa
 * fecha: 23/04/2015.
 */
public class DiligenciaException extends ServiceException
{


}
