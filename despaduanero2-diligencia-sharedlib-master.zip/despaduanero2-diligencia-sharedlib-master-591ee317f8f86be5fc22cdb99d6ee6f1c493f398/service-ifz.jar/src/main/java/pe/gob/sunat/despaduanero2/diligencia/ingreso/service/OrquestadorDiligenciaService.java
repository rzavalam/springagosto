package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;


/**
 * Servicio de validaciones de Diligencia
 *
 * @author rbegazo
 *
 */
public interface OrquestadorDiligenciaService {

	/**
	 * Procesa el Mensaje con los parametros enviados
	 * @param documento Documento
	 * @param codAduana String codigo de aduana
	 * @param tipoDeTransaccion String tipo de transacci?n
	 * @param tipoDocIdentidadSender String tipo de documento de identidad del sender
	 * @param tipoSender String tipo del sender
	 * @param numDocSender String n?mero de documento del sender
	 * @return Mensaje mensaje procesado.
	 */
	public <T extends Documento> Mensaje procesarMensaje(T documento, String codAduana, String tipoDeTransaccion,
			String tipoDocIdentidadSender, String tipoSender, String numDocSender);

	/**
	 * inicializa la declaracion en objeto
	 * @param declaracion
	 */
	public void setDeclaracion(Declaracion declaracion);
	//EJHM P46
	public void setDeclaracionBD(Declaracion declaracionBD);

	/**
	 * Procesa las reglas de validacion de diligenciaDespacho
	 * @param usuario
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> diligenciaDespachoDeclaracion(UsuarioBean usuario) throws Exception;


/*RIN13FSW*/

	/** 
	 * juazor
	 *
	 */
	public Map<String, Object> diligenciaContDespachoDeclaracion(UsuarioBean usuario) throws Exception;

	/*RIN13INSI*/
	public Map<String, Object> validarServiciosDiligDespacho(UsuarioBean usuario) throws Exception;

}
