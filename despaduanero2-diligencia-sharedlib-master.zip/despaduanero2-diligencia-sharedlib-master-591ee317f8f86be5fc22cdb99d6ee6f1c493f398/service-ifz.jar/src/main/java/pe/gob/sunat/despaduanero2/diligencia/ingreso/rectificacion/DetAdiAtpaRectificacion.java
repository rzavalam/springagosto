package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtpaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtpaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


/**
 * Clase que sirve para realizar la rectificaci�n de la tabla DET_ADI_ATPA
 * 
 * @author olunar
 * 
 */
public class DetAdiAtpaRectificacion extends RectificacionAbstract implements Serializable
{

  private static final long   serialVersionUID        = 8840125308628026022L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDetAdiAtpa";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private DetAdiAtpaDAO       detAdiAtpaDAO;

  //rtineo mejoras, grabacion en batch
  private DetAdiAtpaBatchDAO detAdiAtpaBatchDAO;

  public DetAdiAtpaRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DET_ADI_ATPA;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return detAdiAtpaDAO.select(mapParametros);
  }

  public void setDetAdiAtpaDAO(DetAdiAtpaDAO detAdiAtpaDAO)
  {
    this.detAdiAtpaDAO = detAdiAtpaDAO;
  }

  //rtineo mejoras, grabacion en batch
  public DetAdiAtpaBatchDAO getDetAdiAtpaBatchDAO() {
	return detAdiAtpaBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setDetAdiAtpaBatchDAO(DetAdiAtpaBatchDAO detAdiAtpaBatchDAO) {
	this.detAdiAtpaBatchDAO = detAdiAtpaBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    detAdiAtpaDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    detAdiAtpaDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapDetAdiApta

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
	  detAdiAtpaBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
//rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
	  detAdiAtpaBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapDetAdiApta

  }
}
