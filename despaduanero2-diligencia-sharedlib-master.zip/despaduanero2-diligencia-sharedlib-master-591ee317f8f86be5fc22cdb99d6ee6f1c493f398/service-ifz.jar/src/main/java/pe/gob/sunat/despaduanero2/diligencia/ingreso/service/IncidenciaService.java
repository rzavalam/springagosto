package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.lang.Object;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Interface IncidenciaService.
 */
public interface IncidenciaService
{

  /**
   * Permite asignar las Incidencia del catalogo 336.
   *
   * @param incidenciaBean
   *          the incidencia bean
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<IncidenciaBean> asignarIncidencia(IncidenciaBean incidenciaBean) throws ServiceException;

  /**
   * Obtener list map incidencias.
   *
   * @param lstIncidencias
   *          the lst incidencias
   * @param sNumCorredoc
   *          the s num corredoc
   * @param sCodTipoDiligencia
   *          the s cod tipo diligencia
   * @return the list
   */
  public List<Map<String, Object>> obtenerListMapIncidencias(
    List<IncidenciaBean> lstIncidencias,
    String sNumCorredoc,
    String sCodTipoDiligencia);

  /**
   * Inserta un registro de Incidencia en la BD
   * @param paramsIncidencia
   * @throws ServiceException
   */
  public void insert(Map<String, Object> paramsIncidencia) throws ServiceException;

  /**
   * Retorna un listado de incidencias
   * @param paramsDiligencia
   * @return
   * @throws ServiceException
   */
  public List obtenerIncidencias(Map<String, String> paramsDiligencia)
      throws ServiceException;
  /**INICIO-RIN13**/
  /**
   * Obtiene la incidencia, 
   * si esta ha sido subsanada retorna 
   * con la solicitud de subsanacion 
   * @param parametros de busqueda
   * @return solicitud de subsanacion ZPAE
   * @author gbecerrav
   */
  public SolicitudSubsanacion obtenerIncidenciaSubsanada(Map<String, Object> params) throws ServiceException;
  /**FIN-RIN13**/
  
   
  /**
   * Retorna un registro de tener incidencia F121
   * @param paramsDiligencia
   * @return
   * @throws ServiceException
   */
  public List obtenerIncidenciaF121(Map<String, Object> paramsDiligencia)
      throws ServiceException;
/*RIN13FSW-INICIO*/
/**
   * juazor RIN13
   * @param listAntigua
   * @param listNueva
   * @return
   * @throws ServiceException
   */
  public List<Map<String,Object>> compararListMap(List<Map<String,Object>> listAntigua, List<Map<String,Object>> listNueva)
		  throws ServiceException;


    /**
     * obtiene la lista de incidencias automaticas
     */
  // RIN13-SWF	 
  public List<Incidencia> obtenerIncidenciaAutomatica(Map<String,Object> datos);

  // RIN13-SWF
  public List<Incidencia> obtenerIncidenciaManual();  

/*RIN13FSW-FIN*/
}
