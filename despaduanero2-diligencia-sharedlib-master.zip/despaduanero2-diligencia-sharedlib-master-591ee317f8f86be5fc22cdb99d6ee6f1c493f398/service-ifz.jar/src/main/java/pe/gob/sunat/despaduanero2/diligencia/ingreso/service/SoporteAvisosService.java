package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

public interface SoporteAvisosService {
/*RIN13FSW-INICIO*/


	public void notificacionElectronicaBloqueo(String descComunicacion,
			String codAduana, String annPresen, String codRegimen,
			String numDeclaracion, String nombreCompleto, String[] strings,
			Integer codPlNotiObsRecFisico, String codigoNotificacion,
			String contribuyente);

	public void notificacionElectronica(HashMap<String, Object> parametros)throws ServiceException;
/*RIN13FSW-FIN*/

    enum TIPO_ENVIO { NOTIFICACION("1");

        private final String codigo;
        TIPO_ENVIO(String codigo){
            this.codigo = codigo;
        }

        public String getCodigo()
        {
            return codigo;
        }
    }

    enum AVISO { RESULTADO_PROCEDENTE_RECTIFICACION_ELECTRONICA(226,
                     TIPO_ENVIO.NOTIFICACION,"RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACION ELECTRONICA"),
                 RESULTADO_PROCEDENTE_CON_AFECTACION_GARANTIA_PREVIA_RECTIFICACION_ELECTRONICA(228,
                      TIPO_ENVIO.NOTIFICACION,"RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACION ELECTRONICA CON AFECTACION A LA GARANTIA PREVIA"),
                 RESULTADO_PROCEDENTE_EN_PARTE_RECTIFICACION_ELECTRONICA(229,
                      TIPO_ENVIO.NOTIFICACION,"RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACION ELECTRONICA"),
                 RESULTADO_PROCEDENTE_EN_PARTE_CON_AFECTACION_GARANTIA_PREVIA_RECTIFICACION_ELECTRONICA(230,
                         TIPO_ENVIO.NOTIFICACION,"RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACION ELECTRONICA CON AFECTACION A LA GARANTIA PREVIA"),
                 RESULTADO_IMPROCEDENTE_RECTIFICACION_ELECTRONICA(231,
                         TIPO_ENVIO.NOTIFICACION,"RESULTADO DE IMPROCEDENTE DE LA SOLICITUD DE RECTIFICACION ELECTRONICA");


        private final Integer codCatalogoPlantilla;
        private final TIPO_ENVIO tipoEnvio;
        private final String asuntoDelEnvio;

        AVISO(Integer codCatalogoPlantilla,TIPO_ENVIO tipoEnvio, String asuntoDelEnvio){
            this.codCatalogoPlantilla = codCatalogoPlantilla;
            this.tipoEnvio = tipoEnvio;
            this.asuntoDelEnvio = asuntoDelEnvio;
        }

        public Integer getCodCatalogoPlantilla()
        {
            return codCatalogoPlantilla;
        }

        public TIPO_ENVIO getTipoEnvio()
        {
            return tipoEnvio;
        }

        public String getAsuntoDelEnvio()
        {
            return asuntoDelEnvio;
        }
    }

    /*public void noticarResultadoDeLaRectificacionElectronica(Integer TipoPlantilla,Map<String, Object> Data);*/

	public void noticarResultadoDeLaRectificacionElectronica(AVISO aviso,Map<String, Object> Data);

	//PAS20165E220200127
	public void noticarResultadoDeLaRectificacion(AVISO aviso,Map<String, Object> Data);
    /**se comenta bad implementacion**/
    /*public Integer getCodigoResultado(String resultado);*/
/*RIN13FSW-INICIO*/	
	/**
	 * @author juazor
	 * */
	public void notificarContinuacionDespacho(
									            String descripcion,
									            String codAduana,
									            String annPresen,
									            String codRegimen,
									            String numDeclaracion,
									            String codFuncionario,
									            String[] codUsuario,
									            Integer codPlantilla,
									            String codTipoAviso,
									            String tipoUsuario,Map<String, Object> destinatarios)throws ServiceException;	
	/*RIN13-SWF*/
	 public void notificarDatado(
	          String descripcion,
	          String codAduana,
	          String annPresen,
	          String codRegimen,
	          String numDeclaracion,
	          String codFuncionario,
	          String[] codUsuario,
	          Integer codPlantilla,
	          String codTipoAviso,
	          String tipoUsuario)throws ServiceException;
	 
		/**
		 * @author juazor
		 * */
		public void grabarComunicacionNotificacion(Map<String, Object> mapaCom)throws ServiceException; 
		
		  /**
		   * env�o de avisos electr�nicos durante los
		   *
		   * Notificar observacion.
		   * @author RIN13 SWF
		   *
		   * @param descripcion
		   *          the descripcion
		   * @param codAduana
		   *          the cod aduana
		   * @param annPresen
		   *          the ann presen
		   * @param codRegimen
		   *          the cod regimen
		   * @param numDeclaracion
		   *          the num declaracion
		   * @param codFuncionario
		   *          the cod funcionario
		   * @param codUsuario
		   *          the cod usuario
		   * @param codPlantilla
		   *          the cod plantilla
		   * @param codTipoAviso
		   *          the cod tipo aviso
		   * @param tipoUsuario
		   *          the tipo usuario
		   *
		   * @throws ServiceException
		   *           the service exception
		   *
		   */
		  public void notificarObservacion(
			String descripcion,
		    String codAduana,
		    String annPresen,
		    String codRegimen,
		    String numDeclaracion,
		    String codFuncionario,
		    String[] codUsuario,
		    Integer codPlantilla,
		    String codTipoAviso,
		    String tipoUsuario,Map<String, Object> destinatarios) throws ServiceException;
	
/*RIN13FSW-FIN*/

			//inicio lalberti NUMERACION DAM SIN ICA
			 public void notificarRectificacionPuntoLlegada(String nroDeclaracion, String codUsuarioNotificado, String observacion);
			//fin lalberti NUMERACION DAM SIN ICA
}