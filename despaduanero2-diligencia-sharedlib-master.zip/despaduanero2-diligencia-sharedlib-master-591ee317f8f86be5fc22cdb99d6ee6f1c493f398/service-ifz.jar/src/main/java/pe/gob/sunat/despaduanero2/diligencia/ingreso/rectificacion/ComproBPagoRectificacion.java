package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;


/**
 * 
 * @author fjonislla
 * 
 */
public class ComproBPagoRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -3254375510323985719L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstComproBPago";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private static final String SUFIJO_FACTURA_SUCESIVA = "_SUCESIVA";

  private ComprobPagoDAO      comprobPagoDAO;

  private FormBProveedorDAO   formBProveedorDAO;

  //rtineo mejoras, grabacion en batch
  private ComprobPagoBatchDAO comprobPagoBatchDAO;
  private FormBProveedorBatchDAO formBProveedorBatchDAO;

  public ComproBPagoRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    // mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");//gmontoya
    mapClave.put("NUM_SECFACT", "NUM_SECFACT");
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return comprobPagoDAO.select(mapParametros);
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  @Override
  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_COMPROBPAGO;
  }

  public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO)
  {
    this.comprobPagoDAO = comprobPagoDAO;
  }

  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int count = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin      
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      Comparador comparador = new Comparador();
      Map<String, Object> mapPK = new HashMap<String, Object>();
      mapPK.put("NUM_CORREDOC", "NUM_CORREDOC");
      mapPK.put("NUM_SECFACT", "NUM_SECFACT");
      /* olunar */
      // mapPK.put("NUM_SECPROVE", "NUM_SECPROVE");//gmontoya
      /* fin */
      for (Map<String, Object> mapComproBPago : (ArrayList<Map<String, Object>>) mapDatos
          .get(getNombreListaResultante()))
      {
        if (log.isDebugEnabled())
        {

          if (log.isDebugEnabled())
            log.debug(" COMPROBPAGO :" + mapComproBPago);
        }
        /* olunar */
        if (INDICADOR_NUEVO_REGISTRO.equals(mapComproBPago.get("indica")))
        {
          try
          {
            // seteamos tipo comprobante y tipo grabado en duro
            mapComproBPago.put("COD_TIPCOMPROBANTE", "01");// 01:Factura
            mapComproBPago.put("COD_TIPGRABADO", "P");// P:Portal del
                                                      // especialista
            //rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	comprobPagoBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapComproBPago));
            }else{
            	//continua con metodo anterior
            comprobPagoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapComproBPago));
          }
            //rtineo mejoras, fin
          }
          catch (DataIntegrityViolationException e)
          {
            mapComproBPago.put("IND_DEL", 0);
            //rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	comprobPagoBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(mapComproBPago));
            }else{
            	//continua con metodo anterior
            comprobPagoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(mapComproBPago));
          }
            //rtineo merjoras, fin
          }
          // grabamos en ofirecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(mapComproBPago, mapClave);

          mapComproBPago.put("dataOriginal", new HashMap<String, Object>(mapComproBPago));
          mapComproBPago.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(mapComproBPago, numCorredocSol, true);        	  
          }else{
          registrarRectiOficio(mapComproBPago, numCorredocSol, true);
        }
        }
        else
        {
          /* fin */
          for (Map<String, Object> mapComproBPagoAntes : (ArrayList<Map<String, Object>>) mapDatos
              .get(getNombreListaOriginal()))
          {
            if (mapComproBPagoAntes.get("NUM_SECFACT").toString().trim()
                .equals(mapComproBPago.get("NUM_SECFACT").toString().trim()))
            {
              // &&
              // mapComproBPagoAntes.get("NUM_SECPROVE").toString().trim().equals(mapComproBPago.get("NUM_SECPROVE").toString().trim())){//gmontoya
              mapDiferenciaGrabar = comparador.comparaMap(mapComproBPagoAntes, mapComproBPago, mapPK);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (log.isDebugEnabled())
                  log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                // insertamos el codigo de la tabla
                Map<String, Object> mapProvisional = new HashMap<String, Object>();
                for (Entry<String, Object> entrada : mapComproBPago.entrySet())
                {
                  mapProvisional.put(entrada.getKey().toLowerCase(), entrada.getValue());

                }
                /* olunar - al realizar IPU, rafa verifica */
                // comprobPagoDAO.update(mapComproBPago);//habilitar cuando
                // DILIGENCIA cambie a mayusculas los parametros del metodo
                // UPDATE en el xml
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                    comprobPagoBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                    /* fin */
			//PAS20155E220200139
                    //formBProveedorBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapProvisional)); no es necesario actualizar formBProveedor campos (tipgragado y indel) el indel ya se actualiza al invocar formbProveedor
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);// mapDiferenciaGrabar,
                }else{
                comprobPagoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));
                /* fin */
    			//PAS20155E220200139
                //formBProveedorDAO.update(Utilidades.transformFieldsToRealFormat(mapProvisional)); no es necesario actualizar campos (tipgragado y indel)  el indel ya se actualiza al invocar formbProveedor
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);// mapDiferenciaGrabar,
                                                                                 // colocar
                                                                                 // despues.
                }
                count++;
              }
              break;
            }
          }
        }
      }
    }
    return count;
  }

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#getTableRectificadoMergedBD(java.util.Map,
   * java.lang.Long, boolean)
   */
  @Override
  public List<Map<String, Object>> getTableRectificadoMergedBD(
      Map<String, Object> parametrosBd,
      Long numeroCorrelativoSolicitud,
      boolean mergeRectificados)
  {
    // T0067
    List<Map<String, Object>> resultFactura = super.getTableRectificadoMergedBD(parametrosBd,
        numeroCorrelativoSolicitud, mergeRectificados);

    RectificacionAbstract rectifiFacturaSucesiva = fabricaDeServicios.getService("diligencia.rectificacion.codtabla."
        + Constantes.COD_TABLA_FACTUSUCE);
    List<Map<String, Object>> lstFacturaSucesiva = rectifiFacturaSucesiva.getTableRectificadoMergedBD(parametrosBd,
        numeroCorrelativoSolicitud, mergeRectificados);
    // Agregamos la razon social al proveedor
    Iterator<Map<String, Object>> itLstFactura = resultFactura.iterator();

    while (itLstFactura.hasNext())
    {
      Map<String, Object> mapFactura = itLstFactura.next();

      final Map<String, Object> mapParamQuery = new HashMap<String, Object>();

      // buscamos la informacion de la factura sucesiva
      mapParamQuery.put("NUM_SECPROVE", mapFactura.get("NUM_SECPROVE"));
      mapParamQuery.put("NUM_SECFACT", mapFactura.get("NUM_SECFACT"));
      mapParamQuery.put("NUM_CORREDOC", mapFactura.get("NUM_CORREDOC"));
      mapFactura.putAll(buscarFacturaSucesiva(lstFacturaSucesiva, mapParamQuery, SUFIJO_FACTURA_SUCESIVA));

    }
    return resultFactura;
  }

  private Map<? extends String, ? extends Object> buscarFacturaSucesiva(
      List<Map<String, Object>> lstFacturaSucesiva,
      Map<String, Object> mapParamQuery,
      String sufijoFacturaSucesiva)
  {

    Map<String, Object> mapFacturaSucesiva = new HashMap<String, Object>();

    Map<String, Object> facturaSucesivaFound = findInListMapByMapParam(lstFacturaSucesiva, mapParamQuery);

    if (facturaSucesivaFound != null && !facturaSucesivaFound.isEmpty())
    {
      mapFacturaSucesiva.put("NUM_FACT" + sufijoFacturaSucesiva,
          ObjectUtils.toString(facturaSucesivaFound.get("NUM_FACT")));
      mapFacturaSucesiva.put("FEC_FACT" + sufijoFacturaSucesiva,
          ObjectUtils.toString(facturaSucesivaFound.get("FEC_FACT")));
      mapFacturaSucesiva.put("MTO_FACT" + sufijoFacturaSucesiva,
          ObjectUtils.toString(facturaSucesivaFound.get("MTO_FACT")));
    }

    return mapFacturaSucesiva;
  }

  public DatoFactura mapToObject(Map<String, Object> comproBPago)
  {
    DatoFactura factura = new DatoFactura();

    factura.setNumcorredoc(new Long(ObjectUtils.toString(comproBPago.get("NUM_CORREDOC"), "0")));

    factura.setNumsecprove(new Integer(ObjectUtils.toString(comproBPago.get("NUM_SECPROVE"), "0")));
    factura.setNumsecfactu(new Integer(ObjectUtils.toString(comproBPago.get("NUM_SECFACT"), "0")));
    factura.setCnttotitems(new Integer(ObjectUtils.toString(comproBPago.get("CNT_TOTITEMS"), "0")));

    factura.setMtofactufob(new BigDecimal(ObjectUtils.toString(comproBPago.get("MTO_FACT"), "0")));

    factura
        .setFecfactura(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(comproBPago.get("FEC_FACT"), " ")));

    factura.setNumfactura(ObjectUtils.toString(comproBPago.get("NUM_FACT"), " "));
    factura.setIndtipodecl(ObjectUtils.toString(comproBPago.get("IND_DDJJ"), " "));
    factura.setCodincoterm(ObjectUtils.toString(comproBPago.get("COD_INCOTERM"), " "));
    factura.setDeslugtrans(ObjectUtils.toString(comproBPago.get("DIR_LUGARTRANS"), " "));
    factura.setCodpaisembar(ObjectUtils.toString(comproBPago.get("COD_PAISEMBARQUE"), " "));
    factura.setCodmoneda(ObjectUtils.toString(comproBPago.get("COD_MONEDA"), " "));
    factura.setCodtipograbado(ObjectUtils.toString(comproBPago.get("COD_TIPGRABADO"), " "));
    factura.setCodtipocomprobante(ObjectUtils.toString(comproBPago.get("COD_TIPCOMPROBANTE"), " "));

    return factura;
  }

  public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
  {
    this.formBProveedorDAO = formBProveedorDAO;
  }
  //rtineo mejoras, grabacion en batch
  public ComprobPagoBatchDAO getComprobPagoBatchDAO() {
	return comprobPagoBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setComprobPagoBatchDAO(ComprobPagoBatchDAO comprobPagoBatchDAO) {
	this.comprobPagoBatchDAO = comprobPagoBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public FormBProveedorBatchDAO getFormBProveedorBatchDAO() {
	return formBProveedorBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFormBProveedorBatchDAO(FormBProveedorBatchDAO formBProveedorBatchDAO) {
	this.formBProveedorBatchDAO = formBProveedorBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    // no hace nada por que se reescribe el metodo grabarRectificacion
  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    // no hace nada por que se reescribe el metodo grabarRectificacion
  }

  //rtineo mejoras, agregado para la grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    // no hace nada por que se reescribe el metodo grabarRectificacion
  }

  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    // no hace nada por que se reescribe el metodo grabarRectificacion
  }
}
