package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

@SuppressWarnings({ "rawtypes" })
public interface CasillaFormatoService {

  /**
   * Metodo que nos permite obtener un mapa con las descripciones de la seccion y columna
   *
   * @param String
   *          synonimo de la tabla
   * @param String
   *          campo de la tabla
   * @return Map<String,String> devuelve e mapa con las descripciones de la seccion o de la columna
   * @throws ServiceException
   */
  public Map<String, String> buscarDescripcion(final String tabla,
      final String campo);

  /**
   * Metodo que busca obtener un Json de la Clave de la tabla pero usando campos descriptivos
   * para ellos obtenemos la descripcion del campo DES_NEMONICO de la tabla catcasillaformato
   * @param Mapclave : Clave que puede estar compuesto por varios campos
   * @param sinonimoTabla : Tabla que contiene la clave
   * @return una cadena en Json con la nueva descripcion de la clave
   * @author rbegazo
   */
  public String generaClaveMostrar(Map mapClave,
      String sinonimoTabla);

}
