package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


public enum EnumRectifica
{

  // DECLARACION
  cod_aduana_desc("cod_aduana", "00"),
  cod_modalidad_desc("cod_modalidad", "306"),
  cod_tipdesp_desc("cod_tipdesp", "310"),
  cod_lugarrecep_desc("cod_lugarrecep", "402"),
  cod_tiplugarrecep_desc("cod_tiplugarrecep", "UG"),
  COD_ENTIPAGO_DESC("COD_ENTIPAGO", "15"),
  COD_MODPAGO_DESC("COD_MODPAGO", "11"),
  cod_tiptratmerc_desc("cod_tiptratmerc", "313"),
  COD_CANAL_DESC("COD_CANAL", "AR"),
  cod_estdua_desc("cod_estdua", "335"),
  COD_TIPOPLAZO_DESC("COD_TIPOPLAZO", "312"),
  COD_VIATRANS_DESC("COD_VIATRANS", "10"),
  COD_TIPDOCEMPDOCTRA_DESC("COD_TIPDOCEMPDOCTRA", "27"),
  COD_VIA_DESC("COD_VIA", "10"),
  COD_TIPDOC_PTR_DESC("COD_TIPDOC_PTR", "27"),
  COD_ADUANA_DTR_DESC("COD_ADUANA_DTR", "00"),
  COD_TIPADUDEST_DESC("COD_TIPADUDEST", "UG"),
  COD_TIPDOC_PIM_DESC("COD_TIPDOC_PIM", "27"),
  COD_TIPDOC_PDE_DESC("COD_TIPDOC_PDE", "27"),
 /*INICIO PAS20124E600000358*/
    COD_ADUDEST_DESC("COD_ADUDEST", "G121"),
/*FIN    PAS20124E600000358*/
  // DAV
  cod_nivelcomer_desc("cod_nivelcomer", "85"),
  cod_condprove_desc("cod_condprove", "86"),
  cod_natutrans_desc("cod_natutrans", "81"),
  cod_formaenvio_desc("cod_formaenvio", "84"),
  cod_tipinterm_desc("cod_tipinterm", "87"),
  cod_docprovlocal_desc("cod_docprovlocal", "27"),
  IND_INTEMEDIARIO_DESC("IND_INTEMEDIARIO", ""),
  // fin DAV
  // Facturas
  COD_PAISEMBARQUE_DESC("COD_PAISEMBARQUE", "J2"),
  COD_MONEDA_DESC("COD_MONEDA", "J1"),
  COD_TIPOVALOR_DESC("COD_TIPOVALOR", "332"),
  COD_PAISORIGEN_DESC("COD_PAISORIGEN", "J2"),
  IND_SOFTWARE_DESC("IND_SOFTWARE", "342"),
  COD_UNICOMER_DESC("COD_UNICOMER", "29"),
  COD_UMEQUI_DESC("COD_UMEQUI", "29"),
  COD_TIPOPER_DESC("COD_TIPOPER", "327"),
  COD_ENTI_DESC("COD_ENTI", "49"),
  COD_TIPDOC_DESC("COD_TIPDOC", "367"),
  COD_TIPDOC_PARTICIPANTE_DESC("COD_TIPDOC_PARTICIPANTE", "27"),
  COD_ESTMERC_DESC("COD_ESTMERC", "25"),
  COD_TIPCERTIFICADO_DESC("COD_TIPCERTIFICADO", "1H"),
  COD_EMISCERT_DESC("COD_EMISCERT", "1I"),
  COD_CRITERIOORIGEN_DESC("COD_CRITERIOORIGEN", "1J"),
  /*documento autorizante */
  COD_DOCASOCIACION_DESC("COD_TIPDOCASO", "75"),
  COD_INDICADOR_DESC("COD_INDICADOR", "302"),/*P46-PAS20155E410000032*/
  COD_TIPREGUL("COD_TIPREGUL","963"),/*P46-PAS20155E410000032 EJHM*/
  // COD_TIPODOCUMENTO_DESC("COD_TIPDOC","75");
  //P24
  COD_UNIFISICA_DESC("COD_UNIFISICA","29");
   /*INICIO PAS20124E600000358*/
	private String codCampo;
	private String codCatalogoDelCampo;



	EnumRectifica(String codCampo, String codCatalogoDelCampo) {
		this.setCodCampo(codCampo);
		this.setCodCatalogoDelCampo(codCatalogoDelCampo);
  }

	 /**
     * busca EnumRectifica por su atributo codTabla codigo de tabla.
     *
     * @param codCampo [String]
     * @return EnumRectifica
     */
    public static EnumRectifica getEnumRelacionCamposCatalogoCodCampo(String codCampo){

        try {

                return valueOf(codCampo.toUpperCase());

            } catch (IllegalArgumentException e) {
                for (EnumRectifica enumRectifica : EnumRectifica.values()) {
                    if (enumRectifica.codCampo.equalsIgnoreCase(codCampo)) {
                            return enumRectifica;
                    }
  }

                throw new IllegalArgumentException("codigo del Campo no esta registrado en este EnumRectifica verificar: "
                        + codCampo);
            }
     }

    /**
     * busca EnumRectifica por su atributo codTabla codigo de tabla.
     *
     * @param codCampo [String]
     * @return codigo catalogo del campo
     */
    public static String getCodCatalogoPorCodCampo(String codCampo){

        try {

            EnumRectifica EnumRectifica = valueOf(codCampo.toUpperCase());
                return EnumRectifica.codCatalogoDelCampo;

            } catch (IllegalArgumentException e) {
                for (EnumRectifica enumRectifica : EnumRectifica.values()) {
                    if (enumRectifica.codCampo.equalsIgnoreCase(codCampo)) {
                            return enumRectifica.codCatalogoDelCampo;
                    }
                }

                throw new IllegalArgumentException("codigo del Campo no esta registrado en este EnumRectifica verificar: "
                        + codCampo);
            }
  }

	public void setCodCampo(String codCampo) {
		this.codCampo = codCampo;
  }

	public String getCodCampo() {
		return codCampo;
  }

	public void setCodCatalogoDelCampo(String codCatalogoDelCampo) {
		this.codCatalogoDelCampo = codCatalogoDelCampo;
  }

	public String getCodCatalogoDelCampo() {
		return codCatalogoDelCampo;
  }

/*FIN    PAS20124E600000358*/

}
