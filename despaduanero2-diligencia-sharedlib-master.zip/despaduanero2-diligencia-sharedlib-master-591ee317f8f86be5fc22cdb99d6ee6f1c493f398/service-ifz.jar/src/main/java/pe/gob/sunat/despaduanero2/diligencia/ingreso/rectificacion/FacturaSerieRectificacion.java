package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class FacturaSerieRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 1330346869673318833L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstFacturaSerie";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FacturaSerieDAO     facturaSerieDAO;
  //rtineo mejoras, grabacion en batch
  private FacturaSerieBatchDAO facturaSerieBatchDAO;

  public FacturaSerieRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECFACT", "NUM_SECFACT");
    mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FACTURA_SERIE;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return facturaSerieDAO.select(mapParametros);
  }

  public void setFacturaSerieDAO(FacturaSerieDAO facturaSerieDAO)
  {
    this.facturaSerieDAO = facturaSerieDAO;
  }
  //rtineo mejoras, grabacion en batch
  public FacturaSerieBatchDAO getFacturaSerieBatchDAO() {
	return facturaSerieBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFacturaSerieBatchDAO(FacturaSerieBatchDAO facturaSerieBatchDAO) {
	this.facturaSerieBatchDAO = facturaSerieBatchDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.facturaSerieDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    facturaSerieDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapFacturaSerie

  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    this.facturaSerieBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }
  
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    facturaSerieBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapFacturaSerie

  }

  
}
