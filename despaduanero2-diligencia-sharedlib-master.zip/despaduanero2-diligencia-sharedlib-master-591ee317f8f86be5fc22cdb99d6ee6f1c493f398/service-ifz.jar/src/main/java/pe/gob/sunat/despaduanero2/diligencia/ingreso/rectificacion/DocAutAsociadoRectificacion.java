package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class DocAutAsociadoRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 6476181296744846115L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstDocAutAsociado";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private DocAutAsociadoDAO   docAutAsociadoDAO;
  //rtineo mejoras, grabacion en batch
  private DocAutAsociadoBatchDAO docAutAsociadoBatchDAO;

  public DocAutAsociadoRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECDOC", "NUM_SECDOC");
    mapClave.put("COD_TIPOPER", "COD_TIPOPER");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_DOCAUT_ASOCIADO;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, String> mapParametros = new HashMap<String, String>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return docAutAsociadoDAO.select(mapParametros);
  }

  public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
  {
    this.docAutAsociadoDAO = docAutAsociadoDAO;
  }

  //rtineo mejoras, grabacion en batch
  public DocAutAsociadoBatchDAO getDocAutAsociadoBatchDAO() {
	return docAutAsociadoBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setDocAutAsociadoBatchDAO(
		DocAutAsociadoBatchDAO docAutAsociadoBatchDAO) {
	this.docAutAsociadoBatchDAO = docAutAsociadoBatchDAO;
  }
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    docAutAsociadoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    docAutAsociadoDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapDocAutAsociado);

  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    docAutAsociadoBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    docAutAsociadoBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));// mapDocAutAsociado);

  }
}
