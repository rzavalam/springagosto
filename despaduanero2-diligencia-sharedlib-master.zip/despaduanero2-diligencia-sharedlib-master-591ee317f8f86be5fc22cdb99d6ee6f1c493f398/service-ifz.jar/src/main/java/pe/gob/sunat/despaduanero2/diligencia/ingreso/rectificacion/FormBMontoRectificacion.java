package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class FormBMontoRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = 1L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstFormbMonto";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private FormBMontoDAO       formBMontoDAO;
  //rtineo mejoras, grabacion en batch
  private FormBMontoBatchDAO formBMontoBatchDAO;

  public FormBMontoRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");
    mapClave.put("COD_MONTO", "COD_MONTO");
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(NOMBRE_LISTA_ORIGINAL, getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return formBMontoDAO.selectByMap(mapParametros);
  }

  @Override
  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  @Override
  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  @Override
  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_FORMB_MONTO;
  }

  public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO)
  {
    this.formBMontoDAO = formBMontoDAO;
  }

  //rtineo mejoras, grabacion en batch
  public FormBMontoBatchDAO getFormBMontoBatchDAO() {
	return formBMontoBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setFormBMontoBatchDAO(FormBMontoBatchDAO formBMontoBatchDAO) {
	this.formBMontoBatchDAO = formBMontoBatchDAO;
  }
  
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.formBMontoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    formBMontoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap));
  }
  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    this.formBMontoBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    formBMontoBatchDAO.updateSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap));
  }
}
