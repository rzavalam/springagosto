package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;

public class VFobProvisionalRectificacion extends RectificacionAbstract {

	private static final String NOMBRE_LISTA_ORIGINAL = "lstVFobProvisional";
	private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL+"Actual";
	private VFOBProvisionalDAO vFOBProvisionalDAO;	
	//rtineo mejroas, grabacion en batch
	private VFOBProvisionalBatchDAO vFOBProvisionalBatchDAO;
	
	public VFobProvisionalRectificacion() {
		mapClave = new HashMap<String, Object>();
		mapClave.put("NUM_SECITEM", "NUM_SECITEM");
 //RIN10-FSW AFMA
		//mapClave.put("NUM_SECFACT", "NUM_SECFACT");
		//mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");
		//RIN10-FSW AFMA
		mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
	}
	
	@Override
	protected Map<String, Object> getDatosInicialesRectifacion(
			Map<String, Object> mapResultado, Map<String, Object> mapValores) {
		mapResultado.put(NOMBRE_LISTA_ORIGINAL,getTablaBD(mapValores));		
		return mapResultado;
	}
	
	@Override
	protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros){
		Map<String, Object> mapParametros = new HashMap<String, Object>();
		// Se recupera por Documento los valores
		mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
		return vFOBProvisionalDAO.findMapMontoProvByMap(mapParametros);
	}

	@Override
	protected String getNombreListaOriginal() {
		return NOMBRE_LISTA_ORIGINAL;
	}

	@Override
	protected String getNombreListaResultante() {
		return NOMBRE_LISTA_RESULTANTE;
	}

	@Override
	protected String getCodTablaRectificacion() {
		return Constantes.COD_TABLA_VFOB_PROVISIONAL;
	}

	public void setvFOBProvisionalDAO(VFOBProvisionalDAO vFOBProvisionalDAO) {
		this.vFOBProvisionalDAO = vFOBProvisionalDAO;
	}
	//rtineo mejoras, grabacion en batch
	public VFOBProvisionalBatchDAO getvFOBProvisionalBatchDAO() {
		return vFOBProvisionalBatchDAO;
	}
	//rtineo mejoras, grabacion en batch
	public void setvFOBProvisionalBatchDAO(VFOBProvisionalBatchDAO vFOBProvisionalBatchDAO) {
		this.vFOBProvisionalBatchDAO = vFOBProvisionalBatchDAO;
	}

	@Override
	protected void insertRecord(Map<String, Object> newRecordMap) {
		vFOBProvisionalDAO.insertMapSelective(newRecordMap);
		
	}

	@Override
	protected void updateRecord(Map<String, Object> updateRecordMap) {
		vFOBProvisionalDAO.updateMapSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); 
	}

	//rtineo mejoras, grabacion en batch
	@Override
	protected void insertRecordBatch(Map<String, Object> newRecordMap) {
		vFOBProvisionalBatchDAO.insertMapSelective(newRecordMap);
		
	}
	//rtineo mejoras, grabacion en batch
	@Override
	protected void updateRecordBatch(Map<String, Object> updateRecordMap) {
		vFOBProvisionalBatchDAO.updateMapSelective(Utilidades.transformFieldsToRealFormat(updateRecordMap)); 
	}
}
