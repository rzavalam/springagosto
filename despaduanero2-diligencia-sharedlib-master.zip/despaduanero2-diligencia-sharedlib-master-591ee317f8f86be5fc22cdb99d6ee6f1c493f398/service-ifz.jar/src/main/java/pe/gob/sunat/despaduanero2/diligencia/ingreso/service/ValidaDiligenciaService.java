package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;



import java.util.Map;

import pe.gob.sunat.administracion2.tramite.model.DocumentoSustento;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;




/**
 * Metodos que Validaciones aplicados dentro de la
 * diligencia
 *
 * @author rmontes
 */
@SuppressWarnings({ "rawtypes" })
public interface ValidaDiligenciaService
{

  /**
   * Valida merc ayuda humanitaria.
   *
   * @param params
     *            caduana : codigo de la aduana a la que corresponde el
     *            documento COD_TIPTRATMERC : Valor de la declaracion
     *            NUM_PARTNANDI : Valor de pantalla (series) FEC_DECLARACION :
     *            Valor de la declaracion COD_REGIMEN : Valor de la declaracion
   * @return the string
   * @throws ServiceException
   *           the service exception
   */

  public String validaMercAyudaHumanitaria(Map params) throws ServiceException;

  /**
   * Valida incentivo migrat.
   *
   * @param params
     *            caduana : aduana de atencion IND_ACOGCODLIBER : data de
     *            pantalla COD_EXONMERC : data de pantalla NUM_CORREDOC : data
     *            de det_declara NUM_SECSERIE : data de det_declara COD_REGIMEN
     *            : data de cab_declara COD_ADUANA : data de cab_declara
     *            CTIPODOC : data de cab_declara CDOCUMEN : data de cab_declara
     *            FEC_DECLARACION : data de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaIncentivoMigrat(Map params) throws ServiceException;





  /**
   * Valida tp n212_208.
   *
   * @param params
     *            CTIPODOC : data de cab_declara CDOCUMEN : data de cab_declara
     *            FEC_EVAL : data de cab_declara CODI_ADUAN : data de
     *            cab_declara COD_REGIMEN : data de cab_declara TLIB : data de
     *            det_declara () CLIB : data de det_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaTPN212_208(Map params) throws ServiceException;

  /**
   * Valida ultractividad fec.
   *
   * @param params
     *            COD_ULTRACTIVIDAD : data det_declara FEC_CARCR : data de
     *            cab_declara COD_REGIMEN : data de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaUltractividadFec(Map params) throws ServiceException;

  /**
   * Valida ultractividad prece.
   *
   * @param params
     *            COD_ULTRACTIVIDAD : data det_declara NUM_CORREDOC : data
     *            det_declara NUM_SECSERIE : data det_declara COD_REGIMEN : data
     *            de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaUltractividadPrece(Map params) throws ServiceException;

  /**
   * Validar tlc.
   *
   * @param params
     *            TLIB : data det_declara CLIB : data det_declara COD_PAISORIGEN
     *            : data det_declara COD_REGIMEN : data de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validarTLC(Map params) throws ServiceException;

  /**
   * Validar merc ayuda human.
   *
   * @param params
     *            COD_PART : Codigo de partida de la serie evaluada.
     *            COD_TIPTRATMERC : Tipo de tratamiento de la mercaderia en la
     *            declaracion. FEC_EVAL : Fecha a evaluar en formato yyyyMMdd
     *            (fecha de la declaracion) caduana : codigo de la aduana en la
     *            que se realiza la diligencia
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validarMercAyudaHuman(Map params) throws ServiceException;


  /**
     * Validar que si se acoge al TPN 21:DERECHOS PAGADOS DESPACHOS VIGENTES o
     * 222 CONTRATO LLAVE EN MANO declare regimen de precedencia importacion 10
     * validar que si declara TPN 93 o 183 (REPOSICION DE MERCANCIAS EN
     * FRANQUICIA, REFINERIA LA PAMPILLA-CONVENIO ESTAB.JURIDICA) registre que
     * se acoge al regimen de precedencia reposicion (12)
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaTieneRegPrecedencia(Map<String, Object> params) throws ServiceException;

  /**
     * El tipo de operaci�n 2008, validar que la numpartnandi exista en la
     * tabla cat_refpartidas con tipo_uso='NAV' y se encuentre vigente.
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaTienePartida(Map<String, Object> params) throws ServiceException;

  /**
   * Valida ceticos.
     * Vcod_tipdesp=2010 && aduana=172 , validar exista tipo doc y numero doc en
     * la tabla CTUSUARIO (verificar si solo esta en tacna).
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaCeticos(Map<String, Object> params) throws ServiceException;


  /**
   * Valida tiene documentos sustentorios para la rectificacion de oficio.
   *
   * @param params
   *          the params
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public DocumentoSustento obtenerDocumentoSustentatorio(DocumentoSustento documentoSustento);


  /**
   * Find dua diligenciada.
   *
   * @param numCorreDoc
   *          the num corredoc
   * @return the map
   */
  public Map<String, Object> findDuaDiligenciada(String numCorreDoc);

  /**
   * Find primera diligencia.
   *
   * @param params
   *          the params
   * @return the map
   */
  public Map<String, Object> findPrimeraDiligencia(Map<String, Object> params);

  /**
   * Find ultima diligencia.
   *
   * @param params
   *          the params
   * @param declaracion
   *          the declaracion
   * @return the map
   */
  public Map<String, Object> findUltimaDiligencia(Map<String, Object> params, Map<String, Object> declaracion);

  /**
   * Valida tiene diligencia tipo.
   * Metodo modificado 20130115
   * Valida si la declaracion tiene diligencia para el tipo de
   * canal especificado
   * @author matc
   * @param params
   *          the params
   * @return true, if successful
   */
  public boolean validaTieneDiligenciaTipo(Map<String, Object> params);


  /**
   * Validar cambio de modalidad.
   *
   * @param params
   *          [Map<String,Object>] params
   * @return [Map<String,String>] map
   * @author amancillaa
   * @version 1.0
   */
  public Map<String,String> validarCambioDeModalidad(Map<String, Object> params);

  /**
   * Validar cambio de fecha descarga.
   *
   * @param params
   *          [Map<String,Object>] params
   * @return [String] string
   * @author amancillaa
   * @version 1.0
   */
  public String validarCambioDeFechaDescarga(Map<String, Object> params);

  /**
   * Validar cambio de declarante.
   *
   * @param params
   *          [Map<String,Object>] params
   * @return [String] string
   * @author amancillaa
   * @version 1.0
   */
  public String validarCambioDeDeclarante(Map<String, Object> params);
  
  
  /**
   * Validar datos del Declarante
   *
   * @param params
   *          [Map<String,Object>] params
   * @return [Map<String,Object>] res
   * @author wtaco
   * @version 1.0
   */
  public Map<String,Object> validarDatosDeclarante(Map<String,Object>  params);

  /* CUS: 3005-10.02 - Inicio - lrodriguezc */
	
	/** M�todo que valida si la �ltima diligencia seleccionada ha concluido (Estado 02 o 03)
	 * @author lrodriguezc
	 * @param numCorrelativo
	 * @return
	 */
	public boolean validarDiligReconFisicoParaReasignar(String numCorrelativo);
	
	/* CUS: 3005-10.02 - Final - lrodriguezc */
	
	/* P14 - 3005 - Final - lrodriguezc */

}
