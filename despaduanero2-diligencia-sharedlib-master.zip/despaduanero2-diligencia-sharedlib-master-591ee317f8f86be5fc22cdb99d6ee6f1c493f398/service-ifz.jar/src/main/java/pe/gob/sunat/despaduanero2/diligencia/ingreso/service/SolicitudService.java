package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Interface SolicitudService.
 *
 * @author rmontes
 */
public interface SolicitudService
{

  /**
   * Obtener doc autoriza serie.
   *
   * @param pkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerDocAutorizaSerie(Map<String, String> pkDocu) throws ServiceException;

  /**
   * Obtener doc autoriza.
   *
   * @param pkDocu
   *          the pk docu
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerDocAutoriza(Map<String, String> pkDocu) throws ServiceException;



  /**
   * Update estado cab sol recti.
   *
   * @param params
   *          the params
   */
  public void updateEstadoCabSolRecti(Map<String, Object> params);

  /**
   * Regularizacion dentro del plazo.
   *
   * @param params
   *          the params
   * @return true, if successful
   */
  public boolean regularizacionDentroDelPlazo(Map<String, Object> params);

  /**
   * Metodo que sirve para validar si la declaraci?n tiene alguna
   * solicitud del especialista para cambio de canal(01) o solicitud de
   * ampliaci?n de plazo.
   *
   * @param params
   *          the params
   * @return Map<String, Object>
   * @throws ServiceException
   *           the service exception
   * @author lsuclupe
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 ? ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public Map<String, Object> validarDeclaConSolicitudXEspecialista(Map<String, Object> params) throws ServiceException;

  /**
   * Metodo que sirve para registrar la respuesta de la solicitud
   * del especilista, para el cambio de canal.
   *
   * @param params
   *          the params
   * @return Map<String, Object>
   * @throws ServiceException
   *           the service exception
   * @author lsuclupe
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 ? ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public Map<String, Object> registrarRespuestaSolEspecialista(Map<String, Object> params) throws ServiceException;

  /**
   * Metodo que sirve obtener la descripci?n del empleado.
   *
   * @param filtro
   *          the filtro
   * @return Map<String, Object>
   * @author lsuclupe
   * @see F2IngresoDiligencia20091124.doc CUR 11.07 ? ATENDER SOLICITUD DEL
   *      ESPECIALISTA
   */
  public Map<String, CatEmpleado> buscarMapCatEmpleado(FiltroCatEmpleado filtro);

  /**
   * Metodo que devuelve una lista de solicitudes de rectificacion y
   * regularizacion pendiente.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @return List
   * @throws ServiceException
   *           the service exception
   * @author gbecerra
   */
  public List<Map<String, Object>> buscarRectiyReguPend(Long numCorreDoc) throws ServiceException;

  /**
   * Gets the reasignaciones.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @return the reasignaciones
   */
  public List<Map<String, Object>> getReasignaciones(Long numCorreDoc);

  /**
   * Gets the regu asignaciones.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @param tipoAsig
   *          the tipo asig
   * @return the regu asignaciones
   */
  public List<Map<String, Object>> getReguAsignaciones(Long numCorreDoc, String tipoAsig);

  /**
   * Gets the duay regu asignaciones.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @return the duay regu asignaciones
   */
  public List<Map<String, Object>> getDuayReguAsignaciones(Long numCorreDoc);


  /**
   * Reasignacion de documentos
   *
   * @param params
   *          datos
   */
  public void reasignarDocumentos(Map<String, Object> params)
      throws ServiceException;


  /**
   * Evalua si la DUA, tiene solicitud regularizacion pendiente evaluar.
   *
   * @param numCorreDocDua
   *          numero correlativo de la DUA
   * @param codRegimenDUA
   *          codigo regimen d ela DUA
   * @return True Si existen solicitudes pendientes de evaluar False Si NO
   *         existen solicitudes pendientes de evaluar
   */
  public Boolean tieneSolicitudRegularizacionPendienteEvaluar(String numCorreDocDua, String codRegimenDUA);

	/**
	 * M�todo que devuelve los datos de un empreado por su c�digo
	 * 
	 * @author olunar
	 * @param codFuncionario
	 * @return CatEmpleado
	 */
	public CatEmpleado getFuncionarioByCodPers(String codFuncionario);

	/**
	 * M�todo que graba la aceptaci�n de la Solicitud de Reconocimiento F�sico 
	 * 
	 * @author olunar
	 * @param consulta
	 * @throws ServiceException
	 */
	public void grabarAceptacionSolicitudReconFisico(DUA dua, Consulta consulta) throws ServiceException;
	
	/**
	 * M�todo que graba el rechazo de la Solicitud de Reconocimiento F�sico
	 * 
	 * @author olunar
	 * @param consulta
	 * @throws ServiceException
	 */
	public void grabarRechazoSolicitudReconFisico(DUA dua, Consulta consulta) throws ServiceException;

  /** 
   * Rechazar la Solicitud 
   * @param solRec
   */
  public void rechazarSolicitud(Map<String, Object> solRec);

  /**
   * RIN16
   */
  public List<Map<String, Object>> obtenerSolicitudRegularizacionUrgente(String numCorreDoc);
//P24
 public Map<String, Object> obtenerDocDUAOtros(Map<String, Object> pkDocu) throws ServiceException; //gmontoya P24
 
}