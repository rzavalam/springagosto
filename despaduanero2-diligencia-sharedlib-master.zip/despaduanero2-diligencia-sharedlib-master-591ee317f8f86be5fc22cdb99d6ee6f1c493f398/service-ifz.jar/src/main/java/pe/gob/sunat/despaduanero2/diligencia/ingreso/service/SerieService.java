package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

@SuppressWarnings({ "rawtypes" })
public interface SerieService
{
  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public List<Map<String, Object>> obtenerListadoSeries(Map<String, String> params)
      throws ServiceException;

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> obtenerDetalleSerie(Map<String, String> params)
      throws ServiceException;

  /**
   *
   * @param params
   * @param detDeclaraViewList
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> editarSerieSession(Map<String, String> params, List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException;

  public List<Map<String, Object>> grabarSerieSession(
    Map<String, Object> requestParameterMap,
    List<Map<String, Object>> detDeclaraParamList)
      throws ServiceException, Exception;

  /**
   *
   * @param params
   * @throws ServiceException
   */
  public void cargarSubElementosSerie(Map params)
      throws ServiceException;

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   * @throws Exception
   */
  public List<Map<String, Object>> grabarSerie(Map<String, Object> params)
      throws ServiceException, Exception;

  /**INICIO-PAS20155E220000166**/
  /**
   * Usado en el inicio de la regu, lo que hace el boton grabar en la serie.
   * @param 
   * @return 
   */
  public List<Map<String, Object>> grabarSerieReguInicio(Map<String, Object> params)
      throws ServiceException, Exception;
  /**FIN-PAS20155E220000166**/
  
  public List<Map<String, Object>> obtenerListSeriesSession(
    Map<String, Object> params,
    List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException;

  /**
   * Permite obtener el mapa detDeclaraMap de la lista detDeclaraViewList
   * adicionalmente al mapa detDeclaraMap se le setea CONVENIO_SERIE y el tipo
   * de operacion que se realiza a la serie selecionada.
   *
   * @param params (Map<String, Object>) NUM_SECSERIE (String) NUM_OPERACION (String)
   * @param detDeclaraViewList (List<Map<String, Object>>)
   * @return detDeclaraMap (Map<String, Object>)
   * @throws ServiceException
   */
  public Map<String, Object> obtenerSerieSession(
    Map<String, Object> params,
    List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException;

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> actualizaEstadoSerieSession(Map<String, Object> params)
      throws ServiceException;

  /**
   * Obtener secuencia para insercion de una nueva serie
   *
   * @param numCorreDocDua
   * @return int
   */
  public int getSgteNumSecSerie(String numCorreDua);

  /**
   * Obtener secuencia para insercion de una nueva serie
   *
   * @param numCorreDocDua
   *          the num corre doc dua
   * @param lstSeriesActuales
   *          the lst series actuales
   * @return int
   */
  public int getSgteNumSecSerie(String numCorreDocDua, List<Map<String, Object>> lstSeriesActuales);

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public List obtenerRegPrecedencia(Map params)
      throws ServiceException;

  /**
   * Obtiene los datos de Det Atuorizacion de una DUA.
   *
   * @param pkDoc
   *          Map que contiene num_corredoc
   * @return List
   * @throws ServiceException
   */
  public List<Map<String, Object>> obtenerDetAutorizacion(Map<String, String> pkDoc)
      throws ServiceException;

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public List<Map<String, Object>> obtenerSeriesItem(Map<String, Object> params)
      throws ServiceException;

  /**
   *
   * @param lstSeriesItemSession
   * @param param
   * @return
   * @throws Exception
   */
  public List<Map<String, Object>> obtenerLstSeriesItem(
      List<Map<String, Object>> lstSeriesItemSession,
      Map<String, Object> param)
        throws Exception;

  /**
   *
   * @param params
   * @return
   * @throws ServiceException
   */
  public List<Map<String, Object>> select(Map<String, Object> params)
      throws ServiceException;

  /**
   *
   * @param pkDocu
   * @return
   */
  public List<Map<String, Object>> obtenerConvenioSerieMap(Map pkDocu);

  /**
   *
   * @param params
   * @return
   */
  public List<Map<String, Object>> findByNumCorreDoc(Map<String, Object> params);
/**INICIO-RIN13**/
  /**
   * Retorna el listado de n�meros de documentos de transporte de una declaraci�n
   * 
   * @param numeroCorrelativo
   * @return Lista de n�meros de documentos de transporte de una declaraci�n
   * @author gbecerrav
   */
  public List<Map<String, Object>> obtenerListaNumeroDocTransporteByDeclaracion(Long numeroCorrelativo) throws ServiceException;

/*RIN13INSI*/
  //public List<Map<String, Object>> obtenerListaNumeroDocTransporteByDeclaracion(String numCorredoc)  throws ServiceException;  
/**FIN-RIN13**/

  public List<Map<String, Object>> selectDetalleDuaPrece(Map<String, String> params)
		throws ServiceException;
  
  /**
   * Retorna la cantidad de series de una declaraci�n
   * 
   * @param params par�metros de b�squeda
   * @return cantidad de series de una declaraci�n
   * @author gbecerrav
   */
  public int obtenerCantidadSeries(Map<String, Object> params)  throws ServiceException;

  //hosoriov rin 12 inicio

  public List<Map<String, Object>> findNumPartidaSeries(Map<String, ?> params);
  public List<Map<String, Object>> obtenerListaNumeroDocTransporteByDeclaracionYNumDetalle(Long numeroCorrelativo) throws ServiceException;

//hosoriov rin 12 fin
  /*inicio gdlr*/
  public List<Map<String, Object>> obtenerSeriesItemByDocumento(Map<String, Object> parametros) throws ServiceException;
  /*fin gdlr*/
  
//Inicio RIN10 mpoblete BUG 22178 
  public boolean serieTieneValorProvisional(Map<String,Object> serie);
  //Fin RIN10 mpoblete BUG 22178
  /*INICIO-P34 FSW AFMA*/
  public boolean declaracionTieneFormatoB(String numCorredocDeclaracion);
  /*FIN-P34 FSW AFMA*/
  
  //PAS20171U220200016: select de tabla general
  public List<Map<String, Object>> obtenerAllDetAutorizacion(Map<String, String> pkDoc) throws ServiceException;
}
