package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.Nandina;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class ItemFacturaRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long    serialVersionUID        = -1947279683589058464L;

  private static final String  NOMBRE_LISTA_ORIGINAL   = "lstItemFactura";

  private static final String  NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private ItemFacturaDAO       itemFacturaDAO;

  //rtineo mejoras, grabacion en batch
  private ItemFacturaBatchDAO itemFacturaBatchDAO;

  private CatalogoAyudaService catalogoAyudaService;

  public ItemFacturaRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECITEM", "NUM_SECITEM");
    // mapClave.put("NUM_SECPROVE", "NUM_SECPROVE");
    // mapClave.put("NUM_SECFACT", "NUM_SECFACT");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_ITEM_FACTURA;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    List<Map<String, Object>> result = itemFacturaDAO.select(mapParametros);
    return result;
  }

  @Override
  public List<Map<String, Object>> getTableRectificadoMergedBD(
      Map<String, Object> parametrosBd,
      Long numeroCorrelativoSolicitud,
      boolean mergeRectificados)
  {
    List<Map<String, Object>> resultLstItemFactura = super.getTableRectificadoMergedBD(parametrosBd,
        numeroCorrelativoSolicitud, mergeRectificados);
	ObservacionDAO observacion = fabricaDeServicios.getService("observacionDAO");
	//rtineo optimizacion, se utilizara una unica consulta para obtener las partidas
    Iterator<Map<String, Object>> itLstItemFacturaGetPartida = resultLstItemFactura.iterator();
    StringBuilder stringBuilder = new StringBuilder();
    StringBuilder stringBuilderObservacion = new StringBuilder();
    List<String> listPartida = new ArrayList<String>();
    List<String> listSecItem = new ArrayList<String>();
    String num_corredoc="";
    String num_secitem;
    while (itLstItemFacturaGetPartida.hasNext()){
    	//recorremos para obtener las partidas
    	Map<String, Object> itemFacturaGetPartida = itLstItemFacturaGetPartida.next();
    	if(itemFacturaGetPartida.get("NUM_PARARANCEL") != null){
    		String numPararancel = itemFacturaGetPartida.get("NUM_PARARANCEL").toString();
    		if(!listPartida.contains(numPararancel)){
    			stringBuilder.append(numPararancel).append(",");
    			listPartida.add(numPararancel);
    		}
    	}
    	//recorremos tambien para obtener las observacioes
    	num_corredoc = itemFacturaGetPartida.get("NUM_CORREDOC").toString();
    	// se comenta esta seccion
        /*if(itemFacturaGetPartida.get("NUM_SECITEM") != null){
    		num_secitem = itemFacturaGetPartida.get("NUM_SECITEM").toString();
        	if(!listSecItem.contains(num_secitem)){
        		listSecItem.add(num_secitem);
        		stringBuilderObservacion.append(num_secitem).append(",");
        	}
    	}*/
    }
    //consultamos a la BD por unica vez por rest
    List<Nandina> listNandinaRest = new ArrayList<Nandina>();
    if(stringBuilder.length()>0){
    	stringBuilder.deleteCharAt(stringBuilder.length() - 1);
    	List<String> listPartidasBuilder = GeneralUtils.obtenerListCadenas(stringBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
    	for(String cadenaPartidas : listPartidasBuilder){
    		List<Nandina> listNandinaTmp = catalogoAyudaService.getPartidasObject(cadenaPartidas);
    		if(listNandinaTmp != null) listNandinaRest.addAll(listNandinaTmp);
    	}
    	
    }
    //ordenamos por partidas en un Hashmap
    HashMap<String,Object> listNandinas = new HashMap<String,Object>();
    for(Nandina nandinaTmp : listNandinaRest){
    	listNandinas.put(nandinaTmp.getPartida().toString(), nandinaTmp);
    }
    //consultamos una unica vez a observaciones   
    List<Observacion> listObservaciones = new ArrayList<Observacion>();
    //rtineo mejoras 
    		Map<String, Object> mapBusqueda = new HashMap<String, Object>();
	//		mapBusqueda.put("LIST_ITEMS",cadenaObservacion);
			mapBusqueda.put("numcorredoc",num_corredoc);
			mapBusqueda.put("codtipobs","03");//catalogo 369
    		listObservaciones.addAll(observacion.findObservcionByMap(mapBusqueda));

    //agrupamos por secitem
    Map<Integer, List<Observacion>> observacionMap = new HashMap<Integer, List<Observacion>>();
	for (Observacion obsTmp : listObservaciones) {
		List<Observacion> listObservacion = observacionMap.get(obsTmp.getNumsecitem());
		if (listObservacion == null) {
			listObservacion = new ArrayList<Observacion>();
			observacionMap.put(obsTmp.getNumsecitem(), listObservacion);
		}
		listObservacion.add(obsTmp);
	}
	//fin optimizacion
    
    Iterator<Map<String, Object>> itLstItemFactura = resultLstItemFactura.iterator();
    while (itLstItemFactura.hasNext())
    {
      Map<String, Object> itemFactura = itLstItemFactura.next();

      if (itemFactura.get("NUM_PARARANCEL") != null)
      {  
    	  
    	  try {
    		  //rtineo optimizacion, se evitara multiples consultas a la base de datos
        	  //CatalogoAyudaService catalogoAyudaServiceSinRest = fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
              //Nandina nandina = catalogoAyudaServiceSinRest.getPartidaObject(itemFactura.get("NUM_PARARANCEL").toString());
    		  Nandina nandina = (Nandina)listNandinas.get(itemFactura.get("NUM_PARARANCEL").toString());
    		  //rtineo fin optimizacion
    		  
              if (nandina != null)
                itemFactura.put("DESCRIPCION_PARTIDA", nandina.getDescripcion());
			
		   } catch (Exception e) {
			// TODO: handle exception
			
		    itemFactura.put("DESCRIPCION_PARTIDA", "");
      	 	e.printStackTrace();
		   }

      }
    //Inicio cambios 12/06/2014 listado de observaciones AREY PASE 168
		 StringBuffer lstObs = new StringBuffer();
		 /*Map<String, Object> mapBusqueda = new HashMap<String, Object>();
		 mapBusqueda.put("numcorredoc",itemFactura.get("NUM_CORREDOC"));
		 mapBusqueda.put("numsecitem",itemFactura.get("NUM_SECITEM"));
		 mapBusqueda.put("codtipobs","03");//catalogo 369*/
		 
		 //rtineo optimizacion, se evita consultar a la base de datos
		 //List<Observacion> obs = observacion.findObservcionByMap(mapBusqueda);
		 List<Observacion> obs = observacionMap.get(itemFactura.get("NUM_SECITEM"));
		 //fin optimizacion
		 if(obs!=null && obs.size()>0){
			 for(int j=0; j<obs.size(); j++){
				 lstObs.append(" ");
				 lstObs.append(obs.get(j).getObsdeclaracion().toString());
			 } 
		 }			 
		 itemFactura.put("OBSERVACION",lstObs.toString());
		 //Fin cambios 12/06/2014
      
    }
    return resultLstItemFactura;
  }

  public DatoItem mapToObject(Map<String, Object> itemfactura)
  {
    DatoItem datoItem = new DatoItem();

    datoItem.setNumcorredoc(new Long(ObjectUtils.toString(itemfactura.get("NUM_CORREDOC"), "0")));
    datoItem.setNumsecprove(new Integer(ObjectUtils.toString(itemfactura.get("NUM_SECPROVE"), "0")));
    datoItem.setNumsecfact(new Integer(ObjectUtils.toString(itemfactura.get("NUM_SECFACT"), "0")));
    datoItem.setNumsecitem(new Integer(ObjectUtils.toString(itemfactura.get("NUM_SECITEM"), "0")));

    datoItem.setNumpartnandi(new Long(ObjectUtils.toString(itemfactura.get("NUM_PARARANCEL"), "0")));

    datoItem.setMtofobunita(new BigDecimal(ObjectUtils.toString(itemfactura.get("MTO_FOBUNITARIO"), "0")));
    datoItem.setMtoajusunita(new BigDecimal(ObjectUtils.toString(itemfactura.get("MTO_AJUUNITARIO"), "0")));
    datoItem.setMtofobitem(new BigDecimal(ObjectUtils.toString(itemfactura.get("MTO_FOBITEM"), "0")));
    datoItem.setCntcantcomer(new BigDecimal(ObjectUtils.toString(itemfactura.get("CNT_UNI"), "0")));

    datoItem.setCodpaisorige(ObjectUtils.toString(itemfactura.get("COD_PAISORIGEN"), " "));
    datoItem.setCodunidcomer(ObjectUtils.toString(itemfactura.get("COD_UNICOMER"), " "));
    datoItem.setCodpaisadqui(ObjectUtils.toString(itemfactura.get("COD_PAISADQUI"), " "));
    datoItem.setDescomercial(ObjectUtils.toString(itemfactura.get("DES_COMER"), " "));
    datoItem.setDesmarca(ObjectUtils.toString(itemfactura.get("DES_MARCA"), " "));
    datoItem.setDesmodelo(ObjectUtils.toString(itemfactura.get("DES_MODELO"), " "));
    datoItem.setAnnfabrica(ObjectUtils.toString(itemfactura.get("ANN_FABRICACION"), " "));
    datoItem.setCodestamer(ObjectUtils.toString(itemfactura.get("COD_ESTMERC"), " "));
    datoItem.setIndsoftware(ObjectUtils.toString(itemfactura.get("IND_SOFTWARE"), " "));
    datoItem.setIndvarios(ObjectUtils.toString(itemfactura.get("IND_OTROS"), " "));

    datoItem.setInddeducdisti(ObjectUtils.toString(itemfactura.get("IND_DEDUC"), " "));
    datoItem.setCodproducto(ObjectUtils.toString(itemfactura.get("COD_PROD"), " "));
    datoItem.setDescaracteristicas(ObjectUtils.toString(itemfactura.get("DES_CARACTERISTICAS"), " "));
    datoItem.setDesclasevari(ObjectUtils.toString(itemfactura.get("DES_CLASEVARI"), " "));
    datoItem.setDesusoaplica(ObjectUtils.toString(itemfactura.get("DES_USOAPLIC"), " "));
    datoItem.setDesmaterialcomp(ObjectUtils.toString(itemfactura.get("DES_MATERIALCOMP"), " "));
    datoItem.setCodtipograbado(ObjectUtils.toString(itemfactura.get("COD_TIPGRABADO"), " "));

    return datoItem;
  }

  public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO)
  {
    this.itemFacturaDAO = itemFacturaDAO;
  }
  //rtineo mejoras, grabacion en batch
  public ItemFacturaBatchDAO getItemFacturaBatchDAO() {
	return itemFacturaBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setItemFacturaBatchDAO(ItemFacturaBatchDAO itemFacturaBatchDAO) {
	this.itemFacturaBatchDAO = itemFacturaBatchDAO;
  }

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#insertRecord(java.util.Map)
   */
  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    newRecordMap.put("COD_TIPGRABADO", "P");
    itemFacturaDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  /*
   * (non-Javadoc)
   * 
   * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.
   * RectificacionAbstract#updateRecord(java.util.Map)
   */
  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapItemFactura

  }

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap)
  {
    newRecordMap.put("COD_TIPGRABADO", "P");
    itemFacturaBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  //rtineo mejoras, grabacion en batch
  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap)
  {
    itemFacturaBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap)); // mapItemFactura

  }
}
