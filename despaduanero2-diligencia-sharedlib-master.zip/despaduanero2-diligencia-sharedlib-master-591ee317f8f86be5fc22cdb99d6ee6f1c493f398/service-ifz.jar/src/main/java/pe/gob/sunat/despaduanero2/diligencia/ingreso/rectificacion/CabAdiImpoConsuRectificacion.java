package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;


public class CabAdiImpoConsuRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID        = -1992695992175202673L;

  private static final String NOMBRE_LISTA_ORIGINAL   = "lstCabAdiImpoConsu";

  private static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL + "Actual";

  private CabAdiImpoConsuDAO  cabAdiImpoConsuDAO;

  //rtineo mejoras, grabacion en batch
  private CabAdiImpoConsuBatchDAO cabAdiImpoConsuBatchDAO;

  public CabAdiImpoConsuRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");

  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return cabAdiImpoConsuDAO.select(mapParametros);
  }

  public void setCabAdiImpoConsuDAO(CabAdiImpoConsuDAO cabAdiImpoConsuDAO)
  {
    this.cabAdiImpoConsuDAO = cabAdiImpoConsuDAO;
  }

  //rtineo mejoras, grabacion en batch
  public CabAdiImpoConsuBatchDAO getCabAdiImpoConsuBatchDAO() {
	return cabAdiImpoConsuBatchDAO;
  }
  //rtineo mejoras, grabacion en batch
  public void setCabAdiImpoConsuBatchDAO(CabAdiImpoConsuBatchDAO cabAdiImpoConsuBatchDAO) {
	this.cabAdiImpoConsuBatchDAO = cabAdiImpoConsuBatchDAO;
  }
  
  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    Map<String, Object> mapDiferenciaGrabar;
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      Map<String, Object> mapPK = new HashMap<String, Object>();
      Comparador comparador = new Comparador();
      mapPK.put("NUM_CORREDOC", "NUM_CORREDOC");
      for (Map<String, Object> mapCabAdiImpoConsu : (ArrayList<Map<String, Object>>) mapDatos
          .get(getNombreListaResultante()))
      {
        if (log.isDebugEnabled())
        {
          //cont++;
          //log.debug(cont + " CabAdiImpoConsu :" + mapCabAdiImpoConsu);
        	log.debug(" CabAdiImpoConsu :" + mapCabAdiImpoConsu);
        }
       
        //PAS20171U220200005 Inicio adecuaciones para que registre en caso de registro nuevo:
        if(INDICADOR_NUEVO_REGISTRO.equals(mapCabAdiImpoConsu.get("indica")))
        { 
        	//corregido es mapCabAdiImpoConsu no mapDatos!
        	/**Inicio PAS20171U220200005 si es registro nuevo acogimiento al impconsumo, se valida para indicarle el nro de envio parcial **/
			Long num_corredocActual = new Long(mapCabAdiImpoConsu.get("NUM_CORREDOC").toString());
        	Map<String, Object> params = new HashMap<String, Object>();
			IndicadorDUADAO indicadorDAO = fabricaDeServicios.getService("indicadorDUADAO");
			params.put("numcorredoc",num_corredocActual);
			params.put("codtiporegistro", "T");
			params.put("indactivo", Constants.INDICADOR_ACTIVO);
			params.put("listaTipoIndica", new String[]{ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO,ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES});
			List<DatoIndicadores> indicadorRegistrado = null;
			
			indicadorRegistrado = indicadorDAO.findIndicadoresByMap(params);  
			
			//de repente es una vigente y no primigenia :P
			SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
			Map pkDocu = new HashMap();
			pkDocu.put("NUM_CORREDOC",num_corredocActual);
			pkDocu.put("COD_CONVENIO","  21");
			pkDocu.put("COD_TIPCONVENIO","T");
			List lista = serieService.obtenerConvenioSerieMap(pkDocu);
			boolean tieneTPN21 = false;
			Integer enviosRegistrados = 0;
			
			if(!CollectionUtils.isEmpty(lista)){
				tieneTPN21 = true;
				ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService");
		        Long numcorredocPrimigenia = valMercanciaVigenteService.obtenerNumcorredocPrimigeniaPorVigente(num_corredocActual, new Integer(0));
		    	enviosRegistrados = valMercanciaVigenteService.obtenerEnviosRegistrados(numcorredocPrimigenia);
		    	enviosRegistrados++;
			}
			
			if(indicadorRegistrado!=null && !CollectionUtils.isEmpty(indicadorRegistrado)){
				if(mapDatos.get("NUM_ENVIOPARCIAL")==null && mapDatos.get("NUM_TOTALENVIOS")!=null && !mapDatos.get("NUM_TOTALENVIOS").equals("0")){
					if(tieneTPN21){
						mapCabAdiImpoConsu.put("NUM_ENVIOPARCIAL",enviosRegistrados.toString());//es vigente
					}else{
						mapCabAdiImpoConsu.put("NUM_ENVIOPARCIAL", "1");//es primigenia
					}
        		}
			}  
			/**Fin PAS20171U220200005**/
        	
        	
        	
        	try{
        		if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        			cabAdiImpoConsuDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(mapCabAdiImpoConsu));// mapCabAdiImpoConsu
        		 }else{
                	 cabAdiImpoConsuDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(mapCabAdiImpoConsu));// mapCabAdiImpoConsu
                 }
        		
        		cont++;
        		
        	}catch (DataIntegrityViolationException e ) {
        		 if (log.isWarnEnabled())
                 {
                   log.warn("El cabadiImpoConsu ya existe se procede a actualizarlo");
                 }
        		 if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        			 cabAdiImpoConsuBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapCabAdiImpoConsu));
                 }else{
                	 cabAdiImpoConsuDAO.update(Utilidades.transformFieldsToRealFormat(mapCabAdiImpoConsu));
                 }
			}
        	
        	// grabamos en ofirecti
            Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(mapCabAdiImpoConsu, getMapClave());
            mapCabAdiImpoConsu.put("dataOriginal", new HashMap<String, Object>(mapCabAdiImpoConsu));
            mapCabAdiImpoConsu.put("clave", mapTmpPK);
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	 registrarRectiOficioBatch(mapCabAdiImpoConsu, numCorredocSol, true);
            }else{
            	registrarRectiOficio(mapCabAdiImpoConsu, numCorredocSol, true);
            }
            continue;
        }
        else
        {//este bloque se coloc� aqui para cuando haya registro anterior y pueda comparar
        	for (Map<String, Object> mapCabAdiImpoConsuAntes : (ArrayList<Map<String, Object>>) mapDatos
        	       .get(getNombreListaOriginal()))
        	{
        		if (mapCabAdiImpoConsuAntes.get("NUM_CORREDOC").toString().trim()
        	         .equals(mapCabAdiImpoConsu.get("NUM_CORREDOC").toString().trim()))
        	    {
        			mapDiferenciaGrabar = comparador.comparaMap(mapCabAdiImpoConsuAntes, mapCabAdiImpoConsu, mapPK);
        	        if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
        	               && Comparador.esDataCambiada(mapDiferenciaGrabar))
        	        {
        	        	log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
        	            //rtineo mejoras, grabacion para rectificacion desde web
        	            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	            	cabAdiImpoConsuBatchDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));// mapCabAdiImpoConsu
        	            	registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);            	  
        	             }else{
        	            	 cabAdiImpoConsuDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferenciaGrabar));// mapCabAdiImpoConsu
        		             registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
        	             }
        	             //rtineo mejoras, grabacion en batch
        	             cont++;
        	         }
        	         break;
        	    }//fin if
        		
        	 }//fin for 
        }//fin else
        //PAS20171U220200005 Fin adecuaciones para que registre en caso de registro nuevo:
        
      }//fin for mapDatos
    }//fin if
    return cont;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    //

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    //

  }

  //rtineo mejoras
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap){
  }

  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap){
  }
  //rtineo fin

}
