package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

import java.io.Serializable;

public class Constantes implements Serializable
{

  private static final long    serialVersionUID                 = 6564300562374128487L;
  
  public static final String COD_ADUANA_CENTRAL = "000";

  public static final String   NUM_PASE                         = "PAS20134E610000309";

  public static final String   SOLI_CAMBIO_CANAL                = "01";                

  public static final String   SOLI_AMPLI_PLAZO                 = "04";                

  public static final String   CAT_MOTIVO_AMPLIACION            = "357";

  public static final String   CAT_TIPO_DILIGENCIA              = "356";
  //gg lga
  public static final String   CAT_TIPO_MODALIDAD = "306";  
  public static final String   CATALOGO_CODIGICACION_TABLA_NSIGAD = "371";

  // constantes usadas en la copia de series
  public static final String   TIENE_FORMATO_B                  = "0";

  public static final String   NO_TIENE_FORMATO_B               = "1";

  /**********************************************************************
   * REGIMENES DE LA DECLARACION
   **********************************************************************/
  public static final String   REGIMEN_10_IMPORTACION_CONSUMO   = "10";

  public static final String   REGIMEN_20_ADM_TMP_MISMO_ESTADO  = "20";

  public static final String   REGIMEN_21_ADM_TMP_PERFEC_ACTIVO = "21";

  public static final String   REGIMEN_70_DEPOSITO              = "70";

  public static final String   REGIMEN_80_TRANSITO              = "80";

  //public static final String   COD_DOCUMENTO_ADUANERO           = "DUA";
    public static final String   COD_DOCUMENTO_ADUANERO           = "DECLARACION"; //PAS20165E220200099
  
  /**********************************************************************
   * ESTADOS DE LA DECLARACION
   **********************************************************************/
  public static final String   ESTADO_DECLARACION_NUMERADO              = "01";

  public static final String   ESTADO_DILIG_ASIGNADA                    = "02";

  public static final String   ESTADO_DECLARACION_REVISION              = "03";

  public static final String   ESTADO_DILIG_PROCESO                     = "04";

  public static final String   ESTADO_DECLARACION_DILIGENCIA_CONFORME   = "05";
  
  public static final String   ESTADO_EN_CONCLUSION_DESPACHO            = "09";

  public static final String   ESTADO_CONCLU_ASIGNADA                   = "10";
		/* P14 - 3014 - Inicio - lrodriguezc */
  
	public static final String   ESTADO_LEVANTE_AUTORIZADO                = "06";
	
	/* P14 - 3014 - Final - lrodriguezc */
  public static final String   ESTADO_CONCLU_REVISION                   = "11";

  public static final String   ESTADO_CONCLU_PROCESO                    = "12";

  public static final String   ESTADO_DECLARACION_DESPACHO_CONCLUIDO    = "13";

  public static final String   ESTADO_NOTIFICADO                        = "15";
  
  public static final String   ESTADO_CONCLU_NOTIFICADO                 = "16";

  public static final String   ESTADO_DECLARACION_RECEPCIONADO          = "17";
 // P34 inicio EJHM 
 public final static  String  ESTADO_DECLARACION_ASIG_CONCLUS_DESPACHO = "10";
 public static final String   ESTADO_REVISION_ASIGNADO_RECTIFICACION_OFICIO = "13";	
// P34 fin EJHM
  
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	public static final String ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE      = "18";
	
	public static final String ESTADO_MERCANCIA_DISPUESTA_PARCIALMENTE    = "19";
	
	/* P14 - 3006 - Final - lrodriguezc */
	
	/* P14 - 3014 - Inicio - dhernandezv */
	
	public static final String ESTADO_LEGAJADO                            = "08";
	
	/* P14 - 3014 - Fin - dhernandezv */
	
  /**********************************************************************
   * Solicitud Electr�nica de Reconocimiento F�sico (SERF).
   **********************************************************************/
  public static final String   ESTADO_SERF          = " - SERF";
    
  /**********************************************************************
  
   * ESTADOS DE LA RECTIFICACION
   **********************************************************************/
  public static final String   ESTADO_RECTI_ASIGNADO                    = "03";

  public static final String   ESTADO_RECTI_PROCESO                     = "04";

  public static final String   ESTADO_RECTI_CAB_SOL_PENDIENTE           = "02";

  /**********************************************************************
   * ESTADOS DE LA SOLICITUD
   **********************************************************************/
  public static final String   ESTADO_SOLICITUD_RECTI_PENDIENTE = "02";
  
  /**********************************************************************
   * ESTADOS DE LA ASIGNACION DEL ESPECIALISTA A LA DECLARACION 494
   **********************************************************************/
  public static final String   ESTADO_CON_REGISTRO_DILIGENCIA 			= "01";
  public static final String   ESTADO_ASIGNADO 							= "06";
  public static final String   ESTADO_ELIMINADO_POR_REASIGNACION 		= "08";
  public static final String   ESTADO_ASIGNADO_PARA_CONCLUSION_DESPACHO = "10";
  
  
  /**********************************************************************
   * CATALOGOS
   **********************************************************************/
  public static final String   CAT_ESTADO_DUA                   = "335";

  public static final String   CAT_UND_TMP                      = "312";

  public static final String   CAT_ESTADOS_ASIGNACION           = "355";

  public static final String   CAT_MOTIVO_DUA_NARANJA           = "339";
  
  public static final String   CAT_ESTADO_SOLICITUD_RECTIFICACION           = "363";
  
  /* P14 - 3005 - Inicio - lrodriguezc */
  
  /* CUS: 3005-10.02 - Inicio - lrodriguezc */
	
	public static final String   CAT_ESTADOS_RECO_FISICO = "355";
	
	/* CUS: 3005-10.02 - Final - lrodriguezc */
	
	/* P14 - 3005 - Final - lrodriguezc */
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	public static final String CATALOGO_MOTIVOS_NOTIFICACION = "905";
	
	/* P14 - 3006 - Final - lrodriguezc */
  
  public static final String   CAT_NIVEL_COMERCIAL          = "85";
  public static final String   CAT_CONDICION_PROVEEDOR           = "86";
  public static final String   CAT_NATURALEZA_TRANSACCION           = "81";
  //public static final String   CAT_INCOTERMS           = "82";
  public static final String   CAT_FORMA_ENVIO_MERCANCIA           = "84";
  public static final String   CAT_TIPO_INTERMEDIARIO           = "87";
  public static final String   CAT_TIPO_DOCUMENTO          = "27";
  public static final String   CAT_COD_TIPO_MONEDA           = "J1";
  public static final String   CAT_COD_PAIS           = "J2";

  /**********************************************************************
   * INDICADORES
   **********************************************************************/
  public static final String   IND_DUA_T_AUT                    = "T";

  public static final String   IND_DUA_P_AUT                    = "A";

  public static final String   IND_DUA_P_ESP                    = "P";

  /**********************************************************************
   * CANALES DE LA DECLARACION
   **********************************************************************/
  public static final String   CANAL_VERDE                      = "V";

  public static final String   CANAL_NARANJA                    = "D";

  public static final String   CANAL_ROJO                       = "F";
  
  // Constantes de DeclaracionServiceImpl
  public static final String   GRUPO_CONCLUCION_DESPACHO        = "GEC";

  /****Inicio EGH_PASEINGRESOSDA2***************/
  public static final String   GRUPO_REGULARIZACION             = "GRE";
  public static final String   GRUPO_DESTINO             		= "GAD";
  
  public static final String   GRUPO_DILIGENCIA_PREVIA     		= "GDP"; //P24
  
  public static final String   COD_PENDIENTE_EVALUAR            = "02";

  public static final String   COD_EN_EVALUACION                = "04";
  //mordonezl pase 040
  public static final String   COD_ASIG_PENDIENTE_EVALUAR       = "03";

  public static final String   COD_PROCEDENTE                   = "05";

  public static final String   COD_PROCEDENTE_PARTE             = "06";

  public static final String   COD_IMPROCEDENTE                 = "07";

  public static final String   COD_ANULADO                      = "08";

  public static final String   COD_RECHAZADO                    = "09";

  public static final String   DEFAULT_FECHA_BD                 = "01/01/0001";

  public static final String   FORMAT_ddMMyyyy                  = "dd/MM/yyyy";

//INICIO JMCV
//  /**********************************************************************
//   * ESTADO DEL RESULTADO DEL RECONOCIMIENTO FISICO DE MERCANCIAS
//   **********************************************************************/
  	public static final String RECONOCIMIENTO_FISICO_INCONCLUSO		    = "03";
	public static final String DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO = "04";
	public static final String DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO = "05";
	public static final String INMOVILIZACION_TOTAL_DE_LA_MERCANCIA	    = "06";
	public static final String RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL   = "07";
	public static final String RECONOCIMIENTO_FISICO_CON_CONTINUACION   = "08";
	public static final String RECONOCIMIENTO_FISICO_DE_OFICIO   = "09";
	
//FIN JMCV  

	public static final String   FORMAT_DATES_HORA                = "dd/MM/yyyy HH:mm:ss";
	/* P14 - 3006 - mpoblete BUG 19143 - Inicio */
	public static final String FORMAT_DATE_HORA12 ="dd/MM/yyyy hh:mm:ss aa"; 
	/* P14 - 3006 - mpoblete BUG 19143 - Fin */
	
  // Constantes de DeclaracionServiceImpl

  /**********************************************************************
   * TIPO DE DOCUMENTO
   **********************************************************************/
  public static final String   TIPO_DOC_DNI                     = "3";

  public static final String   TIPO_DOC_RUC                     = "4";

  public static final String   TIPO_DOC_PASAPORTE               = "6";

  // Tipo de Despacho
  public static final String   TIPO_DESP_FERIA                  = "2002";
  
  /**********************************************************************
   * CODIGO DE PLANTILLAS - NOTIFICACIONES
   **********************************************************************/
  public static final Integer  COD_PL_NOTI_OBS_REV_DOCUMENTARIA = 120;

  public static final Integer  COD_PL_NOTI_OBS_REC_FISICO       = 122;
  //Conclusion Despacho
  public static final Integer  COD_PL_NOTI_DILIG_CONCLUSION     = 388; //P21-P22
  
/*RIN13FSW-INICIO*/
  public static final Integer  COD_PL_NOTI_OBS_BLOQUEO       = 236;
  public static final Integer  COD_PL_NOTI_OBS_DESBLOQUEO       = 237;
  /*RIN13FSW-FIN*/
  /* olunar 309 */
  public static final Integer  COD_PL_NOTI_REM_REC_FISICO_JEFE  = 133;
  
  public static final Integer  COD_PL_NOTI_ACEPTA_REM_REC_FISICO  = 134;
  
  public static final Integer  COD_PL_NOTI_RECHAZA_REM_REC_FISICO  = 135;
  
  public static final Integer  COD_PL_NOTI_REM_REC_FISICO  = 136;
  
  //ggranados 179
  public static final Integer  COD_PL_NOTI_REC_FISICO_OFICIO  = 383;
  public static final Integer  COD_PL_NOTI_MOV_REC_FISICO_OFICIO  = 384;
  
  
  public static final String   CODIGO_AVISO_ELECTRONICO         = "0";
  /* fin */
/*RIN13FSW-INICIO*/
  public static final Integer  COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO  = 241;
  /* juazor */
  public static final Integer  COD_PL_NOTI_CONTDESPACHO = 122;
  public static final Integer  COD_PL_NOTI_DESCARGAPARCIAL = 122;
  public static final Integer  COD_PL_NOTI_CONTDESPACHO_CONSIGNATARIO = 238;
  public static final String   CODIGO_NOTIFICACION_CONSIGNATARIO  = "2";
  
  //CATALOGO 369 - TIPO DE OBSERVACION
  // amancilla public static final String   TIPO_OBSERVACION_SERIE = "06"; //DILIGENCIA DESPACHO
   // amacnilla el codigo 06 es para la transmisiones se crea otro PAS20155E220200152
    public static final String   TIPO_OBSERVACION_SERIE = "16"; //DILIGENCIA DESPACHO
    public static final String   TIPO_OBSERVACION_SERIE_FORMATOA = "06"; //TICKET INC 2015-027983
    

  //INICIO PAS20155E220000054
  public static final String   TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO = "11";
  public static final String   TIPO_OBSERVACION_SERIE_DILIG_DESCARGA_PARCIAL = "12";
 //FIN PAS20155E220000054
  
  public static final Integer   BLOQUEO_SALIDA_MERCANCIAS =236;
  public static final Integer   DESBLOQUEO_SALIDA_MERCANCIAS =237;
  
  public static final Integer RESULT_DISMINUCION__BULTOS_RESPUESTA_SI = 239;
  public static final Integer RESULT_DISMINUCION__BULTOS_RESPUESTA_NO = 240;
  /* juazor fin */
/*RIN13FSW-FIN*/
  public static final String   CODIGO_NOTIFICACION              = "1";

  public static final String   CONTRIBUYENTE                    = "1";

  /* P14 - 3014 - Inicio - dhernandezv */
  public static final Integer  COD_SEC_NOTI_DECLA			       = 207;
  
  public static final Integer  COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL = 208;  
  
//  <EHR>
  public static final Integer  COD_SEC_NOTI_DECLA_PDF		       = 248;

  public static final String COD_CATALOGO_ERROR = "F09";
  //  </EHR>
  
  //pase 129 - PAS20165E220200099
  public static final String   NOTIFICACION_ELABORADA_IAMC         = "DIVISI&Oacute;N DE IMPORTACI&Oacute;N DE LA IAMC";
  
  public static final String   NOTIFICACION_ELABORADA_TEC_ADUANERA = "DEPARTAMENTO DE T&Eacute;CNICA ADUANERA";
  
  public static final Integer  COD_PL_NOTI_DECLA1			       = 1001591;
  public static final Integer  COD_PL_NOTI_DECLA2			       = 1001592;
  public static final Integer  COD_PL_NOTI_DECLA3			       = 1001593;
  public static final Integer  COD_PL_NOTI_DECLA4			       = 1001594;
  public static final Integer  COD_PL_NOTI_DECLA			       = 100159;
  
  public static final Integer  COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL  = 100160;
  
  /*jreynoso envio de avisos*/
  
  public static final Integer CODIGO_PLANTILLA_NO_DISPONIBILIDAD_ESPECIALISTAS_CONTINUACION_DESPACHO = 263;
  public static final Integer CODIGO_PLANTILLA_NO_DISPONIBILIDAD_ESPECIALISTAS_VERIFICAR_NOTA_TARJA = 364;
  
  
  /* P14 - 3014 - Fin - dhernandezv */
  
	/* P14 - 3005 - Inicio - lrodriguezc */
	
	/* CUS: 3005-10.02 - Inicio - lrodriguezc */
	
	/**********************************************************************
	* ESTADOS DE RECONOCIMIENTO FISICO CAT 355
	**********************************************************************/
	
	public static final String   RECON_FISI_CONT_DESPACHO = "08";
	
	/* CUS: 3005-10.02 - Final - lrodriguezc */
	
	/* P14 - 3005 - Final - lrodriguezc */
  

  /**********************************************************************
   * TIPO DE INTERVENCIONES DILIGENCIA CAT 356
   **********************************************************************/
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	/* CUS: 3005-10.02 - Inicio - lrodriguezc */
	
	public static final String   DILIG_REVISION = "01";
	
	/* CUS: 3005-10.02 - Final - lrodriguezc */
	
	/* P14 - 3006 - Final - lrodriguezc */
	
  public static final String   DILIG_REV_DOCUMENTARIA = "02";
  
  public static final String   DILIG_REC_FISICO = "03";
  
  public static final String   DILIG_CONCLUSION_DESPACHO = "05";
  
  public static final String   DILIG_REGULARIZACION = "07";
  
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	public static final String DILIG_REC_FIS_DES_PARCIALES = "07";
	
	public static final String DILIG_REC_FIS_CONT_DESPACHO = "08";
	
	/* P14 - 3006 - Final - lrodriguezc */
	
  public static final String   DILIG_RECTI_MANUAL = "10";
  // RIN16
  public static final String   DILIG_REGU_REVISION = "20";//Regularizacion Revision
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	public static final String DILIG_PREV_ANTIC_ROJO = "17";
	
	/* P14 - 3006 - Final - lrodriguezc */
  /*RIN13FSW-INICIO*/
  //juazor//
  public static final String   DILIG_CONT_DESPACHO = "19";
  
  public static final String   DILIG_DESCA_PARCIAL = "18";
  public static final String   DILIG_CULMINACION_PECO_AMAZONIA = "27";
  
  public static final String   CODIGO_PROCESO_ASIGNADO = "10"; // P34 CATALOGO 356
  //juazor//
/*RIN13FSW-FIN*/
  /**********************************************************************
   * TIPO DE DILIGENCIAS
   **********************************************************************/
  public static final String   TIPO_DILIG_CONCLUSION_DESPACHO = "C";
  public static final String   TIPO_DILIG_POST_LEVANTE = "L";
  
  
  //P34 AFMA FSW public static final String   TIPO_DILIG_RECTI_OFICIO = "O";
  public static final String   TIPO_DILIG_RECTI_OFICIO = "10";
  public static final String   TIPO_DILIG_REGULARIZACION = "RG";
  
  public static final String   TIPO_DILIG_ESTA_RECTIFICACION = "06";
  public static final String   TIPO_DILIG_ESTA_REGULARIZACION = "07";
  
  // DZC RIN 16
  public static final String   TIPO_DILIG_ESTA_REGULARIZACION_OFICIO = "21";
  public static final String   TIPO_DILIG_CULMINACION_PECO_AMAZONIA = "27";
  
  //public static final String   
  public static final Double   DIF_MAX_MTO =1d;
  
  public static final Double   DIF_MAX_PESO =1d;
  
  public static final Double   DIF_MAX_CANT=0.0009;
  
  public static final String   SEPARADOR1 ="#";
  
  public static final String   SEPARADOR2 ="-";
  
  public static final String   ESTADO_BQ_NO_RATIF = "4";
  
  public static final String   MODO_DILIGENCIA_CONSULTA = "00";
  
  public static final String   MODO_DILIGENCIA_MODIFICA = "MOD";
  
  /**********************************************************************
   * INDICADORES DE LA DECLARACION
   **********************************************************************/ 
  public static final String   IND_DUA_REQ_REGULARIZ = "02";
  public static final String   IND_CAMBIO_REC_FISICO = "08";
  public static final String   IND_DUA_RECTI_OFICIO = "27";//Decia 15 pero el ind de borrador es 27 PAS20155E220200192
  /*P34 - INICIO es mala practica usar asi los codigos de error*/
 public static final String INDICADOR_RECTIFICACION_OFICIO_EN_PROCESO = "26";
	public static final String CODIGO_ERROR_SOLICITUD_RECTIFICACION_OFICIO = "35290";
	/*P34 - FIN*/
  
  
  
  public static final String   INDICADOR_DUA_ACTIVO = "1";
  public static final String   INDICADOR_DUA_INACTIVO = "0";
  
  /**P46 - INSI**/
  public static final String  IND_DONACION_IMPUGNACION_PARCIAL ="06-Impugnaci�n Parcial";
  public static final String  IND_DONACION_IMPUGNACION_TOTAL ="07-Impugnaci�n Total";
  
	/* Inicio P14 3006 01-02 erodriguezb */
	public static final String   IND_DUA_ABANDONO_VOL = "14";
	/* Fin P14 3006 01-02 erodriguezb */
	
	/* P14 - 3014  - Inicio - dhernandezv */
	public static final String   IND_DUA_ABANDONO_LEGAL = "10";
	/* P14 - 3014  - Fin - dhernandezv */
	
  /**********************************************************************
   * MODALIDAD DE DESPACHO
   **********************************************************************/
  public static final String   MODALIDAD_URGENTE = "01";
  public static final String   MODALIDAD_ANTICIPADO= "10";
  public static final String   MODALIDAD_EXCEPCIONAL = "00";
  
  public static final String   MODALIDAD_URGENTE_DESC = "Urgente";
  public static final String   MODALIDAD_ANTICIPADO_DESC= "Anticipado";
  public static final String   MODALIDAD_EXCEPCIONAL_DESC = "Excepcional";
  public static final String   MODALIDAD_DIFERIDO_DESC = "Diferido";
  
  
  
  public static final String   IND_ELIMINADO = "1";
/**INICIO-RIN13**/
  public static final String   IND_NO_ELIMINADO = "0";
/**FIN-RIN13**/  
  /**********************************************************************
   * CODIGOS TABLA NSIGAD
   **********************************************************************/  
  public static final String   COD_TABLA_FACTURA_SERIE          = "T0015";
  public static final String   COD_TABLA_FORMA_FACTU            = "T0016";
  public static final String   COD_TABLA_DET_ADI_ATPA           = "T0028";
  public static final String   COD_TABLA_DET_ADI_ATREEX         = "T0029";
  public static final String   COD_TABLA_DET_AUTORIZACION       = "T0033";
  public static final String   COD_TABLA_CAB_CERTIORIGEN        = "T0037";
  public static final String   COD_TABLA_COMPROBPAGO            = "T0038";
  public static final String   COD_TABLA_CONDICION_TRANSA       = "T0039";
  public static final String   COD_TABLA_CONVENIO_SERIE         = "T0042";
  public static final String   COD_TABLA_SERIES_ITEM            = "T0043";
  public static final String   COD_TABLA_CAB_ADI_ADM_TEM        = "T0047";
  public static final String   COD_TABLA_CAB_ADI_ADM_TEM_DESC   = "CAB_ADI_ADMTEM";
  public static final String   COD_TABLA_CAB_ADI_IMPO_CONSU     = "T0048";
  public static final String   COD_TABLA_DOCUPRECE_DUA          = "T0050";
  public static final String   COD_TABLA_CAB_DECLARA            = "T0051";
  public static final String   COD_TABLA_CAB_DECLARA_DESC       = "CAB_DECLARA";
  public static final String   COD_TABLA_DET_DECLARA            = "T0052";
  public static final String   COD_TABLA_DET_DECLARA_DESC       = "DET_DECLARA";
  public static final String   COD_TABLA_INDICADOR_DUA          = "T0060";
  public static final String   COD_TABLA_DOCAUT_ASOCIADO        = "T0063";
  public static final String   COD_TABLA_FACTUSUCE              = "T0067";
  public static final String   COD_TABLA_FIN_UBICACION          = "T0068";
  public static final String   COD_TABLA_FORMB_ITEM_DESCRI      = "T0069";
  public static final String   COD_TABLA_FORMB_PROVEEDOR        = "T0070";
  public static final String   COD_TABLA_DET_INCIDENCIA         = "T0072";
  public static final String   COD_TABLA_ITEM_FACTURA           = "T0078";
  public static final String   COD_TABLA_ITEM_FACTURA_DESC      = "ITEMFACTURA";
  public static final String   COD_TABLA_MONTO_GASTO            = "T0079";
  public static final String   COD_TABLA_FORMB_MONTO            = "T0080";
  public static final String   COD_TABLA_OBSERVACION            = "T0083";
  public static final String   COD_TABLA_PARTICIPANTE_DOC       = "T0087";
  public static final String   COD_TABLA_DET_ADI_IMPO_CONSU     = "T0092";
  public static final String   COD_TABLA_VFOB_PROVISIONAL       = "T0105";
  public static final String   COD_TABLA_VEHI_CETICO            = "T0106";
  public static final String   COD_TABLA_EQUIPAMIENTO           = "T0112";
  public static final String   COD_TABLA_EQUIPAMIENTO_DESC      = "EQUIPAMIENTO";
  public static final String   COD_TABLA_PLAZOS_PROCESO         = "T0125";
  public static final String   COD_TABLA_PRECINTO        = "T0119";
  public static final String   COD_TABLA_MOVEQUIPAMIENTO        = "T0130";
  
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
  /**********************************************************************
   * Mensajes y Errores 
  **********************************************************************/  
	
	public static final String COD_MENSAJE_IND_ABANDONO_VOLUNTARIO = "35415";
	public static final String COD_ERROR_IND_ABANDONO_VOLUNTARIO = "35407";
	public static final String COD_ERROR_ROL_SUP_OFIC_RESP_NOTI = "35408";
	public static final String COD_ERROR_MERC_DISPUESTA_TOTAL = "35409";
	public static final String COD_ERROR_NOTIF_PEND_RESPUESTA = "35410";
		
	/* P14 - 3006 - Final - lrodriguezc */
	
	/* P14 - 3007 - Incio - dhernandezv */
	
	public static final String COD_ERROR_IND_ABANDONO_VOLUNTARIO_RECTIF   = "35413";
	
	/* P14 - 3007 - Final - dhernandezv */
	
	  //inicio-FSW
  public static final String   COD_TABLA_FORMBITEMDESCRI         = "T0069";
  //fin-FSW
  /**********************************************************************
   * Partidas
   **********************************************************************/  
  public static final String   PARTIDA_MERCANCIA_DONACION       = "9805000000";
  
  
  //Tipos de observaciones
  public static final String   TIPO_OBSERVACION_DECLA = "01";
  public static final String   TIPO_OBSERVACION_PECOAMAZ = "06";  //PAS20181U220200068 - mtorralba 20190304

  //Tipos de Plazo
  public static final String   TIPO_PLAZO_PRESENTADO = "01";
  
  //Tipos de tratamiento de la mercaderia
  public static final String   TIPO_TRATAMIENTO_MERCANCIA_DONACION = "4";
  
  //Tipos de uso de mercaderia
  public static final String   TIPO_USO_MERCANCIA_DONACION = "DNA";
  
  //Tipos de liberacion
  public static final String   TIPO_LIBERACION_TRATADO = "T";
  //public static final String   TIPO_LIBERACION_TRATADO_INTERNACIONAL_TPI = "I";
  
  //Tipos de uso de la referencia
  public static final String   TIPO_USO_REFERENCIA_IMPORTACION = "IM";
  //public static final String   TIPO_USO_REFERENCIA_EXONE_PESO_VEHICULO = "VH2";
  
  //Flags de indicadores
  public static final String   FLAG_INDICADOR_MARCADO = "S";
  public static final String   FLAG_INDICADOR_DESMARCADO= "N";
  
  //Codigos liberatorios (incentivos migratorios)
  public static final String   INCENTIVO_MIGRATORIO_CODIGO_LIBERATORIOS = "4442|4443|4444";
  
  //Tipos de procedencia
  public static final String   TIPO_PROCEDENCIA_IMPORTADOR = "I";

  //Tipos de documento asociado
  public static final String   TIPO_DOCUMENTO_ASOCIADO_RESOLUCION = "2";
  
  public static final String   COD_TIPO_CATALOGO = "D01";
  
  //Tipos de acceso
  public static final String   TIPO_ACCESO_REGULARIZACION = "07";
  public static final String   TIPO_ACCESO_CONCLUSION = "05";
  
  //Tipos de operacion
  public static final String   COD_TIPO_OPERACION_CERTI_ORIGEN = "C";
  
  public static final String   COD_RECTI_RECTIFICA = "R";
  public static final String   COD_RECTI_NUEVO = "N";
  public static final String   COD_RECTI_ANULADO = "A";
  
  public static final String   TIPO_OBSERVACION_ITEM_FB = "03";
  
  public static final String   ESPACIO_BLANCO = " ";
  
//P34 3018 JMCV INICIO  
  public static final Integer PLAZO_MAXIMO_REGU_ANTICIPADA 			= 15;
  public static final String  IND_RECTIOFICIO_EN_PROCESO 			= "1";
  public static final String  IND_RECTIOFICIO_TERMINO_EN_PROCESO	= "0";
//P34 3018 JMCV FIN

//P34 3014 EJHM INICIO   
  public static final String COD_TIPO_CONDICION_TRANSACCION_01        = "01";
  public static final String COD_TIPO_CONDICION_TRANSACCION_02        = "02";
  public static final String COD_TIPO_CONDICION_TRANSACCION_03        = "03";
  public static final String COD_TIPO_CONDICION_TRANSACCION_04        = "04";
  public static final String COD_TIPO_CONDICION_TRANSACCION_05        = "05";
  public static final String COD_TIPO_CONDICION_TRANSACCION_06        = "06";
  public static final String COD_TIPO_CONDICION_TRANSACCION_07        = "07";
  public static final String COD_TIPO_CONDICION_TRANSACCION_08        = "08";
  public static final String COD_TIPO_CONDICION_TRANSACCION_09        = "09";
  public static final String COD_TIPO_CONDICION_TRANSACCION_10        = "10";
  public static final String COD_TIPO_CONDICION_TRANSACCION_11        = "11";
  public static final String COD_TIPO_CONDICION_TRANSACCION_12        = "12";
  public static final String COD_TIPO_CONDICION_TRANSACCION_13        = "13";
  public static final String COD_TIPO_CONDICION_TRANSACCION_14        = "14";
  public static final String COD_TIPO_CONDICION_TRANSACCION_15        = "15";
//P34 3014 EJHM FIN
  
  // TIPO DE DILIGENCIAS CATALOGO 356
  public static final String[] LISTA_DILIGENCIA_DESPACHO        =
                                                                { Diligencia.DESPACHO_DOCUMENTAL.getCodTipDiligencia(),
      Diligencia.DESPACHO_FISICO.getCodTipDiligencia()         };

  public enum Diligencia
  {
    DESPACHO_DOCUMENTAL("02"), DESPACHO_FISICO("03");


    private String codTipDiligencia;

    Diligencia(String codTipDiligencia)
    {
      this.codTipDiligencia = codTipDiligencia;
    }

    public String getCodTipDiligencia()
    {

      return codTipDiligencia;
    }

    public void setCodTipDiligencia(String codTipDiligencia)
    {

      this.codTipDiligencia = codTipDiligencia;
    }

  }
  
  //Claves de secuencias empleadas por el sistema
  public static final String KEY_SECUENCIA_OFI_RECTI = "SEDETOFIRECTI";
  /*RIN13INSI*/
  public static final String KEY_SECUENCIA_PARTICIPANTE = "SEPARTICIPANTE";
  

  /**********************************************************************
   * Prefijo de datasouces dinamicos
   **********************************************************************/  
  public static final String PREF_DATASOURCE_WRITE    = "despaduanero2.dxdaen.";
  public static final String PREF_DATASOURCE_READ     = "despaduanero2.ds.";

  /**********************************************************************
   * Modos de edicion
   **********************************************************************/
  public static final String MODO_EDICION_ACTUALIZADO = "2";
 // public static final String MODO_EDICION_ELIMINADO   = "3";

  public static final String COD_TABLA_DET_ADI_IMPO_CONSU_DESC = "DET_ADI_IMPOCONSU";

  public static final String COD_TABLA_DET_ADI_ATPA_DESC = "DET_ADI_ATPA";

  public static final String COD_TABLA_DET_ADI_ATREEX_DESC = "DET_ADI_ATREEX";

  public static final String COD_TABLA_DOCAUT_ASOCIADO_DESC = "DOCAUT_ASOCIADO";

  public static final String COD_TABLA_DOCUPRECE_DUA_DESC = "DOCUPRECE_DUA";

  public static final String COD_TABLA_FORMB_PROVEEDOR_DESC = "FORMBPROVEEDOR";

  public static final String COD_TABLA_COMPROBPAGO_DESC = "COMPROB_PAGO";

  public static final String COD_TABLA_SERIES_ITEM_DESC = "SERIES_ITEM";

  public static final String COD_TABLA_CONVENIO_SERIE_DESC = "CONVENIO_SERIE";

  public static final String COD_TABLA_FORMA_FACTU_DESC = "FORMA_FACTU";

  public static final String COD_TABLA_INDICADOR_DUA_DESC = "INDICADOR_DUA";

  public static final String COD_TABLA_FIN_UBICACION_DESC = "FIN_UBICACION";

  public static final String COD_TABLA_CONDICION_TRANSA_DESC = "CONDICION_TRANSA";

  public static final String COD_TABLA_CAB_ADI_IMPO_CONSU_DESC = "CAB_ADI_IMPOCONSU";

  public static final String COD_TABLA_VEHI_CETICO_DESC = "VEHI_CETICO";

  public static final String COD_TABLA_FACTUSUCE_DESC = "FACTUSUCE";

  public static final String COD_TABLA_FORMB_MONTO_DESC = "FORMBMONTO";

  public static final String COD_TABLA_MONTO_GASTO_DESC = "MONTOGASTO";
  
  public static final String   COD_TABLA_PRECINTO_DESC      = "PRECINTO";
  
  
  /**********************************************************************
   * #Condiciones de las transacciones
   **********************************************************************/  

  public static final String   CONS_CODFBCONFTRANS7_1 = "01";
  
  public static final String   CONS_CODFBCONFTRANS7_2 = "02";
  
  public static final String   CONS_CODFBCONFTRANS7_3 = "03";
  
  public static final String   CONS_CODFBCONFTRANS7_4 = "04";
  
  public static final String   CONS_CODFBCONFTRANS7_5 = "05";
  
  public static final String   CONS_CODFBCONFTRANS7_6 = "06";
  
  public static final String   CONS_CODFBCONFTRANS7_7 = "07";
  
  public static final String   CONS_CODFBCONFTRANS7_8 = "08";
  
  public static final String   CONS_CODFBCONFTRANS7_9 = "09";
  
  public static final String   CONS_CODFBCONFTRANS7_10= "10";
  
  public static final String   CONS_CODFBCONFTRANS7_11= "11";
  
  public static final String   CONS_CODFBCONFTRANS7_12= "12";
  
  public static final String   CONS_CODFBCONFTRANS7_13= "13";
  
  public static final String   CONS_CODFBCONFTRANS7_14= "14";
  
  public static final String   CONS_CODFBCONFTRANS7_15= "15";
    

  //#Codigos para los montos del Formato B
  //#Base de calculo
  public static final String CONS_CODFBMONTO8_1_1 = "01";
  public static final String CONS_CODFBMONTO8_1_2 = "02";
  public static final String CONS_CODFBMONTO8_1_3 = "03";
  public static final String CONS_CODFBMONTO8_1_4 = "04";
  public static final String CONS_CODFBMONTO8_1_5 = "05";
  public static final String CONS_CODFBMONTO8_1_6_OTROS = "06";
  public static final String CONS_CODFBMONTO8_1_6_VTAS  = "07";
  public static final String CONS_CODFBMONTOTOTBCALCULO = "08";
  //#ADICIONES
  public static final String CONS_CODFBMONTO8_2_1 = "09";
  public static final String CONS_CODFBMONTO8_2_2 = "10";
  public static final String CONS_CODFBMONTO8_2_3 = "11";
  public static final String CONS_CODFBMONTO8_2_3_1 = "12";
  public static final String CONS_CODFBMONTO8_2_3_2 = "13";
  public static final String CONS_CODFBMONTO8_2_3_3 = "14";
  public static final String CONS_CODFBMONTO8_2_3_4 = "15";
  public static final String CONS_CODFBMONTO8_2_4 = "16";
  public static final String CONS_CODFBMONTO8_2_5 = "17";
  public static final String CONS_CODFBMONTOTOTADI ="18";
  //#GASTOS DE TRANSPORTE
  public static final String CONS_CODFBMONTO8_3_1 = "19";
  public static final String CONS_CODFBMONTO8_3_2 = "20";
  public static final String CONS_CODFBMONTOTOTGASTTRANSP = "21";
  public static final String CONS_CODFBMONTOTOTGASTSEG = "22";
  //#DEDUCCIONES
  public static final String CONS_CODFBMONTO8_5_1 = "23";
  public static final String CONS_CODFBMONTO8_5_2 = "24";
  public static final String CONS_CODFBMONTO8_5_3 = "25";
  public static final String CONS_CODFBMONTO8_5_4 = "26";
  public static final String CONS_CODFBMONTO8_5_5 = "27";
  public static final String CONS_CODFBMONTOTOTDEDUC = "28";
  
  //INICIO RIN08
  public static final String AVISOS_CODIGO_SERVICIO_DILIGENCIA_DUA_ADUANA_DESTINO="350";
  public static final String DILIG_ADUANA_DESTINO="22";
  //FIN RIN08  
   /**
   * Enum TipoSeguro.
   *
   * @author amancillaa
   * @version 1.0
   * @since 06/05/2013
   */
  public enum TipoSeguro
  {
    NO_ASEGURADO("1"), SEGURO_INDIVIDUAL("2"), SEGURO_FLOTANTE("3");

    private String codigoSeguro;

    /**
     * Constructor.
     *
     * @param codigoSeguro
     *          the codigo seguro
     */
    TipoSeguro(String codigoSeguro)
    {
      this.codigoSeguro = codigoSeguro;
    }

    public String getCodigo()
    {
      return this.codigoSeguro;
    }

    /**
     * Gets the tipo seguro.
     *
     * @param codSeguro
     *          [String] cod seguro
     * @return the tipo seguro
     */
    public static TipoSeguro getTipoSeguro(String codSeguro)
    {
      try
      {
        return valueOf(codSeguro.toUpperCase());

      }
      catch (IllegalArgumentException e)
      {
        for (TipoSeguro tipoSeguro : TipoSeguro.values())
        {
          if (tipoSeguro.codigoSeguro.equalsIgnoreCase(codSeguro))
          {
            return tipoSeguro;
          }
        }
        throw new IllegalArgumentException("codigo del Campo no esta registrado en este TipoSeguro verificar: "
                                           + codSeguro);
      }
    }

  }
 /*INICIO PAS20124E600000358*/
 
   
  public static final String ACTA_INMOVILIZACION = "AM";
  public static final String ACTA_INCAUTACION     = "AC";

  /** codigo que indica el tipo de operacion que puedo realizar en los JSP **/
  /***CONSTANTES HEREDADAS PARA ADICION Y ELIMINACION DE SERIES PENDIENTE DE REHACER *****/
  public static final String	OPERACION_NUEVO									= "1";
  // public static final String OPERACION_EDITAR = "2";
  // public static final String OPERACION_ELIMINAR = "3";
  public static final String	OPERACION_LECTURA								= "4";

  /************VALORES POR DEFAULT DE LA APLICACION ************************/
  public static final String	DEFAULT_COD_ADUANA							= "000";
  //public static final String	DEFAULT_FECHA_BD			= "01/01/0001";
  public static final String  DEFAULT_FECHA_HORA_BD = "01/01/0001 00:00:00";

    /********************* CONFIGURACION DEL SISTEMA **************************/
  public static final String	RUTA_XML_MAPPING_TABLES							= "mappingTables.xml";
  /* Inicio-AbstractDiligenciaController */
  public static final String	PAGM_MSJ_SOL									= "Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.";
  public static final String	PAGM_MSJ_ERROR									= "Ha ocurrido un error en el aplicativo.";

  //public static final String	DOCUMENTO_ADUANERO								= "DUA";
 // public static final String	NUMERO_PASE										= "PAS20124E600000153";
  //modulo podria englobar varios tipos de diligencia
  public static final String	MODULO_RECTIFICACION_OFICIO						= "10";
  public static final String	MODULO_CULMINACION_PECO						    = "27";
  //public static final String  MODO_DILIGENCIA_CONSULTA              = "00";

  // tipos de documentos asociados a la dua
  public static final String	VAR_NEW											= "NEW";
  public static final String	VAR_OLD											= "OLD";
    // tipos de SWAPPER
  public static final String	SWAPPER_DATASOURCE_DX							= "despaduanero2.dxdaen.";
  public static final String	SWAPPER_DATASOURCE_DS							= "despaduanero2.ds.";

  // Maximo error de redoendo
  /******* FACTORES DE REDONDEO DE LA APLICACION VIGENTE PARA RECTI. OFICIO ***/
  public static final String	DIFERENCIA_MAX_MONTO							= "0.1";
  public static final String	DIFERENCIA_MAX_CANTIDAD							= "0.01";
  public static final String	DIFERENCIA_MAX_PESO								= "0.01";


  /*************** VALORES PARA EL NUEVO COMPARADOR ************************/
  public static final String	REGISTRO_NUEVO									= "N";
  public static final String	REGISTRO_MODIFICADO								= "M";
  public static final String	REGISTRO_SIN_CAMBIOS							= "S";

  /*************** CODIGOS  ************************/
  public static final String	COD_REGIMEN_IMPORTACION_CONSUMO					= "10";
  public static final String	COD_REGIMEN_ADMISION_TEMPORAL_REEXPORTACION		= "20";
  public static final String	COD_REGIMEN_ADMISION_TEMPORAL_PERFECCIONAMIENTO	= "21";
  public static final String	COD_DEPOSITO_ADUANERO							= "70";

  // TRANSPORTISTA(LINEAAEREA)
  public static final String	COD_TIPO_PARTICIPANTE_TRANSPORTISTA				= "11";
  // REPRESENTANTE EN TRANSPORTISTA
  public static final String	COD_TIPO_PARTICIPANTE_REPRESENTANTE				= "12";
  public static final String	COD_TIPO_PARTICIPANTE_DEPOSITO_TEMPORAL			= "31";
  /* olunar 309 */
  public static final String 	COD_TIPO_PARTICIPANTE_AGENTE_ADUANA  			= "41";
  /* fin */
  public static final String	COD_TIPO_PARTICIPANTE_IMPORTADOR				= "45";

  //TIPO DE DILIGENCIAS CATALOGO 356
  // COD_TIPO_DILIGENCIA_DESPACHO SON LOS TIPOS "02 Y "03"
  public static final String	COD_TIPO_DILIGENCIA_REVISION				    = "01"; // olunar 309
  public static final String	COD_TIPO_DILIGENCIA_DESPACHO				    = "02Y03";
  // Rin 13 - inicio - 26-11-2014
  public static final String	COD_TIPO_DILIGENCIA_DESPACHO_02					= "02";
  public static final String	COD_TIPO_DILIGENCIA_DESPACHO_03					= "03";
  // Rin 13 - fin - 26-11-2014
  public static final String	COD_TIPO_REVISION_CONCLUSION					= "04"; //P21-P22
  public static final String	COD_TIPO_DILIGENCIA_CONCLUSION					= "05";
  public static final String	COD_TIPO_DILIGENCIA_RECTIFICACION				= "06";
  public static final String	COD_TIPO_DILIGENCIA_REGULARIZACION				= "07";
  public static final String	COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO		= "10";
  public static final String	COD_TIPO_DILIGENCIA_CULMINACION_PECO		    = "27";
  public static final String	COD_TIPO_DILIGENCIA_ADUANA_DESTINO         		= "22";

  //Tipos de modalidad de la DUA
  public static final String	COD_MODALIDAD_URGENTE	= "01";
  public static final String	COD_MODALIDAD_ANTICIPADO			= "10";
  public static final String	COD_MODALIDAD_EXCEPCIONAL			= "00";

 /*RIN13FSW-INICIO q desgracia de codigo meter en un catalogo*/
  public static final String[] LISTA_SUBPARTIDA_DECLARACION_EXEPTUADA = {"9801", "9802", "9803", "9804", "9805" ,"9806"};
  public static final String[] LISTA_PARA_CODIGOS_LIBERATORIOS = {"2000", "2001", "2002", "2003", "3806" , "3807", "3808", "3809", "3810", "3310",  "3312", "3814", "3302", "3303", "4423", "4425", "4456"};
  public static final String[] LISTA_INFRACCIONES_APTAS_PARA_CALCULO_AUTOMATICO_DE_MONTO = {"A30", "A32", "A33", "A34", "A41", "A50", "A53", "A54", "A56", "A60", "B0", "B11", "B9", "B90", "C20", "C34", "C31", "C41", "C42", "C51", "C62", "C73","D13", "D20", "D30", "D40", "D60", "D61", "D62", "D63", "D70", "D71", "E18", "E19", "E20", "E21", "E22", "E30", "E31", "F21", "F22", "F23", "G11", "G21", "H2", "H4", "H5", "H6" , "H50", "I11", "I12", "I13", "I15", "I17", "J12", "J13", "J11", "J14" ,"M01","A28","B15","B16","B19","D21","D22","D41","D42","D51","D52","E23","E24","F30","F31","F92","M1","M2","M3","M43","M5","M6","M7"};
  public static final String[] LISTA_INFRACCIONES_NO_APTAS_PARA_INCENTIVO = {"A32","A80","B11","B7","C9","C10","D60","D61","D62","D63","E19","E20","E21","E22","F11","F21","F25","J16","K01","L01","B13","B14","B15","B16","B17","B18","B19","B20","B21","B22","B23","D41","D42","F6","F61","F7","F8","F9","F90","F91","F92","G5","G51","H61","H62"};
  public static final String COD_TIPO_DEUDA_PARA_MULTA = "04";
  public static final String IMPORTADOR = "IMPORTADOR";
  public static final String AGENTE = "AGENTE";
  public static final String ALMACEN = "ALMACEN";
 
  /*RIN13FSW-FIN*/

  //Tipos de solicitudes de rectificacion CATALOGO 374
  public static final String	COD_TIPO_SOLICTUD_RECTIFICACION			= "01";
  public static final String	COD_TIPO_SOLICTUD_REGULARIZACION	    = "11";

  public static final String COD_GRUPO_ESPECIALISTA_CONCLUSION	= "GEC";

  //CATALOGO 363 ESTADOS DE LA RECTIFICACION
  public static final String COD_ESTADO_RECTIFICACION_ACEPTADO_AUTO = "01";
  public static final String COD_ESTADO_RECTIFICACION_PENDIENTE_EVALUAR = "02";
  public static final String COD_ESTADO_RECTIFICACION_ASIGNADO = "03";
  public static final String COD_ESTADO_RECTIFICACION_EN_EVALUACION = "04";
  public static final String COD_ESTADO_RECTIFICACION_PROCEDENTE = "05";
  public static final String COD_ESTADO_RECTIFICACION_PROCEDENTE_PARTE = "06";
  public static final String COD_ESTADO_RECTIFICACION_IMPROCEDENTE = "07";
  public static final String COD_ESTADO_RECTIFICACION_ANULADO = "08";
  public static final String COD_ESTADO_RECTIFICACION_RECHAZADO = "09";


  //CATALOGO 352 ESTADOS DE LA RECTIFICACION DE OFICIO
    public static final String COD_EN_REVISION = "01";
    public static final String COD_EN_PROCESO = "02";
    public static final String COD_CONFORME = "03";


    //Estados de dua 335
    public static final String COD_ESTADO_DUA_EN_PROCESO_DILIGENCIA = "04";
    public static final String COD_ESTADO_DUA_EN_PROCESO_CONCLUSION = "12";
// RIN16
    public static final String COD_ESTADO_DUA_LEGAJADA = "08";
    /**********Inicio EGH_INGRESOSDA2******************/
    public static final String COD_ESTADO_DUA_CONCLUSION = "10";

  /****/
  public static final long CANT_HORAS_ITEM_ADICION = 5l;
    
  /*************** CONSTANTES DEL CATALOGO ************************/
  // descripciones de las columnas mostradas en ventana resumenes de rectificaicones
  public static final String	CAT_CASILLAFORMATO							= "D01";
  public static final String	CAT_PARTICIPANTES							= "123";
  public static final String	CAT_CODIFICACION_TABLAS						= "371";
  public static final String  CAT_ESTADO_RECTI_OFICIO                     = "352";
  public static final String LIQUIDA_NO_ELIMINADA = "0";
  public static final String LIQUIDA_NO_CANCELADA = "0";
  //Rin 14 - INI - JYC
  //se agrega el codigo de error 30916 rin alc pase66
  public static final String LST_ALERTAS_DILIGENCIA = "35391,35392,30916";
  public static final String LST_ALERTAS_DILIGENCIA_REGULARIZACION= "30916";  //ALC COREA
  //Rin 14 - FIN - JYC
  
  //VUCE:P_SNADE046-2127
  public static final String CAT_ALERTAS_MERCRESTRINGIDAS_DILIG 	= "854"; 
  
  
/*RIN13FSW-INICIO*/
  //juazor//
  public static final String  CAT_EXPEDIENTE_SUSPENSION                    = "6";
  //fin juazor//
/*RIN13FSW-FIN*/
/*
  public static final String COD_TABLA_CAB_DECLARA                   = "T0051";
  public static final String COD_TABLA_CAB_ADI_ADMTEM                   = "T0047";

  public static final String COD_TABLA_OBSERVACION                   = "T0083";

  public static final String COD_TABLA_DET_DECLARA                   = "T0052";

  public static final String COD_TABLA_DET_ADI_ATPA                   = "T0028";
  public static final String COD_TABLA_DET_ADI_ATREEX                  = "T0029";
  public static final String COD_TABLA_DET_ADI_IMPOCONSU                   = "T0092";


  public static final String COD_TABLA_CAB_CERTIORIGEN                   = "T0037";
  public static final String COD_TABLA_DOCAUT_ASOCIADO                   = "T0063";
  public static final String COD_TABLA_DET_AUTORIZACION                   = "T0033";
  public static final String COD_TABLA_FACTURA_SERIE                   = "T0015";
  public static final String COD_TABLA_FORMA_FACTU                   = "T0016";

  public static final String COD_TABLA_PARTICIPANTE_DOC                   = "T0087";

  public static final String COD_TABLA_FORMBPROVEEDOR                   = "T0070";
  public static final String COD_TABLA_CONDICION_TRANSA                   = "T0039";
  public static final String COD_TABLA_FORMBMONTO                   = "T0080";

  public static final String COD_TABLA_COMPROB_PAGO                   = "T0038";
  public static final String COD_TABLA_ITEMFACTURA                   = "T0078";
  public static final String COD_TABLA_SERIES_ITEM                   = "T0043";

  public static final String COD_TABLA_CONVENIO_SERIE                   = "T0042";

  public static final String COD_TABLA_DOCUPRECE_DUA                   = "T0050";

  public static final String SECUENCIA_DETOFIRECTI       = "SEDETOFIRECTI";

*/
  /************************************* *************************************************/
//FIN PAS20124E600000358
//Inicio RIN14
	  public enum agregarColumnaRestringida{
		TIENE_DOCUMENTO_CONTROL_AUTORIZANTE("S�"),
		TIENE_CODIGO_EXONERACION("Exonerado"),
		TIENE_DOCUMENTOCONTROLAUTORIZANTE_Y_CODIGOEXONERACION("S�(*)"),
		NO_TIENE_MERCANCIASDECLARADAS_RESTRINGIDAS(" ");
		  
		private final String descripcion;
	
		public String getDescripcion() {
			return descripcion;
		}
	
		agregarColumnaRestringida(String descripcion) {
			this.descripcion = descripcion;
		}
		  
	  }
//Fin RIN14	  


/*RIN13FSW-INICIO*/
  //<EHR>
  public static final String   IND_DUA_RECTI_ANTICIPADO = "22";
  public static final String IND_BLOQUEO_DUA = "1";
  public static final String COD_EXTORNOPAGO = "18";
  //--------------
  public final static String IND_REGISTRO_ACTIVO   = "0";
  public static String COD_TIPO_ENVIO_NOTA_DE_TARJA="2";

  public static final String   COD_TIPOREGISTRO_TRANSMISION_ELECTRONICA = "T";
  public static final String   JEFE_DE_MANIFIESTOS = "FEJE-DE-MANIFIESTOS";
  public static final String PLANTILLA_DISMINUCION_BULTOS_SI = "101150";
  public static final String PLANTILLA_DISMINUCION_BULTOS_NO = "101151";
  public static final String TIPO_USUARIO_FUNCIONARIO = "3";
  public static final String TIPO_AVISO_NOTIFICACION = "1";

  //</EHR>
  
  //POSTLEVANTE - PAS20165E220200032
  public static final String   IND_DUA_POST_LEVANTE = "31";

// INICIO RIN13 Bloqueo y Desbloqueo de declaraciones
  public static final String JSON_ADUANAS_139 = "139";
  public static final String JSON_REGIMEN_100 = "100";
  public static final String CON_GARANTIA = "SI";
  public static final String SIN_GARANTIA = "NO";
  public static final String INDICADOR_ELIMINACION_0 = "0";
  public static final String INDICADOR_ELIMINACION_1 = "1";
  public static final String COD_TIP_ACCION_0 = "0";
  public static final String COD_TIP_ACCION_1 = "1";
  public static final int    INT_CERO = 0;
  public static final int    INT_UNO = 1;
  public static final int    INT_DOS = 2; // RIN13FSW ASI VAMOS A TENER TODOS LOS NUMEROS 
  public static final String TODOS_OPCION = "TODOS";
  public static final String TODOS_VALOR = "-1";
  public static final String CODIGO__IMPORTADOR = "45";
  public static final String CODIGO_AGENTE_DE_ADUANAS_41 = "41";
  public static final String CODIGO_AGENTE_DE_ADUANAS_43 = "43";
  public static final String CODIGO_ALMACEN_ADUANANERO_31 = "31";
  public static final String CODIGO_ALMACEN_ADUANANERO_32 = "32";
  public static final String BLOQUEADO_1 = "1";

  public static final char DECIMAL_SEPARADOR_PUNTO = '.';
  public static final char GRUPO_SEPARADOR_COMA = ',';
// FIN RIN13  
/*RIN13FSW-FIN*/
/**INICIO-RIN13**/

  public static final String COD_COMUNICACION_INTERNA = "i";
  public static final String COD_COMUNICACION_EXTERNA = "e";
  public static final String COD_TIENE_DETALLE_COMUNICACION = "1";

/**FIN-RIN13**/
/*RIN13FSW-INICIO*/
// juazor rin13 //
  public static final Integer SOLICITUD_DEPOSITO_ADUANERO = 40;
  public static final Integer SOLICITUD_REGIMEN_IMPORTACION_CONSUMO = 17;
  public static final Integer SOLICITUD_REGIMEN_ADMISION_TEMPORAL_REEXPORTACION = 32;
  public static final Integer SOLICITUD_REGIMEN_ADMISION_TEMPORAL_PERFECCIONAMIENTO = 7;
// fin rin13 //
/*RIN13FSW-FIN*/
  // RIN16
  public static final String FLAG_REGULARIZACION_CONCLUSION_AUTOMATICA = "1";
  public static final String FLAG_REGULARIZACION_NO_CONCLUSION_AUTOMATICA = "0";
  public static final String FLAG_DECLARACION_CARGADA = "1";
  public static final String FLAG_DECLARACION_NO_CARGADA = "0";
  
  //<refactor>
  public static final String CODIGO_TIPO_PARTICIPANTE = "45";
  public static final String CODIGO_TIPO_PARTICIPANTE_AGENCIA = "41";
  /**
   * 495 - ESTADOS DE LA REGULARIZACION DE LA DECLARACION
   */
  public static final String PENDIENTE_DE_REGULARIZAR = "01";
  public static final String PENDIENTE_DE_REGULARIZAR_FUERA_DEL_PLAZO = "02";
  public static final String PENDIENTE_DE_REGULARIZAR_OBSERVADA = "03";
  public static final String REGULARIZADA_DENTRO_DEL_PLAZO = "04";
  public static final String REGULARIZADA_FUERA_DEL_PLAZO = "05";
  public static final String REGULARIZADA_CON_SUSPENSION_DE_PLAZO = "06";
  public static final String REGULARIZADA_DE_OFICIO = "07";
  

  // P34 -3014 Codigo catalogos ini 
  public static final String CODIGO_NIVEL_COMERCIAL         = "85";
  public static final String CODIGO_CONDICION_PROVEEDOR     = "86";
  public static final String CODIGO_MODALIDAD               = "11";
  public static final String CODIGO_FORMA_ENVIO             = "84";
  public static final String CODIGO_NATURALEZA_TRANSACCION  = "81";
  public static final String CODIGO_TIPO_INTERMEDIARIO      = "87";
  public static final String CODIGO_TIPO_DOCUMENTO          = "27";
  public static final String CODIGO_PAIS                    = "J2";
  public static final String CODIGO_TIPO_VALOR              = "332";
  public static final String CODIGO_UNIDAD_COMERCIAL        = "29";
  public static final String CODIGO_ESTADO_MERCANCIA        = "25";
  //AMANCILLA public static final String CODIGO_NIVEL_MERCANCIA_PROVEEDOR = "G6";
  public static final String CODIGO_NIVEL_MERCANCIA_PROVEEDOR = "85";

  public static final String IND_SI_EXISTE_INTERMEDIARIO    = "1";
  public static final String IND_NO_EXISTE_INTERMEDIARIO    = "2";
  public static final String CODIGO_CATALOGO_ADUANAS        = "00";
  // P34 -3014 fin  
  
  /**
   * Constantes para la notificacion de Avisos
   */
  public static final String TIPO_AVISO_ELECTRONICO = "0";
  public static final String TIPO_USUARIO_AVISO_OCE = "1";
  public static final Integer SERVICIO_AVISO_PENDIENTE_DE_REGULARIZAR_OBSERVADA = 222;
  public static final String COD_AREA_NOTIFICA_CENTRAL = "118";
  public static final String DESC_AREA_NOTIFICA_CENTRAL = "Divisi�n de importaci�n de la IAMC";
  public static final String DESC_AREA_NOTIFICA_OPERATIVA = "Departamento de T�cnica Aduanera";
  
  // FIXME: CUS110301 : lpalominom [inicio]
  
  /**
   * Constantes para Validacion Primer Cambio Texto Diligencia Regularizacion
   */
  public static final String TIPO_CAMBIO_PERMITIDO = "P";
  public static final String TIPO_CAMBIO_BLOQUEADO = "B";
  public static final Integer PLAZO_DIAS_UTILIES_SEGUNDA_REGULARIZACION = 2; 
  public static final String FLAG_CONSIDERA_DIA_SIGUIENTE = "N";
  public static final String FLAG_CONSIDERA_DIA_ACTUAL = "S";
  public static final String FLAG_ACTUALIZACION_1 = "1";
  public static final String FLAG_ACTUALIZACION_2 = "2";
  public static final String FLAG_ACTUALIZACION_N = "N";
  public static final Long DEFAULT_CORRELATIVO_SOLICITUD_REGULARIZADA_DE_OFICIO = 0L;
  // FIXME: CUS110301 : lpalominom [final]
  
  /***** GGRANADOS RIN16PASE3 INI *****/
  public static final Integer PLAZO_VENCIMIENTO_REGULARIZACION = 15;
  public static final String COMUNICACION_DILIGENCIA_INTERNA = "i";
  public static final String COMUNICACION_DILIGENCIA_EXTERNA = "e";
  public static final Integer COD_SERVICIO_NOTI_DILIG_REGULARIZACION = 242;
  /***** GGRANADOS RIN16PASE3 FIN *****/
    /*inicio mpoblete BUG*/
  public static final String SALTO_LINEA="\n";
  public static final String ORDENAR_REGISTROS ="1";  
  /*fin mpoblete BUG*/
  /*hosoriov*/
  public static final String INDICADOR_CONTADOR_RECFISIC_04_05 = "24";
  
  //NUMERO MINIMO SERIES DILIGENCIA SIMPLIFICADA
  public static final Integer CANTIDAD_SERIES_DS = 200;
  
    /* PAS20145E220000529 INICIO */
  public static final String BUSCAR_RESOLUCION_MULTA = "B";
  /* PAS20145E220000529 FIN */

  /*INICIO RIN08*/
  //public static final String[] LISTA_CODIGOS_PROCEDIM_PECO_AMAZONIA = {"0919", "0920","0923","0115","3108"};
  public static final String[] LISTA_CODIGOS_PROCEDIM_PECO_AMAZONIA = {"0078","0919", "0920","0923","3108"};
  public static final String[] LISTA_ADUANAS_PECO_LEY_AMAZONIA = {"226","217","271","055","190","118","046","127","280","181","082"};
  /*FIN RIN08*/
	//<RIN10> 3014 ERUESTAA
	public static final String  IND_ACTIVO                    = "1";
	public static final String  COD_TIPO_SOLICITUD_PRORROGA = "21";
	public static final String  COD_TIPO_SOLICITUD_AMPLIACION = "22";
	public static final String  COD_TIPO_VALOR_PROVISIONAL = "2";
	public static final String  COD_TIPO_VALOR_DEFINITIVO = "1";
	//</RIN10> 3014 ERUESTAA
	
	//<RIN10> 3012 ERUESTAA
	/**********************************************************************
	 * VALOR PROVISIONAL
	 **********************************************************************/
	public static final String  COD_PROCESO_F23014                    = "3014";
	public static final String  COD_PROCESO_F23006                    = "3006";
	public static final String  COD_PROCESO_F23012                    = "3012";  
	public static final String  COD_INDICADOR_VALPROV = "20";
	public static final String  IND_GENERACION_LCVP = "1";
	public static final String  COD_TIPO_DILIGENCIA_REGULARIZA_OFICIO = "10";
	public static final int    NUMERO_CERO_INT = 0;
	public static final int    NUMERO_DOS_INT = 2;
	public static final int    NUMERO_TRES_INT = 3;
	public static final int    NUMERO_CUATRO_INT = 4;
	public static final int    NUMERO_CINCO_INT = 5;
	public static final int    NUMERO_SEIS_INT = 6;
	public static final int    NUMERO_SIETE_INT = 7;
	public static final int    NUMERO_OCHO_INT = 8;
	public static final int    NUMERO_DIEZ_INT = 10;
	public static final int    NUMERO_ONCE_INT = 11;	
	public static final int    NUMERO_DIECINUEVO_INT = 19;	
	public static final String BARRA_FECHA = "/";
	public static final String GUION_FECHA = "-";
	public static final int PLAZO_OPERACION_PRORROGA_PE = 12;
	public static final int PLAZO_OPERACION_PRORROGA_PO = 6;
	public static final String  IND_CTACTE_ACTIVO = "1";
	public static final String  COD_TIPODEUDA_DEUDADOCUM = "02";
	public static final String  COD_TIPPLZ_PLAZOSPROCESO = "05";	
	public static final String  COD_TIPDOC_BANDEJADOCU = "332";
	public static final String  COD_ESTDOC_BANDEJADOCU = "00";
	public static final String  COD_ESTDOC_CABSOLICITUD = "01"; //Segun Oswaldo: NUMERADA  
	public static final String  OBSERVACION_DOCAUTASOCIADO = "VALOR PROVISIONAL";
	public static final String  COD_TIPDOCASO_DOCAUTASOCIADO = "17";
	public static final String  TIPO_OPERADOR_CONSIGNATARIO = "45";
	public static final String  DEFAULT_FECHA_BD2 = "31/12/9999";
	public static final String  COD_TIPOMOV_MOVCTACTEGARA = "1";
	public static final String  COD_TIPOEXTINDEUDA_MOVCTACTEGARA = "20";
	
	//lista errores de validaci�n valor provisional - 3012
	public static final String ERR_DUA_NO_TIENE_VALOR_PROVISIONAL = "35544";
	public static final String ERR_NO_FECHA_HABIL = "35545";
	public static final String ERR_EXP_PRESENT_FUERA_PLAZO = "35546";
	public static final String ERR_DUA_TIENE_VALPROV_REGULARIZADO = "35547"; //para ser usado tanto en ampliacion como prorroga
	public static final String ERR_GARANTIA_NO_VIGENTE = "35548";
	public static final String ERR_GARANTIA_NO_CUBRE_MONTO = "35549";
	public static final String ERR_LC_NO_GARANTIZADA = "35550";
	public static final String ERR_DUA_YA_TIENE_PRORROGA_ACEP = "35551";
	public static final String ERR_EXP_NO_EXISTE = "35552";
	public static final String ERR_FECFIN_VALPROV_NO_ES_12_MESES_POST_NUMERACION = "35553";
	public static final String ERR_PRORROGA_EXCEDE_PLAZO_12_MESES = "35554";
	public static final String ERR_AMPLIACION_NO_DENTRO_12_MESES_POST_NUMERACION = "35555";
	public static final String ERR_VIGENCIA_GARAN_NO_CUBRE_FECHA_SOLICITADA = "35556";
	public static final String ERR_DUA_NO_EXISTE = "35557";
	public static final String ERR_LC_NO_EXISTE = "35558";
	public static final String ERR_REG_NO_EXITOSO = "35559";
	public static final String ERR_DUA_NO_TIENE_IMPORTADOR = "35560";
	//Inicio BUG 21978 - Percy HM
	public static final String ERR_PLAZO_MAXIMO_REGULARIZAR_VAL_PROVISIONAL = "35570";
	//Fin BUG 21978 - Percy HM
	//Inicio RIN10 BUG 21585
	public static final String ERR_NUEVA_FECHA_VALOR_PROVISIONAL_ES_MENOR = "35561";
	//Fin RIN10 BUG 21585
	public static final String ERR_LC_NO_GARANTIZADA160 = "35562";  
	public static final String ERR_FECFIN_VALPROV_NO_ES_12_MESES_POST_NUMERACION_PO = "35563";
	public static final String ERR_PLAZO_VENCIDO ="35564";  
	public static final String ERR_PRORROGA_EXCEDE_PLAZO_6_MESES = "35565";
	public static final String ERR_DUA_NO_CORRESPONDE_RUC_IMPORTADOR = "35566";
	public static final String COD_EST_SOL_PARA_DUA_PRORROGA_ACEPTADA  = "04";
	public static final Integer COD_TIPO_CANCELACION_LCVP_GARANTIZADA = 74;
	public final static String COD_CATALOGO_VIGENCIA_GARANTIA = "909";
	public final static String COD_DETCATALOGO_VIGENCIA_GARANTIA = "35077";
	public final static String INDICADOR_GENERACION_LCVP = "1";
	//<RIN10> 3012 ERUESTAA
	
//	<RIN10> 3013 ERODRIGUEZB
	public static final String COD_INDICADOR_VP = "20";
	public static final String COD_REGIMEN_10 = "10";
	public static final String COD_TIPLIQ = "0010";
	public static final String IND_VALPROV = "2";
//	</RIN10> 3013 ERODRIGUEZB

//	<RIN10> 3006 ERUESTAA
	public static final String COD_ESTADO_ADMINISTRATIVO_GARANTIZADO = "G";
	public static final String COD_ESTADO_PAGO_PENDIENTE = "E";
	public static final String COD_TIPO_DEUDA_DE_LA_DUA_LC = "02";
	public static final String MSJ_PENDIENTE_REGUALIZAR = "Pendiente de Regularizar";
	public static final String MSJ_REGULARIZADO			= "Regularizado";
	public static final String MSJ_REGULARIZADO_OFICIO  = "Regularizado de Oficio";
	public static final String TRANS_RECTIFICACION_ANTES_DEL_PAGO_DE_LA_DUA  = "1003";
	public static final String COD_TRANSACCION_DILIGENCIA  = "001";
	public static final String ERR_CTACTE_GARANTIA_NO_VIGENTE  = "LA CTA CTE DE LA GARANTIA NO ESTA VIGENTE";
	public static final String ERR_CTACTE_GARANTIA_SIN_SALDO_OPERATIVO = "LA CTA CTE DE LA GARANTIA NO TIENE SALDO OPERATIVO";
	public static final String ERR_NO_SE_PUEDE_GENERAR_LCVP = "NO SE PUEDE GENERAR LA LC DE VALOR PROVISIONAL";
	public static final String ERR_LCVP_NO_GARANTIZADA = "LIQUIDACI�N DE COBRANZA DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA, NOTIFICAR AL IMPORTADOR";
	public static final String ERR_LCVP_SIN_AFECTACION = "LIQUIDACION DE COBRANZA DE VALOR PROVISIONAL NO HA AFECTADO LA CTA CTE DE LA GARANTIA";
//	</RIN10> 3006 ERUESTAA
  
  //amancilla SAU20153D211000637
  public static final String SOLICITUD_DILIGENCIA_PROCEDENTE = "1";
  public static final String SOLICITUD_DILIGENCIA_IMPROCEDENTE = "0";
  	//ggranados 179
  	public static final String SI = "SI";
  	public static final String NO = "NO";
  	
  	//P14 - diligencia de conclusion pase108
	public static final String ESTADO_NOTIFICADO_CONCLUSION_DESC ="Notificado en Conclusi�n de Despacho";
	
	public static final String COD_TIPO_REGIMEN_PRECEDENTE_FRANQUICIA = "12"; //PAS20155E410000032

    //gg vuce
    public static final String COD_TIPO_DOCUMENTO_SUCE = "20";
    public static final String COD_TIPO_DOCUMENTO_RESOLUTIVO = "21";
    public final static String COD_CATALOG_CODIGO_SUBENTIDAD = "930";

    public static final String DILIG_DESPACHO = "16";
    
    public static final String CAT_REGIMEN_ADUANERO = "17"; /*PAS20175E220200040*/

    /*inicio lalberti DAM DIFERIDA SIN ICA*/
    public static final String COD_CATALOGO_VIGENCIA_NUMERACION_SIN_ICA = "992";
    public static final String COD_PUNTO_LLEGADA_DEPOSITO_TEMPORAL = "1";
    //TIPO DE PUNTO DE LLEGADA - Catalogo 402
    public static final String COD_PUNTO_LLEGADA_TERMINAL_PORTUARIO = "2";
    public static final String COD_TIPO_DOCUMENTO_TRANSPORTE_DIRECTO = "1";
    public static final String COD_TIPO_DOCUMENTO_TRANSPORTE_CONSOLIDADO_1_1 = "3";

    //AVISO
    public static final String COD_PLANTILLA_RECTIFICACION_PUNTO_LLEGADA= "901009";
    public static final Integer  COD_SERVICIO_AVISO_RECTIFICACION_PUNTO_LLEGADA = 419;
    public static final String OBSERVACION_AVISO_RECTIFICACION_PUNTO_LLEGADA="Rectifique el Punto de Llegada de Terminal Portuario a Deposito Temporal";
    
    //RIN 08 MORDONEZL PASE 69
    public static final String[] LISTA_PECO_AMAZONIA = {"34","35", "35","4438"}; 

    /*fin lalberti DAM DIFERIDA SIN ICA*/
    
    /*indicador de diligencia movil cat 302 PAS20181U220200073*/
    public static final String   IND_DILIG_SIMPL_MOVIL = "65";
    
    public static final String CATALOGO_CONTROL_CAMBIO = "380"; // JCV PAS20191U220500086

}