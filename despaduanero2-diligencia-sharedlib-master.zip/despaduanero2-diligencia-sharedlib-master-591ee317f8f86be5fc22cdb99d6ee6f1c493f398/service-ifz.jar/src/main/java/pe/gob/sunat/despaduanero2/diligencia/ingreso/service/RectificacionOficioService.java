package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * <p>Titulo: Metodos de negocio relacionados a Rectificacion de Oficio.</p>
 * <p>Descripcion: Contiene los metodos de negocio validaciones obtencio de datos de la
 *                 rectificacion de oficio.
 * </p>
 * <p>Clase:pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService.java</p>
 * <p>Copyright: SUNAT-2012</p>
 *
 * @author amancillaa
 * @version 1.0
 */
public interface  RectificacionOficioService {


    /**
     * Pre-Condicion : Proceso : Permite validar la declaracion para la
     * Rectificacion de Oficio Post-Condicion: Invocaciones :.
     *
     * @param datosDua
     *            BusquedaDua the datos dua
     * @return ObjectResponseUtil Mapa(Mapa declaracion,Lista
     *         listExpedientesAndActas)
     * @throws ServiceException
     *             the service exception
     * @autor: amancillaa
     */
    public ObjectResponseUtil validarDeclaParaRectificacionOficio(BusquedaDua datosDua) throws ServiceException;


    /**
     * Obtener datos grabados temporalmente en la rectificacion de oficio
     * devuleve .
     *
     * @param numCorreDoc [String] numero correlativo de la DUA
     * @param codTipDiligencia [String] cod tip diligencia
     * @return Map<String,Object> map contenido [lstTmpDetOfiRecti,lstCambios]
     * lstTmpDetOfiRecti datos de las diferencias para ser actualizadas
     * lstCambios        datos formateados para mostrar en el JSP
     * @throws ServiceException
     * @author amancilla
     * @version 1.0
     * @since Aug 26, 2012
     */
    public Map<String, Object> obtenerDatosGrabadosTemporalmente(String numCorreDoc, String codTipDiligencia) throws ServiceException;



    /**
     * Borrar datos tmp.
     *
     * @param numCorreDoc [String] num corre doc
     * @return  [Map<String,Object>] map
     * @throws ServiceException the service exception
     * @author  amancilla
     * @version 1.0
     */
    public void borrarDatosTMP(String numCorreDoc) throws ServiceException;


    /**
     * Registra temporalmente los datos modificados en la declaracion en la.
     * tabla TMP_DET_OFIRECTI considerar la diferencia entre registro anterior y
     * actual para sacar las diferencia a grabar
     *
     * @param params [Map] mapTablasSESSION
     * @throws ServiceException the service exception
     */
    public void grabarTMP(Map<String, Object> mapTablasSESSION) throws ServiceException;

    /**
     * Obtener cambios declaracion.
     *
     * @param param
     *          [Map<String,Object>] param
     * @return [List<DatoModificadoBean>] list
     * @throws ServiceException
     *           the service exception
     * @author amancillaa
     * @version 1.0
     */
    public List<DatoModificadoBean> obtenerCambiosDeclaracion(Map<String, Object> param) throws ServiceException;

    /**
     * Actualizar estado rectificacion oficio.
     *
     * @param busquedaDua
     *          [BusquedaDua] busqueda dua
     * @throws ServiceException
     *           the service exception
     */
    public void actualizarEstadoRectificacionOficio(BusquedaDua busquedaDua) throws ServiceException;

    /**
     * Tiene rectificacion oficio pendiente.
     *
     * @param numCorreDocDua
     *          [String] num corre doc dua
     * @return [Boolean] boolean
     * @throws ServiceException
     *           the service exception
     * @author amancillaa
     * @version 1.0
     */
    public Boolean tieneRectificacionOficioPendiente(String numCorreDocDua) throws ServiceException;

//P34 EJHM
//    /**
//     * Tiene rectificacion oficio pendiente.
//     *
//     * @param numCorreDocDua
//     *          [String] num corre doc dua
//     * @return [Boolean] boolean
//     * @throws ServiceException
//     *           the service exception
//     * @author amancillaa
//     * @version 1.0
//     */
//    public Boolean tieneRectificacionOficioPendiente(String numCorreDocDua) throws ServiceException;
    
    //P34: JAZB - INICIO
    /**
     * Tiene rectificacion oficio en Proceso .
     *
     * @param numCorreDocDua
     *          [String] num corre doc dua
     * @return [Boolean] boolean
     * @throws ServiceException
     *           the service exception
     * @author jzafras
     * @version 1.0
     */
    public Boolean tieneRectificacionOficioEnProceso(String numCorreDocDua) throws ServiceException;
    //P34: JAZB - FIN
    
    public String validarAdvertenciaOficio(BusquedaDua busquedaDua);

}