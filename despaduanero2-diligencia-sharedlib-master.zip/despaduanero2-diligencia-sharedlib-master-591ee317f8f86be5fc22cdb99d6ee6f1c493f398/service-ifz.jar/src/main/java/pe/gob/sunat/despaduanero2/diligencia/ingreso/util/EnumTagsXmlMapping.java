package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

public enum EnumTagsXmlMapping {

    ESPACIO_BLANCO("ESPACIO_BLANCO", " "),
    SYSDATE("SYSDATE", "SYSDATE");

    private String identificadorXML;
    private String valor;

    EnumTagsXmlMapping(String identificadorXML, String valor) {
        this.identificadorXML = identificadorXML;
        this.valor = valor;
    }

    public String getIdentificadorXML() {
        return identificadorXML;
    }

    public void setIdentificadorXML(String identificadorXML) {
        this.identificadorXML = identificadorXML;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}
