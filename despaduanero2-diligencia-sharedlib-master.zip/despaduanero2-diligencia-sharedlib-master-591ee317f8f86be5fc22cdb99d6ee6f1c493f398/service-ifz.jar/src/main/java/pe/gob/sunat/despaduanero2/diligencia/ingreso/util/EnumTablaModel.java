package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.*;;

/**
 * Clase enumerada que contiene los nombres de las tablas de BD y su respectio TAG Entidad
 * registra en el mappingTables.xml.
 *
 * @author  amancilla
 * @version 1.0
 * @since   Aug 27, 2012
 */
public enum EnumTablaModel {
	//P46-PAS20155E410000032 EJHM 
	INDICADOR_DUA("indicadorDua","INDICADOR_DUA",COD_TABLA_INDICADOR_DUA,"",""),

    CAB_DECLARA("cabDeclara", "CAB_DECLARA",COD_TABLA_CAB_DECLARA,"mapCabDeclaraActual","mapCabDeclara"),
      //por el momento los mapas que contiene ese dato es la declaracion
    OBSERVACION("observacion","OBSERVACION",COD_TABLA_OBSERVACION,"mapCabDeclaraActual","mapCabDeclara"),

    CAB_ADI_ADMTEM("cabAdiAdmTem","CAB_ADI_ADMTEM",COD_TABLA_CAB_ADI_ADM_TEM,"",""),

    DET_DECLARA("detDeclara","DET_DECLARA",COD_TABLA_DET_DECLARA,"lstDetDeclaraActual","lstDetDeclara"),

    DET_ADI_ATPA("detAdiAtpa","DET_ADI_ATPA",COD_TABLA_DET_ADI_ATPA,"",""),

    DET_ADI_ATREEX("detAdiAtreex","DET_ADI_ATREEX",COD_TABLA_DET_ADI_ATREEX,"",""),

    DET_ADI_IMPOCONSU("detAdiImpoConsu","DET_ADI_IMPOCONSU",COD_TABLA_DET_ADI_IMPO_CONSU,"",""),

    CAB_CERTIORIGEN("cabCertiOrigen","CAB_CERTIORIGEN",COD_TABLA_CAB_CERTIORIGEN,"",""),

    DOCAUT_ASOCIADO("docAutAsociado","DOCAUT_ASOCIADO",COD_TABLA_DOCAUT_ASOCIADO,"",""),

    DET_AUTORIZACION("detAutorizacion","DET_AUTORIZACION",COD_TABLA_DET_AUTORIZACION,"",""),

    //no esta registrado en el XML COMUNICACION("comunicacion","COMUNICACION","T0001",""),

    //CONSULTA("consulta","CONSULTA","T0002",""),

    FORMA_FACTU("formaFactu","FORMA_FACTU",COD_TABLA_FORMA_FACTU,"",""),

    FACTURA_SERIE("facturaSerie","FACTURA_SERIE",COD_TABLA_FACTURA_SERIE,"",""),

    PARTICIPANTE_DOC("participanteDoc","PARTICIPANTE_DOC",COD_TABLA_PARTICIPANTE_DOC,"",""),

    FORMBPROVEEDOR("formbProveedor","FORMBPROVEEDOR",COD_TABLA_FORMB_PROVEEDOR,"",""),

    CONDICION_TRANSA("condicionTransaccion","CONDICION_TRANSA",COD_TABLA_CONDICION_TRANSA,"",""),

    FORMBMONTO("formbMonto","FORMBMONTO",COD_TABLA_FORMB_MONTO,"",""),

    COMPROB_PAGO("comprobPago","COMPROB_PAGO",COD_TABLA_COMPROBPAGO,"",""),

    ITEMFACTURA("itemFactura","ITEMFACTURA",COD_TABLA_ITEM_FACTURA,"",""),

    SERIES_ITEM("seriesItem","SERIES_ITEM",COD_TABLA_SERIES_ITEM,"",""),

    CONVENIO_SERIE("convenioSerie","CONVENIO_SERIE",COD_TABLA_CONVENIO_SERIE,"",""),

    //CAB_ADI_TRANSITO("cabAdiTransito","CAB_ADI_TRANSITO","T0049",""),

    DOCUPRECE_DUA("docuPreceDua","DOCUPRECE_DUA",COD_TABLA_DOCUPRECE_DUA,"",""),
    
    VEHI_CETICO("vehiCetico","VEHI_CETICO",COD_TABLA_VEHI_CETICO,"",""),
    
    MONTOGASTO("montoGasto","MONTOGASTO",COD_TABLA_MONTO_GASTO,"",""),

    //INDICADOR_DUA("IndicadorDua","INDICADOR_DUA","T0060",""),

    CAB_DILIGENCIA("cabDiligencia","CAB_DILIGENCIA","T0061","mapCabDiligenciaActual",""),

    DET_INCIDENCIA("detIncidencia","DET_INCIDENCIA","T0072","",""),

    //INCI_EVENTO("inciEvento","INCI_EVENTO","T0073",""),

    ESPE_DOCU("espeDocu","ESPE_DOCU","T0031","",""),

    DET_OFIRECTI("detOfiRecti","DET_OFIRECTI","T0126","",""),

    // Bug en SWF P34 - Inicio
    PLAZOSPROCESO("plazosProceso","PLAZOSPROCESO","T0125","",""),
    // Bug en SWF P34 - Fin
    
    //inicio-FSW
    FORMBITEMDESCRI("formbItemDescri","FORMBITEMDESCRI","T0069","",""),
    //fin-FSW
    //BD DESCENTRALZIADAS

    TAB_BOL_QUIM("tabBolQuim","TAB_BOL_QUIM","","","");

    private String identificadorXML;
    private String nombreBD;
    private String codTabla;
    private String nombreVariableSessionNew;
    private String nombreVariableSessionOld;

    /**
     * Instantiates a new enum tabla model.
     *
     * @param identificadorXML [String] identificador xml
     * @param nombreBD [String] nombre bd
     * @param codTabla [String] cod tabla
     * @param nombreVariableSessionNew [String] nombre variable session new
     * @param nombreVariableSessionOld [String] nombre variable session old
     */
    EnumTablaModel(String identificadorXML, String nombreBD, String codTabla, String nombreVariableSessionNew,
            String nombreVariableSessionOld) {

        this.identificadorXML = identificadorXML;
        this.nombreBD = nombreBD;
        this.codTabla = codTabla;
        this.nombreVariableSessionNew = nombreVariableSessionNew;
        this.nombreVariableSessionOld = nombreVariableSessionOld;
    }

    /**
     * busca EnumTablaModel por su atributo codTabla codigo de tabla.
     *
     * @param codigoTabla [String]
     * @return EnumTablaModel
     */
    public static EnumTablaModel getEnumTablaModelPorCodigoTabla(String codigoTabla){

        try {
                return valueOf( codigoTabla.toUpperCase());
            } catch (IllegalArgumentException e) {
                for (EnumTablaModel enumTablaModel : EnumTablaModel.values()) {
                    if (enumTablaModel.codTabla.equalsIgnoreCase(codigoTabla)) {
                        return enumTablaModel;
                    }
                }
                throw new IllegalArgumentException("codigo de tabla no esta registrado en este EnumTablaModel verificar: "
                        + codigoTabla);
            }
    }



    /**
     * busca EnumTablaModel por su atributo codTabla codigo de tabla.
     *
     * @param nombreTabla [String]
     * @return EnumTablaModel
     */
    public static EnumTablaModel getEnumTablaModelPorNombreTabla(String nombreTabla){

        try {
                return valueOf( nombreTabla.toUpperCase());
            } catch (IllegalArgumentException e) {
                for (EnumTablaModel enumTablaModel : EnumTablaModel.values()) {
                    if (enumTablaModel.nombreBD.equalsIgnoreCase(nombreTabla)) {
                        return enumTablaModel;
                    }
                }
                throw new IllegalArgumentException("codigo de tabla no esta registrado en este EnumTablaModel verificar: "
                        + nombreTabla);
            }
    }

    public String getIdentificadorXML() {

        return identificadorXML;
    }

    public void setIdentificadorXML(String identificadorXML) {

        this.identificadorXML = identificadorXML;
    }

    public String getNombreBD() {

        return nombreBD;
    }

    public void setNombreBD(String nombreBD) {

        this.nombreBD = nombreBD;
    }

    public String getCodTabla() {

        return codTabla;
    }

    public void setCodTabla(String codTabla) {

        this.codTabla = codTabla;
    }

    public String getNombreVariableSessionNew() {

        return nombreVariableSessionNew;
    }

    public void setNombreVariableSessionNew(String nombreVariableSessionNew) {

        this.nombreVariableSessionNew = nombreVariableSessionNew;
    }

    public String getNombreVariableSessionOld() {

        return nombreVariableSessionOld;
    }

    public void setNombreVariableSessionOld(String nombreVariableSessionOld) {

        this.nombreVariableSessionOld = nombreVariableSessionOld;
    }
}
