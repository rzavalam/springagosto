package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

import org.apache.commons.lang.StringUtils;

public class StringUtil
{

  private static final String DEFAULT_STRING = "";
/*RIN13FSW-INICIO*/
  private static final String VEHICULOS                   = "VEHICULOS";
  private static final String TEXTIL_FIBRA                = "TEXTIL FIBRA";
  private static final String TEXTIL_HILADO               = "TEXTIL HILADO";
  private static final String TEXTIL_TELA                 = "TEXTIL TELA";
  private static final String TEXTIL_PRENDAS              = "PRENDAS DE VESTIR Y CONFECCIONES";
  private static final String TEXTIL_OTROS                = "DEMAS TEXTILES";
  private static final String REPRODUCCION_DISCOS_OPTICOS = "REPRODUCCION Y ALMACENAMIENTO DE DISCOS OPTICOS";
  private static final String REPRODUCCION_CASETTE_AUDIO  = "REPRODUCCION Y ALMACENAMIENTO DE CASETTE AUDIO";
  private static final String REPRODUCCION_CASETTE_VHS    = "REPRODUCCION Y ALMACENAMIENTO DE VHS";
  private static final String REPRODUCCION_ESTUCHE_DISCO  = "REPRODUCCION Y ALMACENAMIENTO DE ESTUCHE DE DISCO";
  private static final String REPRODUCCION_CONTROLADOR    = "REPRODUCCION Y ALMACENAMIENTO DE CONTROLADOR";
  private static final String REPRODUCCION_TORRE          = "REPRODUCCION Y ALMACENAMIENTO DE TORRE";
  private static final String REPRODUCCION_DUPLICADORA    = "REPRODUCCION Y ALMACENAMIENTO DE DUPLICADORA";
  private static final String NEUMATICOS                  = "NEUMATICOS";
  private static final String CALZADOS_CUERO_NATURAL      = "CALZADOS DE CUERO NATURAL";
  private static final String CALZADOS_PLASTICO_SINTETICO = "CALZADOS DE PLASTICO SINTETICO";
  private static final String CALZADOS_TEXTIL             = "CALZADOS DE TEXTIL";
  private static final String CALZADOS_OTROS              = "DEMAS CALZADOS";
  private static final String ANILLOS 					  = "ANILLOS PARA OJETES";
  private static final String LAMINAS 					  = "LAMINAS";
  private static final String LENTES_DEMAS 				  = "DEMAS LENTES";
  private static final String LENTES_GAFAS 				  = "GAFAS";
  private static final String LENTES_CONTACTO 			  = "LENTES DE CONTACTO CORRECTOR";
  private static final String COMPUTO_COMPUTADORA   	  = "COMPUTADORA";
  private static final String COMPUTO_CPU 				  = "CPU";
  private static final String COMPUTO_DISCO_DURO 		  = "DISCO DURO";
  private static final String COMPUTO_DISQUETERA 		  = "DISQUETERA";
  private static final String COMPUTO_IMPRESORA 		  = "IMPRESORA";
  private static final String COMPUTO_CDROM 			  = "CD-ROM";
  private static final String COMPUTO_MEMORIA 			  = "MEMORIA";
  private static final String COMPUTO_MONITOR 			  = "MONITOR";
  private static final String COMPUTO_MOUSE 			  = "MOUSE";
  private static final String COMPUTO_PROCESADOR 		  = "PROCESADOR";
  private static final String COMPUTO_SCANNER 			  = "SCANNER";
  private static final String COMPUTO_TARJETA_SONIDO 	  = "TARJETA DE SONIDO";
  private static final String COMPUTO_TARJETA_VIDEO 	  = "TARJETA DE VIDEO";
  private static final String COMPUTO_TARJETA_RED 		  = "TARJETA DE RED";
  private static final String COMPUTO_TARJETA_MADRE 	  = "TARJETA MADRE";
  private static final String COMPUTO_TECLADO 			  = "TECLADO";
  private static final String COMPUTO_VENTILADOR 		  = "VENTILADOR";
  private static final String COMPUTO_ZIP_DRIVER 		  = "ZIP DIVER";
  private static final String PILAS 					  = "PILAS";
  private static final String CREMALLERA 				  = "CREMALLERA";
  private static final String CREMALLERA_OTROS 			  = "DEMAS CIERRES";
  private static final String MALETAS 					  = "MALETAS, BOLSO, MOCHILAS Y OTROS";
  private static final String CERAMICOS 				  = "CERAMICOS";
  private static final String JUGUETES 					  = "JUGUETES";
  private static final String SANITARIOS_INODORO 		  = "INODORO";
  private static final String SANITARIOS_OTROS 			  = "DEMAS PRODUCTOS SANITARIOS";
  private static final String ARTICULOS_DOMESTICOS 		  = "ARTICULOS DOMESTICOS";
  private static final String UTILES_ESCRITORIO 		  = "UTILES DE ESCRITORIO";
  private static final String UTILES_OTROS 				  = "DEMAS UTILES DE ESCRITORIO";
/*RIN13FSW-FIN*/
  /**
   * Es vacio.
   *
   * @param lista
   *          the lista
   * @return true, if successful
   */
  public static String defaultSiEsVacio(String dato)
  {
    return StringUtils.defaultIfEmpty(dato, DEFAULT_STRING);
  }

  public static boolean esVacio(String dato)
  {
    return StringUtils.isEmpty(dato);
  }

  public static boolean noEsVacio(String dato)
  {
    return !esVacio(dato);
  }
   
  //inicio EJHM
  public static boolean esVacio(String dato, boolean EliminaEspacios)
  {
	  if(EliminaEspacios)
    return isEmptyBlank(dato);
	  else
	 return StringUtils.isEmpty(dato);
  }
  public static String retirarSaltosCadena(String cadena)
  {
    if(!esVacio(cadena)){
     // P34 inicio EJHM
    	return cadena.replace("\\r|\\n","").replace("  "," ").replace("\r|\n"," ").replace("\n", " ").replace("\r"," ").replace("  ", " ");
     // P34 fin EJHM
	}
    return cadena;
  }
  public static String generarEspacios(String valor, int nroDigitos, boolean limpiaEspacios) {
		if (esVacio(valor)) {
			return replicarValor(' ', nroDigitos);
		}
		String sround = limpiaEspacios ? valor.trim() : valor;
		int dif = nroDigitos - sround.length();
		if (dif <= 0) {
			return sround.substring(0, nroDigitos);

		}
		return replicaralaDerechaRapidam(sround, ' ', dif);
	}
  public static String completarCeroIzquierda(String valor, int nroDigitos) {
		String svalor = valor + "";
		int nro = svalor.length();
		if (nro >= nroDigitos) {
			return svalor;
		}
		return replicarValor("0", nroDigitos - nro) + svalor;
	}
  public static  String replicarValor(String valor, int nroVeces) {
		if (nroVeces <= 0) {
			return "";
		}
		StringBuilder s = new StringBuilder(valor.length() * nroVeces);
		int i = nroVeces;
		while (i > 0) {
			s.append(valor);
			i--;
		}
		return s.toString();
	}
  public static String replicarValor(char valor, int nroVeces) {
		if (nroVeces <= 0) {
			return "";
		}
		StringBuilder s = new StringBuilder(nroVeces);
		int i = nroVeces;
		while (i > 0) {
			s.append(valor);
			i--;
		}
		return s.toString();
	}

	private static String replicaralaDerechaRapidam(String valorAppend, char valor,
			int nroVeces) {
		StringBuilder sb = new StringBuilder(nroVeces + valorAppend.length());
		sb.append(valorAppend);
		int i = nroVeces;
		while (i > 0) {
			sb.append(valor);
			i--;
		}
		return sb.toString();
	}
	public  static String espacio(int nroVeces) {
		return replicarValor(" ", nroVeces);
	}
	public static boolean isEmptyBlank(String str) {
		if(str!=null){
			str=str.trim();	
		}
		return ((str == null) || (str.length() == 0));
	}
	

    //fin EJHM
  
/*RIN13FSW-INICIO*/
  public static String obtenerNombreDescripcionMinima(String codigoDescripcionMinima){
	  String nombreDescripcionMinima = "";
	  int codigo = Integer.parseInt(codigoDescripcionMinima);
	  switch (codigo) {
		case 1: nombreDescripcionMinima = 	VEHICULOS; break;	
		case 2: nombreDescripcionMinima = 	TEXTIL_FIBRA; break;
		case 3: nombreDescripcionMinima =  	TEXTIL_HILADO; break;
		case 4: nombreDescripcionMinima =  	TEXTIL_TELA; break;
		case 5: nombreDescripcionMinima =  	TEXTIL_PRENDAS; break;
		case 6: nombreDescripcionMinima =  	TEXTIL_OTROS; break;
		case 7: nombreDescripcionMinima =  	REPRODUCCION_DISCOS_OPTICOS; break;
		case 8: nombreDescripcionMinima =  	REPRODUCCION_CASETTE_AUDIO; break;
		case 9: nombreDescripcionMinima =  	REPRODUCCION_CASETTE_VHS; break;
		case 10: nombreDescripcionMinima =  REPRODUCCION_ESTUCHE_DISCO; break;
		case 11: nombreDescripcionMinima =  REPRODUCCION_CONTROLADOR; break;
		case 12: nombreDescripcionMinima =  REPRODUCCION_TORRE; break;
		case 13: nombreDescripcionMinima =  REPRODUCCION_DUPLICADORA; break;
		case 14: nombreDescripcionMinima =  NEUMATICOS; break;
		case 15: nombreDescripcionMinima =  CALZADOS_CUERO_NATURAL; break;
		case 16: nombreDescripcionMinima =  CALZADOS_PLASTICO_SINTETICO; break;
		case 17: nombreDescripcionMinima =  CALZADOS_TEXTIL; break;
		case 18: nombreDescripcionMinima =  CALZADOS_OTROS; break;
		case 19: nombreDescripcionMinima =  ANILLOS; break;
		case 20: nombreDescripcionMinima =  LAMINAS; break;
		case 21: nombreDescripcionMinima =  LENTES_DEMAS; break;
		case 22: nombreDescripcionMinima =  LENTES_GAFAS; break;
		case 23: nombreDescripcionMinima =  LENTES_CONTACTO; break;
		case 24: nombreDescripcionMinima =  COMPUTO_COMPUTADORA; break;
		case 25: nombreDescripcionMinima =  COMPUTO_CPU; break;
		case 26: nombreDescripcionMinima =  COMPUTO_DISCO_DURO; break;
		case 27: nombreDescripcionMinima =  COMPUTO_DISQUETERA; break;
		case 28: nombreDescripcionMinima =  COMPUTO_IMPRESORA; break;
		case 29: nombreDescripcionMinima =  COMPUTO_CDROM; break;
		case 30: nombreDescripcionMinima =  COMPUTO_MEMORIA; break;
		case 31: nombreDescripcionMinima =  COMPUTO_MONITOR; break;
		case 32: nombreDescripcionMinima =  COMPUTO_MOUSE; break;
		case 33: nombreDescripcionMinima =  COMPUTO_PROCESADOR; break;
		case 34: nombreDescripcionMinima =  COMPUTO_SCANNER; break;
		case 35: nombreDescripcionMinima =  COMPUTO_TARJETA_SONIDO; break;
		case 36: nombreDescripcionMinima =  COMPUTO_TARJETA_VIDEO; break;
		case 37: nombreDescripcionMinima =  COMPUTO_TARJETA_RED; break;
		case 38: nombreDescripcionMinima =  COMPUTO_TARJETA_MADRE; break;
		case 39: nombreDescripcionMinima =  COMPUTO_TECLADO; break;
		case 40: nombreDescripcionMinima =  COMPUTO_VENTILADOR; break;
		case 41: nombreDescripcionMinima =  COMPUTO_ZIP_DRIVER; break;
		case 42: nombreDescripcionMinima =  PILAS; break;
		case 43: nombreDescripcionMinima =  CREMALLERA; break;
		case 44: nombreDescripcionMinima =  CREMALLERA_OTROS; break;
		case 45: nombreDescripcionMinima =  MALETAS; break;
		case 46: nombreDescripcionMinima =  CERAMICOS; break;
		case 47: nombreDescripcionMinima =  JUGUETES; break;
		case 48: nombreDescripcionMinima =  SANITARIOS_INODORO; break;
		case 49: nombreDescripcionMinima =  SANITARIOS_OTROS;break;
		case 50: nombreDescripcionMinima =  ARTICULOS_DOMESTICOS; break;
		case 51: nombreDescripcionMinima =  UTILES_ESCRITORIO; break;
		case 52: nombreDescripcionMinima =  UTILES_OTROS; break;
		default:nombreDescripcionMinima  =  "No se pudo obtener el Nombre de la Descripci�n M�mina";
			break;
		}
	  return nombreDescripcionMinima; 
  }
/*RIN13FSW-FIN*/
//<EHR>
	public static boolean isBlankOrNull(String cadena)
	{
		boolean valor = false;

		if (cadena == null)
		{
			return true;
		}
		if (cadena.trim().isEmpty())
		{
			return true;
		}
		return valor;
	}
  
	public static String trimCadena(String cadena)
	{

		if (cadena != null)
		{
			return cadena.trim();
		}
		return cadena;
	}
//</EHR>

/*
  public static void main(String[] args)
  {
    String nullo = null;
    System.out.println(defaultSiEsVacio(nullo));
    System.out.println(defaultSiEsVacio(""));
    System.out.println(defaultSiEsVacio("alex"));
  }
*/
}
