package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;

public class SeriesItemRectificacion extends RectificacionAbstract implements Serializable{


	private static final long serialVersionUID = 1564098292856560296L;
	private static final String NOMBRE_LISTA_ORIGINAL = "lstSeriesItem";
	public static final String NOMBRE_LISTA_RESULTANTE = NOMBRE_LISTA_ORIGINAL+"Actual";
	private SeriesItemDAO seriesItemDAO;

	//rtineo mejoras, grabacion en batch
	private SeriesItemBatchDAO seriesItemBatchDAO;

	public SeriesItemRectificacion(){
		mapClave = new HashMap<String, Object>();
		mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
		mapClave.put("NUM_SECITEM", "NUM_SECITEM");
		mapClave.put("NUM_SECSERIE", "NUM_SECSERIE");

		
	}
	
	protected String getNombreListaOriginal() {
		return NOMBRE_LISTA_ORIGINAL;
	}
	
	protected String getNombreListaResultante() {
		return NOMBRE_LISTA_RESULTANTE;
	}
	
	protected String getCodTablaRectificacion() {
		return Constantes.COD_TABLA_SERIES_ITEM;
	}

	@Override
	protected Map<String, Object> getDatosInicialesRectifacion(Map<String, Object> mapResultado, Map<String, Object> mapValores) {
		mapResultado.put(NOMBRE_LISTA_ORIGINAL, getTablaBD(mapValores));
		return mapResultado;
	}
	
	@Override
	protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros){
		Map<String, Object> mapParametros = new HashMap<String, Object>();
		// Se recupera por Documento los valores
		mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
		return seriesItemDAO.select(mapParametros);
	}

	public DatoSerieItem mapToObject(Map<String, Object> seriesItem ){
		DatoSerieItem datoSerieItem = new DatoSerieItem();
		
		datoSerieItem.setNumcorredoc(new Long(ObjectUtils.toString(seriesItem.get("NUM_CORREDOC"), " ")));
		datoSerieItem.setNumsecprove(new Integer(ObjectUtils.toString(seriesItem.get("NUM_SECPROVE"), " ")));
		datoSerieItem.setNumsecfact(new Integer(ObjectUtils.toString(seriesItem.get("NUM_SECFACT"), " ")));
		datoSerieItem.setNumsecitem(new Integer(ObjectUtils.toString(seriesItem.get("NUM_SECITEM"), " ")));
		
		datoSerieItem.setNumserie(new Integer(ObjectUtils.toString(seriesItem.get("NUM_SECSERIE"), " ")));
		datoSerieItem.setMtofobitser(new BigDecimal(ObjectUtils.toString(seriesItem.get("MTO_FOB"), " ")));
		datoSerieItem.setMtoajuitser(new BigDecimal(ObjectUtils.toString(seriesItem.get("MTO_AJUSTE"), " ")));
		datoSerieItem.setCant_mercd(new BigDecimal(ObjectUtils.toString(seriesItem.get("CNT_MERC"), " "))); 
		
		return datoSerieItem;
	}
	
	//rtineo mejoras, grabacion en batch
	public SeriesItemBatchDAO getSeriesItemBatchDAO() {
		return seriesItemBatchDAO;
	}
	//rtineo mejoras, grabacion en batch
	public void setSeriesItemBatchDAO(SeriesItemBatchDAO seriesItemBatchDAO) {
		this.seriesItemBatchDAO = seriesItemBatchDAO;
	}
	
	public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO) {
		this.seriesItemDAO = seriesItemDAO;
	}

	@Override
	protected void insertRecord(Map<String, Object> newRecordMap) {
		seriesItemDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
		
	}

	@Override
	protected void updateRecord(Map<String, Object> updateRecordMap) {
		seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));//mapSeriesItem
		
	}
	//rtineo mejoras, grabacion en batch
	@Override
	protected void insertRecordBatch(Map<String, Object> newRecordMap) {
		seriesItemBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

}
	//rtineo mejoras, grabacion en batch
	@Override
	protected void updateRecordBatch(Map<String, Object> updateRecordMap) {
		seriesItemBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));//mapSeriesItem
		
	}
}
