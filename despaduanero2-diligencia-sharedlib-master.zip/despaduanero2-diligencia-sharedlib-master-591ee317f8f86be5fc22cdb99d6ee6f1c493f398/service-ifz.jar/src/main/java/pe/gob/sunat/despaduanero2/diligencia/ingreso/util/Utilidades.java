package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import java.text.ParseException;
import java.util.zip.ZipException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.util.WebUtils;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateUtils;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.json.JSONArray;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.framework.spring.util.compression.ZipUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;

import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;


/**
 *
 * Proyecto : despaduanero Clase : Utilidades Descripcion : Servlet encargado de
 * las funcionalidades del Mantenimiento de Mascotas.
 *
 * @author fduartej, rmontes
 * @since 14-sep-09
 * @version 1.0
 *
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class Utilidades
{

  static FechaBean        FEC_DEFA1    = new FechaBean("01/01/0001");

  static FechaBean        FEC_DEFA2    = new FechaBean("01/01/1901");

  private static String[] FORMAT_DATES = new String[]
                                       { "dd/MM/yyyy", "dd/MM/yyyy HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd" };


  //P34 AFMA
  private static final String DEPOSITO_TEMPORAL = "1";
  private static final String DEPOSITO_ADUANERO = "3";

  public static String crearCadenaDesdeObjeto(Object objeto)
  {
    String cadena = "";
    try
    {
      if (objeto instanceof String[])
      {
        cadena = ((String[]) objeto)[0];
      }
      else if (objeto instanceof String)
      {
        cadena = (String) objeto;
      }
      else if (objeto instanceof java.sql.Date)
      {
        cadena = DateUtil.dateToString((java.sql.Date) objeto, "dd/MM/yyyy");
      }
      else if (objeto instanceof java.util.Date)
      {
        cadena = DateUtil.dateToString((java.util.Date) objeto, "dd/MM/yyyy");
      }
      else if (objeto == null)
      {
        cadena = "";
      }
      else
      {
        cadena = objeto.toString();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      cadena = "";
    }
    return cadena;
  }

  public static Object obtenerObjetoDesdeMapa(Map<String, Object> params, String key)
  {
    Object objeto = new Object();
    if (params.containsKey(key))
    {
      objeto = params.get(key);
    }
    else if (params.containsKey(key.toUpperCase()))
    {
      objeto = params.get(key.toUpperCase());
    }
    else if (params.containsKey(key.toLowerCase()))
    {
      objeto = params.get(key.toLowerCase());
    }
    else
    {
      Set<String> keySet = params.keySet();
      for (String keyParams : keySet)
      {
        if (StringUtils.contains(keyParams.toLowerCase(), key.toLowerCase()))
        {
          objeto = params.get(keyParams);
          break;
        }
      }
    }
    return objeto;
  }

  public static Object crearObjetoDesdeCadena(String cadena, Object objeto)
  {
    Object valorNuevo = null;
    try
    {
      if (objeto instanceof BigDecimal)
      {
        cadena = StringUtils.defaultIfEmpty(cadena, "0");
        valorNuevo = new BigDecimal(cadena);
      }
      else if (objeto instanceof BigInteger)
      {
        cadena = StringUtils.defaultIfEmpty(cadena, "0");
        valorNuevo = new BigInteger(cadena);
      }
      else if (objeto instanceof java.sql.Timestamp)
      {
        FechaBean fechaBean = new FechaBean(cadena, "yyyy-MM-dd");
        valorNuevo = fechaBean.getTimestamp();
      }
      else if (objeto instanceof java.sql.Date)
      {
        FechaBean fechaBean = new FechaBean(cadena, "yyyy-MM-dd");
        valorNuevo = fechaBean.getSQLDate();
      }
      else if (objeto instanceof java.util.Date)
      {
        valorNuevo = DateUtil.stringToDate(cadena, "yyyy-MM-dd");
      }
      else if (objeto instanceof String)
      {
        valorNuevo = cadena;
      }
      else
      {
        valorNuevo = cadena;
      }
    }
    catch (ParseException pe)
    {
      valorNuevo = null;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return valorNuevo;
  }

  public static final Map<String, Object> obtenerElemento(List<Map<String, Object>> lstEval, Map<String, Object> keys)
  {
    Map res = null;

    boolean booFound;
    String valor;
    if (lstEval != null && lstEval.size() > 0)
      for (Map<String, Object> elemento : lstEval)
      {
        booFound = true;
        for (Entry<String, Object> valores : keys.entrySet())
        {
          valor = (valores.getValue() != null ? valores.getValue().toString().trim() : "") + "diferente";
          if (elemento.get(valores.getKey().toString()) != null)
          {
            valor = elemento.get(valores.getKey().toString()).toString().trim();
          }
          else if (elemento.get(valores.getKey().toString().toUpperCase()) != null)
          {
            valor = elemento.get(valores.getKey().toString().toUpperCase()).toString().trim();
          }
          else if (elemento.get(valores.getKey().toString().toLowerCase()) != null)
          {
            valor = elemento.get(valores.getKey().toString().toLowerCase()).toString().trim();
          }
          if (!valores.getValue().toString().trim().equals(valor))
          {
            booFound = false;
            break;
          }
        }

        if (booFound)
        {
          res = elemento;
          break;
        }
      }

    return res;
  }

  //rtineo mejoras
  public static final Map<String, Object> obtenerElementoNew(Map<String,Map<String, Object>> lstEval, Map<String, Object> keys)
  {
    Map res = null;
    String claveFormB="";
    String num_secitemFormB="";
    String cod_mercanciaitemFormB="";
    String num_secfactFormB="";
    String cod_tipdescFormB="";
    String num_secproveFormB="";
    if (lstEval != null && lstEval.size() > 0){
		num_secitemFormB = keys.get("NUM_SECITEM").toString();
		cod_mercanciaitemFormB = keys.get("COD_MERCANCIA").toString();
		//PAS20155E220200139 no son pk
		//num_secfactFormB = keys.get("NUM_SECFACT").toString();
		cod_tipdescFormB = keys.get("COD_TIPDESC").toString();
		//num_secproveFormB  =keys.get("NUM_SECPROVE").toString();
		claveFormB = num_secitemFormB.concat("-").concat(cod_mercanciaitemFormB)
				//.concat("-").concat(num_secfactFormB)
				.concat("-").concat(cod_tipdescFormB);
				//.concat("-").concat(num_secproveFormB);
		res = lstEval.get(claveFormB);
		//PAS20155E220200139
    }

    return res;
  }
  
  public static final Map<String,Object> obtenerElementoItemFormatoB(Map<String, Object> lstEval, Map<String, Object> keys){
	  Map res = null;
	  String claveFormB="";
	  if(lstEval != null && lstEval.size() > 0){
		  claveFormB = keys.get("NUM_SECITEM").toString();
		  res = (Map)lstEval.get(claveFormB);
	  }
	  return res;
	  
  }
  //fin rtineo mejoras
  /**
   * Copia los elementos de una lista retornandolos en otra lista.
   *
   * @param lstOriginal
   *          the lst original
   * @return the list
   */
  public static final List copiarLista(List<Map> lstOriginal)
  {
    List res = null;

    if (lstOriginal != null && lstOriginal.size() > 0)
    {
      res = new ArrayList();
      for (Map elemento : lstOriginal)
      {
        Map copia = new HashMap();

        for (Object key : elemento.keySet())
        {
          Object dato;
          if (elemento.get(key.toString().trim()) instanceof Map)
          {
            dato = copiarMapa((HashMap) elemento.get(key.toString().trim()));
          }
          else
          {
            dato = elemento.get(key.toString().trim());
          }
          copia.put(key.toString().trim(), dato);
        }
        res.add(copia);
      }
    }

    return res;
  }

  /**
   * Permite copiar los datos de un mapa devolviendo otro Mapa.
   *
   * @param mapOriginal
   *          the map original
   * @return the map
   */
  public static final Map copiarMapa(Map mapOriginal)
  {
    Map res = null;

    if (mapOriginal != null && mapOriginal.size() > 0)
    {
      res = new HashMap();
      for (Object key : mapOriginal.keySet())
      {
        Object dato;
        if (mapOriginal.get(key.toString().trim()) instanceof List)
        {
          dato = copiarLista((ArrayList<Map>) mapOriginal.get(key.toString().trim()));
        }
        else if (mapOriginal.get(key.toString().trim()) instanceof Map)
        {
          dato = copiarMapa((HashMap) mapOriginal.get(key.toString().trim()));
        }
        else
        {
          dato = mapOriginal.get(key.toString().trim());
        }
        res.put(key.toString().trim(), dato);
      }
    }

    return res;
  }

  /** RTINEO
   * Permite copiar los datos de un mapa devolviendo otro Mapa con keys solo String
   *
   * @param mapOriginal
   *          the map original
   * @return the map
   */
  public static final Map copiarMapaConValueString(Map mapOriginal)
  {
    Map res = null;

    if (mapOriginal != null && mapOriginal.size() > 0)
    {
      res = new HashMap();
      for (Object key : mapOriginal.keySet())
      {
        Object dato;
        if (mapOriginal.get(key.toString().trim()) instanceof List)
        {
          dato = new ArrayList();
        }
        else if (mapOriginal.get(key.toString().trim()) instanceof Map)
        {
          dato = new HashMap();
        }
        else
        {
          dato = mapOriginal.get(key.toString().trim());
        }
        res.put(key.toString().trim(), dato);
      }
    }

    return res;
  }
  
  /**
   * Adaptar parametros bd.
   *
   * @param params
   *          the params
   * @return the map
   */
  public static final Map<String, Object> adaptarParametrosBD(Map<String, Object> params)
  {
    Map<String, Object> mapNuevo = new HashMap<String, Object>();
    for (String key : params.keySet())
    {
      mapNuevo.put(key.toUpperCase(), params.get(key));
    }
    return mapNuevo;
  }

  /**
   * Adaptar parametros bd.
   *
   * @param params
   *          the params
   * @return the list
   */
  public static final List<Map<String, Object>> adaptarParametrosBD(List<Map<String, Object>> params)
  {
    List<Map<String, Object>> lstNew = new ArrayList<Map<String, Object>>();
    for (Map<String, Object> mapa : params)
    {
      lstNew.add(adaptarParametrosBD(mapa));
    }

    return lstNew;
  }

  public static Map<String, Object> ponerObjetoAMapa(Map<String, Object> params, Object objeto, String key)
  {
    if (params.containsKey(key))
    {
      params.put(key, objeto);
    }
    else if (params.containsKey(key.toUpperCase()))
    {
      params.put(key.toUpperCase(), objeto);
    }
    else if (params.containsKey(key.toLowerCase()))
    {
      params.put(key.toLowerCase(), objeto);
    }
    else
    {
      Set<String> keySet = params.keySet();
      for (String keyParams : keySet)
      {
        if (StringUtils.contains(keyParams.toLowerCase(), key.toLowerCase()))
        {
          params.put(keyParams, objeto);
          break;
        }
      }
    }
    return params;
  }

  /**
   * Es numerico.
   *
   * @param valor
   *          the valor
   * @return true, if successful
   */
  public static final boolean esNumerico(String valor)
  {

    if ("".equals(valor.trim()))
    {
      return false;
    }
    else
    {
      try
      {
        Long.parseLong(valor);
        return true;
      }
      catch (Exception e)
      {
        try
        {
          Double.parseDouble(valor);
          return true;
        }
        catch (Exception ex)
        {
          return false;
        }
      }
    }
  }

  /* INICIO-PAS20124E600000358 */
  /**
   * Equals by class.
   *
   * @param val1
   *          the val1
   * @param val2
   *          the val2
   * @return true, if successful
   */
  public static final boolean equalsByClass(Object val1, Object val2){
    if (val1 instanceof Integer){
      boolean evaluar = false;
      if (val2  instanceof Integer){
        evaluar = true;
      } else {
        try{
          new Integer(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new Integer(val1.toString().trim())).equals(new Integer(val2.toString().trim())));
      }
    }

    if (val1 instanceof Long){
      boolean evaluar = false;
      if (val2  instanceof Long){
        evaluar = true;
      } else {
        try{
          new Long(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new Long(val1.toString().trim())).equals(new Long(val2.toString().trim())));
      }
    }

    if (val1 instanceof BigInteger){
      boolean evaluar = false;
      if (val2  instanceof BigInteger){
        evaluar = true;
      } else {
        try{
          new BigInteger(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new BigInteger(val1.toString().trim())).equals(new BigInteger(val2.toString().trim())));
      }
    }

    if (val1 instanceof Double){
      boolean evaluar = false;
      if (val2 instanceof Double){
        evaluar = true;
      } else {
        try{
          new Double(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new Double(val1.toString().trim())).compareTo(new Double(val2.toString().trim())) == 0);
      }
    }

    if (val1 instanceof Float){
      boolean evaluar = false;
      if (val2 instanceof Float){
        evaluar = true;
      } else {
        try{
          new Float(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new Float(val1.toString().trim())).compareTo(new Float(val2.toString().trim())) == 0);
      }
    }

    if (val1 instanceof BigDecimal){
      boolean evaluar = false;
      if (val2 instanceof BigDecimal){
        evaluar = true;
      } else {
        try{
          new BigDecimal(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        return ((new BigDecimal(val1.toString().trim())).compareTo(new BigDecimal(val2.toString().trim())) == 0);
      }
    }
    if (val1 instanceof Date){
      boolean evaluar = false;
      if (val2 instanceof Date){
        evaluar = true;
      } else {
        try{
          new FechaBean(val2.toString().trim());
          evaluar = true;
        }catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        FechaBean valComp = new FechaBean(val2.toString().trim());

        return (!(FEC_DEFA1.getSQLDate().equals(valComp.getSQLDate()) ||
                FEC_DEFA2.getSQLDate().equals(valComp.getSQLDate())) &&
                (((Date) val1).equals(valComp.getSQLDate())));
      }
    }

    if (val1 instanceof java.util.Date){

       return SunatDateUtils.sonIguales((java.util.Date)val1, toDate(val2),SunatDateUtils.COMPARA_SOLO_FECHA);
    }
//PASE604
    String valorStr1 = val1.toString().trim();
    String valorStr2 = (val2!=null?val2.toString().trim():"");
    if (val1 instanceof Timestamp || (valorStr1.length() > 15 && valorStr1.substring(4, 5).equals("-") && valorStr1.substring(7, 8).equals("-") && valorStr1.substring(13, 14).equals(":"))) {

      FechaBean fecVal1 = new FechaBean();
      FechaBean fecVal2 = new FechaBean();
      boolean evaluar = false;
      if (val1 instanceof Timestamp){
        fecVal1 = new FechaBean(valorStr1, "yyyy-MM-dd");
        evaluar = true;
      } else {
        try{
          fecVal1 = new FechaBean(val1.toString().trim(), "yyyy-MM-dd hh:mm:ss");
          evaluar = true;
        } catch(Exception e){
          evaluar = false;
        }
      }

      if (evaluar){
        if (val2 instanceof Timestamp){
          // fecVal2 = new FechaBean((Timestamp) val2);
          fecVal2 = new FechaBean(valorStr2, "yyyy-MM-dd"); // lo ponemos a fecha pq en
                                    // realidad solo deberia de
                                    // compara fechas no horas
          evaluar = true;
        } else {
          try{
            fecVal2 = new FechaBean(val2.toString().trim(), "yyyy-MM-dd hh:mm:ss");
            evaluar = true;
          }catch(Exception e){
            evaluar = false;
          }
        }

        if (evaluar){

          if ((FEC_DEFA1.getTimestamp().equals(fecVal2.getTimestamp()) || FEC_DEFA2.getTimestamp().equals(fecVal2.getTimestamp()))
              && (FEC_DEFA1.getTimestamp().equals(fecVal1.getTimestamp()) || FEC_DEFA2.getTimestamp().equals(fecVal1.getTimestamp())))
            return true;

          return (!(FEC_DEFA1.getTimestamp().equals(fecVal2.getTimestamp()) || FEC_DEFA2.getTimestamp().equals(fecVal2.getTimestamp())) && (fecVal1.getTimestamp().equals(fecVal2
              .getTimestamp())));
        }
      }

    }

    if(val2==null)
      return false;
    else
      return (val1.toString().trim().equalsIgnoreCase(val2.toString().trim()));

  }

  /**
   * Parses the date.
   *
   * @param strFecha
   *          the str fecha
   * @param strFormatoFecha
   *          the str formato fecha
   * @return the java.util. date
   */
  public static java.util.Date parseDate(String strFecha, String strFormatoFecha)
  {

    DateFormat formato = new SimpleDateFormat(strFormatoFecha);
    try
    {
      java.util.Date fecha = (java.util.Date) formato.parse(strFecha);
      return fecha;
    }
    catch (Exception e)
    {
      e.getMessage();
    }

    return null;

  }

  /**
   * To collection.
   *
   * @param val1
   *          the val1
   * @param val2
   *          the val2
   * @return the list
   */
  public static final List<Map<String, Object>> toCollection(JSONArray val1, Class val2)
  {
    List<Map<String, Object>> lst = (List<Map<String, Object>>) JSONArray.toCollection(val1, val2);
    List<Map<String, Object>> lstRet = new ArrayList<Map<String, Object>>();
    Map<String, Object> mapRes;
    if (lst != null)
    {
      for (int i = 0; i < lst.size(); i++)
      {
        Map<String, Object> mp = (Map<String, Object>) lst.get(i);
        mapRes = new HashMap<String, Object>();
        for (Entry<String, Object> entr : mp.entrySet())
        {
          if (entr.getValue().toString().equals("null"))
            entr.setValue(null);
          mapRes.put(entr.getKey(), entr.getValue());
        }
        lstRet.add(mapRes);
      }
    }

    return lstRet;
  }

  /**
   * List to map.
   *
   * @param lstEval
   *          the lst eval
   * @param cmpKey
   *          the cmp key
   * @param cmpValue
   *          the cmp value
   * @param defaultValue
   *          the default value
   * @return the map
   */
  public static Map<String, Object> listToMap(List lstEval, String cmpKey, String cmpValue, Object defaultValue)
  {
    Map<String, Object> res = new HashMap<String, Object>();

    if (lstEval != null && lstEval.size() > 0)
    {
      Map<String, Object> row;
      for (int i = 0; i < lstEval.size(); i++)
      {
        row = (HashMap<String, Object>) lstEval.get(i);
        if (StringUtils.isBlank((String) row.get(cmpKey)))
        {
          continue;
        }
        Object value = row.get(cmpValue);
        if (value == null)
        {
          value = defaultValue;
        }
        res.put(row.get(cmpKey).toString().trim(), value);
      }
    }

    return res;
  }

  public static String obtenerCadenaDesdeMapa(Map<String, Object> params, String key)
  {
    String res = "";
    if (params.containsKey(key))
    {
      res = params.get(key).toString();
    }
    else if (params.containsKey(key.toUpperCase()))
    {
      res = params.get(key.toUpperCase()).toString();
    }
    else if (params.containsKey(key.toLowerCase()))
    {
      res = params.get(key.toLowerCase()).toString();
    }
    else
    {
      Set<String> keySet = params.keySet();
      for (String keyParams : keySet)
      {
        if (StringUtils.contains(keyParams.toLowerCase(), key.toLowerCase()))
        {
          res = params.get(keyParams).toString();
          break;
        }
      }
    }
    return res;
  }

  /**
   * autor: amancillaa
   * Limpia las variables de session:
   * diligencia de despacho.
   * Rectificaion Oficio.
   * Rectificacion Electronica.
   * Conclusion de Despacho.
   * Regularizacion.
   * mapCabDeclara : contiene la DECLARACION Y DEPENDENCIAS SIN modificaciones.
   * mapCabDeclaraActual    : contiene la DECLARACION Y DEPENDENCIAS CON modificaciones.
   * mapCabDiligencia       : contiene la DILEGENCIA a registrar a BD.
   * tipoDiligencia         : contiene tipo de diligencia.
   * lstDetDeclara          : contiene la SERIE SIN modificaciones.
   * lstDetDeclaraActual    : contiene la SERIE CON modificaciones realizadas durante la SESSION del USUARIO.
   * lstIncidencias         : contiene la lista de INCIDENCIAS generadas en la diligencia.
   * lstMultaDua            : contiene la lista de MULTAS generadas en la diligencia.
   * lstMultaDuaActual      : ????
   * listadoMultas          : ????
   * mapNuevaSerieSerieBase : contiene la relacion SERIE-NUEVA, SERIE-BASE.
   * first_time_CO          : ????
   * lstFacturasSerieActual : contiene la FACTURA-SERIE CON modificaciones.
   * declaracion            : contiene la DECLARACION datos personalizados.
   * cAduana                : contiene el codigo de aduana del usuario en SESSION
   * dataConstante          : contiene datos de la CONSTANTE.
   * resValidacion          : contiene si los datos de la SERIE son validos al GRABAR en SESSION.
   * lstSeriesItem          : contiene los datos de la relacion SERIE-ITEM originales.
   * lstSeriesItemActual    : contiene los datos de la relacion SERIE-ITEM modificados.
   * detDeclara             : contiene el detalle de las SERIE en SESSIOn
   * lstItemFactura         : contiene los datos originales de ITEMFACTURA
   * lstSeriesAsociadas :
   *
   * @param request
   */
  public static void limpiarMapasSesion(HttpServletRequest request)
  {
    HttpSession session = request.getSession();

    // DespachoController,DiligenciaController,LiquidacionController,RectificacionController
    session.removeAttribute("mapCabDeclara");
    session.removeAttribute("mapCabDeclaraActual");

    session.removeAttribute("mapCabDiligencia");
    // para mostrar datos
    // particulares segun el tipo
    session.removeAttribute("tipoDiligencia");

    session.removeAttribute("lstDetDeclara");
    session.removeAttribute("lstDetDeclaraActual");
    session.removeAttribute("lstIncidencias");
    // MultaController
    session.removeAttribute("lstMultaDua");
    session.removeAttribute("lstMultaDuaActual");
    session.removeAttribute("listadoMultas");

    // consulta DVItem
    // (pantalla SERIE)
    session.removeAttribute("mapNuevaSerieSerieBase");
    // cargarMantCertOrigen
    session.removeAttribute("first_time_CO");
    // mantenimiento de
    // facturas serie
    // (pantalla SERIE)
    session.removeAttribute("lstFacturasSerieActual");
    // datos de la DUA para pintar JSP
    session.removeAttribute("declaracion");
    // datos del codigo de aduanas del
    session.removeAttribute("cAduana");
    // datos del codigo de aduanas del
    // usuario
    // validacion de la serie al
    // momento de grabar
    session.removeAttribute("resValidacion");
    // se creo en Mant SERIE-ITEM
    session.removeAttribute("lstSeriesItem");
    // se creo en Mant
    // SERIE-ITEM
    session.removeAttribute("lstSeriesItemActual");
    // DespachoController
    // obtenerDetalleSerie()
    session.removeAttribute("detDeclara");
    // DespachoController
    // cargarFormatoBItem()
    session.removeAttribute("lstItemFactura");
    // DespachoController
    // cargarDetalleFormatoBItem()
    session.removeAttribute("lstSeriesAsociadas");
  //CU 14.20 
    session.removeAttribute("lstItemFacturaActual");
    session.removeAttribute("lstItemsDisponibles");
    session.removeAttribute("lstItemsSerie");
    session.removeAttribute("lstCorrelacionTemporal");
    session.removeAttribute("lstDetDeclaraActualBack");
    session.removeAttribute("lstSeriesCorrelacion");
    session.removeAttribute("flgPaginaSerieCorrelacion");
  //fin CU 14.20
    
    // RectificacionController
    session.removeAttribute("NUM_CORREDOC_PRE"); // validarDeclaParaRectificacion()
    session.removeAttribute("INDICADOR_SELECCION"); // mostrarRegistroResultadoRectificaciones()
    session.removeAttribute("mapResultado"); // obtenerResultado()
    session.removeAttribute("lstDocuPreceDua");
    session.removeAttribute("lstDocuPreceDuaActual");
    session.removeAttribute("CabDeclaraMap");
    session.removeAttribute("CabDeclaraMapActual");
    session.removeAttribute("lstFacturasSerie"); // cargarMantFactura()

    // RectificacionOficioController
    session.removeAttribute("arrayDUA");
    session.removeAttribute("arraySERIE");
    session.removeAttribute("arrayDOCASOCIADOS");
    session.removeAttribute("arrayDETAUTORIZACION");
    session.removeAttribute("mapDatosRectificados");
    session.removeAttribute("arrayCertOrigen");
    session.removeAttribute("arrayFacturas");
    session.removeAttribute("arrayFacturaSerie");
    session.removeAttribute("codIncidenciasAuto");
    session.removeAttribute("codMultasAuto");

    session.removeAttribute("dataIniRecti");
    session.removeAttribute("arrayDocAsociados");
    session.removeAttribute("arrayRegPrecedencia");
    session.removeAttribute("arrayDav");
    session.removeAttribute("arrayFactura");
    session.removeAttribute("arrayItemFactura");
    session.removeAttribute("arraySeriesItem");
    session.removeAttribute("arrayDatosRectificados");
    session.removeAttribute("listExpediente");
    session.removeAttribute("dataIniModifica");
    session.removeAttribute("dataIniRechazo");
    session.removeAttribute("dataIniRecti");
    session.removeAttribute("dataIniRecupera");
    session.removeAttribute("lstMultas");

    session.removeAttribute("mapCabAdiDiligVinc");

    //pase153

    session.removeAttribute("lstDocTransporteProrratear");
    
    //P21 P22 amancillla
    session.removeAttribute("generarLC010");
    session.removeAttribute("resolucionTributo");
    session.removeAttribute("tributosLiquidaciones");
    session.removeAttribute("totalTributosLiquidaciones");

    //Inicio  P34- 3014
    session.removeAttribute("declaracionInicialBean");
    session.removeAttribute("formatoBCargado");
    session.removeAttribute("incidenciasAuto");
    session.removeAttribute("incidenciasManu");
    session.removeAttribute("lstIncidencias");
    session.removeAttribute("lstIncidenciasManuales");


    //fin P34

  }

  /**
   * Inicializa las variables de session en NULL: diligencia de despacho.
   * Rectificaion Oficio. Rectificacion Electronica. Conclusion de Despacho.
   * Regularizacion.
   *
   * @param request
   *          the request
   */
  public static void inicializarMapasSesion(HttpServletRequest request)
  {

    WebUtils.setSessionAttribute(request, "mapCabDeclara", null);
    WebUtils.setSessionAttribute(request, "mapCabDeclaraActual", null);
    WebUtils.setSessionAttribute(request, "tipoDiligencia", null);
    WebUtils.setSessionAttribute(request, "mapCabDiligencia", null);
    WebUtils.setSessionAttribute(request, "lstDetDeclara", null);
    WebUtils.setSessionAttribute(request, "lstDetDeclaraActual", null);

    WebUtils.setSessionAttribute(request, "lstIncidencias", null);

    WebUtils.setSessionAttribute(request, "lstMultaDua", null);
    WebUtils.setSessionAttribute(request, "lstMultaDuaActual", null);
    WebUtils.setSessionAttribute(request, "listadoMultas", null);

    WebUtils.setSessionAttribute(request, "lstDocuPreceDua", null);
    WebUtils.setSessionAttribute(request, "lstDocuPreceDuaActual", null);
    WebUtils.setSessionAttribute(request, "lstFacturasSerie", null);
    WebUtils.setSessionAttribute(request, "lstFacturasSerieActual", null);
    WebUtils.setSessionAttribute(request, "mapNuevaSerieSerieBase", null);

    WebUtils.setSessionAttribute(request, "declaracion", null);
    WebUtils.setSessionAttribute(request, "cAduana", null);
    WebUtils.setSessionAttribute(request, "resValidacion", null);

    WebUtils.setSessionAttribute(request, "lstSeriesItem", null);
    WebUtils.setSessionAttribute(request, "lstSeriesItemActual", null);

    WebUtils.setSessionAttribute(request, "detDeclara", null);
    WebUtils.setSessionAttribute(request, "lstItemFactura", null);
    WebUtils.setSessionAttribute(request, "lstSeriesAsociadas", null);
    WebUtils.setSessionAttribute(request, "NUM_CORREDOC_PRE", null);

    WebUtils.setSessionAttribute(request, "INDICADOR_SELECCION", null);
    WebUtils.setSessionAttribute(request, "mapResultado", null);
    WebUtils.setSessionAttribute(request, "CabDeclaraMap", null);

    WebUtils.setSessionAttribute(request, "CabDeclaraMapActual", null);
    WebUtils.setSessionAttribute(request, "lstFacturasSerie", null);
    WebUtils.setSessionAttribute(request, "arrayDUA", null);
    WebUtils.setSessionAttribute(request, "arraySERIE", null);
    WebUtils.setSessionAttribute(request, "arrayDOCASOCIADOS", null);
    WebUtils.setSessionAttribute(request, "arrayDETAUTORIZACION", null);
    WebUtils.setSessionAttribute(request, "mapDatosRectificados", null);
    WebUtils.setSessionAttribute(request, "arrayCertOrigen", null);
    WebUtils.setSessionAttribute(request, "arrayFacturas", null);
    WebUtils.setSessionAttribute(request, "codIncidenciasAuto", null);
    WebUtils.setSessionAttribute(request, "codMultasAuto", null);

    WebUtils.setSessionAttribute(request, "dataIniRecti", null);
    WebUtils.setSessionAttribute(request, "arrayCONTENEDOR", null);
    WebUtils.setSessionAttribute(request, "arrayDocAsociados", null);
    WebUtils.setSessionAttribute(request, "arrayRegPrecedencia", null);
    WebUtils.setSessionAttribute(request, "arrayDav", null);
    WebUtils.setSessionAttribute(request, "arraySeriesItem", null);
    WebUtils.setSessionAttribute(request, "arrayIndicadorDUA", null);
    WebUtils.setSessionAttribute(request, "arrayFacturaFormA", null);
    WebUtils.setSessionAttribute(request, "arrayDatosRectificados", null);
    WebUtils.setSessionAttribute(request, "first_time_CO", null);
    WebUtils.setSessionAttribute(request, "arrayMontoGasto", null);
    WebUtils.setSessionAttribute(request, "arrayFormbMonto", null);

    WebUtils.setSessionAttribute(request, "arrayFactura", null);
    WebUtils.setSessionAttribute(request, "arrayItemFactura", null);
    WebUtils.setSessionAttribute(request, "arrayParticipante", null);
    WebUtils.setSessionAttribute(request, "arrayFacturaSerie", null);
    WebUtils.setSessionAttribute(request, "arrayFinUbicacion", null);
    WebUtils.setSessionAttribute(request, "arrayCondicionTransa", null);
    WebUtils.setSessionAttribute(request, "arrayCabAdiImpoConsu", null);
    WebUtils.setSessionAttribute(request, "arrayVehiCetivo", null);
    WebUtils.setSessionAttribute(request, "arrayFactuSuce", null);
    WebUtils.setSessionAttribute(request, "arrayFormbItemDescri", null);


    //pase153
    WebUtils.setSessionAttribute(request, "lstDocTransporteProrratear", null);
	//inicio EJHM
   WebUtils.setSessionAttribute(request, "params", null);
   //fin EJHM
   
   //Inicio P34 3014
   WebUtils.setSessionAttribute(request, "declaracionInicialBean", null);
    WebUtils.setSessionAttribute(request, "formatoBCargado", false);
    WebUtils.setSessionAttribute(request, "incidenciasAuto", null);
    WebUtils.setSessionAttribute(request, "incidenciasManu", null);
    WebUtils.setSessionAttribute(request, "lstIncidencias", null);
    WebUtils.setSessionAttribute(request, "lstIncidenciasManuales", null);

   //fin P34

    //P21 P22 amancillla
    WebUtils.setSessionAttribute(request,"generarLC010", null);
    WebUtils.setSessionAttribute(request, "resolucionTributo", null);
    WebUtils.setSessionAttribute(request, "tributosLiquidaciones", null);
    WebUtils.setSessionAttribute(request, "totalTributosLiquidaciones", null);


  }

  /**
   * Metodo que recupera la fecha habil.
   *
   * @param FechaIn
   *          La fecha de entrada para calcular la fecha habil
   * @param Dias
   *          Numero de dias habiles
   * @return return fecha en formato dd/mm/yyyy
   */
  public static java.util.Date addUtilDay(String FechaIn, int Dias)
  {

    Locale _currentLocale = new Locale("es", "PE");

    int TotalDias = 0;

    TotalDias = getDateHabiles(FechaIn, Dias);
    int iYear = Integer.parseInt(FechaIn.substring(6, 10));
    int iMonth = Integer.parseInt(FechaIn.substring(3, 5));
    int iDay = Integer.parseInt(FechaIn.substring(0, 2));
    Calendar cldInicio = Calendar.getInstance(_currentLocale);
    cldInicio.setFirstDayOfWeek(Calendar.MONDAY);
    cldInicio.set(iYear, iMonth - 1, iDay);

    Calendar cldFin = Calendar.getInstance(_currentLocale);
    cldFin.setFirstDayOfWeek(Calendar.MONDAY);
    cldFin.set(iYear, iMonth - 1, iDay);

    cldFin.add(Calendar.DATE, TotalDias);

    java.util.Date d = cldFin.getTime();

    FechaBean fb = new FechaBean();
    fb.setFecha(d);
    Calendar cal = Calendar.getInstance();
    cal.setTime(d);

    return cal.getTime();
  }


  /**
   * Metodo que recuperara la fecha final despues de ver los dias nohabiles.
   *
   * @param FechaIni
   *          Cadena con la fecha a calcular los dias inhabiles
   * @param Dias
   *          Numero de dias habiles a sumar
   * @return una Fecha con formato dd-mm-yyyy
   */
  private static int getDateHabiles(String FechaIni, int Dias)
  {

    Locale _currentLocale = new Locale("es", "PE");

    int countd = 0;
    int contapasadas = 0;
    int iYear = Integer.parseInt(FechaIni.substring(6, 10));
    int iMonth = Integer.parseInt(FechaIni.substring(3, 5));
    int iDay = Integer.parseInt(FechaIni.substring(0, 2));
    Calendar cldInicio = Calendar.getInstance(_currentLocale);
    cldInicio.setFirstDayOfWeek(Calendar.MONDAY);
    // declaro variables para la obtencion del dia de la semana
    // hacemos el recorrido de todos los dias quitando los sabados y domingos
    while (Dias >= countd)
    {
      contapasadas++;
      cldInicio.set(iYear, iMonth - 1, iDay);
      countd++; // se le suma uno al contador del while
      iDay++; // se le suma uno al dia para recorrerlo no importa el numero que
              // sea en la semana
    }

    return contapasadas - 1;
  }

  /**
   * Transformar rectificado a item consulta.
   *
   * @param jsonRectificado
   *          the json rectificado
   * @return the list
   */
  public static List<Map> transformarRectificadoAItemConsulta(String jsonRectificado)
  {
    return transformarRectificadoAItemConsulta(jsonRectificado, new HashMap<String, String>(), false);
  }

  /**
   * Transformar rectificado a item consulta.
   *
   * @param jsonRectificado
   *          the json rectificado
   * @param iskeynecesary
   *          the iskeynecesary
   * @return the list
   */
  public static List<Map> transformarRectificadoAItemConsulta(String jsonRectificado, boolean iskeynecesary)
  {
    return transformarRectificadoAItemConsulta(jsonRectificado, new HashMap<String, String>(), iskeynecesary);
  }

  /**
   * Transformar rectificado a item consulta.
   *
   * @param jsonRectificado
   *          the json rectificado
   * @param equivalencias
   *          the equivalencias
   * @return the list
   */
  public static List<Map> transformarRectificadoAItemConsulta(String jsonRectificado, Map<String, String> equivalencias)
  {
    return transformarRectificadoAItemConsulta(jsonRectificado, equivalencias, false);
  }

  /**
   * Transformar rectificado a item consulta.
   *
   * @param jsonRectificado
   *          the json rectificado
   * @param equivalencias
   *          the equivalencias
   * @param iskeynecesary
   *          the iskeynecesary
   * @return the list
   */
  public static List<Map> transformarRectificadoAItemConsulta(
    String jsonRectificado,
    Map<String, String> equivalencias,
    boolean iskeynecesary)
  {
    List<Map> listRectificado = null;
    List<Map> listItemColumna = new ArrayList<Map>();
    if (StringUtils.isEmpty(jsonRectificado))
      return listItemColumna;
    if (equivalencias == null)
      return listItemColumna;
    if (!StringUtils.isEmpty(jsonRectificado))
    {
      listRectificado = (List<Map>) SojoUtil.fromJson(jsonRectificado);
    }
    if (CollectionUtils.isEmpty(listRectificado))
      return listItemColumna;
    Collections.sort(listRectificado, new Comparator<Map>()
    {
      @Override
      public int compare(Map thiss, Map that)
      {
        String keyThiss = thiss.get("COD_TABLA").toString() + thiss.get("NUM_SECCAMBIO").toString();
        String keyThat = that.get("COD_TABLA").toString() + that.get("NUM_SECCAMBIO").toString();
        return keyThiss.compareTo(keyThat);
      }
    });
    String keyDetSolRecti = "";
    Map newItem = null;
    String campo = "";
    for (Map item : listRectificado)
    {
      if (!"N".equals(item.get("IND_RECTIFICA")))
        continue;
      if (keyDetSolRecti.equals(item.get("COD_TABLA").toString() + item.get("NUM_SECCAMBIO").toString()))
      {
        campo = equivalencias.containsKey(item.get("CAMPO").toString()) ?
            equivalencias.get(item.get("CAMPO").toString()) : item.get("CAMPO").toString();
        newItem.put(campo, item.get("VALOR2R"));
        try
        {
          newItem.putAll((Map) SojoUtil.fromJson(ObjectUtils.toString(item.get("VALOR2R"), "[]")));
        }
        catch (Exception e)
        {
        }
      }
      else
      {
        if (!SunatStringUtils.isEmptyTrim(keyDetSolRecti))
        {
          listItemColumna.add(newItem);
        }
        newItem = new HashMap();
        newItem.put("COD_TABLA", item.get("COD_TABLA"));
        newItem.put("NUM_SECCAMBIO", item.get("NUM_SECCAMBIO"));
        newItem.put("IND_RECTIFICA", item.get("IND_RECTIFICA"));
        campo = equivalencias.containsKey(item.get("CAMPO").toString()) ?
            equivalencias.get(item.get("CAMPO").toString()) : item.get("CAMPO").toString();
        newItem.put(campo, item.get("VALOR2R"));
        try
        {
          newItem.putAll((Map) SojoUtil.fromJson(ObjectUtils.toString(item.get("VALOR2R"), "[]")));
        }
        catch (Exception e)
        {
        }
        if (iskeynecesary)
        {
          Map<String, Object> keyneed = (Map<String, Object>) SojoUtil.fromJson(item.get("DES_CLAVE").toString());
          newItem.putAll(keyneed);
        }
        keyDetSolRecti = item.get("COD_TABLA").toString() + item.get("NUM_SECCAMBIO").toString();
      }
    }
    if (newItem != null && !SunatStringUtils.isEmptyTrim(keyDetSolRecti))
    {
      listItemColumna.add(newItem);
    }
    return listItemColumna;
  }

  /**
   * Transformar rectificado a consulta.
   *
   * @param jsonRectificado
   *          the json rectificado
   * @param equivalencias
   *          the equivalencias
   * @param iskeynecesary
   *          the iskeynecesary
   * @return the list
   */
  public static List<Map> transformarRectificadoAConsulta(
    String jsonRectificado,
    Map<String, String> equivalencias,
    boolean iskeynecesary)
  {
    List<Map> listRectificado = null;
    List<Map> listItemColumna = new ArrayList<Map>();
    if (StringUtils.isEmpty(jsonRectificado))
      return listItemColumna;
    if (equivalencias == null)
      return listItemColumna;
    if (!StringUtils.isEmpty(jsonRectificado))
    {
      listRectificado = (List<Map>) SojoUtil.fromJson(jsonRectificado);
    }
    if (CollectionUtils.isEmpty(listRectificado))
      return listItemColumna;
    Collections.sort(listRectificado, new Comparator<Map>()
    {
      @Override
      public int compare(Map thiss, Map that)
      {
        String keyThiss = thiss.get("COD_TABLA").toString() + thiss.get("NUM_SECCAMBIO").toString();
        String keyThat = that.get("COD_TABLA").toString() + that.get("NUM_SECCAMBIO").toString();
        return keyThiss.compareTo(keyThat);
      }
    });
    String keyDetSolRecti = "";
    Map newItem = null;
    String campo = "";
    for (Map item : listRectificado)
    {

      if (keyDetSolRecti.equals(item.get("COD_TABLA").toString() + item.get("NUM_SECCAMBIO").toString()))
      {
        campo = equivalencias.containsKey(item.get("CAMPO").toString()) ?
            equivalencias.get(item.get("CAMPO").toString()) : item.get("CAMPO").toString();
        newItem.put(campo, item.get("VALORR"));
      }
      else
      {
        if (!SunatStringUtils.isEmptyTrim(keyDetSolRecti))
        {
          listItemColumna.add(newItem);
        }
        newItem = new HashMap();
        newItem.put("COD_TABLA", item.get("COD_TABLA"));
        newItem.put("NUM_SECCAMBIO", item.get("NUM_SECCAMBIO"));
        newItem.put("IND_RECTIFICA", item.get("IND_RECTIFICA"));
        campo = equivalencias.containsKey(item.get("CAMPO").toString()) ?
            equivalencias.get(item.get("CAMPO").toString()) : item.get("CAMPO").toString();
        newItem.put(campo, item.get("VALORR"));
        if (iskeynecesary)
        {
          Map<String, Object> keyneed = (Map<String, Object>) SojoUtil.fromJson(item.get("DES_CLAVE").toString());
          newItem.putAll(keyneed);
        }
        if ("NEW_RECORD".equals(campo))
        {
          Map newRecord = (Map) SojoUtil.fromJson(ObjectUtils.toString(item.get("VALOR2R"), "{}"));
          newItem.putAll(newRecord);
        }
        keyDetSolRecti = item.get("COD_TABLA").toString() + item.get("NUM_SECCAMBIO").toString();
      }
    }
    if (newItem != null && !SunatStringUtils.isEmptyTrim(keyDetSolRecti))
    {
      listItemColumna.add(newItem);
    }
    return listItemColumna;
  }

  /**
   * Transform fields to real format.
   *
   * @param diferencia
   *          the diferencia
   * @return the map
   */
  public static Map<String, Object> transformFieldsToRealFormat(Map<String, Object> diferencia)
  {
    Map<String, Object> row = new HashMap<String, Object>(diferencia);
    java.util.Date fecha = null;
    BigDecimal monto = null;
    Long lmonto = null;
    for (Entry<String, Object> item : row.entrySet())
    {

      if ((item.getValue() == null))
      {
        if (StringUtils.contains(item.getKey(), "FEC_"))
        {
          try
          {
            fecha = DateUtils.parseDate("01/01/0001", FORMAT_DATES);
          }
          catch (ParseException e)
          {
            fecha = SunatDateUtils.getDateFromUnknownFormat("01/01/0001");
          }
          row.put(item.getKey(), fecha);
        }

        if (StringUtils.contains(item.getKey(), "MTO_"))
        {
          row.put(item.getKey(), new Long(0));
        }
        if (StringUtils.contains(item.getKey(), "CNT_"))
        {
          row.put(item.getKey(), new Long(0));
        }
        if (StringUtils.contains(item.getKey(), "COD_"))
        {
          row.put(item.getKey(), " ");
        }
        if (StringUtils.contains(item.getKey(), "DES_"))
        {
          row.put(item.getKey(), " ");
        }
        /* es ambiguo en el modelo hay puede ser number o varchar
        if(StringUtils.contains(item.getKey(), "NUM_")){
          row.put(item.getKey()," ");
        }*/
      }

      // Para el caso de los campos fechas que estan como String deben pasarse a
      // DATE para evitar el ORA-01861
      if ((item.getValue() instanceof String))
      {
    	//Inicio de cambios de pase 192
    	  if( StringUtils.contains(item.getKey(),"COD_TIPMARGEN")){
    		  row.put(item.getKey(), String.valueOf(item.getValue()).trim());
    	  }
    	  //Fin de cambios de pase 192
    	  
        if (StringUtils.contains(item.getKey(), "FEC_") || StringUtils.contains(item.getKey(), "fec_"))
        {
          try
          {
            fecha = DateUtils.parseDate(item.getValue().toString(), FORMAT_DATES);
          }
          catch (ParseException e)
          {
            fecha = SunatDateUtils.getDateFromUnknownFormat(item.getValue().toString());
          }
          row.put(item.getKey(), fecha);
        }


        //amancilla se verifica el tipo para los montos pase 986
        if((StringUtils.contains(item.getKey(), "MTO_") ||
            StringUtils.contains(item.getKey(), "CNT_"))
            && NumberUtils.isNumber(item.getValue().toString()))
        {

          monto = toBigDecimal(item.getValue().toString());
          row.put(item.getKey(), monto);
        }
        if (StringUtils.contains(item.getKey(), "NUM_") && NumberUtils.isDigits(item.getKey()))
        {
          lmonto = toLong(item.getValue().toString());
          row.put(item.getKey(), lmonto);
        }
      }
    }
    return row;
  }

  /**
   * Transform fields null to value default.
   *
   * @param tabla
   *          the tabla
   * @return the map
   */
  public static Map<String, Object> transformFieldsNullToValueDefault(Map<String, Object> tabla)
  {
    Map<String, Object> row = new HashMap<String, Object>(tabla);
    java.util.Date fecha = null;
    for (Entry<String, Object> item : row.entrySet())
    {
      // Para el caso de los campos fechas que estan como String deben pasarse a
      // DATE para evitar el ORA-01861
      if ((item.getValue() == null))
      {
        if (StringUtils.contains(item.getKey(), "FEC_"))
        {
          try
          {
            fecha = DateUtils.parseDate("01/01/0001", FORMAT_DATES);
          }
          catch (ParseException e)
          {
            fecha = SunatDateUtils.getDateFromUnknownFormat("01/01/0001");
          }
          row.put(item.getKey(), fecha);
        }

        if (StringUtils.contains(item.getKey(), "MTO_"))
        {
          row.put(item.getKey(), new Long(0));
        }
        if (StringUtils.contains(item.getKey(), "CNT_"))
        {
          row.put(item.getKey(), new Long(0));
        }
        if (StringUtils.contains(item.getKey(), "COD_"))
        {
          row.put(item.getKey(), " ");
        }
        if (StringUtils.contains(item.getKey(), "DES_"))
        {
          row.put(item.getKey(), " ");
        }
        if (StringUtils.contains(item.getKey(), "NUM_"))
        {
          row.put(item.getKey(), " ");
        }
      }
    }
    return row;
  }

  /**
   * Transform fields to real format.
   *
   * @param diferencia
   *          the diferencia
   * @param soloFecha
   *          the solo fecha
   * @return the map
   */
  public static Map<String, Object> transformFieldsToRealFormat(Map<String, Object> diferencia, boolean soloFecha)
  {
    Map<String, Object> row = new HashMap<String, Object>(diferencia);
    java.util.Date fecha = null;
    for (Entry<String, Object> item : row.entrySet())
    {
      // Para el caso de los campos fechas que estan como String deben pasarse a
      // DATE para evitar el ORA-01861
      if ((item.getValue() instanceof String))
      {
        if (StringUtils.contains(item.getKey().toUpperCase(), "FEC_"))
        {
          try
          {
            fecha = DateUtils.parseDate(item.getValue().toString(), FORMAT_DATES);
          }
          catch (ParseException e)
          {
            fecha = SunatDateUtils.getDateFromUnknownFormat(item.getValue().toString());
          }
          if (fecha != null && soloFecha)
          {
            fecha = DateUtils.truncate(fecha, Calendar.DATE);
          }
          row.put(item.getKey(), fecha);
        }
      }
    }
    return row;
  }

  /**
   * convierte un Objecto a BigDecimal.
   *
   * @param object
   *          the object
   * @return the big decimal
   */
  public static BigDecimal toBigDecimal(Object object)
  {

    if (object instanceof String && SunatStringUtils.isEmpty((String) object))
      return BigDecimal.ZERO;

    if (object == null)
      return BigDecimal.ZERO;

    if (object instanceof String)
    {
      String string = (String) object;
      if (NumberUtils.isNumber(string.trim()))
      {
        return new BigDecimal(string.trim());
      }

    }
    else if (object instanceof BigDecimal)
    {

      BigDecimal bigDecimal = (BigDecimal) object;
      return bigDecimal;

    }
    else if (object instanceof Long)
    {

      return new BigDecimal((Long) object);

    }
    else if (object instanceof Integer)
    {
      return new BigDecimal((Integer) object);

    }
    else if (object instanceof Double)
    {

      return new BigDecimal(object.toString());
    }

    return BigDecimal.ZERO;
  }

  /**
   * To long.
   *
   * @param object
   *          the object
   * @return the long
   */
  public static Long toLong(Object object)
  {
    if (object == null)
      return 0L;

    if (object instanceof String)
    {
      String string = (String) object;
      if (NumberUtils.isDigits(string.trim()))
        return new Long(string.trim());

    }
    else if (object instanceof BigDecimal)
    {

      BigDecimal bigDecimal = (BigDecimal) object;
      return bigDecimal.longValue();

    }
    else if (object instanceof Long)
    {

      return (Long) object;
    }
    else if (object instanceof Integer)
    {

      return new Long((Integer) object);
    }
    else if (object instanceof Double)
    {

      Long num = ((Double) object).longValue();

      return num; // 4.0 convierte 4 & 5.2 -> 5

    }

    return 0L;
  }

  /**
   * Es diligencia despacho.
   *
   * @param tipDilig
   *          the tip dilig
   * @return true, if successful
   */
  public static boolean esDiligenciaDespacho(String tipDilig)
  {

    return Arrays.asList(Constantes.LISTA_DILIGENCIA_DESPACHO).contains(tipDilig);
  }



  /**
   * Compara los datos modificados entre los datos en session y los datos
   * modificados por el usuario
   *
   * @param primerValor valorNuevo
   * @param segundoValor valorOriginal
   * @return boolean (true son iguales)
   */
  public static boolean compararCadenaConObjeto(String primerValor, Object segundoValor)
  {
    boolean flag = false;
    if (segundoValor instanceof BigDecimal)
    {
      flag = primerValor.equals(segundoValor.toString());
    }
    else if (segundoValor instanceof BigInteger)
    {
      flag = primerValor.equals(segundoValor.toString());
    }
    else if (segundoValor instanceof java.sql.Timestamp)
    {
      // amancillaa los valores de fechas '01/01/0001' 01/01/1901 estan
      // reseteados en los JSP'
      if (!StringUtils.isEmpty(primerValor))
      {

        FechaBean fechaBean = new FechaBean(primerValor, "yyyy-MM-dd");
        flag = segundoValor.equals(fechaBean.getTimestamp());
      }
      else
      {
        // para las fechas reseteadas en los JSP
        flag = true; // consideramos que son iguales los datos
      }

    }
    else if (segundoValor instanceof java.sql.Date)
    {
      flag = primerValor.equals(segundoValor.toString());
    }
    else if (segundoValor instanceof java.util.Date)
    {
      flag = primerValor.equals(segundoValor.toString());
    }
    else if (segundoValor instanceof String)
    {
      // se les quita los espacios para comparar en el formulario se esta usando
      // TRIM
      flag = primerValor.trim().equals(((String) segundoValor).trim());
    }
    else if (segundoValor == null)
    {
      flag = false;
    }
    else
    {
      flag = primerValor.equals(segundoValor.toString());
    }
    return flag;
  }

    /**
   * Iterar lista y aplicar metodo.
   *
   * @param <T>
   *          the generic type
   * @param listDatosDondeSeAplicaElMetodo
   *          the list
   * @param nombreClaseQueContieneElMetodoAplica
   *          the cls
   * @param nombreMetodoAplicar
   *          the method name
   * @throws Exception
   *           the exception
   * @author amancillaa
   */
  public static <T> void iterarListaParaAplicarMetodo(List<T> listDatosDondeSeAplicaElMetodo,
                                                      Class nombreClaseQueContieneElMetodoAplica,
                                                      String nombreMetodoAplicar) throws Exception
  {

    Class[] tiposClaseDelParametro = new Class[1];
    tiposClaseDelParametro[0] = Map.class;
    Object obj = nombreClaseQueContieneElMetodoAplica.newInstance();

    Method method = nombreClaseQueContieneElMetodoAplica.getDeclaredMethod(nombreMetodoAplicar, tiposClaseDelParametro);

    for (T valorParametro : listDatosDondeSeAplicaElMetodo)
    {
      method.invoke(obj, valorParametro);
    }

  }

  /**
   * Sumar por campo.
   *
   * @param lista
   *          [List<Map<String,Object>>] lista
   * @param campo
   *          [String] campo
   * @return [BigDecimal] big decimal
   * @author amancillaa
   * @version 1.0
   */
  public static BigDecimal sumarPorCampo(List<Map<String, Object>> lista,
                                         String campo)
  {
	List<Map<String, Object>> lista_aux = new ArrayList<Map<String, Object>>(lista);
	lista_aux = quitarRegistrosMarcadaParaEliminar(lista_aux);
    BigDecimal suma = new BigDecimal(0);
    for (Map<String, Object> mapa : lista_aux)
    {
      BigDecimal item = Utilidades.toBigDecimal(mapa.get(campo));
      suma = suma.add(item);
    }

    return suma;
  }

  /**
   * Sumar por campo2.
   *
   * @param lista
   *          [List<? extends Object>] lista
   * @param campo
   *          [String] campo
   * @return [BigDecimal] big decimal
   * @throws Exception
   *           the exception
   * @author amancillaa
   * @version 1.0
   */
  public static BigDecimal sumarPorCampo2(List<? extends Object> lista,
                                          String campo) throws Exception
  {
	List <Object> lista_aux = new ArrayList<Object>(lista);
	lista_aux = quitarRegistrosMarcadaParaEliminar(lista_aux);
    BigDecimal suma = new BigDecimal(0);
    BigDecimal item = new BigDecimal(0);
    for (Object fila : lista_aux)
    {

      if (fila instanceof java.util.Map)
      {
        item = Utilidades.toBigDecimal(((Map) fila).get(campo));
      }
      else
      {

        String nameField = campo;
        String nameMethod = "get" + nameField.substring(0, 1).toUpperCase() +
                            nameField.substring(1, nameField.length());

        Method method = fila.getClass().getMethod(nameMethod, new Class[] {});
        Object valorCampo = method.invoke(fila, new Object[] {});

        item = Utilidades.toBigDecimal(valorCampo);
      }

      suma = suma.add(item);
    }

    return suma;
  }

  /**
   * Sumar por campo filtrado and criterios.
   *
   * @param lista
   *          [List<Map<String,Object>>] lista
   * @param campo
   *          [String] campo
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return [BigDecimal] big decimal
   * @author amancillaa
   * @version 1.0
   */
  public static BigDecimal sumarPorCampoFiltradoANDCriterios(List<Map<String, Object>> lista,
                                                             String campo, Map<String, Object> filtros)
  {

	List<Map<String, Object>> lista_aux = new ArrayList<Map<String, Object>>(lista);
	lista_aux = quitarRegistrosMarcadaParaEliminar(lista_aux);
    BigDecimal suma = new BigDecimal(0);
    for (Map<String, Object> mapa : lista_aux)
    {

      if (cumpleTodosLosFiltrosAND(mapa, filtros))
      {
        BigDecimal item = Utilidades.toBigDecimal(mapa.get(campo));

        suma = suma.add(item);
      }
    }

    return suma;
  }

  /**
   * Sumar por campo filtrado or criterios.
   *
   * @param lista
   *          [List<Map<String,Object>>] lista
   * @param campo
   *          [String] campo
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return [BigDecimal] big decimal
   * @author amancillaa
   * @version 1.0
   */
  public static BigDecimal sumarPorCampoFiltradoORCriterios(List<Map<String, Object>> lista,
                                                            String campo, Map<String, Object> filtros)
  {
	List<Map<String, Object>> lista_aux = new ArrayList<Map<String, Object>>(lista);
	lista_aux = quitarRegistrosMarcadaParaEliminar(lista_aux);
    BigDecimal suma = new BigDecimal(0);
    for (Map<String, Object> mapa : lista_aux)
    {

      if (cumpleTodosLosFiltrosOR(mapa, filtros))
      {
        BigDecimal item = Utilidades.toBigDecimal(mapa.get(campo));
        suma = suma.add(item);
      }
    }

    return suma;
  }

  /**
   * Contar por campo filtrado and criterios.
   *
   * @param lista
   *          [List<? extends Object>] lista
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return [Long] long
   * @throws Exception
   *           the exception
   * @author amancillaa
   * @version 1.0
   */
  public static Long contarPorCampoFiltradoANDCriterios(List<? extends Object> lista,
                                                        Map<String, Object> filtros) throws Exception
  {
	List<Object> lista_aux = new ArrayList<Object>(lista);
	lista_aux = quitarRegistrosMarcadaParaEliminar(lista_aux);
    Long conteo = new Long(0);
    for (Object fila : lista_aux)
    {
      if (cumpleTodosLosFiltrosAND2(fila, filtros))
      {
        conteo++;
      }
    }

    return conteo;
  }

  /**
   * Cumple todos los filtros and.
   *
   * @param data
   *          [Map] data
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return true, if successful
   */
  private static boolean cumpleTodosLosFiltrosAND(Map data, Map<String, Object> filtros)
  {

    boolean rspta = true;

    for (Entry filtro : filtros.entrySet())
    {
      // comparamos valores por el campo del filtro
      if (!filtro.getValue().equals(data.get(filtro.getKey())))
      {
        return false;
      }
    }
    return rspta;
  }

  /**
   * Cumple todos los filtros and2.
   *
   * @param data
   *          [Object] data
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return true, if successful
   * @throws Exception
   *           the exception
   */
  private static boolean cumpleTodosLosFiltrosAND2(Object data, Map<String, Object> filtros) throws Exception
  {

    boolean rspta = true;
    String valorCampoString;
    for (Entry filtro : filtros.entrySet())
    {
      // comparamos valores por el campo del filtro
      if (data instanceof java.util.Map)
      {
        valorCampoString = ((Map) data).get(filtro.getKey()).toString();
      }
      else
      {
        String nameField = filtro.getKey().toString();
        String nameMethod = "get" + nameField.substring(0, 1).toUpperCase() +
                            nameField.substring(1, nameField.length());

        Method method = data.getClass().getMethod(nameMethod, new Class[] {});
        Object valorCampo = method.invoke(data, new Object[] {});
        valorCampoString = valorCampo.toString();
      }
      if (!filtro.getValue().equals(valorCampoString))
      {
        return false;
      }
    }

    return rspta;
  }

  /**
   * Cumple todos los filtros or.
   *
   * @param data
   *          [Map] data
   * @param filtros
   *          [Map<String,Object>] filtros
   * @return true, if successful
   */
  private static boolean cumpleTodosLosFiltrosOR(Map data, Map<String, Object> filtros)
  {

    boolean rspta = false;

    for (Entry filtro : filtros.entrySet())
    {
      // comparamos valores por el campo del filtr
      for (Object valor : (List) filtro.getValue())
      {
        if ((valor.toString()).equals(data.get(filtro.getKey())))
        {
          return true;
        }
      }

    }
    return rspta;
  }

  /**
   * Quitar registros marcada para eliminar.
   *
   * @param lstTabla
   *          [List] lst tabla
   * @return [List] list
   * @author amancillaa
   * @version 1.0
   */
  public static List quitarRegistrosMarcadaParaEliminar(List lstTabla)
  {

    List<Map> lstMarcados = new ArrayList<Map>();

    for (Map mapRegistro : (ArrayList<Map>) lstTabla)
    {
      if (esUnaRegistroMarcadaParaEliminar(mapRegistro))
      {
        lstMarcados.add(mapRegistro);
      }
    }

    for (Map mapRegistro : (ArrayList<Map>) lstMarcados)
    {
      lstTabla.remove(mapRegistro);
    }

    return lstTabla;
  }

  /**
   * Metodo que remueve las series eliminadas en una diligencia diferente a la diligencia en proceso
   * 
   * @param lstDetDeclaraActual lista de series
   */
  public static void removerRegistrosEliminadosPermanentemente(List<Map<String, Object>> lstDetDeclaraActual) {
	  for(int i = lstDetDeclaraActual.size() - 1; i >= 0; i--) {
		  Map<String, Object> detDeclaraActual = lstDetDeclaraActual.get(i);
		  
		  String claveCampo = "ELIMINADO_PERMANENTE";
		  
		  if(detDeclaraActual.containsKey(claveCampo) && "BD".equals(detDeclaraActual.get(claveCampo))) {
			  lstDetDeclaraActual.remove(i);
		  }
	  }
  }
  
  /**
   * Devuelve los registros que van a ser eliminados
   * @param lstTabla
   * @return
   */
  public static List obtenerRegistrosMarcadoParaEliminar(List lstTabla) {

    List<Map> lstMarcados = new ArrayList<Map>();

    for (Map mapRegistro : (ArrayList<Map>) lstTabla) {
      if (esUnaRegistroMarcadaParaEliminar(mapRegistro)) {
        lstMarcados.add(mapRegistro);
      }
    }
    return lstMarcados;
  }

  /**
   * Repone los registros que fueron eliminados y opcionalmente sort por un determinado campo
   * @param listaSerieEliminada
   * @param lstTabla
   * @return
   */
  public static List reponeRegistrosMarcadosParaEliminar(List<Map<String, Object>> listaSerieEliminada, List lstTabla, String campoSort) {
	  for (Map<String, Object> mapEliminar : listaSerieEliminada) {
		  lstTabla.add(mapEliminar);
      }
      if (!CollectionUtils.isEmpty(listaSerieEliminada) && !SunatStringUtils.isEmptyTrim(campoSort)) {
        Ordenador.sortDesc(lstTabla, campoSort, Ordenador.ASC);
      }
      return lstTabla;
  }

  /**
   * Es una registro marcada para eliminar.
   *
   * @param mapRegistro
   *          [Map] map registro
   * @return true, if successful
   */
  public static boolean esUnaRegistroMarcadaParaEliminar(Map mapRegistro)
  {
    boolean esUnaRegistroMarcadaParaEliminar = false;
    String indicadorEliminado = mapRegistro.get("IND_DEL") != null ?
                                                                  mapRegistro.get("IND_DEL").toString()
                                                                  : "";

	if ("1".equals(indicadorEliminado) || indicadorCorrelacionado(mapRegistro))
    {
      esUnaRegistroMarcadaParaEliminar = true;
    }

    return esUnaRegistroMarcadaParaEliminar;

  }

  private static boolean indicadorCorrelacionado(Map mapRegistro){
	  return "0".equals(mapRegistro.get("IND_DECLARACION_FORMATOB")) 
			  && "1".equals(mapRegistro.get("IND_SERIE_CORRELACIONADA"));
  }

  /**
   * Convierte una Objeto de cualquier tipo a java.util.Date
   *
   * @param object
   * @return java.util.Date
   */
  public static java.util.Date toDate(Object object){

    // validacion de los datos de entrada
    String string = Constantes.DEFAULT_FECHA_BD;

    // verifica que fecha no este vacia
    if (object instanceof String && SunatStringUtils.isEmpty((String) object))
      return SunatDateUtils.getDate(string);
    // verifica fecha no sea null
    if (object == null)
      return SunatDateUtils.getDate(string);

    // transformamos el datos de entrada
    if (object instanceof String) {

      string = (String) object;

      // verifica que la fecha a transformar sea valida
      if (isValidDate(string) == false) {

          try {
              return DateUtils.parseDate(object.toString(),FORMAT_DATES);
                } catch (ParseException e) {
                    return SunatDateUtils.getDateFromUnknownFormat(object.toString());
                } catch (Exception e) {
                    return SunatDateUtils.getDate(Constantes.DEFAULT_FECHA_BD);
                }
      }
    } else if (object instanceof java.sql.Timestamp) {

      java.sql.Timestamp timestamp = (Timestamp) object;

      long milliseconds = timestamp.getTime() + (timestamp.getNanos() / 1000000);
      return new java.util.Date(milliseconds);

    } else if (object instanceof java.util.Date) {
      return (java.util.Date) object;
    }

    java.util.Date fechaRspta = SunatDateUtils.getDate(string);


    return fechaRspta;
  }

  /**
   * verifica si la fecha es valida
   *
   * @param inDate con formato dd/MM/yyyy
   * @return true si es una fecha validad segun el formato false SI no lo es
   */
  public static boolean isValidDate(String inDate){

    if (inDate == null) {
      return false;
    }

    // MM-dd-yyyy, MM.dd.yyyy, dd.MM.yyyy ,yyyy-MM-dd
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    if (inDate.trim().length() != dateFormat.toPattern().length()) {
      return false;
    }

    dateFormat.setLenient(false);

    try {
      // parse the inDate parameter
      dateFormat.parse(inDate.trim());
    } catch (ParseException pe) {
      return false;
    }
    return true;
  }


  /**
   * Convierte Key de params en Minusculas
   * usado al momento de enviar parametros a los DAO y adaptarlos segun
   * en sus XML.
   *
   * @autor amancillaa
   * @param params tipo Map<String, Object>
   * @return
   */
  public static final Map<String, Object> convertKeyMapToLowerCase(Map<String, Object> params){
    Map<String, Object> mapNuevo = new HashMap<String, Object>();
    for (String key : params.keySet()) {
      mapNuevo.put(key.toLowerCase(), params.get(key));
    }
    return mapNuevo;
  }


  /**
   * Obtiene el titulo concatenado de la DUA
   *
   * @autor amancillaa
   * @param mapaDUA Map contiene cod_aduana,ann_presen,cod_regimen,num_declaracion
   * @return
   */
  public static final String obtenerTituloDUA(Map<String, Object> mapaDUA){

    StringBuffer sb = new StringBuffer();
    sb.append((String) mapaDUA.get("cod_aduana"));
    sb.append("-");
    sb.append((String) mapaDUA.get("ann_presen"));
    sb.append("-");
    sb.append((String) mapaDUA.get("cod_regimen"));
    sb.append("-");
    sb.append((String) mapaDUA.get("num_declaracion"));

    return sb.toString();
  }
  
  /**
   * @author jenciso
   * @param datoVehiculo
   * @return
   */
  public static Map<String,Object> obtenerMapFromObjectDatoVehiculo(DatoVehiculo datoVehiculo){
	  Map<String,Object> mapVehiculo = new HashMap<String, Object>();
	  
	  mapVehiculo.put("NUM_CORREDOC",datoVehiculo.getNumcorredoc());
	  mapVehiculo.put("NUM_SECSERIE",datoVehiculo.getNumserie());
	  mapVehiculo.put("NOM_PUBLI",datoVehiculo.getNomlibro());
	  mapVehiculo.put("NUM_EJEMPLARPUB",datoVehiculo.getCodejempl());
	  mapVehiculo.put("PER_PUBLI",datoVehiculo.getAnnmespubli());
	  mapVehiculo.put("NUM_PAGINA",datoVehiculo.getNumpagin());
	  mapVehiculo.put("COD_FACTORCONV",datoVehiculo.getNumfactconve());
	    
	  return mapVehiculo;
  }
  
  /**
   * @author jenciso
   * @param datoMontoGasto
   * @return
   */
  public static Map<String,Object> obtenerMapFromObjectDatoMontoGasto(DatoMontoGasto datoMontoGasto){
	  Map<String,Object> mapMontoGasto = new HashMap<String, Object>();
	  mapMontoGasto.put("NUM_CORREDOC", datoMontoGasto.getNumcorredoc());
	  mapMontoGasto.put("NUM_SECSERIE", datoMontoGasto.getNumserie());
	  mapMontoGasto.put("COD_CPTOGASTOS", datoMontoGasto.getTipmonto());
	  mapMontoGasto.put("MTO_GASTO", datoMontoGasto.getValmonto());
	  
	  return mapMontoGasto;
  }
  
  /**
   * @author jenciso
   * @param lstDatoMontoGasto
   * @return
   */
  public static List<Map<String,Object>> obtenerListMapFromListObjectDatoMontoGasto(List<DatoMontoGasto> lstDatoMontoGasto){
	  List<Map<String,Object>> listaMontoGastos = new ArrayList<Map<String,Object>>();
	  for(DatoMontoGasto datoMontoGasto: lstDatoMontoGasto){
		  if(datoMontoGasto== null)
			  continue;
		  listaMontoGastos.add(obtenerMapFromObjectDatoMontoGasto(datoMontoGasto));
	  }
	  return listaMontoGastos; 
  }
  
  /**
   * @author jenciso
   * @param mapVehiculo
   * @return
   */
  public static DatoVehiculo obtenerDatoVehiculoFromMap(Map<String,Object> mapVehiculo){
	  DatoVehiculo datoVehiculo = new DatoVehiculo();
	  datoVehiculo.setNumcorredoc(new Long(mapVehiculo.get("NUM_CORREDOC").toString()));
	  datoVehiculo.setNumserie(new Integer(mapVehiculo.get("NUM_SECSERIE").toString()));
	  datoVehiculo.setNomlibro((String)mapVehiculo.get("NOM_PUBLI"));
	  datoVehiculo.setCodejempl(mapVehiculo.get("NUM_EJEMPLARPUB")!=null ? (String)mapVehiculo.get("NUM_EJEMPLARPUB"):null);
	  datoVehiculo.setAnnmespubli(mapVehiculo.get("PER_PUBLI")!=null? mapVehiculo.get("PER_PUBLI").toString():null);
	  datoVehiculo.setNumpagin(mapVehiculo.get("NUM_PAGINA")!=null ? new Integer(mapVehiculo.get("NUM_PAGINA").toString()):null);
	  datoVehiculo.setNumfactconve(mapVehiculo.get("COD_FACTORCONV")!=null ? new BigDecimal(mapVehiculo.get("COD_FACTORCONV").toString()):null);

	  return datoVehiculo;
  }
  
  /**
   * @author jenciso
   * @param mapMontoGasto
   * @return
   */
  public static DatoMontoGasto obtenerDatoMontoGastoFromMap(Map<String,Object> mapMontoGasto){
	  DatoMontoGasto datoMontoGasto = new DatoMontoGasto();
	  datoMontoGasto.setNumcorredoc(new Long(mapMontoGasto.get("NUM_CORREDOC").toString()));
	  datoMontoGasto.setNumserie(new Integer(mapMontoGasto.get("NUM_SECSERIE").toString()));
	  datoMontoGasto.setTipmonto((String)mapMontoGasto.get("COD_CPTOGASTOS"));
	  datoMontoGasto.setValmonto(new BigDecimal(mapMontoGasto.get("MTO_GASTO").toString()));
	  

	  return datoMontoGasto;
  }  
  
  /**
   * @author jenciso
   * @param lstMontoGasto
   * @return
   */
  public static List<DatoMontoGasto> obtenerListDatoMontoGastoFromListMap(List<Map<String,Object>> lstMontoGasto){
	  List<DatoMontoGasto> lstDatoMontoGasto = new ArrayList<DatoMontoGasto>();
	  for(Map<String,Object> mapMontoGasto : lstMontoGasto){
		  if(mapMontoGasto.isEmpty())
			  continue;
		  lstDatoMontoGasto.add(obtenerDatoMontoGastoFromMap(mapMontoGasto));
		  
	  }
	  return lstDatoMontoGasto;
  }  
  
  public static final String validarNuloOVacioRetornaString(Object obj){
	  String valor = "";
	  if(obj==null){
		  valor = "";
	  }else if(obj.toString().trim().isEmpty()){
		  valor = "";
	  }else{
		  valor = obj.toString();
	  }
	  return valor;
  }
  
  public static final BigDecimal validaVacioRetornaBigDecimal(Object monto){
	  
		String valor = "0";
		if(monto!=null ){
			valor = monto.toString().replace(",", "");
		}
		BigDecimal montoDecimal = toBigDecimal(valor);
		return montoDecimal;
  }	

  public static java.util.Date convertirFormatoStringToDate(String fechStr){
	  java.util.Date fecha = null;

	  try{
	        fecha = DateUtils.parseDate(fechStr, FORMAT_DATES);
	  }catch (ParseException e){
	       fecha = SunatDateUtils.getDateFromUnknownFormat(fechStr);
	  }
	   return fecha;
  }
	  
	public static String reemplazaCaracterEspecialEnHtml(String cadena){
		String reemplazo = cadena;
		reemplazo = reemplazo.replaceAll("�", "&aacute;");
		reemplazo = reemplazo.replaceAll("�", "&eacute;");
		reemplazo = reemplazo.replaceAll("�", "&iacute;");
		reemplazo = reemplazo.replaceAll("�", "&oacute;");
		reemplazo = reemplazo.replaceAll("�", "&uacute;");
		reemplazo = reemplazo.replaceAll("�", "&Aacute;");
		reemplazo = reemplazo.replaceAll("�", "&Eacute;");
		reemplazo = reemplazo.replaceAll("�", "&Iacute;");
		reemplazo = reemplazo.replaceAll("�", "&Oacute;");
		reemplazo = reemplazo.replaceAll("�", "&Uacute;");
		reemplazo = reemplazo.replaceAll("�", "&ntilde;");
		reemplazo = reemplazo.replaceAll("�", "&Ntilde;");
		reemplazo = reemplazo.replaceAll("�", "&deg;");
		return reemplazo;
	}
  
  /*inicio mpoblete bug*/
  public static HashMap<String,Object> generarPDF(Integer codPlantilla,ArrayList fields,String fileName){
	  HashMap parameters = new HashMap();
	  parameters.put("consulta", "");
		
	  String urlPlantilla ="/data0/generador/jasper/plantillas/PLANTILLA"+codPlantilla+".jasper";
	  String pathName =  "/data0/uploads/pdf/";	 
	  HashMap<String,Object> retorno = new HashMap<String,Object>();	  
	  try {
			JRMapCollectionDataSource ds= new JRMapCollectionDataSource(fields);
		  	JasperReport jasperReport = null;
		  	    jasperReport = (JasperReport) JRLoader.loadObject(urlPlantilla);
				JasperPrint print = JasperFillManager.fillReport(jasperReport, parameters, ds);						
				JasperExportManager.exportReportToPdfFile(print, pathName + fileName);  
				
				
				retorno.put("path_name", pathName + fileName);
				retorno.put("file_name", fileName);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			retorno = new HashMap<String,Object>();	  
			retorno.put("Error", "Error al generar archivo "+fileName);
		}
	  
	    return retorno;
	  
  }
  /*fin mpoblete bug*/
  

  /*Atencion SAU20143K004000854 */
  public static String obtieneRegimenExped(String pcodRegimen){
  
	  String regimenExped = "";	
	  if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(pcodRegimen))  {
	    regimenExped = "17";
	  }
	  else if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals(pcodRegimen))  {
		    regimenExped = "32";
	  }
	  else if (Constantes.REGIMEN_70_DEPOSITO.equals(pcodRegimen))  {
		    regimenExped = "40";
	  }
	  else if (Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals(pcodRegimen))  {
		    regimenExped = "7";
	  }
	  return regimenExped;
  }
//<EHR> RIN 10
public static String retirarTildeParaAsuntoNotificacion(String cadena) {
	String reemplazo = cadena;
	reemplazo = reemplazo.replaceAll("�", "A");
	reemplazo = reemplazo.replaceAll("�", "E");
	reemplazo = reemplazo.replaceAll("�", "I");
	reemplazo = reemplazo.replaceAll("�", "O");
	reemplazo = reemplazo.replaceAll("�", "U");
	reemplazo = reemplazo.replaceAll("�", "�");
	return reemplazo;
}

//Inicio  P34
  public static final boolean esNuloOVacio(Object obj){
      boolean valor = false;
      if(obj==null){
          valor = true;
      }else if(obj.toString().trim().isEmpty()){
          valor = true;
      }else{
          valor = false;
      }
      return valor;
  }

  public static java.util.Date parseFecha(String fecha)
  {
      SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
      java.util.Date fechaDate = null;
      try {
          fechaDate = formato.parse(fecha);
      } 
      catch (ParseException ex) 
      {
          fechaDate = null;
      }
      return fechaDate;
  }


  public static String formatoNumeroManifiesto(String codTipmanifiesto, String codViatrans, String codAduamanifiesto,  Integer annManifiesto, String numManifiesto) {
    StringBuilder sbManifiesto = new StringBuilder();
    sbManifiesto.append(codTipmanifiesto);
    sbManifiesto.append("-");
    sbManifiesto.append(codViatrans);
    sbManifiesto.append("-");
    sbManifiesto.append(codAduamanifiesto);
    sbManifiesto.append("-");
    sbManifiesto.append(annManifiesto);
    sbManifiesto.append("-");
    sbManifiesto.append(numManifiesto);

    return sbManifiesto.toString();
  }


  //P34 AFMA
  public static String obtenerTipoOperadorSegunCodigoLugarRecepcion(String codigoLugarRecepcion) {

    String codigoTipoOperador = " ";

    if(DEPOSITO_TEMPORAL.equals(codigoLugarRecepcion)){
      codigoTipoOperador="31";
    }else if(DEPOSITO_ADUANERO.equals(codigoLugarRecepcion)){
      codigoTipoOperador="32";
    }

    return codigoTipoOperador;
  }
//FIN  P34

  private static File generarArchivoDesdeBytes(String rutaTempDir, String nombreArchivo, byte[] datosArchivo) throws Exception {
    int data;
    String filename = nombreArchivo != null ? nombreArchivo : "ARCHIVO_" + String.valueOf(System.currentTimeMillis());
    String directory = rutaTempDir;
    File directoryFile = new File(directory);
    if (!directoryFile.exists()) {
      directoryFile.mkdirs();
    }
    byte[] fileInBytes = datosArchivo;
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(fileInBytes);
    File newFile = new File(String.valueOf(directory) + filename);
    FileOutputStream fos = new FileOutputStream(newFile);
    while ((data = byteArrayInputStream.read()) != -1) {
      char ch = (char)data;
      fos.write(ch);
    }
    fos.flush();
    fos.close();
    return newFile;
  }

  private static List<String> descomprimirArchivo(Map<String, Object> parametros) throws Exception {
    List<String> resultado = null;

    try {
      String fileName = (String) parametros.get("filename");
      String destination = (String) parametros.get("destination");

      // Realizamos la descompresion
      ZipUtil zipUtil = new ZipUtil();
      resultado = zipUtil.unZipFiles(fileName,destination);

    } catch(ZipException e) {
      e.printStackTrace();
      return null;
    }
    return resultado;
  }

  public static File grabarArchivoTemporal(byte[] byteArchivo, String rutaDestino) {
    File archivoZIP = null;
    File archivoPDF = null;

    String nombreArchivo = "tmp_"+String.valueOf(System.currentTimeMillis()) + "_" + "comprimido.zip";
    try {
      archivoZIP = generarArchivoDesdeBytes(rutaDestino, nombreArchivo, byteArchivo);

      Map<String,Object> parametros = new HashMap<String,Object>();
      parametros.put("filename", archivoZIP.getAbsolutePath());
      parametros.put("destination","/data1/vuce/envios/anexospdf/descomprimido/");
      List<String> fileNames = descomprimirArchivo(parametros);
      for (String name : fileNames) {
        archivoPDF = new File(name);
      }

    } catch(Exception e) {
      e.printStackTrace();
      return null;
    }
    return archivoPDF;
  }

  /**Para conversiones seguras de fechas por rest
   *  PAS20191U220200013
   * ***/
  public static int length(String str)
  {
		if(str == null)
			return 0;
		
		return str.length();
  }
  public static boolean isEmpty(String str) {
		return StringUtils.isEmpty(str);
  }
  
  public static java.util.Date getDateFromUnknownFormatThreadSafe(String strDate) {
		if( ! Utilidades.isEmpty(strDate) )
		{
			if(Utilidades.length(strDate)==10){
				try {
					SafeSimpleDateFormat _formatddMMyyyy = new SafeSimpleDateFormat("dd/MM/yyyy");
					return _formatddMMyyyy.parse(strDate);
				} catch (ParseException e) {
				}
				try {
					SafeSimpleDateFormat _formatyyyyMMdd = new SafeSimpleDateFormat("yyyy-MM-dd");
					return _formatyyyyMMdd.parse(strDate);
				} catch (ParseException e) {
				}
			}else{
				try {
					SafeSimpleDateFormat _formatddMMyyyyHHmmss = new SafeSimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					return _formatddMMyyyyHHmmss.parse(strDate);
				} catch (ParseException e) {
				}
				try {
					SafeSimpleDateFormat _formatyyyyMMddHHmmss = new SafeSimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					return _formatyyyyMMddHHmmss.parse(strDate);
				} catch (ParseException e) {
				}
			}
		}
		return null;
	}


  public static File grabarArchivoTemporalCO(byte[] byteArchivo, String rutaDestino) {
    File archivoZIP = null;
    File archivoPDF = null;
    File archivoUnzip = null;

    String nombreArchivo = "tmp_"+String.valueOf(System.currentTimeMillis()) + "_" + "comprimido.zip";
    try {
      archivoZIP = generarArchivoDesdeBytes(rutaDestino, nombreArchivo, byteArchivo);

      Map<String,Object> parametros = new HashMap<String,Object>();
      parametros.put("filename", archivoZIP.getAbsolutePath());
      parametros.put("destination","/data1/vuce/envios/anexospdf/descomprimido/");
      List<String> fileNames = descomprimirArchivo(parametros);
      for (String name : fileNames) {
        archivoUnzip = new File(name);
       archivoPDF = changeExtension(archivoUnzip,"pdf");
      }

    } catch(Exception e) {
      e.printStackTrace();
      return null;
    }
    return archivoPDF;
  }


  public static File changeExtension(File file, String extension) {
    String filename = file.getName();

    if (filename.contains(".")) {
      filename = filename.substring(0, filename.lastIndexOf('.'));
    }
    filename += "." + extension;

    File pdf = new File(file.getParentFile(), filename);
    file.renameTo(pdf);
    return pdf ;
  }
}
