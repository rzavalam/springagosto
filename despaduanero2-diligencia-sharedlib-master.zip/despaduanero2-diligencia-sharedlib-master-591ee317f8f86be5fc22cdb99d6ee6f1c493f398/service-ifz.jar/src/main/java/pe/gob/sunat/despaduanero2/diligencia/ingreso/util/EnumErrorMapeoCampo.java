package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

public enum EnumErrorMapeoCampo {
    ERROR_FECHA("ERROR_FECHA"),
    ERROR_NULL("ERROR_NULL"),
    ERROR_VACIO("ERROR_VACIO"),
    ERROR_CERO("ERROR_CERO"),
    ERROR_NEGATIVO("ERROR_NEGATIVO");
    /**
     * Contiene el texto del prefijo
     */
    private String prefijo;


    EnumErrorMapeoCampo(String prefijo) {
        this.prefijo = prefijo;
    }


    public String getPrefijo() {
        return prefijo;
    }


    public void setPrefijo(String prefijo) {
        this.prefijo = prefijo;
    }
}
