package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.ServletWebRequest;

public final class WUtil
{
  private static final String VALOR_VACIO_DEFECTO = "";
  
  private WUtil(){
    //no se debe inicializar objetos de esta clase
  }
  /**
   * Obtiene el valor del parametro enviado, el cual es buscado en el webRequest, de no encontrarse
   * se devuelve el valor enviado como defecto.
   * @param webRequest  :   objeto donde se buscara el valor del parametro
   * @param paramName   :   parametro a buscar
   * @param paramValorDefecto : valor por defecto en caso de ser nulo.
   * @return : devuelve el valor del parametro enviado, en caso de ser nulo, devuelve el parametro por defecto.
   */
  public static String getParam(ServletWebRequest webRequest, String paramName, String paramValorDefecto){
    if(esParametroNulo(webRequest, paramName)){
      return paramValorDefecto;      
    }
    return obtenerValorParametro(webRequest, paramName);    
  }
  
  /**
   * Verifica si el parametro enviado se encuentra webRequest
   * @param webRequest  : objeto donde se buscara el valor del parametro
   * @param paramName   : parametro a buscar
   * @return  devuelve true si encuentra el parametro, caso contrario false.
   */
  private static boolean esParametroNulo(ServletWebRequest webRequest, String paramName){
    return webRequest.getParameter(paramName) == null;
  }
  /**
   * Devuelve el valor de un parametro dentro del objeto webRequest enviado
   * @param webRequest  : objeto donde se buscara el valor del parametro
   * @param paramName   : parametro a buscar
   * @return devuelve el valor del parametro dentro del objeto.
   */
  private static String obtenerValorParametro(ServletWebRequest webRequest, String paramName){
    return webRequest.getParameter(paramName);
  }
  /**
   * Obtiene el valor del parametro enviado, el cual es buscado en el webRequest.
   * @param webRequest  :   objeto donde se buscara el valor del parametro
   * @param paramName   :   parametro a buscar
   * @return : devuelve el valor del parametro enviado, en caso de ser nulo, devuelve una cadena vacia.
   */
  public static String getParam(ServletWebRequest webRequest, String paramName){
    return getParam(webRequest, paramName, VALOR_VACIO_DEFECTO);
  }
  /**
   * Obtiene el valor del parametro enviado, el cual es buscado en el request.
   * @param request  :   objeto donde se buscara el valor del parametro
   * @param paramName   :   parametro a buscar
   * @return : devuelve el valor del parametro enviado, en caso de ser nulo, devuelve una cadena vacia.
   */
  public static String getParam(HttpServletRequest request, String paramName){
    return getParam(request, paramName, VALOR_VACIO_DEFECTO);
  }
  /**
   * Obtiene el valor del parametro enviado, el cual es buscado en el objeto request.
   * @param request  :   objeto donde se buscara el valor del parametro
   * @param paramName   :   parametro a buscar
   * @param paramValorDefecto : valor por defecto en caso de ser nulo.
   * @return : devuelve el valor del parametro enviado, en caso de ser nulo, devuelve el parametro por defecto.
   */
  public static String getParam(HttpServletRequest request, String paramName, String paramValorDefecto){
    if(esParametroNulo(request, paramName)){
      return paramValorDefecto;      
    }
    return obtenerValorParametro(request, paramName);
    
  }
  /**
   * Devuelve el valor de un parametro dentro del objeto request enviado
   * @param request  : objeto donde se buscara el valor del parametro
   * @param paramName   : parametro a buscar
   * @return devuelve el valor del parametro dentro del objeto.
   */
  private static String obtenerValorParametro(HttpServletRequest request, String paramName)
  {
    return request.getParameter(paramName);
  }
  /**
   * Verifica si el parametro enviado se encuentra request
   * @param request  : objeto donde se buscara el valor del parametro
   * @param paramName   : parametro a buscar
   * @return  devuelve true si encuentra el parametro, caso contrario false.
   */
  private static boolean esParametroNulo(HttpServletRequest request, String paramName)
  {
    return request.getParameter(paramName) == null;
  }
  

}
