package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//P34
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Interface FormatoValorService.
 */
@SuppressWarnings({ "rawtypes"})
public interface FormatoValorService
{

  /**
   * Metodo que permite obtener los Items de una determinada Serie.
   *
   * @param PkSerie
   *          the pk serie
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFVItem(Map<String, String> PkSerie) throws ServiceException;

  /**
   * Metodo que nos permite obtener la lista de Proveedores de una DUA con la
   * cantidad de facturas que se posee en dicha DUA. Tener en cuenta la
   * invocacion hacia DPP1 si es necesario??.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerFVProveedores(Map PkDocu) throws ServiceException;

  /**
   * Obtener fv facturas.
   *
   * @param PkFactu
   *          the pk factu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerFVFacturas(Map PkFactu) throws ServiceException;

  /**
   * Metodo que permite obtener el detalle de una Factura.
   *
   * @param PkSerie
   *          the pk serie
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerFVDetalle(Map<String, String> PkSerie) throws ServiceException;
  
  /**
   * Obtiene los Montos del FormatoB por proveedor
   * @author jenciso
   * @param num_correDoc
   * @param num_secProve
   * @return
   * @throws ServiceException
   */
  public Map<String,Object> obtenerMontosFormBByDAV(String num_correDoc, String num_secProve) throws ServiceException;
  
  
  /*INICIO RIN13 PQ2*/
  /**
   * Obtiene las condiciones de transaccion del FormatoB por proveedor
   * @author gbecerrav
   * @param num_correDoc
   * @param num_secProve
   * @return
   * @throws ServiceException
   */
  public Map<String,Object> obtenerCondicionTransaccionFormB(String num_correDoc, String num_secProve) throws ServiceException;
  /*FIN RIN13 PQ2*/
  /**
   * Obtener detalle dav.
   *
   * @param num_correDoc
   *          the num_corre doc
   * @param num_secProve
   *          the num_sec prove
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map obtenerDetalleDAV(String num_correDoc, String num_secProve) throws ServiceException;

  /**
   * Obtener formato b facturas.
   *
   * @param num_correDoc
   *          the num_corre doc
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerFormatoBFacturas(String num_correDoc) throws ServiceException;




  /**
   * Obtener facturas serie.
   *
   * @param pkSerie
   *          the pk serie
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFacturasSerie(Map<String, Object> pkSerie) throws ServiceException;

  /**
   * Obtener facturas proveedor.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerFacturasProveedor(Map params) throws ServiceException;

  /**
   * Obtener items factura.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List obtenerItemsFactura(Map params) throws ServiceException;

  /**
   * Metodo que permite obtener la lista de Items de Factura.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFormatoBItems(Map<String, String> PkDocu) throws ServiceException;

  /**
   * Metodo que permite obtener la lista de Items de Factura, Series Asociadas y
   * Referencia Duda.
   *
   * @param PkDocu
   *          the pk docu
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerFormatoBItem(Map<String, String> PkDocu) throws ServiceException;

  /**
   * Metodo que nos permite obtener las Asociaciones y Referencias de DUDA de un
   * ITEM.
   *
   * @param PkDocu
   *          the pk docu
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerAsociadasReferenciaDUDAFormatoBItem(Map<String, String> PkDocu)
    throws ServiceException;

  /**
   * Metodo que nos permite obtener las correlaciones del Formato B.
   *
   * @param pkItem
   *          the pk item
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFormatoBCorrelaciones(Map<String, Object> pkItem) throws ServiceException;

  /**
   * Metodo que nos permite obtener la lista de Proveedores de una DUA con la
   * informacion necesaria para el proceso de rectifiacion.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerDAVRecti(Map<String, String> PkDocu) throws ServiceException;

  /**
   * Metodo que permite obtener la lista de Items de una DUA.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFBItemsDUA(Map<String, String> PkDocu) throws ServiceException;

  /**
   * Obtener facturas.
   *
   * @param pkSerie
   *          the pk serie
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<DatoFacturaref> obtenerFacturas(Map<String, Object> pkSerie) throws ServiceException;

  /**
   * Obtener factura form a.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> obtenerFacturaFormA(Map<String, Object> params) throws ServiceException;

  /**
   * Select condi transa.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> selectCondiTransa(Map params) throws ServiceException;

  /**
   * Select vehi cetico.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> selectVehiCetico(Map params) throws ServiceException;

  /**
   * Select cab adi impo consu.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> selectCabAdiImpoConsu(Map<String, Object> params) throws ServiceException;

  /**
   * Select factu suce.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> selectFactuSuce(Map<String, Object> params) throws ServiceException;

  /**
   * Select formb monto.
   *
   * @param params
   *          the params
   * @return the list
   */
  public List<Map<String, Object>> selectFormbMonto(Map<String, Object> params);

  /**
   * Select formb item descri.
   *
   * @param params
   *          the params
   * @return the list
   */
  public List<Map<String, Object>> selectFormbItemDescri(Map params);

  /**
   * Select monto gasto.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  public List<Map<String, Object>> selectMontoGasto(Map<String, Object> params) throws ServiceException;
  
  //inicio CU 14.15
  /** Agrega el item copia a la lista de items de la factura seleccionada 
  * @param params
  * @param itemsViewList
  * @param lstItemsTotalActual
  * @return List<Map<String, Object>> Lista de Items
  * @throws ServiceException
  */
  public List<Map<String, Object>> obtenerListaItemsIncluidoItemCopiado(
	      Map<String, Object> params,
	      List<Map<String, Object>> detItemViewList, List<Map<String, Object>> lstItemsTotalActual)
	      throws ServiceException;
  
  /** Metodo que actualiza los indicadores de item Adicionado y si esta registrado en base de datos 
  * @param lstItemFacturaActual
  * @param mapPkSelecModificar
  * @return List<Map<String, Object>> Lista de Items
  */
  public List<Map<String,Object>> cambiarIndTipRegItemSesion(List<Map<String, Object>> lstItemFacturaActual, Map<String, Object> mapPkSelecModificar) throws ServiceException;
  
  /** Metodo que actualiza temporalmente el estado del item y su lista de descripciones minimas
  * (los items de las facturas estan contenidas en la session mapCabDeclaraActual)
  * @param lstItemFacturaActual
  * @param mapPkSelecModificar
  * @return
  */
  public void actualizarEstadoItemSesion(Map<String, Object> declaracionActual, Map<String, Object> parametro)  throws ServiceException;
  
  /** Metodo que retorna el siguiente secuencial del item en funcion a los items registrados en base de datos 
   * @param numCorreDocDua
   * @return int siguiente secuencial del item
   */
  public int obtenerSgteNumSecItemBd(String numCorreDocDua) throws ServiceException;
  
  /** Metodo que obtiene todos los items de las facturas contenidas en la declaracion actual
  * @param mapCabDeclara [Map<String,Object>]
  * @return [List<Map<String, Object>>] Lista de Items de la factura
  */
  public List<Map<String, Object>> obtenerListaItemsDeclaracionActual(Map<String,Object> mapCabDeclara) throws ServiceException;
  //fin CU 14.15

  /*inicio metodos gdlr*/
  public List<Map<String,Object>> obtenerMontosFormBByDocumento(Map<String,Object> parametros) throws ServiceException;
  
  public List<Map<String,Object>> obtenerCondicionTransaccionFormBByDocumento(Map<String, Object> parametros) throws ServiceException;
  
  public List<Map<String, Object>> obtenerItemsFacturaByDocumento(Map<String, Object> parametros) throws ServiceException;
  
  public List<Map<String, Object>> obtenerFobProvisionalByDocumento(Map<String, Object> parametros);
  /*fin metodos gdlr*/
  /** Obtiene el Bean Declaracion inicial con los datos con los que fue numerada la dua inicialmente
   * @param numcorredoc [Long] 
   * @param aduana [String]
   * @param annoEnvio [String] 
   * @return
  */// P34-3014 formatoB-Inicial
  public Declaracion obtenerDeclaracionInicial(Long numcorredoc, String aduana, String anio) throws Exception;
  
  /** Retorna el archivo como String
   * @param paramsMap [Map<String, Object>] 
   * @param fileName [String]
   * @param destination [String] 
   * @return
  */// P34-3014 formatoB-Inicial
  public String obtenerXMLDeclaracion(Map<String, Object> paramsMap, String fileName, String destination) throws Exception;

  /** Obtiene datos del Formato B inicial 
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @param pkSerie [Map] secuencial de la serie, numero corredoc, numero secuencial de factura, numero secuencial del item
   * @return
  */// P34-3014 formatoB-Inicial
  //amancilla P24
  public List<Map<String, Object>> obtenerFVDetalleInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException;
  
  /** Obtiene datos de la seccion Proveedores, lista los proveedores y datos de sus facturas
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerFVProveedoresInicial(Declaracion declaracionInicialBean)  throws ServiceException;
  
  /** Obtiene datos de la seccion Facturas, lista las facturas y datos de sus items
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkFactu [Map] numero corredoc, numero secuencial del proveedor
  * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String,Object>> obtenerFVFacturasInicial(Declaracion declaracionInicialBean, Map pkFactu) throws ServiceException;
 
  /** Obtiene la lista de items de una Factura inicial
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @param pkSerie [Map] secuencial de la serie
   * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerItemFacturaInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException;

  /** Obtiene datos de las facturas y sus Proveedores
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @return
   */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerFacturasProveedoresInicial(Declaracion declaracionInicialBean)  throws ServiceException;
  
  /** Obtiene datos del Item del formato B inicial (del archivo zip numerado inicialmente)
  * @param declaracionInicialBean
  * @param pkParametros
  * @return
  * @throws ServiceException
  */// P34-3014 formatoB-Inicial
  public Map<String,Object> obtenerDatosItemFactura(Declaracion declaracionInicialBean,  Map pkParametros)  throws ServiceException;
  //Fin P34-3014
  
  /*fin metodos gdlr*/

//amancilla P24
  public List<Map<String, Object>> obtenerFacturasSerieAll(Map<String, Object> pkSerie) throws ServiceException;


  public List<Map<String,Object>> obtenerFVItemsFacturaIncial(Declaracion declaracionInicialBean, Map pkFactu) throws ServiceException;

  public Map<String, Object> obtenerFVDetalleProveedorInicial(Declaracion declaracionInicialBean)  throws ServiceException;

  public Map<String, Object> obtenerFVDetalleInicialOriginal(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException;

  public Map<String,Object> cargarFormatoBDetFacturaInicial(Declaracion declaracionInicialBean, Map pkFactu);

  public List<Map<String, Object>> obtenerFormatoBCorrelacionesInicial(Declaracion declaracionInicialBean,Map<String, Object> pkItem) throws ServiceException;
}
