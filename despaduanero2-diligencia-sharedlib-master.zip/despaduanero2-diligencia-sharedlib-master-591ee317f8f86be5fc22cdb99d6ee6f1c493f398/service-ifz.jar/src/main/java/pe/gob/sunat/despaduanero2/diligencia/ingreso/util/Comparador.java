/**
 * Clase que provee metodos de comparacion para los maps y listas de maps utiles para Diligencia.
 * @author Wildor Mostacero Ramirez.
 * 
 */
package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.util.SunatStringUtils;//RIN08
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;


/**
 * Clase que nos permite comparar y obtener las diferencias segun sea el caso.
 * Se debe tener en cuenta que al elegir activarConversionNombresVista = true
 * esto quitara los prefijos: hdn_, txt_, cbx_, ta_, sel_ los cuales son usados
 * en la capa vista.
 *
 * @author wmostacero, rmontes
 *
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class Comparador
{

	private final String        keyPK               = "clave";

	private final String        keyDatosOriginales  = "dataOriginal";

	private final String        cadenaNula          = "null";

	private static final String INDICADOR_RECTIFICA = "R";

	private static final String INDICADOR_NUEVO     = "N";

	private enum enumPrefijos
	{

		HDN_,

		TXT_,

		CBX_,

		TA_,

		SEL_
	}

	/**
	 * Metodo que retorna un map con los datos originales y los cambios enviados
	 * dentro del mapaValores, siempre en cuando los keys del mapavalores existan
	 * dentro del mapaOrignal.
	 *
	 * @param mapaOriginal
	 *          the mapa original
	 * @param mapaValores
	 *          the mapa valores
	 * @return the map
	 */
	public static Map<String, Object> setearValoresMap(Map<String, Object> mapaOriginal, Map<String, Object> mapaValores)
	{
		Map<String, Object> mapResultado = new HashMap<String, Object>();

		mapResultado.putAll(mapaOriginal);
		if (mapResultado.size() > 0)
		{
			for (Entry<String, Object> entradaValor : mapaValores.entrySet())
			{
				if (mapResultado.containsKey(entradaValor.getKey()))
				{
					// Se agrego validacion debido a que en la serializacion json algunos
					// datos pasan como string
					// y al tratar de realizar el update o insert de un string en un campo
					// numerico de la base datos sale error
					Object value = entradaValor.getValue();
					if (value instanceof String)
					{
						if (StringUtils.contains(entradaValor.getKey(), "MTO_") ||
								StringUtils.contains(entradaValor.getKey(), "CNT_"))
						{
							if (NumberUtils.isNumber(value.toString()))
							{
								value = new BigDecimal(value.toString());
							}
						}
					}
					mapResultado.put(entradaValor.getKey(), value);
				}
			}
		}
		return mapResultado;
	}

	/**
	 * Setear valores list map.
	 *
	 * @param lstOriginalDatos
	 *          the lst original datos
	 * @param lstValores
	 *          the lst valores
	 * @param mapKeyClave
	 *          the map key clave
	 * @return the list
	 */
	public static List<Map<String, Object>> setearValoresListMap(
			List<Map<String, Object>> lstOriginalDatos,
			List<Map<String, Object>> lstValores,
			Map<String, Object> mapKeyClave)
	{
		return setearValoresListMap(lstOriginalDatos, lstValores, mapKeyClave, false);
	}

	/**
	 * SETEA A LIST<MAP> VALORES NUEVOS SEGUN PK Metodo que retorna un List con
	 * los datos originales y los cambios enviados dentro del lstValores, siempre
	 * en cuando los keys del mapavalores existan dentro del mapaOrignal.
	 *
	 * @param lstOriginalDatos
	 *          the lst original datos
	 * @param lstValores
	 *          the lst valores
	 * @param mapKeyClave
	 *          the map key clave
	 * @param newdata
	 *          the newdata
	 * @return the list
	 */
	public static List<Map<String, Object>> setearValoresListMap(
			List<Map<String, Object>> lstOriginalDatos,
			List<Map<String, Object>> lstValores,
			Map<String, Object> mapKeyClave,
			boolean newdata)
	{
		boolean bandera = false;
		boolean encontrado = false;
		//boolean banderaConvenioSerie = false;//RIN08
		List<Map<String, Object>> lstResultado = new ArrayList<Map<String, Object>>();
		if (CollectionUtils.isEmpty(lstValores) && CollectionUtils.isEmpty(lstOriginalDatos))
		{
			return lstResultado;
		}
		if (lstOriginalDatos != null && lstOriginalDatos.size() > 0)
		{

			for (Map<String, Object> temp : lstOriginalDatos)
			{
				lstResultado.add(new HashMap<String, Object>(temp));
			}
		}

		Iterator<Map<String, Object>> iterValores = lstValores.iterator();
		while (iterValores.hasNext())
		{
			Map<String, Object> mapValor = iterValores.next();
			if ("N".equals(mapValor.get("indica")) && mapValor.get("NEW_RECORD") != null)
			{
				Map<String, Object> mapNewRecord = (Map) SojoUtil.fromJson(ObjectUtils.toString(
						mapValor.get("NEW_RECORD"),
						"{}")); //
				mapValor.remove("NEW_RECORD");
				mapValor.putAll(mapNewRecord);
			}

		}
		// Cambiando los valores
		for (int i = 0; i < lstResultado.size(); i++)
		{
			Map<String, Object> mapOriginal = lstResultado.get(i);
			for (Map<String, Object> mapValor : lstValores)
			{
				bandera = true;
				//Ya no es necesario, desde el det_solrecti ya se menciona el ind_del 
				//banderaConvenioSerie = false;//RIN08
				for (Entry<String, Object> entradaClave : mapKeyClave.entrySet()) {
					String valor = mapValor.get(entradaClave.getKey()) == null ? "" : mapValor.get(entradaClave.getKey()).toString().trim();
					String valorAnterior = mapOriginal.get(entradaClave.getKey()).toString().trim();
					// RIN08  Si es convenio_Serie filtrar el campo COD_CONVENIO
					//if (!SunatStringUtils.isEqualTo(entradaClave.getKey(),"COD_CONVENIO")){
						if (!(valor.equals(valorAnterior)))
						{
							bandera = false;
							break;
						}        	  
					//} else {
					//	banderaConvenioSerie = true;
					//}
				}
				if (bandera)
				{
					// No consideraba registros que deben ser anulados o si corresponden a convenio_serie
					//if (mapValor.get("indica").equals("A") || banderaConvenioSerie) {// Se considera campo IND_ACTIVO de INDICADOR_DUA P46-INSI INICIO
					if (mapValor.get("indica").equals("A")) {// Se considera campo IND_ACTIVO de INDICADOR_DUA P46-INSI INICIO
						if (lstResultado.get(i).get("COD_INDICADOR")!=null && lstResultado.get(i).get("IND_ACTIVO")!=null && lstResultado.get(i).get("IND_ACTIVO").equals("1")){
							lstResultado.get(i).put("IND_ACTIVO", "0");
						}else{ // Se considera campo IND_ACTIVO de INDICADOR_DUA P46-INSI FIN
							lstResultado.get(i).put("IND_DEL", "1");
						}          
					}
					else { 
						//El registro ya existe pero con indicador logico de borrado
						if (mapValor.get("indica").equals("N")) { 
							if (lstResultado.get(i).get("COD_INDICADOR")!=null && lstResultado.get(i).get("IND_ACTIVO")!=null && lstResultado.get(i).get("IND_ACTIVO").equals("0")){
								lstResultado.get(i).put("IND_ACTIVO", "1");
							}else{ 
								lstResultado.get(i).put("IND_DEL", "0");
							}
							mapValor.put("indica",INDICADOR_RECTIFICA);
						}     	  
						lstResultado.get(i).putAll(setearValoresMap(mapOriginal, mapValor));
					}
					break;
				}
			}
		}

		if (!CollectionUtils.isEmpty(lstValores) && newdata)
		{
			// Agregando los valores nuevos
			for (Map<String, Object> item : lstValores)
			{
				if (INDICADOR_NUEVO.equals(item.get("indica")))
				{
					lstResultado.add(new HashMap<String, Object>(item));
				}
			}
		}

		// Agregando valores nuevos cuando indicador es R
		for (int i = 0; i < lstValores.size(); i++)
		{
			Map<String, Object> mapValor = lstValores.get(i);
			encontrado = false;
			for (Map<String, Object> mapOriginal : lstResultado)
			{
				bandera = true;
				for (Entry<String, Object> entradaClave : mapKeyClave.entrySet())
				{
					String valor = mapValor.get(entradaClave.getKey()) == null ? "" : mapValor
							.get(entradaClave.getKey())
							.toString()
							.trim();
					if (!(ObjectUtils.toString(mapOriginal.get(entradaClave.getKey())).trim().equals(valor)))
					{
						bandera = false;
						break;
					}
				}
				if (bandera)
				{
					encontrado = true;
					break;
				}
			}
			if (!encontrado)
			{
				if (INDICADOR_RECTIFICA.equals(mapValor.get("indica")))
				{
					mapValor.put("indica", INDICADOR_NUEVO);
					lstResultado.add(new HashMap<String, Object>(mapValor));
				}
			}
		}

		return lstResultado;
	}

	/**
	 * Compara list.
	 *
	 * @param lstOriginal
	 *          the lst original
	 * @param lstActual
	 *          the lst actual
	 * @param mapClavePrimaria
	 *          the map clave primaria
	 * @return the list
	 */
	public List<Map<String, Object>> comparaList(
			List<Map<String, Object>> lstOriginal,
			List<Map<String, Object>> lstActual,
			Map<String, Object> mapClavePrimaria)
	{
		return this.comparaList(lstOriginal, lstActual, mapClavePrimaria, true, false);
	}

	/**
	 * Extrae la diferencia de dos listas de mapas extraendo solo las diferencias
	 * por Map segun la clave en mapClavePrimaria.
	 *
	 * @param lstOriginal
	 *          the lst original
	 * @param lstActual
	 *          the lst actual
	 * @param mapClavePrimaria
	 *          the map clave primaria
	 * @param activarConversionNombresListaOriginal
	 *          the activar conversion nombres lista original
	 * @param activarConversionNombresListaActual
	 *          the activar conversion nombres lista actual
	 * @return the list
	 */
	public List<Map<String, Object>> comparaList(
			List<Map<String, Object>> lstOriginal,
			List<Map<String, Object>> lstActual,
			Map<String, Object> mapClavePrimaria,
			Boolean activarConversionNombresListaOriginal,
			Boolean activarConversionNombresListaActual)
	{
		return comparaList(lstOriginal, lstActual, mapClavePrimaria, activarConversionNombresListaOriginal,
				activarConversionNombresListaActual, false, false);
	}

	/**
	 * Extrae la diferencia de dos listas de mapas extraendo solo las diferencias
	 * por Map segun la clave en mapClavePrimaria.
	 *
	 * @param lstOriginal
	 *          the lst original
	 * @param lstActual
	 *          the lst actual
	 * @param mapClavePrimaria
	 *          the map clave primaria
	 * @param activarConversionNombresListaOriginal
	 *          the activar conversion nombres lista original
	 * @param activarConversionNombresListaActual
	 *          the activar conversion nombres lista actual
	 * @param agregarElementosNuevos
	 *          the agregar elementos nuevos
	 * @param activarComparacionEstricta
	 *          the activar comparacion estricta
	 * @return the list
	 */
	public List<Map<String, Object>> comparaList(
			List<Map<String, Object>> lstOriginal,
			List<Map<String, Object>> lstActual,
			Map<String, Object> mapClavePrimaria,
			Boolean activarConversionNombresListaOriginal,
			Boolean activarConversionNombresListaActual,
			Boolean agregarElementosNuevos,
			Boolean activarComparacionEstricta)
	{
		List<Map<String, Object>> lstResultado = new ArrayList<Map<String, Object>>();
		Map<String, Object> mapDatosClavePrimaria = null;
		boolean banderaClave = true;

		if (CollectionUtils.isEmpty(lstOriginal) && CollectionUtils.isEmpty(lstActual))
		{
			return lstActual;
		}
		if (!CollectionUtils.isEmpty(lstOriginal))
		{
			for (Map<String, Object> mapaOriginal : lstOriginal)
			{
				mapDatosClavePrimaria = new HashMap<String, Object>();
				Map<String, Object> mapItem = null;

				// Se recoge los valores para la clave
				for (Entry<String, Object> mapClave : mapClavePrimaria.entrySet())
				{
					mapDatosClavePrimaria.put(mapClave.getKey(), mapaOriginal.get(mapClave.getKey()));

				}

				for (Map<String, Object> mapaActual : lstActual)
				{
					banderaClave = true;
					for (Entry<String, Object> mapClave : mapClavePrimaria.entrySet())
					{
						if (!mapDatosClavePrimaria.get(mapClave.getKey()).toString().equals(
								mapaActual.get(mapClave.getKey()).toString()))
						{
							banderaClave = false;
							break;
						}
					}
					if (banderaClave)
					{

						if (activarComparacionEstricta)
						{
							mapItem = comparaMapEstricto(mapaOriginal, mapaActual, activarConversionNombresListaOriginal,
									activarConversionNombresListaActual, mapClavePrimaria);
						}
						else
						{
							mapItem = comparaMap(mapaOriginal, mapaActual, activarConversionNombresListaOriginal,
									activarConversionNombresListaActual, mapClavePrimaria);
						}

					}
					if (mapItem != null && mapItem.size() > 0)
					{
						mapItem.putAll(mapDatosClavePrimaria);
						lstResultado.add(mapItem);
						break;
					}
				}
			}
		}
		else
		{
			lstResultado = Utilidades.copiarLista((List) lstActual);
		}

		if (agregarElementosNuevos && !CollectionUtils.isEmpty(lstOriginal))
		{
			lstResultado = agregarNuevosMapas(lstResultado, lstActual, mapClavePrimaria,
					activarConversionNombresListaActual);
		}

		return lstResultado;
	}

	/**
	 * Agregar nuevos mapas.
	 *
	 * @param lstOriginal
	 *          the lst original
	 * @param lstActual
	 *          the lst actual
	 * @param mapClavePrimaria
	 *          the map clave primaria
	 * @param activarConversionNombresListaActual
	 *          the activar conversion nombres lista actual
	 * @return the list
	 */
	private List<Map<String, Object>> agregarNuevosMapas(
			List<Map<String, Object>> lstOriginal,
			List<Map<String, Object>> lstActual,
			Map<String, Object> mapClavePrimaria,
			Boolean activarConversionNombresListaActual)
	{
		List<Map<String, Object>> lstResultado = new ArrayList<Map<String, Object>>();
		lstResultado.addAll(lstOriginal);

		Map<String, Object> mapDatosClavePrimaria = null;
		boolean encontrado = false;

		for (Map<String, Object> mapaEval : lstActual)
		{
			mapDatosClavePrimaria = new HashMap<String, Object>();
			Map<String, Object> mapItem = null;

			// Se recoge los valores para la clave
			for (Entry<String, Object> mapClave : mapClavePrimaria.entrySet())
			{
				mapDatosClavePrimaria.put(mapClave.getKey(), mapaEval.get(mapClave.getKey()));

			}

			if (lstOriginal != null && lstOriginal.size() > 0)
			{
				for (Map<String, Object> mapaOriginal : lstOriginal)
				{
					encontrado = true;
					for (Entry<String, Object> mapClave : mapClavePrimaria.entrySet())
					{
						if (!mapDatosClavePrimaria.get(mapClave.getKey()).toString().equals(
								mapaOriginal.get(mapClave.getKey()).toString()))
						{
							encontrado = false;
							break;
						}
					}

					if (encontrado)
					{
						break;
					}
				}
			}
			else
			{
				encontrado = false;
			}

			if (!encontrado)
			{
				if (activarConversionNombresListaActual)
				{
					mapItem = this.cambiaNombreMap(mapaEval);
				}
				else
				{
					mapItem = new HashMap<String, Object>();
					mapItem.putAll(mapaEval);
				}

				if (mapItem != null && mapItem.size() > 0)
				{
					mapItem.putAll(mapDatosClavePrimaria);

					// Se coloca los datos Originales en el mapa
					mapItem.put(this.keyDatosOriginales, null);
					// Se coloca los datos de la clave separados en el key clave.
					mapItem.put(this.keyPK, this.obtenerDatosPK(mapItem, mapDatosClavePrimaria));

					lstResultado.add(mapItem);
					break;
				}
			}
		}

		return lstResultado;
	}

	/**
	 * Compara map.
	 *
	 * @param mapaOriginal
	 *          the mapa original
	 * @param mapaActualizado
	 *          the mapa actualizado
	 * @param mapaClavePrimaria
	 *          the mapa clave primaria
	 * @return the map
	 */
	public Map<String, Object> comparaMap(
			Map<String, Object> mapaOriginal,
			Map<String, Object> mapaActualizado,
			Map<String, Object> mapaClavePrimaria)
	{
		return comparaMap(mapaOriginal, mapaActualizado, false, false, mapaClavePrimaria);
	}

	/**
	 * Metodo que obtiene un mapa con los datos originales y sus cambios actuales,
	 * sin interesar la clave primaria. Este metodo no es usado.
	 *
	 * @param mapa1
	 *          the mapa1
	 * @param mapa2
	 *          the mapa2
	 * @return the map
	 * @deprecated 01-03-2010
	 */
	public Map<String, Object> comparaMap(Map<String, Object> mapa1, Map<String, Object> mapa2)
	{
		return comparaMap(mapa1, mapa2, false, false, new HashMap<String, Object>());
	}

	/**
	 * Metodo que nos permite comparar dos mapas obteniendo un mapa original con
	 * los valores actualizados. No compara Mapas
	 *
	 * @param mapaOriginal
	 *          the mapa original
	 * @param mapaActualizado
	 *          the mapa actualizado
	 * @param activarConversionNombresVistamapaOriginal
	 *          the activar conversion nombres vistamapa original
	 * @param activarConversionNombresVistamapaActualizado
	 *          the activar conversion nombres vistamapa actualizado
	 * @param mapaClavePrimaria
	 *          the mapa clave primaria
	 * @return the map
	 */
	public Map<String, Object> comparaMap(
			Map<String, Object> mapaOriginal,
			Map<String, Object> mapaActualizado,
			Boolean activarConversionNombresVistamapaOriginal,
			Boolean activarConversionNombresVistamapaActualizado,
			Map<String, Object> mapaClavePrimaria)
	{
		Boolean banderaEsClave = false;
		Map<String, Object> mapResultado = new HashMap<String, Object>();
		Map<String, Object> mapaOriginalConvertidoNombres = new HashMap<String, Object>();
		Map<String, Object> mapaActualizadoConvertidoNombres = new HashMap<String, Object>();

		if (activarConversionNombresVistamapaOriginal)
		{
			mapaOriginalConvertidoNombres = this.cambiaNombreMap(mapaOriginal);
		}
		else
		{
			mapaOriginalConvertidoNombres.putAll(mapaOriginal);
		}
		if (activarConversionNombresVistamapaActualizado)
		{
			mapaActualizadoConvertidoNombres = this.cambiaNombreMap(mapaActualizado);
		}
		else
		{
			mapaActualizadoConvertidoNombres.putAll(mapaActualizado);
		}

		for (Entry<String, Object> entrada1 : mapaOriginalConvertidoNombres.entrySet())
		{
			if ((entrada1.getValue() instanceof Map) || (entrada1.getValue() instanceof List))
			{

				continue;
			}
			banderaEsClave = false;
			for (Entry<String, Object> entradaKey : mapaClavePrimaria.entrySet())
			{
				if (entrada1.getKey().toString().trim().equalsIgnoreCase(entradaKey.getKey().toString().trim()))
				{
					banderaEsClave = true;
					break;
				}
			}
			if (banderaEsClave)
			{

				mapResultado.put(entrada1.getKey().toString().trim(), entrada1.getValue());
				banderaEsClave = false;
				continue;
			}
			// existe el key dentro del segundo Map.
			if (mapaActualizadoConvertidoNombres.containsKey(entrada1.getKey()))
			{

				// si alguno de los dos valores es nulo y el otro no.
				if (!(entrada1.getValue() == null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) == null) &&
						((entrada1.getValue() == null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) != null) ||
								(entrada1.getValue() != null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) == null)))
				{
					mapResultado.put(entrada1.getKey(), mapaActualizadoConvertidoNombres.get(entrada1.getKey()));
				}
				else if (entrada1.getValue() != null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) != null)
				{
					// ninguno de los valores es nulo
					if ((entrada1.getValue().toString().trim().equals(this.cadenaNula) &&
							mapaActualizadoConvertidoNombres.get(entrada1.getKey()).toString().trim().equals(this.cadenaNula)) ||
							(entrada1.getValue().toString().trim().equals(this.cadenaNula) &&
									mapaActualizadoConvertidoNombres.get(entrada1.getKey()).toString().trim().equals(this.cadenaNula)))
					{

						mapResultado.put(entrada1.getKey(), mapaActualizadoConvertidoNombres.get(entrada1.getKey()));
						// SI viene cadena "null" se setea el valor null para efectos de
						// grabado en base de datos
						if (mapaActualizadoConvertidoNombres.get(entrada1.getKey()).toString().trim().equals(this.cadenaNula))
						{

							mapResultado.put(entrada1.getKey(), null);
							continue;
						}
					}
					// en caso exista y sean diferentes
					if (!(entrada1.getValue().toString().trim().equals(mapaActualizadoConvertidoNombres
							.get(entrada1.getKey())
							.toString()
							.trim())))
					{

						mapResultado.put(entrada1.getKey(), mapaActualizadoConvertidoNombres.get(entrada1.getKey()));
					}
				}

			}// Fin if existe key dentro de segundo Map.
		}
		// obtenemos datos para RECTIOFICIO
		if (mapaClavePrimaria != null && mapaClavePrimaria.size() > 0)
		{
			// Se coloca los datos Originales en el mapa
			mapResultado.put(this.keyDatosOriginales, this.obtenerDiferencialAntiguo(mapResultado, mapaClavePrimaria,
					mapaOriginalConvertidoNombres));
			// Se coloca los datos de la clave separados en el key clave.
			mapResultado.put(this.keyPK, this.obtenerDatosPK(mapaOriginalConvertidoNombres, mapaClavePrimaria));
		}
		return mapResultado;
	}

	/**
	 * Metodo que nos permite comparar dos mapas obteniendo un mapa original con
	 * los valores actualizados, tratando de comparar cada elemento del mapa con
	 * el metodo equals de su respectiva clase (Integer, Long, Double, etc). No
	 * compara Mapas
	 *
	 * @param mapaOriginal
	 *          the mapa original
	 * @param mapaActualizado
	 *          the mapa actualizado
	 * @param activarConversionNombresVistamapaOriginal
	 *          the activar conversion nombres vistamapa original
	 * @param activarConversionNombresVistamapaActualizado
	 *          the activar conversion nombres vistamapa actualizado
	 * @param mapaClavePrimaria
	 *          the mapa clave primaria
	 * @return the map
	 */
	public Map<String, Object> comparaMapEstricto(
			Map<String, Object> mapaOriginal,
			Map<String, Object> mapaActualizado,
			Boolean activarConversionNombresVistamapaOriginal,
			Boolean activarConversionNombresVistamapaActualizado,
			Map<String, Object> mapaClavePrimaria)
	{
		Boolean banderaEsClave = false;
		Map<String, Object> mapResultado = new HashMap<String, Object>();
		Map<String, Object> mapaOriginalConvertidoNombres = new HashMap<String, Object>();
		Map<String, Object> mapaActualizadoConvertidoNombres = new HashMap<String, Object>();

		if (activarConversionNombresVistamapaOriginal)
		{
			mapaOriginalConvertidoNombres = this.cambiaNombreMap(mapaOriginal);
		}
		else
		{
			mapaOriginalConvertidoNombres.putAll(mapaOriginal);
		}
		if (activarConversionNombresVistamapaActualizado)
		{
			mapaActualizadoConvertidoNombres = this.cambiaNombreMap(mapaActualizado);
		}
		else
		{
			mapaActualizadoConvertidoNombres.putAll(mapaActualizado);
		}

		for (Entry<String, Object> entrada1 : mapaOriginalConvertidoNombres.entrySet())
		{
			if ((entrada1.getValue() instanceof Map) || (entrada1.getValue() instanceof List))
			{

				continue;
			}
			banderaEsClave = false;
			for (Entry<String, Object> entradaKey : mapaClavePrimaria.entrySet())
			{
				if (entrada1.getKey().toString().trim().equalsIgnoreCase(entradaKey.getKey().toString().trim()))
				{
					banderaEsClave = true;
					break;
				}
			}
			if (banderaEsClave)
			{

				mapResultado.put(entrada1.getKey().toString().trim(), entrada1.getValue());
				banderaEsClave = false;
				continue;
			}
			// existe el key dentro del segundo Map.
			if (mapaActualizadoConvertidoNombres.containsKey(entrada1.getKey()))
			{

				// si alguno de los dos valores es nulo y el otro no.
				if (!(entrada1.getValue() == null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) == null) &&
						((entrada1.getValue() == null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) != null) ||
								(entrada1.getValue() != null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) == null)))
				{

					mapResultado.put(entrada1.getKey(), mapaActualizadoConvertidoNombres.get(entrada1.getKey()));
				}
				else if (entrada1.getValue() != null && mapaActualizadoConvertidoNombres.get(entrada1.getKey()) != null)
				{
					// ninguno de los valores es nulo

					if (!Utilidades.equalsByClass(entrada1.getValue(), mapaActualizadoConvertidoNombres.get(entrada1.getKey())))
					{

						mapResultado.put(entrada1.getKey(), mapaActualizadoConvertidoNombres.get(entrada1.getKey()));
					}
				}

			}// Fin if existe key dentro de segundo Map.
		}
		// obtenemos datos para RECTIOFICIO
		if (mapaClavePrimaria != null && mapaClavePrimaria.size() > 0)
		{
			// Se coloca los datos Originales en el mapa
			mapResultado.put(this.keyDatosOriginales, this.obtenerDiferencialAntiguo(mapResultado, mapaClavePrimaria,
					mapaOriginalConvertidoNombres));
			// Se coloca los datos de la clave separados en el key clave.
			mapResultado.put(this.keyPK, this.obtenerDatosPK(mapaOriginalConvertidoNombres, mapaClavePrimaria));
		}
		return mapResultado;
	}


	/**
	 * Metodo que retira los prefijos HDN_, TXT_, CBX_, TA_, SEL_ del map mapa y
	 * convierte a mayusculas los KEYS.
	 *
	 * @param mapa
	 *          the mapa
	 * @return the map
	 */
	private Map<String, Object> cambiaNombreMap(Map<String, Object> mapa)
	{
		Map<String, Object> mapResultado = new HashMap<String, Object>();
		Iterator it1 = mapa.entrySet().iterator();// set de par de valores en mapa
		while (it1.hasNext())
		{
			Map.Entry lvEntry = (Entry) it1.next();
			if (lvEntry.getKey().toString().trim().length() > 3)
			{
				if (enumPrefijos.HDN_.toString().equals(lvEntry.getKey().toString().toUpperCase().substring(0, 4)))
				{
					mapResultado.put(lvEntry.getKey().toString().toUpperCase().substring(4), lvEntry.getValue());
					continue;
				}
				if (enumPrefijos.TXT_.toString().equals(lvEntry.getKey().toString().toUpperCase().substring(0, 4)))
				{
					mapResultado.put(lvEntry.getKey().toString().toUpperCase().substring(4), lvEntry.getValue());
					continue;
				}
				if (enumPrefijos.CBX_.toString().equals(lvEntry.getKey().toString().toUpperCase().substring(0, 4)))
				{
					mapResultado.put(lvEntry.getKey().toString().toUpperCase().substring(4), lvEntry.getValue());
					continue;
				}
				if (enumPrefijos.SEL_.toString().equals(lvEntry.getKey().toString().toUpperCase().substring(0, 4)))
				{
					mapResultado.put(lvEntry.getKey().toString().toUpperCase().substring(4), lvEntry.getValue());
					continue;
				}
				if (enumPrefijos.TA_.toString().equals(lvEntry.getKey().toString().toUpperCase().substring(0, 3)))
				{
					mapResultado.put(lvEntry.getKey().toString().toUpperCase().substring(3), lvEntry.getValue());
					continue;
				}
			}
			mapResultado.put(lvEntry.getKey().toString().toUpperCase(), lvEntry.getValue());
		}
		return mapResultado;
	}

	/**
	 * Metodo que permite obtener los datos antiguos que seran modificados con los
	 * datos en mapDiferencia, se obtienen a partir de mapAntiguo.
	 *
	 * @param mapDiferencia
	 *          the map diferencia
	 * @param keysPK
	 *          the keys pk
	 * @param mapAntiguo
	 *          the map antiguo
	 * @return mapResultado.
	 */
	public Map<String, Object> obtenerDiferencialAntiguo(
			Map<String, Object> mapDiferencia,
			Map<String, Object> keysPK,
			Map<String, Object> mapAntiguo)
	{
		Map<String, Object> mapResultado = null;
		for (Entry<String, Object> entradaDiferencia : mapDiferencia.entrySet())
		{
			if (keysPK.containsKey(entradaDiferencia.getKey()))
			{

				continue;
			}
			if (mapResultado == null)
			{
				mapResultado = new HashMap<String, Object>();
			}
			mapResultado.put(entradaDiferencia.getKey(), mapAntiguo.get(entradaDiferencia.getKey()));
		}
		return mapResultado;
	}

	/**
	 * Metodo que nos permite obtener los datos de mapaOriginal que coinciden con
	 * las claves contenidas en keysPK.
	 *
	 * @param mapaOriginal
	 *          the mapa original
	 * @param keysPK
	 *          the keys pk
	 * @return null si no hay datos en mapaOriginal mapResultado.
	 */
	public Map<String, Object> obtenerDatosPK(Map<String, Object> mapaOriginal, Map<String, Object> keysPK)
	{
		Map<String, Object> mapResultado = null;
		if (mapaOriginal != null && keysPK != null && keysPK.size() > 0 && mapaOriginal.size() > 0)
		{
			mapResultado = new HashMap<String, Object>();
			for (Entry<String, Object> entradaPK : keysPK.entrySet())
			{
				mapResultado.put(entradaPK.getKey(), mapaOriginal.get(entradaPK.getKey()));
			}
			return mapResultado;
		}
		return mapResultado;
	}


	/**
	 * Metodo que nos determina si existen datos cambiados.
	 *
	 * @param registro
	 *          the registro
	 * @return true, if successful
	 */
	public static boolean esDataCambiada(Map<String, Object> registro)
	{
		boolean res = false;

		if (registro.get("dataOriginal") != null)
		{
			res = (((Map) registro.get("dataOriginal")).entrySet().size() > 0);
		}

		return res;
	}

	/**
	 * Checks if is key equal.
	 *
	 * @param mapKeyOld
	 *          the map key old
	 * @param mapKeyNew
	 *          the map key new
	 * @param mapKeys
	 *          the map keys
	 * @return true, if is key equal
	 */
	public static boolean isKeyEqual(
			Map<String, Object> mapKeyOld,
			Map<String, Object> mapKeyNew,
			Map<String, Object> mapKeys)
	{
		boolean isEqual = true;
		if (CollectionUtils.isEmpty(mapKeys) || CollectionUtils.isEmpty(mapKeyOld) || CollectionUtils.isEmpty(mapKeyNew))
			return false;
		for (Entry<String, Object> entry : mapKeys.entrySet())
		{
			if (!mapKeyOld.containsKey(entry.getKey()))
				return false;
			if (!mapKeyNew.containsKey(entry.getKey()))
				return false;
		}
		for (Entry<String, Object> entry : mapKeys.entrySet())
		{
			if (!(mapKeyOld.get(entry.getKey()).toString().trim().equals(mapKeyNew.get(entry.getKey()).toString().trim())))
			{
				isEqual = false;
				break;
			}
		}
		return isEqual;
	}

	/**
	 * rtineo mejoras
	 * @param mapValor
	 * @param mapKey
	 * @return obtiene el identificador en base al mapkey
	 */
	public static String getIdentificador(Map<String,Object> mapValor, Map<String,Object> mapKey){
		StringBuilder stringBuilder = new StringBuilder();
		for(Entry<String, Object> entry : mapKey.entrySet()){
			stringBuilder.append(mapValor.get(entry.getKey())).append("-");
		}
		stringBuilder.deleteCharAt(stringBuilder.length()-1);
		return stringBuilder.toString();
	}

	/**
	 * rtineo mejoras
	 * @param mapValor
	 * @param mapKey
	 * @return retorna tru si todos los key del mapKey estan en el mapValor
	 */
	public static boolean iskeyMapValorInkeyMap(Map<String,Object> mapValor, Map<String,Object> mapKey){
		boolean retu = true;
		for(Entry<String, Object> entry : mapKey.entrySet()){
			if(!mapValor.containsKey(entry.getKey())){
				return false;
			}
		}
		return retu;
	}

	/**
	 * Elimina los valores del pk de la lista.
	 *
	 * @param itemNew
	 *          the item new
	 * @param mapClave
	 *          the map clave
	 * @return the map
	 */
	public static Map<String, Object> removerDatosPK(Map<String, Object> itemNew,
			Map<String, Object> mapClave)
	{
		Map<String, Object> mapRectificadoData = new HashMap<String, Object>(itemNew);
		for (Object keyClave : mapClave.keySet())
		{
			mapRectificadoData.remove(keyClave);
		}
		return mapRectificadoData;
	}
}
