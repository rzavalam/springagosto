package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.RegularizacionBean;
/*INICIO PAS20124E600000358*/
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;


/**
 * The Interface DiligenciaService.
 */
@SuppressWarnings({ "rawtypes" })
public interface DiligenciaService
{

  /**
   * Metodo que nos permite obtener todas las diligencias de un Documento RPH..
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List obtenerDiligencias(Map PkDocu) throws ServiceException;

  List obtenerDiligenciaDespachoSustentoModificado(Map PkDocu) throws ServiceException;

  /**
   * Obtener comunicaciones portal.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<Map<String, Object>> obtenerComunicacionesPortal(Map<String, String> PkDocu) throws ServiceException;
  //MOL PASE280
  /**
   * validar diligencia despacho por diferencia de tributo.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  Map<String, Object> validarDiligenciaConDiferenciaTributo(Map params) throws ServiceException;
//FIN MOL
  /**
   * Grabar diligencia despacho.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  void grabarDiligenciaDespacho(Map params) throws ServiceException;

  /**
   * Validar plazo.
   *
   * @param params
   *          the params
   * @return the boolean
   * @throws ServiceException
   *           the service exception
   */
  Boolean validarPlazo(Map params) throws ServiceException;

  /**
   * Realizar datado.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  @Deprecated
  void realizarDatado(Map params) throws ServiceException;

  /**
   * Validar datado.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  Map<String, Object> validarDatado(Map params) throws ServiceException;


  /**
   * Grabar comunicacion.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  void grabarComunicacion(Map<String, Object> params) throws ServiceException;

  /**
   * Grabar revision.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  void grabarRevision(Map<String, Object> params) throws ServiceException;

  /**
   * Registra la diligencia de tipo 01-Revision catalogo 356..
   *
   * @param params
   *          Map con datos de la diligencia
   * @throws ServiceException
   *           the service exception
   */
  void grabarDiligenciaByInicioRevision(Map<String, Object> params) throws ServiceException;

  /**
   * Insertar diligencia.
   *
   * @param mapaDiligencia
   *          the mapa diligencia
   * @throws ServiceException
   *           the service exception
   */
  void insertarDiligencia(Map<String, Object> mapaDiligencia) throws ServiceException;

  /**
   * Tiene conclusion en proceso.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  Map<String, Object> tieneConclusionEnProceso(Map<String, Object> params) throws ServiceException;

  /**
   * Tiene ampliacion plazo.
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  Map<String, Object> tieneAmpliacionPlazo(Map<String, Object> params) throws ServiceException;

  /**
   * Grabar ampliacion plazo.
   *
   * @param params
   *          the params
   * @throws ServiceException
   *           the service exception
   */
  void grabarAmpliacionPlazo(Map<String, Object> params) throws ServiceException;

  /**
   * Obtener comunicaciones.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<Map<String, Object>> obtenerComunicaciones(Map<String, Object> params) throws ServiceException;

  /**
   * Validar fecha vencimiento.
   *
   * @param codRegimen
   *          the cod regimen
   * @param codAduana
   *          the cod aduana
   * @param tipoOperDespacho
   *          the tipo oper despacho
   * @param fecVenRegimen
   *          the fec ven regimen
   * @param fecNumeracion
   *          the fec numeracion
   * @param fecGarantia
   *          the fec garantia
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
  Map<String, Object> validarFechaVencimiento(
    String codRegimen,
    String codAduana,
    String tipoOperDespacho,
    Date fecVenRegimen,
    Date fecNumeracion,
    Date fecGarantia) throws ServiceException;

  /**
   * Find vehiculo by map.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<DatoVehiculo> findVehiculoByMap(Map<String, Object> params) throws ServiceException;

  /**
   * Find monto gasto by map.
   *
   * @param params
   *          the params
   * @return the list
   * @throws ServiceException
   *           the service exception
   */
  List<DatoMontoGasto> findMontoGastoByMap(Map<String, Object> params) throws ServiceException;

  /**
   * Grabar modificacion diligencia.
   *
   * @param mapaDiligencia
   *          the mapa diligencia
   * @throws ServiceException
   *           the service exception
   */
  void grabarModificacionDiligencia(Map<String, Object> mapaDiligencia) throws ServiceException;


  /**
   * env�o de avisos electr�nicos durante los
   *
   * Notificar observacion.
   * @author asilvala
   *
   * @param descripcion
   *          the descripcion
   * @param codAduana
   *          the cod aduana
   * @param annPresen
   *          the ann presen
   * @param codRegimen
   *          the cod regimen
   * @param numDeclaracion
   *          the num declaracion
   * @param codFuncionario
   *          the cod funcionario
   * @param codUsuario
   *          the cod usuario
   * @param codPlantilla
   *          the cod plantilla
   * @param codTipoAviso
   *          the cod tipo aviso
   * @param tipoUsuario
   *          the tipo usuario
   *
   * @throws ServiceException
   *           the service exception
   *
   */
  public void notificarObservacion(
    String descripcion,
    String codAduana,
    String annPresen,
    String codRegimen,
    String numDeclaracion,
    String codFuncionario,
    String[] codUsuario,
    Integer codPlantilla,
    String codTipoAviso,
    String tipoUsuario,
    String tipo) throws ServiceException;

  
  
  /* P14 - 3006 - dhernandez - Inicio */
  /**
   * Notificacion de Observacion con reporte
   * 
   * @author dhernandez
   * 
   * @param descripcion
   *          the descripcion
   * @param codAduana
   *          the cod aduana
   * @param annPresen
   *          the ann presen
   * @param codRegimen
   *          the cod regimen
   * @param numDeclaracion
   *          the num declaracion
   * @param codFuncionario
   *          the cod funcionario
   * @param codUsuario
   *          the cod usuario          
   * @param codPlantilla
   *          the cod plantilla
   * @param codTipoAviso
   *          the cod tipo aviso
   * @param tipoUsuario
   *          the tipo usuario
   * @param codEstado
   *          the codEstado
   * @param rutaPDF
   *          the rutaPDF
   * @throws ServiceException
   *           the service exception
   *
   */
  public void notificarObservacionReporteAdjunto(    
		  String descripcion,
		  String codAduana,
          String annPresen,
          String codRegimen,
          String numDeclaracion,
          String codFuncionario,
          String[] codUsuario,
          Integer codSecuencia,
          String codTipoAviso,
          String tipoUsuario,
          String codEstado,
          HashMap<String, Object> rutaPDF,String tipo) throws ServiceException;
  
  /**
   * env�o de avisos electr�nicos durante los
   *
   * Notificar observacion.
   * @author dhernandez
   * 
   * @param numCorreDoc
   *          the numCorreDoc 
   * @throws ServiceException
   *           the service exception
   *
   */
  public List<HashMap<String, Object>> obtenerDetalleDocumentosAsociadosParaReporte( String numCorreDoc); 
  
  /**
   * Obtiene el departmanento de elaboracion
   * 
   * @author dhernandez
   * 
   * @param codAduana
   *          Codigo de Aduana
   * @return 
   *
   */
  public String obtenerElaborado(
		  String codAduana);
  
  /**
   * Obtiene el consignatario
   * 
   * @author dhernandez
   * 
   * @param codAduana
   *          the cod aduana
   * @param annPresen
   *          the ann presen
   * @param codRegimen
   *          the cod regimen
   * @param numDeclaracion
   *          the num declaracion
   * @param numCorreDoc
   *          the num corredoc  
   * @return 
   *
   */
  public String obtenerConsignatario(Map<String, Object> params) throws ServiceException;
  
  /**
   * Obtiene el detalle de la notificacion con formato para reporte PDF 
   * 
   * @author dhernandez
   * 
   * @param notificacion
   *          the notificacion
   * @return 
   *
   */
  public HashMap<String,Object> obtenerConsolidadoDetalleNotificacionParaReporte(ComunicacionDescripcion notificacion) throws ServiceException;
  
  /* P14 - 3006 - dhernandez - Fin */ 

	/**
	 * Grabacion de la diligencia desde componentes objetos, se deber�a ir migrado las demas funcionalidades de grabacion.
	 * Es invocada por el orquestador.
	 * @param variablesIngreso
	 * @param declaracion
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> grabarDiligencia (Map<String, Object> variablesIngreso, Declaracion declaracion) throws Exception;


  /**
   *
   * @param paramDiligencia
   * @return
   * @throws ServiceException
   */
  public Integer count(Map<String, Object> paramDiligencia)
    throws ServiceException;

  /**
   *
   * @param numCorreDoc
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> findDuaDiligenciada(String numCorreDoc)
    throws ServiceException;

  /**
   *
   * @param numCorreDoc
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> findDuaRectificada(String numCorreDoc)
      throws ServiceException;

  /**
   * Grabar rectifica manual.
   *
   * @param params
   *          [Map] params
   * @throws ServiceException
   *           the service exception
   */
  public  String grabarRectificaManual (Map params) throws ServiceException;
//RSERRANOV PAS20165E220200076


	/**
	 * Valida numero maximo definido por el parametro (numMaxRegistros) de registros de diligencias
	 * por dia
	 *
	 * @param String numCorreDoc, String codTipDiligencia
	 * @param numMaxRegistros
	 *
	 * @return true cumple false no cumple
	 * @autor: amancillaa
	 */
	public Boolean validarMaximoNumeroDiligenciasRegistradas(String numCorreDoc, String codTipDiligencia, Integer numMaxRegistros) throws ServiceException;

	/**
	 *
	 * @param busquedaDua
	 * @param tipoDiligencia segun catalogo 356 por default
	 *        Si tipoDiligencia=="02Y03" Entonces validara si tiene diligencia de despacho
	 *        para validar la diligencia Despacho debe cumplir tipoDiligencia in ("02","03")
	 *
	 * @return Boolean
	 * @throws ServiceException
	 */
	public Boolean tieneDiligenciaTipo(BusquedaDua busquedaDua, String tipoDiligencia) throws ServiceException;


	/**
   * Cargar datos iniciales b dto map.
   *
   * @param busquedaDua
   *          [BusquedaDua] busqueda dua
   * @param enumVariable
   *          [EnumTablaModel] enum variable
   * @return [Object] object
   * @throws ServiceException
   *           the service exception
   * @author amancillaa
   * @version 1.0
   */
	public Object cargarDatosInicialesBDtoMap(BusquedaDua busquedaDua,EnumTablaModel enumVariable) throws ServiceException;

	public List<Map<String,Object>> selectDiligencia(Map params)  throws ServiceException;

	//P13 JMCV - INICIO
	
	/**
	   * b�squeda de Documentos por Estado de Revisi�n
	   *
	   * @param findbyDocEstRev
	   * @param estadoAsig
	   * @return String object
	   */
	public Map<String, Object> findbyDocEstRev(Long numCorredoc, String estadoAsig);
	
	/**
	   * Valida el Estado del Reconocimineto F�sico de la Mercanc�a 
	   *
	   * @param validarReconocimientoFisico
	   * @param mapDeclaracionActual
	   * @return String 
	*/
	public String validarReconocimientoFisico(Map<String, Object> mapDeclaracionActual);
	
	/**
	   * Graba la Revision del Reconocimiento F�sico del Estado de la Mercanc�a 
	   *
	   * @param grabarRevisionReconocimientoFisico
	   * @param declaracion
	   * @return String 
	*/	
	public String grabarRevisionReconocimientoFisico(Map<String, Object> declaracion);
	
	/**
	   * Valida la Revision del Proceso de Inmovilizaci�n Total de la Mercancia 
	   *
	   * @param grabarRevisionReconocimientoFisico
	   * @param declaracion
	   * @return String 
	*/	
	public String validarRevisionToProcesoDeInmovilizacionTotalDeLaMercancia(Map<String, Object> declaracion);
	//INICIO RIN08
	 public void grabarDiligenciaDespachoAduanaDestino(Map params) throws ServiceException;
	//FIN RIN08


/**INICIO-RIN13**/


	/**
	 * Verifica si existe diligencia
	 * 
	 * @param diligenciaBusqueda
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
	public boolean hasDiligencia(Diligencia diligenciaBusqueda) throws ServiceException;
	
	/**
	 * Verifica si existe diligencia
	 * 
	 * @param mapDiligenciaBusqueda
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
	public boolean hasDiligencia(Map<String, Object> mapDiligenciaBusqueda) throws ServiceException;
	
	/**
	 * Obtiene una diligencia 
	 * de acuerdo a los parametros de b�squeda
	 * 
	 * @param diligenciaBusqueda Parametros de b�squeda
	 * @return diligencia
	 * @author gbecerrav
	 */
	public Diligencia obtenerDiligencia(Diligencia diligenciaBusqueda) throws ServiceException;
	
	/**
	 * Inserta un registro de diligencia 
	 * con campos selectivos
	 * @param diligencia Diligencia a registrar
	 * @return 
	 * @author gbecerrav
	 */
	public void insertarDiligencia(Diligencia diligencia) throws ServiceException;
	
	/**
	 * Inserta un registro de comunicacion 
	 * con campos selectivos
	 * @param comunicacion Comunicacion a registrar
	 * @return 
	 * @author gbecerrav
	 */
	public void insertarComunicacion(Comunicacion comunicacion) throws ServiceException;

/**FIN-RIN13**/	
	
	// RIN16
	// FIXME: CUS110301 lpalominom [inicio]
	/**
	 * Permite obtener los parametros considerados para la validacion del registro de la modificacion de la regularizacion
	 * @param parametros [NUM_CORREDOC, COD_TIPDILIGENCIA]
	 * @return
	 */
	public RegularizacionBean obtenerParametrosSegundaDiligencia(Map<String, Object> parametros);
	
	/**
	 * Permite Actualizar el Resultado de una Diligencia de Regularizacion (Tipo 07)
	 * @param params
	 */
	public void guardarActualizacionRegularizacion(Map<String,Object> params);	
	
	// FIXME: CUS110301 lpalominom [fin]
	
	/***** GGRANADOS RIN16PASE3 INI 
	 * @param usuariosEnvio 
	 * @param contribuyente 
	 * @param codigoNotificacion 
	 * @param codPlantillaNotiDiligRegularizacion 
	 * @param string *****/
	public void notificarComunicacion(Map<String, Object> mapCabDeclaraActual, 
			String descComunicacion,
			String codNroRegistroFuncionario, 
			String usuarioEnvio,
			String razonSocialUsuario);
	public void insertDiligencia(Diligencia diligencia) throws ServiceException;
	/***** GGRANADOS RIN16PASE3 FIN *****/
	
		/* P14 - 3014 - Inicio - dhernandezv*/
		/**
	 *
	 * Obtiene las notificaciones de una declaracion determinada
	 *
	 * @param params
	 *
	 * @return List<Map<String,Object>>
	 * @throws ServiceException
	 */
		
	public  List<ComunicacionDescripcion> obtenerNotificaciones (Map<String, Object> params)  throws ServiceException;
	/* P14 - 3014 - Fin - dhernandezv*/

	/* P14 - 3006 - Inicio - lrodriguezc */

	/** Obtiene la lista de las comunicaciones pendientes de una declaraci�n 
	 * @author lrodriguezc
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<ComunicacionDescripcion> obtenerComunicacionesPendientes (Long numCorreDoc) throws ServiceException;

	/** Formatea el Detalle de la notificaci�n de acuerdo al motivo enviado
	 * @author lrodriguezc
	 * @param listadoDetalle
	 * @param motivoNotificacion
	 * @return
	 * @throws ServiceException
	 */
	public String formatearDetalleNotificacion(Map<String, Object> listadoDetalle, String motivoNotificacion) throws ServiceException;

	/** Obtiene el detalle consolidado de la notificaci�n
	 * @author lrodriguezc
	 * @param notificacion
	 * @return
	 * @throws ServiceException
	 */
	public String obtenerConsolidadoDetalleNotificacion(ComunicacionDescripcion notificacion) throws ServiceException;
		 
	/** Graba los detalles de la comunicacion de tipo notificaci�n de declaracion
	 * @author lrodriguezc
	 * @param params
	 * @throws ServiceException
	 */
	public void grabarDetalleComunicacionNotificacion (Map<String, Object> params) throws ServiceException;
		 
		 
	/** Actualiza la comunicaci�n con su respuesta generada
	 * @author lrodriguezc
	 * @param params
			 * @throws ServiceException
			 */
	public void actualizarRespuestaComunicacionNotificacion (Map<String, Object> params) throws ServiceException;
		 

		
	/* CUS: 3006-01 - Migrado - Rin 13 - Final - lrodriguezc */
	/* P14 - 3006 - Final - lrodriguezc */
	
/*RIN13FSW-INICIO*/
	/**
	 * juazor
	 * */
	public boolean grabarDiligenciaContDespacho(Map<String, Object> paramsDiligencia);
	
		/**
		 * @author juazor
		 * */
		public boolean grabarDiligenciaDescargaParcialDespacho(Map<String, Object> paramsDiligencia);
		
		/**
		 * @author juazor
		 * */

        //esta mal implemenatdo amancilla se quita Rin13FSW
 		//public boolean validarDespachoAnticipado(Map<String, Object> mapaDecla) throws ServiceException;



		/*RIN13-SWF*/
		public void actualizarDeclaracionARevision(Map<String, Object> declaraUpdate) throws ServiceException ;
		 
		 public boolean  existeInformacionICA(Map<String, Object> paramsMap) throws ServiceException;
		 
		 public boolean  findDetDeclaraTipoCargaConsolidadoConsolidado1a1(String NUM_CORREDOC);
		 
			/**
			 * Metodo que  valida una serie de reglas en el caso de via de transporte diferente  a l postal 
			 * 
			 * @param mapCapDeclara
			 * @return String  mensaje
			 * @throws ServiceException
			 */
			public String validarViaTranspDiferentePostal(Map<String, Object> mapCapDeclara) throws ServiceException;
			/**
			 * metodo que valida una serie de reglas  del cual nos retorna un mensaje
			 * 
			 * @param mapCapDeclara
			 * @return String
			 * @throws ServiceException
			 */
			public String validarViaTranspIgualPostal(Map<String, Object> mapCapDeclara) throws ServiceException;
		 
		 
		 //juazor RIN13
		 public String validarValidacionDescargasParciales(Map<String, Object> declaracion);
	
//		<EHR>
		/**
		 * 
		 * @param declaracion
		 * @throws ServiceException
		 */
		public void marcaEstablecimiento(Map<String, Object> declaracion) throws ServiceException;
//		</EHR>
		
		//RIN13
		public String obtenerConsignatario(String codAduana, String annPresen, String codRegimen, String numDeclaracion, String numCorreDoc);
		public void grabarEnProceso(Map<String, Object> params) throws ServiceException;
		
/*RIN13FSW-FIN*/

	/*INICIO - RIN 14*/
	public String validarDocumentosControlAutorizantes(Map params);
	/*FIN - RIN 14*/
	
	/*inicio gdlr*/
	public String validarViaTranspDiferentePostal(Map<String, Object> mapaDecla, List<Map<String, Object>> series) throws ServiceException;
	/*fin gdlr*/

      /* PAS20145E220000529 INICIO GGRANADOS */
	public ObjectResponseUtil validarResolucion(List<ResCabBean> lstResoluciones, Map<String, Object> mapCabDeclara);
	/* PAS20145E220000529 FIN GGRANADOS */
	
		// Inicio P46 3006
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion
	 */
	String validarDocAutorizanteDonacionDiligencia(Map<String, Object> camposValidar);
	// Fin P46 3006
	//PASE 153
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo Incentivo Migratorio
	 */
	String validarDocAutorizanteIncentivoMigratorio(Map<String, Object> camposValidar);
	
	/**P46**/
	public String obtenerTipoDiligencia(Map<String,Object> params);
	/**FIN P46**/
	//		<ERUESTAA> RIN 10 3006
		/**
		 * @author eruestaa
		 * @param mapMensaje
		 * @throws ServiceException
		 */
		public void grabarNotificacionesLCVP(Map<String, Object> mapMensaje) throws ServiceException;
		
		/**
		 * 
		 * @param numCorredoc: numero correlativo de la DUA
		 * @param tipoParticipante tipo participante de la tabla PARTICIPANTE_DOC
		 * @return retorna  la  razon social de la tabla	PARTICIPANTE_DOC
		 * @throws ServiceException
		 */
		public String obtenerAgentesBeneficiarios(String numCorredoc, String tipoParticipante)  throws ServiceException;

	//ggranados 179
	ObjectResponseUtil grabarRevisionReconocimientoFisicioOficio(Map<String, Object> params) throws ServiceException;
	
	//ggranados rollback regu
	Map<String, Object> grabarDiligenciaRegularizacion(Map<String, Object> params) throws Exception;

		
//		</ERUESTAA> RIN 10 3006

//P34 AMANCILLA
  public Map  obtenerParticipante(String numSecParticipante);

		//inicio P21-P22
		public Map<String,Object> validarActualizacionConclusion(Map params) throws ServiceException;
		
		public Map<String,Object> validarActualizacionDestino(Map params) throws ServiceException;
		
		 /**
		   * Grabar diligencia conclusion.
		   *
		   * @param params
		   *          the params
		   * @throws ServiceException
		   *           the service exception
		   */
		public void grabarConclusionDespacho(Map mapValidacion) throws ServiceException;
		
		//fin P21-P22
		//P14-diligencia de conclusion de despacho correccion para se muestre el detalle en el consulta de la notificacion
		public String obtenerConsultaDetalleNotificacion(Comunicacion notificacion) throws ServiceException;
		/**PAS20155E220100038 inicio*/
		public void registrarDetRectiOficio(Map mapRectif, String tipDilig, Long numCorredoc, String codTabla);
		/**PAS20155E220100038 fin*/

		//pase 427
 		public void notificarObserMercaDispuesta(
		    String descripcion,
		    String codAduana,
		    String annPresen,
		    String codRegimen,
		    String numDeclaracion,
		    String codFuncionario,
		    String[] codUsuario,
		    Integer codPlantilla,
		    String codTipoAviso,
		    String tipoUsuario,
		    String tipo) throws ServiceException;
 	
 		/*inicio P46-PAS20155E410000032-[jlunah] BUG 25276*/
 		/**
 		 * Metodo que permite realizar las validaciones necesarias cuando se intenta
 		 * agregar un documento autorizante de tipo donacion para una declaracion sin cancelar
 		 */
 		public String validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(Map<String, Object> camposValidar);
 		/*fin P46-PAS20155E410000032-[jlunah] BUG 25276*/

 		
		public String validarRectiTieneExpedienteContingentes( Map<String, Object> mapaCabDeclara, Long numeroCorrelativoSolicitud);
		
		//csantillan PAS20181U220200069 
		public void insertarResolucion(String nroCorrelativoDUA, String codTipOper, String codTipDocAso, String numeroExpediente, String aduanaExpediente,
		        String anioExpediente, String fechaExpediente, String fechaFinExpediente, String codAreaExpediente);
		
 	//gg vuce
    List<Map<String, Object>> obtenerDocumentoControlAutorizanteSerieACopiar(Long numCorreDoc, 
			Integer numSecDoc, String codTipOper, List<Long> lstSeriesACopiarDocumentoControl);
    List<Long> obtenerSeriesConCopiaDocAut(List<Map<String, Object>> lstDetAutorizacionCopiados);
		void grabarComunicacionCompleta(Map<String, Object> params) throws Exception;
	String obtenerDescripcionCatalogo(String codCatalogo, String codDataCat);
	
	public void actualizarDiligenciaDuaJefeDestino(Long numCorredoc);

//PAS20181U220200056
	public void registroUsoCertificadoOrigenElectronico(Map<String, Object> mapCerti , Map declaracion, String codTransaccion);		

	//PAS20181U220200073
	public Diligencia obtenerDiligenciaPorPk(Map<String,Object> params);		

		
}
