package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;

/**
 * Permite enviar datos desde respuesta.
 *
 * @author wmostacero
 *
 */
public class ObjectResponseUtil implements Serializable
{

  private static final long   serialVersionUID = 1L;

  private List<MensajeBean>   mensajes;

  private Map<String, Object> datos;

  private Boolean             respuesta;

  /**
   * Permite indicar si el objeto respuesta posee algun error dentro de sus
   * mensajes.
   *
   * @return the boolean
   */
  public Boolean poseeError()
  {
    Boolean bandera = false;
    if (!CollectionUtils.isEmpty(mensajes))
    {
      for (MensajeBean bean : mensajes)
      {
        if (bean.isError())
        {
          bandera = true;
          break;
        }
      }
    }
    return bandera;
  }

  /**
   * Permite adherir un mensaje a la lista de mensajes del Objeto respuesta.
   *
   * @param mBean
   *          the m bean
   */
  public void addMensaje(MensajeBean mBean)
  {
    if (CollectionUtils.isEmpty(mensajes))
    {
      mensajes = new ArrayList<MensajeBean>();
    }
    mensajes.add(mBean);
  }

  /**
   * Pemrite adherir un dato al objeto respuesta.
   *
   * @param key
   *          the key
   * @param objeto
   *          the objeto
   */
  public void addDato(String key, Object objeto)
  {
    if (CollectionUtils.isEmpty(datos))
    {
      datos = new HashMap<String, Object>();
    }
    datos.put(key, objeto);
  }

  /**
   * Gets the mensajes.
   *
   * @return the mensajes
   */
  public List<MensajeBean> getMensajes()
  {
    return mensajes;
  }

  /**
   * Sets the mensajes.
   *
   * @param mensajes
   *          the new mensajes
   */
  public void setMensajes(List<MensajeBean> mensajes)
  {
    this.mensajes = mensajes;
  }

  /**
   * Gets the datos.
   *
   * @return the datos
   */
  public Map<String, Object> getDatos()
  {
    return datos;
  }

  /**
   * Sets the datos.
   *
   * @param datos
   *          the datos
   */
  public void setDatos(Map<String, Object> datos)
  {
    this.datos = datos;
  }

  /**
   * Gets the respuesta.
   *
   * @return the respuesta
   */
  public Boolean getRespuesta()
  {
    return respuesta;
  }

  /**
   * Sets the respuesta.
   *
   * @param respuesta
   *          the new respuesta
   */
  public void setRespuesta(Boolean respuesta)
  {
    this.respuesta = respuesta;
  }
}
