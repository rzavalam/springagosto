package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCertificadoOrigen;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtraAduana;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.CollectionUtil;//RIN10
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;



/**
 * The Class GetDeclaracionHashMapToDeclaracionObjectHelper.
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class GetDeclaracionHashMapToDeclaracionObjectHelper
{

	protected final Log   log = LogFactory.getLog(getClass());

	private static GetDeclaracionHashMapToDeclaracionObjectHelper instance;
	private FabricaDeServicios fabricaDeServicios;

	/**P28 Part2*/
	//P34 AFMA private FabricaDeServicios fabrica;
	/**FIN P28 Part2*/
	public static final String  RECTIFICACION   = "R";//RIN10

	public static final String  CONCLUSION   = "C";   //P21-P22


	/**
	 * Gets the single instance of GetDeclaracionHashMapToDeclaracionObjectHelper.
	 *
	 * @return single instance of GetDeclaracionHashMapToDeclaracionObjectHelper
	 */
	public static GetDeclaracionHashMapToDeclaracionObjectHelper getInstance()
	{
		if (instance == null)
			instance = new GetDeclaracionHashMapToDeclaracionObjectHelper();
		return instance;
	}

	/**
	 * Builds the participante.
	 *
	 * @param mapParticipante the map participante
	 * @return the participante
	 */
	public Participante buildParticipante(Map mapParticipante)
	{
		Participante participante = new Participante();

		if (mapParticipante.containsKey("NUM_DOCIDENT"))
			participante.setNumeroDocumentoIdentidad((java.lang.String) mapParticipante.get("NUM_DOCIDENT"));

		if (mapParticipante.containsKey("COD_TIPPARTIC"))
			participante.getTipoParticipante().setCodDatacat((java.lang.String) mapParticipante.get("COD_TIPPARTIC"));

		if (mapParticipante.containsKey("COD_TIPDOC"))
			participante.getTipoDocumentoIdentidad().setCodDatacat((java.lang.String) mapParticipante.get("COD_TIPDOC"));

		if (mapParticipante.containsKey("COD_PAISORIGEN"))
			participante.getPais().setCodDatacat((java.lang.String) mapParticipante.get("COD_PAISORIGEN"));

		if (mapParticipante.containsKey("NOM_RAZONSOCIAL"))
			participante.setNombreRazonSocial((java.lang.String) mapParticipante.get("NOM_RAZONSOCIAL"));

		if (mapParticipante.containsKey("DES_UBIGEOCIUDAD"))
			participante.setCiudad((java.lang.String) mapParticipante.get("DES_UBIGEOCIUDAD"));

		if (mapParticipante.containsKey("DIR_PARTIC"))
			participante.setDireccion((java.lang.String) mapParticipante.get("DIR_PARTIC"));

		if (mapParticipante.containsKey("NUM_TELEFONO"))
			participante.setTelefono((java.lang.String) mapParticipante.get("NUM_TELEFONO"));

		if (mapParticipante.containsKey("NUM_FAX"))
			participante.setFax((java.lang.String) mapParticipante.get("NUM_FAX"));

		if (mapParticipante.containsKey("NOM_EMAIL"))
			participante.setEmail((java.lang.String) mapParticipante.get("NOM_EMAIL"));
		if (mapParticipante.containsKey("NOM_PAGINAWEB"))
			participante.setPaginaWeb((java.lang.String) mapParticipante.get("NOM_PAGINAWEB"));

		return participante;
	}

	/**
	 * Transforma el hasmap de declaracion hacia un objeto declaracion
	 * interponiedo un sufijo = "" a los nombres de los Hasmap dependientes.
	 *
	 * @param mapinput the mapinput
	 * @return the declaracion
	 */
	public Declaracion transform(Map<?, ?> mapinput)
	{
		return transformBySufijo(mapinput, "");
	}
	/** Inicio RIN10 **/
	public Declaracion transformarParaRectificacion(Map<?, ?> mapinput, String sufijo)
	{
		return transformBySufijo(mapinput, sufijo,RECTIFICACION);
	}

	public Declaracion transformBySufijo(Map<?, ?> mapinput, String sufijo){

		return transformBySufijo(mapinput, sufijo,"");
	}
	/** Fin RIN10 **/	
	/**
	 * pase 580 se cambio el nombre y se agrego un parametro par poder transformar
	 * el hashMap de rectificacion cuyos parametros culminan con el sufijo actual
	 *
	 * Transforma el hashmap de declaracion hacia un objeto declaracion
	 * interponiedo un sufijo a los nombres de los Hasmap dependientes.
	 *
	 * @param mapinput the mapinput
	 * @param sufijo the sufijo
	 * @return the declaracion
	 */
	//Inicio RIN10 [Se agrego el campo tipoDiligencia] 
	//public Declaracion transformBySufijo(Map<?, ?> mapinput, String sufijo)
	public Declaracion transformBySufijo(Map<?, ?> mapinput, String sufijo,String tipoDiligencia)
	{

//		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
//		Date fechaHoy = SunatDateUtils.getCurrentDate();
//		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;


		Map mapCabDeclara = (Map) mapinput.get("mapCabDeclara" + sufijo);
		List<Map> lstDetDeclara = (List<Map>) mapinput.get("lstDetDeclara" + sufijo);
		List<Map> lstFacturasSerie = (List<Map>) mapinput.get("lstFacturasSerie" + sufijo);

		//inicio mol Eliminar duplicado de detdeclara 
		if (!CollectionUtils.isEmpty(lstDetDeclara))
		{ 
			List<Map> lstDetAux =  new ArrayList<Map>();
			Integer cantidad = 0;
			List<Map> lstDetAux1 =   new ArrayList<Map>();

			// Map<String, Object> mapSerieItem1 = new HashMap<String, Object>();

			for (Map mapDet: lstDetDeclara)
			{ lstDetAux1.add(mapDet);
			cantidad =0;
			for (Map mapDetAux : lstDetAux1)
			{  if(mapDetAux.containsKey("NUM_SECSERIE")){
				if(mapDet.get("NUM_SECSERIE").equals(mapDetAux.get("NUM_SECSERIE")) ){
					cantidad++;              			  
				}
			}
			}
			if(cantidad==1){
				lstDetAux.add(mapDet);
			}

			}
			lstDetDeclara.clear();
			lstDetDeclara.addAll(lstDetAux);

		}
		//fin mol

		//Inicio RIN10 
		if(RECTIFICACION.equals(tipoDiligencia)){
			lstFacturasSerie = (List<Map>) mapinput.get("lstFacturaSerie" + sufijo);
		}
		//Fin RIN10

		//amancilla P32 RIN7 - RIN13
		List<Map<String,Object>> lstSeriesItemActual = new ArrayList<Map<String,Object>>(); 
		//Inicio RIN10 
		//if(!SunatStringUtils.isEmptyTrim(sufijo)){
		if(RECTIFICACION.equals(tipoDiligencia)){
			//Fin RIN10 
			lstSeriesItemActual = (List<Map<String,Object>>) mapinput.get("lstSeriesItem" + sufijo); 
		}else{
			lstSeriesItemActual = (List<Map<String,Object>>) mapinput.get("lstSeriesItemActual");//jenciso	
		}


		//inicio diligencia rectificacion gmontoya
		//Inicio RIN10
		//if(CollectionUtils.isEmpty(lstFacturasSerie)){
		if(RECTIFICACION.equals(tipoDiligencia)){
			//afma lstFacturasSerie = (List<Map>) mapinput.get("lstFacturaSerie" + sufijo);
			//List<Map> lstComproBPagoActual = (List<Map>) mapinput.get("lstComproBPagoActual");		
			List<Map> lstComproBPago = (List<Map>) mapinput.get("lstComproBPago"+ sufijo);
			List<Map> lstFormaFactu = (List<Map>) mapinput.get("lstFormaFactu"+ sufijo);
			//if(!CollectionUtils.isEmpty(lstFacturasSerie) && !CollectionUtils.isEmpty(lstComproBPagoActual)){
			if(!CollectionUtils.isEmpty(lstFacturasSerie) && !CollectionUtils.isEmpty(lstComproBPago)){
				//Fin RIN10
				for(Map mapaFacSerie : lstFacturasSerie){
					//Inicio RIN10 
					//for(Map mapaComproPago : lstComproBPagoActual){
					for(Map mapaComproPago : lstComproBPago){
						//Fin RIN10
						if(mapaFacSerie.get("NUM_SECFACT").toString().equals(mapaComproPago.get("NUM_SECFACT").toString())){
							mapaFacSerie.put("FEC_FACT", mapaComproPago.get("FEC_FACT"));
							mapaFacSerie.put("NUM_FACT", mapaComproPago.get("NUM_FACT").toString());//adicionado por SAU20143N002000509
							break;
						}
					}
				}// P46 - INICIO - INSI
			} else if (!CollectionUtils.isEmpty(lstFacturasSerie) && !CollectionUtils.isEmpty(lstFormaFactu)){
				for(Map mapaFacSerie : lstFacturasSerie){
					for (Map mapFormAFactu : lstFormaFactu) {
						if(SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(mapFormAFactu.get("NUM_SECFACT"))).equals(mapaFacSerie.get("NUM_SECFACT").toString())){
							mapaFacSerie.put("FEC_FACT", mapFormAFactu.get("FEC_FACT"));
							mapaFacSerie.put("NUM_FACT", mapFormAFactu.get("NUM_FACT").toString());
							break;
						}    					
					}
				}

			}// P46 - FIN - INSI

		}
		//fin diligencia rectificacion gmontoya


		List<Map> lstFormBProveedor = (List<Map>) mapCabDeclara.get("lstFormBProveedor" + sufijo);
		//    List<Map> lstFormBProveedor = (List<Map>) mapCabDeclara.get("lstFormBProveedor");//se cambia porque no existe el sufijo
		//Inicio RIN10  
		//if ("Actual".equals(sufijo))
		if(RECTIFICACION.equals(tipoDiligencia)){
			//Fin RIN10
			lstFormBProveedor = (List<Map>) mapinput.get("lstFormBProveedor" + sufijo);
		}

		/**Inicio cambios PASE 42 AREY*/ 
		List<Map> lstFormbMonto = (List<Map>)mapinput.get("lstFormbMonto"+sufijo);
		if ("Actual".equals(sufijo))
		{
			lstFormbMonto = (List<Map>) mapinput.get("lstFormbMonto" + sufijo);
		}
		/**Fin cambios PASE 42 AREY*/ 

		List<Map<String, Object>> lstDocautAsociado = (List<Map<String, Object>>) mapinput
				.get("lstDocAutAsociado" + sufijo);
		List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapinput.get("lstDetAutorizacion"
				+ sufijo);
		List<Map<String, Object>> lstIndicadorDua    = (List<Map<String, Object>>)mapinput.get("lstIndicadorDua" + sufijo);
		
		//PAS20171U220200005 se adiciona la lista de cabAdiImpoConsu para extraer el numero total de envios
		List<Map<String, Object>> lstCabAdiImpoConsu = (List<Map<String,  Object>>)mapinput.get("lstCabAdiImpoConsu"+ sufijo);
		//inicio pase peru corea declara en parte como cabecera lstCabcertiOrigen 
		List<Map<String, Object>> lstCabCertiOrigen = null;

		if (mapCabDeclara.containsKey("lstCabCertiOrigen"))
			lstCabCertiOrigen = (List<Map<String, Object>>) mapCabDeclara.get("lstCabCertiOrigen" + sufijo);
		//Inicio RIN10 
		if(RECTIFICACION.equals(tipoDiligencia)){
			lstCabCertiOrigen = (List<Map<String, Object>>) mapinput.get("lstCabCertiOrigen" + sufijo);
		}

		//fin pase peru corea 
		Declaracion declaracion = new Declaracion();

		declaracion.setCodaduana((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
		declaracion.setCodtipotrans((String)mapinput.get("codTransaccion"));
		{
			declaracion.setNumdeclRef(new NumdeclRef());
			declaracion.getNumdeclRef().setCodregimen((java.lang.String) mapCabDeclara.get("COD_REGIMEN"));
			declaracion.setNumeroCorrelativo(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC")));
			declaracion.getNumdeclRef().setNumcorre((java.lang.String) mapCabDeclara.get("NUM_DECLARACION").toString());
			declaracion.getNumdeclRef().setCodaduana((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
			declaracion.getNumdeclRef().setAnnprese((java.lang.String) mapCabDeclara.get("ANN_PRESEN").toString());
			declaracion.setNumeroDeclaracion(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_DECLARACION").toString()));
		}

		declaracion.setDua(new DUA());
		declaracion.getDua().setNumcorredoc(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC").toString()));
		declaracion.getDua().setCodtipoperacion((java.lang.String) mapCabDeclara.get("COD_TIPDESP"));
		//declaracion.getDua().setAnnpresen(SunatNumberUtils.toInteger(((BigDecimal) mapCabDeclara.get("ANN_PRESEN"))));//RIN 14
		declaracion.getDua().setAnnpresen(SunatNumberUtils.toInteger(mapCabDeclara.get("ANN_PRESEN")));//RIN 14<KAH>modificado RIN10</KAH>
		declaracion.getDua().setCodmodalidad((java.lang.String) mapCabDeclara.get("COD_MODALIDAD"));
		declaracion.getDua().setNumplazosol(SunatNumberUtils.toInteger(mapCabDeclara.get("NUM_PLAZOSOL")));
		declaracion.getDua().setCodtipoplazo((java.lang.String) mapCabDeclara.get("COD_TIPOPLAZO"));
		declaracion.getDua().setMtotfobclvta(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTFOBDOL")));
		declaracion.getDua().setMtotflecomex(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTFLETEDOL")));
		declaracion.getDua().setMtotsegotros(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTSEGDOL")));
		declaracion.getDua().setMtotajustes(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTAJUSTESDOL")));
		declaracion.getDua().setMtovaladuana(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTVALORADU")));
		declaracion.getDua().setCodtipotratamiento((java.lang.String) mapCabDeclara.get("COD_TIPTRATMERC"));
		declaracion.getDua().setCodpropiedad((java.lang.String) mapCabDeclara.get("COD_PROPIEDAD"));
		declaracion.getDua().setCnttpesoneto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_PESONETO_TOTAL")));
		declaracion.getDua().setCnttpesobruto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_PESOBRUTO_TOTAL")));
		declaracion.getDua().setCnttcantbulto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TOTBULTOS")));
		declaracion.getDua().setCnttqunifis(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TQUNIFIS")));
		declaracion.getDua().setCnttqunicom(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TQUNICOM")));
		declaracion.getDua().setCntnumseries(SunatNumberUtils.toInteger(mapCabDeclara.get("CNT_TOTSERIES")));
		declaracion.getDua().setMtototautoliq(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTAUTOLIQ")));
		declaracion.getDua().setCodferia((java.lang.String) mapCabDeclara.get("")); // CAB_ADI_ADMTEM
		declaracion.getDua().setCodtipempaque((java.lang.String) mapCabDeclara.get("COD_TIPEMPAQUE"));
		declaracion.getDua().setCodprodurgente((java.lang.String) mapCabDeclara.get("COD_PRODURGENTE"));
		/**P28 Part2*/
		declaracion.getDua().setFecNumeracion(SunatDateUtils.getDate(mapCabDeclara.get("FEC_DECLARACION").toString(), "yyyy-MM-dd HH:mm:ss"));
		/**FIN P28 Part2*/
		/**/
		if(mapCabDeclara.get("COD_RIESGOOEA")!=null){
		declaracion.getDua().setCodRiesgoOea((java.lang.String) mapCabDeclara.get("COD_RIESGOOEA"));
		}
		/**/
		//Inicio RIN10
		if(RECTIFICACION.equals(tipoDiligencia)){
			declaracion.setNumorden(mapCabDeclara.get("ANN_ORDEN").toString()+ mapCabDeclara.get("NUM_ORDEN").toString());
			declaracion.setTipoDiligencia("06");
			declaracion.setAnnorden(mapCabDeclara.get("ANN_ORDEN").toString());
		}
		//Fin RIN10

		if (mapCabDeclara
				.get("FEC_FINPROVSIONAL")
				.getClass()
				.getName()
				.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion.getDua().setFecfinprovsional(
					new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_FINPROVSIONAL")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_FINPROVSIONAL") instanceof java.util.Date)
		{
			//declaracion.getDua().setFecfinprovsional((java.util.Date) mapCabDeclara.get("FEC_FINPROVSIONAL"));
			/** inicio mpoblete BUG RIN10**/
			//declaracion.getDua().setFecfinprovsional(SunatDateUtils.getDate(mapCabDeclara.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd HH:mm:ss"));
			String fechaString = SunatDateUtils.getFormatDate((java.util.Date) mapCabDeclara.get("FEC_FINPROVSIONAL"),"yyyy-MM-dd HH:mm:ss");
			declaracion.getDua().setFecfinprovsional(SunatDateUtils.getDate(fechaString, "yyyy-MM-dd HH:mm:ss"));
			/** fin mpoblete BUG RIN10**/
		}
		else
		{
			declaracion.getDua().setFecfinprovsional(
					SunatDateUtils.getDate(mapCabDeclara.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd HH:mm:ss"));
		}
		//( ?  "" : ObjectUtils.toString(this.getObjectFromMapEspacio(mapCabDeclara,("COD_LUGARRECEP"))); 
		//pase 15-252
//		if(!esVigenteRIN31){			
//		declaracion.getDua().setCodlugarecepcion(SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP"))) ? "" : mapCabDeclara.get("COD_LUGARRECEP").toString());
//		}else {
		String codLugarRecep=mapCabDeclara.get("COD_LUGARRECEP")!=null?mapCabDeclara.get("COD_LUGARRECEP").toString():"";
		if(mapCabDeclara.get("COD_LUGARRECEP")!=null){
			codLugarRecep= mapCabDeclara.get("COD_LUGARRECEP")!=" "?mapCabDeclara.get("COD_LUGARRECEP").toString():"";
			if(!SunatStringUtils.isEmptyTrim(codLugarRecep)) {
				if (SunatStringUtils.isLengthGreaterOrEqualsThanNumber(codLugarRecep, 2)){
					declaracion.getDua().setCodlugarecepcion(SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(codLugarRecep)) ? "" : SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP")).substring(0, 2));
				}else{
					declaracion.getDua().setCodlugarecepcion(SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(codLugarRecep)) ? "" : SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP")).substring(0, 1));
				}
			}else{
				declaracion.getDua().setCodlugarecepcion("");
			}

		}else {
			//declaracion.getDua().setCodlugarecepcion(SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP"))) ? "" : SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP")).substring(0, 2));
			declaracion.getDua().setCodlugarecepcion(SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(codLugarRecep)) ? "" : SunatStringUtils.toStringObj(mapCabDeclara.get("COD_LUGARRECEP")).substring(0, 2));
			}
//		}

		declaracion.getDua().setCodtiplugarrecep(ObjectUtils.toString(this.getObjectFromMapEspacio(mapCabDeclara,("COD_TIPLUGARRECEP"))));

		//    declaracion.getDua().setCodlugarecepcion((java.lang.String) mapCabDeclara.get("COD_TIPLUGARRECEP"));
		declaracion.getDua().setNumruclugarecep((java.lang.String) mapCabDeclara.get("COD_RUCLUGRECEP"));
		declaracion.getDua().setCodanexo((java.lang.String) mapCabDeclara.get("COD_LOCALANEXO"));
		declaracion.getDua().setNumrucdeposito((java.lang.String) mapCabDeclara.get("COD_RUCLUGRECEP"));
		declaracion.getDua().setCodlocalanexo((java.lang.String) mapCabDeclara.get("COD_LOCALANEXO"));
		declaracion.getDua().setDesfinalidad((java.lang.String) mapCabDeclara.get("DES_FINALIDAD"));
		declaracion.getDua().setIndSocorro((java.lang.String) mapCabDeclara.get("IND_SOCORRO"));
		declaracion.getDua().setCodregimen((java.lang.String) mapCabDeclara.get("COD_REGIMEN"));
		declaracion.getDua().setCodaduanaorden((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
		declaracion.getDua().setNumdocumento((java.lang.String) (mapCabDeclara.get("NUM_DOCIDENT_PDE")));
		declaracion.getDua().setCodtipooper((java.lang.String) (mapCabDeclara.get("COD_TIPDOC_PDE")));
		declaracion.getDua().setPadre(declaracion); /*RIN 07 - 13*/
		//Agregar tipo lugar
		//ggranados 209
		//	declaracion.getDua().setCodtiplugarrecep(mapCabDeclara.get("COD_LUGARRECEP")!=null? mapCabDeclara.get("COD_LUGARRECEP").toString().substring(0, 1) : "");

		if (mapCabDeclara
				.get("FEC_VENREGIMEN")
				.getClass()
				.getName()
				.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion.getDua().setFecfinacoregimen(
					new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_VENREGIMEN")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_VENREGIMEN") instanceof java.util.Date)
		{
			//declaracion.getDua().setFecfinacoregimen((java.util.Date) mapCabDeclara.get("FEC_VENREGIMEN"));
			declaracion.getDua().setFecfinacoregimen(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_VENREGIMEN").toString()));
		}
		else
		{
			declaracion.getDua().setFecfinacoregimen(
					SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_VENREGIMEN").toString()));
		}
		// Crea declarante
		declaracion.getDua().setDeclarante(new Participante());
		declaracion.getDua().getDeclarante().setNumeroDocumentoIdentidad(
				(java.lang.String) mapCabDeclara.get("NUM_DOCIDENT_PIM"));
		declaracion.getDua().getDeclarante().getTipoParticipante().setCodDatacat(
				(java.lang.String) mapCabDeclara.get("COD_TIPPARTIC_PIM"));
		declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().setCodDatacat(
				(java.lang.String) mapCabDeclara.get("COD_TIPDOC_PIM"));

		// Crea OtraAduana
		declaracion.getDua().setOtraAduana(new DatoOtraAduana());
		declaracion.getDua().getOtraAduana().setCodopadusal((java.lang.String) mapCabDeclara.get("COD_ADUDEST"));
		declaracion.getDua().getOtraAduana().setCodviatrades((java.lang.String) mapCabDeclara.get("COD_VIATRANS"));

		if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstDocautAsociado))
		{
			declaracion.getDua().setListDocAutorizantes(transformListDocAutorizantesfromMap(lstDocautAsociado));
		}

		if (mapCabDeclara.containsKey("NUM_CORREDOC"))
		{
			declaracion.setNumeroCorrelativo(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
			declaracion.getDua().setNumcorredoc(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
		}
		if (mapCabDeclara.containsKey("FEC_CONCLUSION"))
		{
			if (mapCabDeclara
					.get("FEC_CONCLUSION")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecconclusion(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_CONCLUSION")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_CONCLUSION") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecconclusion((java.util.Date) mapCabDeclara.get("FEC_CONCLUSION"));
				declaracion.getDua().setFecconclusion(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CONCLUSION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecconclusion(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_CONCLUSION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}
		//ECANA Se debe de agregar la fecha de conclusi�n calculada en la numeraci�n para utilizarla en los registros de la rectificaci�n
		if (mapCabDeclara.containsKey("FEC_VENCONCLU"))
		{
			if (mapCabDeclara
					.get("FEC_VENCONCLU")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecvenconclu(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_VENCONCLU")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_VENCONCLU") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecconclusion((java.util.Date) mapCabDeclara.get("FEC_CONCLUSION"));
				//inicio gmontoya PAS20165E220200032 
				try{
					declaracion.getDua().setFecvenconclu(SunatDateUtils.getDate(mapCabDeclara.get("FEC_VENCONCLU").toString(), "yyyy-MM-dd HH:mm:ss"));
				}catch(Exception e){
					declaracion.getDua().setFecvenconclu((java.util.Date) mapCabDeclara.get("FEC_VENCONCLU"));
				}
				//fin gmontoya PAS20165E220200032
			}
			else
			{
				declaracion.getDua().setFecvenconclu(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_VENCONCLU").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}
		//
		if (mapCabDeclara.containsKey("FEC_DECLARACION"))
		{
			if (mapCabDeclara
					.get("FEC_DECLARACION")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecdeclaracion(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_DECLARACION")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_DECLARACION") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecdeclaracion((java.util.Date) mapCabDeclara.get("FEC_DECLARACION"));
				declaracion.getDua().setFecdeclaracion(SunatDateUtils.getDate(mapCabDeclara.get("FEC_DECLARACION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecdeclaracion(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_DECLARACION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}

		//PAS20145E220000090 - MATC 20140626  INICIO
		if (mapCabDeclara.containsKey("FEC_LLEGADA") && mapCabDeclara.get("FEC_LLEGADA") != null)//P24-II-130
		{
			if (mapCabDeclara.get("FEC_LLEGADA").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecLlegada(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_LLEGADA")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_LLEGADA") instanceof java.util.Date)
			{
				declaracion.getDua().setFecLlegada(SunatDateUtils.getDate(mapCabDeclara.get("FEC_LLEGADA").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecLlegada(SunatDateUtils.getDate(mapCabDeclara.get("FEC_LLEGADA").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}
		//PAS20145E220000090 - MATC 20140626  FINAL

		//Cargamos las observaciones RIN08 INICIO
		List<Map> lstObservacion = (List<Map>) mapinput.get("lstObservacion" + sufijo);
		if (!CollectionUtils.isEmpty(lstObservacion)) {
			Elementos<Observacion> listObservacion = new Elementos<Observacion>();
			declaracion.getDua().setListObservaciones(listObservacion);
			for (Map<String, Object> observacion : lstObservacion){
				Observacion observa = new Observacion();
				observa.setCodtipobserva(SunatStringUtils.toStringObj(observacion.get("COD_TIPOBS")));
				observa.setNumsecuencia(SunatStringUtils.toStringObj(observacion.get("NUM_SECOBS")));
				observa.setObsdeclaracion(SunatStringUtils.toStringObj(observacion.get("OBS_OBS")));
				observa.setNumcorredoc(SunatNumberUtils.toLong(observacion.get("NUM_CORREDOC")));
				observa.setNumsecitem(SunatNumberUtils.toInteger(observacion.get("NUM_SECITEM")));//PAS20165E220200027
				listObservacion.add(observa);
			}
		}
		//RIN08 FIN
		/**
		 * Cargamos los documentos de transporte a partir de las series
		 */
		if (!CollectionUtils.isEmpty(lstDetDeclara))
		{
			Elementos<DatoDocTransporte> listDocTransporte = new Elementos<DatoDocTransporte>();
			declaracion.getDua().setListDocTransporte(listDocTransporte);
			int i = 1;
			for (Map<?, ?> detDeclara : lstDetDeclara)
			{

				if(Constantes.IND_ELIMINADO.equals(detDeclara.get("IND_DEL"))){//adicionado por PAS20145E220000682
					continue;
				}

				// Si ya esta registrado no lo tomamos - PAS20144E610000111 se agrega numero de detalle 
				boolean existeDoctra = false;
				//inicio rin ALC  peru corea se setea para fecha embarque de origen para documento de transporte 
				DatoDocTransporte docTransporte = new DatoDocTransporte();

				/*INICIO P21-P22*/
				Map<String, Object> paramsPuertoFechaOrigen = getPuertoFechaOrigen(lstDetAutorizacion ,  lstCabCertiOrigen, detDeclara.get("NUM_SECSERIE").toString());        
				/*FIN P21-P22*/

				for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte())
				{    
					if (docTrans.getNumdoctransporte().equals(detDeclara.get("NUM_DOCTRANSP")) && docTrans.getNumdetalle().compareTo(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE")!=null?detDeclara.get("NUM_DETALLE").toString():"0"))==0)//AJUSTE POR NULLPOINTER 
					{ /*INICIO P21-P22*/
						if (docTrans.getCodpuertoorg()==null || docTrans.getFecembarqueorg()==null)
						{
							setPuertoFechaOrigen(paramsPuertoFechaOrigen , docTrans);  
						}
						/*FIN P21-P22*/        	
						existeDoctra = true;
						break;
					}
				}
				if (existeDoctra)
					continue;

				//DatoDocTransporte docTransporte = new DatoDocTransporte(); se comenta se declara arriba
				docTransporte.setCodpuerto((java.lang.String) detDeclara.get("COD_PUER_EMBAR"));

				//PASE 399        
				//docTransporte.setCodpuertoorg((java.lang.String) detDeclara.get("COD_PUER_EMBAR"));
				/*INICIO-P34 PAS20165E220200126 AFMA*/
				if(StringUtils.isEmpty(docTransporte.getCodpuertoorg()) || org.apache.commons.lang.StringUtils.isBlank(docTransporte.getCodpuertoorg())) {
				docTransporte.setCodpuertoorg((java.lang.String) detDeclara.get("COD_PTOEMBORIGEN"));
				}
				/*FIN-P34 PAS20165E220200126 AFMA*/
				//PASE 399        
				String  fecEmbarque=detDeclara.get("FEC_EMBARQUE")!=null?detDeclara.get("FEC_EMBARQUE").toString():"";
				if(!SunatStringUtils.isEmptyTrim(fecEmbarque)) {
                    if (detDeclara
                            .get("FEC_EMBARQUE")
                            .getClass()
                            .getName()
                            .equals("pe.gob.sunat.framework.spring.util.date.FechaBean")) {
                        docTransporte.setFecembarque(new java.util.Date(((FechaBean) detDeclara.get("FEC_EMBARQUE"))
                                .getTimestamp()
                                .getTime()));
                    } else if (detDeclara.get("FEC_EMBARQUE") instanceof java.util.Date) {
                        docTransporte.setFecembarque(SunatDateUtils.getDate(detDeclara.get("FEC_EMBARQUE").toString(), "yyyy-MM-dd HH:mm:ss"));
                    } else {
                        docTransporte.setFecembarque(SunatDateUtils.getDate(
                                detDeclara.get("FEC_EMBARQUE").toString(),
                                "yyyy-MM-dd HH:mm:ss"));
                    }
                }
				docTransporte.setCodtipodoctrans((java.lang.String) (detDeclara.get("COD_TIPDOCTRANSP")!=null?detDeclara.get("COD_TIPDOCTRANSP"):""));
				docTransporte.setNumdocmaster((java.lang.String) (detDeclara.get("NUM_DOCTRANSPMASTER")!=null?detDeclara.get("NUM_DOCTRANSPMASTER"):""));
				//inicio rin ALC  peru corea se setea para fecha embarque de origen y codigo del puerto de origen para documento de transporte
				/*if (detDeclara
            .get("FEC_EMBORIGEN")
            .getClass()
            .getName()
            .equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
        {
          docTransporte.setFecembarqueorg(new java.util.Date(((FechaBean) detDeclara.get("FEC_EMBORIGEN"))
              .getTimestamp()
              .getTime()));
        }
        else if (detDeclara.get("FEC_EMBORIGEN") instanceof java.util.Date)
        {
			//docTransporte.setFecembarqueorg((java.util.Date) detDeclara.get("FEC_EMBORIGEN"));
			docTransporte.setFecembarqueorg(SunatDateUtils.getDate(detDeclara.get("FEC_EMBORIGEN").toString(), "yyyy-MM-dd HH:mm:ss"));
        }
        else
        {
        	if(SunatDateUtils.getDateFromUnknownFormat(detDeclara.get("FEC_EMBORIGEN").toString())==null){//PAS20165E220200064
          docTransporte.setFecembarqueorg(SunatDateUtils.getDate(
              		  SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat("01/01/0001"),"yyyy-MM-dd HH:mm:ss"),"yyyy-MM-dd HH:mm:ss"));//PAS20165E220200064
        	}
        	else{
                docTransporte.setFecembarqueorg(SunatDateUtils.getDate(
        		  SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(detDeclara.get("FEC_EMBORIGEN").toString()),"yyyy-MM-dd HH:mm:ss"),"yyyy-MM-dd HH:mm:ss")); //pase192 hacia nullpointer
        	}
        }*/
				/*INICIO P21-P22*/
				setPuertoFechaOrigen(paramsPuertoFechaOrigen , docTransporte);
				/*FIN P21-P22*/

				//fin  rin ALC  peru corea
				docTransporte.setNumdoctransporte((java.lang.String) detDeclara.get("NUM_DOCTRANSP")!=null?detDeclara.get("NUM_DOCTRANSP").toString():"");
				docTransporte.setNumdetalle(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE") != null ? detDeclara.get("NUM_DETALLE").toString():"0"));// ajuste detalle null
				docTransporte.setNumsecdoctrans(i++);

				listDocTransporte.add(docTransporte);

			}
		}

		//ini P46-PAS20155E410000032
		if(mapCabDeclara.get("registrarCodLibeDonacion") != null
				&& (Boolean)mapCabDeclara.get("registrarCodLibeDonacion")) {
			declaracion.setRegistrarCodLibeDonacion((Boolean)mapCabDeclara.get("registrarCodLibeDonacion"));
		}
		//fin P46-PAS20155E410000032

		/*Se inicilaiza listado de objetos necesarios*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();
		declaracion.getDua().setListOtrosDocSoporte(listOtrosDocSoporte);

		if (!CollectionUtils.isEmpty(lstDetDeclara))
		{
			Elementos<DatoSerie> listSeries = new Elementos<DatoSerie>();
			declaracion.getDua().setListSeries(listSeries);

			List<Map> lstDocuPreceDua;
			for (Map detDeclara : lstDetDeclara)
			{
				if(Constantes.IND_ELIMINADO.equals(detDeclara.get("IND_DEL"))){//adicionado por PAS20145E220000682
					continue;
				}

				DatoSerie serie = new DatoSerie();
				serie.setNumserie(SunatNumberUtils.toInteger(detDeclara.get("NUM_SECSERIE").toString()));
				serie.setCodunicomer((java.lang.String) detDeclara.get("COD_UNICOMER"));
				serie.setCntunicomer(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_COMER")));
				serie.setCntbultos(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_BULTO")));
				serie.setCodclasbul((java.lang.String) detDeclara.get("COD_CLASEBULTOS"));
				serie.setCntpesoneto(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESO_NETO")));
				serie.setCntpesobruto(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESO_BRUTO")));
				serie.setCntunifis(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIFIS")));
				serie.setCodunifis(SunatStringUtils.toStringObj(detDeclara.get("COD_UNIFISICA")));
				serie.setNumpartnandi(SunatNumberUtils.toLong(detDeclara.get("NUM_PARTNANDI")));
				serie.setCodtnan((java.lang.String) detDeclara.get("COD_TIPTASAAPLICAR"));
				serie.setNumpartnalad((java.lang.String) detDeclara.get("NUM_PARNALADISA"));
				serie.setCodtipomarge((java.lang.String) detDeclara.get("COD_TIPMARGEN"));
				serie.setCodpaisorige((java.lang.String) detDeclara.get("COD_PAISORIGEN"));
				serie.setCodpaisadqui((java.lang.String) detDeclara.get("COD_PAISADQUI"));
				serie.setMtofobmon(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBMONTRANS")));
				serie.setCodmoneda((java.lang.String) detDeclara.get("COD_MONETRANS"));
				serie.setMtofledol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FLETEDOL")));
				serie.setMtosegdol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_SEGDOL")));
				serie.setMtoajuste(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_AJUSTE")));
				serie.setMtovaladuana(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_VALORADU")));
				serie.setDescomercial((java.lang.String) detDeclara.get("DES_COMER"));
				serie.setDesformapres((java.lang.String) detDeclara.get("DES_FORMAPRESEN"));
				serie.setDesmatecomp((java.lang.String) detDeclara.get("DES_MATECOMP"));
				serie.setDesusoaplica((java.lang.String) detDeclara.get("DES_USOAPLIC"));
				serie.setDesotros((java.lang.String) detDeclara.get("DES_OTROSCARAC"));
				serie.setNumpartcorre((java.lang.String) detDeclara.get("NUM_PARCORRELACION"));
				serie.setValpreciovta(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_PVPMONNAC")));
				//INICIO RIN08
				if (detDeclara.get("NUM_PARNABANDINA")!=null){
					if(detDeclara.get("NUM_PARNABANDINA").equals(" ")){
						serie.setNumpartnabanAsLong(detDeclara.get("NUM_PARNABANDINA").toString());
					}
					else{
						serie.setNumpartnaban((java.lang.String) detDeclara.get("NUM_PARNABANDINA"));
					}	
				}
				//FIN RIN08
				serie.setCodtipoflete((java.lang.String) detDeclara.get("COD_TIPFLETE"));
				serie.setValestimado(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_ESTIMADO")));
				serie.setPadre(declaracion.getDua()); /*RIN 07-RIN 13*/

				//P34 AFMA INICIO
				if(detDeclara.get("NUM_DETALLE")==null) {
					serie.setNumdetalle(SunatNumberUtils.toInteger(BigDecimal.ZERO));//bug cambio mol
				}else{
					serie.setNumdetalle(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE").toString()));}
				serie.setNumdoctransporte((java.lang.String) detDeclara.get("NUM_DOCTRANSP"));
				//P34 AFMA FIN

				//GGRANADOS INICIO ALCOHOL
				if (detDeclara.get("POR_ALCOHOL") != null) {
					if (!detDeclara.get("POR_ALCOHOL").equals("")) {
						serie.setPoralcohol(SunatNumberUtils
								.toBigDecimal(detDeclara.get("POR_ALCOHOL")));
					}
				}
				//GGRANADOS FIN ALCOHOL

				//ini P46-PAS20155E410000032
				if(!SunatStringUtils.isEmptyTrim((String)detDeclara.get("COD_TIPREGUL"))) {
					serie.setCodTipRegul(SunatStringUtils.trim((String)detDeclara.get("COD_TIPREGUL")));
				}
				//fin P46-PAS20155E410000032

				//RIN14 CUS14.04 mpoblete
				declaracion.getDua().setPadre(declaracion);        
				serie.setPadre(declaracion.getDua());
				//RIN14 CUS14.04 mpoblete

				if (detDeclara.get("FEC_EXPIRACION")!= null) {
					if (detDeclara.get("FEC_EXPIRACION").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")) {
						serie.setFecexpiracion(new java.util.Date(((FechaBean) detDeclara.get("FEC_EXPIRACION")).getTimestamp().getTime()));
					}
					else if (detDeclara.get("FEC_EXPIRACION") instanceof java.util.Date) {
						serie.setFecexpiracion(SunatDateUtils.getDate(detDeclara.get("FEC_EXPIRACION").toString(), "yyyy-MM-dd HH:mm:ss"));
					} else {
						serie.setFecexpiracion(SunatDateUtils.getDate(detDeclara.get("FEC_EXPIRACION").toString(),"yyyy-MM-dd HH:mm:ss"));
					}
				}


				serie.setMercancia(new DatoMercancia());
				serie.getMercancia().setCodproducto((java.lang.String) detDeclara.get("COD_PRODRESTR"));
				serie.getMercancia().setCodtipoexoneracion((java.lang.String) detDeclara.get("COD_TIPEXONRESTRI"));
				serie.getMercancia().setCodexoneracion((java.lang.String) detDeclara.get("COD_EXMERCREST"));
				serie.getMercancia().setCodriesgosanitario((java.lang.String) detDeclara.get("COD_RSSENASA"));


				serie.setProducto(new DatoProducto());
				serie.getProducto().setCodexpantidum((java.lang.String) detDeclara.get("COD_EXPOAPLICANTID"));
				serie.getProducto().setCodpantidum((java.lang.String) detDeclara.get("COD_PRODANTID"));
				serie.getProducto().setMtofobfactu(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBFACT")));
				//serie.getProducto().setPormerma(SunatNumberUtils.toBigDecimal(detDeclara.get("POR_MERMA"))); //RIN13 ya no seria necesario ya que en el serie.setDatoProductoTmp = se setea 
				serie.setCodaplultra((java.lang.String) detDeclara.get("COD_ULTRACTIVIDAD"));

				//RIN13
				//datoProductoTmp
				DatoProducto datoProductoTmp = new DatoProducto();
				datoProductoTmp.setPormerma(SunatNumberUtils.toBigDecimal(detDeclara.get("POR_MERMA")));
				datoProductoTmp.setNumitem((java.lang.String)detDeclara.get("COD_INSUMO"));
				datoProductoTmp.setCntunimedidaequi(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIEQUI")));
				datoProductoTmp.setCodtipoequi((java.lang.String)detDeclara.get("COD_UMEQUI")); 
				serie.setDatoProductoTmp(datoProductoTmp);
				/*RIN08 INICIO - atencion bug 22110*/
				List<Map> lstConvenio = (List) detDeclara.get("lstConvenioSerie"); // RIN08 AGREGO <Map>
				if (!CollectionUtils.isEmpty(lstConvenio))
				{
					for (Map mapCC : lstConvenio) { //RIN08 AGREGO FOR
						//Map mapCC = new HashMap(); RIN08 COMENTO ESTA LINEA
						//mapCC = (Map) lstConvenio.get(0); RIN08 COMENTO ESTA LINEA
						Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;//GMONTOYA P29 - RIN08 AGREGO ESTA LINEA
						if (ind_del.equals(0)) { //RIN08 AGREGO IF
							String tipoConvenio = mapCC.get("COD_TIPCONVENIO").toString();
							if(mapCC.get("COD_CONVENIO")!=null){
								String codConvenio = mapCC.get("COD_CONVENIO").toString().trim();
								//Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;//GMONTOYA P29 - RIN08 COMENTO ESTA LINEA
								/*RIN08 FIN - atencion bug 22110*/
								if (SunatStringUtils.isEqualTo(tipoConvenio, "I") &&  ind_del.equals(0))
								{
									serie.setCodconvinter(Integer.valueOf(codConvenio));
								}
								if (SunatStringUtils.isEqualTo(tipoConvenio, "T") &&  ind_del.equals(0))
								{
									serie.setCodtratprefe(Integer.valueOf(codConvenio));
								}
								if (SunatStringUtils.isEqualTo(tipoConvenio, "C") &&  ind_del.equals(0))
								{
									serie.setCodliberatorio(Integer.valueOf(codConvenio));
								}
							}
						}
					}
				}

				serie.setMtofobdol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBDOL")));
				serie.setCodtiposeg((java.lang.String) detDeclara.get("COD_TIPSEG"));
				serie.setCodestamerca((java.lang.String) detDeclara.get("COD_ESTMERC"));
				serie.setCodvalajuste((java.lang.String) detDeclara.get("COD_VALORAJUSTE"));
				serie.setCntunicomisc(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIISC")));
				serie.setCodunicomisc((java.lang.String) detDeclara.get("COD_UNI_ISC"));
				serie.setCntpesovehic(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESOVEHIC")));


				lstDocuPreceDua = (ArrayList<Map>) detDeclara.get("lstDocuPreceDua" + sufijo);
				//Inicio RIN10
				//if (CollectionUtils.isEmpty(lstDocuPreceDua)) {
				if(RECTIFICACION.equals(tipoDiligencia)){
					//Fin RIN10
					lstDocuPreceDua = (ArrayList<Map>)  mapinput.get("lstDocuPreceDua" + sufijo);
				}

				if (!CollectionUtils.isEmpty(lstDocuPreceDua))
				{
					Elementos<DatoRegPrecedencia> listRegPrecedencia = new Elementos<DatoRegPrecedencia>();
					for (Map docuPreceDua : lstDocuPreceDua)
					{
						//No considerar los anulados
						String indDel = docuPreceDua.get("IND_DEL") == null?"0":docuPreceDua.get("IND_DEL").toString();
						if (!indDel.equals("1") && docuPreceDua.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
							DatoRegPrecedencia regPrecedencia = new DatoRegPrecedencia();
							regPrecedencia.setCodregipre((java.lang.String) docuPreceDua.get("COD_REGIMENPRE"));
							regPrecedencia.setCodaduapre((java.lang.String) docuPreceDua.get("COD_ADUANAPRE"));
							regPrecedencia.setAnndeclpre(SunatStringUtils.toStringObj(docuPreceDua.get("ANN_PRESENPRE")));
							regPrecedencia.setNumdeclpre(SunatStringUtils.toStringObj(docuPreceDua.get("NUM_DECLARACIONPRE")));
							regPrecedencia.setFecvencpre(SunatDateUtils.getDateFromUnknownFormat(docuPreceDua.get("FEC_VENCREGPRE").toString()));
							regPrecedencia.setNumserpre(SunatNumberUtils.toInteger(docuPreceDua.get("NUM_SECSERIEPRE").toString()));
							listRegPrecedencia.add(regPrecedencia);
						}
					}
					serie.setListRegPrecedencia(listRegPrecedencia);
				}
				//jenciso Inicio - agregando vehiculos ceticos a la serie
				//DatoVehiculo  datoVehiculo = null;
				Map<String,Object> datoVehiculoMap = null;
				List<Map<String,Object>>  lstDatoVehiculo = (ArrayList)detDeclara.get("lstDatoVehiculo");
				//pase PAS20145E220000164
				if(RECTIFICACION.equals(tipoDiligencia)){
					lstDatoVehiculo = (ArrayList<Map<String, Object>>)  mapinput.get("lstVehiCetico" + sufijo);
				}
				if(lstDatoVehiculo!=null && !lstDatoVehiculo.isEmpty())
					datoVehiculoMap = (Map<String,Object>)lstDatoVehiculo.get(0);

				List<Map<String,Object>>  lstDatoMontoGasto = (ArrayList)detDeclara.get("lstDatoMontoGasto");
				//pase PAS20145E220000164 
				if(RECTIFICACION.equals(tipoDiligencia)){
					lstDatoMontoGasto = (ArrayList<Map<String, Object>>)  mapinput.get("lstMontoGasto" + sufijo);
				}

				if(datoVehiculoMap!=null && !datoVehiculoMap.isEmpty() ){//verificar montogasto
					Elementos<DatoVehiculo> listVehiculos = new Elementos<DatoVehiculo>();
					Elementos<DatoMontoGasto>  listMontoGastos =  new Elementos<DatoMontoGasto>();
					DatoVehiculo datoVehi = new DatoVehiculo();
					datoVehi = Utilidades.obtenerDatoVehiculoFromMap(datoVehiculoMap);

					if(lstDatoMontoGasto!=null && !lstDatoMontoGasto.isEmpty()){
						List<DatoMontoGasto> listDatoMontoGasto= null;
						listDatoMontoGasto= Utilidades.obtenerListDatoMontoGastoFromListMap(lstDatoMontoGasto);
						if(!CollectionUtils.isEmpty(listDatoMontoGasto)){
							listMontoGastos.addAll(listDatoMontoGasto);
						}
					}


					datoVehi.setNumcorredoc(declaracion.getDua().getNumcorredoc());
					datoVehi.setNumserie(serie.getNumserie());

					datoVehi.setListMontoGastos(listMontoGastos);
					listVehiculos.add(datoVehi);
					serie.setListVehiculos(listVehiculos);
				}

				//jenciso Fin

				if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstDetAutorizacion))
				{
					Elementos<DatoSerieDocSoporte> listSerieDocSoporte = transformListSerieDocSoporteFromMap(
							lstDetAutorizacion,
							SunatNumberUtils.toInteger(detDeclara.get("NUM_SECSERIE").toString()));
					if (listSerieDocSoporte.size() > 0)
					{
						serie.setListSerieDocSoporte(listSerieDocSoporte);
					}

				}
				// Asociamos el documento de transporte a la serie pero como documento
				// de Soporte - PAS20144E610000111 se agrega numero de detalle 
				if (!CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte()))
				{
					for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte())
					{
						if (docTrans.getNumdoctransporte().equals(detDeclara.get("NUM_DOCTRANSP")) &&
								docTrans.getNumdetalle().compareTo(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE")!=null?detDeclara.get("NUM_DETALLE").toString():"0"))==0)//AJUSTE POR NULLPOINTER
						{
							DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
							serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(detDeclara
									.get("NUM_SECSERIE"))));
							serieDocSopTrans.setNumiddocsoporte(docTrans.getNumsecdoctrans());
							serieDocSopTrans.setCodtipodocsoporte("3");
							if (serie.getListSerieDocSoporte() == null)
							{
								serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
							}
							serie.getListSerieDocSoporte().add(serieDocSopTrans);
							break;
						}
					}
				}
				//inicio gmontoya
				// Asociamos las facturas a la serie pero como documento soporte
				List<Map> lstFormaFactuA = (List<Map>) mapinput.get("lstFormaFactuActual");
				List<Map> lstSeriesItemA = (List<Map>) mapinput.get("lstSeriesItemActual");
				//Inicio RIN10
				if(RECTIFICACION.equals(tipoDiligencia)){
					lstFormaFactuA = (ArrayList<Map>)  mapinput.get("lstFormaFactu" + sufijo);
					lstSeriesItemA = (ArrayList<Map>)  mapinput.get("lstSeriesItem" + sufijo);
				}
				//Fin RIN10
				if(RECTIFICACION.equals(tipoDiligencia)){//condicion solo para diligencia de rectificacion electronica PAS20155E220200192
					if (!CollectionUtils.isEmpty(lstFormaFactuA) && !CollectionUtils.isEmpty(lstSeriesItemA))
					{
						for (Map mapa : lstSeriesItemA){
							if(mapa.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
								for(Map mapaFactu : lstFormaFactuA){
									if(mapaFactu.get("NUM_SECFACT")!=null && mapa.get("NUM_SECFACT").toString().equals(mapaFactu.get("NUM_SECFACT").toString()) ){//debe compara como string
										DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
										serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapa
												.get("NUM_SECSERIE"))));
										serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFactu
												.get("NUM_SECFACT"))));
										serieDocSopTrans.setCodtipodocsoporte("2");
										if (CollectionUtils.isEmpty(serie.getListSerieDocSoporte()))
										{
											serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
										}
										serie.getListSerieDocSoporte().add(serieDocSopTrans);	                      
									}
								}
							}
						}//fin gmontoya   
						/***Inicio pase PAS20155E220200192***/  
					}
				}else{//para la que no sea diligencia de rectificacion electronica:        
					List<Map<String, Object>> lstFacturaSerie = (List<Map<String, Object>>)detDeclara.get("lstFacturaSerie");
					if (!CollectionUtils.isEmpty(lstFacturaSerie))
					{
						for (Map<String, Object> mapaFacturaSerie : lstFacturaSerie){
							if(mapaFacturaSerie.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
								DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
								serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFacturaSerie.get("NUM_SECSERIE"))));
								serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFacturaSerie.get("NUM_SECFACT"))));
								serieDocSopTrans.setCodtipodocsoporte("2");
								if (CollectionUtils.isEmpty(serie.getListSerieDocSoporte()))
								{
									serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
								}
								serie.getListSerieDocSoporte().add(serieDocSopTrans);	                      
							}
						}
					}  
				}
				/***Fin pase PAS20155E220200192***/
				//INICIO RIN 13
				// Asociamos el documento de AutoCertificacion a la serie pero como documento
				if (!CollectionUtils.isEmpty(lstDetAutorizacion)) 
				{
					for (Map mapDetAutorizacion : lstDetAutorizacion)
					{
						if (mapDetAutorizacion.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())
								&& (mapDetAutorizacion.get("COD_TIPOPER").equals("C")))
						{
							if (SunatNumberUtils.toInteger(mapDetAutorizacion.get("IND_DEL")).intValue() == 0) {
								DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
								serieDocSopTrans.setNumcorredoc(SunatNumberUtils.toLong(mapDetAutorizacion.get("NUM_CORREDOC")));
								serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECSERIE"))));
								serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECDOC"))));
								serieDocSopTrans.setCodtipooper(ObjectUtils.toString(mapDetAutorizacion.get("COD_TIPOPER")));
								serieDocSopTrans.setCodtipodocsoporte("5");
								if (serie.getListSerieDocSoporte() == null)
								{
									serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
								}
								serie.getListSerieDocSoporte().add(serieDocSopTrans);
							}
						}
					}
				}

				//FIN RIN 13


				listSeries.add(serie);
			}
		}

		if (!CollectionUtils.isEmpty(lstFacturasSerie))
		{
			Elementos<DatoFacturaref> listFacturaRef = new Elementos<DatoFacturaref>();
			declaracion.getDua().setListFacturaRef(listFacturaRef);

			for (Map mapFacturasSerie : lstFacturasSerie)
			{
				DatoFacturaref facturaRef = new DatoFacturaref();
				//inicio diligencia rectificacion gmontoya
				if(mapFacturasSerie.get("NUM_FACT")!=null && !mapFacturasSerie.get("NUM_FACT").toString().trim().isEmpty()){
					facturaRef.setNumfactura((java.lang.String) mapFacturasSerie.get("NUM_FACT"));
				}else{
					List<Map> lstComproBPagoA = (List<Map>) mapinput.get("lstComproBPagoActual");
					//Inicio RIN10
					if(RECTIFICACION.equals(tipoDiligencia)){
						lstComproBPagoA = (ArrayList<Map>)  mapinput.get("lstComproBPago" + sufijo);

					}
					//Fin RIN10
					for(Map mapaCompro : lstComproBPagoA){
						if(mapFacturasSerie.get("NUM_SECFACT").equals(mapaCompro.get("NUM_SECFACT"))){
							facturaRef.setNumfactura((java.lang.String) mapaCompro.get("NUM_FACT"));
						}
					}
				}
				//fin diligencia rectificacion gmontoya
				if(mapFacturasSerie.get("FEC_FACT")!=null){//ajuste por SAU20153K004000234 - regimen 70
					if (mapFacturasSerie.get("FEC_FACT").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")){
						facturaRef.setFecfactura(new java.util.Date(((FechaBean) mapFacturasSerie.get("FEC_FACT")).getTimestamp().getTime()));
					} else if (mapFacturasSerie.get("FEC_FACT") instanceof java.util.Date){
						facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "yyyy-MM-dd HH:mm:ss"));
					} else {


						if(SunatStringUtils.indexOf(mapFacturasSerie.get("FEC_FACT").toString(), "/")!=-1)
						{
							facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "dd/MM/yyyy"));
						}
						else
						{
							facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "yyyy-MM-dd HH:mm:ss"));
						}

					}

				}//fin ajuste SAU20153K004000234
				facturaRef.setNumsecfactu(SunatNumberUtils.toInteger(mapFacturasSerie.get("NUM_SECFACT")));
				facturaRef.setPadre(declaracion.getDua()); /*RIN 07-RIN 13*/
				if(!Constantes.IND_ELIMINADO.equals(mapFacturasSerie.get("IND_DEL"))){//SIGESI 2016-025979 - PAS20165E220200033  
					listFacturaRef.add(facturaRef);/*RIN 07*/
				}

				//declaracion.getDua().setListFacturaRef(listFacturaRef);
			}
		}

		if (!CollectionUtils.isEmpty(lstIndicadorDua)) {
			Elementos<DatoIndicadores> listIndicadores = new Elementos<DatoIndicadores>();
			declaracion.getDua().setListIndicadores(listIndicadores);
			for (Map<String, Object> mapListIndicadores : lstIndicadorDua){
				DatoIndicadores indicadoresRef = new DatoIndicadores();
				indicadoresRef.setCodtipoindica((String)mapListIndicadores.get("COD_INDICADOR"));
				//P46  INICIO EJHM
				if(mapListIndicadores.get("IND_ACTIVO")!=null){
					indicadoresRef.setIndicadorActivo(mapListIndicadores.get("IND_ACTIVO").toString());	
				}
				// FIN P46 EJHM

				listIndicadores.add(indicadoresRef);
			}
		}

		//PAS20171U220200005 se adiciona el cabadiimpoconsu para extraer el total de envios
		if(!CollectionUtils.isEmpty(lstCabAdiImpoConsu)){
			Elementos<DatoIndicadores> listIndicadores = declaracion.getDua().getListIndicadores();
			if(!CollectionUtils.isEmpty(listIndicadores)){
				for(DatoIndicadores mapIndicadores : listIndicadores){
					if(mapIndicadores.getCodtipoindica()!=null &&
							(mapIndicadores.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO)
							|| mapIndicadores.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES))){
						if(lstCabAdiImpoConsu.get(0).get("NUM_TOTALENVIOS")!=null){
							String totalEnvios  = lstCabAdiImpoConsu.get(0).get("NUM_TOTALENVIOS").toString();
							mapIndicadores.setDestipoindica(totalEnvios);
						}
					}
				}
			}
			 
		}
		
		declaracion.getDua().setManifiesto(new DatoManifiesto());
		declaracion.getDua().getManifiesto().setCodaduamanif((java.lang.String) mapCabDeclara.get("COD_ADUAMANIFIESTO"));
		declaracion.getDua().getManifiesto().setAnnmanif(SunatStringUtils.toStringObj(mapCabDeclara.get("ANN_MANIFIESTO")));

		//si el numero de manifesto es vacio debeo enviar NULL para que no date y no valide el manifiesto
		//ya que para anticipados no debe validar
		String numManifiesto = mapCabDeclara.get("NUM_MANIFIESTO").toString().trim();
		if (SunatStringUtils.isEmpty(numManifiesto))
		{
			numManifiesto = null;
		}

		declaracion.getDua().getManifiesto().setNummanif(numManifiesto);
		declaracion.getDua().getManifiesto().setCodmodtransp((java.lang.String) mapCabDeclara.get("COD_VIATRANS"));
		/*inicio P21-P22*/

		if (mapCabDeclara.get("FEC_TERM").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion
			.getDua()
			.getManifiesto()
			.setFectermino(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_TERM")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_TERM") instanceof java.util.Date)
		{
			//declaracion.getDua().getManifiesto().setFectermino((java.util.Date) mapCabDeclara.get("FEC_TERM"));
			//		declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDate(mapCabDeclara.get("FEC_TERM").toString(),"yyyy-MM-dd HH:mm:ss"));
			declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_TERM").toString()));
		}
		else
		{
			//      declaracion
			//          .getDua()
			//          .getManifiesto()
			//          .setFectermino(SunatDateUtils.getDate(mapCabDeclara.get("FEC_TERM").toString(), "yyyy-MM-dd HH:mm:ss"));
			declaracion
			.getDua()
			.getManifiesto()
			.setFectermino(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_TERM").toString()));
		}
		/*fin P21-P22*/

		declaracion.getDua().getManifiesto().setCodtipomanif((java.lang.String) mapCabDeclara.get("COD_TIPMANIFIESTO"));
		declaracion.getDua().getManifiesto().setEmpTransporte(new Participante());
		declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(
				(java.lang.String) mapCabDeclara.get("NUM_DOCIDENT_PTR"));
		declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat(
				(java.lang.String) mapCabDeclara.get("COD_TIPDOC_PTR"));


		declaracion.getDua().setPago(new DatoPago());
		declaracion.getDua().getPago().setPagoDeclaracion(new DatoPagoDecla());
		declaracion.getDua().getPago().getPagoDeclaracion().setCodbcopagoelec(
				SunatStringUtils.toStringObj(mapCabDeclara.get("COD_BCOPAGOELEC")));
		declaracion.getDua().getPago().getPagoDeclaracion().setNumctapagoelec(
				(java.lang.String) mapCabDeclara.get("NUM_CUENTAPAGOE"));
		declaracion.getDua().getPago().getPagoDeclaracion().setCodgarantia(
				(java.lang.String) mapCabDeclara.get("NUM_CTACTE"));

		//amancilla RIN10
		String codTipPago =  !StringUtils.isEmpty(mapCabDeclara.get("NUM_CTACTE"))?"G":"";
		declaracion.getDua().getPago().getPagoDeclaracion().setCodtipopago(codTipPago);
		//fin   
		declaracion.getDua().getPago().setPagoTransaccion(new DatoPagoTrans());
		declaracion.getDua().getPago().getPagoTransaccion().setCodentipago(
				(java.lang.String) mapCabDeclara.get("COD_ENTIPAGO"));
		declaracion.getDua().getPago().getPagoTransaccion().setCodmodpago(
				(java.lang.String) mapCabDeclara.get("COD_MODPAGO"));
		declaracion.getDua().getPago().getPagoTransaccion().setNumplazcredito(
				SunatNumberUtils.toInteger(mapCabDeclara.get("CNT_PLZCREDITO")));

		if (mapCabDeclara.get("FEC_CARCR").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion
			.getDua()
			.getPago()
			.getPagoTransaccion()
			.setFeccarcr(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_CARCR")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_CARCR") instanceof java.util.Date)
		{
			//declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr((java.util.Date) mapCabDeclara.get("FEC_CARCR"));
			declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CARCR").toString(),"yyyy-MM-dd HH:mm:ss"));
		}
		else
		{
			declaracion
			.getDua()
			.getPago()
			.getPagoTransaccion()
			.setFeccarcr(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CARCR").toString(), "yyyy-MM-dd HH:mm:ss"));
		}

		if (declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr() != null)
		{
			FechaBean fDef = new FechaBean("01/01/0001", "dd/MM/yyyy");
			FechaBean fCarcr = new FechaBean(new java.sql.Date(declaracion
					.getDua()
					.getPago()
					.getPagoTransaccion()
					.getFeccarcr()
					.getTime()));
			if (FechaBean.getDiferencia(fCarcr.getCalendar(), fDef.getCalendar(), Calendar.DATE) == 0)
			{
				declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr(null);
			}
		}
		// inicio  rin ALC  peru corease comenta por se declara en la cabecera
		/*List<Map> lstCabCertiOrigen = null;

    if (mapCabDeclara.containsKey("lstCabCertiOrigen"))
      lstCabCertiOrigen = (List<Map>) mapCabDeclara.get("lstCabCertiOrigen" + sufijo);
      //Inicio RIN10 
      if(RECTIFICACION.equals(tipoDiligencia)){
          lstCabCertiOrigen = (List<Map>) mapinput.get("lstCabCertiOrigen" + sufijo);
      }
	  //Fin RIN10*/ 

		//fin  rin ALC  peru corea

		if (!CollectionUtils.isEmpty(lstCabCertiOrigen))
		{
			Elementos<DatoAutocertificacion> listAutocertificacion = new Elementos<DatoAutocertificacion>();
			declaracion.getDua().setDatoCertificadoOrigen(new DatoCertificadoOrigen());

			//declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion(listAutocertificacion);

			for (Map mapCabCertiOrigen : lstCabCertiOrigen)
			{
				DatoAutocertificacion autocertificacion = new DatoAutocertificacion();
				autocertificacion.setNumdocumento((java.lang.String) mapCabCertiOrigen.get("NUM_CERTIFICADO"));

				if (mapCabCertiOrigen.get("FEC_CERTIFICADO") != null &&  mapCabCertiOrigen.get("FEC_CERTIFICADO").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")) //PAS20175E220200055 REQ 2017-037543
				{
					autocertificacion.setFecemision(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_CERTIFICADO")).getTimestamp().getTime()));
				}
				else
				{
					if (mapCabCertiOrigen.get("FEC_CERTIFICADO") != null &&  mapCabCertiOrigen.get("FEC_CERTIFICADO").getClass().getName().equals("java.lang.String")) //PAS20175E220200055 REQ 2017-037543
					{
						String valorStr = mapCabCertiOrigen.get("FEC_CERTIFICADO").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							autocertificacion.setFecemision(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss").getTimestamp().getTime()));
						}
						else
						{
							if (valorStr.length() == 10 && valorStr.substring(4, 5).equals("-")
									&& valorStr.substring(7, 8).equals("-"))
							{
								autocertificacion.setFecemision(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd").getTimestamp().getTime()));
							}
							else
							{
								// PAS20155E220100048
								//autocertificacion.setFecemision(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_CERTIFICADO").toString())==null){
									autocertificacion.setFecemision(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime()));
								}else{
									autocertificacion.setFecemision(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								}
							}
						}
						mapCabCertiOrigen.put("FEC_CERTIFICADO", autocertificacion.getFecemision());
					}
					else if (mapCabCertiOrigen.get("FEC_CERTIFICADO") != null) //PAS20175E220200055 REQ 2017-037543
					{
						autocertificacion.setFecemision((java.util.Date) mapCabCertiOrigen.get("FEC_CERTIFICADO"));
					}
				}
				autocertificacion.setCodffco((java.lang.String) mapCabCertiOrigen.get("COD_FFCO"));
				autocertificacion.setCodtipoCO((java.lang.String) mapCabCertiOrigen.get("COD_TIPCERTIFICADO"));
				autocertificacion.setCodtipoemisorCO((java.lang.String) mapCabCertiOrigen.get("COD_EMISCERT"));
				autocertificacion.setNomemisorCO((java.lang.String) mapCabCertiOrigen.get("NOM_EMISCERTIF"));
				autocertificacion.setIndElectronico((java.lang.String) (mapCabCertiOrigen.get("IND_ELECTRONICO")!=null?mapCabCertiOrigen.get("IND_ELECTRONICO"):"0"));//PAS20181U220200056

				if (mapCabCertiOrigen.get("FEC_INIPERIODOEMB") !=null && mapCabCertiOrigen.get("FEC_INIPERIODOEMB").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					autocertificacion.setFeciniembarque(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_INIPERIODOEMB")).getTimestamp().getTime()));
				}
				else
				{
					if (mapCabCertiOrigen.get("FEC_INIPERIODOEMB") !=null && mapCabCertiOrigen.get("FEC_INIPERIODOEMB").getClass().getName().equals("java.lang.String"))
					{
						String valorStr = mapCabCertiOrigen.get("FEC_INIPERIODOEMB").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss").getTimestamp().getTime()));
						}
						else
						{
							if (valorStr.length() == 10 && valorStr.substring(4, 5).equals("-")
									&& valorStr.substring(7, 8).equals("-"))
							{
								autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd").getTimestamp().getTime()));
							}
							else
							{
								// PAS20155E220100048
								//autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_INIPERIODOEMB").toString())==null){
									autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime()));
								}else{
									autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));	
								}
							}
						}
						mapCabCertiOrigen.put("FEC_INIPERIODOEMB", autocertificacion.getFeciniembarque());
					}
					else
					{ if (mapCabCertiOrigen.get("FEC_INIPERIODOEMB") !=null){
						autocertificacion.setFeciniembarque((java.util.Date) mapCabCertiOrigen.get("FEC_INIPERIODOEMB"));
					}
					//          else{
					//            	 autocertificacion.setFeciniembarque(new FechaBean("00010101", "yyyyMMdd").getSQLDate());
					//            }
					}
				}
				if ( mapCabCertiOrigen.get("FEC_FINPEREMB") != null && mapCabCertiOrigen.get("FEC_FINPEREMB").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					autocertificacion.setFecfinembarque(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_FINPEREMB")).getTimestamp().getTime()));
				}
				else
				{
					if ( mapCabCertiOrigen.get("FEC_FINPEREMB") != null && mapCabCertiOrigen.get("FEC_FINPEREMB").getClass().getName().equals("java.lang.String"))
					{
						String valorStr = mapCabCertiOrigen.get("FEC_FINPEREMB").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss").getTimestamp().getTime()));
						}
						else
						{
							if (valorStr.length() == 10 && valorStr.substring(4, 5).equals("-")
									&& valorStr.substring(7, 8).equals("-"))
							{
								autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd").getTimestamp().getTime()));
							}
							else
							{
								// PAS20155E220100048
								//autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_FINPEREMB").toString())==null){
									autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime()));
								}else{
									autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								}
							}
						}
						mapCabCertiOrigen.put("FEC_FINPEREMB", autocertificacion.getFecfinembarque());
					} 
					else
					{ if(mapCabCertiOrigen.get("FEC_FINPEREMB") != null){
						autocertificacion.setFecfinembarque((java.util.Date) mapCabCertiOrigen.get("FEC_FINPEREMB"));
					}
					//          ELSE{
					//         	 AUTOCERTIFICACION.SETFECFINEMBARQUE(NEW FECHABEAN("00010101", "YYYYMMDD").GETSQLDATE());
					//               }
					}
				}

				if (mapCabCertiOrigen.get("FEC_EMBORIGEN") !=null && mapCabCertiOrigen.get("FEC_EMBORIGEN").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(
							((FechaBean) mapCabCertiOrigen.get("FEC_EMBORIGEN")).getTimestamp().getTime()));
				}
				else
				{
					if (mapCabCertiOrigen.get("FEC_EMBORIGEN") !=null && mapCabCertiOrigen.get("FEC_EMBORIGEN").getClass().getName().equals("java.lang.String"))
					{
						String valorStr = mapCabCertiOrigen.get("FEC_EMBORIGEN").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss").getTimestamp().getTime()));
						}
						else
						{
							if (valorStr.length() == 10 && valorStr.substring(4, 5).equals("-")
									&& valorStr.substring(7, 8).equals("-"))
							{
								mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd").getTimestamp().getTime()));
							}
							else
							{
								// PAS20155E220100048
								//mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_EMBORIGEN").toString())==null){
									mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime()));
								}
								else{
									mapCabCertiOrigen.put("FEC_EMBORIGEN", new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy").getTimestamp().getTime()));
								}
							}
						}
					}
					else
					{ if(mapCabCertiOrigen.get("FEC_EMBORIGEN") !=null){
						// mapCabCertiOrigen.put("FEC_EMBORIGEN", (java.util.Date) mapCabCertiOrigen.get("FEC_FINPEREMB"));
						mapCabCertiOrigen.put("FEC_EMBORIGEN", (java.util.Date) mapCabCertiOrigen.get("FEC_EMBORIGEN"));
					}
					//          else{
					//        	  mapCabCertiOrigen.put("FEC_EMBORIGEN",new FechaBean("00010101", "yyyyMMdd").getSQLDate());
					//                }
					}
				}

				//tlc cOREA DEFECTO NO SETEA EL CERTIORIGEN E
				autocertificacion.setNumcorredoc(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC").toString()));
				autocertificacion.setCodmoneda((java.lang.String)(mapCabCertiOrigen.get("COD_MONEDAFACT")));
				autocertificacion.setMtofobmon(SunatNumberUtils.toBigDecimal(mapCabCertiOrigen.get("MTO_FACTURA")));
				//FIN tlc cOREA
				//autocertificacion.setDesmercancia((java.lang.String) mapCabCertiOrigen.get("NOM_PRODMERC"));
				autocertificacion.setNomproduc((java.lang.String) mapCabCertiOrigen.get("NOM_PRODMERC")); //PAS399
				autocertificacion.setNomProdmerc((java.lang.String) mapCabCertiOrigen.get("NOM_PRODMERC"));
				autocertificacion.setCodcriterioO((java.lang.String) mapCabCertiOrigen.get("COD_CRITERIOORIGEN"));
				autocertificacion.setIndtrans((java.lang.String) mapCabCertiOrigen.get("IND_PROCETERCERPAIS"));
				autocertificacion.setNumsecCO(SunatNumberUtils.toInteger(mapCabCertiOrigen.get("NUM_SECDOC")));
				autocertificacion.setCodPuertoEmbOrigen((java.lang.String)(mapCabCertiOrigen.get("COD_PTOEMBORIGEN")));//adicionado por PAS20155E220200192
				autocertificacion.setNumautoexp((java.lang.String)mapCabCertiOrigen.get("NUM_AUTORIZEXP"));//adicionado por PAS20155E220200192
				autocertificacion.setCodffco((java.lang.String)mapCabCertiOrigen.get("COD_FFCO"));//adicionado por PAS20155E220200192
				autocertificacion.setIndElectronico((java.lang.String)(mapCabCertiOrigen.get("IND_ELECTRONICO")!=null?mapCabCertiOrigen.get("IND_ELECTRONICO"):"0"));//adicionado por PAS20181U220200056
				//TLC Corea Pas 2016-66
				//Se a�ade al objeto el indicador de modificacion de la fecha en la evaluacion del CO.
				if (mapCabCertiOrigen.get("IND_CAMBIO_EVAL")!=null){
					autocertificacion.setCambioCertiEvaluacion((java.lang.Boolean)mapCabCertiOrigen.get("IND_CAMBIO_EVAL"));
				}
				//fin TLC Corea
				listAutocertificacion.add(autocertificacion);


				/*RIN13INSI*/
				List<Map<String, Object>> lstDocAutAsociado = null;
				if (mapCabDeclara.containsKey("lstDocAutAsociado"))
					lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado" + sufijo);
				//Inicio RIN10   
				if(RECTIFICACION.equals(tipoDiligencia)){
					lstDocAutAsociado = (List<Map<String, Object>>) mapinput.get("lstDocAutAsociado" + sufijo);
				}
				//Fin RIN10 

				if (!CollectionUtils.isEmpty(lstDocAutAsociado)) {
					addOtroDocSoporte(declaracion, lstDocAutAsociado, listOtrosDocSoporte);
				}
			}

			declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion(listAutocertificacion); 
		}

		/*RIN13INSI*/
		List<Map<String, Object>> lstDocAutAsociado = null;
		if (mapCabDeclara.containsKey("lstDocAutAsociado"))
			lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado" + sufijo);
		//Inicio RIN10 
		if(RECTIFICACION.equals(tipoDiligencia)){
			lstDocAutAsociado = (List<Map<String, Object>>) mapinput.get("lstDocAutAsociado" + sufijo);
		}
		//Fin RIN10

		if (!CollectionUtils.isEmpty(lstDocAutAsociado)) {
			addOtroDocSoporte(declaracion, lstDocAutAsociado, listOtrosDocSoporte);
		}


		//amancilla inicio PAS20165E220200126
		Elementos<DAV> listDAVs = new Elementos<DAV>();
		declaracion.setListDAVs(listDAVs);
		//amancilla fin PAS20165E220200126

		if (!CollectionUtils.isEmpty(lstFormBProveedor))
		{

			//PAS20165E220200126 Elementos<DAV> listDAVs = new Elementos<DAV>();
			//PAS20165E220200126 declaracion.setListDAVs(listDAVs);

			for (Map formBProveedor : lstFormBProveedor)
			{

				DAV dav = new DAV();
				listDAVs.add(dav);

				//dav.setNumsecuprov(new Integer(ObjectUtils.toString(formBProveedor.get("NUM_SECPROVE"), "0")));
				dav.setNumsecuprov(new Integer(ObjectUtils.toString(this.getObjectFromMap(formBProveedor,"NUM_SECPROVE"), "0")));
				dav.setNumenvio(new Integer(ObjectUtils.toString(formBProveedor.get("NUM_ENVIO"), "0")));
				dav.setCntfacturas(new Integer(ObjectUtils.toString(formBProveedor.get("CNT_FACT"), "0")));

				dav.setNumcorredoc(new Long(ObjectUtils.toString(formBProveedor.get("NUM_CORREDOC"), "0")));
				dav.setNumcodsecprove(new Long(ObjectUtils.toString(formBProveedor.get("NUM_CODSECPROVE"), "0")));
				dav.setNumsecintermediario(new Long(ObjectUtils.toString(formBProveedor.get("NUM_SECINTERMEDIARIO"), "0")));
				dav.setNumsecdeclarante(new Long(ObjectUtils.toString(formBProveedor.get("NUM_SECDECLARANTE"), "0")));

				dav.setCodproveedor(ObjectUtils.toString(formBProveedor.get("COD_PROVE"), null));
				dav.setCodnivcomer(ObjectUtils.toString(formBProveedor.get("COD_NIVELCOMER"), null));
				dav.setCodnatutrans(ObjectUtils.toString(formBProveedor.get("COD_NATUTRANS"), null));
				dav.setCodformenvio(ObjectUtils.toString(formBProveedor.get("COD_FORMAENVIO"), null));
				dav.setIndexisinter(ObjectUtils.toString(formBProveedor.get("IND_INTEMEDIARIO"), null));
				dav.setCodcondprov(ObjectUtils.toString(formBProveedor.get("COD_CONDPROVE"), null));
				dav.setCodtipinter(ObjectUtils.toString(formBProveedor.get("COD_TIPINTERM"), null));
				dav.setNomcargdecla(ObjectUtils.toString(formBProveedor.get("NOM_CARGO"), null));
				dav.setCodtipgrabado(ObjectUtils.toString(formBProveedor.get("COD_TIPGRABADO"), null));
				/*INICIO SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/ 	
				Elementos<DocumentoSoporteFormatoB> listDocumentoSoporteFormatoB = new Elementos<DocumentoSoporteFormatoB>();
				DocumentoSoporteFormatoB documentoSoporteFormatoB = new DocumentoSoporteFormatoB();
				
				documentoSoporteFormatoB.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("COD_MEDIO_PAGO"), null));
				documentoSoporteFormatoB.setDesMedioPago(ObjectUtils.toString(formBProveedor.get("DES_OTRO_MEDIO_PAGO"), null));
				documentoSoporteFormatoB.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("COD_ENTI_FINANC"), null));
				documentoSoporteFormatoB.setDesEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("DES_OTRO_ENTI_FINANC"), null));
				documentoSoporteFormatoB.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("COD_IDENT_PAGO"), null));
				documentoSoporteFormatoB.setTipoDocumento("450");
				
				listDocumentoSoporteFormatoB.add(documentoSoporteFormatoB);
				dav.setListDocumentoSoporteFormatoB(listDocumentoSoporteFormatoB);
				//new
				dav.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("COD_MEDIO_PAGO"), null));
				dav.setDesMedioPago(ObjectUtils.toString(formBProveedor.get("DES_OTRO_MEDIO_PAGO"), null));
				dav.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("COD_IDENT_PAGO"), null));
				dav.setDesEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("DES_OTRO_ENTI_FINANC"), null));
				dav.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("COD_ENTI_FINANC"), null));
				/*FIN SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/  	
				
				dav.setPadre(declaracion); /*RIN 07-RIN 13 gmontoya pase 42 sustento rzavala*/


				if (dav.getProveedorLocal() == null)
				{
					dav.setProveedorLocal(new Participante());
					dav.getProveedorLocal().setTipoDocumentoIdentidad(new DataCatalogo());
				}
				dav
				.getProveedorLocal()
				.getTipoDocumentoIdentidad()
				.setCodDatacat(ObjectUtils.toString(formBProveedor.get("COD_DOCPROVLOCAL"), null));
				dav.getProveedorLocal().setNumeroDocumentoIdentidad(
						ObjectUtils.toString(formBProveedor.get("COD_DOCIDENTPROVLOC"), null));

				// dav.setListMontos()
				/**     Comentado para ser reemplazado por lo sgte del pase 42:
        Map mapFormBMonto = (Map) formBProveedor.get("mapFormBMonto" + sufijo);
        if (!CollectionUtils.isEmpty(mapFormBMonto))
        {
          Elementos<DatoMonto> listMontos = new Elementos<DatoMonto>();
        //  dav.setListMontos(listMontos);

          Set keySetFormBMonto = mapFormBMonto.keySet();
          for (Object key : keySetFormBMonto)
          {
            DatoMonto monto = new DatoMonto();
            monto.setCodmonto(key.toString()); // "COD_MONTO"
            monto.setMtologistico(new java.math.BigDecimal(mapFormBMonto.get(key).toString())); // "MTO_VALOR"
            listMontos.add(monto);
          }
          dav.setListMontos(listMontos);
        }
				 **/
				/**Inicio de cambios pase 42 AREY*/
				if (!CollectionUtils.isEmpty(lstFormbMonto))
				{      	    	
					Elementos<DatoMonto> listMontos = new Elementos<DatoMonto>();   
					for(Map formBMonto : lstFormbMonto)
					{
						if(formBMonto.get("NUM_SECPROVE").toString().equalsIgnoreCase(dav.getNumsecuprov().toString())){//SAU20153D211200184-PAS20155E220200081
							Set keySetFormBMonto = formBMonto.keySet();
							DatoMonto monto = new DatoMonto();
							for (Object key : keySetFormBMonto)
							{
								if(key.toString().equals("COD_MONTO")){
									monto.setCodmonto(formBMonto.get(key.toString()).toString()); // "COD_MONTO"
								}
								if(key.toString().equals("MTO_VALOR")){
									monto.setMtologistico(new java.math.BigDecimal(formBMonto.get(key).toString())); // "MTO_VALOR"
								} 
							}
							listMontos.add(monto);
						}                 
					}
					dav.setListMontos(listMontos);
				}
				/**Fin de cambios pase 42 AREY*/
				//Inicio RIN10
				Map mapFormBMonto = (Map) formBProveedor.get("mapFormBMonto" + sufijo);

				if(RECTIFICACION.equals(tipoDiligencia)){
					//List<Map> lstFormbMonto = (List<Map>) mapinput.get("lstFormbMonto" + sufijo); Ya se le asigana en el PASE 42 AREY
					if(!CollectionUtils.isEmpty(lstFormbMonto)){
						for (Map map: lstFormbMonto){
							if(dav.getNumsecuprov().toString().equals(map.get("NUM_SECPROVE").toString())){
								mapFormBMonto = map;
								break;
							}
						}
					}
				}
				//Fin RIN10



				if (dav.getProveedor() == null)
				{
					dav.setProveedor(new Participante());
				}
				if (dav.getProveedor().getPais() == null)
				{
					dav.getProveedor().setPais(new DataCatalogo());
				}
				// obtener esta info de participante doc
				dav.getProveedor().getPais().setCodDatacat(
						formBProveedor.get("cod_paisorigen_prv") != null ? (java.lang.String) formBProveedor
								.get("cod_paisorigen_prv") : "");
				dav.getProveedor().setNombreRazonSocial(
						formBProveedor.get("nom_razonsocial_prv") != null ? (java.lang.String) formBProveedor
								.get("nom_razonsocial_prv") : "");
				dav.getProveedor().setCiudad(
						formBProveedor.get("des_ubigeociudad_prv") != null ? (java.lang.String) formBProveedor
								.get("des_ubigeociudad_prv") : "");        
				dav.getProveedor().setDireccion(formBProveedor.get("dir_partic_prv") != null ? (java.lang.String) formBProveedor
						.get("dir_partic_prv") : "");
				dav.getProveedor().setTelefono(formBProveedor.get("num_telefono_prv") != null ? (java.lang.String) formBProveedor
						.get("num_telefono_prv") : "");
				dav.getProveedor().setFax(formBProveedor.get("num_fax_prv") != null ? (java.lang.String) formBProveedor
						.get("num_fax_prv") : "");
				dav.getProveedor().setEmail(formBProveedor.get("nom_email_prv") != null ? (java.lang.String) formBProveedor
						.get("nom_email_prv") : "");
				dav.getProveedor().setPaginaWeb(formBProveedor.get("nom_paginaweb_prv") != null ? (java.lang.String) formBProveedor
						.get("nom_paginaweb_prv") : "");
				dav.getProveedor().setCodigoOea(formBProveedor.get("cod_empresa") != null ? (java.lang.String) formBProveedor
						.get("cod_empresa") : "");
				dav.getProveedor().setPaisOea(formBProveedor.get("cod_paisarm") != null ? (java.lang.String) formBProveedor
						.get("cod_paisarm") : "");
				
				dav.getProveedor().setSecuenciaDeParticipantes(formBProveedor.get("num_secpartic") != null ? new Long(formBProveedor.get("num_secpartic").toString()) : 0L);
				//Inicio pase16	OEA	 

				List<Map<String, Object>> lstParticipante = null;
				//ACTUALIZAR EMPRESA OEA  SI EXISTE RECTIFICACION 
				if(RECTIFICACION.equals(tipoDiligencia)){
				
				if (mapinput.containsKey("lstParticipante"+sufijo)){
					lstParticipante = (List<Map<String, Object>>) mapinput.get("lstParticipante" + sufijo);
					if(!CollectionUtils.isEmpty(lstParticipante)){
						
						 for (Map<String, Object> data : lstParticipante)
				           { 
				      		String secuenciaParticipante =  dav.getProveedor().getSecuenciaDeParticipantes().toString();
				      		String secparticipante = data.get("NUM_SECPARTIC")!=null?data.get("NUM_SECPARTIC").toString():" "; // control de nulos INC 2018-104781  
				         	 if (secparticipante.equals(secuenciaParticipante)){
				         		dav.getProveedor().setCodigoOea((String) data.get("COD_EMPRESA"));
				         		dav.getProveedor().setPaisOea((String) data.get("COD_PAISARM"));
				         	 }
				         	  
				           }
						
					}
				}
				}				
				
				
	
				//Fin pase 16

				
				
				// obtener esta info de participante doc
				if (dav.getProveedorLocal() == null)
				{
					dav.setProveedorLocal(new Participante());
				}
				dav.getProveedorLocal().setNombreRazonSocial(
						formBProveedor.get("nom_razonsocial_prl") != null ? (java.lang.String) formBProveedor
								.get("nom_razonsocial_prl") : "");

				if (dav.getIntermediario() == null)
				{
					dav.setIntermediario(new Participante());
				}
				if (dav.getIntermediario().getPais() == null)
				{
					dav.getIntermediario().setPais(new DataCatalogo());
				}
				// obtener esta info de participante doc
				dav.getIntermediario().getPais()
				.setCodDatacat(
						formBProveedor.get("cod_paisorigen") != null ? (java.lang.String) formBProveedor.get("cod_paisorigen")
								: "");
				dav.getIntermediario().setNombreRazonSocial(
						formBProveedor.get("nom_razonsocial_pri") != null ? (java.lang.String) formBProveedor
								.get("nom_razonsocial_pri") : "");
				dav.getIntermediario().setCiudad(
						formBProveedor.get("des_ubigeociudad_pri") != null ? (java.lang.String) formBProveedor
								.get("des_ubigeociudad_pri") : "");
				dav.getIntermediario()
				.setDireccion(
						formBProveedor.get("dir_partic_pri") != null ? (java.lang.String) formBProveedor.get("dir_partic_pri")
								: "");
				dav.getIntermediario().setEmail(
						formBProveedor.get("nom_email_pri") != null ? (java.lang.String) formBProveedor.get("nom_email_pri") : "");


				/*INICIO RNI07 - RIN13*/
				dav.getIntermediario().setNumeroDocumentoIdentidad(formBProveedor.get("num_docident_pri") != null ? (java.lang.String) formBProveedor.get("num_docident_pri"): "");
				dav.getIntermediario().getTipoDocumentoIdentidad().setCodDatacat(formBProveedor.get("cod_tipdoc_pri") != null ? (java.lang.String) formBProveedor.get("cod_tipdoc_pri"): ""); //RIN13
				dav.getIntermediario().getPais().setCodDatacat(formBProveedor.get("cod_paisorigen") != null ? (java.lang.String) formBProveedor.get("cod_paisorigen_pri"): ""); //RIN13
				dav.getIntermediario().setPaginaWeb(formBProveedor.get("nom_paginaweb_pri") != null ? (java.lang.String) formBProveedor.get("nom_paginaweb_pri") : "");
				dav.getIntermediario().setNombreRazonSocial(formBProveedor.get("nom_razonsocial_pri") != null ? (java.lang.String) formBProveedor.get("nom_razonsocial_pri") : "");
				dav.getIntermediario().setCiudad(formBProveedor.get("des_ubigeociudad_pri") != null ? (java.lang.String) formBProveedor.get("des_ubigeociudad_pri") : "");
				dav.getIntermediario().setDireccion(formBProveedor.get("dir_partic_pri") != null ? (java.lang.String) formBProveedor.get("dir_partic_pri"): "");
				dav.getIntermediario().setEmail(formBProveedor.get("nom_email_pri") != null ? (java.lang.String) formBProveedor.get("nom_email_pri") : "");
				/*FIN - RNI07 - RIN13*/


				if (dav.getPersonaDecl() == null)
				{
					dav.setPersonaDecl(new Participante());
				}
				dav.getPersonaDecl().setNumeroDocumentoIdentidad(
						formBProveedor.get("num_docident_prd") != null ? (java.lang.String) formBProveedor.get("num_docident_prd")
								: "");
				//INICIO GMONTOYA PASE 153 2015
				DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();        
				tipoDocumentoIdentidad.setCodDatacat(formBProveedor.get("cod_tipdoc_prd") != null ?  (java.lang.String) formBProveedor.get("cod_tipdoc_prd") : "");
				dav.getPersonaDecl().setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
				//FIN GMONTOYA PASE 153 2015


				dav.getPersonaDecl().setNombreRazonSocial(
						formBProveedor.get("nom_razonsocial_prd") != null ? (java.lang.String) formBProveedor
								.get("nom_razonsocial_prd") : "");

				List<Map> lstComproBPago = null;

				//amancilla      
				if (formBProveedor.containsKey("lstComproBPago" + sufijo)){
					lstComproBPago = (List<Map>) formBProveedor.get("lstComproBPago" + sufijo);
				}else if (mapinput.containsKey("lstComproBPagoActual")){

					lstComproBPago = (List<Map>) mapinput.get("lstComproBPagoActual");
					lstComproBPago = filtrarComproBPagoXProveedor(lstComproBPago,dav.getNumsecuprov());        	        	
				}
				//Inicio RIN10
				//else if (mapinput.containsKey("lstComproBPagoActual")){
				if(RECTIFICACION.equals(tipoDiligencia)){
					//lstComproBPago = (List<Map>) mapinput.get("lstComproBPagoActual"); 
					lstComproBPago = (List<Map>) mapinput.get("lstComproBPago" + sufijo);
					//Fin RIN10
					lstComproBPago = filtrarComproBPagoXProveedor(lstComproBPago,dav.getNumsecuprov());        	        	
				}



				if (!CollectionUtils.isEmpty(lstComproBPago))
				{
					Elementos<DatoFactura> listFacturas = new Elementos<DatoFactura>();
					dav.setListFacturas(listFacturas);
					for (Map comproBPago : lstComproBPago)
					{
						if(Constantes.IND_ELIMINADO.equals(comproBPago.get("IND_DEL"))){//mol
							continue;  
						}

						DatoFactura factura = new DatoFactura();
						listFacturas.add(factura);//jenciso ceticos parte1
						factura.setNumsecprove(dav.getNumsecuprov());//jenciso ceticos parte1
						factura.setNumsecfactu(SunatNumberUtils.toInteger(comproBPago.get("num_secfact")!=null?comproBPago.get("num_secfact"):comproBPago.get("NUM_SECFACT")));
						factura.setCnttotitems(SunatNumberUtils.toInteger(comproBPago.get("cnt_totitems")!=null?comproBPago.get("cnt_totitems"):comproBPago.get("CNT_TOTITEMS")));
						factura.setNumfactura((java.lang.String) (comproBPago.get("num_fact")!=null?comproBPago.get("num_fact"):comproBPago.get("NUM_FACT")));
						factura.setPadre(dav); /*RIN 07-RIN 13*/

						if ((comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT"))
								.getClass()
								.getName()
								.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
						{
							factura.setFecfactura(new java.util.Date(((FechaBean) (comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT")))
									.getTimestamp()
									.getTime()));
						}
						else
						{

							factura.setFecfactura(Utilidades.toDate(comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT")));

						}

						factura.setCodincoterm((java.lang.String) (comproBPago.get("cod_incoterm")!=null?comproBPago.get("cod_incoterm"):comproBPago.get("COD_INCOTERM")));
						factura.setDeslugtrans((java.lang.String) (comproBPago.get("dir_lugartrans")!=null?comproBPago.get("dir_lugartrans"):comproBPago.get("DIR_LUGARTRANS")));
						factura.setCodmoneda((java.lang.String) (comproBPago.get("cod_moneda")!=null?comproBPago.get("cod_moneda"):comproBPago.get("COD_MONEDA")));
						factura.setCodpaisembar((java.lang.String) comproBPago.get("cod_paisembarque"));
						factura.setMtofactufob(SunatNumberUtils.toBigDecimal((comproBPago.get("mto_fact")!=null?comproBPago.get("mto_fact"):comproBPago.get("MTO_FACT"))));
						factura.setIndtipodecl((java.lang.String) (comproBPago.get("ind_ddjj")!=null?comproBPago.get("ind_ddjj"):comproBPago.get("IND_DDJJ")));
						//jenciso Inicio se cargan las facturas sucesivas
						List<Map<String,Object>> lstFactuSucesivas = null;
						if(comproBPago.containsKey("lstFactuSucesivas" + sufijo))
							lstFactuSucesivas = (List<Map<String,Object>>)comproBPago.get("lstFactuSucesivas" + sufijo);
						//Inicio RIN10
						if(RECTIFICACION.equals(tipoDiligencia)){
							lstFactuSucesivas = (List<Map<String,Object>>) mapinput.get("lstFactuSuce" + sufijo);

							lstFactuSucesivas  = filtrarFacturaSucecivaXfactura(lstFactuSucesivas, SunatNumberUtils.toInteger(comproBPago.get("num_secfact")));
						}
						//Fin RIN10

						if(!CollectionUtils.isEmpty(lstFactuSucesivas)){
							Elementos<DatoFactSuce> listFactSuces = new Elementos<DatoFactSuce>();            	
							factura.setListFactSucesivas(listFactSuces);

							for(Map<String,Object> factSuce: lstFactuSucesivas){
								DatoFactSuce datoFactSuce = new DatoFactSuce();
								//datoFactSuce.setNumcorredoc(numcorredoc);
								datoFactSuce.setNumsecprove(dav.getNumsecuprov());
								datoFactSuce.setNumsecfact(SunatNumberUtils.toInteger(comproBPago.get("num_secfact")));
								datoFactSuce.setNumfactsuc((String)factSuce.get("NUM_FACT"));
								datoFactSuce.setMtofactsuc(SunatNumberUtils.toBigDecimal(factSuce.get("MTO_FACT")));
								listFactSuces.add(datoFactSuce);

							}
						}
						//jenciso Fin

						List<Map> lstItemFactura = null;

						if (comproBPago.containsKey("lstItemFactura" + sufijo)) //jenciso se cambia al map correcto
						{
							lstItemFactura = (List<Map>) comproBPago.get("lstItemFactura" + sufijo);//jenciso se cambia al map correcto
						}
						//Inicio RIN10	
						//else if (mapinput.containsKey("lstItemFacturaActual")){
						if(RECTIFICACION.equals(tipoDiligencia)){
							//lstItemFactura = (List<Map>) mapinput.get("lstItemFacturaActual");            	
							lstItemFactura = (List<Map>) mapinput.get("lstItemFactura"+ sufijo);
							//Fin RIN10
							lstItemFactura = filtrarItemFacturaXfactura(lstItemFactura,factura.getNumsecfactu());
						}
						//Pase 42 MOL
						//inicio Eliminar duplicado de serieitem de la factura
						if (!CollectionUtils.isEmpty(lstItemFactura))
						{ 
							List<Map> lstSeriesItemAux =  new ArrayList<Map>();
							Integer cantidad = 0;
							List<Map> lstSeriesItemAux1 =   new ArrayList<Map>();

							// Map<String, Object> mapSerieItem1 = new HashMap<String, Object>();

							for (Map mapSerieItem : lstItemFactura)
							{ lstSeriesItemAux1.add(mapSerieItem);
							cantidad =0;
							for (Map mapSerieItemAux : lstSeriesItemAux1)
							{  if(mapSerieItemAux.containsKey("NUM_SECFACT") && mapSerieItemAux.containsKey("NUM_SECITEM")){
								if(mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
									cantidad++;              			  
								}
							}
							}
							if(cantidad==1){
								lstSeriesItemAux.add(mapSerieItem);
							}else { 
								if(cantidad>1){//por SAU
									List<Map> lstSeriesItemAux2 =  new ArrayList<Map>();
									lstSeriesItemAux2 = lstSeriesItemAux;
									for (Map mapSerieItemAux : lstSeriesItemAux2){
										if(mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
											if(mapSerieItem.containsKey("indica") && "N".equals(mapSerieItem.get("indica"))){
												mapSerieItem.put("IND_DEL","0");
												lstSeriesItemAux.remove(mapSerieItemAux);
												lstSeriesItemAux.add(mapSerieItem); 
												break;
											}

										}
									}


								}
							}

							}
							lstItemFactura.clear();
							lstItemFactura.addAll(lstSeriesItemAux);

						}
						//fin mol

						if (!CollectionUtils.isEmpty(lstItemFactura))
						{
							Elementos<DatoItem> listItems = new Elementos<DatoItem>(); //jenciso ceticos parte 1
							factura.setListItems(listItems); //jenciso ceticos parte 1
							//rtineo mejoras, agrupamos las descripciones minimas para realizar el recorrido una sola vez
							String codTransaccionTmp = declaracion.getCodtipotrans();
							Map<String,List<Map<String,Object>>> mapFormBItemDescri = new HashMap<String , List<Map<String,Object>>>();
							if (SunatStringUtils.include(codTransaccionTmp, new String[]{"07", declaracion.getDua().getCodregimen().concat("07")})){
								Object objectFormBItemDescri = mapinput.get("lstFormBItemDescri"+sufijo);
								if(objectFormBItemDescri instanceof List){
									List<Map<String,Object>> lstFormBItemDescri =  (ArrayList<Map<String,Object>>)objectFormBItemDescri;
									if(!CollectionUtils.isEmpty(lstFormBItemDescri)){
										for(Map<String,Object> formBItemDescri:lstFormBItemDescri){
											Integer numSecProveFormBItemDescri= SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECPROVE")!=null?formBItemDescri.get("NUM_SECPROVE").toString():"");
											Integer numSecFactFormBItemDescri = SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECFACT")!=null?formBItemDescri.get("NUM_SECFACT").toString():"");
											Integer numSecItemFormBItemDescri = SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECITEM")!=null?formBItemDescri.get("NUM_SECITEM").toString():"");
											String identificador =  numSecProveFormBItemDescri + "-" + numSecFactFormBItemDescri + "-" + numSecItemFormBItemDescri;
											String codIndElimina = formBItemDescri.get("IND_DEL")!=null?formBItemDescri.get("IND_DEL").toString():"";
											if(!codIndElimina.equals("1")){
												List<Map<String,Object>> listPorItem =  mapFormBItemDescri.get(identificador);
												if(listPorItem == null){
													listPorItem = new ArrayList<Map<String,Object>>();
													mapFormBItemDescri.put(identificador, listPorItem);
												}
												listPorItem.add(formBItemDescri);
											}
										}
									}
								}
							}
							//rtineo mejoras, no es necesario ejecutar dentro del bucle
							//causa uso excesivo del procesador
							if (!CollectionUtils.isEmpty(lstSeriesItemActual))
							{ 
								List<Map<String,Object>> lstSeriesItemAux =  new ArrayList<Map<String,Object>>();
								Integer cantidad = 0;
								List<Map> lstSeriesItemAux1 =   new ArrayList<Map>();
								for (Map<String,Object> mapSerieItem : lstSeriesItemActual)
								{ lstSeriesItemAux1.add(mapSerieItem);
								cantidad =0;
								for (Map mapSerieItemAux : lstSeriesItemAux1)
								{  if(mapSerieItemAux.containsKey("NUM_SECSERIE") && mapSerieItemAux.containsKey("NUM_SECFACT") && mapSerieItemAux.containsKey("NUM_SECITEM")){
									if(mapSerieItem.get("NUM_SECSERIE").equals(mapSerieItemAux.get("NUM_SECSERIE")) && mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
										cantidad++;              			  
									}
								}
								}
								if(cantidad==1){
									lstSeriesItemAux.add(mapSerieItem);
								}else { 
									if(cantidad>1){
										List<Map<String,Object>> lstSeriesItemAux2 =  new ArrayList<Map<String,Object>>();
										lstSeriesItemAux2 = lstSeriesItemAux;
										for (Map<String,Object> mapSerieItemAux : lstSeriesItemAux2){
											if(mapSerieItem.get("NUM_SECSERIE").equals(mapSerieItemAux.get("NUM_SECSERIE")) && mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
												if(mapSerieItem.containsKey("indica") && "N".equals(mapSerieItem.get("indica"))){
													mapSerieItem.put("IND_DEL","0");                     					
													if(!mapSerieItem.containsKey("MTO_AJUSTE")){
														mapSerieItem.put("MTO_AJUSTE", 0);
													}
													lstSeriesItemAux.remove(mapSerieItemAux);
													lstSeriesItemAux.add(mapSerieItem);	
													break;
												}

											}
										}


									}
								}

								}
								lstSeriesItemActual.clear();
								lstSeriesItemActual.addAll(lstSeriesItemAux);
							}                
							//rtineo mejoras, fin
							for (Map itemFactura : lstItemFactura)
							{
								if(Constantes.IND_ELIMINADO.equals(itemFactura.get("IND_DEL"))){//adicionado por PAS20145E220000682
									continue;  
								}

								DatoItem item = new DatoItem();
								listItems.add(item);
								item.setNumsecprove(dav.getNumsecuprov());//jenciso ceticos parte 1
								item.setNumsecfact(factura.getNumsecfactu());//jenciso ceticos parte 1
								item.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
								if(itemFactura.get("COD_PAISORIGEN")!=null && itemFactura.get("COD_PAISORIGEN").toString().indexOf("-") != -1){
									itemFactura.put("COD_PAISORIGEN", SunatStringUtils.substring(itemFactura.get("COD_PAISORIGEN").toString(), 0, itemFactura.get("COD_PAISORIGEN").toString().indexOf("-")));
								}
								item.setCodpaisorige((java.lang.String) itemFactura.get("COD_PAISORIGEN"));
								item.setCntcantcomer(SunatNumberUtils.toBigDecimal(itemFactura.get("CNT_UNI")));
								item.setCodunidcomer((java.lang.String) itemFactura.get("COD_UNICOMER"));
								item.setDescomercial((java.lang.String) itemFactura.get("DES_COMER"));
								item.setDesmarca((java.lang.String) itemFactura.get("DES_MARCA"));
								item.setDesmodelo((java.lang.String) itemFactura.get("DES_MODELO"));
								item.setCodproducto((java.lang.String) itemFactura.get("COD_PROD"));
								item.setNumpartnandi(SunatNumberUtils.toLong(itemFactura.get("NUM_PARARANCEL")));
								item.setCodpaisadqui((java.lang.String) itemFactura.get("COD_PAISADQUI"));
								item.setDescaracteristicas((java.lang.String) itemFactura.get("DES_CARACTERISTICAS"));
								item.setDesclasevari((java.lang.String) itemFactura.get("DES_CLASEVARI"));
								item.setDesusoaplica((java.lang.String) itemFactura.get("DES_USOAPLIC"));
								item.setDesmaterialcomp((java.lang.String) itemFactura.get("DES_MATERIALCOMP"));
								//FSW-INICIO
								item.setCodtipdescrmin((java.lang.String) itemFactura.get("COD_TIPDESCRMIN"));     
								String codTipDescrMin = itemFactura.get("COD_TIPDESCRMIN")!=null?itemFactura.get("COD_TIPDESCRMIN").toString():"";
								boolean esDescrMinimaNueva = codTipDescrMin.length()> 0;
								/**Inicio de cambios solucion Definitiva para INC 2016-003507*/
								if (!CollectionUtils.isEmpty(declaracion.getDua().getListObservaciones())) {
									Elementos<Observacion> listObservacionItem = new Elementos<Observacion>();
									for(Observacion observacionItem :declaracion.getDua().getListObservaciones()){
										if(observacionItem.getCodtipobserva().equals("03") &&
												observacionItem.getNumsecitem().equals(item.getNumsecitem())){
											listObservacionItem.add(observacionItem);
										}
									}
									item.setListObservaciones(listObservacionItem);
								}
								/**Fin de cambios solucion DEFINITIVA*/
								//FSW-INICIO
								item.setPadre(factura); /*RIN 07-RIN 13*/

								//Pase 399-RECTIFICACION DESCRIPCIONES MINIMAS
								String codTransaccion = declaracion.getCodtipotrans();
								if (SunatStringUtils.include(codTransaccion, new String[]{"07", declaracion.getDua().getCodregimen().concat("07")})) {

									Object objectFormBItemDescri = mapinput.get("lstFormBItemDescri"+sufijo);
									if(objectFormBItemDescri instanceof List)
									{	
										List<Map<String,Object>> lstFormBItemDescri =  (ArrayList<Map<String,Object>>)objectFormBItemDescri;
										if(!CollectionUtils.isEmpty(lstFormBItemDescri))
										{
											Elementos<DatoDescrMinima> listDecrMinima = new Elementos<DatoDescrMinima>();
											item.setListDecrMinima(listDecrMinima);
											//rtineo mejoras, se omite la busqueda por todos las descripciones minimas
											String identificador =  item.getNumsecprove() + "-" + item.getNumsecfact() + "-" + item.getNumsecitem();
											List<Map<String,Object>> listPorItem = mapFormBItemDescri.get(identificador);
											for(Map<String,Object> formBItemDescri : listPorItem){

												/*INICIO-PAS20165E220200137 AFMA*/
												String indicadorEliminado= formBItemDescri.get("IND_DEL")!=null?formBItemDescri.get("IND_DEL").toString():"0";
												if("0".equals(indicadorEliminado)) {
												/*FIN-PAS20165E220200137 AFMA*/
													DatoDescrMinima datoDescrMinima = new DatoDescrMinima();

													datoDescrMinima.setNumcorredoc(dav.getNumcorredoc());
													datoDescrMinima.setNumsecprove(dav.getNumsecuprov());
													datoDescrMinima.setNumsecfact(factura.getNumsecfactu());
													datoDescrMinima.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
													datoDescrMinima.setCodtipdescr((String) formBItemDescri.get("COD_TIPDESC"));
													if (esDescrMinimaNueva) {
														datoDescrMinima.setCodtipvalor((String) formBItemDescri.get("COD_TIPVALOR"));
														datoDescrMinima.setValtipdescri(formBItemDescri.get("DES_DESCRIPCION").toString());//se quita el trim
													} else {
														if (datoDescrMinima.getCodtipdescr().equals("04"))
															datoDescrMinima.setValtipdescri((java.lang.String) itemFactura.get("DES_CLASEVARI"));
														else
															datoDescrMinima.setValtipdescri((String) formBItemDescri.get("DES_DESCRIPCION"));
													}
													datoDescrMinima.setPadre(item);//gmontoya Pase 42 2015 sustento rzavala
													listDecrMinima.add(datoDescrMinima);
												/*INICIO-PAS20165E220200137 AFMA*/
												}
												/*FIN-PAS20165E220200137 AFMA*/
											}
											//metodo antiguo
											/*for(Map<String,Object> formBItemDescri:lstFormBItemDescri)
	  	                	{	
	  	                		Integer numSecProveFormBItemDescri= SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECPROVE")!=null?formBItemDescri.get("NUM_SECPROVE").toString():"");
	  	                		Integer numSecFactFormBItemDescri = SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECFACT")!=null?formBItemDescri.get("NUM_SECFACT").toString():"");
	  	                	    Integer numSecItemFormBItemDescri = SunatNumberUtils.toInteger(formBItemDescri.get("NUM_SECITEM")!=null?formBItemDescri.get("NUM_SECITEM").toString():"");
	  	                	    String codIndElimina = formBItemDescri.get("IND_DEL")!=null?formBItemDescri.get("IND_DEL").toString():"";
	  	         	    	    if(item.getNumsecprove().equals(numSecProveFormBItemDescri)  && item.getNumsecfact().equals(numSecFactFormBItemDescri) && item.getNumsecitem().equals(numSecItemFormBItemDescri) && !codIndElimina.equals("1"))

		  	         			  {
			  	                		DatoDescrMinima  datoDescrMinima = new DatoDescrMinima();
			  	                		datoDescrMinima.setNumcorredoc(dav.getNumcorredoc());
			  	                		datoDescrMinima.setNumsecprove(dav.getNumsecuprov());
			  	                		datoDescrMinima.setNumsecfact(factura.getNumsecfactu());
			  	                		datoDescrMinima.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
			  	                		datoDescrMinima.setCodtipdescr((String)formBItemDescri.get("COD_TIPDESC"));
				                  		if(esDescrMinimaNueva){
				                  			datoDescrMinima.setCodtipvalor((String)formBItemDescri.get("COD_TIPVALOR"));
				                  			datoDescrMinima.setValtipdescri((String)formBItemDescri.get("DES_DESCRIPCION").toString().trim());
				                  		}else{
					  	                		if(datoDescrMinima.getCodtipdescr().equals("04")) 
					  	                			datoDescrMinima.setValtipdescri((java.lang.String) itemFactura.get("DES_CLASEVARI"));
					  	                		else
					  	                			datoDescrMinima.setValtipdescri((String)formBItemDescri.get("DES_DESCRIPCION"));
				                  		}
				                  		datoDescrMinima.setPadre(item);//gmontoya Pase 42 2015 sustento rzavala
			  	                		listDecrMinima.add(datoDescrMinima);		  	                		
		  	         			  }
	  	                	  }*/
											//rtineo fin mejoras
										}
									}
								}
								else {
									//jenciso Inicio agregamos lista de descripciones minimas
									//hacemos esta forma debido a que en la diligencia solo 
									//se esta modificando en el itemfactura mas no en el formbitemdescri
									//RIN13 x mientras ya que sale error lstDecrMinima String no List verificar porque se setea String y no List!!!!!!!!!!!!!!!!!!!
									Object objectDecrMinima = itemFactura.get("lstDecrMinima" + sufijo);
									if(objectDecrMinima instanceof List){
										//List<Map<String,Object>> lstDecrMinima =  (ArrayList<Map<String,Object>>)itemFactura.get("lstDecrMinima" + sufijo);
										List<Map<String,Object>> lstDecrMinima =  (ArrayList<Map<String,Object>>)objectDecrMinima;
										if(!CollectionUtils.isEmpty(lstDecrMinima)){
											Elementos<DatoDescrMinima> listDecrMinima = new Elementos<DatoDescrMinima>();
											item.setListDecrMinima(listDecrMinima);
											for(Map<String,Object> mapDescriMin : lstDecrMinima){

												/*INICIO-PAS20165E220200137 AFMA*/
												String indicadorEliminado= mapDescriMin.get("IND_DEL")!=null?mapDescriMin.get("IND_DEL").toString():"0";
												if("0".equals(indicadorEliminado)) {
												/*FIN-PAS20165E220200137 AFMA*/

													DatoDescrMinima  datoDescrMinima = new DatoDescrMinima();
													datoDescrMinima.setNumcorredoc(dav.getNumcorredoc());
													datoDescrMinima.setNumsecprove(dav.getNumsecuprov());
													datoDescrMinima.setNumsecfact(factura.getNumsecfactu());
													datoDescrMinima.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
													datoDescrMinima.setCodtipdescr((String)mapDescriMin.get("COD_TIPDESC"));
													if(esDescrMinimaNueva){
														datoDescrMinima.setCodtipvalor((String)mapDescriMin.get("COD_TIPVALOR"));
														datoDescrMinima.setValtipdescri(mapDescriMin.get("DES_DESCRIPCION").toString());//se quita el trim
													}else{
														if(datoDescrMinima.getCodtipdescr().equals("04")) // esto solo es temporal...
															datoDescrMinima.setValtipdescri((java.lang.String) itemFactura.get("DES_CLASEVARI"));
														else
															datoDescrMinima.setValtipdescri((String)mapDescriMin.get("DES_DESCRIPCION"));
													}
													datoDescrMinima.setPadre(item);//gmontoya Pase 42 2015 sustento rzavala
													listDecrMinima.add(datoDescrMinima);

												/*INICIO-PAS20165E220200137 AFMA*/
												}
												/*FIN-PAS20165E220200137 AFMA*/
											}
										}
									}
								}
								//jenciso Fin agregamos lista de descripciones minimas

								//jenciso item.getMontoProv() NO DEFINIDO 
								if(item.getMontoProv() == null){
									item.setMontoProv(new DatoMontoProv());
								}

								if (itemFactura.get("FEC_VALESTIMA")!= null && itemFactura.get("FEC_VALESTIMA").getClass().getName()
										.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
								{
									item.getMontoProv().setFecvalestima(
											new java.util.Date(((FechaBean) itemFactura.get("FEC_VALESTIMA")).getTimestamp().getTime()));
								}
								else
								{
									//item.getMontoProv().setFecvalestima((java.util.Date) itemFactura.get("FEC_VALESTIMA"));
									item.getMontoProv().setFecvalestima( Utilidades.toDate(itemFactura.get("FEC_VALESTIMA")));
								}

								item.getMontoProv().setValmonto(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_MONTO")));
								item.getMontoProv().setCodmoneda((java.lang.String) itemFactura.get("COD_MONEDA"));
								//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								if (itemFactura.get("FEC_TIPCAMB") != null && 
										itemFactura.get("FEC_TIPCAMB")
										.getClass()
										.getName()
										.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
								{
									item.getMontoProv().setFectipocambio(
											new java.util.Date(((FechaBean) itemFactura.get("FEC_TIPCAMB")).getTimestamp().getTime()));
								}
								else
								{
									item.getMontoProv().setFectipocambio((java.util.Date) itemFactura.get("FEC_TIPCAMB"));
								}
								//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								item.getMontoProv().setValdefinitivo(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_DEFINITIVO")));

								//RIN10-FSW AFMA
								List<Map<String,Object>> lstVfobProvisional = (List<Map<String,Object>>)itemFactura.get("lstVfobProvisional");
								if(RECTIFICACION.equals(tipoDiligencia)){
									lstVfobProvisional = (ArrayList<Map<String,Object>>)  mapinput.get("lstVFobProvisional" + sufijo);
									lstVfobProvisional = filtrarVfobProvisionalXitem(lstVfobProvisional, SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
								}

								if(!CollectionUtils.isEmpty(lstVfobProvisional)){
									for (Map fobProvisional : lstVfobProvisional) {

										//RIN10-FSW AFMA
										DatoMontoProv datoMontoProv = new DatoMontoProv();
										if(RECTIFICACION.equals(tipoDiligencia)){


											datoMontoProv.setCodmoneda(fobProvisional.get("COD_MONEDA")!=null? fobProvisional.get("COD_MONEDA").toString():"");
											datoMontoProv.setFectipocambio(fobProvisional.get("FEC_TIPCAMB")!=null?Utilidades.convertirFormatoStringToDate(fobProvisional.get("FEC_TIPCAMB").toString()):null);
											//datoMontoProv.setFecvalestima(Utilidades.toDate(itemFactura.get("FEC_VALESTIMA")));
											datoMontoProv.setNumcorredoc(Long.valueOf(fobProvisional.get("NUM_CORREDOC").toString()));
											datoMontoProv.setNumsecfact(Integer.valueOf(itemFactura.get("NUM_SECFACT").toString()));
											datoMontoProv.setNumsecprove(Integer.valueOf(itemFactura.get("NUM_SECPROVE").toString()));
											datoMontoProv.setNumsecitem(Integer.valueOf(fobProvisional.get("NUM_SECITEM").toString()));
											//datoMontoProv.setValmonto(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_MONTO")));
											datoMontoProv.setValdefinitivo(Utilidades.toBigDecimal(fobProvisional.get("MTO_DEFINITIVO")));
											//datoMontoProv.setIndtipovalor(itemFactura.get("COD_TIPOVALOR")!=null?itemFactura.get("COD_TIPOVALOR").toString():"1");
											datoMontoProv.setIndtipovalor(fobProvisional.get("COD_TIPOVALOR")!=null?fobProvisional.get("COD_TIPOVALOR").toString():"1");
											datoMontoProv.setFecvalestima(Utilidades.toDate(fobProvisional.get("FEC_VALESTIMA")));
											datoMontoProv.setValmonto(Utilidades.toBigDecimal(fobProvisional.get("MTO_MONTO")));
										}else{


											datoMontoProv.setCodmoneda(fobProvisional.get("COD_MONEDA")!=null? fobProvisional.get("COD_MONEDA").toString():"");
											datoMontoProv.setFectipocambio(fobProvisional.get("FEC_TIPCAMB")!=null?
													Utilidades.convertirFormatoStringToDate(fobProvisional.get("FEC_TIPCAMB").toString()):null);
											datoMontoProv.setFecvalestima(Utilidades.toDate(itemFactura.get("FEC_VALESTIMA")));
											datoMontoProv.setNumcorredoc(Long.valueOf(fobProvisional.get("NUM_CORREDOC").toString()));
											datoMontoProv.setNumsecfact(Integer.valueOf(fobProvisional.get("NUM_SECFACT").toString()));
											datoMontoProv.setNumsecprove(Integer.valueOf(fobProvisional.get("NUM_SECPROVE").toString()));
											datoMontoProv.setNumsecitem(Integer.valueOf(fobProvisional.get("NUM_SECITEM").toString()));
											datoMontoProv.setValmonto(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_MONTO")));
											datoMontoProv.setValdefinitivo(Utilidades.validaVacioRetornaBigDecimal(fobProvisional.get("MTO_DEFINITIVO")));

											datoMontoProv.setIndtipovalor(itemFactura.get("COD_TIPOVALOR")!=null?itemFactura.get("COD_TIPOVALOR").toString():"1");

										}

										item.setMontoProv(datoMontoProv);
									}	
								}

								//FIN

								// Datos adicionales de los items
								item.setInddeducdisti((java.lang.String) itemFactura.get("IND_DEDUC"));
								item.setMtofobunita(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_FOBUNITARIO")));
								item.setMtoajusunita(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_AJUUNITARIO")));
								//item.setAnnfabrica((java.lang.String) itemFactura.get("ANN_FABRICACION"));
								item.setAnnfabrica(itemFactura.get("ANN_FABRICACION")!=null?itemFactura.get("ANN_FABRICACION").toString():"0");
								item.setCodestamer((java.lang.String) itemFactura.get("COD_ESTMERC"));
								item.setIndsoftware((java.lang.String) itemFactura.get("IND_SOFTWARE"));

								//si es que el indicador de software es null entonces se setea con una cadena vacia... asi lo requieren los servicios de validacion del orquestador
								if (item.getIndsoftware() == null) {
									//reemplazamos el null por una cadena vacia
									item.setIndsoftware("");
								}


								item.setIndvarios((java.lang.String) itemFactura.get("IND_OTROS"));//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								item.setMtofobitem(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_FOBITEM")));



								//amancilla correcciones porblems de castin 
								List<Map> lstSeriesItem = null;
								if(itemFactura.containsKey("lstSeriesItem" + sufijo)){
									//amancilla correccion es un item a�adido no tiene lstSeriesItem
									Object objectlstSeriesItem = itemFactura.get("lstSeriesItem" + sufijo);
									if(objectlstSeriesItem instanceof List){
										lstSeriesItem = (List<Map>) itemFactura.get("lstSeriesItem" + sufijo);//jenciso se cambia al map correcto
									} 
								}
								//Inicio RIN10
								//else if (mapinput.containsKey("lstSeriesItemActual")){
								if(RECTIFICACION.equals(tipoDiligencia)){
									/*Object objectlstSeriesItemActual = itemFactura.get("lstSeriesItemActual");*/
									//AFMA ASI DEBE QUEDAR
									Object objectlstSeriesItemActual = mapinput.get("lstSeriesItem" + sufijo);
									if(objectlstSeriesItemActual instanceof List){
										//lstSeriesItem = (List<Map>) mapinput.get("lstSeriesItemActual");
										lstSeriesItem = (List<Map>) mapinput.get("lstSeriesItem"+ sufijo);
										//Fin RIN10
										//pase 42 mol              	
										lstSeriesItem = filtrarSeriesItemXItem(lstSeriesItem,item.getNumsecitem(),item.getNumsecfact());
									}
								}


								if (!CollectionUtils.isEmpty(lstSeriesItem))
								{
									Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();
									item.setListSerieItems(listSerieItems);

									for (Map mapSerieItem : lstSeriesItem)
									{
										if(Constantes.IND_ELIMINADO.equals(mapSerieItem.get("IND_DEL"))){
											continue;  
										}


										DatoSerieItem serieItem = new DatoSerieItem();
										serieItem.setCant_mercd(SunatNumberUtils.toBigDecimal(mapSerieItem.get("CNT_MERC")));
										serieItem.setNumserie(SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECSERIE")));
										serieItem.setMtofobitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_FOB")));
										serieItem.setMtoajuitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_AJUSTE")));
										serieItem.setPadre(item);
										listSerieItems.add(serieItem);
									}
									//                  
									//inicio Eliminar duplicado de serieitem lstSeriesItemActual
									//rtineo mejoras, no es necesario ejecutar dentro del bucle,
									//movido al antes del bucle
									//                  if (!CollectionUtils.isEmpty(lstSeriesItemActual))
									//                  { 
									//                		List<Map<String,Object>> lstSeriesItemAux =  new ArrayList<Map<String,Object>>();
									//                  Integer cantidad = 0;
									//                  List<Map> lstSeriesItemAux1 =   new ArrayList<Map>();
									//                                                      
									//                    for (Map<String,Object> mapSerieItem : lstSeriesItemActual)
									//                    { lstSeriesItemAux1.add(mapSerieItem);
									//                          cantidad =0;
									//                      	  for (Map mapSerieItemAux : lstSeriesItemAux1)
									//                            {  if(mapSerieItemAux.containsKey("NUM_SECSERIE") && mapSerieItemAux.containsKey("NUM_SECFACT") && mapSerieItemAux.containsKey("NUM_SECITEM")){
									//       		               		  if(mapSerieItem.get("NUM_SECSERIE").equals(mapSerieItemAux.get("NUM_SECSERIE")) && mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
									//       		               			cantidad++;              			  
									//       		               		  }
									//                              }
									//                            }
									//                      	  if(cantidad==1){
									//                      		 lstSeriesItemAux.add(mapSerieItem);
									//                      	  }else { 
									//                       	if(cantidad>1){
									//                       		 List<Map<String,Object>> lstSeriesItemAux2 =  new ArrayList<Map<String,Object>>();
									//                       		 lstSeriesItemAux2 = lstSeriesItemAux;
									//                       		 for (Map<String,Object> mapSerieItemAux : lstSeriesItemAux2){
									//                       			 if(mapSerieItem.get("NUM_SECSERIE").equals(mapSerieItemAux.get("NUM_SECSERIE")) && mapSerieItem.get("NUM_SECFACT").equals(mapSerieItemAux.get("NUM_SECFACT")) && mapSerieItem.get("NUM_SECITEM").equals(mapSerieItemAux.get("NUM_SECITEM"))){
									//                       				 if(mapSerieItem.containsKey("indica") && "N".equals(mapSerieItem.get("indica"))){
									//                       					mapSerieItem.put("IND_DEL","0");                     					
									//                                     	if(!mapSerieItem.containsKey("MTO_AJUSTE")){
									//                                     		mapSerieItem.put("MTO_AJUSTE", 0);
									//                                     	}
									//                                     	lstSeriesItemAux.remove(mapSerieItemAux);
									//                                     	lstSeriesItemAux.add(mapSerieItem);	
									//                                     		break;
									//                       				 }
									//                       				
									//                       			 }
									//                       		 }
									//                       			 
									//                       		
									//                      	   }
									//                      	  }
									//                  	  
									//                    }
									//                    lstSeriesItemActual.clear();
									//                    lstSeriesItemActual.addAll(lstSeriesItemAux);
									//                    
									//                   }
									//rtineo mejoras, fin
									//jenciso Inicio agregar seriesItems que fueron generados al a�adir una serie 
									if(!CollectionUtils.isEmpty(lstSeriesItemActual)){
										for(Map<String,Object> mapSerieItem : lstSeriesItemActual){

											if(Constantes.IND_ELIMINADO.equals(mapSerieItem.get("IND_DEL"))){
												continue;  
											}


											//verificamos que no este cargado en listSerieItems para el item correspondiente
											Integer numSecProv = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECPROVE"));
											Integer numSecfact = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECFACT"));
											Integer numSecItem = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECITEM"));

											if(item.getNumsecprove().equals(numSecProv) && item.getNumsecfact().equals(numSecfact) && item.getNumsecitem().equals(numSecItem)){
												if(!existeSerieItemInList(listSerieItems, mapSerieItem)){

													DatoSerieItem serieItem = new DatoSerieItem();
													serieItem.setCant_mercd(SunatNumberUtils.toBigDecimal(mapSerieItem.get("CNT_MERC")));
													serieItem.setNumserie(SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECSERIE")));
													serieItem.setMtofobitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_FOB")));
													serieItem.setMtoajuitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_AJUSTE")));
													serieItem.setPadre(item);
													listSerieItems.add(serieItem);
												}
											}
										}
									}
									//jenciso Fin
								}
							}
						}
					}
				}

				Map mapCondicionTransa = (Map) formBProveedor.get("mapCondicionTransa" + sufijo);
				if (!CollectionUtils.isEmpty(mapCondicionTransa))
				{
					Elementos<DatoCondTransaccion> listCondTransacciones = new Elementos<DatoCondTransaccion>();
					dav.setListCondTransacciones(listCondTransacciones);

					Set keySetCondicionTransa = mapCondicionTransa.keySet();
					for (Object key : keySetCondicionTransa)
					{
						DatoCondTransaccion condTransaccion = new DatoCondTransaccion();
						condTransaccion.setCodindcondtra((java.lang.String) key); // COD_INDTRANSACCION
						condTransaccion.setIndcondtra((java.lang.String) mapCondicionTransa.get(key)); // IND_TRANSACCION
						listCondTransacciones.add(condTransaccion);
					}
				}
			}
		}

		return declaracion;
	}
	// Ini RIN 10
	private List<Map<String, Object>> filtrarVfobProvisionalXitem(List<Map<String, Object>> lstVfobProvisional, Integer num_secitem)
	{
		List rspta = new ArrayList();
		String sectItem;
		for (Map item : lstVfobProvisional) {
			sectItem = item.get("NUM_SECITEM").toString().trim();
			if (sectItem.equals(num_secitem.toString())) {
				rspta.add(item);
			}
		}

		return rspta;
	}

	//inicio P21-P22
	public Declaracion transformDiligenciaConclusionDespacho(Map<?, ?> mapinput)
	{
		return transformBySufijoDiligenciaDespacho(mapinput,"", CONCLUSION);
	}
	//fin P21-P22



	// Fin RIN 10
	/**
	 * RIN13
	 * Transforma el hasmap de declaracion hacia un objeto declaracion
	 * interponiedo un sufijo = "" a los nombres de los Hasmap dependientes.
	 *
	 * @param mapinput the mapinput
	 * @return the declaracion
	 */
	public Declaracion transformDiligenciaDespacho(Map<?, ?> mapinput)
	{
		return transformBySufijoDiligenciaDespacho(mapinput, "",""); //P21-P22
	}

	/**
	 * Transforma el hashmap de declaracion hacia un objeto declaracion
	 * interponiedo un sufijo a los nombres de los Hasmap dependientes.
	 *
	 * @param mapinput the mapinput
	 * @param sufijo the sufijo
	 * @return the declaracion
	 */
	public Declaracion transformBySufijoDiligenciaDespacho(Map<?, ?> mapinput, String sufijo, String tipodiligencia) //P21-P22
	{


		Map mapCabDeclara = (Map) mapinput.get("mapCabDeclara" + sufijo);
		List<Map> lstDetDeclara = (List<Map>) mapinput.get("lstDetDeclara" + sufijo);
		List<Map> lstFacturasSerie = (List<Map>) mapinput.get("lstFacturasSerie" + sufijo);
		//amancilla P32 RIN7 - RIN13
		List<Map<String,Object>> lstSeriesItemActual = new ArrayList<Map<String,Object>>(); 
		if(!SunatStringUtils.isEmptyTrim(sufijo)){
			lstSeriesItemActual = (List<Map<String,Object>>) mapinput.get("lstSeriesItem" + sufijo); 
		}else{
			lstSeriesItemActual = (List<Map<String,Object>>) mapinput.get("lstSeriesItemActual");//jenciso	//se utiliza en RIN13
		}


		//RIN13 - no esta aplicando
		/*//inicio diligencia rectificacion gmontoya
    if(CollectionUtils.isEmpty(lstFacturasSerie)){
    	lstFacturasSerie = (List<Map>) mapinput.get("lstFacturaSerie" + sufijo);    	
    	List<Map> lstComproBPagoActual = (List<Map>) mapinput.get("lstComproBPagoActual");
    	if(!CollectionUtils.isEmpty(lstFacturasSerie) && !CollectionUtils.isEmpty(lstComproBPagoActual)){
	    	for(Map mapaFacSerie : lstFacturasSerie){
	    		for(Map mapaComproPago : lstComproBPagoActual){
	    			if(mapaFacSerie.get("NUM_SECFACT").toString().equals(mapaComproPago.get("NUM_SECFACT").toString())){
	    				mapaFacSerie.put("FEC_FACT", mapaComproPago.get("FEC_FACT"));

						break;

	    			}
	    		}
	    	}
    	}

    }
    //fin diligencia rectificacion gmontoya*/

		List<Map> lstFormBProveedor = (List<Map>) mapCabDeclara.get("lstFormBProveedor" + sufijo);

		if ("Actual".equals(sufijo))
		{
			lstFormBProveedor = (List<Map>) mapinput.get("lstFormBProveedor" + sufijo);
		}

		//*INICIO RIN13 PQ2*/
		//List<Map<String, Object>> lstDocautAsociado = (List<Map<String, Object>>) mapinput.get("lstDocAutAsociado" + sufijo);
		//List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapinput.get("lstDetAutorizacion" + sufijo);

		List<Map<String, Object>> lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado" + sufijo);
		List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion" + sufijo);
		//*FIN RIN13 PQ2*/
		List<Map<String, Object>>  lstCabCertiOrigen = null;
		if (mapCabDeclara.containsKey("lstCabCertiOrigen"))
			lstCabCertiOrigen = (List<Map<String, Object>>) mapCabDeclara.get("lstCabCertiOrigen" + sufijo);


		List<Map<String, Object>> lstIndicadorDua    = (List<Map<String, Object>>)mapinput.get("lstIndicadorDua" + sufijo); //no se esta enviando RIN13?

		Declaracion declaracion = new Declaracion();
		log.debug("-->mapCabDeclara: " + mapCabDeclara);

		declaracion.setCodaduana((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
		declaracion.setCodtipotrans((String)mapinput.get("codTransaccion"));
		{
			declaracion.setNumdeclRef(new NumdeclRef());
			declaracion.getNumdeclRef().setCodregimen((java.lang.String) mapCabDeclara.get("COD_REGIMEN"));
			declaracion.setNumeroCorrelativo(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC")));
			declaracion.getNumdeclRef().setNumcorre((java.lang.String) mapCabDeclara.get("NUM_DECLARACION").toString());
			declaracion.getNumdeclRef().setCodaduana((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
			declaracion.getNumdeclRef().setAnnprese((java.lang.String) mapCabDeclara.get("ANN_PRESEN").toString());
			declaracion.setNumeroDeclaracion(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_DECLARACION").toString()));
		}

		declaracion.setDua(new DUA());
		declaracion.getDua().setNumcorredoc(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC").toString()));
		declaracion.getDua().setCodtipoperacion((java.lang.String) mapCabDeclara.get("COD_TIPDESP"));
		//P46-PAS20155E410000032
		declaracion.getDua().setAnnpresen(SunatNumberUtils.toInteger(mapCabDeclara.get("ANN_PRESEN")));
		declaracion.getDua().setCodmodalidad((java.lang.String) mapCabDeclara.get("COD_MODALIDAD"));
		declaracion.getDua().setNumplazosol(SunatNumberUtils.toInteger(mapCabDeclara.get("NUM_PLAZOSOL")));
		declaracion.getDua().setCodtipoplazo((java.lang.String) mapCabDeclara.get("COD_TIPOPLAZO"));
		declaracion.getDua().setMtotfobclvta(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTFOBDOL")));
		declaracion.getDua().setMtotflecomex(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTFLETEDOL")));
		declaracion.getDua().setMtotsegotros(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTSEGDOL")));
		declaracion.getDua().setMtotajustes(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTAJUSTESDOL")));
		declaracion.getDua().setMtovaladuana(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTVALORADU")));
		declaracion.getDua().setCodtipotratamiento((java.lang.String) mapCabDeclara.get("COD_TIPTRATMERC"));
		declaracion.getDua().setCodpropiedad((java.lang.String) mapCabDeclara.get("COD_PROPIEDAD"));
		declaracion.getDua().setCnttpesoneto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_PESONETO_TOTAL")));
		declaracion.getDua().setCnttpesobruto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_PESOBRUTO_TOTAL")));
		declaracion.getDua().setCnttcantbulto(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TOTBULTOS")));
		declaracion.getDua().setCnttqunifis(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TQUNIFIS")));
		declaracion.getDua().setCnttqunicom(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("CNT_TQUNICOM")));
		declaracion.getDua().setCntnumseries(SunatNumberUtils.toInteger(mapCabDeclara.get("CNT_TOTSERIES")));
		declaracion.getDua().setMtototautoliq(SunatNumberUtils.toBigDecimal(mapCabDeclara.get("MTO_TOTAUTOLIQ")));
		declaracion.getDua().setCodferia((java.lang.String) mapCabDeclara.get("")); // CAB_ADI_ADMTEM
		declaracion.getDua().setCodtipempaque((java.lang.String) mapCabDeclara.get("COD_TIPEMPAQUE"));
		declaracion.getDua().setCodprodurgente((java.lang.String) mapCabDeclara.get("COD_PRODURGENTE"));

		if (mapCabDeclara
				.get("FEC_FINPROVSIONAL")
				.getClass()
				.getName()
				.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion.getDua().setFecfinprovsional(
					new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_FINPROVSIONAL")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_FINPROVSIONAL") instanceof java.util.Date)
		{
			//declaracion.getDua().setFecfinprovsional((java.util.Date) mapCabDeclara.get("FEC_FINPROVSIONAL"));
			/** inicio mpoblete BUG RIN10**/
			//declaracion.getDua().setFecfinprovsional(SunatDateUtils.getDate(mapCabDeclara.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd HH:mm:ss"));
			String fechaString = SunatDateUtils.getFormatDate((java.util.Date) mapCabDeclara.get("FEC_FINPROVSIONAL"),"yyyy-MM-dd HH:mm:ss");
			declaracion.getDua().setFecfinprovsional(SunatDateUtils.getDate(fechaString, "yyyy-MM-dd HH:mm:ss"));
			/** fin mpoblete BUG RIN10**/
		}
		else
		{
			declaracion.getDua().setFecfinprovsional(
					SunatDateUtils.getDate(mapCabDeclara.get("FEC_FINPROVSIONAL").toString(), "yyyy-MM-dd HH:mm:ss"));
		}

		//RIN-13-619
		declaracion.getDua().setCodlugarecepcion(ObjectUtils.toString(this.getObjectFromMapEspacio(mapCabDeclara,("COD_LUGARRECEP"))));
		declaracion.getDua().setCodtiplugarrecep(ObjectUtils.toString(this.getObjectFromMapEspacio(mapCabDeclara,("COD_TIPLUGARRECEP"))));

		declaracion.getDua().setNumruclugarecep((java.lang.String) mapCabDeclara.get("COD_RUCLUGRECEP"));
		declaracion.getDua().setCodanexo((java.lang.String) mapCabDeclara.get("COD_LOCALANEXO"));
		declaracion.getDua().setNumrucdeposito((java.lang.String) mapCabDeclara.get("NUM_DOCIDENT_PDD"));//PAS20165E220200015
		//declaracion.getDua().setNumrucdeposito((java.lang.String) mapCabDeclara.get("COD_RUCLUGRECEP"));
		declaracion.getDua().setCodlocalanexo((java.lang.String) mapCabDeclara.get("COD_LOCALANEXO"));
		declaracion.getDua().setDesfinalidad((java.lang.String) mapCabDeclara.get("DES_FINALIDAD"));
		declaracion.getDua().setIndSocorro((java.lang.String) mapCabDeclara.get("IND_SOCORRO"));
		declaracion.getDua().setCodregimen((java.lang.String) mapCabDeclara.get("COD_REGIMEN"));
		declaracion.getDua().setCodaduanaorden((java.lang.String) mapCabDeclara.get("COD_ADUANA"));
		declaracion.getDua().setNumdocumento((java.lang.String) (mapCabDeclara.get("NUM_DOCIDENT_PDE")));
		declaracion.getDua().setCodtipooper((java.lang.String) (mapCabDeclara.get("COD_TIPDOC_PDE")));
		declaracion.getDua().setPadre(declaracion); /*RIN 13*/



		if (mapCabDeclara
				.get("FEC_VENREGIMEN")
				.getClass()
				.getName()
				.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion.getDua().setFecfinacoregimen(
					new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_VENREGIMEN")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_VENREGIMEN") instanceof java.util.Date)
		{
			//declaracion.getDua().setFecfinacoregimen((java.util.Date) mapCabDeclara.get("FEC_VENREGIMEN"));
			declaracion.getDua().setFecfinacoregimen(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_VENREGIMEN").toString()));
		}
		else
		{
			declaracion.getDua().setFecfinacoregimen(
					SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_VENREGIMEN").toString()));
		}
		// Crea declarante
		declaracion.getDua().setDeclarante(new Participante());
		declaracion.getDua().getDeclarante().setNumeroDocumentoIdentidad(
				(java.lang.String) mapCabDeclara.get("NUM_DOCIDENT_PIM"));
		declaracion.getDua().getDeclarante().getTipoParticipante().setCodDatacat(
				(java.lang.String) mapCabDeclara.get("COD_TIPPARTIC_PIM"));
		declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().setCodDatacat(
				(java.lang.String) mapCabDeclara.get("COD_TIPDOC_PIM"));

		// Crea OtraAduana
		declaracion.getDua().setOtraAduana(new DatoOtraAduana());
		declaracion.getDua().getOtraAduana().setCodopadusal((java.lang.String) mapCabDeclara.get("COD_ADUDEST"));
		declaracion.getDua().getOtraAduana().setCodviatrades((java.lang.String) mapCabDeclara.get("COD_VIATRANS"));

		if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstDocAutAsociado))
		{
			declaracion.getDua().setListDocAutorizantes(transformListDocAutorizantesfromMap(lstDocAutAsociado));
		}

		if (mapCabDeclara.containsKey("NUM_CORREDOC"))
		{
			declaracion.setNumeroCorrelativo(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
			declaracion.getDua().setNumcorredoc(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
		}
		if (mapCabDeclara.containsKey("FEC_CONCLUSION"))
		{
			if (mapCabDeclara
					.get("FEC_CONCLUSION")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecconclusion(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_CONCLUSION")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_CONCLUSION") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecconclusion((java.util.Date) mapCabDeclara.get("FEC_CONCLUSION"));
				declaracion.getDua().setFecconclusion(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CONCLUSION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecconclusion(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_CONCLUSION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}

		//ECANA Se debe de agregar la fecha de conclusi�n calculada en la numeraci�n para utilizarla en los registros de la rectificaci�n
		if (mapCabDeclara.containsKey("FEC_VENCONCLU"))
		{
			if (mapCabDeclara
					.get("FEC_VENCONCLU")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecvenconclu(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_VENCONCLU")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_VENCONCLU") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecconclusion((java.util.Date) mapCabDeclara.get("FEC_CONCLUSION"));
				declaracion.getDua().setFecvenconclu(SunatDateUtils.getDate(mapCabDeclara.get("FEC_VENCONCLU").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecvenconclu(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_VENCONCLU").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}
		//

		if (mapCabDeclara.containsKey("FEC_DECLARACION"))
		{
			if (mapCabDeclara
					.get("FEC_DECLARACION")
					.getClass()
					.getName()
					.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecdeclaracion(
						new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_DECLARACION")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_DECLARACION") instanceof java.util.Date)
			{
				//declaracion.getDua().setFecdeclaracion((java.util.Date) mapCabDeclara.get("FEC_DECLARACION"));
				declaracion.getDua().setFecdeclaracion(SunatDateUtils.getDate(mapCabDeclara.get("FEC_DECLARACION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecdeclaracion(
						SunatDateUtils.getDate(mapCabDeclara.get("FEC_DECLARACION").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}

		//PAS20145E220000090 - MATC 20140626  INICIO
		if (mapCabDeclara.containsKey("FEC_LLEGADA"))
		{
			if (mapCabDeclara.get("FEC_LLEGADA").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				declaracion.getDua().setFecLlegada(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_LLEGADA")).getTimestamp().getTime()));
			}
			else if (mapCabDeclara.get("FEC_LLEGADA") instanceof java.util.Date)
			{
				declaracion.getDua().setFecLlegada(SunatDateUtils.getDate(mapCabDeclara.get("FEC_LLEGADA").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
			else
			{
				declaracion.getDua().setFecLlegada(SunatDateUtils.getDate(mapCabDeclara.get("FEC_LLEGADA").toString(), "yyyy-MM-dd HH:mm:ss"));
			}
		}
		//PAS20145E220000090 - MATC 20140626  FINAL

		/**
		 * Cargamos los documentos de transporte a partir de las series
		 */
		if (!CollectionUtils.isEmpty(lstDetDeclara))
		{
			Elementos<DatoDocTransporte> listDocTransporte = new Elementos<DatoDocTransporte>();
			declaracion.getDua().setListDocTransporte(listDocTransporte);
			int i = 1;
			for (Map<?, ?> detDeclara : lstDetDeclara)
			{
				if(Constantes.IND_ELIMINADO.equals(detDeclara.get("IND_DEL"))){//adicionado por PAS20145E220000682
					continue;
				}

				// Si ya esta registrado no lo tomamos - PAS20144E610000111 se agrega numero de detalle 
				boolean existeDoctra = false;
				DatoDocTransporte docTransporte = new DatoDocTransporte();

				/*INICIO P21-P22*/
				Map<String, Object> paramsPuertoFechaOrigen = getPuertoFechaOrigen(lstDetAutorizacion ,  lstCabCertiOrigen, detDeclara.get("NUM_SECSERIE").toString());        
				/*FIN P21-P22*/

				for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte())
				{    
					if (docTrans.getNumdoctransporte().equals(detDeclara.get("NUM_DOCTRANSP")) && docTrans.getNumdetalle().compareTo(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE")!=null?detDeclara.get("NUM_DETALLE").toString():"0"))==0)//AJUSTE POR NULLPOINTER 
					{ /*INICIO P21-P22*/
						if (docTrans.getCodpuertoorg()==null || docTrans.getFecembarqueorg()==null)
						{
							setPuertoFechaOrigen(paramsPuertoFechaOrigen , docTrans);  
						}
						/*FIN P21-P22*/        	
						existeDoctra = true;
						break;
					}
				}
				if (existeDoctra)
					continue;



				docTransporte.setCodpuerto((java.lang.String) detDeclara.get("COD_PUER_EMBAR"));
				//INICIO - PAS20155E220000054 RIN-13
				//if (detDeclara.get("FEC_EMBORIGEN").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))

				if (detDeclara.get("FEC_EMBARQUE").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					//docTransporte.setFecembarque(new java.util.Date(((FechaBean) detDeclara.get("FEC_EMBORIGEN")).getTimestamp().getTime()));
					docTransporte.setFecembarque(new java.util.Date(((FechaBean) detDeclara.get("FEC_EMBARQUE")).getTimestamp().getTime()));
				}
				//else if (detDeclara.get("FEC_EMBORIGEN") instanceof java.util.Date)
				else if (detDeclara.get("FEC_EMBARQUE") instanceof java.util.Date)
				{
					//docTransporte.setFecembarque((java.util.Date) detDeclara.get("FEC_EMBORIGEN"));
					//docTransporte.setFecembarque(SunatDateUtils.getDate(detDeclara.get("FEC_EMBORIGEN").toString(), "yyyy-MM-dd HH:mm:ss"));
					docTransporte.setFecembarque(SunatDateUtils.getDate(detDeclara.get("FEC_EMBARQUE").toString(), "yyyy-MM-dd HH:mm:ss"));
				}
				else
				{
					//docTransporte.setFecembarque(SunatDateUtils.getDate(detDeclara.get("FEC_EMBORIGEN").toString(),"yyyy-MM-dd HH:mm:ss"));
					docTransporte.setFecembarque(SunatDateUtils.getDate(detDeclara.get("FEC_EMBARQUE").toString(),"yyyy-MM-dd HH:mm:ss"));
				}
				//FIN - PAS20155E220000054 RIN-13
				docTransporte.setCodtipodoctrans((java.lang.String) detDeclara.get("COD_TIPDOCTRANSP"));
				docTransporte.setNumdocmaster((java.lang.String) detDeclara.get("NUM_DOCTRANSPMASTER"));

				/*INICIO P21-P22*/
				setPuertoFechaOrigen(paramsPuertoFechaOrigen , docTransporte);
				/*FIN P21-P22*/

				docTransporte.setNumdoctransporte((java.lang.String) detDeclara.get("NUM_DOCTRANSP"));
				docTransporte.setNumdetalle(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE").toString()));
				docTransporte.setNumsecdoctrans(i++);

				listDocTransporte.add(docTransporte);

			}
		}

		//ini P46-PAS20155E410000032
		if(mapCabDeclara.get("registrarCodLibeDonacion") != null
				&& (Boolean)mapCabDeclara.get("registrarCodLibeDonacion")) {
			declaracion.setRegistrarCodLibeDonacion((Boolean)mapCabDeclara.get("registrarCodLibeDonacion"));
		}
		//fin P46-PAS20155E410000032

		/*Se inicilaiza listado de objetos necesarios*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();
		declaracion.getDua().setListOtrosDocSoporte(listOtrosDocSoporte);

		if (!CollectionUtils.isEmpty(lstDetDeclara))
		{
			Elementos<DatoSerie> listSeries = new Elementos<DatoSerie>();
			declaracion.getDua().setListSeries(listSeries);

			List<Map> lstDocuPreceDua;
			for (Map detDeclara : lstDetDeclara)
			{

				if(Constantes.IND_ELIMINADO.equals(detDeclara.get("IND_DEL"))){//adicionado por PAS20145E220000682
					continue;
				}

				DatoSerie serie = new DatoSerie();
				serie.setNumserie(SunatNumberUtils.toInteger(detDeclara.get("NUM_SECSERIE").toString()));
				serie.setCodunicomer((java.lang.String) detDeclara.get("COD_UNICOMER"));
				serie.setCntunicomer(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_COMER")));
				serie.setCntbultos(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_BULTO")));
				serie.setCodclasbul((java.lang.String) detDeclara.get("COD_CLASEBULTOS"));
				serie.setCntpesoneto(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESO_NETO")));
				serie.setCntpesobruto(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESO_BRUTO")));
				serie.setCntunifis(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIFIS")));
				serie.setCodunifis(SunatStringUtils.toStringObj(detDeclara.get("COD_UNIFISICA")));
				serie.setNumpartnandi(SunatNumberUtils.toLong(detDeclara.get("NUM_PARTNANDI")));
				serie.setCodtnan((java.lang.String) detDeclara.get("COD_TIPTASAAPLICAR"));
				/*INICIO RIN13 PQ2 */
				if ( detDeclara.get("NUM_PARNALADISA")!=null){
					if(detDeclara.get("NUM_PARNALADISA").equals(" ")){
						serie.setNumpartnaladAsInteger(detDeclara.get("NUM_PARNALADISA").toString());
					}
					else{
						serie.setNumpartnalad((java.lang.String) detDeclara.get("NUM_PARNALADISA"));
					}	
				}
				/*FIN RIN13 PQ2 */
				serie.setCodtipomarge((java.lang.String) detDeclara.get("COD_TIPMARGEN"));
				serie.setCodpaisorige((java.lang.String) detDeclara.get("COD_PAISORIGEN"));
				serie.setCodpaisadqui((java.lang.String) detDeclara.get("COD_PAISADQUI"));
				serie.setMtofobmon(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBMONTRANS")));
				serie.setCodmoneda((java.lang.String) detDeclara.get("COD_MONETRANS"));
				serie.setMtofledol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FLETEDOL")));
				serie.setMtosegdol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_SEGDOL")));
				serie.setMtoajuste(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_AJUSTE")));
				serie.setMtovaladuana(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_VALORADU")));
				serie.setDescomercial((java.lang.String) detDeclara.get("DES_COMER"));
				serie.setDesformapres((java.lang.String) detDeclara.get("DES_FORMAPRESEN"));
				serie.setDesmatecomp((java.lang.String) detDeclara.get("DES_MATECOMP"));
				serie.setDesusoaplica((java.lang.String) detDeclara.get("DES_USOAPLIC"));
				serie.setDesotros((java.lang.String) detDeclara.get("DES_OTROSCARAC"));
				serie.setNumpartcorre((java.lang.String) detDeclara.get("NUM_PARCORRELACION"));
				serie.setValpreciovta(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_PVPMONNAC")));        
				//inicio P21-P22
				if (detDeclara.get("IND_PARTESVEHIC")!=null){
					serie.setIndParteVehiculo((java.lang.String) detDeclara.get("IND_PARTESVEHIC").toString().trim());
				}
				//fin P21-P22

				//P34 AFMA INICIO
				serie.setNumdetalle(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE").toString()));
				serie.setNumdoctransporte((java.lang.String) detDeclara.get("NUM_DOCTRANSP"));
				//P34 AFMA FIN
				/*INICIO BUG 20851 */
				if ( detDeclara.get("POR_ALCOHOL")!=null){
					if(!detDeclara.get("POR_ALCOHOL").equals("")){
						serie.setPoralcohol(SunatNumberUtils.toBigDecimal(detDeclara.get("POR_ALCOHOL")));
					}
				}
				/*FIN BUG 20851 */

				//ini P46-PAS20155E410000032
				if(!SunatStringUtils.isEmptyTrim((String)detDeclara.get("COD_TIPREGUL"))) {
					serie.setCodTipRegul(SunatStringUtils.trim((String)detDeclara.get("COD_TIPREGUL")));
				}
				//fin P46-PAS20155E410000032

				/*INICIO RIN13 PQ2 */
				if (detDeclara.get("NUM_PARNABANDINA")!=null){
					if(detDeclara.get("NUM_PARNABANDINA").equals(" ")){
						serie.setNumpartnabanAsLong(detDeclara.get("NUM_PARNABANDINA").toString());
					}
					else{
						serie.setNumpartnaban((java.lang.String) detDeclara.get("NUM_PARNABANDINA"));
					}	
				}
				/*FIN RIN13 PQ2 */
				serie.setCodtipoflete((java.lang.String) detDeclara.get("COD_TIPFLETE"));
				serie.setValestimado(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_ESTIMADO")));
				serie.setPadre(declaracion.getDua()); /*RIN 13*/
				if (detDeclara.get("FEC_EXPIRACION")!= null) {
					if (detDeclara.get("FEC_EXPIRACION").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")) {
						serie.setFecexpiracion(new java.util.Date(((FechaBean) detDeclara.get("FEC_EXPIRACION")).getTimestamp().getTime()));
					}
					else if (detDeclara.get("FEC_EXPIRACION") instanceof java.util.Date) {
						serie.setFecexpiracion(SunatDateUtils.getDate(detDeclara.get("FEC_EXPIRACION").toString(), "yyyy-MM-dd HH:mm:ss"));
					} else {
						serie.setFecexpiracion(SunatDateUtils.getDate(detDeclara.get("FEC_EXPIRACION").toString(),"yyyy-MM-dd HH:mm:ss"));
					}
				}


				serie.setMercancia(new DatoMercancia());
				serie.getMercancia().setCodproducto((java.lang.String) detDeclara.get("COD_PRODRESTR"));
				serie.getMercancia().setCodtipoexoneracion((java.lang.String) detDeclara.get("COD_TIPEXONRESTRI"));
				serie.getMercancia().setCodexoneracion((java.lang.String) detDeclara.get("COD_EXMERCREST"));
				serie.getMercancia().setCodriesgosanitario((java.lang.String) detDeclara.get("COD_RSSENASA"));


				serie.setProducto(new DatoProducto());
				serie.getProducto().setCodexpantidum((java.lang.String) detDeclara.get("COD_EXPOAPLICANTID"));
				serie.getProducto().setCodpantidum((java.lang.String) detDeclara.get("COD_PRODANTID"));
				serie.getProducto().setMtofobfactu(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBFACT")));
				//serie.getProducto().setPormerma(SunatNumberUtils.toBigDecimal(detDeclara.get("POR_MERMA"))); //RIN13 ya no seria necesario ya que en el serie.setDatoProductoTmp = se setea 
				serie.setCodaplultra((java.lang.String) detDeclara.get("COD_ULTRACTIVIDAD"));

				//RIN13
				//datoProductoTmp
				DatoProducto datoProductoTmp = new DatoProducto();
				datoProductoTmp.setPormerma(SunatNumberUtils.toBigDecimal(detDeclara.get("POR_MERMA")));
				datoProductoTmp.setNumitem((java.lang.String)detDeclara.get("COD_INSUMO"));
				datoProductoTmp.setCntunimedidaequi(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIEQUI")));
				datoProductoTmp.setCodtipoequi((java.lang.String)detDeclara.get("COD_UMEQUI")); 
				serie.setDatoProductoTmp(datoProductoTmp);

				/**  amancilla no corre este codigo Bug 22695 Ley IM pase Gilmar
        List lstConvenio = (List) detDeclara.get("lstConvenioSerie");
        if (!CollectionUtils.isEmpty(lstConvenio))
        {

          Map mapCC = new HashMap();
          mapCC = (Map) lstConvenio.get(0);          
          String tipoConvenio = mapCC.get("COD_TIPCONVENIO").toString();
          //if(mapCC.get("COD_CONVENIO")!=null && !Constantes.IND_ELIMINADO.equals(mapCC.get("IND_DEL")) ){ 
          if(mapCC.get("COD_CONVENIO")!=null){
              String codConvenio = mapCC.get("COD_CONVENIO").toString().trim();
              Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;//GMONTOYA P29
              if (SunatStringUtils.isEqualTo(tipoConvenio, "I") &&  ind_del.equals(0))
              {
                serie.setCodconvinter(Integer.valueOf(codConvenio));
              }
              if (SunatStringUtils.isEqualTo(tipoConvenio, "T") &&  ind_del.equals(0))
              {
                serie.setCodtratprefe(Integer.valueOf(codConvenio));
              }
              if (SunatStringUtils.isEqualTo(tipoConvenio, "C") &&  ind_del.equals(0))
              {
                serie.setCodliberatorio(Integer.valueOf(codConvenio));
              }
           }
         } */


				List<Map> lstConvenio = (List) detDeclara.get("lstConvenioSerie");
				if (!CollectionUtils.isEmpty(lstConvenio))
				{
					for (Map mapCC : lstConvenio) {

						Integer ind_del = mapCC.get("IND_DEL")!=null?Integer.valueOf(mapCC.get("IND_DEL").toString()):0;
						if (ind_del.equals(0)) {
							String tipoConvenio = mapCC.get("COD_TIPCONVENIO").toString();
							if(mapCC.get("COD_CONVENIO")!=null){
								String codConvenio = mapCC.get("COD_CONVENIO").toString().trim();

								if (SunatStringUtils.isEqualTo(tipoConvenio, "I"))
								{
									serie.setCodconvinter(Integer.valueOf(codConvenio));
								}
								if (SunatStringUtils.isEqualTo(tipoConvenio, "T"))
								{
									serie.setCodtratprefe(Integer.valueOf(codConvenio));
								}
								if (SunatStringUtils.isEqualTo(tipoConvenio, "C"))
								{
									serie.setCodliberatorio(Integer.valueOf(codConvenio));
								}
							}
						}
					}
				}

				serie.setMtofobdol(SunatNumberUtils.toBigDecimal(detDeclara.get("MTO_FOBDOL")));
				serie.setCodtiposeg((java.lang.String) detDeclara.get("COD_TIPSEG"));
				serie.setCodestamerca((java.lang.String) detDeclara.get("COD_ESTMERC"));
				serie.setCodvalajuste((java.lang.String) detDeclara.get("COD_VALORAJUSTE"));
				serie.setCntunicomisc(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_UNIISC")));
				serie.setCodunicomisc((java.lang.String) detDeclara.get("COD_UNI_ISC"));
				serie.setCntpesovehic(SunatNumberUtils.toBigDecimal(detDeclara.get("CNT_PESOVEHIC")));
				serie.setValindcodlib((java.lang.String)detDeclara.get("IND_ACOGCODLIBER")); //PAS20155E220000054


				lstDocuPreceDua = (ArrayList<Map>) detDeclara.get("lstDocuPreceDua" + sufijo);
				if (CollectionUtils.isEmpty(lstDocuPreceDua)) {
					lstDocuPreceDua = (ArrayList<Map>)  mapinput.get("lstDocuPreceDua" + sufijo);
				}

				if (!CollectionUtils.isEmpty(lstDocuPreceDua))
				{
					Elementos<DatoRegPrecedencia> listRegPrecedencia = new Elementos<DatoRegPrecedencia>();
					for (Map docuPreceDua : lstDocuPreceDua)
					{
						//No considerar los anulados
						String indDel = docuPreceDua.get("IND_DEL") == null?"0":docuPreceDua.get("IND_DEL").toString();
						if (!indDel.equals("1") && docuPreceDua.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
							DatoRegPrecedencia regPrecedencia = new DatoRegPrecedencia();
							regPrecedencia.setCodregipre((java.lang.String) docuPreceDua.get("COD_REGIMENPRE"));
							regPrecedencia.setCodaduapre((java.lang.String) docuPreceDua.get("COD_ADUANAPRE"));
							regPrecedencia.setAnndeclpre(SunatStringUtils.toStringObj(docuPreceDua.get("ANN_PRESENPRE")));
							regPrecedencia.setNumdeclpre(SunatStringUtils.toStringObj(docuPreceDua.get("NUM_DECLARACIONPRE")));
							regPrecedencia.setFecvencpre(SunatDateUtils.getDateFromUnknownFormat(docuPreceDua.get("FEC_VENCREGPRE").toString()));
							regPrecedencia.setNumserpre(SunatNumberUtils.toInteger(docuPreceDua.get("NUM_SECSERIEPRE").toString()));
							regPrecedencia.setCodAlmZofra(docuPreceDua.get("COD_ALMAZOFRA")!=null?(java.lang.String)docuPreceDua.get("COD_ALMAZOFRA"):""); //csantillan PAS20181U220200054 bug P_SNAA0004-16868
							listRegPrecedencia.add(regPrecedencia);
						}
					}
					serie.setListRegPrecedencia(listRegPrecedencia);
				}
				//jenciso Inicio - agregando vehiculos ceticos a la serie
				//DatoVehiculo  datoVehiculo = null;
				Map<String,Object> datoVehiculoMap = null;
				List<Map<String,Object>>  lstDatoVehiculo = (ArrayList)detDeclara.get("lstDatoVehiculo");

				if(lstDatoVehiculo!=null && !lstDatoVehiculo.isEmpty())
					datoVehiculoMap = (Map<String,Object>)lstDatoVehiculo.get(0);

				List<Map<String,Object>>  lstDatoMontoGasto = (ArrayList)detDeclara.get("lstDatoMontoGasto");
				if(datoVehiculoMap!=null && !datoVehiculoMap.isEmpty() ){//verificar montogasto
					Elementos<DatoVehiculo> listVehiculos = new Elementos<DatoVehiculo>();
					Elementos<DatoMontoGasto>  listMontoGastos =  new Elementos<DatoMontoGasto>();
					DatoVehiculo datoVehi = new DatoVehiculo();
					datoVehi = Utilidades.obtenerDatoVehiculoFromMap(datoVehiculoMap);

					if(lstDatoMontoGasto!=null && !lstDatoMontoGasto.isEmpty()){
						List<DatoMontoGasto> listDatoMontoGasto= null;
						listDatoMontoGasto= Utilidades.obtenerListDatoMontoGastoFromListMap(lstDatoMontoGasto);
						if(!CollectionUtils.isEmpty(listDatoMontoGasto)){
							listMontoGastos.addAll(listDatoMontoGasto);
						}
					}


					datoVehi.setNumcorredoc(declaracion.getDua().getNumcorredoc());
					datoVehi.setNumserie(serie.getNumserie());

					datoVehi.setListMontoGastos(listMontoGastos);
					listVehiculos.add(datoVehi);
					serie.setListVehiculos(listVehiculos);
				}

				//jenciso Fin

				if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstDetAutorizacion))
				{
					Elementos<DatoSerieDocSoporte> listSerieDocSoporte = transformListSerieDocSoporteFromMap(lstDetAutorizacion, SunatNumberUtils.toInteger(detDeclara.get("NUM_SECSERIE").toString()));
					if (listSerieDocSoporte.size() > 0)
					{
						serie.setListSerieDocSoporte(listSerieDocSoporte);
					}

				}


				// Asociamos el documento de transporte a la serie pero como documento
				// de Soporte - PAS20144E610000111 se agrega numero de detalle 
				if (!CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte()))
				{
					for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte())
					{
						if (docTrans.getNumdoctransporte().equals(detDeclara.get("NUM_DOCTRANSP")) && docTrans.getNumdetalle().compareTo(SunatNumberUtils.toInteger(detDeclara.get("NUM_DETALLE")!=null?detDeclara.get("NUM_DETALLE").toString():"0"))==0)//AJUSTE POR NULL POINTER
						{
							DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
							serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(detDeclara.get("NUM_SECSERIE"))));
							serieDocSopTrans.setNumiddocsoporte(docTrans.getNumsecdoctrans());
							serieDocSopTrans.setCodtipodocsoporte("3");
							if (serie.getListSerieDocSoporte() == null)
							{
								serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
							}
							serie.getListSerieDocSoporte().add(serieDocSopTrans);
							break;
						}
					}
				}
				//RIN13
				/*
        //inicio gmontoya
        //Solo para diligencia de rectificaci�n.
        // Asociamos las facturas a la serie pero como documento soporte
        List<Map> lstFormaFactuA = (List<Map>) mapinput.get("lstFormaFactuActual");
        List<Map> lstSeriesItemA = (List<Map>) mapinput.get("lstSeriesItemActual");

        if (!CollectionUtils.isEmpty(lstFormaFactuA) && !CollectionUtils.isEmpty(lstSeriesItemA))
        {
          for (Map mapa : lstSeriesItemA){
        	  if(mapa.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
	        	  for(Map mapaFactu : lstFormaFactuA){
	        		  if(mapa.get("NUM_SECFACT").equals(mapaFactu.get("NUM_SECFACT"))){
	        			  DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
	                      serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapa.get("NUM_SECSERIE"))));
	                      serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFactu.get("NUM_SECFACT"))));
	                      serieDocSopTrans.setCodtipodocsoporte("2");
	                      if (CollectionUtils.isEmpty(serie.getListSerieDocSoporte()))
	                      {
	                        serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
	                      }
	                      serie.getListSerieDocSoporte().add(serieDocSopTrans);	                      
	        		  }
	        	  }
        	  }
          }
        }        
        //fin gmontoya
				 */
				List<Map<String, Object>> lstFacturaSerie = (List<Map<String, Object>>)detDeclara.get("lstFacturaSerie");
				if (!CollectionUtils.isEmpty(lstFacturaSerie))
				{
					for (Map<String, Object> mapaFacturaSerie : lstFacturaSerie){
						if(mapaFacturaSerie.get("NUM_SECSERIE").toString().equals(detDeclara.get("NUM_SECSERIE").toString())){
							DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
							serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFacturaSerie.get("NUM_SECSERIE"))));
							serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapaFacturaSerie.get("NUM_SECFACT"))));
							serieDocSopTrans.setCodtipodocsoporte("2");
							if (CollectionUtils.isEmpty(serie.getListSerieDocSoporte()))
							{
								serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
							}
							serie.getListSerieDocSoporte().add(serieDocSopTrans);	                      
						}
					}
				}        

				//INICIO RIN 13
				// Asociamos el documento de AutoCertificacion a la serie pero como documento
				if (!CollectionUtils.isEmpty(lstDetAutorizacion)) 
				{
					for (Map mapDetAutorizacion : lstDetAutorizacion)
					{
						if (mapDetAutorizacion.get("NUM_SECSERIE").equals(detDeclara.get("NUM_SECSERIE"))
								&& (mapDetAutorizacion.get("COD_TIPOPER").equals("C")))
						{
						  if (SunatNumberUtils.toInteger(mapDetAutorizacion.get("IND_DEL")).intValue() == 0) {//PAS20175E220200059
							DatoSerieDocSoporte serieDocSopTrans = new DatoSerieDocSoporte();
							serieDocSopTrans.setNumcorredoc(SunatNumberUtils.toLong(mapDetAutorizacion.get("NUM_CORREDOC")));
							serieDocSopTrans.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECSERIE"))));
							serieDocSopTrans.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECDOC"))));
							serieDocSopTrans.setCodtipooper(ObjectUtils.toString(mapDetAutorizacion.get("COD_TIPOPER")));
							serieDocSopTrans.setCodtipodocsoporte("5");
							if (serie.getListSerieDocSoporte() == null)
							{
								serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
							}
							serie.getListSerieDocSoporte().add(serieDocSopTrans);
						}
					}
				}
				}

				//FIN RIN 13
				listSeries.add(serie);

			}
		}

		if (!CollectionUtils.isEmpty(lstFacturasSerie))
		{
			/*INICIO RIN13*/
			//RIN 13 se tiene que sacar solo las facturas
			List<Integer> numerosSecuenciaFactura = new ArrayList<Integer>(); 

			Elementos<DatoFacturaref> listFacturaRef = new Elementos<DatoFacturaref>();
			declaracion.getDua().setListFacturaRef(listFacturaRef);

			for (Map mapFacturasSerie : lstFacturasSerie)
			{
				String indicadorEliminacion = ObjectUtils.toString(mapFacturasSerie.get("IND_DEL"), "0");

				if(!"1".equals(indicadorEliminacion)){// si esta eliminado no se agrega
					Integer numeroSecuenciaFacturaSerie = SunatNumberUtils.toInteger(mapFacturasSerie.get("NUM_SECFACT")); //si es vacio el caso de las agregadas le coloca 0
					boolean existe = false;
					boolean isNuevo = false;

					if(!numeroSecuenciaFacturaSerie.equals(0)){
						for(Integer numeroSecuenciaFactura : numerosSecuenciaFactura){
							if(numeroSecuenciaFacturaSerie.equals(numeroSecuenciaFactura)){
								existe = true;
								break;
							}
						}
					}else{
						isNuevo = true;
					}

					if(!existe){
						DatoFacturaref facturaRef = new DatoFacturaref();
						facturaRef.setNumfactura((java.lang.String) mapFacturasSerie.get("NUM_FACT"));

						/*FIN RIN13*/				

						//RIN13 - no aplica
						/*//inicio diligencia rectificacion gmontoya
	        if(mapFacturasSerie.get("NUM_FACT")!=null && !mapFacturasSerie.get("NUM_FACT").toString().trim().isEmpty()){
	        	facturaRef.setNumfactura((java.lang.String) mapFacturasSerie.get("NUM_FACT"));
	        }else{
	        	List<Map> lstComproBPagoA = (List<Map>) mapinput.get("lstComproBPagoActual");
	        	for(Map mapaCompro : lstComproBPagoA){
	      		  if(mapFacturasSerie.get("NUM_SECFACT").equals(mapaCompro.get("NUM_SECFACT"))){
	      			facturaRef.setNumfactura((java.lang.String) mapaCompro.get("NUM_FACT"));
	      		  }
	        	}
	        }
	      //fin diligencia rectificacion gmontoya
						 */  

						if(mapFacturasSerie.get("FEC_FACT")!=null){//ajuste por SAU20153K004000234 - regimen 70 amancilla
							if (mapFacturasSerie.get("FEC_FACT").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")){
								facturaRef.setFecfactura(new java.util.Date(((FechaBean) mapFacturasSerie.get("FEC_FACT")).getTimestamp().getTime()));
							} else if (mapFacturasSerie.get("FEC_FACT") instanceof java.util.Date){
								facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "yyyy-MM-dd HH:mm:ss"));
							} else {


								if(SunatStringUtils.indexOf(mapFacturasSerie.get("FEC_FACT").toString(), "/")!=-1)
								{
									facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "dd/MM/yyyy"));
								}
								else
								{
									facturaRef.setFecfactura(SunatDateUtils.getDate(mapFacturasSerie.get("FEC_FACT").toString(), "yyyy-MM-dd HH:mm:ss"));
								}
							}
						}
						//facturaRef.setNumsecfactu(SunatNumberUtils.toInteger(mapFacturasSerie.get("NUM_SECFACT")));
						facturaRef.setNumsecfactu(numeroSecuenciaFacturaSerie); //RIN13
						facturaRef.setPadre(declaracion.getDua()); /*RIN 07-RIN 13*/
						listFacturaRef.add(facturaRef);
						//declaracion.getDua().setListFacturaRef(listFacturaRef);
						if(!isNuevo){
							numerosSecuenciaFactura.add(numeroSecuenciaFacturaSerie); //RIN13
						}
					}
				}
			}
		}

		if (!CollectionUtils.isEmpty(lstIndicadorDua)) {
			Elementos<DatoIndicadores> listIndicadores = new Elementos<DatoIndicadores>();
			declaracion.getDua().setListIndicadores(listIndicadores);
			for (Map<String, Object> mapListIndicadores : lstIndicadorDua){
				DatoIndicadores indicadoresRef = new DatoIndicadores();
				indicadoresRef.setCodtipoindica((String)mapListIndicadores.get("COD_INDICADOR"));
				//P46 INICIO  EJHM
				if(mapListIndicadores.get("IND_ACTIVO")!=null){
					indicadoresRef.setIndicadorActivo(mapListIndicadores.get("IND_ACTIVO").toString());	
				}
				//P46 FIN EJHM
				listIndicadores.add(indicadoresRef);
			}
		}

		declaracion.getDua().setManifiesto(new DatoManifiesto());
		declaracion.getDua().getManifiesto().setCodaduamanif((java.lang.String) mapCabDeclara.get("COD_ADUAMANIFIESTO"));
		declaracion.getDua().getManifiesto().setAnnmanif(SunatStringUtils.toStringObj(mapCabDeclara.get("ANN_MANIFIESTO")));

		//si el numero de manifesto es vacio debeo enviar NULL para que no date y no valide el manifiesto
		//ya que para anticipados no debe validar
		String numManifiesto = mapCabDeclara.get("NUM_MANIFIESTO").toString().trim();
		if (SunatStringUtils.isEmpty(numManifiesto))
		{
			numManifiesto = null;
		}

		declaracion.getDua().getManifiesto().setNummanif(numManifiesto);
		declaracion.getDua().getManifiesto().setCodmodtransp((java.lang.String) mapCabDeclara.get("COD_VIATRANS"));

		if (mapCabDeclara.get("FEC_TERM").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion
			.getDua()
			.getManifiesto()
			.setFectermino(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_TERM")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_TERM") instanceof java.util.Date)
		{
			//declaracion.getDua().getManifiesto().setFectermino((java.util.Date) mapCabDeclara.get("FEC_TERM"));
			//declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDate(mapCabDeclara.get("FEC_TERM").toString(),"yyyy-MM-dd HH:mm:ss"));

			String fechaString = SunatDateUtils.getFormatDate((java.util.Date) mapCabDeclara.get("FEC_TERM"),"yyyy-MM-dd HH:mm:ss");
			declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDate(fechaString, "yyyy-MM-dd HH:mm:ss"));

		}
		else
		{
			//amancilla es posible que se caiga mejor lo cambio Pase P21-P22 declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDate(mapCabDeclara.get("FEC_TERM").toString(), "yyyy-MM-dd HH:mm:ss"));

			declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclara.get("FEC_TERM").toString()));
		}

		declaracion.getDua().getManifiesto().setCodtipomanif((java.lang.String) mapCabDeclara.get("COD_TIPMANIFIESTO"));
		declaracion.getDua().getManifiesto().setEmpTransporte(new Participante());
		declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad((java.lang.String) mapCabDeclara.get("NUM_DOCIDENT_PTR"));
		declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat((java.lang.String) mapCabDeclara.get("COD_TIPDOC_PTR"));


		declaracion.getDua().setPago(new DatoPago());
		declaracion.getDua().getPago().setPagoDeclaracion(new DatoPagoDecla());
		declaracion.getDua().getPago().getPagoDeclaracion().setCodbcopagoelec(
				SunatStringUtils.toStringObj(mapCabDeclara.get("COD_BCOPAGOELEC")));
		declaracion.getDua().getPago().getPagoDeclaracion().setNumctapagoelec(
				(java.lang.String) mapCabDeclara.get("NUM_CUENTAPAGOE"));
		declaracion.getDua().getPago().getPagoDeclaracion().setCodgarantia(
				(java.lang.String) mapCabDeclara.get("NUM_CTACTE"));


		declaracion.getDua().getPago().setPagoTransaccion(new DatoPagoTrans());
		declaracion.getDua().getPago().getPagoTransaccion().setCodentipago(
				(java.lang.String) mapCabDeclara.get("COD_ENTIPAGO"));
		declaracion.getDua().getPago().getPagoTransaccion().setCodmodpago(
				(java.lang.String) mapCabDeclara.get("COD_MODPAGO"));
		declaracion.getDua().getPago().getPagoTransaccion().setNumplazcredito(
				SunatNumberUtils.toInteger(mapCabDeclara.get("CNT_PLZCREDITO")));

		if (mapCabDeclara.get("FEC_CARCR").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
		{
			declaracion
			.getDua()
			.getPago()
			.getPagoTransaccion()
			.setFeccarcr(new java.util.Date(((FechaBean) mapCabDeclara.get("FEC_CARCR")).getTimestamp().getTime()));
		}
		else if (mapCabDeclara.get("FEC_CARCR") instanceof java.util.Date)
		{
			//declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr((java.util.Date) mapCabDeclara.get("FEC_CARCR"));
			declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CARCR").toString(),"yyyy-MM-dd HH:mm:ss"));
		}
		else
		{
			declaracion
			.getDua()
			.getPago()
			.getPagoTransaccion()
			.setFeccarcr(SunatDateUtils.getDate(mapCabDeclara.get("FEC_CARCR").toString(), "yyyy-MM-dd HH:mm:ss"));
		}

		if (declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr() != null)
		{
			FechaBean fDef = new FechaBean("01/01/0001", "dd/MM/yyyy");
			FechaBean fCarcr = new FechaBean(new java.sql.Date(declaracion
					.getDua()
					.getPago()
					.getPagoTransaccion()
					.getFeccarcr()
					.getTime()));
			if (FechaBean.getDiferencia(fCarcr.getCalendar(), fDef.getCalendar(), Calendar.DATE) == 0)
			{
				declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr(null);
			}
		}



		if (!CollectionUtils.isEmpty(lstCabCertiOrigen))
		{
			Elementos<DatoAutocertificacion> listAutocertificacion = new Elementos<DatoAutocertificacion>();
			declaracion.getDua().setDatoCertificadoOrigen(new DatoCertificadoOrigen());
			//amancilla se pone al final PAS20155E220000054
			// declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion(listAutocertificacion);

			for (Map mapCabCertiOrigen : lstCabCertiOrigen)
			{
				//amancilla esta saliendo error 30402 REQ 2018-077174
				boolean isEliminado = (1 == SunatNumberUtils.toInteger(mapCabCertiOrigen.get("IND_DEL")).intValue());
				if(isEliminado){
					continue;
				}
				DatoAutocertificacion autocertificacion = new DatoAutocertificacion();
				autocertificacion.setNumdocumento((java.lang.String) mapCabCertiOrigen.get("NUM_CERTIFICADO"));

				if (mapCabCertiOrigen.get("FEC_CERTIFICADO").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					autocertificacion.setFecemision(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_CERTIFICADO")).getTimestamp().getTime()));
				}
				//    	  gmontoya Pase 44
				//          else if (mapCabCertiOrigen.get("FEC_CERTIFICADO") instanceof java.util.Date)//PAS20165E220200036
				//          {       
				//        	  autocertificacion.setFecemision(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_CERTIFICADO").toString()));
				//              }
				//    	  gmontoya Pase 44
				else
				{
					/**pase32 inicio ajustes necesarios**/
					if(mapCabCertiOrigen.get("FEC_CERTIFICADO") instanceof java.util.Date){//PAS20165E220200036
						autocertificacion.setFecemision( (Date)mapCabCertiOrigen.get("FEC_CERTIFICADO"));       		  
					}
					else{
						/**pase32 fin ajustes necesarios**/
						// PAS20155E220100048

						if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_CERTIFICADO").toString()) == null){
							autocertificacion.setFecemision(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime())); 
						}else{
							autocertificacion.setFecemision(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_CERTIFICADO").toString()));
						}
						//mapCabCertiOrigen.put("FEC_CERTIFICADO", autocertificacion.getFecemision());    	  
						/**pase32 inicio ajustes necesarios**/
					}//ajuste pase32
					/**pase32 fin ajustes necesarios**/
				}


				if (mapCabCertiOrigen.get("FEC_INIPERIODOEMB").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					// PAS20155E220100048
					autocertificacion.setFeciniembarque(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_INIPERIODOEMB")).getTimestamp().getTime()));
				}
				else if (mapCabDeclara.get("FEC_INIPERIODOEMB") instanceof java.util.Date)
				{
					// PAS20155E220100048
					autocertificacion.setFeciniembarque(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_INIPERIODOEMB").toString()));
				}
				else
				{       
					/**pase32 ajustes necesarios**/
					if(mapCabDeclara.get("FEC_INIPERIODOEMB") instanceof java.util.Date){
						autocertificacion.setFecemision( (Date)mapCabCertiOrigen.get("FEC_INIPERIODOEMB"));       		  
					}
					else{
						//PASE TLC COREA - No se esta seteando la fecha de inicio ni fin de embarque, se a�ade if
						if(mapCabCertiOrigen.get("FEC_INIPERIODOEMB") instanceof java.util.Date){
							autocertificacion.setFeciniembarque( (Date)mapCabCertiOrigen.get("FEC_INIPERIODOEMB"));
							//fin TLC COREA
						}else if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_INIPERIODOEMB").toString()) == null){            	   
							/**pase32 ajustes necesarios**/
							// PAS20155E220100048

							autocertificacion.setFeciniembarque(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime())); 
						}else{
							autocertificacion.setFeciniembarque(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_INIPERIODOEMB").toString()));
						}
						//mapCabCertiOrigen.put("FEC_INIPERIODOEMB", autocertificacion.getFecemision());    	  
						/**pase32 inicio ajustes necesarios**/
					}//ajuste pase32
					/**pase32 fin ajustes necesarios**/
				}


				if (mapCabCertiOrigen.get("FEC_FINPEREMB").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					autocertificacion.setFecfinembarque(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_FINPEREMB")).getTimestamp().getTime()));
				}
				else if (mapCabDeclara.get("FEC_FINPEREMB") instanceof java.util.Date)
				{
					autocertificacion.setFecfinembarque(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_FINPEREMB").toString()));
				}
				else
				{
					/**pase32 ajustes necesarios**/
					if(mapCabDeclara.get("FEC_FINPEREMB") instanceof java.util.Date){
						autocertificacion.setFecemision( (Date)mapCabCertiOrigen.get("FEC_FINPEREMB"));       		  
					}
					else{

						//PASE TLC COREA - No se esta seteando la fecha de inicio ni fin de embarque, se a�ade if
						if(mapCabCertiOrigen.get("FEC_FINPEREMB") instanceof java.util.Date){
							autocertificacion.setFecfinembarque( (Date)mapCabCertiOrigen.get("FEC_FINPEREMB"));
							//fin TLC COREA
						}else
							/**pase32 ajustes necesarios**/ 
							// PAS20155E220100048
							if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_FINPEREMB").toString()) == null){
								autocertificacion.setFecfinembarque(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime())); 
							}else{
								autocertificacion.setFecfinembarque(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_FINPEREMB").toString()));
							}
						//mapCabCertiOrigen.put("FEC_FINPEREMB", autocertificacion.getFecemision());    	
						/**pase32 inicio ajustes necesarios**/
					}//ajuste pase32
					/**pase32 fin ajustes necesarios**/

				}

				if (mapCabCertiOrigen.get("FEC_EMBORIGEN").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					autocertificacion.setFecEmborigen(new java.util.Date(((FechaBean) mapCabCertiOrigen.get("FEC_EMBORIGEN")).getTimestamp().getTime()));
				}
				else if (mapCabDeclara.get("FEC_EMBORIGEN") instanceof java.util.Date)
				{
					autocertificacion.setFecEmborigen(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_EMBORIGEN").toString()));
				}
				else
				{
					/**pase32 ajustes necesarios**/
					if(mapCabDeclara.get("FEC_EMBORIGEN") instanceof java.util.Date){
						autocertificacion.setFecemision( (Date)mapCabCertiOrigen.get("FEC_EMBORIGEN"));       		  
					}
					else{
						/**pase32 ajustes necesarios**/ 
						// PAS20155E220100048
						if (SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_EMBORIGEN").toString()) == null){
							autocertificacion.setFecEmborigen(new java.util.Date(new FechaBean("01/01/0001", "dd/MM/yyyy").getTimestamp().getTime())); 
						}else{
							autocertificacion.setFecEmborigen(SunatDateUtils.getDateFromUnknownFormat(mapCabCertiOrigen.get("FEC_EMBORIGEN").toString()));
						}
						//mapCabCertiOrigen.put("FEC_EMBORIGEN", autocertificacion.getFecemision());
						/**pase32 inicio ajustes necesarios**/
					}//ajuste pase32
					/**pase32 fin ajustes necesarios**/	
				}

				/*INICIO RIN13*/
				autocertificacion.setNumcorredoc(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC").toString()));
				autocertificacion.setCodffco((java.lang.String) mapCabCertiOrigen.get("COD_FFCO"));
				autocertificacion.setCodtipoCO((java.lang.String) mapCabCertiOrigen.get("COD_TIPCERTIFICADO"));
				autocertificacion.setCodtipoemisorCO((java.lang.String) mapCabCertiOrigen.get("COD_EMISCERT"));
				autocertificacion.setNomemisorCO((java.lang.String) mapCabCertiOrigen.get("NOM_EMISCERTIF"));
				autocertificacion.setNumautoexp((java.lang.String) mapCabCertiOrigen.get("NUM_AUTORIZEXP"));
				autocertificacion.setNomproduc((java.lang.String) mapCabCertiOrigen.get("NOM_PRODMERC"));
				autocertificacion.setNomProdmerc((java.lang.String) mapCabCertiOrigen.get("NOM_PRODMERC"));
				autocertificacion.setCodcriterioO((java.lang.String) mapCabCertiOrigen.get("COD_CRITERIOORIGEN"));
				autocertificacion.setIndtrans((java.lang.String) mapCabCertiOrigen.get("IND_PROCETERCERPAIS"));
				autocertificacion.setNumsecCO(SunatNumberUtils.toInteger(mapCabCertiOrigen.get("NUM_SECDOC")));
				autocertificacion.setCodmoneda((java.lang.String)(mapCabCertiOrigen.get("COD_MONEDAFACT")));
				autocertificacion.setMtofobmon(SunatNumberUtils.toBigDecimal(mapCabCertiOrigen.get("MTO_FACTURA")));
				autocertificacion.setIndElectronico((java.lang.String) (mapCabCertiOrigen.get("IND_ELECTRONICO")!=null?mapCabCertiOrigen.get("IND_ELECTRONICO"):"0"));//PAS20181U220200056
				listAutocertificacion.add(autocertificacion);



				//INICIO RIN13
				/*List<Map> lstDocAutAsociado = null;
		if (mapCabDeclara.containsKey("lstDocAutAsociado"))
			lstDocAutAsociado = (List<Map>) mapCabDeclara.get("lstDocAutAsociado" + sufijo);

		if (!CollectionUtils.isEmpty(lstDocAutAsociado)) {
			addOtroDocSoporte(declaracion, lstDocAutAsociado, listOtrosDocSoporte);
		}*/
			}

			//amancilla Bug 21017 PAS20155E220000054
			declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion(listAutocertificacion);
		}


		/*List<Map> lstDocAutAsociado = null;
    if (mapCabDeclara.containsKey("lstDocAutAsociado"))
      lstDocAutAsociado = (List<Map>) mapCabDeclara.get("lstDocAutAsociado" + sufijo);*/

		//FIN RIN13
		if (!CollectionUtils.isEmpty(lstDocAutAsociado)) {
			addOtroDocSoporte(declaracion, lstDocAutAsociado, listOtrosDocSoporte);
		}

		//amancilla inicio PAS20165E220200126
		Elementos<DAV> listDAVs = new Elementos<DAV>();
		declaracion.setListDAVs(listDAVs);
       //amancilla fin PAS20165E220200126
		if (!CollectionUtils.isEmpty(lstFormBProveedor))
		{

			//PAS20165E220200126 Elementos<DAV> listDAVs = new Elementos<DAV>();
			//PAS20165E220200126 declaracion.setListDAVs(listDAVs);

			for (Map formBProveedor : lstFormBProveedor)
			{
				if(Constantes.IND_ELIMINADO.equals(formBProveedor.get("ind_del"))){
					continue;  
				}

				DAV dav = new DAV();
				listDAVs.add(dav);

				log.debug("-->formBProveedor: " + formBProveedor);
				//dav.setNumsecuprov(new Integer(ObjectUtils.toString(formBProveedor.get("NUM_SECPROVE"), "0")));

				//dav.setNumsecuprov(new Integer(ObjectUtils.toString(this.getObjectFromMap(formBProveedor,"NUM_SECPROVE"), "0")));
				dav.setNumsecuprov(new Integer(ObjectUtils.toString(this.getObjectFromMap(formBProveedor,"num_secprove"), "0"))); //RIN13
				//dav.setCntfacturas(new Integer(ObjectUtils.toString(formBProveedor.get("CNT_FACT"), "0")));
				dav.setCntfacturas(new Integer(ObjectUtils.toString(formBProveedor.get("cnt_fact"), "0"))); //RIN13
				//dav.setNumcorredoc(new Long(ObjectUtils.toString(formBProveedor.get("NUM_CORREDOC"), "0")));
				dav.setNumcorredoc(new Long(ObjectUtils.toString(formBProveedor.get("num_corredoc"), "0"))); //RIN13
				//dav.setNumcodsecprove(new Long(ObjectUtils.toString(formBProveedor.get("NUM_CODSECPROVE"), "0")));
				dav.setNumcodsecprove(new Long(ObjectUtils.toString(formBProveedor.get("num_codsecprove"), "0"))); //RIN13
				dav.setNumsecintermediario(new Long(ObjectUtils.toString(formBProveedor.get("num_secintermediario"), "0")));  //RIN13
				//dav.setNumsecdeclarante(new Long(ObjectUtils.toString(formBProveedor.get("NUM_SECDECLARANTE"), "0")));
				dav.setNumsecdeclarante(new Long(ObjectUtils.toString(formBProveedor.get("num_secdeclarante"), "0"))); //RIN13

				//dav.setCodproveedor(ObjectUtils.toString(formBProveedor.get("COD_PROVE"), null));
				//RIN13
				dav.setFlag(ObjectUtils.toString(formBProveedor.get("ind_flag"), null));
				if("3".equals(dav.getFlag())){
					dav.setCodproveedor(null);         	
				}else{
					dav.setCodproveedor(ObjectUtils.toString(formBProveedor.get("cod_prove"), null)); //RIN13
				}

				/*INICIO SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/ 	
				Elementos<DocumentoSoporteFormatoB> listDocumentoSoporteFormatoB = new Elementos<DocumentoSoporteFormatoB>();
				DocumentoSoporteFormatoB documentoSoporteFormatoB = new DocumentoSoporteFormatoB();
				
				documentoSoporteFormatoB.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("cod_medio_pago"), null));
				documentoSoporteFormatoB.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("cod_enti_financ"), null));
				documentoSoporteFormatoB.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("cod_ident_pago"), null));
				documentoSoporteFormatoB.setDesMedioPago(ObjectUtils.toString(formBProveedor.get("des_otro_medio_pago"), null));
				documentoSoporteFormatoB.setDesEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("des_otro_enti_financ"), null));
				documentoSoporteFormatoB.setTipoDocumento("450");
				
				listDocumentoSoporteFormatoB.add(documentoSoporteFormatoB);
				dav.setListDocumentoSoporteFormatoB(listDocumentoSoporteFormatoB);
				
				dav.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("cod_medio_pago"), null));
				dav.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("cod_ident_pago"), null));
				dav.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("cod_enti_financ"), null));
				dav.setDesMedioPago(ObjectUtils.toString(formBProveedor.get("des_otro_medio_pago"), null));
				dav.setDesEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("des_otro_enti_financ"), null));
				/*FIN SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/
				
				//dav.setCodnivcomer(ObjectUtils.toString(formBProveedor.get("COD_NIVELCOMER"), null));
				dav.setCodnivcomer(ObjectUtils.toString(formBProveedor.get("cod_nivelcomer"), null)); //RIN13
				//dav.setCodnatutrans(ObjectUtils.toString(formBProveedor.get("COD_NATUTRANS"), null));
				dav.setCodnatutrans(ObjectUtils.toString(formBProveedor.get("cod_natutrans"), null)); //RIN13
				//dav.setCodformenvio(ObjectUtils.toString(formBProveedor.get("COD_FORMAENVIO"), null)); 
				dav.setCodformenvio(ObjectUtils.toString(formBProveedor.get("cod_formaenvio"), null));
				//dav.setNumenvio(new Integer(ObjectUtils.toString(formBProveedor.get("NUM_ENVIO"), "0")));
				dav.setNumenvio(new Integer(ObjectUtils.toString(formBProveedor.get("num_envio"), "0")));
				//dav.setIndexisinter(ObjectUtils.toString(formBProveedor.get("IND_INTEMEDIARIO"), null)); // no se envia
				dav.setIndexisinter(ObjectUtils.toString(formBProveedor.get("ind_intemediario"), null)); 
				//dav.setCodcondprov(ObjectUtils.toString(formBProveedor.get("COD_CONDPROVE"), null));
				dav.setCodcondprov(ObjectUtils.toString(formBProveedor.get("cod_condprove"), null));
				//dav.setCodtipinter(ObjectUtils.toString(formBProveedor.get("COD_TIPINTERM"), null)); // no se envia
				dav.setCodtipinter(ObjectUtils.toString(formBProveedor.get("cod_tipinterm"), null)); // no se envia
				//dav.setNomcargdecla(ObjectUtils.toString(formBProveedor.get("NOM_CARGO"), null));
				dav.setNomcargdecla(ObjectUtils.toString(formBProveedor.get("nom_cargo"), null)); //RIN13
				//dav.setCodtipgrabado(ObjectUtils.toString(formBProveedor.get("COD_TIPGRABADO"), null));
				dav.setCodtipgrabado(ObjectUtils.toString("P", null)); //Portal especialista 
				dav.setPadre(declaracion); /*RIN 13*/
				//dav.setPadre(declaracion.getDua()); /*RIN 07-RIN 13*/

				log.debug("-->dav.cod_propiedad: " + ((Declaracion)dav.getPadre()).getDua().getCodpropiedad());


				if (dav.getProveedorLocal() == null)
				{
					dav.setProveedorLocal(new Participante());
					dav.getProveedorLocal().setTipoDocumentoIdentidad(new DataCatalogo());
				}
				dav
				.getProveedorLocal()
				.getTipoDocumentoIdentidad()
				.setCodDatacat(ObjectUtils.toString(formBProveedor.get("COD_DOCPROVLOCAL"), null));
				dav.getProveedorLocal().setNumeroDocumentoIdentidad(
						ObjectUtils.toString(formBProveedor.get("COD_DOCIDENTPROVLOC"), null));

				// dav.setListMontos()
				//     Comentado para ser reemplazado por lo sgte del pase 42:
				Map mapFormBMonto = (Map) formBProveedor.get("mapFormBMonto" + sufijo);
				if (!CollectionUtils.isEmpty(mapFormBMonto))
				{
					Elementos<DatoMonto> listMontos = new Elementos<DatoMonto>();
					// dav.setListMontos(listMontos);

					Set keySetFormBMonto = mapFormBMonto.keySet();
					for (Object key : keySetFormBMonto)
					{
						DatoMonto monto = new DatoMonto();
						monto.setCodmonto(key.toString()); // "COD_MONTO"
						//amancilla fix INC 2016-015811 monto.setMtologistico(new java.math.BigDecimal(mapFormBMonto.get(key).toString())); // "MTO_VALOR"
						monto.setMtologistico(Utilidades.toBigDecimal(mapFormBMonto.get(key).toString())); // "MTO_VALOR"
						//fin amancilla
						listMontos.add(monto);
					}
					dav.setListMontos(listMontos);
				}

				if (dav.getProveedor() == null) //PROVEEDOR
				{
					dav.setProveedor(new Participante());
				}
				if (dav.getProveedor().getPais() == null)
				{
					dav.getProveedor().setPais(new DataCatalogo());
				}
				// obtener esta info de participante doc
				//dav.getProveedor().getTipoParticipante().setCodDatacat(formBProveedor.get("cod_tippartic_prv") != null ? (java.lang.String) formBProveedor.get("cod_tippartic_prv") : "93"); //RIN13 
				dav.getProveedor().getTipoParticipante().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tippartic_prv"), "93")); //RIN13
				//dav.getProveedor().getTipoDocumentoIdentidad().setCodDatacat(formBProveedor.get("cod_tipdoc_prv") != null ? (java.lang.String) formBProveedor.get("cod_tipdoc_prv") : ""); //RIN13
				dav.getProveedor().getTipoDocumentoIdentidad().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tipdoc_prv"), "")); //RIN13
				dav.getProveedor().getPais().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_paisorigen_prv"), "")); 
				//dav.getProveedor().getPais().setCodDatacat(formBProveedor.get("cod_paisorigen_prv") != null ? (java.lang.String) formBProveedor.get("cod_paisorigen_prv") : "");
				dav.getProveedor().setNombreRazonSocial(ObjectUtils.toString(formBProveedor.get("nom_razonsocial_prv"), ""));
				//dav.getProveedor().setNombreRazonSocial(formBProveedor.get("nom_razonsocial_prv") != null ? (java.lang.String) formBProveedor.get("nom_razonsocial_prv") : "");
				dav.getProveedor().setCiudad(formBProveedor.get("nom_razonsocial_prv") != null ? (java.lang.String) formBProveedor.get("des_ubigeociudad_prv") : "");
				dav.getProveedor().setDireccion(ObjectUtils.toString(formBProveedor.get("dir_partic_prv"), ""));
				//dav.getProveedor().setDireccion(formBProveedor.get("dir_partic_prv") != null ? (java.lang.String) formBProveedor.get("dir_partic_prv") : "");
				dav.getProveedor().setTelefono(ObjectUtils.toString(formBProveedor.get("num_telefono_prv"), ""));
				//dav.getProveedor().setTelefono(formBProveedor.get("num_telefono_prv") != null ? (java.lang.String) formBProveedor.get("num_telefono_prv") : "");
				dav.getProveedor().setFax(ObjectUtils.toString(formBProveedor.get("num_fax_prv"), ""));
				//dav.getProveedor().setFax(formBProveedor.get("num_fax_prv") != null ? (java.lang.String) formBProveedor.get("num_fax_prv") : ""); 
				dav.getProveedor().setEmail(formBProveedor.get("nom_email_prv") != null ? ((java.lang.String) formBProveedor.get("nom_email_prv")).trim() : "");
				dav.getProveedor().setPaginaWeb(formBProveedor.get("nom_paginaweb_prv") != null ? ((java.lang.String) formBProveedor.get("nom_paginaweb_prv")).trim() : "");

				//PROVEEDOR LOCAL
				/*if (dav.getProveedorLocal() == null)
        {
          dav.setProveedorLocal(new Participante());
        }*/

				if (dav.getProveedorLocal() == null)
				{
					dav.setProveedorLocal(new Participante());
					dav.getProveedorLocal().setTipoDocumentoIdentidad(new DataCatalogo());
				}
				//dav.getProveedorLocal().getTipoDocumentoIdentidad().setCodDatacat(ObjectUtils.toString(formBProveedor.get("COD_DOCPROVLOCAL"), null));
				//dav.getProveedorLocal().getTipoDocumentoIdentidad().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_docprovlocal"), null));
				dav.getProveedorLocal().getTipoDocumentoIdentidad().setCodDatacat(formBProveedor.get("cod_docprovlocal") != null ? ((java.lang.String) formBProveedor.get("cod_docprovlocal")).trim() : "");
				//dav.getProveedorLocal().setNumeroDocumentoIdentidad(ObjectUtils.toString(formBProveedor.get("COD_DOCIDENTPROVLOC"), null));
				//dav.getProveedorLocal().setNumeroDocumentoIdentidad(ObjectUtils.toString(formBProveedor.get("cod_docidentprovloc"), null));
				dav.getProveedorLocal().setNumeroDocumentoIdentidad(formBProveedor.get("cod_docidentprovloc") != null ? ((java.lang.String) formBProveedor.get("cod_docidentprovloc")).trim() : "");
				//dav.getProveedorLocal().setNombreRazonSocial(ObjectUtils.toString(formBProveedor.get("nom_razonsocial_prl"), ""));
				dav.getProveedorLocal().setNombreRazonSocial(formBProveedor.get("nom_razonsocial_prl") != null ? ((java.lang.String) formBProveedor.get("nom_razonsocial_prl")).trim() : "");
				if(!StringUtils.isEmpty(dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat()) && !StringUtils.isEmpty(dav.getProveedorLocal().getNumeroDocumentoIdentidad())){
					dav.getProveedorLocal().getTipoParticipante().setCodDatacat("91"); //RIN13
				}
				
				

				//INTERMEDIARIO
				/*INICIO RIN13*/
				if (dav.getIntermediario() == null) 
				{
					dav.setIntermediario(new Participante());
				}
				if(Constants.COD_EXISTE_INTERMEDIARIO_SI.equals(dav.getIndexisinter())){
					dav.getIntermediario().getTipoParticipante().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tippartic_pri"), "90"));
					dav.getIntermediario().getTipoDocumentoIdentidad().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tipdoc_pri"), ""));
					dav.getIntermediario().setNumeroDocumentoIdentidad(ObjectUtils.toString(formBProveedor.get("num_docident_pri"), ""));
					dav.getIntermediario().getPais().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_paisorigen_pri"), ""));
					dav.getIntermediario().setPaginaWeb(ObjectUtils.toString(formBProveedor.get("nom_paginaweb_pri"), ""));
					dav.getIntermediario().setNombreRazonSocial(ObjectUtils.toString(formBProveedor.get("nom_razonsocial_pri"), ""));
					dav.getIntermediario().setCiudad(ObjectUtils.toString(formBProveedor.get("des_ubigeociudad_pri"), ""));
					dav.getIntermediario().setDireccion(ObjectUtils.toString(formBProveedor.get("dir_partic_pri"), ""));
					dav.getIntermediario().setEmail(ObjectUtils.toString(formBProveedor.get("nom_email_pri"), ""));

					/*dav.getIntermediario().getTipoParticipante().setCodDatacat(formBProveedor.get("cod_tippartic_pri") != null ? (java.lang.String) formBProveedor.get("cod_tippartic_pri"): "90");
        dav.getIntermediario().getTipoDocumentoIdentidad().setCodDatacat(formBProveedor.get("cod_tipdoc_pri") != null ? (java.lang.String) formBProveedor.get("cod_tipdoc_pri"): "");
        dav.getIntermediario().setNumeroDocumentoIdentidad(formBProveedor.get("num_docident_pri") != null ? (java.lang.String) formBProveedor.get("num_docident_pri"): "");
        dav.getIntermediario().getPais().setCodDatacat(formBProveedor.get("cod_paisorigen_pri") != null ? (java.lang.String) formBProveedor.get("cod_paisorigen_pri"): "");
        dav.getIntermediario().setPaginaWeb(formBProveedor.get("nom_paginaweb_pri") != null ? (java.lang.String) formBProveedor.get("nom_paginaweb_pri") : "");
        dav.getIntermediario().setNombreRazonSocial(formBProveedor.get("nom_razonsocial_pri") != null ? (java.lang.String) formBProveedor.get("nom_razonsocial_pri") : "");
        dav.getIntermediario().setCiudad(formBProveedor.get("des_ubigeociudad_pri") != null ? (java.lang.String) formBProveedor.get("des_ubigeociudad_pri") : "");
        dav.getIntermediario().setDireccion(formBProveedor.get("dir_partic_pri") != null ? (java.lang.String) formBProveedor.get("dir_partic_pri"): "");
            dav.getIntermediario().setEmail(formBProveedor.get("nom_email_pri") != null ? (java.lang.String) formBProveedor.get("nom_email_pri") : "");*/
				}else{
					dav.getIntermediario().getTipoParticipante().setCodDatacat("");
					dav.getIntermediario().getTipoDocumentoIdentidad().setCodDatacat("");
					dav.getIntermediario().setNumeroDocumentoIdentidad("");
					dav.getIntermediario().getPais().setCodDatacat("");
					dav.getIntermediario().setPaginaWeb("");
					dav.getIntermediario().setNombreRazonSocial("");
					dav.getIntermediario().setCiudad("");
					dav.getIntermediario().setDireccion("");
					dav.getIntermediario().setEmail("");
				}
				/*FIN - RIN13*/

				//DECLARANTE
				if (dav.getPersonaDecl() == null)
				{
					dav.setPersonaDecl(new Participante());
				}

				dav.getPersonaDecl().getTipoParticipante().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tippartic_prd"), "92"));
				dav.getPersonaDecl().getTipoDocumentoIdentidad().setCodDatacat(ObjectUtils.toString(formBProveedor.get("cod_tipdoc_prd"), ""));
				dav.getPersonaDecl().setNumeroDocumentoIdentidad(ObjectUtils.toString(formBProveedor.get("num_docident_prd"), ""));
				dav.getPersonaDecl().setNombreRazonSocial(ObjectUtils.toString(formBProveedor.get("nom_razonsocial_prd"), ""));

				/*dav.getPersonaDecl().getTipoParticipante().setCodDatacat(formBProveedor.get("cod_tippartic_prd") != null ? (java.lang.String) formBProveedor.get("cod_tippartic_prd") : "92");
        dav.getPersonaDecl().getTipoDocumentoIdentidad().setCodDatacat(formBProveedor.get("cod_tipdoc_prd") != null ? (java.lang.String) formBProveedor.get("cod_tipdoc_prd") : "");
        dav.getPersonaDecl().setNumeroDocumentoIdentidad(formBProveedor.get("num_docident_prd") != null ? (java.lang.String) formBProveedor.get("num_docident_prd") : "");
        dav.getPersonaDecl().setNombreRazonSocial(formBProveedor.get("nom_razonsocial_prd") != null ? (java.lang.String) formBProveedor.get("nom_razonsocial_prd") : "");*/

				List<Map> lstComproBPago = null;

				//amancilla      
				if (formBProveedor.containsKey("lstComproBPago" + sufijo)){
					lstComproBPago = (List<Map>) formBProveedor.get("lstComproBPago" + sufijo);
				}/*else if (mapinput.containsKey("lstComproBPagoActual")){

        	lstComproBPago = (List<Map>) mapinput.get("lstComproBPagoActual");
        	lstComproBPago = filtrarComproBPagoXProveedor(lstComproBPago,dav.getNumsecuprov());        	        	
        }*///RIN13 - no esta aplicando
				if (!CollectionUtils.isEmpty(lstComproBPago))
				{
					Elementos<DatoFactura> listFacturas = new Elementos<DatoFactura>();
					dav.setListFacturas(listFacturas);

					for (Map comproBPago : lstComproBPago)
					{


						log.debug("-->comproBPago: " + comproBPago);
						if(Constantes.IND_ELIMINADO.equals(comproBPago.get("ind_del"))){//gg considerar fact eliminadas
							continue;  
						}
						DatoFactura factura = new DatoFactura();
						listFacturas.add(factura);//jenciso ceticos parte1

						factura.setNumsecprove(dav.getNumsecuprov());//jenciso ceticos parte1
						factura.setNumsecfactu(SunatNumberUtils.toInteger(comproBPago.get("num_secfact")!=null?comproBPago.get("num_secfact"):comproBPago.get("NUM_SECFACT")));
						//factura.setCnttotitems(SunatNumberUtils.toInteger(comproBPago.get("cnt_totitems")!=null?comproBPago.get("cnt_totitems"):comproBPago.get("CNT_TOTITEMS"))); //RIN13
						factura.setNumfactura((java.lang.String) (comproBPago.get("num_fact")!=null?comproBPago.get("num_fact"):comproBPago.get("NUM_FACT")));
						factura.setPadre(dav); /*RIN 07-RIN 13*/

						if ((comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT"))
								.getClass()
								.getName()
								.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
						{
							factura.setFecfactura(new java.util.Date(((FechaBean) (comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT")))
									.getTimestamp()
									.getTime()));
						}
						else
						{

							factura.setFecfactura(Utilidades.toDate(comproBPago.get("fec_fact")!=null?comproBPago.get("fec_fact"):comproBPago.get("FEC_FACT")));

						}

						factura.setCodincoterm((java.lang.String) (comproBPago.get("cod_incoterm")!=null?comproBPago.get("cod_incoterm"):comproBPago.get("COD_INCOTERM")));
						factura.setDeslugtrans((java.lang.String) (comproBPago.get("dir_lugartrans")!=null?comproBPago.get("dir_lugartrans"):comproBPago.get("DIR_LUGARTRANS")));
						factura.setCodmoneda((java.lang.String) (comproBPago.get("cod_moneda")!=null?comproBPago.get("cod_moneda"):comproBPago.get("COD_MONEDA")));
						factura.setCodpaisembar((java.lang.String) comproBPago.get("cod_paisembarque"));
						factura.setMtofactufob(SunatNumberUtils.toBigDecimal((comproBPago.get("mto_fact")!=null?comproBPago.get("mto_fact"):comproBPago.get("MTO_FACT"))));
						factura.setIndtipodecl((java.lang.String) (comproBPago.get("ind_ddjj")!=null?comproBPago.get("ind_ddjj"):comproBPago.get("IND_DDJJ")));
						//jenciso Inicio se cargan las facturas sucesivas
						List<Map<String,Object>> lstFactuSucesivas = null;
						if(comproBPago.containsKey("lstFactuSucesivas" + sufijo))
							lstFactuSucesivas = (List<Map<String,Object>>)comproBPago.get("lstFactuSucesivas" + sufijo);
						if(!CollectionUtils.isEmpty(lstFactuSucesivas)){
							Elementos<DatoFactSuce> listFactSuces = new Elementos<DatoFactSuce>();            	
							factura.setListFactSucesivas(listFactSuces);

							for(Map<String,Object> factSuce: lstFactuSucesivas){
								DatoFactSuce datoFactSuce = new DatoFactSuce();
								//datoFactSuce.setNumcorredoc(numcorredoc);
								datoFactSuce.setNumsecprove(dav.getNumsecuprov());
								datoFactSuce.setNumsecfact(SunatNumberUtils.toInteger(comproBPago.get("num_secfact")));
								datoFactSuce.setNumfactsuc((String)factSuce.get("NUM_FACT"));
								datoFactSuce.setMtofactsuc(SunatNumberUtils.toBigDecimal(factSuce.get("MTO_FACT")));
								//amancilla fix INC 2016-098817 correccion de conclusion
								datoFactSuce.setFecfactsuc(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(factSuce.get("FEC_FACT"))));
								//fin amancilla

								listFactSuces.add(datoFactSuce);

							}
						}
						//jenciso Fin

						List<Map> lstItemFactura = null;
						int cantidadItemFactura = 0;

						if (comproBPago.containsKey("lstItemFactura" + sufijo)) //jenciso se cambia al map correcto 
						{
							lstItemFactura = (List<Map>) comproBPago.get("lstItemFactura" + sufijo);//jenciso se cambia al map correcto
						}/*else if (mapinput.containsKey("lstItemFacturaActual")){

            	lstItemFactura = (List<Map>) mapinput.get("lstItemFacturaActual");            	
            	lstItemFactura = filtrarItemFacturaXfactura(lstItemFactura,factura.getNumsecfactu());
            }*/ //RIN13 - no esta aplicando

						if (!CollectionUtils.isEmpty(lstItemFactura))
						{
							Elementos<DatoItem> listItems = new Elementos<DatoItem>(); //jenciso ceticos parte 1
							factura.setListItems(listItems); //jenciso ceticos parte 1

							for (Map itemFactura : lstItemFactura)
							{

								if(Constantes.IND_ELIMINADO.equals(itemFactura.get("IND_DEL"))){//adicionado por PAS20145E220000682
									continue;  
								}

								DatoItem item = new DatoItem();
								listItems.add(item);
								item.setNumsecprove(dav.getNumsecuprov());//jenciso ceticos parte 1
								item.setNumsecfact(factura.getNumsecfactu());//jenciso ceticos parte 1
								item.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
								item.setCodpaisorige((java.lang.String) itemFactura.get("COD_PAISORIGEN"));
								item.setCntcantcomer(SunatNumberUtils.toBigDecimal(itemFactura.get("CNT_UNI")));
								item.setCodunidcomer((java.lang.String) itemFactura.get("COD_UNICOMER"));
								item.setDescomercial((java.lang.String) itemFactura.get("DES_COMER"));
								item.setDesmarca((java.lang.String) itemFactura.get("DES_MARCA"));
								item.setDesmodelo((java.lang.String) itemFactura.get("DES_MODELO"));
								item.setCodproducto((java.lang.String) itemFactura.get("COD_PROD"));
								item.setNumpartnandi(SunatNumberUtils.toLong(itemFactura.get("NUM_PARARANCEL")));
								item.setCodpaisadqui((java.lang.String) itemFactura.get("COD_PAISADQUI"));
								item.setDescaracteristicas((java.lang.String) itemFactura.get("DES_CARACTERISTICAS"));
								item.setDesclasevari((java.lang.String) itemFactura.get("DES_CLASEVARI"));
								item.setDesusoaplica((java.lang.String) itemFactura.get("DES_USOAPLIC"));
								item.setDesmaterialcomp((java.lang.String) itemFactura.get("DES_MATERIALCOMP"));
								item.setPadre(factura); /*RIN 13*/
								item.setNumsecfact(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECFACT"))); //pase42

								//FSW-INICIO
								item.setCodtipdescrmin((java.lang.String) itemFactura.get("COD_TIPDESCRMIN"));     
								String codTipDescrMin = itemFactura.get("COD_TIPDESCRMIN")!=null?itemFactura.get("COD_TIPDESCRMIN").toString():"";
								boolean esDescrMinimaNueva = codTipDescrMin.length()> 0;
								//FSW-INICIO

								//RIN13
								if("0".equals(itemFactura.get("IND_DEL"))){
									cantidadItemFactura++;
								}
								//jenciso Inicio agregamos lista de descripciones minimas
								//hacemos esta forma debido a que en la diligencia solo 
								//se esta modificando en el itemfactura mas no en el formbitemdescri
								//RIN13 x mientras ya que sale error lstDecrMinima String no List verificar porque se setea String y no List!!!!!!!!!!!!!!!!!!!
								Object objectDecrMinima = itemFactura.get("lstDecrMinima" + sufijo);
								log.debug("-->lstDecrMinima: " + objectDecrMinima);
								if(objectDecrMinima instanceof List){
									//List<Map<String,Object>> lstDecrMinima =  (ArrayList<Map<String,Object>>)itemFactura.get("lstDecrMinima" + sufijo);
									List<Map<String,Object>> lstDecrMinima =  (ArrayList<Map<String,Object>>)objectDecrMinima;
									if(!CollectionUtils.isEmpty(lstDecrMinima)){
										Elementos<DatoDescrMinima> listDecrMinima = new Elementos<DatoDescrMinima>();
										item.setListDecrMinima(listDecrMinima);
										for(Map<String,Object> mapDescriMin : lstDecrMinima){
											/*INICIO-PAS20165E220200137 AFMA*/
											String indicadorEliminado= mapDescriMin.get("IND_DEL")!=null?mapDescriMin.get("IND_DEL").toString():"0";
											if("0".equals(indicadorEliminado)) {
												/*FIN-PAS20165E220200137 AFMA*/
												DatoDescrMinima datoDescrMinima = new DatoDescrMinima();
												datoDescrMinima.setNumcorredoc(dav.getNumcorredoc());
												datoDescrMinima.setNumsecprove(dav.getNumsecuprov());
												datoDescrMinima.setNumsecfact(factura.getNumsecfactu());
												datoDescrMinima.setNumsecitem(SunatNumberUtils.toInteger(itemFactura.get("NUM_SECITEM")));
												datoDescrMinima.setCodtipdescr((String) mapDescriMin.get("COD_TIPDESC"));
												if (esDescrMinimaNueva) {
													datoDescrMinima.setCodtipvalor((String) mapDescriMin.get("COD_TIPVALOR"));
													datoDescrMinima.setValtipdescri( mapDescriMin.get("DES_DESCRIPCION").toString());//se le quita el trim
												} else {
													if (datoDescrMinima.getCodtipdescr().equals("04")) // esto solo es temporal...
														datoDescrMinima.setValtipdescri((java.lang.String) itemFactura.get("DES_CLASEVARI"));
													else
														datoDescrMinima.setValtipdescri((String) mapDescriMin.get("DES_DESCRIPCION"));

												}
												datoDescrMinima.setPadre(item);//gmontoya Pase 42 2015 sustento rzavala
												listDecrMinima.add(datoDescrMinima);
												/*INICIO-PAS20165E220200137 AFMA*/
											}
											/*FIN-PAS20165E220200137 AFMA*/
										}
									} 
								}
								//jenciso Fin agregamos lista de descripciones minimas

								//jenciso item.getMontoProv() NO DEFINIDO 
								if(item.getMontoProv() == null){
									item.setMontoProv(new DatoMontoProv());
								}

								if (itemFactura.get("FEC_VALESTIMA")!= null && itemFactura.get("FEC_VALESTIMA").getClass().getName()
										.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
								{
									item.getMontoProv().setFecvalestima(
											new java.util.Date(((FechaBean) itemFactura.get("FEC_VALESTIMA")).getTimestamp().getTime()));
								}
								else
								{
									//item.getMontoProv().setFecvalestima((java.util.Date) itemFactura.get("FEC_VALESTIMA"));
									item.getMontoProv().setFecvalestima( Utilidades.toDate(itemFactura.get("FEC_VALESTIMA")));
								}

								item.getMontoProv().setValmonto(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_MONTO")));
								item.getMontoProv().setCodmoneda((java.lang.String) itemFactura.get("COD_MONEDA"));
								//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								if (itemFactura.get("FEC_TIPCAMB") != null && 
										itemFactura.get("FEC_TIPCAMB")
										.getClass()
										.getName()
										.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
								{
									item.getMontoProv().setFectipocambio(
											new java.util.Date(((FechaBean) itemFactura.get("FEC_TIPCAMB")).getTimestamp().getTime()));
								}
								else
								{
									item.getMontoProv().setFectipocambio((java.util.Date) itemFactura.get("FEC_TIPCAMB"));
								}
								//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								item.getMontoProv().setValdefinitivo(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_DEFINITIVO")));
								//amancilla PAS20155E220200167 2da parte
								item.getMontoProv().setIndtipovalor(itemFactura.get("COD_TIPOVALOR")!=null?itemFactura.get("COD_TIPOVALOR").toString():"1");
								// Datos adicionales de los items
								item.setInddeducdisti((java.lang.String) itemFactura.get("IND_DEDUC"));
								item.setMtofobunita(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_FOBUNITARIO")));
								item.setMtoajusunita(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_AJUUNITARIO")));
								//item.setAnnfabrica((java.lang.String) itemFactura.get("ANN_FABRICACION"));
								log.debug("-->itemFactura.ANN_FABRICACION: " + itemFactura.get("ANN_FABRICACION"));
								/*RIN-13*/
								item.setAnnfabrica(itemFactura.get("ANN_FABRICACION") != null ? itemFactura.get("ANN_FABRICACION").toString() : null);
								log.debug("-->item.getAnnfabrica(): " + item.getAnnfabrica());
								if(item.getAnnfabrica() != null && item.getAnnfabrica().equals("0")){
									item.setAnnfabrica(null);
								}
								/*RIN-13*/
								item.setCodestamer((java.lang.String) itemFactura.get("COD_ESTMERC"));
								item.setIndsoftware((java.lang.String) itemFactura.get("IND_SOFTWARE"));
								//si es que el indicador de software es null entonces se setea con una cadena vacia... asi lo requieren los servicios de validacion del orquestador
								if (item.getIndsoftware() == null) {
									//reemplazamos el null por una cadena vacia
									item.setIndsoftware("");
								}
								/*RIN-13*/
								/*if(item.getIndsoftware() != null && item.getIndsoftware().trim().equals("")){
                	item.setIndsoftware(null);
                }*/
								/*RIN-13*/
								item.setIndvarios((java.lang.String) itemFactura.get("IND_OTROS"));//JENCISO NO EXISTE ESTE CAMPO VERIFICAR
								/*RIN-13*/
								if(item.getIndvarios() != null && item.getIndvarios().trim().equals("")){
									item.setIndvarios(null);
								}
								/*RIN-13*/
								item.setMtofobitem(SunatNumberUtils.toBigDecimal(itemFactura.get("MTO_FOBITEM")));


								//amancilla 
								List<Map> lstSeriesItem = null;
								if(itemFactura.containsKey("lstSeriesItem" + sufijo)){
									lstSeriesItem = (List<Map>) itemFactura.get("lstSeriesItem" + sufijo);//jenciso se cambia al map correcto
								}else if (mapinput.containsKey("lstSeriesItemActual")){                	
									lstSeriesItem = (List<Map>) mapinput.get("lstSeriesItemActual"); 
									//pase42 mol               	
									lstSeriesItem = filtrarSeriesItemXItem(lstSeriesItem,item.getNumsecitem(),item.getNumsecfact());
								}
								if (!CollectionUtils.isEmpty(lstSeriesItem))
								{
									Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();
									item.setListSerieItems(listSerieItems);

									for (Map mapSerieItem : lstSeriesItem)
									{

										//SAU20153D211000525
										if(Constantes.IND_ELIMINADO.equals(mapSerieItem.get("IND_DEL"))){
											continue;  
										}

										log.debug("-->mapSerieItem.CNT_MERC: " + mapSerieItem.get("CNT_MERC"));
										DatoSerieItem serieItem = new DatoSerieItem();
										serieItem.setCant_mercd(SunatNumberUtils.toBigDecimal(mapSerieItem.get("CNT_MERC")));
										serieItem.setNumserie(SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECSERIE")));
										serieItem.setMtofobitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_FOB")));
										serieItem.setMtoajuitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_AJUSTE")));

										serieItem.setPadre(item);
										listSerieItems.add(serieItem);
									}
									//jenciso Inicio agregar seriesItems que fueron generados al a�adir una serie
									if(!CollectionUtils.isEmpty(lstSeriesItemActual)){

										for(Map<String,Object> mapSerieItem : lstSeriesItemActual){

											//SAU20153D211000525
											if(Constantes.IND_ELIMINADO.equals(mapSerieItem.get("IND_DEL"))){
												continue;  
											}

											//verificamos que no este cargado en listSerieItems para el item correspondiente
											Integer numSecProv = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECPROVE"));
											Integer numSecfact = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECFACT"));
											Integer numSecItem = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECITEM"));

											if(item.getNumsecprove().equals(numSecProv) && item.getNumsecfact().equals(numSecfact) && item.getNumsecitem().equals(numSecItem)){
												if(!existeSerieItemInList(listSerieItems, mapSerieItem)){

													DatoSerieItem serieItem = new DatoSerieItem();
													serieItem.setCant_mercd(SunatNumberUtils.toBigDecimal(mapSerieItem.get("CNT_MERC")));
													serieItem.setNumserie(SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECSERIE")));
													serieItem.setMtofobitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_FOB")));
													serieItem.setMtoajuitser(SunatNumberUtils.toBigDecimal(mapSerieItem.get("MTO_AJUSTE")));

													serieItem.setPadre(item);
													listSerieItems.add(serieItem);
												}
											}
										}
									}
									//jenciso Fin
								}
							}
						}

						//RIN13
						factura.setCnttotitems(cantidadItemFactura);
					}
				}

				Map mapCondicionTransa = (Map) formBProveedor.get("mapCondicionTransa" + sufijo);
				if (!CollectionUtils.isEmpty(mapCondicionTransa))
				{
					Elementos<DatoCondTransaccion> listCondTransacciones = new Elementos<DatoCondTransaccion>();
					dav.setListCondTransacciones(listCondTransacciones);

					Set keySetCondicionTransa = mapCondicionTransa.keySet();
					for (Object key : keySetCondicionTransa)
					{
						DatoCondTransaccion condTransaccion = new DatoCondTransaccion();
						condTransaccion.setCodindcondtra((java.lang.String) key); // COD_INDTRANSACCION
						condTransaccion.setIndcondtra((java.lang.String) mapCondicionTransa.get(key)); // IND_TRANSACCION
						listCondTransacciones.add(condTransaccion);
					}
				}
			}
		}

		
        //PAS20181U220200069 - mtorralba 20190301 - INICIO  - Para cargar lista de observaciones en la declaracion 
		Elementos<Observacion> listaObservaciones = new Elementos<Observacion>();
		if( mapCabDeclara.get("OBS_OBS")!=null ) { 
			Observacion observa = new Observacion();
			observa.setCodtipobserva("01");
			observa.setNumcorredoc(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
			observa.setNumsecitem(1);
			observa.setObsdeclaracion(mapCabDeclara.get("OBS_OBS").toString());
			listaObservaciones.add(observa);
		}
		if( mapCabDeclara.get("OBS_PECO")!=null ) { 
			Observacion observa = new Observacion();
			observa.setCodtipobserva("06");
			observa.setNumcorredoc(Long.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
			observa.setNumsecitem(Integer.valueOf(mapCabDeclara.get("SECOBS_PECO").toString())); 
			observa.setObsdeclaracion(mapCabDeclara.get("OBS_PECO").toString());
			listaObservaciones.add(observa);
		}
		
		declaracion.getDua().setListObservaciones(listaObservaciones);
        //PAS20181U220200069 - mtorralba 20190301 - FIN 
		
		
		return declaracion;
	}

	private List<Map> filtrarComproBPagoXProveedor(List<Map> lstComproBPago,Integer numcodsecprove) {

		List rspta = new ArrayList();
		String sectItem;
		for (Map item : lstComproBPago) {
			sectItem = item.get("NUM_SECPROVE").toString().trim();
			if (sectItem.equals(numcodsecprove.toString())) {
				rspta.add(item);									
			}
		}

		return rspta;	

	}

	private List<Map> filtrarItemFacturaXfactura(List<Map> lstItemFactura, Integer numsecfactu) {

		List rspta = new ArrayList();
		String sectItem;
		for (Map item : lstItemFactura) {
			sectItem = item.get("NUM_SECFACT").toString().trim();
			if (sectItem.equals(numsecfactu.toString())) {
				rspta.add(item);									
			}
		}

		return rspta;
	}
	// Ini RIN 10
	private List<Map<String,Object>> filtrarFacturaSucecivaXfactura(List<Map<String,Object>> lstItemFactura, Integer numsecfactu) {

		List rspta = new ArrayList();
		String sectItem;
		for (Map item : lstItemFactura) {
			sectItem = item.get("NUM_SECFACT").toString().trim();
			if (sectItem.equals(numsecfactu.toString())) {
				rspta.add(item);
			}
		}

		return rspta;
	}
	// Fin RIN 10
	//pase42 mol
	private List filtrarSeriesItemXItem(List<Map> lstSerieItem, Integer num_secitem, Integer num_secfact) {

		List rspta = new ArrayList();
		String sectItem;
		String secfact;
		for (Map item : lstSerieItem) {
			sectItem = item.get("NUM_SECITEM").toString().trim();
			secfact = item.get("NUM_SECFACT").toString().trim();
			if (sectItem.equals(num_secitem.toString()) && secfact.equals(num_secfact.toString()) ) {
				rspta.add(item);									
			}
		}

		return rspta;
	}
	private boolean existeSerieItemInList(Elementos<DatoSerieItem> listSerieItems, Map<String,Object> mapSerieItem ){
		boolean existe = false;
		Integer numeSerie = SunatNumberUtils.toInteger(mapSerieItem.get("NUM_SECSERIE"));
		for(DatoSerieItem serieItem : listSerieItems){
			if(serieItem.getNumserie().equals(numeSerie)){
				existe = true;
				break;
			}
		}

		return existe;		  

	}

	/**
	 * Adds the otro doc soporte.
	 *
	 * @param declaracion the declaracion
	 * @param lstDocAutAsociado the lst doc aut asociado
	 */
	private void addOtroDocSoporte(Declaracion declaracion, List<Map<String, Object>> lstDocAutAsociado, Elementos<DatoOtroDocSoporte> listOtrosDocSoporte) {

		for (Map mapDocAutAsociado : lstDocAutAsociado)
		{
			DatoOtroDocSoporte otroDocSoporte = new DatoOtroDocSoporte();
			otroDocSoporte.setCodtipoproceso((java.lang.String) mapDocAutAsociado.get("COD_TIPOPER"));
			otroDocSoporte.setCodtipodocasoc((java.lang.String) mapDocAutAsociado.get("COD_TIPDOCASO"));

			otroDocSoporte.setAnndocasoc(mapDocAutAsociado.get("ANN_DOC") == null ? "" : mapDocAutAsociado.get("ANN_DOC").toString());
			otroDocSoporte.setNumdocasoc((java.lang.String) mapDocAutAsociado.get("NUM_DOC"));

			if (mapDocAutAsociado.get("FEC_EMIS") != null)
			{
				if (mapDocAutAsociado
						.get("FEC_EMIS")
						.getClass()
						.getName()
						.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					otroDocSoporte.setFecdocasoc(new java.util.Date(((FechaBean) mapDocAutAsociado.get("FEC_EMIS"))
							.getTimestamp()
							.getTime()));
				}
				else
				{
					if (mapDocAutAsociado.get("FEC_EMIS").getClass().getName().equals("java.lang.String"))
					{
						String valorStr = mapDocAutAsociado.get("FEC_EMIS").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							otroDocSoporte.setFecdocasoc(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss")
									.getTimestamp()
									.getTime()));
						}
						else
						{

							if(SunatStringUtils.indexOf(valorStr, "/")!=-1)
							{
								otroDocSoporte.setFecdocasoc(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy")
										.getTimestamp()
										.getTime()));
							}
							else
							{
								otroDocSoporte.setFecdocasoc(Utilidades.toDate(valorStr));
							}


						}
						mapDocAutAsociado.put("FEC_EMIS", otroDocSoporte.getFecdocasoc());
					}
					else
					{
						//Inicio RIN 14
						if (SunatStringUtils.isNumeric(mapDocAutAsociado.get("FEC_EMIS").toString().substring(0,4)))
							otroDocSoporte.setFecdocasoc(SunatDateUtils.getDate(mapDocAutAsociado.get("FEC_EMIS").toString(),"yyyy-MM-dd HH:mm:ss"));
						else 
							//otroDocSoporte.setFecdocasoc(SunatDateUtils.getDate(mapDocAutAsociado.get("FEC_EMIS").toString(),"EEE MMM dd HH:mm:ss zzzz yyyyy"));
							otroDocSoporte.setFecdocasoc(Utilidades.toDate(mapDocAutAsociado.get("FEC_EMIS").toString()));//bug 22303
						//Fin RIN 14
					}
				}
			}
			if (mapDocAutAsociado.get("FEC_VENC") != null)
			{
				if (mapDocAutAsociado
						.get("FEC_VENC")
						.getClass()
						.getName()
						.equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
				{
					otroDocSoporte.setFecvencimiento(new java.util.Date(((FechaBean) mapDocAutAsociado.get("FEC_VENC"))
							.getTimestamp()
							.getTime()));
				}
				else
				{
					if (mapDocAutAsociado.get("FEC_VENC").getClass().getName().equals("java.lang.String"))
					{
						String valorStr = mapDocAutAsociado.get("FEC_VENC").toString();
						if (valorStr.length() > 15 && valorStr.substring(4, 5).equals("-") && valorStr.substring(7, 8).equals("-")
								&& valorStr.substring(13, 14).equals(":"))
						{
							otroDocSoporte.setFecvencimiento(new java.util.Date(new FechaBean(valorStr, "yyyy-MM-dd hh:mm:ss")
									.getTimestamp()
									.getTime()));
						}
						else
						{


							if(SunatStringUtils.indexOf(valorStr, "/")!=-1)
							{
								otroDocSoporte.setFecvencimiento(new java.util.Date(new FechaBean(valorStr, "dd/MM/yyyy")
										.getTimestamp()
										.getTime()));
							}
							else
							{
								otroDocSoporte.setFecvencimiento(Utilidades.toDate(valorStr));
							}

						}
						mapDocAutAsociado.put("FEC_VENC", otroDocSoporte.getFecvencimiento());
					}
					else
					{//pase81
						//Inicio RIN 14 - Se actualiza con la propiedad correcta      	  
						if (SunatStringUtils.isNumeric(mapDocAutAsociado.get("FEC_VENC").toString().substring(0,4)))
							otroDocSoporte.setFecvencimiento(SunatDateUtils.getDate(mapDocAutAsociado.get("FEC_VENC").toString(),"yyyy-MM-dd HH:mm:ss"));
						else {
							//otroDocSoporte.setFecvencimiento(SunatDateUtils.getDate(mapDocAutAsociado.get("FEC_VENC").toString(),"EEE MMM dd HH:mm:ss zzz yyyy"));
							otroDocSoporte.setFecvencimiento(Utilidades.toDate(mapDocAutAsociado.get("FEC_VENC").toString()));//bug 22303
						}

						//Fin RIN 14
					}//pase81
				}
			}
			otroDocSoporte.setDesentidad((java.lang.String) mapDocAutAsociado.get("OBS_OBS"));
			otroDocSoporte.setCodtipoentidad((java.lang.String) mapDocAutAsociado.get("COD_ENTI"));
			otroDocSoporte.setCodtipodocentidad((java.lang.String) mapDocAutAsociado.get("COD_TIPDOC"));
			otroDocSoporte.setCodentidademisora(SunatNumberUtils.toLong(mapDocAutAsociado.get("COD_IDENT")));
			otroDocSoporte.setNumsecdocum(SunatNumberUtils.toInteger(new BigDecimal((mapDocAutAsociado.get("NUM_SECDOC")
					.toString()))));

			otroDocSoporte.setIndicadorEliminado(mapDocAutAsociado.containsKey("IND_DEL") ? new Integer(mapDocAutAsociado
					.get("IND_DEL")
					.toString()) : 0);
			listOtrosDocSoporte.add(otroDocSoporte);
		}
	}

	/**
	 * Transforma lista de documentos asociados contenidos en un mapa en una lista
	 * de DatoDocAutorizante.
	 *
	 * @param lstDocautAsociado lista con los mapas de docAutasociado
	 * @return the elementos
	 */
	public Elementos<DatoDocAutorizante> transformListDocAutorizantesfromMap(List<Map<String, Object>> lstDocautAsociado)
	{
		Elementos<DatoDocAutorizante> ListDocAutorizantes = new Elementos<DatoDocAutorizante>();
		for (Map<String, Object> mapDocautAsociado : lstDocautAsociado)
		{
			// no tomar en cuenta los eliminados
			if (1 == SunatNumberUtils.toInteger(mapDocautAsociado.get("IND_DEL")).intValue())
			{
				continue;
			}
			// tomar en cuenta solo los de tipo COD_TIPOPER = 'P'
			if (!"P".equals(ObjectUtils.toString(mapDocautAsociado.get("COD_TIPOPER"))))
			{
				continue;
			}
			ListDocAutorizantes.add(transformDocAutorizantefromMap(mapDocautAsociado));
		}
		return ListDocAutorizantes;
	}

	/**
	 * Transfroma el map docautAsociado a la clase DatoDocAutorizante.
	 *
	 * @param mapDocautAsociado documento asociado en formato mapa
	 * @return documento asociado como objeto
	 */
	private DatoDocAutorizante transformDocAutorizantefromMap(Map<String, Object> mapDocautAsociado)

	{
		DatoDocAutorizante datoDocAutorizante = new DatoDocAutorizante();

		datoDocAutorizante.setNumsecdocum(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDocautAsociado
				.get("NUM_SECDOC"))));
		datoDocAutorizante.setNumcorredoc(SunatNumberUtils.toLong(mapDocautAsociado.get("NUM_CORREDOC")));
		datoDocAutorizante.setCodtipodocum(ObjectUtils.toString(mapDocautAsociado.get("COD_TIPDOCASO")));
		datoDocAutorizante.setAnndocum(ObjectUtils.toString(mapDocautAsociado.get("ANN_DOC")));
		datoDocAutorizante.setNumdocum(ObjectUtils.toString(mapDocautAsociado.get("NUM_DOC")));
		datoDocAutorizante.setCodentidad(ObjectUtils.toString(mapDocautAsociado.get("COD_ENTI"), null));
		datoDocAutorizante.setDesentidad(ObjectUtils.toString(mapDocautAsociado.get("OBS_OBS"), null));
		datoDocAutorizante.setCodentidademisora(ObjectUtils.toString(mapDocautAsociado.get("COD_IDENT"), null));

		if (mapDocautAsociado.get("FEC_EMIS") != null)
		{
			Object objFechaEmision = mapDocautAsociado.get("FEC_EMIS");
			if (objFechaEmision.getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				datoDocAutorizante.setFecemision(new java.util.Date(((FechaBean) objFechaEmision).getTimestamp().getTime()));
			}
			else
			{
				if (objFechaEmision.getClass().getName().equals("java.lang.String"))
				{
					String valorStr = objFechaEmision.toString();

					datoDocAutorizante.setFecemision(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(valorStr)));

					mapDocautAsociado.put("FEC_EMIS", datoDocAutorizante.getFecemision());
				}
				else
				{
					//Inicio RIN 14 
					if (SunatStringUtils.isNumeric(objFechaEmision.toString().substring(0,4)))
						datoDocAutorizante.setFecemision(SunatDateUtils.getDate(objFechaEmision.toString(),"yyyy-MM-dd HH:mm:ss"));
					else 
						//datoDocAutorizante.setFecemision(SunatDateUtils.getDate(objFechaEmision.toString(),"EEE MMM dd HH:mm:ss zzzz yyyyy"));
						datoDocAutorizante.setFecemision(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(objFechaEmision.toString())));//bug 22303
					//Fin RIN 14 
				}
			}
		}

		if (mapDocautAsociado.get("FEC_VENC") != null)
		{
			Object objFechaVencimiento = mapDocautAsociado.get("FEC_VENC");
			if (objFechaVencimiento.getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean"))
			{
				datoDocAutorizante.setFecvencimiento(new java.util.Date(((FechaBean) objFechaVencimiento)
						.getTimestamp()
						.getTime()));
			}
			else
			{
				if (objFechaVencimiento.getClass().getName().equals("java.lang.String"))
				{
					String valorStr = objFechaVencimiento.toString();
					datoDocAutorizante.setFecvencimiento(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(valorStr)));
					mapDocautAsociado.put("FEC_VENC", datoDocAutorizante.getFecvencimiento());
				}
				else
				{
					//Inicio RIN 14 
					if (SunatStringUtils.isNumeric(objFechaVencimiento.toString().substring(0,4)))
						datoDocAutorizante.setFecvencimiento(SunatDateUtils.getDate(objFechaVencimiento.toString(),"yyyy-MM-dd HH:mm:ss"));
					else
						//datoDocAutorizante.setFecvencimiento(SunatDateUtils.getDate(objFechaVencimiento.toString(),"EEE MMM dd HH:mm:ss zzzz yyyyy"));
						datoDocAutorizante.setFecvencimiento(SunatDateUtils.getDateFromUnknownFormat(ObjectUtils.toString(objFechaVencimiento.toString())));//bug 22303
					//Fin RIN 14 
				}
			}
		}

		datoDocAutorizante.setCodentidad(ObjectUtils.toString(mapDocautAsociado.get("COD_ENTI")));
		datoDocAutorizante.setCodTipoOper(ObjectUtils.toString(mapDocautAsociado.get("COD_TIPOPER"), ""));

		//Inicio RIN 14 - FCO - Agregar los nuevos campos del documento Autorizante
		datoDocAutorizante.setCodsubentidad(ObjectUtils.toString(mapDocautAsociado.get("COD_SUBENTI")));
		datoDocAutorizante.setCodsubtipodocum(ObjectUtils.toString(mapDocautAsociado.get("COD_SUBTIPODOC")));
		datoDocAutorizante.setNroitemdocum(ObjectUtils.toString(mapDocautAsociado.get("NUM_ITEMDOC"), null) == null ? null : Integer.parseInt(mapDocautAsociado.get("NUM_ITEMDOC").toString()));
		//Fin RIN 14 - FCO - Agregar los nuevos campos del documento Autorizante    

		return datoDocAutorizante;
	}


	/**
	 * Transforma lista de documentos asociados contenidos en un mapa en una lista
	 * de DatoDocAutorizante.
	 *
	 * @param lstDetAutorizacion the lst det autorizacion
	 * @param serie the serie
	 * @return the elementos
	 */
	public Elementos<DatoSerieDocSoporte> transformListSerieDocSoporteFromMap(
			List<Map<String, Object>> lstDetAutorizacion,
			final Integer serie)
	{

		// filtramos los eliminados
		Collection<Map> lstDetAutorizacionBySerie = org.apache.commons.collections.CollectionUtils.select(lstDetAutorizacion,new Predicate()
		{
			@Override
			public boolean evaluate(Object objDetAutorizacion)
			{
				Map mapDetAutorizacion = (Map) objDetAutorizacion;
				// no tomar en cuenta los eliminados
				Integer secuenciaSerie = SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECSERIE")));
				boolean isEliminado = (1 == SunatNumberUtils.toInteger(mapDetAutorizacion.get("IND_DEL")).intValue());
				String tipoDocumento = SunatStringUtils.toStringObj(mapDetAutorizacion.get("COD_TIPOPER"));
				return secuenciaSerie.equals(serie) && !isEliminado && !SunatStringUtils.isEqualTo(tipoDocumento,"C"); //diferente de un Certif de Origen, ya que se llena mas adelante
			}
		});

		Elementos<DatoSerieDocSoporte> listDocAutorizantes = new Elementos<DatoSerieDocSoporte>();
		for (Map<String, ?> mapDocautAsociado : lstDetAutorizacionBySerie)
		{
			listDocAutorizantes.add(transformDocAutorizanteFromMap(mapDocautAsociado));
		}
		return listDocAutorizantes;
	}

	/**
	 * Transforma el map docautAsociado a la clase DatoDocAutorizante.
	 *
	 * @param mapDetAutorizacion the map det autorizacion
	 * @return documento asociado como objeto
	 */
	private DatoSerieDocSoporte transformDocAutorizanteFromMap(
			Map<String, ?> mapDetAutorizacion)
	{
		DatoSerieDocSoporte datoSerieDocSoporte = new DatoSerieDocSoporte();

		datoSerieDocSoporte.setNumcorredoc(SunatNumberUtils.toLong(mapDetAutorizacion.get("NUM_CORREDOC")));
		datoSerieDocSoporte.setNumserie(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECSERIE"))));
		datoSerieDocSoporte.setNumiddocsoporte(SunatNumberUtils.toInteger(ObjectUtils.toString(mapDetAutorizacion.get("NUM_SECDOC"))));
		datoSerieDocSoporte.setCodtipooper(ObjectUtils.toString(mapDetAutorizacion.get("COD_TIPOPER")));
		// verificar para que se usa CAB_CERTIORIGEN segun la consulta de documentos
		// autorizantes
		String codTipoDocSoporte = ObjectUtils.toString(mapDetAutorizacion.get("COD_TIPOPER"), "");
		if (codTipoDocSoporte.equals("P"))
		{
			codTipoDocSoporte = "4";
		}
		else
		{
			codTipoDocSoporte = "1";
		}
		datoSerieDocSoporte.setCodtipodocsoporte(codTipoDocSoporte);

		return datoSerieDocSoporte;
	}

	private Object getObjectFromMap(Map<String,Object> map, String key){
		Object object = null ;
		if(map.get(key) != null){
			object = map.get(key);
		}else if(map.get(key.toLowerCase())!=null){
			object = map.get(key.toLowerCase());
		}else if (map.get(key.toUpperCase())!=null){
			object = map.get(key.toUpperCase());
		}
		return object;

	}
	/*RIN13INSI*/
	private Object  getObjectFromMapEspacio(Map<String,Object> map, String key){
		Object object = null ;if ( map.get(key)!=null){
			if(map.get(key).equals(" ")){ 
				object=map.get(key).toString().trim();
			}
			else{
				object=map.get(key);
			}	
		}
		return  object;
	}

	/*INICIO P21-P22*/
	private Map<String, Object> getPuertoFechaOrigen(List<Map<String, Object>> lstDetAutorizacion , List<Map<String, Object>> lstCabCertiOrigen, String numsecserie)
	{   Map<String, Object> params = new HashMap<String, Object>();      
	if(lstDetAutorizacion!=null){
		for (Map item : lstDetAutorizacion ) {     
			//para evitar la comparacion de tipo de campo distintos  pase peru -corea	  
			if (item.get("NUM_SECSERIE").toString().equals(numsecserie.toString())  && (item.get("COD_TIPOPER").toString().equals("C")))
			{
				//region    [amancillaa] PAS20165E220200026
				if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstCabCertiOrigen)) {
					for (Map itemCertiOrigen : lstCabCertiOrigen) {
						if ((itemCertiOrigen.get("NUM_SECDOC") != null && item.get("NUM_SECDOC")!= null) && 
								SunatStringUtils.isEqualTo(itemCertiOrigen.get("NUM_SECDOC").toString(), item.get("NUM_SECDOC").toString())){
							params.put("COD_PTOEMBORIGEN", SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(itemCertiOrigen.get("COD_PTOEMBORIGEN")))); 
							//setear cuando la fec_emborigen sea date 
							if(itemCertiOrigen.get("FEC_EMBORIGEN") instanceof java.util.Date){
								params.put("FEC_EMBORIGEN",SunatDateUtils.getDateFromUnknownFormat(itemCertiOrigen.get("FEC_EMBORIGEN").toString())); 						
							}else{
								params.put("FEC_EMBORIGEN", SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(itemCertiOrigen.get("FEC_EMBORIGEN"))));
							}
							break;

						}        					
					}  
				}
				//endregion [amancillaa] PAS20165E220200026

				break;
			}

		}
	}
	return params;
	}



	private void setPuertoFechaOrigen(Map<String, Object> paramsPuertoFechaOrigen , DatoDocTransporte docTrans)
	{
/*INICIO-P34 PAS20165E220200126 AFMA*/
//solo debe setear si existe C.O si no encuentra no chancha el que ya existe
		if(CollectionUtils.isEmpty(paramsPuertoFechaOrigen)){return;}
/*FIN-P34 PAS20165E220200126 AFMA*/
		docTrans.setCodpuertoorg(ObjectUtils.toString(paramsPuertoFechaOrigen.get("COD_PTOEMBORIGEN"), null)); 
		if (paramsPuertoFechaOrigen.get("FEC_EMBORIGEN")!=null){

			if (paramsPuertoFechaOrigen.get("FEC_EMBORIGEN").getClass().getName().equals("pe.gob.sunat.framework.spring.util.date.FechaBean")){     	    	
				docTrans.setFecembarqueorg(new java.util.Date(((FechaBean) paramsPuertoFechaOrigen.get("FEC_EMBORIGEN")).getTimestamp().getTime())); 				
			}
			else if (paramsPuertoFechaOrigen.get("FEC_EMBORIGEN") instanceof java.util.Date){
				docTrans.setFecembarqueorg(SunatDateUtils.getDateFromUnknownFormat(paramsPuertoFechaOrigen.get("FEC_EMBORIGEN").toString()));
			}
			else {
				docTrans.setFecembarqueorg(SunatDateUtils.getDateFromUnknownFormat(paramsPuertoFechaOrigen.get("FEC_EMBORIGEN").toString()));     	    
			}
		}
		else   {   docTrans.setFecembarqueorg(null); 
		}
	}



}