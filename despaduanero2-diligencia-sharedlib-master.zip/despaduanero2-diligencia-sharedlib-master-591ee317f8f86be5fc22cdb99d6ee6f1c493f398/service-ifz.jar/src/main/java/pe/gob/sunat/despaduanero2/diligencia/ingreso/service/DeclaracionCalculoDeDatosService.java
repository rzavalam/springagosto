package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFleteYPesoPorDocTransporteBean;


/**
 * Esta Clase contiene la logica de calculo de los datos de la declaracion,
 * serie, formato A y B
 *
 * @author amancillaa
 * @version 1.0 26/02/2013
 */
@SuppressWarnings({ "rawtypes" })
public interface DeclaracionCalculoDeDatosService
{

  /**
   * Calcular mto seguro de la serie.
   *
   * @param codTipSegSerie
   *          [String] cod tip seg serie
   * @param mtoFobDolSerie
   *          [BigDecimal] mto fob dol serie
   * @param mtoAjusteSerie
   *          [BigDecimal] mto ajuste serie
   * @param numPartNandiSerie
   *          [Long] num part nandi serie
   * @param fechaVigenciaPartida
   *          [Date] fecha vigencia partida
   * @param mtoTotFobDolDua
   *          [BigDecimal] mto tot fob dol dua
   * @param mtoTotSegDolDua
   *          [BigDecimal] mto tot seg dol dua
   * @return [BigDecimal] big decimal
   * @author amancillaa
   * @version 1.0
   */
  public BigDecimal calcularMtoSeguroDeLaSerie(String codTipSegSerie,
                                               BigDecimal mtoFobDolSerie,
                                               BigDecimal mtoAjusteSerie,
                                               Long numPartNandiSerie,
                                               Date fechaVigenciaPartida,
                                               BigDecimal mtoTotFobDolDua,
                                               BigDecimal mtoTotSegDolDua);

  /**
   * Calcular mto seguro de la serie tipo2y3.
   *
   * @param mtoFobDolSerie
   *          the mto fob dol serie
   * @param mtoAjusteSerie
   *          the mto ajuste serie
   * @param numPartNandiSerie
   *          the num part nandi serie
   * @param fechaVigenciaPartida
   *          the fecha vigencia (fecha de numeracion Fecdeclaracion) si esta
   *          vacio se considera la fecha actual
   * @return newMtoSeguro
   *
   * @author amancillaa
   * @version 1.0
   */
  public BigDecimal calcularMtoSeguroDeLaSerieTipo1(BigDecimal mtoFobDolSerie,
                                                    BigDecimal mtoAjusteSerie,
                                                    Long numPartNandiSerie,
                                                    Date fechaVigenciaPartida);

  /**
   * Calcular mto seguro de la serie tipo1.
   *
   * @param mtoFobDolSerie
   *          [BigDecimal] mto fob dol serie
   * @param mtoAjusteSerie
   *          [BigDecimal] mto ajuste serie
   * @param mtoTotFobDolDua
   *          [BigDecimal] mto tot fob dol dua
   * @param mtoTotSegDolDua
   *          [BigDecimal] mto tot seg dol dua
   * @return [BigDecimal] big decimal
   *
   * @author amancillaa
   * @version 1.0
   */
  public BigDecimal calcularMtoSeguroDeLaSerieTipo2y3(BigDecimal mtoFobDolSerie,
                                                      BigDecimal mtoAjusteSerie,
                                                      BigDecimal mtoTotFobDolDua,
                                                      BigDecimal mtoTotSegDolDua);

  /**
   * prorratea el Monto mtoSeguroProrratear en las series.
   *
   * @param mtoSeguroProrratear
   *          monto a prorratear generalmente es el MTO_TOTSEGDOL de la
   *          declaracion.
   * @param mtoTotalFOBDolDeLaDeclaracion
   *          [BigDecimal] mto total fob dol de la declaracion
   * @param fechaVigenciaPartida
   *          [Date] fecha vigencia partida
   * @param lstSeries
   *          a aplicar el prorrateo
   * @return List listado de las series con los datos actualizados
   *
   * @author amancillaa
   * @version 1.0
   */
  public List prorratearMtoSeguroEnLasSeries(BigDecimal mtoSeguroProrratear,
                                             BigDecimal mtoTotalFOBDolDeLaDeclaracion,
                                             Date fechaVigenciaPartida,
                                             List lstSeries);

  /**
   * prorratea el Monto mtoSeguroProrratear desde itemfactura.
   *
   * @param lstSeries
   *          a aplicar el prorrateo
   * @param fechaVigenciaPartida
   *          [Date] fecha vigencia partida
   * @return List listado de las series con los datos actualizados
   *
   * @author amancillaa
   * @version 1.0
   */
  public List<Map<String, Object>> prorratearMtoSeguroDesdeItemsFactura(List lstSeries,
                                                                        Date fechaVigenciaPartida);

  /**
   * Prorratear flete tomando como monto a prorratear lo registrado por el
   * usuario.
   *
   * @param lstDetDeclara
   *          the lst det declara
   * @param lstSumaFleteYPesoPorDocTransporte
   *          the lst suma flete y peso por doc transporte
   * @return the list
   *
   * @author amancillaa
   * @version 1.0
   */
  public List prorratearFlete(List lstDetDeclara,
                              List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte);

  /**
   * Prorratear flete tomando como base de prorrateo los datos de la serie.
   *
   * @param lstDetDeclara
   *          the lst det declara
   * @return the list
   *
   * @throws Exception
   *           the exception
   * @author amancillaa
   * @version 1.0
   */
  public List prorratearFlete(List lstDetDeclara) throws Exception;

  /**
   * agrupa por BL unicos de tipo de prorrateo 2 y 3 si todas las series tiene
   * tipo de prorrateo 1, entonces devuelve List vacia.
   *
   * @param lstDetDeclara
   *          [List<Map>] lst det declara
   * @return [List<SumaFleteYPesoPorDocTransporteBean>] list
   * @throws Exception
   *           the exception
   * @author amancillaa
   * @version 1.0
   */
  public List<SumaFleteYPesoPorDocTransporteBean>
      obtenerDocTransporteAProrratear(List<Map> lstDetDeclara) throws Exception;

  /**
   * Obtener doc transporte a prorratear desde series. a diferencia
   * obtenerDocTransporteAProrratear que ingresa los valores el usuario en esta
   * se toma como base lo ingresado en la serie
   *
   * @param lstDetDeclara
   *          the lst det declara
   * @return the list
   * @throws Exception
   *           the exception
   * @author amancillaa
   * @version 1.0
   */
  public List<Map<String, Object>> obtenerDocTransporteAProrratearDesdeSeries(List<Map> lstDetDeclara) throws Exception;


  /**
   * Calcular mto valor aduana.
   *
   * @param mto_fobdol
   *          [BigDecimal] mto_fobdol
   * @param mto_fletedol
   *          [BigDecimal] mto_fletedol
   * @param mto_segdol
   *          [BigDecimal] mto_segdol
   * @param mto_ajuste
   *          [BigDecimal] mto_ajuste
   * @param mto_ajuste_otr
   *          [BigDecimal] mto_ajuste_otr
   * @return [BigDecimal] big decimal
   * @author amancillaa
   * @version 1.0
   */
  public BigDecimal calcularMtoValorAduana(BigDecimal mto_fobdol,
                                           BigDecimal mto_fletedol,
                                           BigDecimal mto_segdol,
                                           BigDecimal mto_ajuste,
                                           BigDecimal mto_ajuste_otr);

}
