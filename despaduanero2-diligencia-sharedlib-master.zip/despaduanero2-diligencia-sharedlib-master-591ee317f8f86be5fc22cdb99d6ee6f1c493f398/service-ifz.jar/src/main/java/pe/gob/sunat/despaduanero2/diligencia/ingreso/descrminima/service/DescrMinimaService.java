package pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service;
 

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
public interface DescrMinimaService {
	
	  public ModelAbstract obtenerDescrMinima(long numCorreDoc, int numSecItem);
	  
	  public ModelAbstract obtenerDescrMinimaParaJavascript(long numCorreDoc, int numSecItem);
	  public  List obtenerItemDescrMinima(long numCorreDoc, int numSecItem);
	  //rtineo mejoras se sobrecarga la funcion
	  public  List obtenerItemDescrMinima(long numCorreDoc, int numSecItem, Map<String, Object> variablesIngreso);
}
