package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * <p>Title: DiligenciaSimplificadaService</p>
 * <p>Description: Interface de Servicio para la Diligencia Simplificada</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public interface DiligenciaSimplificadaService {

	/**
	 * Verifica si es una diligenci simplificada (mayor a 200 series) o no 
	 * @param numeroCorrelativo Long
	 * @return
	 * @author gbecerrav
	 */
	public boolean isDiligenciaSimplificada(Long numeroCorrelativo) throws ServiceException;
	
	/**
	 * Registra diligencia de despacho con proceso simplificado
	 * @param diligencia Diligencia de Despacho Simplificada
	 * @param indicadorAnticipado Si es que tiene indicador dua despacho anticipado
	 * @return
	 * @author gbecerrav
	 */
	public void grabarDiligenciaSimplificada(Diligencia diligencia, boolean indicadorAnticipado) throws ServiceException;
	
	/**
	 * Registra diligencia de conclusi�n de despacho con proceso simplificado
	 * @param diligencia Diligencia de Conclusion de Despacho Simplificada
	 * @return
	 * @author gbecerrav
	 */
	public void grabarDiligenciaConclusionSimplificada(Diligencia diligencia) throws ServiceException;
	
	/**
	 * PAS20165E220200032
	 * Registra el indicador 31 para la diligencia de post levante con proceso simplificado
	 * @param numCorredoc
	 * @param fechaDeclaracion
	 */
	
	public void grabarIndicadorPostLevante(String numCorredoc, Date fechaDeclaracion) ;

	public void grabarDiligenciaSimplificada(Diligencia diligencia, boolean indicadorAnticipado, boolean indicadorGrabarPostLevante, Map<String, Object> declaracion) throws ServiceException; //inicio gmontoya Pase 32

}
