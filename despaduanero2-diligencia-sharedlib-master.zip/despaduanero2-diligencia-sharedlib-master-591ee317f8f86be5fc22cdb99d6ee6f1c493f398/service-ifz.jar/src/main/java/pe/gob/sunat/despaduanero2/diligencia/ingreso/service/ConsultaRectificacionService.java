package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.List;

import pe.gob.sunat.despaduanero2.bean.DatoRectificado;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;


public interface ConsultaRectificacionService
{

  /**
   * Consulta las rectificacioens realizadas a la DUA
   *
   * @param uniqueKeyDua
   *          parametros de la busqueda
   * @return lista de rectificaciones realizadas a la dua
   */
  public List<SolicitudRectifica> consultaDiligenciaRectificacion(Long uniqueKeyDua);

  /**
   * Busca los datos rectificados duarante la diligencia de rectificacion (se
   * buscan en el det_ofirecti)
   *
   * @param diligencia
   *          la diligencia debe de tener como minimo el numero correlativo de
   *          la solicitud
   * @return
   */
  public List<DatoRectificado> consultaDatosRectificados(Diligencia diligencia);
  
  //Lmvr- inicio - Complemento de rectificacion
  public List<DatoRectificado> consultaDatosRectificacionAutomatica(Long numCorredoc);
  //Lmvr- fin - Complemento de rectificacion
  /**
   * Busaca una diligencia de acuerdo al num_corredoc de la dua y el
   * num_corredoc de la solicitud
   *
   * @param diligencia
   * @return
   */
  public Diligencia consultaDiligencia(Diligencia diligencia);

}
