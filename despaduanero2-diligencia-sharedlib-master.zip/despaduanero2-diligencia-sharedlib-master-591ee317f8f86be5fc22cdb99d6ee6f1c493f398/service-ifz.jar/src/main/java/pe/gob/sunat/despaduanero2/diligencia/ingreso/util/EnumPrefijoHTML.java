package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;

/**
 * Enumerado que contiene los prefijos html que se usan en la parte vista.
 * @author SUNAT - 2011
 *
 */
public enum EnumPrefijoHTML {

    INPUT_TEXT("txt_"),
    INPUT_HIDDEN("hdn_"),
    INPUT_CHECKBOX("cbx_"),
    INPUT_TEXT_AREA("ta_"),
    INPUT_RADIO("ra_"),
    INPUT_SELECT("sel_");

    /**
     * Contiene el texto del prefijo
     */
    private String prefijo;


    EnumPrefijoHTML(String prefijo) {
        this.prefijo = prefijo;
    }


    public String getPrefijo() {
        return prefijo;
    }


    public void setPrefijo(String prefijo) {
        this.prefijo = prefijo;
    }


}
