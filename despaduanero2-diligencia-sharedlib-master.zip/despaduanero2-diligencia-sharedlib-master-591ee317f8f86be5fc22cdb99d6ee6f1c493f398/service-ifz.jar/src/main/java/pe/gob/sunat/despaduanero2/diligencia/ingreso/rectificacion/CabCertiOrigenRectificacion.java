package pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion;


import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.dao.DataIntegrityViolationException;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.security.Hash;


public class CabCertiOrigenRectificacion extends RectificacionAbstract implements Serializable
{

  /**
	 * 
	 */
  private static final long   serialVersionUID                         = 1289816017220658324L;

  private static final String NOMBRE_LISTA_ORIGINAL                    = "lstCabCertiOrigen";

  private static final String NOMBRE_LISTA_RESULTANTE                  = NOMBRE_LISTA_ORIGINAL + "Actual";

  private static final String NOMBRE_LISTA_RESULTANTE_PROVEEDOR        = FormBProveedorRectificacion.NOMBRE_LISTA_RESULTANTE;

  private static final String NOMBRE_LISTA_RESULTANTE_SERIE_ITEM       = SeriesItemRectificacion.NOMBRE_LISTA_RESULTANTE;

  private static final String NOMBRE_LISTA_RESULTANTE_DET_AUTORIZACION = DetAutorizacionRectificacion.NOMBRE_LISTA_RESULTANTE;

  private static final String NOMBRE_LISTA_RESULTANTE_PARTICIPANTE     = ParticipanteRectificacion.NOMBRE_LISTA_RESULTANTE;

  private static final String CODIGO_TIPO_OPERACION                    = "C";

  private static String[]     FORMAT_DATES                             = new String[]
                                                                       { "dd/MM/yyyy", "dd/MM/yyyy HH:mm:ss",
      "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd"                             };

  private CabCertiOrigenDAO   cabCertiOrigenDAO;

  private DocAutAsociadoDAO   docAutAsociadoDAO;

  //rtineo mejoras, grabacion en baqtch
  private CabCertiOrigenBatchDAO cabCertiOrigenBatchDAO;
  private DocAutAsociadoBatchDAO docAutAsociadoBatchDAO;

  public CabCertiOrigenRectificacion()
  {
    mapClave = new HashMap<String, Object>();
    mapClave.put("NUM_CORREDOC", "NUM_CORREDOC");
    mapClave.put("NUM_SECDOC", "NUM_SECDOC");
    mapClave.put("COD_TIPOPER", "COD_TIPOPER");
  }

  protected String getNombreListaOriginal()
  {
    return NOMBRE_LISTA_ORIGINAL;
  }

  protected String getNombreListaResultante()
  {
    return NOMBRE_LISTA_RESULTANTE;
  }

  protected String getCodTablaRectificacion()
  {
    return Constantes.COD_TABLA_CAB_CERTIORIGEN;
  }

  @Override
  protected Map<String, Object> getDatosInicialesRectifacion(
      Map<String, Object> mapResultado,
      Map<String, Object> mapValores)
  {
    mapResultado.put(getNombreListaOriginal(), getTablaBD(mapValores));
    return mapResultado;
  }

  /**
   * Si se verifica un cambio en proveedor en participante DOC entonces se
   * actualiza el nombre de provedor en cab_certifiado
   * 
   * @param mapResultado
   */
  private void actualizarNombreProveedor(Map mapResultado)
  {
    if (mapResultado.get(NOMBRE_LISTA_RESULTANTE_PARTICIPANTE) != null)
    {
      List<Map<String, Object>> lstDatosParticipanteRectificado = (List<Map<String, Object>>) mapResultado
          .get(NOMBRE_LISTA_RESULTANTE_PARTICIPANTE);

      List<Map<String, Object>> lstCabCetiOrigenModificarProveedor = new ArrayList<Map<String, Object>>();

      for (Map<String, Object> participante : lstDatosParticipanteRectificado)
      {
        // si se rectifico el participante 93 (proveedor) el campo
        // NOM_RAZONSOCIAL entonces se actualiza el campo NOM_PROVE en la tabla
        // CAB_CERTIORIGEN
        if (("93".equals(participante.get("COD_TIPPARTIC")) && (StringUtils.isNotBlank((String) participante
            .get("NOM_RAZONSOCIAL")))))
        {
          // buscamos las facturas a la que pertenece el proveedor actual
          Map<String, Object> cabCertiOrigenProveTmp = new HashMap<String, Object>();
          // FORMBPROVEEDOR
          List<Map<String, Object>> lstFormBproveedor = (List<Map<String, Object>>) mapResultado
              .get(NOMBRE_LISTA_RESULTANTE_PROVEEDOR);
          for (Map<String, Object> proveedor : lstFormBproveedor)
          {
            boolean encontrado = ObjectUtils.toString(proveedor.get("NUM_CORREDOC"), "").equals(
                ObjectUtils.toString(participante.get("NUM_CORREDOC"), null))
                && ObjectUtils.toString(proveedor.get("NUM_CODSECPROVE"), "").equals(
                    ObjectUtils.toString(participante.get("NUM_SECPARTIC"), null));
            encontrado = encontrado && !INDICADOR_ELIMINAR_REGISTRO.equals(proveedor.get("indica"));
            if (encontrado)
            {
              cabCertiOrigenProveTmp.put("NUM_CORREDOC", participante.get("NUM_CORREDOC"));
              cabCertiOrigenProveTmp.put("NOM_PROVE", participante.get("NOM_RAZONSOCIAL"));
              cabCertiOrigenProveTmp.put("NUM_SECPROVE", proveedor.get("NUM_SECPROVE"));
              cabCertiOrigenProveTmp.put("indica", participante.get("indica"));
              break;
            }
          }

          List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) mapResultado
              .get(NOMBRE_LISTA_RESULTANTE_SERIE_ITEM);

          for (Map<String, Object> serieItem : lstSeriesItem)
          {
            boolean encontrado = ObjectUtils.toString(serieItem.get("NUM_CORREDOC"), "").equals(
                ObjectUtils.toString(participante.get("NUM_CORREDOC"), null))
                && ObjectUtils.toString(serieItem.get("NUM_SECPROVE"), "").equals(
                    ObjectUtils.toString(cabCertiOrigenProveTmp.get("NUM_SECPROVE"), null));
            encontrado = encontrado && !INDICADOR_ELIMINAR_REGISTRO.equals(serieItem.get("indica"));
            if (encontrado)
            {
              List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapResultado
                  .get(NOMBRE_LISTA_RESULTANTE_DET_AUTORIZACION);
              for (Map<String, Object> detAutorizacion : lstDetAutorizacion)
              {
                boolean serieEncontrada = ObjectUtils.toString(serieItem.get("NUM_CORREDOC"), "").equals(
                    ObjectUtils.toString(detAutorizacion.get("NUM_CORREDOC"), null))
                    && ObjectUtils.toString(serieItem.get("NUM_SECSERIE"), "").equals(
                        ObjectUtils.toString(detAutorizacion.get("NUM_SECSERIE"), null));
                serieEncontrada = serieEncontrada && "C".equals(detAutorizacion.get("COD_TIPOPER"));
                serieEncontrada = serieEncontrada && !INDICADOR_ELIMINAR_REGISTRO.equals(serieItem.get("indica"));
                if (serieEncontrada)
                {
                  cabCertiOrigenProveTmp.put("NUM_SECDOC", detAutorizacion.get("NUM_SECDOC"));
                  cabCertiOrigenProveTmp.put("COD_TIPOPER", detAutorizacion.get("COD_TIPOPER"));
                  lstCabCetiOrigenModificarProveedor.add(new HashMap<String, Object>(cabCertiOrigenProveTmp));
                }
              }
            }
          }

          //
        }
      }

      for (Map<String, Object> certiOrigenCambiar : lstCabCetiOrigenModificarProveedor)
      {
        List<Map<String, Object>> newCertiOrigenResultante = (List<Map<String, Object>>) mapResultado
            .get(NOMBRE_LISTA_RESULTANTE);

        Iterator<Map<String, Object>> iterNewCertiOrigenResultante = newCertiOrigenResultante.iterator();

        while (iterNewCertiOrigenResultante.hasNext())
        {
          Map<String, Object> mapCertiorigen = iterNewCertiOrigenResultante.next();
          boolean encontrado = ObjectUtils.toString(mapCertiorigen.get("NUM_CORREDOC"), "").equals(
              ObjectUtils.toString(certiOrigenCambiar.get("NUM_CORREDOC"), null));
          encontrado = encontrado
              && ObjectUtils.toString(mapCertiorigen.get("NUM_SECDOC"), "").equals(
                  ObjectUtils.toString(certiOrigenCambiar.get("NUM_SECDOC"), null));
          encontrado = encontrado
              && ObjectUtils.toString(mapCertiorigen.get("COD_TIPOPER"), "").equals(
                  ObjectUtils.toString(certiOrigenCambiar.get("COD_TIPOPER"), null));
          encontrado = encontrado && !INDICADOR_ELIMINAR_REGISTRO.equals(mapCertiorigen.get("indica"));
          if (encontrado)
          {
            mapCertiorigen.put("NOM_PROVE", certiOrigenCambiar.get("NOM_PROVE"));
            if (mapCertiorigen.get("indica") == null)
            {
              mapCertiorigen.put("indica", mapCertiorigen.get("indica"));

            }
          }

        }
      }
    }

  }

  // inicio gmontoya diligencia 2012
  @SuppressWarnings("unchecked")
  @Override
  public int grabarRectificacion(String numCorredocSol, Map<String, Object> mapDatos)
  {
    int cont = 0;
    //rtineo mejoras, grabacion en batch
    String codTransaccion = (mapDatos.get("codTransaccion")!=null)?mapDatos.get("codTransaccion").toString():"";
    //rtineo mejoras, fin
    Map<String, Object> mapDiferenciaGrabar;
    actualizarNombreProveedor(mapDatos);
    if (mapDatos.get(getNombreListaResultante()) != null)
    {
      cont = 0;

      for (Map<String, Object> itemNew : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaResultante()))
      {
        if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
        {
          itemNew.put("IND_DEL", 1);
        }
        if (INDICADOR_NUEVO_REGISTRO.equals(itemNew.get("indica")))
        {
        //La comparacion ya viene como parte del det_solrecti
          Map<String, Object> mapTmpPK = comparador.obtenerDatosPK(itemNew, mapClave);

          /*Map<String, Object> mapDocAutAsociado = new HashMap<String, Object>();
          mapDocAutAsociado.put("numCorredoc", itemNew.get("NUM_CORREDOC"));
          mapDocAutAsociado.put("numSecdoc", itemNew.get("NUM_SECDOC"));
          mapDocAutAsociado.put("codTipdocaso", itemNew.get("COD_TIPCERTIFICADO"));
          java.util.Date fecha = null;
          try
          {
            fecha = DateUtils.parseDate(itemNew.get("FEC_CERTIFICADO").toString(), FORMAT_DATES);
          }
          catch (ParseException e)
          {
            fecha = SunatDateUtils.getDateFromUnknownFormat(itemNew.get("FEC_CERTIFICADO").toString());
          }

          Integer annDoc = SunatDateUtils.getAnho(fecha);
          if (annDoc.intValue() != 0)
          {	
            mapDocAutAsociado.put("annDoc", annDoc);
          }
          mapDocAutAsociado.put("numDoc", itemNew.get("NUM_CERTIFICADO"));
          mapDocAutAsociado.put("fecEmis", fecha);
          Date fecVencimiento = SunatDateUtils.getDate("31/12/9999", "dd/MM/yyyy");
          mapDocAutAsociado.put("fecVenc", fecVencimiento);
          mapDocAutAsociado.put("codTipoper", "C");
          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  docAutAsociadoBatchDAO.insertMapSelective(mapDocAutAsociado);
              }else{
            docAutAsociadoDAO.insertMapSelective(mapDocAutAsociado);
          }
              //rtineo mejoras, fin
          }
          catch (Exception e)
          {
            if (log.isDebugEnabled())
            {
              log.debug("ocurrio u n error al tratar de realizar el insert certificado origen: (docAutAsociadoDAO) "
                  + mapDocAutAsociado);

            }
          }*/

          itemNew.put("IND_DEL", 0);
          try
          {
              //rtineo mejoras, grabacion para rectificacion desde web
              if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	  insertRecordBatch(itemNew);
              }else{
            insertRecord(itemNew);
              }
              //rtineo mejoras, fin
            cont++;
          }
          catch (DataIntegrityViolationException e)
          {
            if (log.isWarnEnabled())
            {
              log.warn("EL registro ya existe se procede a actualizarlo con IND_DEL=0");
            }
            // Si el registro ya existe se activa el registro y se actualiza
            //rtineo mejoras, grabacion para rectificacion desde web
            if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
            	updateRecordBatch(itemNew);
            }else{
            updateRecord(itemNew);
          }
            //rtineo mejoras, fin
          }
          // grabamos en ofirecti

          itemNew.put("dataOriginal", new HashMap(itemNew));
          itemNew.put("clave", mapTmpPK);
          //rtineo mejoras, grabacion para rectificacion desde web
          if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
        	  registrarRectiOficioBatch(itemNew, numCorredocSol, true);
        	  //Inicio PAS20181U220200056                   
        	  //dentro de diligencia se evalua el indicador electronico a veces no se manda
              	registrarMarcadoCertificadoOrigenElectronico(itemNew, codTransaccion);
              //Fin PAS20181U220200056        	  
          }else{
          registrarRectiOficio(itemNew, numCorredocSol, true);
          }
          //rtineo mejoras, fin
          continue;
        }
        else
        {
          for (Map<String, Object> itemOld : (ArrayList<Map<String, Object>>) mapDatos.get(getNombreListaOriginal()))
          {

            if (Comparador.isKeyEqual(itemOld, itemNew, mapClave))
            {
              mapDiferenciaGrabar = comparador.comparaMap(itemOld, itemNew, mapClave);
              if (mapDiferenciaGrabar != null && mapDiferenciaGrabar.size() > 0
                  && Comparador.esDataCambiada(mapDiferenciaGrabar))
              {
                if (INDICADOR_ELIMINAR_REGISTRO.equals(itemNew.get("indica")))
                {
                  mapDiferenciaGrabar.put("IND_DEL", 1);
                }
                log.debug("-------- Tenemos el map resultante a grabar :: " + mapDiferenciaGrabar);
                //rtineo mejoras, grabacion para rectificacion desde web
                if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
                	updateRecordBatch(mapDiferenciaGrabar);
                    registrarRectiOficioBatch(mapDiferenciaGrabar, numCorredocSol, false);
                     
                    //Inicio PAS20181U220200056                    
                   //dentro de diligencia se evalua el indicador electronico a veces no se manda
                    	registrarMarcadoCertificadoOrigenElectronico(mapDiferenciaGrabar, codTransaccion);
                    //Fin PAS20181U220200056
                    
                }else{
                updateRecord(mapDiferenciaGrabar);
                registrarRectiOficio(mapDiferenciaGrabar, numCorredocSol, false);
                }             
                //rtineo fin mejoras
                cont++;
              }
            }
          }
        }
      }
    }
    return cont;
  }

  //PAS20181U220200056
  private void registrarMarcadoCertificadoOrigenElectronico(Map<String, Object> mapDiferenciaGrabar, String codTransaccion) {
	  if(mapDiferenciaGrabar.get("NUM_CERTIFICADO")!=null){
	  	Map<String, Object> mapCerti = new HashMap<String, Object>();
	  	Map declaracion = new HashMap();
	  	mapCerti.put("NUM_CERTIFICADO", mapDiferenciaGrabar.get("NUM_CERTIFICADO").toString());
  		mapCerti.put("IND_ELECTRONICO", mapDiferenciaGrabar.get("IND_ELECTRONICO")!=null?mapDiferenciaGrabar.get("IND_ELECTRONICO").toString():null);
  		declaracion.put("NUM_CORREDOC", mapDiferenciaGrabar.get("NUM_CORREDOC").toString());
  		
	  	//busco el numdeclaracion:
	  	HashMap<String, Object> paramDam = new HashMap<String, Object>();
	  	paramDam.put("numeroCorrelativo", new Long (mapDiferenciaGrabar.get("NUM_CORREDOC").toString()));
	  	
	  	CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
	  	DUA damRecep = cabDeclaraDAO.selectByNumCorredoc(paramDam);
	  	declaracion.put("NUM_DECLARACION", damRecep.getNumdocumento().toString());
		//actualiza el cert electronico:
	  	DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
		
	  	diligenciaService.registroUsoCertificadoOrigenElectronico(mapCerti , declaracion, codTransaccion);
	  }
  }
  /**
   * Retorna las series donde el certificado origen interviene y tambien trae el
   * numero del proveedor de la serie
   * 
   * @param NumeroCorreltivoDua
   * @param secuenciaDocumento
   * @return
   */
  public List<Map<String, Object>> getCertificoOrigenPorSeries(
      final Long numeroCorrelativoDua,
      final Long numeroCorrelativoSolicitud)
  {
    // obtenemos informacion de det_autorizacion

    Map<String, Object> mapParametros = new HashMap<String, Object>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", numeroCorrelativoDua);
    //
    RectificacionAbstract rectifiSerie = fabricaDeServicios.getService("diligencia.rectificacion.codtabla." + "T0043");
    List<Map<String, Object>> lstSeriesItem = rectifiSerie.getTableRectificadoMergedBD(mapParametros,
        numeroCorrelativoSolicitud, true);

    rectifiSerie = fabricaDeServicios.getService("diligencia.rectificacion.codtabla." + "T0033");
    List<Map<String, Object>> lstDetAutorizacion = rectifiSerie.getTableRectificadoMergedBD(mapParametros,
        numeroCorrelativoSolicitud, true);

    // cargamos los valores de FORMBPROVEEDOR cod_tabla ='T0070'
    RectificacionAbstract rectifiProveedor = fabricaDeServicios.getService("diligencia.rectificacion.codtabla."
        + "T0070");
    List<Map<String, Object>> lstProveedor = rectifiProveedor.getTableRectificadoMergedBD(mapParametros,
        numeroCorrelativoSolicitud, true);

    List<Map<String, Object>> lstCetificadoOrigen = this.getTableRectificadoMergedBD(mapParametros,
        numeroCorrelativoSolicitud, true);

    // filtramos los que tengan el certificado origen
    CollectionUtils.filter(lstDetAutorizacion, new Predicate()
    {

      @Override
      public boolean evaluate(Object objDetAutorizacion)
      {
        Map<String, Object> mapDetAutorizacion = (Map<String, Object>) objDetAutorizacion;
        Long numeroCorrelativo = new Long(ObjectUtils.toString(mapDetAutorizacion.get("NUM_CORREDOC"), "0"));
        String tipoOperacion = ObjectUtils.toString(mapDetAutorizacion.get("COD_TIPOPER"), "0").trim();
        // tambien quitamos los eliminados previo a la rectificacion
        String indicadorEliminado = ObjectUtils.toString(mapDetAutorizacion.get("IND_DEL"), "0");
        return numeroCorrelativo.equals(numeroCorrelativoDua) && CODIGO_TIPO_OPERACION.equals(tipoOperacion)
            && "0".equals(indicadorEliminado);
      }
    });

    // ordenamos por serie y luego por item
    Collections.sort(lstSeriesItem, new Comparator<Map<String, Object>>()
    {
      @Override
      public int compare(Map<String, Object> seriesItem1, Map<String, Object> seriesItem2)
      {
        Integer serie = new Integer(ObjectUtils.toString(seriesItem1.get("NUM_SECSERIE"), "0")) * 10000;
        Integer item = new Integer(ObjectUtils.toString(seriesItem1.get("NUM_SECITEM"), "0"));
        serie = +item;
        Integer serie2 = new Integer(ObjectUtils.toString(seriesItem2.get("NUM_SECSERIE"), "0")) * 10000;
        Integer item2 = new Integer(ObjectUtils.toString(seriesItem2.get("NUM_SECITEM"), "0"));
        serie2 = +item2;
        return serie.compareTo(serie2);
      }
    });

    // agregamos el proveedor para la serie
    Iterator<Map<String, Object>> iterListDetAutorizacion = lstDetAutorizacion.iterator();
    while (iterListDetAutorizacion.hasNext())
    {
      Map<String, Object> detAutorizacion = iterListDetAutorizacion.next();
      Integer serieDetAutorizacion = new Integer(ObjectUtils.toString(detAutorizacion.get("NUM_SECSERIE"), "0"));

      for (Map<String, Object> serieItem : lstSeriesItem)
      {
        String indicadorEliminado = ObjectUtils.toString(serieItem.get("IND_DEL"), "0");
        Integer numeroSerie = new Integer(ObjectUtils.toString(serieItem.get("NUM_SECSERIE"), "0"));
        if (serieDetAutorizacion.equals(numeroSerie) && indicadorEliminado.equals("0"))
        {
          // agregamos el numero del proveedor
          detAutorizacion.put("NUM_SECPROVE", serieItem.get("NUM_SECPROVE"));
          Integer secuenciaProvedorSerie = new Integer(ObjectUtils.toString(serieItem.get("NUM_CORREDOC"), "0"));
          for (Map<String, Object> mapProveedor : lstProveedor)
          {
            Long numeroCorrelativo = new Long(ObjectUtils.toString(mapProveedor.get("NUM_CORREDOC"), "0"));
            Integer secuenciaProvedor = new Integer(ObjectUtils.toString(mapProveedor.get("NUM_CORREDOC"), "0"));
            String indicadorEliminadoProveedor = ObjectUtils.toString(mapProveedor.get("IND_DEL"), "0");
            if (numeroCorrelativo.equals(numeroCorrelativoDua) && secuenciaProvedorSerie.equals(secuenciaProvedor)
                && indicadorEliminadoProveedor.equals("0"))
            {
              detAutorizacion.put("NOM_PROVEEDOR", mapProveedor.get("NOM_RAZONSOCIAL_PRV"));
              detAutorizacion.put("NUM_SECPARTIC", mapProveedor.get("NUM_CODSECPROVE"));
            }
          }
          break;
        }
      }

      // agregamos el cerficado a cada serie
      Integer secuenciaDocumentoSerie = new Integer(ObjectUtils.toString(detAutorizacion.get("NUM_SECDOC"), "-1"));

      for (Map<String, Object> mapCertificadoOrigen : lstCetificadoOrigen)
      {
        String indicadorEliminadoCertificado = ObjectUtils.toString(mapCertificadoOrigen.get("IND_DEL"), "0");
        Integer secuenciaDocumentoCetificado = new Integer(
            ObjectUtils.toString(mapCertificadoOrigen.get("NUM_SECDOC"), "-1"));//pase42 lvila
        String tipoOperacionCetificado = ObjectUtils.toString(detAutorizacion.get("COD_TIPOPER"), "").trim();
        if (CODIGO_TIPO_OPERACION.equals(tipoOperacionCetificado) && "0".equals(indicadorEliminadoCertificado)
            && secuenciaDocumentoSerie.equals(secuenciaDocumentoCetificado))
        {
          // si se trata de nuevo o eliminado mantenemos el ind_rectifica de la
          // serie
          String indicadorRectificaSerie = ObjectUtils.toString(detAutorizacion.get("IND_RECTIFICA"), "");
          detAutorizacion.putAll(mapCertificadoOrigen);
          if (!"".equals(indicadorRectificaSerie))
          {
            detAutorizacion.put("IND_RECTIFICA", indicadorRectificaSerie);
          }
        }

      }

    }

    return lstDetAutorizacion;
  }

  // fin gmontoya diligencia 2012
  @Override
  protected List<Map<String, Object>> getTablaBD(Map<String, Object> parametros)
  {
    Map<String, String> mapParametros = new HashMap<String, String>();
    // Se recupera por Documento los valores
    mapParametros.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    return cabCertiOrigenDAO.selectCabCertiOrigenFindByPK(mapParametros);
  }

  public void setCabCertiOrigenDAO(CabCertiOrigenDAO cabCertiOrigenDAO)
  {
    this.cabCertiOrigenDAO = cabCertiOrigenDAO;
  }

  @Override
  protected void insertRecord(Map<String, Object> newRecordMap)
  {
    this.cabCertiOrigenDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));

  }

  @Override
  protected void updateRecord(Map<String, Object> updateRecordMap)
  {
    cabCertiOrigenDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));

  }

  //rtineo mejoras
  @Override
  protected void insertRecordBatch(Map<String, Object> newRecordMap){
	  cabCertiOrigenBatchDAO.insertSelective(Utilidades.transformFieldsToRealFormat(newRecordMap));
  }

  @Override
  protected void updateRecordBatch(Map<String, Object> updateRecordMap){
	  cabCertiOrigenBatchDAO.update(Utilidades.transformFieldsToRealFormat(updateRecordMap));
  }
  //rtineo fin
  
  public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
  {
    this.docAutAsociadoDAO = docAutAsociadoDAO;
  }

  public DocAutAsociadoDAO getDocAutAsociadoDAO()
  {
    return docAutAsociadoDAO;
  }

  //rtineo mejoras, agregado para grabacion en batch
  public CabCertiOrigenBatchDAO getCabCertiOrigenBatchDAO() {
	return cabCertiOrigenBatchDAO;
  }

  public void setCabCertiOrigenBatchDAO(CabCertiOrigenBatchDAO cabCertiOrigenBatchDAO) {
	this.cabCertiOrigenBatchDAO = cabCertiOrigenBatchDAO;
  }
  
  public DocAutAsociadoBatchDAO getDocAutAsociadoBatchDAO() {
	return docAutAsociadoBatchDAO;
  }

  public void setDocAutAsociadoBatchDAO(DocAutAsociadoBatchDAO docAutAsociadoBatchDAO) {
	this.docAutAsociadoBatchDAO = docAutAsociadoBatchDAO;
  }
  //rtineo fin mejoras
}
