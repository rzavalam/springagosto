package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DetDeuda;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;

public interface DeudaService
{
  /**
   * Obtener Deuda Tributaria
   * @param PkDocu
   * @return
   * @throws ServiceException
   */
  public Map<String, Object> obtenerDeudaTributaria(Map<String, String> PkDocu)
      throws ServiceException;

  /**
   * Tiene Deuda Pendiente
   * @param declaracion
   * @return
   * @throws ServiceException
   */
  public String tieneDeudaPendiente(Map<String, Object> declaracion)
      throws ServiceException;

  /**
   * Tiene montos liquidados mayores a los iniciales Para el tipo de diligencia
   * tipDiligencia
   *
   * @param numCorreDoc
   * @param tipDiligencia
   * @return true, Si existe un registro en la tabla deuda?docum
   */
  public boolean tieneMontosLiquidadosParaDiligencia(String numCorreDoc, MovCabliqdilig movCabliqdilig);
  public List<Liquida> tieneLCPendientesPago(Map<String, Object> params);
	// INICIO RIN15
	public Map<String, Object> findFechaHoraCancelacionByNumCorreDoc(String numCorreDoc);
	// FIN RIN15
  /*RIN13FSW-INICIO*/
  /*jlunah*/
  public List<DetDeuda> obtenerTributosPorSerie(String numcorredoc, int identDeuda, String numserie);
  
  public Map<String, Object> obtenerListaTributosPorSerie(String numCorreDoc,String numeroSerie);
  
  public List<Map<String,Object>> obtenerListaDiferenciaTributosTodasLasSeries(String numCorredoc);
  /*fin jlunah*/

  /**
   * M�doto para verificar si  la declaracion cuenta con Extorno de pago.
   * @param numCorreDoc
   * @param  cod_tiporegistro
   * @param cod_indicador  
   * */
  public boolean tieneExtornoPago( Map<String, Object> params) throws ServiceException;
  
  /**
   * RIN13 SWF
   * */
  public void generarDeudaAndPagosParaMulta(Map<String, Object> multa);
  
  public String tieneDeudaPendienteSinGarantia(Map<String, Object> declaracion) throws ServiceException;
  /*RIN13FSW-FIN*/

  //MOL PASE280
  public boolean esDuaCancelada(Map<String, Object> declaracion);
  //FIN MOL

  public List<Map<String, Object>> obtenerCabeceraGarantia160(String numCtaCte);//gmontoya PASE 176 P24 2015

  public List<Map<String, Object>> obtenerMovGarantia160(Map<String, Object> params); //gmontoya PASE 176 P24 2015

  public List<Map<String, Object>> obtenerGarantias159(String numDeclaracion, String codAduana, String codRegimen, String annPresen, String moneda); //gmontoya PASE 176 P24 2015
  
  public List<Map<String, Object>> tieneLCPendPagoAlertaBusqDiligencia(Map<String, Object> declaracion); //475
  
  /*Inicio PAS20155E220200089*/
  public String obtenerNroDeReliqNumDeclaracion (Long numCorredoc);		
  /*Fin PAS20155E220200089*/

  public String verificaLCPendientePago(String numcorredoc); //PAS201830001100016 - mtorralba 20181120
}
