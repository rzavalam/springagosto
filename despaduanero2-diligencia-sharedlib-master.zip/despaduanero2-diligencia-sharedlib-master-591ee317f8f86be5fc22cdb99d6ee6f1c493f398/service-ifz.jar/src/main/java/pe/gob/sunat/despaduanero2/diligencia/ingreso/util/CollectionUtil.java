package pe.gob.sunat.despaduanero2.diligencia.ingreso.util;



import java.util.List;
import java.util.Map;

import static org.springframework.util.CollectionUtils.*;

/**
 * Clase Utilitarios para enmascarar las librerias terceros.
 */
public final class CollectionUtil
{
  private static final String DEFAULT_STRING = "";

  /**
   * Es vacio.
   *
   * @param lista
   *          the lista
   * @return true, if successful
   */
  public static boolean esVacio(List lista)
  {
    return isEmpty(lista) ? true : false;
  }

  /**
   * Es vacio.
   *
   * @param mapa
   *          the mapa
   * @return true, if successful
   */
  public static boolean esVacio(Map<?,?> mapa)
  {
    return isEmpty(mapa) ? true : false;
  }

}
