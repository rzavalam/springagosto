package pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoTextil;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreCremallera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.*;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.domesticos.model.ArticuloDomestico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.juguetes.model.Juguete;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.laminas.model.Lamina;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.maletas.model.Maleta;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.neumaticos.model.Neumatico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproTorre;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilFibra;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilPrenda;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

import java.util.Date;

/**
 * Created by amancillaa on 08/11/2016.
 */
public class PlantillaFactory {

    private FabricaDeServicios fabricaDeServicios;

    
    public String obtenerVersionEstrutura(ModelAbstract objeto){

        CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

        
        Date fechaControlVersionversionPlantilla = (Date) catalogoAyudaService.getElementoCat("380", "0025").get("fec_inidatcat");


        String versionPlantilla = "";

        if (fechaControlVersionversionPlantilla!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(objeto.getFechaIniVigenciaValidador(), fechaControlVersionversionPlantilla, SunatDateUtils.COMPARA_SOLO_FECHA)
                && noEsExcepcion(objeto)){
            versionPlantilla = "2";
        }


        return versionPlantilla;
    }

    private boolean noEsExcepcion(ModelAbstract objeto) {

        return  (objeto instanceof Vehiculo
                || objeto instanceof TextilPrenda
                || objeto instanceof ReproTorre
                || objeto instanceof Neumatico
                || objeto instanceof CalzadoTextil
                || objeto instanceof Lamina
                || objeto instanceof ComputoComputadora
                || objeto instanceof ComputoCPU
                || objeto instanceof ComputoDiscoDuro
                || objeto instanceof ComputoImpresora
                || objeto instanceof ComputoMemoria
                || objeto instanceof ComputoCDRom
                || objeto instanceof ComputoMonitor
                || objeto instanceof ComputoScanner
                || objeto instanceof ComputoTarjetaRed
                || objeto instanceof ComputoTarjetaVideo
                || objeto instanceof ComputoTarjetaSonido
                || objeto instanceof ComputoTarjetaMadre
                || objeto instanceof ComputoVentilador
                || objeto instanceof ComputoMouse
                || objeto instanceof ComputoTeclado
                || objeto instanceof ComputoProcesador
                || objeto instanceof CierreCremallera
                || objeto instanceof CierreOtros
                || objeto instanceof Maleta
                || objeto instanceof Ceramico
                || objeto instanceof Juguete
        || objeto instanceof SanitarioInodoro
        || objeto instanceof ArticuloDomestico)?true:false;
    }


    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
        this.fabricaDeServicios = fabricaDeServicios;
    }
}
   



