package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;//P46-PAS20155E410000032-[jlunah]
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercanciaDispuesta;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieImpoConsumo;//P46-PAS20155E410000032-[jlunah]
//INICIO RIN08
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
//FIN RIN08
import pe.gob.sunat.despaduanero2.declaracion.model.MRestri;//RIN14
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IscvalorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MrestriDAO;//RIN14
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;//RIN10 
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;//RIN14
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuDAO;//P46-PAS20155E410000032-[jlunah]
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MercanciaDispuestaDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;//P46-PAS20155E410000032-[jlunah]

public class SerieServiceImpl implements SerieService
{

protected final Log      log = LogFactory.getLog(this.getClass());

  private DetDeclaraDAO    detDeclaraDAO;

  private ConvenioSerieDAO convenioSerieDAO;

  private SeriesItemDAO    seriesItemDAO;

  private RectiOficioDAO   rectiOficioDAO;

  private DetAutorizacionDAO detAutorizacionDAO;

  private FormatoValorService formatoValorService;

  private DocuPreceDuaDAO docuPreceDuaDAO;

  private FormBProveedorDAO formBProveedorDAO;
  
  private VehiCeticoService vehiCeticoService;
  private MercanciaDispuestaDAO mercanciaDispuestaDAO;
  
  private DisposicionMercanciaService disposicionMercanciaService;
  
  //private DetAdiImpoconsuDAO detAdiImpoconsuDAO; //BUG 20206
  
  private MrestriDAO mrestriDAO;//RIN14
  
  private CabDeclaraDAO cabDeclaraDAO;
  
//Inicio RIN10 mpoblete BUG 22178
private FabricaDeServicios fabricaDeServicios;


public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
	this.fabricaDeServicios = fabricaDeServicios;
}
//Fin RIN10 mpoblete BUG 22178

//ECANA Se debe leer la vigencia en operariva
private HotSwappableTargetSource swapperDatasource;

public HotSwappableTargetSource getSwapperDatasource() {
	return swapperDatasource;
}

public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
	this.swapperDatasource = swapperDatasource;
}

protected boolean enableSwapperDataSource = true;

public void setEnableSwapperDataSource(boolean enableSwapperDataSource) {
	this.enableSwapperDataSource = enableSwapperDataSource;
}
////

  /**
   * @param params
   * @return
   */
  public List<Map<String, Object>> obtenerListadoSeriesOld(Map<String, String> params)
      throws ServiceException
  {
    String codRegimen = (params.get("cod_regimen") != null) ? params.get("cod_regimen") : "";
    List<Map<String, Object>> list;
    // En caso de obtener data con descripcion de catalogos para consultas.
    if (params.get("acceso") != null && "00".equals(params.get("acceso").toString().trim()))
    {
      list = detDeclaraDAO.findSeriesByDocumentoAndDescripcionCatalogos(params);
    }
    else
    {
      if (params.get("cod_regimen") != null)
      {
        if (params.get("cod_regimen").toString().equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))
        {
          list = detDeclaraDAO.findSeriesByDocumentoReg10(params);
        }
        else if (params.get("cod_regimen").toString().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO))
        {
          list = detDeclaraDAO.findSeriesByDocumentoReg20(params);
        }
        else if (params.get("cod_regimen").toString().equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO))
        {
          list = detDeclaraDAO.findSeriesByDocumentoReg21(params);
        }
        else
        {
          list = detDeclaraDAO.findSeriesByDocumentoRegOtros(params);
        }
      }
      else
      {
        list = detDeclaraDAO.findSeriesByDocumentoRegOtros(params);
      }
    }
    // si hay series eliminadas por el proceso de rectificacion automatica no
    // debe mostrase PASE578
    // para la diligencia de despacho pero si para las demas ya sea revision o
    // consulta
    String acceso = params.get("acceso") != null ? params.get("acceso") : "";
    List<Map<String, Object>> listaSerieEliRectiAuto = new ArrayList<Map<String, Object>>();
    Map<String, Object> serieEliminada = null;
    //pase153
    String estadoRectiOficio = params.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null?params.get("COD_ESTADO_RECTIFICACION_OFICIO"):"";

    if ((Constantes.ESTADO_RECTI_PROCESO.equals(params.get("estadoDUA")) || "EN_PROCESO".equals(estadoRectiOficio)) && !(acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA)))
    {

      // si es diligencia de rectificacion
      if (params.get("tipoDiligencia") != null
          && Constantes.TIPO_DILIG_ESTA_RECTIFICACION.equals(params.get("tipoDiligencia")))
      {
        listaSerieEliRectiAuto = getSeriesEliminadasRectificacionAutomatica(params.get("num_corredoc"), list);
      }
      else
      {
        for (Map<String, Object> mapSerie : list)
        {
          if (Constantes.IND_ELIMINADO.equals(mapSerie.get("IND_DEL").toString()))
          {
            serieEliminada = mapSerie;
            listaSerieEliRectiAuto.add(serieEliminada);
            continue;
          }
        }
      }

      for (Map<String, Object> mapEliminar : listaSerieEliRectiAuto)
      {
        list.remove(mapEliminar);
      }
      Ordenador.sortDesc(list, "NUM_SECSERIE", Ordenador.ASC);
    }
    if (!CollectionUtils.isEmpty(list))
    {
      for (int i = 0; i < list.size(); i++)
      {
        mapearCamposSerie(list.get(i), codRegimen);
      }
    }
    
    //CU 14.14
    Map<String, Object> paramsProveedor = new HashMap<String, Object>();
    paramsProveedor.put("NUM_CORREDOC", params.get("num_corredoc"));
    list = this.agregaIndicadorExisteFormatoB(paramsProveedor, list);
    //FIN 14.14
    //BUG20206 - AGREGAR PORCENTAJE DE ALCOHOL
    //list = this.agregaPorcentajeAlcohol(paramsProveedor, list);
    return list;
  }

  //metodo modificado
  /**
   * @param params
   * @return
   * @author modificado por glazaror
   */
  //@Override
  public List<Map<String, Object>> obtenerListadoSeries(Map<String, String> params) throws ServiceException {
	  CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");//P46-PAS20155E410000032-[jlunah]
	  DetAdiImpoconsuDAO detAdiImpoconsuDAO = (DetAdiImpoconsuDAO)fabricaDeServicios.getService("detAdiImpoconsuDAO");//P46-PAS20155E410000032-[jlunah]
	  //gdlr: ojo... todos los datos que vienen en el map "params" tienen como key nombres en minusculas...
	  String codigoRegimen = params.get("cod_regimen");
	  Object numeroCorrelativo = null;
	  // rtineo: para casos en que no se llegue el num_corredoc
	  Map<String,Object> params2 = new HashMap<String,Object>();
	  params2.put("codigoAduana", params.get("cod_aduana"));
	  params2.put("annoPresentacion", params.get("ann_presen"));
	  params2.put("codigoRegimen", params.get("cod_regimen"));
	  params2.put("numeroDeclaracion", params.get("num_declaracion"));
	  if(params.get("num_corredoc")== null){
		     numeroCorrelativo = this.cabDeclaraDAO.findDUAByMap(params2).getNumcorredoc();  
	  }else{
	     numeroCorrelativo = params.get("num_corredoc");
	  }
/*	  if(params.get("estadoDUA")==null){//PASE 427  Mercancia Dispuesta
	     String estadoDua = this.cabDeclaraDAO.findDUAByMap(params2).getCodEstdua(); 
	     params2.put("estadoDUA", estadoDua);
	  }else{
	     params2.put("estadoDUA", params.get("estadoDUA"));
	  }
	  */
	  //gdlr: Se ejecutan N querys... solo deberian ejecutarse 8 querys:
	  //1. DET_DECLARA... aqui se debe incluir la consulta a FORMATO B ya que es solo un indicador
	  List<Map<String, Object>> series = obtenerSeries(params);
	  //2. MRESTRI... formateamos los numero de partida a consultar y ejecutamos un solo query
	  //...pendiente...
	  List<String> partidasInList = new ArrayList<String>();
	  StringBuilder partidas = new StringBuilder();
	  
	  //ECANA Se debe consultar en aduana operativa
	  //swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + "000"));
	  
	  //ECANA Lista para validar partida de Licor
	  Map<String,Object> paramsIscvalor=new HashMap<String,Object>();
	  paramsIscvalor.put("fecvigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
	  boolean VigenciaISC = false;
	  
	  //if (enableSwapperDataSource) {
		  VigenciaISC=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000413", SunatDateUtils.getCurrentDate())>0;
	  //}
	  
	  //obtenemos las partidas de todas las series... para hacer una sola consulta en la tabla MRESTRI
	  for (Map<String, Object> serie : series) {
		  String numeroPartida = serie.get("NUM_PARTNANDI").toString();
		  if (!partidasInList.contains(numeroPartida)) {
			  partidas.append(numeroPartida).append(",");
			  partidasInList.add(numeroPartida);
		  }
		  
		  //ECANA Se verifican las partidas con sus tasas sin que se repitan 
		  if(VigenciaISC){
			  String tnan = (serie.get("COD_TIPTASAAPLICAR").toString()!= null) ? serie.get("COD_TIPTASAAPLICAR").toString() : "";
			  String partida = serie.get("NUM_PARTNANDI").toString();
			  paramsIscvalor.put("cnan", partida);
			  paramsIscvalor.put("tnan", tnan);
			  paramsIscvalor.put("visc", "998");
			  paramsIscvalor.put("tipo_uso", "LIC");
			  
			  IscvalorDAO iscvalorDAO=((IscvalorDAO)fabricaDeServicios.getService("iscvalorDAO"));
			  List<Map<String, Object>> listIscDescrib= iscvalorDAO.findPartidaLic(paramsIscvalor);               
			  
			  if(listIscDescrib.size() > 0){
				  serie.put("DOBS", listIscDescrib.get(0).get("DOBS"));
			  }
		  }
		  
		  /*inicio P46-PAS20155E410000032-[jlunah]*/
		  //Se agrega aqui para aprovechar el for que recorre todas las series
		  //Se requiere que se agregue al mapa "series" el tipo de regularizacion en caso tenga la serie
		  Map<String,Object> paramImpoConsu = new HashMap<String, Object>();  
		  paramImpoConsu.put("numcorredoc", serie.get("NUM_CORREDOC"));
		  paramImpoConsu.put("numserie", serie.get("NUM_SECSERIE"));
		  DatoAdiSerieImpoConsumo datoAdiSerieImpoConsumo =   detAdiImpoconsuDAO.selectByPK(paramImpoConsu);
		  
		  if(datoAdiSerieImpoConsumo != null){ 
			  if(datoAdiSerieImpoConsumo.getCodTipRegul() != null){
			  serie.put("COD_TIPREGUL", datoAdiSerieImpoConsumo.getCodTipRegul());
			  serie.put("DES_TIPREGUL", catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDataCatalogo.TIPO_REGULARIZACION_DONACION,
					  datoAdiSerieImpoConsumo.getCodTipRegul()));
			  }else{
			  serie.put("COD_TIPREGUL", " ");
			  serie.put("DES_TIPREGUL", " ");
			  }
		  }else{
			  serie.put("COD_TIPREGUL", " ");
			  serie.put("DES_TIPREGUL", " ");
		  }
		  
		  /*fin P46-PAS20155E410000032-[jlunah]*/
		  
	  }
	  //glazaror... pendiente: la consulta a la tabla MRESTRI solo funciona para una cadena con maximo 4000 caracteres... si es que se tiene una cadena mas larga se tiene que partir en cadenas de 4000 cada una.
	  List<String> partidasConMercanciaRestringida = null;
	  if (!partidasInList.isEmpty()) {
		  partidas.deleteCharAt(partidas.length() - 1);
		  Map<String, Object> parametrosMercanciaRestringida = new HashMap<String, Object>();
		  parametrosMercanciaRestringida.put("codiregi", codigoRegimen);
		  parametrosMercanciaRestringida.put("NUM_PARTNANDI_ALL", partidas.toString());
		  partidasConMercanciaRestringida = mrestriDAO.getPartidasConMercanciaRestringida(parametrosMercanciaRestringida);
	  } else {
		  partidasConMercanciaRestringida = new ArrayList<String>();
	  }
	  partidasInList = null;
	  
	  //3. DET_AUTORIZACION...1
	  Map<String, String> parametros = new HashMap<String, String>();
	  parametros.put("NUM_CORREDOC", numeroCorrelativo.toString());//gdlr: aqui lo quiere como String...
	  parametros.put("IND_DEL", "0");
	  List<Map<String, Object>> detallesAutorizacion = obtenerDetAutorizacion(parametros);
	  
	  Map<String, Object> parametros2 = new HashMap<String, Object>();
	  parametros2.put("NUM_CORREDOC", numeroCorrelativo);
	  parametros2.put("IND_DEL", "0");
	  
	  //4. DET_AUTORIZACION...2
	  List<Map<String, Object>> documentosAutorizadosAgrupadosPorSerie = detAutorizacionDAO.getCantidadDocumentosPorSerie(parametros);
	  
	  //5. VEHI_CETICO
	  List<Map<String,Object>> vehiculos = vehiCeticoService.selectVehiCetico(parametros2);
	  
	  //6. MONTOGASTO
	  List<Map<String,Object>> montosGasto = vehiCeticoService.selectMontoGasto(parametros2);
	  
	  //7. DOCUPRECE_DUA
	  List<Map<String, Object>> regimenesPrecedencia = (List<Map<String, Object>>) docuPreceDuaDAO.findBySerie(parametros2);
	  
	  //8. FACTURA_SERIE
	  Map<String, Object> parametros3 = new HashMap<String, Object>();
	  parametros3.put("num_corredoc", numeroCorrelativo);
	  //amancill aP24
	  List<Map<String, Object>> facturas = formatoValorService.obtenerFacturasSerieAll(parametros3);
	  
	  
	  //gdlr: este es el metodo mas pesado... se comenta para aplicar la misma funcionalidad de una mejor manera
	  /*if (!CollectionUtils.isEmpty(list)) {
		  for (int i = 0; i < list.size(); i++) {
			  mapearCamposSerie(list.get(i), codRegimen);
		  }
	  }*/
	  
	    
	  //CU 14.14
	  Map<String, Object> paramsProveedor = new HashMap<String, Object>();
	  paramsProveedor.put("NUM_CORREDOC", numeroCorrelativo);
	  series = this.agregaIndicadorExisteFormatoB(paramsProveedor, series);
	  //FIN 14.14
	  
	  if (!CollectionUtils.isEmpty(series)) {
		  for (Map<String, Object> serie : series) {
			  mapearCamposSerieNew(serie, codigoRegimen, partidasConMercanciaRestringida, documentosAutorizadosAgrupadosPorSerie, detallesAutorizacion, 
					  regimenesPrecedencia, vehiculos, montosGasto, facturas, params2);//PASE 427  Mercancia Dispuesta
		  }
	  }
	  //gdlr: lanzo excepcion para no continuar...
      //BUG20206 - AGREGAR PORCENTAJE DE ALCOHOL
	  //series = this.agregaPorcentajeAlcohol(paramsProveedor, series);
	  return series;
  }


  @Override
  public void cargarSubElementosSerie(Map params)
      throws ServiceException
  {

    List<Map<String, Object>> lstSerie = (List<Map<String, Object>>) params.get("lstDetDeclaraActual");
    List<Map<String, Object>> lstSerieAnt = (List<Map<String, Object>>) params.get("lstDetDeclara");
    Map serieAnt;
    if (!CollectionUtils.isEmpty(lstSerie))
    {
      List lstDocPrece;
      Map<String, Object> prmtReg = new HashMap<String, Object>();

      for (Map serie : lstSerie)
      {
        if (serie.get("lstDocuPreceDua") == null)
        {
          prmtReg.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
          prmtReg.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
          lstDocPrece = this.obtenerRegPrecedencia(prmtReg);

          if (!CollectionUtils.isEmpty(lstDocPrece))
          {
            serieAnt = Utilidades.obtenerElemento(lstSerieAnt, prmtReg);

            serieAnt.put("lstDocuPreceDua", lstDocPrece);
            serie.put("lstDocuPreceDua", lstDocPrece);
          }
        }
      }
    }

  }

  /**
   * @param params
   * @return
   */
  public Map<String, Object> obtenerDetalleSerie(Map<String, String> params)
      throws ServiceException
  {
    Map<String, Object> serieMap = null;
    String tipoRegimen = "";
    if (tipoRegimen.equals(Constantes.REGIMEN_80_TRANSITO))
    {
      serieMap = detDeclaraDAO.joinCabAdiTransitoFindBySerie(params);
    }
    else if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))
    {
      serieMap = detDeclaraDAO.joinCabAdiImpoConsuFindBySerie(params);
    }
    else if (tipoRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO))
    {
      serieMap = detDeclaraDAO.joinCabAdiAdmTemFindBySerie(params);
    }
    else if (tipoRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO))
    {
      serieMap = detDeclaraDAO.joinCabAdiATReexFindByDocumento(params);
    }
    else
    {
      serieMap = detDeclaraDAO.findBySerie(params);
    }
    return serieMap;
  }

  public Map<String, Object> editarSerieSession(Map<String, String> params, List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException
  {
    Map<String, Object> detDeclaraMap = null;
    try
    {
      for (Map<String, Object> detDeclaraViewMap : detDeclaraViewList)
      {
        String num_secserie = params.get("num_secserie");
        Object num_secserieView = detDeclaraViewMap.get("NUM_SECSERIE");
        if (Utilidades.compararCadenaConObjeto(num_secserie, num_secserieView))
        {
          detDeclaraMap = detDeclaraViewMap;
          break;
        }
      }
      if (detDeclaraMap.get("lstConvenioSerie") == null)
      {
        detDeclaraMap.put("lstConvenioSerie", convenioSerieDAO.select(detDeclaraMap));
      }
    }
    catch (Exception e)
    {
      new ServiceException(this, e);
    }
    return detDeclaraMap;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> grabarSerieSession(
    Map<String, Object> requestParameterMap,
    List<Map<String, Object>> detDeclaraParamList)
    throws ServiceException, Exception
  {
    List<Map<String, Object>> detDeclaraSessionList = new ArrayList<Map<String, Object>>(
        detDeclaraParamList);
    try
    {
      Map<String, Object> detDeclaraMap;
      String valorNuevo;
      Object valorOriginal;
      Set<String> keySet;
      for (int i = 0; i < detDeclaraSessionList.size(); i++)
      {
        detDeclaraMap = detDeclaraSessionList.get(i);
        Map<String, Object> detDeclaraNuevoMap = Utilidades
            .copiarMapa(detDeclaraMap);

        String num_secserie = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("hdn_num_secserie"));
        if (Utilidades.compararCadenaConObjeto(num_secserie, detDeclaraMap.get("NUM_SECSERIE")))
        {
          keySet = requestParameterMap.keySet();
          for (String strKey : keySet)
          {
            valorNuevo = Utilidades.crearCadenaDesdeObjeto(
                Utilidades.obtenerObjetoDesdeMapa(requestParameterMap, strKey));
            valorOriginal = Utilidades.obtenerObjetoDesdeMapa(detDeclaraMap, strKey);
            if (Utilidades.compararCadenaConObjeto(valorNuevo, valorOriginal))
            {
              // TODO: Verificar que no se hace nada en caso sea
              // igual.
            }
            else
            {
              detDeclaraNuevoMap = Utilidades.ponerObjetoAMapa(
                  detDeclaraNuevoMap,
                  Utilidades.crearObjetoDesdeCadena(valorNuevo,
                      valorOriginal), strKey);
            }
          }

          // Obtenemos los codigos de convenios
          List<Map<String, Object>> lstConvenioSerie = (ArrayList) detDeclaraNuevoMap
              .get("lstConvenioSerie");
          valorNuevo = Utilidades.crearCadenaDesdeObjeto(
              Utilidades.obtenerObjetoDesdeMapa(
              requestParameterMap, "cod_tipconvenio_tpi"));

          lstConvenioSerie = asignarConvenio("I", valorNuevo,
              detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
              detDeclaraNuevoMap.get("NUM_SECSERIE").toString(),
              lstConvenioSerie);

          valorNuevo = Utilidades.crearCadenaDesdeObjeto(
              Utilidades.obtenerObjetoDesdeMapa(
              requestParameterMap, "cod_tipconvenio_tpn"));
          lstConvenioSerie = asignarConvenio("T", valorNuevo,
              detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
              detDeclaraNuevoMap.get("NUM_SECSERIE").toString(),
              lstConvenioSerie);

          valorNuevo = Utilidades.crearCadenaDesdeObjeto(
              Utilidades.obtenerObjetoDesdeMapa(
              requestParameterMap, "cod_tipconvenio_ind_libe"));
          lstConvenioSerie = asignarConvenio("C",
              valorNuevo.toString(),
              detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
              detDeclaraNuevoMap.get("NUM_SECSERIE").toString(),
              lstConvenioSerie);

          detDeclaraNuevoMap = Utilidades.ponerObjetoAMapa(detDeclaraNuevoMap,
              lstConvenioSerie, "lstConvenioSerie");


          detDeclaraSessionList.set(i, detDeclaraNuevoMap);
          break;
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    // se comenta pq el prorrateo se da cuando grabar la declaracion
    // prorrateoFlete(detDeclaraSessionList); // JCV 20100122 Implementa RN038
    // de la Ing. en Reversa
    return detDeclaraSessionList;
  }

  public List<Map<String, Object>> grabarSerie(Map<String, Object> params)
      throws ServiceException, Exception
  {
    log.debug("grabarSerie()");

   // List<Map<String, Object>> detDeclaraList = (List<Map<String, Object>>) params.get("lstDetDeclaraActual");
    //esta lista debe ser sin estado por eso se comenta
    List<Map<String, Object>> detDeclaraList = new ArrayList<Map<String,Object>>();
    detDeclaraList = Utilidades.copiarLista((List)params.get("lstDetDeclaraActual"));

    List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActual");
    Map<String, Object> requestParameterMap = (Map<String, Object>) params.get("requestParameterMap");
    try
    {
      Map<String, Object> detDeclaraMap;
      String valorNuevo;
      Object valorOriginal;
      Set<String> keySet;
      BigDecimal sumMto_fobdol = null;
      BigDecimal sumCnt_comer = null;
      // operaciones
      String OPERACION_EDITAR = "2";
      log.debug("requestParameterMap: " + requestParameterMap);
      String num_operacion = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("hdn_num_operacion"));
      log.debug("num_operacion: " + num_operacion);
      log.debug("OPERACION_EDITAR:" + OPERACION_EDITAR);

      // recorremos la lista de series actuales en session
      for (int i = 0; i < detDeclaraList.size(); i++)
      {
        detDeclaraMap = detDeclaraList.get(i);
        Map<String, Object> detDeclaraNuevoMap = Utilidades.copiarMapa(detDeclaraMap);
        // obtnenemos la serie que se ha modificado los datos
        String num_secserie = Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("hdn_num_secserie"));

        if (Utilidades.compararCadenaConObjeto(num_secserie, detDeclaraMap.get("NUM_SECSERIE")))
        {
          keySet = requestParameterMap.keySet();
          for (String strKey : keySet)
          {
            valorNuevo = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(requestParameterMap, strKey));
            valorOriginal = Utilidades.obtenerObjetoDesdeMapa(detDeclaraMap, strKey);
            if (!Utilidades.compararCadenaConObjeto(valorNuevo, valorOriginal))
            {
              detDeclaraNuevoMap = Utilidades.ponerObjetoAMapa(detDeclaraNuevoMap,
                  Utilidades.crearObjetoDesdeCadena(valorNuevo, valorOriginal), strKey);
            }
          }
 //INICIO RIN08
          if (detDeclaraNuevoMap.get("NUM_PARNABANDINA") != null && "".equals(detDeclaraNuevoMap.get("NUM_PARNABANDINA")) ){
        	  detDeclaraNuevoMap.put("NUM_PARNABANDINA"," ");
            }
//FIN RIN08
          if (detDeclaraNuevoMap.get("COD_INSUMO") != null || detDeclaraNuevoMap.get("CNT_UNIEQUI") != null
              || detDeclaraNuevoMap.get("COD_UMEQUI") != null)
          {

            Map adAtpa = new HashMap();
            adAtpa.put("COD_INSUMO",
                detDeclaraNuevoMap.get("COD_INSUMO") != null ? detDeclaraNuevoMap.get("COD_INSUMO") : ' ');
            adAtpa.put("CNT_UNIEQUI",
                detDeclaraNuevoMap.get("CNT_UNIEQUI") != null ? detDeclaraNuevoMap.get("CNT_UNIEQUI") : 0);
            adAtpa.put("COD_UMEQUI",
                detDeclaraNuevoMap.get("COD_UMEQUI") != null ? detDeclaraNuevoMap.get("COD_UMEQUI") : ' ');
            adAtpa.put("DES_UMEQUI",
                detDeclaraNuevoMap.get("DES_UMEQUI") != null ? detDeclaraNuevoMap.get("DES_UMEQUI") : ' ');
            detDeclaraNuevoMap.put("mapDetAdiAtpa", adAtpa);
          }

          // Obtenemos los codigos de convenios
          List<Map<String, Object>> lstConvenioSerie = (ArrayList) detDeclaraNuevoMap.get("lstConvenioSerie");
          valorNuevo = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(requestParameterMap, "cod_tipconvenio_tpi"));
          lstConvenioSerie = asignarConvenio("I", valorNuevo, detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
              detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
          valorNuevo = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(requestParameterMap, "cod_tipconvenio_tpn"));
          lstConvenioSerie = asignarConvenio("T", valorNuevo, detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
              detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
          
          /*[jlunah] Se agrega if debido a que hay problemas cuando se pone en disabled el control "sel_cod_tipconvenio_ind_libe" de RegSerieOficio.jsp
           * Cuando esta en disabled este control, el valor "cod_tipconvenio_ind_libe" no llega
           * Cuando no esta en disabled este control, el valor "cod_tipconvenio_ind_libe" si llega
           * Esto ocasiona que el sistema reconosca (aun sin cambios cuando esta en disabled) que es un nuevo valor y lo agrega
           * */
          if(requestParameterMap.containsKey("cod_tipconvenio_ind_libe")){//P46-PAS20155E410000032-[jlunah]
          valorNuevo = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(requestParameterMap, "cod_tipconvenio_ind_libe"));
          lstConvenioSerie = asignarConvenio("C", valorNuevo.toString(), detDeclaraNuevoMap.get("NUM_CORREDOC")
              .toString(), detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
          }//P46-PAS20155E410000032-[jlunah]
          
          detDeclaraNuevoMap = Utilidades.ponerObjetoAMapa(detDeclaraNuevoMap, lstConvenioSerie, "lstConvenioSerie");

          String IND_REGISTRO_GRABADO = "0";
          String DES_REGISTRO_GRABADO = "Adicionado";
          detDeclaraNuevoMap.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);
          detDeclaraNuevoMap.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);
          if (detDeclaraNuevoMap.get("IND_DESCMANTSERIE") != null
              && (detDeclaraNuevoMap.get("IND_DESCMANTSERIE").toString()).equals("1"))
          {
         // muestra descipcion DES_REGISTRO_GRABADO
            detDeclaraNuevoMap.put("IND_DESCMANTSERIE", "1");

          }
          // actualiza los datos de la serie con los ingresados en el JSP
          detDeclaraList.set(i, detDeclaraNuevoMap);
        }
        // si tiene formato B solo actualiza a los series agregadas no a las modificadas
        if (params.get("IND_FORMBPROVEEDOR").toString().equals("0")
            && detDeclaraNuevoMap.get("ESTADO_REGISTRO").toString().equals("1")
            && detDeclaraNuevoMap.get("IND_SERIE_CORRELACIONADA").toString().equals("0"))//CU 14.20
        {
          sumMto_fobdol = BigDecimal.ZERO;
          sumCnt_comer = BigDecimal.ZERO;
          if (!CollectionUtils.isEmpty(lstSeriesItemActual))
            for (Map<String, Object> seriesItemAct : lstSeriesItemActual)
            {
              if (detDeclaraMap.get("NUM_SECSERIE").toString().equals(seriesItemAct.get("NUM_SECSERIE").toString())
            	  && seriesItemAct.get("IND_DEL").toString().equals("0")){//CU 14.20
            	  
                sumCnt_comer = sumCnt_comer.add(new BigDecimal(seriesItemAct.get("CNT_MERC").toString()));
                sumMto_fobdol = sumMto_fobdol.add(new BigDecimal(seriesItemAct.get("MTO_FOB").toString()));
              }
            }
          detDeclaraMap.put("CNT_COMER", sumCnt_comer);
          detDeclaraMap.put("MTO_FOBDOL", sumMto_fobdol);
        }
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    return detDeclaraList;
  }
// INCIO RIN 16
  public List<Map<String, Object>> grabarSerieReguInicio(Map<String, Object> params) throws ServiceException, Exception{
	  log.debug("grabarSerie()");
	  List<Map<String, Object>> detDeclaraList = new ArrayList<Map<String,Object>>();
	  detDeclaraList = Utilidades.copiarLista((List)params.get("lstDetDeclaraActual"));
	  List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActual");
	  try{	      
		  Map<String, Object> detDeclaraMap;
	      Set<String> keySet;
	      String valorNuevo;
	      Object valorOriginal;
	      BigDecimal sumMto_fobdol = null;
	      BigDecimal sumCnt_comer = null;	      
	      // recorremos la lista de series actuales en session
	      for (int i = 0; i < detDeclaraList.size(); i++){
	        detDeclaraMap = detDeclaraList.get(i);
	        Map<String, Object> detDeclaraNuevoMap = Utilidades.copiarMapa(detDeclaraMap);
	        // obtnenemos la serie que se ha modificado los datos
	        for (Map<String, Object> seriesItemAct : lstSeriesItemActual){
	        	String num_secserie = seriesItemAct.get("NUM_SECSERIE").toString(); 
		        if (Utilidades.compararCadenaConObjeto(num_secserie, detDeclaraMap.get("NUM_SECSERIE"))){
		        	//INICIO RIN08
		        	if (detDeclaraNuevoMap.get("NUM_PARNABANDINA") != null && "".equals(detDeclaraNuevoMap.get("NUM_PARNABANDINA")) ){
		        		detDeclaraNuevoMap.put("NUM_PARNABANDINA"," ");
		            }
		        	//FIN RIN08
		        	if (detDeclaraNuevoMap.get("COD_INSUMO") != null || detDeclaraNuevoMap.get("CNT_UNIEQUI") != null
		              || detDeclaraNuevoMap.get("COD_UMEQUI") != null){
		        		Map adAtpa = new HashMap();
		        		adAtpa.put("COD_INSUMO", detDeclaraNuevoMap.get("COD_INSUMO") != null ? detDeclaraNuevoMap.get("COD_INSUMO") : ' ');
		        		adAtpa.put("CNT_UNIEQUI", detDeclaraNuevoMap.get("CNT_UNIEQUI") != null ? detDeclaraNuevoMap.get("CNT_UNIEQUI") : 0);
		        		adAtpa.put("COD_UMEQUI", detDeclaraNuevoMap.get("COD_UMEQUI") != null ? detDeclaraNuevoMap.get("COD_UMEQUI") : ' ');
		        		adAtpa.put("DES_UMEQUI", detDeclaraNuevoMap.get("DES_UMEQUI") != null ? detDeclaraNuevoMap.get("DES_UMEQUI") : ' ');     
		        		detDeclaraNuevoMap.put("mapDetAdiAtpa", adAtpa);
		        	}
		        	// Obtenemos los codigos de convenios
		        	List<Map<String, Object>> lstConvenioSerie = (ArrayList) detDeclaraNuevoMap.get("lstConvenioSerie");
		        	lstConvenioSerie = (ArrayList) detDeclaraNuevoMap.get("lstConvenioSerie");
		        	valorNuevo = detDeclaraNuevoMap.get("COD_CONVENIO_CI") != null ? detDeclaraNuevoMap.get("COD_CONVENIO_CI").toString() : " "; 
		        	lstConvenioSerie = asignarConvenio("I", valorNuevo, detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
		            detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
		        	valorNuevo = detDeclaraNuevoMap.get("COD_CONVENIO_CT") != null ? detDeclaraNuevoMap.get("COD_CONVENIO_CT").toString() : " ";
		        	lstConvenioSerie = asignarConvenio("T", valorNuevo, detDeclaraNuevoMap.get("NUM_CORREDOC").toString(),
		            detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
		        	valorNuevo = detDeclaraNuevoMap.get("COD_CONVENIO_CC") != null ? detDeclaraNuevoMap.get("COD_CONVENIO_CC").toString() : " ";
		        	lstConvenioSerie = asignarConvenio("C", valorNuevo.toString(), detDeclaraNuevoMap.get("NUM_CORREDOC")
		              .toString(), detDeclaraNuevoMap.get("NUM_SECSERIE").toString(), lstConvenioSerie);
		        	detDeclaraNuevoMap = Utilidades.ponerObjetoAMapa(detDeclaraNuevoMap, lstConvenioSerie, "lstConvenioSerie");

		        	String IND_REGISTRO_GRABADO = "0";
		        	String DES_REGISTRO_GRABADO = "Adicionado";
		        	detDeclaraNuevoMap.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);
		        	detDeclaraNuevoMap.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);
		        	if (detDeclaraNuevoMap.get("IND_DESCMANTSERIE") != null
		              && (detDeclaraNuevoMap.get("IND_DESCMANTSERIE").toString()).equals("1")){
		        		// muestra descipcion DES_REGISTRO_GRABADO
		        		detDeclaraNuevoMap.put("IND_DESCMANTSERIE", "1");
		        	}
		        	//actualiza los datos de la serie con los ingresados en el JSP
		        	detDeclaraList.set(i, detDeclaraNuevoMap);
		          }						        	
	        	}
	        	// si tiene formato B solo actualiza a los series agregadas no a las modificadas
	        	if (params.get("IND_FORMBPROVEEDOR").toString().equals("0")
	            && detDeclaraNuevoMap.get("ESTADO_REGISTRO").toString().equals("1")
	            && detDeclaraNuevoMap.get("IND_SERIE_CORRELACIONADA").toString().equals("0"))//CU 14.20
	        		{
	        		 sumMto_fobdol = BigDecimal.ZERO;
	        		 sumCnt_comer = BigDecimal.ZERO;
	        		 if (!CollectionUtils.isEmpty(lstSeriesItemActual))
	        			 for (Map<String, Object> seriesItemAct : lstSeriesItemActual){
	        				 if (detDeclaraMap.get("NUM_SECSERIE").toString().equals(seriesItemAct.get("NUM_SECSERIE").toString())
	        						 && seriesItemAct.get("IND_DEL").toString().equals("0")){//CU 14.20
	        					 sumCnt_comer = sumCnt_comer.add(new BigDecimal(seriesItemAct.get("CNT_MERC").toString()));
	        					 sumMto_fobdol = sumMto_fobdol.add(new BigDecimal(seriesItemAct.get("MTO_FOB").toString()));
	        				 }
	        			 }
	        		 detDeclaraMap.put("CNT_COMER", sumCnt_comer);
	        		 detDeclaraMap.put("MTO_FOBDOL", sumMto_fobdol); 
	        		}
	      		}						      
	  	}catch (Exception e){
	        e.printStackTrace();
	      }
	      return detDeclaraList;	    
	  }
  // FIN RIN 16	  
  /**
   * {@inheritDoc} devuelve la serie clonada con todos sus datos y el numero
   * numSecSerie que toma
   *
   */
  public List<Map<String, Object>> obtenerListSeriesSession(
      Map<String, Object> params,
      List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException
  {
    Map<String, Object> detDeclaraMap = null;
    try
    {
      // actualizando series-item
      String IND_FORMBPROVEEDOR = String.valueOf(params.get("IND_FORMBPROVEEDOR"));
      int numeroSerie = 0;
      Map<String, Object> itemBase = null;
      String serie_base = String.valueOf(params.get("_serie_base"));
// comentado p36 
//      if (Constantes.TIENE_FORMATO_B.equals(IND_FORMBPROVEEDOR))
//      {
//
//        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActual");
//        List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) params.get("lstSeriesItem");
//
//        String serie_item = String.valueOf(params.get("_serie_item"));
//        //se comenta 153
//        //serie_base = String.valueOf(params.get("_serie_base"));
//
//        // obtiene el todos los datos del itemBase seleeccionado
//        for (Map<String, Object> seriesItemAct : lstSeriesItemActual)
//        {
//          if (serie_base.toString().equals(seriesItemAct.get("NUM_SECSERIE").toString())
//              && serie_item.toString().equals(seriesItemAct.get("NUM_SECITEM").toString()))
//          {
//
//            itemBase = new HashMap<String, Object>(seriesItemAct);
//            break;
//          }
//        }
//        for (Map<String, Object> seriesItem : lstSeriesItem)
//        {
//          boolean existe = false;
//          // actualiza los datos ingresados en la redistribucion
//          for (Map<String, Object> seriesItemAct : lstSeriesItemActual)
//          {
//            if (seriesItem.get("NUM_SECSERIE").toString().equals(seriesItemAct.get("NUM_SECSERIE").toString())
//                && seriesItem.get("NUM_SECITEM").toString().equals(seriesItemAct.get("NUM_SECITEM").toString()))
//            {
//
//              seriesItemAct.put("CNT_MERC", seriesItem.get("CNT_MERC"));
//              seriesItemAct.put("MTO_FOB", seriesItem.get("MTO_FOB"));
//              existe = true;
//              break;
//            }
//          }
//          if (!existe)
//          {// serie que se agrega
//            numeroSerie = Integer.valueOf(seriesItem.get("NUM_SECSERIE").toString());
//            itemBase.put("NUM_SECSERIE", seriesItem.get("NUM_SECSERIE"));
//            itemBase.put("NUM_SECITEM", seriesItem.get("NUM_SECITEM"));
//            itemBase.put("CNT_MERC", seriesItem.get("CNT_MERC"));
//            itemBase.put("MTO_FOB", seriesItem.get("MTO_FOB"));
//            lstSeriesItemActual.add(itemBase);
//          }
//        }
//        params.put("lstSeriesItemActual", lstSeriesItemActual);
//      }
//      else
//      {
      if(!Constantes.TIENE_FORMATO_B.equals(IND_FORMBPROVEEDOR)){//CU 14.14
        for (Map<String, Object> detDeclaraViewMap : detDeclaraViewList)
        {// ubicar el max numeroserie
          Object num_secserieView = detDeclaraViewMap.get("NUM_SECSERIE");
          if (numeroSerie < Integer.valueOf(num_secserieView.toString()))
          {
            numeroSerie = Integer.valueOf(num_secserieView.toString());
          }
        }
      }
//      }comentado p36
      // actualizando series
      int cantidad = Integer.valueOf(params.get("NUM_CANTIDAD").toString());
      Map<String, Object> fbKeys;
      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", new Long(params.get("NUM_CORREDOC").toString()));
      fbKeys.put("NUM_SECSERIE", new Long(params.get("NUM_SECSERIE").toString()));
      detDeclaraMap = obtenerSerieSession(params, detDeclaraViewList);

      // se copia los datos de las otras tablas a la serie generada
      // cantidad siempre es 1
      for (int i = 0; i < cantidad; i++)
      {
        if (Constantes.NO_TIENE_FORMATO_B.equals(IND_FORMBPROVEEDOR))
        {
          numeroSerie++;
        }

        String numCorreDocDua = params.get("NUM_CORREDOC").toString();
        int nextNumSecSerieGenerada = getSgteNumSecSerie(numCorreDocDua, detDeclaraViewList);
        Map<String, Object> detDeclaraMap1 = Utilidades.copiarMapa(detDeclaraMap);// copiando
                                                                                  // serie
        detDeclaraMap1.put("NUM_SECSERIE", nextNumSecSerieGenerada);
        detDeclaraMap1.put("IND_SERIE_CORRELACIONADA", "1");//serie nace sin correlacion
        detDeclaraMap1.put("ELIMINADO_PERMANENTE","");
        params.put("ULTIMA_SERIE", nextNumSecSerieGenerada);

        // se copia lista de convenio SI
        List<Map<String, Object>> lstConvenio = (List<Map<String, Object>>) detDeclaraMap1.get("lstConvenioSerie");
        if (!CollectionUtils.isEmpty(lstConvenio))
        {
          for (Map<String, Object> convenio : lstConvenio)
          {
            convenio.put("NUM_SECSERIE", detDeclaraMap1.get("NUM_SECSERIE"));
          }
        }
        detDeclaraMap1.put("lstConvenioSerie", lstConvenio);
        // se copia lista detAutorizacion
        List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) detDeclaraMap1
            .get("lstDetAutorizacion");
        if (!CollectionUtils.isEmpty(lstDetAutorizacion))
        {
          for (Map<String, Object> detAutorizacion : lstDetAutorizacion)
          {
            detAutorizacion.put("NUM_SECSERIE", detDeclaraMap1.get("NUM_SECSERIE"));
          }
        }
        detDeclaraMap1.put("lstDetAutorizacion", lstDetAutorizacion);

        // se copia lista docuPreceDua SI
        List<Map<String, Object>> lstDocuPreceDua = (List<Map<String, Object>>) detDeclaraMap1.get("lstDocuPreceDua");
        if (!CollectionUtils.isEmpty(lstDocuPreceDua))
        {
          for (Map<String, Object> docuPreceDua : lstDocuPreceDua)
          {
            docuPreceDua.put("NUM_SECSERIE", detDeclaraMap1.get("NUM_SECSERIE"));
          }
        }
        detDeclaraMap1.put("lstDocuPreceDua", lstDocuPreceDua);

        // se copia lista facturaSerie SI
        List<Map<String, Object>> lstFacturaSerie = (List<Map<String, Object>>) detDeclaraMap1.get("lstFacturaSerie");
        if (!CollectionUtils.isEmpty(lstFacturaSerie))
        {
          for (Map<String, Object> facturaSerie : lstFacturaSerie)
          {
            facturaSerie.put("NUM_SECSERIE", detDeclaraMap1.get("NUM_SECSERIE"));
          }
        }
        detDeclaraMap1.put("lstFacturaSerie", lstFacturaSerie);

        // se copia los certificados de origen

        final String IND_REGISTRO_PENDIENTE = "1";
        String DES_REGISTRO_PENDIENTE = "Pendiente de grabar";
        detDeclaraMap1.put("IND_TIPO_REGISTRO", IND_REGISTRO_PENDIENTE);
        detDeclaraMap1.put("DES_TIPO_REGISTRO", DES_REGISTRO_PENDIENTE);
        detDeclaraMap1.put("ESTADO_REGISTRO", "1");// 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN  BD
        detDeclaraMap1.put("IND_DESCMANTSERIE", "1");
        //PASE153 Se agrega este campo para saber de que serie fue generada
        //en la recti de oficio se quiere ver solo los datos modificados de la nueva serie
        //para compararla es necesario saber de que serie se baso
        detDeclaraMap1.put("SERIE_BASE", serie_base);
        // 0 no muestra ninguna descripcion, 1 si muestra la descripcion del DES_TIPO_REGISTRO

        // seteando cantidad y monto fob a la nueva serie generada segun la
        // re-distribucion
//        if (IND_FORMBPROVEEDOR.equals("0"))
//        { // si tiene formato B
//          double ntoFobDolares = Double.valueOf(itemBase.get("MTO_FOB").toString());
//          detDeclaraMap1.put("MTO_FOBDOL", ntoFobDolares);
//          detDeclaraMap1.put("CNT_COMER", itemBase.get("CNT_MERC"));
//          detDeclaraMap1.put("MTO_FLETEDOL", 0);
//
//        }
//        else
//        {
          // para el regimen 70
          detDeclaraMap1.put("MTO_FLETEDOL", 0);
//        }
        detDeclaraViewList.add(detDeclaraMap1);
      }

    }
    catch (Exception e)
    {
      new ServiceException(this, e);
    }
    return detDeclaraViewList;
  }

  /**
   * {@inheritDoc}
   *
   * @author amancillaa
   */
  public int getSgteNumSecSerie(String numCorreDocDua)
  {

    return obtenerSgteNumSecSerie(numCorreDocDua);
  }

  /**
   * Obtener secuencia para insercion de una nueva serie
   *
   * @param numCorreDocDua
   * @return int
   */
  private int obtenerSgteNumSecSerie(String numCorreDocDua)
  {

    return (detDeclaraDAO.getMaxNumSecSerie(numCorreDocDua) + 1);
  }

  /**
   * {@inheritDoc}
   *
   * @author amancillaa
   */
  public int getSgteNumSecSerie(String numCorreDocDua, List<Map<String, Object>> lstSeriesActuales)
  {

    int secuenciaBD = obtenerSgteNumSecSerie(numCorreDocDua);

    int secuenciaLstSeriesActual = obtenerSgteNumSecSerie(lstSeriesActuales);

    return maximo(secuenciaBD, secuenciaLstSeriesActual);
  }

  private int maximo(int secuenciaBD, int secuenciaLstSeriesActual)
  {
    return (secuenciaBD <= secuenciaLstSeriesActual ? secuenciaLstSeriesActual : secuenciaBD);
  }

  private int obtenerSgteNumSecSerie(List<Map<String, Object>> lstSeriesActuales)
  {

    int numeroSerie = 0;
    for (Map<String, Object> detDeclaraViewMap : lstSeriesActuales)
    {
      Object num_secserieView = detDeclaraViewMap.get("NUM_SECSERIE");
      if (numeroSerie < Integer.valueOf(num_secserieView.toString()))
        numeroSerie = Integer.valueOf(num_secserieView.toString());
    }
    numeroSerie++;
    return numeroSerie;
  }




  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerSerieSession(
      Map<String, Object> params,
      List<Map<String, Object>> detDeclaraViewList)
      throws ServiceException
  {


    Map<String, Object> detDeclaraMap = new HashMap<String, Object>();
    try
    {

      String num_secserie = params.get("NUM_SECSERIE") != null ? params.get("NUM_SECSERIE").toString() : "";

      if (!CollectionUtils.isEmpty(detDeclaraViewList) && !SunatStringUtils.isEmpty(num_secserie))
      {

        for (Map<String, Object> detDeclaraViewMap : detDeclaraViewList)
        {
          //String num_secserie = params.get("NUM_SECSERIE").toString();
          Object num_secserieView = detDeclaraViewMap.get("NUM_SECSERIE");
          if (Utilidades.compararCadenaConObjeto(num_secserie, num_secserieView))
          {
            detDeclaraMap = new HashMap<String, Object>(detDeclaraViewMap);
            break;
          }
        }
        // obteniendo lista de convenios
        if (detDeclaraMap.get("lstConvenioSerie") == null)
        {
          detDeclaraMap.put("lstConvenioSerie", convenioSerieDAO.select(detDeclaraMap));
        }

        // setear tipo operacion
        String num_operacion = params.get("NUM_OPERACION") != null ? params.get("NUM_OPERACION").toString() : "";
        detDeclaraMap.put("OPERACION_SERIE", num_operacion);
      }

    }
    catch (Exception e)
    {
      new ServiceException(this, e);
    }
    return detDeclaraMap;
  }

  private boolean buscarItemAsociadoAOtraSerie(Map declaracion, String nroSerie, String nroItem){
	  List<Map<String, Object>> lstFormBProveedor = (ArrayList) declaracion.get("lstFormBProveedor");
	  for (Map<String, Object> mapProveedor : lstFormBProveedor) {
	      List<Map<String, Object>> lstFacturas = (ArrayList) mapProveedor.get("lstComproBPago");
	      for (Map<String, Object> mapFactura : lstFacturas) {
	    	  List<Map<String, Object>> lstItems = (ArrayList) mapFactura.get("lstItemFactura");
	    	  for (Map<String, Object> mapItem : lstItems) {
	    		  List<Map<String, Object>> lstSeriesItems = (ArrayList) mapItem.get("lstSeriesItem");
	    		  for (Map<String, Object> mapSerieItem : lstSeriesItems) {
	    			  if(mapSerieItem.get("NUM_SECITEM").toString().equals(nroItem) &&
		    				  !mapSerieItem.get("NUM_SECSERIE").toString().equals(nroSerie)){
		    			  return true;
		    		  }					
	    		  }
	    	  }
	      }		
	  }	  
	  return false;
  }
  
  private void eliminarItemFactura(Map declaracion, String nroItem, String estadoEliminado){
	  List<Map<String, Object>> lstFormBProveedor = (ArrayList) declaracion.get("lstFormBProveedor");
	  for (Map<String, Object> mapProveedor : lstFormBProveedor) {
	      List<Map<String, Object>> lstFacturas = (ArrayList) mapProveedor.get("lstComproBPago");
	      for (Map<String, Object> mapFactura : lstFacturas) {
	    	  List<Map<String, Object>> lstItems = (ArrayList) mapFactura.get("lstItemFactura");
	    	  for (Map<String, Object> mapItem : lstItems) {
	    		  if(mapItem.get("NUM_SECITEM").toString().equals(nroItem)){
	    			  mapItem.put("IND_DEL", estadoEliminado);
	    			  return;
	    		  }				
	    	  }
	      }		
	  }	
  }


  public Map<String, Object> actualizaEstadoSerieSession(Map<String, Object> params)
      throws ServiceException
  {
    Map<String, Object> mreturn = new HashMap<String, Object>();
    Map<String, Object> declaracion = (Map) params.get("declaracion");
    try
    {
      String numSecSerie = params.get("NUM_SECSERIE").toString();
      String estSecSerie = params.get("EST_SECSERIE").toString();
      String numCorreDoc = params.get("NUM_CORREDOC").toString();
      List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) params.get("lstDetDeclaraActual");

      Map<String, Object> param = new HashMap<String, Object>();
      param.put("NUM_CORREDOC", numCorreDoc);
      param.put("NUM_SECSERIE", numSecSerie);
      
      List<Map<String, Object>> lstSeriesItemActual = obtenerLstSeriesItem(
          (List<Map<String, Object>>) params.get("lstSeriesItemActual"), param);

      for (Map<String, Object> detDeclara : lstDetDeclara){
        String num_secserieView = detDeclara.get("NUM_SECSERIE").toString();
        if (Utilidades.compararCadenaConObjeto(numSecSerie, num_secserieView)){
          detDeclara.put("IND_DEL", estSecSerie);// serie
          for (Map<String, Object> serieItem : lstSeriesItemActual){
            // seriesItem
            if (serieItem.get("NUM_SECSERIE").toString().equals(num_secserieView)){
            	//inicio CUS 14.16 
            	if(this.validarActivarInactivarCorrelacion(estSecSerie, serieItem, params)){
          	        serieItem.put("IND_DEL", estSecSerie);
          	        this.actualizarEstadoItemFactura(lstSeriesItemActual, params, declaracion, serieItem);
                }	
            	//fin 
			// Se comenta porque la funcionalidad esta contenida en el requerimiento P36,
			// en el metodo actualizarEstadoItemFactura
            /* if(!buscarItemAsociadoAOtraSerie(declaracion, numSecSerie, serieItem.get("NUM_SECITEM").toString())){
            	  eliminarItemFactura(declaracion, serieItem.get("NUM_SECITEM").toString(), estSecSerie);
              } */       
            }			
          }
          
          List<Map<String, Object>> lstDocuPreceDua = Utilidades.copiarLista((List) detDeclara.get("lstDocuPreceDua"));// lstDocuPreceDua
          if (!CollectionUtils.isEmpty(lstDocuPreceDua)){
            for (Map<String, Object> docuPreceDua : lstDocuPreceDua){
              docuPreceDua.put("IND_DEL", estSecSerie);
            }
          }
          detDeclara.put("lstDocuPreceDua", lstDocuPreceDua);
          List<Map<String, Object>> lstConvenioSerie = Utilidades
              .copiarLista((List) detDeclara.get("lstConvenioSerie"));// lstConvenioSerie
          if (!CollectionUtils.isEmpty(lstConvenioSerie)){
            for (Map<String, Object> convenioSerie : lstConvenioSerie){
              convenioSerie.put("IND_DEL", estSecSerie);
            }
          }
          detDeclara.put("lstConvenioSerie", lstConvenioSerie);

          List<Map<String, Object>> lstFacturaSerie = Utilidades.copiarLista((List) detDeclara.get("lstFacturaSerie"));// lstFacturaSerie
          if (!CollectionUtils.isEmpty(lstFacturaSerie)){
            for (Map<String, Object> facturaSerie : lstFacturaSerie){
              facturaSerie.put("IND_DEL", estSecSerie);
            }
          }
          detDeclara.put("lstFacturaSerie", lstFacturaSerie);
          break;
        }
      }
      log.debug("actualizaEstadoSerieSession.lstDetDeclara:" + lstDetDeclara);

      // Se actualiza el estado en los documentos
      List<Map<String, Object>> lstDocAutAsociado = (List) declaracion.get("lstDocAutAsociado");
      if (!CollectionUtils.isEmpty(lstDocAutAsociado)){
        List<Map<String, Object>> lstDetAutorizacion = (List) declaracion.get("lstDetAutorizacion");
        List<Map<String, Object>> lstCabCertiOrigen = (List) declaracion.get("lstCabCertiOrigen");

        actualizarEstadoDocumentosAutorizantes(lstDetAutorizacion, lstDocAutAsociado, lstCabCertiOrigen, numSecSerie,
            estSecSerie);

        declaracion.put("lstDocAutAsociado", lstDocAutAsociado);
        declaracion.put("lstDetAutorizacion", lstDetAutorizacion);
        declaracion.put("lstCabCertiOrigen", lstCabCertiOrigen);
      }
      //inicio 14.16
      if(declaracion.get("IND_FORMBPROVEEDOR").toString().equals("0")){
      	this.actualizarMontoFacturas(lstSeriesItemActual, declaracion, params);
      	if(estSecSerie.equals("0")){
  		mreturn.put("itemsRecuperados", this.mostrarItemsRecuperados(params, lstSeriesItemActual));
      	}
      }	
      //fin 14.16

      mreturn.put("lstSeriesItemActual", lstSeriesItemActual);
      mreturn.put("lstDetDeclaraActual", lstDetDeclara);
      mreturn.put("declaracion", declaracion);
    }
    catch (Exception e){
      log.error("*** ERROR ***", e);
      new ServiceException(this, e);
    }

    return mreturn;
  }

  /**
   * Metodo que optiene las series eliminadas en la rectificacion automatica.
   *
   * @param NumCorredoc numero correlativo del dua
   * @param listaSeriesDetDeclara
   *          lista de series que tiene la dua incluida las eliminadas
   * @return
   */
  private List<Map<String, Object>> getSeriesEliminadasRectificacionAutomatica(
      String numCorredoc,
      List<Map<String, Object>> listaSeriesDetDeclara)
  {

    List<Map<String, Object>> listaSeriesDetDeclaraEliminada = getSeriesEliminadasDetDeclara(listaSeriesDetDeclara);

    if (org.apache.commons.collections.CollectionUtils.isEmpty(listaSeriesDetDeclaraEliminada))
    {
      return new ArrayList<Map<String, Object>>();
    }

    List<Map<String, Object>> seriesRectificadasOfiRecti = getSeriesEliminadasOfiRecti(numCorredoc);

    if (org.apache.commons.collections.CollectionUtils.isEmpty(seriesRectificadasOfiRecti))
    {
      return listaSeriesDetDeclaraEliminada;
    }

    // obtenemos los registros eliminados en la rectificacion automatica
    for (Map<String, Object> serieElimnada : seriesRectificadasOfiRecti)
    {
      final Map<String, Object> serieEliminadaOfiRecti = (Map<String, Object>) SojoUtil.fromJson(serieElimnada.get(
          "desclave").toString());

      org.apache.commons.collections.CollectionUtils.filter(listaSeriesDetDeclaraEliminada, new Predicate()
      {
        @Override
        public boolean evaluate(Object paramObject)
        {
          Map<String, Object> serieElimnadaDetDeclara = (Map<String, Object>) paramObject;
          boolean isEqualNumSecSerie = serieElimnadaDetDeclara.get("NUM_SECSERIE").equals(
              serieEliminadaOfiRecti.get("NUM_SECSERIE"));
          boolean isEqualNumCorredoc = serieElimnadaDetDeclara.get("NUM_CORREDOC").equals(
              serieEliminadaOfiRecti.get("NUM_CORREDOC"));
          return isEqualNumCorredoc && isEqualNumSecSerie;
        }
      });
    }
    return listaSeriesDetDeclaraEliminada;
  }

  private void mapearCamposSerie(Map serie, String codRegimen)
  {
    if (!StringUtils.isEmpty(codRegimen))
    {
      if (!codRegimen.equals(Constantes.REGIMEN_70_DEPOSITO))
      {
        Map adImpConsu = new HashMap();
        adImpConsu.put("MTO_PVPMONNAC", serie.get("MTO_PVPMONNAC") != null ? serie.get("MTO_PVPMONNAC") : 0);
        adImpConsu.put("DES_ZONAFRANCA", serie.get("DES_ZONAFRANCA") != null ? serie.get("DES_ZONAFRANCA") : ' ');
        adImpConsu.put("IND_ACOGCODLIBER", serie.get("IND_ACOGCODLIBER") != null ? serie.get("IND_ACOGCODLIBER") : ' ');
        serie.put("mapDetAdiImpoconsu", adImpConsu);
      }
      if (codRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO))
      {
        Map adDetAdiAtreex = new HashMap();
        adDetAdiAtreex.put("POR_MERMA", serie.get("POR_MERMA") != null ? serie.get("POR_MERMA") : 0);
        serie.put("mapDetAdiAtreex", adDetAdiAtreex);
      }
      else if (codRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO) || codRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)){/*P28-PAS20155E410000032[jlunah] BUG 3320*/
        Map adAtpa = new HashMap();
        adAtpa.put("COD_INSUMO", serie.get("COD_INSUMO") != null ? serie.get("COD_INSUMO") : ' ');
        adAtpa.put("CNT_UNIEQUI", serie.get("CNT_UNIEQUI") != null ? serie.get("CNT_UNIEQUI") : 0);
        adAtpa.put("COD_UMEQUI", serie.get("COD_UMEQUI") != null ? serie.get("COD_UMEQUI") : ' ');
        adAtpa.put("DES_UMEQUI", serie.get("DES_UMEQUI") != null ? serie.get("DES_UMEQUI") : ' ');
        serie.put("mapDetAdiAtpa", adAtpa);
      }
    }

    
    /*INICIO RIN14 - AGREGO COLUMNA RESTRINGIDA-MERCANCIAS RESTRINGIDAS*/
    Map<String,Object> parametroEntrada=new HashMap<String, Object>();
    
    int todasMercanciasTieneDocumentoControlAutorizante=0;
    int todasMercanciasTieneCodigoExoneracion=0;

    
    Integer intFechaActual=SunatDateUtils.getCurrentIntegerDate();
    parametroEntrada.put("cnan", serie.get("NUM_PARTNANDI"));
    parametroEntrada.put("codiregi", codRegimen);
    parametroEntrada.put("fechaVigencia", intFechaActual);
    
    List<MRestri> restringida= mrestriDAO.listMercRestringida(parametroEntrada);
    
    serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.NO_TIENE_MERCANCIASDECLARADAS_RESTRINGIDAS.getDescripcion());
    
    if(!CollectionUtils.isEmpty(restringida)){    	
    	Map<String, String> pkDocu = new HashMap<String, String>();
        pkDocu.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
        pkDocu.put("COD_TIPOPER", "P");
        pkDocu.put("IND_DEL", "0");
        pkDocu.put("NUM_SECSERIE",serie.get("NUM_SECSERIE").toString());
        
        List<Map<String, Object>> listaDocumentoControlAutorizanteSerie=detAutorizacionDAO.joinDetAutorizacionFindBySerie(pkDocu);//Rin 14 KAH
        
        if(!CollectionUtils.isEmpty(listaDocumentoControlAutorizanteSerie)){
        	for (Map<String, Object> documento : listaDocumentoControlAutorizanteSerie) {
    			if(!StringUtils.isEmpty(documento.get("COD_TIPDOCASO").toString().trim()) && !StringUtils.equals(documento.get("COD_TIPDOCASO").toString().trim(),"98")){
    				todasMercanciasTieneDocumentoControlAutorizante++;
    			}else{
    				todasMercanciasTieneCodigoExoneracion++;
    			}
    		}
            
            if(listaDocumentoControlAutorizanteSerie.size()==todasMercanciasTieneDocumentoControlAutorizante){
            	serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTO_CONTROL_AUTORIZANTE.getDescripcion());
            }else if(listaDocumentoControlAutorizanteSerie.size()==todasMercanciasTieneCodigoExoneracion){
            	serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_CODIGO_EXONERACION.getDescripcion());
            }else{
            	serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTOCONTROLAUTORIZANTE_Y_CODIGOEXONERACION.getDescripcion());
            }
        }
        
    }
    /*FIN RIN14 - AGREGO COLUMNA RESTRINGIDA-MERCANCIAS RESTRINGIDAS*/
    
    List lstConvenio = new ArrayList();
    if (serie.get("COD_CONVENIO_CI") != null)
    {
      Map mapCI = new HashMap();
      mapCI.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
      mapCI.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
      mapCI.put("COD_CONVENIO", serie.get("COD_CONVENIO_CI"));
      mapCI.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CI"));
      mapCI.put("IND_DEL", "0");
      lstConvenio.add(mapCI);
    }

    if (serie.get("COD_CONVENIO_CT") != null)
    {
      Map mapCT = new HashMap();
      mapCT.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
      mapCT.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
      mapCT.put("COD_CONVENIO", serie.get("COD_CONVENIO_CT"));
      mapCT.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CT"));
      mapCT.put("IND_DEL", "0");
      lstConvenio.add(mapCT);
    }

    if (serie.get("COD_CONVENIO_CC") != null)
    {
      Map mapCC = new HashMap();
      mapCC.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
      mapCC.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
      mapCC.put("COD_CONVENIO", serie.get("COD_CONVENIO_CC"));
      mapCC.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CC"));
      mapCC.put("IND_DEL", "0");
      lstConvenio.add(mapCC);
    }

    serie.put("lstConvenioSerie", lstConvenio);

    Map<String, String> param = new HashMap<String, String>();
    param.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
    param.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());// NUM_SECPROVE
    param.put("IND_DEL", "0");
    List lstDetAutorizacion = obtenerDetAutorizacion(param);
    List lstDocuPreceDua = obtenerRegPrecedencia(param);
    //jenciso Inicio ceticos parte1
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
    params.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());// NUM_SECPROVE
    params.put("IND_DEL", "0");
    //List<DatoVehiculo> lstDatoVehiculo = vehiCeticoService.findVehiculoByMap(params);
    //List<DatoMontoGasto> lstDatoMontoGasto = vehiCeticoService.findMontoGastoByMap(params);
    List<Map<String,Object>> lstDatoVehiculo = vehiCeticoService.selectVehiCetico(params);
    List<Map<String,Object>> lstDatoMontoGasto = vehiCeticoService.selectMontoGasto(params);
    serie.put("lstDatoVehiculo", lstDatoVehiculo);
    serie.put("lstDatoMontoGasto", lstDatoMontoGasto);
    //jenciso Fin
    //jenciso Inicio ceticos parte2
    StringBuilder precedenteCeticos = new StringBuilder("");
    if(lstDocuPreceDua!=null && lstDocuPreceDua.size()>0){
    	Map mapPrecedencia = (Map)lstDocuPreceDua.get(0);
    	if(mapPrecedencia.get("COD_REGIMENPRE") != null && mapPrecedencia.get("COD_REGIMENPRE").toString().equals("91")){
    		
    		precedenteCeticos= precedenteCeticos.append(mapPrecedencia.get("COD_ADUANAPRE").toString()).append("-")
    				.append(mapPrecedencia.get("ANN_PRESENPRE").toString()).append("-")
    				.append(mapPrecedencia.get("COD_REGIMENPRE").toString()).append("-")
    				.append(mapPrecedencia.get("NUM_DECLARACIONPRE").toString());
    		
    	}
    }
    serie.put("PRECED_CETICOS",precedenteCeticos.toString());
    //jenciso Fin ceticos parte2
    
    // amancillaa para que aparesca en todas las pantallas debo cargar los datos
    // de las facturas junto con FORMA_FACTU y factura_serie

    // List lstFacturaSerie = facturaSerieDAO.select(param1);
    // comentado para que carge en session tambien los datos de la factura
    // impornatente para que al momento de copiar una serie jale los datos de la
    // factura
    Map<String, Object> params1 = new HashMap<String, Object>();
    params1.put("num_corredoc", serie.get("NUM_CORREDOC").toString());
    params1.put("num_secserie", serie.get("NUM_SECSERIE").toString());
    List<Map<String, Object>> lstFacturaSerie = formatoValorService.obtenerFacturasSerie(params1);
    log.debug("mapearCamposSerie.lstDetAutorizacion:" + lstDetAutorizacion);
    log.debug("mapearCamposSerie.lstDocuPreceDua:" + lstDocuPreceDua);
    log.debug("mapearCamposSerie.lstFacturaSerie:" + lstFacturaSerie);
    serie.put("lstDetAutorizacion", lstDetAutorizacion);
    serie.put("lstDocuPreceDua", lstDocuPreceDua);
    serie.put("lstFacturaSerie", lstFacturaSerie);
    
   
    boolean bloquearEdicionSerie = false;
    
    String mensajeBloqueo =" ";
    String estadoMercDispuesta=" ";
    
    //pruizcr p42 consultas 
    
    Map<String,Object> paramsRegu = new HashMap<String,Object>();
    String mensaje = "";
    paramsRegu.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
    paramsRegu.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());
    String numCorreDoc=serie.get("NUM_CORREDOC").toString();
       
    String bultoTotalDispuesto=disposicionMercanciaService.validarTotalBultosDispuestosBySerie(paramsRegu).toString();
    
  	if (bultoTotalDispuesto != null && !bultoTotalDispuesto.isEmpty()) {
	    String varBultDisp = "";
	    String varBultDecl=serie.get("CNT_BULTO").toString();
	    if(bultoTotalDispuesto.equals(varBultDecl))
	    {
	      bloquearEdicionSerie= true;
	      mensajeBloqueo = "Serie de la declaraci�n se encuentra dispuesta totalmente";
	     // mensajeBloqueo=disposicionMercanciaService.validarDisposicionParcial(paramsRegu);
	      estadoMercDispuesta= "Total";
	      serie.put("bloquearEdicionSerie", bloquearEdicionSerie);
	      serie.put("mensajeBloqueo", mensajeBloqueo);
	    }else if(Integer.parseInt(bultoTotalDispuesto)>0 && Integer.parseInt(bultoTotalDispuesto)<Integer.parseInt(varBultDecl)){
	     estadoMercDispuesta= "Parcial"; 
	    }
	}

    serie.put("EST_MERCDISPUESTA", estadoMercDispuesta);
    serie.put("bloquearEdicionSerie", bloquearEdicionSerie);
    serie.put("mensajeBloqueo", mensajeBloqueo);

    String IND_REGISTRO_GRABADO = "0";

    String DES_REGISTRO_GRABADO = "Adicionado";
    // al inicio del cargado de datos de la bd
    // todos las series ya estan grabadas para este caso no deberia pintar nada
    // IND_TIPO_REGISTRO hay 2 tipos 0='Grabado en BD' o 1='Pendiente de Grabado'
    serie.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);
    serie.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);
    serie.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
    serie.put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
    if("1".equals(serie.get("IND_DEL").toString())){
    	serie.put("ELIMINADO_PERMANENTE", "BD");
    }else{
    	serie.put("ELIMINADO_PERMANENTE", "");
    }
    // agrego este campo para diferenciar entre el dato agregado y
    // los que ya existen en la BD
    // aparentemente los IND_REGISTRO_GRABADO y DES_REGISTRO_GRABADO significan
    // lo mismo hay que
    // TODO refactorizar ese codigo tarea pendinte
    //0 no muestra ninguna descripcion, 1 si muestra la descripcion del  DES_TIPO_REGISTRO
    serie.put("IND_DESCMANTSERIE", "0");
  }

  public List obtenerRegPrecedencia(Map params)
      throws ServiceException
  {
    Map paramsBD = Utilidades.adaptarParametrosBD(params);
    List<Map<String, Object>> listadoRegPrecedencia = (List<Map<String, Object>>) docuPreceDuaDAO.findBySerie(paramsBD);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//    for (Map regPrecede : listadoRegPrecedencia)
//    {
//      regPrecede.put("FEC_VENCREGPRE", sdf.format((Date) regPrecede.get("FEC_VENCREGPRE")));
//    }

    return listadoRegPrecedencia;
  }

  /**
   * Asignar convenio.
   *
   * @param tipo the tipo
   * @param codigo the codigo
   * @param codDoc the cod doc
   * @param codSerie the cod serie
   * @param lista  the lista
   * @return the list
   */
  private List asignarConvenio(
    String tipo,
    String codigo,
    String codDoc,
    String codSerie,
    List<Map<String, Object>> lista)
  {

    Map mapConvenio = new HashMap();
    Map mapKey = new HashMap();
    boolean encontrado = false;
    if (!CollectionUtils.isEmpty(lista))
    {

      mapKey.put("NUM_SECSERIE", codSerie);
      mapKey.put("COD_TIPCONVENIO", tipo);

      mapConvenio = Utilidades.obtenerElemento(lista, mapKey);
      if (!CollectionUtils.isEmpty(mapConvenio))
      {
        if (codigo.equals(mapConvenio.get("COD_CONVENIO").toString()) && SunatStringUtils.isEqualTo(mapConvenio.get("IND_DEL").toString(),"0"))
        {
          return lista;
        }
        else
        {
          for (Map mapConvenio2 : lista)
          {
            // Se asume que solo puede a ver un convenio por tipo, quedo
            // pendiente la modificacion de la tabla 20110810
            if (tipo.equals(mapConvenio2.get("COD_TIPCONVENIO").toString()))
            {
              // amancilla para el caso que se quite el convenio de uno ya
              // existente en vez de espacio le pongo 0
              // para que no se caiga el calculo de tributos
              codigo = (!"".equals(codigo.trim())) ? codigo : "0";
              
              //amancilla RIN13
              if("0".equals(codigo)){//si se elimina el codigo debo marcalo como eliminad
            	  //el codigo del convenio seria el mismo pero eliminados 
            	  mapConvenio2.put("IND_DEL", "1");
              }else{
            	  //si es un codigo real se chanca sobre el que ya existe
            	  mapConvenio2.put("COD_CONVENIO", codigo);
            	  mapConvenio2.put("IND_DEL", "0");//P46 - se activa porque sino queda inactivado
              }
              
              //FIN AMANCILLA RIN13
                                          
              encontrado = true;
              break;
            }
          }
        }
      }
    }
      if (!StringUtils.isEmpty(codigo.trim()) && !encontrado)
      {
        if (CollectionUtils.isEmpty(lista))
        {
          lista = new ArrayList<Map<String, Object>>();
        }
        Map mapa = new HashMap();
        mapa.put("COD_CONVENIO", codigo);
        mapa.put("NUM_SECSERIE", new Long(codSerie));
        mapa.put("IND_DEL", "0");
        mapa.put("COD_TIPCONVENIO", tipo);
        mapa.put("NUM_CORREDOC", new Long(codDoc));
        lista.add(mapa);
      }

    return lista;
  }

  public List<Map<String, Object>> obtenerLstSeriesItem(
      List<Map<String, Object>> lstSeriesItemSession,
      Map<String, Object> param)
      throws Exception
  {
    List<Map<String, Object>> lstReturn = new ArrayList<Map<String, Object>>();

    List<Map<String, Object>> lstSeriesItem = obtenerSeriesItem(param);
    boolean existe;
    if (!CollectionUtils.isEmpty(lstSeriesItem))
      for (Map<String, Object> seriesItem : lstSeriesItem)
      {
        existe = false;
        if (!CollectionUtils.isEmpty(lstSeriesItemSession))
          for (Map<String, Object> seriesItemS : lstSeriesItemSession)
            if (seriesItem.get("NUM_SECITEM").toString().equals(seriesItemS.get("NUM_SECITEM").toString())
                && seriesItem.get("NUM_SECSERIE").toString().equals(seriesItemS.get("NUM_SECSERIE").toString()))
            {
              existe = true;
              break;
            }
        if (!existe)
        {
          lstReturn.add(seriesItem);
        }
      }

    if (!CollectionUtils.isEmpty(lstSeriesItemSession))
    {
      for (Map<String, Object> seriesItemS : lstSeriesItemSession)
      {
        lstReturn.add(seriesItemS);
      }
    }

    return lstReturn;
  }

  public List<Map<String, Object>> obtenerSeriesItem(Map<String, Object> params)
      throws ServiceException
  {
    List<Map<String, Object>> lstSeriesItem = new ArrayList<Map<String, Object>>();
// comentado CU 14.16    
//    lstSeriesItem = seriesItemDAO.select(params);
//inicio CU 14.16
      lstSeriesItem = seriesItemDAO.listItemSeriesItem(params);
//fin CU 14.16
      
    for (Map<String, Object> seriesItem : lstSeriesItem)
    {
      Object num_secItem = seriesItem.get("NUM_SECITEM");
      seriesItem.put("c", num_secItem);
      seriesItem.put("n", num_secItem);
    }
    return lstSeriesItem;
  }

  /**
   * actualiza el estado IND_DEL=est_secserie de los documentos de la serie
   * num_secserie cuando eliminan o recuperan la serie
   * @param lstDetAutorizacion
   * @param lstDocAutAsociado
   * @param lstCabCertiOrigen
   * @param num_secserie
   * @param est_secserie
   */
  private void actualizarEstadoDocumentosAutorizantes(
      List<Map<String, Object>> lstDetAutorizacion,
      List<Map<String, Object>> lstDocAutAsociado,
      List<Map<String, Object>> lstCabCertiOrigen,
      String num_secserie,
      String est_secserie)
  {

    // listado de los documento afectados se captura los campos identicadores de
    // la tbla lstDocAutAsociado
    // los campos tomados NUM_SECDOC,COD_TIPOPER ejemplo 1C o 1P pq el
    // NUM_SECDOC numera secuencialmente segun el tipo
    // pueden haber 1C y 1P
    List<Map<String, String>> lstSecDoc = new ArrayList<Map<String, String>>();

    // actualizamos el estado de documentos de la serie seleccionada
    if (!CollectionUtils.isEmpty(lstDetAutorizacion))
    {
      for (Map mapDetAutorizacion : lstDetAutorizacion)
      {
        if (num_secserie.equals(mapDetAutorizacion.get("NUM_SECSERIE").toString()))
        {
          mapDetAutorizacion.put("IND_DEL", est_secserie);

          Map<String, String> mapSecDoc = new HashMap<String, String>();
          mapSecDoc.put("NUM_SECDOC", mapDetAutorizacion.get("NUM_SECDOC").toString());
          mapSecDoc.put("COD_TIPOPER", mapDetAutorizacion.get("COD_TIPOPER").toString());
          lstSecDoc.add(mapSecDoc);

        }
      }
    }

    // Existe referencia a la serie seleccionada de documentos (solo de la serie
    // marcada)
    // lstSecDoc documento de la serie marcada
    if (!CollectionUtils.isEmpty(lstSecDoc))
    {
      // Si es unico se elimina, en caso contrario se deja todo igual
      for (Map<String, String> mapSecDoc : lstSecDoc)
      {
        int conteo = 0;
        // verificamos si el documento tiene referencia en otras series pero
        // solo a los registros activos IND_DEL=0
        if (!CollectionUtils.isEmpty(lstDetAutorizacion))
        {
          for (Map<String, Object> mapDet : lstDetAutorizacion)
          {
            if (mapSecDoc.get("NUM_SECDOC").equals(mapDet.get("NUM_SECDOC").toString())
                && mapSecDoc.get("COD_TIPOPER").equals(mapDet.get("COD_TIPOPER").toString())
                && "0".equals(mapDet.get("IND_DEL").toString()))
            {

              conteo++;
            }
          }
        }
        // regla01 solo si el estado es eliminado=1 y
        // el documento esta relacionado a 1 serie relacion 1-1 => propagar la
        // ELIMINACION IND_DEL a las otras tablas
        // el documento esta relacionado a varias serie relacion N-1 => NO
        // propagar el IND_DEL a las otras tablas
        // regla02 solo si el estado es activar=0 y
        // el documento esta relacionado a 1 o mas serie relacion 1oN-1Doc =>
        // propagar RECUPERACION el IND_DEL a las otras tablas
        if (("1".equals(est_secserie) && (conteo == 0)) || ("0".equals(est_secserie) && (conteo > 0)))
        {
          if (!CollectionUtils.isEmpty(lstDocAutAsociado))
          {
            for (Map mapDocAutAsociado : lstDocAutAsociado)
            {
              if (mapSecDoc.get("NUM_SECDOC").equals(mapDocAutAsociado.get("NUM_SECDOC").toString())
                  && mapSecDoc.get("COD_TIPOPER").equals(mapDocAutAsociado.get("COD_TIPOPER").toString()))
              {

                mapDocAutAsociado.put("IND_DEL", est_secserie);
                break; // sale pq en esta tabla el documento 1P o 1C es unico
              }
            }
          }
          // entra a certificado de origen solo si es del tipo C
          if (!CollectionUtils.isEmpty(lstCabCertiOrigen) && "C".equals(mapSecDoc.get("COD_TIPOPER")))
          {
            for (Map mapCabCertiOrigen : lstCabCertiOrigen)
            {
              if (mapSecDoc.get("NUM_SECDOC").equals(mapCabCertiOrigen.get("NUM_SECDOC").toString()))
              {

                mapCabCertiOrigen.put("IND_DEL", est_secserie);
                break; // sale pq en esta tabla el NUM_SECDOC documento es unico
              }
            }
          }
        }
      }
    }
  }

  
  /*INICIO - RIN13*/  
  /*public List<Map<String, Object>>  obtenerListaNumeroDocTransporteByDeclaracion(String numCorredoc)  throws ServiceException  
  {
	  List<Map<String, Object>> lstNumDocTransporteByDeclaracion = new ArrayList<Map<String, Object>>();	  
	  Map<String, Object> param = new HashMap<String, Object>();
	  param.put("NUM_CORREDOC", numCorredoc);	
	  param.put("IND_DEL", "0");	  
	  lstNumDocTransporteByDeclaracion = detDeclaraDAO.findNumDocTranspByNumCorreDoc(param);	  
	  return lstNumDocTransporteByDeclaracion;  
	  
  }*/
  /*FIN - RIN13*/ 
  
  
  /**
   * Obtenemos las series eliminadas desde el det_declara
   * @param listaSeriesDetDeclara
   * @return
   */
  private List<Map<String, Object>> getSeriesEliminadasDetDeclara(List<Map<String, Object>> listaSeriesDetDeclara)
  {
    // obtenemso las series eliminadas de det_declara
    List<Map<String, Object>> listaSeriesDetDeclaraEliminada = new ArrayList<Map<String, Object>>(listaSeriesDetDeclara);
    org.apache.commons.collections.CollectionUtils.filter(listaSeriesDetDeclaraEliminada, new Predicate()
    {
      @Override
      public boolean evaluate(Object itemLista)
      {
        Map<String, Object> itemMap = (Map<String, Object>) itemLista;
        String indicadorEliminado = (String) itemMap.get("IND_DEL");

        return Constantes.IND_ELIMINADO.equalsIgnoreCase(indicadorEliminado);
      }
    });
    return listaSeriesDetDeclaraEliminada;
  }

  /**
   * Obtener las series eliminas en el proceso de diligencia (Todos los tipos de
   * diligencia) se busca en el det_ofirecti
   * @param numCorredoc numero correlativo de la dua
   * @return
   */
  private List<Map<String, Object>> getSeriesEliminadasOfiRecti(String numCorredoc)
  {
    // buscamos las series eliminadas por las demas diligencias menos las de
    // rectificacion automatica.
    // sino se encuentran en esta lista entonces fueron eliminadas en la
    // rectificacion automatica
    Map<String, Object> parametros = new HashMap<String, Object>();

    parametros.put("codtabla", Constantes.COD_TABLA_DET_DECLARA);
    parametros.put("numcorredoc", numCorredoc);
    // obtenemos las series eliminadas y rectificadas
    List<Map<String, Object>> seriesRectificadasOfiRecti = rectiOficioDAO.findRectiOficioByParams(parametros);
    // obtenemos las series eliminadas de det_ofirecti (eliminadas por alguna
    // diligencia)
    org.apache.commons.collections.CollectionUtils.filter(seriesRectificadasOfiRecti, new Predicate()
    {
      @Override
      public boolean evaluate(Object itemLista)
      {
        Map<String, Object> itemMap = (Map<String, Object>) itemLista;
        String desData = (String) itemMap.get("desdata1");
        desData = desData.trim();

        Map<String, Object> dataMap = (Map<String, Object>) SojoUtil.fromJson(desData);

        String indicadorEliminado = (String) dataMap.get("IND_DEL");
        return Constantes.IND_ELIMINADO.equalsIgnoreCase(indicadorEliminado);

      }
    });
    return seriesRectificadasOfiRecti;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDetAutorizacion(Map<String, String> pkDoc)
      throws ServiceException
  {
    List<Map<String, Object>> listDetAutorizacion = null;
    try
    {
      listDetAutorizacion = detAutorizacionDAO.select(pkDoc);
    }
    catch (Exception e)
    {
      throw new ServiceException(e, e.getMessage());
    }
    return listDetAutorizacion;
  }

  
  //PAS20171U220200016: select de tabla general
  public List<Map<String, Object>> obtenerAllDetAutorizacion(Map<String, String> pkDoc)
	      throws ServiceException
	  {
	    List<Map<String, Object>> listDetAutorizacion = null;
	    try
	    {
	      listDetAutorizacion = detAutorizacionDAO.selectByMapFindByPK(pkDoc);
	    }
	    catch (Exception e)
	    {
	      throw new ServiceException(e, e.getMessage());
	    }
	    return listDetAutorizacion;
	  }
  
  @Override
  public List<Map<String, Object>> select(Map<String, Object> params)
      throws ServiceException
  {
    return detDeclaraDAO.select(params);
  }




  public List<Map<String, Object>> obtenerConvenioSerieMap(Map pkDocu)
  {
    return this.convenioSerieDAO.select(pkDocu);
  }

  public List<Map<String, Object>> findByNumCorreDoc(Map<String, Object> params)
  {
    return detDeclaraDAO.findByNumCorreDoc(params);
  }
  
  /***************************************/

  /** M�todo que valida si una correlaci�n puede ser activada o recuperada
 * @param est_secserie
 * @param serieItem
 * @param params
 * @return
 */
private boolean validarActivarInactivarCorrelacion(String est_secserie, Map<String, Object> serieItem, Map<String,Object> params){
	  
	  boolean indicadorCambioEstado = false;
	  List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)params.get("lstSeriesItem");
      if(!"1".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_CORRELACION_REMOVIDA"))) 
              && !this.validarSerieItemAntEliminada(serieItem, lstSeriesItemAnt)){
	            
    	  indicadorCambioEstado = true;
      }
    return indicadorCambioEstado;
 }

  /**M�todo que valida si una correlacion "serieItem" preexiste en base de datos y si est� eliminada
 * @param serieItem [Map<String,Object>]
 * @param lstSeriesItemAnt [List<Map<String, Object>>]
 * @return
 */
 private boolean validarSerieItemAntEliminada(Map<String,Object> serieItem, List<Map<String, Object>> lstSeriesItemAnt){
	 
	   boolean indicador = false;
			for(Map<String, Object> serieItemAnt : lstSeriesItemAnt){
				if(serieItemAnt.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
					&& serieItemAnt.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())
					&& "1".equals(serieItemAnt.get("IND_DEL").toString())){
						  
					indicador = true;
					break;
				}
			}
			
	   return indicador;
	   
  }

 /** Actualiza el indicador de item "IND_DEL_ITEM" en la correlaci�n(serieItem) seg�n el check(marcado=eliminar, desmarcado=recuperar)  
  * del item asociado a la serie,
  * elimina el �tem si el check es true, recupera el �tem si el indicador IND_DEL_ITEM=1 y de acuerdo al estado de la serie
 * @param lstSeriesItemActual [List<Map<String,Object>>]
 * @param parametro [Map<String, Object>]
 * @param declaracionActual [Map<String, Object>]
 * @param serieItemParam [Map<String, Object>]
 */
 private void actualizarEstadoItemFactura(List<Map<String,Object>> lstSeriesItemActual, 
				Map<String, Object> parametro, Map<String, Object> declaracionActual,
				Map<String, Object> serieItemParam){

	Map<String,Object> parametroItem = new HashMap<String,Object>();
	parametroItem.put("NUM_SECITEM", serieItemParam.get("NUM_SECITEM").toString());
	parametroItem.put("NUM_SECFACT", serieItemParam.get("NUM_SECFACT").toString());
	parametroItem.put("NUM_SECPROVE", serieItemParam.get("NUM_SECPROVE").toString());
	parametroItem.put("NUM_CORREDOC", serieItemParam.get("NUM_CORREDOC").toString());
	
	List<Map<String,Object>> lstItemEstCheck = (List<Map<String,Object>>)parametro.get("lstItemEstCheck");

	if(lstSeriesItemActual!=null){
	
		/**Item a Eliminar**/
		if(parametro.get("EST_SECSERIE").toString().equals("1")){
				
				for(Map<String,Object> itemEstCheck : lstItemEstCheck){
					
				 if(itemEstCheck.get("NUM_SECITEM").toString().equals(parametroItem.get("NUM_SECITEM").toString())){
						
					for(Map<String,Object> serieItem : lstSeriesItemActual){
						if(itemEstCheck.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())
							&& parametro.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())){
								
							/**Correlaciones inactivadas sin marcar el Item**/
							//Estas correlaciones no incrementar�n la cantidad del item al ser recuperadas
							if(!Boolean.parseBoolean(itemEstCheck.get("EST_CHECK").toString())){
								serieItem.put("IND_DEL_ITEM", "0");
								break;
								
												/**Correlaciones inactivadas con item marcado**/	
							}else if(Boolean.parseBoolean(itemEstCheck.get("EST_CHECK").toString())){

								Map<String,Object> param = new HashMap<String,Object>();
								param.put("NUM_SECSERIE", parametro.get("NUM_SECSERIE").toString());
								param.put("NUM_CORREDOC", parametro.get("NUM_CORREDOC").toString());
								param.put("lstSeriesItem", parametro.get("lstSeriesItem"));
								
								int numCorrelaciones = this.contarCorrelacionesItemEnOtrasSeries(lstSeriesItemActual, param, itemEstCheck);
								if(numCorrelaciones == 0){
									serieItem.put("IND_UNICA_CORRELACION", "0");//Unica Correlacion
								}else{
									serieItem.put("IND_UNICA_CORRELACION", "1");
								}
								
								serieItem.put("IND_DEL_ITEM", "1");
								this.eliminarRecuperarItemMarcadoPorSerie(parametroItem, declaracionActual, parametro, 
										 lstSeriesItemActual);
								break;
							}
						}
					}
					break;
				  }
					
			    }				
				
		/**Item a RECUPERAR **/
		}else if(parametro.get("EST_SECSERIE").toString().equals("0")){
		
					for(Map<String, Object> serieItem : lstSeriesItemActual){
					  if(serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
						&& parametroItem.get("NUM_SECITEM").toString().equals(serieItem.get("NUM_SECITEM").toString())){
							
							if("1".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_DEL_ITEM")))){
								this.eliminarRecuperarItemMarcadoPorSerie(parametroItem, declaracionActual, parametro, 
										 lstSeriesItemActual);
							}
							serieItem.put("IND_DEL_ITEM", "0");
							serieItem.put("IND_UNICA_CORRELACION", "");
							break;
						}
					}
		 }
		
		this.actualizarCorrelacionesAsociadasPorItem(declaracionActual, parametroItem, lstSeriesItemActual);
	}
	
  }
	
  /** Cuenta el n�mero de correlaciones del �tem en otras series diferente de la serie buscada
  * @param lstSeriesItemActual [List<Map<String,Object>>]
  * @param parametro [Map<String, Object>]
  * @param item [Map<String,Object>]
  * @return [int] numero de correlaciones
  */
   private int contarCorrelacionesItemEnOtrasSeries(List<Map<String,Object>> lstSeriesItemActual, Map<String, Object> parametro,
				  Map<String,Object> item){
	   
	List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)parametro.get("lstSeriesItem");   
	int numCorrelaciones = 0;
	for(Map<String,Object> serieItem : lstSeriesItemActual){
	
	if(!serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
	&& serieItem.get("NUM_CORREDOC").toString().equals(parametro.get("NUM_CORREDOC").toString())
	&& serieItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())
	&& !"1".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_CORRELACION_REMOVIDA")))
	&& !this.indicarCorrelacionPreExistenteEliminada(serieItem, lstSeriesItemAnt)){
	
	numCorrelaciones++;
	}
	}	  
	return numCorrelaciones;
  }

   /** Verifica si una correlacion(serieItem) que se tiene en sesi�n est� registrada como eliminada en base de datos 
    * @param seriesItem [Map<String,Object>]
    * @param lstSeriesItemAnt [List<Map<String, Object>>]
    * @return [boolean] Indicador
    */
    private boolean indicarCorrelacionPreExistenteEliminada(Map<String,Object> seriesItem, List<Map<String, Object>> lstSeriesItemAnt){
	   
	   boolean indicador = false;
			for(Map<String, Object> serieItemAnt : lstSeriesItemAnt){
				if(serieItemAnt.get("NUM_SECITEM").toString().equals(seriesItem.get("NUM_SECITEM").toString())
					&& serieItemAnt.get("NUM_SECSERIE").toString().equals(seriesItem.get("NUM_SECSERIE").toString())
					&& "1".equals(serieItemAnt.get("IND_DEL").toString())){
						  
					indicador = true;
					break;
				}
			}
			
	   return indicador;
	   
    }

  /** M�todo que filtra las facturas(para no repetir) de las cuales se recalcular� el monto
 * @param lstSeriesItemActual
 * @param declaracionActual
 * @param parametro
 */
private void actualizarMontoFacturas(List<Map<String,Object>> lstSeriesItemActual,
				Map<String, Object> declaracionActual, Map<String, Object> parametro){

	List<Map<String, Object>> lstSeriesItemAnt = (List<Map<String, Object>>)parametro.get("lstSeriesItem");
	List<Map<String,Object>> listCorrelaciones = new ArrayList<Map<String,Object>>();
	
	for(Map<String,Object> serieItem : lstSeriesItemActual){
		if(parametro.get("NUM_SECSERIE").toString().equals(serieItem.get("NUM_SECSERIE").toString())
		&& !"1".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_CORRELACION_REMOVIDA")))
		&& !this.validarSerieItemAntEliminada(serieItem, lstSeriesItemAnt)){
			
			listCorrelaciones.add(serieItem);
		}  
	}
	List<Map<String,Object>> lstFacturas = this.filtrarFacturas(listCorrelaciones);
	
	List<Map<String, Object>> lstFormBProveedor = (ArrayList) declaracionActual.get("lstFormBProveedor");
	
	for(Map<String,Object> factura : lstFacturas){
	
	//Actualiza Monto de la Factura
	this.actualizarMtoFacturaConDatosDeItem(lstFormBProveedor, factura);
	}
	
  }	

  /** M�todo que elimina/recupera el item con sus listas asociadas, resta o incrementa la cantidad Unitaria y Monto Fob del item, seg�n se elimine o recupere
 * @param lstSeriesItemActual
 * @param item
 * @param parametro
 */
private void eliminarRecuperarItemYlistasAsociadas(List<Map<String,Object>> lstSeriesItemActual, 
		  Map<String,Object> item, Map<String, Object> parametro){
		  
		  BigDecimal varCntMercActivo = BigDecimal.ZERO;
		  BigDecimal varCntMercInactivo = BigDecimal.ZERO;
		  BigDecimal cntMercDisponible = BigDecimal.ZERO;
		  BigDecimal totalCntUni = BigDecimal.ZERO;
		  BigDecimal sumaVarCntMerc = BigDecimal.ZERO;
		  BigDecimal varMtoFob = BigDecimal.ZERO;
		  int numCorrelacionesActivas = 0;
		  Map<String,Object> msgItem = new HashMap<String,Object>();
		  boolean indUnicaCorrelacion = false;
		  
		  //Eliminar
		  if(parametro.get("EST_SECSERIE").toString().equals("1")){
		  
			  
			  for(Map<String,Object> serieItem : lstSeriesItemActual){
				  //parte cntMerc activa en las correlaciones para el item en curso
				  if(!serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
				     && serieItem.get("NUM_CORREDOC").toString().equals(parametro.get("NUM_CORREDOC").toString())
					 && serieItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())
					 && "0".equals(serieItem.get("IND_DEL").toString())){
				  
					  varCntMercActivo = varCntMercActivo.add(Utilidades.toBigDecimal(serieItem.get("CNT_MERC")));
					  numCorrelacionesActivas++;
				  }
			 }
			  for(Map<String,Object> serieItem : lstSeriesItemActual){
				  
				  //parte cntMerc eliminado en la correlacion para el item en curso
				  if(serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
					&& serieItem.get("NUM_CORREDOC").toString().equals(parametro.get("NUM_CORREDOC").toString())
					&& serieItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())
					&& "1".equals(serieItem.get("IND_DEL").toString())){
					  
					  varCntMercInactivo = Utilidades.toBigDecimal(serieItem.get("CNT_MERC"));
					  if("0".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_UNICA_CORRELACION"))) ){
						  indUnicaCorrelacion = true;
					  }
					  break;
				  }


			  }
			  
			  if(!indUnicaCorrelacion){
				sumaVarCntMerc = varCntMercActivo.add(varCntMercInactivo);
				cntMercDisponible = Utilidades.toBigDecimal(item.get("CNT_UNI")).subtract(sumaVarCntMerc);
				totalCntUni = cntMercDisponible.add(varCntMercActivo);
				item.put("CNT_UNI", totalCntUni);
				varMtoFob = Utilidades.toBigDecimal(item.get("MTO_FOBUNITARIO")).multiply(Utilidades.toBigDecimal(item.get("CNT_UNI")));
				item.put("MTO_FOBITEM", varMtoFob.toString());
			  }
			 if(numCorrelacionesActivas == 0 || indUnicaCorrelacion){
				 item.put("IND_DEL", parametro.get("EST_SECSERIE").toString());
			  	 if(item.get("lstDecrMinima")!=null && !item.get("lstDecrMinima").toString().isEmpty()){
	  				List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>) item.get("lstDecrMinima");
			  		for(Map<String,Object> fobDescri : lstDecrMinima){
			  			fobDescri.put("COD_USUMODIF", parametro.get("usuario"));
			  			fobDescri.put("IND_DEL", parametro.get("EST_SECSERIE").toString());
			  		}
			  	 }

			 }
			 
		 //Recuperar
		}else if(parametro.get("EST_SECSERIE").toString().equals("0")){
			
			  BigDecimal varCntMercActivoEnOtraSerie = BigDecimal.ZERO;
			  indUnicaCorrelacion = false;
			  for(Map<String,Object> serieItem : lstSeriesItemActual){
				  //parte activa en la correlacion actual
				  if(serieItem.get("NUM_CORREDOC").toString().equals(parametro.get("NUM_CORREDOC").toString())
					 && serieItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())
				     && serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
					 && "0".equals(serieItem.get("IND_DEL").toString())){
					  
					  varCntMercActivo = Utilidades.toBigDecimal(serieItem.get("CNT_MERC"));
					  if("0".equals(Utilidades.validarNuloOVacioRetornaString(serieItem.get("IND_UNICA_CORRELACION"))) ){
						  indUnicaCorrelacion = true;
					  }
					  break;
				  }
			  }
			  
			  if(!indUnicaCorrelacion){
			  totalCntUni = Utilidades.toBigDecimal(item.get("CNT_UNI")).add(varCntMercActivo);
			  
			  item.put("CNT_UNI", totalCntUni);
			  varMtoFob = Utilidades.toBigDecimal(item.get("MTO_FOBUNITARIO")).multiply(Utilidades.toBigDecimal(item.get("CNT_UNI")));
			  item.put("MTO_FOBITEM", varMtoFob.toString());
	        }
			  item.put("IND_DEL", parametro.get("EST_SECSERIE").toString());
			  
		  	  if(item.get("lstDecrMinima")!=null && !item.get("lstDecrMinima").toString().isEmpty()){
  				List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>) item.get("lstDecrMinima");
		  		for(Map<String,Object> fobDescri : lstDecrMinima){
		  			fobDescri.put("COD_USUMODIF", parametro.get("usuario"));
		  			fobDescri.put("IND_DEL", parametro.get("EST_SECSERIE").toString());
		  		}
		  	  }

		}
  }

  /** M�todo que busca el item a ser eliminado o recuperado
 * @param parametroItem
 * @param declaracionActual
 * @param parametro
 * @param lstSeriesItemActual
 */
private void eliminarRecuperarItemMarcadoPorSerie(Map<String,Object> parametroItem, 
	  		Map<String, Object> declaracionActual, Map<String, Object> parametro, List<Map<String,Object>> lstSeriesItemActual){
    
		  List<Map> lstProve = (ArrayList) declaracionActual.get("lstFormBProveedor");
		  for (Map prov : lstProve){
		    String codProv = prov.get("num_secprove").toString().trim();
		    if (codProv.equals(parametroItem.get("NUM_SECPROVE").toString())){
		    
		      List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
		      for (Map comPago : lstComproBPago){
		    	 
		        String secFact = comPago.get("num_secfact").toString().trim();
		        if (secFact.equals(parametroItem.get("NUM_SECFACT").toString())){
		        	
		         for(Map<String, Object> item : (List<Map<String, Object>>) comPago.get("lstItemFactura")){
		        	
		        	 if(parametroItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())) {

		        		 this.eliminarRecuperarItemYlistasAsociadas(lstSeriesItemActual, item, parametro);
		        		 return;			
		 		     }
		         }
		        }
		      }
		    }
		
		  }
   }

  /** M�todo que recalcula los montos de la factura seg�n el acumulado del monto Fob de los items activos correlacionados 
 * @param lstFormBProveedor
 * @param mapPkSelecionadosParaModificar
 * @return [List<Map<String, Object>>] Lista de Proveedores
 */
private List<Map<String, Object>> actualizarMtoFacturaConDatosDeItem(List<Map<String, Object>> lstFormBProveedor,
                                            Map<String, Object> mapPkSelecionadosParaModificar){

  if (!CollectionUtils.isEmpty(lstFormBProveedor)
      && !CollectionUtils.isEmpty(mapPkSelecionadosParaModificar))
  {

    String numSecProveSelec = mapPkSelecionadosParaModificar.get("NUM_SECPROVE").toString().trim();
    String numSecFactSelec = mapPkSelecionadosParaModificar.get("NUM_SECFACT").toString().trim();

    for (Map<String, Object> mapProveedor : lstFormBProveedor)
    {
      String numSecProve = mapProveedor.get("num_secprove").toString().trim();
      List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) mapProveedor.get("lstComproBPago");
      if (numSecProveSelec.equals(numSecProve) && !CollectionUtils.isEmpty(lstComproBPago))
      {

        for (Map<String, Object> factura : lstComproBPago)
        {
          BigDecimal bgFacturaFobAcum = BigDecimal.ZERO;
          List<Map<String, Object>> listaItemFacturas = (List<Map<String, Object>>) factura.get("lstItemFactura");

          String numSecFact = factura.get("num_secfact").toString();
          if (numSecFactSelec.equals(numSecFact) && !CollectionUtils.isEmpty(listaItemFacturas))
          {
            for (Map<String, Object> itemFactura : listaItemFacturas)
            {
            	if(itemFactura.get("IND_DEL").toString().equals("0")){// CU 14.2O
		           
		           if (itemFactura.get("lstSeriesItem")!=null && !itemFactura.get("lstSeriesItem").toString().isEmpty()){
		        	   
		        	  List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) itemFactura.get("lstSeriesItem");
		              for (Map<String, Object> itemSerie : lstSeriesItem){
		                 if(itemSerie.get("IND_DEL").toString().equals("0")){// CU 14.2O
			                BigDecimal bgFobItemSerie = new BigDecimal(itemSerie.get("MTO_FOB").toString());
			                bgFacturaFobAcum = bgFacturaFobAcum.add(bgFobItemSerie);
		                 }
		              }
		           }
	           }

            }
            factura.put("mto_fact", bgFacturaFobAcum);
          }
        }
      }
    }
   }

    return lstFormBProveedor;
  }

  /** M�todo que actualiza las listas de correlaci�n(seriesItem) asociadas por item seg�n la lista 
 *  de correlaciones generales en session "lstSeriesItemActual" para mantenerlas sincronizadas
 * @param mapCabDeclaraActual
 * @param parametroItem
 * @param lstSerieItemActual
 */
private void actualizarCorrelacionesAsociadasPorItem(Map<String, Object> mapCabDeclaraActual, Map<String,Object> parametroItem, 
			 List<Map<String,Object>> lstSerieItemActual){

		List<Map<String, Object>> lstItemFactura = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> lstSeriesItem = new ArrayList<Map<String, Object>>();
		Map<String, Object> serieItemActual = new HashMap<String, Object>();
		Map<String, Object> serieItemPorItem = new HashMap<String, Object>();
		
		List<Map> lstProve = (ArrayList) mapCabDeclaraActual.get("lstFormBProveedor");
		
			for (Map prov : lstProve){
			String codProv = prov.get("num_secprove").toString().trim();
			
			if (codProv.equals(parametroItem.get("NUM_SECPROVE").toString())){
				List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
				
				for (Map comPago : lstComproBPago){
					String secFact = comPago.get("num_secfact").toString().trim();
					
					if (secFact.equals(parametroItem.get("NUM_SECFACT").toString())){
					
						lstItemFactura = (List<Map<String, Object>>)comPago.get("lstItemFactura");
						if(!CollectionUtils.isEmpty(lstItemFactura)){
						for(Map<String, Object> item : lstItemFactura){
						
						   if(item.get("NUM_SECITEM").toString().equals(parametroItem.get("NUM_SECITEM").toString())){
							//Actualizar
							lstSeriesItem = (List<Map<String, Object>>)item.get("lstSeriesItem");
							
							if(!CollectionUtils.isEmpty(lstSeriesItem)){
								int index = 0;
								for(Map<String, Object> serieItem : lstSeriesItem){
								
									serieItemActual = new HashMap<String, Object>();
									
									Map<String, Object> fbKeys = new HashMap<String, Object>();
									fbKeys.put("NUM_SECSERIE", serieItem.get("NUM_SECSERIE").toString());
									fbKeys.put("NUM_SECITEM", serieItem.get("NUM_SECITEM").toString());
									
									serieItemActual = (Map<String, Object>)Utilidades.obtenerElemento(lstSerieItemActual, fbKeys);
									if(serieItemActual!=null && !serieItemActual.toString().isEmpty()){	  
										
										serieItemPorItem = new HashMap<String, Object>();
										serieItemPorItem = Utilidades.copiarMapa(serieItemActual);
										lstSeriesItem.set(index, serieItemPorItem);
									}
									index++;
								}
							}	
							return;
						   }
						}
					  }
					}
				}
			}
		  }
	  
	}

   /** M�todo que filtra las facturas(sin repetir) de una lista ingresada com par�metro
 * @param lstLista
 * @return
 */
private List<Map<String,Object>> filtrarFacturas(List<Map<String, Object>> lstLista){
		
		  List<Map<String,Object>> lstFactura = new ArrayList<Map<String,Object>>();
		  Map<String,Object> factura = null;
		  Map<String,Object> factResult = null;
		  int index = 0;
		  for(Map<String,Object> item : lstLista){
			  factura = new HashMap<String,Object>();
			  if(index == 0){
				  factura.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
				  factura.put("NUM_SECFACT", item.get("NUM_SECFACT"));
				  factura.put("NUM_SECPROVE", item.get("NUM_SECPROVE"));
				  lstFactura.add(factura);
			  }
			  index++;
			  factura = new HashMap<String,Object>();
			  factura.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
			  factura.put("NUM_SECFACT", item.get("NUM_SECFACT"));
			  factura.put("NUM_SECPROVE", item.get("NUM_SECPROVE"));
			  
			  factResult = Utilidades.obtenerElemento(lstFactura,factura);
			  if(factResult==null || factResult.isEmpty()){
				  lstFactura.add(factura);
			  }
		  }
		  Ordenador.sortDesc(lstFactura, "NUM_SECFACT", Ordenador.ASC);
		  return lstFactura;
  }

  /** M�todo que ordena los items en forma ascendente para mostrarlos en una cadena
 * @param lstItemsRecuperados
 * @return
 */
private String ordenarItemsRecuperados(List<String> lstItemsRecuperados){
	  
	  List<Map<String,Object>> lstItems = new ArrayList<Map<String,Object>>();
	  Map<String,Object> item = new HashMap<String,Object>();
	  String itemsRecuperados= "";
	  if(!CollectionUtils.isEmpty(lstItemsRecuperados)){
		  for(String itemRec : lstItemsRecuperados){
			  item = new HashMap<String,Object>();
			  item.put("NUM_SECITEM", itemRec);
			  lstItems.add(item);
		  }
		    Ordenador.sortDesc(lstItems, "NUM_SECITEM", Ordenador.ASC);
		    for(Map<String,Object> serie : lstItems){
		    	itemsRecuperados = itemsRecuperados + (itemsRecuperados.equals("")?"":", ")+ serie.get("NUM_SECSERIE").toString();
		    }
	  }
	    return itemsRecuperados;
  }
  
    /** M�todo que agrega el indicador del tipo de Formato (de la declaraci�n) a cada serie de la lista 
     * @param params
     * @param list
     * @return
     */
    private List<Map<String, Object>> agregaIndicadorExisteFormatoB(Map<String, Object> params,
			List<Map<String, Object>> list){

	  String indicador = "1";
	  
	  if(this.indicaDeclaracionTieneFormatoB(params)){
		  indicador = "0";
	  }
	  
	  for(Map<String, Object> serie : list){
			serie.put("IND_DECLARACION_FORMATOB", indicador);
			serie.put("IND_SERIE_CORRELACIONADA", indicador);
		}
	  return list;
  }
    //INICIO-bug 20206
	/*private List<Map<String, Object>> agregaPorcentajeAlcohol(
			Map<String, Object> params, List<Map<String, Object>> list) {
	  
	  for(Map<String, Object> serie : list){

      	Map<String, Object> param = new HashMap<String, Object>();
      	param.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));             
      	param.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));      	
      	List<Map<String, Object>> ItemActual = new ArrayList<Map<String, Object>>();      	
      	ItemActual= detAdiImpoconsuDAO.select(param);
		  if (!CollectionUtils.isEmpty(ItemActual))
		  {
			  serie.put("POR_ALCOHOL",ItemActual.get(0).get("POR_ALCOHOL")!=null?ItemActual.get(0).get("POR_ALCOHOL").toString():"0") ;
				}
		  else
		  {
			  serie.put("POR_ALCOHOL","0") ;
      	}
		}
	  return list;
  }   */ 
  //FIN-bug 20206
    
    

  /** M�todo que verifica si una declaraci�n tiene formato B, retorna un indicador
 * @param params
 * @return
 */
private boolean indicaDeclaracionTieneFormatoB(Map<String, Object> params){
		
	List lista = null;
	boolean existeFormatoB = false;
	
	try{
		lista = formBProveedorDAO.findByDocumento(params);
	}
	catch (Exception e)
	{
		log.error("*** ERROR ***", e);
		throw new ServiceException(e, e.getMessage());
	}
	
	if (lista != null && lista.size() > 0){
		existeFormatoB = true;// existe formato B
	}
	return existeFormatoB;
  }


  /*INICIO-P34 FSW AFMA*/
  public boolean declaracionTieneFormatoB(String numCorredocDeclaracion){

    Map params = new HashMap();
    params.put("NUM_CORREDOC",numCorredocDeclaracion);
    params.put("IND_DEL","0");
    return indicaDeclaracionTieneFormatoB(params);
  }

  /*FIN-P34 FSW AFMA*/

  /** M�todo que retorna un mensaje con los �tems recuperados de una serie
 * @param parametro
 * @param lstSeriesItemActual
 * @return
 */
private String mostrarItemsRecuperados(Map<String,Object> parametro, List<Map<String, Object>> lstSeriesItemActual){
	  
	  List<Map<String,Object>> lstItemsRecuperados = new ArrayList<Map<String,Object>>();
	  String cadenaItems = "";
	  String msgItemsRecuperados = "";
	  
		if(parametro.get("EST_SECSERIE").toString().equals("0")){
		  	Map<String,Object> item = new HashMap<String,Object>();
		  	for(Map<String,Object> serieItem : lstSeriesItemActual){
		  		if(serieItem.get("NUM_SECSERIE").toString().equals(parametro.get("NUM_SECSERIE").toString())
		  			&& "0".equals(serieItem.get("IND_DEL").toString()) ){	
		  			item = new HashMap<String,Object>();
		  			item.put("NUM_SECITEM", serieItem.get("NUM_SECITEM"));
		  			lstItemsRecuperados.add(item);
		  		}
		  	}
		  	
		    Ordenador.sortDesc(lstItemsRecuperados, "NUM_SECITEM", Ordenador.ASC);
		  	for(Map<String,Object> itemRecupera : lstItemsRecuperados){
		  		cadenaItems = cadenaItems + (cadenaItems.equals("")?"":", ")+ itemRecupera.get("NUM_SECITEM").toString();
		    }
		  	
		  	boolean existeItemCheck = false;
		  	List<Map<String,Object>> listCheck = (List<Map<String,Object>>)parametro.get("lstItemEstCheck");
		  	for(Map<String,Object> check : listCheck){
		  		if(Boolean.parseBoolean(check.get("EST_CHECK").toString())){
		  			existeItemCheck = true;
		  			break;
		  		}
		  	}
	      	if(existeItemCheck && !cadenaItems.isEmpty()){
	      		msgItemsRecuperados = " Se ha(n) recuperado el(los) item(s) "+cadenaItems;
	        }if(!existeItemCheck && !cadenaItems.isEmpty()){
	        	msgItemsRecuperados = " Se ha(n) recuperado la correlaci�n con el(los) item(s) "+cadenaItems;
	        }
		}
     	
      	return msgItemsRecuperados;

  }
  
    
/**INICIO-RIN13**/

  /**
   * Retorna el listado de n�meros de documentos de transporte de una declaraci�n
   * 
   * @param numeroCorrelativo
   * @return Lista de n�meros de documentos de transporte de una declaraci�n
   * @author gbecerrav
   */
  @Override
  public List<Map<String, Object>> obtenerListaNumeroDocTransporteByDeclaracion(
		  Long numeroCorrelativo) throws ServiceException {
	  Map<String, Object> params = new HashMap<String, Object>();
	  params.put("NUM_CORREDOC", numeroCorrelativo);
	  params.put("IND_DEL", Constantes.IND_NO_ELIMINADO);
	  return this.detDeclaraDAO.findNumDocTranspByNumCorreDoc(params);
  }

/**FIN-RIN13**/

  @Override
  public int obtenerCantidadSeries(Map<String, Object> params)
  		throws ServiceException {
  	return this.detDeclaraDAO.getCantidadSeries(params);
  }  
  
  /***********************SET DE SPRING **********************************/
  public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

  public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO)
  {
    this.detDeclaraDAO = detDeclaraDAO;
  }

  public void setConvenioSerieDAO(ConvenioSerieDAO convenioSerieDAO)
  {
    this.convenioSerieDAO = convenioSerieDAO;
  }

  public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO)
  {
    this.seriesItemDAO = seriesItemDAO;
  }

  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {
    this.rectiOficioDAO = rectiOficioDAO;
  }

  public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO)
  {
    this.detAutorizacionDAO = detAutorizacionDAO;
  }

  public void setFormatoValorService(FormatoValorService formatoValorService)
  {
    this.formatoValorService = formatoValorService;
  }

  public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO)
  {
    this.docuPreceDuaDAO = docuPreceDuaDAO;
  }
public void setMercanciaDispuestaDAO(MercanciaDispuestaDAO mercanciaDispuestaDAO) {
	this.mercanciaDispuestaDAO = mercanciaDispuestaDAO;
}
  //INICIO - RIN14
  public void setMrestriDAO(MrestriDAO mrestriDAO) {
	this.mrestriDAO = mrestriDAO;
  }
  //FIN - RIN14



public void setVehiCeticoService(VehiCeticoService vehiCeticoService) {
	this.vehiCeticoService = vehiCeticoService;
}

public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
	this.formBProveedorDAO = formBProveedorDAO;
  }

public List<Map<String,Object>> selectDetalleDuaPrece(Map<String, String> params)
    throws ServiceException
{
  return detDeclaraDAO.findSeriesByDocumento(params);
}

 // hosorio rin 12 inicio
public List<Map<String, Object>> findNumPartidaSeries(Map<String, ?> params){
	return detDeclaraDAO.findNumPartidaSeries(params);
}

public List<Map<String, Object>> obtenerListaNumeroDocTransporteByDeclaracionYNumDetalle(Long numeroCorrelativo) throws ServiceException 
{
	  Map<String, Object> params = new HashMap<String, Object>();
	  params.put("NUM_CORREDOC", numeroCorrelativo);
	  params.put("IND_DEL", Constantes.IND_NO_ELIMINADO);
	  return this.detDeclaraDAO.findNumDocTranspByNumCorreDocConDetalle(params) ;
}
// hosorio rin 12 fin

//bug 20206
/*public void setdetAdiImpoconsuDAO(DetAdiImpoconsuDAO detAdiImpoconsuDAO) {
	this.detAdiImpoconsuDAO = detAdiImpoconsuDAO;
  }
*/

/*inicio modificaciones gdlr*/
   //nuevo metodo
  @Override
  public List<Map<String, Object>> obtenerSeriesItemByDocumento(Map<String, Object> parametros) throws ServiceException {
	  //en el mismo query hay q darle el formato c, n... pendiente...
	  List<Map<String, Object>> seriesItem = seriesItemDAO.listItemSeriesItem(parametros);
	  return seriesItem;
	      
	    /*for (Map<String, Object> seriesItem : lstSeriesItem) {
	      Object num_secItem = seriesItem.get("NUM_SECITEM");
	      seriesItem.put("c", num_secItem);
	      seriesItem.put("n", num_secItem);
	    }
	    return lstSeriesItem;
	  }*/
  }

  //nuevo metodo...
  private List<Map<String, Object>> obtenerSeries(Map<String, String> params) {
	  String codigoRegimen = (params.get("cod_regimen") != null) ? params.get("cod_regimen") : "";
	  String acceso = (String) params.get("acceso");
	  List<Map<String, Object>> series = null;
	  //En caso de obtener data con descripcion de catalogos para consultas.
	  if (acceso != null && "00".equals(acceso.trim())) {
		  series = detDeclaraDAO.findSeriesByDocumentoAndDescripcionCatalogos(params);
	  } else {
		  if (codigoRegimen != null) {
			  if (codigoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)) {
				  series = detDeclaraDAO.findSeriesByDocumentoReg10(params);
			  } else if (codigoRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)) {
				  series = detDeclaraDAO.findSeriesByDocumentoReg20(params);
			  } else if (codigoRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO)) {
				  series = detDeclaraDAO.findSeriesByDocumentoReg21(params);
			  } else {
				  series = detDeclaraDAO.findSeriesByDocumentoRegOtros(params);
			  }
			  
		  } else {
			  series = detDeclaraDAO.findSeriesByDocumentoRegOtros(params);
	      }
	  }
	  
	  //gdlr: esta logica de quitar los eliminados debe ser revisado ... mejor seria que el mismo query haga la exclusion
	  // si hay series eliminadas por el proceso de rectificacion automatica no
	  // debe mostrase PASE578
	  // para la diligencia de despacho pero si para las demas ya sea revision o
	  // consulta
	  acceso = params.get("acceso") != null ? params.get("acceso") : "";
	  List<Map<String, Object>> listaSerieEliRectiAuto = new ArrayList<Map<String, Object>>();
	  Map<String, Object> serieEliminada = null;
	  //pase153
	  String estadoRectiOficio = params.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null?params.get("COD_ESTADO_RECTIFICACION_OFICIO"):"";

	  if ((Constantes.ESTADO_RECTI_PROCESO.equals(params.get("estadoDUA")) || "EN_PROCESO".equals(estadoRectiOficio)) && !(acceso.equals(Constantes.MODO_DILIGENCIA_CONSULTA))) {
		  // si es diligencia de rectificacion
	      if (params.get("tipoDiligencia") != null && Constantes.TIPO_DILIG_ESTA_RECTIFICACION.equals(params.get("tipoDiligencia"))) {
	    	  listaSerieEliRectiAuto = getSeriesEliminadasRectificacionAutomatica(params.get("num_corredoc"), series);
	    	  
	      } else {
	    	  for (Map<String, Object> mapSerie : series) {
	    		  if (Constantes.IND_ELIMINADO.equals(mapSerie.get("IND_DEL").toString())) {
	    			  serieEliminada = mapSerie;
	    			  listaSerieEliRectiAuto.add(serieEliminada);
	    			  continue;
	    		  }
	    	  }
	      }

	      for (Map<String, Object> mapEliminar : listaSerieEliRectiAuto) {
	    	  series.remove(mapEliminar);
	      }
	      Ordenador.sortDesc(series, "NUM_SECSERIE", Ordenador.ASC);
	  }
	  return series;
  }
  
//en este metodo alternativo de mapearCamposSerie... vamos a evitar consultar a la base datos //PASE 427  Mercancia Dispuesta
  private void mapearCamposSerieNew(Map<String, Object> serie, String codigoRegimen, List<String> partidasConMercanciaRestringida, List<Map<String, Object>> documentosAutorizadosAgrupadosPorSerie, 
		  List<Map<String, Object>> detallesAutorizacion, List<Map<String, Object>> regimenesPrecedencia, List<Map<String,Object>> vehiculos, List<Map<String,Object>> montosGasto, List<Map<String, Object>> facturas,Map<String,Object> params2) {
	  
	  Object numeroSerieAsObject = serie.get("NUM_SECSERIE");
	  
	  if (!StringUtils.isEmpty(codigoRegimen)) {
		  if (!codigoRegimen.equals(Constantes.REGIMEN_70_DEPOSITO)) {
			  Map adImpConsu = new HashMap();
			  adImpConsu.put("MTO_PVPMONNAC", serie.get("MTO_PVPMONNAC") != null ? serie.get("MTO_PVPMONNAC") : 0);
			  adImpConsu.put("DES_ZONAFRANCA", serie.get("DES_ZONAFRANCA") != null ? serie.get("DES_ZONAFRANCA") : ' ');
			  adImpConsu.put("IND_ACOGCODLIBER", serie.get("IND_ACOGCODLIBER") != null ? serie.get("IND_ACOGCODLIBER") : ' ');
			  //ini wtaco se agrega el valor neto FOB pase025
			  adImpConsu.put("MTO_FOBPNETO", serie.get("MTO_FOBPNETO") != null ? serie.get("MTO_FOBPNETO") : ' ');

			  serie.put("mapDetAdiImpoconsu", adImpConsu);
		  }
		  if (codigoRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)) {
			  Map adDetAdiAtreex = new HashMap();
		      adDetAdiAtreex.put("POR_MERMA", serie.get("POR_MERMA") != null ? serie.get("POR_MERMA") : 0);
		      serie.put("mapDetAdiAtreex", adDetAdiAtreex);
		      
		  } else if (codigoRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO) || codigoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)) {/*P28-PAS20155E410000032[jlunah] BUG 3320*/
			  Map adAtpa = new HashMap();
			  adAtpa.put("COD_INSUMO", serie.get("COD_INSUMO") != null ? serie.get("COD_INSUMO") : ' ');
		      adAtpa.put("CNT_UNIEQUI", serie.get("CNT_UNIEQUI") != null ? serie.get("CNT_UNIEQUI") : 0);
		      adAtpa.put("COD_UMEQUI", serie.get("COD_UMEQUI") != null ? serie.get("COD_UMEQUI") : ' ');
		      adAtpa.put("DES_UMEQUI", serie.get("DES_UMEQUI") != null ? serie.get("DES_UMEQUI") : ' ');
		      serie.put("mapDetAdiAtpa", adAtpa);
		  }
	  }

    
	  /*INICIO RIN14 - AGREGO COLUMNA RESTRINGIDA-MERCANCIAS RESTRINGIDAS*/
	  //Map<String, Object> parametroEntrada = new HashMap<String, Object>();
    
	  int todasMercanciasTieneDocumentoControlAutorizante = 0;
	  int todasMercanciasTieneCodigoExoneracion = 0;
    
	  /*Integer intFechaActual = SunatDateUtils.getCurrentIntegerDate();
	  parametroEntrada.put("cnan", serie.get("NUM_PARTNANDI"));
	  parametroEntrada.put("codiregi", codigoRegimen);
	  parametroEntrada.put("fechaVigencia", intFechaActual);*/

	  //GDLR: evitamos una consulta a la tabla MRESTRI por serie
	  //List<MRestri> restringida= mrestriDAO.listMercRestringida(parametroEntrada);
	  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.NO_TIENE_MERCANCIASDECLARADAS_RESTRINGIDAS.getDescripcion());
	  
	  String partidaSerie = serie.get("NUM_PARTNANDI").toString();
	  //if (!CollectionUtils.isEmpty(restringida)) {
	  if (partidasConMercanciaRestringida.contains(partidaSerie)) {
		  /*Map<String, String> pkDocu = new HashMap<String, String>();
		  pkDocu.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
		  pkDocu.put("COD_TIPOPER", "P");
		  pkDocu.put("IND_DEL", "0");
		  pkDocu.put("NUM_SECSERIE",serie.get("NUM_SECSERIE").toString());*/
		  
		  //evitamos otra consulta a base datos por serie a la tabla DET_AUTORIZACION y DOCAUT_ASOCIADO
		  //List<Map<String, Object>> listaDocumentoControlAutorizanteSerie = detAutorizacionDAO.joinDetAutorizacionFindBySerie(pkDocu);//Rin 14 KAH
		  
		  //documentosAutorizadosAgrupadosPorSerie
		  for (Map<String, Object> serieGrupoDocumentos : documentosAutorizadosAgrupadosPorSerie) {
			  if (numeroSerieAsObject.equals(serieGrupoDocumentos.get("NUM_SECSERIE"))) {
				  //entonces verificamos las cantidades...
				  int cantidadMercanciasTieneDocumentoControlAutorizante = new Integer(serieGrupoDocumentos.get("CNT_DOC_CONTROL_AUTORIZ").toString());
				  int cantidadMercanciasTieneCodigoExoneracion = new Integer(serieGrupoDocumentos.get("CNT_COD_EXONERACION").toString());
				  
				  if (cantidadMercanciasTieneDocumentoControlAutorizante > 0 || cantidadMercanciasTieneCodigoExoneracion > 0) {
					  if (cantidadMercanciasTieneDocumentoControlAutorizante > 0 && cantidadMercanciasTieneCodigoExoneracion == 0) {
						  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTO_CONTROL_AUTORIZANTE.getDescripcion());
						  
					  } else if (cantidadMercanciasTieneCodigoExoneracion > 0 && cantidadMercanciasTieneDocumentoControlAutorizante == 0) {
						  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_CODIGO_EXONERACION.getDescripcion());
						  
					  } else {
						  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTOCONTROLAUTORIZANTE_Y_CODIGOEXONERACION.getDescripcion());
					  }
				  }
			  }
		  }
		  /*if (!CollectionUtils.isEmpty(listaDocumentoControlAutorizanteSerie)){
			  for (Map<String, Object> documento : listaDocumentoControlAutorizanteSerie) {
				  if(!StringUtils.isEmpty(documento.get("COD_TIPDOCASO").toString().trim()) && !StringUtils.equals(documento.get("COD_TIPDOCASO").toString().trim(),"98")) {
					  todasMercanciasTieneDocumentoControlAutorizante++;
				  } else {
    				todasMercanciasTieneCodigoExoneracion++;
				  }
			  }
			  
			  if (listaDocumentoControlAutorizanteSerie.size()==todasMercanciasTieneDocumentoControlAutorizante) {
				  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTO_CONTROL_AUTORIZANTE.getDescripcion());
				  
			  } else if(listaDocumentoControlAutorizanteSerie.size()==todasMercanciasTieneCodigoExoneracion) {
				  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_CODIGO_EXONERACION.getDescripcion());
			  } else {
				  serie.put("MERCANCIA_RESTRINGIDA", Constantes.agregarColumnaRestringida.TIENE_DOCUMENTOCONTROLAUTORIZANTE_Y_CODIGOEXONERACION.getDescripcion());
			  }
		  }*/
	  }
	  /*FIN RIN14 - AGREGO COLUMNA RESTRINGIDA-MERCANCIAS RESTRINGIDAS*/
    
	  List lstConvenio = new ArrayList();
	  if (serie.get("COD_CONVENIO_CI") != null) {
		  Map mapCI = new HashMap();
		  mapCI.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
		  mapCI.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
		  mapCI.put("COD_CONVENIO", serie.get("COD_CONVENIO_CI"));
		  mapCI.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CI"));
		  mapCI.put("IND_DEL", "0");
		  lstConvenio.add(mapCI);
	  }

	  if (serie.get("COD_CONVENIO_CT") != null) {
		  Map mapCT = new HashMap();
		  mapCT.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
		  mapCT.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
		  mapCT.put("COD_CONVENIO", serie.get("COD_CONVENIO_CT"));
		  mapCT.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CT"));
		  mapCT.put("IND_DEL", "0");
		  lstConvenio.add(mapCT);
	  }

	  if (serie.get("COD_CONVENIO_CC") != null) {
		  Map mapCC = new HashMap();
		  mapCC.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
		  mapCC.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
		  mapCC.put("COD_CONVENIO", serie.get("COD_CONVENIO_CC"));
		  mapCC.put("COD_TIPCONVENIO", serie.get("COD_TIPCONVENIO_CC"));
		  mapCC.put("IND_DEL", "0");
		  lstConvenio.add(mapCC);
	  }

	  serie.put("lstConvenioSerie", lstConvenio);

	  Map<String, String> param = new HashMap<String, String>();
	  param.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
	  param.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());// NUM_SECPROVE
	  param.put("IND_DEL", "0");
	  
	  //GDLR: evitamos otra consulta a base datos tabla DET_AUTORIZACION
	  //List lstDetAutorizacion = obtenerDetAutorizacion(param);
	  List<Map<String, Object>> detallesAutorizacionDeSerie = new ArrayList<Map<String, Object>>();
	  for (Map<String, Object> detalleAutorizacion : detallesAutorizacion) {
		  if (numeroSerieAsObject.equals(detalleAutorizacion.get("NUM_SECSERIE"))) {
			  detallesAutorizacionDeSerie.add(detalleAutorizacion);
		  }
	  }
	  List<Map<String, Object>> lstDetAutorizacion = detallesAutorizacionDeSerie;
	  
	  //GDLR: evitamos otra consulta a base datos tabla DOCUPRECE_DUA
	  //List lstDocuPreceDua = obtenerRegPrecedencia(param);
	  List<Map<String, Object>> precedentesDeSerie = new ArrayList<Map<String, Object>>();
	  for (Map<String, Object> precedente : regimenesPrecedencia) {
		  if (numeroSerieAsObject.equals(precedente.get("NUM_SECSERIE"))) {
			  precedentesDeSerie.add(precedente);
		  }
	  }
	  List<Map<String, Object>> lstDocuPreceDua = precedentesDeSerie;
	  
	  //jenciso Inicio ceticos parte1
	  Map<String, Object> params = new HashMap<String, Object>();
	  params.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
	  params.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());// NUM_SECPROVE
	  params.put("IND_DEL", "0");
	  //List<DatoVehiculo> lstDatoVehiculo = vehiCeticoService.findVehiculoByMap(params);
	  //List<DatoMontoGasto> lstDatoMontoGasto = vehiCeticoService.findMontoGastoByMap(params);
	  //gdlr:evitamos otra consulta a la base datos VEHI_CETICO
	  //List<Map<String,Object>> lstDatoVehiculo = vehiCeticoService.selectVehiCetico(params);
	  List<Map<String, Object>> vehiculosSerie = new ArrayList<Map<String, Object>>();
	  for (Map<String, Object> vehiculo : vehiculos) {
		  if (numeroSerieAsObject.equals(vehiculo.get("NUM_SECSERIE"))) {
			  vehiculosSerie.add(vehiculo);
		  }
	  }
	  List<Map<String, Object>> lstDatoVehiculo = vehiculosSerie;
	  
	  //gdlr: evitamos otra consulta a la base datos tabla MONTOGASTO
	  //List<Map<String,Object>> lstDatoMontoGasto = vehiCeticoService.selectMontoGasto(params);
	  List<Map<String, Object>> montosGastoSerie = new ArrayList<Map<String, Object>>();
	  for (Map<String, Object> montoGasto : montosGasto) {//2015 - es montoGasto la lista correcta PAS20145E220000164 
		  if (numeroSerieAsObject.equals(montoGasto.get("NUM_SECSERIE"))) {
			  montosGastoSerie.add(montoGasto);
		  }
	  }
	  List<Map<String, Object>> lstDatoMontoGasto = montosGastoSerie;
	  
	  
	  serie.put("lstDatoVehiculo", lstDatoVehiculo);
	  serie.put("lstDatoMontoGasto", lstDatoMontoGasto);
	  //jenciso Fin
	  //jenciso Inicio ceticos parte2
	  StringBuilder precedenteCeticos = new StringBuilder("");
	  if (lstDocuPreceDua!=null && lstDocuPreceDua.size()>0) {
		  Map mapPrecedencia = (Map)lstDocuPreceDua.get(0);
		  if (mapPrecedencia.get("COD_REGIMENPRE") != null && mapPrecedencia.get("COD_REGIMENPRE").toString().equals("91")){
    		
			  precedenteCeticos= precedenteCeticos.append(mapPrecedencia.get("COD_ADUANAPRE").toString()).append("-")
    				.append(mapPrecedencia.get("ANN_PRESENPRE").toString()).append("-")
    				.append(mapPrecedencia.get("COD_REGIMENPRE").toString()).append("-")
    				.append(mapPrecedencia.get("NUM_DECLARACIONPRE").toString());
    		
		  }
	  }
	  serie.put("PRECED_CETICOS",precedenteCeticos.toString());
	  //jenciso Fin ceticos parte2
    
	  // amancillaa para que aparesca en todas las pantallas debo cargar los datos
	  // de las facturas junto con FORMA_FACTU y factura_serie

	  // List lstFacturaSerie = facturaSerieDAO.select(param1);
	  // comentado para que carge en session tambien los datos de la factura
	  // impornatente para que al momento de copiar una serie jale los datos de la
	  // factura
	  Map<String, Object> params1 = new HashMap<String, Object>();
	  params1.put("num_corredoc", serie.get("NUM_CORREDOC").toString());
	  params1.put("num_secserie", serie.get("NUM_SECSERIE").toString());
	  
	  //gdlr:evitamos otra consulta a la base datos tabla FACTURA_SERIE
	  //List<Map<String, Object>> lstFacturaSerie = formatoValorService.obtenerFacturasSerie(params1);
	  List<Map<String, Object>> lstFacturaSerie = new ArrayList<Map<String, Object>>();
	  for (Map<String, Object> factura : facturas) {
		  if (numeroSerieAsObject.equals(factura.get("NUM_SECSERIE"))) {
			  lstFacturaSerie.add(factura);
		  }
	  }
	  
	  log.debug("mapearCamposSerie.lstDetAutorizacion:" + lstDetAutorizacion);
	  log.debug("mapearCamposSerie.lstDocuPreceDua:" + lstDocuPreceDua);
	  log.debug("mapearCamposSerie.lstFacturaSerie:" + lstFacturaSerie);
	  serie.put("lstDetAutorizacion", lstDetAutorizacion);
	  serie.put("lstDocuPreceDua", lstDocuPreceDua);
	  serie.put("lstFacturaSerie", lstFacturaSerie);

	  String IND_REGISTRO_GRABADO = "0";

	  String DES_REGISTRO_GRABADO = "Adicionado";
	  // al inicio del cargado de datos de la bd
	  // todos las series ya estan grabadas para este caso no deberia pintar nada
	  // IND_TIPO_REGISTRO hay 2 tipos 0='Grabado en BD' o 1='Pendiente de Grabado'
	  serie.put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);
	  serie.put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);
	  serie.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
	  serie.put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
	  if ("1".equals(serie.get("IND_DEL").toString())) {
		  serie.put("ELIMINADO_PERMANENTE", "BD");
	  } else {
		  serie.put("ELIMINADO_PERMANENTE", "");
	  }
	  // agrego este campo para diferenciar entre el dato agregado y
	  // los que ya existen en la BD
	  // aparentemente los IND_REGISTRO_GRABADO y DES_REGISTRO_GRABADO significan
	  // lo mismo hay que
	  // TODO refactorizar ese codigo tarea pendinte
	  //0 no muestra ninguna descripcion, 1 si muestra la descripcion del  DES_TIPO_REGISTRO
	  serie.put("IND_DESCMANTSERIE", "0");
	  
	  
	  //INICIO PASE 447
	  boolean bloquearEdicionSerie = false;
	    
	    String mensajeBloqueo =" ";
	    String estadoMercDispuesta=" ";
	    
	    //pruizcr p42 consultas 
	    
	    Map<String,Object> paramsRegu = new HashMap<String,Object>();
	    String mensaje = "";
	    paramsRegu.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
	    paramsRegu.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());
	    String numCorreDoc=serie.get("NUM_CORREDOC").toString();
	    //inicio - PASE 427  Mercancia Dispuesta
	    Map<String,String> paramdis = new HashMap<String,String>();
	    paramdis.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
	    paramdis.put("num_secserie", serie.get("NUM_SECSERIE").toString());
	    paramdis.put("NUM_SECSERIE", serie.get("NUM_SECSERIE").toString());
	    int dispMerca =0;
	    boolean tienemercancia = false;
	    paramdis.put("numCorredoc", serie.get("NUM_CORREDOC").toString());
	    Map<String,Object> paramsDUA = new HashMap<String,Object>();
	    paramsDUA.put("NUM_CORREDOC", serie.get("NUM_CORREDOC").toString());
	    Map<String,Object> mapaDUA =    this.cabDeclaraDAO.findMapDUAByPk(paramsDUA);
	    paramdis.put("cod_aduana", mapaDUA.get("COD_ADUANA").toString() );
	    paramdis.put("ann_presen", mapaDUA.get("ANN_PRESEN").toString());
	    paramdis.put("cod_regimen", mapaDUA.get("COD_REGIMEN").toString() );
	    paramdis.put("num_declaracion", mapaDUA.get("NUM_DECLARACION").toString() );
	    paramdis.put("numCorredoc", mapaDUA.get("NUM_CORREDOC").toString());
	    List<Map<String, Object>> ListaSeriesItem = disposicionMercanciaService.obtenerListaSeriesItem(paramdis);

	    //String estadoDUA=params2.get("estadoDUA").toString();
	    //paramdis.put("num_secserie", serie.get("NUM_SECSERIE").toString());	
	    List<Map<String, Object>> listDetalle = selectDetalleDuaPrece(paramdis);
	   // Map<String,Object> paramsItem = new HashMap<String,Object>();
		for (Map<String, Object> paramsSerie : listDetalle) {
			//paramsItem = listDetalle.get(x);
			String tdispo = paramsSerie.get("TIENEDISPO").toString();
			String dispotot = paramsSerie.get("DISPOSICIONTOTAL").toString();//no utilza
		    for (Map<String, Object> paramsItem : ListaSeriesItem) {
		    	dispMerca = Integer.valueOf( paramsItem.get("tieneMercanciaDispuesta").toString());
		    	if(paramsSerie.get("NUM_SECSERIE").toString().equals(paramsItem.get("cod_secserie").toString())){
		    		if ( dispMerca > 0  ) {
			    		tienemercancia = true;
					}else{
						tienemercancia = false;
					}
		    	}
		    }
			if (tdispo.equals("1")) {
				if (tienemercancia){
					//if(estadoDUA.equals("19") || estadoDUA.equals("18")){//solo para cuando 
						  estadoMercDispuesta = "Total";
					 // } 
				  } else {
					  //if(estadoDUA.equals("19")){//solo para cuando 
						  estadoMercDispuesta = "Parcial";
					  //} 
				  }
			}
		}

	    /*String bultoTotalDispuesto=disposicionMercanciaService.validarTotalBultosDispuestosBySerie(paramsRegu).toString();
	  	if (bultoTotalDispuesto != null && !bultoTotalDispuesto.isEmpty()) {
		    String varBultDisp = "";
		    String varBultDecl=serie.get("CNT_BULTO").toString();
		    if(bultoTotalDispuesto.equals(varBultDecl))
		    {
		      bloquearEdicionSerie= true;
		      mensajeBloqueo = "Serie de la declaraci�n se encuentra dispuesta totalmente";
		     // mensajeBloqueo=disposicionMercanciaService.validarDisposicionParcial(paramsRegu);
		      estadoMercDispuesta= "Total";
		      serie.put("bloquearEdicionSerie", bloquearEdicionSerie);
		      serie.put("mensajeBloqueo", mensajeBloqueo);
		    }else if(Integer.parseInt(bultoTotalDispuesto)>0 && Integer.parseInt(bultoTotalDispuesto)<Integer.parseInt(varBultDecl)){
		     //estadoMercDispuesta= "Parcial"; 
		    }
		}*/
		//fin - PASE 427  Mercancia Dispuesta
	    serie.put("EST_MERCDISPUESTA", estadoMercDispuesta);
	    serie.put("bloquearEdicionSerie", bloquearEdicionSerie);
	    serie.put("mensajeBloqueo", mensajeBloqueo);
	  
 //FIN PASE 447
  }
  /*fin modificaciones gdlr*/
  
//Inicio RIN10 mpoblete BUG 22178
public boolean serieTieneValorProvisional(Map<String,Object> serie){
	  boolean tieneValorProvisional = false;	  
	  String numCorreDoc = (String)serie.get("NUM_CORREDOC");
	  String numSerie = (String)serie.get("NUM_SECSERIE");
	  
	  Map<String, Object> paramsFindSerieItem = new HashMap<String,Object>();
	  paramsFindSerieItem.put("NUM_CORREDOC", numCorreDoc);
	  paramsFindSerieItem.put("NUM_SECSERIE", numSerie);
	  
	  List<Map<String, Object>> lstSeriesItem = new ArrayList<Map<String, Object>>();
	  
	  lstSeriesItem = seriesItemDAO.listItemSeriesItem(paramsFindSerieItem);
	  
	  if(CollectionUtils.isEmpty(lstSeriesItem)){return tieneValorProvisional;}
	  
	  VFOBProvisionalDAO vfobProvisionalDAO = fabricaDeServicios.getService("fobProvisionalDAO");
	  Map<String, Object> paramsFindVFobProv = new HashMap<String,Object>();
	  List<Map<String, Object>> listaVFobProv = new ArrayList<Map<String,Object>>();
	  for(Map<String,Object> serieItem :lstSeriesItem){
		  paramsFindVFobProv = new HashMap<String,Object>();
		  paramsFindVFobProv.put("NUM_CORREDOC", numCorreDoc);
		  paramsFindVFobProv.put("NUM_SECITEM", serieItem.get("NUM_SECITEM"));		  		  
		  
		  listaVFobProv = vfobProvisionalDAO.findMapMontoProvByMap(paramsFindVFobProv); 
		  for(Map<String,Object> mapVFobProv:listaVFobProv){
			  if("2".equals(mapVFobProv.get("COD_TIPOVALOR").toString())){
				  return true;
			  }
		  }		  
	  }
	  
	  return tieneValorProvisional;
}
//Fin RIN10 mpoblete BUG 22178
public DisposicionMercanciaService getDisposicionMercanciaService() {
	return disposicionMercanciaService;
}

public void setDisposicionMercanciaService(
		DisposicionMercanciaService disposicionMercanciaService) {
	this.disposicionMercanciaService = disposicionMercanciaService;
}
}
