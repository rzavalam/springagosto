package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.ADUANA_CENTRALIZADA;//<RIN10 />
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.CAT_CODIFICACION_TABLAS;

import java.math.BigDecimal;//rin10
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.saxon.expr.instruct.ValueOf;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;//<RIN10 />
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.CatEmpleadoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO; //<RIN10 /> 3006 ERUESTAA
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.CampoXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumRectifica;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ParserUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;//P34
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.CatCasillaFormatoDAO;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;//<RIN10 />
import pe.gob.sunat.framework.spring.util.lang.Cadena; //<RIN10 /> 3006 ERUESTAA
import pe.gob.sunat.framework.spring.util.security.Hash;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;//<RIN10 />
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;  // P24-bug 24608,24609 ,24610 
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;//P24-152-870 
//P34 3007 JMCV INCIO
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
//P34 3007 JMCV FIN

/**
 * The Class RectificacionServiceImpl.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class RectificacionServiceImpl implements RectificacionService
{

  private static final String TIPO_REGISTRO_NUEVO = "N";
  private static final String TIPO_REGISTRO_MODIFICADO = "M";
  private static final String TIPO_REGISTRO_ELIMINADO = "E";

  private static final String  PROCESO_RECTI_AUTO        = "RECTIFICACION-AUTOMATICA";

  private static final String  PROCESO_RECTI_ELECTRONICA = "RECTIFICACION-ELECTRONICA";

  private static final String  PROCESO_REGULARIZACION    = "DILIGENCIA-REGULARIZACION";

  private static final String  PROCESO_OTRAS_DILIGENCIA  = "DESPACHO-OFICIO-CONCLUSION";

  private static final String  NUEVO_REGISTRO            = TIPO_REGISTRO_NUEVO;

  private static final String  ELIMINAR_REGISTRO         = "A";

  protected final Log          log                       = LogFactory.getLog(this.getClass());

  private DetSolRectiDAO       detSolRectiDAO;

  private CatCasillaFormatoDAO catCasillaFormatoDAO;

  private CatalogoAyudaService catalogoAyudaService;

  private CabSolrectiDAO       cabSolrectiDAO;

  private RectiOficioDAO       rectiOficioDAO;

  private SolicitudService     solicitudService;

  private ParticipanteDocDAO        participanteDocDAO;

  private SoporteMapeoTablasService soporteMapeoTablasService;

  @Autowired
  @Qualifier("diligencia.soporteComparadorService")
  private SoporteComparadorService  soporteComparadorService;

  @Autowired
  @Qualifier("diligencia.ingreso.serieService")
  private SerieService              serieService;


  private DdpDAOService ddpDAOService;
  
  /* inicio ehumareda rin10 */
	private DeudaDocumDAO deudaDocumDAO;
	protected boolean enableSwapperDataSource = true;
	private FabricaDeServicios fabricaDeServicios;
	private HotSwappableTargetSource swapperDatasource;
  /* fin ehumareda rin10 */

   private CabDiligenciaDAO         cabDiligenciaDAO;  //INICIO P24-bug 24608,24609 ,24610 
  /**
   * Retornar array list no nulo.
   *
   * @param objetoNoNulo
   *          the objeto no nulo
   * @return the list
   */
  private List<Map<String, Object>> retornarArrayListNoNulo(Object objetoNoNulo)
  {
    if (objetoNoNulo == null)
    {
      return new ArrayList<Map<String, Object>>();
    }
    return (List<Map<String, Object>>) objetoNoNulo;
  }



private String formatMessage(String mensaje, Object [] argumentos){
    return  MessageFormat.format(mensaje,argumentos);
  }


 //P32 inicio
  
  private String getFuncionarioByDiligencia(String codigoRegistroTrabajador)
  {
	
    FiltroCatEmpleado filtroCatEmpleado = new FiltroCatEmpleado();
    filtroCatEmpleado.setCodPers(codigoRegistroTrabajador);
    	    	      
     Map<String, CatEmpleado> mapCatEmpleado = solicitudService.buscarMapCatEmpleado(filtroCatEmpleado);
     CatEmpleado empleado = mapCatEmpleado.get(codigoRegistroTrabajador);
    StringBuilder sb = new StringBuilder(); 
    if(empleado!=null){
   
    sb.append(empleado.getNombres().trim());
    sb.append(" ");
    sb.append(empleado.getApPate().trim());
    sb.append(" ");
    sb.append(empleado.getApMate().trim());
    }else{
    	sb.append("");
    }
     	    
    return sb.toString().trim();  		
  }
  
  private String tipoDiligencia(String codigo){
		if(codigo.equals("02")||codigo.equals("03")){
			return "DILIGENCIA DE DESPACHO";
		}
		if(codigo.equals("05")){
			return "DILIGENCIA CONCLUSI�N DE DESPACHO";
		}
		if(codigo.equals("06")){
			return "DILIGENCIA DE RECTIFICACI�N";
		}
		if(codigo.equals("10")){
			return "RECTIFICACI�N DE OFICIO";
		}		
		if(codigo.equals("07")){
			return "DILIGENCIA DE REGULARIZACION";
		}
		return "DILIGENCIA DE DESPACHO";
	}
  
  //P32 fin
  /**
   * Metodo que nos permite obtener los datos rectificados por declaracion.
   *
   * @param mapTablas
   *          the map tablas
   * @return Map<String, Object> retorna los valores rectificados de la forma
   *         Valor rectificado, valor Historico
   * @throws ServiceException
   *           the service exception
   */
  public Map<String, Object> obtenerDatosRectificados(Map<String, Object> mapTablas) throws ServiceException
  {
    // mapa que retorna todas las listas rectificadas
    Map<String, Object> data = new HashMap<String, Object>();

    // lista agregadas a mapa data
    List<Object> lstDetDeclara = new ArrayList<Object>();
    List<Object> lstEquipamiento = new ArrayList<Object>();
    List<Object> lstPrecinto = new ArrayList<Object>();
    List<Object> lstDocAsociados = new ArrayList<Object>();
    // List<Object> lstDetAut = new ArrayList<Object>();
    List<Object> lstRegPrecedente = new ArrayList<Object>();
    List<Object> lstFormatoBDAV = new ArrayList<Object>();
    List<Object> lstFormatoBFacturas = new ArrayList<Object>();
    List<Object> lstItemsFactura = new ArrayList<Object>();
    List<Object> lstCertOrigen = new ArrayList<Object>();
    List<Object> lstFacturasFormA = new ArrayList<Object>();
    List<Object> lstIndicadorDUA = new ArrayList<Object>();
    List<Object> lstObservacion = new ArrayList<Object>();
    List<Object> lstConvenioSerie = new ArrayList<Object>();
    List<Object> lstParticipanteDoc = new ArrayList<Object>();
    List<Object> lstDetAutorizacion = new ArrayList<Object>();
    List<Object> lstFacturaSerie = new ArrayList<Object>();
    List<Object> lstVFobProvisional = new ArrayList<Object>();
    List<Object> lstDetAdiconsu = new ArrayList<Object>();
    List<Object> lstDetAdiAtpa = new ArrayList<Object>();
    List<Object> lstDetAdiAtreex = new ArrayList<Object>();
    List<Object> lstFinUbicacion = new ArrayList<Object>();
    List<Object> lstCondicionTransa = new ArrayList<Object>();
    List<Object> lstCabAdiImpoConsu = new ArrayList<Object>();
    List<Object> lstVehiCetico = new ArrayList<Object>();
    List<Object> lstFactuSuce = new ArrayList<Object>();
    List<Object> lstFormbMonto = new ArrayList<Object>();
    List<Object> lstMontoGasto = new ArrayList<Object>();
    List<Object> lstFormbItemDescri = new ArrayList<Object>();
    /* PAS20145E220000399 INICIO GGRANADOS */
    List<Object> lstFormatoBSeriesItem = new ArrayList<Object>();
    /* PAS20145E220000399 FIN GGRANADOS */


    // las tablas enviadas para comparar los valores rectificados
    Map<String, Object> mapCabDeclaraH = (Map<String, Object>) mapTablas.get(Constantes.COD_TABLA_CAB_DECLARA);
    Map<String, Object> mapCabAdiAdmtemH = (Map<String, Object>) mapTablas.get(Constantes.COD_TABLA_CAB_ADI_ADM_TEM);
    List<Map<String, Object>> lstDetAdiImpoconsuH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DET_ADI_IMPO_CONSU));
    List<Map<String, Object>> lstDetAdiAtpaH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DET_ADI_ATPA));
    List<Map<String, Object>> lstDetAdiAtreexH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DET_ADI_ATREEX));
    List<Map<String, Object>> lstDetDeclaraH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DET_DECLARA));
    List<Map<String, Object>> lstContenedoresH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_EQUIPAMIENTO));
    List<Map<String, Object>> lstPrecintosH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_PRECINTO));
    List<Map<String, Object>> lstDocAsociadosH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DOCAUT_ASOCIADO));
    List<Map<String, Object>> lstRegPrecedenteH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DOCUPRECE_DUA));
    List<Map<String, Object>> lstFormatoBDAVH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FORMB_PROVEEDOR));
    List<Map<String, Object>> lstFormatoBFacturasH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_COMPROBPAGO));
    List<Map<String, Object>> lstItemsFacturaH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_ITEM_FACTURA));
    List<Map<String, Object>> lstSeriesItemH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_SERIES_ITEM));
    List<Map<String, Object>> lstCertOrigenH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_CAB_CERTIORIGEN));
    List<Map<String, Object>> lstFacturasFormAH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FORMA_FACTU));
    List<Map<String, Object>> lstIndicadorDUAH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_INDICADOR_DUA));
    List<Map<String, Object>> lstObservacionH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_OBSERVACION));
    List<Map<String, Object>> lstParticipanteDocH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_PARTICIPANTE_DOC));
    List<Map<String, Object>> lstDetAutorizacionH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_DET_AUTORIZACION));
    List<Map<String, Object>> lstFacturaSerieH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FACTURA_SERIE));
    List<Map<String, Object>> lstVFobProvisionalH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_VFOB_PROVISIONAL));
    List<Map<String, Object>> lstConvenioSerieH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_CONVENIO_SERIE));
    Map<String, Object> mapFinUbicacionH = (Map<String, Object>) mapTablas.get(Constantes.COD_TABLA_FIN_UBICACION);
    List<Map<String, Object>> lstCondiTransaH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_CONDICION_TRANSA));
    List<Map<String, Object>> lstCabAdiImpoConsuH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU));
    List<Map<String, Object>> lstVehiCeticoH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_VEHI_CETICO));
    List<Map<String, Object>> lstFactuSuceH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FACTUSUCE));
    List<Map<String, Object>> lstFormbMontoH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FORMB_MONTO));
    List<Map<String, Object>> lstMontoGastoH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_MONTO_GASTO));
    List<Map<String, Object>> lstFormbItemDescriH = retornarArrayListNoNulo(mapTablas.get(Constantes.COD_TABLA_FORMB_ITEM_DESCRI));
    //rtineo mejoras, el formatoB lo ponemos dentro de un hashMap, para realizar la busqueda mas rapido
    Map<String,Map<String,Object>> mapFormbItemDescriH = new HashMap<String,Map<String,Object>>();

    
    String claveFormB="";
    String num_secitemFormB="";
    String cod_mercanciaitemFormB="";
	//PAS20155E220200139
    //String num_secfactFormB="";
    String cod_tipdescFormB="";
    //String num_secproveFormB="";
    for(Map<String,Object> mapTemp:lstFormbItemDescriH){
    	num_secitemFormB=mapTemp.get("NUM_SECITEM").toString();
    	cod_mercanciaitemFormB=mapTemp.get("COD_MERCANCIA").toString();
    	//num_secfactFormB=mapTemp.get("NUM_SECFACT").toString(); //no es pk 			PAS20155E220200139
    	cod_tipdescFormB=mapTemp.get("COD_TIPDESC").toString();
    	//num_secproveFormB=mapTemp.get("NUM_SECPROVE").toString();//no es pk 			PAS20155E220200139
    	claveFormB = num_secitemFormB.concat("-").concat(cod_mercanciaitemFormB)
    			//.concat("-").concat(num_secfactFormB)
    			.concat("-").concat(cod_tipdescFormB);
    			//.concat("-").concat(num_secproveFormB); // no es pk 			PAS20155E220200139
    	mapFormbItemDescriH.put(claveFormB, mapTemp);
    }
	//PAS20155E220200139
    //fin mejoras
    
    Object objetoJsonCertOrigenR = null;
    Object objetoJsonPkCertOrigenR = null;

    Object objetoJsonFacturasR = null;
    Object objetoJsonPkFacturasR = null;

    Object objetoJsonPkCabDeclaraR = null;
    Object objetoJsonPkDetDeclaraR = null;
    Object objetoJsonPkEquipoamientoR = null;
    Object objetoJsonPkPrecintoR = null;
    Object objetoJsonPkDocAsociadosR = null;
    Object objetoJsonPkRegPrecedenteR = null;
    Object objetoJsonPkFormatoBDAVR = null;
    Object objetoJsonPkFormatoBFacturasR = null;
    Object objetoJsonPkItemsFacturaR = null;
    Object objetoJsonPkSeriesItemR = null;
    Object objetoJsonPkFinUbicacionR = null;
    Object objetoJsonPkCondicionTransaR = null;
    Object objetoJsonPkCabAdiImpoConsuR = null;
    Object objetoJsonPkVehiCeticoR = null;
    Object objetoJsonPkFactuSuceR = null;

    Object objetoJsonPkCabAdiAdmtemR = null;
    Object objetoJsonPkDetAdiImpoconsuR = null;
    Object objetoJsonPkDetAdiAtpaR = null;
    Object objetoJsonPkDetAdiAtreexR = null;

    Object objetoJsonCabAdiAdmtemR = null;
    Object objetoJsonDetAdiImpoconsuR = null;
    Object objetoJsonDetAdiAtpaR = null;
    Object objetoJsonDetAdiAtreexR = null;
    Object objetoJsonCabDeclaraR = null;
    Object objetoJsonDetDeclaraR = null;
    Object objetoJsonEquipoamientoR = null;
    Object objetoJsonPrecintoR = null;
    Object objetoJsonDocAsociadosR = null;
    Object objetoJsonRegPrecedenteR = null;
    Object objetoJsonFormatoBDAVR = null;
    Object objetoJsonFormatoBFacturasR = null;

    Object objetoJsonItemsFacturaR = null;
    Object objetoJsonSeriesItemR = null;

    Object objetoJsonFinUbicacionR = null;
    Object objetoJsonCondicionTransaR = null;
    Object objetoJsonCabAdiImpoConsuR = null;
    Object objetoJsonVehiCeticoR = null;
    Object objetoJsonFactuSuceR = null;

    Object objetoJsonPkFormbMontoR = null;
    Object objetoJsonFormbMontoR = null;

    Object objetoJsonPkFormbItemDescriR = null;
    Object objetoJsonFormbItemDescriR = null;

    // obtengo los datos rectificados
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", mapTablas.get("NUM_CORREDOC"));

    List<Map<String, Object>> lstdatosRectificados = detSolRectiDAO.findDatosRectificadosByMap(params);

    //rtineo mejoras -- consultamos por una sola vez
    String codTipoCat = Constantes.COD_TIPO_CATALOGO;
    List<Map<String, String>> listaDescripcion = this.catCasillaFormatoDAO.findByCodTipoCat(codTipoCat);
    Map<String,Map<String,String>> mapDescripcion = new HashMap<String,Map<String,String>>();
    //agrupamos en hashmap para luego realizar la busqueda mas rapida
    String monSinonimTab = "";
    String monCampo = "";
    String clave = "";
    for(Map<String,String> mapTemp:listaDescripcion){
    	monSinonimTab = ObjectUtils.toString(mapTemp.get("NOM_SINONIMTAB"),"TABLA_DESCONOCIDA");
    	monCampo = ObjectUtils.toString(mapTemp.get("NOM_CAMPO")).trim();
    	clave = monSinonimTab+"-"+(monCampo);
    	mapDescripcion.put(clave, mapTemp);
    }
    //fin mejoras
    
    if (!CollectionUtils.isEmpty(lstdatosRectificados))
    {
    	// INI hienka
    	Map<String, Object> mapDesOtros = new HashMap<String, Object>();
    	Map<String, Object> mapAntDesOtros = new HashMap<String, Object>();
        for (Map<String, Object> mapaItemRectifica : lstdatosRectificados)
        {
        	if ("T9833".equals(mapaItemRectifica.get("COD_TABLA")))
        	{
        		// obtengo Pk JSON
                String desData = (String) mapaItemRectifica.get("DES_DATA");
                String desAntData = (String) mapaItemRectifica.get("DES_ANTDATA");
                String desClave = (String) mapaItemRectifica.get("DES_CLAVE");
                JsonSerializer serializer = new JsonSerializer();
                Map<String, Object> mapClave = (Map<String, Object>) serializer.deserialize(desClave);
                Map<String, Object> mapData = (Map<String, Object>) serializer.deserialize(desData);
                Map<String, Object> mapAntData = (Map<String, Object>) serializer.deserialize(desAntData);
                String codCampo = (mapClave.get("COD_CAMPO") == null) ? "" : mapClave.get("COD_CAMPO").toString();

                if ("COD_ENTI_FINANC".equalsIgnoreCase(codCampo)) {
                	codCampo = "DES_OTRO_ENTI_FINANC";
                }
                else if ("COD_MEDIO_PAGO".equalsIgnoreCase(codCampo)) {
                	codCampo = "DES_OTRO_MEDIO_PAGO";
                }
                mapDesOtros.put(codCampo, mapData.get("DES_VALOR"));
                mapAntDesOtros.put(codCampo, mapAntData.get("DES_VALOR"));
                break;
            }
        }
        for (Map<String, Object> mapaItemRectifica : lstdatosRectificados)
        {
        	if (Constantes.COD_TABLA_FORMB_PROVEEDOR.equals(mapaItemRectifica.get("COD_TABLA")))
        	{
                String desData = (String) mapaItemRectifica.get("DES_DATA");
                String desAntData = (String) mapaItemRectifica.get("DES_ANTDATA");
                JsonSerializer serializer = new JsonSerializer();
                Map<String, Object> mapData = (Map<String, Object>) serializer.deserialize(desData);
                Map<String, Object> mapAntData = (Map<String, Object>) serializer.deserialize(desAntData);
                for (Entry<String, Object> map : mapDesOtros.entrySet()) {
                	mapData.put(map.getKey(), map.getValue());
				}
                for (Entry<String, Object> map : mapAntDesOtros.entrySet()) {
                	mapAntData.put(map.getKey(), map.getValue());
				}
                mapaItemRectifica.put("DES_DATA" , (String) serializer.serialize(mapData));
                mapaItemRectifica.put("DES_ANTDATA" , (String) serializer.serialize(mapAntData));
                break;
        	}
        }
    	// FIN hienka
    	
    	
    	
      for (Map<String, Object> mapaItemRectifica : lstdatosRectificados)
      {

        if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CAB_DECLARA) && mapCabDeclaraH != null
            && mapCabDeclaraH.size() > 0)
        {
          // este dato es un objeto string
          // obtengo Pk JSON
          objetoJsonPkCabDeclaraR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkCabDeclaraR = (Map<String, Object>) serializer.deserialize(objetoJsonPkCabDeclaraR);

          String pk = mapPkCabDeclaraR.get("NUM_CORREDOC").toString();
          // obtengo data rectificada JSON
          objetoJsonCabDeclaraR = mapaItemRectifica.get("DES_DATA") != null ? mapaItemRectifica
              .get("DES_DATA")
              .toString()
              .trim() : "";
          String codTipoRectificacion = mapaItemRectifica.get("IND_RECTIFICA") != null ? (String) mapaItemRectifica
              .get("IND_RECTIFICA") : "";

          // comparo datos H con datos R

          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          
          /*Inicio de ajustes por PASE 399*///posicion correcta PASE 81
          String numero_ctacte = mapCabDeclaraH.get("NUM_CTACTE")!=null ? (mapCabDeclaraH.get("NUM_CTACTE").toString().trim().isEmpty()?null:mapCabDeclaraH.get("NUM_CTACTE").toString()): null;
          mapCabDeclaraH.remove("NUM_CTACTE");
          mapCabDeclaraH.put("NUM_CTACTE", numero_ctacte);          
          /*Fin de ajustes por PASE 399*/
          //rtineo mejoras
          List<Map<String, Object>> lstRectiCabDeclara = compararMapas(objetoJsonCabDeclaraR, mapCabDeclaraH,
              Constantes.COD_TABLA_CAB_DECLARA_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla,mapDescripcion);
          data.put(Constantes.COD_TABLA_CAB_DECLARA, lstRectiCabDeclara);

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CAB_ADI_ADM_TEM))
        {
          objetoJsonPkCabAdiAdmtemR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkCabAdiAdmtemR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkCabAdiAdmtemR);

          String pk = mapPkCabAdiAdmtemR.get("NUM_CORREDOC").toString();
          // obtengo data rectificada JSON
          objetoJsonCabAdiAdmtemR = mapaItemRectifica.get("DES_DATA") != null ? mapaItemRectifica
              .get("DES_DATA")
              .toString()
              .trim() : "";
          String codTipoRectificacion = mapaItemRectifica.get("IND_RECTIFICA") != null ? (String) mapaItemRectifica
              .get("IND_RECTIFICA") : "";

          // comparo datos H con datos R
          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          /*Inicio de ajustes por PASE 399*///ESTA EN MALA POSICION ES DET_DECLARA PASE 81
//          String numero_ctacte = mapCabDeclaraH.get("NUM_CTACTE")!=null ? (mapCabDeclaraH.get("NUM_CTACTE").toString().trim().isEmpty()?null:mapCabDeclaraH.get("NUM_CTACTE").toString()): null;
//          mapCabDeclaraH.remove("NUM_CTACTE");
//          mapCabDeclaraH.put("NUM_CTACTE", numero_ctacte);          
          /*Fin de ajustes por PASE 399*/
          
          List<Map<String, Object>> lstRectiCabAdiAdmtem = compararMapas(objetoJsonCabAdiAdmtemR, mapCabAdiAdmtemH,
              Constantes.COD_TABLA_CAB_ADI_ADM_TEM_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla,mapDescripcion);
          data.put(Constantes.COD_TABLA_CAB_ADI_ADM_TEM, lstRectiCabAdiAdmtem);
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DET_ADI_IMPO_CONSU)
            && lstDetAdiImpoconsuH != null
            && lstDetAdiImpoconsuH.size() > 0)
        {
          objetoJsonPkDetAdiImpoconsuR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkDetAdiImpoconsuR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkDetAdiImpoconsuR);

          String pk = mapPkDetAdiImpoconsuR.get("NUM_SECSERIE").toString();

          if (log.isDebugEnabled())
            log.debug("4. Lista Rectificaci�n DetAdiImpoconsu: " + lstDetAdiImpoconsuH);
          if (log.isDebugEnabled())
            log.debug("4. Lista Rectificaci�n PK: " + pk);
          // compara datos H con datos R
          // recorre la lista de series Historicos
          Iterator i1 = lstDetAdiImpoconsuH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaDetAdiconsu = (Map<String, Object>) i1.next();

            if ((mapaDetAdiconsu.get("NUM_SECSERIE").toString()).equals(pk))
            {

              objetoJsonDetAdiImpoconsuR = mapaItemRectifica.get("DES_DATA");
              String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

              // datos ncesario para la grabacion
              String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica.get(
                  "NUM_SECCAMBIO").toString() : "";
              String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica
                  .get("DES_CLAVE") : "";
              String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica
                  .get("COD_TABLA") : "";
              // fin

              List<Map<String, Object>> lstRectiDetAdiImpoconsu = compararMapas(
                  objetoJsonDetAdiImpoconsuR,
                    mapaDetAdiconsu,
                    Constantes.COD_TABLA_DET_ADI_IMPO_CONSU_DESC,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla,mapDescripcion);
              // agrego el listado al listado final
              lstDetAdiconsu.add(lstRectiDetAdiImpoconsu);
              break;
            }
          }
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DET_ADI_ATPA)
            && lstDetAdiAtpaH != null
            && lstDetAdiAtpaH.size() > 0)
        {
          objetoJsonPkDetAdiAtpaR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkDetAdiAtpaR = (Map<String, Object>) serializer.deserialize(objetoJsonPkDetAdiAtpaR);

          String pk = mapPkDetAdiAtpaR.get("NUM_SECSERIE").toString();

          // compara datos H con datos R
          // recorre la lista de series Historicos
          Iterator i1 = lstDetAdiAtpaH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaDetAdiAtpa = (Map<String, Object>) i1.next();

            if ((mapaDetAdiAtpa.get("NUM_SECSERIE").toString()).equals(pk))
            {

              objetoJsonDetAdiAtpaR = mapaItemRectifica.get("DES_DATA");
              String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

              // datos ncesario para la grabacion
              String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica.get(
                  "NUM_SECCAMBIO").toString() : "";
              String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica
                  .get("DES_CLAVE") : "";
              String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica
                  .get("COD_TABLA") : "";
              // fin

              List<Map<String, Object>> lstRectiDetAdiAtpa = compararMapas(objetoJsonDetAdiAtpaR, mapaDetAdiAtpa,
                  Constantes.COD_TABLA_DET_ADI_ATPA_DESC, pk, codTipoRectificacion, numSecCambio, desClave,
                  codTabla,mapDescripcion);
              // agrego el listado al listado final
              lstDetAdiAtpa.add(lstRectiDetAdiAtpa);
              break;
            }
          }
          if (log.isDebugEnabled())
            log.debug("Lista rectificaciones detadiatpa: " + lstDetAdiAtpa);
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DET_ADI_ATREEX)
            && lstDetAdiAtreexH != null
            && lstDetAdiAtreexH.size() > 0)
        {
          objetoJsonPkDetAdiAtreexR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkDetAdiAtreexR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkDetAdiAtreexR);

          String pk = mapPkDetAdiAtreexR.get("NUM_SECSERIE").toString();

          // compara datos H con datos R
          // recorre la lista de series Historicos
          Iterator i1 = lstDetAdiAtreexH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaDetAdiAtreex = (Map<String, Object>) i1.next();

            if ((mapaDetAdiAtreex.get("NUM_SECSERIE").toString()).equals(pk))
            {

              objetoJsonDetAdiAtreexR = mapaItemRectifica.get("DES_DATA");
              String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

              // datos ncesario para la grabacion
              String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica.get(
                  "NUM_SECCAMBIO").toString() : "";
              String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica
                  .get("DES_CLAVE") : "";
              String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica
                  .get("COD_TABLA") : "";
              // fin

              List<Map<String, Object>> lstRectiDetAdiAtreex = compararMapas(objetoJsonDetAdiAtreexR, mapaDetAdiAtreex,
                  Constantes.COD_TABLA_DET_ADI_ATREEX_DESC, pk, codTipoRectificacion, numSecCambio, desClave,
                  codTabla,mapDescripcion);
              // agrego el listado al listado final
              lstDetAdiAtpa.add(lstRectiDetAdiAtreex);
              break;
            }
          }
          if (log.isDebugEnabled())
            log.debug("Lista rectificaciones detadiatreex: " + lstDetAdiAtreex);
        }

        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DET_DECLARA)
            && lstDetDeclaraH != null
            && lstDetDeclaraH.size() > 0)
        {
          // obtengo Pk JSON
          objetoJsonPkDetDeclaraR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo deserializo y lo convierto a objeto
          // este nuevoobjeto esta desseriasalod y es Map
          Map<String, Object> mapPkDetDeclaraR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkDetDeclaraR);
          String pk = mapPkDetDeclaraR.get("NUM_SECSERIE").toString();

          // datos ncesario para la grabacion
          objetoJsonDetDeclaraR = mapaItemRectifica.get("DES_DATA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          // busco las series nuevas
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiDetDeclara = compararMapas(objetoJsonDetDeclaraR, null,
                Constantes.COD_TABLA_DET_DECLARA_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstDetDeclara.add(lstRectiDetDeclara);
            continue;
          }

          // recorro la lista de series Historicos
          Iterator i1 = lstDetDeclaraH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaSerie = (Map<String, Object>) i1.next();

            if ((mapaSerie.get("NUM_SECSERIE").toString()).equals(pk))
            {

              List<Map<String, Object>> lstRectiDetDeclara = compararMapas(objetoJsonDetDeclaraR, mapaSerie,
                  Constantes.COD_TABLA_DET_DECLARA_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla,mapDescripcion);
              // agrego el listado al listado final
              lstDetDeclara.add(lstRectiDetDeclara);
              break;
            }
          }
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_EQUIPAMIENTO))//moll
        {
          // obtengo Pk JSON
          objetoJsonPkEquipoamientoR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo des y lo convierto a obeto
          // este nuevoobjeto esta desseriasalod y es Map
          Map<String, Object> mapPkEquipoamientoR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkEquipoamientoR);
          String pk = mapPkEquipoamientoR.get("NUM_EQUIPAMIENTO").toString();

          objetoJsonEquipoamientoR = mapaItemRectifica.get("DES_DATA");
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          // fin
          // agregamos los nuevos registros
          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiEquipamiento = compararMapas(objetoJsonEquipoamientoR, null,
                Constantes.COD_TABLA_EQUIPAMIENTO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstEquipamiento.add(lstRectiEquipamiento);
            continue;
          }
          // recorro la lista de series Historicos
          Iterator i1 = lstContenedoresH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaEquipamiento = (Map<String, Object>) i1.next();

            if ((mapaEquipamiento.get("NUM_EQUIPAMIENTO").toString()).equals(pk))
            {
              List<Map<String, Object>> lstRectiEquipamiento = compararMapas(objetoJsonEquipoamientoR,
                  mapaEquipamiento, Constantes.COD_TABLA_EQUIPAMIENTO_DESC, pk, codTipoRectificacion,
                  numSecCambio, desClave, codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstEquipamiento.add(lstRectiEquipamiento);
              break;
            }
          }
          
        }else  if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_PRECINTO))
            {
              // obtengo Pk JSON
              objetoJsonPkPrecintoR = mapaItemRectifica.get("DES_CLAVE");
              JsonSerializer serializer = new JsonSerializer();
              // JSon que estaba serializado lo des y lo convierto a obeto
              // este nuevoobjeto esta desseriasalod y es Map
              Map<String, Object> mapPkPrecintoR = (Map<String, Object>) serializer
                  .deserialize(objetoJsonPkPrecintoR);
              String pk = mapPkPrecintoR.get("NUM_PRECINTO").toString();

              objetoJsonPrecintoR = mapaItemRectifica.get("DES_DATA");
              String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
              // datos ncesario para la grabacion
              String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
                  .get("NUM_SECCAMBIO")
                  .toString() : "";
              String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
                  : "";
              String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
                  : "";
              // fin
              // agregamos los nuevos registros
              if (codTipoRectificacion.equals(NUEVO_REGISTRO))
              {
                List<Map<String, Object>> lstRectiPrecinto = compararMapas(objetoJsonPrecintoR, null,
                    Constantes.COD_TABLA_PRECINTO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla);
                // agrego el listado al listado final
                lstPrecinto.add(lstRectiPrecinto);
                continue;
              }
              // recorro la lista de series Historicos
              Iterator i1 = lstPrecintosH.iterator();
              while (i1.hasNext())
              {
                Map<String, Object> mapaPrecinto = (Map<String, Object>) i1.next();

                if ((mapaPrecinto.get("NUM_PRECINTO").toString()).equals(pk))
                {
                  List<Map<String, Object>> lstRectiPrecinto = compararMapas(objetoJsonEquipoamientoR,
                      mapaPrecinto, Constantes.COD_TABLA_PRECINTO_DESC, pk, codTipoRectificacion,
                      numSecCambio, desClave, codTabla);
                  // agrego el listado al listado final
                  lstPrecinto.add(lstRectiPrecinto);
                  break;
                }
              }
          // proceso Doc Asociados
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DOCAUT_ASOCIADO))
        {
          objetoJsonPkDocAsociadosR = mapaItemRectifica.get("DES_CLAVE");// DOCUMENTO ASOCIADOS
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkDocAsociadosR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkDocAsociadosR);

          String pk = mapPkDocAsociadosR.get("NUM_SECDOC").toString();
          pk += mapPkDocAsociadosR.get("COD_TIPOPER").toString();

          objetoJsonDocAsociadosR = mapaItemRectifica.get("DES_DATA");
          log.debug("objetoJsonDocAsociadosR:>>>" + objetoJsonDocAsociadosR);
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          StringBuilder pkR = new StringBuilder();
          pkR.append((mapPkDocAsociadosR.get("COD_TIPOPER") != null) ? mapPkDocAsociadosR
              .get("COD_TIPOPER")
              .toString()
              .trim() : "");
          pkR.append((mapPkDocAsociadosR.get("NUM_SECDOC") != null) ? mapPkDocAsociadosR
              .get("NUM_SECDOC")
              .toString()
              .trim() : "");
          pkR.append((mapPkDocAsociadosR.get("NUM_CORREDOC") != null) ? mapPkDocAsociadosR
              .get("NUM_CORREDOC")
              .toString()
              .trim() : "");

          // agregamos los nuevos registros
          if (NUEVO_REGISTRO.equals(codTipoRectificacion))
          {
            List<Map<String, Object>> lstRectiDocAsociados = compararMapas(objetoJsonDocAsociadosR, null,
                Constantes.COD_TABLA_DOCAUT_ASOCIADO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            List<Map<String, Object>> lstRectiDocAsociadosAux = new ArrayList<Map<String,Object>>();
            // agrego el listado al listado final
            for(Map<String, Object> mapa : lstRectiDocAsociados){
            	String cadena = mapa.get("VALOR2R").toString() ;//ajuste PAS20155E220200006
            	
				int pos = cadena.indexOf("COD_TIPDOCASO");
				if (pos >= 0) {
					String valor = cadena.substring(pos + 16);
					valor = valor.substring(0, valor.indexOf("\""));
					if (!valor.equals("26") && !valor.equals("38")) {
						lstRectiDocAsociadosAux.add(mapa);
					}
				}else{
					lstRectiDocAsociadosAux.add(mapa);
				}
            	
            }            
            lstDocAsociados.add(lstRectiDocAsociadosAux);
        
            continue;
          }
          // recorro la lista de Doc Asociados
          Iterator i1 = lstDocAsociadosH.iterator();//lstDetAutorizacionH,lstDocAsociadosH
          String numSecdoc="";
          while (i1.hasNext())
          {
            Map<String, Object> mapaDocasociado = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaDocasociado.get("COD_TIPOPER") != null) ? mapaDocasociado
                .get("COD_TIPOPER")
                .toString()
                .trim() : "");
            pkH.append((mapaDocasociado.get("NUM_SECDOC") != null) ? mapaDocasociado
                .get("NUM_SECDOC")
                .toString()
                .trim() : "");
            pkH.append((mapaDocasociado.get("NUM_CORREDOC") != null) ? mapaDocasociado
                .get("NUM_CORREDOC")
                .toString()
                .trim() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              numSecdoc=mapaDocasociado.get("NUM_SECDOC").toString();
              List<Map<String, Object>> lstRectiDocAsociados = compararMapas(objetoJsonDocAsociadosR, mapaDocasociado,
                  Constantes.COD_TABLA_DOCAUT_ASOCIADO_DESC, pk, codTipoRectificacion, numSecCambio, desClave,
                  codTabla, mapDescripcion);
              // agrego el listado al listado final
              if (log.isDebugEnabled())
                log.debug("lstRectiDocAsociados:" + lstRectiDocAsociados);
              // fromatea la fecha a dd/MM/yyyy
              formatFecha(lstRectiDocAsociados);
              lstDocAsociados.add(lstRectiDocAsociados);
			  //Pase 152 p24 inicio
              break;
            }
          }
          
          // recorro la lista de Doc Autorizantes
          Iterator i2 = lstDetAutorizacionH.iterator();//lstDetAutorizacionH,lstDocAsociadosH
          while (i2.hasNext())
          {
            Map<String, Object> mapaDocAutorizado  = (Map<String, Object>) i2.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaDocAutorizado.get("COD_TIPOPER") != null) ? mapaDocAutorizado 
                .get("COD_TIPOPER")
                .toString()
                .trim() : "");
            pkH.append((mapaDocAutorizado.get("NUM_SECDOC") != null) ? mapaDocAutorizado 
                .get("NUM_SECDOC")
                .toString()
                .trim() : "");
            pkH.append((mapaDocAutorizado.get("NUM_CORREDOC") != null) ? mapaDocAutorizado 
                .get("NUM_CORREDOC")
                .toString()
                .trim() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
            	Map<String, String> mapaDocAutorizado2  = new HashMap <String, String>();
            	Map<String, Object> mapaSeriesRectificadas  = new HashMap <String, Object>();
            	
            	mapaDocAutorizado2.put("COD_TIPOPER", mapaDocAutorizado.get("COD_TIPOPER") != null? mapaDocAutorizado 
                        .get("COD_TIPOPER").toString().trim() : "");
            	mapaDocAutorizado2.put("NUM_SECDOC", mapaDocAutorizado.get("NUM_SECDOC") != null? mapaDocAutorizado 
                        .get("NUM_SECDOC").toString().trim() : "");
            	mapaDocAutorizado2.put("NUM_CORREDOC", mapaDocAutorizado.get("NUM_CORREDOC") != null? mapaDocAutorizado 
                        .get("NUM_CORREDOC").toString().trim() : "");
            	StringBuilder seriesrectificadas = new StringBuilder();
            	StringBuilder seriesEliminadas = new StringBuilder();
            	StringBuilder seriesActivas = new StringBuilder();
            	StringBuilder seriesAsociadas = new StringBuilder();
            	String numSecDoc = "";
            	List<Map<String, Object>> listadoDetAutorizacionActual = new ArrayList<Map<String, Object>>();
    			listadoDetAutorizacionActual = ((DetAutorizacionDAO)fabricaDeServicios.getService("detAutorizacionDAO")).select(mapaDocAutorizado2);
    			List<Map<String, Object>> listaRectificadosSeries = new ArrayList<Map<String, Object>>();
    			if(!CollectionUtils.isEmpty(listadoDetAutorizacionActual)){
    				for (Map<String, Object> mapaDet : listadoDetAutorizacionActual)
    		        {   		             // relaciones activas
    		            if (mapaDet.get("IND_DEL") != null)
    		            {  		            	    		            	
    		            	if (0 == seriesActivas.toString().trim().length())
    			              {
    			                seriesActivas.append(mapaDet.get("NUM_SECSERIE").toString());
    			              }
    			              else
    			              {
    			                seriesActivas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());
    			              }		
    		            	mapaDocAutorizado.put("NUM_SECSERIE_RECT",seriesActivas);
   		            	
    			             /* else
    			              {
    			                seriesActivas.append(",").append(mapaDet.get("NUM_SECSERIE").toString());
    			              }*/
    		            	//mapaDocAutorizado.put("SERIES_RECTIFICADAS", seriesActivas); 
    		            }

    		        }
    			}
            	List<Map<String, Object>> lstRectiDocAsociadosDetAut = compararMapas(objetoJsonDocAsociadosR, mapaDocAutorizado,
                  Constantes.COD_TABLA_DOCAUT_ASOCIADO_DESC, pk, codTipoRectificacion, numSecCambio, desClave,
                  codTabla, mapDescripcion);
              // agrego el listado al listado final
              if (log.isDebugEnabled())
                log.debug("lstRectiDocAsociados:" + lstRectiDocAsociadosDetAut);
              // fromatea la fecha a dd/MM/yyyy
              formatFecha(lstRectiDocAsociadosDetAut);
            	 // obtenemos los datos rectificados de la tabla det_autorizacion
               // lstDetAutorizacion.add(obtenerDatosDetAutorizacionRectificados(
                //    lstDetAutorizacionH, mapaItemRectifica));
              lstDocAsociados.add(lstRectiDocAsociadosDetAut);
			  // pase p24 152 fin 
              break;
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DOCUPRECE_DUA))
        {
          objetoJsonPkRegPrecedenteR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPKItemRectificado = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkRegPrecedenteR);
          Map<String, Object> mapKey = new HashMap<String, Object>();
          mapKey.put("NUM_CORREDOC", mapPKItemRectificado.get("NUM_CORREDOC"));
          mapKey.put("NUM_SECSERIE", mapPKItemRectificado.get("NUM_SECSERIE"));
          mapKey.put("ANN_PRESENPRE", mapPKItemRectificado.get("ANN_PRESENPRE"));
          mapKey.put("COD_ADUANAPRE", mapPKItemRectificado.get("COD_ADUANAPRE"));
          mapKey.put("COD_REGIMENPRE", mapPKItemRectificado.get("COD_REGIMENPRE"));
          mapKey.put("NUM_SECSERIEPRE", mapPKItemRectificado.get("NUM_SECSERIEPRE"));
          mapKey.put("NUM_DECLARACIONPRE", mapPKItemRectificado.get("NUM_DECLARACIONPRE"));
          String pkGUI = mapPKItemRectificado.get("NUM_DECLARACIONPRE").toString() + "-"
              + mapPKItemRectificado.get("NUM_SECSERIE").toString();
          Map<String, Object> mapaItemFound = Utilidades.obtenerElemento(lstRegPrecedenteH, mapKey);
          log.debug("mapaRegPrecedente::>>" + mapaItemFound);
          objetoJsonRegPrecedenteR = mapaItemRectifica.get("DES_DATA");
          log.debug("objetoJsonRegPrecedenteR:>>>" + objetoJsonRegPrecedenteR);
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          List<Map<String, Object>> lstRecticaItems = compararMapas(objetoJsonRegPrecedenteR, mapaItemFound,
              Constantes.COD_TABLA_DOCUPRECE_DUA_DESC, pkGUI, codTipoRectificacion, numSecCambio, desClave,
              codTabla, mapDescripcion);
          log.debug("lstRectiRegPrecedente:" + lstRecticaItems);
          lstRegPrecedente.add(lstRecticaItems);
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FORMB_PROVEEDOR)
            && lstFormatoBDAVH != null
            && lstFormatoBDAVH.size() > 0)
        {
          // obtengo Pk JSON
          objetoJsonPkFormatoBDAVR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo des y lo convierto a obeto
          // este nuevoobjeto esta desseriasalod y es Map

          Map<String, Object> mapPkFormatoBDAVR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkFormatoBDAVR);

          String pkR = "";

             pkR = pkR.concat((mapPkFormatoBDAVR.get("NUM_SECPROVE") != null) ? mapPkFormatoBDAVR
              .get("NUM_SECPROVE")
              .toString() : "");

          objetoJsonFormatoBDAVR = mapaItemRectifica.get("DES_DATA");
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          // agregamos los registros nuevos
          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFormatoBDAV = compararMapas(objetoJsonFormatoBDAVR, null,
                Constantes.COD_TABLA_FORMB_PROVEEDOR_DESC, pkR, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstFormatoBDAV.add(lstRectiFormatoBDAV);
            continue;
          }
          // recorro la lista de DAV Historicos
          Iterator i1 = lstFormatoBDAVH.iterator();

          while (i1.hasNext())
          {
            Map<String, Object> mapaFormatoBDAV = (Map<String, Object>) i1.next();

            String pkH = "";

            pkH = pkH.concat((mapaFormatoBDAV.get("NUM_SECPROVE") != null) ? mapaFormatoBDAV
                .get("NUM_SECPROVE")
                .toString() : "");
            if ((pkH).equals(pkR))
            {

              List<Map<String, Object>> lstRectiFormatoBDAV = compararMapas(objetoJsonFormatoBDAVR, mapaFormatoBDAV,
                  Constantes.COD_TABLA_FORMB_PROVEEDOR_DESC, pkH, codTipoRectificacion, numSecCambio, desClave,
                  codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstFormatoBDAV.add(lstRectiFormatoBDAV);
              break;
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_COMPROBPAGO)
            && lstFormatoBFacturasH != null && lstFormatoBFacturasH.size() > 0)
        {
          objetoJsonPkFormatoBFacturasR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkFormatoBFacturasR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkFormatoBFacturasR);

          String pkR = "";
          pkR = pkR.concat((mapPkFormatoBFacturasR.get("NUM_SECFACT") != null) ? mapPkFormatoBFacturasR.get(
              "NUM_SECFACT").toString() : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          objetoJsonFormatoBFacturasR = mapaItemRectifica.get("DES_DATA");
          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFormatoBFacturas = compararMapas(objetoJsonFormatoBFacturasR, null,
                Constantes.COD_TABLA_COMPROBPAGO_DESC, pkR, codTipoRectificacion, numSecCambio, desClave,
                codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstFormatoBFacturas.add(lstRectiFormatoBFacturas);
            continue;
          }

          Iterator i1 = lstFormatoBFacturasH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaFormatoBFacturas = (Map<String, Object>) i1.next();

            String pkH = "";
            pkH = pkH.concat((mapaFormatoBFacturas.get("NUM_SECFACT") != null) ? mapaFormatoBFacturas
                .get("NUM_SECFACT")
                .toString() : "");

            if ((pkH).equals(pkR))
            {
              List<Map<String, Object>> lstRectiFormatoBFacturas = compararMapas(objetoJsonFormatoBFacturasR,
                  mapaFormatoBFacturas, Constantes.COD_TABLA_COMPROBPAGO_DESC, pkH, codTipoRectificacion,
                  numSecCambio, desClave, codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstFormatoBFacturas.add(lstRectiFormatoBFacturas);
              break;
            }
          }
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_ITEM_FACTURA)
            && lstItemsFacturaH != null && lstItemsFacturaH.size() > 0)
        {

          objetoJsonPkItemsFacturaR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo des y lo convierto a obeto
          // este nuevoobjeto esta desseriasalod y es Map
          Map<String, Object> mapPkItemsFacturaR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkItemsFacturaR);
          objetoJsonItemsFacturaR = mapaItemRectifica.get("DES_DATA");
          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          // buscamos los registros nuevos
          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            String pk = (mapPkItemsFacturaR.get("NUM_SECITEM").toString() != null) ? mapPkItemsFacturaR.get(
                "NUM_SECITEM").toString() : "";
            List<Map<String, Object>> lstRectiItemsFactura = compararMapas(
                objetoJsonItemsFacturaR,
                  null,
                  Constantes.COD_TABLA_ITEM_FACTURA_DESC,
                  pk,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstItemsFactura.add(lstRectiItemsFactura);
            continue;
          }

          Iterator i1 = lstItemsFacturaH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaItemsFactura = (Map<String, Object>) i1.next();

            if (mapaItemsFactura.get("NUM_SECITEM").toString().equals(
                mapPkItemsFacturaR.get("NUM_SECITEM").toString()))
            {

              List<Map<String, Object>> lstRectiItemsFactura = compararMapas(objetoJsonItemsFacturaR, mapaItemsFactura,
                  Constantes.COD_TABLA_ITEM_FACTURA_DESC, mapaItemsFactura.get("NUM_SECITEM").toString(),
                  codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstItemsFactura.add(lstRectiItemsFactura);
              break;
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_SERIES_ITEM)
            && lstSeriesItemH != null
            && lstSeriesItemH.size() > 0)
        {
          // obtengo Pk JSON
          objetoJsonPkSeriesItemR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo des y lo convierto a obeto
          // este nuevo objeto esta desseriasado y es Map
          Map<String, Object> mapPkSeriesItemR = (Map<String, Object>) serializer.deserialize(objetoJsonPkSeriesItemR);
          StringBuilder pkR = new StringBuilder();
          pkR.append((mapPkSeriesItemR.get("NUM_CORREDOC") != null) ? mapPkSeriesItemR.get("NUM_CORREDOC").toString()
              : "");
          pkR.append((mapPkSeriesItemR.get("NUM_SECITEM") != null) ? mapPkSeriesItemR.get("NUM_SECITEM").toString()
              : "");
          pkR.append((mapPkSeriesItemR.get("NUM_SECSERIE") != null) ? mapPkSeriesItemR.get("NUM_SECSERIE").toString()
              : "");
          objetoJsonSeriesItemR = mapaItemRectifica.get("DES_DATA");
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            String pk = (mapPkSeriesItemR.get("NUM_SECSERIE") != null) ? mapPkSeriesItemR
                .get("NUM_SECSERIE")
                .toString() : "";
            List<Map<String, Object>> lstRectiSeriesItem = compararMapas(
                objetoJsonSeriesItemR,
                  null,
                  Constantes.COD_TABLA_SERIES_ITEM_DESC,
                  pk,
                  codTipoRectificacion,
                  (mapaItemRectifica
                      .get("NUM_SECCAMBIO") != null ? mapaItemRectifica.get("NUM_SECCAMBIO").toString() : ""),
                  (mapaItemRectifica
                      .get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE") : ""),
                  (mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA") : ""), mapDescripcion);
            // agrego el listado al listado final
            /* PAS20145E220000399 INICIO GGRANADOS */
            lstFormatoBSeriesItem.add(lstRectiSeriesItem);
            //lstFormatoBFacturas.add(lstRectiSeriesItem);
            /* PAS20145E220000399 FIN GGRANADOS */
            continue;
          }

          // recorro la lista de egimenes de precedencias Historicos
          Iterator i1 = lstSeriesItemH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaSeriesItem = (Map<String, Object>) i1.next();

            StringBuilder pkH = new StringBuilder();
            pkH
                .append(
                    (mapaSeriesItem.get("NUM_CORREDOC") != null) ? mapaSeriesItem.get("NUM_CORREDOC").toString() : "")
                .append(
                    (mapaSeriesItem.get("NUM_SECITEM") != null) ? mapaSeriesItem.get("NUM_SECITEM").toString() : "")
                .append(
                    (mapaSeriesItem.get("NUM_SECSERIE") != null) ? mapaSeriesItem.get("NUM_SECSERIE").toString() : "");

            String pk = (mapaSeriesItem.get("NUM_SECSERIE") != null) ? mapaSeriesItem.get("NUM_SECSERIE").toString()
                : "";
            if ((pkH.toString()).equals(pkR.toString()))
            {

              List<Map<String, Object>> lstRectiSeriesItem = compararMapas(
                  objetoJsonSeriesItemR,
                    mapaSeriesItem,
                    Constantes.COD_TABLA_SERIES_ITEM_DESC,
                    pk,
                    codTipoRectificacion,
                    (mapaItemRectifica
                        .get("NUM_SECCAMBIO") != null ? mapaItemRectifica.get("NUM_SECCAMBIO").toString() : ""),
                    (mapaItemRectifica
                        .get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE") : ""),
                    (mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA") : ""), mapDescripcion);
              // agrego el listado al listado final
              /* PAS20145E220000399 INICIO GGRANADOS */
              lstFormatoBSeriesItem.add(lstRectiSeriesItem);
              //lstFormatoBFacturas.add(lstRectiSeriesItem);
              /* PAS20145E220000399 FIN GGRANADOS */
              break;
            }
          }
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CONVENIO_SERIE)
            && lstConvenioSerieH != null)
        {

          Object objetoJsonPkConvenioSerieR = mapaItemRectifica.get("DES_CLAVE");
          Object objetoJsonPkConvenioSerieR2 = mapaItemRectifica.get("DES_DATA");
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();
          Map<String, Object> mapPkConvenioSerieR1 = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkConvenioSerieR);

          pkR.append((mapPkConvenioSerieR1.get("NUM_SECSERIE") != null) ? mapPkConvenioSerieR1
              .get("NUM_SECSERIE")
              .toString() : "");
          pkR.append((mapPkConvenioSerieR1.get("COD_TIPCONVENIO") != null) ? mapPkConvenioSerieR1
              .get("COD_TIPCONVENIO")
              .toString() : "");
          pkR.append((mapPkConvenioSerieR1.get("COD_CONVENIO") != null) ? mapPkConvenioSerieR1
              .get("COD_CONVENIO")
              .toString() : "");
          String pk = pkR.toString();

          pkR.append((mapPkConvenioSerieR1.get("NUM_CORREDOC") != null) ? mapPkConvenioSerieR1
              .get("NUM_CORREDOC")
              .toString() : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          List<Map<String, Object>> lstRectiConvenioSerie;
          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            mapPkConvenioSerieR1.remove("COD_CONVENIO");
            lstRectiConvenioSerie = compararMapas(
                objetoJsonPkConvenioSerieR,
                  (Map<String, Object>) mapPkConvenioSerieR1,
                  Constantes.COD_TABLA_CONVENIO_SERIE_DESC,
                  pk,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstConvenioSerie.add(lstRectiConvenioSerie);

          }
          else
          {

            Iterator i1 = lstConvenioSerieH.iterator();
            while (i1.hasNext())
            {
              Map<String, Object> mapaConvenioSerie = (Map<String, Object>) i1.next();
              StringBuilder pkH = new StringBuilder();

              pkH.append((mapaConvenioSerie.get("NUM_SECSERIE") != null) ? mapaConvenioSerie
                  .get("NUM_SECSERIE")
                  .toString() : "");
              pkH.append((mapaConvenioSerie.get("COD_TIPCONVENIO") != null) ? mapaConvenioSerie
                  .get("COD_TIPCONVENIO")
                  .toString() : "");
              pkH.append((mapaConvenioSerie.get("COD_CONVENIO").toString().trim() != null) ? mapaConvenioSerie
                  .get("COD_CONVENIO")
                  .toString() : ""); //se retira por bug 20503

              pk = pkH.toString();

              pkH.append((mapaConvenioSerie.get("NUM_CORREDOC") != null) ? mapaConvenioSerie
                  .get("NUM_CORREDOC")
                  .toString() : "");

              if ((pkH.toString()).equals(pkR.toString()))
              {
                if (ELIMINAR_REGISTRO.equals(codTipoRectificacion))
                {
                  Map<String, Object> mapaTempConvenioSerie = (Map<String, Object>) serializer
                      .deserialize(objetoJsonPkConvenioSerieR);
                  mapaTempConvenioSerie.put("COD_CONVENIO_DESC", " ");
                 // objetoJsonPkConvenioSerieR = serializer.serialize(mapaTempConvenioSerie);
                  objetoJsonPkConvenioSerieR2 = serializer.serialize(mapaTempConvenioSerie);
                }
                // se envia como mapa a rectificar el pk puesto que no tiene
                // cmpo data
                mapaConvenioSerie.put("COD_CONVENIO_DESC", mapaConvenioSerie.get("COD_CONVENIO"));
                //lstRectiConvenioSerie = compararMapas(objetoJsonPkConvenioSerieR, mapaConvenioSerie,
                	lstRectiConvenioSerie = compararMapas(objetoJsonPkConvenioSerieR2, mapaConvenioSerie,
                    Constantes.COD_TABLA_CONVENIO_SERIE_DESC, pk, codTipoRectificacion, numSecCambio,
                    desClave, codTabla, mapDescripcion);
                // agrego el listado al listado final
                lstConvenioSerie.add(lstRectiConvenioSerie);
                break;
              }
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FORMB_ITEM_DESCRI))
        {
          // obtengo Pk JSON
          objetoJsonPkFormbItemDescriR = mapaItemRectifica.get("DES_CLAVE");// DOCUMENTO ASOCIADOS
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkFormbItemDescriR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkFormbItemDescriR);

          Map fbKeys = new HashMap();
          fbKeys.put("NUM_SECITEM", new Long(mapPkFormbItemDescriR.get("NUM_SECITEM").toString()));
          // 20120516 NSR Por un error en el registro en la transmision
          // electronica esta registrando cod_mercancia = null
          // se comenta mientras no se solucione
          // 20120726 GIMJ se descomenta para poder grabar en det_ofirecti.
          fbKeys.put("COD_MERCANCIA", mapPkFormbItemDescriR.get("COD_MERCANCIA") == " " ? null : mapPkFormbItemDescriR
              .get("COD_MERCANCIA")
              .toString());
          if(mapPkFormbItemDescriR.get("NUM_SECFACT")!=null){//BUG PUEDE SER DATO RECTIFICADO NO ES PK 		PAS20155E220200139
        	  mapPkFormbItemDescriR.remove("NUM_SECFACT");			//PAS20155E220200139
          //fbKeys.put("NUM_SECFACT", new Long(mapPkFormbItemDescriR.get("NUM_SECFACT").toString())); //BUG PUEDE SER DATO RECTIFICADO NO ES PK 			PAS20155E220200139
          }
          fbKeys.put("COD_TIPDESC", mapPkFormbItemDescriR.get("COD_TIPDESC").toString());
			//PAS20155E220200139
          if(mapPkFormbItemDescriR.get("NUM_SECPROVE")!=null){
        	  mapPkFormbItemDescriR.remove("NUM_SECPROVE");
           //fbKeys.put("NUM_SECPROVE", new Long(mapPkFormbItemDescriR.get("NUM_SECPROVE").toString())); //BUG PUEDE SER DATO RECTIFICADO NO ES PK 			PAS20155E220200139
          }
			//PAS20155E220200139
          //rtineo mejoras, se implmento un nuevo metodo de busqueda
          //Map<String, Object> mapaFormbItemDescri = Utilidades.obtenerElemento(lstFormbItemDescriH, fbKeys);
          Map<String, Object> mapaFormbItemDescri = Utilidades.obtenerElementoNew(mapFormbItemDescriH, fbKeys);
          //rtineo fin mejoras
          objetoJsonFormbItemDescriR = mapaItemRectifica.get("DES_DATA");
          if (objetoJsonFormbItemDescriR != null && objetoJsonFormbItemDescriR.toString().trim().length() > 0)
          {
            Map<String, Object> temp = (Map<String, Object>) serializer.deserialize(objetoJsonFormbItemDescriR);
            objetoJsonFormbItemDescriR = serializer.serialize(temp);
          }
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";

          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          List<Map<String, Object>> lstRectiFormbItemDescri = compararMapas(objetoJsonFormbItemDescriR,
              mapaFormbItemDescri, "FORMBITEMDESCRI", fbKeys.get("COD_TIPDESC").toString(), codTipoRectificacion,
              numSecCambio, desClave, codTabla, mapDescripcion);
          lstFormbItemDescri.add(lstRectiFormbItemDescri);
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CAB_CERTIORIGEN))
        {
          // obtengo Pk JSON
          objetoJsonPkCertOrigenR = mapaItemRectifica.get("DES_CLAVE");// DOCUMENTO ASOCIADOS
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkCertOrigenR = (Map<String, Object>) serializer.deserialize(objetoJsonPkCertOrigenR);

          Map fbKeys = new HashMap();
          fbKeys.put("NUM_SECDOC", new Long(mapPkCertOrigenR.get("NUM_SECDOC").toString()));
          fbKeys.put("COD_TIPOPER", mapPkCertOrigenR.get("COD_TIPOPER").toString());
          Map<String, Object> mapaCertOrigen = Utilidades.obtenerElemento(lstCertOrigenH, fbKeys);
          objetoJsonCertOrigenR = mapaItemRectifica.get("DES_DATA");
          if (objetoJsonCertOrigenR != null && objetoJsonCertOrigenR.toString().trim().length() > 0)
          {
            Map<String, Object> temp = (Map<String, Object>) serializer.deserialize(objetoJsonCertOrigenR);
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            Date date;
            try
            {
              if (temp.get("FEC_CERTIFICADO") != null)
              {
                date = (Date) df.parse(temp.get("FEC_CERTIFICADO").toString().substring(0, 10));
                temp.put("FEC_CERTIFICADO", SunatDateUtils.getFormatDate(date, "dd/MM/yyyy"));
              }
              if (temp.get("FEC_INIPERIODOEMB") != null)
              {
                date = (Date) df.parse(temp.get("FEC_INIPERIODOEMB").toString().substring(0, 10));
                temp.put("FEC_INIPERIODOEMB", SunatDateUtils.getFormatDate(date, "dd/MM/yyyy"));
              }
              if (temp.get("FEC_FINPEREMB") != null)
              {
                date = (Date) df.parse(temp.get("FEC_FINPEREMB").toString().substring(0, 10));
                temp.put("FEC_FINPEREMB", SunatDateUtils.getFormatDate(date, "dd/MM/yyyy"));
              }
              if (temp.get("FEC_EMBORIGEN") != null)
              {
                date = (Date) df.parse(temp.get("FEC_EMBORIGEN").toString().substring(0, 10));
                temp.put("FEC_EMBORIGEN", SunatDateUtils.getFormatDate(date, "dd/MM/yyyy"));
              }
            }
            catch (ParseException pe)
            {
              throw new RuntimeException(pe);
            }
            objetoJsonCertOrigenR = serializer.serialize(temp);
          }
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          List<Map<String, Object>> lstRectiCertOrigen = compararMapas(objetoJsonCertOrigenR, mapaCertOrigen,
              "CAB_CERTIORIGEN", fbKeys.get("NUM_SECDOC").toString(), codTipoRectificacion, numSecCambio, desClave,
              codTabla, mapDescripcion);
          lstCertOrigen.add(lstRectiCertOrigen);

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FORMA_FACTU))
        {
          // FORMA_FACTU
          // no tocar por que se puede caer en regularizacion
          objetoJsonPkFacturasR = mapaItemRectifica.get("DES_CLAVE");
          objetoJsonFacturasR = mapaItemRectifica.get("DES_DATA");
          JsonSerializer serializer = new JsonSerializer();
          // JSon que estaba serializado lo des y lo convierto a obeto
          // este nuevo objeto esta desseriasalod y es Map
          Map<String, Object> mapPkFacturasR = (Map<String, Object>) serializer.deserialize(objetoJsonPkFacturasR);
          String pk = mapPkFacturasR.get("NUM_SECFACT").toString();

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiIndicadorDUA = compararMapas(objetoJsonFacturasR, null,
                Constantes.COD_TABLA_FORMA_FACTU_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstFacturasFormA.add(lstRectiIndicadorDUA);
            continue;
          }

          // recorro la lista de series Historicos
          Iterator i1 = lstFacturasFormAH.iterator();
          while (i1.hasNext())
          {
            DatoFacturaref factura = (DatoFacturaref) i1.next();

            if ((factura.getNumsecfactu().toString()).equals(pk))
            {

              Map<String, Object> mapaFactura = new HashMap<String, Object>();
              mapaFactura.put("NUM_CORREDOC", factura.getNumcorredoc());
              mapaFactura.put("NUM_SECFACT", factura.getNumsecfactu());
              mapaFactura.put("NUM_FACT", factura.getNumfactura());
              try
              {
                mapaFactura.put("FEC_FACT", DateUtil.dateToString(factura.getFecfactura(), "dd/MM/yyyy"));
              }
              catch (ParseException e)
              {
                throw new RuntimeException(e);
              }

              if (objetoJsonFacturasR != null && objetoJsonFacturasR.toString().trim().length() > 0)
              {
                Map<String, Object> temp = (Map<String, Object>) serializer.deserialize(objetoJsonFacturasR);
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date;
                if (temp.get("FEC_FACT") != null)
                {
                  try
                  {
                    date = (Date) df.parse(temp.get("FEC_FACT").toString().substring(0, 10));
                  }
                  catch (ParseException e)
                  {
                    throw new RuntimeException(e);
                  }
                  temp.put("FEC_FACT", SunatDateUtils.getFormatDate(date, "dd/MM/yyyy"));
                }
                objetoJsonFacturasR = serializer.serialize(temp);
              }
              List<Map<String, Object>> lstRectiFacturas = compararMapas(objetoJsonFacturasR,
                  mapaFactura, Constantes.COD_TABLA_FORMA_FACTU_DESC, pk, codTipoRectificacion,
                  numSecCambio, desClave, codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstFacturasFormA.add(lstRectiFacturas);
              break;
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_INDICADOR_DUA))
        {
          Object objetoPkJsonIndicadorDUAR = mapaItemRectifica.get("DES_CLAVE");// INDICADOR
                                                                                // DUA
          Object objetoJsonIndicadorDUAR = mapaItemRectifica.get("DES_DATA");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPkIndicadorDUAR = (Map<String, Object>) serializer
              .deserialize(objetoPkJsonIndicadorDUAR);

          Map fbKeys = new HashMap();
          fbKeys.put("COD_INDICADOR", mapPkIndicadorDUAR.get("COD_INDICADOR").toString());

          String pk = mapPkIndicadorDUAR.get("COD_INDICADOR").toString();
          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiIndicadorDUA = compararMapas(objetoPkJsonIndicadorDUAR, null,
                Constantes.COD_TABLA_INDICADOR_DUA_DESC,
                pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstIndicadorDUA.add(lstRectiIndicadorDUA);
            continue;
          }

          Map<String, Object> mapaIndicadorDUA = Utilidades.obtenerElemento(lstIndicadorDUAH, fbKeys);
          log.debug("mapaIndicadorDUA::>>" + mapaIndicadorDUA);

          log.debug("objetoJsonIndicadorDUAR:>>>" + objetoJsonIndicadorDUAR);

          List<Map<String, Object>> lstRectiIndicadorDUA = compararMapas(objetoJsonIndicadorDUAR,
              mapaIndicadorDUA, Constantes.COD_TABLA_INDICADOR_DUA_DESC, pk, codTipoRectificacion,
              numSecCambio, desClave, codTabla, mapDescripcion);
          log.debug("lstRectiIndicadorDUA:" + lstRectiIndicadorDUA);
          lstIndicadorDUA.add(lstRectiIndicadorDUA);
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_OBSERVACION)
            && lstObservacionH != null)
        {
          // obtenemos los datos rectificados de las observaciones
          List<Map<String, Object>> observacionRectificada = obtenerDatosObservacionRectificados(
              lstObservacionH, mapaItemRectifica);
          if (!CollectionUtils.isEmpty(observacionRectificada))
          {
            lstObservacion.add(observacionRectificada);
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_PARTICIPANTE_DOC))
        {
          // obtenemos los datos rectificados del participante
          lstParticipanteDoc.add(obtenerDatosParticipanteRectificados(
              lstParticipanteDocH, mapaItemRectifica));

        }
        else if (Constantes.COD_TABLA_DET_AUTORIZACION.equals(mapaItemRectifica.get("COD_TABLA")))
        {
          // obtenemos los datos rectificados de la tabla det_autorizacion
          lstDetAutorizacion.add(obtenerDatosDetAutorizacionRectificados(
              lstDetAutorizacionH, mapaItemRectifica));
        }
        else if (Constantes.COD_TABLA_FACTURA_SERIE.equals(mapaItemRectifica.get("COD_TABLA")))
        {

          Object objetoJsonPkFacturaSerieR = mapaItemRectifica.get("DES_CLAVE");
          Object objetoJsonFacturaSerieR = mapaItemRectifica.get("DES_DATA");
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();
          Map<String, Object> mapPkFacturaSerieR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkFacturaSerieR);

          pkR.append((mapPkFacturaSerieR.get("NUM_SECSERIE") != null) ? mapPkFacturaSerieR
              .get("NUM_SECSERIE")
              .toString() : "");

          pkR.append((mapPkFacturaSerieR.get("NUM_SECFACT") != null) ? mapPkFacturaSerieR.get("NUM_SECFACT").toString()
              : "");

          String pk = pkR.toString();

          pkR.append((mapPkFacturaSerieR.get("NUM_CORREDOC") != null) ? mapPkFacturaSerieR
              .get("NUM_CORREDOC")
              .toString() : "");

          String tablaDesc = "FACTURA_SERIE";

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFacturaSerie = compararMapas(objetoJsonFacturaSerieR, null,
                tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstFacturaSerie.add(lstRectiFacturaSerie);
            continue;
          }

          Iterator i1 = lstFacturaSerieH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaFacturaSerieItem = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaFacturaSerieItem.get("NUM_SECSERIE") != null) ? mapaFacturaSerieItem
                .get("NUM_SECSERIE")
                .toString() : "");

            pkH.append((mapaFacturaSerieItem.get("NUM_SECFACT") != null) ? mapaFacturaSerieItem
                .get("NUM_SECFACT")
                .toString() : "");

            pk = pkH.toString();

            pkH.append((mapaFacturaSerieItem.get("NUM_CORREDOC") != null) ? mapaFacturaSerieItem
                .get("NUM_CORREDOC")
                .toString() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {

              List<Map<String, Object>> lstRectiFacturaSerie = compararMapas(
                  objetoJsonFacturaSerieR,
                    mapaFacturaSerieItem,
                    tablaDesc,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstFacturaSerie.add(lstRectiFacturaSerie);
              break;
            }
          }
        }
        else if (Constantes.COD_TABLA_VFOB_PROVISIONAL.equals(mapaItemRectifica.get("COD_TABLA")))
        {
          // lstObs.add(mapaItemRectifica);
          Object objetoJsonPkVFobProvisionalR = mapaItemRectifica.get("DES_CLAVE");
          Object objetoJsonVFobProvisionalR = mapaItemRectifica.get("DES_DATA");
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();
          Map<String, Object> mapPkVFobProvisionalR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkVFobProvisionalR);

          pkR.append((mapPkVFobProvisionalR.get("NUM_SECITEM") != null) ? mapPkVFobProvisionalR
              .get("NUM_SECITEM")
              .toString() : "");
         /*RIN10-FSW AFMA
          pkR.append((mapPkVFobProvisionalR.get("NUM_SECFACT") != null) ? mapPkVFobProvisionalR
              .get("NUM_SECFACT")
              .toString() : "");

          pkR.append((mapPkVFobProvisionalR.get("NUM_SECPROVE") != null) ? mapPkVFobProvisionalR
              .get("NUM_SECPROVE")
              .toString() : "");
          */
          String pk = pkR.toString();

          pkR.append((mapPkVFobProvisionalR.get("NUM_CORREDOC") != null) ? mapPkVFobProvisionalR
              .get("NUM_CORREDOC")
              .toString() : "");

          String tablaDesc = "VFOBPROVISIONAL";

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFacturaSerie = compararMapas(objetoJsonVFobProvisionalR, null,
                tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            lstVFobProvisional.add(lstRectiFacturaSerie);
            continue;
          }

          Iterator i1 = lstVFobProvisionalH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaVFobProvisional = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaVFobProvisional.get("NUM_SECITEM") != null) ? mapaVFobProvisional
                .get("NUM_SECITEM")
                .toString() : "");
/*RIN10-FSW AFMA
            pkH.append((mapaVFobProvisional.get("NUM_SECFACT") != null) ? mapaVFobProvisional
                .get("NUM_SECFACT")
                .toString() : "");

            pkH.append((mapaVFobProvisional.get("NUM_SECPROVE") != null) ? mapaVFobProvisional
                .get("NUM_SECPROVE")
                .toString() : "");*/

            pk = pkH.toString();

            pkH.append((mapaVFobProvisional.get("NUM_CORREDOC") != null) ? mapaVFobProvisional
                .get("NUM_CORREDOC")
                .toString() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {

              List<Map<String, Object>> lstRectiFacturaSerie = compararMapas(
                  objetoJsonVFobProvisionalR,
                    mapaVFobProvisional,
                    tablaDesc,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla, mapDescripcion);
              // agrego el listado al listado final
              lstVFobProvisional.add(lstRectiFacturaSerie);
              break;
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FIN_UBICACION))
        {
          objetoJsonPkFinUbicacionR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPKFinUbicacion = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkFinUbicacionR);
          String pkFinUbicacion = mapPKFinUbicacion.get("NUM_CORREDOC").toString();

          objetoJsonFinUbicacionR = mapaItemRectifica.get("DES_DATA") != null ? mapaItemRectifica
              .get("DES_DATA")
              .toString()
              .trim() : "";
          log.debug("objetoJsonFinUbicacionR:>>>" + objetoJsonFinUbicacionR);
          String codTipoRectificacion = mapaItemRectifica.get("IND_RECTIFICA") != null ? (String) mapaItemRectifica
              .get("IND_RECTIFICA") : "";

          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";
          // fin

          List<Map<String, Object>> lstRectiFinUbicacion = compararMapas(objetoJsonFinUbicacionR, mapFinUbicacionH,
              Constantes.COD_TABLA_FIN_UBICACION_DESC, pkFinUbicacion, codTipoRectificacion, numSecCambio,
              desClave, codTabla, mapDescripcion);
          log.debug("lstRectiFinUbicacion:" + lstRectiFinUbicacion);
          lstFinUbicacion.add(lstRectiFinUbicacion);

          // CONDICION_TRANSA
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CONDICION_TRANSA))
        {

          objetoJsonPkCondicionTransaR = mapaItemRectifica.get("DES_CLAVE");
          objetoJsonCondicionTransaR = mapaItemRectifica.get("DES_DATA");
          log.debug("objetoJsonCondicionTransaR:>>>" + objetoJsonCondicionTransaR);
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();

          // {"COD_INDTRANSACCION":"02","NUM_CORREDOC":8286,"NUM_SECPROVE":1}
          Map<String, Object> mapPkCondicionTransaR = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkCondicionTransaR);
          pkR.append((mapPkCondicionTransaR.get("NUM_SECPROVE") != null) ? mapPkCondicionTransaR
              .get("NUM_SECPROVE")
              .toString() : "");
          pkR.append((mapPkCondicionTransaR.get("COD_INDTRANSACCION") != null) ? mapPkCondicionTransaR.get(
              "COD_INDTRANSACCION").toString() : "");

          String pk = pkR.toString();

          pkR.append((mapPkCondicionTransaR.get("NUM_CORREDOC") != null) ? mapPkCondicionTransaR
              .get("NUM_CORREDOC")
              .toString() : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiCondicionTransa = compararMapas(
                objetoJsonCondicionTransaR,
                  null,
                  Constantes.COD_TABLA_CONDICION_TRANSA_DESC,
                  pk,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);
            // agrego el listado al listado final
            log.debug("Neo lstRectiCondicionTransa:" + lstRectiCondicionTransa);
            lstCondicionTransa.add(lstRectiCondicionTransa);
          }

          Iterator i1 = lstCondiTransaH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaCondicionTransa = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaCondicionTransa.get("NUM_SECPROVE") != null) ? mapaCondicionTransa
                .get("NUM_SECPROVE")
                .toString() : "");
            pkH.append((mapaCondicionTransa.get("COD_INDTRANSACCION") != null) ? mapaCondicionTransa.get(
                "COD_INDTRANSACCION").toString() : "");
            pk = pkH.toString();
            pkH.append((mapaCondicionTransa.get("NUM_CORREDOC") != null) ? mapaCondicionTransa
                .get("NUM_CORREDOC")
                .toString() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              List<Map<String, Object>> lstRectiCondicionTransa = compararMapas(
                  objetoJsonCondicionTransaR,
                    mapaCondicionTransa,
                    Constantes.COD_TABLA_CONDICION_TRANSA_DESC,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla, mapDescripcion);
              // agrego el listado al listado final
              log.debug("lstRectiCondicionTransa:" + lstRectiCondicionTransa);
              lstCondicionTransa.add(lstRectiCondicionTransa);
              break;
            }
          }

          // CAD_ADI_IMPOCONSU
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU))
        {

          // lstCabAdiImpoConsu
          objetoJsonPkCabAdiImpoConsuR = mapaItemRectifica.get("DES_CLAVE");
          JsonSerializer serializer = new JsonSerializer();
          Map<String, Object> mapPKCabAdiImpoConsu = (Map<String, Object>) serializer
              .deserialize(objetoJsonPkCabAdiImpoConsuR);
          String pkCabAdiImpoConsu = mapPKCabAdiImpoConsu.get("NUM_CORREDOC").toString();

          objetoJsonCabAdiImpoConsuR = mapaItemRectifica.get("DES_DATA") != null ? mapaItemRectifica
              .get("DES_DATA")
              .toString()
              .trim() : "";
          log.debug("objetoJsonCabAdiImpoConsuR:>>>" + objetoJsonCabAdiImpoConsuR);
          String codTipoRectificacion = mapaItemRectifica.get("IND_RECTIFICA") != null ? (String) mapaItemRectifica
              .get("IND_RECTIFICA") : "";

          // datos ncesario para la grabacion
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiCabAdiImpoConsu = compararMapas(
                objetoJsonCabAdiImpoConsuR,
                  null,
                  Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU_DESC,
                  pkCabAdiImpoConsu,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);

            log.debug("Neo lstRectiCabAdiImpoConsu:" + lstRectiCabAdiImpoConsu);
            lstCabAdiImpoConsu.add(lstRectiCabAdiImpoConsu);
          }

          Iterator i1 = lstCabAdiImpoConsuH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaCabAdiImpoConsu = (Map<String, Object>) i1.next();

            List<Map<String, Object>> lstRectiCabAdiImpoConsu = compararMapas(
                objetoJsonCabAdiImpoConsuR,
                  mapaCabAdiImpoConsu,
                  Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU_DESC,
                  pkCabAdiImpoConsu,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);
            log.debug("lstRectiCabAdiImpoConsu:" + lstRectiCabAdiImpoConsu);
            lstCabAdiImpoConsu.add(lstRectiCabAdiImpoConsu);
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_VEHI_CETICO))
        {

          objetoJsonPkVehiCeticoR = mapaItemRectifica.get("DES_CLAVE");
          objetoJsonVehiCeticoR = mapaItemRectifica.get("DES_DATA");
          log.debug("objetoJsonVehiCeticoR:" + objetoJsonVehiCeticoR);
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();

          Map<String, Object> mapPkVehiCeticoR = (Map<String, Object>) serializer.deserialize(objetoJsonPkVehiCeticoR);
          pkR.append((mapPkVehiCeticoR.get("NUM_SECSERIE") != null) ? mapPkVehiCeticoR.get("NUM_SECSERIE").toString()
              : "");

          String pk = pkR.toString();

          pkR.append((mapPkVehiCeticoR.get("NUM_CORREDOC") != null) ? mapPkVehiCeticoR.get("NUM_CORREDOC").toString()
              : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiVehiCetico = compararMapas(objetoJsonVehiCeticoR, null,
                Constantes.COD_TABLA_VEHI_CETICO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            log.debug("Neo lstRectiVehiCetico:" + lstRectiVehiCetico);
            lstVehiCetico.add(lstRectiVehiCetico);
          }

          Iterator i1 = lstVehiCeticoH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaVehiCetico = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaVehiCetico.get("NUM_SECSERIE") != null) ? mapaVehiCetico.get("NUM_SECSERIE").toString()
                : "");
            pk = pkH.toString();
            pkH.append((mapaVehiCetico.get("NUM_CORREDOC") != null) ? mapaVehiCetico.get("NUM_CORREDOC").toString()
                : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              List<Map<String, Object>> lstRectiVehiCetico = compararMapas(
                  objetoJsonVehiCeticoR,
                    mapaVehiCetico,
                    Constantes.COD_TABLA_VEHI_CETICO_DESC,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla, mapDescripcion);
              // agrego el listado al listado final
              log.debug("lstRectiVehiCetico:" + lstRectiVehiCetico);
              lstVehiCetico.add(lstRectiVehiCetico);
            }
          }

        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FACTUSUCE))
        {

          objetoJsonPkFactuSuceR = mapaItemRectifica.get("DES_CLAVE");
          objetoJsonFactuSuceR = mapaItemRectifica.get("DES_DATA");
          log.debug("objetoJsonFactuSuceR:" + objetoJsonFactuSuceR);
          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();

          Map<String, Object> mapPkFactuSuceR = (Map<String, Object>) serializer.deserialize(objetoJsonPkFactuSuceR);
          pkR.append((mapPkFactuSuceR.get("NUM_SECPROVE") != null) ? mapPkFactuSuceR.get("NUM_SECPROVE").toString()
              : "");
          pkR.append((mapPkFactuSuceR.get("NUM_SECFACT") != null) ? mapPkFactuSuceR.get("NUM_SECFACT").toString() : "");

          String pk = pkR.toString();

          pkR.append((mapPkFactuSuceR.get("NUM_CORREDOC") != null) ? mapPkFactuSuceR.get("NUM_CORREDOC").toString()
              : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFactuSuce = compararMapas(objetoJsonFactuSuceR, null,
                Constantes.COD_TABLA_FACTUSUCE_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            // agrego el listado al listado final
            log.debug("Neo lstRectiFactuSuce:" + lstRectiFactuSuce);
            lstFactuSuce.add(lstRectiFactuSuce);
          }

          Iterator i1 = lstFactuSuceH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaFactuSuce = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();

            pkH.append((mapaFactuSuce.get("NUM_SECPROVE") != null) ? mapaFactuSuce.get("NUM_SECPROVE").toString() : "");
            pkH.append((mapaFactuSuce.get("NUM_SECFACT") != null) ? mapaFactuSuce.get("NUM_SECFACT").toString() : "");
            pk = pkH.toString();
            pkH.append((mapaFactuSuce.get("NUM_CORREDOC") != null) ? mapaFactuSuce.get("NUM_CORREDOC").toString() : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              List<Map<String, Object>> lstRectiFactuSuce = compararMapas(objetoJsonFactuSuceR, mapaFactuSuce,
                  Constantes.COD_TABLA_FACTUSUCE_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
              // agrego el listado al listado final
              log.debug("lstRectiFactuSuce:" + lstRectiFactuSuce);
              lstFactuSuce.add(lstRectiFactuSuce);
            }
          }
          // FORMBMONTOS
        }
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_FORMB_MONTO))
        {

          objetoJsonPkFormbMontoR = mapaItemRectifica.get("DES_CLAVE");
          objetoJsonFormbMontoR = mapaItemRectifica.get("DES_DATA");

          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();

          Map<String, Object> mapPkFormbMontoR = (Map<String, Object>) serializer.deserialize(objetoJsonPkFormbMontoR);
          pkR.append((mapPkFormbMontoR.get("NUM_SECPROVE") != null) ? mapPkFormbMontoR.get("NUM_SECPROVE").toString()
              : "");
          pkR.append((mapPkFormbMontoR.get("COD_MONTO") != null) ? mapPkFormbMontoR.get("COD_MONTO").toString() : "");

          String pk = pkR.toString();

          pkR.append((mapPkFormbMontoR.get("NUM_CORREDOC") != null) ? mapPkFormbMontoR.get("NUM_CORREDOC").toString()
              : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFormbMonto = compararMapas(objetoJsonFormbMontoR, null,
                Constantes.COD_TABLA_FORMB_MONTO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
            lstFormbMonto.add(lstRectiFormbMonto);
          }
          Iterator i1 = lstFormbMontoH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaFormbMonto = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();
            pkH.append((mapaFormbMonto.get("NUM_SECPROVE") != null) ? mapaFormbMonto.get("NUM_SECPROVE").toString()
                : "");
            pkH.append((mapaFormbMonto.get("COD_MONTO") != null) ? mapaFormbMonto.get("COD_MONTO").toString() : "");
            pk = pkH.toString();
            pkH.append((mapaFormbMonto.get("NUM_CORREDOC") != null) ? mapaFormbMonto.get("NUM_CORREDOC").toString()
                : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              List<Map<String, Object>> lstRectiFormbMonto = compararMapas(objetoJsonFormbMontoR, mapaFormbMonto,
                  Constantes.COD_TABLA_FORMB_MONTO_DESC, pk, codTipoRectificacion, numSecCambio, desClave, codTabla, mapDescripcion);
              lstFormbMonto.add(lstRectiFormbMonto);
              break;
            }
          }
        }

        // MONTO_GASTO
        else if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_MONTO_GASTO))
        {

          Object objetoJsonPkMontoGastoR = mapaItemRectifica.get("DES_CLAVE");
          Object objetoJsonMontoGastoR = mapaItemRectifica.get("DES_DATA");

          JsonSerializer serializer = new JsonSerializer();
          StringBuilder pkR = new StringBuilder();

          Map<String, Object> mapPkMontoGastoR = (Map<String, Object>) serializer.deserialize(objetoJsonPkMontoGastoR);
          pkR.append((mapPkMontoGastoR.get("COD_CPTOGASTOS") != null) ? mapPkMontoGastoR
              .get("COD_CPTOGASTOS")
              .toString() : "");

          String pk = pkR.toString();

          pkR.append((mapPkMontoGastoR.get("NUM_SECSERIE") != null) ? mapPkMontoGastoR.get("NUM_SECSERIE").toString()
              : "");
          pkR.append((mapPkMontoGastoR.get("NUM_CORREDOC") != null) ? mapPkMontoGastoR.get("NUM_CORREDOC").toString()
              : "");

          String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
          String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
              .get("NUM_SECCAMBIO")
              .toString() : "";
          String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE")
              : "";
          String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA")
              : "";

          if (codTipoRectificacion.equals(NUEVO_REGISTRO))
          {
            List<Map<String, Object>> lstRectiFormbMonto = compararMapas(
                objetoJsonMontoGastoR,
                  null,
                  Constantes.COD_TABLA_MONTO_GASTO_DESC,
                  pk,
                  codTipoRectificacion,
                  numSecCambio,
                  desClave,
                  codTabla, mapDescripcion);
            lstMontoGasto.add(lstRectiFormbMonto);
          }
          Iterator i1 = lstMontoGastoH.iterator();
          while (i1.hasNext())
          {
            Map<String, Object> mapaFormbMonto = (Map<String, Object>) i1.next();
            StringBuilder pkH = new StringBuilder();
            pkH.append((mapaFormbMonto.get("COD_CPTOGASTOS") != null) ? mapaFormbMonto.get("COD_CPTOGASTOS").toString()
                : "");
            pk = pkH.toString();

            pkH.append((mapaFormbMonto.get("NUM_SECSERIE") != null) ? mapaFormbMonto.get("NUM_SECSERIE").toString()
                : "");
            pkH.append((mapaFormbMonto.get("NUM_CORREDOC") != null) ? mapaFormbMonto.get("NUM_CORREDOC").toString()
                : "");

            if ((pkH.toString()).equals(pkR.toString()))
            {
              List<Map<String, Object>> lstRectiMontoGasto = compararMapas(
                  objetoJsonMontoGastoR,
                    mapaFormbMonto,
                    Constantes.COD_TABLA_MONTO_GASTO_DESC,
                    pk,
                    codTipoRectificacion,
                    numSecCambio,
                    desClave,
                    codTabla, mapDescripcion);
              lstMontoGasto.add(lstRectiMontoGasto);
              break;
            }
          }
        }       

      } // while

      // las listas se agregan al mapa a devolver
      data.put(Constantes.COD_TABLA_DET_DECLARA, lstDetDeclara);
      data.put(Constantes.COD_TABLA_DET_ADI_IMPO_CONSU, lstDetAdiconsu);
      data.put(Constantes.COD_TABLA_DET_ADI_ATPA, lstDetAdiAtpa);
      data.put(Constantes.COD_TABLA_DET_ADI_ATREEX, lstDetAdiAtreex);
      data.put(Constantes.COD_TABLA_EQUIPAMIENTO, lstEquipamiento);
      
      data.put(Constantes.COD_TABLA_PRECINTO, lstPrecinto);
      data.put(Constantes.COD_TABLA_DOCAUT_ASOCIADO, lstDocAsociados);
      data.put(Constantes.COD_TABLA_DOCUPRECE_DUA, lstRegPrecedente);
      data.put(Constantes.COD_TABLA_FORMB_PROVEEDOR, lstFormatoBDAV);
      data.put(Constantes.COD_TABLA_COMPROBPAGO, lstFormatoBFacturas);
      data.put(Constantes.COD_TABLA_ITEM_FACTURA, lstItemsFactura);
      data.put(Constantes.COD_TABLA_CONVENIO_SERIE, lstConvenioSerie);
      data.put(Constantes.COD_TABLA_CAB_CERTIORIGEN, lstCertOrigen);
      data.put(Constantes.COD_TABLA_FORMA_FACTU, lstFacturasFormA);
      data.put(Constantes.COD_TABLA_INDICADOR_DUA, lstIndicadorDUA);
      data.put(Constantes.COD_TABLA_PARTICIPANTE_DOC, lstParticipanteDoc);
      data.put(Constantes.COD_TABLA_DET_AUTORIZACION, lstDetAutorizacion);
      data.put(Constantes.COD_TABLA_FACTURA_SERIE, lstFacturaSerie);
      data.put(Constantes.COD_TABLA_VFOB_PROVISIONAL, lstVFobProvisional);
      data.put(Constantes.COD_TABLA_OBSERVACION, lstObservacion);
      data.put(Constantes.COD_TABLA_FIN_UBICACION, lstFinUbicacion);
      data.put(Constantes.COD_TABLA_CONDICION_TRANSA, lstCondicionTransa);
      data.put(Constantes.COD_TABLA_CAB_ADI_IMPO_CONSU, lstCabAdiImpoConsu);
      data.put(Constantes.COD_TABLA_VEHI_CETICO, lstVehiCetico);
      data.put(Constantes.COD_TABLA_FACTUSUCE, lstFactuSuce);
      data.put(Constantes.COD_TABLA_FORMB_MONTO, lstFormbMonto);
      data.put(Constantes.COD_TABLA_FORMB_ITEM_DESCRI, lstFormbItemDescri);
      data.put(Constantes.COD_TABLA_MONTO_GASTO, lstMontoGasto);
      /* PAS20145E220000399 INICIO GGRANADOS */
      data.put(Constantes.COD_TABLA_SERIES_ITEM, lstFormatoBSeriesItem);
      /* PAS20145E220000399 FIN GGRANADOS */


    }
    return data;

  }

  /**
   * Metodo que da formato al campo fecha de un dato rectificado.
   *
   * @param lstRecticados
   *          the lst recticados
   */
  private void formatFecha(List<Map<String, Object>> lstRecticados)
  {

        //validaciones de datos de entrada
        if(CollectionUtils.isEmpty(lstRecticados)){
            return;
        }

    String preficoFecha = "FEC_";
    String nombreCampo = "";
         for (Map<String, Object> rectificado : lstRecticados) {
      nombreCampo = (String) rectificado.get("CAMPO");
      nombreCampo.trim();
                nombreCampo.toUpperCase(); //si viene en minusula lo
                Object valorR = rectificado.get("VALORR");
                Object valorH = rectificado.get("VALORH");
                if(nombreCampo.startsWith(preficoFecha)){
                    try {
                        rectificado.put("VALORR",SunatDateUtils.getFormatDate(Utilidades.toDate(valorR),"dd/MM/yyyy"));
                        rectificado.put("VALORH",SunatDateUtils.getFormatDate(Utilidades.toDate(valorH),"dd/MM/yyyy"));
                    }catch(Exception e){
                        // no hacemos nada si ocurre algun error no se mdifica nada
                        if(log.isDebugEnabled()){
                            log.debug("********FORMATOS DE FECHA ERROR *******");
                            log.debug("valorR:"+valorR);
                            log.debug("valorH:"+valorH);
                            log.debug("********FIN DE FECHA ERROR      *******");
                        }
                    }
                }
        }


  }



    /**
     * devuelve el formato para los campos fecha
     * de tener fecga por fedecto retorna vacio
     *
     * @param nombreCampo the nombre campo
     * @param valorCampo the valor campo
     * @return string
     */
  private Object formatoFecha(String nombreCampo, Object valorCampo)
  {

    String preficoFecha = "FEC_";
    if (nombreCampo.startsWith(preficoFecha))
    {
      try
      {
        valorCampo = SunatDateUtils.getFormatDate(Utilidades.toDate(valorCampo), "dd/MM/yyyy");
      }
      catch (Exception e)
      {
        // no hacemos nada si ocurre algun error no se mdifica nada
        if (log.isDebugEnabled())
        {
          StringBuilder sb = new StringBuilder("ERROR-FORMATO al evaluar el dato");
          sb.append("campo:");
          sb.append(nombreCampo);
          sb.append("valor:");
          sb.append(valorCampo);
          log.debug(sb.toString(), e);
        }
      }
    }

    return valorCampo;
  }




  /**
   * metodo que realiza el merge de los datos rectificados con los datos
   * actuales de la base de datos.
   *
   * @param lstObservacionH
   *          lista con los registros de la tabla observacion optenidos de la
   *          base de datos
   * @param mapaItemRectifica
   *          mapa con los datos a ser rectificados
   * @return lista con los datos a ser modificados
   */
  private List<Map<String, Object>> obtenerDatosObservacionRectificados(
    List<Map<String, Object>> lstObservacionH,
    Map<String, Object> mapaItemRectifica)
  {
    List<Map<String, Object>> lstRectiObservacion = null;
    Object objetoJsonPkObservacionR = mapaItemRectifica.get("DES_CLAVE");
    Object objetoJsonObservacionR = mapaItemRectifica.get("DES_DATA");
    JsonSerializer serializer = new JsonSerializer();
    StringBuilder pkR = new StringBuilder();
    Map<String, Object> mapPkObservacionR = (Map<String, Object>) serializer.deserialize(objetoJsonPkObservacionR);
    pkR.append((mapPkObservacionR.get("COD_TIPOBS") != null) ? mapPkObservacionR.get("COD_TIPOBS").toString()
        : "");

    // no necesitamos el num_corredoc como pk
    String pk = pkR.toString();

    pkR.append((mapPkObservacionR.get("NUM_SECOBS") != null) ? mapPkObservacionR.get("NUM_SECOBS").toString()
        : "");

    pkR.append((mapPkObservacionR.get("NUM_CORREDOC") != null) ? mapPkObservacionR.get("NUM_CORREDOC").toString()
        : "");

    String tablaDesc = "OBSERVACION";

    String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
    String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
        .get("NUM_SECCAMBIO")
        .toString() : "";
    String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE") : "";
    String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA") : "";

    if (codTipoRectificacion.equals(NUEVO_REGISTRO) && !"05".equals(mapPkObservacionR.get("COD_TIPOBS")))
    {
      lstRectiObservacion = compararMapas(objetoJsonObservacionR, null,
          tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla);
      // agrego el listado al listado final
    }
    else
    {

      Iterator i1 = lstObservacionH.iterator();
      while (i1.hasNext())
      {
        Map<String, Object> mapaObservacionItem = (Map<String, Object>) i1.next();
        StringBuilder pkH = new StringBuilder();
        pkH
            .append(
            (mapaObservacionItem.get("COD_TIPOBS") != null) ? mapaObservacionItem.get("COD_TIPOBS").toString() : "");
        // pk para mostar en el jsp
        pk = pkH.toString();

        pkH.append(
            (mapaObservacionItem.get("NUM_SECOBS") != null) ? mapaObservacionItem.get("NUM_SECOBS").toString() : "");
        pkH
            .append(
            (mapaObservacionItem.get("NUM_CORREDOC") != null) ? mapaObservacionItem.get("NUM_CORREDOC").toString() : "");

        if ((pkH.toString()).equals(pkR.toString()))
        {

          lstRectiObservacion = compararMapas(objetoJsonObservacionR, mapaObservacionItem,
              tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla);
          // agrego el listado al listado final
          break;
        }
      }
    }
    return lstRectiObservacion;
  }

  /**
   * metodo que realiza el merge de los datos rectificados con los datos
   * actuales de la base de datos.
   *
   * @param lstDetAutorizacionH
   *          lista con los registros de la tabla det_autorizacion optenidos de
   *          la base de datos
   * @param mapaItemRectifica
   *          mapa con los datos a ser rectificados
   * @return lista con los datos a ser modificados
   */
  private List<Map<String, Object>> obtenerDatosDetAutorizacionRectificados(
    List<Map<String, Object>> lstDetAutorizacionH,
    Map<String, Object> mapaItemRectifica)
  {

    List<Map<String, Object>> lstRectiDetAutorizacion = null;

    Object objetoJsonPkDetAutorizacionR = mapaItemRectifica.get("DES_CLAVE");
    Object objetoJsonDetAutorizacionR = mapaItemRectifica.get("DES_DATA");
    JsonSerializer serializer = new JsonSerializer();
    StringBuilder pkR = new StringBuilder();
    Map<String, Object> mapPkDetAutorizacionR = (Map<String, Object>) serializer
        .deserialize(objetoJsonPkDetAutorizacionR);

    pkR.append((mapPkDetAutorizacionR.get("NUM_SECSERIE") != null) ? mapPkDetAutorizacionR
        .get("NUM_SECSERIE")
        .toString() : "");

    pkR.append((mapPkDetAutorizacionR.get("NUM_SECDOC") != null) ? mapPkDetAutorizacionR.get("NUM_SECDOC").toString()
        : "");

    pkR.append((mapPkDetAutorizacionR.get("COD_TIPOPER") != null) ? mapPkDetAutorizacionR.get("COD_TIPOPER").toString()
        : "");

    String pk = pkR.toString();

    pkR.append((mapPkDetAutorizacionR.get("NUM_CORREDOC") != null) ? mapPkDetAutorizacionR
        .get("NUM_CORREDOC")
        .toString() : "");

    String tablaDesc = "DET_AUTORIZACION";

    String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");
    String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
        .get("NUM_SECCAMBIO")
        .toString() : "";
    String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE") : "";
    String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA") : "";

    if (codTipoRectificacion.equals(NUEVO_REGISTRO))
    {
      lstRectiDetAutorizacion = compararMapas("", null,
          tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla);

    }
    else
    {

      Iterator i1 = lstDetAutorizacionH.iterator();
      while (i1.hasNext())
      {
        Map<String, Object> mapaDetAutorizacionItem = (Map<String, Object>) i1.next();
        StringBuilder pkH = new StringBuilder();

        pkH.append((mapPkDetAutorizacionR.get("NUM_SECSERIE") != null) ? mapPkDetAutorizacionR
            .get("NUM_SECSERIE")
            .toString() : "");

        pkH.append((mapPkDetAutorizacionR.get("NUM_SECDOC") != null) ? mapPkDetAutorizacionR
            .get("NUM_SECDOC")
            .toString() : "");

        pkH.append((mapPkDetAutorizacionR.get("COD_TIPOPER") != null) ? mapPkDetAutorizacionR
            .get("COD_TIPOPER")
            .toString() : "");

        pk = pkH.toString();

        pkH.append((mapPkDetAutorizacionR.get("NUM_CORREDOC") != null) ? mapPkDetAutorizacionR
            .get("NUM_CORREDOC")
            .toString() : "");

        if ((pkH.toString()).equals(pkR.toString()))
        {

          lstRectiDetAutorizacion = compararMapas(objetoJsonDetAutorizacionR, mapaDetAutorizacionItem,
              tablaDesc, pk, codTipoRectificacion, numSecCambio, desClave, codTabla);
          break;
        }
      }
    }
    return lstRectiDetAutorizacion;
  }

  /**
   * metodo que realiza el merge de lso datos rectificados con los datos
   * actuales de la base de datos.
   *
   * @param lstParticipanteDocH
   *          lista de participantes optenidos de la base de datos
   * @param mapaItemRectifica
   *          participante optenido de la transmicion de rectificacion
   * @return lista con los campos rectificados para el participante
   */
  private List<Map<String, Object>> obtenerDatosParticipanteRectificados(
    List<Map<String, Object>> lstParticipanteDocH,
    Map<String, Object> mapaItemRectifica)
  {

    List<Map<String, Object>> lstRectiParticipanteDoc = null;

    Object objetoJsonParticipanteDocR = mapaItemRectifica.get("DES_DATA");
    Object objetoJsonParticipanteDocPkR;
    objetoJsonParticipanteDocPkR = mapaItemRectifica.get("DES_CLAVE");// COD_TIPPARTIC
                                                                      // y
                                                                      // NUM_CORREDOC,
                                                                      // NUM_SECPARTIC

    // objetoJsonParticipanteDocR =
    // agregarRazonSocialParticipante(objetoJsonParticipanteDocPkR,
    // objetoJsonParticipanteDocR);

    JsonSerializer serializer = new JsonSerializer();
    Map<String, Object> mapPkParticipanteDocR = (Map<String, Object>) serializer
        .deserialize(objetoJsonParticipanteDocPkR);

    Map fbKeys = new HashMap();
    fbKeys.put("COD_TIPPARTIC", mapPkParticipanteDocR.get("COD_TIPPARTIC").toString());
    // si no envia el NUM_SECPARTIC se le pone cero
    fbKeys.put("NUM_SECPARTIC", ObjectUtils.toString(mapPkParticipanteDocR.get("NUM_SECPARTIC"), "0"));
    fbKeys.put("NUM_CORREDOC", mapPkParticipanteDocR.get("NUM_CORREDOC").toString());

    String codTipoRectificacion = (String) mapaItemRectifica.get("IND_RECTIFICA");

    String pk = mapPkParticipanteDocR.get("COD_TIPPARTIC").toString();

    String numSecCambio = mapaItemRectifica.get("NUM_SECCAMBIO") != null ? mapaItemRectifica
        .get("NUM_SECCAMBIO")
        .toString() : "";
    String desClave = mapaItemRectifica.get("DES_CLAVE") != null ? (String) mapaItemRectifica.get("DES_CLAVE") : "";
    String codTabla = mapaItemRectifica.get("COD_TABLA") != null ? (String) mapaItemRectifica.get("COD_TABLA") : "";

    Map<String, Object> mapaParticipanteDoc = null;
    if (!NUEVO_REGISTRO.equals(codTipoRectificacion))
    {
      mapaParticipanteDoc = Utilidades.obtenerElemento(lstParticipanteDocH, fbKeys);

      if (log.isDebugEnabled())
        log.debug("mapaParticipanteDoc::>>" + mapaParticipanteDoc);

      log.debug("objetoJsonParticipanteDocR:>>>" + objetoJsonParticipanteDocR);

      lstRectiParticipanteDoc = compararMapas(
          objetoJsonParticipanteDocR,
            mapaParticipanteDoc,
            "PARTICIPANTE_DOC",
            pk,
            codTipoRectificacion,
            numSecCambio,
            desClave,
            codTabla);
      log.debug("lstRectiParticipanteDoc:" + lstRectiParticipanteDoc);

    }
    else
    {

      lstRectiParticipanteDoc = compararMapas(objetoJsonParticipanteDocR, null,
          "PARTICIPANTE_DOC", pk, codTipoRectificacion, numSecCambio, desClave, codTabla);
      // agrego el listado al listado final
    }
    return lstRectiParticipanteDoc;
  }

  /**
   * verificamos que se este cambiando el numero de documento de identidad "RUC"
   * si es asi verificar que exista dicho ruc en la tabla RUC informix si existe
   * y no se envio la razon social agregar campo razon social.
   *
   * @param objKey
   *          string en formato json donde se encuentra el pk del participante
   * @param objDatos
   *          datos a ser modificados en la tabal participante
   * @return retorna los nuevos datos a ser rectificados
   */
  public String agregarRazonSocialParticipante(Object objKey, Object objDatos)
  {
    JsonSerializer serializer = new JsonSerializer();
    Map<String, Object> datos = new HashMap<String, Object>();
    if (StringUtils.isBlank((String) objDatos))
    {
      return (String) serializer.serialize(datos);
    }

    datos = (Map<String, Object>) serializer.deserialize(objDatos);
    Map rptaRuc = new HashMap();

    if (datos.get("NUM_DOCIDENT") != null)
    {
//      rptaRuc = pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl
//          .getInstance()
//          .getDdpDAO()
//          .findByPKDirecc((String) datos.get("NUM_DOCIDENT"), true);
    	rptaRuc = ddpDAOService.findByPKDirecc((String) datos.get("NUM_DOCIDENT"), true);
      if (rptaRuc != null && !rptaRuc.isEmpty())
      {
        datos.put("NOM_RAZONSOCIAL", rptaRuc.get("ddp_nombre") != null ? rptaRuc.get("ddp_nombre").toString() : " ");
        datos.put("DIR_PARTIC", rptaRuc.get("direccion_desc") != null ? rptaRuc.get("direccion_desc").toString() : " ");
        datos.put("COD_TIPDOC", "4");
        datos.put("DES_UBIGEOCIUDAD", rptaRuc.get("dist_desc") != null ? rptaRuc.get("dist_desc").toString() : " ");
      }
    }

    return (String) serializer.serialize(datos);

  }

  /**
   * Metodo que busca obtener un Json de la Clave de la tabla pero usando campos
   * descriptivos para ellos obtenemos la descripcion del campo DES_NEMONICO de
   * la tabla catcasillaformato.
   *
   * @param claveDes
   *          : Clave en Json que puede estar compuesto por varios campos
   * @param desTabla
   *          the des tabla
   * @return una cadena en Json con la nueva descripcion de la clave
   * @author rbegazo
   */
  private String generaClaveMostrar(String claveDes, String desTabla)
  {
	  //rtineo mejoras llamamos el metodo sobrecargado
	  return generaClaveMostrar(claveDes,desTabla, null);
	  //rtineo mejoras
  }
  
  //rtineo mejoras, sobrecargamos el metodo
  private String generaClaveMostrar(String claveDes, String desTabla, Map<String,Map<String, String>> mapDescripcion)
  {
    Map listClave = (Map) SojoUtil.fromJson(claveDes);
    Map<String, Object> mapClaveDes = new HashMap<String, Object>();
    Iterator iterClave = listClave.entrySet().iterator();

    while (iterClave.hasNext())
    {
      Map.Entry entry = (Map.Entry) iterClave.next();
      if (StringUtils.isBlank(ObjectUtils.toString(entry.getValue(), "")))
      {
        continue;
      }
      String clave = " ";
      //rtineo mejoras, llamamos al metodo sobrecargado
      Map<String, String> mapaDesc = new HashMap<String,String>();
      if(mapDescripcion != null){
    	  mapaDesc = buscarDescripcion(desTabla, entry.getKey().toString(),mapDescripcion);
      }else{
    	  mapaDesc = buscarDescripcion(desTabla, entry.getKey().toString());
      }
      //rtineo mejoras
      if (!CollectionUtils.isEmpty(mapaDesc))
      {
        clave = mapaDesc.get("DES_NEMONICO").toString();
        if (StringUtils.isBlank(clave))
        {
          continue;
        }
      }
      else
      {
        continue;
      }
      String data = entry.getValue().toString().trim();
      mapClaveDes.put(clave, data);
    }
    String res = SojoUtil.toJson(mapClaveDes);
    return res;
  }

  /**
   * Metodo que contruye la lista con los datos historico y rectificados de
   * forma vertical.
   *
   * @param objectR
   *          the object r
   * @param mapaH
   *          the mapa h
   * @param tabla
   *          the tabla
   * @param pk
   *          the pk
   * @param codTipoRectificacion
   *          the cod tipo rectificacion
   * @param numSecCambio
   *          the num sec cambio
   * @param desClave
   *          the des clave
   * @param codTabla
   *          the cod tabla
   * @return List<Map<String, Object>> lista con los datos reestructuados para
   *         su visualizacion
   */

  private List<Map<String, Object>> compararMapas(
      Object objectR,
      Map<String, Object> mapaH,
      String tabla,
      String pk,
      String codTipoRectificacion,
      String numSecCambio,
      String desClave,
      String codTabla)
  {
	  //rtineo mejoras llamamos al metodo sobrecargado
	  return compararMapas(objectR, mapaH, tabla, pk, codTipoRectificacion, numSecCambio, desClave, codTabla,null);
	  // fin mejoras
  }
  
  //rtineo mejoras sobrecargamos el metodo
  private List<Map<String, Object>> compararMapas(Object objectR, Map<String, Object> mapaH, String tabla, String pk, String codTipoRectificacion,
	      String numSecCambio, String desClave, String codTabla,Map<String,Map<String, String>> mapDescripcion)
	  {
    List<Map<String, Object>> listaRectificados = new ArrayList<Map<String, Object>>();

    JsonSerializer serializer = new JsonSerializer();

    String tablaTmp = Constantes.COD_TABLA_PARTICIPANTE_DOC.equals(codTabla) ? tabla + "_" + pk : tabla;

    //rtineo mejoras, obtenemos al metodo sobrecargado
    String strClaveMostrar = ""; //pendiente de evaluar si es null o vacio
    if(mapDescripcion != null){
    	strClaveMostrar = generaClaveMostrar(desClave, tabla, mapDescripcion);
    }else{
    	strClaveMostrar = generaClaveMostrar(desClave, tabla);
    }
    //fin mejoras

    // OBS_OBS
    if ((Constantes.COD_TABLA_OBSERVACION.equals(codTabla)) && ("03".equals(pk)))
    {
      tablaTmp = tabla + "_" + pk;
    }

    if (objectR != null && objectR.toString().trim().length() > 0 && !NUEVO_REGISTRO.equals(codTipoRectificacion))
    {

      Map<String, Object> mapR = (Map<String, Object>) serializer.deserialize(objectR);

      String toJson = SojoUtil.toJson(mapaH);
      Map<String, Object> mapH = (Map<String, Object>) serializer.deserialize(toJson);

      // listado resultado del proceso

      if (mapR != null && mapR.size() > 0 && mapH != null && mapH.size() > 0)
      {

    	  /**Inicio de ajustes para registros sin Historico - Nuevos PAS20155E220200006**/ 
    	  
    	  String rectificadoDataAsJson = desClave; 
          /**Fin de ajustes**/
        /*
         * Map1.entrySet() Todos los pares clave-valor (devuelve un conjunto de
         * objetos Map.Entry, cada uno delos cuales devuelve la clave y el valor
         * con los m�todos getKey() y getValue() respectivamente).
         */
        Iterator it1 = mapR.entrySet().iterator();
        while (it1.hasNext())
        {
          Map.Entry lvEntry = (Entry) it1.next();

          String pkCampo = (String) lvEntry.getKey(); // PkCampo del JSON

          Object campoValorR = mapR.get(pkCampo); // obtiene valor del dato
                                                  // rectificado
          Object campoValorH = mapH!=null?mapH.get(pkCampo):null; // obtiene valor del dato 
                                                  // actual de a BD

          if (Constantes.COD_TABLA_CONVENIO_SERIE.equals(codTabla)
              && (pkCampo.equals("COD_TIPCONVENIO") || pkCampo.equals("COD_TIPCONVENIO_DESC") || pkCampo.equals("COD_CONVENIO")))
          {
            tablaTmp = Constantes.COD_TABLA_CONVENIO_SERIE.equals(codTabla) ? tabla + "_"
                + mapaH.get("COD_TIPCONVENIO") : tabla;
          }

          if (Constantes.COD_TABLA_CAB_DECLARA.equals(codTabla))
              {
        	     if( pkCampo.equals("FEC_VENCREGULA")) continue;
                
              }
          //rtineo mejoras verificamos si estamos sobrecargando
          Map<String, String> mapaDesc = new HashMap<String,String>();
          if(mapDescripcion != null){
        	  mapaDesc = buscarDescripcion(tablaTmp, pkCampo,mapDescripcion);
          }else{
        	  //seguimos llamando al metodo pesado
        	  mapaDesc = buscarDescripcion(tablaTmp, pkCampo);
          }
          //fin mejoras

          String seccionDesc = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString()
              : "No registrado";
          String columnaDesc = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : pkCampo;
          // los datos rectificados null no se consideran del JSON
          // consultar CampoValor1 debe traer los valores rectificados
          log.debug("campo"+pkCampo);
          if (!(campoValorR == null || Utilidades.equalsByClass(campoValorR, campoValorH))
              && (buscarListaR2(listaRectificados, pkCampo) == false))
          {
            log.debug(".=====>ingreso....");
            Map<String, Object> mapRecti = new HashMap<String, Object>();
            mapRecti.put("PK", pk); // dato necesario mostrar JSP
            mapRecti.put("SECCION", seccionDesc); // dato necesario mostrar JSP
            mapRecti.put("CAMPO", pkCampo); // dato necesario para la grabacion
            mapRecti.put("CAMPO_DESC", columnaDesc);// dato necesario mostrar
                                                    // JSP
            mapRecti.put("VALORR", campoValorR == null ? "" : campoValorR); // dato
                                                                            // necesario
                                                                            // mostrar
                                                                            // JSP
            mapRecti.put("VALORH", campoValorH == null ? "" : campoValorH); // dato
                                                                            // necesario
                                                                            // mostrar
                                                                            // JSP
            //mol el orquestador lo debe gestionar
            //if(campoValorR!=null && campoValorH==null){//Se adiciona para q indique el ind correcto
            //	mapRecti.put("IND_RECTIFICA", TIPO_REGISTRO_NUEVO); 
            //}else{            
            mapRecti.put("IND_RECTIFICA", codTipoRectificacion); // dato
            //}                                                     // necesario
                                                                 // para la
                                                                 // grabacion
            mapRecti.put("IND_CHECK", "0"); // por defecto desmarcado
            mapRecti.put("NUM_SECCAMBIO", numSecCambio); // dato necesario para
                                                         // la grabacion
            mapRecti.put("DES_CLAVE", desClave); // dato necesario para la
                                                 // grabacion
            mapRecti.put("COD_TABLA", codTabla); // dato necesario para la
                                                 // grabacion
            mapRecti.put("VALOR2R",             	
            		codTipoRectificacion.equals(NUEVO_REGISTRO) ||  codTipoRectificacion.equals(ELIMINAR_REGISTRO)? rectificadoDataAsJson:campoValorR);
            		// dato necesario para la grabacion AJUSTES AREY SI ES R EL VALOR SINO LA PK
            // mapRecti.put("CAMPODESC",""); //dato necesario mostrar JSP
            //
            for (EnumRectifica enumRectifica : EnumRectifica.values())
            { // buscar PkCampo si se encuentra en la lista de
              // datos compuestos
              if (Constantes.COD_TABLA_PARTICIPANTE_DOC.equals(codTabla)
                  && (pkCampo + "_PTR").equalsIgnoreCase(enumRectifica.getCodCampo()))
              {
                setDatoComplejo(campoValorR, campoValorH, mapRecti,
                    enumRectifica);
                break;
              }
              else if (pkCampo.equalsIgnoreCase(enumRectifica.getCodCampo()))
              { // busca si la columna se encuentra registrado
                setDatoComplejo(campoValorR, campoValorH, mapRecti,
                    enumRectifica);
                break;
              }
              }
            // r2bz Convertimos la clave a descripcion a ser mostrada
            mapRecti.put("DES_CLAVENEM", strClaveMostrar);
            /*inico - Pase548*/
            mapRecti.put("DES_MINIMA", pk);//se pintar� desde json
            Map<String, Object> mapaCamposClave = (Map<String, Object>) serializer.deserialize(((String) strClaveMostrar));
            mapRecti.put("COD_MERCA",mapaCamposClave.get("codigoMercancia")!=null ? mapaCamposClave.get("codigoMercancia"):" ");//se pinta detalle desde json
           /*fin - Pase548*/
            mapRecti.put("NUM_SECSERIE_RECT",mapaH.get("NUM_SECSERIE_RECT")!=null ?mapaH.get("NUM_SECSERIE_RECT").toString():"");// p24 152 se pinta las series asociadas al documento

            listaRectificados.add(mapRecti);
          }
        }
      }// fin de if mapR,mapH
    }// fin de if objectR
    else
    { //Nuevos y Anulados PAS20155E220200006
      String campo = "";
      String campoValorH = "";
      String campoValorR = "";
      String campoABuscar = ""; //adicionado para busquedas PAS20155E220200006
      log.debug("ELSE>>>>");
/* se mueva mas abajo esta
      if ("A".equals(codTipoRectificacion))
      {
        // eliminamos los campos pk del HashMap actual
        Map mapActualData = new HashMap();
        String actualDataAsJson = desClave;
        if (mapaH != null)
        {
          mapActualData = new HashMap(mapaH);
          Map listClave = (Map) SojoUtil.fromJson(desClave);
          for (Object keyClave : listClave.keySet())
          {
            mapActualData.remove(keyClave);
          }

          actualDataAsJson = SojoUtil.toJson(mapActualData);
        }

        campoValorH = generaClaveMostrar(actualDataAsJson, tablaTmp);
        if (campoValorH.length() <= 2)
        {
          campoValorH = strClaveMostrar;
        }
      }
*/
      String rectificadoDataAsJson = desClave;
      String pkCampo = "";//PAS20155E220200006
      if (NUEVO_REGISTRO.equals(codTipoRectificacion))
      {
        campo = "NEW_RECORD";
        // eliminamos los campos pk del HashMap actual
        Map maprectificadoData = (Map) SojoUtil.fromJson(desClave);

        if (objectR != null && !StringUtils.isBlank(ObjectUtils.toString(objectR, "")))	   //PAS20155E220200006
        {
          maprectificadoData = (Map) SojoUtil.fromJson(objectR.toString());
          Map listClave = (Map) SojoUtil.fromJson(desClave);
                      /***PASE47 PINTAR TPI**PASE 81 SE HABILITA POR CONFLICTO EN RECTI*****/
		      if(tabla.equals(Constantes.COD_TABLA_CONVENIO_SERIE_DESC)){
		    		 maprectificadoData.remove("NUM_SECSERIE");
		    		 maprectificadoData.remove("NUM_CORREDOC");
		    		 maprectificadoData.remove("COD_TIPCONVENIO");
		      }else{
		      /***PASE47 PINTAR TPI*****/
          for (Object keyClave : listClave.keySet())
          {
            maprectificadoData.remove(keyClave);
          }
		     // }//adicionado pase47

          rectificadoDataAsJson = SojoUtil.toJson(maprectificadoData);
        }
		//rtineo mejoras, llamamos al metodo sobrecargado
		if(mapDescripcion != null){
			campoValorR = generaClaveMostrar(rectificadoDataAsJson, tablaTmp, mapDescripcion);
		}else{
        campoValorR = generaClaveMostrar(rectificadoDataAsJson, tablaTmp);
		}
        if (campoValorR.length() <= 2)
        {
//	         campoValorR = strClaveMostrar;   PAS20155E220200006
 /**Inicio de cambios de recti AREY**/
	        	campoValorR = obtenerCampoFormateado(rectificadoDataAsJson, tablaTmp);
	        }else{
	        	Map listValorEval = (Map) SojoUtil.fromJson(rectificadoDataAsJson);
	            Map maprecti = (Map) SojoUtil.fromJson(desClave);
	        	if(Constantes.COD_TABLA_FORMB_ITEM_DESCRI.equals(codTabla)
	        		&& maprecti.get("COD_TIPDESC")!=null  
	        		&& listValorEval.get("COD_TIPVALOR")!=null 
	        		&& maprecti.get("COD_TIPDESC").toString().length()>4 
	        		&& listValorEval.get("COD_TIPVALOR").toString()!=" "){
	        		
	        		campoValorR =  maprectificadoData.get("DES_DESCRIPCION").toString();
	        		campoABuscar = "DES_DESCRIPCION";
	        		
        }
	        	else if(Constantes.COD_TABLA_CONVENIO_SERIE.equals(codTabla) && maprecti.get("COD_TIPCONVENIO")!=null){
	        		campoValorR =  maprectificadoData.get("COD_CONVENIO").toString();
	        		campoABuscar = "COD_CONVENIO";
      }
	        	else{
	        		campoValorR = obtenerCampoFormateado(rectificadoDataAsJson, tablaTmp);
        }
      }
      }

        else{
        	campoValorR = obtenerCampoFormateado(rectificadoDataAsJson, tablaTmp);//para los nuevos que no tienen valorR y valorH
        }
/**Fin de cambios de recti AREY**/
      }
      //aqui esta la parte del codigo de arriba con un cambio adicional
      if ("A".equals(codTipoRectificacion))
      {
        // eliminamos los campos pk del HashMap actual
        Map mapActualData = new HashMap();
        String actualDataAsJson = desClave;
        if (mapaH != null)
        {
          mapActualData = new HashMap(mapaH);
//          Map listClave = (Map) SojoUtil.fromJson(desClave);
//          for (Object keyClave : listClave.keySet())
//          {
//            mapActualData.remove(keyClave);
//          }
          /***inicio de cambios pase PAS20145E220000164 actualizado***/
		      if(tabla.equals(Constantes.COD_TABLA_DOCUPRECE_DUA_DESC)){
		    	  mapActualData.remove("URL");
		    	  mapActualData.remove("COD_REGIMENPRE");//ya no se muestra en el detalle porque ya esta en la desc
		      } 
		      if(mapActualData.containsKey("FEC_REGIS")){
	        	  mapActualData.remove("FEC_REGIS"); 
	          }
		      if(mapActualData.containsKey("COD_USUREGIS")){
	        	  mapActualData.remove("COD_USUREGIS"); 
	          }
		      if(mapActualData.containsKey("FEC_MODIF")){
	        	  mapActualData.remove("FEC_MODIF"); 
	          } 
		      if(mapActualData.containsKey("COD_USUMODIF")){
	        	  mapActualData.remove("COD_USUMODIF"); 
	          }
		  /**fin cambios**/
          actualDataAsJson = SojoUtil.toJson(mapActualData);
        }

         //rtineo mejoras, llamamos al metodo sobrecargado
        if(mapDescripcion != null){
        	campoValorH = generaClaveMostrar(actualDataAsJson, tablaTmp, mapDescripcion);
        }else{
        campoValorH = generaClaveMostrar(actualDataAsJson, tablaTmp);
        }
        //fin mejoras
        if (campoValorH.length() <= 2)
        {
//          campoValorH = strClaveMostrar; PAS20155E220200006
        /**Inicio de cambios de recti AREY**/
        	campoValorH = obtenerCampoFormateado(actualDataAsJson, tablaTmp);
        }else{
        	campoValorH = obtenerCampoFormateado(actualDataAsJson, tablaTmp);
        }
        /**Fin de cambios de recti AREY**/

        // para que no se muestra valpreciovta
        //String valorH =""; 
       // valorH = valorH.concat("{").concat("''''").concat("valpreciovta").concat("''''").concat(":").concat("0").concat("}");
       // if(tablaTmp.equals("DET_ADI_IMPOCONSU") && campoValorH.length() == 20 && campoValorR.equals("") && campoValorH.contains("valpreciovta") && campoValorH.contains("0") ){
       // 	 campoValorH = "";
        //  }
      }
      // P46-INSI
      //rtineo mejoras, llamamos al metodo sobrecargado
      // se pone el campo a vacio para obtener la descripcion por default
      Map<String, String> mapaDesc = new HashMap<String,String>();
      
      //PAS20171U220200005 Inicio se indica directamente para que traiga la seccion Datos de Indicadores y no confunda al usuario
      if(tablaTmp!=null && tablaTmp.equals("CAB_ADI_IMPOCONSU") && rectificadoDataAsJson!=null && rectificadoDataAsJson.contains("NUM_TOTALENVIOS")){
    	  campoABuscar = "NUM_TOTALENVIOS";
      }
      //PAS20171U220200005 Fin
      
      
      if(mapDescripcion != null){
    	  mapaDesc = buscarDescripcion(tablaTmp, campoABuscar, mapDescripcion);
      }else{
    	  mapaDesc = buscarDescripcion(tablaTmp, campoABuscar);
      }
      //fin mejoras
      String seccionDesc = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString()
          : "No registrado";
      String columnaDesc = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : campo;

      Map<String, Object> mapRecti = new HashMap<String, Object>();
      mapRecti.put("PK", pk);
      mapRecti.put("SECCION", seccionDesc);
      mapRecti.put("CAMPO", campo);
      mapRecti.put("CAMPO_DESC", columnaDesc);
      mapRecti.put("VALORR", campoValorR);
      mapRecti.put("VALORH", campoValorH);
      mapRecti.put("IND_RECTIFICA", codTipoRectificacion);
      mapRecti.put("IND_CHECK", "0");
      mapRecti.put("NUM_SECCAMBIO", numSecCambio);
      mapRecti.put("DES_CLAVE", desClave);
      mapRecti.put("COD_TABLA", codTabla);
      mapRecti.put("VALOR2R", rectificadoDataAsJson);
      // Convertimos la clave a descripcion a ser mostrada para anuladas
      mapRecti.put("DES_CLAVENEM", strClaveMostrar);

      if(Constantes.COD_TABLA_FORMB_ITEM_DESCRI.equals(codTabla) && NUEVO_REGISTRO.equals(codTipoRectificacion)){//PAS20155E220200006
    	  mapRecti.put("DES_MINIMA", pk);//se pintar� desde json
    	  Map mapdata = (Map) SojoUtil.fromJson(desClave);
          mapRecti.put("COD_MERCA",mapdata.get("COD_MERCANCIA")!=null ?mapdata.get("COD_MERCANCIA"):" ");//se pinta detalle desde json PAS20155E220200006
      }
      
      listaRectificados.add(mapRecti);
//    }//P46-INSI
    }
    return listaRectificados;
  }

  /**Adicionado por arey PAS20155E220200006**/
  public String obtenerCampoFormateado(String dataAsJson, String tablaTmp){
	String campoValorRpta="";
	Map listValores = (Map) SojoUtil.fromJson(dataAsJson);
  	Iterator itR = listValores.entrySet().iterator();
  	StringBuffer relacionCampos = new StringBuffer();
  	while (itR.hasNext())
       {
      	Map.Entry lvEntryN = (Entry) itR.next();
      	String pkCampo = "";
      	pkCampo =   lvEntryN.getKey().toString();
      	if(!pkCampo.equals("NUM_CORREDOC") && !pkCampo.equals("IND_DEL")){//no pintar num_corredoc ni ind_del esta de mas
	      	String campoValorRecti ="";
	      	campoValorRecti= listValores.get(pkCampo)!=null?listValores.get(pkCampo).toString().trim(): "";	
	      	if(!campoValorRecti.equals("")){
	          Map<String, String> mapaDesc = buscarDescripcion(tablaTmp, pkCampo);
	          String columnaDesc = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : pkCampo;
	          relacionCampos.append(" "+columnaDesc +": " + campoValorRecti);
	          relacionCampos.append(", ");
	      	}
      	}
      }
  	//campoValorRpta = relacionCampos!=null?relacionCampos.toString().substring(0,relacionCampos.length()-2):""; 
  	campoValorRpta = (relacionCampos!=null && relacionCampos.length()>2)?relacionCampos.toString().substring(0,relacionCampos.length()-2):""; //cambio de anita rey
  	return campoValorRpta;
	  
  }
  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDatosAnuladosOAdicionados(String numCorreDoc, String codTabla)
    throws ServiceException
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();

    Map<String, Object> params = new HashMap<String, Object>();
    params.put("numcorredoc", numCorreDoc);

    // obtener Rectificaciones automaticas

    List<Map<String, Object>> lstResul01 = obtenerRegistrosAnuladosYAgregados(numCorreDoc, codTabla, PROCESO_RECTI_AUTO);
    List<Map<String, Object>> lstResul02 = obtenerRegistrosAnuladosYAgregados(
        numCorreDoc,
          codTabla,
          PROCESO_RECTI_ELECTRONICA);
    List<Map<String, Object>> lstResul03 = obtenerRegistrosAnuladosYAgregados(
        numCorreDoc,
          codTabla,
          PROCESO_REGULARIZACION);
    List<Map<String, Object>> lstResul04 = obtenerRegistrosAnuladosYAgregados(
        numCorreDoc,
          codTabla,
          PROCESO_OTRAS_DILIGENCIA);

    lstRspta.addAll(lstResul01);
    lstRspta.addAll(lstResul02);
    lstRspta.addAll(lstResul03);
    lstRspta.addAll(lstResul04);

    return lstRspta;
  }

  /**
   * Obtener registros anulados y agregados.
   *
   * @param numCorreDocDua
   *          the num corre doc dua
   * @param codTabla
   *          the cod tabla
   * @param proceso
   *          the proceso
   * @return the list
   */
  private List<Map<String, Object>> obtenerRegistrosAnuladosYAgregados(
      String numCorreDocDua,
      String codTabla,
      String proceso)
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();

    List<Map<String, Object>> lstADDyDELFromDetSolRecti = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> lstADDyDELFromDetOfiRecti = new ArrayList<Map<String, Object>>();

    String tipoDiligencia = "";
    Map<String, Object> params = new HashMap<String, Object>();
    List<String> lstTransacciones = new ArrayList<String>();
    List<String> lstEstados = new ArrayList<String>();
    if (PROCESO_RECTI_AUTO.equals(proceso))
    {
      lstTransacciones.add("03");
      lstTransacciones.add("1003");
      lstTransacciones.add("2003");
      lstTransacciones.add("2103");
      lstTransacciones.add("7003");
      // catalogo 374
      params.put("COD_TIPSOL", "01");
      // aceptado automaticamente cod_catalogo='363'
      lstEstados.add("01");

    }
    else if (PROCESO_RECTI_ELECTRONICA.equals(proceso))
    {
      lstTransacciones.add("03");
      lstTransacciones.add("1003");
      lstTransacciones.add("2003");
      lstTransacciones.add("2103");
      lstTransacciones.add("7003");
      // catalogo 374
      params.put("COD_TIPSOL", "01");
      // aceptado automaticamente cod_catalogo='363'
      lstEstados.add("05");
      lstEstados.add("06");
      // cod_catalogo='356'
      tipoDiligencia = "06";
    }
    else if (PROCESO_REGULARIZACION.equals(proceso))
    {
      // 04 para la regularizacion automatica
      lstTransacciones.add("04");
      lstTransacciones.add("1004");
      lstTransacciones.add("2004");
      lstTransacciones.add("2104");
      lstTransacciones.add("7004");
      // 04 para la regularizacion por modulo de diligencia
      lstTransacciones.add("05");
      lstTransacciones.add("1005");
      lstTransacciones.add("2005");
      lstTransacciones.add("2105");
      lstTransacciones.add("7005");
      // aceptado automaticamente cod_catalogo='363'
      lstEstados.add("02"); // ACEPTADO AUTOMATICAMENTE
      lstEstados.add("04");
      params.put("COD_TIPSOL", "11");
      // cod_catalogo='356'
      tipoDiligencia = "07";
    }

    params.put("NUM_CORREDOC", numCorreDocDua);
    params.put("listaCodigoTransaccion", lstTransacciones);
    params.put("listaEstados", lstEstados); // catalogo 329 o 363

    // VERIFICAR LA CAB_SOLRECTI
    if (PROCESO_RECTI_AUTO.equals(proceso) ||
        PROCESO_RECTI_ELECTRONICA.equals(proceso) ||
        PROCESO_REGULARIZACION.equals(proceso))
    {

      lstADDyDELFromDetSolRecti = obtenerRegistrosAnuladosYAgregadosDetSolRecti(codTabla, proceso, params);
      if (PROCESO_RECTI_AUTO.equals(proceso))
      {
        lstRspta.addAll(lstADDyDELFromDetSolRecti);
      }
    }

    // confirmamos si fueron grabados en tabla det_ofirecti
    if ((PROCESO_RECTI_ELECTRONICA.equals(proceso) && !CollectionUtils.isEmpty(lstADDyDELFromDetSolRecti)) ||
    		PROCESO_REGULARIZACION.equals(proceso)) //para que considere transmision + cambios de dilig PASE399 bug 20457
    {

      Map<String, Object> params2 = new HashMap<String, Object>();
      params2.put("numcorredoc", numCorreDocDua);
      params2.put("codtabla", codTabla);
      List<String> lstTipoDiligencia = new ArrayList<String>();
      lstTipoDiligencia.add(tipoDiligencia);
      params2.put("tipoDiligencia", lstTipoDiligencia);

      lstADDyDELFromDetOfiRecti = obtenerRegistrosAnuladosYAgregadosDetOfiRecti(codTabla, params2);

      lstRspta.addAll(lstADDyDELFromDetOfiRecti);

    }

    if (PROCESO_OTRAS_DILIGENCIA.equals(proceso))
    {

      Map<String, Object> params2 = new HashMap<String, Object>();
      params2.put("numcorredoc", numCorreDocDua);
      params2.put("codtabla", codTabla);
      List<String> lstTipoDiligencia = new ArrayList<String>();
      lstTipoDiligencia.add("02");
      lstTipoDiligencia.add("03");
      lstTipoDiligencia.add("05");
      lstTipoDiligencia.add("10");
      params2.put("tipoDiligencia", lstTipoDiligencia);

      lstADDyDELFromDetOfiRecti = obtenerRegistrosAnuladosYAgregadosDetOfiRecti(codTabla, params2);

      lstRspta.addAll(lstADDyDELFromDetOfiRecti);
    }

    return lstRspta;
  }

  /**
   * Obtener registros anulados y agregados det ofi recti.
   *
   * @param codTabla
   *          the cod tabla
   * @param params
   *          the params
   * @return the list
   */
  private List<Map<String, Object>> obtenerRegistrosAnuladosYAgregadosDetOfiRecti(
    String codTabla,
    Map<String, Object> params)
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
    List<Map<String, Object>> lstdatosRectificados = this.rectiOficioDAO.findRectiOficioByParams(params);

    JsonSerializer serializer = new JsonSerializer();

    for (Map<String, Object> mapaDatosJSONPorTabla : lstdatosRectificados)
    {
      if (codTabla.equals(Constantes.COD_TABLA_DET_DECLARA))
      {

        Map<String, Object> mapaDesClave = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla
            .get("desclave")));

        Map<String, Object> mapaDesData = new HashMap<String, Object>();
        Map<String, Object> mapaDesDataAnt = new HashMap<String, Object>();
        StringBuilder sbDesData = new StringBuilder();
        StringBuilder sbDesDataAnt = new StringBuilder();
        if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata1")))
        {
          sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata1"));
        }
        if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata2")))
        {
          sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata2"));
        }
        if (!SunatStringUtils.isEmpty(sbDesData.toString()))
        {
          mapaDesData = (Map<String, Object>) serializer.deserialize(sbDesData.toString());
        }

        if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desantdata1")))
        {
          sbDesDataAnt.append((String) mapaDatosJSONPorTabla.get("desantdata1"));
        }
        if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desantdata2")))
        {
          sbDesDataAnt.append((String) mapaDatosJSONPorTabla.get("desantdata2"));
        }
        if (!SunatStringUtils.isEmpty(sbDesDataAnt.toString().trim()))
        {
          mapaDesDataAnt = (Map<String, Object>) serializer.deserialize(sbDesDataAnt.toString());
        }

        String estado = obtenerEstado(mapaDesData, mapaDesDataAnt);
        // solo los que tengan estado adicionado o eliminado se agregar al
        // resultado
        if (!CollectionUtils.isEmpty(mapaDesClave) && StringUtils.isNotBlank(estado))
        {

          String codDiligencia = (String) mapaDatosJSONPorTabla.get("codtipdiligencia");
          String codDiligenciaDesc = catalogoAyudaService.getDescripcionDataCatalogo("356", codDiligencia);
          String fechaDilig = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(mapaDatosJSONPorTabla.get("fecregis"));
          String codUsuRegis = (String) mapaDatosJSONPorTabla.get("codusuregis");
          // Colocando la descripcion del usuario
          FiltroCatEmpleado filtro = new FiltroCatEmpleado();
          filtro.setCodPers(codUsuRegis);
          Map<String, CatEmpleado> mapCatEmpleado = solicitudService.buscarMapCatEmpleado(filtro);
          CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(codUsuRegis);

          Map<String, Object> mapElem = new HashMap<String, Object>();
          mapElem.put("PK", mapaDesClave.get("NUM_SECSERIE").toString());
          mapElem.put("ESTADO", estado);
          mapElem.put("PROCESO", codDiligencia.concat("-").concat(codDiligenciaDesc));
          mapElem.put("FECHAHORA", fechaDilig);

          StringBuilder sbUsuario = new StringBuilder();
          if (catEmpleadoTemp != null)
          {
            sbUsuario.append(catEmpleadoTemp.getApPate().trim());
            sbUsuario.append(" ");
            sbUsuario.append(catEmpleadoTemp.getApMate().trim());
            sbUsuario.append(" ");
            sbUsuario.append(catEmpleadoTemp.getNombres().trim());
          }
          else if (catEmpleadoTemp == null && StringUtils.isNotBlank(codUsuRegis))
          {
            sbUsuario.append(codUsuRegis);
          }
          else
          {
            sbUsuario.append("---");
          }

          mapElem.put("USUARIO", sbUsuario.toString());
          lstRspta.add(mapElem);
        }
      }
    }

    return lstRspta;
  }

  /**
   * Obtener estado.
   *
   * @param mapaDesData
   *          the mapa des data
   * @param mapaDesDataAnt
   *          the mapa des data ant
   * @return the string
   */
  private String obtenerEstado(Map<String, Object> mapaDesData, Map<String, Object> mapaDesDataAnt)
  {
    String rspta = "";
    // verifica si fue eliminado
    
    if (!CollectionUtils.isEmpty(mapaDesData) && CollectionUtils.isEmpty(mapaDesDataAnt))
    {
      rspta = "Adicionado";
    }
    
    if(mapaDesData.containsKey("IND_DEL") && mapaDesDataAnt.containsKey("IND_DEL")){
  	  String indDel = (String) mapaDesData.get("IND_DEL");
  	    String indDelAnt = (String) mapaDesDataAnt.get("IND_DEL");
    if ("1".equals(indDel) && "0".equals(indDelAnt))
    {
      rspta = "Eliminado";
    }
    }
  
    return rspta;
  }

  /**
   * Obtener registros anulados y agregados det sol recti.
   *
   * @param codTabla
   *          the cod tabla
   * @param proceso
   *          the proceso
   * @param params
   *          the params
   * @return the list
   */
  private List<Map<String, Object>> obtenerRegistrosAnuladosYAgregadosDetSolRecti(
      String codTabla,
      String proceso,
    Map<String, Object> params)
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();

    List<Map<String, Object>> lstRegistros = cabSolrectiDAO.getLstRegistrosAnuladosYAgregados(params);
    if (!CollectionUtils.isEmpty(lstRegistros))
    {
      // buscamos en la det_solrecti
      params.put("COD_TABLA", codTabla);
      // chancamos el atributo NUM_CORREDOC que inicialmente era de la
      // declaracion por la de la solicitud
      params.put("NUM_CORREDOC", lstRegistros.get(0).get("NUM_CORREDOC"));

      List<Map<String, Object>> lstdatosRectificados = detSolRectiDAO.findDatosRectificadosByMap(params);

      JsonSerializer serializer = new JsonSerializer();

      for (Map<String, Object> mapaDatosJSONPorTabla : lstdatosRectificados)
      {
        if (codTabla.equals(Constantes.COD_TABLA_DET_DECLARA))
        {

          Map<String, Object> mapaDesClave = (Map<String, Object>) serializer
              .deserialize(((String) mapaDatosJSONPorTabla.get("DES_CLAVE")));

          if (!CollectionUtils.isEmpty(mapaDesClave))
          {
            String fechaDilig = "";
            try
            {
              fechaDilig = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(mapaDatosJSONPorTabla.get("FEC_REGIS"));
            }
            catch (Exception e)
            {
              fechaDilig = "...";
              log.info("ERROR-FEC_REGIS:" + mapaDatosJSONPorTabla.get("FEC_REGIS"), e);
            }

            Map<String, Object> mapElem = new HashMap<String, Object>();
            mapElem.put("PK", mapaDesClave.get("NUM_SECSERIE").toString());
            mapElem.put("ESTADO", NUEVO_REGISTRO.equals(mapaDatosJSONPorTabla.get("IND_RECTIFICA")) ? "Adicionado"
                : "Eliminado");
            mapElem.put("PROCESO", proceso);
            mapElem.put("FECHAHORA", fechaDilig);
            mapElem.put("USUARIO", "PROCESO-AUTOMATICO");
            lstRspta.add(mapElem);
          }
        }
      }
    }

    return lstRspta;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionService
   * #rectificacionTieneResultado(java.lang.String, java.lang.String)
   */
  public boolean rectificacionTieneResultado(String numCorreDocDua, String tipoSolicitud)
  {
    boolean tieneResultado = false;

    String proceso = "";
    List<String> lstTransacciones = new ArrayList<String>();
    List<String> lstEstados = new ArrayList<String>();

    Map<String, Object> params = new HashMap<String, Object>();

    if ("02".equals(tipoSolicitud))
    {
      proceso = PROCESO_RECTI_ELECTRONICA;
    }
    else if ("03".equals(tipoSolicitud))
    {
      proceso = PROCESO_REGULARIZACION;
    }

    if (PROCESO_RECTI_ELECTRONICA.equals(proceso))
    {
      lstTransacciones.add("03");
      lstTransacciones.add("1003");
      lstTransacciones.add("2003");
      lstTransacciones.add("2103");
      lstTransacciones.add("7003");
      // catalogo 374
      params.put("COD_TIPSOL", "01");
      // aceptado automaticamente cod_catalogo='363'
      lstEstados.add("01"); // automotico
      // lstEstados.add("05");
      // lstEstados.add("06");
      // cod_catalogo='356'

    }
    else if (PROCESO_REGULARIZACION.equals(proceso))
    {
      lstTransacciones.add("05");
      lstTransacciones.add("1005");
      lstTransacciones.add("2005");
      lstTransacciones.add("2105");
      lstTransacciones.add("7005");
      // se agrega regularizacion de anticipados transaccion 04
      lstTransacciones.add("04");
      lstTransacciones.add("1004");
      lstTransacciones.add("2004");
      lstTransacciones.add("2104");
      lstTransacciones.add("7004");
      // aceptado automaticamente cod_catalogo='363'
      lstEstados.add("02"); // ACEPTADO AUTOMATICAMENTE
      // lstEstados.add("04");
      params.put("COD_TIPSOL", "11");
      // cod_catalogo='356'
      // tipoDiligencia= "07";
    }

    params.put("NUM_CORREDOC", numCorreDocDua);
    params.put("listaCodigoTransaccion", lstTransacciones);
    params.put("listaEstados", lstEstados); // catalogo 329 o 363

    List<Map<String, Object>> lstRegistros = cabSolrectiDAO.getLstRegistrosAnuladosYAgregados(params);
    if (!CollectionUtils.isEmpty(lstRegistros))
    {
      tieneResultado = true;
    }
    return tieneResultado;
  }




  /**
   * Permite determinar si un registrao fue eliminado antes.
   *
   * @param mapaR
   * @param mapaH
   * @return
   */
  private boolean esEliminado(Map<String, Object> mapaR, Map<String, Object> mapaH) {
      boolean bandera = false;
      if (CollectionUtils.isEmpty(mapaH) || CollectionUtils.isEmpty(mapaR) || (!CollectionUtils.isEmpty(mapaR) && mapaR.containsKey("IND_DEL") && "0".equals(mapaR.get("IND_DEL").toString()))) {
          bandera = false;
      } else if (!CollectionUtils.isEmpty(mapaH) && !CollectionUtils.isEmpty(mapaR) && mapaR.containsKey("IND_DEL") && "1".equals(mapaR.get("IND_DEL").toString())) {
          bandera = true;
      }
      return bandera;
  }


  private boolean esEliminadoEnOtroProceso(Map<String, Object> mapaR, Map<String, Object> mapaH) {
    boolean bandera = false;
    if (!CollectionUtils.isEmpty(mapaH) && mapaH.containsKey("IND_DEL") && "1".equals(mapaH.get("IND_DEL").toString()))
    {
        bandera = true;
    }
    return bandera;
}

  /**
   * {@inheritDoc}
   */
  public List<DatoModificadoBean> obtenerDatosModificadosPorElUsuario(Map<String, Object> mapTablaNew,
                                                                       Map<String, Object> mapTablaOld,
                                                                       String nomTabla,
                                                                       Map<String, Object> mapKey) {

      
	  //se obtiene antes de que se filtre
      String SerieBase = mapTablaNew.get("SERIE_BASE")!=null?mapTablaNew.get("SERIE_BASE").toString():"";

      mapTablaNew = soporteComparadorService.validarMapEntidad(mapTablaNew,nomTabla);
      mapTablaOld = soporteComparadorService.validarMapEntidad(mapTablaOld,nomTabla);

      String nombreCampo = "";
      Object datoNuevo =  "";
      Object datoAntiguo =  "";
      String identificadorCampo =  SojoUtil.toJson(mapKey);
      String descripcionIdentificadorCampo = generaClaveMostrar2(mapKey,nomTabla);
      String descripcionSecccion    = "";
      String descripcionNombreCampo ="";
      DatoModificadoBean datoModificadoBean;
      List<DatoModificadoBean> lstCambio = new ArrayList<DatoModificadoBean>();


      if (!CollectionUtils.isEmpty(mapTablaNew)) {
          Iterator it = mapTablaNew.entrySet().iterator();
          boolean existeEliminado = esEliminado(mapTablaNew, mapTablaOld);
          if (!CollectionUtils.isEmpty(mapTablaOld) && !existeEliminado)
          {
              while (it.hasNext()) {
                  Map.Entry lvEntry = (Entry) it.next();

                  nombreCampo = lvEntry.getKey().toString();

                  Object valorR = lvEntry.getValue();
                  Object valorH = mapTablaOld.get(nombreCampo) == null ? "" : mapTablaOld.get(nombreCampo);
                  if (lvEntry.getValue() instanceof List
                      || lvEntry.getValue() instanceof Map
                      || esUnCampoQueNoSeDebeMostrarAlUsurio(nomTabla,nombreCampo,valorR,valorH))
                  {
                    continue;
                  }

                  Map<String, String> mapaDesc = buscarDescripcion(nomTabla, lvEntry.getKey().toString());
                  
                  //P34 AFMA

                 if("PARTICIPANTE_DOC".equals(nomTabla)){
                   String nomTablaTmp = mapTablaNew.get("COD_TIPPARTIC")!=null?nomTabla+"_"+mapTablaNew.get("COD_TIPPARTIC").toString():nomTabla;
                   mapaDesc = buscarDescripcion(nomTablaTmp, lvEntry.getKey().toString());
                 }

                 

                  descripcionSecccion = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString() : "---";
                  descripcionNombreCampo = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : lvEntry.getKey().toString();


                  if (!(valorR == null || Utilidades.equalsByClass(valorR, valorH))) {


                    if("PARTICIPANTE_DOC".equals(nomTabla) && "COD_TIPDOC".equals(nombreCampo))
                    {
                      datoAntiguo = getCodigoDescripcionDataCatalogo("COD_TIPDOC_PARTICIPANTE", valorH);
                      datoNuevo   = getCodigoDescripcionDataCatalogo("COD_TIPDOC_PARTICIPANTE", valorR);
                    }
                    else
                    {
                      datoAntiguo = getCodigoDescripcionDataCatalogo(nombreCampo, valorH);
                      datoNuevo   = getCodigoDescripcionDataCatalogo(nombreCampo, valorR);
                    }

                    datoAntiguo = formatoFecha(nombreCampo, datoAntiguo);
                    datoNuevo   = formatoFecha(nombreCampo, datoNuevo);

                    datoModificadoBean = new DatoModificadoBean();

                    /* P34 AFMA
                    String tipoParticipante = mapTablaNew.get("COD_TIPPARTIC")!=null?mapTablaNew.get("COD_TIPPARTIC").toString():"";
                    if("11".equals(tipoParticipante) && "NUM_DOCIDENT".equals(nombreCampo)){
                    	 datoModificadoBean.setNombreCampo(nombreCampo);
                         datoModificadoBean.setDatoNuevo(datoNuevo.toString());
                         datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
                         datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
                         datoModificadoBean.setDescripcionNombreCampo("DOCUMENTO IDENTIDAD");
                         datoModificadoBean.setDescripcionSecccion("TRANSPORTISTA");
                         datoModificadoBean.setIdentificadorCampo(identificadorCampo);
                    	
                    }else{*/
                    datoModificadoBean.setNombreCampo(nombreCampo);
                    datoModificadoBean.setDatoNuevo(datoNuevo.toString());
                    datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
                    datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
                    datoModificadoBean.setDescripcionNombreCampo(descripcionNombreCampo);
                    datoModificadoBean.setDescripcionSecccion(descripcionSecccion);
                    datoModificadoBean.setIdentificadorCampo(identificadorCampo);
                    //}
                    lstCambio.add(datoModificadoBean);
                  }
              }
          }
          else
          {

            if("DET_DECLARA".equals(nomTabla) )
            {

              Map<String, Object> serieBasePk = new HashMap();
              serieBasePk.put("NUM_CORREDOC", mapTablaNew.get("NUM_CORREDOC"));
              serieBasePk.put("NUM_SECSERIE", SerieBase);

              List<Map<String, Object>> lst= serieService.select(serieBasePk);
              if (!CollectionUtils.isEmpty(lst))
              {
                mapTablaOld = soporteComparadorService.validarMapEntidad((HashMap)lst.get(0),nomTabla);
              }
            }

            //Inicio: RIN14 - FVC
            //amancilla se quita no debio de poner aqui el filtro boolean indDocAuto = ("DOCAUT_ASOCIADO".equals(nomTabla) || "DET_AUTORIZACION".equals(nomTabla)) ? true : false;
            //Fin: RIN14 - FVC
            
            existeEliminado = esEliminadoEnOtroProceso(mapTablaNew, mapTablaOld);
            //es nuevo PERO SE QUITA LOS ELIMINADOS EN OTROS PROCESOS
            if (!existeEliminado /* amancilla || indDocAuto*/)
            {
              for (Entry<String, Object> entradaActual : mapTablaNew.entrySet())
              {

                nombreCampo = entradaActual.getKey();
                Object valorR = entradaActual.getValue();
                Object valorH = mapTablaOld!=null && mapTablaOld.get(nombreCampo) != null ?mapTablaOld.get(nombreCampo):"";
                
                String tipoComparacion =  esEliminado(mapTablaNew, mapTablaOld)?TIPO_REGISTRO_ELIMINADO:TIPO_REGISTRO_NUEVO;
                
                if (esUnCampoQueNoSeDebeMostrarAlUsurio(nomTabla,nombreCampo,valorR,valorH,tipoComparacion) /* amancilla && !indDocAuto*/)
                {
                  continue;
                }

                  //amancilla
                  //identificadorCampo = obtenerIdentificador(nomTabla,mapTablaNew,tipoComparacion,mapKey);
                  
                   descripcionIdentificadorCampo = generaClaveMostrar3(mapKey,nomTabla,mapTablaNew,tipoComparacion);
                  identificadorCampo = SojoUtil.toJson(mapKey);

                  Map<String, String> mapaDesc = buscarDescripcion(nomTabla,nombreCampo);
                  
                  /*P28-PAS20155E410000032-[jlunah]*/
                  if(nomTabla.equalsIgnoreCase("CONVENIO_SERIE") || nomTabla.equalsIgnoreCase("DOCUPRECE_DUA")){
                	  if(descripcionSecccion.equals("")){
                		  descripcionSecccion    = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString() : "---";
                	  }
                  }else{
                  descripcionSecccion    = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString() : "---";
                  }
                  /*fin-P28-PAS20155E410000032-[jlunah]*/
                  descripcionNombreCampo = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : nombreCampo;
                  
                  //Inicio: RIN14 - FVC
                  //amancilla no debio de poner esto aqui descripcionNombreCampo = (nombreCampo.equals("IND_DEL")&& indDocAuto) ? "Eliminar Documento" : descripcionNombreCampo;
                  //Fin: RIN14 - FVC 
                  //P28-PAS20155E410000032-INSI - Inicio
                  if(nomTabla.equalsIgnoreCase("CONVENIO_SERIE") && nombreCampo.equalsIgnoreCase("IND_DEL")){
                	  continue;
                  }
                  //P28-PAS20155E410000032-INSI - Fin
                //PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION DE OFICIO VERIFICAR PORQUE PARA ESTE CASO NO FUNCIONA ESTO
                  if(nomTabla.equalsIgnoreCase("CONVENIO_SERIE") && nombreCampo.equalsIgnoreCase("COD_CONVENIO")){
                	
                      if (valorR != null  )
                      {
                        datoNuevo   = getCodigoDescripcionDataCatalogo(nombreCampo, valorR);
                        datoAntiguo = getCodigoDescripcionDataCatalogo(nombreCampo, valorH);

                        datoNuevo   = formatoFecha(nombreCampo, datoNuevo);
                        datoAntiguo = formatoFecha(nombreCampo, datoAntiguo);

                        
                        //if(!descripcionNombreCampo.trim().isEmpty() ){//&& !descripcionSecccion.trim().equalsIgnoreCase("---")){//P28-PAS20155E410000032-INSI
                        datoModificadoBean = new DatoModificadoBean();

                        datoModificadoBean.setNombreCampo(nombreCampo);
                            /*INICIO-P34 PAS20165E220200126 AFMA*/
                        datoModificadoBean.setDatoNuevo(!TIPO_REGISTRO_ELIMINADO.equals(tipoComparacion)?datoNuevo.toString():" ");
                    /*FIN-P34 PAS20165E220200126 AFMA*/
                        datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
                        datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
                        datoModificadoBean.setDescripcionNombreCampo(descripcionNombreCampo);
                        datoModificadoBean.setDescripcionSecccion(descripcionSecccion);
                        datoModificadoBean.setIdentificadorCampo(identificadorCampo);
                        lstCambio.add(datoModificadoBean);
                      //  }
                      }
                  } else {
                  if (valorR != null && !Utilidades.equalsByClass(valorR, valorH))
                  {
                    datoNuevo   = getCodigoDescripcionDataCatalogo(nombreCampo, valorR);
                    datoAntiguo = getCodigoDescripcionDataCatalogo(nombreCampo, valorH);

                    datoNuevo   = formatoFecha(nombreCampo, datoNuevo);
                    datoAntiguo = formatoFecha(nombreCampo, datoAntiguo);

                    
                    //if(!descripcionNombreCampo.trim().isEmpty() ){//&& !descripcionSecccion.trim().equalsIgnoreCase("---")){//P28-PAS20155E410000032-INSI
                    datoModificadoBean = new DatoModificadoBean();

                    datoModificadoBean.setNombreCampo(nombreCampo);
                    datoModificadoBean.setDatoNuevo(datoNuevo.toString());
                    datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
                    datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
                    datoModificadoBean.setDescripcionNombreCampo(descripcionNombreCampo);
                    datoModificadoBean.setDescripcionSecccion(descripcionSecccion);
                    datoModificadoBean.setIdentificadorCampo(identificadorCampo);
                    lstCambio.add(datoModificadoBean);
                  //  }
                  }
              }
                  

              }
            }
          }
      }

      //fromatea la fecha a dd/MM/yyyy
      //formatoFecha(lstCambio);
      return lstCambio;
  }





//amancilla PAS20155E220200035
  private boolean esUnCampoQueNoSeDebeMostrarAlUsurio(String nomTabla, String nombreCampo,Object valorR,Object valorH)
  {
	  return esUnCampoQueNoSeDebeMostrarAlUsurio(nomTabla, nombreCampo, valorR, valorH, TIPO_REGISTRO_MODIFICADO);
  }

  private boolean esUnCampoQueNoSeDebeMostrarAlUsurio(String nomTabla, String nombreCampo,Object valorR,Object valorH, String tipoRegistro)
  {

    if(Constantes.COD_TABLA_CAB_DECLARA_DESC.equals(nomTabla) )
    {
      if (ArrayUtils.contains(new String[] { "COD_MOTIVOCANALASI","FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL" },nombreCampo)
          || soporteComparadorService.esCampoClave(nomTabla,nombreCampo))
      {
        return true;
      }
      else if(nombreCampo.startsWith("MTO_") || nombreCampo.startsWith("CNT_"))
      {
    	  return esUnValorDespreciable(nombreCampo, valorR, valorH);
    		  
      }
    }
    else if(Constantes.COD_TABLA_DET_DECLARA_DESC.equals(nomTabla))
    {

      if(nombreCampo.startsWith("MTO_") || nombreCampo.startsWith("CNT_"))
      {
    	 /* 
        double dif_mto_fobdol = Double.valueOf(valorR!=null?valorR.toString():"0") - Double.valueOf((valorH!=null && !valorH.toString().isEmpty()) ?valorH.toString():"0");
        double diferenciaMaximaMonto = nombreCampo.startsWith("MTO_")?Double.valueOf(Constantes.DIFERENCIA_MAX_MONTO):Double.valueOf(Constantes.DIFERENCIA_MAX_PESO);
        if(Math.abs(dif_mto_fobdol) < diferenciaMaximaMonto)
        {
          return true;
        }*/
    	  
    	  return esUnValorDespreciable(nombreCampo, valorR, valorH);
      }
      else if (ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL" },nombreCampo)
          || soporteComparadorService.esCampoClave(nomTabla,nombreCampo))
      {
        return true;
      }
    }
    else if(Constantes.COD_TABLA_FORMA_FACTU_DESC.equals(nomTabla))
    {
      if (ArrayUtils.contains(new String[] { "COD_MOMGRAB","FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL" },nombreCampo)
          || soporteComparadorService.esCampoClave(nomTabla,nombreCampo))
      {
        return true;
      }
    }
    else if("PARTICIPANTE_DOC".equals(nomTabla))
    {
    	//P34 AFMA FSW
      //if (ArrayUtils.contains(new String[] { "COD_DOCIDENTPROVLOC","FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL" },nombreCampo)
    	if (ArrayUtils.contains(new String[] { "COD_DOCIDENTPROVLOC","FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL","COD_TIPPARTIC" },nombreCampo)
          || soporteComparadorService.esCampoClave(nomTabla,nombreCampo))
      {
        return true;
      }
    }
  //AMANCILLLA PAS20155E220200035 SE AGREGA COD_TABLA_DET_AUTORIZACION
    else if(Constantes.COD_TABLA_SERIES_ITEM_DESC.equals(nomTabla) || Constantes.COD_TABLA_FACTURA_SERIE.equals(nomTabla) || Constantes.COD_TABLA_DET_AUTORIZACION.equals(nomTabla))
    {
      return true;
    }
    //SAU20153K004000062 amancilla
    //AMANCILLLA PAS20155E220200035 SE AGREGA REG PRECEDENCIA DADO QUE SE PUEDE ELIMINAR Y NO SE MUESTRA
    else if(Constantes.COD_TABLA_CONVENIO_SERIE_DESC.equals(nomTabla))
    {
    	boolean rspta = false;
    	if(ArrayUtils.contains(new String[] { TIPO_REGISTRO_MODIFICADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","COD_TIPCONVENIO"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
    		rspta = true;
    	}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_NUEVO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","NUM_SECSERIE","COD_TIPCONVENIO"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA - PAS20155E410000032
    		rspta = true;
    	}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_ELIMINADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","NUM_SECSERIE","COD_TIPCONVENIO"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
    		rspta = true;
    	}
    	
      //campos que si se deben de ver IND_DEL, COD_CONVENIO a pesar de estar en la clave
      return rspta;
    }
	//P46-PAS20155E410000032
    else if(Constantes.COD_TABLA_INDICADOR_DUA_DESC.equals(nomTabla) && nombreCampo.equalsIgnoreCase("COD_INDICADOR") )
    {
      //campos que si se deben de ver, COD_INDICADOR a pesar de estar en la clave ...
      return false;//P28-PAS20155E410000032-INSI 
    }
    else if(Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(nomTabla))
    {
    	boolean rspta = false;
    	if(ArrayUtils.contains(new String[] { TIPO_REGISTRO_MODIFICADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOCPRE","NUM_CORREDOC","NUM_SECSERIE"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
    		rspta = true;
    	}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_NUEVO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOCPRE","NUM_CORREDOC","NUM_SECSERIE","IND_DEL"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
    		rspta = true;
    	}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_ELIMINADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOCPRE","NUM_CORREDOC","NUM_SECSERIE"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
    		rspta = true;
    	}
    	
    	return rspta;
    }
    else if("DOCAUT_ASOCIADO".equals(nomTabla))
    {
	      boolean rspta = false;
	  	if(ArrayUtils.contains(new String[] { TIPO_REGISTRO_MODIFICADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_NUEVO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC","IND_DEL"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_ELIMINADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}
	  	 return rspta;
    }   
    
    /*else if("DET_AUTORIZACION".equals(nomTabla))
    {
	      boolean rspta = false;
	  	if(ArrayUtils.contains(new String[] { TIPO_REGISTRO_MODIFICADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_NUEVO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC","IND_DEL"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_ELIMINADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO AMANCILLA
			rspta = true;
		}
	  	 return rspta;
    }*/
    /****Inicio cambios del PAS20165E220200055**/ 
    else if("FORMBITEMDESCRI".equals(nomTabla))
    {
	      boolean rspta = false;
	  	if(ArrayUtils.contains(new String[] { TIPO_REGISTRO_MODIFICADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS",
	  			"NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC","NUM_SECITEM","NUM_SECPROVE","NUM_SECFACT","COD_MERCANCIA"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO  
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_NUEVO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS",
				"NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC","NUM_SECITEM","NUM_SECPROVE","NUM_SECFACT","COD_MERCANCIA","IND_DEL"},nombreCampo)){  //M MODIFICADO E ELIMINADO N - NUEVO 
			rspta = true;
		}else if(ArrayUtils.contains(new String[] {TIPO_REGISTRO_ELIMINADO},tipoRegistro) && ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", 
				"COD_USUREGIS","NUM_CORREDOC","COD_TIPOPER","NUM_SECDOC","NUM_SECITEM","NUM_SECPROVE","NUM_SECFACT","COD_MERCANCIA"},nombreCampo)){  //M MODIFICADO E ELIMINADO N -NUEVO 
			rspta = true;
		}
	  	 return rspta;
    } 
    /****Fin cambios del PAS20165E220200055**/ 
    else
    {
    	//amancilla cambio convenio es un caso especial esta en la clave cuandos e elmina el tpn solo cambio IND_DEl por eso debe verse
      if(!Constantes.COD_TABLA_CONVENIO_SERIE_DESC.equals(nomTabla) && !Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(nomTabla) &&
    		  /*!"DET_AUTORIZACION".equals(nomTabla) && */!"DOCAUT_ASOCIADO".equals(nomTabla)
    		  
    		  ){	
      if (ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL","NUM_CORREDOC" },nombreCampo)
          || soporteComparadorService.esCampoClave(nomTabla, nombreCampo) /* AMANCILLA && !"COD_CONVENIO".equals(nombreCampo)*/)
      {
        return true;
      }
      }
		//P46-PAS20155E410000032 COD_INDICADOR tb es un caso especial
      if(!Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(nomTabla)){/*P28-PAS20155E410000032-[jlunah] no considerar a la tabla DOCUPRECE_DUA*/
	      if(!Constantes.COD_TABLA_CONVENIO_SERIE_DESC.equals(nomTabla) && !Constantes.COD_TABLA_INDICADOR_DUA_DESC.equals(nomTabla) ){	
	      if (ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS","IND_DEL" },nombreCampo)
	          || soporteComparadorService.esCampoClave(nomTabla, nombreCampo) /* AMANCILLA && !"COD_CONVENIO".equals(nombreCampo)*/)
	      {
	        return true;
	      }
	      }
      }

    }

    return false;
  }



private boolean esUnValorDespreciable(String nombreCampo, Object valorR,
		Object valorH) {
	
	boolean esUnValorDespreciable =false;
	BigDecimal mto_new = new BigDecimal(valorR!=null?valorR.toString():"0");
	BigDecimal mto_old = new BigDecimal(valorH!=null?valorH.toString():"0");	 
	BigDecimal dif_mto = SunatNumberUtils.absoluteDiference(mto_new,mto_old); 
		
	BigDecimal diferenciaMaximaMonto = nombreCampo.startsWith("MTO_")?new BigDecimal(Constantes.DIFERENCIA_MAX_MONTO):new BigDecimal(Constantes.DIFERENCIA_MAX_PESO);

	if(dif_mto.compareTo(diferenciaMaximaMonto) < 0)
	{
		esUnValorDespreciable =true;
	}
	
	return esUnValorDespreciable;
}



          /**
           * {@inheritDoc}
           */
            public List<DatoModificadoBean> obtenerDatosModificadosTmpOfiRecti(Map<String, Object> mapTablaNew,
                                                                   Map<String, Object> mapTablaOld,
                                                                   String codTabla,
                                                            Map<String, Object> mapKey) throws ServiceException {

//limpiamos las columnas con sus respectivas campos registrados en el xml mapping
              //SE DESACTIVA POR ANOMALIAS soporteComparadorService.validarMapEntidad VUELVE
              //QUITA LOS CAMPOS QUE NO CORRESPONDE PERO TAMBIEN SETEAN LAS FECHAS QUE DESPUES SE VUELVEBN STING
              //SI SE USA EL COMPRADO YA NO SE NECESITARIA
            	 mapTablaNew = soporteComparadorService.validarMapEntidad(mapTablaNew,codTabla);
                 mapTablaOld = soporteComparadorService.validarMapEntidad(mapTablaOld,codTabla);

                List<DatoModificadoBean> lstRspta = new ArrayList<DatoModificadoBean>();

                String nombreCampo = "";
                Object datoNuevo =  "";
                Object datoAntiguo =  "";
                String identificadorCampo = "";
                String descripcionIdentificadorCampo = generaClaveMostrar(mapKey,codTabla);
                String descripcionSecccion    = "";
                String descripcionNombreCampo ="";
                String valorNombreCampo="";
                boolean flag=false;

                for (Entry<String, Object> entradaActual : mapTablaNew.entrySet()) {

                    DatoModificadoBean datoModificadoBean = new DatoModificadoBean();

                    nombreCampo = entradaActual.getKey();
                    identificadorCampo = SojoUtil.toJson(mapKey);

                    String desTabla = catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_CODIFICACION_TABLAS,codTabla);
                    Map<String, String> mapaDesc = buscarDescripcion(desTabla,nombreCampo);
                    descripcionSecccion    = mapaDesc.get("NOM_SECCION") != null ? mapaDesc.get("NOM_SECCION").toString() : "---";
                    descripcionNombreCampo = mapaDesc.get("NOM_CASILLA") != null ? mapaDesc.get("NOM_CASILLA").toString() : nombreCampo;


                    //jenciso cuando es un registro nuevo, mapTablaOld es vacio, se agrega la condicional. 
                    
                    if(!CollectionUtils.isEmpty(mapTablaOld)){
                    	
                     if("PARTICIPANTE_DOC".equals(desTabla) && "COD_TIPDOC".equals(nombreCampo))
                     {
              		     nombreCampo="COD_TIPDOC_PARTICIPANTE";
              		     valorNombreCampo=mapTablaOld.get("COD_TIPDOC").toString();
              		     flag=true;
              		  }else{
              			valorNombreCampo=mapTablaOld.get(nombreCampo).toString();
              		  }


                   // si contine el key solo en el Mapa nuevo
                      if (!mapTablaOld.containsKey(entradaActual.getKey())) {
                          EnumTablaModel enumTablaModel = EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla);
                          EntidadXml entidad = soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());
                          CampoXml campo = soporteMapeoTablasService.getCampo(entradaActual.getKey(), entidad);
                          Object objHistoricoValorDefacult = ParserUtil.obtenerObjeto(campo.getDataDefault(),
                                  campo.getTipoDato(), campo.getFormato());

                          datoAntiguo = objHistoricoValorDefacult.toString();

                      }else{
                    	 
                          datoAntiguo = getCodigoDescripcionDataCatalogo(nombreCampo,valorNombreCampo);
                      }

                      datoNuevo = getCodigoDescripcionDataCatalogo(nombreCampo, entradaActual.getValue());

                      datoAntiguo = formatoFecha(nombreCampo, datoAntiguo);
                      datoNuevo   = formatoFecha(nombreCampo, datoNuevo);

                      datoModificadoBean.setNombreCampo(nombreCampo);
                      datoModificadoBean.setDatoNuevo(datoNuevo.toString());
                      datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
                      datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
                      datoModificadoBean.setDescripcionNombreCampo(descripcionNombreCampo);
                      datoModificadoBean.setDescripcionSecccion(descripcionSecccion);
                      datoModificadoBean.setIdentificadorCampo(identificadorCampo);
                      lstRspta.add(datoModificadoBean);
                    }else{//cuando el registro es nuevo 
                    	
                    	// no se considera el pk
                    	if(!mapKey.containsKey(entradaActual.getKey())){
                    		
                    		EnumTablaModel enumTablaModel = EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla);
                            EntidadXml entidad = soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());
                            CampoXml campo = soporteMapeoTablasService.getCampo(entradaActual.getKey(), entidad);
                            Object objHistoricoValorDefacult = ParserUtil.obtenerObjeto(campo.getDataDefault(),campo.getTipoDato(), campo.getFormato());
                            datoAntiguo = objHistoricoValorDefacult.toString();
                            
                        	datoNuevo = getCodigoDescripcionDataCatalogo(nombreCampo, entradaActual.getValue());
                        	
    	                    datoAntiguo = formatoFecha(nombreCampo, datoAntiguo);
    	                    datoNuevo   = formatoFecha(nombreCampo, datoNuevo);
    	                    datoModificadoBean.setNombreCampo(nombreCampo);
    	                    datoModificadoBean.setDatoNuevo(datoNuevo.toString());
    	                    datoModificadoBean.setDatoAntiguo(datoAntiguo.toString());
    	                    datoModificadoBean.setDescripcionIdentificadorCampo(descripcionIdentificadorCampo);
    	                    datoModificadoBean.setDescripcionNombreCampo(descripcionNombreCampo);
    	                    datoModificadoBean.setDescripcionSecccion(descripcionSecccion);
    	                    datoModificadoBean.setIdentificadorCampo(identificadorCampo);
    	                    lstRspta.add(datoModificadoBean);
                    	}
                    	
                    	
                    }
                    
                  }


              //fromatea la fecha a dd/MM/yyyy
               // formatoFecha(lstRspta);
                return lstRspta;
            }

          /**
           * Metodo que busca obtener un Json de la Clave de la tabla pero usando campos descriptivos
           * para ellos obtenemos la descripcion del campo DES_NEMONICO de la tabla catcasillaformato
           * @param claveDes : Clave en Json que puede estar compuesto por varios campos
           * @param codTabla : Tabla que contiene la clave
           * @return una cadena en Json con la nueva descripcion de la clave
           * @author rbegazo
           */
          private String generaClaveMostrar(Map listClave, String codTabla)
          {
              //Map listClave = (Map)SojoUtil.fromJson(claveDes);
              Map<String, Object> mapClaveDes = new HashMap<String, Object>();
              Iterator iterClave = listClave.entrySet().iterator();
              while(iterClave.hasNext()){
                  Map.Entry entry = (Map.Entry)iterClave.next();
                  String clave = " ";

                  String desTabla = codTabla; // a veces invocan con EL NOMBRE DE LA TABLA NO SOLO CONJ LE CODIGO
                  if(codTabla.contains("T0") ){//jenciso hay tablas mayores a T0100
                      desTabla = catalogoAyudaService.getDescripcionDataCatalogo(CAT_CODIFICACION_TABLAS,codTabla);
                  }

                  Map<String, String> mapaDesc = buscarDescripcion(desTabla, entry.getKey().toString());
                  if (!CollectionUtils.isEmpty(mapaDesc)){
                      clave = mapaDesc.get("DES_NEMONICO").toString();
                  }
                  String data = entry.getValue().toString();
                  mapClaveDes.put(clave, data);
              }
              String res = SojoUtil.toJson(mapClaveDes);
              return res;
          }


          private String generaClaveMostrar2(Map listClave, String codTabla)
          {
              //Map listClave = (Map)SojoUtil.fromJson(claveDes);
              Map<String, Object> mapClaveDes = new HashMap<String, Object>();
              Iterator iterClave = listClave.entrySet().iterator();
              while(iterClave.hasNext()){
                  Map.Entry entry = (Map.Entry)iterClave.next();
                  String clave = " ";

                  String desTabla = codTabla; // a veces invocan con EL NOMBRE DE LA TABLA NO SOLO CONJ LE CODIGO
                  if(codTabla.contains("T0") ){
                      desTabla = catalogoAyudaService.getDescripcionDataCatalogo(CAT_CODIFICACION_TABLAS,codTabla);
                  }

                  Map<String, String> mapaDesc = buscarDescripcion(desTabla, entry.getKey().toString().toUpperCase());
                  if (!CollectionUtils.isEmpty(mapaDesc)){
                      clave = mapaDesc.get("DES_NEMONICO").toString();
                  }
                  String data = entry.getValue().toString();
                  mapClaveDes.put(clave, data);
              }

              return mapClaveDes.toString();
          }

    
          private String generaClaveMostrar3(Map listClave, String codTabla,Map mapTablaNew,String tipoComparacion)
          {
        	  
        	  String identificadorCampo="";
                            
        	  if(TIPO_REGISTRO_ELIMINADO.equals(tipoComparacion)){
        		  
        		  if(Constantes.COD_TABLA_CONVENIO_SERIE_DESC.equals(codTabla))
  			    {
  				  
  				  identificadorCampo = "CONVENIO:"+mapTablaNew.get("COD_CONVENIO")+" SERIE:"+mapTablaNew.get("NUM_SECSERIE");
  			    }
  			    /*else if(Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(nomTabla))
  			    {
  			    	identificadorCampo = "REGIMEN:"+mapTablaNew.get("COD_CONVENIO")+" SERIE:"+mapTablaNew.get("NUM_SECSERIE");
  			    }*/
  			    else if("DOCAUT_ASOCIADO".equals(codTabla)) {
                    identificadorCampo = "NUMERO DOCUMENTO:" + mapTablaNew.get("NUM_DOC");

                  }else if(Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(codTabla)){
                      identificadorCampo = "REGIMEN PRECEDENTE:"+mapTablaNew.get("COD_ADUANAPRE")+"-"+mapTablaNew.get("ANN_PRESENPRE")+"-"+mapTablaNew.get("COD_REGIMENPRE")+"-"+mapTablaNew.get("NUM_DECLARACIONPRE");
  			    }else{
  			    	identificadorCampo =  generaClaveMostrar2(listClave,codTabla);
  			    }
        		  
        	  }else{

                  identificadorCampo =  generaClaveMostrar2(listClave,codTabla);
        	  }

             
              
              return identificadorCampo;
          }
  /**
   * Sets the dato complejo.
   *
   * @param campoValorR
   *          the campo valor r
   * @param campoValorH
   *          the campo valor h
   * @param mapRecti
   *          the map recti
   * @param enumRectifica
   *          the enum rectifica
   */
  private void setDatoComplejo(Object campoValorR, Object campoValorH,
    Map<String, Object> mapRecti, EnumRectifica enumRectifica)
  {
    // como dato catalogo
    String codCat = enumRectifica.getCodCatalogoDelCampo();
    String codElemento = campoValorR != null ? campoValorR.toString().trim() : "";
    String codElementoH = campoValorH != null ? campoValorH.toString().trim() : "";

    String campoValorRDesc = catalogoAyudaService.getDescripcionDataCatalogo(codCat, codElemento);
    String campoValorHDesc = catalogoAyudaService.getDescripcionDataCatalogo(codCat, codElementoH);
    // agrega
    if (log.isDebugEnabled())
      log.debug(".=====>" + codCat + "," + codElemento);
    if (log.isDebugEnabled())
      log.debug("campoValorRDesc:" + campoValorRDesc);
    if (log.isDebugEnabled())
      log.debug(".=====>" + codCat + "," + codElementoH);
    if (log.isDebugEnabled())
      log.debug("campoValorHDesc:" + campoValorHDesc);
    if (!campoValorRDesc.trim().isEmpty())
      mapRecti.put("VALORR", campoValorR.toString().concat("-").concat(campoValorRDesc));
    if (!campoValorHDesc.trim().isEmpty())
      mapRecti.put("VALORH", campoValorH.toString().concat("-").concat(campoValorHDesc));
  }

  /**
   * Metodo que nos permite buscar si un campo ya fue registrado dentro de una
   * lista.
   *
   * @param listaRectificados
   *          the lista rectificados
   * @param campo
   *          the campo
   * @return boolean
   */
  private boolean buscarListaR(List<Map<String, Object>> listaRectificados, String campo, String pk)
  {

    boolean encontrado = false;
    for (Map<String, Object> mapa : listaRectificados)
    {
    	//amancilla PAS20155E220200035
      if (mapa.get("CAMPO") != null && (mapa.get("CAMPO").equals(campo) || (campo.contains("COD_TIPDOC") && campo.contains(mapa.get("CAMPO").toString()))) && mapa.get("PK").equals(pk))
      {
        encontrado = true;
        break;
      }
    }

    return encontrado;
  }


  private boolean buscarListaR2(List<Map<String, Object>> listaRectificados, String campo)
  {

    boolean encontrado = false;
    for (Map<String, Object> mapa : listaRectificados)
    {
      if (mapa.get("CAMPO") != null && mapa.get("CAMPO").equals(campo))
      {
        encontrado = true;
        break;
      }
    }

    return encontrado;
  }
  /**
   * Metodo que nos permite obtener un mapa con las descripciones de la seccion
   * y columna.
   *
   * @param tabla
   *          the tabla
   * @param campo
   *          the campo
   * @return Map<String,String> devuelve e mapa con las descripciones de la
   *         seccion o de la columna
   */
  private Map<String, String> buscarDescripcion(final String tabla, final String campo)
  {
	  //rtineo mejoras, llamamos al metodo sobrecargado
	  return buscarDescripcion(tabla,campo,null);
  }
  
  //rtineo mejoras sobrecargamos el metodo
  private Map<String, String> buscarDescripcion(final String tabla, final String campo,Map<String,Map<String, String>> mapDescripcion)
  {

    Map<String, String> res = null;
    //rtineo mejoras, reutilizamos la lista precargada
    List<Map<String, String>> listaDesc = new ArrayList<Map<String,String>>();
    if(mapDescripcion != null){
    	//rtineo obtenemos del mapa precargado
    	res = mapDescripcion.get(tabla+"-"+campo);
    }else{
    	//rtineo continuamos ejecutando el metodo pesado
    String codTipoCat = Constantes.COD_TIPO_CATALOGO;
        listaDesc = this.catCasillaFormatoDAO.findByCodTipoCat(codTipoCat);
    res = (Map<String, String>) org.apache.commons.collections.CollectionUtils.find(listaDesc, new Predicate()
    {

      @Override
      public boolean evaluate(Object objCasilla)
      {
        Map<String, String> mapCasilla = (Map<String, String>) objCasilla;
        String monSinonimTab = ObjectUtils.toString(mapCasilla.get("NOM_SINONIMTAB"), "TABLA_DESCONOCIDA");
        String monCampo = ObjectUtils.toString(mapCasilla.get("NOM_CAMPO")).trim();
        return (monSinonimTab.equals(tabla)) && (monCampo.equals(campo));
      }
    });
    }
    //fin mejoras

    if (res == null)
    {
      return new HashMap<String, String>();
    }
    return res;
  }



  /**
   * {@inheritDoc}
   */
    public Map<String, Object> obtenerDatosModificadosEnDiligencias(String numCorreDoc) throws ServiceException {

        if (log.isDebugEnabled()) {
            log.debug("****Inicio-obtenerDatosModificadosEnDiligencias()*****");
            log.debug("Imput: numCorreDoc:" + numCorreDoc);
        }
        // mapa que retorna todas las listas rectificadas
        Map<String, Object> mapaRSPTADatosModificados = new HashMap<String, Object>(); // de la forma ("tabla",mapaCambios)

        List<Map<String, Object>> listaElemCabDeclara     = new ArrayList<Map<String, Object>>(); // mapaCambios("campo",listaCambios)
        List<Map<String, Object>> listaElemDetDeclara     = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemEquipamiento   = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemDocAsociado    = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemDetAut         = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemCertOrigen     = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemRegPrecedente  = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemFormatoBDAV    = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemFormatoBFactura     = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemFormatoBItemFactura = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemSeriesItem          = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemConvenioSerie       = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemFacturasSeries      = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemObservacion         = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemParticipantesDUA         = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> listaElemFOBValorProvisionalDUA         = new ArrayList<Map<String, Object>>();//gmontoya Pase 35 2017
        List<Map<String, Object>> listaElemFacturaSuce         = new ArrayList<Map<String, Object>>();//PAS20175E220200035

        //INICIO P24-bug 24608,24609 ,24610  
        Map<String, Object> parametros = new HashMap<String, Object>();	 	 
		parametros.put("NUM_CORREDOC", numCorreDoc);
      //  Map<String, Object> diligencia = new HashMap<String, Object>();
       // diligencia = cabDiligenciaDAO.findUltimaDiligencia(parametros);
        Map<String, Object> params = new HashMap<String, Object>(); 
        params.put("numcorredoc", numCorreDoc);
        //if (diligencia!=null)
//        {
//	        if(!CollectionUtils.isEmpty(diligencia)){	        
//		        String[] tipoDiligencia = new String[] {diligencia.get("COD_TIPDILIGENCIA").toString()} ;
//		        params.put("tipoDiligencia", tipoDiligencia);
//	        }
//        }
        //FIN P24-bug 24608,24609 ,24610
        //solo me trae los dato rectificados en la rectificacion de oficio
        //List<Map<String, Object>> listaDatosModificadosEnDiligencia = this.rectiOficioDAO.findRectiOficioByParams(params); se comenta por que se va considearar buscar el ultimo rectificacion oficio registrado para la consulta Dua
        List<Map<String, Object>> listaDatosModificadosEnDiligencia = this.rectiOficioDAO.findUltimaRectiOficioByParams(params);//bug   25156 cuando esta en revision no se muestra los datos rectificados

        if (!CollectionUtils.isEmpty(listaDatosModificadosEnDiligencia)) {

            JsonSerializer serializer = new JsonSerializer(); // Objeto utilitario para deserializar JSON

            for (Map<String, Object> mapaDatosJSONPorTabla : listaDatosModificadosEnDiligencia) {// registo Tabla JSON

            	//P24
                //Map<String, Object> mapaDesData = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desdata1")).concat((String) mapaDatosJSONPorTabla.get("desdata2")));
                //Map<String, Object> mapaDesClave = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desclave")));

         	   String strDesData = ((String) mapaDatosJSONPorTabla.get("desdata1")).concat((String) mapaDatosJSONPorTabla.get("desdata2"));
         	   String strDesClave = ((String) mapaDatosJSONPorTabla.get("desclave"));
         	   
         	   Map<String, Object> mapaDesData = new HashMap<String,Object>();
         	   Map<String, Object> mapaDesClave = new HashMap<String,Object>();
         	   if (!SunatStringUtils.isEmptyTrim(strDesData)){
         		   mapaDesData = (Map<String, Object>) serializer.deserialize(strDesData);
         	   }
         	   if (!SunatStringUtils.isEmptyTrim(strDesClave)){
         		  mapaDesClave = (Map<String, Object>) serializer.deserialize(strDesClave);
         	   }	   

                
                
                String claveABuscar = mapaDatosJSONPorTabla.get("desclave").toString();
                // recorremos ambos mapas de datos estamos considerando los
                // registros nuevos
                if (!CollectionUtils.isEmpty(mapaDesData)) {
                        // recorro todos los campos dentro del JSON
                        for (String campo : mapaDesData.keySet()) {

                                List<Map<String, Object>> listaCambios = new ArrayList<Map<String, Object>>(); // elemento que contiene
                                                                                                            // (campo,Listacambios)
                              // List<Map<String, Object>> = LISTACAMBIOS":[{"VALORH":1385370,"VALORR":1384031.869,"TIPO
                              // DILIGENCIA":"03-DESPACHO","USUARIO REGISTRO":"I900-Alex mancilla"}]
                                Map<String, Object> mapaElem = new HashMap<String, Object>();
                                String codTabla = (String) mapaDatosJSONPorTabla.get("codtabla");

                            if (codTabla.equals(Constantes.COD_TABLA_CAB_DECLARA)) {
                                // si no estan dentro del mapa resultado debo a�adirlo
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_CAB_DECLARA, mapaDesClave);
                                if (buscarListaR(listaElemCabDeclara, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {
                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemCabDeclara.add(mapaElem);
                                    }
                                }
                            } else if (codTabla.equals(Constantes.COD_TABLA_DET_DECLARA)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_DET_DECLARA, mapaDesClave);
                                if (buscarListaR(listaElemDetDeclara, campo,pk) == false)
                                {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {
                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemDetDeclara.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_EQUIPAMIENTO)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_EQUIPAMIENTO, mapaDesClave);
                                if (buscarListaR(listaElemEquipamiento, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemEquipamiento.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_DOCAUT_ASOCIADO)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_DOCAUT_ASOCIADO, mapaDesClave);
                                if (buscarListaR(listaElemDocAsociado, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemDocAsociado.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_DET_AUTORIZACION)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_DET_AUTORIZACION, mapaDesClave);
                                if (buscarListaR(listaElemDetAut, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemDetAut.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_DOCUPRECE_DUA)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_DOCUPRECE_DUA, mapaDesClave);
                                if (buscarListaR(listaElemRegPrecedente, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemRegPrecedente.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_FORMB_PROVEEDOR)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_FORMB_PROVEEDOR, mapaDesClave);
                                if (buscarListaR(listaElemFormatoBDAV, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemFormatoBDAV.add(mapaElem);
                                    }
                                }
                            } else if (codTabla.equals(Constantes.COD_TABLA_COMPROBPAGO)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_COMPROBPAGO, mapaDesClave);
                                if (buscarListaR(listaElemFormatoBFactura, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemFormatoBFactura.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_ITEM_FACTURA)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_ITEM_FACTURA, mapaDesClave);
                                if (buscarListaR(listaElemFormatoBItemFactura, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemFormatoBItemFactura.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_SERIES_ITEM)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_SERIES_ITEM, mapaDesClave);
                                if (buscarListaR(listaElemSeriesItem, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemSeriesItem.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_OBSERVACION)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_OBSERVACION, mapaDesClave);
                                if (buscarListaR(listaElemObservacion, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemObservacion.add(mapaElem);
                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_CONVENIO_SERIE)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_CONVENIO_SERIE, mapaDesClave);
                                if (buscarListaR(listaElemConvenioSerie, campo, pk) == false) {
                                //RIN 08 INICIO
                                	//amancilla esto no funciona solo srive para la primera serie verificar si se puede sacar
									if (SunatStringUtils.isEqualTo(campo,"IND_DEL")) {
                                		for (String campoConvenio : mapaDesClave.keySet()){
                                			if (SunatStringUtils.include(campoConvenio, new String[]{"COD_CONVENIO","COD_TIPCONVENIO"})) {
	                                			String indConvenio = mapaDesData.get("IND_DEL").toString();
	                                			//mapaElem = new HashMap<String, Object>();
			                                    listaCambios = this.obtenerListaCambiosPorCampoPK(campoConvenio, codTabla, listaDatosModificadosEnDiligencia,claveABuscar, indConvenio);
	                                			//listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
			                                    if (!CollectionUtils.isEmpty(listaCambios)) {
			                                    	if (SunatStringUtils.include(campoConvenio, new String[]{"COD_TIPCONVENIO"})) {
				                                        mapaElem.put("PK", pk);
				                                        String campoNew  = "COD_CONVENIO_C"+(String) (listaCambios.get(0).get("VCAMPO") == "---" ?listaCambios.get(0).get("VCAMPOANT"):listaCambios.get(0).get("VCAMPO"));
				                                        mapaElem.put("CAMPO", campoNew);			                                    		
			                                    	}else {
				                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);						                                        
			                                    	}			                                        			
			                                    }
                                			}
                                		}
										//RIN 08 FIN
                            			listaElemConvenioSerie.add(mapaElem);
                            			
                                	}else if(SunatStringUtils.contains(campo,"COD_CONVENIO")){ //amancilla no aparece el cambio anterior se arregla solo para recti de ofiocio                                		
                                		listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                        if (!CollectionUtils.isEmpty(listaCambios)) {
                                        	 // Map<String, Object> desClave = (Map<String, Object>) mapaDatosJSONPorTabla.get("desclave");
                                        	  //mapaDesClave = mapaDesClave;
                                            mapaElem.put("PK", pk);                                                                                                                                                                                                               
                                            mapaElem.put("CAMPO", campo);
                                            mapaElem.put("LISTA_CAMBIOS", listaCambios);
// INICIO PAS201830001100016 MORDONEZL
                                            if(campo.equals("COD_CONVENIO")){
                                            	for (String campoConvenio : mapaDesClave.keySet()){
                                            		if (SunatStringUtils.include(campoConvenio, new String[]{"COD_TIPCONVENIO"})) {
                                            			String campoNew  = "COD_CONVENIO_C".concat(mapaDesClave.get("COD_TIPCONVENIO").toString());
                                            			mapaElem.put("CAMPO", campoNew);
                                            		}
                                            	}
                                            }
// FIN PAS201830001100016
                                            listaElemConvenioSerie.add(mapaElem);
                                	}
                                		
                                	}
									
									
									
									
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_CAB_CERTIORIGEN)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_CAB_CERTIORIGEN, mapaDesClave);
                                if (buscarListaR(listaElemCertOrigen, campo, pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemCertOrigen.add(mapaElem);

                                    }
                                }

                            } else if (codTabla.equals(Constantes.COD_TABLA_FORMA_FACTU)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_FORMA_FACTU, mapaDesClave);
                                if (buscarListaR(listaElemFacturasSeries, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {

                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemFacturasSeries.add(mapaElem);
                                    }
                                }

                            }
                            else if (codTabla.equals(Constantes.COD_TABLA_PARTICIPANTE_DOC)) {
                              String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_PARTICIPANTE_DOC, mapaDesClave);

                              String numSecParticipante = pk;
                              Participante participante= participanteDocDAO.getByPrimaryKey(new Long(numSecParticipante));
                              String tipoParticipante = participante.getTipoParticipante().getCodDatacat();
                              String[] tipoPTR = {"11","12","14"};

                              String sufijo = "";
                              if("45".equals(tipoParticipante))
                              {
                                sufijo = "_PIM";
                              }
                              else if(Arrays.asList(tipoPTR).contains(tipoParticipante))
                              {
                                sufijo = "_PTR";
                              }
                              else if("31".equals(tipoParticipante))
                              {
                                sufijo = "_PDF";
                              }
                              String campoNew = campo.concat(sufijo);

                              if (buscarListaR(listaElemParticipantesDUA, campoNew,pk) == false) {
                                  //amancilla PAS20155E220200035 listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                            	  listaCambios = this.obtenerListaCambiosPorCampo(campoNew, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                  if (!CollectionUtils.isEmpty(listaCambios)) {
                                      mapaElem.put("PK", pk);
                                      mapaElem.put("CAMPO", campoNew);
                                      mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                      listaElemParticipantesDUA.add(mapaElem);
                                  }
                              }

                          }
						  /*inicio P46-PAS20155E410000032 INSI*/
                            else if (codTabla.equals(Constantes.COD_TABLA_INDICADOR_DUA)) {
                                String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_INDICADOR_DUA, mapaDesClave);
                                if (buscarListaR(listaElemCabDeclara, campo,pk) == false) {
                                    listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                    if (!CollectionUtils.isEmpty(listaCambios)) {
                                        mapaElem.put("PK", pk);
                                        mapaElem.put("CAMPO", campo);
                                        mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                        listaElemCabDeclara.add(mapaElem);
                                    }
                                }                            	
                            }
						  /*fin P46-PAS20155E410000032 INSI*/
						  //inicio gmontoya Pase 35 2017
                            else if (codTabla.equals(Constantes.COD_TABLA_VFOB_PROVISIONAL)) {
                              String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_VFOB_PROVISIONAL, mapaDesClave);
                              if (buscarListaR(listaElemFOBValorProvisionalDUA, campo,pk) == false) {
                                listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                if (!CollectionUtils.isEmpty(listaCambios)) {
                                  mapaElem.put("PK", pk);
                                  mapaElem.put("CAMPO", campo);
                                  mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                  listaElemFOBValorProvisionalDUA.add(mapaElem);
                                }
                              }
                            }
                          //fin gmontoya Pase 35 2017
  						  //inicio PAS20175E220200035
                            else if (codTabla.equals(Constantes.COD_TABLA_FACTUSUCE)) {
                              String pk = this.obtenerPKElemModificado(Constantes.COD_TABLA_FACTUSUCE, mapaDesClave);
                              if (buscarListaR(listaElemFacturaSuce, campo,pk) == false) {
                                listaCambios = this.obtenerListaCambiosPorCampo(campo, codTabla, listaDatosModificadosEnDiligencia,claveABuscar);
                                if (!CollectionUtils.isEmpty(listaCambios)) {
                                  mapaElem.put("PK", pk);
                                  mapaElem.put("CAMPO", campo);
                                  mapaElem.put("LISTA_CAMBIOS", listaCambios);
                                  listaElemFacturaSuce.add(mapaElem);
                                }
                              }
                            }
                          //fin PAS20175E220200035                          
                        }
                    }// IF

                }// For recorre todos los datos

                // resultado final
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_CAB_DECLARA, listaElemCabDeclara);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_DET_DECLARA, listaElemDetDeclara);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_EQUIPAMIENTO, listaElemEquipamiento);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_DOCAUT_ASOCIADO, listaElemDocAsociado);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_DET_AUTORIZACION, listaElemDetAut);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_CAB_CERTIORIGEN, listaElemCertOrigen);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_DOCUPRECE_DUA, listaElemRegPrecedente);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_FORMB_PROVEEDOR, listaElemFormatoBDAV);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_COMPROBPAGO, listaElemFormatoBFactura);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_ITEM_FACTURA, listaElemFormatoBItemFactura);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_SERIES_ITEM, listaElemSeriesItem);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_CONVENIO_SERIE, listaElemConvenioSerie);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_FORMA_FACTU, listaElemFacturasSeries); // formaA_FActu
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_OBSERVACION, listaElemObservacion);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_PARTICIPANTE_DOC, listaElemParticipantesDUA);
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_VFOB_PROVISIONAL, listaElemFOBValorProvisionalDUA);//gmontoya Pase 35 2017
                mapaRSPTADatosModificados.put(Constantes.COD_TABLA_FACTUSUCE, listaElemFacturaSuce);//PAS20175E220200035

                if (log.isDebugEnabled()) {
                    log.debug("****Fin-obtenerDatosModificadosEnDiligencias()*****");
                    log.debug("****ouput: mapaRSPTADatosModificados:" + mapaRSPTADatosModificados);
                }
            }// IF


        return mapaRSPTADatosModificados;
    }

    /**
     * concatena el PK de las tablas guardadas en JSON para enviarlas a los JSP
     * y mostrar los datos Historios modificados en la Diligencia Datos
     * Rectificados en el Rectificacion Electronica y Regularizacion
     *
     * @autor: amancillaa
     *
     * @param codigoTabla
     * @param mapaDesClave en JSON
     * @return pkRSPTA String devuelve OK por tabla concatenado obtenido de
     *         campo DES_CLAVE obtenido en JSON de la BD
     */
    private String obtenerPKElemModificado2(EnumTablaModel enumTablaModel, Map<String, Object> mapaDesClave) {

        StringBuilder sbKeyElem = new StringBuilder();

        //obtener el listado de los campos clave de la tabla
        List<String> listaPKtabla = soporteMapeoTablasService.getListaClave(enumTablaModel);
        //llenamos la lista de datos del mapaDesClave

        for (String pk : listaPKtabla) {
            sbKeyElem.append( mapaDesClave.get(pk));
            sbKeyElem.append("-");
        }

        return sbKeyElem.substring(0,sbKeyElem.length()-1).toString(); //quitamos el ultimo "-"
    }

    private String obtenerPKElemModificado(String codigoTabla, Map<String, Object> mapaDesClave) {



        String pkRSPTA = ""; //valor de retorno

        JsonSerializer serializer  = new JsonSerializer();
        Map<String, Object> fbKeys = new HashMap<String, Object>();
        StringBuilder sbKeyElem = new StringBuilder();


        if (Constantes.COD_TABLA_CAB_DECLARA.equals(codigoTabla)) {

        } else if (Constantes.COD_TABLA_DET_DECLARA.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_SECSERIE").toString();

        } else if (Constantes.COD_TABLA_EQUIPAMIENTO.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_EQUIPAMIENTO").toString();

        } else if (Constantes.COD_TABLA_DOCAUT_ASOCIADO.equals(codigoTabla)) {

            String numSecDoc  = mapaDesClave.get("NUM_SECDOC")  != null ? mapaDesClave.get("NUM_SECDOC").toString()  : "";
            String codTipOper = mapaDesClave.get("COD_TIPOPER") != null ? mapaDesClave.get("COD_TIPOPER").toString() : "";
            sbKeyElem.append(numSecDoc);
            sbKeyElem.append("-");
            sbKeyElem.append(codTipOper);
            pkRSPTA = sbKeyElem.toString();

        } else if (Constantes.COD_TABLA_DET_AUTORIZACION.equals(codigoTabla)) {

            // pk=NUM_CORREDOC,NUM_SECDOC,COD_TIPOPER,NUM_SECSERIE
            String numSecDoc = mapaDesClave.get("NUM_SECDOC") != null ? mapaDesClave.get("NUM_SECDOC").toString() : "";
            String codTipOper = mapaDesClave.get("COD_TIPOPER") != null ? mapaDesClave.get("COD_TIPOPER").toString() : "";
            String numSecSerie = mapaDesClave.get("NUM_SECSERIE") != null ? mapaDesClave.get("NUM_SECSERIE").toString() : "";


            pkRSPTA = numSecDoc.concat(codTipOper).concat(numSecSerie);

        } else if (Constantes.COD_TABLA_CAB_CERTIORIGEN.equals(codigoTabla)) {

            // pk=NUM_CORREDOC,NUM_SECDOC,COD_TIPOPER
            String numSecDoc = mapaDesClave.get("NUM_SECDOC") != null ? mapaDesClave.get("NUM_SECDOC").toString() : "";
            String codTipOper = mapaDesClave.get("COD_TIPOPER") != null ? mapaDesClave.get("COD_TIPOPER").toString() : "";
            pkRSPTA = numSecDoc.concat(codTipOper);

        } else if (Constantes.COD_TABLA_DOCUPRECE_DUA.equals(codigoTabla)) {
            // pk=
            // NUM_CORREDOC,NUM_SECSERIE,NUM_DECLARACIONPRE,ANN_PRESENPRE,COD_ADUANAPRE,COD_REGIMENPRE,NUM_SECSERIEPRE

            // fbKeys.put("NUM_CORREDOC", mapaDesClave.get("NUM_CORREDOC") !=
            // null ? mapaDesClave.get("NUM_CORREDOC").toString():"");
            String numSecSerie = mapaDesClave.get("NUM_SECSERIE") != null ? mapaDesClave.get("NUM_SECSERIE").toString() : "";
            String numDeclaracionPre = mapaDesClave.get("NUM_DECLARACIONPRE") != null ? mapaDesClave.get("NUM_DECLARACIONPRE").toString() : "";
            String annPresenPre = mapaDesClave.get("ANN_PRESENPRE") != null ? mapaDesClave.get("ANN_PRESENPRE").toString() : "";
            String codAduanaPre = mapaDesClave.get("COD_ADUANAPRE") != null ? mapaDesClave.get("COD_ADUANAPRE").toString() : "";
            String codRegimenPre = mapaDesClave.get("COD_REGIMENPRE") != null ? mapaDesClave.get("COD_REGIMENPRE").toString() : "";
            String numSecSeriePre = mapaDesClave.get("NUM_SECSERIEPRE") != null ? mapaDesClave.get("NUM_SECSERIEPRE").toString() : "";

            pkRSPTA = numSecSerie.concat(numDeclaracionPre).concat(annPresenPre).concat(codAduanaPre).concat(codRegimenPre).concat(numSecSeriePre);

        } else if (Constantes.COD_TABLA_FORMB_PROVEEDOR.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_SECPROVE") != null ? mapaDesClave.get("NUM_SECPROVE").toString() : "";

        } else if (Constantes.COD_TABLA_COMPROBPAGO.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_SECFACT") != null ? mapaDesClave.get("NUM_SECFACT").toString() : "";

        } else if (Constantes.COD_TABLA_ITEM_FACTURA.equals(codigoTabla) || Constantes.COD_TABLA_VFOB_PROVISIONAL.equals(codigoTabla)) {//gmontoya Pase 35 2017

            pkRSPTA = mapaDesClave.get("NUM_SECITEM") != null ? mapaDesClave.get("NUM_SECITEM").toString() : "";

        } else if (Constantes.COD_TABLA_SERIES_ITEM.equals(codigoTabla)) {
            // Pk =
            fbKeys.put("NUM_CORREDOC", mapaDesClave.get("NUM_CORREDOC") != null ? mapaDesClave.get("NUM_CORREDOC").toString() : "");
            fbKeys.put("NUM_SECITEM", mapaDesClave.get("NUM_SECITEM") != null ? mapaDesClave.get("NUM_SECITEM").toString() : "");
            fbKeys.put("NUM_SECSERIE", mapaDesClave.get("NUM_SECSERIE") != null ? mapaDesClave.get("NUM_SECSERIE").toString() : "");
            pkRSPTA = serializer.serialize(fbKeys).toString();

        } else if (Constantes.COD_TABLA_CONVENIO_SERIE.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_SECSERIE").toString();

        } else if (Constantes.COD_TABLA_FORMA_FACTU.equals(codigoTabla)) {

            pkRSPTA = mapaDesClave.get("NUM_SECFACT").toString();

        } else if (Constantes.COD_TABLA_OBSERVACION.equals(codigoTabla)) {
            //{NUM_SECOBS=1, NUM_CORREDOC=597255, COD_TIPOBS=01}


            String codTipObs = mapaDesClave.get("COD_TIPOBS") != null ? mapaDesClave.get("COD_TIPOBS").toString() : "";
            String numSecItem = mapaDesClave.get("NUM_SECITEM") != null ? mapaDesClave.get("NUM_SECITEM").toString() : "";
            if("01".equals(codTipObs))
            {
              pkRSPTA = codTipObs;
            }
            else if ("03".equals(numSecItem))
            {
              pkRSPTA = codTipObs.concat(numSecItem);
            }
            else if ("06".equals(codTipObs))
            {
              pkRSPTA = codTipObs;
            }            

        } else if (Constantes.COD_TABLA_PARTICIPANTE_DOC.equals(codigoTabla)) {
          //{NUM_SECOBS=1, NUM_CORREDOC=597255, COD_TIPOBS=01}
            pkRSPTA = mapaDesClave.get("NUM_SECPARTIC").toString();
        }

        return pkRSPTA;
    }


    /**
    *
    * @param campo
    *            columna a buscar modificaciones realizadas en alguna tipo de
    *            diligencia
    * @param codtabla
    *            tabla donde se busca el campo
    * @param listaDatosModificadosEnDiligencia
    *            resultado lista de cambios
    * @return
    */
    
   private List<Map<String, Object>> obtenerListaCambiosPorCampo(
                           String campo,
                           String codtabla,
                           List<Map<String, Object>> listaDatosModificadosEnDiligencia,
                           String claveABuscar) {

       List<Map<String, Object>> listaCambiosRspta = new ArrayList<Map<String, Object>>();
       // "LISTACAMBIOS":[{"VALORH":1385370,"VALORR":1384031.869,"TIPO DILIGENCIA":"03-DESPACHO","USUARIO REGISTRO":"I900-Alex mancilla"}]

       JsonSerializer serializer = new JsonSerializer();
       for (Map<String, Object> mapaDatosJSONPorTabla : listaDatosModificadosEnDiligencia) {

           String claveJSON = mapaDatosJSONPorTabla.get("desclave").toString();


           if (mapaDatosJSONPorTabla.get("codtabla").equals(codtabla) && claveJSON.equals(claveABuscar)){  
           		//P24
        	   String strDesData = ((String) mapaDatosJSONPorTabla.get("desdata1")).concat((String) mapaDatosJSONPorTabla.get("desdata2"));
        	   String strDesAntData =((String) mapaDatosJSONPorTabla.get("desantdata1")).concat((String) mapaDatosJSONPorTabla.get("desantdata2"));
        	   Map<String, Object> mapaDesData = new HashMap<String,Object>();
        	   Map<String, Object> mapaDesAntData = new HashMap<String,Object>();
        	   if (!SunatStringUtils.isEmptyTrim(strDesData)){
        		   mapaDesData = (Map<String, Object>) serializer.deserialize(strDesData);
        	   }
        	   if (!SunatStringUtils.isEmptyTrim(strDesAntData)){
        		   mapaDesAntData = (Map<String, Object>) serializer.deserialize(strDesAntData);
        	   }	   

               String numseccambio = mapaDatosJSONPorTabla.get("numseccambio").toString();

               // busco campo en mapaDesData
               for (String campoJSON : mapaDesData.keySet()) {
            	   //amancilla PAS20155E220200035
            	   if (campo.contains(campoJSON)) {
                   //if (campoJSON.equals(campo)) {

                       String vCampoAnt = mapaDesAntData.get(campoJSON) != null ? mapaDesAntData.get(campoJSON).toString() : "---";
                       String vCampo = mapaDesData.get(campoJSON) != null ? mapaDesData.get(campoJSON).toString() : "---";

                       vCampoAnt = getCodigoDescripcionDataCatalogo(campo,vCampoAnt).toString();
                       vCampo    = getCodigoDescripcionDataCatalogo(campo,vCampo).toString();

                       //inicio gmontoya Pase 35 2017 P24
                       if(campo.toLowerCase().startsWith("fec")){
                           SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                           SimpleDateFormat sd2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                           try{
                              vCampo = sd2.format(sd.parse(vCampo));//PAS20155E220200035
                           }catch (Exception e){
                           }
                           try{
                        	   vCampoAnt = sd2.format(sd.parse(vCampoAnt));//PAS20155E220200035
                           }catch (Exception e){
                           }
                       }
                       //fin gmontoya Pase 35 2017 P24
                       String codDiligencia = (String) mapaDatosJSONPorTabla.get("codtipdiligencia");
                       String codDiligenciaDesc = catalogoAyudaService.getDescripcionDataCatalogo("356", codDiligencia);
                       String fechaDilig = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(mapaDatosJSONPorTabla.get("fecregis"));
                       String codUsuRegis = (String) mapaDatosJSONPorTabla.get("codusuregis");
                       // Colocando la descripcion del usuario
                       FiltroCatEmpleado filtro = new FiltroCatEmpleado();
                       filtro.setCodPers(codUsuRegis);
                       Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
                       CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(codUsuRegis);

                       Map<String, Object> mapaJSON = new HashMap<String, Object>();
                       mapaJSON.put("VCAMPO", vCampo);
                       mapaJSON.put("VCAMPOANT", vCampoAnt);
                       mapaJSON.put("TIPDILIG", codDiligencia.concat("-").concat(codDiligenciaDesc));
                       mapaJSON.put("FECHAHORADILIG", fechaDilig);
                       mapaJSON.put("USUARIODILIG", (catEmpleadoTemp != null) ? catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " " + catEmpleadoTemp.getNombres() : "---");
                       mapaJSON.put("ORDEN", numseccambio);
                       listaCambiosRspta.add(mapaJSON);
                   }
               }
           }
       }
       Ordenador.sortDesc(listaCambiosRspta, "ORDEN", Ordenador.DESC);
       return listaCambiosRspta;
   }
   
   
   /**
   *
   * @param campo
   *            columna a buscar modificaciones realizadas en alguna tipo de
   *            diligencia RIN 08
   * @param codtabla
   *            tabla donde se busca el campo
   * @param listaDatosModificadosEnDiligencia
   *            resultado lista de cambios
   * @return
   */
  private List<Map<String, Object>> obtenerListaCambiosPorCampoPK(
                          String campo,
                          String codtabla,
                          List<Map<String, Object>> listaDatosModificadosEnDiligencia,
                          String claveABuscar,
                          String indBorrado) {

      List<Map<String, Object>> listaCambiosRspta = new ArrayList<Map<String, Object>>();

      JsonSerializer serializer = new JsonSerializer();
      for (Map<String, Object> mapaDatosJSONPorTabla : listaDatosModificadosEnDiligencia) {

          String claveJSON = mapaDatosJSONPorTabla.get("desclave").toString();


          if (mapaDatosJSONPorTabla.get("codtabla").equals(codtabla) && claveJSON.equals(claveABuscar)) {
              Map<String, Object> mapaDesData = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desclave").toString()));
              //Map<String, Object> mapaDesAntData = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desantdata1")).concat((String) mapaDatosJSONPorTabla.get("desantdata2")));

              String numseccambio = mapaDatosJSONPorTabla.get("numseccambio").toString();

              // busco campo en mapaDesData
              for (String campoJSON : mapaDesData.keySet()) {
                  if (campoJSON.equals(campo)) {
                	  String vCampo =new String();
                	  String vCampoAnt =new String();
                	  if (SunatStringUtils.isEqualTo(indBorrado,"1")){                          
                          vCampo = "---";
                          vCampoAnt = mapaDesData.get(campo) != null ? mapaDesData.get(campo).toString() : "---";
                	  } else {
                		  vCampo = mapaDesData.get(campo) != null ? mapaDesData.get(campo).toString() : "---";
                          vCampoAnt = "---";
                	  }                	  		
                      vCampoAnt = getCodigoDescripcionDataCatalogo(campo,vCampoAnt).toString();
                      vCampo    = getCodigoDescripcionDataCatalogo(campo,vCampo).toString();

                      String codDiligencia = (String) mapaDatosJSONPorTabla.get("codtipdiligencia");
                      String codDiligenciaDesc = catalogoAyudaService.getDescripcionDataCatalogo("356", codDiligencia);
                      String fechaDilig = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(mapaDatosJSONPorTabla.get("fecregis"));
                      String codUsuRegis = (String) mapaDatosJSONPorTabla.get("codusuregis");
                      // Colocando la descripcion del usuario
                      FiltroCatEmpleado filtro = new FiltroCatEmpleado();
                      filtro.setCodPers(codUsuRegis);
                      Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);
                      CatEmpleado catEmpleadoTemp = mapCatEmpleado.get(codUsuRegis);

                      Map<String, Object> mapaJSON = new HashMap<String, Object>();
                      mapaJSON.put("VCAMPO", vCampo);
                      mapaJSON.put("VCAMPOANT", vCampoAnt);
                      mapaJSON.put("TIPDILIG", codDiligencia.concat("-").concat(codDiligenciaDesc));
                      mapaJSON.put("FECHAHORADILIG", fechaDilig);
                      mapaJSON.put("USUARIODILIG", (catEmpleadoTemp != null) ? catEmpleadoTemp.getApPate() + " " + catEmpleadoTemp.getApMate() + " " + catEmpleadoTemp.getNombres() : "---");
                      mapaJSON.put("ORDEN", numseccambio);
                      listaCambiosRspta.add(mapaJSON);
                  }
              }
          }
      }
      Ordenador.sortDesc(listaCambiosRspta, "ORDEN", Ordenador.DESC);
      return listaCambiosRspta;
  }


   /**
    * Retorne la descripcion del "nombreCampo", para el valor "valorCampo" del DATACATALOGO
    *
    * @param nombreCampo nombre del campo por el cual se seleccionara el codigo de catalogo respectivo
    * @param valorCampo valor por el cual se buscara en el datacatalogo
    *
    * @return descripcion del datacatalogo ejem 04-dni si no tiene descripcion en algun catalogo
    * devuelve solo el codigo 04
    */
   private Object getCodigoDescripcionDataCatalogo(String nombreCampo,Object valorCampo)
   {
       StringBuilder sbRspta = new StringBuilder(valorCampo.toString());
       String descCatalogo = getDescripcionDataCatalogo(nombreCampo,valorCampo);
       if (!SunatStringUtils.isEmpty(descCatalogo))
       {
           sbRspta.append("-");
           sbRspta.append(descCatalogo);

           return sbRspta.toString();
       }

       return valorCampo;
   }



   /**
    * Retorne la descripcion del "nombreCampo", para el valor "valorCampo" del DATACATALOGO
    *
    * @param nombreCampo nombre del campo por el cual se seleccionara el codigo de catalogo respectivo
    * @param valorCampo valor por el cual se buscara en el datacatalogo
    *
    * @return descripcion del datacatalogo o String vacio
    */
   private String getDescripcionDataCatalogo(String nombreCampo,Object valorCampo) {

       /*pae604
     String campoValorRDesc = "";
     for (EnumRectifica enumRectifica : EnumRectifica.values()) {
       if (nombreCampo.equalsIgnoreCase(enumRectifica.getCampo1())) {
         String codCat = enumRectifica.getCampo2();
         String codElemento = valorCampo.toString();
         campoValorRDesc = catalogoAyudaService.getDescripcionDataCatalogo(codCat, codElemento);
       }
     }
     */

       String rspta = "";
       if (!SunatStringUtils.isEmpty(nombreCampo)
               &&  (nombreCampo.startsWith("COD_")  || nombreCampo.startsWith("cod_") || nombreCampo.startsWith("IND_") )
               && valorCampo!=null
               && !SunatStringUtils.isEmpty(valorCampo.toString())
               && !"---".equals(valorCampo.toString()))
       {

           try{
               String codCatalogo = EnumRectifica.getCodCatalogoPorCodCampo(nombreCampo);
               if(!SunatStringUtils.isEmpty(codCatalogo))
               {
                 rspta = catalogoAyudaService.getDescripcionDataCatalogo(codCatalogo, valorCampo.toString());
               }
           }catch (Exception e) {
               if (log.isDebugEnabled())
              {
                 StringBuilder sb = new StringBuilder("ERROR-FORMATO al evaluar el dato");
                 sb.append("campo:");
                 sb.append(nombreCampo);
                 sb.append("valor:");
                 sb.append(valorCampo);
                log.debug(sb.toString(),e);
              }
           }
         }

     return rspta;
   }

   /* inicio ehumareda rin10 */
	@Override
	public String afectarCtaCteGarantia(Map<String, Object> mapParam)
			throws ServiceException {

		Map params = new HashMap();
		String resultado;//<RIN10 />
		BigDecimal montoAcumuladoDolares = new BigDecimal(0);

		String numCorredoc = mapParam.get("NUM_CORREDOC").toString();
		String numeroCDA = "";
		List<DeudaDocum> lstDeudaDocu = new ArrayList<DeudaDocum>();
		DeudaDocum deudaDocumImput = new DeudaDocum();
		deudaDocumImput.setNumCorredoc(new Long(numCorredoc));
		deudaDocumImput.setCodTipdeuda(Constantes.COD_TIPODEUDA_DEUDADOCUM);
		DeudaDocum deudaDocumResult = new DeudaDocum();
		lstDeudaDocu = deudaDocumDAO.selectLCGenerada(deudaDocumImput);
		if (!CollectionUtils.isEmpty(lstDeudaDocu)) {
			deudaDocumResult.setMtoDeuda(lstDeudaDocu.get(0).getMtoDeuda());
			montoAcumuladoDolares = deudaDocumResult.getMtoDeuda();
			numeroCDA = lstDeudaDocu.get(0).getNumCda();
		}
//		BigDecimal resultadoAcumulado = montoAcumuladoDolares;
		params.put("cRUC", mapParam.get("NUM_DOCIDENT_PIM")); // RUC del
																// beneficiario
		params.put("cADUANA", mapParam.get("COD_ADUANA"));
		params.put("cANO", mapParam.get("ANN_PRESEN"));
		params.put("cREGIMEN", mapParam.get("COD_REGIMEN"));
		params.put("cNUMERO", Cadena.padLeft(mapParam.get("NUM_DECLARACION")
				.toString(), 6, '0'));
		params.put("cNUMREF", mapParam.get("NUM_CTACTE"));
		params.put("cCDA", ObjectUtils.defaultIfNull(numeroCDA, null));
		
		//eruestaa rin10 3006
		params.put("cRUCAGENTE", mapParam.get("RUCAGENTE")); // RUC del agente
		params.put("cORDEN", mapParam.get("NUMORDEN"));// anho mas numero de orden �2009000001�
		params.put("nMONTOA", 
				montoAcumuladoDolares.setScale(0, BigDecimal.ROUND_HALF_UP)); //
		params.put("cMONEDAA", "D");
		params.put("nFECHA1", SunatDateUtils.getIntegerFromDate(mapParam
				.get("FEC_CONCLUSION")));
		params.put("cMODULO", mapParam.get("MODULO"));// debe de ser TA o TE.
		params.put("cTRANS", mapParam.get("TRANS").toString().substring(1,4));// 003 - Rectificaci�n antes del pago de la DUA / 001 Numeracion
		params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(mapParam
				.get("FEC_DECLARACION")));
		params.put("nFECRECTI", mapParam.get("FECRECTI"));
		params.put("cTIPOLIQ", Constantes.COD_TIPLIQ);//0010
		params.put("cTIPOEXTIN", Constantes.COD_TIPOEXTINDEUDA_MOVCTACTEGARA);//20
		// branch ingreso 2011-009 gmontoya 13
		/*<KAH-RIN10>*/
		try {	
			
			if(enableSwapperDataSource )
				swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen." + ADUANA_CENTRALIZADA));
			
			resultado = (String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
		} catch (Exception e) {
			throw new ServiceException(this, e.getMessage());
		}	
		//String resultado = (String) NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);
		/*</KAH-RIN10>*/

		return resultado;
	}

	/* fin ehumareda rin10 */
	/* eruestaa rin 10 3006 */
	public List<Map<String, Object>> obtenerDatosParticipanteByParam(Map<String, Object> mapParam)
			throws ServiceException {
		
		Map participParams = new HashMap();
		String rucAgente = "";
		//eruestaa rin10 3006
		
		participParams.put("NUM_CORREDOC", mapParam.get("NUM_CORREDOC"));
		participParams.put("COD_TIPPARTIC",  mapParam.get("COD_TIPPARTIC"));
		List<Map<String, Object>> participante = participanteDocDAO.select(participParams);
		
		return participante;
	}
	/* fin eruestaa rin 10 3006 */


   //INICIO JAZB P34
   /**
    * Obtiene la lista de Solicitud de Rectificacion
    * @param Mapa
    * @return lista de Solicitud de Rectificacion
    */
   public List<SolicitudRectifica> obtenerListaSolicitudRectificacion(Map<String, Object> params){
	   return cabSolrectiDAO.listByParameterMap(params);
   }
 //FIN JAZB

  /**
   * Sets the det sol recti dao.
   *
   * @param detSolRectiDAO
   *          the new det sol recti dao
   */
  public void setDetSolRectiDAO(DetSolRectiDAO detSolRectiDAO)
  {
    this.detSolRectiDAO = detSolRectiDAO;
  }

  /**
   * Sets the catalogo ayuda service.
   *
   * @param catalogoAyudaService
   *          the new catalogo ayuda service
   */
  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  /**
   * Sets the cat casilla formato dao.
   *
   * @param catCasillaFormatoDAO
   *          the new cat casilla formato dao
   */
  public void setCatCasillaFormatoDAO(CatCasillaFormatoDAO catCasillaFormatoDAO)
  {
    this.catCasillaFormatoDAO = catCasillaFormatoDAO;
  }

  /**
   * Sets the cab solrecti dao.
   *
   * @param cabSolrectiDAO
   *          the new cab solrecti dao
   */
  public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO)
  {

    this.cabSolrectiDAO = cabSolrectiDAO;
  }

  /**
   * Sets the recti oficio dao.
   *
   * @param rectiOficioDAO
   *          the new recti oficio dao
   */
  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {

    this.rectiOficioDAO = rectiOficioDAO;
  }

  /**
   * Sets the solicitud service.
   *
   * @param solicitudService
   *          the new solicitud service
   */
  public void setSolicitudService(SolicitudService solicitudService)
  {

    this.solicitudService = solicitudService;
  }

    public void setSoporteMapeoTablasService(SoporteMapeoTablasService soporteMapeoTablasService){

        this.soporteMapeoTablasService = soporteMapeoTablasService;
    }

    public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO)
    {

      this.participanteDocDAO = participanteDocDAO;
    }

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
	/*<KENCHO-RIN10>*/
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
	   this.fabricaDeServicios = fabricaDeServicios;
	}
	
	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
	   this.swapperDatasource = swapperDatasource;
	}
	/*</KENCHO-RIN10>*/
	  public List<Map<String, Object>> obtenerDatosRectificadosVsModificadosXEspecialista(Long numCorreDocDUA, Long numCorreDocSOL) throws ServiceException{
		  
		  // obtengo los datos rectificados

		    Map<String, Object> params2 = new HashMap<String, Object>();
		
		    JsonSerializer serializer = new JsonSerializer();
		    params2.put("numcorredoc", numCorreDocDUA);

	      //solo me trae los dato rectificados en la rectificacion de oficio
	      List<Map<String, Object>> listaDatosModificadosOficio = this.rectiOficioDAO.findRectiOficioByParams(params2);

	      List<Map<String, Object>> lstCabDeclaraTemp = new ArrayList();
	      List<Map<String, Object>> lstDetDeclaraTemp = new ArrayList();
	      
	      for (Map<String, Object> mapaDatosJSONPorTabla : listaDatosModificadosOficio)
	      {
	      	 if (mapaDatosJSONPorTabla.get("codtabla").equals(Constantes.COD_TABLA_CAB_DECLARA) )
		            {	  	     
	      		 Map<String, Object> mapaDesClave = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desclave")));
	      		 Map<String, Object> mapaDesData = new HashMap<String, Object>();
		            
	      		 Map dato = new HashMap();
	      		 
		                StringBuilder sbDesData = new StringBuilder();
		            
		 	            if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata1")))
		 	            {
		 	              sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata1"));		 	              
		 	            }
		 	            if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata2")))
		 	            {
		 	              sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata2"));
		 	            }
		 	            if (!SunatStringUtils.isEmpty(sbDesData.toString()))
		 	            {
		 	              mapaDesData = (Map<String, Object>) serializer.deserialize(sbDesData.toString());
		 	            }	 
	      		 
		 	           String codDiligencia = (String) mapaDatosJSONPorTabla.get("codtipdiligencia");
			 	          String codUsuRegis = (String) mapaDatosJSONPorTabla.get("codusuregis");
			 	          
			 	           dato.put("CLAVE",mapaDesClave);
			 	           dato.put("DATO",mapaDesData);
			 	           dato.put("COD_DILIGENCIA",codDiligencia );
			 	          dato.put("COD_ESPECIALISTA",codUsuRegis );
		 	           lstCabDeclaraTemp.add(dato);
		 	           
		            }	        	  
	      	  if (mapaDatosJSONPorTabla.get("codtabla").equals(Constantes.COD_TABLA_DET_DECLARA) )
		            {
		            	
	      		  Map<String, Object> mapaDesClave = (Map<String, Object>) serializer.deserialize(((String) mapaDatosJSONPorTabla.get("desclave")));
		        		 Map<String, Object> mapaDesData = new HashMap<String, Object>();
		 	            
		        		 Map dato = new HashMap();
		        		 
		 	                StringBuilder sbDesData = new StringBuilder();
		 	            
			 	            if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata1")))
			 	            {
			 	              sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata1"));		 	              
			 	            }
			 	            if (!SunatStringUtils.isEmpty((String) mapaDatosJSONPorTabla.get("desdata2")))
			 	            {
			 	              sbDesData.append((String) mapaDatosJSONPorTabla.get("desdata2"));
			 	            }
			 	            if (!SunatStringUtils.isEmpty(sbDesData.toString()))
			 	            {
			 	              mapaDesData = (Map<String, Object>) serializer.deserialize(sbDesData.toString());
			 	            }	 
		        		 
			 	           String codDiligencia = (String) mapaDatosJSONPorTabla.get("codtipdiligencia");
			 	          String codUsuRegis = (String) mapaDatosJSONPorTabla.get("codusuregis");
			 	          
			 	           dato.put("CLAVE",mapaDesClave);
			 	           dato.put("DATO",mapaDesData);
			 	           dato.put("COD_DILIGENCIA",codDiligencia );
			 	          dato.put("COD_ESPECIALISTA",codUsuRegis );
			 	          lstDetDeclaraTemp.add(dato);
			 	             
		            }
	      }
	      
	      List<Map<String, Object>> lsRSPTA = new ArrayList();
	      Map mapRSPTA = new HashMap();
	      
	      String campo = "";
	      Object valor = "";
	      String especialista = "";        
	      String diligencia = "";
	          
	      int contar = 0;
	      String plantilla = "EL CAMPO {0}, CON VALOR {1} TRANSMITIDO FUE RECTIFICADO POR EL FUNCIONARIO ADUANERO {2} EN LA {3}.";
	      	    	  
	    	// obtengo los datos rectificados
	  	    Map<String, Object> params1 = new HashMap<String, Object>();	    
	  	    params1.put("NUM_CORREDOC", numCorreDocSOL);	 

	  	    List<Map<String, Object>> lstdatosRectificados = detSolRectiDAO.findDatosRectificadosByMap(params1);	  
	    	  
	  	    
		  	  if (!CollectionUtils.isEmpty(lstdatosRectificados) && !CollectionUtils.isEmpty(listaDatosModificadosOficio))
		      {
		        for (Map<String, Object> mapaItemRectifica : lstdatosRectificados)
		        {
		      	  if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_CAB_DECLARA) 
		      			  && (mapaItemRectifica.get("DES_DATA") != null && mapaItemRectifica.get("DES_DATA").toString().trim().length() > 0))
		      		  		      		  
		              
		            {
		      		   Object objetoJsonPkCabDeclaraR = mapaItemRectifica.get("DES_CLAVE");	               
		               Map<String, Object> mapPkCabDeclaraR = (Map<String, Object>) serializer.deserialize(objetoJsonPkCabDeclaraR);
		                
		               for(Map<String, Object> declara: lstCabDeclaraTemp){
		            	   Object campoValorR = declara.get("CLAVE");
		            	   if(Utilidades.equalsByClass(campoValorR, mapPkCabDeclaraR)){	
		            		  
		            		   Object objetoJsonCabDeclara = mapaItemRectifica.get("DES_DATA");	               
		    	               Map<String, Object> datosRecti = (Map<String, Object>) serializer.deserialize(objetoJsonCabDeclara);
		    	               	            	
		            		   Map datosOficio = (HashMap)declara.get("DATO");
		            		   
		            		   datosOficio = soporteComparadorService.validarMapEntidad(datosOficio,"CAB_DECLARA");
		            		   datosRecti = soporteComparadorService.validarMapEntidad(datosRecti,"CAB_DECLARA");
		            		   	            		   		            		   
		            		   String codDiligencia = declara.get("COD_DILIGENCIA").toString();
		            		   String codUsuRegis = declara.get("COD_ESPECIALISTA").toString();
		            		  	            		   
		            		   if(!CollectionUtils.isEmpty(datosRecti)){
//		            			   if(codUsuRegis.isEmpty()){
//		            				   contar++;
//				            		   mapRSPTA = new HashMap();
//				            		   mapRSPTA.put("nro",contar);			            		   
//				            		   mapRSPTA.put("mensaje","No tiene COD_ESPECIALISTA");
//				            		   lsRSPTA.add(mapRSPTA); 
//		            			   }else{// se agreba por errores en el log por null
				            			   try{
		            			   especialista = getFuncionarioByDiligencia(codUsuRegis);        
				            				   
				            				 if(especialista.isEmpty()){
				            					 especialista =codUsuRegis; 
				            				 }
				            				   
				            			   }catch(Exception e){
				            				   especialista =codUsuRegis;
				            				   e.getStackTrace();
				            				
				            			   }	 
		            			  // }
		            			 
			            		   diligencia = tipoDiligencia(codDiligencia); 
			            		   for (Entry<String, Object> entradaActual : datosRecti.entrySet())
			                       {
			            			   	  campo = entradaActual.getKey();
				                          valor = entradaActual.getValue();
				                          		                          
				                          String otrovalor = datosOficio.get(campo)!=null?datosOficio.get(campo).toString():"";
				                          if(!"".equals(otrovalor)){
			            			    	  
			            			    	  Object[] argumentos = new Object[] { campo,valor,especialista,diligencia};
						            		   String mensaje = formatMessage(plantilla.toString(), argumentos);
						            		   contar++;
						            		   mapRSPTA = new HashMap();
						            		   mapRSPTA.put("nro",contar);			            		   
						            		   mapRSPTA.put("mensaje",mensaje);
						            		   lsRSPTA.add(mapRSPTA);  
			            			      }
				            		   
			                       }  
		            		   }
		            		   	            		   	            		  	 		 	          	            		  	            		  	            		  
		            	   }
		               }	              	              
		            }
		      	  
		      	  if (mapaItemRectifica.get("COD_TABLA").equals(Constantes.COD_TABLA_DET_DECLARA) 
		      			&& (mapaItemRectifica.get("DES_DATA") != null && mapaItemRectifica.get("DES_DATA").toString().trim().length() > 0))
		            {
		            	
		      		  Object objetoJsonPkCabDeclaraR = mapaItemRectifica.get("DES_CLAVE");	               
		               Map<String, Object> mapPkCabDeclaraR = (Map<String, Object>) serializer.deserialize(objetoJsonPkCabDeclaraR);
		                
		               for(Map<String, Object> detdeclara: lstDetDeclaraTemp){
		            	   Object campoValorR = detdeclara.get("CLAVE");
		            	   if(Utilidades.equalsByClass(campoValorR, mapPkCabDeclaraR)){	 
		            		   
		            	
		            		   
		            		   Object objetoJsonCabDeclara = mapaItemRectifica.get("DES_DATA");	               
		    	               Map<String, Object> datosRecti = (Map<String, Object>) serializer.deserialize(objetoJsonCabDeclara);
		    	               	            	
		            		   Map datosOficio = (HashMap)detdeclara.get("DATO");
		            		   
		            		   datosOficio = soporteComparadorService.validarMapEntidad(datosOficio,"DET_DECLARA");
		            		   datosRecti = soporteComparadorService.validarMapEntidad(datosRecti,"DET_DECLARA");
		            		  
		            		   String codDiligencia = detdeclara.get("COD_DILIGENCIA").toString();
		            		   String codUsuRegis = detdeclara.get("COD_ESPECIALISTA").toString();
		            		  
		            		   
		            		   if(!CollectionUtils.isEmpty(datosRecti)){
		            			   especialista = getFuncionarioByDiligencia(codUsuRegis);        
			            		   diligencia = tipoDiligencia(codDiligencia); 
		            		   for (Entry<String, Object> entradaActual : datosRecti.entrySet())
			                       {
		            			   
		            			   	  campo = entradaActual.getKey();
			                          valor = entradaActual.getValue();
			                          		                          
			                          String otrovalor = datosOficio.get(campo)!=null?datosOficio.get(campo).toString():"";
		            			      if(!"".equals(otrovalor)){
		            			    	  
		            			    	  Object[] argumentos = new Object[] { campo,valor,especialista, diligencia};
					            		   String mensaje = formatMessage(plantilla.toString(), argumentos);
					            		   contar++;
					            		   mapRSPTA = new HashMap();
					            		   mapRSPTA.put("nro",contar);			            		   
					            		   mapRSPTA.put("mensaje",mensaje);
					            		   lsRSPTA.add(mapRSPTA);  
		            			      }		            			     		                          			                          
			                       } 
		            		   } 
		            	   }
		               }	         
		            }
		        }
		      }
	    	  

	    	  

		    return lsRSPTA;
		  
	  }

	/* inicio ehumareda rin10 */
	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}
	/* fin ehumareda rin10 */
	 //INICIO P24-bug 24608,24609 ,24610 
	  public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO)
	  {
	    this.cabDiligenciaDAO = cabDiligenciaDAO;
	  }

}
