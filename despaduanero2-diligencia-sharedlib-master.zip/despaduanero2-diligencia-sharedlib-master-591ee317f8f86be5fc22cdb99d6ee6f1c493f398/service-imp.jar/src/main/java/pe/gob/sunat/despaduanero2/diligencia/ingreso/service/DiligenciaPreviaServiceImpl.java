package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.text.SimpleDateFormat;//P24
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;//P24

import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;//P24
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;//P24
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;//P24
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;//P24
//import pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;//P24
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

/**
 * <p>Title: DiligenciaPreviaServiceImpl</p>
 * <p>Description: Clase de Servicio para la Diligencia Previa</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public class DiligenciaPreviaServiceImpl implements DiligenciaPreviaService {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	private DeclaracionService declaracionService;
	private AsignacionService asignacionService;
	private SerieService serieService;
	private DocumentoOAManifiestoService documentoOAManifiestoService;
	private DiligenciaService diligenciaService;
	private CabDiligenciaDAO cabDiligenciaDAO;//P24
	private EspeDocuDAO espeDocuDAO;//P24
	private FabricaDeServicios fabricaDeServicios;//P24
	
	/**
	 * Valida la declaracion para el proceso 
	 * de registro de diligencia previa
	 * @param aduanaDeclaracion Aduana de la declaracion
	 * @param anioDeclaracion A�o de la declaracion
	 * @param regimenDeclaracion R�gimen de la declaracion
	 * @param numeroDeclaracion N�mero de la declaracion
	 * @param usuario Usuario logeado
	 * @return Error de validaci�n
	 * @author gbecerrav
	 */
	@Override
	public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, Integer anioDeclaracion, 
			String regimenDeclaracion, Integer numeroDeclaracion, UsuarioBean usuario) throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - validarDeclaracion");
		}
		
		ObjectResponseUtil rpta = new ObjectResponseUtil();
		
		//Que la declaraci�n exista
		DUA dua = this.declaracionService.buscarDatosGeneralesDUAByClaveDeNegocio(aduanaDeclaracion, anioDeclaracion, regimenDeclaracion, numeroDeclaracion);
		if(dua == null){
			rpta.addMensaje("La Declaraci�n no ha sido numerada en el SDA.", "Verifique", true);
			return rpta;
		}
//		<EHR>  p 14 el mensaje se  adapta  los mensajes de esta clase ; obtenemos nuevamente la declaracion el en formato hasMap
			Map<String, Object> paramsDua = new HashMap<String, Object>();
		  	paramsDua.put("NUM_DECLARACION", dua.getNumdocumento().toString());
		    paramsDua.put("COD_ADUANA", dua.getCodaduanaorden().toString());
		    paramsDua.put("ANN_PRESEN", dua.getAnnpresen().toString());
		    paramsDua.put("COD_REGIMEN", dua.getCodregimen().toString());
		    paramsDua.put("EN_PROCESO", "0");
	      Map<String, Object> declaracionMap = this.declaracionService.obtenerDeclaracion(paramsDua);
		
	      if(declaracionMap!=null){
	    	  String estadoDua = declaracionMap.get("COD_ESTDUA").toString();
	          if(estadoDua.equals("15")){
		    	  rpta.addMensaje("Se requiere registrar la respuesta a la notificaci�n ", "Verifique", true);
					return rpta;
			  /*inicio PAS20145E220000427*/
		      }else if (Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE.equals(estadoDua)){
		    	  rpta.addMensaje("La mercanc�a de la declaraci�n se encuentra dispuesta totalmente","Verifique", true);
		    	  return rpta;
		      //}else if (Constantes.ESTADO_MERCANCIA_DISPUESTA_PARCIALMENTE.equals(estadoDua)){
		      //  rpta.addMensaje(declaracionService.tieneMercanciaDispuestaParcial(dua.getNumcorredoc()),"Verifique", true);
		      }else {
		          String mensajeBloqueo = this.declaracionService.tieneMercanciaDispuestaParcial(Long.valueOf(declaracionMap.get("NUM_CORREDOC").toString()));
		          if( !SunatStringUtils.isEmpty(mensajeBloqueo) ) rpta.addMensaje(mensajeBloqueo,"ALERTA",false);
		      }
	          /*fin PAS20145E220000427*/
		      
		      String indAbandonoVoluntario = declaracionMap.get("COD_INDICADOR3").toString();
				if (!indAbandonoVoluntario.equals("00")){	
					rpta.addMensaje("La Declaracion se encuentra en Abandono voluntario", "Verifique", true);
					return rpta;
				}
	      }
	
//		</EHR>
		//Que la declaraci�n corresponda a la modalidad anticipado
		if(!ConstantesDataCatalogo.MODA_ANTICIPADA.equals(dua.getCodmodalidad())){
			rpta.addMensaje("Declaraci�n no corresponde a la modalidad anticipado", "Verifique", true);
			return rpta;
		}
		
		//Que la declaraci�n tenga canal Rojo
		if(!ConstantesDataCatalogo.COD_CANAL_ROJO.equals(dua.getCodCanal())){
			rpta.addMensaje("Declaraci�n no corresponde a canal rojo", "Verifique", true);
			return rpta;
		}
		
		// INICIO P24
//		//Que no tenga diligencia previa anticipado rojo registrada
//		Diligencia diligencia = new Diligencia();
//		diligencia.setNumeroCorrelativo(dua.getNumcorredoc());
//		diligencia.setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_PREVIA);
//		if(this.diligenciaService.hasDiligencia(diligencia)){
//			rpta.setRespuesta(false);
//			rpta.addMensaje("Ya registr� diligencia previa", "Verifique", true);
//			return rpta;
//		}
		
		//P24//Que no tenga diligencia previa anticipado rojo registrada
		String mensaje = new String();
		Boolean regOK = false;
		Map<String, Object> mapBusq = new HashMap<String, Object>();
		mapBusq.put("NUM_CORREDOC",dua.getNumcorredoc());
		mapBusq.put("COD_TIPDILIGENCIA", new String[]{ConstantesDataCatalogo.COD_DILIG_PREVIA.toString()});

		try{		   
			Map<String,Object> ultimaActualizacion =  cabDiligenciaDAO.findUltimaDiligencia(mapBusq);
			rpta.addDato("regOK",regOK);
			if(ultimaActualizacion!=null){
				// Que el actor sea el mismo funcionario aduanero que registr� la diligencia de la DUA
				Map<String, Object> mapParamsAsig = new HashMap<String, Object>();
				mapParamsAsig.put("NUM_CORREDOC", dua.getNumcorredoc());
				mapParamsAsig.put("COD_ESTREV", "01"); 
				mapParamsAsig.put("COD_GRUPO", Constantes.GRUPO_DILIGENCIA_PREVIA); 
				Map<String, Object> mapEspeDespachoAsig = espeDocuDAO.findbyDocEstRev(mapParamsAsig);

				if (CollectionUtils.isEmpty(mapEspeDespachoAsig) || (mapEspeDespachoAsig != null && !mapEspeDespachoAsig.get("cod_funcionario").equals(
						usuario.getNroRegistro().trim()))){

					//mensaje= "Diligencia Previa no fue registrada por usted.";
					rpta.addMensaje("Diligencia Previa no fue registrada por usted.","Verifique", true);
					return rpta;
				}else{		    	
					Boolean seGrabaDiligencia = false;
					Integer numCorredocSol = Integer.parseInt(ultimaActualizacion.get("NUM_CORREDOC_SOL").toString());

					if(numCorredocSol<1){		 
						mapBusq.clear();
						mapBusq.put("NUM_CORREDOC",dua.getNumcorredoc());
						mapBusq.put("COD_TIPDILIGENCIA_IN", new String[]{Constantes.COD_TIPO_DILIGENCIA_CONCLUSION,Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION,Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO}); //Rectificacion electronica o rectificacion de oficio, conclusion
						List<Map<String,Object>> rectificacionesMap = cabDiligenciaDAO.select(mapBusq); 
						seGrabaDiligencia = true;
						if(!rectificacionesMap.isEmpty()){
							Date fechaDiligPrevia = SunatDateUtils.getDefaultDate();
							ValidaDiligenciaService validaDiligenciaService = fabricaDeServicios.getService("diligencia.ingreso.validaDiligenciaService");
							mapBusq.put("COD_TIPDILIGENCIA", new String[] { ConstantesDataCatalogo.COD_DILIG_PREVIA});
						    Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(mapBusq,null);
						    if(!CollectionUtils.isEmpty(mapUltimaDiligencia)){
						    	fechaDiligPrevia =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(mapUltimaDiligencia.get("FEC_REGIS").toString());
						    } 						    	
							for(Map<String,Object> rectificacion:rectificacionesMap){	
								Date fechaDiligencia = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(rectificacion.get("FEC_REGIS").toString());
								if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaDiligencia, fechaDiligPrevia, "COMPARA_TODO")){
									seGrabaDiligencia = false;
									//mensaje = "No puede modifcar la Diligencia Previa por existir una diligencia Posterior o en Proceso";
									rpta.addMensaje("No puede modificar la Diligencia Previa por existir una diligencia Posterior o en Proceso","Verifique", true);
									break;
								}
							}						 						 					
						}
						if(seGrabaDiligencia){					  
							ultimaActualizacion.put("FEC_DILIGENCIA", new FechaBean().getTimestamp());
							ultimaActualizacion.put("FEC_MODIFICACION", new FechaBean().getTimestamp());
							ultimaActualizacion.put("NUM_CORREDOC_SOL", numCorredocSol+1);
							regOK=true;					  
							//rpta.put("CAB_DILIGENCIA", ultimaActualizacion);
						}

					}else{		 
						//mensaje = "Diligencia Previa fue modificada anteriormente, s�lo puede modificarse un maximo de 1 vez.";
						rpta.addMensaje("Diligencia Previa fue modificada anteriormente, s�lo puede modificarse un maximo de 1 vez.","Verifique", true);
			rpta.setRespuesta(false);
			return rpta;
		}
				}
				rpta.addDato("MENSAJE",mensaje);
				rpta.addDato("regOK",regOK);
				Declaracion declaracion = new Declaracion();
				declaracion.setDua(dua);
				
				rpta.setRespuesta(true);
				rpta.addDato("declaracion", declaracion);
				return rpta;
			} 

			
		}catch(Exception e){
			log.error("*** ERROR ***", e);  
			throw new ServiceException(e, e.getMessage());
		}// FIN P24
		
		//Que no tenga diligencia de despacho
		Map<String, Object> paramsDiligenciaDespacho = new HashMap<String, Object>();
		paramsDiligenciaDespacho.put("numeroCorrelativo", dua.getNumcorredoc());
		paramsDiligenciaDespacho.put("listaTipoDiligencia", new String[] {ConstantesDataCatalogo.COD_DILIG_REV, ConstantesDataCatalogo.COD_DILIG_REV_DOC, ConstantesDataCatalogo.COD_DILIG_REC_FIS});
		if(this.diligenciaService.hasDiligencia(paramsDiligenciaDespacho)){
			rpta.setRespuesta(false);
			rpta.addMensaje("Dua, ha inicializado la revisi�n de la diligencia de despacho.", "Verifique", true);
			return rpta;
		}
				
		//Que la Declaraci�n est� asignado al funcionario aduanero autenticado
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", dua.getNumcorredoc());
		params.put("cod_estrev", ConstantesDataCatalogo.COD_EST_ASIGNACION_DUA_ASIGNADO);
		params.put("cod_grupo", ConstantesDataCatalogo.GRUPO_DILIGENCIA_PREVIA);
		String codigoFuncionario = this.asignacionService.obtenerCodigoUltimoEspecialistaAsignado(params);
		
		if(!codigoFuncionario.equalsIgnoreCase(usuario.getNroRegistro().trim())){
			//rpta.addMensaje("El Usuario no tiene asignada la Declaraci�n", "Verifique", true);
			rpta.addMensaje("Declaraci�n no se encuentra asignada para Diligencia Previa", "Verifique", true);
			return rpta;
		}
		
		/*//Que la declaraci�n no tenga nota de tarja
		params.clear();
		params.put("numeroManifiesto", StringUtils.leftPad(dua.getManifiesto().getNummanif(), 6, '0'));
		params.put("anioManifiesto", dua.getManifiesto().getAnnmanif() != null ? Integer.parseInt(dua.getManifiesto().getAnnmanif()) : null);
		params.put("codigoAduana", dua.getManifiesto().getCodaduamanif());
		params.put("tipoManifiesto", dua.getManifiesto().getCodtipomanif());
		params.put("viaTransporte", dua.getManifiesto().getCodmodtransp());
		
		//Obtenemos los documentos de transporte asociados a la declaraci�n
		//params.put("listaDetalleDocTransporte", this.serieService.obtenerListaNumeroDocTransporteByDeclaracion(dua.getNumcorredoc()));
		//params.put("listaNumeroDocTransporte", this.serieService.obtenerListaNumeroDocTransporteByDeclaracion(dua.getNumcorredoc()));
		params.put("estado", ConstantesManifiesto.DOCUMENTO_TRANSPORTE_ESTADO_ANULADO);
		params.put("hijoAndMaster", true);
		params.put("tipoEnvio", ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);
		params.put("indicadorEliminacion", Constantes.IND_NO_ELIMINADO);
		params.put("rownum", "rownum");
		int cantidadNotaTarja = this.documentoOAManifiestoService.obtenerCantidadOperacionesAsociadaDocumentoTransporte(params);
		if(cantidadNotaTarja > 0){
			rpta.addMensaje("Declaraci�n no corresponde a la Diligencia Previa", "Verifique", true);
			return rpta;
		}*/
		
		//si todo ok retorna true y el objeto declaracion
		Declaracion declaracion = new Declaracion();
		declaracion.setDua(dua);
		
		rpta.setRespuesta(true);
		rpta.addDato("declaracion", declaracion);
		rpta.addDato("impFrecuente", declaracionMap.get("impFrecuente")); //p24-parte II-Se adiciono en pase PAS20165E220200099 
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - validarDeclaracion");
		}
		
		return rpta;
	}

	/**
	 * Adiciona datos a la declaracion
	 * @param declaracion Declaracion
	 * @return
	 * @author gbecerrav
	 */
	@Override
	public void adicionarDatosDeclaracion(Declaracion declaracion)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - adicionarDatosDeclaracion");
		}
		
		this.declaracionService.adicionarDatosDeclaracionParaDiligenciaPrevia(declaracion);
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - adicionarDatosDeclaracion");
		}
	}
	
	/**
	 * Actualiza el estado de la declaracion a revision
	 * registra la diligencia previa en revision sino existe 
	 * @param declaracion Declaracion
	 * @param usuario Usuario logeado
	 * @return
	 * @author gbecerrav
	 */
	@Override
	public void actualizarDeclaracionEnRevision(Declaracion declaracion, UsuarioBean usuario)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - actualizarDeclaracionEnRevision");
		}
		
		if(!ConstantesDataCatalogo.COD_DUA_ENREVISION.equals(declaracion.getDua().getCodEstdua())){
			try{
				//Se registra la diligencia por revisi�n 
				Diligencia diligencia = new Diligencia();
				diligencia.setNumeroCorrelativo(declaracion.getDua().getNumcorredoc());
				diligencia.setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV_PREVIA); /////////////////?????????????????
				diligencia.setNumeroCorrelativoSolicitud(0L);
				diligencia.setCodigoFuncionario(usuario.getNroRegistro().trim());
				diligencia.setFechaDiligencia(new Date());
				this.diligenciaService.insertarDiligencia(diligencia);
			}catch(Exception e){ /////////////////?????????????????
				log.error(e);
			}
		}
		
		//Se realiza la actualizaci�n del estado de la dua a revision
		DUA dua = new DUA();
		if(ConstantesDataCatalogo.COD_DUA_ENPROC_DILIG.equals(declaracion.getDua().getCodEstdua())){ //P24-PAS20165E220200099
			dua.setCodEstdua(ConstantesDataCatalogo.COD_DUA_ENPROC_DILIG);
		}
		else{
			dua.setCodEstdua(ConstantesDataCatalogo.COD_DUA_ENREVISION); 
		}
		dua.setNumcorredoc(declaracion.getDua().getNumcorredoc());
		declaracion.getDua().setCodEstdua(dua.getCodEstdua());
		this.declaracionService.actualizarDUAByPrimaryKey(dua);
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - actualizarDeclaracionEnRevision");
		}
	}

	/**
	 * Actualiza el estado de la declaracion a proceso
	 * @param declaracion Declaracion
	 * @return
	 * @author gbecerrav
	 */
	@Override
	public void actualizarDeclaracionEnProceso(Declaracion declaracion)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - actualizarDeclaracionEnProceso");
		}
		
		//Se realiza la actualizaci�n del estado de la dua a proceso
		DUA dua = new DUA();
		dua.setCodEstdua(ConstantesDataCatalogo.COD_DUA_ENPROC_DILIG);
		dua.setNumcorredoc(declaracion.getDua().getNumcorredoc());
		declaracion.getDua().setCodEstdua(dua.getCodEstdua());
		this.declaracionService.actualizarDUAByPrimaryKey(dua);
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - actualizarDeclaracionEnProceso");
		}
	}
	
	/**
	 * Registra una comunicacion
	 * @param comunicacion Comunicacion 
	 * @param declaracion Declaracion
	 * @param usuario Usuario logeado
	 * @return
	 * @author gbecerrav
	 */
	@Override
	public void grabarComunicacion(Comunicacion comunicacion,
			Declaracion declaracion, UsuarioBean usuario)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - grabarComunicacion");
		}
		//Registro de comunicacion
		this.diligenciaService.insertarComunicacion(comunicacion);
		
		//Notificacion
		if(Constantes.COD_COMUNICACION_EXTERNA.equals(comunicacion.getCodigoNota())){
			//Importador
			diligenciaService.notificarObservacion(comunicacion.getDescripcionNota(),
					declaracion.getDua().getCodaduanaorden(),
					declaracion.getDua().getAnnpresen().toString(),
					declaracion.getDua().getCodregimen(),
					declaracion.getDua().getNumdocumento(),
					usuario.getNombreCompleto(),
					new String[] {declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()},
					Constantes.COD_PL_NOTI_OBS_REC_FISICO,
					Constantes.CODIGO_NOTIFICACION,
					Constantes.CONTRIBUYENTE,
					"");
			
			//Agente Aduanas
			diligenciaService.notificarObservacion(comunicacion.getDescripcionNota(),
					declaracion.getDua().getCodaduanaorden(),
					declaracion.getDua().getAnnpresen().toString(),
					declaracion.getDua().getCodregimen(),
					declaracion.getDua().getNumdocumento(),
					usuario.getNombreCompleto(),
					new String[] {declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad()},
					Constantes.COD_PL_NOTI_OBS_REC_FISICO,
					Constantes.CODIGO_NOTIFICACION,
					Constantes.CONTRIBUYENTE,
					"");
		}
		if (log.isDebugEnabled()) {
			log.debug("Fin - grabarComunicacion");
		}
	}
	
	/**
	 * Registra una diligencia previa
	 * @param diligencia Diligencia Previa
	 * @param declaracion Declaracion
	 * @return
	 * @author gbecerrav ,jreynoso pase563
	 */
	@Override
	public void grabarDiligenciaPrevia(Diligencia diligencia, Declaracion declaracion) throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - grabarDiligenciaPrevia");
		}
		//Se registra la diligencia previa - Graba el resultado de la Diligencia previa
		this.diligenciaService.insertarDiligencia(diligencia);
		
		//String mensaje ="Se ha grabado satisfactoriamente la diligencia previa";
		
		//Cambia el estado de la declaraci�n a En Revisi�n
		DUA dua = new DUA();
		//dua.setCodEstdua(ConstantesDataCatalogo.COD_DUA_ENREVISION);
		dua.setCodEstdua(Constantes.ESTADO_DECLARACION_RECEPCIONADO);//P24
		dua.setNumcorredoc(diligencia.getNumeroCorrelativo());
		this.declaracionService.actualizarDUAByPrimaryKey(dua);
		
		//Retira la Declaraci�n de la bandeja de pendientes del funcionario
		Map<String, Object> paramsAsignacion = new HashMap<String, Object>();
		paramsAsignacion.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_CON_REGISTRO_DE_LA_DILIGENCIA);
		paramsAsignacion.put("num_corredoc", diligencia.getNumeroCorrelativo());
		paramsAsignacion.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
		paramsAsignacion.put("fec_termrev", "fec_termrev");
		paramsAsignacion.put("cod_funcionario", diligencia.getCodigoFuncionario().trim());
		this.asignacionService.actualizarEstadoRevision(paramsAsignacion);
		
		//inicio - jreynoso pase 563 inclusion del anfora RIN12
		declaracion.setNumeroDeclaracion(Long.valueOf(declaracion.getDua().getNumdocumento().toString()));
		//hosoriov 179
		this.asignacionService.registrarDeclaracionAnfora(declaracion, "01");
		//fin -jreynoso
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - grabarDiligenciaPrevia");
		}
	}
	
	
	 //PAS20155E220000089 se factoriza la l�gica de obtener el flag de Indicador Frecuente
	 public boolean isImportadorFrecuente(Long numCorreDoc){
		List<IndicadorDeclaracionDescripcion> listaIndicadorDuaDesc = this.declaracionService.obtenerIndicadoresDuaAll(numCorreDoc);
			  if (listaIndicadorDuaDesc != null) {
					for (IndicadorDeclaracionDescripcion indicadorDuaDesc : listaIndicadorDuaDesc) {
						  if(indicadorDuaDesc.getCodigoIndicador().equals("05")){//es decir cuenta con el indicador 05 Importador Frecuente
							  return true;
						  }
					}
			  }
		return false;
	 }
	
	/**
	 * @return the declaracionService
	 */
	public DeclaracionService getDeclaracionService() {
		return declaracionService;
	}

	/**
	 * @param declaracionService the declaracionService to set
	 */
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	/**
	 * @return the asignacionService
	 */
	public AsignacionService getAsignacionService() {
		return asignacionService;
	}

	/**
	 * @param asignacionService the asignacionService to set
	 */
	public void setAsignacionService(AsignacionService asignacionService) {
		this.asignacionService = asignacionService;
	}

	/**
	 * @return the serieService
	 */
	public SerieService getSerieService() {
		return serieService;
	}

	/**
	 * @param serieService the serieService to set
	 */
	public void setSerieService(SerieService serieService) {
		this.serieService = serieService;
	}

	/**
	 * @return the documentoOAManifiestoService
	 */
	public DocumentoOAManifiestoService getDocumentoOAManifiestoService() {
		return documentoOAManifiestoService;
	}

	/**
	 * @param documentoOAManifiestoService the documentoOAManifiestoService to set
	 */
	public void setDocumentoOAManifiestoService(
			DocumentoOAManifiestoService documentoOAManifiestoService) {
		this.documentoOAManifiestoService = documentoOAManifiestoService;
	}

	/**
	 * @return the diligenciaService
	 */
	public DiligenciaService getDiligenciaService() {
		return diligenciaService;
	}

	/**
	 * @param diligenciaService the diligenciaService to set
	 */
	public void setDiligenciaService(DiligenciaService diligenciaService) {
		this.diligenciaService = diligenciaService;
	}
	//P24
		public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO) {
		this.cabDiligenciaDAO = cabDiligenciaDAO;
	}

	public void setEspeDocuDAO(EspeDocuDAO espeDocuDAO) {
		this.espeDocuDAO = espeDocuDAO;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	//P24
	
}
