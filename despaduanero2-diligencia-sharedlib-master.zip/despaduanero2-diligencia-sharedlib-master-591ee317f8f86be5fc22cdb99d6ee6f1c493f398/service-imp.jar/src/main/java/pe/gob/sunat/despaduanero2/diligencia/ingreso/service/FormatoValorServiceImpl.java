package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

// INICIO P34
import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;

import org.apache.commons.io.FileUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ModelFactory; //PAS20165E220200138
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract; //PAS20165E220200138
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima; //PAS20165E220200138
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioArchivoBean;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioArchivoDAO;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.framework.spring.util.compression.ZipUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
// FIN P34
import pe.gob.sunat.despaduanero2.ayudas.model.Nandina;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoDAO;
import pe.gob.sunat.despaduanero2.declaracion.recepcion.util.ConstantesDeclaracion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service.PlantillaFactory;  //PAS20165E220200138
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ReferenciaDudaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;



/**
 * The Class FormatoValorServiceImpl.
 */
@SuppressWarnings({ "rawtypes","unchecked" })
public class FormatoValorServiceImpl implements FormatoValorService
{

  protected final Log              log = LogFactory.getLog(getClass());

  private ItemFacturaDAO           itemFacturaDAO;

  private FormBProveedorDAO        formBProveedorDAO;

  private ComprobPagoDAO           comprobPagoDAO;

  private ParticipanteDocDAO       participanteDAO;

  private CondicionTransaDAO       condicionTransaDAO;

  private FormBMontoDAO            formBMontoDAO;

  private SeriesItemDAO            seriesItemDAO;

  private ReferenciaDudaDAO        referenciaDudaDAO;

  private FormaFactuDAO            formAFactuDAO;

  private CatalogoAyudaService     catalogoAyudaService;


  private SoporteService           soporteService;

  private FabricaDeServicios       fabricaDeServicios;

  private HotSwappableTargetSource swapperDatasource;

  private VehiCeticoDAO            vehiCeticoDAO;

  private CabAdiImpoConsuDAO       cabAdiImpoConsuDAO;

  private FactuSuceDAO             factuSuceDAO;

  private FormBItemDescriDAO       formBItemDescriDAO;

  private MontoGastoDAO            montoGastoDAO;
  private ObservacionDAO           observacionDAO;
  
  //inicio CU 14.15
  private VFOBProvisionalDAO      vFOBProvisionalDAO;
  //fin CU 14.15

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFVItem(Map<String, String> PkSerie) throws ServiceException
  {
    List<Map<String, Object>> listaItemFactura = null;
	ObservacionDAO observacion = fabricaDeServicios.getService("observacionDAO");

    try
    {
      listaItemFactura = itemFacturaDAO.joinSeriesItemVFobProvisionalFindBySerie(PkSerie);

      if (listaItemFactura != null)
      {
        for (int i = 0; i < listaItemFactura.size(); i++)
        {
          if (listaItemFactura.get(i).get("num_partida") != null)
          {
            Nandina nandina = catalogoAyudaService.getPartidaObject(listaItemFactura
                .get(i)
                .get("num_partida")
                .toString());
            listaItemFactura.get(i).put("des_partida", nandina != null ? nandina.getDescripcion() : "");
          }
          //Inicio cambios 12/06/2014 listado de observaciones AREY
          //Inicio PAS20155E220200089 P24	
          //5.4 INCOTERM Ciudad Versi�n
          if (listaItemFactura.get(i).get("dir_lugartrans")!=null  && !listaItemFactura.get(i).get("dir_lugartrans").toString().trim().isEmpty()){        	  
    		  //Inicio-PAS20165E220200138
        	  String ciudad="";
        	  if (listaItemFactura.get(i).get("dir_lugartrans").toString().indexOf("-")!=-1)
        		  ciudad=SunatStringUtils.substring(listaItemFactura.get(i).get("dir_lugartrans").toString(),0,listaItemFactura.get(i).get("dir_lugartrans").toString().indexOf("-"));
        	  else
        		  ciudad=listaItemFactura.get(i).get("dir_lugartrans").toString();
    		  //Fin-PAS20165E220200138        	  
        	  String codigoIcoterm=SunatStringUtils.substring(listaItemFactura.get(i).get("dir_lugartrans").toString(),listaItemFactura.get(i).get("dir_lugartrans").toString().indexOf("-") + 1);
        	  String descripVersionIcoterm= catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDeclaracion.CATALOGO_ICOTERM,codigoIcoterm);
        	  String versionIncoterm =codigoIcoterm+": INCOTERM " + descripVersionIcoterm;
        	  listaItemFactura.get(i).put("versionICOTERM", versionIncoterm);
        	  //Paul - P24
        	  ParticipanteDocDAO participanteDocDAO = fabricaDeServicios.getService("despaduanero2.participanteDocDAO");
        		
        		Map<String, String> PkDocu = new HashMap<String,String>();
        		PkDocu.put("NUM_CORREDOC",listaItemFactura.get(i).get("num_corredoc").toString());
        		//buscar Participante de Documento de tipo IMPORTADOR
        		PkDocu.put("COD_TIPPARTIC","93");
        		Map<String, Object> partipanteImp = participanteDocDAO.findByDocumentoAndTipPartic(PkDocu);
        		String ciudadIncoterm=partipanteImp.get("des_ubigeociudad").toString();
        		 listaItemFactura.get(i).put("ciudadICOTERM", ciudadIncoterm);
          }	  

          String codIdentiProductoDigital = listaItemFactura.get(i).get("ind_software")!=null?listaItemFactura.get(i).get("ind_software").toString():" ";
          String codIdentiProductoDigital_desc= catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDeclaracion.CATALOGO_342, codIdentiProductoDigital);
          listaItemFactura.get(i).put("codIdentiProductoDigital_desc", codIdentiProductoDigital+" "+codIdentiProductoDigital_desc);
          
          String posDespachoSimplificado = listaItemFactura.get(i).get("ind_otros")!=null?listaItemFactura.get(i).get("ind_otros").toString():" ";
          String posDespachoSimplificado_desc= catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDeclaracion.CATALOGO_343,posDespachoSimplificado);
          listaItemFactura.get(i).put("posDespachoSimplificado_desc", posDespachoSimplificado +" " +posDespachoSimplificado_desc);
         
   
           List<Map<String, String>> lstObservaciones= new ArrayList<Map<String, String>>();
		   Map<String, Object> mapBusqueda = new HashMap<String, Object>();
		   mapBusqueda.put("numcorredoc",PkSerie.get("NUM_CORREDOC"));
		   mapBusqueda.put("numsecitem",listaItemFactura.get(i).get("cod_secitem"));
		   mapBusqueda.put("codtipobs","03");//catalogo 369
		   List<Observacion> obs = observacion.findObservcionByMap(mapBusqueda);
		  
		   
		   if(obs!=null && obs.size()>0){
				 for(int j=0; j<obs.size(); j++){
					 	 Map<String, String> observ =new HashMap<String, String>();
						 observ.put("numsecitem", obs.get(j).getNumsecitem().toString());
						 observ.put("numsecuenciaOBS", obs.get(j).getNumsecuencia().toString());
						 observ.put("codtipobservaOBS", obs.get(j).getCodtipobserva().toString());				 
						 observ.put("obsdeclaracionOBS",obs.get(j).getObsdeclaracion()!=null
								 && !SunatStringUtils.isEmpty(obs.get(j).getObsdeclaracion())?
										 obs.get(j).getObsdeclaracion().toString():"");//M_SNADE257-813 PAS20165E220200137 
						 observ.put("numsecitem", obs.get(j).getNumsecitem().toString());
						 lstObservaciones.add(observ);
				 } 
				 
				 
			 }			 
		  listaItemFactura.get(i).put("lstObservaciones",lstObservaciones);
			 //Fin PAS20155E220200089  P24
			//Fin cambios 12/06/2014
			 
		  
	  //Inicio-PAS20165E220200138		  
		  if(listaItemFactura.get(i).get("cod_tipdescrmin")!=null && !StringUtils.isEmpty(listaItemFactura.get(i).get("cod_tipdescrmin").toString())){		  
				Enum<?> tipo = TipoDescrMinima.get(listaItemFactura.get(i).get("cod_tipdescrmin").toString());				
				if(tipo!=null){					
                    // agregar version de plantilla
					ModelAbstract objeto = ModelFactory.crearObjetoDescrMinima(tipo);
					objeto.setFechaIniVigenciaValidador(SunatDateUtils.getDateFromUnknownFormat(PkSerie.get("FEC_DECLARACION").toString()));
					PlantillaFactory plantillaFactory= fabricaDeServicios.getService("descripcionMinima.PlantillaFactory");
					//validadorFactory.crearValidadorDescrMinima(objeto);					
					listaItemFactura.get(i).put("VERSION_PLANTILLA",plantillaFactory.obtenerVersionEstrutura(objeto));
					listaItemFactura.get(i).put("FechaIniVigenciaValidador",PkSerie.get("FEC_DECLARACION").toString());					
				}		
		  }
			//Fin-PAS20165E220200138
		  
		  
        }
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    
    return listaItemFactura;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerFVDetalle(Map<String, String> PkFactu) throws ServiceException
  {
    Map<String, String> mapParticipante = new HashMap<String, String>();
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    Map<String, Object> mapImportador = new HashMap<String, Object>();
    Map<String, Object> mapProveedor = new HashMap<String, Object>();
    Map<String, Object> mapIntermediario = new HashMap<String, Object>();
    List<Map<String, Object>> listSeries = new ArrayList<Map<String, Object>>();
    Map<String, Object> mapDatos = new HashMap<String, Object>();
    try
    {
      // Obtenemos datos de IMPORTADOR
      mapImportador = participanteDAO.findByDocumento(PkFactu);
      // ////
      // Obtenemos el nombre del importador
      if (mapImportador.get("cod_tipdoc") != null && !"".equals(mapImportador.get("cod_tipdoc").toString().trim())
          && mapImportador.get("des_numdociden") != null
          && !"".equals(mapImportador.get("des_numdociden").toString().trim()))
      {

        if (Constantes.TIPO_DOC_DNI.equals(mapImportador.get("cod_tipdoc").toString().trim())
            || Constantes.TIPO_DOC_RUC.equals(mapImportador.get("cod_tipdoc").toString().trim()))
        {
          Map pers = this.soporteService.obtenerPerNatJur(mapImportador.get("cod_tipdoc").toString().trim(),
              mapImportador.get("des_numdociden").toString().trim());

          mapImportador.put("desc_razonsocial", pers.get("nombre"));
          if (!"".equals((String) pers.get("direccion")))
          {
            mapImportador.put("DIR_PARTIC", pers.get("direccion"));
          }
        }
      }
      mapResultado.put("mapImportador", mapImportador);

      // Mapa de datos para obtener datos de participantes
      mapDatos = formBProveedorDAO.findFullByPk(PkFactu);
      mapResultado.put("datosAdicionales", mapDatos);
      // Obtenemos datos de Det, los item de la factura
      listSeries = itemFacturaDAO.obtenerItemFactura(PkFactu);
      if (!CollectionUtils.isEmpty(listSeries))
      {
        for (int i = 0; i < listSeries.size(); i++)
        {
          if (listSeries.get(i).get("num_partida") != null)
          {
            Nandina nandina = catalogoAyudaService.getPartidaObject(listSeries.get(i).get("num_partida").toString());
            listSeries.get(i).put("des_partida", nandina != null ? nandina.getDescripcion() : "");
          }
        }
      }
      mapResultado.put("listSeries", listSeries);
      mapParticipante.put("NUM_SECPARTIC", "" + mapDatos.get("NUM_SECDECLARANTE"));
      mapProveedor = participanteDAO.findByPkParticipante(mapParticipante);
      if (mapProveedor.get("cod_tipdoc") != null && !"".equals(mapProveedor.get("cod_tipdoc").toString().trim())
          && mapProveedor.get("des_numdociden") != null
          && !"".equals(mapProveedor.get("des_numdociden").toString().trim()))
      {

        if (Constantes.TIPO_DOC_DNI.equals(mapProveedor.get("cod_tipdoc").toString().trim())
            || Constantes.TIPO_DOC_RUC.equals(mapProveedor.get("cod_tipdoc").toString().trim()))
        {
          Map pers = this.soporteService.obtenerPerNatJur(mapProveedor.get("cod_tipdoc").toString().trim(),
              mapProveedor.get("des_numdociden").toString().trim());

          if (pers.get("nombre") != null && !pers.get("nombre").toString().trim().isEmpty())
          {
            mapProveedor.put("desc_razonsocial", pers.get("nombre"));
          }
          if (!"".equals((String) pers.get("direccion")))
          {
            mapProveedor.put("desc_direccion", pers.get("direccion"));
          }
        }
      }
      mapResultado.put("mapDeclarante", mapProveedor);

      mapParticipante.put("NUM_SECPARTIC", "" + mapDatos.get("NUM_CODSECPROVE"));
      mapProveedor = participanteDAO.findByPkParticipante(mapParticipante);
      if (mapProveedor.get("cod_tipdoc") != null && !"".equals(mapProveedor.get("cod_tipdoc").toString().trim())
          && mapProveedor.get("des_numdociden") != null
          && !"".equals(mapProveedor.get("des_numdociden").toString().trim()))
      {

        if (Constantes.TIPO_DOC_DNI.equals(mapProveedor.get("cod_tipdoc").toString().trim())
            || Constantes.TIPO_DOC_RUC.equals(mapProveedor.get("cod_tipdoc").toString().trim()))
        {
          Map pers = this.soporteService.obtenerPerNatJur(mapProveedor.get("cod_tipdoc").toString().trim(),
              mapProveedor.get("des_numdociden").toString().trim());

          mapProveedor.put("desc_razonsocial", pers.get("nombre"));
          if (!"".equals((String) pers.get("direccion")))
          {
            mapProveedor.put("desc_direccion", pers.get("direccion"));
          }
        }
      }
      mapResultado.put("mapProveedor", mapProveedor);
      mapParticipante.put("NUM_SECPARTIC", "" + mapDatos.get("NUM_SECINTERMEDIARIO"));
      mapIntermediario = participanteDAO.findByPkParticipante(mapParticipante);
      if (mapIntermediario.get("cod_tipdoc") != null
          && !"".equals(mapIntermediario.get("cod_tipdoc").toString().trim())
          && mapIntermediario.get("des_numdociden") != null
          && !"".equals(mapIntermediario.get("des_numdociden").toString().trim()))
      {

        if (Constantes.TIPO_DOC_DNI.equals(mapIntermediario.get("cod_tipdoc").toString().trim())
            || Constantes.TIPO_DOC_RUC.equals(mapIntermediario.get("cod_tipdoc").toString().trim()))
        {
          Map pers = this.soporteService.obtenerPerNatJur(mapIntermediario.get("cod_tipdoc").toString().trim(),
              mapIntermediario.get("des_numdociden").toString().trim());
          if (StringUtils.isNotBlank((String) pers.get("nombre")))
          {
            mapIntermediario.put("desc_razonsocial", pers.get("nombre"));
          }

          if (StringUtils.isNotBlank((String) pers.get("direccion")))
          {
            mapIntermediario.put("desc_direccion", pers.get("direccion"));
          }
        }
      }
      mapResultado.put("mapIntermediario", mapIntermediario);
      mapResultado.put("mapFormBMonto", this.listToMap(
          formBMontoDAO.findByDav("" + PkFactu.get("NUM_CORREDOC"), "" + mapDatos.get("NUM_SECPROVE")), "COD_MONTO",
          "MTO_VALOR"));
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return mapResultado;
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerFVFacturas(Map PkFactu) throws ServiceException
  {
    List lista = null;
    try
    {
      lista = itemFacturaDAO.joinComprobPagoFindByFactura(PkFactu);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFormatoBItems(Map<String, String> PkDocu) throws ServiceException
  {
    List<Map<String, Object>> listaItemFactura = null;
    try
    {
      listaItemFactura = itemFacturaDAO.joinComprobPagoFindByDocumento(PkDocu);
      //RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
//      if (!CollectionUtils.isEmpty(listaItemFactura))
//      {
//        for (int i = 0; i < listaItemFactura.size(); i++)
//        {
//          if (listaItemFactura.get(i).get("NUM_PARARANCEL") != null)
//          {
//
//            Nandina nandina = catalogoAyudaService.getPartidaObject(listaItemFactura
//                .get(i)
//                .get("NUM_PARARANCEL")
//                .toString());
//            if (nandina != null)
//              listaItemFactura.get(i).put("DESCRIPCION_PARTIDA", nandina.getDescripcion());
//          }
//        }
//      }
      //RTINEO FIN
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return listaItemFactura;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerFormatoBItem(Map<String, String> PkDocu) throws ServiceException
  {
    List<Map<String, Object>> listaItemFactura = null;
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    Map<String, Object> params = new HashMap<String, Object>();

    Map<String, String> params2 = new HashMap<String, String>();

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + PkDocu.get("caduana").toString().trim()));
    try
    {
      listaItemFactura = itemFacturaDAO.joinComprobPagoFindByDocumento(PkDocu);
      
      // para evitar problemas en IE 8
      for(Map<String, Object> itemFactura : listaItemFactura) {
    	  reemplazarCamposNulos(itemFactura);
      }
      
      if (!CollectionUtils.isEmpty(listaItemFactura))
      {

        Map<String, Object> filtro = new HashMap<String, Object>();
        Map<String, Object> obs = new HashMap<String, Object>();

        for (int i = 0; i < listaItemFactura.size(); i++)
        {
          if (listaItemFactura.get(i).get("NUM_PARARANCEL") != null)
          {
						//PAS20155E220000094 RBEGAZO INICIO
        	  			Nandina nandina = null;
						try {
							nandina = catalogoAyudaService.getPartidaObject(listaItemFactura.get(i).get("NUM_PARARANCEL").toString());
						} catch (Exception e) {
							nandina = null;
						}
						if (nandina != null) {
              listaItemFactura.get(i).put("DESCRIPCION_PARTIDA", nandina.getDescripcion());
          }
						//PAS20155E220000094 RBEGAZO FIN
					}

          filtro = new HashMap<String, Object>();
          filtro.put("NUM_CORREDOC", PkDocu.get("NUM_CORREDOC").toString());
          filtro.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
          filtro.put("NUM_SECITEM", listaItemFactura.get(i).get("NUM_SECITEM").toString());
          obs = observacionDAO.findByDocumentoTipo(filtro);
          if (obs != null && obs.size() > 0)
          {
            listaItemFactura.get(i).put("OBSERVACION", obs.get("OBS_OBS"));
            listaItemFactura.get(i).put("NUM_SECOBS", obs.get("NUM_SECOBS"));
          }
          else
          {
            listaItemFactura.get(i).put("OBSERVACION", null);
            listaItemFactura.get(i).put("NUM_SECOBS", null);
          }

          //inicio CU 14.15
	      this.agregarEstadosItemYlstProvicional(listaItemFactura, PkDocu, i);
          //fin CU 14.15
        }
      }
      mapResultado.put("lstItemFactura", listaItemFactura);
      params.put("NUM_CORREDOC", PkDocu.get("NUM_CORREDOC").toString());
      params.put("NUM_SECPROVE", PkDocu.get("NUM_SECPROVE").toString());

      params2.put("NUM_CORREDOC", PkDocu.get("NUM_CORREDOC").toString());
      params2.put("NUM_SECFACT", PkDocu.get("NUM_SECFACT").toString());

      mapResultado.put("lstSeriesItem", seriesItemDAO.select(params));
      //mapResultado.put("lstReferenciaDuda", referenciaDudaDAO.findByPkItem(params2));//PASS399
      Map datosProv = null;
      datosProv = this.formBProveedorDAO.findByPk(params.get("NUM_CORREDOC").toString(), params
          .get("NUM_SECPROVE")
          .toString());
      mapResultado.put("datosProv", datosProv);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Error Inesperado");
    }

    return mapResultado;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerAsociadasReferenciaDUDAFormatoBItem(Map<String, String> pkItem)
    throws ServiceException
  {
    Map<String, Object> mapAsociadasReferenciaDUDA = new HashMap<String, Object>();
    try
    {
      mapAsociadasReferenciaDUDA.put("lstSeriesAsociadas", seriesItemDAO.findSerieItemByPkItem(pkItem));
      //mapAsociadasReferenciaDUDA.put("lstReferenciaDUDA", referenciaDudaDAO.findByPkItem(pkItem));//PASS399
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return mapAsociadasReferenciaDUDA;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFormatoBCorrelaciones(Map<String, Object> pkItem) throws ServiceException
  {
    List<Map<String, Object>> lstCorrelaciones = null;
    try
    {
      lstCorrelaciones = seriesItemDAO.select(pkItem);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return lstCorrelaciones;
  }


  public List<Map<String, Object>> obtenerFormatoBCorrelacionesInicial(Declaracion declaracionInicialBean,Map<String, Object> pkItem) throws ServiceException
  {

    String numSecItem = pkItem.get("NUM_SECITEM")!=null?pkItem.get("NUM_SECITEM").toString():"";

    List<Map<String, Object>> lstCorrelaciones = new ArrayList<Map<String, Object>>();


      if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

        for(DAV otrosDatosProveedor : declaracionInicialBean.getListDAVs()){
          if(!CollectionUtils.isEmpty(otrosDatosProveedor.getListFacturas())){
            for(DatoFactura factura : otrosDatosProveedor.getListFacturas()){
              if(!CollectionUtils.isEmpty(factura.getListItems())){
                for (DatoItem item : factura.getListItems()) {
                  if((item.getNumsecitem().toString()).equals(numSecItem)){
                    if(!CollectionUtils.isEmpty(item.getListSerieItems())){
                      for (DatoSerieItem serieItem : item.getListSerieItems()) {
                        Map serieCorrelacionada = new HashMap();
                        serieCorrelacionada.put("NUM_SECSERIE",serieItem.getNumserie());
                        lstCorrelaciones.add(serieCorrelacionada);
                      }
                    }

                  }
                }
              }
            }
          }
        }
      }


    return lstCorrelaciones;
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerFVProveedores(Map PkDocu) throws ServiceException
  {
    List lista = null;
    try
    {
      lista = formBProveedorDAO.findByDocumento(PkDocu);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public Map obtenerDetalleDAV(String num_correDoc, String num_secProve) throws ServiceException
  {

    Map res = null;
    try
    {
      res = this.formBProveedorDAO.findByPk(num_correDoc, num_secProve);
      
      //PAQUETE2 RIN13
      //res.put("cod_tipinterm", res.get("cod_tipinterm").toString().trim()); //RIN13

        // Obtenemos el nombre del importador
      //RIN13
      String nombre = (String)res.get("nom_razonsocial_pim");
      	if(nombre != null && !"".equals(nombre.trim())){ 
	  		String tipoDocumento = (String)res.get("cod_tipdoc_pim");
	        String numeroDocumento = (String)res.get("num_docident_pim");
	        
	        if (numeroDocumento != null && !"".equals(numeroDocumento.trim()) && tipoDocumento != null && !"".equals(tipoDocumento.trim())) {
	            if (Constantes.TIPO_DOC_DNI.equals(tipoDocumento.trim())
	                    || Constantes.TIPO_DOC_RUC.equals(tipoDocumento.trim())) {
	
	                Map<String, Object> pers = this.soporteService.obtenerPerNatJur(
	                		tipoDocumento.trim(),
	                		numeroDocumento.trim());
	                res.put("nom_razonsocial_pim", pers.get("nombre"));
	
	            }
	        }
	  	}
	  	//RIN13
      if (!CollectionUtils.isEmpty(res))
      {
        res.put("mapFormBMonto", this.listToMap(this.formBMontoDAO.findByDav(num_correDoc, num_secProve), "COD_MONTO",
            "MTO_VALOR"));
        res.put("mapCondicionTransa", this.listToMap(this.condicionTransaDAO.findByDav(num_correDoc, num_secProve),
            "COD_INDTRANSACCION", "IND_TRANSACCION"));
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }

  @Override
  public Map<String,Object> obtenerMontosFormBByDAV(String num_correDoc, String num_secProve) throws ServiceException{
	  Map<String,Object> res = null;
	  try{
		  res = this.listToMap(this.formBMontoDAO.findByDav(num_correDoc, num_secProve), "COD_MONTO","MTO_VALOR");
	  }catch (Exception e){
		  log.error("*** ERROR ***", e);
	      throw new ServiceException(this, e);
	  }
	  return res;
  }
  
  /*inicio metodos gdlr399*/
  @Override
  public List<Map<String,Object>> obtenerMontosFormBByDocumento(Map<String, Object> parametros) throws ServiceException {
	  List<Map<String,Object>> montos = null;
	  try {
		  //gdlr... se consulta todos los montos por documento (num_corredoc)
		  montos = formBMontoDAO.selectByMap(parametros);
		  
	  }catch (Exception e){
		  log.error("*** ERROR ***", e);
	      throw new ServiceException(this, e);
	  }
	  return montos;
  }
  
  @Override
  public List<Map<String,Object>> obtenerCondicionTransaccionFormBByDocumento(Map<String, Object> parametros) throws ServiceException {
	  List<Map<String,Object>> condicionesTransaccion = null;
	  try {
		  //gdlr... se consulta todas las condiciones por documento (num_corredoc)
		  condicionesTransaccion = condicionTransaDAO.selectCondiTransa(parametros);
		  
	  }catch (Exception e){
		  log.error("*** ERROR ***", e);
	      throw new ServiceException(this, e);
	  }
	  return condicionesTransaccion;
  }
  
  @Override
  public List<Map<String, Object>> obtenerItemsFacturaByDocumento(Map<String, Object> parametros) throws ServiceException {
    List<Map<String, Object>> itemsFactura = null;
    
    try {
    	//este DAO recibe como parametro String el numCorredoc... grr
    	Map<String, String> parametros2 = new HashMap<String, String>();
    	Long numeroCorrelativo = (Long) parametros.get("NUM_CORREDOC");
    	parametros2.put("NUM_CORREDOC", numeroCorrelativo.toString());
    	itemsFactura = itemFacturaDAO.joinComprobPagoFindByDocumento(parametros2);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Error Inesperado");
    }

    return itemsFactura;
  }
  
  @Override
  public List<Map<String, Object>> obtenerFobProvisionalByDocumento(Map<String, Object> parametros) throws ServiceException {
	  List<Map<String,Object>> registrosFobProvisional = null;
	  try {
		  registrosFobProvisional = vFOBProvisionalDAO.findMapMontoProvByMap(parametros);
	  } catch (Exception e) {
		  log.error("*** ERROR ***", e);
	      throw new ServiceException(this, "Error Inesperado");
	  }
	  return registrosFobProvisional;
  }
  
  /*fin metodos gdlr399*/
  
  
  
  /*INICIO RIN13 PAQ2*/
  @Override
  public Map<String,Object> obtenerCondicionTransaccionFormB(String num_correDoc, String num_secProve) throws ServiceException{
	  Map<String,Object> res = null;
	  try{
		  res = this.listToMap(this.condicionTransaDAO.findByDav(num_correDoc, num_secProve), "COD_INDTRANSACCION", "IND_TRANSACCION");
	  }catch (Exception e){
		  log.error("*** ERROR ***", e);
	      throw new ServiceException(this, e);
	  }
	  return res;
	  
  }
  /*FIN RIN13*/

  /**
   * {@inheritDoc}
   */
  public List obtenerFormatoBFacturas(String num_correDoc) throws ServiceException
  {
    List res = null;
    try
    {
      res = this.comprobPagoDAO.findByDocumento(num_correDoc);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerFacturasProveedor(Map params) throws ServiceException
  {
    List res = null;
    try
    {
      res = this.comprobPagoDAO.findByDocProveedor(params);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerItemsFactura(Map params) throws ServiceException
  {
    List res = null;
    try
    {
      res = this.itemFacturaDAO.findByFactura(params);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }



  /**
   * List to map.
   *
   * @param lstEval
   *          the lst eval
   * @param cmpKey
   *          the cmp key
   * @param cmpValue
   *          the cmp value
   * @return the map
   */
  private Map<String, Object> listToMap(List lstEval, String cmpKey, String cmpValue)
  {
    Map<String, Object> res = new HashMap<String, Object>();

    if (!CollectionUtils.isEmpty(lstEval))
    {
      Map<String, Object> row;
      for (int i = 0; i < lstEval.size(); i++)
      {
        row = (HashMap<String, Object>) lstEval.get(i);
        res.put(row.get(cmpKey).toString().trim(), row.get(cmpValue));
      }
    }

    return res;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFBItemsDUA(Map<String, String> PkDocu) throws ServiceException
  {
    List<Map<String, Object>> listaItemFactura = null;

    try
    {
      listaItemFactura = itemFacturaDAO.joinComprobPagoFindByDocumento(PkDocu);
      if (!CollectionUtils.isEmpty(listaItemFactura))
      {
        for (int i = 0; i < listaItemFactura.size(); i++)
        {
          if (listaItemFactura.get(i).get("NUM_PARARANCEL") != null)
          {
            Nandina nandina = catalogoAyudaService.getPartidaObject(listaItemFactura
                .get(i)
                .get("NUM_PARARANCEL")
                .toString());
            listaItemFactura.get(i).put("DESCRIPCION_PARTIDA", nandina != null ? nandina.getDescripcion() : "");
          }
        }
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return listaItemFactura;
  }


  /*INICIO PAS20124E600000358*/
  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFacturasSerie(Map<String, Object> pkSerie) throws ServiceException{

      Map mapaNumCorredocAndNumSecSerie = Utilidades.convertKeyMapToLowerCase(pkSerie);


      List<Map<String, Object>> listaFacturasFormatoAxSerie = (List<Map<String, Object>>) formAFactuDAO
              .joinFacturaSerieFindBySeries(mapaNumCorredocAndNumSecSerie);

      SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
      if (!CollectionUtils.isEmpty(listaFacturasFormatoAxSerie)) {
          for (Map mapaFactura : listaFacturasFormatoAxSerie) {
              mapaFactura.put("FEC_FACT", sdf.format(Utilidades.toDate(mapaFactura.get("FEC_FACT"))));
          }
      }

      return listaFacturasFormatoAxSerie;
  }


  public List<Map<String, Object>> obtenerFacturasSerieAll(Map<String, Object> pkSerie) throws ServiceException{

    Map mapaNumCorredocAndNumSecSerie = Utilidades.convertKeyMapToLowerCase(pkSerie);


    List<Map<String, Object>> listaFacturasFormatoAxSerie = (List<Map<String, Object>>) formAFactuDAO.joinFacturaSerieFindBySeriesAll(mapaNumCorredocAndNumSecSerie);


    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    if (!CollectionUtils.isEmpty(listaFacturasFormatoAxSerie)) {
      for (Map mapaFactura : listaFacturasFormatoAxSerie) {
        mapaFactura.put("FEC_FACT", sdf.format(Utilidades.toDate(mapaFactura.get("FEC_FACT"))));
      }
    }

    return listaFacturasFormatoAxSerie;
  }
/*FIN    PAS20124E600000358*/

  /**
   * {@inheritDoc}
   */
  public List<DatoFacturaref> obtenerFacturas(Map<String, Object> pkSerie) throws ServiceException
  {
    return formAFactuDAO.findFacturarefByMap(pkSerie);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerFacturaFormA(Map<String, Object> params) throws ServiceException
  {
    return formAFactuDAO.select(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDAVRecti(Map<String, String> PkDocu) throws ServiceException
  {
    List<Map<String, Object>> lista = null;

    Map<String, Object> pkDocu = new HashMap<String, Object>();
    pkDocu.put("NUM_CORREDOC", PkDocu.get("NUM_CORREDOC"));

    try
    {
      lista = formBProveedorDAO.findDavRectiByDocumento(pkDocu);

    }
    catch (Exception e)
    {
      log.error(this.toString() + " - ERROR: " + e.getMessage());
      throw new ServiceException(this, e);
    }

    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectCondiTransa(Map params)
  {
    return condicionTransaDAO.selectCondiTransa(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectVehiCetico(Map params)
  {
    return vehiCeticoDAO.selectVehiCetico(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectCabAdiImpoConsu(Map<String, Object> params)
  {
    return cabAdiImpoConsuDAO.select(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectFactuSuce(Map<String, Object> params)
  {
    return factuSuceDAO.selectFactuSuse(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectFormbMonto(Map<String, Object> params) throws ServiceException
  {
    return formBMontoDAO.selectByMap(params);

  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectMontoGasto(Map<String, Object> params) throws ServiceException
  {
    return montoGastoDAO.select(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> selectFormbItemDescri(Map params)
  {
    return formBItemDescriDAO.selectByMap(params);
  }


  /** Metodo que asigna el indicador del estado de registro del item en base de datos(ESTADO_REGISTRO) 
   *  o adicionado en session(IND_TIPO_REGISTRO),
   *  asigna el indicador de estado eliminado registrado en Base de datos(ELIMINADO_PERMANENTE) para diferenciar 
   *  de un item eliminado en session,
   *  carga la lista de VFOBPROVISIONAL asociadas al item 
   * @param listaItemFactura
   * @param pkDocu
   * @param i
  */
  private void agregarEstadosItemYlstProvicional(List<Map<String, Object>> listaItemFactura, Map<String, String> pkDocu,
			int i){

	String IND_REGISTRO_GRABADO = "0";
	String DES_REGISTRO_GRABADO = "Adicionado";
	listaItemFactura.get(i).put("IND_TIPO_REGISTRO", IND_REGISTRO_GRABADO);//valor: "0" (Adicionado)
	listaItemFactura.get(i).put("DES_TIPO_REGISTRO", DES_REGISTRO_GRABADO);//valor: "Adicionado"
	listaItemFactura.get(i).put("ESTADO_REGISTRO", "0"); // 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN BD
	listaItemFactura.get(i).put("IND_DESCMANTITEM", "0");//valor: "0" (no muestra descripcion)
	if(listaItemFactura.get(i).get("IND_DEL").equals("1")){
		listaItemFactura.get(i).put("ELIMINADO_PERMANENTE", "BD");
	}else{
		listaItemFactura.get(i).put("ELIMINADO_PERMANENTE", "");
	}
	
	Map<String, Object> paramsMont = new HashMap<String,Object>();
	paramsMont.put("NUM_CORREDOC", pkDocu.get("NUM_CORREDOC").toString());
	paramsMont.put("NUM_SECPROVE", pkDocu.get("NUM_SECPROVE").toString());
	paramsMont.put("NUM_SECFACT", pkDocu.get("NUM_SECFACT").toString());
	paramsMont.put("NUM_SECITEM", listaItemFactura.get(i).get("NUM_SECITEM").toString());

	List<Map<String,Object>> lstVfobProvisional = vFOBProvisionalDAO.findMapMontoProvByMap(paramsMont);
	listaItemFactura.get(i).put("lstVfobProvisional", lstVfobProvisional);

  }

  /** Agrega el item copia a la lista de items de la factura seleccionada 
  * @param params
  * @param itemsViewList
  * @param lstItemsTotalActual
  * @return List<Map<String, Object>> Lista de Items
  * @throws ServiceException
  */
   public List<Map<String, Object>> obtenerListaItemsIncluidoItemCopiado(
      Map<String, Object> params,
      List<Map<String, Object>> itemsViewList, List<Map<String, Object>> lstItemsTotalActual)
      throws ServiceException{	 
        
	    Map<String, Object> detItemMap = null;
	    List<Map<String, Object>> lstDecrMinima = new ArrayList<Map<String, Object>>();
	    List<Map<String, Object>> lstProvicional = new ArrayList<Map<String, Object>>();
	    
	    try
	    {

	      String item_base = String.valueOf(params.get("NUM_SECITEM"));

	      detItemMap = obtenerItemSesion(params, itemsViewList);

	        String numCorreDocDua = params.get("NUM_CORREDOC").toString();
	        int nextNumSectemeGenerado = obtenerSgteNumSecItem(numCorreDocDua, lstItemsTotalActual);
	        Map<String, Object> detItemMap1 = Utilidades.copiarMapa(detItemMap);// copiando item
	        
	        this.reemplazarCamposNulos(detItemMap1);

	        detItemMap1.put("NUM_SECOBS", "");
	        detItemMap1.put("NUM_SECITEM", nextNumSectemeGenerado);

	        final String IND_REGISTRO_PENDIENTE = "1";
	        String DES_REGISTRO_PENDIENTE = "Pendiente de grabar";
	        detItemMap1.put("IND_TIPO_REGISTRO", IND_REGISTRO_PENDIENTE);
	        detItemMap1.put("DES_TIPO_REGISTRO", DES_REGISTRO_PENDIENTE);
	        detItemMap1.put("ESTADO_REGISTRO", "1");// 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN  BD
	        detItemMap1.put("IND_DESCMANTITEM", "1");
	        detItemMap1.put("ELIMINADO_PERMANENTE","");
	        detItemMap1.put("ITEM_BASE", item_base);
	        
	        detItemMap1.put("COD_USUREGIS", params.get("COD_USUREGIS"));
	        detItemMap1.put("FEC_REGIS", params.get("FEC_REGIS"));
	        
	        detItemMap1.put("lstSeriesItem", null);
	        
	        if(detItemMap1.get("lstDecrMinima")!=null && !detItemMap1.get("lstDecrMinima").toString().isEmpty()){
	        	lstDecrMinima = (ArrayList<Map<String, Object>>)detItemMap1.get("lstDecrMinima");
		        for(Map<String, Object> bItemDes: lstDecrMinima){
		        	bItemDes.put("NUM_SECITEM", nextNumSectemeGenerado);
		        }
		        detItemMap1.put("lstDecrMinima", lstDecrMinima);
	        }else{
	        	detItemMap1.put("lstDecrMinima", null);
	        }
	        
	        if(detItemMap1.get("lstVfobProvisional")!=null && !detItemMap1.get("lstVfobProvisional").toString().isEmpty()){
	        	lstProvicional = (ArrayList<Map<String, Object>>)detItemMap1.get("lstVfobProvisional");
		        for(Map<String, Object> prov: lstProvicional){
		        	prov.put("NUM_SECITEM", nextNumSectemeGenerado);
		        }
		        detItemMap1.put("lstVfobProvisional", lstProvicional);
	        }else{
	        	detItemMap1.put("lstVfobProvisional", null);
	        }
	        
	        if(detItemMap1.get("lstReferenciaDuda")!=null && !detItemMap1.get("lstReferenciaDuda").toString().isEmpty()){
	        	List<Map<String,Object>> refDuda = (ArrayList<Map<String, Object>>)detItemMap1.get("lstReferenciaDuda");
	        	for(Map<String, Object> ref : refDuda){
	        		ref.put("NUM_SECITEM", nextNumSectemeGenerado);
	        	}
	        	detItemMap1.put("lstReferenciaDuda", refDuda);
	        }else{
	        	detItemMap1.put("lstReferenciaDuda", null);
	        }
	        
	        itemsViewList.add(detItemMap1);

	    }
	    catch (Exception e)
	    {
	      new ServiceException(this, e);
	    }
	    return itemsViewList;
	    
  }
 
	/**
	 * Metodo que reemplaza los campos nulos por vacio. Ayuda a evitar problemas
	 * en Internet Explorer 8
	 * 
	 * @param itemView
	 */
	private void reemplazarCamposNulos(Map<String, Object> itemView) {
		for (Entry<String, Object> entrada : itemView.entrySet()) {
			if (entrada.getValue() == null) {
				entrada.setValue("");
			}
		}
	}

  /** Metodo que retorna una copia del item seleccionado 
 * @param params
 * @param itemsViewList
 * @return
 * @throws ServiceException
 */
  private Map<String, Object> obtenerItemSesion(
	      Map<String, Object> params,
	      List<Map<String, Object>> itemsViewList)
	      throws ServiceException
	  {

	    Map<String, Object> detItemsMap = new HashMap<String, Object>();
	    try
	    {

	      String num_secitem = params.get("NUM_SECITEM") != null ? params.get("NUM_SECITEM").toString() : "";

	      if (!CollectionUtils.isEmpty(itemsViewList) && !SunatStringUtils.isEmpty(num_secitem))
	      {

	        for (Map<String, Object> itemMap : itemsViewList)
	        {
	          Object num_secitemView = itemMap.get("NUM_SECITEM");
	          if (Utilidades.compararCadenaConObjeto(num_secitem, num_secitemView))
	          {
	        	  detItemsMap = new HashMap<String, Object>(itemMap);
	            break;
	          }
	        }
	      }

	    }
	    catch (Exception e)
	    {
	      new ServiceException(this, e);
	    }
	    return detItemsMap;
  }

  /** BUsca el maximo secuencial del item en base de datos y session, retorna el siguiente secuencial del item despues del maximo encontrado 
 * @param numCorreDocDua
 * @param lstItemsActuales
 * @return
 */
  private int obtenerSgteNumSecItem(String numCorreDocDua, List<Map<String, Object>> lstItemsActuales){
	  
	   int secuenciaBD = obtenerSgteNumSecItemBd(numCorreDocDua);

	   int secuenciaLstItemsActual = obtenerSgteNumSecItemListaSesion(lstItemsActuales);

	   return (secuenciaBD >= secuenciaLstItemsActual ? secuenciaBD : secuenciaLstItemsActual);
 }
  
  /** Metodo que retorna el siguiente secuencial del item en funcion los items registrados en base de datos 
   * @param numCorreDocDua
   * @return int siguiente secuencial del item
   */
  public int obtenerSgteNumSecItemBd(String numCorreDocDua){
  
	    return (itemFacturaDAO.getMaxNumSecItem(numCorreDocDua) + 1);
  }
  
  /** Metodo que retorna el siguiente secuencial del item en funcion los items agregados a la session
   * @param lstItemsActuales
   * @return
   */
  private int obtenerSgteNumSecItemListaSesion(List<Map<String, Object>> lstItemsActuales){

	   int numeroItem = 0;
	    for (Map<String, Object> detDeclaraViewMap : lstItemsActuales)
	    {
	      Object num_secitemView = detDeclaraViewMap.get("NUM_SECITEM");
	      if (numeroItem < Integer.valueOf(num_secitemView.toString()))
	    	  numeroItem = Integer.valueOf(num_secitemView.toString());
	    }
	    numeroItem++;
	    return numeroItem;
  }

  /** Metodo que actualiza los indicadores de item Adicionado y si esta registrado en base de datos 
  * @param lstItemFacturaActual [List<Map<String, Object>>]
  * @param mapPkSelecModificar [Map<String, Object>]
  * @return List<Map<String, Object>> Lista de Items
  */
  public List<Map<String, Object>> cambiarIndTipRegItemSesion(List<Map<String, Object>> lstItemFacturaActual, Map<String, Object> mapPkSelecModificar){
	  
      for(Map itemFactura : lstItemFacturaActual){
           
            if (itemFactura.get("NUM_CORREDOC").toString().trim()
                                 .equals(mapPkSelecModificar.get("NUM_CORREDOC").toString())
                && itemFactura.get("NUM_SECPROVE").toString().trim()
                                    .equals(mapPkSelecModificar.get("NUM_SECPROVE").toString())
                && itemFactura.get("NUM_SECFACT").toString().trim()
                                    .equals(mapPkSelecModificar.get("NUM_SECFACT").toString())
                && itemFactura.get("NUM_SECITEM").toString().trim()
                                    .equals(mapPkSelecModificar.get("NUM_SECITEM").toString())
                && itemFactura.get("ESTADO_REGISTRO").toString().equals("1")
                && itemFactura.get("IND_TIPO_REGISTRO").equals("1")){
                   	
                	itemFactura.put("IND_TIPO_REGISTRO", "0");//ESTADO DEL REGISTRO QUE ESTA EN SESSION
                	itemFactura.put("DES_TIPO_REGISTRO", "Adicionado");
                	itemFactura.put("ESTADO_REGISTRO", "1");// 0 REGISTRADO EN BD, 1 PENDIENTE DE REGISTRO EN  BD
                	itemFactura.put("IND_DESCMANTITEM","1");
            }
    	  
      }

      return lstItemFacturaActual;
  }
  
  /** Metodo que actualiza temporalmente el estado del item y su lista de descripciones minimas
  * (los items de las facturas esten contenidas en la session mapCabDeclaraActual)
  * @param lstItemFacturaActual [Map<String, Object>}
  * @param mapPkSelecModificar [Map<String, Object>]
  * @return
  */
  public void actualizarEstadoItemSesion(Map<String, Object> declaracionActual, Map<String, Object> parametro){
   	
	List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>)parametro.get("lstSeriesItemActual");  
	if (declaracionActual != null && declaracionActual.size() > 0){
	  List<Map> lstProve = (ArrayList) declaracionActual.get("lstFormBProveedor");
	  for (Map prov : lstProve){
	    String codProv = prov.get("num_secprove").toString().trim();
	    if (codProv.equals(parametro.get("NUM_SECPROVE").toString())){
	    
	      List<Map> lstComproBPago = (ArrayList<Map>) prov.get("lstComproBPago");
	      for (Map comPago : lstComproBPago){
	    	 
	        String secFact = comPago.get("num_secfact").toString().trim();
	        if (secFact.equals(parametro.get("NUM_SECFACT").toString())){
	          
	         List<Map<String, Object>> lstItemFactura = (List<Map<String, Object>>) comPago.get("lstItemFactura");
	         for(Map<String, Object> itemFactura : lstItemFactura){
	        	 
	        	if(parametro.get("NUM_SECITEM").toString().equals(itemFactura.get("NUM_SECITEM").toString())
	        		&& parametro.get("NUM_CORREDOC").toString().equals(itemFactura.get("NUM_CORREDOC").toString())){
	        		
	        		itemFactura.put("IND_DEL", parametro.get("EST_ITEM").toString());
	        		
	        		if(itemFactura.get("lstDecrMinima")!=null && !itemFactura.get("lstDecrMinima").toString().isEmpty()){
	      				List<Map<String,Object>> lstDecrMinima = (ArrayList<Map<String,Object>>) itemFactura.get("lstDecrMinima");
	      				for(Map<String,Object> fobDescri : lstDecrMinima){
	      						fobDescri.put("IND_DEL", parametro.get("EST_ITEM").toString());
	      				}
	      			}
	        		break;
	        	}
	         }
	        }
	      }
	
	    }
	  }
	}
	parametro.put("lstSeriesItemActual", lstSeriesItemActual);
  }
  
  /** Metodo que obtiene todos los items de las facturas contenidas en la declaracion Actual
  * @param mapCabDeclara [Map<String,Object>]
  * @return [List<Map<String, Object>>] Lista de Items de la factura
  */
  public List<Map<String, Object>> obtenerListaItemsDeclaracionActual(Map<String,Object> mapCabDeclara) throws ServiceException{
		 
		  List<Map<String,Object>> lstItemFactura = new ArrayList<Map<String,Object>>();
	      
		  if (!CollectionUtils.isEmpty((List) mapCabDeclara.get("lstFormBProveedor"))) {
	    	  List<Map<String,Object>> lstForBProveedor = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
		        for (Map<String, Object> mapa : lstForBProveedor){
		        	List<Map<String,Object>> lstComproBPago = (List<Map<String, Object>>) mapa.get("lstComproBPago");

                     if(org.apache.commons.collections.CollectionUtils.isNotEmpty(lstComproBPago)){ //amancilla correccion ticket INC 2016-053377
                       for (Map<String, Object> mapaFactura : lstComproBPago){

                         List lstItemFactua = (List)mapaFactura.get("lstItemFactura");
                          if(!CollectionUtils.isEmpty(lstItemFactua)){
                           lstItemFactura.addAll(Utilidades.copiarLista((List)mapaFactura.get("lstItemFactura")));
                         }
                       }
                   }
		         }
		   }
	     
	      return lstItemFactura;
  } 

  
  /*****Req 3014******/
  
  /** Obtiene el Bean Declaracion inicial 
   * @param numcorredoc [Long] 
   * @param aduana [String]
   * @param annoEnvio [String] 
   * @return
  */// P34-3014 formatoB-Inicial
  @Override
  public Declaracion obtenerDeclaracionInicial(Long numcorredoc, String aduana, String annoEnvio) throws Exception {

      Declaracion declaracion = new Declaracion();
      EnvioDAO envioDAO = fabricaDeServicios.getService("manifiesto.envioDAO");
      AyudaServiceCache ayudaServiceCache = fabricaDeServicios.getService("Ayuda.ayudaServiceCache");
      ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.formatob.reglaConversionService");
      
      // buscar envio
      Map<String, Object> paramsBuscarEnvio = new HashMap<String, Object>();

      paramsBuscarEnvio.put("codLugarEnvio", aduana);
      paramsBuscarEnvio.put("numeroCorrelativo", numcorredoc);
      paramsBuscarEnvio.put("anhoEnvio", annoEnvio);
      List<EnvioBean> listaEnvios = envioDAO.listByParameterMap(paramsBuscarEnvio);
      
      // no se encontro envio
      if ( CollectionUtils.isEmpty( listaEnvios ) ) {
          return null;
      }
      EnvioBean envio = null;
      boolean indicador = false;
      for(EnvioBean envioBean : listaEnvios){
          if(envioBean.getCodigoTransaccion().equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO + Constantes.CONS_CODFBCONFTRANS7_2)
             || envioBean.getCodigoTransaccion().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO + Constantes.CONS_CODFBCONFTRANS7_2)
             || envioBean.getCodigoTransaccion().equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO + Constantes.CONS_CODFBCONFTRANS7_2)){
              envio =  envioBean;
              indicador = true;
              break;
          }
      }
      if(!indicador){
          for(EnvioBean envioBean : listaEnvios){
              String codTransaccion = envioBean.getCodigoTransaccion().substring(0, 2);
              if(codTransaccion.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO)
                 || codTransaccion.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)
                 || codTransaccion.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO)){
                  envio =  envioBean;
                  indicador = true;
                  break;
              }
          }
      }
      
      if(envio!=null){
      Map<String, Object> params = new HashMap<String, Object>();

      // rutas para zips y xmls
      String destination = "/data1/sigad/envios/descomprimido/";
      String fileName = "/data1/sigad/envios/temporal/"+ UUID.randomUUID().toString() + annoEnvio + "-" + envio.getNumeroEnvio() + ".zip";

      // obtener archivo XML (BD -> ZIP -> XML)
      params.clear();
      params.put("numeroTicket", envio.getNumeroEnvio()); 
      params.put("anhoEnvio", annoEnvio);
      params.put("tipoArchivo", "E");

      String fileXML = obtenerXMLDeclaracion(params, fileName, destination);

      // no pudo encontrar zip
      if (fileXML == null) {
          return null;
      }
          
      // obtener lista de reglas
      params.clear();
      params.put("numeroTransaccion", envio.getCodigoTransaccion());
      List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(params);

      // usar conversor para obtener el objeto mensaje.declaracion usando las reglas y el fichero XML
      XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
      xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

      // obtener el objeto mensaje.declaracion usando las reglas y el ficheroXML
      Mensaje mensaje = xmlConvertirObjetosUtil.convertir(listaReglas,fileXML, envio.getCodigoTransaccion());
  
      declaracion = (Declaracion) mensaje.getDocumento();
      }
      return declaracion;
   
  }

  /** Retorna el archivo en cadena
   * @param paramsMap [Map<String, Object>] 
   * @param fileName [String]
   * @param destination [String] 
   * @return
  */// P34-3014 formatoB-Inicial
  @Override
  public String obtenerXMLDeclaracion(Map<String, Object> paramsMap,
          String fileName, String destination) throws Exception {

      // obtener objeto envio archivo
      EnvioArchivoDAO envioArchivoDAO = fabricaDeServicios.getService("manifiesto.envioArchivoDAO");
      EnvioArchivoBean envioArchivo = envioArchivoDAO.obtenerArchivoEnvio(paramsMap);
   
      if ( envioArchivo != null ) {
           
          // escribir zip en disco
          FileOutputStream fos = new FileOutputStream(fileName);
          fos.write(envioArchivo.getInformacionArchivo());
          fos.flush();
          fos.close();

          ZipUtil zipHelper = fabricaDeServicios.getService("receptor.formatob.zipUtil");

          // descomprimir envio archivo zip en XML
          List<String> nombres = zipHelper.unZipFiles(fileName, destination);
          if (CollectionUtils.isEmpty(nombres)) {
              throw new Exception("No hay ficheros en el zip");
          }

          return nombres.get(0);
          
      }
      
      return null;
      
  }


  public Map<String, Object> obtenerFVDetalleInicialOriginal(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException
  {
    Map<String, String> mapParticipante = new HashMap<String, String>();
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    Map<String, Object> mapImportador = new HashMap<String, Object>();
    Map<String, Object> mapProveedor = new HashMap<String, Object>();
    Map<String, Object> mapIntermediario = new HashMap<String, Object>();
    List<Map<String, Object>> listSeries = new ArrayList<Map<String, Object>>();
    Map<String, Object> mapDatos = new HashMap<String, Object>();
    Map<String, Object> mapCondicionTransaccion = new HashMap<String, Object>();
    try
    {

      DUA dua = declaracionInicialBean.getDua();
      Map<String, Object> cabeceraDeclaracion = new HashMap<String,Object>();
      DataCatalogo dataCatAduana = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_CATALOGO_ADUANAS, dua.getCodaduanaorden());

      cabeceraDeclaracion.put("desc_Aduana", dataCatAduana.getDesDatacat());
      cabeceraDeclaracion.put("fecha_numeracion", dua.getFecNumeracion());
      cabeceraDeclaracion.put("numero_orden", declaracionInicialBean.getNumorden());
      mapResultado.put("cabeceraDeclaracion", cabeceraDeclaracion);

      //HAcostaR Inicio - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
      CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
      String COD_CATALOGO = "CC1";
      String COD_DATACATALOGO = "001278";
      String MSJ_LEY_29733 = "No Disponible - Ley 29733";
      DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(COD_CATALOGO, COD_DATACATALOGO, null);
      Boolean vig001278 = false;
      //Control de Cambio no se encuentra vigente
      if(null!=dataCatalogo)
    	  vig001278 = true;
      //HAcostaR Fin - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
      
      /*****Importador*****/
      Participante importador = dua.getDeclarante();

      String tipoDocumento =  importador!=null ?(importador.getTipoDocumentoIdentidad()!=null?importador.getTipoDocumentoIdentidad().getCodDatacat():""):"";

      
      //HAcostaR Inicio - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
      //String descNumDocIden = importador.getNumeroDocumentoIdentidad();
      String descNumDocIden = importador!=null ?(importador.getNumeroDocumentoIdentidad()!=null?importador.getNumeroDocumentoIdentidad():""):"";
      //if(vig001278 && ( "3".equals(tipoDocumento) || "6".equals(tipoDocumento) || ("4".equals(tipoDocumento) && ( descNumDocIden.startsWith("10") || descNumDocIden.startsWith("15") || descNumDocIden.startsWith("17") )) )){
    	  
      if(vig001278 && dua.getCodregimen().equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_REGIMEN_10) 
        		  && ( ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(tipoDocumento) || ConstantesDataCatalogo.TIPO_DOCUMENTO_PASAPORTE.equals(tipoDocumento) 
        				|| (ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumento) && ( descNumDocIden.startsWith("10") || descNumDocIden.startsWith("15") || descNumDocIden.startsWith("17") )) )){
    	  mapImportador.put("desc_razonsocial", MSJ_LEY_29733);
    	  mapImportador.put("des_numdociden", MSJ_LEY_29733);
    	  mapImportador.put("desc_tipodoc", MSJ_LEY_29733);
      }else{
      //HAcostaR Fin - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
      mapImportador.put("desc_razonsocial", importador.getNombreRazonSocial());
      if (!Utilidades.esNuloOVacio(tipoDocumento) && !Utilidades.esNuloOVacio(descNumDocIden)
              && (Utilidades.esNuloOVacio(importador.getNombreRazonSocial())
              || Utilidades.esNuloOVacio(importador.getDireccion())) ){

        if (Constantes.TIPO_DOC_DNI.equals(tipoDocumento.trim())
                || Constantes.TIPO_DOC_RUC.equals(tipoDocumento.trim())){
          Map pers = this.soporteService.obtenerPerNatJur(tipoDocumento.trim(),
                  descNumDocIden);

          if(Utilidades.esNuloOVacio(importador.getNombreRazonSocial()) ){
            mapImportador.put("desc_razonsocial", pers.get("nombre"));
          }
          if (!"".equals((String) pers.get("direccion")) && Utilidades.esNuloOVacio(importador.getDireccion()) ){
            mapImportador.put("desc_direccion", pers.get("direccion") );
          }
        }
      }

      mapImportador.put("des_numdociden",descNumDocIden );

      String descTipoDco = "";
      if(!Utilidades.esNuloOVacio(tipoDocumento)){
        DataCatalogo dataCatTipoDocumento = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_TIPO_DOCUMENTO, tipoDocumento);
        descTipoDco = dataCatTipoDocumento.getDesDatacat();
      }
      mapImportador.put("desc_tipodoc", descTipoDco );

      }//HAcostaR - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES

      mapImportador.put("des_ubigeociudad", importador.getCiudad());
      mapImportador.put("cod_paisorigen", importador.getPais()!=null ?importador.getPais().getCodCatalogo():"");
      mapImportador.put("desc_telefono", importador.getTelefono() );
      mapImportador.put("desc_fax", importador.getFax());
      mapImportador.put("desc_email", importador.getEmail() );

      mapResultado.put("mapImportador", mapImportador);


      // Mapa de datos para obtener datos de participantes
      mapDatos = this.obtenerDatosParticipanteInicial(declaracionInicialBean, pkSerie);
      mapResultado.put("datosAdicionales", mapDatos);

      mapCondicionTransaccion = this.obtieneCondicionesTransaccion(declaracionInicialBean, pkSerie);
      mapResultado.put("mapCondicionTransaccion", mapCondicionTransaccion);

      // Obtenemos datos de Det, los item de la factura
      /***Items***/
      listSeries = this.obtenerItemFacturaInicial(declaracionInicialBean, pkSerie);
      if (!CollectionUtils.isEmpty(listSeries))
      {
        //P34 EJHM
        boolean tieneIndicadorDUAValorProvisional=false;
        for (int i = 0; i < listSeries.size(); i++)
        {
          if (!Utilidades.esNuloOVacio(listSeries.get(i).get("num_partida") ))
          {
            Nandina nandina = catalogoAyudaService.getPartidaObject(listSeries.get(i).get("num_partida").toString());
            listSeries.get(i).put("des_partida", nandina != null ? nandina.getDescripcion() : "");
          }
          if(listSeries.get(i).get("cod_tipovalor").toString().equals("2") ){
            tieneIndicadorDUAValorProvisional=true;
          }
        }
        //P34 EJHM
        if(tieneIndicadorDUAValorProvisional){
          mapResultado.put("indicadorDUAValorProvisional","SI" );
        }
        else
        {
          mapResultado.put("indicadorDUAValorProvisional","NO" );
        }

      }
      mapResultado.put("listSeries", listSeries);


      /**Declarante***/

      mapProveedor = this.obtenerDatosDeclaranteInicial(declaracionInicialBean, pkSerie);

      if (!Utilidades.esNuloOVacio(mapProveedor.get("cod_tipdoc"))
              && !Utilidades.esNuloOVacio(mapProveedor.get("des_numdociden"))
              && (Utilidades.esNuloOVacio(mapProveedor.get("desc_razonsocial"))
              || Utilidades.esNuloOVacio(mapProveedor.get("desc_direccion"))) ){

        if (Constantes.TIPO_DOC_DNI.equals(mapProveedor.get("cod_tipdoc").toString().trim())
                || Constantes.TIPO_DOC_RUC.equals(mapProveedor.get("cod_tipdoc").toString().trim())
                ){

          Map pers = this.soporteService.obtenerPerNatJur(mapProveedor.get("cod_tipdoc").toString().trim(),
                  mapProveedor.get("des_numdociden").toString().trim());

          if (pers.get("nombre") != null && !pers.get("nombre").toString().trim().isEmpty()
                  && Utilidades.esNuloOVacio(mapProveedor.get("desc_razonsocial")) ){
            mapProveedor.put("desc_razonsocial", pers.get("nombre"));
          }
          if (!"".equals((String) pers.get("direccion")) && Utilidades.esNuloOVacio(mapProveedor.get("desc_direccion")) ) {
            mapProveedor.put("desc_direccion", pers.get("direccion"));
          }
        }
      }

      mapResultado.put("mapDeclarante", mapProveedor);


      /**Proveedor***/

      mapProveedor = this.obtenerDatosInicialesProveedor(declaracionInicialBean, pkSerie);
      if (!Utilidades.esNuloOVacio(mapProveedor.get("cod_tipdoc"))
              && !Utilidades.esNuloOVacio(mapProveedor.get("des_numdociden"))
              && (Utilidades.esNuloOVacio(mapProveedor.get("desc_razonsocial"))
              || Utilidades.esNuloOVacio(mapProveedor.get("desc_direccion"))) ){

        if (Constantes.TIPO_DOC_DNI.equals(mapProveedor.get("cod_tipdoc").toString().trim())
                || Constantes.TIPO_DOC_RUC.equals(mapProveedor.get("cod_tipdoc").toString().trim())){

          Map pers = this.soporteService.obtenerPerNatJur(mapProveedor.get("cod_tipdoc").toString().trim(),
                  mapProveedor.get("des_numdociden").toString().trim());
          if(Utilidades.esNuloOVacio(mapProveedor.get("desc_razonsocial"))){
            mapProveedor.put("desc_razonsocial", pers.get("nombre"));
          }
          if (!"".equals((String) pers.get("direccion")) && Utilidades.esNuloOVacio(mapProveedor.get("desc_direccion"))){
            mapProveedor.put("desc_direccion", pers.get("direccion"));
          }
        }
      }

      mapResultado.put("mapProveedor", mapProveedor);

      /***Intermediario***/

      mapIntermediario = this.obtenerIntermediarioInicial(declaracionInicialBean, pkSerie);
      if (!Utilidades.esNuloOVacio(mapIntermediario.get("cod_tipdoc"))
              && !Utilidades.esNuloOVacio(mapIntermediario.get("des_numdociden"))
              && (Utilidades.esNuloOVacio(mapIntermediario.get("desc_razonsocial"))
              || Utilidades.esNuloOVacio(mapIntermediario.get("desc_direccion")))) {

        if (Constantes.TIPO_DOC_DNI.equals(mapIntermediario.get("cod_tipdoc").toString().trim())
                || Constantes.TIPO_DOC_RUC.equals(mapIntermediario.get("cod_tipdoc").toString().trim())) {

          Map pers = this.soporteService.obtenerPerNatJur(mapIntermediario.get("cod_tipdoc").toString().trim(),
                  mapIntermediario.get("des_numdociden").toString().trim());
          if (StringUtils.isNotBlank((String) pers.get("nombre")) && Utilidades.esNuloOVacio(mapIntermediario.get("desc_razonsocial"))){
            mapIntermediario.put("desc_razonsocial", pers.get("nombre"));
          }
          if (StringUtils.isNotBlank((String) pers.get("direccion")) && Utilidades.esNuloOVacio(mapIntermediario.get("desc_direccion"))){
            mapIntermediario.put("desc_direccion", pers.get("direccion"));
          }
        }
      }

      mapResultado.put("mapIntermediario", mapIntermediario);

      /**Montos***/
      mapResultado.put("mapFormBMonto", this.obtenerListaMontos(declaracionInicialBean, pkSerie));

    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return mapResultado;
  }

  /** Obtiene datos del Formato B inicial 
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @param pkSerie [Map] secuencial de la serie, numero corredoc, numero secuencial de factura, numero secuencial del item
   * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerFVDetalleInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException
  {

    List<Map<String, Object>> listaItems = new ArrayList<Map<String, Object>>();
    Map<String, Object> itemMapa = null;

    if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

      if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

        int nroProveedores = declaracionInicialBean.getListDAVs().size();

        for (int i = 0; i < nroProveedores; i++) {

          DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);

          if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){

            if(!CollectionUtils.isEmpty(otrosDatosProveedor.getListFacturas())){
              for(DatoFactura factura : otrosDatosProveedor.getListFacturas()){

                if (factura != null && factura.getNumsecfactu().toString().equals(pkSerie.get("NUM_SECFACT").toString()) ) {

                  if (factura != null) {

                    Elementos<DatoItem> listaDatoItem = factura.getListItems();

                    for (DatoItem item : listaDatoItem) {

                      itemMapa = new HashMap<String, Object>();
                      //P34 inicio Valor Provisional
                      itemMapa.put("cod_tipovalor", !Utilidades.esNuloOVacio(item.getMontoProv().getIndtipovalor())? item.getMontoProv().getIndtipovalor():" ");
                      String des_tipovalor="";
                      if(!Utilidades.esNuloOVacio(item.getMontoProv().getIndtipovalor())){
                        DataCatalogo dataCodTipovalordesc = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_TIPO_VALOR, item.getMontoProv().getIndtipovalor());
                        des_tipovalor=dataCodTipovalordesc.getDesCorta();
                      }
                      itemMapa.put("des_tipovalor", des_tipovalor);
                      itemMapa.put("des_fobunitarioprovisional", item.getMontoProv().getValmonto()!=null?item.getMontoProv().getValmonto():0.0);
                      if (item.getMontoProv().getFecvalestima()!=null && !SunatDateUtils.isDefaultDate(item.getMontoProv().getFecvalestima())){
                        itemMapa.put("des_fecvalestima", SunatDateUtils.getFormatDate(item.getMontoProv().getFecvalestima(), "dd/MM/yyyy"));
                      }
                      else {
                        itemMapa.put("des_fecvalestima", "-");
                      }
                      //P34 fin Valor Provisional

                      String descPaisOrigen = "";
                      if(!Utilidades.esNuloOVacio(item.getCodpaisorige())){
                        DataCatalogo dataCatPaisOrigen = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_PAIS, item.getCodpaisorige());
                        descPaisOrigen = dataCatPaisOrigen.getDesCorta();
                      }

                      itemMapa.put("cod_paisOrigen", item.getCodpaisorige());
                      itemMapa.put("desc_paisOrigen", descPaisOrigen);

                      String desPaisEmbarque = "";
                      if(!Utilidades.esNuloOVacio(factura.getCodpaisembar())){
                        DataCatalogo dataCatPaisEmbarq = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar());
                        desPaisEmbarque = dataCatPaisEmbarq.getDesCorta();
                      }
                      itemMapa.put("cod_paisembarque", factura.getCodpaisembar());
                      itemMapa.put("desc_paisembarque", desPaisEmbarque);


                      String descUnicomer = "";
                      if(!Utilidades.esNuloOVacio(item.getCodunidcomer())){
                        DataCatalogo dataUnidadComer = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_UNIDAD_COMERCIAL, item.getCodunidcomer());
                        descUnicomer = dataUnidadComer.getDesCorta();
                      }
                      itemMapa.put("cod_uniComer", item.getCodunidcomer());
                      itemMapa.put("desc_uniComer", descUnicomer);

                      String desEstMerc = "";
                      if(!Utilidades.esNuloOVacio(item.getCodestamer())){
                        DataCatalogo dataCatEstMerc = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_ESTADO_MERCANCIA, item.getCodestamer());
                        desEstMerc = dataCatEstMerc.getDesCorta();
                      }
                      itemMapa.put("cod_estmerc", item.getCodestamer());
                      itemMapa.put("desc_estmerc", desEstMerc);

                      itemMapa.put("cod_secprov", Utilidades.validarNuloOVacioRetornaString(pkSerie.get("NUM_SECPROVE").toString()));
                      itemMapa.put("cod_factura", factura.getNumfactura());
                      itemMapa.put("cod_secitem", Utilidades.validarNuloOVacioRetornaString(item.getNumsecitem()));
                      itemMapa.put("cod_inddeduc", item.getInddeducdisti());
                      itemMapa.put("cod_secfact", pkSerie.get("NUM_SECFACT").toString());
                      itemMapa.put("des_montofobunitario", Utilidades.validarNuloOVacioRetornaString(item.getMtofobunita()));
                      itemMapa.put("des_montoajusteunitario", Utilidades.validarNuloOVacioRetornaString(item.getMtoajusunita()));
                      itemMapa.put("des_fobitem", Utilidades.validarNuloOVacioRetornaString(item.getMtofobitem()));
                      itemMapa.put("num_unidad", Utilidades.validarNuloOVacioRetornaString(item.getCntcantcomer()));
                      itemMapa.put("des_comer", item.getDescomercial());
                      itemMapa.put("des_marca", item.getDesmarca());
                      itemMapa.put("des_modelo", item.getDesmodelo());
                      itemMapa.put("des_annfabricacion", item.getAnnfabrica());
                      itemMapa.put("des_indsoftware", item.getIndsoftware());
                      itemMapa.put("cod_producto", item.getCodproducto());
                      itemMapa.put("des_caracteristicas", item.getDescaracteristicas());
                      itemMapa.put("des_clasevariedad", item.getDesclasevari());
                      itemMapa.put("des_usoaplicacion", item.getDesusoaplica());
                      itemMapa.put("des_materialcomp", item.getDesmaterialcomp());
                      itemMapa.put("num_partida", Utilidades.validarNuloOVacioRetornaString(item.getNumpartnandi()));
                      //obtener datos
                      itemMapa.put("cod_secprov", item.getNumsecprove());
                      itemMapa.put("cod_factura", ((DatoFactura)item.getPadre()).getNumfactura());
                      itemMapa.put("cod_secitem", item.getNumsecitem());
                      itemMapa.put("cod_tipovalor", "");
                      itemMapa.put("des_proveedor", otrosDatosProveedor.getProveedor().getNombreRazonSocial());
                      itemMapa.put("des_fecha",SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT) );
                      itemMapa.put("cod_incoterm",factura.getCodincoterm() );

                      String ciudad = "";
                      String descripVersionIcoterm = "";
                      if (factura.getDeslugtrans()!=null){
                        ciudad = SunatStringUtils.substring(factura.getDeslugtrans(), 0, factura.getDeslugtrans().toString().indexOf("-"));
                        String codigoIcoterm = SunatStringUtils.substring(factura.getDeslugtrans(), factura.getDeslugtrans().indexOf("-") + 1);
                        descripVersionIcoterm = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDeclaracion.CATALOGO_ICOTERM, codigoIcoterm);
                      }

                      itemMapa.put("ciudadICOTERM",ciudad);
                      itemMapa.put("versionICOTERM",descripVersionIcoterm );

                      itemMapa.put("cod_monetrans",this.obtenerDescripcionPorCatalogo("J1", factura.getCodmoneda()) );
                      itemMapa.put("des_paisorigen",this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, item.getCodpaisorige()) );
                      itemMapa.put("des_paisembarque",this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar()) );

                      Nandina nandina = catalogoAyudaService.getPartidaObject(item.getNumpartnandi().toString());
                      String partidaDesc =  nandina != null ? nandina.getDescripcion():"";

                      itemMapa.put("des_partida",partidaDesc );
                      itemMapa.put("codIdentiProductoDigital_desc"," " );
                      itemMapa.put("posDespachoSimplificado_desc"," " );
                      itemMapa.put("des_comer2"," " );
                      itemMapa.put("des_comer3"," " );

                      listaItems.add(itemMapa);

                    }
                  }

                }
              }
            }

            break;
          }
        }
      }

    }



    return listaItems;
  }


 
  /** Obtiene la lista de items de la Factura inicial
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @param pkSerie [Map] secuencial de la serie
   * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerItemFacturaInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     List<Map<String, Object>> listaItems = new ArrayList<Map<String, Object>>();
     Map<String, Object> itemMapa = null;
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

             int nroProveedores = declaracionInicialBean.getListDAVs().size();

             for (int i = 0; i < nroProveedores; i++) {

                  DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);

                  if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){
                      
                      if(!CollectionUtils.isEmpty(otrosDatosProveedor.getListFacturas())){
                          for(DatoFactura factura : otrosDatosProveedor.getListFacturas()){
                              
                        	  String numSecFact =pkSerie.get("NUM_SECFACT")!=null?pkSerie.get("NUM_SECFACT").toString():" ";
                              
                              if (factura != null && factura.getNumsecfactu().toString().equals(numSecFact) ) {
                                 
                                  if (factura != null) {

                                      Elementos<DatoItem> listaDatoItem = factura.getListItems();

                                      for (DatoItem item : listaDatoItem) {

                                          itemMapa = new HashMap<String, Object>();
                                        //P34 inicio Valor Provisional
                                          itemMapa.put("cod_tipovalor", !Utilidades.esNuloOVacio(item.getMontoProv().getIndtipovalor())? item.getMontoProv().getIndtipovalor():" ");
                                          String des_tipovalor="";
                                          if(!Utilidades.esNuloOVacio(item.getMontoProv().getIndtipovalor())){
                                              DataCatalogo dataCodTipovalordesc = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_TIPO_VALOR, item.getMontoProv().getIndtipovalor());
                                              des_tipovalor=dataCodTipovalordesc.getDesCorta();
                                          }
                                          itemMapa.put("des_tipovalor", des_tipovalor); 
                                          itemMapa.put("des_fobunitarioprovisional", item.getMontoProv().getValmonto()!=null?item.getMontoProv().getValmonto():0.0);
                                        if (item.getMontoProv().getFecvalestima()!=null && !SunatDateUtils.isDefaultDate(item.getMontoProv().getFecvalestima())){
                                  			itemMapa.put("des_fecvalestima", SunatDateUtils.getFormatDate(item.getMontoProv().getFecvalestima(), "dd/MM/yyyy"));
                                  		}
                                        else {
                                        	itemMapa.put("des_fecvalestima", "-");	
                                        }
                                        //P34 fin Valor Provisional
                                          
                                          String descPaisOrigen = "";
                                          if(!Utilidades.esNuloOVacio(item.getCodpaisorige())){
                                              DataCatalogo dataCatPaisOrigen = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_PAIS, item.getCodpaisorige());
                                              descPaisOrigen = dataCatPaisOrigen.getDesCorta();
                                          }
                                          itemMapa.put("cod_paisOrigen", item.getCodpaisorige());
                                          itemMapa.put("desc_paisOrigen", descPaisOrigen);
                                          
                                          String desPaisEmbarque = "";
                                          if(!Utilidades.esNuloOVacio(factura.getCodpaisembar())){
                                              DataCatalogo dataCatPaisEmbarq = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar());
                                              desPaisEmbarque = dataCatPaisEmbarq.getDesCorta();
                                          }
                                          itemMapa.put("cod_paisembarque", factura.getCodpaisembar());
                                          itemMapa.put("desc_paisembarque", desPaisEmbarque);

                                          
                                          String descUnicomer = "";
                                          if(!Utilidades.esNuloOVacio(item.getCodunidcomer())){
                                              DataCatalogo dataUnidadComer = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_UNIDAD_COMERCIAL, item.getCodunidcomer());
                                              descUnicomer = dataUnidadComer.getDesCorta();
                                          }
                                          itemMapa.put("cod_uniComer", item.getCodunidcomer());
                                          itemMapa.put("desc_uniComer", descUnicomer);
                                          
                                          String desEstMerc = "";
                                          if(!Utilidades.esNuloOVacio(item.getCodestamer())){
                                              DataCatalogo dataCatEstMerc = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_ESTADO_MERCANCIA, item.getCodestamer());
                                              desEstMerc = dataCatEstMerc.getDesCorta();
                                          }
                                          itemMapa.put("cod_estmerc", item.getCodestamer());
                                          itemMapa.put("desc_estmerc", desEstMerc);
                                          
                                          itemMapa.put("cod_secprov", Utilidades.validarNuloOVacioRetornaString(pkSerie.get("NUM_SECPROVE").toString()));
                                          itemMapa.put("cod_factura", factura.getNumfactura());
                                          itemMapa.put("cod_secitem", Utilidades.validarNuloOVacioRetornaString(item.getNumsecitem()));
                                          itemMapa.put("cod_inddeduc", item.getInddeducdisti());
                                          itemMapa.put("cod_secfact", pkSerie.get("NUM_SECFACT").toString());
                                          itemMapa.put("des_montofobunitario", Utilidades.validarNuloOVacioRetornaString(item.getMtofobunita()));
                                          itemMapa.put("des_montoajusteunitario", Utilidades.validarNuloOVacioRetornaString(item.getMtoajusunita()));
                                          itemMapa.put("mto_fobItem", Utilidades.validarNuloOVacioRetornaString(item.getMtofobitem()));
                                          itemMapa.put("num_unidad", Utilidades.validarNuloOVacioRetornaString(item.getCntcantcomer()));
                                          itemMapa.put("des_comer", item.getDescomercial());
                                          itemMapa.put("des_marca", item.getDesmarca());
                                          itemMapa.put("des_modelo", item.getDesmodelo());
                                          itemMapa.put("des_annfabricacion", item.getAnnfabrica());
                                          itemMapa.put("des_indsoftware", item.getIndsoftware());
                                          itemMapa.put("cod_producto", item.getCodproducto());
                                          itemMapa.put("des_caracteristicas", item.getDescaracteristicas());
                                          itemMapa.put("des_clasevariedad", item.getDesclasevari());
                                          itemMapa.put("des_usoaplicacion", item.getDesusoaplica());
                                          itemMapa.put("des_materialcomp", item.getDesmaterialcomp());
                                          itemMapa.put("num_partida", Utilidades.validarNuloOVacioRetornaString(item.getNumpartnandi()));
                                          
                                          listaItems.add(itemMapa);

                                      }
                                  }
                                  
                              }     
                          }
                      }

                     break; 
                  }
             }     
         }

     }
     
     return listaItems;
  }
 
  /** Obtiene los datos del Participante inicial
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] secuencial de la serie
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String, Object> obtenerDatosParticipanteInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     Map<String, Object> mapDatos = null;
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {
            
              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapDatos = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){
                 
                 String desNivelComer = "";
                 if(!Utilidades.esNuloOVacio(otrosDatosProveedor.getCodnivcomer())){
                     DataCatalogo dataCatNivelComer = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_NIVEL_COMERCIAL, otrosDatosProveedor.getCodnivcomer());
                     desNivelComer = dataCatNivelComer.getDesCorta();
                 }
                 mapDatos.put("des_nivelcomercial", desNivelComer);
                 
                 String desCondicion = "";
                 if(!Utilidades.esNuloOVacio(otrosDatosProveedor.getCodcondprov())){
                 DataCatalogo dataCatCodCondProv = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_CONDICION_PROVEEDOR, otrosDatosProveedor.getCodcondprov());
                 desCondicion = dataCatCodCondProv.getDesCorta();
                 }
                 mapDatos.put("des_condicion", desCondicion);

                 String codModPago = declaracionInicialBean.getDua()!=null ? 
                         (declaracionInicialBean.getDua().getPago()!=null?
                                ( declaracionInicialBean.getDua().getPago().getPagoTransaccion()!=null?
                         declaracionInicialBean.getDua().getPago().getPagoTransaccion().getCodmodpago():""):"" ):"";
                 
                 String descModalidad = "";
                 if(!Utilidades.esNuloOVacio(codModPago)){
                     DataCatalogo dataCatmModPago = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_MODALIDAD, codModPago);
                     descModalidad = dataCatmModPago.getDesCorta();
                 }
                 mapDatos.put("DES_MODALIDAD", descModalidad);

                 String descFormaEnvio = "";
                 if(!Utilidades.esNuloOVacio(otrosDatosProveedor.getCodformenvio())){
                     DataCatalogo dataCatFormaEnvio = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_FORMA_ENVIO, otrosDatosProveedor.getCodformenvio());
                     descFormaEnvio = dataCatFormaEnvio.getDesCorta();
                 }
                 mapDatos.put("DES_FORMAENVIO", descFormaEnvio);
                 mapDatos.put("DES_NATURALEZA", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NATURALEZA_TRANSACCION, otrosDatosProveedor.getCodnatutrans()));
                 
                 mapDatos.put("DIR_LUGARTRANS", null);//FIXME
                 mapDatos.put("nro_envio", otrosDatosProveedor.getNumenvio());
                 
                 
                 String descExistIntermediario = "";
                 if(!Utilidades.esNuloOVacio(otrosDatosProveedor.getIndexisinter())) {
                   if(otrosDatosProveedor.getIndexisinter().equals(Constantes.IND_SI_EXISTE_INTERMEDIARIO)){
                       descExistIntermediario = "SI";
                   }else if(otrosDatosProveedor.getIndexisinter().equals(Constantes.IND_NO_EXISTE_INTERMEDIARIO)){
                       descExistIntermediario = "NO";
                   }
                 }
                 mapDatos.put("DESC_IND_INTEMEDIARIO", descExistIntermediario);
                 mapDatos.put("IND_INTEMEDIARIO", otrosDatosProveedor.getIndexisinter());
                 String codTipIntermediario = otrosDatosProveedor.getIntermediario()!=null? (otrosDatosProveedor.getIntermediario().getTipoParticipante()!=null ? 
                         otrosDatosProveedor.getIntermediario().getTipoParticipante().getCodDatacat():""):"";
                 mapDatos.put("des_tipointermediario", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_TIPO_INTERMEDIARIO, codTipIntermediario));
                 
                 if(!CollectionUtils.isEmpty(otrosDatosProveedor.getListFacturas())){
                     for(DatoFactura factura : otrosDatosProveedor.getListFacturas()){
                        // La lista de facturas esta contenida en el bean proveedores
                    	 String numSecFactura = pkSerie.get("NUM_SECFACT")!=null?pkSerie.get("NUM_SECFACT").toString():" ";
                         if (factura != null && factura.getNumsecfactu().toString().equals(numSecFactura) ) {

                             mapDatos.put("DES_FECHA_FACTURA", SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT));
                             break;
                         }     
                     }
                 }

                break; 
              }
              
         }

     }
     return mapDatos;
  }
 
  /** Obtiene los datos del Declarante inicial
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] secuencial de la serie
  * @return
  */// P34-3014 formatoB-Inicial
  public Map<String, Object> obtenerDatosDeclaranteInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     Map<String, Object> mapDatos = null;
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapDatos = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())
                  && otrosDatosProveedor.getPersonaDecl()!=null){
                 
                 String tipodoc = otrosDatosProveedor.getPersonaDecl().getTipoDocumentoIdentidad()!=null ? 
                                      otrosDatosProveedor.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat():"";
                 String descTipodoc = "";              
                 if(!Utilidades.esNuloOVacio(tipodoc)){                     
                     DataCatalogo dataCatTipoDoc = catalogoAyudaService.getDataCatalogo(Constantes.CODIGO_TIPO_DOCUMENTO, tipodoc);
                     descTipodoc = dataCatTipoDoc.getDesDatacat();
                 }
                 mapDatos.put("desc_tipodoc", descTipodoc);
                 mapDatos.put("cod_tipdoc", otrosDatosProveedor.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat());
                 mapDatos.put("des_numdociden", otrosDatosProveedor.getPersonaDecl().getNumeroDocumentoIdentidad());
                 mapDatos.put("des_ubigeociudad",StringUtils.trimToEmpty(otrosDatosProveedor.getPersonaDecl().getCiudad()));
                 
                 String codCatPais = otrosDatosProveedor.getPersonaDecl().getPais()!=null? 
                                  otrosDatosProveedor.getPersonaDecl().getPais().getCodDatacat():"";
                 mapDatos.put("cod_paisorigen", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, codCatPais));
                 mapDatos.put("desc_telefono", StringUtils.trimToEmpty(otrosDatosProveedor.getPersonaDecl().getTelefono()));
                 mapDatos.put("desc_razonsocial", otrosDatosProveedor.getPersonaDecl().getNombreRazonSocial());
                 mapDatos.put("desc_direccion", otrosDatosProveedor.getPersonaDecl().getDireccion());
                 
                 String codRolParticip = otrosDatosProveedor.getPersonaDecl().getRolParticipante()!=null ? 
                                      otrosDatosProveedor.getPersonaDecl().getRolParticipante().getCodDatacat():"";
                 mapDatos.put("des_rolParticipante", codRolParticip);
                 mapDatos.put("cargo_declarante", otrosDatosProveedor.getNomcargdecla());
                 
                 break; 
              }
              
         }

     }

     return mapDatos;
  }
 
  /** carga la lista de montos del proveedor en un objeto Map<String, Object>
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] secuencial de la serie
  * @return
  */// P34-3014 formatoB-Inicial
  public Map<String, Object> obtenerListaMontos(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     Map<String, Object> mapDatos = new HashMap<String,Object>();
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapDatos = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){
                  
                  mapDatos = this.listToMapDelBean(
                          otrosDatosProveedor.getListMontos(), "COD_MONTO",
                          "MTO_VALOR");
                 break; 
              }
              
         }

     }

     return mapDatos;
  }

  /** carga la lista de montos del proveedor en un objeto Map<String, Object>
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param cmpKey [String] clave
  * @param cmpValue [String] valor
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String, Object> listToMapDelBean(Elementos<DatoMonto> lstEval, String cmpKey, String cmpValue){
   Map<String, Object> res = new HashMap<String, Object>();

   if (!CollectionUtils.isEmpty(lstEval))
   {
     for(DatoMonto monto: lstEval){
         res.put(monto.getCodmonto(), monto.getMtologistico());
     }
   }

   return res;
  }

 /** Obtiene datos iniciales del Intermediario
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] Secuencial del proveedor
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String, Object> obtenerIntermediarioInicial(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     Map<String, Object> mapDatos = null;
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapDatos = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){
                  
                  if(otrosDatosProveedor.getIntermediario()!=null){
                      
                      Participante intermediario = otrosDatosProveedor.getIntermediario();
                      
                      mapDatos.put("des_ubigeociudad", intermediario.getCiudad());
                      mapDatos.put("cod_paisorigen", intermediario.getPais()!=null ? intermediario.getPais().getCodDatacat():"");
                      mapDatos.put("desc_telefono", intermediario.getTelefono());
                      mapDatos.put("desc_fax", intermediario.getFax());
                      mapDatos.put("desc_email", intermediario.getEmail());
                      
                      String tipoDoc = intermediario.getTipoDocumentoIdentidad()!=null ? intermediario.getTipoDocumentoIdentidad().getCodDatacat():"";
                      mapDatos.put("cod_tipdoc", tipoDoc);
                      mapDatos.put("des_numdociden", intermediario.getNumeroDocumentoIdentidad());
                      
                  }else{
                  mapDatos.put("des_ubigeociudad", null);
                  mapDatos.put("cod_paisorigen", null);
                  mapDatos.put("desc_telefono", null);
                  mapDatos.put("desc_fax", null);
                  mapDatos.put("desc_email", null);
                  mapDatos.put("cod_tipdoc", null);
                  mapDatos.put("des_numdociden", null);
                  mapDatos.put("des_numdociden", null);
                  }
                break; 
              }
              
         }

     }
     return mapDatos;
  }

  /** Obtiene datos iniciales del Proveedor
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] Secuencial del proveedor
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String,Object> obtenerDatosInicialesProveedor(Declaracion declaracionInicialBean, Map pkSerie) throws ServiceException{
     
     Map<String, Object> mapProveedor = null;
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapProveedor = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkSerie.get("NUM_SECPROVE").toString())){
                  
                  if(otrosDatosProveedor.getProveedor()!=null){
                      
                      Participante proveedorBean = otrosDatosProveedor.getProveedor();
                      
                      mapProveedor.put("des_ubigeociudad", proveedorBean.getCiudad());
                      mapProveedor.put("cod_paisorigen", proveedorBean.getPais()!=null ? proveedorBean.getPais().getCodDatacat() :"");
                      mapProveedor.put("desc_telefono", proveedorBean.getTelefono());
                      mapProveedor.put("desc_fax", proveedorBean.getFax());
                      mapProveedor.put("desc_email", proveedorBean.getEmail());
                      
                      mapProveedor.put("cod_tipdoc", proveedorBean.getTipoDocumentoIdentidad() !=null ? 
                                                     proveedorBean.getTipoDocumentoIdentidad().getCodDatacat() : "");
                      mapProveedor.put("des_numdociden", proveedorBean.getNumeroDocumentoIdentidad());
                      mapProveedor.put("desc_razonsocial", proveedorBean.getNombreRazonSocial());
                      mapProveedor.put("desc_direccion", proveedorBean.getDireccion());
                      mapProveedor.put("pagina_web", proveedorBean.getPaginaWeb());
                      mapProveedor.put("e_mail", proveedorBean.getEmail());
                      mapProveedor.put("cod_proveedor", otrosDatosProveedor.getCodproveedor());
                      
                  }else{
                      mapProveedor.put("des_ubigeociudad", null);
                      mapProveedor.put("cod_paisorigen", null);
                      mapProveedor.put("desc_telefono", null);
                      mapProveedor.put("desc_fax", null);
                      mapProveedor.put("desc_email", null);
                      mapProveedor.put("cod_tipdoc", null);
                      mapProveedor.put("des_numdociden", null);
                      mapProveedor.put("pagina_web", null);
                      mapProveedor.put("e_mail", null);
                      mapProveedor.put("cod_proveedor", null);
                  }
                break; 
              }
              
         }

     }
     return mapProveedor;
      
  }
 
  /** Obtiene datos de la seccion Proveedores, lista los proveedores y datos de sus facturas
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String, Object>> obtenerFVProveedoresInicial(Declaracion declaracionInicialBean)  throws ServiceException{
     
     List<Map<String, Object>> listado = new ArrayList<Map<String,Object>>();
     Map<String, Object> itemProveedor = null;
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

             if (declaracionInicialBean.getListDAVs().get(i).getProveedor() != null) {

                 itemProveedor = new HashMap<String, Object>();
                 DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
                 
                 itemProveedor.put("num_secprove", otrosDatosProveedor.getNumsecuprov());
                 itemProveedor.put("nom_razonsocial_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getNombreRazonSocial():"");

               itemProveedor.put("des_ubigeociudad_prv",  otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getCiudad():"");
               itemProveedor.put("cod_paisorigen_prv_desc", otrosDatosProveedor.getProveedor()!=null ?  this.obtenerDescripcionPorCatalogo("J2",otrosDatosProveedor.getProveedor().getPais().getCodDatacat()):"");

                 //itemProveedor.put("dir_partic_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getDireccion():"");
                 //itemProveedor.put("nom_cargo", otrosDatosProveedor.getNomcargdecla());
                 itemProveedor.put("cod_nivelcomer_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NIVEL_MERCANCIA_PROVEEDOR, otrosDatosProveedor.getCodnivcomer()));
                 itemProveedor.put("cod_condprove_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_CONDICION_PROVEEDOR, otrosDatosProveedor.getCodcondprov()));
                 itemProveedor.put("cod_natutrans_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NATURALEZA_TRANSACCION, otrosDatosProveedor.getCodnatutrans()));
                 itemProveedor.put("cnt_fact", otrosDatosProveedor.getCntfacturas());
                 
                 listado.add(itemProveedor);
             }

         }

     }
     
     return listado;
  }
 
  public Map<String, Object> obtenerFVDetalleProveedorInicial(Declaracion declaracionInicialBean)  throws ServiceException{


    Map<String, Object> itemProveedor = null;
    if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

      int nroProveedores = declaracionInicialBean.getListDAVs().size();

      for (int i = 0; i < nroProveedores; i++) {

        if (declaracionInicialBean.getListDAVs().get(i).getProveedor() != null) {

          itemProveedor = new HashMap<String, Object>();
          DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);

          itemProveedor.put("num_secprove", otrosDatosProveedor.getNumsecuprov());
          itemProveedor.put("nom_razonsocial_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getNombreRazonSocial():"");

          itemProveedor.put("des_ubigeociudad_prv",  otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getCiudad():"");
          itemProveedor.put("cod_paisorigen_prv_desc", otrosDatosProveedor.getProveedor()!=null ?  this.obtenerDescripcionPorCatalogo("J2",otrosDatosProveedor.getProveedor().getPais().getCodDatacat()):"");

          //itemProveedor.put("dir_partic_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getDireccion():"");
          //itemProveedor.put("nom_cargo", otrosDatosProveedor.getNomcargdecla());
          itemProveedor.put("cod_nivelcomer_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NIVEL_MERCANCIA_PROVEEDOR, otrosDatosProveedor.getCodnivcomer()));
          itemProveedor.put("cod_condprove_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_CONDICION_PROVEEDOR, otrosDatosProveedor.getCodcondprov()));
          itemProveedor.put("cod_natutrans_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NATURALEZA_TRANSACCION, otrosDatosProveedor.getCodnatutrans()));
          itemProveedor.put("cnt_fact", otrosDatosProveedor.getCntfacturas());


        }

      }

    }

    return itemProveedor;
  }

  /** Obtiene datos de la seccion Facturas, lista las facturas y datos de sus items
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkFactu [Map] numero corredoc, numero secuencial del proveedor
  * @return
  */// P34-3014 formatoB-Inicial
  public List<Map<String,Object>> obtenerFVFacturasInicial(Declaracion declaracionInicialBean, Map pkFactu) 
                                                                                 throws ServiceException{
     List<Map<String, Object>> listado = new ArrayList<Map<String,Object>>();
     Map<String, Object> facturaMapa = null;
      
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroFacturas = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroFacturas; i++) {

             DAV davProveedor = declaracionInicialBean.getListDAVs().get(i);
             if(davProveedor!=null && davProveedor.getNumsecuprov().toString().equals(pkFactu.get("NUM_SECPROVE").toString())){
             Elementos<DatoFactura> listaFactura = davProveedor.getListFacturas();
             if (listaFactura != null) {

              
                 for (DatoFactura factura : listaFactura) {

                     if (factura != null) {

                       facturaMapa = new HashMap<String, Object>();
                       facturaMapa.put("cod_secprove", pkFactu.get("NUM_SECPROVE").toString());
                       facturaMapa.put("cod_factura", factura.getNumfactura());
                       facturaMapa.put("cod_secfact", factura.getNumsecfactu());
                       facturaMapa.put("des_fecha", SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT)  );
                       facturaMapa.put("des_monto", factura.getMtofactufob());
                       facturaMapa.put("cod_incoterm", factura.getCodincoterm());
                       facturaMapa.put("dir_lugartrans", factura.getDeslugtrans());
                       facturaMapa.put("cod_moneda_desc", this.obtenerDescripcionPorCatalogo("J1", factura.getCodmoneda()));
                       facturaMapa.put("cod_paisembarque_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar()));
                       listado.add(facturaMapa);
                     }

                 }
               }
            }
         }

     }

     return listado;
   }


  public Map<String,Object> cargarFormatoBDetFacturaInicial(Declaracion declaracionInicialBean, Map pkFactu)
          throws ServiceException{

    Map<String, Object> facturaMapa = null;


    String numSecFactura = pkFactu.get("NUM_SECFACT")!=null?pkFactu.get("NUM_SECFACT").toString():"";



    if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

      int nroFacturas = declaracionInicialBean.getListDAVs().size();

      for (int i = 0; i < nroFacturas; i++) {

        DAV davProveedor = declaracionInicialBean.getListDAVs().get(i);

        if(davProveedor!=null && davProveedor.getNumsecuprov().toString().equals(pkFactu.get("NUM_SECPROVE").toString())){
          Elementos<DatoFactura> listaFactura = davProveedor.getListFacturas();
          if (listaFactura != null) {
            for (DatoFactura factura : listaFactura) {

              if (numSecFactura.equals(factura.getNumsecfactu().toString())) {

                facturaMapa = new HashMap<String, Object>();
                facturaMapa.put("cod_secprove", pkFactu.get("NUM_SECPROVE").toString());
                facturaMapa.put("num_fact", factura.getNumfactura());
                facturaMapa.put("cod_secfact", factura.getNumsecfactu());
                facturaMapa.put("fec_fact", SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT)  );
                facturaMapa.put("mto_fact", factura.getMtofactufob());
                facturaMapa.put("cod_incoterm", factura.getCodincoterm());
                facturaMapa.put("dir_lugartrans", factura.getDeslugtrans());
                facturaMapa.put("cod_moneda_desc", this.obtenerDescripcionPorCatalogo("J1", factura.getCodmoneda()));
                facturaMapa.put("cod_paisembarque_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar()));

              }

            }
          }
        }
      }

    }

    return facturaMapa;
  }

  public List<Map<String,Object>> obtenerFVItemsFacturaIncial(Declaracion declaracionInicialBean, Map pkFactu)
          throws ServiceException{
    List<Map<String, Object>> listado = new ArrayList<Map<String,Object>>();
    Map<String, Object> facturaMapa = null;

    if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

      int nroFacturas = declaracionInicialBean.getListDAVs().size();

      for (int i = 0; i < nroFacturas; i++) {

        DAV davProveedor = declaracionInicialBean.getListDAVs().get(i);
        if(davProveedor!=null && davProveedor.getNumsecuprov().toString().equals(pkFactu.get("NUM_SECPROVE").toString())){
          Elementos<DatoFactura> listaFactura = davProveedor.getListFacturas();
          if (listaFactura != null) {


            for (DatoFactura factura : listaFactura) {

              if (factura != null) {

                         Elementos<DatoItem> listaDatoItem = factura.getListItems();

                         if (!CollectionUtils.isEmpty(listaDatoItem)){
                             
                         for (DatoItem item : listaDatoItem) {

                             facturaMapa = new HashMap<String, Object>();

                             facturaMapa.put("cod_secitem", item.getNumsecitem());
                             facturaMapa.put("cod_secprove", pkFactu.get("NUM_SECPROVE").toString());
                             facturaMapa.put("cod_factura", factura.getNumfactura());
                             facturaMapa.put("cod_secfact", factura.getNumsecfactu());
                             facturaMapa.put("cod_partida", item.getNumpartnandi());
                             facturaMapa.put("des_fecha", SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT)  );
                             facturaMapa.put("des_monto", item.getMtofobitem());
                           //amancill apase pulpin
                           facturaMapa.put("cod_incoterm", ((DatoFactura)item.getPadre()).getCodincoterm());
                           facturaMapa.put("dir_lugartrans", ((DatoFactura)item.getPadre()).getDeslugtrans());
                           facturaMapa.put("cod_moneda_desc", ((DatoFactura)item.getPadre()).getCodmoneda());
                           facturaMapa.put("cod_paisembarque_desc", ((DatoFactura)item.getPadre()).getCodpaisembar());



                             facturaMapa.put("desc_descripcion", item.getDescomercial());
                           facturaMapa.put("desc_marca", item.getDesmarca());
                           facturaMapa.put("monto_fob_unitario", item.getMtofobunita());
                           facturaMapa.put("monto_fob_item", item.getMtofobitem());
                           facturaMapa.put("desc_cantidad", item.getCntcantcomer());
                    facturaMapa.put("desc_unicomer", this.obtenerDescripcionPorCatalogo("29",item.getCodunidcomer()));
                    facturaMapa.put("correlacion","--");
                             listado.add(facturaMapa);
                         }
                        }
                     }

                 }
               }
            }
         }

     }

     return listado;
   }
  

  /** Obtiene datos de las facturas y sus Proveedores para Portal Web
   * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
   * @return
   */// P34-3014 formatoB-Inicial
   public List<Map<String, Object>> obtenerFacturasProveedoresInicial(Declaracion declaracionInicialBean)  throws ServiceException{
      
      List<Map<String, Object>> listado = new ArrayList<Map<String,Object>>();
      Map<String, Object> facturaProveedor = null;
      if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

          int nroProveedores = declaracionInicialBean.getListDAVs().size();
          DUA dua = declaracionInicialBean.getDua();
          
          //HAcostaR Inicio - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
          CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
          String COD_CATALOGO = "CC1";
          String COD_DATACATALOGO = "001278";
          String MSJ_LEY_29733 = "No Disponible - Ley 29733";
          DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(COD_CATALOGO, COD_DATACATALOGO, null);
          Boolean vig001278 = false;
          //Control de Cambio no se encuentra vigente
          if(null!=dataCatalogo)
        	  vig001278 = true;
          //HAcostaR Fin - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
          
          for (int i = 0; i < nroProveedores; i++) {

              if (declaracionInicialBean.getListDAVs().get(i).getProveedor() != null) {

                  DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
                                    
                  Elementos<DatoFactura> listaFactura = otrosDatosProveedor.getListFacturas();
                  if (listaFactura != null) {

                      for (DatoFactura factura : listaFactura) {

                          if (factura != null) {
                        	  facturaProveedor = new HashMap<String, Object>();
                        	  facturaProveedor.put("num_secprove", otrosDatosProveedor.getNumsecuprov());
                        	  facturaProveedor.put("nom_razonsocial_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getNombreRazonSocial():"");
                        	  facturaProveedor.put("dir_partic_prv", otrosDatosProveedor.getProveedor()!=null ? otrosDatosProveedor.getProveedor().getDireccion():"");
                        	  facturaProveedor.put("nom_cargo", otrosDatosProveedor.getNomcargdecla());
                        	  facturaProveedor.put("cod_natutrans_desc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_NATURALEZA_TRANSACCION, otrosDatosProveedor.getCodnatutrans()));
                        	  facturaProveedor.put("num_factura", factura.getNumfactura());
                        	  facturaProveedor.put("fech_factura", SunatDateUtils.getFormatDate(factura.getFecfactura(), FechaBean.FORMATO_DEFAULT));
                        	  facturaProveedor.put("num_secfact", factura.getNumsecfactu());
                        	  
                              /*****Importador*****/
                              Participante importador = dua.getDeclarante();
                              
                              String tipoDocumento =  importador!=null ?(importador.getTipoDocumentoIdentidad()!=null?importador.getTipoDocumentoIdentidad().getCodDatacat():""):"";
                              
                              //HAcostaR Inicio - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
                              //String descNumDocIden = importador.getNumeroDocumentoIdentidad();
                              String descNumDocIden = importador!=null ?(importador.getNumeroDocumentoIdentidad()!=null?importador.getNumeroDocumentoIdentidad():""):"";
                              if(vig001278 && dua.getCodregimen().equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_REGIMEN_10) 
                            		  && ( ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(tipoDocumento) || ConstantesDataCatalogo.TIPO_DOCUMENTO_PASAPORTE.equals(tipoDocumento) 
                            				|| (ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumento) && ( descNumDocIden.startsWith("10") || descNumDocIden.startsWith("15") || descNumDocIden.startsWith("17") )) )){
                            	  facturaProveedor.put("nom_razonsocial_importador", MSJ_LEY_29733);
                              }else{
                              //HAcostaR Fin - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES
                              
                             facturaProveedor.put("nom_razonsocial_importador", importador.getNombreRazonSocial());
                             if (!Utilidades.esNuloOVacio(tipoDocumento) && !Utilidades.esNuloOVacio(descNumDocIden)
                                  && (Utilidades.esNuloOVacio(importador.getNombreRazonSocial())) ){

                               if (Constantes.TIPO_DOC_DNI.equals(tipoDocumento.trim())
                                   || Constantes.TIPO_DOC_RUC.equals(tipoDocumento.trim())){
                                 Map pers = this.soporteService.obtenerPerNatJur(tipoDocumento.trim(),
                                         descNumDocIden);

                                 if(Utilidades.esNuloOVacio(importador.getNombreRazonSocial()) ){
                                     facturaProveedor.put("nom_razonsocial_importador", tipoDocumento.concat("-").concat(descNumDocIden).concat(" ").concat(pers.get("nombre").toString()));
                                 }else{
                                     facturaProveedor.put("nom_razonsocial_importador", tipoDocumento.concat("-").concat(descNumDocIden).concat(" ").concat(importador.getNombreRazonSocial()));
                                 }
                               }
                             }
                              }//HAcostaR - M_SNADE193-2 LEY DE PROTECCION DE DATOS PERSONALES

                        	  facturaProveedor.put("numero_dua", dua.getCodaduanaorden().concat("-").concat(dua.getCodregimen()));
                        	  facturaProveedor.put("canal", dua.getCodCanal());
                        	  
                        	  listado.add(facturaProveedor);
                          }
                      }
                  }
              }
          }

      }
      
      return listado;
  }
   
  /** Obtiene datos del Item del formato B inicial (del archivo zip numerado inicialmente)
  * @param declaracionInicialBean
  * @param pkParametros
  * @return
  * @throws ServiceException
  */
  public Map<String,Object> obtenerDatosItemFactura(Declaracion declaracionInicialBean,  Map pkParametros)  throws ServiceException{
      
      Map<String, Object> itemMapa = new HashMap<String,Object>();
      
      if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

          if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

              int nroProveedores = declaracionInicialBean.getListDAVs().size();

              for (int i = 0; i < nroProveedores; i++) {

                   DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);

                   if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkParametros.get("NUM_SECPROVE").toString())){
                       
                       if(!CollectionUtils.isEmpty(otrosDatosProveedor.getListFacturas())){
                           for(DatoFactura factura : otrosDatosProveedor.getListFacturas()){
                               
                               if (factura != null && factura.getNumsecfactu().toString().equals(pkParametros.get("NUM_SECFACT").toString()) ) {
                                  
                                   if (factura != null) {

                                       Elementos<DatoItem> listaDatoItem = factura.getListItems();

                                           for (DatoItem item : listaDatoItem) {
                                               if(item.getNumsecitem().toString().equals(pkParametros.get("NUM_SECITEM").toString())){
                                                   
                                                   itemMapa = new HashMap<String, Object>();    
                                                   itemMapa.put("num_secprov", pkParametros.get("NUM_SECPROVE").toString());
                                                   itemMapa.put("num_secfact", pkParametros.get("NUM_SECFACT").toString());
                                                   itemMapa.put("num_secitem", item.getNumsecitem());
                                                   itemMapa.put("pais_origen", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, item.getCodpaisorige()));
                                                   itemMapa.put("pais_embarque", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_PAIS, factura.getCodpaisembar()));
                                                   itemMapa.put("ind_deduccion", item.getInddeducdisti());
                                                   itemMapa.put("mto_fobunitario", item.getMtofobunita());
                                                   itemMapa.put("mto_fobItem", item.getMtofobitem());
                                                   itemMapa.put("mto_ajusteUnit", item.getMtoajusunita());
                                                   itemMapa.put("inf_verif", null);//FIXME
                                                   itemMapa.put("cantidad_comercial", item.getCntcantcomer());
                                                   itemMapa.put("des_marca", item.getDesmarca());
                                                   itemMapa.put("nom_producto", item.getNombre());
                                                   itemMapa.put("des_modelo", item.getDesmodelo());
                                                   itemMapa.put("desc_estmerc", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_ESTADO_MERCANCIA, item.getCodestamer()));
                                                   itemMapa.put("des_indsoftware", item.getIndsoftware());
                                                   itemMapa.put("cod_producto", item.getCodproducto());
                                                   itemMapa.put("num_partida", Utilidades.validarNuloOVacioRetornaString(item.getNumpartnandi()));
                                                   itemMapa.put("descripcion", item.getDescaracteristicas());
                                                   itemMapa.put("observaciones", this.obtenerObservaciones(item));
                                                   itemMapa.put("nombre_producto", item.getNombre());
                                                   itemMapa.put("tipo_valor", item.getMontoProv().getIndtipovalor());
                                                   itemMapa.put("desc_uniComer", this.obtenerDescripcionPorCatalogo(Constantes.CODIGO_UNIDAD_COMERCIAL, item.getCodunidcomer()));
                                                   itemMapa.put("des_annfabricacion", item.getAnnfabrica());
                                                   itemMapa.put("post_inf_ver", null);//FIXME

                                                   break;
                                           }
                                       }
                                   }
                                   
                               }     
                           }
                       }

                      break; 
                   }
              }     
          }

      }
      
      return itemMapa;

  }
  
  /** Obtiene las observaciones de un item, pasa los datos de una lista a un string
  * @param item [DatoItem]
  * @return
  */// P34-3014 formatoB-Inicial
  private String obtenerObservaciones(DatoItem item){
      String observacion = "";
      Elementos<Observacion> lstObservaciones = item.getListObservaciones();
      for(Observacion obser : lstObservaciones){
          if(obser.getCodtipobserva().equals(Constantes.TIPO_OBSERVACION_ITEM_FB)
             && obser.getNumsecitem()!=null && obser.getNumsecitem().equals(item.getNumsecitem())){
              observacion = observacion + obser.getObsdeclaracion()+"\n";
          }
          
      }
      return observacion;
  }
  /** Obtiene la descripcion de un catalogo
  * @param codCatalogo [String]
  * @param codDatacat [String]
  * @return
  */// P34-3014 formatoB-Inicial
  private String obtenerDescripcionPorCatalogo(String codCatalogo, String codDatacat){
      
      String descripcionCorta = "";
      if(!Utilidades.esNuloOVacio(codDatacat)){
          DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(codCatalogo, codDatacat);
          descripcionCorta = dataCatalogo.getDesCorta();
      }
      return descripcionCorta;
  }
 
  /** Carga las condiciones de la transaccion
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param pkSerie [Map] secuencial del proveedor
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String, Object> obtieneCondicionesTransaccion(Declaracion declaracionInicialBean, Map pkParametros) throws ServiceException{
     
     Map<String, Object> mapDatos = new HashMap<String,Object>();
     
     if (!CollectionUtils.isEmpty(declaracionInicialBean.getListDAVs())) {

         int nroProveedores = declaracionInicialBean.getListDAVs().size();

         for (int i = 0; i < nroProveedores; i++) {

              DAV otrosDatosProveedor = declaracionInicialBean.getListDAVs().get(i);
              mapDatos = new HashMap<String, Object>();
                
              if(otrosDatosProveedor.getNumsecuprov().toString().equals(pkParametros.get("NUM_SECPROVE").toString())){
                  mapDatos = this.listCondTransacToMapDelBean(
                          otrosDatosProveedor.getListCondTransacciones(), "COD_CONDICION",
                          "INDICADOR");
                 break; 
              }
              
         }

     }

     return mapDatos;
  }

  /** Carga la lista de condiciones de la transaccion en un objeto Map<String, Object> a partir de una lista
  * @param declaracionInicialBean [Declaracion] datos de la Declaracion, proveedores, facturas, items, descripciones minimas
  * @param cmpKey [String] clave
  * @param cmpValue [String] valor
  * @return
  */// P34-3014 formatoB-Inicial
  private Map<String, Object> listCondTransacToMapDelBean( Elementos<DatoCondTransaccion> lstEval, String cmpKey, String cmpValue){
   Map<String, Object> res = new HashMap<String, Object>();

   if (!CollectionUtils.isEmpty(lstEval))
   {
     for(DatoCondTransaccion condicion: lstEval){
         res.put(condicion.getCodindcondtra(), condicion.getIndcondtra());
     }
   }

   return res;
  }

  
  // P34-3014-FIN
  
  /***********************SET DE SPRING **********************************/


  /**
   * Sets the item factura dao.
   *
   * @param itemFacturaDAO
   *          the new item factura dao
   */
  public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO)
  {
    this.itemFacturaDAO = itemFacturaDAO;
  }

  /**
   * Sets the form b proveedor dao.
   *
   * @param formBProveedorDAO
   *          the new form b proveedor dao
   */
  public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
  {
    this.formBProveedorDAO = formBProveedorDAO;
  }

  /**
   * Sets the comprob pago dao.
   *
   * @param comprobPagoDAO
   *          the new comprob pago dao
   */
  public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO)
  {
    this.comprobPagoDAO = comprobPagoDAO;
  }

  /**
   * Sets the participante dao.
   *
   * @param participanteDAO
   *          the new participante dao
   */
  public void setParticipanteDAO(ParticipanteDocDAO participanteDAO)
  {
    this.participanteDAO = participanteDAO;
  }

  /**
   * Sets the condicion transa dao.
   *
   * @param condicionTransaDAO
   *          the new condicion transa dao
   */
  public void setCondicionTransaDAO(CondicionTransaDAO condicionTransaDAO)
  {
    this.condicionTransaDAO = condicionTransaDAO;
  }

  /**
   * Sets the form b monto dao.
   *
   * @param formBMontoDAO
   *          the new form b monto dao
   */
  public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO)
  {
    this.formBMontoDAO = formBMontoDAO;
  }

  /**
   * Sets the series item dao.
   *
   * @param seriesItemDAO
   *          the new series item dao
   */
  public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO)
  {
    this.seriesItemDAO = seriesItemDAO;
  }

  /**
   * Sets the form a factu dao.
   *
   * @param formAFactuDAO
   *          the new form a factu dao
   */
  public void setFormAFactuDAO(FormaFactuDAO formAFactuDAO)
  {
    this.formAFactuDAO = formAFactuDAO;
  }

  /**
   * Sets the referencia duda dao.
   *
   * @param referenciaDudaDAO
   *          the new referencia duda dao
   */
  public void setReferenciaDudaDAO(ReferenciaDudaDAO referenciaDudaDAO)
  {
    this.referenciaDudaDAO = referenciaDudaDAO;
  }

  /**
   * Sets the catalogo ayuda service.
   *
   * @param catalogoAyudaService
   *          the new catalogo ayuda service
   */
  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  /**
   * Sets the soporte service.
   *
   * @param soporteService
   *          the new soporte service
   */
  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

  /**
   * Gets the fabrica de servicios.
   *
   * @return the fabrica de servicios
   */
  public FabricaDeServicios getFabricaDeServicios()
  {
    return this.fabricaDeServicios;
  }

  /**
   * Sets the fabrica de servicios.
   *
   * @param fabricaDeServicios
   *          the new fabrica de servicios
   */
  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }

  /**
   * Gets the swapper datasource.
   *
   * @return the swapper datasource
   */
  public HotSwappableTargetSource getSwapperDatasource()
  {
    return this.swapperDatasource;
  }

  /**
   * Sets the swapper datasource.
   *
   * @param swapperDatasource
   *          the new swapper datasource
   */
  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }

  /**
   * Sets the vehi cetico dao.
   *
   * @param vehiCeticoDAO
   *          the new vehi cetico dao
   */
  public void setVehiCeticoDAO(VehiCeticoDAO vehiCeticoDAO)
  {
    this.vehiCeticoDAO = vehiCeticoDAO;
  }

  /**
   * Sets the cab adi impo consu dao.
   *
   * @param cabAdiImpoConsuDAO
   *          the new cab adi impo consu dao
   */
  public void setCabAdiImpoConsuDAO(CabAdiImpoConsuDAO cabAdiImpoConsuDAO)
  {
    this.cabAdiImpoConsuDAO = cabAdiImpoConsuDAO;
  }

  /**
   * Sets the factu suce dao.
   *
   * @param factuSuceDAO
   *          the new factu suce dao
   */
  public void setFactuSuceDAO(FactuSuceDAO factuSuceDAO)
  {
    this.factuSuceDAO = factuSuceDAO;
  }

  /**
   * Sets the form b item descri dao.
   *
   * @param formBItemDescriDAO
   *          the new form b item descri dao
   */
  public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO)
  {
    this.formBItemDescriDAO = formBItemDescriDAO;
  }

  /**
   * Sets the monto gasto dao.
   *
   * @param montoGastoDAO
   *          the new monto gasto dao
   */
  public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO)
  {
    this.montoGastoDAO = montoGastoDAO;
  }

  /**
   * Sets the observacion dao.
   *
   * @param observacionDAO
   *          the new observacion dao
   */
  public void setObservacionDAO(ObservacionDAO observacionDAO)
  {
    this.observacionDAO = observacionDAO;
  }

  public void setvFOBProvisionalDAO(VFOBProvisionalDAO vFOBProvisionalDAO) {
	this.vFOBProvisionalDAO = vFOBProvisionalDAO;
  }
}
