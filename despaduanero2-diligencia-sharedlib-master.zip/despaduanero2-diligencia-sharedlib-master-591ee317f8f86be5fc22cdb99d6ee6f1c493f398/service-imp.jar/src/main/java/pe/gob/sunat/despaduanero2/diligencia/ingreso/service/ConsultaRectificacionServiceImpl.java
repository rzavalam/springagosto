package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
// RIN16
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.bean.DatoRectificado;
import pe.gob.sunat.despaduanero2.bean.RectificacionOficio;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;
// RIN16
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils; //pase42
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
// RIN16
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

@SuppressWarnings(
{ "unchecked", "rawtypes" })
public class ConsultaRectificacionServiceImpl implements
                                             ConsultaRectificacionService
{

  protected final Log                     log = LogFactory.getLog(this.getClass());

  private SolicitudRectificacionesService solicitudRectificacionesService;

  private CasillaFormatoService           casillaFormatoService;
  private CatalogoAyudaService            catalogoAyudaService;

  private RectiOficioDAO                  rectiOficioDAO;
  private SolicitudService                solicitudService;
// RIN16
  private FabricaDeServicios       fabricaDeServicios;

  /**
   * {@inheritDoc}
   */
  public List<SolicitudRectifica> consultaDiligenciaRectificacion(
                                                                  Long numeroCorrelativoDua)
  {

    List<SolicitudRectifica> listaSolicituRectifica =
                                                      solicitudRectificacionesService.listSolicitudesRectificaByDua(new BigDecimal(
                                                                                                                                   numeroCorrelativoDua.toString()));
    // ordenar de forma ascedente por fecha de solicitud
    Collections.sort(listaSolicituRectifica, new Comparator()
    {
      public int compare(Object objSolicitudRectifica1, Object objSolicitudRectifica2)
      {
        SolicitudRectifica solicitudRectifica1 = (SolicitudRectifica) objSolicitudRectifica1;
        SolicitudRectifica solicitudRectifica2 = (SolicitudRectifica) objSolicitudRectifica2;
        return solicitudRectifica1.getFechaSolicitud().compareTo(solicitudRectifica2.getFechaSolicitud());
      }
    });
    // eliminamos las que que esten en estado 02 � 04

    return listaSolicituRectifica;
  }

  /**
   * {@inheritDoc}
   */
  public Diligencia consultaDiligencia(Diligencia diligencia)
  {
    Validate.notNull(diligencia.getNumeroCorrelativo(), "No se esta enviando el numero correlativo de la dua");
    Validate.notNull(diligencia.getNumeroCorrelativoSolicitud(),
                     "No se esta enviando el numero correlativo de la solicitud de rectificacion");
    Diligencia respuesta = this.solicitudRectificacionesService.findDiligenciaByPk(diligencia);

    FiltroCatEmpleado filtro = new FiltroCatEmpleado();
    filtro.setCodPers(respuesta.getCodigoFuncionario());
    // Agregamos la descripci�n del funcionario
    Map<String, CatEmpleado> mapCatEmpleado = this.solicitudService.buscarMapCatEmpleado(filtro);

    CatEmpleado catEmpleadoTemp = (CatEmpleado) mapCatEmpleado.get(respuesta.getCodigoFuncionario());

    StringBuilder sbFullNameEmpleado = new StringBuilder();
    sbFullNameEmpleado.append(catEmpleadoTemp.getNombres());
    sbFullNameEmpleado.append(" ");
    sbFullNameEmpleado.append(catEmpleadoTemp.getApPate());
    sbFullNameEmpleado.append(" ");
    sbFullNameEmpleado.append(catEmpleadoTemp.getApMate());

    respuesta.setNombreFuncionario(sbFullNameEmpleado.toString());

    Validate.notNull(respuesta,
                     "La dua no cuenta con diligencia para la solcitud con numero correlativo: " + diligencia.getNumeroCorrelativoSolicitud());

    return respuesta;
  }

  /**
   * {@inheritDoc}
   */
  public List<DatoRectificado> consultaDatosRectificados(Diligencia diligencia)
  {
    List<DatoRectificado> lstDatosRectificados = null;
    Validate.notNull(diligencia.getNumeroCorrelativoSolicitud(),
                     "No se esta enviando el numero correlativo de la solicitud de rectificacion");
    RectificacionOficio rectificacionOficio = new RectificacionOficio(diligencia.getNumeroCorrelativo(),
                                                                      diligencia.getNumeroCorrelativoSolicitud());
    List<RectificacionOficio> lstRectificacionOficio = rectiOficioDAO.findByPrimaryKey(rectificacionOficio);
    //INC 2016-056530 Se ha depurado codigo que no correspondia, el sistema debe mostrar los valores de det_ofirecti solamente

    lstDatosRectificados = transformRectiOficioToDatoRectificado(lstRectificacionOficio);

    Validate.notEmpty(lstDatosRectificados, "La diligencia no tiene datos rectificados"); 
    return lstDatosRectificados;
  }
 
  //Lmvr- inicio - Complemento de rectificacion
  @Override
  public List<DatoRectificado> consultaDatosRectificacionAutomatica(
  		Long numCorredoc) {
	    List<DatoRectificado> lstDatosRectificados = null;
	    DetSolRectiDAO detSolRectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");
		Map paramsMap = new HashMap();
		paramsMap.put("numeroCorrelativo", numCorredoc);
		List<RectificacionOficio> lstRectificacionAutomatica = detSolRectiDAO.listDetallesByParams(paramsMap);
				
        	//lstDatosRectificados = transformRectiOficioToDatoRectificado(lstRectificacionAutomatica);
		lstDatosRectificados = transformRectiAutoToDatoRectificado(lstRectificacionAutomatica);//Modificado por PASE 399 - bug 19826
	    Validate.notEmpty(lstDatosRectificados, "No tiene datos rectificados");

	    return lstDatosRectificados;
		
  }
   
/*Inicio cambios para Pase 399 - bug 19826*/
  /**
   * Metodo que transfroma una coleccion de RectificacionOficio a una coleccion
   * de dato rectificado
   *
   * @param lstRectificacionOficio
   * @return
   */
  private List<DatoRectificado> transformRectiAutoToDatoRectificado(
		  List<RectificacionOficio> lstRectificacionOficio)
  {
    List<DatoRectificado> lstDatosRectificados = new ArrayList<DatoRectificado>();
    for (RectificacionOficio rectificacionOficio : lstRectificacionOficio)
    {

      lstDatosRectificados.addAll(transformRectiAutoToDatoRectificado(rectificacionOficio));
    }
    return lstDatosRectificados;
  }
  
  /**Creado por pase 399
   * Metodo que transforma un registro de RectificacionAutomatica det_solrecti a una coleccion de
   * datorectificado
   *
   * @param rectificacionOficio
   *          registro en rectificacion autom�tica
   * @return
   */
  private List<DatoRectificado> transformRectiAutoToDatoRectificado(
                                                                      RectificacionOficio rectificacionOficio)
  {
    String sinonimoTabla =
                           catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_CODIGICACION_TABLA_NSIGAD,
                                                                           rectificacionOficio.getCodigotabla());
    String indicadorAccion = rectificacionOficio.getIndRectifica();//este indicador se carga solo para recti automatica.
    return transformToDatoRectificado(sinonimoTabla, rectificacionOficio.getUniqueKeyAsJson(),
                                      rectificacionOficio.getDatoHistoricoAsJson(),
                                      rectificacionOficio.getDatoRectificadoAsJson(), indicadorAccion);
  }
  
  
  
/*Fin cambios para Pase 399 - bug 19826*/ 

  //Lmvr- fin - Complemento de rectificacion
  
  /**
   * Metodo que transfroma una coleccion de RectificacionOficio a una coleccion
   * de dato rectificado
   *
   * @param lstRectificacionOficio
   * @return
   */
  private List<DatoRectificado> transformRectiOficioToDatoRectificado(
		  List<RectificacionOficio> lstRectificacionOficio)
  {
    List<DatoRectificado> lstDatosRectificados = new ArrayList<DatoRectificado>();
    for (RectificacionOficio rectificacionOficio : lstRectificacionOficio)
    {

      lstDatosRectificados.addAll(transformRectiOficioToDatoRectificado(rectificacionOficio));
    }
    return lstDatosRectificados;
  }

  /**
   * Metodo que transfroma un registro de RectificacionOficio a una coleccion de
   * datorectificado
   *
   * @param rectificacionOficio
   *          registro en rectificacion oficio
   * @return
   */
  private List<DatoRectificado> transformRectiOficioToDatoRectificado(
                                                                      RectificacionOficio rectificacionOficio)
  {
    String sinonimoTabla =
                           catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_CODIGICACION_TABLA_NSIGAD,
                                                                           rectificacionOficio.getCodigotabla());
    String indicadorAccion = rectificacionOficio.getIndicadorAccion();
    return transformToDatoRectificado(sinonimoTabla, rectificacionOficio.getUniqueKeyAsJson(),
                                      rectificacionOficio.getDatoHistoricoAsJson(),
                                      rectificacionOficio.getDatoRectificadoAsJson(), indicadorAccion);
  }

  public void setSolicitudRectificacionesService(
                                                 SolicitudRectificacionesService solicitudRectificacionesService)
  {
    this.solicitudRectificacionesService = solicitudRectificacionesService;
  }


  /**
   * Metodo que transforma los valores en formato json a un formato Object de
   * forma desagregada (a nivel de campos)
   *
   * @param sinonimoTabla
   *          sinonimo de la tabla rectificada
   * @param uniqueKeyJson
   *          clave unica de la tabla rectificada
   * @param valorHistoricoJson
   *          valores antes de la rectificacion en fromato JSON
   * @param valorRectificadoJson
   *          valores rectificados en fromato JSON
   * @param indicadorAccion
   *          N nuevo registro, R rectificado A anulado
   * @return lista de Datos rectificados (retorna los datos rectificados a nivel
   *         de campos)
   */
  public List<DatoRectificado> transformToDatoRectificado(String sinonimoTabla,
                                                          String uniqueKeyJson,
                                                          String valorHistoricoJson,
                                                          String valorRectificadoJson,
                                                          String indicadorAccion)
  {
    List<DatoRectificado> listDatoRectificado = new ArrayList<DatoRectificado>();

    Map mapClave = (Map) SojoUtil.fromJson(uniqueKeyJson);
    String primaryKeyMostrar = casillaFormatoService.generaClaveMostrar(mapClave, sinonimoTabla);

    // nombres de campos personalizados para algunas tablas

    sinonimoTabla =
                    "PARTICIPANTE_DOC".equals(sinonimoTabla) ? sinonimoTabla + "_" + mapClave.get("COD_TIPPARTIC")
                                                            : sinonimoTabla;

    // OBS_OBS
    //gmontoya Pase 42-17022015
    if (("OBSERVACION".equals(sinonimoTabla)) && indicadorAccion.equals("N") && ("05".equals(mapClave.get("COD_TIPOBS"))))
    {
//      sinonimoTabla = sinonimoTabla + "_" + mapClave.get("COD_TIPOBS");
    	return listDatoRectificado;
    }
    
    if (("DOCAUT_ASOCIADO".equals(sinonimoTabla)) && indicadorAccion.equals("N")){
    	String cadena = valorRectificadoJson;    		
		int pos = cadena.indexOf("COD_TIPDOCASO");
		if (pos >= 0) {
			String valor = cadena.substring(pos + 16);
			valor = valor.substring(0, valor.indexOf("\""));
			if (valor.equals("26") || valor.equals("38")) {
				return listDatoRectificado;
			}		
		}
    }
	//fin gmontoya Pase 42-17022015
    
    
    if ("R".equals(indicadorAccion))
    {
      Map<String, Object> valorRectificadoMap =
                                                (Map<String, Object>) serializer.deserialize(StringUtils.isBlank(valorRectificadoJson)
                                                                                                                                      ? "{}"
                                                                                                                                      : valorRectificadoJson);
      Map<String, Object> valorHistoricoMap =
                                              (Map<String, Object>) serializer.deserialize(StringUtils.isBlank(valorHistoricoJson)
                                                                                                                                  ? "{}"
                                                                                                                                  : valorHistoricoJson);
      for (String campo : valorHistoricoMap.keySet())
      {

        Map casillaFormato = casillaFormatoService.buscarDescripcion(sinonimoTabla, campo);
        String seccionDesc = ObjectUtils.toString(casillaFormato.get("NOM_SECCION"), "No registrado");
        String columnaDesc = ObjectUtils.toString(casillaFormato.get("NOM_CASILLA"), campo);

        String valorRectificado = ObjectUtils.toString(valorRectificadoMap.get(campo), "");
        String valorHistorico = ObjectUtils.toString(valorHistoricoMap.get(campo), "");
        // creamos el dato rectificado
        DatoRectificado datoRectificado = new DatoRectificado();
        datoRectificado.setSeccion(seccionDesc);
        datoRectificado.setDescripcionCampo(columnaDesc);
        datoRectificado.setValorRectificado(valorRectificado);
        datoRectificado.setValorHistorico(valorHistorico);
        datoRectificado.setIndRectificado(indicadorAccion);
        datoRectificado.setPrimaryKey(primaryKeyMostrar);
        //RIN16-PASS400
        //Se esta enviando el Sinonimo a usar para hallar las descripciones minimas en tabla Datos Modificados de diligencia-Regularizacion
        datoRectificado.setCodigoTabla(sinonimoTabla);
        // agregamos el dato rectificado al retorno
        listDatoRectificado.add(datoRectificado);
      }
    }
    else
    {
      Map casillaFormato = casillaFormatoService.buscarDescripcion(sinonimoTabla, "");
      String seccionDesc = ObjectUtils.toString(casillaFormato.get("NOM_SECCION"), "No registrado");
      String columnaDesc = ObjectUtils.toString(casillaFormato.get("NOM_CASILLA"), "");

      String valorRectificado = " ";
      if (!StringUtils.isBlank(valorRectificadoJson))
      {
        Map mapValorRectificado = (Map) SojoUtil.fromJson(valorRectificadoJson);
        valorRectificado = casillaFormatoService.generaClaveMostrar(mapValorRectificado, sinonimoTabla);
      }

      String valorHistorico = " ";
      if (!StringUtils.isBlank(valorHistoricoJson))
      {
        Map mapValorHistorico = (Map) SojoUtil.fromJson(valorHistoricoJson);
        valorHistorico = casillaFormatoService.generaClaveMostrar(mapValorHistorico, sinonimoTabla);
      }
      /**BUG 20478 PASE 399*/
      if ("N".equals(indicadorAccion) && "CONVENIO_SERIE".equals(sinonimoTabla) && StringUtils.isBlank(valorRectificadoJson))
      {
        Map mapValorRectificado = (Map) SojoUtil.fromJson(uniqueKeyJson);
        //valorRectificado = casillaFormatoService.generaClaveMostrar(mapValorRectificado, sinonimoTabla);
        valorRectificado = SunatStringUtils.toStringObj(mapValorRectificado.get("COD_CONVENIO"));//BUG 21823 P46-INSI
      }
      /**BUG 20478 PASE 399*/
      
      /**P46-INSI - Inicio*/      
      if ("A".equals(indicadorAccion) && "CONVENIO_SERIE".equals(sinonimoTabla) && StringUtils.isBlank(valorHistoricoJson))
      {
        Map mapValorHistorico = (Map) SojoUtil.fromJson(uniqueKeyJson);
        //valorHistorico = casillaFormatoService.generaClaveMostrar(mapValorHistorico, sinonimoTabla);
        valorHistorico = SunatStringUtils.toStringObj(mapValorHistorico.get("COD_CONVENIO"));//BUG 21823 P46-INSI
      }      
      /**P46-INSI - Fin*/
      
      /**P24 gmontoya inicio*/      
      if ("A".equals(indicadorAccion) && "DOCUPRECE_DUA".equals(sinonimoTabla) && StringUtils.isBlank(valorHistoricoJson))
      {
        Map mapValorHistorico = (Map) SojoUtil.fromJson(uniqueKeyJson);
        Map<String, Object> mapVH = new HashMap<String, Object>();
        for (Object campo : mapValorHistorico.keySet())
        {
	        if(String.valueOf(campo).endsWith("PRE")){
		          Map casillaFormato2 = casillaFormatoService.buscarDescripcion(sinonimoTabla, String.valueOf(campo));
		          String columnaDesc2 = ObjectUtils.toString(casillaFormato2.get("NOM_CASILLA"), String.valueOf(campo));
		          String valorHistorico2 = ObjectUtils.toString(mapValorHistorico.get(campo), "");
		          mapVH.put(columnaDesc2, valorHistorico2);
	        }
        }
        valorHistorico = SojoUtil.toJson(mapVH);
      }      
      /**P24 gmontoya fin*/
      
      /**BUG 21823 P46-INSI - Inicio*/      
      if ("N".equals(indicadorAccion) && "DET_AUTORIZACION".equals(sinonimoTabla) && StringUtils.isBlank(valorRectificadoJson))
      {
        Map mapValorRectificado = (Map) SojoUtil.fromJson(uniqueKeyJson);
        valorRectificado = casillaFormatoService.generaClaveMostrar(mapValorRectificado, sinonimoTabla);
      }      
      /**BUG 21823 P46-INSI - Fin*/  
      /**BUG 22081 P46-INSI - Inicio*/      
      if ("N".equals(indicadorAccion) && "INDICADOR_DUA".equals(sinonimoTabla) && StringUtils.isBlank(valorRectificadoJson))
      {
        Map mapValorRectificado = (Map) SojoUtil.fromJson(uniqueKeyJson);
        //valorRectificado = casillaFormatoService.generaClaveMostrar(mapValorRectificado, sinonimoTabla);        
        valorRectificado = SunatStringUtils.toStringObj(mapValorRectificado.get("COD_INDICADOR"));
        if("06".equalsIgnoreCase(valorRectificado.trim())){
        	valorRectificado = valorRectificado.concat(" - ").concat("Impugnacion Parcial");
        }
        if("07".equalsIgnoreCase(valorRectificado.trim())){
        	valorRectificado = valorRectificado.concat(" - ").concat("Impugnacion Total");
        }        
      }      
      if ("A".equals(indicadorAccion) && "INDICADOR_DUA".equals(sinonimoTabla) && StringUtils.isBlank(valorHistoricoJson))
      {
        Map mapValorHistorico = (Map) SojoUtil.fromJson(uniqueKeyJson);
        //valorHistorico = casillaFormatoService.generaClaveMostrar(mapValorHistorico, sinonimoTabla);
        valorHistorico = SunatStringUtils.toStringObj(mapValorHistorico.get("COD_INDICADOR")); 
        if("06".equalsIgnoreCase(valorHistorico.trim())){
        	valorHistorico = valorHistorico.concat(" - ").concat("Impugnacion Parcial");
        }
        if("07".equalsIgnoreCase(valorHistorico.trim())){
        	valorHistorico = valorHistorico.concat(" - ").concat("Impugnacion Total");
        }        
      }      
      /**BUG 22081 P46-INSI - Fin*/      
      
      // creamos el dato rectificado
      DatoRectificado datoRectificado = new DatoRectificado();
      datoRectificado.setSeccion(seccionDesc);
      datoRectificado.setDescripcionCampo(columnaDesc);
      datoRectificado.setValorRectificado(valorRectificado);
      datoRectificado.setValorHistorico(valorHistorico);
      datoRectificado.setIndRectificado(indicadorAccion);
      datoRectificado.setPrimaryKey(primaryKeyMostrar);
      // agregamos el dato rectificado al retorno
      datoRectificado.setCodigoTabla(sinonimoTabla);
      listDatoRectificado.add(datoRectificado);

    }

    return listDatoRectificado;
  }
  
  private JsonSerializer serializer = new JsonSerializer();

  public void setCasillaFormatoService(CasillaFormatoService casillaFormatoService)
  {
    this.casillaFormatoService = casillaFormatoService;
  }

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {
    this.rectiOficioDAO = rectiOficioDAO;
  }

  public void setSerializer(JsonSerializer serializer)
  {
    this.serializer = serializer;
  }

  public SolicitudService getSolicitudService()
  {
    return solicitudService;
  }

  public void setSolicitudService(SolicitudService solicitudService)
  {
    this.solicitudService = solicitudService;
  }
  //Lmvr- inicio - Complemento de rectificacion
  public FabricaDeServicios getFabricaDeServicios() {
	return fabricaDeServicios;
}

public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
	this.fabricaDeServicios = fabricaDeServicios;
}
  //Lmvr- fin - Complemento de rectificacion

}
