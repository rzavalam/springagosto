package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ComunicacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Created by pruizcr on 19/04/2017.
 * @param <fabricaDeServicios>
 */
@Aspect
public class NotificacionAvisoServiceImpl<fabricaDeServicios>
		implements Advice, MethodBeforeAdvice, AfterReturningAdvice, MethodInterceptor, ThrowsAdvice {
	
	ProceedingJoinPoint joinpoint;
//	private ComunicacionDAO comunicacionDAO;
//	private CabDeclaraDAO cabDeclaraDAO;
	private FabricaDeServicios    fabricaDeServicios;
	
	
	
	public void watchPerformanceAroundAvisos(ProceedingJoinPoint joinpoint)  {
		try {
			//ProceedingJoinPoint joinpoint
			System.out.println("Before running loggingAdvice on method="+joinpoint.toString());
			System.out.println("Agruments Passed=" + Arrays.toString(joinpoint.getArgs()));
			System.out.println(joinpoint.getArgs()[0]);
			long start = System.currentTimeMillis();
			joinpoint.proceed();
			long end = System.currentTimeMillis();
			System.out.println("The performance took " + (end - start)
					+ " milliseconds.");
		} catch (Throwable t) {
			System.out.println("Existe un error en al AOP!");
		}
			Integer servicioId=(Integer) joinpoint.getArgs()[0];
			StringBuffer data= (StringBuffer) joinpoint.getArgs()[1];
			String tipoAviso=(String) joinpoint.getArgs()[2];
			Timestamp fechaPublicacion=(Timestamp) joinpoint.getArgs()[3];
			Timestamp fechaVigencia=(Timestamp) joinpoint.getArgs()[4];
			if(servicioId==182 || servicioId==207|| servicioId==383 ||servicioId==114){
				this.insertComunicacion(servicioId, data,
						tipoAviso, fechaPublicacion, fechaVigencia);
				
			}
			
			
	}
		
	public boolean  insertComunicacion(Integer servicioId, StringBuffer data,
			String tipoAviso, Timestamp fechaPublicacion, Timestamp fechaVigencia){
			boolean  idAviso = false;
			String numeroDeclaracion="";
			String codAduana="";
			String annPresen="";
			String codRegimen="";
			String desNota="";
		    String avisos = data.toString();
		    String numero_dua="";
		    String des_ruc_social="";
			Map listValores = (Map) SojoUtil.fromJson(avisos);
			Map<String, Object> mapComunicacion = new HashMap<String, Object>();	
			Iterator itR = listValores.entrySet().iterator();
			while (itR.hasNext()){
				Map.Entry lvEntryN = (Entry) itR.next();
				String pkCampo = "";
		      	pkCampo =   lvEntryN.getKey().toString();

		      	if(!pkCampo.equals("")&& ( pkCampo.equals("num_declaracion")|| pkCampo.equals("cod_aduana") || 
		      			pkCampo.equals("ann_presen")|| pkCampo.equals("cod_regimen")   )){
		      		mapComunicacion.put(lvEntryN.getKey().toString(), lvEntryN.getValue().toString());
		      		numeroDeclaracion=mapComunicacion.get("num_declaracion")!=null?mapComunicacion.get("num_declaracion").toString():"";
		      		codAduana=mapComunicacion.get("cod_aduana")!=null?mapComunicacion.get("cod_aduana").toString():" ";
		      		annPresen=mapComunicacion.get("ann_presen")!=null?mapComunicacion.get("ann_presen").toString():" ";
		      		codRegimen=mapComunicacion.get("cod_regimen")!=null?mapComunicacion.get("cod_regimen").toString():"";
		      		desNota=des_ruc_social;
		      		if(SunatStringUtils.isEmpty(desNota)){
		      			desNota="Notificaciones de Valor Provisional";
		      		}
		      	}else if (pkCampo.equals("numero_dua")){

						numero_dua = lvEntryN.getValue().toString();
						
						numeroDeclaracion = SunatStringUtils.substring(numero_dua, 12, 18);
						codAduana = SunatStringUtils.substring(numero_dua, 0, 3);
						annPresen = SunatStringUtils.substring(numero_dua, 4, 8);
						codRegimen = SunatStringUtils.substring(numero_dua, 9, 11);
						desNota=des_ruc_social;
			      		if(SunatStringUtils.isEmpty(desNota)){
			      			desNota="Notificaciones de Legajo";
			      		}
				}else if(pkCampo.equals("des_ruc_razon_social_importador")) {
					des_ruc_social=lvEntryN.getValue().toString();
					desNota=des_ruc_social;
					if(SunatStringUtils.isEmpty(desNota)){
		      			desNota="Notificaciones de Legajo";
		      		}
				}else{
					continue;
				}
		      	
			}
				
			
			
				//1. Encontrar el num_corredoc del aviso
				Map<String, Object> parameterMap = new HashMap<String, Object>();
				parameterMap.put("NUM_DECLARACION", numeroDeclaracion);
				parameterMap.put("COD_ADUANA", codAduana);
				parameterMap.put("ANN_PRESEN", annPresen);
				parameterMap.put("COD_REGIMEN",codRegimen);
				//DUA dua = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDUAByMap(parameterMap);
				CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
				String numCorreDocDeclaracion="";
				numCorreDocDeclaracion = cabDeclaraDAO.findNumCorreDocByDeclaracion(parameterMap)!=null?cabDeclaraDAO.findNumCorreDocByDeclaracion(parameterMap):"";

			if(!numCorreDocDeclaracion.isEmpty()){	
				parameterMap.put("COD_ESTREV",  "12");
				parameterMap.put("num_corredoc",numCorreDocDeclaracion);
				parameterMap.put("num_corredocSol",numCorreDocDeclaracion);
				parameterMap.put("COD_MOTNOTIPROVISIONAL",  "13");
				
				//3. Registrar comunicacion y su detalle
				ComunicacionDAO comunicacionDAO = (ComunicacionDAO)fabricaDeServicios.getService("diligencia.ingreso.comunicacionDef");
		    	Integer numNota = comunicacionDAO.obtenerSiguienteCorrelativo();
		    	Comunicacion comunicacion = new Comunicacion(true);
		    	comunicacion.setNumNota(SunatNumberUtils.getLongFromString(numNota.toString()));
		    	comunicacion.setCodigoNota(Constantes.COD_COMUNICACION_EXTERNA.toString());
		    	comunicacion.setDesNota(desNota);
		    	comunicacion.setIndDetDescNotificacion(Constantes.COD_TIENE_DETALLE_COMUNICACION);
		    	//comunicacion.setCodMotNoti(SunatStringUtils.toStringObj(parameterMap.get("COD_ESTREV")));
		    	comunicacion.setNumCorreDoc(Long.parseLong(numCorreDocDeclaracion));
		    	if (servicioId==182){
		    	 comunicacion.setCodMotNoti(SunatStringUtils.toStringObj(parameterMap.get("COD_ESTREV")));
		    	 comunicacion.setCodTiDiligencia(ConstantesDataCatalogo.COD_DILIG_NOTIFICACION);
		    	}else if(servicioId==114){
		    	 comunicacion.setCodMotNoti(SunatStringUtils.toStringObj(parameterMap.get("COD_MOTNOTIPROVISIONAL")));	
		    	 comunicacion.setCodTiDiligencia(SunatStringUtils.toStringObj(parameterMap.get("COD_MOTNOTIPROVISIONAL")));	
		    	}else{
		    		
		    	}
		    	comunicacion.setNumCorreDocSol(SunatNumberUtils.toLong(0));
		    	comunicacion.setNumeroCorrelativoSolicitud(SunatNumberUtils.toLong(0));
		    	comunicacion.setNumeroNota(SunatNumberUtils.toLong(numNota));
		    	comunicacion.setDescripcionNota(desNota);
		    	
		    	comunicacion.getDiligencia().setNumeroCorrelativo(SunatNumberUtils.toLong(numCorreDocDeclaracion));
		    	comunicacion.getDiligencia().setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV.toString());
		    	comunicacion.getDiligencia().setNumeroCorrelativoSolicitud(SunatNumberUtils.toLong(0));
		    	
		    	try {
		    		comunicacionDAO.insertSelective(comunicacion);
				} catch (Exception e) {
					System.out.println("Corregir el error" + e);
				}
		    	
			}

		 return idAviso;
	}
		
		@Override
		public Object invoke(MethodInvocation invocation) throws Throwable {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void before(Method method, Object[] args, Object target) throws Throwable {
			// TODO Auto-generated method stub
			
		}
		public NotificacionAvisoServiceImpl() {
			
		}
		public NotificacionAvisoServiceImpl(ProceedingJoinPoint joinpoint) {
			this.joinpoint = joinpoint;
		}

//		public ComunicacionDAO getComunicacionDAO() {
//			return comunicacionDAO;
//		}
//		public void setComunicacionDAO(ComunicacionDAO comunicacionDAO) {
//			this.comunicacionDAO = comunicacionDAO;
//		}
//		public CabDeclaraDAO getCabDeclaraDAO() {
//			return cabDeclaraDAO;
//		}
//		public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
//			this.cabDeclaraDAO = cabDeclaraDAO;
//		}
	
		public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
			this.fabricaDeServicios = fabricaDeServicios;
		}
	
}
