package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import static pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo.CATALOGO_TIPO_TRANSACCION_ELECTRONICA;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.common.ObjectUtil;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.util.holder.EnvioBeanHolder;

import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.orquestador.service.OrquestadorService;
import pe.gob.sunat.tecnologia.receptor.model.Control;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;

/**
 * Implementacion del servicio de validaciones de Diligencia
 *
 * @author rcalla
 *
 */
public class OrquestadorDiligenciaServiceImpl implements OrquestadorDiligenciaService {

	protected final Log log = LogFactory.getLog(getClass());
	private Declaracion declaracion;
	// EJHM P46
	private Declaracion declaracionBD;
	
	private FabricaDeServicios fabricaDeServiciosOrquestador;
	private CatalogoAyudaService catalogoAyudaService;


	/**
	 * Procesa la Diligencia de Despacho
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> diligenciaDespachoDeclaracion(UsuarioBean usuario) throws Exception {
		Map<String, Object> lstValidacion = new HashMap<String, Object>();
		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, Object> resultado = new HashMap<String, Object>();
		Map<String, String> error = new HashMap<String, String>();
		Mensaje mensaje = null;
		Map<String, ?> datos = null;
		Declaracion declaracionProcesado = null;
		boolean recOk = false;
		String mensajeRespuesta = "";
		try{

			JsonSerializer serializer = new JsonSerializer();
			ObjectUtil util = serializer.getObjectUtil();
			util.addFormatterForType(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"), Date.class);
			String JSONDeclaracion = (String) serializer.serialize(declaracion);
			declaracionProcesado = (Declaracion)serializer.deserialize(JSONDeclaracion, Declaracion.class);
			String tipoTransaccion = declaracionProcesado.getCodtipotrans();
			mensaje = procesarMensaje(declaracionProcesado, declaracionProcesado.getCodaduana(),
					tipoTransaccion, declaracionProcesado.getDua().getCodtipooper(),
					ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA, declaracionProcesado.getDua().getNumdocumento());
			EnvioBeanHolder.set(tipoTransaccion, ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA,
					declaracionProcesado.getDua().getNumdocumento(), declaracionProcesado.getDua().getCodtipooper(), 0L,
					declaracionProcesado.getCodaduana(), "A", null);
			OrquestadorService orquestadorService = (OrquestadorService)fabricaDeServiciosOrquestador.getService("orquestador.orquestadorService");
			datos = orquestadorService.procesaMensaje(mensaje, new Date(), usuario.getNroRegistro(), "A", 0L);
		} catch(Exception ex){
			error = setearError(1, ex.getMessage());
			listaErrores.add(error);
			resultado.put("recOk", recOk);
			resultado.put("mensajeRespuesta", mensajeRespuesta);
			lstValidacion.put("resultado",resultado);
			lstValidacion.put("listaErrores", listaErrores);
			return lstValidacion;
		}
		Throwable lastError = (Throwable)datos.get("lastError");
		listaErrores = (List<Map<String, String>>)datos.get("listaErrores");
		Integer nroErroresNegocio = (Integer)datos.get("nroErroresNegocio");
		Integer nroWarningsNegocio = (Integer)datos.get("nroWarningsNegocio");
		Map respuestaGrabacion = (Map)datos.get("respuestaGrabacion");


		if(respuestaGrabacion != null && !respuestaGrabacion.isEmpty()){
			declaracionProcesado = (Declaracion)respuestaGrabacion.get("declaracion");
		}
		if(lastError != null){
			String descError = null;
			error = new HashMap<String, String>();
			listaErrores = new ArrayList<Map<String,String>>();
			error.put("codTipAlerta", "E");
			error.put("codError", "0x0001");
			if(lastError.getMessage() != null){
				descError = lastError.getMessage();
			} else{
				descError ="No se pudo determinar la causa del Error. Contacte con el Administrador.";
			}
			error.put("desError", descError);
			listaErrores.add(error);
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			recOk = false;
		} else if(nroErroresNegocio != null && nroErroresNegocio.intValue() > 0){
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			recOk = false;
		} else if(nroWarningsNegocio != null && nroWarningsNegocio.intValue() > 0){
			mensajeRespuesta = "El registro de la diligencia se realiz�, pero se encontraron advertencias.";
			recOk = true;
		} else {
			mensajeRespuesta = "El registro de la diligencia se realiz� correctamente.";
			recOk = true;
		}
		if(listaErrores == null){
			listaErrores = new ArrayList<Map<String,String>>();
		}
		resultado.put("recOk", recOk);
		resultado.put("mensajeRespuesta", mensajeRespuesta);
		lstValidacion.put("resultado",resultado);
		lstValidacion.put("listaErrores",listaErrores);
		return lstValidacion;
	}
/*RIN13FSW-INICIO*/

	/**
	 * Procesa la Diligencia con Continuacion de Despacho
	 * 
	 * juazor
	 * 
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> diligenciaContDespachoDeclaracion(UsuarioBean usuario) throws Exception {
		Map<String, Object> lstValidacion = new HashMap<String, Object>();
		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, Object> resultado = new HashMap<String, Object>();
		Map<String, String> error = new HashMap<String, String>();
		Mensaje mensaje = null;
		Map<String, ?> datos = null;
		Declaracion declaracionProcesado = null;
		boolean recOk = false;
		String mensajeRespuesta = "";
		try{

			JsonSerializer serializer = new JsonSerializer();
			ObjectUtil util = serializer.getObjectUtil();
			util.addFormatterForType(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"), Date.class);
			String JSONDeclaracion = (String) serializer.serialize(declaracion);
			declaracionProcesado = (Declaracion)serializer.deserialize(JSONDeclaracion, Declaracion.class);
			String tipoTransaccion = declaracionProcesado.getCodtipotrans();
			mensaje = procesarMensaje(declaracionProcesado, declaracionProcesado.getCodaduana(),
					tipoTransaccion, declaracionProcesado.getDua().getCodtipooper(),
					ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA, declaracionProcesado.getDua().getNumdocumento());
			EnvioBeanHolder.set(tipoTransaccion, ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA,
					declaracionProcesado.getDua().getNumdocumento(), declaracionProcesado.getDua().getCodtipooper(), 0L,
					declaracionProcesado.getCodaduana(), "A", null);
			OrquestadorService orquestadorService = (OrquestadorService)fabricaDeServiciosOrquestador.getService("orquestador.orquestadorService");
			datos = orquestadorService.procesaMensaje(mensaje, new Date(), usuario.getNroRegistro(), "A", 0L);
		} catch(Exception ex){
			error = setearError(1, ex.getMessage());
			listaErrores.add(error);
			resultado.put("recOk", recOk);
			resultado.put("mensajeRespuesta", mensajeRespuesta);
			lstValidacion.put("resultado",resultado);
			lstValidacion.put("listaErrores", listaErrores);
			return lstValidacion;
		}
		Throwable lastError = (Throwable)datos.get("lastError");
		listaErrores = (List<Map<String, String>>)datos.get("listaErrores");
		Integer nroErroresNegocio = (Integer)datos.get("nroErroresNegocio");
		Integer nroWarningsNegocio = (Integer)datos.get("nroWarningsNegocio");
		Map respuestaGrabacion = (Map)datos.get("respuestaGrabacion");


		if(respuestaGrabacion != null && !respuestaGrabacion.isEmpty()){
			declaracionProcesado = (Declaracion)respuestaGrabacion.get("declaracion");
		}
		if(lastError != null){
			String descError = null;
			error = new HashMap<String, String>();
			listaErrores = new ArrayList<Map<String,String>>();
			error.put("codTipAlerta", "E");
			error.put("codError", "0x0001");
			if(lastError.getMessage() != null){
				descError = lastError.getMessage();
			} else{
				descError ="No se pudo determinar la causa del Error. Contacte con el Administrador.";
			}
			error.put("desError", descError);
			listaErrores.add(error);
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			recOk = false;
		} else if(nroErroresNegocio != null && nroErroresNegocio.intValue() > 0){
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			recOk = false;
		} else if(nroWarningsNegocio != null && nroWarningsNegocio.intValue() > 0){
			mensajeRespuesta = "El registro de la diligencia se realiz�, pero se encontraron advertencias.";
			recOk = true;
		} else {
			mensajeRespuesta = "El registro de la diligencia se realiz� correctamente.";
			recOk = true;
		}
		if(listaErrores == null){
			listaErrores = new ArrayList<Map<String,String>>();
		}
		resultado.put("recOk", recOk);
		resultado.put("mensajeRespuesta", mensajeRespuesta);
		lstValidacion.put("resultado",resultado);
		lstValidacion.put("listaErrores",listaErrores);
		return lstValidacion;
	}
	/*RIN13FSW-FIN*/
	/*RIN13INSI*/

	/**
	 * Procesa la Diligencia de Despacho
	 */
	public Map<String, Object> validarServiciosDiligDespacho(UsuarioBean usuario) throws Exception {
		Map<String, Object> lstValidacion = new HashMap<String, Object>();
		List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
		Map<String, Object> resultado = new HashMap<String, Object>();
		Map<String, String> error = new HashMap<String, String>();
		Mensaje mensaje = null;
		Map<String, ?> datos = null;
		Declaracion declaracionProcesado = null;
		boolean valOk = false;
		String mensajeRespuesta = "";
		try {
			JsonSerializer serializer = new JsonSerializer();
			ObjectUtil util = serializer.getObjectUtil();
			util.addFormatterForType(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"), Date.class);
			String JSONDeclaracion = (String) serializer.serialize(declaracion);
			declaracionProcesado = (Declaracion) serializer.deserialize(JSONDeclaracion, Declaracion.class);
			String tipoTransaccion = declaracionProcesado.getCodtipotrans();
			mensaje = procesarMensaje(
					declaracionProcesado,
					declaracionProcesado.getCodaduana(),
					tipoTransaccion,
					declaracionProcesado.getDua().getCodtipooper(),
					ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA,
					declaracionProcesado.getDua().getNumdocumento());
			EnvioBeanHolder.set(tipoTransaccion, ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA, declaracionProcesado.getDua().getNumdocumento(), declaracionProcesado
					.getDua().getCodtipooper(), 0L, declaracionProcesado.getCodaduana(), "A", null);
			OrquestadorService orquestadorService = (OrquestadorService) fabricaDeServiciosOrquestador.getService("orquestador.orquestadorService");
			datos = orquestadorService.procesaMensaje(mensaje, new Date(), usuario.getNroRegistro(), "A", 0L);
		} catch (Exception ex) {
			error = setearError(1, ex.getMessage());
			listaErrores.add(error);
			resultado.put("valOk", valOk);
			resultado.put("mensajeRespuesta", mensajeRespuesta);
			lstValidacion.put("resultado", resultado);
			lstValidacion.put("listaErrores", listaErrores);
			return lstValidacion;
		}
		Throwable lastError = (Throwable) datos.get("lastError");
		listaErrores = (List<Map<String, String>>) datos.get("listaErrores");
		Integer nroErroresNegocio = (Integer) datos.get("nroErroresNegocio");
		Integer nroWarningsNegocio = (Integer) datos.get("nroWarningsNegocio");
		Map<String, Object> respuestaGrabacion = (Map<String, Object>) datos.get("respuestaGrabacion");
		if (!CollectionUtils.isEmpty(respuestaGrabacion)) {
			declaracionProcesado = (Declaracion) respuestaGrabacion.get("declaracion");
		}
		
		if (lastError != null) {
			String descError = null;
			error = new HashMap<String, String>();
			listaErrores = new ArrayList<Map<String, String>>();
			error.put("codTipAlerta", "E");
			error.put("codError", "0x0001");
			if (lastError.getMessage() != null) {
				descError = lastError.getMessage();
			} else {
				descError = "No se pudo determinar la causa del Error. Contacte con el Administrador.";
			}
			error.put("desError", descError);
			listaErrores.add(error);
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			valOk = false;
		} else if (nroErroresNegocio != null && nroErroresNegocio.intValue() > 0) {
			mensajeRespuesta = "La operaci�n no pudo realizarse debido a que se encontraron errores.";
			valOk = false;
		} else if (nroWarningsNegocio != null && nroWarningsNegocio.intValue() > 0) {
//			mensajeRespuesta = "El registro de la diligencia se realiz�, pero se encontraron advertencias.";
			valOk = true;
		} else {
//			mensajeRespuesta = "El registro de la diligencia se realiz� correctamente.";
			valOk = true;
		}
		if (listaErrores == null) {
			listaErrores = new ArrayList<Map<String, String>>();
		}
		resultado.put("valOk", valOk);
		resultado.put("mensajeRespuesta", mensajeRespuesta);
		lstValidacion.put("resultado", resultado);
		lstValidacion.put("listaErrores", listaErrores);
		return lstValidacion;
	}


	public <T extends Documento> Mensaje procesarMensaje(T documento, String codAduana, String tipoDeTransaccion,
			String tipoDocIdentidadSender, String tipoSender, String numDocSender){
		Mensaje mensaje = new Mensaje();
		Control control = new Control();
		control.setCodigoAduana(codAduana);
		control.setCodigoAduanaOrden(codAduana);
		control.setFechaDeGeneracion(new Date());
		control.setTipoDeTransaccion(tipoDeTransaccion);
		control.setTipoDocumentoIdentidadSender(tipoDocIdentidadSender);
		control.setTipoSender(tipoSender);
		control.setNumeroDocumentoIdentidadSender(numDocSender);
		DataCatalogo transaccion = catalogoAyudaService.getDataCatalogo(CATALOGO_TIPO_TRANSACCION_ELECTRONICA, tipoDeTransaccion);
		control.setPropositoMensaje(transaccion.getDesCorta());
		mensaje.setDocumento(documento);
		mensaje.setControl(control);
		return mensaje;
	}

	public Map<String, String> setearError(int codError, String desError){
		Map<String, String> error = new HashMap<String, String>();
		error.put(ConstantesManifiesto.CODTIPALERTA, "E");
		error.put(ConstantesManifiesto.CODERROR, ConstantesManifiesto.CEROSHEXA + codError);
		error.put(ConstantesManifiesto.DESERROR, desError);
		return error;
	}

  /***********************SET DE SPRING **********************************/

	public void setFabricaDeServiciosOrquestador(
			FabricaDeServicios fabricaDeServiciosOrquestador) {
		this.fabricaDeServiciosOrquestador = fabricaDeServiciosOrquestador;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void setDeclaracion(Declaracion declaracion) {
		this.declaracion = declaracion;
	}
	//EJHM P46
	public void setDeclaracionBD(Declaracion declaracionBD) {
		this.declaracionBD = declaracionBD;
	}
}
