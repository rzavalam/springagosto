package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import static pe.gob.sunat.despaduanero2.declaracion.api.util.ConstantesApi.BASE_API_RIESGO_PATH;
import static pe.gob.sunat.despaduanero2.declaracion.api.util.ConstantesApi.TAG_API_RIESGO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.MOMENTO_PARAM_WS_REVALUACION_RIESGO;
import static pe.gob.sunat.despaduanero2.seleccion.util.Constantes.AFORO_NARANJA;
import static pe.gob.sunat.despaduanero2.seleccion.util.Constantes.AFORO_ROJO;
import static pe.gob.sunat.despaduanero2.seleccion.util.Constantes.AFORO_VERDE;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_VIGENCIA_INVOCACION_API_RIESGO;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.WebUtils;//RIN10
//import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import org.apache.commons.lang.StringUtils;

import com.gentlyweb.utils.CollectionsUtils;



import com.sun.xml.fastinfoset.util.StringArray;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.despaduanero2.asignacion.bean.BandejaDocu;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.BandejaDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionAutomaticaService;
import pe.gob.sunat.despaduanero2.asignacion.util.TipoInvocacion;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.bean.DatoRectificado;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.FechaCanal;
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.response.CanalEvaluadoResponse;
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.response.CanalResponse;
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.response.ConsistenciaCanalResponse;
import pe.gob.sunat.despaduanero2.declaracion.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService; //RMC RIN-P47
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.ValidaContingentesService; //RMC RIN-P47
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.donacion.ImpugnacionTributosParaDonacionService;//P46 - PAS20155E220000329
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea.ValOperadorOeaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarFormatoAService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarGeneralService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional.ValidadorValorProvisionalService;//rin10
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionBatchService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.service.ProcesoAsignacionCanalService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetIncidenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.RectificacionAbstract;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.HashMapComparator;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ValidadorRectificacion;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DatadoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.DetalleSolicitudRectifica;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudRectifica;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.FnCalculaDiasDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.multa.service.MultaService;
import pe.gob.sunat.despaduanero2.seleccion.bean.ResponseSeleccion;
import pe.gob.sunat.despaduanero2.seleccion.model.CabeceraDuaTipoAforo;
import pe.gob.sunat.despaduanero2.seleccion.service.SeleccionService;
import pe.gob.sunat.despaduanero2.seleccion.service.SeleccionValidacionService;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.service.SolicitudPecoAmazoniaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.prevcontrabando2.ace.util.ConstantesACE;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.sigad.ingreso.service.ControlarSaldoReposicionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.asignacion.util.TipoInvocacion;
//RIN16
//PASE-42-VRD
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OperadorOeaDAO;
/**
 * The Class SolicitudRectificacionesServiceImpl.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class SolicitudRectificacionesServiceImpl implements SolicitudRectificacionesService
{

  protected final Log               log                               = LogFactory.getLog(getClass());

  private static final String       COD_TIPO_DILIGENCIA_RECTIFICACION = "06";

  private static final String  		COD_TRANSACCION_RECTIFICACION_ELECTRONICA = "1007";
  // SERVICE
  private OperadorAyudaService      operadorAyudaService;

  private FabricaDeServicios        fabricaDeServicios;

  private HotSwappableTargetSource  swapperDatasource;

  private MultaService              multaService;

  private LiquidaDeclaracionService liquidaDeclaracionService;

  private DiligenciaService         diligenciaService;
  
  /***** GGRANADOS RIN16PASE3 INI *****/
  private DeclaracionService declaracionService;
/***** GGRANADOS RIN16PASE3 FIN *****/

  private CatalogoAyudaService      catalogoAyudaService;

  // DAOS
  private CabSolrectiDAO            cabSolrectiDAO;

  private IncidenciaService         incidenciaService;

  private CabDiligenciaDAO          cabDiligenciaDAO;

  private DetIncidenciaDAO          detIncidenciaDAO;

  private DocAutAsociadoDAO         docAutAsociadoDAO;

  private DatadoDAO                 datadoDAO;

  private List<String>              tablasRectificacion;

  private GrabarGeneralService grabarGeneralService;
  private GrabarDeclaracionService 	grabarDeclaracionService;

  private IndicadorDUADAO           indicadorDUADAO;
  
  private DdpDAOService ddpDAOService;
//lmvr - inicio: Complemento de Diligencia
  private CabDeclaraDAO  cabDeclaraDAO;
 private FnCalculaDiasDAO fnCalculaDiasDAO;
//lmvr - fin: Complemento de Diligencia
//PASE-42-VRD
 private ObservacionDAO observacionDAO;

	//INCIO RIN10-FSW AFMA
	private ValidadorValorProvisionalService valorProvisionalService;
//FIN RIN10-FSW AFMA

	//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
	private GrabarContingentesService grabarContingentesService;
	private ValidaContingentesService validaContingentesService;

 //rtineo mejoras
	private DiligenciaBatchService diligenciaBatchService;

/**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerResultado(Map<String, Object> mapParametros) throws ServiceException
  {
    MensajeBean mensajeBean = null;
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    // Mapa inicial de datos para consultar los valores de BD.
    Map<String, Object> mapDatosIniciales = new HashMap<String, Object>();
    mapDatosIniciales.put("NUM_CORREDOC", mapParametros.get("NUM_CORREDOC").toString());
    mapDatosIniciales.put("ANN_PRESEN", mapParametros.get("ANN_PRESEN").toString());
    mapDatosIniciales.put("COD_ADUANA", mapParametros.get("COD_ADUANA").toString());
    mapDatosIniciales.put("COD_REGIMEN", mapParametros.get("COD_REGIMEN").toString());
    mapDatosIniciales.put("NUM_DECLARACION", mapParametros.get("NUM_DECLARACION").toString());

    List<Map<String, Object>> lstMultaDuaForm = (List<Map<String, Object>>) mapParametros.get("lstMultaDuaForm");
    // Datos de la Rectificacion, se obtiene los datos seleccionados de la
    // rectificacion enviada.
    mapResultado = this.obtenerDatosRectificacion(mapParametros);

    mapResultado = this.mergeDatosBDRectificacion(mapResultado, mapDatosIniciales);

    // Seteamos valores adicionales
    mapResultado.put("FEC_EVALUACION", mapParametros.get("FEC_EVALUACION"));


    Map<String, Object> declaracion = (Map<String, Object>) mapResultado.get("mapCabDeclaraActual");

    Map<String, Object> paramMulta = new HashMap<String, Object>();
    paramMulta.put("COD_ADUANA", mapParametros.get("COD_ADUANA").toString());//pase42
    paramMulta.put("NUM_REG_USUARIO", mapParametros.get("NUM_REG_USUARIO").toString());
    paramMulta.put("COD_DOCUMENTO", declaracion.get("NUM_CORREDOC").toString());
    paramMulta.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
    paramMulta.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_RECTIFICACION);
    paramMulta.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));
    paramMulta.put(
        "NUM_CORREDOC_SOL",
          mapParametros.containsKey("NUM_CORREDOC_PRE") ? mapParametros.get("NUM_CORREDOC_PRE") : null);
    //cambio de metodo para acoplar funcionalidad de FSW
	// pase 42 lalberti
    if(lstMultaDuaForm != null && !lstMultaDuaForm.isEmpty() ){
    	List<Map<String, Object>> lstMultas =  multaService.armarMapaMultasParaRegistroDiligenciaDespacho(paramMulta,lstMultaDuaForm); //multaService.crearMultaMaps(paramMulta, lstMultaDuaForm);
    	mapResultado.put("lstMultas", lstMultas); // Multas asignadas.
    }
//fin

  
    // Obtenemos cabDeclara para obtener participantes, esto segun lo realizado
    // en grabacion de DILIGENCIA
    // Participantes
    List listParticipanteDoc = new ArrayList();
    // Obtenemos de cabDeclara (importador y agente)
    Map partic = new HashMap();
    partic.put("COD_TIPPARTIC", "45");
    partic.put("COD_TIPDOC", ((Map<String, Object>) mapResultado.get("mapCabDeclara")).get("COD_TIPDOC_PIM"));
    partic.put("NUM_DOCIDENT", ((Map<String, Object>) mapResultado.get("mapCabDeclara")).get("NUM_DOCIDENT_PIM"));
    listParticipanteDoc.add(partic);
    partic = new HashMap();
    partic.put("COD_TIPPARTIC", "41");
    partic.put("COD_TIPDOC", ((Map<String, Object>) mapResultado.get("mapCabDeclara")).get("COD_TIPDOC_PDE"));
    partic.put("NUM_DOCIDENT", ((Map<String, Object>) mapResultado.get("mapCabDeclara")).get("NUM_DOCIDENT_PDE"));
    listParticipanteDoc.add(partic);
    //
    mapResultado.put("lstParticipanteDoc", listParticipanteDoc);

    // validamos que los totales del cabdeclara sean igual a la sumatoria de los
    // valores de la serie
    mensajeBean = ValidadorRectificacion.validarTotalDeclaracionVsSumasSerie((Map<String, Object>) mapResultado.get("mapCabDeclaraActual"),
        (ArrayList<Map<String, Object>>) mapResultado.get("lstDetDeclaraActual"),
        (ArrayList<Map<String, Object>>) mapResultado.get("lstItemFacturaActual"),
        (ArrayList<Map<String, Object>>) mapResultado.get("lstSeriesItemActual"));

    
    // validaciones haciendo uso de servicios creados para el orquestador (crear
    // una instancia del orquestador y validar a traves del orquestador)
    
    
    /*
     * Se centraliza las validaciones para que sean invocadas como servicio
     * 
    if (mensajeBean == null)
    {
      GetDeclaracionHashMapToDeclaracionObjectHelper transform =
          GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance();
      Declaracion Declaracion = transform.transformBySufijo(mapResultado, "Actual");
      // validar mercancia restringida
      List<Map<String, String>> errorValidaciones = MercanciaRestringidaServiceImpl
          .getInstance()
          .validarMercanciaRestringida(Declaracion, COD_TRANSAC_RECTIFICACION);
      String mensajeError = "";
      for (Map<String, String> map : errorValidaciones)
      {
        mensajeError += map.get(ResponseMapManager.KEY_DESCRIPCION) + "; ";
      }

      if (!StringUtils.isBlank(mensajeError))
      {
        mensajeBean = new MensajeBean();
        mensajeBean.setMensajeerror(mensajeError);
      }
    }*/

    /* La validacion del  Datado se hace con los servicios del SEIDA */

    if (mensajeBean != null)
    {
      mapResultado.put("rBean", mensajeBean);
      return mapResultado;
    }
    return mapResultado;
  }

 // <!-- lmvr - Inicio: Complemento de la Diligencia -->
 

  	public Map<String, Object> validarActualizacionFechaRegularizacion(Map<String, Object> mapParametros) throws ServiceException
  	{
		boolean esDespachoAnticipado = false;
		boolean tieneIndicadorSujetoRegularizacion = false;
		boolean tienePlazoRegularizacionVencido = false;
		boolean actualizaFechaRegularizacion = false;
		Date fechaRegularizacionProrroga = (Date) mapParametros.get("FEC_VENCREGULA");
		Date fechaSolicitudRectificacion = null;
		Date fechaExpediSolicitud=null;
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		Map<String, Object> mapResultado = new HashMap<String, Object>();
		//FechaBean    FECHA_DEFAULT    = new FechaBean("01/01/1901");
		Date fechaTerminoDescargaAdicionalInical = SunatDateUtils.getDefaultDate();
		Date fechaTerminoDescargaAdicional= SunatDateUtils.getDefaultDate();
		Date fechaTerminoDescargaAdicionalVen= SunatDateUtils.getDefaultDate();
		esDespachoAnticipado =  Constants.DESPACHO_ANTICIPADO.equals(mapParametros.get("COD_MODALIDAD"));
		
		Map<String, Object> paramsIndicador = new HashMap<String, Object>();
		paramsIndicador.put("numcorredoc", mapParametros.get("NUM_CORREDOC").toString());
		paramsIndicador.put("codtipoindica", Constants.IND_REGULARIZABLE);
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		List<DatoIndicadores> listIndicadores = indicadorDUADAO.findIndicadoresByMap(paramsIndicador);
		
		if (listIndicadores.size() > 0){
			tieneIndicadorSujetoRegularizacion  = true;
		}
	  
		 		
		
		//Date fechaHoy =SunatDateUtils.getCurrentDate() ;
		//Date fechaVencRegula = (Date) mapParametros.get("FEC_VENCREGULA");
		/*if (SunatDateUtils.esFecha1MayorQueFecha2( fechaHoy, fechaTerminoDescargaAdicionalInical, SunatDateUtils.COMPARA_SOLO_FECHA) ) {
			tienePlazoRegularizacionVencido = true;
		} */
		
		/*if (SunatDateUtils.sonIguales(fechaVencRegula, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )) {
			tienePlazoRegularizacionVencido = true;
 		}*/ //bug 19941
		

	 	boolean tieneLevanteAutorizado = false;
	 	boolean tieneSolicitudDentroDelPlazo = false;
	 	boolean tieneExpedienteAsociado = false;

	 	
	 	SolicitudService solicitudService = fabricaDeServicios.getService("diligencia.ingreso.solicitudService");
	 	ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
	 	
	 	if(esDespachoAnticipado && tieneIndicadorSujetoRegularizacion) { // bug 19941
	 		 //Date fechaAutLevante = new Date ( new SimpleDateFormat("dd/MM/yyyy").format(mapParametros.get("FEC_AUTLEVANTE")));
	 		Date fechaAutLevante = (Date) mapParametros.get("FEC_AUTLEVANTE");
	 		/*if (SunatDateUtils.esFecha1MayorQueFecha2(fechaAutLevante, FECHA_DEFAULT.getTimestamp(), SunatDateUtils.COMPARA_SOLO_FECHA)) {
	 			tieneLevanteAutorizado = true;
	 		}*/

	 		 
	 		if (!SunatDateUtils.sonIguales(fechaAutLevante, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )) {
	 			tieneLevanteAutorizado = true;
	 		}
	 		
	 		Map parametroExpedi = new HashMap();
	 		
			if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals( mapParametros.get("COD_REGIMEN"))){
				parametroExpedi.put("COD_REGIMEN", "17");
			  }else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals( mapParametros.get("COD_REGIMEN"))){
				//paramExpedi.setoTipo(32);
				  parametroExpedi.put("COD_REGIMEN", "32");
			  }else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals( mapParametros.get("COD_REGIMEN"))){
				//paramExpedi.setoTipo(7);
				  parametroExpedi.put("COD_REGIMEN", "7");
			  }else if(ConstantesDataCatalogo.REG_DEPOSITO.equals( mapParametros.get("COD_REGIMEN"))){
				//paramExpedi.setoTipo(40);
				  parametroExpedi.put("COD_REGIMEN", "40");
			  }
	 		
	 		
	 		
	 		
	 		parametroExpedi.put("NUM_DECLARACION", mapParametros.get("NUM_DECLARACION"));
	 		parametroExpedi.put("COD_ADUANA", mapParametros.get("COD_ADUANA"));
	 		parametroExpedi.put("ANN_PRESEN", mapParametros.get("ANN_PRESEN"));
	 		//parametroExpedi.put("COD_REGIMEN", mapParametros.get("COD_REGIMEN"));
	 		parametroExpedi.put("codi_aduan", mapParametros.get("COD_ADUANA"));
	 		
	 		
	 		

	 			
	 		//String[] tipoExpediente = new String[] {"1607","3071","3109"};
	 		//parametroExpedi.put("PROCEDIM_IN", tipoExpediente);
	 			
	 		List<Map<String, Object>> listExpediente = expedienteService.findExpedientesAsociadoDeclaracion(parametroExpedi) ;
	 		  /*inico - Pase548*/																 
	 		if(!CollectionUtils.isEmpty(listExpediente)) {//bug 19607
	 			tieneExpedienteAsociado = true;
	 			fechaExpediSolicitud= (new FechaBean( listExpediente.get(0).get("FECEXP").toString(),"yyyyMMdd").getSQLDate());
	 		}else{
	 			
	 			mapResultado.put("actualizaFechaRegularizacion", actualizaFechaRegularizacion ); 
	 		 	mapResultado.put("fechaRegularizacionProrroga", fechaRegularizacionProrroga ); 
	 			
	 			 return mapResultado;
	 		}
	 		
	 		
	 		Long numCorreDocDUA = new Long(mapParametros.get("NUM_CORREDOC").toString());
	 		List<Map<String, Object>> datosSolicitudRectificacion = solicitudService.buscarRectiyReguPend(numCorreDocDUA);
	 		//fechaSolicitudRectificacion = new Date ( new SimpleDateFormat("dd/MM/yyyy").format(datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD")));
	 		fechaSolicitudRectificacion = (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");
	 		
	 		String codigoViaTransporte = (String) mapParametros.get("COD_VIATRANS") ;
	 		String numeroManifiesto = (String)mapParametros.get("NUM_MANIFIESTO");
	 		
	 		
	 		//Integer anioManifiesto = (Integer) mapParametros.get("ANN_MANIFIESTO");
	 		BigDecimal anioManifiestoBigDecimal = (BigDecimal) SunatNumberUtils.toBigDecimal( mapParametros.get("ANN_MANIFIESTO"));//			BigDecimal anioManifiestoBigDecimal = (BigDecimal) mapParametros.get("ANN_MANIFIESTO"); cambiado por mol
            
			Integer anioManifiesto = new Integer(anioManifiestoBigDecimal.intValue());
	 		String codigoTipoManifiesto =  (String) mapParametros.get("COD_TIPMANIFIESTO");
	 		String codigoAduana = (String) mapParametros.get("COD_ADUAMANIFIESTO");
	 		  		
	 		Manifiesto datosManifiesto=manifiestoService.findManifiestoByClaveDeNegocio(codigoTipoManifiesto,  codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto);
	 		if (datosManifiesto!=null && !SunatDateUtils.sonIguales(datosManifiesto.getFechaTerminoDeDescarga(),SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))//BUG 20186 pase 399
			{
	 		
	 		Date fechaTerminoDescarga = datosManifiesto.getFechaTerminoDeDescarga();
	 		//Date fechaTerminoDescargaAdicional = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
	 		fechaTerminoDescargaAdicional = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
	 		fechaTerminoDescargaAdicionalVen = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
	 		
 			SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
 			Long lnFechaActualMenosUnDia = new Long(sdf.format(SunatDateUtils.addDay(fechaTerminoDescargaAdicional, 0)));
 			Long fehaActualMasDiaUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 0, "U", "2", "S", "N");

 			if(fehaActualMasDiaUtil.intValue()!=lnFechaActualMenosUnDia){
 				//Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "2", "S", "N"); 
 				//fechaTerminoDescargaAdicional = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
 				Long lnFechaMasAntUtilD = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "2", "S", "N");
 				fechaTerminoDescargaAdicional=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtilD.toString(),"yyyyMMdd").getSQLDate(), 0);
 				
 			}else{
 			// Si el d�a o d�as anteriores no han sido �tiles
 				// �ltimo d�a �til antes de la fecha
 			//	Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "3", "S", "N"); 
 				// suma un d�a calendario
 			//	fechaIniProc.setFecha(SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1));
 			//	fechaTerminoDescargaAdicional=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1);
 				
 				
 				fechaTerminoDescargaAdicional = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
 			}
	 		
	 		
	 		
	 			
	 		//if(SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRectificacion, fechaTerminoDescargaAdicional, SunatDateUtils.COMPARA_SOLO_FECHA)){
	 		 if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaTerminoDescargaAdicional, fechaExpediSolicitud, SunatDateUtils.COMPARA_SOLO_FECHA)){
	 			tieneSolicitudDentroDelPlazo  = true;
			  }
			 }
	 		
	 	}
	 	
	 
	  	//Date fechaRegularizacionProrroga = new Date ( new SimpleDateFormat("dd/MM/yyyy").format(mapParametros.get("FEC_VENCREGULA")));
	  
	 //	Date fechaDiligenciaRectificacion = FECHA_DEFAULT.getTimestamp();
	 	
	 	if (tieneLevanteAutorizado && tieneSolicitudDentroDelPlazo &&  tieneExpedienteAsociado) {	 	
	 		//if (tieneLevanteAutorizado  &&  tieneExpedienteAsociado) {	
	 		actualizaFechaRegularizacion = true;
	 		Date fechaRegularizacion = (Date) mapParametros.get("FEC_VENCREGULA");	 				
	 		//if (SunatDateUtils.esFecha1MayorQueFecha2(fechaTerminoDescargaAdicionalInical, fechaSolicitudRectificacion, SunatDateUtils.COMPARA_SOLO_FECHA)) {
	 			
	 		if (SunatDateUtils.esFecha1MayorQueFecha2(fechaTerminoDescargaAdicional, fechaExpediSolicitud, SunatDateUtils.COMPARA_SOLO_FECHA)) {	
	 			
	 			
	 			Long diferenciaDias =  SunatDateUtils.getDiferenciaDiasCalendarios(SunatDateUtils.getCurrentDate(), fechaExpediSolicitud);
	 			int  diferenDias= 0;
	 			diferenDias = new Long(diferenciaDias).intValue(); 
	 		    fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicional, diferenDias);
	 			
	
	 			SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
	 			Long lnFechaActualMenosUnDia = new Long(sdf.format(SunatDateUtils.addDay(fechaRegularizacionProrroga, 0)));
	 			Long fehaActualMasDiaUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 0, "U", "2", "S", "N");

	 			if(fehaActualMasDiaUtil.intValue()!=lnFechaActualMenosUnDia){
	 				//fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicionalVen, diferenDias);
	 				Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "2", "S", "N"); 
	 				fechaRegularizacionProrroga=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 0);
	 				
	 			}else{
	 			// Si el d�a o d�as anteriores no han sido �tiles
	 				// �ltimo d�a �til antes de la fecha
	 				//Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "3", "S", "N"); 
	 				// suma un d�a calendario
	 			//	fechaIniProc.setFecha(SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1));
	 				//fechaRegularizacionProrroga=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1);
	 				
	 				
	 				 fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicional, diferenDias);
	 			}		
	 		}

	 		if (SunatDateUtils.sonIguales(fechaTerminoDescargaAdicional, fechaExpediSolicitud,SunatDateUtils.COMPARA_SOLO_FECHA)) {
	 			
	 			fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicional, 2);

	 			SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
	 			Long lnFechaActualMenosUnDia = new Long(sdf.format(SunatDateUtils.addDay(fechaRegularizacionProrroga, 0)));
	 			Long fehaActualMasDiaUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 0, "U", "2", "S", "N");

	 			if(fehaActualMasDiaUtil.intValue()!=lnFechaActualMenosUnDia){
	 				//fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicional, 2);
	 				Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "2", "S", "N"); 
	 				fechaRegularizacionProrroga=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 0);
	 				
	 			}else{
	 			// Si el d�a o d�as anteriores no han sido �tiles
	 				// �ltimo d�a �til antes de la fecha
	 			//	Long lnFechaMasAntUtil = fnCalculaDiasDAO.getFechaUtilSumaNDias(lnFechaActualMenosUnDia, 1, "U", "3", "S", "N"); 
	 				// suma un d�a calendario
	 			//	fechaIniProc.setFecha(SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1));
	 				//fechaRegularizacionProrroga=SunatDateUtils.addDay(new FechaBean(lnFechaMasAntUtil.toString(),"yyyyMMdd").getSQLDate(), 1);
	 				
	 				
	 				fechaRegularizacionProrroga = SunatDateUtils.addDay(fechaTerminoDescargaAdicional, 2);
	 			}
	 			
	 			
	 		}
	 		
	 		// Envio mensaje a Buzon SOL
	 		

	 		FechaBean fechaPublicacion = new FechaBean();
	 		Map parametroParticip = new HashMap();
	 		parametroParticip.put("numeroCorrelativo", mapParametros.get("NUM_CORREDOC"));
	 		parametroParticip.put("codTippartic", new String [] {"41","45"});
	 		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
	 		List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
	 		List lstOperadores   = new ArrayList();		
	 		Map comunicado = new HashMap();
	 		String datosAgente="-";
	 		String datosUsuarioA="-";
	 		String datosUsuarioI="-";
	 		String datosImportador="-";
	 		for (int i=0; i<listadoParticipante.size(); i++) {
	 			Participante participante = listadoParticipante.get(i);
	 			lstOperadores.add(participante.getNumeroDocumentoIdentidad());
		 			if ("41".equals(participante.getTipoParticipante().getCodDatacat()) ) {
		 				// datosAgente=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
		 				 datosAgente=(String)(participante.getNombreRazonSocial());   
		 				 datosUsuarioA=(String)( participante.getNumeroDocumentoIdentidad());     
		 			 }
		 			if ("45".equals(participante.getTipoParticipante().getCodDatacat()) ) {
		 				// datosImportador=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
		 				 datosImportador=(String)(participante.getNombreRazonSocial()); 
		 				 datosUsuarioI=(String)( participante.getNumeroDocumentoIdentidad()); 
		 			 }
	 		}
	 	//	String fechaRegularizacionProrr = new SimpleDateFormat("dd/MM/yyyy").format(fechaRegularizacionProrroga);
	 		comunicado.put("cod_usuario", new String[] {datosUsuarioA.toString(),datosUsuarioI.toString()});
	 		comunicado.put("agente_aduana", datosAgente);
	 		comunicado.put("consignatario", datosImportador);
	        comunicado.put("tip_usuario", "1"); //Contibuyente o registrado por RUC
	        comunicado.put("fecha_emision", fechaPublicacion.getFormatDate("dd/MM/yyyy").toString());
	        comunicado.put("cod_aduana", mapParametros.get("COD_ADUANA").toString());
	        comunicado.put("ann_presen", mapParametros.get("ANN_PRESEN").toString());
	        comunicado.put("cod_regimen", mapParametros.get("COD_REGIMEN").toString());
	        comunicado.put("num_declaracion", mapParametros.get("NUM_DECLARACION").toString());
	        comunicado.put("des_asunto","SUSPENSION DE PLAZO PARA LA REGULARIZACION DEL DESPACHO ANTICIPADO");
	        comunicado.put("fecha_vencimiento_regularizacion", SunatDateUtils.getFormatDate(fechaRegularizacionProrroga, "dd/MM/yyyy"));
	        	        
	 		this.envioCorreoActualizacionPlazoRegularizacion(comunicado);
	 	}

	 	mapResultado.put("actualizaFechaRegularizacion", actualizaFechaRegularizacion ); 
	 	mapResultado.put("fechaRegularizacionProrroga", fechaRegularizacionProrroga ); 
	 	
	  return mapResultado;
  }
  



	private void envioCorreoActualizacionPlazoRegularizacion(Map<String, Object> comunicado)
	  {

	   FechaBean fechaActual = new FechaBean();
	   FechaBean fechaVigencia = new FechaBean();
	   fechaVigencia.setFecha("31/12/9999");
	   
       StringBuffer data = new StringBuffer(SojoUtil.toJson(comunicado));
       PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
       publicacionAvisoService.insert(177, data, ConstantesACE.TIPO_AVISO_MENSAJE_SIMPLE, fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
	  }
  	
  	
  	  //<!-- lmvr - Fin: Complemento de la Diligencia -->
  	
  	
  	
  
  /**
   * Metodo que permite obtener los datos recificados dentro de un Map, dentro
   * del cual se tiene List con nombres de las tablas que coincidan en el envio
   * de la rectificaci�n.
   *
   * @param mapData
   *          the map data
   * @return the map
   */

  public Map<String, Object> obtenerDatosRectificacion(Map<String, Object> mapData) //<--RIN08
  {
    List<Map<String, Object>> lista = (List<Map<String, Object>>) mapData.get("lstData");
    if (CollectionUtils.isEmpty(lista))
    {
      return null;
    }
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    for (Map<String, Object> mapa : lista)
    {
      // Comparamos segun la codigo de tabla el tipo a usar Map o List
      // CabDeclara es Map, unico por el momento.
      if (Constantes.COD_TABLA_CAB_DECLARA.equals(mapa.get("tabla").toString()))
      {
        mapResultado = HashMapComparator.setearMap(mapa, mapResultado);
      }
      else
      {
        mapResultado = HashMapComparator.setearMapList(mapa, mapResultado);
      }
    }

    return mapResultado;
  }

  /**
   * Metodo que setea los valores de la RECTIFICACION sobre los recogidos de la
   * BD, segun PK.
   *
   * @param mapResultado
   *          the map resultado
   * @param mapDatosIniciales
   *          the map datos iniciales
   * @return the map
   */
  private Map<String, Object> mergeDatosBDRectificacion(
    Map<String, Object> mapResultado,
    Map<String, Object> mapDatosIniciales)
  {

    for (String codTablaRecticar : tablasRectificacion)
    {

      RectificacionAbstract rectifi = fabricaDeServicios.getService("diligencia.rectificacion.codtabla."
          + codTablaRecticar);
      if (rectifi != null)
      {
        mapResultado = rectifi.mergeDatosBDRectificacion(mapResultado, mapDatosIniciales);
      }
      else
      {
        if (log.isWarnEnabled())
          log.warn("La clase de rectificacion para la tabla con codigo: \""
              + codTablaRecticar + "\" no se encuentra registrada o no es soportada");
      }

    }
    return mapResultado;
  }
/**INICIO-FSW**/
  /**
   * {@inheritDoc}
   */
  public List<Map<String,Object>> grabarSolicitudRectificacionConIncidencia(Map<String, Object> mapParametros)
  {
	  List<Map<String,Object>> mapResult = new ArrayList<Map<String,Object>>();
	  this.grabarSolicitudRectificacion(mapParametros);
    try
    {
  	  Long numcorredoc = Long.parseLong(((Map<String, Object>) mapParametros.get("mapCabDeclaraActual")).get("NUM_CORREDOC").toString());
  	  String nroaduana = ((Map<String, Object>) mapParametros.get("mapCabDeclaraActual")).get("COD_ADUANA").toString();
  	  int anio = Integer.parseInt(((Map<String, Object>) mapParametros.get("mapCabDeclaraActual")).get("ANN_ORDEN").toString());
  	  mapResult.addAll((liquidaDeclaracionService.getDeudaCancelada(numcorredoc,nroaduana,anio)));
    }
    catch (Exception e)
    {
      log.error("**** ERROR ****", e);
    }
    return mapResult;
  }
  
//gmontoya P29 Pase 15 2015 inicio 
  private void actualizarCtaCteRegimen(Declaracion declaracion, Long numCorreDoc){
	  boolean esTPN21 = false;
	  
	  for(DatoSerie serie:declaracion.getDua().getListSeries()){		
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
				esTPN21 = serie.getCodtratprefe()==21;
				break;
			}
	  }
	  if(esTPN21){
		  DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
		  Map<String, Object> params = new HashMap<String, Object>();
		  params.put("numCorredocDesc", numCorreDoc);
		  params.put("indAnulacion", "1");		  
		  List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);
		  
		  for(DatoSerie serie:declaracion.getDua().getListSeries()){		
				for(DatoRegPrecedencia prec:serie.getListRegPrecedencia()){
					if( esTPN21 ) {
						fillCabCtacteRegimen(serie, prec, numCorreDoc, listaDet);
					}
				}
		  }
	  }else{
		  SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
		  Map pkDocu = new HashMap();
		  pkDocu.put("NUM_CORREDOC",numCorreDoc);
		  pkDocu.put("COD_CONVENIO","  21");
		  pkDocu.put("COD_TIPCONVENIO","T");
		  List lista = serieService.obtenerConvenioSerieMap(pkDocu);
		  if(!CollectionUtils.isEmpty(lista)){
				  
			  DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
			  Map<String, Object> params = new HashMap<String, Object>();
			  params.put("numCorredocDesc", numCorreDoc);
			  params.put("indAnulacion", "1");		  
			  List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);
			
			  DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
			  ctaCteService.quitarTPN21CtacteRegimen(listaDet);
		  }
	  }	  
  }
  
  private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc,List<DetCtacteRegimen> listaDet){
		
		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("codAduana", prec.getCodaduapre());
		paramCtaCte.put("annPresen", prec.getAnndeclpre().substring(0, 4));
		paramCtaCte.put("codRegimen", prec.getCodregipre());
		paramCtaCte.put("numDeclaracion", prec.getNumdeclpre());
		paramCtaCte.put("numSecserie", prec.getNumserpre());
		List<CabCtacteRegimen> listaCabCtacteRegimen = ctaCteService.obtenerCabeceraCtaCte(paramCtaCte);
		if( listaCabCtacteRegimen.size()>0 ) {
			CabCtacteRegimen ctacte = listaCabCtacteRegimen.get(0); 
			boolean actualizarRegu = false;
			BigDecimal diferencia = BigDecimal.ZERO;
			for(DetCtacteRegimen detCtaCte : listaDet){
				if(detCtaCte.getNumCtacte().equals(ctacte.getNumCtacte()) && 
					detCtaCte.getNumSerieDesc().equals(serie.getNumserie())){
					diferencia = SunatNumberUtils.diference(serie.getCntunicomer(), detCtaCte.getCntDescargada());
					actualizarRegu = true;
					break;
				}
			}
			if(actualizarRegu && diferencia.compareTo(BigDecimal.ZERO)!=0){
				ctaCteService.actualizaReguCtacteRegimen(ctacte, serie, numCorredoc,diferencia);
			}else{
				if(!actualizarRegu){
					ctaCteService.actualizaCtacteRegimen(ctacte, serie, numCorredoc);
				}
			}
		}

		return;
	}
//gmontoya P29 Pase 15 2015 fin 
/**FIN-FSW**/  
  public Map<String, Object> grabarSolicitudRectificacion(Map<String, Object> mapParametros)
  {
    Map<String, Object> mapResult = new HashMap<String, Object>();
    UsuarioBean usuarioBean = new UsuarioBean();
    try
    {
      String numCorredocSol = ObjectUtils.toString(mapParametros.get("NUM_CORREDOC_PRE"), "0");
      Map<String, Object> mapDatos = (HashMap<String, Object>) mapParametros.get("mapResultado");
//PAS201830001100016 mordonezl
      Declaracion declaracionBD = (Declaracion)  mapParametros.get("declaracionBD");
//FIN \PAS201830001100016
      //rtineo mejoras, para grabacion en batch
      mapDatos.put("codTransaccion", mapParametros.get("codTransaccion"));
      String codTransaccion = (mapParametros.get("codTransaccion")!=null)?mapParametros.get("codTransaccion").toString():"";
      //rtineo mejoras, fin
      Map<String, Object> mapCabDeclaraActual =
          (Map<String, Object>) mapDatos.get("mapCabDeclaraActual");

      Map<String, Object> mapDiligencia = new HashMap<String, Object>();
      mapDiligencia
          .put("NUM_CORREDOC", ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual")).get("NUM_CORREDOC"));
      mapDiligencia.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_RECTIFICACION);
      usuarioBean = (UsuarioBean) mapParametros.get("USUARIO");
//PAS201830001100016 mordonezl
      List<Map<String,Object>> listIndicadorDua =  mapCabDeclaraActual.get("lstIndicadorDuaActual")!=null?(List<Map<String, Object>>) mapCabDeclaraActual.get("lstIndicadorDuaActual"):new ArrayList();
      String acogimientoPostNumPecoAmazonia = mapCabDeclaraActual.get("acogimientoPostNumPecoAmazonia")!=null?mapCabDeclaraActual.get("acogimientoPostNumPecoAmazonia").toString():"NO";
      String numDeclaracion = mapCabDeclaraActual.get("COD_ADUANA").toString().concat("-").concat(mapCabDeclaraActual.get("ANN_PRESEN").toString().concat("-").concat(mapCabDeclaraActual.get("NUM_DECLARACION").toString()));
      String codAduana = mapCabDeclaraActual.get("COD_ADUANA")!=null?mapCabDeclaraActual.get("COD_ADUANA").toString():"";
      String codAduanaDestino =  mapCabDeclaraActual.get("COD_ADUDEST")!=null?mapCabDeclaraActual.get("COD_ADUDEST").toString():"";
//fin PAS201830001100016
      mapDiligencia.put("IND_INCIDENCIA", mapParametros.get("IND_INCIDENCIA")); //pase42 lalberti
      mapDiligencia.put("IND_MULTA", mapParametros.get("IND_MULTA")); //pase 42 lalberti
      mapDiligencia.put("DES_RESULTADO", StringUtils.trim((String) mapParametros.get("DES_RESULTADO")));
      mapDiligencia.put("COD_FUNCIONARIO", usuarioBean.getNroRegistro().trim());
      mapDiligencia.put("FEC_DILIGENCIA", mapParametros.get("FEC_EVALUACION"));
      mapDiligencia.put("NUM_CORREDOC_SOL", numCorredocSol);
      mapDiligencia.put("LIQSOL", mapParametros.get("cb_liqsol"));
      mapDiligencia.put("LIQDOL", mapParametros.get("cb_liqdol"));
      Boolean generarLC003 =(Boolean)mapParametros.get("generarLC003");
      //pas 42 lalberti adicion documento de determinacion
      	if(mapParametros.get("IND_MULTA").equals("S") && generarLC003){
		      ResCabBean resolucionMulta=(ResCabBean) mapParametros.get("resolucionMulta");
				        //Grabando la Resoluci�n de Determinaci�n de Multas para la Diligencia.
		      mapDiligencia.put("COD_TIPDOCDILI", resolucionMulta.getCodTipDocDili().getCodTipDocSustento());
		      mapDiligencia.put("COD_ADUADOCSUST", resolucionMulta.getCodAduanaDocSust());
		      mapDiligencia.put("COD_TIPDOCSUST", resolucionMulta.getCodTipDocSust());
		      mapDiligencia.put("COD_AREADOCSUST", resolucionMulta.getCodAreaDocSust());
		      mapDiligencia.put("ANN_DOCSUST", resolucionMulta.getAnnDocSust());
		      mapDiligencia.put("NUM_DOCSUST", resolucionMulta.getNumDocSust());
      	}
      //lalberti fin
      
      //PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA, solo cuando elimina o es nuevo pero el nuevo ya no va.
      	//RMC RIN-P47
      	Map prmContingente = new HashMap<String, Object>();
    	prmContingente.put("declaracion", mapCabDeclaraActual);
    	prmContingente.put("NUM_CORREDOC_SOL", numCorredocSol);
//    	extracted(numCorredocSol, prmContingente);
    	prmContingente.put("COD_ADUANA", mapCabDeclaraActual.get("COD_ADUANA"));
    	prmContingente.put("COD_USUMODIF", usuarioBean.getNroRegistro().trim());//pase PAS20181U220200016 esantana
      	prmContingente.put("lstDataAceptada", mapParametros.get("lstData"));
      	// Solo va
      	prmContingente.put("improcedente", "");

      	prmContingente.put("declaracionNue", mapParametros.get("declaracion") );
      	prmContingente.put("declaracionBD", mapParametros.get("declaracionBD") );


      	this.procesarContingente(prmContingente );
      	//this.procesarContProcdente(prmContingente );
      	
      
/**INICIO-P32-AMANCILLA**/
      /*jlunah*/
    // comenatado no va esn ets primera parte igual est mal implementado 
      //Map<String, Object> datosRectificacionConIncidencia = liquidaDeclaracionService.cargaVariablesParaRectiConIncidencia(mapCabDeclaraActual);
      /*fin jlunah*/
/**FIN-P32-AMANCILLA**/
//pase42 lalberti
      /**
       * Comentado  para probar guardar incidencias desde codigo de FSW
      List<IncidenciaBean> lstIncidencias = (ArrayList) mapParametros.get("lstIncidencias");
      if (lstIncidencias != null && lstIncidencias.size() > 0)
      {
        mapDatos.put("lstIncidencias", incidenciaService.obtenerListMapIncidencias(lstIncidencias,
            ((Map<String, Object>) mapParametros.get("mapCabDeclaraActual")).get("NUM_CORREDOC").toString(),
            COD_TIPO_DILIGENCIA_RECTIFICACION));
      }
       **/
//fin lalberti
      try
      {
        this.cabDiligenciaDAO.insert(mapDiligencia);        
      }
      catch (Exception e)
      {

        this.cabDiligenciaDAO.update(mapDiligencia);
      }
      // GRABAR INCIDENCIAS
      // Insertamos las incidencias
//      List<Map<String, Object>> lstIncidencias2 = (ArrayList) mapDatos.get("lstIncidencias");
//      if (lstIncidencias2 != null && lstIncidencias2.size() > 0)
//      {
//        for (Map incid2 : lstIncidencias2)
//        {
//
//          this.detIncidenciaDAO.insert(incid2);
//        }
//      }
      //pase42 lalberti
      if("S".equals(mapParametros.get("IND_INCIDENCIA"))){
    	  List<Incidencia> lstIncidencias2 = (ArrayList<Incidencia>) mapParametros.get("lstIncidencias");
    	     if(!CollectionUtils.isEmpty(lstIncidencias2)) {
    	        int numItm = 0;
    	       Map incidencia;
    	        for(Incidencia incidenciaBean:  lstIncidencias2) {
    	          numItm += 1;
    	         incidencia = new HashMap();
    	          incidencia.put("NUM_CORREDOC", mapDiligencia.get("NUM_CORREDOC"));
    	         incidencia.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_RECTIFICACION);

    	         incidencia.put("NUM_SECINCID", "" + numItm);
    	          incidencia.put("NUM_SERIE", incidenciaBean.getNumeroSerie());
    	          incidencia.put("COD_INCIDENCIA", incidenciaBean.getCodIncidencia());
    	          incidencia.put("NUM_CORREDOC_SOL", numCorredocSol);
    	          incidenciaService.insert(incidencia);
    	       }


          //this.detIncidenciaDAO.insert(incid2);
        }
		// fin lalberti
      }

    //lmvr - Inicio: Complemento de la Diligencia
      Boolean actualizaFechaRegularizacion =(Boolean)mapParametros.get("actualizaFechaRegularizacion");
      //CabdeclaraDAO cabdeclaraDAO = fabricaDeServicios.getService("manifiesto.manifiestoService");
      if (actualizaFechaRegularizacion) {
	     //String fechaRegularizacionProrroga =(String)mapParametros.get("fechaRegularizacionProrroga");
	      Date fechaRegularizacionProrr= (Date) mapParametros.get("fechaRegularizacionProrroga");
	      
	      Map params = new HashMap();
	      params.put("FEC_VENCREGULA", fechaRegularizacionProrr);
	      
	    /*  Map<String, Object> datos = (Map<String, Object>) mapDatos.get("mapCabDeclaraActual");
	      String numeroCorrelativoAsString = (String) datos.get("NUM_CORREDOC");
	      Long numeroCorrelativo = new Long(numeroCorrelativoAsString);*/
	     params.put("NUM_CORREDOC", ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual")).get("NUM_CORREDOC"));
	    //  params.put("NUM_CORREDOC", numeroCorrelativo);
	      cabDeclaraDAO.update(params);
      }
    //lmvr - Fin: Complemento de la Diligencia
      
//   //actualizar para importador oea
//      // PASE PAS20181U220200016
      Map prmCodriesgoOEA = new HashMap<String, Object>();
      
      prmCodriesgoOEA.put("NUM_CORREDOC", ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual")).get("NUM_CORREDOC"));
      prmCodriesgoOEA.put("DECLARACION", mapParametros.get("declaracion") );
      this.procesarCodigoriesgoOEA(prmCodriesgoOEA);
      //mapDatos.put("COD_RIESGOOEA",prmCodriesgoOEA.get("COD_RIESGOOEA").toString());
      mapResult.put("COD_RIESGOOEA",prmCodriesgoOEA.get("COD_RIESGOOEA")!=null?prmCodriesgoOEA.get("COD_RIESGOOEA").toString():"00");

      
      //rtineo mejoras, iniciamos la grabacion en proceso batch
      if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
    	  diligenciaBatchService.iniciarRegistrarRectificacion();
      }

      for (String codTablaRecticar : tablasRectificacion)
      {

        RectificacionAbstract rectifi = fabricaDeServicios.getService("diligencia.rectificacion.codtabla."
            + codTablaRecticar);
        if (rectifi != null)
        {
          int count = rectifi.grabarRectificacion(numCorredocSol, mapDatos);
        }
        else
        {
          log.warn("La clase de rectificacion para la tabla con codigo: \""
              + codTablaRecticar + "\" no se encuentra registrada o no es soportada");
        }

      }
      //rtineo terminamos la grabacion en proceso batch
      if(codTransaccion.equals(COD_TRANSACCION_RECTIFICACION_ELECTRONICA)){
    	  diligenciaBatchService.procesarRegistrarRectificacion();
   
//        Declaracion declaracion =  (Declaracion)mapParametros.get("declaracion");
////      	for (DAV dav : declaracion.getListDAVs()) {
////      		
////      	   for (Map<String, Object> data : (ArrayList<Map<String, Object>>) mapDatos.get("lstParticipanteActual"))
////           { 
////      		 long secuenciaParticipante =  dav.getProveedor().getSecuenciaDeParticipantes();
////         	 if (data.get("NUM_SECPARTIC").equals(secuenciaParticipante)){
////         		dav.getProveedor().setCodigoOea((String) data.get("COD_EMPRESA"));
////         		dav.getProveedor().setPaisOea((String) data.get("COD_PAISARM"));
////         	 }
////         	  
////           }
////      	
////      	}
//          
//     	//actualizar para importador oea
//        // PASE PAS20181U220200016
//        Map prmCodriesgoOEA = new HashMap<String, Object>();          
//        prmCodriesgoOEA.put("NUM_CORREDOC", ((Map<String, Object>) mapDatos.get("mapCabDeclaraActual")).get("NUM_CORREDOC"));
//        prmCodriesgoOEA.put("DECLARACION", declaracion );
//        
//          this.procesarCodigoriesgoOEA(prmCodriesgoOEA);
//    	  //mordonezl OEA
      }

      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + mapParametros.get("caduana").toString().trim()));

      Map<String, Object> declaracion = new HashMap<String, Object>();
      declaracion = (HashMap<String, Object>) mapParametros.get("mapCabDeclaraActual");
      List listaMultasSeleccionadas = (ArrayList) mapParametros.get("lstMultas");
      if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
      {

        String codDocumento = declaracion.get("NUM_CORREDOC").toString();
        String codTipoDiligencia = COD_TIPO_DILIGENCIA_RECTIFICACION;
        Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
        String tipoDocImp = (String) declaracion.get("COD_TIPDOC_PIM");
        String rucImp = (String) declaracion.get("NUM_DOCIDENT_PIM");
        String rucAgente = (String) declaracion.get("NUM_DOCIDENT_PDE");
        Map<String, Object> operador = operadorAyudaService.getOperador(rucAgente, "41");
        if (operador != null && !operador.isEmpty())
        {
          Map paramMulta = new HashMap();
          paramMulta.put("COD_DOCUMENTO", codDocumento);
          paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
          paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
          paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
          paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
          paramMulta.put("NUM_REG_USUARIO", declaracion.get("COD_USUMODIF"));
          paramMulta.put("COD_ANTADU", operador.get("COD_ANTADU"));
          paramMulta.put("tipDilig", codTipoDiligencia);
          //pase42 lalberti incidencias y multas
          paramMulta.put("generacionLCMulta", mapParametros.get("generacionLCMulta"));
          paramMulta.put("generarLC003", mapParametros.get("generarLC003"));
          paramMulta.put("mapCabDeclaraActual", mapCabDeclaraActual);
         
          if(!numCorredocSol.isEmpty()){
        	  paramMulta.put("NUM_CORREDOC_SOL", numCorredocSol);
          }
		  //fin lalberti
          multaService.generarMulta(paramMulta, listaMultasSeleccionadas, false);
        }
      }
      List<String> regimenesNoAptos = Arrays.asList(new String[]
      { "70", "20", "21" });
      String tieneIncTrib = mapCabDeclaraActual.containsKey("tieneIncTrib") ? mapCabDeclaraActual
          .get("tieneIncTrib")
          .toString() : "N";
		boolean tieneIncTribMenor = (Boolean) (mapCabDeclaraActual.containsKey("tieneIncTribMenor") ? mapCabDeclaraActual.get("tieneIncTribMenor") : false); //P29  
    	  //RIN10-FSW AFMA
  		Declaracion odeclaracion = (Declaracion)mapParametros.get("declaracion");
  		odeclaracion.getDua().setCodCanal(declaracion.get("COD_CANAL")!=null?(String)declaracion.get("COD_CANAL"):"");//PAS20175E220200021
  		
  		Declaracion odeclaracionBD = (Declaracion)mapParametros.get("declaracionBD");
  		actualizarCtaCteRegimen(odeclaracion, SunatNumberUtils.toLong(declaracion.get("NUM_CORREDOC")));//gmontoya P29 Pase94
  		Map mapVP = valorProvisionalService.grabarValorProvisional(odeclaracion,odeclaracionBD);

  		/*INICIO P46 - PAS20155E220000329*/
  		ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
		boolean estaImpugnadaDeudaDonacion = impugnacionTributosParaDonacionService.estaImpugnadaDeuda(odeclaracion);
		/*FIN P46 - PAS20155E220000329*/
		
		//MOL - PASE 27 GARANTIA OEA
		boolean esRectificacionCorrienteGarantiaOEA = (Boolean) (mapParametros.get("esRectificacionCorrienteGarantiaOEA")!=null?mapParametros.get("esRectificacionCorrienteGarantiaOEA"):false);
		boolean esrectiCtaCteGarantiaOEASinIncidencia = esRectificacionCorrienteGarantiaOEA && !"S".equals(tieneIncTrib);
		boolean esrectiCtaCteGarantiaOEAConIncidencia = esRectificacionCorrienteGarantiaOEA && "S".equals(tieneIncTrib);

        // REASIGNACION DE CANAL
  		//RIN10 FSW AFMA
	  //if (!regimenesNoAptos.contains(mapCabDeclaraActual.get("COD_REGIMEN").toString()) &&
          //( "S".equals(tieneIncTrib) || tieneIncTribMenor))	
      if (!regimenesNoAptos.contains(mapCabDeclaraActual.get("COD_REGIMEN").toString()) && ("S".equals(tieneIncTrib) || tieneIncTribMenor || tieneLCValorProvionalParaGarantizar(mapVP) || estaImpugnadaDeudaDonacion || esrectiCtaCteGarantiaOEASinIncidencia))//P46 - PAS20155E220000329 agrego estaImpugnadaDeudaDonacion
      {

        Map paramDiligencia = new HashMap();
        paramDiligencia.put("mapCabDeclaraActual", mapCabDeclaraActual);
        paramDiligencia.put("mapCabDiligenciaActual", mapDiligencia);
        //RIN10-FSW AFMA
  		paramDiligencia.put("mapVP",mapVP);
        //gmontoya inicio pase 192 arreglo
        paramDiligencia.put("generarLC15_NO_9", mapParametros.get("generarLC15_NO_9"));
        paramDiligencia.put("declaracionBD", odeclaracionBD);
        //gmontoya fin pase 192 arreglo
  		
//INICIO-FSW
        /* por la puras amancilla
        paramDiligencia.put("duaConGarantia160VigenteAndConSaldo", datosRectificacionConIncidencia.get("duaConGarantia160VigenteAndConSaldo"));
        paramDiligencia.put("recienSeAcogeGarantia160", datosRectificacionConIncidencia.get("recienSeAcogeGarantia160"));
        paramDiligencia.put("duaSiTieneGarantia160", datosRectificacionConIncidencia.get("duaSiTieneGarantia160"));
        paramDiligencia.put("recienRectificaCambioModalidadAExcepcional", datosRectificacionConIncidencia.get("recienRectificaCambioModalidadAExcepcional"));*/
//FIN-FSW
        // amancilla liquidaDeclaracionService.grabaLiqDiligencia(paramDiligencia);
		 //mapResult
        //mol pase 27 garantia OEA
        	paramDiligencia.put("esrectiCtaCteGarantiaOEASinIncidencia", esrectiCtaCteGarantiaOEASinIncidencia);
        	paramDiligencia.put("esrectiCtaCteGarantiaOEAConIncidencia", esrectiCtaCteGarantiaOEAConIncidencia);
		   Map  notificaciones = liquidaDeclaracionService.grabaLiqDiligenciaRectificacion(paramDiligencia);
		  mapResult.put("lstDeudasAAfectar",notificaciones.get("lstDeudasAAfectar")!=null?notificaciones.get("lstDeudasAAfectar"): new ArrayList());
		  mapResult.put("mensaje", notificaciones.get("mensaje")); //PAS20165E220200127
		  //fin amancilla

      }else{//pase105
    	  Map paramDiligencia = new HashMap();
          paramDiligencia.put("mapCabDeclaraActual", mapCabDeclaraActual);
          paramDiligencia.put("mapCabDiligenciaActual", mapDiligencia);
          liquidaDeclaracionService.actualizaLiqDiligencia(paramDiligencia);
      }


		/**INICIO P28-Part2*/
		Map<String,Object> paramsContSaldo = new HashMap<String, Object>();
		paramsContSaldo.put("COD_ADUANA", mapCabDeclaraActual.get("COD_ADUANA"));
		paramsContSaldo.put("ANN_PRESEN", mapCabDeclaraActual.get("ANN_PRESEN"));
		paramsContSaldo.put("NUM_DECLARACION", mapCabDeclaraActual.get("NUM_DECLARACION"));
		paramsContSaldo.put("dicadu", mapCabDeclaraActual.get("COD_ADUANA"));
		paramsContSaldo.put("difano", mapCabDeclaraActual.get("ANN_PRESEN"));
		paramsContSaldo.put("dindcl", mapCabDeclaraActual.get("NUM_DECLARACION"));
		ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");

		List lstDetDeclara = (ArrayList)mapDatos.get("lstDetDeclaraActual");

		List lstDetDeclaraAnt =  (ArrayList)mapDatos.get("lstDetDeclara");

		paramsContSaldo.put("lstDocuPreceDuaActual", (ArrayList)mapDatos.get("lstDocuPreceDuaActual"));
		paramsContSaldo.put("lstDocuPreceDua", (ArrayList)mapDatos.get("lstDocuPreceDua"));
		paramsContSaldo.put("lstConvenioSerie", (ArrayList)mapDatos.get("lstConvenioSerie"));
		paramsContSaldo.put("lstConvenioSerieActual", (ArrayList)mapDatos.get("lstConvenioSerieActual"));


		String numCorreDoc = mapCabDeclaraActual.get("NUM_CORREDOC").toString();
		boolean tieneDiligencia = CollectionUtils.isEmpty(this.diligenciaService.findDuaDiligenciada(numCorreDoc))?false:true;

		paramsContSaldo.put("NUM_CORREDOC_DUA", numCorreDoc);//P28-PAS20155E410000032-[jlunah]
		controlarSaldoReposicionService.actualizarSaldoCertificadoDiligenciaRecti(lstDetDeclara, lstDetDeclaraAnt, paramsContSaldo,tieneDiligencia);
		/**FIN P28-Part2*/
		//ini P28-PAS20155E410000032 - bug 24010
		controlarSaldoReposicionService.actualizarRelacionTemporalSerieItemCrmf(SunatNumberUtils.toLong(numCorreDoc), "1");
		//fin P28-PAS20155E410000032 - bug 24010

      Map mapCabSolRecti = new HashMap<String, Object>();
      FechaBean fechaBean = new FechaBean();
      mapCabSolRecti.put("DES_RESULEVAL", mapParametros.get("DES_RESULEVAL"));
      if (mapParametros.get("INDICADOR_SELECCION").toString().equals("FULL"))
      {
        mapCabSolRecti.put("COD_ESTARECTI", "05");
      }
      else
      {
        mapCabSolRecti.put("COD_ESTARECTI", "06");
      }
      mapCabSolRecti.put("FEC_EVALUACION", fechaBean.getTimestamp());
      mapCabSolRecti.put("NUM_CORREDOC", mapParametros.get("NUM_CORREDOC_PRE"));
      mapCabSolRecti.put("NUM_EXPEDIENTES", mapParametros.get("NUM_EXPEDIENTES"));
      cabSolrectiDAO.update(mapCabSolRecti);
      
      //ggranados pase 39 procedente
      Solicitud solicitud = new Solicitud();
      solicitud.setNumeroCorrelativo(SunatNumberUtils.toLong(numCorredocSol));
      solicitud.setFechaAtencion(new Date());
      SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
      solicitudDAO.updateByPrimaryKeySelective(solicitud);

      String[] expedientes = mapCabSolRecti.get("NUM_EXPEDIENTES") == null ? new String[]
      {} : (String[]) mapCabSolRecti.get("NUM_EXPEDIENTES");
      mapCabSolRecti.put("fortipoopedif", "E");
      mapCabSolRecti.put("COD_TIPOPER", "R");
      List<Map<String, Object>> rows = docAutAsociadoDAO.select(mapCabSolRecti);
      Integer numSecdoc = 1;
      if (!CollectionUtils.isEmpty(rows))
      {
        Collections.sort(rows, new Comparator<Map<String, Object>>()
        {
          @Override
          public int compare(Map<String, Object> thiss, Map<String, Object> that)
          {
            Integer nthiss = new Integer(thiss.get("NUM_SECDOC").toString());
            Integer nthat = new Integer(that.get("NUM_SECDOC").toString());
            return nthiss.compareTo(nthat);
          }
        });
        numSecdoc = rows.size() + 1;
      }
      //pase 42 morodnezl
      if(expedientes.length>0){
      for (String expediente : expedientes)
      {
        String[] splitexpedientes = expediente.split("-");
        if(splitexpedientes.length>0){ //mordonezl pase42
        mapCabSolRecti.put("NUM_SECDOC", numSecdoc);
        mapCabSolRecti.put("COD_TIPDOCASO", "14");
        mapCabSolRecti.put("COD_ADU_AUT", splitexpedientes[0]);
        mapCabSolRecti.put("ANN_DOC", splitexpedientes[1]);
        mapCabSolRecti.put("NUM_DOC", splitexpedientes[2]);
        docAutAsociadoDAO.insertSelective(mapCabSolRecti);
        numSecdoc++;
        }
      }
    }
      // llamar a datado se tiene que la diligencia
		//r2bz Se invoca desde el servicio del orquestador
		//mapDatos.put("mapCabDiligenciaActual", mapDiligencia);
		//this.getDiligenciaService().realizarDatado(mapDatos);
      
      /***** GGRANADOS RIN16PASE3 INI *****/
      Map<String, Object> datosCambioModalidad = declaracionService.getDatosParaEvaluarCambioModalidad(mapDatos);
      
      String cambiaModalidad = declaracionService.procesarCambioModalidadRegularizacion(
    		  (String)datosCambioModalidad.get("codModalidad"),
    		  (String)datosCambioModalidad.get("codModalidadActual"),
    		  (Boolean)datosCambioModalidad.get("tieneIndicadorRegularizable"),
    		  (Boolean)datosCambioModalidad.get("tieneIndicadorRegularizableActual"));
      
      if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_REGULARIZABLE)){
    	  DUA dua = new DUA();
    	  dua.setNumcorredoc(Long.parseLong(declaracion.get("NUM_CORREDOC").toString()));
    	  dua.setCodaduanaorden(declaracion.get("COD_ADUANA").toString());
    	  DatoManifiesto datoManifiesto = new DatoManifiesto();
    	  datoManifiesto.setNummanif(declaracion.get("NUM_MANIFIESTO").toString());
    	  datoManifiesto.setAnnmanif(declaracion.get("ANN_MANIFIESTO").toString());
    	  datoManifiesto.setCodaduamanif(declaracion.get("COD_ADUAMANIFIESTO").toString());
    	  datoManifiesto.setCodtipomanif(declaracion.get("COD_TIPMANIFIESTO").toString());
    	  datoManifiesto.setCodmodtransp(declaracion.get("COD_VIATRANS").toString());
    	  dua.setManifiesto(datoManifiesto);
    	  declaracionService.actualizarDatosRegularizacion(dua);
      }else if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_NO_REGULARIZABLE)){
    	  declaracionService.limpiarDatosRegularizacion(Long.parseLong(declaracion.get("NUM_CORREDOC").toString()));
      }
      /***** GGRANADOS RIN16PASE3 FIN *****/
      // REASIGNACION DE CANAL
      
	/*P14 - 3007 - Inicio - dhernandezv */
        	
	
//	if(!declaracion.get("COD_CANAL").toString().trim().equals("") || !declaracion.get("COD_CANAL").toString().equals(" ")){
//		Map<String, Object> datosReasignacion = grabarReasignacionCanal(numCorredocSol, mapCabDeclaraActual);
//		mapResult.putAll(datosReasignacion);
//	} 
      
      	//Inicio por PAS20181U220200022
        boolean vaIndicadorImpFrecuente = false; 
   	 	GrabarFormatoAService grabarFormatoAService = (GrabarFormatoAService)fabricaDeServicios.getService("grabarFormatoAService");
   	 	//fin por PAS20181U220200022
   	 	
       //boolean indImpFrecuente = false;
		Map<String, Object> MapaModImporFrec =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat("380", "0034",(Date) declaracion.get("FEC_DECLARACION"));
		
		String tipoDocum = (String) declaracion.get("COD_TIPDOC_PIM");
        String numeDocum = (String) declaracion.get("NUM_DOCIDENT_PIM");
		
        if (!CollectionUtils.isEmpty(MapaModImporFrec)){
         
        	/*ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
          if (funcionesService.isImportadorFrecuente(declaracion.get("COD_REGIMEN").toString(), tipoDocum, numeDocum)) {
          	indImpFrecuente = true;
          	 }
          else {
  			Map<String, Object> MapaInvitadoOEA =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat(ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numeDocum,(Date) declaracion.get("FEC_DECLARACION"));
  			if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
  				indImpFrecuente = true;
  			} 
          } 
          Map<String,Object> mapIndicadoresDUA=new HashMap<String, Object>();
			mapIndicadoresDUA.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString());
			mapIndicadoresDUA.put("cod_indicador", "05");
			int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(mapIndicadoresDUA).get("CANT")).intValue();
          if (indImpFrecuente && declaracion.get("COD_MODALIDAD").toString().trim().equals( ConstantesDataCatalogo.MODA_ANTICIPADA ) ) {
				 if(existeIndicador==0){
		            mapIndicadoresDUA.put("numCorredoc",declaracion.get("NUM_CORREDOC").toString());
		            mapIndicadoresDUA.put("codIndicador", "05");
					mapIndicadoresDUA.put("codTiporegistro", "A");
					indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
				} 
          } else {
				 if(existeIndicador > 0){
		            mapIndicadoresDUA.put("numCorredoc", declaracion.get("NUM_CORREDOC").toString());
		            mapIndicadoresDUA.put("codIndicador", "05");
					mapIndicadoresDUA.put("codTiporegistro", "A");
					mapIndicadoresDUA.put("indActivo", "0");
					indicadorDUADAO.update(mapIndicadoresDUA);
				}	*/
			 
          
    		//R1804: ATRG201802 PAS20181U220200022 Los beneficios del importador frecuente se aplican solo cuando se numera una 
			//declaraci�n de modalidad anticipada de los reg�menes 10,20,21,
			//o modalidad de despacho urgente o diferido del r�gimen 10 sujeta a una cuota o contingente arancelario.   			 
  			String codregimen =   declaracion.get("COD_REGIMEN").toString(); 
  			String codModalidad =  declaracion.get("COD_MODALIDAD").toString(); 
  			Elementos<DatoSerie> listSeries =odeclaracion.getDua().getListSeries();
  			vaIndicadorImpFrecuente = grabarFormatoAService.esImportadorFrecuenteNuevasCondiciones(codregimen, tipoDocum, numeDocum, codModalidad, listSeries);
  	 		
		}
       grabarFormatoAService.actualizarIndicadorImportadorFrecuente(new Long(numCorreDoc), vaIndicadorImpFrecuente) ;
       //PAS201830001100016 mordonezl
//enviar aviso electronico en caso de acogimiento posterior a amazonia despues 
       for(int j = 0; j< listIndicadorDua.size(); j++){
    	   
    	   String codIndicador = listIndicadorDua.get(j).get("COD_INDICADOR").toString();
    	   if("62".equals(codIndicador) && acogimientoPostNumPecoAmazonia.equals("SI")){
    		   if(!codAduanaDestino.equals("")){
    			   SolicitudPecoAmazoniaService solicitudPecoAmazoniaService = (SolicitudPecoAmazoniaService) fabricaDeServicios.getService("despaduanero2.solicitudPecoAmazoniaService");
    	    		  //boolean enviarAviso =  solicitudPecoAmazoniaService.procesarAvisoAcogimientoPosteriorLeyAmazoniaAduanaDestino(numDeclaracion, codAduana, codAduanaDestino);
    	    		  boolean enviarAviso =  true;
//    	    				  solicitudPecoAmazoniaService.procesarAvisoAcogimientoPosteriorLeyAmazoniaAduanaDestino(mapCabDeclaraActual);
    		   }
    	
    	   }
  
    	   if("63".equals(codIndicador) ){
    		   
    			   SolicitudPecoAmazoniaService solicitudPecoAmazoniaService = (SolicitudPecoAmazoniaService) fabricaDeServicios.getService("despaduanero2.solicitudPecoAmazoniaService");
    			   //boolean enviarAviso =  solicitudPecoAmazoniaService.procesarAvisoDesistimientoPecoAmazoniaAduanaDestino(numDeclaracion, codAduana, adunaDestinoBD);
    			   String aduanaDestinoBD = declaracionBD.getDua().getOtraAduana()!=null && declaracionBD.getDua().getOtraAduana().getCodopadusal()!=null?declaracionBD.getDua().getOtraAduana().getCodopadusal():"";
    			   boolean enviarAviso =  false;
//    					   solicitudPecoAmazoniaService.procesarAvisoDesistimientoPecoAmazoniaAduanaDestino(mapCabDeclaraActual,aduanaDestinoBD);
    		   
    	
    	   }
       }
  // FIN PAS201830001100016
    }
    catch (Exception e)
    {
      log.error("**** ERROR ****", e);
      throw new ServiceException(this, e.getMessage());
    }

    return mapResult;
  }
  
  /** PAS20171U220200005 si es registro nuevo acogimiento al impconsumo, se valida para indicarle el nro de envio parcial 
	 * @param numCorredocDAM
	 * @param esAcogidoAntes
   * * @param estaAcogidoRecien
	 */
	public void grabarNroEnvioParcialMercanciaVigente(String numCorredocDAM,   boolean esAcogidoAntes, boolean estaAcogidoRecien) {
		if(!numCorredocDAM.isEmpty()) {
			boolean esTPN21 = false;
			String numEnvioParcial = "1";//por defecto si es primigenia va 1
			
			if(!esAcogidoAntes && estaAcogidoRecien) {//se incorpora el indicador recien
				//chekear si tiene convenio serie 21
				Map<String, Object> paramConvSerie = new HashMap<String, Object>();
				paramConvSerie.put("NUM_CORREDOC", new Long(numCorredocDAM));
		        paramConvSerie.put("COD_CONVENIO", SunatStringUtils.lpad("21",4,' '));
		        paramConvSerie.put("COD_TIPCONVENIO", "T");  
	            ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("diligencia.ingreso.convenioSerieDef");
	            List<Map<String,Object>> lstTpnv21 =convenioSerieDAO.select(paramConvSerie);
				if(!CollectionUtils.isEmpty(lstTpnv21)) {
					esTPN21 = true;
				}
				
				if(esTPN21){
					Integer valorSecuenciaNueva = new Integer(0); 
					ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
					Long numCorredocPrimigenia = valMercanciaVigenteService.obtenerNumcorredocPrimigeniaPorVigente(new Long(numCorredocDAM), 1);
					
					valorSecuenciaNueva = valMercanciaVigenteService.obtenerEnviosRegistrados(numCorredocPrimigenia);
					numEnvioParcial = valorSecuenciaNueva.toString();//al contar esta contando el que se va a registrar.		
				}
				
				Map<String,Object> mapDatos=new HashMap<String, Object>();
				mapDatos.put("NUM_ENVIOPARCIAL",  numEnvioParcial);
				mapDatos.put("NUM_CORREDOC", new Long(numCorredocDAM));
				CabAdjImpoconsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");
				cabAdiImpoconsuDAO.update(mapDatos);
				
			}  
		}		
	}
   
	private String getCabDeclaraIDs(Map<String, ?> cabdeclaraMap){
		StringBuffer sb = new StringBuffer()
		.append(cabdeclaraMap.get("COD_ADUANA"))
		.append("-").append(cabdeclaraMap.get("ANN_PRESEN"))
		.append("-").append(cabdeclaraMap.get("COD_REGIMEN"))
		.append("-").append(cabdeclaraMap.get("NUM_DECLARACION"))
		.append(" (").append(cabdeclaraMap.get("NUM_CORREDOC")).append(")")
		;
		return sb.toString();
	}
     
	 	/**
	 * RIN10 FSW AFMA
	 *
	 * @param mapVP
	 * @return
	 */
	public  boolean tieneLCValorProvionalParaGarantizar(Map mapVP)
	{
        boolean tieneLCValorProvionalParaGarantizar = false;

		if(CollectionUtils.isEmpty(mapVP)){
			return false;
		}

		List lstDeudasAAfectarVP =  mapVP.get("lstDeudasAAfectarVP")!=null?(ArrayList)mapVP.get("lstDeudasAAfectarVP"):new ArrayList();
		Map   mpDeudasADesafectarVP = mapVP.get("mpDeudasADesafectarVP")!=null?(HashMap)mapVP.get("mpDeudasADesafectarVP"):new HashMap();


		if(!CollectionUtils.isEmpty(lstDeudasAAfectarVP) || !CollectionUtils.isEmpty(mpDeudasADesafectarVP)){

			tieneLCValorProvionalParaGarantizar=true;
		}


		return tieneLCValorProvionalParaGarantizar;
	}
  public CabDeclaraDAO getCabDeclaraDAO() {
	return cabDeclaraDAO;
}

public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
	this.cabDeclaraDAO = cabDeclaraDAO;
}
		  
//  
//	private void procesarCambioModalidadRegularizacion(
//			Map<String, Object> mapDatos) {
//		// TODO logica para el cambio de modalidad
//		Map<String, Object> mapCabDeclara = (Map<String, Object>) mapDatos.get("mapCabDeclara");
//		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) mapDatos.get("mapCabDeclaraActual");
//		List<Map<String, Object>> lstIndicadorDua = (List<Map<String, Object>>) mapDatos.get("lstIndicadorDua");
//		List<Map<String, Object>> lstIndicadorDuaActual = (List<Map<String, Object>>) mapDatos.get("lstIndicadorDuaActual");
//		
//		String codModalidad = MapUtils.getMapValor(mapCabDeclara, "COD_MODALIDAD");
//		String codModalidadActual = MapUtils.getMapValor(mapCabDeclaraActual, "COD_MODALIDAD");
//		
//		boolean tieneIndicadorRegularizable = tieneIndicadorRegularizable(lstIndicadorDua);
//		boolean tieneIndicadorRegularizableActual = tieneIndicadorRegularizable(lstIndicadorDuaActual);
//		
//		if(!codModalidad.equals(codModalidadActual) || 
//				tieneIndicadorRegularizable != tieneIndicadorRegularizableActual){
//			if(cambiaARegularizable(codModalidad, codModalidadActual, tieneIndicadorRegularizable, tieneIndicadorRegularizableActual)){
//				
//			}else if(cambiaANoRegularizable(codModalidad, codModalidadActual, tieneIndicadorRegularizable, tieneIndicadorRegularizableActual)){
//				
//			}
////			
////		}
//
//		
//		
//		
//		
//
//	}
	


	/***** GGRANADOS RIN16PASE3 FIN *****/


/**
   * Obtener el canal que resulto menor al momento de la revaluacion de canal,.
   *
   * @param params
   *          the params
   * @return the response seleccion
   */
  private ResponseSeleccion obtenerCanalRevaluadoMenor(Map<String, Object> params)
  {
    ResponseSeleccion responseSeleccion = null;
//pase 13
	  ControlVigenciaService controlVigencia = fabricaDeServicios.getService("despaduanero2.declaracion.controlVigenciaService");
	  boolean esReglaApiRiesgoVigente = controlVigencia.esReglaVigente(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
			  COD_VIGENCIA_INVOCACION_API_RIESGO, SunatDateUtils.getCurrentDate());

	  if(esReglaApiRiesgoVigente) {
		  String obtenerCanalPath = "/e/obtenerCanal?numcorredoc=%s&momento=%s&codAduana=%s&codRegimen=%s&annDeclara=%s&numDeclaracion=%s";

		  String obtenerCanalUri = BASE_API_RIESGO_PATH + String.format(obtenerCanalPath,
				  params.get("NUM_CORREDOC").toString(),
				  MOMENTO_PARAM_WS_REVALUACION_RIESGO,
				  null,
				  null,
				  null,
				  null);
		  RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		  CanalEvaluadoResponse canalEvaluadoResponse = restTemplate.getForObject(obtenerCanalUri, CanalEvaluadoResponse.class);
		  responseSeleccion = new ResponseSeleccion();
		  responseSeleccion.setAforo(canalEvaluadoResponse.getCanalEvaluado().getAforo());
		  responseSeleccion.setMotaforo(canalEvaluadoResponse.getCanalEvaluado().getMotAforo());
	  } else {
		  // Invocando al Servicio
		  // NSR Se carga el servicio con la fabrica de Servicios
		  SeleccionValidacionService seleccionValidacionService = fabricaDeServicios
				  .getService("seleccion.SeleccionValidacionService");
		  Map<String, Object> parametros = new HashMap<String, Object>();
		  parametros.put("numcorredoc", params.get("NUM_CORREDOC").toString());
		  parametros.put("indduamom", "1");
		  parametros.put("momento", MOMENTO_PARAM_WS_REVALUACION_RIESGO);
		  try
		  {
			  Map retorno = seleccionValidacionService.obtenerCanal(parametros);
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo((String) retorno.get("aforo"));
			  responseSeleccion.setMotaforo((String) retorno.get("motaforo"));
		  }
		  catch (Exception e)
		  {
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo("");
			  responseSeleccion.setMotaforo("");
		  }
	  }

    return responseSeleccion;
  }

  /**
   * Evalua la consistencia en los datos de canal asignado a la DUA y los
   * registrados en las tablas de Riesgo Si responseSeleccion.codigoError = 0
   * Aun no Existen datos de canal, ni en la Dua ni en las tablas de Riesgo. Si
   * responseSeleccion.codigoError = 1 Existen Datos en Dua y Riesgo y son
   * consistentes entre si. En cualquier otro caso hay inconsistencia en los
   * datos de Riesgo. En casos
   *
   * @param params
   *          the params
   * @return the response seleccion
   */
  private ResponseSeleccion evaluarConsistenciaCanalDuaRiesgo(Map<String, Object> params){
	  ResponseSeleccion responseSeleccion = null;
//pase 13
	  ControlVigenciaService controlVigencia = fabricaDeServicios.getService("despaduanero2.declaracion.controlVigenciaService");
	  boolean esReglaApiRiesgoVigente = controlVigencia.esReglaVigente(pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
			  COD_VIGENCIA_INVOCACION_API_RIESGO, SunatDateUtils.getCurrentDate());

	  if(esReglaApiRiesgoVigente) {
		  String evaluarPath = "/e/evaluarConsistenciaCanal?aduana=%s&regimen=%s&codundsel=%s&annundsel=%s&numundsel=%s&numcorredoc=%s";
		  String evaluarCanalUri = BASE_API_RIESGO_PATH + String.format(evaluarPath, null, null, "0001", null, null, params.get("NUM_CORREDOC").toString());
		  RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		  ConsistenciaCanalResponse consistenciaCanalResponse = restTemplate.getForObject(evaluarCanalUri, ConsistenciaCanalResponse.class);

		  if(consistenciaCanalResponse != null && !consistenciaCanalResponse.getConsistenciaCanal().getResultado().equals("-1")){
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo(consistenciaCanalResponse.getConsistenciaCanal().getCanalRiesgo());
			  responseSeleccion.setMotaforo(consistenciaCanalResponse.getConsistenciaCanal().getMotivoRiesgo());
			  responseSeleccion.setMensajeError(consistenciaCanalResponse.getConsistenciaCanal().getMensaje());
			  responseSeleccion.setCodigoError(consistenciaCanalResponse.getConsistenciaCanal().getResultado());
		  } else {
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo("");
			  responseSeleccion.setMotaforo("");
			  responseSeleccion.setMensajeError("Hubo un error al invocar al Servicio que verifica la consistencia de canal");
			  responseSeleccion.setCodigoError("-1");
		  }

		  return responseSeleccion;
	  } else {
		  SeleccionValidacionService seleccionValidacionService = fabricaDeServicios
				  .getService("seleccion.SeleccionValidacionService");

		  Map retorno = seleccionValidacionService.evaluarConsistenciaCanal(
				  null,
				  null,
				  pe.gob.sunat.despaduanero2.seleccion.util.Constantes.ESDECLARACION,
				  null,
				  null,
				  params.get("NUM_CORREDOC").toString());
		  if (retorno != null && (!retorno.get("resultado").toString().equals("-1"))){
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo((String) retorno.get("canalRiesgo"));
			  responseSeleccion.setMotaforo((String) retorno.get("motivoRiesgo"));
			  responseSeleccion.setMensajeError(retorno.get("mensaje").toString());
			  responseSeleccion.setCodigoError(retorno.get("resultado").toString());
		  } else {
			  responseSeleccion = new ResponseSeleccion();
			  responseSeleccion.setAforo("");
			  responseSeleccion.setMotaforo("");
			  responseSeleccion.setMensajeError("Hubo un error al invocar al Servicio que verifica la consistencia de canal");
			  responseSeleccion.setCodigoError("-1");
		  }
		  return responseSeleccion;
  }
  }



  /**
   * Grabar reasignacion canal.
   *
   * @param numCorredocSol
   *          the num corredoc sol
   * @param declara
   *          the declara
   * @return the map
   */
  public Map<String, Object> grabarReasignacionCanal(String numCorredocSol, Map<String, Object> declara)
  {

    /************* Cargar Canal Actual de la DUA *************/
    ResponseSeleccion seleccionActual = new ResponseSeleccion();
    seleccionActual.setAforo(declara.get("COD_CANAL") != null ? declara.get("COD_CANAL").toString() : "");
    seleccionActual.setMotaforo(declara.get("COD_MOTIVOCANALASIG") != null ? declara.get("COD_MOTIVOCANALASIG").toString() : "");
    /************* ************/

    Map<String, Object> mapResult = new HashMap<String, Object>();
    mapResult.put("COD_CANAL_REE", seleccionActual.getAforo());
    mapResult.put("COD_CANAL_REE_DESC", catalogoAyudaService.getDescripcionDataCatalogo("AR", seleccionActual.getAforo()));

    /**************** CARGA DATOS DE LA DECLARACION ***************/
    // dua
    DUA dua = new DUA();
    dua.setCodaduanaorden(declara.get("COD_ADUANA").toString());
    dua.setAnnpresen(new Integer(declara.get("ANN_PRESEN").toString()));
    dua.setCodregimen(declara.get("COD_REGIMEN").toString());
    dua.setFecAutlevante(declara.get("FEC_AUTLEVANTE") == null ? null : (Date) declara.get("FEC_AUTLEVANTE"));

    // Declaracion
    Declaracion declaracion = new Declaracion();
    declaracion.setNumeroDeclaracion(new Long(declara.get("NUM_DECLARACION").toString()));
    declaracion.setNumeroCorrelativo(new Long(declara.get("NUM_CORREDOC").toString()));
    declaracion.setDua(dua);

	/* P14 - 3007 - Inicio - dhernandezv */
	declaracion.setFechaRecepcion((Date) declara.get("FEC_RECEP"));
	/* P14 - 3007 - Fin - dhernandezv */
	
    /******************** EVALUACION DE CONSISTENCIA DE CANAL ************/

    // Evaluamos Consistencia de Canal de la DUA contra lo registrado en la
    // tabla de Riesgos, este metodo tmb nos devuelve el aforo y motivo de aforo
    // en riesgo
    ResponseSeleccion SeleccionActualenRiesgo = evaluarConsistenciaCanalDuaRiesgo(declara);
    if (!(SunatStringUtils.isStringInList(SeleccionActualenRiesgo.getCodigoError(), "0,1")))
    {
      // Envio de alerta si canal o motivo de aforo de la cabecera de riesgo es
      // distinto al registrado en la cabecera de la DUA
      this.grabarAvisoDeCanalDistintoDua(declaracion, seleccionActual, SeleccionActualenRiesgo);
      // Adicionalmente si se presenta el caso 21, 22 no se reevalua el canal de
      // la dua, (ind_dua inconsistente)
      if (SunatStringUtils.isStringInList(SeleccionActualenRiesgo.getCodigoError(), "21,22"))
      {
        return mapResult;
      }
    }
    /************************** VERIFICAR QUE NO TIENE CANAL ******************************************/
    // Si el codigo es 0 significa que no hay datos de canal ni en cab_declara
    // ni en riesgo, o sea no tiene canal
    // en ese caso no se reasigna canal
    if (SeleccionActualenRiesgo.getCodigoError().equals("0"))
    {
      return mapResult;
    }

    /************************** VERIFICAR QUE LA DUA NO TENGA LEVANTE *********************************/
    // Si la fecha de levante es diferente del default no reasigna canal
    if (!SunatDateUtils.sonIguales(
        dua.getFecAutlevante(),
          SunatDateUtils.getDefaultDate(),
          SunatDateUtils.COMPARA_SOLO_FECHA))
    {
      return mapResult;
    }

    /******************************* REVALUACION DE CANAL *************/
		SeleccionService seleccionCanalService = fabricaDeServicios.getService("seleccion.SeleccionService");
 
		ResponseSeleccion respuestaRevaluacionRiesgo = null;

		// PAS20155E220200179 - mtorralba 20151127 - Inicio
		// Se est� a�adiendo try / catch, para que no interrumpa la diligencia
		// independientemente de la Revaluaci�n de Riesgo 
		try { 
			// PAS20181U220200016
			String codMomento = Constants.MOMENTO_PARAM_WS_REVALUACION_RIESGO;
			if (SunatStringUtils.isStringInList(declara.get("COD_REGIMEN").toString(), "10")) {
				
				String codigoRiesgoOEAARM = "00";
				String codigoRiesgoOEA = declara.get("COD_RIESGOOEA") != null ? declara.get("COD_RIESGOOEA").toString()
						: codigoRiesgoOEAARM;

				CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				DataCatalogo catVigenciaValidacion = catalogoAyudaService
						.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN, "0040");

				Date fechaControlVersionInicio = catVigenciaValidacion.getFecInidatcat();
				Date fechaControlVersionFin = catVigenciaValidacion.getFecFindatcat();
				Date fechaHoy = SunatDateUtils.getCurrentDate();
				if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaControlVersionInicio, fechaHoy,
						SunatDateUtils.COMPARA_SOLO_FECHA)
						&& (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaControlVersionFin,
								SunatDateUtils.addDay(fechaHoy, -1), SunatDateUtils.COMPARA_SOLO_FECHA))) {

					if (!SunatStringUtils.isEmptyTrim(codigoRiesgoOEA)) {
						/*if (!SunatStringUtils.isStringInList(codigoRiesgoOEA, "11,10,01")) {
							respuestaRevaluacionRiesgo = seleccionCanalService.asignar(
									declaracion.getDua().getCodaduanaorden(),
									declaracion.getDua().getCodregimen(),
									Constants.MOMENTO_PARAM_WS_REVALUACION_RIESGO,
									Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
									declaracion.getDua().getAnnpresen().toString(),
									declaracion.getNumeroDeclaracion().toString());
						}*/
					

				
						if (SunatStringUtils.isStringInList(codigoRiesgoOEA, "11,10,01")) {
							codMomento = "1022"; //revisar si es cambio del 13
							/*respuestaRevaluacionRiesgo = seleccionCanalService.asignar(
									declaracion.getDua().getCodaduanaorden(),
									declaracion.getDua().getCodregimen(),
									"1022",
									Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
									declaracion.getDua().getAnnpresen().toString(),
									declaracion.getNumeroDeclaracion().toString());*/
						}

					}
				}
				/*else {

					respuestaRevaluacionRiesgo = seleccionCanalService.asignar(
							declaracion.getDua().getCodaduanaorden(),
							declaracion.getDua().getCodregimen(),
							MOMENTO_PARAM_WS_REVALUACION_RIESGO,
							Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
							declaracion.getDua().getAnnpresen().toString(),
							declaracion.getNumeroDeclaracion().toString());
				}*/
			}/*else {

				respuestaRevaluacionRiesgo = seleccionCanalService.asignar(
						declaracion.getDua().getCodaduanaorden(),
						declaracion.getDua().getCodregimen(),
						MOMENTO_PARAM_WS_REVALUACION_RIESGO,
						Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
						declaracion.getDua().getAnnpresen().toString(),
						declaracion.getNumeroDeclaracion().toString());
			}*/
//pase13
			ControlVigenciaService controlVigencia = fabricaDeServicios.getService("despaduanero2.declaracion.controlVigenciaService");
			boolean esReglaApiRiesgoVigente = controlVigencia.esReglaVigente(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
					COD_VIGENCIA_INVOCACION_API_RIESGO, SunatDateUtils.getCurrentDate());

			if(esReglaApiRiesgoVigente) {

				String asignarPath = "/t/asignar?aduana=%s&regimen=%s&momento=%s&codunidsel=%s&annio=%s&numunisel=%s";
				String asignarCanalUri = BASE_API_RIESGO_PATH + String.format(asignarPath,
						declaracion.getDua().getCodaduanaorden(),
						declaracion.getDua().getCodregimen(),
						codMomento,
						Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
						declaracion.getDua().getAnnpresen().toString(),
						declaracion.getNumeroDeclaracion().toString());
				RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
				CanalResponse canalResponse = restTemplate.getForObject(asignarCanalUri, CanalResponse.class);
				respuestaRevaluacionRiesgo = new ResponseSeleccion();
				respuestaRevaluacionRiesgo.setCodigoError(canalResponse.getCanal().getCodigoError());
				respuestaRevaluacionRiesgo.setAforo(canalResponse.getCanal().getAforo());
				respuestaRevaluacionRiesgo.setMotaforo(canalResponse.getCanal().getMotaforo());

			} else {
				respuestaRevaluacionRiesgo = seleccionCanalService.asignar(
						declaracion.getDua().getCodaduanaorden(),
						declaracion.getDua().getCodregimen(),
						codMomento,
						Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL,
						declaracion.getDua().getAnnpresen().toString(),
						declaracion.getNumeroDeclaracion().toString());
			}

		} catch (Exception e) {
			try {
				String nrodam = declara.get("COD_ADUANA").toString() + "-" + declara.get("ANN_PRESEN").toString() + "-"
						+ declara.get("COD_REGIMEN").toString() + "-" + declara.get("NUM_DECLARACION").toString();
				enviarMsgErrRevaluacionRiesgo(nrodam, e.getMessage());
			} catch (Exception ex) {
				log.error("enviarMsgErrRevaluacionRiesgo:" + ex.getMessage());
			}

			return mapResult;
		}
    
    if (respuestaRevaluacionRiesgo == null || "-1".equals(respuestaRevaluacionRiesgo.getCodigoError()))
    {
      return mapResult;
    }

    /**************************** END Datos para los Servicios ****************************************/

    boolean cambioCanal = !respuestaRevaluacionRiesgo.getAforo().equals(seleccionActual.getAforo());
    boolean cambioMotivo = !respuestaRevaluacionRiesgo.getMotaforo().equals(seleccionActual.getMotaforo());
    boolean CanalNuevoEsMayor = Aforo1esMenorQueAforo2(seleccionActual.getAforo(),respuestaRevaluacionRiesgo.getAforo());

    /**************************************************************************************************/
    // Motivo "77" o Motivo "98" significa que el canal revaluado fue menor que
    // el canal actual en la cabecera de la dua
    // pero en la tabla cab_tipafo_declara se registro el mismo canal actual por
    // tanto solo podemos saberlo por el motivo
    if ("77".equals(respuestaRevaluacionRiesgo.getMotaforo()) || "98".equals(respuestaRevaluacionRiesgo.getMotaforo()))
    {

      // //Actualiza el motivo de asignaci�n de canal para que coincida con la
      // tabla cabecera de riesgos
      Map<String, Object> datosDUA = new HashMap<String, Object>();
      datosDUA.clear();
      datosDUA.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo().toString());
      // Envio de alerta indicando que la revaluacion de riesgo dio como
      // resultado un canal de menor
      // peso que el registrado en la declaracion, para lo cual necesitamos el
      // canal Revaluado que resulto menor
      ResponseSeleccion canalMenor = obtenerCanalRevaluadoMenor(datosDUA);
      // Enviar Aviso
      if (canalMenor != null)
      {

        grabarAvisoDeCanalDeRiesgoMenor(
            declaracion,
              seleccionActual,
              SeleccionActualenRiesgo,
              respuestaRevaluacionRiesgo,
              canalMenor);
      }
    }
    /**************************************** Registra Cambio de Canal y/o Motivo ************************************/
    // Para los casos que el canal de revaluacion es igual o mayor al canal de
    // la DUA
    if (cambioCanal || cambioMotivo)
    {
      // Se instancia el servicio correspondiente a CAB_DECLARA
      RectificacionAbstract rectifi = fabricaDeServicios.getService("diligencia.rectificacion.codtabla.T0051");

      // Genera el Mapa con los datos iniciales de la declaracion
      HashMap<String, Object> mapaDataOriginal = new HashMap<String, Object>();
      // Genera el Mapa con los datos a actualizar en la declaracion
      HashMap<String, Object> mapaDataActualizada = new HashMap<String, Object>();

      mapaDataOriginal.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo().toString());
      mapaDataActualizada.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo().toString());

      if (cambioCanal && CanalNuevoEsMayor)
      {
        mapaDataOriginal.put("COD_CANAL", seleccionActual.getAforo());
        mapaDataActualizada.put("COD_CANAL", respuestaRevaluacionRiesgo.getAforo());
      }
      if (cambioMotivo)
      {
        mapaDataOriginal.put("COD_MOTIVOCANALASIG", seleccionActual.getMotaforo());
        mapaDataActualizada.put("COD_MOTIVOCANALASIG", respuestaRevaluacionRiesgo.getMotaforo());
      }

      // Genera el Mapa a pasar como par�metro para la rectificaci�n
      HashMap<String, Object> mapDatos = new HashMap<String, Object>();
      mapDatos.put("mapCabDeclara", mapaDataOriginal);
      mapDatos.put("mapCabDeclaraActual", mapaDataActualizada);

      // Graba los datos rectificados en CAB_DECLARA y DET_OFIRECTI
      int count = rectifi.grabarRectificacion(numCorredocSol, mapDatos);

      //RTINEO PAS20145E220000587 actualizamos en la tabla riesgo el momento en que se actualiza el canal en la declaracion
      Long num_corredoc = Long.parseLong(declaracion.getNumeroCorrelativo().toString());
//pase 13
		ControlVigenciaService controlVigencia = fabricaDeServicios.getService("despaduanero2.declaracion.controlVigenciaService");
		boolean esReglaApiRiesgoVigente = controlVigencia.esReglaVigente(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				COD_VIGENCIA_INVOCACION_API_RIESGO, SunatDateUtils.getCurrentDate());

		if(esReglaApiRiesgoVigente) {
			RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
			String actualizaFechaAforoUri = BASE_API_RIESGO_PATH +
					"/e/grabarFechaActualizacionCanalAforo?numCorrelativo=" + num_corredoc;

			FechaCanal fechaCanal = restTemplate.getForObject(actualizaFechaAforoUri, FechaCanal.class);
			if (fechaCanal.getValor() >= 1) {
				if (log.isDebugEnabled()) {
					log.debug(TAG_API_RIESGO + " EXITO ACTUALIZAR FECHA EN TABLA DE RIESGO: " + fechaCanal.getValor() + " REGISTRO(S) ACTUALIZADOS");
				}
			}
		} else {
			int rF = seleccionCanalService.grabarFechaActualizacionCanalAforo(num_corredoc, 0);
			if (rF >= 1) {
				if (log.isDebugEnabled())
					log.debug("EXITO ACTUALIZAR FECHA EN TABLA DE RIESGO: " + rF + " REGISTRO(S) ACTUALIZADOS");
			}
		}

      //RTINEO PAS20145E220000587 FIN
      
      // Si hay cambio de canal o de motivo de aforo, se debe insertar el
      // indicador correspondiente en INDICADOR_DUA
      // Se instancia el servicio correspondiente a CAB_DECLARA
      // rectifi =
      // fabricaDeServicios.getService("diligencia.rectificacion.codtabla.T0060");
      mapDatos.clear();
      mapDatos.put("numCorredoc", declaracion.getNumeroCorrelativo().toString());
      // 12 - Para cambio de canal 13 - para cambio de motivo
      mapDatos.put("codIndicador", (cambioCanal ? "12" : "13"));
      mapDatos.put("codTiporegistro", "R");
      try
      {
        indicadorDUADAO.insertMapSelective(mapDatos);
      }
      catch (Exception e)
      {
        indicadorDUADAO.update(mapDatos);
      }

      /**
       * Verifica Si existio Cambio de Canal a Canal Mayor para notificar al
       * despachador
       **/
      if (cambioCanal && CanalNuevoEsMayor)
      {// Debe notificar al despachador el cambio de canal
        // Obtenemos el despachador
        ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
        Map paramsMap = new HashMap();
        paramsMap.put("numeroCorrelativo", declaracion.getNumeroCorrelativo().toString());
        paramsMap.put("codTipoParticipante", "41");
        Participante despachador = null;
        try
        {
          List<Participante> listParticipante = participanteService.obtenerParticipanteByParameterMap(paramsMap);
          despachador = listParticipante.get(0);
        }
        catch (Exception e)
        {
          // Seguimos
        }
        declaracion.getDua().setNumdocumento(despachador.getNumeroDocumentoIdentidad());
        declaracion.getDua().setCodCanal(respuestaRevaluacionRiesgo.getAforo());
        declaracion.getDua().setCodMotivoCanalAsig(respuestaRevaluacionRiesgo.getMotaforo());
        // Notificamos al Despachador
        grabarNotificacionCambioCanalAlDespachador(declaracion);

        // Adicionalmente si era canal Naranja (ahora cambio a mayor deberia ser
        // rojo) eliminamos
        if (seleccionActual.getAforo().equals("D") && respuestaRevaluacionRiesgo.getAforo().equals("F"))
        {

        	/* P14 - 3007 - Inicio - dhernandezv */
        	if(declaracion.getFechaRecepcion()!= null) {
        		mapResult.put("actualizarEstado", true);
        	} else {
        		mapResult.put("actualizarEstado", false);
        	}
        	/* P14 - 3007 - Fin - dhernandezv */
        	
        
          BandejaDocuDAO bandejaDocuDAO = fabricaDeServicios.getService("asignacion.bandejaDocuDAO");

          BandejaDocu bandejaDocu = new BandejaDocu();
          // bandejaDocu.setCabDeclara(cabDeclara);
          bandejaDocu.setNumCorredoc(declaracion.getNumeroCorrelativo());
          bandejaDocu.setCodFuncionario(" ");
          bandejaDocuDAO.modificarBandejaDocu(bandejaDocu);
        }

      }
      // }
    }
    mapResult.put("COD_CANAL_REE", respuestaRevaluacionRiesgo.getAforo());
    mapResult.put("COD_CANAL_REE_DESC", catalogoAyudaService.getDescripcionDataCatalogo("AR", respuestaRevaluacionRiesgo.getAforo()));
    return mapResult;
  }


  	private void enviarMsgErrRevaluacionRiesgo(String nrodam, String mensajeError ) {
		
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		   
		// Notificacion al RUC de la Sunat
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		mapMensaje.put("tip_usuario", "1");
		mapMensaje.put("cod_usuario", new String[] {"20131312955"});
		mapMensaje.put("des_asunto", "Error durante Revaluaci&oacute;n del Riesgo en la Diligencia de Rectificaci&oacute;n");
		mapMensaje.put("fecha_emision", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy HH:mm:ss"));
		mapMensaje.put("nro_dam", nrodam);
		mapMensaje.put("mensajeError", mensajeError);
		
		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(280, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
	}
  
  
  /**
   * Devuelve true si el el CANAL aforo1 es de menor grado de riesgo que el
   * CANAL aforo2 Si son iguales o es de mayor grado devuelve false.
   *
   * @param aforo1
   *          the aforo1
   * @param aforo2
   *          the aforo2
   * @return true, if successful
   */
  private boolean Aforo1esMenorQueAforo2(String aforo1, String aforo2)
  {

    if (aforo1.equals(AFORO_VERDE) && (aforo2.equals(AFORO_NARANJA) || aforo2.equals(AFORO_ROJO)))
    {
      return true;
    }
    else if (aforo1.equals(AFORO_NARANJA) && (aforo2.equals(AFORO_ROJO)))
    {
      return true;
    }
    else if (aforo1.trim().isEmpty() && !aforo2.trim().isEmpty())
    {
      return true;
    }
    return false;
  }



  /**
   * {@inheritDoc}
   */
  public void grabarSolicitudRectificacionImprocedente(Map params)
  {

    String[] expedientes = params.get("NUM_EXPEDIENTES") == null ? new String[]
    {} : (String[]) params.get("NUM_EXPEDIENTES");
    params.put("fortipoopedif", "E");
    params.put("COD_TIPOPER", "R");
    cabSolrectiDAO.update(params);
    
    //ggranados pase 39 improcedente	
    Solicitud solicitud = new Solicitud();
    solicitud.setNumeroCorrelativo(SunatNumberUtils.toLong(params.get("NUM_CORREDOC")));
    solicitud.setFechaAtencion(new Date());
    SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
    solicitudDAO.updateByPrimaryKeySelective(solicitud);

    Map<String, Object> mapDiligencia = new HashMap<String, Object>();
    mapDiligencia.put("NUM_CORREDOC", params.get("NUM_CORREDOC_DUA"));
    mapDiligencia.put("NUM_CORREDOC_SOL", params.get("NUM_CORREDOC"));
    mapDiligencia.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_RECTIFICACION);
    mapDiligencia.put("IND_INCIDENCIA", "N");
    mapDiligencia.put("IND_MULTA", "N");
    mapDiligencia.put("DES_RESULTADO", params.get("DES_RESULEVAL"));
    mapDiligencia.put("COD_FUNCIONARIO", params.get("COD_FUNCIONARIO"));
    mapDiligencia.put("FEC_DILIGENCIA", params.get("FEC_EVALUACION"));


    try
    {
      this.cabDiligenciaDAO.insert(mapDiligencia);
    }
    catch (Exception e)
    {
      this.cabDiligenciaDAO.update(mapDiligencia);
    }
    
    
    
    //lmvr - Inicio: Complemento de la Diligencia
    Boolean actualizaFechaRegularizacion =(Boolean)params.get("actualizaFechaRegularizacion");
    //CabdeclaraDAO cabdeclaraDAO = fabricaDeServicios.getService("manifiesto.manifiestoService");
    if (actualizaFechaRegularizacion) {
	     //String fechaRegularizacionProrroga =(String)mapParametros.get("fechaRegularizacionProrroga");
	      Date fechaRegularizacionProrr= (Date) params.get("fechaRegularizacionProrroga");
	      
	      Map paramsDua = new HashMap();
	      paramsDua.put("FEC_VENCREGULA", fechaRegularizacionProrr);
	      
	     // Map<String, Object> datos = (Map<String, Object>) mapDatos.get("mapCabDeclaraActual");
	    /*  String numeroCorrelativoAsString = (String) params.get("NUM_CORREDOC_DUA");
	      Long numeroCorrelativo = new Long(numeroCorrelativoAsString);*/
	      params.put("NUM_CORREDOC", params.get("NUM_CORREDOC_DUA"));
	     // paramsDua.put("NUM_CORREDOC", numeroCorrelativo);
	      cabDeclaraDAO.update(paramsDua);
    }
  //lmvr - Fin: Complemento de la Diligencia
    
    
    List<Map<String, Object>> rows = docAutAsociadoDAO.select(params);
    Integer numSecdoc = 1;
    if (rows.size() > 0)
    {
      Collections.sort(rows, new Comparator<Map<String, Object>>()
      {
        @Override
        public int compare(Map<String, Object> thiss, Map<String, Object> that)
        {

          Integer nthiss = new Integer(thiss.get("NUM_SECDOC").toString());
          Integer nthat = new Integer(that.get("NUM_SECDOC").toString());
          return nthiss.compareTo(nthat);
        }
      });
      numSecdoc = rows.size() + 1;
    }
    for (String expediente : expedientes)
    {
      String[] splitexpedientes = expediente.split("-");
      params.put("NUM_SECDOC", numSecdoc);
      params.put("COD_TIPDOCASO", "14");
      params.put("COD_ADU_AUT", splitexpedientes[0]);
      params.put("ANN_DOC", splitexpedientes[1]);
      params.put("NUM_DOC", splitexpedientes[2]);
      docAutAsociadoDAO.insertSelective(params);
      numSecdoc++;
    }

	  /*INICIO-RIN10 FSW AFMA*/
	  String codAduana =  params.get("COD_ADUANA")!=null?params.get("COD_ADUANA").toString():"";
	  String codRegimen =  params.get("COD_REGIMEN")!=null?params.get("COD_REGIMEN").toString():"";
	  Integer ano  =  params.get("ANN_PRESEN")!=null? new Integer(params.get("ANN_PRESEN").toString()):0;
	  Integer numDeclaracion =  params.get("NUM_DECLARACION")!=null?new Integer(params.get("NUM_DECLARACION").toString()):0;
	  Long numCorreDocSol = params.get("NUM_CORREDOC")!=null?new Long(params.get("NUM_CORREDOC").toString()):0;
	  valorProvisionalService.improcedenteSolicitudElectronicaConValorProvisional(codAduana,codRegimen,ano,numDeclaracion,numCorreDocSol);

	  /*FIN-P34 RIN10 AFMA*/
  
	  //ini P28-PAS20155E410000032 - bug 24010
	  ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
	  controlarSaldoReposicionService.actualizarRelacionTemporalSerieItemCrmf(SunatNumberUtils.toLong(params.get("NUM_CORREDOC_DUA")), "1");
	  //fin P28-PAS20155E410000032 - bug 24010

	//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA, solo cuando elimina o es nuevo pero el nuevo ya no va.
         //RMC RIN-P47
	  Map<String, Object> prmCont = new HashMap<String, Object>();
	  prmCont.put("NUM_CORREDOC_SOL", params.get("NUM_CORREDOC"));
	  //prmCont.put("declaracion", params.get("declaracion"));
	  prmCont.put("COD_ADUANA", codAduana);
	  prmCont.put("COD_USUMODIF", params.get("COD_FUNCIONARIO"));
      Map<String, Object> mapCabDeclaraActual =
              (Map<String, Object>) params.get("mapCabDeclaraActual");
      prmCont.put("declaracion", mapCabDeclaraActual);
      prmCont.put("improcedente", "T");
      prmCont.put("NUM_DECLARACION", SunatStringUtils.lpad(mapCabDeclaraActual.get("NUM_DECLARACION").toString().trim(),6,'0'));
      prmCont.put("ANN_PRESEN", mapCabDeclaraActual.get("ANN_PRESEN"));
      prmCont.put("COD_REGIMEN", mapCabDeclaraActual.get("COD_REGIMEN"));
	  procesarContingente(prmCont);
      //this.procesarContProcdente(prmCont);
  }

  /**
   * {@inheritDoc}
   */
  public String obtenerRectificacionesDeJSONStrings(String strJSONRecti, String strJSONRectiAll)
  {
    JsonSerializer serializer = new JsonSerializer();
    List<Map<String, Object>> listRectis = (List<Map<String, Object>>) serializer.deserialize(strJSONRecti);
    List<Map<String, Object>> listRectiAlls = (List<Map<String, Object>>) serializer.deserialize(strJSONRectiAll);
    List<Map<String, Object>> lstDatosRectificados = new ArrayList<Map<String, Object>>();
    boolean encontrado = false; //pase42 gmontoya
    for (Map<String, Object> itemCompare : listRectiAlls)
    {
      encontrado = false; //pase42 gmontoya
      for (Map<String, Object> itemFind : listRectis)
      {
        if (itemFind.get("tabla").equals(itemCompare.get("COD_TABLA")) &&
            itemFind.get("campo").equals(itemCompare.get("CAMPO")) &&
            itemFind.get("pk").equals(itemCompare.get("PK")) &&
            itemFind.get("num_cambio").equals(itemCompare.get("NUM_SECCAMBIO")))
        {// num_cambio NUM_SECCAMBIO
          lstDatosRectificados.add(itemCompare);
          encontrado = true; //pase42 gmontoya
          break;
        }
      }
      if(!encontrado){
    	  itemCompare.put("IND_RECTIFICA","S");
    	  lstDatosRectificados.add(itemCompare);
      }
	  // fin pase42 gmontoya
    }
    return lstDatosRectificados.isEmpty() ? "[]" : SojoUtil.toJson(lstDatosRectificados);
  }

  /**
   * {@inheritDoc}
   */
  public void modificarSolicitudRectificacion(Map<String, Object> parametros)
  {
    // parametros para actualizar los cab_diligencia
    String[] arrayExpedientesModificados = parametros.get("EXPEDIENTES_MODIFICADOS") == null ? new String[]
    {} : (String[]) parametros.get("EXPEDIENTES_MODIFICADOS");
    List<String> arrayExpedientesVigentes = parametros.get("EXPEDIENTES_VIGENTES") == null ? new ArrayList<String>()
        : (List<String>) parametros.get("EXPEDIENTES_VIGENTES");

    //recuperar observacion de cabdiligencia antes de modificarla
    Map<String, Object> paramCabD = new HashMap<String, Object>();    
    paramCabD.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC").toString());
    paramCabD.put("NUM_CORREDOC_SOL", parametros.get("NUM_CORREDOC_PRE").toString());
    List<Map<String, Object>> listDiligencia = cabDiligenciaDAO.select(paramCabD);
    
        this.cabDiligenciaDAO.update(parametros);
    //INICIO PASE42-VRD
	int secuencia=0; 
    Map<String, Object> paramOBS = new HashMap<String, Object>();    
    paramOBS.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC_PRE").toString());
    paramOBS.put("COD_TIPOBS", "15");         
    secuencia=this.observacionDAO.getMaxNumSecObs(paramOBS);    
    secuencia++;
    //si es primera modificacion recuperar observacion de cabdiligencia para el hitorial (observacion)
    if (secuencia==1)
    {      
    paramOBS.put("NUM_SECOBS",secuencia);
    paramOBS.put("COD_TIPOBS","15");
    paramOBS.put("OBS_OBS",listDiligencia.get(0).get("DES_RESULTADO").toString());
    this.observacionDAO.insert(paramOBS);
    secuencia++;
    }     
    
    paramOBS.put("NUM_SECOBS",secuencia);
    paramOBS.put("COD_TIPOBS","15");
    paramOBS.put("OBS_OBS",parametros.get("DES_RESULTADO").toString());       
    this.observacionDAO.insert(paramOBS);
  //FIN PASE42-VRD
    
    

    Map<String, Object> temp = new HashMap<String, Object>();
    ;
    temp.put("numcorredoc", parametros.get("NUM_CORREDOC_PRE").toString());
    temp.put("indicadorEliminado", new Integer(1));
    temp.put("tipoper", "R");
    temp.put("tipcaso", "14");

    // almacenamos expedientes eliminados previamente (en oro tiempo y proceso)
    List<String> expedientesEliminadosDB = new ArrayList<String>();

    for (DatoOtroDocSoporte datoOtroDocSoporte : this.docAutAsociadoDAO.findDocSoporteByParameterMap(temp))
    {
      String strTemp = datoOtroDocSoporte.getCodigoAduanaAutoriza() + "-" + datoOtroDocSoporte.getAnndocasoc() + "-"
          + datoOtroDocSoporte.getNumdocasoc();
      expedientesEliminadosDB.add(strTemp);
    }

    Collections.sort(expedientesEliminadosDB);

    // insertamos los que no estan como vigentes y no han sido eliminados
    List<String> expedientesInsertar = ListUtils.subtract(
        Arrays.asList(arrayExpedientesModificados),
          expedientesEliminadosDB);
    expedientesInsertar = ListUtils.subtract(expedientesInsertar, arrayExpedientesVigentes);

    // eliminamos los activos menos los que fueron modificados

    List<String> expedientesEliminar = ListUtils.subtract(
        arrayExpedientesVigentes,
          Arrays.asList(arrayExpedientesModificados));

    // activamso los que estan en la interseccion de los modificados y
    // eliminados
    List<String> expedientesActivar = ListUtils.intersection(
        Arrays.asList(arrayExpedientesModificados),
          expedientesEliminadosDB);

    Integer numSecdoc = arrayExpedientesVigentes.size() + 1;
    if (expedientesEliminadosDB.size() > 0)
    {

      numSecdoc = numSecdoc + expedientesEliminadosDB.size() + 1;
    }

    // /agregamos los expedientes faltantes

    for (String expediente : expedientesInsertar)
    {
      temp = new HashMap<String, Object>();
      String[] splitexpedientes = expediente.toString().split("-");
      temp.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC_PRE"));

      temp.put("COD_TIPOPER", "R");
      temp.put("COD_TIPDOCASO", "14");
      temp.put("COD_ADU_AUT", splitexpedientes[0]);
      temp.put("ANN_DOC", splitexpedientes[1]);
      temp.put("NUM_DOC", splitexpedientes[2]);
      temp.put("IND_DEL", new Integer(0));

      temp.put("FEC_REGIS", parametros.get("FEC_MODIF"));
      temp.put("COD_USUREGIS", parametros.get("COD_USUMODIF"));
      temp.put("FEC_MODIF", parametros.get("FEC_MODIF"));
      temp.put("COD_USUMODIF", parametros.get("COD_USUMODIF"));

      temp.put("NUM_SECDOC", numSecdoc);
      docAutAsociadoDAO.insertSelective(temp);
      numSecdoc++;
    }

    // activamos los expedientes que ya estan relacionados a la rectificacion

    for (String expediente : expedientesActivar)
    {
      temp = new HashMap<String, Object>();
      String[] splitexpedientes = expediente.split("-");

      temp.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC_PRE"));
      temp.put("COD_TIPOPER", "R");
      temp.put("COD_TIPDOCASO", "14");
      temp.put("COD_ADU_AUT", splitexpedientes[0]);
      temp.put("ANN_DOC", splitexpedientes[1]);
      temp.put("NUM_DOC", splitexpedientes[2]);

      temp.put("FEC_MODIF", parametros.get("FEC_MODIF"));
      temp.put("COD_USUMODIF", parametros.get("COD_USUMODIF"));
      temp.put("IND_DEL", new Integer(0));

      docAutAsociadoDAO.activar(temp);
      numSecdoc++;
    }

    // desactivamos los expedientes eliminados

    for (String expediente : expedientesEliminar)
    {
      temp = new HashMap<String, Object>();
      String[] splitexpedientes = expediente.split("-");

      temp.put("NUM_CORREDOC", parametros.get("NUM_CORREDOC_PRE"));
      temp.put("COD_TIPOPER", "R");
      temp.put("COD_TIPDOCASO", "14");
      temp.put("COD_ADU_AUT", splitexpedientes[0]);
      temp.put("ANN_DOC", splitexpedientes[1]);
      temp.put("NUM_DOC", splitexpedientes[2]);

      temp.put("FEC_MODIF", parametros.get("FEC_MODIF"));
      temp.put("COD_USUMODIF", parametros.get("COD_USUMODIF"));
      temp.put("IND_DEL", new Integer(1));

      docAutAsociadoDAO.deleteDesactivar(temp);
      numSecdoc++;
    }

  }

  /**
   * Grabar notificacion cambio canal al despachador.
   *
   * @param declaracion
   *          the declaracion
   */
  private void grabarNotificacionCambioCanalAlDespachador(Declaracion declaracion)
  {

    PublicacionAvisoService publicacionAvisoService = fabricaDeServicios
        .getService("servicio.avisos.service.publicacionAvisoService");
//    DdpDAO ddpDAO = fabricaDeServicios.getService("servicio.registro.model.ddpDAO");

    FechaBean fechaActual = new FechaBean();
    FechaBean fechaVigencia = new FechaBean();
    fechaVigencia.setFecha("31/12/9999");
    Map<String, Object> mapMensaje = new HashMap<String, Object>();

    // Notificaci�n al Despachador de Aduana por Aceptaci�n Dua
    mapMensaje.put("tip_usuario", "1");
    mapMensaje.put("cod_usuario", new String[]
    { declaracion.getDua().getNumdocumento() });
    mapMensaje.put(
        "des_asunto",
          "Notificaci&oacute;n de Cambio de Canal de Control como consecuencia de la Rectificaci&oacute;n");
    mapMensaje.put("fecha_emision", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy HH:mm:ss"));
    mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
    mapMensaje.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
    mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen());
    mapMensaje.put("num_declaracion", declaracion.getNumeroDeclaracion().toString());
    if (declaracion.getDua().getCodCanal().equals("F"))
    {
      mapMensaje.put("cod_canal", "ROJO");
    }
    else if (declaracion.getDua().getCodCanal().equals("D"))
    {
      mapMensaje.put("cod_canal", "NARANJA");
    }
    mapMensaje.put("numruc", declaracion.getDua().getNumdocumento());
    Map params = new HashMap();
//    params = ddpDAO.findByPK(declaracion.getDua().getNumdocumento());
    params = ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
    
    if (params != null)
      mapMensaje.put("nombre", params.get("ddp_nombre").toString());
    else
      mapMensaje.put("nombre", " ");

    StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
    publicacionAvisoService.insert(108, data, "1", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
  }

  /**
   * Grabar aviso de canal de riesgo menor.
   *
   * @param declaracion
   *          the declaracion
   * @param seleccionActual
   *          the seleccion actual
   * @param seleccionActualRiesgo
   *          the seleccion actual riesgo
   * @param seleccionRevaluacion
   *          the seleccion revaluacion
   * @param canalMenor
   *          the canal menor
   */
  private void grabarAvisoDeCanalDeRiesgoMenor(
    Declaracion declaracion,
    ResponseSeleccion seleccionActual,
    ResponseSeleccion seleccionActualRiesgo,
    ResponseSeleccion seleccionRevaluacion,
    ResponseSeleccion canalMenor)
  {

    PublicacionAvisoService publicacionAvisoService = fabricaDeServicios
        .getService("servicio.avisos.service.publicacionAvisoService");
    AduanaRol aduanaRol = fabricaDeServicios.getService("tecnologia.menu.intranet.aduanaRolService");
    FechaBean fechaActual = new FechaBean();
    FechaBean fechaVigencia = new FechaBean();
    fechaVigencia.setFecha("31/12/9999");
    // Obtener Usuarios
    List<Map<String, Object>> empleados = aduanaRol.getEmpleados("000", "JEFATURA.DIVISION.ANALISIS.RIESGO");

    List<String> codigos = new ArrayList<String>();
    // Extraemos solo los codigos de personal
    for (Map<String, Object> m : empleados)
    {
      codigos.add((String) m.get("cod_pers"));
    }
    if (!codigos.isEmpty())
    {
      // Notificaci�n al Jefe del DAR
      Map<String, Object> mapMensaje = new HashMap<String, Object>();
      mapMensaje.put("tip_usuario", "3");
      mapMensaje.put("cod_usuario", codigos.toArray(new String[0]));
      mapMensaje
          .put(
              "des_asunto",
                "Alerta: Canal obtenido durante la Revaluaci�n de Riesgo fue menor al canal de cabecera de la DUA y/o cabecera de Riesgo");
      mapMensaje.put("fecha_emision", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy HH:mm:ss"));
      mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
      mapMensaje.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
      mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen());
      mapMensaje.put("num_declaracion", declaracion.getNumeroDeclaracion().toString());

      mapMensaje.put("cod_canalactual", seleccionActual.getAforo());
      mapMensaje.put("cod_motivoactual", seleccionActual.getMotaforo());

      mapMensaje.put("cod_canalactualriesgo", seleccionActualRiesgo.getAforo());
      mapMensaje.put("cod_motivoactualriesgo", seleccionActualRiesgo.getMotaforo());

      mapMensaje.put("cod_canalmenor", canalMenor.getAforo());
      mapMensaje.put("cod_motivomenor", canalMenor.getMotaforo());

      mapMensaje.put("cod_canalrevaluacion", seleccionRevaluacion.getAforo());
      mapMensaje.put("cod_motivorevaluacion", seleccionRevaluacion.getMotaforo());

      StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
      publicacionAvisoService.insert(110, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
    }
  }

  /**
   * Grabar aviso de canal distinto dua.
   *
   * @param declaracion
   *          the declaracion
   * @param seleccionActual
   *          the seleccion actual
   * @param seleccionRiesgo
   *          the seleccion riesgo
   */
  private void grabarAvisoDeCanalDistintoDua(
    Declaracion declaracion,
    ResponseSeleccion seleccionActual,
    ResponseSeleccion seleccionRiesgo)
  {

    PublicacionAvisoService publicacionAvisoService = fabricaDeServicios
        .getService("servicio.avisos.service.publicacionAvisoService");
    AduanaRol aduanaRol = fabricaDeServicios.getService("tecnologia.menu.intranet.aduanaRolService");
    FechaBean fechaActual = new FechaBean();
    FechaBean fechaVigencia = new FechaBean();
    fechaVigencia.setFecha("31/12/9999");
    // Obtener Usuarios
    List<Map<String, Object>> empleados = aduanaRol.getEmpleados("000", "JEFATURA.DIVISION.ANALISIS.RIESGO");

    List<String> codigos = new ArrayList<String>();
    // Extraemos solo los codigos de personal
    for (Map<String, Object> m : empleados)
    {
      codigos.add((String) m.get("cod_pers"));
    }
    if (!codigos.isEmpty())
    {
      // Notificaci�n al Jefe del DAR
      Map<String, Object> mapMensaje = new HashMap<String, Object>();
      mapMensaje.put("tip_usuario", "3");
      mapMensaje.put("cod_usuario", codigos.toArray(new String[0]));
      mapMensaje.put("des_asunto", "Alerta Canal de cabecera de DUA diferente a Canal de tabla de riesgos.");
      mapMensaje.put("fecha_emision", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy HH:mm:ss"));
      mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
      mapMensaje.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
      mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen());
      mapMensaje.put("num_declaracion", declaracion.getNumeroDeclaracion().toString());
      mapMensaje.put("cod_canal", seleccionActual.getAforo());
      mapMensaje.put("cod_motivocanalasig", seleccionActual.getMotaforo());
      mapMensaje.put("cod_canalriesgo", seleccionRiesgo.getAforo());
      mapMensaje.put("cod_motivocanalasigriesgo", seleccionRiesgo.getMotaforo());
      mapMensaje.put("mensajeerror", seleccionRiesgo.getMensajeError());

      StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
      publicacionAvisoService.insert(109, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
    }
  }


	/**
	 * Invocado por el orquestador para grabar la rectificacion mediante objetos
	 * @param variablesIngreso
	 * @param declaracion
	 * @return
	 * @throws Exception
	 */
	@ServicioAnnot(tipo="G",codServicio=4021, descServicio="servicio general de grabado de la diligencia Rectificacion")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"variablesIngreso","declaracion"})
	@OrquestaDespaAnnot(codServInstancia=4021,numSecEjec=422,nomClase="pe.gob.sunat.tecnologia.receptor.model.Mensaje")
	public Map<String, Object> grabarDiligenciaRectificacion(Map<String, Object> variablesIngreso, Declaracion declaracion) throws Exception{
		if(UserNameHolder.get()==null)
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);
		Map<String, Object> resultadoError = new HashMap<String, Object>();
		Boolean marcaDesdatadoDatado = variablesIngreso.containsKey("marcaDesdatadoDatado")?(Boolean)variablesIngreso.get("marcaDesdatadoDatado"):false;
		Boolean marcaRealizarDatado = variablesIngreso.containsKey("marcaRealizarDatado")? (Boolean)variablesIngreso.get("marcaRealizarDatado"):false;
		String codTransaccion = declaracion.getCodtipotrans();
		DUA dua = declaracion.getDua();

		if(marcaDesdatadoDatado){
			resultadoError = grabarGeneralService.registrarDatado(declaracion,Constants.COD_DATADO_RECTIFICACION,codTransaccion, variablesIngreso);
		} else if(marcaRealizarDatado){
			resultadoError = grabarGeneralService.registrarDatado(declaracion,Constants.COD_DATADO_RECTIFICACION,codTransaccion, variablesIngreso);
		}
		grabarGeneralService.grabaFechaVencRegularizacion(dua);
    grabarDeclaracionService.afectarCtaCteRegPrecedeDeposito(declaracion, "",  "");
		return resultadoError;
	}


  /**
   * {@inheritDoc}
   */
  public List<SolicitudRectifica> listSolicitudesRectificaByDua(
    BigDecimal numeroCorrelativoDua)
  {
    return cabSolrectiDAO.listSolicitudesRectificaByNumeroCorrelativoDua(numeroCorrelativoDua);
  }


  /**
   * {@inheritDoc}
	 */
	public Diligencia findDiligenciaByPk(
			Diligencia diligencia) {
		return cabDiligenciaDAO.findByPrimaryKey(diligencia);
	}





  /**
   * este metodo esta pendiente el requerimiento inicial se cancelo
   * pero es necesario para la regu en el futuro
   *
   * {@inheritDoc}
   */
	public Map<String, Object> mergeDatosBDAndDatosRegularizados(Map<String, Object> mapParametros) throws ServiceException {

	        Map<String, Object> mapResultado = new HashMap<String, Object>();
	        // Mapa inicial de datos para consultar los valores de BD.
	        Map<String, Object> mapDatosIniciales = new HashMap<String, Object>();
	        mapDatosIniciales.put("NUM_CORREDOC", mapParametros.get("NUM_CORREDOC").toString());
	        mapDatosIniciales.put("ANN_PRESEN", mapParametros.get("ANN_PRESEN").toString());
	        mapDatosIniciales.put("COD_ADUANA", mapParametros.get("COD_ADUANA").toString());
	        mapDatosIniciales.put("COD_REGIMEN", mapParametros.get("COD_REGIMEN").toString());
	        mapDatosIniciales.put("NUM_DECLARACION", mapParametros.get("NUM_DECLARACION").toString());


	        // Datos de la Rectificacion, se obtiene los datos seleccionados de la rectificacion enviada.
	        mapResultado = this.obtenerDatosRectificacion(mapParametros);
	        if (log.isDebugEnabled()) {
	            log.debug("Se obtiene los valores a rectificar ");
	        }
	        // Obtenemos Datos de la BD
	        //TODO: amancilla verificr se comenta metodo fue borrado en el ultimo pase

	        //mapResultado = this.obtenerDatosInicialesAsociados(mapResultado, mapDatosIniciales);
	        // merge de datos
	        if(log.isDebugEnabled()){
	            log.debug("Se obtiene Datos Iniciales");
	        }
	        // Obtenemos Datos de la BD
	        //TODO: amancilla verificr se comenta metodo fue borrado en el ultimo pase

	        //mapResultado = this.mergeDatosBDRectificacion(mapResultado);
	        if(log.isDebugEnabled()){
	            log.debug(SojoUtil.toJson(mapResultado));
	            log.debug("Se obtiene Datos Rectificados");
	        }

	        //Map<String,Object> declaracion = (Map<String,Object>)mapResultado.get("mapCabDeclaraActual");

	        MensajeBean mensajeBean = null;
	        // validamos que los totales  del cabdeclara sean igual a la sumatoria de los valores de la serie
	        mensajeBean = ValidadorRectificacion.validarTotalDeclaracionVsSumasSerie((Map<String, Object>) mapResultado.get("mapCabDeclaraActual"), (ArrayList<Map<String, Object>>) mapResultado.get("lstDetDeclaraActual"));

	        if(mensajeBean==null){
	            try{
	                Map<String, Object> diligencia = new HashMap<String, Object>();
	                Map<String, Object> paramsDatado = new HashMap<String, Object>();
	                /*paramsDatado.put("codigoAduana", declaracion.get("COD_ADUAMANIFIESTO"));
	                paramsDatado.put("anioManifiesto", declaracion.get("ANN_MANIFIESTO"));
	                paramsDatado.put("codregimen", declaracion.get("COD_REGIMEN"));
	                paramsDatado.put("numeroManifiesto", declaracion.get("NUM_MANIFIESTO"));
	                paramsDatado.put("detalleNumeroCorrelativo", declaracion.get("NUM_CORREDOC"));

	                List<Datado> listDatados=datadoDAO.listByParameterMap(paramsDatado);
	                paramsDatado.put("tieneDatado", listDatados.size()>0?"S":null);*/
	                diligencia.put("COD_TIPDILIGENCIA", "07");  //07 regularizacion
	                paramsDatado.put("mapCabDeclaraActual", mapResultado.get("mapCabDeclaraActual"));
	                paramsDatado.put("lstDetDeclaraActual", mapResultado.get("lstDetDeclaraActual"));
	                paramsDatado.put("mapCabDiligenciaActual", diligencia);
	                diligenciaService.validarDatado(paramsDatado);
	                /*if(listDatados.size()>0){
	                    if(log.isDebugEnabled()) log.debug("************************** VALIDANDO EL DATADO ***********************");
	                    diligenciaService.validarDatado(paramsDatado);
	                }*/


	            }catch(Exception ex){
	                log.debug("ERROR AL VALIDAR EL DATADO "+ex.getMessage());
	                mensajeBean = new MensajeBean();
	                mensajeBean.setMensajeerror("Se produjo un error al validar el datado "+ex.getMessage());
	                mensajeBean.setMensajesol("Verifique la inconsistencia en el Datado");
	            }
	            if(mensajeBean!=null) log.debug("VALIDACION CON ERROR "+SojoUtil.toJson(mensajeBean));
	        }



	        if (mensajeBean != null) {
	            mapResultado.put("rBean", mensajeBean);
	            return mapResultado;
	        }
	        return mapResultado;
	    }
//mordonezl pase 040	
	public Map<String, Object> recuperarSolicitudRectificacionAnuladaRechazada(Map<String, Object> solRec, Map<String, Object> paramEspecialista,Map<String, Object> mapDUA){
	     Map<String, Object> mapError = new HashMap<String, Object>();
	     Map<String, Object> mensaje = new HashMap<String, Object>();
	     boolean grabarecuperacion= false;	
		
	    // Buscamos si el especialista esta disponible
		solRec.put("indicador","02");    // 02 = Solicitud de rectificacion 
		AsignacionAutomaticaService asignacionAutomatica = fabricaDeServicios.getService("asignacion.service.asignacionAutomatica");
		paramEspecialista.put("COD_GRUPO", "GAR");
	//		Map<String, Object> respuesta =asignacionAutomatica.buscarEspecialistaDisponible(paramEspecialista);
//		if(respuesta!=null && respuesta.containsKey("codigoError") && respuesta.get("codigoError").toString().trim().length() > 0){
//			mapError = respuesta;
//			return mapError;
//		}
		
		String valAsignacion=asignacionAutomatica.validarExistenciaOtrosProcesosPostSolRectificacion(mapDUA) ;
		if (!"".equals(valAsignacion)) {
			 Map<String, Object> respuestaerror = new HashMap<String, Object>();
			 MensajeBean mensajeError = new MensajeBean();
			mensajeError.setError(true);
			mensajeError.setMensajeerror("Se ha realizado otro proceso posterior a la transmisi�n de la rectificaci�n, no se puede recuperar");
			respuestaerror.put("codigoError", "1000");
			respuestaerror.put("msgBean", mensajeError);
			return respuestaerror;
		}
		
		if(solRec.get("COD_ESTARECTI").equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_RECHAZADO)){			
			
			if(!asignacionAutomatica.esJefeEspecialista(paramEspecialista, mapDUA)){
			   Map<String, Object> respuesta =asignacionAutomatica.buscarEspecialistaDisponible(paramEspecialista);
				if(respuesta!=null && respuesta.containsKey("codigoError") && respuesta.get("codigoError").toString().trim().length() > 0){
					mapError = respuesta;
					return mapError;
				}
				// se le asigna automaticamente al especialista que esta recuperando
				solRec.put("mapDUA",mapDUA);
				asignacionAutomatica.grabarAsignacionDelEspecialista(solRec, respuesta, TipoInvocacion.AUTOMATICA, true);
				// actualizacion del estado de la solicitud de rectificacion
			      Map<String, Object> parametros = new HashMap<String, Object>();
			      parametros.put("COD_ESTARECTI", ConstantesDataCatalogo.COD_EST_RECTIFIC_ASIGNADA_ESPECIALISTA);																																		
				  parametros.put("OBS_EVALUACION", solRec.get("OBS_EVALUACION"));
				  parametros.put("NUM_CORREDOC", solRec.get("NUM_SOLICITUD"));
				  this.cabSolrectiDAO.updateEstado(parametros);
				
				grabarecuperacion=true;
			}else{
				
				//actualizacion del estado de la solicitud de rectificacion
			      Map<String, Object> parametros = new HashMap<String, Object>();
			      parametros.put("COD_ESTARECTI", ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);																																		
				  parametros.put("OBS_EVALUACION", solRec.get("OBS_EVALUACION"));
				  parametros.put("NUM_CORREDOC", solRec.get("NUM_SOLICITUD"));
				  parametros.put("FEC_SOLICITUD", "SYSDATE");
				  this.cabSolrectiDAO.updateEstado(parametros);
				  grabarecuperacion=true;
			}
		}else{

//			Map<String, Object> respuesta =asignacionAutomatica.buscarEspecialistaDisponible(paramEspecialista);
//			if(respuesta!=null && respuesta.containsKey("codigoError") && respuesta.get("codigoError").toString().trim().length() > 0){
//				mapError = respuesta;
//				return mapError;
//			}	
			
			if(solRec.get("COD_ESTARECTI").equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_ANULADA)){
/*				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("NUM_SOLICITUD",solRec.get("NUM_SOLICITUD"));
				parametros.put("NUM_CORREDOC",mapDUA.get("NUM_CORREDOC"));
				parametros.put("indicador","02");
				parametros = asignacionAutomatica.asignarEspecialista(parametros, TipoInvocacion.AUTOMATICA);
				if (parametros != null && parametros.containsKey("codigoError")
						&& parametros.get("codigoError").toString().trim().length() > 0) {
					mapError = parametros;
					return mapError;
				}else{
				  grabarecuperacion=true;
				}*/
				//actualizacion del estado de la solicitud de rectificacion
                               //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
				mapDUA.put("NUM_SOLICITUD", solRec.get("NUM_SOLICITUD"));
				 if ( validaRecuperaContingente(mapDUA) ) {
					 Map<String, Object> respuestaerror = new HashMap<String, Object>();
					 MensajeBean mensajeError = new MensajeBean();
					mensajeError.setError(true);
					mensajeError.setMensajeerror("Solicitud no puede ser recuperada, porque tiene contingentes arancelarios envie su solicitud de rectificacion");
					respuestaerror.put("codigoError", "35766");
					respuestaerror.put("msgBean", mensajeError);
					return respuestaerror;
				 }
				 
			      Map<String, Object> parametros = new HashMap<String, Object>();
			      parametros.put("COD_ESTARECTI", ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);																																		
				  parametros.put("OBS_EVALUACION", solRec.get("OBS_EVALUACION"));
				  parametros.put("NUM_CORREDOC", solRec.get("NUM_SOLICITUD"));
				  parametros.put("FEC_SOLICITUD", "SYSDATE");
				  this.cabSolrectiDAO.updateEstado(parametros);
				  grabarecuperacion=true;
			}	
		}
		
		//ggranados pase 39 recuperar
	    Solicitud solicitud = new Solicitud();
	    solicitud.setNumeroCorrelativo(SunatNumberUtils.toLong(solRec.get("NUM_SOLICITUD")));
	    solicitud.setFechaAtencion(SunatDateUtils.getDefaultDate());
	    SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
	    solicitudDAO.updateByPrimaryKeySelective(solicitud);
		
		
	if(grabarecuperacion){	
		//ini P28-PAS20155E410000032 - bug 24010
		ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
		controlarSaldoReposicionService.actualizarRelacionTemporalSerieItemCrmf(SunatNumberUtils.toLong(mapDUA.get("NUM_CORREDOC")), " ");
		//fin P28-PAS20155E410000032 - bug 24010
	MensajeBean mensajeBean = null;			
	mensajeBean = new MensajeBean();
	mensajeBean.setError(false);
	mensajeBean.setMensajesol("Se ha grabado la Recuperaci�n de la Solicitud con Exito");
	mensajeBean.setMensajeerror("");
	mensaje.put("msgBean", mensajeBean);
	//asignar la solicitud automaticamente al especialista que recupero
	}
	   return mensaje;
	}




  /***********************SET DE SPRING **********************************/



  public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
  {
    this.docAutAsociadoDAO = docAutAsociadoDAO;
  }


  public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO)
  {
    this.cabSolrectiDAO = cabSolrectiDAO;
  }


  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }


  public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService)
  {
    this.operadorAyudaService = operadorAyudaService;
  }


  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }


  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }


  public void setMultaService(MultaService multaService)
  {
    this.multaService = multaService;
  }


  public void setIncidenciaService(IncidenciaService incidenciaService)
  {
    this.incidenciaService = incidenciaService;
  }


  public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO)
  {
    this.cabDiligenciaDAO = cabDiligenciaDAO;
  }


  public void setDetIncidenciaDAO(DetIncidenciaDAO detIncidenciaDAO)
  {
    this.detIncidenciaDAO = detIncidenciaDAO;
  }


  public void setDiligenciaService(DiligenciaService diligenciaService)
  {
    this.diligenciaService = diligenciaService;
  }


  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }


  public DatadoDAO getDatadoDAO()
  {
    return datadoDAO;
  }


  public void setDatadoDAO(DatadoDAO datadoDAO)
  {
    this.datadoDAO = datadoDAO;
  }

  public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO)
  {
    this.indicadorDUADAO = indicadorDUADAO;
  }


  public DiligenciaService getDiligenciaService()
  {
    return this.diligenciaService;
  }


  public void setTablasRectificacion(List<String> tablasRectificacion)
  {
    this.tablasRectificacion = tablasRectificacion;
  }

	public void setGrabarGeneralService(GrabarGeneralService grabarGeneralService) {
		this.grabarGeneralService = grabarGeneralService;
	}

  public void setGrabarDeclaracionService(GrabarDeclaracionService grabarDeclaracionService) {
	this.grabarDeclaracionService = grabarDeclaracionService;
  }

public DdpDAOService getDdpDAOService() {
	return ddpDAOService;
}

public void setDdpDAOService(DdpDAOService ddpDAOService) {
	this.ddpDAOService = ddpDAOService;
}
/*
@Override
public List<DetalleSolicitudRectifica> listarDatosRectificadosBySolicitud(
		Long numeroCorrelativoSolicitud) {
	// TODO Auto-generated method stub
	DetSolRectiDAO detSolRectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");
	Map paramsMap = new HashMap();
	paramsMap.put("numeroCorrelativo", numeroCorrelativoSolicitud);
	return detSolRectiDAO.listByParameterMap(paramsMap);
}*/

/*@Override
public List<DatoRectificado> listarDatosRectificadosBySolicitud(
		Long numeroCorrelativoSolicitud) {
	
	//List<DatoRectificado> lstDatoRectificado = consultaRectificacionService.consultaDatosRectificados(diligencia);
	// TODO Auto-generated method stub
	DetSolRectiDAO detSolRectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");
	Map paramsMap = new HashMap();
	paramsMap.put("numeroCorrelativo", numeroCorrelativoSolicitud);
	return detSolRectiDAO.listDetallesByParams(paramsMap);
}*/

	
//PASE42-VRD	
public ObservacionDAO getObservacionDAO() {
	return observacionDAO;
}
//PASE42-VRD	
public void setObservacionDAO(ObservacionDAO observacionDAO) {
	this.observacionDAO = observacionDAO;
}


public FnCalculaDiasDAO getFnCalculaDiasDAO() {
	return fnCalculaDiasDAO;
}

public void setFnCalculaDiasDAO(FnCalculaDiasDAO fnCalculaDiasDAO) {
	this.fnCalculaDiasDAO = fnCalculaDiasDAO;
}



	/***** GGRANADOS RIN16PASE3 INI *****/
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}
    //Inicio RIN10
	public void setValorProvisionalService(ValidadorValorProvisionalService valorProvisionalService)
	{
		this.valorProvisionalService = valorProvisionalService;
	}
	//Fin RIN10
	/***** GGRANADOS RIN16PASE3 FIN *****/

	//rtineo mejoras, grabacion en batch
	public DiligenciaBatchService getDiligenciaBatchService() {
		return diligenciaBatchService;
	}

	public void setDiligenciaBatchService(DiligenciaBatchService diligenciaBatchService) {
		this.diligenciaBatchService = diligenciaBatchService;
	}
	//rtineo fin

        //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
	/**
	 * 
	 * @param grabarContingentesService
	 */// RIN16
	public void setGrabarContingentesService(
			GrabarContingentesService grabarContingentesService) {
		this.grabarContingentesService = grabarContingentesService;
	}
	
	public void setValidaContingentesService(
			ValidaContingentesService validaContingentesService) {
		this.validaContingentesService = validaContingentesService;
	}

	private Map<String, Object> procesarCodigoriesgoOEA(Map prmCodriesgoOEA) throws ServiceException{
		
		try {
		Declaracion declaracion =  (Declaracion)prmCodriesgoOEA.get("DECLARACION");
		ValOperadorOeaService valOperadorOeaService = (ValOperadorOeaService)fabricaDeServicios.getService("ValOperadorOeaServiceImpl");
		List<Map<String, String>> listaErrorOea= new ArrayList<Map<String, String>>();
		 listaErrorOea= (List<Map<String, String>>) valOperadorOeaService.validarEnviodeProveedorOeayPaisOea(declaracion);

		  if(listaErrorOea.size()==0) {
			  String codRiesgoOeaArm= declaracion.getDua().getCodRiesgoOea()!=null?declaracion.getDua().getCodRiesgoOea().toString():"00";
	    		
	    	 if( !"00".equals(codRiesgoOeaArm)){
	 			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
	 			Map<String,Object> mapUpdate=new HashMap<String, Object>();
	 			mapUpdate.put("COD_RIESGOOEA",  codRiesgoOeaArm);
	 			mapUpdate.put("NUM_CORREDOC",  prmCodriesgoOEA.get("NUM_CORREDOC").toString());
	 			cabDeclaraDAO.update(mapUpdate);
	 			prmCodriesgoOEA.put("COD_RIESGOOEA", codRiesgoOeaArm);
	 		}else{
	 			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
	 			Map<String,Object> mapUpdate=new HashMap<String, Object>();
	 			mapUpdate.put("COD_RIESGOOEA",  "00");
	 			mapUpdate.put("NUM_CORREDOC",  prmCodriesgoOEA.get("NUM_CORREDOC").toString());
	 			cabDeclaraDAO.update(mapUpdate);
	 			prmCodriesgoOEA.put("COD_RIESGOOEA",  "00");
	 		}
			}
	   } catch (Exception e) {
    	log.error(this.toString() + " ERROR ACTUALIZACION DE CODIGO RIESGO OEA ERROR: " + e);
    	throw new ServiceException(this, e);
      }

		
		return prmCodriesgoOEA;
	}
	

 	
	public void procesarContingente(Map prmContingente) throws ServiceException{
		Map<String, Object> prmSolRecti = new HashMap<String, Object>();
		Map<String, Object> prmSerieModificada = new HashMap<String, Object>();
		JsonSerializer serializer = new JsonSerializer();
	
		try {
		//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
		prmSolRecti.put("NUM_CORREDOC", prmContingente.get("NUM_CORREDOC_SOL"));

		Map<String, Object> mapDeclaracion = (HashMap<String, Object>) prmContingente.get("declaracion");
		
		//Para saber si la data la tenemos como en la base de datos o detsolrecti, true trae de detSOLRECTI y false de BD 
		boolean indImProcedente = prmContingente.get("improcedente").toString().trim().equals("T")? false : true;
	    	prmContingente.put("lstDatosRectificados", new ArrayList<Map<String,Object>>());
	        this.grabarContingentesService.procesarContingenteRectificacionElectronica(prmContingente, new ArrayList<Map<String,Object>>());
 
	   } catch (Exception e) {
    	log.error(this.toString() + " ERROR ANULACION DE RECTIFICACION DE CONTINGENTE  SolicitudRectificacionesService  procesarContingente  - ERROR: " + e);
    	throw new ServiceException(this, e);
      }

		
 
	}
	
	private List<Map<String, String>> validaContingente(Map prmContingente)  {
		Map<String, Object> variablesIngreso = new HashMap<String, Object>();
	//	Map<String, Object> prmSerieModificada = new HashMap<String, Object>();
		//JsonSerializer serializer = new JsonSerializer();
	
		Declaracion decla= (Declaracion) prmContingente.get("declaracionNue");
				
		//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
		
		
		
		variablesIngreso.put("codTransaccion","1003");
		prmContingente.put("declaracionNue", prmContingente.get("declaracion") );
		
		Map<String, Object> mapDeclaracion = (HashMap<String, Object>) prmContingente.get("declaracion");
		
		//Para saber si la data la tenemos como en la base de datos o detsolrecti, true trae de detSOLRECTI y false de BD 
		//boolean indImProcedente = prmContingente.get("improcedente").toString().trim().equals("T")? false : true;
	    	prmContingente.put("lstDatosRectificados", new ArrayList<Map<String,Object>>());
	    	 List<Map<String, String>> listError =  this.validaContingentesService.procesarDiligencia(decla, variablesIngreso, 0);
 
	       // List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
	        return listError;
	}
	
 
	
	/**
	  * Eliminar registros de contingentes
	  *
	  * @param codTabla
	  *          the cod tabla
	  * @param proceso
	  *          the proceso
	  * @param params
	  *          the params
	  * @return the list
	*/
	public boolean validaRecuperaContingente(Map mapDUA) throws ServiceException{
		Map<String, Object> prmSolRecti = new HashMap<String, Object>();
		JsonSerializer serializer = new JsonSerializer();
		boolean rpta = false ;
		prmSolRecti.put("NUM_CORREDOC", mapDUA.get("NUM_SOLICITUD").toString() );
			List<String> tablas = new ArrayList<String>();
		tablas.add("T0060");
		prmSolRecti.put("COD_TABLA_RECT", tablas);
	 
		boolean rptaCont =  validaContingentesService.tieneContingentes(mapDUA);
		 
		
		DetSolRectiDAO detSolRectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");
	    List<Map<String, Object>> lstDatosRectificados = detSolRectiDAO.findDatosRectificadosByMap(prmSolRecti);
	    if (!CollectionUtils.isEmpty(lstDatosRectificados)) {
	    	
			    for (Map<String, Object> mapaItemRectifica : lstDatosRectificados){
			    	Map<String, Object> mapPkDetSolRecti = (Map<String, Object>) serializer.deserialize(mapaItemRectifica.get("DES_CLAVE"));
			    		if ( "16".equals(  mapPkDetSolRecti.get("COD_INDICADOR").toString().trim()) ) {
			    			return true;
			    		}
			    }
	    }
	
		tablas = new ArrayList<String>();
		tablas.add("T0052");
		prmSolRecti.put("COD_TABLA_RECT", tablas);

	detSolRectiDAO = fabricaDeServicios.getService("diligencia.rectificacion.detSolRectiDef");
    lstDatosRectificados = detSolRectiDAO.findDatosRectificadosByMap(prmSolRecti);
    if (!CollectionUtils.isEmpty(lstDatosRectificados)) {
    	
		    for (Map<String, Object> mapaItemRectifica : lstDatosRectificados){
		    	Map<String, Object> mapPkDetSolRecti = (Map<String, Object>) serializer.deserialize(mapaItemRectifica.get("DES_CLAVE"));
		    			
		    			Map<String, Object> mapDetSerieNue = (Map<String, Object>) serializer.deserialize(mapaItemRectifica.get("DES_DATA"));
		    			Map<String, Object> mapDetSerieOld = (Map<String, Object>) serializer.deserialize(mapaItemRectifica.get("DES_ANTDATA"));
		    			
		    			boolean cambioPartida = mapDetSerieNue.get("NUM_PARTNANDI") == null ? false : true;
		    			boolean cambioUniFis = mapDetSerieNue.get("CNT_UNIFIS") == null ? false : true;
		    			boolean cambioPaisOrigen = mapDetSerieNue.get("COD_PAISORIGEN") == null ? false : true;
		    			boolean cambioPesoNeto = mapDetSerieNue.get("CNT_PESO_NETO") == null ? false : true;
		    			boolean cambioTipMargen = mapDetSerieNue.get("COD_TIPMARGEN") == null ? false : true;
		    			
		    			if (cambioTipMargen) {
		    				
		    				if ( "5".equals(mapDetSerieNue.get("COD_TIPMARGEN").toString().trim()) ||
		    						"5".equals(mapDetSerieOld.get("COD_TIPMARGEN").toString().trim()) ) {
		    					return true;
		    				}
		    				
		    			}
		    				
		    				if ( rptaCont && (cambioPartida || cambioUniFis || cambioPaisOrigen  || cambioPesoNeto )) {
		    					return true;
		    				}
		    					
		  }
	}
    	 
    
	    
	 
	    
	    return rpta ;
	    
	}
 
}