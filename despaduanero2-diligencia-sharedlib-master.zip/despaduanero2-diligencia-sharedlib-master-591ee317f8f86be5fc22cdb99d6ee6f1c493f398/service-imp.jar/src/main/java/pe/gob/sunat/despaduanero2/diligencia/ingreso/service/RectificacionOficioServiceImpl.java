package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.interchange.json.JsonSerializer;



import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.CollectionUtils;



import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
// RIN16
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//P34
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValCabdav;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TmpDetOfiRectiDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DatoModificadoBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.*;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
//P34
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;



import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


//P34 3018 JMCV INICIO
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
//P34 3018 JMCV FIN





/**
 * (non-Javadoc)
 *
 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class RectificacionOficioServiceImpl implements RectificacionOficioService {

  //private static final String IND_REGISTRO_GRABADO = "0";

  private static final int MAX_DIAS_VIGENCIA_DATOS_TMP = 10;

  protected final Log					log								= LogFactory.getLog(this.getClass());

  private static final Integer		NUM_MAX_RECTIFICACIONES_X_DIA	= 5;


  @Autowired
  @Qualifier("disposicionMercanciaService")
  private DisposicionMercanciaService disposicionMercanciaService;
		
  @Autowired
  @Qualifier("diligencia.ingreso.declaracionService")
  private DeclaracionService       declaracionService;

  @Autowired
  @Qualifier("Ayuda.catalogoAyudaService")
  private CatalogoAyudaService     catalogoAyudaService;

  @Autowired
  @Qualifier("diligencia.ingreso.diligenciaService")
  private DiligenciaService        diligenciaService;

  @Autowired
  @Qualifier("diligencia.soporteComparadorService")
  private SoporteComparadorService soporteComparadorService;

  @Autowired
  @Qualifier("diligencia.rectificacion.rectificacionService")
  private RectificacionService     rectificacionService;

  @Autowired
  @Qualifier("diligencia.ingreso.solicitudService")
  private SolicitudService         solicitudService;

  @Autowired
  @Qualifier("diligencia.rectificacionOficio.TmpDetOfiRectiDAO")
  private TmpDetOfiRectiDAO        tmpDetOfiRectiDAO;

  @Autowired
  @Qualifier("diligencia.rectificacionOficio.TmpDetOfiRectiDAO_xa")
  private TmpDetOfiRectiDAO        tmpDetOfiRectiDAO_xa;

  @Autowired
  @Qualifier("diligencia.ingreso.espeDocuDef")
  private EspeDocuDAO              espeDocuDAO;

  @Autowired
  @Qualifier("Framework.sequenceDef")
  private SequenceDAO              sequenceDAO;

  @Autowired
  @Qualifier("diligencia.cabSolRectiDef")
  private CabSolrectiDAO           cabSolrectiDAO;

  @Autowired
  @Qualifier("diligencia.ingreso.cabDiligenciaDef_xa")
  private CabDiligenciaDAO         cabDiligenciaDAO_xa;

  @Autowired
  @Qualifier("diligencia.ingreso.cabDiligenciaDef")
  private CabDiligenciaDAO         cabDiligenciaDAO;

  @Autowired
  @Qualifier("diligencia.ingreso.detDeclaraDef")
  private DetDeclaraDAO            detDeclaraDAO;

  @Autowired
  @Qualifier("diligencia.ingreso.indicadorDuaDef")
  private IndicadorDUADAO          indicadorDuaDAO;

  @Autowired
  @Qualifier("diligencia.ingreso.observacionDef")
  private ObservacionDAO          observacionDAO;

  
	// inicio EJHM
	@Autowired
	@Qualifier("framework.fabricaDeServicios")
	private FabricaDeServicios fabricaDeServicios;
	
	//P34 3018 JMCV INICIO  
	  @Autowired
	  @Qualifier("declaracion.DAMOperativaConsultaService")  
	  private DAMOperativaConsultaService declaracionConsultaService;
	  
	//P34 3018 JMCV FIN 


    /*INICIO-P34 FSW AFMA*/
    @Autowired
    @Qualifier("diligencia.ingreso.serieService")
    private SerieService serieService;

    @Autowired
    @Qualifier("declaracionService")
    private GetDeclaracionService getDeclaracionService;

    @Autowired
    @Qualifier("ValCabdav")
    private ValCabdav validadorFormatoB;


    @Autowired
    @Qualifier("manifiesto.manifiestoDAO")
    private CabManifiestoDAO cabManifiestoDAO;

    @Autowired
    @Qualifier("validacion.ingreso.IndicadorDuaService")
    private IndicadorDuaService indicadorDua;

    @Autowired
    @Qualifier("ValCabdav")
    private ValCabdav valCabdav;


   /*FIN-P34 FSW AFMA*/


  /**
   * {@inheritDoc}
   */
  public ObjectResponseUtil validarDeclaParaRectificacionOficio(BusquedaDua busquedaDua) throws ServiceException{

    // validacion 1 - validamos la existencia de la declaracion
    Map<String, Object> mapDeclara = this.validarExisteDua(busquedaDua);
    if (CollectionUtils.isEmpty(mapDeclara)) {
      return new ObjectResponseUtil("La declaraci�n NO esta registrada.");
    }

 /*INICIO-P34 FSW AFMA*/

      String estado = mapDeclara.get("COD_ESTDUA")!=null?mapDeclara.get("COD_ESTDUA").toString():"";
      if ("08".equals(estado)) {
          return new ObjectResponseUtil("La declaraci�n se encuentra legajada.");
      }


	    String numCorreDoc = mapDeclara.get("NUM_CORREDOC").toString();
            busquedaDua.setNumCorreDoc(Long.parseLong(numCorreDoc)); 
        boolean tieneAsignacion = tieneAsignadaDeclaracionOSolicitud(numCorreDoc, busquedaDua.getRegistroUsuarioLogeado());
        if (!tieneAsignacion)
        {
            return new ObjectResponseUtil("Usuario no tiene asignada la Declaraci�n o Solicitud Vinculada a Esta.");
        }
    /*FIN-P34 FSW AFMA*/
	

    // validamos 2 - un numero de ingreso maximo de 5 veces al dia

    boolean rspta2 = diligenciaService.validarMaximoNumeroDiligenciasRegistradas(numCorreDoc,
        COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO, NUM_MAX_RECTIFICACIONES_X_DIA);
    if (!rspta2) {
      return new ObjectResponseUtil("Se ha excedido el l�mite de rectificaciones por d�a.");
    }

    /*** VALIDAMOS LOS ESTADO DE LA DUA CUMPLE PARA PODER RECTIFICAR DE OFICIO ***/

    /* validamos 3 - Una DUA de modalidad Urgente que tenga levante hasta que se
     * haya registrado la diligencia de regularizaci�n.
     */
    busquedaDua.setNumCorreDoc(new Long(numCorreDoc));
    /* se comenta a pedido de normativa
    boolean rspta3 = esRegularizable(busquedaDua,mapDeclara);
    if (rspta3) {
      return new ObjectResponseUtil("No se permite rectificar la DUA hasta que culmine<br/>" +
                                    "con la diligencia de regularizaci&oacute;n.");
    }
    */

       /*
        * validacion: Una DUA de cualquier modalidad que cuente con GED
        * hasta que se haya registrado la diligencia de despacho.
        */
    boolean rspta4 = esDiligenciable(busquedaDua,mapDeclara);
    if (rspta4) {
        /*INICIO-P34 PAS20165E220200126 AFMA*/
      return new ObjectResponseUtil("No se permite rectificar la DUA hasta que culmine con la diligencia  de despacho");
    }


    /*
     * Una DUA que cuente con transmisi�n de rectificaci�n electr�nica pendiente de evaluar
     * hasta el registro de la diligencia de rectificaci�n electr�nica, su rechazo o anulaci�n.
     */
    boolean rspta5 = esRectificable(busquedaDua,mapDeclara);
    if (rspta5) {
        /*INICIO-P34 PAS20165E220200126 AFMA*/
      return new ObjectResponseUtil("No se permite rectificar la DUA hasta que se evaluaci�n" +
                                    "la transmisi�n de rectificaci�n pendiente");
    }

    /*
     * Una DUA que se encuentre asignada a un funcionario aduanero de conclusi�n de despacho,
     * hasta que la DUA se encuentre concluida
     */
    boolean rspta6 = esConcluible(busquedaDua,mapDeclara);
    if (rspta6) {
        /*INICIO-P34 PAS20165E220200126 AFMA*/
      return new ObjectResponseUtil("No se permite rectificar la DUA hasta que culmine" +
                                    "con la diligencia  de Conclusi�n");
    }
        //pruizcr p42. Rectificacion
    String codigoEstado =  MapUtils.getMapValor(mapDeclara, "COD_ESTDUA").toString();
    if(codigoEstado.equals("18")){
      return new ObjectResponseUtil("La mercanc�a de la declaraci�n se encuentra dispuesta totalmente");
    }
    
  //pruizcr p42. abandono legal rectificacion

  	//String codigoEstado =  MapUtils.getMapValor(mapDeclara, "COD_ESTDUA");
    //validarAdvertenciaOficio(busquedaDua);
      // }
    /***** GGRANADOS RIN16PASE3 INI *****/
    /*
     * El sistema valida que la Declaracion con despacho urgente no cuente con 
     * una Solicitud de Regularizaci�n en estado �En Proceso�
     */
    boolean rspta7 = tieneRegularizacionEnProceso(busquedaDua,mapDeclara);
    if (rspta7) {    	
      //return new ObjectResponseUtil(catalogoAyudaService.getError("35255").get("desError"));
        /*INICIO-P34 PAS20165E220200126 AFMA*/
      return new ObjectResponseUtil("No se permite rectificar la declaraci�n hasta que culmine con la diligencia de regularizaci�n");
    }
    /***** GGRANADOS RIN16PASE3 FIN *****/

     /*INICIO-P34 FSW AFMA*/

      String msgValid = vencioPlazoEnvioFormatoBDiferido(busquedaDua,mapDeclara);
      String cod_tratamiento =  mapDeclara.get("COD_TIPTRATMERC").toString(); //INSI PAS20155E410000032
      if (StringUtils.isNotEmpty(msgValid) && !ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION.equalsIgnoreCase(cod_tratamiento)) { //Se adiciono que para donacion no valide lo del formato B - INSI PAS20155E410000032
          /*INICIO-P34 PAS20165E220200126 AFMA*/
          //return new ObjectResponseUtil("Declaraci�n no cuenta con formato B, plazo de transmisi�n del formato B diferido vencido.");
          return new ObjectResponseUtil(msgValid);
      }


     /*FIN-P34 FSW AFMA*/
    //agrega datos necesario para procesar
    return new ObjectResponseUtil("mapDeclara", mapDeclara);

  }

	public String validarAdvertenciaOficio(BusquedaDua busquedaDua) {
		Map<String, Object> mapaRecti = new HashMap<String, Object>();
		mapaRecti.put("NUM_CORREDOC", busquedaDua.getNumCorreDoc().toString());
		String mensajeAdvertencia = " ";
		List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> lstMercDispuestas1 = null;
		lstMercDispuestas1 = disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(mapaRecti);
		int varMerDis = lstMercDispuestas1.size();
		if (!CollectionUtils.isEmpty(lstMercDispuestas1)) {
			lstResultadoMercancia.addAll(lstMercDispuestas1);
			for (int i = 0; i <= varMerDis - 1; i++) {
				String item = (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
				String seriemd = (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
				String docDispo = (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
				String fecDocDispo = (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
				String fecDoc1 = SunatStringUtils.substring(fecDocDispo, 0, 10);
				mensajeAdvertencia = "Item["
						+ item
						+ "] de la Serie ["
						+ seriemd
						+ "] cuenta con disposici�n de mercanc�as autorizada mediante ["
						+ docDispo + "] de fecha [" + fecDoc1 + "]";
			}
		}
		return mensajeAdvertencia;
	}
	
/*INICIO-P34 FSW AFMA*/
    private String vencioPlazoEnvioFormatoBDiferido(BusquedaDua busquedaDua,Map mapDeclara)
    {

        String msg ="";
        boolean debeEnviarMsj = false;
        boolean noTieneFormatoB = !serieService.declaracionTieneFormatoB(busquedaDua.getNumCorreDoc().toString());

        DUA dua = getDeclaracionService.getCabDUA(busquedaDua.getCodAduana(), busquedaDua.getNumDeclaracion().toString(),busquedaDua.getAnnoPresenta().toString(),busquedaDua.getCodRegimen());

        if(noTieneFormatoB &&  esDeclaracionCanalVerdeNoRegularizable(mapDeclara)){


            if(validadorFormatoB.tieneEnvioFormatoBDiferido(dua)){

                if(vencioPlazoEnvioFormatoBDiferido(mapDeclara)){
                    debeEnviarMsj = true;
                }
            }else{
                //no deberia pasar por aqui deberia validarse antes en los otros proceso
                log.info("dua:"+busquedaDua.toString()+" no tiene formatoB y no esta considerado como diferido!!!!!");
                debeEnviarMsj = true;
            }
        }

        if(debeEnviarMsj){
            msg = "Declaraci�n no cuenta con formato B, plazo de transmisi�n del formato B diferido vencido.";
        }


        String numImportador = mapDeclara.get("NUM_DOCIDENT_PIM")!=null?mapDeclara.get("NUM_DOCIDENT_PIM").toString():"";
        String tipoDocumento = mapDeclara.get("COD_TIPDOC_PIM")!=null?mapDeclara.get("COD_TIPDOC_PIM").toString():"";
        if(StringUtils.isNotEmpty(numImportador) && StringUtils.isNotEmpty(tipoDocumento)){

            Declaracion otraDuaConFormatoBDiferido = valCabdav.importadorTieneOtraDuaConFormatoBDiferido(
                    numImportador, tipoDocumento,dua.getFecdeclaracion());


            if (otraDuaConFormatoBDiferido != null) {

                StringBuffer numeroDua = new StringBuffer(otraDuaConFormatoBDiferido.getCodaduana()).append(" - ")
                        .append(otraDuaConFormatoBDiferido.getDua().getAnnpresen()).append(" - ")
                        .append(otraDuaConFormatoBDiferido.getDua().getCodregimen()).append(" - ")
                        .append(otraDuaConFormatoBDiferido.getNumeroDeclaracion().toString());

                msg="No se permite la Rectificacion de Oficio hasta que se cumpla con la Transmision diferida del formato b de la dua "+numeroDua.toString();
            }
        }


        return msg;
    }

    private boolean esDeclaracionCanalVerdeNoRegularizable(Map mapDeclara)
    {

        String codRegimen = mapDeclara.get("COD_REGIMEN").toString();
        String codCanal = mapDeclara.get("COD_CANAL").toString();

        if(Constantes.CANAL_VERDE.equals(codCanal) && Arrays.asList(new String[]{"10","20","21"}).contains(codRegimen)){
            String codModalidad = mapDeclara.get("COD_MODALIDAD").toString();
          if(Constantes.COD_MODALIDAD_EXCEPCIONAL.equals(codModalidad)){
              return true;
          } else if(Constantes.COD_MODALIDAD_ANTICIPADO.equals(codModalidad)){
              //no tiene indicador 02
              if(!indicadorDua.esDuaRegularizable(Utilidades.toLong(mapDeclara.get("NUM_CORREDOC")))){
                  return true;
              }
          }
        }

        return false;
    }


    private boolean vencioPlazoEnvioFormatoBDiferido(Map mapDeclara)
    {

        if(CollectionUtils.isEmpty(mapDeclara) || StringUtils.isEmpty(mapDeclara.get("ANN_MANIFIESTO").toString())
                || StringUtils.isEmpty(mapDeclara.get("NUM_MANIFIESTO").toString())
                || StringUtils.isEmpty(mapDeclara.get("COD_ADUAMANIFIESTO").toString())
                || StringUtils.isEmpty(mapDeclara.get("COD_TIPMANIFIESTO").toString())
                || StringUtils.isEmpty(mapDeclara.get("COD_VIATRANS").toString())){

         return false;
        }


        Map<String, Object> dataManif = new HashMap<String, Object>();

        dataManif.put("numeroManifiesto", SunatStringUtils.lpad(mapDeclara.get("NUM_MANIFIESTO").toString().trim(), 6, ' '));
        dataManif.put("anioManifiesto", SunatStringUtils.length(mapDeclara.get("ANN_MANIFIESTO").toString()) > 3 ? mapDeclara.get("ANN_MANIFIESTO").toString().substring(0, 4) : null);
        dataManif.put("codigoAduana", mapDeclara.get("COD_ADUAMANIFIESTO"));
        dataManif.put("codigoTipoManifiesto", mapDeclara.get("COD_TIPMANIFIESTO"));
        dataManif.put("codigoViaTransporte", mapDeclara.get("COD_VIATRANS"));

//        CabManifiestoDAO cabManifiestoDAO = fabricaDeServicios.getService("manifiesto.manifiestoDAO");
        List<Manifiesto> listManifiesto = cabManifiestoDAO.listByParameterMap(dataManif);

        if(!CollectionUtils.isEmpty(listManifiesto))
        {
            Manifiesto manifiesto = listManifiesto.get(0);
            if (!SunatDateUtils.isDefaultDate(manifiesto.getFechaTerminoDeDescarga()))
            {
                Date fechaVencimiento = SunatDateUtils.addDay(manifiesto.getFechaTerminoDeDescarga(), Constantes.PLAZO_VENCIMIENTO_REGULARIZACION);

                if(SunatDateUtils.esFecha1MayorQueFecha2( new Date(), fechaVencimiento, SunatDateUtils.COMPARA_SOLO_FECHA)){
                    return true;
                }
            }
        }

        return false;
    }
    private boolean tieneAsignadaDeclaracionOSolicitud(String numCorreDoc, String registroUsuarioLogeado)
    {
        return declaracionService.tieneAsignadaDeclaracionOSolicitud(numCorreDoc, registroUsuarioLogeado);
    }
/*FIN-P34 FSW AFMA*/
	/***** GGRANADOS RIN16PASE3 INI *****/
	private boolean tieneRegularizacionEnProceso(BusquedaDua busquedaDua,
			Map<String, Object> mapDeclara) {
		if(MapUtils.getMapValor(mapDeclara, "COD_MODALIDAD").equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)){
			Map<String, Object> paramRecti = new HashMap<String, Object>();
			paramRecti.put("numcorredocpre", mapDeclara.get("NUM_CORREDOC").toString());
			paramRecti.put("codTransaccion", ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE);
			paramRecti.put("estadosrecti",new String[] {ConstantesDataCatalogo.COD_EST_REGULA_EN_PROCESO});
			List<Map<String, Object>> listaRecti = cabSolrectiDAO.listByDocumentoByParameterMap(paramRecti);
			if(!CollectionUtils.isEmpty(listaRecti)){
				return true;
			}
		}
		return false;
	}
	/***** GGRANADOS RIN16PASE3 FIN *****/


  public void actualizarEstadoRectificacionOficio(BusquedaDua busquedaDua)
  {

 /*INICIO-P34 FSW AFMA*/
        declaracionService.insertarIndicadorDua(busquedaDua.getNumCorreDoc().toString(),Constantes.INDICADOR_RECTIFICACION_OFICIO_EN_PROCESO,Constantes.IND_DUA_P_ESP);

        /*
        Map<String, Object> mapPk= new HashMap<String, Object>();
        mapPk.put("NUM_CORREDOC",busquedaDua.getNumCorreDoc());
        mapPk.put("COD_TIPDILIGENCIA",COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);

        String codEstado = "";

        List<Map<String, Object>> listDiligencia = cabDiligenciaDAO.select(mapPk);
        if (!CollectionUtils.isEmpty(listDiligencia)) {
            codEstado = listDiligencia.get(0).get("COD_MOTIVO").toString();

            String numCorreDocSol = listDiligencia.get(0).get("NUM_CORREDOC_SOL").toString();
            if(COD_EN_REVISION.equals(codEstado) &&
                    !SunatStringUtils.isEmpty((numCorreDocSol))){

                busquedaDua.setNumCorreDocSol(new Long(numCorreDocSol));
                //realiza un update
                updateEstadoRectificacionOficio(busquedaDua);
            }else if (COD_EN_PROCESO.equals(codEstado)){
                //no insert
            }
        }else{
            //realiza un insert
            updateEstadoRectificacionOficio(busquedaDua);
        }
        */

        /*FIN-P34 FSW AFMA*/
  }



    /**
     * Actualizar estado rectificacion oficio.
     *
     * @param numCorreDoc the num corre doc
     */
    private void updateEstadoRectificacionOficio(BusquedaDua busquedaDua){

            Map<String, Object> mapaDiligencia = new HashMap<String, Object>();

            mapaDiligencia.put("NUM_CORREDOC",busquedaDua.getNumCorreDoc());
            mapaDiligencia.put("COD_TIPDILIGENCIA",COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);
            mapaDiligencia.put("COD_CATALOGO", CAT_ESTADO_RECTI_OFICIO);
            mapaDiligencia.put("COD_MOTIVO", COD_EN_PROCESO);
            mapaDiligencia.put("COD_MOTIVO", COD_EN_PROCESO);
            mapaDiligencia.put("NUM_CORREDOC_SOL",busquedaDua.getNumCorreDocSol());

            diligenciaService.insertarDiligencia(mapaDiligencia);

    }


    /**
     * {@inheritDoc}
     */
    public Boolean tieneRectificacionOficioPendiente(String numCorreDocDua) throws ServiceException{

        Boolean bRspta= false;

        Map<String, Object> mapPk= new HashMap<String, Object>();
        mapPk.put("NUM_CORREDOC",numCorreDocDua);
        mapPk.put("COD_TIPDILIGENCIA",COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);

        List<Map<String, Object>> listDiligencia = cabDiligenciaDAO.select(mapPk);
        if (!CollectionUtils.isEmpty(listDiligencia)) {
            String[] estadosPendientes = { COD_EN_REVISION,COD_EN_PROCESO};
            for (Map<String, Object> mapDiligencia: listDiligencia) {

                String codCatalogo = mapDiligencia.get("COD_CATALOGO").toString();
                String codMotivo   = mapDiligencia.get("COD_MOTIVO").toString();
                if(CAT_ESTADO_RECTI_OFICIO.equals(codCatalogo)
                        && Arrays.asList(estadosPendientes).contains(codMotivo)){
                    bRspta=true;
                    break;
                }
            }
        }


        return bRspta;
    }


  /**
   * Devuelve true si la DUA es posible
   * entrar al modulo conclusion de despacho
   *
   * @param busquedaDua
   * @param mapDeclara
   * @return
   */
  private boolean esConcluible(BusquedaDua busquedaDua, Map<String, Object> mapDeclara){

    boolean bRspta = false;
    String codEstadoDua = mapDeclara.get("COD_ESTDUA") != null ? mapDeclara.get("COD_ESTDUA").toString() : "";
    if (COD_ESTADO_DUA_EN_PROCESO_CONCLUSION.equals(codEstadoDua))
    {
      // verificar si ya registro la diligencia despacho
      boolean tieneDiliDespacho = diligenciaService.tieneDiligenciaTipo(busquedaDua,
                                                                        COD_TIPO_DILIGENCIA_CONCLUSION);
      // si tiene diligencia entonces ya no es dilgenciable
      // solo existe una diligencia de despacho por DUA segun la normatividad.
      bRspta = !tieneDiliDespacho;
    }

    return bRspta;
  }


  /**
   * Devuelve true si la DUA es posible
   * entrar al modulo rectificacion electronica
   * es decir si tiene rectificacion electronica
   * pendiente
   *
   * @param busquedaDua
   * @param mapDeclara
   * @return
   */
  private boolean esRectificable(BusquedaDua busquedaDua, Map<String, Object> mapDeclara){

    boolean bRspta = false;

    //01- tiene solicitud de rectifiacion pendiente
     Map<String, Object> params= new HashMap<String, Object>();
     List<String> lstTransacciones = new ArrayList<String>();
         List<String> lstEstadosRectificacion = new ArrayList<String>();

     lstTransacciones.add("03");
         lstTransacciones.add("1003");
         lstTransacciones.add("2003");
         lstTransacciones.add("2103");
         lstTransacciones.add("7003");
      // catalogo 374
         params.put("COD_TIPSOL",COD_TIPO_SOLICTUD_RECTIFICACION);
       //cod_catalogo='363'
         lstEstadosRectificacion.add(COD_ESTADO_RECTIFICACION_EN_EVALUACION);
         lstEstadosRectificacion.add(COD_ESTADO_RECTIFICACION_ASIGNADO);
         lstEstadosRectificacion.add(COD_ESTADO_RECTIFICACION_PENDIENTE_EVALUAR);

         params.put("NUM_CORREDOC",busquedaDua.getNumCorreDoc());
         params.put("listaCodigoTransaccion",lstTransacciones);
         params.put("listaEstados",lstEstadosRectificacion);

    List<Map<String, Object>> listSolicitudesRecti = cabSolrectiDAO.getLstRegistrosAnuladosYAgregados(params);
    //tiene solicitudes de rectiticacion pendientes

    for (Map<String, Object> mapSolRectificacion : listSolicitudesRecti) {
      //02-no debe de tener diligencia de rectificacion
        Long numCorreDocSol =  Utilidades.toLong(mapSolRectificacion.get("NUM_CORREDOC"));
        busquedaDua.setNumCorreDocSol(numCorreDocSol);
            boolean tieneRectificacion = diligenciaService.tieneDiligenciaTipo(busquedaDua,
                    COD_TIPO_DILIGENCIA_RECTIFICACION);
            //si tiene rectificacion entonces ya no es posible rectificar de oficio
            //puede tener mas de una rectificacion electronica por DUA segun la normatividad.
            bRspta = !tieneRectificacion;
            if(bRspta){
              break;
            }
        }

    return bRspta;
  }


  /**
   * queda pendiente de activacion normativa pidio que no se active en el pase I
   * Devuelve true si la DUA es posible
   * entrar al modulo regularizar
   *
   *
   * @param busquedaDua
   * @param mapDeclara
   * @return boolean
   */
  private boolean esRegularizable(BusquedaDua busquedaDua, Map<String, Object> mapDeclara)
  {
    boolean bRspta = false;
    String numCorreDocDua = busquedaDua.getNumCorreDoc().toString();
    String codRegimenDUA = busquedaDua.getCodRegimen();
    if (solicitudService.tieneSolicitudRegularizacionPendienteEvaluar(numCorreDocDua, codRegimenDUA))
    {
      boolean tieneRegu = diligenciaService.tieneDiligenciaTipo(busquedaDua,
                                                                COD_TIPO_DILIGENCIA_REGULARIZACION);
      // si tiene regularizacion entonces ya no es regularizable
      // solo existe una regularizacion por DUA segun la normatividad.
      bRspta = !tieneRegu;
    }

    return bRspta;
  }


  /**
   * Devuelve true si la DUA es posible
   * entrar al modulo diligencia.
   *
   * @param busquedaDua
   * @param mapDeclara
   * @return
   */
  private boolean esDiligenciable(BusquedaDua busquedaDua, Map<String, Object> mapDeclara)
  {
    boolean bRspta = false;
    String codEstadoDua = mapDeclara.get("COD_ESTDUA") != null ? mapDeclara.get("COD_ESTDUA").toString() : "";
    if (COD_ESTADO_DUA_EN_PROCESO_DILIGENCIA.equals(codEstadoDua))
    {
      // verificar si ya registro la diligencia despacho
      boolean tieneDiliDespacho = diligenciaService.tieneDiligenciaTipo(busquedaDua,
                                                                        COD_TIPO_DILIGENCIA_DESPACHO);
      // si tiene diligencia entonces ya no es dilgenciable
      // solo existe una diligencia de despacho por DUA segun la normatividad.
      bRspta = !tieneDiliDespacho;
    }

    return bRspta;
  }


  /**
   * consulta la BD y obtiene los datos de la declaracion
   *
   * @param BusquedaDua
   * @return Map[declaracion]
   * @exception ServiceException
   * @autor: amancillaa
   */
  private Map<String, Object> validarExisteDua(BusquedaDua datosDua){


    Map<String, Object> mapRspta = new HashMap<String, Object>();

    if (datosDua != null) {

      Map<String, Object> mapDua = new HashMap<String, Object>();

      mapDua.put("COD_ADUANA", datosDua.getCodAduana());
      mapDua.put("COD_REGIMEN", datosDua.getCodRegimen());
      mapDua.put("ANN_PRESEN", datosDua.getAnnoPresenta());
      mapDua.put("NUM_DECLARACION", datosDua.getNumDeclaracion());

      Map<String, Object> declaracion = declaracionService.obtenerDeclaracion(mapDua);

      if (!CollectionUtils.isEmpty(declaracion))
      {

        // participante 31 deposito temporal
        String numDocIdentPdf = MapUtils.getMapValor(declaracion, "NUM_DOCIDENT_PDF");
        String codLocalAnexo = MapUtils.getMapValor(declaracion, "COD_LOCALANEXO");
        String direccionLocalAnexo = "";
        if (!SunatStringUtils.isEmpty(codLocalAnexo) && !SunatStringUtils.isEmpty(numDocIdentPdf))
        {
          direccionLocalAnexo = declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdf, codLocalAnexo);
          if (SunatStringUtils.isEmpty(direccionLocalAnexo))
          { // si no esta registrado el local
            direccionLocalAnexo = "No registrado";
          }
        }
        else
        {
          direccionLocalAnexo = "No registrado";
        }
        declaracion.put("COD_LOCALANEXO_DESC", direccionLocalAnexo);
        String numDocIdentPdd =declaracion.get("NUM_DOCIDENT_PDD") != null? (String) declaracion.get("NUM_DOCIDENT_PDD"): "";
        String codLocalAnexoDeposito =declaracion.get("COD_LOCALANEXODEPOSITO") != null? (String) declaracion.get("COD_LOCALANEXODEPOSITO"): "";
        String direccionLocalAnexoDeposito = "";
        if (!SunatStringUtils.isEmpty(codLocalAnexoDeposito) && !SunatStringUtils.isEmpty(numDocIdentPdd))
        {
          direccionLocalAnexoDeposito =declaracionService.obtenerLocalAnexoDeclaracion(numDocIdentPdd,codLocalAnexoDeposito);
          if (SunatStringUtils.isEmpty(direccionLocalAnexoDeposito))
          { // si no esta registrado el local
            direccionLocalAnexoDeposito = " No registrado";
          }
        }
        else
        {
          direccionLocalAnexoDeposito = "No registrado";
        }

        declaracion.put("COD_LOCALANEXODEPOSITO_DESC", direccionLocalAnexoDeposito);

        if (!CollectionUtils.isEmpty(declaracion))
        {
          mapRspta.putAll(declaracion);
        }
      }

    }

    return mapRspta;
  }


  /**
   * @inheritdoc
   */
  public Map<String, Object> obtenerDatosGrabadosTemporalmente(String numCorreDoc, String codTipDiligencia)
  {
    Map<String, Object> mapRspta = new HashMap<String, Object>();
    Map<String, Object> pDiligTemp = new HashMap<String, Object>();
    pDiligTemp.put("NUM_CORREDOC", numCorreDoc);
    pDiligTemp.put("COD_TIPDILIGENCIA", codTipDiligencia);

    List<Map<String, Object>> lstTmpDetOfiRecti = tmpDetOfiRectiDAO.findTmpDetOfiRecti(pDiligTemp);

      /*INICIO-P34 FSW AFMA*/
     String usuario = "";
      /*FIN-P34 FSW AFMA*/
    if (!CollectionUtils.isEmpty(lstTmpDetOfiRecti))
    {
      List<DatoModificadoBean> lstCambios = new ArrayList<DatoModificadoBean>();
      for (Map mDetofiRecti : lstTmpDetOfiRecti)
      {
        String codTabla = mDetofiRecti.get("COD_TABLA").toString();
        Date fechaRegistroDatosTMP = (Date) mDetofiRecti.get("FEC_REGIS");
        Date fechaActual = new Date();
        Date fechaLimiteCaducidad = SunatDateUtils.addDay(fechaRegistroDatosTMP, MAX_DIAS_VIGENCIA_DATOS_TMP);
        if (SunatDateUtils.esFecha1MayorQueFecha2(fechaLimiteCaducidad, fechaActual, SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          // valida datos obtenidos
          if (org.apache.commons.lang.StringUtils.isNotBlank(codTabla))
          {
            Map<String, Object> mapKeys = getDatosValidos(mDetofiRecti, "DES_CLAVE");
            Map<String, Object> mapDesData1 = getDatosValidos(mDetofiRecti, "DES_DATA1");
            Map<String, Object> mapDesAntData1 = getDatosValidos(mDetofiRecti, "DES_ANTDATA1");

            String codtabla = mDetofiRecti.get("COD_TABLA").toString();
            List<DatoModificadoBean> lstDatosModificados = (List) rectificacionService.obtenerDatosModificadosTmpOfiRecti(mapDesData1, mapDesAntData1,
                                                                                                                          codtabla, mapKeys);
            lstCambios.addAll(lstDatosModificados);
          }
        }

         /*INICIO-P34 FSW AFMA*/
          usuario =   mDetofiRecti.get("COD_USUREGIS").toString();
         /*FIN-P34 FSW AFMA*/
      }

      if (!CollectionUtils.isEmpty(lstCambios))
      {
        int num = 1;
        for (DatoModificadoBean bean : lstCambios)
        {
          bean.setCorrelativo(num);
          num++;
        }
      }

      mapRspta.put("lstTmpDetOfiRecti", lstTmpDetOfiRecti);
      // ordernar cambios x tabla falta
      mapRspta.put("lstCambios", lstCambios);
    }
    else
    {
      mapRspta.put("lstTmpDetOfiRecti", new ArrayList());
      mapRspta.put("lstCambios", new ArrayList());
    }


        /*INICIO-P34 FSW AFMA*/
      mapRspta.put("USUARIO", usuario);
        /*FIN-P34 FSW AFMA*/

    return mapRspta;
  }


    /**
     * valida los datos JSON recuperado de la BD
     * @param Map dato contenedor de lso datos
     * @param String key clave del Map que se desea validar
     * @return mapRspta
     */
    private Map getDatosValidos(Map mapDato, String key){

        Map<String, Object> mapRspta = new HashMap<String, Object>();
        JsonSerializer serializer    = new JsonSerializer();
        String sDato = mapDato.get(key)!=null?mapDato.get(key).toString():"";
        if (org.apache.commons.lang.StringUtils.isNotBlank(sDato)){

            mapRspta = (Map<String, Object>) serializer.deserialize(sDato);
        }

        return mapRspta;
    }


    /**
     * @inheritdoc
     */
    public void borrarDatosTMP(String numCorreDoc) throws ServiceException{

        Map mp = new HashMap();
        mp.put("NUM_CORREDOC", numCorreDoc);
        mp.put("COD_TIPDILIGENCIA", COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);
        tmpDetOfiRectiDAO_xa.delete(mp);

        Map<String, Object> mapIndicadorDua = new HashMap<String, Object>();
        mapIndicadorDua.put("IND_ACTIVO", Constantes.INDICADOR_DUA_INACTIVO);
        mapIndicadorDua.put("NUM_CORREDOC", numCorreDoc);
        mapIndicadorDua.put("COD_INDICADOR", Constantes.IND_DUA_RECTI_OFICIO);
        indicadorDuaDAO.updateByRectificacion(mapIndicadorDua);
        
    }



    /**
     * @inheritdoc
     */
    public void grabarTMP(Map<String, Object> mapTablasSESSION) throws ServiceException
    {

        Map<String, Object> mapCabDeclaraActual = (HashMap<String, Object>) mapTablasSESSION.get("mapCabDeclaraActual");
        Map<String, Object> mapCabDeclara = (HashMap<String, Object>) mapTablasSESSION.get("mapCabDeclara");
        List<Map<String, Object>> lstDetDeclaraActual = (List<Map<String, Object>>) mapTablasSESSION.get("lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) mapTablasSESSION.get("lstDetDeclaraAnt");
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) mapTablasSESSION.get("lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItem = (List<Map<String, Object>>) mapTablasSESSION.get("lstSeriesItem");


        List<Map<String, Object>> lstDocuPrece = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDocuPreceActual = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstConvenioSerie = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstConvenioSerieActual = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDetAutorizacion = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDetAutorizacionActual = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstFacturaSerie = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstFacturaSerieActual = new ArrayList<Map<String, Object>>();

        String numCorreDoc = mapCabDeclaraActual.get("NUM_CORREDOC").toString();
        String codTipDiligencia = mapCabDeclaraActual.get("tipdilig").toString();
        // eliminando fisicamente registro anteriores
        borrarDatosTMP(numCorreDoc);

        /*INICIO-P34 FSW AFMA*/


        if(mapCabDeclaraActual.get("DES_RESULTADO")!=null){
            String resultado = mapCabDeclaraActual.get("DES_RESULTADO").toString();

            Map<String, Object> keyDiligencia = new HashMap<String, Object>();
            keyDiligencia.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
            keyDiligencia.put("COD_TIPDILIGENCIA", Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);
            keyDiligencia.put("NUM_CORREDOC_SOL", "0");

            Map<String, Object> mapDiligenciaNew = new HashMap<String, Object>(keyDiligencia);
            Map<String, Object> mapDiligencia = new HashMap<String, Object>(keyDiligencia);

            mapDiligenciaNew.put("DES_RESULTADO", resultado);
            mapDiligencia.put("DES_RESULTADO", "");

            grabarDatosTemporales(mapDiligenciaNew, mapDiligencia, EnumTablaModel.CAB_DILIGENCIA , numCorreDoc, codTipDiligencia);

        }

/*FIN-P34 FSW AFMA*/


        BusquedaDua busquedaDua = new BusquedaDua();
        busquedaDua.setNumCorreDoc( Utilidades.toLong(mapCabDeclaraActual.get("NUM_CORREDOC")));

        String observacionDeclaracionActual = mapCabDeclaraActual.get("OBS_OBS") != null ? mapCabDeclaraActual.get("OBS_OBS").toString() : "";

        if (!StringUtils.isEmpty(observacionDeclaracionActual)) {
            String observacionDeclaracionOld = mapCabDeclara.get("OBS_OBS") != null ? mapCabDeclara.get("OBS_OBS").toString() : "";


            Map<String, Object> keyObservacion = new HashMap<String, Object>();
            keyObservacion.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
            keyObservacion.put("COD_TIPOBS", "01");
            keyObservacion.put("NUM_SECOBS", "1");

            Map<String, Object> mapObservacionActual = new HashMap<String, Object>(keyObservacion);
            Map<String, Object> mapObservacion = new HashMap<String, Object>(keyObservacion);

            mapObservacionActual.put("OBS_OBS", observacionDeclaracionActual);
            mapObservacion.put("OBS_OBS", observacionDeclaracionOld);
            grabarDatosTemporales(mapObservacionActual, mapObservacion, EnumTablaModel.OBSERVACION, numCorreDoc, codTipDiligencia);

        }

        // Dentro de la declaracion tenemos FERIA
        if (!StringUtils.isEmpty((String) mapCabDeclaraActual.get("COD_FERIA"))) {
            if (StringUtils.isEmpty((String) mapCabDeclara.get("COD_FERIA"))
                    || (null != mapCabDeclara.get("COD_FERIA") && !StringUtils.equalsIgnoreCase(mapCabDeclara.get("COD_FERIA").toString(), mapCabDeclaraActual.get("COD_FERIA").toString()))) {
                Map mapAdmTempAntiguo = new HashMap();
                Map keyFeria = new HashMap();
                Map mapAdmTempActual = new HashMap();
                // CLAVE
                keyFeria.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                // ACTUAL DATO
                mapAdmTempActual.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                mapAdmTempActual.put("COD_FERIA", mapCabDeclaraActual.get("COD_FERIA"));
                // VEMOS SI HAY DATO ANTIGUO
                if (!StringUtils.isEmpty((String) mapCabDeclara.get("COD_FERIA"))) {
                    mapAdmTempAntiguo.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                    mapAdmTempAntiguo.put("COD_FERIA", mapCabDeclara.get("COD_FERIA"));
                }

                grabarDatosTemporales(mapAdmTempActual, mapAdmTempAntiguo, EnumTablaModel.CAB_ADI_ADMTEM , numCorreDoc, codTipDiligencia);

            }
        }

        if (!StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PDF").toString())) {

              Map<String, Object> mapParticipante_PDF = new HashMap<String, Object>();
              Map<String, Object> mapParticipante_PDF_ANT= new HashMap<String, Object>();


              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PDF"));

             mapParticipante_PDF.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PDF"));
             mapParticipante_PDF.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PDF"));
             
             mapParticipante_PDF_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PDF"));
             mapParticipante_PDF_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PDF"));

             grabarDatosTemporales(mapParticipante_PDF, mapParticipante_PDF_ANT, EnumTablaModel.PARTICIPANTE_DOC , numCorreDoc, codTipDiligencia);

        }


        if (!StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_SECPARTIC_PTR").toString())) {

            Map<String, Object> mapParticipante_PTR = new HashMap<String, Object>();
            Map<String, Object> mapParticipante_PTR_ANT = new HashMap<String, Object>();



            Map<String, Object> key = new HashMap<String, Object>();
            key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PTR"));

            mapParticipante_PTR.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PTR"));
            mapParticipante_PTR.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PTR"));
            mapParticipante_PTR.put("COD_TIPPARTIC", mapCabDeclaraActual.get("COD_TIPPARTIC_PTR"));
            

            mapParticipante_PTR_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PTR"));
            mapParticipante_PTR_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PTR"));
            mapParticipante_PTR_ANT.put("COD_TIPPARTIC", mapCabDeclara.get("COD_TIPPARTIC_PTR"));
         
            grabarDatosTemporales(mapParticipante_PTR, mapParticipante_PTR_ANT, EnumTablaModel.PARTICIPANTE_DOC , numCorreDoc, codTipDiligencia);


      }


        //P34 amancilla if (!StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString())) {
        if (!StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString())) {
          Map<String, Object> mapParticipante_PIM = new HashMap<String, Object>();
            Map<String, Object> mapParticipante_PIM_ANT = new HashMap<String, Object>();

            Map<String, Object> key = new HashMap<String, Object>();
            key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PIM"));

            mapParticipante_PIM.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PIM"));
            mapParticipante_PIM.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PIM"));
            mapParticipante_PIM.put("COD_TIPDOC", mapCabDeclaraActual.get("COD_TIPDOC_PIM"));
            mapParticipante_PIM.put("NOM_RAZONSOCIAL", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM"));
            mapParticipante_PIM.put("DIR_PARTIC", mapCabDeclaraActual.get("DIR_PARTIC_PIM"));
           
           

            mapParticipante_PIM_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PIM"));
            mapParticipante_PIM_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PIM"));
            mapParticipante_PIM_ANT.put("COD_TIPDOC",    mapCabDeclara.get("COD_TIPDOC_PIM"));
            mapParticipante_PIM_ANT.put("NOM_RAZONSOCIAL", mapCabDeclara.get("NOM_RAZONSOCIAL_PIM"));
            mapParticipante_PIM_ANT.put("DIR_PARTIC", mapCabDeclara.get("DIR_PARTIC_PIM"));

           

            grabarDatosTemporales(mapParticipante_PIM, mapParticipante_PIM_ANT, EnumTablaModel.PARTICIPANTE_DOC , numCorreDoc, codTipDiligencia);
        }

        grabarDatosTemporales(mapCabDeclaraActual, mapCabDeclara, EnumTablaModel.CAB_DECLARA, numCorreDoc, codTipDiligencia);
        grabarDatosTemporales(lstDetDeclaraActual, lstDetDeclara, EnumTablaModel.DET_DECLARA, numCorreDoc, codTipDiligencia);

        // detDeclaraActual
        if (!CollectionUtils.isEmpty(lstDetDeclaraActual))
        {
            for (Map<String, Object> detDeclaraActual : lstDetDeclaraActual)
            {
                // obtiene el mapa historico de la lista por el PK de la tabla
                Map<String, Object> detDeclara = soporteComparadorService.obtenerElementoMapXPkTabla(lstDetDeclara, detDeclaraActual, EnumTablaModel.DET_DECLARA);

                // DocuPrece
                lstDocuPrece = (ArrayList<Map<String, Object>>) detDeclara.get("lstDocuPreceDua");
                lstDocuPreceActual = (ArrayList<Map<String, Object>>) detDeclaraActual.get("lstDocuPreceDua");
                grabarDatosTemporales(lstDocuPreceActual, lstDocuPrece, EnumTablaModel.DOCUPRECE_DUA, numCorreDoc, codTipDiligencia);
                
                //jenciso - Inicio cambios ceticos parte1
                if(!CollectionUtils.isEmpty(lstDocuPreceActual)){
                	List<Map<String, Object>> lstDatoVehiculo = (ArrayList<Map<String,Object>>)detDeclaraActual.get("lstDatoVehiculo");
                    List<Map<String, Object>> lstDatoMontoGasto = (ArrayList<Map<String,Object>>)detDeclaraActual.get("lstDatoMontoGasto");
                    
                    if(!CollectionUtils.isEmpty(lstDatoVehiculo) ){
                    	List<Map<String, Object>> lstDatoVehiculoAnt = (detDeclara!=null && detDeclara.get("lstDatoVehiculo") != null) ? (ArrayList<Map<String, Object>>) detDeclara.get("lstDatoVehiculo") : new ArrayList<Map<String, Object>>();
                    	
                    	grabarDatosTemporales(lstDatoVehiculo, lstDatoVehiculoAnt, EnumTablaModel.VEHI_CETICO, numCorreDoc,codTipDiligencia);
                    	
                    	if(!CollectionUtils.isEmpty(lstDatoMontoGasto)){
                    		List<Map<String, Object>> lstDatoMontoGastoAnt = (detDeclara!=null && detDeclara.get("lstDatoMontoGasto") != null) ? (ArrayList<Map<String, Object>>) detDeclara.get("lstDatoMontoGasto") : new ArrayList<Map<String, Object>>();
                        	List<Map<String, Object>> lstDatoMontoGastoAux = Utilidades.copiarLista((List)lstDatoMontoGasto);//para agregar los eliminado de la lista original
                        	lstDatoMontoGastoAux= agregaEliminadoAListaActual(lstDatoMontoGastoAux, lstDatoMontoGastoAnt, "MONTOGASTO", "NUM_CORREDOC","NUM_SECSERIE","COD_CPTOGASTOS");
                        	grabarDatosTemporales(lstDatoMontoGastoAux, lstDatoMontoGastoAnt, EnumTablaModel.MONTOGASTO, numCorreDoc,codTipDiligencia);
                    	}
                    }
                }                
                //jenciso - Fin cambios ceticos parte1

                // ConvenioSerie
                lstConvenioSerie = (ArrayList<Map<String, Object>>) detDeclara.get("lstConvenioSerie");
                lstConvenioSerieActual = (ArrayList<Map<String, Object>>) detDeclaraActual.get("lstConvenioSerie");
                grabarDatosTemporales(lstConvenioSerieActual, lstConvenioSerie, EnumTablaModel.CONVENIO_SERIE, numCorreDoc, codTipDiligencia);

                // DetAutorizacion
                lstDetAutorizacion = (ArrayList<Map<String, Object>>) detDeclara.get("lstDetAutorizacion");
                lstDetAutorizacionActual = (ArrayList<Map<String, Object>>) detDeclaraActual.get("lstDetAutorizacion");
                grabarDatosTemporales(lstDetAutorizacionActual, lstDetAutorizacion, EnumTablaModel.DET_AUTORIZACION, numCorreDoc, codTipDiligencia);

                // facturaSerie
                lstFacturaSerie       = (ArrayList<Map<String, Object>>) detDeclara.get("lstFacturaSerie");
                lstFacturaSerieActual = (ArrayList<Map<String, Object>>) detDeclaraActual.get("lstFacturaSerie");
                if(lstFacturaSerie==null)
                {
                  lstFacturaSerie  = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.FACTURA_SERIE);
                }
                grabarDatosTemporales(lstFacturaSerieActual, lstFacturaSerie, EnumTablaModel.FACTURA_SERIE, numCorreDoc, codTipDiligencia);

          }
        }

        if(lstSeriesItem==null)
        {
          lstSeriesItem  = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.SERIES_ITEM);
        }
        grabarDatosTemporales(lstSeriesItemActual, lstSeriesItem, EnumTablaModel.SERIES_ITEM, numCorreDoc, codTipDiligencia);

        List<Map<String, Object>> lstCabCertiOrigenActual = (ArrayList<Map<String, Object>>) mapCabDeclaraActual.get("lstCabCertiOrigen");
        List<Map<String, Object>> lstCabCertiOrigen = (ArrayList<Map<String, Object>>) mapCabDeclara.get("lstCabCertiOrigen");
        grabarDatosTemporales(lstCabCertiOrigenActual, lstCabCertiOrigen, EnumTablaModel.CAB_CERTIORIGEN, numCorreDoc, codTipDiligencia);

        //FORMATO B
        List<Map<String, Object>> lstFormBProveedorActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor");
        List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
        if (!CollectionUtils.isEmpty(lstFormBProveedorActual)) {
          grabarDatosTemporales(lstFormBProveedorActual, lstFormBProveedor, EnumTablaModel.FORMBPROVEEDOR , numCorreDoc, codTipDiligencia);


          for (Map<String, Object> mapProveedor : lstFormBProveedorActual)
          {
            Map<String, Object> fbKeys = new HashMap<String, Object>();
            fbKeys.put("num_corredoc", mapProveedor.get("num_corredoc"));
            fbKeys.put("num_secprove", mapProveedor.get("num_secprove"));
            Map mapProveedorAnt = Utilidades.obtenerElemento((ArrayList<Map<String, Object>>) lstFormBProveedor, fbKeys);

            if (mapProveedor.get("num_codsecprove")!=null && !StringUtils.isEmpty(mapProveedor.get("num_codsecprove").toString())) {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prv"));
              partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prv"));
              partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_prv"));
              partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_prv"));
              partic.put("NUM_FAX", mapProveedor.get("num_fax_prv"));
              partic.put("NUM_TELEFONO", mapProveedor.get("num_telefono_prv"));
              partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_prv"));
              partic.put("NOM_EMAIL", mapProveedor.get("nom_email_prv"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_codsecprove"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prv"));
              particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prv"));
              particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_prv"));
              particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_prv"));
              particAnt.put("NUM_FAX", mapProveedorAnt.get("num_fax_prv"));
              particAnt.put("NUM_TELEFONO", mapProveedorAnt.get("num_telefono_prv"));
              particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_prv"));
              particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_prv"));


              grabarDatosTemporales(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC, numCorreDoc, codTipDiligencia);

            }

            if (mapProveedor.get("num_secpartic_pim")!=null && !StringUtils.isEmpty(mapProveedor.get("num_secpartic_pim").toString())) {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pim"));
              partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_pim"));
              partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_pim"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_pim"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pim"));
              particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pim"));
              particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pim"));

              grabarDatosTemporales(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC, numCorreDoc, codTipDiligencia);

            }

            if (mapProveedor.get("num_secpartic_prl")!=null && !StringUtils.isEmpty(mapProveedor.get("num_secpartic_prl").toString())) {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prl"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_prl"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("num_secpartic_prl"));

              grabarDatosTemporales(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC, numCorreDoc, codTipDiligencia);

            }
            // Actualizamos al declarante
            if (mapProveedor.get("num_secdeclarante")!=null && !StringUtils.isEmpty(mapProveedor.get("num_secdeclarante").toString())) {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prd"));
              partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_prd"));
              partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_prd"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secdeclarante"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prd"));
              particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_prd"));
              particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_prd"));

              grabarDatosTemporales(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC, numCorreDoc, codTipDiligencia);
            }
            //se completo el o estaba num_secintermediari y no entraba
            if (mapProveedor.get("num_secintermediario")!=null && !StringUtils.isEmpty(mapProveedor.get("num_secintermediario").toString())) {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pri"));
              partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_pri"));
              partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_pri"));
              partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_pri"));
              partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_pri"));
              partic.put("NOM_EMAIL", mapProveedor.get("nom_email_pri"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secintermediario"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pri"));
              particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_pri"));
              particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_pri"));
              particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_pri"));
              particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_pri"));
              particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_pri"));

              grabarDatosTemporales(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC, numCorreDoc, codTipDiligencia);
            }


            Map condiciones   = mapProveedor.get("mapCondicionTransa")!=null?(HashMap) mapProveedor.get("mapCondicionTransa"):new HashMap();
            Map condicionesAnt = mapProveedorAnt.get("mapCondicionTransa") != null? (HashMap) mapProveedorAnt.get("mapCondicionTransa"): null;

            Object[] ctrNamesCond = condiciones.keySet().toArray();
            if (ctrNamesCond != null && ctrNamesCond.length > 0)
            {
              Map condUpd = new HashMap();
              condUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
              condUpd.put("num_secprove", mapProveedor.get("num_secprove"));

              for (int j = 0; j < ctrNamesCond.length; j++)
              {
                if (condicionesAnt == null
                    || condicionesAnt.get(ctrNamesCond[j].toString()) == null
                    || !condicionesAnt.get(ctrNamesCond[j].toString()).toString().trim().equals(condiciones.get(ctrNamesCond[j].toString()).toString().trim()))
                {
                  condUpd.put("cod_indtransaccion", ctrNamesCond[j].toString());
                  condUpd.put("ind_transaccion", condiciones.get(ctrNamesCond[j].toString()));

                  Map condUpdAnt = new HashMap();
                  condUpdAnt.put("ind_transaccion",(condicionesAnt != null ? condicionesAnt.get(ctrNamesCond[j].toString()) : null));

                  grabarDatosTemporales(condUpd, condUpdAnt, EnumTablaModel.CONDICION_TRANSA , numCorreDoc, codTipDiligencia);
                }
              }
            }

            // Actualizamos los montos
            Map montos    = mapProveedor.get("mapFormBMonto")!=null?(HashMap) mapProveedor.get("mapFormBMonto"): new HashMap();
            Map montosAnt = mapProveedorAnt.get("mapFormBMonto")!=null?(HashMap) mapProveedorAnt.get("mapFormBMonto"):null;
            Object[] ctrNamesMto = montos.keySet().toArray();
            if (ctrNamesMto != null && ctrNamesMto.length > 0)
            {
              Map montoUpd = new HashMap();
              montoUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
              montoUpd.put("num_secprove", mapProveedor.get("num_secprove"));
              for (int j = 0; j < ctrNamesMto.length; j++)
              {
                if (montosAnt == null
                    || montosAnt.get(ctrNamesMto[j].toString()) == null
                    || !montosAnt.get(ctrNamesMto[j].toString()).toString().trim().equals(montos.get(ctrNamesMto[j].toString()).toString().trim()))
                {
                  montoUpd.put("cod_monto", ctrNamesMto[j].toString());
                  montoUpd.put("mto_valor", montos.get(ctrNamesMto[j].toString()));

                  Map montoUpdAnt = new HashMap();
                  montoUpdAnt.put("mto_valor", (montosAnt != null ? montosAnt.get(ctrNamesMto[j].toString()) : null));

                  grabarDatosTemporales(montoUpd, montoUpdAnt, EnumTablaModel.FORMBMONTO, numCorreDoc, codTipDiligencia);
                  }
              }
            }


         // ComproBPago
            List<Map<String, Object>> lstComproBPagoActual = (List<Map<String, Object>>) mapProveedor.get("lstComproBPago");
            List<Map<String, Object>> lstComproBPago       = (List<Map<String, Object>>) mapProveedorAnt.get("lstComproBPago");
            if (!CollectionUtils.isEmpty(lstComproBPagoActual))
            {
                if(lstComproBPago == null)
                {
                  lstComproBPago = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.COMPROB_PAGO);
                }
                grabarDatosTemporales(lstComproBPagoActual, lstComproBPago, EnumTablaModel.COMPROB_PAGO, numCorreDoc, codTipDiligencia);

                // itemFactura
                for (Map<String, Object> comproBPagoActual : lstComproBPagoActual) {
                  Map keys = obtenerMapKey(comproBPagoActual, "num_secfact");
                  Map<String, Object> comproBPago = Utilidades.obtenerElemento(lstComproBPago, keys);

                  List<Map<String, Object>> lstItemFacturaActual = (List<Map<String, Object>>) comproBPagoActual.get("lstItemFactura");
                  List<Map<String, Object>> lstItemFactura = (List<Map<String, Object>>) comproBPago.get("lstItemFactura");
                  if (!CollectionUtils.isEmpty(lstItemFacturaActual))
                  {
                     if(lstItemFactura==null)
                     {
                        lstItemFactura = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.ITEMFACTURA);
                     }
                      grabarDatosTemporales(lstItemFacturaActual, lstItemFactura, EnumTablaModel.ITEMFACTURA , numCorreDoc, codTipDiligencia);


                      //observaciones tipo 03 -OBSERVACION DEL ITEM DEL FORMATO B
                      for (Map<String, Object> mapItem : lstItemFacturaActual)
                      {

                        String observacionItemFacturaActual = mapItem.get("OBSERVACION") != null ? mapItem.get("OBSERVACION").toString() : "";
                        if (!StringUtils.isEmpty(observacionItemFacturaActual))
                        {

                          Map keysitem = new HashMap();
                          keysitem.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));
                          keysitem.put("NUM_SECITEM", mapItem.get("NUM_SECITEM"));

                          Map mapItemOld = Utilidades.obtenerElemento(lstItemFactura, keysitem);
                          String observacionItemFacturaOld = mapItemOld.get("OBSERVACION") != null ? mapItemOld.get("OBSERVACION").toString() : "";

                          Map<String, Object> keyObservacion = new HashMap<String, Object>();
                          keyObservacion.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));
                          keyObservacion.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
                          keyObservacion.put("NUM_SECOBS", mapItem.get("NUM_SECOBS"));

                          Map<String, Object> mapObservacionActual = new HashMap<String, Object>(keyObservacion);
                          Map<String, Object> mapObservacion = new HashMap<String, Object>(keyObservacion);

                          mapObservacionActual.put("OBS_OBS", observacionItemFacturaActual);
                          mapObservacion.put("OBS_OBS", observacionItemFacturaOld);

                          grabarDatosTemporales(mapObservacionActual, mapObservacion, EnumTablaModel.OBSERVACION, numCorreDoc, codTipDiligencia);

                        }
                      }
                  }
              }
            }

          }
        }




    }


    /**
     * Compara los datos enviados y los valida segun el XML
     * una vez validado graba en la tabla TMP
     *
     * @param listActual [List<Map<String,Object>>] list actual
     * @param listHistorica [List<Map<String,Object>>] list historica
     * @param enumTablaModel [EnumTablaModel] enum tabla model
     * @param numCorreDoc [String] num corre doc
     * @param codTipDiligencia [String] cod tip diligencia
     */
    private void grabarDatosTemporales(List<Map<String, Object>> listActual,
                                       List<Map<String, Object>> listHistorica,
                                       EnumTablaModel enumTablaModel,
                                       String numCorreDoc,
                                       String codTipDiligencia){

        if (!CollectionUtils.isEmpty(listActual)) {
            for (Map<String, Object> mapRegistroActual : listActual) {
                 
            	if (enumTablaModel.getCodTabla().equals("T0070")){
            		mapRegistroActual.put("NUM_CORREDOC",mapRegistroActual.get("num_corredoc"));
            		mapRegistroActual.put("NUM_SECPROVE",mapRegistroActual.get("num_secprove"));
                }                
            	
                Map<String, Object> mapHistorica =
                    soporteComparadorService.obtenerElementoMapXPkTabla(listHistorica,mapRegistroActual, enumTablaModel);

                grabarDatosTemporales(mapRegistroActual, mapHistorica, enumTablaModel, numCorreDoc, codTipDiligencia);
      }
    }
  }

    /**
     * Proceso : Metodo permite grabar los datos ingresados por el especialista
     * de forma temporal hasta completar la diligencia.
     * Invocaciones : Rectificacion Oficio
     *
     * @param mapActual
     * @param mapHistorica
     * @param enumTablaModel
     *
     * @autor: amancillaa
     */
    private void grabarDatosTemporales(Map<String, Object> mapActual,
                                       Map<String, Object> mapHistorica,
                                       EnumTablaModel enumTablaModel,
                                       String numCorreDoc,
                                       String codTipDiligencia){

        Map<String, Object> mapDiferencia = new HashMap<String, Object>();
        
        mapDiferencia = soporteComparadorService.comparaMap(mapActual, mapHistorica, enumTablaModel);

        grabarTmpRectiOficio(mapDiferencia, enumTablaModel, numCorreDoc, codTipDiligencia);

  }

    private void grabarTmpRectiOficio(Map<String, Object> mapDatosModificados,
                                      EnumTablaModel enumTablaModel,
                                      String numCorreDoc,
                                      String codTipDiligencia){




        if (!CollectionUtils.isEmpty(mapDatosModificados)
                && !CollectionUtils.isEmpty((Map<String, Object>) mapDatosModificados.get("dataModificados"))) {


            Map mapDatosMofificados = filtrarDatos((Map<String, Object>) mapDatosModificados.get("dataModificados"));

            if (!CollectionUtils.isEmpty(mapDatosMofificados)){

                Map<String, Object> mapDatos = new HashMap<String, Object>();

                mapDatos.put("NUM_CORREDOC", numCorreDoc);
                mapDatos.put("COD_TIPDILIGENCIA", codTipDiligencia);
                mapDatos.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(KEY_SECUENCIA_OFI_RECTI));
                mapDatos.put("COD_TABLA", enumTablaModel.getCodTabla().toString());

                mapDatos.put("DES_CLAVE", SojoUtil.toJson(mapDatosModificados.get("clave")));
                if (SojoUtil.toJson(mapDatosModificados.get("dataModificados")).length() <= 4000) {
                    mapDatos.put("DES_DATA1", SojoUtil.toJson(mapDatosModificados.get("dataModificados")));
                } else {
                    mapDatos.put("DES_DATA1", SojoUtil.toJson(mapDatosModificados.get("dataModificados"))
                            .substring(0, 3999));
                    mapDatos.put("DES_DATA2",
                            SojoUtil.toJson(mapDatosModificados.get("dataModificados")).substring(4000, 7999));
                }

                if (SojoUtil.toJson(mapDatosModificados.get("dataOriginal")).length() <= 4000) {
                    mapDatos.put("DES_ANTDATA1", SojoUtil.toJson(mapDatosModificados.get("dataOriginal")));
                } else {
                    mapDatos.put("DES_ANTDATA1", SojoUtil.toJson(mapDatosModificados.get("dataOriginal"))
                            .substring(0, 3999));
                    mapDatos.put("DES_ANTDATA2",
                            SojoUtil.toJson(mapDatosModificados.get("dataOriginal")).substring(4000, 7999));
                }

                tmpDetOfiRectiDAO_xa.insert(mapDatos);
            }
        }
    }

    //P34 amancilla se filtra datos que no competen
    private Map filtrarDatos(Map<String, Object> dataModificados) {

        if (!CollectionUtils.isEmpty(dataModificados)) {

            if (dataModificados.containsKey("FEC_REGIS"))
                dataModificados.remove("FEC_REGIS");
            if (dataModificados.containsKey("COD_USUREGIS"))
                dataModificados.remove("COD_USUREGIS");
            if (dataModificados.containsKey("FEC_MODIF"))
                dataModificados.remove("FEC_MODIF");
            if (dataModificados.containsKey("COD_USUMODIF"))
                dataModificados.remove("COD_USUMODIF");
        }

        return dataModificados;
    }


    /**
     * Obtiene los cambios de la declaracion realizados por rectificacion de oficio
     * Formaro A y B
     *
     */
    public List<DatoModificadoBean> obtenerCambiosDeclaracion(Map<String, Object> param) throws ServiceException{
//P34 AFMA
        Map<String, Object> mapCabDeclaraActual       =  param.get("mapCabDeclaraActual")!=null?(HashMap) param.get("mapCabDeclaraActual"):new HashMap<String, Object>();
        Map<String, Object> mapCabDeclara             =  param.get("mapCabDeclara")!=null?(HashMap) param.get("mapCabDeclara"):new HashMap<String, Object>();
        List<Map<String, Object>> lstDetDeclaraActual =  param.get("lstDetDeclaraActual")!=null?(ArrayList) param.get("lstDetDeclaraActual"): new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstDetDeclara       =  param.get("lstDetDeclara")!=null?(ArrayList) param.get("lstDetDeclara"): new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItemActual =  param.get("lstSeriesItemActual")!=null?(ArrayList) param.get("lstSeriesItemActual"): new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> lstSeriesItem       =  param.get("lstSeriesItem")!=null?(ArrayList) param.get("lstSeriesItem"): new ArrayList<Map<String, Object>>();

        Map<String, Object> keys = new HashMap<String, Object>();
        List<DatoModificadoBean> lstCambiosDecla = new ArrayList<DatoModificadoBean>();
        // cab_declara
        keys = obtenerMapKey(mapCabDeclaraActual, "NUM_CORREDOC");
        lstCambiosDecla = obtenerCambiosMap(mapCabDeclaraActual, mapCabDeclara, "CAB_DECLARA", keys);

        BusquedaDua busquedaDua = new BusquedaDua();
        busquedaDua.setNumCorreDoc( Utilidades.toLong(mapCabDeclaraActual.get("NUM_CORREDOC")));

        // Dentro de la declaracion tenemos las observaciones, a la fecha se
        // maneja como una sola (dentor d eun map) deberia de
        // ser con una lista de observaciones
        String observacionDeclaracionActual = mapCabDeclaraActual.get("OBS_OBS") != null ? mapCabDeclaraActual.get("OBS_OBS").toString() : "";

        if (!StringUtils.isEmpty(observacionDeclaracionActual)) {
            String observacionDeclaracionOld = mapCabDeclara.get("OBS_OBS") != null ? mapCabDeclara.get("OBS_OBS").toString() : "";


            Map<String, Object> keyObservacion = new HashMap<String, Object>();
            keyObservacion.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
            keyObservacion.put("COD_TIPOBS", "01");
            keyObservacion.put("NUM_SECOBS", "1");

            Map<String, Object> mapObservacionActual = new HashMap<String, Object>(keyObservacion);
            Map<String, Object> mapObservacion = new HashMap<String, Object>(keyObservacion);

            mapObservacionActual.put("OBS_OBS", observacionDeclaracionActual);
            mapObservacion.put("OBS_OBS", observacionDeclaracionOld);
            lstCambiosDecla.addAll(obtenerCambiosMap(mapObservacionActual, mapObservacion, "OBSERVACION", keyObservacion));
        }

        //PAS20181U220200069 - mtorralba 20190301 - INICIO - Para validar observaciones complementarias de PECO Amazonia
        String observacionPecoActual = mapCabDeclaraActual.get("OBS_PECO") != null ? mapCabDeclaraActual.get("OBS_PECO").toString() : "";

        if (!StringUtils.isEmpty(observacionPecoActual)) {
            String observacionPecoOld = mapCabDeclara.get("OBS_PECO") != null ? mapCabDeclara.get("OBS_PECO").toString() : "";

            Map<String, Object> keyObservacion = new HashMap<String, Object>();
            keyObservacion.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
            keyObservacion.put("COD_TIPOBS", "06");
            keyObservacion.put("NUM_SECOBS", mapCabDeclara.get("SECOBS_PECO").toString());

            Map<String, Object> mapObservacionActual = new HashMap<String, Object>(keyObservacion);
            Map<String, Object> mapObservacion = new HashMap<String, Object>(keyObservacion);

            mapObservacionActual.put("OBS_OBS", observacionPecoActual);
            mapObservacion.put("OBS_OBS", observacionPecoOld);
            lstCambiosDecla.addAll(obtenerCambiosMap(mapObservacionActual, mapObservacion, "OBSERVACION", keyObservacion));
        }
        //PAS20181U220200069 - mtorralba 20190301 - FIN

        
        // Dentro de la declaracion tenemos FERIA
        if (!StringUtils.isEmpty((String) mapCabDeclaraActual.get("COD_FERIA"))) {
            if (StringUtils.isEmpty((String) mapCabDeclara.get("COD_FERIA"))
                    || (null != mapCabDeclara.get("COD_FERIA") && !StringUtils.equalsIgnoreCase(mapCabDeclara.get("COD_FERIA").toString(), mapCabDeclaraActual.get("COD_FERIA").toString()))) {
                Map mapAdmTempAntiguo = new HashMap();
                Map keyFeria = new HashMap();
                Map mapAdmTempActual = new HashMap();
                // CLAVE
                keyFeria.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                // ACTUAL DATO
                mapAdmTempActual.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                mapAdmTempActual.put("COD_FERIA", mapCabDeclaraActual.get("COD_FERIA"));
                // VEMOS SI HAY DATO ANTIGUO
                if (!StringUtils.isEmpty((String) mapCabDeclara.get("COD_FERIA"))) {
                    mapAdmTempAntiguo.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
                    mapAdmTempAntiguo.put("COD_FERIA", mapCabDeclara.get("COD_FERIA"));
                }
                lstCambiosDecla.addAll(obtenerCambiosMap(mapAdmTempActual, mapAdmTempAntiguo, "CAB_ADI_ADMTEM", keyFeria));
            }
        }
//amancilla  SAU20153N002000216
        if (mapCabDeclaraActual.get("NUM_DOCIDENT_PDF")!=null && !StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PDF").toString())) {

        	    Map<String, Object> mapParticipante_PDF = new HashMap<String, Object>();
              Map<String, Object> mapParticipante_PDF_ANT= new HashMap<String, Object>();


              Map<String, Object> key = new HashMap<String, Object>();

            String secuenciaParticipante = mapCabDeclaraActual.get("NUM_SECPARTIC_PDF")!=null?mapCabDeclaraActual.get("NUM_SECPARTIC_PDF").toString():"";
            if(StringUtils.isEmpty(secuenciaParticipante)){
                DatoModificadoBean bean = new DatoModificadoBean();
                bean.setDatoNuevo(mapCabDeclaraActual.get("NUM_DOCIDENT_PDF").toString());
                bean.setDatoAntiguo("");
                bean.setDescripcionSecccion("DEPOSITO TEMPORAL");
                bean.setDescripcionNombreCampo("DOCUMENTO IDENTIDAD");
                lstCambiosDecla.add(bean);
            }else{
              key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PDF"));
        	   mapParticipante_PDF.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PDF"));
             mapParticipante_PDF.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PDF"));
             //P34 AFMA
             mapParticipante_PDF.put("COD_TIPPARTIC", mapCabDeclaraActual.get("COD_TIPPARTIC_PDF"));
             
             mapParticipante_PDF_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PDF"));
             mapParticipante_PDF_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PDF"));
             //P34 AFMA
             mapParticipante_PDF_ANT.put("COD_TIPPARTIC",  mapCabDeclara.get("COD_TIPPARTIC_PDF"));
             
                lstCambiosDecla.addAll(obtenerCambiosMap(mapParticipante_PDF, mapParticipante_PDF_ANT, "PARTICIPANTE_DOC", key));
            }

        }


        if (mapCabDeclaraActual.get("NUM_DOCIDENT_PTR")!=null && !StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PTR").toString())) {

            Map<String, Object> mapParticipante_PTR = new HashMap<String, Object>();
            Map<String, Object> mapParticipante_PTR_ANT = new HashMap<String, Object>();

            Map<String, Object> key = new HashMap<String, Object>();
            
            String secuenciaParticipante = mapCabDeclaraActual.get("NUM_SECPARTIC_PTR")!=null?mapCabDeclaraActual.get("NUM_SECPARTIC_PTR").toString():"";
            if(StringUtils.isEmpty(secuenciaParticipante)){
            	DatoModificadoBean bean = new DatoModificadoBean();
            	bean.setDatoNuevo(mapCabDeclaraActual.get("NUM_DOCIDENT_PTR").toString());
            	bean.setDatoAntiguo("");
            	bean.setDescripcionSecccion("TRANSPORTISTA");
            	bean.setDescripcionNombreCampo("DOCUMENTO IDENTIDAD");            	
            	lstCambiosDecla.add(bean);
            }else{
            key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PTR"));
            mapParticipante_PTR.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PTR"));
            mapParticipante_PTR.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PTR"));
            mapParticipante_PTR.put("COD_TIPPARTIC", mapCabDeclaraActual.get("COD_TIPPARTIC_PTR"));
            mapParticipante_PTR_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PTR"));
            mapParticipante_PTR_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PTR"));
            mapParticipante_PTR_ANT.put("COD_TIPPARTIC", mapCabDeclara.get("COD_TIPPARTIC_PTR"));
               lstCambiosDecla.addAll(obtenerCambiosMap(mapParticipante_PTR, mapParticipante_PTR_ANT, "PARTICIPANTE_DOC", key));

      }

                  }

//amancilla  SAU20153N002000216
        if (mapCabDeclaraActual.get("NUM_DOCIDENT_PIM")!=null && !StringUtils.isEmpty(mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString())) {
        	Map<String, Object> mapParticipante_PIM = new HashMap<String, Object>();
            Map<String, Object> mapParticipante_PIM_ANT = new HashMap<String, Object>();

            Map<String, Object> key = new HashMap<String, Object>();

            String secuenciaParticipante = mapCabDeclaraActual.get("NUM_SECPARTIC_PIM")!=null?mapCabDeclaraActual.get("NUM_SECPARTIC_PIM").toString():"";
            if(StringUtils.isEmpty(secuenciaParticipante)){
                DatoModificadoBean bean = new DatoModificadoBean();
                bean.setDatoNuevo(mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString());
                bean.setDatoAntiguo("");
                bean.setDescripcionSecccion("DUE�O, CONSIGNATARIO O CONSIGNANTE");
                bean.setDescripcionNombreCampo("DOCUMENTO IDENTIDAD");
                lstCambiosDecla.add(bean);
            }else{
                //amancilla SAU20153N002000216
                //key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PTR"));
                key.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PIM"));
                //fin amancilla SAU20153N002000216
            mapParticipante_PIM.put("NUM_SECPARTIC", mapCabDeclaraActual.get("NUM_SECPARTIC_PIM"));
            mapParticipante_PIM.put("NUM_DOCIDENT", mapCabDeclaraActual.get("NUM_DOCIDENT_PIM"));
            mapParticipante_PIM.put("COD_TIPDOC", mapCabDeclaraActual.get("COD_TIPDOC_PIM"));
            mapParticipante_PIM.put("NOM_RAZONSOCIAL", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM"));
            mapParticipante_PIM.put("DIR_PARTIC", mapCabDeclaraActual.get("DIR_PARTIC_PIM"));
          //P34 AFMA PARA QUE EL SISTEMA COMPLETA LA DESCRIPCIO
            mapParticipante_PIM.put("COD_TIPPARTIC", mapCabDeclaraActual.get("COD_TIPPARTIC_PIM"));
            
            mapParticipante_PIM_ANT.put("NUM_SECPARTIC", mapCabDeclara.get("NUM_SECPARTIC_PIM"));
            mapParticipante_PIM_ANT.put("NUM_DOCIDENT",  mapCabDeclara.get("NUM_DOCIDENT_PIM"));
            mapParticipante_PIM_ANT.put("COD_TIPDOC",    mapCabDeclara.get("COD_TIPDOC_PIM"));
            mapParticipante_PIM_ANT.put("NOM_RAZONSOCIAL", mapCabDeclara.get("NOM_RAZONSOCIAL_PIM"));
            mapParticipante_PIM_ANT.put("DIR_PARTIC", mapCabDeclara.get("DIR_PARTIC_PIM"));
            //P34 AFMA PARA QUE EL SISTEMA COMPLETA LA DESCRIPCIO
            mapParticipante_PIM_ANT.put("COD_TIPPARTIC", mapCabDeclara.get("COD_TIPPARTIC_PIM"));
        	lstCambiosDecla.addAll(obtenerCambiosMap(mapParticipante_PIM, mapParticipante_PIM_ANT, "PARTICIPANTE_DOC", key));
        }
        }
        //dentro de la decalracion tenemos participantes


        // det_delcara
        if (!CollectionUtils.isEmpty(lstDetDeclaraActual)) {
            for (Map<String, Object> detDeclaraActual : lstDetDeclaraActual) {
                keys = obtenerMapKey(detDeclaraActual, "NUM_CORREDOC", "NUM_SECSERIE");
                Map<String, Object> detDeclara = Utilidades.obtenerElemento(lstDetDeclara, keys);
                //amancilla PAS20155E220200035 que pasa si esta vacio jaja se vuelve loco el comparador                
                if (CollectionUtils.isEmpty(detDeclara))
                {
                	 Map<String, Object> serieBasePk = new HashMap();
                     serieBasePk.put("NUM_CORREDOC",detDeclaraActual.get("NUM_CORREDOC"));    
                     serieBasePk.put("NUM_SECSERIE", detDeclaraActual.get("NUM_SECSERIE"));
                     List series = (ArrayList)serieService.select(serieBasePk);
                     if (!CollectionUtils.isEmpty(series))
                     {
                    	 detDeclara = (Map)series.get(0);
                     }
                     
                }
                 //fin amancilla 
                
                
                lstCambiosDecla.addAll(obtenerCambiosMap(detDeclaraActual, detDeclara, "DET_DECLARA", keys));
                // datos dentro de la series
                // CONVENIO_SERIES
                List<Map<String, Object>> lstConvenioSerieActual = (List) detDeclaraActual.get("lstConvenioSerie");
                List<Map<String, Object>> lstConvenioSerie = (detDeclara != null && detDeclara.get("lstConvenioSerie") != null )? (List) detDeclara.get("lstConvenioSerie") : new ArrayList<Map<String, Object>>();
                if(lstConvenioSerie==null || CollectionUtils.isEmpty(lstConvenioSerie))
                {
                	lstConvenioSerie  = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.CONVENIO_SERIE);
                }

               //amancilla como quedoa asi se cambia if (!CollectionUtils.isEmpty(lstConvenioSerieActual) ||!CollectionUtils.isEmpty(lstConvenioSerie) ) {
                if (!CollectionUtils.isEmpty(lstConvenioSerieActual)) {
                    //List<Map<String, Object>> lstConvenioSerie = (detDeclara != null && detDeclara.get("lstConvenioSerie") != null )? (List) detDeclara.get("lstConvenioSerie") : new ArrayList<Map<String, Object>>();                    
                    //P34 AFMA Bug22814 lstCambiosDecla.addAll(obtenerCambiosList(lstConvenioSerieActual, lstConvenioSerie, "CONVENIO_SERIE", "NUM_CORREDOC", "NUM_SECSERIE", "COD_TIPCONVENIO", "COD_CONVENIO"));
                    lstCambiosDecla.addAll(obtenerCambiosList(lstConvenioSerieActual, lstConvenioSerie, "CONVENIO_SERIE", "NUM_CORREDOC", "NUM_SECSERIE", "COD_TIPCONVENIO","COD_CONVENIO"));
                }

                //det_adi_atpa


                Map adAtpaActual = (Map) detDeclaraActual.get("mapDetAdiAtpa");
                Map adAtpa       = (detDeclara != null && detDeclara.get("mapDetAdiAtpa") != null )? (Map) detDeclara.get("mapDetAdiAtpa") : new HashMap();
                if (!CollectionUtils.isEmpty(adAtpaActual)) {                   
                    lstCambiosDecla.addAll(obtenerCambiosMap(adAtpaActual, adAtpa, "DET_ADI_ATPA", keys));
                }

                // DOCU_PRECEDUA
                List<Map<String, Object>> lstDocuPreceDuaActual = (List) detDeclaraActual.get("lstDocuPreceDua");
                if (!CollectionUtils.isEmpty((List) detDeclaraActual.get("lstDocuPreceDua"))) {
                    List<Map<String, Object>> lstDocuPreceDua = (detDeclara!=null && detDeclara.get("lstDocuPreceDua") != null) ? (List) detDeclara.get("lstDocuPreceDua") : new ArrayList<Map<String, Object>>();
                    
                    lstCambiosDecla.addAll(obtenerCambiosList(lstDocuPreceDuaActual, lstDocuPreceDua, "DOCUPRECE_DUA", "NUM_CORREDOC", "NUM_SECSERIE", "NUM_DECLARACIONPRE", "ANN_PRESENPRE","COD_ADUANAPRE", "COD_REGIMENPRE", "NUM_SECSERIEPRE"));
                    //lstCambiosDecla.addAll(obtenerCambiosList(lstDocuPreceDuaActual, lstDocuPreceDua, "DOCUPRECE_DUA", "NUM_CORREDOC", "NUM_SECSERIE", "COD_ADUANAPRE", "COD_REGIMENPRE"));
                    //jenciso - Inicio cambios ceticos parte1
                    List<Map<String, Object>> lstDatoVehiculo = (ArrayList<Map<String,Object>>)detDeclaraActual.get("lstDatoVehiculo");
                    List<Map<String, Object>> lstDatoMontoGasto = (ArrayList<Map<String,Object>>)detDeclaraActual.get("lstDatoMontoGasto");
                    
                    if(!CollectionUtils.isEmpty(lstDatoVehiculo) ){
                    	List<Map<String, Object>> lstDatoVehiculoAnt = (detDeclara!=null && detDeclara.get("lstDatoVehiculo") != null) ? (ArrayList<Map<String, Object>>) detDeclara.get("lstDatoVehiculo") : new ArrayList<Map<String, Object>>();
                    	
                    	lstCambiosDecla.addAll(obtenerCambiosList(lstDatoVehiculo, lstDatoVehiculoAnt, "VEHI_CETICO", "NUM_CORREDOC","NUM_SECSERIE"));
                    }
                    
                    if(!CollectionUtils.isEmpty(lstDatoVehiculo) && !CollectionUtils.isEmpty(lstDatoMontoGasto)){
                    	List<Map<String, Object>> lstDatoMontoGastoAnt = (detDeclara!=null && detDeclara.get("lstDatoMontoGasto") != null) ? (ArrayList<Map<String, Object>>) detDeclara.get("lstDatoMontoGasto") : new ArrayList<Map<String, Object>>();
                    	List<Map<String, Object>> lstDatoMontoGastoAux = Utilidades.copiarLista((List)lstDatoMontoGasto);//para agregar los eliminado de la lista original
                    	lstDatoMontoGastoAux= agregaEliminadoAListaActual(lstDatoMontoGastoAux, lstDatoMontoGastoAnt, "MONTOGASTO", "NUM_CORREDOC","NUM_SECSERIE","COD_CPTOGASTOS");
                    	//lstCambiosDecla.addAll(obtenerCambiosList(lstDatoMontoGasto, lstDatoMontoGastoAnt, "MONTOGASTO", "NUM_CORREDOC","NUM_SECSERIE","COD_CPTOGASTOS"));
                    	lstCambiosDecla.addAll(obtenerCambiosList(lstDatoMontoGastoAux, lstDatoMontoGastoAnt, "MONTOGASTO", "NUM_CORREDOC","NUM_SECSERIE","COD_CPTOGASTOS"));
                    }
                    
                    //jenciso - Fin cambios ceticos parte1
                    
                    
                }

                // facturaSerie
                List<Map<String, Object>> lstFacturaSerieActual = (List) detDeclaraActual.get("lstFacturaSerie");
                if (!CollectionUtils.isEmpty(lstFacturaSerieActual)) {
                    List<Map<String, Object>> lstFacturaSerie = (detDeclara!=null && detDeclara.get("lstFacturaSerie") != null) ? (List) detDeclara.get("lstFacturaSerie") : new ArrayList<Map<String, Object>>();
                     //amancilla correccion pase35
                    if(CollectionUtils.isEmpty(lstFacturaSerie))
                    {
                      lstFacturaSerie  = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.FACTURA_SERIE);
                    }
                    lstCambiosDecla.addAll(obtenerCambiosList(lstFacturaSerieActual, lstFacturaSerie, "FORMA_FACTU", "NUM_CORREDOC", "NUM_SECFACT"));
                }
            
            //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
                //Verificamos si cambio el porcentaje de alcohol
                Map<String, Object> mpDetAdiICActual = new HashMap<String, Object>();
                mpDetAdiICActual.put("NUM_CORREDOC", detDeclaraActual.get("NUM_CORREDOC"));
                mpDetAdiICActual.put("NUM_SECSERIE", detDeclaraActual.get("NUM_SECSERIE"));
                mpDetAdiICActual.put("POR_ALCOHOL", detDeclaraActual.get("POR_ALCOHOL"));
                
                Map<String, Object> mpDetAdiIC = new HashMap<String, Object>();
                mpDetAdiIC.put("NUM_CORREDOC", detDeclara.get("NUM_CORREDOC"));
                mpDetAdiIC.put("NUM_SECSERIE", detDeclara.get("NUM_SECSERIE"));
                mpDetAdiIC.put("POR_ALCOHOL", detDeclara.get("POR_ALCOHOL"));
                
                lstCambiosDecla.addAll(obtenerCambiosMap(mpDetAdiICActual, mpDetAdiIC, "DET_ADI_IMPOCONSU", keys));
              //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
            
              //P46-PAS20155E410000032 INICIO
                if(detDeclara!= null && detDeclaraActual!=null){
	                if(detDeclara.get("COD_TIPREGUL")!= null && detDeclaraActual.get("COD_TIPREGUL")!= null){
		                if ((!"".equals(SunatStringUtils.trimNotNull((String)detDeclara.get("COD_TIPREGUL"))) || !"".equals(SunatStringUtils.trimNotNull((String)detDeclaraActual.get("COD_TIPREGUL")))) 
		                		&&  !SunatStringUtils.trimNotNull((String)detDeclaraActual.get("COD_TIPREGUL")).equals(SunatStringUtils.trimNotNull((String)detDeclara.get("COD_TIPREGUL")))) {
		                			 Map keyDetAdiImpoComsu = keys; 
		                        	 Map detAdiImpoComsuAct = new HashMap();
		                			 Map detAdiImpoComsuAnt = new HashMap();
		                        	 detAdiImpoComsuAct.put("COD_TIPREGUL", SunatStringUtils.trimNotNull((String)detDeclaraActual.get("COD_TIPREGUL")));
		                        	 detAdiImpoComsuAnt.put("COD_TIPREGUL", SunatStringUtils.trimNotNull((String)detDeclara.get("COD_TIPREGUL")));
		                        	lstCambiosDecla.addAll(obtenerCambiosMap(detAdiImpoComsuAct, detAdiImpoComsuAnt, "DET_ADI_IMPOCONSU", keyDetAdiImpoComsu));
		                }
	                }
                }
                //P46-PAS20155E410000032 FIN
            }
        }

        if (!CollectionUtils.isEmpty(lstSeriesItemActual)) {
            if(lstSeriesItem==null)
            {
              lstSeriesItem  = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.SERIES_ITEM);
              //se estan actualizando por referencia los datos en session
              param.put("lstSeriesItem",lstSeriesItem);
            }
            //no se debe mostrar datos de esta tabla no representa nada para el negocio
            //lstCambiosDecla.addAll(obtenerCambiosList(lstSeriesItemActual, lstSeriesItem, "SERIES_ITEM", "NUM_CORREDOC", "NUM_SECSERIE", "NUM_SECITEM"));
        }


        // FormBProveedor
        List<Map<String, Object>> lstFormBProveedorActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstFormBProveedor"); 
        List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapCabDeclara.get("lstFormBProveedor");
        if (!CollectionUtils.isEmpty(lstFormBProveedorActual)) {
            lstCambiosDecla.addAll(obtenerCambiosList(lstFormBProveedorActual, lstFormBProveedor, "FORMBPROVEEDOR", "num_secprove"));
        }
        //los participantes por cada proveedor

        if (!CollectionUtils.isEmpty(lstFormBProveedorActual))
        {
          for (Map<String, Object> mapProveedor : lstFormBProveedorActual)
          {
            Map<String, Object> fbKeys = new HashMap<String, Object>();
            fbKeys.put("num_corredoc", mapProveedor.get("num_corredoc"));
            fbKeys.put("num_secprove", mapProveedor.get("num_secprove"));
            Map mapProveedorAnt = Utilidades.obtenerElemento((ArrayList<Map<String, Object>>) lstFormBProveedor, fbKeys);

            if (mapProveedor.get("num_codsecprove")!=null
                && !StringUtils.isEmpty(mapProveedor.get("num_codsecprove").toString())
                && !CollectionUtils.isEmpty(mapProveedorAnt))
            {

              Map partic = new HashMap();
              Map particAnt = new HashMap();
              
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prv"));
              partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prv"));
              partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_prv"));
              partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_prv"));
              
              if(mapProveedor.get("num_fax_prv")!=null){
            	  partic.put("NUM_FAX", mapProveedor.get("num_fax_prv"));
            	  particAnt.put("NUM_FAX", mapProveedorAnt.get("num_fax_prv"));
              }
              if(mapProveedor.get("num_telefono_prv")!=null){
            	  partic.put("NUM_TELEFONO", mapProveedor.get("num_telefono_prv"));
            	  particAnt.put("NUM_TELEFONO", mapProveedorAnt.get("num_telefono_prv"));
            	  
              }
              if( mapProveedor.get("nom_paginaweb_prv")!=null){
            	  partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_prv"));
            	  particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_prv"));
              }
              if(mapProveedor.get("nom_email_prv")!=null){
            	  partic.put("NOM_EMAIL", mapProveedor.get("nom_email_prv"));
            	  particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_prv"));
              }
              
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_codsecprove"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prv"));
              particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prv"));
              particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_prv"));
              particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_prv"));

              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));

              lstCambiosDecla.addAll(obtenerCambiosMap(partic, particAnt, "PARTICIPANTE_DOC", key));
            }

            if (mapProveedor.get("num_secpartic_pim")!=null
                && !StringUtils.isEmpty(mapProveedor.get("num_secpartic_pim").toString())
                && !CollectionUtils.isEmpty(mapProveedorAnt))
            {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pim"));
              partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_pim"));
              partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_pim"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_pim"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pim"));
              particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pim"));
              particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pim"));

              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));

              lstCambiosDecla.addAll(obtenerCambiosMap(partic, particAnt, "PARTICIPANTE_DOC", key));
            }

            if (mapProveedor.get("num_secpartic_prl")!=null
                && !StringUtils.isEmpty(mapProveedor.get("num_secpartic_prl").toString())
                && !CollectionUtils.isEmpty(mapProveedorAnt))
            {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prl"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_prl"));
              //particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("num_secpartic_prl"));
              // Error de dedo
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prl"));

              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));

              lstCambiosDecla.addAll(obtenerCambiosMap(partic, particAnt, "PARTICIPANTE_DOC", key));
            }
            // Actualizamos al declarante
            if (mapProveedor.get("num_secdeclarante")!=null
                && !StringUtils.isEmpty(mapProveedor.get("num_secdeclarante").toString())
              && !CollectionUtils.isEmpty(mapProveedorAnt))
            {

              Map partic = new HashMap();
              Map particAnt = new HashMap();
              
              if(mapProveedor.get("nom_razonsocial_prd")!=null){
            	  partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prd"));
            	  particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prd"));
              }
              if(mapProveedor.get("cod_tipdoc_prd")!=null){
            	  partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_prd"));
            	  particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_prd"));
              }
              if(mapProveedor.get("num_docident_prd")!=null){
            	  partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_prd"));
            	  particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_prd"));
              }
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secdeclarante"));
              
              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));

              lstCambiosDecla.addAll(obtenerCambiosMap(partic, particAnt, "PARTICIPANTE_DOC", key));
            }
            //se completo el o estaba num_secintermediari y no entraba
            if (mapProveedor.get("num_secintermediario")!=null
                && !StringUtils.isEmpty(mapProveedor.get("num_secintermediario").toString())
              && !CollectionUtils.isEmpty(mapProveedorAnt))
            {

              Map partic = new HashMap();
              partic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario"));
              partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pri"));
              partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_pri"));
              partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_pri"));
              partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_pri"));
              partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_pri"));
              partic.put("NOM_EMAIL", mapProveedor.get("nom_email_pri"));


              Map particAnt = new HashMap();
              particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secintermediario"));
              particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pri"));
              particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_pri"));
              particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_pri"));
              particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_pri"));
              particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_pri"));
              particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_pri"));

              Map<String, Object> key = new HashMap<String, Object>();
              key.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario"));

              lstCambiosDecla.addAll(obtenerCambiosMap(partic, particAnt, "PARTICIPANTE_DOC", key));
            }


            Map condiciones   = mapProveedor.get("mapCondicionTransa")!=null?(HashMap) mapProveedor.get("mapCondicionTransa"):new HashMap();
            Map condicionesAnt = mapProveedorAnt.get("mapCondicionTransa") != null? (HashMap) mapProveedorAnt.get("mapCondicionTransa"): null;

            Object[] ctrNamesCond = condiciones.keySet().toArray();
            if (ctrNamesCond != null && ctrNamesCond.length > 0)
            {
              Map condUpd = new HashMap();
              condUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
              condUpd.put("num_secprove", mapProveedor.get("num_secprove"));

              for (int j = 0; j < ctrNamesCond.length; j++)
              {
                if (condicionesAnt == null
                    || condicionesAnt.get(ctrNamesCond[j].toString()) == null
                    || !condicionesAnt.get(ctrNamesCond[j].toString()).toString().trim().equals(condiciones.get(ctrNamesCond[j].toString()).toString().trim()))
                {
                  condUpd.put("cod_indtransaccion", ctrNamesCond[j].toString());
                  condUpd.put("ind_transaccion", condiciones.get(ctrNamesCond[j].toString()));

                  Map condUpdAnt = new HashMap();
                  condUpdAnt.put("ind_transaccion",(condicionesAnt != null ? condicionesAnt.get(ctrNamesCond[j].toString()) : null));
                  Map keyCond = new HashMap();
                  keyCond.put("num_corredoc", mapProveedor.get("num_corredoc"));
                  keyCond.put("num_secprove", mapProveedor.get("num_secprove"));
                  keyCond.put("cod_indtransaccion", ctrNamesCond[j].toString());

                  lstCambiosDecla.addAll(obtenerCambiosMap(condUpd, condUpdAnt, "CONDICION_TRANSA", keyCond));
                }
              }
            }

            // Actualizamos los montos
            Map montos    = mapProveedor.get("mapFormBMonto")!=null?(HashMap) mapProveedor.get("mapFormBMonto"): new HashMap();
            Map montosAnt = mapProveedorAnt.get("mapFormBMonto")!=null?(HashMap) mapProveedorAnt.get("mapFormBMonto"):null;
            Object[] ctrNamesMto = montos.keySet().toArray();
            if (ctrNamesMto != null && ctrNamesMto.length > 0)
            {
              Map montoUpd = new HashMap();
              montoUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
              montoUpd.put("num_secprove", mapProveedor.get("num_secprove"));
              for (int j = 0; j < ctrNamesMto.length; j++)
              {
                if (montosAnt == null
                    || montosAnt.get(ctrNamesMto[j].toString()) == null
                    || !montosAnt.get(ctrNamesMto[j].toString()).toString().trim().equals(montos.get(ctrNamesMto[j].toString()).toString().trim()))
                {
                  montoUpd.put("cod_monto", ctrNamesMto[j].toString());
                  montoUpd.put("mto_valor", montos.get(ctrNamesMto[j].toString()));

                  Map montoUpdAnt = new HashMap();
                  montoUpdAnt.put("mto_valor", (montosAnt != null ? montosAnt.get(ctrNamesMto[j].toString()) : null));

                  Map keyMonto = new HashMap();
                  keyMonto.put("num_corredoc", mapProveedor.get("num_corredoc"));
                  keyMonto.put("num_secprove", mapProveedor.get("num_secprove"));
                  keyMonto.put("cod_monto", ctrNamesMto[j].toString());

                  lstCambiosDecla.addAll(obtenerCambiosMap(montoUpd, montoUpdAnt, "FORMBMONTO", keyMonto));
                  }
              }
            }
          }
        }
        //P46-PAS20155E410000032 INICIO   indicador_dua  
        String[] lstIndicadores= {ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL};
        List<Map<String, Object>> lstIndicadorDuaActual = obtenerListaIndicadoresHabilitados((List<Map<String, Object>>) mapCabDeclaraActual.get("LIST_INDICADORES_DUA"),lstIndicadores);
        List<Map<String, Object>> lstIndicadorDuaInical = obtenerListaIndicadoresHabilitados((List<Map<String, Object>>) mapCabDeclara.get("LIST_INDICADORES_DUA"),lstIndicadores);
        if (!CollectionUtils.isEmpty(lstIndicadorDuaActual) && !CollectionUtils.isEmpty(lstIndicadorDuaInical)) {
            
        	 
        	 Map keyIndicadorDon = new HashMap();
        	 Map indDonacionActual = new HashMap();
        	 keyIndicadorDon.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
        	 // si se inactiva el indicador no se deberia considerar diferencia solo "inactivado", por eso se considera el inicial
        	 if(lstIndicadorDuaActual.get(0).get("IND_ACTIVO").toString().equals("0")){
        		 keyIndicadorDon.put("COD_INDICADOR", lstIndicadorDuaInical.get(0).get("COD_INDICADOR")); 
        		 indDonacionActual.put("COD_INDICADOR", lstIndicadorDuaInical.get(0).get("COD_INDICADOR"));
        	 }
        	 else {
        		 keyIndicadorDon.put("COD_INDICADOR", lstIndicadorDuaActual.get(0).get("COD_INDICADOR"));
        		 indDonacionActual.put("COD_INDICADOR", lstIndicadorDuaActual.get(0).get("COD_INDICADOR"));
        	 }
        	 //indDonacionActual.put("IND_ACTIVO", lstIndicadorDuaActual.get(0).get("IND_ACTIVO"));
        	 Map indDonacionAnt = new HashMap();
        	 indDonacionAnt.put("COD_INDICADOR", lstIndicadorDuaInical.get(0).get("COD_INDICADOR"));
        	 //indDonacionAnt.put("IND_ACTIVO", lstIndicadorDuaInical.get(0).get("IND_ACTIVO"));
        	 lstCambiosDecla.addAll(obtenerCambiosMap(indDonacionActual, indDonacionAnt, "INDICADOR_DUA", keyIndicadorDon));
		}
      //P46-PAS20155E410000032  fin 


        // DocAutAsociado
        List<Map<String, Object>> lstDocAutAsociadoActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstDocAutAsociado");
        List<Map<String, Object>> lstDocAutAsociado = (List<Map<String, Object>>) mapCabDeclara.get("lstDocAutAsociado");
        if (!CollectionUtils.isEmpty(lstDocAutAsociadoActual)) {
            lstCambiosDecla.addAll(obtenerCambiosList(lstDocAutAsociadoActual, lstDocAutAsociado, "DOCAUT_ASOCIADO", "NUM_CORREDOC", "NUM_SECDOC", "COD_TIPOPER"));
        }
        // DetAutorizacion
        List<Map<String, Object>> lstDetAutorizacionActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstDetAutorizacion");
        List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) mapCabDeclara.get("lstDetAutorizacion");
        if (!CollectionUtils.isEmpty(lstDetAutorizacionActual)) {
            lstCambiosDecla.addAll(obtenerCambiosList(lstDetAutorizacionActual, lstDetAutorizacion, "DET_AUTORIZACION", "NUM_CORREDOC", "NUM_SECDOC", "COD_TIPOPER", "NUM_SECSERIE"));
        }
        // cabCertiOrigen
        List<Map<String, Object>> lstCabCertiOrigenActual = (List<Map<String, Object>>) mapCabDeclaraActual.get("lstCabCertiOrigen");
        List<Map<String, Object>> lstCabCertiOrigen = (List<Map<String, Object>>) mapCabDeclara.get("lstCabCertiOrigen");
        if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual)) {
            lstCambiosDecla.addAll(obtenerCambiosList(lstCabCertiOrigenActual, lstCabCertiOrigen, "CAB_CERTIORIGEN", "NUM_CORREDOC", "NUM_SECDOC", "COD_TIPOPER"));
        }
        // ComproBPago
        if (!CollectionUtils.isEmpty(lstFormBProveedorActual)) {
            for (Map<String, Object> formBProveedorActual : lstFormBProveedorActual) {
                keys = obtenerMapKey(formBProveedorActual, "num_secprove");
                Map<String, Object> formBProveedor = Utilidades.obtenerElemento(lstFormBProveedor, keys);
                List<Map<String, Object>> lstComproBPagoActual = (List<Map<String, Object>>) formBProveedorActual.get("lstComproBPago");
                List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) formBProveedor.get("lstComproBPago");
                if (!CollectionUtils.isEmpty(lstComproBPagoActual)) {
                    if(lstComproBPago == null)
                    {
                      lstComproBPago = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.COMPROB_PAGO);
                      //se estan actualizando por referencia los datos en session
                      formBProveedor.put("lstComproBPago", lstComproBPago);
                    }
                    lstCambiosDecla.addAll(obtenerCambiosList(lstComproBPagoActual, lstComproBPago, "COMPROB_PAGO", "num_secfact"));
                }
            }
        }
        // itemFactura
        if (!CollectionUtils.isEmpty(lstFormBProveedorActual)) {
            for (Map<String, Object> formBProveedorActual : lstFormBProveedorActual) {
                keys = new HashMap<String, Object>();
                // keys.put("num_corredoc",
                // formBProveedorActual.get("num_corredoc"));
                keys.put("num_secprove", formBProveedorActual.get("num_secprove"));
                Map<String, Object> formBProveedor = Utilidades.obtenerElemento(lstFormBProveedor, keys);

                List<Map<String, Object>> lstComproBPagoActual = (List<Map<String, Object>>) formBProveedorActual.get("lstComproBPago");
                List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>) formBProveedor.get("lstComproBPago");
                if (!CollectionUtils.isEmpty(lstComproBPagoActual)) {
                    for (Map<String, Object> comproBPagoActual : lstComproBPagoActual) {
                        keys = obtenerMapKey(comproBPagoActual, "num_secfact");
                        Map<String, Object> comproBPago = Utilidades.obtenerElemento(lstComproBPago, keys);

                        List<Map<String, Object>> lstItemFacturaActual = (List<Map<String, Object>>) comproBPagoActual.get("lstItemFactura");
                        List<Map<String, Object>> lstItemFactura = (List<Map<String, Object>>) comproBPago.get("lstItemFactura");
                        if (!CollectionUtils.isEmpty(lstItemFacturaActual)) {

                            if(lstItemFactura==null)
                            {
                              lstItemFactura = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.ITEMFACTURA);
                            //GGRANADOS_RECTI INI
                              //se estan actualizando por referencia los datos en session
                              comproBPago.put("lstItemFactura", lstItemFactura);
                            //GGRANADOS_RECTI FIN
                           }
                            lstCambiosDecla.addAll(obtenerCambiosList(lstItemFacturaActual, lstItemFactura, "ITEMFACTURA", "NUM_SECITEM"));

                           //observaciones tipo 03 -OBSERVACION DEL ITEM DEL FORMATO B
                            for (Map<String, Object> mapItem : lstItemFacturaActual)
                            {

                            	/****Inicio cambios del PAS20165E220200055**/ 
                            	Map keysDescrMin= new HashMap();
                            	keysDescrMin.put("NUM_SECITEM", mapItem.get("NUM_SECITEM"));
                            	keysDescrMin.put("NUM_SECFACT", mapItem.get("NUM_SECFACT"));         
                            	keysDescrMin.put("NUM_SECPROVE", mapItem.get("NUM_SECPROVE"));                   	
                            	Map<String, Object> mapItemAnt = Utilidades.obtenerElemento(lstItemFactura, keysDescrMin);
                            	 List<Map<String, Object>> lstDecrMinimaActual = (List<Map<String, Object>>) mapItem.get("lstDecrMinima");
                            	 List<Map<String, Object>> lstDecrMinima = new ArrayList<Map<String,Object>>();
                                if(!CollectionUtils.isEmpty(mapItemAnt)){
                            	  lstDecrMinima = (List<Map<String, Object>>) mapItemAnt.get("lstDecrMinima");
                                }
                                 if (!CollectionUtils.isEmpty(lstDecrMinimaActual)) {
                                	 for(Map<String, Object> mapDescrMinimaActual : lstDecrMinimaActual){
                                			Map keysMin= new HashMap();
                                			keysMin.put("NUM_SECITEM", mapItem.get("NUM_SECITEM"));
                                			//keysMin.put("COD_MERCANCIA", mapItem.get("COD_TIPDESCRMIN").equals(" ")?"**":mapItem.get("COD_TIPDESCRMIN"));
                                			keysMin.put("COD_MERCANCIA", (mapItem.get("COD_TIPDESCRMIN")==null || mapItem.get("COD_TIPDESCRMIN").equals(" "))?"**":mapItem.get("COD_TIPDESCRMIN"));//PAS20165E220200064    
                                			keysMin.put("COD_TIPDESC", mapDescrMinimaActual.get("COD_TIPDESC"));
                                		 
                                		 if(lstDecrMinima == null || CollectionUtils.isEmpty(lstDecrMinima)){
                                			 lstDecrMinima = (List<Map<String, Object>>)diligenciaService.cargarDatosInicialesBDtoMap(busquedaDua,EnumTablaModel.FORMBITEMDESCRI);
                                             //se estan actualizando por referencia los datos en session
                                      		 //region amancillaa SIGESI INC 2016-091039
                                      		    //mapItemAnt.put("lstDecrMinima", lstDecrMinima);
                                               if(!CollectionUtils.isEmpty(mapItemAnt)){
                                                   mapItemAnt.put("lstDecrMinima", lstDecrMinima);
                                               }
                                      		    
                                      		  //endregion amancillaa
                                		 }
                                		 
                                		 Map<String, Object> mapDescrMinAnt = Utilidades.obtenerElemento(lstDecrMinima, keysMin);
                                		 
                             			 keysMin.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));      
                                		 lstCambiosDecla.addAll(obtenerCambiosMap(mapDescrMinimaActual, mapDescrMinAnt, "FORMBITEMDESCRI", keysMin));
                                		 
                                	 }
                                }                                
                                /****Fin cambios del PAS20165E220200055**/
                                 
                              String observacionItemFacturaActual = mapItem.get("OBSERVACION") != null ? mapItem.get("OBSERVACION").toString() : "";
                              if (!StringUtils.isEmpty(observacionItemFacturaActual))
                              {

                                Map keysitem = new HashMap();
                                keysitem.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));
                                keysitem.put("NUM_SECITEM", mapItem.get("NUM_SECITEM"));

                                Map mapItemOld = Utilidades.obtenerElemento(lstItemFactura, keysitem);
                                String observacionItemFacturaOld = (mapItemOld != null && mapItemOld.get("OBSERVACION") != null) ? mapItemOld.get("OBSERVACION").toString() : "";
                                if(SunatStringUtils.isEmpty(observacionItemFacturaOld))
                                {
                                  keysitem.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
                                 if(mapItem.get("NUM_SECOBS")!=null){ keysitem.put("NUM_SECOBS", mapItem.get("NUM_SECOBS"));}
                                  List<Map<String,Object>> obsItemBD  = observacionDAO.select(keysitem);
                                  if (!CollectionUtils.isEmpty(obsItemBD))
                                  {
                                    observacionItemFacturaOld = obsItemBD.get(0)!=null && obsItemBD.get(0).get("OBS_OBS")!=null?obsItemBD.get(0).get("OBS_OBS").toString():"";
                                  }else{// cuando no existe en bd la observacion se setea el num_secobs con un numero por ser nuevo la observacion
                                	// REQ 2016-012074 mordonezl
                                      Map keysitem1 = new HashMap(); 
                                      keysitem1.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));
                                       // keysitem1.put("NUM_SECITEM", mapItem.get("NUM_SECITEM"));
                                        keysitem1.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
                                    int numsecobs= observacionDAO.getMaxNumSecObs(keysitem1) + 1 ;
                                    mapItem.put("NUM_SECOBS",numsecobs);
                                  }
                                }

                                Map<String, Object> keyObservacion = new HashMap<String, Object>();
                                keyObservacion.put("NUM_CORREDOC", mapItem.get("NUM_CORREDOC"));
                                keyObservacion.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
                                keyObservacion.put("NUM_SECOBS", mapItem.get("NUM_SECOBS"));

                                Map<String, Object> mapObservacionActual = new HashMap<String, Object>(keyObservacion);
                                Map<String, Object> mapObservacion = new HashMap<String, Object>(keyObservacion);

                                mapObservacionActual.put("OBS_OBS", observacionItemFacturaActual);
                                mapObservacion.put("OBS_OBS", observacionItemFacturaOld);
                                lstCambiosDecla.addAll(obtenerCambiosMap(mapObservacionActual, mapObservacion, "OBSERVACION", keyObservacion));
                              }
                            }
                        }
                    }
                }
            }
        }

        return lstCambiosDecla;
    }
    //ini P46-PAS20155E410000032
    private List<Map<String, Object>> obtenerListaIndicadoresHabilitados(List<Map<String, Object>>  lstIndicadores, String[] lstIndicadoresHabilitados){
    	List<Map<String, Object>> lstIndicadorFiltrado=null;
    	if(!CollectionUtils.isEmpty(lstIndicadores)) {
	    	for (Map<String, Object> indicador : lstIndicadores) {
	    		if( ArrayUtils.contains(lstIndicadoresHabilitados, indicador.get("COD_INDICADOR").toString())) { 
	    			lstIndicadorFiltrado = new ArrayList<Map<String,Object>>();
	    			lstIndicadorFiltrado.add(indicador);
	    		}
	    	}
    	}
    	return lstIndicadorFiltrado;
	}
    //fin P46-PAS20155E410000032


    /**
     * Permite obtener un mapa con los Keys y sus valores a partir de N
     * parametros String que contienen los nombres de los keys.
     *
     * @param mapaActual
     * @return
     */
    private Map<String, Object> obtenerMapKey(Map<String, Object> mapaActual, String... key){
        Map<String, Object> keys;
        keys = new HashMap<String, Object>();
        for (String clave : key) {
            keys.put(clave, mapaActual.get(clave));
        }
        return keys;
    }



    /**
     * Permite obtener los cambios de dos listas segun los keys. Ademas obtiene
     * las descripciones a partir de su nombre de Tabla.
     *
     * @param lstActual
     * @param lstHistorico
     * @param nombreTabla
     * @param key
     */
    private List<DatoModificadoBean> obtenerCambiosList(List<Map<String, Object>> lstActual, List<Map<String, Object>>
    lstHistorico, String nombreTabla, String... key){

        Map<String, Object> keysParaBuscar;
        Map<String, Object> keysOriginal;
        
        String[] keyParaBuscar = key;
        ArrayList<String> lstKeys = new ArrayList<String>();
        
        

        List<DatoModificadoBean> lstCambios = new ArrayList<DatoModificadoBean>();
        //amancilla casos especiales
        
        if(Constantes.COD_TABLA_CONVENIO_SERIE_DESC.equals(nombreTabla)){
        	
        	 for (String clave : key) {
        		//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION  DE OFicio
                 if(ArrayUtils.contains(new String[] { "NUM_CORREDOC", "NUM_SECSERIE", "COD_TIPCONVENIO","COD_CONVENIO"},clave)){
                	 lstKeys.add(clave);
                 }
             }
       
        	 keyParaBuscar = 	lstKeys.toArray(new String[lstKeys.size()]);
        }else if(Constantes.COD_TABLA_DOCUPRECE_DUA_DESC.equals(nombreTabla)){
        	
       	 for (String clave : key) {
             if(ArrayUtils.contains(new String[] { "NUM_CORREDOC", "NUM_SECSERIE", "NUM_DECLARACIONPRE","ANN_PRESENPRE","COD_REGIMENPRE", "NUM_SECSERIEPRE"},clave)){
            	 lstKeys.add(clave);
             }
         }       	 
       	  keyParaBuscar = 	lstKeys.toArray(new String[lstKeys.size()]);
        }
        	

        for (Map<String, Object> mapActual : lstActual) {
            //amancilla keys = obtenerMapKey(mapActual, key);
        	keysParaBuscar = obtenerMapKey(mapActual, keyParaBuscar);
        	keysOriginal = obtenerMapKey(mapActual, key);
            Map<String, Object> mapAntes = Utilidades.obtenerElemento(lstHistorico, keysParaBuscar);
            lstCambios.addAll(obtenerCambiosMap(mapActual, mapAntes, nombreTabla, keysOriginal));
        }
        return lstCambios;
    }



    /**
     * Permite Obtener los cambios de un mapa actual con respecto a un mapa
     * historico
     *
     * @param mapActual
     * @param mapHistorico
     * @param nombreTabla
     * @param keys
     * @return
     */
    private List<DatoModificadoBean> obtenerCambiosMap(Map<String, Object> mapActual,
            Map<String, Object> mapHistorico, String nombreTabla, Map<String, Object> keys){

        List<DatoModificadoBean> lstCambios = (List)rectificacionService.obtenerDatosModificadosPorElUsuario(mapActual, mapHistorico, nombreTabla, keys);
        if (!CollectionUtils.isEmpty(lstCambios)) {
            return lstCambios;
        }
        return new ArrayList<DatoModificadoBean>();
    }
    
    /**
     * Agrega los registros de la lista antigua que fueron eliminados y que no se encuentren en la nueva lista
     * para que salga en el comparador como eliminado
     * @author jenciso
     * @param lstActual
     * @param lstHistorico
     * @param nombreTabla
     * @param key
     * @return
     */
    private List<Map<String, Object>> agregaEliminadoAListaActual(List<Map<String, Object>> lstActual, List<Map<String, Object>> lstHistorico, String nombreTabla, String... key){
    	
    	if(!CollectionUtils.isEmpty(lstHistorico)){
    		for(Map<String,Object> mapHistorico: lstHistorico){ 
    			Map<String,Object> mapKeys = obtenerMapKey(mapHistorico,key);
	      	  	Map<String,Object> mapEncontrado = Utilidades.obtenerElemento(lstActual, mapKeys);
	      	  	if(mapEncontrado==null){
	      	  		//si no fue encontrado se agrega como elimnado en la lista actual
	      	  		Map<String,Object> mapEliminado = Utilidades.copiarMapa(mapHistorico);
	      	  		mapEliminado.put("IND_DEL", Constantes.IND_ELIMINADO);
	      	  		setearDefaultsByTabla(mapEliminado, nombreTabla );
	      	  		lstActual.add(mapEliminado);            		  
	      	  	}
      	    }
    	}
    	
    	return lstActual;
    }
    
    private void setearDefaultsByTabla(Map<String,Object> mapEliminado,String nombreTabla){
    	if(nombreTabla.equals("MONTOGASTO")){
    		mapEliminado.put("MTO_GASTO", " ");
    	}
    }
    
    //P34: JAZB - INICIO
    public Boolean tieneRectificacionOficioEnProceso(String numCorreDocDua) throws ServiceException{
    	/**  inicio P34 Obs:Mancilla 11/03/2015 **/
    	Boolean bRspta= false;
    	Map<String, Object> mapPk= new HashMap<String, Object>();
    	mapPk.put("num_corredoc", numCorreDocDua);
    	mapPk.put("cod_indicador", "26");
    	mapPk.put("ind_activo", "1");
    	//log.debug("enviando parametros: "+mapPk);
    	List<DatoIndicadores> listIndicadorDuaEnProceso = indicadorDuaDAO.listIndicadorDeclaracionEnProcesoDeRectificacionDeOficio(mapPk);
    	//log.debug("longitud de listIndicadorDuaEnProceso: "+listIndicadorDuaEnProceso.size());
    	if ( listIndicadorDuaEnProceso.size() > 0  ){   		
    		bRspta=true;
    	}
        //TODO: AMANCILLA esto no debe de ir return bRspta;
    	return bRspta;
        //return true;
    	/**  fin P34 Obs:Mancilla  **/
       
    }
   //P34: JAZB - FIN
 public DisposicionMercanciaService getDisposicionMercanciaService() {
    	return disposicionMercanciaService;
    }
    public void setDisposicionMercanciaService(
    		DisposicionMercanciaService disposicionMercanciaService) {
    	this.disposicionMercanciaService = disposicionMercanciaService;
     }
}

