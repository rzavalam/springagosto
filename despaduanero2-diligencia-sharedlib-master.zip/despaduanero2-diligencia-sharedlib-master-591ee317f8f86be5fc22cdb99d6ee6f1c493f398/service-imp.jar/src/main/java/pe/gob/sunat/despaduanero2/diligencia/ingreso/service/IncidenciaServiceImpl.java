package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_ADUANA_CENTRAL;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades.toLong;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.axis.utils.JavaUtils;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.asignacion.util.ListaUtil;

import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.NandTasa;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TasadumpDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SerieIncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EventoIncidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.model.MovLiqdilig;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetIncidenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.InciEventoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.SoliSubsanacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;


/**
 * The Class IncidenciaServiceImpl.
 */
@SuppressWarnings({ "rawtypes" })
public class IncidenciaServiceImpl implements IncidenciaService
{

  protected final Log          log = LogFactory.getLog(getClass());
	private InciEventoDAO inciEventoDAO;
	private DetIncidenciaDAO detIncidenciaDAO;
	private CatalogoAyudaService catalogoAyudaService;
	private SoliSubsanacionDAO soliSubsanacionDAO;  // RIN13
	// RIN13-SWF
	private LiquidaDeclaracionService liquidaDeclaracionService;
	// RIN13-SWF
	private SoporteComparadorService soporteComparadorService;
	private SoporteService soporteService;
	private FabricaDeServicios fabricaDeServicios;

  /**
   * {@inheritDoc}
   */
  public List<IncidenciaBean> asignarIncidencia(IncidenciaBean incidenciaBean) throws ServiceException
  {
    List<IncidenciaBean> incidenciaList = new ArrayList<IncidenciaBean>();
    List<Map<String, String>> catalogoList = catalogoAyudaService.getElementosCat("336");
    //rtineo mejoras,
    Map variablesIngreso = new HashMap<String,Object>();
    List<Map<String, String>> inciEventoList = (List<Map<String, String>>) inciEventoDAO.getInciEventoList(null);
    variablesIngreso.put("inciEventoList", inciEventoList);
    List<Map<String, Object>> detActualList = incidenciaBean.getDetActualList();
    Map<String,List<Map<String,Object>>> mapActualList = new HashMap<String, List<Map<String,Object>>>();
    if(detActualList != null){
        for(Map<String, Object> mapTmp : detActualList){
        	String identificador =  Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(mapTmp, "NUM_SECSERIE"));
        	List<Map<String,Object>> lstTmp = mapActualList.get(identificador);
        	if(lstTmp == null){
        		lstTmp = new ArrayList<Map<String,Object>>();
        		mapActualList.put(identificador, lstTmp);
        	}
        	lstTmp.add(mapTmp);
        }
    }
    variablesIngreso.put("mapActualList", mapActualList);
    //fin mejoras
    int numSecuencia = 1;
    for (Map<String, String> catalogoMap : catalogoList)
    {
      IncidenciaBean incidenciaView = new IncidenciaBean();
      incidenciaView.setNum_secuencia(numSecuencia++);
      incidenciaView.setCod_incidencia(catalogoMap.get("cod_datacat"));
      incidenciaView.setDes_adicional(catalogoMap.get("des_corta"));
      incidenciaView.setItemsList(new ArrayList<String>());
      incidenciaView.setItemsList(generarIncidencias(catalogoMap, incidenciaBean, variablesIngreso));
      incidenciaView.setFlagIncidencia(incidenciaBean.getFlagIncidencia());
      incidenciaList.add(incidenciaView);
    }
    return incidenciaList;
  }

  //rtineo mejoras, sobrecargamos el metodo
  private List<String> generarIncidencias(Map<String, String> catalogoMap, IncidenciaBean incidenciaBean){
	  return generarIncidencias(catalogoMap, incidenciaBean, null);
  }
  /**
   * Generar incidencias.
   *
   * @param catalogoMap
   *          the catalogo map
   * @param incidenciaBean
   *          the incidencia bean
   * @return the list
   */
  private List<String> generarIncidencias(Map<String, String> catalogoMap, IncidenciaBean incidenciaBean, Map<String,Object> variablesIngreso)
  {
    List<String> itemList = new ArrayList<String>();
    //rtineo mejoras, si va se realizo la consulta evitar conectar ala base de datos
    List<Map<String, String>> inciEventoList = new ArrayList<Map<String, String>>();
    if(variablesIngreso != null){
    	inciEventoList = (List<Map<String, String>>)variablesIngreso.get("inciEventoList");
    }else{
    	//continua con metodo anterior
    	inciEventoList = (List<Map<String, String>>) inciEventoDAO.getInciEventoList(null);
    }
    //rtineo mejoras, fin
    
    String nom_campo;
    String valAnterior;
    String valActual;
    boolean hayCambio;
    Map<String, Object> cabAnteriorMap = incidenciaBean.getCabAnteriorMap();
    Map<String, Object> cabActualMap = incidenciaBean.getCabActualMap();
    List<Map<String, Object>> detAnteriorList = incidenciaBean.getDetAnteriorList();
    List<Map<String, Object>> detActualList = incidenciaBean.getDetActualList();
    List<Map<String, Object>> detActualListTmp = detActualList;
    String serieAnterior;
    String serieActual;
    incidenciaBean.setFlagIncidencia(false);

    for (Map<String, String> inciEventoMap : inciEventoList)
    {
      if (catalogoMap.get("cod_datacat").equals(inciEventoMap.get("COD_INCIDENCIA")))
      {
        nom_campo = inciEventoMap.get("NOM_CAMPO");
        valAnterior = "";
        valActual = "";
        if (incidenciaBean.getEntidadMaestro().equalsIgnoreCase(inciEventoMap.get("NOM_TABLA")))
        {
          valAnterior = Utilidades.obtenerCadenaDesdeMapa(cabAnteriorMap, nom_campo);
          valActual = Utilidades.obtenerCadenaDesdeMapa(cabActualMap, nom_campo);

          if (Utilidades.esNumerico(valAnterior) && Utilidades.esNumerico(valActual))
          {
            hayCambio = !(new Double(valAnterior).equals(new Double(valActual)));
          }
          else
          {
            hayCambio = !valAnterior.trim().equals(valActual.trim());
          }

          incidenciaBean.setFlagIncidencia(hayCambio);
        }
        else if (incidenciaBean.getEntidadDetalle().equalsIgnoreCase(inciEventoMap.get("NOM_TABLA")))
        {
          if (detAnteriorList != null && detActualList != null)
          {
            for (Map<String, Object> detAnteriorMap : detAnteriorList)
            {
              //rtineo mejoras, movido de abajo para evitar el calculo innecesario
              serieAnterior = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(detAnteriorMap, "NUM_SECSERIE"));
              if(variablesIngreso != null){
            	  Map<String,List<Map<String,Object>>> mapActualList = (Map<String,List<Map<String,Object>>>)variablesIngreso.get("mapActualList");
            	  detActualListTmp = mapActualList.get(serieAnterior);
              } 
              //rtineo fin, mejoras
              
              for (Map<String, Object> detActualMap : detActualListTmp)
              {
                serieActual = Utilidades.crearCadenaDesdeObjeto(Utilidades.obtenerObjetoDesdeMapa(detActualMap, "NUM_SECSERIE"));
            	
                if (serieAnterior.equals(serieActual))
                {
                  valAnterior = Utilidades.obtenerCadenaDesdeMapa(detAnteriorMap, nom_campo);
                  valActual = Utilidades.obtenerCadenaDesdeMapa(detActualMap, nom_campo);

                  if (Utilidades.esNumerico(valAnterior) && Utilidades.esNumerico(valActual))
                  {
                    hayCambio = !(new Double(valAnterior).equals(new Double(valActual)));
                  }
                  else
                  {
                    hayCambio = !valAnterior.trim().equals(valActual.trim());
                  }

                  if (hayCambio)
                  {
                    if (!itemList.contains(serieActual))
                      itemList.add(serieActual);
                  }
                  break;
                }
              }
            }
          }
        }
      }
    }
    return itemList;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerListMapIncidencias(
      List<IncidenciaBean> lstIncidencias,
      String sNumCorredoc,
      String sCodTipoDiligencia)
  {
    List<Map<String, Object>> lstIncid = new ArrayList<Map<String,Object>>();
    Map<String, Object> incid;
    for (IncidenciaBean incidBean : lstIncidencias)
    {
      if (incidBean.getFlagIncidencia())
      {
        incid = new HashMap<String, Object>();
        incid.put("NUM_CORREDOC", sNumCorredoc);
        incid.put("COD_TIPDILIGENCIA", sCodTipoDiligencia);

        incid.put("NUM_SECINCID", incidBean.getNum_secuencia());
        incid.put("COD_INCIDENCIA", incidBean.getCod_incidencia());
        incid.put("MTO_ACTUAL", incidBean.getVal_actual());
        incid.put("MTO_CORREGIDO", incidBean.getVal_anterior());

        incid.put("DES_ADICIONAL", incidBean.getDes_adicional());
        incid.put("DES_TABLA", incidBean.getDes_tabla());
        incid.put("DES_CAMPO", incidBean.getDes_campo());
        incid.put("VAL_CONDICION", incidBean.getVal_condicion());
        incid.put("NOM_CAMPO_CONDI", incidBean.getNom_campo_condi());
        incid.put("ITEMS_LIST", incidBean.getItemsList());
        incid.put("CAB_ANTERIOR_MAP", incidBean.getCabAnteriorMap());
        incid.put("CAB_ACTUAL_MAP", incidBean.getCabActualMap());
        incid.put("DET_ANTERIOR_LIST", incidBean.getDetAnteriorList());
        incid.put("DET_ACTUAL_LIST", incidBean.getDetActualList());
        incid.put("ENTIDAD_MAESTRO", incidBean.getEntidadMaestro());
        incid.put("ENTIDAD_DETALLE", incidBean.getEntidadDetalle());
        incid.put("FLAG_INICIDENCIA", incidBean.getFlagIncidencia());

        lstIncid.add(incid);
      }
    }
    return lstIncid;
  }




  /**
   * Metodo que nos permite obtener todas las incidencias de una determinada
   * diligencia.
   */
  public List obtenerIncidencias(Map<String, String> paramsDiligencia)
      throws ServiceException
  {
    List<Map<String, Object>> lista = null;
    try
    {
      lista = detIncidenciaDAO.findByDiligencia(paramsDiligencia);

      for (Map<String, Object> mapaIncidencias : lista)
      {
        mapaIncidencias.put("DESC",
            this.catalogoAyudaService.getDescripcionDataCatalogo("336", (String) mapaIncidencias.get("CODIGO")));
      }

    }
    catch (Exception e)
    {
      log.error(this.toString().concat(" obtenerIncidencias- ERROR: ").concat(e.getMessage()));
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

  public void insert(Map<String, Object> paramsIncidencia)
      throws ServiceException
  {
    detIncidenciaDAO.insert(paramsIncidencia);
  }
  
  /**
   * juazor RIN13
   * @param listAntigua
   * @param listNueva
   * @return
   */
  
  public List<Map<String,Object>> compararListMap(List<Map<String,Object>> listAntigua, List<Map<String,Object>> listNueva) {

	  List<Map<String,Object>> listaComparada = new ArrayList<Map<String,Object>>();
	  Map<String, Object> mapComparado = new HashMap<String, Object>();
	  
	  if (listAntigua.size() == listNueva.size() 
			  && ((Map<String, Object>) listAntigua).keySet().equals(((Map<String, Object>) listNueva).keySet())) {
		  
		   for (Map<String, Object> lista1 : listNueva) {
              for (Map<String, Object> lista2 : listAntigua) {
                  
            	  if (lista1.keySet().equals(lista2.keySet()) && !(lista2.get("monto").equals(lista1.get("monto")))) {
            		  mapComparado.put("numCorredoc",1);
            		  mapComparado.put("nombreCampo",1);
            		  mapComparado.put("valorNuevo",1);
            		  mapComparado.put("numSerie",1);
            		  mapComparado.put("nombreCampo",1);
            		  mapComparado.put("indicador",1);
            		  listaComparada.add(mapComparado);           		  
            		  }
            	  
              }//fin for1
          }//fin for2
	  }//fin if
 
	  return listaComparada; 

  }//fin compararListMap
  
  
  
  
  
     // RIN13-SWF
    public List<Incidencia> obtenerIncidenciaAutomatica(Map<String,Object> datos){

        Map mapDeclaracionActual = (HashMap)datos.get("declaracionActual");

        MovCabliqdilig movCabliqdilig = (MovCabliqdilig) datos.get("movCabliqdilig");

                
        Long numCorredoc = new Long(mapDeclaracionActual.get("NUM_CORREDOC").toString());
        
        List<SerieIncidenciaBean> seriesBean = new ArrayList<SerieIncidenciaBean>();


        if("true".equals(datos.get("tieneIncidencia").toString())){
        	seriesBean= liquidaDeclaracionService.obtenerSeriesIncidenciaTributaria(numCorredoc, movCabliqdilig);	
        }else{
        	
        	List<Map> listDetDeclaraActual = (ArrayList)datos.get("lstDetDeclaraActual");      
        	 SerieIncidenciaBean serieBean;
        	 for(Map serie: listDetDeclaraActual){

                 serieBean = new SerieIncidenciaBean();           
                 serieBean.registrarInciTrib(false);                                                        
                 Long numSecSerie = Utilidades.toLong(serie.get("NUM_SECSERIE").toString());
                 serieBean.setNunmSecSerie(numSecSerie);
                 seriesBean.add(serieBean);
               }         
        }
        

      return ejecutarEventos(seriesBean,datos);

    }

     // RIN13-SWF
    public List<Incidencia> obtenerIncidenciaManual(){

        List<Incidencia> incidenciasAutomaticas = new ArrayList<Incidencia>();


        return incidenciasAutomaticas;

    }

// RIN13-SWF
private List<Incidencia> ejecutarEventos(List<SerieIncidenciaBean> seriesBean, Map<String,Object> datos) {


        List<Incidencia> automaticas = new ArrayList<Incidencia>();
        Map<String,Object> tmpMap=new HashMap<String,Object>();//wtaco-optmizacion
        if(CollectionUtils.isNotEmpty(seriesBean)){
            List<EventoIncidencia> eventos = inciEventoDAO.getLstInciEvento();

                  for(EventoIncidencia evento: eventos)
                  {
                	  //wtaco-optimizacion indicador para recorrer 1 vez por evento.
                	  tmpMap.put("indRecti",true);
                      //origen de la regla y que la regla sera del mismo tipo
	              if(evento.getPrioridadEvento()==0) {

	            	  String sinonimoTabla =   evento.getNombreTabla();
	              	  String campo =   evento.getNombreCampo();
	            	  Incidencia incidencia;
	            	  Map mapDeclaracionActual = (HashMap)datos.get("declaracionActual");
            	      Map mapDeclaracion       = (HashMap)datos.get("declaracion");
                      datos.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399	
	            	  //evalua las series y datos dependencientes a las series
	            	  for(SerieIncidenciaBean serie:seriesBean)
	                  {          
	                      if(evaluarEvento(serie, evento, datos,tmpMap)){
	                          incidencia = new Incidencia();
	                          incidencia.setCodIncidencia(evento.getCodIncidencia());
	                          incidencia.setNumeroSerie(serie.getNunmSecSerie().intValue());
	                          if(noEstaRegistrado(automaticas,incidencia)){
	                        	  automaticas.add(incidencia);  
	                          }
	                          
                          }
                      }

	            	 if("CAB_DECLARA".equals(sinonimoTabla)){
	            		            	        
	                      Map mapCamposDiferentes = soporteComparadorService.comparaMap(mapDeclaracionActual, mapDeclaracion, EnumTablaModel.CAB_DECLARA); 
	                      mapCamposDiferentes.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399


                          /*P34 AFMA INICIO bUG 23633 BUEN BUG ASI DA GUSTO RESOLVER BUG AUNQ AQUIN SE LE OCURRE UN CASO TAN TIRADO DE LOS PELOS*/
                         boolean rspta = false;
                         if("F115".equals(evento.getCodIncidencia())){
                             //deben cumplir COD_MODALIDAD,TIPLUGARRECEP=10,04
                             String codModalidad = mapDeclaracionActual.get("COD_MODALIDAD")!=null?mapDeclaracionActual.get("COD_MODALIDAD").toString():"";
                             String codTipLugarRecepcion = mapDeclaracionActual.get("COD_TIPLUGARRECEP")!=null?mapDeclaracionActual.get("COD_TIPLUGARRECEP").toString():"";

                             if(evaluarEvento(campo, evento,mapCamposDiferentes,new String[]{"COD_MODALIDAD","TIPLUGARRECEP"},new String[]{codModalidad,codTipLugarRecepcion})){
                                 incidencia = new Incidencia();
                                 incidencia.setCodIncidencia(evento.getCodIncidencia());
                                 automaticas.add(incidencia);
                             }
                         }else{
                             if(evaluarEvento(campo, evento,mapCamposDiferentes)){
                                 incidencia = new Incidencia();
                                 incidencia.setCodIncidencia(evento.getCodIncidencia());
                                 automaticas.add(incidencia);
                             }
                         }

	                 }else if("CONDICION_TRANSA".equals(sinonimoTabla)){    //f112

	                     List<Map<String, Object>> lstFormBProveedorActual = (List<Map<String, Object>>) mapDeclaracionActual.get("lstFormBProveedor");
	                     List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapDeclaracion.get("lstFormBProveedor");
	                     if (!CollectionUtils.isEmpty(lstFormBProveedorActual))
	                     {
	                       for (Map<String, Object> mapProveedor : lstFormBProveedorActual)
	                       {
	                       	  Map transaNew = mapProveedor.get("mapCondicionTransa")!=null?(HashMap) mapProveedor.get("mapCondicionTransa"):new HashMap();
	                       	  if(org.springframework.util.CollectionUtils.isEmpty(transaNew)) continue;

	                       	  Map key = new HashMap();
	                      	  key.put("num_secprove", mapProveedor.get("num_secprove"));	                      	  
	                       	  Map proveedorOld     =  Utilidades.obtenerElemento(lstFormBProveedor, key);
	                       	  Map transaOld = (HashMap) proveedorOld.get("mapCondicionTransa");	              

	                       	 Object[] ctrNamesCond = transaNew.keySet().toArray();
	                         if (ctrNamesCond != null && ctrNamesCond.length > 0){	                 	                          
	                          for (int j = 0; j < ctrNamesCond.length; j++){
	                            if (transaOld == null
	                                || transaOld.get(ctrNamesCond[j].toString()) == null
	                                || !transaOld.get(ctrNamesCond[j].toString()).toString().trim().equals(transaNew.get(ctrNamesCond[j].toString()).toString().trim()))
	                            {	                              	                       	                    	                           	                             	                          
	   	                    	  incidencia = new Incidencia();
	   	                          incidencia.setCodIncidencia(evento.getCodIncidencia());
	   	                          automaticas.add(incidencia);
	   	                          //se registra 1 solo incidencia basta que haya uno
	   	                          break;
                                }
                                }
                             }
	                        }
	                   }
	               }else if("FORMBITEMDESCRI".equals(sinonimoTabla)){
	               	if("F111".equals(evento.getCodIncidencia())){
	    	        	if(Constantes.TIPO_DILIG_ESTA_RECTIFICACION.equals(datos.get("cod_tipDilig"))){
	    	        		List<Map<String,Object>> formBItemDescriRectificado = (ArrayList) mapDeclaracionActual.get("lstFormBItemActualRectificado");
	    	        		for(Map<String,Object> datoRectificado:formBItemDescriRectificado){
	    	        			Boolean esDescripcionMinima = (Boolean)datoRectificado.get("esDescripcionMinima");
	    	        			Integer numeroSerie = Integer.parseInt(datoRectificado.get("NUM_SECSERIE").toString());
		    	        		if(esDescripcionMinima){
		    	        			incidencia = new Incidencia();
		   	                        incidencia.setCodIncidencia(evento.getCodIncidencia());
		   	                        incidencia.setNumeroSerie(numeroSerie);
		   	                        automaticas.add(incidencia);
		   	                        break;
		    	        		}
	    	        		}
	    	        	}
	            	}
	            	
	            	
	            	
	            }
	            	 
	            	 
	          } else{
	             continue;
	          }    
         }//for eventos
	          
	     filtrarCodigo670(automaticas,seriesBean);
	     
       }//bean
        
        
        
        return automaticas;
    }

	private boolean noEstaRegistrado(List<Incidencia> automaticas,
		Incidencia buscar) {
         boolean rspta = true;
		
		for(Incidencia registrado: automaticas){
			if(registrado.getCodIncidencia().equals(buscar.getCodIncidencia()) 
					&& (registrado.getNumeroSerie().toString()).equals(buscar.getNumeroSerie().toString())){
				rspta = false;
				break;
			}
		}
		            
	return rspta;
}

	private void filtrarCodigo670(List<Incidencia> automaticas,List<SerieIncidenciaBean> seriesBean) {
		     
		String[] otrosCodigosIncidencia ={ "A110","A120","A130","A131","A132",
				                           "A210","A220","A230","A240","A250","A260",
				                           "A410","A420","A430",
				                           "A520","A530",
				                           "A610","A620","A630","A660" };

	     
		for(SerieIncidenciaBean serie:seriesBean){		  
			if(!CollectionUtils.isEmpty(automaticas)){
				
				String numeSecSerie  = serie.getNunmSecSerie().toString();
				boolean tieneA670 = false;
				boolean tieneOtros = false;
				for(Incidencia incidencia : automaticas){
			      	if(numeSecSerie.equals(incidencia.getNumeroSerie()!=null?incidencia.getNumeroSerie().toString():"")){
			      		if("A670".equals(incidencia.getCodIncidencia())){
			      			tieneA670=true;
			      		}else  if (Arrays.asList(otrosCodigosIncidencia).contains(incidencia.getCodIncidencia()))
				  	      {
			      			tieneOtros = true;  
					      }
			      	}					
				}
				if(tieneOtros && tieneA670){
					for(Incidencia incidencia : automaticas){
				      	//if(numeSecSerie.equals(incidencia.getNumeroSerie().toString()) 
				      	if(numeSecSerie.equals(incidencia.getNumeroSerie()!=null?incidencia.getNumeroSerie().toString():"") 		
				      			
				      			&&"A670".equals(incidencia.getCodIncidencia())){
				      		automaticas.remove(incidencia);
				      		break;
				      	}					
					}
				}
			}						 
		}				
    }

	//wtaco-ini-optimizacion
    private boolean evaluarEvento(SerieIncidenciaBean serieBeam,EventoIncidencia evento, Map datos) {
		return evaluarEvento(serieBeam,evento, datos,null);
	}
	//wtaco-fin-optimizacion

	// RIN13-SWF
    private boolean evaluarEvento(SerieIncidenciaBean serieBeam,EventoIncidencia evento, Map datos,Map tmpMap) {

        //tiene que ser una regla del mismo tipo
    	String tieneInciTrib  = serieBeam.tieneInciTrib()?"S":"N";
    	if(!tieneInciTrib.equals(evento.getIncidenciaTributaria())) return false;

    	Long numSecSerie = serieBeam.getNunmSecSerie();    	  
    	String sinonimoTabla =   evento.getNombreTabla();
    	String campo =   evento.getNombreCampo();

        boolean rspta = false;
        //datos para validar
        Map mapDeclaracionActual = (HashMap)datos.get("declaracionActual");
        Map mapDeclaracion       = (HashMap)datos.get("declaracion");
        
        List<Map<String, Object>> lstSeriesItemActual = (ArrayList) datos.get("lstSeriesItemActual");               
        List listDetDeclaraActual = (ArrayList)datos.get("lstDetDeclaraActual");
        List<Map<String, Object>> lstDetDeclara = (List<Map<String, Object>>) datos.get("lstDetDeclaraAnt");

        String codAduana = mapDeclaracionActual.get("COD_ADUANA")!=null?mapDeclaracionActual.get("COD_ADUANA").toString():COD_ADUANA_CENTRAL;
        
        Map mapCamposDiferentesTmp = new HashMap();//P24-II
        Map mapCamposDiferentes = new HashMap();
        Map mapTablaNew = new HashMap();
        Map mapTablaOld = new HashMap();

        Map key = new HashMap();
        
        if("DET_DECLARA".equals(sinonimoTabla)){
        	
        	key = new HashMap();
        key.put("NUM_CORREDOC",mapDeclaracionActual.get("NUM_CORREDOC"));
        key.put("NUM_SECSERIE",numSecSerie);

        	//rtineo mejoras, se va calcular por unica vez
        	if(tmpMap !=null){
        		Map<Integer,Map> mapCamposDiferentesCache = (Map<Integer,Map>)tmpMap.get("mapCamposDiferentesCache");
        		if(mapCamposDiferentesCache == null){
        			mapCamposDiferentesCache = new HashMap<Integer,Map>();
        			tmpMap.put("mapCamposDiferentesCache", mapCamposDiferentesCache);
        		}

        		if(mapCamposDiferentesCache.containsKey(numSecSerie.intValue())){
        			mapCamposDiferentesTmp = mapCamposDiferentesCache.get(numSecSerie.intValue());
        			mapCamposDiferentes = (Map)mapCamposDiferentesTmp.get("mapCamposDiferentes");
        			mapTablaNew = (Map)mapCamposDiferentesTmp.get("mapTablaNewMem");
        			mapTablaOld = (Map)mapCamposDiferentesTmp.get("mapTablaOldMem");
        			if(mapCamposDiferentes.containsKey("return")){
        				return false;
        			}
        		}else{
        			mapTablaNew = soporteComparadorService.obtenerElementoMapXPkTabla(listDetDeclaraActual, key, EnumTablaModel.DET_DECLARA);
        			if("1".equals(mapTablaNew.get("IND_DEL")!=null?mapTablaNew.get("IND_DEL").toString():"0")){
        				Map<String,Object> mapTmp = new HashMap<String,Object>();
        				mapTmp.put("return", "");
        				Map<String,Object> mapTmpTmp = new HashMap<String,Object>();
        				mapTmpTmp.put("mapCamposDiferentes", mapTmp);
        				mapCamposDiferentesCache.put(numSecSerie.intValue(),mapTmpTmp);
        				return false;
        			}
        			mapTablaOld = soporteComparadorService.obtenerElementoMapXPkTabla(lstDetDeclara, key, EnumTablaModel.DET_DECLARA);
        	        mapCamposDiferentes = soporteComparadorService.comparaMap(mapTablaNew, mapTablaOld, EnumTablaModel.DET_DECLARA);
        	        mapCamposDiferentes.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399
        	        //test
        	        mapCamposDiferentesTmp.put("mapCamposDiferentes", mapCamposDiferentes);
        	        mapCamposDiferentesTmp.put("mapTablaNewMem", mapTablaNew);
        	        mapCamposDiferentesTmp.put("mapTablaOldMem", mapTablaOld);
        	        //seteamos el calor calculado
        	        mapCamposDiferentesCache.put(numSecSerie.intValue(), mapCamposDiferentesTmp);
        		}
        	}else{
        		//continuamos ejecutando el metodo pesado
            mapTablaNew = soporteComparadorService.obtenerElementoMapXPkTabla(listDetDeclaraActual, key, EnumTablaModel.DET_DECLARA);
            if("1".equals(mapTablaNew.get("IND_DEL")!=null?mapTablaNew.get("IND_DEL").toString():"0")){return false;}
            mapTablaOld = soporteComparadorService.obtenerElementoMapXPkTabla(lstDetDeclara, key, EnumTablaModel.DET_DECLARA);
            mapCamposDiferentes = soporteComparadorService.comparaMap(mapTablaNew, mapTablaOld, EnumTablaModel.DET_DECLARA);
            mapCamposDiferentes.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399
                        
         	}
        	//rtineo mejoras, fin
            //P34 AFMA
            Map mapDataModificada = mapCamposDiferentes.get("dataModificados")!=null?(Map)mapCamposDiferentes.get("dataModificados"):new HashMap();

            rspta = evaluarEvento(campo, evento,mapCamposDiferentes);
            //rpsta es solo cambio de partida
            if(rspta && "A230".equals(evento.getCodIncidencia())){//ISC o tasa                   	
            	 Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapDeclaracionActual.get("FEC_DECLARACION").toString());
            	 
            	if(/*esUnaMenorTasa(mapTablaNew,mapTablaOld,fechaVigenciaPartida) 
            			|| */serieBeam.tieneDiferenciaISC() && esISCMayor(mapTablaNew,mapTablaOld,fechaVigenciaPartida,codAduana)){
            		return true;
            	}else{
            		return false;
            	}             	
            }else if(rspta && "A210".equals(evento.getCodIncidencia())){//Advaloren
            	
            	Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapDeclaracionActual.get("FEC_DECLARACION").toString());
            	 
             	if( (serieBeam.tieneDiferenciaAdvaloren() && esAdValorenMayor(mapTablaNew,mapTablaOld,fechaVigenciaPartida,codAduana)) || serieBeam.tieneDiferenciaDerechoEspecifico() ){
             		return true;
             	}else{
             		return false;
             	}
            }else if(rspta && "A220".equals(evento.getCodIncidencia())){//Mayor IGV
            	
            	Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapDeclaracionActual.get("FEC_DECLARACION").toString());
            	 
             	if( serieBeam.tieneDiferenciaIGV() && esIGVMayor(mapTablaNew,mapTablaOld,fechaVigenciaPartida,codAduana)){
             		return true;
             	}else{
             		return false;
             	}
            }else if(rspta && "A240".equals(evento.getCodIncidencia())){//tiene antidumping
            	
            	Date fechaVigenciaPartida = SunatDateUtils.getDateFromUnknownFormat(mapDeclaracionActual.get("FEC_DECLARACION").toString());
            	             	
             	if( serieBeam.tieneDiferenciaMayorAntiDumping() && esPartidaConAntiDumping(mapTablaNew,mapTablaOld,fechaVigenciaPartida) ){
             		return true;
             	}else{
             		return false;
             	}
            }else if(rspta && "A260".equals(evento.getCodIncidencia())){// percepcion
            	
            	if( serieBeam.tieneDiferenciaPercepcion() && serieBeam.getTasaPercecionNew().compareTo(serieBeam.getTasaPercecionOld())==1){
             		return true;
             	}else{
             		return false;
             	} 
            }else if(rspta && "A520".equals(evento.getCodIncidencia())){// antidumping
            	if( serieBeam.tieneDiferenciaMayorAntiDumping()){
             		return true;
             	}else{
             		return false;
             	}             	
            	//CODIGOS ISC
            }else if(rspta && "A620".equals(evento.getCodIncidencia())){//ISC o tasa                   	
            	if(serieBeam.tieneDiferenciaISC()){
            		return true;
            }else{
            		return false;
            	}          	 
            	//CODIGO ANTIDUMPING, COMPENSATORIOS O SALVAGUARDA
            }else if(rspta && "A630".equals(evento.getCodIncidencia())){//ISC o tasa                   	
            	if(serieBeam.tieneDiferenciaMayorAntiDumping()){
            		return true;
            	}else{
            		return false;
            	} 	 
            //}P34 AFMA else if("A670".equals(evento.getCodIncidencia())){ //otros
            }else if("A670".equals(evento.getCodIncidencia()) && !org.springframework.util.CollectionUtils.isEmpty(mapDataModificada)){ //otros
            	if(serieBeam.tieneDiferenciaOtros()){
            		return true;
            	}else{
            		return false;
            	}
            	 
            }
            
        }else if("CONVENIO_SERIE".equals(sinonimoTabla)){
        	
        	key = new HashMap();
            key.put("NUM_CORREDOC",mapDeclaracionActual.get("NUM_CORREDOC"));
            key.put("NUM_SECSERIE",numSecSerie);
            
        	Map serie     =  Utilidades.obtenerElemento(listDetDeclaraActual, key);
        	Map serieAnt = Utilidades.obtenerElemento(lstDetDeclara, key);

        	List<Map<String, Object>> lstConvenioSerie   = serie.get("lstConvenioSerie")!=null?(ArrayList) serie.get("lstConvenioSerie"):new ArrayList<Map<String, Object>>();
            //List<Map<String, Object>> lstConvenioSerieAnt= serieAnt.get("lstConvenioSerie")!=null?(ArrayList) serieAnt.get("lstConvenioSerie"):new ArrayList<Map<String, Object>>();
        	List<Map<String, Object>> lstConvenioSerieAnt= new ArrayList<Map<String, Object>>();
               
            if (serieAnt != null ) {
            	lstConvenioSerieAnt= serieAnt.get("lstConvenioSerie")!=null?(ArrayList) serieAnt.get("lstConvenioSerie"):new ArrayList<Map<String, Object>>();
            }
            
            List<Map<String, Object>>  lstConvenioSerieDif =soporteComparadorService.comparaList(lstConvenioSerie, lstConvenioSerieAnt,EnumTablaModel.CONVENIO_SERIE);
            if (!CollectionUtils.isEmpty(lstConvenioSerieDif) && !CollectionUtils.isEmpty(lstConvenioSerie))
            {
              for (Map convenioSerie : lstConvenioSerieDif)
              {
            	  Map mapClave = (Map) convenioSerie.get("clave");
            	  //String codConvenio = mapClave.get("COD_CONVENIO")!=null?mapClave.get("COD_CONVENIO").toString():"";
            	  String codTipConvenio = mapClave.get("COD_TIPCONVENIO")!=null?mapClave.get("COD_TIPCONVENIO").toString():"";
            	  convenioSerie.put("tipoTransaccion", mapDeclaracion.get("tituloDiligencia"));//PAS399
            	  rspta = evaluarEvento(campo, evento, convenioSerie, new String[]{"COD_TIPCONVENIO"},new String[]{codTipConvenio});	  
            	  if(rspta){
                 	 return rspta;  
                   }
              }
            }
      }else if("ITEMFACTURA".equals(sinonimoTabla)){
    	  
    	  
    	//lalberti pas 42
    	  List<Map<String, Object>> lstItemFacturaDeLaSerieNew = new ArrayList<Map<String,Object>>();
    	  List<Map<String, Object>> lstItemFacturaDeLaSerieOld = new ArrayList<Map<String,Object>>();
    	  
    	  
    	  if(Constantes.TIPO_DILIG_ESTA_RECTIFICACION.equals(datos.get("cod_tipDilig"))){
    		  lstItemFacturaDeLaSerieNew = (ArrayList) mapDeclaracionActual.get("lstItemFacturaActual");
    		  lstItemFacturaDeLaSerieOld = (ArrayList) mapDeclaracion.get("lstItemFactura");
    		          
    		  //ini-wtaco-optimizacion.
    		  if(tmpMap !=null){
    			  boolean indrecti= (Boolean) tmpMap.get("indRecti"); 
    			  Map mapItemFormatoBOld = (Map<String,Map<String,Object>>)tmpMap.get("mapItemFormatoB");
    			  //optimizacion- solo se ejecuta 1 vez por evento
    			  if(indrecti){
    				  tmpMap.put("indRecti",false);
    				  for(Map<String, Object> itemNew : lstItemFacturaDeLaSerieNew){
	    	        	  key = new HashMap();
	    	        	  key.put("NUM_SECITEM", itemNew.get("NUM_SECITEM"));
	    	        	  //Map ItemOld =  Utilidades.obtenerElemento(lstItemFacturaDeLaSerieOld, key);
	    	        	  Map ItemOld =  Utilidades.obtenerElementoItemFormatoB(mapItemFormatoBOld, key);
	    	              mapCamposDiferentes = soporteComparadorService.comparaMap(itemNew, ItemOld, EnumTablaModel.ITEMFACTURA);
	    	              mapCamposDiferentes.put("tipoTransaccion",mapDeclaracionActual.get("tituloDiligencia"));
	    	              rspta = evaluarEvento(campo, evento,mapCamposDiferentes);
	    	              if(rspta){
	    	            	 return rspta;
	    	              }
    				  }
    			  }
    		  }
    		  //wtaco-fin optimizacion.
    		          
    	  }else{
    		  List<Map<String, Object>> lstSeriesItemDeLaSerieNew  = obtenerListadoItem(numSecSerie,lstSeriesItemActual);
	    	  lstItemFacturaDeLaSerieNew = obtenerListaItemFactura(lstSeriesItemDeLaSerieNew,mapDeclaracionActual);    	      	  
	    	  lstItemFacturaDeLaSerieOld = obtenerListaItemFactura(lstSeriesItemDeLaSerieNew,mapDeclaracion);
    	  
	      //fin lalberti pas 42
	      for(Map<String, Object> itemNew : lstItemFacturaDeLaSerieNew){
	        	  
	        	  key = new HashMap();        	  
	        	  key.put("NUM_SECITEM", itemNew.get("NUM_SECITEM"));        	  
	              
	        	  Map ItemOld     =  Utilidades.obtenerElemento(lstItemFacturaDeLaSerieOld, key);
	        	           
	              mapCamposDiferentes = soporteComparadorService.comparaMap(itemNew, ItemOld, EnumTablaModel.ITEMFACTURA);
	              mapCamposDiferentes.put("tipoTransaccion",mapDeclaracionActual.get("tituloDiligencia"));//PAS399
	              rspta = evaluarEvento(campo, evento,mapCamposDiferentes);
	              //basta que encuentre 1 valor verdadero y envia la rspta para que consideren a la serie con la incidencia evaluada
	              //cas Bug 20179 una serie con varios item el priero es verdadero los demas no como evaluan para todos no geenra la inciencia
	              if(rspta){
	            	 return rspta;  
	              }
	        	  
	          }
    	   } //wtaco-optimizacion. cuando sea despacho realiza lo mismo.
                                    
        }else if("DOCUPRECE_DUA".equals(sinonimoTabla)){
            key = new HashMap();
            key.put("NUM_CORREDOC",mapDeclaracionActual.get("NUM_CORREDOC"));
            key.put("NUM_SECSERIE",numSecSerie);

        	//rtineo mejoras, la veces que recorre vuelve a calcular el mismo, entonces se alamcena en este map
        	List<Map<String, Object>>  lstDocuPreceDuaDif = new ArrayList<Map<String,Object>>();
        	if(tmpMap !=null){
        		Map<Integer,List<Map<String,Object>>> lstDocuPreceDuaDifCache = (Map<Integer,List<Map<String,Object>>>)tmpMap.get("lstDocuPreceDuaDif");
        		if(lstDocuPreceDuaDifCache == null){
        			lstDocuPreceDuaDifCache = new HashMap<Integer,List<Map<String,Object>>>();
        			tmpMap.put("lstDocuPreceDuaDif", lstDocuPreceDuaDifCache);
        		}

        		if(lstDocuPreceDuaDifCache.containsKey(numSecSerie.intValue())){
        			lstDocuPreceDuaDif = lstDocuPreceDuaDifCache.get(numSecSerie.intValue());
        		}else{
            		//Ejecutamos una vez el metodo pesado para precargar la ejecucion
                    Map serie     =  Utilidades.obtenerElemento(listDetDeclaraActual, key);
                    Map serieAnt = Utilidades.obtenerElemento(lstDetDeclara, key);
                    List<Map<String, Object>> lstDocuPreceDua   = serie.get("lstDocuPreceDua")!=null?(ArrayList) serie.get("lstDocuPreceDua"):new ArrayList<Map<String, Object>>();
                    List<Map<String, Object>> lstDocuPreceDuaAnt= new ArrayList<Map<String, Object>>();
                    if (serieAnt != null ) {
                    	lstDocuPreceDuaAnt= serieAnt.get("lstDocuPreceDua")!=null?(ArrayList) serieAnt.get("lstDocuPreceDua"):new ArrayList<Map<String, Object>>();
                    }
                    lstDocuPreceDuaDif =soporteComparadorService.comparaList(lstDocuPreceDua, lstDocuPreceDuaAnt,EnumTablaModel.DOCUPRECE_DUA);
                    //seteamos el valor en el map
                    lstDocuPreceDuaDifCache.put(numSecSerie.intValue(),lstDocuPreceDuaDif);
        		}
        	}else{
        		//se continua ejecutando metodo pesado
            Map serie     =  Utilidades.obtenerElemento(listDetDeclaraActual, key);
            Map serieAnt = Utilidades.obtenerElemento(lstDetDeclara, key);

            List<Map<String, Object>> lstDocuPreceDua   = serie.get("lstDocuPreceDua")!=null?(ArrayList) serie.get("lstDocuPreceDua"):new ArrayList<Map<String, Object>>();
           // List<Map<String, Object>> lstDocuPreceDuaAnt= serieAnt.get("lstDocuPreceDua")!=null?(ArrayList) serieAnt.get("lstDocuPreceDua"):new ArrayList<Map<String, Object>>();
            List<Map<String, Object>> lstDocuPreceDuaAnt= new ArrayList<Map<String, Object>>();

            if (serieAnt != null ) {
            	lstDocuPreceDuaAnt= serieAnt.get("lstDocuPreceDua")!=null?(ArrayList) serieAnt.get("lstDocuPreceDua"):new ArrayList<Map<String, Object>>();
            }
                lstDocuPreceDuaDif =soporteComparadorService.comparaList(lstDocuPreceDua, lstDocuPreceDuaAnt,EnumTablaModel.DOCUPRECE_DUA);
        	}
        	//rtineo mejoras, fin

            if (!CollectionUtils.isEmpty(lstDocuPreceDuaDif))
            {
                for (Map DocuPrece : lstDocuPreceDuaDif)
                {
                    Map mapClave = (Map) DocuPrece.get("clave");
                    DocuPrece.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399
                    String codTipRegimen = mapClave.get("COD_REGIMENPRE")!=null?mapClave.get("COD_REGIMENPRE").toString():"";
                     //P28 AFMA
                    if("F116".equals(evento.getCodIncidencia())){
                    	if("12".equals(codTipRegimen)){
                    		rspta = evaluarEvento(campo, evento, DocuPrece, new String[]{"COD_REGIMENPRE"},new String[]{codTipRegimen});	
                    		if(!rspta){
                                String numDeclaracionPre = mapClave.get("NUM_DECLARACIONPRE")!=null?mapClave.get("NUM_DECLARACIONPRE").toString():"";
                    			rspta = evaluarEvento(campo, evento, DocuPrece, new String[]{"NUM_DECLARACIONPRE"},new String[]{numDeclaracionPre});	
                                if(!rspta){
                                    String numSecSeriePre = mapClave.get("NUM_SECSERIEPRE")!=null?mapClave.get("NUM_SECSERIEPRE").toString():"";
                                    rspta = evaluarEvento(campo, evento, DocuPrece, new String[]{"NUM_SECSERIEPRE"},new String[]{numSecSeriePre});
                                }
                    		}
                    		
                    	}                        
                    }else if("F117".equals(evento.getCodIncidencia())){
                    	if(!"12".equals(codTipRegimen)){
                    		rspta = evaluarEvento(campo, evento, DocuPrece);	
                    	}                        
                       
                    }
                }
            }
        }else if("DOCAUT_ASOCIADO".equals(sinonimoTabla))
        {    //F118



            List<Map<String, Object>> lstDetAutorizacionActual = mapDeclaracionActual.get("lstDetAutorizacion") != null ? (List) mapDeclaracionActual.get("lstDetAutorizacion") : new ArrayList<Map<String, Object>>();
            List<Map<String, Object>> lstDetAutorizacion = mapDeclaracion.get("lstDetAutorizacion") != null ? (List) mapDeclaracion.get("lstDetAutorizacion") : new ArrayList<Map<String, Object>>();
           // List<Map<String, Object>> lstDocAutAsociadoActual = mapDeclaracionActual.get("lstDocAutAsociado") != null ? (List) mapDeclaracionActual.get("lstDocAutAsociado") : new ArrayList<Map<String, Object>>();
            //List<Map<String, Object>> lstDocAutAsociado = mapDeclaracion.get("lstDocAutAsociado") != null ? (List) mapDeclaracion.get("lstDocAutAsociado") : new ArrayList<Map<String, Object>>();


            List<Map<String, Object>>  lstDetAutorizacionDif =soporteComparadorService.comparaList(lstDetAutorizacionActual, lstDetAutorizacion,EnumTablaModel.DET_AUTORIZACION);
            if (!CollectionUtils.isEmpty(lstDetAutorizacionDif) && !CollectionUtils.isEmpty(lstDetAutorizacionActual))
            {
                for (Map detAutorizacion : lstDetAutorizacionDif)
                {
                    Map mapClave = (Map) detAutorizacion.get("clave");

                    String tipoOperacion = mapClave.get("COD_TIPOPER")!=null?mapClave.get("COD_TIPOPER").toString():"";
                    String numSecSerieDelDocumento = mapClave.get("NUM_SECSERIE")!=null?mapClave.get("NUM_SECSERIE").toString():"";
                    detAutorizacion.put("tipoTransaccion",mapDeclaracion.get("tituloDiligencia"));//PAS399
                    if("P".equals(tipoOperacion) && numSecSerieDelDocumento.equals(numSecSerie.toString())){
                        rspta = evaluarEvento(campo, evento, detAutorizacion);
                        if(rspta){
                       	 return rspta;  
                         }
                    }
                }
        }

        }
        
        return rspta;
    }
    
   


    private boolean esPartidaConAntiDumping(Map mapTablaNew, Map mapTablaOld,
			Date fechaVigenciaPartida) {
    	boolean rspta = false;
		
    	
    	String numPartidaNew = mapTablaNew.get("NUM_PARTNANDI")!=null?mapTablaNew.get("NUM_PARTNANDI").toString():"";
    	String numPartidaOld = mapTablaOld.get("NUM_PARTNANDI")!=null?mapTablaOld.get("NUM_PARTNANDI").toString():"";
    	
    	
    	Map<String,Object> paramsTasadump =new HashMap<String,Object>();    	
		paramsTasadump.put("cnan",numPartidaNew);		
		paramsTasadump.put("fechavigencia", SunatDateUtils.getIntegerFromDate(fechaVigenciaPartida));
		
		TasadumpDAO tasa = (TasadumpDAO)fabricaDeServicios.getService("tasadumpDAO");
		int contTasadumpNew=tasa.count(paramsTasadump);
		
		paramsTasadump.put("cnan",numPartidaOld);		
		
		int contTasadumpOld=tasa.count(paramsTasadump);
		
		if (contTasadumpNew>0 && contTasadumpOld==0){
			rspta = true;
		}
				
		return rspta;
	}

	private boolean esIGVMayor(Map mapTablaNew, Map mapTablaOld,
			Date fechaVigenciaPartida,String codAduana) {
    	
    	boolean rspta = false;
		
		 Long numPartNandiSerieNew = toLong(mapTablaNew.get("NUM_PARTNANDI"));
		 Long numPartNandiSerieOld = toLong(mapTablaOld.get("NUM_PARTNANDI"));
		

		 String tnanNew = mapTablaNew.get("COD_TIPTASAAPLICAR")!=null?mapTablaNew.get("COD_TIPTASAAPLICAR").toString():"";
		 String tnanOld = mapTablaOld.get("COD_TIPTASAAPLICAR")!=null?mapTablaOld.get("COD_TIPTASAAPLICAR").toString():"";
		 
		 NandTasa nandTasaNew = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieNew,fechaVigenciaPartida,tnanNew);
		 NandTasa nandTasaOld = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieOld,fechaVigenciaPartida,tnanOld);
		 		  
		 
		if (nandTasaNew != null 
				&& nandTasaNew.getVigv() != null 
				&& nandTasaOld != null 
				&& nandTasaOld.getVigv() != null)
		{
		  if(nandTasaNew.getVigv().compareTo(nandTasaOld.getVigv())>0){
			  rspta = true;
		  }	
		}
			
		return rspta;
	}

	private boolean esAdValorenMayor(Map mapTablaNew, Map mapTablaOld,
			Date fechaVigenciaPartida,String codAduana) {
    	boolean rspta = false;
		
		 Long numPartNandiSerieNew = toLong(mapTablaNew.get("NUM_PARTNANDI"));
		 Long numPartNandiSerieOld = toLong(mapTablaOld.get("NUM_PARTNANDI"));
		
		 String tnanNew = mapTablaNew.get("COD_TIPTASAAPLICAR")!=null?mapTablaNew.get("COD_TIPTASAAPLICAR").toString():"";
		 String tnanOld = mapTablaOld.get("COD_TIPTASAAPLICAR")!=null?mapTablaOld.get("COD_TIPTASAAPLICAR").toString():"";
		 
		 NandTasa nandTasaNew = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieNew,fechaVigenciaPartida,tnanNew);
		 NandTasa nandTasaOld = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieOld,fechaVigenciaPartida,tnanOld);
		 		  
		 		  
		 
		if (nandTasaNew != null 
				&& nandTasaNew.getVadv() != null 
				&& nandTasaOld != null 
				&& nandTasaOld.getVadv() != null)
		{
		  if(nandTasaNew.getVadv().compareTo(nandTasaOld.getVadv())>0){
			  rspta = true;
		  }	
		}
			
		return rspta;
	}

	private boolean esUnaMenorTasa(Map mapTablaNew, Map mapTablaOld,Date fechaVigenciaPartida,String codAduana) {
		boolean rspta = false;
		
		
		 Long numPartNandiSerieNew = toLong(mapTablaNew.get("NUM_PARTNANDI"));
		 Long numPartNandiSerieOld = toLong(mapTablaOld.get("NUM_PARTNANDI"));
		 String tnanNew = mapTablaNew.get("COD_TIPTASAAPLICAR")!=null?mapTablaNew.get("COD_TIPTASAAPLICAR").toString():"";
		 String tnanOld = mapTablaOld.get("COD_TIPTASAAPLICAR")!=null?mapTablaOld.get("COD_TIPTASAAPLICAR").toString():"";
		
		 NandTasa nandTasaNew = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieNew,fechaVigenciaPartida,tnanNew);
		 NandTasa nandTasaOld = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieOld,fechaVigenciaPartida,tnanOld);
		 		  
		 
		if (nandTasaNew != null 
				&& nandTasaNew.getTseguro() != null 
				&& nandTasaOld != null 
				&& nandTasaOld.getTseguro() != null)
		{
		  if(nandTasaOld.getTseguro().compareTo(nandTasaNew.getTseguro())>0){
			  rspta = true;
		  }	
		}
			
		return rspta;
	}

	private boolean esISCMayor(Map mapTablaNew, Map mapTablaOld,Date fechaVigenciaPartida, String codAduana) {
		boolean rspta = false;
		
		 Long numPartNandiSerieNew = toLong(mapTablaNew.get("NUM_PARTNANDI"));
		 Long numPartNandiSerieOld = toLong(mapTablaOld.get("NUM_PARTNANDI"));
		
		 String tnanNew = mapTablaNew.get("COD_TIPTASAAPLICAR")!=null?mapTablaNew.get("COD_TIPTASAAPLICAR").toString():"";
		 String tnanOld = mapTablaOld.get("COD_TIPTASAAPLICAR")!=null?mapTablaOld.get("COD_TIPTASAAPLICAR").toString():"";
		 		  
		 NandTasa nandTasaNew = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieNew,fechaVigenciaPartida,tnanNew);
		 NandTasa nandTasaOld = soporteService.obtenerTasaNandinaByPartida(codAduana, numPartNandiSerieOld,fechaVigenciaPartida,tnanOld);
		 
		if (nandTasaNew != null 
				&& nandTasaNew.getVisc() != null )
		{
		  BigDecimal mtoISC = (nandTasaOld!=null && nandTasaOld.getVisc()!=null)?nandTasaOld.getVisc():BigDecimal.ZERO;
		  if(nandTasaNew.getVisc().compareTo(mtoISC)>0){
			  rspta = true;
		  }	
		}
			
		return rspta;
	}

    private boolean evaluarEvento(String campo, EventoIncidencia evento,Map mapCamposDiferentes){

    	return evaluarEvento(campo,evento,mapCamposDiferentes,new String[]{},new String[]{});
    }
    
	private boolean evaluarEvento(String campo, 
			EventoIncidencia evento,
			Map mapCamposDiferentes, 
			String[] sCampoCondicionComparar, 
			String[] sValorCampoCondicionComparar) {
			
		
		if(!SunatStringUtils.isEmptyTrim(evento.getNombreCampoCondicion()) 
				&& !SunatStringUtils.isEmptyTrim(evento.getValorCampoCondicion())
			    && sValorCampoCondicionComparar.length > 0
			    && sCampoCondicionComparar.length > 0){
		      
			
			String[] eCamposCondicion = evento.getNombreCampoCondicion().split(",");
			String[] eValoresCondicion= evento.getValorCampoCondicion().split(",");
			
			List<String> lstCamposCondicion = Arrays.asList(eCamposCondicion);
			List<String> lstValoresCondicion = Arrays.asList(eValoresCondicion);
			List<String> lstCampoCondicionComparar = Arrays.asList(sCampoCondicionComparar);
			List<String> lstValoresCampoCondicionComparar = Arrays.asList(sValorCampoCondicionComparar);			
			
			for (int i = 0; i < lstCamposCondicion.size(); i++) {
				String campoCondicion = lstCamposCondicion.get(i);
				String valorCondicion = lstValoresCondicion.get(i);
				String campoCondicionComparar = lstCampoCondicionComparar.get(i);
				String valorCondicionComparar = lstValoresCampoCondicionComparar.get(i);
				if(!campoCondicion.equals(campoCondicionComparar) || 
						!valorCondicion.equals(valorCondicionComparar)){
					return false;
				}
				
			}									
		}
		
		
		boolean rspta = false;	
		List<String> acciones = obtenerListaAcciones(evento);

		Map mapDataOriginal;
		Map mapDataModificada;
        String tipoOperacionBD = (String) mapCamposDiferentes.get("tipoOperacionBD");
        mapDataOriginal = (Map)mapCamposDiferentes.get("dataOriginal");
        mapDataModificada = (Map)mapCamposDiferentes.get("dataModificados");
        if(mapDataOriginal!=null && mapDataModificada!=null){
        	
        	String campoNew = mapDataModificada.get(campo)!=null?mapDataModificada.get(campo).toString():"";
        	String campoOld = mapDataOriginal.get(campo)!=null?mapDataOriginal.get(campo).toString():"";

            if (StringUtils.contains(campo, "MTO_")){
            	BigDecimal diferenciaMaximaMonto = Utilidades.toBigDecimal(Constantes.DIFERENCIA_MAX_MONTO);
                BigDecimal mtoNew = Utilidades.toBigDecimal(StringUtils.isNotBlank(campoNew)?campoNew:0);
                BigDecimal mtoOld = Utilidades.toBigDecimal(StringUtils.isNotBlank(campoOld)?campoOld:0);
                BigDecimal dif = mtoNew.subtract(mtoOld);
            	//Si es Regularizacion no aplica el diferenciaMaximaMonto - PAS399
                String codTransaccion = (String) mapCamposDiferentes.get("tipoTransaccion");
                if (!SunatStringUtils.include(codTransaccion, new String[]{"Regularizaci�n"})){
                    if (diferenciaMaximaMonto.compareTo(dif.abs())>0){
                        return false;
                    }                	
                }
            }


	        boolean campoFueModificado =  !SunatStringUtils.isEmptyTrim(campoNew) &&  !SunatStringUtils.isEmptyTrim(campoOld) ;
	        boolean campoFueEliminado  =  (SunatStringUtils.isEmptyTrim(campoNew) &&  !SunatStringUtils.isEmptyTrim(campoOld)) || "1".equals(mapDataModificada.get("IND_DEL"));
	        boolean campoFueAgregado   =  !SunatStringUtils.isEmptyTrim(campoNew) &&  SunatStringUtils.isEmptyTrim(campoOld) ;
	
	        for (String accion: acciones){
	            if("MODI".equals(accion)){
	                if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD) && campoFueModificado){rspta = true;}
	            }else if("ADD".equals(accion)){
	                if (campoFueAgregado){rspta = true;}
	            }if("DEL".equals(accion)){
	                if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD) && campoFueEliminado){rspta = true;}
	            }
	        }

        }
        
        return rspta;
    }

  private List<String> obtenerListaAcciones(EventoIncidencia evento) {
	  List<String> acciones = new ArrayList<String>();

      if("S".equals(evento.getEventoModificadoCampo())){
          acciones.add("MODI");
      }
      if("S".equals(evento.getEventoRegistrarCampo())){
          acciones.add("ADD");
      }
      if("S".equals(evento.getEventoEliminadoCampo())){
          acciones.add("DEL");
      }
		
      return acciones;
	}

  
  private List<Map<String, Object>> obtenerListadoItem(Long numSecSerie, List<Map<String, Object>> lstSeriesItem){
	  	 		
	  List<Map<String, Object>> lstSeriesItemFiltrado = new ArrayList();
	  
	    if (lstSeriesItem != null && lstSeriesItem.size() > 0)
	      for (Map<String, Object> seriesItem : lstSeriesItem)
	      {
	    	  //adicion para rectificacion
	    	  String ind_del = seriesItem.get("IND_DEL")!= null?seriesItem.get("IND_DEL").toString():new String("0");
	        if (seriesItem.get("NUM_SECSERIE").toString().equals(numSecSerie.toString()) &&
	        		ind_del.equals("0"))
	        {	          
	        	lstSeriesItemFiltrado.add(Utilidades.copiarMapa(seriesItem));	         
	        }
	      }
	    return lstSeriesItemFiltrado;
  }
  
 
  
  private List<Map<String, Object>>  obtenerListaItemFactura(List<Map<String, Object>> lstSeriesItemDeLaSerie,Map mapDeclaracion){
	  
	  List<Map<String, Object>> lstItemFacturaFiltrada = new ArrayList();
	  
	  if (!CollectionUtils.isEmpty(lstSeriesItemDeLaSerie))
	      for (Map<String, Object> seriesItem : lstSeriesItemDeLaSerie)
	      {
	    	  	    	  
	    	  String numSecProve = seriesItem.get("NUM_SECPROVE")!=null?seriesItem.get("NUM_SECPROVE").toString():"";
	    	  String numSecFact  = seriesItem.get("NUM_SECFACT")!=null?seriesItem.get("NUM_SECFACT").toString():"";
	    	  String numSecItem =  seriesItem.get("NUM_SECITEM")!=null?seriesItem.get("NUM_SECITEM").toString():"";
	    	  
	          List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapDeclaracion.get("lstFormBProveedor");
	          if (!CollectionUtils.isEmpty(lstFormBProveedor))
	          {
	            for (Map<String, Object> mapProveedor : lstFormBProveedor)
	            {
	            	if (numSecProve.equals(mapProveedor.get("num_secprove").toString().trim())){
	            		if (!CollectionUtils.isEmpty((List) mapProveedor.get("lstComproBPago"))){	            			
	            			 for (Map<String, Object> mapaFactura : (List<Map<String, Object>>) mapProveedor.get("lstComproBPago"))
	                         {
	                           if (numSecFact.equals(mapaFactura.get("num_secfact").toString().trim()))
	                           {
	                        	   if (!CollectionUtils.isEmpty((List) mapaFactura.get("lstItemFactura"))){	            			
	      	            			 for (Map<String, Object> mapaItem : (List<Map<String, Object>>) mapaFactura.get("lstItemFactura")){
	      	            				if (numSecItem.equals(mapaItem.get("NUM_SECITEM").toString().trim())){
	      	            					lstItemFacturaFiltrada.add(mapaItem);
	     	                           }	      	            				 
	      	            		     }
	      	            		   }	                        	   
	                           }
	                         }
	            		}	            		
	            	}  		          	  
	            }
	          }
	      }
	  
	  return lstItemFacturaFiltrada;
  }
  
  /*
  private Map<String, Object> obtenerListaTransa(
			List<Map<String, Object>> lstSeriesItemDeLaSerie,
			Map mapDeclaracion) {
	
		
		
	  
	  Map<String, Object> MAPFiltrada = new HashMap();
	  
	  if (!CollectionUtils.isEmpty(lstSeriesItemDeLaSerie))
	      for (Map<String, Object> seriesItem : lstSeriesItemDeLaSerie)
	      {
	    	  	    	  
	    	  String numSecProve = seriesItem.get("NUM_SECPROVE")!=null?seriesItem.get("NUM_SECPROVE").toString():"";
	    	  
	          List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>) mapDeclaracion.get("lstFormBProveedor");
	          if (!CollectionUtils.isEmpty(lstFormBProveedor))
	          {
	            for (Map<String, Object> mapProveedor : lstFormBProveedor)
	            {
	            	if (numSecProve.equals(mapProveedor.get("num_secprove").toString().trim())){
	            		MAPFiltrada = (HashMap) mapProveedor.get("mapCondicionTransa");	            		
	            	}  		          	  
	            }
	          }
	      }
	  
	  	  	  
	  return MAPFiltrada;		
	}*/
  
  
/**INICIO-RIN13**/

  /**
   * Obtiene la incidencia, 
   * si esta ha sido subsanada retorna 
   * con la solicitud de subsanacion 
   * @param parametros de busqueda
   * @return solicitud de subsanacion ZPAE
   * @author gbecerrav
   */
  @Override
  public SolicitudSubsanacion obtenerIncidenciaSubsanada(
  		Map<String, Object> params) throws ServiceException {
	  return this.soliSubsanacionDAO.getIncidenciaSubsanadaByParameterMap(params);
  }
 /**FIN-RIN13**/ 
  /***********************SET DE SPRING **********************************/

  public void setInciEventoDAO(InciEventoDAO inciEventoDAO)
  {
    this.inciEventoDAO = inciEventoDAO;
  }

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  public void setDetIncidenciaDAO(DetIncidenciaDAO detIncidenciaDAO)
  {
    this.detIncidenciaDAO = detIncidenciaDAO;
  }
/**FIN-RIN13**/
/**
 * @return the soliSubsanacionDAO
 */
public SoliSubsanacionDAO getSoliSubsanacionDAO() {
	return soliSubsanacionDAO;
}

/**
 * @param soliSubsanacionDAO the soliSubsanacionDAO to set
 */
public void setSoliSubsanacionDAO(SoliSubsanacionDAO soliSubsanacionDAO) {
	this.soliSubsanacionDAO = soliSubsanacionDAO;
}
/**FIN-RIN13**/

  //msanchez
  /**
   * Metodo que nos permite obtener incidencia F121 para Dua con TPN21
   * diligencia.
   */
  public List obtenerIncidenciaF121(Map<String, Object> paramsIncidencia)
      throws ServiceException
  {
    List<Map<String, Object>> lista = null;
    try
    {
      lista = detIncidenciaDAO.findByIncidencia(paramsIncidencia);     

    }
    catch (Exception e)
    {
      log.error(this.toString().concat(" obtenerIncidenciaF121- ERROR: ").concat(e.getMessage()));
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

	// RIN13-SWF
    public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
        this.liquidaDeclaracionService = liquidaDeclaracionService;
    }

	// RIN13-SWF
    public void setSoporteComparadorService(SoporteComparadorService soporteComparadorService) {
        this.soporteComparadorService = soporteComparadorService;
    }
    
    public void setSoporteService(SoporteService soporteService) {
  		this.soporteService = soporteService;
  	}

    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
}
