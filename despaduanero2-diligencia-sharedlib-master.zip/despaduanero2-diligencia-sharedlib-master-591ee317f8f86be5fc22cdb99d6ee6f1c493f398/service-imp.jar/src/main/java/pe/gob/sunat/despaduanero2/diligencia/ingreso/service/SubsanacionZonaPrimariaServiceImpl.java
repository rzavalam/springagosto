package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.administracion2.tramite.util.ConstantesTramite;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Estabnoapto;
import pe.gob.sunat.sigad.diligencia.service.EstablecimientoNoAptoService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.SoliSubsanacionDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.service.SolicitudService;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.servicio2.registro.model.Spr;
import pe.gob.sunat.servicio2.registro.service.SprDAOService;
//import pe.gob.sunat.servicio2.registro.service.SprService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.rrhh2.service.ConsultaService;

/**
 * <p>Title: SubsanacionZonaPrimariaServiceImpl</p>
 * <p>Description: Clase de Servicio para la Subsanacion de Observacion ZPAE</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public class SubsanacionZonaPrimariaServiceImpl implements SubsanacionZonaPrimariaService{
    protected final Log log = LogFactory.getLog(getClass());

    private IncidenciaService            incidenciaService;
    private DeclaracionService           declaracionService;
    private ExpedienteService            expedienteService;
    private ParticipanteService          participanteService;
    private CatalogoAyudaService         catalogoAyudaService;
    private OperadorAyudaService         operadorAyudaService;
    //private SprService                   sprService;
    private SprDAOService                sprDAOService;

    private SolicitudService             solicitudService;
    private SoliSubsanacionDAO           soliSubsanacionDAOXA;
    private SoliSubsanacionDAO           soliSubsanacionDAO;
    private EstablecimientoNoAptoService establecimientoNoAptoService;
    private ConsultaService              consultaService;

    /**
     * Valida la declaracion para el proceso
     * de subsanacion ZPAE
     * @param aduanaDeclaracion Aduana de la declaracion
     * @param anioDeclaracion A�o de la declaracion
     * @param regimenDeclaracion R�gimen de la declaracion
     * @param numeroDeclaracion N�mero de la declaracion
     * @param usuario Usuario logeado
     * @return Error de validaci�n
     * @author gbecerrav
     */
    @Override
    public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, Integer anioDeclaracion,
                                                 String regimenDeclaracion, Integer numeroDeclaracion, UsuarioBean usuario) throws ServiceException
    {

        ObjectResponseUtil rpta = new ObjectResponseUtil();

        //1. Que la declaraci�n exista
        DUA dua = this.declaracionService.buscarDUAByClaveDeNegocio(aduanaDeclaracion, anioDeclaracion, regimenDeclaracion, numeroDeclaracion);
        if (dua == null)
        {
            rpta.addMensaje("La Declaraci�n no ha sido numerada en el SDA.", "Verifique", true);
            return rpta;
        }

        //2.Que la declaraci�n corresponda a la modalidad anticipado
        if (!ConstantesDataCatalogo.MODA_ANTICIPADA.equals(dua.getCodmodalidad()))
        {
            rpta.addMensaje("Declaraci�n no corresponde a despacho anticipado", "Verifique", true);
            return rpta;
        }

        //3.Que la declaraci�n no cuente con local apto para reconocimiento
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("numeroCorrelativo", dua.getNumcorredoc());
        params.put("tipoIncidencia", ConstantesDataCatalogo.INCIDENCIA_LOCAL_NO_APTO_RECONOCIMIENTO);
        SolicitudSubsanacion solicitudSubsanacion = this.incidenciaService.obtenerIncidenciaSubsanada(params);

        //Verificamos si no se ha registrado incidencia o Verificamos si la incidencia ha sido subsanada
        if (solicitudSubsanacion == null || solicitudSubsanacion.getIncidencia().getDiligencia().getNumeroCorrelativo() == null || solicitudSubsanacion.getNumeroCorrelativo() != null)
        {
            rpta.addMensaje("Declaraci�n cuenta con local apto para reconocimiento f�sico", "Verifique", true);
            return rpta;
        }

        //4.Que exista expediente asociado a la declaraci�n:
		//En caso de no existir expediente asociado o este se encuentra concluido con resultado improcedente (08)
		//Para verificar si el expediente se encuentra concluido con resultado improcedente
		Expedi expediEncontrado = this.expedientesAsociadoDUA(dua);
		
		if (expediEncontrado == null) {
			rpta.addMensaje("La declaraci�n no cuenta con expediente asociado", "Verifique", true);
			return rpta;
		
		} else { 
			if ( expediEncontrado.getActEstado().equals(ConstantesTramite.EXPEDI_ESTADO_CONCLUIDO) && expediEncontrado.getTipoConc().equals(ConstantesTramite.EXPEDI_TIPOCONC_IMPROCEDENTE )) 
			{ 		rpta.addMensaje("Expediente " + expediEncontrado.getCodiAdua() + "-" + expediEncontrado.getOficRec() + 
						"-"	+ expediEncontrado.getAnoexpedi() + "-" + expediEncontrado.getNroexpedi() + 
						"  asociado se encuentra con resultado improcedente", "Verfique", true);
						return rpta;
			}
		}
		
		//si todo ok retorna true y el objeto declaracion
		rpta.setRespuesta(true);
		rpta.addDato("dua", dua);
		rpta.addDato("incidencia", solicitudSubsanacion.getIncidencia());
		rpta.addDato("expediente", expediEncontrado);
		
		return rpta;
	}

	private Expedi expedientesAsociadoDUA(DUA dua) {	
		Integer oTipo = null;
		
		if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(dua.getCodregimen())) { oTipo = 17; }
		else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(dua.getCodregimen())) { oTipo = 32; }
		else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(dua.getCodregimen())) { oTipo = 7; }
		else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(dua.getCodregimen())) { oTipo = 40; }
		
		Expedi expediAbuscar = new Expedi();
		expediAbuscar.setCodiAdua(dua.getCodaduanaorden());
		expediAbuscar.setoAnno(dua.getAnnpresen().toString());
		expediAbuscar.setoTipo(oTipo);
		expediAbuscar.setoNro(Integer.parseInt(dua.getNumdocumento()));
		//expediAbuscar.setProcedim(ConstantesTramite.PROCEDIM_AMPLIA_PLAZO_ANTICIPADO);
		return this.expedienteService.getExpediente(expediAbuscar);
	}
	
	/**
	 * Adiciona datos a la declaracion
	 * @param dua Declaracion
	 * @author 
	 */
	@Override
	public void adicionarDatosDeclaracion(DUA dua) throws ServiceException {
		 //Verificar si se puede obtener en el query al obtener declaracion!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		Map<String, Object> paramsParticipante = new HashMap<String, Object>();
		paramsParticipante.put("numeroCorrelativo", dua.getNumcorredoc());
		paramsParticipante.put("codTiposParticipantes", new String[] { ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO,  ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA });
		List<Participante> listaParticipantes = this.participanteService.listarByParameterMap(paramsParticipante);
		
		if (listaParticipantes != null && !listaParticipantes.isEmpty()) {
			for (Participante participante : listaParticipantes) {
				//Descripcion de tipo de documento
				//participante.getTipoDocumentoIdentidad().setDesDatacat((String) this.catalogoAyudaService.getElementoCat(Constantes.CAT_TIPO_DOCUMENTO, participante.getTipoDocumentoIdentidad().getCodDatacat()).get("des_corta"));
				
				//Razon social (si es que esta es nula � vacia)
				if (StringUtils.isEmpty(participante.getNombreRazonSocial())) {
					participante.setNombreRazonSocial((String) this.operadorAyudaService.getDeclarante(participante.getTipoDocumentoIdentidad().getCodDatacat(), participante.getNumeroDocumentoIdentidad()).get("nombre"));
				}
				
				//Asignamos el importador � consignatario y agenteAduana � declarante a la dua
				if (ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO.equals(participante.getTipoParticipante().getCodDatacat())) {
					dua.setDeclarante(participante);
				} else {
					dua.setAgenteAduanas(participante);
				}
	    	}
		}
	}
	
	/**
	 * Obtener establecimientos de la declaracion 
	 * @param dua Declaracion
	 * @return lista de establecimientos
	 * @author 
	 */
	@Override
	public Spr obtenerEstablecimiento(DUA dua) throws ServiceException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numRuc", dua.getDeclarante().getNumeroDocumentoIdentidad());
		params.put("correl", new Short[] { Short.valueOf(dua.getCodanexo()) }); ///Short?????
		
		List<Spr> lista = this.sprDAOService.listEstablecimientosAnexos(params);
		
		if (lista != null && !lista.isEmpty()){
			return lista.get(0);
		}
		return null;
	}
	
	/**
	 * Registra subsanacion de observacion ZPAE 
	 * @param solicitudSubsanacion Solicitud de Subsanacion
	 * @param dua Declaracion
	 * @param expediente Expediente
	 * @author 
	 */
	@Override
	public void grabarSubsnacionObsZPAE(
			SolicitudSubsanacion solicitudSubsanacion, DUA dua)
			throws ServiceException {
		FechaBean fbFechaActual = new FechaBean();
		Date fechaActual = fbFechaActual.getTimestamp();
		
		//Registrar la solicitud
		Solicitud solicitud = new Solicitud();
		solicitud.setNumeroCorrelativo(null);
		solicitud.setEstado(ConstantesDataCatalogo.COD_EST_CONCLUIDO);
		solicitud.setCodAduana(dua.getCodaduanaorden());
		solicitud.setFechaGeneracion(fechaActual);
		solicitud.setRegimen(dua.getCodregimen());
		solicitud.setTipoSolicitud(ConstantesDataCatalogo.TIPO_SOLICITUD_SUBSANACION);
		solicitud.setEstadoSolicitud(ConstantesDataCatalogo.COD_EST_CONCLUIDO);
		/*DataCatalogo aduana = new DataCatalogo();
		aduana.setCodDatacat(dua.getCodaduanaorden());
		solicitud.setAduana(aduana);*/
		solicitud.setFechaSolicitud(fechaActual);
		solicitud.setFechaAtencion(fechaActual);
		Long numeroCorrelativoSolicitud = this.solicitudService.registrarSolicitud(solicitud);
		
		//Registrar solicitud de subsanacion
		solicitudSubsanacion.setNumeroCorrelativo(numeroCorrelativoSolicitud);
		this.soliSubsanacionDAOXA.insertSelective(solicitudSubsanacion);
		
		/*SolicitudSubsanacion solicitudSubsanacion = new SolicitudSubsanacion();
		solicitudSubsanacion.setNumeroCorrelativo(numeroCorrelativoSolicitud);
		solicitudSubsanacion.setIncidencia(incidencia);
		solicitudSubsanacion.setExpediente(expediente);
		descripcionSubsanacion: sustento de la subsanaci�n
		*/
		
		//Desmarcar el local como no apto para reconocimiento f�sico en ZPAE
		Estabnoapto estabnoapto = new Estabnoapto();
		estabnoapto.setRuc(dua.getDeclarante().getNumeroDocumentoIdentidad());
		estabnoapto.setCorrel(Short.valueOf(dua.getCodanexo()));
		estabnoapto.setCodiAduan(dua.getCodaduanaorden());
		estabnoapto.setAnoPrese(dua.getAnnpresen().toString());
		estabnoapto.setNumeCorre(Cadena.padLeft(dua.getNumdocumento().toString(), 6, '0'));
		estabnoapto.setCodiRegi(dua.getCodregimen());
		estabnoapto.setCdel("S");
		estabnoapto.setTexpedhabil(solicitudSubsanacion.getExpediente().getCodiAdua() + "-" + 
				solicitudSubsanacion.getExpediente().getOficRec() + "-" + 
				solicitudSubsanacion.getExpediente().getAnoexpedi() + "-" + 
				solicitudSubsanacion.getExpediente().getNroexpedi());
		estabnoapto.setFfin(new Integer(fbFechaActual.getFormatDate("yyyyMMdd")));
		this.establecimientoNoAptoService.actualizarEstablecimientoNoApto(estabnoapto);
	}
	
	/**
	 * Consulta de subsanacion de observacion ZPAE 
	 * @param params Par�metros de b�squeda
	 * @return lista de solicitudes de subsanacion
	 * @author gbecerrav
 	 */
	@Override
	public List<SolicitudSubsanacion> consultarSubsanacionObsZPAE(
			Map<String, Object> params) throws ServiceException {
		List<SolicitudSubsanacion> listaSolicitudSubsanacion = this.soliSubsanacionDAO.listConsultaSubsanacionObsZPAE(params);
		
		log.debug("-->listaSolicitudSubsanacion: " + listaSolicitudSubsanacion.size());
		
		for(SolicitudSubsanacion solicitudSubsanacion : listaSolicitudSubsanacion){
			Map<String, Object> especialista = this.obtenerEspecialista(solicitudSubsanacion.getCodigoFuncionarioRegistro());
			
			if(especialista != null){
				solicitudSubsanacion.setNombreFuncionarioRegistro(especialista.get("t02ap_pate") + " " + especialista.get("t02ap_mate") + " " + especialista.get("t02nombres"));
			}else{
				solicitudSubsanacion.setNombreFuncionarioRegistro("");
			}
		}
		return listaSolicitudSubsanacion;
	}
	
	
	private Map<String, Object> obtenerEspecialista(String codigoPersonal){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_pers", codigoPersonal);
		
		List<Map<String, Object>> listaEspecialistas = this.consultaService.consultarPersonal(params);
		if(!listaEspecialistas.isEmpty()){
			return listaEspecialistas.get(0);
		}
		return null;
	}
	
	/**
	 * @return the incidenciaService
	 */
	public IncidenciaService getIncidenciaService() {
		return incidenciaService;
	}

	/**
	 * @param incidenciaService the incidenciaService to set
	 */
	public void setIncidenciaService(IncidenciaService incidenciaService) {
		this.incidenciaService = incidenciaService;
	}
	
	/**
	 * @return the declaracionService
	 */
	public DeclaracionService getDeclaracionService() {
		return declaracionService;
	}
	
	/**
	 * @param declaracionService the declaracionService to set
	 */
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}
	
	/**
	 * @return the expedienteService
	 */
	public ExpedienteService getExpedienteService() {
		return expedienteService;
	}
	
	/**
	 * @param expedienteService the expedienteService to set
	 */
	public void setExpedienteService(ExpedienteService expedienteService) {
		this.expedienteService = expedienteService;
	}
	
	/**
	 * @return the participanteService
	 */
	public ParticipanteService getParticipanteService() {
		return participanteService;
	}
	
	/**
	 * @param participanteService the participanteService to set
	 */
	public void setParticipanteService(ParticipanteService participanteService) {
		this.participanteService = participanteService;
	}
	
	/**
	 * @return the catalogoAyudaService
	 */
	public CatalogoAyudaService getCatalogoAyudaService() {
		return catalogoAyudaService;
	}
	
	/**
	 * @param catalogoAyudaService the catalogoAyudaService to set
	 */
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}
	
	/**
	 * @return the operadorAyudaService
	 */
	public OperadorAyudaService getOperadorAyudaService() {
		return operadorAyudaService;
	}
	
	/**
	 * @param operadorAyudaService the operadorAyudaService to set
	 */
	public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService) {
		this.operadorAyudaService = operadorAyudaService;
	}

    /* comentado se usara el servicio de Gilmar
	public SprService getSprService() {
		return sprService;
	}

	public void setSprService(SprService sprService) {
		this.sprService = sprService;
	}
	*/

	/**
	 * @return the solicitudService
	 */
	public SolicitudService getSolicitudService() {
		return solicitudService;
	}

	/**
	 * @param solicitudService the solicitudService to set
	 */
	public void setSolicitudService(SolicitudService solicitudService) {
		this.solicitudService = solicitudService;
	}

	/**
	 * @return the soliSubsanacionDAOXA
	 */
	public SoliSubsanacionDAO getSoliSubsanacionDAOXA() {
		return soliSubsanacionDAOXA;
	}

	/**
	 * @param soliSubsanacionDAOXA the soliSubsanacionDAOXA to set
	 */
	public void setSoliSubsanacionDAOXA(SoliSubsanacionDAO soliSubsanacionDAOXA) {
		this.soliSubsanacionDAOXA = soliSubsanacionDAOXA;
	}
	
	/**
	 * @return the soliSubsanacionDAO
	 */
	public SoliSubsanacionDAO getSoliSubsanacionDAO() {
		return soliSubsanacionDAO;
	}

	/**
	 * @param soliSubsanacionDAO the soliSubsanacionDAO to set
	 */
	public void setSoliSubsanacionDAO(SoliSubsanacionDAO soliSubsanacionDAO) {
		this.soliSubsanacionDAO = soliSubsanacionDAO;
	}

	/**
	 * @return the establecimientoNoAptoService
	 */
	public EstablecimientoNoAptoService getEstablecimientoNoAptoService() {
		return establecimientoNoAptoService;
	}

	/**
	 * @param establecimientoNoAptoService the establecimientoNoAptoService to set
	 */
	public void setEstablecimientoNoAptoService(
			EstablecimientoNoAptoService establecimientoNoAptoService) {
		this.establecimientoNoAptoService = establecimientoNoAptoService;
	}

	/**
	 * @return the consultaService
	 */
	public ConsultaService getConsultaService() {
		return consultaService;
	}

	/**
	 * @param consultaService the consultaService to set
	 */
	public void setConsultaService(ConsultaService consultaService) {
		this.consultaService = consultaService;
	}

    public void setSprDAOService(SprDAOService sprDAOService)
    {
        this.sprDAOService = sprDAOService;
    }
}
