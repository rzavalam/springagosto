package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.CampoXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadXml;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.*;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumErrorMapeoCampo;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.ParserUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;


import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;



/**
 * (non-Javadoc)
 * @author amancilla
 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteComparadorService
 */
@SuppressWarnings({"rawtypes"})
public class SoporteComparadorServiceImpl implements SoporteComparadorService {

  protected final Log               log = LogFactory.getLog(this.getClass());

  @Autowired
  @Qualifier("diligencia.soporteMapeoTablasService")
  private SoporteMapeoTablasService soporteMapeoTablasService;



  /**
   * {@inheritDoc}
       */
      public List<Map<String, Object>> comparaList(List<Map<String, Object>> lstActual,
                                                 List<Map<String, Object>> lstHistorico,
                                                 EnumTablaModel enumTablaModel) throws ServiceException{

        List<Map<String, Object>> lstResultado = new ArrayList<Map<String, Object>>();

        //validacion de los datos de entrada
        if (!CollectionUtils.isEmpty(lstActual) && enumTablaModel != null) {
            for (Map<String, Object> mapAux : lstActual) {

                EntidadXml entidad = soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());
                  Map<String, Object> mapClaveAux = obtenerClave(mapAux, entidad);
                //tiene que existir el mapa de claves
                  if (!CollectionUtils.isEmpty(mapClaveAux)) {
                    Map<String, Object> mapAuxHist = Utilidades.obtenerElemento(lstHistorico, mapClaveAux);
                    if (CollectionUtils.isEmpty(mapAuxHist)) {
                      mapAuxHist = new HashMap<String, Object>();
                    }
                    lstResultado.add(comparaMap(mapAux, mapAuxHist, entidad, mapClaveAux));
                  }
            }
        }

        return lstResultado;
      }


    /**
     * {@inheritDoc}
     */
    public Map<String, Object> comparaMap(Map<String, Object> mapActual,
                                          Map<String, Object> mapHistorico,
                                          EnumTablaModel enumTablaModel) throws ServiceException {

        Map<String, Object> mapResultado = new HashMap<String, Object>();
        //validacion de los datos de entrada
        if (!CollectionUtils.isEmpty(mapActual) && enumTablaModel != null) {

            EntidadXml entidad = this.soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());
            Map<String, Object> mapClave = this.obtenerClave(mapActual, entidad);
            if (!CollectionUtils.isEmpty(mapClave)) {
                //se obtiene el mapClave del XML si de realiza la comparacion
                mapResultado = this.comparaMap(mapActual, mapHistorico, entidad, mapClave);
            }
        }

        return mapResultado;
    }


    /**
     * {@inheritDoc}
     */
    public Map<String, Object> comparaMap(Map<String, Object> mapActual,
                                          Map<String, Object> mapHistorico,
                                          Map<String, Object> mapClave,
                                          String codTabla) throws ServiceException {

        Map<String, Object> mapResultado = new HashMap<String, Object>();
        //validacion de los datos de entrada
        if (!CollectionUtils.isEmpty(mapActual)
               && !CollectionUtils.isEmpty(mapClave)
               && StringUtils.isNotBlank(codTabla)) {

            EnumTablaModel enumTablaModel = EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla);
            EntidadXml entidad = this.soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());
                //se obtiene el mapClave del XML si de realiza la comparacion
            mapResultado = this.comparaMap(mapActual, mapHistorico, entidad, mapClave);

        }

        return mapResultado;
    }
    /**
     * {@inheritDoc}
       */
      public boolean esDataCambiada(Map<String, Object> mapRegistro) throws ServiceException {

        boolean res = false; //datos nuevos
        if (!CollectionUtils.isEmpty(mapRegistro)) {
            //suponenmos que "dataOriginal" siempre sera un Map
          if (!CollectionUtils.isEmpty((Map) mapRegistro.get("dataOriginal"))) {
              //verificamos que los campos no sean solo los de auditoria
              Map mapDataOriginal = (Map)mapRegistro.get("dataOriginal");
              for (Object key : mapDataOriginal.keySet()){
                    // campos modificados deben ser diferentes a los campos de
                    // auditoria
                    if (!ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS" },
                            key.toString())) {

                        res = true; // datos originales modificados basta que
                                    // halla 1 difernete a los campos
                                    // mencionados
                      break;
                  }
          }
        }
      }

          return res;
        }


    /**
     * {@inheritDoc}
       */
    public Map<String, Object> obtenerElementoMapXPkTabla(List<Map<String, Object>> listData,
                                                          Map<String, Object> mapDataBusqueda,
                                                          EnumTablaModel enumTablaModel) throws ServiceException{

            Map<String, Object> mapaPkTabla = this.obtenerClave(mapDataBusqueda, enumTablaModel);

            return Utilidades.obtenerElemento(listData, mapaPkTabla);
        }


      /**
       * Permite comparar dos mapas con la estructura de TABLAS
       * con las reglas definidas en el XML:
       * 1. mapActual y mapHistorico sin prefijos html
       * 2. mapActual y mapHistorico sin los keys que no se encuentren definidos
       *
       * @param Map<String, Object>  mapActual    (No debe de estar vacio)
       * @param Map<String, Object>  mapHistorico (puede ser que este VACIO)
       * @param EntidadXml entidad
       * @param Map<String, Object> mapClave      (No debe de estar vacio)
       * @return Map[String, Object] mapResultado (key de los campos que han sido modificados aqui si aparecen los campos nuevos)
       *                             key adicionales:
       *                             1-mapResultado.put("clave", mapClave)
       *                             2-mapResultado.put("dataOriginal", mapDatosOriginales) devuelve los valores originales
       *                                                                                     de los datos campos modificados
       *                                                                                     solo de los campos modificados
       *                                                                                     comunes a ambos mapas no aparecen
       *                                                                                     los campos nuevos insertados.
       *                            4-mapResultado.put("dataModificados",mapDatosModificados)
       *                            5-mapResultado.put("tipoOperacionBD",=N (Update) o M (Insert),
       *                            "S" (sin cambio nada solo los de auditoria no se considera como para ejecutar un UPDATE)
       *                            mapResultado devolver Map Empty Si no tienes el mismo valor de clave
       *
       * @throws Exception
       */
      private Map<String, Object> comparaMap(Map<String, Object> mapActual,
              Map<String, Object> mapHistorico,
              EntidadXml entidad,
              Map<String, Object> mapClave) throws ServiceException {


          if (log.isDebugEnabled()) {
              log.debug("***********Input************");
              log.debug("Tabla:"+entidad.getNombre());
              log.debug("mapActual:"+ mapActual);
              log.debug("mapHistorico:"+mapHistorico);
          }


        Map<String, Object> mapResultado       = new HashMap<String, Object>();
        Map<String, Object> mapDatosOriginales = new HashMap<String, Object>();
        Map<String, Object> mapDatosModificados = new HashMap<String, Object>();

        //validacion de datos de entrada
        if (entidad != null && !CollectionUtils.isEmpty(mapActual)
                && !CollectionUtils.isEmpty(mapClave) ) {

                // cambiamos los datos del MapActual sin prefijos html
                Map<String, Object> mapaAuxActual = ParserUtil.obtenerMapSinPrefijo(mapActual);
                Map<String, Object> mapaAuxOrigen;
                // obtenemos la entidad a usar desde xml
                if (!CollectionUtils.isEmpty(mapHistorico)) {
                    // cambiamos datos del MapHistorico
                    mapaAuxOrigen = ParserUtil.obtenerMapSinPrefijo(mapHistorico);
                    mapaAuxOrigen = this.validarMapEntidad(mapaAuxOrigen, entidad);
                } else {
                    mapaAuxOrigen = new HashMap<String, Object>();
                }
                // CAMBIAMOS LOS KEYS DE CLAVE, necesario para evitar se compare
                // los datos de la clave
                mapClave = this.validarMapEntidad(mapClave, entidad);
                mapaAuxActual = this.validarMapEntidad(mapaAuxActual, entidad);
                if (!CollectionUtils.isEmpty(mapaAuxOrigen)) {

                    // 956 amancillaa se agrega validacion de valores del PK
                    // deben ser iguales para los registros Modificados
                    if(!isValorClaveIgual(mapaAuxActual,mapaAuxOrigen,mapClave)){
                        return new HashMap<String, Object>();
                    }

                    for (Entry<String, Object> entradaActual : mapaAuxActual.entrySet()) {
                      //campos que no esten dentro de la clave de la tabla
                        if (!mapClave.containsKey(entradaActual.getKey().trim())) {
                         // si contine el key solo en el Mapa nuevo
                            if (!mapaAuxOrigen.containsKey(entradaActual.getKey())) {
                                // En caso no se tenga el KEY en el mapa Origen
                                // se agrega el Key con el nuevo valor
                                // Tener en cuenta que ya se hizo evaluacion
                                // previa de que se contenga el key
                                // dentro de la definicion de la tabla dentro
                                // del XML
                                //TODO : deberia de comentarse la linea de abajo
                                // ya que los mismos datos se guardan mapDatosModificados
                                // cuando se migre se deberia de quitar

                                //antes comparo con el valor por defecto del historico
                                //del campo
                                //amancilla
                                    CampoXml campo = soporteMapeoTablasService.getCampo(entradaActual.getKey(), entidad);
                                    Object objHistoricoValorDefacult = ParserUtil.obtenerObjeto(campo.getDataDefault(), campo.getTipoDato(), campo.getFormato());
                                    if (this.existeDiferencia(entradaActual.getValue(),objHistoricoValorDefacult)) {
                                        mapResultado.put(entradaActual.getKey(), entradaActual.getValue());
                                        //956 mapa guarda los datos modificados
                                        mapDatosModificados.put(entradaActual.getKey(), entradaActual.getValue());
                                    }
                                //fin mancillaa
                            } else { // si contine el key en ambos mapas
                             // compara los valores mapa nuevo, historico si llega aqui ambos valores tienen datos
                                if (this.existeDiferencia(entradaActual.getValue(),mapaAuxOrigen.get(entradaActual.getKey()))) {
                                    mapResultado.put(entradaActual.getKey(), entradaActual.getValue());
                                    //956 mapa guarda los datos modificados
                                    mapDatosModificados.put(entradaActual.getKey(), entradaActual.getValue());
                                    mapDatosOriginales.put(entradaActual.getKey(), mapaAuxOrigen.get(entradaActual.getKey()));
                                }
                            }
                        }else{ //TODO:los campos PK deben grabarse en el MAP pq no parecen en el WHERE de los uodate probisionalmete
                            mapResultado.put(entradaActual.getKey(), entradaActual.getValue());
                            //ojo que esta mal pq los campos clave no deberian de grabarse como modificados en ofi_recti
                        }
                    }
                } else {
                    //registro nuevo
                    mapResultado = new HashMap<String, Object>(mapaAuxActual);
                    //956 mapa guarda los datos modificados
                    mapDatosModificados = new HashMap<String, Object>(mapaAuxActual);
                }

                mapResultado.put("dataOriginal", mapDatosOriginales); //devuleve vacio si mapHistorico no tiene datos
                mapResultado.put("clave", mapClave);

                //pase 956 aqui debemos considerar que los datos de auitoria no se considera como data cambiada
              //amancilla no tocar si esta parte los datos modificados tiene que ir antes
                mapResultado.put("dataModificados", mapDatosModificados);
                mapResultado.put("tipoOperacionBD",esDataCambiada2(mapResultado));
                // favor de no habilita este campo hace varios a�os que los comente vuelve aparece mapResultado.put("dataModificados", mapDatosModificados);
        }


        if (log.isDebugEnabled()) {
            log.debug("***********Ouput************");
            log.debug("mapResultado:"+mapResultado);
        }

        return mapResultado;
    }





      /**
       * Proceso       : Metodo evalua mapaAuxActual y mapaAuxOrigen tengan valor de clave iguales
       *
       * @param mapaAuxActual
       * @param mapaAuxOrigen
       * @param mapClave
       * @return boolean
       *
       * @autor: amancillaa
       */
      private boolean isValorClaveIgual(Map<String, Object> mapaAuxActual, Map<String, Object> mapaAuxOrigen, Map<String, Object> mapClave) {

          boolean valorClaveIgual = true;
          for (Entry<String, Object> keyClave : mapClave.entrySet()) {

              if (this.existeDiferencia(mapaAuxActual.get(keyClave.getKey()),mapaAuxOrigen.get(keyClave.getKey()))) {
                  valorClaveIgual = false;
              }
          }
        return valorClaveIgual;
    }


    /**
       * Verifica si dos objectos son iguales, teniendo como base el
       * tipo de dato del objeto historico.
       *
       * @param objActual
       * @param objHistorico
       * @return
       */
      private boolean existeDiferencia(Object objActual, Object objHistorico) {
        boolean banderaDif = false;
        try {
          if (objHistorico instanceof java.math.BigDecimal) {
            banderaDif = 0 == ((BigDecimal) objActual).compareTo((BigDecimal) objHistorico);
          } else if (objHistorico instanceof java.lang.Integer) {
            banderaDif = 0 == ((Integer) objActual).compareTo((Integer) objHistorico);
          } else if (objHistorico instanceof java.lang.Long) {
            banderaDif = 0 == ((Long) objActual).compareTo((Long) objHistorico);
          } else if (objHistorico instanceof java.lang.Double) {
            banderaDif = 0 == ((Double) objActual).compareTo((Double) objHistorico);
          } else if (objHistorico instanceof java.math.BigInteger) {
            banderaDif = 0 == ((BigInteger) objActual).compareTo((BigInteger) objHistorico);
          } else if (objHistorico instanceof java.sql.Date) {
            //banderaDif = 0 == ((java.sql.Date) objActual).compareTo((java.sql.Date) objHistorico);
            //COMPARA SOLO FECHA
            banderaDif =  SunatDateUtils.sonIguales((java.sql.Date)objActual,(java.sql.Date) objHistorico,SunatDateUtils.COMPARA_SOLO_FECHA);
          } else if (objHistorico instanceof java.util.Date) {
            //COMPARA SOLO FECHA
            banderaDif =  SunatDateUtils.sonIguales((java.util.Date)objActual,(java.util.Date) objHistorico,SunatDateUtils.COMPARA_SOLO_FECHA);
          } else if (objHistorico instanceof java.lang.String) {
              //quitamos los espacios en blanco para que pueda comparar

              //inicio-amancilla-PAS20155E220200035
              //banderaDif = objActual.toString().trim().equals(objHistorico.toString().trim());
              banderaDif = (objActual.toString().trim().toUpperCase()).equals(objHistorico.toString().trim().toUpperCase());
              //fin-amancilla-PAS20155E220200035

          } else if (objHistorico == null) {
            //compararlo con el valor por defecto
              banderaDif = objActual.toString().trim().equals(objHistorico.toString().trim());
          } else {
               if (log.isDebugEnabled()) {
                   StringBuilder sb = new  StringBuilder();
                   sb.append("NO SE ENCONTRO COMPARACION PARA objActual:");
                   sb.append( SojoUtil.toJson(objActual));
                   sb.append("- objHistorico:");
                   sb.append( SojoUtil.toJson(objHistorico));
                   log.debug(sb.toString());
               }
          }
        } catch (Exception e) {
          e.printStackTrace();

          if (log.isDebugEnabled()) {
              StringBuilder sb = new  StringBuilder();
              sb.append("NO SE ENCONTRO COMPARACION PARA objActual:");
              sb.append( SojoUtil.toJson(objActual));
              sb.append("- objHistorico:");
              sb.append( SojoUtil.toJson(objHistorico));
              log.debug(sb.toString());
          }
        }
        return !banderaDif;
      }



   public boolean esCampoClave(String nombreTabla,String nombreCampo)
   {
     EnumTablaModel enumTablaModel = EnumTablaModel.getEnumTablaModelPorNombreTabla(nombreTabla);
     EntidadXml entidad = this.soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());

        return soporteMapeoTablasService.esCampoClave(nombreCampo, entidad);
    }

  /**
   * Obtener clave.
   *
   * @param mapDato [Map<String,Object>] map dato
   * @param enumTablaModel [EnumTablaModel] enum tabla model
   * @return  [Map<String,Object>] map
   * @author  amancilla
   * @version 1.0
   */
      private Map<String, Object> obtenerClave(Map<String, Object> mapDato, EnumTablaModel enumTablaModel) {

            EntidadXml entidad = this.soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());

            return obtenerClave(mapDato, entidad);
        }

      /**
   * Permite obtener un mapa con los datos de la clave de una tabla registrados en el XML
   * los valores de las claves son llenados con valores del mapa mapDato.
   * Si key no refistrador en el XML devuelve VACIO
       *
   * @param mapDato [Map<String,Object>] map dato
   * @param entidad [EntidadXml] entidad
   * @return Map<String, Object> mapClave ejemplo ["NUM_CORREDOC",'XXXXX']
   * SI (key no registrado) devuelve VACIO
   * @author  amancilla
   * @version 1.0
       */
      private Map<String, Object> obtenerClave(Map<String, Object> mapDato, EntidadXml entidad) {

        Map<String, Object> mapClave = new HashMap<String, Object>();
        //validacion de dtaos de entrada
        if (!CollectionUtils.isEmpty(mapDato) && !CollectionUtils.isEmpty(entidad.getLstClave())) {

        	mapDato = Utilidades.adaptarParametrosBD(mapDato); //RIN 13/
        	
            for (String keyClave : entidad.getLstClave()) {
              if (mapDato.containsKey(keyClave.trim().toUpperCase())){ /*RIN 13*/    	  
   		      //if (mapDato.containsKey(keyClave.trim())) { 
                
                mapClave.put(keyClave.trim(), mapDato.get(keyClave.trim()));
                } else { //si no cumple un solo campo key devulve vacio
                return new HashMap<String, Object>();
              }
            }
        }

        return mapClave;
      }


      /**
       * Permite obtener un objeto desde una entrada segun el campo definido
       * en la entidad configurada en el archivo XML.
       *
       * @param entrada
       * @param campo
       * @param EntidadXml
       * @return
       * @throws Exception
       */
      private Object obtenerValorCampo(Entry<String, Object> entrada, CampoXml campo, EntidadXml EntidadXml)
          throws ServiceException
     {
        Object obj = null;
        if (log.isDebugEnabled())
        {
          StringBuilder sb = new StringBuilder(this.toString());
          sb.append("Nombre:");
          sb.append(campo.getNombre());
          log.debug(sb.toString());
        }

        if (this.poseeError(entrada, campo)) {
          // Si posee error y es una clave primaria se arroja una exception
          if (soporteMapeoTablasService.esCampoClave(campo.getNombre(), EntidadXml)) {
            throw new ServiceException(this, "Error en un campo clave de la entidad: " + EntidadXml.getNombre() + " :: "
                + campo.getNombre());
          } else {
            // si no es campo clave y se dio un error se setea el valor por defecto
            obj = ParserUtil.obtenerObjeto(campo.getDataDefault(), campo.getTipoDato(), campo.getFormato());
          }
        } else {
          // si no hay errores se obtiene el objeto
          //se considera el caso cuando envian un dato "" y el IBATIS lo considera como NULL
          if(entrada.getValue().toString().equals(""))
          {
            obj = ParserUtil.obtenerObjeto(campo.getDataDefault(), campo.getTipoDato(), campo.getFormato());
          }
          else
          {
            obj = ParserUtil.obtenerObjeto(entrada.getValue(), campo.getTipoDato(), campo.getFormato());
          }
        }
        return obj;
      }


      /**
       * Indica si existe error en un campo.
       *
       * @param entrada
       * @param campo
       * @return
       */
      private boolean poseeError(Entry<String, Object> entrada, CampoXml campo) {
        boolean bandera = false;
        // recorre la lista de errores declarados para el campo
        for (String cadenaError : campo.getLstError()) {
          // validamos dato
          bandera = validaErrorCampo(entrada.getValue(), cadenaError, campo.getFormato());
          if (bandera) {
            break;
          }
        }
        return bandera;
      }


      /**
       * Permite validar un objeto segun un error y formato.
       *
       * @param objValidar
       * @param cadenaError
       * @param formato, opcional. En caso de fechas si no tiene
       * un formato por defecto asumira el formato dd/MM/yyyy
       * @return
       */
      private boolean validaErrorCampo(Object objValidar, String cadenaError, String formato) {
        if (cadenaError.equals(EnumErrorMapeoCampo.ERROR_NULL.getPrefijo())) {
          if (null == objValidar || objValidar.toString().trim().equals("null")
              || objValidar.toString().trim().equals("'null'")) {
            return true;
          }
        }
        if (cadenaError.equals(EnumErrorMapeoCampo.ERROR_VACIO.getPrefijo())) {
          if (objValidar.toString().trim().equals("") || objValidar.toString().trim().equals("''")) {
            return true;
          }
        }
        if (cadenaError.equals(EnumErrorMapeoCampo.ERROR_CERO.getPrefijo())) {
          if (objValidar.toString().trim().equals("0")) {
            return true;
          }
        }
        if (cadenaError.equals(EnumErrorMapeoCampo.ERROR_NEGATIVO.getPrefijo())) {
          if (NumberUtils.isNumber(objValidar.toString()) && -1 < objValidar.toString().indexOf("-")) {
            return true;
          }
        }
        if (cadenaError.equals(EnumErrorMapeoCampo.ERROR_FECHA.getPrefijo())) {
          if (objValidar != null) {
            try {
              FechaBean fecha = new FechaBean();
              if (0 == formato.trim().length()) {
                fecha = new FechaBean(objValidar.toString());
              } else {
                fecha = new FechaBean(objValidar.toString(), formato);
              }
            } catch (Exception e) {
              return false;
            }
          }
        }
        return false;
      }


      /**
       * Permite validar un Mapa con su Entidad. Retira los keys que no se encuentren definidos dentro de la Entidad del
       * xml.
       *
       * @param mapa
       * @param EntidadXml
       * @return
       * @throws Exception
       */
      public Map<String, Object> validarMapEntidad(Map<String, Object> mapa, String codTabla)
          throws ServiceException {


        EnumTablaModel enumTablaModel = null;

        if (StringUtils.contains(codTabla, "T0"))
        {
          enumTablaModel = EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla);
        }else
        {
          enumTablaModel = EnumTablaModel.getEnumTablaModelPorNombreTabla(codTabla);
        }

        EntidadXml entidad = this.soporteMapeoTablasService.getEntidad(enumTablaModel.getIdentificadorXML());

        return validarMapEntidad(mapa,entidad);
      }

      /**
       * Permite validar un Mapa con su Entidad. Retira los keys que no se encuentren definidos dentro de la Entidad del
       * xml.
       *
       * @param mapa
       * @param EntidadXml
       * @return
       * @throws Exception
       */
      private Map<String, Object> validarMapEntidad(Map<String, Object> mapa, EntidadXml EntidadXml)
          throws ServiceException {
        Map<String, Object> mapResultado = new HashMap<String, Object>();
        if (!CollectionUtils.isEmpty(mapa))
        {
          for (Entry<String, Object> entradaActual : mapa.entrySet())
          {
            CampoXml campoAux = soporteMapeoTablasService.getCampo(entradaActual.getKey(), EntidadXml);
            if (null != campoAux) {
              mapResultado.put(campoAux.getNombre(), this.obtenerValorCampo(entradaActual, campoAux, EntidadXml));
            }
          }
        }

        return mapResultado;
      }




      /**
         * Evalua el mapa diferencias despues de una comparacion entre mapas
         *
         * @param mapRegistro [Map<String,Object>] map registro
         * @return  [String] devuleve REGISTRO_NUEVO,REGISTRO_MODIFICADO,REGISTRO_SIN_CAMBIOS
         * @throws ServiceException
         * @author  amancilla
         * @version 1.0
         */
        private String esDataCambiada2(Map<String, Object> mapRegistro) throws ServiceException {
            String res = "";
            if (!CollectionUtils.isEmpty(mapRegistro)) {
                //suponenmos que "dataOriginal" siempre sera un Map
              if (!CollectionUtils.isEmpty((Map) mapRegistro.get("dataOriginal"))) {
                  //verificamos que los campos no sean solo los de auditoria
                  Map mapDataOriginal = (Map)mapRegistro.get("dataOriginal");
                  for (Object key : mapDataOriginal.keySet()){
                      //campos modificados deben ser diferentes a los campos de auditoria
                      if (!ArrayUtils.contains(new String[] { "FEC_MODIF", "FEC_REGIS", "COD_USUMODIF", "COD_USUREGIS" }, key.toString())) {
                          //datos originales modificados basta que halla 1 difernete a los campos mencionados
                          res = REGISTRO_MODIFICADO;
                          break;
                      }else{
                          res = REGISTRO_SIN_CAMBIOS;
                                }
                            }
              }else{ //dataoriginal esta vacio puede que sea nuevo
                  if (!CollectionUtils.isEmpty((Map) mapRegistro.get("dataModificados"))) { //tiene datos modificados
                      res = REGISTRO_NUEVO; //si no tiene mapa de datos Origen se entiende que es nuevo
                  }else{
                      res = REGISTRO_SIN_CAMBIOS;
                        }
                    }
            }else{ //si no tiene data
                res = REGISTRO_SIN_CAMBIOS;
                    }
            return res;
        }



}


