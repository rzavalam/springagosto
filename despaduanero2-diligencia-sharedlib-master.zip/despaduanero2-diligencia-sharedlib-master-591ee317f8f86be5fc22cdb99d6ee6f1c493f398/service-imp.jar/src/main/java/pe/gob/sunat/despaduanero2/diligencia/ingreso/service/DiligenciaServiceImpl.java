package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.springframework.dao.DuplicateKeyException;
//ggranados 179 no se usa
//import javax.swing.plaf.ListUI;

//ggranados 179 no se usa
//import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//ggranados 179 no se usa
//import org.mockito.internal.util.ListUtil;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
//ggranados 179 no se usa
//import org.springframework.web.util.WebUtils;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.bean.ResCabBean;
import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Estabnoapto;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.EstabnoaptoDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.PitTipoPlazos;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.PitTipoPlazosDAO;
import pe.gob.sunat.despaduanero2.asignacion.bean.Aduana;
import pe.gob.sunat.despaduanero2.asignacion.bean.BandejaDocu;
import pe.gob.sunat.despaduanero2.asignacion.bean.CabDeclara;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatTurno;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDespa;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDocu;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroEspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.bean.GrupoTrabajo;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.asignacion.bean.Aduana;
import pe.gob.sunat.despaduanero2.asignacion.bean.Regimen;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.BandejaDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.CatEmpleadoDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionManualService;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.asignacion.util.ListaUtil;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataAtributo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen.CertiOrigenElectronicoService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService;
//P46
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;//RIN 14
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.CodigoLiberatorioService;//P46-PAS20155E410000032-[jlunah]
import pe.gob.sunat.estrategico2.aduanero.vuce.model.acuerdo.DocCertificadoOrigen;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ExigibilidadService;
// RIN16
/* PAS20145E220000399 INICIO GGRANADOS */
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ExigibilidadService;
/* PAS20145E220000399 FIN GGRANADOS */
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarFormatoAService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarGeneralService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
//ggranados 179 no se usa
/*
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
*/
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DescripcionOtroCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DetCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiAdmTemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescripOtrosDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtpaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.service.DocAutAsociadoService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DetalleComunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.MensajeAviso;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ReconocimientoFisicoOficio;
//pase 472
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MercanciaDispuestaDAO;

/* PAS20145E220000399 INICIO GGRANADOS */
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.IncidenciaBean;
/* PAS20145E220000399 FIN GGRANADOS */
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.RegularizacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.BusquedaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Incidencia;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabAdiDiligVincDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ComunicacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ConsultaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ReferenciaDudaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.TabBolQuimDAO;
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
import pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.RectificacionAbstract;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Comparador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.StringUtil; //RIN 14
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.Datado;
import pe.gob.sunat.despaduanero2.manifiesto.model.Equipamiento;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;//juazor
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.MovimientoCargaParti;
import pe.gob.sunat.despaduanero2.manifiesto.model.MovimientoDeEquipamiento;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DatadoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.MovCargaPartiDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.MovEquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2Service;
//ggranados 179 no se usa
//import pe.gob.sunat.despaduanero2.manifiesto.service.EquipamientoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoDeTransporteService; //juazor
/* PAS20145E220000399 INICIO GGRANADOS */
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.SolicitudPecoAmazonia;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.multa.service.MultaService;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.service.SolicitudPecoAmazoniaService;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//ggranados 179 no se usa
//import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionPecoAmazoniaService;
//ggranados 179 no se usa
/*
import pe.gob.sunat.recauda2.genadeudo.model.CabDocliq;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
*/
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
//ggranados 179 no se usa
//import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
// RIN16
// RIN16
//P13 INICIO JMCV
//ggranados 179 no se usa
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
//ggranados 179 no se usa
/*
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataAtributo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
import pe.gob.sunat.administracion2.tramite.util.ConstantesTramite;
*/
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import net.sf.sojo.interchange.json.JsonSerializer;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetalleComunicacionDAO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_MOTIVO_NOTIFICACION_02;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_MOTIVO_NOTIFICACION_03;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_MOTIVO_NOTIFICACION_05;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_MOTIVO_NOTIFICACION_08;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_DILIGENCIA;
import static pe.gob.sunat.estrategico2.aduanero.vuce.util.Constantes.INDICADOR_CERT_ELECTRONICO;
import static pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto.INDICADOR_DE_ELIMINACION_FALSO;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.EspecialistaService;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;

import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.ParameterMode;


/**
 * The Class DiligenciaServiceImpl.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DiligenciaServiceImpl implements DiligenciaService
{
  protected final Log                log = LogFactory.getLog(getClass());

  private CabDiligenciaDAO           cabDiligenciaDAO;

  private IncidenciaService          incidenciaService;

  private ComunicacionDAO            comunicacionDAO;

  private CabDeclaraDAO              cabDeclaraDAO;

  private DetDeclaraDAO              detDeclaraDAO;

  private ObservacionDAO             observacionDAO;

  private CabCertiOrigenDAO          cabCertiOrigenDAO;

  private DocAutAsociadoDAO          docAutAsociadoDAO;

  private LiquidaDeclaracionService  liquidaDeclaracionService;

  private MultaService               multaService;

  private GrabarContingentesService  grabarContingentesService;

  private ItemFacturaDAO             itemFacturaDAO;

  private SeriesItemDAO              seriesItemDAO;

  private ReferenciaDudaDAO          referenciaDudaDAO;

  private EspeDocuDAO                espeDocuDAO;

  private ConsultaDAO                consultaDAO;

  private CatEmpleadoDAO             catEmpleadoDAO;

  private VehiCeticoDAO              vehiCeticoDAO;

  private MontoGastoDAO              montoGastoDAO;

  private TabBolQuimDAO              tabBolQuimDAO;

  private FormBProveedorDAO          formBProveedorDAO;

  private FormBMontoDAO              formBMontoDAO;

  private ComprobPagoDAO             comprobPagoDAO;

  private CondicionTransaDAO         condicionTransaDAO;

  private ParticipanteDocDAO         participanteDocDAO;

  private PitTipoPlazosDAO           pitTipoPlazosDAO;

  private FabricaDeServicios         fabricaDeServicios;

  private PlazosProcesoDAO           plazosProcesoDAO;

  private CabAdiAdmTemDAO            cabAdiAdmTemDAO;

  private Datado2Service             datadoService;

  private DocuPreceDuaDAO            docuPreceDuaDAO;

  private HotSwappableTargetSource   swapperDatasource;

  private EstabnoaptoDAO             estabnoaptoDAO;

  private RectiOficioDAO             rectiOficioDAO;

  private SequenceDAO                sequenceDAO;

  private ConvenioSerieDAO           convenioSerieDAO;

  private FacturaSerieDAO            facturaSerieDAO;

  private FormaFactuDAO              formaFactuDAO;

  private DetAutorizacionDAO         detAutorizacionDAO;

  private CabSolrectiDAO             cabSolrectiDAO;

  private CatalogoAyudaService       catalogoAyudaService;

  private DetAdiAtpaDAO              detAdiAtpaDAO;

  private SoporteService             soporteService;

  private CabAdiDiligVincDAO         cabAdiDiligVincDAO;
// RIN16
//  private PublicacionAvisoService    publicacionAvisoService;

  private GrabarGeneralService       grabarGeneralService;

  private GrabarDeclaracionService   grabarDeclaracionService;

  private SoporteComparadorService   soporteComparadorService;

  private RectificacionOficioService rectificacionOficioService;

  private DiligenciaCulminacionPecoService diligenciaCulminacionPecoService;
  
  private VehiCeticoService vehiCeticoService;//jenciso ceticos parte1

  //<refactor>
  private ParticipanteService participanteService;
//P13 INICIO JMCV
  private AsignacionManualService    asignacionManualService;
  private ResolucionService			 resolucionService;	
  /* PAS20145E220000399 INICIO GGRANADOS */
//  private ConstantesAtributo		 constantesAtributo;
  /* PAS20145E220000399 FIN GGRANADOS */
  private DocumentoInternoService    documentoInternoService;
  private AyudaServiceDataAtributo	 ayudaServiceDataAtributo;
  private DiligenciaService    		 diligenciaService;
  private SerieService               serieService;
  private DeclaracionService         declaracionService;
//P13 FIN JMCV  
/*RIN13FSW-INICIO*/
//inicio-FSW
//  private FormBItemDescriDAO       formBItemDescriDAO;
  
  private MovEquipamientoDAO movEquipamientoDAO;//juazor
  
  /* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//  private MovimientoDeEquipamiento movimientoDeEquipamiento;//juazor
  /* PAS20145E220000399 INICIO GGRANADOS */
  
  /* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//  private Manifiesto manifiesto;//juazor
  /* PAS20145E220000399 INICIO GGRANADOS */
//<EHR>
  private MovCargaPartiDAO movCargaPartiDAO;
  private DatadoDAO datadoDAO;
//</EHR>
  /* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//  private Equipamiento equipamiento;//juazor
  /* PAS20145E220000399 FIN GGRANADOS*/
 /*RIN13FSW-FIN*/
  //inicio CU 14.15
  private VFOBProvisionalDAO         vFOBProvisionalDAO;
  
  private FormBItemDescriDAO         formBItemDescriDAO;

  //fin CU 14.15


	private PagarantiaDAO pagarantiaDAO;//PAS20165E220200032

  // hosorio asignacion en bloque
   private AsignacionService asignacionService;
   private IndicadorDUADAO indicadorDUADAO;
   //ggranados rollback regu
   private OrquestadorDiligenciaService orquestadorDiligenciaService;
   //Hajalcri�a
   private DescripOtrosDAO descripOtrosDAO;
   
  //fin CU 14.15
/*RIN13FSW-INICIO*/
//fin-FSW

/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//juazor  
//private DocumentoDeTransporteService documentoDeTransporteService;
/* PAS20145E220000399 FIN GGRANADOS */

/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
   //juazor   
//public void setDocumentoDeTransporteService(
//		DocumentoDeTransporteService documentoDeTransporteService) {
//	this.documentoDeTransporteService = documentoDeTransporteService;
//}
/* PAS20145E220000399 INICIO GGRANADOS */
 /*RIN13FSW-FIN*/
//pase 427
private static final String FORMAT_ddMMyyyy = "dd/MM/yyyy";
public static final String INDICADOR_CERT_ELECTRONICO = "1"; //PAS20181U220200056
   
  private MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService;//RIN 14
  /**
   * {@inheritDoc}
   */
  public void notificarObservacion(
                                   String descripcion,
                                   String codAduana,
                                   String annPresen,
                                   String codRegimen,
                                   String numDeclaracion,
                                   String codFuncionario,
                                   String[] codUsuario,
                                   Integer codPlantilla,
                                   String codTipoAviso,
                                   String tipoUsuario,
                                   String tipo)
  {
    FechaBean fechaPublicacion = new FechaBean();

    FechaBean fechaVigencia = new FechaBean();

    fechaVigencia.setFecha("31/12/9999");

    Map<String, Object> mapMensaje = new HashMap<String, Object>();
/*RIN13FSW-INICIO*/
	Map<String, Object> params = new HashMap<String, Object>();
	params.put("COD_ADUANA", codAduana);
	params.put("ANN_PRESEN", annPresen);
	params.put("COD_REGIMEN", codRegimen);
	params.put("NUM_DECLARACION", numDeclaracion);

    //obtener el consignatario RIN13
	String numCorreDoc = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
    String consignatario = diligenciaService.obtenerConsignatario(codAduana,annPresen,codRegimen,numDeclaracion,numCorreDoc);
    
    mapMensaje.put("des_consignatario", consignatario);
/*RIN13FSW-FIN*/
    mapMensaje.put("cod_usuario", codUsuario);
    mapMensaje.put("funcionario", codFuncionario);
    mapMensaje.put("des_asunto", obtenerAsunto(codPlantilla)); 

    mapMensaje.put("tip_usuario", tipoUsuario);

    mapMensaje.put("des_intendencia", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));

    if (descripcion != null)
    {
      mapMensaje.put("descripcion", descripcion);
    }
    mapMensaje.put("cod_aduana", codAduana);
    mapMensaje.put("ann_presen", annPresen);
    mapMensaje.put("cod_regimen", codRegimen);
    mapMensaje.put("num_declaracion", numDeclaracion);
    //Obtener ruc - razon social (Aceptacion solicitud regularizacion) RIN16_Pase400 - Inicio
    if("PIM".equalsIgnoreCase(tipo.trim()) || "PDE".equalsIgnoreCase(tipo.trim())){
    	ExigibilidadService exigibilidadService = fabricaDeServicios.getService("declaracion.ingreso.exigibilidadService");
    	Participante agenciaAduana = null;
    	if("PIM".equalsIgnoreCase(tipo.trim())){
    		agenciaAduana = exigibilidadService.findRucParticipante(Long.parseLong(numCorreDoc), Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
    	}
    	else{
    		agenciaAduana = exigibilidadService.findRucParticipante(Long.parseLong(numCorreDoc), Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);
    	}
    	mapMensaje.put("ruc", agenciaAduana.getNumeroDocumentoIdentidad());
    	mapMensaje.put("razonsocial", agenciaAduana.getNombreRazonSocial());
    }
	//Obtener ruc - razon social (Aceptacion solicitud regularizacion) RIN16_Pase400 - Fin
    mapMensaje.put("fecha_emision",
                   new StringBuilder(fechaPublicacion.getDia()).
                                                               append("/").append(fechaPublicacion.getMes()).
                                                               append("/").append(fechaPublicacion.getAnho())
                                                               .toString());

    StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
// RIN16
    PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
    publicacionAvisoService.insert(codPlantilla, data, codTipoAviso,
                                   fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());

  }

  /*P14 - 3006 - dhernandezv - Inicio */
  
  /**
   * {@inheritDoc}
   */
  public void notificarObservacionReporteAdjunto(
		  String descripcion,
		  String codAduana,
          String annPresen,
          String codRegimen,
          String numDeclaracion,
          String codFuncionario,
          String[] codUsuario,
          Integer codSecuencia,
          String codTipoAviso,
          String tipoUsuario,
          String codEstado,
          HashMap<String, Object> rutaPDF,String tipo)
	{
	FechaBean fechaPublicacion = new FechaBean();
	
	FechaBean fechaVigencia = new FechaBean();
	
	fechaVigencia.setFecha("31/12/9999");
	
	Map<String, Object> mapMensaje = new HashMap<String, Object>();
        //pase p14 - pase108 //pase p14 - pase108 -diligencia de conclusion
	
	if(207 == codSecuencia){
		mapMensaje.put("des_asunto", obtenerAsunto(codSecuencia));
	} else if (codEstado.equals(Constantes.ESTADO_CONCLU_NOTIFICADO)){
		mapMensaje.put("des_asunto", obtenerAsunto(Constantes.COD_PL_NOTI_DILIG_CONCLUSION));
	} else {
		mapMensaje.put("des_asunto", obtenerAsunto(codSecuencia));
	}
	
	mapMensaje.put("cod_usuario", codUsuario);
	mapMensaje.put("tip_usuario", tipoUsuario);
	mapMensaje.put("funcionario", codFuncionario);
	//mapMensaje.put("des_asunto", obtenerAsunto(codSecuencia));//pase p14 - pase108 -diligencia de conclusion
	mapMensaje.put("des_intendencia", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));
	if(descripcion!=null){//error cuando viene null pase 427
		  mapMensaje.put("descripcion", Utilidades.reemplazaCaracterEspecialEnHtml(descripcion)); //pase p14 - pase108 -diligencia de conclusion
	}
	mapMensaje.put("cod_aduana", codAduana);
	mapMensaje.put("ann_presen", annPresen);
	mapMensaje.put("cod_regimen", codRegimen);
	mapMensaje.put("num_declaracion", numDeclaracion);
	
	//obteniendo el emisor de la notificacion
	mapMensaje.put("elaborado_por", obtenerElaborado(codAduana));
	mapMensaje.put("mostrarPdf", ".");
	mapMensaje.put("idDocumentoWS", "0000");
	
	if(rutaPDF!=null){
		//modificar el numero de plantilla y servicio
		codSecuencia = Constantes.COD_SEC_NOTI_DECLA_PDF;
		mapMensaje.put("numIdPDF", rutaPDF.get("num_pdf"));
		mapMensaje.put("idDocumentoWS", rutaPDF.get("num_pdf").toString());
		mapMensaje.put("mostrarPdf", "PDF");
		
		/*if("-1".equals(rutaPDF.get("num_pdf").toString())){
			mapMensaje.put("mostrarPdf", "");
			mapMensaje.put("mensajeError", "LA GENERACION  DEL PDF TUVO PROBLEMAS  CON EL SERVICIO EXTERNO DE TRIBUTO");
		}*/
	}
	
	
	Map<String, Object> params = new HashMap<String, Object>();
	params.put("COD_ADUANA", codAduana);
	params.put("ANN_PRESEN", annPresen);
	params.put("COD_REGIMEN", codRegimen);
	params.put("NUM_DECLARACION", numDeclaracion);
	
	
	if (tipo.equals("PDE")){
		mapMensaje.put("desDestinatario", "Srs.");
		params.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
		mapMensaje.put("des_consignatario", this.obtenerConsignatario(params));
		//mapMensaje.put("nombreDestinatario", mapMensaje.get("cod_aduana").toString().trim() + " - "+mapMensaje.get("des_intendencia").toString().trim());
		mapMensaje.put("nombreDestinatario", mapMensaje.get("des_consignatario").toString().trim());
	}else{
		params.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE);
		mapMensaje.put("des_consignatario", this.obtenerConsignatario(params));
		mapMensaje.put("desDestinatario", "Srs.");
		mapMensaje.put("nombreDestinatario", mapMensaje.get("des_consignatario").toString().trim());
	}
	
	if(codEstado == null)
	{
		//obteniendo el consignatario o due�o    
		//mapMensaje.put("des_consignatario", obtenerConsignatario(codAduana,annPresen,codRegimen,numDeclaracion,numCorreDoc));
		//obteniendo los documentos asociados

		if (descripcion != null)
			mapMensaje.put("descripcion", Utilidades.reemplazaCaracterEspecialEnHtml(descripcion));

	}
	else if(codEstado.equals(Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE))
	{
		codSecuencia = Constantes.COD_SEC_NOTI_DECLA_MERCA_DISP_TOTAL;
		//obteniendo el consignatario o due�o
		//mapMensaje.put("des_consignatario", obtenerConsignatario(codAduana,annPresen,codRegimen,numDeclaracion,numCorreDoc));
		//obteniendo los documentos asociados
		//mapMensaje.put("des_notificacion", obtenerDetalleDocumentosAsociadosFormatoHTML(numCorreDoc));
		mapMensaje.put("des_notificacion", "");
	}
	
	mapMensaje.put("fecha_emision",
	new StringBuilder(fechaPublicacion.getDia()).
	                                      append("/").append(fechaPublicacion.getMes()).
	                                      append("/").append(fechaPublicacion.getAnho())
	                                      .toString());
	
	StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
	publicacionAvisoService.insert(codSecuencia, data, codTipoAviso,
	          fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	
	}
  
  /**
   * {@inheritDoc}
   */
  public String obtenerConsignatario(Map<String, Object> params){
	  String consignatario =".";
		Map<String, Object> participante = new HashMap<String, Object>();
		
		String numCorreDoc = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
	    participante.put("numeroCorrelativo", numCorreDoc);
	    participante.put("codTipoParticipante",  params.get("tipoParticipante"));
	    List<Participante> listaParticipante = participanteService.obtenerParticipanteByParameterMap(participante);
	    	if(listaParticipante!=null && listaParticipante.size()>0){
	    		return listaParticipante.get(0).getNombreRazonSocial();
	    	}
	  return consignatario;
  }
  
  /**
   * {@inheritDoc}
   */
  public String obtenerElaborado(String codAduana){
	  String elaborador =".";
	  if(ConstantesDataCatalogo.ADUANA_PAITA.equals(codAduana) 			 || 
		   ConstantesDataCatalogo.ADUANA_SALAVERRY.equals(codAduana)  		 ||
		   ConstantesDataCatalogo.ADUANA_CHIMBOTE.equals(codAduana) 		 ||
		   ConstantesDataCatalogo.ADUANA_PISCO.equals(codAduana) 			 ||
		   ConstantesDataCatalogo.ADUANA_MOLLENDO_MATARANI.equals(codAduana) ||
		   ConstantesDataCatalogo.ADUANA_ILO.equals(codAduana))
		{			       	
		  elaborador = Constantes.NOTIFICACION_ELABORADA_TEC_ADUANERA;
		}else if (ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(codAduana)){			   
			elaborador =  Constantes.NOTIFICACION_ELABORADA_IAMC;
		}
	  return elaborador;
  }
  
  /* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//  private String obtenerDetalleDocumentosAsociadosFormatoHTML(String numCorreDoc){
//	  Map<String, String> paramsAutAsociado = new HashMap<String, String>();
//		paramsAutAsociado.put("NUM_CORREDOC", numCorreDoc);
//		
//		FechaBean fechaDocAsosciado = new FechaBean();
//		String tipoDocDispMerc; 
//		List<DatoOtroDocSoporte> listAutAsociado = docAutAsociadoDAO.find(paramsAutAsociado);
//		StringBuilder HTMLDetalle = new StringBuilder(".");
//		
//		if(listAutAsociado != null && !listAutAsociado.isEmpty()){
//			HTMLDetalle.setLength(0);
//			HTMLDetalle.append("<table class='detalleNotificacion' align='center'>");
//			HTMLDetalle.append("<tr style='width:150px;'><th> Tipo de Documento de Disp. de Merc.</th><th style='width:200px;'> Documento de Disposicion de Mercancias </th><th style='width:150px;'> Fecha de Emision </th></tr>");
//			
//			for (DatoOtroDocSoporte datoOtroDocSoporte : listAutAsociado) {		
//				tipoDocDispMerc="";
//				
//				if(!SunatStringUtils.isEmpty(datoOtroDocSoporte.getCodtipodocasoc())){
//					tipoDocDispMerc = catalogoAyudaService.getDescripcionDataCatalogo("75", datoOtroDocSoporte.getCodtipodocasoc());
//				}
//				
//				HTMLDetalle.append("<tr>");
//				HTMLDetalle.append("<td style='width:150px;'>");
//				HTMLDetalle.append(tipoDocDispMerc);
//				HTMLDetalle.append("</td>");
//				
//				HTMLDetalle.append("<td style='width:200px;'>");
//				HTMLDetalle.append(datoOtroDocSoporte.getNumdocasoc().concat(datoOtroDocSoporte.getAnndocasoc()));
//				HTMLDetalle.append("</td>");				
//				
//				HTMLDetalle.append("<td style='width:150px;'>");
//				fechaDocAsosciado.setFecha(datoOtroDocSoporte.getFecdocasoc());		
//				
//				HTMLDetalle.append(new StringBuilder(fechaDocAsosciado.getDia().toString())
//													.append("/").append(fechaDocAsosciado.getMes().toString())
//													.append("/").append(fechaDocAsosciado.getAnho()).toString());
//				HTMLDetalle.append("</td>");
//				HTMLDetalle.append("</tr>");		
//			}
//		
//			HTMLDetalle.append("</table>");
//		}
//		return HTMLDetalle.toString();    
//		
//  }
  /* PAS20145E220000399 FIN GGRANADOS NO SE USA*/
  
  /**
   * {@inheritDoc}
   */
  public List<HashMap<String, Object>> obtenerDetalleDocumentosAsociadosParaReporte(String numCorreDoc){
	  
	    Map<String, String> paramsAutAsociado = new HashMap<String, String>();
		paramsAutAsociado.put("NUM_CORREDOC", numCorreDoc);
		
		FechaBean fechaDocAsosciado = new FechaBean();
		String tipoDocDispMerc; 
		List<DatoOtroDocSoporte> listAutAsociado = docAutAsociadoDAO.find(paramsAutAsociado);		
		
		List<HashMap<String, Object>> listaDocAsociados = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> docAsociado;
		
		if(listAutAsociado != null && !listAutAsociado.isEmpty()){
			for (DatoOtroDocSoporte datoOtroDocSoporte : listAutAsociado) {
				
				docAsociado = new HashMap<String,Object>();
				tipoDocDispMerc="";
				
				if(!SunatStringUtils.isEmpty(datoOtroDocSoporte.getCodtipodocasoc())){
					tipoDocDispMerc = catalogoAyudaService.getDescripcionDataCatalogo("75", datoOtroDocSoporte.getCodtipodocasoc());
				}

				docAsociado.put("tipo_doc_disp_merc", tipoDocDispMerc);
				docAsociado.put("doc_disp_merc", datoOtroDocSoporte.getNumdocasoc().concat(datoOtroDocSoporte.getAnndocasoc()));
				
				fechaDocAsosciado.setFecha(datoOtroDocSoporte.getFecdocasoc());		
				docAsociado.put("fec_emision_doc", new StringBuilder(fechaDocAsosciado.getDia().toString())
																.append("/").append(fechaDocAsosciado.getMes().toString())
																.append("/").append(fechaDocAsosciado.getAnho()).toString());
				
				listaDocAsociados.add(docAsociado);
			}
		
		}
		return listaDocAsociados;   
  }

  @Override
	public HashMap<String,Object> obtenerConsolidadoDetalleNotificacionParaReporte(ComunicacionDescripcion notificacion) throws ServiceException {
		
		HashMap<String,Object> detalleNotificacion = new HashMap<String, Object>();
		
		//obteniendo la cabecera
		if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[0] != null && !notificacion.getDesNota().toString().trim().equals("") )
			detalleNotificacion.put("CAB_DETALLE", notificacion.getDesNota().toString().split("@_@")[0].replace("<p>", "").replace("</p>", "").replace("<br />", "\n").replace("<b>", "").replace("</b>", "").replace("<u>", "").replace("</u>", ""));
		else if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("</p>") == true && notificacion.getDesNota().toString().split("</p>")[0] != null && !notificacion.getDesNota().toString().trim().equals("") )
			detalleNotificacion.put("CAB_DETALLE", notificacion.getDesNota().toString().split("</p>")[0].replace("<p>", "").replace("</p>", "").replace("<br />", "\n").replace("<b>", "").replace("</b>", "").replace("<u>", "").replace("</u>", ""));
		else	
			detalleNotificacion.put("CAB_DETALLE", "");
		
		//obteniendo el pie
		if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[1] != null && !notificacion.getDesNota().toString().trim().equals("") )
			detalleNotificacion.put("PIE_DETALLE", notificacion.getDesNota().toString().split("@_@")[1].replace("<p>", "").replace("</p>", "").replace("<br />", "\n").replace("<b>", "").replace("</b>", "").replace("<u>", "").replace("</u>", ""));
		else if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("</p>") == true && notificacion.getDesNota().toString().split("</p>")[1] != null && !notificacion.getDesNota().toString().trim().equals("") )
			detalleNotificacion.put("PIE_DETALLE", notificacion.getDesNota().toString().split("</p>")[1].replace("<p>", "").replace("</p>", "").replace("<br />", "\n").replace("<b>", "").replace("</b>", "").replace("<u>", "").replace("</u>", ""));
		else
			detalleNotificacion.put("PIE_DETALLE", "");
		
		if(notificacion.getIndDetDescNotificacion().equals("1")){
			//obteniendo el cuerpo					
			detalleNotificacion.put("DET_NOTIFICACION", obtenerDetalleNotificacionParaReporte(notificacion));
		}
		
		detalleNotificacion.put("COD_MOTIVO_NOTI", notificacion.getCodMotNoti());
		
		return detalleNotificacion;
	}
	
	
	private List<HashMap<String, String>> obtenerDetalleNotificacionParaReporte(ComunicacionDescripcion notificacion) {

		List<HashMap<String, String>> listaDetalleNotificacion = new ArrayList<HashMap<String,String>>();
		DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
		try{
			
			DetalleComunicacion dc = new DetalleComunicacion();
			dc.setNumNota(notificacion.getNumNota());
			
			List<DetalleComunicacion> lstDetalleNotificacion = detalleComunicacionDAO.findDetalleComunicacionNotificacion(dc);
			for (DetalleComunicacion deNot : lstDetalleNotificacion) {
				HashMap<String, String> detalleNotificacion = (HashMap<String, String>) new JsonSerializer().deserialize(deNot.getDesDetalle(), HashMap.class);				
				listaDetalleNotificacion.add(detalleNotificacion);
			}
			
		} catch (DataAccessException e) {
			log.error(this.toString().concat(" obtenerDetalleNotificacionFormatPDF- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		} catch (Exception e) {
			log.error(this.toString().concat(" obtenerDetalleNotificacionFormatPDF- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}			
		return listaDetalleNotificacion;
	}
  
  /*P14 - 3006 - dhernandezv - Fin */

  /**
   * Obtener asunto.
   *
   * @param codPlantilla
   *          the cod plantilla
   * @return the string
   */
  private String obtenerAsunto(Integer codPlantilla)
  {

    switch (codPlantilla)
    {
    case 120:
      return "NOTIFICACION DE COMUNICACION DE OBSERVACIONES DE REVISION DOCUMENTARIA";
    case 121:
      return "AVISO ELECTRONICO DE RECONOCIMIENTO FISICO DE OFICIO";
    case 122:
      return "NOTIFICACION DE OBSERVACIONES DE RECONOCIMIENTO FISICO";
    case 123:
      return "MENSAJE DE DILIGENCIA DE REGULARIZACION";
    /*P14 - 3006 - dhernandez - Inicio */
    case 207:
        return "NOTIFICACION DE LA DECLARACION"; 
    case 208:
        return "RECEPCI�N DE LA RESPUESTA NOTIFICACION  DECLARACION EN ESTADO 18 - MERCANCIA DISPUESTA TOTALMENTE";
    /*P14 - 3006 - dhernandez - Fin */    
    /*P21 - P22*/     
    case 388:
        return "NOTIFICACION DE LA DECLARACION EN CONCLUSION  DE DESPACHO";
    /*P21- P22 - Fin */       
    default:
      return "";
    }
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerDiligencias(Map PkDocu) throws ServiceException
  {
    List<Map<String, Object>> lista = null;
    try
    {
      lista = cabDiligenciaDAO.findByDocumento(PkDocu);

      FiltroCatEmpleado filtro = new FiltroCatEmpleado();
      for (int i = 0; i < lista.size(); i++)
      {
        StringBuilder funcionario = new StringBuilder();
        if (((Map<String, Object>) lista.get(i)).get("FUNCIONARIO") != null)
        {
          funcionario.append(((Map<String, Object>) lista.get(i)).get("FUNCIONARIO").toString().trim());
          if (funcionario.length() > 0)
          {
            filtro.setCodPers(funcionario.toString());
            CatEmpleado empleado = catEmpleadoDAO.consultarCatEmpleado(filtro);
            funcionario.append(" - ").append(empleado.getApPate()).append(" ").append(empleado.getApMate())
                       .append(", ").append(empleado.getNombres());
            lista.get(i).put("FUNCIONARIO", funcionario.toString());
          }
        }
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

  public List obtenerDiligenciaDespachoSustentoModificado(Map PkDocu) throws ServiceException
  {
    List<Map<String, Object>> lista = null;

    try
    {
      lista = cabDiligenciaDAO.getDiligenciaDespachoSustentoModificado(PkDocu);
      // cogemos el especialista sus datos

      FiltroCatEmpleado filtro = new FiltroCatEmpleado();
      for (int i = 0; i < lista.size(); i++)
      {
        StringBuilder funcionario = new StringBuilder();
        if (((Map<String, Object>) lista.get(i)).get("FUNCIONARIO") != null)
        {
          funcionario.append(((Map<String, Object>) lista.get(i)).get("FUNCIONARIO").toString().trim());
          if (funcionario.length() > 0)
          {
            filtro.setCodPers(funcionario.toString());
            CatEmpleado empleado = catEmpleadoDAO.consultarCatEmpleado(filtro);
            funcionario.append(" - ").append(empleado.getApPate()).append(" ").append(empleado.getApMate())
                       .append(", ").append(empleado.getNombres());
            lista.get(i).put("FUNCIONARIO", funcionario.toString());
          }
        }
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerComunicacionesPortal(Map<String, String> PkDocu)
                                                                                          throws ServiceException
  {
    List<Map<String, Object>> lista = null;
    try
    {
      lista = comunicacionDAO.findByDiligenciaAndTipo(PkDocu);
    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public Boolean validarPlazo(Map params) throws ServiceException
  {
    Boolean res = new Boolean(true);

    try
    {
      PitTipoPlazos plazo =
                            this.pitTipoPlazosDAO.selectAnoMesByTipoOperacionDespa((String) params
                                                                                                  .get("tipoOperDespacho"));
      if (plazo != null)
      {
        FechaBean fValida = new FechaBean((Timestamp) params.get("fecInicial"));

        short meses = 0;
        if (plazo.getAno() != 0)
        {
          meses = new Short("" + new Short("12").shortValue() * plazo.getAno().shortValue()).shortValue();
        }
        else if (plazo.getMes() != 0)
        {
          meses = plazo.getMes().shortValue();
        }

        fValida = new FechaBean(new Timestamp(SunatDateUtils.addMonth(fValida.getSQLDate(), meses).getTime()));

        res = new Boolean(FechaBean.getDiferencia(
                                                  fValida.getCalendar(),
                                                  ((FechaBean) params.get("fecEvaluada")).getCalendar(),
                                                  Calendar.DATE) >= 0);
      }

    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return res;
  }
  //MOL PASE280
	public Map<String, Object> validarDiligenciaConDiferenciaTributo(Map params) throws ServiceException{
		
	    Map mapCabDeclaraActual = (HashMap) params.get("mapCabDeclaraActual");
	    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
	    Map<String, Object> respta = new HashMap<String, Object>();
	    List<Map<String, String>> lstError = new ArrayList<Map<String, String>>();
	    List<Map<String, String>> lstMensaje = new ArrayList<Map<String, String>>();
	    
	        Map mapParamsDilig = new HashMap();
	        mapParamsDilig.put("mapCabDeclaraActual", mapCabDeclaraActual);
	        mapParamsDilig.put("mapCabDiligenciaActual", mapDilig);
	        mapCabDeclaraActual.put("duaCancelado","S");
	        DeudaService deudaService = fabricaDeServicios.getService("diligencia.ingreso.deudaService");
	        boolean duaCancelada = deudaService.esDuaCancelada(mapCabDeclaraActual);
            if (!duaCancelada)
            {
            	mapCabDeclaraActual.put("duaCancelado","N");
            }
            
	        
	        if (!Constantes.REGIMEN_70_DEPOSITO.equals((String) mapCabDeclaraActual.get("COD_REGIMEN")))
	        { boolean tieneGarantia = !(SunatStringUtils.isEmptyTrim(mapCabDeclaraActual.get("NUM_CTACTE_DESC").toString()));
	         
	          if(tieneGarantia){
	        	  mapParamsDilig.put("duaCancelado",mapCabDeclaraActual.get("duaCancelado"));
	        	 List<Map<String, String>> respuesta  = this.liquidaDeclaracionService.validarLiqDiligenciaConGarantia160(mapParamsDilig);
	        	 
	        	 if(respuesta!=null && respuesta.size()>0){
	        		 Integer j=0;
	        		 for(Map<String,String> rs : respuesta){
	        			 j++;
	        			 if(rs.containsKey("codError")){	        
	        				 
	        				 lstError.add(rs) ;
	        			 }else{
	        				 lstMensaje.add(rs) ;
	        			 }
	        		 }
	        	 }
	           }
	        }
	        
	        respta.put("mensaje", lstMensaje);
	        respta.put("error", lstError);
	   
	      return respta;
	}
	// FIN MOL

	//ggranados rollback regu
	public Map<String, Object> grabarDiligenciaRegularizacion(Map<String, Object> params) throws Exception {
		List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
		Map<String, Object> lstValidacion = new HashMap<String, Object>();
		boolean indConfirmaDiligencia  = params.get("indConfirmaDiligencia") == null? false: (Boolean) params.get("indConfirmaDiligencia");
	
		//se llama al orquestador
		orquestadorDiligenciaService.setDeclaracion((Declaracion) params.get("objDeclaracion"));
		lstValidacion = orquestadorDiligenciaService.diligenciaDespachoDeclaracion((UsuarioBean) params.get("objUsuario"));
		listaErrores.addAll((List) lstValidacion.get("listaErrores"));
		Map<String, Object> resultado = (Map<String, Object>) lstValidacion.get("resultado");
		
	     /*** Inicio MOL ***/        
			List<Map<String, String>> lstAlertasDocAutoriza = new ArrayList<Map<String, String>>();
			List<Map<String, String>> listaErroresAux = new ArrayList<Map<String, String>>();
			listaErroresAux.addAll(listaErrores);
			List<Map<String, String>> lstSoloErrores = new ArrayList<Map<String, String>>();
		    lstSoloErrores.addAll(listaErrores);
				
		/***Inicio se cambia  Constantes.LST_ALERTAS_DILIGENCIA a catalogo 854 P_SNADE046-2127***/ 		
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listAlertasDiligencia =  catalogoAyudaService.getElementosCat(Constantes.CAT_ALERTAS_MERCRESTRINGIDAS_DILIG,SunatDateUtils.getCurrentDate());
		String alertasDiligencia = "";
		if(!CollectionUtils.isEmpty(listAlertasDiligencia)){
			for(Map<String, String> listAlertas : listAlertasDiligencia){
				alertasDiligencia+=(listAlertas.get("cod_datacat").toString())+",";
			}
		}
		if(!SunatStringUtils.isEmptyTrim(alertasDiligencia)){
			alertasDiligencia = alertasDiligencia.substring(0,alertasDiligencia.length()-1);
		} 
		/**Fin**/
		 for (Map<String, String> itemError : listaErroresAux) {
		  //if (SunatStringUtils.isStringInList( (String) itemError.get(ResponseMapManager.KEY_CODIGO) , Constantes.LST_ALERTAS_DILIGENCIA)){
		   if (SunatStringUtils.isStringInList( (String) itemError.get(ResponseMapManager.KEY_CODIGO) ,alertasDiligencia)){// P_SNADE046-2127 
		   if (indConfirmaDiligencia) {			   
			   
			   listaErrores.remove(itemError);		
			   
		   } else {	
			 lstSoloErrores.remove(itemError);
			   //listaErrores.remove(itemError);	
		     lstAlertasDocAutoriza.add(itemError);		
		     
		   }	
		  }
		 }
		 				
		 if (lstAlertasDocAutoriza.size() > 0 && lstSoloErrores.size() == 0 && !indConfirmaDiligencia){
		
		  
			 resultado.put("pendienteConfirmacion", true);		  
			 resultado.put("lstConfirmaDilig", SojoUtil.toJson(lstAlertasDocAutoriza));
			 resultado.put("recOk", false);	
		
		 } else if (indConfirmaDiligencia) {
			 resultado.put("pendienteConfirmacion", false);
			 resultado.put("mensajeRespuesta","El registro de la diligencia se realiz� correctamente.");			 
			 resultado.put("recOk", true);
		 }        
       /*** Fin  MOL**/
		
		//se llama al grabado de la diligencia
		if ((Boolean) resultado.get("recOk")) { 
			grabarDiligenciaDespacho(params);
		}
		
		return lstValidacion;
	}
 
 /**
   * {@inheritDoc}
   */
  public void grabarDiligenciaDespacho(Map params) throws ServiceException
  {
    Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
    FechaBean fecActual = new FechaBean();
    //pase 15 - 252
    if(declaracion.get("COD_LUGARRECEP") != null){
    	//declaracion.put("COD_LUGARRECEP", declaracion.get("COD_LUGARRECEP").toString().substring(0, 1));
    	//csantillan PAS20191U220200002 bug P_SNAA0004-16844
		if (SunatStringUtils.isLengthGreaterOrEqualsThanNumber(declaracion.get("COD_LUGARRECEP").toString(), 2)){
			declaracion.put("COD_LUGARRECEP", declaracion.get("COD_LUGARRECEP").toString().substring(0, 2));
		}else{
			declaracion.put("COD_LUGARRECEP", declaracion.get("COD_LUGARRECEP").toString().substring(0, 1));
		}

    }


    String flag = ""; // para saber de donde esta siendo accedido
    if (declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_CONCLU_PROCESO))
    {
      flag = "C"; // conclusion
    }

    Map<String, Object> mapaPK = new HashMap<String, Object>();

    mapaPK.put("NUM_CORREDOC", "NUM_CORREDOC");

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
                                                         + params.get("caduana").toString().trim()));
    Long numeroCorrelativo = Utilidades.toLong(declaracion.get("NUM_CORREDOC")); //RIN-13
    //Long numCorreDocSol = 0L; //RIN-13
    Integer numCorreDocSol = 0;//PAS20165E220200137
    String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
    try
    {    
    	
    	/*** Inicio Cambio PAS20155E220200192 RSV **/
    	Map resulPreliq = (Map)declaracion.get("resulPreliq");
    	if(resulPreliq!=null){//PAS20165E220200039
        	Map<String,Object> montoLC15S9 =  resulPreliq.get("montoTPILC15_SI_9")!=null ? (Map<String,Object>) resulPreliq.get("montoTPILC15_SI_9"): new HashMap<String,Object>();//PAS20165E220200039 
    		Map<String,Object> montoLC15N9 =  resulPreliq.get("montoTPILC15_NO_9")!=null ? (Map<String,Object>) resulPreliq.get("montoTPILC15_NO_9"): new HashMap<String,Object>();//adicionado por bug 837-pase192//modificado PAS20165E220200039
    		Map<String,Object> mapMontos = new HashMap<String, Object>();
    		mapMontos.put("montoLC15S9", montoLC15S9);
    		resulPreliq.put("montoLC15S9", montoLC15S9);
    		params.put("montoLC15S9", montoLC15S9);
            params.put("generarLC15_SI_9",montoLC15S9!=null &&!montoLC15S9.isEmpty()?"SI":"NO");//adicionado por bug 837-pase192
            params.put("generarLC15_NO_9",montoLC15N9!=null &&!montoLC15N9.isEmpty()?"SI":"NO");//adicionado por bug 837-pase192
    		declaracion.put("resulPreliq",resulPreliq);
    	}
		/*** fIN Cambio PAS20155E220200192 RSV **/
		
      // para diligencia despacho actualizar la informacion de contingentes
//RSERRANOV PAS20165E220200076
    	String mensaje = "";
      if (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig) || Constantes.DILIG_REGULARIZACION.equals(tipDilig) || 
    		  Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig))
      {
    	  String nroTransaccion = tipDilig;
    	  // No se debe madar el tipo de diligencia sino la transacci�n
    	  if (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig) )
          {
    		  nroTransaccion = Constantes.DILIG_DESPACHO ;
    	  
          }
    	  List<Map<String, String>> lstValidacion =  procesarGrabaContingente(params, nroTransaccion);
    	  
	    if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)||Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(tipDilig) ) {
	    	if (!CollectionUtils.isEmpty(lstValidacion)) {
	            for (Map<String, String> mapDatos : lstValidacion)
      {
	              if (mapDatos.get("codError").toString().trim().equals("XXXX")) { 
	            	  mensaje = mapDatos.get("desError").toString().trim();
	            	  break;
	              }
	            } 
	    	}
	    }
    	  
      }
//RSERRANOV PAS20165E220200076
      // Insertamos o actualizamos la DILIGENCIA
      mapDilig.put("NUM_CORREDOC", numeroCorrelativo);//declaracion.get("NUM_CORREDOC"));  //RIN-13

      if (mapDilig.get("FEC_DILIGENCIA") == null)
      {
        mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
      }

      // Mapeamos los datos para la rectificacion de oficio
      Map keyDilig = new HashMap();
      keyDilig.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
      keyDilig.put("COD_TIPDILIGENCIA", mapDilig.get("COD_TIPDILIGENCIA"));

      mapDilig.put("dataOriginal", null);
      mapDilig.put("clave", keyDilig);

      //amancilla RIN13
      mapDilig.put("LIQSOL", params.get("cb_liqsol"));
      mapDilig.put("LIQDOL", params.get("cb_liqdol"));
      //fin amancilla RIN13

      try
      {
           this.cabDiligenciaDAO.insert(mapDilig);
      }
      catch (Exception e)
      {
        log.info("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:" + SojoUtil.toJson(mapDilig),e);
        if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) ||  Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig))//DZC RIN 16
        {
          throw new ServiceException(this, e);
        }else if(Utilidades.esDiligenciaDespacho(tipDilig))
        {
            throw new DiligenciaException();
        }else
        {
          this.cabDiligenciaDAO.update(mapDilig);
        }
      }

 /*rin13 swf inicio*/
      if(params.containsKey("IndicadorAnticipado")){
    	 if(params.get("IndicadorAnticipado").equals("SI")){
    		 declaracionService.insertarIndicadorDua(declaracion.get("NUM_CORREDOC").toString(), Constantes.IND_DUA_RECTI_ANTICIPADO, Constantes.IND_DUA_P_ESP);
    	 } 
      }
      /*rin13 swf fin*/

      String codFuncionario = (String) mapDilig.get("COD_FUNCIONARIO"); //PAS20175E220200051

      Map declaracionAnt = (HashMap) params.get("mapCabDeclara");
      //RIN-13 Actualizaci�n de participantes - 31 Deposito
      this.actualizarParticipanteDeposito(declaracion, declaracionAnt, numeroCorrelativo, numCorreDocSol, tipDilig);//numCorreDocSol es Integer
      Map mapCabAdiDiligVinc = (HashMap) params.get("mapCabAdiDiligVinc");
      if (SunatStringUtils.isStringInList(declaracion.get("COD_REGIMEN").toString(), "20,21")
          && !CollectionUtils.isEmpty(mapCabAdiDiligVinc)
          && SunatStringUtils.isStringInList(tipDilig, "02,03"))
      {

        mapCabAdiDiligVinc.putAll(mapDilig);
        mapCabAdiDiligVinc.put("NUM_CORREDOC_SOL", "0");
        cabAdiDiligVincDAO.insert(mapCabAdiDiligVinc);
      }

      if (declaracion.get("COD_REGIMEN").toString().trim().equals("20") && (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig))){  //PAS20175E220200051 y PAS20175E220200059
      declaracionService.generaCuentaCorriente(codFuncionario,declaracion);
      }
      
      insertarPlazoProceso(declaracion, fecActual, tipDilig);

      //Map declaracionAnt = (HashMap) params.get("mapCabDeclara");

      // Obtenemos los registros que relacionan las series con los items
      Map fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", numeroCorrelativo);//declaracion.get("NUM_CORREDOC"));
      List lstSeriesItem = this.seriesItemDAO.select(fbKeys);
      params.put("lstSeriesItem", lstSeriesItem);

      // Actualizamos el Boletin Quimico
      if (declaracion.get("lstTabBolQuim") != null)
      {
        Map mapBolQuim = new HashMap();
        mapBolQuim.put("lstTabBolQuim", declaracion.get("lstTabBolQuim"));
        mapBolQuim.put("lstTabBolQuimAnt", declaracionAnt.get("lstTabBolQuim"));
        // Parametros para actualizar la partida en las series del formato B
        mapBolQuim.put("lstSeriesItem", lstSeriesItem);
        mapBolQuim.put("mapCabDeclaraActual", declaracion);
        this.actualizarBolQuimicos(mapBolQuim);
      }

      // **************Actualizamos la DECLARACION********************//
      declaracion.put("FEC_MODIF", fecActual.getTimestamp());
      //amancilla cambio
      // se cambia esto siempre pone diligencia conforme if (flag.equals("") && (!Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) || !Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig) ))//DZC RIN 16
        //si no es despacho no hay pq poner conforem
        if (flag.equals("") && !Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) && !Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig))//DZC RIN 16
      {
        declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_DILIGENCIA_CONFORME);
      }
      else if (flag.equals("C"))
      {
        declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO);
      }
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) || Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig))// DZC RIN 16
        declaracion.put("FEC_REGULARIZA", new FechaBean().getTimestamp());

      if (declaracion.get("FEC_VENREGIMEN").getClass().getName().equals(fecActual.getClass().getName()))
      {
        declaracion.put("FEC_VENREGIMEN", ((FechaBean) declaracion.get("FEC_VENREGIMEN")).getTimestamp());
      }
      
      // RIN16 : lpalominom [inicio]
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig)){
//    	  Declaracion decla = (Declaracion) params.get("objDeclaracion");
    	  Declaracion decla = new Declaracion();
    	  DUA dua = new DUA();
    	  decla.setCodaduana((String)declaracion.get("COD_ADUANA"));
    	  decla.setNumeroDeclaracion((declaracion.get("NUM_DECLARACION")!=null) ? ((BigDecimal)declaracion.get("NUM_DECLARACION")).longValue() : null);
    	  decla.setCodregimen((String)declaracion.get("COD_REGIMEN"));
  		  dua.setAnnpresen((declaracion.get("ANN_PRESEN")!=null) ? ((BigDecimal)declaracion.get("ANN_PRESEN")).intValue() : null);
    	  dua.setFecSegundaRecepcion((Date)declaracion.get("FEC_REREG"));
    	  //pase 15 - 252  
		  dua.setFecvencregula(SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_VENCREGULA").toString()));
    	  decla.setDua(dua);
    	  
    	  declaracion.put("COD_ESTREGUL", declaracionService.estadoDeRegularizacion(decla));
      }
      
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){// DZC RIN 16
    	  declaracion.put("COD_ESTREGUL", Constantes.REGULARIZADA_DE_OFICIO);
      }
      
      // RIN16 : lpalominom [fin]
      
      // **************fin Actualizamos la DECLARACION********************//

      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", "");

      Comparador comp = new Comparador();
      /* Retirar campos que no son modificables */
      if (declaracion.containsKey("FEC_DECLARACION"))
        declaracionAnt.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));
      if (declaracion.containsKey("FEC_REGIS"))
        declaracion.remove("FEC_REGIS");
      if (declaracionAnt.containsKey("FEC_REGIS"))
        declaracionAnt.remove("FEC_REGIS");
      if (declaracion.containsKey("FEC_MODIF"))
        declaracion.remove("FEC_MODIF");
      if (declaracionAnt.containsKey("FEC_MODIF"))
        declaracionAnt.remove("FEC_MODIF");
      
      ///inicio P21-P22 Se comenta por Bug 24228
        /*
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) || Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){
      declaracion.put("COD_ESTDUA", Constantes.ESTADO_EN_CONCLUSION_DESPACHO);
      }*/

      
      
      // RIN16 : lpalominom [inicio]
      if (Constantes.FLAG_REGULARIZACION_CONCLUSION_AUTOMATICA.equals(params.get("FLAG_CONCLUSION"))
    		  && (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig))){// DZC RIN 16
    	  declaracion.put("FEC_CONCLUSION", new FechaBean().getTimestamp());
    	  declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO);
      }   
      // RIN16 : lpalominom [Fin]
      
      /**Inicio cambios por PAS20165E220200032***/
      if(params.containsKey("indGrabarPostLevante")){
     	 if(params.get("indGrabarPostLevante")!=null && params.get("indGrabarPostLevante").equals("SI")){
     	
	     	// Date fechaDiligencia = mapDilig.get("FEC_DILIGENCIA") instanceof FechaBean? ((FechaBean) mapDilig.get("FEC_DILIGENCIA")).getTimestamp():(Date)mapDilig.get("FEC_DILIGENCIA");
	     	 
	     	 //Inicio  Cálculo de plazo 3 meses, dias hábiles:
	     	 Date fechaConclusion=new Date();
	     	 String resultadoDias="";
	     	 fechaConclusion = SunatDateUtils.addMonth(new Date(), 3);
	   		 Map<String,Object> paramsFecha = new HashMap<String,Object>();
	   		 paramsFecha.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaConclusion));
			 paramsFecha.put("FECHAHASTA", 1);
			 paramsFecha.put("TIPO", 2);
			 paramsFecha.put("INCLUYE", "S");
			 paramsFecha.put("SUSPENDE", "S");		
			 resultadoDias=(String)((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(paramsFecha);//ya esta en YYYYMMDD			 
			 fechaConclusion=SunatDateUtils.getDateFromInteger( SunatNumberUtils.toInteger(resultadoDias));
			//Fin Cálculo de plazo 3 meses, dias hábiles	
			 declaracion.put("FEC_VENCONCLU", fechaConclusion);//seteo de la fecha de vencimiento de conclusion.
	   		 Map<String, Object> mapParam = new HashMap<String, Object>();
	         mapParam.put("cADUAFECTA", String.valueOf(declaracion.get("COD_ADUANA")));
	         mapParam.put("cANNAFECTA", String.valueOf(declaracion.get("ANN_PRESEN")));
	         mapParam.put("cNUMAFECTA", SunatStringUtils.lpad(String.valueOf(declaracion.get("NUM_DECLARACION")), 6, '0'));
	         mapParam.put("cREGIAFECTA", String.valueOf(declaracion.get("COD_REGIMEN")));
	         mapParam.put("cFECHAFECTA", Integer.valueOf(resultadoDias));
	         mapParam.put("cTRANS", "2");
	         log.debug("PARAM = " + mapParam);
	         String resultado = this.pagarantiaDAO.registroFechaTermino(mapParam);
	         log.debug("PAGARANTIA.FNFECHA resultado = " + resultado);
			 
			   
	         /**Inicio REGISTRO DE PLAZOS**/
				Map <String, Object> parametros = new HashMap<String, Object>(); 
				long diferenciaFechas;
				diferenciaFechas = 0;
				
				parametros.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				parametros.put("COD_TIPPLZ", "06");
				parametros.put("FEC_INICIO", SunatDateUtils.getCurrentDate());
				parametros.put("FEC_FIN", fechaConclusion);
				parametros.put("CNT_DURACION", diferenciaFechas);
				parametros.put("COD_UNIMED", "2");
				parametros.put("COD_ESTPLZ", "1");
				
				((PlazosProcesoDAO)fabricaDeServicios.getService("plazosprocesoDAO")).insert(parametros);
				/**Fin REGISTRO DE PLAZOS**/
     	 } 
       }
      /**Fin cambios por PAS20165E220200032***/
      
      
      Map<String, Object> mapDiferencias = comp.comparaMapEstricto(declaracionAnt, declaracion, false, false, fbKeys);

      if (mapDiferencias != null && mapDiferencias.size() > 0)
      {
        if (Comparador.esDataCambiada(mapDiferencias))
        {
          this.cabDeclaraDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferencias));
          this.registrarRectiOficio(mapDiferencias, tipDilig, new Long(mapDiferencias
                                                                                     .get("NUM_CORREDOC")
                                                                                     .toString()
                                                                                     .trim()), "T0051");
        }
      }

      if (!MapUtils.esValorMapaNuloOVacio(declaracion, "COD_FERIA"))
      {
        if ((declaracionAnt.get("COD_FERIA") == null)
            || (declaracionAnt.get("COD_FERIA") != null && !declaracionAnt.get("COD_FERIA")
                                                                          .toString()
                                                                          .trim()
                                                                          .equals(declaracion.get("COD_FERIA")
                                                                                             .toString().trim())))
        {

          Map keyAdmTemp = new HashMap();
          keyAdmTemp.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));

          Map mapAdmTempDO = new HashMap();
          mapAdmTempDO.put("COD_FERIA", declaracionAnt.get("COD_FERIA"));

          Map mapAdmTempDif = new HashMap();
          mapAdmTempDif.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
          mapAdmTempDif.put("COD_FERIA", declaracion.get("COD_FERIA"));

          mapAdmTempDif.put("dataOriginal", mapAdmTempDO);
          mapAdmTempDif.put("clave", keyAdmTemp);

          if (declaracionAnt.get("COD_FERIA") == null)
          {

            this.cabAdiAdmTemDAO.insert(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
          }
          else
          {

            this.cabAdiAdmTemDAO.update(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
          }

          this.registrarRectiOficio(
                                    mapAdmTempDif,
                                    tipDilig,
                                    //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                    numeroCorrelativo,
                                    Constantes.COD_TABLA_CAB_ADI_ADM_TEM);
        }
      }

      // Actualizamos el estado de la asignacion
      Map prmtBusq = new HashMap();
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig) || Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig))// RIN 16 DZC
      {
        prmtBusq.put("NUM_CORREDOC", (declaracion.get("NUM_CORREDOC_SOL")!=null? declaracion.get("NUM_CORREDOC_SOL") : declaracion.get("NUM_CORREDOC")));
      }
      else
      {
        prmtBusq.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
      }
      prmtBusq.put("COD_ESTREV", "06");
      prmtBusq.put("COD_PROCESOASIG", tipDilig);// SIGESI - INC 2015-026689

      Map mapEspeDocuAnt = this.espeDocuDAO.findbyDocEstRev(prmtBusq);
      
      try {//CAMBIO INC 2015-026689
      
      if (mapEspeDocuAnt != null && mapEspeDocuAnt.size() > 0)
      {
        Map mapEspeDocu = new HashMap();
        mapEspeDocu.putAll(mapEspeDocuAnt);
        mapEspeDocu.put("cod_estrev", flag.equals("") ? "01" : "12");

        fbKeys = new HashMap();
        fbKeys.put("num_corredoc", "");
        fbKeys.put("fec_asig", "");

        mapDiferencias = new HashMap();
        mapDiferencias = comp.comparaMapEstricto(mapEspeDocuAnt, mapEspeDocu, false, false, fbKeys);

        if (!MapUtils.esMapaNuloOVacio(mapDiferencias))
        {
          if (Comparador.esDataCambiada(mapDiferencias))
          {
            mapDiferencias.put("cod_estrev_ant", "06");
            mapDiferencias.put("cod_funcionario", params.get("cod_funcionario").toString());
            mapDiferencias.put("fec_termrev", "fec_termrev");
            this.espeDocuDAO.updateEstadoRevision(mapDiferencias); 
          }
        }
      }
      else
      {
        Map<String, Object> mapaRev = new HashMap();
        Map<String, Object> mapaRevFin = new HashMap();
        Map<String, Object> mapaEspeDocu = new HashMap();
        Map<String, Object> mapaEspeDocuResult = new HashMap();
        mapaEspeDocu.put("NUM_CORREDOC", prmtBusq.get("NUM_CORREDOC"));
        mapaEspeDocu.put("COD_ESTREV", "02");
        prmtBusq.put("COD_PROCESOASIG", tipDilig);    // SIGESI - INC 2015-026689
        mapaEspeDocuResult = espeDocuDAO.findbyDocEstRev(mapaEspeDocu);

        mapaRev.put("cod_estrev", "02");
        mapaRev.put("cod_estrev_ant", "02");

        if (MapUtils.esMapaNuloOVacio(mapaEspeDocuResult))
        {
          mapaEspeDocu.put("NUM_CORREDOC", prmtBusq.get("NUM_CORREDOC"));
          mapaEspeDocu.put("COD_ESTREV", "03");
          prmtBusq.put("COD_PROCESOASIG", tipDilig);   // SIGESI - INC 2015-026689
          mapaEspeDocuResult = espeDocuDAO.findbyDocEstRev(mapaEspeDocu);

          mapaRev.put("cod_estrev", "03");
          mapaRev.put("cod_estrev_ant", "03");
        }

        if (!CollectionUtils.isEmpty(mapaEspeDocuResult))
        {
          mapaRev.put("cod_funcionario", mapaEspeDocuResult.get("cod_funcionario"));
          mapaRev.put("num_corredoc", prmtBusq.get("NUM_CORREDOC"));

          mapaRevFin.put("cod_funcionario", mapaEspeDocuResult.get("cod_funcionario"));
          mapaRevFin.put("num_corredoc", prmtBusq.get("NUM_CORREDOC"));

          mapaRev.put("cod_tipasig", "R");
          espeDocuDAO.updateEstadoRevision(mapaRev);

          EspeDocu espeDocu = new EspeDocu();
          EspeDispo espeDispo = new EspeDispo();
          GrupoTrabajo grupoTrabajo = new GrupoTrabajo();
          CatEmpleado catEmpleado = new CatEmpleado();
          CatTurno catTurno = new CatTurno();
          CabDeclara cabDeclara = new CabDeclara();
          BandejaDocu bandejaDocu = new BandejaDocu();
          EspeDespa espeDespa = new EspeDespa();
          Aduana aduana = new Aduana();
          Regimen regimen = new Regimen();

          bandejaDocu.setCabDeclara(cabDeclara);
          espeDespa.setCatEmpleado(catEmpleado);
          catTurno.setAduana(aduana);
          catTurno.setRegimen(regimen);

          espeDispo.setGrupoTrabajo(grupoTrabajo);
          espeDispo.setEspeDespa(espeDespa);
          espeDispo.setCatTurno(catTurno);

          espeDocu.setEspeDispo(espeDispo);
          espeDocu.setBandejaDocu(bandejaDocu);

          espeDocu.getEspeDispo().setFecIniDispon((Date) mapaEspeDocuResult.get("fec_inidispon"));

          espeDocu.getEspeDispo().getGrupoTrabajo().setCodDatacat(mapaEspeDocuResult.get("cod_grupo").toString());

          espeDocu.getEspeDispo().getEspeDespa().getCatEmpleado().setCodPers(params.get("cod_funcionario").toString());

          espeDocu.getEspeDispo().getCatTurno().setCodTurno(mapaEspeDocuResult.get("cod_turno").toString());

          espeDocu
                  .getEspeDispo()
                  .getCatTurno()
                  .getAduana()
                  .setCodDatacat(mapaEspeDocuResult.get("cod_aduana").toString());

          espeDocu
                  .getEspeDispo()
                  .getCatTurno()
                  .getRegimen()
                  .setCodDatacat(mapaEspeDocuResult.get("cod_regimen").toString());

          espeDocu
                  .getBandejaDocu()
                  .getCabDeclara()
                  .setNumCorreDoc(Long.valueOf(prmtBusq.get("NUM_CORREDOC").toString()));

          Date fecha = (Date) mapaEspeDocuResult.get("fec_asig");
          Calendar cal = Calendar.getInstance();
          cal.setTime(fecha);
          cal.add(Calendar.SECOND, 1);
          espeDocu.setFecAsig(cal.getTime());
          espeDocu.setCodEstRev("01");
          espeDocu.setCodTipAsig("A");
          espeDocu.setFecActEst((Date) mapaEspeDocuResult.get("fec_actest"));

          if (mapaEspeDocuResult.get("cnt_difidua") != null)
          {
            espeDocu.setCntDifiDua(Long.valueOf(mapaEspeDocuResult.get("cnt_difidua").toString()));
          }
          else
          {
            espeDocu.setCntDifiDua(0L);
          }
          if (mapaEspeDocuResult.get("ind_aviso") != null)
          {
            espeDocu.setIndAviso(mapaEspeDocuResult.get("ind_aviso").toString());
          }
          else
          {
            espeDocu.setIndAviso("1");
          }
          if (mapaEspeDocuResult.get("cod_formaasig") != null)
          {
            espeDocu.setCodFormaAsig(mapaEspeDocuResult.get("cod_formaasig").toString());
          }
          else
          {
            espeDocu.setCodFormaAsig("M");
          }
          if (mapaEspeDocuResult.get("des_motivoasig") != null)
          {
            espeDocu.setDesMotivoAsig(mapaEspeDocuResult.get("des_motivoasig").toString());
          }
          else
          {
            espeDocu.setDesMotivoAsig("DILIGENCIA DE DESPACHO");
          }
          espeDocuDAO.crearEspeDocu(espeDocu);

          mapaRevFin.put("cod_estrev", "01");
          mapaRevFin.put("cod_estrev_ant", "01");
          mapaRevFin.put("fec_termrev", new Date());
          espeDocuDAO.updateEstadoRevision(mapaRevFin);
        }
      }
     }
      //Inicio-INC 2015-026689
      catch (Exception e)
      {
        log.error("Actualizando estadoRevisi�n espedocuDAO - ERROR: ", e);
        throw new ServiceException(this, e.getStackTrace().toString());
      }
      //Fin-INC 2015-026689
      
      //inicio CU 14.21
      if(declaracion.get("IND_FORMBPROVEEDOR").toString().equals("0")){
    	  this.insertarItemFacturaDeclaracion(params, tipDilig);
      }
      //fin CU 14.21
      
      this.actualizarSeries(params);

      List<Map<String, Object>> lstDetAutorizacionActual = (List) declaracion.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDetAutorizacion = (List) declaracionAnt.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDocAutAsociadoActual = (List) declaracion.get("lstDocAutAsociado");
      List<Map<String, Object>> lstDocAutAsociado = (List) declaracionAnt.get("lstDocAutAsociado");
      List<Map<String, Object>> lstCabCertiOrigenActual = (List) declaracion.get("lstCabCertiOrigen");
      List<Map<String, Object>> lstCabCertiOrigen = (List) declaracionAnt.get("lstCabCertiOrigen");
      // actualizacion de documentos asociados a la serie

      // Debe existir un registro para actualizar o algun nuevo
      //Inicio RIN 14
      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", "");
      fbKeys.put("COD_TIPOPER", "");
      fbKeys.put("NUM_SECDOC", "");
      List<Map<String, Object>> lstDiferDocAut = comp.comparaList(lstDocAutAsociado, lstDocAutAsociadoActual, fbKeys);
      //Fin RIN 14
      if (!CollectionUtils.isEmpty(lstDiferDocAut))
      {
        // Documentos asociados
        Map<String, Object> mapKeyAsoc = new HashMap<String, Object>();
        Map<String, Object> mapDifAsoc = new HashMap<String, Object>();
        for (Map<String, Object> mapAsoc : lstDocAutAsociadoActual)
        {
          Map<String, Object> mapAsocAntes = new HashMap<String, Object>();

        //pase 153          
//          if (mapAsoc.get("COD_TIPDOC").equals("")) 
//          mapAsoc.put("COD_TIPDOC", " "); 
//          if (mapAsoc.get("COD_IDENT").equals(""))
//          mapAsoc.put("COD_IDENT", " ");
//          if (mapAsoc.get("OBS_OBS").equals(""))
//              mapAsoc.put("OBS_OBS", " ");
//cambio de pablito           
          if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "COD_TIPDOC"))
        	  mapAsoc.put("COD_TIPDOC", " ");  
         if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "COD_IDENT"))
             mapAsoc.put("COD_IDENT", " ");         
         if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "OBS_OBS"))
             mapAsoc.put("OBS_OBS", " "); 
           //pase 153
          
          mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
          mapKeyAsoc.put("NUM_SECDOC", mapAsoc.get("NUM_SECDOC"));
          mapKeyAsoc.put("COD_TIPOPER", mapAsoc.get("COD_TIPOPER"));
          mapKeyAsoc.put("COD_TIPDOC", mapAsoc.get("COD_TIPDOC"));

          mapAsocAntes = Utilidades.obtenerElemento(lstDocAutAsociado, mapKeyAsoc);
          if (CollectionUtils.isEmpty(mapAsocAntes))
          {
            if ("0".equals(mapAsoc.get("IND_DEL").toString()))
            {
            	if((mapAsoc.get("COD_TIPDOC")).toString().trim().length()<1){//adicionado por el pase 192
            		mapAsoc.remove("COD_TIPDOC");
            	}
              docAutAsociadoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAsoc));
              this.registrarRectiOficio(
                                        mapAsoc,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo, 
                                        Constantes.COD_TABLA_DOCAUT_ASOCIADO);
              //Inicio RIN 14
              mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            		  ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, Constants.IND_REGISTRO_NUEVO);
              //Fin RIN 14
            }
          }
          else
          {
            // ya existe en documentos asociados
            mapDifAsoc = comp.comparaMap(mapAsocAntes, mapAsoc, false, false, mapKeyAsoc);
            if (Comparador.esDataCambiada(mapDifAsoc))
            {
              //Inicio RIN 14
              if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                    
            	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
            	    Constants.IND_REGISTRO_ANULADO);

              }	
              //Fin RIN 14
              docAutAsociadoDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
              this.registrarRectiOficio(
                                        mapAsoc,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo, 
                                        Constantes.COD_TABLA_DOCAUT_ASOCIADO);
              //Inicio RIN 14
              if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                  
            	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
            	    Constants.IND_REGISTRO_NUEVO);

              } else {

            	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc,  
            	      Constants.IND_REGISTRO_ANULADO);

              }
			  //Fin RIN 14
            }
          }
          mapDifAsoc.clear();
          mapKeyAsoc.clear();
        }
        //inicio PAS20181U220200056
        String nroTransaccion = tipDilig;
  	  	// No se debe madar el tipo de diligencia sino la transacci�n
  	  	if (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig) )
        {
  		  nroTransaccion = Constantes.DILIG_DESPACHO ;
  	    }
  	  	//fin PAS20181U220200056
  	  	
        // Certificados
        if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual))
        {
          for (Map<String, Object> mapCerti : lstCabCertiOrigenActual)
          {
            Map<String, Object> mapCertiAntes = new HashMap<String, Object>();

            mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
            mapKeyAsoc.put("NUM_SECDOC", mapCerti.get("NUM_SECDOC"));
            mapKeyAsoc.put("COD_TIPOPER", mapCerti.get("COD_TIPOPER"));

            mapCertiAntes = Utilidades.obtenerElemento(lstCabCertiOrigen, mapKeyAsoc);
              
            if (CollectionUtils.isEmpty(mapCertiAntes))
            {
              if ("0".equals(mapCerti.get("IND_DEL").toString()))
              {
            	  //Inicio TLC Corea
            	 if(Constantes.DILIG_REGULARIZACION.equals(tipDilig)){//Para optimizar - PASE plmadrid
            		 Map<String,String> mapDocAutAsociadoBusq=new HashMap<String,String>();
            		 mapDocAutAsociadoBusq.put("NUM_CORREDOC", mapCerti.get("NUM_CORREDOC").toString());
            		 mapDocAutAsociadoBusq.put("COD_TIPDOCASO", mapCerti.get("COD_TIPCERTIFICADO").toString());
            		 mapDocAutAsociadoBusq.put("COD_TIPOPER", mapCerti.get("COD_TIPOPER").toString());
            		 mapDocAutAsociadoBusq.put("NUM_SECDOC", mapCerti.get("NUM_SECDOC").toString());
            		 List<Map<String,Object>> prevDocAut = docAutAsociadoDAO.select(mapDocAutAsociadoBusq);
            		  
                      Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();
                      mapDocAutAsociado.put("NUM_CORREDOC", mapCerti.get("NUM_CORREDOC"));
                      mapDocAutAsociado.put("COD_TIPDOCASO", mapCerti.get("COD_TIPCERTIFICADO"));
                      mapDocAutAsociado.put("COD_TIPOPER", mapCerti.get("COD_TIPOPER"));
                      mapDocAutAsociado.put("NUM_SECDOC", mapCerti.get("NUM_SECDOC"));
                      Integer annDoc=SunatDateUtils.getAnho((Date)mapCerti.get("FEC_CERTIFICADO"));
                      if (annDoc.intValue()!=0)
                                  mapDocAutAsociado.put("ANN_DOC", annDoc);
                      mapDocAutAsociado.put("NUM_DOC", mapCerti.get("NUM_CERTIFICADO").toString());
                      mapDocAutAsociado.put("FEC_EMIS", mapCerti.get("FEC_CERTIFICADO"));   
                      Date fecVencimiento=SunatDateUtils.getDate("31/12/9999", "dd/MM/yyyy");
                      mapDocAutAsociado.put("FEC_VENC", fecVencimiento);
                      
                      if(prevDocAut!= null && prevDocAut.isEmpty()){
                    	  docAutAsociadoDAO.insertSelective(mapDocAutAsociado);
                      }else{
                    	  docAutAsociadoDAO.update(mapDocAutAsociado);
                      }
                      this.registrarRectiOficio(
                    		  mapDocAutAsociado,
                              tipDilig,
                              //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                              numeroCorrelativo, 
                              Constantes.COD_TABLA_DOCAUT_ASOCIADO);
               }
            	 //Fin TLC Corea
                cabCertiOrigenDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapCerti));
                this.registrarRectiOficio(
                                          mapCerti,
                                          tipDilig,
                                          //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                          numeroCorrelativo, 
                                          Constantes.COD_TABLA_CAB_CERTIORIGEN);
                
                //invocar PAS20181U220200056
                String codTransaccion = "";                
                if(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)){
                	codTransaccion = "1007";
                }else if(Constantes.DILIG_DESPACHO.equals(nroTransaccion)){
                	codTransaccion = "1006";
                }
                 	
                if(!codTransaccion.isEmpty()){	 
                	registroUsoCertificadoOrigenElectronico(mapCerti , declaracion, codTransaccion);
                }
              }
            }
            else
            {
              // ya existe en documentos asociados
              mapDifAsoc = comp.comparaMap(mapCertiAntes, mapCerti, false, false, mapKeyAsoc);
              if (Comparador.esDataCambiada(mapDifAsoc))
              {
                cabCertiOrigenDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
                this.registrarRectiOficio(
                                          mapCerti,
                                          tipDilig,
                                          //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                          numeroCorrelativo,
                                          Constantes.COD_TABLA_CAB_CERTIORIGEN);
                //invocar PAS20181U220200056
                String codTransaccion = "";
                if(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)){
                	codTransaccion = "1007";
                }else if(Constantes.DILIG_DESPACHO.equals(nroTransaccion)){
                	codTransaccion = "1006";
                }
                 	
                if(!codTransaccion.isEmpty()){	 
                	registroUsoCertificadoOrigenElectronico(mapCerti , declaracion, codTransaccion);
                }
              }
            }
            mapDifAsoc.clear();
            mapKeyAsoc.clear();
          }
        }
        // Autorizantes
        //Inicio RIN 14
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", "");
        fbKeys.put("COD_TIPOPER", "");
        fbKeys.put("NUM_SECDOC", "");
        fbKeys.put("NUM_SECSERIE", "");
        List<Map<String, Object>> lstDiferDetAut = comp.comparaList(lstDetAutorizacion, lstDetAutorizacionActual, fbKeys);
        //Fin RIN 14
        if (!CollectionUtils.isEmpty(lstDiferDetAut))
        {
          for (Map<String, Object> mapAut : lstDetAutorizacionActual)
          {
            Map<String, Object> mapAutAntes = new HashMap<String, Object>();

            mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
            mapKeyAsoc.put("NUM_SECDOC", mapAut.get("NUM_SECDOC"));
            mapKeyAsoc.put("COD_TIPOPER", mapAut.get("COD_TIPOPER"));
            mapKeyAsoc.put("NUM_SECSERIE", mapAut.get("NUM_SECSERIE"));



            mapAutAntes = Utilidades.obtenerElemento(lstDetAutorizacion, mapKeyAsoc);
            if (CollectionUtils.isEmpty(mapAutAntes))
            {
              if ("0".equals(mapAut.get("IND_DEL").toString()))
              {
                detAutorizacionDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAut));
                this.registrarRectiOficio(
                                          mapAut,
                                          tipDilig,
                                          //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                          numeroCorrelativo, 
                                          Constantes.COD_TABLA_DET_AUTORIZACION);
                //Inicio RIN 14
                mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                		  ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                		   Constants.IND_REGISTRO_NUEVO);
				//Fin RIN 14
              }
            }
            else
            {
              // ya existe en documentos asociados
              mapDifAsoc = comp.comparaMap(mapAutAntes, mapAut, false, false, mapKeyAsoc);
              if (Comparador.esDataCambiada(mapDifAsoc))
              {
            	//Inicio RIN 14  
            	if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){       
                      
              	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
              	    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
              	    Constants.IND_REGISTRO_ANULADO);

                }
            	//Fin RIN 14  
                detAutorizacionDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
                this.registrarRectiOficio(
                                          mapAut,
                                          tipDilig,
                                          //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                          numeroCorrelativo,
                                          Constantes.COD_TABLA_DET_AUTORIZACION);
                //Inicio RIN 14
                if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){
                    
                    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                    Constants.IND_REGISTRO_NUEVO);

                  } else {

                    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut,  
                      Constants.IND_REGISTRO_ANULADO);

                  }
				//Fin RIN 14
              }
            }
            mapDifAsoc.clear();
            mapKeyAsoc.clear();
          }
        }
      }
      //Inicio - RIN 14
      List lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
      params.put("tipDilig", tipDilig);
      if (Constantes.COD_TIPO_DILIGENCIA_REGULARIZACION.equals(params.get("tipDilig").toString())){
      Map prmtVal = new HashMap();
      prmtVal.put("mapCabDeclara", declaracion);
      prmtVal.put("lstDetDeclara", lstDetDeclara);
      prmtVal.put("lstDocAutAsociado", lstDocAutAsociadoActual);
      prmtVal.put("lstDetAutorizacion", lstDetAutorizacionActual);
      prmtVal.put("codTransaccion", Constants.COD_TRANSAC_DILIGENCIAREGUL);
      
      Declaracion decla = GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance().transform(prmtVal);
      mercanciaRestringidaEntidadService.actualizarDocAutorizaIQBF(decla, Constants.EST_DOCAUT_CONCLUIDA);
      }
      //Fin - RIN 14

      // Insertamos las incidencias


      // RIN13-SWF - INICIO cambio amancillaa RIN13

     List<Incidencia> lstIncidencias2 = (ArrayList<Incidencia>) params.get("lstIncidencias");
     if(!CollectionUtils.isEmpty(lstIncidencias2)) {
        int numItm = 0;
       Map incidencia;
        for(Incidencia incidenciaBean:  lstIncidencias2) {
          numItm += 1;
         incidencia = new HashMap();
          incidencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
         incidencia.put("COD_TIPDILIGENCIA", tipDilig);

         incidencia.put("NUM_SECINCID", "" + numItm);
          incidencia.put("NUM_SERIE", incidenciaBean.getNumeroSerie());
          incidencia.put("COD_INCIDENCIA", incidenciaBean.getCodIncidencia());
        incidenciaService.insert(incidencia);
       }

      }
	  
      // Insertamos o actualizamos la OBSERVACION correspondiente
      Map mapObs = new HashMap();
      mapObs.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      mapObs.put("NUM_SECOBS", declaracion.get("NUM_SECOBS") != null ? declaracion.get("NUM_SECOBS").toString().trim()
                                                                    : "1");// siguiente
      mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_DECLA);
      mapObs.put("OBS_OBS", declaracion.get("OBS_OBS"));
/*RIN13FSW-INICIO*/
    //  mapObs.put("OBS_OBS", mapDilig.get("DES_RESULTADO"));//juazor
    //  mapObs.put("NUM_SECITEM", declaracion.get("NUM_SECITEM") != null ? declaracion.get("NUM_SECOBS").toString().trim() : "1");//juazor
/*RIN13FSW-FIN*/
      Map keyObs = new HashMap();
      keyObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
      keyObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
      keyObs.put("COD_TIPOBS", mapObs.get("COD_TIPOBS"));

      Map mapObsDO = null;
      mapObs.put("dataOriginal", mapObsDO);
      mapObs.put("clave", keyObs);

      if ((mapObs.get("OBS_OBS") == null || "".equals(mapObs.get("OBS_OBS").toString().trim())))
      {
        if (declaracionAnt.get("NUM_SECOBS") != null)
        {
          if (mapObs.get("OBS_OBS") == null)
          {
            mapObs.put("OBS_OBS", "");
          }
          this.observacionDAO.update(mapObs);

          this.registrarRectiOficio(mapObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                    Constantes.COD_TABLA_OBSERVACION);
        }
      }
      else
      {
        if (declaracionAnt.get("NUM_SECOBS") == null)
        {
          this.observacionDAO.insert(mapObs);

          mapObs.put("dataOriginal", mapObsDO);

          this.registrarRectiOficio(mapObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                    Constantes.COD_TABLA_OBSERVACION);
        } else {
        	if (!mapObs.get("OBS_OBS").toString().trim().equals(declaracionAnt.get("OBS_OBS") != null ? declaracionAnt.get("OBS_OBS").toString().trim():"")){ // ajuste null
            this.observacionDAO.update(mapObs);
              Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
        		mapObsAnt.put("OBS_OBS", declaracionAnt.get("OBS_OBS") != null ? declaracionAnt.get("OBS_OBS").toString().trim():""); // ajuste null
              Map<String, Object> mapDiferenciasObs = soporteComparadorService.comparaMap(mapObs, mapObsAnt, EnumTablaModel.OBSERVACION);
              this.registrarRectiOficio(mapDiferenciasObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),Constantes.COD_TABLA_OBSERVACION);
          }
        }
      }

      // Actualizamos las tablas del Formato B
      Map paramsFB = new HashMap();
      paramsFB.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
      paramsFB.put("lstFormBProveedor", declaracion.get("lstFormBProveedor"));
      paramsFB.put("lstFormBProveedorAnt", declaracionAnt.get("lstFormBProveedor"));
      paramsFB.put("tipDilig", tipDilig);
      //this.actualizarFormatoB(paramsFB);//PAS20165E220200137 este ya fue es antiguo y no funciona bien
      this.actualizarFormatoB(paramsFB, numCorreDocSol);//PAS20165E220200137 se rehusa el comparador actualizado que usa DILIGENCIA DE DESPACHO
//      List lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");

//      if (lstDetDeclara != null && lstDetDeclara.size() > 0)
       // Regularizacion de Oficio no LIQUIDA		
   	  if (!Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){	
			if (!CollectionUtils.isEmpty(lstDetDeclara)) {
				Map mapParamsDilig = new HashMap();
				mapParamsDilig.put("mapCabDeclaraActual", declaracion);
				mapParamsDilig.put("mapCabDiligenciaActual", mapDilig);
				//INICIO PAS20155E220000054
                if (params.get("lstMultaDua")!=null){
		        mapParamsDilig.put("generacionLCMulta", params.get("generacionLCMulta"));
		        mapParamsDilig.put("lstMultaDuaOkResolucion", params.get("lstMultaDuaOkResolucion"));
                }
				//FIN  PAS20155E220000054				
				//PAS20155E220000166 - Inicio
                mapParamsDilig.put("generacionLCTributo", params.get("generacionLCTributo"));
                //PAS20155E220000166 - Fin     
                
                /*** Inicio Cambio PAS20155E220200192 RSV **/
                mapParamsDilig.put("generarLC15_SI_9", params.get("generarLC15_SI_9") == null? "NO" : params.get("generarLC15_SI_9").toString().trim() );
                mapParamsDilig.put("generarLC15_NO_9", params.get("generarLC15_NO_9") == null? "NO" : params.get("generarLC15_NO_9").toString().trim() );
                /*** Fin Cambio PAS20155E220200192 RSV **/
                
				if (!Constantes.REGIMEN_70_DEPOSITO.equals((String) declaracion.get("COD_REGIMEN"))) {
					this.liquidaDeclaracionService.grabaLiqDiligencia(mapParamsDilig);
					// mordonezl pase280
					// params.put("mpDeudasADesafectar", mapParamsDilig.get("mpDeudasADesafectar"));
					params.put("mensaje", mapParamsDilig.get("mensaje"));
					// FIN MOL
				}
			}
        }
   	//INICIO EJHM P46  se coloca despues de la liquidacion p poder obtener el indicador inicial de BD
   	agregaOactualizaIndicadorDonacion( declaracion, declaracionAnt);
   	//FIN EJHM 
   	 

	  // Regularizacion de Oficio no LIQUIDA		
	  if (!Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){		
       // Grabamos las multas registradas
       List listaMultasSeleccionadas = (ArrayList) params.get("lstMultaDua");
       if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
       {
        String codDocumento = declaracion.get("NUM_CORREDOC").toString();
        String codTipoDiligencia = (String) mapDilig.get("COD_TIPDILIGENCIA");
        Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
        String tipoDocImp = (String) declaracion.get("COD_TIPDOC_PIM");
        String rucImp = (String) declaracion.get("NUM_DOCIDENT_PIM");
        //String codFuncionario = (String) mapDilig.get("COD_FUNCIONARIO"); PAS20175E220200051

        Map paramMulta = new HashMap();
        paramMulta.put("COD_DOCUMENTO", codDocumento);
        paramMulta.put("NUM_CORREDOC", codDocumento);
        paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
        paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
        paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
        paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
        paramMulta.put("COD_ANTADU", "41");
		//Inicio PAS20155E220000054
        paramMulta.put("NUM_REG_USUARIO", codFuncionario);
        paramMulta.put("generarLC003", (Map<String, Object>) params.get("generacionLCMulta"));
		//Fin PAS20155E220000054
        
        paramMulta.put("tipDilig", tipDilig);
        this.multaService.generarMulta(paramMulta, listaMultasSeleccionadas);
       }
      }
      // actualizando la cabecera de sollicitud de rectificacion
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig))
      {
        Map<String, Object> paramCsr = new HashMap<String, Object>();
        paramCsr.put("COD_ESTARECTI", "04");// Regularizaci�n aceptada
        paramCsr.put("FEC_EVALUACION", "FEC_EVALUACION");
        paramCsr.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC_SOL").toString());
        cabSolrectiDAO.updateEstado(paramCsr);
        
        //pase 39 grabar fecha atencion regu
        Solicitud solicitud = new Solicitud();
        solicitud.setNumeroCorrelativo(SunatNumberUtils.toLong(declaracion.get("NUM_CORREDOC_SOL")));
        solicitud.setFechaAtencion(new Date());
        SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
        solicitudDAO.updateByPrimaryKeySelective(solicitud);
      }

      //DZC INI RIN 16 - INI   
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){

		  // -- Verificamos que la Declaracion cuente con una Solicitud de Regularizacion
		  Map<String,Object> p2 = new HashMap<String,Object>();
		  p2.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
		  p2.put("COD_TIPSOL", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
		  //p2.put("COD_ESTSOL", "03");//  Asignada a Funcionario Aduanero
		  RelacionDocDAO relacionDocDAO= fabricaDeServicios.getService("despaduanero2.relacionDocDAO");
		  
		  String numSolicitud = relacionDocDAO.findSolicitudByDocumento(p2);
		  
		  if (!StringUtils.isEmpty(numSolicitud) ) {
			 
	    	  // Anulamos en Cab_solicitud
			  SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
			  Map<String, Object> paramSolicitud = new HashMap<String, Object>();
			  paramSolicitud.put("NUM_CORREDOC", numSolicitud);
			  paramSolicitud.put("COD_ESTSOL", "04");		  
			  solicitudDAO.updateEstado(paramSolicitud);
			  
	    	  // Anulamos la solicitud Cab_solrecti.COD_ESTARECTI='07' - Catalogo 329
	    	  Map<String, Object> paramCsr = new HashMap<String, Object>();
	          paramCsr.put("COD_ESTARECTI", "07");// Regularizaci�n Anulada
	          paramCsr.put("FEC_EVALUACION", "FEC_EVALUACION");
	          paramCsr.put("NUM_CORREDOC", numSolicitud);
	          paramCsr.put("OBS_EVALUACION", "Anulado por Regularizaci�n de Oficio");
	          cabSolrectiDAO.updateEstado(paramCsr); 
		  }
      }
            
    //DZC INI RIN 16 - FIN

    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Ha ocurrido un error al inserta los datos");
    }
    catch (Throwable e)
    {
      log.error("DiligenciaServiceImpl : grabarDiligenciaDespacho - ERROR: ", e);
      throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo de grabado de la diligencia");
    }
  }
  

	//PAS20181U220200056
	public void registroUsoCertificadoOrigenElectronico(Map<String, Object> mapCerti , Map declaracion, String codTransaccion) {
		Boolean esValidoVUCECO = ((CertiOrigenElectronicoService)fabricaDeServicios.getService("certiOrigenElectronicoService"))
	    		  .esValidoCambiosDiligVUCECO(SunatDateUtils.getCurrentDate());
		if(esValidoVUCECO) { //Correccion al pase 56
			
		final String URL_VUCE_CERT_ELECT = "http://api.sunat.peru/v1/estrategico/vuce/e/certificadoorigenelectronico"; 	
		String codTipoElect = mapCerti.get("IND_ELECTRONICO") != null ? mapCerti.get("IND_ELECTRONICO").toString(): null;
		String numCertificado = mapCerti.get("NUM_CERTIFICADO")!=null? mapCerti.get("NUM_CERTIFICADO").toString():null;
		if(!codTransaccion.endsWith("01") && numCertificado!=null) { 
			  DocCertificadoOrigen  docCertificadoOExiste = new DocCertificadoOrigen();
			  docCertificadoOExiste = ((CertiOrigenElectronicoService)fabricaDeServicios.getService("certiOrigenElectronicoService"))
					  .consultarCertificadoElectronico("0", numCertificado);
			if( docCertificadoOExiste !=null && docCertificadoOExiste.getNumeroCertificadoOrigen()!=null) {
				codTipoElect = INDICADOR_CERT_ELECTRONICO;
			}			
		}
				
		if(INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(codTipoElect)) {
			try{
				DocCertificadoOrigen docCertificadoOrigen = new DocCertificadoOrigen();
				docCertificadoOrigen.setNumeroCertificadoOrigen(mapCerti.get("NUM_CERTIFICADO").toString());
				docCertificadoOrigen.setNumeroCorrelativoDAMUso(new Long(declaracion.get("NUM_CORREDOC").toString()));
				docCertificadoOrigen.setCodTransaccionUso(codTransaccion);
				docCertificadoOrigen.setNumeroDAMUso(SunatStringUtils.lpad(String.valueOf(declaracion.get("NUM_DECLARACION")), 6, '0'));	
				RestTemplate restTemplate = new RestTemplate();
				//String uriActualizarCampoUso = "http://localhost:7001/ol-ad-aduanerovucews/certificadoorigenelectronico";
				String responseUpdate = restTemplate.postForObject(URL_VUCE_CERT_ELECT, docCertificadoOrigen, String.class);		
              log.info("RegistroUsoCertificadoOrigenElectronicio " + responseUpdate);
			}
			catch(Exception e){
				log.info("Error RegistroUsoCertificadoOrigenElectronicio : " + e.getMessage());
			}
		}

		}
	}


  /*inicio P46-PAS20155E410000032-[jlunah] BUG 25285*/
public void  agregaOactualizaIndicadorDonacion(Map declaracion,Map declaracionInicial){
	  agregaOactualizaIndicadorDonacion(declaracion,declaracionInicial, null , null);
  }  
  /*fin P46-PAS20155E410000032-[jlunah] BUG 25285*/

public void actualizarDiligenciaDuaJefeDestino(Long numCorredoc)
{
	BandejaDocuDAO bandejaDocuDAO = (BandejaDocuDAO) fabricaDeServicios.getService("asignacion.bandejaDocuDAO");
	BandejaDocu bandejaDocu = bandejaDocuDAO.consultarBandejaDocuByPK(numCorredoc);
	bandejaDocu.setFecAsig((new FechaBean()).getTimestamp());
	bandejaDocu.setIndjGrupoDestino("2");
	bandejaDocuDAO.modificarBandejaDocu(bandejaDocu);
}

public void  agregaOactualizaIndicadorDonacion(Map declaracion,Map declaracionInicial, String tipoDiligencia , Integer numCorredocSol){/*P46-PAS20155E410000032-[jlunah] BUG 25285*/
   if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals((String) declaracion.get("COD_REGIMEN"))){
  		   Map<String, Object> paramsInd =new HashMap<String, Object>();
  		    boolean actualizaIndicador=false;
  		    boolean presentaIndDonacion=declaracion.get("COD_INDICADOR_DONACION")!=null && !declaracion.get("COD_INDICADOR_DONACION").toString().equals("00")?true:false;
  		    boolean presentoIndDonacion=declaracionInicial.get("COD_INDICADOR_DONACION")!=null && !declaracionInicial.get("COD_INDICADOR_DONACION").toString().equals("00")?true:false;
  		    String CodIndicadorActual = declaracion.get("COD_INDICADOR_DONACION")!=null?declaracion.get("COD_INDICADOR_DONACION").toString():"";
  		    String CodIndicadorInicial = declaracionInicial.get("COD_INDICADOR_DONACION")!=null?declaracionInicial.get("COD_INDICADOR_DONACION").toString():"";
  		    //  CUANDO SE CAMBIA EL INDICADOR DE DONACION DE 07 A 06 o se AGREGA NUEVO INDICADOR
  		    if(presentaIndDonacion  && !CodIndicadorActual.equals(CodIndicadorInicial) &&  Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracion.get("COD_TIPTRATMERC"))
  		    	&& !CodIndicadorActual.equals("00")	){
  		    	paramsInd.put("numcorredoc", declaracion.get("NUM_CORREDOC"));
    		  	paramsInd.put("codtipoindica", declaracionInicial.get("COD_INDICADOR_DONACION"));
    		  	List<DatoIndicadores> LstdatoIndicador=  indicadorDUADAO.findIndicadoresByMap(paramsInd);
    		  	paramsInd.clear();
    		  	if(CollectionUtils.isEmpty(LstdatoIndicador)){
    		  		// nunca deberia llegar aqui pq se ha bloquea en la capa d vista
    		  		paramsInd.put("numCorredoc", declaracion.get("NUM_CORREDOC"));
    		  		paramsInd.put("codIndicador", declaracion.get("COD_INDICADOR_DONACION").toString());
    		  		paramsInd.put("codTiporegistro", "P");
    		        indicadorDUADAO.insertMapSelective(paramsInd);
    		        /*inicio P46-PAS20155E410000032-[jlunah] BUG 25285*/
    		        try {
    		        	/*Graba diferencia es det_ofirecti*/
        		        if(tipoDiligencia != null){
        		        	
        		        	Map keyAdmTemp = new HashMap();
        		            keyAdmTemp.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

        		            Map mapAdmTempDO = new HashMap();
        		            mapAdmTempDO.put("COD_INDICADOR", CodIndicadorInicial);

        		            Map mapAdmTempDif = new HashMap();
        		            mapAdmTempDif.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        		            mapAdmTempDif.put("COD_INDICADOR", CodIndicadorActual);

        		            mapAdmTempDif.put("dataOriginal", mapAdmTempDO);
        		            mapAdmTempDif.put("clave", keyAdmTemp);
        		            
        		            Map nuevo = new HashMap();
        		            nuevo.put("COD_INDICADOR", CodIndicadorActual);
        		            mapAdmTempDif.put("dataModificados", nuevo);
        		            this.registrarRectiOficio(mapAdmTempDif, tipoDiligencia,
        		            		new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0060",numCorredocSol);
        		        }
        		        
					} catch (Exception e) {
						// TODO: handle exception
					}
    		        /*fin P46-PAS20155E410000032-[jlunah] BUG 25285*/
    		  		
    		  	} else
    		  	{
    		  		paramsInd.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
    	  		  	paramsInd.put("COD_INDICADOR_ACTUAL", declaracion.get("COD_INDICADOR_DONACION").toString());
    	  		  	paramsInd.put("COD_INDICADOR", declaracionInicial.get("COD_INDICADOR_DONACION").toString());
    	  		    paramsInd.put("IND_ACTIVO", 1);
    	  		    actualizaIndicador=true;
    		  	}
  		    }
  		// CUANDO SE RETIRA EL TIPO DE TRATAMIENTO O SE RETIRA EL INDICADOR DE INPUGNACION
  		    else{
  		    	if(presentoIndDonacion  && !presentaIndDonacion 
  		    		&& ( Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracionInicial.get("COD_TIPTRATMERC")) || 	Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracion.get("COD_TIPTRATMERC")))){
  		    		paramsInd.put("IND_ACTIVO", 0);// SE RETIRA EL INDICADOR
  		    		paramsInd.put("COD_INDICADOR", declaracionInicial.get("COD_INDICADOR_DONACION").toString());
  		    		paramsInd.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
  		    		actualizaIndicador=true;
  		    	}
  		    }
  		    if(actualizaIndicador){
  		    	indicadorDUADAO.updateByPrimaryKeySelective(paramsInd);	
  		    	
  		    	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25285*/
		        try {
		        	/*Graba diferencia es det_ofirecti*/
    		        if(tipoDiligencia != null){
    		        	
    		        	Map keyAdmTemp = new HashMap();
    		            keyAdmTemp.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

    		            Map mapAdmTempDO = new HashMap();
    		            mapAdmTempDO.put("COD_INDICADOR", CodIndicadorInicial);

    		            Map mapAdmTempDif = new HashMap();
    		            mapAdmTempDif.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
    		            mapAdmTempDif.put("COD_INDICADOR", CodIndicadorActual);

    		            mapAdmTempDif.put("dataOriginal", mapAdmTempDO);
    		            mapAdmTempDif.put("clave", keyAdmTemp);
    		            
    		            Map nuevo = new HashMap();
    		            nuevo.put("COD_INDICADOR", CodIndicadorActual);
    		            mapAdmTempDif.put("dataModificados", nuevo);
    		            this.registrarRectiOficio(mapAdmTempDif, tipoDiligencia,
    		            		new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0060",numCorredocSol);
    		        }
    		        
				} catch (Exception e) {
					// TODO: handle exception
				}
		        /*fin P46-PAS20155E410000032-[jlunah] BUG 25285*/
  		    }
      }
      
   
}
      
      // FIN EJHM
  
  
  /**
   * @param declaracion
   * 
   * 
   * 
   */
  public boolean validarDifDatosProv(Map params){
	  
	  List lstFormBProveedor = (ArrayList) params.get("lstFormBProveedor");      
	  boolean flagDatoCambiado=false;
	  
	  if (lstFormBProveedor != null && lstFormBProveedor.size() > 0) {
	  
	  Map mapProveedor=null;
      Map mapProveedorAnt=null;
      Map datosProveedorActual=null;
      Map datosProveedorAnt=null;
      Map mapSecuencial=null;
      Map particDif;
      
      Map fbKeys=null;
      Comparador comp = new Comparador();
      
      for (int i = 0; i < lstFormBProveedor.size(); i++)
      {
    	  mapProveedor = (HashMap) lstFormBProveedor.get(0); 
    	  fbKeys=new HashMap();
    	  mapSecuencial=new HashMap();
    	  fbKeys.put("num_corredoc", mapProveedor.get("num_corredoc"));
          fbKeys.put("num_secprove", mapProveedor.get("num_secprove"));
    	  
    	  mapProveedorAnt = obtenerElemento((ArrayList<Map<String, Object>>) params.get("lstFormBProveedorAnt"), fbKeys);
    	  if (Constantes.MODO_EDICION_ACTUALIZADO.equals(mapProveedor.get("mod_edicion"))){
    		  if (mapProveedor.get("num_secdeclarante") != null)
              {
        		  datosProveedorActual = new HashMap();
        		  datosProveedorActual.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));
        		  datosProveedorActual.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prd"));
        		  datosProveedorActual.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_prd"));
        		  datosProveedorActual.put("NUM_DOCIDENT", mapProveedor.get("num_docident_prd"));
        		  datosProveedorActual.put("NOM_CARGO", mapProveedor.get("nom_cargo"));
        		  
        		  datosProveedorAnt = new HashMap();
        		  datosProveedorAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secdeclarante"));
        		  datosProveedorAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prd"));
        		  datosProveedorAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_prd"));
        		  datosProveedorAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_prd"));
        		  datosProveedorAnt.put("NOM_CARGO", mapProveedorAnt.get("nom_cargo"));
        		  
        		  mapSecuencial.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));

                  particDif = comp.comparaMapEstricto(datosProveedorAnt, datosProveedorActual, false, false, mapSecuencial);
                  
                  if (Comparador.esDataCambiada(particDif))
                  {
                	  flagDatoCambiado=true;  
                  }
               }
    	  }
    	  
        }
	 } 
    	
	  return flagDatoCambiado;	  
  } 
  
  
  /**
   * @param declaracion
   * @param fecActual
   * @param tipDilig
   * @throws NumberFormatException
   */
  private void insertarPlazoProceso(Map declaracion, FechaBean fecActual, String tipDilig)
                                                                                          throws NumberFormatException
  {
    // Insertamos el registro de plazos
    Map mapPlazo = (HashMap) declaracion.get("mapPlazosProceso");
    if (!MapUtils.esMapaNuloOVacio(mapPlazo))
    {
      mapPlazo.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      mapPlazo.put("COD_TIPPLZ", Constantes.TIPO_PLAZO_PRESENTADO);
      mapPlazo.put("FEC_INICIO", declaracion.get("FEC_DECLARACION"));

      if (mapPlazo.get("FEC_FIN").getClass().getName().equals(fecActual.getClass().getName()))
      {
        mapPlazo.put("FEC_FIN", ((FechaBean) mapPlazo.get("FEC_FIN")).getTimestamp());
      }

      try
      {
        this.plazosProcesoDAO.insert(mapPlazo);
      }
      catch (Exception e)
      {
      }

      // Mapeamos los datos para la rectificacion de oficio
      Map keyPlazo = new HashMap();
      keyPlazo.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      keyPlazo.put("COD_TIPPLZ", mapPlazo.get("COD_TIPPLZ"));
      keyPlazo.put("FEC_INICIO", mapPlazo.get("FEC_INICIO"));

      mapPlazo.put("dataOriginal", null);
      mapPlazo.put("clave", keyPlazo);
      this.registrarRectiOficio(
                                mapPlazo,
                                tipDilig,
                                new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                Constantes.COD_TABLA_PLAZOS_PROCESO);
    }
  }

  /**
   * @param params
   * @throws ServiceException
   */
//RSERRANOV PAS20165E220200076
  private List<Map<String, String>> procesarGrabaContingente(Map params, String tipoDilig) throws ServiceException {
    Map<String, Object> parametros = new HashMap<String, Object>();
    Declaracion decla = (Declaracion) params.get("objDeclaracion");
    UsuarioBean bUsuario = (UsuarioBean) params.get("objUsuario");
    List<Map<String, String>> lstValidacion = null;
    if (bUsuario != null)
      parametros.put("COD_USUMODIF", bUsuario.getNroRegistro());

 List<Map<String, Object>> lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
    List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) params.get("lstDetDeclaraAnt");
    List<Map<String, Object>> lstDetDeclaraEliminada = new ArrayList();
    parametros.put("codTransaccion", tipoDilig);
    Map<String, Object> fbKeys;
    Map cabDeclara = (HashMap) params.get("mapCabDeclaraActual");
    Comparador comp = new Comparador();

    // Para conclusi�n de despacho
    if (   SunatStringUtils.isEqualTo(tipoDilig , Constants.COD_TRANSAC_DILIGENCIACONCLUSION ) ) {
    	 Map prmtVal = new HashMap();
    	 parametros.put("COD_USUMODIF", params.get("cod_funcionario").toString());
    	    prmtVal.put("mapCabDeclara", cabDeclara);
    	    prmtVal.put("lstDetDeclara", params.get("lstDetDeclaraActual"));
    	    prmtVal.put("lstDocAutAsociado", cabDeclara.get("lstDocAutAsociadoActual") );
    	    prmtVal.put("lstDetAutorizacion", cabDeclara.get("lstDetAutorizacionActual"));
    	    prmtVal.put("codTransaccion", Constants.COD_TRANSAC_DILIGENCIACONCLUSION);
    	    decla = GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance().transform(prmtVal);
    }
    Map<String, Object> serieAnt;
    Map<String, Object> serieDif = new HashMap<String, Object>();


    if (lstDetDeclara != null && lstDetDeclara.size() > 0)
    {

      for (Map<String, Object> serie : lstDetDeclara)
      {
        serieDif = new HashMap<String, Object>();
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(cabDeclara.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(serie.get("NUM_SECSERIE").toString().trim()));

        serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt, fbKeys);

        // Si existen diferencias grabamos la serie
        if (!CollectionUtils.isEmpty(serieAnt))
        {
        	
          serieDif = comp.comparaMapEstricto(serieAnt, serie, false, false, fbKeys);
        }
        if (Comparador.esDataCambiada(serieDif))
        {

        	  if (Constantes.IND_ELIMINADO.equals(serieDif.get("IND_DEL")))
              {
                //continue;
              	//serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt, fbKeys);
              	lstDetDeclaraEliminada.add(serie);
              }
        }

      }
    }
    
    parametros.put("lstDetDeclaraEliminada",lstDetDeclaraEliminada);
     lstValidacion =this.grabarContingentesService.procesarContingenteDiligencia(decla,parametros, true);
	if (!CollectionUtils.isEmpty(lstValidacion)) {
		if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipoDilig)||Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(tipoDilig)) {
			return lstValidacion;
		} else {
      String mensajeContigente = lstValidacion.get(0).get("desError");
      throw new ServiceException(this, mensajeContigente);
    }
  }

	return lstValidacion;
  }
//RSERRANOV PAS20165E220200076

  /**
   * Actualizar series.
   *
   * @param params
   *          the params
   */
  private void actualizarSeries(Map params)
  {
    List<Map<String, Object>> lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
    List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) params.get("lstDetDeclaraAnt");

    Map<String, Object> fbKeys;

    List<Map<String, Object>> lstDocuPrece;
    List<Map<String, Object>> lstDocuPreceAnt;
    List<Map<String, Object>> lstDocuPreceDif;

    Map cabDeclara = (HashMap) params.get("mapCabDeclaraActual");
    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
    String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();

    // Obtenemos los datos de series_item
    Long numCorredoc = new Long(cabDeclara.get("NUM_CORREDOC").toString());
    List lstSeriesItem = (ArrayList) params.get("lstSeriesItem");

    Comparador comp = new Comparador();
    Map<String, Object> serieAnt;
    Map<String, Object> serieDif = new HashMap<String, Object>();
   //amancilla String observacionAct = ""; //INICIO PAS20155E220000054

    Map<String, Object> prmtMigrac = new HashMap();
    prmtMigrac.put("lstSeriesItem", lstSeriesItem);
    prmtMigrac.put("mapCabDeclaraActual", cabDeclara);

    List<Map<String, Object>> lstConvenioSerie;
    List<Map<String, Object>> lstConvenioSerieAnt;
    List<Map<String, Object>> lstConvenioSerieDif;
    List<Map<String, Object>> lstFacturaSerie;
    List<Map<String, Object>> lstFacturaSerieAnt;

    if (lstDetDeclara != null && lstDetDeclara.size() > 0){

    	for (Map<String, Object> serie : lstDetDeclara){
    		//pase 15-252
    		if(serie.get("COD_ESTMERC") != null){
    			serie.put("COD_ESTMERC", serie.get("COD_ESTMERC").toString().substring(0, 2));
    		}
    		
    		if(serie.get("COD_UNICOMER") != null && serie.get("COD_UNICOMER").toString().indexOf("-") != -1){
    			serie.put("COD_UNICOMER", serie.get("COD_UNICOMER").toString().substring(0, serie.get("COD_UNICOMER").toString().indexOf("-")));
    		}
    		
    		if(serie.get("COD_PAISORIGEN") != null && serie.get("COD_PAISORIGEN").toString().indexOf("-") != -1){
    			serie.put("COD_PAISORIGEN", serie.get("COD_PAISORIGEN").toString().substring(0, serie.get("COD_PAISORIGEN").toString().indexOf("-")));
    		}
        serieDif = new HashMap<String, Object>();
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(cabDeclara.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(serie.get("NUM_SECSERIE").toString().trim()));

        serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt, fbKeys);

            //INICIO-bug 20206
        if (!CollectionUtils.isEmpty(serieAnt) && serieAnt.containsKey("POR_ALCOHOL"))
            	serieAnt.remove("POR_ALCOHOL");
            //fin-bug 20206
        	
        
        // Si existen diferencias grabamos la serie
        if (!CollectionUtils.isEmpty(serieAnt))
        {  
        	
          serieDif = comp.comparaMapEstricto(serieAnt, serie, false, false, fbKeys);
        }

        if (CollectionUtils.isEmpty(serieAnt))
        {
          if (serie.get("ESTADO_REGISTRO").toString().equals("1"))
          {
            if (Constantes.IND_ELIMINADO.equals(serie.get("IND_DEL")))
            {
              continue;
            }
          }
          //INICIO PAS20155E220000054
            /* amancilla
          if (serie.containsKey("OBSERVACION")){
          	observacionAct = (String)serie.get("OBSERVACION");
          	serie.remove("OBSERVACION");
          }*/
          //FIN PAS20155E220000054
          this.detDeclaraDAO.insertSelective(Utilidades.transformFieldsToRealFormat(serie));
          actualizarSeriesItem(params, serie.get("NUM_SECSERIE").toString());
          prmtMigrac.put("lstSeriesItem", lstSeriesItem);
          prmtMigrac.put("serie", serie);

          this.migrarCambioSeries(prmtMigrac);

          boolean isNewRecord = true;
          Map<String, Object> mapClave = new HashMap<String, Object>();
          mapClave.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
          mapClave.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
          serie.put("clave", mapClave);
          this.registrarRectiOficio(
                                    serie,
                                    tipDilig,
                                    numCorredoc,
                                    Constantes.COD_TABLA_DET_DECLARA,
                                    isNewRecord);
          //INICIO PAS20155E220000054
          //Observacion serie
            /* amancllla
          if(observacionAct != null && observacionAct.isEmpty()){
        	  String tipoObservacion = null;
        	  if(tipDilig.equals(Constantes.DILIG_CONT_DESPACHO)){
        		  tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO;
        	  }else if(tipDilig.equals(Constantes.DILIG_DESCA_PARCIAL)){
        		  tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE_DILIG_DESCARGA_PARCIAL;
        	  }else{
        		  tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE;
        	  }
	          Map<String, Object> mapObs = new HashMap<String, Object>();
	          mapObs.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
	          mapObs.put("NUM_SECOBS", serie.get("NUM_SECSERIE"));
	          mapObs.put("COD_TIPOBS", tipoObservacion);
	          mapObs.put("NUM_SECITEM", serie.get("NUM_SECSERIE"));
	          mapObs.put("OBS_OBS", observacionAct);
	          this.observacionDAO.insert(mapObs);
          }*/
		  //FIN PAS20155E220000054
        }
        else
        {
          if (Comparador.esDataCambiada(serieDif))
          {
            this.detDeclaraDAO.update(Utilidades.transformFieldsToRealFormat(serieDif));
            actualizarSeriesItem(params, serie.get("NUM_SECSERIE").toString());
            prmtMigrac.put("lstSeriesItem", lstSeriesItem);
            prmtMigrac.put("serie", serieDif);
            this.migrarCambioSeries(prmtMigrac);
            this.registrarRectiOficio(serieDif, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_DECLARA);

			//INICIO PAS20155E220000054
          }
          


          }
        	
            //amancilla
            actualizarObservacionEspecialista(tipDilig, serie);

        if (serie.get("lstDocuPreceDua") != null)
        {
          fbKeys = new HashMap();

          fbKeys.put("NUM_CORREDOC", "");
          fbKeys.put("NUM_SECSERIE", "");
          fbKeys.put("NUM_DECLARACIONPRE", "");
          fbKeys.put("ANN_PRESENPRE", "");
          fbKeys.put("COD_ADUANAPRE", "");
          fbKeys.put("COD_REGIMENPRE", "");
          fbKeys.put("NUM_SECSERIEPRE", "");

          lstDocuPreceAnt =
                            ((serieAnt != null && serieAnt.get("lstDocuPreceDua") != null)
                                                                                          ? (ArrayList<Map<String, Object>>) serieAnt
                                                                                                                                     .get("lstDocuPreceDua")
                                                                                          : null);
          lstDocuPrece =
                         ((serie.get("lstDocuPreceDua") != null)
                                                                ? (ArrayList<Map<String, Object>>) serie
                                                                                                        .get("lstDocuPreceDua")
                                                                : null);

          if (lstDocuPrece != null && lstDocuPrece.size() > 0)
          {
            lstDocuPreceDif = comp.comparaList(lstDocuPreceAnt, lstDocuPrece, fbKeys, true, false, true, true);

            for (Map regPre : lstDocuPreceDif)
            {
              fbKeys = new HashMap();
              fbKeys.put("ANN_PRESENPRE", regPre.get("ANN_PRESENPRE"));
              fbKeys.put("NUM_SECSERIEPRE", regPre.get("NUM_SECSERIEPRE"));
              fbKeys.put("NUM_SECSERIE", regPre.get("NUM_SECSERIE"));
              fbKeys.put("COD_ADUANAPRE", regPre.get("COD_ADUANAPRE"));
              fbKeys.put("NUM_DECLARACIONPRE", regPre.get("NUM_DECLARACIONPRE"));
              fbKeys.put("COD_REGIMENPRE", regPre.get("COD_REGIMENPRE"));
              fbKeys.put("NUM_CORREDOC", regPre.get("NUM_CORREDOC"));

              //ini P28-part2 - bug 23913
              if(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION.equals((String)regPre.get("COD_REGIMENPRE"))
            		  && regPre.get("NUM_DECLARACIONPRE") != null) {
            	  String numDeclaracionpre = regPre.get("NUM_DECLARACIONPRE").toString().replaceFirst("^0+(?!$)", "");
            	  fbKeys.put("NUM_DECLARACIONPRE", numDeclaracionpre);
            	  regPre.put("NUM_DECLARACIONPRE", numDeclaracionpre);
              }
              //fin P28-part2 - bug 23913
              
              if (Utilidades.obtenerElemento(lstDocuPreceAnt, fbKeys) == null)
              {
                this.docuPreceDuaDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(regPre));
                this.registrarRectiOficio(
                                          regPre,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_DOCUPRECE_DUA);
              }
              else if ((regPre.get("IND_NUEVO") != null) && ("1".equals(regPre.get("IND_NUEVO").toString().trim())))
              {
                this.docuPreceDuaDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(regPre));
                this.registrarRectiOficio(
                                          regPre,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_DOCUPRECE_DUA);
              }
              //else if ("0".equals(regPre.get("IND_DEL")))//jenciso el comparador ya no lo retorna cuando se cambia solo la fecha.
              else if ((regPre.get("IND_DEL")!=null && "0".equals(regPre.get("IND_DEL"))) || regPre.get("IND_DEL") == null)
              {
                this.docuPreceDuaDAO.updateRegPrecedenciaByMap(Utilidades.transformFieldsToRealFormat(regPre));
                this.registrarRectiOficio(
                                          regPre,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_DOCUPRECE_DUA);
              }
              else if ("1".equals(regPre.get("IND_DEL")))
              {
                this.docuPreceDuaDAO.deleteRegPrecedenciaByPK(Utilidades.transformFieldsToRealFormat(regPre));
                this.registrarRectiOficio(
                                          regPre,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_DOCUPRECE_DUA);
              }
            }
            
            //jenciso Inicio - agregando actualizacion de vehiculos ceticos
            List<Map<String,Object>> lstDatoVehiculo = null;
            List<Map<String,Object>> lstDatoMontoGasto = null;
            List<Map<String,Object>> lstDatoVehiculoAnt = null;
            List<Map<String,Object>> lstDatoMontoGastoAnt = null;
            Map<String,Object> mapVehiculo= null;
            Map<String,Object> mapVehiculoAnt= null;
            //List<Map<String,Object>> lstMontoGastos = null;
            //List<Map<String,Object>> lstMontoGastosAnt = null;
            Map<String,Object> mapVehiculoDif= null;
            /* PAS20145E220000399 INICIO GGRANADOS */
//            List<Map<String,Object>> lstMontoGastosDif = null;
            /* PAS20145E220000399 FIN GGRANADOS */
            
            Map<String,Object> mapClave= null;
            
            if(serie.get("lstDatoVehiculo")!=null && serie.get("lstDatoMontoGasto")!=null){
            	lstDatoVehiculo =  (List<Map<String,Object>>)serie.get("lstDatoVehiculo");
            	lstDatoMontoGasto = (List<Map<String,Object>>)serie.get("lstDatoMontoGasto");
            	if(!CollectionUtils.isEmpty(lstDatoVehiculo) && !CollectionUtils.isEmpty(lstDatoMontoGasto)){
	            	//mapVehiculo= Utilidades.obtenerMapFromObjectDatoVehiculo(lstDatoVehiculo.get(0));
	            	//lstMontoGastos = Utilidades.obtenerListMapFromListObjectDatoMontoGasto(lstDatoMontoGasto);
	            	mapVehiculo = (Map<String,Object>)lstDatoVehiculo.get(0);
	            	
	            	lstDatoVehiculoAnt = (serieAnt!=null && serieAnt.get("lstDatoVehiculo")!=null)?(List<Map<String,Object>>)serieAnt.get("lstDatoVehiculo"):null;
	            	lstDatoMontoGastoAnt = (serieAnt!=null && serieAnt.get("lstDatoMontoGasto")!=null)?(List<Map<String,Object>>)serieAnt.get("lstDatoMontoGasto"):null;
	            	
	            	if(CollectionUtils.isEmpty(lstDatoVehiculoAnt) && CollectionUtils.isEmpty(lstDatoMontoGastoAnt)  ){
	            		//se realiza el insert pero verificando si antes hubo uno en BD
	            		vehiCeticoService.insertarVehiculoCeticos(mapVehiculo);
	            		mapClave = new HashMap<String, Object>();
	            		mapClave.put("NUM_CORREDOC", mapVehiculo.get("NUM_CORREDOC"));
	            		mapClave.put("NUM_SECSERIE", mapVehiculo.get("NUM_SECSERIE"));
	            		mapVehiculo.put("clave", mapClave);
	            		this.registrarRectiOficio(mapVehiculo, tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO, true);
	            		
	            		//eliminamos logicamente los conceptos gasto de toda la serie
	            		Map<String,Object> mapEliminacion = new HashMap<String, Object>();
	            		mapEliminacion.putAll(mapVehiculo);
	            		mapEliminacion.put("IND_DEL", "1");
	            		vehiCeticoService.actualizarDatoEliminacionMontoGastoBySerie(mapEliminacion);
	            		for(Map<String,Object> mapMontoGasto: lstDatoMontoGasto){            			
	            			//se realiza el insert pero verificando si antes hubo uno en BD
	            			vehiCeticoService.insertarMontoGasto(mapMontoGasto);
	            			mapClave = new HashMap<String, Object>();
	            			mapClave.put("NUM_CORREDOC", mapMontoGasto.get("NUM_CORREDOC"));
	            			mapClave.put("NUM_SECSERIE", mapMontoGasto.get("NUM_SECSERIE"));
	            			mapClave.put("COD_CPTOGASTOS", mapMontoGasto.get("COD_CPTOGASTOS"));                		
	            			mapMontoGasto.put("clave", mapClave);
	            			this.registrarRectiOficio(mapMontoGasto, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, true);
	            		}
	            		
	            	}else{
	            		//se compara y se actualiza los datos guardados
	            		mapVehiculoDif = new HashMap<String, Object>();
	            		//mapVehiculoAnt = Utilidades.obtenerMapFromObjectDatoVehiculo(lstDatoVehiculoAnt.get(0));
	            		//lstMontoGastosAnt = Utilidades.obtenerListMapFromListObjectDatoMontoGasto(lstDatoMontoGastoAnt);
	            		mapVehiculoAnt = (Map<String,Object>)lstDatoVehiculoAnt.get(0);
	            		
	            		fbKeys.clear();
	            		fbKeys.put("NUM_CORREDOC", mapVehiculo.get("NUM_CORREDOC"));
	                    fbKeys.put("NUM_SECSERIE", mapVehiculo.get("NUM_SECSERIE"));
	            		//mapVehiculoDif = comp.comparaMapEstricto(mapVehiculoAnt, mapVehiculo, false, false, fbKeys);
	            		mapVehiculoDif = soporteComparadorService.comparaMap(mapVehiculo, mapVehiculoAnt, EnumTablaModel.VEHI_CETICO);
	            		// verificamos si existe data cambiada
	            		//if(Comparador.esDataCambiada(mapVehiculoDif)){
	            		if(soporteComparadorService.esDataCambiada(mapVehiculoDif)){
	            			vehiCeticoDAO.updateSelective(mapVehiculoDif);
	            			//this.registrarRectiOficio(soporteComparadorService.comparaMap(mapVehiculo, mapVehiculoAnt, EnumTablaModel.VEHI_CETICO), tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO);
	            			this.registrarRectiOficio(mapVehiculoDif, tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO, new Integer(0));
	            		}
	            		//si se usa lo siguiente cambia el metodo de registrar los cambios
	            		//mapVehiculoDif = soporteComparadorService.comparaMap(mapVehiculo, mapVehiculoAnt, EnumTablaModel.VEHI_CETICO);
	            		
	            		
	            		
	            		//hacer otro for para guardar en detsolrecti los elimnados (con esto ya no se usaria actualizarDatoEliminacionMontoGastoBySerie)
	            		//segunda alternativa
	            		for(Map<String,Object> mapMontoGasto: lstDatoMontoGasto){
	            			fbKeys.clear();
	                		fbKeys.put("NUM_CORREDOC", mapMontoGasto.get("NUM_CORREDOC"));
	                        fbKeys.put("NUM_SECSERIE", mapMontoGasto.get("NUM_SECSERIE"));
	                        fbKeys.put("COD_CPTOGASTOS", mapMontoGasto.get("COD_CPTOGASTOS"));
	                        if (Utilidades.obtenerElemento(lstDatoMontoGastoAnt, fbKeys) == null){
	                        	//se realiza el insert pero verificando si antes hubo uno en BD
	                			vehiCeticoService.insertarMontoGasto(mapMontoGasto);
	                			            		
	                			mapMontoGasto.put("clave", fbKeys);
	                			this.registrarRectiOficio(mapMontoGasto, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, true);
	                        }else{
	                        	Map<String,Object> mapMontoGastoAnt = Utilidades.obtenerElemento(lstDatoMontoGastoAnt, fbKeys) ;
	                        	Map<String,Object> mapMontoGastoDif = new HashMap<String, Object>();
	                        	
	                        	mapMontoGastoDif = comp.comparaMapEstricto(mapMontoGastoAnt, mapMontoGasto, false, false, fbKeys);
	                        	//verificamos si hay cambios
	                        	if(Comparador.esDataCambiada(mapMontoGastoDif)){
	                        		//mapMontoGastoDif.put("IND_DEL", Constants.INDICADOR_NO_ELIMINADO);
	                            	montoGastoDAO.updateSelective(mapMontoGastoDif);
	                            	this.registrarRectiOficio(mapMontoGastoDif, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO);
	                        	}
	                        }
	            			
	            		}
	            		for(Map<String,Object> mapMontoGastoAnt: lstDatoMontoGastoAnt){
	            			fbKeys.clear();
	                		fbKeys.put("NUM_CORREDOC", mapMontoGastoAnt.get("NUM_CORREDOC"));
	                        fbKeys.put("NUM_SECSERIE", mapMontoGastoAnt.get("NUM_SECSERIE"));
	                        fbKeys.put("COD_CPTOGASTOS", mapMontoGastoAnt.get("COD_CPTOGASTOS"));
	                        if (Utilidades.obtenerElemento(lstDatoMontoGasto, fbKeys) == null){//si no esta en la lista actual se elimina
	                        	Map<String,Object>mapMontoGastoAux = new HashMap<String, Object>();
	                        	Map<String,Object>mapMontoGastoDifAux = new HashMap<String, Object>();
	                        	mapMontoGastoAux.putAll(mapMontoGastoAnt);
	                        	mapMontoGastoAux.put("IND_DEL", Constants.INDICADOR_ELIMINADO);
	                        	mapMontoGastoDifAux = comp.comparaMapEstricto(mapMontoGastoAnt, mapMontoGastoAux, false, false, fbKeys);//para registrar control de cambios
	                        	montoGastoDAO.updateSelective(mapMontoGastoDifAux);
	                        	this.registrarRectiOficio(mapMontoGastoDifAux, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO);
	                        }
	            		}
	            		
	            		
	            		
	            	}
            	
            	}
            }
            
            //jenciso Fin
            
            
          }
        }

        if (serie.get("lstConvenioSerie") != null){
          lstConvenioSerie = (ArrayList) serie.get("lstConvenioSerie");
        	lstConvenioSerieAnt = null != serieAnt ? (ArrayList) serieAnt.get("lstConvenioSerie") : new ArrayList<Map<String, Object>>();

          fbKeys = new HashMap();
          fbKeys.put("NUM_SECSERIE", "");
          fbKeys.put("COD_TIPCONVENIO", "");
          fbKeys.put("COD_CONVENIO", "");
        	
        	lstConvenioSerieDif = comp.comparaList(lstConvenioSerieAnt, lstConvenioSerie, fbKeys, true, false, true, true);
        	
        	if (!CollectionUtils.isEmpty(lstConvenioSerieDif)){
		  //INICIO RIN08
        	 Map<String,Object> mapConvenio;
        	 for (Map convenioSerieAnt : lstConvenioSerieAnt) {
        		  boolean encontrado=false;
        		  
        		  for (Map convenioSerieAct : lstConvenioSerie) {
            		  if ( convenioSerieAnt.get("COD_CONVENIO").toString().trim().equals(convenioSerieAct.get("COD_CONVENIO").toString().trim()) && 
            				convenioSerieAnt.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieAct.get("COD_TIPCONVENIO").toString().trim()) &&
                              convenioSerieAnt.get("IND_DEL").toString().trim().equals(convenioSerieAct.get("IND_DEL").toString().trim())){
            			  encontrado=true; 
            			  break;
            		  }
            		          		  
            	  }
        		  
        		  if (!encontrado){
        			  // Buscamos la clave que se encuentra en el mapa lstConvenioSerieDif
        			  for (Map convenioSerieDif : lstConvenioSerieDif){
        				  if (convenioSerieAnt.get("COD_CONVENIO").toString().trim().equals(convenioSerieDif.get("COD_CONVENIO").toString().trim()) && 
                  				convenioSerieAnt.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieDif.get("COD_TIPCONVENIO").toString().trim()) &&
                  				convenioSerieAnt.get("NUM_SECSERIE").toString().trim().equals(convenioSerieDif.get("NUM_SECSERIE").toString().trim())){
        					  Object claveConvenio = convenioSerieDif.get("clave");
        					  Object dataOriginal = convenioSerieDif.get("dataOriginal");
        					  convenioSerieAnt.put("clave",claveConvenio);
        					  convenioSerieAnt.put("dataOriginal",dataOriginal);
        					  break;        					  
        				  }
        			  }
        			  mapConvenio = new HashMap<String,Object>();
        			  mapConvenio.putAll(convenioSerieAnt);
        			  mapConvenio.put("IND_DEL","1");
        			  this.convenioSerieDAO.update(mapConvenio);
                      this.registrarRectiOficio( mapConvenio,  tipDilig,  numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE);
        			  
        		  }
        		  
        		  
        	  }
        	 
        	 for (Map convenioSerieAct : lstConvenioSerie) {
	       		  boolean encontrado=false;
	       		  
	       		  for (Map convenioSerieAnt :lstConvenioSerieAnt ) {
	           		  if ( convenioSerieAct.get("COD_CONVENIO").toString().trim().equals(convenioSerieAnt.get("COD_CONVENIO").toString().trim()) && 
                                     convenioSerieAct.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieAnt.get("COD_TIPCONVENIO").toString().trim())){
	           			  encontrado=true; 
	           			  break;
	           		  }
	           		          		  
	           	  }
	       		  
	       		  if (!encontrado && !convenioSerieAct.get("COD_CONVENIO").toString().trim().equals("0") && !convenioSerieAct.get("IND_DEL").toString().trim().equals(Constantes.IND_ELIMINADO) ){
	       			  // Buscamos la clave que se encuentra en el mapa lstConvenioSerieDif
        			  for (Map convenioSerieDif : lstConvenioSerieDif){
        				  if (convenioSerieAct.get("COD_CONVENIO").toString().trim().equals(convenioSerieDif.get("COD_CONVENIO").toString().trim()) && 
        						  convenioSerieAct.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieDif.get("COD_TIPCONVENIO").toString().trim()) &&
        						  convenioSerieAct.get("NUM_SECSERIE").toString().trim().equals(convenioSerieDif.get("NUM_SECSERIE").toString().trim())){
        					  Object claveConvenio = convenioSerieDif.get("clave");
        					  Object dataOriginal = convenioSerieDif.get("dataOriginal");
        					  convenioSerieAct.put("clave",claveConvenio);
        					  convenioSerieAct.put("dataOriginal",dataOriginal);
        					  break;        					  
        				  }
        			  }
	       			 mapConvenio = new HashMap<String,Object>();
       			     mapConvenio.putAll(convenioSerieAct);
       			     mapConvenio.put("numCorredoc", serie.get("NUM_CORREDOC"));
       			     mapConvenio.put("numSecserie", convenioSerieAct.get("NUM_SECSERIE"));
       			     mapConvenio.put("codTipconvenio", convenioSerieAct.get("COD_TIPCONVENIO"));
       			     mapConvenio.put("codConvenio", convenioSerieAct.get("COD_CONVENIO"));
//                    this.convenioSerieDAO.insertMapSelective(mapConvenio);
  //                  this.registrarRectiOficio(  mapConvenio,  tipDilig,numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE);
                    
                    //RSV RIN-P47
                    try{
                     this.convenioSerieDAO.insertMapSelective(mapConvenio);
                     this.registrarRectiOficio(  mapConvenio,  tipDilig,numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE);	       			  
                    } catch(DuplicateKeyException e) {
                  	  //PASE 69
                  	  if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig) || Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION.equals(tipDilig) ||
                  			  Constantes.COD_TIPO_DILIGENCIA_CONCLUSION.equals(tipDilig)||Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(tipDilig) ) {
                  		  //Actualizamos registro de convenio
                  		mapConvenio.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
      	                  this.convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(mapConvenio));
      	                  this.registrarRectiOficio(mapConvenio, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE );
                  	  }
                  	  
                    }                  
                    
	       		  }	       		
       	    }
		  //FIN RIN08
          }
        }
         /* if (!CollectionUtils.isEmpty(lstConvenioSerieDif))
          {
            for (Map convenioSerie : lstConvenioSerieDif)
            {
              if ("1".equals(convenioSerie.get("IND_DEL")))
              {
                convenioSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                this.convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(convenioSerie));

                this.registrarRectiOficio(
                                          convenioSerie,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_CONVENIO_SERIE);
              }
              else
              {
                fbKeys.put("NUM_SECSERIE", convenioSerie.get("NUM_SECSERIE"));
                fbKeys.put("COD_TIPCONVENIO", convenioSerie.get("COD_TIPCONVENIO"));
                fbKeys.put("COD_CONVENIO", convenioSerie.get("COD_CONVENIO"));

                if (Utilidades.obtenerElemento(lstConvenioSerieAnt, fbKeys) == null)
                {
                  convenioSerie.put("numCorredoc", serie.get("NUM_CORREDOC"));
                  convenioSerie.put("numSecserie", convenioSerie.get("NUM_SECSERIE"));
                  convenioSerie.put("codTipconvenio", convenioSerie.get("COD_TIPCONVENIO"));
                  convenioSerie.put("codConvenio", convenioSerie.get("COD_CONVENIO"));

                  this.convenioSerieDAO.insertMapSelective(convenioSerie);

                  this.registrarRectiOficio(
                                            convenioSerie,
                                            tipDilig,
                                            numCorredoc,
                                            Constantes.COD_TABLA_CONVENIO_SERIE);
                }
              }
            }
          }
        }*/
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(cabDeclara.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(serie.get("NUM_SECSERIE").toString().trim()));

        if (!CollectionUtils.isEmpty(serieAnt))
        {
          if (serie.get("mapDetAdiAtpa") != null && serieAnt.get("mapDetAdiAtpa") != null)
          {

            Map adAtpaActual = (Map) serie.get("mapDetAdiAtpa");
            adAtpaActual.putAll(fbKeys);
            Map adAtpaAntiguo = (Map) serieAnt.get("mapDetAdiAtpa");
            adAtpaAntiguo.putAll(fbKeys);
            Map adAtpaDif = comp.comparaMapEstricto(adAtpaAntiguo, adAtpaActual, false, false, fbKeys);

            if (Comparador.esDataCambiada(adAtpaDif))
            {
              adAtpaActual.putAll(fbKeys);
              Map<String, Object> mapTabla = new HashMap<String, Object>();
              mapTabla = Utilidades.transformFieldsToRealFormat(adAtpaActual);
              this.detAdiAtpaDAO.updateSelective(mapTabla);
              this.registrarRectiOficio(mapTabla, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_ADI_ATPA);
            }
          }
        }

        if (serie.get("lstFacturaSerie") != null && ((List) serie.get("lstFacturaSerie")).size() > 0)
        {

          lstFacturaSerie = (ArrayList) serie.get("lstFacturaSerie");
          lstFacturaSerieAnt = null != serieAnt ? (ArrayList) serieAnt.get("lstFacturaSerie")
                                               : new ArrayList<Map<String, Object>>();

          fbKeys = new HashMap();
          fbKeys.put("NUM_SECFACT", "");
          fbKeys.put("NUM_SECSERIE", "");

          for (Map facturaSerie : lstFacturaSerie)
          {
            fbKeys.put("NUM_SECFACT", facturaSerie.get("NUM_SECFACT"));
            fbKeys.put("NUM_SECSERIE", facturaSerie.get("NUM_SECSERIE"));
            //RIN13
            String indicadorEliminacion = ObjectUtils.toString(facturaSerie.get("IND_DEL"), "0");
            
            //if ("1".equals(facturaSerie.get("IND_DEL")))
            if("1".equals(indicadorEliminacion))
            { // registrios eliminado
              facturaSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
              String numSecFac = facturaSerie.get("NUM_SECFACT").toString();
              // la factura debe de haber existido en BD
              if (!StringUtils.isBlank(numSecFac) && Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys) != null)
              {
                Map<String, Object> mapActualizar = new HashMap<String, Object>();
                mapActualizar.put("IND_DEL", "1");
                this.facturaSerieDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));
                this.registrarRectiOficio(
                                          mapActualizar,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_FACTURA_SERIE);

                if (isFacturaRegistradaMultiplesSeries(lstDetDeclara, numSecFac) == true)
                {
                  facturaSerie.put("IND_DEL", "0");
                }
                formaFactuDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));
                this.registrarRectiOficio(
                                          mapActualizar,
                                          tipDilig,
                                          numCorredoc,
                                          Constantes.COD_TABLA_FORMA_FACTU);
              }
            }
            else
            { // registros activos
              if (Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys) == null)
              { // es nuevo
                facturaSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));

                // 2 casos mas si el nuevo registro tiene la misma numero de
                // factura no se registra

                String numeroFactura = (String) facturaSerie.get("NUM_FACT");
                Map<String, Object> mapFacturaSerieAnt = buscarFactura(lstDetDeclaraAnt, numeroFactura);

                if (CollectionUtils.isEmpty(mapFacturaSerieAnt))
                {
                  Integer numSecFacturaSiguiente = obtenerNumeroSecFactSeguiente(numCorredoc);
                  facturaSerie.put("NUM_SECFACT", numSecFacturaSiguiente);
                  formaFactuDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  facturaSerieDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  registrarRectiOficio(
                                       facturaSerie,
                                       tipDilig,
                                       numCorredoc,
                                       Constantes.COD_TABLA_FORMA_FACTU);
                }
                else
                { // para este caso lo que se inserta es la una relacion mas
                  // apuntando a la factura que ya existe
                  facturaSerie.put("NUM_SECFACT", mapFacturaSerieAnt.get("NUM_SECFACT"));
                  facturaSerieDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  registrarRectiOficio(
                                       facturaSerie,
                                       tipDilig,
                                       numCorredoc,
                                       Constantes.COD_TABLA_FACTURA_SERIE);
                }
              }
              else
              { // si no es nuevo y actualizado los datos
                Map facturaSerieAnt = Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys);
                Map facturaSerieDif = comp.comparaMapEstricto(facturaSerieAnt, facturaSerie, false, false, fbKeys);
                if (Comparador.esDataCambiada(facturaSerieDif))
                {
                  facturaSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                  // se actualiza la factura ya existe relacion factura_Serie
                  formaFactuDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  this.registrarRectiOficio(
                                            facturaSerie,
                                            tipDilig,
                                            numCorredoc,
                                            Constantes.COD_TABLA_FORMA_FACTU);
                }
              }
            }
          }
        }

        // se esta copiando las tablas complementarias de la copia de la serie
        // ESTADO_REGISTRO=1 NUEVA SERIE amancillaa cambiar este codigo cuando
        // se implemente el mantenimiento de estas tablas
        if (serie.get("ESTADO_REGISTRO").toString().equals("1"))
        {
          Map<String, Object> detAdiAtpa = (HashMap) serie.get("mapDetAdiAtpa");

          if (detAdiAtpa != null && (detAdiAtpa.get("COD_INSUMO") != null
                                     || detAdiAtpa.get("CNT_UNIEQUI") != null || detAdiAtpa.get("COD_UMEQUI") != null))
          {

            Map<String, Object> detAdiAtpaNuevo = new HashMap();
            detAdiAtpaNuevo.put("numCorredoc", serie.get("NUM_CORREDOC"));
            detAdiAtpaNuevo.put("numSecserie", serie.get("NUM_SECSERIE"));

            boolean graba = false;

            if (detAdiAtpa.get("COD_INSUMO") != null && !"".equals(detAdiAtpa.get("COD_INSUMO").toString().trim()))
            {
              detAdiAtpaNuevo.put("codInsumo", detAdiAtpa.get("COD_INSUMO"));
              graba = true;
            }
            if (detAdiAtpa.get("COD_UMEQUI") != null && !"".equals(detAdiAtpa.get("COD_UMEQUI").toString().trim()))
            {
              detAdiAtpaNuevo.put("codUmEqui", detAdiAtpa.get("COD_UMEQUI"));
              graba = true;
            }

            if (detAdiAtpa.get("CNT_UNIEQUI") != null && !"".equals(detAdiAtpa.get("CNT_UNIEQUI").toString().trim())
                && !"0".equals(detAdiAtpa.get("CNT_UNIEQUI").toString().trim()))
            {
              detAdiAtpaNuevo.put("cntUniEqui", detAdiAtpa.get("CNT_UNIEQUI"));
              graba = true;
            }
            if (graba == true)
            {
              detAdiAtpaDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(detAdiAtpaNuevo));
            }

          }
        }
       /*RIN13FSW-INICIO*/ 
	   //INICIO PAS20155E220000054
        /*//REGISTRAR OBSERVACION RIN13
        boolean indActu= false;
        
        Map<String, Object> mapObs = new HashMap<String, Object>();
       
        mapObs.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
        mapObs.put("NUM_SECOBS", serie.get("NUM_SECSERIE"));
        mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_SERIE);
        mapObs.put("NUM_SECITEM",serie.get("NUM_SECSERIE"));
        mapObs.put("OBS_OBS", serie.get("OBSERVACION") !=null ? serie.get("OBSERVACION").toString() : "");
      
        if(indActu){
        	this.observacionDAO.insert(mapObs);
          }else{
    	   this.observacionDAO.update(mapObs);   
        }*/
		//FIN PAS20155E220000054
       //INICIO BUGS 20206-Guardar porcentaje de alcohol 
        
        Map<String, Object> mapPorAlcohol = new HashMap<String, Object>();
        mapPorAlcohol.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
        mapPorAlcohol.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
        DetAdiImpoconsuDAO detAdiImpoconsuDAO = fabricaDeServicios.getService("detAdiImpoconsuDAO");
//GGRANADOS INICIO ALCOHOL
        mapPorAlcohol.put("POR_ALCOHOL", SunatNumberUtils.toBigDecimal(serie.get("POR_ALCOHOL")));        
//GGRANADOS FIN ALCOHOL
        
        List<Map<String, Object>> ItemActual = new ArrayList<Map<String, Object>>();
        
		ItemActual= detAdiImpoconsuDAO.select(mapPorAlcohol);     	        	        	
		  if (!CollectionUtils.isEmpty(ItemActual))
		  {
			//update		
        	detAdiImpoconsuDAO.update(mapPorAlcohol);	
			  
		  }
		  else
		  {
			  if (!serie.get("POR_ALCOHOL").equals("0"))
			  {
				  detAdiImpoconsuDAO.insertSelective(mapPorAlcohol);
        }
   	 	         
		  }   	 	         
       //FIN BUGS 20206-Guardar porcentaje de alcohol

      } //FIN FOR ..
    }//FIN DEL IF 
  }//FIN DEL METODO actualizarSerie

    private void actualizarObservacionEspecialista(String tipDilig, Map<String, Object> serie) {
        String observacionAct = "" ;
        //INICIO PAS20155E220000054
        if (serie.containsKey("OBSERVACION")){
            //amancilla observacionAct = (String)serie.get("OBSERVACION");
            observacionAct = serie.get("OBSERVACION")!=null?serie.get("OBSERVACION").toString().trim():"";
            serie.remove("OBSERVACION");
        }
        //FIN PAS20155E220000054

        //if(observacionAct != null && !observacionAct.isEmpty()){ //siempre inserta uno nuevo por diligencia
        if( StringUtils.isNotEmpty(observacionAct)){ //siempre inserta uno nuevo por diligencia
            String tipoObservacion = null;
                 if(tipDilig.equals(Constantes.DILIG_CONT_DESPACHO)){
                     tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE_DILIG_CONT_DESPACHO;
                 }else if(tipDilig.equals(Constantes.DILIG_DESCA_PARCIAL)){
                     tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE_DILIG_DESCARGA_PARCIAL;
                 }else{
                     tipoObservacion = Constantes.TIPO_OBSERVACION_SERIE;
                 }
            Map<String, Object> mapObs = new HashMap<String, Object>();
                 mapObs.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                 mapObs.put("NUM_SECOBS", serie.get("NUM_SECSERIE"));
                 mapObs.put("COD_TIPOBS", tipoObservacion);
                 mapObs.put("NUM_SECITEM", serie.get("NUM_SECSERIE"));
                 mapObs.put("OBS_OBS", observacionAct);
                 this.observacionDAO.insert(mapObs);


            Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
            mapObsAnt.put("OBS_OBS", "");
            Map<String, Object> mapDiferenciasObs =
                    soporteComparadorService.comparaMap(mapObs, mapObsAnt,
                            EnumTablaModel.OBSERVACION);
            this.registrarRectiOficio(mapDiferenciasObs, tipDilig,  new Long(serie.get("NUM_CORREDOC").toString()),
                    Constantes.COD_TABLA_OBSERVACION);

            //FIN PAS20155E220000054
      }

    }
/*RIN13FSW-FIN*/
  /**
   * metodo que evalua que una factura esta relacionada a multiples series
   * ACTIVAS si tiene varias relaciones no es posible eliminarla si no tiene
   * ninguna relacion activa es posible eliminarla.
   *
   * @param lstDetDeclara
   *          the lst det declara
   * @param numSecFac
   *          the num sec fac
   * @return true, if is factura registrada multiples series
   */
  private boolean isFacturaRegistradaMultiplesSeries(List<Map<String, Object>> lstDetDeclara, String numSecFac)
  {

    boolean banderaUnico = true;
    int contador = 0;
    // recorro la lista de la serie actual con todos los datos editados
    for (Map<String, Object> mapDetDeclara : lstDetDeclara)
    {
      List<Map<String, Object>> lstFacturaSerie = (List<Map<String, Object>>) mapDetDeclara.get("lstFacturaSerie");
      // recorro sus facturas
      for (Map<String, Object> mapFacturaSerie : lstFacturaSerie)
      {
        if (numSecFac.equals(mapFacturaSerie.get("NUM_SECFACT").toString().trim())
            && "0".equals(mapFacturaSerie.get("IND_DEL") == null ? "0" : mapFacturaSerie
                                                                                        .get("IND_DEL")
                                                                                        .toString()
                                                                                        .trim()))
        {
          contador++;
        }
      }
    }
    if (contador >= 1)
    {
      banderaUnico = false;
    }

    return !banderaUnico;
  }

  /**
   * Buscar factura.
   *
   * @param lstDetDeclaraAnt
   *          the lst det declara ant
   * @param numeroFactura
   *          the numero factura
   * @return the map
   */
  private Map<String, Object> buscarFactura(List<Map<String, Object>> lstDetDeclaraAnt, String numeroFactura)
  {

    Map<String, Object> mapRspta = new HashMap<String, Object>();
    for (Map<String, Object> mapDetDeclaraAnt : lstDetDeclaraAnt)
    {
      List<Map<String, Object>> lstFacturaSerie = (List<Map<String, Object>>) mapDetDeclaraAnt.get("lstFacturaSerie");
      for (Map<String, Object> mapFacturaSerie : lstFacturaSerie)
      {
        if (numeroFactura.equals(mapFacturaSerie.get("NUM_FACT")))
        {
          mapRspta = mapFacturaSerie;
        }
      }
    }
    return mapRspta;
  }

  /**
   * Obtener numero sec fact seguiente.
   *
   * @param numCorredoc
   *          the num corredoc
   * @return the integer
   */
  private Integer obtenerNumeroSecFactSeguiente(Long numCorredoc)
  {

    Map mapBusqueda = new HashMap();
    mapBusqueda.put("NUM_CORREDOC", numCorredoc);
    List<Map<String, Object>> listaFacturas = formaFactuDAO.select(mapBusqueda);
    ArrayList arrayList = new ArrayList();
    for (Map mapFactura : listaFacturas)
    {
      arrayList.add(mapFactura.get("NUM_SECFACT"));
    }
    Object obj = Collections.max(arrayList);
    Integer correlativoSgte = SunatNumberUtils.toInteger(obj);
    correlativoSgte = correlativoSgte + 1;

    return correlativoSgte;
  }

  /**
   * Actualizar series item.
   *
   * @param params
   *          the params
   * @param num_secserie
   *          the num_secserie
   * @return the list
   */
  private List<Map<String, Object>> actualizarSeriesItem(Map params, String num_secserie)
  {
    List<Map<String, Object>> lstSeriesItem = (ArrayList) params.get("lstSeriesItem");
    List<Map<String, Object>> lstSeriesItemActual = (ArrayList) params.get("lstSeriesItemActual");
    List<Map<String, Object>> lstSeriesItemReturn = new ArrayList<Map<String, Object>>();
    Map fbKeys = new HashMap();
    Comparador comp = new Comparador();
    Map<String, Object> seriesItem;
    Map<String, Object> serieItemDif;
    if (lstSeriesItemActual != null)
    {
      for (Map<String, Object> seriesItemAct : lstSeriesItemActual)
      {
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(seriesItemAct.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(seriesItemAct.get("NUM_SECSERIE").toString().trim()));
        fbKeys.put("NUM_SECITEM", new Long(seriesItemAct.get("NUM_SECITEM").toString().trim()));
        if (fbKeys.get("NUM_SECSERIE").toString().equals(num_secserie))
        {
          seriesItem = Utilidades.obtenerElemento(lstSeriesItem, fbKeys);
          if (seriesItem != null && seriesItem.size() > 0)
          {
            serieItemDif = comp.comparaMap(seriesItem, seriesItemAct, fbKeys);
            if (Comparador.esDataCambiada(serieItemDif))
            {
              this.seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(serieItemDif));
              lstSeriesItemReturn.add(seriesItemAct);
            }
            else
              lstSeriesItemReturn.add(seriesItem);

          }
          else
          {
            this.seriesItemDAO.insertSelective(Utilidades.transformFieldsToRealFormat(seriesItemAct));
            lstSeriesItemReturn.add(seriesItemAct);
          }
        }
      }
    }
    else
    {
      lstSeriesItemReturn = lstSeriesItem;
    }
    return lstSeriesItemReturn;
  }

  /**
   * Migrar cambio series.
   *
   * @param params
   *          the params
   */
  private void migrarCambioSeries(Map params)
  {
    String tipo = params.get("tipo") != null ? (String) params.get("tipo") : "1";
    Map serie = null;
    Map tabBolQuim = null;

    if ("1".equals(tipo))
    {
      serie = (HashMap) params.get("serie");
    }
    else if ("2".equals(tipo))
    {
      tabBolQuim = (HashMap) params.get("tabBolQuim");
    }

    Map fBItem = null;

    if (("1".equals(tipo) && serie.get("dataOriginal") != null && (((Map) serie.get("dataOriginal"))
                                                                                                    .containsKey("NUM_PARTNANDI") ||
        ((Map) serie.get("dataOriginal")).containsKey("COD_PAISORIGEN"))) || "2".equals(tipo))
    {
      // Buscamos el registro del item correspondiente en la data del formato B
      Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
      List lstSeriesItem = (ArrayList) params.get("lstSeriesItem");

      Map keys = new HashMap();
      if ("1".equals(tipo))
      {
        keys.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
      }
      else
      {
        keys.put("NUM_SECSERIE", tabBolQuim.get("NSERIE_DUA").toString().trim());
      }
      Map serieItem = Utilidades.obtenerElemento(lstSeriesItem, keys);

      if (serieItem != null && serieItem.size() > 0)
      {
        List lstFormBProveedor = (ArrayList) declaracion.get("lstFormBProveedor");
        keys = new HashMap();
        keys.put("NUM_SECPROVE", serieItem.get("NUM_SECPROVE"));

        Map fBProve = ((lstFormBProveedor != null) ? Utilidades.obtenerElemento(lstFormBProveedor, keys) : null);

        if (fBProve != null && fBProve.size() > 0)
        {
          List lstComproBPago = (ArrayList) fBProve.get("lstComproBPago");
          keys = new HashMap();
          keys.put("NUM_SECFACT", serieItem.get("NUM_SECFACT"));

          Map fBFact = ((lstComproBPago != null) ? Utilidades.obtenerElemento(lstComproBPago, keys) : null);

          if (!CollectionUtils.isEmpty(fBFact))
          {
            List lstItemFactura = (ArrayList) fBFact.get("lstItemFactura");
            keys = new HashMap();
            keys.put("NUM_SECITEM", serieItem.get("NUM_SECITEM"));

            fBItem = ((lstItemFactura != null) ? Utilidades.obtenerElemento(lstItemFactura, keys) : null);
          }
        }

        if (!CollectionUtils.isEmpty(fBItem))
        {
          // Si encontramos el registro, actualizamos el mapa
          if ("1".equals(tipo))
          {
            if (((Map) serie.get("dataOriginal")).containsKey("NUM_PARTNANDI"))
            {
              fBItem.put("NUM_PARARANCEL", serie.get("NUM_PARTNANDI"));
            }
            if (((Map) serie.get("dataOriginal")).containsKey("COD_PAISORIGEN"))
            {
              fBItem.put("COD_PAISORIGEN", serie.get("COD_PAISORIGEN"));
            }
          }
          else if ("2".equals(tipo))
          {
            fBItem.put("NUM_PARARANCEL", tabBolQuim.get("CPART_RESUL"));
          }
        }
        else
        {
          // Sino enviamos la actualizaci�n directa a BD
          fBItem = new HashMap();
          fBItem.put("NUM_CORREDOC", serieItem.get("NUM_CORREDOC"));
          fBItem.put("NUM_SECITEM", serieItem.get("NUM_SECITEM"));

          if ("1".equals(tipo))
          {
            if (((Map) serie.get("dataOriginal")).containsKey("NUM_PARTNANDI"))
            {
              fBItem.put("NUM_PARARANCEL", serie.get("NUM_PARTNANDI"));
            }
            if (((Map) serie.get("dataOriginal")).containsKey("COD_PAISORIGEN"))
            {
              fBItem.put("COD_PAISORIGEN", serie.get("COD_PAISORIGEN"));
            }
          }
          else if ("2".equals(tipo))
          {
            fBItem.put("NUM_PARARANCEL", tabBolQuim.get("CPART_RESUL"));
          }

          this.itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(fBItem));
        }
      }
    }
  }

  /**
   * Actualizar bol quimicos.
   *
   * @param params
   *          the params
   */
  private void actualizarBolQuimicos(Map params)
  {
    List lstTabBolQuim = (ArrayList) params.get("lstTabBolQuim");
    List lstTabBolQuimAnt = (ArrayList) params.get("lstTabBolQuimAnt");

    Map<String, Object> fbKeys = new HashMap();
    fbKeys.put("CADUA_SOLBQ", "");
    fbKeys.put("NANNO_SOLBQ", "");
    fbKeys.put("NCORR_SOLBQ", "");

    Comparador comp = new Comparador();
    List<Map<String, Object>> lstDiferencias = comp.comparaList(lstTabBolQuimAnt, lstTabBolQuim, fbKeys);
    if (lstDiferencias != null && lstDiferencias.size() > 0)
    {
      Map mapBolQuim = null;
      Map paramUpd;

      Map paramMigrac = new HashMap();
      paramMigrac.put("tipo", "2");
      paramMigrac.put("mapCabDeclaraActual", params.get("mapCabDeclaraActual"));
      paramMigrac.put("lstSeriesItem", params.get("lstSeriesItem"));
      for (int i = 0; i < lstDiferencias.size(); i++)
      {
        mapBolQuim = (HashMap) lstDiferencias.get(i);
        String estado = mapBolQuim.get("COD_ESTDILIG") != null ? (String) mapBolQuim.get("COD_ESTDILIG") : "";
        if (Comparador.esDataCambiada(mapBolQuim) && Constantes.ESTADO_DILIG_ASIGNADA.equals(estado))
        {
          paramUpd = new HashMap();
          paramUpd.put("CADUA_SOLBQ", mapBolQuim.get("CADUA_SOLBQ"));
          paramUpd.put("NANNO_SOLBQ", mapBolQuim.get("NANNO_SOLBQ"));
          paramUpd.put("NCORR_SOLBQ", mapBolQuim.get("NCORR_SOLBQ"));
          paramUpd.put("CPART_NANDI", mapBolQuim.get("CPART_NANDI"));

          this.tabBolQuimDAO.update(paramUpd);

          if (params.get("mapCabDeclaraActual") != null)
          {
            fbKeys.put("CADUA_SOLBQ", mapBolQuim.get("CADUA_SOLBQ"));
            fbKeys.put("NANNO_SOLBQ", mapBolQuim.get("NANNO_SOLBQ"));
            fbKeys.put("NCORR_SOLBQ", mapBolQuim.get("NCORR_SOLBQ"));

            paramMigrac.put("tabBolQuim", Utilidades.obtenerElemento(lstTabBolQuim, fbKeys));
            this.migrarCambioSeries(paramMigrac);
          }
        }
      }
    }
  }

  /**
   * Metodo que permite actualizar los datos del Formato B.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoB(Map params)
  {
    List lstFormBProveedor = (ArrayList) params.get("lstFormBProveedor");

    if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
    {
      Map mapProveedor;
      Map mapProveedorAnt;
      Map<String, Object> fbKeys = new HashMap();
      Map difProveedor;

      Map montos;
      Map montosAnt;
      Object[] ctrNamesMto;
      Map montoUpd;
      Map montoUpdAnt;
      Map keyMonto;

      Map condiciones;
      Map condicionesAnt;
      Object[] ctrNamesCond;
      Map condUpd;
      Map condUpdAnt;
      Map keyCond;

      Comparador comp = new Comparador();

      Map partic;
      Map particAnt;
      Map keyPartic;
      Map particDif;
      Map paramsFact;

      for (int i = 0; i < lstFormBProveedor.size(); i++)
      {
        mapProveedor = (HashMap) lstFormBProveedor.get(i);

        fbKeys.put("num_corredoc", mapProveedor.get("num_corredoc"));
        fbKeys.put("num_secprove", mapProveedor.get("num_secprove"));
        mapProveedorAnt = obtenerElemento((ArrayList<Map<String, Object>>) params.get("lstFormBProveedorAnt"), fbKeys);

        if (Constantes.MODO_EDICION_ACTUALIZADO.equals(mapProveedor.get("mod_edicion")))
        {
          //RIN13
        	//Verificamos nuevo intermediario
        	boolean isNuevoIntermediario = false;
        	if(Integer.parseInt(mapProveedorAnt.get("num_secintermediario").toString()) == 0 && (mapProveedor.get("ind_intemediario").equals("1") && mapProveedor.get("num_docident_pri") != null)){
        		isNuevoIntermediario = true;
        		Long secuenciaIntermediario = this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_PARTICIPANTE); //se debio usar participanteService
        		mapProveedor.put("num_secintermediario", secuenciaIntermediario);
        	}
        	
        	// Actualizamos los proveedores
          //mapProveedor = (HashMap) lstFormBProveedor.get(i); //RIN13
          //if (Constantes.MODO_EDICION_ACTUALIZADO.equals(mapProveedor.get("mod_edicion")))
          //{
        	//jenciso-- se cambia el comparador para que filtre nulos y vacios
        	  //difProveedor = comp.comparaMapEstricto(mapProveedorAnt, mapProveedor, false, false, fbKeys);
        	  difProveedor = soporteComparadorService.comparaMap(mapProveedor, mapProveedorAnt, EnumTablaModel.FORMBPROVEEDOR);
            
            //if (Comparador.esDataCambiada(difProveedor))
        	if (soporteComparadorService.esDataCambiada(difProveedor))
            {
			/*INICIO RIN13*/
        		this.formBProveedorDAO.update(Utilidades.transformFieldsToRealFormat(Utilidades.convertKeyMapToLowerCase(difProveedor))); 
			/*FIN RIN13*/              
              if (params.get("tipDilig") != null)
              {
                ((HashMap) difProveedor.get("clave")).put("num_corredoc", mapProveedor.get("num_corredoc"));
                this.registrarRectiOficio(difProveedor, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_FORMB_PROVEEDOR);
              }
            }
          //}

          // Actualizamos los montos
          montos = (HashMap) mapProveedor.get("mapFormBMonto");
          montosAnt = (HashMap) mapProveedorAnt.get("mapFormBMonto");
          ctrNamesMto = montos.keySet().toArray();
          if (ctrNamesMto != null && ctrNamesMto.length > 0)
          {
            montoUpd = new HashMap();
            montoUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
            montoUpd.put("num_secprove", mapProveedor.get("num_secprove"));
            for (int j = 0; j < ctrNamesMto.length; j++)
            {
              if (montosAnt == null
                  || montosAnt.get(ctrNamesMto[j].toString()) == null
                  || !montosAnt.get(ctrNamesMto[j].toString()).toString().trim()
                               .equals(montos.get(ctrNamesMto[j].toString()).toString().trim()))
              {
                montoUpd.put("cod_monto", ctrNamesMto[j].toString());
                montoUpd.put("mto_valor", montos.get(ctrNamesMto[j].toString()));

                this.formBMontoDAO.update(Utilidades.transformFieldsToRealFormat(montoUpd));

                // Para la rectificacion de oficio
                if (params.get("tipDilig") != null)
                {
                  montoUpdAnt = new HashMap();
                  montoUpdAnt.put("mto_valor", (montosAnt != null ? montosAnt.get(ctrNamesMto[j].toString()) : null));

                  keyMonto = new HashMap();
                  keyMonto.put("num_corredoc", mapProveedor.get("num_corredoc"));
                  keyMonto.put("num_secprove", mapProveedor.get("num_secprove"));
                  keyMonto.put("cod_monto", ctrNamesMto[j].toString());

                  montoUpd.put("dataOriginal", montoUpdAnt);
                  montoUpd.put("clave", keyMonto);

                  this.registrarRectiOficio(montoUpd, params.get("tipDilig").toString().trim(),
                                            new Long(mapProveedor
                                                                 .get("num_corredoc").toString().trim()),
                                            Constantes.COD_TABLA_FORMB_MONTO);
                }
              }

            }
          }

          // Actualizamos las condiciones de transanccion
          condiciones = (HashMap) mapProveedor.get("mapCondicionTransa");
          condicionesAnt =
                           (mapProveedorAnt.get("mapCondicionTransa") != null
                                                                             ? (HashMap) mapProveedorAnt
                                                                                                        .get("mapCondicionTransa")
                                                                             : null);
          //ctrNamesCond = condiciones.keySet().toArray();
          ctrNamesCond = (condiciones != null ? condiciones.keySet().toArray() : null); 
          
          if (ctrNamesCond != null && ctrNamesCond.length > 0)
          {
            condUpd = new HashMap();
            condUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
            condUpd.put("num_secprove", mapProveedor.get("num_secprove"));

            for (int j = 0; j < ctrNamesCond.length; j++)
            {
              if (condicionesAnt == null
                  || condicionesAnt.get(ctrNamesCond[j].toString()) == null
                  || !condicionesAnt.get(ctrNamesCond[j].toString()).toString().trim()
                                    .equals(
                                            condiciones.get(ctrNamesCond[j].toString()).toString().trim()))
              {
                condUpd.put("cod_indtransaccion", ctrNamesCond[j].toString());
                condUpd.put("ind_transaccion", condiciones.get(ctrNamesCond[j].toString()));
                this.condicionTransaDAO.update(condUpd);

                // Para la rectificacion de oficio
                if (params.get("tipDilig") != null)
                {
                  condUpdAnt = new HashMap();
                  condUpdAnt.put(
                                 "ind_transaccion",
                                 (condicionesAnt != null ? condicionesAnt.get(ctrNamesCond[j].toString()) : null));

                  keyCond = new HashMap();
                  keyCond.put("num_corredoc", mapProveedor.get("num_corredoc"));
                  keyCond.put("num_secprove", mapProveedor.get("num_secprove"));
                  keyCond.put("cod_indtransaccion", ctrNamesCond[j].toString());

                  condUpd.put("dataOriginal", condUpdAnt);
                  condUpd.put("clave", keyCond);

                  this.registrarRectiOficio(condUpd, params.get("tipDilig").toString().trim(),
                                            new Long(mapProveedor
                                                                 .get("num_corredoc").toString().trim()),
                                            Constantes.COD_TABLA_CONDICION_TRANSA);
                }
              }
            }
          }

          // Actualizamos los participantes del Formato B
          partic = new HashMap();

          // Actualizamos el importador
          keyPartic = new HashMap();
          if (mapProveedor.get("num_secpartic_pim") != null)
          {
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pim"));
            partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_pim"));
            partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_pim"));

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_pim"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pim"));
            particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pim"));
            particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pim"));

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));

            particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);

            if (Comparador.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);

              // Para la rectificacion de oficio
              if (params.get("tipDilig") != null)
              {

                this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_PARTICIPANTE_DOC);
              }
            }
          }

          // Actualizamos al proveedor
          if (mapProveedor.get("num_codsecprove") != null)
          {
            partic = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prv"));
            partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prv"));
            partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_prv"));
            partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_prv"));
            partic.put("NUM_FAX", mapProveedor.get("num_fax_prv"));
            partic.put("NUM_TELEFONO", mapProveedor.get("num_telefono_prv"));
            partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_prv"));
            partic.put("NOM_EMAIL", mapProveedor.get("nom_email_prv"));

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_codsecprove"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prv"));
            particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prv"));
            particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_prv"));
            particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_prv"));
            particAnt.put("NUM_FAX", mapProveedorAnt.get("num_fax_prv"));
            particAnt.put("NUM_TELEFONO", mapProveedorAnt.get("num_telefono_prv"));
            particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_prv"));
            particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_prv"));

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));

            particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);

            if (Comparador.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);

              // Para la rectificacion de oficio
              if (params.get("tipDilig") != null)
              {

                this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_PARTICIPANTE_DOC);
              }
            }
          }

          // Actualizamos al proveedor local
          if (mapProveedor.get("num_secpartic_prl") != null)
          {
            partic = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prl"));            
            partic.put("COD_TIPDOC", mapProveedor.get("cod_docprovlocal")); //RIN13
            partic.put("NUM_DOCIDENT", mapProveedor.get("cod_docidentprovloc")); //RIN13

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_prl"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prl")); //RIN13
            particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_docprovlocal"));  //RIN13 
            particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("cod_docidentprovloc"));   //RIN13

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));

            particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);

            if (Comparador.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);

              // Para la rectificacion de oficio
              if (params.get("tipDilig") != null)
              {

                this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_PARTICIPANTE_DOC);
              }
            }
          }
		  /*INICIO RIN13*/
          else {
        	  String tipoDocumentoProveedorLocal = (String)mapProveedor.get("cod_docprovlocal");
        	  String numeroDocumentoProveedorLocal = (String)mapProveedor.get("cod_docidentprovloc");
        	  
        	  if (tipoDocumentoProveedorLocal != null && numeroDocumentoProveedorLocal != null && !tipoDocumentoProveedorLocal.trim().isEmpty() && !numeroDocumentoProveedorLocal.trim().isEmpty())
        	  	{
        	    	  Participante participante = new Participante();		        	 	
		        	  Documento documento = new Documento();
		              Long correlativo = Long.parseLong(mapProveedorAnt.get("num_corredoc").toString());
		              documento.setNumeroCorrelativo(correlativo);
		              Long secuenciaProveedorLocal = this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_PARTICIPANTE); //se debio usar participanteService
		              //participante.setSecuenciaDeParticipantes((Long) mapProveedor.get("num_secpartic_prl"));
		              participante.setSecuenciaDeParticipantes(secuenciaProveedorLocal);
		              participante.setDocumento(documento);
		              participante.getTipoParticipante().setCodDatacat("91");
		              participante.setNombreRazonSocial((String)mapProveedor.get("nom_razonsocial_prl"));
		              //participante.setNumeroDocumentoIdentidad(mapProveedor.get("cod_docidentprovloc").toString());
		  	  	      //participante.getTipoDocumentoIdentidad().setCodDatacat(mapProveedor.get("cod_docidentprovloc").toString());
		              participante.getTipoDocumentoIdentidad().setCodDatacat(tipoDocumentoProveedorLocal);
		              participante.setNumeroDocumentoIdentidad(numeroDocumentoProveedorLocal);
		  	  	      this.participanteDocDAO.insertSelective(participante);
		  	          
		  	    }
          }
  		  /*FIN RIN13*/
          

          // Actualizamos al declarante
          if (mapProveedor.get("num_secdeclarante") != null)
          {
            partic = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prd"));
            partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_prd"));
            partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_prd"));
            partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prd"));
            
            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secdeclarante"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prd"));
            particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_prd"));
            particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_prd"));
            particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prd"));
            
            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));

            particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);

            if (Comparador.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);

              // Para la rectificacion de oficio
              if (params.get("tipDilig") != null)
              {

                this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_PARTICIPANTE_DOC);
              }
            }
          }

          // Actualizamos al intermediario
         //if (Integer.parseInt(mapProveedorAnt.get("num_secintermediario").toString()) != 0) //RIN13
          if(!isNuevoIntermediario)
          {
        	partic = new HashMap();
        	partic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario")); //RIN13
        	partic.put("NOM_RAZONSOCIAL", ObjectUtils.toString(mapProveedor.get("nom_razonsocial_pri"), " ")); //RIN13
        	partic.put("DIR_PARTIC", ObjectUtils.toString(mapProveedor.get("dir_partic_pri"), " ")); //RIN13
        	partic.put("DES_UBIGEOCIUDAD", ObjectUtils.toString(mapProveedor.get("des_ubigeociudad_pri"), " ")); //RIN13
        	partic.put("COD_PAISORIGEN", ObjectUtils.toString(mapProveedor.get("cod_paisorigen_pri"), " ")); //RIN13
          	partic.put("NOM_PAGINAWEB", ObjectUtils.toString(mapProveedor.get("nom_paginaweb_pri"), " ")); //RIN13
          	partic.put("NOM_EMAIL", ObjectUtils.toString(mapProveedor.get("nom_email_pri"), " ")); //RIN13
          	partic.put("COD_TIPDOC", ObjectUtils.toString(mapProveedor.get("cod_tipdoc_pri"), " "));  //RIN13
          	partic.put("NUM_DOCIDENT", ObjectUtils.toString(mapProveedor.get("num_docident_pri"), " "));  //RIN13

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secintermediario"));  //RIN13
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pri"));
            particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_pri"));
            particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_pri"));
            particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_pri"));
            particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_pri"));
            particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_pri"));
            particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pri"));  //RIN13
            particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pri"));  //RIN13

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario"));  //RIN13

            particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);

            if (Comparador.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);

              // Para la rectificacion de oficio
              if (params.get("tipDilig") != null)
              {

                this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                          new Long(mapProveedor
                                                               .get("num_corredoc").toString().trim()),
                                          Constantes.COD_TABLA_PARTICIPANTE_DOC);
              }
            }
          }
          /*INICIO - RIN13*/
          else {
        	  //if ((mapProveedor.get("ind_intemediario").equals("1") && mapProveedor.get("num_docident_pri") != null))
        	  	//{
        	    	  Participante participante = new Participante();		        	 	
		        	  Documento documento = new Documento();
		              Long correlativo = Long.parseLong(mapProveedorAnt.get("num_corredoc").toString());
		              documento.setNumeroCorrelativo(correlativo);
		              participante.setSecuenciaDeParticipantes((Long) mapProveedor.get("num_secintermediario"));
		              participante.setDocumento(documento);
		              participante.setNombreRazonSocial((String)mapProveedor.get("nom_razonsocial_pri"));
		              participante.setDireccion((String)mapProveedor.get("dir_partic_pri"));
		  	  	      participante.setCiudad((String)mapProveedor.get("des_ubigeociudad_pri")); 	
		  	  	      participante.getPais().setCodDatacat((String)mapProveedor.get("cod_paisorigen_pri"));
		  	  	      //participante.setPaginaWeb((String)mapProveedor.get("nom_paginaweb_pri"));
		  	  	      participante.setEmail((String)mapProveedor.get("nom_email_pri"));
		  	  	      participante.setNumeroDocumentoIdentidad((String)mapProveedor.get("num_docident_pri"));
		  	  	      participante.getTipoDocumentoIdentidad().setCodDatacat((String)mapProveedor.get("cod_tipdoc_pri"));
		  	  	      participante.getTipoParticipante().setCodDatacat("90");
		  	          this.participanteDocDAO.insertSelective(participante);
		  	          
		  	    //}
          }
          /*FIN - RIN 13*/
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActual");
        List<Map<String, Object>> lstSeriesItemActualXProv = new ArrayList<Map<String,Object>>();
        for (Map<String, Object> serieItem : lstSeriesItemActual) {//ajuste PAS20165E220200137 diferentes datos
        	if(mapProveedor.get("num_secprove").toString().equals(serieItem.get("NUM_SECPROVE").toString())){
        		lstSeriesItemActualXProv.add(serieItem);
        	}
		}

        // Actualizamos los datos de las facturas, items, series y referencias
        paramsFact = new HashMap();
        paramsFact.put("lstSeriesItemActualXProv", lstSeriesItemActualXProv);
        paramsFact.put("lstComproBPago", mapProveedor.get("lstComproBPago"));
        paramsFact.put("lstComproBPagoAnt", mapProveedorAnt.get("lstComproBPago"));
        paramsFact.put("tipDilig", params.get("tipDilig"));
        this.actualizarFormatoBFact(paramsFact);
      }
      }
    }
  }
    
  
  /**
   * Metodo que permite actualizar los datos del Formato B.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoB(Map params, Integer numCorreDocSol)
  {
    List lstFormBProveedor = (ArrayList) params.get("lstFormBProveedor");

    if (lstFormBProveedor != null && lstFormBProveedor.size() > 0)
    {
      Map mapProveedor;
      Map mapProveedorAnt;
      Map<String, Object> fbKeys = new HashMap();
      Map difProveedor;

      Map montos;
      Map montosAnt;
      Object[] ctrNamesMto;
      Map montoUpd;
      Map montoUpdAnt;
      /* PAS20145E220000399 INICIO GGRANADOS */
//      Map keyMonto;
      /* PAS20145E220000399 FIN GGRANADOS */

      Map condiciones;
      Map condicionesAnt;
      Object[] ctrNamesCond;
      Map condUpd;
      Map condUpdAnt;
      Map keyCond;

      /* PAS20145E220000399 INICIO GGRANADOS */
//      Comparador comp = new Comparador();
      /* PAS20145E220000399 FIN GGRANADOS */

      Map partic;
      Map particAnt;
      Map keyPartic;
      Map particDif;
      Map paramsFact;

      for (int i = 0; i < lstFormBProveedor.size(); i++)
      {
        mapProveedor = (HashMap) lstFormBProveedor.get(i);

        fbKeys.put("num_corredoc", mapProveedor.get("num_corredoc"));
        fbKeys.put("num_secprove", mapProveedor.get("num_secprove"));
        mapProveedorAnt = obtenerElemento((ArrayList<Map<String, Object>>) params.get("lstFormBProveedorAnt"), fbKeys);

        if (Constantes.MODO_EDICION_ACTUALIZADO.equals(mapProveedor.get("mod_edicion")) || mapProveedor.get("mod_borrador")!=null)
        {

          /*INICIO-P34 FSW AFMA*/
            //Verificamos nuevo intermediario
            boolean isNuevoIntermediario = false;
            if(Integer.parseInt(mapProveedorAnt.get("num_secintermediario").toString()) == 0 && (mapProveedor.get("ind_intemediario").equals("1") && mapProveedor.get("num_docident_pri") != null)){
                isNuevoIntermediario = true;
                Long secuenciaIntermediario = this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_PARTICIPANTE); //se debio usar participanteService
                mapProveedor.put("num_secintermediario", secuenciaIntermediario);
            }
          /*FIN-P34 FSW AFMA*/

          // Actualizamos los proveedores
        //  P34 FSW AFMA mapProveedor = (HashMap) lstFormBProveedor.get(i);
        //  if (Constantes.MODO_EDICION_ACTUALIZADO.equals(mapProveedor.get("mod_edicion")) || mapProveedor.get("mod_borrador")!=null)
        //  {
            // difProveedor = comp.comparaMapEstricto(mapProveedorAnt,
            // mapProveedor, false, false, fbKeys);
             /***ini wtaco***********/
        	  mapProveedor.put("NUM_CORREDOC", mapProveedor.get("num_corredoc"));
        	  mapProveedor.put("NUM_SECPROVE", mapProveedor.get("num_secprove"));
        	  mapProveedor.put("NOM_CARGO", mapProveedor.get("nom_cargo"));
        	 /*******fin wtaco****************/
        	  
            difProveedor =
                           soporteComparadorService.comparaMap(mapProveedor, mapProveedorAnt,
                                                               EnumTablaModel.FORMBPROVEEDOR);

            if (soporteComparadorService.esDataCambiada(difProveedor))
            {
              
                /*P34 FSW AFMA se comenta
            	difProveedor.put("num_corredoc", difProveedor.get("NUM_CORREDOC"));
            	difProveedor.put("num_secprove", difProveedor.get("NUM_SECPROVE"));
            	difProveedor.put("nom_cargo", difProveedor.get("NOM_CARGO"));
                 */
/*INICIO-P34 FSW AFMA*/
                this.formBProveedorDAO.update(Utilidades.transformFieldsToRealFormat(Utilidades.convertKeyMapToLowerCase(difProveedor)));
                // Grabacion de otro tipo de medio de pago
                if (((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_MEDIO_PAGO") != null){
                	descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
                	if (mapProveedorAnt.get("des_otro_medio_pago")!=null){
                		Map<String,Object> mapUpdate=new HashMap<String, Object>();
                		mapUpdate.put("NUM_CORREDOC",difProveedor.get("NUM_CORREDOC"));
                		mapUpdate.put("NUM_SECDOC",difProveedor.get("NUM_SECPROVE"));
                		mapUpdate.put("COD_TABLA","T0070");
                		mapUpdate.put("COD_CAMPO","COD_MEDIO_PAGO");
                		mapUpdate.put("COD_CATALOGO","147");
                		mapUpdate.put("COD_VALOR","14");
                		mapUpdate.put("DES_VALOR",((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_MEDIO_PAGO").toString());
                		descripOtrosDAO.updateSelective(mapUpdate);
                	} else {
                		DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(difProveedor.get("NUM_CORREDOC").toString()));
                		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(difProveedor.get("NUM_SECPROVE").toString()));
                		descripcionOtroCatalogo.setCodTabla("T0070");
                		descripcionOtroCatalogo.setCodCampo("COD_MEDIO_PAGO");
                		descripcionOtroCatalogo.setCodCatalogo("147");
                		descripcionOtroCatalogo.setCodValor("14");
                		descripcionOtroCatalogo.setDesValor(((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_MEDIO_PAGO").toString());
                		descripOtrosDAO.insert(descripcionOtroCatalogo);
                	}
                }
                // Grabacion de otra entidad financiera
                if (((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_ENTI_FINANC") != null){
                	descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
                	if (mapProveedorAnt.get("des_otro_enti_financ")!=null){
                		Map<String,Object> mapUpdate=new HashMap<String, Object>();
                		mapUpdate.put("NUM_CORREDOC",difProveedor.get("NUM_CORREDOC"));
                		mapUpdate.put("NUM_SECDOC",difProveedor.get("NUM_SECPROVE"));
                		mapUpdate.put("COD_TABLA","T0070");
                		mapUpdate.put("COD_CAMPO","COD_ENTI_FINANC");
                		mapUpdate.put("COD_CATALOGO","148");
                		mapUpdate.put("COD_VALOR","99");
                		mapUpdate.put("DES_VALOR",((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_ENTI_FINANC").toString());
                		descripOtrosDAO.updateSelective(mapUpdate);
                	} else {
                		DescripcionOtroCatalogo descripcionOtroCatalogo = new DescripcionOtroCatalogo();
                		descripcionOtroCatalogo.setNumCorreDoc(Long.parseLong(difProveedor.get("NUM_CORREDOC").toString()));
                		descripcionOtroCatalogo.setNumSecuenciaDoc(Integer.parseInt(difProveedor.get("NUM_SECPROVE").toString()));
                		descripcionOtroCatalogo.setCodTabla("T0070");
                		descripcionOtroCatalogo.setCodCampo("COD_ENTI_FINANC");
                		descripcionOtroCatalogo.setCodCatalogo("148");
                		descripcionOtroCatalogo.setCodValor("99");
                		descripcionOtroCatalogo.setDesValor(((HashMap)difProveedor.get("dataModificados")).get("DES_OTRO_ENTI_FINANC").toString());
                		descripOtrosDAO.insert(descripcionOtroCatalogo);
                	}
                }
/*FIN-P34 FSW AFMA*/
              this.registrarRectiOficio(difProveedor, params.get("tipDilig").toString(),
                                        new Long(mapProveedor.get("num_corredoc").toString().trim()),
                                        Constantes.COD_TABLA_FORMB_PROVEEDOR, numCorreDocSol);
             
            }
            
          //P34 FSW AFMA}

          // Actualizamos los montos
          if(mapProveedor.get("mapFormBMonto")!=null && mapProveedorAnt.get("mapFormBMonto")!=null){
        	  
	          montos = (HashMap) mapProveedor.get("mapFormBMonto");
	          montosAnt = (HashMap) mapProveedorAnt.get("mapFormBMonto");
	          ctrNamesMto = montos.keySet().toArray();
	          if (ctrNamesMto != null && ctrNamesMto.length > 0)
	          {
	            montoUpd = new HashMap();
	            montoUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
	            montoUpd.put("num_secprove", mapProveedor.get("num_secprove"));
	            for (int j = 0; j < ctrNamesMto.length; j++)
	            {
	              
	            	// JCV 20190513 Se compara valores numericos
	            	BigDecimal valorAnt = montosAnt.get(ctrNamesMto[j].toString())==null?BigDecimal.ZERO:new BigDecimal(montosAnt.get(ctrNamesMto[j].toString()).toString().trim());
	            	BigDecimal valorNew = montos.get(ctrNamesMto[j].toString())==null?BigDecimal.ZERO:new BigDecimal(montos.get(ctrNamesMto[j].toString()).toString().trim());
	            	/*if (montosAnt == null
	                  || montosAnt.get(ctrNamesMto[j].toString()) == null
	                  || !montosAnt.get(ctrNamesMto[j].toString()).toString().trim()
	                               .equals(montos.get(ctrNamesMto[j].toString()).toString().trim()))
	                {*/
	            	if (montosAnt == null
	  	                  || montosAnt.get(ctrNamesMto[j].toString()) == null
	  	                  || valorAnt.compareTo(valorNew)!=0)
	  	                {
		                montoUpd.put("cod_monto", ctrNamesMto[j].toString());
		                montoUpd.put("mto_valor", montos.get(ctrNamesMto[j].toString()));
		
		                this.formBMontoDAO.update(Utilidades.transformFieldsToRealFormat(montoUpd));
		
		                montoUpdAnt = new HashMap();
		                montoUpdAnt.put("mto_valor", (montosAnt != null ? montosAnt.get(ctrNamesMto[j].toString()) : null));
		                /*
		                 * keyMonto = new HashMap(); keyMonto.put("num_corredoc",
		                 * mapProveedor.get("num_corredoc"));
		                 * keyMonto.put("num_secprove",
		                 * mapProveedor.get("num_secprove")); keyMonto.put("cod_monto",
		                 * ctrNamesMto[j].toString());
		                 *
		                 * montoUpd.put("dataOriginal", montoUpdAnt);
		                 * montoUpd.put("clave", keyMonto);
		                 */
		                Map<String, Object> mapDiferencias =
		                                                     soporteComparadorService.comparaMap(montoUpd, montoUpdAnt,
		                                                                                         EnumTablaModel.FORMBMONTO);
		
		                if (soporteComparadorService.esDataCambiada(mapDiferencias))
		                {
		                  this.registrarRectiOficio(montoUpd, params.get("tipDilig").toString().trim(),
		                                            new Long(mapProveedor.get("num_corredoc").toString().trim()),
		                                            Constantes.COD_TABLA_FORMB_MONTO, numCorreDocSol);
		                }
	
	                 }
	
	             }
	           }

          }
          // Actualizamos las condiciones de transanccion
          
          if(mapProveedor.get("mapCondicionTransa")!=null){
        	  
          
          condiciones = (HashMap) mapProveedor.get("mapCondicionTransa");
          condicionesAnt =
                           (mapProveedorAnt.get("mapCondicionTransa") != null
                                                                             ? (HashMap) mapProveedorAnt
                                                                                                        .get("mapCondicionTransa")
                                                                             : null);
          ctrNamesCond = condiciones.keySet().toArray();
          if (ctrNamesCond != null && ctrNamesCond.length > 0)
          {
            condUpd = new HashMap();
            condUpd.put("num_corredoc", mapProveedor.get("num_corredoc"));
            condUpd.put("num_secprove", mapProveedor.get("num_secprove"));

            for (int j = 0; j < ctrNamesCond.length; j++)
            {
              if (condicionesAnt == null
                  || condicionesAnt.get(ctrNamesCond[j].toString()) == null
                  || !condicionesAnt.get(ctrNamesCond[j].toString()).toString().trim()
                                    .equals(
                                            condiciones.get(ctrNamesCond[j].toString()).toString().trim()))
              {
                condUpd.put("cod_indtransaccion", ctrNamesCond[j].toString());
                condUpd.put("ind_transaccion", condiciones.get(ctrNamesCond[j].toString()));
                this.condicionTransaDAO.update(condUpd);

                // Para la rectificacion de oficio
                if (params.get("tipDilig") != null)
                {
                  condUpdAnt = new HashMap();
                  condUpdAnt.put(
                                 "ind_transaccion",
                                 (condicionesAnt != null ? condicionesAnt.get(ctrNamesCond[j].toString()) : null));

                  keyCond = new HashMap();
                  keyCond.put("num_corredoc", mapProveedor.get("num_corredoc"));
                  keyCond.put("num_secprove", mapProveedor.get("num_secprove"));
                  keyCond.put("cod_indtransaccion", ctrNamesCond[j].toString());

                  condUpd.put("dataOriginal", condUpdAnt);
                  condUpd.put("clave", keyCond);

                  Map<String, Object> mapDiferencias =
                                                       soporteComparadorService.comparaMap(condUpd,
                                                                                           condUpdAnt,
                                                                                           EnumTablaModel.CONDICION_TRANSA);

                  if (soporteComparadorService.esDataCambiada(mapDiferencias))
                  {
                    this.registrarRectiOficio(condUpd, params.get("tipDilig").toString().trim(),
                                              new Long(mapProveedor.get("num_corredoc").toString().trim()),
                                              Constantes.COD_TABLA_CONDICION_TRANSA, numCorreDocSol);
                  }
                }
              }
            }
           }
          }
          // Actualizamos los participantes del Formato B
          partic = new HashMap();

          // Actualizamos el importador
          keyPartic = new HashMap();
            /* amancilla no es popsible modifica importador desde el formato B PAS20155E220200035
          if (mapProveedor.get("num_secpartic_pim") != null)
          {
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_pim"));
            partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_pim"));
            partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_pim"));

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_pim"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pim"));
            particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pim"));
            particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pim"));

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_pim"));

            // particDif = comp.comparaMapEstricto(particAnt, partic, false,
            // false, keyPartic);
            particDif = soporteComparadorService.comparaMap(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC);

            if (soporteComparadorService.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);
              this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                        new Long(mapProveedor
                                                             .get("num_corredoc").toString().trim()),
                                        Constantes.COD_TABLA_PARTICIPANTE_DOC, numCorreDocSol);
            }
          }*/

          // Actualizamos al proveedor
          if (mapProveedor.get("num_codsecprove") != null)
          {
            partic = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prv"));
            partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prv"));
            partic.put("DES_UBIGEOCIUDAD", mapProveedor.get("des_ubigeociudad_prv"));
            partic.put("COD_PAISORIGEN", mapProveedor.get("cod_paisorigen_prv"));
            partic.put("NUM_FAX", mapProveedor.get("num_fax_prv"));
            partic.put("NUM_TELEFONO", mapProveedor.get("num_telefono_prv"));
            partic.put("NOM_PAGINAWEB", mapProveedor.get("nom_paginaweb_prv"));
            partic.put("NOM_EMAIL", mapProveedor.get("nom_email_prv"));

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_codsecprove"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prv"));
            particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prv"));
            particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_prv"));
            particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_prv"));
            particAnt.put("NUM_FAX", mapProveedorAnt.get("num_fax_prv"));
            particAnt.put("NUM_TELEFONO", mapProveedorAnt.get("num_telefono_prv"));
            particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_prv"));
            particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_prv"));

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_codsecprove"));

            // particDif = comp.comparaMapEstricto(particAnt, partic, false,
            // false, keyPartic);
            particDif = soporteComparadorService.comparaMap(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC);
            if (soporteComparadorService.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);
              this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                        new Long(mapProveedor
                                                             .get("num_corredoc").toString().trim()),
                                        Constantes.COD_TABLA_PARTICIPANTE_DOC, numCorreDocSol);
            }
          }

          // Actualizamos al proveedor local
          if (mapProveedor.get("num_secpartic_prl") != null)
          {
            partic = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));
            partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prl"));

            particAnt = new HashMap();
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secpartic_prl"));
            particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("num_secpartic_prl"));

            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secpartic_prl"));

            // particDif = comp.comparaMapEstricto(particAnt, partic, false,
            // false, keyPartic);
            particDif = soporteComparadorService.comparaMap(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC);
            if (soporteComparadorService.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);
              this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                        new Long(mapProveedor
                                                             .get("num_corredoc").toString().trim()),
                                        Constantes.COD_TABLA_PARTICIPANTE_DOC, numCorreDocSol);
            }
          }
           /*INICIO-P34 FSW AFMA*/
          else {
              String tipoDocumentoProveedorLocal = (String)mapProveedor.get("cod_docprovlocal");
              String numeroDocumentoProveedorLocal = (String)mapProveedor.get("cod_docidentprovloc");

              if (tipoDocumentoProveedorLocal != null && numeroDocumentoProveedorLocal != null && !tipoDocumentoProveedorLocal.trim().isEmpty() && !numeroDocumentoProveedorLocal.trim().isEmpty())
              {
                  Participante participante = new Participante();
                  Documento documento = new Documento();
                  Long correlativo = Long.parseLong(mapProveedorAnt.get("num_corredoc").toString());
                  documento.setNumeroCorrelativo(correlativo);
                  Long secuenciaProveedorLocal = this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_PARTICIPANTE); //se debio usar participanteService
                  //participante.setSecuenciaDeParticipantes((Long) mapProveedor.get("num_secpartic_prl"));
                  participante.setSecuenciaDeParticipantes(secuenciaProveedorLocal);
                  participante.setDocumento(documento);
                  participante.getTipoParticipante().setCodDatacat("91");
                  participante.setNombreRazonSocial((String)mapProveedor.get("nom_razonsocial_prl"));
                  //participante.setNumeroDocumentoIdentidad(mapProveedor.get("cod_docidentprovloc").toString());
                  //participante.getTipoDocumentoIdentidad().setCodDatacat(mapProveedor.get("cod_docidentprovloc").toString());
				  //PAS20165E220200137 quitar espacios para evitar prblema en la replica
                  participante.getTipoDocumentoIdentidad().setCodDatacat(tipoDocumentoProveedorLocal.trim());
                  participante.setNumeroDocumentoIdentidad(numeroDocumentoProveedorLocal);
                  this.participanteDocDAO.insertSelective(participante);

              }
          }
           /*FIN-P34 FSW AFMA*/

          // Actualizamos al declarante
          if (mapProveedor.get("num_secdeclarante") != null)
          {
            partic = new HashMap();
            particAnt = new HashMap();
            partic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));
            particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secdeclarante"));
            
            if(mapProveedor.get("nom_razonsocial_prd")!=null){
            	partic.put("NOM_RAZONSOCIAL", mapProveedor.get("nom_razonsocial_prd"));
            	particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_prd"));
            	
            }if(mapProveedor.get("cod_tipdoc_prd")!=null){
            	partic.put("COD_TIPDOC", mapProveedor.get("cod_tipdoc_prd"));
            	particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_prd"));
            	
            }if(mapProveedor.get("num_docident_prd")!=null){
            	partic.put("NUM_DOCIDENT", mapProveedor.get("num_docident_prd"));
            	particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_prd"));
            }if(mapProveedor.get("dir_partic_prd")!=null){
            	 partic.put("DIR_PARTIC", mapProveedor.get("dir_partic_prd"));
            	 particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_prd"));
            }
            
            keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secdeclarante"));

            // particDif = comp.comparaMapEstricto(particAnt, partic, false,
            // false, keyPartic);
            particDif = soporteComparadorService.comparaMap(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC);
            if (soporteComparadorService.esDataCambiada(particDif))
            {
              this.participanteDocDAO.update(particDif);
              this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                        new Long(mapProveedor
                                                             .get("num_corredoc").toString().trim()),
                                        Constantes.COD_TABLA_PARTICIPANTE_DOC, numCorreDocSol);
            }
          }

          // Actualizamos al intermediario
          //se completo el o estaba num_secintermediari y no entraba
            /*INICIO-P34 FSW AFMA*/

            

            if(!isNuevoIntermediario)
            {
                partic = new HashMap();
                partic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario")); //RIN13
                partic.put("NOM_RAZONSOCIAL", ObjectUtils.toString(mapProveedor.get("nom_razonsocial_pri"), " ")); //RIN13
                partic.put("DIR_PARTIC", ObjectUtils.toString(mapProveedor.get("dir_partic_pri"), " ")); //RIN13
                partic.put("DES_UBIGEOCIUDAD", ObjectUtils.toString(mapProveedor.get("des_ubigeociudad_pri"), " ")); //RIN13
                partic.put("COD_PAISORIGEN", ObjectUtils.toString(mapProveedor.get("cod_paisorigen_pri"), " ")); //RIN13
                partic.put("NOM_PAGINAWEB", ObjectUtils.toString(mapProveedor.get("nom_paginaweb_pri"), " ")); //RIN13
                partic.put("NOM_EMAIL", ObjectUtils.toString(mapProveedor.get("nom_email_pri"), " ")); //RIN13
                partic.put("COD_TIPDOC", ObjectUtils.toString(mapProveedor.get("cod_tipdoc_pri"), " "));  //RIN13
                partic.put("NUM_DOCIDENT", ObjectUtils.toString(mapProveedor.get("num_docident_pri"), " "));  //RIN13

                particAnt = new HashMap();
            	particAnt.put("NUM_SECPARTIC", mapProveedorAnt.get("num_secintermediario"));
            	particAnt.put("NOM_RAZONSOCIAL", mapProveedorAnt.get("nom_razonsocial_pri"));
            	particAnt.put("DIR_PARTIC", mapProveedorAnt.get("dir_partic_pri"));
            	particAnt.put("DES_UBIGEOCIUDAD", mapProveedorAnt.get("des_ubigeociudad_pri"));
            	particAnt.put("COD_PAISORIGEN", mapProveedorAnt.get("cod_paisorigen_pri"));
            	particAnt.put("NOM_PAGINAWEB", mapProveedorAnt.get("nom_paginaweb_pri"));
            	particAnt.put("NOM_EMAIL", mapProveedorAnt.get("nom_email_pri"));
                particAnt.put("COD_TIPDOC", mapProveedorAnt.get("cod_tipdoc_pri"));  //RIN13
                particAnt.put("NUM_DOCIDENT", mapProveedorAnt.get("num_docident_pri"));  //RIN13

                keyPartic.put("NUM_SECPARTIC", mapProveedor.get("num_secintermediario"));  //RIN13

                //P34 AFMA particDif = comp.comparaMapEstricto(particAnt, partic, false, false, keyPartic);
                particDif = soporteComparadorService.comparaMap(partic, particAnt, EnumTablaModel.PARTICIPANTE_DOC);
                if (Comparador.esDataCambiada(particDif))
                {
                    this.participanteDocDAO.update(particDif);

                    // Para la rectificacion de oficio
                    if (params.get("tipDilig") != null)
                    {

                        this.registrarRectiOficio(particDif, params.get("tipDilig").toString().trim(),
                                new Long(mapProveedor
                                        .get("num_corredoc").toString().trim()),
                                Constantes.COD_TABLA_PARTICIPANTE_DOC, numCorreDocSol);//PAS20175E220200028
                       
                    }
                }
            }
          
            /*FIN-P34 FSW AFMA*/
        }

        // Actualizamos los datos de las facturas, items, series y referencias
        paramsFact = new HashMap();
        paramsFact.put("lstComproBPago", mapProveedor.get("lstComproBPago"));
        paramsFact.put("lstComproBPagoAnt", mapProveedorAnt.get("lstComproBPago"));
        paramsFact.put("tipDilig", params.get("tipDilig"));
        paramsFact.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
        this.actualizarFormatoBFact(paramsFact, numCorreDocSol);
      }
    }
  }

  /**
   * Obtener elemento.
   *
   * @param lstEval
   *          the lst eval
   * @param keys
   *          the keys
   * @return the map
   */
  private Map<String, Object> obtenerElemento(List<Map<String, Object>> lstEval, Map<String, Object> keys)
  {
    return Utilidades.obtenerElemento(lstEval, keys);
  }

  /**
   * Actualizar formato b fact.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoBFact(Map params)
  {
    // Actualizamos las facturas
    List<Map<String, Object>> lstFacturas = (ArrayList) params.get("lstComproBPago");
    List<Map<String, Object>> lstFacturasAnt = (ArrayList) params.get("lstComproBPagoAnt");
    Comparador comp = new Comparador();

    if (lstFacturas != null && lstFacturasAnt != null)
    {

      Map<String, Object> fbKeys = new HashMap();
      fbKeys.put("num_corredoc", "");

      fbKeys.put("num_secfact", "");

      List<Map<String, Object>> lstDiferencias = comp.comparaList(
                                                                  lstFacturasAnt,
                                                                  lstFacturas,
                                                                  fbKeys,
                                                                  false,
                                                                  false,
                                                                  true,
                                                                  true);
      for (Map<String, Object> factura : lstDiferencias)
      {

        if (Comparador.esDataCambiada(factura))
        {
          for (Entry<String, Object> entrada : factura.entrySet())
          {
            if (entrada.getValue() != null && ("null".equals(entrada.getValue().toString().trim())
                || "NULL".equals(entrada.getValue().toString().trim())))
            {
              factura.put(entrada.getKey(), null);
            }
          }

          this.comprobPagoDAO.update(Utilidades.transformFieldsToRealFormat(factura));

          // Para la rectificacion de oficio
          if (params.get("tipDilig") != null)
          {

            this.registrarRectiOficio(factura, params.get("tipDilig").toString().trim(),
                                      new Long(factura.get("num_corredoc").toString().trim()),
                                      Constantes.COD_TABLA_COMPROBPAGO);
          }

        }
      }

      Map<String, Object> facturaAnt;
      Map paramsItm;
      for (Map<String, Object> factura : lstFacturas)
      {
        fbKeys.put("num_corredoc", factura.get("num_corredoc"));

        fbKeys.put("num_secfact", factura.get("num_secfact"));

        facturaAnt = obtenerElemento(lstFacturasAnt, fbKeys);

        // Actualizamos los items de facturas, seriesitem y referencias
        
        List<Map<String, Object>> lstSeriesItemActualXFact = new ArrayList<Map<String,Object>>();
        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActualXProv");
        for (Map<String, Object> serieItemXFact : lstSeriesItemActual) {
			if(serieItemXFact.get("NUM_SECFACT").toString().equals(factura.get("num_secfact").toString())){//ajuste PAS20165E220200137 diferentes datos
				lstSeriesItemActualXFact.add(serieItemXFact);
			}
		}
        
        
        paramsItm = new HashMap();
        paramsItm.put("lstSeriesItemActualXFact", lstSeriesItemActualXFact);
        paramsItm.put("lstItemFactura", factura.get("lstItemFactura"));
        paramsItm.put("lstItemFacturaAnt", facturaAnt.get("lstItemFactura"));
        paramsItm.put("tipDilig", params.get("tipDilig"));
        actualizarFormatoBItems(paramsItm);
      }
    }
  }

  /**
   * Actualizar formato b fact.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoBFact(Map params, Integer numCorreDocSol)
  {
    // Actualizamos las facturas
    List<Map<String, Object>> lstFacturas = (ArrayList) params.get("lstComproBPago");
    List<Map<String, Object>> lstFacturasAnt = (ArrayList) params.get("lstComproBPagoAnt");
    List<Map<String, Object>> lstDiferencias = new ArrayList<Map<String, Object>>();
    // Comparador comp = new Comparador();

    if (lstFacturas != null && lstFacturasAnt != null)
    {

      lstDiferencias = soporteComparadorService.comparaList(lstFacturas, lstFacturasAnt, EnumTablaModel.COMPROB_PAGO);
      
      if(CollectionUtils.isEmpty(lstDiferencias)) {
    	  cambiarClavesMapasDeLista(lstFacturas, Tipo.MAYUSCULA);
    	  cambiarClavesMapasDeLista(lstFacturasAnt, Tipo.MAYUSCULA);
    	  
    	  lstDiferencias = soporteComparadorService.comparaList(lstFacturas, lstFacturasAnt, EnumTablaModel.COMPROB_PAGO);
      }

      cambiarClavesMapasDeLista(lstDiferencias, Tipo.MINUSCULA);
      
      if (!CollectionUtils.isEmpty(lstDiferencias))
      {
        for (Map diferencia : lstDiferencias)
        {
          if (soporteComparadorService.esDataCambiada(diferencia))
          {
        	Map<String,Object> diferenciaMinuscula =  Utilidades.copiarMapa(diferencia);
        	this.cambiarClavezMapa(diferenciaMinuscula);
        	  
            this.comprobPagoDAO.update(diferenciaMinuscula);
            this.registrarRectiOficio(diferencia, params.get("tipDilig").toString().trim(),
                                      new Long(diferencia.get("num_corredoc").toString().trim()),
                                      Constantes.COD_TABLA_COMPROBPAGO, numCorreDocSol);
          }
        }
      }

	  cambiarClavesMapasDeLista(lstFacturas, Tipo.MINUSCULA);
	  cambiarClavesMapasDeLista(lstFacturasAnt, Tipo.MINUSCULA);

      /*
       * if (lstFacturas != null && lstFacturasAnt != null) {
       *
       * Map<String, Object> fbKeys = new HashMap(); fbKeys.put("num_corredoc",
       * "");
       *
       * fbKeys.put("num_secfact", "");
       *
       * List<Map<String, Object>> lstDiferencias = comp.comparaList(
       * lstFacturasAnt, lstFacturas, fbKeys, false, false, true, true); for
       * (Map<String, Object> factura : lstDiferencias) {
       *
       * if (Comparador.esDataCambiada(factura)) { for (Entry<String, Object>
       * entrada : factura.entrySet()) { if (entrada.getValue() != null &&
       * ("null".equals(entrada.getValue().toString().trim()) ||
       * "NULL".equals(entrada.getValue().toString().trim()))) {
       * factura.put(entrada.getKey(), null); } }
       *
       * this.comprobPagoDAO.update(Utilidades.transformFieldsToRealFormat(factura
       * ));
       *
       *
       * Map<String, Object> mapDiferencias =
       * soporteComparadorService.comparaMap(factura, declaracionAnt,
       * EnumTablaModel.COMPROB_PAGO);
       *
       * if (soporteComparadorService.esDataCambiada(mapDiferencias)) {
       * this.registrarRectiOficio(factura,
       * params.get("tipDilig").toString().trim(), new
       * Long(factura.get("num_corredoc").toString().trim()),
       * Constantes.COD_TABLA_COMPROBPAGO,numCorreDocSol); } } }
       */

      Map<String, Object> fbKeys = new HashMap();

      Map<String, Object> facturaAnt;
      Map paramsItm;
      for (Map<String, Object> factura : lstFacturas)
      {
        fbKeys.put("num_corredoc", factura.get("num_corredoc"));

        fbKeys.put("num_secfact", factura.get("num_secfact"));

        facturaAnt = obtenerElemento(lstFacturasAnt, fbKeys);

        // Actualizamos los items de facturas, seriesitem y referencias
        paramsItm = new HashMap();
        paramsItm.put("lstItemFactura", factura.get("lstItemFactura"));
        paramsItm.put("lstItemFacturaAnt", facturaAnt.get("lstItemFactura"));
        paramsItm.put("tipDilig", params.get("tipDilig"));
        paramsItm.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
        actualizarFormatoBItems(paramsItm, numCorreDocSol);
      }
    }
  }

  /**
   * Actualizar formato b items.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoBItems(Map params)
  {
    // Actualizamos los items
    List<Map<String, Object>> lstItems = (ArrayList) params.get("lstItemFactura");
    List<Map<String, Object>> lstItemsAnt = (ArrayList) params.get("lstItemFacturaAnt");
    Comparador comp = new Comparador();

    Map<String, Object> fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");

    fbKeys.put("NUM_SECITEM", "");

    Map mapObs = new HashMap();
    Map keyObs = new HashMap();
    Map mapObsData = new HashMap();
    Map mapObsDataOrig = new HashMap();
    Long numcorredoc = null;
    Map<String, Object> itemF = new HashMap<String, Object>();
    for (int i = 0; i < lstItems.size(); i++)
    {
      itemF = lstItems.get(i);

      // Retirar los campos que pertenecen a la tabla VFOBPROVISIONAL
      if (itemF.containsKey("COD_TIPOVALOR"))
        itemF.remove("COD_TIPOVALOR");
      if (itemF.containsKey("COD_TIPOVALOR_DESC"))
        itemF.remove("COD_TIPOVALOR_DESC");
      if (itemF.containsKey("MTO_MONTO"))
        itemF.remove("MTO_MONTO");
      if (itemF.containsKey("FEC_VALESTIMA"))
        itemF.remove("FEC_VALESTIMA");
      // Retirar los campos de descripci�n
      if (itemF.containsKey("COD_ESTMERC_DESC"))
        itemF.remove("COD_ESTMERC_DESC");
      if (itemF.containsKey("IND_SOFTWARE_DESC"))
        itemF.remove("IND_SOFTWARE_DESC");
      //RIN13
      if (itemF.containsKey("COD_PAISEMBARQUE_DESC"))
    	  itemF.remove("COD_PAISEMBARQUE_DESC");
      if (itemF.containsKey("COD_PAISORIGEN_DESC"))
          itemF.remove("COD_PAISORIGEN_DESC");
      if (itemF.containsKey("COD_UNICOMER_DESC"))
          itemF.remove("COD_UNICOMER_DESC");
      //COD_PAISEMBARQUE_DESC
      //COD_UNICOMER_DESC
      //DESCRIPCION_PARTIDA
      //COD_PAISORIGEN_DESC
      
      // Grabar observaci�n de �tem
      numcorredoc = new Long(itemF.get("NUM_CORREDOC").toString().trim());
      if (!CollectionUtils.isEmpty(this.validarActualizarItem(itemF, lstItemsAnt))){
      if (itemF.get("OBSERVACION") != null && lstItemsAnt != null
          && lstItemsAnt.get(i) != null
          && !itemF
                   .get("OBSERVACION")
                   .toString()
                   .trim()
                   .equals(
                           lstItemsAnt.get(i).get("OBSERVACION") == null ? "" : lstItemsAnt.get(i).get("OBSERVACION")
                                                                                           .toString()))
      {
        // observacion
        mapObs = new HashMap();
        mapObs.put("NUM_CORREDOC", numcorredoc);
        mapObs.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
        mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
        mapObs.put("OBS_OBS", itemF.get("OBSERVACION"));

        // llave observaci�n
        keyObs = new HashMap();
        keyObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
        keyObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
        keyObs.put("COD_TIPOBS", mapObs.get("COD_TIPOBS"));

        mapObsData = new HashMap();
        mapObsData.put("OBS_OBS", itemF.get("OBSERVACION"));
        mapObsDataOrig = new HashMap();
        mapObsDataOrig.put("OBS_OBS", lstItemsAnt.get(i).get("OBSERVACION"));
        mapObsData.put("dataOriginal", mapObsDataOrig);

        //if (itemF.get("NUM_SECOBS") != null && !itemF.get("NUM_SECOBS").equals(""))
        if (itemF.get("NUM_SECOBS") != null && !itemF.get("NUM_SECOBS").equals("") && !"".equals(lstItemsAnt.get(i).get("OBSERVACION") == null ? "" : lstItemsAnt.get(i).get("OBSERVACION").toString())) // mol REQ 2016-012074
        {
          mapObs.put("NUM_SECOBS", itemF.get("NUM_SECOBS"));
          this.observacionDAO.update(mapObs);
        }
        else
        //{
        //  mapObs.put("NUM_SECOBS", "1");
        {//mol insidencia REQ 2016-012074
        	if( "".equals( itemF.get("NUM_SECOBS")==null?"": itemF.get("NUM_SECOBS").toString()))
        	{ 	mapObs.put("NUM_SECOBS", "1");
        	 }
        	else {
        		mapObs.put("NUM_SECOBS", itemF.get("NUM_SECOBS"));
        	}
          this.observacionDAO.insert(mapObs);
        }
        this.registrarRectiOficio(mapObs, params.get("tipDilig").toString().trim(), numcorredoc, "T0083");
      }
      }
      // eliminar campo ombservaci�n, porque no pertenece a �tem
      itemF.remove("OBSERVACION");
      itemF.remove("NUM_SECOBS");
    }
    if ((lstItems != null && lstItems.size() > 0) && (lstItemsAnt != null && lstItemsAnt.size() > 0))
    {
      List<Map<String, Object>> lstDiferencias = comp.comparaList(lstItemsAnt, lstItems, fbKeys);
      for (Map<String, Object> item : lstDiferencias)
      {
    	if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){

    	if (item.size() > 4)
    	{

          this.itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(item));
        }

        // Para la rectificacion de oficio
        if (params.get("tipDilig") != null)
        {

          this.registrarRectiOficio(item, params.get("tipDilig").toString().trim(), new Long(item
                                                                                                 .get("NUM_CORREDOC")
                                                                                                 .toString().trim()),
                                    Constantes.COD_TABLA_ITEM_FACTURA);
        }
    	}
      }
    }
    else if (lstItems != null && lstItems.size() > 0)
    {
      for (Map<String, Object> item : lstItems)
      {
       if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){  
        for (Entry<String, Object> entrada : item.entrySet())
        {
          if ("null".equals(entrada.getValue().toString().trim()))
          {
            item.put(entrada.getKey(), null);
          }
        }

        if (Comparador.esDataCambiada(item))
        {
          this.itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(item));

          // Para la rectificacion de oficio
          if (params.get("tipDilig") != null)
          {
            fbKeys = new HashMap();
            fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
            fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));

            item.put("dataOriginal", null);
            item.put("clave", fbKeys);

            this.registrarRectiOficio(item, params.get("tipDilig").toString().trim(), new Long(item.get("NUM_CORREDOC")
                                                                                                   .toString().trim()),
                                      Constantes.COD_TABLA_ITEM_FACTURA);
          }
        }
       }
      }
    }

    if (lstItems != null && lstItems.size() > 0)
    {
      Map<String, Object> itemAnt;
      Map paramsItm;
      for (Map<String, Object> item : lstItems)
      {
       if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){   
        fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
        fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));

        itemAnt = obtenerElemento(lstItemsAnt, fbKeys);

        List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActualXFact");
        List<Map<String, Object>> lstSeriesItemActualSeriesItem = new ArrayList<Map<String,Object>>();
        for (Map<String, Object> serieItemXItem : lstSeriesItemActual) {
			if(serieItemXItem.get("NUM_SECITEM").toString().equals(item.get("NUM_SECITEM").toString())){//ajuste PAS20165E220200137 diferentes datos
				lstSeriesItemActualSeriesItem.add(serieItemXItem);
			}
		}

        // Actualizamos los items de seriesitem y referencias
        paramsItm = new HashMap();
        paramsItm.put("lstSeriesItemActualSeriesItem", lstSeriesItemActualSeriesItem);
        paramsItm.put("lstSeries", item.get("lstSeriesItem"));
        paramsItm.put("lstRef", item.get("lstReferenciaDuda"));
        paramsItm.put("lstSeriesItemAnt", itemAnt != null ? itemAnt.get("lstSeriesItem") : new ArrayList());
        paramsItm.put("tipDilig", params.get("tipDilig"));
        paramsItm.put("lstDecrMinima",item.get("lstDecrMinima"));
        paramsItm.put("lstDecrMinimaAnt",itemAnt.get("lstDecrMinima"));

        actualizarDetaItems(paramsItm);
       }
      }
/*RIN13FSW-INICIO*/
    //INICIO-FSW
            
    if (!CollectionUtils.isEmpty(lstItems)) 
    {
    	Map<String, Object> itemOld;    	
    	 for (Map<String, Object> item : lstItems)
         {
    		  fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
    	      fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));
    	      itemOld = obtenerElemento(lstItemsAnt, fbKeys);
    	        
    		 if(tieneDescrMinimaNuevaEstructura(item))
    	     {
    	      	  grabarFormbitemdescri(item,itemOld,params.get("tipDilig").toString());
    	     }else{
    	    	 continue;//debe seguir no break! PAS20165E220200137
    	     }	     		
         }
    	 
    	 //para los items eliminados o blanqueado en el formulario se debe acualziar ind_del=1
    	 /* amancilla se comenta pq no hace nada jaaj
    	 Map<String, Object> itemNew;    
    	 for (Map<String, Object> itemOld1 : lstItemsAnt)
         {
    		  fbKeys.put("NUM_CORREDOC", itemOld1.get("NUM_CORREDOC"));
    	      fbKeys.put("NUM_SECITEM", itemOld1.get("NUM_SECITEM"));
    	      itemNew = obtenerElemento(lstItems, fbKeys);
    	        
    		 if(tieneDescrMinimaNuevaEstructura(itemNew))
    	     {
    	      	 if(CollectionUtils.isEmpty(itemNew) && !CollectionUtils.isEmpty(itemOld1))
    	      	 {    	      		     	      		
    	      		itemOld1.put("IND_DEL", "1");
    	      		this.formBItemDescriDAO.updateSelective(itemOld1); 
    	      	 } 
    			 
    	     }else{
    	    	 break;
    	     }	     		
         } */   	
    	 
    }    
    }
    //FIN-FSW
  }//FIN DEL METODO actualizarFormatoBItems
  
  
  
  private void grabarFormbitemdescri(Map<String, Object> item,Map<String, Object> itemOld,String tipDilig) 
  {
	  
		List<Map<String, Object>> lstDecrMinimaOld = new ArrayList<Map<String,Object>>();
		  if (!CollectionUtils.isEmpty(itemOld)) 	      {
			  lstDecrMinimaOld = (ArrayList)itemOld.get("lstDecrMinima");
	      }

	  
	if(!CollectionUtils.isEmpty(item) 
			&& !CollectionUtils.isEmpty((ArrayList)item.get("lstDecrMinima"))){
				
		//  List<Map<String, Object>> lstDiferencias = soporteComparadorService.comparaList((ArrayList)item.get("lstDecrMinima"), (ArrayList)itemOld.get("lstDecrMinima") , EnumTablaModel.FORMBITEMDESCRI);
		  List<Map<String, Object>> lstDiferencias = soporteComparadorService.comparaList((ArrayList)item.get("lstDecrMinima"), lstDecrMinimaOld , EnumTablaModel.FORMBITEMDESCRI);
		  
	      if (!CollectionUtils.isEmpty(lstDiferencias))
	      {
	        for (Map diferencia : lstDiferencias)
	        {	        	
	        	String tipoOperacionBD = (String) diferencia.get("tipoOperacionBD");	        	
	        	if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD)){
	        		
	        		this.formBItemDescriDAO.updateSelective(diferencia);
		            /*
	        		this.registrarRectiOficio(diferencia, tipDilig,
		                                      new Long(diferencia.get("num_corredoc").toString().trim()),
		                                      Constantes.COD_TABLA_FORMBITEMDESCRI);*/
	        	}
	        	else if (Constantes.REGISTRO_NUEVO.equals(tipoOperacionBD)){
	        		
	        		this.formBItemDescriDAO.insertSelective(diferencia);
	        		
	        		 /*this.registrarRectiOficio(diferencia, tipDilig,
                             new Long(diferencia.get("num_corredoc").toString().trim()),
                             Constantes.COD_TABLA_FORMBITEMDESCRI);*/
	        	}	        			        	
	        }	          
    }

    //amancilla FSW datos eliminados
	      //comparacion a la inversa que buena se me hubiera ocurrido antes
	      if (!CollectionUtils.isEmpty(itemOld)) 	      {
			  lstDecrMinimaOld = (ArrayList)itemOld.get("lstDecrMinima");
	      }
	  //List<Map<String, Object>> lstDiferencias2 = soporteComparadorService.comparaList((ArrayList)itemOld.get("lstDecrMinima"), (ArrayList)item.get("lstDecrMinima"), EnumTablaModel.FORMBITEMDESCRI);    
	 List<Map<String, Object>> lstDiferencias2 = soporteComparadorService.comparaList(lstDecrMinimaOld, (ArrayList)item.get("lstDecrMinima"), EnumTablaModel.FORMBITEMDESCRI);
	  if (!CollectionUtils.isEmpty(lstDiferencias2))
      {
        for (Map diferencia : lstDiferencias2)
        {	
        	Map dataOriginal = (Map) diferencia.get("dataOriginal");
        	Map dataModificados = (Map) diferencia.get("dataModificados");
        	
        	if (!CollectionUtils.isEmpty(dataModificados) && CollectionUtils.isEmpty(dataOriginal)) {
        		
                Map<String,Object> descrMinEliminado = new HashMap<String,Object>();
                descrMinEliminado.put("NUM_CORREDOC", diferencia.get("NUM_CORREDOC"));
                descrMinEliminado.put("NUM_SECITEM", diferencia.get("NUM_SECITEM"));
                descrMinEliminado.put("COD_MERCANCIA", diferencia.get("COD_MERCANCIA"));
                descrMinEliminado.put("COD_TIPDESC", diferencia.get("COD_TIPDESC"));
                descrMinEliminado.put("IND_DEL", "1");         
        		
        		this.formBItemDescriDAO.updateSelective(descrMinEliminado);
	            /*
        		this.registrarRectiOficio(diferencia, tipDilig,
	                                      new Long(diferencia.get("num_corredoc").toString().trim()),
	                                      Constantes.COD_TABLA_FORMBITEMDESCRI);*/
        	}
        	        		                	
        }
      }
	      
  }
  }

private boolean tieneDescrMinimaNuevaEstructura(Map<String, Object> item) {

	  boolean tieneNuevaEstructura = false;
	  	  
	  String tipo = (item!=null && item.get("COD_TIPDESCRMIN")!=null)?item.get("COD_TIPDESCRMIN").toString():"";
	  if(StringUtils.isNotBlank(tipo) && StringUtils.isNotBlank(catalogoAyudaService.getDescripcionDataCatalogo("393", tipo))){
		  tieneNuevaEstructura = true;
	  }
		  	  	  
	return tieneNuevaEstructura;
  }

/*RIN13FSW-FIN*/

  /**
   * Actualizar formato b items.
   *
   * @param params
   *          the params
   */
  private void actualizarFormatoBItems(Map params, Integer numCorreDocSol)
  {
    // Actualizamos los items
    List<Map<String, Object>> lstItems = (ArrayList) params.get("lstItemFactura");
    List<Map<String, Object>> lstItemsAnt = (ArrayList) params.get("lstItemFacturaAnt");
    Comparador comp = new Comparador();

    Map<String, Object> fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");

    fbKeys.put("NUM_SECITEM", "");

    Map mapObs = new HashMap();
    /* PAS20145E220000399 INICIO GGRANADOS */
//    Map keyObs = new HashMap();
    /* PAS20145E220000399 FIN GGRANADOS */
    Map mapObsData = new HashMap();
    Map mapObsDataOrig = new HashMap();
    Long numcorredoc = null;
    Map<String, Object> itemF = new HashMap<String, Object>();

    if (lstItems != null && lstItems.size() > 0)
    {

      for (int i = 0; i < lstItems.size(); i++)
      {
        itemF = lstItems.get(i);

        // Retirar los campos que pertenecen a la tabla VFOBPROVISIONAL
          if (itemF.containsKey("COD_TIPOVALOR"))
              itemF.remove("COD_TIPOVALOR");
          if (itemF.containsKey("COD_TIPOVALOR_DESC"))
              itemF.remove("COD_TIPOVALOR_DESC");
          if (itemF.containsKey("MTO_MONTO"))
              itemF.remove("MTO_MONTO");
          if (itemF.containsKey("FEC_VALESTIMA"))
              itemF.remove("FEC_VALESTIMA");
          // Retirar los campos de descripci�n
          if (itemF.containsKey("COD_ESTMERC_DESC"))
              itemF.remove("COD_ESTMERC_DESC");
          if (itemF.containsKey("IND_SOFTWARE_DESC"))
              itemF.remove("IND_SOFTWARE_DESC");
          //RIN13
          if (itemF.containsKey("COD_PAISEMBARQUE_DESC"))
              itemF.remove("COD_PAISEMBARQUE_DESC");
          if (itemF.containsKey("COD_PAISORIGEN_DESC"))
              itemF.remove("COD_PAISORIGEN_DESC");
          if (itemF.containsKey("COD_UNICOMER_DESC"))
              itemF.remove("COD_UNICOMER_DESC");

        // Grabar observaci�n de �tem
        numcorredoc = new Long(itemF.get("NUM_CORREDOC").toString().trim());
        if (!CollectionUtils.isEmpty(this.validarActualizarItem(itemF, lstItemsAnt))){ 
        if (itemF.get("OBSERVACION") != null && lstItemsAnt != null
            && lstItemsAnt.get(i) != null
            && !itemF
                     .get("OBSERVACION")
                     .toString()
                     .trim()
                     .equals(
                             lstItemsAnt.get(i).get("OBSERVACION") == null ? "" : lstItemsAnt.get(i).get("OBSERVACION")
                                                                                             .toString()))
        {
          // observacion
          mapObs = new HashMap();
          mapObs.put("NUM_CORREDOC", numcorredoc);
          mapObs.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
          mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
          mapObs.put("OBS_OBS", itemF.get("OBSERVACION"));

          // llave observaci�n
          /*keyObs = new HashMap();
          keyObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
          keyObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
          keyObs.put("COD_TIPOBS", mapObs.get("COD_TIPOBS"));*/

          mapObsData = new HashMap();
          mapObsData.put("OBS_OBS", itemF.get("OBSERVACION"));
          mapObsDataOrig = new HashMap();
          mapObsDataOrig.put("OBS_OBS", lstItemsAnt.get(i).get("OBSERVACION"));
          mapObsData.put("dataOriginal", mapObsDataOrig);

          if (itemF.get("NUM_SECOBS") != null && !itemF.get("NUM_SECOBS").equals("") && !"".equals(lstItemsAnt.get(i).get("OBSERVACION") == null ? "" : lstItemsAnt.get(i).get("OBSERVACION").toString())) // mol REQ 2016-012074
          {
            mapObs.put("NUM_SECOBS", itemF.get("NUM_SECOBS"));
            this.observacionDAO.update(mapObs);
          }
          else
          {//mol incidencia REQ 2016-012074
        	  if( "".equals( itemF.get("NUM_SECOBS")==null?"": itemF.get("NUM_SECOBS").toString()))
        	  { mapObs.put("NUM_SECOBS", "1");
        	  }
        	  else {
        		  mapObs.put("NUM_SECOBS", itemF.get("NUM_SECOBS"));
        		  }
        	  
            this.observacionDAO.insert(mapObs);
          }

          // this.registrarRectiOficio(mapObs,
          // params.get("tipDilig").toString().trim(), numcorredoc,
          // "T0083",numCorreDocSol);

          Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
          mapObsAnt.put("OBS_OBS", mapObsDataOrig.get("OBS_OBS"));
          Map<String, Object> mapDiferenciasObs =
                                                  soporteComparadorService.comparaMap(mapObs, mapObsAnt,
                                                                                      EnumTablaModel.OBSERVACION);
          this.registrarRectiOficio(mapDiferenciasObs, params.get("tipDilig").toString().trim(), numcorredoc,
                                    Constantes.COD_TABLA_OBSERVACION, numCorreDocSol);

        }
       }
        // eliminar campo ombservaci�n, porque no pertenece a �tem
        itemF.remove("OBSERVACION");
        itemF.remove("NUM_SECOBS");
      }
    }

    if ((lstItems != null && lstItems.size() > 0) && (lstItemsAnt != null && lstItemsAnt.size() > 0))
    {
      List<Map<String, Object>> lstDiferencias = comp.comparaList(lstItemsAnt, lstItems, fbKeys);
      for (Map<String, Object> item : lstDiferencias)
      {
    	
      if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){
    	if (item.size() > 4)
        {
          this.itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(item));

          fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
          fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));
          Map<String, Object> mapDiferencias =
                                               soporteComparadorService.comparaMap(item,
                                                                                   Utilidades.obtenerElemento(lstItemsAnt,
                                                                                                              fbKeys),
                                                                                   EnumTablaModel.ITEMFACTURA);

          if (soporteComparadorService.esDataCambiada(mapDiferencias))
          {
            this.registrarRectiOficio(mapDiferencias, params.get("tipDilig").toString().trim(),
                                      new Long(item
                                                   .get("NUM_CORREDOC").toString().trim()),
                                      Constantes.COD_TABLA_ITEM_FACTURA, numCorreDocSol);
          }
         }
        }
      }
    }
    else if (lstItems != null && lstItems.size() > 0)
    {
      for (Map<String, Object> item : lstItems)
      {
       if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){
        for (Entry<String, Object> entrada : item.entrySet())
        {
          if ("null".equals(entrada.getValue().toString().trim()))
          {
            item.put(entrada.getKey(), null);
          }
        }

        if (Comparador.esDataCambiada(item))
        {
          this.itemFacturaDAO.update(Utilidades.transformFieldsToRealFormat(item));

          fbKeys = new HashMap();
          fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
          fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));
          Map<String, Object> mapDiferencias =
                                               soporteComparadorService.comparaMap(item,
                                                                                   Utilidades.obtenerElemento(lstItemsAnt,
                                                                                                              fbKeys),
                                                                                   EnumTablaModel.ITEMFACTURA);
          if (soporteComparadorService.esDataCambiada(mapDiferencias))
          {
            this.registrarRectiOficio(item, params.get("tipDilig").toString().trim(), new Long(item.get("NUM_CORREDOC")
                                                                                                   .toString().trim()),
                                      Constantes.COD_TABLA_ITEM_FACTURA, numCorreDocSol);
          }
         }
        }
      }
    }

    if (lstItems != null && lstItems.size() > 0)
    {
      Map<String, Object> itemAnt;
      Map paramsItm;
      for (Map<String, Object> item : lstItems)
      {
       if (!CollectionUtils.isEmpty(this.validarActualizarItem(item, lstItemsAnt))){  
        fbKeys.put("NUM_CORREDOC", item.get("NUM_CORREDOC"));
        fbKeys.put("NUM_SECITEM", item.get("NUM_SECITEM"));

        itemAnt = obtenerElemento(lstItemsAnt, fbKeys);

        // Actualizamos los items de seriesitem y referencias
        paramsItm = new HashMap();
        paramsItm.put("lstSeries", item.get("lstSeriesItem"));
        paramsItm.put("lstRef", item.get("lstReferenciaDuda"));
        paramsItm.put("lstSeriesItemAnt", itemAnt != null ? itemAnt.get("lstSeriesItem") : new ArrayList());
        paramsItm.put("tipDilig", params.get("tipDilig"));
        paramsItm.put("lstSeriesItemActualSeriesItem", this.filtrarCorrelacionesPorItem(params, item));
        paramsItm.put("lstDecrMinima",item.get("lstDecrMinima"));
        paramsItm.put("lstDecrMinimaAnt",itemAnt.get("lstDecrMinima"));
        actualizarDetaItems(paramsItm, numCorreDocSol);
       }
      }
    }
  }

  /**
   * Actualizar deta items.
   *
   * @param params
   *          the params
   */
  private void actualizarDetaItems(Map params)
  {
    // Actualizamos las seriesitem
    List<Map<String, Object>> lstSeries = (ArrayList) params.get("lstSeries");
    List<Map<String, Object>> lstSeriesAnt = (ArrayList) params.get("lstSeriesAnt");
    List<Map<String, Object>> lstSeriesActual = (List<Map<String, Object>>) params.get("lstSeriesItemActualSeriesItem");
    
    Comparador comp = new Comparador();

    Map<String, Object> fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");

    fbKeys.put("NUM_SECITEM", "");
    fbKeys.put("NUM_SECSERIE", "");
    if (lstSeriesActual != null && lstSeriesAnt != null)
    {

      List<Map<String, Object>> lstDiferencias = comp.comparaList(lstSeriesAnt, lstSeriesActual, fbKeys);
      for (Map<String, Object> serie : lstDiferencias)
      {

        if (Comparador.esDataCambiada(serie))
        {
          this.seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(serie));
        }
      }
    }
    else if (lstSeries != null)
    {
      for (Map<String, Object> serie : lstSeries)
      {
        this.seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(serie));
      }
    }

    // Actualizamos las referencias
    List<Map<String, Object>> lstRef = (ArrayList) params.get("lstRef");

    if (!CollectionUtils.isEmpty(lstRef))
    {
      for (Map<String, Object> ref : lstRef)
      {
        this.referenciaDudaDAO.insert(ref);
      }
    }

    // Actualizamos las lstDecrMinima
    FechaBean fecActual = new FechaBean();
    //RIN13 x mientras ya que sale error lstDecrMinima String no List verificar porque se setea String y no List!!!!!!!!!!!!!!!!!!!
    Object objectDecrMinima = params.get("lstDecrMinima");
    if(objectDecrMinima instanceof List){
    	List<Map<String, Object>> lstDecrMinima = (ArrayList) objectDecrMinima;
    	//List<Map<String, Object>> lstDecrMinima = (ArrayList) params.get("lstDecrMinima");
    	List<Map<String, Object>> lstDecrMinimaAnt = (ArrayList) params.get("lstDecrMinimaAnt");
        if (!CollectionUtils.isEmpty(lstDecrMinima)){
        	for(Map<String, Object> descrMin : lstDecrMinima){
        	
        		Map<String,Object> keys = new HashMap<String,Object>();
        		keys.put("NUM_CORREDOC", descrMin.get("NUM_CORREDOC"));
        		keys.put("NUM_SECITEM", descrMin.get("NUM_SECITEM"));
        		keys.put("COD_MERCANCIA", descrMin.get("COD_MERCANCIA"));
        		keys.put("COD_TIPDESC", descrMin.get("COD_TIPDESC"));
        		
        		Map<String,Object> descripcion = Utilidades.obtenerElemento(lstDecrMinimaAnt, keys);
        		if(descripcion!=null){
        			//considerar logica de comparacion aca! cuando no tiene minimas nueva estructura
        			
        			//descrMin.put("FEC_MODIF", fecActual.getTimestamp());//esto ya lo hace el trigger PASE137 DESCRMIN AREY
        			formBItemDescriDAO.updateSelective(descrMin);
        		}
        		
            }
        }
    }
    //RIN13
  }

  /**
   * Actualizar deta items.
   *
   * @param params
   *          the params
   */
  private void actualizarDetaItems(Map params, Integer numCorreDocSol)
  {
    // Actualizamos las seriesitem
    List<Map<String, Object>> lstSeries = (ArrayList) params.get("lstSeries");
    List<Map<String, Object>> lstSeriesAnt = (ArrayList) params.get("lstSeriesAnt");
    List<Map<String, Object>> lstSeriesItemActual = (ArrayList) params.get("lstSeriesItemActualSeriesItem");
    Comparador comp = new Comparador();

    Map<String, Object> fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");

    fbKeys.put("NUM_SECITEM", "");
    fbKeys.put("NUM_SECSERIE", "");
    if (lstSeriesItemActual != null && lstSeriesAnt != null)
    {

      List<Map<String, Object>> lstDiferencias = comp.comparaList(lstSeriesAnt, lstSeriesItemActual, fbKeys);
      for (Map<String, Object> serie : lstDiferencias)
      {

        if (Comparador.esDataCambiada(serie))
        {
          this.seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(serie));
        }
      }
    }
    else if (lstSeries != null)
    {
      for (Map<String, Object> serie : lstSeries)
      {

        this.seriesItemDAO.update(Utilidades.transformFieldsToRealFormat(serie));
      }
    }

    // Actualizamos las referencias
    List<Map<String, Object>> lstRef = (ArrayList) params.get("lstRef");

    if (!CollectionUtils.isEmpty(lstRef))
    {
      for (Map<String, Object> ref : lstRef)
      {
        this.referenciaDudaDAO.insert(ref);
      }
    }
    
    // Actualizamos las lstDecrMinima
    FechaBean fecActual = new FechaBean();
    List<Map<String, Object>> lstDecrMinima = (ArrayList) params.get("lstDecrMinima");
    List<Map<String, Object>> lstDecrMinimaAnt = (ArrayList) params.get("lstDecrMinimaAnt");
    if (!CollectionUtils.isEmpty(lstDecrMinima)){
    	for(Map<String, Object> descrMin : lstDecrMinima){
    	
    		Map<String,Object> keys = new HashMap<String,Object>();
    		keys.put("NUM_CORREDOC", descrMin.get("NUM_CORREDOC"));
    		keys.put("NUM_SECITEM", descrMin.get("NUM_SECITEM"));
    		keys.put("COD_MERCANCIA", descrMin.get("COD_MERCANCIA"));
    		keys.put("COD_TIPDESC", descrMin.get("COD_TIPDESC"));
    		
    		Map<String,Object> descripcion = Utilidades.obtenerElemento(lstDecrMinimaAnt, keys);
    		if(descripcion!=null){
    		
    		/****Inicio cambios del PAS20165E220200055**/
//    			descrMin.put("FEC_MODIF", fecActual.getTimestamp());//se comenta
//    			formBItemDescriDAO.updateSelective(descrMin);//se comenta
//    		}
    			//si existe en la data de bd antigua
    			Map<String, Object> mapDiferencias = comp.comparaMap(descripcion, descrMin, keys);
    			if(!CollectionUtils.isEmpty(mapDiferencias)){
    				 if (Comparador.esDataCambiada(mapDiferencias))
    			        {
    					 	//descrMin.put("FEC_MODIF", fecActual.getTimestamp());//esto lo hace el trigger, esta de mas PAS137 DESCMIN
    					 	formBItemDescriDAO.updateSelective(descrMin);
							
							Map<String,Object> dataAdicional = new HashMap<String, Object>();  
							Map<String,Object> dataModificados = new HashMap<String, Object>();   
							
							Map<String, Object> dataOriginal = (Map) mapDiferencias.get("dataOriginal");
							for (Entry<String, Object> campo : dataOriginal.entrySet())
							{
							    String nombreCampo = campo.getKey();
							    if (nombreCampo.startsWith("DES_DESCRIPCION"))
							    {
							     	dataModificados.put("DES_DESCRIPCION",descrMin.get("DES_DESCRIPCION"));
							    }else if (nombreCampo.startsWith("NUM_SECFACT"))
							    {
							      	dataModificados.put("NUM_SECFACT",descrMin.get("NUM_SECFACT"));
							    }else if (nombreCampo.startsWith("NUM_SECPROVE"))
							    {
							       	dataModificados.put("NUM_SECPROVE",descrMin.get("NUM_SECPROVE"));
							    }else if (nombreCampo.startsWith("COD_TIPVALOR"))
							    {
							      	dataModificados.put("COD_TIPVALOR",descrMin.get("COD_TIPVALOR"));
							    }else if (nombreCampo.startsWith("IND_DEL"))
							    {
							      	dataModificados.put("IND_DEL",descrMin.get("IND_DEL"));
							    }   
							}
							dataAdicional.put("dataModificados",dataModificados);
							mapDiferencias.putAll(dataAdicional); 

    					 	this.registrarRectiOficio(mapDiferencias, params.get("tipDilig").toString().trim(), new Long(descrMin.get("NUM_CORREDOC")
    	                            .toString().trim()),Constantes.COD_TABLA_FORMB_ITEM_DESCRI, numCorreDocSol);
    			        }
    			}
    			
    		}
    		else{// si no existe en la bd antigua
    			if(descrMin.get("IND_DEL").equals("0")){
    				formBItemDescriDAO.insertSelective(descrMin);
    				Map<String,Object> dataAdicional = new HashMap<String, Object>();  
    				Map<String,Object> dataModificados = new HashMap<String, Object>();  
    				Map<String,Object> dataOriginal = new HashMap<String, Object>(); 
    				dataModificados.put("DES_DESCRIPCION",descrMin.get("DES_DESCRIPCION"));
    				dataModificados.put("IND_DEL",descrMin.get("IND_DEL"));
    				dataModificados.put("NUM_SECFACT",descrMin.get("NUM_SECFACT"));
    				dataModificados.put("NUM_SECPROVE",descrMin.get("NUM_SECPROVE"));
    				dataModificados.put("COD_TIPVALOR",descrMin.get("COD_TIPVALOR"));
    				dataAdicional.put("clave", keys);
    				dataAdicional.put("dataModificados",dataModificados );
    				dataAdicional.put("dataOriginal",dataOriginal );
    				descrMin.putAll(dataAdicional); 
    				this.registrarRectiOficio(descrMin, params.get("tipDilig").toString().trim(), new Long(descrMin.get("NUM_CORREDOC")
                            .toString().trim()),Constantes.COD_TABLA_FORMB_ITEM_DESCRI, numCorreDocSol);
    			}
    		}
    		/****Fin cambios del PAS20165E220200055**/     			
        }
    }
    
  }

  /**
   * {@inheritDoc}
   *
   * @deprecated ahora se usa la del orquestador
   */
  public void realizarDatado(Map params) throws ServiceException
  {
    try
    {
      Map declaracion = (HashMap) params.get("mapCabDeclaraActual");

      Map prmDatado = new HashMap();
      Boolean esAnticipado = "10".equals(declaracion.get("COD_MODALIDAD").toString().trim());
      Boolean esUrgenteAnticipado = false;
      Boolean esUrgenteExcepcional = false;
      Boolean esExcepcional = "00".equals(declaracion.get("COD_MODALIDAD").toString().trim());
      Boolean esDiligenciaDeRegularizacion = false;
      Boolean esDiligenciaDeRectificacion = false;

      String codTipDiligencia = ((Map) params.get("mapCabDiligenciaActual")).get("COD_TIPDILIGENCIA").toString();
      esDiligenciaDeRegularizacion = Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(codTipDiligencia);
      esDiligenciaDeRectificacion = Constantes.TIPO_DILIG_ESTA_RECTIFICACION.equals(codTipDiligencia);
      Boolean tienePrece = declaracion.get("IND_DOCUPRECEDUA") != null ? (Boolean) declaracion.get("IND_DOCUPRECEDUA")
                                                                      : false;
      if (tienePrece && !esDiligenciaDeRegularizacion)
      {
        return;
      }

      // Debe datar para via transporte terrestre y aereo
      if (esExcepcional && declaracion.get("COD_VIATRANS").toString().trim().equals("0"))
      {
        return;
      }

      //
      // NSR: Verificamos si existe el Manifiesto Antes de Hacer cualquier cosa
      // *********************************************************************//
      Map<String, Object> dataManif = new HashMap<String, Object>();

      dataManif.put("numeroManifiesto",
                    SunatStringUtils.lpad(declaracion.get("NUM_MANIFIESTO").toString().trim(), 6, ' '));
      dataManif.put("anioManifiesto", declaracion.get("ANN_MANIFIESTO").toString().trim());
      dataManif.put("codigoAduana", declaracion.get("COD_ADUAMANIFIESTO").toString().trim());
      dataManif.put("codigoTipoManifiesto", declaracion.get("COD_TIPMANIFIESTO").toString().trim());
      dataManif.put("codigoViaTransporte", declaracion.get("COD_VIATRANS").toString().trim());

      String codaduamanif = declaracion.get("COD_ADUAMANIFIESTO").toString().trim();
      String annmanif = declaracion.get("ANN_MANIFIESTO").toString().trim();
      String nummanif = SunatStringUtils.lpad(declaracion.get("NUM_MANIFIESTO").toString().trim(), 6, ' ');
      String codmodtransp = declaracion.get("COD_VIATRANS").toString().trim();

      CabManifiestoDAO cabManifiestoDAO = fabricaDeServicios.getService("manifiesto.manifiestoDAO");
      List<Manifiesto> listManifiesto = cabManifiestoDAO.listByParameterMap(dataManif);
      if (listManifiesto == null || listManifiesto.isEmpty())
      {

        if (esExcepcional
            && declaracion.get("COD_REGIMEN").toString().trim().equals("10")
            && SunatNumberUtils.isLessThanParam(Integer.parseInt((String) dataManif.get("anioManifiesto")), 2011))
        {

          ManifiestoSigadService manifiestoSigadService =
                                                          fabricaDeServicios
                                                                            .getService("manifiesto.manifiestoSigadService");
          Manifiesto manifiesto =
                                  manifiestoSigadService.getManifiestoByClaveDeNegocio(
                                                                                       codmodtransp,
                                                                                       codaduamanif,
                                                                                       Integer.parseInt(SunatStringUtils.length(annmanif) > 3
                                                                                                                                             ? annmanif.substring(0,
                                                                                                                                                                  4)
                                                                                                                                             : null),
                                                                                       SunatStringUtils.lpad(nummanif,
                                                                                                             5, ' '));
          if (manifiesto == null)
          {
            throw new Exception("11515: No existe manifiesto de carga: " + dataManif.get("codigoTipoManifiesto") + "-" +
                                dataManif.get("codigoViaTransporte") + "-" + dataManif.get("codigoAduana") + "-" +
                                dataManif.get("anioManifiesto") + "-" + dataManif.get("numeroManifiesto"));

          }
        }
        else
        {
          throw new Exception("11515: No existe manifiesto de carga: " + dataManif.get("codigoTipoManifiesto") + "-" +
                              dataManif.get("codigoViaTransporte") + "-" + dataManif.get("codigoAduana") + "-" +
                              dataManif.get("anioManifiesto") + "-" + dataManif.get("numeroManifiesto"));
        }
      }

      // NSR: Determinamos el tipo de despacho
      if ("10".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {
        esAnticipado = true;
      }
      else if ("01".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {

        Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
        Date fecLlegada = listManifiesto.get(0).getFechaEfectivaDeLlegada();
        if (fecLlegada == null
            || SunatDateUtils
                             .sonIguales(fecLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          fecLlegada = listManifiesto.get(0).getFechaProgramadaLlegada();
        }
        // Usamos la fecha de Llegada y la fecha de la Declaraci�n para
        // determinar si es Urg.Anticipada o Urg.Excepcional
        if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaDeclaracion, fecLlegada, SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          // Si es urgente Anticipado, Se declaro Antes o el Mismo dia de la
          // Llegada
          esUrgenteAnticipado = true;
        }
        else
        {
          esUrgenteExcepcional = true;
        }
      }
      else if ("00".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {
        esExcepcional = true;
      }

      if (esDiligenciaDeRectificacion && (esExcepcional || esUrgenteExcepcional))
      {
        Date fechaTermino = null;
        try
        {
          fechaTermino = (Date) declaracion.get("FEC_TERM");
        }
        catch (Exception e)
        {
          fechaTermino = SunatDateUtils
                                       .getDate(declaracion.get("FEC_TERM").toString(), "yyyy-MM-dd hh:mm:ss");
        }
        Date fechaTermDesc = listManifiesto.get(0).getFechaTerminoDeDescarga();
        if (!SunatDateUtils.sonIguales(fechaTermino, fechaTermDesc, SunatDateUtils.COMPARA_SOLO_FECHA))
          throw new Exception(
                              "30262: Fecha de descarga manifiesto declarado en DUA no coincide con la informaci�n registrada en manifiestos");
      }
      // Validacion para que no daten las Urgentes en diligencia que no sea de
      // regularizacion (despacho u otros)
      /*
       * olunar - 009 - Si es diligencia rectificacion y es excepcional urgente
       * tambien debe datar
       */
      if ((esUrgenteAnticipado || esUrgenteExcepcional) && !esDiligenciaDeRegularizacion
          && (esUrgenteAnticipado && esDiligenciaDeRectificacion))
      {
        return;
      }

      if (esExcepcional && declaracion.get("COD_VIATRANS").toString().trim().equals("0"))
      {
        return;
      }

      // NSR: Verificamos si es diligencia de regularizaci�n o es otro tipo de
      // diligencia para proceder seg�n sea el caso
      if (esDiligenciaDeRegularizacion)
      {
        prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_URGENTE_EXCEPCIONAL);
      }
      else
      { // Es otra diligencia
        if (esAnticipado || esUrgenteAnticipado)
        {
          prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
        }
        else if (esUrgenteExcepcional || esExcepcional)
        {
          prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
        }
      }

      prmDatado.put("regimenDua", declaracion.get("COD_REGIMEN").toString().trim());
      prmDatado.put("numeroDua", declaracion.get("NUM_DECLARACION").toString().trim());
      prmDatado.put("annoDua", new Integer(declaracion.get("ANN_PRESEN").toString()));
      prmDatado.put("aduanaDua", declaracion.get("COD_ADUANA").toString().trim());
      prmDatado.put("codigoViaTransporte", declaracion.get("COD_VIATRANS").toString().trim());
      prmDatado.put("numeroManifiesto", declaracion.get("NUM_MANIFIESTO").toString());
      prmDatado.put("anioManifiesto", new Integer(declaracion.get("ANN_MANIFIESTO").toString().trim()));
      prmDatado.put("codigoTipoManifiesto", declaracion.get("COD_TIPMANIFIESTO").toString().trim());
      prmDatado.put("codigoAduana", declaracion.get("COD_ADUAMANIFIESTO").toString().trim());
      prmDatado.put("codigoEmpresaTransportista",
                    declaracion.get("NUM_DOCIDENT_PTR") != null ?
                                                               declaracion.get("NUM_DOCIDENT_PTR").toString().trim()
                                                               : null);

      prmDatado.put("detalleNumeroCorrelativo", new Long(declaracion.get("NUM_CORREDOC").toString().trim()));

      List<Map<String, Object>> lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
      List<Map<String, Object>> lstBL = new ArrayList();
      Map mapBLPk = new HashMap<String, Object>();

      BigDecimal dblTotBultos;
      BigDecimal dblTotPesoBr;

      for (Map<String, Object> serie : lstDetDeclara)
      {
        if (!("1".equals(serie.get("IND_DEL"))))
        {
          prmDatado.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP").toString().trim());
          mapBLPk.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP").toString().trim());
          mapBLPk.put("numeroDeDetalle",
                      ("0".equals(serie.get("NUM_DETALLE").toString().trim()) ||
                      "".equals(serie.get("NUM_DETALLE").toString().trim())) ? new Integer("-1") :
                                                                            new Integer(serie.get("NUM_DETALLE")
                                                                                             .toString().trim()));

          Map mapBL = Utilidades.obtenerElemento(lstBL, mapBLPk);
          if (mapBL == null || mapBL.isEmpty())
          {
            mapBL = new HashMap<String, Object>();
            mapBL.putAll(mapBLPk);
            mapBL.put("puertoEmbarque", serie.get("COD_PUER_EMBAR").toString().trim());
            mapBL.put("totalBulto", SunatNumberUtils.toBigDecimal(serie.get("CNT_BULTO")));
            mapBL.put("totalPesoBruto", SunatNumberUtils.toBigDecimal(serie.get("CNT_PESO_BRUTO")));

            lstBL.add(mapBL);
          }
          else
          {
            dblTotBultos = ((BigDecimal) mapBL.get("totalBulto"));
            dblTotPesoBr = ((BigDecimal) mapBL.get("totalPesoBruto"));

            dblTotBultos = SunatNumberUtils.sum(dblTotBultos, SunatNumberUtils.toBigDecimal(serie.get("CNT_BULTO")));
            dblTotPesoBr = SunatNumberUtils.sum(
                                                dblTotPesoBr,
                                                SunatNumberUtils.toBigDecimal(serie.get("CNT_PESO_BRUTO")));

            mapBL.put("totalBulto", dblTotBultos);
            mapBL.put("totalPesoBruto", dblTotPesoBr);
          }
        }
      }

      Map resDatado;

      // Desdatado por DUA, bug 5642
      if (esDiligenciaDeRegularizacion)
      {
        resDatado = this.datadoService.registrarDesDatadoDua(
                                                             prmDatado,
                                                             ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
        if (resDatado != null && resDatado.size() > 0)
        {
          throw new Exception(resDatado.get("codError").toString().trim() + ": "
                              + resDatado.get("desError").toString().trim());
        }
      }

      boolean deboDesdatadoDua = true;

      for (Map mapBL : lstBL)
      {
        // Verificamos Si tiene numero de Detalle
        Integer numeroDeDetalle = (Integer) mapBL.get("numeroDeDetalle");
        if (SunatNumberUtils.isLessOrEqualsThanZero(numeroDeDetalle))
        {
          mapBL.remove("numeroDeDetalle");
        }
        // Validamos el datado
        prmDatado.putAll(mapBL);
        resDatado = this.datadoService.validarDatado(prmDatado);

        if (resDatado != null && resDatado.size() > 0)
        {
          throw new Exception(resDatado.get("codError").toString().trim() + ": "
                              + resDatado.get("desError").toString().trim());
        }
        else
        {
          prmDatado.put(
                        "fechaNumeracionDua",
                        (new FechaBean((Timestamp) declaracion.get("FEC_DECLARACION"))).getSQLDate());
          // NSR: Si no es Regularizaci�n debemos desdatar manualmente
          if (!esDiligenciaDeRegularizacion)
          {
            if (deboDesdatadoDua == true)
            {
              if (esAnticipado || esUrgenteAnticipado)
              {
                prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
              }
              else if (esExcepcional || esUrgenteExcepcional)
              {
                prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
              }

              String tipoDespacho = (String) prmDatado.get("tipoDespacho");
              Map<String, Object> dataDua = new HashMap<String, Object>();

              dataDua.put("regimenDua", prmDatado.get("regimenDua"));
              dataDua.put("numeroDua", prmDatado.get("numeroDua"));
              dataDua.put("annoDua", prmDatado.get("annoDua"));
              dataDua.put("aduanaDua", prmDatado.get("aduanaDua"));

              Map resMap = datadoService.registrarDesDatadoDua(dataDua, tipoDespacho);
              if (resMap.isEmpty())
              {
                if (esAnticipado || esUrgenteAnticipado)
                {
                  prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
                }
                else if (esExcepcional || esUrgenteExcepcional)
                {
                  prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
                }
              }
              else
              {
                throw new Exception(resMap.get("codError").toString().trim() + ": "
                                    + resMap.get("desError").toString().trim());
              }

              deboDesdatadoDua = false;
            }
          }
          // NSR: Registramos el Datado
          resDatado = this.datadoService.registrarDatado(prmDatado);

          if (resDatado != null && resDatado.size() > 0)
          {
            throw new Exception(resDatado.get("codError").toString().trim() + ": "
                                + resDatado.get("desError").toString().trim());
          }
        }
      }
    }
    catch (Exception e)
    {
      log.error("DiligenciaServiceImpl : realizarDatado - ERROR: ", e);
      throw new ServiceException(this, e.getMessage());
    }
  }

  /**
   * Validar datado.
   *
   * @deprecated se usa el servicio del SEIDA
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   * @author nsullca
   */
  public Map<String, Object> validarDatado(Map params) throws ServiceException
  {
    try
    {
      Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
      Map rptaDatado = new HashMap<String, Object>();

      Map prmDatado = new HashMap();
      Boolean esAnticipado = "10".equals(declaracion.get("COD_MODALIDAD").toString().trim());
      Boolean esUrgenteAnticipado = false;
      Boolean esUrgenteExcepcional = false;
      Boolean esExcepcional = "00".equals(declaracion.get("COD_MODALIDAD").toString().trim());
      Boolean esDiligenciaDeRegularizacion = false;
      Boolean tieneDatado = "S".equals(params.get("tieneDatado"));

      String codTipDiligencia = ((Map) params.get("mapCabDiligenciaActual")).get("COD_TIPDILIGENCIA").toString();
      esDiligenciaDeRegularizacion = Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(codTipDiligencia);

      // Verificamos si tiene regimen precedente
      Boolean tienePrece = declaracion.get("IND_DOCUPRECEDUA") != null ? (Boolean) declaracion.get("IND_DOCUPRECEDUA")
                                                                      : false;
      if (tienePrece && !esDiligenciaDeRegularizacion)
      {
        return rptaDatado;
      }
      // Esta validacion se modifica para que no date las que no son
      // urgentes (anticipadas y excepcionales)
      // y las que no son de via maritima y las que no son diligencias de
      // regularizacion
      if ((esExcepcional && declaracion.get("COD_VIATRANS").toString().trim().equals("0"))
          || (esExcepcional && declaracion.get("COD_VIATRANS").toString().trim().equals("4"))
          || (declaracion.get("COD_VIATRANS").toString().trim().equals("7")))
      {
        return rptaDatado;
      }

      Map<String, Object> dataManif = new HashMap<String, Object>();

      dataManif.put("numeroManifiesto",
                    SunatStringUtils.lpad(declaracion.get("NUM_MANIFIESTO").toString().trim(), 6, ' '));
      dataManif.put("anioManifiesto", declaracion.get("ANN_MANIFIESTO").toString().trim());
      dataManif.put("codigoAduana", declaracion.get("COD_ADUAMANIFIESTO").toString().trim());
      dataManif.put("codigoTipoManifiesto", declaracion.get("COD_TIPMANIFIESTO").toString().trim());
      dataManif.put("codigoViaTransporte", declaracion.get("COD_VIATRANS").toString().trim());

      String codaduamanif = declaracion.get("COD_ADUAMANIFIESTO").toString().trim();
      String annmanif = declaracion.get("ANN_MANIFIESTO").toString().trim();
      String nummanif = SunatStringUtils.lpad(declaracion.get("NUM_MANIFIESTO").toString().trim(), 6, ' ');
      String codmodtransp = declaracion.get("COD_VIATRANS").toString().trim();

      CabManifiestoDAO cabManifiestoDAO = fabricaDeServicios.getService("manifiesto.manifiestoDAO");
      List<Manifiesto> listManifiesto = cabManifiestoDAO.listByParameterMap(dataManif);
      if (listManifiesto == null || listManifiesto.isEmpty())
      {

        if (esExcepcional
            && declaracion.get("COD_REGIMEN").toString().trim().equals("10")
            && SunatNumberUtils.isLessThanParam(Integer.parseInt((String) dataManif.get("anioManifiesto")), 2011))
        {

          ManifiestoSigadService manifiestoSigadService =
                                                          fabricaDeServicios
                                                                            .getService("manifiesto.manifiestoSigadService");
          Manifiesto manifiesto =
                                  manifiestoSigadService.getManifiestoByClaveDeNegocio(
                                                                                       codmodtransp,
                                                                                       codaduamanif,
                                                                                       Integer.parseInt(SunatStringUtils.length(annmanif) > 3
                                                                                                                                             ? annmanif.substring(0,
                                                                                                                                                                  4)
                                                                                                                                             : null),
                                                                                       SunatStringUtils.lpad(nummanif,
                                                                                                             5, ' '));
          if (manifiesto == null)
          {
            throw new Exception("11515: No existe manifiesto de carga: " + dataManif.get("codigoTipoManifiesto") + "-" +
                                dataManif.get("codigoViaTransporte") + "-" + dataManif.get("codigoAduana") + "-" +
                                dataManif.get("anioManifiesto") + "-" + dataManif.get("numeroManifiesto"));
          }
          else
          {
            return rptaDatado;
          }
        }
        else
        {
          throw new Exception("11515: No existe manifiesto de carga: " + dataManif.get("codigoTipoManifiesto") + "-" +
                              dataManif.get("codigoViaTransporte") + "-" + dataManif.get("codigoAduana") + "-" +
                              dataManif.get("anioManifiesto") + "-" + dataManif.get("numeroManifiesto"));
        }
      }
      if ("10".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {
        esAnticipado = true;
      }
      else if ("01".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {

        Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
        Date fecLlegada = listManifiesto.get(0).getFechaEfectivaDeLlegada();
        if (fecLlegada == null
            || SunatDateUtils
                             .sonIguales(fecLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          fecLlegada = listManifiesto.get(0).getFechaProgramadaLlegada();
        }
        if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaDeclaracion, fecLlegada, SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          // Si es urgente Anticipado, Se declaro Antes o el Mismo dia de la
          // Llegada
          esUrgenteAnticipado = true;
        }
        else
        {
          esUrgenteExcepcional = true;
        }
      }
      else if ("00".equals(declaracion.get("COD_MODALIDAD").toString().trim()))
      {
        esExcepcional = true;
      }

      // Validacion para que no daten las Urgentes en diligencia que no sea de
      // regularizacion (despacho u otros)
      if ((esUrgenteAnticipado || esUrgenteExcepcional) && !esDiligenciaDeRegularizacion)
      {
        if (!tieneDatado)
        {
          return rptaDatado;
        }
      }

      // Verificamos que sea maritimo en el caso de Excepcional
      if (!esDiligenciaDeRegularizacion && esExcepcional
          && !declaracion.get("COD_VIATRANS").toString().trim().equals("1"))
      {
        return rptaDatado;
      }

      // Verificamos si es diligencia de regularizaci�n o es otro tipo de
      // diligencia para proceder seg�n sea el caso
      if (esDiligenciaDeRegularizacion)
      {// Es diligencia de Regularizaci�n
       // NSR: 05/04/2011 por ahora vamos a utilizar este codigo para todas las
       // regularizaciones, debido a que esta desdata primero
       // y de no encontrar datado previo no hace nada
        prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_URGENTE_EXCEPCIONAL);
      }
      else
      {
        if (esAnticipado || esUrgenteAnticipado)
        {
          prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
        }
        else if (esExcepcional || esUrgenteExcepcional)
        {
          prmDatado.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
        }
      }

      prmDatado.put("regimenDua", declaracion.get("COD_REGIMEN").toString().trim());
      prmDatado.put("numeroDua", declaracion.get("NUM_DECLARACION").toString().trim());
      prmDatado.put("annoDua", new Integer(declaracion.get("ANN_PRESEN").toString()));
      prmDatado.put("aduanaDua", declaracion.get("COD_ADUANA").toString().trim());
      prmDatado.put("codigoViaTransporte", declaracion.get("COD_VIATRANS").toString().trim());
      prmDatado.put("numeroManifiesto", declaracion.get("NUM_MANIFIESTO").toString());
      prmDatado.put("anioManifiesto", new Integer(declaracion.get("ANN_MANIFIESTO").toString().trim()));
      prmDatado.put("codigoTipoManifiesto", declaracion.get("COD_TIPMANIFIESTO").toString().trim());
      prmDatado.put("codigoAduana", declaracion.get("COD_ADUAMANIFIESTO").toString().trim());
      prmDatado.put("codigoEmpresaTransportista",
                    declaracion.get("NUM_DOCIDENT_PTR") != null ?
                                                               declaracion.get("NUM_DOCIDENT_PTR").toString().trim()
                                                               : null);

      // Parametro para el datado
      prmDatado.put("detalleNumeroCorrelativo", new Long(declaracion.get("NUM_CORREDOC").toString().trim()));

      List<Map<String, Object>> lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
      List<Map<String, Object>> lstBL = new ArrayList();
      Map mapBLPk = new HashMap<String, Object>();

      BigDecimal dblTotBultos;
      BigDecimal dblTotPesoBr;

      // amancillaa solo se valida los BL no eliminados en el mantenimiento de
      // Series PASE578
      for (Map<String, Object> serie : lstDetDeclara)
      {
        if (!("1".equals(serie.get("IND_DEL"))))
        {

          prmDatado.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP").toString().trim());
          mapBLPk.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP").toString().trim());
          mapBLPk.put("numeroDeDetalle",
                      ("0".equals(serie.get("NUM_DETALLE").toString().trim()) ||
                      "".equals(serie.get("NUM_DETALLE").toString().trim())) ? new Integer("-1") :
                                                                            new Integer(serie.get("NUM_DETALLE")
                                                                                             .toString().trim()));

          Map mapBL = Utilidades.obtenerElemento(lstBL, mapBLPk);
          if (mapBL == null || mapBL.isEmpty())
          {
            mapBL = new HashMap<String, Object>();
            mapBL.putAll(mapBLPk);
            mapBL.put("puertoEmbarque", serie.get("COD_PUER_EMBAR").toString().trim());
            mapBL.put("totalBulto", new BigDecimal(serie.get("CNT_BULTO").toString().trim()));
            mapBL.put("totalPesoBruto", new BigDecimal(serie.get("CNT_PESO_BRUTO").toString().trim()));

            lstBL.add(mapBL);
          }
          else
          {
            dblTotBultos = ((BigDecimal) mapBL.get("totalBulto"));
            dblTotPesoBr = ((BigDecimal) mapBL.get("totalPesoBruto"));

            dblTotBultos = SunatNumberUtils.sum(dblTotBultos, SunatNumberUtils.toBigDecimal(serie.get("CNT_BULTO")));
            dblTotPesoBr = SunatNumberUtils.sum(
                                                dblTotPesoBr,
                                                SunatNumberUtils.toBigDecimal(serie.get("CNT_PESO_BRUTO")));

            mapBL.put("totalBulto", dblTotBultos);
            mapBL.put("totalPesoBruto", dblTotPesoBr);
          }
        }
      }

      Map resDatado;

      // Validamos el datado por BL
      for (Map mapBL : lstBL)
      {
        // Verificamos Si tiene numero de Detalle
        Integer numeroDeDetalle = (Integer) mapBL.get("numeroDeDetalle");
        if (SunatNumberUtils.isLessOrEqualsThanZero(numeroDeDetalle))
        {
          mapBL.remove("numeroDeDetalle");
        }
        // Validamos el datado
        prmDatado.putAll(mapBL);

        resDatado = this.datadoService.validarDatado(prmDatado);

        if (resDatado != null && resDatado.size() > 0)
        {
          throw new Exception(resDatado.get("codError").toString().trim() + ": "
                              + resDatado.get("desError").toString().trim());
        }
      }
      // Paso todas las validaciones
      rptaDatado.put("Datado.listaParaDatado", lstBL);
      return rptaDatado;
    }
    catch (Exception e)
    {
      log.error("DiligenciaServiceImpl : realizarDatado - ERROR: ", e);
      throw new ServiceException(this, e.getMessage());
    }
  }

  /**
   * {@inheritDoc}
   */
  public void grabarComunicacion(Map<String, Object> params) throws ServiceException
  {
    params.put("num_nota", comunicacionDAO.obtenerSiguienteCorrelativo());
    comunicacionDAO.insertComunicacion(params);
  }

  /**
   * Permite Grabar la Revisi�n del Estados  del reconocimiento f�sico de mercanc�as
   *
   * @param params
   *          the params
   * @return the map
   * @throws ServiceException
   *           the service exception
   */
//P13 JMCV - INICIO	***************************************************************************
public void grabarRevision(Map<String, Object> params) throws ServiceException
	  {

          //amancilla FSW
          String esUltimaDescargaParcial = params.get("esUltimaDescargaParcial")!=null?params.get("esUltimaDescargaParcial").toString():"N";

	    Map<String, Object> diligencia = new HashMap();
//	    P13 JMCV - INICIO		
	    String cod_EstRev = String.valueOf(params.get("cod_estrev"));
	    String cod_Catalogo = "";
//	    P13 JMCV - FIN	    
	    diligencia.put("COD_TIPDILIGENCIA", ConstantesDataCatalogo.COD_DILIG_REV);
	    diligencia.put("NUM_CORREDOC", params.get("num_corredoc"));
	    diligencia.put("COD_MOTIVO", cod_EstRev );

	    diligencia.put("COD_FUNCIONARIO", params.get("cod_funcionario"));
//	    P13 JMCV - INICIO ***********************************************************************************************************
	    if (ConstantesDataCatalogo.COD_CANAL_ROJO.equals(params.get("cod_canal")))
	    {
	      log.info("Cuando es F�sico");
	      cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO;
/*RIN13FSW*/
	      if (ArrayUtils.contains(new String []{ ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
	    		  ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
	      		  ConstantesDataCatalogo.COD_EST_REVISION_INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
	      		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_CON_CONTINUACION,
	      		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL
	      							}, cod_EstRev)){

              if("S".equals(esUltimaDescargaParcial)){
                  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
              }else{
	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ELIMINADO_POR_REASIGNACION);  //RETIRO DE BANDEJA
              }

	      }else{
	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
	      }
	      
	      params.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
	      /* PAS20145E220000399 INICIO GGRANADOS */
//	      Integer result = 0;	      
	      espeDocuDAO.updateEstadoRevision(params);
	      /* PAS20145E220000399 FIN GGRANADOS */
	      params.put("cod_estrev",cod_EstRev );
//		  P13 JMCV - FIN *************************************************************************************************************	      
	      
//	      if (result == 0)
//	      {
//	        Map<String, Object> mapaEspeDocu = new HashMap();
//	        Map<String, Object> mapaEspeDocuResult = new HashMap();
//	        mapaEspeDocu.put("NUM_CORREDOC", params.get("num_corredoc"));
//	        mapaEspeDocu.put("COD_ESTREV", "02");
//	        mapaEspeDocuResult = espeDocuDAO.findbyDocEstRev(mapaEspeDocu);
	//
//	        params.put("cod_estrev_ant", "02");
	//
//	        if (mapaEspeDocuResult == null || mapaEspeDocuResult.size() == 0)
//	        {
//	          mapaEspeDocu.put("NUM_CORREDOC", params.get("num_corredoc"));
//	          mapaEspeDocu.put("COD_ESTREV", "03");
//	          mapaEspeDocuResult = espeDocuDAO.findbyDocEstRev(mapaEspeDocu);
//	          params.put("cod_estrev_ant", "03");
//	        }
//	        espeDocuDAO.updateEstadoRevision(params);

//	      }

	      diligencia.put("COD_CATALOGO", cod_Catalogo);
	      cabDiligenciaDAO.update(diligencia);
//		    P13 JMCV - INICIO	      
            //amancilla FSW
            if("N".equals(esUltimaDescargaParcial)){
	      asignacionManualService.grabarBandejaDocu(Long.valueOf(String.valueOf(params.get("num_corredoc"))),cod_EstRev);
            }

//		    P13 JMCV - FIN
	    }
	    else
	    {
//		    P13 JMCV - INICIO ***********************************************************************************************************	    
	    	if((params.get("cod_canal").toString().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) )){///&&  params.get("cod_indicador_dua").toString().equals(ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO))){
	    		cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO;
	    		if (ArrayUtils.contains(new String []{
	    	    		  ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
	    	    		  ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
	    	    		  ConstantesDataCatalogo.COD_EST_REVISION_INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
	    	    		  }, cod_EstRev)){

	                if("S".equals(esUltimaDescargaParcial)){
	                    params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
	                }else{
	    	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ELIMINADO_POR_REASIGNACION);  //RETIRO DE BANDEJA
	                }

	    	      }else{
	    	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
	    	      }    		
	    		params.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
	    		/* PAS20145E220000399 INICIO GGRANADOS */
//		        Integer result = 0;
		        espeDocuDAO.updateEstadoRevision(params);
		        /* PAS20145E220000399 FIN GGRANADOS */
		        params.put("cod_estrev",cod_EstRev );
	    	}
	    	else{
	    		cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_MOTIVO_FISCALIZAR_DECLARACIONES_NARANJAS;
	    	}
//		    P13 JMCV - FIN **************************************************************************************************************	    
	      diligencia.put("COD_CATALOGO", cod_Catalogo); 	
	      cabDiligenciaDAO.update(diligencia);
//		    P13 JMCV - INICIO	      
	      if (cod_Catalogo.equals(ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO)){
	    	  asignacionManualService.grabarBandejaDocu(Long.valueOf(String.valueOf(params.get("num_corredoc"))),cod_EstRev);  
	      }
//		    P13 JMCV - FIN	      
	      diligencia.put("COD_USUREGIS", params.get("cod_usumodif"));
	      diligencia.put("FEC_REGIS", params.get("fec_modif"));
	 

	      if((params.get("cod_canal").toString().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)
				  && params.get("cod_indicador_dua")!=null &&  params.get("cod_indicador_dua").toString().equals(ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO))){

	   		 diligencia.put("IND_RESPUESTA", 1);	
	   		 //AMANCILLA INC 2017-036204 Map<String, Object> consulta = consultaDAO.findByNumCorredocDiligencia(diligencia);

			  List<Map<String, Object>> consulta = consultaDAO.findByNumCorredocDiligencia2(diligencia);
	   		 
	   		  //INC 2017-036204 if (CollectionUtils.isEmpty(consulta) || consulta.get("NUM_CORREDOC") == null && "S".equals(esUltimaDescargaParcial))
			  if (CollectionUtils.isEmpty(consulta) && "S".equals(esUltimaDescargaParcial))
	   	      {
                  //amancilla   SAU20153D211000637
                  ConsultaService consultaService = fabricaDeServicios.getService("diligencia.ingreso.consultaService");
                  Consulta consultaBean = new Consulta();

                  consultaBean.setNumcorredoc(Utilidades.toLong(params.get("num_corredoc").toString()));
                  //TODO: amancilla insertan 01 pq la revision de la continuacion de despacho se inserta con 01 ojo alli
                  consultaBean.setTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
                  consultaBean.setNumcorredocSol(new Long(0)); //cero pq no es rectificacion
                  consultaBean.setIndicadorRespuesta(Constantes.SOLICITUD_DILIGENCIA_PROCEDENTE);
                  CatEmpleado funcionario = new CatEmpleado();
                  funcionario.setCodPers(params.get("cod_funcionario").toString());
                  consultaBean.setFuncionario(funcionario);
                  consultaService.grabarConsulta(consultaBean);

	   	        //amancilla consultaDAO.insert(diligencia);
	   	      }
	   	      /* amancilla  INC 2017-036204 else
	   	      {
	   	    	diligencia.put("IND_RESPUESTA",null );
	   	        consultaDAO.update(diligencia);

	   	      }*/

	   		}else if (ConstantesDataCatalogo.COD_CANAL_ROJO.equals(params.get("cod_canal"))){
	   		 Map<String, Object> consulta = consultaDAO.findByNumCorredocDiligencia(diligencia);
	   		 
	   		  if (CollectionUtils.isEmpty(consulta) || consulta.get("NUM_CORREDOC") == null && "S".equals(esUltimaDescargaParcial))
	   	      {
                  //amancilla   SAU20153D211000637
                  ConsultaService consultaService = fabricaDeServicios.getService("diligencia.ingreso.consultaService");
                  Consulta consultaBean = new Consulta();

                  consultaBean.setNumcorredoc(Utilidades.toLong(params.get("num_corredoc").toString()));
                  //TODO: amancilla insertan 01 pq la revision de la continuacion de despacho se inserta con 01 ojo alli
                  consultaBean.setTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
                  consultaBean.setNumcorredocSol(new Long(0)); //cero pq no es rectificacion
                  consultaBean.setIndicadorRespuesta(Constantes.SOLICITUD_DILIGENCIA_PROCEDENTE);
                  CatEmpleado funcionario = new CatEmpleado();
                  funcionario.setCodPers(params.get("cod_funcionario").toString());
                  consultaBean.setFuncionario(funcionario);
                  consultaService.grabarConsulta(consultaBean);

	   	        //amancilla  consultaDAO.insert(diligencia);
	   	      }
	   	      /*amancilla  INC 2017-036204 else
	   	      {
	   	        consultaDAO.update(diligencia);
	   	      }*/
	   		} 
	    }
	  }
//P13 JMCV - FIN
/*RIN13FSW-INICIO*/
/***
 * juazor RIN13
 * @param params
 * @throws ServiceException
 */
public void grabarEnProceso(Map<String, Object> params) throws ServiceException
{
  Map<String, Object> diligencia = new HashMap();
//  P13 JMCV - INICIO		
  String cod_EstRev = String.valueOf(params.get("cod_estrev"));
  String cod_Catalogo = "";
//  P13 JMCV - FIN	    
  diligencia.put("COD_TIPDILIGENCIA", ConstantesDataCatalogo.COD_DILIG_REV);
  diligencia.put("NUM_CORREDOC", params.get("num_corredoc"));
  diligencia.put("COD_MOTIVO", cod_EstRev );

  diligencia.put("COD_FUNCIONARIO", params.get("cod_funcionario"));
//  P13 JMCV - INICIO ***********************************************************************************************************
  if (ConstantesDataCatalogo.COD_CANAL_ROJO.equals(params.get("cod_canal")))
  {
    log.info("Cuando es F�sico");
    cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO;
    if (ArrayUtils.contains(new String []{ ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
  		  ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
    		  ConstantesDataCatalogo.COD_EST_REVISION_INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
    		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_CON_CONTINUACION,
    		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL
    							}, cod_EstRev)){
  	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ELIMINADO_POR_REASIGNACION);  //RETIRO DE BANDEJA
    }else{
  	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
    }
    
    params.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
    /* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//    Integer result = 0;    
    espeDocuDAO.updateEstadoRevision(params);
    /* PAS20145E220000399 FIN GGRANADOS */
    params.put("cod_estrev",cod_EstRev );
    
    asignacionManualService.grabarBandejaDocu(Long.valueOf(String.valueOf(params.get("num_corredoc"))),cod_EstRev);
//	    P13 JMCV - FIN
  }
  else
  {
//	    P13 JMCV - INICIO ***********************************************************************************************************	    
  	if((params.get("cod_canal").toString().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) &&  params.get("cod_indicador_dua").toString().equals(ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO))){
  		cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO;
  		if (ArrayUtils.contains(new String []{
  	    		  ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO,
  	    		  ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO,
  	    		  ConstantesDataCatalogo.COD_EST_REVISION_INMOVILIZACION_TOTAL_DE_LA_MERCANCIA,
  	    		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_CON_CONTINUACION,
  	    		  ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL
  	    		  }, cod_EstRev)){
  	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ELIMINADO_POR_REASIGNACION);  //RETIRO DE BANDEJA
  	      }else{
  	    	  params.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
  	      }    		
  		params.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
  		/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//	        Integer result = 0;	        
	        espeDocuDAO.updateEstadoRevision(params);
	        /* PAS20145E220000399 FIN GGRANADOS */
	        params.put("cod_estrev",cod_EstRev );
  	}
  	else{
  		cod_Catalogo = ConstantesTipoCatalogo.CATALOGO_MOTIVO_FISCALIZAR_DECLARACIONES_NARANJAS;
  	}

//	    P13 JMCV - INICIO	      
    if (cod_Catalogo.equals(ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO)){
  	  asignacionManualService.grabarBandejaDocu(Long.valueOf(String.valueOf(params.get("num_corredoc"))),cod_EstRev);  
    }
//	    P13 JMCV - FIN	      
    diligencia.put("COD_USUREGIS", params.get("cod_usumodif"));
    diligencia.put("FEC_REGIS", params.get("fec_modif"));


    if((params.get("cod_canal").toString().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) &&  params.get("cod_indicador_dua").toString().equals(ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO))){
 		 diligencia.put("IND_RESPUESTA", 1);	
 		 Map<String, Object> consulta = consultaDAO.findByNumCorredocDiligencia(diligencia);
 		 
 		  if (CollectionUtils.isEmpty(consulta) || consulta.get("NUM_CORREDOC") == null)
 	      {
             //amancilla   SAU20153D211000637
              ConsultaService consultaService = fabricaDeServicios.getService("diligencia.ingreso.consultaService");
              Consulta consultaBean = new Consulta();

              consultaBean.setNumcorredoc(Utilidades.toLong(params.get("num_corredoc").toString()));
              //TODO: amancilla insertan 01 pq la revision de la continuacion de despacho se inserta con 01 ojo alli
              consultaBean.setTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
              consultaBean.setNumcorredocSol(new Long(0)); //cero pq no es rectificacion
              consultaBean.setIndicadorRespuesta(Constantes.SOLICITUD_DILIGENCIA_PROCEDENTE);
              CatEmpleado funcionario = new CatEmpleado();
              funcionario.setCodPers(params.get("cod_funcionario").toString());
              consultaBean.setFuncionario(funcionario);
              consultaService.grabarConsulta(consultaBean);

 	        //amancilla no pasa nada con esta implementacion consultaDAO.insert(diligencia);
 	      }
 	      else
 	      {
 	    	diligencia.put("IND_RESPUESTA",null );
 	        consultaDAO.update(diligencia);

 	      }

 		}else{
 		 Map<String, Object> consulta = consultaDAO.findByNumCorredocDiligencia(diligencia);
 		 
 		  if (CollectionUtils.isEmpty(consulta) || consulta.get("NUM_CORREDOC") == null)
 	      {
              //amancilla   SAU20153D211000637
              ConsultaService consultaService = fabricaDeServicios.getService("diligencia.ingreso.consultaService");
              Consulta consultaBean = new Consulta();

              consultaBean.setNumcorredoc(Utilidades.toLong(params.get("num_corredoc").toString()));
              //TODO: amancilla insertan 01 pq la revision de la continuacion de despacho se inserta con 01 ojo alli
              consultaBean.setTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
              consultaBean.setNumcorredocSol(new Long(0)); //cero pq no es rectificacion
              consultaBean.setIndicadorRespuesta(Constantes.SOLICITUD_DILIGENCIA_PROCEDENTE);
              CatEmpleado funcionario = new CatEmpleado();
              funcionario.setCodPers(params.get("cod_funcionario").toString());
              consultaBean.setFuncionario(funcionario);
              consultaService.grabarConsulta(consultaBean);

              //amancilla no pasa nada con esta implementacion consultaDAO.insert(diligencia);
 	      }
 	      else
 	      {
 	        consultaDAO.update(diligencia);
 	      }
 		} 
  }
}
//fin juazor RIN13

/*RIN13FSW-FIN*/
  
  
  /**
   * {@inheritDoc}
   */
  public void grabarDiligenciaByInicioRevision(Map<String, Object> params) throws ServiceException
  {

    Map<String, Object> mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
    FechaBean fecActual = new FechaBean();
    mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
    try
    {
      this.cabDiligenciaDAO.insert(mapDilig);

    }
    catch (Exception e)
    {
      // dejar asi en produccion aparecio error SAU20133N002000144
      // es decir este metodo se ejecuta varias veces en distintas invocaciones
      // para que no se caiga , ya estaba asi, cuando se arreglo aparecio
      // SAU20133N002000144
      // se regresa a su estadeo original,pendiente de evaluar

        //amancilla se comenta pq hace mucho bulla en el log esta parte del codigo hay que cambiarlo
        //dado que no se debe de invocar dada vez que se guarda la revision siempre va salir error de PK
     // log.error("*** ERROR ***", e);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void insertarDiligencia(Map<String, Object> mapaDiligencia) throws ServiceException
  {
    FechaBean fecActual = new FechaBean();
    mapaDiligencia.put("FEC_DILIGENCIA", fecActual.getTimestamp());
    try
    {
      this.cabDiligenciaDAO.insert(mapaDiligencia);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
    }
  }
  // RIN16
  public void insertDiligencia(Diligencia diligencia) throws ServiceException{
	  cabDiligenciaDAO.insert(diligencia);
  }

  /**
   * {@inheritDoc}
   */
  public void grabarModificacionDiligencia(Map<String, Object> mapaDiligencia) throws ServiceException
  {
    this.cabDiligenciaDAO.insert(mapaDiligencia);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> tieneConclusionEnProceso(Map<String, Object> params) throws ServiceException
  {
    try
    {

      Map<String, Object> mapRes = new HashMap<String, Object>();

      Map<String, Object> mapSol = cabDeclaraDAO.findTieneConclusionEnProceso(params);
      if (CollectionUtils.isEmpty(mapSol))
      {
        mapRes.put("FEC_DECLARACION", "NO_FOUND");
      }
      else
      {
        mapRes = mapSol;
      }
      return mapRes;
    }
    catch (Exception e)
    {
      log.error("DiligenciaServiceImpl : tieneConclusionEnProceso - ERROR: ", e);
      throw new ServiceException(this, e.getStackTrace().toString());
    }
  }

  /**
   * 25/02/2010: Metodo para validar si la DUA tuvo una diligencia de ampliaci�n
   * de plazo.
   *
   * @param params
   *          the params
   * @return Map<String, Object>
   * @throws ServiceException
   *           the service exception
   * @author lsuclupe
   * @see F2ingresoDiligencia20091124.doc CUR 11.03 Ampliar plazo de Conclusi�n
   *      de Despacho
   */
  public Map<String, Object> tieneAmpliacionPlazo(Map<String, Object> params) throws ServiceException
  {
    try
    {
      Map<String, Object> mapRes = new HashMap<String, Object>();
      Map<String, Object> mapSol = cabDiligenciaDAO.findTieneAmpliacionPlazo(params);
      if (CollectionUtils.isEmpty(mapSol))
      {
        mapRes.put("FEC_CONCLUSION", "NO_FOUND");
      }
      else
      {
        mapRes = mapSol;
      }
      return mapRes;
    }
    catch (Exception e)
    {
      log.error("DiligenciaServiceImpl : tieneAmpliacionPlazo - ERROR: ", e);
      throw new ServiceException(this, e.getStackTrace().toString());
    }
  }

  /**
   * 25/02/2010: Metodo para grabar la ampliaci�n del plazo.
   *
   * @param params
   *          the params
   * @return void
   * @throws ServiceException
   *           the service exception
   * @author lsuclupe
   * @see F2ingresoDiligencia20091124.doc CUR 11.03 Ampliar plazo de Conclusi�n
   *      de Despacho
   */
  public void grabarAmpliacionPlazo(Map<String, Object> params) throws ServiceException
  {
    try
    {
      if (params.get("TIPO_OPERACION").equals("INSERT"))
      {
        cabDiligenciaDAO.insert(params);
        consultaDAO.insert(params);
      }
      else if (params.get("TIPO_OPERACION").equals("UPDATE"))
      {
        cabDiligenciaDAO.update(params);
        Map<String, Object> mapConsul = new HashMap<String, Object>();
        mapConsul.put("NUM_CORREDOC", params.get("NUM_CORREDOC"));
        mapConsul.put("COD_TIPDILIGENCIA", params.get("COD_TIPDILIGENCIA"));
        mapConsul.put("COD_FUNCIONARIO", params.get("COD_FUNCIONARIO"));
        mapConsul.put("COD_USUREGIS", params.get("COD_USUREGIS"));
        mapConsul.put("FEC_REGIS", params.get("FEC_REGIS"));
        mapConsul.put("COD_USUMODIF", params.get("COD_USUMODIF"));
        mapConsul.put("FEC_MODIF", params.get("FEC_MODIF"));
        consultaDAO.update(mapConsul);
      }
    }
    catch (Exception e)
    {
      log.error("DiligenciaServiceImpl : tieneAmpliacionPlazo - ERROR: ", e);
      throw new ServiceException(this, e.getStackTrace().toString());
    }
  }

  /**
   * 01/03/2010: Metodo para las comunicaciones grabadas por la declaracion.
   *
   * @param params
   *          the params
   * @return List<Map<String, Object>>
   * @throws ServiceException
   *           the service exception
   * @author lsuclupe
   * @see
   */
  public List<Map<String, Object>> obtenerComunicaciones(Map<String, Object> params) throws ServiceException
  {
    List lista = null;
    try
    {
      lista = comunicacionDAO.findByNumCorredoc(params);

    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return lista;
  }

  /**
   * Marca establecimiento.
   *
   * @param declaracion
   *          the declaracion
   * RIN13 cambio a public
   */
	public void marcaEstablecimiento(Map declaracion) throws ServiceException {
		if (declaracion.get("COD_LOCALANEXO") != null) {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + "000"));
      boolean inserta = false;
      Integer hoy = Integer.valueOf((new FechaBean()).getFormatDate("yyyyMMdd"));
      Estabnoapto estabnoapto = new Estabnoapto();
      estabnoapto.setRuc(declaracion.get("NUM_DOCIDENT_PIM").toString());
      estabnoapto.setCorrel(Short.valueOf(declaracion.get("COD_LOCALANEXO").toString()));
      List<Estabnoapto> lstEstabnoapto = estabnoaptoDAO.selectOrdenado(estabnoapto);
      if (lstEstabnoapto != null && lstEstabnoapto.size() > 0)
      {
        for (Estabnoapto tmpEstabnoapto : lstEstabnoapto)
        {
          if (tmpEstabnoapto.getFfin() <= hoy)
          {
            inserta = true;
            if (tmpEstabnoapto.getNsecuDesha() == 2)
            {
              estabnoapto.setNsecuDesha(Integer.valueOf(1));
              estabnoapto.setFfin(Integer.valueOf(99991231));
            }
            else
            {
              estabnoapto.setNsecuDesha(Integer.valueOf(2));
              estabnoapto.setFfin(Integer.valueOf(hoy + 10000));
            }
          }
          break;
        }
      }
      else
      {
        inserta = true;
        estabnoapto.setNsecuDesha(Integer.valueOf(1));
        estabnoapto.setFfin(Integer.valueOf(99991231));
      }
      if (inserta)
      {
        estabnoapto.setFingreso(hoy);
      //  estabnoapto.setFmod(hoy);
        estabnoapto.setCodiAduan(declaracion.get("COD_ADUANA").toString());
        estabnoapto.setAnoPrese(declaracion.get("ANN_PRESEN").toString());
        estabnoapto.setNumeCorre(Cadena.padLeft(declaracion.get("NUM_DECLARACION").toString(), 6, '0'));
        estabnoapto.setCodiRegi(declaracion.get("COD_REGIMEN").toString());
        // estabnoapto.setCdel(" ");
        //estabnoapto.setTexpedhabil(" ");
        //estabnoapto.setCdigmod(" ");
        estabnoaptoDAO.insert(estabnoapto);
      }
    }
  }

  /**
   * Registrar recti oficio.
   *
   * @param mapRectif
   *          the map rectif
   * @param tipDilig
   *          the tip dilig
   * @param numCorredoc
   *          the num corredoc
   * @param codTabla
   *          the cod tabla
   */
  private void registrarRectiOficio(Map mapRectif,
                                    String tipDilig, Long numCorredoc, String codTabla)
  {
    mapRectif.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapRectif.put("tipoDiligencia", tipDilig);
    mapRectif.put("tabla", codTabla);
    mapRectif.put("NUM_CORREDOC", numCorredoc);
    if (mapRectif.get("dataOriginal") == null)
    {
      mapRectif.put("dataOriginal", mapRectif.get("clave"));
    }
    if(!tipDilig.equals(Constantes.DILIG_DESCA_PARCIAL)){//si es diferente a la diligencia de descargas parciales, continua con el flujo normal
    mapRectif.put("NUM_CORREDOC_SOL", "0");
    }
    
    rectiOficioDAO.insertMapComparador(mapRectif);
  }

  /**
   * Permite grabar los dados modificdos en tabla det_ofirecti incluye los datos
   * nuevos.
   *
   * @param mapRectif
   *          the map rectif
   * @param tipDilig
   *          the tip dilig
   * @param numCorredoc
   *          the num corredoc
   * @param codTabla
   *          the cod tabla
   * @param isNewRecord
   *          the is new record
   */
  private void registrarRectiOficio(
                                    Map mapRectif,
                                    String tipDilig,
                                    Long numCorredoc,
                                    String codTabla,
                                    boolean isNewRecord)
  {

    mapRectif.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapRectif.put("tipoDiligencia", tipDilig);
    mapRectif.put("tabla", codTabla);
    mapRectif.put("NUM_CORREDOC", numCorredoc);

    Map<String, Object> mapTablaLimpia = new HashMap<String, Object>(mapRectif);
    // limpiar datos
    mapTablaLimpia.remove("lstDocuPreceDua");
    mapTablaLimpia.remove("lstFacturaSerie");
    mapTablaLimpia.remove("mapDetAdiAtreex");
    mapTablaLimpia.remove("ESTADO_REGISTRO");
    mapTablaLimpia.remove("IND_TIPO_REGISTRO");
    mapTablaLimpia.remove("OPERACION_SERIE");
    mapTablaLimpia.remove("tabla");

    mapRectif.put("dataOriginal", mapTablaLimpia);
    mapRectif.put("NUM_CORREDOC_SOL", "0");

    rectiOficioDAO.insertMapComparadorAll(mapRectif, isNewRecord);

  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> validarFechaVencimiento(
                                                     String codRegimen,
                                                     String codAduana,
                                                     String tipoOperDespacho,
                                                     Date fecVenRegimen,
                                                     Date fecNumeracion,
                                                     Date fecGarantia)
  {
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ + codAduana));
    Map<String, Object> resultado = new HashMap<String, Object>();

    String fechaVencimientoError = "";
    /*
     * se verifica la fec. vencimiento de acuerdo a la tabla pit_tipo_plazos a
     * partir de la fecha de numeraci�n y ser un d�a h�bil, y ser menor o igual
     * a la fecha de garant�a.
     */

    Date fecMaxVencimiento = null;
    // se verifica que la fecha de vencimiento sea mayor a la fecha de
    // numeracion.
    if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fecVenRegimen, fecNumeracion,
                                                   SunatDateUtils.COMPARA_SOLO_FECHA))
    {
      fechaVencimientoError = "La fecha de vencimiento debe ser mayor a la fecha de numeraci�n " +
                              SunatDateUtils.getFormatDate(fecNumeracion, "dd/MM/yyyy");
      resultado.put("fechaVencimientoError", fechaVencimientoError);
      return resultado;
    }

    // se calcula la fecha de vencimiento maxima de acuerdo al regimen
    if (codRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO))
    {
      PitTipoPlazos pitTipoPlazos = pitTipoPlazosDAO.selectAnoMesByTipoOperacionDespa(tipoOperDespacho);
      if (pitTipoPlazos != null)
      {
        if (pitTipoPlazos.getAno() == 0)
        {
          fecMaxVencimiento = SunatDateUtils.addMonth(fecNumeracion, (pitTipoPlazos.getMes()));
        }
        else
        {
          fecMaxVencimiento = SunatDateUtils.addMonth(fecNumeracion, (pitTipoPlazos.getAno() * 12));
        }
      }
      /*
       * fecha de ven. sea menor o igual de dos a�os a partir de la fecha de
       * numeraci�n y que la garant�a cubra dicho plazo, la fecha de vencimiento
       * debe ser un d�a h�il.
       */
    }
    else if (codRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO))
    {
      fecMaxVencimiento = SunatDateUtils.addMonth(fecNumeracion, 24);
    }

    if (fecMaxVencimiento != null
        && SunatDateUtils.esFecha1MayorQueFecha2(fecVenRegimen, fecMaxVencimiento, SunatDateUtils.COMPARA_SOLO_FECHA))
    {
      fechaVencimientoError =
                              "La fecha de vencimiento ingresada : "
                                  + SunatDateUtils.getFormatDate(fecVenRegimen, "dd/MM/yyyy")
                                  +
                                  " es mayor a la fecha de m�xima permitida: "
                                  + SunatDateUtils.getFormatDate(fecMaxVencimiento, "dd/MM/yyyy");
      resultado.put("fechaVencimientoError", fechaVencimientoError);
      return resultado;
    }
    if (fecGarantia != null
        && SunatDateUtils.esFecha1MayorQueFecha2(fecVenRegimen, fecGarantia, SunatDateUtils.COMPARA_SOLO_FECHA))
    {
      fechaVencimientoError = "La fecha de vencimiento ingresada : "
                              + SunatDateUtils.getFormatDate(fecVenRegimen, "dd/MM/yyyy") +
                              " es mayor a la fecha fin de cobertura de la garant�a: "
                              + SunatDateUtils.getFormatDate(fecGarantia, "dd/MM/yyyy");
      resultado.put("fechaVencimientoError", fechaVencimientoError);
      return resultado;
    }

    if (fecVenRegimen != null)
    {
      Map pFecha = new HashMap();
      int numdias = 0; // 0: cantidad de d�as sumados
      int operacion = 2; // 2: Sumatoria de d�as
      String tipodia = "U"; // U: d�a �til
      String incluye = "S"; // S: Se cuenta del primer d�a
      String alcance = "S"; // N: No cuenta las fechas suspendidas�.cat_suspende
      pFecha.put("NUMDIAS", numdias);
      pFecha.put("TIPODIA", tipodia);
      pFecha.put("OPERACION", operacion);
      pFecha.put("INCLUYE", incluye);
      pFecha.put("ALCANCE", alcance);
      pFecha.put("COD_ADUANA", codAduana);
      pFecha.put("FECHAINICIAL", SunatDateUtils.getIntegerFromDate(fecVenRegimen));
      String ultimoDia = this.soporteService.obtenerSgteDiaUtil(pFecha);
      fecVenRegimen = SunatDateUtils.getDateFromInteger(Integer.parseInt(ultimoDia));
      resultado.put("fechaUtilRegimen", SunatDateUtils.getFormatDate(fecVenRegimen, "dd/MM/yyyy"));
    }

    return resultado;
  }

  /**
   * Grabacion de la diligencia desde componentes objetos, se deber�a ir migrado
   * las demas funcionalidades de grabacion. Es invocada por el orquestador.
   *
   * @param variablesIngreso
   * @param declaracion
   * @return
   * @throws Exception
   */
  @ServicioAnnot(tipo = "G", codServicio = 4020, descServicio = "servicio general de grabado de la diligencia")
  @ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "variablesIngreso", "declaracion" })
  @OrquestaDespaAnnot(codServInstancia = 4020,
                      numSecEjec = 422,
                      nomClase = "pe.gob.sunat.tecnologia.receptor.model.Mensaje")
  public Map<String, Object>
      grabarDiligencia(Map<String, Object> variablesIngreso, Declaracion declaracion) throws Exception
  {
    if (UserNameHolder.get() == null)
      UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);
    Map<String, Object> resultadoError = new HashMap<String, Object>();
    Boolean marcaDesdatadoDatado =
                                   variablesIngreso.containsKey("marcaDesdatadoDatado")
                                                                                       ? (Boolean) variablesIngreso.get("marcaDesdatadoDatado")
                                                                                       : false;
    Boolean marcaRealizarDatado =
                                  variablesIngreso.containsKey("marcaRealizarDatado")
                                                                                     ? (Boolean) variablesIngreso.get("marcaRealizarDatado")
                                                                                     : false;

    String codTransaccion = declaracion.getCodtipotrans();

    if (marcaDesdatadoDatado)
    {
      resultadoError =
                       grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_RECTIFICACION,
                                                            codTransaccion, variablesIngreso);
    }
    else if (marcaRealizarDatado)
    {
      resultadoError =
                       grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_RECTIFICACION,
                                                            codTransaccion, variablesIngreso);
    }
//    if (!Constants.COD_TRANSAC_DILIGENCIA_OFICIO.equals(codTransaccion.substring(2, 4)))
//    {
      grabarDeclaracionService.afectarCtaCteRegPrecedeDeposito(declaracion, "", "");
//    }
      actualizarCtaCteRegimen(declaracion, declaracion.getNumeroCorrelativo());//gmontoya P29 Pase 15 2015 

    return resultadoError;
  }
//gmontoya P29 Pase 15 2015 inicio 
  private void actualizarCtaCteRegimen(Declaracion declaracion, Long numCorreDoc){
	  boolean esTPN21 = false;
	  
	  for(DatoSerie serie:declaracion.getDua().getListSeries()){		
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
				esTPN21 = serie.getCodtratprefe()==21;
				break;
			}
	  }
	  if(esTPN21){
		  DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
		  Map<String, Object> params = new HashMap<String, Object>();
		  params.put("numCorredocDesc", numCorreDoc);
		  params.put("indAnulacion", "1");		  
		  List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);
		  
		  for(DatoSerie serie:declaracion.getDua().getListSeries()){		
				for(DatoRegPrecedencia prec:serie.getListRegPrecedencia()){
					if( esTPN21 ) {
						fillCabCtacteRegimen(serie, prec, numCorreDoc, listaDet);
					}
				}
		  }
	  }else{
		  SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
		  Map pkDocu = new HashMap();
		  pkDocu.put("NUM_CORREDOC",numCorreDoc);
		  pkDocu.put("COD_CONVENIO","  21");
		  pkDocu.put("COD_TIPCONVENIO","T");
		  List lista = serieService.obtenerConvenioSerieMap(pkDocu);
		  if(!CollectionUtils.isEmpty(lista)){
				  
			  DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
			  Map<String, Object> params = new HashMap<String, Object>();
			  params.put("numCorredocDesc", numCorreDoc);
			  params.put("indAnulacion", "1");		  
			  List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);
			
			  DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
			  ctaCteService.quitarTPN21CtacteRegimen(listaDet);
		  }
	  }	  
  }
  
  private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc,List<DetCtacteRegimen> listaDet){
		
		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("codAduana", prec.getCodaduapre());
		paramCtaCte.put("annPresen", prec.getAnndeclpre().substring(0, 4));
		paramCtaCte.put("codRegimen", prec.getCodregipre());
		paramCtaCte.put("numDeclaracion", prec.getNumdeclpre());
		paramCtaCte.put("numSecserie", prec.getNumserpre());
		List<CabCtacteRegimen> listaCabCtacteRegimen = ctaCteService.obtenerCabeceraCtaCte(paramCtaCte);
		if( listaCabCtacteRegimen.size()>0 ) {
			CabCtacteRegimen ctacte = listaCabCtacteRegimen.get(0); 
			boolean actualizarRegu = false;
			BigDecimal diferencia = BigDecimal.ZERO;
			for(DetCtacteRegimen detCtaCte : listaDet){
				if(detCtaCte.getNumCtacte().equals(ctacte.getNumCtacte()) && 
					detCtaCte.getNumSerieDesc().equals(serie.getNumserie())){
					diferencia = SunatNumberUtils.diference(serie.getCntunicomer(), detCtaCte.getCntDescargada());
					actualizarRegu = true;
					break;
				}
			}
			if(actualizarRegu && diferencia.compareTo(BigDecimal.ZERO)!=0){
				ctaCteService.actualizaReguCtacteRegimen(ctacte, serie, numCorredoc,diferencia);
			}else{
				if(!actualizarRegu){
					ctaCteService.actualizaCtacteRegimen(ctacte, serie, numCorredoc);
				}
			}
		}

		return;
	}
//gmontoya P29 Pase 15 2015 fin 
  /**
   * {@inheritDoc}
   */
  public List<DatoVehiculo> findVehiculoByMap(Map<String, Object> params) throws ServiceException
  {
    return vehiCeticoDAO.findVehiculoByMap(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<DatoMontoGasto> findMontoGastoByMap(Map<String, Object> params) throws ServiceException
  {
    return montoGastoDAO.findMontoGastoByMap(params);
  }

  public Integer count(Map<String, Object> paramDiligencia)
                                                           throws ServiceException
  {
    return cabDiligenciaDAO.count(paramDiligencia);
  }

  public Map<String, Object> findDuaDiligenciada(String numCorreDoc)
                                                                    throws ServiceException
  {
    return cabDiligenciaDAO.findDuaDiligenciada(numCorreDoc);
  }

  public Map<String, Object> findDuaRectificada(String numCorreDoc)
                                                                   throws ServiceException
  {
    return cabDiligenciaDAO.findDuaRectificada(numCorreDoc);
  }



  /**
   * Valida numero maximo definido por el parametro (numMaxRegistros) de
   * registros de diligencias por dia
   *
   * @param String
   *          numCorreDoc, String codTipDiligencia, Integer numMaxRegistros
   * @param numMaxRegistros
   *
   * @autor: amancillaa
   */
  public Boolean validarMaximoNumeroDiligenciasRegistradas(String numCorreDoc, String codTipDiligencia,
                                                           Integer numMaxRegistros)
  {

    Boolean res = true;
    Map<String, Object> mapBusq = new HashMap<String, Object>();
    mapBusq.put("NUM_CORREDOC", numCorreDoc);
    mapBusq.put("COD_TIPDILIGENCIA", codTipDiligencia);
    // Flag para activar condicion en el query
    mapBusq.put("FLG_REC_REGIS", "0");
    Integer maxDiligenciaOficio = this.cabDiligenciaDAO.countMaxByNumCorreDocAndTipodAndDate(mapBusq);
    if (maxDiligenciaOficio != null && maxDiligenciaOficio >= numMaxRegistros)
    {
      res = false;
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public Boolean tieneDiligenciaTipo(BusquedaDua busquedaDua, String tipoDiligencia) throws ServiceException
  {

    if (Constantes.COD_TIPO_DILIGENCIA_DESPACHO.equals(tipoDiligencia))
    {
      String numCorreDoc = busquedaDua.getNumCorreDoc().toString();
      // Verificamos si tiene diligencia
      Map<String, Object> mapRes = cabDiligenciaDAO.findDuaDiligenciada(numCorreDoc);

      return !CollectionUtils.isEmpty(mapRes) ? true : false;

    }
    else
    {
      HashMap<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_DECLARACION", busquedaDua.getNumDeclaracion());
      params.put("COD_ADUANA", busquedaDua.getCodAduana());
      params.put("ANN_PRESEN", busquedaDua.getAnnoPresenta());
      params.put("COD_REGIMEN", busquedaDua.getCodRegimen());
      params.put("COD_TIPDILIGENCIA", tipoDiligencia);
      // en el caso de rectifiacion su PK adicional es el numcorredoc de la
      // solictud
      if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION.equals(tipoDiligencia) &&
          busquedaDua.getNumCorreDocSol() > 0)
      {
        params.put("NUM_CORREDOC_SOL", busquedaDua.getNumCorreDocSol());
      }
      // Verifica si existe registrado diligencia tipo

      Map<String, Object> mapRes = cabDiligenciaDAO.findTieneDeclaracionDiligenciaTipo(params);

      return !CollectionUtils.isEmpty(mapRes) ? true : false;
    }
  }

  public Object
      cargarDatosInicialesBDtoMap(BusquedaDua busquedaDua, EnumTablaModel enumVariable)
                                                                                       throws ServiceException
  {

    String codTabla = enumVariable.getCodTabla();

    if (busquedaDua.getNumCorreDoc() == null)
    {
      return null;
    }

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
    if (Constantes.COD_TABLA_DET_DECLARA.equals(codTabla))
    {

      // lstRspta = serieService.obtenerListadoSeries();
    }
    if (Constantes.COD_TABLA_CAB_CERTIORIGEN.equals(codTabla))
    {

    }
    else if (Constantes.COD_TABLA_DOCAUT_ASOCIADO.equals(codTabla))
    {

      // docAutAsociadoDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_DET_AUTORIZACION.equals(codTabla))
    {

      // detAutorizacionDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_FACTURA_SERIE.equals(codTabla))
    {

      // lstRspta = facturaSerieDAO.select(busquedaDua.convertMap());
      // se cambia pq esta consulta te trae todo join factura x serie con su
      // datos
      Map numCorredocDua = new HashMap();
      numCorredocDua.put("num_corredoc", busquedaDua.getNumCorreDoc());
      lstRspta = (List<Map<String, Object>>) formaFactuDAO.joinFacturaSerieFindBySeries(numCorredocDua);

    }
    else if (Constantes.COD_TABLA_FORMA_FACTU.equals(codTabla))
    {

      lstRspta = formaFactuDAO.select(busquedaDua.convertMap());

    }
    else if (Constantes.COD_TABLA_OBSERVACION.equals(codTabla))
    {

      lstRspta = observacionDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_CAB_ADI_ADM_TEM.equals(codTabla))
    {

      lstRspta = cabAdiAdmTemDAO.select(busquedaDua.convertMap());

    }
    else if (Constantes.COD_TABLA_DET_ADI_ATPA.equals(codTabla))
    {

    }
    else if (Constantes.COD_TABLA_DET_ADI_ATREEX.equals(codTabla))
    {

      // detAdiAtreexDAO.select(busquedaDua.convertMap());

    }
    else if (Constantes.COD_TABLA_DET_ADI_IMPO_CONSU.equals(codTabla))
    {

      // detAdiImpoconsuDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_PARTICIPANTE_DOC.equals(codTabla))
    {

      lstRspta = participanteDocDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_FORMB_PROVEEDOR.equals(codTabla))
    {

      lstRspta = formBProveedorDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_CONDICION_TRANSA.equals(codTabla))
    {

    }
    else if (Constantes.COD_TABLA_FORMB_MONTO.equals(codTabla))
    {

    }
    else if (Constantes.COD_TABLA_COMPROBPAGO.equals(codTabla))
    {

      lstRspta = comprobPagoDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_ITEM_FACTURA.equals(codTabla))
    {

      lstRspta = itemFacturaDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_SERIES_ITEM.equals(codTabla))
    {

      lstRspta = seriesItemDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_CONVENIO_SERIE.equals(codTabla))
    {

      lstRspta = convenioSerieDAO.select(busquedaDua.convertMap());
    }
    else if (Constantes.COD_TABLA_DOCUPRECE_DUA.equals(codTabla))
    {

      lstRspta = docuPreceDuaDAO.select(busquedaDua.convertMap());
    }

    return lstRspta;
  }
/*RIN13FSW-INICIO*/
//<EHR>

   //P34 amancilla
   public Map  obtenerParticipante(String numSecParticipante){

       Map params = new HashMap();
       params.put("NUM_SECPARTIC",numSecParticipante);
       // FIXME : Error en la compilacion del trunk, se agrega CAST (Map)
       return (Map)participanteDocDAO.select(params).get(0);
   }



public boolean  existeInformacionICA(Map<String, Object> paramsMap) throws ServiceException {
	List<MovimientoCargaParti> result= (List<MovimientoCargaParti>)movCargaPartiDAO.getMovimientoCargaParti(paramsMap);
	if(CollectionUtils.isEmpty(result)){
		return false;
	}
	return true;
}

public boolean  findDetDeclaraTipoCargaConsolidadoConsolidado1a1(String NUM_CORREDOC){
	
	Map<String, Object> params = new HashMap<String, Object>();
	params.put("NUM_CORREDOC", NUM_CORREDOC);
	int cant = detDeclaraDAO.findCantDetDeclaraTipoCargaConsolidadoConsolidado1a1(params );
	if(cant>0){
		return true;
	}
	return false;
}



/*inicio gdlr*/
@Override
public String validarViaTranspDiferentePostal(Map<String, Object> mapaDecla)throws ServiceException {
	return validarViaTranspDiferentePostal(mapaDecla, null);
}

@Override
public String validarViaTranspDiferentePostal(Map<String, Object> mapaDecla, List<Map<String, Object>> series) throws ServiceException {

	//List<Manifiesto> ListManifiesto = this.obtenerListManifiesto(mapaDecla);
    //DZC INI	SAU20143N002000521
    /*Declaracion declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(mapaDecla.get("COD_ADUANA").toString(),
            new Integer(mapaDecla.get("NUM_DECLARACION").toString()), new Integer(mapaDecla.get("ANN_PRESEN").toString()), mapaDecla.get("COD_REGIMEN").toString());
	boolean tieneprece=false;
	DUA dua = declaracionBD.getDua();
	boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
	
	 if(declaracionTieneDatoSeries){
		tieneprece = this.existeRegPrecedencia(dua.getListSeries());
	 }
	 */
	 //DZC FIN
	 //gdlr... un solo query para verificar precedencia
	 Long numeroCorrelativo = new Long(mapaDecla.get("NUM_CORREDOC").toString());
	 boolean tieneprece = docuPreceDuaDAO.hasRegimenPrecedenteRegimen70o91(numeroCorrelativo);
	 
	/*ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
	Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio("01", mapaDecla.get("COD_VIATRANS").toString().trim(), 
			mapaDecla.get("COD_ADUAMANIFIESTO").toString().trim(), Integer.parseInt(mapaDecla.get("ANN_MANIFIESTO").toString().trim()), 
			SunatStringUtils.lpad(mapaDecla.get("NUM_MANIFIESTO").toString().trim(), 6, ' '), true );*/

	//String result =  declaracionService.obtieneDocumentosDeTransporteDeLaDeclaracionValid(mapaDecla);
	if(!tieneprece){// DZC Si tiene regimen precedente el manifiesto ya fue validado, Manifiesto no deberia validarse
		//gdlr: solo en este caso se debe consultar el manifiesto
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		/*Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio("01", mapaDecla.get("COD_VIATRANS").toString().trim(),
				mapaDecla.get("COD_ADUAMANIFIESTO").toString().trim(), Integer.parseInt(mapaDecla.get("ANN_MANIFIESTO").toString().trim()), 
				SunatStringUtils.lpad(mapaDecla.get("NUM_MANIFIESTO").toString().trim(), 6, ' '), true );*/

		Map<String,Object> mapManifiesto = new HashMap<String, Object>();
		mapManifiesto.put("COD_VIATRANS", mapaDecla.get("COD_VIATRANS").toString().trim());
		mapManifiesto.put("COD_ADUAMANIFIESTO", mapaDecla.get("COD_ADUAMANIFIESTO").toString().trim());
		mapManifiesto.put("ANN_MANIFIESTO", Integer.parseInt(mapaDecla.get("ANN_MANIFIESTO").toString().trim()));
		mapManifiesto.put("NUM_MANIFIESTO", SunatStringUtils.lpad(mapaDecla.get("NUM_MANIFIESTO").toString().trim(), 6, ' '));
		mapManifiesto.put("COD_TIPMANIFIESTO", "01");
		mapManifiesto.put("COD_LUGARRECEP",  mapaDecla.get("COD_LUGARRECEP").toString().trim());
		mapManifiesto.put("FEC_DECLARACION", mapaDecla.get("FEC_DECLARACION"));//PAS20191U220200013
		mapManifiesto.put("COD_REGIMEN", mapaDecla.get("COD_REGIMEN").toString().trim());

		//Este metodo busca en el Nsigad y el en Sigad haciendo conversion de via si es necesario - PAS20191U220200013
		Manifiesto manifiesto =  manifiestoService.obtenerDatosManifiesto(mapManifiesto);

		String codigoViaTransporteSda = "";
		if(manifiesto != null ){//PAS20191U220200013
			if(manifiesto.isEsSigad()) {
				codigoViaTransporteSda = manifiestoService.transformarViaTransporteDeUnece(mapManifiesto.get("COD_VIATRANS").toString(), (Date) mapManifiesto.get("FEC_DECLARACION"), true);
			}
		}

		
	if(manifiesto != null ){
		//Manifiesto manifiesto = ListManifiesto.get(0);
		/*String numeroDocumento = this.compararDocumentoTrasnporte(manifiesto.getNumeroDocumentoReferencia(),mapaDecla.get("NUM_CORREDOC").toString());*/ 
		 if(manifiesto.getCodAnulaManif()!=null &&!StringUtils.isEmpty(manifiesto.getCodAnulaManif().trim())){ 
			  return "N�mero de manifiesto anulado";
		  }else if(!manifiesto.getViaTransporte().getCodDatacat().equals(mapaDecla.get("COD_VIATRANS").toString())){
				  if(manifiesto.isEsSigad() && !manifiesto.getViaTransporte().getCodDatacat().equals(codigoViaTransporteSda)) {
			  return "La v�a de transporte de la declaraci�n "+catalogoAyudaService.getDescripcionDataCatalogo("10", mapaDecla.get("COD_VIATRANS").toString())+" no es la misma que la del manifiesto  "+catalogoAyudaService.getDescripcionDataCatalogo("10", manifiesto.getViaTransporte().getCodDatacat().toString());
				  }//revisar si es cambio 13
				  else if (!manifiesto.isEsSigad()) {
					  return "La v�a de transporte de la declaraci�n "+catalogoAyudaService.getDescripcionDataCatalogo("227", mapaDecla.get("COD_VIATRANS").toString())+" no es la misma que la del manifiesto  "+catalogoAyudaService.getDescripcionDataCatalogo("10", manifiesto.getViaTransporte().getCodDatacat().toString());
			  }


		  /*}else if(!StringUtils.isEmpty(result)){
			  return result;
		  }*/
		  }else{
				//gdlr: solo en este caso se debe aplicar este metodo pesado "declaracionService.obtieneDocumentosDeTransporteDeLaDeclaracionValid"... el cual tambien debe ser optimizado
				String result =  declaracionService.obtieneDocumentosDeTransporteDeLaDeclaracionValid(mapaDecla, series);
				if (!StringUtils.isEmpty(result)) {
					return result;
				}
		  }
	}else{
		return "N�mero de manifiesto no existe";
	}
	}
	return "";
}

//DZC INI SAU20143N002000521
public boolean existeRegPrecedencia (Elementos<DatoSerie> series){
	boolean tienePrecedencia = false;
	for (DatoSerie datoSerieActual : series) {
		if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
			for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
				if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(datoRegPreActual.getCodregipre())){
					;
				}else{
					if (!tienePrecedencia)
						tienePrecedencia=true;
				}
			}
		}		
	}
	return tienePrecedencia;
}
//DZC FIN
@Override
@Deprecated
/**
 * La validacion no esta completa solo verifica en el bdsigad
 * Ya existe a nivel SEIDA la validaci�n ya no debe usarse este metodo
 */
public String validarViaTranspIgualPostal(Map<String, Object> mapCapDeclara)throws ServiceException {
	//List<Manifiesto> ListManifiesto = this.obtenerListManifiesto(mapCapDeclara);
	ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
	Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio("01", mapCapDeclara.get("COD_VIATRANS").toString().trim(), 
			mapCapDeclara.get("COD_ADUAMANIFIESTO").toString().trim(), Integer.parseInt(mapCapDeclara.get("ANN_MANIFIESTO").toString().trim()), 
			SunatStringUtils.lpad(mapCapDeclara.get("NUM_MANIFIESTO").toString().trim(), 6, ' '), true );
	if(manifiesto != null ){
		//Manifiesto manifiesto = ListManifiesto.get(0);
		
		String result =  declaracionService.obtieneDocumentosDeTransporteDeLaDeclaracionValid(mapCapDeclara);
//		String numeroDocumento = this.compararDocumentoTrasnporte(manifiesto.getNumeroDocumentoReferencia(),mapCapDeclara.get("NUM_CORREDOC").toString());
		 if(manifiesto.getCodAnulaManif()!=null && !StringUtils.isEmpty(manifiesto.getCodAnulaManif().trim())){
			  return "N�mero de manifiesto anulado";
		  }else if(!manifiesto.getViaTransporte().getCodDatacat().equals(mapCapDeclara.get("COD_VIATRANS").toString())){
			  return "La v�a de transporte de la declaraci�n "+catalogoAyudaService.getDescripcionDataCatalogo("10", mapCapDeclara.get("COD_VIATRANS").toString())+" no es la misma que la del manifiesto postal "+catalogoAyudaService.getDescripcionDataCatalogo("10", manifiesto.getViaTransporte().getCodDatacat().toString());
		  }else if(!StringUtils.isEmpty(result)){
			  return result;
		  }/*else if(!mapCapDeclara.get("NUM_CORREDOC").toString().equals(numeroDocumento)){
			  return "El documento de transporte (aviso postal) "+manifiesto.getNumeroDocumentoReferencia()+" no coincide con el consignado en el manifiesto postal"+manifiesto.getNumeroDocumentoReferencia();
			  
		  }*/else if(StringUtils.isEmpty((String) ObjectUtils.defaultIfNull(mapCapDeclara.get("COD_PUER_DESP").toString().trim(), ""))){
			  return "El puerto de embarque a�n no fue consignado en la declaraci�n";
		  }else if(!mapCapDeclara.get("COD_PUER_DESP").equals(manifiesto.getLugarSalida().getIdentificacion())){
			  /**COD_PUER_EMBAR*/
			  return "El puerto de embarque consignado en la declaraci�n "+mapCapDeclara.get("COD_PUER_DESP")+" no coincide con el consignado en el manifiesto postal "+manifiesto.getLugarSalida().getIdentificacion();
		  }/*else if(manifiesto.getTotalBultos().compareTo(new BigDecimal(mapCapDeclara.get("CNT_TOTBULTOS").toString()))==-1){
			  return "Los pesos y bultos consignados en la declaraci�n son mayores a los pesos y bultos recibidos del manifiesto";
		  } cambio al dia 17/10/2014-12:45*/
		 /*23/10/2014-11:59 inicio*/
		 Map<String, Object> parameterMap = new HashMap<String, Object>();
		 parameterMap.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
		 Datado datado= datadoDAO.findSumByParameterMap(parameterMap);
		 BigDecimal totalPesoDatado = new BigDecimal(0);
		 BigDecimal totalBultoDatado = new BigDecimal(0);
		 BigDecimal bultosDeclara = new BigDecimal(mapCapDeclara.get("CNT_TOTBULTOS").toString());
		 
		 BigDecimal pesoDeclara = new BigDecimal(mapCapDeclara.get("CNT_PESOBRUTO_TOTAL").toString());
		 
		 BigDecimal saldoBultos = new BigDecimal(0);
		 BigDecimal saldoPeso = new BigDecimal(0);
		 if(datado!=null){
				totalPesoDatado= datado.getTotalPesoBruto();
				totalBultoDatado = datado.getTotalBulto();
		 }
		 saldoBultos =  manifiesto.getTotalBultos().subtract(totalBultoDatado);
		 saldoPeso   =  manifiesto.getTotalPesoBruto().subtract(totalPesoDatado);
		 
		 if((saldoBultos.compareTo(bultosDeclara)==-1)&&(saldoPeso.compareTo(pesoDeclara)==-1)){
			 return "Los pesos y bultos consignados en la declaraci�n son mayores a los pesos y bultos recibidos del manifiesto";
		 }
		 
		 /*23/10/2014-11:59 fin*/
		 
	}else{
		return "N�mero de manifiesto no existe";
	}
	return "";
}

/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//private List<Manifiesto> obtenerListManifiesto(Map<String, Object> mapaDecla) throws ServiceException{
//	Map<String, Object> paramManifiesto = new HashMap<String, Object>();
//	paramManifiesto.put("numeroManifiesto",SunatStringUtils.lpad(mapaDecla.get("NUM_MANIFIESTO").toString().trim(), 6, ' '));
//	paramManifiesto.put("anioManifiesto", mapaDecla.get("ANN_MANIFIESTO").toString().trim());
//	paramManifiesto.put("codigoAduana", mapaDecla.get("COD_ADUAMANIFIESTO").toString().trim());
//	paramManifiesto.put("codigoTipoManifiesto", mapaDecla.get("COD_TIPMANIFIESTO").toString().trim());
////	paramManifiesto.put("codigoViaTransporte", mapaDecla.get("COD_VIATRANS").toString().trim());
//
//	CabManifiestoDAO cabManifiestoDAO = fabricaDeServicios.getService("manifiesto.manifiestoDAO");
//	List<Manifiesto> listManifiesto = cabManifiestoDAO.listByParameterMap(paramManifiesto);
//	return listManifiesto;
//}
/* PAS20145E220000399 FIN GGRANADOS NO SE USA*/

  /**
 * Metodo que compara los documentos de transportes  con lo declarado en el manifiesto
 * en caso haya algun documento de trasnporte distinto a lo manifestado retorna el documento de
 * transporte que hace la diferencia
 * @param numeroDocumento
 * @param numCorreDoc
 * @return
 */
/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//private String compararDocumentoTrasnporte(String numeroDocumento,String numCorreDoc){
//	List<Map<String, Object>> listaDocumentoTransporte = soporteService.getListDocTransporteDua(numCorreDoc);
//	for (Map<String, Object> map : listaDocumentoTransporte) {
//			if(!map.get("NUM_DOCTRANSP").equals(numeroDocumento)){
//				return map.get("NUM_DOCTRANSP").toString();
//			}
//	}
//	return numCorreDoc;
//}
/* PAS20145E220000399 FIN GGRANADOS NO SE USA*/
//</EHR>
  /*RIN13FSW-FIN*/
  /**
   * {@inheritDoc}
   */
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
  public String grabarRectificaManual(Map params) throws ServiceException
  {
//RSERRANOV PAS20165E220200076
    Integer numCorreDocSol = 0;
    Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
    String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
    FechaBean fecActual = new FechaBean();
    String mensaje = "";

    /*INICIO-P34 FSW AFMA*/
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
              + params.get("caduana").toString().trim()));
    /*FIN-P34 FSW AFMA*/
    try
    {

      Map<String, Object> mapBusqDiligenciaOficio = new HashMap<String, Object>();
      mapBusqDiligenciaOficio.put("numcorredoc", declaracion.get("NUM_CORREDOC"));
      mapBusqDiligenciaOficio.put("codtipdiligencia", mapDilig.get("COD_TIPDILIGENCIA"));

      numCorreDocSol = cabDiligenciaDAO.ultimoNumCorreDocSol(mapBusqDiligenciaOficio);
      mapDilig.put("NUM_CORREDOC_SOL", numCorreDocSol);
      mapDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

      if (mapDilig.get("FEC_DILIGENCIA") == null)
      {
        mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
      }

      // Mapeamos los datos para la rectificacion de oficio
      Map keyDilig = new HashMap();
      keyDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      keyDilig.put("COD_TIPDILIGENCIA", mapDilig.get("COD_TIPDILIGENCIA"));

      mapDilig.put("dataOriginal", null);
      mapDilig.put("clave", keyDilig);

       /*INICIO-P34 FSW AFMA*/
        mapDilig.put("LIQSOL", params.get("cb_liqsol"));
        mapDilig.put("LIQDOL", params.get("cb_liqdol"));
       /*FIN-P34 FSW AFMA*/

        
      //RSERRANOV PAS20165E220200076 porque aqui no grabo nada aun en bd, PASE 69
	    if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)||Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO.equals(tipDilig)) {
	    	
	    	List<Map<String, String>> lstValidacion = procesarGrabaContingente(params, tipDilig);
	    	if (!CollectionUtils.isEmpty(lstValidacion)) {
	            for (Map<String, String> mapDatos : lstValidacion)
	            {
	              if (mapDatos.get("codError").toString().trim().equals("XXXX")) { 
	            	  mensaje = mapDatos.get("desError").toString().trim();
	            	  break;
	              }
	            } 
	    	}
	    	
	    	//Inicio por PAS20181U220200022
	        boolean vaIndicadorImpFrecuente = false; 
	   	 	GrabarFormatoAService grabarFormatoAService = (GrabarFormatoAService)fabricaDeServicios.getService("grabarFormatoAService");
	   	 	String numCorreDoc = declaracion.get("NUM_CORREDOC").toString(); 
	   	 	
	   	 	List<Map<String, Object>> listDeclaracion = (ArrayList<Map<String, Object>>)params.get("lstDetDeclaraActual");
	   	 	boolean tieneMargenYTPI = false;
	   	 	
	   	 	for(Map<String, Object> serie : listDeclaracion){
	   	 		 
	   	 		if(tieneMargenYTPI)break;
	   	 		
	   	 		 if(serie.get("COD_TIPMARGEN")!=null && serie.get("IND_DEL")!=null && serie.get("IND_DEL").toString().equals("0")){
	   	 			List<Map<String, Object>> convenios  = (List<Map<String, Object>>) serie.get("lstConvenioSerie");
	   	 			for(Map datoSerie :  convenios){
	   	 				if(datoSerie.get("COD_CONVENIO")!=null && datoSerie.get("IND_DEL")!=null && datoSerie.get("IND_DEL").toString().equals("0")){
	   	 					tieneMargenYTPI = true;
	   	 					break;
	   	 				}
	   	 			}
	   	 		 } 
	   	 	}  
	   	 	//fin por PAS20181U220200022
	   	 	
			Map<String, Object> MapaModImporFrec =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat("380", "0034",(Date) declaracion.get("FEC_DECLARACION"));
			if (!CollectionUtils.isEmpty(MapaModImporFrec)){
	    		String tipoDocum = "";
		          String numeDocum = "";
		          boolean indImpFrecuente = false;
				    Map<String, Object> paramsParticipante = new HashMap<String, Object>();
				    paramsParticipante.put("numeroCorrelativo", declaracion.get("NUM_CORREDOC"));
				    paramsParticipante.put("codTipoParticipante",   ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		    	  List<Participante> listConsignatario = participanteService.obtenerParticipanteByParameterMap(paramsParticipante);
		    	  if(listConsignatario != null && !listConsignatario.isEmpty()) {
		    		tipoDocum = listConsignatario.get(0).getTipoDocumentoIdentidad().getCodDatacat().toString();
		    		 numeDocum = listConsignatario.get(0).getNumeroDocumentoIdentidad();
		    	  }
                  /*if(((pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isImportadorFrecuente(declaracion.get("COD_REGIMEN").toString() , tipoDocum, numeDocum)){
		          	indImpFrecuente = true;
		          } else {
		        	  Map<String, Object> MapaInvitadoOEA = catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numeDocum,(Date) declaracion.get("FEC_DECLARACION"));
		    			if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
		    				indImpFrecuente = true;
		    			}
		          } 
		    		Map<String,Object> mapIndicadoresDUA=new HashMap<String, Object>();
		    		mapIndicadoresDUA.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
		    		mapIndicadoresDUA.put("cod_indicador", "05");
		    		int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(mapIndicadoresDUA).get("CANT")).intValue();
		          if (indImpFrecuente && declaracion.get("COD_MODALIDAD").toString().trim().equals( ConstantesDataCatalogo.MODA_ANTICIPADA ) ) {
		    			if(existeIndicador==0){
		    	            mapIndicadoresDUA.put("numCorredoc", declaracion.get("NUM_CORREDOC"));
		    	            mapIndicadoresDUA.put("codIndicador", "05");
		    				mapIndicadoresDUA.put("codTiporegistro", "A");
		    				indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
		    			}	
		    		}else {
		    			if(existeIndicador > 0){
		    	            mapIndicadoresDUA.put("numCorredoc", declaracion.get("NUM_CORREDOC"));
		    	            mapIndicadoresDUA.put("codIndicador", "05");
		    				mapIndicadoresDUA.put("codTiporegistro", "A");
		    				mapIndicadoresDUA.put("indActivo", "0");
		    				indicadorDUADAO.update(mapIndicadoresDUA);
		    			}								
		    		}*/
		    	//R1804: ATRG201802 PAS20181U220200022 Los beneficios del importador frecuente se aplican solo cuando se numera una 
					//declaraci�n de modalidad anticipada de los reg�menes 10,20,21,
					//o modalidad de despacho urgente o diferido del r�gimen 10 sujeta a una cuota o contingente arancelario.   			 
		  			String codregimen =   declaracion.get("COD_REGIMEN").toString(); 
		  			String codModalidad =  declaracion.get("COD_MODALIDAD").toString();  
		  			vaIndicadorImpFrecuente = grabarFormatoAService.esImportadorFrecuenteNuevasCondiciones(codregimen, tipoDocum, numeDocum, codModalidad, null, tieneMargenYTPI);
		  	 		
				}
		       grabarFormatoAService.actualizarIndicadorImportadorFrecuente(new Long(numCorreDoc), vaIndicadorImpFrecuente) ;
	    }
        //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
        
      try
      { 
           this.cabDiligenciaDAO.insert(mapDilig);
      }
      catch (Exception e)
      {
        log.info("***VERIFICAR***", e);
        log.info("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:" + SojoUtil.toJson(mapDilig));
        this.cabDiligenciaDAO.update(mapDilig);
      }

      this.actualizarParticipantes(params, numCorreDocSol, Constantes.MODULO_RECTIFICACION_OFICIO);

      /*INICIO-P34 FSW AFMA*/
        insertarPlazoProceso(declaracion, fecActual, tipDilig,numCorreDocSol);

        Map<String, Object> paramsBajaIndicador =new HashMap<String, Object>();
        paramsBajaIndicador.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
        paramsBajaIndicador.put("COD_INDICADOR", Constantes.INDICADOR_RECTIFICACION_OFICIO_EN_PROCESO);
        paramsBajaIndicador.put("IND_ACTIVO", Constantes.INDICADOR_DUA_INACTIVO);
        indicadorDUADAO.updateByPrimaryKeySelective(paramsBajaIndicador);
      /*FIN-P34 FSW AFMA*/
      Map declaracionAnt = (HashMap) params.get("mapCabDeclara");

      // Obtenemos los registros que relacionan las series con los items
      Map fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      List lstSeriesItem = this.seriesItemDAO.select(fbKeys);
      params.put("lstSeriesItem", lstSeriesItem);

      // **************Actualizamos la DECLARACION********************//
      declaracion.put("FEC_MODIF", fecActual.getTimestamp());

      // **************fin Actualizamos la DECLARACION********************//

      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", "");

      /* Retirar campos que no son modificables */
      if (declaracion.containsKey("FEC_DECLARACION"))
        declaracionAnt.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));
      if (declaracion.containsKey("FEC_REGIS"))
        declaracion.remove("FEC_REGIS");
      if (declaracionAnt.containsKey("FEC_REGIS"))
        declaracionAnt.remove("FEC_REGIS");
      if (declaracion.containsKey("FEC_MODIF"))
        declaracion.remove("FEC_MODIF");
      if (declaracionAnt.containsKey("FEC_MODIF"))
        declaracionAnt.remove("FEC_MODIF");

      Map<String, Object> mapDiferencias =
                                           soporteComparadorService.comparaMap(declaracion, declaracionAnt,
                                                                               EnumTablaModel.CAB_DECLARA);

      if (soporteComparadorService.esDataCambiada(mapDiferencias))
      {
        this.cabDeclaraDAO.update(mapDiferencias);
        this.registrarRectiOficio(mapDiferencias, tipDilig,
                                  new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0051", numCorreDocSol);
      }

      if (declaracion.get("COD_FERIA") != null && !"".equals(declaracion.get("COD_FERIA").toString().trim()))
      {
        if ((declaracionAnt.get("COD_FERIA") == null)
            || (declaracionAnt.get("COD_FERIA") != null && !declaracionAnt.get("COD_FERIA")
                                                                          .toString()
                                                                          .trim()
                                                                          .equals(
                                                                                  declaracion.get("COD_FERIA")
                                                                                             .toString().trim())))
        {

          Map keyAdmTemp = new HashMap();
          keyAdmTemp.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

          Map mapAdmTempDO = new HashMap();
          mapAdmTempDO.put("COD_FERIA", declaracionAnt.get("COD_FERIA"));

          Map mapAdmTempDif = new HashMap();
          mapAdmTempDif.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
          mapAdmTempDif.put("COD_FERIA", declaracion.get("COD_FERIA"));

          mapAdmTempDif.put("dataOriginal", mapAdmTempDO);
          mapAdmTempDif.put("clave", keyAdmTemp);
          if (declaracionAnt.get("COD_FERIA") == null)
          {
            this.cabAdiAdmTemDAO.insert(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
          }
          else
          {
            this.cabAdiAdmTemDAO.update(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
          }
          // como no usa el nuevo comparador se pone manualmente caso
          // excepcional
          Map nuevo = new HashMap();
          nuevo.put("COD_FERIA", declaracion.get("COD_FERIA"));
          mapAdmTempDif.put("dataModificados", nuevo);
          this.registrarRectiOficio(mapAdmTempDif, tipDilig,
                                    new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0047",
                                    numCorreDocSol);

        }
      }

      //inicio CU 14.21
      if(declaracion.get("IND_FORMBPROVEEDOR").toString().equals("0")){
    	  this.insertarItemFacturaDeclaracion(params, numCorreDocSol, tipDilig);
      }
      //fin 14.21
      this.actualizarSeries(params, numCorreDocSol);

      List<Map<String, Object>> lstDetAutorizacionActual = (List) declaracion.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDetAutorizacion = (List) declaracionAnt.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDocAutAsociadoActual = (List) declaracion.get("lstDocAutAsociado");
      List<Map<String, Object>> lstDocAutAsociado = (List) declaracionAnt.get("lstDocAutAsociado");
      List<Map<String, Object>> lstCabCertiOrigenActual = (List) declaracion.get("lstCabCertiOrigen");
      List<Map<String, Object>> lstCabCertiOrigen = (List) declaracionAnt.get("lstCabCertiOrigen");
      // actualizacion de documentos asociados a la serie

      // Debe existir un registro para actualizar o algun nuevo
      //Inicio RIN 14
      Comparador comp = new Comparador();
      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", "");
      fbKeys.put("COD_TIPOPER", "");
      fbKeys.put("NUM_SECDOC", "");
      List<Map<String, Object>> lstDiferDocAut = comp.comparaList(lstDocAutAsociado, lstDocAutAsociadoActual, fbKeys);
      //Fin RIN 14
      if (!CollectionUtils.isEmpty(lstDiferDocAut))
      {
        // Documentos asociados
        Map<String, Object> mapKeyAsoc = new HashMap<String, Object>();
        Map<String, Object> mapDifAsoc = new HashMap<String, Object>();
        for (Map<String, Object> mapAsoc : lstDocAutAsociadoActual)
        {
          Map<String, Object> mapAsocAntes = new HashMap<String, Object>();

        //pase 153          
//          if (mapAsoc.get("COD_TIPDOC").equals(""))
//          mapAsoc.put("COD_TIPDOC", " ");
//          if (mapAsoc.get("COD_IDENT").equals(""))
//          mapAsoc.put("COD_IDENT", " ");
//          if (mapAsoc.get("OBS_OBS").equals(""))
//              mapAsoc.put("OBS_OBS", " ");
//cambio de pablito
            if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "COD_TIPDOC"))
          mapAsoc.put("COD_TIPDOC", " "); 
            if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "COD_IDENT"))
          mapAsoc.put("COD_IDENT", " ");
            if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "OBS_OBS"))
              mapAsoc.put("OBS_OBS", " ");
            if (MapUtils.esValorMapaNuloOVacio(mapAsoc, "NUM_DOC"))//adicionado por PAS20155E220200192
                mapAsoc.put("NUM_DOC", " "); 
           //pase 153
            Long numeroCorrelativo = Utilidades.toLong(declaracion.get("NUM_CORREDOC")); //RIN-13
            mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
            mapKeyAsoc.put("NUM_SECDOC", mapAsoc.get("NUM_SECDOC"));
            mapKeyAsoc.put("COD_TIPOPER", mapAsoc.get("COD_TIPOPER"));
            mapKeyAsoc.put("COD_TIPDOC", mapAsoc.get("COD_TIPDOC"));

           //pase 153
          mapAsocAntes = Utilidades.obtenerElemento(lstDocAutAsociado, mapKeyAsoc);
          if (CollectionUtils.isEmpty(mapAsocAntes))
          {
            if ("0".equals(mapAsoc.get("IND_DEL").toString()))
            {
              docAutAsociadoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAsoc));
              // nuevo
              mapDiferencias =
                               soporteComparadorService.comparaMap(mapAsoc, new HashMap(),
                                                                   EnumTablaModel.DOCAUT_ASOCIADO);

              if (soporteComparadorService.esDataCambiada(mapDiferencias))
              {
                this.registrarRectiOficio(mapDiferencias, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString()
                                                                                        .trim()),
                                          Constantes.COD_TABLA_DOCAUT_ASOCIADO, numCorreDocSol);
              }
              //Inicio RIN 14
              mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            		  ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, Constants.IND_REGISTRO_NUEVO);
			  //Fin RIN 14
            }
          }
          else
          {
            // ya existe en documentos asociados
            mapDifAsoc = soporteComparadorService.comparaMap(mapAsoc, mapAsocAntes, EnumTablaModel.DOCAUT_ASOCIADO);
            if (soporteComparadorService.esDataCambiada(mapDifAsoc))
            {
              //Inicio RIN 14
              if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                    
            	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
            	    Constants.IND_REGISTRO_ANULADO);

              }
              //Fin RIN 14
              docAutAsociadoDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
              this.registrarRectiOficio(mapDifAsoc, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString()
                                                                                  .trim()),
                                        Constantes.COD_TABLA_DOCAUT_ASOCIADO, numCorreDocSol);
              //Inicio RIN 14
              if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                  
          	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
          	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
          	    Constants.IND_REGISTRO_NUEVO);

              } else {
	
	          	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
	          	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc,  
	          	      Constants.IND_REGISTRO_ANULADO);
	
              }
              //Fin RIN 14
            }
          }
          // limpiamos maps
          mapDifAsoc.clear();
          mapKeyAsoc.clear();
        }

        //inicio PAS20181U220200056
        String nroTransaccion = tipDilig;
  	  	// No se debe madar el tipo de diligencia sino la transacci�n
  	  	if (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig) )
        {
  		  nroTransaccion = Constantes.DILIG_DESPACHO ;
  	    }
  	  	//fin PAS20181U220200056
        // Certificados
        if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual))
        {
          for (Map<String, Object> mapCerti : lstCabCertiOrigenActual)
          {
            Map<String, Object> mapCertiAntes = new HashMap<String, Object>();

            mapKeyAsoc.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
            mapKeyAsoc.put("NUM_SECDOC", mapCerti.get("NUM_SECDOC"));
            mapKeyAsoc.put("COD_TIPOPER", mapCerti.get("COD_TIPOPER"));

            mapCertiAntes = Utilidades.obtenerElemento(lstCabCertiOrigen, mapKeyAsoc);
            if (CollectionUtils.isEmpty(mapCertiAntes))
            {
              if ("0".equals(mapCerti.get("IND_DEL").toString()))
              {
                cabCertiOrigenDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapCerti));

                // nuevo
                mapDiferencias =
                                 soporteComparadorService.comparaMap(mapCerti, new HashMap(),
                                                                     EnumTablaModel.CAB_CERTIORIGEN);
                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, new Long(declaracion.get("NUM_CORREDOC")
                                                                                          .toString().trim()),
                                            Constantes.COD_TABLA_CAB_CERTIORIGEN, numCorreDocSol);
                  
                  //invocar PAS20181U220200056
                  String codTransaccion = "";
                  if(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)){
                  	codTransaccion = "1007";
                  }else if(Constantes.DILIG_DESPACHO.equals(nroTransaccion)){
                  	codTransaccion = "1006";
                  }
                  if(!codTransaccion.isEmpty()){	 
                  	registroUsoCertificadoOrigenElectronico(mapCerti , declaracion, codTransaccion);
                  }
                }
              }
            }
            else
            {
              // ya existe en documentos asociados
              mapDifAsoc = soporteComparadorService.comparaMap(mapCerti, mapCertiAntes, EnumTablaModel.CAB_CERTIORIGEN);
              if (soporteComparadorService.esDataCambiada(mapDifAsoc))
              {
                cabCertiOrigenDAO.update(mapDifAsoc);
                this.registrarRectiOficio(mapDifAsoc, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString()
                                                                                    .trim()),
                                          Constantes.COD_TABLA_CAB_CERTIORIGEN, numCorreDocSol);
               //invocar PAS20181U220200056
               String codTransaccion = "";
               if(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig)){
            	   codTransaccion = "1007";
               }else if(Constantes.DILIG_DESPACHO.equals(nroTransaccion)){
              		codTransaccion = "1006";
				}
               if(!codTransaccion.isEmpty()){	 
                   	registroUsoCertificadoOrigenElectronico(mapCerti , declaracion, codTransaccion);
               }                                      
              }
            }
            // limpiamos maps
            mapDifAsoc.clear();
            mapKeyAsoc.clear();
          }
        }
        // Autorizantes
        //Inicio RIN 14
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", "");
        fbKeys.put("COD_TIPOPER", "");
        fbKeys.put("NUM_SECDOC", "");
        fbKeys.put("NUM_SECSERIE", "");
        List<Map<String, Object>> lstDiferDetAut = comp.comparaList(lstDetAutorizacion, lstDetAutorizacionActual, fbKeys);
        //Fin RIN 14
        if (!CollectionUtils.isEmpty(lstDiferDetAut))
        {
          for (Map<String, Object> mapAut : lstDetAutorizacionActual)
          {
            Map<String, Object> mapAutAntes = new HashMap<String, Object>();

            mapKeyAsoc.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
            mapKeyAsoc.put("NUM_SECDOC", mapAut.get("NUM_SECDOC"));
            mapKeyAsoc.put("COD_TIPOPER", mapAut.get("COD_TIPOPER"));
            mapKeyAsoc.put("NUM_SECSERIE", mapAut.get("NUM_SECSERIE"));

            mapAutAntes = Utilidades.obtenerElemento(lstDetAutorizacion, mapKeyAsoc);
            if (CollectionUtils.isEmpty(mapAutAntes))
            {
              if ("0".equals(mapAut.get("IND_DEL").toString()))
              {
                detAutorizacionDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAut));

                // ya existe en documentos asociados
                Map mapDiferencia =
                                    soporteComparadorService.comparaMap(mapAut, new HashMap(),
                                                                        EnumTablaModel.DET_AUTORIZACION);
                if (soporteComparadorService.esDataCambiada(mapDiferencia))
                {
                  this.registrarRectiOficio(mapDiferencia, tipDilig, new Long(declaracion.get("NUM_CORREDOC")
                                                                                         .toString().trim()),
                                            Constantes.COD_TABLA_DET_AUTORIZACION, numCorreDocSol);
                  //Inicio RIN 14
                  mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                		  ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                		   Constants.IND_REGISTRO_NUEVO);
                  //Fin RIN 14
                }
              }
            }
            else
            {
              // ya existe en documentos asociados
              mapDifAsoc = soporteComparadorService.comparaMap(mapAut, mapAutAntes, EnumTablaModel.DET_AUTORIZACION);
              if (soporteComparadorService.esDataCambiada(mapDifAsoc))
              {
            	 //Inicio RIN 14
            	 if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){       
                      
                	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                	    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                	    Constants.IND_REGISTRO_ANULADO);

                 }
                 //Fin RIN 14
                detAutorizacionDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
                this.registrarRectiOficio(mapDifAsoc, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString()
                                                                                    .trim()),
                                          Constantes.COD_TABLA_DET_AUTORIZACION, numCorreDocSol);
                  //Inicio RIN 14
                  if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){
                    
                    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                    Constants.IND_REGISTRO_NUEVO);

                  } else {

                    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut,  
                      Constants.IND_REGISTRO_ANULADO);

                  }
                  //Fin RIN 14
              }
            }
            // limpiamos maps
            mapDifAsoc.clear();
            mapKeyAsoc.clear();
          }
        }
      }
      //Inicio - RIN 14
      List lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
      params.put("tipDilig", tipDilig);
      if (Constantes.COD_TIPO_DILIGENCIA_REGULARIZACION.equals(params.get("tipDilig").toString()))
      {
      Map prmtVal = new HashMap();
      prmtVal.put("mapCabDeclara", declaracion);
      prmtVal.put("lstDetDeclara", lstDetDeclara);
      prmtVal.put("lstDocAutAsociado", lstDocAutAsociadoActual);
      prmtVal.put("lstDetAutorizacion", lstDetAutorizacionActual);
      prmtVal.put("codTransaccion", Constants.COD_TRANSAC_DILIGENCIAREGUL);
      
      Declaracion decla = GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance().transform(prmtVal);
      mercanciaRestringidaEntidadService.actualizarDocAutorizaIQBF(decla, Constants.EST_DOCAUT_CONCLUIDA);
      }
      //Fin - RIN 14

        /*INICIO-P34 FSW AFMA*/


        // Insertamos las incidencias
        List<Incidencia> lstIncidencias2 = (ArrayList<Incidencia>) params.get("lstIncidencias");
        if(!CollectionUtils.isEmpty(lstIncidencias2)) {
            int numItm = 0;
            Map incidencia;
            for(Incidencia incidenciaBean:  lstIncidencias2) {
                numItm += 1;
                incidencia = new HashMap();
                incidencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
                incidencia.put("COD_TIPDILIGENCIA", tipDilig);
                incidencia.put("NUM_SECINCID", "" + numItm);
                incidencia.put("NUM_SERIE", incidenciaBean.getNumeroSerie());
                incidencia.put("COD_INCIDENCIA", incidenciaBean.getCodIncidencia());
                incidencia.put("NUM_CORREDOC_SOL", numCorreDocSol);
                incidenciaService.insert(incidencia);
            }

        }
        /*FIN-P34 FSW AFMA*/

      //PAS20181U220200069 - mtorralba 20190304 - Comparacion de observaciones
      comparaCampoObservacion( Constantes.TIPO_OBSERVACION_DECLA, declaracion, declaracionAnt, tipDilig, numCorreDocSol );
      comparaCampoObservacion( Constantes.TIPO_OBSERVACION_PECOAMAZ, declaracion, declaracionAnt, tipDilig, numCorreDocSol );
      
      // Actualizamos las tablas del Formato B
      Map paramsFB = new HashMap();
      paramsFB.put("lstFormBProveedor", declaracion.get("lstFormBProveedor"));
      paramsFB.put("lstFormBProveedorAnt", declaracionAnt.get("lstFormBProveedor"));
      paramsFB.put("tipDilig", tipDilig);
      paramsFB.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
      this.actualizarFormatoB(paramsFB, numCorreDocSol);//DE DILIGENCIA DE DESPACHO
 /*INICIO-P34 FSW AFMA  se comento pq evita reliquidar ya no sirve este validacion*/
 //INICIO RIN08  ---para rectificacion en caso solo tenga diligencia en aduana de destino
        /*
      Map<String, Object> PkDocu = new HashMap();
      PkDocu.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      PkDocu.put("COD_TIPDILIGENCIA", "22"); //constantes.DILIG_ADUANA_DESTINO
      List <Map<String, Object>>listadoDiligenciaDespacho = diligenciaService.selectDiligencia(PkDocu);
      if (listadoDiligenciaDespacho.size()>0){*/
    	  lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");

	      if (lstDetDeclara != null && lstDetDeclara.size() > 0)
	      {
	        Map mapParamsDilig = new HashMap();
	        mapParamsDilig.put("mapCabDeclaraActual", declaracion);
	        mapParamsDilig.put("mapCabDeclara", declaracionAnt);/*P46-PAS20155E410000032-[jlunah] BUG 24889*/
	        mapParamsDilig.put("tieneCodLiberatorioDonacion", params.containsKey("tieneCodLiberatorioDonacion") ? params.get("tieneCodLiberatorioDonacion") : false);//P46-PAS20155E410000032-[jlunah]
	        mapParamsDilig.put("mapCabDiligenciaActual", mapDilig);
	        //ini P46-PAS20155E410000032
	        mapParamsDilig.put("generacionLCTributo", params.get("generacionLCTributo"));
	       //fin P46-PAS20155E410000032

                /*INICIO-P34 FSW AFMA*/
                   String indicadorSoloGrabadoSinliquidacion = params.get("indicadorSoloGrabadoSinliquidacion").toString();
                /*FIN-P34 FSW AFMA*/
                   
                   /*** Inicio Cambio PAS20155E220200192 RSV **/
                   mapParamsDilig.put("generarLC15_SI_9", params.get("generarLC15_SI_9") == null? "NO" : params.get("generarLC15_NO_9").toString().trim() );
                   mapParamsDilig.put("generarLC15_NO_9", params.get("generarLC15_NO_9") == null? "NO" : params.get("generarLC15_NO_9").toString().trim() );
                   /*** Fin Cambio PAS20155E220200192 RSV **/
                   
                if (!Constantes.REGIMEN_70_DEPOSITO.equals((String) declaracion.get("COD_REGIMEN")) && "N".equals(indicadorSoloGrabadoSinliquidacion)) {
                	
                	/*inicio P46-PAS20155E410000032-[jlunah]*/
//                	ValTratamientoDonacionService valTratamientoDonacion = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");
//                	Declaracion declaracionBean = new Declaracion();
//                	DUA dua = new DUA();
//                	declaracionBean.setDua(dua);
//                	declaracionBean.setCodaduana(declaracion.get("COD_ADUANA").toString());
//                	declaracionBean.getDua().setAnnpresen(Integer.parseInt(declaracion.get("ANN_PRESEN").toString()));//ES BIGDECIMAL
//                	declaracionBean.getDua().setCodregimen(declaracion.get("COD_REGIMEN").toString());
//                	declaracionBean.setNumeroDeclaracion(new Long(declaracion.get("NUM_DECLARACION").toString()));//ES BIGDECIMAL
//                	declaracionBean.getDua().setCodCanal(declaracion.get("COD_CANAL").toString());
                	
                	boolean declaracionEstaCanceladaDonacion =  declaracion.get("COD_CANAL") != null ? !declaracion.get("COD_CANAL").toString().trim().equals("") : false;   //valTratamientoDonacion.declaracionEstaCancelada(declaracionBean);
                	mapParamsDilig.put("declaracionEstaCanceladaDonacion", declaracionEstaCanceladaDonacion);
                	/*fin P46-PAS20155E410000032-[jlunah]*/
                	
                    this.liquidaDeclaracionService.grabaLiqDiligencia(mapParamsDilig);
                    params.put("mensaje", mapParamsDilig.get("mensaje"));
                }
            }
        /*}*/
 //FIN RIN08
 /*FIN-P34 FSW AFMA*/
	           
      //ini P46-PAS20155E410000032
      //se coloca despues de la liquidacion para poder obtener el indicador inicial de BD
      agregaOactualizaIndicadorDonacion(declaracion, declaracionAnt, tipDilig, numCorreDocSol);//P46-PAS20155E410000032-[jlunah] BUG 25285
      
      if(declaracion.get("registrarCodLibeDonacion") != null
    		  && (Boolean)declaracion.get("registrarCodLibeDonacion")
    		  && !liquidaDeclaracionService.declaracionTieneIndicadorImpugnacionDonacion(declaracion)
    		  && liquidaDeclaracionService.declaracionTieneIndicadorImpugnacionDonacion(declaracionAnt)) {
    	  Map<String, Object> mapCabAdiImpoconsu = new HashMap<String, Object>();
    	  mapCabAdiImpoconsu.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
    	  
    	  CabAdiImpoConsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("diligencia.rectificacion.cabAdiImpoConsuDef_xa");
    	  
    	  boolean existeCabAdiImpoconsu = !CollectionUtils.isEmpty(cabAdiImpoconsuDAO.select(mapCabAdiImpoconsu));
    	  
    	  mapCabAdiImpoconsu.put("FEC_REGULARIZACION", SunatDateUtils.getCurrentDate());
    	  if(existeCabAdiImpoconsu) {
    		  cabAdiImpoconsuDAO.update(mapCabAdiImpoconsu);
    	  } else {
    		  cabAdiImpoconsuDAO.insertMapSelective(mapCabAdiImpoconsu);
    	  }
	
    	  notificarBuzonSolReguDonacion(declaracion);
      }
      //fin P46-PAS20155E410000032
      
      // borra fisicamente los registros graabdos temporalmente
      String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();
      rectificacionOficioService.borrarDatosTMP(numCorreDoc);
      
      /***** GGRANADOS RIN16PASE3 INI *****/
		//DeclaracionService declaracionService =  (DeclaracionService)fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
	    Map<String, Object> datosCambioModalidad = declaracionService.getDatosParaEvaluarCambioModalidad(params);
	      
	    String cambiaModalidad = declaracionService.procesarCambioModalidadRegularizacion(
	    		  (String)datosCambioModalidad.get("codModalidad"),
	    		  (String)datosCambioModalidad.get("codModalidadActual"),
	    		  (Boolean)datosCambioModalidad.get("tieneIndicadorRegularizable"),
	    		  (Boolean)datosCambioModalidad.get("tieneIndicadorRegularizableActual"));
	    
	    if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_REGULARIZABLE)){
	    	DUA dua = new DUA();
	    	dua.setNumcorredoc(Long.parseLong(declaracion.get("NUM_CORREDOC").toString()));
	    	dua.setCodaduanaorden(declaracion.get("COD_ADUANA").toString());
	    	DatoManifiesto datoManifiesto = new DatoManifiesto();
	    	datoManifiesto.setNummanif(declaracion.get("NUM_MANIFIESTO").toString());
	    	datoManifiesto.setAnnmanif(declaracion.get("ANN_MANIFIESTO").toString());
	    	datoManifiesto.setCodaduamanif(declaracion.get("COD_ADUAMANIFIESTO").toString());
	    	datoManifiesto.setCodtipomanif(declaracion.get("COD_TIPMANIFIESTO").toString());
	    	datoManifiesto.setCodmodtransp(declaracion.get("COD_VIATRANS").toString());
	    	dua.setManifiesto(datoManifiesto);
	        declaracionService.actualizarDatosRegularizacion(dua);
	    }else if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_NO_REGULARIZABLE)){
	    	declaracionService.limpiarDatosRegularizacion(Long.parseLong(declaracion.get("NUM_CORREDOC").toString()));
	    }
	      /***** GGRANADOS RIN16PASE3 FIN *****/
		  


            /*INICIO-P34 FSW AFMA*/
            Long numCorreDocDua = Long.parseLong(declaracion.get("NUM_CORREDOC").toString());
            String codFuncionario = mapDilig.get("COD_FUNCIONARIO").toString();
             EspeDocu asignacionOficio = new EspeDocu();
            asignacionOficio.setNumCorreDoc(numCorreDocDua);
            asignacionOficio.setCodFuncionario(codFuncionario);
            asignacionOficio.setCodEstRev(ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
            asignacionOficio.setCodProcesoAsignar(Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);
		    asignacionOficio.setCodProcesoAsignar(Constantes.COD_TIPO_DILIGENCIA_CULMINACION_PECO);
            if(tieneAsignacionDeOficio(asignacionOficio)){

                //Retira la Declaraci�n de la bandeja de pendientes del funcionario
                Map<String, Object> paramsAsignacion = new HashMap<String, Object>();
                paramsAsignacion.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_CON_REGISTRO_DE_LA_DILIGENCIA);
                paramsAsignacion.put("num_corredoc", numCorreDocDua);
                paramsAsignacion.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
                paramsAsignacion.put("fec_termrev", "fec_termrev");
                paramsAsignacion.put("cod_funcionario", codFuncionario);
                asignacionService.actualizarEstadoRevision(paramsAsignacion);
                //P34-PAS20155E220200067 inicio bug 23991
                Map<String, Object> paramsAsigNumCorredocSol = new HashMap<String, Object>();
                paramsAsigNumCorredocSol.put("num_corredoc", numCorreDocDua);
                paramsAsigNumCorredocSol.put("cod_procesoasig", Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO);
                paramsAsigNumCorredocSol.put("num_corredoc_sol", numCorreDocSol);
                asignacionService.actualizarNumeroCorrelativoSol(paramsAsigNumCorredocSol);
                //P34-PAS20155E220200067 fin
                
            }

            /*FIN-P34 FSW AFMA*/

}
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Ha ocurrido un error al inserta los datos");
    }
    catch (Throwable e)
    {
      log.error("grabarRectificacionOficio-ERROR: ", e);
      throw new ServiceException(this,
                                 "Ha ocurrido un error inseperado en el metodo de grabado de la rectificacion de oficio");
    }
    return  mensaje;
  }

  //ini P46-PAS20155E410000032
  /**
   * Metodo que permite enviar la notificacion al buzon SOL del Consignatario y de la Agencia de Aduana
   * en caso se trate de una regularizacion de donacion
   */
  private void notificarBuzonSolReguDonacion(Map<String, Object> declaracion) {
	  PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
	  ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
	  
	  FechaBean fechaPublicacion = new FechaBean();
	  FechaBean fechaVigencia = new FechaBean("31/12/9999");
	  String codTipoNotificacion = "1";
	  Integer codPlantillaNotificacionConsignatarioAgenteAduana = 275;
	  
	  Map<String,Object> params = new HashMap<String, Object>();
	  params.put("numeroCorrelativo", declaracion.get("NUM_CORREDOC"));
	  
	  String tipElaborado;
	  if(declaracion.get("COD_ADUANA").toString().trim().equalsIgnoreCase(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO)) {
		  tipElaborado = SunatStringUtils.quitarCaracteresEspeciales("Divisi�n de Importaci�n de la IAMC");//Corresponde a la Divisi�n de Importaci�n de la IAMC (Aduana 118)
	  } else {
		  tipElaborado = SunatStringUtils.quitarCaracteresEspeciales("Departamento de T�cnica Aduanera");//Corresponde al Departamento de T�cnica Aduanera
	  }
	  
	  Map<String, Object> mapMensaje = new HashMap<String, Object>();
	  mapMensaje.put("des_asunto", "Declaraci�n de donaci�n regularizada");
	  mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).append("/").append(fechaPublicacion.getMes()).append("/").append(fechaPublicacion.getAnho()).toString());
	  mapMensaje.put("cod_aduana", declaracion.get("COD_ADUANA").toString().trim());
	  mapMensaje.put("ann_presen", declaracion.get("ANN_PRESEN").toString().trim());
	  mapMensaje.put("cod_regimen", declaracion.get("COD_REGIMEN").toString().trim());
	  mapMensaje.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString().trim());
	  mapMensaje.put("tip_elaborado", tipElaborado);
	  mapMensaje.put("tip_usuario", ConstantesDataCatalogo.COD_TIPO_USUARIO_CONTRIBUYENTE);
	  
	  /*CONSIGNATARIO*/
	  params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
	  List<Participante> listConsignatario = participanteService.obtenerParticipanteByParameterMap(params);
	  
	  if(listConsignatario != null && !listConsignatario.isEmpty()) {
		  //mapMensaje.put("nombre_destinatario", "Srs. Due&ntilde;o o Consignatario: " + listConsignatario.get(0).getNombreRazonSocial());
		  mapMensaje.put("nombre_destinatario", "Srs. " + listConsignatario.get(0).getNombreRazonSocial());//PAS20155E410000032-INSI-Cambio por observacion de normativa
		  mapMensaje.put("cod_usuario", new String[] { listConsignatario.get(0).getNumeroDocumentoIdentidad() });
		  
		  StringBuffer dataConsignatario = new StringBuffer(SojoUtil.toJson(mapMensaje));
		  publicacionAvisoService.insert(codPlantillaNotificacionConsignatarioAgenteAduana, dataConsignatario, codTipoNotificacion, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	  }
	  
	  /*AGENTE ADUANERO*/
	  params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA);
	  List<Participante> listAgenteAdua = participanteService.obtenerParticipanteByParameterMap(params);
	  
	  if(listAgenteAdua != null && !listAgenteAdua.isEmpty()) {
		  //mapMensaje.put("nombre_destinatario", "Srs. Agencia de Aduana: " + listAgenteAdua.get(0).getNombreRazonSocial());
		  mapMensaje.put("nombre_destinatario", "Srs. " + listAgenteAdua.get(0).getNombreRazonSocial());//PAS20155E410000032-INSI-Cambio por observacion de normativa
		  mapMensaje.put("cod_usuario", new String[] { listAgenteAdua.get(0).getNumeroDocumentoIdentidad() });
		  
		  StringBuffer dataAgenteAduanero = new StringBuffer(SojoUtil.toJson(mapMensaje));
		  publicacionAvisoService.insert(codPlantillaNotificacionConsignatarioAgenteAduana, dataAgenteAduanero, codTipoNotificacion, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	  }
  }
  //fin P46-PAS20155E410000032
  
  //P34 AFMA
 private void insertarPlazoProceso(Map declaracion, FechaBean fecActual,
		String tipDilig, Integer numCorreDocSol) {

	

	    // Insertamos el registro de plazos
	    Map mapPlazo = (HashMap) declaracion.get("mapPlazosProceso");
	    if (!MapUtils.esMapaNuloOVacio(mapPlazo))
	    {
	      mapPlazo.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
	      mapPlazo.put("COD_TIPPLZ", Constantes.TIPO_PLAZO_PRESENTADO);
	      mapPlazo.put("FEC_INICIO", declaracion.get("FEC_DECLARACION"));

	      if (mapPlazo.get("FEC_FIN").getClass().getName().equals(fecActual.getClass().getName()))
	      {
	        mapPlazo.put("FEC_FIN", ((FechaBean) mapPlazo.get("FEC_FIN")).getTimestamp());
	      }

	      try
	      {
	        this.plazosProcesoDAO.insert(mapPlazo);
	      }
	      catch (Exception e)
	      {
	      }

	      // Mapeamos los datos para la rectificacion de oficio
	      Map keyPlazo = new HashMap();
	      keyPlazo.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
	      keyPlazo.put("COD_TIPPLZ", mapPlazo.get("COD_TIPPLZ"));
	      keyPlazo.put("FEC_INICIO", mapPlazo.get("FEC_INICIO"));

	      mapPlazo.put("dataOriginal", null);
	      mapPlazo.put("clave", keyPlazo);
	      this.registrarRectiOficio(
	                                mapPlazo,
	                                tipDilig,
	                                new Long(declaracion.get("NUM_CORREDOC").toString().trim()),	                                
	                                Constantes.COD_TABLA_PLAZOS_PROCESO,numCorreDocSol);
	    }
	  
	 
}

/*INICIO-P34 FSW AFMA*/
    private boolean tieneAsignacionDeOficio(EspeDocu asignacionOficio)
    {

        Map params = new HashMap();
        params.put("NUM_CORREDOC", asignacionOficio.getNumCorreDoc());
        params.put("COD_ESTREV", asignacionOficio.getCodEstRev());
        params.put("COD_FUNCIONARIO",asignacionOficio.getCodFuncionario());
        params.put("COD_PROCESOASIG",asignacionOficio.getCodProcesoAsignar());
        Map mapEspeDocu =  espeDocuDAO.findbyDocEstRev(params);


        return !CollectionUtils.isEmpty(mapEspeDocu)?true:false;

    }
 /*FIN-P34 FSW AFMA*/
  /**
   * Permite registrar en RectiOficio
   *
   * @param mapRectif
   * @param tipDilig
   * @param numCorredoc
   * @param codTabla
   */
  private void registrarRectiOficio(Map<String, Object> mapRectif,
                                    String tipDilig,
                                    Long numCorredoc,
                                    String codTabla,
                                    Integer numCorreDocSol)
  {

    grabarRectiOficio(mapRectif, EnumTablaModel.getEnumTablaModelPorCodigoTabla(codTabla), numCorredoc.toString(),
                      tipDilig, numCorreDocSol);

  }

  private void grabarRectiOficio(Map<String, Object> mapDatosModificados, EnumTablaModel enumTablaModel,
                                 String numCorreDoc, String codTipDiligencia, Integer numCorreDocSol)
  {

    if (!CollectionUtils.isEmpty(mapDatosModificados)
        && !CollectionUtils.isEmpty((Map<String, Object>) mapDatosModificados.get("dataModificados")))
    {

      Map<String, Object> mapDatos = new HashMap<String, Object>();

      mapDatos.put("NUM_CORREDOC", numCorreDoc);
      mapDatos.put("COD_TIPDILIGENCIA", codTipDiligencia);
      mapDatos.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
      mapDatos.put("COD_TABLA", enumTablaModel.getCodTabla().toString());
      mapDatos.put("NUM_CORREDOC_SOL", numCorreDocSol);
      mapDatos.put("DES_CLAVE", SojoUtil.toJson(mapDatosModificados.get("clave")));

      Map<String, Object> dataModificados = (Map) mapDatosModificados.get("dataModificados");
      for (Entry<String, Object> campo : dataModificados.entrySet())
      {
        String nombreCampo = campo.getKey();
        String preficoFecha = "FEC_";
        if (nombreCampo.startsWith(preficoFecha))
        {
          String fechaConFormato = SunatDateUtils.getFormatDate(Utilidades.toDate(campo.getValue()), "dd/MM/yyyy");
          dataModificados.put(nombreCampo, fechaConFormato);
        }
      }

      Map<String, Object> dataOriginal = (Map) mapDatosModificados.get("dataOriginal");
      for (Entry<String, Object> campo : dataOriginal.entrySet())
      {
        String nombreCampo = campo.getKey();
        String preficoFecha = "FEC_";
        if (nombreCampo.startsWith(preficoFecha))
        {
          String fechaConFormato = SunatDateUtils.getFormatDate(Utilidades.toDate(campo.getValue()), "dd/MM/yyyy");
          dataOriginal.put(nombreCampo, fechaConFormato);
        }
      }

      if (SojoUtil.toJson(dataModificados).length() <= 4000)
      {
        mapDatos.put("DES_DATA1", SojoUtil.toJson(dataModificados));
      }
      else
      {
        mapDatos.put("DES_DATA1", SojoUtil.toJson(dataModificados).substring(0, 3999));
		int tamanio = SojoUtil.toJson(dataModificados).length();
		if(tamanio > 7999){
			tamanio = 7999;
		}
        mapDatos.put("DES_DATA2", SojoUtil.toJson(dataModificados).substring(4000, tamanio));
      }

      if (SojoUtil.toJson(dataOriginal).length() <= 4000)
      {
        mapDatos.put("DES_ANTDATA1", SojoUtil.toJson(dataOriginal));
      }
      else
      {
        mapDatos.put("DES_ANTDATA1", SojoUtil.toJson(dataOriginal).substring(0, 3999));
		int tamanio = SojoUtil.toJson(dataOriginal).length();
		if(tamanio > 7999){
			tamanio = 7999;
		}
        mapDatos.put("DES_ANTDATA2", SojoUtil.toJson(dataOriginal).substring(4000, tamanio));
      }
      mapDatos.put("COD_ESTCAMBIO", "00");
      rectiOficioDAO.insert(mapDatos);
    }

  }

  //RIN-13 se agrega par�metro para que se pueda utilizar en las diferentes diligencias
  private void actualizarParticipantes(Map params, Integer numCorreDocSol, String tipoDiligencia)
  {

    Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
    Map declaracionAnt = (HashMap) params.get("mapCabDeclara");

    /*Map<String, Object> mapParticipante_PDF = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PDF_ANT = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PDF_DIF = new HashMap<String, Object>();*/

    Map<String, Object> mapParticipante_PTR = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PTR_ANT = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PTR_DIF = new HashMap<String, Object>();

    Map<String, Object> mapParticipante_PIM = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PIM_ANT = new HashMap<String, Object>();
    Map<String, Object> mapParticipante_PIM_DIF = new HashMap<String, Object>();

    Long numeroCorrelativo = new Long(declaracion.get("NUM_CORREDOC").toString().trim());

    //RIN13 se factoriza con el fin de utilizarlo independiente
    this.actualizarParticipanteDeposito(declaracion, declaracionAnt, numeroCorrelativo, numCorreDocSol, tipoDiligencia);
    /*if (declaracion.get("NUM_DOCIDENT_PDF") != null)
    { // tenga dato modificado en el JSP

      mapParticipante_PDF.put("NUM_SECPARTIC", declaracion.get("NUM_SECPARTIC_PDF"));
      mapParticipante_PDF.put("NUM_DOCIDENT", declaracion.get("NUM_DOCIDENT_PDF"));
      String numDocIdentidad = (String) declaracion.get("NUM_DOCIDENT_PDF");

      mapParticipante_PDF_ANT.put("NUM_SECPARTIC", declaracionAnt.get("NUM_SECPARTIC_PDF"));
      mapParticipante_PDF_ANT.put("NUM_DOCIDENT", declaracionAnt.get("NUM_DOCIDENT_PDF"));
      // comparamos los datos
      mapParticipante_PDF_DIF =
                                soporteComparadorService.comparaMap(mapParticipante_PDF, mapParticipante_PDF_ANT,
                                                                    EnumTablaModel.PARTICIPANTE_DOC);

      String tipoOperacionBD = (String) mapParticipante_PDF_DIF.get("tipoOperacionBD");

      Participante participante = new Participante();

      Documento documento = new Documento();
      documento.setNumeroCorrelativo(numeroCorrelativo);

      DataCatalogo tipoParticipante = new DataCatalogo();
      tipoParticipante.setCodDatacat("31");
      DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();
      tipoDocumentoIdentidad.setCodDatacat("4");

      participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PDF")));
      participante.setDocumento(documento);
      participante.setTipoParticipante(tipoParticipante);
      participante.setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
      participante.setNumeroDocumentoIdentidad(declaracion.get("NUM_DOCIDENT_PDF").toString().trim());
      if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD))
      {
        participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PDF")));

        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);
        participante.setNombreRazonSocial((String) res.get("nombre"));
        participante.setDireccion((String) res.get("direccion"));

        this.participanteDocDAO.updateByPrimaryKey(participante);
        this.registrarRectiOficio(mapParticipante_PDF_DIF, Constantes.MODULO_RECTIFICACION_OFICIO, numeroCorrelativo,
                                  "T0087", numCorreDocSol);

      }
      else if (Constantes.REGISTRO_NUEVO.equals(tipoOperacionBD))
      {

        String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
        Long codigoParticipante = sequenceDAO.getNextSequence(sequenceName);

        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);
        participante.setNombreRazonSocial((String) res.get("nombre"));
        participante.setDireccion((String) res.get("direccion"));

        participante.setSecuenciaDeParticipantes(codigoParticipante);

        this.participanteDocDAO.insertSelective(participante);
        this.registrarRectiOficio(mapParticipante_PDF_DIF, Constantes.MODULO_RECTIFICACION_OFICIO,
                                  new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);
      }
    }*/

    if (declaracion.get("NUM_DOCIDENT_PTR") != null)
    {

        String secuenciaParticipante = declaracion.get("NUM_SECPARTIC_PTR")!=null?declaracion.get("NUM_SECPARTIC_PTR").toString():"";
        if(StringUtils.isEmpty(secuenciaParticipante)){

            Participante participante = new Participante();

            Documento documento = new Documento();
            documento.setNumeroCorrelativo(numeroCorrelativo);

            DataCatalogo tipoParticipante = new DataCatalogo();
            tipoParticipante.setCodDatacat((String) declaracion.get("COD_TIPPARTIC_PTR")); // dato
            // particular
            DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();
            tipoDocumentoIdentidad.setCodDatacat("4");

            participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PTR")));
            participante.setDocumento(documento);
            participante.setTipoParticipante(tipoParticipante);
            participante.setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
            participante.setNumeroDocumentoIdentidad(declaracion.get("NUM_DOCIDENT_PTR").toString().trim());

            String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
            Long codigoParticipante = sequenceDAO.getNextSequence(sequenceName);
            String numDocIdentidad = (String) declaracion.get("NUM_DOCIDENT_PTR");
            Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);
            participante.setNombreRazonSocial((String) res.get("nombre"));
            participante.setDireccion((String) res.get("direccion"));

            participante.setSecuenciaDeParticipantes(codigoParticipante);

            this.participanteDocDAO.insertSelective(participante);
        /*this.registrarRectiOficio(mapParticipante_PTR_DIF, Constantes.MODULO_RECTIFICACION_OFICIO,
                                  new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);*/
            this.registrarRectiOficio(mapParticipante_PTR_DIF, tipoDiligencia, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);

        }else{

      mapParticipante_PTR.put("NUM_SECPARTIC", declaracion.get("NUM_SECPARTIC_PTR"));
      mapParticipante_PTR.put("NUM_DOCIDENT", declaracion.get("NUM_DOCIDENT_PTR"));
      mapParticipante_PTR.put("COD_TIPPARTIC", declaracion.get("COD_TIPPARTIC_PTR"));
      String numDocIdentidad = (String) declaracion.get("NUM_DOCIDENT_PTR");

      mapParticipante_PTR_ANT.put("NUM_SECPARTIC", declaracionAnt.get("NUM_SECPARTIC_PTR"));
      mapParticipante_PTR_ANT.put("NUM_DOCIDENT", declaracionAnt.get("NUM_DOCIDENT_PTR"));
      mapParticipante_PTR_ANT.put("COD_TIPPARTIC", declaracionAnt.get("COD_TIPPARTIC_PTR"));
      // comparamos los datos
      mapParticipante_PTR_DIF =
                                soporteComparadorService.comparaMap(mapParticipante_PTR, mapParticipante_PTR_ANT,
                                                                    EnumTablaModel.PARTICIPANTE_DOC);

      String tipoOperacionBD = (String) mapParticipante_PTR_DIF.get("tipoOperacionBD");

      Participante participante = new Participante();

      Documento documento = new Documento();
      documento.setNumeroCorrelativo(numeroCorrelativo);

      DataCatalogo tipoParticipante = new DataCatalogo();
      tipoParticipante.setCodDatacat((String) declaracion.get("COD_TIPPARTIC_PTR")); // dato
                                                                                     // particular
      DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();
      tipoDocumentoIdentidad.setCodDatacat("4");

      participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PTR")));
      participante.setDocumento(documento);
      participante.setTipoParticipante(tipoParticipante);
      participante.setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
      participante.setNumeroDocumentoIdentidad(declaracion.get("NUM_DOCIDENT_PTR").toString().trim());

      if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD))
      {
        participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PTR")));
        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);
        participante.setNombreRazonSocial((String) res.get("nombre"));
        participante.setDireccion((String) res.get("direccion"));

        this.participanteDocDAO.updateByPrimaryKey(participante);
        /*this.registrarRectiOficio(mapParticipante_PTR_DIF, Constantes.MODULO_RECTIFICACION_OFICIO, numeroCorrelativo,
                                  "T0087", numCorreDocSol);*/
        this.registrarRectiOficio(mapParticipante_PTR_DIF, tipoDiligencia, numeroCorrelativo, "T0087", numCorreDocSol);

      }
      else if (Constantes.REGISTRO_NUEVO.equals(tipoOperacionBD))
      {

        String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
        Long codigoParticipante = sequenceDAO.getNextSequence(sequenceName);

        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);
        participante.setNombreRazonSocial((String) res.get("nombre"));
        participante.setDireccion((String) res.get("direccion"));

        participante.setSecuenciaDeParticipantes(codigoParticipante);

        this.participanteDocDAO.insertSelective(participante);
        /*this.registrarRectiOficio(mapParticipante_PTR_DIF, Constantes.MODULO_RECTIFICACION_OFICIO,
                                  new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);*/
        this.registrarRectiOficio(mapParticipante_PTR_DIF, tipoDiligencia, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);
      }
    }

    }//amancilla cambios pase 224

    if (declaracion.get("NUM_DOCIDENT_PIM") != null)
    {

      mapParticipante_PIM.put("NUM_SECPARTIC", declaracion.get("NUM_SECPARTIC_PIM"));
      mapParticipante_PIM.put("NUM_DOCIDENT", declaracion.get("NUM_DOCIDENT_PIM"));
      mapParticipante_PIM.put("COD_TIPDOC", declaracion.get("COD_TIPDOC_PIM"));
      String numDocIdentidad = (String) declaracion.get("NUM_DOCIDENT_PIM");

      Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numDocIdentidad);

      mapParticipante_PIM.put("NOM_RAZONSOCIAL", res.get("nombre"));
      mapParticipante_PIM.put("DIR_PARTIC", declaracion.get("DIR_PARTIC_PIM"));

      mapParticipante_PIM_ANT.put("NUM_SECPARTIC", declaracionAnt.get("NUM_SECPARTIC_PIM"));
      mapParticipante_PIM_ANT.put("NUM_DOCIDENT", declaracionAnt.get("NUM_DOCIDENT_PIM"));
      mapParticipante_PIM_ANT.put("COD_TIPDOC", declaracionAnt.get("COD_TIPDOC_PIM"));
      mapParticipante_PIM_ANT.put("NOM_RAZONSOCIAL", declaracionAnt.get("NOM_RAZONSOCIAL_PIM"));
      mapParticipante_PIM_ANT.put("DIR_PARTIC", declaracionAnt.get("DIR_PARTIC_PIM"));

      // comparamos los datos
      mapParticipante_PIM_DIF =soporteComparadorService.comparaMap(mapParticipante_PIM, mapParticipante_PIM_ANT,
                                                                    EnumTablaModel.PARTICIPANTE_DOC);

      String tipoOperacionBD = (String) mapParticipante_PIM_DIF.get("tipoOperacionBD");

      Participante participante = new Participante();

      Documento documento = new Documento();
      documento.setNumeroCorrelativo(numeroCorrelativo);

      DataCatalogo tipoParticipante = new DataCatalogo();
      tipoParticipante.setCodDatacat("45");
      DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();
      tipoDocumentoIdentidad.setCodDatacat((String) declaracion.get("COD_TIPDOC_PIM"));

      participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PIM")));
      participante.setDocumento(documento);
      participante.setTipoParticipante(tipoParticipante);
      participante.setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
      participante.setNumeroDocumentoIdentidad(declaracion.get("NUM_DOCIDENT_PIM").toString().trim());

      participante.setNombreRazonSocial((String) res.get("nombre"));
      participante.setDireccion((String) res.get("direccion"));

      if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD))
      {
        participante.setSecuenciaDeParticipantes(Utilidades.toLong(declaracion.get("NUM_SECPARTIC_PIM")));

        this.participanteDocDAO.updateByPrimaryKey(participante);
        /*this.registrarRectiOficio(mapParticipante_PIM_DIF, Constantes.MODULO_RECTIFICACION_OFICIO, numeroCorrelativo,
                                  "T0087", numCorreDocSol);*/
        this.registrarRectiOficio(mapParticipante_PIM_DIF, tipoDiligencia, numeroCorrelativo, "T0087", numCorreDocSol);

		  //region amancillaa SDA2-RIN18-PAS20171U220200035
		  verificarCambioImportadorOEA(declaracion);
		  //endregion amancillaa
      }
      else if (Constantes.REGISTRO_NUEVO.equals(tipoOperacionBD))
      {

        String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
        Long codigoParticipante = sequenceDAO.getNextSequence(sequenceName);

        participante.setSecuenciaDeParticipantes(codigoParticipante);

        this.participanteDocDAO.insertSelective(participante);
        /*this.registrarRectiOficio(mapParticipante_PIM_DIF, Constantes.MODULO_RECTIFICACION_OFICIO,
                                  new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);*/
        this.registrarRectiOficio(mapParticipante_PIM_DIF, tipoDiligencia, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), "T0087", numCorreDocSol);
		  //region amancillaa SDA2-RIN18-PAS20171U220200035
		  verificarCambioImportadorOEA(declaracion);

      }
    }

  }

	//region amancillaa SDA2-RIN18-PAS20171U220200035
	private void verificarCambioImportadorOEA(Map declaracion) {

		String numRuc = declaracion.get("NUM_DOCIDENT_PIM").toString().trim();
        Date fechaVigencia =   (Date) declaracion.get("FEC_DECLARACION");
		Long  numCorredocDua =   new Long(declaracion.get("NUM_CORREDOC").toString().trim());

		Map<String,Object> filter = new HashMap<String, Object>();
		filter.put("num_corredoc", numCorredocDua);
		filter.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
		DatoIndicadores indicador = indicadorDUADAO.obtenerIndicadorDeclaracion(filter);

		if(((pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isOEA(numRuc,fechaVigencia)){

			if(indicador==null ){
				Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
				mapIndicadoresDUA.put("numCorredoc", numCorredocDua);
				mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
				mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);

				indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
			}else{

				if (ConstantesDataCatalogo.IND_INACTIVO.equals(indicador.getIndicadorActivo())){

					Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
					mapIndicadoresDUA.put("numCorredoc",numCorredocDua);
					mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
					mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);
					mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_ACTIVO);
					indicadorDUADAO.update(mapIndicadoresDUA);
				}
			}
		}else{
			if(indicador!=null && ConstantesDataCatalogo.IND_ACTIVO.equals(indicador.getIndicadorActivo())){

				Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
				mapIndicadoresDUA.put("numCorredoc",numCorredocDua);
				mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
				mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_PORTAL);
				mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_INACTIVO);
				indicadorDUADAO.update(mapIndicadoresDUA);
			}
		}
	}
	//endregion amancillaa
   //RIN-13
  private void actualizarParticipanteDeposito(Map declaracion, Map declaracionAnt, Long numeroCorrelativo, Integer numCorreDocSol, String tipoDiligencia){
	  String numeroDocumentoIdentidad = (String)declaracion.get("NUM_DOCIDENT_PDF");
			  
	  if (numeroDocumentoIdentidad != null)
	  { // tenga dato modificado en el JSP
		  Object numeroSecuenciaParticipante = declaracion.get("NUM_SECPARTIC_PDF");
		  
		  Map<String, Object> mapParticipante_PDF = new HashMap<String, Object>();
		  mapParticipante_PDF.put("NUM_SECPARTIC", numeroSecuenciaParticipante);
	      mapParticipante_PDF.put("NUM_DOCIDENT", numeroDocumentoIdentidad);
	      
		  Map<String, Object> mapParticipante_PDF_ANT = new HashMap<String, Object>();
	      mapParticipante_PDF_ANT.put("NUM_SECPARTIC", declaracionAnt.get("NUM_SECPARTIC_PDF"));
	      mapParticipante_PDF_ANT.put("NUM_DOCIDENT", declaracionAnt.get("NUM_DOCIDENT_PDF"));
	      
	      //comparamos los datos
		  Map<String, Object> mapParticipante_PDF_DIF = soporteComparadorService.comparaMap(mapParticipante_PDF, mapParticipante_PDF_ANT, EnumTablaModel.PARTICIPANTE_DOC);

	      String tipoOperacionBD = (String) mapParticipante_PDF_DIF.get("tipoOperacionBD");

	      Participante participante = new Participante();

	      Documento documento = new Documento();
	      documento.setNumeroCorrelativo(numeroCorrelativo);

	      DataCatalogo tipoParticipante = new DataCatalogo();
	      tipoParticipante.setCodDatacat("31");
	      DataCatalogo tipoDocumentoIdentidad = new DataCatalogo();
	      tipoDocumentoIdentidad.setCodDatacat("4");

	      participante.setDocumento(documento);
	      participante.setTipoParticipante(tipoParticipante);
	      participante.setTipoDocumentoIdentidad(tipoDocumentoIdentidad);
	      participante.setNumeroDocumentoIdentidad(numeroDocumentoIdentidad.trim());
	      
	      if (Constantes.REGISTRO_MODIFICADO.equals(tipoOperacionBD))
	      {
	        participante.setSecuenciaDeParticipantes(Utilidades.toLong(numeroSecuenciaParticipante));

	        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numeroDocumentoIdentidad);
	        participante.setNombreRazonSocial((String) res.get("nombre"));
	        participante.setDireccion((String) res.get("direccion"));

	        this.participanteDocDAO.updateByPrimaryKey(participante);
	        this.registrarRectiOficio(mapParticipante_PDF_DIF, tipoDiligencia, numeroCorrelativo, "T0087", numCorreDocSol);

	      }
	      else if (Constantes.REGISTRO_NUEVO.equals(tipoOperacionBD))
	      {
	        String sequenceName = ConstanteSecuencia.SECUENCIA_PARTICIPANTE;
	        Long codigoParticipante = sequenceDAO.getNextSequence(sequenceName);

	        Map<String, Object> res = this.soporteService.obtenerPerNatJur("4", numeroDocumentoIdentidad);
	        participante.setNombreRazonSocial((String) res.get("nombre"));
	        participante.setDireccion((String) res.get("direccion"));

	        participante.setSecuenciaDeParticipantes(codigoParticipante);

	        this.participanteDocDAO.insertSelective(participante);
	        this.registrarRectiOficio(mapParticipante_PDF_DIF, tipoDiligencia, numeroCorrelativo, "T0087", numCorreDocSol);
	      }
	  }
  }

  private void actualizarSeries(Map params, Integer numCorreDocSol)
  {
    List<Map<String, Object>> lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
    List<Map<String, Object>> lstDetDeclaraAnt = (ArrayList) params.get("lstDetDeclaraAnt");

    Map<String, Object> fbKeys;

    List<Map<String, Object>> lstDocuPrece;
    List<Map<String, Object>> lstDocuPreceAnt;
    List<Map<String, Object>> lstDocuPreceDif;

    Map cabDeclara = (HashMap) params.get("mapCabDeclaraActual");
    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");
    String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();

    // Obtenemos los datos de series_item
    Long numCorredoc = new Long(cabDeclara.get("NUM_CORREDOC").toString());
    List lstSeriesItem = (ArrayList) params.get("lstSeriesItem");

    Map<String, Object> serieAnt;
    Map<String, Object> serieDif = new HashMap<String, Object>();

    Map<String, Object> prmtMigrac = new HashMap();
    prmtMigrac.put("lstSeriesItem", lstSeriesItem);
    prmtMigrac.put("mapCabDeclaraActual", cabDeclara);

    List<Map<String, Object>> lstConvenioSerie;
    List<Map<String, Object>> lstConvenioSerieAnt;
    List<Map<String, Object>> lstConvenioSerieDif;
    List<Map<String, Object>> lstFacturaSerie;
    List<Map<String, Object>> lstFacturaSerieAnt;

//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
    Map<String, Object> mpDetAdiIC;
    Map<String, Object> mpDetAdiICAnt;
    Map<String, Object> detAdiICDif;
    //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
    
    // actualizacion de docs de autorizacion y documentos asociados

    if (lstDetDeclara != null && lstDetDeclara.size() > 0)
    {

      for (Map<String, Object> serie : lstDetDeclara)
      {
        serieDif = new HashMap<String, Object>();
        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(cabDeclara.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(serie.get("NUM_SECSERIE").toString().trim()));

        serieAnt = Utilidades.obtenerElemento(lstDetDeclaraAnt, fbKeys);

        serieDif = soporteComparadorService.comparaMap(serie, serieAnt, EnumTablaModel.DET_DECLARA);

        if (CollectionUtils.isEmpty(serieAnt))
        {
          if (serie.get("ESTADO_REGISTRO").toString().equals("1"))
          {// pendiente de registro en bd
            if (Constantes.IND_ELIMINADO.equals(serie.get("IND_DEL")))
            {
              // si es nuevo con IND_DEL = 1 no se graba
              continue;
            }
          }
            //amancilla pase137
            this.detDeclaraDAO.insertSelective(Utilidades.transformFieldsToRealFormat(serie));
          actualizarSeriesItem(params, serie.get("NUM_SECSERIE").toString());
          prmtMigrac.put("lstSeriesItem", lstSeriesItem);
          prmtMigrac.put("serie", serie);

          this.migrarCambioSeries(prmtMigrac);

          // boolean isNewRecord = true;
          Map<String, Object> mapClave = new HashMap<String, Object>();
          mapClave.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
          mapClave.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
          serie.put("clave", mapClave);

          this.registrarRectiOficio(serieDif, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_DECLARA, numCorreDocSol);
        }
        else
        {
          if (soporteComparadorService.esDataCambiada(serieDif))
          {

            this.detDeclaraDAO.update(serieDif);

            actualizarSeriesItem(params, serie.get("NUM_SECSERIE").toString());
            prmtMigrac.put("lstSeriesItem", lstSeriesItem);
            prmtMigrac.put("serie", serieDif);

            this.migrarCambioSeries(prmtMigrac);
            this.registrarRectiOficio(serieDif, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_DECLARA, numCorreDocSol);
          }
        }

        // Grabamos los regimenes que han sido registrados, modificados o
        // eliminados

        if (serie.get("lstDocuPreceDua") != null)
        {
          fbKeys = new HashMap();

          fbKeys.put("NUM_CORREDOC", "");
          fbKeys.put("NUM_SECSERIE", "");
          fbKeys.put("NUM_DECLARACIONPRE", "");
          fbKeys.put("ANN_PRESENPRE", "");
          fbKeys.put("COD_ADUANAPRE", "");
          fbKeys.put("COD_REGIMENPRE", "");
          fbKeys.put("NUM_SECSERIEPRE", "");

          lstDocuPreceAnt =
                            ((serieAnt != null && serieAnt.get("lstDocuPreceDua") != null)
                                                                                          ? (ArrayList<Map<String, Object>>) serieAnt
                                                                                                                                     .get("lstDocuPreceDua")
                                                                                          : null);
          lstDocuPrece =
                         ((serie.get("lstDocuPreceDua") != null)
                                                                ? (ArrayList<Map<String, Object>>) serie
                                                                                                        .get("lstDocuPreceDua")
                                                                : null);

          if (!CollectionUtils.isEmpty(lstDocuPrece))
          {
            Comparador comp = new Comparador();
            lstDocuPreceDif = comp.comparaList(lstDocuPreceAnt, lstDocuPrece, fbKeys, true, false, true, true);

            // lstDocuPreceDif = comp.comparaList(lstDocuPreceAnt,lstDocuPrece,
            // fbKeys, true, false, true, true);
            // lstDocuPreceDif = comparadorUtil.comparaList(lstDocuPrece,
            // lstDocuPreceAnt, EnumTablaModel.DOCUPRECE_DUA);
            // amancilla pase604 el problema de aqui es que el nuevo comparador
            // no devuelve directamente los mapasa del PK
            // ademas de eso filtra los campos que no pertenecen a la tabla
            // regPre.get("IND_NUEVO") que se usa en una operacion
            // nunca va encontrar valor por lo tanto
            // pendiente de corregir regresamos a su antigua comparacion

            for (Map regPre : lstDocuPreceDif)
            {
              fbKeys = new HashMap();
              fbKeys.put("ANN_PRESENPRE", regPre.get("ANN_PRESENPRE"));
              fbKeys.put("NUM_SECSERIEPRE", regPre.get("NUM_SECSERIEPRE"));
              fbKeys.put("NUM_SECSERIE", regPre.get("NUM_SECSERIE"));
              fbKeys.put("COD_ADUANAPRE", regPre.get("COD_ADUANAPRE"));
              fbKeys.put("NUM_DECLARACIONPRE", regPre.get("NUM_DECLARACIONPRE"));
              fbKeys.put("COD_REGIMENPRE", regPre.get("COD_REGIMENPRE"));
              fbKeys.put("NUM_CORREDOC", regPre.get("NUM_CORREDOC"));
              /* PAS20145E220000399 INICIO GGRANADOS */
//              Map regAct = Utilidades.obtenerElemento(lstDocuPrece, fbKeys);
              /* PAS20145E220000399 FIN GGRANADOS */

              if (Utilidades.obtenerElemento(lstDocuPreceAnt, fbKeys) == null)
              {
            	  
                 //amancilla cuando ya fue registrado se cae pq quiere volver a registrarlo y pq no lo carga desde un inicio ?? eso ya es otro precio 
            	  
            	 try{
                this.docuPreceDuaDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(regPre));
                }catch(DuplicateKeyException e){
                	this.docuPreceDuaDAO.updateRegPrecedenciaByMap(Utilidades.transformFieldsToRealFormat(regPre));
                }
                // nuevo
                Map<String, Object> mapDiferencias =
                                                     soporteComparadorService.comparaMap(regPre, new HashMap(),
                                                                                         EnumTablaModel.DOCUPRECE_DUA);
                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_DOCUPRECE_DUA,
                                            numCorreDocSol);
                }

              }
              else if ((regPre.get("IND_NUEVO") != null) && ("1".equals(regPre.get("IND_NUEVO").toString().trim())))
              {
                this.docuPreceDuaDAO.insertRegPrecedencia(Utilidades.transformFieldsToRealFormat(regPre));
                // nuevo
                Map<String, Object> mapDiferencias =
                                                     soporteComparadorService.comparaMap(regPre, new HashMap(),
                                                                                         EnumTablaModel.DOCUPRECE_DUA);
                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_DOCUPRECE_DUA,
                                            numCorreDocSol);
                }
              }
              //else if ("0".equals(regPre.get("IND_DEL")))//jenciso el comparador ya no lo retorna cuando se cambia solo la fecha.
              else if ((regPre.get("IND_DEL")!=null && "0".equals(regPre.get("IND_DEL"))) || regPre.get("IND_DEL") == null)
              {
                this.docuPreceDuaDAO.updateRegPrecedenciaByMap(Utilidades.transformFieldsToRealFormat(regPre));
                // nuevo
                Map regPreOld = Utilidades.obtenerElemento(lstDocuPreceAnt, fbKeys);
                Map<String, Object> mapDiferencias =
                                                     soporteComparadorService.comparaMap(regPre, regPreOld,
                                                                                         EnumTablaModel.DOCUPRECE_DUA);
                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_DOCUPRECE_DUA,
                                            numCorreDocSol);
                }
              }
              else if ("1".equals(regPre.get("IND_DEL")))
              {
                this.docuPreceDuaDAO.deleteRegPrecedenciaByPK(Utilidades.transformFieldsToRealFormat(regPre));
                // nuevo
                Map regPreOld = Utilidades.obtenerElemento(lstDocuPreceAnt, fbKeys);
                Map<String, Object> mapDiferencias =
                                                     soporteComparadorService.comparaMap(regPre, regPreOld,
                                                                                         EnumTablaModel.DOCUPRECE_DUA);
                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_DOCUPRECE_DUA,
                                            numCorreDocSol);
                }
              }
            } // for
            

            //jenciso Inicio - agregando actualizacion de vehiculos ceticos
            List<Map<String,Object>> lstDatoVehiculo = null;
            List<Map<String,Object>> lstDatoMontoGasto = null;
            List<Map<String,Object>> lstDatoVehiculoAnt = null;
            List<Map<String,Object>> lstDatoMontoGastoAnt = null;
            Map<String,Object> mapVehiculo= null;
            Map<String,Object> mapVehiculoAnt= null;
            //List<Map<String,Object>> lstMontoGastos = null;
            //List<Map<String,Object>> lstMontoGastosAnt = null;
            Map<String,Object> mapVehiculoDif= null;
            /* PAS20145E220000399 INICIO GGRANADOS */
//            List<Map<String,Object>> lstMontoGastosDif = null;
            /* PAS20145E220000399 FIN GGRANADOS */
            
            Map<String,Object> mapClave= null;
            Map<String,Object> mapDif = new HashMap<String,Object>();
            
            if(serie.get("lstDatoVehiculo")!=null  && serie.get("lstDatoMontoGasto")!=null){            	
            	lstDatoVehiculo =  (List<Map<String,Object>>)serie.get("lstDatoVehiculo");
            	lstDatoMontoGasto = (List<Map<String,Object>>)serie.get("lstDatoMontoGasto");
            	if(!CollectionUtils.isEmpty(lstDatoVehiculo) && !CollectionUtils.isEmpty(lstDatoMontoGasto)){
	            	//mapVehiculo= Utilidades.obtenerMapFromObjectDatoVehiculo(lstDatoVehiculo.get(0));
	            	//lstMontoGastos = Utilidades.obtenerListMapFromListObjectDatoMontoGasto(lstDatoMontoGasto);
	            	mapVehiculo = (Map<String,Object>)lstDatoVehiculo.get(0);
	            	
	            	lstDatoVehiculoAnt = (serieAnt!=null && serieAnt.get("lstDatoVehiculo")!=null)?(List<Map<String,Object>>)serieAnt.get("lstDatoVehiculo"):null;
	            	lstDatoMontoGastoAnt = (serieAnt!=null && serieAnt.get("lstDatoMontoGasto")!=null)?(List<Map<String,Object>>)serieAnt.get("lstDatoMontoGasto"):null;
	            	
	            	if(CollectionUtils.isEmpty(lstDatoVehiculoAnt) && CollectionUtils.isEmpty(lstDatoMontoGastoAnt)  ){
	            		//se realiza el insert pero verificando si antes hubo uno en BD
	            		vehiCeticoService.insertarVehiculoCeticos(mapVehiculo);
	            		mapClave = new HashMap<String, Object>();
	            		mapClave.put("NUM_CORREDOC", mapVehiculo.get("NUM_CORREDOC"));
	            		mapClave.put("NUM_SECSERIE", mapVehiculo.get("NUM_SECSERIE"));
	            		mapVehiculo.put("clave", mapClave);
	            		//this.registrarRectiOficio(mapVehiculo, tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO, true);
	            		mapDif = new HashMap<String, Object>();
	            		mapDif = soporteComparadorService.comparaMap(mapVehiculo, null, EnumTablaModel.VEHI_CETICO);
	            		this.registrarRectiOficio(mapDif, tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO, numCorreDocSol);
	            		
	            		//eliminamos logicamente los conceptos gasto de toda la serie
	            		Map<String,Object> mapEliminacion = new HashMap<String, Object>();
	            		mapEliminacion.putAll(mapVehiculo);
	            		mapEliminacion.put("IND_DEL", "1");
	            		vehiCeticoService.actualizarDatoEliminacionMontoGastoBySerie(mapEliminacion);
	            		for(Map<String,Object> mapMontoGasto: lstDatoMontoGasto){            			
	            			//se realiza el insert pero verificando si antes hubo uno en BD
	            			vehiCeticoService.insertarMontoGasto(mapMontoGasto);
	            			mapClave = new HashMap<String, Object>();
	            			mapClave.put("NUM_CORREDOC", mapMontoGasto.get("NUM_CORREDOC"));
	            			mapClave.put("NUM_SECSERIE", mapMontoGasto.get("NUM_SECSERIE"));
	            			mapClave.put("COD_CPTOGASTOS", mapMontoGasto.get("COD_CPTOGASTOS"));                		
	            			mapMontoGasto.put("clave", mapClave);
	            			//this.registrarRectiOficio(mapMontoGasto, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, true);
	            			mapDif = new HashMap<String, Object>();
	            			mapDif = soporteComparadorService.comparaMap(mapMontoGasto, null, EnumTablaModel.MONTOGASTO);            			
	            			this.registrarRectiOficio(mapDif, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, numCorreDocSol);
	            		}
	            		
	            	}else{
	            		//se compara y se actualiza los datos guardados
	            		mapVehiculoDif = new HashMap<String, Object>();            		
	            		//mapVehiculoAnt = Utilidades.obtenerMapFromObjectDatoVehiculo(lstDatoVehiculoAnt.get(0));
	            		//lstMontoGastosAnt = Utilidades.obtenerListMapFromListObjectDatoMontoGasto(lstDatoMontoGastoAnt);
	            		mapVehiculoAnt = (Map<String,Object>)lstDatoVehiculoAnt.get(0);
	            		
	            		fbKeys.clear();
	            		fbKeys.put("NUM_CORREDOC", mapVehiculo.get("NUM_CORREDOC"));
	                    fbKeys.put("NUM_SECSERIE", mapVehiculo.get("NUM_SECSERIE"));
	            		//mapVehiculoDif = comp.comparaMapEstricto(mapVehiculoAnt, mapVehiculo, false, false, fbKeys);
	                    mapVehiculoDif = soporteComparadorService.comparaMap(mapVehiculo, mapVehiculoAnt, EnumTablaModel.VEHI_CETICO);
	            		
	            		// verificamos si existe data cambiada
	            		//if(Comparador.esDataCambiada(mapVehiculoDif)){
	            		if(soporteComparadorService.esDataCambiada(mapVehiculoDif)){
	            			vehiCeticoDAO.updateSelective(Utilidades.transformFieldsToRealFormat(mapVehiculoDif));
	            			this.registrarRectiOficio(mapVehiculoDif, tipDilig, numCorredoc, Constantes.COD_TABLA_VEHI_CETICO,numCorreDocSol);
	            		}
	            		
	            		
	            		//hacer otro for para guardar en detsolrecti los elimnados (con esto ya no se usaria actualizarDatoEliminacionMontoGastoBySerie)
	            		//segunda alternativa
	            		for(Map<String,Object> mapMontoGasto: lstDatoMontoGasto){
	            			fbKeys.clear();
	                		fbKeys.put("NUM_CORREDOC", mapMontoGasto.get("NUM_CORREDOC"));
	                        fbKeys.put("NUM_SECSERIE", mapMontoGasto.get("NUM_SECSERIE"));
	                        fbKeys.put("COD_CPTOGASTOS", mapMontoGasto.get("COD_CPTOGASTOS"));
	                        if (Utilidades.obtenerElemento(lstDatoMontoGastoAnt, fbKeys) == null){
	                        	//se realiza el insert pero verificando si antes hubo uno en BD
	                			vehiCeticoService.insertarMontoGasto(mapMontoGasto);                			
	                			mapMontoGasto.put("clave", fbKeys);
	                			
	                			mapDif = new HashMap<String, Object>();
	                			mapDif = soporteComparadorService.comparaMap(mapMontoGasto, null, EnumTablaModel.MONTOGASTO);//para control de cambios
	                			
	                			this.registrarRectiOficio(mapDif, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, numCorreDocSol);
	                        }else{
	                        	Map<String,Object> mapMontoGastoAnt = Utilidades.obtenerElemento(lstDatoMontoGastoAnt, fbKeys) ;
	                        	Map<String,Object> mapMontoGastoDif = new HashMap<String, Object>();
	                        	
	                        	//mapMontoGastoDif = comp.comparaMapEstricto(mapMontoGastoAnt, mapMontoGasto, false, false, fbKeys);
	                        	mapMontoGastoDif = soporteComparadorService.comparaMap(mapMontoGasto, mapMontoGastoAnt, EnumTablaModel.MONTOGASTO);
	                        	//verificamos si hay cambios
	                        	if(soporteComparadorService.esDataCambiada(mapMontoGastoDif)){
	                        		//mapMontoGastoDif.put("IND_DEL", Constants.INDICADOR_NO_ELIMINADO);
	                            	montoGastoDAO.updateSelective(mapMontoGastoDif);
	                            	this.registrarRectiOficio(mapMontoGastoDif, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, numCorreDocSol);
	                        	}
	                        }
	            			
	            		}
	            		for(Map<String,Object> mapMontoGastoAnt: lstDatoMontoGastoAnt){
	            			fbKeys.clear();
	                		fbKeys.put("NUM_CORREDOC", mapMontoGastoAnt.get("NUM_CORREDOC"));
	                        fbKeys.put("NUM_SECSERIE", mapMontoGastoAnt.get("NUM_SECSERIE"));
	                        fbKeys.put("COD_CPTOGASTOS", mapMontoGastoAnt.get("COD_CPTOGASTOS"));
	                        if (Utilidades.obtenerElemento(lstDatoMontoGasto, fbKeys) == null){//si no esta en la lista actual se elimina
	                        	Map<String,Object>mapMontoGastoAux = new HashMap<String, Object>();
	                        	Map<String,Object>mapMontoGastoDifAux = new HashMap<String, Object>();
	                        	mapMontoGastoAux.putAll(mapMontoGastoAnt);
	                        	mapMontoGastoAux.put("IND_DEL", Constants.INDICADOR_ELIMINADO);
	                        	//mapMontoGastoDifAux = comp.comparaMapEstricto(mapMontoGastoAnt, mapMontoGastoAux, false, false, fbKeys);//para registrar control de cambios
	                        	mapMontoGastoDifAux = soporteComparadorService.comparaMap(mapMontoGastoAux, mapMontoGastoAnt, EnumTablaModel.MONTOGASTO);//para registrar control de cambios
	                        	montoGastoDAO.updateSelective(mapMontoGastoDifAux);
	                        	this.registrarRectiOficio(mapMontoGastoDifAux, tipDilig, numCorredoc, Constantes.COD_TABLA_MONTO_GASTO, numCorreDocSol);
	                        }
	            		}
	            		
	            		
	            		
	            	}
            	
            	}
            }
            
            //jenciso Fin
          }
        }

          //P34 AFMA CAMBIOS DE GRABADO
        // Actualizamos los convenios de la serie
        if (serie.get("lstConvenioSerie") != null)
        {
          lstConvenioSerie = (ArrayList) serie.get("lstConvenioSerie");
          lstConvenioSerieAnt =
                                null != serieAnt ? (ArrayList) serieAnt.get("lstConvenioSerie")
                                                : new ArrayList<Map<String, Object>>();

          fbKeys = new HashMap();

          fbKeys.put("NUM_SECSERIE", "");
          fbKeys.put("COD_TIPCONVENIO", "");
          fbKeys.put("COD_CONVENIO", "");


          lstConvenioSerieDif =
                                soporteComparadorService.comparaList(lstConvenioSerie, lstConvenioSerieAnt,
                                                                     EnumTablaModel.CONVENIO_SERIE);
          /*inicio P46-PAS20155E410000032-[jlunah]*/
          boolean tieneCodLiberatorioDonacion = false;
          /*fin P46-PAS20155E410000032-[jlunah]*/
          
          if (!CollectionUtils.isEmpty(lstConvenioSerieDif))
          {


            List<HashMap> lstConvenioEliminados = new ArrayList<HashMap>();
            for (Map convenioSerie : lstConvenioSerieDif)
            {

                //amancilla inico-PAS20155E220200035 se copia lo mismo de desapacho deberia funcionar, jaja no funciono caballero no mas a arregalro

                Map<String,Object> mapConvenio;
                for (Map convenioSerieAnt : lstConvenioSerieAnt) {
                    boolean encontrado=false;

                    for (Map convenioSerieAct : lstConvenioSerie) {
                        if ( convenioSerieAnt.get("COD_CONVENIO").toString().trim().equals(convenioSerieAct.get("COD_CONVENIO").toString().trim()) &&
                                convenioSerieAnt.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieAct.get("COD_TIPCONVENIO").toString().trim()) &&
                                convenioSerieAnt.get("IND_DEL").toString().trim().equals(convenioSerieAct.get("IND_DEL").toString().trim())){
                            encontrado=true;
                            break;
                        }

                    }

                    if (!encontrado){
                                              
                        //para que funcione dato aterior y dato modificado en la consulta para convenios se hace un artificio
                        HashMap convenioEliminado = new HashMap();
                        convenioEliminado.put("NUM_CORREDOC",serie.get("NUM_CORREDOC"));
                        convenioEliminado.put("NUM_SECSERIE",convenioSerie.get("NUM_SECSERIE"));
                        convenioEliminado.put("COD_TIPCONVENIO",convenioSerie.get("COD_TIPCONVENIO"));
                        convenioEliminado.put("COD_CONVENIO",convenioSerieAnt.get("COD_CONVENIO").toString().trim());
                        convenioEliminado.put("IND_DEL","1");
                        lstConvenioEliminados.add(convenioEliminado);

                        this.convenioSerieDAO.update(convenioEliminado);
                          //amancilla no se sabe si biene con espacio o sin espacio tons mejor hacemos doble jaja                                
                        convenioEliminado.put("COD_CONVENIO",Cadena.padLeft(convenioSerieAnt.get("COD_CONVENIO").toString().trim(),4,' '));                
                        this.convenioSerieDAO.update(convenioEliminado);
                        
                        //amancilla no se registra cuando se elimina this.registrarRectiOficio( convenioSerie,  tipDilig,  numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE,numCorreDocSol);
                    }
                }

                for (Map convenioSerieAct : lstConvenioSerie) {
                    boolean encontrado=false;

                    for (Map convenioSerieAnt :lstConvenioSerieAnt ) {
                        if ( convenioSerieAct.get("COD_CONVENIO").toString().trim().equals(convenioSerieAnt.get("COD_CONVENIO").toString().trim()) &&
                                convenioSerieAct.get("COD_TIPCONVENIO").toString().trim().equals(convenioSerieAnt.get("COD_TIPCONVENIO").toString().trim())){
                            encontrado=true;
                            break;
                        }

                    }

                    if (!encontrado && !convenioSerieAct.get("COD_CONVENIO").toString().trim().equals("0") && !convenioSerieAct.get("IND_DEL").toString().trim().equals(Constantes.IND_ELIMINADO) ){

                        convenioSerie.put("numCorredoc", serie.get("NUM_CORREDOC"));
                        convenioSerie.put("numSecserie", convenioSerie.get("NUM_SECSERIE"));
                        convenioSerie.put("codTipconvenio", convenioSerie.get("COD_TIPCONVENIO"));
                        convenioSerie.put("codConvenio", convenioSerie.get("COD_CONVENIO"));
                        convenioSerie.put("IND_DEL", convenioSerieAct.get("IND_DEL").toString());
                        
                        /*inicio P46-PAS20155E410000032-[jlunah]*/
                        CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
                        tieneCodLiberatorioDonacion = convenioSerie.get("COD_TIPCONVENIO").toString().equals(ConstantesDataCatalogo.CODIGO_LIBERATORIO) && codigoLiberatorioService.serieTieneCodLiberatorioDonacion(Integer.parseInt(convenioSerie.get("COD_CONVENIO").toString()));
                        params.put("tieneCodLiberatorioDonacion", tieneCodLiberatorioDonacion);
                        /*fin P46-PAS20155E410000032-[jlunah]*/

                        try{
                            this.convenioSerieDAO.insertMapSelective(convenioSerie);

                            if(!CollectionUtils.isEmpty(lstConvenioEliminados)){

                                for(Map convenioEliminado: lstConvenioEliminados){
                                    if(convenioSerie.get("NUM_SECSERIE").toString().equals(convenioEliminado.get("NUM_SECSERIE").toString())
                                            &&  convenioSerie.get("COD_TIPCONVENIO").toString().equals(convenioEliminado.get("COD_TIPCONVENIO").toString())){

                                        Map dataModificados = new HashMap();
                                        Map dataOriginal    = new HashMap();

                                        String aliasParaMostrarConsultaDua = "COD_CONVENIO";
                                        //(I:TPI T:TPN C:CODIGO LIBERATORIO)
                                        if("I".equals(convenioSerie.get("COD_TIPCONVENIO").toString())){
                                            aliasParaMostrarConsultaDua = "COD_CONVENIO_CI";
                                        }else if("T".equals(convenioSerie.get("COD_TIPCONVENIO").toString())){
                                            aliasParaMostrarConsultaDua = "COD_CONVENIO_CT";
                                        }else if("C".equals(convenioSerie.get("COD_TIPCONVENIO").toString())){
                                            aliasParaMostrarConsultaDua = "COD_CONVENIO_CC";
                                        }

                                        dataModificados.put(aliasParaMostrarConsultaDua,convenioSerie.get("COD_CONVENIO"));
                                        dataOriginal.put(aliasParaMostrarConsultaDua, convenioEliminado.get("COD_CONVENIO"));
                                        convenioSerie.put("dataModificados",dataModificados);
                                        convenioSerie.put("dataOriginal",dataOriginal);
                                    }
                                }
                            }

                            this.registrarRectiOficio(  convenioSerie,  tipDilig,numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE,numCorreDocSol);
                        } catch(DuplicateKeyException e) {
                                convenioSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                                this.convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(convenioSerie));
                                this.registrarRectiOficio(convenioSerie, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE,numCorreDocSol );
                        }

                    }
                }

                //amancilla fin-PAS20155E220200035 se copia lo mismo de desapacho deberia funcionar

                /* amancilla se comenta pq malograron el grabado cambiaron en diligencia y lo desjaron mal para recti de oficio
              if ("1".equals(convenioSerie.get("IND_DEL")))
              {
                // Eliminamos registro de convenio
                convenioSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
                this.convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(convenioSerie));
                this.registrarRectiOficio(convenioSerie, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE,
                                          numCorreDocSol);
              }
              else
              {
                // Insertamos registro de convenio
                fbKeys.put("NUM_SECSERIE", convenioSerie.get("NUM_SECSERIE"));
                fbKeys.put("COD_TIPCONVENIO", convenioSerie.get("COD_TIPCONVENIO"));
                fbKeys.put("COD_CONVENIO", convenioSerie.get("COD_CONVENIO"));

                if (Utilidades.obtenerElemento(lstConvenioSerieAnt, fbKeys) == null)
                {
                  convenioSerie.put("numCorredoc", serie.get("NUM_CORREDOC"));
                  convenioSerie.put("numSecserie", convenioSerie.get("NUM_SECSERIE"));
                  convenioSerie.put("codTipconvenio", convenioSerie.get("COD_TIPCONVENIO"));
                  convenioSerie.put("codConvenio", convenioSerie.get("COD_CONVENIO"));

//                  this.convenioSerieDAO.insertMapSelective(convenioSerie);
  //                this.registrarRectiOficio(convenioSerie, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE,
                       //                     numCorreDocSol);
                  
                  
                  
                  //RSV RIN-P47
                  try{
                	  
                  this.convenioSerieDAO.insertMapSelective(convenioSerie);
                      this.registrarRectiOficio(convenioSerie, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE, numCorreDocSol);
                      
                  } catch(DuplicateKeyException e) {
                	  
                	  if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipDilig) || Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION.equals(tipDilig) ||
                			  Constantes.COD_TIPO_DILIGENCIA_CONCLUSION.equals(tipDilig) ) {
                		  //Actualizamos registro de convenio
    	                  convenioSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
    	                  this.convenioSerieDAO.update(Utilidades.transformFieldsToRealFormat(convenioSerie));
    	                  this.registrarRectiOficio(convenioSerie, tipDilig, numCorredoc, Constantes.COD_TABLA_CONVENIO_SERIE, numCorreDocSol);
                	  }
                	  
                  }                  
                }
            }*/
                      }
          }
        }

        fbKeys = new HashMap();
        fbKeys.put("NUM_CORREDOC", new Long(cabDeclara.get("NUM_CORREDOC").toString().trim()));
        fbKeys.put("NUM_SECSERIE", new Long(serie.get("NUM_SECSERIE").toString().trim()));

        if (!CollectionUtils.isEmpty(serieAnt))
        {
          if (serie.get("mapDetAdiAtpa") != null && serieAnt.get("mapDetAdiAtpa") != null)
          {

            Map adAtpaActual = (Map) serie.get("mapDetAdiAtpa");
            adAtpaActual.putAll(fbKeys);
            Map adAtpaAntiguo = (Map) serieAnt.get("mapDetAdiAtpa");
            adAtpaAntiguo.putAll(fbKeys);

            Map adAtpaDif =
                            soporteComparadorService.comparaMap(adAtpaActual, adAtpaAntiguo,
                                                                EnumTablaModel.DET_ADI_ATPA);

            if (soporteComparadorService.esDataCambiada(adAtpaDif))
            {

              this.detAdiAtpaDAO.updateSelective(adAtpaDif);
              this.registrarRectiOficio(adAtpaDif, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_ADI_ATPA,
                                        numCorreDocSol);
            }

          }
        }

        //ini P46-PAS20155E410000032
        Map<String, Object> mapDetAdiImpoconsu = new HashMap<String, Object>();
        mapDetAdiImpoconsu.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
        mapDetAdiImpoconsu.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
        
        DetAdiImpoconsuDAO detAdiImpoconsuDAO = fabricaDeServicios.getService("detAdiImpoconsuDAO");
        
        boolean existeDetAdiImpoconsu = !CollectionUtils.isEmpty(detAdiImpoconsuDAO.select(mapDetAdiImpoconsu));
        
        mapDetAdiImpoconsu.put("COD_TIPREGUL", serie.get("COD_TIPREGUL"));
		if (existeDetAdiImpoconsu) {
        	detAdiImpoconsuDAO.update(mapDetAdiImpoconsu);
		} else if (!"".equals(SunatStringUtils.trimNotNull((String)serie.get("COD_TIPREGUL")))) {
			detAdiImpoconsuDAO.insertSelective(mapDetAdiImpoconsu);
		}
		//fin P46-PAS20155E410000032
		  
        // lstFacturaSerie
        if (!CollectionUtils.isEmpty((List) serie.get("lstFacturaSerie")))
        {

          lstFacturaSerie = (ArrayList) serie.get("lstFacturaSerie");
          lstFacturaSerieAnt =
                               null != serieAnt ? (ArrayList) serieAnt.get("lstFacturaSerie")
                                               : new ArrayList<Map<String, Object>>();

          fbKeys = new HashMap();
          fbKeys.put("NUM_SECFACT", "");
          fbKeys.put("NUM_SECSERIE", "");
          // lstFacturaSerieDif = comp.comparaList(lstFacturaSerieAnt,
          // lstFacturaSerie, fbKeys, true, false, true, true);
          // lstFacturaSerie se encuntran todas las series el comparador se raya
          // cuand NUM_SECFACT viene "" ya que es parte de la clave
          // y es en el grabado que se asigna el correlativo NUM_SECFACT
          // dinamicamente
          for (Map facturaSerie : lstFacturaSerie)
          {
            fbKeys.put("NUM_SECFACT", facturaSerie.get("NUM_SECFACT"));
            fbKeys.put("NUM_SECSERIE", facturaSerie.get("NUM_SECSERIE"));
            //RIN13
            String indicadorEliminacion = ObjectUtils.toString(facturaSerie.get("IND_DEL"), "0");
            
            //if ("1".equals(facturaSerie.get("IND_DEL")))
            if("1".equals(indicadorEliminacion))
            { // registrios eliminado
              facturaSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
              String numSecFac = facturaSerie.get("NUM_SECFACT").toString();
              // la factura debe de haber existido en BD
              if (!StringUtils.isBlank(numSecFac) && Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys) != null)
              {
                Map<String, Object> mapActualizar = new HashMap<String, Object>();
                mapActualizar.put("IND_DEL", "1");
                this.facturaSerieDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));

                Map<String, Object> mapDiferencias =
                                                     soporteComparadorService.comparaMap(facturaSerie,
                                                                                         Utilidades.obtenerElemento(lstFacturaSerieAnt,
                                                                                                                    fbKeys),
                                                                                         EnumTablaModel.FACTURA_SERIE);

                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_FACTURA_SERIE,
                                            numCorreDocSol);
                }

                if (isFacturaRegistradaMultiplesSeries(lstDetDeclara, numSecFac) == true)
                {
                  facturaSerie.put("IND_DEL", "0");
                }
                formaFactuDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));

                mapDiferencias =
                                 soporteComparadorService.comparaMap(facturaSerie,
                                                                     Utilidades.obtenerElemento(lstFacturaSerieAnt,
                                                                                                fbKeys),
                                                                     EnumTablaModel.FORMA_FACTU);

                if (soporteComparadorService.esDataCambiada(mapDiferencias))
                {
                  this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_FORMA_FACTU,
                                            numCorreDocSol);
                }

              }
            }
            else
            { // registros activos
              if (Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys) == null)
              { // es nuevo
                facturaSerie.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));

                // String numSecFac = (String) facturaSerie.get("NUM_SECFACT");
                // if(StringUtils.isBlank(numSecFac) ){ //es nuevo

                // 2 casos mas si el nuevo registro tiene la misma numero de
                // factura no se registra

                String numeroFactura = (String) facturaSerie.get("NUM_FACT");
                Map<String, Object> mapFacturaSerieAnt = buscarFactura(lstDetDeclaraAnt, numeroFactura);

                if (CollectionUtils.isEmpty(mapFacturaSerieAnt))
                {
                  Integer numSecFacturaSiguiente = obtenerNumeroSecFactSeguiente(numCorredoc);
                  facturaSerie.put("NUM_SECFACT", numSecFacturaSiguiente);
                  formaFactuDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  facturaSerieDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));

                  // NUEVO
                  Map<String, Object> mapDiferencias =
                                                       soporteComparadorService.comparaMap(facturaSerie, new HashMap(),
                                                                                           EnumTablaModel.FORMA_FACTU);
                  if (soporteComparadorService.esDataCambiada(mapDiferencias))
                  {
                    this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc, Constantes.COD_TABLA_FORMA_FACTU,
                                              numCorreDocSol);
                  }

                  mapDiferencias =
                                   soporteComparadorService.comparaMap(facturaSerie, new HashMap(),
                                                                       EnumTablaModel.FACTURA_SERIE);
                  if (soporteComparadorService.esDataCambiada(mapDiferencias))
                  {
                    this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc,
                                              Constantes.COD_TABLA_FACTURA_SERIE, numCorreDocSol);
                  }

                }
                else
                { // para este caso lo que se inserta es la una relacion mas
                  // apuntando a la factura que ya existe
                  facturaSerie.put("NUM_SECFACT", mapFacturaSerieAnt.get("NUM_SECFACT"));
                  facturaSerieDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(facturaSerie));

                  // NUEVO
                  Map<String, Object> mapDiferencias =
                                                       soporteComparadorService.comparaMap(facturaSerie, new HashMap(),
                                                                                           EnumTablaModel.FACTURA_SERIE);
                  if (soporteComparadorService.esDataCambiada(mapDiferencias))
                  {
                    this.registrarRectiOficio(mapDiferencias, tipDilig, numCorredoc,
                                              Constantes.COD_TABLA_FACTURA_SERIE, numCorreDocSol);
                  }
                }
              }
              else
              { // si no es nuevo y actualizado los datos
                Map facturaSerieAnt = Utilidades.obtenerElemento(lstFacturaSerieAnt, fbKeys);

                Map<String, Object> facturaSerieDif =
                                                      soporteComparadorService.comparaMap(facturaSerie,
                                                                                          facturaSerieAnt,
                                                                                          EnumTablaModel.FORMA_FACTU);

                // if (Comparador.esDataCambiada(facturaSerieDif))
                if (soporteComparadorService.esDataCambiada(facturaSerieDif))
                {
                  // facturaSerie.put("NUM_CORREDOC",
                  // serie.get("NUM_CORREDOC"));
                  // se actualiza la factura ya existe relacion factura_Serie
                  // formaFactuDAO.update(Utilidades.transformFieldsToRealFormat(facturaSerie));
                  formaFactuDAO.update(facturaSerieDif);
                  this.registrarRectiOficio(facturaSerieDif, tipDilig, numCorredoc, Constantes.COD_TABLA_FORMA_FACTU,
                                            numCorreDocSol);
                }
              }
            }
          } // for
        }

        // se esta copiando las tablas complementarias de la copia de la serie
        // PAS20112A600000578
        // ESTADO_REGISTRO=1 NUEVA SERIE amancillaa cambiar este codigo cuando
        // se implemente el mantenimiento de estas tablas
        if (serie.get("ESTADO_REGISTRO").toString().equals("1"))
        {

          Map<String, Object> detAdiAtpa = (HashMap) serie.get("mapDetAdiAtpa");

          if (detAdiAtpa != null
              && (detAdiAtpa.get("COD_INSUMO") != null || detAdiAtpa.get("CNT_UNIEQUI") != null || detAdiAtpa
                                                                                                             .get("COD_UMEQUI") != null))
          {

            Map<String, Object> detAdiAtpaNuevo = new HashMap();
            detAdiAtpaNuevo.put("numCorredoc", serie.get("NUM_CORREDOC"));
            detAdiAtpaNuevo.put("numSecserie", serie.get("NUM_SECSERIE"));

            boolean graba = false;

            if (detAdiAtpa.get("COD_INSUMO") != null && !"".equals(detAdiAtpa.get("COD_INSUMO").toString().trim()))
            {
              detAdiAtpaNuevo.put("codInsumo", detAdiAtpa.get("COD_INSUMO"));
              graba = true;
            }
            if (detAdiAtpa.get("COD_UMEQUI") != null && !"".equals(detAdiAtpa.get("COD_UMEQUI").toString().trim()))
            {
              detAdiAtpaNuevo.put("codUmEqui", detAdiAtpa.get("COD_UMEQUI"));
              graba = true;
            }

            if (detAdiAtpa.get("CNT_UNIEQUI") != null && !"".equals(detAdiAtpa.get("CNT_UNIEQUI").toString().trim())
                && !"0".equals(detAdiAtpa.get("CNT_UNIEQUI").toString().trim()))
            {
              detAdiAtpaNuevo.put("cntUniEqui", detAdiAtpa.get("CNT_UNIEQUI"));
              graba = true;
            }
            if (graba == true)
            {
              detAdiAtpaDAO.insertMapSelective(Utilidades.transformFieldsToRealFormat(detAdiAtpaNuevo));
            }

          }
        }

        //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
        //Actualizamos DET_ADI_IMPOCONSU
        mpDetAdiIC = new HashMap<String, Object>();
        mpDetAdiIC.put("NUM_CORREDOC", serie.get("NUM_CORREDOC"));
        mpDetAdiIC.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
        mpDetAdiIC.put("POR_ALCOHOL", serie.get("POR_ALCOHOL"));
         
        mpDetAdiICAnt = new HashMap<String, Object>();
        mpDetAdiICAnt.put("NUM_CORREDOC", serieAnt.get("NUM_CORREDOC"));
        mpDetAdiICAnt.put("NUM_SECSERIE", serieAnt.get("NUM_SECSERIE"));
        mpDetAdiICAnt.put("POR_ALCOHOL", serieAnt.get("POR_ALCOHOL"));
        
        detAdiICDif = soporteComparadorService.comparaMap(mpDetAdiIC, mpDetAdiICAnt, EnumTablaModel.DET_ADI_IMPOCONSU);
        
        if (soporteComparadorService.esDataCambiada(detAdiICDif)) {
        	DetAdiImpoconsuDAO detAdiICDAO =  fabricaDeServicios.getService("diligencia.rectificacion.detAdiImpoconsuDef_xa");
        	detAdiICDAO.update(mpDetAdiIC);
        	this.registrarRectiOficio(detAdiICDif, tipDilig, numCorredoc, Constantes.COD_TABLA_DET_ADI_IMPO_CONSU, numCorreDocSol);
        }
       
      } // for lsdetdeclara
    }// IF lsdetfeclar
  }
  
//P13 JMCV - INICIO**************************************************************************************************************************
  /**
   * M�todo que Busca si existe un elemento en la lista de Mapas
   * @param List<Map<String,Object>> : lista
   *                 String Key: key de la lista
   *                 String Valor: Valor de la lista
   *  @return boolean
   */
public boolean existeElementoEnListaDeMapas (
			List<Map<String, Object>> lista, String key, String valor) {

		if (!CollectionUtils.isEmpty(lista)) {
			for (Map<String, Object> item : lista) {
				//if (StringUtils.equals(valor,item.get(key))) { //corregir en el codigo
				if (StringUtils.equals(valor,(String) item.get(key))) {	
					return true;
				}
			}
		}

		return false;
	}   

/**
* Metodo que Valida ActaInmovilizaIncauta,validarNotificacionAsociadaDua,validarValidacionDescargasParciales, Asociadas a la Declaraci�n.
* @param request
*          the request
* @param response
*          the response
* @return the model and view
* */
	public String validarReconocimientoFisico(Map<String, Object> mapDeclaracionActual){
			
  	boolean existeIndicador = existeElementoEnListaDeMapas((List<Map<String,Object>>) 
  			mapDeclaracionActual.get("LIST_INDICADORES_DUA"),"COD_INDICADOR",ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
  	
  	String mensaje=StringUtils.EMPTY;
  	  	
  	String codCanal = (String) mapDeclaracionActual.get("COD_CANAL");
  	String codEstrev =(String) mapDeclaracionActual.get("COD_ESTREV");
	    
      if (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO) || (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) && existeIndicador)){
      	   
	  	   	  if (codEstrev.equals(ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_INCONCLUSO)){
	  	   		  //C�digo: 03-Reconocimiento f�sico inconcluso	  	   		  
	  	   		  mensaje = validarActaInmovilizaIncauta(mapDeclaracionActual);
	  	   	  }else if (codEstrev.equals(ConstantesDataCatalogo.DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO)){
	  	   		  //C�digo: 04-Despachador no se present� a reconocimiento f�sico
	   		  	  mensaje = validarActaInmovilizaIncauta(mapDeclaracionActual);
    	      }else if (codEstrev.equals(ConstantesDataCatalogo.DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO)){ 
    	    	  //C�digo: 05-Declaraci�n notificada sin realizar reconocimiento f�sico
    	          mensaje = validarActaInmovilizaIncauta(mapDeclaracionActual);
    	    	    if (StringUtils.EMPTY.equals(mensaje)){
    	    	    	mensaje=validarNotificacionAsociadaDua(mapDeclaracionActual);
    	    	    }
    	     }else if(codEstrev.equals(ConstantesDataCatalogo.INMOVILIZACION_TOTAL_DE_LA_MERCANCIA	)){
    	    	 //C�digo: 06-Inmovilizaci�n total de mercanc�a
    	    	 mensaje=StringUtils.EMPTY;
    	     }else if(codEstrev.equals(ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL)){ 
    	    	 //C�digo: 07-Reconocimiento f�sico de descarga parcial
    	    	 mensaje = validarValidacionDescargasParciales(mapDeclaracionActual);
    		     if (StringUtils.EMPTY.equals(mensaje)){
    		    	 mensaje = validarActaInmovilizaIncauta(mapDeclaracionActual);
    		     }
    	    }else if(codEstrev.equals(ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_CON_CONTINUACION)){ 
    	    	//C�digo: 08 Reconocimiento f�sico con continuaci�n de despacho
    	    	mensaje = validarActaInmovilizaIncauta(mapDeclaracionActual);
		   	    if (StringUtils.EMPTY.equals(mensaje)){
		   		    mensaje = validarDuaAcogidaGarantiaPrevia(mapDeclaracionActual);
		   	    }
	   	  	} 
     }
return mensaje.toString();
  }

	/**
 * Metodo (mensajeDuaAcogidaGarantiaPrevia) permite buscar a la seleccion N� 08 Reconocimiento f�sico con Continuaci�n de Despacho
 * permite consultar que en la entidad Declaraci�n, la DUA NO se encuentre ACOGIDA A LA GARANT�A PREVIA (Art�culo 160� de la LGA)
 * @param request
 *          the request
 * @param response
 *          the response
 * @return the string
 */ 	
public String validarDuaAcogidaGarantiaPrevia(Map<String, Object> declaracion){	
       String mensaje=StringUtils.EMPTY;
		if (!(StringUtils.EMPTY.equals(StringUtils.trimToEmpty(MapUtils.getMapValor(declaracion, "NUM_CTACTE", ""))))) {
		    mensaje = "DUA garantizada bajo el art�culo 160� de la LGA, no corresponde remitir a Continuaci�n de Despacho";
		}
		    return mensaje;
} 



//INICIO - MOFIFICADO PAS20155E220000054/23
/**
 * Metodo (mensajeValidacionDescargasParciales) permite buscar a la seleccion N� 07 Reconocimiento f�sico de descarga parcial
 * permite VALIDACIONES PARA EL CAT�LOGO DE DESCARGAS PARCIALES, que cumplan con las siguientes condiciones:
 * -ADUANA DEL SDA  // REGIMEN: 10 // MODALIDAD: 10 // SUBMODALIDAD: 04 // VIGENCIA: 99991231  // FECHA DE INICIO : 20141101
 * 
 * @param request
 *          the request
 * @param response
 *          the response
 * @return the string
 */ 
public String validarValidacionDescargasParciales(Map<String, Object> declaracion){
	  String mensaje="";
	  Map<String, Object> mapDescargaParcialRegimen = new HashMap<String, Object>();
	  
	  //Fecha  
	  Date fechaDeclaracion = SunatDateUtils.getDate(new SimpleDateFormat("dd/MM/yyyy").format(declaracion.get("FEC_DECLARACION")));
	  boolean existeAsoc=false;

	  mapDescargaParcialRegimen.put("type"       , "");
	  mapDescargaParcialRegimen.put("codAtributo", ConstantesAtributo.COD_ATRIBUTO_REGIMEN_ADUANERO_PARA_DESCARGAS_PARCIALES);
	  mapDescargaParcialRegimen.put("codGrupo"   , ConstantesGrupoCatalogo.COD_GRUPO_ADUANAS_DE_NUMERACION);
	  mapDescargaParcialRegimen.put("codCatalogo", ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA);
	  mapDescargaParcialRegimen.put("codDatacat" , declaracion.get("COD_ADUANA"));
	  mapDescargaParcialRegimen.put("fecha"     , fechaDeclaracion);
	  mapDescargaParcialRegimen.put("valatributo"     , declaracion.get("COD_REGIMEN"));
	  
	  List<Map<String, Object>> listDescargaParcialRegimen = ayudaServiceDataAtributo.buscar(mapDescargaParcialRegimen);
	  if (CollectionUtils.isEmpty(listDescargaParcialRegimen))
	  {
		 mensaje = "BAD";
	  }
	  else
	  {
		  if (!CollectionUtils.isEmpty(listDescargaParcialRegimen))
		  {
			  Map<String, Object> mapDescargaParcialModalidad = new HashMap<String, Object>();
			  mapDescargaParcialModalidad.put("type"       , "");
			  mapDescargaParcialModalidad.put("codAtributo", ConstantesAtributo.COD_ATRIBUTO_MODALIDAD_EN_DESCARGAS_PARCIALES);
			  mapDescargaParcialModalidad.put("codGrupo"   , ConstantesGrupoCatalogo.COD_GRUPO_ADUANAS_DE_NUMERACION);
			  mapDescargaParcialModalidad.put("codCatalogo", ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA);
			  mapDescargaParcialModalidad.put("codDatacat" , declaracion.get("COD_ADUANA"));
			  mapDescargaParcialModalidad.put("fecha"     , fechaDeclaracion);
			  mapDescargaParcialModalidad.put("valatributo"  , declaracion.get("COD_MODALIDAD"));
			  
			  List<Map<String, Object>> listDescargaParcialModalidad = ayudaServiceDataAtributo.buscar(mapDescargaParcialModalidad);
			  if (CollectionUtils.isEmpty(listDescargaParcialModalidad)){
				  mensaje = "BAD";
			  }
			  else{
				  if (!CollectionUtils.isEmpty(listDescargaParcialModalidad))
				  {
					  
					  Map<String, Object> mapDescargaParcialSubModalidad = new HashMap<String, Object>();
					  mapDescargaParcialSubModalidad.put("type"       , "");
					  mapDescargaParcialSubModalidad.put("codAtributo", ConstantesAtributo.COD_ATRIBUTO_SUBMODALIDAD_EN_DESCARGAS_PARCIALES);
					  mapDescargaParcialSubModalidad.put("codGrupo"   , ConstantesGrupoCatalogo.COD_GRUPO_ADUANAS_DE_NUMERACION);
					  mapDescargaParcialSubModalidad.put("codCatalogo", ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA);
					  mapDescargaParcialSubModalidad.put("codDatacat" , declaracion.get("COD_ADUANA"));
					  mapDescargaParcialSubModalidad.put("fecha"     , fechaDeclaracion);
					  mapDescargaParcialSubModalidad.put("valatributo"  , declaracion.get("COD_TIPLUGARRECEP"));
					  
					  List<Map<String, Object>> listDescargaParcialSubModalidad = ayudaServiceDataAtributo.buscar(mapDescargaParcialSubModalidad);
					  if (CollectionUtils.isEmpty(listDescargaParcialSubModalidad))
					  {
						  mensaje = "BAD";
					  }
					  else 
					  {
						  /// Validamos la Asociaci�n que existe entre Lugar de Descarga y Punto de Llegada
						  if (!CollectionUtils.isEmpty(listDescargaParcialSubModalidad))
						  {
							  Date fechaReferencia = SunatDateUtils.getCurrentDate();
							  List<Map<String, String>> listDescargaParcialSubModalidadvsPuntoLlegada =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_LUGAR_DE_DESCARGA_PUNTO_DE_LLEGAGA, "C",declaracion.get("COD_TIPLUGARRECEP").toString(),fechaReferencia);
							  if (!CollectionUtils.isEmpty(listDescargaParcialSubModalidadvsPuntoLlegada))
							  {	  for(Map codLugarrecep: listDescargaParcialSubModalidadvsPuntoLlegada){
									  if (codLugarrecep.get("cod_datacat").equals(declaracion.get("COD_LUGARRECEP").toString()))
									  {   existeAsoc=true;
										  break;
									  } 
							  		}
							  }
						else{
								  mensaje = "BAD";
								  if(log.isDebugEnabled())
									  log.debug("No se encuentr� asoaciaci�n de Lugar de Descarga y Punto de llega");
							  }
								  
							  
						  }
						  
					  }
				  }
			  }
  		  }
	  }
	  
	if ("BAD".equals(mensaje) || !existeAsoc)
	{
	//FIN  - MOFIFICADO PAS20155E220000054/23
		String regimen = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, (String) declaracion.get("COD_REGIMEN"));
		String reconocimientoFisicoDescargaParcial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO,ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL);
		
		String cod_tiplugarrecp = MapUtils.getMapValor(declaracion, "COD_TIPLUGARRECEP", StringUtils.EMPTY) ;
		String cod_tiplugarrecp_desc = MapUtils.getMapValor(declaracion, "COD_TIPLUGARRECEP_DESC", StringUtils.EMPTY);
		
		String submodalidad = StringUtils.EMPTY;
		if ( !StringUtils.isBlank( cod_tiplugarrecp ) && !StringUtils.isBlank( cod_tiplugarrecp_desc ) )
		{
			submodalidad =  cod_tiplugarrecp + " - " + cod_tiplugarrecp_desc;  			
		}  
		
		mensaje = "No se encuentra habilitada la vigencia para el uso del C�digo " + ConstantesDataCatalogo.RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL + " - " + reconocimientoFisicoDescargaParcial + 
				 	" \n para el R�gimen : " + declaracion.get("COD_REGIMEN") + " - " + regimen +", " + 
				 	" \n Modalidad : " + declaracion.get("COD_MODALIDAD") + " - " + declaracion.get("COD_MODALIDAD_DESC") + ", " +
		 	        " \n SubModalidad : " + submodalidad;
		
	}	  
 return mensaje;
}


/**
 * Metodo (mensajeNotificacionAsociadaDua) permite validar a la seleccion N� 05 Declaraci�n notificada sin realizar reconocimiento f�sico.
 * ---Permite validar si la Notificaci�n asociada a la DUA NO se encuentra registrada
 *
 * @return the string
 */ 
public String validarNotificacionAsociadaDua(Map<String, Object> declaracion){
	  String mensaje=StringUtils.EMPTY;
	      List<Map<String, Object>> listComunicacion = diligenciaService.obtenerComunicaciones(declaracion);            

	      if (CollectionUtils.isEmpty(listComunicacion)){
	    	  mensaje = "Registre previamente su notificaci�n";
	      }
	      
	      return mensaje;
} 

/**
 * Metodo (mensajeActaInmovilizaIncauta) Permite validar Si existe un Acta de Inmovilizaci�n-Incautaci�n 
 * registrada en el SIGEDA por el �total� de las mercanc�as
 * 
 * @param request
 *          the request
 * @param response
 *          the response
 * @return the string
 */ 
public String validarActaInmovilizaIncauta(Map<String, Object> declaracion){
    
    StringBuilder mensaje = new StringBuilder(3000);
    
    Map<String, String> mapSerie = new HashMap<String, String>();
    
    mapSerie.put("cod_regimen", (String) declaracion.get("COD_REGIMEN"));
    mapSerie.put("cod_aduana", (String) declaracion.get("COD_ADUANA"));
    /** Inicio bug rin10 no corresponde al requerimiento pero se corrigio bug **/
    String anioPresentacionDUA ="";
    if(declaracion.get("ANN_PRESEN")!=null){
    	if(declaracion.get("ANN_PRESEN") instanceof String){
    		anioPresentacionDUA = (String)declaracion.get("ANN_PRESEN");
    	}else if(declaracion.get("ANN_PRESEN") instanceof BigDecimal){
    		anioPresentacionDUA = ((BigDecimal)declaracion.get("ANN_PRESEN")).toString();
    	}    	
    }    
    /** Fin bug rin10 no corresponde al requerimiento pero se corrigio bug **/	
    mapSerie.put("ann_presen", anioPresentacionDUA);
	//mapSerie.put("ann_presen", ((BigDecimal) declaracion.get("ANN_PRESEN")).toString());
    mapSerie.put("num_declaracion", ((BigDecimal) declaracion.get("NUM_DECLARACION")).toString());
    mapSerie.put("acceso", "00");
    
    List<Map<String, Object>> listSerie = serieService.obtenerListadoSeries(mapSerie);
    
    
    Map<String,Object> mapAccionesDeControlExtraordinario = new HashMap<String, Object>();
    
    mapAccionesDeControlExtraordinario.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
    mapAccionesDeControlExtraordinario.put("ANN_PRESEN", declaracion.get("ANN_PRESEN"));
    mapAccionesDeControlExtraordinario.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
    mapAccionesDeControlExtraordinario.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION"));
    mapAccionesDeControlExtraordinario.put("LIST_SERIES", listSerie);
  	mapAccionesDeControlExtraordinario.put("viewTotal", "true"); // true : Acta de Inmovilizacion - Incautacion por el Total de las Mercanc�as
  																 //  false : Acta de Inmovilizacion - Incautacion parcial de las Mercanc�as
  	//--------------------------------------------------------------------------------------------------------------
	//Acciones de Control Extraordinario(Actas de Inmovilizacion de Duas y Manifiestos y Avisos de Inspeccion )
	Map<String,Object> mapAces = soporteService.obtenerAccionesDeControlExtraordinario(mapAccionesDeControlExtraordinario);
	List<Map<String,Object>> listDuaActas =(List<Map<String,Object>>) mapAces.get("aces");
	//--------------------------------------------------------------------------------------------------------------
	if(!CollectionUtils.isEmpty(listDuaActas))
	{
		for(Map<String, Object> actaDua : listDuaActas)
	    {
			String nroCortoActaInmovilizaIncauta = (String) actaDua.get("NROCORTO");  
			mensaje.append("DUA registra Acta de Inmovilizaci�n - Incautaci�n Total N� ");
			mensaje.append(nroCortoActaInmovilizaIncauta);
	    }
	}
  return mensaje.toString(); 
} 


/**
 * Metodo que efectua la grabacion del Reconocimiento F�sico de la Mercancia.
 *
 * @param request
 *          the request
 * @param response
 *          the response
 * @return the model and view
 * @throws Exception
 *           the exception
 */
public String grabarRevisionReconocimientoFisico(Map<String, Object> declaracion){
	  
	  String mensaje=StringUtils.EMPTY;
	  Map<String, Object> params = new HashMap<String, Object>();
	  Map<String, Object> mapUpdateDeclaracion = new HashMap<String, Object>();
	  
	  boolean existeIndicador = existeElementoEnListaDeMapas((List<Map<String,Object>>) declaracion.get("LIST_INDICADORES_DUA"),
				"COD_INDICADOR",
				ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
	  
	  String codCanal = String.valueOf(declaracion.get("COD_CANAL"));
	  String codEstRev = String.valueOf(declaracion.get("COD_ESTREV"));
    
	  if (existeIndicador){
		  params.put("cod_indicador_dua", ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
	  }else{
		  params.put("cod_indicador_dua", declaracion.get("cod_indicador_dua"));
	  }
		  
	  params.put("num_corredoc",declaracion.get("NUM_CORREDOC"));
	  params.put("cod_estrev",declaracion.get("COD_ESTREV"));
	  params.put("cod_funcionario",declaracion.get("cod_funcionario"));
	  params.put("cod_canal",declaracion.get("COD_CANAL"));
      params.put("COD_REGIMEN", declaracion.get("COD_REGIMEN"));
      params.put("COD_ADUANA", declaracion.get("COD_ADUANA"));
      params.put("ANN_PRESEN", declaracion.get("ANN_PRESEN"));
      params.put("NUM_DECLARACION", declaracion.get("NUM_DECLARACION")); 
      params.put("EN_PROCESO", "0");
	  mapUpdateDeclaracion.put("NUM_CORREDOC",declaracion.get("NUM_CORREDOC"));
    
    if (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO) || (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) && existeIndicador)){	      
	    	  
	    	  //C�digo: 03-Reconocimiento f�sico inconcluso
		      if (codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_INCONCLUSO)) {
		    	
			    	params.put("cod_tipasig", "R");
			    	  
			    	this.grabarRevision(params);
			    	
			    	mapUpdateDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			    	
			    	declaracionService.updateDeclaracion(mapUpdateDeclaracion);
			    	
			    	mensaje="Se guard� satisfactoriamente el resultado del Reconocimiento F�sico de la DUA";

		      }else if ((codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO) || 
		    		  codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO) )){
			      //C�digo: 04-Despachador no se present� a reconocimiento f�sico
			      //C�digo: 05-Declaraci�n notificada sin realizar reconocimiento f�sico    	  

		    	  params.put("cod_tipasig", "R");
		    	  
		    	  this.grabarRevision(params);
		    	  
		    	  mapUpdateDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_RECEPCIONADO);
		    	  
		    	  declaracionService.updateDeclaracion(mapUpdateDeclaracion);
		    	  
		    	  if (codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO)){
		    		  mensaje="Se guard� satisfactoriamente el resultado del Reconocimiento F�sico de la DUA";
		    	  }else{
		    		  mensaje="Se guard� satisfactoriamente el resultado de la DUA asignada a reconocimiento f�sico";
		    	  }
		    	  
		    	  // hosorio rin 12
		    	  // registrar en anfora
		    	  declaracion.put("COD_MOTIVOREVISION", codEstRev);
				  registroAnforaDiligeciaReconocimientoFisico04_05(declaracion);

				  
				// contador de registros de reconocimiento fisico en estado 04 o 05
			  	  actualizarContadorReconoFisico04_05(declaracion);		
		    	  
		      }else if ((codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_INMOVILIZACION_TOTAL_DE_LA_MERCANCIA))){
	      		  //C�digo: 06-Inmovilizaci�n total de mercanc�a  
	      		  params.put("cod_tipasig", "R");
		    	  
		    	  this.grabarRevision(params);
		    	  
		    	  mapUpdateDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
		    	  
		    	  declaracionService.updateDeclaracion(mapUpdateDeclaracion);
		    	  
		    	  mensaje="Se guard� satisfactoriamente el resultado del Reconocimiento F�sico de la DUA";
		    	  
	      	  }else if ((codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_DESCARGA_PARCIAL)) || 
	      			(codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_FISICO_CON_CONTINUACION))){
	      		  //C�digo: 07-Reconocimiento f�sico de descarga 
		      	  //C�digo: 08 Reconocimiento f�sico con continuaci�n de despacho.
	      		  params.put("cod_tipasig", "R");
		    	  
		    	  this.grabarRevision(params);
		    	  
		    	  mensaje="Se guard� satisfactoriamente el resultado del Reconocimiento F�sico de la DUA";
	      	  }
    		
    }
    else{
  	  
  	  this.grabarRevision(params);
  	  
  	  mensaje="Se guard� satisfactoriamente la revisi�n";
  	  
    }

    // hosoriov asignacion en bloque
	  // hosoriov rin 12
    
    if ((codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_DESPACHADOR_NO_SE_PRESENTO_RECONO_FISICO) || 
  		  codEstRev.equals(ConstantesDataCatalogo.COD_EST_REVISION_DECLARACION_NOTIFICADA_SIN_REALIZAR_RECONO_FISICO) )){    
			  if(codCanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO) ||
				 codCanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)  
					  ){

				  Declaracion declara=new Declaracion();
				  declara.setDua(new DUA());
				  
				   declara.getDua().setNumcorredoc(((BigDecimal)declaracion.get("NUM_CORREDOC")).longValue());

				  declara.getDua().setCodEstdua((String)declaracion.get("COD_ESTDUA"));
				  declara.getDua().setCodregimen((String) declaracion.get("COD_REGIMEN"));
				  declara.getDua().setCodaduanaorden( (String) declaracion.get("COD_ADUANA"));
				  declara.getDua().setAnnpresen(Integer.parseInt(((String)declaracion.get("ANN_PRESEN"))));
				  declara.setNumeroDeclaracion(Long.valueOf((String) declaracion.get("NUM_DECLARACION")));
				  declara.getDua().setCodmodalidad((String)declaracion.get("COD_MODALIDAD"));
				  
				  //hosoriov 179
				  asignacionService.registrarDeclaracionAnfora(declara, codEstRev);
				  }}	  
return mensaje;
}





/**
* Metodo que permite Validar registro de resultado de revisi�n para diligencia
* Si el estado registrado como RESULTADO DE LA REVISI�N del reconocimiento f�sico en la SECCI�N 03, es igual a 06, el sistema deber� validar:
* S� existe un Acta de Inmovilizaci�n-Incautaci�n registrada en el SIGEDA por el �total� de las mercanc�as debe contar con:
* 1)	Una Resoluci�n (C�digo. 02, 12, 29, 55, 141, 143, 186, 214) o
* 2)	Un Acta de Verificaci�n (C�digo 171), asociada a la DUA. (Ver ANEXO 04).
*
*
* @param String declaracion  
* @return mensaje.toString()
*/

public String validarRevisionToProcesoDeInmovilizacionTotalDeLaMercancia(Map<String, Object> declaracion){

	  StringBuilder mensaje = new StringBuilder(3000);
  	  Map<String, String> pkDiligencia = new HashMap<String, String>();
  	  
  	  pkDiligencia.put("viewRevision","true");
  	  pkDiligencia.put("NUM_CORREDOC",String.valueOf(declaracion.get("NUM_CORREDOC")));
  	  
 	  List<Map<String, Object>> lstDiligencia = diligenciaService.obtenerDiligencias(pkDiligencia);
 	 /* PAS20145E220000399 INICIO GGRANADOS */
//  	  String CodCanal = String.valueOf(declaracion.get("COD_CANAL"));
//  	  String codCatalogoEvaluar="";
  	/* PAS20145E220000399 FIN GGRANADOS */
  	  boolean tieneInmovilizacionTotalMercancia=false;
  	  boolean tieneEstadoReconocimientoInmovilizacionTotal=false;
  	/* PAS20145E220000399 INICIO GGRANADOS */
//  	  codCatalogoEvaluar = ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO;
  	/* PAS20145E220000399 INICIO GGRANADOS */
  	  if (!CollectionUtils.isEmpty(lstDiligencia)){
  		  
  		  String tipoDiligencia = "";
  		/* PAS20145E220000399 INICIO GGRANADOS */
//		  String codCatalogo 	= "";
		/* PAS20145E220000399 FIN GGRANADOS */
			  String cod_estrev 	= "";
			  
  		  for (Map<String, Object> mapDiligencia : lstDiligencia){
  			  
  			  tipoDiligencia = String.valueOf(mapDiligencia.get("COD_TIPDILIGENCIA")).trim();
  			/* PAS20145E220000399 INICIO GGRANADOS */
//  			  codCatalogo 	 = String.valueOf(mapDiligencia.get("COD_CATALOGO")).trim();
  			/* PAS20145E220000399 FIN GGRANADOS */
  			  cod_estrev 	 = String.valueOf(mapDiligencia.get("COD_MOTIVO")).trim();
  			  
  			  if((tipoDiligencia.equals(ConstantesDataCatalogo.COD_DILIG_REV) || 
  				 tipoDiligencia.equals(ConstantesDataCatalogo.COD_DILIG_REV_DOC) ||
  				 tipoDiligencia.equals(ConstantesDataCatalogo.COD_DILIG_REC_FIS) ||
  				 tipoDiligencia.equals(ConstantesDataCatalogo.COD_DILIG_REV_CON))){  				  
  				  tieneInmovilizacionTotalMercancia=true;
  				  if (cod_estrev.equals(ConstantesDataCatalogo.INMOVILIZACION_TOTAL_DE_LA_MERCANCIA)){
  					tieneEstadoReconocimientoInmovilizacionTotal=true;
  				  }
  				  
  			  }
  		  }
  		  
  	  }
  	  
  	  if (tieneInmovilizacionTotalMercancia){
  	  					  
  		 mensaje.append(validarActaInmovilizaIncauta(declaracion));
		  
		  if (!StringUtils.EMPTY.equals( mensaje.toString() ) )
		  {
				  Map<String, Object> mapResolucionOActaVerificacionConDUA = new HashMap<String, Object>();
				  String tipodoc = "";
				  
				  String codRegimen = StringUtils.trimToEmpty( (String) declaracion.get("COD_REGIMEN"));
				  
				  if ((codRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))){ //Regimen=10
					  tipodoc = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_DEFINITIVA; //=17 
				  }else{
					  if ((codRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO))){ //Regimen=20
						  tipodoc = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_EXPORTACION_TEMPORAL; //=31
					  }else{
						  if ((codRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO))){ //Regimen=21
							  tipodoc = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_TEMPORAL; //=32
						  }else{
							  if ((codRegimen.equals(Constantes.REGIMEN_70_DEPOSITO))){ //Regimen=70
								  tipodoc = ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_DEPOSITO; // = 40
							  }
						  }
					  }
				  }
	
				  mapResolucionOActaVerificacionConDUA.put("tipodoc", tipodoc);
				  mapResolucionOActaVerificacionConDUA.put("codiAdua",  declaracion.get("COD_ADUANA").toString());
				  mapResolucionOActaVerificacionConDUA.put("dresAnno", declaracion.get("ANN_PRESEN").toString());
				  mapResolucionOActaVerificacionConDUA.put("dresNro", declaracion.get("NUM_DECLARACION").toString());
				  mapResolucionOActaVerificacionConDUA.put("codigoAduana",declaracion.get("COD_ADUANA").toString());
				  mapResolucionOActaVerificacionConDUA.put("ldres_tip", new String[]{ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_INTENDENCIA,ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_GERENCIA,
						  ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_DE_DIVISION,ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_DE_INTENDENCIA_NACIONAL,ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_JEFATURAL_DE_DEPARTAMENTO,
						  ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_JEFATURAL_143,ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_JEFATURAL_186,ConstantesDataCatalogo.COD_DCTO_TRAMITE_RESOLUCION_OFICINA});
				  
				  	List<Map<String, Object>> listResolucionConDUA = resolucionService.obtenerResolucionConTransbordo(mapResolucionOActaVerificacionConDUA);

				  	Map<String, Object> PkDecla = new HashMap<String, Object>();
				  	
			  	  	PkDecla.put("tipodoc", ConstantesDataCatalogo.COD_DCTO_TRAMITE_ACTA_DE_VERIFICACION);
			  	  	PkDecla.put("codi_adua",  declaracion.get("COD_ADUANA").toString());
			  	    PkDecla.put("codigoAduana",  declaracion.get("COD_ADUANA").toString());
			  	  	PkDecla.put("annoref", declaracion.get("ANN_PRESEN").toString());
			  	  	PkDecla.put("numeref", declaracion.get("NUM_DECLARACION").toString());
		  	  		
		  	  		List<Map<String, Object>> listActaVerificacionConDUA = documentoInternoService.obtenerDocInternoTransbordo(PkDecla);
				  
					if (!CollectionUtils.isEmpty(listResolucionConDUA) && (CollectionUtils.isEmpty(listActaVerificacionConDUA)))
			  	  	{
						mensaje.setLength(0);
			  	  	}else
			  	  	 { 
						if (CollectionUtils.isEmpty(listResolucionConDUA) && (!CollectionUtils.isEmpty(listActaVerificacionConDUA)))
						{
							mensaje.setLength(0);	
						}else
							{
								mensaje.append(" y No cuenta con Resoluci�n y/o Acta de Verificaci�n");
							}
				  	 }
		}			  
		else
		{
			if (tieneEstadoReconocimientoInmovilizacionTotal){
			  mensaje.append("No existe un Acta de Incautaci�n - Inmovilizaci�n registrada en el SIGEDA por el total de las mercanc�as");
			}
		}
   }		
	  return mensaje.toString();  
}

/**
   * Metodo que permite encontrar los Documentos en Estado de Revision
   *
   * @param Long numCorredoc
   *        String estadoAsig  
   * @param Map<String, Object>
   *         Mapa de Documentos en Estado de Revision
   * @return the model and view
   */
  public Map<String, Object> findbyDocEstRev(Long numCorredoc, String estadoAsig) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", numCorredoc);
		params.put("COD_ESTREV", estadoAsig);
		return espeDocuDAO.findbyDocEstRev(params);
	}

//P13 JMCV - FIN *****************************************************************************************************************

	/*P14 - 3014 - Inicio - dhernandezv*/
	
	/**
	 *
	 * Obtiene las notificaciones de una declaracion determinada
	 *
	 * @param params
	 *
	 * @return List<Map<String,Object>>
	 * @throws ServiceException
	 */
	@Override
	public List<ComunicacionDescripcion> obtenerNotificaciones(
			Map<String, Object> params) throws ServiceException {
		
		List<ComunicacionDescripcion> listNotificaciones = new ArrayList<ComunicacionDescripcion>();
		
		if (log.isDebugEnabled()) {
			log.debug(this.toString().concat(" obtenerNotificaciones- INICIO."));
		}
		try {
						
			listNotificaciones = this.comunicacionDAO.obtenerNotificaciones(params);
			
			for (ComunicacionDescripcion notificacion : listNotificaciones) {
				
				notificacion.setDesNota(obtenerConsolidadoDetalleNotificacion(notificacion));
			}		
			
		} catch (DataAccessException e) {
			log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		} catch (Exception e) {
			log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		} finally {
		}
		if (log.isDebugEnabled()) {
			log.debug(this.toString().concat(" obtenerNotificaciones- FIN."));
		}
		return listNotificaciones;
	}
	
	/**
	 *
	 * Obtiene los detalles de una notificacion determinada
	 *
	 * @param params
	 *
	 * @return List<Map<String,Object>>
	 * @throws ServiceException
	 */
	private String obtenerDetalleNotificacion(ComunicacionDescripcion notificacion) {
		
		StringBuilder filaHTML = new StringBuilder();
		filaHTML.append("<div align='center'> <table>");
		DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
		
		try{
			
			DetalleComunicacion dc = new DetalleComunicacion();
			dc.setNumNota(notificacion.getNumNota());
			
			List<DetalleComunicacion> lstDetalleNotificacion = detalleComunicacionDAO.findDetalleComunicacionNotificacion(dc);
			boolean indRenderCabecera = true;
			
			String cabeceraActual="";			
			String cuerpoActual="";
			
			for (DetalleComunicacion deNot : lstDetalleNotificacion) {
			
				HashMap<String, Object> detalleNotificacion = (HashMap<String, Object>) new JsonSerializer().deserialize(deNot.getDesDetalle(), HashMap.class);
				
				if(indRenderCabecera == true){
					filaHTML.append("<tr>");
					for ( int numColumna=0; numColumna< detalleNotificacion.size(); numColumna++ ) {
						filaHTML.append("<th>");
						cabeceraActual = obtenerCabCuerpoDetalle(notificacion.getCodMotNoti(), numColumna);					
						filaHTML.append(cabeceraActual.toUpperCase().replace("_", " "));
						filaHTML.append("</th>");
					}
					filaHTML.append("<tr>");
					indRenderCabecera = false;
				}
				
				
				
				//p24 PAS20165E220200099
				filaHTML.append("<tr>");
				for ( int numColumna=0; numColumna< detalleNotificacion.size(); numColumna++ ) {
					filaHTML.append("<td style='text-align: justify; text-justify: inter-word;'>");
					cabeceraActual = obtenerCabCuerpoDetalle(notificacion.getCodMotNoti(), numColumna);
					cuerpoActual   =  (detalleNotificacion.get(cabeceraActual)==null) ? "" : detalleNotificacion.get(cabeceraActual).toString();
					filaHTML.append(cuerpoActual);					
					filaHTML.append("</td>");
				}
				filaHTML.append("<tr>");
			}
			
		} catch (DataAccessException e) {
			log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		} catch (Exception e) {
			log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}
			
		filaHTML.append("</table></div>");			
		return filaHTML.toString();
	}
	
	/**
	 *
	 * Obtiene la cabecera del cuerpo del detalle de Notificacion
	 *
	 * @param params
	 *
	 * @return List<Map<String,Object>>
	 * @throws ServiceException
	 */
	private String obtenerCabCuerpoDetalle(String codMotivoNotificacion, int numColumna){
		String cabecera="";
						
		if (COD_MOTIVO_NOTIFICACION_02.equals(codMotivoNotificacion)) {
			switch (numColumna)
			{
				case 0: cabecera = "serie"; break;
				case 1: cabecera = "valor_observado_por_unidad_(us$_por_unidad)"; break;
				case 2: cabecera = "referencia_(declaracion)"; break;			
			}
		}else if (COD_MOTIVO_NOTIFICACION_03.equals(codMotivoNotificacion)) {
			switch (numColumna)
			{
				case 0: cabecera = "serie"; break;
				case 1: cabecera = "subpartida_nacional_declarada"; break;
				case 2: cabecera = "subpartida_nacional_propuesta"; break;
			}
		}else if (COD_MOTIVO_NOTIFICACION_05.equals(codMotivoNotificacion)) {
			switch (numColumna)
			{
				case 0: cabecera = "serie"; break;
				case 1: cabecera = "subpartida_nacional"; break;
				case 2: cabecera = "derecho_antidumping_(%)"; break;
			}
		}else if (COD_MOTIVO_NOTIFICACION_08.equals(codMotivoNotificacion)){
			switch (numColumna){
				case 0: cabecera = "serie"; break;
				case 1: cabecera = "sector_autoriza_ingreso"; break;
				case 2: cabecera = "documento"; break;
			}			
		}else if ("09".equals(codMotivoNotificacion)){
			switch (numColumna){
			case 0: cabecera = "descripcionRecFisicioOficio"; break; 
		}			
		}
		return cabecera;
	}

	/*P14 - 3014 - Fin - dhernandezv*/
	
  @Override
  public List<Map<String, Object>> selectDiligencia(Map params)
  		throws ServiceException {
	  return cabDiligenciaDAO.select(params);
  }


  /**INICIO RIN14 - KAH **/
  public String validarDocumentosControlAutorizantes(Map camposFormulario) {
	  String mensaje=null;
	  CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
	  ArrayList<String> camposObligatorios=new ArrayList<String>();
	  if(StringUtil.esVacio(camposFormulario.get("codigoEntidad").toString())){
		  camposObligatorios.add("ENTIDAD");
	  }
	  if(StringUtil.esVacio(camposFormulario.get("codigoSubEntidad").toString())){
		  camposObligatorios.add("SUB ENTIDAD");
	  }
	  if(StringUtil.esVacio(camposFormulario.get("codigoDocumentoControl").toString())){
		  camposObligatorios.add("C�DIGO Y DOCUMENTO DE CONTROL");
	  }
	  if(StringUtil.esVacio(camposFormulario.get("numeroDocumento").toString())){
		  camposObligatorios.add("N�MERO DE DOCUMENTO");
	  }
	  
	  boolean validarFechaEmision = true;
	  if(!StringUtil.esVacio(camposFormulario.get("codigoDocumentoControl").toString()) && "20".equals(camposFormulario.get("codigoDocumentoControl")))
		  validarFechaEmision = false;
	  if(!StringUtil.esVacio(camposFormulario.get("codigoDocumentoControl").toString()) && "21".equals(camposFormulario.get("codigoDocumentoControl")))
		  validarFechaEmision = false;
	  if(validarFechaEmision){	  
		  if(camposFormulario.get("fechaEmision")==null || StringUtil.esVacio(camposFormulario.get("fechaEmision").toString())){
		  camposObligatorios.add("FECHA DE EMISI�N");
	  }
	  }
	  if(camposObligatorios.isEmpty()){
		  
		  if(validarFechaEmision){
		  String[] obtenerddmmyyyyFechaEmision = camposFormulario.get("fechaEmision").toString().split("-");
	
		  FechaBean fechaDiligencia=new FechaBean();
		  FechaBean fechaEmision=new FechaBean(obtenerddmmyyyyFechaEmision[2]+"/"+obtenerddmmyyyyFechaEmision[1]+"/"+obtenerddmmyyyyFechaEmision[0]); 
		  
		  String entidad=camposFormulario.get("codigoEntidad").toString();
		  String subEntidad=camposFormulario.get("codigoSubEntidad").toString();
		  String documentoControl=camposFormulario.get("codigoDocumentoControl").toString();
		  String codigoRegimen=camposFormulario.get("codRegimen").toString();
		  
		  int compararFechaEmisionFechaDiligencia=FechaBean.compareDate(fechaEmision.getSQLDate(), fechaDiligencia.getSQLDate());
	  
	  
		  if(!entidad.equalsIgnoreCase("30")){
			if(compararFechaEmisionFechaDiligencia<=0){
				if(validacionObligatoriedadFechaVencimiento(validacionesPorEntidadDigemid(entidad,subEntidad,documentoControl), 
				   validacionesPorEntidadDigesa(entidad,subEntidad,documentoControl),
				   validacionesPorEntidadMtc(entidad, subEntidad, documentoControl, codigoRegimen),
				   validacionesPorEntidadOto(entidad, subEntidad, documentoControl),
				   validacionesPorEntidadProduce(entidad, subEntidad, documentoControl), 
				   validacionesPorEntidadSenasa(entidad, subEntidad, documentoControl))){
					
					if(!camposFormulario.get("fechaVencimiento").equals("")){
						String[] obtenerddmmyyyyFechaVencimiento = camposFormulario.get("fechaVencimiento").toString().split("-");
						FechaBean fechaVencimiento=new FechaBean(obtenerddmmyyyyFechaVencimiento[2]+"/"+obtenerddmmyyyyFechaVencimiento[1]+"/"+obtenerddmmyyyyFechaVencimiento[0]);
						int compararFechaVencimientoFechaEmision=FechaBean.compareDate(fechaVencimiento.getSQLDate(),fechaEmision.getSQLDate());
						
						if(compararFechaVencimientoFechaEmision>=0){
							mensaje="ok";
						}else{
							Map<String, String>error= catalogoAyudaService.getError("35398");
							mensaje=error.get("desError");
							//mensaje="La fecha de vencimiento no puede ser menor que la fecha de emisi�n";
						}						
					}else{						
						Map<String, String>error= catalogoAyudaService.getError("35399");
						mensaje=error.get("desError");
						//mensaje="Debe ingresar la fecha de vencimiento";
					}	
					
				}else{
					if(!camposFormulario.get("fechaVencimiento").equals("")){	
						String[] obtenerddmmyyyyFechaVencimiento = camposFormulario.get("fechaVencimiento").toString().split("-");
						FechaBean fechaVencimiento=new FechaBean(obtenerddmmyyyyFechaVencimiento[2]+"/"+obtenerddmmyyyyFechaVencimiento[1]+"/"+obtenerddmmyyyyFechaVencimiento[0]);
						int compararFechaVencimientoFechaEmision=FechaBean.compareDate(fechaVencimiento.getSQLDate(),fechaEmision.getSQLDate());
						
						if(compararFechaVencimientoFechaEmision>=0){
							mensaje="ok";
						}else{
							Map<String, String>error= catalogoAyudaService.getError("35398");
							mensaje=error.get("desError");
							//mensaje="La fecha de vencimiento no puede ser menor que la fecha de emisi�n";
						}						
					}else{						
						mensaje="ok";
					}
				}
			}else{
				  Map<String, String>error= catalogoAyudaService.getError("35397");
				  mensaje=error.get("desError");
				//mensaje="La fecha de emisi�n no puede ser mayor que la fecha de la diligencia";
			}  
		  }else{
			  Map<String, String>error= catalogoAyudaService.getError("35400");
			  mensaje=error.get("desError");
			  //mensaje="No se puede seleccionar la entidad 30 por corresponder a una Autorizaci�n IQBF";
		  }
		  
		  }else{
			  mensaje="ok";
		  }
	  }else{
		  String descripcionErrores="";

		  for (String campos : camposObligatorios) {
			  descripcionErrores=descripcionErrores.concat(",").concat(campos);
		  }
		  String descripcionErroresAux=descripcionErrores.trim().substring(1, descripcionErrores.length());
		  Map<String, String>error= catalogoAyudaService.getError("35395", new String[]{descripcionErroresAux});
		  mensaje=error.get("desError");
	  }
	  
  	return mensaje;
  }
  
  public boolean validacionObligatoriedadFechaVencimiento(boolean digemid,boolean digesa,boolean oto,boolean produce,boolean senasa,boolean mtc){
	  boolean flagValidacionGeneral = false;
	  if(digemid || digesa || oto || produce || senasa || mtc){
		  flagValidacionGeneral=true;
	  }
	  return flagValidacionGeneral;
  }
  
  public boolean validacionesPorEntidadDigemid(String entidad, String subEntidad, String documentoControl){
	  boolean flagDigemid = false;
	  
	  if(entidad.equalsIgnoreCase("03")){
		  if(subEntidad.equalsIgnoreCase("0301")){
			  if(documentoControl.equalsIgnoreCase("03") || documentoControl.equalsIgnoreCase("08") || documentoControl.equalsIgnoreCase("16")){
				  flagDigemid=true;
			  }
		  }else if(subEntidad.equalsIgnoreCase("0302")){
			  if(documentoControl.equalsIgnoreCase("02") || documentoControl.equalsIgnoreCase("03")){
				  flagDigemid=true;
			  }
		  }
	  }
	  
	  return flagDigemid;
  }
  
  public boolean validacionesPorEntidadDigesa(String entidad, String subEntidad, String documentoControl){
	  boolean flagDigesa = false;
	  
	  if(entidad.equalsIgnoreCase("04")){
		  if(subEntidad.equalsIgnoreCase("0401")){
			  if(documentoControl.equalsIgnoreCase("03") || documentoControl.equalsIgnoreCase("08")){
				  flagDigesa=true;
			  }
		  }else if(subEntidad.equalsIgnoreCase("0403")){
			  if(documentoControl.equalsIgnoreCase("02") || documentoControl.equalsIgnoreCase("16")){
				  flagDigesa=true;
			  }
		  }else if(subEntidad.equalsIgnoreCase("0404") || subEntidad.equalsIgnoreCase("0405") || subEntidad.equalsIgnoreCase("0406") || subEntidad.equalsIgnoreCase("0407")){
			  if(documentoControl.equalsIgnoreCase("02") ){
				  flagDigesa=true;
			  }
		  }
	  }
	  
	  return flagDigesa;
  }
  
  public boolean validacionesPorEntidadOto(String entidad, String subEntidad, String documentoControl){
	  boolean flagOto = false;
	  
	  if(entidad.equalsIgnoreCase("18")){
		  if(subEntidad.equalsIgnoreCase("1802")){
			  if(documentoControl.equalsIgnoreCase("10")){
				  flagOto=true;
			  }
		  }
	  }
	  
	  return flagOto;
  }
  
  public boolean validacionesPorEntidadProduce(String entidad, String subEntidad, String documentoControl){
	  boolean flagProduce = false;
	  
	  if(entidad.equalsIgnoreCase("27")){
		  if(subEntidad.equalsIgnoreCase("2701") || subEntidad.equalsIgnoreCase("2702") || subEntidad.equalsIgnoreCase("2703")){
			  if(documentoControl.equalsIgnoreCase("04")){
				  flagProduce=true;
			  }
		  }
	  }
	  
	  return flagProduce;
  }
  
  public boolean validacionesPorEntidadSenasa(String entidad, String subEntidad, String documentoControl){
	  boolean flagSenasa = false;
	  
	  if(entidad.equalsIgnoreCase("05")){
		  if(subEntidad.equalsIgnoreCase("0503")){
			  if(documentoControl.equalsIgnoreCase("09")){
				  flagSenasa=true;
			  }
		  }
	  }
	  
	  return flagSenasa;
  }
  
  public boolean validacionesPorEntidadMtc(String entidad, String subEntidad, String documentoControl,String codigoRegimen){
	  boolean flagMTC = false;
	  
	  if(codigoRegimen.equalsIgnoreCase("20") || codigoRegimen.equalsIgnoreCase("21")){
		  if(entidad.equalsIgnoreCase("08")){
			  if(subEntidad.equalsIgnoreCase("0801")){
				  if(documentoControl.equalsIgnoreCase("09")){
					  flagMTC=true;
				  }
			  }
		  }
	  }
	  
	  return flagMTC;
  }
  /**FIN RIN14 - KAH **/

	/* P14 - 3006 - Inicio - lrodriguezc */
	
	@Override
	public List<ComunicacionDescripcion> obtenerComunicacionesPendientes (Long numCorreDoc) throws ServiceException{
		
		List lista = null;
		
		try {
			lista = comunicacionDAO.findPendientesByNumCorreDoc(numCorreDoc);
		} catch (DataAccessException e) {
			log.error("*** ERROR ***", e);
			throw new ServiceException(e, e.getMessage());
		} catch (Exception e) {
			log.error("*** ERROR ***", e);
			throw new ServiceException(e, e.getMessage());
		}
		
		return lista;
		
	}
	
	@Override
	public String formatearDetalleNotificacion(Map<String, Object> detalleNotificacion, String motivoNotificacion) throws ServiceException {
		
		String detalleFinal = "";
		List<String> camposTipo = new ArrayList<String>();
		
		if (COD_MOTIVO_NOTIFICACION_02.equals(motivoNotificacion)) {
			
			camposTipo.add("serie");
			camposTipo.add("valor_observado_por_unidad");
			camposTipo.add("referencia");
			
			detalleFinal = this.reorganizarDetalleNotificacion(detalleNotificacion, camposTipo);
			
		} else if (COD_MOTIVO_NOTIFICACION_03.equals(motivoNotificacion)) {
			
			camposTipo.add("serie");
			camposTipo.add("subpartida_nacional_declarada");
			camposTipo.add("subpartida_nacional_propuesta");
			
			detalleFinal = this.reorganizarDetalleNotificacion(detalleNotificacion, camposTipo);
			
		} else if (COD_MOTIVO_NOTIFICACION_05.equals(motivoNotificacion)) {
			
			camposTipo.add("serie");
			camposTipo.add("subpartida_nacional");
			camposTipo.add("derecho_antidumping");
			
			detalleFinal = this.reorganizarDetalleNotificacion(detalleNotificacion, camposTipo);
			
		} else if (COD_MOTIVO_NOTIFICACION_08.equals(motivoNotificacion)) {
			
			camposTipo.add("serie");
			camposTipo.add("sector_autoriza_ingreso");
			camposTipo.add("documento");
			
			detalleFinal = this.reorganizarDetalleNotificacion(detalleNotificacion, camposTipo);
			
		}
		
		return detalleFinal;
		
	}
	
	private String reorganizarDetalleNotificacion(Map<String, Object> registro, List<String> camposTipo) {
		
		String detalleOrganizado;
		StringBuilder detalleConstruido = new StringBuilder();
		String comillaDoble = "\"";
		int longitud = camposTipo.size();
		
		for (int i = 0; i < longitud; i++) {
			
			String titulo = camposTipo.get(i);
			//<EHR>
			if (titulo.equals("serie")) {
				
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + StringUtil.completarCeroIzquierda(registro.get(camposTipo.get(i)).toString(), 4) + comillaDoble);
				
			}
//			</EHR>
			else if (titulo.equals("valor_observado_por_unidad")) {
				
				titulo = "valor_observado_por_unidad_(us$_por_unidad)";
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
			} else if (titulo.equals("referencia")) {
				
				titulo = "referencia_(declaracion)";
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
			} else if (titulo.equals("derecho_antidumping")) {
				
				titulo = "derecho_antidumping_(%)";
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
				
			} else if (titulo.equals("subpartida_nacional")) {
				
				
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
				
			}else if (titulo.equals("subpartida_nacional_declarada")) {
					
					
					detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
					detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
					
			}else if (titulo.equals("subpartida_nacional_propuesta")) {
					
					
					detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
					detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
					
			}else if (titulo.equals("sector_autoriza_ingreso")) {
				
				
				detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
				detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
				
			}else if (titulo.equals("documento")) {
			
			
			detalleConstruido.append(comillaDoble + titulo + comillaDoble + ":");
			detalleConstruido.append(comillaDoble + registro.get(camposTipo.get(i)) + comillaDoble);
			
			}
			
			
			
			if (i != longitud -1) {
				
				detalleConstruido.append(",");
				
			}
			
		}
		
		detalleOrganizado = "{" + detalleConstruido.toString() + "}";
		
		return detalleOrganizado;
		
	}
	
	@Override
	public String obtenerConsolidadoDetalleNotificacion(ComunicacionDescripcion notificacion) throws ServiceException {
		
		StringBuilder HTMLDetalle = new StringBuilder();
		String detalleNotificacionConsolidado = "";
		
		if(("1").equals(notificacion.getIndDetDescNotificacion())){				
			//Insercion de cabecera				
			if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[0] != null && !notificacion.getDesNota().toString().trim().equals("") )
				HTMLDetalle.append(notificacion.getDesNota().toString().split("@_@")[0]);
			
			//Insercion de cuerpo					
				if(notificacion.isIndInsercionAviso()==false)
					HTMLDetalle.append(obtenerDetalleNotificacion(notificacion));
			
			//Insercion de pie
			if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[1] != null && !notificacion.getDesNota().toString().trim().equals("") )
				HTMLDetalle.append(notificacion.getDesNota().toString().split("@_@")[1]);
		}else{
			if (notificacion.getDesNota() !=null) HTMLDetalle.append(notificacion.getDesNota().replace("@_@", ""));
		}
		
		detalleNotificacionConsolidado = HTMLDetalle.toString();
		
		return detalleNotificacionConsolidado;
		
	}	
	//p24 pase PAS20165E220200099
	public void grabarDetalleComunicacionNotificacion (Map<String, Object> params) throws ServiceException {
		DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
		params.put("num_deta_desc", detalleComunicacionDAO.obtenerSiguienteCorrelativo(params));
		detalleComunicacionDAO.insert(params);
		
	}
	
	public void actualizarRespuestaComunicacionNotificacion (Map<String, Object> params) throws ServiceException{
		
		comunicacionDAO.updateRespuestaComunicacionNotificacion(params);
		
	}
	

  //INICIO JAZB 
  // INICIO P34
  /**
   * Encuentra la Lista de Declaraciones Pendiente de Regularizar
   * @param params  the params
   * @return List<Declaracion>
   */
  public List<Declaracion> findDeclaraPendienteRegularizacion (Map<String, Object> params){
	 return cabDeclaraDAO.findDeclaraPendienteRegularizacion(params);
  } 
  // FIN P34
 //FIN JAZB
  /****************/

   /** Busca los items que ser�n insertados, los cuales se encuentran en la sesion de declaraci�n "mapCabDeclaraActual" para Diligencia Despacho
   * @param params [Map<String,Object>] params
   * @param tipDilig [String] Tipo de Diligencia
   */
   private void insertarItemFacturaDeclaracion(Map<String,Object> params, String tipDilig){
	  
	  	Map<String,Object> mapCabDeclaraActual = (Map)params.get("mapCabDeclaraActual");
	  	Map<String,Object> mapCabDeclara = (Map)params.get("mapCabDeclara");
	    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>)mapCabDeclaraActual.get("lstFormBProveedor");
	    List<Map<String, Object>> lstFormBProveedorAnt = (List<Map<String, Object>>)mapCabDeclara.get("lstFormBProveedor");
	    Map facturaAnt = null;
	    
		if(!CollectionUtils.isEmpty(lstFormBProveedor)){
		  for(Map<String, Object> mapProveedor : lstFormBProveedor){ 
					
			Map<String,Object> keys = new HashMap<String,Object>();
			keys.put("num_corredoc", mapProveedor.get("num_corredoc"));
			keys.put("num_secprove", mapProveedor.get("num_secprove"));
			Map<String,Object> mapProveedorAnt = obtenerElemento(lstFormBProveedorAnt, keys);

		    List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>)mapProveedor.get("lstComproBPago");
			List<Map<String, Object>> lstComproBPagoAnt = (List<Map<String, Object>>)mapProveedorAnt.get("lstComproBPago");
				  
			if(!CollectionUtils.isEmpty(lstComproBPago)){
					  
		    for(Map<String, Object> facturaActual : lstComproBPago){
	
		    	Map fbKeys = new HashMap<String,Object>();
		        fbKeys.put("num_corredoc", facturaActual.get("num_corredoc"));
		        fbKeys.put("num_secfact", facturaActual.get("num_secfact"));
		        fbKeys.put("num_secprove", facturaActual.get("num_secprove"));
		        
		        facturaAnt = obtenerElemento(lstComproBPagoAnt, fbKeys);
		        
		        List<Map<String, Object>> lstItemsAnt = (List<Map<String, Object>>)facturaAnt.get("lstItemFactura");
		    	List<Map<String, Object>> lstItemsActual = (ArrayList) facturaActual.get("lstItemFactura");
		    	
		    	if(!CollectionUtils.isEmpty(lstItemsActual)){
			    	for(Map<String, Object> item : lstItemsActual){
			    		
			    	    	this.insertarItemFactura(item, params, lstItemsAnt, tipDilig);
		 	    	}
		    	}
		     }
		   }
		 }
	  }  
   }
  
   /** Inserta el �tem y sus listas asociadas(observaci�n, referenciaDuda, VfobProvisional, DecrMinima)
   * @param itemF [Map<String, Object>] �tem actual
   * @param params [Map] par�metros
   * @param lstItemsAnt [List<Map<String, Object>>] lista e �tems antiguos
   * @param tipDilig [String] Tipo de diligencia
   */
   private void insertarItemFactura(Map<String, Object> itemF, Map params, List<Map<String, Object>> lstItemsAnt, String tipDilig){

	   if(!itemF.get("IND_TIPO_REGISTRO").toString().equals("1") && !Constantes.IND_ELIMINADO.equals(itemF.get("IND_DEL"))){  
 	      Map<String,Object> keys = new HashMap();
 	      keys.put("NUM_CORREDOC", new Long(itemF.get("NUM_CORREDOC").toString().trim()));
 	      keys.put("NUM_SECITEM", new Long(itemF.get("NUM_SECITEM").toString().trim()));
 	      keys.put("NUM_SECFACT", new Long(itemF.get("NUM_SECFACT").toString().trim()));
 	      keys.put("NUM_SECPROVE", new Long(itemF.get("NUM_SECPROVE").toString().trim()));

 	      Map<String,Object> itemAnt = Utilidades.obtenerElemento(lstItemsAnt, keys);
 	      
 	      if(itemAnt==null || itemAnt.isEmpty()){
 	    	 
 	    	 boolean isNewRecord = true;

 	    	//Items  
	        this.itemFacturaDAO.insertSelective(Utilidades.transformFieldsToRealFormat(itemF));
	        
	        Map<String,Object> paramspr = new HashMap<String,Object>();
	        paramspr.put("numcorredoc", itemF.get("NUM_CORREDOC").toString().trim());
	        paramspr.put("numsecuprov", itemF.get("NUM_SECPROVE").toString().trim());
	        paramspr.put("numsecfact", itemF.get("NUM_SECFACT").toString().trim());
	        
	        Map<String, Object> mapClave = new HashMap<String, Object>();
	        mapClave.put("NUM_CORREDOC", itemF.get("NUM_CORREDOC"));
	        mapClave.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
	        itemF.put("clave", mapClave);
		    Map itemOrig = null;
		    itemF.put("dataOriginal", itemOrig);
		    
		    Object observacion = itemF.get("OBSERVACION");
		    Object fecValestima = itemF.get("FEC_VALESTIMA");
		    Object codTipValor = itemF.get("COD_TIPOVALOR");
		    Object mtoMonto = itemF.get("MTO_MONTO");

	        // Retirar los campos que pertenecen a la tabla VFOBPROVISIONAL
		    if (itemF.containsKey("COD_TIPOVALOR"))
		      itemF.remove("COD_TIPOVALOR");
		    if (itemF.containsKey("COD_TIPOVALOR_DESC"))
		      itemF.remove("COD_TIPOVALOR_DESC");
		    if (itemF.containsKey("MTO_MONTO"))
		      itemF.remove("MTO_MONTO");
		    if (itemF.containsKey("FEC_VALESTIMA"))
		      itemF.remove("FEC_VALESTIMA");
		    // Retirar los campos de descripci�n
		    if (itemF.containsKey("COD_ESTMERC_DESC"))
		      itemF.remove("COD_ESTMERC_DESC");
		    if (itemF.containsKey("IND_SOFTWARE_DESC"))
		      itemF.remove("IND_SOFTWARE_DESC");
		      itemF.remove("NUM_SECOBS");
		      
		    itemF.remove("OBSERVACION");

	        this.registrarRectiOficio(
	        						  itemF,
	        						  tipDilig,
	        						  new Long(itemF.get("NUM_CORREDOC").toString().trim()),
	                                  Constantes.COD_TABLA_ITEM_FACTURA,
	                                  isNewRecord);
	        
 	    	//Observaci�n  
	        if(Utilidades.validarNuloOVacioRetornaString(observacion)!=""){
	        	
		          Long numcorredoc = new Long(itemF.get("NUM_CORREDOC").toString().trim());
		          Map<String,Object> mapObs = new HashMap<String,Object>();
		          mapObs.put("NUM_CORREDOC", numcorredoc);
		          mapObs.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
		          mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
		          mapObs.put("OBS_OBS", observacion.toString());
		          
		          Map<String, Object> paramSecObs = new HashMap<String,Object>();
		          paramSecObs.put("NUM_CORREDOC", itemF.get("NUM_CORREDOC"));
		          paramSecObs.put("COD_TIPOBS",Constantes.TIPO_OBSERVACION_ITEM_FB);
		          
				  mapObs.put("NUM_SECOBS", getSecObservacion(paramSecObs));
				  mapObs.put("COD_USUREGIS", itemF.get("COD_USUREGIS")!=null?itemF.get("COD_USUREGIS").toString():"");
				  mapObs.put("FEC_REGIS", Utilidades.parseDate(itemF.get("FEC_REGIS").toString(),Constantes.FORMAT_DATES_HORA));
				  mapObs.put("IND_DEL", "0");
				  
		          this.observacionDAO.insert(mapObs);
		        
			      Map<String, Object> mapClaveObs = new HashMap<String, Object>();
			      mapClaveObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
			      mapClaveObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
			      mapClaveObs.put("COD_TIPOBS", mapObs.get("NUM_SECOBS"));
			      mapObs.put("clave", mapClaveObs);
			      
			      Map mapObsDO = null;
			      mapObs.put("dataOriginal", mapObsDO);
				  this.registrarRectiOficio(mapObs, tipDilig, new Long(mapObs.get("NUM_CORREDOC").toString().trim()),
						  					Constantes.COD_TABLA_OBSERVACION, isNewRecord);
	        }
	        
	        //Inserta lstVfobProvisional
	        DatoMontoProv datoMontoProv = null;
	        if (itemF.get("lstVfobProvisional")!=null && !itemF.get("lstVfobProvisional").toString().isEmpty()){
	        	List<Map<String,Object>> lstFobProvisional = (List<Map<String,Object>>)itemF.get("lstVfobProvisional");
		        for(Map<String,Object> fobProvisional : lstFobProvisional){
		        
		        datoMontoProv = new DatoMontoProv();
		        datoMontoProv.setCodmoneda(fobProvisional.get("COD_MONEDA")!=null? fobProvisional.get("COD_MONEDA").toString():"");
		        datoMontoProv.setFectipocambio(fobProvisional.get("FEC_TIPCAMB")!=null?
		        				Utilidades.convertirFormatoStringToDate(fobProvisional.get("FEC_TIPCAMB").toString()):null);
		        datoMontoProv.setFecvalestima(!Utilidades.validarNuloOVacioRetornaString(fecValestima).equals("")?
		        	Utilidades.convertirFormatoStringToDate(fecValestima.toString()): null);
		        datoMontoProv.setNumcorredoc(Long.valueOf(fobProvisional.get("NUM_CORREDOC").toString()));
		        datoMontoProv.setNumsecfact(Integer.valueOf(fobProvisional.get("NUM_SECFACT").toString()));
		        datoMontoProv.setNumsecprove(Integer.valueOf(fobProvisional.get("NUM_SECPROVE").toString()));
		        datoMontoProv.setNumsecitem(Integer.valueOf(fobProvisional.get("NUM_SECITEM").toString()));
		        datoMontoProv.setValmonto(Utilidades.validarNuloOVacioRetornaString(mtoMonto)!=""? Utilidades.validaVacioRetornaBigDecimal(mtoMonto)
		        		:BigDecimal.ZERO);
		        datoMontoProv.setValdefinitivo(Utilidades.validaVacioRetornaBigDecimal(fobProvisional.get("MTO_DEFINITIVO")));
		        datoMontoProv.setIndtipovalor(Utilidades.validarNuloOVacioRetornaString(codTipValor)!=""? codTipValor.toString()
		        		:"");
		        datoMontoProv.setFecregis(itemF.get("FEC_REGIS")!=null ? 
								  Utilidades.convertirFormatoStringToDate(itemF.get("FEC_REGIS").toString()):null);
		        datoMontoProv.setCodusuregis(itemF.get("COD_USUREGIS")!=null?itemF.get("COD_USUREGIS").toString():"");
		        this.vFOBProvisionalDAO.insertSelective(datoMontoProv);
		        
	           }
	        }
	        
		    //Inserta lstDecrMinima
	        if (itemF.get("lstDecrMinima")!=null && !itemF.get("lstDecrMinima").toString().isEmpty()){
	        	List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>)itemF.get("lstDecrMinima"); 
		        for(Map<String,Object> formBItemDescri : lstDecrMinima){
		        	formBItemDescri.put("FEC_REGIS",itemF.get("FEC_REGIS")!=null ? 
							  Utilidades.parseDate(itemF.get("FEC_REGIS").toString(),Constantes.FORMAT_DATES_HORA):null);
		        	formBItemDescri.put("COD_USUREGIS",itemF.get("COD_USUREGIS"));
		        	if(formBItemDescri.get("NOM_CAMPO") == null){
		        		formBItemDescri.put("NOM_CAMPO", "");
		        	}
		        	this.formBItemDescriDAO.insertSelective(formBItemDescri);
		        }
  	        }
	      
	        // referencia Duda
	        if (itemF.get("lstReferenciaDuda")!=null && !itemF.get("lstReferenciaDuda").toString().isEmpty()){
	        	
		      List<Map<String, Object>> lstRef = (ArrayList) itemF.get("lstReferenciaDuda");

	          for (Map<String, Object> ref : lstRef){
	        	  
	        	ref.put("FEC_REGIS",itemF.get("FEC_REGIS")!=null ? 
						  Utilidades.parseDate(itemF.get("FEC_REGIS").toString(),Constantes.FORMAT_DATES_HORA):null);
	        	ref.put("COD_USUREGIS",itemF.get("COD_USUREGIS"));
	        	
	        	Map<String,Object> numSecRef = new HashMap<String,Object>();
	        	numSecRef.put("NUM_CORREDOC", itemF.get("NUM_CORREDOC"));
	        	numSecRef.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
	        	int maxSecRefDuda = getSecReferenciaDuda(numSecRef);
	        	ref.put("NUM_SECREF", maxSecRefDuda);
	            this.referenciaDudaDAO.insert(ref);
	          }
	        }
	        
	     }
       }
   }
  
  /** Obtiene el siguiente secuencial de la observaci�n
  * @param params [Map<String, Object>] 
  * @return [int] secuencial
  */
   private int getSecObservacion(Map<String, Object> params) {

	   return observacionDAO.getMaxNumSecObs(params) + 1;
	  
   }
   
   /** Obtiene el siguiente secuencial de la referenciaDuda
  * @param params [Map<String, Object>]
  * @return [int] secuencial
  */
  private int getSecReferenciaDuda(Map<String, Object> params) {

	   return referenciaDudaDAO.getMaxNumSecRefDuda(params) + 1;
	  
   }
   
   /** Busca los items que ser�n insertados, los cuales se encuentran en la sesi�n de declaraci�n "mapCabDeclaraActual" para la diligencia de Rectificaci�n Oficio
  * @param params [Map<String,Object>] par�metros
  * @param numCorreDocSol [Integer] Numero correlaci�n
  * @param tipDilig [String] Tipo de diligencia
  */
   private void insertarItemFacturaDeclaracion(Map<String,Object> params, Integer numCorreDocSol, String tipDilig){
	  
	  	Map<String,Object> mapCabDeclaraActual = (Map)params.get("mapCabDeclaraActual");
	  	Map<String,Object> mapCabDeclara = (Map)params.get("mapCabDeclara");
	    List<Map<String, Object>> lstFormBProveedor = (List<Map<String, Object>>)mapCabDeclaraActual.get("lstFormBProveedor");
	    List<Map<String, Object>> lstFormBProveedorAnt = (List<Map<String, Object>>)mapCabDeclara.get("lstFormBProveedor");

	    Map facturaAnt = null;
	    
	 if(!CollectionUtils.isEmpty(lstFormBProveedor)){
		for(Map<String, Object> mapProveedor : lstFormBProveedor){ 
			
		  Map<String,Object> keys = new HashMap<String,Object>();
		  keys.put("num_corredoc", mapProveedor.get("num_corredoc"));
		  keys.put("num_secprove", mapProveedor.get("num_secprove"));
	      Map<String,Object> mapProveedorAnt = obtenerElemento(lstFormBProveedorAnt, keys);

		  List<Map<String, Object>> lstComproBPago = (List<Map<String, Object>>)mapProveedor.get("lstComproBPago");
		  List<Map<String, Object>> lstComproBPagoAnt = (List<Map<String, Object>>)mapProveedorAnt.get("lstComproBPago");
		  
		  if(!CollectionUtils.isEmpty(lstComproBPago)){
		      for(Map<String, Object> facturaActual : lstComproBPago){
	
		    	Map fbKeys = new HashMap<String,Object>();
		        fbKeys.put("num_corredoc", facturaActual.get("num_corredoc"));
		        fbKeys.put("num_secfact", facturaActual.get("num_secfact"));
		        fbKeys.put("num_secprove", facturaActual.get("num_secprove"));
		        
		        facturaAnt = obtenerElemento(lstComproBPagoAnt, fbKeys);
		        
		        List<Map<String, Object>> lstItemsAnt = (List<Map<String, Object>>)facturaAnt.get("lstItemFactura");
		    	List<Map<String, Object>> lstItemsActual = (ArrayList) facturaActual.get("lstItemFactura");
		    	
		    	if(!CollectionUtils.isEmpty(lstItemsActual)){
		    	for(Map<String, Object> item : lstItemsActual){
		    		
		    	    this.insertarItemFactura(item,params, lstItemsAnt, numCorreDocSol, tipDilig);
		    	 
		    	}
		    	}
		      }
	     }
		}
	  }
   }
  
   /** Inserta el �tem y sus listas asociadas(observaci�n, referenciaDuda, VfobProvisional, DecrMinima)
  * @param itemF [Map<String, Object>] �tem actual
  * @param params [Map] par�metros
  * @param lstItemsAnt [List<Map<String,Object>>] lista de �tems Antiguos
  * @param numCorreDocSol [Integer] Numero de Correlaci�n
  * @param tipDilig [String] Tipo de diligencia
  */
   private void insertarItemFactura(Map<String, Object> itemF, Map params, List<Map<String,Object>> lstItemsAnt,
		   			Integer numCorreDocSol, String tipDilig){
 
	   if(!itemF.get("IND_TIPO_REGISTRO").toString().equals("1") && !Constantes.IND_ELIMINADO.equals(itemF.get("IND_DEL"))){  
 	      Map<String,Object> keys = new HashMap();
 	      keys.put("NUM_CORREDOC", new Long(itemF.get("NUM_CORREDOC").toString().trim()));
 	      keys.put("NUM_SECITEM", new Long(itemF.get("NUM_SECITEM").toString().trim()));
 	      keys.put("NUM_SECFACT", new Long(itemF.get("NUM_SECFACT").toString().trim()));
 	      keys.put("NUM_SECPROVE", new Long(itemF.get("NUM_SECPROVE").toString().trim()));

 	      Map<String,Object> itemAnt = Utilidades.obtenerElemento(lstItemsAnt, keys);
 	      
 	      if(itemAnt==null || itemAnt.isEmpty()){
	   
 	    	//Inserta Item  
 	        this.itemFacturaDAO.insertSelective(Utilidades.transformFieldsToRealFormat(itemF));
 	        
		    Object observacion = itemF.get("OBSERVACION");
		    Object fecValestima = itemF.get("FEC_VALESTIMA");
		    Object codTipValor = itemF.get("COD_TIPOVALOR");
		    Object mtoMonto = itemF.get("MTO_MONTO");

	        // Retirar los campos que pertenecen a la tabla VFOBPROVISIONAL
	        if (itemF.containsKey("COD_TIPOVALOR"))
	          itemF.remove("COD_TIPOVALOR");
	        if (itemF.containsKey("COD_TIPOVALOR_DESC"))
	          itemF.remove("COD_TIPOVALOR_DESC");
	        if (itemF.containsKey("MTO_MONTO"))
	          itemF.remove("MTO_MONTO");
	        if (itemF.containsKey("FEC_VALESTIMA"))
	          itemF.remove("FEC_VALESTIMA");
	        // Retirar los campos de descripci�n
	        if (itemF.containsKey("COD_ESTMERC_DESC"))
	          itemF.remove("COD_ESTMERC_DESC");
	        if (itemF.containsKey("IND_SOFTWARE_DESC"))
	          itemF.remove("IND_SOFTWARE_DESC");
	        itemF.remove("NUM_SECOBS");

	        itemF.remove("OBSERVACION");

	        Map<String, Object> mapDiferencias = soporteComparadorService.comparaMap(itemF,new HashMap(),
	                                                                                   EnumTablaModel.ITEMFACTURA);
	            this.registrarRectiOficio(mapDiferencias, tipDilig,
	                    new Long(itemF.get("NUM_CORREDOC").toString().trim()),
	                    Constantes.COD_TABLA_ITEM_FACTURA, numCorreDocSol);
	        
 	    	//Insertar Observaci�n  
            if(Utilidades.validarNuloOVacioRetornaString(observacion)!=""){
	 			Long numcorredoc = new Long(itemF.get("NUM_CORREDOC").toString().trim());
	 	        Map<String,Object>  mapObs = new HashMap<String,Object>();
	 	        mapObs.put("NUM_CORREDOC", numcorredoc);
	 	        mapObs.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
	 	        mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_ITEM_FB);
	 	        mapObs.put("OBS_OBS", observacion.toString());
	 	        
		        Map<String, Object> paramSecObs = new HashMap<String,Object>();
		        paramSecObs.put("NUM_CORREDOC", itemF.get("NUM_CORREDOC"));
		        paramSecObs.put("COD_TIPOBS",Constantes.TIPO_OBSERVACION_ITEM_FB);
  
	 			mapObs.put("NUM_SECOBS", getSecObservacion(paramSecObs));
				mapObs.put("COD_USUREGIS", itemF.get("COD_USUREGIS")!=null?itemF.get("COD_USUREGIS").toString():"");
				mapObs.put("FEC_REGIS", Utilidades.parseDate(itemF.get("FEC_REGIS").toString(), Constantes.FORMAT_DATES_HORA));
				mapObs.put("IND_DEL", "0");

	 			this.observacionDAO.insert(mapObs);
	 	  
	 	        Map<String, Object> mapDiferenciasObs =
                          soporteComparadorService.comparaMap(mapObs, new HashMap(),
                                                              EnumTablaModel.OBSERVACION);
	 	        this.registrarRectiOficio(mapDiferenciasObs, tipDilig, numcorredoc,
	 	                                    Constantes.COD_TABLA_OBSERVACION, numCorreDocSol);
           }
 	        
	        //Inserta lstVfobProvisional
	        DatoMontoProv datoMontoProv = null;
	        if (itemF.get("lstVfobProvisional")!=null && !itemF.get("lstVfobProvisional").toString().isEmpty()){
		        List<Map<String,Object>> lstFobProvisional = (List<Map<String,Object>>)itemF.get("lstVfobProvisional");

		        for(Map<String,Object> fobProvisional : lstFobProvisional){
		        
		        datoMontoProv = new DatoMontoProv();
		        datoMontoProv.setCodmoneda(fobProvisional.get("COD_MONEDA")!=null ?fobProvisional.get("COD_MONEDA").toString():"");
		        datoMontoProv.setFectipocambio(fobProvisional.get("FEC_TIPCAMB")!=null? Utilidades.convertirFormatoStringToDate(fobProvisional.get("FEC_TIPCAMB").toString()):null);
		        datoMontoProv.setFecvalestima(!Utilidades.validarNuloOVacioRetornaString(fecValestima).equals("")?
		        	Utilidades.convertirFormatoStringToDate(fecValestima.toString()):null);
		        datoMontoProv.setNumcorredoc(Long.valueOf(fobProvisional.get("NUM_CORREDOC").toString()));
		        datoMontoProv.setNumsecfact(Integer.valueOf(fobProvisional.get("NUM_SECFACT").toString()));
		        datoMontoProv.setNumsecprove(Integer.valueOf(fobProvisional.get("NUM_SECPROVE").toString()));
		        datoMontoProv.setNumsecitem(Integer.valueOf(fobProvisional.get("NUM_SECITEM").toString()));
		        datoMontoProv.setValmonto(Utilidades.validarNuloOVacioRetornaString(mtoMonto)!=""?Utilidades.validaVacioRetornaBigDecimal(mtoMonto)
		        		:BigDecimal.ZERO);
		        datoMontoProv.setValdefinitivo(Utilidades.validaVacioRetornaBigDecimal(fobProvisional.get("MTO_DEFINITIVO")));
		        datoMontoProv.setIndtipovalor(Utilidades.validarNuloOVacioRetornaString(codTipValor)!="" ? codTipValor.toString():"");
		        datoMontoProv.setFecregis(itemF.get("FEC_REGIS")!=null ? 
		        			Utilidades.convertirFormatoStringToDate(itemF.get("FEC_REGIS").toString()):null);
		        datoMontoProv.setCodusuregis(itemF.get("COD_USUREGIS")!=null?itemF.get("COD_USUREGIS").toString():"");
		        this.vFOBProvisionalDAO.insertSelective(datoMontoProv);
		        
	            }
	        }
		        
		    //Inserta lstDecrMinima
	        if (itemF.get("lstDecrMinima")!=null && !itemF.get("lstDecrMinima").toString().isEmpty()){
			    List<Map<String,Object>> lstDecrMinima = (List<Map<String,Object>>)itemF.get("lstDecrMinima");  
  	
		        for(Map<String,Object> formBItemDescri : lstDecrMinima){
		        	
		        	formBItemDescri.put("FEC_REGIS",itemF.get("FEC_REGIS")!=null ? 
							  Utilidades.parseDate(itemF.get("FEC_REGIS").toString(),Constantes.FORMAT_DATES_HORA):null);
		        	formBItemDescri.put("COD_USUREGIS",itemF.get("COD_USUREGIS"));
		        	this.formBItemDescriDAO.insertSelective(formBItemDescri);
		        }
  	        }
	        
	        // referencia Duda
	        if (itemF.get("lstReferenciaDuda")!=null && !itemF.get("lstReferenciaDuda").toString().isEmpty()){
	        	
		      List<Map<String, Object>> lstRef = (ArrayList) itemF.get("lstReferenciaDuda");

	          for (Map<String, Object> ref : lstRef){
	        	  
		        ref.put("FEC_REGIS",itemF.get("FEC_REGIS")!=null ? 
						  Utilidades.parseDate(itemF.get("FEC_REGIS").toString(),Constantes.FORMAT_DATES_HORA):null);
		        ref.put("COD_USUREGIS",itemF.get("COD_USUREGIS"));
	        	Map<String,Object> numSecRef = new HashMap<String,Object>();
	        	numSecRef.put("NUM_CORREDOC", itemF.get("NUM_CORREDOC"));
	        	numSecRef.put("NUM_SECITEM", itemF.get("NUM_SECITEM"));
	        	int maxSecRefDuda = getSecReferenciaDuda(numSecRef);
	        	ref.put("NUM_SECREF", maxSecRefDuda);

	            this.referenciaDudaDAO.insert(ref);
	          }
	          
	        }
	        
        }
 	  }
  }

  /** Busca el item actual(en session) en la lista de items antiguos (lstItemsAnt = la lista de items antiguos contiene lo registrado en base de datos)
  * @param item [Map<String,Object>] item actual
  * @param lstItemsAnt [List<Map<String,Object>>] lista de items antiguos
  * @return [Map] item antiguo
  */
  private Map<String,Object> validarActualizarItem(Map<String,Object> item, List<Map<String,Object>> lstItemsAnt){
	  
      Map keys = new HashMap();
      keys.put("NUM_CORREDOC", new Long(item.get("NUM_CORREDOC").toString().trim()));
      keys.put("NUM_SECITEM", new Long(item.get("NUM_SECITEM").toString().trim()));

      Map itemAnt = Utilidades.obtenerElemento(lstItemsAnt, keys);
      
      return itemAnt;
  }
  
  private enum Tipo {
	  MAYUSCULA,
	  MINUSCULA
  }
  
  /** Cambia a may�scula o min�scula los campos principales del map de facturas, seg�n el indicador tipo
  * @param lstFacturas [List<Map<String, Object>>]
  * @param tipo [Tipo]
  */
  private void cambiarClavesMapasDeLista(List<Map<String, Object>> lstFacturas, Tipo tipo) {
	  
	  if(!CollectionUtils.isEmpty(lstFacturas)){
		  for(Map<String, Object> factura : lstFacturas) {
			 
			  List<String> lstClaveMapaFactura = new ArrayList<String>(factura.keySet());
			  for (String claveMapaFactura : lstClaveMapaFactura) {
				  if(Tipo.MAYUSCULA.equals(tipo)) {
					  if(claveMapaFactura.equalsIgnoreCase("num_corredoc") || claveMapaFactura.equalsIgnoreCase("num_secfact")){
						  factura.put(claveMapaFactura.toUpperCase(), factura.remove(claveMapaFactura));
					  }
				  } else {
					  if(claveMapaFactura.equalsIgnoreCase("num_corredoc") || claveMapaFactura.equalsIgnoreCase("num_secfact")){
						  factura.put(claveMapaFactura.toLowerCase(), factura.remove(claveMapaFactura));
					  }
					  

				  }
			  }
		  }
	  }
	  
  }
  
  /** Cambia las claves a min�scula de toda la lista
  * @param mapa [Map]
  */
  private void cambiarClavezMapa(Map<String, Object> mapa){
	  
		  List<String> lstClaveMapa = new ArrayList<String>(Utilidades.copiarMapa(mapa).keySet());
		  for (String claveMapa : lstClaveMapa) {
		  		
			  mapa.put(claveMapa.toLowerCase(), mapa.remove(claveMapa));
		  	}
  }
  
  /** Lista correlaciones(seriesItem) asociadas al �tem
  * @param params [Map]
  * @param item [Map<String, Object>]
  * @return [List<Map<String, Object>>]
  */
  private List<Map<String, Object>> filtrarCorrelacionesPorItem(Map params, Map<String, Object> item){
	  
      List<Map<String, Object>> lstSeriesItemActual = (List<Map<String, Object>>) params.get("lstSeriesItemActual");
      List<Map<String, Object>> lstSeriesItemActualSeriesItem = new ArrayList<Map<String,Object>>();
      for (Map<String, Object> serieItemXItem : lstSeriesItemActual) {
			if(serieItemXItem.get("NUM_SECITEM").equals(item.get("NUM_SECITEM"))
			   && serieItemXItem.get("NUM_SECFACT").equals(item.get("NUM_SECFACT"))
			   && serieItemXItem.get("NUM_SECPROVE").equals(item.get("NUM_SECPROVE"))
			   && serieItemXItem.get("NUM_CORREDOC").equals(item.get("NUM_CORREDOC"))){
				
				lstSeriesItemActualSeriesItem.add(serieItemXItem);
			}
		}
      return lstSeriesItemActualSeriesItem;
  }
	
/*RIN13FSW-INICIO*/
  /**
   * juazor RIN13
   * */
  
  public boolean grabarDiligenciaContDespacho(Map<String, Object> paramsDiligencia) {
		Map declaracion = (HashMap) paramsDiligencia.get("mapCabDeclaraActual");
		Map declaracionAnt = (HashMap) paramsDiligencia.get("mapCabDeclara");
		Map mapDilig = (HashMap) paramsDiligencia.get("mapCabDiligenciaActual");
		FechaBean fecActual = new FechaBean();

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + paramsDiligencia.get("caduana").toString().trim()));
		String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
		try {

			// Insertamos o actualizamos la DILIGENCIA
			mapDilig.put("COD_TIPDILIGENCIA",Constantes.DILIG_CONT_DESPACHO );
			mapDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			mapDilig.put("COD_MOTIVO", "08");
			mapDilig.put("COD_CATALOGO", "355");
			mapDilig.put("DES_RESULTADO", paramsDiligencia.get("DES_RESULTADO"));

			if (mapDilig.get("FEC_DILIGENCIA") == null) {
				mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
			}

			try {
				this.cabDiligenciaDAO.insert(mapDilig);
			} catch (Exception e) {
				log.info("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:"
						+ SojoUtil.toJson(mapDilig));
				if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig)) {
					throw new ServiceException(this, e);
				} else {
					this.cabDiligenciaDAO.update(mapDilig);
				}
			}

			// **************Actualizamos la DECLARACION********************//

			// juazor - se Actualiza fecha actual y se cambia el estado de la dua
			// a revision
			
			Map<String, Object> declaraUpdate = new HashMap<String, Object>();
			
			declaraUpdate.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			declaraUpdate.put("FEC_MODIF", fecActual.getTimestamp());
			declaraUpdate.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			declaraUpdate.put("CNT_TOTBULTOS", declaracion.get("CNT_TOTBULTOS"));
			
			try {
				this.cabDeclaraDAO.update(declaraUpdate);
				// **************fin Actualizamos la DECLARACION********************//
				
				//trazabilidad cabdeclara
								   
				  Map fbKeys = new HashMap();
			      fbKeys.put("NUM_CORREDOC", "");

			      Comparador comp = new Comparador();
			      /* Retirar campos que no son modificables */
			      if (declaracion.containsKey("CNT_TOTBULTOS"))
			        declaracionAnt.put("CNT_TOTBULTOS", declaracion.get("CNT_TOTBULTOS"));
			      if (declaracion.containsKey("FEC_REGIS"))
			        declaracion.remove("FEC_REGIS");
			      if (declaracionAnt.containsKey("FEC_REGIS"))
			        declaracionAnt.remove("FEC_REGIS");
			      if (declaracion.containsKey("FEC_MODIF"))
			        declaracion.remove("FEC_MODIF");
			      if (declaracionAnt.containsKey("FEC_MODIF"))
			        declaracionAnt.remove("FEC_MODIF");

			      Map<String, Object> mapDiferencias = comp.comparaMapEstricto(declaracionAnt, declaracion, false, false, fbKeys);

			      if (mapDiferencias != null && mapDiferencias.size() > 0)
			      {
			        if (Comparador.esDataCambiada(mapDiferencias))
			        {
			            this.registrarRectiOficio(mapDiferencias, Constantes.DILIG_CONT_DESPACHO, new Long(mapDiferencias.get("NUM_CORREDOC").toString().trim()), "T0051");
			        }
			      }
				//fin trazabilidad cabdelcara
			     
			    //actualiza series y  detdeclara
			      this.actualizarSeries(paramsDiligencia);
				      
				
			} catch (Exception e) {
				log.error("*** ERROR ***"+e.getMessage() , e);
				return false;
					
			}	
			
		    
			
		} catch (Throwable e) {
			log.error("*** ERROR ***", e);
			throw new ServiceException(this,"Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador");
			
		}
		return true;
		
	}//fin grabarDiligenciaContDespacho 
  
  
  
  /**
   * 
   * juazor RIN13
   * 
   * */
  
  
  public boolean grabarDiligenciaDescargaParcialDespacho(Map<String, Object> paramsDiligencia) {
	  
		Map declaracion = (HashMap) paramsDiligencia.get("mapCabDeclaraActual");
		Map declaracionAnt = (HashMap) paramsDiligencia.get("mapCabDeclara");
		Map mapDilig = (HashMap) paramsDiligencia.get("mapCabDiligenciaActual");
		List<Map<String, Object>> lstmovEquipamiento = (ArrayList) paramsDiligencia.get("lstmovEquipamiento");
		boolean res=true;		
		
		String codigoTipoMovimiento = "97";
		FechaBean fecActual = new FechaBean();
		/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//		String cod_funcionario=paramsDiligencia.get("cod_funcionario").toString();
		/* PAS20145E220000399 FIN GGRANADOS NO SE USA*/

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + paramsDiligencia.get("caduana").toString().trim()));
		String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
		String numDocTransp="";
				
		try {
			
			//insertar movequipamiento
			
			for (Map<String, Object> map : lstmovEquipamiento) {
				
				String numeroCorrelativo =  map.get("NUM_CORREDOC").toString();
				Long numeCorreDoc =Long.parseLong(numeroCorrelativo);
				String numeroEquipamiento = map.get("NUM_EQUIPAMIENTO").toString();	
				numDocTransp = (String) map.get("NUM_DOC_TRANSPORTE");
				
				MovimientoDeEquipamiento movEqui = new MovimientoDeEquipamiento();
				Equipamiento equipamiento = new Equipamiento();
				Manifiesto manifiesto = new Manifiesto();
				manifiesto.setNumeroCorrelativo(numeCorreDoc);
								
				equipamiento.setNumeroEquipamiento(numeroEquipamiento);
				equipamiento.setManifiesto(manifiesto);
								
				DataCatalogo dataCatalogo_tipoMovimiento = new DataCatalogo();
				dataCatalogo_tipoMovimiento.setCodDatacat(codigoTipoMovimiento);
				
				movEqui.setEquipamiento(equipamiento);
				movEqui.setTipoMovimiento(dataCatalogo_tipoMovimiento);
				//movEqui.setNumeroDeDNI(cod_funcionario);//juazor
				movEquipamientoDAO.insertSelectivo(movEqui);
				
			}
					
			
			// Insertamos o actualizamos la DILIGENCIA
			mapDilig.put("COD_TIPDILIGENCIA",Constantes.DILIG_DESCA_PARCIAL);
			mapDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			mapDilig.put("COD_MOTIVO", "07");
			mapDilig.put("COD_CATALOGO", "355");
			mapDilig.put("CNT_BULTOSRECON", paramsDiligencia.get("BULTOS_RECON"));
			mapDilig.put("DES_RESULTADO", paramsDiligencia.get("DES_RESULTADO"));
			
			//obtenemos el siguinete num_corredoc_sol
			Map<String, Object> params1  = new HashMap<String, Object>();
			params1.put("numcorredoc",declaracion.get("NUM_CORREDOC"));
			params1.put("codtipdiligencia",Constantes.DILIG_DESCA_PARCIAL);
			
			Integer numCorreDocSol=cabDiligenciaDAO.ultimoNumCorreDocSol(params1);
			mapDilig.put("NUM_CORREDOC_SOL",numCorreDocSol);
	
			if (mapDilig.get("FEC_DILIGENCIA") == null) {
				mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
			}

			try {
				this.cabDiligenciaDAO.insert(mapDilig);
			} catch (Exception e) {
				log.info("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:"
						+ SojoUtil.toJson(mapDilig));
				if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig)) {
					throw new ServiceException(this, e);
				} else {
					this.cabDiligenciaDAO.update(mapDilig);
				}
			}

			// **************Actualizamos la DECLARACION********************//

			// juazor - se Actualiza fecha actual y se cambia el estado de la dua
		 
			String codAduamanifiesto = declaracion.get("COD_ADUAMANIFIESTO") !=null ? declaracion.get("COD_ADUAMANIFIESTO").toString() : ""; 
			String codViatrans = declaracion.get("COD_VIATRANS") !=null ? declaracion.get("COD_VIATRANS").toString() : ""; 
			Integer annManifiesto = declaracion.get("ANN_MANIFIESTO") !=null ? Integer.parseInt(declaracion.get("ANN_MANIFIESTO").toString()) : new Integer(0);
			String numManifiesto = declaracion.get("NUM_MANIFIESTO") !=null ? declaracion.get("NUM_MANIFIESTO").toString() : "";
			String codTipmanifiesto = declaracion.get("COD_TIPMANIFIESTO") !=null ? declaracion.get("COD_TIPMANIFIESTO").toString() : "";
			String numManifiestoD= StringUtils.trim(numManifiesto);
			
			Map<String, Object> paramsDocTrans  = new HashMap<String, Object>();
			
			paramsDocTrans.put("numeroDocumentoTransporte",numDocTransp);
			paramsDocTrans.put("COD_ADUAMANIFIESTO",codAduamanifiesto);
			paramsDocTrans.put("COD_VIATRANS",codViatrans);
			paramsDocTrans.put("ANN_MANIFIESTO",annManifiesto);
			paramsDocTrans.put("NUM_MANIFIESTO",numManifiestoD);
			paramsDocTrans.put("COD_TIPMANIFIESTO",codTipmanifiesto);
			paramsDocTrans.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			
			boolean ultimaDiligencia=declaracionService.obtenerRegistro(paramsDocTrans);// 
									
			
			Map<String, Object> declaraUpdate = new HashMap<String, Object>();
			
			
			declaraUpdate.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			declaraUpdate.put("FEC_MODIF", fecActual.getTimestamp());
			declaraUpdate.put("CNT_TOTBULTOS", declaracion.get("CNT_TOTBULTOS"));
					
			if(ultimaDiligencia){
				/*graba trazabilidad*/
                
                Map fbKeys = new HashMap();
                fbKeys.put("NUM_CORREDOC", "");

                Comparador comp = new Comparador();
                /* Retirar campos que no son modificables */
//                if (declaracion.containsKey("CNT_TOTBULTOS"))
//                  declaracionAnt.put("CNT_TOTBULTOS", declaracion.get("CNT_TOTBULTOS"));
                declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
                
                if (declaracion.containsKey("FEC_REGIS"))
                	declaracion.remove("FEC_REGIS");
                if (declaracionAnt.containsKey("FEC_REGIS"))
                  declaracionAnt.remove("FEC_REGIS");
                if (declaracion.containsKey("FEC_MODIF"))
                	declaracion.remove("FEC_MODIF");
                if (declaracionAnt.containsKey("FEC_MODIF"))
                  declaracionAnt.remove("FEC_MODIF");

                Map<String, Object> mapDiferencias = comp.comparaMapEstricto(declaracionAnt, declaracion, false, false, fbKeys);

                if (mapDiferencias != null && mapDiferencias.size() > 0)
                {
                  if (Comparador.esDataCambiada(mapDiferencias))
                  {	  
                	  mapDiferencias.put("NUM_CORREDOC_SOL", numCorreDocSol); 
                      this.registrarRectiOficio(mapDiferencias, Constantes.DILIG_DESCA_PARCIAL, new Long(mapDiferencias.get("NUM_CORREDOC").toString().trim()), "T0051");
                  }
                }
              //fin trazabilidad cabdelcara

				
				declaraUpdate.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			}else{
				declaraUpdate.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_RECEPCIONADO);	
			}
			
						
			try {
				this.cabDeclaraDAO.update(declaraUpdate);
				
				
			    //actualiza series y  detdeclara
			      this.actualizarSeries(paramsDiligencia);
				
				
			} catch (Exception e) {
				log.error("*** ERROR ***"+e.getMessage() , e);
				return res=false;
					
			}	
			// **************fin Actualizamos la DECLARACION********************//
		
		} catch (Throwable e) {
			log.error("*** ERROR ***", e);
			throw new ServiceException(this,"Ocurrio un error, por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador");
			
		}
		return res;
		
	}// fin grabarDiligenciaDescargaParcialDespacho
  
  
  
			
	/* RIN13-SWF-INICIO */
	  public void actualizarDeclaracionARevision(Map<String, Object> declaraUpdate)throws ServiceException{
		  
			declaraUpdate.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
			
			try {
				this.cabDeclaraDAO.update(declaraUpdate);
			} catch (Exception e) {
				log.error("*** ERROR ***"+e.getMessage() , e);			
			}	
	  }
	  /*RIN13-SWF-FIN*/
	
	  public String obtenerConsignatario(String codAduana, String annPresen, String codRegimen, String numDeclaracion, String numCorreDoc){
		  String consignatario =".";
		  
		  if(numCorreDoc ==  null){
				Map<String, Object> params = new HashMap<String, Object>();
			    params.put("COD_ADUANA", codAduana);
			    params.put("ANN_PRESEN", annPresen);
			    params.put("COD_REGIMEN", codRegimen);
			    params.put("NUM_DECLARACION", numDeclaracion);		  
			    numCorreDoc = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
		  }
		    
		  if(!SunatStringUtils.isEmpty(numCorreDoc))
		  {
		    Map<String, String> paramsParticipante = new HashMap<String, String>();
		    paramsParticipante.put("NUM_CORREDOC", numCorreDoc);
			    
		    Map<String, Object> participanteDoc = participanteDocDAO.findByDocumento(paramsParticipante);
		    if(participanteDoc != null && !participanteDoc.isEmpty() && participanteDoc.get("desc_razonsocial").toString()!=null)
		    	consignatario = participanteDoc.get("desc_razonsocial").toString();
		  }
		    
		  return consignatario;
	  }
  

/*RIN13FSW-FIN*/


	// CUS110301 lpalominom [inicio]
	/**
	 * {@inheritDoc}
	 */
	public RegularizacionBean obtenerParametrosSegundaDiligencia(Map<String, Object> parametros) {
		return cabDiligenciaDAO.obtenerParametrosActualizacionRegularizacion(parametros);
	}
	
	/**
	 * {@inheritDoc}
	 * @param params
	 */
	public void guardarActualizacionRegularizacion(Map<String,Object> params) {
		cabDiligenciaDAO.update(params);
	}
	
	// CUS110301 lpalominom [fin]
	
	/***** GGRANADOS RIN16PASE3 INI *****/
	public void notificarComunicacion(Map<String, Object> mapCabDeclaraActual, 
			String descComunicacion,
			String codNroRegistroFuncionario, 
			String usuarioEnvio,
			String razonSocialUsuario){
		
        StringBuffer numeroDua = new StringBuffer(mapCabDeclaraActual.get("COD_ADUANA").toString()).
        		append("-").
        		append(mapCabDeclaraActual.get("ANN_PRESEN").toString()).
        		append("-").
        		append(mapCabDeclaraActual.get("COD_REGIMEN").toString()).
        		append("-").
        		append(mapCabDeclaraActual.get("NUM_DECLARACION").toString());
        
        FechaBean fechaPublicacion = new FechaBean();
        FechaBean fechaVigencia = new FechaBean();
        fechaVigencia.setFecha("31/12/9999");

        Map<String, Object> mapMensaje = new HashMap<String, Object>();        
//        mapMensaje.put("cod_usuario", usuarioEnvio);
        mapMensaje.put("cod_usuario", new String[] {usuarioEnvio});
        mapMensaje.put("destinatario", razonSocialUsuario);
        mapMensaje.put("tip_usuario", Constantes.CONTRIBUYENTE);        
        mapMensaje.put("des_asunto", "Notificaci&oacute;n de Observaciones Dilig. de Regularizaci&oacute;n " + 
        numeroDua.toString());
        mapMensaje.put("fecha_emision", 
        		new StringBuilder(fechaPublicacion.getDia()).
        		append("/").
        		append(fechaPublicacion.getMes()).
                append("/").
                append(fechaPublicacion.getAnho()).toString());
        mapMensaje.put("cod_documento", numeroDua.toString());
        mapMensaje.put("descripcion", SunatStringUtils.convertirCaracteresEspecialesAHtml(descComunicacion));
        //Se solicito nombre completo de funcionario
        FiltroEspeDispo filtro = new FiltroEspeDispo();
        filtro.setCodPers(codNroRegistroFuncionario.toUpperCase());
        EspecialistaService especialistaService = fabricaDeServicios.getService("Asignacion.especialistaService");
        List<CatEmpleado> lst = especialistaService.buscarCatEmpleado(filtro);
        String nombreCompleto = lst.get(0).getApPate().toUpperCase()+" "+
        						lst.get(0).getApMate().toUpperCase()+" ,"+
        						lst.get(0).getNombres().toUpperCase();        
        mapMensaje.put("funcionario", nombreCompleto);
        StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
        PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
        publicacionAvisoService.insert(Constantes.COD_SERVICIO_NOTI_DILIG_REGULARIZACION, data, Constantes.CODIGO_NOTIFICACION,
                                       fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
		
	}
	/***** GGRANADOS RIN16PASE3 FIN *****/
	//INICIO RIN08
	
	/**
	 * NSIGAD permite la modificaci�n del �texto� de la diligencia de
	 * aduana de destino, siempre que: Se realice por un m�ximo de una vez;
	 */
	public Map<String,Object> validarActualizacionDestino(Map params) throws ServiceException{

		Map<String,Object> result = new HashMap<String,Object>();
		String mensaje = new String();
		String numCorredoc =  params.get("NUM_CORREDOC").toString();
		Boolean regOK = false;

		Map<String, Object> mapBusq = new HashMap<String, Object>();
		mapBusq.put("NUM_CORREDOC",numCorredoc);
		mapBusq.put("COD_TIPDILIGENCIA", new String[]{params.get("COD_TIPDILIGENCIA").toString()});

		try{		   
			Map<String,Object> ultimaActualizacion =  cabDiligenciaDAO.findUltimaDiligencia(mapBusq);
			if(ultimaActualizacion!=null){
				// Que el actor sea el mismo funcionario aduanero que registr� la diligencia de la DUA
				Map<String, Object> mapParamsAsig = new HashMap<String, Object>();
				mapParamsAsig.put("NUM_CORREDOC", numCorredoc);
				mapParamsAsig.put("COD_ESTREV", "01"); 
				mapParamsAsig.put("COD_GRUPO", Constantes.GRUPO_DESTINO); 
				Map<String, Object> mapEspeDespachoAsig = espeDocuDAO.findbyDocEstRev(mapParamsAsig);
				//	p24 pase 99
				if (mapEspeDespachoAsig == null || (mapEspeDespachoAsig != null && !CollectionUtils.isEmpty(mapEspeDespachoAsig) && !mapEspeDespachoAsig.get("cod_funcionario").equals(
                        params.get("COD_FUNCIONARIO")))){

					mensaje= "Diligencia de Aduana de Destino no fue registrada por usted.";

				}else{		    	
					Boolean seGrabaDiligencia = false;
					Integer numCorredocSol = Integer.parseInt(ultimaActualizacion.get("NUM_CORREDOC_SOL").toString());

					if(numCorredocSol<1){		 
						mapBusq.clear();
						mapBusq.put("NUM_CORREDOC",numCorredoc);
						mapBusq.put("COD_TIPDILIGENCIA_IN", new String[]{Constantes.COD_TIPO_DILIGENCIA_CONCLUSION,Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION,Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO}); //Rectificacion electronica o rectificacion de oficio, conclusion
						List<Map<String,Object>> rectificacionesMap = cabDiligenciaDAO.select(mapBusq); 
						seGrabaDiligencia = true;
						if(!rectificacionesMap.isEmpty()){
							Date fechaDiligDestino = SunatDateUtils.getDefaultDate();
							ValidaDiligenciaService validaDiligenciaService = fabricaDeServicios.getService("diligencia.ingreso.validaDiligenciaService");
							mapBusq.put("COD_TIPDILIGENCIA", new String[] { Constantes.DILIG_ADUANA_DESTINO});
						    Map<String, Object> mapUltimaDiligencia = validaDiligenciaService.findUltimaDiligencia(mapBusq,null);
						    if(!CollectionUtils.isEmpty(mapUltimaDiligencia)){
						    	fechaDiligDestino =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(mapUltimaDiligencia.get("FEC_REGIS").toString());
						    } 						    	
							for(Map<String,Object> rectificacion:rectificacionesMap){	
								Date fechaDiligencia = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(rectificacion.get("FEC_REGIS").toString());
								if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaDiligencia, fechaDiligDestino, "COMPARA_TODO")){
									seGrabaDiligencia = false;
									mensaje = "No puede modifcar la diligencia de aduana de destino por existir una diligencia Posterior o en Proceso";	
									break;
								}
							}						 						 					
						}
						if(seGrabaDiligencia){					  
							ultimaActualizacion.put("FEC_DILIGENCIA", new FechaBean().getTimestamp());
							ultimaActualizacion.put("FEC_MODIFICACION", new FechaBean().getTimestamp());
							ultimaActualizacion.put("NUM_CORREDOC_SOL", numCorredocSol+1);
							regOK=true;					  
							result.put("CAB_DILIGENCIA", ultimaActualizacion);
						}

					}else{		 
						mensaje = "Diligencia en Aduana de Destino fue modificada anteriormente, s�lo puede modificarse un maximo de 1 vez.";					 
					}
				}
			} 
			result.put("MENSAJE",mensaje);
			result.put("regOK",regOK);
			return result;
		}catch(Exception e){
			log.error("*** ERROR ***", e);
			throw new ServiceException(e, e.getMessage());
		}
	}

	
    public void grabarDiligenciaDespachoAduanaDestino(Map params) throws ServiceException  {
    List lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");	
    Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
    Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");   
    BigDecimal  totalAutoliqSoles =  params.get("totalAutoliqSoles")!=null? (BigDecimal)params.get("totalAutoliqSoles"): new BigDecimal(0);
    BigDecimal  totalAutoliqDolares =  params.get("totalAutoliqDolares")!=null? (BigDecimal)params.get("totalAutoliqDolares"): new BigDecimal(0);
    FechaBean fecActual = new FechaBean();
    String codFuncionario = (String) mapDilig.get("COD_FUNCIONARIO"); //PAS20175E220200051
    String flag = ""; // para saber de donde esta siendo accedido
    if (declaracion.get("COD_ESTDUA").equals(Constantes.ESTADO_CONCLU_PROCESO))
    {
      flag = "C"; // conclusion
    }

    System.out.println("Estamos dentro del: grabarDiligenciaDespacho");
    System.out.println("Parametros: " + params);
    Map<String, Object> mapaPK = new HashMap<String, Object>();

    mapaPK.put("NUM_CORREDOC", "NUM_CORREDOC");
//Mordonez - P24
//    List<IncidenciaBean> lstIncidencias = (ArrayList) params.get("lstIncidencias");
//    if (lstIncidencias != null && lstIncidencias.size() > 0)
//    {
//      List<Map<String, Object>> lstIncid = new ArrayList();
//      Map incid;
//      for (IncidenciaBean incidBean : lstIncidencias)
//      {
//        if (incidBean.getFlagIncidencia() != null && incidBean.getFlagIncidencia())
//        {
//          incid = new HashMap();
//          incid.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
//          incid.put("COD_TIPDILIGENCIA", mapDilig.get("COD_TIPDILIGENCIA"));
//          incid.put("COD_INCIDENCIA", incidBean.getCod_incidencia());
//          incid.put("MTO_ACTUAL", incidBean.getVal_actual());
//          incid.put("MTO_CORREGIDO", incidBean.getVal_anterior());
//
//          incid.put("DES_ADICIONAL", incidBean.getDes_adicional());
//          incid.put("DES_TABLA", incidBean.getDes_tabla());
//          incid.put("DES_CAMPO", incidBean.getDes_campo());
//          incid.put("VAL_CONDICION", incidBean.getVal_condicion());
//          incid.put("NOM_CAMPO_CONDI", incidBean.getNom_campo_condi());
//          incid.put("ITEMS_LIST", incidBean.getItemsList());
//          incid.put("CAB_ANTERIOR_MAP", incidBean.getCabAnteriorMap());
//          incid.put("CAB_ACTUAL_MAP", incidBean.getCabActualMap());
//          incid.put("DET_ANTERIOR_LIST", incidBean.getDetAnteriorList());
//          incid.put("DET_ACTUAL_LIST", incidBean.getDetActualList());
//          incid.put("ENTIDAD_MAESTRO", incidBean.getEntidadMaestro());
//          incid.put("ENTIDAD_DETALLE", incidBean.getEntidadDetalle());
//          incid.put("FLAG_INICIDENCIA", incidBean.getFlagIncidencia());
//
//          lstIncid.add(incid);
//        }
//      }
//      params.put("lstIncidencias", lstIncid);
//    }

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
                                                         + params.get("caduana").toString().trim()));
    String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
    System.out.println("Tipo de Diligencia: {" + tipDilig + "]");
    try
    {
      // para diligencia despacho actualizar la informacion de contingentes
      if (Constantes.DILIG_REV_DOCUMENTARIA.equals(tipDilig) || Constantes.DILIG_REC_FISICO.equals(tipDilig))
      {
         //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
    	  procesarGrabaContingente(params,tipDilig);
      }
      // Insertamos o actualizamos la DILIGENCIA
      mapDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));

      if (mapDilig.get("FEC_DILIGENCIA") == null)
      {
        mapDilig.put("FEC_DILIGENCIA", fecActual.getTimestamp());
      }

      // Mapeamos los datos para la rectificacion de oficio
      Map keyDilig = new HashMap();
      keyDilig.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      keyDilig.put("COD_TIPDILIGENCIA", mapDilig.get("COD_TIPDILIGENCIA"));

      mapDilig.put("dataOriginal", null);
      mapDilig.put("clave", keyDilig);

      try
      {
    	  System.out.println("Insertamos en cabDiligenciaDAO: " + mapDilig);
           this.cabDiligenciaDAO.insert(mapDilig);
      }
      catch (Exception e)
      {
        log.info("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:" + SojoUtil.toJson(mapDilig));
        System.out.println("*** NO EJECUTO INSERT DILIGENCIA SI NO UPDATE PARA LOS DATOS:" + SojoUtil.toJson(mapDilig));
        if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig))
        {
          throw new ServiceException(this, e);
        }
        else
        {
        	System.out.println("Actualizamos en cabDiligenciaDAO: " + mapDilig);
          this.cabDiligenciaDAO.update(mapDilig);
        }
      }

      //ggranados 179 no se usa
      //Map mapCabAdiDiligVinc = (HashMap) params.get("mapCabAdiDiligVinc");
    

      Map declaracionAnt = (HashMap) params.get("mapCabDeclara");

      // Obtenemos los registros que relacionan las series con los items
      Map fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      List lstSeriesItem = this.seriesItemDAO.select(fbKeys);
      params.put("lstSeriesItem", lstSeriesItem);
          

      Comparador comp = new Comparador();


      Map<String,Object> mapa=new HashMap<String,Object>();
      mapa.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      mapa.put("CNT_TOTSERIES", declaracion.get("CNT_TOTSERIES"));
      this.cabDeclaraDAO.update(mapa);
        
     
      
      // Actualizamos el estado de la asignacion
      Map prmtBusq = new HashMap();
      if (Constantes.TIPO_DILIG_ESTA_REGULARIZACION.equals(tipDilig))
      {
        prmtBusq.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC_SOL"));
      }
      else
      {
        prmtBusq.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
      }
      prmtBusq.put("COD_ESTREV", "06");

      Map mapEspeDocuAnt = this.espeDocuDAO.findbyDocEstRev(prmtBusq);
      if (mapEspeDocuAnt != null && mapEspeDocuAnt.size() > 0)
      {
        Map mapEspeDocu = new HashMap();
        mapEspeDocu.putAll(mapEspeDocuAnt);
        mapEspeDocu.put("cod_estrev", flag.equals("") ? "01" : "12");

        fbKeys = new HashMap();
        fbKeys.put("num_corredoc", "");
        fbKeys.put("fec_asig", "");

        
        Map<String,Object>  mapDiferencias = new HashMap();
        mapDiferencias = new HashMap();
        mapDiferencias = comp.comparaMapEstricto(mapEspeDocuAnt, mapEspeDocu, false, false, fbKeys);

        if (!MapUtils.esMapaNuloOVacio(mapDiferencias))
        {
          if (Comparador.esDataCambiada(mapDiferencias))
          {
            mapDiferencias.put("cod_estrev_ant", "06");
            mapDiferencias.put("cod_funcionario", params.get("cod_funcionario").toString());
            mapDiferencias.put("fec_termrev", "fec_termrev");
            this.espeDocuDAO.updateEstadoRevision(mapDiferencias);
            
            /*BandejaDocu beanBandeja=new BandejaDocu();
            beanBandeja.setNumCorredoc(new Long(declaracion.get("NUM_CORREDOC").toString().trim()));
            
            Map<String, Object> param=new  HashMap<String, Object>();
   	        param.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));
   	        List<Map<String, Object>> listaEspeAsig=asignacionManualService.obtenerEspecAsigDocumento(param);//lista ordenada by fecha_regisb asc
   	        if (listaEspeAsig.size()>0) {
              beanBandeja.setCodFuncionario(listaEspeAsig.get(0).get("COD_USUREGIS").toString());
              bandejaDocuDAO.modificarBandejaDocu(beanBandeja);
   	        }*/
                      
          }
        }
      }
     
      this.actualizarSeries(params);

      /* ggranados 179 no se usa
      List<Map<String, Object>> lstDetAutorizacionActual = (List) declaracion.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDetAutorizacion = (List) declaracionAnt.get("lstDetAutorizacion");
      List<Map<String, Object>> lstDocAutAsociadoActual = (List) declaracion.get("lstDocAutAsociado");
      List<Map<String, Object>> lstDocAutAsociado = (List) declaracionAnt.get("lstDocAutAsociado");
      List<Map<String, Object>> lstCabCertiOrigenActual = (List) declaracion.get("lstCabCertiOrigen");
      List<Map<String, Object>> lstCabCertiOrigen = (List) declaracionAnt.get("lstCabCertiOrigen");
      */
//Mordonez - P24	
      // Insertamos las incidencias
//      List<Map<String, Object>> lstIncidencias2 = (ArrayList) params.get("lstIncidencias");
//      if (lstIncidencias2 != null && lstIncidencias2.size() > 0)
//      {
//        List<String> lstItems;        
//        int numItm = 0;
//        Map keyIncid;
//        for (Map incid2 : lstIncidencias2)
//        {
//          // Mapeamos los datos para registrar la rectificacion
//          keyIncid = new HashMap();
//          keyIncid.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
//          keyIncid.put("COD_TIPDILIGENCIA", incid2.get("COD_TIPDILIGENCIA"));
//
//          incid2.put("dataOriginal", null);
//          incid2.put("clave", keyIncid);
//
//          if (incid2.get("ITEMS_LIST") != null && ((ArrayList<String>) incid2.get("ITEMS_LIST")).size() > 0)
//          {
//            lstItems = (ArrayList) incid2.get("ITEMS_LIST");
//            for (String itm : lstItems)
//            {                  
//            	  numItm += 1;
//                  incid2.put("NUM_SECINCID", "" + numItm);
//                  incid2.put("NUM_SERIE", itm);
//                  incidenciaService.insert(incid2);
//
//                  keyIncid.put("NUM_SECINCID", incid2.get("NUM_SECINCID"));
//                  this.registrarRectiOficio(incid2, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
//                                            Constantes.COD_TABLA_DET_INCIDENCIA);
//            }
//          }
//          else
//          {               	     
//        		  numItm += 1;
//                  incid2.put("NUM_SECINCID", "" + numItm);
//                  incidenciaService.insert(incid2);
//
//                  keyIncid.put("NUM_SECINCID", incid2.get("NUM_SECINCID"));
//                  this.registrarRectiOficio(incid2, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
//                                            Constantes.COD_TABLA_DET_INCIDENCIA);
//          }
//          if ("44".equals(incid2.get("COD_INCIDENCIA")))
//          {
//            marcaEstablecimiento(declaracion);
//          }
//        }
//      }
      
      
      //Mordonez - P24
      List<Incidencia> lstIncidencias2 = (ArrayList<Incidencia>) params.get("lstIncidencias");
      if(!CollectionUtils.isEmpty(lstIncidencias2)) {
         int numItm = 0;
        Map incidencia;
         for(Incidencia incidenciaBean:  lstIncidencias2) {
           numItm += 1;
          incidencia = new HashMap();
           incidencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
          incidencia.put("COD_TIPDILIGENCIA", tipDilig);

          incidencia.put("NUM_SECINCID", "" + numItm);
           incidencia.put("NUM_SERIE", incidenciaBean.getNumeroSerie());
           incidencia.put("COD_INCIDENCIA", incidenciaBean.getCodIncidencia());
         incidenciaService.insert(incidencia);
         Map<String, Object> mapRectif = new HashMap<String, Object>();
         this.registrarRectiOficio(mapRectif, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                 Constantes.COD_TABLA_DET_INCIDENCIA);
         
         if ("44".equals(incidenciaBean.getCodIncidencia().toString()))
         {
           marcaEstablecimiento(declaracion);
         }
         
         
        }
      }
      
     
      // Actualizamos las tablas del Formato B
     Map paramsFB = new HashMap();
      paramsFB.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
      paramsFB.put("lstFormBProveedor", declaracion.get("lstFormBProveedor"));
      paramsFB.put("lstFormBProveedorAnt", declaracionAnt.get("lstFormBProveedor"));
      paramsFB.put("tipDilig", tipDilig);
      this.actualizarFormatoB(paramsFB);



      // Grabamos las multas registradas
      List listaMultasSeleccionadas = (ArrayList) params.get("lstMultaDua");
      if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
      {
        String codDocumento = declaracion.get("NUM_CORREDOC").toString();
        String codTipoDiligencia = (String) mapDilig.get("COD_TIPDILIGENCIA");
        Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
        String tipoDocImp = (String) declaracion.get("COD_TIPDOC_PIM");
        String rucImp = (String) declaracion.get("NUM_DOCIDENT_PIM");
        Map paramMulta = new HashMap();
        paramMulta.put("COD_DOCUMENTO", codDocumento);
        paramMulta.put("NUM_CORREDOC", codDocumento);
        paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
        paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
        paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
        paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
        paramMulta.put("COD_ANTADU", "41");
        paramMulta.put("NUM_REG_USUARIO", codFuncionario);
        paramMulta.put("generarLC003", (Map<String, Object>) params.get("generacionLCMulta"));

        paramMulta.put("tipDilig", tipDilig);
        this.multaService.generarMulta(paramMulta, listaMultasSeleccionadas);
      }
      // PasePecoPAS20181U220200069	mol	
      String estadoResultadoAduanaDestinoMercancia = (String) mapDilig.get("estadoResultadoAduanaDestinoMercancia");
  	SolicitudPecoAmazoniaService solicitudPecoAmazoniaServiceImpl = fabricaDeServicios.getService("despaduanero2.solicitudPecoAmazoniaService");		
  	Map<String, Object> mapaSolicitud = new HashMap<String, Object>();
  	mapaSolicitud.put("codEstSol", new String[]{"01","02"});
  	String numCorredocDam = (String) declaracion.get("NUM_CORREDOC").toString();
  	boolean tieneSolicitudRenocimientoFisico = solicitudPecoAmazoniaServiceImpl.tieneSolicitudReconocimientoFisico(  numCorredocDam, mapaSolicitud);
	//String tieneIncTrib = declaracion.containsKey("tieneIncTrib")?declaracion.get("tieneIncTrib").toString():"N";
	HashMap diferenciaTributos = (HashMap) declaracion.get("diferenciaTributos");
	boolean tieneIncTribByTrib =  diferenciaTributos.get("tieneIncTribByTrib")!=null? (Boolean)diferenciaTributos.get("tieneIncTribByTrib"):false ;
	String des_consignatario = "";
	String numeroDocumentoIdentidadConsignatario ="";
	String numeroDocumentoIdentidadAgente= "";
	String des_agente = "";
	boolean existeGarantia = declaracion.get("NUM_CTACTE")!=null && !"".equals(declaracion.get("NUM_CTACTE").toString().trim())? true:false; 
	List listaAutoliquidaciones = (List) declaracion.get("lstAutoliquidaciones");
	
  	// reliquida 
	  Map parametroParticip = new HashMap();
		parametroParticip.put("numeroCorrelativo", numCorredocDam);
		parametroParticip.put("codTippartic", new String [] {"41","45"});
		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
		List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
		for (int i=0; i<listadoParticipante.size(); i++) {
 			Participante participante = listadoParticipante.get(i);
 			    if ("41".equals(participante.getTipoParticipante().getCodDatacat()) ) {
 			    	numeroDocumentoIdentidadAgente = participante.getNumeroDocumentoIdentidad();
 			    	des_agente =participante.getNumeroDocumentoIdentidad().concat("-").concat(participante.getNombreRazonSocial());
	 			 }
	 			if ("45".equals(participante.getTipoParticipante().getCodDatacat()) ) {
	 				 numeroDocumentoIdentidadConsignatario = participante.getNumeroDocumentoIdentidad();
	 				 des_consignatario = participante.getNumeroDocumentoIdentidad().concat("-").concat(participante.getNombreRazonSocial());
	 			 }
 		}
	
      boolean regularizaPagoPecoAmazonia = true;
      /*
       * DATOS PARA EL AVISO
       */
		Map<String, Object> dato = new HashMap<String, Object>();
		String des_declaracion = declaracion.get("COD_ADUANA").toString().concat("-").concat(declaracion.get("ANN_PRESEN").toString()).concat("-").concat(declaracion.get("COD_REGIMEN").toString()).concat("-").concat(declaracion.get("NUM_DECLARACION").toString());
		//dato.put("des_declaracion", declaracion.get("NUM_CORREDOC"));
		dato.put("des_declaracion",des_declaracion);
		
		dato.put("numCorredocDam", numCorredocDam);
		dato.put("des_solicitud","");
		if(tieneSolicitudRenocimientoFisico){
		//dato.put("des_solicitud",mapaSolicitud.get("numSolRecFisico") );
			String des_solicitud =  declaracion.get("COD_ADUDEST").toString().concat("-").concat(mapaSolicitud.get("annoSolicitud").toString()).concat("-").concat(mapaSolicitud.get("numeroSolicitud").toString());
			dato.put("des_solicitud",des_solicitud );
		}else{
						
			Expedi expedi = solicitudPecoAmazoniaServiceImpl.buscarExpedientePeco(numCorredocDam, declaracion.get("COD_ADUDEST").toString() , declaracion.get("ANN_PRESEN").toString(), declaracion.get("NUM_DECLARACION").toString());
			if(expedi!=null){
				String des_solicitud = 	declaracion.get("COD_ADUDEST").toString().concat("-").concat(expedi.getAnoexpedi().toString()).concat("-").concat(expedi.getNroexpedi().toString());
			dato.put("des_solicitud",des_solicitud);
			}
		}			
		
		dato.put("des_consignatario",des_consignatario);
		dato.put("numeroDocumentoIdentidadConsignatario",numeroDocumentoIdentidadConsignatario);
		dato.put("des_agente",des_agente);
		dato.put("numeroDocumentoIdentidadAgente",numeroDocumentoIdentidadAgente);
		dato.put("codaduana", declaracion.get("COD_ADUANA").toString());
		//FIN DE DATOS DE AVISO
		
	if(	(ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_NO_LLEGO.equals(estadoResultadoAduanaDestinoMercancia) || 
					ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_CONFORME.equals(estadoResultadoAduanaDestinoMercancia) ||
					ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(estadoResultadoAduanaDestinoMercancia))){
		//BigDecimal mtoDiferencialAfectarPecoAmazonia = BigDecimal.ZERO;
		//mtoDiferencialAfectarPecoAmazonia = SunatNumberUtils.toBigDecimal(declaracion.get("mtoDiferencialAfectarPecoAmazonia"));

		if (ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_NO_LLEGO.equals(estadoResultadoAduanaDestinoMercancia) || ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(estadoResultadoAduanaDestinoMercancia)){
			if (diferenciaTributos!=null && SunatNumberUtils.toBigDecimal(diferenciaTributos.get("MTO_TOTAL")).compareTo(BigDecimal.ZERO)>0 && !existeGarantia ){
				
				regularizaPagoPecoAmazonia = false;	
				solicitudPecoAmazoniaServiceImpl.procesarAvisoDiligenciaAduanaDestino("2",dato);
				
			}else{// con Garantia
				if (SunatNumberUtils.toBigDecimal(diferenciaTributos.get("MTO_TOTAL")).compareTo(BigDecimal.ZERO)>0 && (totalAutoliqSoles.compareTo(BigDecimal.ZERO)>0 || totalAutoliqDolares.compareTo(BigDecimal.ZERO)>0)){
					
					// existe autiliquidaciones que cubre el monto
					regularizaPagoPecoAmazonia = true;
					BandejaDocuDAO bandejaDocuDAO = (BandejaDocuDAO) fabricaDeServicios.getService("asignacion.bandejaDocuDAO");
					//se quita para mostrar la DAM AL JEFE
					Long numCorredoc=(new Long(numCorredocDam));
					BandejaDocu bandejaDocu = bandejaDocuDAO.consultarBandejaDocuByPK(numCorredoc);
					bandejaDocu.setFecAsig((new FechaBean()).getTimestamp());
					bandejaDocu.setIndjGrupoDestino("0");
					bandejaDocuDAO.modificarBandejaDocu(bandejaDocu);
					params.put("bandejaJefeDAM",false);
				  	if(tieneSolicitudRenocimientoFisico  ){ //&& SunatNumberUtils.toBigDecimal(diferenciaTributos.get("MTO_TOTAL")).compareTo(BigDecimal.ZERO)==0  el monto puede ser mayor o igual a 0 que cubre con la garantia
				  		SolicitudPecoAmazonia solicitud  = new SolicitudPecoAmazonia();  		
				  		 solicitud.setTipoSolicitud(ConstantesDataCatalogo.TIPO_SOLICITUD_RECONOCIMIENTO_FISICO);
					        solicitud.setEstadoSolicitud("03");
					        solicitud.setNumeroCorrelativo((Long) mapaSolicitud.get("numcorredocSol"));		
					        solicitudPecoAmazoniaServiceImpl.actualizarSolicitud(solicitud);
					     //ACTUALIZAR bandeja del jefe la opcion de ser asignado
					        //ACTUALIZAR EL CAMPO IND_JGRUPODESTINO = 0 EN BANDEJA_DOCU		        
					        
				  	}
				  	//envio del aviso			
					solicitudPecoAmazoniaServiceImpl.procesarAvisoDiligenciaAduanaDestino("1",dato);
					
				}else{

					regularizaPagoPecoAmazonia = false;			
					solicitudPecoAmazoniaServiceImpl.procesarAvisoDiligenciaAduanaDestino("2",dato);
					
					
				}
				
				
			}
		}else{
			if (diferenciaTributos!=null && SunatNumberUtils.toBigDecimal(diferenciaTributos.get("MTO_TOTAL")).compareTo(BigDecimal.ZERO)>0 && (!existeGarantia)){
				regularizaPagoPecoAmazonia = false;				
				solicitudPecoAmazoniaServiceImpl.procesarAvisoDiligenciaAduanaDestino("2",dato);
				
			}else{
			//regularizaPagoPecoAmazonia = true;
			Date fechadeclaracion = SunatDateUtils.getDateFromUnknownObject(declaracion.get("FEC_DECLARACION"));
			List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0054",fechadeclaracion);
			regularizaPagoPecoAmazonia = ResponseListManager.responseListHasErrors(listaOMA) ? false : true;

			BandejaDocuDAO bandejaDocuDAO = (BandejaDocuDAO) fabricaDeServicios.getService("asignacion.bandejaDocuDAO");
			//se quita para mostrar la DAM AL JEFE
			Long numCorredoc=(new Long(numCorredocDam));
			BandejaDocu bandejaDocu = bandejaDocuDAO.consultarBandejaDocuByPK(numCorredoc);
			bandejaDocu.setFecAsig((new FechaBean()).getTimestamp());
			bandejaDocu.setIndjGrupoDestino("0");
			bandejaDocuDAO.modificarBandejaDocu(bandejaDocu);
			params.put("bandejaJefeDAM",false);
		  	if(tieneSolicitudRenocimientoFisico  ){ //&& SunatNumberUtils.toBigDecimal(diferenciaTributos.get("MTO_TOTAL")).compareTo(BigDecimal.ZERO)==0  el monto puede ser mayor o igual a 0 que cubre con la garantia
		  		SolicitudPecoAmazonia solicitud  = new SolicitudPecoAmazonia();  		
		  		 solicitud.setTipoSolicitud(ConstantesDataCatalogo.TIPO_SOLICITUD_RECONOCIMIENTO_FISICO);
			        solicitud.setEstadoSolicitud("03");
			        solicitud.setNumeroCorrelativo((Long) mapaSolicitud.get("numcorredocSol"));		
			        solicitudPecoAmazoniaServiceImpl.actualizarSolicitud(solicitud);
			     //ACTUALIZAR bandeja del jefe la opcion de ser asignado
			        //ACTUALIZAR EL CAMPO IND_JGRUPODESTINO = 0 EN BANDEJA_DOCU		        
			        
		  	}
		  	//envio del aviso
			solicitudPecoAmazoniaServiceImpl.procesarAvisoDiligenciaAduanaDestino("1",dato);
		}
	  }
	}
	//PAS20181U220200069 - mtorralba 20190405 - Se incluye porque si el monto liquidado ha variado, corresponde grabar la nueva liquidacion.
	LiquidaDeclaracionPecoAmazoniaService liquidaDeclaracionPecoAmazoniaService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionPecoAmazoniaService");
	boolean diferenciaMontosReliquidados = liquidaDeclaracionPecoAmazoniaService.montosReliquidadosDiferentes(declaracion);
	
	if(regularizaPagoPecoAmazonia || diferenciaMontosReliquidados ){
  	  if (!Constantes.TIPO_DILIG_ESTA_REGULARIZACION_OFICIO.equals(tipDilig)){	
			if (!CollectionUtils.isEmpty(lstDetDeclara)) {
				Map mapParamsDilig = new HashMap();
				mapParamsDilig.put("mapCabDeclaraActual", declaracion);
				mapParamsDilig.put("mapCabDiligenciaActual", mapDilig);
			
               if (params.get("lstMultaDua")!=null){
		        mapParamsDilig.put("generacionLCMulta", params.get("generacionLCMulta"));
		        mapParamsDilig.put("lstMultaDuaOkResolucion", params.get("lstMultaDuaOkResolucion"));
               }
				
               mapParamsDilig.put("generacionLCTributo", params.get("generacionLCTributo"));
            
               
            
               mapParamsDilig.put("generarLC15_SI_9", params.get("generarLC15_SI_9") == null? "NO" : params.get("generarLC15_SI_9").toString().trim() );
               mapParamsDilig.put("generarLC15_NO_9", params.get("generarLC15_NO_9") == null? "NO" : params.get("generarLC15_NO_9").toString().trim() );
            
               
				if (!Constantes.REGIMEN_70_DEPOSITO.equals((String) declaracion.get("COD_REGIMEN"))) {
					this.liquidaDeclaracionService.grabaLiqDiligencia(mapParamsDilig);
		
					params.put("mensaje", mapParamsDilig.get("mensaje"));
					
				}
			}
       }
	}
      

    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Ha ocurrido un error al inserta los datos");
    }
    catch (Throwable e)
    {
      log.error("DiligenciaServiceImpl : grabarDiligenciaDespacho - ERROR: ", e);
      throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo de grabado de la diligencia");
    }
  }	
//FIN RIN08


//	<RIN10:eruestaa>
	/**
	 * @param mapMensaje
	 * @author eruestaa
	 */
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService#grabarNotificacionesLCVP(java.util.Map)
	 */
	public void grabarNotificacionesLCVP(Map<String, Object> mapMensaje) {
		
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
	
//		FechaBean fechaDeclara = new FechaBean();
//		fechaDeclara.setFecha((String)mapMensaje.get("fec_regis"));
		
		String descAduana = "";
		descAduana = catalogoAyudaService.getDescripcionDataCatalogo(
				Constants.COD_CATALOG_ADUANA, mapMensaje.get("cod_aduana").toString());
	
		String strNumeroDeclaracion = mapMensaje.get("num_declaracion").toString().trim();
	
		int j = strNumeroDeclaracion.length();
		for (int i = 0; i < 6 - j; i++) {
			strNumeroDeclaracion = "0" + strNumeroDeclaracion;
		}
	
		// Notificaci�n al Despachador de Aduana por Rectificaci�n de Dua
		String cod_usuario = mapMensaje.get("numruc").toString();
		mapMensaje.put("tip_usuario", "1"); // default contribuyente		
		mapMensaje.put("cod_usuario", new String[] { cod_usuario!=null? cod_usuario:"" });
		mapMensaje.put("des_ruc_razon_social",mapMensaje.get("razon_social"));
		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
//		mapMensaje.put("cod_aduana",  mapMensaje.get("cod_aduana").toString());//ya viene en el map
		mapMensaje.put("des_intendencia", descAduana);
		mapMensaje.put("ann_presen", mapMensaje.get("ann_presen").toString());
//		mapMensaje.put("cod_regimen", mapMensaje.get("cod_regimen").toString());//ya viene en el map
		mapMensaje.put("num_declaracion", strNumeroDeclaracion);
//		mapMensaje.put("numruc", mapMensaje.get("numruc").toString());//ya viene en el map
		String dua = mapMensaje.get("cod_aduana").toString() + "-"
				+ mapMensaje.get("ann_presen").toString() + "-"
				+ mapMensaje.get("cod_regimen").toString() + "-"
				+ mapMensaje.get("num_declaracion").toString();
		
		mapMensaje.put("dua", dua);
		
		mapMensaje.put("des_asunto", Constants.COMUNICACION_LC_VALOR_PROVISIONAL_GENERADA);
		String unidadRemitente = "118".equals(mapMensaje.get("cod_aduana").toString())?
				"la Divisi�n de Importaci�n de la IAMC":"el Departamento de T�cnica Aduanera";
		mapMensaje.put("des_unidad_organica", unidadRemitente);
	
		for (Map.Entry<String, Object> entry : mapMensaje.entrySet()) {
			if (entry.getValue() == null || entry.equals(""))
				mapMensaje.put(entry.getKey(), "-");
		}
	
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		if("SI".equalsIgnoreCase(mapMensaje.get("tieneGarantia160").toString())){
			Integer codigoNotifLCVP = Integer.parseInt(Constants.COD_NOTIF_RECTIF_81);
			publicacionAvisoService.insert(codigoNotifLCVP, data,
					Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
		}else{
			Integer codigoNotifLCVP = Integer.parseInt(Constants.COD_NOTIF_RECTIF_80);
			publicacionAvisoService.insert(codigoNotifLCVP, data,
					Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
		}
	}
//	</RIN10:eruestaa>	
  /*********************** SET DE SPRING **********************************/

  public void setVehiCeticoDAO(VehiCeticoDAO vehiCeticoDAO)
  {
    this.vehiCeticoDAO = vehiCeticoDAO;
  }

  public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO)
  {
    this.montoGastoDAO = montoGastoDAO;
  }

  public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO)
  {
    this.cabDiligenciaDAO = cabDiligenciaDAO;
  }

  public void setComunicacionDAO(ComunicacionDAO comunicacionDAO)
  {
    this.comunicacionDAO = comunicacionDAO;
  }

  public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO)
  {
    this.cabDeclaraDAO = cabDeclaraDAO;
  }

  public void setObservacionDAO(ObservacionDAO observacionDAO)
  {
    this.observacionDAO = observacionDAO;
  }

  public void setCabCertiOrigenDAO(CabCertiOrigenDAO cabCertiOrigenDAO)
  {
    this.cabCertiOrigenDAO = cabCertiOrigenDAO;
  }

  public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
  {
    this.docAutAsociadoDAO = docAutAsociadoDAO;
  }

  public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService)
  {
    this.liquidaDeclaracionService = liquidaDeclaracionService;
  }

  public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO)
  {
    this.detDeclaraDAO = detDeclaraDAO;
  }

  public void setTabBolQuimDAO(TabBolQuimDAO tabBolQuimDAO)
  {
    this.tabBolQuimDAO = tabBolQuimDAO;
  }

  public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
  {
    this.formBProveedorDAO = formBProveedorDAO;
  }

  public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO)
  {
    this.formBMontoDAO = formBMontoDAO;
  }

  public void setCondicionTransaDAO(CondicionTransaDAO condicionTransaDAO)
  {
    this.condicionTransaDAO = condicionTransaDAO;
  }

  public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO)
  {
    this.participanteDocDAO = participanteDocDAO;
  }

  public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO)
  {
    this.itemFacturaDAO = itemFacturaDAO;
  }

  public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO)
  {
    this.seriesItemDAO = seriesItemDAO;
  }

  public void setReferenciaDudaDAO(ReferenciaDudaDAO referenciaDudaDAO)
  {
    this.referenciaDudaDAO = referenciaDudaDAO;
  }

  public void setPlazosProcesoDAO(PlazosProcesoDAO plazosProcesoDAO)
  {
    this.plazosProcesoDAO = plazosProcesoDAO;
  }

  public void setPitTipoPlazosDAO(PitTipoPlazosDAO pitTipoPlazosDAO)
  {
    this.pitTipoPlazosDAO = pitTipoPlazosDAO;
  }

  public void setEspeDocuDAO(EspeDocuDAO espeDocuDAO)
  {
    this.espeDocuDAO = espeDocuDAO;
  }

  public void setConsultaDAO(ConsultaDAO consultaDAO)
  {
    this.consultaDAO = consultaDAO;
  }

  public void setMultaService(MultaService multaService)
  {
    this.multaService = multaService;
  }

  public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO)
  {
    this.comprobPagoDAO = comprobPagoDAO;
  }

  public FabricaDeServicios getFabricaDeServicios()
  {
    return this.fabricaDeServicios;
  }

  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }

  public HotSwappableTargetSource getSwapperDatasource()
  {
    return this.swapperDatasource;
  }

  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }

  public void setCatEmpleadoDAO(CatEmpleadoDAO catEmpleadoDAO)
  {
    this.catEmpleadoDAO = catEmpleadoDAO;
  }

  public void setCabAdiAdmTemDAO(CabAdiAdmTemDAO cabAdiAdmTemDAO)
  {
    this.cabAdiAdmTemDAO = cabAdiAdmTemDAO;
  }

  public void setEstabnoaptoDAO(EstabnoaptoDAO estabnoaptoDAO)
  {
    this.estabnoaptoDAO = estabnoaptoDAO;
  }

  public void setDatadoService(Datado2Service datadoService)
  {
    this.datadoService = datadoService;
  }

  public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO)
  {
    this.docuPreceDuaDAO = docuPreceDuaDAO;
  }

  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {
    this.rectiOficioDAO = rectiOficioDAO;
  }

  public void setSequenceDAO(SequenceDAO sequenceDAO)
  {
    this.sequenceDAO = sequenceDAO;
  }

  public void setConvenioSerieDAO(ConvenioSerieDAO convenioSerieDAO)
  {
    this.convenioSerieDAO = convenioSerieDAO;
  }

  public DetAdiAtpaDAO getDetAdiAtpaDAO()
  {
    return detAdiAtpaDAO;
  }

  public void setDetAdiAtpaDAO(DetAdiAtpaDAO detAdiAtpaDAO)
  {
    this.detAdiAtpaDAO = detAdiAtpaDAO;
  }

  public void setFacturaSerieDAO(FacturaSerieDAO facturaSerieDAO)
  {
    this.facturaSerieDAO = facturaSerieDAO;
  }

  public void setFormaFactuDAO(FormaFactuDAO formaFactuDAO)
  {
    this.formaFactuDAO = formaFactuDAO;
  }

  public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO)
  {
    this.detAutorizacionDAO = detAutorizacionDAO;
  }

  public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO)
  {
    this.cabSolrectiDAO = cabSolrectiDAO;
  }

  public void setCatalogoAyudaService(
                                      CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }

  public void setSoporteService(SoporteService soporteService)
  {
    this.soporteService = soporteService;
  }

  public void setCabAdiDiligVincDAO(CabAdiDiligVincDAO cabAdiDiligVincDAO)
  {

    this.cabAdiDiligVincDAO = cabAdiDiligVincDAO;
  }

  public void setGrabarContingentesService(
                                           GrabarContingentesService grabarContingentesService)
  {
    this.grabarContingentesService = grabarContingentesService;
  }

  public void setGrabarGeneralService(GrabarGeneralService grabarGeneralService)
  {
    this.grabarGeneralService = grabarGeneralService;
  }

  public void setIncidenciaService(IncidenciaService incidenciaService)
  {
    this.incidenciaService = incidenciaService;
  }
// RIN16
//  public void setPublicacionAvisoService(PublicacionAvisoService publicacionAvisoService)
//  {
//    this.publicacionAvisoService = publicacionAvisoService;
//  }

  public void setGrabarDeclaracionService(
                                          GrabarDeclaracionService grabarDeclaracionService)
  {
    this.grabarDeclaracionService = grabarDeclaracionService;
  }

/*RIN13FSW-INICIO*/
	//<EHR>
	public void setMovCargaPartiDAO(MovCargaPartiDAO movCargaPartiDAO) {
		this.movCargaPartiDAO = movCargaPartiDAO;
	}
	public void setDatadoDAO(DatadoDAO datadoDAO) {
		this.datadoDAO = datadoDAO;
	}
	//</EHR>
  /*RIN13FSW-FIN*/
  /* INICIO PAS20124E600000358 */

  public void setSoporteComparadorService(SoporteComparadorService soporteComparadorService)
  {

    this.soporteComparadorService = soporteComparadorService;
  }

  public void setRectificacionOficioService(RectificacionOficioService rectificacionOficioService)
  {

    this.rectificacionOficioService = rectificacionOficioService;
  }

	public void setdiligenciaCulminacionPecoService(DiligenciaCulminacionPecoService diligenciaCulminacionPecoService) {
		this.diligenciaCulminacionPecoService = diligenciaCulminacionPecoService;
	}

	public void setVehiCeticoService(VehiCeticoService vehiCeticoService) {
	this.vehiCeticoService = vehiCeticoService;
}

//P13 JMCV-INICIO 
public void setAsignacionManualService(AsignacionManualService asignacionManualService) {
	this.asignacionManualService = asignacionManualService;
  }
  

public void setAyudaServiceDataAtributo(AyudaServiceDataAtributo ayudaServiceDataAtributo) {
		this.ayudaServiceDataAtributo = ayudaServiceDataAtributo;
}

public void setDiligenciaService(DiligenciaService diligenciaService){
  this.diligenciaService = diligenciaService;
}

public void setSerieService(SerieService serieService){
 this.serieService = serieService;
}

public void setResolucionService(ResolucionService resolucionService){
 this.resolucionService = resolucionService;	
}
/* PAS20145E220000399 INICIO GGRANADOS */
//public void setConstantesAtributo(ConstantesAtributo constantesAtributo){
//this.constantesAtributo = constantesAtributo;	
//}
/* PAS20145E220000399 FIN GGRANADOS */

public void setDeclaracionService(DeclaracionService declaracionService)
{
  this.declaracionService = declaracionService;
}

public void setParticipanteService(ParticipanteService participanteService) {
	this.participanteService = participanteService;
}

public void setDocumentoInternoService(DocumentoInternoService documentoInternoService) {
	this.documentoInternoService = documentoInternoService;
}
  public void setvFOBProvisionalDAO(VFOBProvisionalDAO vFOBProvisionalDAO) {
	this.vFOBProvisionalDAO = vFOBProvisionalDAO;
  }

  public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO) {
	this.formBItemDescriDAO = formBItemDescriDAO;
  }
	
//INICIO - RIN 14
public void setMercanciaRestringidaEntidadService(MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService) {
	this.mercanciaRestringidaEntidadService = mercanciaRestringidaEntidadService;
}
//INICIO - FIN 14
//P13 JMCV-FIN

/**INICIO-RIN13**/

  	/**
	 * Verifica si existe diligencia
	 * 
	 * @param diligenciaBusqueda
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
	@Override
	public boolean hasDiligencia(Diligencia diligenciaBusqueda) throws ServiceException {
		return this.cabDiligenciaDAO.hasDiligencia(diligenciaBusqueda);
	}

	/**
	 * Verifica si existe diligencia
	 * 
	 * @param mapDiligenciaBusqueda
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
	@Override
	public boolean hasDiligencia(Map<String, Object> mapDiligenciaBusqueda) throws ServiceException {
		return this.cabDiligenciaDAO.hasDiligenciaByParameterMap(mapDiligenciaBusqueda);
	}
	
	/**
	 * Obtiene una diligencia 
	 * de acuerdo a los parametros de b�squeda
	 * 
	 * @param diligenciaBusqueda Parametros de b�squeda
	 * @return diligencia
	 * @author gbecerrav
	 */
	@Override
	public Diligencia obtenerDiligencia(Diligencia diligenciaBusqueda) throws ServiceException {
		return this.cabDiligenciaDAO.findByPrimaryKey(diligenciaBusqueda);
	}
	
	/**
	 * Inserta un registro de diligencia 
	 * con campos selectivos
	 * @param diligencia Diligencia a registrar
	 * @return 
	 * @author gbecerrav
	 */
	@Override
	public void insertarDiligencia(Diligencia diligencia)
			throws ServiceException {
		this.cabDiligenciaDAO.insertSelective(diligencia);
	}

	/**
	 * Inserta un registro de comunicacion 
	 * con campos selectivos
	 * @param comunicacion Comunicacion a registrar
	 * @return 
	 * @author gbecerrav
	 */
	@Override
	public void insertarComunicacion(Comunicacion comunicacion)
			throws ServiceException {
		//Verificar pq estan obteniendo la secuencia de max() + 1 y no con el sequenceDAO (SECOMUNICACION)
		//ya que con la forma actual puede haber problemas de concurrencia ??????????????????????????????????????????????????
		comunicacion.setNumeroNota(new Long(comunicacionDAO.obtenerSiguienteCorrelativo())); 
		this.comunicacionDAO.insertSelective(comunicacion);
	}
/**FIN-RIN13**/
// hosorio rin 12
	
	
	private void registroAnforaDiligeciaReconocimientoFisico04_05(
			Map<String, Object> declaracion) {
		Declaracion declara=new Declaracion();
		  declara.setDua(new DUA());
		  
		   declara.getDua().setNumcorredoc(((BigDecimal)declaracion.get("NUM_CORREDOC")).longValue());
		  
		  declara.getDua().setCodEstdua((String)declaracion.get("COD_ESTDUA"));
		  declara.getDua().setCodregimen((String) declaracion.get("COD_REGIMEN"));
		  declara.getDua().setCodaduanaorden( (String) declaracion.get("COD_ADUANA"));
		  declara.getDua().setAnnpresen(Integer.parseInt(((String)declaracion.get("ANN_PRESEN"))));
		  declara.setNumeroDeclaracion(Long.valueOf((String) declaracion.get("NUM_DECLARACION")));
		  declara.getDua().setCodmodalidad((String)declaracion.get("COD_MODALIDAD"));
		  
		  //hosoriov 179
		  asignacionService.registrarDeclaracionAnfora(declara, declaracion.get("COD_MOTIVOREVISION").toString());
}

public void setAsignacionService(AsignacionService asignacionService) {
	this.asignacionService = asignacionService;
}

public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
	this.indicadorDUADAO = indicadorDUADAO;
}

private void actualizarContadorReconoFisico04_05(Map<String, Object> declaracion) {
	Map<String, Object> paramsIndiRecFis =new HashMap<String, Object>();
	  paramsIndiRecFis.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
	  paramsIndiRecFis.put("cod_indicador", Constantes.INDICADOR_CONTADOR_RECFISIC_04_05);
	  paramsIndiRecFis.put("ind_activo", Constantes.INDICADOR_DUA_ACTIVO);
	
	  Map<String,Object> mpResultado= indicadorDUADAO.findByDocumentoAndValor(paramsIndiRecFis);
	  
	  
	  
	     paramsIndiRecFis.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
	     paramsIndiRecFis.put("COD_INDICADOR", Constantes.INDICADOR_CONTADOR_RECFISIC_04_05);
	  
	  if(CollectionUtils.isEmpty(mpResultado)){
	    	  
	      paramsIndiRecFis.put("COD_TIPOREGISTRO", "1");		    		        
		  indicadorDUADAO.insert(paramsIndiRecFis);
	  }
	  else {
		 Integer cantidadRecFisico04_05 =  Integer.valueOf((String) mpResultado.get("COD_TIPOREGISTRO"));
		 cantidadRecFisico04_05=cantidadRecFisico04_05+1;
		 paramsIndiRecFis.put("COD_TIPOREGISTRO", cantidadRecFisico04_05);
		 indicadorDUADAO.updateByPrimaryKeySelective(paramsIndiRecFis);
	  }
}

// hosoriov

	/*  //Inicio PAS20155E220000054 */
	public ObjectResponseUtil validarResolucion(List<ResCabBean> lstResoluciones, Map<String, Object> mapCabDeclara) {
		//verificar si existe la resolucion
		String regimenResolucion="";

		ObjectResponseUtil respuesta = new ObjectResponseUtil();
		respuesta.setRespuesta(false);
		if(CollectionUtils.isEmpty(lstResoluciones)){
			//resolucion no existe
			respuesta = new ObjectResponseUtil("Resoluci�n inv�lida");//Se usa para multa y tributos - PAS20155E220000166
			return respuesta;
		}
		
		//verificar si la resolucion esta asociada a la dua
		for (ResCabBean resCabBean : lstResoluciones) {
			
			 if(resCabBean.getTipoDocReferencia().equals(Integer.parseInt(ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_DEFINITIVA))){
				 regimenResolucion=ConstantesDataCatalogo.REG_IMPO_CONSUMO;
			  }else if(resCabBean.getTipoDocReferencia().equals(Integer.parseInt(ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_IMPORTACION_TEMPORAL))){
				  regimenResolucion=ConstantesDataCatalogo.REG_ADM_TEMP_RME;
			  }else if(resCabBean.getTipoDocReferencia().equals(Integer.parseInt(ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_ADMISION_TEMPORAL))){
				  regimenResolucion=ConstantesDataCatalogo.REG_ADM_TEMP_PA;
			  }else if(resCabBean.getTipoDocReferencia().equals(Integer.parseInt(ConstantesDataCatalogo.COD_DCTO_TRAMITE_DECLARACION_DE_DEPOSITO))){
				  regimenResolucion=ConstantesDataCatalogo.REG_DEPOSITO;
			  }
			
			if(//mapCabDeclara.get("COD_ADUANA").toString().equals(resCabBean.getCodiAdua()) && la aduana ya se valida en el query de lstResoluciones
					!(SunatNumberUtils.toInteger(mapCabDeclara.get("NUM_DECLARACION")).compareTo(resCabBean.getNroDocReferencia()) == 0 &&
					mapCabDeclara.get("COD_REGIMEN").toString().equals(regimenResolucion) &&
					mapCabDeclara.get("ANN_PRESEN").toString().equals(resCabBean.getAnnoDocReferencia()))){

				respuesta = new ObjectResponseUtil("Resoluci�n no est� asociada a la declaraci�n");//Se usa para multa y tributos - PAS20155E220000166
			}

		}
		return respuesta;
	}
	/*  //FIN PAS20155E220000054 */

	// Inicio P46 3006
	/**
	 * Metodo que permite validar sin un objeto es nulo o vacio
	 * 
	 * @param objeto
	 * @return
	 */
	private boolean esNuloOVacio(Object objeto) {
		return objeto == null || "".equals(objeto.toString().trim());
	}
	
	/**
	 * Metodo que permite obtener un bean de tipo Declaracion que sera
	 * usado en las validaciones de documento autorizante de tipo donacion
	 * 
	 * @param camposValidar
	 * @return
	 */
	private Declaracion getDeclaracion(Map<String, Object> camposValidar) {
		DatoOtroDocSoporte datoOtroDocSoporte = new DatoOtroDocSoporte();

		//amancilla inicio PAS20165E220200126
		datoOtroDocSoporte.setCodtipoproceso(esNuloOVacio(camposValidar.get("tipoProceso"))?"":camposValidar.get("tipoProceso").toString());
		datoOtroDocSoporte.setCodtipodocasoc(esNuloOVacio(camposValidar.get("tipoDocAsoc"))?"":camposValidar.get("tipoDocAsoc").toString());
		datoOtroDocSoporte.setDesentidad(esNuloOVacio(camposValidar.get("nombreEntidadEmi"))?"":camposValidar.get("nombreEntidadEmi").toString());
		datoOtroDocSoporte.setCodtipodocentidad(esNuloOVacio(camposValidar.get("tipoDocEntidad"))?"":camposValidar.get("tipoDocEntidad").toString());
		
		Object numDocEntidad = camposValidar.get("numDocEntidad");
		if(!esNuloOVacio(numDocEntidad) && SunatStringUtils.isNumeric(numDocEntidad.toString())) {
			datoOtroDocSoporte.setCodentidademisora(Long.valueOf(numDocEntidad.toString()));
		}
		
		datoOtroDocSoporte.setCodtipoentidad(esNuloOVacio(camposValidar.get("codTipoEntidad"))?"":camposValidar.get("codTipoEntidad").toString());
		datoOtroDocSoporte.setNumdocasoc(esNuloOVacio(camposValidar.get("numDoc"))?"":camposValidar.get("numDoc").toString());
		//amancilla fin PAS20165E220200126
		//EJHM
		datoOtroDocSoporte.setIndicadorEliminado(0);
		
	
		
		if(!esNuloOVacio(camposValidar.get("fechaEmision"))) {
			datoOtroDocSoporte.setFecdocasoc(SunatDateUtils.getDate(camposValidar.get("fechaEmision").toString(), "yyyy-MM-dd"));
		}
		
		// Se usa cero para que tenga un valor y asi poder reutilizar la validacion
		// hecha para el subsistema 3003
		datoOtroDocSoporte.setNumsecdocum(0);
		
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte = new Elementos<DatoOtroDocSoporte>();
		listOtrosDocSoporte.add(datoOtroDocSoporte);
		
		Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
		listDatoSerie.add(getDatoSerie(camposValidar));
		
		DUA dua = new DUA();
		dua.setCodtipotratamiento((String)camposValidar.get("COD_TIPTRATMERC"));
		dua.setCodregimen((String)camposValidar.get("COD_REGIMEN"));
		dua.setListOtrosDocSoporte(listOtrosDocSoporte);
		dua.setListSeries(listDatoSerie);
		
		Declaracion declaracion = new Declaracion();
		declaracion.setDua(dua);
		
		return declaracion;
	}
	
	/**
	 * Metodo que permite obtener un bean de tipo DatoSerie que sera
	 * usado en las validaciones de documento autorizante de tipo donacion
	 * 
	 * @param camposValidar
	 * @return
	 */
	private DatoSerie getDatoSerie(Map<String, Object> camposValidar) {
		DatoSerieDocSoporte datoSerieDocSoporte = new DatoSerieDocSoporte();
		
		// Se usa cero para que tenga un valor y asi poder reutilizar la validacion
		// hecha para el subsistema 3003
		datoSerieDocSoporte.setNumiddocsoporte(0);
		
		Elementos<DatoSerieDocSoporte> listSerieDocSoporte = new Elementos<DatoSerieDocSoporte>();
		listSerieDocSoporte.add(datoSerieDocSoporte);
		
		DatoSerie datoSerie = new DatoSerie();
		//amancilla inicio PAS20165E220200126
		datoSerie.setNumserie(Integer.valueOf( esNuloOVacio(camposValidar.get("numSecSerie"))?"0":camposValidar.get("numSecSerie").toString()));
		datoSerie.setListSerieDocSoporte(listSerieDocSoporte);
		
		if(!"".equals(camposValidar.get("codigoLiberatorio")) && camposValidar.get("codigoLiberatorio")!=null) {
			datoSerie.setCodliberatorio(Integer.valueOf(camposValidar.get("codigoLiberatorio").toString()));
		}
		//amancilla fin PAS20165E220200126
		return datoSerie;
	}
	
	/**
	 * pre requisito para su uso necesitamos  obtener  el numcorredoc.
	 * logica  donde  hace la busqueda  en participante docu
	 *  de la lista  tenemos  que obtener  para mostrar la razon social
	 *  ejemplo dua : numcorredoc : xxxxx tipoParticipante : 45
	 */
	public String obtenerAgentesBeneficiarios(String numCorredoc, String tipoParticipante){
		String consignatario =".";
		Map<String, Object> participante = new HashMap<String, Object>();
	   participante.put("numeroCorrelativo", numCorredoc);
	    participante.put("codTipoParticipante",  tipoParticipante);
	    List<Participante> listaParticipante = participanteService.obtenerParticipanteByParameterMap(participante);
	    	if(listaParticipante!=null && listaParticipante.size()>0){
	    		return listaParticipante.get(0).getNombreRazonSocial();
	    	}
	  return consignatario;
	}
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion
	 */
	public String validarDocAutorizanteDonacionDiligencia(Map<String, Object> camposValidar) {
		String rpta = "ok";
	
		Declaracion declaracion = getDeclaracion(camposValidar);
		
		ValTratamientoDonacionService valTratamientoDonacionService = fabricaDeServicios.getService("ValTratamientoDonacion");
		
		List<Map<String, String>> result = valTratamientoDonacionService.validarDocAutorizanteDonacionDiligencia(declaracion);
		 
		if(result.size() > 0) {
			StringBuilder sbError = new StringBuilder();
			
			for(Map<String, String> error : result) {
				String msjError = error.get("desError");
				
				if(msjError.toUpperCase().startsWith("SERIE (")) {
					String strBuscar = "): ";
					msjError = msjError.substring(msjError.indexOf(strBuscar) + strBuscar.length());
				}
				sbError.append("<p>").append(msjError).append("</p>");
			}
			
			rpta = sbError.toString();
		}
		
		return rpta;
	}
	// Fin P46 3006
	//INICIO PASE 153
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo Incentivo Migratorio
	 */
	public String validarDocAutorizanteIncentivoMigratorio(Map<String, Object> camposValidar) {
		String rpta = "ok";
			
		
		//List<Map<String, String>> result = ValTratamientoDonacion.validarDocAutorizanteIncentivoMigratorio(declaracion);
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();		
        List<Map<String,Object>> listCatRefRuc=new ArrayList<Map<String,Object>>(); 
		
		
		Map<String,String> paramsCatRefRuc=new HashMap<String,String>();
		paramsCatRefRuc.put("ctipoUso", "IM");		
		paramsCatRefRuc.put("tbaseLegal_like", camposValidar.get("fechaEmision").toString().substring(0, 4) +"-"+camposValidar.get("numDoc")+"%"+camposValidar.get("numDocEntidad"));
		listCatRefRuc=((CatRefRucDAO)fabricaDeServicios.getService("catRefRucCentralizadaDAO")).findByMap(paramsCatRefRuc);		 
		
		if (listCatRefRuc==null || listCatRefRuc.isEmpty()){			
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("01167",new String[]{camposValidar.get("fechaEmision").toString().substring(0, 4),camposValidar.get("numDoc").toString()+'-'+camposValidar.get("numDocEntidad")}));			
  
		}				
		if(result.size() > 0) {
			StringBuilder sbError = new StringBuilder();   
			
			for(Map<String, String> error : result) {
				String msjError = error.get("desError");
				
				if(msjError.toUpperCase().startsWith("SERIE (")) {
					String strBuscar = "): ";
					msjError = msjError.substring(msjError.indexOf(strBuscar) + strBuscar.length());
				}
				sbError.append("<p>").append(msjError).append("</p>");
			}
			
			rpta = sbError.toString();
		}
		
		return rpta;
	}
	//FIN DE PASE 153
	
	/**P46**/
	public String obtenerTipoDiligencia(Map<String,Object> params){
		String result="";
		
		String consulta = cabDiligenciaDAO.obtenerTipoDiligencia(params);
		
		result = consulta!=null?consulta:result;
		
		return result;
	}
	/**FIN P46**/
  /*RIN13FSW-INICIO*/
public void setMovEquipamientoDAO(MovEquipamientoDAO movEquipamientoDAO) {
	this.movEquipamientoDAO = movEquipamientoDAO;
}

	//ggranados 179
 	public ObjectResponseUtil grabarRevisionReconocimientoFisicioOficio(Map<String, Object> params) throws ServiceException {
 		ObjectResponseUtil resultado;
		DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
		
		//1. Registrar diligencia
		Map<String, Object> diligencia = new HashMap();
		diligencia.put("COD_TIPDILIGENCIA", ConstantesDataCatalogo.COD_DILIG_REV);
		diligencia.put("NUM_CORREDOC", SunatNumberUtils.toLong(params.get("num_corredoc")));
		diligencia.put("COD_MOTIVO", SunatStringUtils.toStringObj(params.get("COD_ESTREV")));
		diligencia.put("COD_FUNCIONARIO", SunatStringUtils.toStringObj(params.get("cod_funcionario")));
		diligencia.put("COD_CATALOGO", ConstantesTipoCatalogo.CATALOGO_ESTADOS_RECONOCIMIENTO_FISICO);
    	cabDiligenciaDAO.update(diligencia);
    	
    	//2. Registrar indicador de reconocimiento fisico oficio
    	DatoIndicadores indicador = new DatoIndicadores();
    	indicador.setNumeroCorrelativo(SunatNumberUtils.toLong(params.get("num_corredoc")));
    	indicador.setCodigoIndicador(ConstantesDataCatalogo.INDICADOR_RECONOCIMIENTO_FISICO_OFICIO);
    	indicador.setCodigoTipoRegistro(Constantes.COD_TIPOREGISTRO_TRANSMISION_ELECTRONICA);
    	indicador.setIndicadorActivo(Constantes.IND_ACTIVO);
    	//si no tiene indicador 28 registralo
    	if(indicadorDUADAO.existeIndicadorByParams(indicador).compareTo(Constantes.INT_CERO) == 0){
    		indicadorDUADAO.insert(indicador);
    	}
    	
    	//3. Registrar comunicacion y su detalle
    	Integer numNota = comunicacionDAO.obtenerSiguienteCorrelativo();
    	Comunicacion comunicacion = new Comunicacion(true);
    	comunicacion.setNumCorreDoc(SunatNumberUtils.toLong(params.get("num_corredoc")));
    	comunicacion.setCodigoNota(Constantes.COD_COMUNICACION_EXTERNA);
    	comunicacion.setIndDetDescNotificacion(Constantes.COD_TIENE_DETALLE_COMUNICACION);
    	comunicacion.setCodMotNoti(SunatStringUtils.toStringObj(params.get("COD_ESTREV")));
    	comunicacion.setNumeroNota(SunatNumberUtils.toLong(numNota));
    	comunicacion.getDiligencia().setNumeroCorrelativo(SunatNumberUtils.toLong(params.get("num_corredoc")));
    	comunicacion.getDiligencia().setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
    	comunicacion.setCodTiDiligencia(ConstantesDataCatalogo.COD_DILIG_REV);
    	comunicacionDAO.insertSelective(comunicacion);
    	
    	ReconocimientoFisicoOficio recFisicoOficio = (ReconocimientoFisicoOficio) params.get("recFisicoOficio");
    	recFisicoOficio.setIndRecFisicoOficio(true);
    	recFisicoOficio.setFecRegis(new Date());
    	DetalleComunicacion detalleComunicacion = new DetalleComunicacion();
    	detalleComunicacion.setNumNota(SunatNumberUtils.toLong(numNota));
    	/**Inicio cambios por P24 M_SNADE283-597**/
    	Map<String, Object> paramDetalle = new HashMap<String, Object>();
    	paramDetalle.put("num_nota", SunatNumberUtils.toLong(numNota));//para no impactar grabarComunicacionCompleta
    	detalleComunicacion.setCodUsuRegistro(SunatStringUtils.toStringObj(params.get("cod_funcionario")));
    	detalleComunicacion.setCodUsuModificacion(SunatStringUtils.toStringObj(params.get("cod_funcionario")));
    	/**Fin cambios por P24 M_SNADE283-597**/
    	detalleComunicacion.setNumDetaDescripcion(detalleComunicacionDAO.obtenerSiguienteCorrelativo(paramDetalle));//ajuste M_SNADE283-597
    	detalleComunicacion.setDesDetalle(SojoUtil.toJson(recFisicoOficio));
    	detalleComunicacionDAO.insertSelective(detalleComunicacion);
    	
    	//4. Registrar avisos a los interesados
    	//aviso a agencia
    	MensajeAviso avisoAgenConsig = new MensajeAviso();
    	avisoAgenConsig.addUsuario(SunatStringUtils.toStringObj(params.get("NUM_DOCIDENT_PDE")));
    	avisoAgenConsig.setCodServicio(Constantes.COD_PL_NOTI_REC_FISICO_OFICIO);
    	avisoAgenConsig.setFechaEmision(new FechaBean());
    	avisoAgenConsig.setFechaVigencia(new FechaBean("31/12/9999"));
    	avisoAgenConsig.setDesAsunto("Notificaci&oacute;n para reconocimiento f&iacute;sico de oficio DAM: " +
    			SunatStringUtils.toStringObj(params.get("ANN_PRESEN")) + "-" +
    			SunatStringUtils.toStringObj(params.get("COD_ADUANA")) + "-" +
    			SunatStringUtils.toStringObj(params.get("COD_REGIMEN")) + "-" +
    			SunatStringUtils.toStringObj(params.get("NUM_DECLARACION")));
    	avisoAgenConsig.setTipoUsuarioAviso(MensajeAviso.TipoUsuarioAviso.CONTRIBUYENTE);
    	avisoAgenConsig.setTipoAviso(MensajeAviso.TipoAviso.NOTIFICACION);
    	avisoAgenConsig.addDatoPersonalizado("cod_aduana", SunatStringUtils.toStringObj(params.get("COD_ADUANA")));
    	avisoAgenConsig.addDatoPersonalizado("ann_presen", SunatStringUtils.toStringObj(params.get("ANN_PRESEN")));
    	avisoAgenConsig.addDatoPersonalizado("cod_regimen", SunatStringUtils.toStringObj(params.get("COD_REGIMEN")));
    	avisoAgenConsig.addDatoPersonalizado("num_declaracion", SunatStringUtils.toStringObj(params.get("NUM_DECLARACION")));
    	avisoAgenConsig.addDatoPersonalizado("fecha_emision", SunatDateUtils.getFormatDate(SunatDateUtils.getCurrentDate(), "dd/MM/yyyy"));
    	avisoAgenConsig.addDatoPersonalizado("lugarRecFisicoOficio", SunatStringUtils.toStringObj(params.get("COD_LOCALANEXO_DESC")) + ", "+ 
    	SunatStringUtils.convertirCaracteresEspecialesAHtml(SunatStringUtils.toStringObj(recFisicoOficio.getReferenciaRecFisicoOficio())));
    	avisoAgenConsig.addDatoPersonalizado("nombreRazonSocial", SunatStringUtils.toStringObj(params.get("NOM_RAZONSOCIAL_PDE")));
    	avisoAgenConsig.addDatoPersonalizado("fechaRecFisicoOficio", SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(recFisicoOficio.getFechaRecFisicoOficio()), "dd/MM/yyyy"));
    	avisoAgenConsig.addDatoPersonalizado("horaRecFisicoOficio", SunatStringUtils.substring(recFisicoOficio.getHoraRecFisicoOficio(), 1, 6));
    	avisoAgenConsig.addDatoPersonalizado("des_descripcion", SunatStringUtils.convertirCaracteresEspecialesAHtml(recFisicoOficio.getDescripcionRecFisicioOficio().replaceAll("(\\r|\\n)", "")));
    	notificarReconocimientoFisicoOficio(avisoAgenConsig);
    	
    	//aviso a importador
    	if(recFisicoOficio.getRaEnvioConsig().equals(Constantes.SI)){
    		avisoAgenConsig.borrarTodosUsuarios();
    		avisoAgenConsig.addUsuario(SunatStringUtils.toStringObj(params.get("NUM_DOCIDENT_PIM")));
    		avisoAgenConsig.addDatoPersonalizado("nombreRazonSocial", SunatStringUtils.toStringObj(params.get("NOM_RAZONSOCIAL_PIM")));
    		notificarReconocimientoFisicoOficio(avisoAgenConsig);
    	}
    	
    	//aviso a deposito temporal
    	MensajeAviso avisoDeposito = new MensajeAviso();
    	avisoDeposito.addUsuario(SunatStringUtils.toStringObj(params.get("NUM_DOCIDENT_PDF")));
    	avisoDeposito.setCodServicio(Constantes.COD_PL_NOTI_MOV_REC_FISICO_OFICIO);
    	avisoDeposito.setFechaEmision(new FechaBean());
    	avisoDeposito.setFechaVigencia(new FechaBean("31/12/9999"));
    	avisoDeposito.setDesAsunto("Movilizaci&oacute;n de mercanc&iacute;a para rec. f&iacute;sico de oficio DAM: " +
    			SunatStringUtils.toStringObj(params.get("ANN_PRESEN")) + "-" +
    			SunatStringUtils.toStringObj(params.get("COD_ADUANA")) + "-" +
    			SunatStringUtils.toStringObj(params.get("COD_REGIMEN")) + "-" +
    			SunatStringUtils.toStringObj(params.get("NUM_DECLARACION")));
    	avisoDeposito.setTipoUsuarioAviso(MensajeAviso.TipoUsuarioAviso.CONTRIBUYENTE);
    	avisoDeposito.setTipoAviso(MensajeAviso.TipoAviso.NOTIFICACION);
    	avisoDeposito.addDatoPersonalizado("cod_aduana", SunatStringUtils.toStringObj(params.get("COD_ADUANA")));
    	avisoDeposito.addDatoPersonalizado("ann_presen", SunatStringUtils.toStringObj(params.get("ANN_PRESEN")));
    	avisoDeposito.addDatoPersonalizado("cod_regimen", SunatStringUtils.toStringObj(params.get("COD_REGIMEN")));
    	avisoDeposito.addDatoPersonalizado("num_declaracion", SunatStringUtils.toStringObj(params.get("NUM_DECLARACION")));
    	avisoDeposito.addDatoPersonalizado("fecha_emision", SunatDateUtils.getFormatDate(SunatDateUtils.getCurrentDate(), "dd/MM/yyyy"));
    	avisoDeposito.addDatoPersonalizado("lugarRecFisicoOficio", SunatStringUtils.toStringObj(params.get("COD_LOCALANEXO_DESC")) + ", "+ 
    	SunatStringUtils.convertirCaracteresEspecialesAHtml(SunatStringUtils.toStringObj(recFisicoOficio.getReferenciaRecFisicoOficio())));
    	avisoDeposito.addDatoPersonalizado("nombreRazonSocial", SunatStringUtils.toStringObj(params.get("NUM_DOCIDENT_PDF_DESC")));
    	avisoDeposito.addDatoPersonalizado("fechaRecFisicoOficio", SunatDateUtils.getFormatDate(SunatDateUtils.getDateFromUnknownFormat(recFisicoOficio.getFechaRecFisicoOficio()), "dd/MM/yyyy"));
    	avisoDeposito.addDatoPersonalizado("horaRecFisicoOficio", SunatStringUtils.substring(recFisicoOficio.getHoraRecFisicoOficio(), 1, 6));
    	notificarReconocimientoFisicoOficio(avisoDeposito);

    	//si la fecha de reconocimiento fisico es mayor a la fecha actual
    	if(SunatDateUtils.esFecha1MayorQueFecha2(recFisicoOficio.getFechaRecFisicoOficioAsDate(), SunatDateUtils.getCurrentDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
    		//Cambia el estado de la declaracian a recepcionada
    		DUA dua = new DUA();
    		dua.setCodEstdua(Constantes.ESTADO_DECLARACION_RECEPCIONADO);
    		dua.setNumcorredoc(SunatNumberUtils.toLong(params.get("num_corredoc")));
    		this.declaracionService.actualizarDUAByPrimaryKey(dua);
    		
    		//Retira la Declaraci�n de la bandeja de pendientes del funcionario
    		Map<String, Object> paramsAsignacion = new HashMap<String, Object>();
    		paramsAsignacion.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_ELIMINADO_POR_REASIGNACION);
    		paramsAsignacion.put("num_corredoc",SunatNumberUtils.toLong(params.get("num_corredoc")));
    		paramsAsignacion.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
    		paramsAsignacion.put("fec_termrev", "fec_termrev");
    		paramsAsignacion.put("cod_funcionario", SunatStringUtils.toStringObj(params.get("cod_funcionario")).trim());
    		this.asignacionService.actualizarEstadoRevision(paramsAsignacion);
    		
    		//registrar DAM en anfora
    		params.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_RECEPCIONADO);
    		//hosoriov 179
    		params.put("COD_MOTIVOREVISION", SunatStringUtils.toStringObj(params.get("COD_ESTREV")));
    		registroAnforaDiligeciaReconocimientoFisico04_05(params);
    	}
    	
    	return new ObjectResponseUtil();
  	}
 	
 	//ggranados 179
 	public void notificarReconocimientoFisicoOficio(MensajeAviso aviso){ 		
 		PublicacionAvisoService avisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
 		avisoService.insert(
 				aviso.getCodServicio(), 
 				new StringBuffer(aviso.getMensajeAsJsonString()), 
 				aviso.getTipoAviso().getValue(),
                aviso.getFechaEmision().getTimestamp(), 
                aviso.getFechaVigencia().getTimestamp());
 	}
 	
 	//ggranados rollback regu
 	public void setOrquestadorDiligenciaService(OrquestadorDiligenciaService orquestadorDiligenciaService) {
 		this.orquestadorDiligenciaService = orquestadorDiligenciaService;
    }


/* PAS20145E220000399 INICIO GGRANADOS NO SE USA*/
//public void setMovimientoDeEquipamiento(
//		MovimientoDeEquipamiento movimientoDeEquipamiento) {
//	this.movimientoDeEquipamiento = movimientoDeEquipamiento;
//}

//public void setManifiesto(Manifiesto manifiesto) {
//	this.manifiesto = manifiesto;
//}

//public void setEquipamiento(Equipamiento equipamiento) {
//	this.equipamiento = equipamiento;
//}
/* PAS20145E220000399 FIN GGRANADOS */
  /*RIN13FSW-FIN*/

private void actualizaDocumentosRelacionados(Map<String,Object> declaracion, Map<String,Object> declaracionAnt, String tipDilig){
	Long numeroCorrelativo = Utilidades.toLong(declaracion.get("NUM_CORREDOC")); 
	Comparador comp = new Comparador();
	List<Map<String, Object>> lstDetAutorizacionActual = (List) declaracion.get("lstDetAutorizacion");
    List<Map<String, Object>> lstDetAutorizacion = (List) declaracionAnt.get("lstDetAutorizacion");
    List<Map<String, Object>> lstDocAutAsociadoActual = (List) declaracion.get("lstDocAutAsociado");
    List<Map<String, Object>> lstDocAutAsociado = (List) declaracionAnt.get("lstDocAutAsociado");
    List<Map<String, Object>> lstCabCertiOrigenActual = (List) declaracion.get("lstCabCertiOrigen");
    List<Map<String, Object>> lstCabCertiOrigen = (List) declaracionAnt.get("lstCabCertiOrigen");
    // actualizacion de documentos asociados a la serie

    // Debe existir un registro para actualizar o algun nuevo
    //Inicio RIN 14
    Map<String,Object> fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");
    fbKeys.put("COD_TIPOPER", "");
    fbKeys.put("NUM_SECDOC", "");
    List<Map<String, Object>> lstDiferDocAut = comp.comparaList(lstDocAutAsociado, lstDocAutAsociadoActual, fbKeys);
    //Fin RIN 14
    if (!CollectionUtils.isEmpty(lstDiferDocAut))
    {
      // Documentos asociados
      Map<String, Object> mapKeyAsoc = new HashMap<String, Object>();
      Map<String, Object> mapDifAsoc = new HashMap<String, Object>();
      for (Map<String, Object> mapAsoc : lstDocAutAsociadoActual)
      {
        Map<String, Object> mapAsocAntes = new HashMap<String, Object>();

        mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
        mapKeyAsoc.put("NUM_SECDOC", mapAsoc.get("NUM_SECDOC"));
        mapKeyAsoc.put("COD_TIPOPER", mapAsoc.get("COD_TIPOPER"));

        mapAsocAntes = Utilidades.obtenerElemento(lstDocAutAsociado, mapKeyAsoc);
        if (CollectionUtils.isEmpty(mapAsocAntes))
        {
          if ("0".equals(mapAsoc.get("IND_DEL").toString()))
          {
            docAutAsociadoDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAsoc));
            this.registrarRectiOficio(
                                      mapAsoc,
                                      tipDilig,
                                      //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                      numeroCorrelativo, 
                                      Constantes.COD_TABLA_DOCAUT_ASOCIADO);
            //Inicio RIN 14
            mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
          		  ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, Constants.IND_REGISTRO_NUEVO);
            //Fin RIN 14
          }
        }
        else
        {
          // ya existe en documentos asociados
          mapDifAsoc = comp.comparaMap(mapAsocAntes, mapAsoc, false, false, mapKeyAsoc);
          if (Comparador.esDataCambiada(mapDifAsoc))
          {
            //Inicio RIN 14
            if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                  
          	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
          	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
          	    Constants.IND_REGISTRO_ANULADO);

            }	
            //Fin RIN 14
            docAutAsociadoDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
            this.registrarRectiOficio(
                                      mapAsoc,
                                      tipDilig,
                                      //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                      numeroCorrelativo, 
                                      Constantes.COD_TABLA_DOCAUT_ASOCIADO);
            //Inicio RIN 14
            if (!Constants.INDICADOR_ELIMINADO.equals(mapAsoc.get("IND_DEL").toString())){       
                
          	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
          	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc, 
          	    Constants.IND_REGISTRO_NUEVO);

            } else {

          	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
          	    ConstantesDataCatalogo.TABLA_DOCASOCIADO, mapKeyAsoc, mapAsoc,  
          	      Constants.IND_REGISTRO_ANULADO);

            }
			  //Fin RIN 14
          }
        }
        mapDifAsoc.clear();
        mapKeyAsoc.clear();
      }

      // Certificados
      if (!CollectionUtils.isEmpty(lstCabCertiOrigenActual))
      {
        for (Map<String, Object> mapCerti : lstCabCertiOrigenActual)
        {
          Map<String, Object> mapCertiAntes = new HashMap<String, Object>();

          mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
          mapKeyAsoc.put("NUM_SECDOC", mapCerti.get("NUM_SECDOC"));
          mapKeyAsoc.put("COD_TIPOPER", mapCerti.get("COD_TIPOPER"));

          mapCertiAntes = Utilidades.obtenerElemento(lstCabCertiOrigen, mapKeyAsoc);
          if (CollectionUtils.isEmpty(mapCertiAntes))
          {
            if ("0".equals(mapCerti.get("IND_DEL").toString()))
            {
              cabCertiOrigenDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapCerti));
              this.registrarRectiOficio(
                                        mapCerti,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo, 
                                        Constantes.COD_TABLA_CAB_CERTIORIGEN);
            }
          }
          else
          {
            // ya existe en documentos asociados
            mapDifAsoc = comp.comparaMap(mapCertiAntes, mapCerti, false, false, mapKeyAsoc);
            if (Comparador.esDataCambiada(mapDifAsoc))
            {
              cabCertiOrigenDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
              this.registrarRectiOficio(
                                        mapCerti,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo,
                                        Constantes.COD_TABLA_CAB_CERTIORIGEN);
            }
          }
          mapDifAsoc.clear();
          mapKeyAsoc.clear();
        }
      }
      // Autorizantes
      //Inicio RIN 14
      fbKeys = new HashMap();
      fbKeys.put("NUM_CORREDOC", "");
      fbKeys.put("COD_TIPOPER", "");
      fbKeys.put("NUM_SECDOC", "");
      fbKeys.put("NUM_SECSERIE", "");
      List<Map<String, Object>> lstDiferDetAut = comp.comparaList(lstDetAutorizacion, lstDetAutorizacionActual, fbKeys);
      //Fin RIN 14
      if (!CollectionUtils.isEmpty(lstDiferDetAut))
      {
        for (Map<String, Object> mapAut : lstDetAutorizacionActual)
        {
          Map<String, Object> mapAutAntes = new HashMap<String, Object>();

          mapKeyAsoc.put("NUM_CORREDOC", numeroCorrelativo); //declaracion.get("NUM_CORREDOC"));
          mapKeyAsoc.put("NUM_SECDOC", mapAut.get("NUM_SECDOC"));
          mapKeyAsoc.put("COD_TIPOPER", mapAut.get("COD_TIPOPER"));
          mapKeyAsoc.put("NUM_SECSERIE", mapAut.get("NUM_SECSERIE"));

          mapAutAntes = Utilidades.obtenerElemento(lstDetAutorizacion, mapKeyAsoc);
          if (CollectionUtils.isEmpty(mapAutAntes))
          {
            if ("0".equals(mapAut.get("IND_DEL").toString()))
            {
              detAutorizacionDAO.insertSelective(Utilidades.transformFieldsToRealFormat(mapAut));
              this.registrarRectiOficio(
                                        mapAut,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo, 
                                        Constantes.COD_TABLA_DET_AUTORIZACION);
              //Inicio RIN 14
              mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
              		  ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
              		   Constants.IND_REGISTRO_NUEVO);
				//Fin RIN 14
            }
          }
          else
          {
            // ya existe en documentos asociados
            mapDifAsoc = comp.comparaMap(mapAutAntes, mapAut, false, false, mapKeyAsoc);
            if (Comparador.esDataCambiada(mapDifAsoc))
            {
          	//Inicio RIN 14  
          	if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){       
                    
            	    mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
            	    ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
            	    Constants.IND_REGISTRO_ANULADO);

              }
          	//Fin RIN 14  
              detAutorizacionDAO.update(Utilidades.transformFieldsToRealFormat(mapDifAsoc));
              this.registrarRectiOficio(
                                        mapAut,
                                        tipDilig,
                                        //new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                        numeroCorrelativo,
                                        Constantes.COD_TABLA_DET_AUTORIZACION);
              //Inicio RIN 14
              if (!Constants.INDICADOR_ELIMINADO.equals(mapAut.get("IND_DEL").toString())){
                  
                  mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                  ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut, 
                  Constants.IND_REGISTRO_NUEVO);

                } else {

                  mercanciaRestringidaEntidadService.actualizarDocAutRectificacion(
                  ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, mapKeyAsoc, mapAut,  
                    Constants.IND_REGISTRO_ANULADO);

                }
				//Fin RIN 14
            }
          }
          mapDifAsoc.clear();
          mapKeyAsoc.clear();
        }
      }
    }
}


//Inicio P21-P22
/**
 * NSIGAD permite la modificaci�n del �texto� de la diligencia de
 * conclusi�n de despacho, siempre que: Se realice por un m�ximo de tres veces;
 */
public Map<String,Object> validarActualizacionConclusion(Map params) throws ServiceException{

	Map<String,Object> result = new HashMap<String,Object>();
	String mensaje = new String();
	String numCorredoc =  params.get("NUM_CORREDOC").toString();
	Boolean regOK = false;

	Map<String, Object> mapBusq = new HashMap<String, Object>();
	mapBusq.put("NUM_CORREDOC",numCorredoc);
	mapBusq.put("COD_TIPDILIGENCIA", new String[]{params.get("COD_TIPDILIGENCIA").toString()});
	/**Inicio de cambios por PAS20165E220200032***/
	Date fechadeclaracion = params.get("FEC_DECLARACION")!=null && params.get("FEC_DECLARACION").toString()!=" "?
			SunatDateUtils.getDateFromUnknownFormat(params.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
	Boolean tieneGarantia160 = (params.get("NUM_CTACTE")!=null && params.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				
	Boolean ingresoPorPostLevante = params.get("esPostLevante")!=null && "1".equals(params.get("esPostLevante").toString())?true:false;
	String codiregimen = params.get("COD_REGIMEN")!=null? params.get("COD_REGIMEN").toString():" ";
	String nombreDiligencia="Conclusi�n de Despacho";
	if(ingresoPorPostLevante){
		nombreDiligencia="Post Levante";
	}
	/**Fin de cambios por PAS20165E220200032***/
	
	try{		   
		
		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		 //RF01 - Bloqueo para diligencia de Conclusion - Modificacion
		if(!ingresoPorPostLevante && getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
			mensaje = "No corresponde Diligencia de Conclusi�n para la Declaraci�n numerada posterior a la vigencia del DL 1235"; 
		}
		
		if(ingresoPorPostLevante){
			if(!getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
				mensaje = "No corresponde el registro de Diligencia de Post Levante, Declaraci�n numerada previo a la vigencia del DL 1235";  
			}else{
				if(!codiregimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)|| !tieneGarantia160){
					mensaje = "Declaraci�n no presenta condiciones para acceder a Post Levante";  
				}
			}				
		}
		
		if(mensaje.isEmpty()){//adicionado para PAS20165E220200032
		Map<String,Object> ultimaActualizacion =  cabDiligenciaDAO.findUltimaDiligencia(mapBusq);
		if(ultimaActualizacion!=null){
			// Que el actor sea el mismo funcionario aduanero que registr� la diligencia de la DUA
			Map<String, Object> mapParamsAsig = new HashMap<String, Object>();
			mapParamsAsig.put("NUM_CORREDOC", numCorredoc);
			mapParamsAsig.put("COD_ESTREV", "01"); 
			mapParamsAsig.put("COD_GRUPO", Constantes.GRUPO_CONCLUCION_DESPACHO); 
			Map<String, Object> mapEspeDespachoAsig = espeDocuDAO.findbyDocEstRev(mapParamsAsig);

			if (mapEspeDespachoAsig == null || (mapEspeDespachoAsig != null && !CollectionUtils.isEmpty(mapEspeDespachoAsig) && !mapEspeDespachoAsig.get("cod_funcionario").equals(
					params.get("COD_FUNCIONARIO")))){//se adiciona por error empty PAS20165E220200032 

				mensaje= "Diligencia de "+nombreDiligencia+" no fue registrada por usted.";//modificado por PAS20165E220200032
			}else{		    	
				Boolean seGrabaDiligencia = false;
				Integer numCorredocSol = Integer.parseInt(ultimaActualizacion.get("NUM_CORREDOC_SOL").toString());

				if(numCorredocSol<4){		 
					mapBusq.clear();
					mapBusq.put("NUM_CORREDOC",numCorredoc);
					mapBusq.put("COD_TIPDILIGENCIA_IN", new String[]{"06","10"}); //Rectificacion electronica o rectificacion de oficio
					List<Map<String,Object>> rectificacionesMap = cabDiligenciaDAO.select(mapBusq); 
					seGrabaDiligencia = true;
					if(!rectificacionesMap.isEmpty()){						 
						//seGrabaDiligencia = true;
					//}else{				 
						for(Map<String,Object> rectificacion:rectificacionesMap){	
							Date fechaDiligencia = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(rectificacion.get("FEC_DILIGENCIA").toString());
							Date fechaConclusion =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(params.get("FEC_CONCLUSION").toString());

							if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaDiligencia, fechaConclusion, "COMPARA_TODO")){
								seGrabaDiligencia = false;
								mensaje = "No puede modificar la diligencia de "+nombreDiligencia+" por existir una rectificacion";	//modificado por PAS20165E220200032
								break;
							}
						}						 						 					
					}
					if(seGrabaDiligencia){					  
						ultimaActualizacion.put("FEC_DILIGENCIA", new FechaBean().getTimestamp());
						ultimaActualizacion.put("FEC_MODIFICACION", new FechaBean().getTimestamp());
						ultimaActualizacion.put("NUM_CORREDOC_SOL", numCorredocSol+1);
						regOK=true;					  
						result.put("CAB_DILIGENCIA", ultimaActualizacion);
					}

				}else{	
					mensaje = "Diligencia de "+nombreDiligencia+" fue modificada anteriormente, s�lo puede modificarse un maximo de 3 veces.";//modificado por PAS20165E220200032
				}
			}
		} 
		}
		result.put("MENSAJE",mensaje);
		result.put("regOK",regOK);
		return result;
	}catch(Exception e){
		log.error("*** ERROR ***", e);
		throw new ServiceException(e, e.getMessage());
	}
}

public void grabarConclusionDespacho(Map params) throws ServiceException{
  Map declaracion = (HashMap) params.get("mapCabDeclaraActual");
  Map declaracionAnt = (HashMap) params.get("mapCabDeclara");
  Map mapDilig = (HashMap) params.get("mapCabDiligenciaActual");

    //AMANCILLA

//    Date fechaActual = new FechaBean().getTimestamp();
  String tipDilig = mapDilig.get("COD_TIPDILIGENCIA").toString().trim();
  Long numeroCorrelativo = Utilidades.toLong(declaracion.get("NUM_CORREDOC")); 
  Long numCorreDocSol = 0L; 
  
  if(declaracion.get("COD_LUGARRECEP") != null){
  	declaracion.put("COD_LUGARRECEP", declaracion.get("COD_LUGARRECEP").toString().substring(0, 1));
  }

  declaracion.put("FEC_MODIF", new FechaBean().getTimestamp());
  declaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO);
  declaracion.put("FEC_CONCLUSION", new FechaBean().getTimestamp());
  
  
  Map<String, Object> mapaPK = new HashMap<String, Object>();
  
  mapaPK.put("NUM_CORREDOC", "NUM_CORREDOC");

  swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
                                                       + params.get("caduana").toString().trim()));
  
  //Consultar para la conclusion se deberia procesar los contingentes?
  try
  {    
	  mapDilig.put("NUM_CORREDOC", numeroCorrelativo);
      mapDilig.put("FEC_DILIGENCIA", new FechaBean().getTimestamp());
      mapDilig.put("FEC_CONCLUSION", new FechaBean().getTimestamp());
    try{
         this.cabDiligenciaDAO.insert(mapDilig);
    }catch (Exception e){      
         throw new DiligenciaException();
    }

	//PAS20165E220200076 RSERRANO CONTINGENTE SE MODIFICA PARA CONCLUSION DE DESPACHO
		  List<Map<String, String>> ListaValida = this.procesarGrabaContingente(params,  Constants.COD_TRANSAC_DILIGENCIACONCLUSION);
    
    /**Inicio de cambios PAS20165E220200032**/
    if(params.containsKey("ingresoPostLevante")){
    	GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
				SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
   	 if(params.get("ingresoPostLevante").equals("1") &&  getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
   		 declaracionService.insertarIndicadorDua(declaracion.get("NUM_CORREDOC").toString(), Constantes.IND_DUA_POST_LEVANTE, Constantes.IND_DUA_P_ESP);
   	 } 
     }
    /**Fin de cambios PAS20165E220200032**/

   
    //RIN-13 Actualizaci�n de participantes - 31 Deposito VErificar si es suficiente para mapear 
    this.actualizarParticipanteDeposito(declaracion, declaracionAnt, numeroCorrelativo, numCorreDocSol.intValue(), tipDilig);

    // Obtenemos los registros que relacionan las series con los items
    Map fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", numeroCorrelativo);
    List lstSeriesItem = this.seriesItemDAO.select(fbKeys);
    params.put("lstSeriesItem", lstSeriesItem);

    // Actualizamos el Boletin Quimico
    if (declaracion.get("lstTabBolQuim") != null)
    {
      Map mapBolQuim = new HashMap();
      mapBolQuim.put("lstTabBolQuim", declaracion.get("lstTabBolQuim"));
      mapBolQuim.put("lstTabBolQuimAnt", declaracionAnt.get("lstTabBolQuim"));
      // Parametros para actualizar la partida en las series del formato B
      mapBolQuim.put("lstSeriesItem", lstSeriesItem);
      mapBolQuim.put("mapCabDeclaraActual", declaracion);
      this.actualizarBolQuimicos(mapBolQuim);
    }

    if (declaracion.get("FEC_VENREGIMEN").getClass().getName().equals( new FechaBean().getClass().getName()))
    {
      declaracion.put("FEC_VENREGIMEN", ((FechaBean) declaracion.get("FEC_VENREGIMEN")).getTimestamp());
    }
    

    fbKeys = new HashMap();
    fbKeys.put("NUM_CORREDOC", "");

    Comparador comp = new Comparador();
    /* Retirar campos que no son modificables */
    if (declaracion.containsKey("FEC_DECLARACION"))
      declaracionAnt.put("FEC_DECLARACION", declaracion.get("FEC_DECLARACION"));
    if (declaracion.containsKey("FEC_REGIS"))
      declaracion.remove("FEC_REGIS");
    if (declaracionAnt.containsKey("FEC_REGIS"))
      declaracionAnt.remove("FEC_REGIS");
    if (declaracion.containsKey("FEC_MODIF"))
      declaracion.remove("FEC_MODIF");
    if (declaracionAnt.containsKey("FEC_MODIF"))
      declaracionAnt.remove("FEC_MODIF");
    

    //Map<String, Object> mapDiferencias = comp.comparaMapEstricto(declaracionAnt, declaracion, false, false, fbKeys);
    Map<String, Object> mapDiferencias = soporteComparadorService.comparaMap(declaracion, declaracionAnt, EnumTablaModel.CAB_DECLARA);

    if (mapDiferencias != null && mapDiferencias.size() > 0)
    {
      if (Comparador.esDataCambiada(mapDiferencias))
      {
        this.cabDeclaraDAO.update(Utilidades.transformFieldsToRealFormat(mapDiferencias));
        this.registrarRectiOficio(mapDiferencias, tipDilig, new Long(mapDiferencias
                                                                                   .get("NUM_CORREDOC")
                                                                                   .toString()
                                                                                   .trim()), "T0051");
      }
    }

    if (!MapUtils.esValorMapaNuloOVacio(declaracion, "COD_FERIA"))
    {
      if ((declaracionAnt.get("COD_FERIA") == null)
          || (declaracionAnt.get("COD_FERIA") != null && !declaracionAnt.get("COD_FERIA")
                                                                        .toString()
                                                                        .trim()
                                                                        .equals(declaracion.get("COD_FERIA")
                                                                                           .toString().trim())))
      {

        Map keyAdmTemp = new HashMap();
        keyAdmTemp.put("NUM_CORREDOC", numeroCorrelativo); 

        Map mapAdmTempDO = new HashMap();
        mapAdmTempDO.put("COD_FERIA", declaracionAnt.get("COD_FERIA"));

        Map mapAdmTempDif = new HashMap();
        mapAdmTempDif.put("NUM_CORREDOC", numeroCorrelativo); 
        mapAdmTempDif.put("COD_FERIA", declaracion.get("COD_FERIA"));

        mapAdmTempDif.put("dataOriginal", mapAdmTempDO);
        mapAdmTempDif.put("clave", keyAdmTemp);

        if (declaracionAnt.get("COD_FERIA") == null)
        {

          this.cabAdiAdmTemDAO.insert(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
        }
        else
        {

          this.cabAdiAdmTemDAO.update(Utilidades.transformFieldsToRealFormat(mapAdmTempDif));
        }

        this.registrarRectiOficio(
                                  mapAdmTempDif,
                                  tipDilig,
                                  numeroCorrelativo,
                                  Constantes.COD_TABLA_CAB_ADI_ADM_TEM);
      }
    }

    // Actualizamos el estado de la asignacion
    
    Map prmtBusq = new HashMap();
    prmtBusq.put("NUM_CORREDOC", numeroCorrelativo);
    prmtBusq.put("COD_ESTREV", "10"); //10: Asignado a Conclusion

    Map mapEspeDocuAnt = this.espeDocuDAO.findbyDocEstRev(prmtBusq);
    if (mapEspeDocuAnt != null && mapEspeDocuAnt.size() > 0){
      Map mapEspeDocu = new HashMap();
      mapEspeDocu.putAll(mapEspeDocuAnt);      
      mapEspeDocu.put("fec_termrev", new Date());
      mapEspeDocu.put("cod_estrev",  "01"); //Diligencia Concluida
      mapEspeDocu.put("cod_funcionario", params.get("cod_funcionario").toString());
      this.espeDocuDAO.updateEstadoRevision(mapEspeDocu);
    }
    
    //inicio CU 14.21
    if(declaracion.get("IND_FORMBPROVEEDOR").toString().equals("0")){
  	  this.insertarItemFacturaDeclaracion(params, tipDilig);
    }
    //fin CU 14.21
    
    this.actualizarSeries(params);
    this.actualizaDocumentosRelacionados(declaracion, declaracionAnt,tipDilig);
    

    List lstDetDeclara = (ArrayList) params.get("lstDetDeclaraActual");
    params.put("tipDilig", tipDilig);
    


   List<Incidencia> lstIncidencias2 = (ArrayList<Incidencia>) params.get("lstIncidencias");
   if(!CollectionUtils.isEmpty(lstIncidencias2)) {
      int numItm = 0;
     Map incidencia;
      for(Incidencia incidenciaBean:  lstIncidencias2) {
        numItm += 1;
       incidencia = new HashMap();
        incidencia.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
       incidencia.put("COD_TIPDILIGENCIA", tipDilig);

       incidencia.put("NUM_SECINCID", "" + numItm);
        incidencia.put("NUM_SERIE", incidenciaBean.getNumeroSerie());
        incidencia.put("COD_INCIDENCIA", incidenciaBean.getCodIncidencia());
      incidenciaService.insert(incidencia);
     }

    }
	  
    // Insertamos o actualizamos la OBSERVACION correspondiente
    Map mapObs = new HashMap();
    mapObs.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
    mapObs.put("NUM_SECOBS", declaracion.get("NUM_SECOBS") != null ? declaracion.get("NUM_SECOBS").toString().trim()
                                                                  : "1");// siguiente
    mapObs.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_DECLA);
    mapObs.put("OBS_OBS", declaracion.get("OBS_OBS"));

    Map keyObs = new HashMap();
    keyObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
    keyObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
    keyObs.put("COD_TIPOBS", mapObs.get("COD_TIPOBS"));

    Map mapObsDO = null;
    mapObs.put("dataOriginal", mapObsDO);
    mapObs.put("clave", keyObs);

    if ((mapObs.get("OBS_OBS") == null || "".equals(mapObs.get("OBS_OBS").toString().trim())))
    {
      if (declaracionAnt.get("NUM_SECOBS") != null)
      {
        if (mapObs.get("OBS_OBS") == null)
        {
          mapObs.put("OBS_OBS", "");
        }
        this.observacionDAO.update(mapObs);

        this.registrarRectiOficio(mapObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                  Constantes.COD_TABLA_OBSERVACION);
      }
    }
    else
    {
      if (declaracionAnt.get("NUM_SECOBS") == null)
      {
        this.observacionDAO.insert(mapObs);

        mapObs.put("dataOriginal", mapObsDO);

        this.registrarRectiOficio(mapObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                  Constantes.COD_TABLA_OBSERVACION);
      }
      else
      {
        if (!mapObs.get("OBS_OBS").toString().trim().equals(declaracionAnt.get("OBS_OBS").toString().trim()))
        {// VERITIFCAMOS SI HAY CAMBIOS EN LAS OBSERVACIONES
          this.observacionDAO.update(mapObs);
          this.registrarRectiOficio(mapObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()),
                                    Constantes.COD_TABLA_OBSERVACION);
        }
      }
    }

    // Actualizamos las tablas del Formato B
    Map paramsFB = new HashMap();
    paramsFB.put("lstSeriesItemActual", params.get("lstSeriesItemActual"));
    paramsFB.put("lstFormBProveedor", declaracion.get("lstFormBProveedor"));
    paramsFB.put("lstFormBProveedorAnt", declaracionAnt.get("lstFormBProveedor"));
    paramsFB.put("tipDilig", tipDilig);
    this.actualizarFormatoB(paramsFB);

      if (!CollectionUtils.isEmpty(lstDetDeclara)) {

          mapDilig.put("LIQSOL", params.get("cb_liqsol"));
          mapDilig.put("LIQDOL", params.get("cb_liqdol"));

          Map mapParamsDilig = new HashMap();
          mapParamsDilig.put("mapCabDeclaraActual", declaracion);
          mapParamsDilig.put("mapCabDiligenciaActual", mapDilig);
          if (params.get("lstMultaDua")!=null){
              mapParamsDilig.put("generacionLCMulta", params.get("generacionLCMulta"));
              mapParamsDilig.put("lstMultaDuaOkResolucion", params.get("lstMultaDuaOkResolucion"));
          }
          //PAS20155E220000166 - Inicio
          mapParamsDilig.put("generacionLCTributo", params.get("generacionLCTributo"));
          //PAS20155E220000166 - Fin
          if (!Constantes.REGIMEN_70_DEPOSITO.equals((String) declaracion.get("COD_REGIMEN"))) {
              this.liquidaDeclaracionService.grabaLiqDiligencia(mapParamsDilig);
          	params.put("mensaje", mapParamsDilig.get("mensaje"));
          }
      }
         // Grabamos las multas registradas
         List listaMultasSeleccionadas = (ArrayList) params.get("lstMultaDua");
         if (listaMultasSeleccionadas != null && listaMultasSeleccionadas.size() > 0)
         {
          String codDocumento = declaracion.get("NUM_CORREDOC").toString();
          String codTipoDiligencia = (String) mapDilig.get("COD_TIPDILIGENCIA");
          Date fechaDeclaracion = (Date) declaracion.get("FEC_DECLARACION");
          String tipoDocImp = (String) declaracion.get("COD_TIPDOC_PIM");
          String rucImp = (String) declaracion.get("NUM_DOCIDENT_PIM");
          String codFuncionario = (String) mapDilig.get("COD_FUNCIONARIO");

          Map paramMulta = new HashMap();
          paramMulta.put("COD_DOCUMENTO", codDocumento);
          paramMulta.put("NUM_CORREDOC", codDocumento);
          paramMulta.put("COD_TIPDILIGENCIA", codTipoDiligencia);
          paramMulta.put("FEC_DECLARACION", fechaDeclaracion);
          paramMulta.put("COD_TIPDOC_PIM", tipoDocImp);
          paramMulta.put("NUM_DOCIDENT_PIM", rucImp);
          paramMulta.put("COD_ANTADU", "41");  		
          paramMulta.put("NUM_REG_USUARIO", codFuncionario);
          paramMulta.put("generacionLCMulta", (Map<String, Object>) params.get("generacionLCMulta"));
          paramMulta.put("tipDilig", tipDilig);
          this.multaService.generarMulta(paramMulta, listaMultasSeleccionadas);
         }
         
        /**Inicio cambios por PAS20165E220200032***/

         String resultadoDias= (String) SunatDateUtils.getCurrentFormatDate("yyyyMMdd");
        		 
 		 Map<String, Object> mapParam = new HashMap<String, Object>();
         mapParam.put("cADUAFECTA", String.valueOf(declaracion.get("COD_ADUANA")));
         mapParam.put("cANNAFECTA", String.valueOf(declaracion.get("ANN_PRESEN")));
         mapParam.put("cNUMAFECTA", SunatStringUtils.lpad(String.valueOf(declaracion.get("NUM_DECLARACION")), 6, '0'));
         mapParam.put("cREGIAFECTA", String.valueOf(declaracion.get("COD_REGIMEN")));
         mapParam.put("cFECHAFECTA", Integer.valueOf(resultadoDias));
         mapParam.put("cTRANS", "2");
         log.debug("PARAM = " + mapParam);
         String resultado = this.pagarantiaDAO.registroFechaTermino(mapParam);
         log.debug("PAGARANTIA.FNFECHA resultado = " + resultado);

         /**Fin cambios por PAS20165E220200032***/  
 
  }
  catch (DataAccessException e)
  {
    log.error("*** ERROR ***", e);
    throw new ServiceException(this, "Ha ocurrido un error al inserta los datos");
  }
  catch (Throwable e)
  {
    log.error("DiligenciaServiceImpl : grabarDiligenciaConclusion - ERROR: ", e);
    throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo de grabado de la diligencia");
  }
}
//inicio - p14-diligencia de conclusion de despacho notificacion se muestra el detalle.
public String obtenerConsultaDetalleNotificacion(Comunicacion notificacion) throws ServiceException {
	
	StringBuilder HTMLDetalle = new StringBuilder();
	String detalleNotificacionConsolidado = "";
	//p24 PAS20165E220200099
	if(("1").equals(notificacion.getIndDetDescNotificacion())){				
		//Insercion de cabecera				
		if(notificacion.getDesNota() != null && !SunatStringUtils.isEmptyTrim(notificacion.getDesNota()) && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[0] != null && !notificacion.getDesNota().toString().trim().equals("") )
			HTMLDetalle.append(notificacion.getDesNota().toString().split("@_@")[0]);
		
		//Insercion de cuerpo					
			//if(notificacion.isIndInsercionAviso()==false)
				HTMLDetalle.append(obtenerDetalleNotificacionConsulta(notificacion));
		
		//Insercion de pie
		if(notificacion.getDesNota() != null && notificacion.getDesNota().toString().contains("@_@") == true && notificacion.getDesNota().toString().split("@_@")[1] != null && !notificacion.getDesNota().toString().trim().equals("") )
			HTMLDetalle.append(notificacion.getDesNota().toString().split("@_@")[1]);
	//p24 PAS20165E220200099			
	}else{
		if (notificacion.getDesNota() !=null && !SunatStringUtils.isEmptyTrim(notificacion.getDesNota())) HTMLDetalle.append(notificacion.getDesNota().replace("@_@", ""));//p24 espacios vacios
	}
	
	detalleNotificacionConsolidado = HTMLDetalle.toString();
	
	return detalleNotificacionConsolidado;
	
}

private String obtenerDetalleNotificacionConsulta(Comunicacion notificacion) {
	//p24 PAS20165E220200099
	StringBuilder filaHTML = new StringBuilder();
	filaHTML.append("<div align='justify'> <table border='0' cellpadding='0' cellspacing='0' class='form-table'>");
	DetalleComunicacionDAO detalleComunicacionDAO =  fabricaDeServicios.getService("diligencia.ingreso.detalleComunicacionDef");
	
	try{
		
		DetalleComunicacion dc = new DetalleComunicacion();
		dc.setNumNota(notificacion.getNumNota());
		
		List<DetalleComunicacion> lstDetalleNotificacion = detalleComunicacionDAO.findDetalleComunicacionNotificacion(dc);
		boolean indRenderCabecera = true;
		
		String cabeceraActual="";			
		String cuerpoActual="";
		
		for (DetalleComunicacion deNot : lstDetalleNotificacion) {
		
			HashMap<String, Object> detalleNotificacion = (HashMap<String, Object>) new JsonSerializer().deserialize(deNot.getDesDetalle(), HashMap.class);
			//p24 pase PAS20165E220200099
			if(indRenderCabecera == true){
				filaHTML.append("<tr>");
				for ( int numColumna=0; numColumna< detalleNotificacion.size(); numColumna++ ) {
					filaHTML.append("<th class = 'rowTitle'>");
					cabeceraActual = obtenerCabCuerpoDetalle(notificacion.getCodMotNoti(), numColumna);					
					if(cabeceraActual.equals("descripcionRecFisicioOficio")){
						filaHTML.append("Descripci&oacute;n Rec. F&iacute;sico Oficio");
					}else{
						filaHTML.append(cabeceraActual.toUpperCase().replace("_", " "));
					}
					filaHTML.append("</th>");
					if(cabeceraActual.equals("descripcionRecFisicioOficio")){
						break;
					}
				}
				filaHTML.append("<tr>");
				indRenderCabecera = false;
			}			
			filaHTML.append("<tr>");
			for ( int numColumna=0; numColumna< detalleNotificacion.size(); numColumna++ ) {
				filaHTML.append("<td  style='text-align: justify; text-justify: inter-word;'>");
				cabeceraActual = obtenerCabCuerpoDetalle(notificacion.getCodMotNoti(), numColumna);
				String cadena="";
				if(cabeceraActual.equals("subpartida_nacional")||cabeceraActual.equals("subpartida_nacional_declarada") || cabeceraActual.equals("subpartida_nacional_propuesta")){
					cadena=(detalleNotificacion.get(cabeceraActual)==null) ? "" : detalleNotificacion.get(cabeceraActual).toString();
					if(cadena.length()<11){
						String bloqueUno    = cadena.substring(0, 4);
						String bloqueDos    = cadena.substring(4, 6);
						String bloqueTres    = cadena.substring(6, 8);
						String bloqueCuatro    = cadena.substring(8, 10);
						cadena = bloqueUno.concat(".") + bloqueDos.concat(".") +bloqueTres.concat(".") + bloqueCuatro;
					}
					cuerpoActual   =  cadena;
					
				}else{
					cuerpoActual   =  (detalleNotificacion.get(cabeceraActual)==null) ? "" : detalleNotificacion.get(cabeceraActual).toString();
				}
				filaHTML.append(cuerpoActual);					
				filaHTML.append("</td>");
				if(cabeceraActual.equals("descripcionRecFisicioOficio")){
					break;
				}
			}
			filaHTML.append("<tr>");
		}
		
	} catch (DataAccessException e) {
		log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
				.concat(e.getMessage()));
		throw new ServiceException(e, e.getMessage());
	} catch (Exception e) {
		log.error(this.toString().concat(" obtenerNotificaciones- ERROR: ")
				.concat(e.getMessage()));
		throw new ServiceException(e, e.getMessage());
	}
		
	filaHTML.append("</table></div>");			
	return filaHTML.toString();
}
//fin - p14-diligencia de conclusion de despacho notificacion se muestra el detalle.
	/**PAS20155E220100038 inicio*/
	public void registrarDetRectiOficio(Map mapRectif, String tipDilig, Long numCorredoc, String codTabla){
		mapRectif.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
		mapRectif.put("tipoDiligencia", tipDilig);
		mapRectif.put("tabla", codTabla);
		mapRectif.put("NUM_CORREDOC", numCorredoc);
		if (mapRectif.get("dataOriginal") == null){
			mapRectif.put("dataOriginal", mapRectif.get("clave"));
		}		
		rectiOficioDAO.insertMapComparador(mapRectif);
	}
	/**PAS20155E220100038 fin*/


	//pase 427
	public void notificarObserMercaDispuesta(
	        String descripcion,
	        String codAduana,
	        String annPresen,
	        String codRegimen,
	        String numDeclaracion,
	        String tipoPDE_PIM,
	        String[] codUsuario,
	        Integer codPlantilla,
	        String codTipoAviso,
	        String tipoUsuario,
	        String tipo)
	{
		FechaBean fechaPublicacion = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		String mensajeRpta =" ";
		String fecDocDispo =" ";

		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<String, Object>();

		MercanciaDispuestaDAO mercanciaDispuestaDAO =  fabricaDeServicios.getService("mercanciaDispuestaDAO");

		//obtener el consignatario 
		mapMensaje.put("cod_usuario", codUsuario);
		mapMensaje.put("des_asunto", obtenerAsunto(codPlantilla)); 
		mapMensaje.put("tip_usuario", tipoUsuario);
		mapMensaje.put("des_intendencia", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));

		mapMensaje.put("cod_aduana", codAduana);
		mapMensaje.put("ann_presen", annPresen);
		mapMensaje.put("cod_regimen", codRegimen);
		mapMensaje.put("num_declaracion", numDeclaracion);
		mapMensaje.put("fecha_emision",new StringBuilder(fechaPublicacion.getDia()).
		                                    append("/").append(fechaPublicacion.getMes()).
		                                    append("/").append(fechaPublicacion.getAnho())
		                                    .toString());

		params.put("COD_ADUANA", codAduana);
		params.put("ANN_PRESEN", annPresen);
		params.put("COD_REGIMEN", codRegimen);
		params.put("NUM_DECLARACION", numDeclaracion);

		//obtener el consignatario RIN13
		String numCorreDoc = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
		String consignatario = diligenciaService.obtenerConsignatario(codAduana,annPresen,codRegimen,numDeclaracion,numCorreDoc);

		params.put("NUM_CORREDOC", numCorreDoc);

		if (tipoPDE_PIM.equals("PDE")){
			mapMensaje.put("desDestinatario", "Srs.");
			params.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
			mapMensaje.put("des_consignatario", this.obtenerConsignatario(params));
			mapMensaje.put("desDestinatario", "Srs. Agencia de Aduana:");
			mapMensaje.put("nombreDestinatario", mapMensaje.get("des_consignatario").toString().trim());
		}else{
			params.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE);
			mapMensaje.put("des_consignatario", this.obtenerConsignatario(params));
			mapMensaje.put("desDestinatario", "Srs. Due�o o Consignatario:");
			mapMensaje.put("nombreDestinatario", mapMensaje.get("des_consignatario").toString().trim());
		}

		List<Map<String,Object>> lstMercDispuestas= mercanciaDispuestaDAO.findMercanciasDispuestaByDUA(params);	
		if (lstMercDispuestas!=null&&lstMercDispuestas.size()>0&&!lstMercDispuestas.isEmpty()){
			for (Map<String, Object> mapMercDis : lstMercDispuestas){
				if(!CollectionUtils.isEmpty(mapMercDis)){
					// fecDocDispo = new SimpleDateFormat(FORMAT_ddMMyyyy).format(mapMercDis.get("FEC_DOCDISPOSICION").toString());
					mensajeRpta = "<tr>".concat("<td>").concat(mapMercDis.get("NUM_SECITEM").toString()).concat("</td>")
							.concat("<td>").concat(mapMercDis.get("NUM_SECSERIE").toString()).concat("</td>").concat("<td>").
							concat(mapMercDis.get("COD_TIPDOCMERCDISP").toString()).concat(" - ").concat(
							catalogoAyudaService.getDescripcionDataCatalogo("194", mapMercDis.get("COD_TIPDOCMERCDISP").toString())
		                    ).concat("</td>")
							.concat("<td>").concat(mapMercDis.get("NUM_DOCDISPOSICION").toString()).concat("</td>").concat("<td>").concat(
							mapMercDis.get("FEC_DOCDISPOSICION").toString()).concat("</td>")
							.concat("</tr>"); 
			        }
			}
		}
		mapMensaje.put("detalle", mensajeRpta);

		if (codAduana.trim().equals("118") )
			mapMensaje.put("des_aduana ", "Divisi&oacute;n de Importaciones.");
		else
			mapMensaje.put("des_aduana ", "Departamento de T&eacute;cnica Aduanera.");

		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());

	}

	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25276*/
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion para una declaracion sin cancelar
	 */
	public String validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(Map<String, Object> camposValidar) {
		String rpta = "ok";
	
		Declaracion declaracion = getDeclaracion(camposValidar);
		
		ValTratamientoDonacionService valTratamientoDonacionService = fabricaDeServicios.getService("ValTratamientoDonacion");
		
		List<Map<String, String>> result = valTratamientoDonacionService.validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(declaracion);
		 
		if(result.size() > 0) {
			StringBuilder sbError = new StringBuilder();
			
			for(Map<String, String> error : result) {
				String msjError = error.get("desError");
				
				if(msjError.toUpperCase().startsWith("SERIE (")) {
					String strBuscar = "): ";
					msjError = msjError.substring(msjError.indexOf(strBuscar) + strBuscar.length());
				}
				sbError.append("<p>").append(msjError).append("</p>");
			}
			
			rpta = sbError.toString();
		}
		
		return rpta;
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25276*/
	
	
	//gg vuce
	public List<Map<String, Object>> obtenerDocumentoControlAutorizanteSerieACopiar(Long numCorreDoc, 
			Integer numSecDoc, String codTipOper, List<Long> lstSeriesACopiarDocumentoControl){
		List<Map<String, Object>> documentoControlAutorizanteSerieACopiar = new ArrayList<Map<String,Object>>();
		
		for (Long numSecSerie : lstSeriesACopiarDocumentoControl) {
			Map<String, Object> mDetAutBase = new HashMap<String, Object>();
	        mDetAutBase.put("NUM_CORREDOC", numCorreDoc);
	        mDetAutBase.put("NUM_SECSERIE", numSecSerie);
	        mDetAutBase.put("NUM_SECDOC", numSecDoc);
	        mDetAutBase.put("COD_TIPOPER", codTipOper);
	        mDetAutBase.put("IND_DEL", Constantes.IND_REGISTRO_ACTIVO);
	        documentoControlAutorizanteSerieACopiar.add(mDetAutBase);
		}
		
		return documentoControlAutorizanteSerieACopiar;
	}
	
	public List<Long> obtenerSeriesConCopiaDocAut(
			List<Map<String, Object>> lstDetAutorizacionCopiados){
		List<Long> lstSeriesConCopiaDocAut = new ArrayList<Long>();
		for (Map<String, Object> detAutCopiado : lstDetAutorizacionCopiados) {
			lstSeriesConCopiaDocAut.add((Long)detAutCopiado.get("NUM_SECSERIE"));
		}
		return lstSeriesConCopiaDocAut;		
	}

	
	public void setPagarantiaDAO(PagarantiaDAO pagarantiaDAO) {
		this.pagarantiaDAO = pagarantiaDAO;
	}

    public void grabarComunicacionCompleta(Map<String, Object> params) throws ServiceException {
		try {
			SoporteAvisosService soporteAvisosService = fabricaDeServicios.getService("diligencia.ingreso.soporteAvisosService");
			String tipoPDE = "PDE";
			String tipoPIN = "PIN";
			String descComunicacion = params.get("des_nota").toString();
			String codMotivoNotificacion = params.get("cod_motnoti").toString();
			String indicadorDetalle = params.get("ind_detdescnoti").toString();
			String numCorreDoc = params.get("num_corredoc").toString();
			String tipoDiligencia = params.get("tipoDiligencia").toString();
			String diligenciaContDespacho = params.get("diligenciaContDespacho").toString();
			String usuarioNombre = params.get("usuarioNombre").toString();
			String detalleNotificacion = params.get("detalleNotificacion").toString();
			Map mapCabDeclaraActual = (Map) params.get("mapCabDeclaraActual");
			HashMap<String, Object> mapaDetalleNotificacionPDF;
			List<HashMap<String, Object>> detallesNotificacion = null;
			HashMap<String, Object> mapaDetalleNotificacion;
			FechaBean fecActual = new FechaBean();

			if (indicadorDetalle.equals("1")) {
				detallesNotificacion = (List<HashMap<String, Object>>) new JsonSerializer().deserialize(detalleNotificacion, ArrayList.class);
			}

			// inserta la comunicacion con el portal
			grabarComunicacion(params);

			List<ComunicacionDescripcion> listaComunicacionesPendientes;
			ComunicacionDescripcion ultimaComunicacion = null;
			int numeroComunicacionesPendientes;

			listaComunicacionesPendientes = obtenerComunicacionesPendientes(Long.parseLong(numCorreDoc));
			numeroComunicacionesPendientes = listaComunicacionesPendientes.size();

			if (numeroComunicacionesPendientes != 0) {
				ultimaComunicacion = listaComunicacionesPendientes.get(numeroComunicacionesPendientes - 1);
			}

			if (indicadorDetalle.equals("1")) {
				for (HashMap<String, Object> detNotificacion : detallesNotificacion) {
					mapaDetalleNotificacion = new HashMap<String, Object>();
					mapaDetalleNotificacion.put("des_detalle", formatearDetalleNotificacion(detNotificacion, codMotivoNotificacion));
					mapaDetalleNotificacion.put("num_nota", ultimaComunicacion.getNumNota());
					mapaDetalleNotificacion.put("cod_usuregis", ultimaComunicacion.getCodUsuRegistro());
					mapaDetalleNotificacion.put("fec_regis", fecActual.getTimestamp());
					mapaDetalleNotificacion.put("cod_usumodif", ultimaComunicacion.getCodUsuRegistro());
					mapaDetalleNotificacion.put("fec_modif", fecActual.getTimestamp());
					grabarDetalleComunicacionNotificacion(mapaDetalleNotificacion);
				}
			}

			// Formateamos del Tipo Html la descripcion de la comunicaci�n y su detalle
			ultimaComunicacion.setIndInsercionAviso(true);
			descComunicacion = obtenerConsolidadoDetalleNotificacion(ultimaComunicacion);

			// Formateamos el detalle para la generacion del PDF
			mapaDetalleNotificacionPDF = obtenerConsolidadoDetalleNotificacionParaReporte(ultimaComunicacion);
			String tipoComunicacion = "e";

			// si es comunicacion con el portal envia una notificacion
			HashMap<String, Object> rutaPDFPIN = null;
			HashMap<String, Object> rutaPDFPDE = null;
			String codAduana = mapCabDeclaraActual.get("COD_ADUANA").toString();
			String annPresen = mapCabDeclaraActual.get("ANN_PRESEN").toString();
			String codRegimen = mapCabDeclaraActual.get("COD_REGIMEN").toString();
			String numDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION").toString();
			String codCanal = mapCabDeclaraActual.get("COD_CANAL").toString();
			Integer codPlantilla = 0;

			if ("02".equals(codMotivoNotificacion)) {
				codPlantilla = Constantes.COD_PL_NOTI_DECLA1;
			}
			if ("03".equals(codMotivoNotificacion)) {
				codPlantilla = Constantes.COD_PL_NOTI_DECLA2;
			}
			if ("05".equals(codMotivoNotificacion)) {
				codPlantilla = Constantes.COD_PL_NOTI_DECLA3;
			}
			if ("08".equals(codMotivoNotificacion)) {
				codPlantilla = Constantes.COD_PL_NOTI_DECLA4;
			}

			if (SunatStringUtils.isStringInList(codMotivoNotificacion, "02,03,05,08")) {
				
			rutaPDFPIN = generarPDF(codPlantilla, mapaDetalleNotificacionPDF, tipoPIN, mapCabDeclaraActual);
			rutaPDFPDE = generarPDF(codPlantilla, mapaDetalleNotificacionPDF, tipoPDE, mapCabDeclaraActual);
			}

			if (tipoComunicacion.trim().equals(Constantes.COMUNICACION_DILIGENCIA_EXTERNA) && !("11".equals(codMotivoNotificacion))) {//PAS20175E220100069: Motivo 11(Duda Razonable), no env�a notificaci�n
				Map<String, Object> destinatarios = new HashMap<String, Object>();
				destinatarios.put("DES_CONSIGNATARIO", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PIM"));
				destinatarios.put("DES_AGENCIA_ADUANAS", mapCabDeclaraActual.get("NOM_RAZONSOCIAL_PDE"));
				if (tipoDiligencia.equals(Constantes.DILIG_CONT_DESPACHO) ||
						tipoDiligencia.equals(Constantes.DILIG_DESCA_PARCIAL)) {
					if (codCanal.equals(Constantes.CANAL_NARANJA)) {
						destinatarios.put("RECEPTOR", Constantes.IMPORTADOR);
						//continuacion de despacho
						soporteAvisosService.notificarObservacion(
								descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString()},
								Constantes.COD_PL_NOTI_OBS_REV_DOCUMENTARIA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);

						destinatarios.put("RECEPTOR", Constantes.AGENTE);
						//continuacion de despacho
						soporteAvisosService.notificarObservacion(
								descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString()},
								Constantes.COD_PL_NOTI_OBS_REV_DOCUMENTARIA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);
					}

					if (tipoDiligencia.equals(Constantes.DILIG_CONT_DESPACHO)) {
						if (codCanal.equals(Constantes.CANAL_ROJO)) {
							destinatarios.put("RECEPTOR", Constantes.IMPORTADOR);
							//continuacion de despacho
							soporteAvisosService.notificarObservacion(
									descComunicacion,
									codAduana,
									annPresen,
									codRegimen,
									numDeclaracion,
									usuarioNombre,
									new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString()},
									Constantes.COD_PL_NOTI_CONTDESPACHO,
									Constantes.CODIGO_NOTIFICACION,
									Constantes.CONTRIBUYENTE,
									destinatarios);

							destinatarios.put("RECEPTOR", Constantes.AGENTE);
							//continuacion de despacho
							soporteAvisosService.notificarObservacion(
									descComunicacion,
									codAduana,
									annPresen,
									codRegimen,
									numDeclaracion,
									usuarioNombre,
									new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString()},
									Constantes.COD_PL_NOTI_CONTDESPACHO,
									Constantes.CODIGO_NOTIFICACION,
									Constantes.CONTRIBUYENTE,
									destinatarios);
						}
					}

					if (tipoDiligencia.equals(Constantes.DILIG_DESCA_PARCIAL)) {
						if (codCanal.equals(Constantes.CANAL_ROJO)) {
							destinatarios.put("RECEPTOR", Constantes.IMPORTADOR);
							//Decargas Parciales
							soporteAvisosService.notificarObservacion(
									descComunicacion,
									codAduana,
									annPresen,
									codRegimen,
									numDeclaracion,
									usuarioNombre,
									new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString()},
									Constantes.COD_PL_NOTI_DESCARGAPARCIAL,
									Constantes.CODIGO_NOTIFICACION,
									Constantes.CONTRIBUYENTE,
									destinatarios);

							destinatarios.put("RECEPTOR", Constantes.AGENTE);
							//Descargas Parciales
							soporteAvisosService.notificarObservacion(
									descComunicacion,
									codAduana,
									annPresen,
									codRegimen,
									numDeclaracion,
									usuarioNombre,
									new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString()},
									Constantes.COD_PL_NOTI_DESCARGAPARCIAL,
									Constantes.CODIGO_NOTIFICACION,
									Constantes.CONTRIBUYENTE,
									destinatarios);
						}
					}
				}

				if (tipoDiligencia == "") {
					if (codCanal.equals(Constantes.CANAL_ROJO)) {
						diligenciaService.notificarObservacionReporteAdjunto(descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString()},
								Constantes.COD_SEC_NOTI_DECLA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								Constantes.ESTADO_CONCLU_NOTIFICADO,
								rutaPDFPIN, tipoPIN);


						diligenciaService.notificarObservacionReporteAdjunto(descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString()},
								Constantes.COD_SEC_NOTI_DECLA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								Constantes.ESTADO_CONCLU_NOTIFICADO,
								rutaPDFPDE, tipoPDE);
					} else if (codCanal.equals(Constantes.CANAL_NARANJA)) {
						diligenciaService.notificarObservacionReporteAdjunto(descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PIM").toString()},
								Constantes.COD_SEC_NOTI_DECLA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								Constantes.ESTADO_CONCLU_NOTIFICADO,
								rutaPDFPIN, tipoPIN);

						diligenciaService.notificarObservacionReporteAdjunto(descComunicacion,
								codAduana,
								annPresen,
								codRegimen,
								numDeclaracion,
								usuarioNombre,
								new String[]{mapCabDeclaraActual.get("NUM_DOCIDENT_PDE").toString()},
								Constantes.COD_SEC_NOTI_DECLA,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								Constantes.ESTADO_CONCLU_NOTIFICADO,
								rutaPDFPDE, tipoPDE);
					}
				}
                if(!("11".equals(codMotivoNotificacion))){//PAS20175E220100069: Motivo de Notificacion 11(Duda Razonable), no actualiza estado de la DAM
				BusquedaDua busquedaDua = new BusquedaDua();
				busquedaDua.setNumCorreDoc(Long.parseLong(mapCabDeclaraActual.get("NUM_CORREDOC").toString()));
				busquedaDua.setCodAduana(mapCabDeclaraActual.get("COD_ADUANA").toString());
				busquedaDua.setAnnoPresenta(Long.parseLong(mapCabDeclaraActual.get("ANN_PRESEN").toString()));
				busquedaDua.setCodRegimen(mapCabDeclaraActual.get("COD_REGIMEN").toString());
				busquedaDua.setNumDeclaracion(Long.parseLong(mapCabDeclaraActual.get("NUM_DECLARACION").toString()));

				Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
				paramDeclaracion.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
				if (diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_CONCLUSION_DESPACHO)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_NOTIFICADO);
				} else if ("01".equals(diligenciaContDespacho)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
				} else if ("02".equals(diligenciaContDespacho)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
				} else if (diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_REV_DOCUMENTARIA)
						|| diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_REC_FISICO)
						|| diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_DESCA_PARCIAL)
						|| diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_CONT_DESPACHO)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_NOTIFICADO);
				} else if (diligenciaService.tieneDiligenciaTipo(busquedaDua, Constantes.DILIG_PREV_ANTIC_ROJO)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_REVISION);
				} else {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_NOTIFICADO);
				}

				if (mapCabDeclaraActual.get("COD_ESTDUA").toString().equals(Constantes.ESTADO_CONCLU_REVISION)) {
					paramDeclaracion.put("COD_ESTDUA", Constantes.ESTADO_CONCLU_NOTIFICADO);
				}

				//amancilla  INC 2017-036204 declaracionService.updateDeclaracion(paramDeclaracion);
				//error de programacion se cruzan las tx
				declaracionService.updateDeclaracionSinTXNewRequired(paramDeclaracion);
			}
			}
			//P24-II-PAS20165E220200152 - Inicio
			boolean existeIndicador = existeElementoEnListaDeMapas((List<Map<String,Object>>) mapCabDeclaraActual.get("LIST_INDICADORES_DUA"),"COD_INDICADOR",
					ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
			Map<String, Object> param = new HashMap<String, Object>();
			if (existeIndicador){
				param.put("cod_indicador_dua", ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
			}else{
				param.put("cod_indicador_dua", mapCabDeclaraActual.get("cod_indicador_dua"));
			}
			if (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO) || (codCanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) && existeIndicador)){	
				param.put("num_corredoc",mapCabDeclaraActual.get("NUM_CORREDOC"));
				param.put("cod_estrev", ConstantesDataCatalogo.COD_EST_REVISION_RECONOCIMIENTO_EFECTUADO_CON_NOTIFICACION);
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("NUM_CORREDOC", mapCabDeclaraActual.get("NUM_CORREDOC"));
				param.put("cod_funcionario",this.espeDocuDAO.findEspecAsigByDocu(parametros));
				param.put("cod_canal",mapCabDeclaraActual.get("COD_CANAL"));
				param.put("COD_REGIMEN", mapCabDeclaraActual.get("COD_REGIMEN"));
				param.put("COD_ADUANA", mapCabDeclaraActual.get("COD_ADUANA"));
				param.put("ANN_PRESEN", mapCabDeclaraActual.get("ANN_PRESEN"));
				param.put("NUM_DECLARACION", mapCabDeclaraActual.get("NUM_DECLARACION")); 
				param.put("EN_PROCESO", "0");
				param.put("cod_tipasig", "R");
				this.grabarRevision(param);
			}			
			//P24-II-PAS20165E220200152 - Fin
			
		} catch (DataAccessException e) {
			log.error("*** ERROR ***", e);
			throw new ServiceException(this,
					"grabarComunicacionCompleta Ha ocurrido un error al inserta los datos");
		} catch (Throwable e) {
			log.error("DiligenciaServiceImpl : grabarComunicacionCompleta - ERROR: ", e);
			throw new ServiceException(this,
					"Ha ocurrido un error inseperado en el metodo de grabado de la comunicacion");
		}
    }

    private HashMap<String, Object> generarPDF(Integer codPlantilla, HashMap<String, Object> detalleComunicacion, String tipo, Map mapCabDeclaraActual) throws Exception {

        HashMap<String, Object> rutas = new HashMap<String, Object>();
        String json;
        int ide = -1;
        try {
            //request.setCharacterEncoding("ISO-8859-1");

            if (codPlantilla == Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL) {
                mapCabDeclaraActual = (Map) detalleComunicacion.get("DECLARACION");
            }

            String codAduana = mapCabDeclaraActual.get("COD_ADUANA").toString();
            String annPresen = mapCabDeclaraActual.get("ANN_PRESEN").toString();
            String codRegimen = mapCabDeclaraActual.get("COD_REGIMEN").toString();
            String numDeclaracion = mapCabDeclaraActual.get("NUM_DECLARACION").toString();

            Map<String, Object> paramsCons = new HashMap<String, Object>();
            paramsCons.put("COD_ADUANA", codAduana);
            paramsCons.put("ANN_PRESEN", annPresen);
            paramsCons.put("COD_REGIMEN", codRegimen);
            paramsCons.put("NUM_DECLARACION", numDeclaracion);
            if (tipo.equals("PDE")) {
                paramsCons.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
                log.debug("obteniendo los datos agente" + paramsCons);
            } else if (tipo.equals("PIN")) {
                paramsCons.put("tipoParticipante", Constantes.CODIGO_TIPO_PARTICIPANTE);
                log.debug("obteniendo consignatario importador" + paramsCons);
            }

            Map<String, String> cabecera = new HashMap<String, String>();
            FechaBean fechaPublicacion = new FechaBean();
            String consignatario = diligenciaService.obtenerConsignatario(paramsCons);
            log.debug("descripcion consignatario" + consignatario);
            String intendencia = catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana);
            String elaboradoPor = diligenciaService.obtenerElaborado(codAduana);
            String fechaEmision = fechaPublicacion.getDia().toString() + "/" + fechaPublicacion.getMes().toString() + "/" + fechaPublicacion.getAnho().toString();
            List lista = new ArrayList();

            //Para la plantilla 100159
            if (codPlantilla == Constantes.COD_PL_NOTI_DECLA1 || codPlantilla == Constantes.COD_PL_NOTI_DECLA2
                    || codPlantilla == Constantes.COD_PL_NOTI_DECLA3 || codPlantilla == Constantes.COD_PL_NOTI_DECLA4) {
                if (!detalleComunicacion.isEmpty()) {
                    if (detalleComunicacion.get("DET_NOTIFICACION") != null) {
                        List<HashMap<String, Object>> detalleNotificacion = (List<HashMap<String, Object>>) detalleComunicacion.get("DET_NOTIFICACION");
                        log.debug("entrada de los detalles para gestion" + detalleNotificacion);

                        for (HashMap<String, Object> map : detalleNotificacion) {
                            Map<String, Object> filaDetalle = new HashMap<String, Object>();
                            String subpartidaDeclarada = null;
                            String subpartidaPropuesta = null;
                            String subpartidaNacional = null;
                            if (map.get("subpartida_nacional_declarada") != null) {
                                subpartidaDeclarada = this.formatearSupartida(map.get("subpartida_nacional_declarada").toString());
                            }

                            if (map.get("subpartida_nacional_propuesta") != null) {
                                subpartidaPropuesta = this.formatearSupartida(map.get("subpartida_nacional_propuesta").toString());
                            }

                            if (map.get("subpartida_nacional") != null) {
                                subpartidaNacional = this.formatearSupartida(map.get("subpartida_nacional").toString());
                            }

                            filaDetalle.put("SERIE", map.get("serie"));
                            filaDetalle.put("VALOR_OBSERVADO_UNIDAD", map.get("valor_observado_por_unidad_(us$_por_unidad)"));
                            filaDetalle.put("REFERENCIA", map.get("referencia_(declaracion)"));
                            filaDetalle.put("SUB_NACIONAL_DECLARADA", subpartidaDeclarada);
                            filaDetalle.put("SUB_NACIONAL_PROPUESTA", subpartidaPropuesta);
                            filaDetalle.put("SUB_NACIONAL", subpartidaNacional);
                            filaDetalle.put("DERECHO_ANTIDUMPING", map.get("derecho_antidumping_(%)"));
                            filaDetalle.put("SEC_AUTORIZA_INGRESO", map.get("sector_autoriza_ingreso"));
                            filaDetalle.put("DOCUMENTO", map.get("documento"));
                            log.debug("entmediooogestion" + filaDetalle);
                            filaDetalle.put("COD_MOTIVO_NOTI", detalleComunicacion.get("COD_MOTIVO_NOTI"));
                            filaDetalle.put("CAB_DETALLE", detalleComunicacion.get("CAB_DETALLE"));
                            filaDetalle.put("PIE_DETALLE", detalleComunicacion.get("PIE_DETALLE"));
                            filaDetalle.put("COD_ADUANA", codAduana);
                            filaDetalle.put("ANN_PRESEN", annPresen);
                            filaDetalle.put("COD_REGIMEN", codRegimen);
                            filaDetalle.put("NUM_DECLARACION", numDeclaracion);
                            filaDetalle.put("DES_CONSIGNATARIO", consignatario);
                            filaDetalle.put("DES_INTENDENCIA", intendencia);
                            filaDetalle.put("ELABORADO_POR", elaboradoPor);
                            filaDetalle.put("FECHA_EMISION", fechaEmision);
                            log.debug("finall de los detalles para gestion" + filaDetalle);
                            lista.add(filaDetalle);
                        }
                    }
                }
                //Para la plantilla 100160
            } else if (codPlantilla == Constantes.COD_PL_NOTI_DECLA_MERCA_DISP_TOTAL) {
                if (!detalleComunicacion.isEmpty()) {
                    if (detalleComunicacion.get("DET_NOTIFICACION") != null) {
                        List<HashMap<String, Object>> detalleNotificacion = (List<HashMap<String, Object>>) detalleComunicacion.get("DET_NOTIFICACION");

                        for (HashMap<String, Object> map : detalleNotificacion) {
                            Map<String, Object> filaDetalle = new HashMap<String, Object>();
                            filaDetalle.put("CAB_DETALLE", detalleComunicacion.get("CAB_DETALLE"));
                            filaDetalle.put("TIPO_DOC_DISP_MERC", map.get("tipo_doc_disp_merc"));
                            filaDetalle.put("DOC_DISP_MERC", map.get("doc_disp_merc"));
                            filaDetalle.put("FEC_EMISION", map.get("fec_emision"));
                            lista.add(filaDetalle);
                        }
                    }
                }
            }

            Map<String, Object> mapJson = new HashMap();
            mapJson.put("cabecera", cabecera);

            mapJson.put("detalle", lista);
            int iddoc = codPlantilla;
            log.debug("codigo plantilla" + codPlantilla);
            String tipoDoc = "pdf";
            int modelo = 1000;
            JsonSerializer serializer = new JsonSerializer();
            json = serializer.serialize(mapJson).toString();
            log.debug("json json" + json);
            try {
                Service service = new Service();
                Call call = (Call) service.createCall();
                String urlServiceGenerarPDF = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_GENERADOR_PDF, ConstantesDataCatalogo.COD_DATACATALOGO_GENERADOR_PDF);
                log.info("EHR: urlServiceGenerarPDF: " + urlServiceGenerarPDF);
                call.setTargetEndpointAddress(new java.net.URL(urlServiceGenerarPDF));
                call.setOperationName("genera");
                call.addParameter("iddoc", XMLType.XSD_INT, ParameterMode.IN);
                call.addParameter("datos", XMLType.XSD_STRING, ParameterMode.IN);
                call.addParameter("tipo", XMLType.XSD_STRING, ParameterMode.IN);
                call.addParameter("modelo", XMLType.XSD_INT, ParameterMode.IN);
                call.setReturnClass(int.class);
                ide = new Integer(call.invoke(new Object[]{iddoc, json, tipoDoc, modelo}).toString()).intValue();
                log.info("EHR: ide: " + ide);
                rutas.put("num_pdf", ide);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            Map<String, Object> error = handleError(e);
            log.info(error.get("msgLog"));
            return (HashMap<String, Object>) error;
        }
        return rutas;
    }

    private String formatearSupartida(String supartida) {

        String uno = (String) supartida.subSequence(0, 4);
        String dos = (String) supartida.subSequence(4, 6);
        String tres = (String) supartida.subSequence(6, 8);
        String cuatro = (String) supartida.subSequence(8, 10);

        String partidaFormateado = uno.concat(".").concat(dos).concat(".").concat(tres).concat(".").concat(cuatro);

        return partidaFormateado;
    }

    private Map<String, Object> handleError(Exception e) {

        // seteando el mensaje de tipo de error (para aclarar el log)
        String tipoError = null;
        if (e instanceof ServiceException) {
            tipoError = "**** ERROR DE NEGOCIO ****";
        } else if (e instanceof IllegalArgumentException) {
            tipoError = "**** ERROR DE NEGOCIO ****";
        } else if (e instanceof Exception) {
            tipoError = "**** ERROR DE APLICACION ****";
        }

        // seteando el mensaje de error
        String msgError = "" + ((e == null || e instanceof NullPointerException) ? "Null Pointer Exception" : e.getMessage());
        if (e != null && e.getCause() != null) {
            msgError = msgError + ", CAUSA: " + e.getCause().getMessage();
        }

        // seteando el bean de error standard
        MensajeBean beanM = new MensajeBean();
        beanM.setError(true);
        beanM.setMensajeerror(msgError);
        beanM.setMensajesol("Por favor vuelva a intentarlo. De continuar el error comuniquese con el Administrador.");

        // seteando el objeto result
        HashMap<String, Object> result = new HashMap<String, Object>();
        result.put("msgError", msgError);
        result.put("msgLog", tipoError + ": " + msgError);
        result.put("msgSol", beanM.getMensajesol());

        return result;
    }

   	//RSV PAS20165E220200076 PARA VALIDAR CONTINGENTES
	/**
	 * Metodo que verifica si la dua cuenta con un expediente de sustento de
	 * rectificacion: Canal Verde: todos deben de tener un expediente de sustento
	 * de rectificacion Canal Rojo o Naranja: solo los que tengan una diligencia
	 * de despacho deben tener un expediente de sustento de rectificacion.
	 *
	 * @param mapaCabDeclara
	 *          mapa con la informacion de la declaracion (DUA)
	 * @param tieneDiligenciaDespacho
	 *          the tiene diligencia despacho
	 * @throws ServiceException
	 *           the service exception
	 */
	public String validarRectiTieneExpedienteContingentes(
			Map<String, Object> mapaCabDeclara, Long numeroCorrelativoSolicitud)
					throws ServiceException
	{
		String mensajeError = ""; 
	//	List<Map<String, Object>> listaIndicador=(List) mapaCabDeclara.get("LIST_INDICADORES_DUA");
        boolean indicador16 = false; 

        	   Map<String, Object> parametros = new HashMap<String, Object>();
        	    parametros.put("NUM_CORREDOC", new Long(mapaCabDeclara.get("NUM_CORREDOC").toString()));
            // cargamos los valores de series iTem cod_tabla ='T0060'
            RectificacionAbstract rectifiSerie = fabricaDeServicios.getService("diligencia.rectificacion.codtabla." + "T0060");
            List<Map<String, Object>> lstIndicadorDUA = rectifiSerie.getTableRectificadoMergedBD(
                parametros,
                  numeroCorrelativoSolicitud);
            if(   !CollectionUtils.isEmpty(lstIndicadorDUA))	 {
                for (Map<String, Object> indicadorDUA : lstIndicadorDUA)
                {
                	
                	if( "16".equals(indicadorDUA.get("COD_INDICADOR").toString())     )	{    
            				indicador16 = true;
            				break;
            			}
                }
            }
        	

    	parametros = new HashMap();
		String[] notEstadoExpediente = new String[] {"8","9","99"};
		parametros.put("NUM_DECLARACION", mapaCabDeclara.get("NUM_DECLARACION"));
		parametros.put("ANN_PRESEN", mapaCabDeclara.get("ANN_PRESEN").toString());//faltaba y generaba error
		parametros.put("COD_ADUANA", mapaCabDeclara.get("COD_ADUANA"));
		parametros.put("COD_REGIMEN", mapaCabDeclara.get("COD_REGIMEN"));
		parametros.put("codi_aduan", mapaCabDeclara.get("COD_ADUANA")); // Para el swaper de tramite
		parametros.put("procedim", "0904");
		parametros.put("ACT_ESTADO_NOT_IN", notEstadoExpediente);
		if (indicador16 ) {
			parametros.put("COD_REGIMEN", Utilidades.obtieneRegimenExped(mapaCabDeclara.get("COD_REGIMEN").toString()));
			ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
			List<Map<String, Object>> listExpediente = expedienteService.findExpedientesAsociadoDeclaracion(parametros);
			if (CollectionUtils.isEmpty(listExpediente) ){
					mensajeError = "La declaraci�n con acogimiento a contingente en la rectificaci�n posterior a la cancelaci�n de la deuda, no cuenta con expediente de tr�mite documentario (procedimiento 0904)";
					throw new ServiceException(this, mensajeError);
			} else {
				
						parametros.put("numeroCorrelativo", mapaCabDeclara.get("NUM_CORREDOC"));
						parametros.put("codTippartic", new String[] {"41","45"});

						ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("diligencia.ingreso.participanteDef_xa");

						List<Participante> listadoParticipante = participanteDAO.findTipoPartTransByCriterios(parametros);
						String[] RucImportadorAgente = new String[listadoParticipante.size()];

						int i=0;
						for(Participante participante : listadoParticipante) {
							RucImportadorAgente[i] = participante.getNumeroDocumentoIdentidad();
							i++;
						}
						for(Map<String, Object> expediente : listExpediente){
							//if(SunatStringUtils.include(expediente.get("NRODOC").toString().trim(), RucImportadorAgente)) {
							if(SunatStringUtils.include(expediente.get("COMIT_NRO").toString().trim(), RucImportadorAgente)) {
								return "";
							}
							else{						
								String rucExpediente = expediente.get("COMIT_NRO").toString();
								String numeroexpediente = expediente.get("CODI_ADUA").toString()+"-"+expediente.get("OFIC_REC").toString()+
										"-"+expediente.get("ANOEXPEDI").toString() + "-" +expediente.get("NROEXPEDI").toString();
								mensajeError =  "Numero de RUC " + rucExpediente + " del expediente " + numeroexpediente + " no corresponde al agente de aduana y/o consignatario de la declaraci�n a rectificar";
								throw new ServiceException(this, mensajeError);
							}
						}
				//** */
				
			}
		}
		
		return mensajeError;
	}    
       
	public String obtenerDescripcionCatalogo(String codCatalogo, String codDataCat){

		if(StringUtils.isEmpty(codCatalogo) || StringUtils.isEmpty(codDataCat)){
			return "";
		}
		String descripcionCat = catalogoAyudaService.getDescripcionDataCatalogo(codCatalogo, codDataCat);
		return StringUtils.isEmpty(descripcionCat) ? "" : descripcionCat ;
	}
	
	
	@Override
	public Diligencia obtenerDiligenciaPorPk(Map<String, Object> params) {
		Diligencia diligencia = new Diligencia();
		if(params!=null) {
			diligencia = cabDiligenciaDAO.findAllDiligenciaByPK(params);
		}
		return diligencia;
	}


	/*------ csantillan PAS20181U220200069 ----------*/
		public void insertarResolucion(String nroCorrelativoDUA, String codTipOper, String codTipDocAso, String numeroExpediente, String aduanaExpediente,
		        String anioExpediente, String fechaExpediente,  String fechaFinExpediente, String codAreaExpediente) {
			FechaBean fechaBean = new FechaBean();

			// buscar los documentos asociados ya existentes para seguir la secuencia (NUM_SECDOC)
			List<DatoOtroDocSoporte> docAsoList = buscarDocumentosAsociados(nroCorrelativoDUA);

			// buscar el secuencial
			int nextNumSecDoc = buscarSecuencialDocumentoAsociado(docAsoList);

			// insertar lo ingresado en decision administrativa
			Map<String, Object> paramsDocAso = new HashMap<String, Object>();

			paramsDocAso.put("NUM_CORREDOC", nroCorrelativoDUA);
			paramsDocAso.put("NUM_SECDOC", nextNumSecDoc);
			paramsDocAso.put("COD_TIPOPER", codTipOper);
			paramsDocAso.put("COD_TIPDOCASO", codTipDocAso);
			paramsDocAso.put("COD_ADU_AUT", aduanaExpediente);
			paramsDocAso.put("ANN_DOC", anioExpediente);
			paramsDocAso.put("NUM_DOC", numeroExpediente);
			paramsDocAso.put("FEC_VENC", SunatDateUtils.getDate(fechaFinExpediente,"dd/MM/yyyy"));
			paramsDocAso.put("OBS_OBS", codAreaExpediente);
			
			if (NumberUtils.isNumber(fechaExpediente)) {
				Integer expFechaEmisionInt = Integer.parseInt(fechaExpediente);
				paramsDocAso.put("FEC_EMIS", SunatDateUtils.getDateFromInteger(expFechaEmisionInt));
			}
			
			

			DocAutAsociadoService docAutAsociadoService = (DocAutAsociadoService) fabricaDeServicios
			        .getService("declaracion.docAutAsociadoService");

			docAutAsociadoService.insertSelective(paramsDocAso);
			
		}
		
		// busquedas en listas y secuenciales
		public List<DatoOtroDocSoporte> buscarDocumentosAsociados(String nroCorrelativoDUA) {
				return buscarDocumentosAsociados(nroCorrelativoDUA, null);
		}
		
		
		private List<DatoOtroDocSoporte> buscarDocumentosAsociados(String nroCorrelativoDUA, String tipoDocAso) {

			Map<String, String> params = new HashMap<String, String>();

			params.put("NUM_CORREDOC", nroCorrelativoDUA);
			params.put("IND_DEL", INDICADOR_DE_ELIMINACION_FALSO);
			params.put("COD_TIPDOCASO", tipoDocAso);

			DocAutAsociadoService docAutAsociadoService = (DocAutAsociadoService) fabricaDeServicios
			        .getService("declaracion.docAutAsociadoService");

			List<DatoOtroDocSoporte> docAsoList = docAutAsociadoService.find(params);

			return docAsoList;
	}
		
		public int buscarSecuencialDocumentoAsociado(List<DatoOtroDocSoporte> lista) {

			int result = 1;

			if (!CollectionUtils.isEmpty(lista)) {

				DatoOtroDocSoporte item = null;

				int maxNumSecDoc = -1;
				for (int i = 0; i < lista.size(); i++) {
					item = lista.get(i);

					if (item != null) {

						int numSecDocValue = item.getNumsecdocum();

						if (numSecDocValue > maxNumSecDoc) {
							maxNumSecDoc = numSecDocValue;
						}

					}

				}

				if (maxNumSecDoc != -1) {
					result = maxNumSecDoc + 1;
				}

			}
			return result;
		}
		
		/*------ fin csantillan PAS20181U220200069 ----------*/

	//PAS20181U220200069 - mtorralba 20190304 - Se convierte el registro de cambios de Observaci�n de cualquier tipo
	private void comparaCampoObservacion( String tipoObservacion, Map<String,Object> declaracion, Map<String,Object> declaracionAnt, String tipDilig, Integer numCorreDocSol ) {
			
		String keyNUMSEC_OBS = "";
		String keyOBS_OBS = "";
		if( tipoObservacion.equals(Constantes.TIPO_OBSERVACION_DECLA)) {
			keyNUMSEC_OBS = "NUM_SECOBS";
			keyOBS_OBS = "OBS_OBS";
		}
		if( tipoObservacion.equals(Constantes.TIPO_OBSERVACION_PECOAMAZ)) {
			keyNUMSEC_OBS = "SECOBS_PECO";
			keyOBS_OBS = "OBS_PECO";
		}

		Map mapObs = new HashMap();
		mapObs.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
		mapObs.put("NUM_SECOBS", declaracion.get(keyNUMSEC_OBS) != null ? declaracion.get(keyNUMSEC_OBS).toString().trim() : "1");// siguiente
		mapObs.put("COD_TIPOBS", tipoObservacion); 
		mapObs.put("OBS_OBS", declaracion.get(keyOBS_OBS));
		      
		Map keyObs = new HashMap();
		keyObs.put("NUM_CORREDOC", mapObs.get("NUM_CORREDOC"));
		keyObs.put("NUM_SECOBS", mapObs.get("NUM_SECOBS"));
		keyObs.put("COD_TIPOBS", mapObs.get("COD_TIPOBS"));

		Map mapObsDO = null;
		mapObs.put("dataOriginal", mapObsDO);
		mapObs.put("clave", keyObs);

		if ((mapObs.get("OBS_OBS") == null || "".equals(mapObs.get("OBS_OBS").toString().trim()))) {
			if (declaracionAnt.get(keyNUMSEC_OBS) != null) {
				if (mapObs.get("OBS_OBS") == null) {
					mapObs.put("OBS_OBS", "");
				}
				this.observacionDAO.update(mapObs);
				// caso excepcional
				Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
				mapObsAnt.put("OBS_OBS", declaracionAnt.get(keyOBS_OBS));
				Map<String, Object> mapDiferenciasObs = soporteComparadorService.comparaMap(mapObs, mapObsAnt, EnumTablaModel.OBSERVACION);
				this.registrarRectiOficio(mapDiferenciasObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), Constantes.COD_TABLA_OBSERVACION, numCorreDocSol);
			}
		}
		else {
			if (declaracionAnt.get(keyNUMSEC_OBS) == null) {
				// P34 parche por lo mientras EJHM	
				mapObs.put("NUM_SECITEM", 0);
				// P34
				this.observacionDAO.insert(mapObs);
				mapObs.put("dataOriginal", mapObsDO);
				// caso excepcional
				Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
				mapObsAnt.put("OBS_OBS", declaracionAnt.get(keyOBS_OBS));
				Map<String, Object> mapDiferenciasObs = soporteComparadorService.comparaMap(mapObs, mapObsAnt, EnumTablaModel.OBSERVACION);
				this.registrarRectiOficio(mapDiferenciasObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), Constantes.COD_TABLA_OBSERVACION, numCorreDocSol);
			}
		    else {
		    	if (!mapObs.get("OBS_OBS").toString().trim().equals(declaracionAnt.get(keyOBS_OBS).toString().trim())) {// VERITIFCAMOS SI HAY CAMBIOS EN LAS OBSERVACIONES
					this.observacionDAO.update(mapObs);
					Map<String, Object> mapObsAnt = new HashMap<String, Object>(mapObs);
					mapObsAnt.put("OBS_OBS", declaracionAnt.get(keyOBS_OBS));
					Map<String, Object> mapDiferenciasObs = soporteComparadorService.comparaMap(mapObs, mapObsAnt, EnumTablaModel.OBSERVACION);
					this.registrarRectiOficio(mapDiferenciasObs, tipDilig, new Long(declaracion.get("NUM_CORREDOC").toString().trim()), Constantes.COD_TABLA_OBSERVACION, numCorreDocSol);
				}
	        }
		}
			
	}//Final metodo comparaCampoObservacion

}
