package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
//import org.josql.internal.Utilities;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;

//import bsh.util.Util;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.CabDeuda;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DetDeuda;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeudaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recauda2.garantia.service.ConsultaCtaCteService;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Cambio1DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.Cambio1;

public class DeudaServiceImpl implements DeudaService
{
  protected final Log   log = LogFactory.getLog(this.getClass());
  protected static final String DOLAR = "USD";

  private DeudaDocumDAO  deudaDocumDAO;

  private DetPagoDuaDAO detPagoDuaDAO;
  //<EHR>
  private IndicadorDUADAO indicadorDUADAO;
  //</EHR>

  private SoporteService soporteService;
  private FabricaDeServicios fabricaDeServicios;
  private HotSwappableTargetSource swapperDatasource;

  private DetDeudaDAO detDeudaDAO; 
  
  //inicio gmontoya  PASE 176 P24
  private ConsultaCtaCteService consultaCtaCteService;
  
//fin gmontoya PASE 176 P24  
  //private HotSwappableTargetSource swapperDSDeclaracion; /*RIN13 SWF*/
  
  
  // RIN13
  public boolean tieneExtornoPago( Map<String, Object> params) throws ServiceException{
	  
	  String indicadorExtorno = detPagoDuaDAO.findIndicadorExtornoPago(params.get("numcorredoc").toString());
	  if(indicadorExtorno.equals("0")){
		  return false;  
	  }
	  return true;
	  
  }
  //</EHR>
  
  //inicio gmontoya PASE 176 P24 2015
  @Override
  public List<Map<String,Object>> obtenerCabeceraGarantia160(String numCtaCte){
	  return consultaCtaCteService.consCabeceraGarantia160(numCtaCte);	  
  }
  
  
  public List<Map<String,Object>> obtenerMovGarantia160(Map<String, Object> params){
	  return consultaCtaCteService.consMovGarantia160(params);	  
  }
  
  @Override
  public List<Map<String,Object>> obtenerGarantias159(String numDeclaracion, String codAduana,String codRegimen,String annPresen, String moneda){
	  return consultaCtaCteService.garantiasOperativas(numDeclaracion, codAduana, codRegimen, annPresen,moneda);	  
  }
// fin gmontoya PASE 176  P24 2015
  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerDeudaTributaria(Map<String, String> PkDocu)
      throws ServiceException
  {
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    List<Map<String, Object>> listaTributos = null;
    List<Map<String, Object>> listaTributosDev = null;
    List<Map<String, Object>> listaTributosFormatoCAntesDiligDestino = null;
    List<Map<String, Object>> listaPagos = null;
    String EstadoCan=" ";
    try
    {
      /*INICIO P46 - se modifico el metodo de tal manera que solo se muestren los registros que no estan anulados*/
      listaTributos = deudaDocumDAO.joinCabDeudaFindByDocumento(PkDocu);
      listaTributosDev = deudaDocumDAO.joinCabDeudaFindByDocumentoDam(PkDocu);
      listaTributosFormatoCAntesDiligDestino = deudaDocumDAO.joinCabDeudaFindByDocumento(PkDocu); //deudaDocumDAO.joinCabDeudafindByFormatoC(PkDocu);
      listaPagos = detPagoDuaDAO.findByDocumento(PkDocu);
      
    //Pase 176 estado de cancelacion de dua   Regimen 10    
      /*PAS20155E220000418 BUG 22488 se corrige ya que para invocacion en ConsultaTributoSerie.jsp 
       * metodo obtenerListaTributosPorSerie el mapa PkDocu solo tiene NUM_CORREDOC*/
      //if (PkDocu.get("COD_REGIMEN").toString().trim().equals("10"))
      if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(PkDocu.get("COD_REGIMEN")))
      { 
      	Map<String,Object> mapDua =null;		
		mapDua=consultaCtaCteService.obtenerTributosPorDoc( PkDocu.get("COD_ADUANA").toString().trim(), PkDocu.get("COD_REGIMEN").toString().trim(), "20"+PkDocu.get("ANN_PRESEN").toString().trim(),PkDocu.get("NUM_DECLARACION").toString().trim());
		if (mapDua!=null) 
		{
		 if (mapDua.get("TIPOCANCE").toString().equals("74"))
			 EstadoCan="GARANTIZADO ART. 160";
		 	
		 if (mapDua.get("TIPOCANCE").toString().equals("75"))
			 EstadoCan= "IMPUGNADO ART. 160";
		 
		 if (mapDua.get("TIPOCANCE").toString().equals("7"))
			 EstadoCan= "IMPUGNADA"; 
		}		
      }	
     mapResultado.put("TIPOCANCE", EstadoCan);
    // fin 176 estado de cancelacion de dua
    
      if(!CollectionUtils.isEmpty(listaTributos) && !CollectionUtils.isEmpty(listaPagos)){
    	  for(Map<String,Object> datoPago: listaPagos){
    		  boolean identDeudaAnulado = false;
    		  for(Map<String,Object> datoTributo: listaTributos){
    			  if(SunatStringUtils.isEqualTo(String.valueOf(ConstantesDataCatalogo.TIPO_CANCELACION_IMPUGNACION_SIN_GARANTIA_DONACION), datoPago.get("cod_tipcance").toString().trim())){
    				  identDeudaAnulado = true;
    				  if(SunatStringUtils.isEqualTo(datoPago.get("cod_identdeuda").toString().trim(), datoTributo.get("cod_identdeuda").toString().trim())){
    					  identDeudaAnulado = false;
    					  break;
            		  } 
    			  }        		  
        	  }
    		  if(identDeudaAnulado){
    			  datoPago.put("ind_elim", "1");
    		  }else{
    			  datoPago.put("ind_elim", "0");
    		  }
    		      		  
    		  Cambio1DAO cambio1DAO = ((Cambio1DAO) fabricaDeServicios.getService("declaracion.cambio1DAO.Def"));
    		  Map<String,Object> mapCambio1=new HashMap<String,Object>();
    		  Date  des_fec_pago=  SunatDateUtils.getDate((String)datoPago.get("des_fec_pago"));
    		 // String fechaPago = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(datoPago.get("des_fec_pago") != null ? des_fec_pago : new Date("01/01/0001"));    	   		  
    		  if( des_fec_pago!=null && !SunatDateUtils.sonIguales(des_fec_pago, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) {
    			  //String fechaString = new SimpleDateFormat("yyyymmdd").format(des_fec_pago);
    			  SimpleDateFormat formatoFechaTemp = new SimpleDateFormat("yyyyMMdd");
    				String strFecha= formatoFechaTemp.format(des_fec_pago).toString();
    				Integer fecsol = SunatNumberUtils.toInteger(strFecha);
    				
    			 //Integer fecha = SunatDateUtils.getIntegerFromDate(new FechaBean(fechaPago, "yyyyMMdd").getSQLDate());
    			  mapCambio1.put("fingreso", fecsol);
	    		  mapCambio1.put("cmoneda", DOLAR);
	    		  Cambio1 cambio1=cambio1DAO.findByPK(mapCambio1);
	    		  if(cambio1!=null){
		    		  BigDecimal pventa = (BigDecimal)cambio1.getPventa();
		    		  if(pventa!=null){
		    			  datoPago.put("pventaTipoCambio", pventa); 
		    		  }
	    		  }else{
	    			  datoPago.put("pventaTipoCambio",  BigDecimal.ZERO); 
	    		  }
    		  }
    	  }    	  
      }
      
      mapResultado.put("listaTributos", listaTributos);
      mapResultado.put("listaTributosFormatoCAntesDiligDestino", listaTributosFormatoCAntesDiligDestino);
      mapResultado.put("listaTributosDev", listaTributosDev);
      /*FIN P46*/
      
      mapResultado.put("listaPagos", listaPagos);
    }
    catch (DataAccessException e)
    {
      log.error(this.toString().concat(" obtenerDeudaTributaria- ERROR: ").concat(e.getMessage()));
      throw new ServiceException(e, e.getMessage());
    }
    catch (Exception e)
    {
      log.error(this.toString().concat(" obtenerDeudaTributaria- ERROR: ").concat(e.getMessage()));
      throw new ServiceException(e, e.getMessage());
    }

    return mapResultado;
  }

//MOL PASE280 
  public boolean esDuaCancelada(Map<String, Object> declaracion)
  {
	  boolean duaCancelado = true;
 
    DeudaDocum tmpDeudaDocum = new DeudaDocum();
    tmpDeudaDocum.setNumCorredoc(Long.valueOf(declaracion.get("NUM_CORREDOC").toString().trim()));
    List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
    for (DeudaDocum deudaDocum : lstDeudaDocum)
    {

      if (!deudaDocum.getCodEstpago().equals("P"))
      {    
    	  duaCancelado= false;
   
      }
    }
  
    return duaCancelado;
  }
  //FIN MOL
  /**
   * {@inheritDoc}
   */
  public String tieneDeudaPendiente(Map<String, Object> declaracion)
  {
    String msgDeudas = "";
    String deudaFormatoC = "";
    String deudaLCs = "";
    String deudaOtros = "";
    BigDecimal mtoDeuda = BigDecimal.ZERO;
    BigDecimal mtoPagado = BigDecimal.ZERO;
    BigDecimal mtoImpugnado = BigDecimal.ZERO;
    BigDecimal mtoGarantizado = BigDecimal.ZERO;
    BigDecimal mtoSaldo = BigDecimal.ZERO;
    DeudaDocum tmpDeudaDocum = new DeudaDocum();
    tmpDeudaDocum.setNumCorredoc(Long.valueOf(declaracion.get("NUM_CORREDOC").toString().trim()));
    List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
    List<Map<String, Object>> lstLCPendPago = soporteService.validarLCPendPago(declaracion);
    for (DeudaDocum deudaDocum : lstDeudaDocum)
    {
      mtoDeuda = deudaDocum.getMtoDeuda() == null ? BigDecimal.ZERO : deudaDocum.getMtoDeuda();
      mtoPagado = deudaDocum.getMtoPagado() == null ? BigDecimal.ZERO : deudaDocum.getMtoPagado();
      mtoImpugnado = deudaDocum.getMtoImpugna() == null ? BigDecimal.ZERO : deudaDocum.getMtoImpugna();
      mtoGarantizado = deudaDocum.getMtoGarant() == null ? BigDecimal.ZERO : deudaDocum.getMtoGarant();
      if (mtoPagado.add(mtoImpugnado.add(mtoGarantizado)).compareTo(mtoDeuda) < 0)
      { // Si hay deuda pendiente de pago
        mtoSaldo = mtoDeuda.subtract(mtoPagado.add(mtoImpugnado.add(mtoGarantizado)));
 //       if ("".equals(msgDeudas))
 //       {
 //         msgDeudas = "La DUA tiene la(s) siguiente(s) deuda(s) pendiente(s) de pago:\n";
 //       }
        if ("01".equals(deudaDocum.getCodTipdeuda()))
        {
          // Se remplaza porque el �ltimo es el que vale.
          deudaFormatoC = "Formato C (".concat("Monto: ").concat(mtoSaldo.toString()).concat(", CDA: ")
              .concat(deudaDocum.getNumCda()).concat(")").concat("\n");
        }
        else if ("02".equals(deudaDocum.getCodTipdeuda()))
        {
          deudaLCs = quitarLCPendPagoRepetidasParaMostrar(deudaDocum, mtoSaldo, deudaLCs, lstLCPendPago);
        }
        else
        {
          deudaOtros = deudaOtros.concat("Otra deuda (".concat("Monto: ").concat(mtoSaldo.toString()).concat(")")
              .concat("\n"));
        }
      }
    }
    //P46 EJHM para donaciones obviar las LC Pendientes de pago 00006 RLTIPLIQ pendiente
   if( Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals((String) declaracion.get("COD_REGIMEN"))  &&  Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracion.get("COD_TIPTRATMERC")) 
	 && declaracion.get("COD_INDICADOR_DONACION")!=null &&
	 (ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL.equals((String)declaracion.get("COD_INDICADOR_DONACION")) ||  ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL.equals( (String)declaracion.get("COD_INDICADOR_DONACION"))) ){
	   
	   for (Iterator it = lstLCPendPago.iterator(); it.hasNext();)
       {
         Map mapLCPendPago = (HashMap) it.next();
         if( ConstantesDataCatalogo.COD_DATCT_TIP_LIQ_TRIB_NO_IMPUGNADOS.equals(mapLCPendPago.get("RLTIPLIQ").toString())){
        	 it.remove();
		  }
		}
	 }
   // 
    String LCPendPago = mostrarLCPendPago(lstLCPendPago);
//pase280
   // if(!deudaFormatoC.equals("") || !deudaLCs.equals("") || !LCPendPago.equals("") || !deudaOtros.equals("") ){
    
    if(!deudaFormatoC.equals("") || !deudaLCs.equals("") || !deudaOtros.equals("") )  //PASE475
	{
    	   if ("".equals(msgDeudas))
           {
             msgDeudas = "La DUA tiene la(s) siguiente(s) deuda(s) pendiente(s) de pago:\n";
           }
    }
//fin pase280
    //return msgDeudas.concat(deudaFormatoC).concat(deudaLCs).concat(LCPendPago).concat(deudaOtros);

    return msgDeudas.concat(deudaFormatoC).concat(deudaLCs).concat(deudaOtros);  //PASE475
  }
/*RIN13FSW-INICIO*/
  public String tieneDeudaPendienteSinGarantia(Map<String, Object> declaracion)
  {
    String msgDeudas = "";
    String deudaFormatoC = "";
    String deudaLCs = "";
    String deudaOtros = "";
    BigDecimal mtoDeuda = BigDecimal.ZERO;
    BigDecimal mtoPagado = BigDecimal.ZERO;
    BigDecimal mtoImpugnado = BigDecimal.ZERO;
    BigDecimal mtoGarantizado = BigDecimal.ZERO;
    BigDecimal mtoSaldo = BigDecimal.ZERO;
    DeudaDocum tmpDeudaDocum = new DeudaDocum();
    tmpDeudaDocum.setNumCorredoc(Long.valueOf(declaracion.get("NUM_CORREDOC").toString().trim()));
    List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
    List<Map<String, Object>> lstLCPendPago = soporteService.validarLCPendPago(declaracion);
    for (DeudaDocum deudaDocum : lstDeudaDocum)
    {
      mtoDeuda = deudaDocum.getMtoDeuda() == null ? BigDecimal.ZERO : deudaDocum.getMtoDeuda();
      mtoPagado = deudaDocum.getMtoPagado() == null ? BigDecimal.ZERO : deudaDocum.getMtoPagado();
      mtoImpugnado = deudaDocum.getMtoImpugna() == null ? BigDecimal.ZERO : deudaDocum.getMtoImpugna();
      mtoGarantizado = deudaDocum.getMtoGarant() == null ? BigDecimal.ZERO : deudaDocum.getMtoGarant();
      if (mtoPagado.add(mtoImpugnado.add(new BigDecimal("0"))).compareTo(mtoDeuda) < 0){ // Si hay deuda pendiente de pago
        mtoSaldo = mtoDeuda.subtract(mtoPagado.add(mtoImpugnado.add(mtoGarantizado)));
        if ("".equals(msgDeudas)){
          msgDeudas = "La DUA tiene la(s) siguiente(s) deuda(s) pendiente(s) de pago:\n";
        }if ("01".equals(deudaDocum.getCodTipdeuda())){
          // Se remplaza porque el �ltimo es el que vale.
          deudaFormatoC = "Formato C (".concat("Monto: ").concat(mtoSaldo.toString()).concat(", CDA: ")
              .concat(deudaDocum.getNumCda()).concat(")").concat("\n");
        } else if ("02".equals(deudaDocum.getCodTipdeuda())){
          deudaLCs = quitarLCPendPagoRepetidasParaMostrar(deudaDocum, mtoSaldo, deudaLCs, lstLCPendPago);
        }else{
          deudaOtros = deudaOtros.concat("Otra deuda (".concat("Monto: ").concat(mtoSaldo.toString()).concat(")")
              .concat("\n"));
        }
      }
    }
    String LCPendPago = mostrarLCPendPago(lstLCPendPago);
    return msgDeudas.concat(deudaFormatoC).concat(deudaLCs).concat(LCPendPago).concat(deudaOtros);
  }
  /*RIN13FSW-FIN*/
  /**
   * {@inheritDoc}
   */
  /*INICIO PASE 475*/
  public  List<Map<String,Object>> tieneLCPendPagoAlertaBusqDiligencia(Map<String, Object> declaracion)
  {
    String msgDeudas = "";    
    String deudaLCs = "";    
    BigDecimal mtoDeuda = BigDecimal.ZERO;
    BigDecimal mtoPagado = BigDecimal.ZERO;
    BigDecimal mtoImpugnado = BigDecimal.ZERO;
    BigDecimal mtoGarantizado = BigDecimal.ZERO;
    BigDecimal mtoSaldo = BigDecimal.ZERO;
    DeudaDocum tmpDeudaDocum = new DeudaDocum();
    tmpDeudaDocum.setNumCorredoc(Long.valueOf(declaracion.get("NUM_CORREDOC").toString().trim()));
    //List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum); --se comenta por pase PAS20165E220200038
    List<Map<String, Object>> lstLCPendPago = soporteService.validarLCPendPago(declaracion);
    List<Map<String,Object>> listaLCPendPago = new ArrayList<Map<String,Object>>();
    //Se comenta por pase PAS20165E220200038
    /*
    for (DeudaDocum deudaDocum : lstDeudaDocum)
    {
      mtoDeuda = deudaDocum.getMtoDeuda() == null ? BigDecimal.ZERO : deudaDocum.getMtoDeuda();
      mtoPagado = deudaDocum.getMtoPagado() == null ? BigDecimal.ZERO : deudaDocum.getMtoPagado();
      mtoImpugnado = deudaDocum.getMtoImpugna() == null ? BigDecimal.ZERO : deudaDocum.getMtoImpugna();
      mtoGarantizado = deudaDocum.getMtoGarant() == null ? BigDecimal.ZERO : deudaDocum.getMtoGarant();
      if (mtoPagado.add(mtoImpugnado.add(mtoGarantizado)).compareTo(mtoDeuda) < 0)
      {
        if ("02".equals(deudaDocum.getCodTipdeuda()))
        {
          deudaLCs = quitarLCPendPagoRepetidasParaMostrar(deudaDocum, mtoSaldo, deudaLCs, lstLCPendPago);
        }
        
      }
    }
    */
    //P46 EJHM para donaciones obviar las LC Pendientes de pago 00006 RLTIPLIQ pendiente
   if( Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals((String) declaracion.get("COD_REGIMEN"))  &&  Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracion.get("COD_TIPTRATMERC")) 
	 && declaracion.get("COD_INDICADOR_DONACION")!=null &&
	 (ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL.equals((String)declaracion.get("COD_INDICADOR_DONACION")) ||  ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL.equals( (String)declaracion.get("COD_INDICADOR_DONACION"))) ){
	   
	   for (Iterator it = lstLCPendPago.iterator(); it.hasNext();)
       {
         Map mapLCPendPago = (HashMap) it.next();
         if( ConstantesDataCatalogo.COD_DATCT_TIP_LIQ_TRIB_NO_IMPUGNADOS.equals(mapLCPendPago.get("RLTIPLIQ").toString())){
        	 it.remove();
		  }
		}
	 }
   
   listaLCPendPago = listaLCPendPago(lstLCPendPago);    
   
    return listaLCPendPago;
  }
    /*FINAL PASE 475*/
  @Override
  public boolean tieneMontosLiquidadosParaDiligencia(String numCorreDoc, MovCabliqdilig movCabliqdilig)
  {
    String movTipDiligencia = movCabliqdilig.getCodTipdiligencia();
    String movNumreliq = movCabliqdilig.getNumReliq().toString();
    String movFechaLiquidacion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(movCabliqdilig.getFecLiquida());

    boolean bRspta = false;

    DeudaDocum tmpDeudaDocum = new DeudaDocum();
    tmpDeudaDocum.setNumCorredoc(Long.valueOf(numCorreDoc));
    List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
    for (DeudaDocum deudaDocum : lstDeudaDocum)
    {
      String deudaTipDiligencia = deudaDocum.getCodTipdiligencia() != null ? deudaDocum.getCodTipdiligencia() : "";
      String deudaFechaRegistro = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy)
          .format(deudaDocum.getFecRegis() != null ? deudaDocum.getFecRegis() : new Date("01/01/0001"));
      String deudaNumReliq = deudaDocum.getNumReliq().toString();
      if (movTipDiligencia.equals(deudaTipDiligencia) && movNumreliq.equals(deudaNumReliq)
          && movFechaLiquidacion.equals(deudaFechaRegistro))
      {
        bRspta = true;
        break;
      }
    }

    return bRspta;
  }

  private String quitarLCPendPagoRepetidasParaMostrar(
    DeudaDocum deudaDocum,
    BigDecimal mtoSaldo,
    String deudaLCs,
    List<Map<String, Object>> lstLCPendPago)
  {
    Map<String, Object> mapLCPendPagoEliminar = null;
    for (Map<String, Object> mapLCPendPago : lstLCPendPago)
    {
      String nroLiq = (String) mapLCPendPago.get("RLNROLIQ");
      if (nroLiq.equalsIgnoreCase(deudaDocum.getNumLiquida()))
      {
        mapLCPendPagoEliminar = mapLCPendPago;
        break;
      }
    }
    lstLCPendPago.remove(mapLCPendPagoEliminar);
    String LC = deudaDocum.getCodAduliquida().concat("-").concat(deudaDocum.getAnnLiquida().toString()).concat("-")
        .concat(deudaDocum.getNumLiquida());

    deudaLCs = deudaLCs.concat("LC: ").concat(LC).concat(" (Monto: ").concat(mtoSaldo.toString()).concat(", CDA: ")
        .concat(deudaDocum.getNumCda()).concat(")\n");
    return deudaLCs;
  }

  private String mostrarLCPendPago(List<Map<String, Object>> lstLCPendPago)
  {
    String LCPendPago = "";
    for (Map<String, Object> mapLCPendPago : lstLCPendPago)
    {
      String monto = mapLCPendPago.get("RLCODMON").toString().equals("D") ? mapLCPendPago.get("RLDMONTOT").toString(): mapLCPendPago.get("RLSMONTOT").toString();
      String LC = ((String) mapLCPendPago.get("RLADUANA")).concat("-").concat(((String) mapLCPendPago.get("RLANO"))).concat("-").concat(((String) mapLCPendPago.get("RLNROLIQ")));
      LCPendPago = LCPendPago.concat("LC: ").concat(LC).concat(" (Monto: ").concat(monto).concat(")\n");
    }
    return LCPendPago;
  }

  
  /*INICIO PASE475*/
  private  List<Map<String,Object>> listaLCPendPago(List<Map<String, Object>> lstLCPendPago)
  {
    String LCPendPago = "";
    List<Map<String,Object>> listaLCPendPago = new ArrayList<Map<String,Object>>();
    Map<String, Object> datosLCPendPago = null;
    
    for (Map<String, Object> mapLCPendPago : lstLCPendPago)
    {
      String monto = mapLCPendPago.get("RLCODMON").toString().equals("D") ? mapLCPendPago.get("RLDMONTOT").toString(): mapLCPendPago.get("RLSMONTOT").toString();
      String LC = ((String) mapLCPendPago.get("RLADUANA")).concat("-").concat(((String) mapLCPendPago.get("RLANO"))).concat("-").concat(((String) mapLCPendPago.get("RLNROLIQ")));
      LCPendPago = "LC: ".concat(LC).concat(" (Monto: ").concat(monto).concat(")").concat(" pendiente de pago");
      datosLCPendPago = new HashMap<String, Object>();
      datosLCPendPago.put("rlnroliq",(String) mapLCPendPago.get("RLNROLIQ"));
      datosLCPendPago.put("descripcion", LCPendPago);      
      listaLCPendPago.add(datosLCPendPago);
    }
    return listaLCPendPago;
  }
  
    /*FIN PASE475*/
  
	public List<Liquida> tieneLCPendientesPago(Map<String, Object> params) {
//		swapperDatasource.swap(fabricaDeServicios
//				.getService(Constantes.PREF_DATASOURCE_READ
//						+ params.get("COD_ADUANA").toString().trim()));
		//LRMZ RIN10
		LiquidaDAO liquidaDAO = ((LiquidaDAO) fabricaDeServicios.getService("recauda.liquidaciones"));
		DataSourceContextHolder.setKeyDataSource(params.get("COD_ADUANA").toString().trim());
	//	LiquidaDAO liquidaDAO = (LiquidaDAO) fabricaDeServicios
		//		.getService("recauda2.liquidaDAO");
		return liquidaDAO.selectMapSelectivo(params);
	}

  // INICIO RIN15
  public Map<String,Object> findFechaHoraCancelacionByNumCorreDoc (String numCorreDoc) {
	  return deudaDocumDAO.findFechaHoraCancelacionByNumCorreDoc(numCorreDoc);
  }
  // FIN RIN15  

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
    this.deudaDocumDAO = deudaDocumDAO;
  }

  /*jlunah*/
  public List<DetDeuda> obtenerTributosPorSerie(String numcorredoc, int identDeuda, String numserie){
	  
	  DetDeuda params = new DetDeuda();
	  List<DetDeuda> listaDetDeuda = new ArrayList<DetDeuda>();
	  params.setNumCorredoc(new Long(numcorredoc));
	  params.setNumIdentdeuda(identDeuda);
	  params.setNumSecserie(Integer.parseInt(numserie));	  
	  listaDetDeuda.addAll(detDeudaDAO.selectSelective(params));
	  
	  return listaDetDeuda;
	  
  }
  
  
  /**
   * RIN13 SWF
   * */
  	public Map<String, Object> obtenerListaTributosPorSerie(String numCorreDoc,String numeroSerie){
  		//INICIO P24 
  		Map<String, Object> mapDetalleDeuda = null;
	    Map<String, String> pkDocu = new HashMap<String, String>();
	    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
	    List<Map<String, String>> tributosConsiderados = obtenerTributosConsiderados();
	    
	    
//	    List <DetDeuda> listaTributosPorSerie = new ArrayList<DetDeuda>();
	    BigDecimal montoTotalLiquidacion = new BigDecimal(0);
	    BigDecimal montoTotalLiberacion = new BigDecimal(0);
	    BigDecimal montoTotalPagar = new BigDecimal(0);
	    
	    List<Map<String,Object>> tributosPorSerie = new ArrayList<Map<String,Object>>();//valor enviado
	    Map<String,Object> tributos = new HashMap<String, Object>();
	    tributos.put("ERROR", "");	    
	    pkDocu.put("NUM_CORREDOC", numCorreDoc);	  
	    //INICIO PASE 130 p24
        pkDocu.put("agregarCeros", "true");//PASE-130 p24
        
	    mapDetalleDeuda = obtenerDeudaTributaria(pkDocu);
	    listaTipoDeuda = getListTipoDeuda(mapDetalleDeuda);
	    List<Map<String, Object>> lstTributos = (List<Map<String, Object>>) mapDetalleDeuda.get("listaTributos");
	     
	    if (CollectionUtils.isEmpty(lstTributos) || CollectionUtils.isEmpty(listaTipoDeuda)) {
	    	tributos.put("ERROR", "No se encontraron tributos para la Serie.");
	    	return tributos;
	    }
	      
	    //Con los datos tal cual de la cabecera, busco su detalle	      
	    if(!CollectionUtils.isEmpty(lstTributos)){	    	
	    	List <DetDeuda> tmpListaTributosPorSerie = new ArrayList<DetDeuda>();	    	
	    	for(Map<String,Object> tributo : lstTributos){
	    		//busco deuda tributo por serie
	    		int identDeuda = Integer.valueOf(((BigDecimal) tributo.get("cod_identdeuda")).intValue());
	    		if(identDeuda>0) {
	    			tmpListaTributosPorSerie = obtenerTributosPorSerie(numCorreDoc, identDeuda, numeroSerie);
	    			break;
	    		}
	    	}
	    	  
	    	if(!CollectionUtils.isEmpty(tmpListaTributosPorSerie)||!CollectionUtils.isEmpty(lstTributos)){//p24 pase 130
	    		
				//Tributos Dolares
		        boolean madvDolares 	= false; //0001D
		        boolean mdesDolares 	= false; //0021D
		        boolean miscDolares 	= false; //0003D
		        boolean migvDolares 	= false; //0002D
		        boolean mipmDolares 	= false; //0014D
		        boolean madumDolares 	= false; //0050D
		        boolean msadDolares		= false; //0062D
		        	
				//boolean mtservDolares 	= false; //0007D
				//boolean mcommDolares 	= false; //0053D
				//boolean mipmaDolares 	= false; //0054D
				//boolean minteDolares 	= false; //0059D
				//		        	
	    		  
	    		for(DetDeuda datoDetDeuda : tmpListaTributosPorSerie){
	    		 
	    		  if(datoDetDeuda.getCodTributo().equals("0001")){//0001D - AD-VALOREM
		    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  
	    			  mapTributoPorSerie.put("codigo", "0001");
	    			  mapTributoPorSerie.put("concepto", "AD-VALOREM");
	    			  mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
	    			  mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
	    			  mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag());
	    			  
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  madvDolares = true;
	    			  
	    			  montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
	    			  montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
	    			  montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
	    			  
	    		  }
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0021")){//0021D - DERECHO ESPECIFICO

		    		Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
		    		mapTributoPorSerie.put("codigo", "0021");
		    		mapTributoPorSerie.put("concepto", "DERECHO ESPECIFICO");
		    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
		    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
		    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
		    		
		    		tributosPorSerie.add(mapTributoPorSerie);
		    		mdesDolares = true;
		    		
		    		  montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
	    			  montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
	    			  montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
		    			  
		    		}
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0003")){//0003D - IMP. SELECTIVO AL CONSUMO
		    			
		    			Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
			    		mapTributoPorSerie.put("codigo", "0003");
			    		mapTributoPorSerie.put("concepto", "IMP. SELECTIVO AL CONSUMO");
			    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
			    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
			    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
			    		
			    		tributosPorSerie.add(mapTributoPorSerie);
			    		miscDolares = true;

			    		montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
		    			montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
		    		    montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
			    		
			    		
		    		}
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0002")){//0002D - IMP. GENERAL A LAS VENTAS
		    			
		    			Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
			    		mapTributoPorSerie.put("codigo", "0002");
			    		mapTributoPorSerie.put("concepto", "IMP. GENERAL A LAS VENTAS");
			    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
			    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
			    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
			    		
			    		tributosPorSerie.add(mapTributoPorSerie);
			    		migvDolares = true;
			    		
			    		montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
		    			montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
		    		    montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
			    		
		    		}
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0014")){//0014D - IMP. PROMOCION MUNICIPAL
		    			
		    			Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
			    		mapTributoPorSerie.put("codigo", "0014");
			    		mapTributoPorSerie.put("concepto", "IMP. PROMOCION MUNICIPAL");
			    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
			    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
			    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
			    		
			    		tributosPorSerie.add(mapTributoPorSerie);
			    		mipmDolares = true;
			    		
			    		montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
		    			montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
		    		    montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
		    		}
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0050")){//0050D - DERECHO ANTIDUMPING
		    			
		    			Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
			    		mapTributoPorSerie.put("codigo", "0050");
			    		mapTributoPorSerie.put("concepto", "DERECHO ANTIDUMPING");
			    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
			    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
			    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
			    		
			    		tributosPorSerie.add(mapTributoPorSerie);
			    		madumDolares = true;
			    		
			    		montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
		    			montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
		    		    montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
		    		}
	    		  
	    		  else if(datoDetDeuda.getCodTributo().equals("0062")){//0062D	- SOBRETASA ADICIONAL	
		    			
		    			Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
		    			  
			    		mapTributoPorSerie.put("codigo", "0062");
			    		mapTributoPorSerie.put("concepto", "SOBRETASA ADICIONAL");
			    		mapTributoPorSerie.put("liquidacion", datoDetDeuda.getMtoValnorm());
			    		mapTributoPorSerie.put("liberacion", datoDetDeuda.getMtoValliber());
			    		mapTributoPorSerie.put("pagar", datoDetDeuda.getMtoValpag()); 
			    		
			    		tributosPorSerie.add(mapTributoPorSerie);
			    		msadDolares = true;
			    		
			    		montoTotalLiquidacion = SunatNumberUtils.sum(montoTotalLiquidacion, datoDetDeuda.getMtoValnorm());
		    			montoTotalLiberacion = SunatNumberUtils.sum(montoTotalLiberacion, datoDetDeuda.getMtoValliber());
		    		    montoTotalPagar = SunatNumberUtils.sum(montoTotalPagar, datoDetDeuda.getMtoValpag());
		    		}
		    		
	    		}
	    		
	    		//Para los tributos que no se agregaron
	    		
	    		BigDecimal cero = new BigDecimal("0.00");
	        	
	    		if(!madvDolares){//0001D - AD-VALOREM
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0001");
	    			  mapTributoPorSerie.put("concepto", "AD-VALOREM");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  
	    		}
	    		if(!mdesDolares){//0021D - DERECHO ESPECIFICO
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0021");
	    			  mapTributoPorSerie.put("concepto", "DERECHO ESPECIFICO");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			
	    		}
	    		if(!miscDolares){//0003D - IMP. SELECTIVO AL CONSUMO
	    			 
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0003");
	    			  mapTributoPorSerie.put("concepto", "IMP. SELECTIVO AL CONSUMO");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  
	    		}
	    		if(!migvDolares){//0002D - IMP. GENERAL A LAS VENTAS
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0002");
	    			  mapTributoPorSerie.put("concepto", "IMP. GENERAL A LAS VENTAS");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);	
	    			  
	    		}
	    		if(!mipmDolares){//0014D - IMP. PROMOCION MUNICIPAL
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0014");
	    			  mapTributoPorSerie.put("concepto", "IMP. PROMOCION MUNICIPAL");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  
	    		}
	    		if(!madumDolares){//0050D - DERECHO ANTIDUMPING
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0050");
	    			  mapTributoPorSerie.put("concepto", "DERECHO ANTIDUMPING");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  
	    		}
	    		if(!msadDolares){//0062D	- SOBRETASA ADICIONAL
	    			
	    			  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
	    			  mapTributoPorSerie.put("codigo", "0062");
	    			  mapTributoPorSerie.put("concepto", "SOBRETASA ADICIONAL");
	    			  mapTributoPorSerie.put("liquidacion", cero);
	    			  mapTributoPorSerie.put("liberacion", cero);
	    			  mapTributoPorSerie.put("pagar", cero);
	    			  tributosPorSerie.add(mapTributoPorSerie);
	    			  
	    		}
	    		
	    	  Map<String,Object> mapTributoPorSerie = new HashMap<String, Object>();
  			  mapTributoPorSerie.put("codigo", "");
  			  mapTributoPorSerie.put("concepto", "ultimoRegistro");
  			  mapTributoPorSerie.put("liquidacion", montoTotalLiquidacion);
  			  mapTributoPorSerie.put("liberacion", montoTotalLiberacion);
  			  mapTributoPorSerie.put("pagar", montoTotalPagar);
  			  tributosPorSerie.add(mapTributoPorSerie);
	    		
	    	  }
  
	      }
	      
	      tributos.put("lista", tributosPorSerie);
	      
	      //en caso listaTributosPorSerie este vacia devolver mensaje de error
	      if (CollectionUtils.isEmpty(tributosPorSerie))
	      {
	    	tributos.put("ERROR", "No se encontraron tributos para la Serie.");
	    	return tributos;
	      }
	     
	    return tributos;
  	}
  	
  	private void actualizarMontoTributo(List<Map<String, Object>> tributosPorSerie, DetDeuda datoDetDeuda) {
  		
  		for (Map<String, Object> tributoSerieDet : tributosPorSerie) {
			if(tributoSerieDet.get("codigo").equals(datoDetDeuda.getCodTributo())){
				tributoSerieDet.put("liquidacion", datoDetDeuda.getMtoValnorm());
				tributoSerieDet.put("liberacion", datoDetDeuda.getMtoValliber());
				tributoSerieDet.put("pagar", datoDetDeuda.getMtoValpag());
				break;
			}
		}	
  	}

	private List<Map<String, String>> obtenerTributosConsiderados() {
  		List<Map<String, String>> tributosConsiderados = new ArrayList<Map<String,String>>();
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MADV_DOLAR); put("DES_TRIBUTO", "AD-VALOREM");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MDES_DOLAR); put("DES_TRIBUTO", "DERECHO ESPECIFICO");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MISC_DOLAR); put("DES_TRIBUTO", "IMP. SELECTIVO AL CONSUMO");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MIGV_DOLAR); put("DES_TRIBUTO", "IMP. GENERAL A LAS VENTAS");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MIPM_DOLAR); put("DES_TRIBUTO", "IMP. PROMOCION MUNICIPAL");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MDER_ADUMP); put("DES_TRIBUTO", "DERECHO ANTIDUMPING");  }});
  		tributosConsiderados.add(new HashMap<String, String>(){{ put("COD_TRIBUTO", Constants.TRIBUTO_MSAD_DOLAR); put("DES_TRIBUTO", "SOBRETASA ADICIONAL");  }});
  		return tributosConsiderados;
  	}
  	
/*jlunah
   * Me devuelve una lista tipo map con los valores de la diferencia de tributos por serie
   * */
  public List<Map<String,Object>> obtenerListaDiferenciaTributosTodasLasSeries(String numCorredoc)  throws ServiceException{
	
	  List<Map<String,Object>> listaDifTributosSerie = new ArrayList<Map<String,Object>>();
	  Map <String,Object> deudaTributaria = new HashMap<String, Object>();
	  ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
	  
	  //Obtener deuda tributaria
	  Map <String,String> params = new HashMap<String, String>();
	  params.put("NUM_CORREDOC", numCorredoc);
	  deudaTributaria = obtenerDeudaTributaria(params);
	  
	  //Obtener Tipo deuda
	  listaTipoDeuda = getListTipoDeuda(deudaTributaria);
	  
	  if(deudaTributaria.isEmpty() || listaTipoDeuda.isEmpty()){
		  //RETORNAR ERROR = No se encontraron tributos para la Serie.;
		  return listaDifTributosSerie; /*retornamos la lista null*/
	  }
	  
	  List<Map<String, Object>> lstTributos = (List<Map<String, Object>>) deudaTributaria.get("listaTributos");
	  HashSet listIdentDeuda = new HashSet();
      if(!CollectionUtils.isEmpty(lstTributos)){
    	  for(Map <String, Object> datosTributo : lstTributos){
    		  log.debug("");
             if(!datosTributo.get("cod_estpago").equals("P") && datosTributo.get("cod_tipdeuda").equals("03")){ /*SI DEUDAS NO PAGADAS Y DE TIPO MULTA */
               	listIdentDeuda.add(datosTributo.get("cod_identdeuda"));
    	     }
    	  }
      }
      
      /*Obtengo en general la lista de tributos por serie*/
      List <DetDeuda> listaTributosSerie = new ArrayList<DetDeuda>();
      if(!listIdentDeuda.isEmpty()){
    	  int identDeuda ;
    	  for( Iterator it = listIdentDeuda.iterator(); it.hasNext();) {
    		  BigDecimal temporal = new BigDecimal(0);
    		  temporal = (BigDecimal) it.next();
    		  identDeuda = temporal.intValueExact();
		      List <DetDeuda> tmpListaTributos = obtenerTributosPorSerie(numCorredoc, identDeuda, null);
		      if(!tmpListaTributos.isEmpty()){
		    	  listaTributosSerie.addAll(tmpListaTributos);
		      }
    	  }
      }
      
       /*
        Si existen series repetidas, acumular los montos, 
        teniendo en cuenta separar los soles de los d�lares
       */
      HashSet Serie = new HashSet();
      for(DetDeuda tmpSerie : listaTributosSerie){
    	  Serie.add(tmpSerie.getNumSecserie());
      }
      
      if(!Serie.isEmpty()){
	      Integer codSerie ;
		  for( Iterator it = Serie.iterator(); it.hasNext();) {
			  Map <String,Object> mapSerie = new HashMap<String, Object>();
			  BigDecimal temporal = new BigDecimal(0);
			  temporal = (BigDecimal) it.next();
			  codSerie = temporal.intValueExact();
			  
			  BigDecimal montoDolares = new BigDecimal(0);//inicializo la variable que va acumular el monto en DOLARES de la deuda
			  BigDecimal montoSoles = new BigDecimal(0);//inicializo la variable que va acumular el monto en SOLES de la deuda
			  
			  for(DetDeuda tmpSerie : listaTributosSerie){
				  //OBTENGO LA MONEDA A LA QUE SE REFIERE LA DEUDA
				  DeudaDocum deudaDocum = new DeudaDocum();
				  deudaDocum.setNumCorredoc(tmpSerie.getNumCorredoc());
				  deudaDocum.setNumIdentdeuda(tmpSerie.getNumIdentdeuda());
				  DeudaDocum deuda = (DeudaDocum) deudaDocumDAO.selectByDocumento(deudaDocum);
				  String codigoMoneda = deuda.getCodMoneda();
				  
				  if(tmpSerie.getNumSecserie() == codSerie){
					 /*SEPARO POR MONEDAS*/
					 //DOLARES
					 if(codigoMoneda.equals("USD")){
						 montoDolares = SunatNumberUtils.sum(montoDolares, tmpSerie.getMtoValpag());
					 } 
					 //SOLES
					 if(codigoMoneda.equals("PEN")){
						 montoSoles = SunatNumberUtils.sum(montoSoles, tmpSerie.getMtoValpag());
					 }
				  }
			  }
			  mapSerie.put("serie", codSerie);
			  mapSerie.put("montoSoles", montoSoles);
			  mapSerie.put("montoDolares", montoDolares);
			  listaDifTributosSerie.add(mapSerie);
		  }
      }
      
	  return listaDifTributosSerie;
	  
  }
  /*jlunah*/
  
  
  /**
   * Metodo que nos permite obtener los tipos de deudas filtradas.
   *
   * @param mapa
   *          the mapa
   * @return the list tipo deuda
   */
  private ArrayList<Map<String, String>> getListTipoDeuda(Map<String, Object> mapa)
  {
    List<Map<String, Object>> listaTributos = (ArrayList<Map<String, Object>>) mapa.get("listaTributos");
    ArrayList<Map<String, String>> listaTipoDeuda = new ArrayList<Map<String, String>>();
    boolean banderaComparaTipoDeuda = false;
    for (int i = 0; i < listaTributos.size(); i++)
    {
      // no mostrar deudas de tipo 02 LC
      if (!((String) listaTributos.get(i).get("cod_tipdeuda")).equals("02"))
      {
        if (i == 0)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
          continue;
        }
        banderaComparaTipoDeuda = true;
        for (int j = 0; j < listaTipoDeuda.size(); j++)
        {
          if (listaTipoDeuda.get(j).get("cod_tipdeuda").equals((String) listaTributos.get(i).get("cod_tipdeuda")))
          {
            banderaComparaTipoDeuda = false;
            break;
          }
        }
        if (banderaComparaTipoDeuda)
        {
          Map<String, String> mapaDato = new HashMap<String, String>();
          mapaDato.put("cod_tipdeuda", (String) listaTributos.get(i).get("cod_tipdeuda"));
          mapaDato.put("des_tipdeuda", (String) listaTributos.get(i).get("des_tipodeuda"));
          listaTipoDeuda.add(mapaDato);
        }
      }
    }
    return listaTipoDeuda;
  }
  
  /**
   * RIN13 SWF
   * */
  public void generarDeudaAndPagosParaMulta(Map<String, Object> multa){
	  
		//generamos deuda
	  	DeudaDocum deudaDocumento = new DeudaDocum();
		
		String numCorredoc = (String) multa.get("NUM_CORREDOC");
		String tipoDiligencia = multa.get("COD_TIPDILIGENCIA").toString();
		BigDecimal montoMulta = (BigDecimal) multa.get("MTO_TOTALMULTA"); 
		BigDecimal annLiq = new BigDecimal(multa.get("ANN_LC").toString());
		/**inicio cambio 4 digitos para deuda_docum y det_pagodua, dos digitos se mantiene para LC pase 2015**/
		String annLiquidaDoc = multa.get("ANN_LC").toString().length()>2?multa.get("ANN_LC").toString(): ((new FechaBean()).getAnho()).toString().substring(0,2) + multa.get("ANN_LC").toString();/// 
    	BigDecimal annLiqDoc = new BigDecimal(annLiquidaDoc);
    	/**fin cambio pase 2015**/    	
		
//pase 42
	    Date fechaRegistro;
        fechaRegistro = new java.util.Date(new FechaBean().getSQLDate().getTime());//gc.getTime();
//pase 42 fin
        
		deudaDocumento.setNumCorredoc(Long.parseLong(numCorredoc));
		Integer ultimoIdentDeuda = deudaDocumDAO.obtMaxNroDeudaDocu(String.valueOf(numCorredoc));
		deudaDocumento.setNumIdentdeuda(ultimoIdentDeuda + 1);
		deudaDocumento.setNumReliq(0);
		deudaDocumento.setCodTipdeuda(Constantes.COD_TIPO_DEUDA_PARA_MULTA);
		deudaDocumento.setCodEstadmin(" ");
		deudaDocumento.setNumCda(" ");
		deudaDocumento.setCodEstpago("P");
		deudaDocumento.setMtoDeuda(montoMulta); 
		deudaDocumento.setMtoPagado(montoMulta);
		deudaDocumento.setMtoGarant(new BigDecimal(0));
		if(multa.get("MONEDA").equals("S")){
			deudaDocumento.setMtoDuasol(montoMulta.longValue());
			deudaDocumento.setCodMoneda("PEN");
		}else{
			deudaDocumento.setMtoDuadol(montoMulta.longValue());
			deudaDocumento.setCodMoneda("USD");
		}
		
		deudaDocumento.setFecVenc(fechaRegistro);
		deudaDocumento.setCodTipdiligencia(tipoDiligencia);
		//pase 42
		if(multa.get("NUM_CORREDOC_SOL") != null){
			deudaDocumento.setCodTipdiligencia(tipoDiligencia);
			deudaDocumento.setNumCorredocSol(Long.parseLong(multa.get("NUM_CORREDOC_SOL").toString()));
		}else{
			deudaDocumento.setNumCorredocSol(new Long("0"));	
		}
		//fin 42
		deudaDocumento.setAnnLiquida(annLiqDoc.intValue()); //cambio pase 2015
		deudaDocumento.setCodAduliquida(multa.get("COD_ADUANALC").toString());
		deudaDocumento.setNumLiquida(multa.get("NUM_LC").toString());
		deudaDocumDAO.insert(deudaDocumento);
		
		
		//generamos pagos
		DetPagodua documentoPago = new DetPagodua();
		documentoPago.setCodTipcance("2");
		documentoPago.setNumCorredoc(Long.parseLong(numCorredoc));
		documentoPago.setNumIdentdeuda(ultimoIdentDeuda + 1);
		documentoPago.setCodTipodocpag("03");//Autoliquidacion
		documentoPago.setCodAduliquida(multa.get("COD_ADUANALC").toString());
		documentoPago.setAnnLiquida(annLiqDoc.intValue()); //cambio pase 2015
		documentoPago.setNumLiquida(multa.get("NUM_LC").toString());

		documentoPago.setCodFormpago(" ");
		documentoPago.setMtoPagado(montoMulta);
		documentoPago.setFecPago(fechaRegistro);
		documentoPago.setCodBcopago(" ");
		
		if(multa.get("MONEDA").equals("S")){
			documentoPago.setCodMoneda("PEN");
		}else{
			documentoPago.setCodMoneda("USD");
		}
		documentoPago.setFecConta(new FechaBean("00010101", "yyyyMMdd").getSQLDate());
		documentoPago.setFecExtorno(new FechaBean("00010101", "yyyyMMdd").getSQLDate());

		detPagoDuaDAO.insert(documentoPago);
		
		//Pagamos la liquidacion
		String codAduana = multa.get("COD_ADUANALC").toString();

//		 amancilla Rin13FSW Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codAduana));

		//amancilla Rin13FSW LiquidaDAO liquidaDAO = (LiquidaDAO) fabricaDeServicios.getService("recauda2.liquidaDAO");
        LiquidaDAO liquidaDAO = (LiquidaDAO) fabricaDeServicios.getService("recaudacion2.liquidaDefDxdaen");

		//liquidaDAO.
		Liquida tmpLiquida=new Liquida();
		tmpLiquida.setRladuana(multa.get("COD_ADUANALC").toString());
		tmpLiquida.setRlnroliq(multa.get("NUM_LC").toString());
		tmpLiquida.setRlano(annLiq.toString());
		tmpLiquida.setRlcodest("P"); //Pagado
		//lalberti pase 42
		DataSourceContextHolder.setKeyDataSource(codAduana);
        swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codAduana));
        //fin lalberti pase 42
        //se comenta por bug 21658 pase 42
        //swapperDatasource.swap(fabricaDeServicios.getService("diligencia.ingreso.liquidaDef"+codAduana));	
		liquidaDAO.updateByPrimaryKeySelective(tmpLiquida);		
		// amancilla Rin13 FSW swapperDatasource.swap(o);
  }
  
  // FIN P24
	
	/*Inicio PAS20155E220200089*/
	/**
	 *Obtener el Nro de reliquidaci�n para tipo de deuda 01 para mostrar en el Nro. de la Declaraci�n
	 * */	
	public String obtenerNroDeReliqNumDeclaracion (Long numCorredoc) {		
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(numCorredoc);
		tmpDeudaDocum.setCodTipdeuda("01");	
		Integer numReliq = 0;		
		numReliq =deudaDocumDAO.selectMaxReliqNumDeclaracion(tmpDeudaDocum);
		return numReliq.toString();		
	}
	
	/*Fin PAS20155E220200089*/

	//PAS201830001100016 - mtorralba 20181120 - Para verificar si existen LCs pendientes de Pago


	//PAS201830001100016 - mtorralba 20181120 - Para verificar si existen LCs pendientes de Pago
	public String verificaLCPendientePago(String numcorredoc) {

		String mensaje = "";
		String LCs = "";
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(Long.valueOf(numcorredoc));
		tmpDeudaDocum.setCodTipdeuda("02");
		List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
		for (DeudaDocum deudaDocum : lstDeudaDocum) {
			if (!deudaDocum.getCodEstpago().equals("P")) {    
				LCs = "  *  ".concat(deudaDocum.getCodAduliquida()).concat("-").concat(deudaDocum.getAnnLiquida().toString().trim());
				LCs = LCs.concat("-").concat(deudaDocum.getNumLiquida());
				if( mensaje.equals("")) mensaje = "La declaraci�n tiene Liquidaciones de Cobranza Pendientes de Pago:";
				mensaje = mensaje.concat("\n").concat(LCs);
			}
		}
  
		return mensaje;
	}
	
	
//  public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO)
//  {
//    this.deudaDocumDAO = deudaDocumDAO;
//  }

	public void setDetPagoDuaDAO(DetPagoDuaDAO detPagoDuaDAO) {
    this.detPagoDuaDAO = detPagoDuaDAO;
  }

  // RIN13
public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
	this.indicadorDUADAO = indicadorDUADAO;
}

  

	public void setSoporteService(SoporteService soporteService) {
    this.soporteService = soporteService;
  }

  // RIN13
  public void setDetDeudaDAO(DetDeudaDAO detDeudaDAO) {
	this.detDeudaDAO = detDeudaDAO;
  }

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public ConsultaCtaCteService getConsultaCtaCteService() {
		return consultaCtaCteService;
	}
  
	public void setConsultaCtaCteService(ConsultaCtaCteService consultaCtaCteService) {
		this.consultaCtaCteService = consultaCtaCteService;
	}
}
