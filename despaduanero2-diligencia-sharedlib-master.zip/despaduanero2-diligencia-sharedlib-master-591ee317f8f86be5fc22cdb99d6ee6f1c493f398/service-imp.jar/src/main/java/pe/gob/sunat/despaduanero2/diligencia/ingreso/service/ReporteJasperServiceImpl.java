package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.jasperreports.JasperReportsHtmlView;
import org.springframework.web.servlet.view.jasperreports.JasperReportsPdfView;
import org.springframework.web.servlet.view.jasperreports.JasperReportsXlsView;
import pe.gob.sunat.framework.spring.util.lang.Numero;

public class ReporteJasperServiceImpl  implements ReporteJasperService
{
	protected final Log log = LogFactory.getLog(getClass());
	private Properties diligenciaIngresoProperties;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ModelAndView generarPdf(Map configData, Collection fieldData, Map paramData, ApplicationContext appContext)
	{
		Map model = new HashMap();
		paramData.put("SUBREPORT_DIR", this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper"));
		model.putAll(paramData);
		model.put("fieldData", fieldData);

		JasperReportsPdfView pdf = new JasperReportsPdfView();
		Map parameters = new HashMap();
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
		if (configData.containsKey("metadata_asunto")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_SUBJECT", configData.get("metadata_asunto"));
		}
		if (configData.containsKey("metadata_titulo")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_TITLE", configData.get("metadata_titulo"));
		}
		pdf.setExporterParameters(parameters);
		
		pdf.setUrl(this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper") + this.diligenciaIngresoProperties.getProperty("diligencia.jasperPattern") + Numero.format(configData.get("plantillaID"), "000000") + ".jasper");
		pdf.setApplicationContext(appContext);

		if ((configData.containsKey("attachment")) && (((Boolean)configData.get("attachment")).booleanValue())) {
			Properties p = new Properties();
			p.put("Content-Disposition", "attachment; filename=" + configData.get("filename"));
			pdf.setHeaders(p);
		} else if (configData.containsKey("filename")) {
			Properties p = new Properties();
			p.put("Content-Disposition", "inline; filename=" + configData.get("filename"));
			pdf.setHeaders(p);
		}

		if (this.log.isDebugEnabled()) this.log.debug(pdf.getExporterParameters());

		return new ModelAndView(pdf, model);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ModelAndView generarExcel(Map configData, Collection fieldData, Map paramData, ApplicationContext appContext)
	{
		Map model = new HashMap();
		paramData.put("SUBREPORT_DIR", this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper"));
		model.putAll(paramData);
		model.put("fieldData", fieldData);
		JasperReportsXlsView excel = new JasperReportsXlsView();
		Map parameters = new HashMap();
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
		if (configData.containsKey("metadata_asunto")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_SUBJECT", configData.get("metadata_asunto"));
		}
		if (configData.containsKey("metadata_titulo")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_TITLE", configData.get("metadata_titulo"));
		}

		excel.setExporterParameters(parameters);
		excel.setUrl(this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper") + this.diligenciaIngresoProperties.getProperty("diligencia.jasperPattern") + Numero.format(configData.get("plantillaID"), "000000") + ".jasper");
		excel.setApplicationContext(appContext);
		if ((configData.containsKey("attachment")) && (((Boolean)configData.get("attachment")).booleanValue())) {
			Properties p = new Properties();
			p.put("Content-Disposition", "attachment; filename=" + configData.get("filename"));
			excel.setHeaders(p);
		} else if (configData.containsKey("filename")) {
			Properties p = new Properties();
			p.put("Content-Disposition", "inline; filename=" + configData.get("filename"));
			excel.setHeaders(p);
		}
		if (this.log.isDebugEnabled()) this.log.debug(excel.getExporterParameters());
		return new ModelAndView(excel, model);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public File generarReportePdf(InputStream jasper, Map configData, Collection fieldData, Map paramData)
			throws Exception{

		Map parameters = new HashMap();
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
		parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
		if (this.log.isDebugEnabled()) this.log.debug("jasper=" + jasper);
		if (this.log.isDebugEnabled()) this.log.debug("configData=" + configData);
		if (this.log.isDebugEnabled()) this.log.debug("fieldData=" + fieldData);
		if (this.log.isDebugEnabled()) this.log.debug("paramData" + paramData);

		if (configData.containsKey("metadata_asunto")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_SUBJECT", configData.get("metadata_asunto"));
		}
		if (configData.containsKey("metadata_titulo")) {
			parameters.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_TITLE", configData.get("metadata_titulo"));
		}

		JasperPrint print = JasperFillManager.fillReport(jasper, paramData, new JRBeanCollectionDataSource(fieldData));
		if (this.log.isDebugEnabled()) this.log.debug("print=" + print);
		JRPdfExporter exporter = new JRPdfExporter();
		if (this.log.isDebugEnabled()) this.log.debug("exporter=" + exporter);
		exporter.setParameters(parameters);
		if (this.log.isDebugEnabled()) this.log.debug("parameters=" + parameters);
		if (this.log.isDebugEnabled()) this.log.debug("exporter=" + exporter);
		if (this.log.isDebugEnabled()) this.log.debug("RutaArchivo" + this.diligenciaIngresoProperties.getProperty("pdfDirectory") + configData.get("nombre_archivo"));
		if (this.log.isDebugEnabled()) this.log.debug("JRExporterParameter.JASPER_PRINT=" + JRExporterParameter.JASPER_PRINT);
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);

		exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, this.diligenciaIngresoProperties.getProperty("pdfDirectory") + configData.get("nombre_archivo"));
		if (this.log.isDebugEnabled()) this.log.debug("exporter=" + exporter);
		exporter.exportReport();

		return new File(this.diligenciaIngresoProperties.getProperty("pdfDirectory") + configData.get("nombre_archivo"));
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ModelAndView generarHtml(Map configData, Collection fieldData, Map paramData, ApplicationContext appContext)
	{
		Map model = new HashMap();
		paramData.put("SUBREPORT_DIR", this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper"));
		model.putAll(paramData);
		model.put("fieldData", fieldData);

		JasperReportsHtmlView html = new JasperReportsHtmlView();
		Map parameters = new HashMap();
		if (configData.containsKey("IS_USING_IMAGES_TO_ALIGN")) {
			parameters.put("net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN", configData.get("IS_USING_IMAGES_TO_ALIGN"));
		}
		if (configData.containsKey("IGNORE_PAGE_MARGINS")) {
			parameters.put("net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IGNORE_PAGE_MARGINS", configData.get("IGNORE_PAGE_MARGINS"));
		}
		if (configData.containsKey("CHARACTER_ENCODING")) {
			parameters.put("net.sf.jasperreports.engine.export.JRHtmlExporterParameter.CHARACTER_ENCODING", configData.get("CHARACTER_ENCODING"));
		}
		html.setExporterParameters(parameters);
		html.setUrl(this.diligenciaIngresoProperties.getProperty("diligencia.file")+this.diligenciaIngresoProperties.getProperty("diligencia.rutaPlantillaJasper") + this.diligenciaIngresoProperties.getProperty("diligencia.jasperPattern") + Numero.format(configData.get("plantillaID"), "000000") + ".jasper");
		html.setApplicationContext(appContext);

		if ((configData.containsKey("attachment")) && (((Boolean)configData.get("attachment")).booleanValue())) {
			Properties p = new Properties();
			p.put("Content-Disposition", "attachment; filename=" + configData.get("filename"));
			html.setHeaders(p);
		} else if (configData.containsKey("filename")) {
			Properties p = new Properties();
			p.put("Content-Disposition", "inline; filename=" + configData.get("filename"));
			html.setHeaders(p);
		}

		if (this.log.isDebugEnabled()) this.log.debug(html.getExporterParameters());

		return new ModelAndView(html, model);
	}

	public void setDiligenciaIngresoProperties(
			Properties diligenciaIngresoProperties) {
		this.diligenciaIngresoProperties = diligenciaIngresoProperties;
	}
	
	
	
}