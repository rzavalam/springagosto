package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.NandTasa;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFOBSeriesTipSeguro2PorDocTransporteBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.SumaFleteYPesoPorDocTransporteBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades.*;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.*;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;



/**
 * Esta Clase contiene la logica de calculo de los datos de la declaracion,
 * serie, formato A y B.
 *
 * @author amancillaa
 * @version 1.0 26/02/2013
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DeclaracionCalculoDeDatosServiceImpl implements DeclaracionCalculoDeDatosService
{

    protected final Log log = LogFactory.getLog(this.getClass());
    private SoporteService soporteService;

    /**
     * *METODOS PUBLICO DEL CALCULO Y PRORRATEO DEL SEGURO *.
     *
     * @param codTipSegSerie
     *          [String] cod tip seg serie
     * @param mtoFobDolSerie
     *          [BigDecimal] mto fob dol serie
     * @param mtoAjusteSerie
     *          [BigDecimal] mto ajuste serie
     * @param numPartNandiSerie
     *          [Long] num part nandi serie
     * @param fechaVigenciaPartida
     *          [Date] fecha vigencia partida
     * @param mtoTotFobDolDua
     *          [BigDecimal] mto tot fob dol dua
     * @param mtoTotSegDolDua
     *          [BigDecimal] mto tot seg dol dua
     * @return [BigDecimal] big decimal
     * @author amancillaa
     * @version 1.0
     */

    /**
     * {@inheritDoc}
     */
  public BigDecimal calcularMtoSeguroDeLaSerie(String codTipSegSerie,
                                               BigDecimal mtoFobDolSerie,
                                               BigDecimal mtoAjusteSerie,
                                               Long numPartNandiSerie,
                                               Date fechaVigenciaPartida,
                                               BigDecimal mtoTotFobDolDua,
                                               BigDecimal mtoTotSegDolDua)
  {
    BigDecimal newMtoSeguro = new BigDecimal(0);

    TipoSeguro tipoSeguro = TipoSeguro.getTipoSeguro(codTipSegSerie);

    switch (tipoSeguro)
    {
    case NO_ASEGURADO:
      newMtoSeguro = calcularMtoSeguroDeLaSerieTipo1(mtoFobDolSerie,
                                                     mtoAjusteSerie,
                                                     numPartNandiSerie,
                                                     fechaVigenciaPartida);
      break;
    case SEGURO_INDIVIDUAL:
      newMtoSeguro = calcularMtoSeguroDeLaSerieTipo2y3(mtoFobDolSerie,
                                                       mtoAjusteSerie,
                                                       mtoTotFobDolDua,
                                                       mtoTotSegDolDua);
      break;
    case SEGURO_FLOTANTE:
      newMtoSeguro = calcularMtoSeguroDeLaSerieTipo2y3(mtoFobDolSerie,
                                                       mtoAjusteSerie,
                                                       mtoTotFobDolDua,
                                                       mtoTotSegDolDua);
      break;
    }

    return newMtoSeguro;
  }


  /**
   * {@inheritDoc}
   */
  public BigDecimal calcularMtoSeguroDeLaSerieTipo1(BigDecimal mtoFobDolSerie,
                                                    BigDecimal mtoAjusteSerie,
                                                    Long numPartNandiSerie,
                                                    Date fechaVigenciaPartida)
  {
    BigDecimal newMtoSeguro = new BigDecimal(0);
    NandTasa nandTasa =
                        soporteService.obtenerTasaNandinaByPartida(COD_ADUANA_CENTRAL, numPartNandiSerie,
                                                                   fechaVigenciaPartida);
    if (nandTasa != null && nandTasa.getTseguro() != null)
    {
      BigDecimal mtoFobAjustado = SunatNumberUtils.sum(mtoFobDolSerie, mtoAjusteSerie);
      BigDecimal divisor = new BigDecimal(100);
      BigDecimal tasa = nandTasa.getTseguro();
      newMtoSeguro = SunatNumberUtils.divide(SunatNumberUtils.multiply(mtoFobAjustado, tasa), divisor, 3);
    }

    return newMtoSeguro;
  }

  /**
   * {@inheritDoc}
   */
  public BigDecimal calcularMtoSeguroDeLaSerieTipo2y3(BigDecimal mtoFobDolSerie,
                                                      BigDecimal mtoAjusteSerie,
                                                      BigDecimal mtoTotFobDolDua,
                                                      BigDecimal mtoTotSegDolDua)
  {

    BigDecimal newMtoSeguro = new BigDecimal(0);

    if (mtoTotFobDolDua.compareTo(BigDecimal.ZERO) > 0)
    {
      //segun coordinacion con normativa tipo 2 y 3 se quita mtoAjustado
      //BigDecimal mtoFobAjustadoSerie = SunatNumberUtils.sum(mtoFobDolSerie, mtoAjusteSerie);
      BigDecimal mtoFobAjustadoSerie = mtoFobDolSerie;
      BigDecimal dividendo = SunatNumberUtils.multiply(mtoTotSegDolDua, mtoFobAjustadoSerie);
      newMtoSeguro = SunatNumberUtils.divide(dividendo, mtoTotFobDolDua, 3);

    }

    return newMtoSeguro;
  }


  public BigDecimal calcularMtoValorAduana(BigDecimal mto_fobdol,
                                                      BigDecimal mto_fletedol,
                                                      BigDecimal mto_segdol,
                                                      BigDecimal mto_ajuste,
                                                      BigDecimal mto_ajuste_otr)
  {



    BigDecimal bgFobSerie = BigDecimal.ZERO;
    BigDecimal bgSeguroSerie = BigDecimal.ZERO;
    BigDecimal bgFleteSerie = BigDecimal.ZERO;
    BigDecimal bgAjusteSerie = BigDecimal.ZERO;
    BigDecimal bgOtroAjusteSerie = BigDecimal.ZERO;
    BigDecimal bgAduanaSerie = BigDecimal.ZERO;

    bgFobSerie.add(mto_fobdol);
    bgSeguroSerie.add(mto_segdol);
    bgFleteSerie.add(mto_fletedol);
    bgAjusteSerie.add(mto_ajuste);
    bgOtroAjusteSerie.add(mto_ajuste_otr);

    bgAduanaSerie = bgFobSerie.add(bgSeguroSerie).add(bgFleteSerie).add(bgAjusteSerie).add(bgOtroAjusteSerie);



    return bgAduanaSerie;
  }


  /**
   * {@inheritDoc}
   */
  public List prorratearMtoSeguroEnLasSeries(BigDecimal mtoSeguroProrratear,
                                             BigDecimal mtoTotalFOBDolDeLaDeclaracion,
                                             Date fechaVigenciaPartida,
                                             List lstSeries)
  {

    // invocado desde itemfactura se debe de reconstrir el monto
    if (mtoSeguroProrratear.compareTo(BigDecimal.ZERO) == 0)
    {
      return lstSeries;
    }

    List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
    listaSerieEliminada = Utilidades.obtenerRegistrosMarcadoParaEliminar(lstSeries);

    lstSeries = quitarRegistrosMarcadaParaEliminar(lstSeries);

    // 1calculamos el flete tipo1 de todas las series
    lstSeries = calcularTipoSeguro1(fechaVigenciaPartida, lstSeries);

    // sumamos el flete tipo 1 4 y 9 de todas las series
    MultiValueMap filtros = new MultiValueMap();
    filtros.put("COD_TIPSEG", "1");
    filtros.put("COD_TIPSEG", "4");
    filtros.put("COD_TIPSEG", "9");

    BigDecimal mtoSeguroSeriesTipo1_4_9 = sumarPorCampoFiltradoORCriterios(lstSeries, "MTO_SEGDOL", filtros);
    BigDecimal mtoFobSeriesTipo1_4_9 = sumarPorCampoFiltradoORCriterios(lstSeries, "MTO_FOBDOL", filtros);

    if (mtoSeguroProrratear.compareTo(mtoSeguroSeriesTipo1_4_9) > 0)
    {

      // prorratea para todos los casos y se deja la validacion cuando se valida
      // el total de las series con los datos de la cabecera
      mtoSeguroProrratear = mtoSeguroProrratear.subtract(mtoSeguroSeriesTipo1_4_9);
      mtoTotalFOBDolDeLaDeclaracion = mtoTotalFOBDolDeLaDeclaracion.subtract(mtoFobSeriesTipo1_4_9);
      // prorrateamos la diferencia para los tipos 2 y 3
      lstSeries = calcularTipoSeguro2y3(
                                        mtoSeguroProrratear,
                                        mtoTotalFOBDolDeLaDeclaracion,
                                        lstSeries);

    }

    lstSeries = Utilidades.reponeRegistrosMarcadosParaEliminar(listaSerieEliminada,lstSeries,"NUM_SECSERIE");

    return lstSeries;
  }


  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> prorratearMtoSeguroDesdeItemsFactura(List lstSeries,
                                                                        Date fechaVigenciaPartida)
  {

	List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();
	listaSerieEliminada = Utilidades.obtenerRegistrosMarcadoParaEliminar(lstSeries);

    // invocado desde itemfactura se debe de reconstrir el monto
    lstSeries = quitarRegistrosMarcadaParaEliminar(lstSeries);

    // 1calculamos el flete tipo1 de todas las series
    lstSeries = calcularTipoSeguro1(fechaVigenciaPartida, lstSeries);

    // aqui ya este considerando los montos actualizados del tipo de seguro 1
    BigDecimal newMtoTotalFOBDolSumaSeries = Utilidades.sumarPorCampo(lstSeries, "MTO_FOBDOL");
    BigDecimal newMtoSeguroProrratearSumaSeries = Utilidades.sumarPorCampo(lstSeries, "MTO_SEGDOL");

    // sumamos el flete tipo 1 4 y 9 de todas las series
    MultiValueMap filtros = new MultiValueMap();

    filtros.put("COD_TIPSEG", "1");
    filtros.put("COD_TIPSEG", "4");
    filtros.put("COD_TIPSEG", "9");

    BigDecimal mtoSeguroSeriesTipo1_4_9 = sumarPorCampoFiltradoORCriterios(lstSeries, "MTO_SEGDOL", filtros);
    BigDecimal mtoFobSeriesTipo1_4_9    = sumarPorCampoFiltradoORCriterios(lstSeries, "MTO_FOBDOL", filtros);

    newMtoSeguroProrratearSumaSeries = newMtoSeguroProrratearSumaSeries.subtract(mtoSeguroSeriesTipo1_4_9);

    newMtoTotalFOBDolSumaSeries = newMtoTotalFOBDolSumaSeries.subtract(mtoFobSeriesTipo1_4_9);
    // prorrateamos la diferencia para los tipos 2 y 3
    // newMtoSeguroProrratearSumaSeries para el caso del seguro no se resta los
    // tipo 1 si no que se suman
    lstSeries = calcularTipoSeguro2y3(newMtoSeguroProrratearSumaSeries,
                                      newMtoTotalFOBDolSumaSeries,
                                      lstSeries);

    lstSeries = Utilidades.reponeRegistrosMarcadosParaEliminar(listaSerieEliminada,lstSeries,"NUM_SECSERIE");

    return lstSeries;
  }

    /**
     * *FIN-METODOS PUBLICO DEL CALCULO Y PRORRATEO DEL SEGURO *.
     *
     * @param lstDetDeclara
     *          [List] lst det declara
     * @param lstSumaFleteYPesoPorDocTransporte
     *          [List<SumaFleteYPesoPorDocTransporteBean>] lst suma flete y peso
     *          por doc transporte
     * @return [List] list
     * @author amancillaa
     * @version 1.0
     */

    /***INICIO-METODOS PUBLICO DEL CALCULO Y PRORRATEO DEL FLETE **/

  /**
   * {@inheritDoc}
   */
  public List prorratearFlete(List lstDetDeclara,
                              List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte)
  {

    if (!CollectionUtils.isEmpty(lstSumaFleteYPesoPorDocTransporte))
    {
      if (log.isDebugEnabled())
      {
        log.debug(this.toString().concat("|Se procedera a quitar para el proceso las series marcadas para eliminar"));
      }

      List<Map<String, Object>> listaSerieEliminada = new ArrayList<Map<String, Object>>();

      for (Map detDeclaraMap : (List<Map>) lstDetDeclara)
      {
    	boolean esParaEliminar = esUnaRegistroMarcadaParaEliminar(detDeclaraMap);
        if (esParaEliminar)
        {
          listaSerieEliminada.add(detDeclaraMap);
        }
      }

      for (Map filaRemover : listaSerieEliminada)
      {
        lstDetDeclara.remove(filaRemover);
      }

      if (log.isDebugEnabled())
      {
        log.debug(this.toString()
                      .concat("|quitadas del proceso prorrateo de flete:")
                      .concat(SojoUtil.toJson(listaSerieEliminada)));
      }

      if (!CollectionUtils.isEmpty(lstDetDeclara))
      {
        List<SumaFleteYPesoPorDocTransporteBean> tablaFletePesosPorBL;
        List<SumaFOBSeriesTipSeguro2PorDocTransporteBean> tablaFOBPorBL;
        // List<SeriesParaProrratearBean> tablafleteProrrateado;

        tablaFletePesosPorBL = obtenerTablaDeFleteYPesosPorBL(lstDetDeclara, lstSumaFleteYPesoPorDocTransporte);
        tablaFOBPorBL = obtenertablaFOBPorBL(lstDetDeclara, lstSumaFleteYPesoPorDocTransporte);
        lstDetDeclara = prorratearFlete(lstDetDeclara, tablaFletePesosPorBL, tablaFOBPorBL);
      }

      // se reponen las series eliminadas y setea valores por defecto de FLETE
      for (Map<String, Object> mapEliminar : listaSerieEliminada)
      {
      	if(mapEliminar.get("IND_DEL").toString().equals("1")){

    	  mapEliminar.put("MTO_FLETEDOL", 0);
      	}  
        lstDetDeclara.add(mapEliminar);
      }
      if (!CollectionUtils.isEmpty(listaSerieEliminada))
      {
        Ordenador.sortDesc(lstDetDeclara, "NUM_SECSERIE", Ordenador.ASC);
      }

      if (log.isDebugEnabled())
      {
        log.debug(this.toString()
                      .concat("|Se ponen las serie quitadas del proceso prorrateo de flete:")
                      .concat(SojoUtil.toJson(lstDetDeclara)));
      }
    }

    return lstDetDeclara;
  }


  /**
   * {@inheritDoc}
   */
  public List prorratearFlete(List lstDetDeclara) throws Exception
  {

    List<SumaFleteYPesoPorDocTransporteBean> lstRespuesta = obtenerDocTransporteAProrratear(lstDetDeclara);

    for (SumaFleteYPesoPorDocTransporteBean registro : lstRespuesta)
    {
      registro.setSumaFleteAProrratear(registro.getSumaFleteInicial());
    }

    return prorratearFlete(lstDetDeclara, lstRespuesta);
  }

  /**
   * {@inheritDoc}
   *
   * @throws Exception
   */
  public List<SumaFleteYPesoPorDocTransporteBean> obtenerDocTransporteAProrratear
      (List<Map> lstDetDeclara) throws Exception
  {
	List<Map> lstDetDeclara_aux = new ArrayList<Map>(lstDetDeclara);
	lstDetDeclara_aux = quitarRegistrosMarcadaParaEliminar(lstDetDeclara_aux);
    List<SumaFleteYPesoPorDocTransporteBean> lstRespuesta = new ArrayList<SumaFleteYPesoPorDocTransporteBean>();

   // String docTransporteUnico = "";
    SumaFleteYPesoPorDocTransporteBean sumaFleteYPesoPorDocTransporte;
    BigDecimal sumaFleteInicial = BigDecimal.ZERO;

    List<String> lstDocTransporteMarcados = new ArrayList<String>();

    for (Map serie : lstDetDeclara_aux)
    {
      String docTransporteSerie = serie.get("NUM_DOCTRANSP").toString();

      if (!lstDocTransporteMarcados.contains(docTransporteSerie))
      {
        lstDocTransporteMarcados.add(docTransporteSerie);
        sumaFleteYPesoPorDocTransporte = new SumaFleteYPesoPorDocTransporteBean();
        sumaFleteYPesoPorDocTransporte.setDocTransporte(docTransporteSerie);

        List<Map<String, Object>> lstDetDeclara2 = new ArrayList(lstDetDeclara_aux);

        Map filtros = new HashMap();
        filtros.put("NUM_DOCTRANSP", docTransporteSerie);

        sumaFleteInicial = Utilidades.sumarPorCampoFiltradoANDCriterios(lstDetDeclara2, "MTO_FLETEDOL", filtros);
        sumaFleteYPesoPorDocTransporte.setSumaFleteInicial(sumaFleteInicial);
        sumaFleteYPesoPorDocTransporte.setSumaFleteAProrratear(sumaFleteInicial);

        lstRespuesta.add(sumaFleteYPesoPorDocTransporte);
      }
    }

    return lstRespuesta;
  }


  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDocTransporteAProrratearDesdeSeries(List<Map> lstDetDeclara)
                                                                                                      throws Exception
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
    Map dato;
    List<SumaFleteYPesoPorDocTransporteBean> lstRespuesta = obtenerDocTransporteAProrratear(lstDetDeclara);

    for (SumaFleteYPesoPorDocTransporteBean registro : lstRespuesta)
    {

      dato = new HashMap();
      dato.put("docTransporte", registro.getDocTransporte());
      dato.put("sumaFleteInicial", registro.getSumaFleteInicial());
      dato.put("sumaFleteAProrratear", registro.getSumaFleteInicial());
      lstRspta.add(dato);
    }

    return lstRspta;
  }


  /**
   * Calcular tipo seguro2y3.
   *
   * @param mtoSeguroProrratear
   *          [BigDecimal] mto seguro prorratear
   * @param mtoTotalFOBDolDeLaDeclaracion
   *          [BigDecimal] mto total fob dol de la declaracion
   * @param lstSeries
   *          [List<Map>] lst series
   * @return [List<Map>] list
   * @author amancillaa
   * @version 1.0
   */
  private List<Map> calcularTipoSeguro2y3(BigDecimal mtoSeguroProrratear,
                                          BigDecimal mtoTotalFOBDolDeLaDeclaracion,
                                          List<Map> lstSeries){
    for (Map serie : lstSeries){
      String codTipSegSerie = serie.get("COD_TIPSEG").toString();
      String[] arrayTipoSeguro = { "2", "3" };
      if (Arrays.asList(arrayTipoSeguro).contains(codTipSegSerie)){
        BigDecimal mtoFobDolSerie = toBigDecimal(serie.get("MTO_FOBDOL").toString());
        BigDecimal mtoAjusteSerie = toBigDecimal(serie.get("MTO_AJUSTE").toString());
        if (!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(serie.get("IND_PRORRATEO")),"1")){	
	        BigDecimal NewMtoFobDolSerie = calcularMtoSeguroDeLaSerieTipo2y3(mtoFobDolSerie,mtoAjusteSerie,mtoTotalFOBDolDeLaDeclaracion,mtoSeguroProrratear);	
	        serie.put("MTO_SEGDOL", NewMtoFobDolSerie);
        }
      }
    }

    return lstSeries;
  }



  /**
   * Calcular tipo seguro1.
   *
   * @param fechaVigenciaPartida
   *          [Date] fecha vigencia partida
   * @param lstSeries
   *          [List<Map>] lst series
   * @return [List<Map>] list
   * @author amancillaa
   * @version 1.0
   */
  private List<Map> calcularTipoSeguro1(Date fechaVigenciaPartida,
                                        List<Map> lstSeries)
  {
    for (Map serie : lstSeries)
    {

      String codTipSegSerie = serie.get("COD_TIPSEG").toString();

      if ("1".equals(codTipSegSerie))
      {

        BigDecimal mtoFobDolSerie = toBigDecimal(serie.get("MTO_FOBDOL").toString());
        BigDecimal mtoAjusteSerie = toBigDecimal(serie.get("MTO_AJUSTE").toString());
        Long numPartNandiSerie = toLong(serie.get("NUM_PARTNANDI"));

        BigDecimal NewMtoFobDolSerie = calcularMtoSeguroDeLaSerieTipo1(mtoFobDolSerie,
                                                                       mtoAjusteSerie,
                                                                       numPartNandiSerie,
                                                                       fechaVigenciaPartida);

        serie.put("MTO_SEGDOL", NewMtoFobDolSerie);
      }

    }

    return lstSeries;
  }


  /**
   * Obtenertabla fob por bl.
   *
   * @param lstDetDeclara
   *          [List] lst det declara
   * @param lstSumaFleteYPesoPorDocTransporte
   *          [List<SumaFleteYPesoPorDocTransporteBean>] lst suma flete y peso
   *          por doc transporte
   * @return [List<SumaFOBSeriesTipSeguro2PorDocTransporteBean>] list
   * @author amancillaa
   * @version 1.0
   */
  private List<SumaFOBSeriesTipSeguro2PorDocTransporteBean>
      obtenertablaFOBPorBL(List lstDetDeclara,
                           List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte)
  {

    List<SumaFOBSeriesTipSeguro2PorDocTransporteBean> lstRspta = new ArrayList();
    SumaFOBSeriesTipSeguro2PorDocTransporteBean sumaFOB;
    String docTransporte;
    Map<String, Object> filtros;
    for (SumaFleteYPesoPorDocTransporteBean fila : lstSumaFleteYPesoPorDocTransporte)
    {

      docTransporte = fila.getDocTransporte();
      filtros = new HashMap<String, Object>();
      filtros.put("NUM_DOCTRANSP", docTransporte);
      filtros.put("COD_TIPFLETE", "2");
      BigDecimal sumaFOBTipo2 = Utilidades.sumarPorCampoFiltradoANDCriterios(lstDetDeclara, "MTO_FOBDOL", filtros);

      sumaFOB = new SumaFOBSeriesTipSeguro2PorDocTransporteBean();
      sumaFOB.setDocTransporte(docTransporte);
      sumaFOB.setSumaFOB(sumaFOBTipo2);
      lstRspta.add(sumaFOB);
    }

    return lstRspta;
  }

  /**
   * Obtener tabla de flete y pesos por bl.
   *
   * @param lstDetDeclara
   *          [List] lst det declara
   * @param lstSumaFleteYPesoPorDocTransporte
   *          [List<SumaFleteYPesoPorDocTransporteBean>] lst suma flete y peso
   *          por doc transporte
   * @return [List<SumaFleteYPesoPorDocTransporteBean>] list
   * @author amancillaa
   * @version 1.0
   */
  private List<SumaFleteYPesoPorDocTransporteBean>
      obtenerTablaDeFleteYPesosPorBL(List lstDetDeclara,
                                     List<SumaFleteYPesoPorDocTransporteBean> lstSumaFleteYPesoPorDocTransporte)
  {

    Map<String, Object> filtros;
    for (SumaFleteYPesoPorDocTransporteBean fila : lstSumaFleteYPesoPorDocTransporte)
    {

      filtros = new HashMap<String, Object>();
      filtros.put("NUM_DOCTRANSP", fila.getDocTransporte());

      BigDecimal sumaPesoBrutoTipoFlete2Y3 = Utilidades.sumarPorCampoFiltradoANDCriterios(lstDetDeclara,
          "CNT_PESO_BRUTO", filtros);
      filtros.put("COD_TIPFLETE", "1");
      BigDecimal sumaPesoBrutoFleteTipo1 = Utilidades.sumarPorCampoFiltradoANDCriterios(lstDetDeclara,
          "CNT_PESO_BRUTO", filtros);
      BigDecimal sumaFleteTipo1 = Utilidades.sumarPorCampoFiltradoANDCriterios(lstDetDeclara, "MTO_FLETEDOL", filtros);


      fila.setSumaPesoBruto(sumaPesoBrutoTipoFlete2Y3.subtract(sumaPesoBrutoFleteTipo1));
      BigDecimal sumaFleteAProrratear = fila.getSumaFleteAProrratear();
      fila.setSumaFleteRealProrratear(sumaFleteAProrratear.subtract(sumaFleteTipo1));
    }

    return lstSumaFleteYPesoPorDocTransporte;
  }


  /**
   * Prorratear flete.
   *
   * @param lstDetDeclara
   *          [List<Map>] lst det declara
   * @param tablaFletePesosPorBL
   *          [List<SumaFleteYPesoPorDocTransporteBean>] tabla flete pesos por
   *          bl
   * @param tablaFOBPorBL
   *          [List<SumaFOBSeriesTipSeguro2PorDocTransporteBean>] tabla fob por
   *          bl
   * @return [List] list
   * @author amancillaa
   * @version 1.0
   */
  private List prorratearFlete(List<Map> lstDetDeclara,
                               List<SumaFleteYPesoPorDocTransporteBean> tablaFletePesosPorBL,
                               List<SumaFOBSeriesTipSeguro2PorDocTransporteBean> tablaFOBPorBL)
  {

    BigDecimal mtoFleteProrrateado = BigDecimal.ZERO;
    BigDecimal mtoDividendo        = BigDecimal.ZERO;
    BigDecimal mtoDivisor          = BigDecimal.ZERO;
    BigDecimal mtoFleteRealProrratear = BigDecimal.ZERO;
    BigDecimal sumaFleteTipo3 = BigDecimal.ZERO;


    for (SumaFleteYPesoPorDocTransporteBean filatablaFletePesosPorBL : tablaFletePesosPorBL)
    {
      if (filatablaFletePesosPorBL.getSumaFleteRealProrratear().compareTo(BigDecimal.ZERO) > 0)
      {
        for (Map serie : lstDetDeclara)
        {
          if (filatablaFletePesosPorBL.getDocTransporte().equals(serie.get("NUM_DOCTRANSP").toString())
              && serie.get("COD_TIPFLETE").equals("3"))
          {

            mtoDivisor = filatablaFletePesosPorBL.getSumaPesoBruto();
            mtoFleteRealProrratear = filatablaFletePesosPorBL.getSumaFleteRealProrratear();
            mtoDividendo =mtoFleteRealProrratear.setScale(3)
                                                 .multiply(Utilidades.toBigDecimal(serie.get("CNT_PESO_BRUTO")));

            mtoFleteProrrateado = mtoDividendo.divide(mtoDivisor, 3, BigDecimal.ROUND_HALF_DOWN);

            serie.put("MTO_FLETEDOL", mtoFleteProrrateado);
            sumaFleteTipo3 = filatablaFletePesosPorBL.getSumaFleteTipo3();
            filatablaFletePesosPorBL.setSumaFleteTipo3(sumaFleteTipo3.setScale(3).add(mtoFleteProrrateado));
          }
        }

        mtoFleteRealProrratear = filatablaFletePesosPorBL.getSumaFleteRealProrratear();
        sumaFleteTipo3         = filatablaFletePesosPorBL.getSumaFleteTipo3();

        filatablaFletePesosPorBL.setSumaFleteRealProrratear(mtoFleteRealProrratear.setScale(3).subtract(sumaFleteTipo3));

        for (Map serie : lstDetDeclara)
        {

          if (filatablaFletePesosPorBL.getDocTransporte().equals(serie.get("NUM_DOCTRANSP").toString())
              && serie.get("COD_TIPFLETE").equals("2"))
          {

            for (SumaFOBSeriesTipSeguro2PorDocTransporteBean filatablaFOBPorBL : tablaFOBPorBL)
            {
              if (filatablaFOBPorBL.getDocTransporte().equals(serie.get("NUM_DOCTRANSP").toString()))
              {
                mtoDivisor = filatablaFOBPorBL.getSumaFOB();
              }
            }

            mtoFleteRealProrratear = filatablaFletePesosPorBL.getSumaFleteRealProrratear();
            mtoDividendo = mtoFleteRealProrratear.setScale(3)
                                                 .multiply(Utilidades.toBigDecimal(serie.get("MTO_FOBDOL")));

            mtoFleteProrrateado = mtoDividendo.divide(mtoDivisor, 3, BigDecimal.ROUND_HALF_DOWN);
            //Por SAU20153D211200040 se ha comentado la validacion de la diferencia de 0.02 para colocar el nuevo prorrateo del flete
            //SAU20153K004000299
       	   //BigDecimal diferencia = SunatNumberUtils.diference(mtoFleteProrrateado,(BigDecimal)SunatNumberUtils.toBigDecimal(serie.get("MTO_FLETEDOL")));
       	   //if(Math.abs(diferencia.doubleValue())>ConstantesTipoCatalogo.DIFERENCIA_MINIMA){
       		   serie.put("MTO_FLETEDOL", mtoFleteProrrateado);
       	   //  }
            

          }
        }
      }
    }

    return lstDetDeclara;
  }

  /******************** SET AND GET FOR SPRING-FRAMEWROK ***************************/

  public void setSoporteService(SoporteService soporteService)
  {

    this.soporteService = soporteService;
  }

}
