package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.CollectionUtil.esVacio;
import static pe.gob.sunat.despaduanero2.asignacion.util.Constantes.ESTADO_REVISION_ASIGNADO;
import static pe.gob.sunat.despaduanero2.asignacion.util.Constantes.ESTADO_REVISION_ELIMINADO_REASIGNACION;
import static pe.gob.sunat.despaduanero2.asignacion.util.Constantes.COD_TIPO_ASIGNACION_REASIGNADO;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.CatEmpleadoDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionManualService;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService; //RMC RIN-P47
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional.ValidadorValorProvisionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ConsultaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
//RIN16
//import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.sigad.ingreso.service.ControlarSaldoReposicionService;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.CollectionUtil.*;


/**
 * The Class SolicitudServiceImpl.
 *
 * @author rmontesc, rdelosreyes, wmostacero, lsuclupe
 */
@SuppressWarnings({ "rawtypes","unchecked" })
public class SolicitudServiceImpl implements SolicitudService
{

  protected final Log          log        = LogFactory.getLog(this.getClass());


  private DetAutorizacionDAO   detAutorizacionDAO;

  private IndicadorDUADAO      indicadorDuaDAO;

  private EspeDocuDAO          espeDocuDAO;

  private CabSolrectiDAO       cabSolrectiDAO;

  private RelacionDocDAO       relacionDocDAO;

  private CabDiligenciaDAO     cabDiligenciaDAO;

  private ConsultaDAO          consultaDAO;

  private CatEmpleadoDAO       catEmpleadoDAO;

  private DocAutAsociadoDAO    docAutAsociadoDAO;

  private CabDeclaraDAO        cabDeclaraDAO;

  /* olunar 309 */
  private ParticipanteDocDAO   participanteDocDAO;
  /* fin */

  private static final Integer CODIGO_PLANTILLA_AVISO_ELECTRONICO_RECONOCIMIENTO_FISICO_OFICIO = 121;

  private static final String  CODIGO_AVISO_ELECTRONICO                                        = "0";

  private static final String  USUARIO_INTERNO                                                 = "3";

  private static final String  JEFE_RFISICO                                                    = "JEFE.GRUPO.RECONOCIMIENTO.FISICO";

  private static final String  JEFE_RFISICO_IMPORTACION                                        = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.IMPORTACION";

  private static final String  JEFE_RFISICO_ADMISION_TEMPORAL                                  = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.ADMISION.TEM";

  private static final String  JEFE_RFISICO_DEPOSITO                                           = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.DEPOSITO";

  private static final String  REGIMEN_IMPORTACION_DEFINITIVA                                  = "10";

  private static final String  REGIMEN_DEPOSITO_ADUANERO                                       = "70";

  private static final String  REGIMEN_ADMISION_TEMPORAL_DE_PERFECCIONAMIENTO_ACTIVO           = "21";

  private static final String  REGIMEN_ADMISION_TEMPORAL_PARA_REEXPORTACION_EN_EL_MISMO_ESTADO = "20";

  /* olunar 309 */
  public static final String ASUNTO_PL_NOTI_REM_REC_FISICO = "Aviso de Remisi�n de DUA canal naranja a Reconocimiento F�sico";
  
  public static final String ASUNTO_PL_NOTI_RECHAZA_REM_REC_FISICO = "Aviso Denegatorio de la Solicitud de Reconocimiento F�sico";
  
  private PublicacionAvisoService publicacionAvisoService;
  
  private CatalogoAyudaService catalogoAyudaService;

  private AsignacionManualService asignacionManualService;
  /* fin */
  
  private DiligenciaService    diligenciaService;

  private FabricaDeServicios   fabricaDeServicios;
  
  // hosoriov rin 12
  private AsignacionService asignacionService;
  
  //INCIO RIN10-FSW AFMA
  private ValidadorValorProvisionalService valorProvisionalService;

  public void setValorProvisionalService(ValidadorValorProvisionalService valorProvisionalService)
  {
    this.valorProvisionalService = valorProvisionalService;
  }
  //Fin RIN10

/**
   * Obtener jefes.
   * TODO: revisar no tiene metodo en la intefaz
   *
   * @param params
   *          the params
   * @return the list
   */
  public List<Map<String, Object>> obtenerJefes(Map<String, Object> params)
  {

    List<Map<String, Object>> listaJefes = null;

    AduanaRol aduanaRol = fabricaDeServicios.getService("tecnologia.menu.intranet.aduanaRolService");

    try
    {
      if (REGIMEN_IMPORTACION_DEFINITIVA.equals(params.get("cod_regimen").toString().trim()))
      {
        listaJefes = aduanaRol.getEmpleados(params.get("cod_aduana").toString(), JEFE_RFISICO_IMPORTACION);
      }
      else if (REGIMEN_DEPOSITO_ADUANERO.equals(params.get("cod_regimen").toString().trim()))
      {
        listaJefes = aduanaRol.getEmpleados(params.get("cod_aduana").toString(), JEFE_RFISICO_DEPOSITO);
      }
      else if (REGIMEN_ADMISION_TEMPORAL_DE_PERFECCIONAMIENTO_ACTIVO.equals(params.get("cod_regimen").toString()
          .trim())
          || REGIMEN_ADMISION_TEMPORAL_PARA_REEXPORTACION_EN_EL_MISMO_ESTADO.equals(params.get("cod_regimen")
              .toString().trim()))
      {
        listaJefes = aduanaRol.getEmpleados(params.get("cod_aduana").toString(), JEFE_RFISICO_ADMISION_TEMPORAL);
      }
      if (listaJefes == null || listaJefes.size() == 0)
      {
        listaJefes = aduanaRol.getEmpleados(params.get("cod_aduana").toString(), JEFE_RFISICO);
        if (listaJefes == null || listaJefes.size() == 0)
        {
          log.error("NO SE ENCONTRARON JEFES PARA ENVIO DE AVISO ELECTRONICO PARA RECONOCIMIENTO FISICO DE OFICIO ");
        }
      }
    }

    catch (Exception e)
    {
      log.error(e);
      log.error("NO SE PUDO OBTENER LISTA DE JEFES PARA AVISO ELECTRONICO PARA RECONOCIMIENTO FISICO DE OFICIO");
    }
    return listaJefes;
  }

  /**
   * {@inheritDoc}
   */
  public void reasignarDocumentos(Map<String, Object> params) throws ServiceException
  {
    params.put("fec_actest", new java.util.Date());
    params.put("cod_estrev", "04");// El despachador no se presento
    params.put("cod_estrev_ant", "06");// estado anterior
    params.put("cod_funcionario", params.get("cod_funcionario"));

    espeDocuDAO.updateEstadoRevision(params);
    Integer numVeces = espeDocuDAO.findNumVecesNoSePresentoByDocumentoAndEstRev(params);
    if (numVeces >= 3)
    {
      params.put("cod_tiporegistro", "A");
      params.put("cod_indicador", "01");
      Map<String, Object> mapaIndicador = indicadorDuaDAO.findByDocumentoAndValor(params);
      if (mapaIndicador == null)
      {
        indicadorDuaDAO.insertIndicador(params);
      }

      List<Map<String, Object>> listaJefes = null;
      listaJefes = obtenerJefes(params);
      if (listaJefes != null && listaJefes.size() != 0)
      {

        for (int i = 0; i < listaJefes.size(); i++)
        {

          diligenciaService.notificarObservacion(
              null,
                params.get("cod_aduana").toString(),
                params.get("ann_presen").toString(),
                params.get("cod_regimen").toString(),
                params.get("num_declaracion").toString(),
                params.get("cod_funcionario").toString(),
                new String[]
                { listaJefes.get(i).get("cod_pers").toString() },
                CODIGO_PLANTILLA_AVISO_ELECTRONICO_RECONOCIMIENTO_FISICO_OFICIO,
                CODIGO_AVISO_ELECTRONICO,
                USUARIO_INTERNO,
                "");

        }

      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDocAutorizaSerie(Map<String, String> pkDocu) throws ServiceException
  {
    List<Map<String, Object>> lista = null;
    try
    {
      lista = detAutorizacionDAO.joinDetAutorizacionFindBySerie(pkDocu);
    }
    catch (Exception e)
    {
      log.error(this.toString() + " obtenerDocAutorizaSerie- ERROR: " + e.getMessage());
      throw new ServiceException(this, e);
    }
    return lista;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerDocAutoriza(Map<String, String> pkDocu) throws ServiceException
  {
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    Map<String, String> params = new HashMap<String, String>();
    try
    {
      params.put("NUM_CORREDOC", pkDocu.get("NUM_CORREDOC").toString().trim());
      params.put("fortipoopedif", pkDocu.get("fortipoopedif"));
      params.put("COD_TIPOPER", pkDocu.get("COD_TIPOPER"));
      mapResultado.put("lstDocAutAsociado", docAutAsociadoDAO.select(params));
      mapResultado.put("lstDetAutorizacion", detAutorizacionDAO.select(params));
    }
    catch (Exception e)
    {
      throw new ServiceException(e, e.getMessage());
    }
    return mapResultado;
  }
  //inicio gmontoya P24
  public Map<String, Object> obtenerDocDUAOtros(Map<String, Object> pkDocu) throws ServiceException
  {
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    Map<String, Object> params = new HashMap<String, Object>();
    try
    {
      params.put("NUM_CORREDOC", pkDocu.get("NUM_CORREDOC").toString().trim());
      params.put("LISTA_COD_TIPOPER", pkDocu.get("listaCodTipOper"));
      mapResultado.put("lstDocAutAsociado", docAutAsociadoDAO.selectDocDUAOtros(params));
    }
    catch (Exception e)
    {
      throw new ServiceException(e, e.getMessage());
    }
    return mapResultado;
  }
//fin gmontoya P24
  /**
   * {@inheritDoc}
   */
  public void updateEstadoCabSolRecti(Map<String, Object> params) throws ServiceException
  {
   this.cabSolrectiDAO.updateEstado(params);
  }

  /**
   * {@inheritDoc}
   */
  public boolean regularizacionDentroDelPlazo(Map<String, Object> params) throws ServiceException
  {
    boolean res = true;
    try
    {
      String num_corredoc_pre = this.relacionDocDAO.findNumCorreDocPreByDocumento(params).toString();
      params.put("NUM_CORREDOC_PRE", num_corredoc_pre != null ? num_corredoc_pre : "");
    }
    catch (Exception e)
    {
      throw new ServiceException(this, e);
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> validarDeclaConSolicitudXEspecialista(Map<String, Object> params) throws ServiceException
  {
    try
    {
      Map<String, Object> mapRes = new HashMap<String, Object>();
      Map<String, Object> mapSol = cabDiligenciaDAO.tieneSolicitudesXEspecialista(params);

      if (mapSol == null)
      {
        mapRes.put("COD_TIPDILIGENCIA", "NO_FOUND");
      }
      else if (mapSol.size() == 0)
      {
        mapRes.put("COD_TIPDILIGENCIA", "NO_FOUND");
      }
      else
      {
        mapRes = mapSol;
      }
      return mapRes;
    }
    catch (Exception e)
    {
      throw new ServiceException(this, e);
    }

  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> registrarRespuestaSolEspecialista(Map<String, Object> params) throws ServiceException
  {
    try
    {
      Map<String, Object> mapRes = new HashMap<String, Object>();
      int rowUpdate = consultaDAO.update(params);
      if (params.get("COD_TIPDILIGENCIA").equals(Constantes.SOLI_AMPLI_PLAZO))
      {
        cabDiligenciaDAO.update(params);
        // Para el cabdeclara solo se actualiza la nueva fecha de conclusi�n
        Map<String, Object> paramDeclara = new HashMap<String, Object>();
        paramDeclara.put("NUM_CORREDOC", params.get("NUM_CORREDOC"));
        paramDeclara.put("FEC_CONCLUSION", params.get("FEC_CONCLUSION"));
        this.cabDeclaraDAO.update(paramDeclara);
      }
      else
      {
        params.put("num_corredoc", params.get("NUM_CORREDOC"));
        params.put("cod_tiporegistro", "P"); // P:Portal del especialista
        params.put("cod_indicador", "08");
        indicadorDuaDAO.insertIndicador(params);
      }
      mapRes.put("RESPUESTA", rowUpdate);
      return mapRes;
    }
    catch (Exception e)
    {
      throw new ServiceException(this, e);
    }
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, CatEmpleado> buscarMapCatEmpleado(FiltroCatEmpleado filtro)
  {
    return catEmpleadoDAO.buscarMapCatEmpleado(filtro);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> buscarRectiyReguPend(Long numCorreDoc) throws ServiceException
  {
    List<Map<String, Object>> res = new ArrayList<Map<String, Object>>();
    try
    {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("NUM_CORREDOC", numCorreDoc);
      res = this.cabSolrectiDAO.findRectiyReguPend(params);

    }
    catch (Exception e)
    {
      throw new ServiceException(this, e);
    }
    return res;
  }


  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> getReasignaciones(Long numCorreDoc)
  {
    List<Map<String, Object>> lstAsignaciones = null;
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", numCorreDoc);
    lstAsignaciones = espeDocuDAO.findDuaReasignaciones(params);
    if (lstAsignaciones != null)
    {
      for (Map<String, Object> asignacion : lstAsignaciones)
      {
        String codPers = (String) asignacion.get("COD_FUNCIONARIO");
        asignacion.put("catEmpleado", getFuncionarioByCodPers(codPers));
      }
    }
    return lstAsignaciones;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> getReguAsignaciones(Long numCorreDoc, String tipoAsig)
  {
    List<Map<String, Object>> lstAsignaciones = null;
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", numCorreDoc);
    params.put("COD_TIPASIG", tipoAsig);
    lstAsignaciones = espeDocuDAO.findReguAsignaciones(params);
    if (lstAsignaciones != null)
    {
      for (Map<String, Object> asignacion : lstAsignaciones)
      {
        String codPers = (String) asignacion.get("COD_FUNCIONARIO");
        asignacion.put("catEmpleado", getFuncionarioByCodPers(codPers));
      }
    }
    return lstAsignaciones;
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> getDuayReguAsignaciones(Long numCorreDoc)
  {
    List<Map<String, Object>> lstAsignaciones = null;
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", numCorreDoc);
    lstAsignaciones = espeDocuDAO.findDuayReguAsignaciones(params);
    if (lstAsignaciones != null)
    {
      for (Map<String, Object> asignacion : lstAsignaciones)
      {
        String codPers = (String) asignacion.get("COD_FUNCIONARIO");
        asignacion.put("catEmpleado", getFuncionarioByCodPers(codPers));
      }
    }
    return lstAsignaciones;
  }

  /**
   * Gets the funcionario by cod pers.
   *
   * @param codFuncionario
   *          the cod funcionario
   * @return the funcionario by cod pers
   */
  public CatEmpleado getFuncionarioByCodPers(String codFuncionario)
  {
    FiltroCatEmpleado filtroCatEmpleado = new FiltroCatEmpleado();
    filtroCatEmpleado.setCodPers(codFuncionario);
    return catEmpleadoDAO.consultarCatEmpleado(filtroCatEmpleado);
  }




  /**
   * {@inheritDoc}
   *
   * Obtenedio de
   * Clase Valrecti.java
   * metodo Solrectieneval
   * TODO: refactorizar junto con numeracion
   * @author amancillaa
   */
  public Boolean tieneSolicitudRegularizacionPendienteEvaluar(String numCorreDocDua,
                                                              String codRegimenDua) throws ServiceException
  {

    Map mapWhere = new HashMap();

    mapWhere.put("numcorredocpre", numCorreDocDua);
    mapWhere.put("codTipoSolicitud", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
    mapWhere.put("estadosrecti",
                 new String[] { ConstantesDataCatalogo.COD_EST_REGULA_RECEPCIONADA
                     , ConstantesDataCatalogo.COD_EST_REGULA_ASIGNADA_ESPEC
                 });
    mapWhere.put("codtransaccion",
                 new String[] {
                     ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO,
                     SunatStringUtils.toNotNull(codRegimenDua)
                                     .concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO),
                     ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE,
                     SunatStringUtils.toNotNull(codRegimenDua)
                                     .concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE) });

    List<Map<String, Object>> lstSolEvalu = cabSolrectiDAO.listByDocumentoByParameterMap(mapWhere);

    return esVacio(lstSolEvalu) ? false : true;

  }
  
  public List<Map<String, Object>> obtenerSolicitudRegularizacionUrgente(String numCorreDoc){
	  Map<String, Object> mapWhere = new HashMap<String, Object>();
	  mapWhere.put("numcorredocpre", numCorreDoc);
	  mapWhere.put("codTipoSolicitud", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
	  mapWhere.put("codTransaccion", ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE);
	  return cabSolrectiDAO.listByDocumentoByParameterMap(mapWhere);
  }
  
  

	/* olunar - 309 */
	@Override
	public void grabarAceptacionSolicitudReconFisico(DUA dua, Consulta consulta) throws ServiceException {
		try {
			// Actualizar consulta
			consulta.setIndicadorRespuesta("1");
			Date fechaRespuesta = new Date();
			Timestamp fechahoy = new Timestamp(fechaRespuesta.getTime());
			consulta.setFechaRespuesta(fechahoy);
			this.consultaDAO.update(consulta);
			
			// Insertar indicador dua
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("num_corredoc", consulta.getNumcorredoc());
			param.put("cod_tiporegistro", Constantes.IND_DUA_P_ESP);
			param.put("cod_indicador", "08");
			int existeIndicador = ((BigDecimal) this.indicadorDuaDAO.existsIndicadorByDocumentoAndCodigo(param).get("CANT")).intValue();
			if (existeIndicador==0)
				this.indicadorDuaDAO.insertIndicador(param);
			else 
			{
				Map<String, Object> paramInd = new HashMap<String, Object>();
				paramInd.put("numCorredoc", param.get("num_corredoc"));
				paramInd.put("codIndicador", param.get("cod_indicador"));
				paramInd.put("codTiporegistro", param.get("cod_tiporegistro"));
				paramInd.put("indActivo", "1");
				this.indicadorDuaDAO.update(paramInd);
			}			

			// Actualizar diligencia
			Map<String, Object> paramDilig = new HashMap<String, Object>();
			paramDilig.put("NUM_CORREDOC", consulta.getNumcorredoc());
			paramDilig.put("COD_TIPDILIGENCIA", consulta.getTipoDiligencia());
			paramDilig.put("IND_PASEARECFISICO", "1");
			paramDilig.put("NUM_CORREDOC_SOL", "0");
			this.cabDiligenciaDAO.update(paramDilig);
			
			// Actualiza declaracion
			Map<String, Object> paramDeclara = new HashMap<String, Object>();
			paramDeclara.put("NUM_CORREDOC", consulta.getNumcorredoc());
			paramDeclara.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_RECEPCIONADO);
			this.cabDeclaraDAO.update(paramDeclara);
			
			//anular asignacion
			/*asignacionManualService.anularAsignacion(consulta.getNumcorredoc(), 
					pe.gob.sunat.despaduanero2.asignacion.util.Constantes.ESTADO_REVISION_ASIGNADO);*/
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", consulta.getNumcorredoc());
			params.put("COD_ESTREV", ESTADO_REVISION_ASIGNADO);
			Map<String, Object> espeDocu =  espeDocuDAO.findbyDocEstRev(params);
			if(espeDocu!=null){
				params.put("codEstRev", ESTADO_REVISION_ELIMINADO_REASIGNACION);
				params.put("codTipAsig", COD_TIPO_ASIGNACION_REASIGNADO);			
				params.put("numCorreDoc", consulta.getNumcorredoc());
				params.put("fecAsig", espeDocu.get("fec_asig"));
				espeDocuDAO.modificarEspeDocuEstadoRevision(params);
			}
			
			// Grabar notificaciones
			this.grabarNotificacionesAceptacionSolicitudReconFisico(dua, consulta);
			
			// hosorio rin 12 registro en anfora 
			Declaracion declaracion=new Declaracion();
			declaracion.setDua(dua);
			declaracion.setNumeroDeclaracion(Long.valueOf(dua.getNumdocumento()));
			//hosoriov 179
			asignacionService.registrarDeclaracionAnfora(declaracion, "08");
			
		} catch (Exception e) {
			throw new ServiceException(e, e.getMessage());
		}
	}

	@Override
	public void grabarRechazoSolicitudReconFisico(DUA dua, Consulta consulta) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			// Actualizar consulta
			consulta.setIndicadorRespuesta("0");
			Date fechaRespuesta = new Date();
			Timestamp fechahoy = new Timestamp(fechaRespuesta.getTime());
			consulta.setFechaRespuesta(fechahoy);
			this.consultaDAO.update(consulta);
			// Grabar notificaciones
			this.grabarNotificacionesRechazoSolicitudReconFisico(dua, consulta);
			
		} catch (Exception e) {
			throw new ServiceException(e, e.getMessage());
		}
	}	
	
	/**
	 * Genera las notificaciones de remisi�n a reconocimiento f�sico para el due�o o consignatario y el agente
	 * 
	 * @author olunar - 309
	 * @param dua
	 * @param consulta
	 */
	private void grabarNotificacionesAceptacionSolicitudReconFisico(DUA dua, Consulta consulta)	{
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");	
		StringBuffer data = new StringBuffer();
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		
		// Notificaci�n a consignatario y representante
		mapMensaje.put("tip_usuario", "1");		
		mapMensaje.put("des_asunto", ASUNTO_PL_NOTI_REM_REC_FISICO);
		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		String strGarantia = dua.getPago().getPagoDeclaracion().getCodgarantia() != null && !dua.getPago().getPagoDeclaracion().getCodgarantia().isEmpty() ? "Garantia del articulo 160 de la LGA": "-";
		mapMensaje.put("garantia", strGarantia);	
		mapMensaje.put("cod_aduana", dua.getCodaduanaorden());		
		String descripcionAduana = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA,dua.getCodaduanaorden());
		mapMensaje.put("nom_aduana", descripcionAduana);
		mapMensaje.put("ann_presen", dua.getAnnpresen().toString());
		mapMensaje.put("cod_regimen", dua.getCodregimen());
		mapMensaje.put("num_declaracion", dua.getNumdocumento());		 
		
		// Notificaci�n a consignatario
		Map<String, Object> mapParticipante = new HashMap<String, Object>();
		mapParticipante.put("numeroCorrelativo", consulta.getNumcorredoc());
		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
		mapParticipante.put("tipoDocumentoIdentidad", Constantes.TIPO_DOC_RUC);
		List<Participante> listaConsignatario = this.participanteDocDAO.listByParameterMap(mapParticipante);
		
		if(!CollectionUtils.isEmpty(listaConsignatario)){
			mapMensaje.put("cod_usuario", new String[]{listaConsignatario.get(0).getNumeroDocumentoIdentidad()});
			mapMensaje.put("num_ruc", listaConsignatario.get(0).getNumeroDocumentoIdentidad());
			mapMensaje.put("nombre", listaConsignatario.get(0).getNombreRazonSocial());
			data = new StringBuffer(SojoUtil.toJson(mapMensaje));
			this.publicacionAvisoService.insert(Constantes.COD_PL_NOTI_REM_REC_FISICO, data, Constantes.CODIGO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());		
		}
		
		// Notificaci�n a representante		
		mapParticipante = new HashMap<String, Object>();
		mapParticipante.put("numeroCorrelativo", consulta.getNumcorredoc());
		mapParticipante.put("codTipoParticipante", Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);
		mapParticipante.put("tipoDocumentoIdentidad", Constantes.TIPO_DOC_RUC);
		List<Participante> listaRepresentante = this.participanteDocDAO.listByParameterMap(mapParticipante);
		
		if(!CollectionUtils.isEmpty(listaRepresentante)){
			mapMensaje.put("cod_usuario", new String[]{listaRepresentante.get(0).getNumeroDocumentoIdentidad()});
			mapMensaje.put("num_ruc", listaRepresentante.get(0).getNumeroDocumentoIdentidad());
			mapMensaje.put("nombre", listaRepresentante.get(0).getNombreRazonSocial());
			data = new StringBuffer(SojoUtil.toJson(mapMensaje));
			this.publicacionAvisoService.insert(Constantes.COD_PL_NOTI_REM_REC_FISICO, data, Constantes.CODIGO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());		
		}		
		
	}	
	
	/**
	 * Genera las notificaciones de rechazo de remisi�n a reconocimiento f�sico para el due�o o consignatario y el agente
	 * 
	 * @author olunar - 309
	 * @param dua
	 * @param consulta
	 */
	private void grabarNotificacionesRechazoSolicitudReconFisico(DUA dua, Consulta consulta)	{
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");	
		StringBuffer data = new StringBuffer();

		// Enviar notificaciones
		Map<String, Object> mapMensajeEspe = new HashMap<String, Object>();
		mapMensajeEspe.put("tip_usuario", "3");
		mapMensajeEspe.put("cod_usuario", new String[] {consulta.getFuncionario().getCodPers()});		
		mapMensajeEspe.put("des_asunto", ASUNTO_PL_NOTI_RECHAZA_REM_REC_FISICO);
		mapMensajeEspe.put("cod_aduana", dua.getCodaduanaorden());
		String descripcionAduana = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA,dua.getCodaduanaorden());
		mapMensajeEspe.put("nom_aduana", descripcionAduana);		
		mapMensajeEspe.put("ann_presen", dua.getAnnpresen().toString());
		mapMensajeEspe.put("cod_regimen", dua.getCodregimen());
		mapMensajeEspe.put("num_declaracion", dua.getNumdocumento());
		mapMensajeEspe.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		String strGarantia = dua.getPago().getPagoDeclaracion().getCodgarantia() != null && !dua.getPago().getPagoDeclaracion().getCodgarantia().isEmpty() ? "Garantia del articulo 160 de la LGA"
				: "-";
		mapMensajeEspe.put("garantia", strGarantia);	
		mapMensajeEspe.put("des_respuesta", consulta.getDescripcionRespuesta());
		mapMensajeEspe.put("registro", consulta.getAprobador().getCodPers());
		mapMensajeEspe.put("nombre", consulta.getAprobador().getApPate() + " " + consulta.getAprobador().getApMate() + " " + consulta.getAprobador().getNombres());

		
		data = new StringBuffer(SojoUtil.toJson(mapMensajeEspe));
		this.publicacionAvisoService.insert(Constantes.COD_PL_NOTI_RECHAZA_REM_REC_FISICO, data, Constantes.CODIGO_AVISO_ELECTRONICO,
				fechaActual.getTimestamp(), fechaVigencia.getTimestamp());		
		
	}	
	/* fin */

	public void rechazarSolicitud(Map<String, Object> solRec){

		String CodigoEstado = ""; //PAS20165E220200124 - mtorralba 20161006 - Variable para controlar Estado a Grabar
		boolean actualizaSaldos = true;
		if( solRec.get("COD_USUMODIF")!=null && solRec.get("COD_USUMODIF").toString().equals("PROC.AUT")) {
			CodigoEstado = ConstantesDataCatalogo.COD_EST_RECTIFIC_ANULADA;
			actualizaSaldos = solRec.get("COD_REGIMEN").toString().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO) ? true : false; 
		}
		else {
		// eliminar la asignacion del especialista de la solicitud de rectificacion
		if(solRec.get("COD_ESTARECTI").equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_ASIGNADA_ESPECIALISTA) || solRec.get("COD_ESTARECTI").equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_EN_PROCESO_EVALUACION) ){
			this.anularAsignacion(new Long(solRec.get("NUM_CORREDOC").toString()), ConstantesDataCatalogo.ESTADO_REVISION_ASIGNADO);
		}
		    CodigoEstado = ConstantesDataCatalogo.COD_EST_RECTIFIC_RECHAZADO;
		}

		
		//rechazar		
               //PAS20165E220200124 - mtorralba 20161006
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("COD_ESTARECTI", CodigoEstado);
              parametros.put("OBS_EVALUACION", solRec.get("OBS_EVALUACION") == null? " ": solRec.get("OBS_EVALUACION"));
	    parametros.put("NUM_CORREDOC", solRec.get("NUM_CORREDOC"));
	    this.cabSolrectiDAO.updateEstado(parametros);

        //ggranados pase 39 rechazar recti
	    Solicitud solicitud = new Solicitud();
	    solicitud.setNumeroCorrelativo(SunatNumberUtils.toLong(solRec.get("NUM_CORREDOC")));
	    solicitud.setFechaAtencion(new Date());
	    SolicitudDAO solicitudDAO= fabricaDeServicios.getService("despaduanero2.solicitudDAO");
	    solicitudDAO.updateByPrimaryKeySelective(solicitud);

	try {
		    	
		   
	    //PAS20165E220200124 - mtorralba 20161006
	    if( actualizaSaldos ) {
	  //PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
      //RMC RIN-P47
      if (solRec.get("NUM_DECLARACION")!=null) {
    	  solRec.put("NUM_CORREDOC_SOL", solRec.get("NUM_CORREDOC"));
          
    	  Map<String, Object> declaracion = new HashMap<String, Object>();
          declaracion.put("NUM_DECLARACION", solRec.get("NUM_DECLARACION"));
          declaracion.put("ANN_PRESEN", solRec.get("ANN_PRESEN"));
          declaracion.put("COD_REGIMEN", solRec.get("COD_REGIMEN")); 
          declaracion.put("NUM_CORREDOC", solRec.get("NUM_CORREDOC_DUA"));
          declaracion.put("COD_ADUANA", solRec.get("COD_ADUANA"));
          declaracion.put("FEC_MODIF", new java.sql.Timestamp(System.currentTimeMillis()));

          solRec.put("declaracion", declaracion);
          solRec.put("FEC_MODIF",  new java.sql.Timestamp(System.currentTimeMillis()));
          solRec.put("improcedente", "T");
          SolicitudRectificacionesService sr = fabricaDeServicios.getService("solicitudRectificacionesService");
          sr.procesarContingente(solRec);
      }
      //RMC RIN-P47

	   
	     }
	} catch (Exception e) {
	        	log.error(this.toString() + " ERROR ANULACION DE RECTIFICACION DE CONTINGENTE  procesarContingente - ERROR: " + e);
	        	throw new ServiceException(this, e);
	}
	    String codAduana =  solRec.get("COD_ADUANA")!=null?solRec.get("COD_ADUANA").toString():"";
	    String codRegimen =  solRec.get("COD_REGIMEN")!=null?solRec.get("COD_REGIMEN").toString():"";
	    Integer ano  =  solRec.get("ANN_PRESEN")!=null? new Integer(solRec.get("ANN_PRESEN").toString()):0;
	    Integer numDeclaracion =  solRec.get("NUM_DECLARACION")!=null?new Integer(solRec.get("NUM_DECLARACION").toString()):0;
	    Long numCorreDocSol  =  solRec.get("NUM_CORREDOC")!=null?new Long(solRec.get("NUM_CORREDOC").toString()):0;
	    valorProvisionalService.rechazarSolicitudElectronicaConValorProvisional(codAduana,codRegimen,ano,numDeclaracion,numCorreDocSol);

        ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
      
        try {
        	String numCorreDoc = solRec.get("NUM_CORREDOC_DUA").toString();
        	boolean tieneDiligencia = CollectionUtils.isEmpty(this.diligenciaService.findDuaDiligenciada(numCorreDoc))?false:true;
        	controlarSaldoReposicionService.eliminarReservaCtaCte(codAduana,codRegimen,ano,numDeclaracion,"RECTI-RECHAZO",tieneDiligencia);
        } catch (Exception e) {
        	log.error(this.toString() + " controlarSaldoReposicionService - ERROR: " + e);
        	throw new ServiceException(this, e);
        }
	}
	
	public void anularAsignacion(Long numCorredoc, String estadoRevision){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", numCorredoc);
		params.put("COD_ESTREV", estadoRevision);
		Map<String, Object> espeDocu =  espeDocuDAO.findbyDocEstRev(params);
		if(espeDocu!=null){
			params.put("codEstRev", ConstantesDataCatalogo.ESTADO_REVISION_ELIMINADO_REASIGNACION);
			params.put("codTipAsig", ConstantesDataCatalogo.COD_TIPO_ASIGNACION_REASIGNADO);
			params.put("numCorreDoc", numCorredoc);
			params.put("fecAsig", espeDocu.get("fec_asig"));
			espeDocuDAO.modificarEspeDocuEstadoRevision(params);
		}							
	}
//fin mordonezl	
  /***********************SET DE SPRING **********************************/



  public void setIndicadorDuaDAO(IndicadorDUADAO indicadorDuaDAO)
  {
    this.indicadorDuaDAO = indicadorDuaDAO;
  }


  public void setEspeDocuDAO(EspeDocuDAO espeDocuDAO)
  {
    this.espeDocuDAO = espeDocuDAO;
  }


  public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO)
  {
    this.detAutorizacionDAO = detAutorizacionDAO;
  }


  public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO)
  {
    this.cabSolrectiDAO = cabSolrectiDAO;
  }


  public void setRelacionDocDAO(RelacionDocDAO relacionDocDAO)
  {
    this.relacionDocDAO = relacionDocDAO;
  }


  public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO)
  {
    this.cabDiligenciaDAO = cabDiligenciaDAO;
  }


  public void setConsultaDAO(ConsultaDAO consultaDAO)
  {
    this.consultaDAO = consultaDAO;
  }


  public void setCatEmpleadoDAO(CatEmpleadoDAO catEmpleadoDAO)
  {
    this.catEmpleadoDAO = catEmpleadoDAO;
  }


  public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
  {
    this.docAutAsociadoDAO = docAutAsociadoDAO;
  }


  public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO)
  {
    this.cabDeclaraDAO = cabDeclaraDAO;
  }

  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }

  public void setDiligenciaService(DiligenciaService diligenciaService)
  {
    this.diligenciaService = diligenciaService;
  }

  /* olunar 309 */
  public void setPublicacionAvisoService(PublicacionAvisoService publicacionAvisoService) {
	this.publicacionAvisoService = publicacionAvisoService;
  }

  public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO) {
	this.participanteDocDAO = participanteDocDAO;
  }

  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
	this.catalogoAyudaService = catalogoAyudaService;
  }

  public void setAsignacionManualService(
		AsignacionManualService asignacionManualService) {
	this.asignacionManualService = asignacionManualService;
  }
  /* fin */
  
// hsooriov rin 12
  public void setAsignacionService(AsignacionService asignacionService) {
	this.asignacionService = asignacionService;
}
  
  
  
}
