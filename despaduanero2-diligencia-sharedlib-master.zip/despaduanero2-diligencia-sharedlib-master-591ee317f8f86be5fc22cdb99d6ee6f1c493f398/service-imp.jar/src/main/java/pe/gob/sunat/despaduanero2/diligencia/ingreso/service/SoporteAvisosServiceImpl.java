package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.service.ReporteGestionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import net.sf.sojo.interchange.json.JsonSerializer;

public class SoporteAvisosServiceImpl implements SoporteAvisosService {
	
	protected final Log              log = LogFactory.getLog(this.getClass());
	
	private FabricaDeServicios fabricaDeServicios;
	private ReporteGestionService reporteGestionService;
	//private PublicacionAvisoService publicacionAvisoService;
	private static final String CODIGO_TIPO_NOTIFICACION = "1";
	private static final Integer RESULT_PROCEDENTE = 101116;
	private static final Integer RESULT_IMPROCEDENTE = 101120;
	
	/*RIN13 SWF INICIO*/
	private static final Integer RESULT_BLOQUEO = 101147;
	private static final Integer RESULT_DESBLOQUEO = 101148;	
	/*RIN13 SWF FIN*/
	
	private static final Integer RESULT_PROCEDENTE_CON_AFECTACION = 101117;
	private static final Integer RESULT_PROCEDENTE_EN_PARTE = 101118;
	private static final Integer RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION = 101119;

	private CatalogoAyudaService       catalogoAyudaService;
	

    /*
	private PublicacionAvisoService publicacionAvisoService;


	public void setPublicacionAvisoService(
			PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}*/
		

/* estos codigos no son los que necesita la tabla avisos
	public static final String CODIGO_TIPO_NOTIFICACION = "1";
	public static final Integer RESULT_PROCEDENTE = 101116;
	public static final Integer RESULT_IMPROCEDENTE = 101120;
	public static final Integer RESULT_PROCEDENTE_CON_AFECTACION = 101117;
	public static final Integer RESULT_PROCEDENTE_EN_PARTE = 101118;
	public static final Integer RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION = 101119;

	public Integer getCodigoResultado(String resultado) {
		
		if(resultado!=null){
			if(resultado.equals("RESULT_PROCEDENTE")){
				return RESULT_PROCEDENTE;
			}
			if(resultado.equals("RESULT_IMPROCEDENTE")){
				return RESULT_IMPROCEDENTE;
			}
			if(resultado.equals("RESULT_PROCEDENTE_CON_AFECTACION")){
				return RESULT_PROCEDENTE_CON_AFECTACION;
			}
			if(resultado.equals("RESULT_PROCEDENTE_EN_PARTE")){
				return RESULT_PROCEDENTE_EN_PARTE;
			}
			if(resultado.equals("RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION")){
				return RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION;
			}
		}
		return 0;
	}
*/

 public void noticarResultadoDeLaRectificacionElectronica(AVISO aviso,Map<String, Object> data){

        //amancillaa
        PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService)fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");

        Integer tipoplantilla =aviso.getCodCatalogoPlantilla();
        FechaBean fechaActual = new FechaBean();
        FechaBean fechaVigencia = new FechaBean("31/12/9999");

        String[] cod_usuario = (String[]) ((data.get("COD_USUARIO")==null) ? "" : data.get("COD_USUARIO"));

        String elaborado=(data.get("ELABORADO_POR")==null) ? "" : data.get("ELABORADO_POR").toString();

        //Obteniendo el detalle
        List<HashMap<String,Object>> listaLC = (List<HashMap<String,Object>>)data.get("dataLC");
        Map<String, Object> mapMensaje = new HashMap<String, Object>();
        mapMensaje.put("fecha_emision",  new StringBuilder(fechaActual.getDia()).
                						append("/").append(fechaActual.getMes()).
                						append("/").append(fechaActual.getAnho()).toString());
        mapMensaje.put("des_asunto", aviso.getAsuntoDelEnvio());
        try {
        	byte[] byte_array = elaborado.getBytes("ISO-8859-1");
			elaborado = new String(byte_array, "ISO-8859-1");
		} catch (UnsupportedEncodingException e) {
			log.info(e.getStackTrace());
		}
        mapMensaje.put("elaborado_por", StringEscapeUtils.escapeHtml(elaborado.replaceAll("</?\\w++[^>]*+>", "")));
        mapMensaje.put("tip_usuario", 1);
        mapMensaje.put("cod_usuario", cod_usuario);

        Date  fechaSol = Utilidades.toDate(data.get("FEC_SOLICITUD_RECTI"));                        
        mapMensaje.put("fecha_solirectielectronica", SunatDateUtils.getFormatDate(fechaSol, "dd/MM/yyyy"));
        mapMensaje.put("receptor", data.get("RECEPTOR").toString().trim());
        mapMensaje.put("cod_aduana",data.get("COD_ADUANA").toString());
        mapMensaje.put("ann_presen",data.get("ANN_PRESEN").toString());
        mapMensaje.put("cod_regimen",data.get("COD_REGIMEN").toString());
        mapMensaje.put("num_declaracion",data.get("NUM_DECLARACION").toString());
       List<Map> lstDeudasAAfectar = data.get("lstDeudasAAfectar")!=null?(ArrayList<Map>)data.get("lstDeudasAAfectar"):new ArrayList();
       StringBuffer buffer = new StringBuffer();
       
	   List<Map<String,String>> lstDocumentos = new ArrayList();

       if(CollectionUtils.isNotEmpty(lstDeudasAAfectar)){
    	   
		   Map<String,String> mapDocumento;
		   for (Map deuda: lstDeudasAAfectar) {
			   buffer.append("<tr>");
			   mapDocumento = new HashMap();
			   if ("DUA".equals(deuda.get("TIPO"))) { // Para ver si incluye la deuda de la DUA.
				   buffer.append("<td>");
				   buffer.append("Formato C");
				   buffer.append("</td>");
				   buffer.append("<td>");
				   buffer.append("---");
				   buffer.append("</td>");
			   }else{
				  buffer.append("<td>");
                  if("0022".equals(deuda.get("TIPOLC"))){
                	  buffer.append("LC ISC");
				  }else if("0038".equals(deuda.get("TIPOLC"))){
					  buffer.append("LC Percepcion");

				  }else if("0010".equals(deuda.get("TIPOLC"))){
					  buffer.append("LC Tributos");
				  }
                  buffer.append("</td>");
                  
			   }
			   buffer.append("<td>");
			   buffer.append(deuda.get("CDA").toString());
			   buffer.append("</td>");
//pase81
			   //bug  20561
			   if ("DUA".equals(deuda.get("TIPO"))) { 
				   buffer.append("<td>");
				   buffer.append("---");
				   buffer.append("</td>");
			   }else{
//pase81
                  buffer.append("<td>");
				  String liquidacion = deuda.get("COD_ADULIQUIDA")+"-"+deuda.get("ANN_LIQUIDA")+"-"+deuda.get("NUM_LIQUIDA");
				  buffer.append(liquidacion);
				  buffer.append("</td>");
			   }
			   
			   buffer.append("<td>");
			   String simboloMoneda = "D".equals(deuda.get("MONEDA").toString())?"$/. ":"S/. ";
			   buffer.append(deuda.get("CDA").toString());
			   buffer.append("</td>");
			   buffer.append("<td>");
			   buffer.append(simboloMoneda+deuda.get("MONTO").toString());
			   buffer.append("<td>");			   
			   buffer.append("</tr>");
		   }
		   
		   mapMensaje.put("lstDocumentos",buffer.toString());
	   }

        StringBuffer sdata = new StringBuffer(SojoUtil.toJson(mapMensaje));
        publicacionAvisoService.insert(tipoplantilla, sdata, aviso.getTipoEnvio().getCodigo(),fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

    }

//PAS20165E220200127
 public void noticarResultadoDeLaRectificacion(AVISO aviso,Map<String, Object> data){
     PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService)fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
     Integer tipoplantilla =aviso.getCodCatalogoPlantilla();
     FechaBean fechaActual = new FechaBean();
     FechaBean fechaVigencia = new FechaBean("31/12/9999");
     String[] cod_usuario = (String[]) ((data.get("COD_USUARIO")==null) ? "" : data.get("COD_USUARIO"));
     String elaborado=(data.get("ELABORADO_POR")==null) ? "" : data.get("ELABORADO_POR").toString();
     List<HashMap<String,Object>> listaLC = (List<HashMap<String,Object>>)data.get("dataLC");
     Map<String, Object> mapMensaje = new HashMap<String, Object>();
     mapMensaje.put("fecha_emision",  new StringBuilder(fechaActual.getDia()).
             						append("/").append(fechaActual.getMes()).
             						append("/").append(fechaActual.getAnho()).toString());
     mapMensaje.put("des_asunto", aviso.getAsuntoDelEnvio());
     try {
     	byte[] byte_array = elaborado.getBytes("ISO-8859-1");
			elaborado = new String(byte_array, "ISO-8859-1");
		} catch (UnsupportedEncodingException e) {
			log.info(e.getStackTrace());
		}
     mapMensaje.put("elaborado_por", StringEscapeUtils.escapeHtml(elaborado.replaceAll("</?\\w++[^>]*+>", "")));
     mapMensaje.put("tip_usuario", 1);
     mapMensaje.put("cod_usuario", cod_usuario);
     Date  fechaSol = Utilidades.toDate(data.get("FEC_SOLICITUD_RECTI"));                        
     mapMensaje.put("fecha_solirectielectronica", SunatDateUtils.getFormatDate(fechaSol, "dd/MM/yyyy"));
     mapMensaje.put("receptor", data.get("RECEPTOR").toString().trim());
     mapMensaje.put("cod_aduana",data.get("COD_ADUANA").toString());
     mapMensaje.put("ann_presen",data.get("ANN_PRESEN").toString());
     mapMensaje.put("cod_regimen",data.get("COD_REGIMEN").toString());
     mapMensaje.put("num_declaracion",data.get("NUM_DECLARACION").toString());
    List<Map> lstDeudasAAfectar = data.get("lstDeudasAAfectar")!=null?(ArrayList<Map>)data.get("lstDeudasAAfectar"):new ArrayList();
    StringBuffer buffer = new StringBuffer();
	   List<Map<String,String>> lstDocumentos = new ArrayList();
    if(CollectionUtils.isNotEmpty(lstDeudasAAfectar)){
		   Map<String,String> mapDocumento;
		   for (Map deuda: lstDeudasAAfectar) {
			   buffer.append("<tr>");
			   mapDocumento = new HashMap();
			   if ("DUA".equals(deuda.get("TIPO"))) { // Para ver si incluye la deuda de la DUA.
				   buffer.append("<td>");
				   buffer.append("Formato C");
				   buffer.append("</td>");
			   }else{
				  buffer.append("<td>");
               if("0022".equals(deuda.get("TIPOLC"))){
             	  buffer.append("LC ISC");
				  }else if("0038".equals(deuda.get("TIPOLC"))){
					  buffer.append("LC Percepcion");
				  }else if("0010".equals(deuda.get("TIPOLC"))){
					  buffer.append("LC Tributos");
				  }
               buffer.append("</td>");
			   }
			   buffer.append("<td>");
			   buffer.append(deuda.get("CDA").toString());
			   buffer.append("</td>");
			   if ("DUA".equals(deuda.get("TIPO"))) { 
				   buffer.append("<td>");
				   buffer.append("---");
				   buffer.append("</td>");
			   }else{
               buffer.append("<td>");
				  String liquidacion = deuda.get("COD_ADULIQUIDA")+"-"+deuda.get("ANN_LIQUIDA")+"-"+deuda.get("NUM_LIQUIDA");
				  buffer.append(liquidacion);
				  buffer.append("</td>");
			   }
			   buffer.append("<td>");
			   String simboloMoneda = "D".equals(deuda.get("MONEDA").toString())?"$/. ":"S/. ";
			   buffer.append(simboloMoneda+deuda.get("MONTO").toString());
			   buffer.append("<td>");			   
			   buffer.append("</tr>");
		   }
		   mapMensaje.put("lstDocumentos",buffer.toString());
	   }
    
    //Inicio PAS20175E410000003
    //Verifica si le corresponde mandato electronico y de ser asi registra el indicador del mismo.
    if(data.get("ind_mandato_incorpora")!=null && data.get("msg_mandato")!=null){
 	   mapMensaje.put("ind_mandato_incorpora", data.get("ind_mandato_incorpora"));
 	   mapMensaje.put("msg_mandato", data.get("msg_mandato"));
    }
    //Fin 
    
     StringBuffer sdata = new StringBuffer(SojoUtil.toJson(mapMensaje));
     publicacionAvisoService.insert(tipoplantilla, sdata, aviso.getTipoEnvio().getCodigo(),fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
 }
//Fin PAS20165E220200127
	/*public void noticarResultadoDeLaRectificacionElectronica(
			Integer TipoPlantilla, Map Data) {

        //amancillaa
        PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService)fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");


		Integer tipoplantilla =TipoPlantilla;
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean("31/12/9999");

		String[] cod_usuario = (String[]) ((Data.get("COD_USUARIO")==null) ? "" : Data.get("COD_USUARIO"));
		String rzs_social = (Data.get("NOM_RAZONSOCIAL")==null) ? "" : Data.get("NOM_RAZONSOCIAL").toString();
		String elaborado=(Data.get("ELABORADO_POR")==null) ? "" : Data.get("ELABORADO_POR").toString();

		//Obteniendo el detalle
		List<HashMap<String,Object>> listaLC = (List<HashMap<String,Object>>)Data.get("dataLC");
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		mapMensaje.put("LC",listaLC);
		mapMensaje.put("rsocial", rzs_social);
		mapMensaje.put("fecha_emision", fechaActual.getTimestamp());
		mapMensaje.put("des_asunto", obtenerAsuntoDeNotificacion(tipoplantilla));
		mapMensaje.put("elaborado_por", elaborado);
		mapMensaje.put("tip_usuario", 1);
		mapMensaje.put("cod_usuario", cod_usuario);

		*//*jlunah*//*
		mapMensaje.put("fecha_solirectielectronica", Data.get("FEC_SOLICITUD_RECTI"));
		mapMensaje.put("receptor", Data.get("RECEPTOR"));
		mapMensaje.put("cod_aduana",Data.get("COD_ADUANA"));
		mapMensaje.put("ann_presen",Data.get("ANN_PRESEN"));
		mapMensaje.put("cod_regimen",Data.get("COD_REGIMEN"));
		mapMensaje.put("num_declaracion",Data.get("NUM_DECLARACION"));


		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		publicacionAvisoService.insert(tipoplantilla, data, CODIGO_TIPO_NOTIFICACION,
				fechaActual.getTimestamp(), fechaVigencia.getTimestamp());


	}


	String obtenerAsuntoDeNotificacion(Integer tipoPlantilla){
		String ret="";
		if(tipoPlantilla!=null){
			if (tipoPlantilla.toString().equals(RESULT_PROCEDENTE.toString())){
				 ret="RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
			}
			if (tipoPlantilla.toString().equals(RESULT_PROCEDENTE_CON_AFECTACION.toString())){
				 ret="RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA CON AFECTACI�N A LA GARANT�A PREVIA";
			}
			if (tipoPlantilla.toString().equals(RESULT_PROCEDENTE_EN_PARTE.toString())){
				 ret="RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
			}
			if (tipoPlantilla.toString().equals(RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION.toString())){
				 ret="RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA CON AFECTACI�N A LA GARANT�A PREVIA";
			}
			if (tipoPlantilla.toString().equals(RESULT_IMPROCEDENTE.toString())){
				 ret="RESULTADO DE IMPROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
			}
		}
		return ret;

	}*/

	/**
	 * 
	 * juazor RIN13
	   * {@inheritDoc}
	   */
	  public void notificacionElectronicaBloqueo(
	                                   String descripcion,
	                                   String codAduana,
	                                   String annPresen,
	                                   String codRegimen,
	                                   String numDeclaracion,
	                                   String codFuncionario,
	                                   String[] codUsuario,
	                                   Integer codPlantilla,
	                                   String codTipoAviso,
	                                   String tipoUsuario)
	  {
	    FechaBean fechaPublicacion = new FechaBean();

	    FechaBean fechaVigencia = new FechaBean();

	    fechaVigencia.setFecha("31/12/9999");

	    Map<String, Object> mapMensaje = new HashMap<String, Object>();

	    mapMensaje.put("cod_usuario", codUsuario);
	    mapMensaje.put("funcionario", codFuncionario);
	    mapMensaje.put("des_asunto", obtenerAsuntoDeNotificacion(codPlantilla));

	    mapMensaje.put("tip_usuario", tipoUsuario);

	    mapMensaje.put("des_intendencia", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));

	    if (descripcion != null){
	      mapMensaje.put("descripcion", StringEscapeUtils.escapeHtml(descripcion.replaceAll("</?\\w++[^>]*+>", "")));
	    }
	    mapMensaje.put("cod_aduana", codAduana);
	    mapMensaje.put("ann_presen", annPresen);
	    mapMensaje.put("cod_regimen", codRegimen);
	    mapMensaje.put("num_declaracion", numDeclaracion);

	    mapMensaje.put("fecha_emision",
	                   new StringBuilder(fechaPublicacion.getDia()).
	                                                               append("/").append(fechaPublicacion.getMes()).
	                   append("/").append(fechaPublicacion.getAnho()).toString());

	    StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	    PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService)fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
	    publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	}
		
	
	private String obtenerAsuntoDeNotificacion(Integer tipoPlantilla){
		String ret="";
		if (tipoPlantilla==RESULT_PROCEDENTE){
			 ret="RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
		}
		if (tipoPlantilla==RESULT_PROCEDENTE_CON_AFECTACION){
			 ret="RESULTADO DE PROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA CON AFECTACI�N A LA GARANT�A PREVIA";
		}
		if (tipoPlantilla==RESULT_PROCEDENTE_EN_PARTE){
			 ret="RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
		}
		if (tipoPlantilla==RESULT_PROCEDENTE_EN_PARTE_CON_AFECTACION){
			 ret="RESULTADO DE PROCEDENTE EN PARTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA CON AFECTACI�N A LA GARANT�A PREVIA";
		}
		if (tipoPlantilla==RESULT_IMPROCEDENTE){
			 ret="RESULTADO DE IMPROCEDENTE DE LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA";
		}
		/*RIN13 SWF INICIO*/
		if (tipoPlantilla==RESULT_BLOQUEO){
			 ret="NOTIFICACION DE BLOQUEO DE SALIDA";
		}
		if (tipoPlantilla==RESULT_DESBLOQUEO){
			 ret="NOTIFICACION DE DESBLOQUEO DE SALIDA";
		}
		if (tipoPlantilla==Constantes.COD_PL_NOTI_CONTDESPACHO_CONSIGNATARIO){
			 ret="NOTIFICACION CONTINUACION DE DESPACHO";
		}
		if (tipoPlantilla==Constantes.RESULT_DISMINUCION__BULTOS_RESPUESTA_SI){
			 ret="Plantilla de Notificaci�n al jefe de disminuci�n de bultos Respuesta SI";
		}
		if (tipoPlantilla==Constantes.RESULT_DISMINUCION__BULTOS_RESPUESTA_NO){
			 ret="Plantilla de Notificaci�n al jefe de disminuci�n de bultos Respuesta NO";
		}
		if (tipoPlantilla==Constantes.COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO){
			 ret="NOTIFICACION ARRIBO DE MERCANCIAS FUERA DE PLAZO";
		}
		/*RIN13 SWF FIN*/
		return ret;
				
	}
	

	
	/////set//////
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	
    public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService){
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void notificacionElectronica(HashMap<String, Object> parametros) throws ServiceException {
		Integer codPlantilla = Constantes.INT_CERO;
		Integer numServicio = Constantes.INT_CERO;
		if(parametros.containsKey("bloqueo")){
			if((Boolean)parametros.get("bloqueo")){
				codPlantilla = RESULT_BLOQUEO;
				numServicio=Constantes.COD_PL_NOTI_OBS_BLOQUEO;
			} else {
				codPlantilla = RESULT_DESBLOQUEO;
				numServicio=Constantes.COD_PL_NOTI_OBS_DESBLOQUEO;
			}
		}
			
		String nombreFuncionario = reporteGestionService.obtenerUsuario(parametros.get("codFuncionario").toString());
		if(nombreFuncionario==null){
			nombreFuncionario="Usuario no Ubicado";
		}
		FechaBean fechaPublicacion = new FechaBean();
			
	    FechaBean fechaVigencia = new FechaBean();

	    fechaVigencia.setFecha("31/12/9999");

	    Map<String, Object> mapMensaje = new HashMap<String, Object>();

	    /*amancilla Rin13 correcciones */
	    //String [] usuarioNuevo2 =  new String[]{parametros.get("numDocIdentPim").toString()};	    
	    String[] usuarios = new String[]{parametros.get("usuarios").toString()}  !=null ? new String[]{parametros.get("usuarios").toString()} : new String[]{parametros.get("numDocIdentPim").toString()};
	    mapMensaje.put("cod_usuario",usuarios);
	    mapMensaje.put("funcionario", nombreFuncionario);
	    //mapMensaje.put("funcionario", parametros.get("codFuncionario").toString());
	    mapMensaje.put("des_asunto", obtenerAsuntoDeNotificacion(codPlantilla));

	    mapMensaje.put("tip_usuario", Constantes.TIPO_USUARIO_AVISO_OCE);

	    /*amancilla Rin13 correcciones*/
	    String desConsignatario = parametros.get("DES_CONSIGNATARIO") != null ? parametros.get("DES_CONSIGNATARIO").toString() : "-"; //consignatario
	    String desAgencia = parametros.get("DES_AGENCIA_ADUANAS") != null ? parametros.get("DES_AGENCIA_ADUANAS").toString() : "-"; //agencia de aduanas
	    mapMensaje.put("des_consignatario", StringEscapeUtils.escapeHtml(desConsignatario));//importador
	    mapMensaje.put("des_agencia", StringEscapeUtils.escapeHtml(desAgencia));
		if (parametros.get("desSustento").toString() != null) {
	      mapMensaje.put("descripcion", StringEscapeUtils.escapeHtml(parametros.get("desSustento").toString().replaceAll("</?\\w++[^>]*+>", "")));
	    }
	    mapMensaje.put("cod_aduana", parametros.get("codAduana").toString());
	    mapMensaje.put("ann_presen", parametros.get("annPresen").toString());
	    mapMensaje.put("cod_regimen", parametros.get("codRegimen").toString());
	    mapMensaje.put("num_declaracion", parametros.get("numDeclaracion").toString());
	    
	    if(parametros.containsKey("plantillaAlmacen")) {
	    	mapMensaje.put("lbl_sres", StringEscapeUtils.escapeHtml("Almac�n"));
		    mapMensaje.put("lbl_agencia", "&nbsp;");
		    mapMensaje.put("des_agencia", "&nbsp;");
		    mapMensaje.put("des_complementaria", StringEscapeUtils.escapeHtml(" por el motivo indicado a continuaci�n. S�rvase disponer las medidas " +
		    		"correspondientes para evitar el retiro de la mercanc�a de sus recintos."));		    
	    } else {
	    	mapMensaje.put("lbl_sres", "Sres");
		    mapMensaje.put("lbl_agencia", "Agencia");
		    
		    if(parametros.containsKey("des_almacen_aduanero")) {
		    	mapMensaje.put("des_almacen_aduanero", StringEscapeUtils.escapeHtml(parametros.get("des_almacen_aduanero").toString()));
		    }
		    mapMensaje.put("des_complementaria", ".");
	    }	    
		    
		// seteamos el usuario que se va a mostrar en las plantillas html
	    if(parametros.containsKey("bloqueo")){
	    	if(parametros.get("RECEPTOR").equals(Constantes.IMPORTADOR)){//Para el IMPORTADOR
	    		mapMensaje.put("lbl_destinatario", "Sres");
	    		mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(desConsignatario));
	    	}
	    	if(parametros.get("RECEPTOR").equals(Constantes.AGENTE)){//Para el AGENTE
	    		mapMensaje.put("lbl_destinatario", "Agencia");
	    		mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(desAgencia));
	    	}
	    	if(parametros.get("RECEPTOR").equals(Constantes.ALMACEN)){//Para el ALMACEN
	    		mapMensaje.put("lbl_destinatario", "Almacen Aduanero");
	    		mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(parametros.get("des_almacen_aduanero").toString()));
	    	}
	    }	    
	    mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).
	                                                               append("/").append(fechaPublicacion.getMes()).
	            append("/").append(fechaPublicacion.getAnho()).toString());

	    StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	    PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService)fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
	    publicacionAvisoService.insert(numServicio, data, "1", fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	    /*----------------------------------------------------------------------------------------------*/
	}

	public void setReporteGestionService(ReporteGestionService reporteGestionService) {
		this.reporteGestionService = reporteGestionService;
	}
	
	/**
	   * juazor RIN13
	   * @param descripcion
	   * @param codAduana
	   * @param annPresen
	   * @param codRegimen
	   * @param numDeclaracion
	   * @param codFuncionario
	   * @param codUsuario
	   * @param codPlantilla
	   * @param codTipoAviso
	   * @param tipoUsuario
	   */
	  public void notificarContinuacionDespacho(
	          String descripcion,
	          String codAduana,
	          String annPresen,
	          String codRegimen,
	          String numDeclaracion,
	          String codFuncionario,
	          String[] codUsuario,
	          Integer codPlantilla,
	          String codTipoAviso,
	          String tipoUsuario,
	          Map<String, Object> destinatarios)
	{
		FechaBean fechaPublicacion = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		  
		Map<String, Object> mapMensaje = new HashMap<String, Object>();	
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("COD_ADUANA", codAduana);
		params.put("ANN_PRESEN", annPresen);
		params.put("COD_REGIMEN", codRegimen);
		params.put("NUM_DECLARACION", numDeclaracion);
	
		String asunto = " - "+codAduana+ "-"+annPresen+ "-"+codRegimen+"-"+numDeclaracion.trim();	
		//obtener el consignatario RIN13
		//String numCorreDoc = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
		DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
		String consignatario = diligenciaService.obtenerConsignatario(codAduana,annPresen,codRegimen,numDeclaracion, null); //le enviamos null para que en diligenciaService se busque el numcorredoc de la declaracion
		String desConsignatario = destinatarios.get("DES_CONSIGNATARIO") != null ? destinatarios.get("DES_CONSIGNATARIO").toString() : "-"; //consignatario
		mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(desConsignatario));//descripcion consignatario
		mapMensaje.put("lbl_destinatario", "Sres:");	
		mapMensaje.put("cod_usuario", codUsuario);
		mapMensaje.put("funcionario", codFuncionario);
		mapMensaje.put("des_asunto", obtenerAsuntoDeNotificacion(codPlantilla) + asunto);	
		mapMensaje.put("tip_usuario", tipoUsuario);
		String desAgencia = destinatarios.get("DES_AGENCIA_ADUANAS") != null ? destinatarios.get("DES_AGENCIA_ADUANAS").toString() : "-"; //agencia de aduanas
		mapMensaje.put("des_agencia", StringEscapeUtils.escapeHtml(desAgencia));//agencia de aduanas
	
		if (descripcion != null) {
			mapMensaje.put("descripcion",  StringEscapeUtils.escapeHtml(descripcion.replaceAll("</?\\w++[^>]*+>", "")));
		}
		mapMensaje.put("cod_aduana", codAduana);
		mapMensaje.put("ann_presen", annPresen);
		mapMensaje.put("cod_regimen", codRegimen);
		mapMensaje.put("num_declaracion", numDeclaracion);	
		mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).
	                                      append("/").append(fechaPublicacion.getMes()).
				append("/").append(fechaPublicacion.getAnho()).toString());

	StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());

	}//fin notificarContinuacionDespacho

	  /**
	   * juazor RIN13
	   * @param descripcion
	   * @param codAduana
	   * @param annPresen
	   * @param codRegimen
	   * @param numDeclaracion
	   * @param codFuncionario
	   * @param codUsuario
	   * @param codPlantilla
	   * @param codTipoAviso
	   * @param tipoUsuario
	   */
	  public void notificarDatado(
	          String descripcion,
	          String codAduana,
	          String annPresen,
	          String codRegimen,
	          String numDeclaracion,
	          String codFuncionario,
	          String[] codUsuario,
	          Integer codPlantilla,
	          String codTipoAviso,
	          String tipoUsuario)
	{
		FechaBean fechaPublicacion = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");	
		Map<String, Object> mapMensaje = new HashMap<String, Object>();	
		mapMensaje.put("cod_usuario", codUsuario);
		mapMensaje.put("funcionario", codFuncionario);
		mapMensaje.put("des_asunto", obtenerAsuntoDeNotificacion(codPlantilla));	
		mapMensaje.put("tip_usuario", tipoUsuario);	
		mapMensaje.put("des_intendencia", catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana));	
		if (descripcion != null) {
			mapMensaje.put("descripcion", StringEscapeUtils.escapeHtml(descripcion).replaceAll("</?\\w++[^>]*+>", ""));
		}
		mapMensaje.put("cod_aduana", codAduana);
		mapMensaje.put("ann_presen", annPresen);
		mapMensaje.put("cod_regimen", codRegimen);
		mapMensaje.put("num_declaracion", numDeclaracion);	
		mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).
	                                      append("/").append(fechaPublicacion.getMes()).
		        append("/").append(fechaPublicacion.getAnho()).toString());

	StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	}//fin notificarDatado
	  
	  /*juazor*/
	public void grabarComunicacionNotificacion(Map<String, Object> params) throws ServiceException {

			String descNotificacion = (String) params.get("des_noti");
			String codAduana = (String) params.get("codAduana");
			String annPresen = (String) params.get("annPresen");
			String codRegimen = (String) params.get("codRegimen");
			String numDeclaracion = (String) params.get("numDeclaracion");
			String cod_usuregis = (String) params.get("cod_usuregis");
			String num_docident_pim = (String) params.get("num_docident_pim");
			String num_docident_pde = (String) params.get("num_docident_pde");
			
			DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");

			try {

				if (!params.get("flag").equals("C")) {
					params.put("cod_tipdiligencia", "01");
				} else {
					params.put("cod_tipdiligencia", "04");
				}
				// inserta la comunicacion

//				params.put("cod_nota", "i");
//				diligenciaService.grabarComunicacion(params);

				params.put("cod_nota", "e");
				diligenciaService.grabarComunicacion(params);

				// si es comunicacion con el portal envia una notificacion
				if (((String) params.get("cod_nota")).trim().equals("e")) {
					
					Map<String,Object> destinatarios = new HashMap<String, Object>();
					destinatarios.put("DES_CONSIGNATARIO", params.get("DES_CONSIGNATARIO"));
					destinatarios.put("DES_AGENCIA_ADUANAS", params.get("DES_AGENCIA_ADUANAS"));
					
					if (params.get("codCanal").equals(Constantes.CANAL_ROJO) && StringUtils.isNotEmpty(num_docident_pim)) {
						destinatarios.put("RECEPTOR", Constantes.IMPORTADOR);//RIN13 SWF
						notificarObservacion(descNotificacion, codAduana,
								annPresen, codRegimen, numDeclaracion,
								cod_usuregis, new String[] { num_docident_pim },
								Constantes.COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);
					}
					
					if (params.get("codCanal").equals(Constantes.CANAL_ROJO) && StringUtils.isNotEmpty(num_docident_pde)) {
						destinatarios.put("RECEPTOR", Constantes.AGENTE);//RIN13 SWF
						notificarObservacion(descNotificacion, codAduana,
								annPresen, codRegimen, numDeclaracion,
								cod_usuregis, new String[] { num_docident_pde },
								Constantes.COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);
					} 
					
					if (params.get("codCanal").equals(Constantes.CANAL_NARANJA) && StringUtils.isNotEmpty(num_docident_pim)) {
						destinatarios.put("RECEPTOR", Constantes.IMPORTADOR);//RIN13 SWF
						notificarObservacion(descNotificacion, codAduana,
								annPresen, codRegimen, numDeclaracion,
								cod_usuregis, new String[] { num_docident_pim },
								Constantes.COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);
					}
					
					if (params.get("codCanal").equals(Constantes.CANAL_NARANJA) && StringUtils.isNotEmpty(num_docident_pde)) {
						destinatarios.put("RECEPTOR", Constantes.AGENTE);//RIN13 SWF
						notificarObservacion(descNotificacion, codAduana,
								annPresen, codRegimen, numDeclaracion,
								cod_usuregis, new String[] { num_docident_pde },
								Constantes.COD_PL_NOTI_ARRIBO_MERC_FUERA_PLAZO,
								Constantes.CODIGO_NOTIFICACION,
								Constantes.CONTRIBUYENTE,
								destinatarios);
					}

				}

			} catch (Exception e) {
				throw new ServiceException(this, e);
			}

		}
		
		/**
		   * RIN13 SWF - afecta diligencia despacho - continuacion de despacho - descargas parciales
		   */
		public void notificarObservacion(
										String descripcion,
						                String codAduana,
						                String annPresen,
						                String codRegimen,
						                String numDeclaracion,
						                String codFuncionario,
						                String[] codUsuario,
						                Integer codPlantilla,
						                String codTipoAviso,
										String tipoUsuario,
										Map<String, Object> destinatarios){
			FechaBean fechaPublicacion = new FechaBean();
			
			FechaBean fechaVigencia = new FechaBean();
			
			fechaVigencia.setFecha("31/12/9999");
			
			Map<String, Object> mapMensaje = new HashMap<String, Object>();
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("COD_ADUANA", codAduana);
			params.put("ANN_PRESEN", annPresen);
			params.put("COD_REGIMEN", codRegimen);
			params.put("NUM_DECLARACION", numDeclaracion);
			String desConsignatario = destinatarios.get("DES_CONSIGNATARIO") != null ? destinatarios.get("DES_CONSIGNATARIO").toString() : "-"; //consignatario			
			//mapMensaje.put("des_consignatario", StringEscapeUtils.escapeHtml(desConsignatario));//consignatario
			mapMensaje.put("cod_usuario", codUsuario);
			mapMensaje.put("funcionario", codFuncionario);
			mapMensaje.put("des_asunto", obtenerAsunto(codPlantilla,params));
			
			mapMensaje.put("tip_usuario", tipoUsuario);
			String desAgencia = destinatarios.get("DES_AGENCIA_ADUANAS") != null ? destinatarios.get("DES_AGENCIA_ADUANAS").toString() : "-"; //agencia de aduanas
			//mapMensaje.put("des_agencia", StringEscapeUtils.escapeHtml(desAgencia));//agencia de aduanas
		if (descripcion != null) {
			mapMensaje.put("descripcion", StringEscapeUtils.escapeHtml(descripcion.replaceAll("</?\\w++[^>]*+>", "")));
		}
		mapMensaje.put("cod_aduana", codAduana);
		mapMensaje.put("ann_presen", annPresen);
		mapMensaje.put("cod_regimen", codRegimen);
		mapMensaje.put("num_declaracion", numDeclaracion);		
		mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).
			                                            append("/").append(fechaPublicacion.getMes()).
		        append("/").append(fechaPublicacion.getAnho()).toString());
		
		if (destinatarios.containsKey("RECEPTOR")) {
			if (destinatarios.get("RECEPTOR").equals(Constantes.IMPORTADOR)) {
				mapMensaje.put("lbl_destinatario", "Sres. Consignatario:");
			    mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(desConsignatario));
			}
			if (destinatarios.get("RECEPTOR").equals(Constantes.AGENTE)) {
				mapMensaje.put("lbl_destinatario", "Sres. Agencia de Aduana:");
				mapMensaje.put("des_destinatario", StringEscapeUtils.escapeHtml(desAgencia));
			}
		}		
		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));		
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
	}

	//inicio lalberti DAM NUMERACION SIN ICA
	public void notificarRectificacionPuntoLlegada(String nroDeclaracion, String codUsuarioNotificado, String observacion){

		try{
			Map<String,Object>mapDatos = new HashMap<String, Object>();
			mapDatos.put("des_asunto", "AVISO RECTIFICACION PUNTO LLEGADA DAM DIFERIDA");
			mapDatos.put("tip_usuario", Constantes.TIPO_USUARIO_AVISO_OCE);
			mapDatos.put("cod_usuario", new String[]{codUsuarioNotificado});

			Map<String,Object> comunicado = new HashMap<String, Object>();
			comunicado.put("fecha_emision", (new FechaBean()).getFormatDate("dd/MM/yyyy"));
			comunicado.put("nroDeclaracion",nroDeclaracion);
			comunicado.put("observacion",observacion);

			mapDatos.putAll(comunicado);

			JsonSerializer json = new JsonSerializer()	;
			StringBuffer datos = new StringBuffer(json.serialize(mapDatos).toString());
			FechaBean fechaPublicacion = new FechaBean();
			FechaBean fechaVigencia = new FechaBean();
			fechaVigencia.setFecha("31/12/9999");

			PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
			publicacionAvisoService.insert(Constantes.COD_SERVICIO_AVISO_RECTIFICACION_PUNTO_LLEGADA,
														datos,
														Constantes.TIPO_AVISO_NOTIFICACION,
														fechaPublicacion.getTimestamp(),
														fechaVigencia.getTimestamp());
		}catch(Exception e){
			log.error(e);
		}

	}
	//fin lalberti DAM NUMERACION SIN ICA

	/**
		   * Obtener asunto.
		   *
		   * @param codPlantilla
		   *          the cod plantilla
		   * @return the string
		   * RIN13 SWF
		   */
	private String obtenerAsunto(Integer codPlantilla, Map<String, Object> params) {

		switch (codPlantilla) {
		    case 120:
		      return "NOTIFICACION DE COMUNICACION DE OBSERVACIONES DE REVISION DOCUMENTARIA";
		    case 121:
		      return "AVISO ELECTRONICO DE RECONOCIMIENTO FISICO DE OFICIO";
		    case 122:
		      return "NOTIFICACION DE OBSERVACIONES DE RECONOCIMIENTO FISICO";
		    case 123:
		      return "MENSAJE DE DILIGENCIA DE REGULARIZACION";
		    case 241:
			      return "NOTIFICACION ARRIBO DE MERCANCIAS FUERA DE PLAZO " + params.get("COD_ADUANA").toString().concat("-") + params.get("ANN_PRESEN").toString().concat("-") + params.get("COD_REGIMEN").toString().concat("-") + params.get("NUM_DECLARACION");  
		    default:
		      return "";
		    }
		  }
		  

}

