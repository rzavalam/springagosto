package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;

/**
 * <p>Title: DiligenciaSimplificadaServiceImpl</p>
 * <p>Description: Clase de Servicio para la Diligencia Simplificada</p>
 * <p>Copyright: Copyright (c) 2014</p>
 * <p>Company: SUNAT - INSI</p>
 * @author gbecerrav
 * @version 1.0
 */
public class DiligenciaSimplificadaServiceImpl implements DiligenciaSimplificadaService {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	private SerieService serieService;
	private DiligenciaService diligenciaService;
	private DeclaracionService declaracionService;
	private AsignacionService asignacionService;
	private FabricaDeServicios  fabricaDeServicios;//adicionado por PAS20165E220200032
	private PagarantiaDAO pagarantiaDAO;//PAS20165E220200032

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	private CabDeclaraDAO cabDeclaraDAO;//PAS20165E220200032
	
	@Override
	public boolean isDiligenciaSimplificada(Long numeroCorrelativo)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - isDiligenciaSimplificada");
		}
		
		//Se obtiene por cat�logo la cantidad m�nima de series para que se considere diligencia simplificada
		int cantidadMinimaSeries = Constantes.CANTIDAD_SERIES_DS;
		
		Map<String, Object> paramsSerie = new HashMap<String, Object>();
		paramsSerie.put("numeroCorrelativo", numeroCorrelativo);
		paramsSerie.put("indicadorEliminacion", Constantes.IND_NO_ELIMINADO);
		int cantidadSeries = this.serieService.obtenerCantidadSeries(paramsSerie);
		
		if(cantidadSeries >= cantidadMinimaSeries){
			return true;
		}else{
			return false;
		}
	}
	/**Inicio cambios por PAS20165E220200032***/
	@Override
	public void grabarDiligenciaSimplificada(Diligencia diligencia, boolean indicadorAnticipado){
		grabarDiligenciaSimplificada( diligencia,  indicadorAnticipado, false, new HashMap<String, Object>());
	}
	/**Fin cambios por PAS20165E220200032***/
	@Override
	public void grabarDiligenciaSimplificada(Diligencia diligencia, boolean indicadorAnticipado,boolean indicadorGrabarPostLevante, Map<String, Object> declaracion )/**cambios por PAS20165E220200032***/
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - grabarDiligenciaSimplificada");
		}
		//Se registra la diligencia simplificada
		this.diligenciaService.insertarDiligencia(diligencia);
		
		//Se registra el indicador anticipado
		if(indicadorAnticipado){
			this.declaracionService.insertarIndicadorDua(diligencia.getNumeroCorrelativo().toString(), Constantes.IND_DUA_RECTI_ANTICIPADO, Constantes.IND_DUA_P_ESP);
		}
		
		//Cambia el estado de la declaraci�n a En Revisi�n
		DUA dua = new DUA();
		dua.setCodEstdua(Constantes.ESTADO_DECLARACION_DILIGENCIA_CONFORME);
		dua.setNumcorredoc(diligencia.getNumeroCorrelativo());
		this.declaracionService.actualizarDUAByPrimaryKey(dua);
		
		//Retira la Declaraci�n de la bandeja de pendientes del funcionario
		Map<String, Object> paramsAsignacion = new HashMap<String, Object>();
		paramsAsignacion.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_CON_REGISTRO_DE_LA_DILIGENCIA);
		paramsAsignacion.put("num_corredoc", diligencia.getNumeroCorrelativo());
		paramsAsignacion.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO);
		paramsAsignacion.put("fec_termrev", "fec_termrev");
		paramsAsignacion.put("cod_funcionario", diligencia.getCodigoFuncionario().trim());
		this.asignacionService.actualizarEstadoRevision(paramsAsignacion);
		
		/**Inicio cambios por PAS20165E220200032***/
     	 if(indicadorGrabarPostLevante){
     	
	     	 //Date fechaDiligencia = diligencia.getFechaDiligencia();
	     	 
	     	 //Inicio  C�lculo de plazo 3 meses, dias h�biles:
	     	 Date fechaConclusion=new Date();
	     	 String resultadoDias="";
	     	 fechaConclusion = SunatDateUtils.addMonth(new Date(), 3);//la fecha
	   		 Map<String,Object> paramsFecha = new HashMap<String,Object>();
	   		 paramsFecha.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaConclusion));
			 paramsFecha.put("FECHAHASTA", 1);
			 paramsFecha.put("TIPO", 2);
			 paramsFecha.put("INCLUYE", "S");
			 paramsFecha.put("SUSPENDE", "S");		
			 resultadoDias=(String)((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(paramsFecha);//ya esta en YYYYMMDD
			 
			 fechaConclusion=SunatDateUtils.getDateFromInteger( SunatNumberUtils.toInteger(resultadoDias));
			//Fin C�lculo de plazo 3 meses, dias h�biles	
	   		 Map<String, Object> mapParam = new HashMap<String, Object>();
	         mapParam.put("cADUAFECTA", String.valueOf(declaracion.get("COD_ADUANA")));
	         mapParam.put("cANNAFECTA", String.valueOf(declaracion.get("ANN_PRESEN")));
	         mapParam.put("cNUMAFECTA", SunatStringUtils.lpad(String.valueOf(declaracion.get("NUM_DECLARACION")), 6, '0'));
	         mapParam.put("cREGIAFECTA", String.valueOf(declaracion.get("COD_REGIMEN")));
	         mapParam.put("cFECHAFECTA", Integer.valueOf(resultadoDias));
	         mapParam.put("cTRANS", "2");
	         log.debug("PARAM = " + mapParam);
	         String resultado = this.pagarantiaDAO.registroFechaTermino(mapParam);
	         log.debug("PAGARANTIA.FNFECHA resultado = " + resultado);
	         Map<String, Object> params = new HashMap<String,Object>();
	         params.put("FEC_VENCONCLU", fechaConclusion);
	         params.put("NUM_CORREDOC", diligencia.getNumeroCorrelativo());
			 declaracion.putAll(params);
	         cabDeclaraDAO.update(declaracion);
			 
			 /**INICIO REGISTRO DE PLAZOS**/
				Map <String, Object> parametros = new HashMap<String, Object>(); 
				long diferenciaFechas;
				diferenciaFechas = 0;
				
				parametros.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				parametros.put("COD_TIPPLZ", "06");
				parametros.put("FEC_INICIO", SunatDateUtils.getCurrentDate());
				parametros.put("FEC_FIN", fechaConclusion);
				parametros.put("CNT_DURACION", diferenciaFechas);
				parametros.put("COD_UNIMED", "2");
				parametros.put("COD_ESTPLZ", "1");
				
				((PlazosProcesoDAO)fabricaDeServicios.getService("plazosprocesoDAO")).insert(parametros);
			/**FIN REGISTRO DE PLAZOS**/
     	 } 
	      /**Fin cambios por PAS20165E220200032***/
		
		if (log.isDebugEnabled()) {
			log.debug("Fin - grabarDiligenciaSimplificada");
		}
		
	}

	@Override
	public void grabarDiligenciaConclusionSimplificada(Diligencia diligencia)
			throws ServiceException {
		if (log.isDebugEnabled()) {
			log.debug("Inicio - grabarDiligenciaConclusionSimplificada");
		}
		
		//Se registra la diligencia de conclusion de despacho simplificada
		this.diligenciaService.insertarDiligencia(diligencia);
		
		//Actualiza la declaraci�n
		DUA dua = new DUA();
		dua.setNumcorredoc(diligencia.getNumeroCorrelativo());
		dua.setCodEstdua(Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO);
		dua.setFecconclusion(diligencia.getFechaDiligencia()); //fecha actual
		this.declaracionService.actualizarDUAByPrimaryKey(dua);
			
		//Retira la declaraci�n de la bandeja de pendientes del funcionario
		Map<String, Object> paramsAsignacion = new HashMap<String, Object>();
		paramsAsignacion.put("cod_estrev", ConstantesDataCatalogo.ESTADO_ASIGNACION_CON_REGISTRO_DE_LA_DILIGENCIA);
		paramsAsignacion.put("num_corredoc", diligencia.getNumeroCorrelativo());
		paramsAsignacion.put("cod_estrev_ant", ConstantesDataCatalogo.ESTADO_ASIGNACION_ASIGNADO_PARA_CONCLUSION_DE_DESPACHO);
		paramsAsignacion.put("fec_termrev", "fec_termrev");
		paramsAsignacion.put("cod_funcionario", diligencia.getCodigoFuncionario().trim());
		this.asignacionService.actualizarEstadoRevision(paramsAsignacion);
				
		if (log.isDebugEnabled()) {
			log.debug("Fin - grabarDiligenciaConclusionSimplificada");
		}
		
		/**Inicio cambios por PAS20165E220200032***/

        String resultadoDias= (String) SunatDateUtils.getCurrentFormatDate("yyyyMMdd");
       		 
        Map<String, Object> mapParam = new HashMap<String, Object>();
        mapParam.put("cADUAFECTA", String.valueOf(diligencia.getCodAduana()));
        mapParam.put("cANNAFECTA", String.valueOf(diligencia.getAnnPresen()));
        mapParam.put("cNUMAFECTA", SunatStringUtils.lpad(String.valueOf(diligencia.getNumDeclaracion()), 6, '0'));
        mapParam.put("cREGIAFECTA", String.valueOf(diligencia.getCodRegimen()));
        mapParam.put("cFECHAFECTA", Integer.valueOf(resultadoDias));
        mapParam.put("cTRANS", "2");
        log.debug("PARAM = " + mapParam);
        String resultado = this.pagarantiaDAO.registroFechaTermino(mapParam);
        log.debug("PAGARANTIA.FNFECHA resultado = " + resultado);

        /**Fin cambios por PAS20165E220200032***/ 
		
	}
	

    /**Inicio de cambios PAS20165E220200032**/
    public void grabarIndicadorPostLevante(String numCorredoc, Date fechaDeclaracion){
		if (log.isDebugEnabled()) {
			log.debug("Inicio - grabarIndicadorPostLevante");
		}
		
		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		 
	   	 if(getDeclaracionService.esVigenteNuevaLGAPorFecha(fechaDeclaracion)){
	   		 declaracionService.insertarIndicadorDua(numCorredoc, Constantes.IND_DUA_POST_LEVANTE, Constantes.IND_DUA_P_ESP);
	   	 } 
   	 
		if (log.isDebugEnabled()) {
			log.debug("Fin - grabarIndicadorPostLevante");
		}
		
	}	
    /**Fin de cambios PAS20165E220200032**/
    
	/**
	 * @return the serieService
	 */
	public SerieService getSerieService() {
		return serieService;
	}

	/**
	 * @param serieService the serieService to set
	 */
	public void setSerieService(SerieService serieService) {
		this.serieService = serieService;
	}

	/**
	 * @return the diligenciaService
	 */
	public DiligenciaService getDiligenciaService() {
		return diligenciaService;
	}

	/**
	 * @param diligenciaService the diligenciaService to set
	 */
	public void setDiligenciaService(DiligenciaService diligenciaService) {
		this.diligenciaService = diligenciaService;
	}

	/**
	 * @return the declaracionService
	 */
	public DeclaracionService getDeclaracionService() {
		return declaracionService;
	}

	/**
	 * @param declaracionService the declaracionService to set
	 */
	public void setDeclaracionService(DeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	/**
	 * @return the asignacionService
	 */
	public AsignacionService getAsignacionService() {
		return asignacionService;
	}

	/**
	 * @param asignacionService the asignacionService to set
	 */
	public void setAsignacionService(AsignacionService asignacionService) {
		this.asignacionService = asignacionService;
	}

	public PagarantiaDAO getPagarantiaDAO() {
		return pagarantiaDAO;
	}

	public void setPagarantiaDAO(PagarantiaDAO pagarantiaDAO) {
		this.pagarantiaDAO = pagarantiaDAO;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}
}
