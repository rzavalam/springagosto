package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.despacho.model.dao.NotiDudaCabDAO;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/**
 * The Class DudaRazonableServiceImpl.
 */
@SuppressWarnings({ "rawtypes" })
public class DudaRazonableServiceImpl implements DudaRazonableService
{


  private NotiDudaCabDAO notiDudaCabDAO;



  /**
   * M�todo que busca si tiene duda razonable por concluir.
   *
   * @param params
   *          the params
   * @return Boolean
   * @throws ServiceException
   *           the service exception
   */
  public Boolean tieneDudaRazonablePendPorConcluir(Map params) throws ServiceException
  {
    try
    {
      Map<String, Object> parametros = new HashMap<String, Object>();
// RIN16
      parametros.put("codi_aduan", params.get("COD_ADUANA").toString());
      parametros.put("ano_prese", params.get("ANN_PRESEN").toString());
      parametros.put("codi_regi", params.get("COD_REGIMEN").toString());
      parametros.put("nume_corre", params.get("NUM_DECLARACION").toString());
      parametros.put("tipo_eval", " ");

      return this.notiDudaCabDAO.findDudaRazPendConcluByDocuAndResEval(parametros);
    }
    catch (Exception e)
    {
      throw new ServiceException(this, e);
    }
  }
  // RIN16
  /**
   * {@inheritDoc}
   */
  public boolean tieneDudaRazonablePendPorConcluir(Declaracion declaracion) throws ServiceException {
	  Map<String, Object> parametros = new HashMap<String, Object>();
	  parametros.put("COD_ADUANA", declaracion.getCodaduana());
	  parametros.put("ANN_PRESEN", declaracion.getDua().getAnnpresen());
	  parametros.put("NUM_DECLARACION", SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0'));
	  parametros.put("COD_REGIMEN", declaracion.getCodregimen());
	  Boolean respuesta = this.tieneDudaRazonablePendPorConcluir(parametros); 
	  return respuesta.booleanValue();
  }
  

  //inicio P21-P22
  
  public Boolean duaTieneNotificacionDudaRazonable(Map params) throws ServiceException{
	  List<Map<String,Object>> result = notiDudaCabDAO.listDudaByParameterMap(params);
	  if(result==null || result.isEmpty())
		  return false;
	  else
		  return true;
	  
  }
  //fin P21-P22
  
  /**
   * Sets the noti duda cab dao.
   *
   * @param notiDudaCabDAO
   *          the new noti duda cab dao
   */
  public void setNotiDudaCabDAO(NotiDudaCabDAO notiDudaCabDAO)
  {
    this.notiDudaCabDAO = notiDudaCabDAO;
  }
}