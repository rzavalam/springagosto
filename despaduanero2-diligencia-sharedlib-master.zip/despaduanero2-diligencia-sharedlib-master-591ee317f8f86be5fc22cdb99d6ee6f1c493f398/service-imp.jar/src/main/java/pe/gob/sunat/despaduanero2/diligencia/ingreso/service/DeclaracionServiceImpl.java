package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.math.BigDecimal;
import java.sql.SQLException;/* PAS20175E220200051 */
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.administracion2.tramite.util.ConstantesTramite;
import pe.gob.sunat.controladuanero2.ingreso.postlevante.service.SolicitudPostLevanteService;
//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.rectificacion.RectificacionAbstract;
import pe.gob.sunat.despaduanero.catalogo.tg.model.Feria;
import pe.gob.sunat.administracion2.tramite.model.dao.ExpediDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.service.FeriasDAOService;
import pe.gob.sunat.despaduanero.despacho.comun.tr.model.dao.MovEConfirmaDAO;
import pe.gob.sunat.despaduanero2.dudarazonable.model.NotificaDuda;
import pe.gob.sunat.despaduanero2.dudarazonable.service.DudaConsultaService;
import pe.gob.sunat.sigad.diligencia.service.SolicitudElectronicaReconocimientoFisicoService;
import pe.gob.sunat.sigad.sini.service.SiniConsultaService;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDocu;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroEspeDispo;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroEspeDocu;
import pe.gob.sunat.despaduanero2.declaracion.bean.ConsultaDocuTransManifiesto; //jlunah
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDispoDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionManualService;
import pe.gob.sunat.despaduanero2.asignacion.service.EspecialistaService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.Puerto;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
// RIN16
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.bean.ReporteBloqueoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ModelFactory;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValModalidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
//INICIO RIN08
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
//FIN RIN08
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.ReporteDeclaracionBloqueada;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAccionDuaDAO;
/* P14 - 3014 - Inicio - lrodriguezc */
import pe.gob.sunat.despaduanero2.declaracion.model.IndicadorDeclaracionDescripcion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiDeclaraDAO; // RIN 10
/* P14 - 3014 - Final - lrodriguezc */
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CanalesDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
/* PAS20145E220000399 INICIO GGRANADOS */
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DfrecdocDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DirecepDAO;
/* PAS20145E220000399 FIN GGRANADOS */
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FinUbicacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
/* PAS20145E220000399 INICIO GGRANADOS */
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.SdrecepDAO;
/* PAS20145E220000399 FIN GGRANADOS */
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.AutorizacionZonaPrimariaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.service.ObservacionService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.RegularizacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service.PlantillaFactory;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ComunicacionDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.MedioTransDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapUtils;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.StringUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.dudarazonable.service.DudaConsultaService;//p24 pase99
import pe.gob.sunat.despaduanero2.manifiesto.model.Datado;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporteHouse;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdage;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2ValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoDeTransporteService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.MotivoSolicitud;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.SolicitudAutorizacionZonaPrimaria;
import pe.gob.sunat.despaduanero2.model.SolicitudPostLevante;
import pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto;
import pe.gob.sunat.despaduanero2.model.dao.AutorizaInternacionDAO;/* PAS20175E220200051 */
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.MotivoSoliDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.SoliPostLevanteDAO;
import pe.gob.sunat.despaduanero2.model.dao.SoliProrrogaDAO;//RIN10
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.seleccion.model.dao.CabTipoAforoDeclaraDAO;
import pe.gob.sunat.despaduanero2.seleccion.model.dao.FraudesDAO;
import pe.gob.sunat.despaduanero2.seleccion.service.SeleccionService;
import pe.gob.sunat.despaduanero2.service.SoliAnulacionService;
//import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
// RIN16
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
// RIN16
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.lang.Bean;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
// RIN16
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.prevcontrabando2.ace.service.AceValidacionesService;
import pe.gob.sunat.prevcontrabando2.ace.service.ConsultaAceService;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovDuasActasDAO;  //RIN13
import pe.gob.sunat.prevcontrabando2.ace.service.ConsultaAceService;
import pe.gob.sunat.prevcontrabando2.ace.service.AceValidacionesService;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.recauda2.garantia.service.ConsultaCtaCteService;
import pe.gob.sunat.recauda2.genadeudo.service.FuncionesLiquidacionService;
import pe.gob.sunat.recauda2.genadeudo.service.GarantiaOperativaService;
// RIN16
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.servicio2.registro.service.SprDAOService;
import pe.gob.sunat.sigad.diligencia.service.SolicitudElectronicaReconocimientoFisicoService;
import pe.gob.sunat.sigad.sini.service.SiniConsultaService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
////PAS20145E220000583-Consulta SERF
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.dudarazonable.model.CabDudaRazonable;
import pe.gob.sunat.despaduanero2.dudarazonable.service.DudaBusquedaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
//<RIN10> 3012 ERUESTAA
import pe.gob.sunat.recauda2.garantia.model.dao.CabCtaCteGarDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.MovCtaCteGaraDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.CalculaDiaDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.ControlVigenciaService;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.DocumentoCanal;
import pe.gob.sunat.despaduanero2.declaracion.api.riesgo.model.DocumentoRiesgo;
import pe.gob.sunat.sigad.manifiesto.service.ManifiestoDefinitivoService;
/**
 * The Class DeclaracionServiceImpl.
 *
 * @author rmontesc, rdelosreyes, wmostacero
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class DeclaracionServiceImpl implements DeclaracionService {
	protected final Log              log = LogFactory.getLog(this.getClass());

	private CabDeclaraDAO            cabDeclaraDAO;

	@Deprecated  //RIN13
	private ObservacionDAO observacionDAO;

	private EspeDocuDAO              espeDocuDAO;

	private SolicitudService         solicitudService;

	private CabManifiestoDAO         manifiestoDAO;

	private DocuTransDAO             gralDocTranporteDAO;

	private CabCertiOrigenDAO        cabCertiOrigenDAO;

	private MedioTransDAO            medioTransDAO;

	private EquipamientoDAO          equipamientoDAO;

	@Deprecated  //RIN13
	private IndicadorDUADAO indicadorDuaDAO;
	private SoporteService           soporteService;
	//  private DdpDAO                   ddpDAO;
	private CatalogoAyudaService     catalogoAyudaService;
	private DocuPreceDuaDAO          docuPreceDuaDAO;
	private CabTipoAforoDeclaraDAO   cabTipoAforoDeclaraDAO;
	private CanalesDAO               canalesDAO;
	private DocAutAsociadoDAO        docAutAsociadoDAO;
	private CabSolrectiDAO           cabSolRectiDAO;
	private FinUbicacionDAO          finUbicacionDAO;
	//  private SprDAO                   sprDAO;
	private RelacionDocDAO           relacionDocDAO;

	/* PAS20145E220000399 INICIO GGRANADOS */
	//  private DirecepDAO               direcepDAO;
	/* PAS20145E220000399 FIN GGRANADOS */

	private DudaRazonableService     dudaRazonableService;

	private ValidaDiligenciaService  validaDiligenciaService;

	//  private FeriasDAO                feriasDAO;

	private PagarantiaDAO            pagarantiaDAO;

	private DiasUtilesDAO            diasUtilesDAO;

	private FabricaDeServicios       fabricaDeServicios;

	private HotSwappableTargetSource swapperDatasource;

	private PlazosProcesoDAO         plazosProcesoDAO;
	/* PAS20145E220000399 INICIO GGRANADOS */
	//  private DfrecdocDAO              dfrecdocDAO;
	//  private SdrecepDAO               sdrecepDAO;
	/* PAS20145E220000399 INICIO GGRANADOS */

	private FraudesDAO               fraudesDAO;

	private ItemFacturaDAO           itemFacturaDAO;

	private FormBProveedorDAO        formBProveedorDAO;

	private EspeDispoDAO             espeDispoDAO;

	private ParticipanteDocDAO       participanteDocDAO;

	private VFOBProvisionalDAO       vFOBProvisionalDAO;

	private ManifiestoSigadService manifiestoSigadService;
	private Datado2ValidacionService datadoValidacionService;

	private SerieService             serieService;

	private DiligenciaService        diligenciaService;

	private DeudaService             deudaService;

	/* olunar - 309 */
	private ConsultaService          consultaService;
	/* fin */


	private DdpDAOService				ddpDAOService;
	private SprDAOService				sprDAOService;	

	//INICIO RIN08
	private DetDeclaraDAO detDeclaraDAO;
	//FIN RIN08

	//Lmvr- inicio - Complemento de rectificacion
	private FeriasDAOService 			feriasDAOService;
	Boolean tieneExpedienteAsociadoRUCRectificacion = false;


	//PAS20145E220000583-INICIO Consulta SERF
	private MovEConfirmaDAO movEConfirmaDAO;
	/*RIN13FSW-INICIO*/

	@Autowired
	@Qualifier("diligencia.ingreso.cabDiligenciaDef")
	private CabDiligenciaDAO         cabDiligenciaDAO;
	private ExpediDAO expediDAO;
	//private DeclaracionService declaracionService;
	private DocumentoDeTransporteService documentoDeTransporteService;
	private DisposicionMercanciaService disposicionMercanciaService;
  
	/* fin */

	/* jlunah - rin13*/
	private ConvenioSerieDAO convenioSerieDAO;
	/* fin*/

	/* rcalle - Inicio */  
	private CabAccionDuaDAO cabAccionDuaDAO;
	/* rcalle - Fin */
	/*RIN13FSW-FIN*/

	//Lmvr- fin - Complemento de rectificacion
	//gmontoya
	//private AduanaRol aduanaRol;
	// <RIN10> 3014 ERUESTAA
	private CabAdiDeclaraDAO cabAdiDeclaraDAO;
	// </RIN10> 3014 ERUESTAA

	//    <RIN10> 3012 ERUESTAA
	private CabCtaCteGarDAO cabCtaCteGarDAO;
	private MovCtaCteGaraDAO movCtaCteGaraDAO;
	private CalculaDiaDAO calculaDiaDAO;    
	//  </RIN10> 3012 ERUESTAA

	/*INICIO-P34 PAS20165E220200126 AFMA*/
	private static final String REGU = "11";
	private static final String LEGAJO = "19";
	/*FIN-P34 PAS20165E220200126 AFMA*/

	/*Inicio  PAS20165E220200032*/
	 public static final String TIPO_MOTIVO_DUDA = "02";
	 public static final String IND_MOTIVO_ACTIVO = "0";
	 public static final String TIPO_MOTIVO_IND_RIESGO = "04";
     public static final String TIPO_SOLICITUD_POSTLEVANTE = "25";
     public static final String ESTADO_SOL_POSTLEV_ACEPTADO = "01";
     public static final String ESTADO_SOL_POSTLEV_RECHAZADO = "02";
     public static final String ESTADO_SOL_POSTLEV_REGISTRADO = "00";
     public static final String ESTADO_SOL_POSTLEV_ANULADA = "99";     
	 /*Fin PAS20165E220200032*/
     public static final String BASE_API_RIESGO_PATH = "http://api.sunat.peru/v1/gestionriesgo/seleccion";
 	 public static final String TAG_API_RIESGO = "WS-API-RIESGO";
	/**
	 * Metodo que implenta la funcionalidad de carga de la declaracion. Detallado
	 * en el Diagrama IngresoDiligencia_CUR_11_14_15_99 Desarrollado por rmontes
	 *
	 * @param params
	 *          the params
	 * @return the map
	 * @throws ServiceException
	 *           the service exception
	 */
	public Map<String, Object> obtenerDeclaracion(Map<String, Object> params) throws ServiceException
	{
		Map<String, Object> res = null;
		String tipoRegimen = (String) params.get("COD_REGIMEN");
		try
		{
			//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			params.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_DECLA);
			//FIN RTINEO
			res = obtenerDeclaracionPorRegimen(params, tipoRegimen);
			if(!MapUtils.esMapaNuloOVacio(res))
			{
				//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				//obtenerDescripcionObservaciones(res);
				//RTINEO FIN
				// Cargamos los datos de ddp
				obtenerDescripcionParticipante(res, "NUM_DOCIDENT_PDD");
				// Cargamos los datos de ddp
				obtenerDescripcionParticipante(res, "NUM_DOCIDENT_PDF");
				// Obtenemos el nombre del importador
				if(sonValidosParametrosParticipante(res, "PIM"))
				{
					if(esTipoDocumentoDentroDeLista(res.get("COD_TIPDOC_PIM").toString(),
							Constantes.TIPO_DOC_DNI,
							Constantes.TIPO_DOC_RUC,
							Constantes.TIPO_DOC_PASAPORTE))
					{
						obtenerDatosParticipante(res, "PIM");
					}
				}
				// Obtenemos el nombre del declarante
				if(sonValidosParametrosParticipante(res, "PDE"))
				{
					if(esTipoDocumentoDentroDeLista(res.get("COD_TIPDOC_PDE").toString(),
							Constantes.TIPO_DOC_DNI,
							Constantes.TIPO_DOC_RUC))
					{
						obtenerDatosParticipante(res, "PDE");
					}
				}
				// Obtenemos el nombre del transportista
				if(sonValidosParametrosParticipante(res, "PTR"))
				{
					obtenerDatosParticipante(res, "PTR");
				}
				Map prmtDUtil = new HashMap();
				prmtDUtil.put("FECHAHASTA", "1");
				prmtDUtil.put("TIPO", "2");
				prmtDUtil.put("INCLUYE", "S");
				prmtDUtil.put("SUSPENDE", "S");
				if(tipoRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)){
					obtenerFechaVencimientoMaximoReg20(res, prmtDUtil);
				}
				if (params.get("EN_PROCESO") != null && "1".equals((String) params.get("EN_PROCESO"))
						|| StringUtils.equals((String) params.get("tipoDiligencia"),Constantes.MODULO_RECTIFICACION_OFICIO))
				{
					obtenerFechaVencimientoMaximoOtrosCasos(res, prmtDUtil);
				}
				// Evaluacion: Garantia Art 160 D.Leg 1053
				res.put("NUM_CTACTE_DESC", "");
				if(!MapUtils.esValorMapaNuloOVacio(res, "NUM_CTACTE"))
				{
					res.put("NUM_CTACTE_DESC", "Art. 160 D.Leg 1053");
				}
				// PAS20145E220000583-INICIO Consulta SERF
				// verifica que la declaracin con estado 17
				// no tenga registrada una Solicitud Electrnica de
				// Reconocimiento Fsico (SERF).
				if (res.get("COD_ESTDUA").equals("17"))
				{
					Map<String, Object> paramsSerf = new HashMap<String, Object>();
					paramsSerf.put("NUME_CORRE", params.get("NUM_DECLARACION"));
					paramsSerf.put("CODI_ADUAN", res.get("COD_ADUANA"));
					paramsSerf.put("ANO_PRESE", res.get("ANN_PRESEN"));
					paramsSerf.put("COD_REGI", res.get("COD_REGIMEN"));	
					/*RIN08 INICIO*/					
					SolicitudElectronicaReconocimientoFisicoService solicitudElectronicaReconocimientoFisicoService = fabricaDeServicios.getService("sigad.diligencia.solicitudElectronicaReconocimientoFisicoService");
					//List<Map<String,Object>> list = movEConfirmaDAO.listarSolicitudes(paramsSerf);//RIN08 COMENTO
					List<Map<String,Object>> list = solicitudElectronicaReconocimientoFisicoService.listarSolicitudes(paramsSerf);
					/*RIN08 FIN*/	
					if(!CollectionUtils.isEmpty(list)){
						res.put("SERF", Constantes.ESTADO_SERF);
					}
				}
				// PAS20145E220000583-FIN Consulta SERF
				verificarDUASujetaRegularizacion(res);
				verificarDUATieneRegPrecedente(res);
				//INICIO JMCV
				verificarIndicadorTipoAbandono(res);
				//FIN JMCV
				// obteniendo la fecha de diligencia
				// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE MODIFICA METODO COMENTANDO EL CODIGO QUE SE ENCUENTRA DEBAJO DE ESTE COMENTARIO  
				/*Map mDuaDiligenciada = validaDiligenciaService.findDuaDiligenciada(res.get("NUM_CORREDOC").toString());
        if (!CollectionUtils.isEmpty(mDuaDiligenciada))
        {
          res.put("FEC_DILIGENCIA", mDuaDiligenciada.get("FEC_DILIGENCIA"));
        }*/
				res.put("FEC_DILIGENCIA", res.get("FEC_DILIGENCIA"));
				// FIN HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				if(res.containsKey("FEC_SOLICITUD")){
					res.put("FEC_SOLICITUD_RECTI",res.get("FEC_SOLICITUD"));
				}else{
					res.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(res.get("NUM_CORREDOC")));
				}
				//RTINEO FIN
				obtenerIndicadorFormatoB(res);
				res.put("FEC_VENREGIMEN", SunatDateUtils.getFormatDate((Date) res.get("FEC_VENREGIMEN"), "dd/MM/yyyy"));
				//INICIO JMCV
				List<Map<String, Object>> listIndicadoresDua = obtenerIndicadoresDua(res);
				res.put("LIST_INDICADORES_DUA", listIndicadoresDua);
				//FIN JMCV
					//INICIO P25 PASE129 - PAS20165E220200099
				String etiqImpFrec = "";
				if ( this.isImportadorFrecuente(listIndicadoresDua) ) {
					//res.put("impFrecuente", "Importador Frecuente");
					//PAS20181U220200011 osancheza - se cambia "Importador frecuente" en duro por catalogo 302, datacat 05
					CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");//PAS20191U220200013
					etiqImpFrec = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_DE_DATOS_INDICADORES, ConstantesDataCatalogo.INDICADOR_IMPORTADOR_FRECUENTE).getDesDatacat();
					res.put("impFrecuente", etiqImpFrec);
				}else {
					res.put("impFrecuente", " ");
				}
				//region amancillaa SDA2-RIN18-PAS20171U220200035
				Long numCorreDocDUA  = SunatNumberUtils.getLongFromString(res.get("NUM_CORREDOC").toString());
				String etiqOperadorOEA = this.obtenerEtiquetaOEA(numCorreDocDUA).trim();
				res.put("etiqOperadorOEA", etiqOperadorOEA);
				//if(!etiqOperadorOEA.equals(""))
				//	etiqImpFrec = etiqImpFrec + " / " + etiqOperadorOEA;
				res.put("impFrecuente",etiqImpFrec);
				//endregion amancillaa
			}
		}catch (DataAccessException e)
		{
			log.error(e);
			throw new ServiceException(this,"Ha ocurrido un error al obtener informacion de la dua");
		}
		catch (Throwable e)
		{
			log.error(e);
			throw new ServiceException(this,"Ha ocurrido un error inesperado en el metodo");
		}
		return res;
	}

	//region amancillaa SDA2-RIN18-PAS20171U220200035
	public String obtenerEtiquetaOEA(Long numCorreDoc){

		String oea ="";
		pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
		DatoIndicadores indicadorFrecuente = indicadorDuaService.obtenerIndicadorDeclaracion(numCorreDoc.toString(), ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
		if(indicadorFrecuente!=null && indicadorFrecuente.getIndicadorActivo().equals(ConstantesDataCatalogo.IND_ACTIVO)){
			oea = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_DE_DATOS_INDICADORES, ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA).getDesDatacat();
			
		}

		return oea;
	}

	//endregion amancillaa

	//INICIO-VRD-PASE 179 
	public Map<String, Object> obtenerEstadosHistoricos(Map<String, Object> params) throws ServiceException {
		Map<String, Object> res = new HashMap<String, Object>(); 
		Map<String, Object> paramsT = new HashMap<String, Object>();
		paramsT.put("NUM_CORREDOC", params.get("NUM_CORREDOC"));

		List<Map<String,Object>> registrosEstados = null;
		registrosEstados = this.cabDeclaraDAO.obtenerEstadosHistorico(paramsT);

		if(!CollectionUtils.isEmpty(registrosEstados)) {
			for (Map item : registrosEstados) {
				Map<String,Object> parametroBusquedaRRHH = new HashMap<String, Object>();
				parametroBusquedaRRHH.put("cod_pers", item.get("COD_USUREGIS").toString());

				pe.gob.sunat.rrhh2.service.ConsultaService consultaServiceRRHH = (pe.gob.sunat.rrhh2.service.ConsultaService) fabricaDeServicios.getService("rrhh2.service.consultaService");
				List<Map<String, Object>> detallesFuncionario = consultaServiceRRHH.consultarPersonal(parametroBusquedaRRHH);

				if (detallesFuncionario!=null && detallesFuncionario.size()>0){
					String nombre=detallesFuncionario.get(0).get("t02ap_pate") + " " + detallesFuncionario.get(0).get("t02ap_mate") + " " + detallesFuncionario.get(0).get("t02nombres");
					item.put("FUNCIONARIO", nombre);
				} else {
					item.put("FUNCIONARIO", "Usuario NO definido");
				}										
			}
		}        
		res.put("registros", registrosEstados);	    
		return res;
	}
	//FIN-VRD-PASE 179




	//INICIO JMCV
	/**
	 * Verifica si una Declaracion tiene un tipo de Abandono
	 * @param res
	 * @return
	 */
	private void verificarIndicadorTipoAbandono(Map<String, Object> res)
	{
		// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE MODIFICA METODO
		if (res.containsKey("COD_DES_INDICADOR")) {
			verificarIndicadorTipoAbandonoNew(res);
		} else {
			// FIN HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			res.put("ind_activo","1");  
			List<Map<String, Object>> list = indicadorDuaDAO.findIndicadorTipoAbandono(res);
			if(!CollectionUtils.isEmpty(list))
			{
				for (Map item : list)
				{
					res.put("COD_ABANDONO", item.get("COD_INDICADOR").toString().trim());
					res.put("DES_ABANDONO", item.get("DES_INDICADOR").toString().trim());
				}
			}
		} // HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	}
	//FIN JMCV

	/**
	 * 
	 * @param res
	 */
	// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE CREA METODO
	private void verificarIndicadorTipoAbandonoNew(Map<String, Object> res) {
		//el dato viene concatenado "COD_INDICADOR-DES_INDICADOR"
		String datoIndicadorFull = (String) res.get("COD_DES_INDICADOR");
		if (datoIndicadorFull != null) {
			String [] datos = datoIndicadorFull.split("-");
			String codigoIndicadorAbandono = datos[0];
			String descripcionIndicadorAbandono = datos[1];
			res.put("COD_ABANDONO", codigoIndicadorAbandono);
			res.put("DES_ABANDONO", descripcionIndicadorAbandono);
		}
	}

	/**
	 * Obtiene la declaracion de acuerdo al regimen enviado como parametro
	 * @param paramsDeclaracion
	 * @param tipoRegimen
	 * @return
	 */
	private Map<String, Object> obtenerDeclaracionPorRegimen(Map<String, Object> paramsDeclaracion, String tipoRegimen)
	{
		Map<String, Object> declaracion;
		// Ejecutamos el metodo de acuerdo al tipo de regimen
		if (tipoRegimen.equals(Constantes.REGIMEN_80_TRANSITO))
		{
			declaracion = cabDeclaraDAO.joinCabAdiTransitoFindByDeclaracion(paramsDeclaracion);
		}
		else if (tipoRegimen.equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))
		{
			declaracion = cabDeclaraDAO.joinCabAdiImpoConsuFindByDeclaracion(paramsDeclaracion);
		}
		else if (tipoRegimen.equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)
				|| tipoRegimen.equals(Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO))
		{
			declaracion = cabDeclaraDAO.joinCabAdiATPAFindByDeclaracion(paramsDeclaracion);
		}
		else
		{
			declaracion = cabDeclaraDAO.joinParticipanteFindByDeclaracion(paramsDeclaracion);
		}
		return declaracion;
	}

	/**
	 * @param res
	 * @param prmtDUtil
	 */
	private void obtenerFechaVencimientoMaximoOtrosCasos(Map<String, Object> res, Map prmtDUtil)
	{
		if(!MapUtils.esValorMapaNuloOVacio(res, "NUM_CTACTE"))
		{
			Map prmtGaran = new HashMap();
			prmtGaran.put("cRUC", res.get("NUM_DOCIDENT_PIM").toString().trim());
			prmtGaran.put("cADUANA", res.get("COD_ADUANA").toString().trim());
			prmtGaran.put("cANO", res.get("ANN_PRESEN").toString().trim());
			prmtGaran.put("cREGIMEN", res.get("COD_REGIMEN").toString().trim());
			prmtGaran.put("cNUMERO", res.get("NUM_CTACTE").toString().trim());
			prmtGaran.put("cMODULO", "TA");
			prmtGaran.put("nFECNUMERA", 0);
			prmtGaran.put("nFECRECTI", 0);

			try
			{
				String fec = this.pagarantiaDAO.consultarFechaVencimientoGarantia(prmtGaran);
				if ("1".equals(fec.substring(0, 1)))
				{
					prmtDUtil.put("FECHADESDE", fec.substring(2));
					FechaBean fVen = new FechaBean(this.diasUtilesDAO.getSPDiasUtiles(prmtDUtil), "yyyyMMdd");
					res.put("FEC_VENCGARAN", fVen.getTimestamp());
					res.put("FEC_VENCGARAN_DESC", fVen.getFormatDate("dd/MM/yyyy"));
				}
			}
			catch (Exception e)
			{
				log.error("******** EVALUANDO FECHA DE VENCIMIENTO GARANTIA ERROR:" + e);
				log.error("******** PARAMETROS  prmtDUtil:" + prmtDUtil);
			}
		}
	}

	/**
	 * @param res
	 * @param tipoRegimen
	 * @return
	 */
	private void obtenerFechaVencimientoMaximoReg20(Map<String, Object> res, Map<String, Object> paramFechaUtil)
	{
		/*******************************************
		 * Obtenemos la fecha de vencimiento maxima
		 *******************************************/

		// Obtenemos los datos de la feria
		if(!MapUtils.esValorMapaNuloOVacio(res, "COD_FERIA"))
		{
			Map prmt = new HashMap();
			prmt.put("CODIGO", res.get("COD_FERIA"));
			//      List lstFerias = this.feriasDAO.findByParams(prmt);
			List lstFerias = this.feriasDAOService.findByParams(prmt);
			if (!CollectionUtils.isEmpty(lstFerias))
			{
				Map feria = (HashMap) lstFerias.get(0);
				res.put("COD_FERIA_DESC", feria.get("NOMBRE"));

				if (res.get("COD_TIPDESP") != null
						&& Constantes.TIPO_DESP_FERIA.equals(((String) res.get("COD_TIPDESP")).trim()))
				{
					FechaBean fIni = new FechaBean(feria.get("FINICIO").toString(), "yyyyMMdd");
					FechaBean fFin = new FechaBean(feria.get("FFIN").toString(), "yyyyMMdd");

					res.put("FINI_FERIA", fIni.getTimestamp());
					res.put("FFIN_FERIA", fFin.getTimestamp());
					res.put("FINI_FERIA_DESC", fIni.getFormatDate("dd/MM/yyyy"));
					res.put("FFIN_FERIA_DESC", fFin.getFormatDate("dd/MM/yyyy"));

					// Obtenemos el dia util siguiente a los 120
					// dias de plazo
					String strfMax = fFin.getOtraFecha(
							fFin.getFormatDate("dd/MM/yyyy"),
							"yyyyMMdd",
							121,
							Calendar.DAY_OF_MONTH);
					paramFechaUtil.put("FECHADESDE", strfMax);
				}
			}
		}

		// De haber encontrado la fecha maxima de vencimiento, la
		// agregamos al resultado
		if (paramFechaUtil.get("FECHADESDE") != null)
		{
			try
			{
				FechaBean fMaxVen = new FechaBean(this.diasUtilesDAO.getSPDiasUtiles(paramFechaUtil), "yyyyMMdd");
				res.put("FEC_MAXVENCI", fMaxVen.getTimestamp());
				res.put("FEC_MAXVENCI_DESC", fMaxVen.getFormatDate("dd/MM/yyyy"));
			}
			catch (Exception e)
			{
				log.error("******** EVALUANDO FECHA DE VENCIMIENTO GARANTIA ERROR:" + e.getMessage());
				log.error("******** PARAMETROS  prmtDUtil:" + paramFechaUtil);
			}
		}
	}

	/**
	 * @param res
	 */
	private void verificarDUATieneRegPrecedente(Map<String, Object> res)
	{
		// consultando docuPreceDUa
		// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE MODIFICA METODO
		if (res.containsKey("IND_REGIMEN_PRECEDENCIA10")) {
			verificarDUATieneRegPrecedenteNew(res);
		} else {
			// FIN HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			res.put("IND_DOCUPRECEDUA", false);// no tiene regimen de precedencia
			Map param = new HashMap();
			param.put("NUM_CORREDOC", res.get("NUM_CORREDOC"));
			param.put("IND_DEL", "0");
			List<Map<String, Object>> lstDocuPreceDua = docuPreceDuaDAO.select(param);
			if (!CollectionUtils.isEmpty(lstDocuPreceDua))
			{
				for (Map docuPreceDua : lstDocuPreceDua)
				{
					// BIM: Verifica el datado solo cuando el regimen de precedencia es
					// 10:Bultos vigentes
					if (!docuPreceDua.get("COD_REGIMENPRE").toString().equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))
					{
						res.put("IND_DOCUPRECEDUA", true);// tiene regimen de precedencia
						break;
					}
				}
			}
		} // HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	}

	/**
	 * Verifica si es que la DUA tiene regimen precedente
	 * @param res
	 */
	// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE CREA METODO
	private void verificarDUATieneRegPrecedenteNew(Map<String, Object> res) {
		if ("1".equals(res.get("IND_REGIMEN_PRECEDENCIA10"))) {
			res.put("IND_DOCUPRECEDUA", true);
		} else {
			res.put("IND_DOCUPRECEDUA", false);
		}
	}

	/**
	 *
	 * @param res
	 */
	private void verificarDUASujetaRegularizacion(Map<String, Object> res)
	{
		// Evaluacion: si se encuentran en regularizacion para DUA de despacho anticipado
		// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE MODIFICA METODO
		if (res.containsKey("IND_SUJETO_REGULARIZACION")) {
			verificarDUASujetaRegularizacionNew(res);
		} else {
			// FIN HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			res.put("ANTIC_REGU", "0");
			res.put("ANTIC_REGU_DESC", "");
			if (res.containsKey("COD_MODALIDAD") && "10".equals(res.get("COD_MODALIDAD")))
			{
				Map filtro1 = new HashMap();
				filtro1.put("num_corredoc", res.get("NUM_CORREDOC").toString());
				filtro1.put("cod_indicador", "02"); // indicador de sujeto a regularizacion
				Map indicador = indicadorDuaDAO.findByDocumentoAndValor(filtro1);
				if (!CollectionUtils.isEmpty(indicador) && "1".equals(indicador.get("IND_ACTIVO")))
				{
					res.put("ANTIC_REGU", "1");
					res.put("ANTIC_REGU_DESC", "-Sujeto a Regularizaci�n");
				}
			}
		} // HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	}

	/**
	 * Verifica si es que la DUA esta sujeta a regularizacion
	 * @param res
	 */
	//HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE CREA METODO
	private void verificarDUASujetaRegularizacionNew(Map<String, Object> res) {
		if ("1".equals(res.get("IND_SUJETO_REGULARIZACION"))) {
			res.put("ANTIC_REGU", "1");
			res.put("ANTIC_REGU_DESC", "-Sujeto a Regularizaci�n");
		} else {
			res.put("ANTIC_REGU", "0");
			res.put("ANTIC_REGU_DESC", "");
		}
	}

	/**
	 * @param res
	 */
	private void obtenerIndicadorFormatoB(Map<String, Object> res)
	{
		// verificamos si tiene formato B
		// HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA: SE MODIFICA METODO
		//if (res.containsKey("IND_FORMBPROVEEDOR")) {
		//String indicadorFormatoB = (String) res.get("IND_FORMBPROVEEDOR");
		/*if (res.get("IND_FORMBPROVEEDOR") != null) {
			res.put("IND_FORMBPROVEEDOR", "1");
		}else{
			res.put("IND_FORMBPROVEEDOR", "0");
		}*/
		//} else {
		if (!res.containsKey("IND_FORMBPROVEEDOR")) {
			// Fin HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			String IND_REGISTRO_ACTIVO = "0";
			String IND_REGISTRO_INACTIVO = "1";
			Map<String, Object> pFormBP = new HashMap<String, Object>();
			pFormBP.put("numeroCorrelativo", res.get("NUM_CORREDOC"));
			pFormBP.put("inddel", IND_REGISTRO_ACTIVO);
			List<DAV> listFormBP = formBProveedorDAO.findDAVByParams(pFormBP);
			if (!CollectionUtils.isEmpty(listFormBP))
			{
				res.put("IND_FORMBPROVEEDOR", IND_REGISTRO_ACTIVO);// existe formato B
			}
			else
			{
				res.put("IND_FORMBPROVEEDOR", IND_REGISTRO_INACTIVO);
			}
		} // HSAENZ, RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	}

	//inicio EJHM
	public boolean esTipoDocumentoDentroDeLista(String tipoDocumento, String ... listaDocumentos){
		// fin EJHM
		for (int i = 0; i < listaDocumentos.length; i++)
		{
			if(listaDocumentos[i].equals(tipoDocumento.trim())){
				return true;
			}
		}
		return false;
	}


	/**
	 * @param res
	 * @return
	 */
	//inicio EJHM
	public boolean sonValidosParametrosParticipante(Map<String, Object> res, String tipoParticipante)
	//FIN EJHM
	{
		return !MapUtils.esValorMapaNuloOVacio(res, "COD_TIPDOC_" + tipoParticipante)
				&& !MapUtils.esValorMapaNuloOVacio(res, "NUM_DOCIDENT_" + tipoParticipante);
	}

	/**
	 * @param res
	 * @throws ServiceException
	 */
	//inicio EJHM
	public void obtenerDatosParticipante(Map<String, Object> res, String tipoParticipante)
	//FIN EJHM
			throws ServiceException
	{
		Map pers = this.soporteService.obtenerPerNatJur(
				res.get("COD_TIPDOC_" + tipoParticipante).toString().trim(),
				res.get("NUM_DOCIDENT_" + tipoParticipante).toString().trim());

		if (!MapUtils.esValorMapaNuloOVacio(pers, "nombre")){
			res.put("NOM_RAZONSOCIAL_" + tipoParticipante, pers.get("nombre"));
		}		
		
		if (!MapUtils.esValorMapaNuloOVacio(pers, "direccion"))
		{
			res.put("DIR_PARTIC_" + tipoParticipante, pers.get("direccion"));
		}
	}

	/**
	 * @param res
	 */
	/*private void obtenerDescripcionObservaciones(Map<String, Object> res)
  {
    Map<String, Object> filtro = new HashMap<String, Object>();
    filtro.put("NUM_CORREDOC", res.get("NUM_CORREDOC").toString());
    filtro.put("COD_TIPOBS", Constantes.TIPO_OBSERVACION_DECLA);

    Map obs = observacionDAO.findByDocumentoTipo(filtro);
    res.put("OBSERVACION", null);
    if(!MapUtils.esMapaNuloOVacio(obs))
    {
      res.put("OBSERVACION", obs.get("OBS_OBS"));
    }
  }*/


	/**
	 * @param res
	 * @throws DataAccessException
	 */
	private void obtenerDescripcionParticipante(Map<String, Object> res, String numDocParticipante)
			throws DataAccessException
	{
		if(!MapUtils.esValorMapaNuloOVacio(res, numDocParticipante))
		{
			//      Map mapLugRecep = this.ddpDAO.findByPK((String) res.get(numDocParticipante));
			Map mapLugRecep = ddpDAOService.findByPK((String) res.get(numDocParticipante));

			if(!MapUtils.esMapaNuloOVacio(mapLugRecep))
			{
				res.put(numDocParticipante.concat("_DESC"), mapLugRecep.get("ddp_nombre"));
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public String obtenerFeriaDesc(Map<String, Object> params)
			throws ServiceException
	{
		String res = "";
		Map prmt = new HashMap();
		prmt.put("CODIGO", params.get("COD_FERIA"));
		//    List lstFerias = this.feriasDAO.findByParams(prmt);
		List lstFerias = this.feriasDAOService.findByParams(prmt);
		if (!CollectionUtils.isEmpty(lstFerias))
		{
			Map feria = (HashMap) lstFerias.get(0);
			res = (String) feria.get("NOMBRE");
		}

		return res;
	}

	/**
	 * {@inheritDoc}
	 */
	public String buscarDocumento(Map<String, Object> params)
			throws ServiceException
	{
		String res = "";
		try
		{
			res = this.cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error de base de datos buscar documentos");
		}

		return res;
	}


	/**
	 * {@inheritDoc}
	 */
	public DUA buscarDUA(Map<String, Object> params)
			throws ServiceException
	{
		DUA dua = null;
		try
		{
			dua = this.cabDeclaraDAO.findDUAByMap(params);
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error de base de datos buscar documentos");
		}

		return dua;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> obtenerIndicadoresDua(Map<String, Object> params) throws ServiceException
	{
		List<Map<String, Object>> res = null;

		try
		{
			res = this.indicadorDuaDAO.findByDocumentoAndTipo(params);
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error de base de datos buscar indicadores de la dua");
		}

		return res;
	}
	//p24 129 - PAS20165E220200099
	private boolean isImportadorFrecuente(List<Map<String, Object>>  listIndicadoresDua){
		if (listIndicadoresDua != null) {
			for (Map<String, Object> indicadorDUA : listIndicadoresDua) {			
				if(indicadorDUA.get("COD_INDICADOR").equals("05")){ //es decir cuenta con el indicador 05 Importador Frecuente
					return true;
				}				
			}
		}
		return false;
	}
	
	/**
	 * {@inheritDoc}
	 */
	/*inicio P21-P22*/
	public Map<String, Object> validarDeclaParaConclucionDespacho(Map<String, Object> params) throws ServiceException
	{
		Map<String, Object> declaracion = new HashMap<String, Object>();
		Map<String, Object> res = new HashMap<String, Object>();
		String numCorredoc;
		try
		{
			String codRegimen = params.get("cod_regimen").toString();
			declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(params), codRegimen);

			boolean existeDua = true;
			if(MapUtils.esMapaNulo(declaracion))
			{
				existeDua = false;
				res.put("existeDua",  existeDua);
				res.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return res;
			}
			declaracion.put("existeDua",  existeDua);
			numCorredoc = declaracion.get("NUM_CORREDOC").toString().trim();

			//Se a�ade al mapa de la declaracion la lista de indicadores para las validaciones futuras del orquestador.
			if(declaracion.get("LIST_INDICADORES_DUA") == null){
				Map<String,Object> paramsIndicador =  new HashMap<String,Object>();
				paramsIndicador.put("NUM_CORREDOC", numCorredoc);
				List<Map<String, Object>> listIndicadoresDua = obtenerIndicadoresDua(paramsIndicador);
				declaracion.put("LIST_INDICADORES_DUA", listIndicadoresDua);
			}

			//Map<String, Object> paramsUpper = Utilidades.adaptarParametrosBD(params);

			String sNumCorreDoc = declaracion.get("NUM_CORREDOC").toString().trim();
			Long numCorreDoc = new Long(sNumCorreDoc);

			//rin 2.1
			//PAS20155E220300002 Diligencia de Conclusi�n Simplificada
			//Que no cuente con diligencia de conclusi�n de despacho 
		  
		  // No se deberia bloquear puesto que no se podria modificar posteriormente.
		  /*Map<String, Object> p = new HashMap<String,Object>();
			p.put("COD_TIPDILIGENCIA", Constantes.DILIG_CONCLUSION_DESPACHO);
			p.put("NUM_CORREDOC", numCorreDoc);
			RegularizacionBean diligConclusion = diligenciaService.obtenerParametrosSegundaDiligencia(p);
			if (diligConclusion != null){
				declaracion.put("error", "Declaraci�n ya cuenta con la Diligencia de Conclusi�n del Despacho");
				return declaracion;
		  }*/
			//rin 2.2
			//PAS20155E220300002 Diligencia de Conclusi�n Simplificada
			//Que no se encuentre con el estado �13-Despacho Concluido�
		  
		  //Salvo se desee modificar mas de 3 veces y eso se valida en DiligenciaService.validarActualizacionConclusion
			String codigoEstado = (String) declaracion.get("COD_ESTDUA");
//		  if (Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals(codigoEstado))
//		  {
//			  declaracion.put("error", "Declaraci�n se encuentra con el Despacho Concluido");
//			  return declaracion;
//		  }
			
			/**Inicio de cambios PAS20165E220200032***/
			String nombreDiligencia = "Diligencia de Post Levante";
			Boolean ingresoPorPostLevante = params.get("esPostLevante")!=null && "1".equals(params.get("esPostLevante").toString())?true:false;
			GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
			Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
					SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
			//RF01 - Bloqueo para diligencia de conclusion E1
			if(!ingresoPorPostLevante && getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
				declaracion.put("error", "No corresponde el registro de Diligencia de Conclusi�n para la Declaraci�n numerada posterior a la vigencia del DL 1235"); 
				return  declaracion;
			}
			
			if(ingresoPorPostLevante){
			
				Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				
				if(!getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
					declaracion.put("error", "No corresponde el registro de Diligencia de Post Levante, Declaraci�n numerada previo a la vigencia del DL 1235"); //E2 
					return  declaracion;	
				}else{
					if(!codRegimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)|| !tieneGarantia160){
						declaracion.put("error", "Declaraci�n no presenta condiciones para acceder a Post Levante"); //E2 
						return  declaracion;
					}
				}				
			}
			/**Fin de cambios PAS20165E220200032***/
			 			
			//rin 2.4
			Date fechaAutLevante = (Date) declaracion.get("FEC_AUTLEVANTE");
			if (fechaAutLevante == null || SunatDateUtils.isDefaultDate(fechaAutLevante)) {
				declaracion.put("error", "Declaraci�n no cuenta con levante autorizado."); 
				return  declaracion;
			}

			// Validamos que el documento este asignado al funcionario
			params.put("cod_estrev", Constantes.ESTADO_CONCLU_ASIGNADA);
			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(params));
			//rin 1.3
			if (!codigoFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario").toString().trim()))
			{
				/**Inicio de cambios PAS20165E220200032***/
				if(!ingresoPorPostLevante){
					nombreDiligencia="Conclusi�n de Despacho";
				}
				/**Fin de cambios PAS20165E220200032***/
				declaracion.put("error", "Declaraci�n no se encuentra asignada al funcionario aduanero de "+nombreDiligencia);//parametrizado PAS20165E220200032 E3
				return declaracion;
			}

			//rin 2.3 
			if (!ArrayUtils.contains(new String[] { "10", "11","12", "16" ,"13"}, codigoEstado)){
								 
				/*inicio PAS20145E220000427*/
				/*String mensajeError =  "Estado de la Declaraci�n no permite registrar Diligencia de Conclusi�n de Despacho " + codigoEstado
							+ " (" + catalogoAyudaService.getDescripcionDataCatalogo("335", codigoEstado) + ")\n";*/
				
				/**Inicio de cambios PAS20165E220200032***/
				//String descripEstado = catalogoAyudaService.getDescripcionDataCatalogoConVigencia("335", codigoEstado, fechadeclaracion); 
				String descripEstado = (catalogoAyudaService.getDataCatalogo(Constantes.CAT_ESTADO_DUA, codigoEstado, fechadeclaracion).getDesDatacat().toUpperCase());
				String mensajeError =  "Estado de la Declaraci�n no permite registrar Diligencia de Conclusi�n de Despacho " + codigoEstado+ " (" + descripEstado + ")\n";
				
				if(ingresoPorPostLevante){
					mensajeError="Declaraci�n se encuentra con el Post Levante Concluido "+ codigoEstado+ " (" + descripEstado + ")\n";//E6							
				}
				/**Fin de cambios PAS20165E220200032***/
				
				if(Constantes.ESTADO_MERCANCIA_DISPUESTA_PARCIALMENTE.equals(codigoEstado)){
					mensajeError += this.tieneMercanciaDispuestaParcial(numCorreDoc);
				}
				/*fin PAS20145E220000427*/
				
				/**Inicio de cambios PAS20165E220200032***/
				if(ingresoPorPostLevante){
					mensajeError=mensajeError.replaceAll("Conclusi�n de Despacho", "Post Levante");							
				}
				/**Fin de cambios PAS20165E220200032***/
				
				declaracion.put("error", mensajeError);
				return declaracion;
			}

			 
			String nombreDilig="la conclusion";
			if(ingresoPorPostLevante){//Adicionado por cambios PAS20165E220200032
				nombreDilig="Post Levante";
			}
			//rin 2.5
			FechaBean fConcl = declaracion.get("FEC_VENCONCLU") != null ? new FechaBean((Timestamp) declaracion.get("FEC_VENCONCLU")): new FechaBean();
			FechaBean fActual = new FechaBean();

			if (FechaBean.getDiferencia(fConcl.getCalendar(), fActual.getCalendar(), Calendar.DATE) < 0)
			{
				declaracion.put("error", "Plazo para el registro de "+nombreDilig+" se encuentra vencido");
				return declaracion;
			}
			
			Map<String, Object> paramrecti = new HashMap<String, Object>();
			paramrecti.put("NUM_CORREDOC", numCorreDoc);
			paramrecti.put("COD_TIPSOL", "01");
			List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(paramrecti);
			//rin 2.6
			for (Map<String, Object> map : listSolicitudesRecti)
			{
				String estaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
				if (ArrayUtils.contains(new String[]{ Constantes.COD_PENDIENTE_EVALUAR,Constantes.COD_ASIG_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION }, estaRecti))
				{
					declaracion.put("error", "Existe Solicitud de Rectificaci�n Electr�nica pendiente de atenci�n (" + estaRecti + "-" 
							+ catalogoAyudaService.getDescripcionDataCatalogo("363", estaRecti) + ")");
					return declaracion;
				}
			}
			//rin 2.7
			// Obtenemos la lista de boletines quimicos sin concluir
			Map<String, Object> pkDecla=new HashMap<String, Object>();
			pkDecla.put("caduana", params.get("cod_aduana").toString());
			pkDecla.put("CADUA_DUA", params.get("cod_aduana").toString());
			pkDecla.put("NANNO_DUA", params.get("ann_presen").toString());
			pkDecla.put("CREG_DUA", params.get("cod_regimen").toString());
			pkDecla.put("NCORR_DUA", Cadena.padLeft(params.get("num_declaracion").toString(), 6, '0'));
			List<Map<String, Object>> lstBol= soporteService.obtenerBoletinQuimico(pkDecla);
			for(int i=0;i<lstBol.size();i++){
				if ( !("0".equals(lstBol.get(i).get("SESTA_ANALIS")) || "3".equals(lstBol.get(i).get("SESTA_ANALIS")) || "4".equals(lstBol.get(i).get("SESTA_ANALIS")) ) ){
					declaracion.put("error", "Declaraci�n tiene Bolet�n(es) Qu�mico(s) pendiente(s)");
					return declaracion;
				}
			}
			//rin 2.8
			/*//Obtenemos una lista que indica si tiene solicitud de rectificacion y regularizacion
		  List<Map<String, Object>> lstSol = solicitudService.buscarRectiyReguPend(new Long(declaracion.get("NUM_CORREDOC").toString()));
		  Map<String, Object> solicitud;
		  for (int i=0; i<lstSol.size();i++){
			  solicitud=lstSol.get(i);
			  if ("363".equals(solicitud.get("COD_CATESTADO")) &&  ("02".equals(solicitud.get("COD_ESTARECTI")) || "03".equals(solicitud.get("COD_ESTARECTI")) || "04".equals(solicitud.get("COD_ESTARECTI")) ) ){//02, 03,04
				  declaracion.put("error", "La declaraci�n tiene rectificaci�n pendiente."); 
				  return  declaracion;
			  }else  if ("329".equals(solicitud.get("COD_CATESTADO")) && ("01".equals(solicitud.get("COD_ESTARECTI")) || "03".equals(solicitud.get("COD_ESTARECTI")) || "05".equals(solicitud.get("COD_ESTARECTI")) || "06".equals(solicitud.get("COD_ESTARECTI")) )    ){//01, 03, 05, 06
				  declaracion.put("error", "La declaraci�n tiene Diligencia de Regularizaci�n pendiente."); 
				  return  declaracion;
              }
		  }*/
			Map paramsIndicador = new HashMap();
			paramsIndicador.put("num_corredoc", numCorreDoc);
			paramsIndicador.put("cod_indicador", Constantes.IND_DUA_REQ_REGULARIZ); // indicador de sujeto a regularizacion
			paramsIndicador.put("ind_activo",Constantes.INDICADOR_DUA_ACTIVO); //PAS201930001100012 - esantana 20190711 - Atencion SAU20193D512200114
			Map indicador = indicadorDuaDAO.findByDocumentoAndValor(paramsIndicador);
			String modalidad = declaracion.get("COD_MODALIDAD").toString();
			Boolean tieneIndicadorRegu;
			if(indicador == null || indicador.isEmpty()){
				tieneIndicadorRegu = false;
			}else{
				tieneIndicadorRegu = true;
			}
			if(Constantes.COD_MODALIDAD_URGENTE.equals(modalidad) || 
					(Constantes.COD_MODALIDAD_ANTICIPADO.equals(modalidad) && tieneIndicadorRegu)){
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String tmp = declaracion.get("FEC_REGULARIZA").toString().substring(0,10);		
				Date fechaRegularizacion = formatter.parse(tmp);					   
				Date defaultDate = formatter.parse("0001-01-01");
				if(SunatDateUtils.isEqualTo(fechaRegularizacion,defaultDate)){
					declaracion.put("error", "Declaraci�n pendiente de regularizaci�n."); 
					return  declaracion;
				}
			}

			//PAS20155E220300002 Diligencia de Conclusi�n Simplificada -  Se comenta x correo normativa
			/*//rin 2.9 
	      //lc pendientes de pago
		  Map<String, Object> pkDeclaLC=new HashMap<String, Object>();
		  pkDeclaLC.put("caduana", params.get("cod_aduana").toString());
		  pkDeclaLC.put("COD_ADUANA", params.get("cod_aduana").toString());
		  pkDeclaLC.put("ANN_PRESEN", params.get("ann_presen").toString());		   
		  pkDeclaLC.put("NUM_DECLARACION", params.get("num_declaracion").toString());	       
		  List<Map<String, Object>> lstliquida=soporteService.validarLCPendPagoParaConclusionDespacho(pkDeclaLC);

		  if (!CollectionUtils.isEmpty(lstliquida)){
			  declaracion.put("error", "Liquidaci�n de Cobranza pendiente de pago o garant�a (Art�culo 160� de la LGA)"); 
			  return  declaracion;
		  }*/

			//rin 2.10
			Map<String, Object> param= new HashMap<String, Object>();
			param.put("numCorreDoc", numCorreDoc);
			param.put("inddel", Constants.INDICADOR_NO_ELIMINADO); 
			Elementos<DatoSerie> series = new Elementos<DatoSerie>();
			series.addAll(detDeclaraDAO.findSerie(param));
			boolean esPecoAmazonia=false;
			List<Map<String,Object>> lstConv;
			Map<String,Object> paramConvSerie=new HashMap<String, Object>();  
			for (DatoSerie serie :series) {
				paramConvSerie.put("NUM_CORREDOC", numCorreDoc);
				paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
				paramConvSerie.put("COD_TIPCONVENIO", "C"); //4438 LEY AMAZONIA RIN08
				lstConv=convenioSerieDAO.select(paramConvSerie);
				for(Map<String,Object> beanMap:lstConv){
					String cod_convenio = beanMap.get("COD_CONVENIO").toString().trim();
					if (ArrayUtils.contains(new String[]{"4437", ConstantesDataCatalogo.COD_TIP_4438}, cod_convenio)){
						esPecoAmazonia=true;
						break;
					}
				}

				if (!esPecoAmazonia) {
					paramConvSerie.put("NUM_CORREDOC", numCorreDoc);
					paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
					paramConvSerie.put("COD_TIPCONVENIO", "I"); // TPI
					lstConv=convenioSerieDAO.select(paramConvSerie);	
					for (Map<String, Object> beanMap : lstConv) {
						String cod_convenio = beanMap.get("COD_CONVENIO").toString().trim();
						if (ArrayUtils.contains(new String[]{ ConstantesDataCatalogo.COD_TIP_34,
								ConstantesDataCatalogo.COD_TIP_35,
								ConstantesDataCatalogo.COD_TIP_36}, 
								cod_convenio)){						
							esPecoAmazonia = true;
							break;
						}
					}
				}
				if (esPecoAmazonia) {
					break;
				}
			}
			if (esPecoAmazonia) {
				//Verificar si tiene aduana destino
				Map<String, Object> PkDocu = new HashMap();
				PkDocu.put("NUM_CORREDOC", numCorreDoc);
				PkDocu.put("COD_TIPDILIGENCIA", Constantes.DILIG_ADUANA_DESTINO);
				List <Map<String, Object>> aduanaDestino = diligenciaService.selectDiligencia(PkDocu);
				if(aduanaDestino.isEmpty()){
					//Rechaza
					declaracion.put("error", "Declaraci�n acogida a PECO y/o Amazon�a carece de diligencia en aduana de destino");
					return declaracion;
				}else{
					Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;
					Boolean tieneGarantia159 = false;
					Map<String,Object> paramsGarantia = new HashMap<String,Object>();		        			
					paramsGarantia.put("PADUANA",declaracion.get("COD_ADUANA").toString());
					paramsGarantia.put("PREGIMEN",declaracion.get("COD_REGIMEN").toString());
					paramsGarantia.put("PANO",declaracion.get("ANN_PRESEN").toString());
					paramsGarantia.put("PNUMERO",SunatStringUtils.lpad(declaracion.get("NUM_DECLARACION").toString().trim(), 6, ' ') );

					MovNGarantiaDAO movNGarantiaDAO = fabricaDeServicios.getService("movNGarantiaDefRead");
					List<Map<String,Object>> mapTieneGarantia = movNGarantiaDAO.buscarGarantia159(paramsGarantia);		        			
					tieneGarantia159 = mapTieneGarantia.isEmpty()?false:true;

					if(tieneGarantia159 || tieneGarantia160){
						Map<String,Object> ultimaDiligenciaAD = aduanaDestino.get(0);
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						String tmp = ultimaDiligenciaAD.get("FEC_DILIGENCIA").toString().substring(0,10);		
						Date fechaDiligenciaAD = formatter.parse(tmp);			        	

						Map<String, Object> mapBusq = new HashMap<String, Object>();
						mapBusq.put("NUM_CORREDOC", numCorreDoc);
						mapBusq.put("COD_TIPDILIGENCIA", new String[] {Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO});		        	
						Map<String, Object> rectificacionOficio = cabDiligenciaDAO.findUltimaDiligencia(mapBusq);
						if(rectificacionOficio == null || rectificacionOficio.isEmpty()){
							declaracion.put("error", "Declaraci�n acogida a PECO y/o Amazon�a carece de confirmaci�n de diligencia en aduana de destino(rectificaci�n de oficio)");
							return declaracion;
						}else {
							Date fechaDiligenciaRO = formatter.parse(rectificacionOficio.get("FEC_DILIGENCIA").toString().substring(0,10));
							if(SunatDateUtils.esFecha1MayorQueFecha2(fechaDiligenciaAD,fechaDiligenciaRO, "COMPARA_TODO")){
								declaracion.put("error", "Declaraci�n acogida a PECO y/o Amazon�a carece de confirmaci�n de diligencia en aduana de destino(rectificaci�n de oficio)");
								return declaracion;
							}
						}
					}
				}
			}
			//PAS20155E220300002 �? 
			//rin 2.11   
			/*String codiAduan = declaracion.get("COD_ADUANA").toString();
	      String numeCorre = declaracion.get("NUM_CORREDOC").toString();
	      String anoPrese =  declaracion.get("ANN_PRESEN").toString();
	      UtilGarantiaService utilGarantiaService = fabricaDeServicios.getService("utilGarantiaService");
	      List<Map<String, Object>> listaNc = null;
	      if(listaNc!=null){
	    	  declaracion.put("error", "R�gimen Concluido");
	    	  return declaracion;
	      }*/
		}
		catch (Exception e)
		{
			log.error("validarDeclaParaConclucionDespacho - Error: " + e.getLocalizedMessage());
			throw new ServiceException(this, "Ocurrio un error al momento de validar la declaracion: " + e.getMessage());
		}
		return declaracion;
	}
	/*fin P21-P22*/

	//PAS20155E220200101 - Inicio
	public Map<String, Object> validarDeclaParaProrrogaConclusion(Map<String, Object> params) throws ServiceException
	{
		Map<String, Object> declaracion = new HashMap<String, Object>();
		Map<String, Object> res = new HashMap<String, Object>();
		String numCorredoc;
		try
		{
			String codRegimen = params.get("cod_regimen").toString();
			declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(params), codRegimen);

			boolean existeDua = true;
			if(MapUtils.esMapaNulo(declaracion))
			{
				existeDua = false;
				res.put("existeDua",  existeDua);
				res.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return res;
			}
			declaracion.put("existeDua",  existeDua);
			numCorredoc = declaracion.get("NUM_CORREDOC").toString().trim();

			//Se a�ade al mapa de la declaracion la lista de indicadores para las validaciones futuras del orquestador.
			if(declaracion.get("LIST_INDICADORES_DUA") == null){
				Map<String,Object> paramsIndicador =  new HashMap<String,Object>();
				paramsIndicador.put("NUM_CORREDOC", numCorredoc);
				List<Map<String, Object>> listIndicadoresDua = obtenerIndicadoresDua(paramsIndicador);
				declaracion.put("LIST_INDICADORES_DUA", listIndicadoresDua);
			}

			String sNumCorreDoc = declaracion.get("NUM_CORREDOC").toString().trim();
			Long numCorreDoc = new Long(sNumCorreDoc);
 
            /**Inicio de cambios PAS20165E220200086 **/
            if(Constantes.ESTADO_CONCLU_PROCESO.equals((String) declaracion.get("COD_ESTDUA"))  
            || Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO.equals((String) declaracion.get("COD_ESTDUA"))){
                   declaracion.put("error", 
                   "No corresponde el registro de Pr�rroga de Conclusi�n para la Declaraci�n por encontrarse con Diligencia en Proceso o Concluida"); 
                   return  declaracion;       
            }
            /**Fin de cambios PAS20165E220200086 **/
 
 
			/**Inicio de cambios PAS20165E220200032***/
			String nombreDiligencia = "Diligencia de Post Levante";
			Boolean ingresoPorPostLevante = params.get("esPostLevante")!=null && "1".equals(params.get("esPostLevante").toString())?true:false;
			GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
			Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
					SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
			//RF01 - Bloqueo para diligencia de conclusion E1
			if(!ingresoPorPostLevante && getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
				declaracion.put("error", "No corresponde el registro de Pr�rroga de Conclusi�n para la Declaraci�n numerada posterior a la vigencia del DL 1235"); 
				return  declaracion;				
			}
			if(ingresoPorPostLevante){
				
				Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				
				if(!getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
					declaracion.put("error", "Declaraci�n no presenta condiciones para acceder a Pr�rroga de Post Levante"); //E2 
					return  declaracion;	
				}else{
					if(!codRegimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)|| !tieneGarantia160){
						declaracion.put("error", "Declaraci�n no presenta condiciones para acceder a Pr�rroga de Post Levante"); //E2 
						return  declaracion;
					}
										
					//El motivo de Post Levante registrado sea 2- Duda Razonable de lo contrario se ejecuta la excepci�n E2.
					// buscamos si tiene solicitud
				    Map<String,Object> paramSol = new HashMap<String, Object>();
				    paramSol.put("NUM_CORREDOC", sNumCorreDoc);
				    paramSol.put("COD_TIPSOL", TIPO_SOLICITUD_POSTLEVANTE);
					 
				    List<Map<String, Object>> resultSol  = ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).findSolicitudesByDocumento(paramSol);
				    if(!CollectionUtils.isEmpty(resultSol)){
				        Map<String, Object> mapSolPostLevante  = resultSol.get(0); //se carga el primero con la mas reciente fec_solicitud
				        String numCorreDocSolicitud = mapSolPostLevante.get("NUM_CORREDOC")!=null?mapSolPostLevante.get("NUM_CORREDOC").toString():"";

				        if(StringUtils.isNotEmpty(numCorreDocSolicitud)){

				           SolicitudPostLevante solicitudPostLevante = new SolicitudPostLevante();
				           SolicitudPostLevante solicitudEncontrada = new SolicitudPostLevante();
				           solicitudPostLevante.setNumeroCorrelativo(new Long(numCorreDocSolicitud));
				            
			               solicitudEncontrada = ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).get(solicitudPostLevante);
			               List<MotivoSolicitud> lstMotivos = ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).getMotivoSolicitudByNumeroCorrelativo(solicitudPostLevante.getNumeroCorrelativo());
			               if(!CollectionUtils.isEmpty(lstMotivos)){
			            	   solicitudEncontrada.setLsMotivos(lstMotivos);
			               }
			               solicitudPostLevante=solicitudEncontrada;
			               
				           if(solicitudPostLevante!=null && !CollectionUtils.isEmpty(solicitudPostLevante.getLsMotivos())){		
				        	   boolean tieneMotivoDuda = false;
				        	   for(MotivoSolicitud motivosSol : solicitudPostLevante.getLsMotivos()){
				        		   if(!solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_ANULADA) && !solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_RECHAZADO)
				        				   && motivosSol.getCodMotivo().equals(TIPO_MOTIVO_DUDA)
				        				   && motivosSol.getIndDel().equals(IND_MOTIVO_ACTIVO)){
				        			   tieneMotivoDuda=true;
				        		   }
				        	   }
				        	  //if(!("01".equals(solicitudPostLevante.getEstadoSolicitud()) &&(solicitudPostLevante.getLsMotivos().get(0)).getCodMotivo().equals(TIPO_MOTIVO_DUDA))){
				        	   if(!tieneMotivoDuda){
				        		declaracion.put("error", "Declaraci�n no cuenta con el Motivo de Post Levante 2-Duda Razonable requerido para registrar Pr�rroga Post Levante"); //E2 
								return  declaracion;			        		  
				        	  }else{//codigo implementando por amancilla
								   //validar que tenga notificaicon de duda raonable

								   if(!tieneNotificacionDudaRazonable(declaracion)){
									   declaracion.put("error", "Duda Razonable debe estar notificada para registrar Pr�rroga Post Levante"); //E3
									   return  declaracion;
								   }

				        	  }
				         }else{
				    	 declaracion.put("error", "Declaraci�n no cuenta con el Motivo de Post Levante 2-Duda Razonable requerido para registrar Pr�rroga Post Levante"); //E2 
				    	 return  declaracion;
				     } 
				}
				   }else{
					   declaracion.put("error", "Declaraci�n no cuenta con el Motivo de Post Levante 2-Duda Razonable requerido para registrar Pr�rroga Post Levante"); //E2 
					   return  declaracion;
				   }
				     
				     
				}
				
			}
			/**Fin de cambios PAS20165E220200032***/

			//rin 2.1
			//PAS20155E220300002 Diligencia de Conclusi�n Simplificada
			//Que no cuente con diligencia de conclusi�n de despacho 
			Map<String, Object> p = new HashMap<String,Object>();
			p.put("COD_TIPDILIGENCIA", Constantes.DILIG_CONCLUSION_DESPACHO);
			p.put("NUM_CORREDOC", numCorreDoc);
			RegularizacionBean diligConclusion = diligenciaService.obtenerParametrosSegundaDiligencia(p);
			if (diligConclusion != null){
				
				if(!ingresoPorPostLevante){// cambios PAS20165E220200032
				nombreDiligencia="Diligencia de Conclusi�n del Despacho";
				}
				//declaracion.put("error", "Declaraci�n ya cuenta con la Diligencia de Conclusi�n del Despacho");// cambios PAS20165E220200032
				declaracion.put("error", "Declaraci�n ya cuenta con la "+nombreDiligencia);
				return declaracion;
			}

			//rin 2.4
			Date fechaAutLevante = (Date) declaracion.get("FEC_AUTLEVANTE");
			if (fechaAutLevante == null || SunatDateUtils.isDefaultDate(fechaAutLevante)) {
				declaracion.put("error", "Declaraci�n no cuenta con levante autorizado."); 
				return  declaracion;
			}

			// Validamos que el documento este asignado al funcionario
			params.put("cod_estrev", Constantes.ESTADO_CONCLU_ASIGNADA);
			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(params));
			//rin 1.3
			if (!codigoFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario").toString().trim()))
			{
				if(!ingresoPorPostLevante){// cambios PAS20165E220200032
					nombreDiligencia="Conclusi�n del Despacho";
				}
				
				//declaracion.put("error", "Declaraci�n no se encuentra asignada al funcionario aduanero de Conclusi�n de Despacho");// cambios PAS20165E220200032
				declaracion.put("error", "Declaraci�n no se encuentra asignada al funcionario aduanero de "+nombreDiligencia);
				return declaracion;
			}

			//rin 2.5
			FechaBean fConcl = declaracion.get("FEC_VENCONCLU") != null ? new FechaBean((Timestamp) declaracion.get("FEC_VENCONCLU")): new FechaBean();
			FechaBean fActual = new FechaBean();

			if (FechaBean.getDiferencia(fConcl.getCalendar(), fActual.getCalendar(), Calendar.DATE) < 0)
			{
				/**Inicio de cambios PAS20165E220200032***/
				if(!ingresoPorPostLevante){
					nombreDiligencia="Conclusi�n";
				}else{
					if(FechaBean.getDiferencia(fConcl.getCalendar(),(new FechaBean("01/01/0001")).getCalendar(), Calendar.DATE) == 0)
					{
						declaracion.put("error", "No hay fecha registrada para vencimiento de "+nombreDiligencia+" no corresponde Pr�rroga de Post Levante");
						return declaracion;
					}
				}
				/**Fin de cambios PAS20165E220200032***/
				
				//declaracion.put("error", "Plazo para el registro de la conclusion se encuentra vencido");// cambios PAS20165E220200032
				declaracion.put("error", "Plazo para el registro de la "+nombreDiligencia+" se encuentra vencido");
				return declaracion;
			}		  

		}
		catch (Exception e)
		{
			log.error("validarDeclaParaProrrogaConclusion - Error: " + e.getLocalizedMessage());
			throw new ServiceException(this, "Ocurrio un error al momento de validar la declaracion: " + e.getMessage());
		}
		return declaracion;
	}

	//amancilla LGA
	private boolean tieneNotificacionDudaRazonable(Map declaracion) {

		boolean rspta = false;

		String sNumCorreDoc = declaracion.get("NUM_CORREDOC").toString().trim();
		Long numCorreDoc = new Long(sNumCorreDoc);

		DudaConsultaService dudaConsultaService=  fabricaDeServicios.getService("dudarazonable.DudaConsultaService");
		Map<String,Object> dudaConsultaMap=new HashMap<String, Object>();
		dudaConsultaMap.put("numCorredocDam", numCorreDoc);
		//dudaConsultaMap.put("codEstadoDuda", "1");
		Map<String,Object> resultadoDudaMap= dudaConsultaService.obtenerDatosGeneralDudaRazonable(dudaConsultaMap);
		if(!CollectionUtils.isEmpty(resultadoDudaMap)){
			Long numCorreDocDudaRazonable = 	resultadoDudaMap.get("NUM_CORREDOC")!=null?new Long(resultadoDudaMap.get("NUM_CORREDOC").toString()):null;
           if(numCorreDocDudaRazonable!=null){
			   DudaBusquedaService dudaBusquedaService = this.fabricaDeServicios.getService("dudarazonable.DudaBusquedaService");
			   NotificaDuda notificaDuda = dudaBusquedaService.obtenerNotificacionFechaActiva(numCorreDocDudaRazonable, pe.gob.sunat.despaduanero2.dudarazonable.util.Constantes.TIPO_NOTIFICACION_NOTIF_DUDARAZ, pe.gob.sunat.despaduanero2.dudarazonable.util.Constantes.ESTADO_NOTIFICACION_GENERADO);
			   rspta = notificaDuda!=null;
		   }
		}
		if(!rspta){
			rspta = duaTieneNotificacionDudaRazonable(declaracion);
		}

		return rspta;
	}
	//fin amancilla LGA
	//PAS20155E220200101 - Fin


	/**
	 * {@inheritDoc}
	 */
	// hsaenz: 10/09/2014
	public Map<String, Object> validarDeclaSoliProrrogaConclDespacho(Map<String, Object> params) throws ServiceException {

		Map<String, Object> res = new HashMap<String, Object>();
		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
				+ params.get("caduana").toString().trim()));

		try
		{
			Map<String, Object> paramsUpper = Utilidades.adaptarParametrosBD(params);
			/**Inicio de cambios por PAS20165E220200032***/
			Boolean ingresoPorPostLevante = params.get("esPostLevante")!=null && (params.get("esPostLevante").toString()).equals("1")?true:false;
			String nombreDiligencia="Conclusi�n de Despacho";
			if(ingresoPorPostLevante){
				nombreDiligencia="Post Levante";
			}
			/**Fin de cambios por PAS20165E220200032***/
			
			String numero = this.cabDeclaraDAO.findNumCorreDocByDeclaracion(paramsUpper);
			if ("".equals(numero))
			{
				res.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
			}
			else
			{
				Long numCorreDoc = new Long(numero);
				paramsUpper.put("NUM_CORREDOC", numCorreDoc);
				Date fecAutLevante = this.cabDeclaraDAO.findFecAutLevante(paramsUpper);

				if (fecAutLevante.equals((DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD, "dd/MM/yyyy"))))
				{
					// Obtenemos registro de acta de inmovilizacion o separacion
					Map<String, Object> paramIndLev = new HashMap<String, Object>();
					paramIndLev.put("NUM_CORREDOC", numCorreDoc);
					paramIndLev.put("COD_ESTREV", "09");
					List lstActas = this.espeDocuDAO.findEstadoRevisionByDocumento(paramIndLev);
					if ((lstActas == null || lstActas.size() == 0))
					{
						res.put("error", "Declaraci�n no cuenta con Levante.");
					}
				}
				else
				{

					// GRG Validacion de bloqueo de Diligencias de despacho, de
					// regularizaci�n y conclusi�n de despacho por Rectificaci�n
					// 'Pendiente de evaluar' o 'En proceso de evaluaci�n'.
					Map<String, Object> paramrecti = new HashMap<String, Object>();
					paramrecti.put("NUM_CORREDOC", numCorreDoc);
					paramrecti.put("COD_TIPSOL", "01");
					List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(paramrecti);
					for (Map<String, Object> map : listSolicitudesRecti)
					{
						String estaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
						if (ArrayUtils.contains(new String[]
								{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION }, estaRecti))
						{
							res.put("error",
									"La declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado "
											+ estaRecti
											+ " ("
											+ catalogoAyudaService
											.getDescripcionDataCatalogo("363",
													estaRecti) + ")");
							return res;
						}
					}

					// Validacion de documentos pendientes de pago
					String msgDeudas = deudaService.tieneDeudaPendiente(paramsUpper);
					if (!msgDeudas.equals(""))
					{
						res.put("error", "Declaraci�n cuenta con documentos pendientes de cancelaci�n. \n");
					}
					else
					{
						Map<String, Object> odParam = new HashMap<String, Object>();
						odParam.put("rladuaso", paramsUpper.get("COD_ADUANA"));
						odParam.put("rlanoaso", (paramsUpper.get("ANN_PRESEN").toString().trim().substring(2, 4)));
						odParam.put("rlnumaso", paramsUpper.get("NUM_DECLARACION"));
						odParam.put("rlregimen", paramsUpper.get("COD_REGIMEN"));

						List<Map<String, Object>> lstDeudas = this.soporteService.validarOrdeDepoPendPago(odParam);
						if (lstDeudas != null && lstDeudas.size() > 0 && !ordeDepoPendCancelar(lstDeudas))
						{
							res.put("error", "La Declaracion tiene Orden de Deposito sin cancelar o afianzar.");
						}
						else
						{
							// Obtenemos los datos de la declaracion
							res = this.obtenerDeclaracion(paramsUpper);
							
							 /**Inicio de cambios PAS20165E220200032***/
							GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
							Date fechadeclaracion = res.get("FEC_DECLARACION")!=null && res.get("FEC_DECLARACION").toString()!=" "?
									(Date) res.get("FEC_DECLARACION"):SunatDateUtils.getDefaultDate();
							//RF01 - Bloqueo para diligencia de conclusion E1
							if(!ingresoPorPostLevante && getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
								res.put("error", "No corresponde la Autorizaci�n de Prorroga de Conclusi�n para la Declaraci�n, corresponde Autorizaci�n de Post Levante "); 
								return  res;
							}
							if(ingresoPorPostLevante && !getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion)){
								res.put("error", "No corresponde la Autorizaci�n de Prorroga de Post Levante, corresponde Autorizaci�n de Prorroga Conclusi�n para la Declaraci�n "); 
								return  res;
							}
							/**Fin de cambios PAS20165E220200032***/
							
							// hsaenz: 10/09/2014: Se modifica para que tome la fecha de vencimiento de la conclusion
							//FechaBean fConcl = res.get("FEC_CONCLUSION") != null ? new FechaBean(
							//    (Timestamp) res.get("FEC_CONCLUSION"))
							//    : new FechaBean();
							FechaBean fConcl = res.get("FEC_VENCONCLU") != null ? new FechaBean(
									(Timestamp) res.get("FEC_VENCONCLU"))
							: new FechaBean();
									// Fin hsaenz: 10/09/2014
									FechaBean fActual = new FechaBean();

									if (FechaBean.getDiferencia(fConcl.getCalendar(), fActual.getCalendar(), Calendar.DATE) < 0)
									{
										//res.put("error", "Plazo para el registro de la conclusion se encuentra vencido");
										res.put("error", "Plazo para el registro de la "+ingresoPorPostLevante+" se encuentra vencido");//actualizado por PAS20165E220200032 
									}
									else
									{

										Map<String, Object> pkDecla = new HashMap<String, Object>();
										pkDecla.put("caduana", params.get("caduana"));
										pkDecla.put("COD_ADUANA", res.get("COD_ADUANA"));
										pkDecla.put("ANN_PRESEN", res.get("ANN_PRESEN"));

										String numDeclaracion = MapUtils.getMapValor(res, "NUM_DECLARACION");
										pkDecla.put("NUM_DECLARACION", Cadena.padLeft(numDeclaracion, 6, '0'));
										pkDecla.put("COD_REGIMEN", res.get("COD_REGIMEN"));
										pkDecla.put("COD_TIPDILIG", "09");

										// Obtenemos una lista que indica si tiene solicitud de
										// rectificacion y regularizacion
										List<Map<String, Object>> lstSol = this.solicitudService.buscarRectiyReguPend(numCorreDoc);
										res.put("lstSol", lstSol);

										// Obtenemos un boolean que indica si tiene duda razonable ()
										// RIN16
										//res.put("tieneDudaRazonable", this.dudaRazonableService.tieneDudaRazonablePendPorConcluir(pkDecla));
										res.put("tieneDudaRazonable", false);

										// Obtenemos la lista de boletines quimicos sin concluir
										res.put("lstTabBolQuimSC", this.soporteService.obtenerBolQuimicoSinConcluir(pkDecla));

										// Obtenemos la lista de actas sin concluir (SoporteService)
										res.put("lstCabActasSC", this.soporteService.obtenerActasSinConcluir(pkDecla));
									}
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error al momento de validar la declaracion");
		}

		return res;
	}

	/**
	 * Creado por PAS20165E220200032
	 * @param numeCorredoc
	 * @param fechaNumeracion
	 * @return
	 * @throws ServiceException
	 */
	public Date obtenerFechaOrigenPostLevante(String numeCorredoc, Date fechaNumeracion) throws ServiceException {

		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		if(getDeclaracionService.esVigenteNuevaLGAPorFecha(fechaNumeracion)){
			Map <String,Object> mapDatosDiligencia = cabDiligenciaDAO.findDuaDiligenciada(numeCorredoc);
			if(!CollectionUtils.isEmpty(mapDatosDiligencia)){
				return mapDatosDiligencia.get("FEC_DILIGENCIA")!=null && mapDatosDiligencia.get("FEC_DILIGENCIA").toString()!=" "?
						(Date) mapDatosDiligencia.get("FEC_DILIGENCIA"):SunatDateUtils.getDefaultDate(); 
			}else{
				return SunatDateUtils.getDefaultDate();
			}
		}else{
			
			return SunatDateUtils.getDefaultDate();
		}
			 
	}
	/**
	 * Verifica si las Ordenes de deposito estan canceladas o no.
	 *
	 * @param lstDeudas
	 *          : Listado de Ordenes de Deposito.
	 * @return : true:canceladas, false:pendientes de cancelar
	 */
	private boolean ordeDepoPendCancelar(List<Map<String, Object>> lstDeudas)
	{
		boolean ordenPendiente = true;
		for (Map<String, Object> deuda : lstDeudas)
		{
			BigDecimal fechaCance = (BigDecimal) deuda.get("RLFECCAN");
			if (fechaCance.compareTo(BigDecimal.ZERO) == 0)
			{
				ordenPendiente = false;
				break;
			}
		}
		return ordenPendiente;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> validarDeclaParaRegularizacion(Map<String, Object> params) throws ServiceException
	{

		Map<String, Object> res = new HashMap<String, Object>();
		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
				+ params.get("caduana").toString().trim()));
		FechaBean fecDecto = new FechaBean(Constantes.DEFAULT_FECHA_BD);
		String msgDeudas = "";
		try
		{
			res = this.obtenerDeclaracion(Utilidades.adaptarParametrosBD(params));
			if(MapUtils.esMapaNuloOVacio(res))
			{
				res = new HashMap<String, Object>();
				res.put("error", "La Declaraci�n no se encuentra registrada");
				return res;
			}


			res.put("MSGINV", new Boolean(false));
			res.put("MSGINS", new Boolean(false));
			res.put("MSGLIQ", new Boolean(false));
			res.put("MSGACT", new Boolean(false));
			res.put("MSGEXP", new Boolean(false));     

      
			//pruizcr 
			String codigoEstado =  MapUtils.getMapValor(res, "COD_ESTDUA").toString();
			if(codigoEstado.equals("18")) {
				res.put("error","La mercanc�a de la declaraci�n se encuentra dispuesta totalmente");
				return res;
			}
      
			//pruizcr valida disposici�n parcial regularizacion.
			Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
			Map<String, Object> paramRegu = new HashMap<String, Object>();     
			String numCorreDocRegu= declaracion.get("NUM_CORREDOC").toString();
			paramRegu.put("NUM_CORREDOC", numCorreDocRegu);
			String mensajeBloqueo =" ";
			List<Map<String,Object>> lstMercDispuestas1 = null;
			List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();
			List<String> lstAviso=new ArrayList<String>();
			if(codigoEstado.equals("19")){
				lstMercDispuestas1= disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(paramRegu);
				//lstMercDispuestas= disposicionMercanciaService.validarDisposicionParcial(paramRegu);	 
				int varMerDis=lstMercDispuestas1.size();
				if(lstMercDispuestas1.size()>0 && !lstMercDispuestas1.isEmpty() && lstMercDispuestas1!=null){
					lstResultadoMercancia.addAll(lstMercDispuestas1);
					for(int i=0;i<=varMerDis-1;i++){
						//lstResultadoMercancia1.addAll(lstMercDispuestas);
						String item= (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
						String seriemd= (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
						String docDispo= (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
						String fecDocDispo= (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
						String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
						mensajeBloqueo="Serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
											+docDispo+"] de fecha ["+fecDoc1+"]";
			     
						res.put("error",mensajeBloqueo);
						lstAviso.add(mensajeBloqueo);
						res.put("lstAviso",lstAviso);
					}
					return res;
				}
			}
			/* Inicio RIN15 - lrodriguezc */

			SoliAnulacionService soliAnulacionService = fabricaDeServicios.getService("despaduanero2.soliAnulacionService");

			String errorDevuelto = soliAnulacionService.verificaDeclaracionPendientes(res);

			if (!errorDevuelto.isEmpty()){

				res.put("error", errorDevuelto);
				return res;

			}

			/* Fin RIN15 - lrodriguezc */

			Date fecRegulariza = res.get("FEC_REGULARIZA") != null ? (Date) res.get("FEC_REGULARIZA") : fecDecto
					.getTimestamp();
			Date fecAutlevante = res.get("FEC_AUTLEVANTE") != null ? (Date) res.get("FEC_AUTLEVANTE") : fecDecto
					.getTimestamp();
			if (!fecDecto.getTimestamp().equals((Timestamp) fecRegulariza))
			{
				res.put("error", "Declaraci�n se encuentra regularizada");
				return res;
			}
			if (fecDecto.getTimestamp().equals((Timestamp) fecAutlevante))
			{
				res.put("error", "La Declaraci�n no cuenta con Levante Autorizado");
				return res;
			}

			String numCorreDoc = MapUtils.getMapValor(res, "NUM_CORREDOC");
			String codModalidad = MapUtils.getMapValor(res, "COD_MODALIDAD");

			// GRG Validacion de bloqueo de Diligencias de despacho, de regularizaci�n
			// y conclusi�n de despacho por Rectificaci�n 'Pendiente de evaluar' o 'En
			// proceso de evaluaci�n'.
			Map<String, Object> paramrecti = new HashMap<String, Object>();
			paramrecti.put("NUM_CORREDOC", numCorreDoc);
			paramrecti.put("COD_TIPSOL", "01");
			List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(paramrecti);
			for (Map<String, Object> map : listSolicitudesRecti)
			{

				String estaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
				if (ArrayUtils.contains(new String[]
						{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_ASIG_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION }, estaRecti))
				{
					res.put("error",
							"La declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado "
									+ estaRecti
									+ " ("
									+ catalogoAyudaService
									.getDescripcionDataCatalogo("363",
											estaRecti) + ")");
					return res;
				}
			}

			params.put("NUM_CORREDOC", numCorreDoc);
			params.put("COD_TIPSOL", "11");

			Object numDocSol = this.relacionDocDAO.findSolicitudByDocumento(params);
			if (StringUtils.isEmpty((String) numDocSol))
			{
				res.put("error", "La Declaraci�n no cuenta con solicitud de regularizaci�n aceptada");// se corrige bugs18667
				return res;
			}

			params.put("NUM_CORREDOC", numDocSol.toString());

			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocu(params));
			// DZC PAS20145E220000255 nuenas trazas y limpia blancos en el funcionario sesion
			String func_aduanero_sesion=(String) params.get("codigoFuncionario").toString().trim();
			log.info("codigoFuncionario del ESPE_DOCU: " + codigoFuncionario);
			log.info("codigoFuncionario de la  Sesion: " + func_aduanero_sesion);

			if (!codigoFuncionario.equals(func_aduanero_sesion))
			{
				res.put("error", "Solicitud no se encuentra asignada al funcionario aduanero"); //se corrige bugs18668
				return res;
			}

			Map<String, Object> mapaCabSolRecti = this.cabSolRectiDAO.findByDocumento(params); // params
			// NUM_CORREDOC_PRE
			if (CollectionUtils.isEmpty(mapaCabSolRecti))
			{
				res.put("error", "La Declaraci�n no tiene solicitud de Regularizacion");
				return res;
			}

			res.put("NUM_CORREDOC_SOL", numDocSol);
			// 329 Estados de la Regularizaci�n
			String codEstaRegu = MapUtils.getMapValor(mapaCabSolRecti, "COD_ESTARECTI");
			// Se va a validar el estado de la solicitud de regularizaci�n ya no el
			// peso bruto o neto 329 01 Transmisi�n de Regularizaci�n Recepcionada y
			// 03
			if (!ArrayUtils.contains(new String[]
					// RIN16
					{ "01", "03","05", "06" }, codEstaRegu))
			{
				// 329 estados de la solicutd regularizacion
				res.put("error",
						"La declaraci�n tiene un estado que no permite su registro:" + codEstaRegu + " ("
								+ catalogoAyudaService.getDescripcionDataCatalogo("329", codEstaRegu) + ")");
				return res;
			}

			res.put("FEC_REREG_ANT", res.get("FEC_REREG"));
			Date fecRereg = res.get("FEC_REREG") != null ? (Date) res.get("FEC_REREG") : fecDecto.getTimestamp();
			Date fecRecep = res.get("FEC_RECEP") != null ? (Date) res.get("FEC_RECEP") : fecDecto.getTimestamp();
			Calendar cFecRereg = Calendar.getInstance();
			Calendar cFecRecep = Calendar.getInstance();
			cFecRereg.setTime(fecRereg);
			cFecRecep.setTime(fecRecep);// RIN16
			/*

      Map<String, Object> pm;
      if (fecDecto.getTimestamp().equals((Timestamp) fecRereg))
      {

        if (res.get("COD_REGIMEN").toString().equals("20") || res.get("COD_REGIMEN").toString().equals("21"))
        {
          pm = new HashMap<String, Object>();
          pm.put("TIPO_TRAMI", res.get("COD_REGIMEN").toString() + "03");// 03
                                                                         // constante
          pm.put("CODI_ADUAN", res.get("COD_ADUANA").toString());
          pm.put("ANO_PRESE", res.get("ANN_PRESEN").toString());
          String nnumdecla = "000000".substring(res.get("NUM_DECLARACION").toString().length(), 6)
              + res.get("NUM_DECLARACION").toString();
          pm.put("DUI", nnumdecla);
          pm.put("FECH_RECHA", "0"); // activo
          List<Map<String, Object>> listFec2daRecDoc = dfrecdocDAO.findFec2daRecepcionRecDoc(pm);
          if (listFec2daRecDoc != null && listFec2daRecDoc.size() > 0
              && listFec2daRecDoc.get(0).get("FECH_INGSI") != null)
            res.put("FEC_REREG", listFec2daRecDoc.get(0).get("FECH_INGSI"));
        }
        else if (res.get("COD_REGIMEN").toString().equals("70"))
        {
          pm = new HashMap<String, Object>();
          pm.put("TIPO_TRAMI", "37");// 37 constante
          pm.put("NUM_CORREDOC", res.get("NUM_CORREDOC").toString());
          List<Map<String, Object>> listFec2daRecep = sdrecepDAO.findFec2daRecepcionDrecep(pm);
          if (listFec2daRecep != null && listFec2daRecep.size() > 0 && listFec2daRecep.get(0).get("FECH_INGSI") != null)
            res.put("FEC_REREG", listFec2daRecep.get(0).get("FECH_INGSI"));
        }
        else if (res.get("COD_REGIMEN").toString().equals("10"))
        {
          pm = new HashMap<String, Object>();
          pm.put("TIPO_TRAMI", "25");// 25 constante
          pm.put("NUM_CORREDOC", res.get("NUM_CORREDOC").toString());
          pm.put("ANN_PRESEN", res.get("ANN_PRESEN").toString().substring(2, 4));
          List<Map<String, Object>> listFec2daDirecep = direcepDAO.findFec2daRecepcionDirecep(pm);

          if (!CollectionUtils.isEmpty(listFec2daDirecep)
              && listFec2daDirecep.get(0).get("FECH_INGSI") != null)
            res.put("FEC_REREG", listFec2daDirecep.get(0).get("FECH_INGSI"));
        }
      }

      fecRereg = res.get("FEC_REREG") != null ? (Date) res.get("FEC_REREG") : fecDecto.getTimestamp();
			 */ // RIN16
			if (fecDecto.getTimestamp().equals((Timestamp) fecRereg))
			{
				res.put("error", "Declaraci�n no cuenta con la recepci�n de la 2da GED.");
				return res;
			}

			// En la regularizaci�n, La fecha de la segunda recepci�n
			// cab_declara.FEC_REREG debe ser mayor a la fecha
			// de la primera recepci�n cab_declara.FEC_RECEP, sino mostrar el mensaje
			// Declaraci�n no cuenta con
			// segunda recepci�n" concluir con el CU de Regularizaci�n sin permitir se
			// registre la informaci�n.

			Calendar cFecRereg1 = Calendar.getInstance();
			fecRereg = res.get("FEC_REREG") != null ? (Date) res.get("FEC_REREG") : fecDecto.getTimestamp();
			cFecRereg1.setTime(fecRereg);

			if (codModalidad.equals(Constantes.MODALIDAD_URGENTE)
					&& (FechaBean.getDiferencia(cFecRereg1, cFecRecep, Calendar.DATE) < 0))
			{
				res.put("error", "Declaraci�n no cuenta con la recepci�n de la 2da GED.");
				return res;
			}

			params.put("numcorredoc", numCorreDoc);
			params.put("codtipdiligencia", Constantes.TIPO_DILIG_ESTA_REGULARIZACION);
			if (diligenciaService.count(params) > 0)
			{
				res.put("error", "Ya se ha registrado una diligencia de regularizaci�n para la DUA.");
				return res;
			}

			if (!(res.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO) && SunatStringUtils
					.isStringInList(res.get("COD_TIPDESP").toString(), "2002,2011,2012")))
			{
				msgDeudas = deudaService.tieneDeudaPendiente(res);
			}
			if (!StringUtils.isEmpty(msgDeudas))
			{
				res.put("error", msgDeudas);
			}
			//SAU20153N002000183 -- se comenta porque la validacion de orden de deposito solo se debe realizar en la diligencia de despacho
			/*else
      {
        Map<String, Object> odParam = new HashMap<String, Object>();
        odParam.put("rladuaso", res.get("COD_ADUANA"));
        odParam.put("rlanoaso", (res.get("ANN_PRESEN").toString().trim().substring(2, 4)));
        odParam.put("rlnumaso", res.get("NUM_DECLARACION"));
        odParam.put("rlregimen", res.get("COD_REGIMEN"));

        List<Map<String, Object>> lstDeudas = this.soporteService.validarOrdeDepoPendPago(odParam);
        if (!CollectionUtils.isEmpty(lstDeudas) && !ordeDepoPendCancelar(lstDeudas))
        {
          res.put("error", "La Declaracion tiene Orden de Deposito sin cancelar o afianzar.");
        }
      }*/
			//RIN16-CUS 11.03 - Inicio/ 
			Map<String, Object> mapPkManifiesto = new HashMap<String, Object>();
			mapPkManifiesto.put("COD_ADUAMANIFIESTO", res.get("COD_ADUAMANIFIESTO").toString());
			mapPkManifiesto.put("ANN_MANIFIESTO", res.get("ANN_MANIFIESTO").toString());
			mapPkManifiesto.put("NUM_MANIFIESTO", res.get("NUM_MANIFIESTO").toString());
			mapPkManifiesto.put("COD_VIATRANS", res.get("COD_VIATRANS").toString());
			Map<String, Object> mapPkDua = new HashMap<String, Object>();
			mapPkDua.put("COD_ADUANA", res.get("COD_ADUANA"));
			mapPkDua.put("COD_REGIMEN", res.get("COD_REGIMEN"));
			mapPkDua.put("ANN_PRESEN", res.get("ANN_PRESEN"));
			mapPkDua.put("NUM_DECLARACION", res.get("NUM_DECLARACION"));

			Map<String, String> mapSerie = new HashMap<String, String>();
			mapSerie.put("cod_regimen", (String) res.get("COD_REGIMEN"));
			mapSerie.put("cod_aduana", (String) res.get("COD_ADUANA"));
			mapSerie.put("ann_presen", ((BigDecimal) res.get("ANN_PRESEN")).toString());
			mapSerie.put("num_declaracion", ((BigDecimal) res.get("NUM_DECLARACION")).toString());
			mapSerie.put("acceso", "00");
			mapSerie.put("num_corredoc",res.get("NUM_CORREDOC").toString());//adicionado pase81 por nullpointer
			SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
			List<Map<String, Object>> listSerie = serieService.obtenerListadoSeries(mapSerie);
			mapPkDua.put("LIST_SERIES", listSerie);
			List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
			//valida que la regularizacion no este fuera de plazo

			//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			//Date fech_solic_regul = (Date) obteniendoFechaTransmision(res.get("NUM_CORREDOC"));
			Date fech_solic_regul = null;
			if(res.containsKey("FEC_SOLICITUD")){
				fech_solic_regul = (Date)res.get("FEC_SOLICITUD");
			}else{
				fech_solic_regul = (Date) obteniendoFechaTransmision(res.get("NUM_CORREDOC"));
			}
			//RTINEO FIN

			Date fech_venc_regul = SunatDateUtils.getDateFromUnknownFormat(res.get("FEC_VENCREGULA").toString());
			if(SunatDateUtils.esFecha1MayorQueFecha2(fech_solic_regul, fech_venc_regul,"COMPARA_SOLO_FECHA") && !SunatDateUtils.isDefaultDate(fech_venc_regul)){/*PAS20175E220200040*/
				Map mapFila = new HashMap<String, Object>();
				mapFila.put("DOCUMENTO", "Regularizaci�n efectuada fuera de plazo");
				mapFila.put("NRODOCUMENTO", "");
				lstRspta.add(mapFila);    	  		
				res.put("lstRspta",lstRspta);
				res.put("MSGLIQ", true);    	  
			}
			SoporteService soporteService = fabricaDeServicios.getService("diligencia.ingreso.soporteService");
			Map<String, Object> mapActasExpedientes = soporteService.getAllActasAndExpedientesForDeclaParaRegul(numCorreDoc,mapPkManifiesto,mapPkDua);
			//valida que la declaraci�n no se encuentre con Acta de Inmovilizaci�n (en el m�dulo del SIGEDA), caso contrario el sistema muestra el
			//mensaje de advertencias: �Declaraci�n cuenta con Acta de Inmovilizaci�n N���, �Desea continuar? SI/NO
			List<Map<String, Object>> listaAvisosIncautacionInmovilizacion = (List<Map<String, Object>>) mapActasExpedientes.get("listActasIncautacionInmovilizacionDua");
			if(listaAvisosIncautacionInmovilizacion !=null && listaAvisosIncautacionInmovilizacion.size() != 0){
				String numerosAvisosInmovilizacion="";
				for (int i = 0; i < listaAvisosIncautacionInmovilizacion.size(); i++) {
					numerosAvisosInmovilizacion = numerosAvisosInmovilizacion.concat(listaAvisosIncautacionInmovilizacion.get(i).get("NUMERO").toString().concat(" "));  
					Map mapFila = new HashMap<String, Object>();
					mapFila.put("DOCUMENTO", "Declaraci�n cuenta con Acta de Inmovilizaci�n:");
					mapFila.put("NRODOCUMENTO", listaAvisosIncautacionInmovilizacion.get(i).get("NUMERO").toString());
					lstRspta.add(mapFila);
				}
				res.put("lstRspta",lstRspta);
				res.put("MSGINV", true);
				res.put("MSGINV_error", "Declaraci�n cuenta con Acta de Inmovilizaci�n N� " + numerosAvisosInmovilizacion);
			}
			//Valida que la declaraci�n no se encuentre asociada con Avisos de Inspecci�n (en el m�dulo del SIGEDA), caso contrario 
			//el sistema muestra el mensaje de advertencias: �Declaraci�n cuenta con Aviso de Inspecci�n N���, �Desea continuar? SI/NO.      
			List<Map<String, Object>> listaAvisosInspeccion = (List<Map<String, Object>>) mapActasExpedientes.get("listActasInspeccion");
			if(listaAvisosInspeccion !=null && listaAvisosInspeccion.size() != 0){
				String numerosAvisosInspeccion="";
				for (int i = 0; i < listaAvisosInspeccion.size(); i++) {
					numerosAvisosInspeccion = numerosAvisosInspeccion.concat(listaAvisosInspeccion.get(i).get("NROFULL").toString().concat(" ")); 
					Map mapFila = new HashMap<String, Object>();
					mapFila.put("DOCUMENTO", "Declaraci�n cuenta con Aviso de Inspecci�n:");
					mapFila.put("NRODOCUMENTO", listaAvisosInspeccion.get(i).get("NROFULL").toString());
					lstRspta.add(mapFila);
				}
				res.put("lstRspta",lstRspta);
				res.put("MSGINS", true);
				res.put("MSGINS_error", "Declaraci�n cuenta con Aviso de Inspecci�n N� " + numerosAvisosInspeccion);
			}      
			//Valida que la declaraci�n no se encuentre asociada al Acta de Separaci�n (Documento Interno de Tr�mite Documentario c�digo 062),
			//caso el sistema el  mensaje de advertencias: �Declaraci�n cuenta con Acta de Separaci�n N��.�, �Desea continuar? SI/NO.
			Map<String, Object> PkDecla = new HashMap<String, Object>();
			PkDecla.put("tipodoc", ConstantesDataCatalogo.COD_DCTO_TRAMITE_ACTA_DE_SEPARACION); //062
			PkDecla.put("codi_adua",  res.get("COD_ADUANA").toString());
			PkDecla.put("codigoAduana",  res.get("COD_ADUANA").toString());
			PkDecla.put("annoref", res.get("ANN_PRESEN").toString());
			PkDecla.put("numeref", res.get("NUM_DECLARACION").toString());
			DocumentoInternoService documentoInternoService = fabricaDeServicios.getService("tramite.DocumentoInternoService");
			List<Map<String, Object>> listActaVerificacionConDUA = documentoInternoService.obtenerDocInternoTransbordo(PkDecla);
			if(listActaVerificacionConDUA !=null && listActaVerificacionConDUA.size() != 0){
				String numerosActasSeparacion="";
				for (int i = 0; i < listActaVerificacionConDUA.size(); i++) {
					numerosActasSeparacion = numerosActasSeparacion.concat(listActaVerificacionConDUA.get(i).get("NUMERO").toString().concat(" "));
					Map mapFila = new HashMap<String, Object>();
					mapFila.put("DOCUMENTO", "Declaraci�n cuenta con Acta de Separaci�n:");
					mapFila.put("NRODOCUMENTO", listActaVerificacionConDUA.get(i).get("NUMERO").toString());
					lstRspta.add(mapFila);
				}
				res.put("lstRspta",lstRspta);
				res.put("MSGACT", true);
				res.put("MSGACT_error", "Declaraci�n cuenta con Acta de Separaci�n N� " + numerosActasSeparacion);
			}   		

			//Valida que la declaraci�n no se encuentre con Expedientes asociados (en el m�dulo de tr�mite documentario), caso contrario el sistema muestra el 
			//mensaje de advertencias: �Declaraci�n cuenta con Expedientes N��.�.�, �Desea continuar? SI/NO.
			List<Map<String, Object>> listaExpedienteAsociados = (List<Map<String, Object>>) mapActasExpedientes.get("listExpedientesDua");
			//List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
			if(listaExpedienteAsociados !=null && listaExpedienteAsociados.size() != 0){
				String numerosExpedientesAsociados="";
				for (int i = 0; i < listaExpedienteAsociados.size(); i++) {
					numerosExpedientesAsociados = numerosExpedientesAsociados.concat(listaExpedienteAsociados.get(i).get("NUMERO").toString().concat(" "));
					Map mapFila = new HashMap<String, Object>();
					mapFila.put("DOCUMENTO", "Declaraci�n cuenta con Expediente:");
					mapFila.put("NRODOCUMENTO", listaExpedienteAsociados.get(i).get("NUMERO").toString());
					lstRspta.add(mapFila);
				}
				res.put("lstRspta",lstRspta);
				res.put("MSGEXP", true);
				res.put("MSGEXP_error", "Declaraci�n cuenta con Expediente N� " + numerosExpedientesAsociados);
			}      

			//RIN16-CUS 11.03 - Fin/

		}
		catch (Exception e)
		{
			throw new ServiceException(this, e);
		}
		return res;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> validarDeclaParaRectificacionOficio(Map<String, Object> params) throws ServiceException
	{

		Map<String, Object> res = new HashMap<String, Object>();
		try
		{
			// validamos la existencia de la declaracion
			res = this.obtenerDeclaracion(Utilidades.adaptarParametrosBD(params));
			if(MapUtils.esMapaNuloOVacio(res))
			{
				res = new HashMap<String, Object>();
				res.put("error", "La Declaraci�n no se encuentra registrado");
				return res;
			}
		}
		catch (Exception e)
		{
			throw new ServiceException(this, e);
		}
		return res;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> validarDeclaParaDiligenciaCulminacionPeco(Map<String, Object> params) throws ServiceException
	{

		Map<String, Object> res = new HashMap<String, Object>();
		try
		{
			// validamos la existencia de la declaracion
			res = this.obtenerDeclaracion(Utilidades.adaptarParametrosBD(params));
			if(MapUtils.esMapaNuloOVacio(res))
			{
				res = new HashMap<String, Object>();
				res.put("error", "La Declaraci�n no se encuentra registrada para PECO");
				return res;
			}
		}
		catch (Exception e)
		{
			throw new ServiceException(this, e);
		}
		return res;
	}


	/**
	 * {@inheritDoc}
	 */
	public String validarFechaRecepcion(Map<String, Object> mapaDecla)
			throws ServiceException
	{
		String res = "";
		try
		{
			// validamos la existencia de la declaracion
			if (MapUtils.esMapaNuloOVacio(mapaDecla))
			{
				return "";
			}

			FechaBean fecDecto = new FechaBean(Constantes.DEFAULT_FECHA_BD);
			Date fecRecep = mapaDecla.get("FEC_RECEP") != null ?
					(mapaDecla.get("FEC_RECEP") instanceof Date ? (Date) mapaDecla
					.get("FEC_RECEP") : SunatDateUtils.getDateFromUnknownFormat(mapaDecla
					.get("FEC_RECEP").toString()) )
					: fecDecto.getTimestamp();//gmontoya Pase 23
					Date fecDeclaracion = mapaDecla.get("FEC_DECLARACION") != null ? 
							(mapaDecla.get("FEC_DECLARACION") instanceof Date ? (Date) mapaDecla
									.get("FEC_DECLARACION") : SunatDateUtils.getDateFromUnknownFormat(mapaDecla
									.get("FEC_DECLARACION").toString()) )	
							: fecDecto.getTimestamp();//gmontoya Pase 23
					if(fecRecep != null && fecDeclaracion != null){
						//inicio gmontoya Pase 24
//							Calendar cFecRecep = Calendar.getInstance();
//							Calendar cFecDeclaracion = Calendar.getInstance();							
//							cFecRecep.setTime(fecRecep);
//							cFecDeclaracion.setTime(fecDeclaracion);
//							if (fecDecto.getTimestamp().equals((Timestamp) fecRecep))
//							{
//								return "La Declaraci�n no ha sido recepcionada.";
//							}
//							if (fecDecto.getTimestamp().equals((Timestamp) fecDeclaracion))
//							{
//								return "No existe fecha de declaracion.";
//							}
							if(SunatDateUtils.sonIguales(fecDecto.getTimestamp(), fecRecep, SunatDateUtils.COMPARA_SOLO_FECHA)){
								return "La Declaraci�n no ha sido recepcionada.";
							}

							if(SunatDateUtils.sonIguales(fecDecto.getTimestamp(), fecDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
								return "No existe fecha de declaracion..";
							}
						//fin gmontoya Pase 24
							// En la diligencia
							// La fecha de recepci�n cab_declara.FEC_RECEP debe ser mayor a la
							// fecha de la declaraci�n, sino mostrar el mensaje
							// "La Declaraci�n no ha sido recepcionada" y si se est� en:
							// -Revisi�n: continuar con el registro
							// -Proceso : no continuar con el registro
							//inicio gmontoya Pase 24
//							if (FechaBean.getDiferencia(cFecRecep, cFecDeclaracion,
//									Calendar.DATE) < 0)
//							{
//								return "La Declaraci�n no ha sido recepcionada.";
//							}
							if(SunatDateUtils.esFecha1MenorQueFecha2(fecRecep, fecDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
								return "La Declaraci�n no ha sido recepcionada.";
							}
							//fin gmontoya Pase 24
							// si todo es corecto pasamos la fecha de solicitud
					}else{
						return "Error de Sesi�n, fecha de Recepci�n Err�nea.";//gmontoya Pase 23
		}
		}
		catch (Exception e)
		{
			throw new ServiceException(this, e);
		}

		return res;
	}


	/**
	 * Valida si el documento cuyo correlativo se recibe como parametro debe tener
	 * registrada la fecha de reconocimiento fisico.
	 *
	 * @param params
	 *          the params
	 * @return the boolean
	 * @throws ServiceException
	 *           the service exception
	 */
	public Boolean valRegistraFecReconFis(Map<String, Object> params) throws ServiceException
	{
		boolean res = false;

		String canal = params.get("cod_canal").toString().trim();
		if (Constantes.CANAL_ROJO.equals(canal))
		{
			res = true;
		}
		else if (Constantes.CANAL_NARANJA.equals(canal))
		{
			params.put("cod_indicador", Constantes.IND_CAMBIO_REC_FISICO);

			Map mapIndLev = this.indicadorDuaDAO.findByDocumentoAndValor(params);
			if(!MapUtils.esMapaNuloOVacio(mapIndLev))
			{
				res = true;
			}
		}

		return res;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> obtenerACE(Map<String, Object> mapParametros)
	{

		Map<String, Object> mapRespuesta = new HashMap<String, Object>();
		mapRespuesta.put("ERROR", "NO");
		mapRespuesta.put("MSGACE", false);

		// Vallidacion de si tiene acciones de control extraordinario
		List<Map<String, Object>> detailRows = serieService.select(mapParametros);
		mapParametros.put("LIST_SERIES", detailRows);

		Map<String, Object> response = this.soporteService.obtenerAccionesDeControlExtraordinario2(mapParametros);
		List aces1 = (List) response.get("aces");

		// elimino los elementos duplicados no soporta combo Almaceb JSON en el JSP
		HashSet<Map<String, String>> hashSet = new HashSet<Map<String, String>>(aces1);
		List<Map<String, String>> aces = new ArrayList<Map<String, String>>(hashSet);

		StringBuilder straces = new StringBuilder("\n");
		for (Map ace : aces)
		{
			straces.append(ace.get("ACE").toString() + ":" + ace.get("NRO").toString() + "\n");
		}
		if (aces.size() > 0)
		{
			mapRespuesta.put("ERROR", "Mercanc�a cuenta con:" + straces.toString() + "\nDesea Continuar?");
			mapRespuesta.put("MSGACE", true);
		}

		return mapRespuesta;
	}

	/*INICIO - RIN 13*/  
	public Map<String, Object> validarAceDeclaracion(Map<String, Object> mapCabDeclara) {
		Map<String, Object> mapRespuesta = new HashMap<String, Object>();

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NUM_CORREDOC", mapCabDeclara.get("NUM_CORREDOC") != null ? mapCabDeclara.get("NUM_CORREDOC").toString() : " ");
		parametros.put("COD_ADUAMANIFIESTO", mapCabDeclara.get("COD_ADUAMANIFIESTO") != null ? mapCabDeclara.get("COD_ADUAMANIFIESTO").toString() : " ");
		parametros.put("ANN_MANIFIESTO",mapCabDeclara.get("ANN_MANIFIESTO") != null ? mapCabDeclara.get("ANN_MANIFIESTO").toString() : " ");
		parametros.put("NUM_MANIFIESTO",mapCabDeclara.get("NUM_MANIFIESTO") != null ? mapCabDeclara.get("NUM_MANIFIESTO").toString() : " ");
		parametros.put("COD_VIATRANS", mapCabDeclara.get("COD_VIATRANS") != null ? mapCabDeclara.get("COD_VIATRANS").toString() : " ");
		parametros.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA") != null ? mapCabDeclara.get("COD_ADUANA").toString() : " ");
		parametros.put("COD_REGIMEN", mapCabDeclara.get("COD_REGIMEN") != null ? mapCabDeclara.get("COD_REGIMEN").toString() : " ");
		parametros.put("ANN_PRESEN", mapCabDeclara.get("ANN_PRESEN") != null ? mapCabDeclara.get("ANN_PRESEN").toString() : " ");
		parametros.put("NUM_DECLARACION", mapCabDeclara.get("NUM_DECLARACION") != null ? mapCabDeclara.get("NUM_DECLARACION").toString() : " ");
		String[] codEstadosNotIn =  new String[] {"09", "10", "11", "12", "13", "14", "15", "16", "17", "20", "25", "29", "33", "36", "37", "41", "42", "46", "47", "65", "99"};
		parametros.put("codEstadosNotIn", codEstadosNotIn);
		//parametros.put("viewTotal", "true");

		//Buscamos ACE Declaracion
		List<Map> listaACE = new ArrayList();
		List<Map> listaACEDeclaracion = validarAccionesDeControlExtraordinarioDeclaracion(parametros);

		if(listaACEDeclaracion != null && !listaACEDeclaracion.isEmpty()){
			listaACE.addAll(listaACEDeclaracion); 
		}else{
			//Buscamos ACE Documento Transporte
			//List<Map<String, Object>> listaDocTransporte = serieService.obtenerListaNumeroDocTransporteByDeclaracion(mapCabDeclara.get("NUM_CORREDOC").toString());
			List<Map<String, Object>> listaDocTransporte = serieService.obtenerListaNumeroDocTransporteByDeclaracion(SunatNumberUtils.toLong(mapCabDeclara.get("NUM_CORREDOC")));

			parametros.put("LIST_SERIES", listaDocTransporte);

			List<Map> listaACEDocumentoTransporte = validarAccionesDeControlExtraordinarioDocumentoTransporte(parametros);
			if(listaACEDocumentoTransporte != null && !listaACEDocumentoTransporte.isEmpty()){
				listaACE.addAll(listaACEDocumentoTransporte);
			}
		}

		if(listaACE.isEmpty()){
			mapRespuesta.put("rpta", false);
		}else{
			Map mapACE = listaACE.get(0);
			String mensaje = "Declaraci�n registra "+ mapACE.get("DESCRIPCION").toString() + " NRO. " + mapACE.get("NROFULL").toString() + "\n";
			mapRespuesta.put("mensaje", mensaje + "\nDesea Continuar?");
			mapRespuesta.put("rpta", true);
		}

		return mapRespuesta;
	}


	private List<Map> validarAccionesDeControlExtraordinarioDeclaracion(Map<String, Object> parametros)
	{  
		ConsultaAceService consultaAceService = (ConsultaAceService) fabricaDeServicios.getService("prevcontrabando2.ace.consultaAceService");
		return consultaAceService.obtenerAccionesDeControlExtraordinarioActasDUA(parametros);
	}

	private List<Map> validarAccionesDeControlExtraordinarioDocumentoTransporte(Map<String, Object> parametros)
	{  
		ConsultaAceService consultaAceService = (ConsultaAceService) fabricaDeServicios.getService("prevcontrabando2.ace.consultaAceService");
		return consultaAceService.obtenerAccionesDeControlExtraordinarioDocumentoTransporte(parametros);
	}

	/*FIN - RIN 13*/

	/**
	 * Obtener dia habil.
	 *
	 * @param numDias
	 *          the num dias
	 * @param operacion
	 *          the operacion
	 * @param tipoDia
	 *          the tipo dia
	 * @param incluye
	 *          the incluye
	 * @param alcance
	 *          the alcance
	 * @param codAduana
	 *          the cod aduana
	 * @param fechaInicial
	 *          the fecha inicial
	 * @return the date
	 */
	public Date obtenerDiaHabil(
			int numDias,
			int operacion,
			String tipoDia,
			String incluye,
			String alcance,
			String codAduana,
			Date fechaInicial)
	{
		Map<String, Object> pFecha = new HashMap<String, Object>();

		pFecha.put("NUMDIAS", numDias);// 0: cantidad de d�as sumados
		pFecha.put("TIPODIA", tipoDia);// 2: Sumatoria de d�as
		pFecha.put("OPERACION", operacion);// U: d�a �til
		pFecha.put("INCLUYE", incluye);// S: Se cuenta del primer d�a
		pFecha.put("ALCANCE", alcance);// N: No cuenta las fechas
		// suspendidas�.cat_suspende
		pFecha.put("COD_ADUANA", codAduana);
		pFecha.put("FECHAINICIAL", SunatDateUtils.getIntegerFromDate(fechaInicial));
		String ultimoDia = this.soporteService.obtenerSgteDiaUtil(pFecha);
		return SunatDateUtils.getDateFromInteger(Integer.parseInt(ultimoDia));
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> obtenerPrimeraDiligencia(String numCorreDoc) throws ServiceException
	{
		return obtenerPrimeraDiligencia(numCorreDoc, null);
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> obtenerPrimeraDiligencia(String numCorreDoc, String codCanal) throws ServiceException
	{
		Map<String, Object> paramsDiligencia = new HashMap<String, Object>();

		paramsDiligencia.put("NUM_CORREDOC", numCorreDoc);
		if (codCanal == null || codCanal.equals(ConstantesDataCatalogo.COD_CANAL_VERDE)  )
		{
			paramsDiligencia.put("COD_TIPDILIGENCIA",
					new String[]
							{Constantes.DILIG_REV_DOCUMENTARIA,
					Constantes.DILIG_REC_FISICO});
		}
		else
		{
			//r2bz Para los casos de cambio de canal puede tener cualquiera de las dos, son excluyentes
			if(codCanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA )) paramsDiligencia.put("COD_TIPDILIGENCIA", new String[]{Constantes.DILIG_REV_DOCUMENTARIA,Constantes.DILIG_REC_FISICO});
			if(codCanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)) paramsDiligencia.put("COD_TIPDILIGENCIA", new String[]{Constantes.DILIG_REC_FISICO});
		}
		return validaDiligenciaService.findPrimeraDiligencia(paramsDiligencia);
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> validaModificacionDiligencia(Map<String, Object> params) throws ServiceException
	{
		Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));

		/* P14 - 3006 - Inicio - lrodriguezc */

		declaracion = verificarAbandonoVoluntario(declaracion);

		/* P14 - 3006 - Final - lrodriguezc */

		String numCorreDoc = declaracion.get("NUM_CORREDOC").toString();

		/* Inicio RIN15 - lrodriguezc */

		SoliAnulacionService soliAnulacionService = fabricaDeServicios.getService("despaduanero2.soliAnulacionService");

		String errorDevuelto = soliAnulacionService.verificaDeclaracionPendientes(declaracion);

		if (!errorDevuelto.isEmpty()){

			declaracion.put("error", errorDevuelto);
			return declaracion;

		}

		/* Fin RIN15 - lrodriguezc */


		// c. Que la diligencia original de despacho de la DUA haya sido registrada
		// con fecha posterior a la puesta en producci�n de esta implementaci�n.
		// En caso la fecha de registro de la diligencia de la DUA haya sido
		// efectuada en fecha anterior, muestra el mensaje:
		// Se ha registrado la diligencia antes de la vigencia, no puede ser
		// modificada y registra un error en el sistema
		//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
		Date fecVigenciaModDilig = (declaracion.get("FEC_INIVIGENCIA_MODDILIGENCIA")!=null)?(Date)declaracion.get("FEC_INIVIGENCIA_MODDILIGENCIA"):null;
		if(fecVigenciaModDilig == null){
			fecVigenciaModDilig = (Date) catalogoAyudaService.getElementoCat("380", "0002").get("fec_inidatcat");
		}
		//    Date fecVigenciaModDilig = (Date) catalogoAyudaService.getElementoCat("380", "0002").get("fec_inidatcat");
		//RTINEO FIN
		Date fecDiligencia = (Date) params.get("FEC_DILIGENCIA");

		if (SunatDateUtils.esFecha1MenorQueFecha2(fecDiligencia, fecVigenciaModDilig, SunatDateUtils.COMPARA_SOLO_FECHA))
		{
			declaracion.put("error", "Se ha registrado la diligencia antes de la vigencia, no puede ser modificada.");
			return declaracion;
		}

		// b. Que el actor sea el mismo funcionario aduanero que registr� la
		// diligencia de la DUA
		// Ud. no ha diligenciado la DUA
		Map<String, Object> mapParamsAsig = new HashMap<String, Object>();
		mapParamsAsig.put("NUM_CORREDOC", numCorreDoc);
		//mapParamsAsig.put("COD_ESTREV", 1);
		mapParamsAsig.put("COD_ESTREV", "01"); //RIN13
		mapParamsAsig.put("COD_PROCESOASIG", params.get("COD_PROCESOASIG")); //gmontoya Pase 99 2016 -
		Map<String, Object> mapEspeDespachoAsig = espeDocuDAO.findbyDocEstRev(mapParamsAsig);
		if (mapEspeDespachoAsig == null || mapEspeDespachoAsig.isEmpty()
				|| (mapEspeDespachoAsig != null && !mapEspeDespachoAsig.isEmpty() && !mapEspeDespachoAsig.get("cod_funcionario").equals(
						params.get("COD_FUNCIONARIO"))))//cuando es empty bota oBject error!
		{
			declaracion.put("error", "Ud. no ha diligenciado la DUA.");
			return declaracion;
		}

		// d. Que la DUA no cuente con transmisi�n de la regularizaci�n aceptada
		// para el caso de DUAs de modalidad urgente o anticipada
		// En caso la DUA cuente con transmisi�n de regularizaci�n, muestra el
		// mensaje: La diligencia no puede ser modificada,
		// DUA cuenta con transmisi�n de regularizaci�n y registra un error en el
		// sistema.
		// ConstantesDataCatalogo.COD_EST_REGULA_ACEPTADA=04
		if (SunatStringUtils.isStringInList(declaracion.get("COD_MODALIDAD").toString(), "01,10"))
		{
			Integer tieneReguAceptada = 0;
			//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			//P24 - PAS20165E220200099 , se modifico por bug M_SNADE283-610
			/* 			
			String indicadorTransmisionRegularizacion = (declaracion.get("IND_TRANSMISION_REGULARIZA")!=null)?(String)declaracion.get("IND_TRANSMISION_REGULARIZA"):null;
			if(StringUtils.isEmpty(indicadorTransmisionRegularizacion)){
				tieneReguAceptada = 1;
			}else{
			*/	
				Map<String, Object> mapParamsRegu = new HashMap<String, Object>(); 
				mapParamsRegu.put("numcorredocpre", numCorreDoc);

				if (declaracion.get("COD_MODALIDAD").toString().equals("01")) 
				{
					mapParamsRegu.put("codTransaccion", "05");
					//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
					//tieneReguAceptada = relacionDocDAO.countSolRectificacionByParameterMap(mapParamsRegu);
					tieneReguAceptada = relacionDocDAO.hasSolRectificacionByParameterMap(mapParamsRegu);
					//FIN RTINEO
				}
				else if (declaracion.get("COD_MODALIDAD").toString().equals("10")) 
				{
					mapParamsRegu.put("codTransaccion", "04"); 
					//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
					//tieneReguAceptada = relacionDocDAO.countSolRectificacionByParameterMap(mapParamsRegu);
					tieneReguAceptada = relacionDocDAO.hasSolRectificacionByParameterMap(mapParamsRegu);
					//FIN RTINEO
				}
				//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				if(tieneReguAceptada == null){
					tieneReguAceptada = 0;
				}
				//RTINEO
			//}P24 - PAS20165E220200099 , se modifico por bug M_SNADE283-610

			if (tieneReguAceptada > 0)
			{
//				declaracion
//				.put("error", "La diligencia no puede ser modificada, DUA cuenta con transmisi�n de regularizaci�n.");
//				return declaracion;
			}
		}

		String msgValidacion = validarRectificacionesPendientes(numCorreDoc);
		if (StringUtils.isNotEmpty(msgValidacion))
		{
			declaracion.put("error", "La diligencia no puede ser modificada, " + msgValidacion);
			return declaracion;
		}

		Date fechaHoy = SunatDateUtils.getCurrentDate();
		Date fechaMaxZPAE = obtenerDiaHabil(1, 2, "U", "N", "S", declaracion.get("COD_ADUANA").toString(), fecDiligencia);

		if (SunatStringUtils.isStringInList(declaracion.get("COD_REGIMEN").toString(), "10,20,21"))
		{
			if (declaracion.get("COD_MODALIDAD").toString().equals("10") &&
					declaracion.get("COD_TIPLUGARRECEP").toString().equals("04"))
			{
				if (SunatDateUtils.esFecha1MayorQueFecha2(fechaHoy, fechaMaxZPAE, SunatDateUtils.COMPARA_SOLO_FECHA))
				{
					declaracion.put(
							"error",
							"No puede modificar la diligencia por haber sido registrada hace m�s de un d�a h�bil.");
					return declaracion;
				}
			}
			else
			{
				if (declaracion.get("FEC_SALTERALM") != null &&
						!SunatDateUtils.isDefaultDate((Date) declaracion.get("FEC_SALTERALM")))
				{
					declaracion.put("error", "No puede modificar una diligencia cuya mercanc�a ya no est� en zona primaria.");
					return declaracion;
				}
			}
		}

		Date fechaMax70 = obtenerDiaHabil(2, 2, "U", "N", "S", declaracion.get("COD_ADUANA").toString(), fecDiligencia);

		if (SunatStringUtils.isStringInList(declaracion.get("COD_REGIMEN").toString(), "70"))
		{
			if (SunatDateUtils.esFecha1MayorQueFecha2(fechaHoy, fechaMax70, SunatDateUtils.COMPARA_SOLO_FECHA))
			{
				declaracion.put(
						"error",
						"No puede modificar la diligencia por haber sido registrada hace m�s de dos d�as h�biles.");
				return declaracion;
			}
		}

		// codigo dependiente
		//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
		//declaracion.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(declaracion.get("NUM_CORREDOC")));
		if(declaracion.containsKey("FEC_SOLICITUD")){
			declaracion.put("FEC_SOLICITUD_RECTI", declaracion.get("FEC_SOLICITUD"));
		}else{
			declaracion.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(declaracion.get("NUM_CORREDOC")));
		}
		//RTINEO FIN


		String codigoCanal = (String) declaracion.get("COD_CANAL");
		String codigoIndicador = (String) declaracion.get("COD_INDICADOR");

		if (codigoIndicador.equals("00"))
		{
			if (codigoCanal.equals(Constantes.CANAL_VERDE))
			{
				declaracion.put("error", "Canal de la Declaraci�n no habilitado para su diligencia.");
				return declaracion;
			}
			else
			{
				String tituloDiligencia = obtenerTituloDiligencia(codigoCanal);
				log.info("tituloDiligencia: " + tituloDiligencia);
				declaracion.put("tituloDiligencia", tituloDiligencia);
			}
		}
		else
		{
			String tituloDiligencia = obtenerTituloDiligencia(Constantes.CANAL_ROJO);
			declaracion.put("tituloDiligencia", tituloDiligencia);
		}

		// rin 13 -inicio- 26-11-2014

		List<Map<String, Object>> listaDeDiligencias = null;

		Map PkDocu = new HashMap<String, Object>();
		PkDocu.put("NUM_CORREDOC", numCorreDoc);
		listaDeDiligencias = cabDiligenciaDAO.findByDocumento(PkDocu);
		int contadorRevisionDocumentaria = 0; // 02
		int contadorRevisionFisica = 0; // 03
		for (Map<String, Object> lista : listaDeDiligencias) {
			String cod_tipdiligencia = lista.get("COD_TIPDILIGENCIA").toString();
			if("02".equalsIgnoreCase(cod_tipdiligencia) && params.get("COD_FUNCIONARIO").equals(lista.get("FUNCIONARIO"))){
				contadorRevisionDocumentaria = contadorRevisionDocumentaria + 1;
			}
			if("03".equalsIgnoreCase(cod_tipdiligencia) && params.get("COD_FUNCIONARIO").equals(lista.get("FUNCIONARIO"))){
				contadorRevisionFisica = contadorRevisionFisica + 1;
			}

		}

		if(contadorRevisionFisica >= 2 || contadorRevisionDocumentaria >= 2){
			declaracion.put("error", "No puede registrar m�s de una modificaci�n a la diligencia de despacho.");
			return declaracion;
		}

		// rin 13 -fin- 26-11-2014    

		return declaracion;
	}


	private Map<String, Object>  verificarAbandonoVoluntario(Map<String, Object> declaracion) {
		String indAbandonoVoluntario = declaracion.get("COD_INDICADOR3").toString();

		if (!indAbandonoVoluntario.equals("00")){
			// RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
			String descripcionError = (declaracion.get("DES_ERROR_INDICADOR3")!= null)?(String) declaracion.get("DES_ERROR_INDICADOR3"):"";
			if(!StringUtils.isEmpty(descripcionError)){//<EHR -p14>si es vacio no deberia ingresar, no hay mensaje  alguno que mostrar
				declaracion.put("error",descripcionError);
			}else{
				Map<String, String> resultado = new HashMap<String, String>();		
				resultado = catalogoAyudaService.getError(Constantes.COD_ERROR_IND_ABANDONO_VOLUNTARIO);
				declaracion.put("error", resultado.get("desError"));
			}
			//		Map<String, String> resultado = new HashMap<String, String>();		
			//		resultado = catalogoAyudaService.getError(Constantes.COD_ERROR_IND_ABANDONO_VOLUNTARIO);
			//		declaracion.put("error", resultado.get("desError"));
			return declaracion;
			// RTINEO FIN
		}
		return declaracion;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> validarDeclaParaDespacho(Map<String, Object> params) throws ServiceException
	{

		/**INICIO-RIN13**/
		Map<String, Object> declaracion = new HashMap<String, Object>();

		try
		{
			/*//Validar Operador
	      OperadorValidaService operadorValidaService = this.fabricaDeServicios.getService("Ayuda.operadorValidaService");
	      if(!operadorValidaService.validarOperador((String)declaracion.get("NUM_DOCIDENT_PDE"), ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA, (String)declaracion.get("COD_ADUANA"), new Date()).isEmpty()){
	    	  declaracion.put("error", "Declarante no se encuentra habilitado para operar en la circunscripci�n.");
	          return declaracion;
	      }*/

			declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
			//String acceso = params.get("acceso") != null ? params.get("acceso").toString().trim() : "";
			String acceso = MapUtils.getMapValor(params, "acceso");
			String msgDeudas = "";
			/**FIN-RIN13**/   	    
			//if (declaracion == null)
			if(MapUtils.esMapaNulo(declaracion))
			{
				declaracion = new HashMap<String, Object>();
				declaracion.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return declaracion;
			}

			String num_corredoc = declaracion.get("NUM_CORREDOC").toString(); // GRG
			// Si es consulta
			if ((acceso.equals("00"))){
				//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				//declaracion.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(declaracion.get("NUM_CORREDOC")));
				if(declaracion.containsKey("FEC_SOLICITUD")){
					declaracion.put("FEC_SOLICITUD_RECTI", declaracion.get("FEC_SOLICITUD"));
				}else{
					declaracion.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(declaracion.get("NUM_CORREDOC")));
				}
				//RTINEO FIN
				return declaracion;
			}
			// PAS20181U220200016
//			String codigoRiesgoOea = declaracion.get("COD_RIESGOOEA")!=null?declaracion.get("COD_RIESGOOEA").toString():""; 
//			if (SunatStringUtils.isStringInList(codigoRiesgoOea, "11,10,01")){
//				
//				declaracion.put(
//						"error",
//						"La declaraci�n cuenta con un Proveedor OEA bajo los alcances del Acuerdo de Reconocimiento Mutuo");
//				return declaracion;
//			}
			
			//RIN16
			/* Inicio RIN15 - lrodriguezc */      
			SoliAnulacionService soliAnulacionService = fabricaDeServicios.getService("despaduanero2.soliAnulacionService");
			String errorDevuelto = soliAnulacionService.verificaDeclaracionPendientes(declaracion);
			if (!errorDevuelto.isEmpty()){
				declaracion.put("error", errorDevuelto);
				return declaracion;
			}
			/* Fin RIN15 - lrodriguezc */

			// Cuando la DUA es canal f�sico, verifica que, si tiene diligencia
			// documentaria debe tambien tener indicador de cambio de canal

			/* olunar 309 */
			if (declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_ROJO) || declaracion.get("COD_INDICADOR").equals(Constantes.IND_CAMBIO_REC_FISICO))
			{
				Map<String, Object> diligencia = new HashMap<String, Object>();
				diligencia.put("numcorredoc", declaracion.get("NUM_CORREDOC").toString());
				diligencia.put("codtipdiligencia", ConstantesDataCatalogo.COD_DILIG_REV_DOC);
				// Si tiene diligencia para canal naranja y no tiene indicador de
				// cambio de canal por revaluacion, no contin�a la diligencia
				if (validaDiligenciaService.validaTieneDiligenciaTipo(diligencia)
						&& !tieneCambioCanalControl(declaracion.get("NUM_CORREDOC").toString()))
				{
					declaracion.put(
							"error",
							"La declaraci�n no tiene un indicador de Cambio de Canal producto de la Rectificacion");
					return declaracion;
				}
				// RIN13 SWF QUITO : params.put("cod_grupo", ConstantesDataCatalogo.GRUPO_RECONOCIMIENTO_FISICO);
			}
			// RIN13 SWF QUITO : ELSE{params.put("cod_grupo", ConstantesDataCatalogo.GRUPO_REVISION_DOCUMENTARIA);}

			//PAS20145E220000427 
			String codigoEstado = (String) declaracion.get("COD_ESTDUA");
			if(codigoEstado.equals("18")){
				declaracion.put("error","La mercanc�a de la declaraci�n se encuentra dispuesta totalmente.");
				return declaracion;
			}
			params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());

			String mensajeBloqueo = tieneMercanciaDispuestaParcial(Long.valueOf(declaracion.get("NUM_CORREDOC").toString()));
			if( !SunatStringUtils.isEmpty(mensajeBloqueo) ) declaracion.put("aviso",mensajeBloqueo);
    
			//PAS201830001100016 - mtorralba 20181120 - Se cambia la ubicaci�n de la verificaci�n si es DAM garantizada 
			Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				

			//PAS20145E220000427
			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(params));
			// DZC PAS20145E220000255 se limpia blancos
			if (!codigoFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario").toString().trim()))
			{
				if (codigoFuncionario.equals(""))
				{
					Map<String, Object> paramEspeDocu = new HashMap<String, Object>();
					paramEspeDocu.put("cod_estrev", "09");
					paramEspeDocu.put("cod_aduana", params.get("cod_aduana").toString());
					paramEspeDocu.put("ann_presen", params.get("ann_presen").toString());
					paramEspeDocu.put("cod_regimen", params.get("cod_regimen").toString());
					paramEspeDocu.put("num_declaracion", params.get("num_declaracion").toString());

					String varConfirma = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(paramEspeDocu));
					if ((varConfirma).length() > 0)
					{
						declaracion
						.put(
								"error",
								"No se permite registro de diligencia de despacho para la presente DUA con resultado de reconocimiento f�sico 06.");
						return declaracion; //RIN13
					}
					else
					{
						declaracion.put("error", "El Usuario no tiene asignada la Declaraci�n.");
						return declaracion; //RIN13
					}
				}
				else
				{
					declaracion.put("error", "El Usuario no tiene asignada la Declaraci�n.");
					return declaracion; //RIN13
				}
			}
			else
			{

			/* amancilla SAU201510002900141 PAS20155E220200128
				String msgValidacion = validarRectificacionesPendientes(num_corredoc);
				if (StringUtils.isNotEmpty(msgValidacion))
				{
					declaracion.put("error", msgValidacion);
					return declaracion;
				}*/

        //String codigoEstado = (String) declaracion.get("COD_ESTDUA");

				/**inicio PAS20165E220200032**/
				Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
						SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate();
				//String descripEstado = catalogoAyudaService.getDescripcionDataCatalogoConVigencia("335", codigoEstado, fechadeclaracion);
				String descripEstado = (catalogoAyudaService.getDataCatalogo(Constantes.CAT_ESTADO_DUA, codigoEstado, fechadeclaracion).getDesDatacat().toUpperCase());				
				/**Fin PAS20165E220200032**/
						
				if (!ArrayUtils.contains(new String[]
						{ Constantes.COD_PENDIENTE_EVALUAR, "03", Constantes.COD_EN_EVALUACION, "07", "15" ,"18","19","21"}, codigoEstado))
        		{
					/*declaracion.put("error", "La declaraci�n tiene un estado que no permite su registro: " + codigoEstado
							+ " (" + catalogoAyudaService.getDescripcionDataCatalogo("335", codigoEstado) + ")");*/
					declaracion.put("error", "La declaraci�n tiene un estado que no permite su registro: " + codigoEstado + " (" + descripEstado + ")");
					return declaracion;
				}

				String codigoCanal = (String) declaracion.get("COD_CANAL");
				String codigoIndicador = (String) declaracion.get("COD_INDICADOR");
				if (StringUtils.isBlank(codigoCanal))
				{
					declaracion.put("error", "La Declaraci�n no tiene canal asignado.");
					return declaracion;
				}

				// 27.05.2010 BIM Cambie la validaci�n para que reconozca
				// DUA's inducidos a f�sico
				if (codigoIndicador.equals("00"))
				{
					if (codigoCanal.equals(Constantes.CANAL_VERDE))
					{
						declaracion.put("error", "Canal de la Declaraci�n no habilitado para su diligencia.");
						return declaracion; //RIN13
					}
					else
					{
						String tituloDiligencia = obtenerTituloDiligencia(codigoCanal);
						declaracion.put("tituloDiligencia", tituloDiligencia);
					}
				}
				else
				{
					String tituloDiligencia = obtenerTituloDiligencia(Constantes.CANAL_ROJO);
					declaracion.put("tituloDiligencia", tituloDiligencia);
				}

				/* olunar 309 */
				if (codigoCanal.equals(Constantes.CANAL_NARANJA)) {
					// Verificar pase a reconocimiento f�sico pendiente 
					Consulta filtroConsulta = new Consulta();
					filtroConsulta.setNumcorredoc(new Long(num_corredoc));
					filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
					filtroConsulta.setIndicadorRespuesta(" ");
					List<Consulta> listaConsultasPendientes = consultaService.buscarConsulta(filtroConsulta);
					if (!CollectionUtils.isEmpty(listaConsultasPendientes)) {
						declaracion.put("error", "DUA cuenta con Solicitud de Reconocimiento F�sico Pendiente de Aceptaci�n, verificar.");
						return declaracion; //RIN13
					}
				}
				/* fin */									

				//JCV 20100105 Reversa RN007
				List<Expedi> lstExpedi = soporteService.obtenerExpedi(declaracion); // JCV
				for (Expedi expedi : lstExpedi)
				{
					if (expedi.getProcedim().equals("3071") && expedi.getFechConc().equals(Integer.valueOf("0")))
					{
						String lcMensaje = "DUA tiene Expediente pendiente de concluir.";
						/**INICIO-RIN13**/
						//String lctipoMensaje = "aviso";
						if (!("02".equals(declaracion.get("COD_ESTDUA")) || "03".equals(declaracion.get("COD_ESTDUA"))))
						{
							//lctipoMensaje = "error";
							declaracion.put("error", lcMensaje);
							return declaracion;
						}else{
							declaracion.put("aviso", lcMensaje);
							break;
						}
						/*if (declaracion.get(lctipoMensaje) == null)
            {
              declaracion.put(lctipoMensaje, lcMensaje);
            }
            else
            {
              declaracion.put(lctipoMensaje, declaracion.get(lctipoMensaje).toString().concat("\n")
                  .concat(lcMensaje));
	            }*/

						/**FIN-RIN13**/
					}}

				String validaFecRecp = this.validarFechaRecepcion(declaracion);
				if (!validaFecRecp.equals(""))
				{
					declaracion.put("error", validaFecRecp);
					return declaracion; //RIN13
				}
				else
				{
					// JCV 20100105 Reversa RN018 - Verifica si corresponde
					// cambio de modalidad
					verificaModalidad(declaracion);
				}
				// se verifica se la DUA tiene deudas pendientes de pago,
				// excepto para el regimen
				// 20 y tipo de despacho 2,11,12
				//Se comenta por pase PAS20165E220200038
				/*  
				if (!(declaracion.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO) && SunatStringUtils
						.isStringInList(declaracion.get("COD_TIPDESP").toString(), "2002,2011,2012")))
				{
					msgDeudas = deudaService.tieneDeudaPendiente(declaracion);
				}
				*/
				if (!StringUtils.isEmpty(msgDeudas))
				{
					declaracion.put("error", msgDeudas);
					return declaracion; //RIN13
				}
                  /* amancilla PAS20155E220200128 sau de angelica
				else
				{
					Map<String, Object> odParam = new HashMap<String, Object>();
					odParam.put("rladuaso", declaracion.get("COD_ADUANA"));
					odParam.put("rlanoaso", (declaracion.get("ANN_PRESEN").toString().trim().substring(2, 4)));
					odParam.put("rlnumaso", declaracion.get("NUM_DECLARACION"));
					odParam.put("rlregimen", declaracion.get("COD_REGIMEN"));

					List<Map<String, Object>> lstDeudas = this.soporteService.validarOrdeDepoPendPago(odParam);
					if (!CollectionUtils.isEmpty(lstDeudas) && !ordeDepoPendCancelar(lstDeudas))
					{
						declaracion.put("error", "La Declaracion tiene Orden de Deposito sin cancelar o afianzar.");


						return declaracion;
					}
	        }*/




				//String modalidad = (String)declaracion.get("COD_MODALIDAD");
				//se comenta amancilla Rin13FSW en coordinanacion con el usuario no debio estar aqui si no aya jajaa
				/*
	      if(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(modalidad)){	    	 
	    	  {
	    		  String mensaje = validarDespachoAnticipado(declaracion);
		    	  if(!mensaje.isEmpty()){
		    		  declaracion.put("error", mensaje);
		    		  return declaracion;
		    	  }
          }
	      }else if(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE.equals(modalidad)){
	    	  String mensaje = validarPlazoMercanciaArriboDespachoUrgente(declaracion);
	    	  if(!mensaje.isEmpty()){
	    		  declaracion.put("error", mensaje);
	    		  return declaracion;
	      }

        }*/
				///**FIN-RIN13**/

				/*RIN13FSW-INICIO*/	    	  
				/*jlunah INICIO*/	
				if(!declaracion.get("COD_REGIMEN").equals(Constantes.REGIMEN_70_DEPOSITO)){
					Map<String, Object> res = new HashMap<String, Object>();
					res.put("NUM_CORREDOC", num_corredoc);
					obtenerIndicadorFormatoB(res);
					if(res.get("IND_FORMBPROVEEDOR").equals("1")){
						if(!validarDeclaracionExceptuada(declaracion)){
							declaracion.put("error", "Declaracion requiere la transmision del Formato B, verifique.");
						}
					}
				}
				/*jlunah FIN*/              

				/**Inicio de cambios PAS20165E220200032**/
				
				//PAS20181U220200073 se traslada funcionalidad aqui:
				declaracion = evalGrabarFechaPostLevante(declaracion, fechadeclaracion);
				
				/*GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
				
				String sNumCorreDoc = declaracion.get("NUM_CORREDOC").toString().trim();
				Long numCorreDoc = new Long(sNumCorreDoc);
				Boolean grabarFechaPostLevante = false; 
				
				if(declaracion.get("COD_REGIMEN").equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO) 
						&& (declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_ROJO)||declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)) ){
				
					Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				
					
					if(getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion) && tieneGarantia160){
						//El motivo de Post Levante registrado sea 4- Indicadores de riesgo de lo contrario se ejecuta la excepci�n E1.(warning)
						// buscamos si tiene solicitud
					    Map<String,Object> paramSol = new HashMap<String, Object>();
					    paramSol.put("NUM_CORREDOC", sNumCorreDoc);
					    paramSol.put("COD_TIPSOL", TIPO_SOLICITUD_POSTLEVANTE);

					    List<Map<String, Object>> resultSol  = ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).findSolicitudesByDocumento(paramSol);
					    if(!CollectionUtils.isEmpty(resultSol)){
					        Map<String, Object> mapSolPostLevante  = resultSol.get(0); //se carga el primero con la mas reciente fec_solicitud
					        String numCorreDocSolicitud = mapSolPostLevante.get("NUM_CORREDOC")!=null?mapSolPostLevante.get("NUM_CORREDOC").toString():"";

					        if(StringUtils.isNotEmpty(numCorreDocSolicitud)){

					           SolicitudPostLevante solicitudPostLevante = new SolicitudPostLevante();
					           SolicitudPostLevante solicitudEncontrada = new SolicitudPostLevante();
					           solicitudPostLevante.setNumeroCorrelativo(new Long(numCorreDocSolicitud));
					           //SolicitudPostLevanteService solicitudPostLevanteService = fabricaDeServicios.getService("ingreso.postLevante.solicitudPostLevanteService");
				               //solicitudPostLevante = solicitudPostLevanteService.obtenerSolicitud(solicitudPostLevante);
				               solicitudEncontrada = ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).get(solicitudPostLevante);
				               List<MotivoSolicitud> lstMotivos = ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).getMotivoSolicitudByNumeroCorrelativo(solicitudPostLevante.getNumeroCorrelativo());
				               solicitudEncontrada.setLsMotivos(lstMotivos);
				               solicitudPostLevante=solicitudEncontrada; 
				               
								if (solicitudPostLevante != null && !solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_ANULADA) && !CollectionUtils.isEmpty(solicitudPostLevante.getLsMotivos())) {
								boolean evaluarSolicitud = false;
									for(MotivoSolicitud motivosSol : solicitudPostLevante.getLsMotivos()){
									//if ((solicitudPostLevante.getLsMotivos().get(0)).getCodMotivo().equals(TIPO_MOTIVO_IND_RIESGO)) {
										if (motivosSol.getCodMotivo().equals(TIPO_MOTIVO_IND_RIESGO) && motivosSol.getIndDel().equals(IND_MOTIVO_ACTIVO) ) {
											evaluarSolicitud=true;										
										}										
									}
									if(evaluarSolicitud){
										if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_REGISTRADO)) {
											declaracion.put("error", "Declaraci�n No cuenta con Post Levante, Motivo 4 Pendiente de evaluar"); // E1
										}
										if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_ACEPTADO)) {
											grabarFechaPostLevante = true;
										}
										if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_RECHAZADO)) {										
											declaracion.put("aviso", "Declaraci�n No cuenta con Post Levante, Motivo 4 Rechazado"); // E2
										}
									}else{
											if (!solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_RECHAZADO)) {	
												grabarFechaPostLevante = true;
											}
									}
								}
					        }
					   }
					}
				}
				declaracion.put("grabarFechaPostLevante", grabarFechaPostLevante);
				**/
				
				/**Fin de cambios PAS20165E220200032**/
				
				/*jlunah validacion verificacion descarga parcial*/
				if(tieneDescargaParcial(num_corredoc)){

					//obtengo datos necesarios para consultar la lista de los documentos de transporte (en esa lista me trae su estado - PENDIENTE � COMPLETO)
					//pendiente = faltan descargar contenedores
					//completo =  se descargaron todos los contenedores del documento de transporte
					String codAduamanifiesto = declaracion
							.get("COD_ADUAMANIFIESTO") != null ? declaracion
									.get("COD_ADUAMANIFIESTO").toString() : "";
									String codViatrans = declaracion.get("COD_VIATRANS") != null ? declaracion
											.get("COD_VIATRANS").toString() : "";
											Integer annManifiesto = declaracion.get("ANN_MANIFIESTO") != null ? Integer
													.parseInt(declaracion.get("ANN_MANIFIESTO")
															.toString()) : new Integer(0);
													String numManifiesto = declaracion.get("NUM_MANIFIESTO") != null ? declaracion
															.get("NUM_MANIFIESTO").toString() : "";
															String codTipmanifiesto = declaracion
																	.get("COD_TIPMANIFIESTO") != null ? declaracion
																			.get("COD_TIPMANIFIESTO").toString() : "";

																			Map<String, Object> paramsDocTrans = new HashMap<String, Object>();
																			paramsDocTrans.put("numeroManifiesto", numManifiesto);
																			paramsDocTrans.put("anioManifiesto", annManifiesto);
																			paramsDocTrans.put("codigoAduana", codAduamanifiesto);
																			paramsDocTrans.put("codigoTipoManifiesto", codTipmanifiesto);
																			paramsDocTrans.put("codigoViaTransporte", codViatrans);

																			/*seteamos valores para las series (con las series se filtran los documentos de transporte de la declaracion)*/
																			paramsDocTrans.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
																			paramsDocTrans.put("num_corredoc", num_corredoc);
																			paramsDocTrans.put("num_declaracion", declaracion.get("NUM_DECLARACION"));
																			paramsDocTrans.put("cod_aduana", declaracion.get("COD_ADUANA"));
																			paramsDocTrans.put("ann_presen", declaracion.get("ANN_PRESEN"));
																			paramsDocTrans.put("cod_regimen", declaracion.get("COD_REGIMEN"));
																			paramsDocTrans.put("estadoDUA", declaracion.get("COD_ESTDUA"));
																			paramsDocTrans.put("acceso", acceso);

																			List<Map<String, Object>> listaDocumentosDeTransporte = new ArrayList<Map<String, Object>>();
																			listaDocumentosDeTransporte.addAll(obtieneDocumentosDeTransporteDeLaDeclaracion(paramsDocTrans));

																			if(!seDescargaronTodosLosContenedores(listaDocumentosDeTransporte)){
																				declaracion.put("error", "No puede registrar la diligencia de despacho si no ha registrado la diligencia con descargas parciales para todos los contenedores de la declaracion ");
																			}
				}

			}
			//inicio lalberti DAM DIFERIDA SIN ICA
			// Si la vigencia no esta abierta, no se ejecutan las nuevas validaciones
			Date fechaLlegadaManifiesto = getFechaLlegadaManifiestoDeclaracion(declaracion);
			if(isVigenciaAbiertaValidacionesDAMSinIca(fechaLlegadaManifiesto)){
				String mensajeBloqueoDAMSinICA = validarDAMDiferidaSinICA(declaracion);
				if(!mensajeBloqueoDAMSinICA.isEmpty()){
					declaracion.put("error", mensajeBloqueoDAMSinICA );
					notificarRectificacionPuntoLlegada(declaracion);
					return declaracion;
				}
			}
			//fin lalberti DAM DIFERIDA SIN ICA
	
			
			/**inicio PAS20181U220200049**/
			Date fechadeclaracion = declaracion.get("FEC_DECLARACION")!=null && declaracion.get("FEC_DECLARACION").toString()!=" "?
					SunatDateUtils.getDateFromUnknownFormat(declaracion.get("FEC_DECLARACION").toString()):SunatDateUtils.getDefaultDate(); 
			List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechadeclaracion);
			if(!ResponseListManager.responseListHasErrors(listaOMA)){
				if(declaracion.get("COD_VIATRANS")!=null && !declaracion.get("COD_VIATRANS").toString().isEmpty()){
					String descrViaTransporte =   (catalogoAyudaService.getDataCatalogo("227", declaracion.get("COD_VIATRANS").toString(), fechadeclaracion).getDesDatacat().toUpperCase());
					declaracion.remove("COD_VIATRANS_DESC");
					declaracion.put("COD_VIATRANS_DESC",descrViaTransporte);
				}
			} 				
			/**Fin PAS20181U220200049**/
				
			//PAS201830001100016 - mtorralba 20181120 - Inicio  RF6 RIN08 - Peco Amazonia
			/*if( !tieneGarantia160 ) {
				boolean tienePecoAmazonia = declaracion.get("TIENE_PECOAMAZONIA")==null || declaracion.get("TIENE_PECOAMAZONIA").toString().equals("0") ? false : true;
				if( tienePecoAmazonia ) {
					//Si no tiene Garant�a Previa, las LCs deben estar pagadas
					String msgError = deudaService.verificaLCPendientePago(num_corredoc);
					if( !msgError.equals(""))
						declaracion.put("error", msgError);
				}
			}
			*/
			//PAS201830001100016 - mtorralba 20181120 - Fin
			
        	//PAS201830001100069 - mtorralba 20190307 - INICIO
        	//Si la DAM tiene PECO Amazonia, se verifica si la DAM tiene Garantia159, entonces las LCs asociadas deben estar pagadas.
			if( declaracion.get("TIENE_PECOAMAZONIA")!=null && !declaracion.get("TIENE_PECOAMAZONIA").equals("0")) {
            	Map paramsDeclaracion = new HashMap();
            	paramsDeclaracion.put("codAduana", declaracion.get("COD_ADUANA").toString());
    			params.put("codRegimen", declaracion.get("COD_REGIMEN").toString());
    			params.put("annPresen", declaracion.get("ANN_PRESEN").toString());
    			params.put("numDeclaracion", SunatStringUtils.lpad(declaracion.get("NUM_DECLARACION").toString().trim(),6,'0'));
    			params.put("anoPresen", declaracion.get("ANN_PRESEN").toString().substring(2));
    			GarantiaOperativaService garantiaService = fabricaDeServicios.getService("recauda.diligencia.garantiaService");
    			List<Map> listaGaran = garantiaService.obtenerGarantiaPorDeclaracion(params);
    			if( listaGaran.size() > 0 ) {
    				FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
    				if( !funcionesLiquidacionService.verificaLCPagadas(Long.valueOf(declaracion.get("NUM_CORREDOC").toString())) ) {
    					declaracion.put("error", "Declaracion amparada con Garantia 159. Todas las L/C asociadas deben estar pagadas.");
    				}
    			}
			
			}
			//PAS201830001100069 - mtorralba 20190307 - FIN
			
				
		}
		catch (Exception e)
		{
			log.error(e);
		}
		return declaracion;
	}

	/*RIN13FSW-INICIO*/
	/**
	 * @author jlunah
	 * Verifica si la declaracion tiene alguna diligencia de descarga parcial
	 * */
	public boolean tieneDescargaParcial(String numCorredoc){
		Map<String, Object> PkDocu = new HashMap<String, Object>();
		PkDocu.put("NUM_CORREDOC", numCorredoc);
		List<Map<String, Object>> lstDiligenciasDeclaracion = new ArrayList<Map<String,Object>>();
		lstDiligenciasDeclaracion=(List<Map<String, Object>>) diligenciaService.obtenerDiligencias(PkDocu);

		for (Map<String, Object> map : lstDiligenciasDeclaracion) {
			if(map.get("COD_TIPDILIGENCIA").toString().equals(Constantes.DILIG_DESCA_PARCIAL)){
				return true;
			}
		}
		return false;
	}

	/**
	 * @author jlunah
	 * obtiene la lista de los documentos de transporte de la declaracion
	 * */
	public List<Map<String,Object>> obtieneDocumentosDeTransporteDeLaDeclaracion(Map paramsDocTrans){

		List<Map<String, Object>> listaCabecera = new ArrayList<Map<String, Object>>();
		/*obtengo lista de series*/
		/****/
		Map<String, String> params = new HashMap<String, String>();
		params.put("documentoAduanero", paramsDocTrans.get("documentoAduanero").toString());
		params.put("num_corredoc", paramsDocTrans.get("num_corredoc").toString());
		params.put("num_declaracion", paramsDocTrans.get("num_declaracion").toString());
		params.put("cod_aduana", paramsDocTrans.get("cod_aduana").toString());
		params.put("ann_presen", paramsDocTrans.get("ann_presen").toString());
		params.put("cod_regimen", paramsDocTrans.get("cod_regimen").toString());
		params.put("acceso", paramsDocTrans.get("acceso")!=null?paramsDocTrans.get("acceso").toString():" ");

		// Para Declaracion en Proceso se filtran las Series
		params.put("estadoDUA", paramsDocTrans.get("estadoDUA").toString());

		List lstDetDeclara = serieService.obtenerListadoSeries(params);
		List<Map<String, Object>> lstDetDeclaraActual = new ArrayList<Map<String,Object>>(); //aqui se almacenan las series de la declaracion
		if(!lstDetDeclara.isEmpty()){lstDetDeclaraActual = Utilidades.copiarLista(lstDetDeclara);}

		if(lstDetDeclaraActual.size()>0){
			String [] documentosDeTransporte = new String[lstDetDeclaraActual.size()];
			int i = 0;
			if(!lstDetDeclaraActual.isEmpty()){
				for (Map serie : lstDetDeclaraActual){
					if(serie.get("NUM_DOCTRANSP") != null){
						documentosDeTransporte[i] = serie.get("NUM_DOCTRANSP").toString();	  
					}
					i++;
				}
			}

			/****/
			List<DocumentoDeTransporte> listaDocumentoTransporteCabecera = new ArrayList<DocumentoDeTransporte>();
			paramsDocTrans.put("numeroManifiesto",SunatStringUtils.lpad(paramsDocTrans.get("numeroManifiesto").toString().trim(), 6, ' ') );
			listaDocumentoTransporteCabecera = documentoDeTransporteService.obtenerDocumentosDeTransporteByParameterMap2(paramsDocTrans);

			Map<String, Object> paramsRegistro = new HashMap<String, Object>();

			if(documentosDeTransporte.length>0){
				for (DocumentoDeTransporte documentoDeTransporte : listaDocumentoTransporteCabecera) {
					//le agregamos el filtro de las series
					if(ArrayUtils.contains(documentosDeTransporte, documentoDeTransporte.getNumeroDocumentoTransporte())){
						// logica de registro
						paramsRegistro.put("numeroDocumentoTransporte",	documentoDeTransporte.getNumeroDocumentoTransporte());
						paramsRegistro.put("NUM_CORREDOC",	paramsDocTrans.get("num_corredoc").toString());

						boolean registro = obtenerRegistro(paramsRegistro);

						Map<String, Object> mapaCabecera = new HashMap<String, Object>();
						mapaCabecera.put("numeroDocumentoTransporte",documentoDeTransporte.getNumeroDocumentoTransporte());
						mapaCabecera.put("numeroDeDetalle",documentoDeTransporte.getNumeroDeDetalle());
						if (!registro) {
							mapaCabecera.put("registroTransporte", "PENDIENTE");
						} else {
							mapaCabecera.put("registroTransporte", "COMPLETO");
						}
						listaCabecera.add(mapaCabecera);
					}
				}
			}
		}
		return listaCabecera;
	}

	//  <EHR>
	public String obtieneDocumentosDeTransporteDeLaDeclaracionValidOld(Map<String, Object> declaracion) throws ServiceException{

		String codAduamanifiesto = declaracion.get("COD_ADUAMANIFIESTO") != null ? declaracion.get("COD_ADUAMANIFIESTO").toString() : "";
		String codViatrans = declaracion.get("COD_VIATRANS") != null ? declaracion.get("COD_VIATRANS").toString() : "";
		Integer annManifiesto = declaracion.get("ANN_MANIFIESTO") != null ? Integer.parseInt(declaracion.get("ANN_MANIFIESTO").toString()) : new Integer(0);
		String numManifiesto = declaracion.get("NUM_MANIFIESTO") != null ? declaracion.get("NUM_MANIFIESTO").toString() : "";
		String codTipmanifiesto = declaracion.get("COD_TIPMANIFIESTO") != null ? declaracion.get("COD_TIPMANIFIESTO").toString() : "";
		String numManifiestoFormato = StringUtils.leftPad(numManifiesto, 6);
		Map<String, Object> paramsDocTrans = new HashMap<String, Object>();
		paramsDocTrans.put("numeroManifiesto", numManifiestoFormato);
		paramsDocTrans.put("anioManifiesto", annManifiesto);
		paramsDocTrans.put("codigoAduana", codAduamanifiesto);
		paramsDocTrans.put("codigoTipoManifiesto", codTipmanifiesto);
		paramsDocTrans.put("codigoViaTransporte", codViatrans);
		BigDecimal totalPesoTransporte = new BigDecimal(0);
		BigDecimal totalBultoTransporte = new BigDecimal(0);
		/*seteamos valores para las series (con las series se filtran los documentos de transporte de la declaracion)*/
		paramsDocTrans.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
		paramsDocTrans.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
		paramsDocTrans.put("num_declaracion", declaracion.get("NUM_DECLARACION"));
		paramsDocTrans.put("cod_aduana", declaracion.get("COD_ADUANA"));
		paramsDocTrans.put("ann_presen", declaracion.get("ANN_PRESEN"));
		paramsDocTrans.put("cod_regimen", declaracion.get("COD_REGIMEN"));
		paramsDocTrans.put("estadoDUA", declaracion.get("COD_ESTDUA"));

		//		List<Map<String, Object>> listaDocumentosDeTransporte = new ArrayList<Map<String, Object>>();
		//		listaDocumentosDeTransporte.addAll(obtieneDocumentosDeTransporteDeLaDeclaracion(paramsDocTrans));
		/*obtengo lista de series*/
		/****/
		Map<String, String> params = new HashMap<String, String>();
		params.put("documentoAduanero", paramsDocTrans.get("documentoAduanero").toString());
		params.put("num_corredoc", paramsDocTrans.get("num_corredoc").toString());
		params.put("num_declaracion", paramsDocTrans.get("num_declaracion").toString());
		params.put("cod_aduana", paramsDocTrans.get("cod_aduana").toString());
		params.put("ann_presen", paramsDocTrans.get("ann_presen").toString());
		params.put("cod_regimen", paramsDocTrans.get("cod_regimen").toString());
		int  postal=1;
		if(codViatrans.equals("0")){
			postal= 0;
		}

		// Para Declaracion en Proceso se filtran las Series
		params.put("estadoDUA", paramsDocTrans.get("estadoDUA").toString());

		List lstSeries = serieService.obtenerListadoSeries(params);
		List<Map<String, Object>> lstDetDeclaraActual = new ArrayList<Map<String,Object>>(); //aqui se almacenan las series de la declaracion
		if(!lstSeries.isEmpty()){lstDetDeclaraActual = Utilidades.copiarLista(lstSeries);}

		if(lstDetDeclaraActual.size()>0){
			String [] lstDocumentosDeTransporteSerie = new String[lstDetDeclaraActual.size()];
			int i = 0;
			if(!lstDetDeclaraActual.isEmpty()){
				for (Map serie : lstDetDeclaraActual){
					if(!StringUtils.isEmpty(serie.get("NUM_DOCTRANSP").toString().trim())){
						//P34 AFMA lstDocumentosDeTransporteSerie[i] = serie.get("NUM_DOCTRANSP").toString();
						lstDocumentosDeTransporteSerie[i] = serie.get("NUM_DOCTRANSP").toString()+" de la serie "+serie.get("NUM_SECSERIE").toString();
						i++;
					}else{
						return "Debe registrar el n�mero de documento de transporte" ;
					}

				}
			}

			/****/
			List<DocumentoDeTransporte> listaDocumentoTransporteManifiesto = new ArrayList<DocumentoDeTransporte>(); // del manifiesto
			listaDocumentoTransporteManifiesto = documentoDeTransporteService.obtenerDocumentosDeTransporteByParameterMap2(paramsDocTrans);

			/**/
			if(listaDocumentoTransporteManifiesto != null && !listaDocumentoTransporteManifiesto.isEmpty()){


				String []  documentosDeTransporteManifiesto = new String[listaDocumentoTransporteManifiesto.size()];
				if(listaDocumentoTransporteManifiesto.size()>0){
					//String []  documentosDeTransporteManifiesto = new String[listaDocumentoTransporteManifiesto.size()];
					int j = 0;
					if(!listaDocumentoTransporteManifiesto.isEmpty()){
						for (DocumentoDeTransporte documentoDeTransporte: listaDocumentoTransporteManifiesto){
							if(documentoDeTransporte.getNumeroDocumentoTransporte()!= null){   // TODO LO DIFERENTE COD_VIA <> 0
								documentosDeTransporteManifiesto[j] = documentoDeTransporte.getNumeroDocumentoTransporte(); 
								totalPesoTransporte=totalPesoTransporte.add(documentoDeTransporte.getPesoRecibido());
								totalBultoTransporte=totalBultoTransporte.add(documentoDeTransporte.getBultosRecibidos());
							}
							j++;
						}
					}
				}

				for (String numDocumentoTransporte : lstDocumentosDeTransporteSerie) {

					//for (String docManifiestTransporte : documentosDeTransporteManifiesto) {
					if(!ArrayUtils.contains(documentosDeTransporteManifiesto , numDocumentoTransporte)){
						if(postal==0){
							return "El documento de transporte (aviso postal)  "+numDocumentoTransporte+" no coincide con el consignado en el manifiesto postal  "+numManifiesto;
						}
						//P34 AFMA return "El n�mero de documento de transporte "+numDocumentoTransporte+" no coincide con el consignado en el manifiesto de carga "+numManifiesto;
						return "El n�mero de documento de transporte "+numDocumentoTransporte+" no coincide con el consignado en el manifiesto de carga "+Utilidades.formatoNumeroManifiesto(codTipmanifiesto,codViatrans,codAduamanifiesto,annManifiesto,numManifiesto);
					}
					//}

				}

			}   
			if(postal==0&&totalPesoTransporte.compareTo(new BigDecimal("0"))==0 && totalBultoTransporte.compareTo(new BigDecimal("0"))==0){
				return "No se han registrado los pesos y bultos recibidos en el manifiesto postal";
			}
		}

		return "";
	}
	//</EHR>
	/*inicio gdlr*/
	@Override
	public String obtieneDocumentosDeTransporteDeLaDeclaracionValid(Map<String, Object> declaracion) throws ServiceException {
		return obtieneDocumentosDeTransporteDeLaDeclaracionValid(declaracion, null);
	} 


	@Override
	public String obtieneDocumentosDeTransporteDeLaDeclaracionValid(Map<String, Object> declaracion, List<Map<String, Object>> series) throws ServiceException {

		String codAduamanifiesto = declaracion.get("COD_ADUAMANIFIESTO") != null ? declaracion.get("COD_ADUAMANIFIESTO").toString() : "";
		String codViatrans = declaracion.get("COD_VIATRANS") != null ? declaracion.get("COD_VIATRANS").toString() : "";
		Integer annManifiesto = declaracion.get("ANN_MANIFIESTO") != null ? Integer.parseInt(declaracion.get("ANN_MANIFIESTO").toString()) : new Integer(0);
		String numManifiesto = declaracion.get("NUM_MANIFIESTO") != null ? declaracion.get("NUM_MANIFIESTO").toString() : "";
		String codTipmanifiesto = declaracion.get("COD_TIPMANIFIESTO") != null ? declaracion.get("COD_TIPMANIFIESTO").toString() : "";
		String numManifiestoFormato = StringUtils.leftPad(numManifiesto, 6);
		Map<String, Object> paramsDocTrans = new HashMap<String, Object>();
		paramsDocTrans.put("numeroManifiesto", numManifiestoFormato);
		paramsDocTrans.put("anioManifiesto", annManifiesto);
		paramsDocTrans.put("codigoAduana", codAduamanifiesto);
		paramsDocTrans.put("codigoTipoManifiesto", codTipmanifiesto);
		paramsDocTrans.put("codigoViaTransporte", codViatrans);
		BigDecimal totalPesoTransporte = new BigDecimal(0);
		BigDecimal totalBultoTransporte = new BigDecimal(0);
		/*seteamos valores para las series (con las series se filtran los documentos de transporte de la declaracion)*/
		paramsDocTrans.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
		paramsDocTrans.put("num_corredoc", declaracion.get("NUM_CORREDOC"));
		paramsDocTrans.put("num_declaracion", declaracion.get("NUM_DECLARACION"));
		paramsDocTrans.put("cod_aduana", declaracion.get("COD_ADUANA"));
		paramsDocTrans.put("ann_presen", declaracion.get("ANN_PRESEN"));
		paramsDocTrans.put("cod_regimen", declaracion.get("COD_REGIMEN"));
		paramsDocTrans.put("estadoDUA", declaracion.get("COD_ESTDUA"));

		//		List<Map<String, Object>> listaDocumentosDeTransporte = new ArrayList<Map<String, Object>>();
		//		listaDocumentosDeTransporte.addAll(obtieneDocumentosDeTransporteDeLaDeclaracion(paramsDocTrans));
		/*obtengo lista de series*/
		/****/
		Map<String, String> params = new HashMap<String, String>();
		params.put("documentoAduanero", paramsDocTrans.get("documentoAduanero").toString());
		params.put("num_corredoc", paramsDocTrans.get("num_corredoc").toString());
		params.put("num_declaracion", paramsDocTrans.get("num_declaracion").toString());
		params.put("cod_aduana", paramsDocTrans.get("cod_aduana").toString());
		params.put("ann_presen", paramsDocTrans.get("ann_presen").toString());
		params.put("cod_regimen", paramsDocTrans.get("cod_regimen").toString());
		int  postal=1;
		if(codViatrans.equals("0")){
			postal= 0;
		}

		// Para Declaracion en Proceso se filtran las Series
		params.put("estadoDUA", paramsDocTrans.get("estadoDUA").toString());

		List lstSeries = null;
		if (series == null) {
			lstSeries = serieService.obtenerListadoSeries(params);
		} else {
			lstSeries = series;
		}
		List<Map<String, Object>> lstDetDeclaraActual = new ArrayList<Map<String,Object>>(); //aqui se almacenan las series de la declaracion
		if(!lstSeries.isEmpty()){lstDetDeclaraActual = Utilidades.copiarLista(lstSeries);}

		if(lstDetDeclaraActual.size()>0){
			//P34 EJHM
			String [][] lstDocumentosDeTransporteSerie = new String[lstDetDeclaraActual.size()][2];
			int i = 0;
			if(!lstDetDeclaraActual.isEmpty()){
				for (Map serie : lstDetDeclaraActual){
					if(!StringUtils.isEmpty(serie.get("NUM_DOCTRANSP").toString().trim())){
						//P34 AFMA lstDocumentosDeTransporteSerie[i] = serie.get("NUM_DOCTRANSP").toString();
						lstDocumentosDeTransporteSerie[i][0] = serie.get("NUM_DOCTRANSP").toString()+" de la serie "+serie.get("NUM_SECSERIE").toString();
						lstDocumentosDeTransporteSerie[i][1] = serie.get("NUM_DOCTRANSP").toString();
						i++;
					}else{
						return "Debe registrar el n�mero de documento de transporte" ;
					}

				}
			}

			/****/
			List<DocumentoDeTransporte> listaDocumentoTransporteManifiesto = new ArrayList<DocumentoDeTransporte>(); // del manifiesto
			listaDocumentoTransporteManifiesto = documentoDeTransporteService.obtenerDocumentosDeTransporteByParameterMap2(paramsDocTrans);

			/**/
			if(listaDocumentoTransporteManifiesto != null && !listaDocumentoTransporteManifiesto.isEmpty()){


				String []  documentosDeTransporteManifiesto = new String[listaDocumentoTransporteManifiesto.size()];
				if(listaDocumentoTransporteManifiesto.size()>0){
					//String []  documentosDeTransporteManifiesto = new String[listaDocumentoTransporteManifiesto.size()];
					int j = 0;
					if(!listaDocumentoTransporteManifiesto.isEmpty()){
						for (DocumentoDeTransporte documentoDeTransporte: listaDocumentoTransporteManifiesto){
							if(documentoDeTransporte.getNumeroDocumentoTransporte()!= null){   // TODO LO DIFERENTE COD_VIA <> 0
								documentosDeTransporteManifiesto[j] = documentoDeTransporte.getNumeroDocumentoTransporte(); 
								totalPesoTransporte=totalPesoTransporte.add(documentoDeTransporte.getPesoRecibido());
								totalBultoTransporte=totalBultoTransporte.add(documentoDeTransporte.getBultosRecibidos());
							}
							j++;
						}
					}
				}
				//P34 �el objeto tiene que ser igual para que el utilitario  ArrayUtils devuelva true
				// o el  commoms jar necesita ser actualizado?
				for (String[] numDocumentoTransporte : lstDocumentosDeTransporteSerie) {

					//for (String docManifiestTransporte : documentosDeTransporteManifiesto) {

					if(!ArrayUtils.contains(documentosDeTransporteManifiesto , numDocumentoTransporte[1])){  
						if(postal==0){
							return "El documento de transporte (aviso postal)  "+numDocumentoTransporte[0]+" no coincide con el consignado en el manifiesto postal  "+numManifiesto;
						}
						/*INICIO-P34 PAS20165E220200126 AFMA*/
						// P34 AFMA return "El n�mero de documento de transporte "+numDocumentoTransporte+" no coincide con el consignado en el manifiesto de carga "+numManifiesto;
						//return "El n�mero de documento de transporte "+numDocumentoTransporte[0]+" no coincide con el consignado en el manifiesto de carga "+Utilidades.formatoNumeroManifiesto(codTipmanifiesto,codViatrans,codAduamanifiesto, annManifiesto, numManifiestoFormato);
						/*FIN-P34 PAS20165E220200126 AFMA*/
					}
					//}

				}

			}   
			if(postal==0&&totalPesoTransporte.compareTo(new BigDecimal("0"))==0 && totalBultoTransporte.compareTo(new BigDecimal("0"))==0){
				return "No se han registrado los pesos y bultos recibidos en el manifiesto postal";
			}
		}

		return "";
	}


	/*fin gdlr*/

	/**
	 * 
	 * juazor RIN13
	 * 
	 */
	public boolean seDescargaronTodosLosContenedores(List<Map<String, Object>> listaDocumentosDeTransporte){

		for(Map<String, Object> documento : listaDocumentosDeTransporte){
			if(documento.get("registroTransporte").equals("PENDIENTE")){
				return false;
			}

		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 * @author jlunah,juazor
	 */
	public Map<String, Object> validarDeclaParaContDespacho(Map<String, Object> params) throws ServiceException {

		Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
		//String acceso = MapUtils.getMapValor(params, "acceso");
		String msgDeudas = "";


		try{
			/* inicio 1.1 */
			if (MapUtils.esMapaNulo(declaracion)) {
				declaracion = new HashMap<String, Object>();
				declaracion.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return declaracion;
			}/* fin 1.1 */

			/* P14 - 3006 - Inicio - lrodriguezc */

			declaracion = verificarAbandonoVoluntario(declaracion);
            
            /*INICIO P42 mercancia dispuesta*/
            String codigoEstado = (String) declaracion.get("COD_ESTDUA");
			if(codigoEstado.equals("18")){
            	declaracion.put("error","La mercanc�a de la declaraci�n se encuentra dispuesta totalmente.");
              	return declaracion;
			}
            
			String mensajeBloqueo =" ";	
			params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();			
			List<Map<String,Object>> lstMercDispuestas1 = null;
			lstMercDispuestas1= disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(params); 
			int varMerDis=lstMercDispuestas1.size();
			if(lstMercDispuestas1.size()>0 && !lstMercDispuestas1.isEmpty() && lstMercDispuestas1!=null){
				lstResultadoMercancia.addAll(lstMercDispuestas1);
				for(int i=0; i<=varMerDis-1;i++){
					String item= (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
					String seriemd= (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
					String docDispo= (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
					String fecDocDispo= (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
					String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
					mensajeBloqueo= mensajeBloqueo +" Item["+item+"] de la Serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
												+docDispo+"] de fecha ["+fecDoc1+"]";
				}			  			 
				declaracion.put("aviso",mensajeBloqueo);
			}
			/*FIN P42 mercancia dispuesta*/   				 
            
            
			/* P14 - 3006 - Final - lrodriguezc */

			String num_corredoc = declaracion.get("NUM_CORREDOC").toString(); // GRG

			/* inicio 1.2 */
			if ( (declaracion.get("COD_CANAL").equals(Constantes.CANAL_ROJO)) || 
					(declaracion.get("COD_CANAL").equals(Constantes.CANAL_NARANJA) &&
							(declaracion.get("COD_INDICADOR").equals(Constantes.IND_CAMBIO_REC_FISICO)))
					){

			}else{
				declaracion.put("error","La declaraci�n no ha sido seleccionada a reconocimiento f�sico");
				return declaracion;
			}
			/* fin 1.2 */

			/* inicio 1.3 */
			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(params));
			if (!codigoFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario"))) {
				if (codigoFuncionario.equals("")) {
					Map<String, Object> paramEspeDocu = new HashMap<String, Object>();
					paramEspeDocu.put("cod_estrev", "09");
					paramEspeDocu.put("cod_aduana", params.get("cod_aduana").toString());
					paramEspeDocu.put("ann_presen", params.get("ann_presen").toString());
					paramEspeDocu.put("cod_regimen", params.get("cod_regimen").toString());
					paramEspeDocu.put("num_declaracion",params.get("num_declaracion").toString());

					String varConfirma = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(paramEspeDocu));
					if ((varConfirma).length() > 0) {
						declaracion.put("error","No se permite registro de diligencia de despacho para la presente DUA con resultado de reconocimiento f�sico 06.");
					} else {
						declaracion.put("error","El Usuario no tiene asignada la Declaraci�n.");
					}
				} else {
					declaracion.put("error","El Usuario no tiene asignada la Declaraci�n.");
					return declaracion;
				}
			}
			/* fin 1.3 */


			/* 1.4 */
			Map<String, Object> map14 = new HashMap<String, Object>();
			map14=diligenciaService.findDuaDiligenciada(num_corredoc);

			if (map14!=null)
			{
				declaracion.put("error","La Declaracion ya fue diligenciada.");
				return declaracion;
			}
			/* fin 1.4 */



			/* inicio 1.5 */
			String msgValidacion = validarRectificacionesPendientes(num_corredoc);
			if (StringUtils.isNotEmpty(msgValidacion))
			{
				declaracion.put("error", msgValidacion);
				return declaracion;
			}

			//			// 01 rectificacion
			//			Map<String, Object> parametros = new HashMap<String, Object>();
			//			parametros.put("NUM_CORREDOC", num_corredoc);
			//			parametros.put("COD_TIPSOL", "01"); // rectificacion electronica
			//
			//			List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(parametros);
			//			if (listSolicitudesRecti != null
			//					|| listSolicitudesRecti.size() != 0) {
			//				String tempEstaRecti = "";
			//				String numCorreDocSolicitud = "";
			//
			//				// buscamos la solicitudes que esten en estado pendiente de
			//				// evaluacion/ on
			//				// proceso de evaluacion
			//				// ordenamos el resultado por fecha en orden descendente
			//				if (listSolicitudesRecti.size() > 0) {
			//					Collections.sort(listSolicitudesRecti,
			//							new Comparator<Map<String, Object>>() {
			//								@Override
			//								public int compare(Map<String, Object> thiss,
			//										Map<String, Object> that) {
			//									Date nthiss = (Date) thiss
			//											.get("FEC_SOLICITUD");
			//									Date nthat = (Date) that
			//											.get("FEC_SOLICITUD");
			//									return nthat.compareTo(nthiss);
			//								}
			//							});
			//				}
			//
			//				for (Map<String, Object> map : listSolicitudesRecti) {
			//					if (map.get("COD_ESTARECTI") == null) {
			//						continue;
			//					}
			//					tempEstaRecti = (String) map.get("COD_ESTARECTI");
			//					if (ArrayUtils.contains(
			//							new String[] { Constantes.COD_PENDIENTE_EVALUAR },
			//							tempEstaRecti)) {
			//						declaracion
			//								.put("error",
			//										"La Declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado PENDIENTE DE EVALUACION");
			//						return declaracion;
			//					}
			//
			//					if (ArrayUtils.contains(
			//							new String[] { Constantes.COD_EN_EVALUACION },
			//							tempEstaRecti)) {
			//						declaracion
			//								.put("error",
			//										"La Declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado EN EVALUACION");
			//						return declaracion;
			//					}
			//				}
			//				
			//			}/* fin 1.5 */

			/* inicio 1.6 */

			Map<String, Object> newparametros = new HashMap<String, Object>();

			newparametros.put("COD_REGIMEN", params.get("cod_regimen"));
			newparametros.put("COD_ADUANA", params.get("cod_aduana"));
			newparametros.put("ANN_PRESEN", params.get("ann_presen"));
			newparametros.put("NUM_DECLARACION", params.get("num_declaracion"));

			Map<String, Object> mapaCabDeclara = this.cabDeclaraDAO
					.findNumCorreDocAndNumOrdenByDeclaracion(newparametros);

			String codCanal = MapUtils.getMapValor(mapaCabDeclara, "COD_CANAL");
			String fechaRecepcion = new SimpleDateFormat(
					Constantes.FORMAT_ddMMyyyy).format(mapaCabDeclara
							.get("FEC_RECEP"));
			boolean esCanalRojoOrNaranja = ArrayUtils.contains(new String[] {
					Constantes.CANAL_NARANJA, Constantes.CANAL_ROJO },
					codCanal.trim());
			boolean noTieneFechaRecepcion = fechaRecepcion
					.equals(Constantes.DEFAULT_FECHA_BD);

			if (esCanalRojoOrNaranja && noTieneFechaRecepcion) {
				declaracion
				.put("error",
						"No se cuenta con el registro de Recepci�n de Documentos");
				return declaracion;
			}/* fin 1.6 */



			/* 1.7 */

			Object o = swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ + declaracion.get("COD_ADUANA").toString().trim()));
			swapperDatasource.swap(o);

			Expedi expedi =  new Expedi();

			Integer O_NRO = Integer.parseInt(declaracion.get("NUM_DECLARACION").toString());

			expedi.setoNro(O_NRO);
			expedi.setoAnno(declaracion.get("ANN_PRESEN").toString());
			expedi.setCodiAdua(declaracion.get("COD_ADUANA").toString());

			List<Expedi>  listExpediDua = expediDAO.selectByDocumento(expedi);

			if(listExpediDua != null && listExpediDua.size() != 0){

				for (Expedi  expedis :  listExpediDua) {
					if(expedis.getProcedim().equals( "3071") && expedis.getFechConc().equals(Integer.valueOf(0))){
						declaracion.put("error","DUA tiene expediente Pendiente de concluir");
						return declaracion;
					}

				}//fin del for

			}//fin del if


			/* fin 1.7 */


			/*  1.8 - juazor - Inicio */

			// se verifica se la DUA tiene deudas pendientes de pago,
			// excepto para el regimen
			// 20 y tipo de despacho 2,11,12

			/* amaancilla NC 2015-024723 esto nadie lo pidio se comena
			if (!(declaracion.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)) ||
					!(declaracion.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_70_DEPOSITO)) &&
					SunatStringUtils.isStringInList(declaracion.get("COD_TIPDESP").toString(), "2002,2011,2012")) {
				msgDeudas = deudaService.tieneDeudaPendiente(declaracion);
			}

			if (!StringUtils.isEmpty(msgDeudas)){
				declaracion.put("error", msgDeudas);
			}else{
				Map<String, Object> odParam = new HashMap<String, Object>();
				odParam.put("rladuaso", declaracion.get("COD_ADUANA").toString());
				odParam.put("rlanoaso", (declaracion.get("ANN_PRESEN").toString().trim().substring(2, 4)));
				odParam.put("rlnumaso", declaracion.get("NUM_DECLARACION").toString());
				odParam.put("rlregimen", declaracion.get("COD_REGIMEN").toString());

				List<Map<String, Object>> lstDeudas = this.soporteService.validarOrdeDepoPendPago(odParam);

				if (!CollectionUtils.isEmpty(lstDeudas) && !ordeDepoPendCancelar(lstDeudas)){
					declaracion.put("error", "La Declaracion tiene Orden de Deposito sin cancelar o afianzar.");
					return declaracion;
				}
			}*/


			String tieneDuaGarantizada = SunatStringUtils.trim(declaracion.get("NUM_CTACTE").toString());

			if (!SunatStringUtils.isEmpty(tieneDuaGarantizada)) {
				declaracion.put("error","DUA garantizada bajo el art�culo 160� de la LGA, no corresponde remitir a Continuaci�n de Despacho");
				return declaracion;
			}


			/* fin 1.8 */



			// validacion no acogida a valor provicional

			Map<String, Object> parame = new HashMap<String, Object>();
			parame.put("NUM_CORREDOC", num_corredoc);

			List<Map<String, Object>> listValorProvisional = vFOBProvisionalDAO.findMapMontoProvByMap(parame);

			// basta que en COD_TIPOVALOR sea igual a 2 - lanzar mensaje!!
			// 1 = no
			// 2 = acogido

			for (Map<String, Object> map : listValorProvisional) {

				if (map.get("COD_TIPOVALOR").equals("2")) {
					declaracion.put("error","DUA acogida a valor Provisional, no corresponde remitir a Continuaci�n de Despacho");
					return declaracion;

				}
			}

			// si cuenta con diligencia continuacion de despacho
			Map<String, Object> parame1 = new HashMap<String, Object>();
			parame1.put("NUM_CORREDOC", num_corredoc);
			parame1.put("COD_TIPDILIGENCIA",Constantes.DILIG_CONT_DESPACHO);

			List<Map<String, Object>> listaDiligencia = cabDiligenciaDAO.select(parame1);		

			if (!CollectionUtils.isEmpty(listaDiligencia)) {

				declaracion
				.put("error",
						"Ya registr� diligencia de continuaci�n del despacho, para continuar ingresa a la Opci�n Diligencia de Despacho");
				return declaracion;
			}


		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return declaracion;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @author juazor
	 */

	public Map<String, Object> validarDeclaParaDescargaParcial(
			Map<String, Object> params) throws ServiceException {


		Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
		String acceso = MapUtils.getMapValor(params, "acceso");
		String msgDeudas = "";

		try { 

			/* inicio 1.1 */
			if (MapUtils.esMapaNulo(declaracion)) {
				declaracion = new HashMap<String, Object>();
				declaracion.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return declaracion;
			}/* fin 1.1 */

			/* P14 - 3006 - Inicio - lrodriguezc */

			declaracion= verificarAbandonoVoluntario(declaracion);

            //PAS20145E220000427 - mtorralba 20150922 - Inicio
            Map<String,Object> msgError = new HashMap<String, Object>();
            String estadoDua = declaracion.get("COD_ESTDUA").toString();
			if(estadoDua.equals("15")){
				declaracion.put("error","Se requiere registrar la respuesta a la notificaci�n. Verifique");
				return declaracion;
			/*inicio PAS20145E220000427*/
			}else if (Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE.equals(estadoDua)){
				declaracion.put("error","La mercanc�a de la declaraci�n se encuentra dispuesta totalmente. Verifique");
				return declaracion;
			}else {
				String mensajeBloqueo = tieneMercanciaDispuestaParcial(Long.valueOf(declaracion.get("NUM_CORREDOC").toString()));
				declaracion.put("warning",mensajeBloqueo);
			}
            //PAS20145E220000427 - mtorralba 20150922 - Fin
            
            
			/* P14 - 3006 - Final - lrodriguezc */
			String num_corredoc = declaracion.get("NUM_CORREDOC").toString(); // GRG


			/* inicio 1.2 */
			String codigoFuncionario = StringUtils.defaultString(espeDocuDAO
					.findEspecAsigByDocumento(params));
			if (!codigoFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario").toString().trim()))  //PAS20155E220000054/23
			{
				if (codigoFuncionario.equals("")) {
					Map<String, Object> paramEspeDocu = new HashMap<String, Object>();
					paramEspeDocu.put("cod_estrev", "09");
					paramEspeDocu.put("cod_aduana", params.get("cod_aduana")
							.toString());
					paramEspeDocu.put("ann_presen", params.get("ann_presen")
							.toString());
					paramEspeDocu.put("cod_regimen", params.get("cod_regimen")
							.toString());
					paramEspeDocu.put("num_declaracion",
							params.get("num_declaracion").toString());

					String varConfirma = StringUtils.defaultString(espeDocuDAO
							.findEspecAsigByDocumento(paramEspeDocu));
					if ((varConfirma).length() > 0) {
						declaracion
						.put("error",
								"No se permite registro de diligencia de despacho para la presente DUA con resultado de reconocimiento f�sico 06.");
					} else {
						declaracion.put("error",
								"El Usuario no tiene asignada la Declaraci�n.");
					}
				} else {
					declaracion.put("error",
							"El Usuario no tiene asignada la Declaraci�n.");
				}
			}/* fin 1.2 */

			/* 1.3 */
			boolean resultado;
			Map<String, Object> diligencia = new HashMap<String, Object>();
			diligencia.put("numcorredoc", declaracion.get("NUM_CORREDOC").toString());
			diligencia.put("codtipdiligencia", "03");
			resultado = validaDiligenciaService.validaTieneDiligenciaTipo(diligencia) ;


			if(resultado)
			{
				declaracion.put("error","La Declaracion ya fue Diligenciada");
				return declaracion;
			}/*fin 1.3*/


			/* inicio 1.4 */
			// 01 rectificacion
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("NUM_CORREDOC", num_corredoc);
			parametros.put("COD_TIPSOL", "01"); // rectificacion electronica

			List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(parametros);
			if (listSolicitudesRecti != null
					|| listSolicitudesRecti.size() != 0) {
				String tempEstaRecti = "";
				//String numCorreDocSolicitud = "";

				// buscamos la solicitudes que esten en estado pendiente de
				// evaluacion/ on
				// proceso de evaluacion
				// ordenamos el resultado por fecha en orden descendente
				if (listSolicitudesRecti.size() > 0) {
					Collections.sort(listSolicitudesRecti,
							new Comparator<Map<String, Object>>() {
						@Override
						public int compare(Map<String, Object> thiss,
								Map<String, Object> that) {
							Date nthiss = (Date) thiss
									.get("FEC_SOLICITUD");
							Date nthat = (Date) that
									.get("FEC_SOLICITUD");
							return nthat.compareTo(nthiss);
						}
					});
				}

				for (Map<String, Object> map : listSolicitudesRecti) {
					if (map.get("COD_ESTARECTI") == null) {
						continue;
					}
					tempEstaRecti = (String) map.get("COD_ESTARECTI");
					if (ArrayUtils.contains(
							new String[] { Constantes.COD_PENDIENTE_EVALUAR },
							tempEstaRecti)) {
						declaracion
						.put("error",
								"La Declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado PENDIENTE DE EVALUACION");
						return declaracion;
					}

					if (ArrayUtils.contains(
							new String[] { Constantes.COD_EN_EVALUACION },
							tempEstaRecti)) {
						declaracion
						.put("error",
								"La Declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado EN EVALUACION");
						return declaracion;
					}
				}

			}
			/* fin 1.4 */


			/* inicio 1.5 */

			if ( (declaracion.get("COD_CANAL").equals(Constantes.CANAL_ROJO)) || 
					(declaracion.get("COD_CANAL").equals(Constantes.CANAL_NARANJA) &&
							(declaracion.get("COD_INDICADOR").equals(Constantes.IND_CAMBIO_REC_FISICO)))
					){

			}else{
				declaracion.put("error","La declaraci�n no ha sido seleccionada a reconocimiento f�sico");
				return declaracion;
			}


			/* fin */



			/* inicio 1.6 */
			/* que el regimen, modalidad y tipo de lugar de descarga corresponda a los registrados en la configuracion 
			 * de las diligencias de descargas parciales.
			 */

			String mensaje=""; 

			mensaje = diligenciaService.validarValidacionDescargasParciales(declaracion);

			/**RIN13*/
			SolicitudAutorizacionZonaPrimaria solicitudAutorizacionZonaPrimaria = new SolicitudAutorizacionZonaPrimaria();
			solicitudAutorizacionZonaPrimaria.setParticipante(new Participante());
			solicitudAutorizacionZonaPrimaria.getParticipante().setNumeroDocumentoIdentidad(declaracion.get("NUM_DOCIDENT_PIM").toString().trim());
			solicitudAutorizacionZonaPrimaria.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
			solicitudAutorizacionZonaPrimaria.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(declaracion.get("COD_ADUANA").toString().trim());  

			solicitudAutorizacionZonaPrimaria.getDatoOtroDocSoporte().setAnndocasoc(declaracion.get("ANN_PRESEN").toString().trim());//PAS20191U220200013

			/*INICIO-amancila*/
			String cod_tiplugarrecp = MapUtils.getMapValor(declaracion, "COD_TIPLUGARRECEP", StringUtils.EMPTY) ;
			/*FIN-amancilla*/
			AutorizacionZonaPrimariaService autorizacionZonaPrimaria = this.fabricaDeServicios.getService("autorizacionZonaPrimariaService");
			List<SolicitudAutorizacionZonaPrimaria> lstAutorizacionZonaPrimaria = autorizacionZonaPrimaria.consultarAutorizacionZonaPrimaria(solicitudAutorizacionZonaPrimaria);
			int indVigencia = -1;
			if(!lstAutorizacionZonaPrimaria.isEmpty()){
				Date fecVencimiento = lstAutorizacionZonaPrimaria.get(0).getDatoOtroDocSoporte().getFecvencimiento();
				Date today = SunatDateUtils.getDate(new SimpleDateFormat("dd/MM/yyyy").format(new Date())); //PAS20155E220000054/23				//Date today = new Date();
				indVigencia = SunatDateUtils.compareDate(fecVencimiento,today);            	   
			}               
			/**FIN RIN13*/

			/*INICIO-amancila*/
			if ((StringUtils.isNotEmpty(mensaje) || (indVigencia==-1 && "04".equals(cod_tiplugarrecp)))){
				declaracion.put("error", "La declaracion no cumple con el regimen, modalidad y tipo de lugar de descarga configurados para la diligencia de descargas parciales");
				return declaracion;
			}

			/* fin 1.6    */

			/* 1.7 */
			Map<String, Object> newparametros = new HashMap<String, Object>();

			newparametros.put("COD_REGIMEN", params.get("cod_regimen"));
			newparametros.put("COD_ADUANA", params.get("cod_aduana"));
			newparametros.put("ANN_PRESEN", params.get("ann_presen"));
			newparametros.put("NUM_DECLARACION", params.get("num_declaracion"));

			Map<String, Object> mapaCabDeclara = this.cabDeclaraDAO
					.findNumCorreDocAndNumOrdenByDeclaracion(newparametros);

			String codCanal = MapUtils.getMapValor(mapaCabDeclara, "COD_CANAL");
			String fechaRecepcion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapaCabDeclara.get("FEC_RECEP"));
			boolean esCanalRojoOrNaranja = ArrayUtils.contains(new String[] {
					Constantes.CANAL_NARANJA, Constantes.CANAL_ROJO },codCanal.trim());
			boolean noTieneFechaRecepcion = fechaRecepcion.equals(Constantes.DEFAULT_FECHA_BD);

			if (esCanalRojoOrNaranja && noTieneFechaRecepcion) {
				declaracion.put("error","No se cuenta con el registro de Recepci�n de Documentos");
				return declaracion;
			}
			/* fin 1.7 */


			/* 1.8 */
			/* que no exista registrado un expediemte de rectificacion pendiente asociado a la declaracion
			 * en el modulo de tramite documentario*/
//p24-pase99
//			Expedi expedi =  new Expedi();
//
//			Integer O_NRO = Integer.parseInt(declaracion.get("NUM_DECLARACION").toString());
//
//			expedi.setoNro(O_NRO);
//			expedi.setoAnno(declaracion.get("ANN_PRESEN").toString());
//			expedi.setCodiAdua(declaracion.get("COD_ADUANA").toString());
//
//			List<Expedi>  listExpediDua = expediDAO.selectByDocumento(expedi);
//
//			if(listExpediDua != null && listExpediDua.size() != 0){
//
//				for (Expedi  expedis :  listExpediDua) {
//					if(expedis.getProcedim().equals( "3071") && expedis.getFechConc().equals(Integer.valueOf(0)))
//						break;
//				}//fin del for
//				declaracion.put("error","DUA tiene expediente Pendiente de concluir");
//				return declaracion;
//			}//fin del if



			/*  1.9  */
			// se verifica se la DUA tiene deudas pendientes de pago,
			// excepto para el regimen
			// 20 y tipo de despacho 2,11,12

			if (!(declaracion.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO)) ||
					!(declaracion.get("COD_REGIMEN").toString().equals(Constantes.REGIMEN_70_DEPOSITO)) &&
					SunatStringUtils.isStringInList(declaracion.get("COD_TIPDESP").toString(), "2002,2011,2012")) {
				msgDeudas = deudaService.tieneDeudaPendiente(declaracion);
			}

			if (!StringUtils.isEmpty(msgDeudas)){
				declaracion.put("error", msgDeudas);
			}else{
				Map<String, Object> odParam = new HashMap<String, Object>();
				odParam.put("rladuaso", declaracion.get("COD_ADUANA").toString());
				odParam.put("rlanoaso", (declaracion.get("ANN_PRESEN").toString().trim().substring(2, 4)));
				odParam.put("rlnumaso", declaracion.get("NUM_DECLARACION").toString());
				odParam.put("rlregimen", declaracion.get("COD_REGIMEN").toString());

				List<Map<String, Object>> lstDeudas = this.soporteService.validarOrdeDepoPendPago(odParam);

				if (!CollectionUtils.isEmpty(lstDeudas) && !ordeDepoPendCancelar(lstDeudas)){
					declaracion.put("error", "La Declaracion tiene Orden de Deposito sin cancelar o afianzar.");
					return declaracion;
				}
			}


			//			 String tieneDuaGarantizada = SunatStringUtils.trim(declaracion.get("NUM_CTACTE").toString());
			//				
			//				if (!SunatStringUtils.isEmpty(tieneDuaGarantizada)) {
			//					declaracion.put("error","DUA garantizada bajo el art�culo 160� de la LGA, no corresponde remitir a Descarga Parcial");
			//					return declaracion;
			//				}
			//fin del if
			/* fin 1.9 */    

			/* 1.10 */
			//contenedores asociados
			Map<String ,Object> paramsContenedores = new HashMap<String, Object>();
			paramsContenedores.put("NUM_CORREDOC", num_corredoc);

			List<ConsultaDocuTransManifiesto> listContenedores =  new ArrayList<ConsultaDocuTransManifiesto>();
			listContenedores = obtenerContenedoresDescargaParcial(paramsContenedores);

			if(listContenedores!= null){	
				if(listContenedores.size() == 0){
					//solo se evalua la lista de documentos de transporte, ya que un documento de transporte contiene como minimo
					//un contenedor
					declaracion.put("error","La declaracion no cuenta con contenedores asociados");
					return declaracion;
				}
			}else{
				declaracion.put("error","La declaracion no cuenta con contenedores asociados");
				return declaracion;
			}



			/* 1.11 */
			String codAduamanifiesto = declaracion.get("COD_ADUAMANIFIESTO") !=null ? declaracion.get("COD_ADUAMANIFIESTO").toString() : ""; 
			String codViatrans = declaracion.get("COD_VIATRANS") !=null ? declaracion.get("COD_VIATRANS").toString() : ""; 
			Integer annManifiesto = declaracion.get("ANN_MANIFIESTO") !=null ? Integer.parseInt(declaracion.get("ANN_MANIFIESTO").toString()) : new Integer(0);
			String numManifiestoFormato = declaracion.get("NUM_MANIFIESTO") !=null ? declaracion.get("NUM_MANIFIESTO").toString() : "";
			String numManifiesto = StringUtils.leftPad(numManifiestoFormato, 6);
			String codTipmanifiesto = declaracion.get("COD_TIPMANIFIESTO") !=null ? declaracion.get("COD_TIPMANIFIESTO").toString() : "";

			//List<DocumentoDeTransporte> listaDocumentoTransporteCabecera = new ArrayList<DocumentoDeTransporte>();

			Map<String, Object> paramsDocTrans = new HashMap<String, Object>();
			paramsDocTrans.put("numeroManifiesto", numManifiesto);
			paramsDocTrans.put("anioManifiesto", annManifiesto);
			paramsDocTrans.put("codigoAduana", codAduamanifiesto );
			paramsDocTrans.put("codigoTipoManifiesto", codTipmanifiesto);
			paramsDocTrans.put("codigoViaTransporte", codViatrans);

			/*seteamos valores para las series (con las series se filtran los documentos de transporte de la declaracion)*/
			paramsDocTrans.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
			paramsDocTrans.put("num_corredoc", num_corredoc);
			paramsDocTrans.put("num_declaracion", declaracion.get("NUM_DECLARACION"));
			paramsDocTrans.put("cod_aduana", declaracion.get("COD_ADUANA"));
			paramsDocTrans.put("ann_presen", declaracion.get("ANN_PRESEN"));
			paramsDocTrans.put("cod_regimen", declaracion.get("COD_REGIMEN"));
			paramsDocTrans.put("estadoDUA", declaracion.get("COD_ESTDUA"));
			paramsDocTrans.put("acceso", acceso);


			List<Map<String, Object>> listaDocumentosDeTransporte = new ArrayList<Map<String, Object>>();
			listaDocumentosDeTransporte.addAll(obtieneDocumentosDeTransporteDeLaDeclaracion(paramsDocTrans));

			if(this.seDescargaronTodosLosContenedores(listaDocumentosDeTransporte)){
				declaracion.put("error", "La declaracion no cuenta con contenedores asociados pendientes de diligencia de descargas parciales");
				return declaracion;
			}




		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return declaracion;
	}


	/**
	 * @author jlunah
	 * Verifica que la declaraci�n est� exceptuada
	 */
	public boolean validarDeclaracionExceptuada(Map<String, Object> declaracion){
		//Si es un env�o de Socorro
		if(declaracion.get("IND_SOCORRO").equals("S")){
			return true;
		}

		//Si el tipo de tratamiento de la mercanc�a es Donaciones en tr�mite (c�digo 4)
		if(declaracion.get("COD_TIPTRATMERC").equals("4")){
			return true;
		}

		/*Si por lo menos una serie de la DUA cuenta con alguno 
		 * de los siguientes c�digos liberatorios: 
		 * 2000, 2001, 2002, 2003, 3806,3807, 3808, 3809, 3810,
		 * 3310,  3312, 3814, 3302, 3303, 4423, 4425, 4456.*/
		List<Map<String,Object>> listaConvenioSerie = new ArrayList<Map<String,Object>>();
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
		param.put("COD_TIPCONVENIO", "C");
		listaConvenioSerie = convenioSerieDAO.select(param);
		//String [] codigosLiberatorios =  { "2000", "2001", "2002", "2003", "3806" , "3807", "3808", "3809", "3810", "3310",  "3312", "3814", "3302", "3303", "4423", "4425", "4456" } ;
		String [] codigosLiberatorios = Constantes.LISTA_PARA_CODIGOS_LIBERATORIOS ;
		boolean contiene = false ;
		if(!listaConvenioSerie.isEmpty()){
			for(Map<String,Object> convenioSerie : listaConvenioSerie){
				if(ArrayUtils.contains(codigosLiberatorios, convenioSerie.get("COD_CONVENIO"))){
					contiene = true ; 
				}
			}
			if(contiene) return contiene;
		}

		/*Si por lo menos una serie de la DUA corresponde a una SubPartida Nacional de los cap�tulos :
		 * 98.01, 98.02, 98.03, 98.04, 98.05 y 98.06 */
		//String [] subPartidas = {"9801", "9802", "9803", "9804", "9805" ,"9806"};
		String [] subPartidas =Constantes.LISTA_SUBPARTIDA_DECLARACION_EXEPTUADA;
		Map<String, String> params = new HashMap<String, String>();

		params.put("documentoAduanero", Constantes.COD_DOCUMENTO_ADUANERO);
		params.put("num_corredoc", declaracion.get("NUM_CORREDOC").toString());
		params.put("num_declaracion", declaracion.get("NUM_DECLARACION").toString());
		params.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
		params.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
		params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());
		params.put("estadoDUA", declaracion.get("COD_ESTDUA").toString());

		List lstDetDeclara = serieService.obtenerListadoSeries(params);
		contiene = false ;
		if(!lstDetDeclara.isEmpty()){
			for( int i = 0 ; i < lstDetDeclara.size() ; i++ ){
				Map<String, Object> mapDetDeclara = (Map<String, Object>) lstDetDeclara.get(i);
				String partida = mapDetDeclara.get("NUM_PARTNANDI").toString().substring(0, 4);
				if(ArrayUtils.contains(subPartidas, partida )){
					contiene =  true ; 
				}
			}
			if(contiene) return contiene;
		}

		//params.put("acceso", request.getParameter("hdn_acceso") != null ? request.getParameter("hdn_acceso") : "");

		//	      String tipoDiligencia = (String) getVariableSesion(request, EnumVariablesSession.TIP_DILIGENCIA);
		//	      if ("10".equals(tipoDiligencia))
		//	      {
		//	        if (mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO")!=null
		//	            && "EN_PROCESO".equals(mapCabDeclara.get("COD_ESTADO_RECTIFICACION_OFICIO").toString()))
		//	         {
		//	          params.put("COD_ESTADO_RECTIFICACION_OFICIO", "EN_PROCESO");
		//	         }
		//
		//	      }

		return false;
	}

	/*RIN13FSW-FIN*/
	/**INICIO-RIN13**/
	//private boolean validarDespachoAnticipadoRojo(Map<String, Object> declaracion){
	/*private String validarDespachoAnticipado(Map<String, Object> declaracion){
	  //Validaci�n de declaraci�n de despacho anticipado seleccionada a canal rojo tenga registrado diligencia previa

	  String numeroManifiesto = StringUtils.leftPad((String)declaracion.get("NUM_MANIFIESTO"), 6, ' ');
	  Object oAnioManifiesto = declaracion.get("ANN_MANIFIESTO");
	  Integer anioManifiesto = oAnioManifiesto != null ? Integer.valueOf(oAnioManifiesto.toString()) : null;
	  String codigoAduana = (String)declaracion.get("COD_ADUAMANIFIESTO");
	  String tipoManifiesto = (String)declaracion.get("COD_TIPMANIFIESTO");
	  String viaTransporte = (String)declaracion.get("COD_VIATRANS");

	  Long numeroCorrelativo = ((BigDecimal)declaracion.get("NUM_CORREDOC")).longValue();
      if(ConstantesDataCatalogo.COD_CANAL_ROJO.equals(declaracion.get("COD_CANAL"))){
			  //if(hasDiligenciaPreviaInCompleta(numeroCorrelativo)){ //RIN13 - paquete2
				  //return "No se ha registrado la diligencia previa a la declaraci�n.";
			  //}

			  //Si la DUA tiene modalidad de despacho �Anticipado� y con canal �Rojo�, verifica que todos los documentos de transporte asociados a la declaraci�n cuente con Nota de Tarja transmitida
			  if(!hasDocTransporteNotaTarja(numeroCorrelativo, numeroManifiesto, anioManifiesto, codigoAduana, tipoManifiesto, viaTransporte)){
				  return "Documento de Transporte no cuenta con Nota de Tarja transmitida";
			  }			  
      }

	  Object oNumeroDeclaracion = declaracion.get("NUM_DECLARACION");
	  Integer numeroDeclaracion = oNumeroDeclaracion != null ? Integer.parseInt(oNumeroDeclaracion.toString()) : null;
	  Object oAnioDeclaracion = declaracion.get("ANN_PRESEN");
	  String anioDeclaracion =  oAnioDeclaracion != null ? oAnioDeclaracion.toString() : null;
	  String regimenDeclaracion = (String)declaracion.get("COD_REGIMEN");
	  String aduanaDeclaracion = (String)declaracion.get("COD_ADUANA");
	  Date fechaDeclaracion =  (Date) declaracion.get("FEC_DECLARACION");
	  String mensaje = isPlazoMercanciaArriboDespachoAnticipado(numeroDeclaracion, anioDeclaracion, regimenDeclaracion, aduanaDeclaracion, fechaDeclaracion, numeroManifiesto, anioManifiesto, codigoAduana, tipoManifiesto, viaTransporte,numeroCorrelativo);

//	  if(!isPlazoMercanciaArriboDespachoAnticipado(numeroDeclaracion, anioDeclaracion, regimenDeclaracion, aduanaDeclaracion, fechaDeclaracion, 
//			  numeroManifiesto, anioManifiesto, codigoAduana, tipoManifiesto, viaTransporte))
//	  
//	  {
//		  //El sistema env�a una notificaci�n al Buz�n SOL del importador y del Agente de Aduana, indicando que la mercanc�a arrib� fuera del plazo y en el Portal Web
//		  String tipoDocumentoIdentidad = (String)declaracion.get("COD_TIPDOC_PIM");
//		  if(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumentoIdentidad)){
//			  this.enviarAvisoDeclaracionArriboFueraPlazo(numeroDeclaracion, anioDeclaracion, regimenDeclaracion, aduanaDeclaracion, 
//				  tipoDocumentoIdentidad, (String)declaracion.get("NUM_DOCIDENT_PIM"), (String)declaracion.get("NOM_RAZONSOCIAL_PIM"));
//		  }
//		  tipoDocumentoIdentidad = (String)declaracion.get("COD_TIPDOC_PDE");
//		  if(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumentoIdentidad)){
//			  this.enviarAvisoDeclaracionArriboFueraPlazo(numeroDeclaracion, anioDeclaracion, regimenDeclaracion, aduanaDeclaracion, 
//					  tipoDocumentoIdentidad, (String)declaracion.get("NUM_DOCIDENT_PDE"), (String)declaracion.get("NOM_RAZONSOCIAL_PDE"));
//		  }
//		  return "MERCANCIA ARRIBO FUERA DEL PLAZO ESTABLECIDO EN EL ARTICULO 132� DE LA LEY GENERAL DE ADUANAS, Declaraci�n requiere cambio de modalidad de Despacho Anticipado a Excepcional.";
//	  }

	  if (!mensaje.equals("ok"))
	  {
		  return mensaje;
	  }

	  return "";
  }*/
	/*RIN13INSI*/
	/*private boolean hasDiligenciaPreviaInCompleta(Long numeroCorrelativo){
	  Diligencia diligencia = new Diligencia();
	  diligencia.setNumeroCorrelativo(numeroCorrelativo);
      diligencia.setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_REV_PREVIA);
      boolean tienerevision = this.diligenciaService.hasDiligencia(diligencia);
//
      diligencia.setCodigoTipoDiligencia(ConstantesDataCatalogo.COD_DILIG_PREVIA);
      boolean tienePrevia = this.diligenciaService.hasDiligencia(diligencia);
//
	  return (tienerevision==true && tienePrevia==false)?true:false;
  }*/

	public boolean hasDocTransporteNotaTarja(Long numeroCorrelativo, String numeroManifiesto, 
			Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte){

		return hasDocTransporteNotaTarja(numeroCorrelativo,  numeroManifiesto, anioManifiesto,  codigoAduana ,  tipoManifiesto,  viaTransporte,null);
	}

	/*INICIO RIN 13 PAQ2*/
	public boolean hasDocTransporteNotaTarja(Long numeroCorrelativo, String numeroManifiesto, 
			Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte,Integer indCampoUsar){
		//PAS20155E220000094 GGRANADOS INICIO
		List<Map<String, Object>> listaDocTransporte = this.serieService.obtenerListaNumeroDocTransporteByDeclaracionYNumDetalle(numeroCorrelativo);
		//PAS20155E220000094 GGRANADOS FIN

		Map<String, Object> paramsBusqueda = new HashMap<String, Object>();
		paramsBusqueda.put("numeroManifiesto", numeroManifiesto);
		paramsBusqueda.put("anioManifiesto", anioManifiesto);
		paramsBusqueda.put("codigoAduana", codigoAduana);
		paramsBusqueda.put("tipoManifiesto", tipoManifiesto);
		paramsBusqueda.put("viaTransporte", viaTransporte);
		/*hosoriov rin 12*/
		if(indCampoUsar==null)
			paramsBusqueda.put("listaNumeroDocTransporte", listaDocTransporte); //jreynoso PAS20155E220000128
		else {
			/*hosoriov rin 12*/
			paramsBusqueda.put("listaDetalleDocTransporte", listaDocTransporte); //jreynoso PAS20155E220000128

		}

		paramsBusqueda.put("estado", ConstantesManifiesto.DOCUMENTO_TRANSPORTE_ESTADO_ANULADO);
		paramsBusqueda.put("hijoAndMaster", true);
		paramsBusqueda.put("tipoEnvio", ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);
		paramsBusqueda.put("indicadorEliminacion", Constantes.IND_NO_ELIMINADO);
		DocumentoOAManifiestoService documentoOAManifiestoService = this.fabricaDeServicios.getService("manifiesto.documentoOAManifiestoService");
		int cantidadNotaTarja = documentoOAManifiestoService.obtenerCantidadOperacionesAsociadaDocumentoTransporte(paramsBusqueda);
		if(cantidadNotaTarja != listaDocTransporte.size()){
			return false;
		}
		return true;
	}
	/*FIN RIN 13 PAQ2*/

	//private boolean isPlazoMercanciaArriboDespachoAnticipado(Integer numeroDeclaracion, String anioDeclaracion,
	/*RIN13FSW*/
	public String isPlazoMercanciaArriboDespachoAnticipado(Integer numeroDeclaracion, String anioDeclaracion,
			String regimenDeclaracion, String aduanaDeclaracion, Date fechaDeclaracion, 
			String numeroManifiesto, Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte, Long numeroCorrelativo){
		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");
		boolean buscarManifiestoSigadActual = false;
		//buscarManifiestoSigadActual = ("4".equals(viaTransporte) || "7".equals(viaTransporte));
		buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte) || ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(viaTransporte));
		
		ManifiestoService manifiestoService = this.fabricaDeServicios.getService("manifiesto.manifiestoService");
		//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(tipoManifiesto, viaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, buscarManifiestoSigadActual);//SAU
		Manifiesto manifiesto =null;
		/**PAS20181U220200049 inicio***/
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
	 		 buscarManifiestoSigadActual = true;//que busque en bdsigad y en sigad
	 		manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(tipoManifiesto,viaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, true);	
	 	}else{/**PAS20181U220200049 fin***/
	 		manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(tipoManifiesto, viaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, buscarManifiestoSigadActual);//SAU
	 	}	
		String mensaje="";

		Date fechaLlegada = new Date();
        //amancilla por donde caiga veo bugs  
		if(manifiesto!=null){

		if(manifiesto.getFechaEfectivaDeLlegada()!=null && !SunatDateUtils.isDefaultDate(manifiesto.getFechaEfectivaDeLlegada())){
			fechaLlegada =manifiesto.getFechaEfectivaDeLlegada();;
		}else{
			//fechaLlegada = manifiesto.getFechaProgramadaLlegada();
			fechaLlegada = fechaDeclaracion;//PAS20165E220200080
		}
		}

		if(!valModalidadService.correspondeModalidadAnticipada(fechaDeclaracion, fechaLlegada)){

			DataCatalogo catPlazoModalidadAnticipadaCasoFortuito = ((CatalogoAyudaService) fabricaDeServicios
					.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
							ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
							ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA_CASO_FORTUITO, fechaDeclaracion);
			Integer plazoModalidadAnticipadaCasoFortuito = SunatNumberUtils.toInteger(catPlazoModalidadAnticipadaCasoFortuito.getDesCorta());
			Date fechaMaxPlazoCasoFortuito = SunatDateUtils.addDay(fechaDeclaracion, plazoModalidadAnticipadaCasoFortuito);

		//Se a�ade validaci�n 
			if(SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fechaMaxPlazoCasoFortuito, SunatDateUtils.COMPARA_SOLO_FECHA)){
			mensaje  = "LA DECLARACION SE ENCUENTRA NUMERADA POSTERIORMENTE AL ARRIBO DEL MEDIO DE TRANSPORTE, NO CORRESPONDE ACOGERSE A LA MODALIDAD DE DESPACHO ANTICIPADO";
			} else {

			//Excede el plazo de los 15 dias 
			//Se evalua que tenga registrado expediente de suspensi�n de plazo con c�digo de procedimiento 1606 concluido con el tipo de conclusi�n procedente
			Expedi paramExpedi = new Expedi();
			paramExpedi.setCodiAdua(aduanaDeclaracion);
			paramExpedi.setoAnno(anioDeclaracion);
			if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimenDeclaracion)){
				paramExpedi.setoTipo(17);	
			}else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(regimenDeclaracion)){
				paramExpedi.setoTipo(32);
			}else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(regimenDeclaracion)){
				paramExpedi.setoTipo(7);
			}else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(regimenDeclaracion)){
				paramExpedi.setoTipo(40);
			}
			paramExpedi.setoNro(numeroDeclaracion);
			/*paramExpedi.setActEstado(ConstantesTramite.EXPEDI_ESTADO_CONCLUIDO);
		  paramExpedi.setTipoConc(ConstantesTramite.EXPEDI_TIPOCONC_PROCEDENTE);*/
			//paramExpedi.setProcedim(ConstantesTramite.PROCEDIM_SUSPENCION_PLAZO_DESPACHO);
			//ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
			//Expedi expediente1606 = expedienteService.getExpediente(paramExpedi);	

			//o, de exceder los 15 d�as calendario pero no superar los 30 d�as calendario y se tenga un expediente en el sistema de tr�mite documentario con c�digo 3126 con resultado procedente 
				//la fecha de llegada no supera los 30 dias
				paramExpedi.setProcedim(ConstantesTramite.PROCEDIM_AMPLIA_PLAZO_ANTICIPADO);
				ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
				//Expedi expediente3126 = expedienteService.getExpediente(paramExpedi);
				List<Expedi> listaExpediente3126 = expedienteService.findByMap(paramExpedi);

				if (!CollectionUtils.isEmpty(listaExpediente3126)) {
					for(Expedi expediente3126 : listaExpediente3126){
						if (ConstantesTramite.EXPEDI_ESTADO_CONCLUIDO.equals(expediente3126.getActEstado()) && ConstantesTramite.EXPEDI_TIPOCONC_PROCEDENTE.equals(expediente3126.getTipoConc())){
							mensaje="ok";
							boolean esNuevaReglaLgaVigente = esNuevaReglaLgaVigente(fechaDeclaracion);
							if(esNuevaReglaLgaVigente){
								boolean esExpedientePresentadoEnPlazo = valModalidadService.correspondeModalidadAnticipada(fechaDeclaracion, SunatDateUtils.getDateFromInteger(expediente3126.getFecexp()));
								if(!esExpedientePresentadoEnPlazo){
									mensaje="expediente fuera de plazo";
								}
						} 

							if(mensaje.equals("ok")){
								break;
							}
						} 
					}
					if(SunatStringUtils.isEmpty(mensaje)){
						Expedi expediente3126 = listaExpediente3126.get(0);
						String numeroExpediente3126 = expediente3126.getCodiAdua() +" - " + expediente3126.getCodAreaDocSust()+" - " +expediente3126.getAnoexpedi()+" - "+expediente3126.getNroexpedi();
						mensaje = "Expediente N� "+ numeroExpediente3126  +" por Arribo tardio por caso fortuito o fuerza mayor, no cuenta con resultado procedente, declaracion excede el plazo para la modalidad de despacho anticipado";
					}
				}else {
					mensaje="DECLARACION EXCEDE EL PLAZO PARA LA MODALIDAD DE DESPACHO ANTICIPADO";
				}
			}
				//				else  if ((expediente1606 != null) && ((ConstantesTramite.EXPEDI_ESTADO_CONCLUIDO.equals(expediente1606.getActEstado()) && ConstantesTramite.EXPEDI_TIPOCONC_PROCEDENTE.equals(expediente1606.getTipoConc()))))
				//					   {	mensaje="ok";  }
				//else  {  mensaje="Expediente por arribo tardio por caso fortuito o fuerza mayor no existe"; }

				//		  if  ((expediente1606 != null)  && (ConstantesTramite.EXPEDI_ESTADO_CONCLUIDO.equals(expediente1606.getActEstado()) && ConstantesTramite.EXPEDI_TIPOCONC_PROCEDENTE.equals(expediente1606.getTipoConc())))
				//		  		{			mensaje="ok"; 	}		
				//				else  
		}else{
			//no excede los dias
			//return true;
			mensaje="ok";
		}
		return mensaje;
	}


	/*INICIO RIN 13 PAQ2*/
	/*private void enviarAvisoDeclaracionArriboFueraPlazo(Integer numeroDeclaracion, String anioDeclaracion, 
		  String regimenDeclaracion, String aduanaDeclaracion, String tipoDocumentoIdentidad, String numeroDocumentoIdentidad, String nombreRazonSocial){
	  if(nombreRazonSocial == null || nombreRazonSocial.trim().equals("")){
		  OperadorAyudaService operadorAyudaService = this.fabricaDeServicios.getService("Ayuda.operadorAyudaService");
		  nombreRazonSocial = operadorAyudaService.getDeclarante(tipoDocumentoIdentidad, numeroDocumentoIdentidad).get("nombre").toString();
  		}

		final FechaBean fechaActual = new FechaBean();
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		mapMensaje.put("tip_usuario", "1");
		mapMensaje.put("cod_usuario", new String[] {numeroDocumentoIdentidad});
		mapMensaje.put("des_asunto", "Notificaci�n");
		mapMensaje.put("razon_social", numeroDocumentoIdentidad);
		mapMensaje.put("num_ruc", numeroDocumentoIdentidad);
		mapMensaje.put("cod_aduana", aduanaDeclaracion);
		mapMensaje.put("ann_presen", anioDeclaracion);
		mapMensaje.put("cod_regimen", regimenDeclaracion);
		mapMensaje.put("num_declaracion", numeroDeclaracion);
		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy"));

		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		PublicacionAvisoService publicacionAvisoService = this.fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(259, data, Constantes.CODIGO_NOTIFICACION, fechaActual.getTimestamp(), new FechaBean("31/12/9999").getTimestamp()); 
  }*/
	/*FIN RIN 13 PAQ2*/
	/*private String validarPlazoMercanciaArriboDespachoUrgente(Map<String, Object> declaracion){
	  String mensaje = "";

	  String numeroManifiesto = StringUtils.leftPad((String)declaracion.get("NUM_MANIFIESTO"), 6, '0');
	  Object oAnioManifiesto = declaracion.get("ANN_MANIFIESTO");
	  Integer anioManifiesto = oAnioManifiesto != null ? Integer.valueOf(oAnioManifiesto.toString()) : null;
	  String codigoAduana = (String)declaracion.get("COD_ADUAMANIFIESTO");
	  String tipoManifiesto = (String)declaracion.get("COD_TIPMANIFIESTO");
	  String viaTransporte = (String)declaracion.get("COD_VIATRANS");

	  boolean buscarManifiestoSigadActual = false;
	  buscarManifiestoSigadActual = ("4".equals(viaTransporte) || "7".equals(viaTransporte));


	  ManifiestoService manifiestoService = this.fabricaDeServicios.getService("manifiesto.manifiestoService");
	  Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(tipoManifiesto, viaTransporte, codigoAduana, anioManifiesto, numeroManifiesto,buscarManifiestoSigadActual);

	  if(manifiesto != null) {
		  Date fechaLlegada = new Date();

		  if(manifiesto.getFechaEfectivaDeLlegada()!=null && !SunatDateUtils.isDefaultDate(manifiesto.getFechaEfectivaDeLlegada())){
				fechaLlegada = manifiesto.getFechaEfectivaDeLlegada();;
		  }else{
				fechaLlegada = manifiesto.getFechaProgramadaLlegada();
		  }

		  Date fechaDeclaracion = (Date)declaracion.get("FEC_DECLARACION");
		  ValNegocNumeracFormA valNegocNumeracFormA = this.fabricaDeServicios.getService("ValNegocNumeracFormA");
		  //List<Map<String, String>> listaError = valNegocNumeracFormA.validarPlazoDespachoUrgente(manifiesto.getFechaTerminoDeDescarga(), manifiesto.getFechaEfectivaDeLlegada(), fechaDeclaracion);
		  //List<Map<String, String>> listaError = valNegocNumeracFormA.validarPlazoDespachoUrgente(manifiesto.getFechaTerminoDeDescarga(), fechaLlegada, fechaDeclaracion);

		  List<Map<String, String>> listaError = valNegocNumeracFormA.validarPlazoDespachoUrgente(fechaDeclaracion, fechaLlegada, manifiesto.getFechaTerminoDeDescarga());
		  if(!listaError.isEmpty()){
			  Map<String, String> mapaError = listaError.get(0);
			  return mapaError.get(mapaError.keySet().toArray()[0]);
		  }
	  }
	  return mensaje;
  }*/



	/**FIN-RIN13**/
	//gg lga
	public boolean esNuevaReglaLgaVigente(Date fechaReferencia){
		DataCatalogo catPlazoValidacionNuevaLga = ((CatalogoAyudaService) fabricaDeServicios
				.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
						ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
						ConstantesDataCatalogo.COD_PLAZO_VALIDACION_NUEVA_LGA, fechaReferencia);
		if (catPlazoValidacionNuevaLga == null){
			return false;
		}
		return true;
	}

	/**
	 * Validar rectificaciones electronicas en estado pendientes.
	 *
	 * @param numCorredocDua
	 *          the num corredoc dua
	 * @return string Msg de validacion
	 */
  public String validarRectificacionesPendientes(String numCorredocDua)
	{

		StringBuilder sbRspta = new StringBuilder("");

		Map<String, Object> paramrecti = new HashMap<String, Object>();
		paramrecti.put("NUM_CORREDOC", numCorredocDua);
		paramrecti.put("COD_TIPSOL", "01");
		List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(paramrecti);
		for (Map<String, Object> map : listSolicitudesRecti)
		{
			String estaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
			if (ArrayUtils.contains(new String[]
					{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION, Constantes.COD_ASIG_PENDIENTE_EVALUAR }, estaRecti))
			{
				sbRspta.append("La declaraci�n tiene una Solicitud de Rectificaci�n Electr�nica en estado ");
				sbRspta.append(estaRecti);
				sbRspta.append(" (");
				//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
				//sbRspta.append(catalogoAyudaService.getDescripcionDataCatalogo("363", estaRecti));
				String descripcionEstadoRectificacion = MapUtils.getMapValor(map, "DES_ESTARECTI");
				sbRspta.append(descripcionEstadoRectificacion);
				// RTINEO FIN
				sbRspta.append(")");
			}
		}
		return sbRspta.toString();
	}

	/**
	 * Obteniendo fecha transmision.
	 *
	 * @param num_corredoc
	 *          the num_corredoc
	 * @return the object
	 */
	private Object obteniendoFechaTransmision(Object num_corredoc)
	{

		Map param = new HashMap();
		param.put("NUM_CORREDOC", num_corredoc);
		param.put("COD_TIPSOL", "11");
		Object obj = null;
		Object numDocSol = this.relacionDocDAO.findSolicitudByDocumento(param);
		if (!StringUtils.isEmpty((String) numDocSol))
		{
			param.put("NUM_CORREDOC", numDocSol);
			Map<String, Object> cabSolRecti = cabSolRectiDAO.findByDocumento(param);
			if (!CollectionUtils.isEmpty(cabSolRecti) && cabSolRecti.get("FEC_SOLICITUD") != null)
				obj = cabSolRecti.get("FEC_SOLICITUD");
		}

		return obj;

	}

	/**
	 * {@inheritDoc}
	 */
	public void updateDeclaracion(Map<String, Object> params)
			throws ServiceException
	{
		this.cabDeclaraDAO.update(params);
	}

	public void updateDeclaracionSinTXNewRequired(Map<String, Object> params)
			throws ServiceException
	{
		this.cabDeclaraDAO.update(params);
	}

	/**
	 * {@inheritDoc}
	 */
	public String obtenerTituloDiligencia(String codigoCanal)
			throws ServiceException
	{
		return obtenerTituloDiligencia(codigoCanal, "");
	}

	/**
	 * {@inheritDoc}
	 */
	public String obtenerTituloDiligencia(String codigoCanal, String invocador)
			throws ServiceException
	{
		String tituloDiligencia = "";
		if (SunatStringUtils.isEmpty(invocador))
		{
			if (Constantes.CANAL_ROJO.equalsIgnoreCase(codigoCanal))
			{
				tituloDiligencia =
						(String) catalogoAyudaService.getElementoCat(
								Constantes.CAT_TIPO_DILIGENCIA,
								Constantes.DILIG_REC_FISICO).get("des_corta");
			}
			else if (Constantes.CANAL_NARANJA.equalsIgnoreCase(codigoCanal))
			{
				tituloDiligencia =
						(String) catalogoAyudaService.getElementoCat(
								Constantes.CAT_TIPO_DILIGENCIA,
								Constantes.DILIG_REV_DOCUMENTARIA).get("des_corta");
			}
		}
		else if (Constantes.TIPO_DILIG_CONCLUSION_DESPACHO.equals(invocador))
		{ // Para los titulos de conclusion
			tituloDiligencia ="Conclusi�n de Despacho";
		}
		/**Inicio de cambios PAS20165E220200032**/
		else if (Constantes.TIPO_DILIG_POST_LEVANTE.equals(invocador))
		{ // Para los titulos de Post Levante			
			tituloDiligencia =
					(String) catalogoAyudaService.getElementoCat(
							Constantes.CAT_TIPO_DILIGENCIA,
							Constantes.DILIG_CONCLUSION_DESPACHO).get("des_corta");
		}
		/**Fin de cambios PAS20165E220200032**/
		else if (Constantes.TIPO_DILIG_RECTI_OFICIO.equals(invocador))
		{
			tituloDiligencia =
					(String) catalogoAyudaService.getElementoCat(
							Constantes.CAT_TIPO_DILIGENCIA,
							Constantes.DILIG_RECTI_MANUAL).get("des_corta");
		}
		else if (Constantes.TIPO_DILIG_REGULARIZACION.equals(invocador))
		{
			tituloDiligencia =
					(String) catalogoAyudaService.getElementoCat(
							Constantes.CAT_TIPO_DILIGENCIA,
							Constantes.DILIG_REGULARIZACION).get("des_corta");
		}
		else if (Constantes.TIPO_DILIG_CULMINACION_PECO_AMAZONIA.equals(invocador))//pase 69
		{
			tituloDiligencia =
					(String) catalogoAyudaService.getElementoCat(
							Constantes.CAT_TIPO_DILIGENCIA,
							Constantes.DILIG_CULMINACION_PECO_AMAZONIA).get("des_corta");
		}

		return tituloDiligencia;
	}


	public Map<String, Object> seleccionarFacturaSession(
			Map<String, String> params,
			List<Map<String, Object>> lstFacturasSerie)
					throws ServiceException
					{

		Map<String, Object> mapFacturasSerieSeleccionado = null;
		String num_secfact = params.get("num_secfact");
		String num_secserie = params.get("num_secserie");
		String index = params.get("index");
		for (Map<String, Object> mapFacturasSerie : lstFacturasSerie)
		{

			Object num_secfactMap = mapFacturasSerie.get("NUM_SECFACT");
			Object num_secserieMap = mapFacturasSerie.get("NUM_SECSERIE");
			Object INDEX = mapFacturasSerie.get("INDEX");

			if (StringUtils.isEmpty(num_secfact))
			{
				if (Utilidades.compararCadenaConObjeto(num_secfact, num_secfactMap) &&
						Utilidades.compararCadenaConObjeto(num_secserie, num_secserieMap) &&
						Utilidades.compararCadenaConObjeto(index, INDEX))
				{
					mapFacturasSerieSeleccionado = mapFacturasSerie;
					break;
				}
			}
			else
			{
				if (Utilidades.compararCadenaConObjeto(num_secfact, num_secfactMap) &&
						Utilidades.compararCadenaConObjeto(num_secserie, num_secserieMap))
				{
					mapFacturasSerieSeleccionado = mapFacturasSerie;
					break;
				}
			}
		}
		return mapFacturasSerieSeleccionado;
					}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> grabarFacturaSession(
			Map<String, String> params,
			List<Map<String, Object>> lstFacturasSerie,
			List<Map<String, Object>> lstFacturasSerieAnt)
					throws ServiceException
					{
		//RIN13
		String num_secfact = params.get("num_secfact");
		String num_secSerie = params.get("num_secserie");
		String index = params.get("index");

		for (Map<String, Object> mapFacturasSerie : lstFacturasSerie)
		{
			Object num_secfactMap = mapFacturasSerie.get("NUM_SECFACT");
			Object num_secSerieMap = mapFacturasSerie.get("NUM_SECSERIE");
			Object INDEX = mapFacturasSerie.get("INDEX");

			if (StringUtils.isEmpty(num_secfact))
			{
				if (Utilidades.compararCadenaConObjeto(num_secfact, num_secfactMap) &&
						Utilidades.compararCadenaConObjeto(num_secSerie, num_secSerieMap) &&
						Utilidades.compararCadenaConObjeto(index, INDEX))
				{
					mapFacturasSerie.put("NUM_FACT",
							Utilidades.crearObjetoDesdeCadena(params.get("num_fact"), mapFacturasSerie.get("NUM_FACT")));
					mapFacturasSerie.put("FEC_FACT", SunatDateUtils.getFormatDate(SunatDateUtils.getDate(params.get("fec_fact"), "yyyy-MM-dd"), "dd/MM/yyyy"));
					//          mapFacturasSerie.put("FEC_FACT",
					//              Utilidades.crearObjetoDesdeCadena(params.get("fec_fact"), mapFacturasSerie.get("FEC_FACT")));
					break;
				}
			}
			else
			{
				if (Utilidades.compararCadenaConObjeto(num_secfact, num_secfactMap) &&
						Utilidades.compararCadenaConObjeto(num_secSerie, num_secSerieMap))
				{
					mapFacturasSerie.put("NUM_FACT",
							Utilidades.crearObjetoDesdeCadena(params.get("num_fact"), mapFacturasSerie.get("NUM_FACT")));
					mapFacturasSerie.put("FEC_FACT", SunatDateUtils.getFormatDate(SunatDateUtils.getDate(params.get("fec_fact"), "yyyy-MM-dd"), "dd/MM/yyyy"));
					//          mapFacturasSerie.put("FEC_FACT",
					//              Utilidades.crearObjetoDesdeCadena(params.get("fec_fact"), mapFacturasSerie.get("FEC_FACT")));
					break;
				}
			}

		}

		return lstFacturasSerie;
					}

	/**
	 * {@inheritDoc}
	 */
	public void eliminarFacturaSession(Map<String, String> params,
			List<Map<String, Object>> lstFacturasSerie) throws ServiceException
	{

		Map<String, Object> mapFacturasSerieEliminar = null;
		for (Map<String, Object> mapFacturasSerie : lstFacturasSerie)
		{
			String num_secfact = params.get("num_secfact");
			Object num_secfactMap = mapFacturasSerie.get("NUM_SECFACT");

			String num_secSerie = params.get("num_secserie");
			Object num_secSerieMap = mapFacturasSerie.get("NUM_SECSERIE");

			if (Utilidades.compararCadenaConObjeto(num_secfact, num_secfactMap) &&
					Utilidades.compararCadenaConObjeto(num_secSerie, num_secSerieMap))
			{
				mapFacturasSerieEliminar = mapFacturasSerie;
				break;
			}
		}
		lstFacturasSerie.remove(mapFacturasSerieEliminar);

	}

	/**
	 * {@inheritDoc}
	 */
	public void adicionarFacturaSession(
			Map<String, String> params,
			List<Map<String, Object>> lstFacturasSerie,
			List<Map<String, Object>> lstFacturasSerieAnt)
					throws ServiceException
	{
		Map<String, Object> mapFacturasSerieAdicionar = new HashMap<String, Object>();
		String correlativoDUA = params.get("num_corredoc");
		String secuencialSerie = params.get("num_secserie");
		String secuencialFactura = params.get("num_secfact");
		String numeroFactura = params.get("num_fact");
		String fechaFactura = params.get("fec_fact");
		String index = params.get("index");
		if (StringUtils.isBlank(secuencialFactura))
		{ // los que no tiene numsecfact no se adiciona se modifica
			mapFacturasSerieAdicionar.put("NUM_CORREDOC", new BigDecimal(correlativoDUA));
			mapFacturasSerieAdicionar.put("NUM_SECSERIE", new BigDecimal(secuencialSerie));

			mapFacturasSerieAdicionar.put("NUM_SECFACT", "");
			mapFacturasSerieAdicionar.put("NUM_FACT", numeroFactura);

			mapFacturasSerieAdicionar.put("FEC_FACT", Utilidades.crearObjetoDesdeCadena(fechaFactura, new Timestamp(0)));
			mapFacturasSerieAdicionar.put("COD_MOMGRAB", "03");
			mapFacturasSerieAdicionar.put("INDEX", new Integer(index));
			lstFacturasSerie.add(mapFacturasSerieAdicionar);
		}

	}

	/**
  /**
	 * Metodo que nos permite obtener el Certificado de Origen de una Serie.
	 *
	 * @param PkSerie
	 *          the pk serie
	 * @return the list
	 * @throws ServiceException
	 *           the service exception
	 */
	public List<Map<String, Object>> obtenerCertOrigen(Map<String, String> PkSerie) throws ServiceException
	{
		List<Map<String, Object>> listCertificadoOrigen = null;
		try
		{
			listCertificadoOrigen = cabCertiOrigenDAO.joinDetAutorizacionFindBySerie(PkSerie);
		}
		catch (Exception e)
		{
			throw new ServiceException(e, e.getMessage());
		}
		return listCertificadoOrigen;
	}

	/**
	 * Metodo que nos permite obtener los Certificado de Origen de una DUA y
	 * asociarlos a las series que los tengan referenciados.
	 *
	 * @param PkSerie
	 *          the pk serie
	 * @param listaDetAutorizacion
	 *          the lista det autorizacion
	 * @return the list
	 * @throws ServiceException
	 *           the service exception
	 */
	public List<Map<String, Object>> obtenerCertOrigen(
			Map<String, String> PkSerie,
			List<Map<String, Object>> listaDetAutorizacion)
					throws ServiceException
					{

		List<Map<String, Object>> listCertificadoOrigen = null;
		try
		{
			listCertificadoOrigen = cabCertiOrigenDAO.joinDetAutorizacionFindBySerie(PkSerie);
			listCertificadoOrigen = this.getSeries(listCertificadoOrigen, listaDetAutorizacion);
		}
		catch (Exception e)
		{
			throw new ServiceException(e, e.getMessage());
		}
		return listCertificadoOrigen;
					}


	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> obtenerDocAutAsociados(Map<String, String> pkDoc)
			throws ServiceException
			{
		List<Map<String, Object>> lstDocAutAsociado = null;
		try
		{
			lstDocAutAsociado = docAutAsociadoDAO.select(pkDoc);
		}
		catch (Exception e)
		{
			throw new ServiceException(e, e.getMessage());
		}
		return lstDocAutAsociado;
			}

	/**
	 * {@inheritDoc}
	 */
	public Integer obtenerMaxCorrelativoDocAutAsociado(Map<String, String> pkDoc) throws ServiceException
	{
		Integer correlativoDoc = 0;
		try
		{
			correlativoDoc = docAutAsociadoDAO.selectMaxCorrelativoDocAutAsociado(pkDoc);
		}
		catch (Exception e)
		{
			throw new ServiceException(e, e.getMessage());
		}
		return correlativoDoc;
	}

	/**
	 * Metodo que permite asociar los certificados a las series que los
	 * referencian, las series se encuentran en listaDetAutorizacion.
	 *
	 * @param listaCertificados
	 *          the lista certificados
	 * @param listaDetAutorizacion
	 *          the lista det autorizacion
	 * @return the series
	 */
	private List<Map<String, Object>> getSeries(
			List<Map<String, Object>> listaCertificados,
			List<Map<String, Object>> listaDetAutorizacion)
			{
		boolean banderaExiste = false;
		StringBuilder cadenaSeries = new StringBuilder("");
		Map<String, Object> mapClavePrimaria = new HashMap<String, Object>();
		mapClavePrimaria.put("NUM_CORREDOC", "");
		mapClavePrimaria.put("NUM_SECDOC", "");
		mapClavePrimaria.put("COD_TIPOPER", "");

		for (int i = 0; i < listaCertificados.size(); i++)
		{
			Map<String, Object> mapCertificado = listaCertificados.get(i);
			cadenaSeries = new StringBuilder("");
			for (Entry<String, Object> entrada : mapClavePrimaria.entrySet())
			{
				// Se recoge los valores del PK.
				mapClavePrimaria.put(entrada.getKey(),
						mapCertificado.get(entrada.getKey()));
			}

			for (Map<String, Object> mapDetAutoriza : listaDetAutorizacion)
			{
				for (Entry<String, Object> entrada : mapClavePrimaria
						.entrySet())
				{
					if (mapCertificado.get(entrada.getKey()).toString().trim()
							.equals(mapDetAutoriza.get(entrada.getKey()).toString().trim()))
					{
						banderaExiste = true;
					}
					else
					{
						banderaExiste = false;
						break;
					}
				}
				if (banderaExiste)
				{
					if (cadenaSeries.length() == 0)
					{
						cadenaSeries.append(mapDetAutoriza.get("NUM_SECSERIE").toString().trim());
					}
					else if (cadenaSeries.length() > 0)
					{
						cadenaSeries.append(
								mapDetAutoriza.get("NUM_SECSERIE").toString()
								.trim()).append(" ,");
					}
				}
			}
			listaCertificados.get(i).put("SERIES", cadenaSeries.toString().trim());
		}
		return listaCertificados;
			}


	public List<Map<String, Object>> obtenerPrecintos(Map<String, String> PkDocu) throws ServiceException
	{
		List<Map<String, Object>> listaResultado = new ArrayList<Map<String, Object>>();
		try
		{
			listaResultado = equipamientoDAO.joinPrecintoFindByDocumento(PkDocu);
		} catch (Exception e)
		{
			log.error(this.toString() + " obtenerPrecinto- ERROR: " + e.getMessage());
			throw new ServiceException(this, e);
		}
		return listaResultado;

	}
	//inicio gmontoya P24
	/**
	 * {@inheritDoc}
	 */

	public List<Map<String, Object>> obtenerContenedoresEvaluacionSINI(Map<String, Object> declaracionDua,Map<String, String> PkDocu) throws ServiceException
	{
		List<Map<String, Object>> lista = null;
		List<Map<String, Object>> listaResultado = new ArrayList<Map<String, Object>>();
		try
		{
			lista = equipamientoDAO.joinPrecintoFindByDocumento(PkDocu);
			Collections.sort(lista, new Comparator<Map>()
					{
				@Override
				public int compare(Map first, Map second)
				{
					return first.get("NUM_EQUIPAMIENTO").toString().compareTo(second.get("NUM_EQUIPAMIENTO").toString());
				}
					});

			if(!CollectionUtils.isEmpty(lista)){
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("cod_regimen", declaracionDua.get("COD_REGIMEN").toString());
				parametros.put("codigoAduana", declaracionDua.get("COD_ADUAMANIFIESTO").toString());
				parametros.put("anioDocumento", declaracionDua.get("ANN_PRESEN").toString());
				parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(),6, " "));
				parametros.put("codigoViaTransporte", declaracionDua.get("COD_VIATRANS").toString());
				parametros.put("numdua", StringUtils.leftPad(declaracionDua.get("NUM_DECLARACION").toString(),6,"0"));

				SiniConsultaService siniConsultaService =fabricaDeServicios.getService("sigad.sini.SiniConsultaService");
				List<Map<String,Object>> listSini= siniConsultaService.evaluarContenedorSINIxDAM(parametros);

				int contadorPrecintos = -1;
				String contenedorAnterior = "";
				boolean contEncontrado= false;
				for(Map<String, Object> contenedor : lista){
					if(contenedorAnterior.equals(contenedor.get("NUM_EQUIPAMIENTO"))){
						listaResultado.get(contadorPrecintos).put("cadena", (listaResultado.get(contadorPrecintos).get("NUM_PRECINTO")!=null?listaResultado.get(contadorPrecintos).get("NUM_PRECINTO").toString():"").concat(" ").concat(contenedor.get("NUM_PRECINTO")!=null?contenedor.get("NUM_PRECINTO").toString():""));
					}else{
						contenedor.put("scanner", " ");
						contenedor.put("archivo", " ");
						contEncontrado = false;
						if (!CollectionUtils.isEmpty(listSini)) {
							if (listSini.size() > 0) {
								for (Map<String, Object> mapConSini : listSini) {
									if (SunatStringUtils.isEqualTo((String) contenedor.get("NUM_EQUIPAMIENTO"),(String) mapConSini.get("DES_CONTENEDOR"))) {
										contenedor.put("scanner",(String) mapConSini.get("COD_ESTADO") + " - " + (String) mapConSini.get("DES_ESTADO"));
										contenedor.put("archivo",mapConSini.get("DES_XMLRECEP")!=null?(String) mapConSini.get("DES_XMLRECEP"):"");
										contEncontrado = true;
										continue;
									}
								}

							}
						}
						if (!contEncontrado) {
							parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(), 5, " "));
							parametros.put("contenedor", (String) contenedor.get("NUM_EQUIPAMIENTO"));
							List<Map<String, Object>> listSiniManif = siniConsultaService.evaluarContenedorSINISinDestinar(parametros);
							if (!CollectionUtils.isEmpty(listSiniManif)) {
								if (listSiniManif.size() > 0) {
									for (Map<String, Object> mapConSiniManif : listSiniManif) {
										if (SunatStringUtils.isEqualTo((String) contenedor.get("NUM_EQUIPAMIENTO"),(String) mapConSiniManif.get("DES_CONTENEDOR"))) {
											contenedor.put("scanner",(String) mapConSiniManif.get("COD_ESTADO") + " - " + (String) mapConSiniManif.get("DES_ESTADO"));
											contenedor.put("archivo",mapConSiniManif.get("DES_XMLRECEP")!=null?(String) mapConSiniManif.get("DES_XMLRECEP"):"");
											continue;
										}
									}
								}
							}
						}
						listaResultado.add(contenedor);
						contadorPrecintos++;
						contenedorAnterior = contenedor.get("NUM_EQUIPAMIENTO").toString();
						listaResultado.get(contadorPrecintos).put("cadena",listaResultado.get(contadorPrecintos).get("NUM_PRECINTO")!=null?listaResultado.get(contadorPrecintos).get("NUM_PRECINTO").toString():"");
					}
				}		      
			}  
		}catch (Exception e)
		{
			log.error(this.toString() + " obtenerContenedores- ERROR: " + e.getMessage());
			throw new ServiceException(this, e);
		}

		return listaResultado;
	}


	//fin gmontoya P24

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> obtenerContenedores(Map<String, String> PkDocu) throws ServiceException
	{
		List<Map<String, Object>> lista = null;
		List<Map<String, Object>> listaResultado = new ArrayList<Map<String, Object>>();
		boolean isNuevoPrecinto = true;
		try
		{
			lista = equipamientoDAO.joinPrecintoFindByDocumento(PkDocu);
			Collections.sort(lista, new Comparator<Map>()
					{
				@Override
				public int compare(Map first, Map second)
				{
					return first.get("NUM_EQUIPAMIENTO").toString().compareTo(second.get("NUM_EQUIPAMIENTO").toString());
				}
					});
			int contadorPrecintos = 0;
			String lisprecintos=""; 
			for (int i = 0; i < lista.size(); i++)
			{
				if (i == 0)
				{
					listaResultado.add(lista.get(i));
					if(lista.get(i).get("NUM_PRECINTO")!=null)//mol pase18
					{lisprecintos=lisprecintos+lista.get(i).get("NUM_PRECINTO").toString();
					}
					/*listaResultado.get(contadorPrecintos).put(
              "cadena",
                listaResultado.get(contadorPrecintos).get("NUM_PRECINTO") != null ? listaResultado
                    .get(contadorPrecintos)
                    .get("NUM_PRECINTO")
                        .toString() : "");*/
					listaResultado.get(contadorPrecintos).put(
							"cadena",lisprecintos);
				}
				else
				{
					String precintoActual = lista.get(i).get("NUM_EQUIPAMIENTO").toString();
					String precintoAnterior = lista.get(i - 1).get("NUM_EQUIPAMIENTO").toString();

					if (precintoActual.equals(precintoAnterior))
					{
						if(lista.get(i).get("NUM_PRECINTO")!=null){ //mol pase18
							lisprecintos=lisprecintos+" "+lista.get(i).get("NUM_PRECINTO").toString();  
						}
						/*listaResultado.get(contadorPrecintos).put(
                "cadena",
                  listaResultado
                      .get(contadorPrecintos)
                      .get("cadena")
                      .toString()
                      .concat(lista.get(i).get("NUM_PRECINTO") != null ?
                               ", " + listaResultado.get(contadorPrecintos).get("NUM_PRECINTO").toString() : ""));*/
						listaResultado.get(contadorPrecintos).put(
								"cadena",lisprecintos);
						continue;
					}
					contadorPrecintos++;
					if (isNuevoPrecinto)
					{
						lisprecintos="";  
						if(lista.get(i).get("NUM_PRECINTO")!=null){//mol pase 18
							lisprecintos=lisprecintos+" "+lista.get(i).get("NUM_PRECINTO").toString(); 
						}
						listaResultado.add(lista.get(i));
						/* listaResultado.get(contadorPrecintos).put(
                "cadena",
                  listaResultado.get(contadorPrecintos).get("NUM_PRECINTO") != null ? listaResultado
                      .get(contadorPrecintos)
                      .get("NUM_PRECINTO")
                          .toString() : "");*/
						listaResultado.get(contadorPrecintos).put(
								"cadena",lisprecintos);
					}
				}
			}
		}
		catch (Exception e)
		{
			log.error(this.toString() + " obtenerContenedores- ERROR: " + e.getMessage());
			throw new ServiceException(this, e);
		}
		return listaResultado;
	}

	//inicio gmontoya P24

	public List obtenerDocumentosTransporteDUA(Map PkDocu){	  
		return documentoDeTransporteService.obtenerDocTransDUA(PkDocu);	  
	}
	//fin gmontoya P24
	//inicio gmontoya P24

		public List obtenerReceptorCargaDUA(Map PkDocu){
			List lista = documentoDeTransporteService.obtenerReceptorCargaDUA(PkDocu);
			return lista;
		}
		//fin gmontoya P24

	/**
	 * {@inheritDoc}
	 */
	public List obtenerDatado(Map PkDocu) throws ServiceException
	{
		List<Map<String, Object>> lista = null;

		try
		{
			lista = manifiestoDAO.findByDocumentoDeclaracion(PkDocu);
			log.info(lista.size());
			for (int i = 0; i < lista.size(); i++)
			{
				Puerto puerto = catalogoAyudaService.getPuertoObject(lista
						.get(i).get("cod_puerto_embarca").toString());
				lista.get(i).put("des_puerto", puerto.getDpuerto());
			}
		}
		catch (DataAccessException e)
		{
			log.error(this.toString().concat(" obtenerDatado- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}
		catch (Exception e)
		{
			log.error(this.toString().concat(" obtenerDatado- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}
		return lista;
	}

	/**
	 * Obtiene la informacion del datado, considerando los datos tanto del ASIGAD como del NSIGAD, dependiendo de donde se numero el manifiesto
	 */
	public List obtenerDatado(Map<String, Object> PkDocu, Manifiesto manifiesto) throws ServiceException {
		List<Map<String, Object>> lista = new ArrayList<Map<String,Object>>();
		List<Mcdeta> listMcdeta = new ArrayList<Mcdeta>();
		try {
			/**
			 * 1. obtener los bls de la dua
			 * 2. Por cada bl obtener la informacion del docutrans o mcdeta de corresponder instanceof manifiesto
			 * 3. Luego por cada bl obtener su datado
			 * 4. setear a los campos que debe leer
			 */
			String codigoViaTransporte = manifiesto.getViaTransporte().getCodDatacat();
			Integer anioManifiesto = manifiesto.getAnioManifiesto();
			String numeroManifiesto = manifiesto.getNumeroManifiesto();
			String codigoAduana = manifiesto.getAduana().getCodDatacat();

			List<Map<String, Object>> listDetDeclara = serieService.findByNumCorreDoc(PkDocu);
			for (int i = 0; i < listDetDeclara.size(); i++) {
				Map<String, Object> listaDetalle = listDetDeclara.get(i);
				if(manifiesto instanceof  Mcdage ) {
					Map<String, Object> list = new HashMap<String, Object>();
					list.put("cod_num_corredoc", PkDocu.get("NUM_CORREDOC").toString());
					list.put("des_fecha_descarga", manifiesto.getFechaTerminoDeDescarga());

					String numeroDocumentoTransporte = listaDetalle.get("NUM_DOCTRANSP").toString();
					String puertoEmbarque            = listaDetalle.get("COD_PUER_EMBAR").toString();
					list.put("cod_num_doc_transp", numeroDocumentoTransporte);
					list.put("cod_puerto_embarca", puertoEmbarque);

					listMcdeta =  manifiestoSigadService.getListMcdetaByClaveDeNegocio(codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, numeroDocumentoTransporte, puertoEmbarque);
					if(!CollectionUtils.isEmpty(listMcdeta)){
						DocumentoDeTransporte documentoDeTransporte=null;
						documentoDeTransporte = listMcdeta.get(0).getDocumentoDeTransporte();
						documentoDeTransporte.setManifiesto(manifiesto);
						list.put("des_peso", documentoDeTransporte.getPesoManifestado());
						list.put("des_bulto", documentoDeTransporte.getCantidadBultoManifestado());
						list.put("des_peso_recibo", documentoDeTransporte.getPesoRecibido());
						list.put("des_bulto_recibo", documentoDeTransporte.getBultosRecibidos());
						Datado datado= datadoValidacionService.obtenerPesoYBultoTotalDatado(documentoDeTransporte);
						if (datado != null){
							list.put("des_peso_descargado", datado.getTotalPesoBruto());
							list.put("des_bulto_descargado", datado.getTotalBulto());
						}
						lista.add(list);
					}
				}else{
					lista = obtenerDatado(PkDocu);
				}
			}
		} catch (Exception e) {
			log.error(this.toString().concat(" obtenerDatado- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}
		return lista;
	}

	//inicio gmontoya P24

	public List<Map<String,Object>> obtenerDatadoDUA(Map<String,Object> pk){
		return datadoValidacionService.obtenerDatadoDUA(pk);
	}
	//fin gmontoya P24
	public List<Map<String,Object>> obtenerDatadoDUASIGAD(Map<String,Object> pk){
		return datadoValidacionService.obtenerDatadoDUASIGAD(pk);
	}
	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> obtenerRiesgos(Map<String, String> pkDocu) throws ServiceException
	{
		List<Map<String, Object>> listaEventos = null;

		List<Map<String, Object>> listaCanalesEvento = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> listaHerramienta;

		List<Map<String, Object>> listaHerraFraudSeries = new ArrayList<Map<String, Object>>();
		Map<String, Object> mapaResultado = new HashMap<String, Object>();

		ControlVigenciaService controlVigencia = fabricaDeServicios.getService("despaduanero2.declaracion.controlVigenciaService");
		boolean esReglaApiRiesgoVigente = controlVigencia.esReglaVigente(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_VIGENCIA_INVOCACION_API_RIESGO, SunatDateUtils.getCurrentDate());

		try
		{

			if(esReglaApiRiesgoVigente) {
				listaEventos = obtenerListaEventos(pkDocu, true);
				listaHerramienta = obtenerMotivoHerramienta(listaEventos, true);
				// obtenemos el canal para cada evento
				listaCanalesEvento = obtenerCanal(listaEventos, pkDocu, true);
				// obtenemos las series para cada Item de la Herramienta
				listaHerraFraudSeries = obtenerSeries(listaHerramienta, true);


			}else {
				// obtenemos la lista de Eventos
				listaEventos = cabTipoAforoDeclaraDAO.joinTipoEventoAforoDeclara(pkDocu);
				// Iterator de Tipo de Herramienta
				listaHerramienta = obtenerMotivoHerramienta(listaEventos);
				// obtenemos el canal para cada evento
				listaCanalesEvento = obtenerCanal(listaEventos, pkDocu);
				// obtenemos las series para cada Item de la Herramienta
				listaHerraFraudSeries = obtenerSeries(listaHerramienta);
			}

			mapaResultado.put("listaCanalesEvento", listaCanalesEvento);
			mapaResultado.put("listaHerraFraudSeries", listaHerraFraudSeries);
			mapaResultado.put("listaEventos", listaEventos);

		}
		catch (Exception e)
		{
			e.printStackTrace();
			log.error(this.toString() + " Nuevo obtenerRiesgos- ERROR: " + e.getMessage());
			throw new ServiceException(e, e.getMessage());
		}

		return mapaResultado;
	}

	private List<Map<String, Object>> obtenerMotivoHerramienta(List<Map<String, Object>> listaEventos)
	{
		return obtenerMotivoHerramienta(listaEventos, false);
	}
	/**
	 * Metodo para obtener las lista de Herramienta para cada secuencia. autor:
	 * Rolando Sachun
	 * pase13
	 * @param listaEventos
	 *          the lista eventos
	 * @return List
	 */
	private List<Map<String, Object>> obtenerMotivoHerramienta(List<Map<String, Object>> listaEventos,boolean usarRest)
	{
		List<Map<String, Object>> listaTipoMovHerramienta01 = null;
		List<Map<String, Object>> listaTipoMovHerramienta02 = new ArrayList<Map<String, Object>>();

		RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		String consultarHerramientasPath = "/e/joinTipoMotivoHerramienta?NUM_DECLARACION=%s&COD_ADUANA=%s&COD_REGIMEN=%s&ANN_DECLARA=%s&NUM_SECMOM=%s";

		for (Map<String, Object> mapa : listaEventos)
		{
			Map<String, Object> mapita = new HashMap<String, Object>();
			String COD_TIPAFORO = mapa.get("COD_TIPAFORO").toString();
			if (COD_TIPAFORO.equals("D") || COD_TIPAFORO.equals("F"))
			{
				if(usarRest) {
					String consultarHerramientasUri = BASE_API_RIESGO_PATH + String.format(consultarHerramientasPath, mapa.get("NUM_DECLARACION"), mapa.get("COD_ADUANA"),
							mapa.get("COD_REGIMEN"),mapa.get("ANN_DECLARA"), mapa.get("NUM_SECMOM"));

					DocumentoCanal documentoCanal =  restTemplate.getForObject(consultarHerramientasUri, DocumentoCanal.class);
					List<Object> listEventos = documentoCanal.getValor();
					listaTipoMovHerramienta01 = convertirListaObjetosAListaMaps (listEventos);

				}else {
					Map<String, String> mapMotivoHerramienta = new HashMap();
					for (Map.Entry<String, Object> entry : mapa.entrySet()) {
						mapMotivoHerramienta.put(entry.getKey(), entry.getValue().toString());
					}
					//listaTipoMovHerramienta01 = cabTipoAforoDeclaraDAO.joinTipoMotivoHerramienta(mapa);
					listaTipoMovHerramienta01 = cabTipoAforoDeclaraDAO.joinTipoMotivoHerramienta(mapMotivoHerramienta);
				}

				mapita.put("listaTipoMovHerramienta", listaTipoMovHerramienta01);
				listaTipoMovHerramienta02.add(mapita);

			}
		}
		return listaTipoMovHerramienta02;
	}


	private List<Map<String, Object>> obtenerCanal(List<Map<String, Object>> listaEventos, Map<String, String> pkDocu){
		return obtenerCanal(listaEventos, pkDocu, false);
	}


	/**
	 * Metodo para obtener lista de Canales para cada codigo de Momento. autor:
	 * Rolando Sachun
	 *
	 * @param listaEventos
	 *          the lista eventos
	 * @param pkDocu
	 *          the pk docu
	 * @return List
	 */
	private List<Map<String, Object>> obtenerCanal(List<Map<String, Object>> listaEventos, Map<String, String> pkDocu, boolean usarRest)
	{
		List<Map<String, Object>> listaCanalMotivo = new ArrayList<Map<String, Object>>();
		Map<String, Object> MapSeries = new HashMap<String, Object>(0);
		String COD_TIPAFORO;
		String COD_MOTAFORO;
		String NUM_SECMOM;
		String COD_CANAL = pkDocu.get("COD_CANAL").toString();
		String COD_MOTIVOCANALASIG = pkDocu.get("COD_MOTIVOCANALASIG").toString();
		String COD_ADUANA = pkDocu.get("COD_ADUANA").toString();
		String ANN_DECLARA = pkDocu.get("ANN_DECLARA").toString();
		String COD_REGIMEN = pkDocu.get("COD_REGIMEN").toString();
		String NUM_DECLARACION = pkDocu.get("NUM_DECLARACION").toString();
		Integer mxNumSecuencia;

		RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		String consultarSecuenciaPath = "/e/maxNumSecuencia?NUM_DECLARACION=%s&COD_ADUANA=%s&COD_REGIMEN=%s&ANN_DECLARA=%s";

		for (int i = 0; i < listaEventos.size(); i++)
		{
			Map<String, Object> mapa = listaEventos.get(i);
			COD_TIPAFORO = mapa.get("COD_TIPAFORO").toString();
			COD_MOTAFORO = mapa.get("COD_MOTAFORO").toString();
			NUM_SECMOM = mapa.get("NUM_SECMOM").toString();
			/* PAS20145E220000399 INICIO GGRANADOS */
			Date FECHA_REGISTRO = mapa.get("FEC_REGIS") != null ? SunatDateUtils.getDateFromUnknownFormat(mapa.get(
					"FEC_REGIS").toString()) : SunatDateUtils.getDate("01/01/1900", "dd/MM/yyyy");
			/* PAS20145E220000399 FIN GGRANADOS */
			Integer numSecmon = Integer.parseInt(NUM_SECMOM);
			MapSeries.put("COD_CANAL", COD_CANAL);
			MapSeries.put("COD_ADUANA", COD_ADUANA);
			MapSeries.put("ANN_DECLARA", ANN_DECLARA);
			MapSeries.put("COD_REGIMEN", COD_REGIMEN);
			MapSeries.put("NUM_DECLARACION", NUM_DECLARACION);
			Map<String, Object> mapita = new HashMap<String, Object>();
			if (mapa.get("IND_DUA").toString().trim().equals("1"))
			{
				mapita.put("COD_MOTAFORO", mapa.get("COD_MOTAFORO"));
				mapita.put("COD_TIPAFORO", mapa.get("COD_TIPAFORO"));
				mapita.put("COD_REGIMEN", mapa.get("COD_REGIMEN"));
				mapita.put("COD_MOMENTO", mapa.get("COD_MOMENTO"));
				mapita.put("COD_MOMENTOS", mapa.get("COD_MOMENTOS"));
				mapita.put("NUM_SECMOM", mapa.get("NUM_SECMOM"));
				mapita.put("IND_DUA", mapa.get("IND_DUA"));
				mapita.put("FEC_REGIS", SunatDateUtils.getIntegerFromDate(FECHA_REGISTRO));
				String motivo = canalesDAO.selectDescMotivo(mapita);

				if(usarRest) {

					String consultarSecuenciaUri = BASE_API_RIESGO_PATH + String.format(consultarSecuenciaPath, mapa.get("NUM_DECLARACION"), mapa.get("COD_ADUANA"),
									mapa.get("COD_REGIMEN"),mapa.get("ANN_DECLARA"));

					DocumentoRiesgo documentoRiesgo =  restTemplate.getForObject(consultarSecuenciaUri, DocumentoRiesgo.class);
					mxNumSecuencia =Integer.parseInt(documentoRiesgo.getValor()!=null? documentoRiesgo.getValor().toString():"0");

				}else {
					mxNumSecuencia = cabTipoAforoDeclaraDAO.maxNumSecuencia(MapSeries);
				}

				if (!COD_TIPAFORO.equals(COD_CANAL) || !COD_MOTAFORO.equals(COD_MOTIVOCANALASIG))
				{
					if (mxNumSecuencia.equals(numSecmon))
					{
						mapita
						.put(
								"COD_MOTVCANAL_DESC",
								"Canal-Motivo de la DUA es ["
										+ COD_CANAL
										+ " - "
										+ COD_MOTIVOCANALASIG
										+
								"] no coincide con Canal-Motivo registrado en las Tablas de Motivos del  Sistema de Selecci�n � Comunicar a IFGRA");
					}
					else
					{
						mapita.put("COD_MOTVCANAL_DESC", " ");
					}
				}
				else
				{
					mapita.put("COD_MOTVCANAL_DESC", " ");
				}
				mapita.put("COD_MOTAFORO_DESC", motivo.equals("") ? "No registrado" : motivo);
				listaCanalMotivo.add(mapita);
			}
		}
		return listaCanalMotivo;
	}


	private List<Map<String, Object>> obtenerSeries(List<Map<String, Object>> listaHerramienta){
		return obtenerSeries(listaHerramienta, false);
	}

	/**
	 * Metodo para obtener las lista de Serie para cada Tipo de Codigo de
	 * Herramienta. autor: Rolando Sachun
	 *
	 * @param listaHerramienta
	 *          the lista herramienta
	 * @return List
	 */
	private List<Map<String, Object>> obtenerSeries(List<Map<String, Object>> listaHerramienta, boolean usaRest)
	{
		List<Map<String, Object>> listaSeriesTipoAforo = null;

		List<Map<String, Object>> listaSeriesArrays = new ArrayList<Map<String, Object>>();
		String NUM_SECTIPAFORO;

		RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		String consultarSeriesTipoAforoPath = "/e/valorSeriesTipoAforo?NUM_SECTIPAFORO=%s";
		String consultarMaxSeriesPath = "/e/getMaxSeries?NUM_SECTIPAFORO=%s";
		String consultaTipoFraude = "/e/tipoFraudes?COD_FRAUDE=%s&FEC_REGIS=%s";

		for (Map<String, Object> mapa : listaHerramienta)
		{

			// Obtenemos la lista de Herramienta
			List valorTipoMovHerramienta = (List) mapa.get("listaTipoMovHerramienta");
			Iterator valorTipoMovHerra = valorTipoMovHerramienta.iterator();
			while (valorTipoMovHerra.hasNext())
			{
				Map seriesMap = (HashMap<String, Object>) valorTipoMovHerra.next();
				Map<String, Object> MapSeries = new HashMap<String, Object>(0);

				Integer rowSeries = 0;
				/* PAS20145E220000399 INICIO GGRANADOS */
				String descFraude = "";

				String COD_TIPHERRA = seriesMap.get("COD_TIPHERRA")!=null?seriesMap.get("COD_TIPHERRA").toString():"";
				NUM_SECTIPAFORO = seriesMap.get("NUM_SECTIPAFORO")!=null?seriesMap.get("NUM_SECTIPAFORO").toString():"0";

				if(usaRest) {
					String fechaUsar =  (new SimpleDateFormat("dd-MM-yyyy")).format(seriesMap.get("FEC_REGIS"));
					String consultarFraude = BASE_API_RIESGO_PATH + String.format(consultaTipoFraude, seriesMap.get("NFRAUDE"), fechaUsar);
					if(seriesMap.get("NFRAUDE")!=null && !seriesMap.get("NFRAUDE").equals("-")) {
						DocumentoRiesgo documentoRiesgo =  restTemplate.getForObject(consultarFraude, DocumentoRiesgo.class);
						descFraude = documentoRiesgo.getValor()!=null?documentoRiesgo.getValor().toString():"------";
					}else {
						descFraude = "------";
					}

				}else {
					Date FECHA_REGISTRO = seriesMap.get("FEC_REGIS") != null ?
						SunatDateUtils.getDateFromUnknownFormat(seriesMap.get("FEC_REGIS").toString()) : 
							SunatDateUtils.getDate("01/01/1900", "dd/MM/yyyy");
						/* PAS20145E220000399 FIN GGRANADOS */
					String COD_FRAUDE = MapUtils.getMapValor(seriesMap, "NFRAUDE");
					MapSeries.put("NUM_SECTIPAFORO", NUM_SECTIPAFORO);
					MapSeries.put("COD_MOMENTO", COD_FRAUDE);
					MapSeries.put("FEC_REGIS", SunatDateUtils.getIntegerFromDate(FECHA_REGISTRO));
					// Obtenemos los Fraudes por cada motivo de la Herramienta

					if (!COD_FRAUDE.equals("") && COD_FRAUDE.length() == 4)
					{
						descFraude = fraudesDAO.tipoFraudes(MapSeries);
						if (descFraude.equals("") || descFraude == null)
						{
							descFraude = " ------ ";
						}
					}
					else
					{
						descFraude = " ------ ";
					}
				}
						seriesMap.put("NFRAUDE", descFraude);
						// obtenemos la lista de la Series por cada herramienta solo las 5 mas
						// riesgosas//

						if(usaRest) {
							String consultarSeriesTipoAforo = BASE_API_RIESGO_PATH + String.format(consultarSeriesTipoAforoPath, NUM_SECTIPAFORO);
							try {
								DocumentoCanal documentoSeries = restTemplate.getForObject(consultarSeriesTipoAforo, DocumentoCanal.class);
								List<Object> listSeriesAforo = documentoSeries.getValor();
								listaSeriesTipoAforo = convertirListaObjetosAListaMaps(listSeriesAforo);
							}catch (Exception e){

							}

							try {
								String consultarMaxSeries = BASE_API_RIESGO_PATH + String.format(consultarMaxSeriesPath, NUM_SECTIPAFORO);
								DocumentoRiesgo documentoRiesgo=  restTemplate.getForObject(consultarMaxSeries, DocumentoRiesgo.class);
								rowSeries = Integer.parseInt(documentoRiesgo.getValor()!=null?documentoRiesgo.getValor().toString():"0");
							}catch (Exception e){

							}

						}else {
							listaSeriesTipoAforo = cabTipoAforoDeclaraDAO.valorSeriesTipoAforo(MapSeries);

							// obtenemos la cantidad de series por cada herramienta
							rowSeries = cabTipoAforoDeclaraDAO.getMaxSeries(MapSeries);
						}

						if (rowSeries == 0)
						{
							String NUM_SECSERIE = "0";
							seriesMap.put("NUM_SECSERIE", NUM_SECSERIE);
							listaSeriesArrays.add(seriesMap);
						}
						else
						{
							String NUM_SECSERIE = " ";
							String NUM_SECSERIE2 = "";
							int i = 0;
							for (Map<String, Object> ArraysJsonFila : listaSeriesTipoAforo)
							{
								i++;
								NUM_SECSERIE2 = ArraysJsonFila.get("NUM_SECSERIE").toString();
								NUM_SECSERIE += NUM_SECSERIE2 + "  ";
								if ((COD_TIPHERRA.equals("04") || COD_TIPHERRA.equals("02")) && i == 5)
								{
									break;
								}
							}
							seriesMap.put("NUM_SECSERIE", NUM_SECSERIE);
							listaSeriesArrays.add(seriesMap);
						}
			}
		}
		return listaSeriesArrays;
	}

	/**
	 * Metodo que nos permite obtener los datos de los vehiculos (Numero de Placa)
	 * y los datos de las empresas de transporte.
	 *
	 * @param PkDocu
	 *          the pk docu
	 * @return the list
	 * @throws ServiceException
	 *           the service exception
	 */
	public List obtenerVehiculos(Map PkDocu) throws ServiceException
	{
		List lista = null;
		try
		{
			lista = medioTransDAO.findByDocumento(PkDocu);
		}
		catch (DataAccessException e)
		{
			log.error(this.toString().concat(" obtenerVehiculos- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}
		catch (Exception e)
		{
			log.error(this.toString().concat(" obtenerVehiculos- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, e.getMessage());
		}

		return lista;
	}

	//inicio gmontoya P24

	public List obtenerPlazosProcesoConclusion(Map PkDecla) throws ServiceException
	{
		List lista = null;
		try
		{
			lista = plazosProcesoDAO.findPlazosYProrrogasConclusion(PkDecla);
		}
		catch (Exception e)
		{
			log.error(this.toString().concat(" obtenerPlazosProceso- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, "Ocurrio un error de base de datos");
		}

		return lista;
	}  
	//fin gmontoya P24

	/**
	 * {@inheritDoc}
	 */
	public List obtenerPlazosProceso(Map PkDecla) throws ServiceException
	{
		List lista = null;
		try
		{
			lista = plazosProcesoDAO.findByDUA(PkDecla);
			/** Inicio mpoblete RIN10 BUG 21179 **/
			lista = mostrarFechaFinalDefinitivaProrrogaValorProvisional(lista,PkDecla);
			/** Fin mpoblete RIN10 BUG 21179 **/      
		}
		catch (Exception e)
		{
			log.error(this.toString().concat(" obtenerPlazosProceso- ERROR: ")
					.concat(e.getMessage()));
			throw new ServiceException(e, "Ocurrio un error de base de datos");
		}

		return lista;
	}

	/** Inicio mpoblete RIN10 BUG 21179 **/
	private List mostrarFechaFinalDefinitivaProrrogaValorProvisional(List listaPlazoProceso,Map PkDecla){
		List lista = listaPlazoProceso;
		if(PkDecla.containsKey("FLAG_MOSTRAR_FECHA_FINAL_DEF_PRORROGA")){
			if(!CollectionUtils.isEmpty(lista)){
				Map<String, Object> mapaPlazoProceso = new HashMap<String, Object>();
				Map<String,Object> resultadoSoliPorroga = new HashMap<String, Object>();
				SoliProrrogaDAO soliProrrogaDAO;
				soliProrrogaDAO = fabricaDeServicios.getService("despaduanero2.soliProrrogaDAO");
				for(int i=0;i<lista.size();i++){	    		 
					mapaPlazoProceso = (Map<String, Object>) lista.get(i);
					if(ConstantesDataCatalogo.COD_CATALOGO_TIPO_PLAZO.equals(mapaPlazoProceso.get("COD_TIPPLZ"))){	    	    	 	    	    	 
						//Inicio RIN10 mpoblete BUG 22117	    	    	 
						/*
	    	    	 Map<String,Object> filtroSoliPorroga = new HashMap<String, Object>();	    
	    	    	 filtroSoliPorroga.put("NUM_CORREDOC", PkDecla.get("NUM_CORREDOC"));  
	    	    	 resultadoSoliPorroga = soliProrrogaDAO.findContarSolicitudesProrrogaConclusion(filtroSoliPorroga);
	    	    	 boolean noTieneSoliPorroga = false;
	    	    	 Object cantidadSoliProrroga = resultadoSoliPorroga.get("CANT"); 
	    	    	 if(cantidadSoliProrroga instanceof BigDecimal){	    	    			 
	    	    		 noTieneSoliPorroga = ((BigDecimal)cantidadSoliProrroga).compareTo(BigDecimal.ZERO)==0; 
	    	    	 }else{
	    	    		 noTieneSoliPorroga = ((Integer)cantidadSoliProrroga)==0; 
	    	    	 }*/
						boolean noTieneSoliPorroga = false;

						Map<String,Object> filtroSoliPorroga = new HashMap<String, Object>();
						filtroSoliPorroga.put("NUM_CORREDOC_PRE", PkDecla.get("NUM_CORREDOC"));
						filtroSoliPorroga.put("COD_TIPSOL",Constantes.COD_TIPO_SOLICITUD_PRORROGA);

						resultadoSoliPorroga = soliProrrogaDAO.findSolicitudesProrroga(filtroSoliPorroga);
						noTieneSoliPorroga = CollectionUtils.isEmpty(resultadoSoliPorroga); 
						//Fin RIN10 mpoblete BUG 22117	    	    	 
						if(noTieneSoliPorroga){
							mapaPlazoProceso.put("FEC_FINALDEFINITIVA", "");
							lista.remove(i);
							lista.add(i, mapaPlazoProceso);
						}	 
					}
				}
			}
		}      
		return lista;
	}
	/** Fin mpoblete RIN10 BUG 21179 **/



	/**
	 * realiza el proceso de validacion de la declaracion para el proceso de
	 * diligencia de rectificacion electronica.
	 *
	 * @param params
	 *          the params
	 * @return Map<String, Object>
	 * @throws ServiceException
	 *           the service exception
	 */
	public Map<String, Object> validarDeclaParaRectificacion(
			Map<String, Object> params) throws ServiceException
			{

		// valida que la declaracion tenga solicitud de rectificacion
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		Map<String, Object> parametros = new HashMap<String, Object>();

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
				+ params.get("caduana").toString().trim()));

		try
		{
			mapaRespuesta.put("MSGACE", new Boolean(false));
			Map<String, Object> mapaCabDeclara = this.cabDeclaraDAO
					.findNumCorreDocAndNumOrdenByDeclaracion(params);


			if(MapUtils.esMapaNuloOVacio(mapaCabDeclara))
			{
				mapaRespuesta.put("ERROR", "La Declaraci�n no se encuentra registrada en el sistema.");
				return mapaRespuesta;
			}

			String codCanal = MapUtils.getMapValor(mapaCabDeclara, "COD_CANAL");
			String fechaRecepcion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapaCabDeclara.get("FEC_RECEP"));
			// si el canal es rojo o naranja y fec_recep = '01/01/0001'
			// mensaje = La declaracion no tiene GED, no se puede evaluar la Solicitud
			// de Rectificaci�n Electr�nica
			boolean esCanalRojoOrNaranja = ArrayUtils.contains(new String[]
					{ Constantes.CANAL_NARANJA, Constantes.CANAL_ROJO }, codCanal.trim());
			boolean noTieneFechaRecepcion = fechaRecepcion.equals(Constantes.DEFAULT_FECHA_BD);

			if (esCanalRojoOrNaranja && noTieneFechaRecepcion)
			{
				mapaRespuesta.put("ERROR", "DUA con canal \"" + catalogoAyudaService
						.getDescripcionDataCatalogo("AR",
								codCanal.trim())
								+ "\" no cuenta con recepci�n de documentos, no puede efectuarse la evaluaci�n de la rectificaci�n");
				return mapaRespuesta;
			}

			mapaRespuesta.put("COD_CANAL", codCanal);

			String num_corredoc = MapUtils.getMapValor(mapaCabDeclara, "NUM_CORREDOC");

			// 01 rectificacion
			// 11 regularizacion
			parametros.put("NUM_CORREDOC", num_corredoc);
			parametros.put("COD_TIPSOL", "01"); // se agrego para validar el tipo de

			List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(parametros);
			if (listSolicitudesRecti == null || listSolicitudesRecti.size() == 0)
			{
				mapaRespuesta.put("ERROR", "La Declaraci�n no cuenta con Solicitud de Rectificaci�n Electr�nica.");
				return mapaRespuesta;
			}
      
			//pruizcr Rectificacion Electronica 
			Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
			String codigoEstado = (String) declaracion.get("COD_ESTDUA");
      
			//String codigoEstado =  MapUtils.getMapValor(mapaCabDeclara, "COD_ESTDUA");
			if(codigoEstado.equals("18")){
				mapaRespuesta.put("ERROR", "La mercanc�a de la declaraci�n se encuentra dispuesta totalmente.");
				return mapaRespuesta;
			}
      
			//pruizcr valida disposici�n parcial Rectificacion.
			Map<String, Object> paramsRecti = new HashMap<String, Object>();
			String num_secserie = MapUtils.getMapValor(mapaCabDeclara, "NUM_SECSERIE");
			paramsRecti.put("NUM_CORREDOC", num_corredoc);
			List lstAviso=null;
			if(codigoEstado.equals("19")){
        	
				//lstMercDispuestas= disposicionMercanciaService.validarDisposicionParcial(params);
				List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();			
				List<Map<String,Object>> lstMercDispuestas1 = null;
				//lstMercDispuestas1= disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(params); 
				lstMercDispuestas1= disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(paramsRecti); 
				int varMerDis=lstMercDispuestas1.size();
				String item= "";
				String seriemd="";
				String docDispo="";
				String fecDocDispo="";
				String fecDoc1="";
				if(lstMercDispuestas1.size()>0 && !lstMercDispuestas1.isEmpty() && lstMercDispuestas1!=null){
					lstResultadoMercancia.addAll(lstMercDispuestas1);
					for(int i=0; i<=varMerDis-1;i++){
						item= (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
						seriemd= (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
						docDispo= (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
						fecDocDispo= (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
						fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10); 
						mapaRespuesta.put("ERROR","Item["+item+"] de la Serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["+docDispo+"] de fecha ["+fecDoc1+"]");
					}	
				}
				return mapaRespuesta;
			}

			String tempEstaRecti = "";
			String numCorreDocSolicitud = "";

			// buscamos la solicitudes que esten en estado pendiente de evaluacion/ on
			// proceso de evaluacion
			// ordenamos el resultado por fecha en orden descendente
			if (listSolicitudesRecti.size() > 0)
			{
				Collections.sort(listSolicitudesRecti, new Comparator<Map<String, Object>>()
						{
					@Override
					public int compare(Map<String, Object> thiss, Map<String, Object> that)
					{
						Date nthiss = (Date) thiss.get("FEC_SOLICITUD");
						Date nthat = (Date) that.get("FEC_SOLICITUD");
						return nthat.compareTo(nthiss);
					}
						});
			}

			for (Map<String, Object> map : listSolicitudesRecti)
			{
				if (map.get("COD_ESTARECTI") == null)
				{
					continue;
				}
				tempEstaRecti = (String) map.get("COD_ESTARECTI");
				if (ArrayUtils.contains(new String[]
						//mordonezl pase 040
						{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION, Constantes.COD_ASIG_PENDIENTE_EVALUAR}, tempEstaRecti))
				{
					numCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
					break;
				}
			}

			if (numCorreDocSolicitud.equals(""))
			{
				mapaRespuesta.put(
						"ERROR",
						// "La solicitud de rectificacion tiene un estado que no permite su diligencia: "
						"La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica Pendiente de Evaluar, ya que se encuentra en estado "
						+ tempEstaRecti
						+ " ("
						+ catalogoAyudaService
						.getDescripcionDataCatalogo("363",
								tempEstaRecti) + ")");
				return mapaRespuesta;
			}

			parametros.put("NUM_CORREDOC", numCorreDocSolicitud);

			mapaRespuesta.put("NUM_CORREDOC_PRE", num_corredoc);
			mapaRespuesta.put("NUM_CORREDOC", numCorreDocSolicitud);

			Map<String, Object> mapaCabSolRecti = this.cabSolRectiDAO.findByDocumento(parametros);
			if(MapUtils.esMapaNuloOVacio(mapaCabSolRecti))
			{
				mapaRespuesta
				.put("ERROR", "La declaraci�n no cuenta con Solicitud de Rectificaci�n Electr�nica pendiente de evaluar.");
				return mapaRespuesta;
			}

			// verifico que el estado debe estar en 02,03 y 04,
			// "03 esta fuera de vigencia"
			String codEstaRecti = MapUtils.getMapValor(mapaCabSolRecti, "COD_ESTARECTI");

			mapaRespuesta.put("COD_ESTARECTI", codEstaRecti);
			mapaRespuesta.put("DES_MOTIVRECTI", MapUtils.getMapValor(mapaCabSolRecti, "DES_MOTIVRECTI").replace("\\r|\\n","").replace("  "," ").replace("\r|\n"," ").replace("\n", " ").replace("\r"," ").replace("  ", " "));

			if (!ArrayUtils.contains(new String[]
					//mordonezl pase 040
					{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION,Constantes.COD_ASIG_PENDIENTE_EVALUAR }, codEstaRecti))
			{
				// 363 estado de las solicitudes de rectificacion
				mapaRespuesta.put(
						"ERROR",
						// "La solicitud de rectificacion tiene un estado que no permite su diligencia: "
						"La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica Pendiente de Evaluar, ya que se encuentra en estado "
						+ codEstaRecti
						+ " ("
						+ catalogoAyudaService
						.getDescripcionDataCatalogo("363",
								codEstaRecti) + ")");

				return mapaRespuesta;
			}

			//bloquear ingreso a recti si tiene regu pendiente

			/***** GGRANADOS RIN16PASE3 INI *****/
			if(MapUtils.getMapValor(mapaCabDeclara, "COD_MODALIDAD").equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)){    	  
				Map<String, Object> paramRecti = new HashMap<String, Object>();
				paramRecti.put("numcorredocpre", mapaCabDeclara.get("NUM_CORREDOC").toString());
				paramRecti.put("codTransaccion", ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE);
				paramRecti.put("estadosrecti",new String[] {ConstantesDataCatalogo.COD_EST_REGULA_EN_PROCESO});
				List<Map<String, Object>> listaRecti = cabSolRectiDAO.listByDocumentoByParameterMap(paramRecti);
				if(!CollectionUtils.isEmpty(listaRecti)){
					mapaRespuesta.put("ERROR", 
							((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35255").get("desError"));
					return mapaRespuesta;
				}
			}
			/***** GGRANADOS RIN16PASE3 FIN *****/

			parametros.put("NUM_CORREDOC", num_corredoc);
			List rows = null;
			rows = this.cabDeclaraDAO.select(parametros);
			mapaCabDeclara = (Map) rows.get(0);

			String fechaAutorizacioLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapaCabDeclara
					.get("FEC_AUTLEVANTE"));
			boolean tieneAutorizacionLevante = !fechaAutorizacioLevante.equals(Constantes.DEFAULT_FECHA_BD);

			mapaRespuesta.put("COD_CANAL_DESC", catalogoAyudaService.getDescripcionDataCatalogo("AR", codCanal));
			mapaRespuesta.put("COD_MOTIVOCANALASIG", MapUtils.getMapValor(mapaCabDeclara, "COD_MOTIVOCANALASIG"));
			
			//RSV PAS20165E220200076 VALIDACION DE TRAMITE PARA CONTINGENTES CON INDICADOR 16
			//	if ( !diligenciaService.validarRectiTieneExpedienteContingentes(mapaCabDeclara , new Long(numCorreDocSolicitud)) ) {
			
			try
			{
				diligenciaService.validarRectiTieneExpedienteContingentes(mapaCabDeclara , new Long(numCorreDocSolicitud));

			}
			catch (ServiceException serException)
			{
				mapaRespuesta.put("ERROR", serException.getMessage());
				return mapaRespuesta;
			}
				 

			try
			{
				// buscamos la fecha de la diligencia de despacho
				Map duadiligenciada = diligenciaService.findDuaDiligenciada(num_corredoc);
				boolean tieneDiligenciaDespacho = duadiligenciada == null ? false : true;
				//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
				mapaCabDeclara.put("numCorreDocSolicitud", numCorreDocSolicitud);
				validarRectiTieneExpedienteSustentoRectificacion(mapaCabDeclara, tieneDiligenciaDespacho);
			}
			catch (ServiceException serException)
			{
				mapaRespuesta.put("ERROR", serException.getMessage());
				return mapaRespuesta;
			}

			parametros.put("COD_ADUANA", params.get("COD_ADUANA"));
			parametros.put("ANN_PRESEN", params.get("ANN_PRESEN"));
			parametros.put("COD_REGIMEN", params.get("COD_REGIMEN"));
			parametros.put("NUM_DECLARACION", params.get("NUM_DECLARACION"));
			parametros.put("NUM_CORREDOC", num_corredoc);

			String cod_funcionario_portal = params.get("USERSESSION").toString().trim();
			String codEstDua = mapaCabDeclara.get("COD_ESTDUA").toString();

			try
			{

				//      boolean tieneMedidaPreventiva = tieneMedidaPreventivaDua(params.get("COD_ADUANA").toString(), params.get("COD_REGIMEN").toString(), new Long(params.get("NUM_DECLARACION").toString()),new Long(params.get("ANN_PRESEN").toString()));
				/*	 log.debug("medida preventiva es" + tieneMedidaPreventiva );
      	if(codCanal != null && !tieneMedidaPreventiva){
      		 // Validacion canal D,F con fecha de recepcion y con fecha de
              // autorizacion de levante
        validaTieneAsignadoFuncionario(num_corredoc, fechaRecepcion,
            tieneAutorizacionLevante, cod_funcionario_portal,
      	            codCanal.trim(),codEstDua);
      	}*/

				//Lmvr- inicio - Complemento de rectificacion  	
				if(codEstDua.equals("02")){
					validaTieneAsignadoFuncionario(num_corredoc, fechaRecepcion,
							tieneAutorizacionLevante, cod_funcionario_portal,
							codCanal.trim(),codEstDua);
				}else{

					validaTieneAsignadoFuncionarioSolRectificacion(numCorreDocSolicitud, cod_funcionario_portal,
							codCanal.trim(),codEstDua,num_corredoc);	
					//Lmvr- fin - Complemento de rectificacion  	
				}


				// Validacion sin fecha de recepcion o ( canal F y D con diligencia) o
				// canal V y sin fecha de autorizacion de levante
				//ggranados pase 102, ya no se debe validar si esta vigente el especialista,
				//basta con que este asignado
				/* validaDisponibilidadEspecialidad(params,
            tieneAutorizacionLevante, cod_funcionario_portal,
            codCanal.trim());*/
			}
			catch (ServiceException serException)
			{
				mapaRespuesta.put("ERROR", serException.getMessage());
				return mapaRespuesta;
			}

			/* P14 - Inicio 3007 06.01 - erodriguezb*/
			//validar indicador de abandono voluntario
			try
			{
				validaNoTengaIndicadorAbandonoVoluntario(Long.valueOf(num_corredoc));
			}
			catch (ServiceException serException)
			{
				mapaRespuesta.put("ERROR", serException.getMessage());
				return mapaRespuesta;
			}
			/* P14 - FIN 3007 06.01 - erodriguezb*/

			parametros.put("NUM_CORREDOC", num_corredoc);

			// Vallidacion de si tiene ACE
			List<Map<String, Object>> detailRows = serieService.select(parametros);
			parametros.put("LIST_SERIES", detailRows);
			parametros.put("COD_ADUAMANIFIESTO", mapaCabDeclara.get("COD_ADUAMANIFIESTO"));
			parametros.put("ANN_MANIFIESTO", mapaCabDeclara.get("ANN_MANIFIESTO"));
			parametros.put("NUM_MANIFIESTO", mapaCabDeclara.get("NUM_MANIFIESTO"));
			parametros.put("COD_VIATRANS", mapaCabDeclara.get("COD_VIATRANS"));
			Map<String, Object> response = this.soporteService.obtenerAccionesDeControlExtraordinario(parametros);
			List<Map> aces = (List<Map>) response.get("aces");
			StringBuilder straces = new StringBuilder("<br>");
			//amancilla
			Integer contar = 0;
			List<Map<String,String>> jsonLstAdvertencias = new ArrayList();
			Map<String,String> mapRSPTA = new HashMap();
			//fin amancilla
			for (Map ace : aces)
			{
				contar++;
				//PAS20165E220200127  
				straces.append(ace.get("ACE").toString() + " N�" + ace.get("NRO").toString() + "<br>");

				mapRSPTA = new HashMap();
				mapRSPTA.put("nro",contar.toString());	
				if(ace.get("ACE").toString().equalsIgnoreCase(" ACE")){
					mapRSPTA.put("documento","Mercanc�a cuenta con " + ace.get("ACE").toString().toUpperCase());
				}
				else if (ace.get("ACE").toString().equalsIgnoreCase("ACTA DE INMOVILIZACION"))
				{
					mapRSPTA.put("documento","Mercanc�a cuenta con Acta de Inmovilizacion");
				}
				else if (ace.get("ACE").toString().equalsIgnoreCase("ACTA DE INCAUTACION"))
				{
					mapRSPTA.put("documento","Mercanc�a cuenta con Acta de Incautacion");
				}
				else{
					mapRSPTA.put("documento","Mercanc�a cuenta con " + ace.get("ACE").toString().toLowerCase());
				}

				mapRSPTA.put("mensaje", " N�" + ace.get("NRO").toString());
				jsonLstAdvertencias.add(mapRSPTA);
			}
			
			DudaBusquedaService miDudaBusquedaService = (DudaBusquedaService)this.fabricaDeServicios.getService("dudarazonable.DudaBusquedaService");
			Map<String,Object> mapDAM = new HashMap<String,Object>(); 
			mapDAM.put("numCorrelativoDAM", new Long(num_corredoc));
			mapDAM.put("codigoEstado", "1");
			CabDudaRazonable resultadoCabDuda = miDudaBusquedaService.obtenerCabDudaRazonableGeneral(mapDAM);
			if(resultadoCabDuda!=null){
				Map<String,String> temp = new HashMap();
				temp.put("tieneDuda", "1");
				aces.add(temp);
				contar++;
				mapRSPTA = new HashMap();
				mapRSPTA.put("nro",contar.toString());			            		   
				mapRSPTA.put("documento","DUDA RAZONABLE");
				mapRSPTA.put("mensaje","EXISTE UNA DUDA RAZONABLE PENDIENTE");
				jsonLstAdvertencias.add(mapRSPTA);
			}
			
			if (aces.size() > 0)
			{ 
				//PAS20165E220200127
				mapaRespuesta.put("ERROR", "Mercanc�a cuenta con " + straces.toString());        
				mapaRespuesta.put("MSGACE", aces.size() > 0 ? true : false);
				mapaRespuesta.put("documento","Observaci�n");
				mapaRespuesta.put("jsonLstAdvertencias", jsonLstAdvertencias);
				return mapaRespuesta;
			}

		}
		catch (Exception e)
		{
			log.error(this.toString() + " validarDeclaParaRectificacion - ERROR: "
					+ e);
			throw new ServiceException(this, "ocurrio un error durante la validacion de la dua");
		}

		return mapaRespuesta;
			}

	//Lmvr- inicio - Complemento de rectificacion
	private void validaTieneAsignadoFuncionarioSolRectificacion(
			String numCorredocSolRect,
			String cod_funcionario_portal,
			String codCanal,
			String codEstDua,
			String num_corredocDeclaracion ) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		Validate.notEmpty(numCorredocSolRect, "Para la validaci�n de funcionario asignado el numero correlativo de la Solicitud de Rectificacion es requerido");
		Validate.notEmpty(cod_funcionario_portal, "Para la validaci�n de funcionario asignado el codigo del funcionario es requerido");
		/*
		 * verificar utilizando la clase Validate, no se esta mostrando el mensaje requerido
		 */
		//	    if ((codCanal == null || codCanal.length() == 0) && !tieneMedidaPreventiva ) La validacion del canal de control en una DUA sin canal se realiza en un proceso anterior,: al momento de Asignar la Declaracion. si no tiene canal pero tiene medida preveniva se asigna.
		//			throw new ServiceException(this, "Para la validaci�n de funcionario asignado el codigo del canal de la DUA es requerida");;
		parametros.put("NUM_CORREDOC", numCorredocSolRect);
		String cod_funcionario;
		//	    String cod_funcionarioDeclaracion;
		//	    if  (!Constantes.ESTADO_DECLARACION_NUMERADO.equals(codEstDua)){ 
		// Validar si dua esta asignado a funcionario
		cod_funcionario = this.espeDocuDAO.findEspecAsigByDocu(parametros);
		//	      parametros.put("NUM_CORREDOC", num_corredocDeclaracion);
		//	      cod_funcionarioDeclaracion = this.espeDocuDAO.findEspecAsigByDocu(parametros);
		if (cod_funcionario == null) {
			throw new ServiceException(this, "Funcionario aduanero no se encuentra asignado");
		}
		if(cod_funcionario!=null){
			if (!cod_funcionario.trim().equals(cod_funcionario_portal)) {
				throw new ServiceException(this, "La Solicitud de Rectificaci�n no est� asignada a usted, est� asignada al funcionario con registro " + cod_funcionario);
			}else{
				return;
			}
		}
		/*	      if(cod_funcionarioDeclaracion!=null){
				if (!cod_funcionarioDeclaracion.trim().equals(cod_funcionario_portal)) {
					throw new ServiceException(this, "La Solicitud de Rectificaci�n no est� asignada a usted, est� asignada al funcionario con registro "
		                + cod_funcionarioDeclaracion );
		       }
		    }*/
	}
	//	  }

	//Lmvr- fin - Complemento de rectificacion

	/* P14 - Inicio 3007 06.01 - erodriguezb*/

	/**
	 * Valida que no tenga indicador de abandono voluntario.
	 *
	 * @param numCorredoc N�mero de documento, String 
	 */
	public void validaNoTengaIndicadorAbandonoVoluntario(Long numCorreDoc) {
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("numcorredoc", numCorreDoc);
		parametros.put("codtipoindica", "14");
		parametros.put("indactivo", "1");
		//Integer resultado = cabDeclaraDAO.declaracionTieneIndicadorAbandonoVoluntario(parametros);
		List<DatoIndicadores> resultado = indicadorDUADAO.findIndicadoresByMap(parametros);

		if (resultado.size() > 0){

			Map<String, String> mapa = catalogoAyudaService.getError(Constantes.COD_ERROR_IND_ABANDONO_VOLUNTARIO_RECTIF);
			throw new ServiceException(this, mapa.get("desError") );

		}

	}

	/* P14 - Fin 3007 06.01 - erodriguezb*/

	/**
	 * Valida que el funcionaro aduanero sea especialista y este vigente y el
	 * codigo de la aduana y el codigo del regimen sean iguales a la DUA.
	 *
	 * @param params
	 *          (COD_ADUANA, COD_REGIMEN)
	 * @param tieneDiligenciaDespacho
	 *          the tiene diligencia despacho
	 * @param cod_funcionario_portal
	 *          the cod_funcionario_portal
	 * @param codCanal
	 *          the cod canal
	 */
	private void validaDisponibilidadEspecialidad(
			Map<String, Object> params,
			boolean tieneDiligenciaDespacho,
			String cod_funcionario_portal,
			String codCanal)
	{

		Validate.notEmpty(params, "Para la validaci�n de disponibilidad el mapa params no debe de ser nulo ni estar vacio");
		Validate.notNull(params.get("COD_ADUANA"),
				"Para la validaci�n de disponibilidad el codigo de aduana no debe ser nulo");
		Validate.notNull(params.get("COD_REGIMEN"),
				"Para la validaci�n de disponibilidad el codigo de regimen no debe ser nulo");

		boolean esCanalRojoOrNaranja = ArrayUtils.contains(new String[]
				{ Constantes.CANAL_NARANJA, Constantes.CANAL_ROJO }, codCanal.trim());

		boolean esCanalVerde = Constantes.CANAL_VERDE.equals(codCanal.trim());
		List rows;
		// Validacion sin fecha de recepcion o ( canal F y D con diligencia) o canal V
		if ((esCanalRojoOrNaranja && tieneDiligenciaDespacho) || esCanalVerde)
		{
			Map<String, Object> mapespedispo = new HashMap<String, Object>();
			mapespedispo.put("COD_FUNCIONARIO", cod_funcionario_portal);
			mapespedispo.put("COD_ADUANA", params.get("COD_ADUANA"));
			mapespedispo.put("COD_REGIMEN", params.get("COD_REGIMEN"));
			//actualmente no necesariamente perteneca al GRUPO_CONCLUCION_DESPACHO puede ser un GAR 
			// mapespedispo.put("COD_GRUPO", Constantes.GRUPO_CONCLUCION_DESPACHO);
			mapespedispo.put("INDICADOR_VIGENTE", "1");
			rows = this.espeDispoDAO.buscarEspeDispo(mapespedispo);
			if (rows.size() == 0)
			{
				throw new ServiceException(
						this,
						"Funcionario aduanero no se encuentra habilitado, verifique en disponibilidad del especialista.");
			}
		}
	}

	/**
	 * Valida tiene asignado funcionario.
	 *
	 * @param numCorredocDua
	 *          the num corredoc dua
	 * @param fechaRecepcion
	 *          the fecha recepcion
	 * @param tieneAutorizacionLevante
	 *          the tiene autorizacion levante
	 * @param cod_funcionario_portal
	 *          the cod_funcionario_portal
	 * @param codCanal
	 *          the cod canal
	 */
	private void validaTieneAsignadoFuncionario(
			String numCorredocDua,
			String fechaRecepcion,
			boolean tieneAutorizacionLevante,
			String cod_funcionario_portal,
			String codCanal,
			String codEstDua)
	{
		Map<String, Object> parametros = new HashMap<String, Object>();

		Validate.notEmpty(
				numCorredocDua,
				"Para la validaci�n de funcionario asignado el numero correlativo de la Dua es requerido");
		Validate.notEmpty(
				fechaRecepcion,
				"Para la validaci�n de funcionario asignado la fecha de recepci�n de la Dua es requerida");
		Validate.notEmpty(
				cod_funcionario_portal,
				"Para la validaci�n de funcionario asignado el codigo del funcionario es requerido");
		/*
		 * verificar utilizando la clase Validate, no se esta mostrando el
		 * mensaje requerido
		 */
		// Validate.notEmpty(codCanal,"Para la validaci�n de funcionario asignado el codigo del canal de la DUA es requerida");

		if (codCanal == null || codCanal.length() == 0)
			throw new ServiceException(
					this,
					"Para la validaci�n de funcionario asignado el codigo del canal de la DUA es requerida");
		;

		parametros.put("NUM_CORREDOC", numCorredocDua);

		String cod_funcionario;
		/*boolean esCanalRojoOrNaranja = ArrayUtils.contains(new String[]
    { Constantes.CANAL_NARANJA, Constantes.CANAL_ROJO }, codCanal.trim());*/
		// Validacion canal D,F con fecha de recepcion y sin diligencia de
		// despacho
		/*PAS20144E610000040 
		 * if (esCanalRojoOrNaranja && !fechaRecepcion.equals(Constantes.DEFAULT_FECHA_BD) && !tieneAutorizacionLevante)
    {*/    
		if  (!Constantes.ESTADO_DECLARACION_NUMERADO.equals(codEstDua)){ 
			// Validar si dua esta asignado a funcionario
			cod_funcionario = this.espeDocuDAO.findEspecAsigByDocu(parametros);

			if (cod_funcionario == null)
			{
				throw new ServiceException(this,
						"Funcionario aduanero no se encuentra asignado a la DUA");
			}

			if (!cod_funcionario.trim().equals(cod_funcionario_portal))
			{
				throw new ServiceException(
						this,
						"La declaraci�n no est� asignada a usted, est� asignada al funcionario con registro "
								+ cod_funcionario);
			}
		}
	}

	/* olunar 040 */
	private boolean tieneMedidaPreventivaDua(String codAduana, String codRegimen,Long numDeclaracion,Long annPresen) throws ServiceException {

		Map<String, Object> paramDua = new HashMap<String, Object>();
		paramDua.put("COD_ADUANA", codAduana);  
		paramDua.put("ANN_PRESEN", annPresen);
		paramDua.put("COD_REGIMEN", codRegimen);
		paramDua.put("NUM_DECLARACION", numDeclaracion);
		paramDua.put("ctdoc_preco", "0300");
		MovDuasActasDAO movDuasActasDAO = fabricaDeServicios.getService("prevcontrabando2.operativo.movDuasActasDAO");
		int numActasPrevParcial = movDuasActasDAO.countActasPrevParcial(paramDua);		
		return numActasPrevParcial > 0;   		
	}
	/* fin */

	/**
	 * Metodo que verifica si la dua cuenta con un expediente de sustento de
	 * rectificacion: Canal Verde: todos deben de tener un expediente de sustento
	 * de rectificacion Canal Rojo o Naranja: solo los que tengan una diligencia
	 * de despacho deben tener un expediente de sustento de rectificacion.
	 *
	 * @param mapaCabDeclara
	 *          mapa con la informacion de la declaracion (DUA)
	 * @param tieneDiligenciaDespacho
	 *          the tiene diligencia despacho
	 * @throws ServiceException
	 *           the service exception
	 */
	private void validarRectiTieneExpedienteSustentoRectificacion(
			Map<String, Object> mapaCabDeclara,
			boolean tieneDiligenciaDespacho)
					throws ServiceException
	{
		String mensajeError = ""; 
		String codCanal = MapUtils.getMapValor(mapaCabDeclara, "COD_CANAL");
		String descCanal = catalogoAyudaService.getDescripcionDataCatalogo("AR", codCanal);
		boolean tieneExpedienteSustento = false;
		boolean esCanalVerde = Constantes.CANAL_VERDE.equals(codCanal);
		boolean esCanalNaranja = Constantes.CANAL_NARANJA.equals(codCanal);
		boolean esCanalRojo = Constantes.CANAL_ROJO.equals(codCanal);
		boolean esCanalRojoNaranja = esCanalNaranja || esCanalRojo;
		boolean esSinCanal = "".equals(codCanal.trim());//PAS20165E220200127

	
        //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
		Long numeroCorrelativoSolicitud =  mapaCabDeclara.get("numCorreDocSolicitud")== null ? new Long(0):  Long.valueOf( MapUtils.getMapValor(mapaCabDeclara, "numCorreDocSolicitud")); 
        Map<String, Object> parametros = new HashMap<String, Object>();
	    parametros.put("NUM_CORREDOC", new Long(mapaCabDeclara.get("NUM_CORREDOC").toString()));
        boolean indicador16 = false;
        RectificacionAbstract rectifiSerie = fabricaDeServicios.getService("diligencia.rectificacion.codtabla." + "T0060");
        List<Map<String, Object>> lstIndicadorDUA = rectifiSerie.getTableRectificadoMergedBD(
        parametros,
          numeroCorrelativoSolicitud);
		    if(   !CollectionUtils.isEmpty(lstIndicadorDUA))	 {
		        for (Map<String, Object> indicadorDUA : lstIndicadorDUA)
		        {
		        	
		        	if( "16".equals(indicadorDUA.get("COD_INDICADOR").toString())     )	{    
		    				indicador16 = true;
		    				break;
		    			}
		        }
		    }
    //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
        //PAS20165E220200127
		if ((esCanalRojoNaranja && tieneDiligenciaDespacho) || esCanalVerde || indicador16 || esSinCanal)
		{
			Map<String, Object> param2 = new HashMap<String, Object>();
			param2.put("FEC_DECLARACION", mapaCabDeclara.get("FEC_DECLARACION"));
			param2.put("COD_ADUANA", mapaCabDeclara.get("COD_ADUANA"));
			param2.put("ANN_PRESEN", mapaCabDeclara.get("ANN_PRESEN").toString());
			param2.put("NUM_DECLARACION", mapaCabDeclara.get("NUM_DECLARACION"));
			param2.put("COD_REGIMEN", mapaCabDeclara.get("COD_REGIMEN"));

			tieneExpedienteSustento = soporteService.tieneExpedienteSustentoRectificacion(param2);
			if (tieneExpedienteSustento)
			{
				//return;
			}
			else
			{
				if (esCanalRojoNaranja)
				{
					mensajeError = "La declaraci�n con canal \""
							+ descCanal
							+ "\", tiene una solicitud de rectificaci�n posterior a la diligencia de despacho, que no cuenta con un expediente de tr�mite documentario con el sustento de la rectificaci�n";
				}

				if (esCanalVerde)
				{
					mensajeError = "La declaraci�n con canal \""
							+ descCanal
							+ "\", tiene una solicitud de rectificaci�n que no cuenta con un expediente de tr�mite documentario con el sustento de la rectificaci�n";
				}
				//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
				if (indicador16)
				{
					mensajeError = "La declaraci�n con acogimiento a contingente en la rectificaci�n posterior a la cancelaci�n de la deuda, no cuenta con expediente de tr�mite documentario (procedimiento 0904)";
				}
				//RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
				//PAS20165E220200127
				if (esSinCanal)
				{
					mensajeError = "La declaraci�n sin canal tiene una solicitud de rectificaci�n que no cuenta con un expediente de tr�mite documentario con el sustento de la rectificaci�n";
				}
				throw new ServiceException(this, mensajeError);
			}
		}
		/*lmvr - Inicio: Complemento de la Diligencia */
		List<Map<String, Object>> list = validarExpedienteAsociadoImportadorDeclaracion(mapaCabDeclara);
		if (list!=null) {
			if (list.size()>0) {
				mensajeError = " ";
				for(Map<String, Object> mensaje : list){
					mensajeError = mensajeError +  mensaje.get("DESCRIPCION").toString() + " ";
				}
				throw new ServiceException(this, mensajeError);
			}
		}

		/*lmvr - Fin: Complemento de la Diligencia */    
	}

	/*lmvr - Inicio: Complemento de la Diligencia */
	/**
	 * Verifica que exista un expediente de tr�mite documentario asociado a la declaraci�n  con alguno de los siguientes c�digos:
	 * 1607: Importaci�n Definitiva � Solicitud Electr�nica de Rectificaci�n de la Declaraci�n.
	 * 3071: Declaraci�n de Importaci�n � Rectificar / Aclaraci�n. 
	 * 3109: Documentaci�n Sustentatoria de la Rectificaci�n Electr�nica
	 *
	 * @param mapaCabDeclara
	 *          mapa con la informacion de la declaracion (DUA)
	 * @throws ServiceException
	 *          the service exception
	 */  
	public List<Map<String, Object>> validarExpedienteAsociadoImportadorDeclaracion(Map<String, Object> mapaCabDeclara) throws ServiceException{
		List<Map<String, Object>> errores = new ArrayList<Map<String, Object>>();
		Map<String, Object> error = new HashMap<String,Object>();
		Map parametros = new HashMap();
                //RSERRANOV PAS20165E220200076  SE ADICIONA PARA CONTINGENTES
		String[] tipoExpediente = new String[] {"1607","3071","3109","0904"};
		String[] notEstadoExpediente = new String[] {"8","9","99"};
		parametros.put("NUM_DECLARACION", mapaCabDeclara.get("NUM_DECLARACION"));
		parametros.put("ANN_PRESEN", mapaCabDeclara.get("ANN_PRESEN").toString());//faltaba y generaba error
		parametros.put("COD_ADUANA", mapaCabDeclara.get("COD_ADUANA"));
		parametros.put("COD_REGIMEN", mapaCabDeclara.get("COD_REGIMEN"));
		parametros.put("codi_aduan", mapaCabDeclara.get("COD_ADUANA")); // Para el swaper de tramite
		parametros.put("PROCEDIM_IN", tipoExpediente);
		parametros.put("ACT_ESTADO_NOT_IN", notEstadoExpediente);

		Long NUM_CORREDOC = Long.parseLong(mapaCabDeclara.get("NUM_CORREDOC").toString());
		List<Map<String, Object>> datosSolicitudRectificacion = this.solicitudService.buscarRectiyReguPend(NUM_CORREDOC);

		//PAS20165E220200152-Inicio
		Date fechaSolicitudRectificacion = SunatDateUtils.getDefaultDate();
		if(!CollectionUtils.isEmpty(datosSolicitudRectificacion)) {
		   fechaSolicitudRectificacion = (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");
		}
		//PAS20165E220200152-Fin		
		
		Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(parametros);
		Date fechaAutLevante = (Date) mapCabDeclara.get("FEC_AUTLEVANTE");

		if (SunatDateUtils.isDefaultDate(fechaAutLevante)) {
			return errores;
		}
		if(SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRectificacion,fechaAutLevante,SunatDateUtils.COMPARA_SOLO_FECHA)) {			
			parametros.put("COD_REGIMEN", Utilidades.obtieneRegimenExped(mapaCabDeclara.get("COD_REGIMEN").toString()));
			ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
			List<Map<String, Object>> listExpediente = expedienteService.findExpedientesAsociadoDeclaracion(parametros); 
			parametros.put("COD_REGIMEN", mapaCabDeclara.get("COD_REGIMEN"));
			if (listExpediente.size() > 0) {				
				parametros.put("numeroCorrelativo", mapCabDeclara.get("NUM_CORREDOC"));
				parametros.put("codTippartic", new String[] {"41","45"});

				ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("diligencia.ingreso.participanteDef_xa");

				List<Participante> listadoParticipante = participanteDAO.findTipoPartTransByCriterios(parametros);
				String[] RucImportadorAgente = new String[listadoParticipante.size()];

				int i=0;
				for(Participante participante : listadoParticipante) {
					RucImportadorAgente[i] = participante.getNumeroDocumentoIdentidad();
					i++;
				}
				for(Map<String, Object> expediente : listExpediente){
					//if(SunatStringUtils.include(expediente.get("NRODOC").toString().trim(), RucImportadorAgente)) {
					if(SunatStringUtils.include(expediente.get("COMIT_NRO").toString().trim(), RucImportadorAgente)) {
						tieneExpedienteAsociadoRUCRectificacion = true;
						errores.clear();
						return errores;
					}
					else{						
						error.put("ERROR", "30775");
						//String rucExpediente = expediente.get("NRODOC").toString();
						String rucExpediente = expediente.get("COMIT_NRO").toString();
						String numeroexpediente = expediente.get("CODI_ADUA").toString()+"-"+expediente.get("OFIC_REC").toString()+
								"-"+expediente.get("ANOEXPEDI").toString() + "-" +expediente.get("NROEXPEDI").toString();
						error.put("DESCRIPCION", "Numero de RUC " + rucExpediente + " del expediente " + numeroexpediente + " no corresponde al agente de aduana y/o consignatario de la declaraci�n a rectificar");
						errores.add(error);
					}
				}
			} else {
				error.put("ERROR", "30775");
				error.put("DESCRIPCION", "No existe expediente de tr�mite documentario asociado a la declaraci�n");
				errores.add(error);
			}
		}
		return errores;
	}

	/*lmvr - Fin: Complemento de la Diligencia */  


	/**
	 * Extrae los datos del anexo y las direcciones de los establecimientos de un
	 * contribuyente.
	 *
	 * @param pkDocu
	 *          the pk docu
	 * @return Map que contienen el correlativo del establecimiento y la direccion
	 *         formada por el nombre de via, numero e interior
	 * @throws ServiceException
	 *           the service exception
	 */
	public Map<String, Object> obtenerAnexo2(Map<String, Object> pkDocu)
			throws ServiceException
			{
		List<Map<String, Object>> lstFinUbicacion = finUbicacionDAO.select(pkDocu);
		Map<String, Object> resultado = lstFinUbicacion.size() > 0 ? (HashMap<String, Object>) lstFinUbicacion.get(0)
				: null;
		String direccionAnexo = "";
		String razonSocialAnexo = "";
		if (resultado != null)
		{
			// si el tipo de documento es ruc
			if (resultado.get("COD_TIPDOCLOCMERC") != null
					&& "4".equals(resultado.get("COD_TIPDOCLOCMERC").toString().trim()))
			{
				if (resultado.get("NUM_DOC_LOCMERC") != null)
				{

					String codLocalAnexo = Cadena.padLeft(
							MapUtils.getMapValor(resultado, "COD_LOCALANEXO"), 4, '0');

					//          List anexos = this.sprDAO.getEstablecimientosAnexos(resultado
					//              .get("NUM_DOC_LOCMERC").toString().trim());

					List anexos = sprDAOService.getEstablecimientosAnexos(resultado
							.get("NUM_DOC_LOCMERC").toString().trim());

					if (!CollectionUtils.isEmpty(anexos))
					{
						Iterator it = anexos.iterator();
						while (it.hasNext())
						{
							Map mapSpr = (HashMap) it.next();
							//String correl = Cadena.padLeft(String.valueOf(((Short) mapSpr.get("spr_correl")).intValue()), 4, '0');
							String correl = Cadena.padLeft(String.valueOf(mapSpr.get("spr_correl")!=null?mapSpr.get("spr_correl"):"").trim(), 4, '0');
							if (correl.equals(codLocalAnexo))
							{
								direccionAnexo = formaDireccion(
										(String) mapSpr.get("spr_nomvia"),
										(String) mapSpr.get("spr_numer1"),
										(String) mapSpr.get("spr_inter1"));
							}
						}
					}
					resultado.put("DIRECCION", direccionAnexo);
					direccionAnexo = "Codigo local anexo: ".concat(codLocalAnexo)
							.concat("-").concat(direccionAnexo);
				}
			}
			if (Constantes.TIPO_DOC_RUC.equals(resultado.get("COD_TIPDOCLOCMERC").toString().trim()))
			{
				Map pers = this.soporteService.obtenerPerNatJur(
						resultado.get("COD_TIPDOCLOCMERC").toString().trim(),
						resultado.get("NUM_DOC_LOCMERC").toString().trim());

				razonSocialAnexo = (String) pers.get("nombre");

			}
			resultado.put("NOM_RAZONSOCIAL_ANEXO", razonSocialAnexo);
			resultado.put("DIRECCION_ANEXO", direccionAnexo);
		}
		return resultado;
			}

	/**
	 * Obtener anexo2 from fin ubicacion.
	 *
	 * @param finUbicacion
	 *          the fin ubicacion
	 * @return el fin ubicacion con todos los datos necesarioa para ser mostrados
	 *         en pantalla
	 * @throws DataAccessException
	 *           the data access exception
	 * @throws ServiceException
	 *           the service exception
	 */
	public Map<String, Object> obtenerAnexo2FromFinUbicacion(Map<String, Object> finUbicacion)
			throws DataAccessException, ServiceException
			{

		Map<String, Object> resultado = new HashMap<String, Object>(finUbicacion);
		String direccionAnexo = "";
		String razonSocialAnexo = "";
		// si el tipo de documento es ruc
		if (resultado.get("COD_TIPDOCLOCMERC") != null
				&& Constantes.TIPO_DOC_RUC.equals(resultado.get("COD_TIPDOCLOCMERC").toString().trim()))
		{
			if (resultado.get("NUM_DOC_LOCMERC") != null)
			{

				String codLocalAnexo = Cadena.padLeft(
						MapUtils.getMapValor(resultado, "COD_LOCALANEXO"), 4, '0');

				//        List anexos = this.sprDAO.getEstablecimientosAnexos(resultado
				//            .get("NUM_DOC_LOCMERC").toString().trim());

				List anexos = sprDAOService.getEstablecimientosAnexos(resultado
						.get("NUM_DOC_LOCMERC").toString().trim());

				if (anexos != null && anexos.size() > 0)
				{
					Iterator it = anexos.iterator();
					while (it.hasNext())
					{
						Map mapSpr = (HashMap) it.next();
						//String correl = Cadena.padLeft(String.valueOf(((Short) mapSpr.get("spr_correl")).intValue()), 4, '0');
						String correl = Cadena.padLeft(String.valueOf(mapSpr.get("spr_correl")!=null?mapSpr.get("spr_correl"):"").trim(), 4, '0');
						if (correl.equals(codLocalAnexo))
						{
							direccionAnexo = formaDireccion(
									(String) mapSpr.get("spr_nomvia"),
									(String) mapSpr.get("spr_numer1"),
									(String) mapSpr.get("spr_inter1"));
						}
					}
				}
				resultado.put("DIRECCION", direccionAnexo);
				direccionAnexo = "Codigo local anexo: ".concat(codLocalAnexo)
						.concat("-").concat(direccionAnexo);
			}
			Map pers = this.soporteService.obtenerPerNatJur(
					resultado.get("COD_TIPDOCLOCMERC").toString().trim(),
					resultado.get("NUM_DOC_LOCMERC").toString().trim());

			razonSocialAnexo = (String) pers.get("nombre");
		}

		resultado.put("NOM_RAZONSOCIAL_ANEXO", razonSocialAnexo);
		resultado.put("DIRECCION_ANEXO", direccionAnexo);

		return resultado;
			}

	/**
	 * Extrae los datos del local anexo de la declaracion con el Ruc del Deposito
	 * Aduanero recuadro 4.2 de la pantalla de la declaracion
	 *
	 * @param ruc
	 *          the ruc
	 * @param codAnexo
	 *          the cod anexo
	 * @return String direccion formada por el nombre de via, numero e interior
	 * @throws ServiceException
	 *           the service exception
	 */
	public String obtenerLocalAnexoDeclaracion(String ruc, String codAnexo)
			throws ServiceException
	{
		String direccionAnexo = "";

		if ((!"".equals(ruc) && !"".equals(codAnexo)) && (!"0000".equals(codAnexo)))
		{
			//me aseguro que tenga 4 caracteres
			String codLocalAnexo = Cadena.padLeft(codAnexo != null ? codAnexo.trim() : "", 4, '0');

			//      List lstAnexos = this.sprDAO.getEstablecimientosAnexos(ruc);

			List lstAnexos = sprDAOService.getEstablecimientosAnexos(ruc);

			if (!CollectionUtils.isEmpty(lstAnexos))
			{
				Iterator it = lstAnexos.iterator();
				while (it.hasNext())
				{
					Map mapSpr = (HashMap) it.next();
					String correl = Cadena.padLeft(String.valueOf(mapSpr.get("spr_correl")!=null?mapSpr.get("spr_correl"):"").trim(), 4, '0');//gmontoya Rest
					if (correl.equals(codLocalAnexo))
					{
						direccionAnexo = formaDireccion(
								(String) mapSpr.get("spr_nomvia"),
								(String) mapSpr.get("spr_numer1"),
								(String) mapSpr.get("spr_inter1"));
					}
				}
			}
		}
		else
		{
			//      Map direccion = ddpDAO.findByPK(ruc);
			Map direccion = ddpDAOService.findByPK(ruc);
			if(!CollectionUtils.isEmpty(direccion)){
				direccionAnexo = formaDireccion((String) direccion.get("ddp_nomvia"),
						(String) direccion.get("ddp_numer1"),
						(String) direccion.get("ddp_inter1"));
			}

		}

		return direccionAnexo;
	}

	/**
	 * Forma direccion.
	 *
	 * @param via
	 *          the via
	 * @param num
	 *          the num
	 * @param inter
	 *          the inter
	 * @return the string
	 */
	private String formaDireccion(String via, String num, String inter)
	{
		if (!inter.trim().equals("-"))
		{
			inter = " - " + inter.trim();
		}
		else
		{
			inter = "";
		}
		return via.trim() + " " + num.trim() + inter;
	}

	/**
	 * GRG realiza el proceso de validacion de la declaracion para el proceso de
	 * rechazo para nuevo env�o.
	 *
	 * @param params
	 *          the params
	 * @return Map<String, Object>
	 * @throws ServiceException
	 *           the service exception
	 */

	public Map<String, Object> validarDeclaParaRechazo(Map<String, Object> params) throws ServiceException
	{
		// valida que la declaracion tenga solicitud de rectificacion
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		Map<String, Object> parametros = new HashMap<String, Object>();

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
				+ params.get("caduana").toString().trim()));

		try
		{
			// busca que la declaracion exista
			String num_corredoc = "";
			List<Map<String, Object>> listDocSolicitud = null;
			try
			{
				num_corredoc = getNumCorreDocDeclaracion(params);
				listDocSolicitud = getSolicitudElectronica(num_corredoc);
			}
			catch (ServiceException e)
			{
				mapaRespuesta.put("ERROR", e.getMessage());
				return mapaRespuesta;
			}

			String tempEstaRecti = "";
			String strNumCorreDocSolicitud = "";
			// buscamos la solicitudes que esten en estado pendiente de evaluacion o estado asignado - pendiente de evaluacion / on
			// proceso de evaluacion
			for (Map<String, Object> map : listDocSolicitud)
			{
				tempEstaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
				strNumCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
				if (ArrayUtils.contains(new String[]
						//mordonezl pase 040
						{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION, Constantes.COD_ESTADO_RECTIFICACION_ASIGNADO }, tempEstaRecti))
				{
					strNumCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
					break;
				}
			}

			mapaRespuesta.put("NUM_CORREDOC_PRE", num_corredoc);
			mapaRespuesta.put("NUM_CORREDOC", strNumCorreDocSolicitud);

			parametros.put("NUM_CORREDOC", strNumCorreDocSolicitud);
			Map<String, Object> mapaCabSolRecti = this.cabSolRectiDAO.findByDocumento(parametros); // NUM_CORREDOC_PRE

			if(MapUtils.esMapaNuloOVacio(mapaCabSolRecti))
			{
				mapaRespuesta.put("ERROR", "No existe solicitud de rectificacion para la Declaraci�n.");
				return mapaRespuesta;
			}
			// Verifica que la declaracion tenga solicitud de de rectificacion
			// electronica pendiente de evaluar
			// verifico que el estado debe estar en 02 o 04

			String codEstaRecti = MapUtils.getMapValor(mapaCabSolRecti, "COD_ESTARECTI");
			mapaRespuesta.put("COD_ESTARECTI", codEstaRecti);
			if (!ArrayUtils.contains(new String[]
					//mordonezl pase 040
					{ Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION , Constantes.COD_ESTADO_RECTIFICACION_ASIGNADO }, codEstaRecti))
			{
				mapaRespuesta.put(
						"ERROR",
						"La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica pendiente de evaluar");
				return mapaRespuesta;
			}
			//
			Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(params);

			String codCanal = mapCabDeclara.get("COD_CANAL").toString();
			/* PAS20145E220000399 INICIO GGRANADOS */
			//      String fechaRecepcion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapCabDeclara.get("FEC_RECEP"));      
			//      String fechaAutorizacioLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapCabDeclara.get("FEC_AUTLEVANTE"));      
			//      boolean tieneAutorizacionLevante = !fechaAutorizacioLevante.equals(Constantes.DEFAULT_FECHA_BD);
			/* PAS20145E220000399 INICIO GGRANADOS */

			String cod_funcionario_portal = params.get("USERSESSION").toString().trim();
			String codEstDua = mapCabDeclara.get("COD_ESTDUA").toString();

			try
			{

				//  	boolean tieneMedidaPreventiva = tieneMedidaPreventivaDua(mapCabDeclara.get("COD_ADUANA").toString(), mapCabDeclara.get("COD_REGIMEN").toString(), new Long(mapCabDeclara.get("NUM_DECLARACION").toString()),new Long(mapCabDeclara.get("ANN_PRESEN").toString()));
				//  	 log.debug("medida preventiva es" + tieneMedidaPreventiva );
				if(codCanal != null){
					// Validacion canal D,F con fecha de recepcion y con fecha de
					// autorizacion de levante


					/* validaTieneAsignadoFuncionario(num_corredoc, fechaRecepcion,
            tieneAutorizacionLevante, cod_funcionario_portal,
    	            codCanal.trim(),codEstDua);
					 */
					Boolean tienePerfilJefeDeArea = false;
					Boolean tienePerfilJefeGAR = false;//gmontoya Pase 42 2015
					String codigoRegistroFuncionario = params.get("USERSESSION").toString().trim();
					String codPersonalJefeArea = params.get("COD_PERS_JEFEAREA").toString().trim();
					if (codigoRegistroFuncionario.equals(codPersonalJefeArea)) {
						tienePerfilJefeDeArea = true;
					}
					Map mapRoles = (Map)params.get("roles");
					if(mapRoles != null && (mapRoles.containsKey("ADUANA-JEFE-OPERATIVO") || mapRoles.containsKey("ADUANA.ESPECIALISTA.JEFE"))){
						tienePerfilJefeGAR = true;
					}	
					if (!tienePerfilJefeDeArea && !tienePerfilJefeGAR) {	
						//Lmvr- inicio - Complemento de rectificacion
						validaTieneAsignadoFuncionarioSolRectificacion(strNumCorreDocSolicitud, cod_funcionario_portal,
								codCanal.trim(),codEstDua,num_corredoc);	

						//Lmvr- fin - Complemento de rectificacion
						log.info("cod_funcionario_portal" + cod_funcionario_portal + " quien rechaza no tienePerfilJefeDeArea y no tienePerfilJefeGAR");
					}
				}

				// se comenta porque ahora lo puede rechazo el grupo GAR
				// Validacion sin fecha de recepcion o ( canal F y D con diligencia) o
				// canal V y sin fecha de autorizacion de levante
				//        validaDisponibilidadEspecialidad(params,
				//            tieneAutorizacionLevante, cod_funcionario_portal,
				//            codCanal.trim());

			}
			catch (ServiceException serException)
			{ log.error("*** ERROR ***",  serException);
			mapaRespuesta.put("ERROR", serException.getMessage());
			return mapaRespuesta;
			}

		}
		catch (Exception e)
		{
			log.error(this.toString() + " validarDeclaParaRechazo - ERROR: " + e);
			throw new ServiceException(this, "Ocurrio un error durante la validacion de la dua");
		}

		return mapaRespuesta;
	}

	/**
	 * GRG realiza el proceso de validacion de la declaracion para el proceso de
	 * recuperar rectificaci�n anulada o rechazada.
	 *
	 * @param params
	 *          the params
	 * @return Map<String, Object>
	 * @throws ServiceException
	 *           the service exception
	 */

	public Map<String, Object> validarDeclaParaRecuperar(Map<String, Object> params) throws ServiceException
	{
		// valida que la declaracion tenga solicitud de rectificacion
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		Map<String, Object> parametros = new HashMap<String, Object>();
		String mensajeError = ""; 
		boolean solicitudesRectificacionPendientes =true;

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
				+ params.get("caduana").toString().trim()));

		try
		{
			String num_corredoc = "";
			List<Map<String, Object>> lstSolicitudesRectificacion = null;
			//PASE 42
			Map<String, Object> solicitudRectificacionAnulada = new HashMap<String,Object>();
			List<Map<String, Object>> lstSolicitudesRectificacionPendientes = new ArrayList<Map<String,Object>>();
			try
			{
				num_corredoc = getNumCorreDocDeclaracion(params);
				lstSolicitudesRectificacion = getSolicitudElectronica(num_corredoc);
			}
			catch (ServiceException e)
			{
				mapaRespuesta.put("ERROR", e.getMessage());
				return mapaRespuesta;
			}

			String tempEstaRecti = "";
			String strNumCorreDocSolicitud = "";
			String strDescripcionEstado = "";
			// buscamos la solicitudes que esten en estado pendiente de evaluacion/ on
			// proceso de evaluacion
			// verficar los codigos en el catalogo 363
			//inicio gmontoya Pase 42 2015
			if(CollectionUtils.isEmpty(lstSolicitudesRectificacion))
			{
				mapaRespuesta.put("ERROR", "No existe solicitud de rectificacion para la Declaraci�n.");
				return mapaRespuesta;
			}

			for (Map<String, Object> map : lstSolicitudesRectificacion) 
			{
				if(map.get("COD_ESTARECTI").equals(Constantes.COD_ANULADO)||map.get("COD_ESTARECTI").equals(Constantes.COD_RECHAZADO)){
					solicitudRectificacionAnulada = map; 
					solicitudesRectificacionPendientes=false;
					break;
				}else{
					lstSolicitudesRectificacionPendientes.add(map);
				}
			}

			if (CollectionUtils.isEmpty(solicitudRectificacionAnulada))  {
				mapaRespuesta.put("ERROR","No existe Solicitud de rectificaci�n con estado anulada o rechazada");
				return mapaRespuesta;
			}


			if(solicitudesRectificacionPendientes) {

				for (Map<String, Object> map : lstSolicitudesRectificacionPendientes)
				{
					tempEstaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
					strNumCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
					//        if (ArrayUtils.contains(new String[]
					//        { Constantes.COD_PENDIENTE_EVALUAR, Constantes.COD_EN_EVALUACION }, tempEstaRecti))
					//        {
					//          mapaRespuesta
					//              .put(
					//                  "ERROR",
					//                    "La declaraci�n tiene otra Solicitud de Rectificaci�n Electr�nica pendiente de evaluar/en proceso de evaluaci�n.");
					//          return mapaRespuesta;
					//        }
					//        if (ArrayUtils.contains(new String[]
					//                { Constantes.COD_ASIG_PENDIENTE_EVALUAR }, tempEstaRecti))
					//                {
					//                  mapaRespuesta
					//                      .put(
					//                          "ERROR",
					//                            "La ultima solicitud de rectificaci�n electr�nica se encuentra asignado pendiente de evaluar.");
					//                  return mapaRespuesta;
					//                }

					if (ArrayUtils.contains(new String[]
							{ Constantes.COD_PROCEDENTE_PARTE, Constantes.COD_PROCEDENTE, Constantes.COD_IMPROCEDENTE }, tempEstaRecti))
					{

						strDescripcionEstado = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_ESTADO_RECTI, tempEstaRecti);
						mapaRespuesta.put( "ERROR","Solicitud no puede ser recuperada, porque ya cuenta con resultado de solicitud de rectificaci�n electr�nica. " + strDescripcionEstado + ".");
						// "La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica anulada o rechazada vigente. DUA cuenta con resultado "
						//lmvr - inicio. Complemento de la Diligencia

						//lmvr - Fin. Complemento de la Diligencia
						//fin gmontoya Pase 42 2015         
						return mapaRespuesta;
					}

					if (ArrayUtils.contains(new String[] { Constantes.COD_ANULADO, Constantes.COD_RECHAZADO }, tempEstaRecti))  {
						strNumCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
						break;
					} else {   //lmvr - Inicio: Complemento de la Diligencia
						strDescripcionEstado = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_ESTADO_RECTI, tempEstaRecti);
						mapaRespuesta.put("ERROR","Solicitud de rectificaci�n no se encuentra con estado de anulada o rechazada. Declaracion cuenta  con resultado "+ strDescripcionEstado + ".");
						return mapaRespuesta;
					}
				}
			}  

			params.put("NUM_CORREDOC_SOLICITUD", MapUtils.getMapValor(solicitudRectificacionAnulada, "NUM_CORREDOC"));//gmontoya pase 42

			Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(params);
			String codCanal = mapCabDeclara.get("COD_CANAL").toString();

			params.put("COD_CANAL", codCanal);
			params.put("COD_ESTDUA", mapCabDeclara.get("COD_ESTDUA").toString());
			params.put("FEC_RECEP", mapCabDeclara.get("FEC_RECEP"));

			List<Map<String, Object>> list = validarFuncionarioAduaneroDeclaracion(params);
			if (list.size()>0) {
				// mensajeError = list.toString();
				mensajeError = list.get(0).get("ERROR").toString();
				//throw new ServiceException(this, mensajeError);
				mapaRespuesta.put("ERROR", mensajeError);
				return mapaRespuesta;
			}

			List<Map<String, Object>> listFecha = validarFechaSolicitudRectificacion(params);
			if (listFecha.size()>0) {

				//for (int i = 0; i < listFecha.size(); i++) { 
				mensajeError = listFecha.get(0).get("ERROR").toString();
				//}
				// mensajeError = listFecha.toString();
				//throw new ServiceException(this, mensajeError);
				mapaRespuesta.put("ERROR", mensajeError);
				return mapaRespuesta;
			}
			/*lmvr - Fin: Complemento de la Diligencia */

			//inicio gmontoya Pase 42 2015
			mapaRespuesta.put("NUM_CORREDOC_PRE", num_corredoc);
			mapaRespuesta.put("NUM_CORREDOC", MapUtils.getMapValor(solicitudRectificacionAnulada, "NUM_CORREDOC"));

			//      parametros.put("NUM_CORREDOC", strNumCorreDocSolicitud);
			//
			//      Map<String, Object> mapaCabSolRecti = this.cabSolRectiDAO.findByDocumento(parametros);
			//
			//      if(MapUtils.esMapaNuloOVacio(mapaCabSolRecti))
			//      {
			//        mapaRespuesta.put("ERROR", "No existe solicitud de rectificacion para la Declaraci�n.");
			//        return mapaRespuesta;
			//      }
			//
			//      // verifico que el estado debe estar en 08 o 09
			//      String codEstaRecti = MapUtils.getMapValor(mapaCabSolRecti, "COD_ESTARECTI");
			//      mapaRespuesta.put("COD_ESTARECTI", codEstaRecti);
			//      if (!ArrayUtils.contains(new String[]
			//      { Constantes.COD_ANULADO, Constantes.COD_RECHAZADO }, codEstaRecti))
			//      {
			//        mapaRespuesta.put(
			//            "ERROR",
			//              "La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica anulada o rechazada vigente.");
			//        return mapaRespuesta;
			//      }
			//  Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(params);

			//      String fechaAutorizacioLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy)
			//          .format(mapCabDeclara.get("FEC_AUTLEVANTE"));
			//      boolean tieneAutorizacionLevante = !fechaAutorizacioLevante.equals(Constantes.DEFAULT_FECHA_BD);
			//
			//     // String codCanal = mapCabDeclara.get("COD_CANAL").toString();
			//      String fechaRecepcion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapCabDeclara.get("FEC_RECEP"));
			//      //Date fechaRecepcion = (Date) mapCabDeclara.get("FEC_RECEP");
			//
			//      String cod_funcionario_portal = params.get("USERSESSION").toString().trim();
			//      String codEstDua = mapCabDeclara.get("COD_ESTDUA").toString();
			//
			//      // Validacion canal D,F con fecha de recepcion y con fecha de autorizacion de levante
			//      try
			//      {
			//    	  
			//    	  String aduana = mapCabDeclara.get("COD_ADUANA").toString();
			//    	  String regimen = mapCabDeclara.get("COD_REGIMEN").toString();
			//    	  Long numdeclaracion = new Long(mapCabDeclara.get("NUM_DECLARACION").toString());
			//    	  Long annprese = new Long(mapCabDeclara.get("ANN_PRESEN").toString());    	  
			//      	 boolean tieneMedidaPreventiva = tieneMedidaPreventivaDua(aduana,regimen ,numdeclaracion,annprese);
			//      	//if(log.isDebugEnabled()) 
			//        log.debug("medida preventiva es" + tieneMedidaPreventiva );
			//      	if(codCanal != null && !tieneMedidaPreventiva){
			//      		 // Validacion canal D,F con fecha de recepcion y con fecha de autorizacion de levante
			//        validaTieneAsignadoFuncionario(num_corredoc, fechaRecepcion,
			//            tieneAutorizacionLevante, cod_funcionario_portal,
			//      	            codCanal.trim(),codEstDua);
			//      	}
			//        // Validacion sin fecha de recepcion o ( canal F y D con diligencia) o
			//        // canal V y sin fecha de autorizacion de levante
			////        validaDisponibilidadEspecialidad(params,
			////            tieneAutorizacionLevante, cod_funcionario_portal,
			////            codCanal.trim());
			//      }
			//      catch (ServiceException serException)
			//      {
			//        mapaRespuesta.put("ERROR", serException.getMessage());
			//        return mapaRespuesta;
			//      }
			//fin gmontoya Pase 42 2015
		}
		catch (Exception e)
		{
			log.error(this.toString() + " validarDeclaParaRecuperar - ERROR: " + e);
			throw new ServiceException(this, "Ocurrio un error durante la validacion de la dua");
		}
		return mapaRespuesta;
	}




	/*  
	 *   lmvr - Inicio: Complemento de la Diligencia
	 *   Valida que la declaraci�n se encuentra asignada al funcionario aduanero que realizara la 
	 *   recuperaci�n y que �ste haya tenido asignada a la Solicitud anteriormente
	 */
	public List<Map<String, Object>> validarFuncionarioAduaneroDeclaracion(
			Map<String, Object> params) throws Exception {

		List<Map<String, Object>> mapaRespuesta = new ArrayList<Map<String, Object>>();
		Map<String, Object> error = new HashMap<String, Object>();
		String num_corredoc = "";
		/* PAS20145E220000399 INICIO GGRANADOS */
		//		List<Map<String, Object>> lstSolicitudesRectificacion = new ArrayList<Map<String, Object>>();
		/* PAS20145E220000399 FIN GGRANADOS */
		try {

			try {
				num_corredoc = getNumCorreDocDeclaracion(params);
				/* PAS20145E220000399 INICIO GGRANADOS */
				//				lstSolicitudesRectificacion = getSolicitudElectronica(num_corredoc);
				/* PAS20145E220000399 FIN GGRANADOS */
			} catch (ServiceException e) {
				error.put("ERROR", e.getMessage());
				mapaRespuesta.add(error);
				return mapaRespuesta;
			}

			FechaBean FECHA_DEFAULT = new FechaBean("01/01/0001");

			Date fechaSolicitudRectificacion = FECHA_DEFAULT.getTimestamp();
			Date fechaDiligencia = FECHA_DEFAULT.getTimestamp();
			Date fechaGEDSERF = FECHA_DEFAULT.getTimestamp();
			String fechaStringGEDSERF = null;
			Boolean tienePerfilJefeDeArea = false;
			Boolean tienePerfilJefeGAR = false;//gmontoya Pase 42 2015
			//Date fechaDefault = SunatDateUtils.getDefaultDate();


			Long strNumCorreDocSolicitud = new Long(params.get("NUM_CORREDOC_SOLICITUD").toString());

			//String codigoAreaFuncionario = params.get("USERCodUO").toString().trim();
			String codigoRegistroFuncionario = params.get("USERSESSION").toString().trim();
			String codPersonalJefeArea = params.get("COD_PERS_JEFEAREA").toString().trim();
			String codCanalDUA = params.get("COD_CANAL").toString();
			if (codigoRegistroFuncionario.equals(codPersonalJefeArea)) {
				tienePerfilJefeDeArea = true;
			}

			/* PAS20145E220000399 INICIO GGRANADOS */
			//			Boolean esCanalRojoNaranja = false;			
			//			String[] stringRojoNaranja = new String[] { Constantes.CANAL_ROJO, Constantes.CANAL_NARANJA }; // Usar las constantes definidas para los tipos de aforo.
			//			if (SunatStringUtils.include(codCanalDUA, stringRojoNaranja)) {
			//				esCanalRojoNaranja = true;
			//			}
			/* PAS20145E220000399 FIN GGRANADOS */

			Map parametrosPerfil = new HashMap();
			AsignacionManualService asignacionManualService = fabricaDeServicios.getService("Asignacion.asignacionManualService");
			EspecialistaService especialistaService = fabricaDeServicios.getService("Asignacion.especialistaService");
			SolicitudElectronicaReconocimientoFisicoService solicitudElectronicaReconocimientoFisicoService = fabricaDeServicios.getService("sigad.diligencia.solicitudElectronicaReconocimientoFisicoService");
			//inicio gmontoya Pase 42 2015
			Map parametros = new HashMap();
			parametros.put("declaracion", params.get("NUM_DECLARACION"));
			parametros.put("cod_aduana", params.get("COD_ADUANA"));

			Map mapRoles = (Map)params.get("roles");

			if(mapRoles != null && (mapRoles.containsKey("ADUANA-JEFE-OPERATIVO") || mapRoles.containsKey("ADUANA.ESPECIALISTA.JEFE"))){
				tienePerfilJefeGAR = true;
			}

			if (!tienePerfilJefeDeArea && !tienePerfilJefeGAR) {
				Long numCorreDocDUA = new Long(num_corredoc); // Num_corredoc de la declaracion

				//List<Map<String, Object>> datosSolicitudRectificacion = this.solicitudService.buscarRectiyReguPend(numCorreDocDUA);
				Map parametrosRectiAnuladas = new HashMap();
				parametrosRectiAnuladas.put("NUM_CORREDOC",numCorreDocDUA);
				parametrosRectiAnuladas.put("COD_TIPSOL","01");
				parametrosRectiAnuladas.put("listaEstados",new String[]{"08","09"});

				List<Map<String, Object>> datosSolicitudRectificacion = cabSolRectiDAO.getLstRegistrosAnuladosYAgregados(parametrosRectiAnuladas);
				//fechaSolicitudRectificacion = new Date(new SimpleDateFormat("dd/MM/yyyy").format(datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD")));
				if (datosSolicitudRectificacion.size()>0) {
					fechaSolicitudRectificacion =  (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");	
				}
				//fin gmontoya Pase 42 2015

				Map parametroReconFisico = new HashMap();
				parametroReconFisico.put("NUME_CORRE",params.get("NUM_DECLARACION"));
				parametroReconFisico.put("CODI_ADUAN", params.get("COD_ADUANA"));
				parametroReconFisico.put("ANO_PRESE", params.get("ANN_PRESEN"));
				parametroReconFisico.put("CODI_REGI", params.get("COD_REGIMEN"));

				if (codCanalDUA.equals("F")) {
					List<Map<String, Object>> listado = solicitudElectronicaReconocimientoFisicoService.listarSolicitudes(parametroReconFisico);
					//fechaGEDSERF = new Date(new SimpleDateFormat("dd/MM/yyyy").format(listado.get(0).get("FECH_ENVIO_CONFIR")));
					if (listado.size()>0){
						// se corrige por el SAU20153D211000428
						fechaStringGEDSERF =  SunatStringUtils.toStringObj(listado.get(0).get("FECH_ENVIO_CONFIR")) ;
						if (!"0".equals(fechaStringGEDSERF) && fechaStringGEDSERF.trim().length() == 8) {
							FechaBean fechaGEDSERFBean = new FechaBean(fechaStringGEDSERF.trim(),"yyyyMMdd");
							fechaGEDSERF = fechaGEDSERFBean.getTimestamp();
						}
					}
					parametrosPerfil.put("COD_TIPDILIGENCIA", Constantes.DILIG_REC_FISICO);
				} else if (codCanalDUA.equals("D")) {
					//fechaGEDSERF = new Date(new SimpleDateFormat("dd/MM/yyyy").format(params.get("FEC_RECEP")));
					fechaGEDSERF = (Date) params.get("FEC_RECEP"); 
					parametrosPerfil.put("COD_TIPDILIGENCIA", Constantes.DILIG_REV_DOCUMENTARIA);
				}

				parametrosPerfil.put("NUM_CORREDOC", num_corredoc); // Num_corredoc de la declaracion

				List<Map<String, Object>> listDiligencia = cabDiligenciaDAO.select(parametrosPerfil);

				if (!CollectionUtils.isEmpty(listDiligencia)) {
					//fechaDiligencia = new Date(new SimpleDateFormat("dd/MM/yyyy").format(listDiligencia.get(0).get("FEC_DILIGENCIA")));
					fechaDiligencia =  (Date) listDiligencia.get(0).get("FEC_DILIGENCIA");
				}

				boolean enProcesoConclusion = false;
				String stringProcesoConclusion[] = new String[] { 
						Constantes.ESTADO_CONCLU_ASIGNADA,
						Constantes.ESTADO_CONCLU_REVISION,
						Constantes.ESTADO_DILIG_PROCESO,
						Constantes.ESTADO_CONCLU_NOTIFICADO }; 

				if (SunatStringUtils.include(params.get("COD_ESTDUA").toString(), stringProcesoConclusion)) {
					enProcesoConclusion = true;
				}
				//inicio gmontoya Pase 42 2015
				String aduana = params.get("COD_ADUANA").toString();
				String regimen = params.get("COD_REGIMEN").toString();
				Long numdeclaracion = new Long(params.get("NUM_DECLARACION").toString());
				Long annprese = new Long(params.get("ANN_PRESEN").toString());    	  
				boolean tieneMedidaPreventiva = tieneMedidaPreventivaDua(aduana,regimen ,numdeclaracion,annprese);  

				if ((SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRectificacion, fechaGEDSERF, SunatDateUtils.COMPARA_TODO) 
						//&& ((SunatDateUtils.esFecha1MayorQueFecha2(fechaDiligencia,fechaSolicitudRectificacion,SunatDateUtils.COMPARA_SOLO_FECHA) || fechaDiligencia.equals(FECHA_DEFAULT)) && (codCanalDUA.equals("D")|| codCanalDUA.equals("F"))))
						&& ((SunatDateUtils.sonIguales(fechaDiligencia, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)) && (codCanalDUA.equals("D")|| codCanalDUA.equals("F"))))
						|| enProcesoConclusion) {
					// Valido declaraci�n se encuentra asignado especialista que realiza la recuperaci�n
					FiltroEspeDocu filtro = new FiltroEspeDocu(); 
					filtro.setNumCorreDoc(numCorreDocDUA); // NUM_CORREDOC de la declaracion.
					filtro.setCodPers(codigoRegistroFuncionario);
					filtro.setCodEstRev("06"); // Estado de la asignaci�n del especialista a la declaraci�n. Ver catalogo DATACATALOGO, tipo COD_CATALOGO = 355.

					List<EspeDocu> listado = asignacionManualService.buscarEspeDocu(filtro);
					if (listado == null || listado.size() == 0) {
						error.clear();
						error.put("ERROR","Funcionario aduanero no tiene asignada la Declaraci�n.");
						mapaRespuesta.add(error);
						return mapaRespuesta;
					}

				}
				//fin gmontoya Pase 42 2015
				if (SunatDateUtils.esFecha1MayorQueFecha2(fechaGEDSERF,fechaSolicitudRectificacion,SunatDateUtils.COMPARA_SOLO_FECHA)
						|| ((SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRectificacion, fechaDiligencia,SunatDateUtils.COMPARA_SOLO_FECHA)) && (codCanalDUA.equals("D")|| codCanalDUA.equals("F")) && !fechaDiligencia.equals(FECHA_DEFAULT))
						|| (codCanalDUA.equals("V")|| (codCanalDUA.isEmpty()) && tieneMedidaPreventiva)) {

					FiltroEspeDispo filtro = new FiltroEspeDispo();
					filtro.setCodGrupoTrabajo("GAR");
					filtro.setCodPers(codigoRegistroFuncionario);
					filtro.setIndicadorSoloVigente(1);
					List<EspeDispo> listado = especialistaService.buscarEspeDispo(filtro);
					if (listado == null || listado.size() == 0) {
						error.clear();
						error.put("ERROR","Funcionario aduanero no se encuentra dentro del Grupo GAR.");
						mapaRespuesta.add(error);
						return mapaRespuesta;
					}
					//inicio gmontoya Pase 42 2015
					FiltroEspeDocu filtroDocu = new FiltroEspeDocu();
					filtroDocu.setNumCorreDoc(strNumCorreDocSolicitud); // NUM_CORREDOC de la rectificaci�n.
					filtroDocu.setCodPers(codigoRegistroFuncionario);
					//filtroDocu.setCodEstRev("06"); // Estado de la asignaci�n del especialista a la declaraci�n. Ver catalogo DATACATALOGO, tipo COD_CATALOGO = 355.
					filtroDocu.setIndicadorUltimoRegistro(1);

					EspeDocu listadoDocu = asignacionManualService.consultarEspeDocuSolRect(filtroDocu);
					if (listadoDocu == null ) {
						error.clear();
						error.put("ERROR","Funcionario aduanero no tuvo asignada anteriormente  la Solicitud.");
						mapaRespuesta.add(error);
						return mapaRespuesta;
					}
					//fin gmontoya Pase 42 2015
					//					listado = especialistaService.buscarFuncionarioAduaneroAsignadaSolicitud(filtro);
				}

			}

		} catch (Exception e) {
			log.error(this.toString() + " validarFuncionarioAduaneroDeclaracion - ERROR: "
					+ e.getStackTrace());
			throw new ServiceException(this,
					"Ocurrio un error durante la validarFuncionarioAduaneroDeclaracion");
		}

		return mapaRespuesta;
	}

	// lmvr - Fin: Complemento de la Diligencia



	/*lmvr - Inicio: Complemento de la Diligencia
	 * Valida si con fecha posterior de la transmisi�n de solicitud, se ha realizado otro proceso sobre la 
	 * declaraci�n para modificar o no datos, siendo otro proceso cualquiera de los siguientes: 
	 * Diligencia de Despacho, Diligencia de Regularizaci�n, Transmisi�n de Regularizaci�n de Despacho Anticipado, 
	 * Diligencia de Conclusi�n, Diligencia de Rectificaci�n de Oficio 
	 */

	public List<Map<String, Object>> validarFechaSolicitudRectificacion (
			Map<String, Object> params) throws Exception {

		List<Map<String, Object>> mapaRespuesta = new ArrayList<Map<String, Object>>();
		Map<String, Object> error = new HashMap<String, Object>();
		String num_corredoc = "";
		/* PAS20145E220000399 INICIO GGRANADOS */
		//		List<Map<String, Object>> lstSolicitudesRectificacion = new ArrayList<Map<String, Object>>();
		/* PAS20145E220000399 FIN GGRANADOS */
		FechaBean FECHA_DEFAULT = new FechaBean("01/01/0001"); 

		Date fechaSolicitudRectificacion = FECHA_DEFAULT.getTimestamp();
		Date fechaSolicitudRegularizacion = FECHA_DEFAULT.getTimestamp();
		try {

			try {
				num_corredoc = getNumCorreDocDeclaracion(params);
				/* PAS20145E220000399 INICIO GGRANADOS */
				//				lstSolicitudesRectificacion = getSolicitudElectronica(num_corredoc);
				/* PAS20145E220000399 FIN GGRANADOS */
			} catch (ServiceException e) {
				error.put("ERROR", e.getMessage());
				mapaRespuesta.add(error);
				return mapaRespuesta;
			}

			Long numCorreDocDUA = new Long(num_corredoc); // Num_corredoc de la declaracion
			//inicio gmontoya Pase 42 2015
			//			List<Map<String, Object>> datosSolicitudRectificacion = this.solicitudService.buscarRectiyReguPend(numCorreDocDUA);
			Map parametrosRectiAnuladas = new HashMap();
			parametrosRectiAnuladas.put("NUM_CORREDOC",numCorreDocDUA);
			parametrosRectiAnuladas.put("COD_TIPSOL","01");
			parametrosRectiAnuladas.put("listaEstados",new String[]{"08","09"});

			List<Map<String, Object>> datosSolicitudRectificacion = cabSolRectiDAO.getLstRegistrosAnuladosYAgregados(parametrosRectiAnuladas);
			//Date fechaSolicitudRectificacion = new Date(new SimpleDateFormat("dd/MM/yyyy").format(datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD")));
			//fin gmontoya Pase 42 2015
			if (datosSolicitudRectificacion.size()>0) {
				fechaSolicitudRectificacion = (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");	
			}


			Map parametrosDiligencia = new HashMap();
			parametrosDiligencia.put("COD_TIPDILIGENCIA_IN", new String[] {"02", "03", "05", "07", "10","06" });   

			parametrosDiligencia.put("NUM_CORREDOC", num_corredoc);
			List<Map<String, Object>> listadoDiligencias = cabDiligenciaDAO.select(parametrosDiligencia); // Necesita los par�metros NUM_CORREDOC y
			// COD_TIPDILIGENCIA_IN.
			for (int i = 0; i < listadoDiligencias.size(); i++) { 
				Map<String, Object> datosDiligencia = listadoDiligencias.get(i);
				//Date fechDiligencia = new Date(new SimpleDateFormat("dd/MM/yyyy").format(datosDiligencia.get("FEC_DILIGENCIA")));
				Date fechDiligencia = (Date) datosDiligencia.get("FEC_DILIGENCIA");

				if (SunatDateUtils.esFecha1MayorQueFecha2(fechDiligencia,fechaSolicitudRectificacion,SunatDateUtils.COMPARA_TODO)) {
					error.put("ERROR","Solicitud no puede ser recuperada, porque se modific� la declaraci�n con fecha posterior a la transmisi�n de la solicitud.");
					mapaRespuesta.add(error);
					return mapaRespuesta;
				}
				//break;
			}
			//PAS20171U220200004 INICIO
			Map parametrosRegularizacion = new HashMap();
			parametrosRegularizacion.put("NUM_CORREDOC",numCorreDocDUA);
			parametrosRegularizacion.put("COD_TIPSOL","11");
			parametrosRegularizacion.put("listaEstados",new String[]{"02"});

			List<Map<String, Object>> datosSolicitudRegularizacion = cabSolRectiDAO.getLstRegistrosAnuladosYAgregados(parametrosRegularizacion);

			if (datosSolicitudRegularizacion.size()>0) {
				fechaSolicitudRegularizacion = (Date) datosSolicitudRegularizacion.get(0).get("FEC_SOLICITUD");	
			
				if (SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRegularizacion,fechaSolicitudRectificacion,SunatDateUtils.COMPARA_TODO)) {
				error.put("ERROR", "Solicitud no puede ser recuperada, porque se modific� la declaraci�n con fecha posterior a la transmisi�n de la solicitud.");
				mapaRespuesta.add(error);
				return mapaRespuesta;
			}

			}			

//			Map parametrosAnticipada = new HashMap();
//			parametrosAnticipada.put("NUM_CORREDOC_PRE", num_corredoc);
//			parametrosAnticipada.put("COD_TRANSACCION", "1004");
//			parametrosAnticipada.put("COD_ESTADO", "1");
//
//			List listadoRegularizacionesAnticipadas = relacionDocDAO.buscarTransmisionesSolicitudesPorDeclaracion(parametrosAnticipada);
//			if (listadoRegularizacionesAnticipadas.size() > 0) {
//				error.put("ERROR", "Solicitud no puede ser recuperada, porque se modific� la declaraci�n con fecha posterior a la transmisi�n de la solicitud.");
//				mapaRespuesta.add(error);
//				return mapaRespuesta;
//			} PAS20171U220200004 FIN

		} catch (Exception e) {
			log.error(this.toString() + " validarFechaSolicitudRectifciacion - ERROR: "
					+ e.getMessage());
			throw new ServiceException(this,
					"Ocurrio un error durante la validarFechaSolicitudRectifciacion");
		}

		return mapaRespuesta;
	}
	//lmvr - Fin: Complemento de la Diligencia

	/*lmvr - inicio: Complemento de la Diligencia
	 * Se valida que si la declaraci�n es un Despacho Anticipado, seleccionada a canal de control VERDE se verifica lo siguiente [R1495]:
	 * 1.1.	Que la declaraci�n cuente con Garant�a del art�culo 160�, previa a la numeraci�n.
	 * 1.2.	Que la Solicitud de rectificaci�n se haya transmitido dentro del plazo de quince (15) d�as calendario, siguientes a la fecha del t�rmino de la descarga.
	 * 1.3.	Que la declaraci�n no cuente con medida preventiva (Acta de Inmovilizaci�n o de Incautaci�n), o si cuenta con ella, debe estar concluida o anulada.
 Si se cumple con las validaciones indicadas se visualizara el mensaje emergente "La rectificaci�n de esta declaraci�n NO SE ENCU
	 */
	@Override
	public List<Map<String, Object>> validarDeclaracionAnticipadaCanalVerde(Map<String, Object> mapCabDeclara) {

		List<Map<String, Object>> mapaRespuesta = new ArrayList<Map<String, Object>>();
		Map<String, Object> mensajeAlerta = new HashMap<String, Object>();

		if( Constants.DESPACHO_ANTICIPADO.equals(mapCabDeclara.get("COD_MODALIDAD")) ) {
			// Realizar las validaciones del punto (1).
			boolean CambioLGAVigente = false;
			Date fecVigenciaCambiosLGA = (Date) catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN, ConstantesDataCatalogo.COD_PLAZO_VALIDACION_NUEVA_LGA).get("fec_inidatcat");
			Date fecDeclaracion = (Date) mapCabDeclara.get("FEC_DECLARACION");
			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecDeclaracion, fecVigenciaCambiosLGA, SunatDateUtils.COMPARA_SOLO_FECHA)) {
				CambioLGAVigente = true;
			}
			boolean tieneSolicitudDentroDelPlazo = false;
			boolean tieneMedidaPreventiva = false;
			boolean tieneGarantia160 = false;
			boolean tieneLevante = false;

			if( CambioLGAVigente ) {
				tieneGarantia160 = true;
				if ( !mapCabDeclara.get("COD_CANAL").equals(" ") ) {  //Tiene Canal asignado
					Date fecLevante = (Date) mapCabDeclara.get("FEC_AUTLEVANTE");
					tieneLevante = !SunatDateUtils.sonIguales(fecLevante, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA);
				}
			}
			else { //No est�n vigentes los cambios del D.S.1235
				if (ConstantesDataCatalogo.COD_CANAL_VERDE.equals(mapCabDeclara.get("COD_CANAL"))) {
					tieneLevante = true;
			Map parametroGaran = new HashMap();
			parametroGaran.put("CODNUMAFECTA", SunatStringUtils.lpad(mapCabDeclara.get("NUM_DECLARACION").toString(), 6, '0') );
			parametroGaran.put("CODADUAFECTA", mapCabDeclara.get("COD_ADUANA"));
			parametroGaran.put("ANNANOAFECTA", mapCabDeclara.get("ANN_PRESEN"));
			parametroGaran.put("CODREGIAFECTA", mapCabDeclara.get("COD_REGIMEN"));

			// RPH Diligencia de Rectificacion
			ConsultaCtaCteService consultaCtaCteService = fabricaDeServicios.getService("diligencia.ingreso.consultaCtaCteService"); // "consultaCtaCteService","diligencia.ingreso.consultaCtaCteService" 
					List<Map<String, Object>> datosAfectacionGarantiaDUA = consultaCtaCteService.buscarDocumentoGarantizado(parametroGaran);
					if (datosAfectacionGarantiaDUA.size() > 0) {
						tieneGarantia160 = true;
					}			
				}
			}
			ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
			AceValidacionesService aceValidacionesService = fabricaDeServicios.getService("prevcontrabando2.ace.AceValidacionesService");

			Long numCorreDocDUA = new Long(mapCabDeclara.get("NUM_CORREDOC").toString());

			List<Map<String, Object>> datosSolicitudRectificacion = solicitudService.buscarRectiyReguPend(numCorreDocDUA);
			//Date fechaSolicitudRectificacion = new Date(new SimpleDateFormat("dd/MM/yyyy").format(datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD")));
			Date fechaSolicitudRectificacion =  (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");

			String codigoViaTransporte = (String) mapCabDeclara.get("COD_VIATRANS");
			String numeroManifiesto = (String) mapCabDeclara.get("NUM_MANIFIESTO");
			BigDecimal anioManifiestoBigDecimal = (BigDecimal) mapCabDeclara.get("ANN_MANIFIESTO");
			Integer anioManifiesto = new Integer(anioManifiestoBigDecimal.intValue());
			String codigoTipoManifiesto = (mapCabDeclara.get("COD_TIPMANIFESTO")!=null?mapCabDeclara.get("COD_TIPMANIFESTO").toString():"01");
			String codigoAduana = (String) mapCabDeclara.get("COD_ADUAMANIFIESTO");						

			Manifiesto datosManifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codigoTipoManifiesto,
					codigoViaTransporte, codigoAduana, anioManifiesto,numeroManifiesto);
			if (datosManifiesto!=null) {
				Date fechaTerminoDescarga = datosManifiesto.getFechaTerminoDeDescarga();
				if (fechaTerminoDescarga!=null) {
					Date fechaTerminoDescargaAdicional = SunatDateUtils.addDay(fechaTerminoDescarga, 15);
					if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaTerminoDescargaAdicional, fechaSolicitudRectificacion, SunatDateUtils.COMPARA_SOLO_FECHA)) {
						tieneSolicitudDentroDelPlazo = true;
					}
				}
			}

			Map parametroActaInmo = new HashMap();
			parametroActaInmo.put("num_dua", SunatStringUtils.lpad(mapCabDeclara.get("NUM_DECLARACION").toString(), 6, '0'));
			parametroActaInmo.put("cod_aduana", mapCabDeclara.get("COD_ADUANA"));
			parametroActaInmo.put("ann_dua", mapCabDeclara.get("ANN_PRESEN"));
			parametroActaInmo.put("cod_regimen", mapCabDeclara.get("COD_REGIMEN"));

			String cActaInmovilizacionIncautacion = new String("0300"); 
			parametroActaInmo.put("CTIPO_ACTA", cActaInmovilizacionIncautacion);

			String[] cTipoActa = new String[] { "AC", "AM" };
			parametroActaInmo.put("CTIPO_ACTA_IN", cTipoActa);

			String[] cEstadoNotIn = new String[] { "09", "10", "11", "12", "13", "14", "15", "16", "17", "20", "25", "29", "33", "36",
					"37", "41", "42", "46", "47", "65", "99" };
			parametroActaInmo.put("CESTADO_ACTA_NOT_IN", cEstadoNotIn);

			List<Map<String, Object>> listMedidaPreventiva = aceValidacionesService.listarActasByDeclaracion(parametroActaInmo);
			if (listMedidaPreventiva.size() > 0) {
				tieneMedidaPreventiva = true;
			}

			if (tieneGarantia160 && tieneSolicitudDentroDelPlazo && !tieneMedidaPreventiva && tieneLevante ) {
				mensajeAlerta.put("ERROR","La rectificaci�n de esta declaraci�n NO SE ENCUENTRA SUJETA A SANCI�N ALGUNA, conforme a lo previsto en el art�culo 136� de la Ley General de Aduanas.");
				mapaRespuesta.add(mensajeAlerta);
			}
		}
		return mapaRespuesta;
	}
	//lmvr - Fin: Complemento de la Diligencia


	//Lmvr- inicio - Complemento de rectificacion
	public List<Map<String, Object>> validarSolicitudRectificacionUltimoExpediente(Map<String, Object> mapCabDeclara) {

		List<Map<String, Object>> mapaRespuesta = new ArrayList<Map<String, Object>>();
		//Map<String, Object> error = new HashMap<String, Object>();
		//Map<String, Object> data = new HashMap<String, Object>();	
		//boolean mostrarUltimoExpediente = false;
		//boolean tieneExpedienteAsociadoRUCRectificacion  = false;



		Map parametroExpedi = new HashMap();
		parametroExpedi.put("NUM_DECLARACION", mapCabDeclara.get("NUM_DECLARACION"));
		parametroExpedi.put("COD_ADUANA", mapCabDeclara.get("COD_ADUANA"));
		parametroExpedi.put("codi_aduan", mapCabDeclara.get("COD_ADUANA")); // Para el swaper de tramite
		parametroExpedi.put("ANN_PRESEN", mapCabDeclara.get("ANN_PRESEN").toString());
		//pase 42 revisar inicio
		String regimenDeclaracion= mapCabDeclara.get("COD_REGIMEN").toString();
		if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimenDeclaracion)){
			parametroExpedi.put("COD_REGIMEN", "17");
		}else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(regimenDeclaracion)){
			//paramExpedi.setoTipo(32);
			parametroExpedi.put("COD_REGIMEN", "32");
		}else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(regimenDeclaracion)){
			//paramExpedi.setoTipo(7);
			parametroExpedi.put("COD_REGIMEN", "7");
		}else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(regimenDeclaracion)){
			//paramExpedi.setoTipo(40);
			parametroExpedi.put("COD_REGIMEN", "40");
		}

		//parametroExpedi.put("COD_REGIMEN", mapCabDeclara.get("COD_REGIMEN"));
		//fin pase 42 revisar
		Long numCorreDocDUA = new Long(mapCabDeclara.get("NUM_CORREDOC").toString());

		String[] tipoExpediente = new String[] {"1607","3071","3109"};
		parametroExpedi.put("PROCEDIM_IN", tipoExpediente);

		List<Map<String, Object>> datosSolicitudRectificacion  = solicitudService.buscarRectiyReguPend(numCorreDocDUA);

		//PAS20165E220200152-Inicio
		Date fechaSolicitudRectificacion = SunatDateUtils.getDefaultDate();
		if(!CollectionUtils.isEmpty(datosSolicitudRectificacion)) {
		   fechaSolicitudRectificacion = (Date) datosSolicitudRectificacion.get(0).get("FEC_SOLICITUD");
		}
		//PAS20165E220200152-Fin
		
		Date fechaAutLevante = (Date) mapCabDeclara.get("FEC_AUTLEVANTE");

		if (SunatDateUtils.isDefaultDate(fechaAutLevante)) {
			return mapaRespuesta;
		}

		if (SunatDateUtils.esFecha1MayorQueFecha2(fechaSolicitudRectificacion, fechaAutLevante, SunatDateUtils.COMPARA_TODO)) {
			//mostrarUltimoExpediente = true;
			ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");					  
			List<Map<String, Object>> listExpediente = expedienteService.findExpedientesAsociadoDeclaracion(parametroExpedi) ;

			if( listExpediente.size() >0) {
				//pase24 mol
				String asunto = "";
				if(listExpediente.get(0).get("ASUNTO")!=null && !StringUtil.isEmptyBlank((String)listExpediente.get(0).get("ASUNTO")))
					{// quitar comillas dobles por bug mordonez
					asunto = (String)listExpediente.get(0).get("ASUNTO");
					asunto =  asunto.replaceAll("\"", "");
					listExpediente.get(0).put("ASUNTO",asunto) ;
					}
				mapaRespuesta.add((HashMap)listExpediente.get(0));
				/*
				Map parametroParticip = new HashMap();
				ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
				parametroParticip.put("numeroCorrelativo", mapCabDeclara.get("NUM_CORREDOC"));
				parametroParticip.put("codTippartic", new String [] {"41","45"});
				List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
				String[] RucImportadorAgente = new String[listadoParticipante.size()];		
				int i=0;
				for(Participante participante : listadoParticipante) {
					RucImportadorAgente[i] = participante.getNumeroDocumentoIdentidad();
					i++;
				}

				for (Map<String, Object> expediente : listExpediente){
					 if(SunatStringUtils.include(expediente.get("NRODOC").toString().trim(), RucImportadorAgente)) {
					 	 data.put("ultimoExpediente",expediente);
					 	 mapaRespuesta.add(data);
						 return mapaRespuesta;
					}else{
						String rucExpediente = expediente.get("NRODOC").toString();
						String numeroexpediente = expediente.get("CODI_ADUA").toString()+"-"+expediente.get("OFIC_REC").toString()+
												"-"+expediente.get("NROEXPEDI").toString();										
						error.put("ERROR","Numero de RUC " + rucExpediente + " del expediente " + numeroexpediente + " no corresponde al agente de aduana y/o consignatario de la declaraci�n a rectificar");
						mapaRespuesta.add(error);
						return mapaRespuesta;
					}										
				}
			}else{
				error.put("ERROR","No existe expediente de tr�mite documentario asociado a la declaraci�n");
				mapaRespuesta.add(error);
				return mapaRespuesta;*/												
			}
		}

		return mapaRespuesta;
	}

	//Lmvr- fin - Complemento de rectificacion	

	/*
  public void setAsignacionManualService(
		AsignacionManualService asignacionManualService) {
	this.asignacionManualService = asignacionManualService;
}

public void setEspecialistaService(EspecialistaService especialistaService) {
	this.especialistaService = especialistaService;
}
	 */
	/**
	 * Realiza el proceso de validacion de la declaracion para el proceso de
	 * modificar rectificaci�n.
	 *
	 * @param NUM_DECLARACION
	 * @param COD_ADUANA
	 * @param ANN_PRESEN
	 * @param COD_REGIMEN
	 * @param USERSESSION
	 * @return Map<String, Object>
	 * @throws ParseException
	 */
	public Map<String, Object> validarDeclaParaModificar(Map<String, Object> params)
	{
		// valida que la declaracion tenga solicitud de rectificacion electronica
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
				+ params.get("caduana").toString().trim()));
		try
		{
			String num_corredoc = "";
			List<Map<String, Object>> listDocSolicitud = null;
			try
			{
				num_corredoc = getNumCorreDocDeclaracion(params);
				listDocSolicitud = getSolicitudElectronica(num_corredoc);
			}
			catch (ServiceException e)
			{
				mapaRespuesta.put("ERROR", e.getMessage());
				return mapaRespuesta;
			}

			String tempEstaRecti = "";
			String strNumCorreDocSolicitud = "";

			// buscamos la solicitudes que esten en estado �Procedente�, �Procedente
			// en parte� o �Improcedente�
			// solo verificamos el ultimo registro el resto no importa
			for (Map<String, Object> map : listDocSolicitud)
			{
				tempEstaRecti = MapUtils.getMapValor(map, "COD_ESTARECTI");
				strNumCorreDocSolicitud = MapUtils.getMapValor(map, "NUM_CORREDOC");
				if (!ArrayUtils.contains(new String[]
						{ "05", "06", "07" }, tempEstaRecti))
				{
					// mapaRespuesta.put("ERROR","La declaraci�n no tiene Solicitud de Rectificaci�n Electr�nica procedente, procedente en parte o improcedente.");
					//Inicio - lmvr: Complemento de la Diligencia
					mapaRespuesta.put("ERROR"," Solicitud no puede ser modificada, porque ya cuenta con otra solicitud de rectificaci�n electr�nica evaluada.");
					//Fin - lmvr: Complemento de la Diligencia


					return mapaRespuesta;
				}

				break;
			}

			mapaRespuesta.put("NUM_CORREDOC_PRE", num_corredoc);
			mapaRespuesta.put("NUM_CORREDOC", strNumCorreDocSolicitud);

			//Lmvr- inicio - Complemento de rectificacion
			String cod_funcionarioDUA;
			String cod_funcionarioSolicitud;
			Map<String, Object> parametrosBD = new HashMap<String, Object>();
			parametrosBD.put("NUM_CORREDOC", num_corredoc);
			cod_funcionarioDUA = this.espeDocuDAO.findEspecAsigByDocu(parametrosBD);

			parametrosBD.put("NUM_CORREDOC", strNumCorreDocSolicitud);
			cod_funcionarioSolicitud = this.espeDocuDAO.findEspecAsigByDocu(parametrosBD);

			String cod_funcionario =    params.get("USERSESSION").toString();

			if (cod_funcionario != null) {

				if (cod_funcionarioDUA != null) {
					if (!cod_funcionarioDUA.trim().equals(cod_funcionario)) {
						mapaRespuesta
						.put("ERROR",
								" La modificaci�n de la diligencia de rectificaci�n s�lo puede ser efectuada por el funcionario aduanero que la registr�..");
						return mapaRespuesta;
					}

				}

				if (cod_funcionarioSolicitud != null) {
					if (!cod_funcionarioSolicitud.trim().equals(cod_funcionario)) {
						mapaRespuesta
						.put("ERROR",
								" La modificaci�n de la diligencia de rectificaci�n s�lo puede ser efectuada por el funcionario aduanero que la registr�..");
						return mapaRespuesta;
					}

				}

			}

			//Lmvr- fin - Complemento de rectificacion

			params.put("NUM_CORREDOC", num_corredoc);
			Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(params);

			String codCanal = mapCabDeclara.get("COD_CANAL").toString();
			String fechaRecepcion = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(mapCabDeclara.get("FEC_RECEP"));

			String cod_funcionario_portal = params.get("USERSESSION").toString().trim();
			String codEstDua = mapCabDeclara.get("COD_ESTDUA").toString();

			try
			{
				// Validacion canal D,F con fecha de recepcion y sin fecha de
				// autorizacion de levante
				validaTieneAsignadoFuncionario(num_corredoc, fechaRecepcion,
						false, cod_funcionario_portal,
						codCanal.trim(), codEstDua);

				// Validacion sin fecha de recepcion o ( canal F y D con diligencia) o
				// canal V y con fecha de autorizacion de levante
				validaDisponibilidadEspecialidad(params,
						true, cod_funcionario_portal,
						codCanal.trim());
			}
			catch (ServiceException serException)
			{
				mapaRespuesta.put("ERROR", serException.getMessage());
				return mapaRespuesta;
			}

		}
		catch (Exception e)
		{
			log.error(this.toString() + " validarDeclaParaModificar - ERROR: " + e);
			throw new ServiceException(this, "Ocurrio un error durante la validacion de la dua");
		}

		return mapaRespuesta;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> obtenerDeclaracionMoficar(Map<String, Object> params) throws ServiceException
	{

		Map<String, Object> res = new HashMap<String, Object>();

		try
		{
			/*******************************************
			 * Obtenemos la la dua a ser modificada
			 *******************************************/
			res = diligenciaService.findDuaRectificada(params.get("NUM_CORREDOC").toString());

			/*******************************************
			 * Obtenemos los expedientes a modificar
			 *******************************************/
			Map<String, Object> temp = new HashMap<String, Object>();
			temp.put("numcorredoc", params.get("NUM_CORREDOC_PRE").toString());
			temp.put("indicadorEliminado", new Integer(0));
			temp.put("tipoper", "R");
			temp.put("tipcaso", "14");

			List<DatoOtroDocSoporte> listaExpedientes;
			listaExpedientes = this.docAutAsociadoDAO.findDocSoporteByParameterMap(temp);
			res.put("LISTA_EXPEDIENTES", listaExpedientes);
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error durante la optencion de la dua");
		}

		return res;
	}

	/**
	 * Verifica modalidad.
	 *
	 * @param declaracion
	 *          the declaracion
	 */
	private void verificaModalidad(Map<String, Object> declaracion)
	{
		if ("10".equals(declaracion.get("COD_MODALIDAD")))
		{
			Map<String, String> params = new HashMap();
			Map<String, Object> paramManif = new HashMap();
			params.put("num_declaracion", declaracion.get("NUM_DECLARACION")
					.toString());
			params.put("cod_aduana", declaracion.get("COD_ADUANA").toString());
			params.put("ann_presen", declaracion.get("ANN_PRESEN").toString());
			params.put("cod_regimen", declaracion.get("COD_REGIMEN").toString());

			//glazaror: se debe evitar la invocacion innecesaria al metodo SerieService.obtenerListadoSeries... este metodo se carga la informacion completa de todas las series de la dua lo cual es demasiado lento
			//de lo revisado solo se requiere una serie para las validaciones posteriores... por lo tanto es innecesario consultar todas las series...
			//pendiente de mejorar...
			List<Map<String, Object>> lstDetDeclara = serieService.obtenerListadoSeries(params);
			if (!CollectionUtils.isEmpty(lstDetDeclara))
			{
				Map<String, Object> serie = lstDetDeclara.get(0);
				Map<String, Object> paramMap = new HashMap();
				paramMap.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP"));
				List<DocumentoDeTransporteHouse> lstDocTrans = gralDocTranporteDAO.listHousesByParameterMap(paramMap);
				if (!CollectionUtils.isEmpty(lstDocTrans))
				{
					for (DocumentoDeTransporteHouse docTrans : lstDocTrans)
					{
						try
						{
							if ((DateUtil.dateToString(docTrans.getFechaDeEmbarque(), "yyyyMMdd").equals(DateUtil.dateToString(
									(Date) serie.get("FEC_EMBARQUE"), "yyyyMMdd")))
									&& (docTrans.getPuertoEmbarque().getCpais().concat(docTrans.getPuertoEmbarque().getCpuerto()))
									.equals(serie
											.get("COD_PUER_EMBAR")))
							{
								paramManif.put("anioManifiesto", docTrans.getManifiesto().getAnioManifiesto());
								paramManif.put(
										"numeroManifiesto",
										Cadena.padLeft(docTrans.getManifiesto().getNumeroManifiesto().trim(), 6, ' '));
								paramManif.put("codigoAduana", declaracion.get("COD_ADUANA"));
								paramManif.put("codigoTipoManifiesto", docTrans.getManifiesto().getTipoManifiesto().getCodDatacat());
								paramManif.put("codigoViaTransporte", docTrans.getManifiesto().getViaTransporte().getCodDatacat());
								List<Manifiesto> lstManifiesto = manifiestoDAO.listByParameterMap(paramManif);
								for (Manifiesto manifiesto : lstManifiesto)
								{
									if (manifiesto.getFechaEfectivaDeLlegada() != null)
									{ // Si la fecha de llegada en mayor a la fecha de numetaci�n
										// de la DUA
										FechaBean ldFechaLlegada = new FechaBean(DateUtil.dateToString(
												manifiesto.getFechaEfectivaDeLlegada(),
												"yyyy-MM-dd"), "yyyy-MM-dd");
										if (Integer.valueOf(ldFechaLlegada.getAnho()).compareTo(1900) > 0)
										{
											if (manifiesto.getFechaEfectivaDeLlegada().compareTo((Date) declaracion.get("FEC_DECLARACION")) < 0)
											{
												String lCNuevaModalidad = "Diferido";
												String lcMensaModalidad = "Fecha de llegada de la Nave es anterior a la fecha de numeraci�n de la DUA. Se realizar� cambio de Modalidad de "
														.concat(declaracion.get("COD_MODALIDAD_DESC").toString())
														.concat(" a ")
														.concat(lCNuevaModalidad)
														.concat(".");
												if (declaracion.get("aviso") == null)
												{
													declaracion.put("aviso", lcMensaModalidad);
												}
												else
												{
													declaracion.put(
															"aviso",
															declaracion.get("aviso").toString().concat("\n").concat(lcMensaModalidad));
												}
												declaracion.put("COD_MODALIDAD", "00");
												declaracion.put("COD_MODALIDAD_DESC", lCNuevaModalidad);
												Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
												paramDeclaracion.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
												paramDeclaracion.put("COD_MODALIDAD", declaracion.get("COD_MODALIDAD"));
												updateDeclaracion(paramDeclaracion);
											}
										}
										Timestamp ldFecLlegaManif = (new FechaBean(DateUtil.dateToString(
												manifiesto.getFechaEfectivaDeLlegada(),
												"yyyy-MM-dd"), "yyyy-MM-dd")).getTimestamp();
										if (Integer.valueOf(ldFecLlegaManif.toString().substring(0, 4)).compareTo(1900) > 1)
										{
											if (manifiesto.getFechaEfectivaDeLlegada().compareTo((Date) declaracion.get("FEC_TERM")) != 0)
											{
												String lcMensaje = "La fecha de t�rmino de descarga en la DUA ("
														.concat(declaracion.get("FEC_TERM").toString().substring(0, 10))
														.concat(") difiere a la del manifiesto (")
														.concat(ldFecLlegaManif.toString().substring(0, 10))
														.concat("). Se realizar� la actualizaci�n en la DUA.");
												declaracion.put("FEC_TERM", ldFecLlegaManif);
												String lctipoMensaje = "aviso";
												if (declaracion.get(lctipoMensaje) == null)
												{
													declaracion.put(lctipoMensaje, lcMensaje);
												}
												else
												{
													declaracion.put(
															lctipoMensaje,
															declaracion.get(lctipoMensaje).toString().concat("\n").concat("\n")
															.concat(lcMensaje));
												}
											}
										}
									}
								}

								break;
							}
						}
						catch (ParseException e)
						{
							log.error("*** ERROR ***", e);
						}
					}
				}
			}
		}
		else
		{
			return;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> prorrateoFlete(List<Map<String, Object>> lstDetDeclara)
	{
		List<Map<String, Object>> lstPorPeso = new ArrayList();
		List<Map<String, Object>> lstPorFOB = new ArrayList();
		List<Map<String, Object>> lstSerieProrr = new ArrayList();
		BigDecimal lnFle_TotSer = BigDecimal.ZERO;
		BigDecimal lnFle_TotCab = BigDecimal.ZERO;
		// Se llena primero lista por Peso
		for (Map<String, Object> serie : lstDetDeclara)
		{
			if (!serie.get("COD_TIPFLETE").equals("1"))
			{
				boolean agrega = true;
				for (Map<String, Object> mapPorPeso : lstPorPeso)
				{
					if (mapPorPeso.get("COD_CONO_EMBAR").equals(
							serie.get("NUM_DOCTRANSP")))
					{
						agrega = false;
						break;
					}
				}
				if (agrega)
				{
					Map<String, Object> mapPorAux = new HashMap();
					mapPorAux.put("COD_CONO_EMBAR", serie.get("NUM_DOCTRANSP"));
					mapPorAux.put("FLE_DOLAR", BigDecimal.ZERO);
					mapPorAux.put("PESO_BRUTO", BigDecimal.ZERO);
					mapPorAux.put("FLE_DOLAR1", BigDecimal.ZERO);
					lstPorPeso.add(mapPorAux);
				}
			}
		}
		for (Map<String, Object> serie : lstDetDeclara)
		{
			for (Map<String, Object> mapPorPeso : lstPorPeso)
			{
				if (mapPorPeso.get("COD_CONO_EMBAR").equals(
						serie.get("NUM_DOCTRANSP")))
				{
					BigDecimal fleteSer = serie.get("MTO_FLETEDOL") == null ? BigDecimal.ZERO : Utilidades.toBigDecimal(serie
							.get("MTO_FLETEDOL"));
					BigDecimal pesoSer = serie.get("CNT_PESO_BRUTO") == null ? BigDecimal.ZERO : Utilidades.toBigDecimal(serie
							.get("CNT_PESO_BRUTO"));
					mapPorPeso.put("FLE_DOLAR", ((BigDecimal) mapPorPeso.get("FLE_DOLAR")).add(fleteSer));
					mapPorPeso.put("PESO_BRUTO", ((BigDecimal) mapPorPeso.get("PESO_BRUTO")).add(pesoSer));
					mapPorPeso.put("FLE_DOLAR1", ((BigDecimal) mapPorPeso.get("FLE_DOLAR1")).add(fleteSer));
					break;
				}
			}
		}
		// Se llena ahora la lista por FOB
		for (Map<String, Object> serie : lstDetDeclara)
		{
			if (serie.get("COD_TIPFLETE").equals("2"))
			{
				boolean agrega = true;
				for (Map<String, Object> mapPorFOB : lstPorFOB)
				{
					if (mapPorFOB.get("COD_CONO_EMBAR").equals(
							serie.get("NUM_DOCTRANSP")))
					{
						agrega = false;
						break;
					}
				}
				if (agrega)
				{
					Map<String, Object> mapPorAux = new HashMap();
					mapPorAux.put("COD_CONO_EMBAR", serie.get("NUM_DOCTRANSP"));
					mapPorAux.put("FOB_DOLPOL", BigDecimal.ZERO);
					lstPorFOB.add(mapPorAux);
				}
			}
		}
		for (Map<String, Object> serie : lstDetDeclara)
		{
			for (Map<String, Object> mapPorFOB : lstPorFOB)
			{
				if (mapPorFOB.get("COD_CONO_EMBAR").equals(
						serie.get("NUM_DOCTRANSP")))
				{
					BigDecimal FOBSer = serie.get("MTO_FOBDOL") == null ? BigDecimal.ZERO : Utilidades.toBigDecimal(serie
							.get("MTO_FOBDOL"));
					mapPorFOB.put("FOB_DOLPOL", (Utilidades.toBigDecimal(mapPorFOB.get("FOB_DOLPOL")).add(FOBSer)));
					break;
				}
			}
		}
		// Ahora se evalua por cada serie.
		BigDecimal dflete_ser1 = BigDecimal.ZERO;
		BigDecimal lnComodin = BigDecimal.ZERO;
		for (Map<String, Object> serie : lstDetDeclara)
		{
			if (serie.get("COD_TIPFLETE").equals("1"))
			{
				dflete_ser1 = Utilidades.toBigDecimal(serie.get("MTO_FLETEDOL"));
			}
			else if (serie.get("COD_TIPFLETE").equals("3"))
			{ // Se prorratea por Peso
				for (int i = 0; i < lstPorPeso.size(); i++)
				{
					Map<String, Object> mapPorPeso = lstPorPeso.get(i);
					if (mapPorPeso.get("COD_CONO_EMBAR").equals(
							serie.get("NUM_DOCTRANSP")))
					{

						//            dflete_ser1 = (((BigDecimal) mapPorPeso.get("FLE_DOLAR")).setScale(3).multiply((BigDecimal) serie
						//                .get("CNT_PESO_BRUTO"))).divide(
						//                (BigDecimal) mapPorPeso.get("PESO_BRUTO"), 3, BigDecimal.ROUND_HALF_DOWN);

						BigDecimal  CNT_PESO_BRUTO = new BigDecimal(serie.get("CNT_PESO_BRUTO").toString().replaceAll(",",""));
						BigDecimal  FLE_DOLAR = new BigDecimal(mapPorPeso.get("FLE_DOLAR").toString().replaceAll(",",""));
						BigDecimal  PESO_BRUTO = new BigDecimal(mapPorPeso.get("PESO_BRUTO").toString().replaceAll(",",""));

						dflete_ser1 = (FLE_DOLAR.setScale(3).multiply(CNT_PESO_BRUTO)).divide(PESO_BRUTO, 3, BigDecimal.ROUND_HALF_DOWN);

						BigDecimal  FLE_DOLAR1 = new BigDecimal(mapPorPeso.get("FLE_DOLAR1").toString().replaceAll(",","")); 

						lnComodin = FLE_DOLAR1.setScale(3);
						lnComodin = (lnComodin.subtract(dflete_ser1)).setScale(3);
						mapPorPeso.put("FLE_DOLAR1", lnComodin);
						lstPorPeso.set(i, mapPorPeso);
						break;
					}
				}
			}
			else if (serie.get("COD_TIPFLETE").equals("2"))
			{ // Se prorratea por FOB
				for (Map<String, Object> mapPorPeso : lstPorPeso)
				{
					if (mapPorPeso.get("COD_CONO_EMBAR").equals(
							serie.get("NUM_DOCTRANSP")))
					{
						lnComodin = ((BigDecimal) mapPorPeso.get("FLE_DOLAR1")).setScale(3);
						break;
					}
				}
				for (Map<String, Object> mapPorFOB : lstPorFOB)
				{
					if (mapPorFOB.get("COD_CONO_EMBAR").equals(
							serie.get("NUM_DOCTRANSP")))
					{
						dflete_ser1 = (lnComodin.multiply(Utilidades.toBigDecimal(serie.get("MTO_FOBDOL")))).divide(
								(BigDecimal) mapPorFOB.get("FOB_DOLPOL"),
								3,
								BigDecimal.ROUND_HALF_DOWN);
						break;
					}
				}
			}
			lnFle_TotCab = lnFle_TotCab.add(Utilidades.toBigDecimal(serie.get("MTO_FLETEDOL")));
			lnFle_TotSer = lnFle_TotSer.add(dflete_ser1); // Suma de los montos prorrateados
			Map<String, Object> mapSerieProrr = new HashMap();
			mapSerieProrr.put("NUM_SECSERIE", serie.get("NUM_SECSERIE"));
			mapSerieProrr.put("MTO_VALOR", dflete_ser1);
			lstSerieProrr.add(mapSerieProrr);
		}
		// Se suma monto diferencial entre el total Flete y la suma de los prorrateados.
		BigDecimal lnFle_Tempo = BigDecimal.ZERO;
		BigDecimal lnFle_Max = BigDecimal.ZERO;
		BigDecimal lnFle_Min = BigDecimal.ZERO;
		int indMax = 0;
		int indMin = 0;
		lnFle_Tempo = (lnFle_TotCab.subtract(lnFle_TotSer)).setScale(3);
		if (lnFle_Tempo.compareTo(BigDecimal.ZERO) < 0)
		{
			for (int i = 0; i < lstSerieProrr.size(); i++)
			{
				Map<String, Object> mapSerieProrr = lstSerieProrr.get(i);
				if (((BigDecimal) mapSerieProrr.get("MTO_VALOR"))
						.compareTo(lnFle_Max) > 0)
				{
					lnFle_Max = (BigDecimal) mapSerieProrr.get("MTO_VALOR");
					indMax = i;
				}
			}
			Map<String, Object> mapSerieProrr = lstSerieProrr.get(indMax);
			mapSerieProrr.put("MTO_VALOR", ((BigDecimal) mapSerieProrr
					.get("MTO_VALOR")).add(lnFle_Tempo));
			lstSerieProrr.set(indMax, mapSerieProrr);
		}
		else if (lnFle_Tempo.compareTo(BigDecimal.ZERO) > 0)
		{
			for (int i = 0; i < lstSerieProrr.size(); i++)
			{
				Map<String, Object> mapSerieProrr = lstSerieProrr.get(i);
				if (i == 0)
				{
					lnFle_Min = (BigDecimal) mapSerieProrr.get("MTO_VALOR");
					indMin = i;
				}
				if (((BigDecimal) mapSerieProrr.get("MTO_VALOR"))
						.compareTo(lnFle_Min) < 0)
				{
					lnFle_Min = (BigDecimal) mapSerieProrr.get("MTO_VALOR");
					indMin = i;
				}
			}
			Map<String, Object> mapSerieProrr = lstSerieProrr.get(indMin);
			mapSerieProrr.put("MTO_VALOR", ((BigDecimal) mapSerieProrr
					.get("MTO_VALOR")).add(lnFle_Tempo));
			lstSerieProrr.set(indMin, mapSerieProrr);
		}
		// Se actualiza montos prorrateados
		for (int i = 0; i < lstDetDeclara.size(); i++)
		{
			Map<String, Object> serie = lstDetDeclara.get(i);
			for (Map<String, Object> mapSerieProrr : lstSerieProrr)
			{
				if (mapSerieProrr.get("NUM_SECSERIE").equals(
						serie.get("NUM_SECSERIE")))
				{
					serie.put("MTO_FLETEDOL", mapSerieProrr.get("MTO_VALOR"));
					break;
				}
			}
			lstDetDeclara.set(i, serie);
		}
		return lstDetDeclara;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Map<String, Object>> obtenerItemFactura(Map<String, Object> params)
			throws ServiceException
			{
		return itemFacturaDAO.select(params);
			}

	/**
  /**
	 * Metodo que obtiene la lista de observaciones asociados a una declaracion
	 * por rmontes.
	 *
	 * @param params
	 *          the params
	 * @return the list
	 * @throws ServiceException
	 *           the service exception
	 */
	public List<Map<String, Object>> obtenerObservaciones(
			Map<String, Object> params) throws ServiceException
			{
		List<Map<String, Object>> res = null;

		try
		{
			res = this.observacionDAO.select(params);
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error de base de datos (observacion)");
		}
		return res;
			}

	/**
	 * Buscamos el numcorredoc de la declaracion a travez de los parametros
	 * ingresados y valida que la declarion exista.
	 *
	 * @param params
	 *          the params
	 * @return the num corre doc declaracion
	 */
	private String getNumCorreDocDeclaracion(Map<String, Object> params)
	{
		Map<String, Object> mapaCabDeclara = this.cabDeclaraDAO.findNumCorreDocAndNumOrdenByDeclaracion(params);

		if(MapUtils.esMapaNuloOVacio(mapaCabDeclara))
		{
			throw new ServiceException(this, "La Declaraci�n no se encuentra registrada en el sistema.");
		}
		return MapUtils.getMapValor(mapaCabDeclara, "NUM_CORREDOC");
	}

	/**
	 * Recupera la solicitud electronica a travez del num corredoc y el tipo de
	 * solicitud.
	 *
	 * @param num_corredoc
	 *          the num_corredoc
	 * @return the solicitud electronica
	 */
	private List<Map<String, Object>> getSolicitudElectronica(String num_corredoc)
	{

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NUM_CORREDOC", num_corredoc);
		parametros.put("COD_TIPSOL", "01");
		// busca que la declaracion tenga solicitud de de rectificacion electronica
		List<Map<String, Object>> lstSolicitudesRectificacion = this.relacionDocDAO.findSolicitudesByDocumento(parametros);

		if (lstSolicitudesRectificacion == null || lstSolicitudesRectificacion.size() == 0)
		{

			throw new ServiceException(this, "La declaraci�n no cuenta con Solicitud de Rectificaci�n Electr�nica.");
		}

		// ordenamos el resultado por fecha en orden descendente
		if (lstSolicitudesRectificacion.size() > 0)
		{
			Collections.sort(lstSolicitudesRectificacion, new Comparator<Map<String, Object>>()
					{
				@Override
				public int compare(Map<String, Object> thiss, Map<String, Object> that)
				{
					Date nthiss = (Date) thiss.get("FEC_SOLICITUD");
					Date nthat = (Date) that.get("FEC_SOLICITUD");
					return -1 * nthiss.compareTo(nthat);
				}
					});
		}
		return lstSolicitudesRectificacion;
	}

	/**
	 * Verifica si la DUA tiene indicador de cambio de canal por revaluacion del
	 * riesgo MATC 20130125.
	 *
	 * @param numCorreDoc
	 *          the num corre doc
	 * @return true, if successful
	 */
	private boolean tieneCambioCanalControl(String numCorreDoc)
	{
		Map params = new HashMap();
		params.put("num_corredoc", numCorreDoc);
		params.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_CAMBIO_CANAL_POR_REVALUACION);
		params.put("ind_activo", ConstantesDataCatalogo.IND_ACTIVO);
		Map indicador = indicadorDuaDAO.findByDocumentoAndValor(params);
		return (indicador != null && !indicador.isEmpty());
	}

	/**
	 * {@inheritDoc}
	 */
	public List obtenerParticipantesMap(Map params)
	{
		return this.participanteDocDAO.select(params);
	}

	/**
	 * {@inheritDoc}
	 */
	public List obtenerVFobProvisional(Map params)
	{
		return this.vFOBProvisionalDAO.findMapMontoProvByMap(params);
	}

	//GGRANADOS OFICIO
	public Integer insertarIndicadorDua(String numCorreDoc, String codIndicador, String tipoRegistro){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", numCorreDoc);
		params.put("cod_tiporegistro", tipoRegistro); // P:Portal del especialista
		params.put("cod_indicador", codIndicador);
		//return indicadorDuaDAO.insertIndicador(params);

		try
		{
			// TODO: AMANCILLAindicadorDuaDAO.insertIndicador(params);
			indicadorDuaDAO.insertIndicador(params);
		}
		catch (Exception e)
		{
			params.put("numCorredoc", numCorreDoc);
			params.put("codTiporegistro", tipoRegistro);
			params.put("codIndicador", codIndicador);
			params.put("indActivo", "1");

			// TODO: AMANCILLA indicadorDuaDAO.update(params);
			indicadorDuaDAO.update(params);
		}

		return 1;
	}

	/*INICIO-P34 FSW AFMA*/
	public void updateIndicadorDua(String numCorreDoc, String codIndicador, String tipoRegistro, String indActivo){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numCorredoc", numCorreDoc);
		params.put("codTiporegistro", tipoRegistro);
		params.put("codIndicador", codIndicador);
		params.put("indActivo", indActivo);
		indicadorDuaDAO.update(params);
	}
	/*FIN-P34 FSW AFMA*/

	public Map<String, Object> obtenerIndicadorDuaByPk(String numCorreDoc, String codIndicador){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", numCorreDoc);
		params.put("cod_indicador", codIndicador);
		params.put("ind_activo", Constantes.INDICADOR_DUA_ACTIVO);

		return indicadorDuaDAO.findByDocumentoAndValor(params);
	}

	/* rcalle - Inicio */


	//	/*
	//	 * (non-Javadoc)
	//	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#notificacionElectronica(java.util.Map)
	//	 */
	//	public void notificacionElectronica(Map<String, Object> parametros) throws ServiceException {
	//		diligenciaService.notificarObservacion(
	//				parametros.get("desSustento").toString(), 
	//				parametros.get("codAduana").toString(), 
	//				parametros.get("annPresen").toString(), 
	//				parametros.get("codRegimen").toString(), 
	//				parametros.get("numDeclaracion").toString(),
	//				parametros.get("codFuncionario").toString(),
	//				new String[] { parametros.get("numDocIdentPim").toString() },
	//				Constantes.COD_PL_NOTI_OBS_REC_FISICO, "1", "1");
	//	}

	/*
	 * (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#buscaDeclaracionBloqueoSalida(java.util.Map)
	 */
	public List<ReporteDeclaracionBloqueada> buscaDeclaracionBloqueoSalida(Map<String, Object> parametros) throws ServiceException {

		ReporteBloqueoMercancia reporteBloqueoMercancia = new ReporteBloqueoMercancia();
		reporteBloqueoMercancia.setCodTipAccion(Constantes.COD_TIP_ACCION_1);
		reporteBloqueoMercancia.setBloqueado(Constantes.COD_TIP_ACCION_1);
		reporteBloqueoMercancia.setDesbloqueado(Constantes.COD_TIP_ACCION_0);
		reporteBloqueoMercancia.setCodImportador(Constantes.CODIGO__IMPORTADOR);
		reporteBloqueoMercancia.setCodAgenteAduanas(Constantes.CODIGO_AGENTE_DE_ADUANAS_41);
		reporteBloqueoMercancia.setCodAlmacenAduanero(Constantes.CODIGO_ALMACEN_ADUANANERO_31);
		reporteBloqueoMercancia.setCodAduana(parametros.get("codAduana").toString());
		FechaBean fechaDesde = new FechaBean();
		fechaDesde.setFecha(parametros.get("fecDesde").toString());		
		reporteBloqueoMercancia.setFecHasta(fechaDesde);
		FechaBean fechaHasta = new FechaBean();
		fechaHasta.setFecha(parametros.get("fecHasta").toString());
		reporteBloqueoMercancia.setFecHasta(fechaHasta);
		reporteBloqueoMercancia.setCodFuncionario(parametros.get("codFuncionario").toString());
		List<String> listRegimen = new ArrayList<String>();
		if(Integer.parseInt(parametros.get("codRegimen").toString()) == -1){
			listRegimen.add("10");
			listRegimen.add("20");
			listRegimen.add("21");
			listRegimen.add("70");
			reporteBloqueoMercancia.setListRegimen(listRegimen);
		}else{
			listRegimen.add(parametros.get("codRegimen").toString());
			reporteBloqueoMercancia.setListRegimen(listRegimen);
		}

		List<ReporteDeclaracionBloqueada> listado = cabAccionDuaDAO.findDeclaracionBloqueoSalida(reporteBloqueoMercancia);
		List<ReporteDeclaracionBloqueada> listadoFinal = new ArrayList<ReporteDeclaracionBloqueada>();

		for (int i = 0; i<listado.size(); i++) {
			ReporteDeclaracionBloqueada reporteDeclaracionBloqueada = new ReporteDeclaracionBloqueada();
			reporteDeclaracionBloqueada.setNumeroDeclaracion((String)ObjectUtils.defaultIfNull(listado.get(i).getNumeroDeclaracion(), " "));
			reporteDeclaracionBloqueada.setImportador((String)ObjectUtils.defaultIfNull(listado.get(i).getImportador(), " "));
			reporteDeclaracionBloqueada.setAgenteAduanas((String)ObjectUtils.defaultIfNull(listado.get(i).getAgenteAduanas(), " "));
			reporteDeclaracionBloqueada.setAlmacenAduanero((String)ObjectUtils.defaultIfNull(listado.get(i).getAlmacenAduanero(), " "));
			reporteDeclaracionBloqueada.setFechaBloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getFechaBloqueo(), " "));
			reporteDeclaracionBloqueada.setSustentoBloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getSustentoBloqueo(), " "));
			reporteDeclaracionBloqueada.setFechaDesbloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getFechaDesbloqueo(), " "));
			reporteDeclaracionBloqueada.setSustentoDesbloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getSustentoDesbloqueo(), " "));
			reporteDeclaracionBloqueada.setFuncionarioDesbloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getFuncionarioDesbloqueo(), " "));
			reporteDeclaracionBloqueada.setFuncionarioBloqueo((String)ObjectUtils.defaultIfNull(listado.get(i).getFuncionarioBloqueo(), " "));
			listadoFinal.add(reporteDeclaracionBloqueada);
		}	

		return listadoFinal;
	}



	/* rcalle - Fin */

	/**
	 * juazor RIN13
	 * @param paramsDocTrans
	 * @return
	 */
	public boolean obtenerRegistro(Map<String,Object> paramsDocTrans) {

		boolean resu=true;

		//obtener si el registro esta completo o pendiente
		String numCorreDoc=paramsDocTrans.get("NUM_CORREDOC") !=null ? paramsDocTrans.get("NUM_CORREDOC").toString() : "";

		Map<String ,Object> paramConte = new HashMap<String, Object>();
		paramConte.put("NUM_CORREDOC",numCorreDoc);

		List<ConsultaDocuTransManifiesto> listaCont =  new ArrayList<ConsultaDocuTransManifiesto>();
		listaCont = obtenerContenedoresDescargaParcial(paramConte);
		Integer Zero=0;

		if(listaCont != null){
			if(!listaCont.isEmpty()){
				for (ConsultaDocuTransManifiesto consultaDocuTransManifiesto : listaCont) {
					if(Integer.parseInt(consultaDocuTransManifiesto.getFlagDescargado()) == Zero ){
						resu = false;
					}
				}
			}else{
				resu = false;
			}
		}else{
			resu = false;
		}

		return resu;
	}// fin obtenerRegistroCompletoPendiente


	/**
	 * juazor RIN13
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public List<ConsultaDocuTransManifiesto> obtenerContenedoresDescargaParcial(Map<String , Object> params) throws ServiceException{

		List<ConsultaDocuTransManifiesto> listContenedores = new ArrayList<ConsultaDocuTransManifiesto>();
		listContenedores = cabDeclaraDAO.obtenerContenedoresDescargaParcial(params);
		return listContenedores;
	}	

	/**
	 * juazor RIN13
	 * @param params
	 * @return
	 * @throws ServiceException
	 */
	public boolean tieneContinuacionDespacho(String numCorredoc){
		Map<String, Object> PkDocu = new HashMap<String, Object>();
		PkDocu.put("NUM_CORREDOC", numCorredoc);
		List<Map<String, Object>> lstDiligenciasDeclaracion = new ArrayList<Map<String,Object>>();
		lstDiligenciasDeclaracion=(List<Map<String, Object>>) diligenciaService.obtenerDiligencias(PkDocu);

		for (Map<String, Object> map : lstDiligenciasDeclaracion) {
			if(map.get("COD_TIPDILIGENCIA").toString().equals(Constantes.DILIG_CONT_DESPACHO)){
				return true;
			}
		}
		return false;
	}



	/*RIN13FSW-FIN*/
	/**INICIO-RIN13**/

	/**
	 * Busca la DUA 
	 * por su clave de negocio 
	 * @param aduana Aduana de la declaraci�n
	 * @param anio A�o de la declaraci�n
	 * @param regimen R�gimen de la declaraci�n
	 * @param numero N�mero de la declaraci�n
	 * @return DUA
	 * @author gbecerrav
	 */
	@Override
	public DUA buscarDUAByClaveDeNegocio(String aduana, Integer anio,
			String regimen, Integer numero) throws ServiceException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana", aduana);
		params.put("annoPresentacion", anio);
		params.put("codigoRegimen", regimen);
		params.put("numeroDeclaracion", numero);
		return this.cabDeclaraDAO.findDUAByKeyMap(params);
	}

	/**
	 * Buscar la DUA 
	 * su clave de negocio 
	 * @param aduana Aduana de la declaraci�n
	 * @param anio A�o de la declaraci�n
	 * @param regimen R�gimen de la declaraci�n
	 * @param numero N�mero de la declaraci�n
	 * @return DUA
	 * @author gbecerrav
	 */
	@Override
	public DUA buscarDatosGeneralesDUAByClaveDeNegocio(String aduana,
			Integer anio, String regimen, Integer numero) throws ServiceException {
		return this.cabDeclaraDAO.getDatosGeneralesDUAByClaveDeNegocio(aduana, anio, regimen, numero);
	}


	/**
	 * Adiciona datos a la declaracion
	 * para el proceso de diligencia previa
	 * @param declaracion Declaracion
	 * @return 
	 * @author gbecerrav
	 */
	@Override
	public void adicionarDatosDeclaracionParaDiligenciaPrevia(
			Declaracion declaracion) throws ServiceException {
		//Buscamos la descripcion del local anexo
		String direccionLocalAnexo = "";
		if(!SunatStringUtils.isEmpty(declaracion.getDua().getCodanexo()) && !SunatStringUtils.isEmpty(declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad())){
			direccionLocalAnexo = this.obtenerLocalAnexoDeclaracion(declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad(), declaracion.getDua().getCodanexo());
			if(SunatStringUtils.isEmpty(direccionLocalAnexo)){ 
				direccionLocalAnexo = "No registrado";
			}
		}else{
			direccionLocalAnexo = "No registrado";
		}
		declaracion.getDua().setDescripcionAnexo(direccionLocalAnexo);

		if(ConstantesDataCatalogo.REG_DEPOSITO.equals(declaracion.getDua().getCodregimen())){
			//Buscamos la descripci�n del local anexo dep�sito
			String direccionLocalAnexoDeposito = "";
			if(!SunatStringUtils.isEmpty(declaracion.getDua().getCodlocalanexo()) && !SunatStringUtils.isEmpty(declaracion.getDua().getDepositoAduanero().getNumeroDocumentoIdentidad())){
				direccionLocalAnexoDeposito = this.obtenerLocalAnexoDeclaracion(declaracion.getDua().getDepositoAduanero().getNumeroDocumentoIdentidad(), declaracion.getDua().getCodlocalanexo());
				if(SunatStringUtils.isEmpty(direccionLocalAnexoDeposito)){
					direccionLocalAnexoDeposito = "No registrado";
				}
			}else{
				direccionLocalAnexoDeposito = "No registrado";
			}
			declaracion.getDua().setDescripcionLocalAnexo(direccionLocalAnexoDeposito);
		}else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(declaracion.getDua().getCodregimen()) || ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(declaracion.getDua().getCodregimen())){
			//Descripcion de feria
			declaracion.getDua().setDescripcionFeria(this.obtenerFeriaDescripcion(declaracion.getDua().getCodferia()));
		}

		//Si los nombres o raz�n social son nulo o vacio
		OperadorAyudaService operadorAyudaService = this.fabricaDeServicios.getService("Ayuda.operadorAyudaService");

		//Transportista
		if(StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getManifiesto().getEmpTransporte().getNombreRazonSocial()))){
			String tipoDocumento =  declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().getCodDatacat();
			String numeroDocumento =  declaracion.getDua().getManifiesto().getEmpTransporte().getNumeroDocumentoIdentidad();

			if(!StringUtils.isEmpty(StringUtils.trim(tipoDocumento))){
				Map<String, Object> mapTransportista = operadorAyudaService.getDeclarante(numeroDocumento, tipoDocumento);
				declaracion.getDua().getManifiesto().getEmpTransporte().setNombreRazonSocial((String)mapTransportista.get("nombre"));
			}
		}

		//Importador
		if(StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDeclarante().getNombreRazonSocial())) || StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDeclarante().getDireccion()))){
			String tipoDocumento =  declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
			String numeroDocumento =  declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();

			if(!StringUtils.isEmpty(StringUtils.trim(tipoDocumento)) && !StringUtils.isEmpty(StringUtils.trim(numeroDocumento))){
				Map<String, Object> mapImportador = operadorAyudaService.getDeclarante(numeroDocumento, tipoDocumento);
				declaracion.getDua().getDeclarante().setNombreRazonSocial((String)mapImportador.get("nombre"));
				declaracion.getDua().getDeclarante().setDireccion((String)mapImportador.get("direccion"));
			}
		}

		//Declarante
		if(StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getAgenteAduanas().getNombreRazonSocial()))){
			String tipoDocumento =  declaracion.getDua().getAgenteAduanas().getTipoDocumentoIdentidad().getCodDatacat();
			String numeroDocumento =  declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad();

			if(!StringUtils.isEmpty(StringUtils.trim(tipoDocumento))){
				Map<String, Object> mapDeclarante = operadorAyudaService.getDeclarante(numeroDocumento, tipoDocumento);
				declaracion.getDua().getAgenteAduanas().setNombreRazonSocial((String)mapDeclarante.get("nombre"));
			}
		}

		//Deposito Temporal
		if(StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDepositoTemporal().getNombreRazonSocial()))){
			String tipoDocumento =  declaracion.getDua().getDepositoTemporal().getTipoDocumentoIdentidad().getCodDatacat();
			String numeroDocumento =  declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();

			if(!StringUtils.isEmpty(StringUtils.trim(tipoDocumento)) && !StringUtils.isEmpty(StringUtils.trim(numeroDocumento))){
				Map<String, Object> mapDepositoTemporal = operadorAyudaService.getDeclarante(numeroDocumento, tipoDocumento);
				declaracion.getDua().getDepositoTemporal().setNombreRazonSocial((String)mapDepositoTemporal.get("nombre"));
			}
		}

		if(ConstantesDataCatalogo.REG_DEPOSITO.equals(declaracion.getDua().getCodregimen())){
			//Desposito Aduanero
			if(StringUtils.isEmpty(StringUtils.trim(declaracion.getDua().getDepositoAduanero().getNombreRazonSocial()))){
				String tipoDocumento =  declaracion.getDua().getDepositoAduanero().getTipoDocumentoIdentidad().getCodDatacat();
				String numeroDocumento =  declaracion.getDua().getDepositoAduanero().getNumeroDocumentoIdentidad();

				if(!StringUtils.isEmpty(StringUtils.trim(tipoDocumento)) && !StringUtils.isEmpty(StringUtils.trim(numeroDocumento))){
					Map<String, Object> mapDepositoAduanero = operadorAyudaService.getDeclarante(numeroDocumento, tipoDocumento);
					declaracion.getDua().getDepositoAduanero().setNombreRazonSocial((String)mapDepositoAduanero.get("nombre"));
				}
			}
		}

		//Buscamos observaciones, en este caso solo el tipo 01
		Observacion paramsObservacion = new Observacion();
		paramsObservacion.setNumcorredoc(declaracion.getDua().getNumcorredoc());
		paramsObservacion.setCodtipobserva(ConstantesDataCatalogo.COD_TIPO_OBSERVACION_FORMATOA);
		Elementos<Observacion> listaObservaciones = new Elementos<Observacion>();
		ObservacionService observacionService = this.fabricaDeServicios.getService("declaracion.observacionService");
		listaObservaciones.addAll(observacionService.buscarObservacion(paramsObservacion));
		declaracion.getDua().setListObservaciones(listaObservaciones);

		//Buscamos indicadores
		//Tipo 02 y 12 
		Map<String, Object> paramsIndicador = new HashMap<String, Object>(); 
		paramsIndicador.put("numcorredoc", declaracion.getDua().getNumcorredoc());
		//paramsIndicador.put("codtipoindica", ConstantesDataCatalogo.INDICADOR_CAMBIO_CANAL_REVALUACION_RIESGO);
		paramsIndicador.put("listaTipoIndica", new String[] {ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION,
				ConstantesDataCatalogo.INDICADOR_CAMBIO_CANAL_POR_REVALUACION});
		paramsIndicador.put("indactivo", Constantes.INDICADOR_DUA_ACTIVO);
		Elementos<DatoIndicadores> listaIndicadores = new Elementos<DatoIndicadores>();
		IndicadorDuaService indicadorDuaService = this.fabricaDeServicios.getService("declaracion.indicadorDuaService");
		listaIndicadores.addAll(indicadorDuaService.buscarIndicadores(paramsIndicador));
		declaracion.getDua().setListIndicadores(listaIndicadores);

		//Buscamos si tiene formatoB
		DAV dav = new DAV();
		dav.setNumcorredoc(declaracion.getDua().getNumcorredoc());
		dav.setInddel(Constantes.IND_NO_ELIMINADO);
		declaracion.setExoneradoFB(!this.hasFormatoB(dav));

		///OBSERVACION RIN13
		//Buscamos fecha de vencimiento de garantia
		if(!StringUtils.isEmpty(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia())){

			FechaBean fechaVencimiento = this.obtenerFechaVencimientoGarantia(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(), 
					declaracion.getDua().getCodaduanaorden(), declaracion.getDua().getAnnpresen().toString(), declaracion.getDua().getCodregimen(), 
					declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());

			if (fechaVencimiento !=null){
				declaracion.getDua().getPago().getPagoDeclaracion().setFechaVencimientoGarantia(fechaVencimiento.getTimestamp());  
			}

		}
	}

	/**
	 * Obtiene la descripcion de la feria
	 * buscada por su PK codigo de feria 
	 * @param codigoFeria Codigo de Feria
	 * @return nombre de feria
	 * @author gbecerrav
	 */
	public String obtenerFeriaDescripcion(String codigoFeria) throws ServiceException {
		FeriasDAOService feriasService = this.fabricaDeServicios.getService("Ayuda.feriasService");
		Feria feria = feriasService.buscarFeriaByPK(codigoFeria);
		return feria != null ? feria.getNombre() : "";
	}


	/**
	 * Obtiene la fecha de vencimiento de garantia
	 * @param ruc RUC importador
	 * @param aduana Aduana de declaracion
	 * @param anio A�o de declaracion
	 * @param regimen Regimen de declaracion
	 * @param numero Numero de CtaCte
	 * @return fecha
	 * @author gbecerrav
	 */
	private FechaBean obtenerFechaVencimientoGarantia(String ruc, String aduana, String anio, String regimen, String numero) {
		Map<String, Object> paramsGarantia = new HashMap<String, Object>();
		paramsGarantia.put("cRUC", ruc);
		paramsGarantia.put("cADUANA", aduana);
		paramsGarantia.put("cANO", anio);
		paramsGarantia.put("cREGIMEN", regimen);
		paramsGarantia.put("cNUMERO", numero);
		paramsGarantia.put("cMODULO", "TA");
		paramsGarantia.put("nFECNUMERA", 0);
		paramsGarantia.put("nFECRECTI", 0);

		try {
			String fecha = this.pagarantiaDAO.consultarFechaVencimientoGarantia(paramsGarantia);

			if ("1".equals(fecha.substring(0, 1))) {
				Map<String, Object> paramsFechaUtil = new HashMap<String, Object>();
				paramsFechaUtil.put("FECHAHASTA", "1");
				paramsFechaUtil.put("TIPO", "2");
				paramsFechaUtil.put("INCLUYE", "S");
				paramsFechaUtil.put("SUSPENDE", "S");
				paramsFechaUtil.put("FECHADESDE", fecha.substring(2));
				return new FechaBean(this.diasUtilesDAO.getSPDiasUtiles(paramsFechaUtil), "yyyyMMdd");
			}
		} catch (Exception e) {
			log.error("******** EVALUANDO FECHA DE VENCIMIENTO GARANTIA ERROR:" + e);
		}
		return null;

	}

	/**
	 * Actualiza selectivamente 
	 * un registro de declaracion 
	 * buscado por la clave primaria
	 * @param dua Declaracion a actualizar
	 * @return 
	 * @author gbecerrav
	 */
	@Override
	public void actualizarDUAByPrimaryKey(DUA dua) throws ServiceException {
		this.cabDeclaraDAO.updateByPrimaryKeySelective(dua);
	}

	/**
	 * Verifica si tiene formatoB
	 * @param dav DAV
	 * @return true si es que existe y false si no existe
	 * @author gbecerrav
	 */
	public boolean hasFormatoB(DAV dav) throws ServiceException {
		return formBProveedorDAO.hasFormBProveedor(dav);
	}


	/**INICIO -RIN13**/
	//  private void enviarAvisoRectificacionPuntodeLlegadaPlazo(Integer numeroDeclaracion, String anioDeclaracion, 
	//	  String regimenDeclaracion, String aduanaDeclaracion, String tipoDocumentoIdentidad, String numeroDocumentoIdentidad, String nombreRazonSocial){
	//	  if(nombreRazonSocial == null || nombreRazonSocial.trim().equals("")){
	//		  OperadorAyudaService operadorAyudaService = this.fabricaDeServicios.getService("Ayuda.operadorAyudaService");
	//		  nombreRazonSocial = operadorAyudaService.getDeclarante(tipoDocumentoIdentidad, numeroDocumentoIdentidad).get("nombre").toString();
	//  		}
	//		
	//		final FechaBean fechaActual = new FechaBean();
	//		Map<String, Object> mapMensaje = new HashMap<String, Object>();
	//		mapMensaje.put("tip_usuario", "1");
	//		mapMensaje.put("cod_usuario", new String[] {numeroDocumentoIdentidad});
	//		mapMensaje.put("des_asunto", "Notificaci�n");
	//		mapMensaje.put("razon_social", numeroDocumentoIdentidad);
	//		mapMensaje.put("num_ruc", numeroDocumentoIdentidad);
	//		mapMensaje.put("cod_aduana", aduanaDeclaracion);
	//		mapMensaje.put("ann_presen", anioDeclaracion);
	//		mapMensaje.put("cod_regimen", regimenDeclaracion);
	//		mapMensaje.put("num_declaracion", numeroDeclaracion);
	//		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy"));
	//
	//		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
	//		PublicacionAvisoService publicacionAvisoService = this.fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
	//		publicacionAvisoService.insert(162, data, Constantes.CODIGO_NOTIFICACION, fechaActual.getTimestamp(), new FechaBean("31/12/9999").getTimestamp()); 
	//  }  




	/**FIN-RIN13**/


	//FIXME: RIN16 : lpalominom [inicio]
	/**
	 * {@inheritDoc}
	 */
	public String verificarRegularizacionConclusionAutomatica(Declaracion declaracion){
		String respuesta = Constantes.FLAG_REGULARIZACION_NO_CONCLUSION_AUTOMATICA;

		// #1# - Que NO se haya registrado en estado [13 - Concluida] en algun momento
		GetDeclaracionService declaracionService = fabricaDeServicios.getService("declaracionService");
		boolean flag1 = declaracionService.existeEstadoHistorico(declaracion);

		// #2# - Que NO tenga Asociada Boletines Quimicos pendientes de informe
		boolean flag2 = soporteService.tieneBoletinesQuimicosPendientes(declaracion);

		// #3# - Que NO exista Duda Razonable pendiente [Notificacion Emitida y sin Diligencia de Duda Razonable]
		boolean flag3 = dudaRazonableService.tieneDudaRazonablePendPorConcluir(declaracion);
		/**Inicio de cambios PAS20165E220200032***/
		// #4# - Que NO se haya numerado la Declaracion despues de la vigencia de la NLGA
		boolean flag4 = declaracionService.esVigenteNuevaLGA(declaracion);
		/**Fin de cambios PAS20165E220200032***/
		if (!flag1 && !flag2 && !flag3 && !flag4){//PAS20165E220200032
			respuesta = Constantes.FLAG_REGULARIZACION_CONCLUSION_AUTOMATICA;
		}

		return respuesta;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String, Object> guardarDeclaracionObservada(Map<String, Object> params) {
		Map<String, Object> p = new HashMap<String, Object>();
		p.put("NUM_CORREDOC", params.get("NUM_CORREDOC"));
		p.put("COD_ESTREGUL", Constantes.PENDIENTE_DE_REGULARIZAR_OBSERVADA);
		log.info("---------------------------------------------------------");
		log.info("## p :"+p);
		log.info("---------------------------------------------------------");
		Map<String, Object> respuesta = new HashMap<String, Object>();
		cabDeclaraDAO.update(p);
		this.notificarDeclaracionObservada(params);
		respuesta.put("EXITO", "Declaraci�n pendiente de regularizar OBSERVADA");
		return respuesta;
	}

	/**
	 * {@inheritDoc}
	 * @throws ParseException 
	 */
	public Map<String, Object> validarDeclaracionParaObservar(Map<String, Object> params) throws Exception {
		log.info("$$ validarDeclaracionParaObservar() [inicio]"); 
		log.info("## params : "+params);
		Map<String, Object> respuesta = new HashMap<String, Object>();
		List<String> mensajes = new ArrayList<String>();
		boolean tieneObservacion = true; 
		String DEFAULT_TIPO_DOC = "01"; //P24 129 - PAS20165E220200099

		// -- Buscamos la Declaracion
		Map<String, Object> declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(params), (String)params.get("cod_regimen"));
		log.info("## declaracion : " + declaracion);

		// -- Verificamos que la Declaracion Exista	        
		if ( declaracion == null || (declaracion != null && declaracion.isEmpty()) ){
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_NO_CARGADA);
			mensajes.add("La Declaraci�n no ha sido numerada en el SDA.");//p24
		} else {

			// -- Verificamos que la Declaracion no se encuentre legajada
			String codEstDua = (String)declaracion.get("COD_ESTDUA");
			if (codEstDua.equals(Constantes.COD_ESTADO_DUA_LEGAJADA)) {
				mensajes.add("Declaraci�n se encuentra legajada.");
				tieneObservacion = false;
			}	

			// -- Verificamos que la Declaracion No Cuente con Levante
			Date fecAutLevante = (Date)declaracion.get("FEC_AUTLEVANTE");
			if (DateUtil.dateToString(fecAutLevante, "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD) && tieneObservacion) {
				mensajes.add("Declaraci�n no cuenta con Levante Autorizado.");
				tieneObservacion = false;
			}

			// -- Verificamos que sea Despacho Urgente
			if (!declaracion.get("COD_MODALIDAD").equals(Constantes.COD_MODALIDAD_URGENTE) && tieneObservacion){
				mensajes.add("Declaraci�n no corresponde a la modalidad de despacho urgente, verifique");
				tieneObservacion = false;
			}	 


			// -- Verificamos que la Declaracion cuente con una Solicitud de Regularizacion
			if (tieneObservacion) {
				Map<String,Object> p2 = new HashMap<String,Object>();
				p2.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				p2.put("COD_TIPSOL", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
				String numSolicitud = relacionDocDAO.findSolicitudByDocumento(p2);
				if (StringUtils.isEmpty(numSolicitud) ) {
					mensajes.add("Declaracion no cuenta con Solicitud de Regularizaci�n.");
					tieneObservacion = false;
				} else {
					// -- Verificamos que el Funcionario se encuentre asociado a la
					// Solicitud de Regularizacion
					p2.put("NUM_CORREDOC", numSolicitud);
					String funcionarioSolicitud = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocu(p2));

					if ((StringUtils.isEmpty(funcionarioSolicitud))) {
						mensajes.add("Solicitud de Regularizaci�n no cuenta con Funcionario Aduanero asignado");
						tieneObservacion = false;
					} else if (!params.get("codigoFuncionario").equals(	funcionarioSolicitud)) {
						mensajes.add("Funcionario Aduanero no tiene asignada la Transmisi�n de la Regularizaci�n.");
						tieneObservacion = false;
					}
				}
			}
			// -- Verificamos que la Declaracion no se encuentre Observada
			String codEstRegul = (String)declaracion.get("COD_ESTREGUL");
			if (codEstRegul.equals(Constantes.PENDIENTE_DE_REGULARIZAR_OBSERVADA) && tieneObservacion) {
				mensajes.add("Declaraci�n de despacho urgente se encuentra Observada.");
				tieneObservacion = false;
			}		

			// -- Verificamos que la Declaracion No se encuentre Regularizada
			Date fecRegulariza = (Date)declaracion.get("FEC_REGULARIZA");
			if (!DateUtil.dateToString(fecRegulariza, "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD) && tieneObservacion) {
				mensajes.add("Declaraci�n de despacho urgente cuenta con diligencia de regularizaci�n, imposible registrar el estado DUA pendiente de regularizar OBSERVADA.");
				tieneObservacion = false;
			}	

			// -- Verificamos cuente con Notificacion realizada en la Diligencia de Regularizacion
			if (tieneObservacion) {
				ComunicacionDAO comunicacionDAO = fabricaDeServicios.getService("diligencia.ingreso.comunicacionDef_xa");
				Map<String, String> p = new HashMap<String, String>();
				p.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
				p.put("COD_TIPDILIGENCIA", "20");
				List<Map<String, Object>> lista = comunicacionDAO.findByDiligenciaAndTipo(p);

				if (lista == null || (lista != null && lista.isEmpty())) {
					mensajes.add("Declaraci�n no cuenta con notificaci�n realizada en la revisi�n de la diligencia de regularizaci�n");
				}
			} 

		}

		if (mensajes.isEmpty()) {		
		    /*Inicio P24- 129  - PAS20165E220200099 II*/
			DeclaracionService declaracionService = (DeclaracionService) fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
		    String numeroDeclaracionTitulo= declaracionService.adicionParametrosNumeroDeclaracion(declaracion, DEFAULT_TIPO_DOC);		    
		    /*Fin P24-129 - PAS20165E220200099 II*/   
			respuesta.put("declaracion", this.prepararDatos(declaracion));
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_CARGADA);			
		} else {
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_NO_CARGADA);
			respuesta.put("mensajes", mensajes);
		}

		log.info("@@ respuesta : "+respuesta);
		log.info("$$ validarDeclaracionParaObservar() [fin]"); 
		return respuesta;
	}
	/**
	 * Verifica si la declaracion cuenta con un expediente concluido [05] para la suspension del plazo
	 * @param decVen
	 * @return
	 */
	private boolean verificaTieneExpedienteSuspensionPlazo(Declaracion decVen){		
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		List<Map<String, Object>> listaExpedientes = funcionesService.buscarExpedienteSuspension(
				decVen.getCodaduana(), 
				decVen.getDua().getAnnpresen().toString(), 
				decVen.getCodregimen(), 
				decVen.getNumeroDeclaracion().toString(), 
				decVen.getDua().getFecvencregula());		
		if(CollectionUtils.isEmpty(listaExpedientes)){
			return false;
		}else{
			return true;
		}		
	}

	/**
	 * {@inheritDoc}
	 */
	public String estadoDeRegularizacion(Declaracion declaracion, String tipoEstado) {
		String estado = "";
		Date fecSegundaRecepcion;
		Date fecVencPlazoRegul = declaracion.getDua().getFecvencregula(); // date	  

		if (Constantes.COD_MODALIDAD_ANTICIPADO.equals(tipoEstado)){
			fecSegundaRecepcion = new Date();
		} else {
			fecSegundaRecepcion = declaracion.getDua().getFecSegundaRecepcion(); // date
		}

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecVencPlazoRegul, fecSegundaRecepcion,"COMPARA_SOLO_FECHA")){
			estado = Constantes.REGULARIZADA_DENTRO_DEL_PLAZO;
		} else {
			if (verificaTieneExpedienteSuspensionPlazo(declaracion)){
				estado = Constantes.REGULARIZADA_CON_SUSPENSION_DE_PLAZO;
			} else {
				estado = Constantes.REGULARIZADA_FUERA_DEL_PLAZO;
			}
		}
		return estado;
	}

	/*********Inicio EGH_PASEINGRESO2*********************/
	/**
	 * {@inheritDoc} 
	 * @throws ParseException 
	 */
	public Map<String, Object> validarDeclaParaRegularizacionOficio(Map<String, Object> params,UsuarioBean usuario) throws Exception {
		log.info("$$ validarDeclaracionParaObservar() [inicio]"); 
		log.info("## params : "+params);
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//List<String> mensajes = new ArrayList<String>();
		// -- Buscamos la Declaracion
		//Map<String, Object> declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(params), (String)params.get("cod_regimen"));
		respuesta = this.obtenerDeclaracion(Utilidades.adaptarParametrosBD(params));


		log.info("## declaracion : " + respuesta);
		// -- Verificamos que la Declaracion Exista
		if ( respuesta == null || (respuesta != null && respuesta.isEmpty()) ){
			//mensajes.add("La Declaraci�n no ha sido numerada en el SDA.");//p24
			respuesta = new HashMap<String, Object>();
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_NO_CARGADA);
			respuesta.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
			return respuesta;
		} else {


			// -- Verificamos que la Declaracion No se encuentre Regularizada
			Date fecRegulariza = (Date)respuesta.get("FEC_REGULARIZA");
			if (!DateUtil.dateToString(fecRegulariza, "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD)) {
				//mensajes.add("Declaraci�n de despacho urgente se encuentra Regularizada.");
				respuesta.put("error", "Declaraci�n de despacho urgente se encuentra Regularizada.");
				return respuesta;
			}

			/* comentamos para probar la grabacion */
			// -- Verificamos que la Declaracion No Cuente con Levante
			Date fecAutLevante = (Date)respuesta.get("FEC_AUTLEVANTE");
			if (fecAutLevante.equals((DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD, "dd/MM/yyyy")))) {
				//mensajes.add("Declaraci�n no cuenta con Levante Autorizado.");
				respuesta.put("error", "Declaraci�n no cuenta con Levante Autorizado.");
				return respuesta;
			}

			// -- Verificamos que se Despacho Urgente
			if (respuesta.get("COD_MODALIDAD").equals(Constantes.COD_MODALIDAD_URGENTE) || 
					respuesta.get("COD_MODALIDAD").equals(Constantes.COD_MODALIDAD_ANTICIPADO)){
				if (respuesta.get("COD_MODALIDAD").equals(Constantes.COD_MODALIDAD_URGENTE)){
					if(respuesta.get("COD_ESTREGUL")==null || !(respuesta.get("COD_ESTREGUL").equals(Constantes.PENDIENTE_DE_REGULARIZAR_FUERA_DEL_PLAZO) || respuesta.get("COD_ESTREGUL").equals(Constantes.PENDIENTE_DE_REGULARIZAR_OBSERVADA))){
						//mensajes.add("Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo"); 
						respuesta.put("error", "Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo.");
						return respuesta;
					}
				}else{//ANTICIPADO
					List<Map<String,?>> declaracionPendienteRegularizar = null;
					Map parametrosBusqueda = new HashMap<String,Object>();
					parametrosBusqueda.put("codmodalidad", Constantes.COD_MODALIDAD_ANTICIPADO);
					parametrosBusqueda.put("indactivo", Constantes.INDICADOR_DUA_ACTIVO);
					parametrosBusqueda.put("codindicador", Constantes.IND_DUA_REQ_REGULARIZ);
					parametrosBusqueda.put("codestregul", Constantes.PENDIENTE_DE_REGULARIZAR_FUERA_DEL_PLAZO);
					parametrosBusqueda.put("numeroCorrelativo", respuesta.get("NUM_CORREDOC"));
					declaracionPendienteRegularizar = this.cabDeclaraDAO.buscarPendienteRegularizar(parametrosBusqueda);
					if(declaracionPendienteRegularizar==null || declaracionPendienteRegularizar.size()==0){
						//mensajes.add("Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo");
						respuesta.put("error", "Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo.");
						return respuesta;
					}
				}
			}else{
				//mensajes.add("Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo");
				respuesta.put("error", "Declaraci�n no se encuentra Pendiente de Regularizar Fuera del Plazo.");
				return respuesta;
			}                              

			// -- Verificamos que la Declaracion cuente con una Solicitud de Regularizacion
			Map<String,Object> p2 = new HashMap<String,Object>();
			p2.put("NUM_CORREDOC", respuesta.get("NUM_CORREDOC"));
			p2.put("COD_TIPSOL", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
			//p2.put("COD_ESTSOL", "03");//  Asignada a Funcionario Aduanero

			boolean validarFuncionarioPertenezcaGrupo = false;
			String numSolicitud = relacionDocDAO.findSolicitudByDocumento(p2);
			if (StringUtils.isEmpty(numSolicitud)){
				validarFuncionarioPertenezcaGrupo = true;
			}else{ // si presenta solicitud
				// -- Verificamos que el Funcionario se encuentre asociado a la Solicitud de Regularizacion
				p2.put("NUM_CORREDOC", numSolicitud);
				String funcionarioSolicitud = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocu(p2));
				if (StringUtils.isEmpty(funcionarioSolicitud)){
					validarFuncionarioPertenezcaGrupo = true;
				}else{
					if(!params.get("codigoFuncionario").equals(funcionarioSolicitud)){
						//Error
						//mensajes.add("La solicitud de regularizaci�n se encuentra asignada a "+funcionarioSolicitud);
						//respuesta.put("error", "La solicitud de regularizaci�n se encuentra asignada a "+funcionarioSolicitud);

						Map<String,Object> parametroBusquedaRRHH = new HashMap<String, Object>();
						parametroBusquedaRRHH.put("cod_pers", funcionarioSolicitud.trim());
						parametroBusquedaRRHH.put("orderby",Constantes.ORDENAR_REGISTROS);
						pe.gob.sunat.rrhh2.service.ConsultaService consultaServiceRRHH = (pe.gob.sunat.rrhh2.service.ConsultaService) fabricaDeServicios.getService("rrhh2.service.consultaService");
						List<Map<String, Object>> detallesFuncionario = consultaServiceRRHH.consultarPersonal(parametroBusquedaRRHH);
						//fin mpoblete BUG
						if (detallesFuncionario!=null && detallesFuncionario.size()>0){
							respuesta.put("error", "La solicitud de regularizaci�n se encuentra asignada a "+ funcionarioSolicitud + " - " + 
									detallesFuncionario.get(0).get("t02ap_pate") + " " + detallesFuncionario.get(0).get("t02ap_mate") + " " + detallesFuncionario.get(0).get("t02nombres"));
						}
						else{
							respuesta.put("error", "La solicitud de regularizaci�n se encuentra asignada a "+funcionarioSolicitud);						
						}						

						return respuesta;
					}
				}
			}

			if(validarFuncionarioPertenezcaGrupo){
				Map<String, Object> mapespedispo = new HashMap<String, Object>();
				mapespedispo.put("COD_FUNCIONARIO", params.get("codigoFuncionario").toString());
				mapespedispo.put("COD_GRUPO", Constantes.GRUPO_REGULARIZACION);
				mapespedispo.put("INDICADOR_VIGENTE", "1");
				List rows;
				rows = this.espeDispoDAO.buscarEspeDispo(mapespedispo);
				if (rows.size() == 0){
					//mensajes.add("Funcionario Aduanero No pertenece al grupo de Regularizaci�n.");
					respuesta.put("error", "Funcionario Aduanero No pertenece al grupo de Regularizaci�n.");
					return respuesta;
				}
			}


			// -- Verificamos cuente con Notificacion realizada en la Diligencia de Regularizacion (DZC: NO INDICA ESTO EN EL F2)
			/*
		  ComunicacionDAO comunicacionDAO = fabricaDeServicios.getService("diligencia.ingreso.comunicacionDef_xa");
		  Map <String,String> p = new HashMap<String, String>();
		  p.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
		  p.put("COD_TIPDILIGENCIA", "07");
		  List<Map<String, Object>> lista = comunicacionDAO.findByDiligenciaAndTipo(p);

		  if ( lista == null || (lista !=null && lista.isEmpty()) ){
			  //mensajes.add("Declaraci�n no cuenta con notificaci�n realizada en la revisi�n de la diligencia de regularizaci�n");
			  respuesta.put("error", "Declaraci�n no cuenta con notificaci�n realizada en la revisi�n de la diligencia de regularizaci�n");
		      return respuesta;
		  }
			 */

			// Regla: No se ha registrado la informaci�n de pesos y bultos recibidos del ICA
			Long numeroCorrelativo = new Long(respuesta.get("NUM_CORREDOC").toString());

			Map<String, String> mapSerie = new HashMap<String, String>();
			mapSerie.put("cod_regimen", (String) respuesta.get("COD_REGIMEN"));
			mapSerie.put("cod_aduana", (String) respuesta.get("COD_ADUANA"));
			mapSerie.put("ann_presen", ((BigDecimal) respuesta.get("ANN_PRESEN")).toString());
			mapSerie.put("num_declaracion", ((BigDecimal) respuesta.get("NUM_DECLARACION")).toString());
			mapSerie.put("acceso", "00");
			SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
			List<Map<String, Object>> listSerie = serieService.obtenerListadoSeries(mapSerie);
			//int total_serie= listSerie.size();

			List<Map<String, Object>> listaDocTransporte = serieService.obtenerListaNumeroDocTransporteByDeclaracionYNumDetalle(numeroCorrelativo);          
			Map<String, Object> paramsBusqueda = new HashMap<String, Object>();
			String numeroManifiesto = (String) respuesta.get("NUM_MANIFIESTO");
			BigDecimal anioManifiestoBigDecimal = (BigDecimal) respuesta.get("ANN_MANIFIESTO");
			Integer anioManifiesto = new Integer(anioManifiestoBigDecimal.intValue());
			String tipoManifiesto = (respuesta.get("COD_TIPMANIFESTO")!=null?respuesta.get("COD_TIPMANIFESTO").toString():"01");
			String codigoAduana = (String) respuesta.get("COD_ADUAMANIFIESTO");	
			String viaTransporte=(String) respuesta.get("COD_VIATRANS");

			paramsBusqueda.put("numeroManifiesto", SunatStringUtils.lpad(numeroManifiesto, 6, ' '));		  
			paramsBusqueda.put("anioManifiesto", anioManifiesto);
			paramsBusqueda.put("codigoAduana", codigoAduana);
			paramsBusqueda.put("tipoManifiesto", tipoManifiesto);
			paramsBusqueda.put("viaTransporte", viaTransporte);
			paramsBusqueda.put("listaDetalleDocTransporte", listaDocTransporte);
			paramsBusqueda.put("estado", ConstantesManifiesto.DOCUMENTO_TRANSPORTE_ESTADO_ANULADO);
			paramsBusqueda.put("hijoAndMaster", true);
			//paramsBusqueda.put("tipoEnvio", ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA );//ICA
			String[] lista = new String[] { Integer.toString(ConstantesDataCatalogo.TIPO_ENVIO_TARJA_AL_DETALLE),Integer.toString(ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA),Integer.toString(ConstantesDataCatalogo.TIPO_ENVIO_IRM)};//PAS20191U220200019 - Se adiciono IRM
			paramsBusqueda.put("listaTipoEnvio", lista );//ICA
			paramsBusqueda.put("indicadorEliminacion", Constantes.IND_NO_ELIMINADO);
			DocumentoOAManifiestoService documentoOAManifiestoService = this.fabricaDeServicios.getService("manifiesto.documentoOAManifiestoService");
			int cantidadICA = documentoOAManifiestoService.obtenerCantidadOperacionesAsociadaDocumentoTransporte(paramsBusqueda);
		  if(cantidadICA != listaDocTransporte.size()){
				respuesta.put("error", "No se ha registrado la informaci�n de pesos y bultos recibidos del ICA.");
		    }


			// -- Verificamos que la Dua ha sido asignada a conclusion cuando el estado de la dua es 10
			if(respuesta.get("COD_ESTDUA")!=null && respuesta.get("COD_ESTDUA").toString().equals(Constantes.COD_ESTADO_DUA_CONCLUSION)){
				Map<String,Object> p3 = new HashMap<String,Object>();
				p3.put("NUM_CORREDOC", respuesta.get("NUM_CORREDOC"));
				p3.put("COD_GRUPO", Constantes.GRUPO_CONCLUCION_DESPACHO);
				String funcionarioSolicitud2 = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocu(p3));
				if(funcionarioSolicitud2!=null && !funcionarioSolicitud2.trim().equals("")){
					//WARNING
					//mensajes.add("Declaraci�n asignada a conclusi�n de despacho a "+funcionarioSolicitud2);
					//respuesta.put("Msjwarning", "Declaraci�n asignada a conclusi�n de despacho a "+funcionarioSolicitud2);

					Map<String,Object> parametroBusquedaRRHH = new HashMap<String, Object>();
					parametroBusquedaRRHH.put("cod_pers", funcionarioSolicitud2.trim());
					parametroBusquedaRRHH.put("orderby",Constantes.ORDENAR_REGISTROS);
					pe.gob.sunat.rrhh2.service.ConsultaService consultaServiceRRHH = (pe.gob.sunat.rrhh2.service.ConsultaService) fabricaDeServicios.getService("rrhh2.service.consultaService");
					List<Map<String, Object>> detallesFuncionario = consultaServiceRRHH.consultarPersonal(parametroBusquedaRRHH);
					//fin mpoblete BUG
					if (detallesFuncionario!=null && detallesFuncionario.size()>0){
						respuesta.put("Msjwarning", "Declaraci�n asignada a conclusi�n de despacho a "+ funcionarioSolicitud2 + " - " + 
								detallesFuncionario.get(0).get("t02ap_pate") + " " + detallesFuncionario.get(0).get("t02ap_mate") + " " + detallesFuncionario.get(0).get("t02nombres"));
					}
					else{
						respuesta.put("Msjwarning", "Declaraci�n asignada a conclusi�n de despacho a "+funcionarioSolicitud2);						
					}				  
				}
			}

		} 

		params.put("NUM_CORREDOC", respuesta.get("NUM_CORREDOC").toString());
		params.put("COD_TIPSOL", "11");

		Object numDocSol = this.relacionDocDAO.findSolicitudByDocumento(params);
		respuesta.put("NUM_CORREDOC_SOL", numDocSol);


		respuesta.put("num_corredoc", respuesta.get("NUM_CORREDOC").toString());
		respuesta.put("COD_ESTDUA", respuesta.get("COD_ESTDUA").toString());
		respuesta.put("FLAG", Constantes.FLAG_DECLARACION_CARGADA);

		log.info("@@ respuesta : "+respuesta);
		log.info("$$ validarDeclaracionParaObservar() [fin]"); 
		return respuesta;
	}
	/*********Fin EGH_PASEINGRESO2*********************/



	/**
	 * {@inheritDoc}
	 */
	public String estadoDeRegularizacion(Declaracion declaracion) {
		return estadoDeRegularizacion(declaracion, Constantes.COD_MODALIDAD_URGENTE);
	}


	/**
	 * Permite preparar los datos a visualizarse en pantalla
	 * @param declaracion
	 * @return
	 */
	private Map<String,String> prepararDatos(Map<String, Object> declaracion) {
		Map<String,String> data = new HashMap<String, String>();
		String DAM = (declaracion.get("COD_ADUANA").toString()).concat("-").concat(((BigDecimal)declaracion.get("ANN_PRESEN")).toString()).concat("-").concat(declaracion.get("COD_REGIMEN").toString()).concat("-").concat(((BigDecimal)declaracion.get("NUM_DECLARACION")).toString());
		data.put("ADUANA", declaracion.get("COD_ADUANA").toString());
		data.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString());
		data.put("NUMERO_DAM", DAM);
		data.put("ORDEN", (String)declaracion.get("NUM_ORDEN"));
		FechaBean fecha = new FechaBean((Timestamp)declaracion.get("FEC_DECLARACION"));
		data.put("FECHA_DECLARACION", fecha.getFormatDate("dd/MM/yyyy HH:mm"));
		data.put("CANAL", (String)declaracion.get("COD_CANAL"));
		data.put("CANAL_DESC", (String)declaracion.get("COD_CANAL_DESC"));
		data.put("MODALIDAD", (String)declaracion.get("COD_MODALIDAD"));
		data.put("MODALIDAD_DESC", (String)declaracion.get("COD_MODALIDAD_DESC"));
		data.put("CTACTE", (org.springframework.util.StringUtils.hasText((String)declaracion.get("NUM_CTACTE")))? "SI" : "NO");
		data.put("CONSIGNATARIO", ((String)declaracion.get("NUM_DOCIDENT_PIM")).concat(" - ").concat((String)declaracion.get("NOM_RAZONSOCIAL_PIM")));
		data.put("RUC_CONSIGNATARIO", (String)declaracion.get("NUM_DOCIDENT_PIM"));
		data.put("DECLARANTE", ((String)declaracion.get("NUM_DOCIDENT_PDE")).concat(" - ").concat((String)declaracion.get("NOM_RAZONSOCIAL_PDE")));
		data.put("RUC_DECLARANTE", (String)declaracion.get("NUM_DOCIDENT_PDE"));
		data.put("numeroDeclaracionTitulo", (String)declaracion.get("numeroDeclaracionTitulo")); //p24 129 - PAS20165E220200099
		
		return data;
	}

	/**
	 * Permite publicar en el servicio de Avisos Electronicos la notificacion correspondiente a una Declaracion Observada
	 * @param parametros
	 * @throws ServiceException
	 */
	private void notificarDeclaracionObservada(Map<String, Object> parametros) throws ServiceException {
		log.info("$$ notificarDeclaracionObservada() [inicio]");
		log.info("## parametros : "+parametros);

		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");

		String[] usuarios = new String[]{ (String)parametros.get("RUC_CONSIGNATARIO"),(String)parametros.get("RUC_DECLARANTE") };

		Map<String,Object>mapDatos = new HashMap<String, Object>();
		String asunto = "Declaraci&oacute;n Observada : ".concat(parametros.get("NUMERO_DAM").toString());
		mapDatos.put("des_asunto", asunto);
		mapDatos.put("tip_usuario", Constantes.TIPO_USUARIO_AVISO_OCE);
		mapDatos.put("cod_usuario", usuarios);
		mapDatos.put("fechaAlerta", (new FechaBean()).getFormatDate("dd/MM/yyyy HH:mm:ss"));

		Map<String,Object> comunicado = new HashMap<String, Object>();
		comunicado.put("fecha_emision", (new FechaBean()).getFormatDate("dd/MM/yyyy"));
		comunicado.put("datos_consignatario", parametros.get("CONSIGNATARIO"));
		comunicado.put("datos_declarante", parametros.get("DECLARANTE"));
		comunicado.put("descDeclaracion", parametros.get("NUMERO_DAM"));

		String area = Constantes.DESC_AREA_NOTIFICA_OPERATIVA + " de la Aduana de " + catalogoAyudaService.getDescripcionDataCatalogo("00", parametros.get("ADUANA").toString());
		if (Constantes.COD_AREA_NOTIFICA_CENTRAL.equals(parametros.get("ADUANA"))){
			area = Constantes.DESC_AREA_NOTIFICA_CENTRAL;
		}
		comunicado.put("des_area", SunatStringUtils.convertirCaracteresEspecialesAHtml(area));

		mapDatos.putAll(comunicado);
		log.info("## mapDatos : "+mapDatos);

		JsonSerializer json = new JsonSerializer();			
		StringBuffer datos = new StringBuffer(json.serialize(mapDatos).toString());
		FechaBean fechaPublicacion = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		log.info("## datos : "+datos);
		Long numAviso;
		numAviso = publicacionAvisoService.insert(Constantes.SERVICIO_AVISO_PENDIENTE_DE_REGULARIZAR_OBSERVADA, datos, Constantes.TIPO_USUARIO_AVISO_OCE, fechaPublicacion.getTimestamp(),fechaVigencia.getTimestamp());
		if(log.isDebugEnabled())log.debug("SECUENCIA DEL AVISO: "+numAviso);

		log.info("$$ notificarDeclaracionObservada() [fin]");
	}

	//FIXME: RIN16 : lpalominom [fin]

	// FIXME: CUS110301 : lpalominom [inicio]
	/**
	 * {@inheritDoc}
	 */
	public Map<String,Object> validarBloqueoActualizacionDiligenciaRegularizacion(Map<String,Object> parametros){
		Map<String,Object> respuesta = new HashMap<String, Object>();

		// -- Buscamos la Declaracion
		Map<String, Object> declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(parametros), (String)parametros.get("cod_regimen"));
		log.info("## declaracion : " + declaracion);

		// -- Verificamos que la Declaracion Exista	        
		if ( declaracion == null || (declaracion != null && declaracion.isEmpty()) ){
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_NO_CARGADA);
			respuesta.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
		} else {
			// -- Obtenemos los parametros de Validacion
			Map<String, Object> p = new HashMap<String,Object>();
			p.put("COD_TIPDILIGENCIA", Constantes.REGULARIZADA_DE_OFICIO);
			p.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			RegularizacionBean regularizacionBean = diligenciaService.obtenerParametrosSegundaDiligencia(p);

			if (regularizacionBean != null){
				respuesta.put("regularizacionBean", regularizacionBean);
				if (regularizacionBean.getIndicadorCambio().equals(Constantes.TIPO_CAMBIO_BLOQUEADO)){
					respuesta.put("FLAG_NUMERO", Constantes.FLAG_ACTUALIZACION_N);
					respuesta.put("error", "El texto de la diligencia ya fue modificado");
				} else {
					respuesta.put("FLAG_NUMERO", Constantes.FLAG_ACTUALIZACION_2);
					respuesta.put("advertencia", "Declaraci�n ya cuenta con Diligencia de Regularizaci�n. �Desea Modificar el texto?");
				}
			} else {
				respuesta.put("FLAG_NUMERO", Constantes.FLAG_ACTUALIZACION_1);
			}
		}

		return respuesta;
	}

	/**
	 * {@inheritDoc}
	 */
	public Map<String,Object> validarActualizacionDiligenciaRegularizacion(Map<String,Object> parametros) {
		log.debug("@@ validarActualizacionDiligenciaRegularizacion() [inicio]");
		log.info("## parametros : "+parametros);
		Map<String,Object> respuesta = new HashMap<String, Object>();
		String mensaje = "";

		// -- Buscamos la Declaracion
		Map<String, Object> declaracion = obtenerDeclaracionPorRegimen(Utilidades.adaptarParametrosBD(parametros), (String)parametros.get("cod_regimen"));
		log.info("## declaracion : " + declaracion);

		// -- Verificamos que la Declaracion Exista	        
		if ( declaracion == null || (declaracion != null && declaracion.isEmpty()) ){
			respuesta.put("FLAG", Constantes.FLAG_DECLARACION_NO_CARGADA);
			mensaje = "La Declaraci�n no ha sido numerada en el SDA.";//p24
		} else {
			respuesta.put("declaracionRegularizada",declaracion);
			// -- Obtenemos los parametros de Validacion
			Map<String, Object> p = new HashMap<String,Object>();
			p.put("COD_TIPDILIGENCIA", Constantes.REGULARIZADA_DE_OFICIO);
			p.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			RegularizacionBean regularizacionBean = diligenciaService.obtenerParametrosSegundaDiligencia(p);

			declaracion.put("FEC_SOLICITUD_RECTI", obteniendoFechaTransmision(declaracion.get("NUM_CORREDOC")));

			if (regularizacionBean != null){
				respuesta.put("regularizacionBean",regularizacionBean);
				// -- Verificamos si es la primera modificacion del texto de la diligencia
				if (regularizacionBean.getIndicadorCambio().equals(Constantes.TIPO_CAMBIO_BLOQUEADO)){
					mensaje = "El texto de la diligencia ya fue modificado";
				} else {

					// -- Verificar que el Funcionario Aduanero sea el que Realizo la Regularizacion
					if (!regularizacionBean.getCodigoFuncionario().equals(parametros.get("codigoFuncionario"))) {
						mensaje = "El texto de la Diligencia de la Regularizaci�n s�lo puede ser modificada por el Funcionario Aduanero que lo Registro";
					} else {

						// -- Verificar Fecha Actual vs Fecha de Diligencia de Regularizacion
						Map<String, Object> paramDias = new HashMap<String, Object>();
						paramDias.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(regularizacionBean.getFechaDiligencia()));
						paramDias.put("NUMERODIAS", Constantes.PLAZO_DIAS_UTILIES_SEGUNDA_REGULARIZACION);
						paramDias.put("INCLUYE", Constantes.FLAG_CONSIDERA_DIA_SIGUIENTE);

						// -- FIXME : el famoso swapper da muchos problemas, mejor usamos el DataSourceContextHolder
						DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
						DataSourceContextHolder.setKeyDataSource((String)declaracion.get("COD_ADUANA"));
						String fechaPlazo = diasUtilesDAOsolicitud.getSPFechaDias(paramDias);
						String fechaActual = SunatDateUtils.getFormatDate(regularizacionBean.getFechaActual(), "yyyyMMdd");

						if (Integer.valueOf(fechaActual) > Integer.valueOf(fechaPlazo)  ) {
							mensaje = "Han transcurridos m�s de dos d�as h�biles desde el registro de la diligencia de regularizaci�n. No es posible modificar";
						} else {

							// -- Verificar si se Realizaron Diligencias del tipo 05, 06 y 10 posterior a la fecha de la diligencia tipo 07
							StringBuffer sb = new StringBuffer("No es posible modificar el texto de la diligencia al haberse realizado el/los proceso(s) de ");
							boolean flagControl = false;

							if (regularizacionBean.getNumeroDiligConclusionDespacho() > 0) {
								sb.append(" Conclusi�n de Despacho,");
								flagControl = true;
							}

							if (regularizacionBean.getNumeroDiligRectElectronica() > 0) {
								sb.append(" Rectificaci�n Electr�nica,");
								flagControl = true;
							}

							if (regularizacionBean.getNumeroDiligRectOficio() > 0) {
								sb.append(" Rectificaci�n de Oficio,");
								flagControl = true;
							}

							if (flagControl){
								mensaje = sb.toString();
								int longitud = mensaje.length();
								if (mensaje.endsWith(",")){
									mensaje.substring(0, longitud-2);
								}
							}

						}

						// -- Para el Regimen 70 (Deposito): Verificar Fecha de Vencimiento no sea mayor a la fecha actual
						if (Constantes.REGIMEN_70_DEPOSITO.equals(parametros.get("cod_regimen"))) {
							String fechaRegimen = SunatDateUtils.getFormatDate((Date)declaracion.get("FEC_VENREGIMEN"),"yyyyMMdd");
							if (Integer.valueOf(fechaRegimen) < Integer.valueOf(fechaActual)){
								mensaje = "El plazo del r�gimen de dep�sito se encuentra vencido. No es posible modificar.";
							}
						}

					}

				}

			}
		}

		// -- No hay Errores
		if ("".equals(mensaje)){
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			params.put("COD_TIPSOL", "11");
			String numCorredocSol = relacionDocDAO.findSolicitudByDocumento(params);
			declaracion.put("NUM_CORREDOC_SOL", numCorredocSol);
		}

		respuesta.put("error", mensaje);
		log.info("## mensaje : " + mensaje);
		log.debug("@@ validarActualizacionDiligenciaRegularizacion() [fin]");
		return respuesta;
	}

	// FIXME: CUS110301 : lpalominom [fin]


	/***** GGRANADOS RIN16PASE3 INI *****/
	public String procesarCambioModalidadRegularizacion(String codModalidad,
			String codModalidadActual, 
			boolean tieneIndicadorRegularizable,
			boolean tieneIndicadorRegularizableActual) {
		if (!codModalidad.equals(codModalidadActual)
				|| tieneIndicadorRegularizable != tieneIndicadorRegularizableActual) {
			if (cambiaARegularizable(codModalidad, 
					codModalidadActual,
					tieneIndicadorRegularizable,
					tieneIndicadorRegularizableActual)) {
				//actualizar fecha de vencimiento de la regularizacion
				//actualizar estado de la regularizacion
				return pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_REGULARIZABLE;

			} else if (cambiaANoRegularizable(codModalidad, 
					codModalidadActual,
					tieneIndicadorRegularizable,
					tieneIndicadorRegularizableActual)) {
				//limpiar fecha de vencimiento de la regularizacion
				//limpiar estado de la regularizacion
				return pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_NO_REGULARIZABLE;
			}

		}
		return pe.gob.sunat.despaduanero2.ayudas.util.Constantes.NO_CAMBIA_MODALIDAD;
	}	

	public void limpiarDatosRegularizacion(Long numCorreDoc){
		Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
		paramCabDeclara.put("FEC_VENCREGULA", SunatDateUtils.getDefaultDate());
		paramCabDeclara.put("COD_ESTREGUL", " ");
		paramCabDeclara.put("NUM_CORREDOC", numCorreDoc);
		cabDeclaraDAO.update(paramCabDeclara);
	}

	public void actualizarDatosRegularizacion(DUA dua){

		if (dua.getManifiesto().getNummanif() != null){			

			Map<String, Object> dataManif = new HashMap<String, Object>();

			dataManif.put("numeroManifiesto", SunatStringUtils.lpad(dua.getManifiesto().getNummanif().toString().trim(), 6, ' '));
			dataManif.put("anioManifiesto", SunatStringUtils.length(dua.getManifiesto().getAnnmanif()) > 3 ? dua.getManifiesto().getAnnmanif().substring(0, 4) : null);
			dataManif.put("codigoAduana", dua.getManifiesto().getCodaduamanif());
			dataManif.put("codigoTipoManifiesto", dua.getManifiesto().getCodtipomanif());
			dataManif.put("codigoViaTransporte", dua.getManifiesto().getCodmodtransp());

			CabManifiestoDAO cabManifiestoDAO = fabricaDeServicios.getService("manifiesto.manifiestoDAO");
			List<Manifiesto> listManifiesto = cabManifiestoDAO.listByParameterMap(dataManif);
			if(!CollectionUtils.isEmpty(listManifiesto)){
				Manifiesto manifiesto = listManifiesto.get(0);
				if(!SunatDateUtils.isDefaultDate(manifiesto.getFechaTerminoDeDescarga())){
					Date fechVencimientoRegu = SunatDateUtils.addDay(manifiesto.getFechaTerminoDeDescarga(), 
							Constantes.PLAZO_VENCIMIENTO_REGULARIZACION);    		

					Map<String, Object> paramDias = new HashMap<String, Object>();
					paramDias.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechVencimientoRegu));
					paramDias.put("FECHAHASTA", 0);
					paramDias.put("TIPO", pe.gob.sunat.despaduanero2.ayudas.util.Constantes.SUMAR_DIAS);
					paramDias.put("INCLUYE", "S");
					paramDias.put("SUSPENDE", "S");	    		
					DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
					DataSourceContextHolder.setKeyDataSource(dua.getCodaduanaorden());
					String resultadoDiaUtil = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias); // yyyyMMdd
					Date fechVencimientoReguUtil = SunatDateUtils.getDateFromInteger(Integer.parseInt(resultadoDiaUtil));	    		
					Date fechaHoy = new Date();
					String codEstRegul = Constantes.PENDIENTE_DE_REGULARIZAR;

					if(SunatDateUtils.esFecha1MayorQueFecha2(fechaHoy, fechVencimientoRegu, SunatDateUtils.COMPARA_SOLO_FECHA)){
						codEstRegul = Constantes.PENDIENTE_DE_REGULARIZAR_FUERA_DEL_PLAZO;
					}

					Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
					paramCabDeclara.put("FEC_TERM", manifiesto.getFechaTerminoDeDescarga());
					paramCabDeclara.put("FEC_VENCREGULA", fechVencimientoReguUtil);
					paramCabDeclara.put("COD_ESTREGUL", codEstRegul);
					paramCabDeclara.put("NUM_CORREDOC", dua.getNumcorredoc());
					cabDeclaraDAO.update(paramCabDeclara);

				}else{
					String codEstRegul = Constantes.PENDIENTE_DE_REGULARIZAR;

					Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
					paramCabDeclara.put("COD_ESTREGUL", codEstRegul);
					paramCabDeclara.put("NUM_CORREDOC", dua.getNumcorredoc());
					cabDeclaraDAO.update(paramCabDeclara);

				}

			}else{
				String codEstRegul = Constantes.PENDIENTE_DE_REGULARIZAR;

				Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
				paramCabDeclara.put("COD_ESTREGUL", codEstRegul);
				paramCabDeclara.put("NUM_CORREDOC", dua.getNumcorredoc());
				cabDeclaraDAO.update(paramCabDeclara);
			}

		}else {
			String codEstRegul = Constantes.PENDIENTE_DE_REGULARIZAR;

			Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
			paramCabDeclara.put("COD_ESTREGUL", codEstRegul);
			paramCabDeclara.put("NUM_CORREDOC", dua.getNumcorredoc());
			cabDeclaraDAO.update(paramCabDeclara);		
		}

	}


	private boolean cambiaANoRegularizable(String codModalidad,
			String codModalidadActual, 
			boolean tieneIndicadorRegularizable,			
			boolean tieneIndicadorRegularizableActual) {
		if((esAnticipadaRegularizable(codModalidad, tieneIndicadorRegularizable) || esUrgente(codModalidad)) 
				&& esExcepcional(codModalidadActual)){
			return true;
		}

		if(esAnticipadaRegularizable(codModalidad, tieneIndicadorRegularizable) && 
				esAnticipadaNoRegularizable(codModalidadActual, tieneIndicadorRegularizableActual)){
			return true;
		}

		return false;
	}

	private boolean cambiaARegularizable(String codModalidad, 
			String codModalidadActual, 
			boolean tieneIndicadorRegularizable,			
			boolean tieneIndicadorRegularizableActual) {
		if((esAnticipadaNoRegularizable(codModalidad, tieneIndicadorRegularizable) && 
				esAnticipadaRegularizable(codModalidadActual, tieneIndicadorRegularizableActual))){
			return true;
		}

		if((esAnticipadaRegularizable(codModalidad, tieneIndicadorRegularizableActual) || esUrgente(codModalidad)
				&& esExcepcional(codModalidadActual))){
			return true;
		}

		return false;
	}

	private boolean esExcepcional(String codModalidadActual) {
		return codModalidadActual.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL);
	}

	private boolean esUrgente(String codModalidad) {
		return codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE);
	}

	private boolean esAnticipadaRegularizable(String codModalidad,
			boolean tieneIndicadorRegularizable) {
		if(codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && tieneIndicadorRegularizable){
			return true;
		}
		return false;
	}

	private boolean esAnticipadaNoRegularizable(String codModalidad,
			boolean tieneIndicadorRegularizable) {
		if(codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && !tieneIndicadorRegularizable){
			return true;
		}
		return false;
	}

	/**
	 * 
	 */
	public boolean tieneIndicadorRegularizable(List<Map<String, Object>> lstIndicadorDua) {
		if(CollectionUtils.isEmpty(lstIndicadorDua)){
			return false;
		}
		for (Map<String, Object> indicadorDua : lstIndicadorDua) {
			if(indicadorDua.get("COD_INDICADOR").equals(ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION)){
				return true;
			}
		}
		return false;
	}

	/***** GGRANADOS RIN16PASE3 INI *****/
	public Map<String, Object> getDatosParaEvaluarCambioModalidad(
			Map<String, Object> mapDatos) {
		Map<String, Object> mapCabDeclara = (Map<String, Object>) mapDatos.get("mapCabDeclara");
		Map<String, Object> mapCabDeclaraActual = (Map<String, Object>) mapDatos.get("mapCabDeclaraActual");
		List<Map<String, Object>> lstIndicadorDua = (List<Map<String, Object>>) mapDatos.get("lstIndicadorDua");
		List<Map<String, Object>> lstIndicadorDuaActual = (List<Map<String, Object>>) mapDatos.get("lstIndicadorDuaActual");

		String codModalidad = MapUtils.getMapValor(mapCabDeclara,"COD_MODALIDAD");
		String codModalidadActual = MapUtils.getMapValor(mapCabDeclaraActual,"COD_MODALIDAD");

		boolean tieneIndicadorRegularizable = tieneIndicadorRegularizable(lstIndicadorDua);
		boolean tieneIndicadorRegularizableActual = tieneIndicadorRegularizable(lstIndicadorDuaActual);

		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("codModalidad", codModalidad);
		respuesta.put("codModalidadActual", codModalidadActual);
		respuesta.put("tieneIndicadorRegularizable",
				tieneIndicadorRegularizable);
		respuesta.put("tieneIndicadorRegularizableActual",
				tieneIndicadorRegularizableActual);

		return respuesta;
	}

	public Map<String, Object> getDatosParaEvaluarCambioModalidad(
			Declaracion declaracion, Declaracion declaracionBD){
		String codModalidad = declaracionBD.getDua().getCodmodalidad();
		String codModalidadActual = declaracion.getDua().getCodmodalidad();

		boolean tieneIndicadorRegularizable = tieneIndicadorRegularizable(declaracionBD.getDua().getListIndicadores());
		boolean tieneIndicadorRegularizableActual = tieneIndicadorRegularizable(declaracion.getDua().getListIndicadores());

		Map<String, Object> respuesta = new HashMap<String, Object>();
		respuesta.put("codModalidad", codModalidad);
		respuesta.put("codModalidadActual", codModalidadActual);
		respuesta.put("tieneIndicadorRegularizable", tieneIndicadorRegularizable);
		respuesta.put("tieneIndicadorRegularizableActual", tieneIndicadorRegularizableActual);

		return respuesta;
	}

	private boolean tieneIndicadorRegularizable(
			Elementos<DatoIndicadores> listIndicadores) {
		if(CollectionUtils.isEmpty(listIndicadores)){
			return false;
		}
		for (DatoIndicadores indicador : listIndicadores) {
			if(indicador.getCodtipoindica()!=null && indicador.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION)){
				return true;
			}
		}
		return false;
	}
	/***** GGRANADOS RIN16PASE3 FIN *****/

	//INICIO RIN08
	public Map<String, Object> validarDeclaParaDespachoAduanaDestino(Map<String, Object> params) throws ServiceException
	{

		Map<String, Object> declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
		//String acceso = params.get("acceso") != null ? params.get("acceso").toString().trim() : "";
		//String acceso = MapUtils.getMapValor(params, "acceso");
		//String msgDeudas = "";
		try
		{
			//if (declaracion == null)
			if(MapUtils.esMapaNulo(declaracion))
			{
				declaracion = new HashMap<String, Object>();
				declaracion.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return declaracion;
			}

			//rin08
			Map<String, Object> param= new HashMap<String, Object>();
			param.put("numCorreDoc", declaracion.get("NUM_CORREDOC"));
			param.put("inddel", Constants.INDICADOR_NO_ELIMINADO);        
			Elementos<DatoSerie> series = new Elementos<DatoSerie>();
			series.addAll(detDeclaraDAO.findSerie(param));
			boolean esPecoAmazonia=false;
			List<Map<String,Object>> lstConv;
			Map<String,Object> paramConvSerie=new HashMap<String, Object>();  
			for (DatoSerie serie :series) {

				paramConvSerie.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
				paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
				paramConvSerie.put("COD_TIPCONVENIO", "C"); //4438 LEY AMAZONIA RIN08
				lstConv=convenioSerieDAO.select(paramConvSerie);
				for(Map<String,Object> beanMap:lstConv){
					if ( ConstantesDataCatalogo.COD_TIP_4438.equals(beanMap.get("COD_CONVENIO").toString().trim()) ){
						esPecoAmazonia=true;
						break;
					}

				}

				if  (!esPecoAmazonia) {
					paramConvSerie.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
					paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
					paramConvSerie.put("COD_TIPCONVENIO", "I"); //34,35,36 PECO
					lstConv=convenioSerieDAO.select(paramConvSerie);	
					for(Map<String,Object> beanMap:lstConv){
						if ( ConstantesDataCatalogo.COD_TIP_34.equals(beanMap.get("COD_CONVENIO").toString().trim()) ||
								ConstantesDataCatalogo.COD_TIP_35.equals(beanMap.get("COD_CONVENIO").toString().trim()) ||
								ConstantesDataCatalogo.COD_TIP_36.equals(beanMap.get("COD_CONVENIO").toString().trim())
								){
							esPecoAmazonia=true;
							break;
						}

					}

				}

				if  (esPecoAmazonia) {
					break;

				}

				/* if(!CollectionUtils.isEmpty(lstConv)){
	esPecoAmazonia=true;
	break;
	}else{
	paramConvSerie.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
	paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
	   paramConvSerie.put("COD_TIPCONVENIO", "I"); //314,315,316
	   lstConv=convenioSerieDAO.select(paramConvSerie);
	   if(!CollectionUtils.isEmpty(lstConv)){
	esPecoAmazonia=true;
	break;
	}
	}*/

			}

			String fechaAutorizacioLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(declaracion.get("FEC_AUTLEVANTE"));
			boolean tieneAutorizacionLevante = !fechaAutorizacioLevante.equals(Constantes.DEFAULT_FECHA_BD);

			if(!tieneAutorizacionLevante){
				declaracion.put("error","Declaraci�n no tiene levante autorizado");
				return declaracion;
			}

			if  (!esPecoAmazonia) {
				declaracion.put("error", "La declaraci�n no se encuentra acogida a PECO y/o Ley de Amazon�a.");
				return declaracion;
			}  

			params.put("cod_grupo", "GAD");// ConstantesDataCatalogo.GRUPO_DESPACHO_ADUANA_DESTINO
			String codFuncionario = StringUtils.defaultString(espeDocuDAO.findEspecAsigByDocumento(params));
			if (!codFuncionario.equalsIgnoreCase((String) params.get("codigoFuncionario").toString().trim())){
				declaracion.put("error", "El Usuario no tiene asignada la Declaraci�n.");  
				return declaracion;
			}


			Map<String, Object> paramsUpper=new HashMap<String, Object>();
			paramsUpper.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC"));
			Date fecAutLevante = cabDeclaraDAO.findFecAutLevante(paramsUpper);
			if (fecAutLevante.equals((DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD, "dd/MM/yyyy")))) {
				// declaracion.put("error", "La declaraci�n no cuenta con levante.");  
				// return declaracion;
			}

			// Obtenemos la lista de boletines quimicos sin concluir
			Map<String, Object> pkDecla=new HashMap<String, Object>();
			pkDecla.put("caduana",  params.get("cod_aduana").toString());
			pkDecla.put("CADUA_DUA",  params.get("cod_aduana").toString());
			pkDecla.put("NANNO_DUA", params.get("ann_presen").toString());
			pkDecla.put("CREG_DUA", params.get("cod_regimen").toString());
			pkDecla.put("NCORR_DUA", Cadena.padLeft(params.get("num_declaracion").toString(), 6, '0'));
			List<Map<String, Object>> lstBol= soporteService.obtenerBoletinQuimico(pkDecla);
			for(int i=0;i<lstBol.size();i++){
				if (  !("0".equals(lstBol.get(i).get("SESTA_ANALIS")) || "3".equals(lstBol.get(i).get("SESTA_ANALIS")) || "4".equals(lstBol.get(i).get("SESTA_ANALIS")) ) ){
					declaracion.put("error", "Bolet�n Qu�mico pendiente."); 
					return declaracion;
				}

			}

			// Obtenemos una lista que indica si tiene solicitud de rectificacion y regularizacion
			List<Map<String, Object>> lstSol = solicitudService.buscarRectiyReguPend(new Long(declaracion.get("NUM_CORREDOC").toString()));
			Map<String, Object> solicitud;
			for (int i=0; i<lstSol.size();i++){
				solicitud=lstSol.get(i);
				if ("363".equals(solicitud.get("COD_CATESTADO")) &&  ("02".equals(solicitud.get("COD_ESTARECTI")) || "03".equals(solicitud.get("COD_ESTARECTI")) || "04".equals(solicitud.get("COD_ESTARECTI")) ) ){//02, 03,04
					declaracion.put("error", "La declaraci�n tiene rectificaci�n pendiente."); 
					return  declaracion;
				}else  if ("329".equals(solicitud.get("COD_CATESTADO")) && ("01".equals(solicitud.get("COD_ESTARECTI")) || "03".equals(solicitud.get("COD_ESTARECTI")) || "05".equals(solicitud.get("COD_ESTARECTI")) || "06".equals(solicitud.get("COD_ESTARECTI")) )    ){//01, 03, 05, 06
					declaracion.put("error", "La declaraci�n tiene Diligencia de Regularizaci�n pendiente."); 
					return  declaracion;
				}

			}

			String cadenaSeries="";
			String separador="";
			for(int i=0;i<lstBol.size();i++){
				if ( "4".equals(lstBol.get(i).get("SESTA_ANALIS")) ){
					cadenaSeries=separador.concat(cadenaSeries.concat(lstBol.get(i).get("NSERIE_DUA")!=null?lstBol.get(i).get("NSERIE_DUA").toString():""));
					separador=",";

				}

			}   

			if (cadenaSeries.length()>0){
				declaracion.put("avisoBoletin", "Declaraci�n con Bolet�n Qu�mico No Ratificado para las series[".concat(cadenaSeries).concat("]")); 
				return declaracion;
			}


			//fin rin08  


		}
		catch (Exception e)
		{
			log.error(e);
		}
		return declaracion;
	}


	public  Expedi findExpediDocAsociadoPecoAmazonia(Map<String, Object> params) {
		// Se debe buscar por documento origen y tambien por documento de referencia	  
		//return expediDAO.findExpediDocAsociadoPecoAmazonia(params);
		Expedi expediDocAsociado = new Expedi();
		ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		List<Map<String, Object>> listExpediMap = expedienteService.findByDocumentoOrigen(params);
		if (CollectionUtils.isEmpty(listExpediMap)) {
			//List<Expedi> listExpedi = expediDAO.findExpediDocReferencia(params);
			List<Expedi> listExpedi = expedienteService.findExpediDocReferencia(params);
			if (!CollectionUtils.isEmpty(listExpedi)){
				expediDocAsociado = listExpedi.get(0);
			}
		}else {
			expediDocAsociado.setCodiAdua(SunatStringUtils.toStringObj(listExpediMap.get(0).get("CODI_ADUA")));
			expediDocAsociado.setComitNro(SunatStringUtils.toStringObj(listExpediMap.get(0).get("COMIT_NRO")));
			expediDocAsociado.setFecexp(SunatNumberUtils.getIntegerFromString(listExpediMap.get(0).get("FECEXP").toString()));
			expediDocAsociado.setNroexpedi(SunatNumberUtils.getIntegerFromString(listExpediMap.get(0).get("NROEXPEDI").toString()));
			expediDocAsociado.setAnoexpedi(listExpediMap.get(0).get("ANOEXPEDI").toString());
			
		}
		return expediDocAsociado;
	}


	public List<Map<String, Object>> obtenerDeclaracionImportador(Map<String, Object> params) {
		return cabDeclaraDAO.obtenerDeclaracionImportador(params);

	}
	//FIN RIN08	

	/* P14 - 3014 - Inicio - lrodriguezc */

	@Override
	public List<IndicadorDeclaracionDescripcion> obtenerIndicadoresDuaAll(Long numCorrelativo) {

		List<IndicadorDeclaracionDescripcion> resultado = null;

		try{
			resultado = this.indicadorDuaDAO.findByDocumentoAll(numCorrelativo);
		} catch (Exception e){
			throw new ServiceException(this, "Ocurrio un error de base de datos buscar indicadores de la dua");
		}

		return resultado;

	}

	/* P14 - 3014 - Final - lrodriguezc */

	/* P14 - 3004 - Inicio - lrodriguezc */
	/* CUS: 3004-01 - Inicio - lrodriguezc */

	@Override
	public DatoIndicadores obtenerIndicadorDeclaracion(String numCorreDoc, String codIndicador) { 

		Map<String, Object> parametros = new HashMap<String, Object>();
		DatoIndicadores indicadorDeclaracion = null;

		parametros.put("num_corredoc", numCorreDoc);
		parametros.put("cod_indicador", codIndicador);

		indicadorDeclaracion = indicadorDuaDAO.obtenerIndicadorDeclaracion(parametros);

		return indicadorDeclaracion;

	}

	/* CUS: 3004-01 - Final - lrodriguezc */
	/* P14 - 3004 - Final - lrodriguezc */

	/* P14 - 3006 - Inicio - lrodriguezc */

	@Override
	public Map<String, Object> validarRecepcionRespuestaNotificacion(Map<String, Object> params, UsuarioBean usuarioBean){

		Map<String, Object> declaracion = new HashMap<String, Object>();
		Map<String, String> error = new HashMap<String, String>();

		Long numCorreDoc = null;

		List<ComunicacionDescripcion> listaComunicacionesPendientes = null;
		/*inicio mpoblete BUG*/
		//int numeroComunicacionesPendientes = 0;
		/*fin mpoblete BUG*/
		ComunicacionDescripcion ultimaComunicacion = new ComunicacionDescripcion();
		String detalleNotificacion;
		List<Map<String, Object>> detallesFuncionario = null;
		StringBuffer construccionFuncionario = new StringBuffer("");
		String descripcionFuncionario;
		/*inicio mpoblete BUG*/
		try {
			/*fin mpoblete BUG*/	

			declaracion = cabDeclaraDAO.findByDeclaracion(params);

			if (MapUtils.esMapaNulo(declaracion)) {

				declaracion = new HashMap<String, Object>();
				declaracion.put("error", "La Declaraci�n no ha sido numerada en el SDA.");//p24
				return declaracion;

			} else {

				// En espera de los demas roles (se puso la negaci�n)

				boolean validarRol = true;
				/*inicio mpoblete BUG*/
				/*if (((Map)usuarioBean.getMap().get("roles")).containsKey("SUPERVISOR.DE.OFICIALES")) {*/
				if (((Map)usuarioBean.getMap().get("roles")).containsKey("SUPERVISOR DE OFICIALES")) {
					/*fin mpoblete BUG*/	
					if (declaracion.get("COD_MODALIDAD").equals(Constantes.MODALIDAD_URGENTE)) {

						validarRol = true;

					} else {

						validarRol = false;

					}

				} else {

					validarRol = true;

				}

				if(!validarRol){

					error = catalogoAyudaService.getError(Constantes.COD_ERROR_ROL_SUP_OFIC_RESP_NOTI);
					declaracion.put("error", error.get("desError"));

				} else if (Constantes.ESTADO_MERCANCIA_DISPUESTA_TOTALMENTE.equals(declaracion.get("COD_ESTDUA"))) {

					error = catalogoAyudaService.getError(Constantes.COD_ERROR_MERC_DISPUESTA_TOTAL);
					declaracion.put("error", error.get("desError"));

				} else if ( Constantes.ESTADO_DECLARACION_REVISION.equals(declaracion.get("COD_ESTDUA"))
						|| Constantes.ESTADO_NOTIFICADO.equals(declaracion.get("COD_ESTDUA")) || Constantes.ESTADO_CONCLU_NOTIFICADO.equals(declaracion.get("COD_ESTDUA")) //P14 - diligencia de Conclusion
						|| Constantes.DILIG_PREV_ANTIC_ROJO.equals(declaracion.get("COD_ESTDUA"))
						|| !SunatDateUtils.isDefaultDate((Date) declaracion.get("FEC_AUTLEVANTE"))) {

					numCorreDoc = Long.parseLong(declaracion.get("NUM_CORREDOC").toString());

					listaComunicacionesPendientes = diligenciaService.obtenerComunicacionesPendientes(numCorreDoc);
					/*inicio mpoblete flag*/
					//numeroComunicacionesPendientes = listaComunicacionesPendientes.size();
					boolean tieneComunicacionesPendientes = (listaComunicacionesPendientes!=null && !listaComunicacionesPendientes.isEmpty());
					/*if ( numeroComunicacionesPendientes != 0){*/
					if (tieneComunicacionesPendientes){	
						//ultimaComunicacion = listaComunicacionesPendientes.get(numeroComunicacionesPendientes - 1);
						ultimaComunicacion = listaComunicacionesPendientes.get(listaComunicacionesPendientes.size() - 1);
						/*fin mpoblete flag*/
						log.info(ultimaComunicacion.getFeRegistro().toString());

						//inicio mpoblete BUG
						//detalleNotificacion = catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_MOTIVOS_NOTIFICACION, ultimaComunicacion.getCodMotNoti());
						if(StringUtil.noEsVacio(ultimaComunicacion.getCodMotNoti())){
							detalleNotificacion = catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CATALOGO_MOTIVOS_NOTIFICACION, ultimaComunicacion.getCodMotNoti());	
						}else{
							detalleNotificacion ="";
						}
						//fin mpoblete BUG
						pe.gob.sunat.rrhh2.service.ConsultaService consultaServiceRRHH = (pe.gob.sunat.rrhh2.service.ConsultaService) fabricaDeServicios.getService("rrhh2.service.consultaService");
						//inicio mpoblete BUG
						//detallesFuncionario = consultaServiceRRHH.consultarPersonal(ultimaComunicacion.getCodUsuRegistro(), null, null);
						Map<String,Object> parametroBusquedaRRHH = new HashMap<String, Object>();
						parametroBusquedaRRHH.put("cod_pers", ultimaComunicacion.getCodUsuRegistro());
						parametroBusquedaRRHH.put("orderby",Constantes.ORDENAR_REGISTROS);						
						detallesFuncionario = consultaServiceRRHH.consultarPersonal(parametroBusquedaRRHH);
						//fin mpoblete BUG
						if (detallesFuncionario!=null && detallesFuncionario.size()>0){
							construccionFuncionario.append(detallesFuncionario.get(0).get("t02nombres"));
							construccionFuncionario.append(" ");
							construccionFuncionario.append(detallesFuncionario.get(0).get("t02ap_pate"));
							construccionFuncionario.append(" ");
							construccionFuncionario.append(detallesFuncionario.get(0).get("t02ap_mate"));
						}
						descripcionFuncionario = construccionFuncionario.toString();

						ultimaComunicacion.setDesNota(diligenciaService.obtenerConsolidadoDetalleNotificacion(ultimaComunicacion));

						ultimaComunicacion.setDesMotivoNotificacion(detalleNotificacion);
						ultimaComunicacion.setDesUsuarioRegistro(descripcionFuncionario);

						/* P14 - 3006 - mpoblete BUG 19143 - Inicio */
						ultimaComunicacion.setFecRegistroString(SunatDateUtils.getFormatDate(ultimaComunicacion.getFeRegistro(),Constantes.FORMAT_DATE_HORA12));
						/* P14 - 3006 - mpoblete BUG 19143 - Fin */
						declaracion.put("ultimaComunicacion", ultimaComunicacion);
						declaracion.put("error", "");

					} else {

						error = catalogoAyudaService.getError(Constantes.COD_ERROR_NOTIF_PEND_RESPUESTA);
						declaracion.put("error", error.get("desError"));

					}

				} else {

					error = catalogoAyudaService.getError(Constantes.COD_ERROR_NOTIF_PEND_RESPUESTA);
					declaracion.put("error", error.get("desError"));

				}

			}
			/*inicio mpoblete BUG*/
		}catch(ServiceException e){	
			log.debug(this,e);
			log.error(this,e);
			declaracion = new HashMap<String, Object>();
			declaracion.put("error",Constantes.PAGM_MSJ_ERROR.concat(Constantes.SALTO_LINEA).concat(Constantes.PAGM_MSJ_SOL));
			return declaracion;			
		}
		/*fin mpoblete BUG*/
		return declaracion;

	}


	//lmvr
	private Manifiesto buscarManifiesto(DUA dua) throws Exception {

		DatoManifiesto dataManifiesto = dua.getManifiesto();

		if (dataManifiesto == null || StringUtils.isBlank(dataManifiesto.getNummanif())) {
			return null;
		}
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("COD_TIPMANIFIESTO", dataManifiesto.getCodtipomanif());
		param.put("COD_VIATRANS", dataManifiesto.getCodmodtransp());
		param.put("COD_ADUAMANIFIESTO", dataManifiesto.getCodaduamanif());
		param.put("ANN_MANIFIESTO", dataManifiesto.getAnnmanif());
		param.put("NUM_MANIFIESTO", dataManifiesto.getNummanif());

		boolean buscarManifiestoSigadActual = false;
		//buscarManifiestoSigadActual = ("4".equals(dataManifiesto.getCodmodtransp()) || "7".equals(dataManifiesto.getCodmodtransp()));
		buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(dataManifiesto.getCodmodtransp()) || ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(dataManifiesto.getCodmodtransp()));
		
		ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
		/*Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(param.get("COD_TIPMANIFIESTO").toString(),
				param.get("COD_VIATRANS").toString(), param.get("COD_ADUAMANIFIESTO").toString(),
				Integer.parseInt(param.get("ANN_MANIFIESTO").toString()), param.get("NUM_MANIFIESTO").toString(), buscarManifiestoSigadActual);*/

		/**PAS20181U220200049 inicio***/
		Manifiesto manifiesto = null;
		Date fechaReferencia = dua.getFecdeclaracion()!=null?dua.getFecdeclaracion():new Date();		
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
	 		boolean evaluarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			buscarManifiestoSigadActual = true;//que busque en bdsigad y en sigad
	 		manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(param.get("COD_TIPMANIFIESTO").toString(),
					param.get("COD_VIATRANS").toString(), param.get("COD_ADUAMANIFIESTO").toString(),
					Integer.parseInt(param.get("ANN_MANIFIESTO").toString()), param.get("NUM_MANIFIESTO").toString(),true, fechaReferencia,evaluarEER);			
	 	}else{/**PAS20181U220200049 fin***/

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", ConstantesDataCatalogo.COD_VIG_SALIDA_DEPOSITO_OP_DEP_TEMPORAL_EER_POSTAL,new Date());
			if (!CollectionUtils.isEmpty(MapaValManNum)){
				buscarManifiestoSigadActual = true;//busca en sda y sigad para casos de postal//pase11
			}

			manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(param.get("COD_TIPMANIFIESTO").toString(),
					param.get("COD_VIATRANS").toString(), param.get("COD_ADUAMANIFIESTO").toString(),
					Integer.parseInt(param.get("ANN_MANIFIESTO").toString()), param.get("NUM_MANIFIESTO").toString(), buscarManifiestoSigadActual);
	 	}
		return manifiesto;
	}



	public boolean  buscarNotaTarjaSigad(DUA dua)



			throws ServiceException
	{
		//dua = null;
		try
		{
			Manifiesto manifiesto = buscarManifiesto(dua);

			if (manifiesto == null || manifiesto.getNumeroCorrelativo() == null) {
				return false;
			}

			String codigoViaTransporte = manifiesto.getViaTransporte().getCodDatacat();
			Integer anioManifiesto = manifiesto.getAnioManifiesto();
			String numeroManifiesto = manifiesto.getNumeroManifiesto();
			String codigoAduana = manifiesto.getAduana().getCodDatacat();

			DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
			Map<String, Object> paramDetDeclara = new HashMap<String, Object>();
			paramDetDeclara.put("NUM_CORREDOC",dua.getNumcorredoc());
			List<Map<String, Object>> listSerieMap = detDeclaraDAO.select(paramDetDeclara);
			int contador = 0;
			boolean tieneTarja = false;
			String mcdetabase = ""; 
			for (Map<String, Object> serieMap : listSerieMap) {
				ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
				List<Mcdeta> listMcdeta = manifiestoSigadService.getListMcdetaByNumeroBL( codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, serieMap.get("NUM_DOCTRANSP") .toString());
				if (listMcdeta.size() > 0) {

					Mcdeta mcdeta = listMcdeta.get(0);
					if (SunatStringUtils.isEqualTo(mcdeta.getDocumentoDeTransporte().getNumeroDocumentoTransporte().toString(),mcdetabase))
						continue;

					if (!mcdeta.getDocumentoOABL().getStrFechaInicioOperacion().equals("0")) {
						tieneTarja = true;
						//break;
						return true;
					} else {
						contador++;
					} 
					mcdetabase = mcdeta.getDocumentoDeTransporte().getNumeroDocumentoTransporte().toString();
				} else {
					//grabaTelelog(listError, "00122", "DOCUMENTO DE TRANSPORTE NO REGISTRADO EN MANIFIESTO ENVIADO");
					return false;
				}
			}
			if (contador >= 1 && !tieneTarja) {
				//grabaTelelog(listError, "11508", "NO SE HA REALIZADO EL PROCESO DE TARJA PARA EL DOCUMENTO DE TRANSPORTE");
				return false;
			}


		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error de base de datos buscar Nota  tarja Sigad");
		}

		return false;
	}

	//RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
	public Map<String, Object> buscarDUAconDiligenciaAsociada(Map<String, Object> params)
			throws ServiceException{
		Map<String, Object> dua = null;
		try{
			dua = this.cabDeclaraDAO.buscarDUAconDiligenciaAsociada(params);
		}catch (Exception e){
			//throw new ServiceException(this, "Ocurrio un error de base de datos buscar documentos");
			throw new DiligenciaException();
		}
		return dua;
	}
	//RTINEO: FIN	
	/* CUS: 3006-01 - Migrado - Rin 03 - Final - lrodriguezc */
	/* P14 - 3006 - Final - lrodriguezc */

	//	<RIN10> 3014 ERUESTAA
	/** @author ERUESTAA 
	 * Obtiene los datos adicionales de una DUA
	 * **/
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#obtenerDatosAdicionalesDuaByPk(java.lang.String)
	 */
	public DUA obtenerDatosAdicionalesDuaByPk(Map<String, Object> params){
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("numcorredoc", params.get("numCorreDoc"));				
		DUA adideclara = new DUA();

		adideclara = this.cabAdiDeclaraDAO.getByPrimaryKey(paramsMap);

		return adideclara;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#listarExpedientes(java.util.Map)
	 */
	public List<Map<String, Object>> listarExpedientes(Map<String, Object> params)
			throws ServiceException
			{		
		List<Map<String,Object>> listaExpedientes= new ArrayList<Map<String,Object>>();
		Map<String,Object> item=null;
		List <DatoOtroDocSoporte> listDatoOtroDocSoporte = docAutAsociadoDAO.listadoExpedientes(params);
		if(log.isDebugEnabled())log.debug("Inicio iteracion de Listado  - listDatoOtroDocSoporte");
		for(DatoOtroDocSoporte datoOtroDocSoporte:listDatoOtroDocSoporte){
			item= new HashMap<String,Object>();
			item.put("NUM_DOC", datoOtroDocSoporte.getNumdocasoc());
			item.put("FEC_EMIS", SunatDateUtils.getFormatDate(datoOtroDocSoporte.getFecdocasoc(), "dd/MM/yyyy"));
			item.put("DES_SUSTENTO", datoOtroDocSoporte.getSustento());
			listaExpedientes.add(item);
		}
		return listaExpedientes;
			}
	//	</RIN10> 3014 ERUESTAA

	//	  <RIN10> 3012 ERUESTAA
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#validarValorProvisional(java.util.Map)
	 */
	public Map<String, Object> validarValorProvisional(Map<String, Object> params)
			throws ServiceException
			{
		String indicadorVFobProvValorProvisional = "NO";//RIN10 BUG 22611,22613
		Map<String, Object> res = new HashMap<String, Object>();
		try
		{   //Inicio RIN10 mpoblete BUG 21738
			//Map<String, Object> indicadorDua = new HashMap<String, Object>();		      
			//indicadorDua = obtenerIndicadorDuaByPk(params.get("NUM_CORREDOC").toString(),Constantes.COD_INDICADOR_VALPROV);
			DatoIndicadores objIndicadorDua = obtenerIndicadorDeclaracion(params.get("NUM_CORREDOC").toString(),Constantes.COD_INDICADOR_VALPROV);
			boolean tieneIndicadorDUAVP = (objIndicadorDua!=null && objIndicadorDua.getIndicadorActivo().equals("1"));//gmontoya Pase 35 2017 P24
			//if (indicadorDua != null && !indicadorDua.isEmpty()){		      
			if (tieneIndicadorDUAVP){	  
				//Fin RIN10 mpoblete BUG 21738 	  
				if (params.get("COD_PROCESO").equals(Constantes.COD_PROCESO_F23006)){

					Map<String, Object> paramvp = new HashMap<String, Object>();
					paramvp.put("numcorredoc", params.get("NUM_CORREDOC").toString());
					paramvp.put("codtipovalor", Constantes.COD_TIPO_VALOR_PROVISIONAL);
					paramvp.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
					List<DatoMontoProv> result = vFOBProvisionalDAO.findMontoProvByMap(paramvp);
					if(result.size()>0){
						res.put("mesagges", Constantes.MSJ_PENDIENTE_REGUALIZAR);  
						indicadorVFobProvValorProvisional = "SI";//RIN10 BUG 22611,22613
					}

					Map<String, Object> paramsDiligencia = new HashMap<String, Object>();
					paramsDiligencia.put("NUM_CORREDOC", params.get("NUM_CORREDOC").toString());
					paramsDiligencia.put("COD_TIPDILIGENCIA",new String[]{Constantes.MODULO_RECTIFICACION_OFICIO});
					Map<String, Object> resultRectifica = validaDiligenciaService.findPrimeraDiligencia(paramsDiligencia);

					if(MapUtils.esMapaNuloOVacio(resultRectifica)){
						paramvp.put("numcorredoc", params.get("NUM_CORREDOC").toString());
						paramvp.put("codtipovalor", Constantes.COD_TIPO_VALOR_DEFINITIVO);
						List<DatoMontoProv> resultRegularizado = vFOBProvisionalDAO.findMontoProvByMap(paramvp);
						if(resultRegularizado.size()>0 && result.size()==0){
							res.put("mesagges", Constantes.MSJ_REGULARIZADO);
						}
					}

					if(!MapUtils.esMapaNuloOVacio(resultRectifica)){
						paramvp.put("numcorredoc", params.get("NUM_CORREDOC").toString());
						paramvp.put("codtipovalor", Constantes.COD_TIPO_VALOR_DEFINITIVO);
						List<DatoMontoProv> resultRegularizado = vFOBProvisionalDAO.findMontoProvByMap(paramvp);
						if(resultRegularizado.size()>0 && result.size()==0){
							res.put("mesagges", Constantes.MSJ_REGULARIZADO_OFICIO);
						}
					}
					res.put("Excepcion1", Constantes.ESPACIO_BLANCO);
					res.put("indicadorVFobProvValorProvisional",indicadorVFobProvValorProvisional);//RIN10 BUG 22611,22613
				}
				if (params.get("COD_PROCESO").equals(Constantes.COD_PROCESO_F23012)){
					//Inicio RIN10 BUG 21583
					boolean existeFecRecep = (params.get("FEC_RECEP")!=null && !StringUtils.isEmpty(params.get("FEC_RECEP").toString())); 
					String fecRecepTemp = (existeFecRecep)?params.get("FEC_RECEP").toString():"99991231";
					//String fecRecep = this.fechaYhora_to_soloFecha(params.get("FEC_RECEP").toString());	  
					//Fin RIN10 BUG 21583
					String fecFinVP = this.fechaYhora_to_soloFecha(params.get("FEC_FINPROVSIONAL").toString());
					String nuevaFecFinVP = this.fechaYhora_to_soloFecha(params.get("NUEVA_FEC_FINPROVSIONAL").toString());

					//Date dateRecep = DateUtil.stringToDate(fecRecep, "dd/MM/yyyy");
					Date dateRecep = SunatDateUtils.getDateyyyMMdd(fecRecepTemp);
					dateRecep = SunatDateUtils.getDate(SunatDateUtils.getFormatDate(dateRecep,FechaBean.FORMATO_DEFAULT));
					Date dateFinVP = DateUtil.stringToDate(fecFinVP, "dd/MM/yyyy");
					Date dateNuevaFinVP = DateUtil.stringToDate(nuevaFecFinVP, "dd/MM/yyyy");

					//EXPEDIENTE PRESENTADO FUERA DE PLAZO
					//Inicio RIN10 BUG 21583
					//if (FechaBean.compareDate(dateRecep, dateFinVP) > 0){ /*si es menor = -1, si es mayor = 1*/		     		 
					boolean esProrroga = "Prorroga".equals(params.get("TIPO_SOLICITUD").toString());
					int resultadoComparacion = 0;
					resultadoComparacion = (esProrroga)?FechaBean.compareDate(dateRecep, dateFinVP):FechaBean.compareDate(dateRecep, dateNuevaFinVP);
					if (resultadoComparacion > 0){ /*si es menor = -1, si es mayor = 1*/
						//Fin RIN10 BUG 21583	  
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_EXP_PRESENT_FUERA_PLAZO);//BUG RIN10 KAH
						res.put("Excepcion3",Constantes.GUION_FECHA +" " + mapaError.get("desError").toString());
					}
					//<KAH-RIN10> 
					/*REQ 2017-043302 validcion no corresponde al PFA segun RIN10
					//TODO para que salga error la fecha del sistema > ffvp 20/02/2015 "PLAZO PARA REGULARIZACI�N DEL VALOR PROVISIONAL VENCIDO, NO PROCEDE"
					Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
					paramCabDeclara.put("NumCorredoc", params.get("NUM_CORREDOC"));
					int vigenciaFechaFinValorProvDUA = cabDeclaraDAO.verificaVigenciaFechaFinValProv(paramCabDeclara);
					if (!(vigenciaFechaFinValorProvDUA>0)){  
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_PLAZO_VENCIDO);//BUG RIN10 KAH
						res.put("Excepcion17", mapaError.get("desError").toString());
					}*/
					//</KAh-RIN10>
					//DUA CON VALOR PROVISIONAL REGULARIZADO
					String fecVencRegulaVP = Constantes.DEFAULT_FECHA_BD2;
					Map<String, Object> paramCabAdiDecl = new HashMap<String, Object>();
					paramCabAdiDecl.put("numcorredoc", params.get("NUM_CORREDOC").toString());                                                      
					DUA adideclara = cabAdiDeclaraDAO.getByPrimaryKey(paramCabAdiDecl);

					if (adideclara != null){
						fecVencRegulaVP = this.dateFechaYhora_to_soloFecha(adideclara.getFecRegulaValProv());
					}

					Date dateVenRegulaVP =  DateUtil.stringToDate(fecVencRegulaVP, Constantes.FORMAT_ddMMyyyy);
					if ( !(dateVenRegulaVP.equals(DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD2, Constantes.FORMAT_ddMMyyyy))|| dateVenRegulaVP.equals(DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD, Constantes.FORMAT_ddMMyyyy))) )
					{
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_TIENE_VALPROV_REGULARIZADO);//BUG RIN10 KAH
						res.put("Excepcion4",Constantes.GUION_FECHA +" " + mapaError.get("desError").toString());
						return res; 
					}

					//DUA CUENTA CON PRORROGA
					boolean tieneProrrogaAceptada = ProrrogaAceptada(params.get("NUM_CORREDOC").toString());
					if(tieneProrrogaAceptada){
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_YA_TIENE_PRORROGA_ACEP);//BUG RIN10 KAH
						res.put("Excepcion9",Constantes.GUION_FECHA +" " + mapaError.get("desError").toString());
					}	     		  

					//NUEVA FECFINVP TIENE QUE SER <= FECHA NUMERACION + 12 MESES
					String fecNumeracion = this.fechaYhora_to_soloFecha(params.get("FEC_NUMERACION").toString());
					Date dateNumeracion =  DateUtil.stringToDate(fecNumeracion, "dd/MM/yyyy");
					Date dateNumeracion_Mas12Meses = SunatDateUtils.addMonth(dateNumeracion, Constantes.PLAZO_OPERACION_PRORROGA_PE);
					//Inicio RIN10 mpoblete BUG 22002
					Map<String, Object> paramsIsFechaHabil = new HashMap<String, Object>();
					Integer fechaNumeracionMas12Meses = SunatDateUtils.getIntegerFromDate(dateNumeracion_Mas12Meses);
					paramsIsFechaHabil.put("FECHAINICIAL", fechaNumeracionMas12Meses);
					paramsIsFechaHabil.put("NUMDIAS", fechaNumeracionMas12Meses);
					paramsIsFechaHabil.put("TIPODIA", "U");
					paramsIsFechaHabil.put("OPERACION", 1);                 
					paramsIsFechaHabil.put("INCLUYE", "S");
					paramsIsFechaHabil.put("ALCANCE", "N");

					Date dateNumeracion_Mas12Meses_diaHabil = new Date();
					boolean fechaNumeracionMas12MesesEsHabil = this.isFechaHabil(paramsIsFechaHabil);  
					if(fechaNumeracionMas12MesesEsHabil){
						dateNumeracion_Mas12Meses_diaHabil = dateNumeracion_Mas12Meses;
					}else{
						dateNumeracion_Mas12Meses_diaHabil=this.obtenerDiaHabil(0, 2, "U", "S", "S", params.get("COD_ADUANA").toString(), dateNumeracion_Mas12Meses);//BUG RIN10 KAH 
					}
					//Fin RIN10 mpoblete BUG 22002
					//inicio PAS20175E220200013
//					if(esProrroga && !(SunatDateUtils.sonIguales(dateNumeracion_Mas12Meses_diaHabil, dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA) && SunatDateUtils.esFecha1MayorQueFecha2(dateNuevaFinVP, dateNumeracion_Mas12Meses, SunatDateUtils.COMPARA_SOLO_FECHA))){
//						//Inicio RIN10 mpoblete BUG 22002
//						String fecPlazoMax = this.dateFechaYhora_to_soloFecha(dateNumeracion_Mas12Meses_diaHabil);
//						//Fin RIN10 mpoblete BUG 22002
//						String dia =  fecPlazoMax.substring(Constantes.NUMERO_CERO_INT, Constantes.NUMERO_DOS_INT);		
//						String mes = fecPlazoMax.substring(Constantes.NUMERO_TRES_INT, Constantes.NUMERO_CINCO_INT);
//						String anio = fecPlazoMax.substring(Constantes.NUMERO_SEIS_INT, Constantes.NUMERO_DIEZ_INT);
//						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_FECFIN_VALPROV_NO_ES_12_MESES_POST_NUMERACION,new String[]{dia + Constantes.GUION_FECHA + mes + Constantes.GUION_FECHA + anio});//BUG RIN10 KAH
//						res.put("Excepcion11",Constantes.GUION_FECHA +" " +mapaError.get("desError").toString());						
//					}
					//fin  PAS20175E220200013
					//Inicio BUG 21978 - Percy HM
					if(!esProrroga && (SunatDateUtils.esFecha1MayorIgualQueFecha2(dateFinVP, dateNumeracion_Mas12Meses_diaHabil, SunatDateUtils.COMPARA_SOLO_FECHA))){
						Map<String, String> mapaErrorDos = catalogoAyudaService.getError(Constantes.ERR_PLAZO_MAXIMO_REGULARIZAR_VAL_PROVISIONAL);
						res.put("Excepcion12A",Constantes.GUION_FECHA +" " + mapaErrorDos.get("desError").toString());
					}else{
						//Fin BUG 21978
						//INICIO BUG RIN10 KAH
						if(!esProrroga && !(SunatDateUtils.esFecha1MenorIgualQueFecha2(dateNuevaFinVP, dateNumeracion_Mas12Meses_diaHabil, SunatDateUtils.COMPARA_SOLO_FECHA))){//BUG RIN10 KAH
							Map<String, String> mapaErrorDos = catalogoAyudaService.getError(Constantes.ERR_AMPLIACION_NO_DENTRO_12_MESES_POST_NUMERACION);
							res.put("Excepcion12A",Constantes.GUION_FECHA +" " + mapaErrorDos.get("desError").toString());
						}
						//FIN BUG RIN10 KAH
					}//BUG 21978
					//eruestaa. Que la nueva fecha VP sea mayor o igual a la actual
					//Inicio RIN10 BUG 21585
					if(!(SunatDateUtils.esFecha1MayorQueFecha2(dateNuevaFinVP,dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA))){
						//Fin RIN10 BUG 21585	 
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_NUEVA_FECHA_VALOR_PROVISIONAL_ES_MENOR);//BUG RIN10 KAH
						res.put("Excepcion13P", Constantes.GUION_FECHA +" " +mapaError.get("desError").toString());
					}
					//fin eruestaa

					//EXCEDE PLAZO MAXIMO DE 12 MESES: diferencia entre nuevaFecFinVP y la FecFinVP de la declaracion sea <= 12 meses  		  
					Date fechaFinVPMas12Meses = SunatDateUtils.addMonth(dateFinVP, Constantes.PLAZO_OPERACION_PRORROGA_PE);//es el tope que puede llegar la nueva fecha finVP	     		 
					if ((SunatDateUtils.esFecha1MayorIgualQueFecha2(dateNuevaFinVP,dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA))
							&& !(SunatDateUtils.esFecha1MenorIgualQueFecha2(dateNuevaFinVP,fechaFinVPMas12Meses, SunatDateUtils.COMPARA_SOLO_FECHA))){
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_PRORROGA_EXCEDE_PLAZO_12_MESES);//BUG RIN10 KAH
						res.put("Excepcion12P", Constantes.GUION_FECHA +" " +mapaError.get("desError").toString());	     			
					}	     		
				}
				if (params.get("COD_PROCESO").equals(Constantes.COD_PROCESO_F23014)){    		  
					//Inicio RIN10 mpoblete BUG 21738
					//res = indicadorDua;//No es usado en ninguna parte
					//Fin RIN10 mpoblete BUG 21738

					//Inicio RIN10 BUG 22611,22613
					Map<String, Object> paramvp = new HashMap<String, Object>();
					paramvp.put("numcorredoc", params.get("NUM_CORREDOC").toString());
					paramvp.put("codtipovalor", Constantes.COD_TIPO_VALOR_PROVISIONAL);
					paramvp.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
					List<DatoMontoProv> result = vFOBProvisionalDAO.findMontoProvByMap(paramvp);
					if(result.size()>0){		    			  
						res.put("indicadorVFobProvValorProvisional","SI");
					}else{
						res.put("indicadorVFobProvValorProvisional","NO");//RIN10 BUG 22611,22613
					}
					//Fin RIN10 BUG 22611,22613
					res.put("Excepcion1", Constantes.ESPACIO_BLANCO);
				}
			}
			else{
				Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_NO_TIENE_VALOR_PROVISIONAL);//BUG RIN10 KAH
				res.put("Excepcion1", mapaError.get("desError").toString());
			}  
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error durante la optencion validarValorProvisional");
		}

		return res;     
			}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#fechaYhora_to_soloFecha(java.lang.String)
	 */
	public String fechaYhora_to_soloFecha(String fechaHora){
		String soloFecha="";	  		
		String anio = fechaHora.substring(Constantes.NUMERO_CERO_INT, Constantes.NUMERO_CUATRO_INT);
		String mes = fechaHora.substring(Constantes.NUMERO_CINCO_INT, Constantes.NUMERO_SIETE_INT);				
		String dia = fechaHora.substring(Constantes.NUMERO_OCHO_INT, Constantes.NUMERO_DIEZ_INT);					
		soloFecha = dia+Constantes.BARRA_FECHA+mes+Constantes.BARRA_FECHA+anio;
		return soloFecha;
	}

	/**
	 * @param fechaHora
	 * @return
	 */
	public String fechaYhora_to_soloHora(String fechaHora){	  			
		FechaBean fbEnvio = new FechaBean();
		fbEnvio.setFecha(fechaHora, "yyyy-MM-dd HH:mm:ss");
		String horaEnvioTemp = fbEnvio.getFormatCUSCAR();					
		String soloHora = horaEnvioTemp.substring(Constantes.NUMERO_ONCE_INT, Constantes.NUMERO_DIECINUEVO_INT);
		return soloHora;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#dateFechaYhora_to_soloFecha(java.util.Date)
	 */
	public String dateFechaYhora_to_soloFecha(Date fechaHora){
		FechaBean fecMensFB = new FechaBean();
		fecMensFB.setFecha(fechaHora);	     		 
		String fechaTemp = fecMensFB.getFormatCUSCAR();
		String anioRegis = fechaTemp.substring(Constantes.NUMERO_CERO_INT,Constantes.NUMERO_CUATRO_INT);
		String mesRegis  = fechaTemp.substring(Constantes.NUMERO_CINCO_INT, Constantes.NUMERO_SIETE_INT);				
		String diaRegis  = fechaTemp.substring(Constantes.NUMERO_OCHO_INT, Constantes.NUMERO_DIEZ_INT);
		String fecMens = diaRegis+Constantes.BARRA_FECHA+mesRegis+Constantes.BARRA_FECHA+anioRegis;

		return fecMens;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#getCabCtaCteGara(java.util.Map)
	 */
	public Map<String, Object> getCabCtaCteGara(Map<String, Object> params){
		Map<String, Object> resultado = cabCtaCteGarDAO.findByNumCtaCte(params);
		return resultado;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#obtenerMovCtaCteGaraDeLC(java.util.Map)
	 */
	public List<Map<String,Object>> obtenerMovCtaCteGaraDeLC(Map<String,Object> mapWhere){
		List<Map<String,Object>> listaMovs = new ArrayList<Map<String,Object>>();
		listaMovs = movCtaCteGaraDAO.findByWhereSelectivo(mapWhere);
		return listaMovs;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#isFechaHabil(java.util.Map)
	 */
	public boolean isFechaHabil(Map<String, Object> params){
		String numDias = calculaDiaDAO.getFnCalculaDias(params);		
		return numDias.equalsIgnoreCase("1")?true:false;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#actualizarMovCtaCteGarantia(java.util.Map)
	 */
	public void actualizarMovCtaCteGarantia(Map<String, Object> paramUpdate)  throws ServiceException{
		try{
			movCtaCteGaraDAO.updateSelectivoByWhereSelectivo(paramUpdate);                    
		}catch(Exception e){
			log.error("Error actualizarMovCtaCteGarantia:"+e.getMessage());
		}
	}

	/**
	 * @param numCorreDoc
	 * @return
	 */
	boolean ProrrogaAceptada(String numCorreDoc){
		//		  boolean ret=false;
		//	      PlazosProceso plazo = new PlazosProceso();
		//	      Long num = new Long(numCorreDoc);
		//	      plazo.setNumeroCorrelativo(num);
		//	      List<PlazosProceso> lista= plazosProcesoDAO.selectSelective(plazo);  
		//		  ret = (lista.size()==0) ? false : true; //si existe en la tabla tiene prorroga aceptada
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NumCorredoc", numCorreDoc);
		params.put("codTipSol", Constantes.COD_TIPO_SOLICITUD_PRORROGA);

		int duaProrrogada = docuPreceDuaDAO.getDuaProrrogada(params);
		return duaProrrogada!=0?true:false;
	}  

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#validarValorProvisionalPO(java.util.Map)
	 */
	public Map<String, Object> validarValorProvisionalPO(Map<String, Object> params)
			throws ServiceException
			{

		Map<String, Object> res = new HashMap<String, Object>();
		try
		{
			//Inicio RIN10 mpoblete BUG 21738
			//Map<String, Object> indicadorDua = new HashMap<String, Object>();  
			//indicadorDua = obtenerIndicadorDuaByPk(params.get("NUM_CORREDOC").toString(),Constantes.COD_INDICADOR_VALPROV);
			DatoIndicadores objIndicadorDua = obtenerIndicadorDeclaracion(params.get("NUM_CORREDOC").toString(),Constantes.COD_INDICADOR_VALPROV);
			boolean tieneIndicadorDUAVP = (objIndicadorDua!=null);
			//if (indicadorDua != null && !indicadorDua.isEmpty()){
			if (tieneIndicadorDUAVP){
				//Fin RIN10 mpoblete BUG 21738	  
				String nueva_fecFinVP = this.fechaYhora_to_soloFecha(params.get("NUEVA_FECVALORPROV").toString());							
				String fecFinVP = this.fechaYhora_to_soloFecha(params.get("FEC_FINPROVSIONAL").toString());

				Date nuevo_dateFinVP = DateUtil.stringToDate(nueva_fecFinVP, "dd/MM/yyyy");
				Date dateFinVP = DateUtil.stringToDate(fecFinVP, "dd/MM/yyyy");


				//	    		  TODO para que salga error la fecha del sistema > ffvp 20/02/2015 "PLAZO PARA REGULARIZACI�N DEL VALOR PROVISIONAL VENCIDO, NO PROCEDE"
				Map<String, Object> paramCabDeclara = new HashMap<String, Object>();
				paramCabDeclara.put("NumCorredoc", params.get("NUM_CORREDOC"));
				int vigenciaFechaFinValorProvDUA = cabDeclaraDAO.verificaVigenciaFechaFinValProv(paramCabDeclara);
				if (!(vigenciaFechaFinValorProvDUA>0)){  
					Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_PLAZO_VENCIDO);//BUG RIN10 KAH
					res.put("Excepcion5", mapaError.get("desError").toString());
					return res; 
				}
				//	     		 FIXME para que salga error nuevo_dateFinVP > ffvp 20/02/2015 "PLAZO PARA REGULARIZACI�N DEL VALOR PROVISIONAL VENCIDO, NO PROCEDE"
				//	     		 if (!(SunatDateUtils.esFecha1MayorIgualQueFecha2(dateFinVP,nuevo_dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA))){  
				//	     			 res.put("Excepcion5", Constantes.ERR_PLAZO_VENCIDO);
				//	     			 return res; 
				//	   		     }

				//La DUA no cuente con una pr�rroga aceptada. Sino tiene registro en Docu_prece arrojara el error.
				String numcorredoc = params.get("NUM_CORREDOC").toString();
				boolean indicadorProrrogaAceptada = ProrrogaAceptada(numcorredoc);

				if (indicadorProrrogaAceptada){
					Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_YA_TIENE_PRORROGA_ACEP);//BUG RIN10 KAH
					res.put("Excepcion9", mapaError.get("desError").toString());
					return res; 
				}

				//DUA CON VALOR PROVISIONAL REGULARIZADO
				String fecVencRegulaVP = Constantes.DEFAULT_FECHA_BD2;
				Map<String, Object> paramCabAdiDecl = new HashMap<String, Object>();
				paramCabAdiDecl.put("numcorredoc", params.get("NUM_CORREDOC").toString());                                                      
				DUA adideclara = cabAdiDeclaraDAO.getByPrimaryKey(paramCabAdiDecl);

				if (adideclara != null){
					//fecVencRegulaVP = this.fechaYhora_to_soloFecha(adideclara.getFecRegulaValProv().toString());
					fecVencRegulaVP = this.dateFechaYhora_to_soloFecha(adideclara.getFecRegulaValProv());
				}

				//Si de cabAdiDeclara FecRegulaValProv <> 31/12/9999 arroja el error "DUA CON VALOR PROVISIONAL REGULARIZADO, NO PROCEDE"
				Date dateVenRegulaVP =  DateUtil.stringToDate(fecVencRegulaVP, Constantes.FORMAT_ddMMyyyy);
				if ( !(dateVenRegulaVP.equals(DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD2, Constantes.FORMAT_ddMMyyyy)) || dateVenRegulaVP.equals(DateUtil.stringToDate(Constantes.DEFAULT_FECHA_BD, Constantes.FORMAT_ddMMyyyy))))
				{
					Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_TIENE_VALPROV_REGULARIZADO);//BUG RIN10 KAH
					res.put("Excepcion7", mapaError.get("desError").toString());
					return res; 
				}else //Inicio RIN10 mpoblete BUG 21828
					if(!(SunatDateUtils.esFecha1MayorQueFecha2(nuevo_dateFinVP,dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA))){
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_NUEVA_FECHA_VALOR_PROVISIONAL_ES_MENOR);//BUG RIN10 KAH
						res.put("Excepcion13P", Constantes.GUION_FECHA +" " +mapaError.get("desError").toString());
						return res;//RIN10 mpoblete BUG 21828 
					}
				//Fin RIN10 mpoblete BUG 21828

				//NUEVA FECFINVP TIENE QUE SER <= FECHA NUMERACION + 12 MESES
				boolean esProrroga = "Prorroga".equals(params.get("TIP_PROCESO").toString());//BUG RIN10 KAH
				String fecNumeracion = this.fechaYhora_to_soloFecha(params.get("FEC_NUMERACION").toString());
				Date dateNumeracion =  DateUtil.stringToDate(fecNumeracion, Constantes.FORMAT_ddMMyyyy);
				Date dateNumeracion_Mas12Meses = SunatDateUtils.addMonth(dateNumeracion, Constantes.PLAZO_OPERACION_PRORROGA_PE);
				//Inicio RIN10 mpoblete BUG 22002
				Map<String, Object> paramsIsFechaHabil = new HashMap<String, Object>();
				Integer fechaNumeracionMas12Meses = SunatDateUtils.getIntegerFromDate(dateNumeracion_Mas12Meses);
				paramsIsFechaHabil.put("FECHAINICIAL", fechaNumeracionMas12Meses);
				paramsIsFechaHabil.put("NUMDIAS", fechaNumeracionMas12Meses);
				paramsIsFechaHabil.put("TIPODIA", "U");
				paramsIsFechaHabil.put("OPERACION", 1);                 
				paramsIsFechaHabil.put("INCLUYE", "S");
				paramsIsFechaHabil.put("ALCANCE", "N");

				Date dateNumeracion_Mas12Meses_diaHabil = new Date();
				boolean fechaNumeracionMas12MesesEsHabil = this.isFechaHabil(paramsIsFechaHabil);  
				if(fechaNumeracionMas12MesesEsHabil){
					dateNumeracion_Mas12Meses_diaHabil = dateNumeracion_Mas12Meses;
				}else{
					dateNumeracion_Mas12Meses_diaHabil=this.obtenerDiaHabil(0, 2, "U", "S", "S", params.get("COD_ADUANA").toString(), dateNumeracion_Mas12Meses);//BUG RIN10 KAH 
				}
				//Fin RIN10 mpoblete BUG 22002 // INICIO PAS201930001100003
//				if(esProrroga && !(SunatDateUtils.sonIguales(dateNumeracion_Mas12Meses_diaHabil, dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA) && SunatDateUtils.esFecha1MayorQueFecha2(nuevo_dateFinVP, dateNumeracion_Mas12Meses, SunatDateUtils.COMPARA_SOLO_FECHA))){
//					String fecPlazoMax = this.dateFechaYhora_to_soloFecha(dateNumeracion_Mas12Meses_diaHabil);
//					String dia =  fecPlazoMax.substring(Constantes.NUMERO_CERO_INT, Constantes.NUMERO_DOS_INT);		
//					String mes = fecPlazoMax.substring(Constantes.NUMERO_TRES_INT, Constantes.NUMERO_CINCO_INT);
//					String anio = fecPlazoMax.substring(Constantes.NUMERO_SEIS_INT, Constantes.NUMERO_DIEZ_INT);
//
//					Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_FECFIN_VALPROV_NO_ES_12_MESES_POST_NUMERACION_PO, new String[]{dia + Constantes.GUION_FECHA + mes + Constantes.GUION_FECHA + anio});//BUG RIN10 KAH
//					res.put("Excepcion8",mapaError.get("desError").toString() );
//					return res;//RIN10 mpoblete BUG 21941
//
//				} //FIN PAS201930001100003

				//Inicio BUG 22119 - Percy HM
				if(!esProrroga && (SunatDateUtils.esFecha1MayorIgualQueFecha2(dateFinVP, dateNumeracion_Mas12Meses_diaHabil, SunatDateUtils.COMPARA_SOLO_FECHA))){
					Map<String, String> mapaErrorDos = catalogoAyudaService.getError(Constantes.ERR_PLAZO_MAXIMO_REGULARIZAR_VAL_PROVISIONAL);
					res.put("Excepcion11", mapaErrorDos.get("desError").toString());
					return res;
				}else{
					//Fin BUG 22119				 
					//INICIO BUG RIN10 KAH
					if(!esProrroga && !(SunatDateUtils.esFecha1MenorIgualQueFecha2(nuevo_dateFinVP, dateNumeracion_Mas12Meses_diaHabil, SunatDateUtils.COMPARA_SOLO_FECHA))){
						Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_AMPLIACION_NO_DENTRO_12_MESES_POST_NUMERACION);//BUG RIN10 KAH
						res.put("Excepcion11",mapaError.get("desError").toString());
						return res;//RIN10 mpoblete BUG 21941
					}
					//FIN BUG RIN10 KAH
				}//BUG 22119 


				//EXCEDE PLAZO MAXIMO DE 6 MESES: diferencia entre nuevaFecFinVP y la fecnumeracion de la declaracion sea <= 6 meses		  
				Date dateFinVP_Mas6Meses = SunatDateUtils.addMonth(dateFinVP, Constantes.PLAZO_OPERACION_PRORROGA_PO);//es el tope que puede llegar la nueva fecha finVP	     		 
				if ((SunatDateUtils.esFecha1MayorIgualQueFecha2(nuevo_dateFinVP,dateFinVP, SunatDateUtils.COMPARA_SOLO_FECHA))
						&& !(SunatDateUtils.esFecha1MenorIgualQueFecha2(nuevo_dateFinVP,dateFinVP_Mas6Meses, SunatDateUtils.COMPARA_SOLO_FECHA))){
					Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_PRORROGA_EXCEDE_PLAZO_6_MESES);//BUG RIN10 KAH
					res.put("Excepcion10",mapaError.get("desError").toString());
					return res; 
				}
				//				//EXCEDE PLAZO MAXIMO DE 6 MESES: diferencia entre nuevaFecFinVP y la fecnumeracion de la declaracion sea <= 6 meses
				//	     		Date dateNumeracion_Mas6Meses = SunatDateUtils.addMonth(dateFinVP, Constantes.PLAZO_OPERACION_PRORROGA_PO)
				//				 boolean excede=SunatDateUtils.esFecha1MenorIgualQueFecha2(nuevo_dateFinVP, dateNumeracion_Mas6Meses, SunatDateUtils.COMPARA_SOLO_FECHA);
				//				 if(!excede){
				//					res.put("Excepcion10",Constantes.ERR_PRORROGA_EXCEDE_PLAZO_6_MESES );
				//					return res; 
				//				 }
			}
			else{
				Map<String, String> mapaError = catalogoAyudaService.getError(Constantes.ERR_DUA_NO_TIENE_VALOR_PROVISIONAL);
				res.put("Excepcion2", mapaError.get("desError").toString());
			}
		}
		catch (Exception e)
		{
			throw new ServiceException(this, "Ocurrio un error durante la optencion validarValorProvisionalPO");
		}

		return res;    

			}
	//	</RIN10> 3012 ERUESTAA

	//Inicio RIN10 mpoblete BUG 22178
	//Inicio RIN10 mpoblete BUG 22178
//amancilla inicio-PAS20165E220200137
	public List<Map<String, Object>> listaItemFacturaTieneValorProvisional(List<Map<String, Object>> lstItemFactura){

		return listaItemFacturaTieneValorProvisional(lstItemFactura,null);
	}
	//amancilla fin-PAS20165E220200137
	public List<Map<String, Object>> listaItemFacturaTieneValorProvisional(List<Map<String, Object>> lstItemFactura, Map mapCabDeclaraActual){


		List<Map<String, Object>> lstItemFacturaTemp = lstItemFactura;
		if(!CollectionUtils.isEmpty(lstItemFacturaTemp)){
			Map<String, Object> paramsFindVFobProv = new HashMap<String,Object>();	
			List<Map<String, Object>> listaVFobProv = new ArrayList<Map<String,Object>>();
			for(Map<String, Object> itemFactura : lstItemFacturaTemp){

				paramsFindVFobProv = new HashMap<String,Object>();	
				paramsFindVFobProv.put("NUM_CORREDOC", itemFactura.get("NUM_CORREDOC"));
				paramsFindVFobProv.put("NUM_SECPROVE",itemFactura.get("NUM_SECPROVE"));	
				paramsFindVFobProv.put("NUM_SECFACT", itemFactura.get("NUM_SECFACT"));
				paramsFindVFobProv.put("NUM_SECITEM", itemFactura.get("NUM_SECITEM"));
				List<Map<String, Object>> listaItemFactura = null;
				Map<String, String> PkSerie = new HashMap<String,String>();
				PkSerie.put("NUM_CORREDOC", itemFactura.get("NUM_CORREDOC").toString());
				PkSerie.put("NUM_SECPROVE",itemFactura.get("NUM_SECPROVE").toString());	
				PkSerie.put("NUM_SECFACT", itemFactura.get("NUM_SECFACT").toString());
				PkSerie.put("NUM_SECITEM", itemFactura.get("NUM_SECITEM").toString());
			    listaItemFactura = itemFacturaDAO.joinSeriesItemVFobProvisionalFindBySerie(PkSerie);
			    if(listaItemFactura.size()>0){
			    	itemFactura.put("DES_SECPROVE",listaItemFactura.get(0).get("des_proveedor")!=null?listaItemFactura.get(0).get("des_proveedor").toString():"oip"); //PAS20175E220200035
			    }
				listaVFobProv = new ArrayList<Map<String,Object>>();
				listaVFobProv = vFOBProvisionalDAO.findMapMontoProvByMap(paramsFindVFobProv);
				if(CollectionUtils.isEmpty(listaVFobProv)){
					itemFactura.put("TIENE_VP", "NO");
				}else{
					for(Map<String,Object> mapVFobProv:listaVFobProv){
						if("2".equals(mapVFobProv.get("COD_TIPOVALOR").toString())){
							itemFactura.put("TIENE_VP", "SI");
						}else{
							itemFactura.put("TIENE_VP", "NO");
						}
					}
				}

				//amancilla inicio-PAS20165E220200137
				if(mapCabDeclaraActual!=null
						&& itemFactura.get("COD_TIPDESCRMIN")!=null
						&& !StringUtils.isEmpty(itemFactura.get("COD_TIPDESCRMIN").toString())){
					Enum<?> tipo = TipoDescrMinima.get(itemFactura.get("COD_TIPDESCRMIN").toString());
					if(tipo!=null){
						ModelAbstract objeto = ModelFactory.crearObjetoDescrMinima(tipo);

						objeto.setFechaIniVigenciaValidador(SunatDateUtils.getDateFromUnknownFormat(mapCabDeclaraActual.get("FEC_DECLARACION").toString()));

						PlantillaFactory plantillaFactory= fabricaDeServicios.getService("descripcionMinima.PlantillaFactory");
						//validadorFactory.crearValidadorDescrMinima(objeto);
						itemFactura.put("VERSION_PLANTILLA", plantillaFactory.obtenerVersionEstrutura(objeto));
					}
				}
				//amancilla fin-PAS20165E220200137
			}
		}	

		return lstItemFacturaTemp;
	}
	//Fin RIN10 mpoblete BUG 22178

	//<EHR> RIN10
	/*
	 * (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService#tieneRectificacionAutomatica(java.lang.String)
	 */
	public boolean tieneRectificacionAutomatica( String numCorredoc){
		Map<String, Object> parametros = new HashMap<String, Object>();
		// 01 rectificacion
		// 11 regularizacion
		parametros.put("NUM_CORREDOC", numCorredoc);
		parametros.put("COD_TIPSOL", "01"); // se agrego para validar el tipo de
		List<Map<String, Object>> listSolicitudesRecti = relacionDocDAO.findSolicitudesByDocumento(parametros);
		if (listSolicitudesRecti == null || listSolicitudesRecti.size() == 0){
			return false;
		}
		return true;
	}
	//</EHR>

	//inicio P21-P22
	public Boolean duaTieneNotificacionDudaRazonable(Map<String,Object> declaracion){
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("CODI_ADUAN", declaracion.get("COD_ADUANA").toString());
		params.put("ANO_PRESE", declaracion.get("ANN_PRESEN").toString());
		params.put("CODI_REGI", declaracion.get("COD_REGIMEN").toString());
		params.put("NUME_CORRE", SunatStringUtils.lpad(declaracion.get("NUM_DECLARACION").toString(), 6, '0'));			

		Boolean flag = dudaRazonableService.duaTieneNotificacionDudaRazonable(params);		
		return flag;
	}

	//fin P21-P22

	/***********************SET DE SPRING **********************************/


	public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO)
	{
		this.itemFacturaDAO = itemFacturaDAO;
	}


	public ItemFacturaDAO getItemFacturaDAO()
	{
		return itemFacturaDAO;
	}


	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO)
	{
		this.cabDeclaraDAO = cabDeclaraDAO;
	}


	public void setObservacionDAO(ObservacionDAO observacionDAO)
	{
		this.observacionDAO = observacionDAO;
	}


	public void setEspeDocuDAO(EspeDocuDAO espeDocuDAO)
	{
		this.espeDocuDAO = espeDocuDAO;
	}

	public void setSolicitudService(SolicitudService solicitudService)
	{
		this.solicitudService = solicitudService;
	}

	public void setCabCertiOrigenDAO(CabCertiOrigenDAO cabCertiOrigenDAO)
	{
		this.cabCertiOrigenDAO = cabCertiOrigenDAO;
	}


	public void setMedioTransDAO(MedioTransDAO medioTransDAO)
	{
		this.medioTransDAO = medioTransDAO;
	}


	public void setEquipamientoDAO(EquipamientoDAO equipamientoDAO)
	{
		this.equipamientoDAO = equipamientoDAO;
	}


	public void setIndicadorDuaDAO(IndicadorDUADAO indicadorDuaDAO)
	{
		this.indicadorDuaDAO = indicadorDuaDAO;
	}

	public void setSoporteService(SoporteService soporteService)
	{
		this.soporteService = soporteService;
	}

	//  public void setDdpDAO(DdpDAO ddpDAO)
	//  {
	//    this.ddpDAO = ddpDAO;
	//  }

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
	{
		this.catalogoAyudaService = catalogoAyudaService;
	}


	public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO)
	{
		this.docuPreceDuaDAO = docuPreceDuaDAO;
	}


	public void setDudaRazonableService(DudaRazonableService dudaRazonableService)
	{
		this.dudaRazonableService = dudaRazonableService;
	}


	public void setCabSolRectiDAO(CabSolrectiDAO cabSolRectiDAO)
	{
		this.cabSolRectiDAO = cabSolRectiDAO;
	}


	public void setRelacionDocDAO(RelacionDocDAO relacionDocDAO)
	{
		this.relacionDocDAO = relacionDocDAO;
	}


	public FabricaDeServicios getFabricaDeServicios()
	{
		return this.fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
	{
		this.fabricaDeServicios = fabricaDeServicios;
	}


	public HotSwappableTargetSource getSwapperDatasource()
	{
		return this.swapperDatasource;
	}


	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
	{
		this.swapperDatasource = swapperDatasource;
	}


	/* PAS20145E220000399 INICIO GGRANADOS */
	//  public void setDirecepDAO(DirecepDAO direcepDAO)
	//  {
	//    this.direcepDAO = direcepDAO;
	//  }
	/* PAS20145E220000399 INICIO GGRANADOS */


	public void setCabTipoAforoDeclaraDAO(
			CabTipoAforoDeclaraDAO cabTipoAforoDeclaraDAO)
	{
		this.cabTipoAforoDeclaraDAO = cabTipoAforoDeclaraDAO;
	}


	public void setValidaDiligenciaService(
			ValidaDiligenciaService validaDiligenciaService)
	{
		this.validaDiligenciaService = validaDiligenciaService;
	}


	public void setCanalesDAO(CanalesDAO canalesDAO)
	{
		this.canalesDAO = canalesDAO;
	}


	public void setFinUbicacionDAO(FinUbicacionDAO finUbicacionDAO)
	{
		this.finUbicacionDAO = finUbicacionDAO;
	}


	public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO)
	{
		this.docAutAsociadoDAO = docAutAsociadoDAO;
	}


	//  public void setSprDAO(SprDAO sprDAO)
	//  {
	//    this.sprDAO = sprDAO;
	//  }


	//  public void setFeriasDAO(FeriasDAO feriasDAO)
	//  {
	//    this.feriasDAO = feriasDAO;
	//  }


	public void setPagarantiaDAO(PagarantiaDAO pagarantiaDAO)
	{
		this.pagarantiaDAO = pagarantiaDAO;
	}


	public void setDiasUtilesDAO(DiasUtilesDAO diasUtilesDAO)
	{
		this.diasUtilesDAO = diasUtilesDAO;
	}


	public void setGralDocTranporteDAO(DocuTransDAO gralDocTranporteDAO)
	{
		this.gralDocTranporteDAO = gralDocTranporteDAO;
	}


	public void setManifiestoDAO(CabManifiestoDAO manifiestoDAO)
	{
		this.manifiestoDAO = manifiestoDAO;
	}


	public void setPlazosProcesoDAO(PlazosProcesoDAO plazosProcesoDAO)
	{
		this.plazosProcesoDAO = plazosProcesoDAO;
	}

	/* PAS20145E220000399 INICIO GGRANADOS */
	//  public void setDfrecdocDAO(DfrecdocDAO dfrecdocDAO)
	//  {
	//    this.dfrecdocDAO = dfrecdocDAO;
	//  }
	//
	//
	//  public void setSdrecepDAO(SdrecepDAO sdrecepDAO)
	//  {
	//    this.sdrecepDAO = sdrecepDAO;
	//  }
	/* PAS20145E220000399 FIN GGRANADOS */


	public void setEspeDispoDAO(EspeDispoDAO espeDispoDAO)
	{
		this.espeDispoDAO = espeDispoDAO;
	}


	public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO)
	{
		this.formBProveedorDAO = formBProveedorDAO;
	}


	public void setFraudesDAO(FraudesDAO fraudesDAO)
	{
		this.fraudesDAO = fraudesDAO;
	}


	public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO)
	{
		this.participanteDocDAO = participanteDocDAO;
	}


	public void setvFOBProvisionalDAO(VFOBProvisionalDAO vFOBProvisionalDAO)
	{
		this.vFOBProvisionalDAO = vFOBProvisionalDAO;
	}

	public void setManifiestoSigadService(
			ManifiestoSigadService manifiestoSigadService) {
		this.manifiestoSigadService = manifiestoSigadService;
	}

	public void setDatadoValidacionService(
			Datado2ValidacionService datadoValidacionService) {
		this.datadoValidacionService = datadoValidacionService;
	}

	public void setSerieService(SerieService serieService)
	{
		this.serieService = serieService;
	}

	public void setDiligenciaService(DiligenciaService diligenciaService)
	{
		this.diligenciaService = diligenciaService;
	}

	public void setDeudaService(DeudaService deudaService)
	{
		this.deudaService = deudaService;
	}

	/* olunar 309 */
	public void setConsultaService(ConsultaService consultaService) {
		this.consultaService = consultaService;
	}  
	/* fin */

	public ParticipanteDocDAO getParticipanteDocDAO() {
		return participanteDocDAO;
	}

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}

	public SprDAOService getSprDAOService() {
		return sprDAOService;
	}

	public void setSprDAOService(SprDAOService sprDAOService) {
		this.sprDAOService = sprDAOService;
	}

	public FeriasDAOService getFeriasDAOService() {
		return feriasDAOService;
	}

	public void setFeriasDAOService(FeriasDAOService feriasDAOService) {
		this.feriasDAOService = feriasDAOService;
	}

	//PAS20145E220000583-Consulta SERF 
	public void setMovEConfirmaDAO(MovEConfirmaDAO movEConfirmaDAO) {
		this.movEConfirmaDAO = movEConfirmaDAO;
	}

	/* juazor RIN13 */
	public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO) {
		this.cabDiligenciaDAO = cabDiligenciaDAO;
	}


	/* juazor RIN13 */
	public void setExpediDAO(ExpediDAO expediDAO) {
		this.expediDAO = expediDAO;
	}
	/* juazor RIN13 */

	/* se comenta amancilla

public void setDeclaracionService(DeclaracionService declaracionService) {
	this.declaracionService = declaracionService;
}*/

	/* juazor RIN13 */
	public void setDocumentoDeTransporteService(
			DocumentoDeTransporteService documentoDeTransporteService) {
		this.documentoDeTransporteService = documentoDeTransporteService;
	}
	/*INICIO RIN08*/
	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}
	/*FIN RIN08*/

	/* jlunah - rin13*/
	public void setConvenioSerieDAO(ConvenioSerieDAO convenioSerieDAO) {
		this.convenioSerieDAO = convenioSerieDAO;
	}
	/* fin*/

	public CabAccionDuaDAO getCabAccionDuaDAO() {
		return cabAccionDuaDAO;
	}

	public void setCabAccionDuaDAO(CabAccionDuaDAO cabAccionDuaDAO) {
		this.cabAccionDuaDAO = cabAccionDuaDAO;
	}
	// hosoriov rin 12 inicio
	public Map<String,Object> consultarDatosDUAParaCargaLaboral (Map<String ,Object> params){
		Map<String,Object> resultado=null;

		List<Map<String,Object>> decla= cabDeclaraDAO.consultarDatosDUAParaCargaLaboral(params);

		if(!CollectionUtils.isEmpty(decla) ){
			resultado=new HashMap<String, Object>();
			resultado.put("dua", decla.get(0));

			List<Map<String,Object>> s= serieService.findNumPartidaSeries(params);
			resultado.put("series", s);
		}

		return  resultado;
	}


	public boolean hasDocTransporteNotaTarjaConDetalle(Long numeroCorrelativo, String numeroManifiesto, 
			Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte){

		return hasDocTransporteNotaTarjaConDetalle(numeroCorrelativo,  numeroManifiesto, anioManifiesto,  codigoAduana ,  tipoManifiesto,  viaTransporte,null);
	}


	public boolean hasDocTransporteNotaTarjaConDetalle(Long numeroCorrelativo, String numeroManifiesto, 
			Integer anioManifiesto, String codigoAduana , String tipoManifiesto, String viaTransporte,Integer indCampoUsar){
		List<Map<String, Object>> listaDocTransporte = this.serieService.obtenerListaNumeroDocTransporteByDeclaracionYNumDetalle(numeroCorrelativo);

		Map<String, Object> paramsBusqueda = new HashMap<String, Object>();
		paramsBusqueda.put("numeroManifiesto", numeroManifiesto);
		paramsBusqueda.put("anioManifiesto", anioManifiesto);
		paramsBusqueda.put("codigoAduana", codigoAduana);
		paramsBusqueda.put("tipoManifiesto", tipoManifiesto);
		paramsBusqueda.put("viaTransporte", viaTransporte);
		if(indCampoUsar==null)
			paramsBusqueda.put("listaDetalleDocTransporte", listaDocTransporte);
		else {
			paramsBusqueda.put("listaNumeroDocTransporte", listaDocTransporte);

		}

		paramsBusqueda.put("estado", ConstantesManifiesto.DOCUMENTO_TRANSPORTE_ESTADO_ANULADO);
		paramsBusqueda.put("hijoAndMaster", true);
		paramsBusqueda.put("tipoEnvio", ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);
		paramsBusqueda.put("indicadorEliminacion", Constantes.IND_NO_ELIMINADO);
		DocumentoOAManifiestoService documentoOAManifiestoService = this.fabricaDeServicios.getService("manifiesto.documentoOAManifiestoService");
		int cantidadNotaTarja = documentoOAManifiestoService.obtenerCantidadOperacionesAsociadaDocumentoTransporte(paramsBusqueda);
		if(cantidadNotaTarja != listaDocTransporte.size()){
			return false;
		}
		return true;
	}
	//hosoriov rin 12 fin
	public Integer contarRegistrosReporteRiesgos(Map<String, Object> params) throws ServiceException, Exception {
		Integer numeroRegistros;
		numeroRegistros = ((SeleccionService) fabricaDeServicios.getService("seleccion.SeleccionService")).obtenerCountReporteDeclaracion(params); 
		return  numeroRegistros;
	}
	public List <Map<String, Object>> obtenerReporteRiesgos (Map<String, Object> params) throws ServiceException, Exception {
		List<Map<String, Object>> obtener = null;
		List<Map<String, Object>> reporte = null;
		Map<String,Object> pruebita = new HashMap<String,Object>();
		String descripcionFraude;
		obtener = new ArrayList <Map<String, Object>> ();
		reporte = new ArrayList <Map<String, Object>> ();
		obtener = ((SeleccionService) fabricaDeServicios.getService("seleccion.SeleccionService")).obtenerReporteDeclaracion(params);
		for (Map<String, Object> seriesMap: obtener) {
			//Para Funcionario aduanero
			if (seriesMap.get("COD_FUNCIONARIO") != null && !seriesMap.get("COD_FUNCIONARIO").toString().trim().isEmpty()) {
				FiltroCatEmpleado filtro= new FiltroCatEmpleado();
				String funcionario = seriesMap.get("COD_FUNCIONARIO").toString().toUpperCase().trim();
				filtro.setCodPers(seriesMap.get("COD_FUNCIONARIO").toString().toUpperCase().trim());
				List<CatEmpleado> lista = ((EspecialistaService) fabricaDeServicios.getService("Asignacion.especialistaService")).buscarCatEmpleado(filtro);
				if (lista != null && !lista.isEmpty()) {
					for (CatEmpleado emple : lista) {
						String codUUOO =  !StringUtils.isEmpty(emple.getCodUniOrgDestaque())?emple.getCodUniOrgDestaque():emple.getCodUniOrg();
						if(codUUOO != null) {
							//Map<String,Object> datosFuncionario = catalogoAyudaService.getTabdep(codUUOO.trim());	
							//String codAduanaFuncionario = null;
							funcionario = seriesMap.get("COD_FUNCIONARIO").toString().toUpperCase().trim()
									+ " - " + emple.getApPate().trim() + " " + emple.getApMate().trim() + " " + emple.getNombres().trim();
						}
					}
				}
				seriesMap.put("COD_FUNCIONARIO", funcionario);
			}
			Map<String, Object> MapSeries = new HashMap<String, Object>(0);
			String sectipaforo = seriesMap.get("NUM_SECTIPAFORO") != null ? seriesMap.get("NUM_SECTIPAFORO").toString() : "";
			String codigoFraude = seriesMap.get("NFRAUDE") != null ? seriesMap.get("NFRAUDE").toString() : "";
			descripcionFraude = "";
			MapSeries.put("NUM_SECTIPAFORO", sectipaforo);
			MapSeries.put("COD_MOMENTO", codigoFraude);
			MapSeries.put("FEC_REGIS", SunatDateUtils.getIntegerFromDate(seriesMap.get("FEC_REGIS") != null ? SunatDateUtils.getDateFromUnknownFormat(seriesMap.get("FEC_REGIS").toString()) : 
				SunatDateUtils.getDate("01/01/1900", "dd/MM/yyyy")));
			if (!codigoFraude.trim().equals("") && codigoFraude.trim().length() == 4) {
				descripcionFraude = fraudesDAO.tipoFraudes(MapSeries);
				if (descripcionFraude == null || descripcionFraude.trim().equals("")) {
					descripcionFraude = " ------ ";
				}
			} else {
				descripcionFraude = " ------ ";
			}
			seriesMap.put("NFRAUDE", descripcionFraude);
			// Obtenemos la lista de la Series por cada herramienta solo las 5 mas riesgosas
			List<Map<String, Object>> listaSeriesTipoAforo = cabTipoAforoDeclaraDAO.valorSeriesTipoAforo(MapSeries);
			// obtenemos la cantidad de series por cada herramienta
			Integer rowSeries = cabTipoAforoDeclaraDAO.getMaxSeries(MapSeries);
			if (rowSeries == 0) {
				String NUM_SECSERIE = "0";
				seriesMap.put("NUM_SECSERIE", NUM_SECSERIE);
				reporte.add(seriesMap);
			} else {
				String NUM_SECSERIE = " ";
				String NUM_SECSERIE2 = "";
				int i = 0;
				for (Map<String, Object> ArraysJsonFila : listaSeriesTipoAforo) {
					i++;
					NUM_SECSERIE2 = ArraysJsonFila.get("NUM_SECSERIE").toString();
					NUM_SECSERIE += NUM_SECSERIE2 + "  ";
					if ((seriesMap.get("COD_TIPHERRA").toString().equals("04") || seriesMap.get("COD_TIPHERRA").toString().equals("02")) && i == 5)
					{
						break;
					}
				}
				seriesMap.put("NUM_SECSERIE", NUM_SECSERIE);
				reporte.add(seriesMap);
			}
		}

		return reporte;
	}

	//	<RIN10> 3014 ERUESTAA
	public CabAdiDeclaraDAO getCabAdiDeclaraDAO() {
		return cabAdiDeclaraDAO;
	}
	public void setCabAdiDeclaraDAO(CabAdiDeclaraDAO cabAdiDeclaraDAO) {
		this.cabAdiDeclaraDAO = cabAdiDeclaraDAO;
	}
	//	</RIN10> 3014 ERUESTAA

	//	<RIN10> 3012 ERUESTAA
	public CabCtaCteGarDAO getCabCtaCteGarDAO() {
		return cabCtaCteGarDAO;
	}
	public void setCabCtaCteGarDAO(CabCtaCteGarDAO cabCtaCteGarDAO) {
		this.cabCtaCteGarDAO = cabCtaCteGarDAO;
	}
	public MovCtaCteGaraDAO getMovCtaCteGaraDAO() {
		return movCtaCteGaraDAO;
	}
	public void setMovCtaCteGaraDAO(MovCtaCteGaraDAO movCtaCteGaraDAO) {
		this.movCtaCteGaraDAO = movCtaCteGaraDAO;
	}
	public CalculaDiaDAO getCalculaDiaDAO() {
		return calculaDiaDAO;
	}
	public void setCalculaDiaDAO(CalculaDiaDAO calculaDiaDAO) {
		this.calculaDiaDAO = calculaDiaDAO;
	} 
	//	</RIN10> 3012 ERUESTAA

	/*INICIO-P34 FSW AFMA*/
	public boolean tieneAsignadaDeclaracionOSolicitud(String numCorreDocDeclaracion,  String registroUsuarioLogeado){


		if(tieneAsignacion(numCorreDocDeclaracion,registroUsuarioLogeado)){
			return true;
		}

		String numCorreDocSolRegularizacion = obtenerNumCorreDoc(numCorreDocDeclaracion, REGU);

		if(tieneAsignacion(numCorreDocSolRegularizacion,registroUsuarioLogeado)){
			return true;
		}
		String numCorreDocSolLegajo = obtenerNumCorreDoc(numCorreDocDeclaracion,LEGAJO);
		if(tieneAsignacionLegajo(numCorreDocSolLegajo,registroUsuarioLogeado)){
			return true;
		}
		return  false;
	}

	private boolean tieneAsignacion(String numCorreDoc, String registroUsuarioLogeado)
	{
		if(numCorreDoc==null) return false;
		Map params = new HashMap();
		params.put("NUM_CORREDOC", numCorreDoc);
		params.put("COD_ESTREV", "06"); //estado asignado
		params.put("COD_FUNCIONARIO", registroUsuarioLogeado);
		// amancilla no debe agregar este campo se comenta
		//params.put("COD_PROCESOASIG",  Constantes.CODIGO_PROCESO_ASIGNADO);// P34 Se agrego este Campo

		Map mapEspeDocu =  espeDocuDAO.findbyDocEstRev(params);
		//P34 afma FSW
		if(CollectionUtils.isEmpty(mapEspeDocu)){
			params.put("COD_ESTREV", "10"); //estado asignado a conclusion
			mapEspeDocu =  espeDocuDAO.findbyDocEstRev(params);
		}


		return !CollectionUtils.isEmpty(mapEspeDocu)?true:false;
	}


	public void generaCuentaCorriente(String codFuncionario, Map declaracion) {/* INICIO PAS20175E220200051 */
		try {
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("codAdu", declaracion.get("COD_ADUANA").toString());
        params.put("annOrden", declaracion.get("ANN_PRESEN").toString());
        params.put("numDoc",(declaracion.get("NUM_DECLARACION").toString().trim()));
        String codUsuario = codFuncionario;
        params.put("codFuncionario", codUsuario);
        AutorizaInternacionDAO AutorizaInternacionDAO = fabricaDeServicios.getService("despaduanero2.solicitud.AutorizaInternacionDAO");
        DataSourceContextHolder.setKeyDataSource(declaracion.get("COD_ADUANA").toString());
		AutorizaInternacionDAO.generaCuentaCorriente(params);
		} catch (SQLException e) {
			log.error(e);
			throw new ServiceException(this,"Ha ocurrido un error al generar una cuenta corriente");			
		}
	}	/* FIN PAS20175E220200051 */

	/*inicio PAS20145E220000427*/
	public String tieneMercanciaDispuestaParcial(Long numCorreDoc){
		String mensajeError = "";	  
		List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();			
		Map<String, Object> paramMercancia = new HashMap<String, Object>();
		paramMercancia.put("NUM_CORREDOC", numCorreDoc);
		List<Map<String,Object>> lstMercDispuestas1 = null;
		lstMercDispuestas1= disposicionMercanciaService.findMercanciasDispuestaByNumCorredoc(paramMercancia); 
		int varMerDis=lstMercDispuestas1.size();
		if(lstMercDispuestas1.size()>0 && !lstMercDispuestas1.isEmpty() && lstMercDispuestas1!=null){
			lstResultadoMercancia.addAll(lstMercDispuestas1);
			for(int i=0; i<=varMerDis-1;i++){
				String item= (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
				String seriemd= (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
				String docDispo= (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
				String fecDocDispo= (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
				String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
				mensajeError += "Item[" + item + "] de la Serie [" + seriemd + "] cuenta con disposici�n de mercanc�as autorizada mediante [" + docDispo + "] de fecha [" + fecDoc1+"]\n";
				//return mensajeError;
			}	
		}
		return mensajeError;
	}
	/*fin PAS20145E220000427*/

  
	private boolean tieneAsignacionLegajo(String numCorreDoc, String registroUsuarioLogeado)
	{
		if(numCorreDoc==null) return false;
		Map params = new HashMap();
		params.put("NUM_CORREDOC", numCorreDoc);
		params.put("COD_ESTREV", "01"); ////estado asignado a solicitud de legajo (asi esta en produccion que vamos hacer)
		params.put("COD_FUNCIONARIO", registroUsuarioLogeado);

		Map mapEspeDocu =  espeDocuDAO.findbyDocEstRev(params);

		return !CollectionUtils.isEmpty(mapEspeDocu)?true:false;
	}

	private String obtenerNumCorreDoc(String numCorreDocDeclaracion, String tipo){


		Map params = new HashMap();
		params.put("NUM_CORREDOC", numCorreDocDeclaracion);
/*INICIO-P34 PAS20165E220200126 AFMA*/
		if(REGU.equals(tipo)){params.put("COD_TIPSOL", REGU);}
		else if(LEGAJO.equals(tipo)){params.put("COD_TIPSOL", LEGAJO);}
/*FIN-P34 PAS20165E220200126 AFMA*/
		return relacionDocDAO.findSolicitudByDocumento(params);
	}
	/*FIN-P34 FSW AFMA*/


	//Inicio - PAS20155E220200089
	public String adicionParametrosNumeroDeclaracion(Map<String, Object> declaracion, String DEFAULT_TIPO_DOC){     
		Long numeroCorredoc = declaracion.get("NUM_CORREDOC")!=null? new Long(declaracion.get("NUM_CORREDOC").toString()):new Long(0); //p24 arreglo salia nullpointer
		DeudaService deudaService = (DeudaService)fabricaDeServicios.getService("diligencia.ingreso.deudaService");
		String num_reliq = "";
		if(numeroCorredoc.compareTo(new Long(0))>0) {
			num_reliq = deudaService.obtenerNroDeReliqNumDeclaracion(numeroCorredoc);
		}
		String NUM_DECLARACIONLARGO=SunatStringUtils.lpad(declaracion.get("NUM_DECLARACION").toString(), 6, '0');
		String NUMRELIQ=SunatStringUtils.lpad(num_reliq, 2, '0');
		String numeroDeclaracionTitulo=declaracion.get("COD_ADUANA")+"-"+declaracion.get("ANN_PRESEN")+"-"+declaracion.get("COD_REGIMEN")+"-"+NUM_DECLARACIONLARGO+"-"+DEFAULT_TIPO_DOC+"-"+declaracion.get("COD_DIGVERI")+"-"+NUMRELIQ;
		declaracion.put("NUMRELIQ", NUMRELIQ);
		declaracion.put("NUM_DECLARACIONLARGO",NUM_DECLARACIONLARGO);
		declaracion.put("TIPO_DOC", DEFAULT_TIPO_DOC); 
		declaracion.put("numeroDeclaracionTitulo", numeroDeclaracionTitulo);
		return numeroDeclaracionTitulo; 	 
	}
	//Fin - PAS20155E220000089
	//PAS20155E410000032 - Inicio
	public boolean validarDamTieneMercanciaFranquicia(Long numCorreDoc){
		boolean damTieneMercanciaFranquicia = true;		
		//si tiene reg precedente de tipo 12 devuelvo true
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", numCorreDoc);
		params.put("COD_REGIMENPRE", Constantes.COD_TIPO_REGIMEN_PRECEDENTE_FRANQUICIA);
		params.put("IND_DEL", Constantes.IND_NO_ELIMINADO);
		List<Map<String, Object>> lstRegPrecedentes = docuPreceDuaDAO.select(params);
		if (CollectionUtils.isEmpty(lstRegPrecedentes)){
			damTieneMercanciaFranquicia = false;
		}

		return damTieneMercanciaFranquicia;
	}
	//PAS20155E410000032 - Fin
	public DisposicionMercanciaService getDisposicionMercanciaService() {
		return disposicionMercanciaService;
  	}
  
  	public void setDisposicionMercanciaService(
		DisposicionMercanciaService disposicionMercanciaService) {
		this.disposicionMercanciaService = disposicionMercanciaService;
  	}


  	/**INICIO PAS20155E220200129 - PAS20165E220200099**/
  	/*Se traslada m�todo de Despacho Controller*/
    //inicio gmontoya P24
   public Map<String, Object> obtenerDatosLevanteDuaSini(Map<String, Object> declaracionDua) throws ServiceException {
  		Map<String, Object> rspta = new HashMap<String, Object>();
            String aduana=declaracionDua.get("COD_ADUAMANIFIESTO").toString();
            String codRegimen=declaracionDua.get("COD_REGIMEN").toString();
  			if(aduana.equals("118")){
  				String[] regimenTMP = new String[] {"10","20" ,"21","70"};
  				if (Arrays.asList(regimenTMP).contains(codRegimen)) {
                Map<String, Object> parametro = new HashMap<String, Object>();
                Map<String, Object> parametros = new HashMap<String, Object>();
                List<Map<String,Object>> listAuxiliar = new ArrayList<Map<String,Object>> ();
                
                parametros.put("cod_regimen", declaracionDua.get("COD_REGIMEN").toString());
                parametros.put("codigoAduana", declaracionDua.get("COD_ADUAMANIFIESTO").toString());
                parametros.put("anioDocumento", declaracionDua.get("ANN_PRESEN").toString());
                parametros.put("numeroManifiesto", StringUtils.leftPad(declaracionDua.get("NUM_MANIFIESTO").toString(),6, " "));
                parametros.put("codigoViaTransporte", declaracionDua.get("COD_VIATRANS").toString());
                parametros.put("numdua", declaracionDua.get("NUM_DECLARACION").toString());//pruiz
                parametros.put("numdua", StringUtils.leftPad(declaracionDua.get("NUM_DECLARACION").toString(),6,"0"));
                
                
                SiniConsultaService siniConsultaService =fabricaDeServicios.getService("sigad.sini.SiniConsultaService");
                List<Map<String,Object>> listSini= siniConsultaService.evaluarContenedorSINIxDAM(parametros);
                String etiquetaSini=null;
             
                /*if (!CollectionUtils.isEmpty(listSini)){
                if(listSini.size()>0){
             	
                 etiquetaSini=	String.valueOf(listSini.get(0).get("DES_ESTADO"));
             	rspta.put("COD_ESTADO_SINI", listSini.get(0).get("COD_ESTADO"));
              
	                }else{
	                	//se obtiene los datos de la dua
	                    
	                    parametro.put("numeroCorrelativoDua", declaracionDua.get("NUM_CORREDOC").toString());
	                    parametros.put("anioManifiesto", declaracionDua.get("ANN_MANIFIESTO").toString());
	                    parametros.put("codigoTipoManifiesto", declaracionDua.get("COD_TIPMANIFIESTO").toString());
	                    EntradaSalidaService entradaSalidaService =  fabricaDeServicios.getService("declaracion.entradasalida.EntradaSalidaService");
	                    List<Manifiesto> lstManifiesto = entradaSalidaService.obtenerManifiesto(parametros);
	                    Long numeroCorrelativoManif = lstManifiesto.get(0).getNumeroCorrelativo();                                                                
	                    parametro.put("numeroCorrelativoManif", numeroCorrelativoManif);
	                    //Obtenemos Contenedores Declarados
	                    listAuxiliar=entradaSalidaService.obtenerContenedoresDeclarados(parametro);
	                    if (!listAuxiliar.isEmpty() && listAuxiliar!=null){
	                    	List<String> listaEquipaminetos = new ArrayList<String>();
	 	                    for(Map<String, Object> mapCon :listAuxiliar){
	 	                    	listaEquipaminetos.add((String)mapCon.get("numeroEquipamiento"));
	 	    				}
	 	                   
	 	                   parametros.put("listContenedores", listaEquipaminetos);
	 	            
	 	                    List<Map<String,Object>> listSiniManif= siniConsultaService.evaluarContenedorSINISinDestinar(parametros);
	 	                    if(!listSiniManif.isEmpty()){
	 	                    etiquetaSini=	String.valueOf(listSiniManif.get(0).get("DES_ESTADO"));
	 	                	rspta.put("COD_ESTADO_SINI", listSiniManif.get(0).get("COD_ESTADO"));
	 	                    }
	 	                   
	 	                }
	                 
	                  }
				}*/
  	                   
               	   rspta.put("DES_ESTADO_SINI", etiquetaSini);

                  }
               }

  		
  		return rspta;
  	}

	/**FIN PAS20165E220200099**/
    /*Inicio lalberti PASE DAM DIFERIDA SIN ICA*/
    private Boolean isDeclaracionConCargaDirectaOConsolidada1a1(Map<String,Object> declaracion){
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("NUM_CORREDOC",  declaracion.get("NUM_CORREDOC").toString());
		List<Map<String, Object>> lstSeries = serieService.select(params);
		if(!lstSeries.isEmpty()){
			for(Map<String,Object> serie:lstSeries){
				String tipoDocuTransporte = serie.get("COD_TIPDOCTRANSP").toString();
				if(!ArrayUtils.contains(new String[]{Constantes.COD_TIPO_DOCUMENTO_TRANSPORTE_DIRECTO,
													Constantes.COD_TIPO_DOCUMENTO_TRANSPORTE_CONSOLIDADO_1_1},
						tipoDocuTransporte)){
					return false;
				}
			}
			return true;
		}

		return false;
	}
    private Date getFechaLlegadaManifiestoDeclaracion(Map<String,Object> declaracion){
		Date fechaLlegada = null;
		String nroManifiesto = StringUtils.leftPad((String)declaracion.get("NUM_MANIFIESTO"), 6, '0');
		Integer anioManifiesto = Integer.valueOf(declaracion.get("ANN_MANIFIESTO").toString());
		String codigoAduana = declaracion.get("COD_ADUAMANIFIESTO").toString();
		String tipoManifiesto = declaracion.get("COD_TIPMANIFIESTO").toString();
		String viaTransporte = declaracion.get("COD_VIATRANS").toString();

		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		Manifiesto manifiesto =
				manifiestoService.findManifiestoByClaveDeNegocio(
						tipoManifiesto, viaTransporte, codigoAduana, anioManifiesto, nroManifiesto);

		if(manifiesto != null) {
			fechaLlegada = manifiesto.getFechaEfectivaDeLlegada();
		}
		return fechaLlegada;
	}

	private Boolean isVigenciaAbiertaValidacionesDAMSinIca(Date fechaLlegadaManifiesto){
		//Se verifica la fecha actual contra el catalogo de apertura 992
		Date fechaInicioVigencia = (Date) catalogoAyudaService.getElementoCat(Constantes.COD_CATALOGO_VIGENCIA_NUMERACION_SIN_ICA, "FEC_INIVIG").get("fec_inidatcat");
		if(fechaInicioVigencia != null){
			if (fechaLlegadaManifiesto!=null &&
					fechaLlegadaManifiesto.compareTo(fechaInicioVigencia) >= 0) {
				return true;
			}
		}
		return false;
	}

	private String validarDAMDiferidaSinICA(Map<String, Object> declaracion){
		String mensajeError = "";
		String codModalidad = declaracion.get("COD_MODALIDAD").toString();
		String codCanal = declaracion.get("COD_CANAL").toString();
		String codPuntoLlegada = declaracion.get("COD_LUGARRECEP").toString();
		String codRegimen = declaracion.get("COD_REGIMEN").toString();
		if(Constantes.COD_REGIMEN_10.equals(codRegimen) &&
				Constantes.COD_MODALIDAD_EXCEPCIONAL.equals(codModalidad) &&
				ArrayUtils.contains(new String[]{Constantes.CANAL_NARANJA,Constantes.CANAL_ROJO},codCanal) &&
				Constantes.COD_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codPuntoLlegada)
				){
			//Recien se verifica que todas las series tengan carga directa o consolidada 1 a 1
			Boolean isCargaDirecta = isDeclaracionConCargaDirectaOConsolidada1a1(declaracion);
			if(isCargaDirecta){
				mensajeError = Constantes.OBSERVACION_AVISO_RECTIFICACION_PUNTO_LLEGADA;
			}
		}
		return mensajeError;
	}

	private void notificarRectificacionPuntoLlegada(Map<String,Object> declaracion){
		SoporteAvisosService soporteAvisoService = fabricaDeServicios.getService("diligencia.ingreso.soporteAvisosService");
		String rucAgenteAduana = declaracion.get("NUM_DOCIDENT_PDE").toString();
		String observacion=Constantes.OBSERVACION_AVISO_RECTIFICACION_PUNTO_LLEGADA;
		//observacion calidad deberia estar compuesto el numero de declaracion
		String numeroDeclaracion = declaracion.get("COD_ADUANA").toString()+"-"+  declaracion.get("ANN_PRESEN").toString()+"-"+declaracion.get("COD_REGIMEN").toString()+"-"+declaracion.get("NUM_DECLARACION").toString();
		soporteAvisoService.notificarRectificacionPuntoLlegada(numeroDeclaracion,rucAgenteAduana,observacion);
	}
    /*Fin lalberti PASE DAM DIFERIDA SIN ICA*/

	
	 /** Metodo para obtener las lista de Eventos por dam:
	 *
	 * @param listaEventos
	 *          the lista eventos
	 * @return List
	 */
	private List<Map<String, Object>> obtenerListaEventos(Map<String, String> pkDocu, boolean usarRest)
	{
		List<Map<String, Object>> listaEventos = new ArrayList<Map<String, Object>>();
		if(usarRest) {
			RestTemplate restTemplate = fabricaDeServicios.getService("despaduanero2.declaracion.restTemplate");
		 	String consultarEventosPath = "/e/joinTipoEventoAforoDeclara?NUM_DECLARACION=%s&COD_ADUANA=%s&COD_REGIMEN=%s&ANN_DECLARA=%s";
			String consultarEventosUri = BASE_API_RIESGO_PATH + String.format(consultarEventosPath, pkDocu.get("NUM_DECLARACION"), pkDocu.get("COD_ADUANA"),
					pkDocu.get("COD_REGIMEN"),pkDocu.get("ANN_DECLARA"));

			DocumentoCanal documentoCanal =  restTemplate.getForObject(consultarEventosUri, DocumentoCanal.class);
			log.info(TAG_API_RIESGO + " PROCESO CORRECTAMENTE LA CONSULTA DE EVENTOS "+ pkDocu.get("NUM_CORREDOC").toString());
			List<Object> listEventos = documentoCanal.getValor();
			listaEventos  = convertirListaObjetosAListaMaps (listEventos);
		}
		return listaEventos;
	}


	private List<Map<String, Object>>  convertirListaObjetosAListaMaps (List<Object> listDatosRest ){
	List<Map<String, Object>> listaEventos = new ArrayList<Map<String, Object>>();
		if(listDatosRest!=null && listDatosRest.size()>0) {
			for(Object evento : listDatosRest) {
				Iterator i=((Map<String, Object>) evento).entrySet().iterator();
				Map<String, Object> mapEventos = new HashMap<String, Object>();
				while(i.hasNext()){
					Map.Entry<String,String> e=(Map.Entry)i.next();
					String nombre=(e.getKey()==null)?null :e.getKey().toUpperCase() ;
					mapEventos.put(nombre,e.getValue());
				}
				listaEventos.add(mapEventos);
			}
		}
		return listaEventos;
	}

	/*
	 * declaracion trae el regimen, canal, numctacte y numcorredoc, 
	 * finalmente se le setea el indicador de grabarFechaPostLevante
	 * @param declaracion
	 * @param fechadeclaracion
	 * @return
	 */
	public Map<String, Object> evalGrabarFechaPostLevante(Map<String, Object> declaracion, Date fechadeclaracion) {
		 
		boolean grabarFechaPostLevante = false;
		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		
		
		if( Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(declaracion.get("COD_REGIMEN"))
				&& (ConstantesDataCatalogo.COD_CANAL_ROJO.equals(declaracion.get("COD_CANAL"))||ConstantesDataCatalogo.COD_CANAL_NARANJA.equals(declaracion.get("COD_CANAL"))) ){
		
			Boolean tieneGarantia160 = (declaracion.get("NUM_CTACTE")!=null && declaracion.get("NUM_CTACTE").toString().trim().length()>0)?true:false;				
			
			if(getDeclaracionService.esVigenteNuevaLGAPorFecha(fechadeclaracion) && tieneGarantia160){
				//El motivo de Post Levante registrado sea 4- Indicadores de riesgo de lo contrario se ejecuta la excepci�n E1.(warning)
				// buscamos si tiene solicitud
			    Map<String,Object> paramSol = new HashMap<String, Object>();
			    paramSol.put("NUM_CORREDOC", declaracion.get("NUM_CORREDOC").toString().trim());
			    paramSol.put("COD_TIPSOL", TIPO_SOLICITUD_POSTLEVANTE);

			    List<Map<String, Object>> resultSol  = ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).findSolicitudesByDocumento(paramSol);
			    if(!CollectionUtils.isEmpty(resultSol)){
			        Map<String, Object> mapSolPostLevante  = resultSol.get(0); //se carga el primero con la mas reciente fec_solicitud
			        String numCorreDocSolicitud = mapSolPostLevante.get("NUM_CORREDOC")!=null?mapSolPostLevante.get("NUM_CORREDOC").toString():"";

			        if(StringUtils.isNotEmpty(numCorreDocSolicitud)){

			           SolicitudPostLevante solicitudPostLevante = new SolicitudPostLevante();
			           SolicitudPostLevante solicitudEncontrada = new SolicitudPostLevante();
			           solicitudPostLevante.setNumeroCorrelativo(new Long(numCorreDocSolicitud));
			           solicitudEncontrada = ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).get(solicitudPostLevante);
		               List<MotivoSolicitud> lstMotivos = ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).getMotivoSolicitudByNumeroCorrelativo(solicitudPostLevante.getNumeroCorrelativo());
		               solicitudEncontrada.setLsMotivos(lstMotivos);
		               solicitudPostLevante=solicitudEncontrada; 
		               
						if (solicitudPostLevante != null && !solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_ANULADA) && !CollectionUtils.isEmpty(solicitudPostLevante.getLsMotivos())) {
						boolean evaluarSolicitud = false;
							for(MotivoSolicitud motivosSol : solicitudPostLevante.getLsMotivos()){
								if (motivosSol.getCodMotivo().equals(TIPO_MOTIVO_IND_RIESGO) && motivosSol.getIndDel().equals(IND_MOTIVO_ACTIVO) ) {
									evaluarSolicitud=true;										
								}										
							}
							if(evaluarSolicitud){
								if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_REGISTRADO)) {
									declaracion.put("error", "Declaraci�n No cuenta con Post Levante, Motivo 4 Pendiente de evaluar"); // E1
								}
								if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_ACEPTADO)) {
									grabarFechaPostLevante = true;
								}
								if (solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_RECHAZADO)) {										
									declaracion.put("aviso", "Declaraci�n No cuenta con Post Levante, Motivo 4 Rechazado"); // E2
								}
							}else{
									if (!solicitudPostLevante.getEstadoSolicitud().equals(ESTADO_SOL_POSTLEV_RECHAZADO)) {	
										grabarFechaPostLevante = true;										
									}
							}
						}
			        }
			   }
			}
		}
		declaracion.put("grabarFechaPostLevante", grabarFechaPostLevante);
		return declaracion;
	}
	//Inicio PAS20191U220200011
	public  List<Map<String, Object>>  obtenerDatadoSimplificadaDUA(Map<String,Object> pk){
		List<Map<String, Object>>  listadoSimplif = new  ArrayList<Map<String, Object>>();
		Map<String,Object> datadoSigad = new HashMap<String,Object>();
		if(!ConstantesDataCatalogo.ADUANA_MANIFIESTO_POSTAL_NACIONAL.equals(pk.get("codi_aduan"))) {
		List<Map<String, Object>>  listadoDatadoxregimen = datadoValidacionService.obtenerDatadoSimplificadaDUA(pk);

		if(listadoDatadoxregimen!=null && !listadoDatadoxregimen.isEmpty()) {

			for(Map<String,Object> datadoDam : listadoDatadoxregimen) {
				String[] dam = datadoDam.get("DUA").toString().split("-");
				String aduanaDam = dam[0];
				Integer anioDam = new Integer(dam[1]);
				String regimenDam =  dam[2];
				String numDam = dam[3];

				if(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA.equals(regimenDam)
					|| ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ.equals(regimenDam)
					|| ConstantesDataCatalogo.REG_IMPO_COURIER_EER.equals(regimenDam)) {

		            DAMOperativaConsultaService dAMOperativaConsultaService =
		                    fabricaDeServicios.getService("declaracion.DAMOperativaConsultaService");
		            regimenDam = ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA.equals(regimenDam)?ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ:regimenDam;
		            //en este metodo los simplificados se buscan como regimen DQ, en la tabla datado si se busca como 18:
		            DUA damSigad = dAMOperativaConsultaService.ObtenerDAMOperativa(aduanaDam, regimenDam, anioDam, numDam);

		            if(damSigad!=null && damSigad.getFecdeclaracion()!=null) {
		            	datadoDam.put("FEC_DECLARACION",  SunatDateUtils.getFormatDate((Date) damSigad.getFecdeclaracion(), "yyyy-MM-dd"));
		            	listadoSimplif.add(datadoDam);
		            }
				}
			}
		}
		}
			//si es postal se complementa buscando en el mcdreg:
			//comentado hasta que se defina lo de postal
		else if(ConstantesDataCatalogo.ADUANA_MANIFIESTO_POSTAL_NACIONAL.equals(pk.get("codi_aduan"))) {
			ManifiestoDefinitivoService manifiestoDefinitivoService = fabricaDeServicios.getService("sigad.manifiesto.ManifiestoDefinitivoService");

			Map<String,Object> busquedaBasica = pk;
			busquedaBasica.remove("listRegDesti");
			List<Map<String, Object>>  listadoDatadoBasico = datadoValidacionService.obtenerDatadoSimplificadaDUA(pk);
			String listDamsReportar = "";
			if(listadoDatadoBasico!=null && !listadoDatadoBasico.isEmpty()) {

				for(Map<String, Object> datadoBasico : listadoDatadoBasico) {
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("nume_mc", pk.get("nume_mc"));
					params.put("anno", pk.get("anno").toString().substring(2));
					params.put("via_trans", pk.get("via_trans"));
					params.put("codi_aduan", pk.get("codi_aduan"));
					params.put("numcon", datadoBasico.get("NUMCON"));
					params.put("numdet", datadoBasico.get("NUMDET"));
					Map<String, Object> registroMcdreg =  manifiestoDefinitivoService.getMcdreg(params);

					if(registroMcdreg!=null && !registroMcdreg.isEmpty()) {
						Map<String,Object> simplificadas = new HashMap<String,Object>();
						String regimenDestino = registroMcdreg.get("REG_DESTI").toString();

						//polizadc es para postales solamente DC:
						if(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA.equals(regimenDestino)
									|| ConstantesDataCatalogo.REG_IMPO_COURIER_EER.equals(regimenDestino)) {

							DAMOperativaConsultaService dAMOperativaConsultaService =
							                fabricaDeServicios.getService("declaracion.DAMOperativaConsultaService");

							String DUANueva = registroMcdreg.get("CODI_ADUAN").toString().concat("-")
									.concat(pk.get("anno").toString()).concat("-").concat(regimenDestino)
									.concat("-").concat(registroMcdreg.get("NUME_REG").toString());

							regimenDestino = ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA.equals(regimenDestino)?
					          		ConstantesDataCatalogo.REG_IMPO_COURIER_EER:regimenDestino;


							if(!SunatStringUtils.isStringInList(DUANueva, listDamsReportar)) {
								//en este metodo los simplificados se buscan como regimen DC, en la tabla datado si se busca como 18:
								DUA damSigad = dAMOperativaConsultaService.ObtenerDAMOperativa(registroMcdreg.get("CODI_ADUAN").toString(),
								          		regimenDestino, new Integer(pk.get("anno").toString()), registroMcdreg.get("NUME_REG").toString());

								if(damSigad!=null && damSigad.getFecdeclaracion()!=null) {
										simplificadas.put("DUA", damSigad.getCodaduanaorden().concat("-")
												.concat("20").concat(damSigad.getAnnpresen().toString()).concat("-").concat(damSigad.getCodregimen())
												.concat("-").concat(damSigad.getNumdocumento()));
										Date fechaDatada = SunatDateUtils.getDateyyyMMdd( registroMcdreg.get("FECH_REG").toString());
										simplificadas.put("FEC_DATADA", registroMcdreg.get("FECH_REG"));
										simplificadas.put("NUMCON", registroMcdreg.get("NUMCON").toString());
										simplificadas.put("FEC_DECLARACION",  SunatDateUtils.getFormatDate((Date) damSigad.getFecdeclaracion(), "yyyy-MM-dd"));
								       	listadoSimplif.add(simplificadas);
										listDamsReportar = listDamsReportar.concat(",").concat(simplificadas.get("DUA").toString());
								}
							}
						}
					}
				}
		}

		}
		return listadoSimplif;
	}

	public List<Map<String, Object>>  obtenerDatadoManifAsigad(Map<String, Object> pkDocu, Manifiesto manifiesto){
		List<Map<String, Object>>  listado = new ArrayList<Map<String, Object>>();
		Map<String,Object> parametros = new HashMap<String, Object>();

		parametros.put("codigoAduana", manifiesto.getAduana().getCodDatacat());
		parametros.put("anioManifiesto", manifiesto.getAnioManifiesto().toString().substring(2));
		parametros.put("numeroManifiesto", manifiesto.getNumeroManifiesto());
		parametros.put("codigoViaTransporte", manifiesto.getViaTransporte().getCodDatacat());
		parametros.put("codregimen", pkDocu.get("regimen").toString());

		List<Map<String, Object>>  datadoAsigad = datadoValidacionService.consultarDatado(parametros) ;
		if(datadoAsigad!=null && !datadoAsigad.isEmpty()) {

			List<Map<String, Object>>  listDocTransp = (List<Map<String, Object>>) pkDocu.get("listadoDocuTrans");

			for(Map<String,Object> dataListado : datadoAsigad) {

				for(int i=0; i<listDocTransp.size(); i++){
					Map<String, Object> docu = listDocTransp.get(i);
					if(dataListado.get("NUMCON").equals(docu.get("NUM_DOCTRANSP").toString())
							&& dataListado.get("NUMDET").toString().trim().equals(docu.get("NUM_DETALLE").toString().trim())){
							dataListado.put("PESO_MANIF", docu.get("TPESO_BRUT"));
							dataListado.put("BULTO_MANIF", docu.get("CANT_BULTO"));
							dataListado.put("PESO_EXCEP", docu.get("TPESO_RECI"));
							dataListado.put("BULTO_EXCEP", docu.get("CANT_BRECI"));

							Map<String, Object> paramsDua = new HashMap<String, Object>();
							paramsDua.put("NUM_DECLARACION", SunatStringUtils.lpad(dataListado.get("NUME_REG").toString(),6,'0'));
							paramsDua.put("COD_ADUANA", dataListado.get("ADU_DESTI").toString());
							paramsDua.put("ANN_PRESEN", "20".concat(dataListado.get("ANNO_REG").toString()));
							paramsDua.put("COD_REGIMEN", dataListado.get("REG_DESTI").toString());
							Map<String, Object> datosDua = cabDeclaraDAO.findNumCorreDocAndNumOrdenByDeclaracion(paramsDua);
							dataListado.put("DUA", dataListado.get("ADU_DESTI").toString().concat("-20")
									.concat(dataListado.get("ANNO_REG").toString().concat("-")
									.concat(dataListado.get("REG_DESTI").toString().concat("-")
									.concat(SunatStringUtils.lpad(dataListado.get("NUME_REG").toString(),6,'0')))));
							if(datosDua!=null) {
								Date fechaDeclaracion = datosDua.get("FEC_DECLARACION")!=null? SunatDateUtils.getDate(datosDua.get("FEC_DECLARACION").toString(),"yyyy-MM-dd"):null;
								if(fechaDeclaracion!=null) {
									dataListado.put("FEC_DECLARACION",SunatDateUtils.getFormatDate(fechaDeclaracion, "yyyy-MM-dd"));
								}
							}
							break;
					}
				}



			}
			listado.addAll(datadoAsigad);
		}
		return listado;
	}

	public List<Map<String, Object>> obtenerDocumentosTransporteAsigad(String codigoViaTransporte,String  codigoAduana, Integer anioManifiesto,
			String numeroManifiesto, Long numcorredocDam){

		List<Map<String, Object>> listadoDocuTrans = new ArrayList<Map<String, Object>>();
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		Map<String, Object> paramDetDeclara = new HashMap<String, Object>();
		paramDetDeclara.put("NUM_CORREDOC",numcorredocDam);
		List<Map<String, Object>> listSerieMap = detDeclaraDAO.select(paramDetDeclara);
		int contador = 0;
		boolean tieneTarja = false;

		String mcdetabase = "";
		for (Map<String, Object> serieMap : listSerieMap) {
			ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("anioManifiesto", anioManifiesto);
			paramMap.put("codigoAduana", codigoAduana);
			paramMap.put("codigoViaTransporte", codigoViaTransporte);
			paramMap.put("numManifiesto", numeroManifiesto);
			paramMap.put("numeroDocumentoTransporte", serieMap.get("NUM_DOCTRANSP") .toString());
			paramMap.put("indicadorAnulado", "A");
			List<Map<String, Object>> listMcdeta = manifiestoSigadService.listarDocTransportesAsigad(paramMap);

			if (listMcdeta!=null && !listMcdeta.isEmpty()) {
				for(Map<String, Object> mapMcdeta : listMcdeta) {
				 	Map<String, Object> doctrans = new HashMap<String, Object>();
					doctrans.put("NUM_DOCTRANSP", mapMcdeta.get("NUMCON"));
					doctrans.put("NUM_DETALLE", mapMcdeta.get("NUMDET"));
					doctrans.put("COD_PUER_EMBAR", mapMcdeta.get("PUER_EMBAR"));

					Date fechaTarja = mapMcdeta.get("FECH_TARJA")!=null ? SunatDateUtils.getDate(mapMcdeta.get("FECH_TARJA").toString(),"yyyyMMdd"): null;
					if(fechaTarja!=null)doctrans.put("FECHATARJA",SunatDateUtils.getFormatDate(fechaTarja,"yyyy-MM-dd"));

					doctrans.put("NUM_CORREDOC", mapMcdeta.get("NUM_CORREDOC"));
					doctrans.put("CANT_BULTO", mapMcdeta.get("CANT_BULTO"));
					doctrans.put("TPESO_BRUT", mapMcdeta.get("TPESO_BRUT"));
					doctrans.put("CANT_BRECI", mapMcdeta.get("CANT_BRECI"));
					doctrans.put("TPESO_RECI", mapMcdeta.get("TPESO_RECI"));
					doctrans.put("FECZAR", mapMcdeta.get("FECZAR"));
					doctrans.put("ESTADO", mapMcdeta.get("ESTADO"));
					doctrans.put("DESCRIP", mapMcdeta.get("DESCRIP"));
					doctrans.put("CODI_TERM", mapMcdeta.get("CODI_TERM"));
					listadoDocuTrans.add(doctrans);
				}
			}
		}
		return listadoDocuTrans;
	}

	/*MCDETA.CODI_TERM (se llena luego de la transmisi�n del ICA)
	 * OPERAMANI.COD_DEPOSITO con COD_TIPOPERAC=2
	 * (en la transmisi�n del ICA no est� grabando este dato,
	 * pero deber�a ser el mismo que figura en la nota de tarja, ya que en la tarja el transportista indica a quien est� entregando la carga)
	 */
	public List<Map<String, Object>>  obtenerReceptorCargaDUAEnAsigad(Map<String, Object> paramMap){

		List<Map<String, Object>> listadoDocuTransreceptor = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> listadoDocuTrans = (List<Map<String, Object>>) paramMap.get("listadoDocuTrans");
		if(listadoDocuTrans!=null && !listadoDocuTrans.isEmpty()) {
			paramMap.put("cod_tipoperac", ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);//2
			paramMap.put("numdet",listadoDocuTrans.get(0).get("NUM_DETALLE").toString());
			List<Map<String, Object>>  listadoOperaciones = manifiestoSigadService.listMcDetaOperaciones(paramMap);

			if(listadoOperaciones!=null && !listadoOperaciones.isEmpty()) {
				String cod_deposito = listadoOperaciones.get(0).get("COD_DEPOSITO").toString();
				listadoDocuTransreceptor=manifiestoSigadService.obtenerDescripcionOperadorSigad(cod_deposito, paramMap.get("codi_aduan").toString());
			}
		}
		return listadoDocuTransreceptor;
	}

	public void obtenerFechaTarjaAsigad(Map<String, Object> paramMap) {

		List<Map<String, Object>> listadoDocuTrans = (List<Map<String, Object>>) paramMap.get("listadoDocuTrans");
		if(listadoDocuTrans!=null && !listadoDocuTrans.isEmpty()) {
			for (Map<String, Object> docutrans : listadoDocuTrans ) {
				paramMap.put("cod_tipoperac", ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);//2
				paramMap.put("numdet",docutrans.get("NUM_DETALLE").toString());
				List<Map<String, Object>>  listadoOperaciones = manifiestoSigadService.listMcDetaOperaciones(paramMap);
				if(listadoOperaciones!=null && !listadoOperaciones.isEmpty()) {
					docutrans.put("FECHATARJA", (Date)listadoOperaciones.get(0).get("fec_operac"));
				}
			}
		}
	}

	public void obtenerFechaIcaAsigad(Map<String, Object> paramMap){

		List<Map<String, Object>> listadoDocuTrans = (List<Map<String, Object>>) paramMap.get("listadoDocuTrans");
		if(listadoDocuTrans!=null && !listadoDocuTrans.isEmpty()) {
			for (Map<String, Object> docutrans : listadoDocuTrans ) {
				paramMap.put("cod_tipoperac", ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA);//4
				paramMap.put("numdet",docutrans.get("NUM_DETALLE").toString());
				List<Map<String, Object>>  listadoOperaciones = manifiestoSigadService.listMcDetaOperaciones(paramMap);
				if(listadoOperaciones!=null && !listadoOperaciones.isEmpty()) {
					docutrans.put("FECHAICA", (Date)listadoOperaciones.get(0).get("fec_operac"));
				}
			}
		}

	}

	//Fin PAS20191U220200011
}
// RIN16
////PAS20145E220000583-Consulta SERF
//<RIN10> 3012 ERUESTAA
//</RIN10> 3012 ERUESTAA
