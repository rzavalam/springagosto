package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

public class VehiCeticoServiceImpl implements VehiCeticoService
{
	protected final Log      log = LogFactory.getLog(this.getClass());
	
	private VehiCeticoDAO vehiCeticoDAO;
	
	private MontoGastoDAO montoGastoDAO;



	@Override
	public void insertarVehiculoCeticos(Map<String, Object> mapVehiculo) {
		// TODO Auto-generated method stub
		List<Map<String,Object>> listVehiculo = new ArrayList<Map<String,Object>>();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", mapVehiculo.get("NUM_CORREDOC"));
		params.put("NUM_SECSERIE", mapVehiculo.get("NUM_SECSERIE"));
		listVehiculo = vehiCeticoDAO.selectVehiCetico(params);
		if(CollectionUtils.isEmpty(listVehiculo)){
			vehiCeticoDAO.insertSelective(mapVehiculo);
		}else{
			mapVehiculo.put("IND_DEL", Constants.INDICADOR_NO_ELIMINADO);
			vehiCeticoDAO.updateSelective(mapVehiculo);
		}
		
	}


	@Override
	public void insertarMontoGasto(Map<String, Object> mapMontoGasto) {
		// TODO Auto-generated method stub
		List<Map<String,Object>> listMontoGasto = new ArrayList<Map<String,Object>>();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", mapMontoGasto.get("NUM_CORREDOC"));
		params.put("NUM_SECSERIE", mapMontoGasto.get("NUM_SECSERIE"));
		params.put("COD_CPTOGASTOS", mapMontoGasto.get("COD_CPTOGASTOS"));
		listMontoGasto = montoGastoDAO.select(params);
		if(CollectionUtils.isEmpty(listMontoGasto)){
			montoGastoDAO.insertSelective(mapMontoGasto);
		}else{
			mapMontoGasto.put("IND_DEL", Constants.INDICADOR_NO_ELIMINADO);
			montoGastoDAO.updateSelective(mapMontoGasto);
		}
		
	}


	@Override
	public void actualizarDatoEliminacionMontoGastoBySerie(Map<String, Object> mapParams) {
		// TODO Auto-generated method stub
		Map<String,Object> params = new HashMap<String, Object>();
		int filasActualizadas = 0;
		if(mapParams.get("NUM_CORREDOC")!=null && mapParams.get("NUM_SECSERIE")!=null){
			params.put("NUM_CORREDOC", mapParams.get("NUM_CORREDOC"));
			params.put("NUM_SECSERIE", mapParams.get("NUM_SECSERIE"));
			params.put("IND_DEL", mapParams.get("IND_DEL"));
			filasActualizadas = montoGastoDAO.updateDatoEliminacionBySerie(params);
			log.info("VehiCeticoServiceImpl.actualizarDatoEliminacionMontoGastoBySerie filas actualizadas: "+filasActualizadas);
		}
		
	}
	@Override 
	public List<DatoVehiculo> findVehiculoByMap(Map<String, Object> params)
			throws ServiceException {
		return vehiCeticoDAO.findVehiculoByMap(params);
	}
	
	@Override
	public List<Map<String,Object>> selectVehiCetico(Map<String, Object> params)
			throws ServiceException {
		return vehiCeticoDAO.selectVehiCetico(params);
	}

	@Override
	public List<DatoMontoGasto> findMontoGastoByMap(Map<String, Object> params)
			throws ServiceException {
		return montoGastoDAO.findMontoGastoByMap(params);
	}
	
	@Override
	public List<Map<String,Object>> selectMontoGasto(Map<String, Object> params)
			throws ServiceException {
		return montoGastoDAO.select(params);
	}

	public void setVehiCeticoDAO(VehiCeticoDAO vehiCeticoDAO) {
		this.vehiCeticoDAO = vehiCeticoDAO;
	}


	public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO) {
		this.montoGastoDAO = montoGastoDAO;
	}

}
