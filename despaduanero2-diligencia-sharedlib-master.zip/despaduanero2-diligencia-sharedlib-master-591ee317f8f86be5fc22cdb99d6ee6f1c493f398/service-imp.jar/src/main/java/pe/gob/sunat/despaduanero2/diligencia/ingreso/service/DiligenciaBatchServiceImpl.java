package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiAdmTemBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtpaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtreexBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FinUbicacionBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUABatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoBatchDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoBatchDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocBatchDAO;

public class DiligenciaBatchServiceImpl implements DiligenciaBatchService{
	//rtineo mejoras, grabacion rectificacion Electronica
	RectiOficioBatchDAO rectiOficioBatchDAO;
	DetAdiAtpaBatchDAO detAdiAtpaBatchDAO;
	CabAdiAdmTemBatchDAO cabAdiAdmTemBatchDAO;
	CabAdiImpoConsuBatchDAO cabAdiImpoConsuBatchDAO;
	CabDeclaraBatchDAO cabDeclaraBatchDAO;
	ComprobPagoBatchDAO comprobPagoBatchDAO;
	FormBProveedorBatchDAO formBProveedorBatchDAO;
	ConvenioSerieBatchDAO convenioSerieBatchDAO;
	DetAdiImpoconsuBatchDAO detAdiImpoconsuBatchDAO;
	DetAdiAtreexBatchDAO detAdiAtreexBatchDAO;
	DetDeclaraBatchDAO detDeclaraBatchDAO;
	DocAutAsociadoBatchDAO docAutAsociadoBatchDAO;
	DocuPreceDuaBatchDAO docuPreceDuaBatchDAO;
	EquipamientoBatchDAO equipamientoBatchDAO;
	FacturaSerieBatchDAO facturaSerieBatchDAO;
	FinUbicacionBatchDAO finUbicacionBatchDAO;
	FormaFactuBatchDAO formaFactuBatchDAO;
	IndicadorDUABatchDAO indicadorDUABatchDAO;
	ItemFacturaBatchDAO itemFacturaBatchDAO;
	ObservacionBatchDAO observacionBatchDAO;
	ParticipanteDocBatchDAO participanteDocBatchDAO;
	SeriesItemBatchDAO seriesItemBatchDAO;
	DetAutorizacionBatchDAO detAutorizacionBatchDAO;
	VFOBProvisionalBatchDAO vFOBProvisionalBatchDAO;
	CondicionTransaBatchDAO condicionTransaBatchDAO;
	FactuSuceBatchDAO factuSuceBatchDAO;
	VehiCeticoBatchDAO vehiCeticoBatchDAO;
	FormBMontoBatchDAO formBMontoBatchDAO;
	CabCertiOrigenBatchDAO cabCertiOrigenBatchDAO;
	FormBItemDescriBatchDAO formBItemDescriBatchDAO;
	MontoGastoBatchDAO montoGastoBatchDAO;
	//rtineo mejoras, fin
	
	//rtineo, grabar Tablas de Rectificacion
	@Override
	public void iniciarRegistrarRectificacion() {
		rectiOficioBatchDAO.iniciar();
		//detAdiAtpaBatchDAO.iniciar();
		cabAdiAdmTemBatchDAO.iniciar();
		cabAdiImpoConsuBatchDAO.iniciar();
		cabDeclaraBatchDAO.iniciar();
		comprobPagoBatchDAO.iniciar();
		formBProveedorBatchDAO.iniciar();
		detAdiImpoconsuBatchDAO.iniciar();
		detAdiAtreexBatchDAO.iniciar();//se movio aqui
		detDeclaraBatchDAO.iniciar();
		detAdiAtpaBatchDAO.iniciar();
		//ggranados se inserta los convenios 
		//despues de las series
		convenioSerieBatchDAO.iniciar();
		docAutAsociadoBatchDAO.iniciar();
		docuPreceDuaBatchDAO.iniciar();
		equipamientoBatchDAO.iniciar();
		facturaSerieBatchDAO.iniciar();
		finUbicacionBatchDAO.iniciar();
		formaFactuBatchDAO.iniciar();
		indicadorDUABatchDAO.iniciar();
		itemFacturaBatchDAO.iniciar();
		observacionBatchDAO.iniciar();
		participanteDocBatchDAO.iniciar();
		seriesItemBatchDAO.iniciar();
		detAutorizacionBatchDAO.iniciar();
		vFOBProvisionalBatchDAO.iniciar();
		condicionTransaBatchDAO.iniciar();
		factuSuceBatchDAO.iniciar();
		vehiCeticoBatchDAO.iniciar();
		formBMontoBatchDAO.iniciar();
		cabCertiOrigenBatchDAO.iniciar();
		formBItemDescriBatchDAO.iniciar();
		montoGastoBatchDAO.iniciar();
	}
	
	@Override
	public void procesarRegistrarRectificacion() throws Exception {
		rectiOficioBatchDAO.procesarBatch();
        cabAdiAdmTemBatchDAO.procesarBatch();//T0047
        cabAdiImpoConsuBatchDAO.procesarBatch();//T0048
        cabDeclaraBatchDAO.procesarBatch();//T0051
      //  comprobPagoBatchDAO.procesarBatch();//T0038
        detDeclaraBatchDAO.procesarBatch();//T0052
        detAdiAtpaBatchDAO.procesarBatch();//T0028
        detAdiAtreexBatchDAO.procesarBatch();//T0029
        detAdiImpoconsuBatchDAO.procesarBatch();//T0092
        docAutAsociadoBatchDAO.procesarBatch();//T0063
        docuPreceDuaBatchDAO.procesarBatch();//T0050
        equipamientoBatchDAO.procesarBatch();//T0112
        finUbicacionBatchDAO.procesarBatch();//T0068
        formaFactuBatchDAO.procesarBatch();//T0016
        facturaSerieBatchDAO.procesarBatch();//T0015
        formBProveedorBatchDAO.procesarBatch();//T0070
        comprobPagoBatchDAO.procesarBatch();//T0038 // POR BUG PASE 139
        indicadorDUABatchDAO.procesarBatch();//T0060   
        itemFacturaBatchDAO.procesarBatch();//T0078
        observacionBatchDAO.procesarBatch();//T0083
        participanteDocBatchDAO.procesarBatch();//T0087
        seriesItemBatchDAO.procesarBatch();//T0043
        cabCertiOrigenBatchDAO.procesarBatch();//T0037
        detAutorizacionBatchDAO.procesarBatch();//T0033
        //ggranados se inserta los convenios 
        //despues de las series
        convenioSerieBatchDAO.procesarBatch();//T0042
        vFOBProvisionalBatchDAO.procesarBatch();//T0105
        condicionTransaBatchDAO.procesarBatch();//T0039
        factuSuceBatchDAO.procesarBatch();//T0067
        vehiCeticoBatchDAO.procesarBatch();//T0106
        formBMontoBatchDAO.procesarBatch();//T0080
        formBItemDescriBatchDAO.procesarBatch();//T0069
        montoGastoBatchDAO.procesarBatch();//T0079

	}
	//rtineo mejoras, fin
	public void setRectiOficioBatchDAO(RectiOficioBatchDAO rectiOficioBatchDAO) {
		this.rectiOficioBatchDAO = rectiOficioBatchDAO;
	}

	public void setDetAdiAtpaBatchDAO(DetAdiAtpaBatchDAO detAdiAtpaBatchDAO) {
		this.detAdiAtpaBatchDAO = detAdiAtpaBatchDAO;
	}

	public void setCabAdiAdmTemBatchDAO(CabAdiAdmTemBatchDAO cabAdiAdmTemBatchDAO) {
		this.cabAdiAdmTemBatchDAO = cabAdiAdmTemBatchDAO;
	}

	public void setCabAdiImpoConsuBatchDAO(
			CabAdiImpoConsuBatchDAO cabAdiImpoConsuBatchDAO) {
		this.cabAdiImpoConsuBatchDAO = cabAdiImpoConsuBatchDAO;
	}

	public void setCabDeclaraBatchDAO(CabDeclaraBatchDAO cabDeclaraBatchDAO) {
		this.cabDeclaraBatchDAO = cabDeclaraBatchDAO;
	}

	public void setComprobPagoBatchDAO(ComprobPagoBatchDAO comprobPagoBatchDAO) {
		this.comprobPagoBatchDAO = comprobPagoBatchDAO;
	}

	public void setFormBProveedorBatchDAO(
			FormBProveedorBatchDAO formBProveedorBatchDAO) {
		this.formBProveedorBatchDAO = formBProveedorBatchDAO;
	}

	public void setConvenioSerieBatchDAO(ConvenioSerieBatchDAO convenioSerieBatchDAO) {
		this.convenioSerieBatchDAO = convenioSerieBatchDAO;
	}

	public void setDetAdiImpoconsuBatchDAO(
			DetAdiImpoconsuBatchDAO detAdiImpoconsuBatchDAO) {
		this.detAdiImpoconsuBatchDAO = detAdiImpoconsuBatchDAO;
	}

	public void setDetAdiAtreexBatchDAO(DetAdiAtreexBatchDAO detAdiAtreexBatchDAO) {
		this.detAdiAtreexBatchDAO = detAdiAtreexBatchDAO;
	}

	public void setDetDeclaraBatchDAO(DetDeclaraBatchDAO detDeclaraBatchDAO) {
		this.detDeclaraBatchDAO = detDeclaraBatchDAO;
	}

	public void setDocAutAsociadoBatchDAO(
			DocAutAsociadoBatchDAO docAutAsociadoBatchDAO) {
		this.docAutAsociadoBatchDAO = docAutAsociadoBatchDAO;
	}

	public void setDocuPreceDuaBatchDAO(DocuPreceDuaBatchDAO docuPreceDuaBatchDAO) {
		this.docuPreceDuaBatchDAO = docuPreceDuaBatchDAO;
	}

	public void setEquipamientoBatchDAO(EquipamientoBatchDAO equipamientoBatchDAO) {
		this.equipamientoBatchDAO = equipamientoBatchDAO;
	}

	public void setFacturaSerieBatchDAO(FacturaSerieBatchDAO facturaSerieBatchDAO) {
		this.facturaSerieBatchDAO = facturaSerieBatchDAO;
	}

	public void setFinUbicacionBatchDAO(FinUbicacionBatchDAO finUbicacionBatchDAO) {
		this.finUbicacionBatchDAO = finUbicacionBatchDAO;
	}

	public void setFormaFactuBatchDAO(FormaFactuBatchDAO formaFactuBatchDAO) {
		this.formaFactuBatchDAO = formaFactuBatchDAO;
	}

	public void setIndicadorDUABatchDAO(IndicadorDUABatchDAO indicadorDUABatchDAO) {
		this.indicadorDUABatchDAO = indicadorDUABatchDAO;
	}

	public void setItemFacturaBatchDAO(ItemFacturaBatchDAO itemFacturaBatchDAO) {
		this.itemFacturaBatchDAO = itemFacturaBatchDAO;
	}

	public void setObservacionBatchDAO(ObservacionBatchDAO observacionBatchDAO) {
		this.observacionBatchDAO = observacionBatchDAO;
	}

	public void setParticipanteDocBatchDAO(
			ParticipanteDocBatchDAO participanteDocBatchDAO) {
		this.participanteDocBatchDAO = participanteDocBatchDAO;
	}

	public void setSeriesItemBatchDAO(SeriesItemBatchDAO seriesItemBatchDAO) {
		this.seriesItemBatchDAO = seriesItemBatchDAO;
	}

	public void setDetAutorizacionBatchDAO(
			DetAutorizacionBatchDAO detAutorizacionBatchDAO) {
		this.detAutorizacionBatchDAO = detAutorizacionBatchDAO;
	}

	public void setvFOBProvisionalBatchDAO(
			VFOBProvisionalBatchDAO vFOBProvisionalBatchDAO) {
		this.vFOBProvisionalBatchDAO = vFOBProvisionalBatchDAO;
	}

	public void setCondicionTransaBatchDAO(
			CondicionTransaBatchDAO condicionTransaBatchDAO) {
		this.condicionTransaBatchDAO = condicionTransaBatchDAO;
	}

	public void setFactuSuceBatchDAO(FactuSuceBatchDAO factuSuceBatchDAO) {
		this.factuSuceBatchDAO = factuSuceBatchDAO;
	}

	public void setVehiCeticoBatchDAO(VehiCeticoBatchDAO vehiCeticoBatchDAO) {
		this.vehiCeticoBatchDAO = vehiCeticoBatchDAO;
	}

	public void setFormBMontoBatchDAO(FormBMontoBatchDAO formBMontoBatchDAO) {
		this.formBMontoBatchDAO = formBMontoBatchDAO;
	}

	public void setCabCertiOrigenBatchDAO(
			CabCertiOrigenBatchDAO cabCertiOrigenBatchDAO) {
		this.cabCertiOrigenBatchDAO = cabCertiOrigenBatchDAO;
	}

	public void setFormBItemDescriBatchDAO(
			FormBItemDescriBatchDAO formBItemDescriBatchDAO) {
		this.formBItemDescriBatchDAO = formBItemDescriBatchDAO;
	}

	public void setMontoGastoBatchDAO(MontoGastoBatchDAO montoGastoBatchDAO) {
		this.montoGastoBatchDAO = montoGastoBatchDAO;
	}
}
