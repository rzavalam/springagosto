package pe.gob.sunat.controladuanero2.ingreso.postlevante.service;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.DetEvaluacion;
import pe.gob.sunat.despaduanero2.model.MotivoSolicitud;

import pe.gob.sunat.despaduanero2.model.SolicitudPostLevante;
import pe.gob.sunat.despaduanero2.model.dao.*;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;

import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by amancillaa on 19/04/2016.
 */
@Service
//@Transactional
public class SolicitudPostLevanteServiceImpl implements SolicitudPostLevanteService{

    public static final String CATALOGO_VIGENCIA = "380";
    public static final String COD_CAR_FECHA_LGA = "0021";//cambio por PAS20165E220200087 de 0015 a 0021 vigencia post levante
    public static final String SECUENCIA_CORRELATIVODOCUMENTO = "SEDOCUMENTO";
    public final static String COD_DOC_RECTIFICACION="332";
    public static final String TIPO_SOLICITUD_POSTLEVANTE = "25";
    public static final String CATALOGO_565_ESTADO_GENERADO = "00";
    public static final String CATALOGO_565_ESTADO_APROBADO = "01";
    public static final String CATALOGO_565_ESTADO_RECHAZADO = "02";
    public static final String CATALOGO_565_ESTADO_ANULADO = "99";

    protected final Log log = LogFactory.getLog(getClass());

    @Autowired
    private FabricaDeServicios fabricaDeServicios;

    //@Transactional(readOnly=true)
    public ObjectResponseUtil validarDeclaracion(String aduanaDeclaracion, String anioDeclaracion, String regimenDeclaracion, String numeroDeclaracion, UsuarioBean usuario) throws ServiceException {


        ObjectResponseUtil rpta = new ObjectResponseUtil();

        DeclaracionService declaracionService = fabricaDeServicios.getService("diligencia.ingreso.declaracionService");

        DUA dua = declaracionService.buscarDatosGeneralesDUAByClaveDeNegocio(aduanaDeclaracion, Integer.valueOf(anioDeclaracion), regimenDeclaracion, Integer.valueOf(numeroDeclaracion));

        //La DAM debe existir en la base de datos
        if(dua == null){
            rpta.addMensaje("Declaraci\u00f3n no registrada en la base de datos", "Verifique", true);
            return rpta;
        }

        Declaracion declaracion = new Declaracion();
        declaracion.setDua(dua);

        //La DAM debe haber sido numerada despu�s de la fecha de inicio de vigencia de la norma
        if(!duaNumeradaDespuesFechaInicioNormaLGA(declaracion)){
            rpta.addMensaje("Declaraci\u00f3n numerada antes de la vigencia del DL 1235. No corresponde usar esta opci\u00f3n", "Verifique", true);
            return rpta;
        }

        //La DAM debe estar asociada a una garant�a 160� y ser r�gimen 10
        if(!Constantes.COD_REGIMEN_IMPORTACION_CONSUMO.equals(declaracion.getDua().getCodregimen())
                || StringUtils.isEmpty(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia())){

            rpta.addMensaje("Declaraci\u00f3n sin garant\u00eda 160 no aplica proceso Post-Levante", "Verifique", true);
            return rpta;
        }

        //La DAM debe estar asignada a canal de control rojo o naranja
        if(!Constantes.CANAL_ROJO.equals(declaracion.getDua().getCodCanal())
                && !Constantes.CANAL_NARANJA.equals(declaracion.getDua().getCodCanal())){
            rpta.addMensaje("Declaraci\u00f3n debe estar asignada a canal de control rojo o naranja", "Verifique", true);
            return rpta;
        }



        //La DAM no debe contar con diligencia de despacho
        if(tieneDiligenciaDespacho(declaracion)){
            rpta.addMensaje("Declaraci\u00f3n ya cuenta con diligencia de despacho", "Verifique", true);
            return rpta;
        }

        //La DAM debe estar asignada al funcionario
        if(!tieneAsignadaDeclaracion(declaracion,usuario)){
            rpta.addMensaje("Declaraci\u00f3n no se encuentra asignada al funcionario", "Verifique", true);
            return rpta;
        }

        rpta.setRespuesta(true);
        rpta.addDato("declaracion", declaracion);

        // buscamos si tiene solicitud
        Map<String,Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
        params.put("COD_TIPSOL", TIPO_SOLICITUD_POSTLEVANTE);

        List<Map<String, Object>> res  = ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).findSolicitudesByDocumento(params);
        if(CollectionUtils.isNotEmpty(res)){
            Map<String, Object> mapSolPostLevante  = res.get(0); //se carga el primero con la mas reciente fec_solicitud
            String numCorreDocSolicitud = mapSolPostLevante.get("NUM_CORREDOC")!=null?mapSolPostLevante.get("NUM_CORREDOC").toString():"";

            if(StringUtils.isNotEmpty(numCorreDocSolicitud)){
                SolicitudPostLevante solicitudPostLevante = new SolicitudPostLevante();
                solicitudPostLevante.setNumeroCorrelativo(new Long(numCorreDocSolicitud));
                solicitudPostLevante = obtenerSolicitud(solicitudPostLevante);
                if(solicitudPostLevante!=null && !"99".equals(solicitudPostLevante.getEstadoSolicitud())){
                	//ECANA 20170907 REQ 2016-135388 Si la solicitud ha sido rechazada por el supervisor, y existe el motivo POST LEVANTE "04", entonces el estado de la solicitud vuelve a '00' para que pueda ser modificado el motivo
                	if ("02".equals(solicitudPostLevante.getEstadoSolicitud())){
                        for(MotivoSolicitud motivo: solicitudPostLevante.getLsMotivos()){
                            if("04".equals(motivo.getCodMotivo()) && "0".equals(motivo.getIndDel())){
                            	//solicitudPostLevante.setEstadoSolicitud("00");
                            	//break;
                            	return rpta;
                            }
                        }
                	}
                    rpta.addDato("solicitud", solicitudPostLevante);
                }
            }
        }

        return rpta;
    }


    @Override
    public ObjectResponseUtil validarAprobacionSolicitud(String aduanaDeclaracion, String anioDeclaracion, String regimenDeclaracion, String numeroDeclaracion, UsuarioBean usuario) throws Exception {
        ObjectResponseUtil rpta = new ObjectResponseUtil();

        DeclaracionService declaracionService = fabricaDeServicios.getService("diligencia.ingreso.declaracionService");

        DUA dua = declaracionService.buscarDatosGeneralesDUAByClaveDeNegocio(aduanaDeclaracion, Integer.valueOf(anioDeclaracion), regimenDeclaracion, Integer.valueOf(numeroDeclaracion));

        //La DAM debe existir en la base de datos
        if(dua == null){
            rpta.addMensaje("Declaraci\u00f3n no registrada en la base de datos", "Verifique", true);
            return rpta;
        }

        Declaracion declaracion = new Declaracion();
        declaracion.setDua(dua);




        // buscamos si tiene solicitud
        Map<String,Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
        params.put("COD_TIPSOL", TIPO_SOLICITUD_POSTLEVANTE);

        List<Map<String, Object>> res  = ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).findSolicitudesByDocumento(params);
        if(CollectionUtils.isNotEmpty(res)){
            Map<String, Object> mapSolPostLevante  = res.get(0); //se carga el primero con la mas reciente fec_solicitud
            String numCorreDocSolicitud = mapSolPostLevante.get("NUM_CORREDOC")!=null?mapSolPostLevante.get("NUM_CORREDOC").toString():"";

            if(StringUtils.isNotEmpty(numCorreDocSolicitud)){

                SolicitudPostLevante solicitudPostLevante = new SolicitudPostLevante();
                solicitudPostLevante.setNumeroCorrelativo(new Long(numCorreDocSolicitud));
                solicitudPostLevante = obtenerSolicitud(solicitudPostLevante);
                if(solicitudPostLevante!=null){
                    if("00".equals(solicitudPostLevante.getEstadoSolicitud())){

                        //la solicitud debe estar asignada al JEFE
                        if(!rolValido(solicitudPostLevante,declaracion,usuario)){
                            Map mapRoles = (Map) usuario.getMap().get("roles");
                            rpta.addMensaje("Solicitud debe ser aprobado por funcionario con el Rol JEFE, Rol:"+mapRoles.values().toString()+" no corresponde.", "Verifique", true);
                            return rpta;
                        }
                        rpta.addDato("declaracion", declaracion);
                        rpta.addDato("solicitud", solicitudPostLevante);

                    }else{
                        CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

                        String estado = catalogoAyudaService.getDescripcionDataCatalogo("565",solicitudPostLevante.getEstadoSolicitud());
                        rpta.addMensaje("Autorizaci\u00f3n de Post-levante ya fue evaluada con estado: "+estado, "Verifique", true);
                        return rpta;
                    }
                }else{
                    rpta.addMensaje("Declaraci\u00f3n no cuenta con solicitud post-levante solicitada", "Verifique", true);
                    return rpta;
                }
            }
        }else{

            rpta.addMensaje("Declaraci\u00f3n no cuenta con solicitud post-levante solicitada", "Verifique", true);
            return rpta;
        }


        return rpta;
    }


    @Override
    public void insertarSolicitud(SolicitudPostLevante solicitud) throws ServiceException {

        //como es nuevo se genera un correlativo
        Long numCorreDocSolicitud =((SequenceDAO)fabricaDeServicios.getService("sequenceDAO")).getNextSequence(SECUENCIA_CORRELATIVODOCUMENTO);

        Documento documento = new Documento();
        documento.setNumeroCorrelativo(numCorreDocSolicitud);
        documento.setEstado("00");//duracel no puede estar vacio
        documento.setTipoDocumento(COD_DOC_RECTIFICACION); //332  es tipo SOLICITUD
        documento.setCodAduana(solicitud.getCodAduana() !=null?solicitud.getCodAduana():"000");
        documento.setTipoDiligencia("25"); // seta el tipo de solicitud
        //falta tiposol pero el bean no lo tiene generar el 25 codigo por refactorizar

        Date fechaActual= new Date(System.currentTimeMillis());
        documento.setFechaGeneracion(fechaActual);
        DocumentoDAO documentoDAO = fabricaDeServicios.getService("despaduanero2.documentoDAO");
        documentoDAO.insertSelective(documento);

        //Actualiza IND_JGRUPOCONCLUSION (BANDEJA_DOCU) solo si el estado es generado
        if(debeEnviarseAprobacionJefe(solicitud)){
            Map<String, Object> mapActualizaBandeja = new HashMap <String, Object>();
            mapActualizaBandeja.put("numeroCorrelativo", numCorreDocSolicitud);
            mapActualizaBandeja.put("ind_jgrupoconclusion", "1");
            documentoDAO.actualizarBandeja(mapActualizaBandeja,false);
        }

        Map<String,Object> mapRelacion = new HashMap<String, Object>();
        mapRelacion.put("numCorredoc",  numCorreDocSolicitud);
        mapRelacion.put("numCorredocPre",solicitud.getNumeroCorrelativo()); //se fuerza para envio correlativo de la declaacion
        mapRelacion.put("annPresen",solicitud.getAnnoSolicitud());
        mapRelacion.put("codRegimen",solicitud.getRegimen());
        mapRelacion.put("numDeclaracion",solicitud.getNumeroDiligencia()); //se fuerza para elvio num_declaracion
        mapRelacion.put("codAduana",solicitud.getCodAduana()!=null?solicitud.getCodAduana():"000");

        ((RelacionDocDAO)fabricaDeServicios.getService("despaduanero2.relacionDocDAO")).insertMapSelective(mapRelacion);


        Map params = new HashMap();
        params.put("CODADUANA",solicitud.getCodAduana());
        params.put("ANNSOL",solicitud.getAnnoSolicitud());
        Map numeroSolicitud = ((SolicitudDAO)fabricaDeServicios.getService("despaduanero2.solicitudDAO")).selectLastSequence(params);
        Integer numSol= numeroSolicitud.get("SEQUENCE")!=null?new Integer(numeroSolicitud.get("SEQUENCE").toString()):0;

        // inserta cabsolicitu por referencia
        mapRelacion.put("NUMCORREDOC",numCorreDocSolicitud);
        mapRelacion.put("ANNSOL",solicitud.getAnnoSolicitud());
        mapRelacion.put("NUMSOL",numSol);
        mapRelacion.put("CODREGIMEN",solicitud.getRegimen());
        mapRelacion.put("CODTIPSOL", TIPO_SOLICITUD_POSTLEVANTE); //25 SOLICITUD POST-LEVANTE
        mapRelacion.put("FECSOLICITUD", SunatDateUtils.getCurrentDate());
        mapRelacion.put("CODESTSOL",CATALOGO_565_ESTADO_GENERADO ); //
        //mapRelacion.put("CODESTSOL",solicitud.getEstadoSolicitud());

        ((SolicitudDAO)fabricaDeServicios.getService("despaduanero2.solicitudDAO")).insertSelectivoSolicitud(mapRelacion);
        //se llena los datos que necesita
        solicitud.setNumeroCorrelativo(numCorreDocSolicitud);
        for(MotivoSolicitud motivo: solicitud.getLsMotivos()){
            motivo.setNumCorrelativo(numCorreDocSolicitud);
        }

        ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).insert(solicitud);
        ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).insertBatch(solicitud.getLsMotivos());

    }

    private boolean debeEnviarseAprobacionJefe(SolicitudPostLevante solicitud) {

        boolean debeEnviarseAprobacionJefe = false;
        for(MotivoSolicitud motivo: solicitud.getLsMotivos()){
            if("04".equals(motivo.getCodMotivo()) && "0".equals(motivo.getIndDel())){
                debeEnviarseAprobacionJefe = true;
            }
        }
        return debeEnviarseAprobacionJefe;
    }

    @Override
    public void modificarSolicitud(SolicitudPostLevante solicitud) throws ServiceException {


        //Actualiza IND_JGRUPOCONCLUSION (BANDEJA_DOCU) solo si se seleciono el codigo 04
        DocumentoDAO documentoDAO = fabricaDeServicios.getService("despaduanero2.documentoDAO");
        Map<String, Object> mapActualizaBandeja = new HashMap <String, Object>();
        mapActualizaBandeja.put("numeroCorrelativo", solicitud.getNumeroCorrelativo());
        if(debeEnviarseAprobacionJefe(solicitud)){
            mapActualizaBandeja.put("ind_jgrupoconclusion", "1");
        }else{ //si no tiene 04 y se le quito debe quitarse de la bandeja
            mapActualizaBandeja.put("ind_jgrupoconclusion", "0");
        }
        documentoDAO.actualizarBandeja(mapActualizaBandeja,false);


        ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).update(solicitud);
        ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).updateBatch(solicitud.getLsMotivos());
    }

    @Override
    public void eliminarSolicitud(SolicitudPostLevante solicitud) throws ServiceException {

        // inserta cabsolicitu por referencia
        Map mapSolicitud = new HashMap();
        mapSolicitud.put("NUM_CORREDOC",solicitud.getNumeroCorrelativo());
        mapSolicitud.put("COD_ESTSOL",CATALOGO_565_ESTADO_ANULADO );

        ((SolicitudDAO)fabricaDeServicios.getService("despaduanero2.solicitudDAO")).updateEstado (mapSolicitud);
        ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).update(solicitud);

        DocumentoDAO documentoDAO = fabricaDeServicios.getService("despaduanero2.documentoDAO");
        //Actualiza IND_JGRUPOCONCLUSION (BANDEJA_DOCU)
        Map<String, Object> mapActualizaBandeja = new HashMap <String, Object>();
        mapActualizaBandeja.put("numeroCorrelativo", solicitud.getNumeroCorrelativo());
        mapActualizaBandeja.put("ind_jgrupoconclusion", "0");
        documentoDAO.actualizarBandeja(mapActualizaBandeja, false);
    }

    @Override
    public void aceptarSolicitud(SolicitudPostLevante solicitud) throws ServiceException {


        // Grabar en Det_evaluacion
        DetEvaluacion detEvaluacion = new DetEvaluacion();
        detEvaluacion.setNumCorreDoc(solicitud.getNumeroCorrelativo());
        detEvaluacion.setCodTipEvaluacion("1");
        detEvaluacion.setNumSecEvaluacion(1L); //secuencia 1
        detEvaluacion.setObsObs("APROBACION SOLICITUD POST-LEVANTE");
        detEvaluacion.setDesResulEval(" ");
        detEvaluacion.setIndBorrador("0");
        detEvaluacion.setCodResultadoEval("1");
        detEvaluacion.setFecEvaluacion(SunatDateUtils.getCurrentDate());
        detEvaluacion.setFecAprobada(SunatDateUtils.getCurrentDate());

        ((DetEvaluacionDAO)fabricaDeServicios.getService("despaduanero2.detEvaluacionDAO")).insert(detEvaluacion);


        Map mapSolicitud = new HashMap();
        mapSolicitud.put("NUM_CORREDOC",solicitud.getNumeroCorrelativo());
        mapSolicitud.put("COD_ESTSOL",CATALOGO_565_ESTADO_APROBADO );

        ((SolicitudDAO)fabricaDeServicios.getService("despaduanero2.solicitudDAO")).updateEstado (mapSolicitud);





        DocumentoDAO documentoDAO = fabricaDeServicios.getService("despaduanero2.documentoDAO");
        //Actualiza IND_JGRUPOCONCLUSION (BANDEJA_DOCU)
        Map<String, Object> mapActualizaBandeja = new HashMap <String, Object>();
        mapActualizaBandeja.put("numeroCorrelativo", solicitud.getNumeroCorrelativo());
        mapActualizaBandeja.put("ind_jgrupoconclusion", "0");
        documentoDAO.actualizarBandeja(mapActualizaBandeja, false);

    }

    @Override
    public void rechazarSolicitud(SolicitudPostLevante solicitud) throws ServiceException {

        // Grabar en Det_evaluacion
        DetEvaluacion detEvaluacion = new DetEvaluacion();
        detEvaluacion.setNumCorreDoc(solicitud.getNumeroCorrelativo());
        detEvaluacion.setCodTipEvaluacion("1");
        detEvaluacion.setNumSecEvaluacion(1L); //secuencia 1
        detEvaluacion.setObsObs("RECHAZO SOLICITUD POST-LEVANTE");
        detEvaluacion.setDesResulEval(" ");
        detEvaluacion.setIndBorrador("0");
        detEvaluacion.setCodResultadoEval("0"); //0 RECAHZADO
        detEvaluacion.setFecEvaluacion(SunatDateUtils.getCurrentDate());
        detEvaluacion.setFecAprobada(SunatDateUtils.getCurrentDate());

        Map mapSolicitud = new HashMap();
        mapSolicitud.put("NUM_CORREDOC",solicitud.getNumeroCorrelativo());
        mapSolicitud.put("COD_ESTSOL",CATALOGO_565_ESTADO_RECHAZADO );

        ((SolicitudDAO)fabricaDeServicios.getService("despaduanero2.solicitudDAO")).updateEstado (mapSolicitud);


        DocumentoDAO documentoDAO = fabricaDeServicios.getService("despaduanero2.documentoDAO");

        //Actualiza IND_JGRUPOCONCLUSION (BANDEJA_DOCU)
        Map<String, Object> mapActualizaBandeja = new HashMap <String, Object>();
        mapActualizaBandeja.put("numeroCorrelativo", solicitud.getNumeroCorrelativo());
        mapActualizaBandeja.put("ind_jgrupoconclusion", "0");
        documentoDAO.actualizarBandeja(mapActualizaBandeja, false);

    }

    @Override
    //@Transactional(readOnly=true)
    public SolicitudPostLevante obtenerSolicitud(SolicitudPostLevante solicitud) throws ServiceException {

        SolicitudPostLevante solicitudEncontrada = ((SoliPostLevanteDAO)fabricaDeServicios.getService("despaduanero2.soliPostLevanteDAO")).get(solicitud);

        List<MotivoSolicitud> lstMotivos = ((MotivoSoliDAO)fabricaDeServicios.getService("despaduanero2.motivoSoliDAO")).getMotivoSolicitudByNumeroCorrelativo(solicitud.getNumeroCorrelativo());
        solicitudEncontrada.setLsMotivos(lstMotivos);



        return solicitudEncontrada;
    }


    //@Transactional(readOnly=true)
    private boolean tieneDiligenciaDespacho(Declaracion declaracion) {

        Map<String, Object> paramsDiligenciaDespacho = new HashMap<String, Object>();
        paramsDiligenciaDespacho.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
        paramsDiligenciaDespacho.put("listaTipoDiligencia", new String[] {Constantes.DILIG_REV_DOCUMENTARIA, Constantes.DILIG_REC_FISICO});

        DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");

        return diligenciaService.hasDiligencia(paramsDiligenciaDespacho);
    }

    //@Transactional(readOnly=true)
    private boolean tieneAsignadaDeclaracion(Declaracion declaracion, UsuarioBean usuario) {

        //La DAM debe estar asignada al funcionario
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("num_corredoc", declaracion.getDua().getNumcorredoc());
        params.put("cod_estrev", "06");

        AsignacionService asignacionService = fabricaDeServicios.getService("Asignacion.asignacionService");

        String codigoFuncionario = asignacionService.obtenerCodigoUltimoEspecialistaAsignado(params);

        return codigoFuncionario.equalsIgnoreCase(usuario.getNroRegistro().trim())?true:false;
    }


    private boolean rolValido(SolicitudPostLevante solicitudPostLevante,Declaracion declaracion, UsuarioBean usuario) throws Exception{

        boolean rolValido = false;

       Map  mapRoles = (Map) usuario.getMap().get("roles");
        Map<String, Object> mapDeclaracion = new HashMap();
        mapDeclaracion.put("COD_REGIMEN",declaracion.getDua().getCodregimen());
        mapDeclaracion.put("COD_ADUANA",declaracion.getCodAduana());
        mapDeclaracion.put("COD_TIPTRATMERC",declaracion.getDua().getCodtipotratamiento());
        mapDeclaracion.put("ANN_PRESEN",declaracion.getDua().getAnnpresen());
         mapDeclaracion.put("NUM_DECLARACION", declaracion.getNumeroDeclaracion());


        rolValido = ((AsignacionService) fabricaDeServicios.getService("Asignacion.asignacionService")).validaUsuarioRolProrrogaConclusion(mapDeclaracion, mapRoles.values().toArray());

        return rolValido;
    }

   // @Transactional(readOnly=true)
    private boolean duaNumeradaDespuesFechaInicioNormaLGA(Declaracion declaracion) {

        boolean esVigente = false;
        CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

        Object fecha = catalogoAyudaService.getElementoCat(CATALOGO_VIGENCIA, COD_CAR_FECHA_LGA).get("fec_inidatcat");
        if(fecha!=null){
            Date fecInicioVigenciaLGA = SunatDateUtils.getDateFromUnknownFormat(fecha.toString());
            Date fechaReferencia = declaracion.getDua().getFecdeclaracion();
            if (fecInicioVigenciaLGA != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fecInicioVigenciaLGA,SunatDateUtils.COMPARA_SOLO_FECHA)) {
                esVigente = true;
            }
        }

        return esVigente;
    }


    public boolean tienePECO(Long numCorredocDeclaracion) throws ServiceException{

        boolean esPecoAmazonia=false;

        Map<String, Object> param= new HashMap<String, Object>();
        param.put("numCorreDoc", numCorredocDeclaracion);
        param.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
        Elementos<DatoSerie> series = new Elementos<DatoSerie>();

        DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("diligencia.ingreso.detDeclaraDef");

        series.addAll(detDeclaraDAO.findSerie(param));

        List<Map<String,Object>> lstConv;
        Map<String,Object> paramConvSerie=new HashMap<String, Object>();
        for (DatoSerie serie :series) {
            paramConvSerie.put("NUM_CORREDOC", numCorredocDeclaracion);
            paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
            paramConvSerie.put("COD_TIPCONVENIO", "C"); //4438 LEY AMAZONIA RIN08

            ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("diligencia.ingreso.convenioSerieDef");

            lstConv=convenioSerieDAO.select(paramConvSerie);
            for(Map<String,Object> beanMap:lstConv){
                String cod_convenio = beanMap.get("COD_CONVENIO").toString().trim();
                if (ArrayUtils.contains(new String[]{"4437", ConstantesDataCatalogo.COD_TIP_4438}, cod_convenio)){
                    esPecoAmazonia=true;
                    break;
                }
            }

            if (!esPecoAmazonia) {
                paramConvSerie.put("NUM_CORREDOC", numCorredocDeclaracion);
                paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
                paramConvSerie.put("COD_TIPCONVENIO", "I"); // TPI
                lstConv=convenioSerieDAO.select(paramConvSerie);
                for (Map<String, Object> beanMap : lstConv) {
                    String cod_convenio = beanMap.get("COD_CONVENIO").toString().trim();
                    if (ArrayUtils.contains(new String[]{ ConstantesDataCatalogo.COD_TIP_34,
                                    ConstantesDataCatalogo.COD_TIP_35,
                                    ConstantesDataCatalogo.COD_TIP_36},
                            cod_convenio)){
                        esPecoAmazonia = true;
                        break;
                    }
                }
            }
            if (esPecoAmazonia) {
                break;
            }
        }

        return esPecoAmazonia;
    }
}
