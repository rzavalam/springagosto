package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ConsultaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;

public class ConsultaServiceImpl implements ConsultaService {

	protected final Log log = LogFactory.getLog(this.getClass());
	private ConsultaDAO consultaDAO;
	private CatalogoAyudaService catalogoAyudaService;
	private SolicitudService solicitudService;
	private PublicacionAvisoService publicacionAvisoService;
	private FabricaDeServicios fabricaDeServicios;
	private AduanaRol aduanaRol;

	public static final String ASUNTO_PL_NOTI_REM_REC_FISICO_JEFE = "Aviso de Remisi�n de DUA canal naranja a Reconocimiento F�sico";
	private static final String JEFE_RFISICO = "JEFE.GRUPO.RECONOCIMIENTO.FISICO";
	private static final String JEFE_RFISICO_IMPORTACION = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.IMPORTACION";
	private static final String JEFE_RFISICO_ADMISION_TEMPORAL = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.ADMISION.TEM";
	private static final String JEFE_RFISICO_DEPOSITO = "JEFE.GRUPO.RECONOCIMIENTO.FISICO.DEPOSITO";

	@Override
	public Consulta obtenerConsulta(Consulta consulta) throws ServiceException {
		Consulta consultaRes = consultaDAO.findByPk(consulta);
		if (consultaRes != null) {
			JsonSerializer serializer = new JsonSerializer();
			// Se agrega descripci�n de motivos
			if (!StringUtils.isEmpty(consultaRes.getStrMotivos().trim())) {
				Map<String, ArrayList<String>> mapIdMotivos = new HashMap<String, ArrayList<String>>();
				ArrayList<String> listaIdMotivos = new ArrayList<String>();
				mapIdMotivos = (Map<String, ArrayList<String>>) serializer.deserialize(consultaRes.getStrMotivos().trim(), HashMap.class);
				listaIdMotivos = (ArrayList<String>) mapIdMotivos.get("amoti");
				ArrayList<DataCatalogo> listaDataCatalogo = new ArrayList<DataCatalogo>();
				for (int j = 0; j < listaIdMotivos.size(); j++) {
					DataCatalogo motivo = new DataCatalogo();
					motivo.setCodDatacat(listaIdMotivos.get(j).toString());
					motivo.setDesDatacat(catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_MOTIVO_DUA_NARANJA, listaIdMotivos.get(j).toString()));
					listaDataCatalogo.add(motivo);
				}
				consultaRes.setMotivos(listaDataCatalogo);
			}
			// Se agrega datos del creador de la consulta
			if (consultaRes.getFuncionario().getCodPers() != null)
				consultaRes.setFuncionario(solicitudService.getFuncionarioByCodPers(consultaRes.getFuncionario().getCodPers()));
			// Se agrega dotos del aprobador
			if (consultaRes.getAprobador().getCodPers() != null)
				consultaRes.setAprobador(solicitudService.getFuncionarioByCodPers(consultaRes.getAprobador().getCodPers()));
		}
		return consultaRes;
	}

	@Override
	public List<Consulta> buscarConsultaSimple(Consulta consulta) throws ServiceException {
		List<Consulta> listaConsulta = consultaDAO.findByConsulta(consulta);
		return listaConsulta;
	}

	@Override
	public List<Consulta> buscarConsulta(Consulta consulta) throws ServiceException {
		List<Consulta> listaConsulta = consultaDAO.findByConsulta(consulta);
		// if (consulta.isFlagMotivos()) {
		JsonSerializer serializer = new JsonSerializer();
		Map<String, ArrayList<String>> mapIdMotivos = new HashMap<String, ArrayList<String>>();
		ArrayList<String> listaIdMotivos = new ArrayList<String>();
		for (int i = 0; i < listaConsulta.size(); i++) {
			// Agrega descripciones de conceptos
			if (!StringUtils.isEmpty(listaConsulta.get(i).getStrMotivos().trim())) {
				mapIdMotivos = (Map<String, ArrayList<String>>) serializer.deserialize(listaConsulta.get(i).getStrMotivos().trim(), HashMap.class);
				listaIdMotivos = (ArrayList<String>) mapIdMotivos.get("amoti");
				ArrayList<DataCatalogo> listaDataCatalogo = new ArrayList<DataCatalogo>();
				for (int j = 0; j < listaIdMotivos.size(); j++) {
					DataCatalogo motivo = new DataCatalogo();
					motivo.setCodDatacat(listaIdMotivos.get(j).toString());
					motivo.setDesDatacat(catalogoAyudaService.getDescripcionDataCatalogo(Constantes.CAT_MOTIVO_DUA_NARANJA, listaIdMotivos.get(j).toString()));
					listaDataCatalogo.add(motivo);
				}
				listaConsulta.get(i).setMotivos(listaDataCatalogo);
			}
			// Agrega datos funcionario
			if (listaConsulta.get(i).getFuncionario().getCodPers() != null)
				listaConsulta.get(i).setFuncionario(solicitudService.getFuncionarioByCodPers(listaConsulta.get(i).getFuncionario().getCodPers()));
			// Agrega datos de aprobador
			if (listaConsulta.get(i).getAprobador().getCodPers() != null)
				listaConsulta.get(i).setAprobador(solicitudService.getFuncionarioByCodPers(listaConsulta.get(i).getAprobador().getCodPers()));
		}
		// }
		return listaConsulta;
	}

	/**
	 * Grabar notificaciones producto de la remisi�n de la DUA a reconocimieno f�sico
	 * 
	 * @param dua
	 * @param consulta
	 */
	private void grabarNotificacionesRemisionReconFisico(DUA dua, Consulta consulta) {

		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		List<Map<String, Object>> listaJefes = null;
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer data = new StringBuffer();

		// Obtener jefes
		listaJefes = this.obtenerJefesReconFisico(dua.getCodaduanaorden(), dua.getCodregimen());
		// Enviar notificaciones
		Map<String, Object> mapMensajeRFJefe = new HashMap<String, Object>();
		mapMensajeRFJefe.put("tip_usuario", "3");
		mapMensajeRFJefe.put("des_asunto", ASUNTO_PL_NOTI_REM_REC_FISICO_JEFE);
		mapMensajeRFJefe.put("cod_aduana", dua.getCodaduanaorden());
		mapMensajeRFJefe.put("ann_presen", dua.getAnnpresen().toString());
		mapMensajeRFJefe.put("cod_regimen", dua.getCodregimen());
		mapMensajeRFJefe.put("num_declaracion", dua.getNumdocumento());
		mapMensajeRFJefe.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		String strGarantia = dua.getPago().getPagoDeclaracion().getCodgarantia() != null && !dua.getPago().getPagoDeclaracion().getCodgarantia().isEmpty() ? "Garantia del articulo 160 de la LGA"
				: "-";
		mapMensajeRFJefe.put("garantia", strGarantia);
		// mapMensaje.put("numruc_consig",
		// declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		if (listaJefes != null && listaJefes.size() != 0) {
			for (int i = 0; i < listaJefes.size(); i++) {
				mapMensajeRFJefe.put("cod_usuario", new String[] { listaJefes.get(i).get("cod_pers").toString() });
				mapMensajeRFJefe.put("registro", consulta.getFuncionario().getCodPers());
				mapMensajeRFJefe.put("nombre", consulta.getFuncionario().getApPate() + " " + consulta.getFuncionario().getApMate() + " "
						+ consulta.getFuncionario().getNombres());
				data = new StringBuffer(SojoUtil.toJson(mapMensajeRFJefe));
				this.publicacionAvisoService.insert(Constantes.COD_PL_NOTI_REM_REC_FISICO_JEFE, data, Constantes.CODIGO_AVISO_ELECTRONICO,
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}
		}
		// mapMensaje.put("cod_aduana",
		// declaracion.getDua().getCodaduanaorden());
		// mapMensaje.put("ann_presen",
		// declaracion.getDua().getAnnpresen().toString());
		// mapMensaje.put("cod_regimen",
		// declaracion.getDua().getCodregimen().toString());
		// mapMensaje.put("num_declaracion", strNumeroDeclaracion);
		// mapMensaje.put("numruc_consig",
		// declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		// mapMensaje.put("des_intendencia", descAduana);
		// mapMensaje.put("lnk_consultaDua", linkDua);
	}

	@Override
	public Integer obtenerSecuenciaMaximaConsulta(Consulta consulta) throws ServiceException {
		return consultaDAO.selectMaxNumSec(consulta);
	}

	@Override
	public void grabarConsulta(Consulta consulta) {
		int numSec = this.obtenerSecuenciaMaximaConsulta(consulta).intValue() + 1;
		consulta.setNumeroSecuencia(numSec);
		consultaDAO.insert(consulta);
	}

	@Override
	public void grabarSolicitudReconFisico(DUA dua, Consulta consulta) {
		this.grabarConsulta(consulta);
		this.grabarNotificacionesRemisionReconFisico(dua, consulta);
	}

	@Override
	public List<Map<String, Object>> obtenerJefesReconFisico(String codAduana, String codRegimen) {
		List<Map<String, Object>> listaJefes = null;

	    try
	    {
			//AduanaRol aduanaRol = fabricaDeServicios.getService("tecnologia.menu.intranet.aduanaRolService");
			if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen)) {
				listaJefes = aduanaRol.getEmpleados(codAduana, JEFE_RFISICO_IMPORTACION);
			} else if (Constantes.REGIMEN_70_DEPOSITO.equals(codRegimen)) {
				listaJefes = aduanaRol.getEmpleados(codAduana, JEFE_RFISICO_DEPOSITO);
			} else if (Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals(codRegimen) || Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals(codRegimen)) {
				listaJefes = aduanaRol.getEmpleados(codAduana, JEFE_RFISICO_ADMISION_TEMPORAL);
			}
			if (listaJefes == null || listaJefes.size() == 0) {
				listaJefes = aduanaRol.getEmpleados(codAduana, JEFE_RFISICO);
				if (listaJefes == null || listaJefes.size() == 0) {
					log.error("NO SE ENCONTRARON JEFES PARA ENVIO DE AVISO ELECTRONICO PARA RECONOCIMIENTO FISICO DE OFICIO ");
				}
			}
	    	
	    } catch (Exception e)
	    {
	      log.error(e);
	      log.error("NO SE PUDO OBTENER LISTA DE JEFES PARA AVISO ELECTRONICO PARA RECONOCIMIENTO FISICO DE OFICIO");
	    }

		return listaJefes;
	}

	/**
	 * {@inheritDoc}
	 */
	// hsaenz: 10/09/2014
	public List<Map<String, Object>> obtenerJefesGrupo(Map<String, Object> params, String[] roles) {
		List<Map<String, Object>> listaJefes = null;
		 try{
			 if(log.isDebugEnabled()) log.debug("Inicio - obtenerJefesGrupo:"+params.get("declaracion").toString()+" BUSCANDO JEFES PARA ADUANA:"+params.get("cod_aduana"));
			 
			 listaJefes = aduanaRol.getEmpleados(params.get("cod_aduana").toString(), roles);
			 
			 if(listaJefes == null || listaJefes.isEmpty()) {
				 log.error("NO SE ENCONTRARON JEFES");
				 
				 if(log.isDebugEnabled()) log.debug("Fin - obtenerJefesGrupo:"+params.get("declaracion").toString()+" NO SE ENCONTRARON JEFES PARA ENVIO DE AVISO ELECTRONICO PARA NOTIFICACION VENCIMIENTO");
			 }
			 
		 } catch(Exception e) {
			 log.error("Error interno en la aplicación. El error es: " + e.getMessage(), e);
		     log.error("NO SE PUDO OBTENER LISTA DE JEFES");
		 }
		 
		 return listaJefes;
	}

	public void setConsultaDAO(ConsultaDAO consultaDAO) {
		this.consultaDAO = consultaDAO;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void setSolicitudService(SolicitudService solicitudService) {
		this.solicitudService = solicitudService;
	}

	public void setPublicacionAvisoService(PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setAduanaRol(AduanaRol aduanaRol) {
		this.aduanaRol = aduanaRol;
	}		

}