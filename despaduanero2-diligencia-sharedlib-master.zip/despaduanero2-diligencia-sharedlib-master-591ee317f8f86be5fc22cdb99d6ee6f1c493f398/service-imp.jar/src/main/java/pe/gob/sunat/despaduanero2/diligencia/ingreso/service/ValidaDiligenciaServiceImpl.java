package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.administracion2.tramite.model.DocumentoSustento;
import pe.gob.sunat.administracion2.tramite.model.TipoDocumentoSustentatorio;
import pe.gob.sunat.administracion2.tramite.model.dao.ExpediDAO;
import pe.gob.sunat.administracion2.tramite.service.DocumentoSustentoService;
import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDetdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDocSop;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDescMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValFactura;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValSerieItemFB;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GetValidacionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.CTUsuarios;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AladlibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CTUsuariosDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandlibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;

@SuppressWarnings({ "rawtypes" })
public class ValidaDiligenciaServiceImpl implements ValidaDiligenciaService
{
  protected final Log              log         = LogFactory.getLog(getClass());

//  private CatRefpartidasDAO        catRefPartidasDAO;

  private DetAutorizacionDAO       detAutorizacionDAO;

  private CabDiligenciaDAO         cabDiligenciaDAO;

  private CatRefRucDAO             catRefRucDAO;

  private DocuPreceDuaDAO          docuPreceDuaDAO;

  private CTUsuariosDAO            ctUsuariosDAO;

  private FabricaDeServicios       fabricaDeServicios;

  private HotSwappableTargetSource swapperDatasource;

  private AladlibeDAO              aladlibeDAO;

  private NandlibeDAO              nandlibeDAO;

  private ExpediDAO                expediDAO;

  private PlazosProcesoDAO         plazosProcesoDAO;

  //private GetValidacionesService   validacionesService;

  private OperadorValidaService    operadorValidaService;
  
  private SoporteService           soporteService;

private AyudaService ayudaService;
/*inicio P21-P22*/
private static final String CATALOGO_ULTRACTIVIDAD = "I1";
/*fin P21-P22*/



  /**
   * Valida merc ayuda humanitaria.
   *
   * @param params
   *          caduana : codigo de la aduana a la que corresponde el documento
   *          COD_TIPTRATMERC : Valor de la declaracion NUM_PARTNANDI : Valor de
   *          pantalla (series) FEC_DECLARACION : Valor de la declaracion
   *          COD_REGIMEN : Valor de la declaracion
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaMercAyudaHumanitaria(Map params)
      throws ServiceException
  {
    String res = "";

    String codRegimen = (String) params.get("COD_REGIMEN");

    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
//      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
//          + params.get("caduana").toString().trim()));
    	DataSourceContextHolder.setKeyDataSource(params.get("caduana").toString().trim());//gmontoya rest
      if (Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals(params.get("COD_TIPTRATMERC").toString().trim()))
      {
        params.put("tipo_uso", Constantes.TIPO_USO_MERCANCIA_DONACION);
        params.put("cnan", params.get("NUM_PARTNANDI"));
        params.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(params.get("FEC_DECLARACION")));

       // List lstCatRef = this.catRefPartidasDAO.getCatRefPartidas(params);
        
        params.put("ayudaID", "CatRefpartidas");
    	List<CatRefpartidas> lstCatRef =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);
        
        
        if (CollectionUtils.isEmpty(lstCatRef))
        {
          res = "No se ha encontrado referencia para el tratamiento de la mercaderia como donacion, por favor modifique la partida o el tipo de tratamiento.";
        }
      }
    }

    return res;
  }

  /**
   * Valida incentivo migrat.
   *
   * @param params
   *          caduana : aduana de atencion IND_ACOGCODLIBER : data de pantalla
   *          COD_EXONMERC : data de pantalla NUM_CORREDOC : data de det_declara
   *          NUM_SECSERIE : data de det_declara COD_REGIMEN : data de
   *          cab_declara COD_ADUANA : data de cab_declara CTIPODOC : data de
   *          cab_declara CDOCUMEN : data de cab_declara FEC_DECLARACION : data
   *          de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaIncentivoMigrat(Map params) throws ServiceException
  {
    String res = "";

    String codRegimen = (String) params.get("COD_REGIMEN");

    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
      if (params.get("CTIPODOC") != null && "4".equals(params.get("CTIPODOC").toString().trim()))
      {
        String codLib[] = Constantes.INCENTIVO_MIGRATORIO_CODIGO_LIBERATORIOS.split("|");
        boolean validar = false;
        if (Constantes.FLAG_INDICADOR_MARCADO.equals(params.get("IND_ACOGCODLIBER").toString()))
        {
          String codExonmerc = (String) params.get("COD_EXONMERC");
          for (int i = 0; i < codLib.length; i++)
          {
            if (codLib[i].equals(codExonmerc))
            {
              validar = true;
              break;
            }
          }

          if (validar)
          {
            Map paramsAut = new HashMap();
            paramsAut.put("NUM_CORREDOC", params.get("NUM_CORREDOC"));
            paramsAut.put("NUM_SECSERIE", params.get("NUM_SECSERIE"));
            paramsAut.put("COD_TIPOPER", Constantes.TIPO_PROCEDENCIA_IMPORTADOR);
            paramsAut.put("COD_TIPDOC", Constantes.TIPO_DOCUMENTO_ASOCIADO_RESOLUCION);

            // Verificamos que exista un doc de autorizacion adecuado
            List lstDocAut = this.detAutorizacionDAO.joinDocAsociadoFindBySerieTOpTDoc(paramsAut);

            if (CollectionUtils.isEmpty(lstDocAut))
            {
              res = "No existe un documento de autorizaci�n asociado que avale la liberaci�n por incentivo migratorio.";
            }
            else
            {
              swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
                  + params.get("caduana").toString().trim()));

              Map paramsCRR = new HashMap();
              paramsCRR.put("CTIPODOC", params.get("CTIPODOC"));
              paramsCRR.put("CDOCUMEN", params.get("CDOCUMEN"));
              paramsCRR.put("CTIPO_USO", Constantes.TIPO_USO_REFERENCIA_IMPORTACION);
              paramsCRR.put("TBASE_LEGAL", "Resolucion");
              paramsCRR.put("FEC_EVAL", params.get("FEC_EVAL"));

              List<Map<String, Object>> lstCatRef = this.catRefRucDAO.obtenerCatRefRuc(paramsCRR);
              String codiRegi = "";
              String codiAduan = "";
              boolean booEncontrado = false;
if (!CollectionUtils.isEmpty(lstCatRef)) {
              for (Map<String, Object> catRef : lstCatRef)
              {
                codiRegi = catRef.get("CODI_REGI") != null ? ((String) catRef.get("CODI_REGI")).trim() : "";

                if (codiRegi.equals(codRegimen))
                {
                  codiAduan = catRef.get("CODI_ADUAN") != null ? ((String) catRef.get("CODI_ADUAN")).trim() : "";

                  if (codiAduan.equals((String) params.get("CODI_ADUAN")))
                  {
                    booEncontrado = true;
                    break;
                  }
                }
              }
}
              if (!booEncontrado)
              {
                res = "No se encontr� sustento para la exoneraci�n por incentivo migratorio";
              }
            }
          }
        }
      }
      else
      {
        res = "El incentivo migratorio solo puede ser aplicado a un declarante con RUC.";
      }

    }

    return res;
  }



  /**
   * Valida tp n212_208.
   *
   * @param params
   *          CTIPODOC : data de cab_declara CDOCUMEN : data de cab_declara
   *          FEC_EVAL : data de cab_declara CODI_ADUAN : data de cab_declara
   *          COD_REGIMEN : data de cab_declara TLIB : data de det_declara ()
   *          CLIB : data de det_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaTPN212_208(Map params) throws ServiceException
  {
    String res = "";
    String codRegimen = (String) params.get("COD_REGIMEN");

    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
      String codTConv = (String) params.get("TLIB");
      String codConv = (String) params.get("CLIB");
      if (Constantes.TIPO_LIBERACION_TRATADO.equals(codTConv) && ("212".equals(codConv) || "208".equals(codConv)))
      {
        Map paramsCRR = new HashMap();
        paramsCRR.put("CTIPODOC", params.get("CTIPODOC"));
        paramsCRR.put("CDOCUMEN", params.get("CDOCUMEN"));
        paramsCRR.put("FEC_EVAL", params.get("FEC_EVAL"));
        paramsCRR.put("CODI_ADUAN", params.get("CODI_ADUAN"));
        paramsCRR.put("TLIB", codTConv);
        String cLib[] = new String[1];
        cLib[0] = codConv;
        paramsCRR.put("CLIB", cLib);

        List<Map<String, Object>> lstCatRef = this.catRefRucDAO.obtenerCatRefRuc(paramsCRR);

        if (CollectionUtils.isEmpty(lstCatRef))
        {
          res = "No se ha encontrado autorizacion para la exoneracion vehicular";
        }
      }
    }

    return res;
  }

  /**
   * Valida ultractividad fec.
   *
   * @param params
   *          COD_ULTRACTIVIDAD : data det_declara FEC_CARCR : data de
   *          cab_declara COD_REGIMEN : data de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaUltractividadFec(Map params) throws ServiceException
  {
    String res = "";
    String codRegimen = (String) params.get("COD_REGIMEN");

    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
      String codUA = (String) params.get("COD_ULTRACTIVIDAD");
      FechaBean fCarcr = new FechaBean((Timestamp) params.get("FEC_CARCR"));

      FechaBean fDef = new FechaBean(Constantes.DEFAULT_FECHA_BD);
      if ("01".equals(codUA))
      {
        if (fCarcr.equals(fDef))
        {
          res = "Para asignar el codigo de ultractividad registrado debe ingresar fecha de la carta de credito de la declaracion";
        }
      }
    }

    return res;
  }

  /**
   * Valida ultractividad prece.
   *
   * @param params
   *          COD_ULTRACTIVIDAD : data det_declara NUM_CORREDOC : data
   *          det_declara NUM_SECSERIE : data det_declara COD_REGIMEN : data de
   *          cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validaUltractividadPrece(Map params) throws ServiceException
  {
    String res = "";
    String codRegimen = (String) params.get("COD_REGIMEN");

    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
      //amancilla correccion sale null en el log  String codUA = (String) params.get("COD_ULTRACTIVIDAD");
      String codUA = params.get("COD_ULTRACTIVIDAD")!=null?params.get("COD_ULTRACTIVIDAD").toString().trim():"";

      //inicio P21-P22
     //amancilla correccion sale null en el log if(!codUA.trim().isEmpty()){
      if(StringUtils.isNotEmpty(codUA)){
	      CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
	      List<Map<String,String>>codUltractividadCatalogo = catalogoAyudaService.getElementosCat(CATALOGO_ULTRACTIVIDAD);
	      List<String> keysTmp = new ArrayList<String>();
	      for(Map<String,String> result :codUltractividadCatalogo ){
	    	  String key = result.get("cod_datacat").toString();
	    	  keysTmp.add(key);
	      }
	      if(!keysTmp.contains(codUA)){
	    	  res = "Codigo de ultractividad invalido";
	      }else{
	      //fin P21-P22
      if ("01".equals(codUA) || "02".equals(codUA) || "03".equals(codUA))
      {
        List<Map<String, Object>> lstPreced = this.docuPreceDuaDAO.findBySerie(params);

        boolean booEncontrado = false;
        String codRegPre;
        for (Map<String, Object> regPrecede : lstPreced)
        {
          codRegPre = (String) regPrecede.get("COD_REGIMENPRE");
          if ("20".equals(codRegPre) || "21".equals(codRegPre) || "70".equals(codRegPre) || "80".equals(codRegPre)
              || "89".equals(codRegPre))
          {
            booEncontrado = true;
            break;
          }
        }

        if (booEncontrado)
        {
          res = "El codigo de ultractividad no corresponde con el o los regimenes de precedencia registrados para la serie";
        }
      }
    }
	    }
    }

    return res;
  }

  /**
   * Validar tlc.
   *
   * @param params
   *          TLIB : data det_declara CLIB : data det_declara COD_PAISORIGEN :
   *          data det_declara COD_REGIMEN : data de cab_declara
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validarTLC(Map params) throws ServiceException
  {
    String res = "";
    String codRegimen = (String) params.get("COD_REGIMEN");
    Map<String, Object> mapita = new HashMap<String, Object>();
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + params.get("caduana").toString().trim()));
    int conteo = 0;
    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(codRegimen))
    {
      mapita.put("cnan", params.get("NUM_PARTNANDI"));
      mapita.put("fecvigencia", params.get("FEC_DECLARACION"));
      mapita.put("tlib", params.get("TLIB"));
      mapita.put("clib", params.get("CLIB").toString().trim());
      mapita.put("cpaiorige", params.get("COD_PAISORIGEN"));
      conteo = aladlibeDAO.count(mapita);
      // valido que pais de origen este asociado al convenio pase 578
      if (conteo == 0)
      {

        Map<String, Object> newParams = new HashMap<String, Object>();
        newParams.put("COD_ADUANA", params.get("COD_ADUANA"));
        newParams.put("cnan", params.get("NUM_PARTNANDI"));
        newParams.put("fecvigencia", params.get("FEC_DECLARACION"));
        newParams.put("tlib", params.get("TLIB"));
        newParams.put("clib", params.get("CLIB").toString().trim());
        log.info("newParams:: " + newParams);

        Integer valor = nandlibeDAO.count(newParams);

        if (valor == 0)
        {
          res = "No se encuentra partida: " + params.get("NUM_PARTNANDI").toString().trim() + " asociada al convenio: "
              + params.get("CLIB").toString().trim() + " y pa�s de origen";
        }
      }

    }

    return res;
  }

  /**
   * Validar merc ayuda human.
   *
   * @param params
   *          COD_PART : Codigo de partida de la serie evaluada. COD_TIPTRATMERC
   *          : Tipo de tratamiento de la mercaderia en la declaracion. FEC_EVAL
   *          : Fecha a evaluar en formato yyyyMMdd (fecha de la declaracion)
   *          caduana : codigo de la aduana en la que se realiza la diligencia
   * @return the string
   * @throws ServiceException
   *           the service exception
   */
  public String validarMercAyudaHuman(Map params) throws ServiceException
  {
    String res = "";
//    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
//        + params.get("caduana").toString().trim()));
    DataSourceContextHolder.setKeyDataSource(params.get("caduana").toString().trim());//gmontoya rest

    if (Constantes.PARTIDA_MERCANCIA_DONACION.equals(params.get("COD_PART").toString().trim()))
    {
      if (Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals(params.get("COD_TIPTRATMERC").toString().trim()))
      {
        Map prmtPart = new HashMap();
        prmtPart.put("CNAN", Constantes.PARTIDA_MERCANCIA_DONACION);
        prmtPart.put("TIPO_USO", Constantes.TIPO_USO_MERCANCIA_DONACION);
        prmtPart.put("FEC_EVAL", params.get("FEC_EVAL"));

        //List lstPart = this.catRefPartidasDAO.findByPartTipUsoVig(prmtPart);
        
        prmtPart.put("ayudaID", "CatRefpartidas");
		List lstPart =  (List)ayudaService.findByPartTipUsoVig(prmtPart);
		
        

        if (CollectionUtils.isEmpty(lstPart))
        {
          res = "No se ha encontrado la una partida vigente para el tratamiento de mercaderia en donacion.";
        }
      }
      else
      {
        res = "El tipo de tratamiento de la mercader�a de la dua debe ser de donacion.";
      }
    }

    return res;
  }



  /**
   * Validar que si se acoge al TPN 21:DERECHOS PAGADOS DESPACHOS VIGENTES o 222
   * CONTRATO LLAVE EN MANO declare regimen de precedencia importacion 10
   * validar que si declara TPN 93 o 183 (REPOSICION DE MERCANCIAS EN
   * FRANQUICIA, REFINERIA LA PAMPILLA-CONVENIO ESTAB.JURIDICA) registre que se
   * acoge al regimen de precedencia reposicion (12)
   *
   * @param params
   *          the params
   * @return boolean
   * @throws ServiceException
   *           the service exception
   * @params
   */

  public String validaTieneRegPrecedencia(Map<String, Object> params)
    throws ServiceException
  {

    String res = "";
    String res1 = "";
    boolean tieneCodRegimenPre10 = false;
    boolean tieneCodRegimenPre12 = false;
    List<Map<String, Object>> listadoRegPrecedencia = (List<Map<String, Object>>) docuPreceDuaDAO.findBySerie(params);

    String codTipConvenioTpn = (String) params.get("COD_TIPCONVENIO_TPN");
if (CollectionUtils.isEmpty(listadoRegPrecedencia)) {
    for (Map regPrecede : listadoRegPrecedencia)
    {
      String codRegimenPre = regPrecede.get("COD_REGIMENPRE") != null ? regPrecede.get("COD_REGIMENPRE").toString()
          : "";
      if ("10".equals(codRegimenPre))
      {
        tieneCodRegimenPre10 = true;
      }
      if ("12".equals(codRegimenPre))
      {
        tieneCodRegimenPre12 = true;
      }
    }
}
    // si registra TPN 21 o 222 debe tener necesariamente regimen de precedencia
    // 10
    if (("21".equals(codTipConvenioTpn) || "222".equals(codTipConvenioTpn)) && !tieneCodRegimenPre10)
    {
      res = "Valor de TPN no tiene registrado Regimen de precedencia valido.";
      res1 = params.get("NUM_SECSERIE") != null ? (" Verificar Serie Nro." + params.get("NUM_SECSERIE")) : "";
      res = res.concat(res1);
    }
    if (("93".equals(codTipConvenioTpn) || "183".equals(codTipConvenioTpn)) && !tieneCodRegimenPre12)
    {
      res = "Valor de TPN no tiene registrado Regimen de precedencia valido.";
      res1 = params.get("NUM_SECSERIE") != null ? (" Verificar Serie Nro." + params.get("NUM_SECSERIE")) : "";
      res = res.concat(res1);
    }
    return res;
  }

  /**
   * Vcod_tipdesp=2010 && aduana=172 , validar exista tipo doc y numero doc en
   * la tabla CTUSUARIO (verificar si solo esta en tacna).
   *
   * @param params
   *          the params
   * @return String
   * @throws ServiceException
   *           the service exception
   * @params Map<String, Object> params
   */
  public String validaCeticos(Map<String, Object> params) throws ServiceException
  {
    String res = "";

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
        + params.get("caduana").toString().trim()));

    Map<String, Object> params2 = new HashMap<String, Object>();
    params2.put("Cetico", params.get("COD_ADUANA"));
    params2.put("NroDocumento", params.get("NUM_DOCIDENT_PIM"));
    params2.put("TipoDocumento", params.get("COD_TIPDOC_PIM"));

    List<CTUsuarios> list = ctUsuariosDAO.listByParameterMap(params2);
    // tienen que estar registrados en la tabla
    if (list == null || list.size() == 0)
    {
      res = "Para el tipo de despacho,debe ser un usuario Zofratacna.";
    }

    return res;
  }

  /**
   * El tipo de operaci�n 2008, validar que la numpartnandi exista en la tabla
   * cat_refpartidas con tipo_uso='NAV' y se encuentre vigente.
   *
   * @param params
   *          the params
   * @return String
   * @throws ServiceException
   *           the service exception
   * @params Map<String, Object> params
   */
  public String validaTienePartida(Map<String, Object> params) throws ServiceException
  {
    String res = "";
    String res1 = "";
//    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
//        + params.get("caduana").toString().trim()));
    DataSourceContextHolder.setKeyDataSource(params.get("caduana").toString().trim());//gmontoya rest
    Date fechaActual = new Date();

    Map<String, Object> params2 = new HashMap<String, Object>();
    params2.put("tipo_uso", "NAV");
    params2.put("cnan", params.get("NUM_PARNABANDINA"));
    params2.put("ffinvig", SunatDateUtils.getIntegerFromDate(fechaActual));
    params2.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(fechaActual));
    //List list = catRefPartidasDAO.getCatRefPartidas(params2);
    
    params2.put("ayudaID", "CatRefpartidas");
	List<CatRefpartidas> list =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params2);
	
    
    if (CollectionUtils.isEmpty(list) && "2008".equals(params.get("COD_TIPDESP")))
    {
      res = "Partida arancelaria no corresponde al tipo de despacho." + params.get("NUM_SECSERIE");
      res1 = params.get("NUM_SECSERIE") != null ? (" Verificar Serie Nro." + params.get("NUM_SECSERIE")) : "";
      res = res.concat(res1);
    }
    return res;
  }

  /**
   * valida si existe el expediente registrado como sustento de la rectificacion
   * de oficio.
   *
   * @param params
   *          the params
   * @return String
   * @throws ServiceException
   *           the service exception
   * @params Map<String, Object> params
   */
  public String validaTieneExpediente(Map<String, Object> params) throws ServiceException
  {

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
        + params.get("caduana").toString().trim()));

    boolean res = false;
    List<Map<String, Object>> listaExpediente = expediDAO.findExpediRectificacionByDeclaracion(params);

    for (Map expedi : listaExpediente)
    {
      String codiAdua = expedi.get("CODI_ADUA") != null ? expedi.get("CODI_ADUA").toString() : "";
      String anoExpedi = expedi.get("ANOEXPEDI") != null ? expedi.get("ANOEXPEDI").toString() : "";
      String nroExpedi = expedi.get("NROEXPEDI") != null ? expedi.get("NROEXPEDI").toString() : "";
      // comparamos el expediente obtenido con lo que ha ingresado el usuario
      if ((params.get("CODI_ADUA").toString().trim()).equals(codiAdua) &&
          (params.get("ANOEXPEDI").toString().trim()).equals(anoExpedi) &&
          (params.get("NROEXPEDI").toString().trim()).equals(nroExpedi))
      {
        res = true;
      }
    }
    return (res ? "" : "Expediente no se encuentra registrado.");
  }



  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findDuaDiligenciada(String numCorredoc)
  {
    return cabDiligenciaDAO.findDuaDiligenciada(numCorredoc);
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> findPrimeraDiligencia(Map<String, Object> params)
  {
    return cabDiligenciaDAO.findPrimeraDiligencia(params);
  }

  /**
   * {@inheritDoc}
   *
   */
  public Map<String, Object> findUltimaDiligencia(Map<String, Object> params, Map<String, Object> mapDeclaracion)
  {
    //RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
//		Map<String, Object> mapBusq = new HashMap<String, Object>();
//		mapBusq.put("numcorredoc", params.get("NUM_CORREDOC").toString());
//		mapBusq.put("codtipplz", "01"); // diligencia guarda el tipo 01
//    List<Map<String, Object>> listPlazos = plazosProcesoDAO.findPlazosProcesoByParams(mapBusq);
//    Map<String, Object> mapDiligencia = cabDiligenciaDAO.findUltimaDiligencia(params);
    params.put("codtipplz", "01");
    Map<String, Object> mapDiligencia  = cabDiligenciaDAO.findUltimaDiligenciaConPlazoProceso(params);
    //RTINEO FIN
    
//    if (!CollectionUtils.isEmpty(listPlazos)
//        && !CollectionUtils.isEmpty(mapDiligencia))
//    {
//
//      mapDiligencia.put("fecVencRegimen", listPlazos.get(0).get("fecFin"));
//      mapDiligencia.put("cntDuracion", listPlazos.get(0).get("cntDuracion"));
//      mapDiligencia.put("codUnimed", listPlazos.get(0).get("codUnimed"));
//
//    }
//    else if (!CollectionUtils.isEmpty(mapDeclaracion)
//        && !CollectionUtils.isEmpty(mapDiligencia))
//    {
//      mapDiligencia.put("fecVencRegimen", mapDeclaracion.get("FEC_VENREGIMEN"));
//      mapDiligencia.put("cntDuracion", mapDeclaracion.get("NUM_PLAZOSOL"));
//      mapDiligencia.put("codUnimed", mapDeclaracion.get("COD_TIPOPLAZO"));
//    }
    if(!CollectionUtils.isEmpty(mapDiligencia)){
    	if(mapDiligencia.get("FEC_FIN") != null){
    		mapDiligencia.put("fecVencRegimen", mapDiligencia.get("FEC_FIN"));
    		mapDiligencia.put("cntDuracion", mapDiligencia.get("CNT_DURACION"));
    		mapDiligencia.put("codUnimed", mapDiligencia.get("COD_UNIMED"));
    	}
    }else if(!CollectionUtils.isEmpty(mapDeclaracion)){
    	mapDiligencia = new HashMap();
    	mapDiligencia.put("fecVencRegimen", mapDeclaracion.get("FEC_VENREGIMEN"));
    	mapDiligencia.put("cntDuracion", mapDeclaracion.get("NUM_PLAZOSOL"));
    	mapDiligencia.put("codUnimed", mapDeclaracion.get("COD_TIPOPLAZO"));
    }
//RTINEO FIN
    return mapDiligencia;
  }

  public boolean validaTieneDiligenciaTipo(Map<String, Object> params)
  {
    boolean res = false;
    if (cabDiligenciaDAO.count(params) > 0)
      res = true;
    return res;
  }


  /**
   * {@inheritDoc}
   */
    public DocumentoSustento obtenerDocumentoSustentatorio(DocumentoSustento documentoSustento)
    {
      DocumentoSustentoService service = crearDocumentoSustentoService(documentoSustento.getCodTipDocDili());

      return service.obtenerDocumentoSustento(documentoSustento);
   }


   /**
     * Fabrica de servicio para obtener el documento sustento
     *
     * @param tipo
     *          [TipoDocumentoSustentatorio] tipo
     * @return [DocumentoSustentoService] documento sustento service
     * @author amancillaa
     * @version 1.0
     */
   private DocumentoSustentoService crearDocumentoSustentoService(TipoDocumentoSustentatorio tipo){

     if (TipoDocumentoSustentatorio.EXPEDIENTE==tipo)
     {

       return fabricaDeServicios.getService("tramite.ExpedienteService");
     }
     else if(TipoDocumentoSustentatorio.RESOLUCION==tipo)
     {
       return fabricaDeServicios.getService("tramite.ResolucionService");
     }
     else if(TipoDocumentoSustentatorio.ACTA_VERFICACION==tipo)
     {
       return fabricaDeServicios.getService("tramite.DocumentoInternoService");
     }

     return null;
   }



    public Map<String,String> validarCambioDeModalidad(Map<String, Object> params){


  try
  {

    Map<String,String> msjValidacion = new HashMap<String,String>();
    Date fechaDeclaracion = (Date)params.get("fechaDeclaracion");

    Map<String,Object> dataManif = new HashMap<String,Object>();

    dataManif.put("numeroManifiesto", SunatStringUtils.lpad(params.get("numManifiesto").toString().trim(),6,' '));
    dataManif.put("anioManifiesto", params.get("annManifiesto").toString().trim());
    dataManif.put("codigoAduana", params.get("codAduanaManifiesto").toString().trim());
    dataManif.put("codigoTipoManifiesto", params.get("codTipManifiesto").toString().trim());
    dataManif.put("codigoViaTransporte", params.get("codViaTrans").toString().trim());

    String codaduamanif = params.get("codAduanaManifiesto").toString().trim();
    String annmanif = params.get("annManifiesto").toString().trim();
    String nummanif = SunatStringUtils.lpad(params.get("numManifiesto").toString().trim(),6,' ');
    String codmodtransp = params.get("codViaTrans").toString().trim();
    String codtipmanif  = params.get("codTipManifiesto").toString().trim();

    ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");

    Manifiesto manifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);

    String codModalidadBD = params.get("codModalidadBD").toString();
    if(Constantes.MODALIDAD_ANTICIPADO.equals(codModalidadBD)){
      msjValidacion.put("esAnticipado", "SI");
    }
    if (manifiesto!=null) {

        Date fecLlegada = manifiesto.getFechaEfectivaDeLlegada();
        if( fecLlegada==null
            || SunatDateUtils.sonIguales(fecLlegada,SunatDateUtils.getDefaultDate(),SunatDateUtils.COMPARA_SOLO_FECHA)){

            fecLlegada = manifiesto.getFechaProgramadaLlegada();
        }


        //Usamos la fecha de Llegada y la fecha de la Declaraci�n para determinar si es Urg.Excepcional
        if(!SunatDateUtils.esFecha1MayorQueFecha2(fechaDeclaracion,fecLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)
            && Constantes.MODALIDAD_ANTICIPADO.equals(codModalidadBD)){
            String msjValidacion1 = "Para modalidad diferido, Fecha de la Declaraci\u00f3n: "+DateUtil.dateToString(fechaDeclaracion, "dd/MM/yyyy")+
                             " debe ser mayor a la fecha de llegada: " +
                             DateUtil.dateToString(fecLlegada, "dd/MM/yyyy")+
                             " del medio de transporte";

            msjValidacion.put("msjValAnticipado", msjValidacion1);
        }
    }
    else
    {

      String msjValidacion2 = "No existe manifiesto de carga: "+dataManif.get("codigoTipoManifiesto")+"-"+
          dataManif.get("codigoViaTransporte")+"-"+dataManif.get("codigoAduana")+"-"+
          dataManif.get("anioManifiesto")+"-"+dataManif.get("numeroManifiesto");
        msjValidacion.put("msjValManif", msjValidacion2);

    }



    return msjValidacion;
  }
  catch (DataAccessException e)
  {
    log.error(e);
    throw new ServiceException(this, "Ha ocurrido un error buscar el manifiesto" );
  }
  catch (Throwable e)
  {
    log.error(e);
    throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo");
  }

}


  public String validarCambioDeFechaDescarga(Map<String, Object> params)
  {

    String msjValidacion = "";
    try
    {

      Date fechaDescargaModificado = (Date) params.get("fechaDescargaModificado");

      Map<String, Object> dataManif = new HashMap<String, Object>();

      dataManif.put("numeroManifiesto", SunatStringUtils.lpad(params.get("numManifiesto").toString().trim(), 6, ' '));
      dataManif.put("anioManifiesto", params.get("annManifiesto").toString().trim());
      dataManif.put("codigoAduana", params.get("codAduanaManifiesto").toString().trim());
      dataManif.put("codigoTipoManifiesto", params.get("codTipManifiesto").toString().trim());
      dataManif.put("codigoViaTransporte", params.get("codViaTrans").toString().trim());

      String codaduamanif = params.get("codAduanaManifiesto").toString().trim();
      String annmanif = params.get("annManifiesto").toString().trim();
      String nummanif = SunatStringUtils.lpad(params.get("numManifiesto").toString().trim(), 6, ' ');
      String codmodtransp = params.get("codViaTrans").toString().trim();
      String codtipmanif = params.get("codTipManifiesto").toString().trim();

      ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");

      Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif,
                                                                               SunatNumberUtils.toInteger(annmanif),
                                                                               nummanif, true);
      if (manifiesto != null)
      {
        Date fecTerminoDescargaDelManifiesto = manifiesto.getFechaTerminoDeDescarga();
        if (fecTerminoDescargaDelManifiesto == null
            || SunatDateUtils.sonIguales(fecTerminoDescargaDelManifiesto, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))
        {

          return "No es posible modificar la fecha de termino de descarga, aun no ha sido registrado en el manifiesto.";
        }


        if (!SunatDateUtils.sonIguales(fecTerminoDescargaDelManifiesto, fechaDescargaModificado, SunatDateUtils.COMPARA_SOLO_FECHA))
        {
          msjValidacion = "la Fecha de termino descarga de la Dua: "+
                           DateUtil.dateToString(fechaDescargaModificado,"dd/MM/yyyy")+
                           " debe ser igual a la registrada en el Manifiesto: " +
                           DateUtil.dateToString(fecTerminoDescargaDelManifiesto,"dd/MM/yyyy");
        }
      }
      else
      {
        msjValidacion = "No existe manifiesto de carga: " + dataManif.get("codigoTipoManifiesto") + "-" +
                        dataManif.get("codigoViaTransporte") + "-" + dataManif.get("codigoAduana") + "-" +
                        dataManif.get("anioManifiesto") + "-" + dataManif.get("numeroManifiesto");
      }

      return msjValidacion;
    }
    catch (DataAccessException e)
    {
      log.error(e);
      throw new ServiceException(this, "Ha ocurrido un error buscar el manifiesto");
    }
    catch (Throwable e)
    {
      log.error(e);
      throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo");
    }

  }



    public String validarCambioDeDeclarante(Map<String, Object> params) throws ServiceException{
      String msjValidacion = "";

      Map<String, Object> declaracionActual = (HashMap) params.get("mapCabDeclaraActual");

      String codRegimen = declaracionActual.get("COD_REGIMEN").toString();

      List<Map<String, String>> listValidaciones = new ArrayList<Map<String,String>>();

      String tipoDocIdentidad = params.get("tipoDocIdentidad").toString();
      String numeroDocIdentidad = params.get("numeroDocIdentidad").toString();

      //primero valido que los datos del declarante esten registrados
      listValidaciones.addAll(operadorValidaService.validarDeclarante(tipoDocIdentidad, numeroDocIdentidad));
      if (!CollectionUtils.isEmpty(listValidaciones)) {
        for (Map<String, String> mapvalidacion : listValidaciones) {
            msjValidacion=  mapvalidacion.get("desError").toString();
            break;
        }
     }
      if("10".equals(codRegimen)){
         //2do validamos la cuenta cte del declarante

          String mtoTotFobDol = params.get("mtoTotFobDol").toString();

          //actualizo el valor actual del formularia para que valide
          ((Map) params.get("mapCabDeclaraActual")).put("MTO_TOTFOBDOL",SunatNumberUtils.toBigDecimal(mtoTotFobDol));

              GetDeclaracionHashMapToDeclaracionObjectHelper transform =
              GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance();


            ValNegocNumeracFormA valNegocNumeracFormA  = (ValNegocNumeracFormA) fabricaDeServicios.getService("ValNegocNumeracFormA");
            Declaracion declaracion = transform.transformBySufijo(params, "Actual");
            //  listValidaciones.addAll(validacionesService.getValNegocNumeracFormA().valCtaCtePerNat(declaracion));
            listValidaciones.addAll(valNegocNumeracFormA.valCtaCtePerNat(declaracion));//desacoplamiento

        if (!CollectionUtils.isEmpty(listValidaciones)) {
            for (Map<String, String> mapvalidacion : listValidaciones) {
                msjValidacion=  mapvalidacion.get("desError").toString();
                break;
            }
         }
      }

      return msjValidacion;
    }

  //wtaco
  
  public Map<String, String> numerodocumentoDNI(String arg) {   
		boolean containsDigit=true;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1), "0,1,2,3,4,5,6,7,8,9")){
				containsDigit=false;
				break;
			}
		}
		if(!containsDigit)
		{
			return new HashMap<String, String>();	
		}
		
		return null;
  }
  
  public Map<String,Object> validarDatosDeclarante(Map<String,Object>  map){  	  
  	  String tipoDocumento= map.get("tipo_documento")==null? " ":map.get("tipo_documento").toString();
  	  String numeroDocumento=map.get("numero_documento")==null? " ":map.get("numero_documento").toString();
  	  String fechaReferencia=map.get("fec_referencia")==null? " ":map.get("fec_referencia").toString();
  	  String nombreDeclaranteTransmitido=map.get("nom_declarante")==null? " ":map.get("nom_declarante").toString();  	
  	  
  	  Date fecnac_pernat=null;
  	  Date fecnac_vigencia=null;
  	  Date fecfall_pernat=null;
  	  Date fecha_default=null;  	  
  	  Map<String, Object> resp=new  HashMap<String, Object>();
  	  String numerodni="";
  	  String nombreDeclarante=null; 	
  	
  	  try { 	  	  
  	  resp=this.soporteService.obtenerPerNatJur(tipoDocumento,numeroDocumento);  	  
  	    if(resp!=null){
  		     numerodni=(String)resp.get("codigo");   		   
  		     nombreDeclarante= (String)resp.get("nombreDeclarante");
  		     Date fechaReferenciaDeclaracion = SunatDateUtils.getDateFromUnknownFormat(fechaReferencia);
  		     fecnac_pernat =   (Date)resp.get("fechNac");
  		     fecnac_vigencia = (Date)resp.get("fecVigencia");
  		     fecha_default   = DateUtil.getDefaultDate();
  		     fecfall_pernat  = (Date)resp.get("fecFallecimiento");  		    
  		     
             this.log.info("fechaReferenciaDeclaracion: " + fechaReferenciaDeclaracion);
             this.log.info("fecnac_vigencia: " + fecnac_vigencia);
             this.log.info("fecha_default: " + fecha_default);
             this.log.info("fecnac_pernat: " + fecnac_pernat);
             this.log.info("fecfall_pernat: " + fecfall_pernat);
             
             long time=-1L;
            if(!(numerodni.equals(""))){
            	 time = SunatDateUtils.getDifference(fechaReferenciaDeclaracion,fecnac_pernat,Calendar.YEAR).longValue(); 
            	 this.log.info("fecha_default: " + time);
            }                   
            
            if(SunatStringUtils.length(numeroDocumento)!=8){
            	resp.put("error","Nro. de documento del declarante del formato B inv�lido");  
            }else if(numerodocumentoDNI(numeroDocumento)!=null){
            	resp.put("error","Nro. de documento del declarante del formato B inv�lido");   
            }else if(numerodni.equals("")){
            	resp.put("error","Nro. de documento del declarante del formato B inv�lido");
            }else if(!(fecfall_pernat.compareTo(fecha_default)==0)){            	
            	resp.put("error","Nro. de documento del declarante del formato B inv�lido");
            }else if(!(fecnac_vigencia.compareTo(fecha_default)==0) &&  
            		SunatDateUtils.esFecha1MayorQueFecha2(fechaReferenciaDeclaracion,fecnac_vigencia,"COMPARA_TODO")){            		  
  		    	         resp.put("error","Nro. de documento del declarante del formato B inv�lido");  		    	      
  	        }else if (time < 18L) {
            	resp.put("error","Nro de documento del declarante del formato B corresponde a un menor de edad");
            }else if (!nombreDeclarante.equals(nombreDeclaranteTransmitido)){
            	resp.put("error","Nombre del declarante del formato B inv�lido, envi� "+nombreDeclaranteTransmitido+", y debe enviar "+nombreDeclarante);            	
            }  	
             
  	      }  
  		     
    	} catch (ParseException e) {
		 // TODO Auto-generated catch block
		  e.printStackTrace();
	   } 
  	 return resp;  
  }
  //fin-wtaco

  
  /* P14 - 3005 - Inicio - lrodriguezc */
	
	/* CUS: 3005-10.02 - Inicio - lrodriguezc */
	
	
	public boolean validarDiligReconFisicoParaReasignar(String numCorrelativo){
		
		Map<String, Object> parametros = new HashMap<String, Object>();
		
		parametros.put("NUM_CORREDOC", numCorrelativo);
		
		Map<String, Object> diligencia = new HashMap<String, Object>();
		
		diligencia = cabDiligenciaDAO.findUltimaDiligencia(parametros);
		
		/*inicio mpoblete BUG 18801*/
		boolean esDiligenciaRevision = ConstantesDataCatalogo.COD_DILIG_REV.equals(diligencia.get("COD_TIPDILIGENCIA"));
		boolean esDiligenciaReviDocum = ConstantesDataCatalogo.COD_DILIG_REV_DOC.equals(diligencia.get("COD_TIPDILIGENCIA"));
		boolean esDiligenciaReconoFisico = ConstantesDataCatalogo.COD_DILIG_REC_FIS.equals(diligencia.get("COD_TIPDILIGENCIA"));
		
		boolean esContinuacionDespacho = ConstantesDataCatalogo.COD_DILIG_CONT_DESPACHO.equals(diligencia.get("COD_TIPDILIGENCIA"));
		
		if ( esDiligenciaRevision || esDiligenciaReviDocum || esDiligenciaReconoFisico || esContinuacionDespacho) {
		/*fin mpoblete BUG 18801*/	
			
			if ( Constantes.CAT_ESTADOS_RECO_FISICO.equals(diligencia.get("COD_CATALOGO")) && Constantes.RECON_FISI_CONT_DESPACHO.equals(diligencia.get("COD_MOTIVO")) ) {
				
				return true;
				
			} else {
				
				return false;
				
			}
			
		} else {
			
			return false;
			
		}
		
	}
	
	/* CUS: 3005-10.02 - Final - lrodriguezc */
	
	/* P14 - 3005 - Final - lrodriguezc */
  
  /***********************SET DE SPRING **********************************/





  public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO)
  {
    this.detAutorizacionDAO = detAutorizacionDAO;
  }


  public void setCatRefRucDAO(CatRefRucDAO catRefRucDAO)
  {
    this.catRefRucDAO = catRefRucDAO;
  }


  public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO)
  {
    this.docuPreceDuaDAO = docuPreceDuaDAO;
  }


  public FabricaDeServicios getFabricaDeServicios()
  {
    return this.fabricaDeServicios;
  }


  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }


  public HotSwappableTargetSource getSwapperDatasource()
  {
    return this.swapperDatasource;
  }


  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }


  public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO)
  {
    this.cabDiligenciaDAO = cabDiligenciaDAO;
  }



  public void setAladlibeDAO(AladlibeDAO aladlibeDAO)
  {
    this.aladlibeDAO = aladlibeDAO;
  }


  public void setNandlibeDAO(NandlibeDAO nandlibeDAO)
  {
    this.nandlibeDAO = nandlibeDAO;
  }


  public void setCtUsuariosDAO(CTUsuariosDAO ctUsuariosDAO)
  {
    this.ctUsuariosDAO = ctUsuariosDAO;
  }


  public void setExpediDAO(ExpediDAO expediDAO)
  {
    this.expediDAO = expediDAO;
  }

  public void setPlazosProcesoDAO(PlazosProcesoDAO plazosProcesoDAO)
  {

    this.plazosProcesoDAO = plazosProcesoDAO;
  }

    /*public void setValidacionesService(GetValidacionesService validacionesService) {
        this.validacionesService = validacionesService;
    }*/

    public void setOperadorValidaService(OperadorValidaService operadorValidaService){

        this.operadorValidaService = operadorValidaService;
    }

        public SoporteService getSoporteService() {
		return soporteService;
	}

	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

}
