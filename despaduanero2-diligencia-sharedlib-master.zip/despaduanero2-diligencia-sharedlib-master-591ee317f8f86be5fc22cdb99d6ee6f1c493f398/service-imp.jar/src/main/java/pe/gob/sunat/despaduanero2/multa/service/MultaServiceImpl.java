package pe.gob.sunat.despaduanero2.multa.service;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
//import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;

import pe.gob.sunat.despaduanero2.declaracion.model.Uit;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.UitDAO;
/* RIN15 - f2 3011 - Inicio - lrodriguezc */
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.MultaDua;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
/* RIN15 - f2 3011 - Fin - lrodriguezc */
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Ordenador;
import pe.gob.sunat.despaduanero2.multa.model.dao.MultaDuaDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.genadeudo.model.dao.ConceptoDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.SancionOperDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;


/**
 * The Class MultaServiceImpl.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class MultaServiceImpl implements MultaService
{

  protected final Log log = LogFactory.getLog(MultaServiceImpl.class);

  private MultaDuaDAO              multaDuaDAO;

  private SancionOperDAO           sancionOperDAO;

  private ConceptoDAO              conceptoDAO;

  private RectiOficioDAO           rectiOficioDAO;

  private SequenceDAO              sequenceDAO;

  private HotSwappableTargetSource swapperDatasource;

  private FabricaDeServicios       fabricaDeServicios;
  
  private DeudaService 			   deudaService; //RIN13 SWF
  
  private UitDAO uitDAO; //RIN13 SWF
  
  //RIN13 SWF
  public void setUitDAO(UitDAO uitDAO) {
	this.uitDAO = uitDAO;
}

//RIN13 SWF
  public void setDeudaService(DeudaService deudaService) {
	this.deudaService = deudaService;
  }

/**
   * {@inheritDoc}
   */
  public void generarMulta(Map paramMulta, List<Map<String, Object>> multas)
    throws ServiceException
  {
    generarMulta(paramMulta, multas, true);
  }

  
  private void guardaRegistroRectiOficio(Map paramMulta,Map<String, Object> multa){
	  // Para la rectificacion de oficio
      Map keyMultas = new HashMap();
      if (paramMulta.get("tipDilig") != null)
      {
        keyMultas.put("NUM_CORREDOC", multa.get("NUM_CORREDOC"));
        keyMultas.put("COD_TIPDILIGENCIA", multa.get("COD_TIPDILIGENCIA"));
        keyMultas.put("COD_MULTA", multa.get("COD_MULTA"));
        if (multa.containsKey("NUM_CORREDOC"))
        {
          keyMultas.put("NUM_CORREDOC_SOL", multa.get("NUM_CORREDOC_SOL"));
        }

        multa.put("dataOriginal", keyMultas);
        multa.put("clave", keyMultas);

        this.registrarRectiOficio(multa, paramMulta.get("tipDilig").toString().trim(), new Long(multa.get(
            "NUM_CORREDOC").toString().trim()), "T0022");
      }
  }
  
  private void guardarMultas(Map paramMulta, List<Map<String, Object>> multas)
  {
	    Map<String, Object> generacionLCMulta = (Map<String, Object>) paramMulta.get("generacionLCMulta");
	    List<Map<String, Object>> multasTemp = new ArrayList<Map<String,Object>>();//RIN13 SWF
    //amancilla correcion
	    boolean generarLCMulta = ((generacionLCMulta == null || generacionLCMulta.get("generarLC003")  == null )? false : (Boolean) (generacionLCMulta.get("generarLC003")));
	    
	    if(generarLCMulta){
	    	Map<String,Object> mapCabDeclaraActual = (HashMap<String,Object>)paramMulta.get("mapCabDeclaraActual"); 
			
			BigDecimal mtoMultaSolesGen = ((Map<String, Object>) generacionLCMulta.get("generarLCMulta")).get("montoMultaSoles") == null ? BigDecimal.ZERO : (BigDecimal)((Map<String, Object>) generacionLCMulta.get("generarLCMulta")).get("montoMultaSoles");
			BigDecimal mtoMultaDolaresGen = ((Map<String, Object>) generacionLCMulta.get("generarLCMulta")).get("montoMultaDolares") == null ?	BigDecimal.ZERO : (BigDecimal)((Map<String, Object>) generacionLCMulta.get("generarLCMulta")).get("montoMultaDolares");
		
			LiquidaDeclaracionService liquidaDeclaracion = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
			
			
				if (mtoMultaSolesGen.compareTo(BigDecimal.ZERO) == 1) {
					HashMap<String,Object> lC003Multas = liquidaDeclaracion.generarLC003Multas(mapCabDeclaraActual, multas, "S", generacionLCMulta); //Cambio por PAS20155E220000166
				}
				if (mtoMultaDolaresGen.compareTo(BigDecimal.ZERO) == 1) {
					HashMap<String,Object> lC003Multas = liquidaDeclaracion.generarLC003Multas(mapCabDeclaraActual, multas, "D", generacionLCMulta); //Cambio por PAS20155E220000166
				}
	    }
	    
	    
	    for (Map<String, Object> multa : multas)
		{
	    	if(multasTemp.isEmpty()){// si es el primer registro lo inserta sin evaluar
        		multasTemp.add(multa);
        		multaDuaDAO.insertSelective(multa);
        	}else{//caso contrario evalua 
        		boolean seRepiteMulta = false;
        		for(Map<String,Object> multaTemp : multasTemp){
        			if(multaTemp.get("COD_MULTA").toString().equals(multa.get("COD_MULTA").toString())){	  
        				seRepiteMulta = true;  
        			  }
        		}
        		if(!seRepiteMulta){ // si no se repitio la multa entonces lo inserta
        			multasTemp.add(multa);
        			multaDuaDAO.insertSelective(multa);
        		}
        	}
		    if(!generarLCMulta){
		    	deudaService.generarDeudaAndPagosParaMulta(multa);
		    }
		    guardaRegistroRectiOficio(paramMulta, multa);
		}
	 
	    
	    
  }
  
  
  /**
   * {@inheritDoc}
   */
  public void generarMulta(Map paramMulta, List<Map<String, Object>> multas, boolean isgetfieldvalues)
		    throws ServiceException
		    {

		        List<Map<String, Object>> listaMultas;
		        if (isgetfieldvalues)
		        {
		          listaMultas = armarMapaMultasParaRegistroDiligenciaDespacho(paramMulta, multas); //crearMultaMaps(paramMulta, multas);
		        }
		        else
		        {
		          listaMultas = multas;
		        }

		        /*
		         * Aqui se llama al servicio de generacion de los tributos (Juan Canchucaja)
		         * Atributos de entrada: listaMultas codDocumento codTipoDiligencia
		         */
		        Map keyMultas = new HashMap();
		        List<Map<String, Object>> multasTemp = new ArrayList<Map<String,Object>>();//RIN13 SWF
		        //Inicio PAS20155E220000054
		        Map<String, Object> generacionLCMulta = (Map<String, Object>) paramMulta.get("generacionLCMulta");
              //amancilla correccion se comenta
		        //boolean generarLCMulta = (generacionLCMulta.get("generarLC003")  == null ? false : (Boolean) (generacionLCMulta.get("generarLC003")));
              boolean generarLCMulta = (generacionLCMulta==null || generacionLCMulta.get("generarLC003")  == null) ? false : (Boolean) (generacionLCMulta.get("generarLC003"));
		        //Fin PAS20155E220000054
	      //Conclusion de Despacho	        
              String codTipoDilig = paramMulta.get("tipDilig").toString().trim();
		        if(ArrayUtils.contains(new String[]{"06"},codTipoDilig)){ 
		        	guardarMultas(paramMulta,multas);
		        }else{        
			        for (Map<String, Object> multa : listaMultas)
			        {
			        	/*RIN13 SWF INICIO*/
			        	//String annLiquidar = multa.get("ANN_LC").toString().length()>2?multa.get("ANN_LC").toString(): ((new FechaBean()).getAnho()).toString().substring(0,2) + multa.get("ANN_LC").toString();///cambio por rzavalam pase 144-2015 
			        	BigDecimal annLiq = new BigDecimal(multa.get("ANN_LC").toString());///cambio por rzavalam pase 144-2015 //el cambio se reubica en generarDeudaAndPagosParaMulta para todos las diligencias pase 2015
			        	String codAduanaLiq =  multa.get("COD_ADUANALC").toString();
			        	String numLiq = multa.get("NUM_LC").toString();
			        	String indLiq = "1"; // multaReg.put("IND_LC", "1");
			        	
			        	  if (!generarLCMulta)  {//PAS20155E220000054
				        	multa.remove("ANN_LC");
				        	multa.remove("COD_ADUANALC");
				        	multa.remove("NUM_LC");
				        	multa.remove("IND_LC");
			        	  }
			            /*solo insertar una vez la multa*/
			            	if(multasTemp.isEmpty()){// si es el primer registro lo inserta sin evaluar
			            		multasTemp.add(multa);
			            		multaDuaDAO.insertSelective(multa);
			            	}else{//caso contrario evalua 
			            		boolean seRepiteMulta = false;
			            		for(Map<String,Object> multaTemp : multasTemp){
			            			if(multaTemp.get("COD_MULTA").toString().equals(multa.get("COD_MULTA").toString())){	  
			            				seRepiteMulta = true;  
			            			  }
			            		}
			            		if(!seRepiteMulta){ // si no se repitio la multa entonces lo inserta
			            			multasTemp.add(multa);
			            			multaDuaDAO.insertSelective(multa);
			            		}
			            	}	  
			            /*RIN13 SWF FIN*/
			     
			          //RIN13 SWF - registramos deuda de tipo multa
			         multa.put("ANN_LC",annLiq);
			         multa.put("COD_ADUANALC",codAduanaLiq);
			         multa.put("NUM_LC",numLiq);
			         multa.put("IND_LC",indLiq);
			    	 //Inicio PAS20155E220000054
			       //Inicio PAS20155E220000054
                      //amancilla correccion
			         //generarLCMulta = ( paramMulta==null  || ((Map<String, Object>) paramMulta.get("generarLC003")).get("generarLC003")  == null) ? false : (Boolean) ((Map<String, Object>) paramMulta.get("generarLC003")).get("generarLC003");			         
			         if (!generarLCMulta)  {
			          deudaService.generarDeudaAndPagosParaMulta(multa);
			         }
			    	 //Final PAS20155E220000054
			          // Para la rectificacion de oficio
			          if (paramMulta.get("tipDilig") != null)
			          {
			            keyMultas.put("NUM_CORREDOC", multa.get("NUM_CORREDOC"));
			            keyMultas.put("COD_TIPDILIGENCIA", multa.get("COD_TIPDILIGENCIA"));
			            keyMultas.put("COD_MULTA", multa.get("COD_MULTA"));
			            if (multa.containsKey("NUM_CORREDOC"))
			            {
			              keyMultas.put("NUM_CORREDOC_SOL", multa.get("NUM_CORREDOC_SOL"));
			            }
	
			            multa.put("dataOriginal", keyMultas);
			            multa.put("clave", keyMultas);
	
			            this.registrarRectiOficio(multa, paramMulta.get("tipDilig").toString().trim(), new Long(multa.get(
			                "NUM_CORREDOC").toString().trim()), "T0022");
			          }
	
			        }
		        }
		      }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerCatMultas(Map<String, Object> params) throws ServiceException
  {

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + params.get("caduana").toString().trim()));

    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    params.put("FEC_DECLARACION", new Long(sdf.format((Date) params.get("FEC_DECLARACION"))));
    List<Map<String, Object>> listaConcepto = new ArrayList(conceptoDAO.findConceptosInRangoFecha(params));
    List<Map<String, Object>> infractoresMulta = new ArrayList<Map<String, Object>>();
    if (listaConcepto != null)
    {
      List<String> codConceptos = new ArrayList<String>();
      for (Map<String, Object> concepto : listaConcepto)
      {
        codConceptos.add((String) concepto.get("CODCONC"));
        codConceptos.add((String) concepto.get("NATURALEZA"));  //PAS20155E220000054
      }
      // Listado de infractores con descripcion de nombre en Grupo 202
      // (Actualmente Catalogo 359)
      infractoresMulta = new ArrayList(sancionOperDAO.findInfractoresMulta(codConceptos));
      // Listado de conceptos con relacion en SancionOper y en Grupo 202
      // (Actualmente Catalogo 359)
      List<Map<String, Object>> conceptosEnSancionOper = new ArrayList(
          sancionOperDAO.findConceptosEnSancionOper(codConceptos));
      agregarConceptoConRelacionSancionOper(conceptosEnSancionOper, listaConcepto, infractoresMulta);
      // Listado de conceptos sin relacion en SancionOper (Se agregan a
      // infractor Otros)
      List<Map<String, Object>> lstSancOper = (ArrayList<Map<String, Object>>) new ArrayList(
          sancionOperDAO.findInfractorMultas(codConceptos));
      agregarConceptoSinRelacionSancionOper(listaConcepto, infractoresMulta, lstSancOper);
    }
    return infractoresMulta;
  }

  /**
   * Agregar concepto con relacion sancion oper.
   *
   * @param conceptosEnSancionOper
   *          the conceptos en sancion oper
   * @param listaConcepto
   *          the lista concepto
   * @param infractoresMulta
   *          the infractores multa
   * @throws ServiceException
   *           the service exception
   */
  private void agregarConceptoConRelacionSancionOper(List<Map<String, Object>> conceptosEnSancionOper,
    List<Map<String, Object>> listaConcepto, List<Map<String, Object>> infractoresMulta) throws ServiceException
  {
    for (Map<String, Object> conceptoEnSancion : conceptosEnSancionOper)
    {
      for (Map<String, Object> concepto : listaConcepto)
      {
        if (conceptoEnSancion.get("COD_MULTA").equals(concepto.get("CODCONC")))
        {
          for (Map<String, Object> infractorMulta : infractoresMulta)
          {
            if (infractorMulta.get("COD_INFRACTOR").equals(conceptoEnSancion.get("COD_INFRACTOR")))
            {
              agregarConceptoEnListaOrdenada(infractorMulta, concepto);
            }
          }
        }
      }
    }
  }

  /**
   * Agregar concepto sin relacion sancion oper.
   *
   * @param listaConcepto
   *          the lista concepto
   * @param infractoresMulta
   *          the infractores multa
   * @param lstSancOper
   *          the lst sanc oper
   */
  private void agregarConceptoSinRelacionSancionOper(List<Map<String, Object>> listaConcepto,
    List<Map<String, Object>> infractoresMulta, List<Map<String, Object>> lstSancOper)
  {

    boolean agregado;


    Map sanciones = new HashMap();
    for (Map<String, Object> sancionMap : lstSancOper)
    {
      sanciones.put((String) sancionMap.get("COD_MULTA"), sancionMap.get("NUM_ELEMENTOS"));
    }

    for (Map<String, Object> concepto : listaConcepto)
    {

      if (sanciones.get((String) concepto.get("CODCONC")) == null)
      {
        agregado = false;
        for (Map infractorMulta : infractoresMulta)
        {
          if ("Z".equals(infractorMulta.get("COD_INFRACTOR")))
          {
            agregarConceptoEnListaOrdenada(infractorMulta, concepto);
            agregado = true;

            break;
          }
        }
        if (!agregado)
        {
          Map infractorPorDefecto = new HashMap();
          infractorPorDefecto.put("COD_INFRACTOR", "Z");
          infractorPorDefecto.put("DES_DATACAT", "Otros");
          infractoresMulta.add(infractorPorDefecto);
          agregarConceptoEnListaOrdenada(infractorPorDefecto, concepto);
        }
      }
    }
  }

  /**
   * Agregar concepto en lista ordenada.
   *
   * @param infractor
   *          the infractor
   * @param concepto
   *          the concepto
   * @throws ServiceException
   *           the service exception
   */
  private void agregarConceptoEnListaOrdenada(Map infractor, Map concepto) throws ServiceException
  {
    if (infractor.containsKey("LISTADO"))
    {
      Set<Map<String, Object>> listadoMultasPorInfractor = (HashSet) infractor.get("LISTADO");
      listadoMultasPorInfractor.add(concepto);
    }
    else
    {
      Set<Map<String, Object>> listadoMultasPorInfractor = new HashSet<Map<String, Object>>();
      listadoMultasPorInfractor.add(concepto);
      infractor.put("LISTADO", listadoMultasPorInfractor);
    }
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> crearMultaMaps(Map paramMulta,
    List<Map<String, Object>> multas) throws ServiceException
  {
    List<Map<String, Object>> listaMultas = new ArrayList<Map<String, Object>>();
    String sufijo;
    Calendar gc;
    Date fechaRegistro;
    String pctRebaja;
    for (Map<String, Object> multa : multas)
    {
      for (String clave : multa.keySet())
      {
        if (clave.startsWith("cbxSeleccion"))
        {
          sufijo = clave.substring("cbxSeleccion".length(),clave.length());
          pctRebaja = "".equals(multa.get("selPctRebaja" + sufijo).toString().trim()) ? "0" : multa.get(
              "selPctRebaja" + sufijo).toString().trim();
          gc = GregorianCalendar.getInstance();
          fechaRegistro = gc.getTime();
          Map<String, Object> multaReg = new HashMap<String, Object>();
          multaReg.put("COD_MULTA", multa.get("txtCodMulta" + sufijo));
          multaReg.put("MTO_MULTA", new BigDecimal((String) multa.get("txtMonto" + sufijo)).setScale(2,
              BigDecimal.ROUND_HALF_UP));
          multaReg.put("POR_DESCUENTO", new BigDecimal(pctRebaja).setScale(2,BigDecimal.ROUND_HALF_UP));
          multaReg.put("MTO_TOTALMULTA", new BigDecimal((String) multa.get("txtMontoPag" + sufijo))
              .setScale(2, BigDecimal.ROUND_HALF_UP));
          multaReg.put("MONEDA", multa.get("txtMoneda" + sufijo));
          multaReg.put("TIPO_MULTA", multa.get("txtTipoMulta"
              + sufijo));
          multaReg.put("NATURALEZA", multa.get("txtNaturaleza"
              + sufijo));

          multaReg.put("IND_LC", " ");
          multaReg.put("NUM_LC", " ");
          multaReg.put("ANN_LC", "0");
          multaReg.put("COD_ADUANALC", " ");
          multaReg.put("DES_EXONERALC", " ");
          multaReg.put("IND_DEL", "0");

          multaReg.put("COD_FUNCIONARIO", paramMulta.get("NUM_REG_USUARIO"));
          multaReg.put("COD_USUREGIS", paramMulta.get("NUM_REG_USUARIO"));
          multaReg.put("FEC_REGIS", fechaRegistro);
          multaReg.put("COD_USUMODIF", paramMulta.get("NUM_REG_USUARIO"));
          multaReg.put("FEC_MODIF", fechaRegistro);
          multaReg.putAll(paramMulta);

          listaMultas.add(multaReg);
        }
      }
    }
    return listaMultas;
  }

  /**
   * Registrar recti oficio.
   *
   * @param mapRectif
   *          the map rectif
   * @param tipDilig
   *          the tip dilig
   * @param numCorredoc
   *          the num corredoc
   * @param codTabla
   *          the cod tabla
   */
  public void registrarRectiOficio(Map mapRectif, String tipDilig, Long numCorredoc, String codTabla) throws ServiceException
  {
	  /*inicio P28-PAS20155E410000032 [jlunah] - BUG 3475 ERROR DE PRODUCCION QUE CORRIGE SWF*/
	  try {
    mapRectif.put("NUM_SECCAMBIO", this.sequenceDAO.getNextSequence(Constantes.KEY_SECUENCIA_OFI_RECTI));
    mapRectif.put("tipoDiligencia", tipDilig);
    mapRectif.put("tabla", codTabla);
    mapRectif.put("NUM_CORREDOC", numCorredoc);
    if (mapRectif.get("dataOriginal") == null)
    {
      mapRectif.put("dataOriginal", mapRectif.get("clave"));
    }

    rectiOficioDAO.insertMapComparador(mapRectif);
	} catch (Exception e) {
		// TODO: handle exception
		//System.out.print("Error"+e);
	}
	  /*fin P28-PAS20155E410000032 [jlunah] - BUG 3475 ERROR DE PRODUCCION QUE CORRIGE SWF*/
  }

  	/* RIN15 - f2 3011 - Inicio - lrodriguezc */
  
	@Override
	public List<MultaDua> listMultaDUA(Map paramMulta) throws ServiceException {
		return multaDuaDAO.listMultaDUA(paramMulta);
	}
	
	/* RIN15 - f2 3011 - Fin - lrodriguezc */
	

  /*
   * RIN13
   * @see pe.gob.sunat.despaduanero2.multa.service.MultaService#obtenerListaCatMultasPorInfractor(java.util.HashMap)
   */
  public List<Map<String, Object>> obtenerListaCatMultasPorInfractor(Map<String, Object> parametros) throws ServiceException {
      Date fechaDeclaracion = (Date) parametros.get("FEC_DECLARACION_AUX");
	  //pase42 lalberti
      FechaBean tmp = new FechaBean();
      tmp.setFecha(fechaDeclaracion);

      String dia = tmp.getDia(); //String dia = fechaTemporal.substring(0, 4);
      String mes = tmp.getMes(); //String mes = fechaTemporal.substring(5, 7);
      String annio = tmp.getAnho();//String annio = fechaTemporal.substring(8, 10);	      
	  	  //pase42 lalberti fin
      log.debug("fecha_anio: "+annio+"fecha_mes: "+mes+"fecha_dia: "+dia);
      
	  List<String> lista = new ArrayList<String>();
	  lista.add(parametros.get("COD_INFRACTOR").toString());
	  List<Map<String, Object>> listadoCodigoDeMultasPorInfractor = sancionOperDAO.findSancionOperByInfractoresVigentes(lista);
	  
	  List<String> listaMultas = new ArrayList<String>();
	  for (Map<String, Object> list : listadoCodigoDeMultasPorInfractor) {		  
		listaMultas.add(list.get("COD_MULTA").toString());		
	  }
	  
	  List<String> listCMonedaMul = new ArrayList<String>();
	  listCMonedaMul.add("S");
	  listCMonedaMul.add("D");
	  
	  parametros.put("listaMultas", listaMultas);
	  parametros.put("listCMonedaMul", listCMonedaMul);
	  // COMENTADO TEMPORALMENTE <rcalle> parametros.put("FEC_DECLARACION", annio+mes+dia);
	  List<Map<String, Object>> listaCatMultasPorInfractor = conceptoDAO.obtenerListaCatMultasPorInfractor(parametros);
	  if(listaCatMultasPorInfractor == null || listaCatMultasPorInfractor.size() < 1){
		  throw new ServiceException(this, "No existen infracciones."); 
	  }
	  return listaCatMultasPorInfractor;
  }
    
  /**
   * RIN13 SWF
   * */
  public boolean tieneInfraccionEnOtraDiligencia(Map<String,Object> parametros) throws ServiceException {
	  boolean bandera = false;
	  List<String> listCodTipDiligencia = new ArrayList<String>();
	  listCodTipDiligencia.add("06");
	  listCodTipDiligencia.add("10");	  
	  
	  Map<String, Object> parametros2 = new HashMap<String, Object>();
	  parametros2.put("listCodTipDiligencia", listCodTipDiligencia);
	  parametros2.put("codMulta", parametros.get("codInfraccion"));
	  parametros2.put("indDel", "0");
	  parametros2.put("numCorredoc", parametros.get("numCorredoc"));
	  List<Map<String,Object>> listadoTotalInfracciones = multaDuaDAO.buscaMismaInfraccionEnOtraDiligencia(parametros2);
	  
	  if(listadoTotalInfracciones!=null && !listadoTotalInfracciones.isEmpty()){
		  
		  bandera = true;
		  
	  }
	  
  	return bandera;
  }
  
  /**
   * RIN13 - SWF
   * */
  public ObjectResponseUtil validarMontoMultasVsMontoAutoliquidaciones(List<Map<String,Object>> lstMultasRegistradas,List<Map<String,Object>> lstAutoliq, String numCtaCte, String TipDiligencia){
	  
		BigDecimal montoTotalMultaSoles = new BigDecimal(0);
		BigDecimal montoTotalAutoliqSoles = new BigDecimal(0);
		
		BigDecimal montoTotalMultaDolares = new BigDecimal(0);
		BigDecimal montoTotalAutoliqDolares = new BigDecimal(0);
		
		BigDecimal montoDiferencialMultaDolares = new BigDecimal(0);
		BigDecimal montoDiferencialMultaSoles = new BigDecimal(0);
		
		ObjectResponseUtil respuesta = new ObjectResponseUtil();
		respuesta.setRespuesta(false);
		
		Map<String, Object> datosGenerarLC = new HashMap<String, Object>();
		datosGenerarLC.put("montoMultaDolares", BigDecimal.ZERO);
		datosGenerarLC.put("montoMultaSoles", BigDecimal.ZERO);
		datosGenerarLC.put("montoTotalAutoliquidacionesDolares", BigDecimal.ZERO);
		datosGenerarLC.put("montoTotalAutoliquidacionesSoles", BigDecimal.ZERO);		
		datosGenerarLC.put("generaLC003", false);
		
		//String mensaje = "Monto de Autoliquidaci�n no cubre, el monto de la multa registrada";

		/* agrupamos por soles */
		List<Map<String, Object>> multaSoles = new ArrayList<Map<String, Object>>();
		multaSoles = obtenerMultasPorMoneda(lstMultasRegistradas, "Soles");

		List<Map<String, Object>> autoliqSoles = new ArrayList<Map<String, Object>>();
		autoliqSoles = obtenerAutoliqPorMoneda(lstAutoliq, "S");
		
		/* evaluamos montos en soles */
		for (Map multa : multaSoles) {
			montoTotalMultaSoles = SunatNumberUtils.sum(montoTotalMultaSoles,
					new BigDecimal(multa.get("montoPagar").toString()));
		}

		for (Map autoliq : autoliqSoles) {
			montoTotalAutoliqSoles = SunatNumberUtils.sum(montoTotalAutoliqSoles,
					new BigDecimal(autoliq.get("montoPagar").toString()));
		}
		
		/*if(montoTotalMultaSoles.compareTo(montoTotalAutoliqSoles) == 1){ //si el monto de la multa es mayor al monto de las autoliquidaciones seleccionadas
			return mensaje;
		}*/
		
		/* agrupamos por dolares */
		List<Map<String, Object>> multaDolares = new ArrayList<Map<String, Object>>();
		multaDolares = obtenerMultasPorMoneda(lstMultasRegistradas, "Dolares");

		List<Map<String, Object>> autoliqDolares = new ArrayList<Map<String, Object>>();
		autoliqDolares = obtenerAutoliqPorMoneda(lstAutoliq, "D");

		/* evaluamos montos en dolares */
		for (Map multa : multaDolares) {
			montoTotalMultaDolares = SunatNumberUtils.sum(montoTotalMultaDolares,
					new BigDecimal(multa.get("montoPagar").toString()));
		}

		for (Map autoliq : autoliqDolares) {
			montoTotalAutoliqDolares = SunatNumberUtils.sum(montoTotalAutoliqDolares,
					new BigDecimal(autoliq.get("montoPagar").toString()));
		}
		
		/*if(montoTotalMultaDolares.compareTo(montoTotalAutoliqDolares) == 1){ //si el monto de la multa es mayor al monto de las autoliquidaciones seleccionadas
			return mensaje;
		}*/

		//En el caso de declaraciones que tengan garantia previa del Art. 160�, el sistema verificar� que existan autiliquidaciones que cubran el monto de la multa, 
		//caso contrario detiene el proceso no genera Liquidaciones de Cobranza y emite el siguiente mensaje: "Declaraci�n con Garantia Previa Art. 160�"
		if(!SunatStringUtils.isEmptyTrim(numCtaCte) && (!Constantes.DILIG_REGULARIZACION.equalsIgnoreCase(TipDiligencia) && !Constantes.DILIG_CONCLUSION_DESPACHO.equalsIgnoreCase(TipDiligencia))){
			if(montoTotalMultaSoles.compareTo(montoTotalAutoliqSoles) == 1 ||
					montoTotalMultaDolares.compareTo(montoTotalAutoliqDolares) == 1){
					respuesta = new ObjectResponseUtil("Declaraci�n con Garantia Previa Art. 160�");
					return respuesta;
			}
		}else{
			//si el monto de la multa es mayor al monto de las autoliquidaciones seleccionadas
			if (montoTotalMultaSoles.compareTo(montoTotalAutoliqSoles) == 1){
				montoDiferencialMultaSoles = montoTotalMultaSoles.subtract(montoTotalAutoliqSoles);
				datosGenerarLC.put("montoMultaSoles", montoDiferencialMultaSoles);
				datosGenerarLC.put("montoTotalAutoliquidacionesSoles", montoTotalAutoliqSoles);
				datosGenerarLC.put("generaLC003", true);
				respuesta.setRespuesta(true);
				
				////Por mientras hasta que este lo de resolucion de multas
				//respuesta = new ObjectResponseUtil("Monto de Autoliquidaci�n no cubre, el monto de la multa registrada");
				//return respuesta;	
				//
			}
			
			if(montoTotalMultaDolares.compareTo(montoTotalAutoliqDolares) == 1){
				montoDiferencialMultaDolares = montoTotalMultaDolares.subtract(montoTotalAutoliqDolares);
				datosGenerarLC.put("montoMultaDolares", montoDiferencialMultaDolares);
				datosGenerarLC.put("montoTotalAutoliquidacionesDolares", montoTotalAutoliqDolares);
				datosGenerarLC.put("generaLC003", true);
				respuesta.setRespuesta(true);
				
				////Por mientras hasta que este lo de resolucion de multas
				//respuesta = new ObjectResponseUtil("Monto de Autoliquidaci�n no cubre, el monto de la multa registrada");
				//return respuesta;
				//
			}
		}
		
		respuesta.addDato("generarLCMulta", datosGenerarLC);
		
		//return "";
		return respuesta;
  }
  
  /**
   * RIN13 - SWF
   * */
  public List<Map<String,Object>> asociarAutoliqConMultas(List<Map<String,Object>> multas, List<Map<String,Object>> autoliquidaciones, String moneda){
	  
		List<Map<String, Object>> listaMultaVsAutoliq = new ArrayList<Map<String, Object>>();

		//BigDecimal montoSuma = new BigDecimal(0);
		int i = 0;

		List<Map<String, Object>> listaMulta = multas;
		List<Map<String, Object>> listaAutoliquidaciones = autoliquidaciones;

		Integer cantidadAutoliquidaciones = listaAutoliquidaciones.size();
		Integer cantidadMultas = listaMulta.size();

		BigDecimal montoTemp = null;
		for (Map<String, Object> itemListaMulta : listaMulta) {
			if ( itemListaMulta == null ) continue;
			montoTemp = new BigDecimal(itemListaMulta.get("montoPagar").toString());
			itemListaMulta.put("montoPagar", montoTemp);
		}
		for (Map<String, Object> itemAutoLiquidaciones : listaAutoliquidaciones) {
			if ( itemAutoLiquidaciones == null ) continue;
			montoTemp = new BigDecimal(itemAutoLiquidaciones.get("montoPagar").toString());
			itemAutoLiquidaciones.put("montoPagar", montoTemp);
		}		
		Ordenador.sortDesc(listaMulta, "montoPagar", Ordenador.DESC);
		Ordenador.sortDesc(listaAutoliquidaciones, "montoPagar", Ordenador.DESC);

		BigDecimal resto = new BigDecimal(0);

		if (listaMulta != null) {

			while (i < cantidadMultas) {

				BigDecimal montoMulta = new BigDecimal(0);

				if (resto.compareTo(new BigDecimal(0)) == 0) {
					montoMulta = new BigDecimal(listaMulta.get(i).get("montoPagar").toString());
				} else {
					montoMulta = resto.multiply(new BigDecimal("-1"));
				}

				// empiezo a buscar si hay un valor igual al monto de la multa
				// recorrido

				for (int j = 0; j < cantidadAutoliquidaciones; j++) {

					BigDecimal montoAutoliq = new BigDecimal(0);

					// verifico si la autoliq no ha sido usada
					if (listaAutoliquidaciones.get(j).get("indicadorUsado").equals("N")) {// SI NO HA SIDO USADO
						if (new BigDecimal(listaAutoliquidaciones.get(j).get("montoResto").toString()).compareTo(new BigDecimal(0)) == 0) {
							montoAutoliq = new BigDecimal(listaAutoliquidaciones.get(j).get("montoPagar").toString());
						} else {
							montoAutoliq = new BigDecimal(listaAutoliquidaciones.get(j).get("montoResto").toString());
						}

						resto = SunatNumberUtils.diference(montoAutoliq,montoMulta);

						if (resto.compareTo(new BigDecimal(0)) == 0) { // CUBRIO POR COMPLETO
							// asocio multa con autoliq;
							// ponerle estado USADO a la autoliquidacion
							// ponerle valor del resto = 0 a la autoliquidacion
							Map<String, Object> listaMultaTemp = new HashMap<String, Object>();
							listaMultaTemp = usarAutoliquidacion(listaMulta.get(i),listaAutoliquidaciones.get(j), moneda, listaMultaVsAutoliq); // asocio liquidacion a multa
							listaMultaVsAutoliq.add(listaMultaTemp);
							listaAutoliquidaciones.get(j).put("indicadorUsado","U");
							listaAutoliquidaciones.get(j).put("montoResto", 0);
							resto = new BigDecimal(0);
							i++;
							break;
						}
						if (resto.compareTo(new BigDecimal(0)) > 0) { // CURBRIO EN PARTE
							
							// quiere decir que hay saldo en la autoliquidacion por usar

							// asociar multa con autoliquidacion
							// ponerle valor del resto a la autoliquidacion
							Map<String, Object> listaMultaTemp = new HashMap<String, Object>();
							listaMultaTemp = usarAutoliquidacion(listaMulta.get(i),listaAutoliquidaciones.get(j), moneda , listaMultaVsAutoliq); // asocio liquidacion a multa
							listaMultaVsAutoliq.add(listaMultaTemp);
							listaAutoliquidaciones.get(j).put("montoResto",resto);
							resto = new BigDecimal(0);
							i++;
							break;

						}
						if (resto.compareTo(new BigDecimal(0)) < 0) { // NO CUBRIO
							
							// quiere decir que la multa no fue cubierta del todo por la autoliquidacion

							// asocio multa con autoliq;
							// ponerle estado USADO a la autoliquidacion
							// ponerle valor del resto = 0 a la autoliquidacion
							Map<String, Object> listaMultaTemp = new HashMap<String, Object>();
							listaMultaTemp = usarAutoliquidacion(listaMulta.get(i),listaAutoliquidaciones.get(j), moneda , listaMultaVsAutoliq); // asocio liquidacion a multa
							listaMultaVsAutoliq.add(listaMultaTemp);
							listaAutoliquidaciones.get(j).put("indicadorUsado","U");
							listaAutoliquidaciones.get(j).put("montoResto", 0);
							break;

						}
					}
				}

			}
		}

		return listaMultaVsAutoliq;
  }
  
  /**
   * RIN13 - SWF
   * */
  private Map<String,Object> usarAutoliquidacion(Map<String,Object> listaMultaSoles , Map<String,Object> listaAutoliqSoles , String moneda , List<Map<String, Object>> listaMultaVsAutoliq){
	  
	  Map<String,Object> multa = new HashMap<String, Object>();
	  multa.put("COD_MULTA", listaMultaSoles.get("codMulta"));
	  multa.put("MTO_MULTA", listaMultaSoles.get("montoMulta"));
	  multa.put("PORCENTAJE_MULTA", listaMultaSoles.get("incentivo")!=null ? listaMultaSoles.get("incentivo").toString().substring(0, listaMultaSoles.get("incentivo").toString().length()-1) : "0");
	  multa.put("MTO_PAGAR_MULTA", listaMultaSoles.get("montoPagar"));
	  multa.put("MONEDA_MULTA", moneda);
	  multa.put("TIPO_MULTA", "");
	  multa.put("NATURALEZA_MULTA", "");
	  multa.put("NRO_LC", listaAutoliqSoles.get("numeroLiquidacion"));
	  multa.put("ANN_LC", listaAutoliqSoles.get("anyo"));
	  multa.put("ADUANA_LC", listaAutoliqSoles.get("aduana"));
	  multa.put("FECHA_MULTA", SunatDateUtils.getDate((String) listaMultaSoles.get("fechaInfraccion"), Constantes.FORMAT_ddMMyyyy));
	  multa.put("NUM_CORREDOC_SOL", new BigDecimal(0));
	  multa.put("NUM_SEC_MULTA", asignaSecuenciaMulta(listaMultaVsAutoliq,listaAutoliqSoles.get("numeroLiquidacion").toString(),listaAutoliqSoles.get("anyo").toString(),listaAutoliqSoles.get("aduana").toString()));
	  multa.put("DATOS_ORIGINALES", listaMultaSoles);
	  
	  return multa;
  }
  
  /**
   * RIN13 -SWF
   * */
  private BigDecimal asignaSecuenciaMulta(List<Map<String, Object>> listaMultaVsAutoliq , String numeroLiquidacion , String anyoLiquidacion , String aduanaLiquidacion){
	  
	  BigDecimal numeroSecuencia = new BigDecimal(0);
	  
	  if(listaMultaVsAutoliq!= null){
		  
		  for(Map<String,Object> multa : listaMultaVsAutoliq){
			  
			  if(multa.get("NRO_LC").toString().equals(numeroLiquidacion) && multa.get("ANN_LC").toString().equals(anyoLiquidacion) && multa.get("ADUANA_LC").toString().equals(aduanaLiquidacion)){
				  numeroSecuencia = SunatNumberUtils.sum(numeroSecuencia, new BigDecimal(1));
			  }
			  
		  }
		  
	  }else{
		  
		  return numeroSecuencia;
		  
	  }
	  
	  return numeroSecuencia;
  }
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String,Object>> obtenerMultasPorMoneda(List<Map<String,Object>> lstMultasRegistradas, String moneda){
	  
	  List<Map<String,Object>> multasSoles = new ArrayList<Map<String,Object>>();
	  
	  for(Map<String,Object> multa : lstMultasRegistradas){
		  if(multa.get("moneda")!=null){
			  if(multa.get("moneda").toString().equals(moneda)){
				  multasSoles.add(multa);
			  }  
		  }
	  }
	  
	  return multasSoles;
  }
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String,Object>> obtenerAutoliqPorMoneda(List<Map<String,Object>> lstAutoliq , String moneda){
	  
	  List<Map<String,Object>> autoliqSoles = new ArrayList<Map<String,Object>>();
	  
	  for(Map<String,Object> autoliq : lstAutoliq){
		  if(autoliq.get("moneda")!=null){
			  if(autoliq.get("moneda").toString().equals(moneda)){
				  autoliqSoles.add(autoliq);
			  }  
		  }
	  }
	  
	  return autoliqSoles;
  }
  
  /**
   * RIN13 SWF
   * */
public BigDecimal calcularMontoMultaAutomatico(String codigoInfraccion, String formulaMulta){
	  
	  BigDecimal montoMulta = new BigDecimal(1);
	  String multiplicador1 = "1";
	  String multiplicador2 = "1";
	  
	  Map<String, Object> params = new HashMap<String, Object>();
	  params.put("fSistema", SunatDateUtils.getIntegerFromDate(new Date()));
	  
	  Uit uit = uitDAO.findByParams(params);
	  
	  BigDecimal montoUIT = uit.getMuit();
	  
		  //calculamos monto automatico
		  /*la formula por lo general tiene esta forma :
		   * mUIT = monto exacto de la UIT
		   * (Numero entero o decimal)*mUIT
		   * */
		  if(formulaMulta!=null && !formulaMulta.equals("") && !formulaMulta.equals(" ")){
			  
			  if(formulaMulta.equalsIgnoreCase("mUIT")){ //monto multa igual al de la uit
				  
				  montoMulta = montoUIT;
				  
			  }else{//aplico formula
				  
				  String [] datosFormula = formulaMulta.split("\\*");
				  if(datosFormula != null){
					  int i = 0;
					  while (i < datosFormula.length) {

						  multiplicador1 = datosFormula[i];
						  if(multiplicador1.equalsIgnoreCase("mUIT")){
							  multiplicador1 = montoUIT.toString();
						  }
						  
						  if( (i+1) < datosFormula.length ){
							  
							  multiplicador2 = datosFormula[i+1];
							  if(multiplicador2.equalsIgnoreCase("mUIT")){
								  multiplicador2 = montoUIT.toString();
							  }
							  
							  montoMulta = montoMulta.multiply( new BigDecimal(multiplicador1).multiply(new BigDecimal(multiplicador2)));
							  i = i + 2;
							  
						  }else{
							  
							  montoMulta = montoMulta.multiply( new BigDecimal(multiplicador1) );
							  i = i + 2;
							  
						  }
							
						}  
				  }
			  }
		  }
		  
		  
		  if(montoMulta.compareTo(new BigDecimal(1)) == 0){
			  montoMulta = new BigDecimal(0); 
		  }
		  
		  return montoMulta;
  }
  
  /**
   * RIN13 SWF
   * */
  public List<Map<String, Object>> armarMapaMultasParaRegistroDiligenciaDespacho(Map paramMulta,
		    List<Map<String, Object>> multas) throws ServiceException
		  {
		    List<Map<String, Object>> listaMultas = new ArrayList<Map<String, Object>>();
		    Calendar gc;
		    Date fechaRegistro;
		    for (Map<String, Object> multa : multas){

		          gc = GregorianCalendar.getInstance();
		          fechaRegistro = gc.getTime();
		          Map<String, Object> multaReg = new HashMap<String, Object>();
		          multaReg.put("COD_MULTA", multa.get("COD_MULTA"));
		          multaReg.put("MTO_MULTA", new BigDecimal((String) multa.get("MTO_MULTA")).setScale(2,BigDecimal.ROUND_HALF_UP));
		          multaReg.put("POR_DESCUENTO", new BigDecimal((String) multa.get("PORCENTAJE_MULTA")).setScale(2,BigDecimal.ROUND_HALF_UP));
		          multaReg.put("MTO_TOTALMULTA", ((BigDecimal) multa.get("MTO_PAGAR_MULTA")).setScale(2, BigDecimal.ROUND_HALF_UP));
		          multaReg.put("MONEDA", multa.get("MONEDA_MULTA"));
		          multaReg.put("MONEDA_MULTA", multa.get("MONEDA_MULTA")); //lalberti
		          multaReg.put("TIPO_MULTA", multa.get("TIPO_MULTA"));
		          multaReg.put("NATURALEZA", multa.get("NATURALEZA_MULTA"));
		          multaReg.put("NATURALEZA_MULTA", multa.get("NATURALEZA_MULTA"));//lalberti
		          multaReg.put("FEC_INFRACCION", (Date) multa.get("FECHA_MULTA"));

		          multaReg.put("IND_LC", "1");
		          multaReg.put("NUM_LC", multa.get("NRO_LC"));
		          multaReg.put("ANN_LC", multa.get("ANN_LC"));
//lalberti pase42
		          if(multa.get("ADUANA_LC") != null && multa.get("ADUANA_LC").toString().trim().length()>0)
		          multaReg.put("COD_ADUANALC", multa.get("ADUANA_LC"));
		          else
		        	  multaReg.put("COD_ADUANALC", paramMulta.get("COD_ADUANA"));
//fin lalberti
		          multaReg.put("NUM_CORREDOC_SOL", multa.get("NUM_CORREDOC_SOL"));
		          multaReg.put("NUM_SEC_MULTA", multa.get("NUM_SEC_MULTA"));
		          multaReg.put("DES_EXONERALC", " ");
		          multaReg.put("IND_DEL", "0");

		          multaReg.put("COD_FUNCIONARIO", paramMulta.get("NUM_REG_USUARIO"));
		          multaReg.put("COD_USUREGIS", paramMulta.get("NUM_REG_USUARIO"));
		          multaReg.put("FEC_REGIS", fechaRegistro);
		          multaReg.put("COD_USUMODIF", paramMulta.get("NUM_REG_USUARIO"));
		          multaReg.put("FEC_MODIF", fechaRegistro);
		          multaReg.putAll(paramMulta);

		          listaMultas.add(multaReg);
		    }
		    
		    return listaMultas;
		    
     }
  //Inicio PAS20155E220000054 
  public List<Map<String,Object>> getListMultasNoCubreAutoliquidaciones(List<Map<String,Object>> lstMultasRegistradas)
  {
  	List<Map<String, Object>> listaMulta = new ArrayList<Map<String, Object>>();
  	String COD_SOLES = "S";
  	String COD_DOLAR = "D";
  	
  	if (lstMultasRegistradas != null )
  	{
  		for (Map<String, Object> itemListaMulta : lstMultasRegistradas) 
  		{		  Map<String,Object> multa = new HashMap<String, Object>();
  				  multa.put("COD_MULTA", itemListaMulta.get("codMulta"));
  				  multa.put("MTO_MULTA", itemListaMulta.get("montoMulta"));
  				  multa.put("PORCENTAJE_MULTA", itemListaMulta.get("incentivo")!=null ? itemListaMulta.get("incentivo").toString().substring(0, itemListaMulta.get("incentivo").toString().length()-1) : "0");
  				  multa.put("MTO_PAGAR_MULTA", SunatNumberUtils.toBigDecimal(itemListaMulta.get("montoPagar")));
  				  multa.put("MONEDA_MULTA", itemListaMulta.get("moneda").equals("Soles")? COD_SOLES:COD_DOLAR);
  				  multa.put("TIPO_MULTA", "");
  				  multa.put("NATURALEZA_MULTA", itemListaMulta.get("naturaleza"));
  				  multa.put("NRO_LC", " ");
  				  multa.put("IND_LC", " ");
  				  multa.put("ANN_LC", "0");				  
  				  multa.put("IND_DEL", "0");				  
  				  multa.put("ADUANA_LC", " ");
  				  multa.put("FECHA_MULTA", SunatDateUtils.getDate((String) itemListaMulta.get("fechaInfraccion"), Constantes.FORMAT_ddMMyyyy));
  				  multa.put("INFRACCION", itemListaMulta.get("infraccion"));
  				  multa.put("MONEDA", itemListaMulta.get("moneda"));
  				  multa.put("DATOS_ORIGINALES", itemListaMulta);
  				  listaMulta.add(multa);
  		}
  	}
  	
  	return listaMulta;
    }
  /***********************SET DE SPRING **********************************/


  public void setMultaDuaDAO(MultaDuaDAO multaDuaDAO)
  {
    this.multaDuaDAO = multaDuaDAO;
  }


  public void setSancionOperDAO(SancionOperDAO sancionOperDAO)
  {
    this.sancionOperDAO = sancionOperDAO;
  }


  public void setConceptoDAO(ConceptoDAO conceptoDAO)
  {
    this.conceptoDAO = conceptoDAO;
  }


  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }


  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }


  public void setRectiOficioDAO(RectiOficioDAO rectiOficioDAO)
  {
    this.rectiOficioDAO = rectiOficioDAO;
  }

  public void setSequenceDAO(SequenceDAO sequenceDAO)
  {
    this.sequenceDAO = sequenceDAO;
  }

}
