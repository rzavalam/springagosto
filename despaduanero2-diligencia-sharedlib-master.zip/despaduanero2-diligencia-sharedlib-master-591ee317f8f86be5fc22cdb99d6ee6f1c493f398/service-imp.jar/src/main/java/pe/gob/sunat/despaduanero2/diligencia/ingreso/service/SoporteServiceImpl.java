package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.administracion2.tramite.model.dao.ExpediDAO;
import pe.gob.sunat.administracion2.tramite.service.DocumentoInternoService;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
//import pe.gob.sunat.administracion2.tramite.model.dao.TabDepDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TabLibe;
import pe.gob.sunat.despaduanero.catalogo.tg.service.CalculaDiaDAOService;
import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero.despacho.model.dao.ODepoCabDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NandTasa;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ResSpimDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.TabBolQuimDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
//import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.model.Participante;


import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.prevcontrabando2.ace.util.ConstantesACE;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.CabActasDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.DatAuxActaDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.FnValidarMedidaPreventivaDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovDuasActasDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovManifiestosActasDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.servicio2.registro.model.Spr;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.servicio2.registro.service.SprDAOService;
import pe.gob.sunat.servicio2.registro.service.T733DAOService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeclaranDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandinaDAO;
import pe.gob.sunat.tecnologia.menu.sso.service.AduanaRol;
//import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;

/**
 * The Class SoporteServiceImpl.
 * Expone los servicio que involucran tablas del ASIGAD
 *
 * @author rmontesc, wmostacero
 */
@SuppressWarnings({ "rawtypes","unchecked" })
public class SoporteServiceImpl implements SoporteService
{

  private NandTasaDAO                  nandTasaDAO;

  //private NandinaDAO                   nandinaDAO;

//  private NandUniDAO                   nandUniDAO;

//  private TabLibeDAO                   tabLibeDAO;

  //private DeclaranDAO                  declaranDAO;

  private ExpediDAO                    expediDAO;

  private LiquidaDAO                   liquidaDAO;

  private TabBolQuimDAO                tabBolQuimDAO;

//  private DdpDAO                       ddpDAO;

//  private T733DAO                      t733DAO;

  private CabActasDAO                  cabActasDAO;

  private ODepoCabDAO                  oDepoCabDAO;

  private DocuTransDAO                 docuTransDAO;

  private FabricaDeServicios           fabricaDeServicios;

  private HotSwappableTargetSource     swapperDatasource;

  private CatalogoAyudaService         catalogoAyudaService;

  private MovDuasActasDAO              movDuasActasDAO;

//  private CalculaDiaDAO                calculaDiaDAO;

  private DatAuxActaDAO                datAuxActaDAO;

  private FnValidarMedidaPreventivaDAO fnValidarMedidaPreventivaDAO;

  private DetDeclaraDAO                detdeclaraDAO;

  private ResSpimDAO                   resSpimDAO;

//  private SprDAO                       sprDAO;

//  private TabDepDAO                    tabDepDAO;

  private MovManifiestosActasDAO       movManifiestosActasDAO;
  
private  AyudaService ayudaService;

private DdpDAOService ddpDAOService;

private SprDAOService sprDAOService;

private T733DAOService t733daoService;

private CalculaDiaDAOService calculaDiaDAOService;

private TabLibeDAOService tabLibeDAOService; 

private HotSwappableTargetSource     swapperDatasourceTabLib;
/*RIN13FSW-INICIO*/
//<EHR>
private PublicacionAvisoService publicacionAvisoService;
private AduanaRol aduanaRol;
//</EHR>
/*RIN13FSW-FIN*/
  public AyudaService getAyudaService() {
	return ayudaService;
}

public void setAyudaService(AyudaService ayudaService) {
	this.ayudaService = ayudaService;
}

protected final Log                  log = LogFactory.getLog(this.getClass());

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerBoletinQuimico(Map<String, Object> params) throws ServiceException
  {
    List res;
    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + params.get("caduana").toString().trim()));

      String numDecla = "000000" + params.get("NCORR_DUA").toString().trim();
      numDecla = numDecla.substring(numDecla.length() - 6);
      params.put("NCORR_DUA", numDecla);
      res = this.tabBolQuimDAO.joinDetDeclaraFindByDeclaracion(params);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }

    return res;
  }

  /**
   * {@inheritDoc}
   */
  public Participante completarParticipante(Participante participante)
  {
    Map<String, Object> persona = new HashMap<String, Object>();
    String tip_doc = participante.getTipoDocumentoIdentidad().getCodDatacat();
    String num_doc = participante.getNumeroDocumentoIdentidad();
    persona = obtenerPerNatJur(tip_doc, num_doc);
    if (participante.getNombreRazonSocial() == null
        || SunatStringUtils.isEmptyTrim(participante.getNombreRazonSocial()))
    {
      if (!persona.get("nombre").toString().isEmpty())
      {
        participante.setNombreRazonSocial(persona.get("nombre").toString().trim());
        participante.setNombre(persona.get("nombre").toString().trim());
      }
    }
    if (participante.getDireccion() == null || SunatStringUtils.isEmptyTrim(participante.getDireccion()))
    {
      if (persona!=null && !persona.get("direccion").toString().isEmpty())
      {
        participante.setDireccion(persona.get("direccion").toString().trim());
      }
    }
    return participante;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerPerNatJur(String tip_doc, String num_doc) throws ServiceException
  {
    Map<String, Object> res = null;
    try
    {
      String codigo = "";
      StringBuilder nombre = new StringBuilder("");
      String direccion = "";
      String telefono = "";
            String habido = "";
            String vigente = "";
       String habidoDdp = "";
       String estadoRUC = ""; //Complemento de la Diligencia lmvr 
      Date fechNac = null;
      Date fecVigencia=null;
      Date fecFallecimiento=null;
      StringBuilder nombreDeclarante = new StringBuilder("");

      if (Constants.COD_DATA_CATALOG_TIPO_DOC_RUC.equals(tip_doc))
      {
//        res = this.ddpDAO.findByPK(num_doc.trim());
    	  res = ddpDAOService.findByPK(num_doc.trim());
    	  
        if (!CollectionUtils.isEmpty(res))
        {
          codigo = res.get("ddp_numruc") != null ? res.get("ddp_numruc").toString() : "";
          habidoDdp = (String) res.get("ddp_flag22");
          estadoRUC = (String) res.get("ddp_estado"); //Complemento de la Diligencia lmvr 
          nombre.append(res.get("ddp_nombre") != null ? (String) res.get("ddp_nombre") : "");

//          direccion = ddpDAO.getDomicilioLegal(num_doc);
          direccion = ddpDAOService.getDomicilioLegal(num_doc);          

                    //si RUC es Vigente y Habido Verifica Vigente y Habido del RUC
                    habido = "00".equals(res.get("ddp_flag22").toString().trim()) ? "SI" : "NO";
                    vigente = "00".equals(res.get("ddp_estado").toString().trim()) ? "SI" : "NO";
        }
      }
      else if (Constants.COD_DATA_CATALOG_TIPO_DOC_DNI.equals(tip_doc))
      {
//        res = this.t733DAO.findByPK(num_doc.trim(), "01");
    	  res = this.t733daoService.findByPK(num_doc.trim(), "01");
        if (!CollectionUtils.isEmpty(res))
        {
          codigo = res.get("num_docide_pnat") != null ? res.get("num_docide_pnat").toString() : "";
          nombre.append(res.get("des_apepat_pnat") != null ? ((String) res.get("des_apepat_pnat") + " ") : "")
              .append(res.get("des_apemat_pnat") != null ? ((String) res.get("des_apemat_pnat") + ", ") : "")
              .append(res.get("des_nombre_pnat") != null ? ((String) res.get("des_nombre_pnat") + ", ") : "");
          direccion = res.get("des_domici_pnat") != null ? res.get("des_domici_pnat").toString() : "";
          telefono = res.get("num_telefo_pnat") != null ? res.get("num_telefo_pnat").toString() : "";
          
          fecVigencia          = (Date)((res.get("fec_caducidad") != null) ? res.get("fec_caducidad") : DateUtil.getDefaultDate());
          fechNac              = (Date)((res.get("fec_nac_pnat")  != null) ? res.get("fec_nac_pnat")  : "");
          fecFallecimiento     = (Date)((res.get("fec_fall_pnat")  != null) ? res.get("fec_fall_pnat")  : "");
          nombreDeclarante.append(res.get("des_apepat_pnat") != null ? ((String) res.get("des_apepat_pnat") + " ") : "")
          .append(res.get("des_apemat_pnat") != null ? ((String) res.get("des_apemat_pnat") + " ") : "")
          .append(res.get("des_nombre_pnat") != null ? ((String) res.get("des_nombre_pnat")) : "");
                  
        }
      }
      else if (Constants.COD_DATA_CATALOG_TIPO_DOC_PAS.equals(tip_doc) || Constants.COD_DATA_CATALOG_TIPO_DOC_ORGAN_INTERNA.equals(tip_doc) || 
    		  Constants.COD_DATA_CATALOG_TIPO_CARNET_EXTRANJERIA.equals(tip_doc))
      {
      //  Declaran declaran = declaranDAO.selectByPrimaryKey(num_doc, tip_doc);
        
        Declaran declaran= (Declaran)ayudaService.selectByPrimaryKeyDeclaran(num_doc, tip_doc);
        
        if (declaran != null)
        {
          codigo = declaran.getCdocumen();
          nombre.append(declaran.getDnombre() != null ? declaran.getDnombre() : "");
          direccion = declaran.getDdirecc() != null ? declaran.getDdirecc() : "";
        }
      }

      res = new HashMap();
      res.put("codigo", codigo);
      res.put("nombre", nombre.toString());
      res.put("direccion", direccion);
      res.put("telefono", telefono);
      res.put("habido", habido);
      res.put("vigente", vigente);
      res.put("fechNac", fechNac);
      res.put("habidoDdp", habidoDdp);
      res.put("fecVigencia", fecVigencia);
      res.put("fecFallecimiento",fecFallecimiento);
      res.put("nombreDeclarante", nombreDeclarante.toString());
      res.put("estadoRUC", estadoRUC); //Complemento de la Diligencia lmvr 
      
      
      
      //pase153 se quita pq afecta a la numeracion siempre espera un dato con esos campos
      //return res!=null?res:new HashMap();
      return res;

    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
  }


  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> validarDocPendPago(Map params) throws ServiceException
  {
    List res = new ArrayList();

    try
    {
      List r1 = this.validarLCPendPago(params);
      if (!CollectionUtils.isEmpty(r1))
      {
        res.addAll(r1);
      }

      Map odParam = new HashMap();
      odParam.put("rladuaso", params.get("COD_ADUANA"));
      odParam.put("rlanoaso", params.get("ANN_PRESEN"));
      odParam.put("rlnumaso", params.get("NUM_DECLARACION"));
      odParam.put("rlregimen", params.get("COD_REGIMEN"));

      List r2 = this.validarOrdeDepoPendPago(odParam);
      if (!CollectionUtils.isEmpty(r2))
      {
        res.addAll(r2);
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }

    return res;
  }

  /**
   * {@inheritDoc}
   */ // RIN16
  public List<Map<String, Object>> validarLCPendPago(Map<String, Object> params) throws ServiceException
  {
	  swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
		        + params.get("COD_ADUANA").toString().trim()));
	  
    String ann_presen_2d = (params.get("ANN_PRESEN").toString().trim()).substring(2);
    params.put("ANN_PRESEN_2D", ann_presen_2d);
    String num_corredoc_6c = StringUtils.leftPad((params.get("NUM_DECLARACION").toString().trim()), 6, "0");
    params.put("NUM_CORREDOC_6C", num_corredoc_6c);
    params.put("COD_REGIMEN", params.get("COD_REGIMEN").toString().trim());
    
    //LiquidaDAO liquidaDAO = fabricaDeServicios.getService("diligencia.ingreso.routing.liquidaDef");
    //DataSourceContextHolder.setKeyDataSource((String)params.get("COD_ADUANA"));
    //params.put("COD_REGIMEN", params.get("COD_REGIMEN").toString().trim());
    
 // FIXME : P46 - INICIO - RESTRICCION PARA DUAS IMPUGNADAS
    String tipTratDona = SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(params.get("COD_TIPTRATMERC")));
    String indImpugTotal = SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(params.get("COD_INDICADOR_DONACION")));
        
    if (tipTratDona.equals("4") && indImpugTotal.equals("07")){
    	params.put("NOT_COD_TIPLIQ", "0006");
    	return liquidaDAO.findLiquidacionesPendientePago(params);
    }
 // FIXME : P46 - FIN - RESTRICCION PARA DUAS IMPUGNADAS
    
    return liquidaDAO.findLiquidacionesPendientePago(params);
  }// RIN16

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> validarOrdeDepoPendPago(Map params) throws ServiceException
  {

	  String rlnumaso = StringUtils.leftPad((params.get("rlnumaso").toString().trim()), 6, "0");
    //convierte string se estaba cayendo por eso amancilla
        params.put("rlnumaso", rlnumaso);
        // FIXME : RIN 16 - Utilizando Routing Datasource
        ODepoCabDAO oDepoCabDAO = fabricaDeServicios.getService("diligencia.ingreso.routing.oDepoCabDef");
        DataSourceContextHolder.setKeyDataSource(params.get("rladuaso").toString().trim());
    return oDepoCabDAO.findPendPagoByDocumento(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerBolQuimicoSinConcluir(Map<String, Object> params) throws ServiceException
  {

    List<Map<String, Object>> res = new ArrayList<Map<String, Object>>();
    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + params.get("caduana").toString().trim()));
      Map<String, Object> parametros = new HashMap<String, Object>();
      parametros.put("cadua_solbq", params.get("COD_ADUANA"));
      parametros.put("nanno_solbq", params.get("ANN_PRESEN"));
      parametros.put("ncorr_solbq", params.get("NUM_DECLARACION"));
      parametros.put("creg_dua", params.get("COD_REGIMEN"));
      parametros.put("cod_estdilig", params.get("COD_TIPDILIG") != null ? (String) params.get("COD_TIPDILIG") : "03");
      res = this.tabBolQuimDAO.findPendConcluByDeclaracion(parametros);
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }

  public List<Map<String, Object>> validarLCPendPagoParaConclusionDespacho(Map<String, Object> params) throws ServiceException
  {
	  swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
		        + params.get("COD_ADUANA").toString().trim()));
	  
    String ann_presen_2d = (params.get("ANN_PRESEN").toString().trim()).substring(2);
    params.put("ANN_PRESEN_2D", ann_presen_2d);
    String num_corredoc_6c = StringUtils.leftPad((params.get("NUM_DECLARACION").toString().trim()), 6, "0");
    params.put("NUM_CORREDOC_6C", num_corredoc_6c);
    
    return liquidaDAO.selectLiquidacionesPendientePagoParaConclusionDespacho(params);
  }
  
  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerActasSinConcluir(Map<String, Object> params) throws ServiceException
  {
    List<Map<String, Object>> res = new ArrayList<Map<String, Object>>();
    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + params.get("caduana").toString().trim()));
      Map<String, Object> parametros = new HashMap<String, Object>();
      parametros.put("ccodi_regim", params.get("COD_REGIMEN"));
      parametros.put("cadua_dua", params.get("COD_ADUANA"));
      parametros.put("fanno_dua", params.get("ANN_PRESEN"));
      parametros.put("ncorr_dua", params.get("NUM_DECLARACION"));
      parametros.put("ctipo_acta", "AM");// inmovilizacion

      List<Map<String, Object>> lista = this.cabActasDAO
          .joinMovDuasActasFindActaInmovilizacionByDeclaracion(parametros);

      List ctipo_seguim = new ArrayList();
      ctipo_seguim.add("10");
      ctipo_seguim.add("17");

      for (Map<String, Object> mapa : lista)
      {
        parametros = new HashMap<String, Object>();
        parametros.put("ctdoc_preco", mapa.get("CTDOC_PRECO"));
        parametros.put("cadua_preco", params.get("COD_ADUANA"));
        parametros.put("cptoc_preco", "CPTOC_PRECO");
        parametros.put("fanno_preco", params.get("ANN_PRESEN"));
        parametros.put("ncorr_preco", params.get("NUM_DECLARACION"));
        parametros.put("ctipo_seguim", ctipo_seguim);
        res.addAll(this.cabActasDAO.findActaVerificacionByDeclaracion(parametros));
      }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(this, e);
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public List listarDocuTrans(Map params) throws ServiceException
  {
    return this.docuTransDAO.listByParameterMap(params);
  }

  /**
   * {@inheritDoc}
   */
  public List<Map<String, Object>> obtenerDocRef(Map PkDecla) throws ServiceException
  {


    List<Map<String, Object>> lista = null;
    List<Map<String, Object>> listaDocumentos = new ArrayList<Map<String, Object>>();
    Map<String, Object> mapParams = new HashMap<String, Object>();

    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + PkDecla.get("caduana").toString().trim()));

      if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(PkDecla.get("COD_REGIMEN").toString()))
      {
        PkDecla.put("O_TIPO", "17");
      }
      else if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals(PkDecla.get("COD_REGIMEN").toString()))
      {
        PkDecla.put("O_TIPO", "32");
      }
      else if (Constantes.REGIMEN_70_DEPOSITO.equals(PkDecla.get("COD_REGIMEN").toString()))
      {
        PkDecla.put("O_TIPO", "40");
      }
      else if (Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals(PkDecla.get("COD_REGIMEN").toString()))
      {
        PkDecla.put("O_TIPO", "7");
      }

      lista = expediDAO.findByDeclaracion(PkDecla);

      if (!CollectionUtils.isEmpty(lista))
      {
        listaDocumentos.addAll(lista);
        lista = null;
      }
      // Liquidaciones
      mapParams.put("", "");
      lista = liquidaDAO.findByDeclaracion(PkDecla);

      if (!CollectionUtils.isEmpty(lista))
      {
        listaDocumentos.addAll(lista);
        lista = null;
      }
      // Boletin Quimico
      lista = tabBolQuimDAO.findByDeclaracion(PkDecla);

      if (!CollectionUtils.isEmpty(lista))
      {
        listaDocumentos.addAll(lista);
        lista = null;
      }
      // CabActas
        //  lista = cabActasDAO.findByDeclaracion(PkDecla);
          String  codigo_aduana = Constantes.COD_ADUANA_CENTRAL;
          lista =this.listaCabactas(PkDecla,codigo_aduana);

      if (!CollectionUtils.isEmpty(lista))
      {
        listaDocumentos.addAll(lista);
        lista = null;
      }

    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return listaDocumentos;
  }

  
 
  /**
   * {@inheritDoc}
   */
   //inicio PASE176
  public List<Map<String, Object>> obtenerLiquidacionesCobranza(Map PkDecla) throws ServiceException
  {
    List<Map<String, Object>> listaLiqCobranza = new ArrayList<Map<String, Object>>();    
    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + PkDecla.get("caduana").toString().trim()));
      listaLiqCobranza = liquidaDAO.getListaLiquidacionesCobranzaDUA(PkDecla);     
      
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return listaLiqCobranza;
  }
  
  public List<Map<String, Object>> obtenerLiquidacionesCobranzaGarantizadosSinGarantizar(String annPresenAfecta,List<Map<String, Object>> listaLiquidacionesCobranza,List<Map<String, Object>> listaDeudaGarantia159,List<Map<String, Object>> listaMovDeudaGaranatia160 ) throws ServiceException
  {
    
	 List<Map<String, Object>> listaLiqCobranzaActual = new ArrayList<Map<String, Object>>();
    String estado="";
	String cod_documento="";
	Map<String, Object> lcGarantizado160 = null;
	Map<String, Object> lcGarantizado159 = null;
	boolean  garantizado160=false;
	boolean  estadoCancelado=false;
    try
    {    if(!CollectionUtils.isEmpty(listaLiquidacionesCobranza)) {     
		      for (Map<String, Object> lcliquida : listaLiquidacionesCobranza) {			    	  
			    	  estado=lcliquida.get("CODESTADO").toString();
			    	  cod_documento=lcliquida.get("RLADUANA").toString().concat(annPresenAfecta.concat(lcliquida.get("RLREGIMEN").toString())).concat(lcliquida.get("RLNUMASO").toString());
			    	  //Estado Cancelado
			    	  if (SunatStringUtils.include(estado, new String[]{"33","10","2","1","3","15"}) && (lcliquida.get("RLFECELI").toString().equals("0")) ) {
						  lcliquida.put("ESTADO", "CANCELADO");	
						  estadoCancelado=true;					  
			    	  }
			    	  else {  estadoCancelado=false;}
			    	  //Estado ANULADO 	  
					   if (!lcliquida.get("RLFECELI").toString().equals("0")){
							    lcliquida.put("ESTADO", "ANULADO");							    
					   }
					   Map<String, Object> parametroGaran = new HashMap<String, Object>();
					   ///Garantia 160					   
					   if(!CollectionUtils.isEmpty(listaMovDeudaGaranatia160)){
							for (Map<String, Object> lcliquidagarantia160 : listaMovDeudaGaranatia160) {
								if ( lcliquidagarantia160.get("COD_NUMAFECTA").equals(lcliquida.get("RLNROLIQ")) &&
								   lcliquidagarantia160.get("COD_DOCUMENTO").equals(cod_documento))
								  	{	if (estadoCancelado){
								  		    lcGarantizado160 = new HashMap<String, Object>();
								  		    listaLiqCobranzaActual.add(maplcGarantizado(lcGarantizado160,lcliquida,lcliquidagarantia160.get("FEC_AFECTACION")));
										}
										else {
											lcliquida.put("FECHA_CANC", lcliquidagarantia160.get("FEC_AFECTACION")); 
										} 
									garantizado160=true;									
									break;
							   	}
							}
					     }
					   
					   //Garantia 159			    	  
					   if (!garantizado160 && !CollectionUtils.isEmpty(listaDeudaGarantia159)) {
						     for (Map<String, Object> lcliquidagarantia159 : listaDeudaGarantia159) {			    		  
						    	 if ( lcliquidagarantia159.get("CADUA_DOCAFI").equals(lcliquida.get("RLADUANA"))  &&  lcliquidagarantia159.get("FANNO_DOCAFI").equals(annPresenAfecta) &&
						    		  lcliquidagarantia159.get("NUME_DOCAFI").equals(lcliquida.get("RLNROLIQ")))
						    		 {
						    		 if (estadoCancelado){
						    			 lcGarantizado159 = new HashMap<String, Object>();
						    			 listaLiqCobranzaActual.add(maplcGarantizado(lcGarantizado159,lcliquida,lcliquidagarantia159.get("FECHA_INIVIG")));
						    		 
						    		 }
						    		 else {
						    			 lcliquida.put("FECHA_CANC", lcliquidagarantia159.get("FECHA_INIVIG"));
						    		 }						    		 
						    		 break;
						    		 }
						    }   
					   }    
					 		    	  
			   listaLiqCobranzaActual.add(lcliquida);	  
		 }
		 }
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    return listaLiqCobranzaActual;
  }
  
  public Map<String, Object> maplcGarantizado (Map<String, Object> lcliquidagarantia, Map<String, Object> lcliquida,Object Fecha) throws ServiceException
  {	  lcliquidagarantia.put("NUMERO",lcliquida.get("NUMERO"));
	  lcliquidagarantia.put("TIPO",lcliquida.get("TIPO"));
	  lcliquidagarantia.put("FECHA_LIQ",lcliquida.get("FECHA_LIQ"));
	  lcliquidagarantia.put("FECHA_NOTIF",lcliquida.get("FECHA_NOTIF"));
	  lcliquidagarantia.put("FECHA_ULTDIACANC",lcliquida.get("FECHA_ULTDIACANC"));
	  lcliquidagarantia.put("FECHA_CANC", Fecha); 
	  lcliquidagarantia.put("RLCODMON", lcliquida.get("RLCODMON"));
		if (lcliquida.get("RLCODMON").equals("S")){
			lcliquidagarantia.put("RLSMONTOT", 0);
		}
		else {
			lcliquidagarantia.put("RLDMONTOT", 0);
		}											
		lcliquidagarantia.put("ESTADO", "GARANTIZADO ART. 160");
	  return lcliquidagarantia;
}
   
  
  
 //fin PASE176
	private synchronized List<Map<String, Object>> listaCabactas (Map<String,Object> PkDecla, String codaduanaConex){
		Object o = swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + codaduanaConex)); 
		 List<Map<String, Object>> lista = null;
		 lista = cabActasDAO.findByDeclaracion(PkDecla);
		 swapperDatasource.swap(o);
	     return lista;
	}
    
  

  /**
   * {@inheritDoc}
   */
  public List<Expedi> obtenerExpedi(Map<String, Object> PkDecla) throws ServiceException
  {
    List<Expedi> lista = new ArrayList<Expedi>();

    try
    {
      swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE
          + PkDecla.get("COD_ADUANA").toString().trim()));

      // Expedientes
      Expedi expedi = new Expedi();
      expedi.setoTipo(17);
      expedi.setoAnno(PkDecla.get("ANN_PRESEN").toString());
      expedi.setoNro(Integer.valueOf(PkDecla.get("NUM_DECLARACION").toString()));
      expedi.setCodiAdua(PkDecla.get("COD_ADUANA").toString());
      lista = expediDAO.selectByDocumento(expedi);
    }
    catch (DataAccessException e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }
    catch (Exception e)
    {
      log.error("*** ERROR ***", e);
      throw new ServiceException(e, e.getMessage());
    }

    return lista;
  }

  
  public synchronized List<Map>  obtenerActasByDua(Map<String, Object> params){
	  Object o = swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + ConstantesDataCatalogo.ADUANA_CENTRALIZADA)); 
	  CabActasDAO  cabActasDAO = (CabActasDAO) fabricaDeServicios.getService("prevcontrabando2.operativo.cabActasDAO");
	  List<Map> listactas = cabActasDAO.joinMovDuaActasByDUA(params);
	  swapperDatasource.swap(o);
	  return listactas;
  }


  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerAccionesDeControlExtraordinario(Map<String, Object> parametros)
  {
    String tmpNumDocTransp;
    String tmpNumDocTranspMaster;

    List<Map<String, Object>> detailRows = (List<Map<String, Object>>) parametros.get("LIST_SERIES");

    List<Map> duaactas = this.cabActasDAO.joinMovDuaActasByDUA(parametros);    
    List<Map<String, Object>> duaActasPF = getAceAsociadosDua(parametros); //PAS20165E220200127
    List<Map> soloActasDua = new ArrayList<Map>();
    if (!CollectionUtils.isEmpty(duaactas))
      soloActasDua = new ArrayList<Map>(duaactas);
	//PAS20165E220200127
    List<Map> soloActasDuaPF = new ArrayList<Map>();
    if (!CollectionUtils.isEmpty(duaActasPF)){
        for (Map row : duaActasPF)
        {	//00 es en proceso
          if("00".equals(row.get("CESTADO_ACTA")) || "01".equals(row.get("CESTADO_ACTA"))){	
    	    soloActasDuaPF.addAll(duaActasPF);
          }
        }
	}
	//Fin PAS20165E220200127
    // Se valida los documentos de transporte Master o Hijo, para identificar
    // las actas asociadas al manifiesto
    List<String> numDocsTransps = new ArrayList<String>();
    for (Map<String, Object> row : detailRows)
    {
      tmpNumDocTransp = row.get("NUM_DOCTRANSP") != null ? row.get("NUM_DOCTRANSP").toString() : "";
      tmpNumDocTranspMaster = row.get("NUM_DOCTRANSPMASTER") != null ? row.get("NUM_DOCTRANSPMASTER").toString() : "";
      tmpNumDocTransp = tmpNumDocTransp.trim();
      tmpNumDocTranspMaster = tmpNumDocTranspMaster.trim();
      if (!"".equals(tmpNumDocTransp) && !numDocsTransps.contains(tmpNumDocTransp))
      {
        numDocsTransps.add(tmpNumDocTransp);
      }
      if (!"".equals(tmpNumDocTranspMaster) && !numDocsTransps.contains(tmpNumDocTranspMaster))
      {
        numDocsTransps.add(tmpNumDocTranspMaster);
      }
    }
    parametros.put("NUM_DOCTRANS", numDocsTransps);
    List<Map> manifiestoactas = new ArrayList<Map>();
    List<Map> avisosinspeccion = new ArrayList<Map>();
    if (!CollectionUtils.isEmpty(numDocsTransps))
    {
      manifiestoactas = this.cabActasDAO.joinMovManifiestoActasByDocTransporte(parametros);
      duaactas.addAll(manifiestoactas);

      // uery que implementa avisos inspeccion a revisar no se
      // reemplazo pq este se usa en numeracion
      // y consulta de levante ver el metodo getAvisosInspeccion
      avisosinspeccion = this.datAuxActaDAO.findAvisoInspeccionByManifiesto(parametros);
    }

    // Acta de Inmovilizacion o Incautacion
    List<Map> actasinmovilizacion = new ArrayList<Map>();
    List<Map> aces = new ArrayList<Map>();
    for (Map row : duaactas)
    {
      Map accioncontrol = new HashMap();
      accioncontrol.put("ACE", row.get("DESCRIPCION"));
      accioncontrol.put("NRO", row.get("NROFULL"));
	  //INICIO JMCV
      accioncontrol.put("NROCORTO", row.get("NROCORTO"));
      //FIN JMCV
      aces.add(accioncontrol);
      if (row.get("CTIPO_ACTA").equals("AM"))
      {
        actasinmovilizacion.add(row);
      }
    }

    // Aviso de Inspeccion
    for (Map row : avisosinspeccion)
    {
      Map accioncontrol = new HashMap();
      accioncontrol.put("ACE", row.get("DESCRIPCION"));
      accioncontrol.put("NRO", row.get("NROFULL"));
	  //INICIO JMCV
      accioncontrol.put("NROCORTO", row.get("NROCORTO"));
      //FIN JMCV
      aces.add(accioncontrol);
    }
    
    // ACE PAS20165E220200127
    for (Map row : duaActasPF)
    {	//00 es en proceso
      if("00".equals(row.get("CESTADO_ACTA")) || "01".equals(row.get("CESTADO_ACTA"))){	
      Map accioncontrol = new HashMap();
      accioncontrol.put("ACE", " ACE");
      accioncontrol.put("NRO", row.get("CTDOC_PRECO")+" - "+row.get("CADUA_DUA") +" - "+row.get("CPTOC_PRECO")+" - "+row.get("FANNO_PRECO")+" - "+row.get("NCORR_PRECO"));
      accioncontrol.put("NROCORTO", "LA DUA TIENE ACE");
      aces.add(accioncontrol);
    	}
    }
	//Fin PAS20165E220200127
    if (aces.size() > 0)
    {
      Collections.sort(aces, new Comparator<Map>()
      {
        @Override
        public int compare(Map thiss, Map that)
        {
          return thiss.get("ACE").toString().compareTo(that.get("ACE").toString());
        }
      });
    }

    Map<String, Object> response = new HashMap<String, Object>();
    response.put("aces", aces);
    response.put("actasinmovilizacion", actasinmovilizacion);
    response.put("duaactas", duaactas);
    response.put("manifiestoactas", manifiestoactas);
    response.put("avisosinspeccion", avisosinspeccion);
    response.put("soloActasDua", soloActasDua);
    response.put("soloActasDuaPF", soloActasDuaPF);//PAS20165E220200127

    return response;
  }


/*RIN13FSW-INICIO*/
  
  public NandTasa obtenerTasaNandinaByPartida(String codAduanaSwapper,
          Long numPartNandi,
          Date fechaVigencia){
	  
	 return  obtenerTasaNandinaByPartida(codAduanaSwapper,numPartNandi,fechaVigencia,"");
  }
     /*RIN13FSW-FIN*/     
  /**
   * {@inheritDoc}
   */
  public NandTasa obtenerTasaNandinaByPartida(String codAduanaSwapper,
                                              Long numPartNandi,
                                              Date fechaVigencia, String tnan)
  {

    Map params = new HashMap();
    params.put("COD_ADUANA", codAduanaSwapper);
    params.put("cnan", numPartNandi);
    params.put("ffintas", SunatDateUtils.getIntegerFromDate(fechaVigencia));

//cambio RIN13-FSW

    if(!SunatStringUtils.isEmpty(tnan.trim())){
    	params.put("tnan",tnan);	
    }
    
        
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
                                                         + codAduanaSwapper));

    NandTasa nandTasa = new NandTasa();
    List<NandTasa> lstNandTasas = nandTasaDAO.findNandtasaByParams(params);
    if (org.apache.commons.collections.CollectionUtils.isNotEmpty(lstNandTasas))
    {
      nandTasa = lstNandTasas.get(0);
    }

    return nandTasa;
  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public NandTasa obtenerTasaNandinaByPartida(Map<String, Object> params) throws ServiceException
  {
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + params.get("COD_ADUANA")));
    List<NandTasa> lstNandTasas = nandTasaDAO.findNandtasaByParams(params);
    NandTasa nandTasa = new NandTasa();
    if (!CollectionUtils.isEmpty(lstNandTasas))
    {
      nandTasa = lstNandTasas.get(0);
    }
    return nandTasa;
  }

  /**
   * {@inheritDoc}
   */
  public int existePartidaNandina(Map<String, Object> params) throws ServiceException
  {
//    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
//        + params.get("COD_ADUANA")));
    
//    DataSourceContextHolder.setKeyDataSource(String.valueOf(params.get("COD_ADUANA")));//gmontoya rest
//    
	Integer contNandina = (Integer)ayudaService.countNandina(params);
    //return nandinaDAO.count(params);
    
    return contNandina;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> validaUnidadMedidaFisicas(Map<String, Object> params) throws ServiceException
  {
    int iConteo = 0;
    BigDecimal margen = new BigDecimal(0.0001);
    Map<String, Object> mapResultado = new HashMap<String, Object>();
    List<Map<String, Object>> listaUnidadesVigentes = null;
//    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
//        + params.get("COD_ADUANA")));}
    DataSourceContextHolder.setKeyDataSource(String.valueOf(params.get("COD_ADUANA")));//gmontoya rest
//    iConteo = nandUniDAO.getNumeroVigentesByMap(params);
    iConteo = ayudaService.getNumeroVigentesByMap(params);
    if (iConteo == 0)
    {
//      listaUnidadesVigentes = nandUniDAO.getListVigentesByMap(params);
      listaUnidadesVigentes = ayudaService.getListVigentesByMap(params);
      mapResultado.put("validaUnidadFisica", "0");
      if (CollectionUtils.isEmpty(listaUnidadesVigentes))
      {
        mapResultado.put("mensaje", "La Unidad seleccionada no esta permitida para la Partida ingresada.");
      }
      else
      {
        StringBuilder cadena = new StringBuilder("");
        for (Map<String, Object> mapa : listaUnidadesVigentes)
        {
          if ("".equals(cadena.toString().trim()))
          {
            cadena
                .append("[")
                .append(mapa.get("UNI").toString())
                .append("] ")
                .append(catalogoAyudaService.getDescripcionDataCatalogo("29", mapa.get("UNI").toString()));
          }
          else
          {
            cadena
                .append(", ")
                .append("[")
                .append(mapa.get("UNI").toString())
                .append("] ")
                .append(catalogoAyudaService.getDescripcionDataCatalogo("29", mapa.get("UNI").toString()));
          }
        }
        mapResultado.put("mensaje",
            "La Unidad seleccionada no esta permitida para la Partida ingresada. Las unidades permitidas son: "
                + cadena.toString() + ".");
      }

    }
    else if (iConteo > 0)
    {
      if ("KG".equals(params.get("COD_UNIFISICA").toString().trim()))
      {
        if (SunatNumberUtils.isEqual(new BigDecimal(params.get("CNT_UNIFIS").toString().trim()), new BigDecimal(params
            .get("CNT_PESO_NETO").toString().trim())))
        {
          mapResultado.put("validaUnidadFisica", "");
          mapResultado.put("mensaje", "");
        }
        else
        {
          mapResultado.put("validaUnidadFisica", "-1");
          mapResultado.put("mensaje", "La cantidad de Unidades Fisicas debe ser igual al Peso Neto.");
        }
      }
      else if ("KG3".equals(params.get("COD_UNIFISICA").toString().trim()))
      {
        BigDecimal dif = SunatNumberUtils.absoluteDiference(((new BigDecimal(params.get("CNT_PESO_NETO").toString()))
            .divide(new BigDecimal(1000))), new BigDecimal(params.get("CNT_UNIFIS").toString()));
        if (!SunatNumberUtils.isLessThanParam(dif, margen))
        {
          mapResultado.put("validaUnidadFisica", "-1");
          mapResultado
              .put(
                  "mensaje",
                    "Verifique el numero de UNIDADES FISICAS con respecto al Peso Neto. Considere la formula 'UNIDADES FISICAS' = ROUND('PESO NETO'/ 1 000 ,3)");
        }
        else
        {
          mapResultado.put("validaUnidadFisica", "");
          mapResultado.put("mensaje", "");
        }
      }
      else if ("KG6".equals(params.get("COD_UNIFISICA").toString().trim()))
      {
        BigDecimal dif = SunatNumberUtils.absoluteDiference(((new BigDecimal(params.get("CNT_PESO_NETO").toString()))
            .divide(new BigDecimal(1000000))), new BigDecimal(params.get("CNT_UNIFIS").toString()));
        if (!SunatNumberUtils.isLessThanParam(dif, margen))
        {
          mapResultado.put("validaUnidadFisica", "-1");
          mapResultado
              .put(
                  "mensaje",
                    "Verifique el numero de UNIDADES FISICAS con respecto al Peso Neto. Considere la formula 'UNIDADES FISICAS' = ROUND('PESO NETO'/1 000 000,3)");
        }
        else
        {
          mapResultado.put("validaUnidadFisica", "");
          mapResultado.put("mensaje", "");
        }
      }
      else
      {
        mapResultado.put("validaUnidadFisica", "");
        mapResultado.put("mensaje", "");
      }
    }
    
    //RIN13-FSW AMANCILLA VALIDACION DEL TNAN
    String partida = params.get("CNAN").toString();
    String codAduana = params.get("COD_ADUANA").toString();
    String tnanSeleccionado = params.get("COD_TIPTASAAPLICAR")!=null?params.get("COD_TIPTASAAPLICAR").toString().trim():"";
    //FechaBean fechaBean = new FechaBean((java.sql.Timestamp) params.get("FEC_DECLARACION"));
    String fecDeclaracion =params.get("FEC_DECLARACION").toString();
    boolean tnanvalido = false;      		 
    Map<String, Object> params2 = new HashMap<String, Object>();
    params2.put("COD_ADUANA", codAduana);
    params2.put("partida", partida);
    params2.put("finicio", fecDeclaracion);
    params2.put("ffin", fecDeclaracion);
    int existePartida = existePartidaNandina(params2);
    List<Map> lstTNAN = new ArrayList();
    if (existePartida == 1)// si existe
    {     
      lstTNAN = obtenerLstTasaNAN(partida, fecDeclaracion);
    }
    if(!CollectionUtils.isEmpty(lstTNAN)){
    	for(Map maptnan : lstTNAN){
    		String tnan = maptnan.get("tnan").toString().trim();
    		if(tnanSeleccionado.equals(tnan)){
    			tnanvalido=true;
    			break;
    		}
    	}
    }
     
    if(tnanvalido==false){
    	 mapResultado.put("validaUnidadFisica", "-1");
    	 
    	 String mensaje = mapResultado.get("mensaje").toString().trim();
    	 if(StringUtils.isNotBlank(mensaje)){
    		 mensaje = mensaje.concat(", debe seleccionar tipo de tasa a aplicar TNAN.");
    	 }else{
    		 mensaje = "Debe seleccionar tipo de tasa a aplicar TNAN.";	 
    	 }
    	 mapResultado.put("mensaje", mensaje);
    }
    //fin RIN13-FSW validacion de TNAN
    return mapResultado;
  }

 
  
  /**
   * {@inheritDoc}
   */
  public List<TabLibe> obtenerTabLibeByParams(Map<String, Object> params) throws ServiceException
  {
    try
    {
//    	swapperDatasourceTabLib.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
//        + params.get("COD_ADUANA")));
    	DataSourceContextHolder.setKeyDataSource(String.valueOf(params.get("COD_ADUANA")));//bug18551 rin16
//      return tabLibeDAO.helpTabLibeByParams(params);
//RIN13fsw AMANCILLA mas facil es modificar que invalidar el bug jajaj

        List<TabLibe> lstLibeResul = new ArrayList<TabLibe>();
        List<TabLibe> lstLibe = tabLibeDAOService.helpTabLibeByParams(params);
        if(!CollectionUtils.isEmpty(lstLibe)){
            //Revertimos cambios hasta nuevo aviso, afecta la Diligencia de conclsuion
        	/*for(TabLibe libe : lstLibe){
            	//amancilla se quita espacion en blanco para que se vea en los JSP PAS20155E220200035
            	String codigo = libe.getClib().trim();
                String codigoDesc = codigo+"-"+libe.getDlib().trim();
                libe.setDlib(codigoDesc);
                libe.setClib(codigo);
                lstLibeResul.add(libe);
            }*/
            for(TabLibe libe : lstLibe){
                String codigoDesc = libe.getClib()+"-"+libe.getDlib();
                libe.setDlib(codigoDesc);
                lstLibeResul.add(libe);
            }
        }

    return lstLibeResul;
    }
    catch (DataAccessException e)
    {

      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Ha ocurrido un error al seleccionar registros en la tabla Tablibe");
    }
    catch (Throwable e)
    {

      log.error("*** ERROR ***", e);
      throw new ServiceException(this, "Ha ocurrido un error inseperado en el metodo");
    }
  }



  /**
   * {@inheritDoc}
   */
  public String obtenerSgteDiaUtil(Map<String, Object> params) throws ServiceException
  {
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + params.get("COD_ADUANA")));

//    String ultimoDia = this.calculaDiaDAO.getFnCalculaDias(params);
    String ultimoDia = this.calculaDiaDAOService.getFnCalculaDias(params);
    return ultimoDia;
  }

  /**
   * {@inheritDoc}
   */
  public Date getMinDateFromList(List<Map<String, Object>> lst, String field)
  {
    Date fecMin = null;
    for (Map<String, Object> row : lst)
    {
      Date fecTemp = SunatDateUtils.getDateFromInteger(((BigDecimal) row.get(field)).intValue());
      if (fecMin == null)
      {
        fecMin = fecTemp;
        continue;
      }
      if (SunatDateUtils.esFecha1MenorQueFecha2(fecTemp, fecMin, SunatDateUtils.COMPARA_SOLO_FECHA))
      {
        fecMin = fecTemp;
      }

    }
    return fecMin;
  }

  /**
   * {@inheritDoc}
   */
  public void validarExpediente(Map<String, Object> params)
  {
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + params.get("COD_ADUANA")));
    List rows = expediDAO.findExpediRectificacionByDeclaracion(params);
    if (rows.size() == 0)
    {
      throw new ServiceException(this, "Expediente no se encuentra registrado, por favor verificar");
    }
  }

  /**
   * {@inheritDoc}
   */
  public boolean tieneExpedienteSustentoRectificacion(Map<String, Object> pkDecla)
  {

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
        + pkDecla.get("COD_ADUANA")));
    if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals(pkDecla.get("COD_REGIMEN").toString()))
    {
      pkDecla.put("TIPO", "17");
    }
    else if (Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO.equals(pkDecla.get("COD_REGIMEN").toString()))
    {
      pkDecla.put("TIPO", "32");
    }
    else if (Constantes.REGIMEN_70_DEPOSITO.equals(pkDecla.get("COD_REGIMEN").toString()))
    {
      pkDecla.put("TIPO", "40");
    }
    else if (Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO.equals(pkDecla.get("COD_REGIMEN").toString()))
    {
      pkDecla.put("TIPO", "7");
    }
    Integer rows = expediDAO.findCantExpediParaAnulacionRectificacion(pkDecla);
    if (rows == 0)
    {
      return false;
    }
    return true;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, Object> obtenerAccionesDeControlExtraordinario2(Map<String, Object> parametros)
  {
    String tmpNumDocTransp;
    String tmpNumDocTranspMaster;

    List<Map<String, Object>> detailRows = (List<Map<String, Object>>) parametros.get("LIST_SERIES");

    List<Map> duaactas = this.cabActasDAO.joinMovDuaActasByDUA(parametros);
    List<Map> soloActasDua = new ArrayList<Map>();
    if (!CollectionUtils.isEmpty(duaactas))
      soloActasDua = new ArrayList<Map>(duaactas);
    // Se valida los documentos de transporte Master o Hijo, para identificar
    // las actas asociadas al manifiesto
    List<String> numDocsTransps = new ArrayList<String>();
    for (Map<String, Object> row : detailRows)
    {
      tmpNumDocTransp = row.get("NUM_DOCTRANSP") != null ? row.get("NUM_DOCTRANSP").toString() : "";
      tmpNumDocTranspMaster = row.get("NUM_DOCTRANSPMASTER") != null ? row.get("NUM_DOCTRANSPMASTER").toString() : "";
      tmpNumDocTransp = tmpNumDocTransp.trim();
      tmpNumDocTranspMaster = tmpNumDocTranspMaster.trim();
      if (!"".equals(tmpNumDocTransp) && !numDocsTransps.contains(tmpNumDocTransp))
      {
        numDocsTransps.add(tmpNumDocTransp);
      }
      if (!"".equals(tmpNumDocTranspMaster) && !numDocsTransps.contains(tmpNumDocTranspMaster))
      {
        numDocsTransps.add(tmpNumDocTranspMaster);
      }
    }

    if (numDocsTransps.size()==0){
      numDocsTransps=null;
    }
    parametros.put("NUM_DOCTRANS", numDocsTransps);
    List<Map> manifiestoactas = this.cabActasDAO.joinMovManifiestoActasByDocTransporte(parametros);
    duaactas.addAll(manifiestoactas);

    String numCorreDocDua = parametros.get("NUM_CORREDOC").toString();
    Map<String, Object> mapPkManifiesto = new HashMap<String, Object>();
    mapPkManifiesto.put("COD_ADUAMANIFIESTO", parametros.get("COD_ADUAMANIFIESTO"));
    mapPkManifiesto.put("ANN_MANIFIESTO", parametros.get("ANN_MANIFIESTO"));
    mapPkManifiesto.put("NUM_MANIFIESTO", parametros.get("NUM_MANIFIESTO"));
    mapPkManifiesto.put("COD_VIATRANS", parametros.get("COD_VIATRANS"));

    List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDocDua);
    addPkManifiestoListaDocTransporte(listNumDoctrans, mapPkManifiesto);

    List<Map<String, Object>> avisosinspeccion = getAvisosInspeccion(listNumDoctrans);

    // Acta de Inmovilizacion o Incautacion
    List<Map> actasinmovilizacion = new ArrayList<Map>();
    List<Map> aces = new ArrayList<Map>();
    for (Map row : duaactas)
    {
      Map accioncontrol = new HashMap();
      accioncontrol.put("ACE", row.get("DESCRIPCION"));
      accioncontrol.put("NRO", row.get("NROFULL"));
      //INICIO JMCV
      accioncontrol.put("NROCORTO", row.get("NROCORTO"));
      //FIN JMCV
      aces.add(accioncontrol);
      if (row.get("CTIPO_ACTA").equals("AM"))
      {
        actasinmovilizacion.add(row);
      }
    }

    // Aviso de Inspeccion
    for (Map row : avisosinspeccion)
    {
      Map accioncontrol = new HashMap();
      accioncontrol.put("ACE", row.get("ACE"));
      accioncontrol.put("NRO", row.get("NRO"));
      aces.add(accioncontrol);
    }

    if (aces.size() > 0)
    {
      Collections.sort(aces, new Comparator<Map>()
      {
        @Override
        public int compare(Map thiss, Map that)
        {
          return thiss.get("ACE").toString().compareTo(that.get("ACE").toString());
        }
      });
    }

    Map<String, Object> response = new HashMap<String, Object>();
    response.put("aces", aces);
    response.put("actasinmovilizacion", actasinmovilizacion);
    response.put("duaactas", duaactas);
    response.put("manifiestoactas", manifiestoactas);
    response.put("avisosinspeccion", avisosinspeccion);
    response.put("soloActasDua", soloActasDua);

    return response;
  }

  /**
   * Gets the list doc transporte dua.
   *
   * @param numCorreDoc
   *          the num corre doc
   * @return the list doc transporte dua
   */
//incio EJHM
  public List<Map<String, Object>> getListDocTransporteDua(String numCorreDoc)
  //fin EJHM
  {

    Map<String, Object> mapaNumCorreDoc = new HashMap<String, Object>();
    mapaNumCorreDoc.put("NUM_CORREDOC", numCorreDoc);

    return detdeclaraDAO.findNumDocTranspByNumCorreDoc(mapaNumCorreDoc);
  }

  /**
   * Adds the pk manifiesto lista doc transporte.
   *
   * @param listNumDoctrans
   *          the list num doctrans
   * @param mapPkManifiesto
   *          the map pk manifiesto
   */
  private void addPkManifiestoListaDocTransporte(List<Map<String, Object>> listNumDoctrans,
    Map<String, Object> mapPkManifiesto)
  {

    // recorre la lista de documentos de transporte para analizar si tiene
    // actas
    if (!CollectionUtils.isEmpty(listNumDoctrans))
    {
      for (Map<String, Object> numDoctrans : listNumDoctrans)
      {

        numDoctrans.put("COD_ADUAMANIFIESTO", mapPkManifiesto.get("COD_ADUAMANIFIESTO").toString());
        numDoctrans.put("ANN_MANIFIESTO", mapPkManifiesto.get("ANN_MANIFIESTO").toString());
        numDoctrans.put("NUM_MANIFIESTO", mapPkManifiesto.get("NUM_MANIFIESTO").toString());
        numDoctrans.put("COD_VIATRANS", mapPkManifiesto.get("COD_VIATRANS").toString());

      //setea como string nun_detalle pq los querys ejecutan con string
        if (numDoctrans.containsKey("NUM_DETALLE"))	numDoctrans.put("NUM_DETALLE", numDoctrans.get("NUM_DETALLE").toString());

      }
    }
  }

  /**
   * Gets the avisos inspeccion.
   *
   * @param listNumDoctrans
   *          the list num doctrans
   * @return the avisos inspeccion
   */
//incio EJHM
  public List<Map<String, Object>> getAvisosInspeccion(List<Map<String, Object>> listNumDoctrans)
  // fin EJHM
  {

    List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
    for (Map<String, Object> mapNumDoctrans : listNumDoctrans)
    {
      Map<String, Object> mapAvisosInspeccion = getAvisosInspeccion(mapNumDoctrans);
      if (!CollectionUtils.isEmpty(mapAvisosInspeccion))
      {
        lstRspta.add(mapAvisosInspeccion);
      }
    }

    return lstRspta;
  }

  /**
   * Proceso : Metodo que obtiene con acta tipo aviso de inspeccion asociados a
   * la dua. por defecto ejecuta el store procedure en pram1
   *
   * @param mapaDocumentoTrans
   *          the mapa documento trans
   * @return the avisos inspeccion
   * @throws ServiceException
   *           the service exception
   * @autor: amancillaa
   */
  private Map<String, Object> getAvisosInspeccion(Map<String, Object> mapaDocumentoTrans) throws ServiceException
  {

    Map<String, Object> mapAviso = new HashMap<String, Object>();

    // Lista de parametros para invocar a la funcion
    // USAMTG00.pktd_td.fnValidarMedidaPreventiva
    String mensajeAviso = fnValidarMedidaPreventivaDAO.getValidarMedidaPreventiva(mapaDocumentoTrans);

    if (!(mensajeAviso.substring(0, 1).equals("2") && mensajeAviso.split("\\|").length == 1))
    {
      if (mensajeAviso.substring(0, 1).equals("1"))
      {
        // el retorno es "1: 1700 - 118 - 0300 - 2011 - 000092"

        // Formo el map con el nro del aviso de inspeccion
        // codigo de mensaje
        mapAviso.put("ACE", "AVISO DE INSPECCION");
        // nro de aviso de inspeccion
        mapAviso.put("NRO", mensajeAviso.split(":")[1].trim());
      }
    }

    return mapAviso;
  }

  /**
   * {@inheritDoc}
   */
  public List obtenerLstTasaNAN(String cnan, String fechavigencia)
  {
    List lstRsta = new ArrayList();
    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
            + Constantes.DEFAULT_COD_ADUANA));
    
    Map params = new HashMap();
    params.put("cnan", cnan);
    params.put("fechavigencia", fechavigencia);
    lstRsta = nandTasaDAO.findByMap(params);

    return lstRsta;
  }

/**INICIO-RIN13**/

  /**
   * {@inheritDoc}
   */
  public List obtenerLstTasaNAN(String cnan, String fechavigencia, String codigoAduana)
  {
	  swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
              + (!StringUtils.isEmpty(StringUtils.trimToEmpty(codigoAduana)) ? codigoAduana : Constantes.DEFAULT_COD_ADUANA)));
	  
	List lstRsta = new ArrayList();

    Map params = new HashMap();
    params.put("cnan", cnan);
    params.put("fechavigencia", fechavigencia);
    lstRsta = nandTasaDAO.findByMap(params);

    return lstRsta;
  }

/**FIN-RIN13**/

  /**
   * {@inheritDoc}
   */
  public boolean isExoneradoDua(Map<String, Object> params) throws ServiceException
  {

    swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ
                                                         + params.get("COD_ADUANA")));

    Integer i = this.resSpimDAO.getCount(params);
    return i > 0 ? true : false;
  }

  /**
   * {@inheritDoc}
   */
  public String obtenerAduana(HttpServletRequest request)
  {
    String res = "000";

    if (WebUtils.getSessionAttribute(request, "cAduana") != null)
    {
      res = (String) WebUtils.getSessionAttribute(request, "cAduana");
    }
    else
    {
      UsuarioBean bUsuario = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
      Map adu = catalogoAyudaService.getTabdep(bUsuario.getCodUO());
      if (log.isDebugEnabled())
      {
        log.debug("obtenerAduana : " + adu);
      }

      if (adu != null && adu.size() > 0)
      {
        if (adu.get("aduana") != null)
        {
          res = (String) adu.get("aduana");
        }
      }

      WebUtils.setSessionAttribute(request, "cAduana", res);
    }
    return res;
  }

  /**
   * {@inheritDoc}
   *
   **/
  public boolean tieneActasPrevParcial(Map<String, Object> pkDecla)
      throws ServiceException
  {
    boolean tiene = false;
    int num = movDuasActasDAO.countActasPrevParcial(pkDecla);
    if (num > 0)
    {
      tiene = true;
    }
    return tiene;
  }
  
  //inicio gmontoya P24
  @Override
  public Map<String, Object> getDocumentosDUA(String numCorreDoc, Map<String, Object> mapPkDua) throws ServiceException{

      Map<String, Object> mapRspta = new HashMap<String, Object>();
      //validamos datos de entrada
      if (CollectionUtils.isEmpty(mapPkDua)
              || SunatStringUtils.isEmpty(numCorreDoc)) {
          return mapRspta;
      }
    //inicio gmontoya Pase 99 2016
      List<Map<String, Object>> listaExpedi = new ArrayList<Map<String, Object>>();
      listaExpedi = getExpedientesAsociadoDua(mapPkDua);
      if(mapPkDua.get("COD_ADUDEST")!=null && !mapPkDua.get("COD_ADUDEST").toString().trim().isEmpty()) {
    	  listaExpedi.addAll(getExpedientesAsociadoDuaPECO(mapPkDua));
      }
      mapRspta.put("listExpediDua", listaExpedi);
    //fin gmontoya Pase 99 2016

      DocumentoInternoService documentoInternoService = fabricaDeServicios.getService("tramite.DocumentoInternoService");
      Map<String, Object> mapPkDuaDI = new HashMap<String, Object>();
      mapPkDuaDI.put("codi_adua", mapPkDua.get("COD_ADUANA"));
      mapPkDuaDI.put("annoref", mapPkDua.get("ANN_PRESEN").toString());
      mapPkDuaDI.put("numeref", mapPkDua.get("NUM_DECLARACION"));
      //GGRANADOS_RECTI INI
      //gmontoya P24 INICIO
      String codRegimen = mapPkDua.get("COD_REGIMEN")!=null?mapPkDua.get("COD_REGIMEN").toString():"";        
      if(codRegimen.equals("10")) {
    	  mapPkDuaDI.put("tiporef","17");
      }else if(codRegimen.equals("20")){
    	  mapPkDuaDI.put("tiporef","32");
      }else if(codRegimen.equals("21")){
    	  mapPkDuaDI.put("tiporef","7");
      }else if(codRegimen.equals("70")){
    	  mapPkDuaDI.put("tiporef","40");
      }else{
    	  mapPkDuaDI.put("tiporef", mapPkDua.get("COD_REGIMEN"));
      }
      mapRspta.put("listDocIntDua",documentoInternoService.obtenerDocumentosInternosDUA(mapPkDuaDI));
      //P24-II Inicio -
      List<Map<String, Object>> listActasDua = new ArrayList<Map<String, Object>>();
      List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDoc);
      listActasDua.addAll(cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua));
      List<Map<String, Object>> listActasACE = new ArrayList<Map<String, Object>>();
      listActasACE = getAceAsociadosDua(mapPkDua);
      if (!CollectionUtils.isEmpty(listActasACE)){
    	  for(Map<String, Object> mapACE : listActasACE) {
    		  mapACE.put("TIPO", "ACE");
    		  mapACE.put("NUMERO", mapACE.get("CPTOC_PRECO").toString().concat("-").concat(mapACE.get("CADUA_PRECO").toString()).concat("-").concat(mapACE.get("FANNO_PRECO").toString()).concat("-").concat(mapACE.get("NCORR_PRECO").toString()));
    		  mapACE.put("INDICADOR","-");
    		  if (mapACE.get("CESTADO_ACTA").toString().equalsIgnoreCase("00")){
    			  mapACE.put("ESTADO","ACTA REGISTRADA");
    		  }
    		  else if(mapACE.get("CESTADO_ACTA").toString().equalsIgnoreCase("01")){
    			  mapACE.put("ESTADO","ACTA REGISTRADA DENTRO DEL PLAZO");
    		  }
    		  else if(mapACE.get("CESTADO_ACTA").toString().equalsIgnoreCase("02")){
    			  mapACE.put("ESTADO","ACTA REGISTRADA TERMINADO EL PLAZO");
    		  }
    		  else if(mapACE.get("CESTADO_ACTA").toString().equalsIgnoreCase("03")){
    			  mapACE.put("ESTADO","ACTA REGISTRADA CON PRORROGA");
    		  }
    		  else{
    			  mapACE.put("ESTADO","-");
    		  }
    		}
      }
      listActasDua.addAll(listActasACE);
      //P24-II Fin
      mapRspta.put("listActasDua", listActasDua);
      return mapRspta;
  }
//fin gmontoya P24
//inicio P21-P22

   /**
     * {@inheritDoc}
     */
    public Map<String, Object> getAllActasAndExpedientes(String numCorreDoc,
              Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException{

          Map<String, Object> mapRspta = new HashMap<String, Object>();
          //validamos datos de entrada
          if (CollectionUtils.isEmpty(mapPkManifiesto)
                  || CollectionUtils.isEmpty(mapPkDua)
                  || SunatStringUtils.isEmpty(numCorreDoc)) {
              return mapRspta;
          }

          //obtenemos los documentos de transporte de la dua
          List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDoc);
          addPkManifiestoListaDocTransporte(listNumDoctrans,mapPkManifiesto);

          mapRspta.put("listExpediDua", getExpedientesAsociadoDua(mapPkDua));
          // RIN15 - INICIO
          mapRspta.putAll(getAllActasDuaManifiesto(numCorreDoc, mapPkManifiesto, mapPkDua));
          // RIN15 - FIN
          mapRspta.put("listActasDua", cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua));
          mapRspta.put("listAceDua", getAceAsociadosDua(mapPkDua));
          mapRspta.put("lstAvisosInspeccionDocTransporte", getAvisosInspeccion(listNumDoctrans));
          mapRspta.put("listActasDocTransporte", getActasAsociadosDocTransporte(listNumDoctrans));
          mapRspta.put("listAceDocTransporte", getAceAsociadosDocTransporte(listNumDoctrans));

          return mapRspta;
      }

    //inicio P21-P22
    public Map<String, Object> obtenerTodasActasConclusionDespacho(String numCorreDoc,
            Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException{

        Map<String, Object> mapRspta = new HashMap<String, Object>();
        if (CollectionUtils.isEmpty(mapPkManifiesto)
                || CollectionUtils.isEmpty(mapPkDua)
                || SunatStringUtils.isEmpty(numCorreDoc)) {
            return mapRspta;
        }

        //obtenemos los documentos de transporte de la dua
        List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDoc);
        addPkManifiestoListaDocTransporte(listNumDoctrans,mapPkManifiesto);        mapRspta.put("listActasDua", cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua));
        mapRspta.put("listAceDua", getAceAsociadosDua(mapPkDua));
        mapRspta.put("listActasVerificacionConDua", getActasVerificacionConDUA(mapPkDua)); 
        mapRspta.put("listBoletinesQuimicosRatificadoNoRatificado", getBoletinesQuimicosRatificadoNoRatificado(mapPkDua));        
        mapRspta.put("mapActasAceAsociadosDocTransporte", getActasAvisosInspeccionAsociadosDocTransporte(mapPkManifiesto,listNumDoctrans));
        
        return mapRspta;
    }
    //fin P21-P22
    

    // RIN15 - INICIO
    /**
     * {@inheritDoc}
     */
    public Map<String, Object> getAllActasDuaManifiesto(String numCorreDoc,
              Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException{

          Map<String, Object> mapRspta = new HashMap<String, Object>();
          //validamos datos de entrada
          if (CollectionUtils.isEmpty(mapPkManifiesto)
                  || CollectionUtils.isEmpty(mapPkDua)
                  || SunatStringUtils.isEmpty(numCorreDoc)) {
              return mapRspta;
          }

          //obtenemos los documentos de transporte de la dua
          List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDoc);
          addPkManifiestoListaDocTransporte(listNumDoctrans,mapPkManifiesto);

          mapRspta.put("listActasDua", cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua));
          mapRspta.put("listAceDua", getAceAsociadosDua(mapPkDua));
          mapRspta.put("lstAvisosInspeccionDocTransporte", getAvisosInspeccion(listNumDoctrans));
          mapRspta.put("listActasDocTransporte", getActasAsociadosDocTransporte(listNumDoctrans));
          mapRspta.put("listAceDocTransporte", getAceAsociadosDocTransporte(listNumDoctrans));

          return mapRspta;
      }
    // RIN15 - FIN

    //RIN16-CUS 11.03 - Inicio/ 
    public Map<String, Object> getAllActasAndExpedientesForDeclaParaRegul (String numCorreDoc,
            Map<String, Object> mapPkManifiesto, Map<String, Object> mapPkDua) throws ServiceException{

        Map<String, Object> mapRspta = new HashMap<String, Object>();
        //validamos datos de entrada
        if (CollectionUtils.isEmpty(mapPkManifiesto)
                || CollectionUtils.isEmpty(mapPkDua)
                || SunatStringUtils.isEmpty(numCorreDoc)) {
            return mapRspta;
        }

        //obtenemos los documentos de transporte de la dua
        List<Map<String, Object>> listNumDoctrans = getListDocTransporteDua(numCorreDoc);
        addPkManifiestoListaDocTransporte(listNumDoctrans,mapPkManifiesto);
        //Expedientes asociados
        mapRspta.put("listExpedientesDua", getExpedientesAsociadoDua(mapPkDua));
        //Actas de incautacion
        mapRspta.put("listActasIncautacionInmovilizacionDua", cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua));
        //Actas de inmovilizacion - Actas de inspeccion
        String tmpNumDocTransp;
        String tmpNumDocTranspMaster;
        List<Map<String, Object>> detailRows = (List<Map<String, Object>>) mapPkDua.get("LIST_SERIES");
        List<Map> duaactas = this.cabActasDAO.joinMovDuaActasByDUA(mapPkDua);
        // Se valida los documentos de transporte Master o Hijo, para identificar
        // las actas asociadas al manifiesto
        List<String> numDocsTransps = new ArrayList<String>();
        for (Map<String, Object> row : detailRows)
        {
          tmpNumDocTransp = row.get("NUM_DOCTRANSP") != null ? row.get("NUM_DOCTRANSP").toString() : "";
          tmpNumDocTranspMaster = row.get("NUM_DOCTRANSPMASTER") != null ? row.get("NUM_DOCTRANSPMASTER").toString() : "";
          tmpNumDocTransp = tmpNumDocTransp.trim();
          tmpNumDocTranspMaster = tmpNumDocTranspMaster.trim();
          if (!"".equals(tmpNumDocTransp) && !numDocsTransps.contains(tmpNumDocTransp))
          {
            numDocsTransps.add(tmpNumDocTransp);
          }
          if (!"".equals(tmpNumDocTranspMaster) && !numDocsTransps.contains(tmpNumDocTranspMaster))
          {
            numDocsTransps.add(tmpNumDocTranspMaster);
          }
        }
        mapPkDua.put("NUM_DOCTRANS", numDocsTransps);
        List<Map> manifiestoactas = new ArrayList<Map>();
        if (!CollectionUtils.isEmpty(numDocsTransps))
        {
          manifiestoactas = this.cabActasDAO.joinMovManifiestoActasByDocTransporte(mapPkDua);
          duaactas.addAll(manifiestoactas);
        }
//		List<Map> actasinmovilizacion = new ArrayList<Map>();
        List<Map> actasinspeccion = new ArrayList<Map>();
        for (Map row : duaactas)
        {
          Map accioncontrol = new HashMap();
          accioncontrol.put("ACE", row.get("DESCRIPCION"));
          accioncontrol.put("NRO", row.get("NROFULL"));
          accioncontrol.put("NROCORTO", row.get("NROCORTO"));
//          if (row.get("CTIPO_ACTA").equals("AM")){
//        	  actasinmovilizacion.add(row);
//          }
//          else
//        	  actasinspeccion.add(row);
          if (!row.get("CTIPO_ACTA").equals("AM"))
        	  actasinspeccion.add(row); 
        }
//      mapRspta.put("listActasInmovilizadas", actasinmovilizacion);
        mapRspta.put("listActasInspeccion", actasinspeccion);
        return mapRspta;
    }
  //RIN16-CUS 11.03 - Fin/ 

    //este metodo no es utilizado
    @Deprecated
    public List<Map<String, Object>> obtenerAreasParaResoluciones(String tipoResolucion){

          // busca en prad1
//          swapperDatasource.swap(fabricaDeServicios.getService(Constantes.SWAPPER_DATASOURCE_DS + "000"));

          Map<String, Object> params = new HashMap<String, Object>();
          params.put("depen", tipoResolucion.concat("%"));
          params.put("flag", "0");
          params.put("ind_rec", "S");

//          return tabDepDAO.select(params);
          return ayudaService.selecttabdep(params);
      }

    //este metodo no es utilizado
    @Deprecated
      public List<Map<String, Object>> obtenerAreasParaActasVerificacion(String codAduana){


//        swapperDatasource.swap(fabricaDeServicios.getService(Constantes.SWAPPER_DATASOURCE_DS + codAduana));

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("aduana", codAduana);

//        return tabDepDAO.select(params);
        return ayudaService.selecttabdep(params);
    }


      public List<Map<String, Object>> obtenerLocaAnexo(String ruc) throws ServiceException{

          List<Map<String, Object>> lstAnexosRspta = new ArrayList<Map<String, Object>>();
          /*
//          List<Map<String, Object>> lstAnexos = (List<Map<String, Object>>) this.sprDAO.getEstablecimientosAnexos(ruc);
          List<Map<String, Object>> lstAnexos = (List<Map<String, Object>>)sprDAOService.getEstablecimientosAnexos(ruc);
          if (!CollectionUtils.isEmpty(lstAnexos)) {
              for (Map mapSpr : lstAnexos) {
                  //correccion esantana encuentra el error amancilla lo resulve y lo envia al trunk sin pruebas
                  //String correl = Cadena.padLeft(String.valueOf(((Short) mapSpr.get("spr_correl")).intValue()), 4, '0');
                  String correl = Cadena.padLeft(String.valueOf((Utilidades.toLong(mapSpr.get("spr_correl")))), 4, '0');
                  String direccionAnexo = formaDireccion((String) mapSpr.get("spr_nomvia"), (String) mapSpr.get("spr_numer1"), (String) mapSpr.get("spr_inter1"));
                  Map<String, Object> mapAnexo = new HashMap<String, Object>();
                  mapAnexo.put("codLocalAnexo", correl);
                  mapAnexo.put("direccion", direccionAnexo);
                  lstAnexosRspta.add(mapAnexo);
              }
          }
          */
    	//RIN-13
    	Map<String, Object> params = new HashMap<String, Object>();
    	params.put("numRuc", ruc);
  		List<Spr> lstAnexos = this.sprDAOService.listEstablecimientosAnexos(params);
  		
  		if (!CollectionUtils.isEmpty(lstAnexos)) {
            for (Spr spr : lstAnexos) {
            	Map<String, Object> mapAnexo = new HashMap<String, Object>();
                mapAnexo.put("codLocalAnexo", Cadena.padLeft(spr.getCorrelativo().toString(), 4, '0'));
                mapAnexo.put("direccion", spr.getDireccion());
                lstAnexosRspta.add(mapAnexo);
            }
        }
  		
          return lstAnexosRspta;
      }



      /**
       * Metodo que permite obtener la direccion en base a los parametros enviados
       *
       * @param via
       * @param num
       * @param inter
       * @return
       */
      /*private String formaDireccion(String via, String num, String inter){
          if (!inter.trim().equals("-")) {
              inter = " - " + inter.trim();
          } else {
              inter = "";
          }
          return via.trim() + " " + num.trim() + inter;
      }*/

      /**
       * Proceso : Metodo que obtiene con acta tipo aviso de inspeccion
       * asociados a la dua. por defecto ejecuta el store procedure en pram1
       *
       * @param params
       * (#COD_ADUAMANIFIESTO#,#ANN_MANIFIESTO#,#COD_VIATRANS#,#NUM_MANIFIESTO#,#NUM_DOCTRANSP#,
       * '08','VI') AS AVISO
       * @return
       * @throws ServiceException
       *
       * @autor: amancillaa
       */
      @Deprecated
      private Map<String, Object> getAvisosInspeccion2(Map<String, Object> mapaDocumentoTrans) throws ServiceException{

          Map<String, Object> mapAviso = new HashMap<String, Object>();

          // Lista de parametros para invocar a la funcion USAMTG00.pktd_td.fnValidarMedidaPreventiva
          String mensajeAviso = fnValidarMedidaPreventivaDAO.getValidarMedidaPreventiva(mapaDocumentoTrans);

          if (!(mensajeAviso.substring(0, 1).equals("2") && mensajeAviso.split("\\|").length == 1)) {
              if (mensajeAviso.substring(0, 1).equals("1")) {
                  // 1: 0300-118-2011-000014
                  // Formo el map con el nro del aviso de inspeccion
                  // codigo de mensaje
                  mapAviso.put("codigo", mensajeAviso.split(":")[0]);
                  // nro de aviso de inspeccion
                  mapAviso.put("nroAviso", mensajeAviso.split(":")[1].trim());

              } /*
               * else if(mensajeAviso.substring(0, 1).equals("2")){
               * //Formo el map con el nro de aviso y nro de acta
               * //2: DOC. TRANSPORTE SIN AVISO DE
               * INSPECCI?N.|1700-0300-118-2011-000041|0400-0300-118-2011-000023
               * mapAviso.put("codigo", mensajeAviso.split("\\|")[0]);//codigo y descripcion del
               * mensaje);
               * mapAviso.put("nroAviso", mensajeAviso.split("\\|")[1]);//nroAviso);
               * mapAviso.put("nroActa", mensajeAviso.split("\\|")[2]);//nroActa);
               * }
               */
          } else {
              // mapAviso.put("codigo", mensajeAviso.split(":")[0]);//codigo del mensaje (2 : sin
              // aviso o 0: error)
          }

          return mapAviso;
      }


      /**
       * Proceso : Obtiene las NUEVAS ACES en cualquier estado y tipo
       * asociado a la DUA
       *
       * @param Map mapPkDua
       * @return List[Mapa[aces]]
       *
       * @autor: amancillaa
       */
	  //incio EJHM
      public List<Map<String, Object>> getAceAsociadosDua(Map<String, Object> mapPkDua){
    // fin EJHM

          List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
          //validacion datos de entrada
          if (CollectionUtils.isEmpty(mapPkDua)) {
               return lstRspta;
          }

          Map<String, Object> mapBuqDua= new HashMap<String, Object>();
          mapBuqDua.put("CTDOC_PRECO", ConstantesACE.CTDOC_PRECO_ACE);  // solo tipos ace
          mapBuqDua.put("NELIM_REGIS", "0"); //solo activos
          mapBuqDua.put("CADUA_DUA",mapPkDua.get("COD_ADUANA").toString());
          mapBuqDua.put("CCODI_REGIM",mapPkDua.get("COD_REGIMEN").toString());
          mapBuqDua.put("FANNO_DUA",mapPkDua.get("ANN_PRESEN").toString());
          mapBuqDua.put("NCORR_DUA",mapPkDua.get("NUM_DECLARACION").toString());

          List<Map<String, Object>> lstActasACEAsocDua =  movDuasActasDAO.findAce(mapBuqDua);
          if (!CollectionUtils.isEmpty(lstActasACEAsocDua)) {
              lstRspta.addAll(lstActasACEAsocDua);
          }

          return lstRspta;
      }

      /**
       * Proceso : Obtiene las NUEVAS ACES en cualquier estado y tipo
       * asociado al Documento de Transporte
       *
       * @param Map mapPkManifiesto
       * @return List[Mapa[aces]]
       *
       * @autor: amancillaa
       */
      private List<Map<String, Object>> getAceAsociadosDocTransporte(Map<String, Object> mapPkManifiesto){

          List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
          //validacion datos de entrada
          if (CollectionUtils.isEmpty(mapPkManifiesto)) {
               return lstRspta;
          }

          Map<String, Object> mapManifiestoDocTrans = new HashMap<String, Object>();

          mapManifiestoDocTrans.put("CTDOC_PRECO", ConstantesACE.CTDOC_PRECO_ACE);  // solo tipos ace 1800
          mapManifiestoDocTrans.put("NELIM_REGIS", "0"); //solo activos
          mapManifiestoDocTrans.put("CADUA_MANIF",mapPkManifiesto.get("COD_ADUAMANIFIESTO"));
          mapManifiestoDocTrans.put("FANO_MANIF",mapPkManifiesto.get("ANN_MANIFIESTO"));
          mapManifiestoDocTrans.put("NNUME_MANIF",mapPkManifiesto.get("NUM_MANIFIESTO"));
          mapManifiestoDocTrans.put("CVIA_TRANSP",mapPkManifiesto.get("COD_VIATRANS"));
          //se comenta en numeracion no es obligatorio enviar el num_detalle siempre lo envian con cero
          //mapManifiestoDocTrans.put("NNUM_DETALLE",mapPkManifiesto.get("NUM_DETALLE"));
          mapManifiestoDocTrans.put("NNUM_CONOCIM",mapPkManifiesto.get("NUM_DOCTRANSP"));
          //mapManifiestoDocTrans.put("CTIPO_ACTA",ConstantesACE.COD_TIPO_ACE_INMOVILIZACION_PARA_INSPECCION);
          //mapManifiestoDocTrans.put("CESTADO_ACTA",ConstantesACE.COD_ESTADO_ACE_EJECUCION);
            //TODO: deberia jalar findAce3 pero este metodoe sta haciendo refrencia al findAce2
          //cuando se modifique no necesitara eliminar los elementos duplicados

          List<Map<String, Object>> lstACE =  movManifiestosActasDAO.findAce3(mapManifiestoDocTrans);

          if (!CollectionUtils.isEmpty(lstACE)) {

            //elimino los elementos duplicados no soporta combo Almaceb JSON en el JSP
              HashSet<Map<String, Object>> hashSet = new HashSet<Map<String, Object>>(lstACE);
              List<Map<String, Object>> lstACE2 = new ArrayList<Map<String, Object>>(hashSet);

              lstRspta.addAll(lstACE2);
          }

          return lstRspta;
      }

	// RIN13, lo puso public
	@Override
	public List<Map<String, Object>> getExpedientesAsociadoDua(Map<String, Object> mapPkDua){

        swapperDatasource.swap(fabricaDeServicios.getService(Constantes.SWAPPER_DATASOURCE_DS
                + (String) mapPkDua.get("COD_ADUANA")));



        Map<String, Object> mapPkDua2 = new HashMap<String, Object>();
        mapPkDua2.put("COD_ADUANA", mapPkDua.get("COD_ADUANA"));
        mapPkDua2.put("ANN_PRESEN", mapPkDua.get("ANN_PRESEN").toString());
        mapPkDua2.put("NUM_DECLARACION", mapPkDua.get("NUM_DECLARACION"));
        //GGRANADOS_RECTI INI
        //gmontoya P24 INICIO
        String codRegimen = mapPkDua.get("COD_REGIMEN")!=null?mapPkDua.get("COD_REGIMEN").toString():"";        
        if(codRegimen.equals("10")) {
        	mapPkDua2.put("COD_REGIMEN","17");
        }else if(codRegimen.equals("20")){
        	mapPkDua2.put("COD_REGIMEN","32");
        }else if(codRegimen.equals("21")){
        	mapPkDua2.put("COD_REGIMEN","7");
        }else if(codRegimen.equals("70")){
        	mapPkDua2.put("COD_REGIMEN","40");
        }else{
        	mapPkDua2.put("COD_REGIMEN", mapPkDua.get("COD_REGIMEN"));
        }
        //gmontoya P24 FIN
        //GGRANADOS_RECTI FIN


        return expediDAO.findExpedientesAsociadoDua(mapPkDua2);
    }
	//inicio P21-P22
  //inicio gmontoya Pase 99 2016
    @Override
    public List<Map<String, Object>> getExpedientesAsociadoDuaPECO(Map<String, Object> mapPkDua){

      List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
      String codProcedim [] = Constantes.LISTA_CODIGOS_PROCEDIM_PECO_AMAZONIA;
      Map<String, Object> mapPkDua2 = new HashMap<String, Object>();
      mapPkDua2.put("COD_ADUANA", mapPkDua.get("COD_ADUDEST"));
      mapPkDua2.put("ANN_PRESEN", mapPkDua.get("ANN_PRESEN").toString());
      mapPkDua2.put("NUM_DECLARACION", mapPkDua.get("NUM_DECLARACION"));
      mapPkDua2.put("CODPROCEDIM", codProcedim);
      String codRegimen = mapPkDua.get("COD_REGIMEN")!=null?mapPkDua.get("COD_REGIMEN").toString():"";
      if(codRegimen.equals("10")) {
        mapPkDua2.put("COD_REGIMEN","17");
      }else if(codRegimen.equals("20")){
        mapPkDua2.put("COD_REGIMEN","32");
      }else if(codRegimen.equals("21")){
        mapPkDua2.put("COD_REGIMEN","7");
      }else if(codRegimen.equals("70")){
        mapPkDua2.put("COD_REGIMEN","40");
      }else{
        mapPkDua2.put("COD_REGIMEN", mapPkDua.get("COD_REGIMEN"));
      }
      Object o = swapperDatasource.swap(fabricaDeServicios.getService(Constantes.SWAPPER_DATASOURCE_DS
              + (String) mapPkDua.get("COD_ADUDEST")));
      lista = expediDAO.findExpedientesAsociadoDua(mapPkDua2);
      swapperDatasource.swap(o);
      return lista;
    }
  //fin gmotnoya Pase 99 2016
	private Boolean expedienteExistente(List<Map<String, Object>> listExpediMap, Expedi expedi){
		Boolean expedienteExistente = false;
		if(!listExpediMap.isEmpty()){
			for(Map<String,Object> expediMap:listExpediMap){
				String nro    = expediMap.get("NROEXPEDI").toString();			
				String ofiRec = expediMap.get("OFIC_REC").toString();
				String anio   = expediMap.get("ANOEXPEDI").toString();
				if(expedi.getNroexpedi().toString().equals(nro) && expedi.getOficRec().equals(ofiRec) && expedi.getoAnno().equals(anio))
					expedienteExistente = true;
			}
		}
		return expedienteExistente;
	}
	
	public List<Map<String,Object>> findExpediDocAsociado(Map<String, Object> params){
		  // Se debe buscar por documento origen y tambien por documento de referencia	 
		  ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		  List<Map<String, Object>> listExpediMap = expedienteService.findExpedientesAsociadoDeclaracion(params);		  
			  params.put("O_TIPO", params.get("COD_REGIMEN"));
			  params.put("COD_ADUANA_DECLA", params.get("COD_ADUANA"));
			  params.remove("COD_REGIMEN");
			  List<Expedi> listExpediRef = expedienteService.findExpediDocReferencia(params);			  
			  if (!CollectionUtils.isEmpty(listExpediRef)){
				  for(Expedi dr:listExpediRef ){
					 Boolean expedienteExistente = expedienteExistente(listExpediMap,dr);
					 if(!expedienteExistente){
						 Map<String,Object> expParam = new HashMap<String,Object>();
						 expParam.put("codAduaExpedi", dr.getCodiAdua().toString());
						 expParam.put("anoExpedi", dr.getAnoexpedi().toString());
						 expParam.put("nroExpedi", dr.getNroexpedi().toString());
						 expParam.put("codAreaExpedi", dr.getOficRec().toString());
						 expParam.put("codi_aduan", params.get("COD_ADUANA"));
						 List<Map<String,Object>> it =expedienteService.findByExpediente(expParam);
						 for(Map<String,Object> i:it){
							 String numero = i.get("CODI_ADUA").toString().trim()+"-"+i.get("OFIC_REC").toString().trim()+"-"+
									 		 i.get("ANOEXPEDI").toString().trim()+"-"+i.get("NROEXPEDI").toString().trim();
							 i.put("NUMERO",numero);
							 try{
								 Date tmp = new SimpleDateFormat("yyyyMMdd").parse(i.get("FECEXP").toString());						 
								 i.put("FECHA_HORA",new SimpleDateFormat("yyyy-MM-dd").format(tmp));
							 }catch(Exception e){
								 i.put("FECHA_HORA","");
								 throw new ServiceException(e,e.getMessage());
							 }
									 		 
						 }
						 listExpediMap.addAll(it);
					 }
				  }
			  
		  }
		  return listExpediMap;
	  }
	

	public List<Map<String, Object>> getBoletinesQuimicosRatificadoNoRatificado (Map<String, Object> mapPkDua){
		
		List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
        Map<String, Object> PkDecla = new HashMap<String, Object>();
        PkDecla.put("caduana",  mapPkDua.get("COD_ADUANA").toString());
        PkDecla.put("CADUA_DUA",mapPkDua.get("COD_ADUANA").toString());
        PkDecla.put("NANNO_DUA",mapPkDua.get("ANN_PRESEN").toString());
        PkDecla.put("ANN_PRESEN", mapPkDua.get("ANN_PRESEN").toString());
        PkDecla.put("CREG_DUA", mapPkDua.get("COD_REGIMEN").toString());
        PkDecla.put("NCORR_DUA", Cadena.padLeft(mapPkDua.get("NUM_DECLARACION").toString(), 6, '0'));
        SoporteService soporteService = fabricaDeServicios.getService("diligencia.ingreso.soporteService");
	    List<Map<String, Object>> lstBol= soporteService.obtenerBoletinQuimico(PkDecla);
	    if(lstBol !=null && lstBol.size() != 0){
	    	
	    	 for (Map<String, Object> mapBoletinQuimico : lstBol) {
		     
		       if (  ("4".equals(mapBoletinQuimico.get("SESTA_ANALIS")) || "3".equals(mapBoletinQuimico.get("SESTA_ANALIS"))))
		       {
		    	   lstRspta.add(mapBoletinQuimico);
		       }
		     }
	     }
	    return lstRspta;
    }

	public List<Map<String, Object>> getActasVerificacionConDUA (Map<String, Object> mapPkDua){

		List<Map<String, Object>> lstRspta= new ArrayList<Map<String, Object>>();
        Map<String, Object> PkDecla = new HashMap<String, Object>();
  	  	PkDecla.put("tipodoc", ConstantesDataCatalogo.COD_DCTO_TRAMITE_ACTA_DE_SEPARACION); //062
  	  	PkDecla.put("codi_adua",  mapPkDua.get("COD_ADUANA").toString());
		PkDecla.put("codigoAduana",  mapPkDua.get("COD_ADUANA").toString());
  	  	PkDecla.put("annoref", mapPkDua.get("ANN_PRESEN").toString());
  	  	PkDecla.put("numeref", mapPkDua.get("NUM_DECLARACION").toString());
  	  	DocumentoInternoService documentoInternoService = fabricaDeServicios.getService("tramite.DocumentoInternoService");
  		List<Map<String, Object>> listActaVerificacionConDUA = documentoInternoService.obtenerDocInternoTransbordo(PkDecla);
        	if(listActaVerificacionConDUA !=null && listActaVerificacionConDUA.size() != 0){
        		lstRspta.addAll(listActaVerificacionConDUA);
        	}
	      	
	      	return lstRspta;
    }

	
	  public Map<String, Object> getActasAvisosInspeccionAsociadosDocTransporte(Map<String, Object> mapPkManifiesto, List<Map<String, Object>> listNumDoctrans)
	  {
	    String tmpNumDocTransp;
	    String tmpNumDocTranspMaster;
	    Map<String, Object> mapResultado = new HashMap<String, Object>();
	   
	    List<String> numDocsTrans= new ArrayList<String>();
	    for (Map<String, Object> row : listNumDoctrans)
	    {
	      tmpNumDocTransp = row.get("NUM_DOCTRANSP") != null ? row.get("NUM_DOCTRANSP").toString().trim() : "";
	      tmpNumDocTranspMaster = row.get("NUM_DOCTRANSPMASTER") != null ? row.get("NUM_DOCTRANSPMASTER").toString().trim() : "";
	  
	      if (!SunatStringUtils.isEmptyTrim(tmpNumDocTransp) )
	      {      
	        numDocsTrans.add(tmpNumDocTransp);
	      }
	      if (!SunatStringUtils.isEmptyTrim(tmpNumDocTranspMaster))    		  
	      {
	        numDocsTrans.add(tmpNumDocTranspMaster);
	      }
	    }

	    mapPkManifiesto.put("NUM_DOCTRANS", numDocsTrans);
	    List<Map> manifiestoactas = new ArrayList<Map>();
	    List<Map> avisosinspeccion = new ArrayList<Map>();

	    if (!CollectionUtils.isEmpty(numDocsTrans))
	    {
	    	manifiestoactas = this.cabActasDAO.joinMovManifiestoActasByDocTransporte(mapPkManifiesto);	
	    	avisosinspeccion = this.datAuxActaDAO.findAvisoInspeccionByManifiesto(mapPkManifiesto);
	     }

	    mapResultado.put("listManifiestoActas", manifiestoactas);
	    mapResultado.put("listAvisosIspeccion", avisosinspeccion);

	    return mapResultado;
	  }

	//fin P21-P22
      private List<Map<String, Object>> getAceAsociadosDocTransporte(List<Map<String, Object>> listNumDoctrans){

          List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
          // obtengo avisos inspeccion
          for (Map<String, Object> mapNumDoctrans : listNumDoctrans) {
              List<Map<String, Object>> AceAsociadosDocTransporte = getAceAsociadosDocTransporte(mapNumDoctrans);
              if (!CollectionUtils.isEmpty(AceAsociadosDocTransporte)) {
                  lstRspta.addAll(AceAsociadosDocTransporte);
              }
          }

          return lstRspta;
      }


      private List<Map<String, Object>> getActasAsociadosDocTransporte(List<Map<String, Object>> listNumDoctrans){

          List<Map<String, Object>> lstRspta = new ArrayList<Map<String, Object>>();
          // obtengo avisos inspeccion
          for (Map<String, Object> mapNumDoctrans : listNumDoctrans) {
              List<Map<String, Object>> listActasAsociadasManifiesto = cabActasDAO.findIncautacionAndInmovilizacionAsociadosDocTransporte(mapNumDoctrans);
              if (!CollectionUtils.isEmpty(listActasAsociadasManifiesto)) {
                  lstRspta.addAll(listActasAsociadasManifiesto);
              }
          }

          return lstRspta;
      }
      
      
      // FIXME RIN16 : lpalominom [inicio]
      /**
       * {@inheritDoc}
       */
      public List<Map<String, Object>> obtenerBoletinQuimicoPorDeclaracion(Map<String, Object> params){
    	  swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_WRITE + params.get("COD_ADUANA").toString().trim()));
    	  return this.tabBolQuimDAO.findByDeclaracion(params);
      }
      
      /**
       * {@inheritDoc}
       */
      public boolean tieneBoletinesQuimicosPendientes(Declaracion declaracion){
    	  boolean flag = false;
    	  Map<String, Object> parametros = new HashMap<String, Object>();
    	  
    	  parametros.put("COD_ADUANA", declaracion.getCodaduana());
    	  parametros.put("ANN_PRESEN", declaracion.getDua().getAnnpresen());
    	  parametros.put("NUM_DECLARACION", declaracion.getNumeroDeclaracion());
    	  parametros.put("COD_REGIMEN", declaracion.getCodregimen());
    	  parametros.put("IND_FINALIZADO", "1");
    	  log.info("## Parametros : "+parametros);
    	  
    	  List<Map<String,Object>> lista = this.obtenerBoletinQuimicoPorDeclaracion(parametros);
    	  log.info("## Boletines: "+lista);
    	  
    	  if (lista != null && lista.size()>0){
    		  flag = true;
    	  }
    	  
    	  return flag;
      }
      
	  /*P20*/
      public List<Map<String, Object>> obtenerCabActasForAsignacionAutomatica(Map<String,Object> params){
    	  List<Map<String,Object>> result = cabActasDAO.findByDeclaracionForAsignacionAutomatica(params);
    	  return result; 
      }
      /*FIN P20*/	  
      
      // FIXME RIN16 : lpalominom [fin]
      /*RIN13FSW-INICIO*/

      /**
       * obtener expediente de suspencion de plazo 1606
       * juazor RIN 13
       * 
       */
        public List<Expedi> obtenerExpediSuspencionPlazo(Map<String, Object> PkDecla) throws ServiceException
        {
        	List<Expedi> lstExpedi = new ArrayList<Expedi>();

          try
          {
        	
        	
            Expedi expediente = new Expedi();
            
            Integer O_TIPO = Integer.parseInt(PkDecla.get("O_TIPO").toString()) ;
            Integer O_NRO = Integer.parseInt( PkDecla.get("NUM_DECLARACION").toString()) ;
                       
            expediente.setoTipo(O_TIPO);
            expediente.setoAnno(MapUtils.getString(PkDecla,"ANN_PRESEN"));
            expediente.setoNro(O_NRO);
            expediente.setCodiAdua(MapUtils.getString(PkDecla,"COD_ADUANA"));        
            
            Object o = swapperDatasource.swap(fabricaDeServicios.getService(Constantes.PREF_DATASOURCE_READ + PkDecla.get("COD_ADUANA").toString().trim()));  
        	ExpedienteService expedienteService = (ExpedienteService) fabricaDeServicios.getService("tramite.ExpedienteService");
        	
            lstExpedi = expedienteService.findByMap(expediente);
             
            swapperDatasource.swap(o);
            
          }
          catch (DataAccessException e)
          {
            log.error("*** ERROR ***", e);
            throw new ServiceException(e, e.getMessage());
          }
          catch (Exception e)
          {
            log.error("*** ERROR ***", e);
            throw new ServiceException(e, e.getMessage());
          }

          return lstExpedi;
        }
        
        @Override
        public long emitirNotificacion(Map<String, Object> mapMensaje) throws ServiceException {
        	long serie = 00;
        	List<Map<String, Object>> listaJefes = null;
        	FechaBean fechaPublicacion = new FechaBean();
        	FechaBean fechaVigencia = new FechaBean();
        	String codTipoAviso = mapMensaje.get("codTipoAviso").toString();
        	String flagLst = mapMensaje.get("flag").toString();
        	if(flagLst.equals("JEFES_MANIFIESTO")){
        		 listaJefes = aduanaRol.getEmpleados(mapMensaje.get("cod_aduana").toString(), Constantes.JEFE_DE_MANIFIESTOS);
        	}
        	Integer codPlantilla = Integer.parseInt(mapMensaje.get("codPlantilla").toString());
        	fechaVigencia.setFecha("31/12/9999");
        	mapMensaje.put("fecha_emision", new StringBuilder(fechaPublicacion.getDia()).append("/").append(fechaPublicacion.getMes()).append("/").append(fechaPublicacion.getAnho()).toString());
        	StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
        	
        	for (Map<String, Object> map : listaJefes) {
        		mapMensaje.put("cod_usuario", new String[] { map.get("cod_pers").toString() });
        		serie =publicacionAvisoService.insert(codPlantilla, data, codTipoAviso, fechaPublicacion.getTimestamp(), fechaVigencia.getTimestamp());
        		log.debug(":::::::se registro el mensaje::::::::serieal de envio"+serie);
			}
        	
        	return serie;
        }
/*RIN13FSW-FIN*/

      //RIN13
      @Override
      public String getDescripcionElementoCatalogo(String codigoCatalogo, String codigoElementoCatalogo){
    	  return catalogoAyudaService.getDescripcionDataCatalogo(codigoCatalogo, codigoElementoCatalogo);
      }
      
  /***********************SET DE SPRING **********************************/


  public void setTabBolQuimDAO(TabBolQuimDAO tabBolQuimDAO)
  {
    this.tabBolQuimDAO = tabBolQuimDAO;
  }


//  public void setDdpDAO(DdpDAO ddpDAO)
//  {
//    this.ddpDAO = ddpDAO;
//  }


//  public void setT733DAO(T733DAO t733dao)
//  {
//    t733DAO = t733dao;
//  }


  public void setExpediDAO(ExpediDAO expediDAO)
  {
    this.expediDAO = expediDAO;
  }


  public void setLiquidaDAO(LiquidaDAO liquidaDAO)
  {
    this.liquidaDAO = liquidaDAO;
  }


  public void setCabActasDAO(CabActasDAO cabActasDAO)
  {
    this.cabActasDAO = cabActasDAO;
  }


  public void setoDepoCabDAO(ODepoCabDAO oDepoCabDAO)
  {
    this.oDepoCabDAO = oDepoCabDAO;
  }


  public void setNandTasaDAO(NandTasaDAO nandTasaDAO)
  {
    this.nandTasaDAO = nandTasaDAO;
  }


//  public void setNandinaDAO(NandinaDAO nandinaDAO)
//  {
//    this.nandinaDAO = nandinaDAO;
//  }



//  public void setTabLibeDAO(TabLibeDAO tabLibeDAO)
//  {
//    this.tabLibeDAO = tabLibeDAO;
//  }


  public FabricaDeServicios getFabricaDeServicios()
  {
    return this.fabricaDeServicios;
  }


  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
  {
    this.fabricaDeServicios = fabricaDeServicios;
  }


  public HotSwappableTargetSource getSwapperDatasource()
  {
    return this.swapperDatasource;
  }


  public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
  {
    this.swapperDatasource = swapperDatasource;
  }


//  public void setNandUniDAO(NandUniDAO nandUniDAO)
//  {
//    this.nandUniDAO = nandUniDAO;
//  }


  public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService)
  {
    this.catalogoAyudaService = catalogoAyudaService;
  }


  public void setDocuTransDAO(DocuTransDAO docuTransDAO)
  {
    this.docuTransDAO = docuTransDAO;
  }


//  public void setCalculaDiaDAO(CalculaDiaDAO calculaDiaDAO)
//  {
//    this.calculaDiaDAO = calculaDiaDAO;
//  }


  public void setDatAuxActaDAO(DatAuxActaDAO datAuxActaDAO)
  {
    this.datAuxActaDAO = datAuxActaDAO;
  }


//  public void setDeclaranDAO(DeclaranDAO declaranDAO)
//  {
//    this.declaranDAO = declaranDAO;
//  }


  public void setFnValidarMedidaPreventivaDAO(FnValidarMedidaPreventivaDAO fnValidarMedidaPreventivaDAO)
  {

    this.fnValidarMedidaPreventivaDAO = fnValidarMedidaPreventivaDAO;
  }


  public void setDetdeclaraDAO(DetDeclaraDAO detdeclaraDAO)
  {

    this.detdeclaraDAO = detdeclaraDAO;
  }


  public void setMovDuasActasDAO(MovDuasActasDAO movDuasActasDAO)
  {
    this.movDuasActasDAO = movDuasActasDAO;
  }

  public void setResSpimDAO(ResSpimDAO resSpimDAO)
  {
    this.resSpimDAO = resSpimDAO;
  }


//  public void setSprDAO(SprDAO sprDAO)
//  {
//    this.sprDAO = sprDAO;
//  }

//  public void setTabDepDAO(TabDepDAO tabDepDAO)
//  {
//    this.tabDepDAO = tabDepDAO;
//  }

  public void setMovManifiestosActasDAO(MovManifiestosActasDAO movManifiestosActasDAO)
  {
    this.movManifiestosActasDAO = movManifiestosActasDAO;
  }

public DdpDAOService getDdpDAOService() {
	return ddpDAOService;
}

public void setDdpDAOService(DdpDAOService ddpDAOService) {
	this.ddpDAOService = ddpDAOService;
}

public SprDAOService getSprDAOService() {
	return sprDAOService;
}

public void setSprDAOService(SprDAOService sprDAOService) {
	this.sprDAOService = sprDAOService;
}

public T733DAOService getT733daoService() {
	return t733daoService;
}

public void setT733daoService(T733DAOService t733daoService) {
	this.t733daoService = t733daoService;
}

public CalculaDiaDAOService getCalculaDiaDAOService() {
	return calculaDiaDAOService;
}

public void setCalculaDiaDAOService(CalculaDiaDAOService calculaDiaDAOService) {
	this.calculaDiaDAOService = calculaDiaDAOService;
}

public TabLibeDAOService getTabLibeDAOService() {
	return tabLibeDAOService;
}

public void setTabLibeDAOService(TabLibeDAOService tabLibeDAOService) {
	this.tabLibeDAOService = tabLibeDAOService;
}

public HotSwappableTargetSource getSwapperDatasourceTabLib() {
	return swapperDatasourceTabLib;
}

public void setSwapperDatasourceTabLib(HotSwappableTargetSource swapperDatasourceTabLib) {
	this.swapperDatasourceTabLib = swapperDatasourceTabLib;
}
/*RIN13FSW-INICIO*/
//<EHR>
public void setPublicacionAvisoService(
		PublicacionAvisoService publicacionAvisoService) {
	this.publicacionAvisoService = publicacionAvisoService;
}
public void setAduanaRol(AduanaRol aduanaRol) {
	this.aduanaRol = aduanaRol;
}
//</EHR>

/*RIN13FSW-FIN*/

}
