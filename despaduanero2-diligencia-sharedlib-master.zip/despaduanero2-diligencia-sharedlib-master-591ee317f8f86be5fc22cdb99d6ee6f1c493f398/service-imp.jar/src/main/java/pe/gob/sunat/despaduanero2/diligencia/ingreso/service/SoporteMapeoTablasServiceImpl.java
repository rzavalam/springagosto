package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;



import java.io.IOException;


import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.core.io.Resource;

import org.springframework.util.CollectionUtils;
//import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.CampoXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadRelacionesXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadXml;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTagsXmlMapping;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * <p>Titulo: Clase servicio</p>
 * <p>Descripcion: Comparador de Maps del negocio, de acuerdo al xml registrado permite realizar la comparacion entre dos
 *    Mapas o Listas devolviendo la diferencia de estos para su actualizacion.
 * </p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.servicio.MapeoEntidadService.java</p>
 * <p>Copyright: SUNAT-2011</p>
 * @author amancillaa
 *
 * @version 1.0
 */
public class SoporteMapeoTablasServiceImpl implements SoporteMapeoTablasService {

    protected final Log	log							= LogFactory.getLog(getClass());

      private static final String CAMPO_ATTRIBUTE_PATH      = "campo-attribute-path";
      private static final String CAMPO_DATA_DEFAULT        = "campo-data-default";
      private static final String CAMPO_ERRORES             = "campo-errores";
      private static final String CAMPO_FORMATO             = "campo-formato";
      // private static final String CAMPO_NOMBRE_BD = "campo-nombre-bd";
      private static final String CAMPO_IDENTIFICADOR_VISTA = "campo-identificador-vista";
      private static final String CAMPO_NOMBRE              = "campo-nombre";
      // private static final String CAMPO_IDENTIFICADOR_IBATIS = "campo-identificador-ibatis";
      private static final String CAMPO_TIPO_DATO           = "campo-tipo-dato";
      private static final String ENT_CAMPOS                = "ent-campos";
      // private static final String ENT_CODIGO_RECTIOFICIO = "ent-codigo-rectioficio";
      private static final String ENT_CLAVE                 = "ent-clave";
      private static final String ENT_NOMBRE                = "ent-nombre";
      private static final String ENT_NOMBRE_SECUENCIA      = "ent-nombre-secuencia";
      // private static final String ENT_NOMBRE_BD = "ent-nombre-bd";
      private static final String ENT_SINONIMO_BD           = "ent-sinonimo-bd";
      private static final String ENTIDAD                   = "entidad";
      //956 relaciones
      private static final String ENT_RELACIONES            = "ent-relaciones";
      private static final String RELACION_ENTIDAD          = "relacion-entidad";
      private static final String RELACION_TIPO             = "relacion-tipo";

      //lista de entidades mapeadas
      private List<EntidadXml>  listaEntidadXml                = new ArrayList<EntidadXml>();

      /**
       * Constructor, que carga las entidades al momento que Spring levanta el contexto.
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
       */
      public SoporteMapeoTablasServiceImpl(Resource resource) throws ParserConfigurationException, SAXException, IOException{


                  DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                  DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
                  Document document = documentBuilder.parse(resource.getInputStream());
                  document.getDocumentElement().normalize();
                  //setea los datos del XML a la propiedad listaEntidadXml
                  this.setListaEntidadXml(this.getListaEntidades(document));

                  if (log.isDebugEnabled()) {
                        log.debug("---------------carga de XML------------------");
                        log.debug(getListaEntidadXml());
                    }

      }



      /*
       * (non-Javadoc)
       *
       * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapeoEntidadServices#getCampo(java.lang.String,
       * pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EntidadXml)
       */
      @Override
      public CampoXml getCampo(String nombreCampo, EntidadXml entidad) {


      //validamos que el parametros no se a NULL
        if(SunatStringUtils.isEmpty(nombreCampo) || entidad==null){
            return null;
        }

        for (CampoXml campo : entidad.getCampos()) {
          if (nombreCampo.toUpperCase().equals(campo.getNombre().toUpperCase().trim())
              || nombreCampo.toUpperCase().equals(campo.getIdentificadorVista().toUpperCase().trim())) {
            return campo;
          }
        }
        return null;
      }


      /*
       * (non-Javadoc)
       *
       * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapeoEntidadServices#getCampo(java.lang.String,
       * java.lang.String)
       */
      @Override
      public CampoXml getCampo(String nombreCampo, String nombreEntidad) {

          //validamos que el parametro no se a NULL
        if(SunatStringUtils.isEmpty(nombreCampo) || SunatStringUtils.isEmpty(nombreEntidad)){
            return null;
        }

        for (EntidadXml entidad : listaEntidadXml) {
          if (nombreEntidad.toUpperCase().equals(entidad.getNombre().toUpperCase())
              || nombreEntidad.toUpperCase().equals(entidad.getNombreSinonimoBD().toUpperCase())) {
            return getCampo(nombreCampo, entidad);
          }
        }
        return null;
      }


      /*
       * (non-Javadoc)
       *
       * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.util.MapeoEntidadServices#getEntidad(java.lang.String)
       */
      @Override
      public EntidadXml getEntidad(String nombreEntidad) {

        //validamos que el parametro no se a NULL
        if(SunatStringUtils.isEmpty(nombreEntidad)){
            return null;
        }
        for (EntidadXml entidad : listaEntidadXml) {
          if (nombreEntidad.toUpperCase().trim().equals(entidad.getNombre().toUpperCase().trim())) {
            return entidad;
          }
        }
        return null;
      }


      /**
       * Permite obtener los datos de las entidades
       *
       * @param document
       * @return
       */
      public List<EntidadXml> getListaEntidades(Document document) throws ServiceException {

        List<EntidadXml> lista = new ArrayList<EntidadXml>();

        NodeList lstNode = document.getElementsByTagName(ENTIDAD);
        for (int i = 0; i < lstNode.getLength(); i++) {
          Node node = lstNode.item(i);
          if (node.getNodeType() == Node.ELEMENT_NODE) {
            lista.add(getEntity((Element) node));
          }
        }
        if (CollectionUtils.isEmpty(lista)) {
          this.setListaEntidadXml(new ArrayList<EntidadXml>());
        } else {
          this.setListaEntidadXml(lista);
        }

        return lista;
      }

    /*
     * (non-Javadoc)
     * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteMapeoTablasService#esCampoClave(java.lang.String, pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EntidadXml)
     */
     public boolean esCampoClave(String nombreCampo, EntidadXml entidad) {
            boolean bandera = false;

          //validamos que el parametros no se a NULL
            if(SunatStringUtils.isEmpty(nombreCampo) || entidad==null){
                return false;
            }

            for (String campoClave : entidad.getLstClave()) {
              if (nombreCampo.toUpperCase().equals(campoClave.toUpperCase())
                  || nombreCampo.toUpperCase().equals(campoClave.toUpperCase())) {
                bandera = true;
                break;
              }
            }
            return bandera;
          }


        /*
         * (non-Javadoc)
         * @see pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteMapeoTablasService#getListaClave(pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EnumTablaModel)
         */
        public List<String> getListaClave(EnumTablaModel enumTablaModel) throws ServiceException {

            EntidadXml entidad = this.getEntidad(enumTablaModel.getIdentificadorXML());

            return entidad.getLstClave();
        }


      /**
       * Permite Obtener un determinado tag desde un Element. Si el elemento no fue registrado se devuelve vacio.
       *
       * @param sTag
       * @param eElement
       * @return
       */
      private String getTagValue(String sTag, Element eElement) {
        if (null != eElement.getElementsByTagName(sTag) && 0 < eElement.getElementsByTagName(sTag).getLength()) {
          NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
          if (null != nlList && 0 < nlList.getLength()) {
            Node nValue = (Node) nlList.item(0);
            return nValue.getNodeValue();
          }
        }
        return "";
      }


      /**
       * Permite obtener un arreglo a partir de una cadena
       *
       * @param sTag
       * @param sDelimiter
       * @param element
       * @return
       */
      private String[] getArrayOfString(String sTag, String sDelimiter, Element element) {
        String[] array = null;
        String cadena = getTagValue(sTag, element).trim();
        if (-1 < cadena.indexOf(sDelimiter)) {
         // array = StringUtils.split(cadena, sDelimiter); //pase604 por alguna razon solo jala 2 elementos
            array = cadena.split(sDelimiter);
          for (String subCadena : array) {
            subCadena = subCadena.trim();
          }
        } else if (0 < cadena.trim().length()) {
          array = new String[] { cadena };
        }
        return array;
      }





    /**
       * Permite obtener los datos basicos de una entidad
       *
       * @param element
       * @return
       */
      private EntidadXml getBasicEntity(Element element) {
        String[] claves;
        EntidadXml entidad = new EntidadXml();
        entidad.setNombre(getTagValue(ENT_NOMBRE, element));
        // entidad.setNombreBD(getTagValue(ENT_NOMBRE_BD, element));
        entidad.setNombreSecuencia(getTagValue(ENT_NOMBRE_SECUENCIA, element));
        entidad.setNombreSinonimoBD(getTagValue(ENT_SINONIMO_BD, element));
        // entidad.setCodigoRectiOficio(getTagValue(ENT_CODIGO_RECTIOFICIO, element));
        claves = getArrayOfString(ENT_CLAVE, ",", element);
        if (null != claves && 0 < claves.length) {
          entidad.setLstClave(claves);
        }
        return entidad;
      }


      /**
       * Permite Obtener un CampoXml a partir de un element
       *
       * @param elementCampo
       * @return
       */
      private CampoXml getCampoEntity(Element elementCampo) {
        String[] errores;
        CampoXml CampoXml = new CampoXml();
        CampoXml.setNombre(getTagValue(CAMPO_NOMBRE, elementCampo).trim());
        // CampoXml.setNombreBD(getTagValue(CAMPO_NOMBRE_BD, elementCampo));
        CampoXml.setIdentificadorVista(getTagValue(CAMPO_IDENTIFICADOR_VISTA, elementCampo).trim());
        // CampoXml.setIdentificadorIbatis(getTagValue(CAMPO_IDENTIFICADOR_IBATIS,
        // elementCampo));
        CampoXml.setTipoDato(getTagValue(CAMPO_TIPO_DATO, elementCampo).trim());
        CampoXml.setFormato(getTagValue(CAMPO_FORMATO, elementCampo).trim());
        CampoXml.setAttributePath(getTagValue(CAMPO_ATTRIBUTE_PATH, elementCampo).trim());
        // El valor por default puede contener espacio en blanco
        CampoXml.setDataDefault(getTagValue(CAMPO_DATA_DEFAULT, elementCampo).trim());
        if (EnumTagsXmlMapping.ESPACIO_BLANCO.getIdentificadorXML().equals(CampoXml.getDataDefault())) {
          CampoXml.setDataDefault(EnumTagsXmlMapping.ESPACIO_BLANCO.getValor());
        }else if(EnumTagsXmlMapping.SYSDATE.getIdentificadorXML().equals(CampoXml.getDataDefault())){
          CampoXml.setDataDefault(EnumTagsXmlMapping.SYSDATE.getValor());
        }
        errores = getArrayOfString(CAMPO_ERRORES, ",", elementCampo);
        if (null != errores && 0 < errores.length) {
          CampoXml.setLstError(errores);
        }
        return CampoXml;
      }


      /**
       * Permite Obtener un EntidadRelacionesXml a partir de un element
       *
       * @param elementRelacion
       * @return
       */
      private EntidadRelacionesXml getRelacionEntity(Element elementRelacion) {

        EntidadRelacionesXml entidadRelacionesXml = new EntidadRelacionesXml();

        entidadRelacionesXml.setEntidad(getTagValue(RELACION_ENTIDAD, elementRelacion).trim());

        entidadRelacionesXml.setTipo(getTagValue(RELACION_TIPO, elementRelacion).trim());


        return entidadRelacionesXml;
      }

      /**
       * Permite obtener los campos de una entidad
       *
       * @param element
       * @return
       */
      private List<CampoXml> getListaCampos(Element element) throws ServiceException {
        List<CampoXml> lstCampos = new ArrayList<CampoXml>();
        NodeList lstNodeCampos = element.getElementsByTagName(ENT_CAMPOS).item(0).getChildNodes();
        for (int ii = 0; ii < lstNodeCampos.getLength(); ii++) {
          Node nodeCampo = lstNodeCampos.item(ii);
          if (nodeCampo.getNodeType() == Node.ELEMENT_NODE) {
            Element elementCampo = (Element) nodeCampo;
            CampoXml CampoXml = getCampoEntity(elementCampo);
            lstCampos.add(CampoXml);
          }
        }
        return lstCampos;
      }


      /**
       * Permite obtener los relaciones con otras entidades de una entidad
       *
       * @param element
       * @return
       */
      private List<EntidadRelacionesXml> getListaRelaciones(Element element) throws ServiceException {
        List<EntidadRelacionesXml> lstRelaciones = new ArrayList<EntidadRelacionesXml>();

        NodeList lstNodeRelaciones = element.getElementsByTagName(ENT_RELACIONES).item(0).getChildNodes();
        for (int ii = 0; ii < lstNodeRelaciones.getLength(); ii++) {
          Node nodeRelacion = lstNodeRelaciones.item(ii);
          if (nodeRelacion.getNodeType() == Node.ELEMENT_NODE) {
            Element elementRelacion = (Element) nodeRelacion;
            EntidadRelacionesXml relacion = getRelacionEntity(elementRelacion);
            lstRelaciones.add(relacion);
          }
        }
        return lstRelaciones;
      }

      /**
       * Permite obtener la entidad a partir de un element
       *
       * @param element
       * @return
       */
      private EntidadXml getEntity(Element element) throws ServiceException {
        // datos bases de la entidad
        EntidadXml entidad = getBasicEntity(element);
        // Para los campos
        entidad.setCampos(getListaCampos(element));

        // Para los relaciones
        entidad.setLstRelaciones(getListaRelaciones(element));

        return entidad;
      }


      // Setters Getters


    private List<EntidadXml> getListaEntidadXml() {
        return listaEntidadXml;
    }

    private void setListaEntidadXml(List<EntidadXml> listaEntidadXml) {
        this.listaEntidadXml = listaEntidadXml;
    }


}
