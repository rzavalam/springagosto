package pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.despaduanero2.ayudas.model.Nandina;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract; 
import  pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.TipoDeDescrMinimaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.TransformadorDescrMinimaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
 

@Service
public class DescrMinimaServiceImpl implements DescrMinimaService
{

  @Autowired
  private FabricaDeServicios fabricaDeServicios;

  public ModelAbstract obtenerDescrMinima(long numCorreDoc, int numSecItem)
  { 
	   
	TipoDeDescrMinimaService tipoDeDescrMinima = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");

	TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
	String tipo= tipoDeDescrMinima.obtenerTipoDeDescrMinima(numCorreDoc,numSecItem);
       
    ModelAbstract objeto = null;
   
    if(tipo!=null){
         objeto=transformador.obtenerObjetoDescrMinima(numCorreDoc,numSecItem, tipo);
    }
	return objeto;

  }
  

	public ModelAbstract obtenerDescrMinimaParaJavascript(long numCorreDoc, int numSecItem)
	{

		TipoDeDescrMinimaService tipoDeDescrMinima = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");

		TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
		String tipo= tipoDeDescrMinima.obtenerTipoDeDescrMinima(numCorreDoc,numSecItem);

		ModelAbstract objeto = null;

		if(tipo!=null){
			objeto=transformador.obtenerObjetoDescrMinima(numCorreDoc,numSecItem, tipo, "DILIGENICA");
		}
		return objeto;

	}
  
	//rtineo mejoras, sobrecargamos el metodo
  public List<Map<String, Object>> obtenerItemDescrMinima(long numCorreDoc, int numSecItem){
	  return obtenerItemDescrMinima(numCorreDoc, numSecItem, null);
  }
	//rtineo mejoras, fin
	
  public List<Map<String, Object>> obtenerItemDescrMinima(long numCorreDoc, int numSecItem, Map<String, Object> variablesIngreso){
	  
	  ItemFacturaDAO itemFactura = fabricaDeServicios.getService("itemFacturaDAO");
	  CabDeclaraDAO declaran = fabricaDeServicios.getService("cabDeclaraDAO");
	ObservacionDAO observacion = fabricaDeServicios.getService("observacionDAO");
	CatalogoAyudaService catalogoAyuda = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
	
	  //obteniendo el valor detalle del Item 
	  Map<String, Object> params=  new HashMap<String, Object>();
		 params.put("NUM_CORREDOC", numCorreDoc);
		 params.put("NUM_SECITEM", numSecItem);
	//rtineo mejoras, se obtiene de variablesIngreso
	List<Map<String, Object>> listaItem = new ArrayList<Map<String,Object>>();
	if(variablesIngreso!=null){
		Map<Integer,List<Map<String,Object>>> mapItems = (Map<Integer,List<Map<String,Object>>>)variablesIngreso.get("mapItemFacturaCache");
		listaItem = mapItems.get(numSecItem);
	}else{
		//se continua ejecutando metodo anterior
		listaItem = itemFactura.getListItemByMap(params);
	}
	 //rtineo fin
	 
	 if(listaItem!=null && listaItem.size()>0){
		 for(int i=0; i<listaItem.size();i++){
			 //	detalle de la partida
			 if(listaItem.get(i).get("numpartnandi")!=null){
//pase42
				 
				  try {
					  //rtineo mejoras, consultamos a variablesIngreso donde esta precargado las partidas
					  Nandina nadina=null;
					  if(variablesIngreso != null){
						  Map<String,Object> mapPartidas = (HashMap<String,Object>)variablesIngreso.get("listPartidasRestCache"); 
						  nadina =  (Nandina)mapPartidas.get(SunatStringUtils.toStringObj(listaItem.get(i).get("numpartnandi")));			        	  
					  }else{
						  //continua con el metodo anterior
		        	  CatalogoAyudaService catalogoAyudaServiceSinRest = fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
			              nadina = catalogoAyudaServiceSinRest.getPartidaObject(SunatStringUtils.toStringObj(listaItem.get(i).get("numpartnandi")));
					  }
				 listaItem.get(i).put("despartida", nadina!=null ? nadina.getDescripcion(): "");
					
				   } catch (Exception e) {
					// TODO: handle exception
					
					   listaItem.get(i).put("despartida", "");
		      	 	   e.printStackTrace();
				   }
				 
				 //Nandina nadina = catalogoAyuda.getPartidaObject(SunatStringUtils.toStringObj(listaItem.get(i).get("numpartnandi")));//pase42
				// listaItem.get(i).put("despartida", nadina!=null ? nadina.getDescripcion(): "");
				 //listaItem.get(i).put("despartida", listaItem.get(i).get("despartida")!=null ? listaItem.get(i).get("despartida"): "");
			 }
			 
			 //datos de cabecera
			 Map<String, Object> paramsDua= new HashMap<String, Object>();
			 paramsDua.put("numeroCorrelativo",new Long(numCorreDoc));
			 //rtineo mejoras, se consulta de variableIngreso
			 DUA datosDua;
			 if(variablesIngreso != null){
				 datosDua = (DUA)variablesIngreso.get("duaCache");
			 }else{
				 //continua con la consulta anterior
				 datosDua=declaran.selectByNumCorredoc(paramsDua);
			 }
			 //rtineo fin
			 
			 listaItem.get(i).put("aduanaDua",datosDua.getCodaduanaorden()!=null? datosDua.getCodaduanaorden():" ");
			 listaItem.get(i).put("annoDua", datosDua.getAnnpresen()!=null?datosDua.getAnnpresen():" ");
			 listaItem.get(i).put("regimenDua", datosDua.getCodregimen()!=null?datosDua.getCodregimen():" ");
			 listaItem.get(i).put("numDeclaraDua", datosDua.getNumdocumento()!=null?datosDua.getNumdocumento():" ");
			 //Inicio-PAS20165E220200138	
			 listaItem.get(i).put("Fecdeclaracion", datosDua.getFecdeclaracion()!=null?datosDua.getFecdeclaracion():" ");
			 
			 
			 //listado de observaciones
			 StringBuffer lstObs = new StringBuffer();
			 Map<String, Object> mapBusqueda = new HashMap<String, Object>();
			 mapBusqueda.put("numcorredoc",numCorreDoc);
			 mapBusqueda.put("numsecitem",numSecItem);
			 mapBusqueda.put("codtipobs","03");//catalogo 369
			 //rtineo mejoras, se consulta de variablesIngreso
			 List<Observacion> obs;
			 if(variablesIngreso != null){
				 Map<Integer,List<Observacion>> mapObservaciones = (Map<Integer,List<Observacion>>)variablesIngreso.get("mapObservacionesCache");
				 obs = mapObservaciones.get(numSecItem);
			 }else{
				 //continua realizando la consulta
				 obs = observacion.findObservcionByMap(mapBusqueda);
			 }
			 //rtineo fin
			 if(obs!=null && obs.size()>0){
				 for(int j=0; j<obs.size(); j++){
					 lstObs.append(obs.get(j).getObsdeclaracion()!=null?obs.get(j).getObsdeclaracion().toString():" ");
					 lstObs.append("\n");
				 } 
			 }			 
			 listaItem.get(i).put("observacion",lstObs.toString());
		 }
	 }
	 
	  return listaItem;
  }

}