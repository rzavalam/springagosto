package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;


import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.dao.CatCasillaFormatoDAO;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;

@SuppressWarnings(
{ "unchecked", "rawtypes" })
public class CasillaFormatoServiceImpl implements CasillaFormatoService
{

  private List<Map<String, String>> casillaFormatoRectificacion;

  private CatCasillaFormatoDAO      catCasillaFormatoDAO;

  private List<Map<String, String>> getCasillaFormatoRectificacion()
  {
    if (casillaFormatoRectificacion == null)
    {
      String codTipoCat = Constantes.COD_TIPO_CATALOGO;
      casillaFormatoRectificacion = this.catCasillaFormatoDAO.findByCodTipoCat(codTipoCat);
    }

    return casillaFormatoRectificacion;
  }

  /**
   * {@inheritDoc}
   */
  public Map<String, String> buscarDescripcion(final String tabla, final String campo)
  {

    Map<String, String> res = null;

    List<Map<String, String>> casillaFormatoRecti = getCasillaFormatoRectificacion();// this.catCasillaFormatoDAO.findByCodTipoCat(codTipoCat);

    res = (Map<String, String>) CollectionUtils.find(casillaFormatoRecti, new Predicate()
    {

      @Override
      public boolean evaluate(Object objCasilla)
      {
        Map<String, String> mapCasilla = (Map<String, String>) objCasilla;
        String monSinonimTab = ObjectUtils.toString(mapCasilla.get("NOM_SINONIMTAB"), "TABLA_DESCONOCIDA");
        String monCampo = ObjectUtils.toString(mapCasilla.get("NOM_CAMPO")).trim();
        return (monSinonimTab.equals(tabla)) && (monCampo.equals(campo));
      }
    });
    if (res == null)
    {
      return new HashMap<String, String>();
    }
    return res;
  }

  /**
   * {@inheritDoc}
   */
  public String generaClaveMostrar(Map mapClave, String sinonimoTabla)
  {

    Map<String, Object> mapClaveDes = new HashMap<String, Object>();
    Iterator iterClave = mapClave.entrySet().iterator();

    while (iterClave.hasNext())
    {
      Map.Entry entry = (Map.Entry) iterClave.next();
      if (StringUtils.isBlank(ObjectUtils.toString(entry.getValue(), "")))
      {
        continue;
      }
      String clave = " ";

      Map<String, String> mapaDesc = buscarDescripcion(sinonimoTabla, entry.getKey().toString());
      if ((mapaDesc != null) && (!mapaDesc.isEmpty()))
      {
        clave = mapaDesc.get("DES_NEMONICO").toString();
        if (StringUtils.isBlank(clave))
        {
          continue;
        }
      }
      else
      {
        continue;
      }
      String data = entry.getValue().toString().trim();
      mapClaveDes.put(clave, data);
    }
    String res = SojoUtil.toJson(mapClaveDes);
    return res;
  }

  public void setCatCasillaFormatoDAO(CatCasillaFormatoDAO catCasillaFormatoDAO)
  {
    this.catCasillaFormatoDAO = catCasillaFormatoDAO;
  }
}
