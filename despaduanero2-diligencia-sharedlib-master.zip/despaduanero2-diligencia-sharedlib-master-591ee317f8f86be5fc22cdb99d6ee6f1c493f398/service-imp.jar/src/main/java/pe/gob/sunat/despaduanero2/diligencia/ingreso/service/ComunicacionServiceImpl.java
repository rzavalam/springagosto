package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.ComunicacionDAO;

public class ComunicacionServiceImpl implements ComunicacionService{
	
	private ComunicacionDAO comunicacionDao;
	
	/**
	 * @param numNota numero de la comunicacion (PK)
	 *
	 */
	public Comunicacion selectNotificacionByID(Long numNota){
		return comunicacionDao.selectNotificacionByID(numNota);
	}	
	
	public void setComunicacionDao(ComunicacionDAO comunicacionDao) {
		this.comunicacionDao = comunicacionDao;
	}
}
