package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.testng.Assert.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;

public class DeclaracionServiceTest {
  
  private DeclaracionServiceImpl declaracionService;
  private CabDeclaraDAO cabDeclaraDAO;
  private IndicadorDUADAO indicadorDuaDAO;
  
  @BeforeClass
  public void setUp() {
    declaracionService = new DeclaracionServiceImpl();
    cabDeclaraDAO = mock(CabDeclaraDAO.class);
    indicadorDuaDAO = mock(IndicadorDUADAO.class);
    declaracionService.setCabDeclaraDAO(cabDeclaraDAO);
    declaracionService.setIndicadorDuaDAO(indicadorDuaDAO);
  }
  
  @Test
  public void buscarDUAEncontro() {
    DUA resultDUA = new DUA();
    when(cabDeclaraDAO.findDUAByMap(new HashMap<String, Object>())).thenReturn(resultDUA);    
    assertNotNull(declaracionService.buscarDUA(new HashMap<String, Object>()));
  }
  
  @Test
  public void buscarDUANoEncontro() {    
    Map<String, Object> params = null;
    when(cabDeclaraDAO.findDUAByMap(params)).thenReturn(null);
    assertNull(declaracionService.buscarDUA(params));
  }
  
  @Test
  public void valRegistraFecReconFisRoja() {    
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("cod_canal", Constantes.CANAL_ROJO);
    assertTrue(declaracionService.valRegistraFecReconFis(params));
  }
  
  @Test
  public void valRegistraFecReconFisNaranjaConIndicadorRecFisico() {    
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("cod_canal", Constantes.CANAL_NARANJA);
    Map<String, Object> mapResult = new HashMap<String, Object>();
    mapResult.put("NUM_CORREDOC", 99999);    
    when(indicadorDuaDAO.findByDocumentoAndValor(params)).thenReturn(mapResult);
    assertTrue(declaracionService.valRegistraFecReconFis(params));
  }
  
  @Test
  public void valRegistraFecReconFisVerde() {    
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("cod_canal", Constantes.CANAL_VERDE);
    assertFalse(declaracionService.valRegistraFecReconFis(params));
  }
  
}
