package pe.gob.sunat.despaduanero2.diligencia.ingreso.service;

import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import static org.testng.Assert.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;

public class DiligenciaServiceTest {
  
  private DiligenciaServiceImpl diligenciaService;  
  private CabDeclaraDAO cabDeclaraDAO;
  
  @BeforeClass
  public void setUp() {
    diligenciaService = new DiligenciaServiceImpl();
    cabDeclaraDAO = mock(CabDeclaraDAO.class);
    diligenciaService.setCabDeclaraDAO(cabDeclaraDAO);
  }
  
  @Test
  public void tieneConclusionEnProcesoSi() {
    Map<String, Object> params = new HashMap<String, Object>();
    params.put("NUM_CORREDOC", 99999);
    Map<String, Object> mapResult = new HashMap<String, Object>();
    mapResult.put("FEC_DECLARACION", "FECHA");
    when(cabDeclaraDAO.findTieneConclusionEnProceso(params)).thenReturn(mapResult);
    assertSame(diligenciaService.tieneConclusionEnProceso(params).get("FEC_DECLARACION"), "FECHA");
  }
  
  @Test
  public void tieneConclusionEnProcesoNo() {
    when(cabDeclaraDAO.findTieneConclusionEnProceso(new HashMap<String, Object>())).thenReturn(null);
    assertSame(diligenciaService.tieneConclusionEnProceso(new HashMap<String, Object>()).get("FEC_DECLARACION"), "NO_FOUND");
  }
}
