package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;


import java.math.BigDecimal;


/**
 * La Class SumaFOBSeriesTipSeguro2PorDocTransporteBean.
 * es usado en el calculo de prorrateo de flete.
 *
 * @author amancillaa
 * @version 1.0
 * @since 06/05/2013
 */
public class SumaFOBSeriesTipSeguro2PorDocTransporteBean
{

  private String     docTransporte;
  private BigDecimal sumaFOB;

  /********************* SET AND GET ***************************/

  public BigDecimal getSumaFOB()
  {
    return sumaFOB;
  }


  public void setSumaFOB(BigDecimal sumaFOB)
  {
    this.sumaFOB = sumaFOB;
  }


  public String getDocTransporte()
  {
    return docTransporte;
  }


  public void setDocTransporte(String docTransporte)
  {
    this.docTransporte = docTransporte;
  }

}
