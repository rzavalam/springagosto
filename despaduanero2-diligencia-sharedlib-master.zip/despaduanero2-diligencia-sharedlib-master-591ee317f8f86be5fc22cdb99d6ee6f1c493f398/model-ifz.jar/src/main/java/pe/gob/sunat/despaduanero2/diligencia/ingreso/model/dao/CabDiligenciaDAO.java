package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.AccionesDespachoBean;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.RegularizacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Diligencia;
import pe.gob.sunat.despaduanero2.diligencia.salida.bean.UnidadSeleccionDiligenciaSalida;


/**
 * The Interface CabDiligenciaDAO.
 */
@SuppressWarnings({ "rawtypes" })
public interface CabDiligenciaDAO
{

  /**
   * Retorna todas las diligencias mostradas en la consulta de incidencias
   * no usar este metodo esta muy customizado.
   *
   * @param PkDocu
   *          the pk docu
   * @return the list
   */

  public List<Map<String, Object>> findByDocumento(Map<String, String> pkDocumento);


  /**
   * Retorna el historico de sustentos para la diligencia de despacho.
   *
   * @param PkDocu
   *          [Map<String,String>] pk docu
   * @return Lista de sustentos modificados
   */
  public List<Map<String, Object>> getDiligenciaDespachoSustentoModificado(Map<String, String> PkDocu);

  /**
   * Inserta una diligencia en la BD
   * @param params Diligencia a insertar
   */
  public void insert(Map<String, Object> params);

  /**
   * Actualiza una diligencia en forma selectiva
   * @param params Diligencia a actualizar
   */
  public void update(Map<String, Object> params);

  /**
   * Obtiene el numero de diligencias realizadas a un documento DUA
   * @param params parametros de busqueda
   * @return numero de diligencias realizadas
   */
  public Integer count(Map<String, Object> params);

  /**
   * Metodo que sirve para validar si la declaraci?n tiene alguna
   * solicitud del especialista para cambio de canal(01) o solicitud de
   * ampliaci?n de plazo (04).
   * @param params
   * @return
   */
  public Map<String, Object> tieneSolicitudesXEspecialista(Map<String, Object> params);

  /**
   * Metodo que sirve para validar si la declaraci?n tiene solicitud
   * de ampliaci?n de plazo (04).
   * @param params
   * @return
   */
  public Map<String, Object> findTieneAmpliacionPlazo(Map<String, Object> params);


  /**
   * Verifica si la declaracion ya ha sido diligencia mediante su num_corredoc.
   *
   * @param numCorredoc
   *          the num corredoc
   * @return Map<String, Object> Contiene el num_corredoc de la declaracion en
   *         caso este diligencia sino retorna null.
   */
  public Map<String, Object> findDuaDiligenciada(String numCorredoc);

  /**
   * <p>
   * consulta de plazo y conclusion
   * </p>
   * .
   *
   * @param params
   *          the params
   * @return the list
   * @author fduartej
   */
  public List<Map> findPlazoConclusion(Map<String, Object> params);

  /**
   * Verifica si la declaracion ya ha sido rectificada mediante su num_corredoc
   * y retorna la ultima rectificacion diligenciada.
   *
   * @param numCorredoc
   *          the num corredoc
   * @return Map<String, Object> Contiene el NUM_CORREDOC, FEC_DILIGENCIA y
   *         DES_RESULTADO de la declaracion en caso este diligencia sino
   *         retorna null.
   */
  public Map<String, Object> findDuaRectificada(String numCorredoc);


  /**
   * Busca la primera diligencia realizada a un documento
   * @param params numCorreDoc
   * @return
   */
  public Map<String, Object> findPrimeraDiligencia(Map<String, Object> params);

  /**
   * Busca la ultima diligencia realizada a un documento
   * @param params numCorreDoc
   * @return
   */
  public Map<String, Object> findUltimaDiligencia(Map<String, Object> params);

  /**
   * Busca una diligencia por su primary key
   * @param diligencia
   * @return
   */
  public Diligencia findByPrimaryKey(Diligencia diligencia);


  /**
   * Obtiene el tipo de diligencia.
   * tambien es invocado desde el TRANSFORMADOR
   *
   * @param params
   *          the params
   * @return tipo de diligencia
   */
   public String obtenerTipoDiligencia(Map<String, Object> params);



   /**
     * Ultimo num corre doc sol.
     *
     * @param params
     *          [Map<String,Object>] params
     * @return [Integer] integer
     * @author amancillaa
     * @version 1.0
     */
   public Integer ultimoNumCorreDocSol(Map<String, Object> params);

    /**
     * Count max by num corre doc and tipod and date.
     *
     * @param params
     *          [Map<String,Object>] params
     * @return [Integer] integer
     * @author amancillaa
     * @version 1.0
     */
    public Integer countMaxByNumCorreDocAndTipodAndDate(Map<String, Object> params);

    /**
     * Select.
     *
     * @param mapPK
     *          [Map<String,Object>] map pk
     * @return [List<Map<String,Object>>] list
     * @author amancillaa
     * @version 1.0
     */
    public List<Map<String, Object>> select(Map<String, Object> mapPK);


    /**
     * 04/03/2010: Metodo que sirve para si la declaracion tiene diligencia de
     * acuerdo al tipo enviado.
     *
     * @param params
     *          the params
     * @return Map<String, Object>
     * @author lsuclupe
     * @see
     */
    public Map<String, Object> findTieneDeclaracionDiligenciaTipo(Map<String, Object> params);

/*INICIO-RIN13*/
    /**
	 * Verifica si existe diligencia
	 * @param diligencia Diligencia a verificar
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
    public boolean hasDiligencia(Diligencia diligencia);
    
    /**
	 * Verifica si existe diligencia
	 * @param params Parametros de b�squeda
	 * @return true si existe y false no existe
	 * @author gbecerrav
	 */
    public boolean hasDiligenciaByParameterMap(Map<String, Object> params);
    
    /**
	 * Inserta un registro de diligencia 
	 * con campos selectivos
	 * @param diligencia Diligencia a registrar
	 * @return 
	 * @author gbecerrav
	 */
    public void insertSelective(Diligencia diligencia);
/*FIN-RIN13*/
    
    // FIXME: CUS110301 lpalominom [inicio]
    
    /**
     * Permite obtener los parametros considerados para la validacion del registro de la modificacion de la regularizacion
     * @param params [NUM_CORREDOC, COD_TIPDILIGENCIA]
     * @return
     */
    public RegularizacionBean obtenerParametrosActualizacionRegularizacion(Map<String, Object> params);
	
    // FIXME: CUS110301 lpalominom [fin]
    
    /***** GGRANADOS RIN16PASE3 INI *****/
    public void insert(Diligencia diligencia);
    /***** GGRANADOS RIN16PASE3 FIN *****/
    
    //RTINEO: 24/12/2014: RINMEJORASPROCESOSSDA
    public Map<String, Object> findUltimaDiligenciaConPlazoProceso(Map<String, Object> params);
    //RTINEO FIN
    
    // Diligencia-01 modificado
    public List<Diligencia> getAccionesDiligencia(Map<String, Object> params);
    
    public List<AccionesDespachoBean> getAccionesDespacho(String codigoNumeracionDAM);
    
    // Diligencia-01 rectificacion de diligencia
    public List<UnidadSeleccionDiligenciaSalida> getUnidadesSeleccionDiligenciaSalida(Long numeroCorrelativoDAM);

    /**PAS20181U220200073
     * Busca una diligencia por numCorredoc
     * o todas sus pk
     * @param diligencia
     * @return
     */
    public Diligencia findAllDiligenciaByPK(Map<String, Object> params);
}
