package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

/**
 * The Interface TabBolQuimDAO.
 */
@SuppressWarnings({ "rawtypes" })
public interface TabBolQuimDAO
{

  /**
   *
   * @param params
   * @return
   */
  public List<Map> joinDetDeclaraFindByDeclaracion(Map<String, Object> params);

  /**
   *
   * @param pkDeclaracion
   * @return
   */
  public List findPendConcluByDeclaracion(Map<String, Object> pkDeclaracion);

  /**
   * Metodo que permite obtener los Boletin Quimico de una determinada
   * Declaracion.
   * @param pkDeclaracion
   * @return
   */
  public List<Map<String, Object>> findByDeclaracion(Map<String, Object> pkDeclaracion);

  /**
   * Actualiza un Boletin Quimico
   * @param params Boletin Quimico a actyalizar
   */
  public void update(Map<String, Object> params);
  
  public List<Map<String, Object>> findByDeclaracionForAsignacionAutomatica(Map<String, Object> PkDecla);
  
  /**  P44 - INI - JYC
   *   Permitir� buscar el ultimo bolet�n qu�mico concluido de una determinada DUA:
   */
  public List<Map<String, Object>> buscarFechaBoletinQuimicoConcluido(Map<String, Object> parametros);
  /**  P44 - FIN - JYC */

}
