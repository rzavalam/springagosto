package pe.gob.sunat.despaduanero2.multa.model.dao;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;


/* RIN15 - f2 3011 - Inicio - lrodriguezc */
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.MultaDua;
/* RIN15 - f2 3011 - Fin - lrodriguezc */

/**
 * The Interface MultaDuaDAO.
 */
public interface MultaDuaDAO
{


  /**
   * Inserta de manera selectiva una multa en la BD
   * @param record Registro a insertar
   */
  void insertSelective(Map<String, Object> record);

  /* RIN15 - f2 3011 - Inicio - lrodriguezc */
  /** M�todo que devuelve las multas por DUA
   * @author lrodriguezc
   * @param params Mapa de par�metros en la busqueda de las multas por DUA
   * @return
   */
  public List<MultaDua> listMultaDUA (Map<String, Object> paramMulta);
  /* RIN15 - f2 3011 - Fin - lrodriguezc */
  
/*RIN13FSW*/
  /*jlunah*/
  public List<Map<String,Object>> buscaMismaInfraccionEnOtraDiligencia(Map<String,Object> parametros) throws ServiceException;

}