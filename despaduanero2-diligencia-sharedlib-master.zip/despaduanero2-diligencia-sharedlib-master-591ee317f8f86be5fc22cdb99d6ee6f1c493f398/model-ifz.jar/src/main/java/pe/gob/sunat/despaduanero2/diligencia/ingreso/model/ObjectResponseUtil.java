package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;

/**
 * Permite enviar datos desde respuesta.
 * @author amancilla
 *
 */
public class ObjectResponseUtil implements Serializable {

  private static final long serialVersionUID = 1L;
  private List<MensajeBean> mensajes;
  private Map<String, Object> datos;
/*INICIO-RIN13*/  
  private boolean respuesta;

  public ObjectResponseUtil(){
  }
/*FIN-RIN13*/  
  public ObjectResponseUtil(String mensaje){

	  addMensaje(mensaje);
  }

  public ObjectResponseUtil(String key, Object objeto){

	  addDato(key, objeto);
  }

  /**
   * Permite indicar si el objeto respuesta posee algun error dentro de sus mensajes.
   * @return
   */
  public Boolean poseeError(){
    Boolean bandera= false;
    if(!CollectionUtils.isEmpty(mensajes)){
      for(MensajeBean bean: mensajes){
        if(bean.isError()){
          bandera = true;
          break;
        }
      }
    }
    return bandera;
  }
  /**
   * Permite adherir un mensaje a la lista de mensajes del Objeto respuesta.
   * @param mBean
   */
  public void addMensaje(MensajeBean mBean){
    if(CollectionUtils.isEmpty(mensajes)){
      mensajes= new ArrayList<MensajeBean>();
    }
    mensajes.add(mBean);
  }

  /**
   * Permite agregar una advertencia o una validacion de negocio
   * @param mensaje
   */
  public void addMensaje(String mensaje){
	  MensajeBean mBean = new MensajeBean();
	  mBean.setError(true);
	  mBean.setMensajeerror(mensaje);
	  addMensaje(mBean);
  }

/*INICIO-RIN13*/  

  /**
   * Permite agregar una advertencia o una validacion de negocio
   * @param mensaje
   */
  public void addMensaje(String mensaje, String titulo, boolean tipoError){
	  MensajeBean mBean = new MensajeBean();
	  mBean.setError(tipoError);
	  mBean.setMensajeerror(mensaje);
	  mBean.setMensajesol(titulo);
	  addMensaje(mBean);
  }

/*FIN-RIN13*/  
  
  /**
   * Pemite adherir un dato al objeto respuesta.
   * @param key
   * @param objeto
   */
  public void addDato(String key, Object objeto){
    if(CollectionUtils.isEmpty(datos)){
      datos= new HashMap<String, Object>();
    }
    datos.put(key, objeto);
  }

  public List<MensajeBean> getMensajes() {
    return mensajes;
  }
  public void setMensajes(List<MensajeBean> mensajes) {
    this.mensajes = mensajes;
  }
  public Map<String, Object> getDatos() {
    return datos;
  }
  public void setDatos(Map<String, Object> datos) {
    this.datos = datos;
  }
/*INICIO-RIN13*/  
  public boolean isRespuesta() {
    return respuesta;
  }
  public void setRespuesta(boolean respuesta) {
    this.respuesta = respuesta;
  }
/*FIN-RIN13*/  
}
