package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;

public class EntidadRelacionesXml implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 8101241712815758508L;

    private String entidad="";
    private String tipo="";

    public String getEntidad() {
        return entidad;
    }
    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "EntidadRelacionesXml [relacionEntidad=" + entidad + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((entidad == null) ? 0 : entidad.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EntidadRelacionesXml other = (EntidadRelacionesXml) obj;
        if (entidad == null) {
            if (other.entidad != null)
                return false;
        } else if (!entidad.equals(other.entidad))
            return false;
        return true;
    }

}
