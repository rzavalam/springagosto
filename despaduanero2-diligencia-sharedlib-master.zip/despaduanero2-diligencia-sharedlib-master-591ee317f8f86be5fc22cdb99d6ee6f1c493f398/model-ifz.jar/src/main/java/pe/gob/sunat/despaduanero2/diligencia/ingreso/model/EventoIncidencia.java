package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;




import java.lang.Integer;
import java.lang.String;


/**
 * Catalogo de Incidencia identificadas en funcion a la actualizacion de la
 * informacion en la Declaracion
 *
 * @author amancillaa
 **/
public class EventoIncidencia
{

    /**
     * Numero de secuencia de la incidencia por evento
     *
     **/
    private Integer      numSecuencia;

    /** Codigo de incidencia (catalogo 336) */
    private String codIncidencia;


    /**
     * Descripcion adicional de la incidencia por nombre del campo
     *
     **/
    private String       descripcionEvento;

    /**
     * Nombre de la tabla del campo que se observa
     * en base a determinadas acciones
     **/
    private String       nombreTabla;

    /**
     * campo de la tabla observada en base a determinadas acciones
     */
    private String       nombreCampo;


    /**
     * accion ADD que debe de ejecutarse para activar el evento
     * del campo registrado S y N
     */
    private String eventoRegistrarCampo;

    /**
     * accion DELETE que debe de ejecutarse para activar el evento
     * del campo registrado  S y N
     */
    private String eventoEliminadoCampo;

    /**
     * accion MODIFY que debe de ejecutarse para activar el evento
     * del campo registrado  S y N
     */
    private String eventoModificadoCampo;


    /**
     * Array nombre de Campos
     **/
    private String nombreCampoCondicion;

    /**
     * Array de los valores de los campos condicion
     **/
    private String valorCampoCondicion;


    /**
     * Indica si el evento se ejecuta con incidencia tributario
     * S y N
     **/
    private String incidenciaTributaria;


    /**
     * Orden de prioridad 0 a +
     * cero de maryor prioridad el origen del evento
     * 1 es el sgte evento
     **/
    private Integer prioridadEvento;

    /**
     * enlaza a una sgte evento recursivamente para anidar
     * eventos
     **/
    private Integer numSecSgteEvento;



    /**
     * Eliminado logico del registro
     * 0 activo
     * 1 eliminado
     */
    private String eliminadoLogico;

    /******************** CONSTRUCTORES ***************************/

    public EventoIncidencia(){
        super();
      }

    /********************* SET AND GET ***************************/

    public String getEliminadoLogico() {
        return eliminadoLogico;
    }

    public void setEliminadoLogico(String eliminadoLogico) {
        this.eliminadoLogico = eliminadoLogico;
    }

    public Integer getNumSecSgteEvento() {
        return numSecSgteEvento;
    }

    public void setNumSecSgteEvento(Integer numSecSgteEvento) {
        this.numSecSgteEvento = numSecSgteEvento;
    }

    public Integer getPrioridadEvento() {
        return prioridadEvento;
    }

    public void setPrioridadEvento(Integer prioridadEvento) {
        this.prioridadEvento = prioridadEvento;
    }

    public String getIncidenciaTributaria() {
        return incidenciaTributaria;
    }

    public void setIncidenciaTributaria(String incidenciaTributaria) {
        this.incidenciaTributaria = incidenciaTributaria;
    }

    public String getValorCampoCondicion() {
        return valorCampoCondicion;
    }

    public void setValorCampoCondicion(String valorCampoCondicion) {
        this.valorCampoCondicion = valorCampoCondicion;
    }

    public String getNombreCampoCondicion() {
        return nombreCampoCondicion;
    }

    public void setNombreCampoCondicion(String nombreCampoCondicion) {
        this.nombreCampoCondicion = nombreCampoCondicion;
    }

    public String getEventoModificadoCampo() {
        return eventoModificadoCampo;
    }

    public void setEventoModificadoCampo(String eventoModificadoCampo) {
        this.eventoModificadoCampo = eventoModificadoCampo;
    }

    public String getEventoEliminadoCampo() {
        return eventoEliminadoCampo;
    }

    public void setEventoEliminadoCampo(String eventoEliminadoCampo) {
        this.eventoEliminadoCampo = eventoEliminadoCampo;
    }

    public String getEventoRegistrarCampo() {
        return eventoRegistrarCampo;
    }

    public void setEventoRegistrarCampo(String eventoRegistrarCampo) {
        this.eventoRegistrarCampo = eventoRegistrarCampo;
    }

    public String getNombreCampo() {
        return nombreCampo;
    }

    public void setNombreCampo(String nombreCampo) {
        this.nombreCampo = nombreCampo;
    }

    public String getNombreTabla() {
        return nombreTabla;
    }

    public void setNombreTabla(String nombreTabla) {
        this.nombreTabla = nombreTabla;
    }

    public String getDescripcionEvento() {
        return descripcionEvento;
    }

    public void setDescripcionEvento(String descripcionEvento) {
        this.descripcionEvento = descripcionEvento;
    }


    public Integer getNumSecuencia() {
        return numSecuencia;
    }

    public void setNumSecuencia(Integer numSecuencia) {
        this.numSecuencia = numSecuencia;
    }

    public String getCodIncidencia() {
        return codIncidencia;
    }

    public void setCodIncidencia(String codIncidencia) {
        this.codIncidencia = codIncidencia;
    }

}