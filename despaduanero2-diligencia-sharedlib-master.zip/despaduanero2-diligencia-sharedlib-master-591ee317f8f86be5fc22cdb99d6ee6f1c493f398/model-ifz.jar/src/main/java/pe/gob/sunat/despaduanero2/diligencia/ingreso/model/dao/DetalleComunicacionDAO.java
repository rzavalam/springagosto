/* Creado - P14 - 3014 - Inicio - dhernandezv */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.DetalleComunicacion;

/**
 * The Interface DetalleComunicacionDAO.
 */
public interface DetalleComunicacionDAO
{
	
	/**
	 * Busca los detalles de las notificaciones
	 *
	 * @param notificacion parametro a realizar la busqueda
	 * @return Listado de Detalles de notificacion
	 */
	public List<DetalleComunicacion> findDetalleComunicacionNotificacion(DetalleComunicacion notificacion);
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	/** Obtiene el siguiente correlativo del detalle de notificaci�n
	 * @author lrodriguezc
	 * @return
	 */
	public Long obtenerSiguienteCorrelativo(Map<String, Object> params);
	
	/** Inserta el detalle de las comunicaciones
	 * @author lrodriguezc
	 * @param params
	 */
	public void insert(Map<String, Object> params);
	
	//ggranados 179
	/**
	 * Busca los detalles de las notificaciones Para declaracion de Oficio
	 *
	 * @param  Mapa con parametros
	 * @return Listado de Detalles de notificacion
	 */
	public List<DetalleComunicacion> findDetalleComunicacionNotificacionParaDeclaracionOficio(Map<String, Object> params);
	public void insertSelective(DetalleComunicacion notificacion);
	
	//rtineo PAS20155E220400065
	public List<DetalleComunicacion> selectDetalleNotificacionesEER(Map<String,Object> params);
	
	
}
