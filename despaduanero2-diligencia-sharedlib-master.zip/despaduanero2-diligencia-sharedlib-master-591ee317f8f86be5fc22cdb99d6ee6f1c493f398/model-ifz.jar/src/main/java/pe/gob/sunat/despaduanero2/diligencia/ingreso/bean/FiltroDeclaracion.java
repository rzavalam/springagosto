package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;

public class FiltroDeclaracion implements Serializable {

	/**
	 * Codigo del documento aduanero
	 */
	private String codDocumentoAduanero;
	
	/**
	 * C�digo de aduana
	 */
	private String codAduana;
	
	/**
	 * C�digo del R�gimen
	 */
	private String codRegimen;
	
	/**
	 * N�mero de la declaraci�n en tipo cadena
	 */
	private String strNumDeclaracion;
	
	/**
	 * N�mero de la declaraci�n
	 */
	private Long numDeclaracion;
	
	/**
	 * A�o de presentaci�n
	 */
	private Long annPresen;
	
	
	public String getCodDocumentoAduanero() {
		return codDocumentoAduanero;
	}

	public void setCodDocumentoAduanero(String codDocumentoAduanero) {
		this.codDocumentoAduanero = codDocumentoAduanero;
	}

	public String getCodAduana() {
		return codAduana;
	}

	public void setCodAduana(String codAduana) {
		this.codAduana = codAduana;
	}

	public String getCodRegimen() {
		return codRegimen;
	}

	public void setCodRegimen(String codRegimen) {
		this.codRegimen = codRegimen;
	}

	public Long getNumDeclaracion() {
		return numDeclaracion;
	}

	public void setNumDeclaracion(Long numDeclaracion) {
		this.numDeclaracion = numDeclaracion;
	}

	public Long getAnnPresen() {
		return annPresen;
	}

	public void setAnnPresen(Long annPresen) {
		this.annPresen = annPresen;
	}

	public String getStrNumDeclaracion() {
		return strNumDeclaracion;
	}

	public void setStrNumDeclaracion(String strNumDeclaracion) {
		this.strNumDeclaracion = strNumDeclaracion;
	}
	
	
	
}
