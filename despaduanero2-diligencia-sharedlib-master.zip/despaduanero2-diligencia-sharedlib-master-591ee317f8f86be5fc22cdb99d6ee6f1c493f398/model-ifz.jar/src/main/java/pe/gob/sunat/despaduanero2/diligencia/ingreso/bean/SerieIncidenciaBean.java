package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.math.BigDecimal;

/**
 * Created by amancilla on 16/09/2014.
 */
public class SerieIncidenciaBean {

    private Long nunmSecSerie;
    private boolean tieneInciTrib;
    private BigDecimal tasaPercecionOld;
    private BigDecimal tasaPercecionNew;
    private boolean tieneDiferenciaISC;
    private boolean tieneDiferenciaAdvaloren;
    private boolean tieneDiferenciaIGV;
    private boolean tieneDiferenciaPercepcion;
	private boolean tieneDiferenciaMayorAntiDumping;
	private boolean tieneDiferenciaDerechoEspecifico;
	private boolean tieneDiferenciaOtros;
    
    public SerieIncidenciaBean() {
		super();
		tasaPercecionOld = BigDecimal.ZERO;
		tasaPercecionNew = BigDecimal.ZERO;
	}

    public Long getNunmSecSerie() {
        return nunmSecSerie;
    }

    public void setNunmSecSerie(Long nunmSecSerie) {
        this.nunmSecSerie = nunmSecSerie;
    }

    public boolean tieneInciTrib() {
        return tieneInciTrib;
    }

    public void registrarInciTrib(boolean tieneInciTrib) {
        this.tieneInciTrib = tieneInciTrib;
    }

	public BigDecimal getTasaPercecionNew() {
		return tasaPercecionNew;
	}

	public void setTasaPercecionNew(BigDecimal tasaPercecionNew) {
		this.tasaPercecionNew = tasaPercecionNew;
	}

	public BigDecimal getTasaPercecionOld() {
		return tasaPercecionOld;
	}

	public void setTasaPercecionOld(BigDecimal tasaPercecionOld) {
		this.tasaPercecionOld = tasaPercecionOld;
	}

	public boolean tieneDiferenciaMayorAntiDumping() {
		return tieneDiferenciaMayorAntiDumping;
	}

	public void registrarDiferenciaMayorAntiDumping(
			boolean tieneDiferenciaMayorAntiDumping) {
		this.tieneDiferenciaMayorAntiDumping = tieneDiferenciaMayorAntiDumping;
	}
	

	public boolean tieneDiferenciaDerechoEspecifico() {
		return tieneDiferenciaDerechoEspecifico;
	}

	public void registrarDiferenciaDerechoEspecifico(boolean tieneDiferenciaDerechoEspecifico) {
		this.tieneDiferenciaDerechoEspecifico = tieneDiferenciaDerechoEspecifico;
	}
	

	public boolean tieneDiferenciaISC() {
		return tieneDiferenciaISC;
	}

	public void registrarDiferenciaISC(boolean tieneDiferenciaISC) {
		this.tieneDiferenciaISC = tieneDiferenciaISC;
	}

	public boolean tieneDiferenciaAdvaloren() {
		return tieneDiferenciaAdvaloren;
	}

	public void registrarDiferenciaAdvaloren(boolean tieneDiferenciaAdvaloren) {
		this.tieneDiferenciaAdvaloren = tieneDiferenciaAdvaloren;
	}
	
	public boolean tieneDiferenciaIGV() {
		return tieneDiferenciaIGV;
	}

	public void registrarDiferenciaIGV(boolean tieneDiferenciaIGV) {
		this.tieneDiferenciaIGV = tieneDiferenciaIGV;
	}
	
	public boolean tieneDiferenciaPercepcion() {
		return tieneDiferenciaPercepcion;
	}

	public void registrarDiferenciaPercepcion(boolean tieneDiferenciaPercepcion) {
		this.tieneDiferenciaPercepcion = tieneDiferenciaPercepcion;
	}

	public boolean tieneDiferenciaOtros() {
		return tieneDiferenciaOtros;
	}

	public void registrarDiferenciaOtros(boolean tieneDiferenciaOtros) {
		this.tieneDiferenciaOtros = tieneDiferenciaOtros;
	}
		    
}
