package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

public class RegularizacionBean implements Serializable {

	private static final long serialVersionUID = -3509221131316723385L;
	
	private Long numeroCorrelativo;
	private String tipoDiligencia;
	private String codigoFuncionario;
	private Date fechaDiligencia;
	private Date fechaActual;
	private String indicadorCambio;
	private Integer numeroDiligConclusionDespacho;
	private Integer numeroDiligRectElectronica;
	private Integer numeroDiligRectOficio;
	private String descripcionResultado;
	
	public Long getNumeroCorrelativo() {
		return numeroCorrelativo;
	}
	
	public void setNumeroCorrelativo(Long numeroCorrelativo) {
		this.numeroCorrelativo = numeroCorrelativo;
	}
	
	public String getTipoDiligencia() {
		return tipoDiligencia;
	}
	
	public void setTipoDiligencia(String tipoDiligencia) {
		this.tipoDiligencia = tipoDiligencia;
	}
	
	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}
	
	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}
	
	public Date getFechaDiligencia() {
		return fechaDiligencia;
	}
	
	public void setFechaDiligencia(Date fechaDiligencia) {
		this.fechaDiligencia = fechaDiligencia;
	}
	
	public Date getFechaActual() {
		return fechaActual;
	}
	
	public void setFechaActual(Date fechaActual) {
		this.fechaActual = fechaActual;
	}
	
	public String getIndicadorCambio() {
		return indicadorCambio;
	}
	
	public void setIndicadorCambio(String indicadorCambio) {
		this.indicadorCambio = indicadorCambio;
	}
	
	public Integer getNumeroDiligConclusionDespacho() {
		return numeroDiligConclusionDespacho;
	}
	
	public void setNumeroDiligConclusionDespacho(
			Integer numeroDiligConclusionDespacho) {
		this.numeroDiligConclusionDespacho = numeroDiligConclusionDespacho;
	}
	
	public Integer getNumeroDiligRectElectronica() {
		return numeroDiligRectElectronica;
	}
	
	public void setNumeroDiligRectElectronica(Integer numeroDiligRectElectronica) {
		this.numeroDiligRectElectronica = numeroDiligRectElectronica;
	}
	
	public Integer getNumeroDiligRectOficio() {
		return numeroDiligRectOficio;
	}
	
	public void setNumeroDiligRectOficio(Integer numeroDiligRectOficio) {
		this.numeroDiligRectOficio = numeroDiligRectOficio;
	}

	public String getDescripcionResultado() {
		return descripcionResultado;
	}

	public void setDescripcionResultado(String descripcionResultado) {
		this.descripcionResultado = descripcionResultado;
	}
	
}
