package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.*;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.ComunicacionDescripcion;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.NotificacionBean;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * The Interface ComunicacionDAO.
 */
public interface ComunicacionDAO{

	/**
	 * Busca las comunicaciones por numCorredoc y tipo de Diligencia
	 *
	 * @param pkDocumento  parametros a realizar la busqueda
	 * @return Listado de comunicaciones
	 */
	public List<Map<String, Object>> findByDiligenciaAndTipo(Map<String, String> pkDocumento);
	
	/**
	 * Obtiene el siguiente numero correlativo de la comunicacion
	 * 
	 * @return
	 */
	public Integer obtenerSiguienteCorrelativo();

	/**
	 * Insertar una comunicacion en la BD
	 * 
	 * @param params
	 * @return
	 */
	public Integer insertComunicacion(Map<String, Object> params);

	/**
	 * Busca comunicaciones por numCorreDoc
	 * 
	 * @param pkDocumento
	 * @return
	 */
	public List<Map<String, Object>> findByNumCorredoc(Map<String, Object> pkDocumento);

	/**
	 * Busca notificaciones de acuerdo a los parametros enviados
	 * 
	 * @param pkDocumento
	 * @return
	 */
	public List<Map<String, Object>> findNotificacionesByNumCorreDoc(Map<String, Object> pkDocumento);

	/**
	 * Obtiene el numero de secuencia de la tabla Comunicacion. tambien es
	 * invocado desde el TRANSFORMADOR
	 *
	 * @param params
	 *            the params
	 * @return tipo de diligencia
	 */
	public String obtenerNumeroSecuenciaComunicacion(Map<String, Object> params);

	/**
	 * Inserta un registro de comunicacion con campos selectivos
	 * 
	 * @param diligencia
	 *            Comunicacion a registrar
	 * @return
	 * @author gbecerrav
	 */
	public void insertSelective(Comunicacion comunicacion);

	public List<Map<String, Object>> buscarNotificacionRespondida(Map<String, Object> params);

	/**
	 * Obtiene las notificaciones de una declaracion determinada
	 *
	 * @param params
	 *
	 * @return List<Map<String,Object>>
	 * @throws ServiceException
	 */
	public List<ComunicacionDescripcion> obtenerNotificaciones(Map<String, Object> params);

	/**
	 * Obtiene las comunicaciones pendientes de acuerdo al n�mero correlativo de
	 * la declaraci�n
	 * 
	 * @author lrodriguezc
	 * @param numCorreDoc
	 * @return
	 */
	public List<ComunicacionDescripcion> findPendientesByNumCorreDoc(Long numCorreDoc);

	/**
	 * Actualiza las comunicaciones de tipo notificaci�n para las declaraciones
	 * 
	 * @author lrodriguezc
	 * @param params
	 */
	public void updateRespuestaComunicacionNotificacion(Map<String, Object> params);

	/**
	 * Obtiene un registro de comunicacion por su PK (NUM_NOTA)
	 * @param numNota
	 * @return
	 */
	Comunicacion selectNotificacionByID(Long numNota);
	
	/**
	 * Obtiene el listado de notificaciones de acuerdo a los parametros enviados
	 * @param params
	 * @return
	 */
	public List<Comunicacion> listNotificaciones(Map<String,Object> params);
	
	/**
	 * Actualiza el objeto comunicacion
	 * @param comunicacion
	 */
	public void updateComunicacion(Comunicacion comunicacion);
	
	/**
	 * reporte de la notificacion eer
	 * @param params
	 * @return
	 */
	public List<NotificacionBean> listConsultaNotificacionesEER(Map<String,Object> params);
	
}
