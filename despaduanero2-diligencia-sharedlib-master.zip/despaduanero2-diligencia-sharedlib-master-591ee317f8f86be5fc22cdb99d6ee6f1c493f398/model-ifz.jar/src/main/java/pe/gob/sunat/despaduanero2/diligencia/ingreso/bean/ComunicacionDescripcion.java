/* Creado - P14 - 3014 - Inicio - dhernandezv */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.Comunicacion;

public class ComunicacionDescripcion extends Comunicacion implements Serializable {

	/**
	 * Serial
	 * @author dhernandezv
	 */
	private static final long serialVersionUID = -8039166775878884420L;
	
	
	/**
	 * Constructor de la Clase ComunicacionDescripcion
	 * @author dhernandezv
	 */
	public ComunicacionDescripcion() {
		super();
	}

	
	/**
	 * Descripcion tipo de diligencia
	 * @author dhernandezv
	 */
	private String desTipoDiligencia;
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	/** Descripci�n del Motivo de Notificaci�n
	 * @author lrodriguezc
	 */
	private String desMotivoNotificacion;
	
	/** Descripci�n del Usuario de Registro
	 * @author lrodriguezc
	 */
	private String desUsuarioRegistro;
	
	/** Identificador de insercion en avisos 
	 * @author lrodriguezc
	 */
	private boolean indInsercionAviso = false;
	
	/* P14 - 3006 - Final - lrodriguezc */
	
	/**
	 * Obtenemos la descripcion del tipo de diligencia
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getDesTipoDiligencia() {
		return desTipoDiligencia;
	}

	/**
	 * Inicializamos la descripcion del tipo de diligencia
	 * @author dhernandezv
	 * @param desTipoDiligencia, Indicador de descripcion del tipo de diligencia
	 */	
	public void setDesTipoDiligencia(String desTipoDiligencia) {
		this.desTipoDiligencia = desTipoDiligencia;
	}
	
	/* P14 - 3006 - Inicio - lrodriguezc */
	
	/** Obtenemos la Descripci�n del Motivo de Notificaci�n
	 * @author lrodriguezc
	 * @return
	 */
	public String getDesMotivoNotificacion() {
		return desMotivoNotificacion;
	}
	
	/** Inicializamos la Descripci�n del Motivo de Notificaci�n
	 * @author lrodriguezc
	 * @param desMotivoNotificacion
	 */
	public void setDesMotivoNotificacion(String desMotivoNotificacion) {
		this.desMotivoNotificacion = desMotivoNotificacion;
	}
	
	/** Obtenemos la Descripci�n del Usuario de Registro
	 * @author lrodriguezc
	 * @return
	 */
	public String getDesUsuarioRegistro() {
		return desUsuarioRegistro;
	}
	
	/** Inicializamos la Descripci�n del Usuario de Registro
	 * @author lrodriguezc
	 * @param desUsuarioRegistro
	 */
	public void setDesUsuarioRegistro(String desUsuarioRegistro) {
		this.desUsuarioRegistro = desUsuarioRegistro;
	}

	/** Verificamos el estado del indicador de insercion en avisos 
	 * @author dhernandezv
	 * @return
	 */
	public boolean isIndInsercionAviso() {
		return indInsercionAviso;
	}
	
	/** Inicializamos el identificador de insercion en avisos 
	 * @author dhernandezv
	 * @param insercionAviso
	 */
	public void setIndInsercionAviso(boolean indInsercionAviso) {
		this.indInsercionAviso = indInsercionAviso;
	}
	
	/* P14 - 3006 - Final - lrodriguezc */
	
}
