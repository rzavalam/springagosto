package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;


/**
 * The Interface MedioTransDAO.
 */
public interface MedioTransDAO
{

  /**
   * Busca un Medio de Transporte por numCorreDoc
   * @param pkDocumento
   * @return
   */
 public List<Map<String, String>> findByDocumento(Map<String, String> pkDocumento);

}
