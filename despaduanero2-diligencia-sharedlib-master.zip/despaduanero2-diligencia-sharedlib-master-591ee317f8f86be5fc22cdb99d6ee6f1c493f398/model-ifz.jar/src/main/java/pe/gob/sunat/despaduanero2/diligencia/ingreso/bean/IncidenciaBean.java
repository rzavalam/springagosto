package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;


import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class IncidenciaBean implements Serializable
{
  private static final long serialVersionUID = -5885438070534854194L;

  private Integer                   num_secuencia;

  private String                    cod_incidencia;

  private String                    des_adicional;

  private String                    des_tabla;

  private String                    des_campo;

  private String                    val_anterior;

  private String                    val_actual;

  private String                    val_condicion;

  private String                    nom_campo_condi;

  private List<String>              itemsList;

  private Map<String, Object>       cabAnteriorMap;

  private Map<String, Object>       cabActualMap;

  private List<Map<String, Object>> detAnteriorList;

  private List<Map<String, Object>> detActualList;

  private String                    entidadMaestro;

  private String                    entidadDetalle;

  private Boolean                   flagIncidencia;

  public Integer getNum_secuencia()
  {
    return num_secuencia;
  }

  public void setNum_secuencia(Integer numSecuencia)
  {
    num_secuencia = numSecuencia;
  }

  public String getCod_incidencia()
  {
    return cod_incidencia;
  }

  public void setCod_incidencia(String codIncidencia)
  {
    cod_incidencia = codIncidencia;
  }

  public String getDes_adicional()
  {
    return des_adicional;
  }

  public void setDes_adicional(String desAdicional)
  {
    des_adicional = desAdicional;
  }

  public String getDes_tabla()
  {
    return des_tabla;
  }

  public void setDes_tabla(String desTabla)
  {
    des_tabla = desTabla;
  }

  public String getDes_campo()
  {
    return des_campo;
  }

  public void setDes_campo(String desCampo)
  {
    des_campo = desCampo;
  }

  public String getVal_anterior()
  {
    return val_anterior;
  }

  public void setVal_anterior(String valAnterior)
  {
    val_anterior = valAnterior;
  }

  public String getVal_actual()
  {
    return val_actual;
  }

  public void setVal_actual(String valActual)
  {
    val_actual = valActual;
  }

  public String getVal_condicion()
  {
    return val_condicion;
  }

  public void setVal_condicion(String valCondicion)
  {
    val_condicion = valCondicion;
  }

  public String getNom_campo_condi()
  {
    return nom_campo_condi;
  }

  public void setNom_campo_condi(String nomCampoCondi)
  {
    nom_campo_condi = nomCampoCondi;
  }

  public List<String> getItemsList()
  {
    return itemsList;
  }

  public void setItemsList(List<String> itemsList)
  {
    this.itemsList = itemsList;
  }

  public Map<String, Object> getCabAnteriorMap()
  {
    return cabAnteriorMap;
  }

  public void setCabAnteriorMap(Map<String, Object> cabAnteriorMap)
  {
    this.cabAnteriorMap = cabAnteriorMap;
  }

  public Map<String, Object> getCabActualMap()
  {
    return cabActualMap;
  }

  public void setCabActualMap(Map<String, Object> cabActualMap)
  {
    this.cabActualMap = cabActualMap;
  }

  public List<Map<String, Object>> getDetAnteriorList()
  {
    return detAnteriorList;
  }

  public void setDetAnteriorList(List<Map<String, Object>> detAnteriorList)
  {
    this.detAnteriorList = detAnteriorList;
  }

  public List<Map<String, Object>> getDetActualList()
  {
    return detActualList;
  }

  public void setDetActualList(List<Map<String, Object>> detActualList)
  {
    this.detActualList = detActualList;
  }

  public String getEntidadMaestro()
  {
    return entidadMaestro;
  }

  public void setEntidadMaestro(String entidadMaestro)
  {
    this.entidadMaestro = entidadMaestro;
  }

  public String getEntidadDetalle()
  {
    return entidadDetalle;
  }

  public void setEntidadDetalle(String entidadDetalle)
  {
    this.entidadDetalle = entidadDetalle;
  }

  public Boolean getFlagIncidencia()
  {
    return flagIncidencia;
  }

  public void setFlagIncidencia(Boolean flagIncidencia)
  {
    this.flagIncidencia = flagIncidencia;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("\nIncidenciaBean [\n  cabActualMap: ");
    builder.append(cabActualMap);
    builder.append("\n  cabAnteriorMap: ");
    builder.append(cabAnteriorMap);
    builder.append("\n  cod_incidencia: ");
    builder.append(cod_incidencia);
    builder.append("\n  des_adicional: ");
    builder.append(des_adicional);
    builder.append("\n  des_campo: ");
    builder.append(des_campo);
    builder.append("\n  des_tabla: ");
    builder.append(des_tabla);
    builder.append("\n  detActualList: ");
    builder.append(detActualList);
    builder.append("\n  detAnteriorList: ");
    builder.append(detAnteriorList);
    builder.append("\n  entidadDetalle: ");
    builder.append(entidadDetalle);
    builder.append("\n  entidadMaestro: ");
    builder.append(entidadMaestro);
    builder.append("\n  flagIncidencia: ");
    builder.append(flagIncidencia);
    builder.append("\n  itemsList: ");
    builder.append(itemsList);
    builder.append("\n  nom_campo_condi: ");
    builder.append(nom_campo_condi);
    builder.append("\n  num_secuencia: ");
    builder.append(num_secuencia);
    builder.append("\n  val_actual: ");
    builder.append(val_actual);
    builder.append("\n  val_anterior: ");
    builder.append(val_anterior);
    builder.append("\n  val_condicion: ");
    builder.append(val_condicion);
    builder.append("\n]");
    return builder.toString();
  }

}
