package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;

public class Consulta implements Serializable {

	/**
	 * N�mero de serializaci�n
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * N�mero correlativo del documento
	 */
	private Long numcorredoc;

	/**
	 * N�mero de secuencia
	 */
	private Integer numeroSecuencia;

	/**
	 * Tipo de diligencia
	 */
	private String tipoDiligencia;

	/**
	 * Numero correlativo de solicitud
	 */
	private Long numcorredocSol;

	/**
	 * C�digo del funcionario
	 */
	private CatEmpleado funcionario;

	/**
	 * C�digo del aprobador
	 */
	private CatEmpleado aprobador;
	
	/**
	 * Fecha de concluci�n propuesta por el funcionario
	 */
	private Date fechaConcluPropuesta;

	/**
	 * Descripci�n de la consulta
	 */
	private String descripcion;

	/**
	 * Motivos de la consulta en json
	 */
	private String strMotivos;

	/**
	 * Motivos de la consulta
	 */
	private ArrayList<DataCatalogo> motivos;

	/**
	 * Indicador si se cargan la lista de motivos
	 */
	private boolean flagMotivos;

	/**
	 * Indicador de respuesta
	 */
	private String indicadorRespuesta;

	/**
	 * Descripci�n de la respuesta a la consulta
	 */
	private String descripcionRespuesta;

	/**
	 * Fecha de registro
	 */
	private Timestamp fechaRegistro;

	/**
	 * Fecha de respuesta
	 */
	private Timestamp fechaRespuesta;

	/**
	 * Fecha de registro en formato String
	 */
	private String strFechaRegistro;

	/**
	 * Fecha de registro en string
	 */
	private String strFechaRespuesta;
	
	/**
	 * Catalogo de los motivos de la consulta
	 */
	private DataCatalogo catalogoMotivos;

	
	public Long getNumcorredoc() {
		return numcorredoc;
	}

	public void setNumcorredoc(Long numcorredoc) {
		this.numcorredoc = numcorredoc;
	}

	public Integer getNumeroSecuencia() {
		return numeroSecuencia;
	}

	public void setNumeroSecuencia(Integer numeroSecuencia) {
		this.numeroSecuencia = numeroSecuencia;
	}

	public String getTipoDiligencia() {
		return tipoDiligencia;
	}

	public void setTipoDiligencia(String tipoDiligencia) {
		this.tipoDiligencia = tipoDiligencia;
	}

	public Long getNumcorredocSol() {
		return numcorredocSol;
	}

	public void setNumcorredocSol(Long numcorredocSol) {
		this.numcorredocSol = numcorredocSol;
	}

	public CatEmpleado getFuncionario() {
		if (funcionario == null)
			funcionario = new CatEmpleado();
		return funcionario;
	}

	public void setFuncionario(CatEmpleado funcionario) {
		this.funcionario = funcionario;
	}

	public Date getFechaConcluPropuesta() {
		return fechaConcluPropuesta;
	}

	public void setFechaConcluPropuesta(Date fechaConcluPropuesta) {
		this.fechaConcluPropuesta = fechaConcluPropuesta;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getStrMotivos() {
		return strMotivos;
	}

	public void setStrMotivos(String strMotivos) {
		this.strMotivos = strMotivos;
	}

	public String getIndicadorRespuesta() {
		return indicadorRespuesta;
	}

	public ArrayList<DataCatalogo> getMotivos() {
		if (motivos == null) {
			motivos = new ArrayList<DataCatalogo>();
		}
		return motivos;
	}

	public void setMotivos(ArrayList<DataCatalogo> motivos) {
		this.motivos = motivos;
	}

	public void setIndicadorRespuesta(String indicadorRespuesta) {
		this.indicadorRespuesta = indicadorRespuesta;
	}

	public Timestamp getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Timestamp fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getStrFechaRegistro() {
		return strFechaRegistro;
	}

	public void setStrFechaRegistro(String strFechaRegistro) {
		this.strFechaRegistro = strFechaRegistro;
	}

	public boolean isFlagMotivos() {
		return flagMotivos;
	}

	public void setFlagMotivos(boolean flagMotivos) {
		this.flagMotivos = flagMotivos;
	}

	public String getDescripcionRespuesta() {
		return descripcionRespuesta;
	}

	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}

	public Timestamp getFechaRespuesta() {
		return fechaRespuesta;
	}

	public void setFechaRespuesta(Timestamp fechaRespuesta) {
		this.fechaRespuesta = fechaRespuesta;
	}

	public String getStrFechaRespuesta() {
		return strFechaRespuesta;
	}

	public void setStrFechaRespuesta(String strFechaRespuesta) {
		this.strFechaRespuesta = strFechaRespuesta;
	}

	public DataCatalogo getCatalogoMotivos() {
		if (catalogoMotivos == null) {
			catalogoMotivos = new DataCatalogo();
		}
		return catalogoMotivos;
	}

	public void setCatalogoMotivos(DataCatalogo catalogoMotivos) {
		this.catalogoMotivos = catalogoMotivos;
	}

	public CatEmpleado getAprobador() {
		if (aprobador == null)
			aprobador = new CatEmpleado();		
		return aprobador;
	}

	public void setAprobador(CatEmpleado aprobador) {
		this.aprobador = aprobador;
	}

}
