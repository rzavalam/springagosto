/* Creado - P14 - 3014 - Inicio - dhernandezv */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;
import java.util.Date;

public class Comunicacion implements Serializable {
	private Long numeroNota;
	private String codigoNota;
	private String descripcionNota;
	private Diligencia diligencia;
	
	//rtineo PAS20155E220400065
	private Long numeroCorrelativoSolicitud;
	private String codigoFuncionario;
	private String codigoAprobador;
	private String codigoEstadoNotificacion;
	private String observacionRespuestaNotificacion;
	private Date fechaRespuestaNotificacion;
	private Date fechaModificacion;
	
	/**
	 * Serial
	 * 
	 * @author dhernandezv
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor de la Clase Comunicacion
	 * 
	 * @author dhernandezv
	 */
	public Comunicacion() {
		super();
	}
	
	public Comunicacion(boolean registro) {
		this.diligencia = new Diligencia();
	}
	
	/**
	 * Codigo Motivo Notificacion
	 * 
	 * @author dhernandezv
	 */
	private String codMotNoti;

	/**
	 * Codigo de Nota
	 * 
	 * @author dhernandezv
	 */
	private String codNota;

	/**
	 * Codigo Tipo Diligencia
	 * 
	 * @author dhernandezv
	 */
	private String codTiDiligencia;

	/**
	 * Codigo Usuario Modificacion
	 * 
	 * @author dhernandezv
	 */
	private String codUsuModificacion;

	/**
	 * Codigo Usuario Registro
	 * 
	 * @author dhernandezv
	 */
	private String codUsuRegistro;

	/**
	 * Descripcion de Nota
	 * 
	 * @author dhernandezv
	 */
	private String desNota;

	/**
	 * Fecha de Modificacion
	 * 
	 * @author dhernandezv
	 */
	private Date feModificacion;

	/**
	 * Fecha de Recepcion de la Respuesta de Notificacion
	 * 
	 * @author dhernandezv
	 */
	private Date feRecRespNoti;

	/**
	 * Fecha de Registro
	 * 
	 * @author dhernandezv
	 */
	private Date feRegistro;
	
	/* P14 - 3006 - mpoblete BUG 19143 - Inicio */
	
	/**
	 * Fecha de Registro en formato dd/mm/aaaa hh:mm:ss 
	 * 
	 * @author mpoblete
	 */	
	private String fecRegistroString;
	/* P14 - 3006 - mpoblete BUG 19143 - fin */

	/**
	 * N�mero Correlativo de Documento
	 * 
	 * @author dhernandezv
	 */
	private Long numCorreDoc;

	/**
	 * N�mero correlativo de Documento Solicitud
	 * 
	 * @author dhernandezv
	 */
	private Long numCorreDocSol;

	/**
	 * N�mero de Folio de Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 */
	private Long numFolioRptaNoti;

	/**
	 * N�mero de Nota
	 * 
	 * @author dhernandezv
	 */
	private Long numNota;

	/**
	 * Observacion Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 */
	private String obsRptaNoti;

	/**
	 * Indicador detalle de descripcion de Notificacion
	 * 
	 * @author dhernandezv
	 */
	private String indDetDescNotificacion;

	/****************** GETTERS Y SETTERS ******************/

	/**
	 * Obtenemos el Codigo Motivo Notificacion
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodMotNoti() {
		return codMotNoti;
	}

	/**
	 * Inicializamos el Codigo Motivo Notificacion
	 * 
	 * @author dhernandezv
	 * @param codMotNoti
	 *            , Codigo Motivo Notificacion
	 */
	public void setCodMotNoti(String codMotNoti) {
		this.codMotNoti = codMotNoti;
	}

	/**
	 * Obtenemos el Codigo Nota
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodNota() {
		return codNota;
	}

	/**
	 * Inicializamos el Codigo Nota
	 * 
	 * @author dhernandezv
	 * @param codNota
	 *            , Codigo Nota
	 */
	public void setCodNota(String codNota) {
		this.codNota = codNota;
	}

	/**
	 * Obtenemos el Codigo Tipo Diligencia
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodTiDiligencia() {
		return codTiDiligencia;
	}

	/**
	 * Inicializamos el Codigo Tipo Diligencia
	 * 
	 * @author dhernandezv
	 * @param codTiDiligencia
	 *            , Codigo Tipo Diligencia
	 */
	public void setCodTiDiligencia(String codTiDiligencia) {
		this.codTiDiligencia = codTiDiligencia;
	}

	/**
	 * Obtenemos el Codigo Usuario Modificacion
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodUsuModificacion() {
		return codUsuModificacion;
	}

	/**
	 * Inicializamos el Codigo Usuario Modificacion
	 * 
	 * @author dhernandezv
	 * @param codUsuModificacion
	 *            , Codigo Usuario Modificacion
	 */
	public void setCodUsuModificacion(String codUsuModificacion) {
		this.codUsuModificacion = codUsuModificacion;
	}

	/**
	 * Obtenemos el Codigo Usuario Registro
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodUsuRegistro() {
		return codUsuRegistro;
	}

	/**
	 * Inicializamos el Codigo Usuario Registro
	 * 
	 * @author dhernandezv
	 * @param codUsuRegistro
	 *            , Codigo Usuario Registro
	 */
	public void setCodUsuRegistro(String codUsuRegistro) {
		this.codUsuRegistro = codUsuRegistro;
	}

	/**
	 * Obtenemos la Descripcion de Nota
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getDesNota() {
		return desNota;
	}

	/**
	 * Inicializamos la Descripcion de Nota
	 * 
	 * @author dhernandezv
	 * @param desNota
	 *            , Descripcion de Nota
	 */
	public void setDesNota(String desNota) {
		this.desNota = desNota;
	}

	/**
	 * Obtenemos la Fecha de Modificacion
	 * 
	 * @author dhernandezv
	 * @return Date, objeto de tipo Date.Util
	 */
	public Date getFeModificacion() {
		return feModificacion;
	}

	/**
	 * Inicializamos la Fecha de Modificacion
	 * 
	 * @author dhernandezv
	 * @param feModificacion
	 *            , Fecha de Modificacion
	 */
	public void setFeModificacion(Date feModificacion) {
		this.feModificacion = feModificacion;
	}

	/**
	 * Obtenemos la Fecha de Rececpion de Repuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @return Date, objeto de tipo Date.Util
	 */
	public Date getFeRecRespNoti() {
		return feRecRespNoti;
	}

	/**
	 * Inicializamos la Fecha de Rececpion de Repuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @param feRecRespNoti
	 *            , Fecha de Rececpion de Repuesta Notificacion
	 */
	public void setFeRecRespNoti(Date feRecRespNoti) {
		this.feRecRespNoti = feRecRespNoti;
	}

	/**
	 * Obtenemos la Fecha de Registro
	 * 
	 * @author dhernandezv
	 * @return Date, objeto de tipo Date.Util
	 */
	public Date getFeRegistro() {
		return feRegistro;
	}

	/**
	 * Inicializamos la Fecha de Registro
	 * 
	 * @author dhernandezv
	 * @param feRegistro
	 *            , Fecha de Registro
	 */
	public void setFeRegistro(Date feRegistro) {
		this.feRegistro = feRegistro;
	}

	/**
	 * Obtenemos el N�mero Correlativo de Documento
	 * 
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumCorreDoc() {
		return numCorreDoc;
	}

	/**
	 * Inicializamos el N�mero Correlativo de Documento
	 * 
	 * @author dhernandezv
	 * @param numCorreDoc
	 *            , N�mero Correlativo de Documento
	 */
	public void setNumCorreDoc(Long numCorreDoc) {
		this.numCorreDoc = numCorreDoc;
	}

	/**
	 * Obtenemos el N�mero Correlativo de Documento Solicitud
	 * 
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumCorreDocSol() {
		return numCorreDocSol;
	}

	/**
	 * Inicializamos el N�mero Correlativo de Documento Solicitud
	 * 
	 * @author dhernandezv
	 * @param numCorreDocSol
	 *            , N�mero Correlativo de Documento Solicitud
	 */
	public void setNumCorreDocSol(Long numCorreDocSol) {
		this.numCorreDocSol = numCorreDocSol;
	}

	/**
	 * Obtenemos el Numero de Folio de Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumFolioRptaNoti() {
		return numFolioRptaNoti;
	}

	/**
	 * Inicializamos el Numero de Folio de Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @param numFolioRptaNoti
	 *            , Numero de Folio de Respuesta Notificacion
	 */
	public void setNumFolioRptaNoti(Long numFolioRptaNoti) {
		this.numFolioRptaNoti = numFolioRptaNoti;
	}

	/**
	 * Obtenemos el N�mero de Nota
	 * 
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumNota() {
		return numNota;
	}

	/**
	 * Inicializamos el N�mero de Nota
	 * 
	 * @author dhernandezv
	 * @param numNota
	 *            , N�mero de Nota
	 */
	public void setNumNota(Long numNota) {
		this.numNota = numNota;
	}

	/**
	 * Obtenemos la Observacion de Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getObsRptaNoti() {
		return obsRptaNoti;
	}

	/**
	 * Inicializamos la Observacion de Respuesta Notificacion
	 * 
	 * @author dhernandezv
	 * @param obsRptaNoti
	 *            , Observacion de Respuesta Notificacion
	 */
	public void setObsRptaNoti(String obsRptaNoti) {
		this.obsRptaNoti = obsRptaNoti;
	}

	/**
	 * Obtenemos el Indicador de detalle de descripcion de Notificacion
	 * 
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getIndDetDescNotificacion() {
		return indDetDescNotificacion;
	}

	/**
	 * Inicializamos el Indicador de detalle de descripcion de Notificacion
	 * 
	 * @author dhernandezv
	 * @param indDetDescNotificacion
	 *            , Indicador de detalle de descripcion de Notificacion
	 */
	public void setIndDetDescNotificacion(String indDetDescNotificacion) {
		this.indDetDescNotificacion = indDetDescNotificacion;
	}

	/**
	 * @return the numeroNota
	 */
	public Long getNumeroNota() {
		return numeroNota;
	}

	/**
	 * @param numeroNota
	 *            the numeroNota to set
	 */
	public void setNumeroNota(Long numeroNota) {
		this.numeroNota = numeroNota;
	}

	/**
	 * @return the codigoNota
	 */
	public String getCodigoNota() {
		return codigoNota;
	}

	/**
	 * @param codigoNota
	 *            the codigoNota to set
	 */
	public void setCodigoNota(String codigoNota) {
		this.codigoNota = codigoNota;
	}

	/**
	 * @return the descripcionNota
	 */
	public String getDescripcionNota() {
		return descripcionNota;
	}

	/**
	 * @param descripcionNota
	 *            the descripcionNota to set
	 */
	public void setDescripcionNota(String descripcionNota) {
		this.descripcionNota = descripcionNota;
	}

	/**
	 * @return the diligencia
	 */
	public Diligencia getDiligencia() {
		return diligencia;
	}

	/**
	 * @param diligencia
	 *            the diligencia to set
	 */
	public void setDiligencia(Diligencia diligencia) {
		this.diligencia = diligencia;
	}
	/* P14 - 3006 - mpoblete BUG 19143 - inicio */
	/**
	 * @return the fecRegistroString
	 */
	public String getFecRegistroString() {
		return fecRegistroString;
	}
    
	/**
	 * @param fecRegistroString
	 *            the fecRegistroString to set
	 */
	public void setFecRegistroString(String fecRegistroString) {
		this.fecRegistroString = fecRegistroString;
	}
	/* P14 - 3006 - mpoblete BUG 19143 - fin */
	//rtineo PAS20155E220400065
	public Long getNumeroCorrelativoSolicitud() {
		return numeroCorrelativoSolicitud;
	}

	public void setNumeroCorrelativoSolicitud(Long numeroCorrelativoSolicitud) {
		this.numeroCorrelativoSolicitud = numeroCorrelativoSolicitud;
	}

	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}

	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}

	public String getCodigoAprobador() {
		return codigoAprobador;
	}

	public void setCodigoAprobador(String codigoAprobador) {
		this.codigoAprobador = codigoAprobador;
	}

	public String getCodigoEstadoNotificacion() {
		return codigoEstadoNotificacion;
	}

	public void setCodigoEstadoNotificacion(String codigoEstadoNotificacion) {
		this.codigoEstadoNotificacion = codigoEstadoNotificacion;
	}


	public String getObservacionRespuestaNotificacion() {
		return observacionRespuestaNotificacion;
	}

	public void setObservacionRespuestaNotificacion(
			String observacionRespuestaNotificacion) {
		this.observacionRespuestaNotificacion = observacionRespuestaNotificacion;
	}

	public Date getFechaRespuestaNotificacion() {
		return fechaRespuestaNotificacion;
	}

	public void setFechaRespuestaNotificacion(Date fechaRespuestaNotificacion) {
		this.fechaRespuestaNotificacion = fechaRespuestaNotificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	//rtineo fin
}
