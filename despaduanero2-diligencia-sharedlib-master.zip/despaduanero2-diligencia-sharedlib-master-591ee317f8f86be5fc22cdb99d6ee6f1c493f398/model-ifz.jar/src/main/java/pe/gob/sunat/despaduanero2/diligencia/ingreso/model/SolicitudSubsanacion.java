package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;
import java.util.Date;

import pe.gob.sunat.administracion2.tramite.model.Expedi;
import pe.gob.sunat.despaduanero2.model.Solicitud;

public class SolicitudSubsanacion extends Solicitud implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String descripcionSubsanacion;
	private Incidencia incidencia;
	private Expedi expediente;
	private String codigoFuncionarioRegistro;
	private Date fechaRegistro;
	//private String nombreFuncionarioRegistro = "";
	private String nombreFuncionarioRegistro;
	private int orden;
	
	
	public SolicitudSubsanacion() {
		super();
	}

	/**
	 * @return the descripcionSubsanacion
	 */
	public String getDescripcionSubsanacion() {
		return descripcionSubsanacion;
	}

	/**
	 * @param descripcionSubsanacion the descripcionSubsanacion to set
	 */
	public void setDescripcionSubsanacion(String descripcionSubsanacion) {
		this.descripcionSubsanacion = descripcionSubsanacion;
	}

	/**
	 * @return the incidencia
	 */
	public Incidencia getIncidencia() {
		return incidencia;
	}

	/**
	 * @param incidencia the incidencia to set
	 */
	public void setIncidencia(Incidencia incidencia) {
		this.incidencia = incidencia;
	}

	/**
	 * @return the expediente
	 */
	public Expedi getExpediente() {
		return expediente;
	}

	/**
	 * @param expediente the expediente to set
	 */
	public void setExpediente(Expedi expediente) {
		this.expediente = expediente;
	}

	/**
	 * @return the codigoFuncionarioRegistro
	 */
	public String getCodigoFuncionarioRegistro() {
		return codigoFuncionarioRegistro;
	}

	/**
	 * @param codigoFuncionarioRegistro the codigoFuncionarioRegistro to set
	 */
	public void setCodigoFuncionarioRegistro(String codigoFuncionarioRegistro) {
		this.codigoFuncionarioRegistro = codigoFuncionarioRegistro;
	}

	
	/**
	 * @return the fechaRegistro
	 */
	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	/**
	 * @param fechaRegistro the fechaRegistro to set
	 */
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	/**
	 * @return the orden
	 */
	public int getOrden() {
		return orden;
	}

	/**
	 * @param orden the orden to set
	 */
	public void setOrden(int orden) {
		this.orden = orden;
	}

	/**
	 * @return the nombreFuncionarioRegistro
	 */
	public String getNombreFuncionarioRegistro() {
		return nombreFuncionarioRegistro;
	}

	/**
	 * @param nombreFuncionarioRegistro the nombreFuncionarioRegistro to set
	 */
	public void setNombreFuncionarioRegistro(String nombreFuncionarioRegistro) {
		this.nombreFuncionarioRegistro = nombreFuncionarioRegistro;
	}
	
}
