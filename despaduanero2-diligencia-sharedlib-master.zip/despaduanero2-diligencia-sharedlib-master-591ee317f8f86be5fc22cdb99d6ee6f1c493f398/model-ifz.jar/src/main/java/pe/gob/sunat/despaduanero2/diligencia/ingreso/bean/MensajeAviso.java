package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class MensajeAviso {
	
	private List<String> usuarios;
	private String desAsunto;
	private Integer codServicio;
	private TipoUsuarioAviso tipoUsuarioAviso;
	private TipoAviso tipoAviso;
	private FechaBean fechaEmision;
	private FechaBean fechaVigencia;
	private Map<String, Object> msgPersonalizado;

	public MensajeAviso(){
		usuarios = new ArrayList<String>();
		msgPersonalizado = new HashMap<String, Object>();
	}
	public void addDatoPersonalizado(String key, Object value){
		msgPersonalizado.put(key, value);
	}
	public void borrarTodosUsuarios(){
		usuarios.clear();
	}
	public void addUsuario(String usuario){
		usuarios.add(usuario);
	}
	public List<String> getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(List<String> usuarios) {
		this.usuarios = usuarios;
	}
	public String getDesAsunto() {
		return desAsunto;
	}
	public void setDesAsunto(String desAsunto) {
		this.desAsunto = desAsunto;
	}
	public Integer getCodServicio() {
		return codServicio;
	}
	public void setCodServicio(Integer codServicio) {
		this.codServicio = codServicio;
	}
	public TipoUsuarioAviso getTipoUsuarioAviso() {
		return tipoUsuarioAviso;
	}
	public void setTipoUsuarioAviso(TipoUsuarioAviso tipoUsuarioAviso) {
		this.tipoUsuarioAviso = tipoUsuarioAviso;
	}
	public TipoAviso getTipoAviso() {
		return tipoAviso;
	}
	public void setTipoAviso(TipoAviso tipoAviso) {
		this.tipoAviso = tipoAviso;
	}
	public FechaBean getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(FechaBean fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public FechaBean getFechaVigencia() {
		return fechaVigencia;
	}
	public void setFechaVigencia(FechaBean fechaVigencia) {
		this.fechaVigencia = fechaVigencia;
	}
	public Map<String, Object> getMsgPersonalizado() {
		return msgPersonalizado;
	}
	public void setMsgPersonalizado(Map<String, Object> msgPersonalizado) {
		this.msgPersonalizado = msgPersonalizado;
	}
	
	public enum TipoUsuarioAviso{
		CONTRIBUYENTE("1"), OPERADOR_COMERCIO("2"), USUARIO_INTERNO("3");

        private final String value;

        private TipoUsuarioAviso(final String tipoUsuarioAviso) {
            value = tipoUsuarioAviso;
        }

        public String getValue() { return value; }
    }
	
	public enum TipoAviso{
		AVISO_ELECTRONICO("0"), NOTIFICACION("1"), MENSAJE_SIMPLE_BUZON("2");

        private final String value;

        private TipoAviso(final String tipoAviso) {
            value = tipoAviso;
        }

        public String getValue() { return value; }
    }
	
	public String getMensajeAsJsonString(){
		String [] users = new String[usuarios.size()];
		msgPersonalizado.put("des_asunto", getDesAsunto());
		msgPersonalizado.put("tip_usuario", getTipoUsuarioAviso().getValue());		
		msgPersonalizado.put("cod_usuario", usuarios.toArray(users));
		return SojoUtil.toJson(msgPersonalizado);
	}

}
