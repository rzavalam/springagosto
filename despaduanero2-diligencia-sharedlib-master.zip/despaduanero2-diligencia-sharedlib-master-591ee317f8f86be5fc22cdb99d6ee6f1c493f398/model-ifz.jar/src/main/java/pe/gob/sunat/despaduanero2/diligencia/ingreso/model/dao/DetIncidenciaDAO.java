package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

/**
 * The Interface DetIncidenciaDAO.
 */
public interface DetIncidenciaDAO
{
  /**
   * Metodo que retorna las incidencias de un determinada Diligencia.
   * @param PkDili
   * @return
   * @throws DataAccessException
   */
  public List<Map<String, Object>> findByDiligencia(Map<String, String> PkDili) throws DataAccessException;


  /**
   * Inserta una DetIncidencia en la BD
   * @param params
   */
  public void insert(Map<String, Object> params);
  /**
   * Metodo que retorna las incidencia  , b�squeda x cod_incidencia.
   * @param PkDili
   * @return
   * @throws DataAccessException
   */
  public List<Map<String, Object>> findByIncidencia(Map<String, Object> paramsIncidencia) throws DataAccessException;
}
