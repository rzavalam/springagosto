/* Creado - P14 - 3014 - Inicio - dhernandezv */

package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

public class DetalleComunicacion implements Serializable {

	/**
	 * Serial
	 * @author dhernandezv
	 */
	private static final long serialVersionUID = -980238084548545083L;

	/**
	 * Constructor de la Clase DetalleComunicacion
	 * @author dhernandezv
	 */
	public DetalleComunicacion() {
		super();
	}
	
	
	/**
	 * Numero Nota
	 * @author dhernandezv
	 */
	private Long numNota;
	
	/**
	 * Numero Detalle Descripcion
	 * @author dhernandezv
	 */
	private Long numDetaDescripcion;
	
	/**
	 * Descripcion Detalle
	 * @author dhernandezv
	 */
	private String desDetalle;
	
	/**
	 * Fecha Registro
	 * @author dhernandezv
	 */
	private Date feRegistro;
	
	/**
	 * Fecha Modificacion
	 * @author dhernandezv
	 */
	private Date feModificacion;
	
	/**
	 * Codigo Usuario Registro
	 * @author dhernandezv
	 */
	private String codUsuRegistro;
	
	/**
	 * Codigo Usuario Modificacion
	 * @author dhernandezv
	 */
	private String codUsuModificacion;

	
	/****************** GETTERS Y SETTERS ******************/

	/**
	 * Obtenemos el N�mero de Nota
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumNota() {
		return numNota;
	}

	/**
	 * Inicializamos el N�mero de Nota
	 * @author dhernandezv
	 * @param numNota, N�mero de Nota
	 */	
	public void setNumNota(Long numNota) {
		this.numNota = numNota;
	}

	/**
	 * Obtenemos el Numero Detalle Descripcion 
	 * @author dhernandezv
	 * @return Long, objeto de tipo Long
	 */
	public Long getNumDetaDescripcion() {
		return numDetaDescripcion;
	}

	/**
	 * Inicializamos el Numero Detalle Descripcion
	 * @author dhernandezv
	 * @param numDetaDescripcion, Numero Detalle Descripcion
	 */	
	public void setNumDetaDescripcion(Long numDetaDescripcion) {
		this.numDetaDescripcion = numDetaDescripcion;
	}

	/**
	 * Obtenemos la Descripcion de Detalle
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getDesDetalle() {
		return desDetalle;
	}

	/**
	 * Inicializamos la Descripcion de Detalle
	 * @author dhernandezv
	 * @param desDetalle, Descripcion de Detalle
	 */	
	public void setDesDetalle(String desDetalle) {
		this.desDetalle = desDetalle;
	}

	/**
	 * Obtenemos la Fecha de Registro
	 * @author dhernandezv
	 * @return Date, objeto de tipo Date.Util
	 */
	public Date getFeRegistro() {
		return feRegistro;
	}

	/**
	 * Inicializamos la Fecha de Registro
	 * @author dhernandezv
	 * @param feRegistro, Fecha de Registro
	 */	
	public void setFeRegistro(Date feRegistro) {
		this.feRegistro = feRegistro;
	}

	/**
	 * Obtenemos la Fecha de Modificacion
	 * @author dhernandezv
	 * @return Date, objeto de tipo Date.Util
	 */
	public Date getFeModificacion() {
		return feModificacion;
	}

	/**
	 * Inicializamos la Fecha de Modificacion
	 * @author dhernandezv
	 * @param feModificacion, Fecha de Modificacion
	 */	
	public void setFeModificacion(Date feModificacion) {
		this.feModificacion = feModificacion;
	}

	/**
	 * Obtenemos el Codigo de Usuario de Registro
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodUsuRegistro() {
		return codUsuRegistro;
	}

	/**
	 * Inicializamos el Codigo de Usuario de Registro
	 * @author dhernandezv
	 * @param codUsuRegistro, Codigo de Usuario de Registro
	 */	
	public void setCodUsuRegistro(String codUsuRegistro) {
		this.codUsuRegistro = codUsuRegistro;
	}

	/**
	 * Obtenemos el Codigo Usuario Modificacion
	 * @author dhernandezv
	 * @return String, objeto de tipo String
	 */
	public String getCodUsuModificacion() {
		return codUsuModificacion;
	}

	/**
	 * Inicializamos el Codigo Motivo Notificacion
	 * @author dhernandezv
	 * @param codUsuModificacion, Codigo Motivo Notificacion
	 */	
	public void setCodUsuModificacion(String codUsuModificacion) {
		this.codUsuModificacion = codUsuModificacion;
	}
		
}
