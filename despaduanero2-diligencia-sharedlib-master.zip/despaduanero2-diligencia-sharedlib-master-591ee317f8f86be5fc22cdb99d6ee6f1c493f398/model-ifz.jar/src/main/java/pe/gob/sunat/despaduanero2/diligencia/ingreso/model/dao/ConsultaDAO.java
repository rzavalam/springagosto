package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;

/**
 * The Interface ConsultaDAO.
 *
 * @author rdelosreyes
 */
public interface ConsultaDAO
{
  /**
   * Inserta un registro de Consulta
   * @param params
   * @return
   * @throws DataAccessException
   */
  public Integer insert(Map<String, Object> params) throws DataAccessException;

  /**
   * Actualiza un registro de consulta
   * @param params
   * @return
   * @throws DataAccessException
   */
  public int update(Map<String, Object> params) throws DataAccessException;

  /**
   * Busca lo registro de consulta por numCorreDoc
   * @param params
   * @return
   */
  public Map<String, Object> findByNumCorredocDiligencia(Map<String, Object> params);


  public List<Map<String, Object>> findByNumCorredocDiligencia2(Map<String, Object> params);


	/**
	 * Obtener una consulta por su clave primaria
	 * 
	 * @author olunar
	 * @param consulta
	 * @return Consulta
	 * @throws DataAccessException
	 */
	public Consulta findByPk(Consulta consulta) throws DataAccessException;

	/**
	 * Buscar consultas por par�metros de la consulta
	 * 
	 * @author olunar
	 * @param consulta
	 * @return Consulta
	 * @throws DataAccessException
	 */
	public List<Consulta> findByConsulta(Consulta consulta) throws DataAccessException;
	
	/**
	 * Devuelve el n�mero de secuencia m�ximo de las consultas de un documento
	 * 
	 * @author olunar
	 * @param consulta
	 * @return Integer
	 * @throws DataAccessException
	 */
	public Integer selectMaxNumSec(Consulta consulta) throws DataAccessException;
	
	/**
	 * Actualiza los datos de una consulta
	 * 
	 * @author olunar
	 * @param consulta
	 * @return int
	 * @throws DataAccessException
	 */
	public int update(Consulta consulta) throws DataAccessException;
	
	/**
	 * Insertar una consulta
	 * 
	 * @author olunar
	 * @param consulta
	 * @throws DataAccessException
	 */
	public void insert(Consulta consulta) throws DataAccessException;
}
