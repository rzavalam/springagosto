package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Titulo: Clase Utilitaria CampoEntidad.</p>
 * <p>Descripcion: Clase que contiene los datos de los campos de la entidad mapeada en el archivo XML de configuracion.</p>
 * <p>Descripcion: Clase que contiene los datos de la entidad mapeada en el archivo XML de configuracion.</p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EntidadMapeo.java</p>
 * <p>Copyright: SUNAT-2011</p>
 *
 * @version 1.0
 */
public class CampoXml implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 3459938314486417749L;

    /**
     * Nombre del campo
     */
    private String nombre= "";
//	/**
//	 * Nombre del campo en la Base de Datos, para efectos de comparacion.
//	 */
//	private String nombreBD="";
    /**
     * Nombre identificador del campo en la parte vista.
     * Es decir si en base de datos es NUM_CORREDOC en la parte vista pudiera llamarse hdn_correlativo
     * con lo cual su identificador seria "correlativo" ya que los prefijos de la parte de jsp son
     * eliminados y solo se usan para mostrarse en el jsp.
     */
    private String identificadorVista="";
//	/**
//	 * Nombre identificador del campo en los xml de ibatis, en caso los tuviera.
//	 * No siempre se usa el nombre de base de Datos, pudiendose enmascarar desde este.
//	 */
//	private String identificadorIbatis="";
    /**
     * Tipo de Dato Java del campo.
     */
    private String tipoDato="";

    /**
     * Identificador de la ruta del atributo en el modelo de clases de la DUA.<br>
     * Se usa en la trasmision electronica.
     */
    private String attributePath="";
    /**
     * Formato del campo, en caso lo tuviese.
     */
    private String formato="";
    /**
     * Dato por default a considerar en caso viniese con algun error,
     * en caso no se detalle ningun error se asumira en caso se obtenga null o vacio.
     */
    private String dataDefault="";
    /**
     * Lista de valores los cuales podrian causar error al momento de grabar o actualizar la informacion en Base de Datos.
     */
    private List<String> lstError = new ArrayList<String>();


    //GETTERs and SETTERs
    public List<String> getLstError() {
        return lstError;
    }
    public void setLstError(List<String> lstError) {
        this.lstError = lstError;
    }
    public void setLstError(String[] lstError) {
        for(String cadenaError: lstError){
            this.lstError.add(cadenaError);
        }
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getIdentificadorVista() {
        return identificadorVista;
    }
    public void setIdentificadorVista(String identificadorVista) {
        this.identificadorVista = identificadorVista;
    }
    public String getTipoDato() {
        return tipoDato;
    }
    public void setTipoDato(String tipoDato) {
        this.tipoDato = tipoDato;
    }
    public String getFormato() {
        return formato;
    }
    public void setFormato(String formato) {
        this.formato = formato;
    }
    public String getDataDefault() {
        return dataDefault;
    }
    public void setDataDefault(String dataDefault) {
        this.dataDefault = dataDefault;
    }

    public String getAttributePath() {
        return attributePath;
    }
    public void setAttributePath(String attributePath) {
        this.attributePath = attributePath;
    }

    @Override
    public String toString() {
        return "CampoXml [campoNombre=" + nombre + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((nombre == null) ? 0 : nombre.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CampoXml other = (CampoXml) obj;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        return true;
    }

}

