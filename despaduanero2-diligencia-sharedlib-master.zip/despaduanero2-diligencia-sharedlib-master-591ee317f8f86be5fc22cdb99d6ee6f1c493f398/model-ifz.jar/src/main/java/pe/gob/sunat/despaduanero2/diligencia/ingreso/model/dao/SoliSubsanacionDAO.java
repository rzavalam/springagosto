package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.SolicitudSubsanacion;

public interface SoliSubsanacionDAO {
	
	/**
	 * Inserta selectivamente una solicitud subsanacion
	 * @param solicitudSubsanacion
	 * @return
	 * @author gbecerrav
	 */
	public void insertSelective(SolicitudSubsanacion solicitudSubsanacion);
	
	/**
	 * Lista incidencias subsanadas
	 * @param params
	 * @return Lista de SolicitudSubsanacion
	 * @author gbecerrav
	 */
	public SolicitudSubsanacion getIncidenciaSubsanadaByParameterMap(Map<String, Object> params);
	
	/**
	 * Lista para la consulta de subsanacion de observacion ZPAE
	 * @param params
	 * @return Lista de SolicitudSubsanacion
	 * @author gbecerrav
	 */
	public List<SolicitudSubsanacion> listConsultaSubsanacionObsZPAE(Map<String, Object> params);
}
