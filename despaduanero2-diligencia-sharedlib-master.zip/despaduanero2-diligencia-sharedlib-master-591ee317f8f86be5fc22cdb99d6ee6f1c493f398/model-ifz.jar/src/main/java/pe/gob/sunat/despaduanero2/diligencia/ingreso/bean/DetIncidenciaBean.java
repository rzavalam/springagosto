package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class DetIncidenciaBean implements Serializable {

    private static final long serialVersionUID = 1422887090508633469L;

    private Long numCorredoc;
    private String codTipdiligencia;
    private Integer numSecincid;
    private String codIncidencia;
    private String codNivelinci;
    private Integer numSerie;
    private Integer numItem;
    private String desSustento;
    private Double mtoActual;
    private Double mtoCorregido;
    private String codUsuregis;
    private Date fecRegis;
    private String codUsumodif;
    private Date fecModif;
    private Long numCorredocSol;
//    <EHR>
    private String valAnterior;
    private String valActual;
//    </EHR>
    
    public Long getNumCorredoc() {
        return numCorredoc;
    }
    public void setNumCorredoc(Long numCorredoc) {
        this.numCorredoc = numCorredoc;
    }
    public String getCodTipdiligencia() {
        return codTipdiligencia;
    }
    public void setCodTipdiligencia(String codTipdiligencia) {
        this.codTipdiligencia = codTipdiligencia;
    }
    public Integer getNumSecincid() {
        return numSecincid;
    }
    public void setNumSecincid(Integer numSecincid) {
        this.numSecincid = numSecincid;
    }
    public String getCodIncidencia() {
        return codIncidencia;
    }
    public void setCodIncidencia(String codIncidencia) {
        this.codIncidencia = codIncidencia;
    }
    public String getCodNivelinci() {
        return codNivelinci;
    }
    public void setCodNivelinci(String codNivelinci) {
        this.codNivelinci = codNivelinci;
    }
    public Integer getNumSerie() {
        return numSerie;
    }
    public void setNumSerie(Integer numSerie) {
        this.numSerie = numSerie;
    }
    public Integer getNumItem() {
        return numItem;
    }
    public void setNumItem(Integer numItem) {
        this.numItem = numItem;
    }
    public String getDesSustento() {
        return desSustento;
    }
    public void setDesSustento(String desSustento) {
        this.desSustento = desSustento;
    }
    public Double getMtoActual() {
        return mtoActual;
    }
    public void setMtoActual(Double mtoActual) {
        this.mtoActual = mtoActual;
    }
    public Double getMtoCorregido() {
        return mtoCorregido;
    }
    public void setMtoCorregido(Double mtoCorregido) {
        this.mtoCorregido = mtoCorregido;
    }
    public String getCodUsuregis() {
        return codUsuregis;
    }
    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis;
    }
    public Date getFecRegis() {
        return fecRegis;
    }
    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }
    public String getCodUsumodif() {
        return codUsumodif;
    }
    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif;
    }
    public Date getFecModif() {
        return fecModif;
    }
    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
    public Long getNumCorredocSol() {
        return numCorredocSol;
    }
    public void setNumCorredocSol(Long numCorredocSol) {
        this.numCorredocSol = numCorredocSol;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
	public String getValAnterior() {
		return valAnterior;
	}
	public void setValAnterior(String valAnterior) {
		this.valAnterior = valAnterior;
	}
	public String getValActual() {
		return valActual;
	}
	public void setValActual(String valActual) {
		this.valActual = valActual;
	}
 
    
}
