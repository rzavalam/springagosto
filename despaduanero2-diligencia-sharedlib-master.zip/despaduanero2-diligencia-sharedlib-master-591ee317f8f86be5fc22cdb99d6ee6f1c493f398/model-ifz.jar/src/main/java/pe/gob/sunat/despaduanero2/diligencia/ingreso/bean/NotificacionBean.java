package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;

public class NotificacionBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String codigoAduana;
	private Integer anioDeclaracion;
	private String numeroDeclaracion;
	private Integer numeroSecuenciaCorrelativo;
	private String stringFechaRegistro;
	private Date fechaRegistro;
	private String stringFechaCulminacion;
	private String codigoFuncionario;
	private String nombreCompletoFuncionario;
	private String descripcionNotificacion;
	private String codigoEstadoNotificacion;
	private String descripcionEstadoNotificacion;
	private String descripcionRespuesta;
	private String codigoAprobador;
	private String codigoNota;
	private String codigoTipoDiligencia;
	private String codigoUsuarioModificacion;
	private String codigoUsuarioRegistro;
	private Long numeroCorrelativo;
	private Long numeroNotificacion;
	private String numeroGED;
	private String stringFechaDiligencia;
	private Date fechaDiligencia;
	private String codigoCanal;
	private String descripcionCanal;
	private String stringFechaAsignacion;
	private Date fechaAsignacion;
	private String tiempoTranscurridoNotiDili;
	private String tiempoTranscurridoAsigDili;
	private List<DetalleComunicacion> listMotivos;
	private CatEmpleado especialista;
	private String nombreImportador;

	public String getCodigoAduana() {
		return codigoAduana;
	}
	public void setCodigoAduana(String codigoAduana) {
		this.codigoAduana = codigoAduana;
	}
	public Integer getAnioDeclaracion() {
		return anioDeclaracion;
	}
	public void setAnioDeclaracion(Integer anioDeclaracion) {
		this.anioDeclaracion = anioDeclaracion;
	}
	public String getNumeroDeclaracion() {
		return numeroDeclaracion;
	}
	public void setNumeroDeclaracion(String numeroDeclaracion) {
		this.numeroDeclaracion = numeroDeclaracion;
	}
	public Integer getNumeroSecuenciaCorrelativo() {
		return numeroSecuenciaCorrelativo;
	}
	public void setNumeroSecuenciaCorrelativo(Integer numeroSecuenciaCorrelativo) {
		this.numeroSecuenciaCorrelativo = numeroSecuenciaCorrelativo;
	}
	public String getStringFechaRegistro() {
		return stringFechaRegistro;
	}
	public void setStringFechaRegistro(String stringFechaRegistro) {
		this.stringFechaRegistro = stringFechaRegistro;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getStringFechaCulminacion() {
		return stringFechaCulminacion;
	}
	public void setStringFechaCulminacion(String stringFechaCulminacion) {
		this.stringFechaCulminacion = stringFechaCulminacion;
	}
	public String getStringFechaAsignacion() {
		return stringFechaAsignacion;
	}
	public void setStringFechaAsignacion(String stringFechaAsignacion) {
		this.stringFechaAsignacion = stringFechaAsignacion;
	}
	public Date getFechaAsignacion() {
		return fechaAsignacion;
	}
	public void setFechaAsignacion(Date fechaAsignacion) {
		this.fechaAsignacion = fechaAsignacion;
	}
	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}
	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}
	public String getDescripcionNotificacion() {
		return descripcionNotificacion;
	}
	public void setDescripcionNotificacion(String descripcionNotificacion) {
		this.descripcionNotificacion = descripcionNotificacion;
	}
	public String getCodigoEstadoNotificacion() {
		return codigoEstadoNotificacion;
	}
	public void setCodigoEstadoNotificacion(String codigoEstadoNotificacion) {
		this.codigoEstadoNotificacion = codigoEstadoNotificacion;
	}
	public String getDescripcionRespuesta() {
		return descripcionRespuesta;
	}
	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}
	public String getCodigoAprobador() {
		return codigoAprobador;
	}
	public void setCodigoAprobador(String codigoAprobador) {
		this.codigoAprobador = codigoAprobador;
	}
	public String getCodigoNota() {
		return codigoNota;
	}
	public void setCodigoNota(String codigoNota) {
		this.codigoNota = codigoNota;
	}
	public String getCodigoTipoDiligencia() {
		return codigoTipoDiligencia;
	}
	public void setCodigoTipoDiligencia(String codigoTipoDiligencia) {
		this.codigoTipoDiligencia = codigoTipoDiligencia;
	}
	public String getCodigoUsuarioModificacion() {
		return codigoUsuarioModificacion;
	}
	public void setCodigoUsuarioModificacion(String codigoUsuarioModificacion) {
		this.codigoUsuarioModificacion = codigoUsuarioModificacion;
	}
	public String getCodigoUsuarioRegistro() {
		return codigoUsuarioRegistro;
	}
	public void setCodigoUsuarioRegistro(String codigoUsuarioRegistro) {
		this.codigoUsuarioRegistro = codigoUsuarioRegistro;
	}
	public Long getNumeroCorrelativo() {
		return numeroCorrelativo;
	}
	public void setNumeroCorrelativo(Long numeroCorrelativo) {
		this.numeroCorrelativo = numeroCorrelativo;
	}
	public Long getNumeroNotificacion() {
		return numeroNotificacion;
	}
	public void setNumeroNotificacion(Long numeroNotificacion) {
		this.numeroNotificacion = numeroNotificacion;
	}
	public String getNumeroGED() {
		return numeroGED;
	}
	public void setNumeroGED(String numeroGED) {
		this.numeroGED = numeroGED;
	}
	public String getCodigoCanal() {
		return codigoCanal;
	}
	public void setCodigoCanal(String codigoCanal) {
		this.codigoCanal = codigoCanal;
	}
	public String getDescripcionCanal() {
		return descripcionCanal;
	}
	public void setDescripcionCanal(String descripcionCanal) {
		this.descripcionCanal = descripcionCanal;
	}
	public String getNombreCompletoFuncionario() {
		return nombreCompletoFuncionario;
	}
	public void setNombreCompletoFuncionario(String nombreCompletoFuncionario) {
		this.nombreCompletoFuncionario = nombreCompletoFuncionario;
	}
	public String getDescripcionEstadoNotificacion() {
		return descripcionEstadoNotificacion;
	}
	public void setDescripcionEstadoNotificacion(
			String descripcionEstadoNotificacion) {
		this.descripcionEstadoNotificacion = descripcionEstadoNotificacion;
	}
	public String getStringFechaDiligencia() {
		return stringFechaDiligencia;
	}
	public void setStringFechaDiligencia(String stringFechaDiligencia) {
		this.stringFechaDiligencia = stringFechaDiligencia;
	}
	public Date getFechaDiligencia() {
		return fechaDiligencia;
	}
	public void setFechaDiligencia(Date fechaDiligencia) {
		this.fechaDiligencia = fechaDiligencia;
	}
	public String getTiempoTranscurridoNotiDili() {
		return tiempoTranscurridoNotiDili;
	}
	public void setTiempoTranscurridoNotiDili(String tiempoTranscurridoNotiDili) {
		this.tiempoTranscurridoNotiDili = tiempoTranscurridoNotiDili;
	}
	public String getTiempoTranscurridoAsigDili() {
		return tiempoTranscurridoAsigDili;
	}
	public void setTiempoTranscurridoAsigDili(String tiempoTranscurridoAsigDili) {
		this.tiempoTranscurridoAsigDili = tiempoTranscurridoAsigDili;
	}
	public List<DetalleComunicacion> getListMotivos() {
		return listMotivos;
	}
	public void setListMotivos(List<DetalleComunicacion> listMotivos) {
		this.listMotivos = listMotivos;
	}
	public CatEmpleado getEspecialista() {
		return especialista;
	}
	public void setEspecialista(CatEmpleado especialista) {
		this.especialista = especialista;
	}
	public String getNombreImportador() {
		return nombreImportador;
	}
	public void setNombreImportador(String nombreImportador) {
		this.nombreImportador = nombreImportador;
	}

}
