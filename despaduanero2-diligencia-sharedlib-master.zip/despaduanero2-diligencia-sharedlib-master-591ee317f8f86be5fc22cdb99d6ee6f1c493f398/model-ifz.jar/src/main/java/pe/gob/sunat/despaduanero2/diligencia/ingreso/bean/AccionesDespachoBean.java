package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

public class AccionesDespachoBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4574950649813950346L;
	
	private Long correlativoDeclaracion;
	private Long correlativoDiligencia;
	private String codigoTipoDiligencia;
	private String tipoDiligencia;	
	private String fechaAccion;
	private String unidadDiligencia;	
	private Long numeroParcial;
	private Long correlativoTranspMercancia;
	private String transpMercancia;	
	private String numeroEquipamiento;
	private String codigoFuncionario;	
	private String indicadorIncidencia;
	private String estado;
	private String resultado;
	
	public Long getCorrelativoDeclaracion() {
		return correlativoDeclaracion;
	}
	public void setCorrelativoDeclaracion(Long correlativoDeclaracion) {
		this.correlativoDeclaracion = correlativoDeclaracion;
	}
	public Long getCorrelativoDiligencia() {
		return correlativoDiligencia;
	}
	public void setCorrelativoDiligencia(Long correlativoDiligencia) {
		this.correlativoDiligencia = correlativoDiligencia;
	}
	public String getCodigoTipoDiligencia() {
		return codigoTipoDiligencia;
	}
	public void setCodigoTipoDiligencia(String codigoTipoDiligencia) {
		this.codigoTipoDiligencia = codigoTipoDiligencia;
	}
	public String getTipoDiligencia() {
		return tipoDiligencia;
	}
	public void setTipoDiligencia(String tipoDiligencia) {
		this.tipoDiligencia = tipoDiligencia;
	}
	public String getFechaAccion() {
		return fechaAccion;
	}
	public void setFechaAccion(String fechaAccion) {
		this.fechaAccion = fechaAccion;
	}
	public String getUnidadDiligencia() {
		return unidadDiligencia;
	}
	public void setUnidadDiligencia(String unidadDiligencia) {
		this.unidadDiligencia = unidadDiligencia;
	}
	public Long getNumeroParcial() {
		return numeroParcial;
	}
	public void setNumeroParcial(Long numeroParcial) {
		this.numeroParcial = numeroParcial;
	}
	public Long getCorrelativoTranspMercancia() {
		return correlativoTranspMercancia;
	}
	public void setCorrelativoTranspMercancia(Long correlativoTranspMercancia) {
		this.correlativoTranspMercancia = correlativoTranspMercancia;
	}
	public String getTranspMercancia() {
		return transpMercancia;
	}
	public void setTranspMercancia(String transpMercancia) {
		this.transpMercancia = transpMercancia;
	}
	public String getNumeroEquipamiento() {
		return numeroEquipamiento;
	}
	public void setNumeroEquipamiento(String numeroEquipamiento) {
		this.numeroEquipamiento = numeroEquipamiento;
	}
	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}
	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}
	public String getIndicadorIncidencia() {
		return indicadorIncidencia;
	}
	public void setIndicadorIncidencia(String indicadorIncidencia) {
		this.indicadorIncidencia = indicadorIncidencia;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	
	
	
	
	
	
	
	
	
}
