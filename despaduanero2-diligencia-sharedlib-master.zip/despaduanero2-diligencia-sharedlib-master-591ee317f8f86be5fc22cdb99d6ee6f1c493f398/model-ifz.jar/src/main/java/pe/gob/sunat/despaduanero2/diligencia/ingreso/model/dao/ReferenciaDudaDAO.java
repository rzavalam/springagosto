package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

/**
 * The Interface ReferenciaDudaDAO.
 */
public interface ReferenciaDudaDAO
{

  /**
   * Busca un listado de ReferenciaDuda por numCorreDoc
   * @param pkItem
   * @return
   */
  public List<Map<String, Object>> findByPkItem(Map<String, String> pkItem);

  /**
   * inserta un registro a la BD
   * @param mapReferenciaDuda
   */
  public void insert(Map<String, Object> mapReferenciaDuda);
  
  public int getMaxNumSecRefDuda(Map<String,Object> numSecRef);

}
