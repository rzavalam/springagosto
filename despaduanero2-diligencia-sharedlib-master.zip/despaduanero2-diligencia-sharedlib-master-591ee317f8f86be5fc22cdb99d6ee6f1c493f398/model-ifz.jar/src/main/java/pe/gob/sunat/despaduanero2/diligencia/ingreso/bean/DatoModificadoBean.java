package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;


import java.io.Serializable;


public class DatoModificadoBean implements Serializable
{
  private static final long serialVersionUID = 1L;

  private Integer            correlativo;
  private String            descripcionSecccion;
  private String            identificadorCampo;
  private String            descripcionIdentificadorCampo;
  private String            nombreCampo;
  private String            descripcionNombreCampo;
  private String            datoNuevo;
  private String            datoAntiguo;
  private String            estadoCampo;


  public DatoModificadoBean()
  {
    super();
  }

  public String getDescripcionSecccion()
  {
    return descripcionSecccion;
  }

  public void setDescripcionSecccion(String descripcionSecccion)
  {
    this.descripcionSecccion                 = descripcionSecccion;
  }

  public String getIdentificadorCampo()
  {
    return identificadorCampo;
  }

  public void setIdentificadorCampo(String identificadorCampo)
  {
    this.identificadorCampo = identificadorCampo;
  }

  public String getDescripcionIdentificadorCampo()
  {
    return descripcionIdentificadorCampo;
  }

  public void setDescripcionIdentificadorCampo(String descripcionIdentificadorCampo)
  {
    this.descripcionIdentificadorCampo = descripcionIdentificadorCampo;
  }

  public String getNombreCampo()
  {
    return nombreCampo;
  }

  public void setNombreCampo(String nombreCampo)
  {
    this.nombreCampo = nombreCampo;
  }

  public String getDescripcionNombreCampo()
  {
    return descripcionNombreCampo;
  }

  public void setDescripcionNombreCampo(String descripcionNombreCampo)
  {
    this.descripcionNombreCampo = descripcionNombreCampo;
  }

  public String getDatoNuevo()
  {
    return datoNuevo;
  }

  public void setDatoNuevo(String datoNuevo)
  {
    this.datoNuevo = datoNuevo;
  }

  public String getDatoAntiguo()
  {
    return datoAntiguo;
  }

  public void setDatoAntiguo(String datoAntiguo)
  {
    this.datoAntiguo = datoAntiguo;
  }

  public String getEstadoCampo()
  {
    return estadoCampo;
  }

  public void setEstadoCampo(String estadoCampo)
  {
    this.estadoCampo = estadoCampo;
  }

  public Integer getCorrelativo()
  {
    return correlativo;
  }

  public void setCorrelativo(Integer correlativo)
  {
    this.correlativo = correlativo;
  }


}
