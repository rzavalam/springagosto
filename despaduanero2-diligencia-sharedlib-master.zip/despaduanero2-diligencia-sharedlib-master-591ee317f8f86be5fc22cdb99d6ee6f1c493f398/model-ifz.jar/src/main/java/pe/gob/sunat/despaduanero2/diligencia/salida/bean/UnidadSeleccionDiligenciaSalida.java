package pe.gob.sunat.despaduanero2.diligencia.salida.bean;

import java.util.Date;

// para rectificacion de diligencia de salida
public class UnidadSeleccionDiligenciaSalida  implements java.io.Serializable {
	private static final long serialVersionUID = 9138184220738073327L;
	
	private Long numeroCorrelativoDeclaracion;
	private String codigoTipoDiligencia;
	private Long numeroCorrelativoDiligencia;
	private Date fechaDiligencia;
	private Integer numeroParcial;
	private String codigoTransporteMercancia;
	private String descripcionTransporteMercancia;
	private String numeroContenedor;
	private String codigoFuncionario;
	private String nombresFuncionario;
	
	public Long getNumeroCorrelativoDeclaracion() {
		return numeroCorrelativoDeclaracion;
	}
	public void setNumeroCorrelativoDeclaracion(Long numeroCorrelativoDeclaracion) {
		this.numeroCorrelativoDeclaracion = numeroCorrelativoDeclaracion;
	}
	public String getCodigoTipoDiligencia() {
		return codigoTipoDiligencia;
	}
	public void setCodigoTipoDiligencia(String codigoTipoDiligencia) {
		this.codigoTipoDiligencia = codigoTipoDiligencia;
	}
	public Long getNumeroCorrelativoDiligencia() {
		return numeroCorrelativoDiligencia;
	}
	public void setNumeroCorrelativoDiligencia(Long numeroCorrelativoDiligencia) {
		this.numeroCorrelativoDiligencia = numeroCorrelativoDiligencia;
	}
	public Date getFechaDiligencia() {
		return fechaDiligencia;
	}
	public void setFechaDiligencia(Date fechaDiligencia) {
		this.fechaDiligencia = fechaDiligencia;
	}
	public Integer getNumeroParcial() {
		return numeroParcial;
	}
	public void setNumeroParcial(Integer numeroParcial) {
		this.numeroParcial = numeroParcial;
	}
	public String getCodigoTransporteMercancia() {
		return codigoTransporteMercancia;
	}
	public void setCodigoTransporteMercancia(String codigoTransporteMercancia) {
		this.codigoTransporteMercancia = codigoTransporteMercancia;
	}
	public String getDescripcionTransporteMercancia() {
		return descripcionTransporteMercancia;
	}
	public void setDescripcionTransporteMercancia(String descripcionTransporteMercancia) {
		this.descripcionTransporteMercancia = descripcionTransporteMercancia;
	}
	public String getNumeroContenedor() {
		return numeroContenedor;
	}
	public void setNumeroContenedor(String numeroContenedor) {
		this.numeroContenedor = numeroContenedor;
	}
	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}
	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}
	public String getNombresFuncionario() {
		return nombresFuncionario;
	}
	public void setNombresFuncionario(String nombresFuncionario) {
		this.nombresFuncionario = nombresFuncionario;
	}
	
	

}
