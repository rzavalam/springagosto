package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;



import java.io.Serializable;
import java.lang.Double;
import java.lang.Integer;
import java.lang.String;
import java.util.List;


public class Incidencia implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7695786767003924307L;
	
	private Diligencia diligencia;
	private Integer secuenciaIncidencia;
	private DataCatalogo tipoIncidencia;
    private String codIncidencia;
	private String nivelIncidencia;
	private Integer numeroSerie;
	private Integer numeroItem;
	private String sustento;
	private Double montoActual;
	private Double montoCorregido;
	private List<SolicitudSubsanacion> solicitudesSubsanacion;
	
    /******************** CONSTRUCTORES ***************************/


	public Incidencia() {
		tipoIncidencia = new DataCatalogo();
	}
    public Incidencia(Diligencia diligencia) {
        this.diligencia = diligencia;
        tipoIncidencia = new DataCatalogo();
    }

    /********************* SET AND GET ***************************/

	
	/**
	 * @return the diligencia
	 */
	public Diligencia getDiligencia() {
		return diligencia;
	}
	/**
	 * @param diligencia the diligencia to set
	 */
	public void setDiligencia(Diligencia diligencia) {
		this.diligencia = diligencia;
	}
	/**
	 * @return the secuenciaIncidencia
	 */
	public Integer getSecuenciaIncidencia() {
		return secuenciaIncidencia;
	}
	/**
	 * @param secuenciaIncidencia the secuenciaIncidencia to set
	 */
	public void setSecuenciaIncidencia(Integer secuenciaIncidencia) {
		this.secuenciaIncidencia = secuenciaIncidencia;
	}
	/**
	 * @return the tipoIncidencia
	 */
	public DataCatalogo getTipoIncidencia() {
		return tipoIncidencia;
	}

    public String getCodIncidencia() {
        return codIncidencia;
    }

    public void setCodIncidencia(String codIncidencia) {
        this.codIncidencia = codIncidencia;
    }


	/**
	 * @param tipoIncidencia the tipoIncidencia to set
	 */
	public void setTipoIncidencia(DataCatalogo tipoIncidencia) {
		this.tipoIncidencia = tipoIncidencia;
	}
	/**
	 * @return the nivelIncidencia
	 */
	public String getNivelIncidencia() {
		return nivelIncidencia;
	}
	/**
	 * @param nivelIncidencia the nivelIncidencia to set
	 */
	public void setNivelIncidencia(String nivelIncidencia) {
		this.nivelIncidencia = nivelIncidencia;
	}
	/**
	 * @return the numeroSerie
	 */
	public Integer getNumeroSerie() {
		return numeroSerie;
	}
	/**
	 * @param numeroSerie the numeroSerie to set
	 */
	public void setNumeroSerie(Integer numeroSerie) {
		this.numeroSerie = numeroSerie;
	}
	/**
	 * @return the numeroItem
	 */
	public Integer getNumeroItem() {
		return numeroItem;
	}
	/**
	 * @param numeroItem the numeroItem to set
	 */
	public void setNumeroItem(Integer numeroItem) {
		this.numeroItem = numeroItem;
	}
	/**
	 * @return the sustento
	 */
	public String getSustento() {
		return sustento;
	}
	/**
	 * @param sustento the sustento to set
	 */
	public void setSustento(String sustento) {
		this.sustento = sustento;
	}
	/**
	 * @return the montoActual
	 */
	public Double getMontoActual() {
		return montoActual;
	}
	/**
	 * @param montoActual the montoActual to set
	 */
	public void setMontoActual(Double montoActual) {
		this.montoActual = montoActual;
	}
	/**
	 * @return the montoCorregido
	 */
	public Double getMontoCorregido() {
		return montoCorregido;
	}
	/**
	 * @param montoCorregido the montoCorregido to set
	 */
	public void setMontoCorregido(Double montoCorregido) {
		this.montoCorregido = montoCorregido;
	}
	/**
	 * @return the solicitudesSubsanacion
	 */
	public List<SolicitudSubsanacion> getSolicitudesSubsanacion() {
		return solicitudesSubsanacion;
	}
	/**
	 * @param solicitudesSubsanacion the solicitudesSubsanacion to set
	 */
	public void setSolicitudesSubsanacion(List<SolicitudSubsanacion> solicitudesSubsanacion) {
		this.solicitudesSubsanacion = solicitudesSubsanacion;
	}
    public int compareTo(Incidencia compareIncidencia)
    {
      final int BEFORE = -1;
      final int EQUAL = 0;
      final int AFTER = 1;

      int comparison = this.codIncidencia.compareTo(compareIncidencia.getCodIncidencia());
      if (comparison != EQUAL) return comparison;

      if (this.numeroSerie < compareIncidencia.getNumeroSerie()) return BEFORE;
      if (this.numeroSerie > compareIncidencia.getNumeroSerie()) return AFTER;

      return EQUAL;
    }
    
}
