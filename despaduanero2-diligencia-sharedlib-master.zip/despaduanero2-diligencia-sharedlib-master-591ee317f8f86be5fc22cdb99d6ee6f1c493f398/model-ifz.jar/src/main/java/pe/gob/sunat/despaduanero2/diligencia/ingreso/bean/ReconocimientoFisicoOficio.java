package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;

import pe.gob.sunat.despaduanero2.util.SunatDateUtils;


public class ReconocimientoFisicoOficio implements Serializable{
	
	private static final long serialVersionUID = 5400269330785955061L;
	private String funcionarioRecFisicoOficio;
	private String fechaRecFisicoOficio;
	private String horaRecFisicoOficio;
	private String referenciaRecFisicoOficio;
	private String descripcionRecFisicoOficio;
	private String raEnvioConsig;
	private boolean indRecFisicoOficio;
	private Date fecRegis;
	
	public String getFuncionarioRecFisicioOficio() {
		return funcionarioRecFisicoOficio;
	}
	public void setFuncionarioRecFisicioOficio(String funcionarioRecFisicioOficio) {
		this.funcionarioRecFisicoOficio = funcionarioRecFisicioOficio;
	}
	public String getFechaRecFisicoOficio() {
		return fechaRecFisicoOficio;
	}
	public Date getFechaRecFisicoOficioAsDate(){
		return SunatDateUtils.getDate(fechaRecFisicoOficio, "yyyy-MM-dd");
	}
	public Date getFechaRecFisicoOficioAsFormatDate(String formato){
		return SunatDateUtils.getDate(fechaRecFisicoOficio, formato);
	}
	public void setFechaRecFisicoOficio(String fechaRecFisicoOficio) {
		this.fechaRecFisicoOficio = fechaRecFisicoOficio;
	}
	public String getHoraRecFisicoOficio() {
		return horaRecFisicoOficio;
	}
	public void setHoraRecFisicoOficio(String horaRecFisicoOficio) {
		this.horaRecFisicoOficio = horaRecFisicoOficio;
	}
	public String getReferenciaRecFisicoOficio() {
		return referenciaRecFisicoOficio;
	}
	public void setReferenciaRecFisicoOficio(String referenciaRecFisicoOficio) {
		this.referenciaRecFisicoOficio = referenciaRecFisicoOficio;
	}
	public String getDescripcionRecFisicioOficio() {
		return descripcionRecFisicoOficio;
	}
	public void setDescripcionRecFisicioOficio(String descripcionRecFisicioOficio) {
		this.descripcionRecFisicoOficio = descripcionRecFisicioOficio;
	}
	public String getRaEnvioConsig() {
		return raEnvioConsig;
	}
	public void setRaEnvioConsig(String raEnvioConsig) {
		this.raEnvioConsig = raEnvioConsig;
	}
	public boolean isIndRecFisicoOficio() {
		return indRecFisicoOficio;
	}
	public void setIndRecFisicoOficio(boolean indRecFisicoOficio) {
		this.indRecFisicoOficio = indRecFisicoOficio;
	}
	public Date getFecRegis() {
		return fecRegis;
	}
	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}
}
