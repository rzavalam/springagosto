package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;


import java.math.BigDecimal;


/**
 * La Class SeriesProrrateadasBean.
 * es usado en el calculo de prorrateo.
 * almacena los datos finales del proceso de prorrateo
 * de flete y seguro, se muestra en el resumen de prorrateo
 * al momento de grabar la declaracion.
 *
 * @author amancillaa
 * @version 1.0
 * @since 06/05/2013
 */
public class SeriesProrrateadasBean
{

  private Long       numSecSerie;
  private BigDecimal mtoFleteInicial;
  private String     tipoProrrateo;
  private BigDecimal mtoFleteProrrateado;
  private BigDecimal mtoSeguroInicial;
  private String     tipoSeguro;
  private BigDecimal mtoSeguroProrrateado;


  /******************** SET AND GET ***************************/

  public Long getNumSecSerie()
  {
    return numSecSerie;
  }

  public void setNumSecSerie(Long numSecSerie)
  {
    this.numSecSerie = numSecSerie;
  }

  public BigDecimal getMtoFleteInicial()
  {
    return mtoFleteInicial;
  }

  public void setMtoFleteInicial(BigDecimal mtoFleteInicial)
  {
    this.mtoFleteInicial = mtoFleteInicial;
  }

  public String getTipoProrrateo()
  {
    return tipoProrrateo;
  }

  public void setTipoProrrateo(String tipoProrrateo)
  {
    this.tipoProrrateo = tipoProrrateo;
  }

  public BigDecimal getMtoFleteProrrateado()
  {
    return mtoFleteProrrateado;
  }

  public void setMtoFleteProrrateado(BigDecimal mtoFleteProrrateado)
  {
    this.mtoFleteProrrateado = mtoFleteProrrateado;
  }

  public BigDecimal getMtoSeguroInicial()
  {
    return mtoSeguroInicial;
  }

  public void setMtoSeguroInicial(BigDecimal mtoSeguroInicial)
  {
    this.mtoSeguroInicial = mtoSeguroInicial;
  }

  public String getTipoSeguro()
  {
    return tipoSeguro;
  }

  public void setTipoSeguro(String tipoSeguro)
  {
    this.tipoSeguro = tipoSeguro;
  }

  public BigDecimal getMtoSeguroProrrateado()
  {
    return mtoSeguroProrrateado;
  }

  public void setMtoSeguroProrrateado(BigDecimal mtoSeguroProrrateado)
  {
    this.mtoSeguroProrrateado = mtoSeguroProrrateado;
  }

}
