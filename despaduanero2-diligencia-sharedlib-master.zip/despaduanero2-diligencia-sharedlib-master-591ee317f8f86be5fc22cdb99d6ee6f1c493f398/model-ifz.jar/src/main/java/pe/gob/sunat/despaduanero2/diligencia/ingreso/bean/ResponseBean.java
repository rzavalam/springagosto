package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;

public class ResponseBean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5926664929871601516L;
	private boolean estadoExitoso;
	private Object datos;
	private String mensaje;
	
	/**
	 * @return the estadoExitoso
	 */
	public boolean isEstadoExitoso() {
		return estadoExitoso;
	}
	
	/**
	 * @param estadoExitoso the estadoExitoso to set
	 */
	public void setEstadoExitoso(boolean estadoExitoso) {
		this.estadoExitoso = estadoExitoso;
	}
	
	/**
	 * @return the datos
	 */
	public Object getDatos() {
		return datos;
	}
	
	/**
	 * @param datos the datos to set
	 */
	public void setDatos(Object datos) {
		this.datos = datos;
	}
	
	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}
	
	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
