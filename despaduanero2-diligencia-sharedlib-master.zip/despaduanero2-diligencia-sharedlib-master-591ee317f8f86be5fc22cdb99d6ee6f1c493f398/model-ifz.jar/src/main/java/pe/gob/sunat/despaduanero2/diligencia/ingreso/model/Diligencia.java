package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Date;

import javax.annotation.Generated;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.DateUtil;

/**
 *Clase Diligencia.
 */
@Generated("CAB_DILIGENCIA")
public class Diligencia  implements Serializable{

  /**
	 * 
	 */
  private static final long serialVersionUID = 3789174415086902894L;

@Generated("NUM_CORREDOC")
  private Long numeroCorrelativo;

  @Generated("COD_TIPDILIGENCIA")
  private String codigoTipoDiligencia;

  @Generated("IND_INCIDENCIA")
  private String indicarIncidencia;

  @Generated("IND_MULTA")
  private String indicadorMulta;

  @Generated("IND_IMAGEN")
  private String indicadorImagen;

  @Generated("IND_PASEARECFISICO")
  private String indicadorPaseReconoFisico ;

  @Generated("IND_PLAZO")
  private String indicadorPlazo;

  @Generated("COD_CATALOGO")//Codigo del catalogo de solicitud 339 - 357
  private String codigoCatalogoSolicitud;

  @Generated("COD_MOTIVO")
  private String codigoMotivoSolicitud;

  @Generated("FEC_CONCLUSION")//Fecha sugerida en la ampliacion del plaso
  private Date fechaConclusion;

  @Generated("COD_TIPLUGARDILIG")
  private String codigoTipoLugarDiligencia;

  @Generated("NUM_RUCLUGARDILIG")
  private String numeroRucLugarDiligencia;

  @Generated("NUM_DECLARACION")
  private String numDeclaracion;
  
  @Generated("COD_ADUANA")
  private String codAduana;
  
  @Generated("COD_REGIMEN")
  private String codRegimen;
  
  @Generated("ANN_PRESEN")
  private String annPresen;

  /** Local anexo del lugar de la diligencia. */
  @Generated("COD_LOCALANEXO ")
  private String codigoLocalAnexo;

  @Generated("DES_RESULTADO")
  private String descripcionResultado;

  @Generated("CNT_BULTOSRECON")
  private Long cantidadBultosReconocidos;

  /** Codigo del funcionario quien efectua la diligencia (catalogo de RRHH). */
  @Generated("COD_FUNCIONARIO")
  private String codigoFuncionario;

  private String nombreFuncionario;

  @Generated("FEC_DILIGENCIA")
  private Date fechaDiligencia;

  @Generated("NUM_CORREDOC_SOL")
  private Long numeroCorrelativoSolicitud;
/*INICIO-RIN13*/
  private Declaracion declaracion;
/*FIN-RIN13*/  
	
  // RIN13-SWF	
  private List<Incidencia> incidencias;

  @Generated("IND_GRABADO")
  private String indicadorGrabado;  
  
  
  @Generated("COD_ESTDILIG")
  private String codEstadoDiligencia;  
  
  // Diligencia 01 - registro, rectificacion y anulacion de diligencia de salida - atributos adicionales
  private String indicadorBoletinQuimico;
  private Integer numeroParcial;
  private Long correlativoTransporteMercancia;
  private String codigoUnidadDiligencia;
  

  /******************** CONSTRUCTORES ***************************/

  public Diligencia(){
    super();
  }

  /**
   * Contructor para realizar consultas por primary key
   * @param numeroCorrelativo num_corredoc de la dua
   * @param numeroCorrelativoSolicitud num_corredoc_sol de la solicitud de rectificacion
   */
  public Diligencia(Long numeroCorrelativo, Long numeroCorrelativoSolicitud)
  {
    this.numeroCorrelativo = numeroCorrelativo;
    this.numeroCorrelativoSolicitud = numeroCorrelativoSolicitud;
    // RIN13-SWF
    this.incidencias = new ArrayList<Incidencia>();
  }

  /**
   * Si no se requiere el num_corredoc_sol
   *
   * @param numeroCorrelativo
   */
  public Diligencia(Long numeroCorrelativo)
  {
    this.numeroCorrelativo = numeroCorrelativo;
    this.numeroCorrelativoSolicitud = new Long(0);
  }

    /********************* METODOS DE NEGOCIO ***************************/
	// RIN13-SWF
    public void registrarIncidencia(Incidencia incidencia) {

        if (!isRegistradoIncidencia(incidencia))
            incidencias.add(incidencia);
        else
            throw new IllegalStateException("incidencia ya se encuentra registrada");
    }
	// RIN13-SWF
     public boolean isRegistradoIncidencia(Incidencia incidencia) {
        return incidencias.contains(incidencia);
     }


  /********************* SET AND GET ***************************/


  public Long getNumeroCorrelativo()
  {
    return numeroCorrelativo;
  }

  public void setNumeroCorrelativo(Long numeroCorrelativo)
  {
    this.numeroCorrelativo = numeroCorrelativo;
  }

  public String getCodigoTipoDiligencia()
  {
    return codigoTipoDiligencia;
  }

  public void setCodigoTipoDiligencia(String codigoTipoDiligencia)
  {
    this.codigoTipoDiligencia = codigoTipoDiligencia;
  }

  public String getIndicarIncidencia()
  {
    return indicarIncidencia;
  }

  public void setIndicarIncidencia(String indicarIncidencia)
  {
    this.indicarIncidencia = indicarIncidencia;
  }

  public String getIndicadorMulta()
  {
    return indicadorMulta;
  }

  public void setIndicadorMulta(String indicadorMulta)
  {
    this.indicadorMulta = indicadorMulta;
  }

  public String getIndicadorImagen()
  {
    return indicadorImagen;
  }

  public void setIndicadorImagen(String indicadorImagen)
  {
    this.indicadorImagen = indicadorImagen;
  }

  public String getIndicadorPaseReconoFisico()
  {
    return indicadorPaseReconoFisico;
  }

  public void setIndicadorPaseReconoFisico(String indicadorPaseReconoFisico)
  {
    this.indicadorPaseReconoFisico = indicadorPaseReconoFisico;
  }

  public String getIndicadorPlazo()
  {
    return indicadorPlazo;
  }

  public void setIndicadorPlazo(String indicadorPlazo)
  {
    this.indicadorPlazo = indicadorPlazo;
  }

  public String getCodigoCatalogoSolicitud()
  {
    return codigoCatalogoSolicitud;
  }

  public void setCodigoCatalogoSolicitud(String codigoCatalogoSolicitud)
  {
    this.codigoCatalogoSolicitud = codigoCatalogoSolicitud;
  }

  public String getCodigoMotivoSolicitud()
  {
    return codigoMotivoSolicitud;
  }

  public void setCodigoMotivoSolicitud(String codigoMotivoSolicitud)
  {
    this.codigoMotivoSolicitud = codigoMotivoSolicitud;
  }

  public Date getFechaConclusion()
  {
    return fechaConclusion;
  }

  public void setFechaConclusion(Date fechaConclusion)
  {
    this.fechaConclusion = fechaConclusion;
  }

  public String getCodigoTipoLugarDiligencia()
  {
    return codigoTipoLugarDiligencia;
  }

  public void setCodigoTipoLugarDiligencia(String codigoTipoLugarDiligencia)
  {
    this.codigoTipoLugarDiligencia = codigoTipoLugarDiligencia;
  }

  public String getNumeroRucLugarDiligencia()
  {
    return numeroRucLugarDiligencia;
  }

  public void setNumeroRucLugarDiligencia(String numeroRucLugarDiligencia)
  {
    this.numeroRucLugarDiligencia = numeroRucLugarDiligencia;
  }
  
    public String getNumDeclaracion()
  {
    return numDeclaracion;
  }

  public void setNumDeclaracion(String numDeclaracion)
  {
    this.numDeclaracion = numDeclaracion;
  }
  
  public String getCodAduana()
  {
    return codAduana;
  }

  public void setCodAduana(String codAduana)
  {
    this.codAduana = codAduana;
  }
  
  public String getCodRegimen()
  {
    return codRegimen;
  }

  public void setCodRegimen(String codRegimen)
  {
    this.codRegimen = codRegimen;
  }
  
  public String getAnnPresen()
  {
    return annPresen;
  }

  public void setAnnPresen(String annPresen)
  {
    this.annPresen = annPresen;
  }

  public String getCodigoLocalAnexo()
  {
    return codigoLocalAnexo;
  }

  public void setCodigoLocalAnexo(String codigoLocalAnexo)
  {
    this.codigoLocalAnexo = codigoLocalAnexo;
  }

  public String getDescripcionResultado()
  {
    return descripcionResultado;
  }

  public void setDescripcionResultado(String descripcionResultado)
  {
    this.descripcionResultado = descripcionResultado;
  }

  public Long getCantidadBultosReconocidos()
  {
    return cantidadBultosReconocidos;
  }

  public void setCantidadBultosReconocidos(Long cantidadBultosReconocidos)
  {
    this.cantidadBultosReconocidos = cantidadBultosReconocidos;
  }

  public String getCodigoFuncionario()
  {
    return codigoFuncionario;
  }

  public void setCodigoFuncionario(String codigoFuncionario)
  {
    this.codigoFuncionario = codigoFuncionario;
  }

  public Date getFechaDiligencia()
  {
    return fechaDiligencia;
  }

  public void setFechaDiligencia(Date fechaDiligencia)
  {
    this.fechaDiligencia = fechaDiligencia;
  }

  public Long getNumeroCorrelativoSolicitud()
  {
    return numeroCorrelativoSolicitud;
  }

  public void setNumeroCorrelativoSolicitud(Long numeroCorrelativoSolicitud)
  {
    this.numeroCorrelativoSolicitud = numeroCorrelativoSolicitud;
  }

  public String getNombreFuncionario()
  {
    return nombreFuncionario;
  }

  public void setNombreFuncionario(String nombreFuncionario)
  {
    this.nombreFuncionario = nombreFuncionario;
  }

/*INICIO-RIN13*/  
	/**
	 * @return the declaracion
	 */
	public Declaracion getDeclaracion() {
		return declaracion;
	}

	/**
	 * @param declaracion the declaracion to set
	 */
	public void setDeclaracion(Declaracion declaracion) {
		this.declaracion = declaracion;
	}

	public String getStrFechaDiligencia() {	
		try {
			return DateUtil.dateToString(this.fechaDiligencia, "yyyy-MM-dd");			
		} catch (Exception e) {
			return "";			
		}
	}
/*FIN-RIN13*/  
  // RIN13-SWF
  public List<Incidencia> getIncidencias() {
        return Collections.unmodifiableList(incidencias);
  }

	/**
	 * @return the indicadorGrabado
	 */
	public String getIndicadorGrabado() {
		return indicadorGrabado;
	}
	
	/**
	 * @param indicadorGrabado the indicadorGrabado to set
	 */
	public void setIndicadorGrabado(String indicadorGrabado) {
		this.indicadorGrabado = indicadorGrabado;
	}

	/**
	 * @return the codEstadoDiligencia
	 */
	public String getCodEstadoDiligencia() {
		return codEstadoDiligencia;
	}

	/**
	 * @param codEstadoDiligencia the codEstadoDiligencia to set
	 */
	public void setCodEstadoDiligencia(String codEstadoDiligencia) {
		this.codEstadoDiligencia = codEstadoDiligencia;
	}

	public String getIndicadorBoletinQuimico() {
		return indicadorBoletinQuimico;
	}

	public void setIndicadorBoletinQuimico(String indicadorBoletinQuimico) {
		this.indicadorBoletinQuimico = indicadorBoletinQuimico;
	}

	public Integer getNumeroParcial() {
		return numeroParcial;
	}

	public void setNumeroParcial(Integer numeroParcial) {
		this.numeroParcial = numeroParcial;
	}

	public Long getCorrelativoTransporteMercancia() {
		return correlativoTransporteMercancia;
	}

	public void setCorrelativoTransporteMercancia(Long correlativoTransporteMercancia) {
		this.correlativoTransporteMercancia = correlativoTransporteMercancia;
	}

	public String getCodigoUnidadDiligencia() {
		return codigoUnidadDiligencia;
	}

	public void setCodigoUnidadDiligencia(String codigoUnidadDiligencia) {
		this.codigoUnidadDiligencia = codigoUnidadDiligencia;
	}
}
