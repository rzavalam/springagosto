package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
// RIN16
import pe.gob.sunat.despaduanero2.asignacion.bean.TipoProceso;


public class BusquedaDua implements Serializable {

	private static final long	serialVersionUID	= -5337615526026084539L;

	private Long				numCorreDoc;
	private String				codAduana;
	private Long				numDeclaracion;
	private Long				annoPresenta;
	private String				codRegimen;
	//numCorreDoc de la solicitud puede ser rectificacion o regularizacion
	private Long                numCorreDocSol;
	//f2_3005_req_RIN16_Regularizacion
	private TipoProceso tipoProceso;

    /*INICIO-P34 FSW AFMA*/
    private String registroUsuarioLogeado;
    /*FIN-P34 FSW AFMA*/

    public BusquedaDua() {
        super();
    }

    public BusquedaDua(Map<String, Object> mapDua) {

        super();
        numCorreDoc = mapDua.get("NUM_CORREDOC") != null ? new Long(mapDua.get("NUM_CORREDOC").toString()) : 0;
        codAduana = mapDua.get("COD_ADUANA") != null ? mapDua.get("COD_ADUANA").toString() : "";
        numDeclaracion = mapDua.get("NUM_DECLARACION") != null ? new Long(mapDua.get("NUM_DECLARACION").toString()) : 0;
        annoPresenta = mapDua.get("ANN_PRESEN") != null ? new Long(mapDua.get("ANN_PRESEN").toString()) : 0;
        codRegimen   = mapDua.get("COD_REGIMEN") != null ? mapDua.get("COD_REGIMEN").toString() : "";
        numCorreDocSol = mapDua.get("NUM_CORREDOC_SOL") != null ? new Long(mapDua.get("NUM_CORREDOC_SOL").toString()) : 0;

    }

    public BusquedaDua(Long numCorreDoc, String codAduana, Long numDeclaracion, Long annoPresenta, String codRegimen
            ,Long numCorreDocSol) {

        super();
        this.numCorreDoc = numCorreDoc;
        this.codAduana = codAduana;
        this.numDeclaracion = numDeclaracion;
        this.annoPresenta = annoPresenta;
        this.codRegimen = codRegimen;
        this.numCorreDocSol = numCorreDocSol;
    }
    //f2_3005_req_RIN16_Regularizacion
    public BusquedaDua(String codAduana, Long numDeclaracion, Long annoPresenta, String codRegimen) {
        super();
        this.codAduana = codAduana;
        this.numDeclaracion = numDeclaracion;
        this.annoPresenta = annoPresenta;
        this.codRegimen = codRegimen;
    }

    public Map<String, Object> convertMap(){
        Map<String, Object> mapBusquedaDua = new HashMap<String, Object>();
        mapBusquedaDua.put("NUM_CORREDOC", this.numCorreDoc);
        mapBusquedaDua.put("COD_ADUANA", this.codAduana);
        mapBusquedaDua.put("NUM_DECLARACION", this.numDeclaracion);
        mapBusquedaDua.put("ANN_PRESEN", this.annoPresenta);
        mapBusquedaDua.put("COD_REGIMEN", this.codRegimen);
        mapBusquedaDua.put("NUM_CORREDOC_SOL", this.numCorreDocSol);

        return mapBusquedaDua;
    }

 //f2_3005_req_RIN16_Regularizacion
 // Obtener un mapa con los par�metros necesarios para realizar la b�squeda de la declaraci�n    
    public Map<String, Object> convertMapParaBuscarDUA(){
        Map<String, Object> mapBusquedaDua = new HashMap<String, Object>();
        mapBusquedaDua.put("numeroCorrelativo", this.numCorreDoc);
        mapBusquedaDua.put("codigoAduana", this.codAduana);
        mapBusquedaDua.put("numeroDeclaracion", this.numDeclaracion);
        mapBusquedaDua.put("annoPresentacion", this.annoPresenta);
        mapBusquedaDua.put("codigoRegimen", this.codRegimen);
        return mapBusquedaDua;
    }

	public Long getNumCorreDoc(){

		return numCorreDoc;
	}

	public void setNumCorreDoc(Long numCorreDoc){

		this.numCorreDoc = numCorreDoc;
	}

	public String getCodAduana(){

		return codAduana;
	}

	public void setCodAduana(String codAduana){

		this.codAduana = codAduana;
	}

	public Long getNumDeclaracion(){

		return numDeclaracion;
	}

	public void setNumDeclaracion(Long numDeclaracion){

		this.numDeclaracion = numDeclaracion;
	}

	public Long getAnnoPresenta(){

		return annoPresenta;
	}

	public void setAnnoPresenta(Long annoPresenta){

		this.annoPresenta = annoPresenta;
	}

	public String getCodRegimen(){

		return codRegimen;
	}

	public void setCodRegimen(String codRegimen){

		this.codRegimen = codRegimen;
	}


    public Long getNumCorreDocSol(){

        return numCorreDocSol;
    }

    public void setNumCorreDocSol(Long numCorreDocSol){

        this.numCorreDocSol = numCorreDocSol;
    }
// RIN16
	public TipoProceso getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(TipoProceso tipoProceso) {
		this.tipoProceso = tipoProceso;
	}
// RIN16
    @Override
    public String toString(){

        return "BusquedaDua con datos [numCorreDoc:" + getNumCorreDoc() + ",codAduana:" + getCodAduana()
                + ",annPresen:" + getAnnoPresenta() + ",codRegimen:" + getCodRegimen() + ",numDeclaracion:"
                + getNumDeclaracion() +",numCorreDocSol:"+getNumCorreDocSol()+ "]";
    }

/*INICIO-P34 FSW AFMA*/
    public String getRegistroUsuarioLogeado()
    {
        return registroUsuarioLogeado;
    }

    public void setRegistroUsuarioLogeado(String registroUsuarioLogeado)
    {
        this.registroUsuarioLogeado = registroUsuarioLogeado;
    }
}