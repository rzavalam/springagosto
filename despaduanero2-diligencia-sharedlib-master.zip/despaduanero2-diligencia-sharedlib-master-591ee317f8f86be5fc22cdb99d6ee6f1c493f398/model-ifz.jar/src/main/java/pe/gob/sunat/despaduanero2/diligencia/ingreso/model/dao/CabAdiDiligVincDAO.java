package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.Map;


/**
 * The Interface CabAdiDiligVincDAO.
 */
public interface CabAdiDiligVincDAO
{

  /**
   * Insertar un registro de CabAdiDiligVinc
   * @param params objeto a insertar
   */
  public void insert(Map<String, Object> params);


  /**
   * Gets the by tipo diligencia.
   *
   * @param params
   *          the params
   * @return the by tipo diligencia
   */
  public Map<String, Object> getByTipoDiligencia(Map<String, Object> params);
}
