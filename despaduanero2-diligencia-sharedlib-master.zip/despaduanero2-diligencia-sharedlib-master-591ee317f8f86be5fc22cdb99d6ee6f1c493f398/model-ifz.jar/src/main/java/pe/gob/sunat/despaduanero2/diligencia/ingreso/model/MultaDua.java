package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;

import java.io.Serializable;
import java.util.Date;

public class MultaDua implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long numCorreDoc;
	private String codTipoDiligencia;
	private String codMulta;
	private String montoMulta;
	private Double porcDescuento;
	private Double montoTotalMulta;
	private String indLC;
	private String numLC;
	private Long annLC;
	private String codAduanaLC;
	private String desExoneraLC;
	private String codFuncionario;
	private String indDel;
	private String codUsuaRegistro;
	private Date fecRegistro;
	private String codUsuaModificacion;
	private Date fecModificacion;
	private Long numCorredocSol;
	
	public Long getNumCorreDoc() {
		return numCorreDoc;
	}
	
	public void setNumCorreDoc(Long numCorreDoc) {
		this.numCorreDoc = numCorreDoc;
	}
	
	public String getCodTipoDiligencia() {
		return codTipoDiligencia;
	}
	
	public void setCodTipoDiligencia(String codTipoDiligencia) {
		this.codTipoDiligencia = codTipoDiligencia;
	}
	
	public String getCodMulta() {
		return codMulta;
	}
	
	public void setCodMulta(String codMulta) {
		this.codMulta = codMulta;
	}
	
	public String getMontoMulta() {
		return montoMulta;
	}
	
	public void setMontoMulta(String montoMulta) {
		this.montoMulta = montoMulta;
	}
	public Double getPorcDescuento() {
		return porcDescuento;
	}
	public void setPorcDescuento(Double porcDescuento) {
		this.porcDescuento = porcDescuento;
	}
	public Double getMontoTotalMulta() {
		return montoTotalMulta;
	}
	public void setMontoTotalMulta(Double montoTotalMulta) {
		this.montoTotalMulta = montoTotalMulta;
	}
	public String getIndLC() {
		return indLC;
	}
	public void setIndLC(String indLC) {
		this.indLC = indLC;
	}
	public String getNumLC() {
		return numLC;
	}
	public void setNumLC(String numLC) {
		this.numLC = numLC;
	}
	public Long getAnnLC() {
		return annLC;
	}
	public void setAnnLC(Long annLC) {
		this.annLC = annLC;
	}
	public String getCodAduanaLC() {
		return codAduanaLC;
	}
	public void setCodAduanaLC(String codAduanaLC) {
		this.codAduanaLC = codAduanaLC;
	}
	public String getDesExoneraLC() {
		return desExoneraLC;
	}
	public void setDesExoneraLC(String desExoneraLC) {
		this.desExoneraLC = desExoneraLC;
	}
	public String getCodFuncionario() {
		return codFuncionario;
	}
	public void setCodFuncionario(String codFuncionario) {
		this.codFuncionario = codFuncionario;
	}
	public String getIndDel() {
		return indDel;
	}
	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}
	public String getCodUsuaRegistro() {
		return codUsuaRegistro;
	}
	public void setCodUsuaRegistro(String codUsuaRegistro) {
		this.codUsuaRegistro = codUsuaRegistro;
	}
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getCodUsuaModificacion() {
		return codUsuaModificacion;
	}
	public void setCodUsuaModificacion(String codUsuaModificacion) {
		this.codUsuaModificacion = codUsuaModificacion;
	}
	public Date getFecModificacion() {
		return fecModificacion;
	}
	public void setFecModificacion(Date fecModificacion) {
		this.fecModificacion = fecModificacion;
	}
	public Long getNumCorredocSol() {
		return numCorredocSol;
	}
	public void setNumCorredocSol(Long numCorredocSol) {
		this.numCorredocSol = numCorredocSol;
	}
	
	
	
}
