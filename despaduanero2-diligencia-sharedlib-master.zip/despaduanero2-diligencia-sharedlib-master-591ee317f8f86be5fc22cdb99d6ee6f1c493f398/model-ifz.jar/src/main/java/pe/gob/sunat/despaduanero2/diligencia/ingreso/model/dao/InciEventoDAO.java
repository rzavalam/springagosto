package pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.EventoIncidencia;


/**
 * The Interface InciEventoDAO.
 *
 * @author rdelosreyes
 */
public interface InciEventoDAO
{


  /**
   * Obtiene un listado de InciEvento
   * @param params
   * @return
   * @throws DataAccessException
   */
  public List<Map<String, String>> getInciEventoList(Map<String, Object> params) throws DataAccessException;

  // RIN13-SWF
  public List<EventoIncidencia> getLstInciEvento() throws DataAccessException;

}
