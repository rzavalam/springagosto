package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;


import java.math.BigDecimal;


/**
 * La Class SumaFleteYPesoPorDocTransporteBean.
 * es usado en el calculo de prorrateo de flete.
 *
 * @author amancillaa
 * @version 1.0
 * @since 06/05/2013
 */
public class SumaFleteYPesoPorDocTransporteBean
{

  /* se mustra al usuario en caso sea mas de 1 BL*/
  private String     docTransporte;
  /* este cammpo es basicamente para mostrar al usuario el flete calculado inicla por BL para que confirme*/
  private BigDecimal sumaFleteInicial;
  /* flete a prorratear 1ero le quitan los tipo 1, calcula los tipos 3 y lo resta y por ultimo calculo los tipo 2*/
  private BigDecimal sumaFleteAProrratear;
 // private BigDecimal sumaFleteTipo1;
  /* campo de uso del sistema para ir actualizando lo que va quedando del flete*/
  private BigDecimal sumaFleteRealProrratear;
  /* tipo flete3 que se llena cuando procesa el prorrateo para el 3*/
  private BigDecimal sumaFleteTipo3;
 // private BigDecimal sumaFleteTipo2;
  /* suma de peso buto de los tipos de prorrateo de flete 2 y 3 los 1 no se deben considerar*/
  private BigDecimal sumaPesoBruto;

  /******************** CONSTRUCTORES ***************************/

  public SumaFleteYPesoPorDocTransporteBean()
  {
    super();
  }

  /**
   * Instantiates a new suma flete y peso por doc transporte bean.
   *
   * @param docTransporte
   *          [String] doc transporte
   * @param sumaFleteAProrratear
   *          [BigDecimal] suma flete a prorratear
   */
  public SumaFleteYPesoPorDocTransporteBean(String docTransporte,
                                            BigDecimal sumaFleteAProrratear)
  {

    this.docTransporte = docTransporte;
    this.sumaFleteAProrratear = sumaFleteAProrratear;
  }

  /******************** SET AND GET ***************************/

  public BigDecimal getSumaPesoBruto()
  {
    return sumaPesoBruto;
  }

  public void setSumaPesoBruto(BigDecimal sumaPesoBruto)
  {
    this.sumaPesoBruto = sumaPesoBruto;
  }

  public BigDecimal getSumaFleteRealProrratear()
  {
    return sumaFleteRealProrratear;
  }

  public void setSumaFleteRealProrratear(BigDecimal sumaFleteRealProrratear)
  {
    this.sumaFleteRealProrratear = sumaFleteRealProrratear;
  }


  public BigDecimal getSumaFleteAProrratear()
  {
    return sumaFleteAProrratear != null ? sumaFleteAProrratear : new BigDecimal(0);
  }

  public void setSumaFleteAProrratear(BigDecimal sumaFleteAProrratear)
  {
    this.sumaFleteAProrratear = sumaFleteAProrratear;
  }

  public String getDocTransporte()
  {
    return docTransporte;
  }

  public void setDocTransporte(String docTransporte)
  {
    this.docTransporte = docTransporte;
  }

  public BigDecimal getSumaFleteTipo3()
  {
    return sumaFleteTipo3 != null ? sumaFleteTipo3 : new BigDecimal(0);
  }

  public void setSumaFleteTipo3(BigDecimal sumaFleteTipo3)
  {
    this.sumaFleteTipo3 = sumaFleteTipo3;
  }


  public BigDecimal getSumaFleteInicial()
  {
    return sumaFleteInicial;
  }

  public void setSumaFleteInicial(BigDecimal sumaFleteInicial)
  {
    this.sumaFleteInicial = sumaFleteInicial;
  }

}
