package pe.gob.sunat.despaduanero2.diligencia.ingreso.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.util.SunatDateUtils;

public class ResolucionMulta implements Serializable {
	
	
	private static final long serialVersionUID = -5337615556123087589L;
	
	private String codAduanaMulta;
	private String codAreaMulta;
	private String codTipoDocMulta;
	private Integer numeroMulta;
	private Date fechaEmisionMulta;
	
	public Map<String, Object> convertirAMapa(ResolucionMulta resolMulta){
		Map<String, Object> mapResolMulta = new HashMap<String, Object>();
		mapResolMulta.put("codAduanaResol", resolMulta.getCodAduanaMulta());
		mapResolMulta.put("codTipoDocResol", Integer.parseInt(resolMulta.getCodTipoDocMulta()));
		mapResolMulta.put("codAreaResol", resolMulta.getCodAreaMulta());
		mapResolMulta.put("numeroResol", resolMulta.getNumeroMulta());
		mapResolMulta.put("fechaEmisionResol", SunatDateUtils.getIntegerFromDate(resolMulta.getFechaEmisionMulta()));
	   	return mapResolMulta;
	}
	
	public String getCodAduanaMulta() {
		return codAduanaMulta;
	}
	public void setCodAduanaMulta(String codAduanaMulta) {
		this.codAduanaMulta = codAduanaMulta;
	}
	public String getCodAreaMulta() {
		return codAreaMulta;
	}
	public void setCodAreaMulta(String codAreaMulta) {
		this.codAreaMulta = codAreaMulta;
	}
	public String getCodTipoDocMulta() {
		return codTipoDocMulta;
	}
	public void setCodTipoDocMulta(String codTipoDocMulta) {
		this.codTipoDocMulta = codTipoDocMulta;
	}
	public Integer getNumeroMulta() {
		return numeroMulta;
	}
	public void setNumeroMulta(Integer numeroMulta) {
		this.numeroMulta = numeroMulta;
	}
	public Date getFechaEmisionMulta() {
		return fechaEmisionMulta;
	}
	public void setFechaEmisionMulta(Date fechaEmisionMulta) {
		this.fechaEmisionMulta = fechaEmisionMulta;
	}
}