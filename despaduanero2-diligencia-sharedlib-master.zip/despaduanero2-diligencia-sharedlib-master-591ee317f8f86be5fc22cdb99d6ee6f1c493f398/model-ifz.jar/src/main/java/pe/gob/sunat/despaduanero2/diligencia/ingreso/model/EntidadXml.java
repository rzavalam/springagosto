package pe.gob.sunat.despaduanero2.diligencia.ingreso.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * <p>Titulo: Clase Utilitaria EntidadMapeo.</p>
 * <p>Descripcion: Clase que contiene los datos de la entidad mapeada en el archivo XML de configuracion.</p>
 * <p>Clase: pe.gob.sunat.despaduanero2.diligencia.ingreso.util.EntidadMapeo.java</p>
 * <p>Copyright: SUNAT-2011</p>
 *
 * @version 1.0
 */
public class EntidadXml implements Serializable{


    /**
     *
     */
    private static final long serialVersionUID = 2975843811587204429L;

    /**
     * Nombre de la entidad
     */
    private String nombre= "";
    /**
     * Lista de campos de la Entidad a mapear.
     */
    private List<CampoXml> campos = new ArrayList<CampoXml>();

    /**
     * Nombre de la secuencia a emplear por la tabla al momento de insercion.
     */
    private String nombreSecuencia = "";
    /**
     * Sinonimo de la entidad.
     */
    private String nombreSinonimoBD = "";
//	/**
//	 * Codigo de la entidad empleado dentro de la tabla rectiOficio al momento de algun cambio.
//	 */
//	private String codigoRectiOficio="";
    /**
     * Nombre de la Base de Datos
     */
//	private String nombreBD="";
    /**
     * Lista de los nombres de la clave para la entidad
     */
    private List<String> lstClave= new ArrayList<String>();


    /**
     * Lista de los relaciones entre entidades
     */
    private List<EntidadRelacionesXml> lstRelaciones = new ArrayList<EntidadRelacionesXml>();


    //GETTERs and SETTERs
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public List<CampoXml> getCampos() {
        return campos;
    }
    public void setCampos(List<CampoXml> campos) {
        this.campos = campos;
    }
    public String getNombreSecuencia() {
        return nombreSecuencia;
    }
    public void setNombreSecuencia(String nombreSecuencia) {
        this.nombreSecuencia = nombreSecuencia;
    }
    public String getNombreSinonimoBD() {
        return nombreSinonimoBD;
    }
    public void setNombreSinonimoBD(String nombreSinonimoBD) {
        this.nombreSinonimoBD = nombreSinonimoBD;
    }
    public List<String> getLstClave() {
        return lstClave;
    }
    public void setLstClave(List<String> lstClave) {
        this.lstClave = lstClave;
    }
    public void setLstClave(String[] lstClave) {
        for(String cadena: lstClave){
            this.lstClave.add(cadena);
        }
    }

    public List<EntidadRelacionesXml> getLstRelaciones() {
        return lstRelaciones;
    }
    public void setLstRelaciones(List<EntidadRelacionesXml> lstRelaciones) {
        this.lstRelaciones = lstRelaciones;
    }

    @Override
    public String toString() {
        return "EntidadXml [nombre=" + nombre + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EntidadXml other = (EntidadXml) obj;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        return true;
    }
}
