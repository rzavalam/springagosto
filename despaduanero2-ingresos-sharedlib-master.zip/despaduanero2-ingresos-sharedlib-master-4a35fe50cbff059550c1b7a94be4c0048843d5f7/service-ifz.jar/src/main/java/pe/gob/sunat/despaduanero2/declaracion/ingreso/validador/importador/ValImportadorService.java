package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.importador;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;

public interface ValImportadorService {
	public List<Map<String, String>> validaExistenciaDNI(Declaracion declaracion) throws ParseException;
	
	public List<Map<String, String>> valMayoriaEdad(Declaracion declaracion) throws ParseException;
	
	public List<Map<String, String>> valCondicionPersona(Declaracion declaracion) throws ParseException;
	
	public List<Map<String, String>> valTipoDocumentoPermitido(Declaracion declaracion);
	
	public List<Map<String, String>> valRegistroOrganismoInternacional(Declaracion declaracion);
	
	public List<Map<String, String>> valObligatoriedadRazonSocial(Declaracion declaracion);
	
	public List<Map<String, String>> valObligatoriedadDireccion(Declaracion declaracion);
	
	public List<Map<String, String>> validarEstadoRUCImportador(DUA dua);

	public List<Map<String, ?>> validarMandatoriedadTipoNroDocumento(Participante participante);
}
