/*
 * Clase que define el servicio de validaciones de 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMedioTransporte;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * @deprecated Esta clase invoca a validacion de atributos de DatoMedioTransporte que no se cargan de informacion
 * The Class ValMTrans. 
 */
public interface ValMTrans {
	
	public Map<String, String> numsecuTransporte(Elementos<DatoMedioTransporte> listDatoMedioTransporte);
	
	public Map<String, String> nommedtransp(String nommedtransp);
	
	public Map<String, String> codnactransp(String codnactransp);
	
}
