package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface MontosCertifiOrigenService {
	
	/**
	 * Cuando no se tienen Certificado de Origen, se valida que el CIF de la serie no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoCIFEnvioNoRequiereCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando no se tienen Certificado de Origen, y existen varias series con la misma subpartida los valores CIF no debe ser mayor al permitido por tipo de TLC
	 * @param Declaracion
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valMontoCIFSubpartidaNoRequiereCO(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando se tiene como CO una Declaracion de Origen, se valida que el CIF de la serie no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoCIFEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando se tiene como CO una Declaracion de Origen, se valida que el CIF de la serie con la misma factura no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoCIFFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando no se requiere un CO, se valida que el valor CIF de la serie con la misma factura no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoCIFFacturaNoRequiereCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion);
	
	/**
	 * Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura en USD no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoUSDFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	
	/**
	 * Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura tanto en EUR como en USD no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valMontoUSDEURFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura en EUR o su equivalente no supere el monto maximo permitido por tipo de TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valMontoEURFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Cuando el CO corresponda a una Declaracion de origen, se valida que no exista una DUA o DSI a nivel nacional con los datos del certificado y factura
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valUsoCOPorTipoFactura(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	
	/**
	 * Cuando no se requiere un CO, se valida que no exista una DUA o DSI a nivel nacional con los datos del certificado, factura y manifiesto y que no supere el monto establecido para el TLC
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valUsoCOPorTipoManifiesto(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> valMontoUSDEURFacturaEnvioDeclaracionNivelNacional(Declaracion declaracion, Date fechaReferencia) ;
	
	public Map<String, String> valMontoEURFacturaEnvioDeclaracionNivelNacional(Declaracion declaracion, Date fechaReferencia); 
	
	public List<Map<String, String>> valMontoCIFFacturaProveedorEnvioDeclaracion( Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) ;
	
	public Map<String, String> valUsoCOPorTipoFacturaProveedor(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion);
	
	public List<Map<String, String>> valMontoImportadorProveedorPeriodo(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> valMontoCIFProveedorConSinCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion);
	
	public List<Map<String, String>> valMontoCIFFacturaProveedorNoRequiereCO( Declaracion declaracion,  Date fechaReferencia);
	
}
