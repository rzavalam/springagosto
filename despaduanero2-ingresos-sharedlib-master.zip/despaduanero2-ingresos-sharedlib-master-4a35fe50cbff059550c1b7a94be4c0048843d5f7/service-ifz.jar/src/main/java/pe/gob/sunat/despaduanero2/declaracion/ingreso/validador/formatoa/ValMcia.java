/*
 * Clase que define el servicio de validaciones de la mercancia
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Map;

/**
 * The Class ValMcia. Clase que define el servicio de validaciones de la mercancia.
 */
public interface ValMcia {
	
	public Map<String, String> codtipoexoneracion(String codtipoexoneracion);
	
	public Map<String, String> codexoneracion(String codexoneracion);
	
	public Map<String, String> codproducto(String codproducto);
	
	public Map<String, String> codriesgosanitario(String codriesgosanitario);
	
}
