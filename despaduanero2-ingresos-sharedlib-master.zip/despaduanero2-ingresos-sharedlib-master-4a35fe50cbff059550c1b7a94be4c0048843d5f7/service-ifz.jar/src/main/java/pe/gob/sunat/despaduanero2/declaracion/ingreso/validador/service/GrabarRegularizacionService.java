package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarRegularizacionService {

	public Map<String, String> grabarRegularizacion(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion,			
			Map<String, Object> variablesIngreso )  throws Exception;
}
