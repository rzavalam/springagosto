package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;

public interface ValModalidadService {
	
	boolean correspondeModalidadAnticipada(Date fechaNumeracion, Date fechaLlegada);
	boolean correspondeModalidadDiferida(Date fechaNumeracion, Date fechaDescarga);
	boolean correspondeModalidadUrgente(Date fechaNumeracion, Date fechaLlegada, Date fechaDescarga);
	

}
