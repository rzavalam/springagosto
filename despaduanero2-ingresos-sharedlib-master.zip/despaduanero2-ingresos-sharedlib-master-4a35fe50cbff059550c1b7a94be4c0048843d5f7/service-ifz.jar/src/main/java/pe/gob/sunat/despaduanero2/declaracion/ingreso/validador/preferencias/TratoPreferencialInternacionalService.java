package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface TratoPreferencialInternacionalService {

	/**
	 * validacion de tlcs
	 * @param serie
	 * @param variablesIngreso
	 */
	public  Map<String, String> validarTratoPreferenciaInternacional(DatoSerie serie, Map<String, Object> variablesIngreso);
	
	/**
	 * validacion de tlcs
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @param solicitudRectificacion
	 */
	//public List<Map<String, String>> validarPlazoRectificacionTPI (Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);
	
	//pase105 - II
	//public List<Map<String, String>> validarPlazoRectificacionTPI (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD ) throws Exception;
	
	/**
	 * Identifica si un determinado servicio deber� ser ejecutado como parte de la validaci�n de los TLC
	 * @param o
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public boolean validarServicioTLC (Object o, DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	
	/**
	 * Permite obtener el valor del atributo dentro del modelo de catalogos el cual se encuentra asociado a un determinado TLC
	 * @param codAtributo
	 * @param codGrupo
	 * @param codTipoCat
	 * @param codElemento
	 * @return
	 */
	//rtineo optimizacion
	public String obtenerAtributo(String codAtributo, String codGrupo, String codTipoCat, String codElemento, Map<String, Object> variablesIngreso);
	
	public String obtenerAtributo(String codAtributo, String codGrupo, String codTipoCat, String codElemento);
	//fin optimziacion
	/**
	 * Identifica si un determinado servicio deber� ser ejecutado como parte de la validaci�n de los TLC, invocado por dato general de la declaracion
	 * @param o
	 * @param serie
	 * @param fechaReferencia
	 * @return
	 */
	public boolean validarServicioTLC (Object o, DatoSerie serie, Date fechaReferencia, List<String> serviciosTLC);
	

	/**Pase 548 II
	 * Permite determinar si previamente a la rectificaci�n se declar� TPI (no es primera vez)
	 * @param serie
	 * @param declaracionBD
	 * @return
	 */
	public boolean esRectificacionTPI (DatoSerie serie, Declaracion declaracionBD ) ;
	
	/**Pase 548 II
	 * Permite determinar si es una recti con el mismo TPI
	 * @param serie
	 * @param declaracionBD
	 * @return
	 */
	public boolean esMismoTPI (DatoSerie serie, Declaracion declaracionBD ) ;
	
	//TLC Corea pas2016-66
	public Date obtenerFechaReferenciaCOEnEvaluacion(DatoAutocertificacion certiOrigen,Map<String, Object> variablesIngreso);
	//fin TLC Corea

}
