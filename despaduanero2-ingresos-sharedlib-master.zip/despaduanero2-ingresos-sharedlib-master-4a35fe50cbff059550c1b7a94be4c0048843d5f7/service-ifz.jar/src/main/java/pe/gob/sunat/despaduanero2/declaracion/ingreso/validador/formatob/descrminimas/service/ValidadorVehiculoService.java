package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValidadorVehiculoService {

	/**
	 * Realiza todas las validaciones necesarias para veh�culos antiguos.
	 * @param item
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> validarAntiguedadVehiculo(DatoItem item, Declaracion declaracion);
	
	/**
	 * Valida y retorna true si se exceptua de los requisitos m�nimos de calidad respecto a la antiguedad, kilometraje o siniestro 
	 * @param item
	 * @param declaracion
	 * @param indicadorSNTT
	 * @param lstDatoSerie
	 * @return
	 */
	public boolean esExceptuadoReqMinimosCalidad( DatoItem item, Declaracion declaracion, String indicadorSNTT, List<Map<String, Object>> lstDatoSerie, String numeroVIN, String carroceria, Map<String, Object> mapDatosVehiculo);//arey Pase 451 - 2015  PAS20175E220200059
	
	/**
	 * Valida si el vehiculo es siniestrado
	 * @param item
	 * @param declaracion
	 * @param lstDatoSerie
	 * @return
	 */
	public List<ErrorDescrMinima> validarVehiculoSiniestrado(DatoItem item,Declaracion declaracion,Map<String, Object> mapDatosVehiculo,List<Map<String, Object>> lstDatoSerie);
	

	/**
	 * Valida los KM respecto a los Tipos de Uso. 
	 * @param item
	 * @param declaracion
	 * @param mapDatosVehiculo
	 * @param tipo
	 * @param lstDatoSerie
	 * @return
	 */
	public List<ErrorDescrMinima> validarKmVehiculo(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, int tipo);
		
		
	/**
	 * Valida la Antig�edad de Veh�culos por fechas:
	 * Antig�edad <=18/12/2008
	 * 19/12/2008 <= Antig�edad <= 31/12/2008
	 * Antig�edad >= 01/01/2009
	 * @param item
	 * @param declaracion
	 * @param mapDatosVehiculo
	 * @return
	 */
	public List<ErrorDescrMinima> validarAntiguedadPorFechas(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie);
	 
	/**
	 * Valida la prohibici�n de Importaci�n para Consumo.
	 * @param item
	 * @param declaracion
	 * @param mapDatosVehiculo
	 * @param lstDatoSerie
	 * @return
	 */
	public List<ErrorDescrMinima> validarProhibicionImpoConsumo(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie);
	 
	/**
	 * Valida las restricciones para el ingreso de veh�culos liberados por Diplom�ticos y Funcionarios Extranjeros.
	 * @param vehiculo
	 * @param item
	 * @param declaracion
	 * @param lstDatoSerie
	 * @return
	 */
	public List<ErrorDescrMinima> validarRestriccionFuncExtranjeros(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie);
	
}
