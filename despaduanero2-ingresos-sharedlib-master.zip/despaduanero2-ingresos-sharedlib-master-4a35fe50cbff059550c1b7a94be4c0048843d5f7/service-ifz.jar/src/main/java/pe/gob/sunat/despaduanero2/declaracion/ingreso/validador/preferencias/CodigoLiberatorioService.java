package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;

public interface CodigoLiberatorioService {

	/**
	 * Validar si corresponde el acogimiento al c�digo liberatorio de acuerdo a La Ley N� 29482 - Ley de Promoci�n para el desarrollo de Actividades Productivas en Zonas Alto Andinas.
	 * @param dua
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valZonasAltoAndinas(DUA dua, Date fechaReferencia);
	
	//Ini p46
	public boolean serieTieneCodLiberatorioDonacion (Integer codLiberatorio);
	public boolean   serieTieneCodLiberatorioDonacion20012002 (Integer codLiberatorio, Integer numSerieDUA);
	public List<Map<String, String>> duaTieneCodigoLiberatorio (DUA dua);
	public List<Map<String, String>> validarCodigoLiberatorioporSerieDonacion(DUA dua);
	//Fin p46
	
}
