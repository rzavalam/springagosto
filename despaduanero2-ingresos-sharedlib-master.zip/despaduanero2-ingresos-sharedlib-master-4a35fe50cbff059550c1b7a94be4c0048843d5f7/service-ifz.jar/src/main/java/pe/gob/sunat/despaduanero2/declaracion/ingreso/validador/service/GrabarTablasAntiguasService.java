package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarTablasAntiguasService {

	void grabarTablasAntiguas(Declaracion declaracion, Map<String,Object> variablesIngreso);
	
}
