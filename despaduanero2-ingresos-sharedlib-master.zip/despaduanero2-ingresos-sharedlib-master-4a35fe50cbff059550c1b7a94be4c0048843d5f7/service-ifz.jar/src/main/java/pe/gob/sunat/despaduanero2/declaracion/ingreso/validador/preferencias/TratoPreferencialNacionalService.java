package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface TratoPreferencialNacionalService {
	
	/**
	 * Realiza las validaciones sobre el TPN 93.<br> 
	 * @param declaracion Declaracion
	 * @return Lista de errorres
	 */
	public List<Map<String,String>> validarTratoPreferencialNacional93(DatoSerie datoSerie);

}
