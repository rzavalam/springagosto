package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCertificadoOrigen;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtraAduana;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.serialization.SerializacionUtil;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class GetDeclaracionHashMapToDeclaracionObjectHelper {

	private static GetDeclaracionHashMapToDeclaracionObjectHelper instance;
	
	private GetDeclaracionHashMapToDeclaracionObjectHelper(){
		// do nothing
	}
	
	public static GetDeclaracionHashMapToDeclaracionObjectHelper getInstance()
	{
		if(instance == null)
			instance = new GetDeclaracionHashMapToDeclaracionObjectHelper();
		return instance;
	}
	
	
	public Participante buildParticipante(Map mapParticipante)
	{
		Participante participante = new Participante() ;
		
		if(mapParticipante.containsKey("NUM_DOCIDENT"))
			participante.setNumeroDocumentoIdentidad	( (java.lang.String)  mapParticipante.get("NUM_DOCIDENT")  );
		
		if(mapParticipante.containsKey("COD_TIPPARTIC"))
			participante.getTipoParticipante().setCodDatacat	( (java.lang.String)  mapParticipante.get("COD_TIPPARTIC")  );
		
		if(mapParticipante.containsKey("COD_TIPDOC"))
			participante.getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  mapParticipante.get("COD_TIPDOC")  );
		
		if(mapParticipante.containsKey("COD_PAISORIGEN"))
			participante.getPais().setCodDatacat	( (java.lang.String)  mapParticipante.get("COD_PAISORIGEN")  );
		
		if(mapParticipante.containsKey("NOM_RAZONSOCIAL"))
			participante.setNombreRazonSocial	( (java.lang.String)  mapParticipante.get("NOM_RAZONSOCIAL")  );
		
		if(mapParticipante.containsKey("DES_UBIGEOCIUDAD"))
			participante.setCiudad	( (java.lang.String)  mapParticipante.get("DES_UBIGEOCIUDAD")  );
		
		if(mapParticipante.containsKey("DIR_PARTIC"))
			participante.setDireccion	( (java.lang.String)  mapParticipante.get("DIR_PARTIC")  );
		
		if(mapParticipante.containsKey("NUM_TELEFONO"))
			participante.setTelefono	( (java.lang.String)  mapParticipante.get("NUM_TELEFONO")  );
		
		if(mapParticipante.containsKey("NUM_FAX"))
			participante.setFax	( (java.lang.String)  mapParticipante.get("NUM_FAX")  );
		
		if(mapParticipante.containsKey("NOM_EMAIL"))
			participante.setEmail	( (java.lang.String)  mapParticipante.get("NOM_EMAIL")  );
		if(mapParticipante.containsKey("NOM_PAGINAWEB"))
			participante.setPaginaWeb	( (java.lang.String)  mapParticipante.get("NOM_PAGINAWEB")  );
		
		return participante;
	}
	
	@SuppressWarnings("unchecked")
	public Declaracion transform(Map<?,?> mapinput){
		
		Map mapCabDeclara = (Map)mapinput.get("mapCabDeclara");		
		List<Map> lstDetDeclara = (List<Map>)mapinput.get("lstDetDeclara");
		List<Map> lstDocuPreceDua = (List<Map>)mapinput.get("lstDocuPreceDua");
		List<Map> lstFacturasSerie = (List<Map>)mapinput.get("lstFacturasSerie");
		
		List<Map> lstFormBProveedor = (List<Map> )mapCabDeclara.get("lstFormBProveedor");
		
		Declaracion declaracion = new Declaracion();
		
		declaracion.setCodaduana	( (java.lang.String)  mapCabDeclara.get("COD_ADUANA")  );
		
		{
			declaracion.setNumdeclRef( new NumdeclRef() );
			declaracion.getNumdeclRef().setCodregimen	( (java.lang.String)  mapCabDeclara.get("COD_REGIMEN")  );
			declaracion.getNumdeclRef().setNumcorre	( (java.lang.String)  mapCabDeclara.get("NUM_CORREDOC").toString()  );
			declaracion.getNumdeclRef().setCodaduana	( (java.lang.String)  mapCabDeclara.get("COD_ADUANA")  );
			declaracion.getNumdeclRef().setAnnprese	( (java.lang.String)  mapCabDeclara.get("ANN_PRESEN").toString()  );			
		}
		
		declaracion.setDua( new DUA() );
		declaracion.getDua().setCodtipoperacion	( (java.lang.String)  mapCabDeclara.get("COD_TIPDESP")  );
		declaracion.getDua().setCodmodalidad	( (java.lang.String)  mapCabDeclara.get("COD_MODALIDAD")  );
		declaracion.getDua().setNumplazosol	( SunatNumberUtils.toInteger( mapCabDeclara.get("NUM_PLAZOSOL")  ) );
		declaracion.getDua().setCodtipoplazo	( (java.lang.String)  mapCabDeclara.get("COD_TIPOPLAZO")  );
		declaracion.getDua().setMtotfobclvta	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTFOBDOL")  );
		declaracion.getDua().setMtotflecomex	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTFLETEDOL")  );
		declaracion.getDua().setMtotsegotros	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTSEGDOL")  );
		declaracion.getDua().setMtotajustes	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTAJUSTESDOL")  );
		declaracion.getDua().setMtovaladuana	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTVALORADU")  );
		declaracion.getDua().setCodtipotratamiento	( (java.lang.String)  mapCabDeclara.get("COD_TIPTRATMERC")  );
		declaracion.getDua().setCodpropiedad	( (java.lang.String)  mapCabDeclara.get("COD_PROPIEDAD")  );
		declaracion.getDua().setCnttpesoneto	( ( java.math.BigDecimal )  mapCabDeclara.get("CNT_PESONETO_TOTAL")  );
		declaracion.getDua().setCnttpesobruto	( ( java.math.BigDecimal )  mapCabDeclara.get("CNT_PESOBRUTO_TOTAL")  );
		declaracion.getDua().setCnttcantbulto	( ( java.math.BigDecimal )  mapCabDeclara.get("CNT_TOTBULTOS")  );
		declaracion.getDua().setCnttqunifis	( ( java.math.BigDecimal )  mapCabDeclara.get("CNT_TQUNIFIS")  );
		declaracion.getDua().setCnttqunicom	( ( java.math.BigDecimal )  mapCabDeclara.get("CNT_TQUNICOM")  );
		declaracion.getDua().setCntnumseries	( SunatNumberUtils.toInteger( mapCabDeclara.get("CNT_TOTSERIES")   ));
		declaracion.getDua().setMtototautoliq	( ( java.math.BigDecimal )  mapCabDeclara.get("MTO_TOTAUTOLIQ")  );
		declaracion.getDua().setCodferia	( (java.lang.String)  mapCabDeclara.get("")  ); //CAB_ADI_ADMTEM
		declaracion.getDua().setCodtipempaque	( (java.lang.String)  mapCabDeclara.get("COD_TIPEMPAQUE")  );
		declaracion.getDua().setCodprodurgente	( (java.lang.String)  mapCabDeclara.get("COD_PRODURGENTE")  );
		declaracion.getDua().setFecfinprovsional	( (java.util.Date)  mapCabDeclara.get("FEC_FINPROVSIONAL")  );
		declaracion.getDua().setCodlugarecepcion	( (java.lang.String)  mapCabDeclara.get("COD_TIPLUGARRECEP")  );
		declaracion.getDua().setNumruclugarecep	( (java.lang.String)  mapCabDeclara.get("COD_RUCLUGRECEP")  );
		declaracion.getDua().setCodanexo	( (java.lang.String)  mapCabDeclara.get("COD_LOCALANEXO")  );
		declaracion.getDua().setNumrucdeposito	( (java.lang.String)  mapCabDeclara.get("COD_RUCLUGRECEP")  );
		declaracion.getDua().setCodlocalanexo	( (java.lang.String)  mapCabDeclara.get("COD_LOCALANEXO")  );
		declaracion.getDua().setDesfinalidad	( (java.lang.String)  mapCabDeclara.get("DES_FINALIDAD")  );
		declaracion.getDua().setIndSocorro	( (java.lang.String)  mapCabDeclara.get("IND_SOCORRO")  );
		declaracion.getDua().setCodregimen	( (java.lang.String)  mapCabDeclara.get("COD_REGIMEN")  );
		declaracion.getDua().setCodaduanaorden	( (java.lang.String)  mapCabDeclara.get("COD_ADUANA")  );
		declaracion.getDua().setNumdocumento	( SunatStringUtils.toStringObj( mapCabDeclara.get("NUM_DECLARACION")  ) );
		//declaracion.getDua().setCodtipooper	( (java.lang.String)  mapCabDeclara.get("")  ); 
		declaracion.getDua().setFecfinacoregimen( (java.util.Date)  mapCabDeclara.get("FEC_VENREGIMEN")  );
		
		//Crea declarante
		declaracion.getDua().setDeclarante( new Participante() );
		declaracion.getDua().getDeclarante().setNumeroDocumentoIdentidad	( (java.lang.String)  mapinput.get("NUM_DOCIDENT_PIM")  );
		declaracion.getDua().getDeclarante().getTipoParticipante().setCodDatacat	( (java.lang.String)  mapinput.get("COD_TIPPARTIC_PIM")  );
		declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  mapinput.get("COD_TIPDOC_PIM")  );			
		
		// Crea OtraAduana
		declaracion.getDua().setOtraAduana( new DatoOtraAduana() );
		declaracion.getDua().getOtraAduana().setCodopadusal	( (java.lang.String)  mapCabDeclara.get("COD_ADUDEST")  );
//		declaracion.getDua().getOtraAduana().setCodopadutra	( (java.lang.String)  hm.get("")  );
//		declaracion.getDua().getOtraAduana().setCodopaduing	( (java.lang.String)  hm.get("")  );
		declaracion.getDua().getOtraAduana().setCodviatrades	( (java.lang.String)  mapCabDeclara.get("COD_VIATRANS")  );			

				
		if(! CollectionUtils.isEmpty(lstDetDeclara) )
		{
			Elementos<DatoSerie> listSeries = new Elementos<DatoSerie>();
			declaracion.getDua().setListSeries(listSeries);
			
			for (Map detDeclara : lstDetDeclara)
			{
				DatoSerie serie = new DatoSerie();		
				serie.setNumserie	( SunatNumberUtils.toInteger( detDeclara.get("NUM_SECSERIE")  ) );
				serie.setCodunicomer	( (java.lang.String)  detDeclara.get("COD_UNICOMER")  );
				serie.setCntunicomer	( ( java.math.BigDecimal )  detDeclara.get("CNT_COMER")  );
				serie.setCntbultos	( ( java.math.BigDecimal )  detDeclara.get("CNT_BULTO")  );
				serie.setCodclasbul	( (java.lang.String)  detDeclara.get("COD_CLASEBULTOS")  );
				serie.setCntpesoneto	( ( java.math.BigDecimal )  detDeclara.get("CNT_PESO_NETO")  );
				serie.setCntpesobruto	( ( java.math.BigDecimal )  detDeclara.get("CNT_PESO_BRUTO")  );
				serie.setCntunifis	( ( java.math.BigDecimal )  detDeclara.get("CNT_UNIFIS")  );
				serie.setCodunifis	(  SunatStringUtils.toStringObj( detDeclara.get("CNT_UNIFIS")  ) );
				serie.setNumpartnandi ( SunatNumberUtils.toLong( detDeclara.get("NUM_PARTNANDI")  ) );	
				serie.setCodtnan	( (java.lang.String)  detDeclara.get("COD_TIPTASAAPLICAR")  );
				serie.setNumpartnalad	( (java.lang.String)  detDeclara.get("NUM_PARNALADISA")  );
				serie.setCodtipomarge	( (java.lang.String)  detDeclara.get("COD_TIPMARGEN")  );
				serie.setCodpaisorige	( (java.lang.String)  detDeclara.get("COD_PAISORIGEN")  );
				serie.setCodpaisadqui	( (java.lang.String)  detDeclara.get("COD_PAISADQUI")  );
				serie.setMtofobmon	( ( java.math.BigDecimal )  detDeclara.get("MTO_FOBMONTRANS")  );
				serie.setCodmoneda	( (java.lang.String)  detDeclara.get("COD_MONETRANS")  );
				serie.setMtofledol	( ( java.math.BigDecimal )  detDeclara.get("MTO_FLETEDOL")  );
				serie.setMtosegdol	( ( java.math.BigDecimal )  detDeclara.get("MTO_SEGDOL")  );
				serie.setMtoajuste	( ( java.math.BigDecimal )  detDeclara.get("MTO_AJUSTE")  );
				serie.setMtovaladuana	( ( java.math.BigDecimal )  detDeclara.get("MTO_VALORADU")  );
				serie.setDescomercial	( (java.lang.String)  detDeclara.get("DES_COMER")  );
				serie.setDesformapres	( (java.lang.String)  detDeclara.get("DES_FORMAPRESEN")  );
				serie.setDesmatecomp	( (java.lang.String)  detDeclara.get("DES_MATECOMP")  );
				serie.setDesusoaplica	( (java.lang.String)  detDeclara.get("DES_USOAPLIC")  );
				serie.setDesotros	( (java.lang.String)  detDeclara.get("DES_OTROSCARAC")  );
				serie.setNumpartcorre	( (java.lang.String)  detDeclara.get("NUM_PARCORRELACION")  );
				serie.setValpreciovta	( ( java.math.BigDecimal )  detDeclara.get("MTO_PVPMONNAC")  );
				serie.setNumpartnaban	( (java.lang.String)  detDeclara.get("NUM_PARNABANDINA")  );
				serie.setCodtipoflete	( (java.lang.String)  detDeclara.get("COD_TIPFLETE")  );
				serie.setValestimado	( ( java.math.BigDecimal )  detDeclara.get("MTO_ESTIMADO")  );
				serie.setFecexpiracion	( (java.util.Date)  detDeclara.get("FEC_EXPIRACION")  );
		

				Elementos<DatoDocTransporte> listDocTransporte = new  Elementos<DatoDocTransporte>();
				declaracion.getDua().setListDocTransporte(listDocTransporte);
				
				DatoDocTransporte docTransporte = new DatoDocTransporte();		
				docTransporte.setCodpuerto	( (java.lang.String)  detDeclara.get("COD_PUER_EMBAR")  );
				docTransporte.setFecembarque	( (java.util.Date)  detDeclara.get("FEC_EMBORIGEN")  );
				docTransporte.setCodtipodoctrans	( (java.lang.String)  detDeclara.get("COD_TIPDOCTRANSP")  );
				docTransporte.setNumdocmaster	( (java.lang.String)  detDeclara.get("NUM_DOCTRANSPMASTER")  );
				docTransporte.setFecembarqueorg	( (java.util.Date)  detDeclara.get("FEC_EMBORIGEN")  );
				docTransporte.setNumdoctransporte	( (java.lang.String)  detDeclara.get("NUM_DOCTRANSP")  );
				docTransporte.setCodpuertoorg( (java.lang.String) detDeclara.get("COD_PTOEMBORIGEN"));//adicionado por pase 192
				//docTransporte.setNumsecdoctrans	( SunatNumberUtils.toInteger( detDeclara.get("")  );
				//docTransporte.setNumdetalle	( SunatNumberUtils.toInteger( detDeclara.get("")  );
				listDocTransporte.add(docTransporte);

				serie.setMercancia( new DatoMercancia() );
				serie.getMercancia().setCodproducto	( (java.lang.String)  detDeclara.get("COD_PRODRESTR")  );
				serie.getMercancia().setCodtipoexoneracion	( (java.lang.String)  detDeclara.get("COD_TIPEXONRESTRI")  );
				serie.getMercancia().setCodexoneracion	( (java.lang.String)  detDeclara.get("COD_EXMERCREST")  );
				serie.getMercancia().setCodriesgosanitario	( (java.lang.String)  detDeclara.get("COD_RSSENASA")  );
				//serie.getMercancia().setIndcustodia	( (java.lang.String)  hm.get("")  );				
				  
				serie.setProducto( new DatoProducto() );
				serie.getProducto().setCodexpantidum	( (java.lang.String)  detDeclara.get("COD_EXPOAPLICANTID")  );
				serie.getProducto().setCodpantidum	( (java.lang.String)  detDeclara.get("COD_PRODANTID")  );
				serie.getProducto().setMtofobfactu	( ( java.math.BigDecimal )  detDeclara.get("MTO_FOBFACT")  );
				//del temporal
				//TODO serie.getProducto().setCodtipoequi	( (java.lang.String)  detDeclara.get("COD_UMEQUI")  );
				//TODO serie.getProducto().setCntunimedidaequi	( ( java.math.BigDecimal )  detDeclara.get("CNT_UNIEQUI")  ); //DETADIATPA
				//TODO serie.getProducto().setNumitem	( (java.lang.String)  detDeclara.get("COD_INSUMO")  );
				serie.getProducto().setPormerma	( ( java.math.BigDecimal )  detDeclara.get("POR_MERMA")  );				

				//TODO Validar esto
				/*
				Elementos<DatoSerieDocSoporte> listSerieDocSoporte = new Elementos<DatoSerieDocSoporte>();
				serie.setListSerieDocSoporte(listSerieDocSoporte);
				
				{
					DatoSerieDocSoporte serieDocSoporte = new DatoSerieDocSoporte();		
					//serieDocSoporte.setCodtipodocsoporte	( (java.lang.String)  hm.get("")  );
					//serieDocSoporte.setNumiddocsoporte	( SunatNumberUtils.toInteger( hm.get("")  );				
				}
			  	*/
				
				//serie.setNumserie	( SunatNumberUtils.toInteger( hm.get("")  );
				serie.setCodaplultra	( (java.lang.String)  detDeclara.get("COD_ULTRACTIVIDAD")  );
				//TODO Vienen de convenioSerie
				/*
				serie.setCodconvinter	( SunatNumberUtils.toInteger( detDeclara.get("")  );
				serie.setCodtratprefe	( SunatNumberUtils.toInteger( detDeclara.get("")  );
				serie.setCodliberatorio	( SunatNumberUtils.toInteger( detDeclara.get("")  );
				*/
				
				serie.setMtofobdol	( ( java.math.BigDecimal )  detDeclara.get("MTO_FOBDOL")  );
				serie.setCodtiposeg	( (java.lang.String)  detDeclara.get("COD_TIPSEG")  );
				serie.setCodestamerca	( (java.lang.String)  detDeclara.get("COD_ESTMERC")  );
				serie.setCodvalajuste	( (java.lang.String)  detDeclara.get("COD_VALORAJUSTE")  );
				//serie.setValindcodlib	( (java.lang.String)  detDeclara.get("IND_ACOGCODLIBER")  );
				//serie.setDeszonafranca	( (java.lang.String)  detDeclara.get("DES_ZONAFRANCA")  );
				serie.setCntunicomisc	( ( java.math.BigDecimal )  detDeclara.get("CNT_UNIISC")  );
				serie.setCodunicomisc	( (java.lang.String)  detDeclara.get("COD_UNI_ISC")  );
				serie.setCntpesovehic	( ( java.math.BigDecimal )  detDeclara.get("CNT_PESOVEHIC")  );
				//serie.setMtofobnet	( ( java.math.BigDecimal )  detDeclara.get("MTO_FOBPNETO")  ); //DETADIIMPOCONSU
				
				
				if(! CollectionUtils.isEmpty(lstDocuPreceDua) )
				{
					Elementos<DatoRegPrecedencia> listRegPrecedencia = new Elementos<DatoRegPrecedencia>();
					serie.setListRegPrecedencia(listRegPrecedencia);

					for (Map docuPreceDua : lstDocuPreceDua) {
						{
							DatoRegPrecedencia regPrecedencia = new DatoRegPrecedencia();
							regPrecedencia.setCodregipre	( (java.lang.String)  docuPreceDua.get("COD_REGIMENPRE")  );
							regPrecedencia.setCodaduapre	( (java.lang.String)  docuPreceDua.get("COD_ADUANPRE")  );
							regPrecedencia.setAnndeclpre	( SunatStringUtils.toStringObj( docuPreceDua.get("ANN_PRESENPRE")  ) );
							regPrecedencia.setNumdeclpre	( SunatStringUtils.toStringObj( docuPreceDua.get("NUM_DECLARACIONPRE") ) );
							regPrecedencia.setFecvencpre	( (java.util.Date)  docuPreceDua.get("FEC_VENCREGPRE")  );
							regPrecedencia.setNumserpre	( SunatNumberUtils.toInteger( docuPreceDua.get("NUM_SECSERIEPRE")  ) );
							listRegPrecedencia.add(regPrecedencia);
						}						
					}
				}
				
				//TODO serie.setListVehiculos(listVehiculos);
				/*
				Elementos<DatoVehiculo> listVehiculos = new Elementos<DatoVehiculo>();
				serie.setListVehiculos(listVehiculos);
				{
					DatoVehiculo vehiculo = new DatoVehiculo();
					vehiculo.setNumitemb	( (java.lang.String)  hm.get("NUM_SECSERIE")  );
					vehiculo.setNomlibro	( (java.lang.String)  hm.get("NOM_PUBLI")  );
					vehiculo.setCodejempl	( (java.lang.String)  hm.get("NUM_EJEMPLARPUB")  );
					vehiculo.setAnnmespubli	( (java.lang.String)  hm.get("PER_PUBLI")  );
					vehiculo.setNumpagin(	 SunatNumberUtils.toInteger( hm.get("NUM_PAGINA")  );
					vehiculo.setNumfactconve	( ( java.math.BigDecimal )  hm.get("COD_FACTORCONV")  );
					listVehiculos.add(vehiculo);
					
					Elementos<DatoMontoGasto> listMontoGastos = new Elementos<DatoMontoGasto>();
					vehiculo.setListMontoGastos(listMontoGastos);
					{
						DatoMontoGasto montoGasto = new DatoMontoGasto();
						montoGasto.setTipmonto( (java.lang.String)  hm.get("COD_CPTOGASTOS")  );
						montoGasto.setValmonto	( ( java.math.BigDecimal )  hm.get("MTO_GASTO")  );
						listMontoGastos.add(montoGasto);					
					}				
				}
				
				*/
			}			
		}
				
		

		
		if(!CollectionUtils.isEmpty(lstFacturasSerie))
		{
			Elementos<DatoFacturaref> listFacturaRef = new Elementos<DatoFacturaref>();
			declaracion.getDua().setListFacturaRef(listFacturaRef);
			
			for (Map mapFacturasSerie : lstFacturasSerie) {
				DatoFacturaref facturaRef = new DatoFacturaref();
				facturaRef.setNumfactura	( (java.lang.String)  mapFacturasSerie.get("NUM_FACT")  );
				facturaRef.setFecfactura	( (java.util.Date)  mapFacturasSerie.get("FEC_FACT")  );
				facturaRef.setNumsecfactu	( SunatNumberUtils.toInteger( mapFacturasSerie.get("NUM_SECFACT")  ) );
				//facturaRef.setCodtipofact	( (java.lang.String)  mapFacturasSerie.get("")  );
				listFacturaRef.add(facturaRef);
			}
		}
		
		//TODO declaracion.getDua().setListIndicadores(listIndicadores);
		/*
		Elementos<DatoIndicadores> listIndicadores = new Elementos<DatoIndicadores>();
		declaracion.getDua().setListIndicadores(listIndicadores);
		{
			DatoIndicadores indicador = new DatoIndicadores();		
			//indicador.setValindicador	( (java.lang.String)  hm.get("")  );
			indicador.setCodtipoindica	( (java.lang.String)  hm.get("COD_INDICADOR")  );
			listIndicadores.add(indicador);
		}
		*/
		
		//TODO declaracion.getDua().setListObservaciones(listObservaciones);
		/*
		Elementos<Observacion> listObservaciones = new Elementos<Observacion>();
		declaracion.getDua().setListObservaciones(listObservaciones);
		{
			Observacion observacion = new Observacion();
			observacion.setNumsecuencia	( (java.lang.String)  hm.get("NUM_SECOBS")  );
			observacion.setCodtipobserva	( (java.lang.String)  hm.get("COD_TIPOBS")  );
			observacion.setObsdeclaracion	( (java.lang.String)  hm.get("OBS_OBS")  );
			listObservaciones.add( observacion );
		}
		*/
		
			declaracion.getDua().setManifiesto(new DatoManifiesto());
			declaracion.getDua().getManifiesto().setCodaduamanif	( (java.lang.String)  mapCabDeclara.get("COD_ADUAMANIFIESTO")  );
			declaracion.getDua().getManifiesto().setAnnmanif	( SunatStringUtils.toStringObj(  mapCabDeclara.get("ANN_MANIFIESTO") ) );
			declaracion.getDua().getManifiesto().setNummanif	( (java.lang.String)  mapCabDeclara.get("NUM_MANIFIESTO")  );
			declaracion.getDua().getManifiesto().setCodmodtransp	( (java.lang.String)  mapCabDeclara.get("COD_VIATRANS")  );
			declaracion.getDua().getManifiesto().setFectermino	( (java.util.Date)  mapCabDeclara.get("FEC_TERM")  );
			declaracion.getDua().getManifiesto().setCodtipomanif	( (java.lang.String)  mapCabDeclara.get("COD_TIPMANIFIESTO")  );
			//TODO validar declaracion.getDua().getManifiesto().setNumviaje	( (java.lang.String)  mapCabDeclara.get("NUM_VIAJE")  );
			
			
			declaracion.getDua().getManifiesto().setEmpTransporte( new Participante() );
			declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad	( (java.lang.String)  mapCabDeclara.get("NUM_DOCIDENT_PTR")  );
			declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  mapCabDeclara.get("COD_TIPDOC_PTR")  );
		
		
		//TODO declaracion.getDua().getManifiesto().listEquipamientos[]
		/*
		Elementos<DatoEquipamiento> listEquipamientos = new Elementos<DatoEquipamiento>();
		declaracion.getDua().getManifiesto().setListEquipamientos(listEquipamientos);
		{
			DatoEquipamiento equipamiento = new DatoEquipamiento();
			equipamiento.setNumequipo	( (java.lang.String)  hm.get("NUM_EQUIPAMIENTO")  );
			equipamiento.setCodtamequip	( (java.lang.String)  hm.get("COD_TAM_EQUIPAMIEN")  );
			equipamiento.setCodcondequip	( (java.lang.String)  hm.get("COD_LLENADO")  );
			listEquipamientos.add(equipamiento);

			//equipamiento.listPrecintos[]
			Elementos<DatoPrecinto> listPrecintos = new Elementos<DatoPrecinto>();
			equipamiento.setListPrecintos(listPrecintos);
			{
				DatoPrecinto precinto = new DatoPrecinto();		
				precinto.setNumprecinto	( (java.lang.String)  hm.get("NUM_PRECINTO")  );
				listPrecintos.add(precinto);
			}
		}
		*/

		//TODO declaracion.getDua().setListTributosAutocalculados()
		/*
		Elementos<DatoTributosAutocalc> listTributosAutocalculados = new  Elementos<DatoTributosAutocalc>();
		DatoTributosAutocalc tributoAutocalculado = new DatoTributosAutocalc(); 
		{
//			tributoAutocalculado.setCodtributo	( (java.lang.String)  hm.get("")  );
//			tributoAutocalculado.setCodmoneda	( (java.lang.String)  hm.get("")  );
//			tributoAutocalculado.setMtovalortrib	( ( java.math.BigDecimal )  hm.get("")  );			
		}
		*/
		declaracion.getDua().setPago( new DatoPago() );
		declaracion.getDua().getPago().setPagoDeclaracion( new DatoPagoDecla() );
		declaracion.getDua().getPago().getPagoDeclaracion().setCodbcopagoelec	( SunatStringUtils.toStringObj( mapCabDeclara.get("COD_BCOPAGOELEC") ) );
		declaracion.getDua().getPago().getPagoDeclaracion().setNumctapagoelec	( (java.lang.String)  mapCabDeclara.get("NUM_CUENTAPAGOE")  );
		declaracion.getDua().getPago().getPagoDeclaracion().setCodgarantia	( (java.lang.String)  mapCabDeclara.get("NUM_CTACTE")  );
		//declaracion.getDua().getPago().getPagoDeclaracion().setCodtipopago	( (java.lang.String)  mapCabDeclara("")  );
		
		declaracion.getDua().getPago().setPagoTransaccion( new DatoPagoTrans() );
		declaracion.getDua().getPago().getPagoTransaccion().setCodentipago	( (java.lang.String)  mapCabDeclara.get("COD_ENTIPAGO")  );
		declaracion.getDua().getPago().getPagoTransaccion().setCodmodpago	( (java.lang.String)  mapCabDeclara.get("COD_MODPAGO")  );
		declaracion.getDua().getPago().getPagoTransaccion().setNumplazcredito	( SunatNumberUtils.toInteger( mapCabDeclara.get("CNT_PLZCREDITO")  ) );
		declaracion.getDua().getPago().getPagoTransaccion().setFeccarcr	( (java.util.Date)  mapCabDeclara.get("FEC_CARCR")  );
		
		//TODO revisar
		/*
		declaracion.getDua().getRucAnexoUbicacion().setNumeroDocumentoIdentidad	( (java.lang.String)  hm.get("NUM_DOCIDENT")  );
		declaracion.getDua().getRucAnexoUbicacion().getTipoParticipante().setCodDatacat	( (java.lang.String)  hm.get("COD_TIPPARTIC")  );
		declaracion.getDua().getRucAnexoUbicacion().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  hm.get("COD_TIPDOC")  );
		*/
		
		//declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion()		
		List<Map> lstCabCertiOrigen = null;
		
		if( mapCabDeclara.containsKey("lstCabCertiOrigen") )
			lstCabCertiOrigen = (List<Map>)mapCabDeclara.get("lstCabCertiOrigen");
				
		if(! CollectionUtils.isEmpty( lstCabCertiOrigen ))
		{
			Elementos<DatoAutocertificacion> listAutocertificacion= new Elementos<DatoAutocertificacion>();
			declaracion.getDua().setDatoCertificadoOrigen( new DatoCertificadoOrigen() );
			declaracion.getDua().getDatoCertificadoOrigen().setListAutocertificacion(listAutocertificacion);
			
			for (Map mapCabCertiOrigen : lstCabCertiOrigen) {
				DatoAutocertificacion autocertificacion = new  DatoAutocertificacion();	
			    autocertificacion.setNumdocumento	( (java.lang.String)  mapCabCertiOrigen.get("NUM_CERTIFICADO")  );
				autocertificacion.setFecemision	( (java.util.Date)  mapCabCertiOrigen.get("FEC_CERTIFICADO")  );
				autocertificacion.setCodffco	( (java.lang.String)  mapCabCertiOrigen.get("COD_FFCO")  );
				autocertificacion.setCodtipoCO	( (java.lang.String)  mapCabCertiOrigen.get("COD_TIPCERTIFICADO")  );
				autocertificacion.setCodtipoemisorCO	( (java.lang.String)  mapCabCertiOrigen.get("COD_EMISCERT")  );
				autocertificacion.setNomemisorCO	( (java.lang.String)  mapCabCertiOrigen.get("NOM_EMISCERTIF")  );
				autocertificacion.setFeciniembarque	( (java.util.Date)  mapCabCertiOrigen.get("FEC_INIPERIODOEMB")  );
				autocertificacion.setFecfinembarque	( (java.util.Date)  mapCabCertiOrigen.get("FEC_FINPEREMB")  );
				autocertificacion.setDesmercancia	( (java.lang.String)  mapCabCertiOrigen.get("NOM_PRODMERC")  );
				autocertificacion.setCodcriterioO	( (java.lang.String)  mapCabCertiOrigen.get("COD_CRITERIOORIGEN")  );
				autocertificacion.setIndtrans	( (java.lang.String)  mapCabCertiOrigen.get("IND_PROCETERCERPAIS")  );
				autocertificacion.setNumsecCO	( SunatNumberUtils.toInteger( mapCabCertiOrigen.get("NUM_SECDOC")  ) );
				listAutocertificacion.add(autocertificacion);
				
				
				List<Map> lstDocAutAsociado = null;
				if( mapCabDeclara.containsKey("lstDocAutAsociado") )
					lstDocAutAsociado = (List<Map>)mapCabDeclara.get("lstDocAutAsociado");
				
				if( !CollectionUtils.isEmpty( lstDocAutAsociado ))
				{
					Elementos<DatoOtroDocSoporte> listOtrosDocSoporte = new Elementos<DatoOtroDocSoporte>();
					declaracion.getDua().setListOtrosDocSoporte(listOtrosDocSoporte);
					for(Map mapDocAutAsociado : lstDocAutAsociado)
					{
						DatoOtroDocSoporte otroDocSoporte = new DatoOtroDocSoporte();
						otroDocSoporte.setCodtipoproceso	( (java.lang.String)  mapDocAutAsociado.get("COD_TIPOPER")  );
						otroDocSoporte.setCodtipodocasoc	( (java.lang.String)  mapDocAutAsociado.get("COD_TIPDOCASO")  );
						otroDocSoporte.setAnndocasoc	( (java.lang.String)  mapDocAutAsociado.get("ANN_DOC")  );
						otroDocSoporte.setNumdocasoc	( (java.lang.String)  mapDocAutAsociado.get("NUM_DOC")  );
						otroDocSoporte.setFecdocasoc	( (java.util.Date)  mapDocAutAsociado.get("FEC_EMIS")  );
						otroDocSoporte.setFecvencimiento	( (java.util.Date)  mapDocAutAsociado.get("FEC_VENC")  );
						otroDocSoporte.setDesentidad	( (java.lang.String)  mapDocAutAsociado.get("OBS_OBS")  );
						otroDocSoporte.setCodtipoentidad	( (java.lang.String)  mapDocAutAsociado.get("COD_ENTI")  );
						otroDocSoporte.setCodtipodocentidad	( (java.lang.String)  mapDocAutAsociado.get("COD_TIPDOC")  );
						otroDocSoporte.setCodentidademisora	( SunatNumberUtils.toLong( mapDocAutAsociado.get("COD_IDENT")  ) );
						otroDocSoporte.setNumsecdocum	( SunatNumberUtils.toInteger( mapDocAutAsociado.get("NUM_SECDOC")  ) );
						listOtrosDocSoporte.add(otroDocSoporte);			
					}
					
				}
			}
		}
		
		
		//TODO declaracion.getDua().listDocAutorizantes()
		/*
		Elementos<DatoDocAutorizante> listDocAutorizantes = new  Elementos<DatoDocAutorizante>();
		DatoDocAutorizante docAutorizante = new DatoDocAutorizante(); 
		docAutorizante.setNumsecdocum	( SunatNumberUtils.toInteger( hm.get("NUM_SECDOC")  );
		docAutorizante.setCodtipodocum	( (java.lang.String)  hm.get("COD_TIPDOCASO")  );
		docAutorizante.setNumdocum	( (java.lang.String)  hm.get("NUM_DOC")  );
		docAutorizante.setAnndocum	( (java.lang.String)  hm.get("ANN_DOC")  );
		docAutorizante.setCodentidad	( (java.lang.String)  hm.get("COD_ENTI")  );
		docAutorizante.setDesentidad	( (java.lang.String)  hm.get("OBS_OBS")  );
		docAutorizante.setFecemision	( (java.util.Date)  hm.get("FEC_EMIS")  );
		docAutorizante.setFecvencimiento	( (java.util.Date)  hm.get("FEC_VENC")  );
		*/
		if( !CollectionUtils.isEmpty(lstFormBProveedor) )
		{
			//declaracion.setListDAVs()
			Elementos<DAV> listDAVs = new Elementos<DAV>();
			declaracion.setListDAVs(listDAVs);

			for (Map formBProveedor : lstFormBProveedor) {

				DAV dav = new DAV();
				listDAVs.add(dav);
			    dav.setNumsecuprov	( SunatNumberUtils.toInteger( formBProveedor.get("NUM_SECPROVE")  ) );
				dav.setCodnivcomer	( (java.lang.String)  formBProveedor.get("COD_NIVELCOMER")  );
				dav.setCodproveedor	( (java.lang.String)  formBProveedor.get("COD_PROVE")  );
				dav.setCodcondprov	( (java.lang.String)  formBProveedor.get("COD_CONDPROVE")  );
				dav.setCodnatutrans	( (java.lang.String)  formBProveedor.get("COD_NATUTRANS")  );
				dav.setCodformenvio	( (java.lang.String)  formBProveedor.get("COD_FORMAENVIO")  );
				dav.setNumenvio	( SunatNumberUtils.toInteger( formBProveedor.get("NUM_ENVIO")  ) );
				dav.setIndexisinter	( (java.lang.String)  formBProveedor.get("IND_INTEMEDIARIO")  );
				dav.setCodtipinter	( (java.lang.String)  formBProveedor.get("COD_TIPINTERM")  );
				dav.setCntfacturas	( SunatNumberUtils.toInteger( formBProveedor.get("CNT_FACT")   ));
				dav.setNomcargdecla	( (java.lang.String)  formBProveedor.get("NOM_CARGO")  );
				
				/*INICIO SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/ 	
				Elementos<DocumentoSoporteFormatoB> listDocumentoSoporteFormatoB = new Elementos<DocumentoSoporteFormatoB>();
				DocumentoSoporteFormatoB documentoSoporteFormatoB = new DocumentoSoporteFormatoB();
				
				documentoSoporteFormatoB.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("COD_MEDIO_PAGO"), null));
				documentoSoporteFormatoB.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("COD_ENTI_FINANC"), null));
				documentoSoporteFormatoB.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("COD_IDENT_PAGO"), null));
				documentoSoporteFormatoB.setTipoDocumento("450");
				
				listDocumentoSoporteFormatoB.add(documentoSoporteFormatoB);
				dav.setListDocumentoSoporteFormatoB(listDocumentoSoporteFormatoB);
				
				dav.setCodMedioPago(ObjectUtils.toString(formBProveedor.get("COD_MEDIO_PAGO"), null));
				dav.setCodIdentPago(ObjectUtils.toString(formBProveedor.get("COD_IDENT_PAGO"), null));
				dav.setCodEntidadFinanciera(ObjectUtils.toString(formBProveedor.get("COD_ENTI_FINANC"), null));
				/*FIN SWF-[PAS20191U220500050]:P_SNAA0058-02 PFA Admisi�n temporal-Hajalcri�a*/  	
				
			    //dav.setListMontos()
				
				Map mapFormBMonto = (Map)formBProveedor.get("mapFormBMonto");
				if(!CollectionUtils.isEmpty(mapFormBMonto))
				{
				    Elementos<DatoMonto> listMontos = new Elementos<DatoMonto>();
				    dav.setListMontos(listMontos);

					Set keySetFormBMonto = mapFormBMonto.keySet();
					for (Object key : keySetFormBMonto) {
					    DatoMonto monto = new DatoMonto();
						monto.setCodmonto	 ( key.toString() ) ; //"COD_MONTO"
						monto.setMtologistico	( ( java.math.BigDecimal )  mapFormBMonto.get(key) ); //"MTO_VALOR"		    	
						listMontos.add(monto);
					}					
				}
				
//				dav.getProveedor().setNumeroDocumentoIdentidad	( (java.lang.String)  hm.get("NUM_DOCIDENT")  );
//				dav.getProveedor().getTipoParticipante().setCodDatacat	( (java.lang.String)  hm.get("COD_TIPPARTIC")  );
//				dav.getProveedor().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  hm.get("COD_TIPDOC")  );
				dav.getProveedor().getPais().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_PAISORIGEN_PRV")  );
				dav.getProveedor().setNombreRazonSocial	( (java.lang.String)  formBProveedor.get("NOM_RAZONSOCIAL_PRV")  );
				dav.getProveedor().setCiudad	( (java.lang.String)  formBProveedor.get("DES_UBIGEOCIUDAD_PRV")  );
				dav.getProveedor().setDireccion	( (java.lang.String)  formBProveedor.get("DIR_PARTIC_PRV")  );
				dav.getProveedor().setTelefono	( (java.lang.String)  formBProveedor.get("NUM_TELEFONO_PRV")  );
				dav.getProveedor().setFax	( (java.lang.String)  formBProveedor.get("NUM_FAX_PRV")  );
				dav.getProveedor().setEmail	( (java.lang.String)  formBProveedor.get("NOM_EMAIL_PRV")  );
				dav.getProveedor().setPaginaWeb	( (java.lang.String)  formBProveedor.get("NOM_PAGINAWEB_PRV")  );
				
//				dav.getProveedorLocal().setNumeroDocumentoIdentidad	( (java.lang.String)  formBProveedor.get("NUM_DOCIDENT")  );
//				dav.getProveedorLocal().getTipoParticipante().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_TIPPARTIC")  );
//				dav.getProveedorLocal().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_TIPDOC")  );
				dav.getProveedorLocal().setNombreRazonSocial	( (java.lang.String)  formBProveedor.get("NOM_RAZONSOCIAL_PRL")  );
				
//				dav.getIntermediario().setNumeroDocumentoIdentidad	( (java.lang.String)  formBProveedor.get("NUM_DOCIDENT")  );
//				dav.getIntermediario().getTipoParticipante().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_TIPPARTIC")  );
//				dav.getIntermediario().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_TIPDOC")  );
				dav.getIntermediario().getPais().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_PAISORIGEN")  );
				dav.getIntermediario().setNombreRazonSocial	( (java.lang.String)  formBProveedor.get("NOM_RAZONSOCIAL_PRI")  );
				dav.getIntermediario().setCiudad	( (java.lang.String)  formBProveedor.get("DES_UBIGEOCIUDAD_PRI")  );
				dav.getIntermediario().setDireccion	( (java.lang.String)  formBProveedor.get("DIR_PARTIC_PRI")  );
				dav.getIntermediario().setEmail	( (java.lang.String)  formBProveedor.get("NOM_EMAIL_PRI")  );
				
				dav.getPersonaDecl().setNumeroDocumentoIdentidad	( (java.lang.String)  formBProveedor.get("NUM_DOCIDENT_PRD")  );
//				dav.getPersonaDecl().getTipoDocumentoIdentidad().setCodDatacat	( (java.lang.String)  formBProveedor.get("COD_TIPPARTIC")  );
				dav.getPersonaDecl().setNombreRazonSocial	( (java.lang.String)  formBProveedor.get("NOM_RAZONSOCIAL_PRD")  );
			    			    
			    List<Map> lstComproBPago = null;
			    
			    if(formBProveedor.containsKey("lstComproBPago"))
			    	lstComproBPago = (List<Map>)formBProveedor.get("lstComproBPago");
			    
			    if( !CollectionUtils.isEmpty(lstComproBPago) )
			    {
				    Elementos<DatoFactura> listFacturas = new Elementos<DatoFactura>();
				    dav.setListFacturas(listFacturas);

			    	for (Map comproBPago : lstComproBPago) {

						DatoFactura factura = new  DatoFactura();
						factura.setNumsecfactu	( SunatNumberUtils.toInteger( comproBPago.get("NUM_SECFACT")  ) );
						factura.setCnttotitems	( SunatNumberUtils.toInteger( comproBPago.get("CNT_TOTITEMS")  ) ); 
						factura.setNumfactura	( (java.lang.String)  comproBPago.get("NUM_FACT")  );
						factura.setFecfactura	( (java.util.Date)  comproBPago.get("FEC_FACT")  );
						factura.setCodincoterm	( (java.lang.String)  comproBPago.get("COD_INCOTERM")  );
						factura.setDeslugtrans	( (java.lang.String)  comproBPago.get("DIR_LUGARTRANS")  );
						factura.setCodmoneda	( (java.lang.String)  comproBPago.get("COD_MONEDA")  );
						factura.setCodpaisembar	( (java.lang.String)  comproBPago.get("COD_PAISEMBARQUE")  );
						factura.setMtofactufob	( ( java.math.BigDecimal )  comproBPago.get("MTO_FACT")  );
						factura.setIndtipodecl	( (java.lang.String)  comproBPago.get("IND_DDJJ")  );
						
						//TODO factura.setListFactSucesivas(listFactSucesivas);
						/*
						Elementos<DatoFactSuce> listFactSucesivas = new Elementos<DatoFactSuce>();
						factura.setListFactSucesivas(listFactSucesivas);
						
						{
							DatoFactSuce factSucesiva = new DatoFactSuce(); 
							factSucesiva.setNumfactsuc	( (java.lang.String)  hm.get("NUM_FACTSUC")  );
							factSucesiva.setFecfactsuc	( (java.util.Date)  hm.get("FEC_FACT")  );
							factSucesiva.setMtofactsuc	( ( java.math.BigDecimal )  hm.get("MTO_FACT")  );			
						}
						*/
						
						List<Map> lstItemFactura = null;
						
						if(formBProveedor.containsKey("lstItemFactura"))
							lstItemFactura = (List<Map>)formBProveedor.get("lstItemFactura");
						
						if( ! CollectionUtils.isEmpty(lstItemFactura))
						{
							for (Map itemFactura : lstItemFactura) {

								DatoItem item = new DatoItem();
								item.setNumsecitem	( SunatNumberUtils.toInteger( itemFactura.get("NUM_SECITEM")  ) );
								item.setCodpaisorige	( (java.lang.String)  itemFactura.get("COD_PAISORIGEN")  );
								item.setCntcantcomer	( ( java.math.BigDecimal )  itemFactura.get("CNT_UNI")  );
								item.setCodunidcomer	( (java.lang.String)  itemFactura.get("COD_UNICOMER")  );
								item.setDescomercial	( (java.lang.String)  itemFactura.get("DES_COMER")  );
								item.setDesmarca	( (java.lang.String)  itemFactura.get("DES_MARCA")  );
								item.setDesmodelo	( (java.lang.String)  itemFactura.get("DES_MODELO")  );
								item.setCodproducto	( (java.lang.String)  itemFactura.get("COD_PROD")  );
								item.setNumpartnandi	( SunatNumberUtils.toLong( itemFactura.get("NUM_PARARANCEL")  ) );
								item.setCodpaisadqui	( (java.lang.String)  itemFactura.get("COD_PAISADQUI")  );
								item.setDescaracteristicas	( (java.lang.String)  itemFactura.get("DES_CARACTERISTICAS")  );
								item.setDesclasevari	( (java.lang.String)  itemFactura.get("DES_CLASEVARI")  );
								item.setDesusoaplica	( (java.lang.String)  itemFactura.get("DES_USOAPLIC")  );
								item.setDesmaterialcomp	( (java.lang.String)  itemFactura.get("DES_MATERIALCOMP")  );		
								//item.getMontoProv().setIndtipovalor	( (java.lang.String)  itemFactura.get("")  );
								item.getMontoProv().setFecvalestima	( (java.util.Date)  itemFactura.get("FEC_VALESTIMA")  );
								item.getMontoProv().setValmonto	( ( java.math.BigDecimal )  itemFactura.get("MTO_MONTO")  );
								item.getMontoProv().setCodmoneda	( (java.lang.String)  itemFactura.get("COD_MONEDA")  );
								item.getMontoProv().setFectipocambio	( (java.util.Date)  itemFactura.get("FEC_TIPCAMB")  );
								item.getMontoProv().setValdefinitivo	( ( java.math.BigDecimal )  itemFactura.get("MTO_DEFINITIVO")  );
								
								//Datos adicionales de los items		
								item.setInddeducdisti	( (java.lang.String)  itemFactura.get("IND_DEDUC")  );
								item.setMtofobunita	( ( java.math.BigDecimal )  itemFactura.get("MTO_FOBUNITARIO")  );
								item.setMtoajusunita	( ( java.math.BigDecimal )  itemFactura.get("MTO_AJUUNITARIO")  );
								item.setAnnfabrica	( (java.lang.String)  itemFactura.get("ANN_FABRICACION")  );
								item.setCodestamer	( (java.lang.String)  itemFactura.get("COD_ESTMERC")  );
								item.setIndsoftware	( (java.lang.String)  itemFactura.get("IND_SOFTWARE")  );
								item.setIndvarios	( (java.lang.String)  itemFactura.get("IND_OTROS")  );
								item.setMtofobitem	( ( java.math.BigDecimal )  itemFactura.get("MTO_FOBITEM")  );
								
								//TODO item.setListDecrMinima
								/*
								Elementos<DatoDescrMinima> listDescrMinimas = new Elementos<DatoDescrMinima>();
								item.setListDecrMinima(listDescrMinimas);
								
								{
									DatoDescrMinima descrMinima = new DatoDescrMinima();
									descrMinima.setCodtipdescr	( (java.lang.String)  hm.get("COD_TIPDESC")  );
									descrMinima.setValtipdescri	( (java.lang.String)  hm.get("DES_DESCRIPCION")  );
									listDescrMinimas.add(descrMinima);			
								}
								*/
								
								//TODO item.setListObservaciones()
								/*
								observacion.setNumsecuencia	( (java.lang.String)  hm.get("")  );
								observacion.setCodtipobserva	( (java.lang.String)  hm.get("")  );
								observacion.setObsdeclaracion	( (java.lang.String)  hm.get("")  );
									
								*/
																
								List<Map> lstSeriesItem = (List<Map>)formBProveedor.get("lstSeriesItem");
								
								if(!CollectionUtils.isEmpty(lstSeriesItem))
								{
									Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();
									item.setListSerieItems(listSerieItems);

									for (Map mapSerieItem : lstSeriesItem) {

										DatoSerieItem serieItem = new DatoSerieItem(); 
										serieItem.setCant_mercd	( ( java.math.BigDecimal )  mapSerieItem.get("CNT_MERC")  );
										serieItem.setNumserie	( SunatNumberUtils.toInteger( mapSerieItem.get("NUM_SECSERIE")  ) );
										serieItem.setMtofobitser	( ( java.math.BigDecimal )  mapSerieItem.get("MTO_FOB")  );
										serieItem.setMtoajuitser	( ( java.math.BigDecimal )  mapSerieItem.get("MTO_AJUSTE")  );			
										listSerieItems.add(serieItem);
									}
								}
							}
						}
					}
			    }
			    
			    Map mapCondicionTransa = (Map)formBProveedor.get("mapCondicionTransa");
				if(!CollectionUtils.isEmpty(mapCondicionTransa))
				{
					//dav.setListCondTransacciones()
					Elementos<DatoCondTransaccion> listCondTransacciones = new Elementos<DatoCondTransaccion>();
					dav.setListCondTransacciones(listCondTransacciones);

					Set keySetCondicionTransa = mapCondicionTransa.keySet();
					for (Object key : keySetCondicionTransa) 
					{
						DatoCondTransaccion condTransaccion = new DatoCondTransaccion();
						condTransaccion.setCodindcondtra	( (java.lang.String)  key ); //COD_INDTRANSACCION
						condTransaccion.setIndcondtra	( (java.lang.String)  mapCondicionTransa.get(key)  );				//IND_TRANSACCION
						listCondTransacciones.add(condTransaccion);
					}			
				}
			}
		}
		
		
		return declaracion;
	}
	
	
	
	public static void main(String[] args) {
		HashMap map =  (HashMap)(new SerializacionUtil()).desSerializarObjeto("", "C:/Tmp/rectificacion.mser");
		GetDeclaracionHashMapToDeclaracionObjectHelper.getInstance().transform(map);
	}
}
