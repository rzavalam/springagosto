package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;//RIN10

public interface RectificacionService {

//Refactory RIN 10
	public Map<String, Object> findByNumRucExiste(String numeroDocumentoIdentidad);

	public void insertPadUsuGara(Map<String, Object> params);
//RIN 10

	//DUA getDUA(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen);
}
