package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.Predicate;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatAsocDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
@Deprecated
public class CatalogoHelperImpl {
	
	private static final String RUC_VIGENTE_HABIDO = "0000";
	CatalogoAyudaService catalogoAyudaService;
	CatalogoValidaService catalogoValidacionService;
	OperadorValidaService operadorValidaService;
	OperadorAyudaService operadorAyudaService;
	private AyudaService ayudaService;
	private PackageTD packageTD; 
	
	//private DataCatAsocDAO dataCatAsocDAO;
	
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public boolean isValid(String value, String catalogType){
	    
		return isValid( value, catalogType, SunatDateUtils.getCurrentDate());
	}
 
	@SuppressWarnings("rawtypes")
	public boolean isValid(String value, String catalogType, Date fechaVigencia){
	    // para resolver el bug 1589	
		//List result = catalogoValidacionService.validarElementoCat(catalogType, value);
		//List result = catalogoValidacionService.validarElementoCat(catalogType, value, SunatDateUtils.getCurrentDate());
		List result = catalogoValidacionService.validarElementoCat(catalogType, value, fechaVigencia!=null?fechaVigencia:SunatDateUtils.getCurrentDate() );
				
		return CollectionUtils.isEmpty(result);
	}
	
	private Map<String,String>  getErrorMapFromDataCatalogo(DataCatalogo dataCatalogo)
	{
		Map<String,String> map = new HashMap<String, String>();
		map.put(ResponseMapManager.KEY_CODIGO, dataCatalogo.getCodDatacat() );
		map.put(ResponseMapManager.KEY_DESCRIPCION, dataCatalogo.getDesDatacat());
		map.put(ResponseMapManager.KEY_TIPO_ALERTA, ResponseMapManager.VALUE_TIPO_ALERTA_WARNING);			
		
		return map;
	}
	
	private Map<String,String>  getEmptyErrorMap(String errorCode){
		Map<String,String> map = new HashMap<String, String>();
		
		map.put(ResponseMapManager.KEY_CODIGO, SunatStringUtils.isEmpty(errorCode) ? "XXXXX": errorCode );
		map.put(ResponseMapManager.KEY_DESCRIPCION, " ");
		map.put(ResponseMapManager.KEY_TIPO_ALERTA, ResponseMapManager.VALUE_TIPO_ALERTA_WARNING);			
		return map;
	}
	
	/**
	 * Obtiene un mapa de error segun el codigo enviado
	 * @param errorCode
	 * @return
	 */
	public Map<String,String> getErrorMap(String errorCode){		
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =catalogoAyudaService.getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}
		
	}

	/**
	 * Obtiene un mapa de error segun el codigo enviado y formatea el mensaje con el argumento enviado 
	 * @param errorCode
	 * @param args
	 * @return
	 */
	public Map<String,String> getErrorMap(String errorCode, Object args){
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =catalogoAyudaService.getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			dataCatalogo.setDesDatacat( formatMessage( dataCatalogo.getDesDatacat(), new Object[]{args} )  );
			
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}
		
	}	
	
	/**
	 * Crea un mapa de error con el codigo y la descripcion enviada
	 * @param errorCode
	 * @param description
	 * @return
	 */
	public Map<String,String> getErrorMapWithDescription(String errorCode, String description){
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);		
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =catalogoAyudaService.getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}

	}	
	
	/**
	 * Obtiene un mapa de error segun el codigo entregado y formatea la descripcion con los argumentos enviados 
	 * @param errorCode
	 * @param args
	 * @return
	 */
	public Map<String,String> getErrorMap(String errorCode, Object[] args){
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);		
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =catalogoAyudaService.getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			// Se agregan los mensajes
			dataCatalogo.setDesDatacat( formatMessage( dataCatalogo.getDesDatacat(), args )  );
			//
			
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}
		
	}	
	
	/**
	 * 
	 * @param codproveedor
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public boolean existsProveedor(String codproveedor )
	{
		if(SunatStringUtils.isEmpty(codproveedor))
			return false; 
		
		List result = operadorValidaService.validarCatprovee(codproveedor);
		
		return CollectionUtils.isEmpty(result);		
	}
	
	/**
	 * 
	 * @param numRUC
	 * @claseOpera
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public boolean esOperadorValido(String numRUC, String claseOpera )
	{
		if(SunatStringUtils.isEmpty(numRUC))
			return false; 
		
		List result = operadorValidaService.validarOperador(numRUC, claseOpera);
		
		return CollectionUtils.isEmpty(result);		
	}
	
	public boolean esOperadorValido(String numRUC, String claseOpera, Date fecha )
	{
		if(SunatStringUtils.isEmpty(numRUC))
			return false; 
		
		List result = operadorValidaService.validarOperador(numRUC, claseOpera, fecha);
		
		return CollectionUtils.isEmpty(result);		
	}
	
	public boolean esOperadorValido(String numRUC, String claseOpera, Date fecha, String codAduana )
	{
		if(SunatStringUtils.isEmpty(numRUC))
			return false; 
		
		List result = operadorValidaService.validarOperador(numRUC, claseOpera, codAduana, fecha);
		
		return CollectionUtils.isEmpty(result);		
	}

	public boolean esOperadorComexValido(String numRUC, String claseOpera, Date fecha, Boolean indHabilitado )
	{
		if(SunatStringUtils.isEmpty(numRUC))
			return false; 
		
		List result = operadorValidaService.validarOperadorOpecomext(numRUC, claseOpera, fecha, indHabilitado);
		
		return CollectionUtils.isEmpty(result);		
	}

	/**/
	
	
	public String getDescripcionDataCatalogo(String tipo, String codigo){
		if (isValid(tipo,codigo))
			return catalogoAyudaService.getDescripcionDataCatalogo(tipo, codigo);
		else
			return "";
	}
	
	public List<Map<String,String>> getElementosCat(String tipo){
		return catalogoAyudaService.getElementosCat(tipo);
	}
	
	/**
	 *b.	Sql = "select codigo from tablnew where tipo='TV' AND codigo='"+A_CADENA(Tempo2.trat_prefe)+"' AND TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) BETWEEN finicio and ffin" 
	 */
	@SuppressWarnings("rawtypes")
	public boolean existsTratamiento(String tipo, Integer tratPrefe)
	{		
		List result = catalogoValidacionService.validarElementoCat(tipo, tratPrefe.toString());
		//NSR: el Metodo ValidarElementoCat devuelve una List con un mapa vacio si encuentra el elemento
		//	   caso contrario devuelve null, por lo tanto se reescribe este metodo
		if(result==null){			//null es no existe
			return false;
		}else if(result.isEmpty()){	//vacio es ok
			return true;
		}else{//por un tal vez
			return false;
		}
	}
	
	/**
	 * Verifica que el punto de llegada pertenezca a la aduana de
	 * transmision
	 * @deprecated
	 * @param numeroRUCpuntoLlegada
	 * @param codigoAduanaTransmision
	 * @return
	 */
	public boolean rucTerminalPortuarioPerteneceAduanaTransmision(String numeroRUCpuntoLlegada,
			String codigoAduanaTransmision) {
		List<Map<String, Object>> puertosPorAduana = findPuertosEnJurisdiccionByCodigoAduana(codigoAduanaTransmision);
		List<Map<String, Object>> puertosPorNumeroRuc = findPuertosByRuc(numeroRUCpuntoLlegada, "113");
		List<Map<String, Object>> puertosPorNumeroRucMultiBoyas = findPuertosByRuc(numeroRUCpuntoLlegada, "123");

		for (Map<String, Object> mapPuertoAduana : puertosPorAduana) {
			final String codigoPuertoAduana = (String) mapPuertoAduana.get("cod_datacatasoc");
			Object puertoEncontrado = org.apache.commons.collections.CollectionUtils.find(puertosPorNumeroRuc, new Predicate() {

				@Override
				public boolean evaluate(Object puertoPorNumeroRuc) {
					@SuppressWarnings("unchecked")
					String codigoPuertoPorNumeroRuc = (String) ((Map<String, Object>) puertoPorNumeroRuc)
							.get("cod_datacat");
					try {
						return codigoPuertoPorNumeroRuc.equals(codigoPuertoAduana);
					} catch (NullPointerException ne) {
						return false;
					}
				}
			});
			if (puertoEncontrado != null) {				
				return true;
			} else {				
				//puertosPorNumeroRuc = findPuertosByRuc(numeroRUCpuntoLlegada, "123");
				puertoEncontrado = org.apache.commons.collections.CollectionUtils.find(puertosPorNumeroRucMultiBoyas, new Predicate() {
					@Override
					public boolean evaluate(Object puertoPorNumeroRuc) {
						@SuppressWarnings("unchecked")
						String codigoPuertoPorNumeroRuc = (String) ((Map<String, Object>) puertoPorNumeroRuc)
								.get("cod_datacat");
						try {
							return codigoPuertoPorNumeroRuc.equals(codigoPuertoAduana);
						} catch (NullPointerException ne) {
							return false;
						}
					}
				});
				if (puertoEncontrado != null) {				
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Busca puertos por de una determinada aduana
	 * @deprecated
	 * @return
	 */
	private List<Map<String, Object>> findPuertosEnJurisdiccionByCodigoAduana(String codigoAduanaTransmision) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		// retornar COD_DATACATASOC
		/* para asociacion = 109 */
		parametros.put("codAsociacion", "109");
		parametros.put("codElemento", codigoAduanaTransmision);
		parametros.put("codSelElemento", "C");

		
		List<Map<String,Object>>  listDataCatAsoc= new ArrayList();	
		parametros.put("ayudaID", "DataCatAsoc");
		listDataCatAsoc= (List<Map<String,Object>>)ayudaService.findByMapDataCatAsoc(parametros);
		
		//return dataCatAsocDAO.findByMap(parametros);
		
		return listDataCatAsoc;
	}

	/**
	 * Busca puertos asociados a un numero de ruc
	 * 
	 * @return
	 */
	private List<Map<String, Object>> findPuertosByRuc(String numeroRUCpuntoLlegada, String codAsociacion) {
		// retornar COD_DATACAT
		Map<String, Object> parametros = new HashMap<String, Object>();
		// para asociacion = 113
		//parametros.put("codAsociacion", "113");
		parametros.put("codAsociacion", codAsociacion);
		parametros.put("codElemento", numeroRUCpuntoLlegada);
		parametros.put("codSelElemento", "A");
		
		
		List<Map<String,Object>>  listDataCatAsoc= new ArrayList();	
		parametros.put("ayudaID", "DataCatAsoc");
		listDataCatAsoc= (List<Map<String,Object>>)ayudaService.findByMapDataCatAsoc(parametros);
		
		
		//return dataCatAsocDAO.findByMap(parametros);
		
		return listDataCatAsoc;
	}

	/**
	 * Valida si un ruc se encuentra en estado vigente y habido
	 * @param numeroRUCpuntoLlegada
	 * @deprecated
	 * @return
	 */
	public boolean esRucValidoActivo(String numeroRUCpuntoLlegada) {
		
		// para el tipo de busqueda = 2 retorna la vigencia y la condicion del ruc buscado
		//los dos primeros caracteres de la vigencia y los dos ultimos la condicion
		String vigenciaCondicionRuc = packageTD.functionDeclaVig(numeroRUCpuntoLlegada,"2","4");
		if(RUC_VIGENTE_HABIDO.equals(vigenciaCondicionRuc)){
			return true;
		}else{
			return false;
		}
	}
	public void setCatalogoValidacionService(CatalogoValidaService catalogoValidacionService) {
		this.catalogoValidacionService = catalogoValidacionService;
	}

	public CatalogoValidaService getCatalogoValidacionService() {
		return catalogoValidacionService;
	}

	public OperadorValidaService getOperadorValidaService() {
		return operadorValidaService;
	}

	public void setOperadorValidaService(OperadorValidaService operadorValidaService) {
		this.operadorValidaService = operadorValidaService;
	}

	public OperadorAyudaService getOperadorAyudaService() {
		return operadorAyudaService;
	}

	public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService) {
		this.operadorAyudaService = operadorAyudaService;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}
	public CatalogoAyudaService getCatalogoAyudaService() {
		return catalogoAyudaService;
	}

	public boolean isPuertoVigente(String codPuerto){
		List<Map<String,String>> listValPuerto=catalogoValidacionService.validarPuerto(codPuerto);
		return (listValPuerto==null || listValPuerto.isEmpty());
	}
	
	private String formatMessage(String mensaje, Object [] argumentos){
		return  MessageFormat.format(mensaje,argumentos);
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}

	

}
