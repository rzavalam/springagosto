package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.partidas;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValPartidaEERService {
	public List<Map<String,String>> valPartidasCategoria02(DatoSerie datoSerie, String codCategoria);
	public List<Map<String,String>> valPartidasCategoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries);
	public List<Map<String,String>> valPartidas30Categoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries);
	public List<Map<String,String>> valPartidas40Categoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries);
	public List<Map<String,String>> valTipoDocumentoPartidas40(Declaracion declaracion);
}
