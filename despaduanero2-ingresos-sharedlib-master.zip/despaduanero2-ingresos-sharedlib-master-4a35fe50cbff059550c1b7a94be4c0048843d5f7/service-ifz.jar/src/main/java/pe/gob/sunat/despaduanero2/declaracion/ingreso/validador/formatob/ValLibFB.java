package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

public interface ValLibFB {

	public List<Map<String, String>> valDescMin(String pTipoRela) ;
	
	public List<Map<String, String>> valNombCom();

}
