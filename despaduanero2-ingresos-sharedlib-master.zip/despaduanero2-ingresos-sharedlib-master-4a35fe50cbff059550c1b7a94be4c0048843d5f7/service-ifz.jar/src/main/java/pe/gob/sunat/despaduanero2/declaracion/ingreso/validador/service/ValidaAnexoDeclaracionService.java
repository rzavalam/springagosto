package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date; // RIN10
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;

public interface ValidaAnexoDeclaracionService {

	//public abstract void setCalculoAdeudoService(GeneraLiquidacionService generaLiquidacionService);

	/**
	 * Realiza el calculo de liquidacion de la declaracion
	 * @param declaracion
	 * @param numeroDocumentoIdentidadSender
	 * @param tipoDocumentoIdentidadSender
	 * @param numOrden
	 * @param codUsuario
	 * @return
	 */
	public abstract Map<String, String> calculaLiquidacion(
			Declaracion declaracion, String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, String numOrden,
			String codUsuario, String codTransaccion, Integer nroErroresNegocio, Map variablesIngreso);

	public abstract List<Map<String, ?>> separaGarantia(
			Declaracion declaracion, String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, String numOrden,
			String codUsuario, Integer nroErroresNegocio,
			Map<String, Object> variablesIngreso, String codTransaccion);

	/**
	 * Servicio que invoca a la funciones del calculo de adeudo
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @author hosorio
	 * @return HashMap<String, Object>
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3033, descServicio = "Invocacion al servicio de calculo de diferencia y la almacena en memoria")
	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion",
			"variablesIngreso", "nroErroresNegocio" })
	@OrquestaDespaAnnot(codServInstancia = 3033, numSecEjec = 425, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public abstract Map<String, String> calculaDeudaRectificacion(
			Declaracion declaracion, Map<String, Object> variablesIngreso,
			Integer nroErroresNegocio) throws Exception;

	/**
	 * Servicio que valida la exigencia de autoliquidacion en la rectificacion y en caso de no presentar autoliquidacion
	 * ,valida la exigencia de garantia disponible
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @author hosorio
	 * @return HashMap<String, Object>
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3034, descServicio = "Realiza la validacion de la liquidacion de rectificacion")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion",
			"variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3034, numSecEjec = 426, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public abstract List<Map<String, String>> validarliquidacionRectificacion(
			Declaracion declaracion, Map<String, Object> variablesIngreso)
			throws Exception;

	
	public abstract List<Map<String, String>> validarAfectarGarantia160(
			Declaracion declaracion, BigDecimal montoAcumuladoDolares,
			String cda, Integer fechaConclusionDespacho,
			String numeroDocumentoIdentidadSender, String modulo, String ctrans,Map<String, Object> variablesIngreso);

	public abstract BigDecimal imputacion(Declaracion declaracion,
			Map<String, Object> variablesIngreso,
			Map<String, Object> deudadiferencial) throws Exception;

	/**
	 * Servicio que valida la autoliquidacion contra los montos diferenciales calculados, esta validacion
	 * se hace de manera jerarquica (imputacion)  o tributo por tributo
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @author hosorio
	 * @return HashMap<String, Object>
	 */
	/*@ServicioAnnot(tipo="V",codServicio=3027, descServicio="valida la autoliquidacion contra los montos diferenciales calculados")
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"declaracion","deudadiferencial","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3027,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")*/
	public abstract List<Map<String, String>> infoautoliquidacion(
			Declaracion declaracion, Map<String, Object> deudaCalculada,
			Map<String, Object> variablesIngreso) throws Exception;

	public abstract BigDecimal calculoTotalTributo(
			Map<String, Object> deudadiferencial, int tipoLiqui);

	/*pase 580*/
	public abstract Map<String, Object> obtenerMapDua(Declaracion declaracion);

	@ServicioAnnot(tipo = "V", codServicio = 3311, descServicio = "Servicio de Validacion de Liquidacion de la Regularizacion")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion",
			"variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3311, numSecEjec = 3, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public abstract List<Map<String, String>> validarLiquidacionRegularizacionAntiguo(
			Declaracion declaracion, Map<String, Object> variablesIngreso)
			throws Exception;

	/**
	 * Valida imputacion regularizaci�n.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return lista de errorres
	 */
	public abstract List<Map<String, String>> validaImputacionRegularizacion(
			Declaracion declaracion, Map<String, Object> variablesIngreso);

	@ServicioAnnot(tipo = "V", codServicio = 3311, descServicio = "Servicio de Validacion de Liquidacion de la Regularizacion")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion",
			"variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3311, numSecEjec = 3, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public abstract List<Map<String, String>> validarLiquidacionRegularizacion(
			Declaracion declaracion, Map<String, Object> variablesIngreso)
			throws Exception;

	public abstract Map<String, BigDecimal> obtenerDeudaAnterior(
			Declaracion declaracion, String codCatalogotributo,
			String codEstaAdmin);

	public abstract Map<String, Object> recalculoDiferenciaTrib(
			Map<String, Object> mapTributos1,
			Map<String, BigDecimal> mapTributos2, String codCatalogoTrib);

	/*Pase 580*/
	public abstract List<Map<String, String>> autoLiquidacionTributoATributo(
			Map<String, Object> deudadiferencial,
			Map<String, BigDecimal> mapTributos2, String codCatalogoTrib);

	// metodo sobrecargado del anterior	
	public abstract List<Map<String, String>> autoLiquidacionTributoATributo(
			Map<String, Object> deudadiferencial,
			Map<String, BigDecimal> mapTributos2, String codCatalogoTrib,
			String listTribNoAutoliqui);

	public abstract List<Map<String, Object>> obtenerDudaRazonableDua(
			Declaracion declaracion);

	public abstract List<DatoOtroDocSoporte> obtenerAutoliquiDeclarada(
			Declaracion declaracion, String strLstAutoAsociada);

	public abstract Map<String, BigDecimal> obtenerDetalleTributosAutoliquidado(
			List<Liquida> lstAutoliquidaciones, String codCatalogTributo);

	public abstract boolean isFCCancelado(Declaracion declaracion);
	
	public Map<String, String> validaGeneraPercepcion(Declaracion declaracion,  Map<String, Object> variablesIngreso);

	boolean esGarantiaRenovada(String numCtaCte);
	//Inicio RIN10 Refactor
	public List<Map<String,String>> validarSaldoOperativoDisponibleCtaCteGarantiaVP(Declaracion declaracion,Date fechaReferencia,BigDecimal sumaBaseImponibleSeries);
	//Fin RIN10 Refactor
	//PAS20165E220200127
	public boolean existeIncidencia(Map<String,Object> deudadiferencial,List<DeudaDocum> listaDeudaDocum);
	public boolean isAplicarImputacion(Declaracion declaracion,Map<String, Object> mapDua,Map<Object,Object> mapManif);

	public Map<String, String> calculaLiquidacionEER(
			Declaracion declaracion,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender,
			String numOrden,
			String codUsuario,
			String codTransaccion,
			Integer nroErroresNegocio,
            Map variablesIngreso);

	public List<Map<String, ?>> separaGarantiaEER(Declaracion declaracion,
												  String numeroDocumentoIdentidadSender,
												  String tipoDocumentoIdentidadSender,
												  String numOrden,
												  String codUsuario,
												  Integer nroErroresNegocio,
												  Map variablesIngreso,
												  String codTransaccion);
	public List<Map<String, String>> validarGarantiaEER(DUA dua, String numeroDocumentoIdentidadSender,Map<String, Object> variablesCancelacion);

	public Map<String, String> validaMontoGarantia159(Declaracion declaracion) throws Exception;
}