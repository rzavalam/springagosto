package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ValPrecedenteDutyFreeService {

	//public List<Map<String, String>> validaDutyFree(List<DatoSerie> listSeries);
	public List<Map<String, String>> validaDutyFree(Declaracion declaracion,String puntoDeLlegada, List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia);
}
