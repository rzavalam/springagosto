package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * Clase que permite realizar la grabacion del formato B 
 * @author rcalla
 *
 */
public interface GrabarFormatoBService {

	Map<String, ?> grabaFB(Declaracion declaracion);
}
