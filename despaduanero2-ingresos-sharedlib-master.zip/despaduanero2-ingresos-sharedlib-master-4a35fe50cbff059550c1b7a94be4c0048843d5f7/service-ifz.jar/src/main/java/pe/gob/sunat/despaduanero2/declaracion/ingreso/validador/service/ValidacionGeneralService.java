package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValidacionGeneralService {

	
	public Map<String, Object> obtfecConclusionDespacho(Map<String, Object> variablesIngreso);		
	/**
     * @author hsaenz
     * @since 08/09/2014
     * Obtiene fecha de vencimiento de conclusi�n. 
     */	
	public Map<String, Object> obtFechaConclusionDespacho(Map<String, Object> variablesIngreso, Date fechaInicio, int numeroMeses);
	public Map<String, Object> validarTipoDespacho(Declaracion declaracion, Map<String, Object> variablesIngreso);
	public List<Map<String,?>> validarDatado(Declaracion declaracion,Map<String, Object> variablesIngreso ) throws Exception;
	public  Boolean verificarCancelacion(Long Numecorredoc);
	public Map<String,String> verificaCtaCteVehiUsado(Declaracion declaracion,Map<String, Object> variablesIngreso) throws Exception;
	public List<Map<String,?>> validarDesDatado(Declaracion declaracion,String codTransaccion);
	public List<Map<String,?>> validarMontoSeguro(Declaracion declaracion, Date fechaReferencia) throws Exception;
	public List<Map<String, ?>> validarUsuarioSEIDA(String codUsuario, String tipoSender );
}
