/*
 *
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;


import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoValidacionDescrMin;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;




/**
 * La Interface TipoDeDescrMinimaService.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public interface TipoDeDescrMinimaService {

  public static final String ASOCIACION_PARTIDA_VS_DESCRMINIMA   = "015";
  public static final String CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA = "320";
  public static final String CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA = "500";
  public static final String CATALOGO_FECHA_VIGENCIA             = "507";



  /**
   * Obtener tipo de descr minima desde la base de datos
   * 
   * @param numCorreDoc
   *          [Long] num corre doc
   * @param numSecItem
   *          [Int] num sec item
   * @return [String] String
   * @author amancillaa
   * @version 1.0
   */
  public String obtenerTipoDeDescrMinima(long numCorreDoc, int numSecItem);


  /**
   * Obtener tipo de descr minima en base a la estructura que se envia solo
   * reconoce la nueva estructura de descripciones minimas de verificar que
   * tiene la antigua estructur devolver NULL
   * 
   * @param lstDatosXML
   *          [List<DatoDescrMinima>] lst datos xml
   * @return [Enum<?>] enum
   * @author amancilla
   * @version 1.0
   */
  public Enum<?> obtenerTipoDeDescrMinima(DatoItem item) throws Exception;

  /**Inicio Ajuste para la consideracion de la fecha de declaracion de la dam**/
  public Enum<?> obtenerTipoDeDescrMinima(DatoItem item,Date fechaVigencia) throws Exception;


  //rtineo mejoras,sobrecargamos la funcion
  public Enum<?> obtenerTipoDeDescrMinima(DatoItem item,Date fechaVigencia, Map<String, Object> variablesIngreso) throws Exception;
  /**Fin ajuste para la consideracion de la fecha de declaracion de la dam**/
  
  /**
   * Determinar tipo validacion aplicar evaluando la estructura de transmision .
   * 
   * @param lstDatosXML
   *          [List<DatoDescrMinima>] lst datos xml
   * @return NEW_VALIDACIONES - nueva estructura cat 500 OLD_VALIDACIONES -
   *         antigua estructura cat 320
   * @author amancillaa
   * @version 1.0
   */
  public TipoValidacionDescrMin determinarTipoValidacionAplicar(DatoItem item);


  /**
   * Tiene nueva estructura.
   * 
   * @param item
   *          [DatoItem] item
   * @return true, if successful
   */
  public boolean tieneNuevaEstructura(DatoItem item);

  //rtineo mejoras, sobrecargamos el metodo
  public boolean tieneNuevaEstructura(DatoItem item,Map<String, Object> variablesIngreso);
  
  /**
   * Determinar tipo validacion aplicar evaluando la estructura del item enviado (usado para recti, regu y dilig).
   * 
   * @param lstDatosXML
   *          [List<DatoDescrMinima>] lst datos xml
   * @return NEW_VALIDACIONES - nueva estructura cat 500 OLD_VALIDACIONES -
   *         antigua estructura cat 320
   * @author arey
   * @version 1.0
   */
  public TipoValidacionDescrMin determinarTipoValidacionPorTipoDescrMinima(DatoItem item);
  public TipoValidacionDescrMin determinarTipoValidacionPorTipoDescrMinima(DatoItem item,Map<String, Object> variablesIngreso);
}
