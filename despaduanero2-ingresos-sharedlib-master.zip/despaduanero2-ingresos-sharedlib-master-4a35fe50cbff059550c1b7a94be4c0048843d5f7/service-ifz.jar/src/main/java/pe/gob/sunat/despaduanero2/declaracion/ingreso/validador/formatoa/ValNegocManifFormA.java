/*
 * Clase que define el servicio de validaciones de los datos del manifiesto.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValNegocManifFormA. Clase que define el servicio de validaciones de los datos del manifiesto.
 */
public interface ValNegocManifFormA {
	
	public List<Map<String, String>> valManif(Declaracion declaracion, String xTipoProce);
	
}
