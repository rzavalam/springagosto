package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.transportista;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.model.Participante;

public interface ValTransportistaService {

	public List<Map<String, ?>> validarTipoDocumentoIdentidadTransportista(DUA dua,String codTransaccion, Date fechaReferencia);
	public List<Map<String, ?>> validarTipoOperadorTransportistaPermitido(DUA dua,String codTransaccion, Date fechaReferencia);
}
