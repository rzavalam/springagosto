package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean;

import java.util.Map;

public class RecordBean {

	private String codtabla;
	private Map<String,Object> key;
	private Map<String,Object> datos;
	public String getCodtabla() {
		return codtabla;
	}
	public void setCodtabla(String codtabla) {
		this.codtabla = codtabla;
	}
	public Map<String, Object> getKey() {
		return key;
	}
	public void setKey(Map<String, Object> key) {
		this.key = key;
	}
	public Map<String, Object> getDatos() {
		return datos;
	}
	public void setDatos(Map<String, Object> datos) {
		this.datos = datos;
	}

	
}
