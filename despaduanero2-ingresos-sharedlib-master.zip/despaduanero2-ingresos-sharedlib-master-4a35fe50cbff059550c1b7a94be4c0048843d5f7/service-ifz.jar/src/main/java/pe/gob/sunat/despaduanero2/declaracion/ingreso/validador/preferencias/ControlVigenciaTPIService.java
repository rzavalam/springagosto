package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * Representa la interface del servicio de control de vigencias realizadas a un determinado tratado preferencial internacional (tpi).
 * Creado para el proyecto msnade236_1. 
 * @author Gerardo David L�zaro Ramos
 * @email glazaror@sunat.gob.pe
 */
public interface ControlVigenciaTPIService {
	
	/**
     * Se encarga de obtener el valor de la variable de control de vigencia requerida. Se sugiere tener inializado "variablesIngreso" para ejecutar
     * de manera optima las validaciones.
     * @param codigoConvenio Codigo del convenio
     * @param tipoCertificado Codigo del tipo de certificado de origen
     * @param codigoVariable Codigo de variable de control de vigencia
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return fecha variable de control de vigencia transformado en java.util.Date
     **/
	public Date getVariableDate(String codigoConvenio, String tipoCertificado, String codigoVariable, Map<String, Object> variablesIngreso);
	
	/**
     * Se encarga de verificar si se debe aplicar la validacion de vigencia del tipo de certificado.
     * @param serie serie que se esta evaluando
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que se debe aplicar la validacion de vigencia, false de lo contrario
     **/
	public boolean isValidacionVigenciaAplicable(DatoSerie serie, Map<String, Object> variablesIngreso);
	
	/**
     * Se encarga de determinar si es que se esta rectificando el tpi de la serie especificada.
     * @param serie Serie que se esta adicionando o rectificando
     * @param variablesIngreso Variables de validacion de un determinado proceso. Aqui debe existir la variable "declaracionBDParaValidacionTLC", caso contario no se realiza la evaluacion y se retorna false
     * @return true si es que se trata de una nueva serie o se esta rectificando tpi o fecha de certificado de origen, false de lo contrario
     **/
	public boolean isRectificacionTPI (DatoSerie serie, Map<String, Object> variablesIngreso);
	
	/**
     * Se encarga de determinar si es que se esta rectificando el tpi de la serie especificada.
     * @param serie Serie que se esta adicionando o rectificando
     * @param declaracionBD declaracion de base de datos
     * @return true si es que se trata de una nueva serie o se esta rectificando tpi o fecha de certificado de origen, false de lo contrario
     **/
	public boolean isRectificacionTPI (DatoSerie serie, Declaracion declaracionBD);
	
	/**
     * Se encarga de verificar si es que el tpi y tipo de certificado especificados tienen configurado el control de vigencias
     * @param serie Serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el tpi/tipo certificado tienen configurado el nuevo control de vigencias, false de lo contrario.
     **/
	public boolean hasConfiguracionControlVigencia(DatoSerie serie, Map<String, Object> variablesIngreso);
	
	/**
     * Se encarga de ejecutar el control de vigencias en base al tipo de certificado y tpi.
     * El control de vigencia se realiza sobre la fecha del certificado de origen y la fecha actual.  
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @param serie Serie que se esta adicionando o rectificando
     * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
     * @param codigoServicio codigo del servicio de validacion de negocio que actualmente se esta ejecutando y el cual es sometido al control de vigencia
     * @return true si es que el servicio identificado por codigoServicio debe continuar su ejecucion, false de lo contrario
     **/
	public boolean isServicioVigente(Map<String, Object> variablesIngreso, DatoSerie serie, Date fechaReferencia, String codigoServicio);
	
	/**
     * Obtiene la fecha de referencia para determinar la vigencia del servicio ejecutado actualmente.
     * @param codigoTPI Codigo de convenio asociado a la serie evaluada
     * @param serie serie que se esta evaluando
     * @param fechaReferencia fecha de referencia usado en las validaciones TLC
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return fecha actual: si es que se esta modificando TPI o tipo de certificado o fecha de certificado, de lo contrario se retorna la fecha de numeracion.
     **/
	public Date getFechaReferenciaControl(String codigoTPI, DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
}
