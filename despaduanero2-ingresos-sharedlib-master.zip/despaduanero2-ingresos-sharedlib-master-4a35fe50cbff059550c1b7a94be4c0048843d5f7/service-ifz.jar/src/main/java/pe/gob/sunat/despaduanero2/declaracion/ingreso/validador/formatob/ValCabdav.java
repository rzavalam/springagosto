package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;

public interface ValCabdav  {
	public Map<String, String> numsecuprov(Declaracion declaracion);
	public List<Map<String, String>> codproveedor(DAV dav);
	public Map<String, String> codnivcomer(DAV dav);
	public Map<String, String> codnatutrans(DAV dav);
	public Map<String, String> codformenvio(DAV dav);
	public Map<String, String> numenvio(DAV dav) ;
	public Map<String, String> indexisinter(DAV dav);
	public Map<String, String> cntfacturas(DAV dav) ;	
	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos
	 */
	public Map<String, String> codcondprov(DAV dav);
	/**
	 * Validar en funcion del Catalogo, la calse debe heredar las funciones del
	 * Modelo de catalogos
	 */
	public Map<String, String> codtipinter(DAV dav);
	
	/** Verificar que se envie un texto de longitud mayor de 3 caracteres */
	public Map<String, String> nomcargdecla(String arg);
        public List<Map<String, String>> validarDiferenciaAjustesFormatoBconA(Declaracion declaracion);
        public Map<String, String> validarDiferenciaAjustesFormatoBconItems(DAV dav); 	
        public Map<String, String> validarIncotermUnicoXFactura(DAV dav);
        public List<Map<String, String>> validarDiferenciaFOBYAjustesItemsProveedor(DAV dav);
        /**
	 * Valida si la cantidad de facturas en indicadas corresponde a la lista de facturas enviadas
	 * @param dav
	 * @return
	 */
	public Map<String, String> valgralfb3(DAV dav);
	/**
	 * Realiza la validacion del envio del formato B
	 * @param declaracion
	 * @return
	 */
        public List<Map<String,?>> validarEnviosFormatoB(Declaracion declaracion, Date fechaReferencia); 
	/**
	 * Validacion envio complementario de Formato B
	 * Valida que la declaracion de referncia exista en la base de datos.
	 * @param declaracion
	 * @return
	 */
	public List<java.util.Map<String, String>> validarDeclaracionExista(Declaracion declaracion);
	public List<Map<String, String>> validarAnnNumOrden(Declaracion declaracion, String numOrden);
	/**
	 * Validacion envio complementario de Formato B
	 * Verificar que la declaraci�n no este legajada (cab_declara.cod_estdua='por definir'),
     * de estarlo se genera el error 0332
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> validarEstadoLegajado(Declaracion declaracion);
	/**
	 * Validacion envio complementario de Formato B
	 * Verificar que las series enviadas por cada item del formato de valor (DatoSerieItem.numserie) 
     * correspondan a la totalidad de series de datos generales (cab_declar.cnt_totseries), 
     * sino se genera el error 0343
	 * @param declaracion
	 * @return
	 */
	public Map<String, String> validarSeriesEnviadas(Declaracion declaracion);

        public List<Map<String, String>> verificarTieneFormatoBRegistrado(
		Declaracion declaracion);
	
	/**
	 * Validacion envio complementario de Formato B
	 * Verificar que el c�digo del agente sea el mismo al declarado en la numeraci�n,
     * sino se genera el error 0337 
	 * @param declaracion
	 * @param numeroDocumentoIdentidadSender
	 * @param tipoDocumentoIdentidadSender
	 * @return
	 */
	public List<Map<String, String>> validarCodigoAgente(Declaracion declaracion,String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String tipoSender);
	
	public List<Map<String, String>> validarProveedor(Participante proveedor, DAV dav);
	public List<Map<String, String>> validarProveedorLocal(DAV dav);
    public List<Map<String, String>> validarVentasSucesivas(DAV dav); 
	public List<Map<String, String>> validarIntermediario(DAV dav);
    public Declaracion importadorTieneOtraDuaConFormatoBDiferido(String numeroDocumentoImportador, String tipoDocumentoImportador, Date fechaReferencia);
	public List<Map<String, String>> validarPersonaDecl(DAV dav);
    public boolean tieneEnvioFormatoBExonerado(DUA dua, Date fechaReferencia);
	public Map<String, Object> setupDAV(DAV dav);
    public List<Map<String, String>> validarPersonaDeclFormatoB (Participante personaDecl,Declaracion declaracion,String codTransaccion);
    public boolean tieneEnvioFormatoBDiferido(DUA dua); 
    public List<Map<String, String>> debeEnviarFormatoBObligatorio(Declaracion declaracion, Date fechaReferencia);
    public Integer esAutoUsado(DUA dua);
    public boolean esAutoUsado(DatoSerie serie);
    public boolean esProductoUsado(String codEstadoMercaderia);
    public boolean esPartidaVehiculo(Long numeroPartida);
    public Map<String, String> sonValoresDefinitivos(DatoMontoProv datoMontoProv);
    public boolean esDuaAnticipadaConGarantia160(DUA dua);
    public boolean esDuaAnticipadaEImportadorFrecuente(DUA dua);
    public List<Map<String,String>> validarDeterminacionValorTransaccion(DAV dav);
    public List<Map<String, String>> validarAutoUsadoRegimenPrecedente(DatoSerie serie);
    public List<Map<String, String>> validarNoEnviaFBPrimeraVez (Declaracion declaracion, Map<String,Object> variablesIngreso );
    public List<Map<String, String>> verificarCondicionesEnvioDiferido (Declaracion declaracion, Map<String,Object> variablesIngreso);
    public List<Map<String, String>> verificarCondicionesEnvioExonerado (Declaracion declaracion , Date fechaReferencia, Map<String,Object> variablesIngreso );
    public List<Map<String, String>> validarNoEnviaVehiUsados(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public List<Map<String, String>> validarPuedeRectificarFA(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public List<Map<String, String>> validarEnvioFBRegu(Declaracion declaracion);
    //gg7 - dua can
	List<Map<String, String>> validarResolucion(DAV dav, Date fechaReferencia);
	List<Map<String, String>> validarMedioPago(DAV dav, Date fechaReferencia);
	List<Map<String, String>> validarMedioPago (DAV dav, Date fechaReferencia, Declaracion declaracion);
	Map<String, String> validarRepresentateLegal(DAV dav);
	Map<String, String> codTipInterOtros(DAV dav);
	Map<String, String> codNatuTransOtros(DAV dav);
	Map<String, String> codCondProvOtros(DAV dav);
	Map<String, String> codNivComerOtros(DAV dav);
          
}
