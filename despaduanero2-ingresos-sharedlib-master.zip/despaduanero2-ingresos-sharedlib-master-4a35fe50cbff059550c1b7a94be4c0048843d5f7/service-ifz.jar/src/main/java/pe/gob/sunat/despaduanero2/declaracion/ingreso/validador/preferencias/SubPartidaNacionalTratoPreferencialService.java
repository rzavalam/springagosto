package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.AladLibe;
import pe.gob.sunat.despaduanero2.declaracion.model.CatRefPartida;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface SubPartidaNacionalTratoPreferencialService {

	public Map<String, String> validarSubPartidaMotoresPiezasUsados(DatoSerie serie, Date fechaReferencia);
	
	public Map<String, String> validarSubPartidaMotoresPiezasExoneradas(String numSerie, String numpartnandi, Date fechaReferencia);
	
	/**
	 * validacion de Derecho Correctivo Provisional, para subpartida nacional relacionadas con Mantecas
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> validarSubPartidaManteca (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Consulta por partidas referenciales
	 * @param numeparti
	 * @param codConvenio
	 * @param fechaReferencia
	 * @param tipoRef
	 * @return
	 */
	//public List<CatRefPartida> consultarPartidasReferenciales(String numeparti,  String codConvenio, Date fechaReferencia, String tipoRef);

	/**
	 * Consulta de si la partida forma parte de todo el arancel para el aladlibe
	 * @param serie
	 * @param fechaReferencia
	 * @return
	 */
	public List<AladLibe> validaVigenciaSubPartidaTodoArancel(DatoSerie serie,  Date fechaReferencia);
	
	//glazaror... metodo optimizado
	public Map<String, String> validarSubPartidaMotoresPiezasUsados(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	//glazaror... metodo optimizado
	public Map<String, String> validarSubPartidaMotoresPiezasExoneradas(String numSerie, String numpartnandi, Date fechaReferencia, Map<String, Object> variablesIngreso);

}
