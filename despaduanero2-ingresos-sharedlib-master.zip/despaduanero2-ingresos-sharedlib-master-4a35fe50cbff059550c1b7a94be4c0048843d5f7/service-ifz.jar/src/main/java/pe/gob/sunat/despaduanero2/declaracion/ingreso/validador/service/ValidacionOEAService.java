package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValidacionOEAService {
	 //PAS20181U220200022
    public boolean esOperadorCertificado(String numRucOperador, String tipoOperador, Date fechaReferencia);
    public boolean existeOperador(String numRucOperador, String tipoOperador);
    public boolean esInvitadoOEARegistradoOVigente(String numRucInvitado, Date fechaReferencia);
	public boolean damTieneContingente(Declaracion declaracion);			 	
	public String validarCondicionesInvitado(String nume_docum, Declaracion declaracion, Date fechaReferencia, boolean esGarEmpresaOea, boolean tieneDeudaAsociadaPdte); 
	
	public String[] entidadesGarantesAceptadas ( Date fechaReferencia, boolean recienSeAcogeGarantia);		
	public boolean esEntidadGaranteAutorizada (String numRucBeneficiario, String numctacte, Date fechaReferencia, String[] entidadGarante);

	public List<Map<String,String>> validarGarNominalIncumplimiento(Declaracion declaracion, Date fechaReferencia);
	public List<Map<String,String>> validarGarNominalIncumplimientoRecti(Declaracion declaracion, Declaracion declaracionBD, Date fechaReferencia, String codTransaccion);
	public List<Map<String, String>> validarGarNominalIncumplimientoPorParametros(Date fechaReferencia, boolean recienSeAcogeGarantia, String numRucBeneficiarioEval, String numCtacteEval, 
			String codTransaccion , Long numcorredoc, String codregimen);	
	
	public List<Map<String,String>> validarGarantiaNominal(Declaracion declaracion, Date fechaReferencia);
}
