package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;

public class PackageGetManif {

	public static String validaViaTrans(String punitra, String paduana, Date pfechavig){
		return null;
	}
	
	public static String getViaTrans(String punitra, String paduana, String pcoditerm){
		return null;
	}
	
	public static String getTipo(String punitra, String pcoditerm, String xaduana){
		return null;
	}
}
