package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarDeclaracionService {

	public Map<String, String> grabarNumeracion(Map<String, Object> variablesIngreso) throws Exception;
	
	public Map<String, String> grabarEnvioComplementario(Map<String, Object> variablesIngreso);
	
	public void afectarCtaCteVehiculosUsados(Declaracion declaracion, String IndAfectaDesafecta) throws Exception;
	
	public void afectarCtaCteRegPrecedeDeposito(Declaracion declaracion, String indAfectaDesafectaRegPreDepo, String numeroDocumentoIdentidadSender);	

	public void desafectarCtaCteRegPrecedeDeposito(Map<String,Object> params);
	public void grabarIndicadorPlazoNumeracion(Declaracion declaracion, long numcorredoc);
	public void grabarIndicadorPlazoNumeracion(Declaracion declaracion, long numcorredoc,String transaccion);
	public Map<String, Object> grabarNumeracionMaterialGuerra(Map<String, Object> mapCabDeclara);
	public Map<String, Object> grabarNumeracionRegimenesEspeciales (Declaracion declaracion);

}