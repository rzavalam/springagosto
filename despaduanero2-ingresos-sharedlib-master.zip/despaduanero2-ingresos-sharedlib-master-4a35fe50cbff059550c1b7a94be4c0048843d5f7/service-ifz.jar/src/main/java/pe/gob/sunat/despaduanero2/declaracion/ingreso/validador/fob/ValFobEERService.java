package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.fob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValFobEERService {
	public List<Map<String,String>> valMontoFobCategoria02(DUA dua, String codCategoria);
	public List<Map<String,String>> valMontoFobCategoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries);
}
