package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

public class PackageRucDni {
	
	private static DdpDAOService ddpDAOService;

	@SuppressWarnings("unchecked")
	public static String getFlag22(String numeroDocumento) {
		//SELECT "ddp_flag22" INTO lcresp FROM ddp WHERE "ddp_numruc" = tcnumdocs
		if(!SunatStringUtils.isEmptyTrim(numeroDocumento)){
//			Map mapDdp = FormatoBServiceImpl.getInstance().getDdpDAO().findByPK(numeroDocumento);
			Map mapDdp = ddpDAOService.findByPK(numeroDocumento);
			return mapDdp!=null?(String)mapDdp.get("ddp_flag22"):"";
		}
		else
			 return "";
	}
	
	@SuppressWarnings("unchecked")
	public static String getEstadoRuc(String numeroDocumento) {
		//SELECT "ddp_estado" INTO lcresp FROM ddp WHERE "ddp_numruc" = tcnumdoc
		if(!SunatStringUtils.isEmptyTrim(numeroDocumento)){
//			Map mapDdp = FormatoBServiceImpl.getInstance().getDdpDAO().findByPK(numeroDocumento);
			Map mapDdp = ddpDAOService.findByPK(numeroDocumento);
			return mapDdp!=null?(String)mapDdp.get("ddp_estado"):"";
		} 
		else return "";
	}
	
	public static Map<String,Object> getDatosPrinRUC(String numruc){
//		return SunatStringUtils.isEmptyTrim(numruc)?null:FormatoAServiceImpl.getInstance().getDdpDAO().findByPK(numruc);
		return SunatStringUtils.isEmptyTrim(numruc)?null:ddpDAOService.findByPK(numruc);
		//TODO formar direccion
	}

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
}
