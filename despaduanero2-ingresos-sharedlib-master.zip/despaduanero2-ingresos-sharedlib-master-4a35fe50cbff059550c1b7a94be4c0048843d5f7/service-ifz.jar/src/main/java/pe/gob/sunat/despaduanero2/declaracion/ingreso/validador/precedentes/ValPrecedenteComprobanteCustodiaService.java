package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero.despacho.entrada.cc.model.CabRetencion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ValPrecedenteComprobanteCustodiaService {

	public List<Map<String, String>> validaComprobanteCustodia(Declaracion declaracion,String puntoDeLlegada,List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia);

}
