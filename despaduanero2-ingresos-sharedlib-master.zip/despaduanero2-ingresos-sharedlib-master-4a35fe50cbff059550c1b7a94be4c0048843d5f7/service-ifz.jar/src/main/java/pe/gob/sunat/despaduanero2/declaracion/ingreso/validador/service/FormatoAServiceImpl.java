package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import org.springframework.aop.target.HotSwappableTargetSource;
//import org.springframework.context.ApplicationContext;

import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.DipolizaiDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.EstabnoaptoDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.SeriesdDAO;
import pe.gob.sunat.despaduanero.despacho.especial.ct.model.dao.TrasladoCeticoDAO;
import pe.gob.sunat.despaduanero.despacho.especial.ct.model.dao.TrasladoSeriesCeticoDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.CatRefpartidasDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdualibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdulibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Aladi504DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AladlibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabImportFrecDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Cambio1DAO;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatparSenasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CodilibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContCtaCteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContPeriodoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContValidDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContingenteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContplazoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Correl9298DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CtaCtePerNatDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupolibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupotpiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DecantiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeclaranDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DirectoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DitabltasDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DuaRegPreDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExCodLibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExNanLibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExpediDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExpodumpDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IscfactoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IscvalorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MaxaplDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MrestriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NabandinDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandUniDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Nandi110DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandlibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OpeComExtDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OrilibeDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.PolizadDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.PolizadDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PrupersoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RaDirecDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ResSpimDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabLibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TablNewDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TasadumpDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TdmalconDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TriblibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.AutorizacionZonaPrimariaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.genadeudo.service.ConsultaLiquidacionService;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionPerfecService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionReexpService;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.OperadorComexDAO;


@Deprecated
public class FormatoAServiceImpl {

	private static FormatoAServiceImpl instance;
	//private ApplicationContext appContext= null;
	private GrabarFormatoAService grabarFormatoAService; 
	
	CatalogoHelperImpl catalogoValidacionService;
	AutorizacionZonaPrimariaService autorizacionZonaPrimariaService;
	ConsultaLiquidacionService consultaLiquidacionService;
	GetDeclaracionService getDeclaracionService;
	ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService;
	ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService;
	ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService;
	ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService;

	ManifiestoService manifiestoService;
	DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService;
	McdetaDAO  mcdetaDAO;
	ManifiestoSigadService manifiestoSigadService;
	
	public ManifiestoSigadService getManifiestoSigadService() {
		return manifiestoSigadService;
	}

	public void setManifiestoSigadService(
			ManifiestoSigadService manifiestoSigadService) {
		this.manifiestoSigadService = manifiestoSigadService;
	}
	
	public McdetaDAO getMcdetaDAO() {
		return mcdetaDAO;
	}

	public void setMcdetaDAO(McdetaDAO mcdetaDAO) {
		this.mcdetaDAO = mcdetaDAO;
	}
	
	//DAO de consulta de datos
	private TriblibeDAO triblibeDAO;
	private RaDirecDAO radirecDAO;	
//	private NandUniDAO nanduniDAO;
	private NandTasaDAO nandtasaDAO;
	private NabandinDAO nabandinDAO;
	private IscfactoDAO iscfactoDAO;
	private IscvalorDAO iscvalorDAO;
//	private CatRefpartidasDAO catrefpartidasDAO;
	private TasadumpDAO tasadumpDAO;
	private ExpodumpDAO expodumpDAO;
	private CodilibeDAO codilibeDAO;
	private TabLibeDAO tablibeDAO;
	private OrilibeDAO orilibeDAO;
	private ExCodLibDAO excodlibDAO;
	private NandlibeDAO nandlibeDAO;
	private Nandi110DAO nandi110DAO;
	private ExNanLibDAO exnanlibDAO;
	private Aladi504DAO aladi504DAO;
	private AladlibeDAO aladLibeDAO;
	private CupotpiDAO cupoTpiDAO;
	private AdulibeDAO adulibeDAO;
	private AdualibDAO adualibDAO;

	private DeclaranDAO declaranDAO;
	private CabManifiestoDAO manifiestoDAO;
	private DocuTransDAO docuTransDAO;
	private CabImportFrecDAO cabimportfrecDAO;

	private OpeComExtDAO opecomextDAO;
	private DirectoDAO directoDAO;
	private AladlibeDAO aladlibeDAO;
//	private Cambio1DAO cambio1DAO;
	private CatRefRucDAO catRefRucDAO;
	private CatRefRucDAO catRefRucCentralizadaDAO;
	private ExpediDAO expediDAO;
    private CupolibeDAO cupolibeDAO;
    private ResSpimDAO resspimDAO;

    private CtaCtePerNatDAO ctaCtePerNatDAO;
    
    //20091103
    private MrestriDAO mrestriDAO;
    private CatparSenasaDAO catparSenasaDAO;
    private CabDeclaraDAO cabDeclaraDAO;
    private DitabltasDAO ditabltasDAO;
    private TdmalconDAO tdmalconDAO;
    private DecantiDAO decantiDAO;
    private OpecomextDAO opecomextDao;
    
    //
    private MaxaplDAO maxaplDAO;
	private DdpDAO ddpDAO;
	
	private ParticipanteDocDAO participanteDAO;
	private TablNewDAO tablNewDAO;
	
	private ContingenteDAO contingenteDAO;
	private ContValidDAO contValidDAO;
	private ContplazoDAO contPlazoDAO;
	private PrupersoDAO prupersoDAO;
	private TrasladoCeticoDAO trasladoCeticoDAO;
	private TrasladoSeriesCeticoDAO trasladoSeriesCeticoDAO;
	private EstabnoaptoDAO estabnoaptoDAO;
	//private DocuTransDAO docuTransDAO;
	private DetAutorizacionDAO detAutorizacionDAO;
	private OperadorValidaService operadorValidaService;
	private ProveedorFuncionesService funcionesService;
	
	private PolizadDAO polizadDAO;
	private SeriesdDAO seriesdDAO;
	private DepoctaDAO depoctaDAO;
	
	private DipolizaiDAO dipolizaiDAO;	
	
	/*
	 * RC: Validacion de contingentes
	 */
	private ContCtaCteDAO contCtaCteDAO; 
	private ContPeriodoDAO contPeriodoDAO;
	
	private DetDeclaraDAO detDeclaraDAO;
	private CabDiligenciaDAO cabDiligenciaDAO;
	
	private DuaRegPreDAO duaRegPreDAO;
	private Correl9298DAO correl9298DAO;
	
	private FabricaDeServicios fabricaDeServicios;
	private HotSwappableTargetSource swapperDatasource;
	
	//PAS20144E620000100 cpuente
	private OperadorComexDAO operadorComexDAO;
	
	
    public DuaRegPreDAO getDuaRegPreDAO() {
		return duaRegPreDAO;
	}

	public void setDuaRegPreDAO(DuaRegPreDAO duaRegPreDAO) {
		this.duaRegPreDAO = duaRegPreDAO;
	}
	
    public CupolibeDAO getCupolibeDAO() {
		return cupolibeDAO;
	}

	public void setCupolibeDAO(CupolibeDAO cupolibeDAO) {
		this.cupolibeDAO = cupolibeDAO;
	}

	private FormatoAServiceImpl() {
	}
	
	public static FormatoAServiceImpl getInstance() {
		if(instance == null )
		{
			instance = new FormatoAServiceImpl();		
		}
		
		return instance;
	}
	
	
	public boolean isValidCatalogo(String tipoCatalogo, String codigo){
		return catalogoValidacionService.isValid(codigo, tipoCatalogo);
	}

	public GrabarFormatoAService getGrabarFormatoAService() {
		return grabarFormatoAService;
	}

	public void setGrabarFormatoAService(GrabarFormatoAService grabarFormatoAService) {
		this.grabarFormatoAService = grabarFormatoAService;
	}

	public TriblibeDAO getTriblibeDAO() {
		return triblibeDAO;
	}

	public void setTriblibeDAO(TriblibeDAO triblibeDAO) {
		this.triblibeDAO = triblibeDAO;
	}

	public RaDirecDAO getRadirecDAO() {
		return radirecDAO;
	}

	public void setRadirecDAO(RaDirecDAO radirecDAO) {
		this.radirecDAO = radirecDAO;
	}

//	public NandUniDAO getNanduniDAO() {
//		return nanduniDAO;
//	}
//
//	public void setNanduniDAO(NandUniDAO nanduniDAO) {
//		this.nanduniDAO = nanduniDAO;
//	}

	public NandTasaDAO getNandtasaDAO() {
		return nandtasaDAO;
	}

	public void setNandtasaDAO(NandTasaDAO nandtasaDAO) {
		this.nandtasaDAO = nandtasaDAO;
	}

	public IscfactoDAO getIscfactoDAO() {
		return iscfactoDAO;
	}

	public void setIscfactoDAO(IscfactoDAO iscfactoDAO) {
		this.iscfactoDAO = iscfactoDAO;
	}

	public IscvalorDAO getIscvalorDAO() {
		return iscvalorDAO;
	}

	public void setIscvalorDAO(IscvalorDAO iscvalorDAO) {
		this.iscvalorDAO = iscvalorDAO;
	}



//	public CatRefpartidasDAO getCatrefpartidasDAO() {
//		return catrefpartidasDAO;
//	}
//
//	public void setCatrefpartidasDAO(CatRefpartidasDAO catrefpartidasDAO) {
//		this.catrefpartidasDAO = catrefpartidasDAO;
//	}

	public TasadumpDAO getTasadumpDAO() {
		return tasadumpDAO;
	}

	public void setTasadumpDAO(TasadumpDAO tasadumpDAO) {
		this.tasadumpDAO = tasadumpDAO;
	}

	public ExpodumpDAO getExpodumpDAO() {
		return expodumpDAO;
	}

	public void setExpodumpDAO(ExpodumpDAO expodumpDAO) {
		this.expodumpDAO = expodumpDAO;
	}

	public CodilibeDAO getCodilibeDAO() {
		return codilibeDAO;
	}

	public void setCodilibeDAO(CodilibeDAO codilibeDAO) {
		this.codilibeDAO = codilibeDAO;
	}

	public CatalogoHelperImpl getCatalogoValidacionService() {
		return catalogoValidacionService;
	}

	public void setCatalogoValidacionService(
			CatalogoHelperImpl catalogoValidacionService) {
		this.catalogoValidacionService = catalogoValidacionService;
	}

	public OpeComExtDAO getOpecomextDAO() {
		return opecomextDAO;
	}

	public void setOpecomextDAO(OpeComExtDAO opecomextDAO) {
		this.opecomextDAO = opecomextDAO;
	}

	public DirectoDAO getDirectoDAO() {
		return directoDAO;
	}

	public void setDirectoDAO(DirectoDAO directoDAO) {
		this.directoDAO = directoDAO;
	}

	public AladlibeDAO getAladlibeDAO() {
		return aladlibeDAO;
	}

	public void setAladlibeDAO(AladlibeDAO aladlibeDAO) {
		this.aladlibeDAO = aladlibeDAO;
	}

	public Aladi504DAO getAladi504DAO() {
		return aladi504DAO;
	}

	public void setAladi504DAO(Aladi504DAO aladi504DAO) {
		this.aladi504DAO = aladi504DAO;
	}

//	public Cambio1DAO getCambio1DAO() {
//		return cambio1DAO;
//	}
//
//	public void setCambio1DAO(Cambio1DAO cambio1DAO) {
//		this.cambio1DAO = cambio1DAO;
//	}

	public CatRefRucDAO getCatRefRucDAO() {
		return catRefRucDAO;
	}

	public void setCatRefRucDAO(CatRefRucDAO catRefRucDAO) {
		this.catRefRucDAO = catRefRucDAO;
	}

	public ExpediDAO getExpediDAO() {
		return expediDAO;
	}

	public void setExpediDAO(ExpediDAO expediDAO) {
		this.expediDAO = expediDAO;
	}

	public TabLibeDAO getTablibeDAO() {
		return tablibeDAO;
	}

	public void setTablibeDAO(TabLibeDAO tablibeDAO) {
		this.tablibeDAO = tablibeDAO;
	}

	public OrilibeDAO getOrilibeDAO() {
		return orilibeDAO;
	}

	public void setOrilibeDAO(OrilibeDAO orilibeDAO) {
		this.orilibeDAO = orilibeDAO;
	}

	public ExCodLibDAO getExcodlibDAO() {
		return excodlibDAO;
	}

	public void setExcodlibDAO(ExCodLibDAO excodlibDAO) {
		this.excodlibDAO = excodlibDAO;
	}

	public NandlibeDAO getNandlibeDAO() {
		return nandlibeDAO;
	}

	public void setNandlibeDAO(NandlibeDAO nandlibeDAO) {
		this.nandlibeDAO = nandlibeDAO;
	}

	public Nandi110DAO getNandi110DAO() {
		return nandi110DAO;
	}

	public void setNandi110DAO(Nandi110DAO nandi110DAO) {
		this.nandi110DAO = nandi110DAO;
	}

	public ExNanLibDAO getExnanlibDAO() {
		return exnanlibDAO;
	}

	public void setExnanlibDAO(ExNanLibDAO exnanlibDAO) {
		this.exnanlibDAO = exnanlibDAO;
	}

	public AladlibeDAO getAladLibeDAO() {
		return aladLibeDAO;
	}

	public void setAladLibeDAO(AladlibeDAO aladLibeDAO) {
		this.aladLibeDAO = aladLibeDAO;
	}

	public CupotpiDAO getCupoTpiDAO() {
		return cupoTpiDAO;
	}

	public void setCupoTpiDAO(CupotpiDAO cupoTpiDAO) {
		this.cupoTpiDAO = cupoTpiDAO;
	}

	public AdulibeDAO getAdulibeDAO() {
		return adulibeDAO;
	}

	public void setAdulibeDAO(AdulibeDAO adulibeDAO) {
		this.adulibeDAO = adulibeDAO;
	}

	public AdualibDAO getAdualibDAO() {
		return adualibDAO;
	}

	public void setAdualibDAO(AdualibDAO adualibDAO) {
		this.adualibDAO = adualibDAO;
	}

	public DeclaranDAO getDeclaranDAO() {
		return declaranDAO;
	}

	public void setDeclaranDAO(DeclaranDAO declaranDAO) {
		this.declaranDAO = declaranDAO;
	}

	public CabManifiestoDAO getManifiestoDAO() {
		return manifiestoDAO;
	}

	public void setManifiestoDAO(CabManifiestoDAO manifiestoDAO) {
		this.manifiestoDAO = manifiestoDAO;
	}

	public CabImportFrecDAO getCabimportfrecDAO() {
		return cabimportfrecDAO;
	}

	public void setCabimportfrecDAO(CabImportFrecDAO cabimportfrecDAO) {
		this.cabimportfrecDAO = cabimportfrecDAO;
	}

	public ResSpimDAO getResspimDAO() {
		return resspimDAO;
	}

	public void setResspimDAO(ResSpimDAO resspimDAO) {
		this.resspimDAO = resspimDAO;
	}

	public CtaCtePerNatDAO getCtaCtePerNatDAO() {
		return ctaCtePerNatDAO;
	}

	public void setCtaCtePerNatDAO(CtaCtePerNatDAO ctaCtePerNatDAO) {
		this.ctaCtePerNatDAO = ctaCtePerNatDAO;
	}

	public MrestriDAO getMrestriDAO() {
		return mrestriDAO;
	}

	public void setMrestriDAO(MrestriDAO mrestriDAO) {
		this.mrestriDAO = mrestriDAO;
	}

	public CatparSenasaDAO getCatparSenasaDAO() {
		return catparSenasaDAO;
	}

	public void setCatparSenasaDAO(CatparSenasaDAO catparSenasaDAO) {
		this.catparSenasaDAO = catparSenasaDAO;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public DitabltasDAO getDitabltasDAO() {
		return ditabltasDAO;
	}

	public void setDitabltasDAO(DitabltasDAO ditabltasDAO) {
		this.ditabltasDAO = ditabltasDAO;
	}

	public TdmalconDAO getTdmalconDAO() {
		return tdmalconDAO;
	}

	public void setTdmalconDAO(TdmalconDAO tdmalconDAO) {
		this.tdmalconDAO = tdmalconDAO;
	}

	public DecantiDAO getDecantiDAO() {
		return decantiDAO;
	}

	public void setDecantiDAO(DecantiDAO decantiDAO) {
		this.decantiDAO = decantiDAO;
	}

	public MaxaplDAO getMaxaplDAO() {
		return maxaplDAO;
	}

	public void setMaxaplDAO(MaxaplDAO maxaplDAO) {
		this.maxaplDAO = maxaplDAO;
	}

	public DdpDAO getDdpDAO() {
		return ddpDAO;
	}

	public void setDdpDAO(DdpDAO ddpDAO) {
		this.ddpDAO = ddpDAO;
	}

	public ParticipanteDocDAO getParticipanteDAO() {
		return participanteDAO;
	}

	public void setParticipanteDAO(ParticipanteDocDAO participanteDAO) {
		this.participanteDAO = participanteDAO;
	}

	public TablNewDAO getTablNewDAO() {
		return tablNewDAO;
	}

	public void setTablNewDAO(TablNewDAO tablNewDAO) {
		this.tablNewDAO = tablNewDAO;
	}

	public ContingenteDAO getContingenteDAO() {
		return contingenteDAO;
	}

	public void setContingenteDAO(ContingenteDAO contingenteDAO) {
		this.contingenteDAO = contingenteDAO;
	}

	public ContValidDAO getContValidDAO() {
		return contValidDAO;
	}

	public void setContValidDAO(ContValidDAO contValidDAO) {
		this.contValidDAO = contValidDAO;
	}

	public ContplazoDAO getContPlazoDAO() {
		return contPlazoDAO;
	}

	public void setContPlazoDAO(ContplazoDAO contPlazoDAO) {
		this.contPlazoDAO = contPlazoDAO;
	}

	public PrupersoDAO getPrupersoDAO() {
		return prupersoDAO;
	}

	public void setPrupersoDAO(PrupersoDAO prupersoDAO) {
		this.prupersoDAO = prupersoDAO;
	}

	public TrasladoSeriesCeticoDAO getTrasladoSeriesCeticoDAO() {
		return trasladoSeriesCeticoDAO;
	}

	public void setTrasladoSeriesCeticoDAO(
			TrasladoSeriesCeticoDAO trasladoSeriesCeticoDAO) {
		this.trasladoSeriesCeticoDAO = trasladoSeriesCeticoDAO;
	}

	public TrasladoCeticoDAO getTrasladoCeticoDAO() {
		return trasladoCeticoDAO;
	}

	public void setTrasladoCeticoDAO(
			TrasladoCeticoDAO trasladoCeticoDAO) {
		this.trasladoCeticoDAO = trasladoCeticoDAO;
	}

	
	public EstabnoaptoDAO getEstabnoaptoDAO() {
		return estabnoaptoDAO;
	}

	public void setEstabnoaptoDAO(EstabnoaptoDAO estabnoaptoDAO) {
		this.estabnoaptoDAO = estabnoaptoDAO;
	}

//	public DocuTransDAO getDocuTransDAO() {
//		return docuTransDAO;
//	}
//
//	public void setDocuTransDAO(DocuTransDAO docuTransDAO) {
//		this.docuTransDAO = docuTransDAO;
//	}

	public OperadorValidaService getOperadorValidaService() {
		return operadorValidaService;
	}

	public void setOperadorValidaService(OperadorValidaService operadorValidaService) {
		this.operadorValidaService = operadorValidaService;
	}

	public ProveedorFuncionesService getFuncionesService() {
		return funcionesService;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public DetAutorizacionDAO getDetAutorizacionDAO() {
		return detAutorizacionDAO;
	}

	public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO) {
		this.detAutorizacionDAO = detAutorizacionDAO;
	}

	public PolizadDAO getPolizadDAO() {
		return polizadDAO;
	}

	public void setPolizadDAO(PolizadDAO polizadDAO) {
		this.polizadDAO = polizadDAO;
	}

	public SeriesdDAO getSeriesdDAO() {
		return seriesdDAO;
	}

	public void setSeriesdDAO(SeriesdDAO seriesdDAO) {
		this.seriesdDAO = seriesdDAO;
	}

	public DepoctaDAO getDepoctaDAO() {
		return depoctaDAO;
	}

	public void setDepoctaDAO(DepoctaDAO depoctaDAO) {
		this.depoctaDAO = depoctaDAO;
	}

	public DipolizaiDAO getDipolizaiDAO() {
		return dipolizaiDAO;
	}

	public void setDipolizaiDAO(DipolizaiDAO dipolizaiDAO) {
		this.dipolizaiDAO = dipolizaiDAO;
	}

	public CatRefRucDAO getCatRefRucCentralizadaDAO() {
		return catRefRucCentralizadaDAO;
	}

	public void setCatRefRucCentralizadaDAO(CatRefRucDAO catRefRucCentralizadaDAO) {
		this.catRefRucCentralizadaDAO = catRefRucCentralizadaDAO;
	}

	public DocuTransDAO getDocuTransDAO() {
		return docuTransDAO;
	}
	
	public void setDocuTransDAO(DocuTransDAO docuTransDAO) {
		this.docuTransDAO = docuTransDAO;
	}	

	public ContCtaCteDAO getContCtaCteDAO() {
		return contCtaCteDAO;
	}

	public ContPeriodoDAO getContPeriodoDAO() {
		return contPeriodoDAO;
	}

	public void setContPeriodoDAO(ContPeriodoDAO contPeriodoDAO) {
		this.contPeriodoDAO = contPeriodoDAO;
	}

	public void setContCtaCteDAO(ContCtaCteDAO contCtaCteDAO) {
		this.contCtaCteDAO = contCtaCteDAO;
	}

	public DetDeclaraDAO getDetDeclaraDAO() {
		return detDeclaraDAO;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public CabDiligenciaDAO getCabDiligenciaDAO() {
		return cabDiligenciaDAO;
	}

	public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO) {
		this.cabDiligenciaDAO = cabDiligenciaDAO;
	}	
	public void setNabandinDAO(NabandinDAO nabandinDAO) {
		this.nabandinDAO = nabandinDAO;
	}

	public NabandinDAO getNabandinDAO() {
		return nabandinDAO;
	}	
	public Correl9298DAO getCorrel9298DAO() {
		return correl9298DAO;
	}

	public void setCorrel9298DAO(Correl9298DAO correl9298dao) {
		correl9298DAO = correl9298dao;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public AutorizacionZonaPrimariaService getAutorizacionZonaPrimariaService() {
		return autorizacionZonaPrimariaService;
	}
	
	public OpecomextDAO getOpecomextDao() {
		return opecomextDao;
	}

	public void setAutorizacionZonaPrimariaService(
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService) {
		this.autorizacionZonaPrimariaService = autorizacionZonaPrimariaService;
	}

	public void setOpecomextDao(OpecomextDAO opecomextDao) {
		this.opecomextDao = opecomextDao;
	}


	public ConsultaLiquidacionService getConsultaLiquidacionService() {
		return consultaLiquidacionService;
	}

	public void setConsultaLiquidacionService(
			ConsultaLiquidacionService consultaLiquidacionService) {
		this.consultaLiquidacionService = consultaLiquidacionService;
	}

	public GetDeclaracionService getGetDeclaracionService() {
		return getDeclaracionService;
	}

	public ManifiestoService getManifiestoService() {
		return manifiestoService;
	}

	public void setGetDeclaracionService(GetDeclaracionService getDeclaracionService) {
		this.getDeclaracionService = getDeclaracionService;
	}

	public void setManifiestoService(ManifiestoService manifiestoService) {
		this.manifiestoService = manifiestoService;
	}


	public ConsultaDeclaracionImpoConsumoService getConsultaDeclaracionImpoConsumoService() {
		return consultaDeclaracionImpoConsumoService;
	}

	public ConsultaDeclaracionDepositoAduaneroService getConsultaDeclaracionDepositoAduaneroService() {
		return consultaDeclaracionDepositoAduaneroService;
	}

	public ConsultaDeclaracionImportacionAdmisionReexpService getConsultaDeclaracionImportacionAdmisionReexpService() {
		return consultaDeclaracionImportacionAdmisionReexpService;
	}

	public ConsultaDeclaracionImportacionAdmisionPerfecService getConsultaDeclaracionImportacionAdmisionPerfecService() {
		return consultaDeclaracionImportacionAdmisionPerfecService;
	}

	public DocumentoOAManifiestoValidacionService getDocumentoOAManifiestoValidacionService() {
		return documentoOAManifiestoValidacionService;
	}

	public void setConsultaDeclaracionImpoConsumoService(
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService) {
		this.consultaDeclaracionImpoConsumoService = consultaDeclaracionImpoConsumoService;
	}

	public void setConsultaDeclaracionDepositoAduaneroService(
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService) {
		this.consultaDeclaracionDepositoAduaneroService = consultaDeclaracionDepositoAduaneroService;
	}

	public void setConsultaDeclaracionImportacionAdmisionReexpService(
			ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService) {
		this.consultaDeclaracionImportacionAdmisionReexpService = consultaDeclaracionImportacionAdmisionReexpService;
	}

	public void setConsultaDeclaracionImportacionAdmisionPerfecService(
			ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService) {
		this.consultaDeclaracionImportacionAdmisionPerfecService = consultaDeclaracionImportacionAdmisionPerfecService;
	}

	public void setDocumentoOAManifiestoValidacionService(
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService) {
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
	}

        //INICIO PAS20144E620000100 - cpuente
	public OperadorComexDAO getOperadorComexDAO() {
		return operadorComexDAO;
	}

	public void setOperadorComexDAO(OperadorComexDAO operadorComexDAO) {
		this.operadorComexDAO = operadorComexDAO;
	}
	//FIN
}
