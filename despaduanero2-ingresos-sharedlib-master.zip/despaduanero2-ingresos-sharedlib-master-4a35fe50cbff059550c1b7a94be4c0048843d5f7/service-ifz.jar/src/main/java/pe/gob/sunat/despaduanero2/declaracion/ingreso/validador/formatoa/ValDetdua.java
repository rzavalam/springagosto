/*
 * Clase que define el servicio de validaciones de las series
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValDetdua. Clase que define el servicio de validaciones de las series
 */
public interface ValDetdua {

	public Map<String, String> numserie(Elementos<DatoSerie> listSeries);
	
	public Map<String, String> codunicomer(String codunicomer);
	
	public Map<String, String> cntunicomer(BigDecimal cntunicomer);
	
	public Map<String, String> codclasbul(String codclasbul);
	
	public Map<String, String> cntbultos(BigDecimal cntbultos);
	
	public Map<String, String> cntpesoneto(BigDecimal cntpesoneto, Integer numserie);
	
	public Map<String, String> cntpesobruto(BigDecimal cntpesobruto, BigDecimal cntpesoneto, Integer numserie);
	
	public Map<String, String> cntpesovehic(BigDecimal cntpesovehic);
	
	public Map<String, String> codunifis(String codunifis);
	
	public Map<String, String> cntunifis(BigDecimal cntunifis);
	
	public Map<String, String> codunicomisc(String codunicomisc);
	
	public Map<String, String> cntunicomisc(BigDecimal cntunicomisc);
	
	public Map<String, String> numpartnandi(Long numpartnandi);
	
	public Map<String, String> numpartnalad(String numpartnalad);
	
	public Map<String, String> validarNumPartNalad(String numpartnalad,String codTransaccion);
	
	public Map<String, String> numpartnaban(String numpartnaban);
	
	public Map<String, String> numpartcorre(String numpartcorre);
	
	public Map<String, String> codconvinter(Integer codconvinter);
	
	public Map<String, String> codtratprefe(Integer codtratprefe);
	
	public Map<String, String> codpaisorige(String codpaisorige);
	
	public Map<String, String> codpaisadqui(String codpaisadqui);
	
	public Map<String, String> codpaisdestino(String codpaisdestino);
	
	public Map<String, String> codmoneda(String codmoneda);
	
	public Map<String, String> mtofobmon(BigDecimal mtofobmon);
	
	public Map<String, String> mtofobdol(BigDecimal mtofobdol);
	
	public Map<String, String> mtofledol(BigDecimal mtofledol);
	
	public Map<String, String> mtosegdol(BigDecimal mtosegdol);
	
	public Map<String, String> mtoajuste(BigDecimal mtoajuste);
	
	public Map<String, String> mtovaladuana(BigDecimal mtovaladuana);
	
	public Map<String, String> codtiposeg(String codtiposeg);
	
	public Map<String, String> codtipoflete(String codtipoflete);
	
	public Map<String, String> descomercial(String descomercial);
	
	public Map<String, String> desformapres(String desformapres);
	
	public Map<String, String> desmatecomp(String desmatecomp);
	
	public Map<String, String> desusoaplica(String desusoaplica);

	public Map<String, String> desotros(String desotros);
	
	public Map<String, String> codestamerca(String codestamerca);
	
	public Map<String, String> codcuota(String codcuota);
	
	public Map<String, String> codubigeo(String codubigeo);
	
	public Map<String, String> fecexpiracion(Date fecexpiracion);
	
	public Map<String, String> codtnan(String codtnan);
	
	public Map<String, String> codtipomarge(String codtipomarge);
	
	public Map<String, String> codliberatorio(Integer codliberatorio);
	
	public Map<String, String> valindcodlib(String valindcodlib);
	
	public Map<String, String> deslugar(String deslugar);
	
	public Map<String, String> valpreciovta(BigDecimal valpreciovta);
	
	public Map<String, String> valestimado(BigDecimal valestimado);
	
	public Map<String, String> mtofobnet(BigDecimal mtofobnet);
	
	public Map<String, String> codvalajuste(String codvalajuste);
	
	public Map<String, String> indzonafranca(String indzonafranca);
	
	public Map<String, String> deszonafranca(String deszonafranca);

    public Map<String, String> codaplultra(DatoSerie serie);       
    public Map<String, String> valCantDocuTrans(DatoSerie serie);
    public Map<String, String> valCodTipoFleteDocutrans(Declaracion declaracion);
    public Map<String, String> valPartidaEER(DatoSerie serie);
    public Map<String, String> valCodiLiberEER (DatoSerie serie);
    public Map<String, String> valCodiLiberPostal (DatoSerie serie);
    	
    public Map<String, String> validarDisposicionTotalPorSerie(Declaracion declaracionBD,DatoSerie datoSerie);
	Map<String, String> codRegion(DatoSerie serie, Date fechaReferencia);

    	
}
