package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValDescMin {
	
	public Map<String, String> codtipdescri(DatoDescrMinima datoDescrMinima);
	//rtineo mejoras,
	public Map<String, String> codtipdescri(DatoDescrMinima datoDescrMinima,Map<String, Object> variablesIngreso);
	public List<Map<String, String>> valtipdescr(DatoItem item) ;
	//rtineo mejoras
	public List<Map<String, String>> valtipdescr(DatoItem item,Map<String, Object> variablesIngreso);
	public List<Map<String, String>> valgraldescmin(DatoItem item, Declaracion declaracion);
	public List<Map<String, String>> valgraldescmin2(Declaracion declaracion);
	
	
}
