package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface PecoAmazoniaDirectoService {
	public Map<Integer,Object> esPECOAmazoniaDirecto(Declaracion declaracion);
	public List<Map<String,?>> validacionesPECOAmazoniaDirecto(Declaracion declaracion, Map<String,Object> variablesIngreso, Declaracion declaracionBD);
	public List<Map<String,?>> validacionesNumeracion(Declaracion declaracion, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesRegularizacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesDiligenciaDespacho(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validarRegimen(String codRegimen, Map<Integer,Object> mapa, Declaracion declaracion);
	public List<Map<String,?>> validarSubpartidaArancelaria(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarCorrelacionNandinaNabandina(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarInformacionComplementaria(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarPartidaConvenioPECOAmazoniaDirecto(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarUbigeo(Declaracion declaracion, Map<Integer,Object> mapaSerieDUA);	
	//public String validarSeriePecoAmazoniaModificada(Map<String, Object> requestParameterMap);		
}
