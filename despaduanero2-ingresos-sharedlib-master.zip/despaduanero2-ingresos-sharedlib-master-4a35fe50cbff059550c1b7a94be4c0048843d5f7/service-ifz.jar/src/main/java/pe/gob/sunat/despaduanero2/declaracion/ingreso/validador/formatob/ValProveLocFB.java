package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;

public interface ValProveLocFB {

    public Map<String, String> codtipparticipante (DAV dav) ;
    public Map<String, String> codtipdocparticipante( DataCatalogo tipoDocumentoIdentidad);	
    public Map<String, String> codtipdocparticipante(DAV dav);	
    public List<Map<String, String>> numdocparticipante(DAV dav);	 
    public List<Map<String, String>> nomparticipante(DAV dav);
}
