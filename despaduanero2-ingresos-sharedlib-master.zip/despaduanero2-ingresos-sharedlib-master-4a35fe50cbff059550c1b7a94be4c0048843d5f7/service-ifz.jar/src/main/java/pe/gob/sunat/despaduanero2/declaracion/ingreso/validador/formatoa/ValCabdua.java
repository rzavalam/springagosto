/*
 * Clase que define el servicio de validaciones generales de la declaracion
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;


/**
 * The Class ValCabdua. Clase que define el servicio de validaciones generales de la declaracion
 */
public interface ValCabdua {

	public HashMap<String, Date> obtfecvalidacion(Declaracion declaracion);
	
	public Map<String, ?> setupDeclaracion(
			Declaracion declaracion, 
			String numOrden,
			String codUsuario, 
			Integer annEnvio, 
			Long numEnvio,
			String tipoSender,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender,
			String codTransaccion) ;
	
	
	public Map<String,String> validarEnProceso(Declaracion declaracion, String codTransaccion, String numeroDocumentoIdentidadSender, String numOrden, String numEnvio) throws Exception;
	public Map<String,String> validarOrdenDuplicada(Declaracion declaracion, String tipoDocumentoIdentidadSender ,String numeroDocumentoIdentidadSender, String numOrden,String codTransaccion)  throws Exception;
	public Map<String, String> codregimen(String codregimen, String codTransaccion);
	public List<Map<String, String>> codaduanaorden(Declaracion declaracion, String codTransaccion);
	public Map<String, String> valModalidadAduana(String codaduanaorden, DatoManifiesto manifiesto);
	public Map<String, String> numdocumento( DUA dua, String tipoDocumentoIdentidadSender ,String numeroDocumentoIdentidadSender, String tipoSender );
	public Map<String, String> codtipooper(String codtipooper);
	public Map<String, String> codmodalidad(String codmodalidad);
	public Map<String, String> valModalidadManifiesto(String codmodalidad, DatoManifiesto manifiesto);	
	public Map<String, String> codtipoperacion(String codtipoperacion,Declaracion declaracion);
	public Map<String, String> codlugarecepcion(String codlugarecepcion, Map<String,Object> variablesIngreso);
	public Map<String, String> numruclugarecep(String numruclugarecep,String codlugarecepcion);
	public Map<String, String> codanexo(String codanexo, String codlugarecepcion); //RIN05 PAS20181U220200004
	public Map<String, String> numrucdeposito(String numrucdeposito);
	public Map<String, String> mtotfobclvta(BigDecimal mtotfobclvta);
	public Map<String, String> mtotflecomex(BigDecimal mtotflecomex);
	public Map<String, String> mtotsegotros(BigDecimal mtotsegotros);
	public Map<String, String> mtotajustes(BigDecimal mtotajustes);
	public Map<String, String> mtovaladuana(BigDecimal mtovaladuana, BigDecimal mtotajustes, BigDecimal mtotfobclvta,BigDecimal mtotsegotros, BigDecimal mtotflecomex);
	public Map<String, String> cnttpesobruto(BigDecimal cnttpesobruto);
	public Map<String, String> cnttpesoneto(BigDecimal cnttpesoneto, BigDecimal cnttpesobruto);
	public Map<String, String> cnttcantbulto(BigDecimal cnttcantbulto);
	public Map<String, String> cnttqunifis(BigDecimal cnttqunifis);
	public Map<String, String> cntnumseries(Integer cntnumseries);
	public Map<String, String> cnttqunicom(BigDecimal cnttqunicom);
	public Map<String, String> mtototautoliq(BigDecimal mtototautoliq);
	public Map<String, String> codpropiedad(String codpropiedad);
	public Map<String, String> codtipoplazo(String codtipoplazo);
	public Map<String, String> numplazosol(Integer numplazosol);
	public Map<String, String> codtipotratamiento(String codtipotratamiento);
	public Map<String, String> codferia(String codferia);
	public Map<String, String> codtipempaque(String codtipempaque);
	public Map<String, String> codprodurgente(DUA dua);
	public Map<String, String> fecfinprovsional(Date fecfinprovsional);
	public Map<String, String> fecfinacoregimen(Date fecfinacoregimen);
	public Map<String, String> desfinalidad(String desfinalidad);
	public Map<String, String> codlocalanexo(String codlocalanexo);
	public Map<String, String> codoperacion(String codoperacion);
	public Map<String, String> codopaduana(String codopaduana);
	public Map<String, String> codoppuerto(String codoppuerto);
	public Map<String, String> codviatrades(String codviatrades);
	public Map<String, String> codmodpago(String codmodpago);
	public Map<String, String> codentipago(String codentipago);
	public Map<String, String> numplazcredito(Integer numplazcredito);
	public Map<String, String> feccarcr(Date feccarcr);
	public Map<String, String> codbcopagoelec(String codbcopagoelec);
	public Map<String, String> numctapagoelec(String numctapagoelec);
	public Map<String, String> codgarantia(String codgarantia);
	public List<Map<String,String>> declarante(Participante declarante, String codTransaccion);
	public List<Map<String,String>> rucAnexoUbicacion(Participante rucAnexoUbicacion, String codTransaccion
			,String codtipoperacion,String codlocalanexo);
	public Map<String,String> indSocorro(DUA dua);
	public Map<String, String> codtipopago(String codtipopago);
	public Map<String, String> codopaduing(String codopaduing);
	public Map<String, String> codopadusal(String codopadusal);
	public Map<String, String> codopadutra(String codopadutra);
	public Map<String, String> validarPuntoLLegada(Declaracion declaracion, String codTransaccion, Date fechaReferencia);
	public List<Map<String, String>> prorrateoFlete(Declaracion declaracion);
	public Map<String, String> fecvenregimen(Date fecvenregimen);
	public Map<String, String> validarLocalAnexoPuntoLLegada(Declaracion declaracion, String codigoTransaccion);
	public int obtenerDocTransporte(List<DatoDocTransporte> docutransSerie, String numDocTransporte);
	public int obtenerDocTransporteAll(List<DatoDocTransporte> docutransSerie, Integer numeroDetalle);
	public Map<String, String> valPuntoLlegadaImportador(String numruclugarecep, String codlugarecepcion, String codanexo, String codTransaccion);
    public List<Map<String,String>>  bloqueoDespachosUrgentes(String codmodalidad, Date fechareferencia, Declaracion declaracion);
   	public List<Map<String,String>>  validarPuntoLLegadaUrgenteExcepcional(Declaracion declaracion , String codigoTransaccion	);
    public List<Map<String,String>>  validarAduanaMaritimaExcepcional(Declaracion declaracion 	);
   	public Map<String,String> validarDisposicionTotal (Declaracion declaracionBD);
   	public Map<String,String> validarDisposicionParcial (Declaracion declaracionBD);
   	public Map<String,String> validarDisposicionTotalRegul (Declaracion declaracionBD);
   	public Map<String, String> validarDisposicionParcialRegul (Declaracion declaracionBD);
    public Map<String, String> validarDAMDiferidaSinICA(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public Map<String, String> validaNoExistenciaNotaTarjaParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public Map<String, String> validaTipoDocumentoPermitidoParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public Map<String, String> validaNoExistenciaICAParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public Map<String,Object> isDAMDiferidaSinICA(DUA dua);
    public Map<String, String> validarPuntoLLegada(Declaracion declaracion, String codTransaccion, Date fechaReferencia,Map<String,Object> variablesIngreso);
    public Map<String, String> validaExistenciaContenedoresDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso);
    public Map<String, String> validaFechaNumeMayorFechaLlegada(Declaracion declaracion, Map<String,Object> variablesIngreso);
	public Map<String, String> validaTipoDestinacionBlDAMDiferidaSinIca(Declaracion declaracion, Map<String,Object> variablesIngreso);

	public Map<String, String> validaSinICAPesoUnidadVolumenDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso); //PAS20181U220200049 pruizcr
	
	//HAcostaR Inicio - PROYECTO REGIMENES ESPECIALES MUA
    public Map<String,String> validarOrdenDuplicada(Declaracion declaracion, String tipOperadorSender, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String numOrden, String codTransaccion)  throws Exception;
    //HAcostaR Fin - PROYECTO REGIMENES ESPECIALES MUA
	List<Map<String, String>> validarUnidadCarga(DUA dua, Date fechaReferencia);
	Map<String, String> codModPagoOtros(String codModPago, String desModoPago);
	//rtineo Numeracion DSEER
	public Map<String, ?> setupDeclaracionEER(Declaracion declaracion,String numOrden,String codUsuario,Integer annEnvio,Long numEnvio,String tipoSender,String numeroDocumentoIdentidadSender,	String tipoDocumentoIdentidadSender,String codTransaccion);
	public Map<String, ?> setupDeclaracionEspeciales(Declaracion declaracionEspecial,String numOrden,String codUsuario,Integer annEnvio,Long numEnvio,String tipoSender,String numeroDocumentoIdentidadSender,	String tipoDocumentoIdentidadSender,String codTransaccion);

}
