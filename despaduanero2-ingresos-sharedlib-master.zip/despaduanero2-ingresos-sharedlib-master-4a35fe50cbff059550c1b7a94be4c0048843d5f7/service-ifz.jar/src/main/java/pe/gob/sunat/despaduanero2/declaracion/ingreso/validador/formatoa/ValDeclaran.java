/*
 * Clase que define el servicio de validaciones del declarante de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;

/**
 * The Class ValDeclaran. Clase que define el servicio de validaciones del declarante de la DUA
 */
public interface ValDeclaran {

	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante);
	
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad);

	public Map<String, String> numeroDocumentoIdentidad(String numeroDocumentoIdentidad);
	
	public Map<String, String> pais(DataCatalogo pais);
	
	public Map<String, String> nombreRazonSocial(String nombreRazonSocial);

	public Map<String, String> direccion(String direccion);
	
	public Map<String, String> ciudad(String ciudad);
	
	public Map<String, String> telefono(String telefono);
	
	public Map<String, String> fax(String fax);
	
	public Map<String, String> email(String email);
	
	public Map<String, String> paginaWeb(String paginaWeb);	

}
