package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;

public interface ValmontoFB {
	//public Map<String, String> indestiprov(java.lang.String arg);
	public java.util.List<Map<String, String>> codmoneda(DatoMontoProv monto);
	public java.util.List<Map<String, String>> fectipocambio(DatoMontoProv monto);
	public java.util.List<Map<String, String>> fecvalestima(DatoMontoProv monto) ;
	public Map<String, String> indtipovalor(DatoMontoProv montoProv) ;
	public java.util.List<Map<String, String>> valmonto(DatoMontoProv monto);
	public java.util.List<Map<String, String>> valdefinitivo(DatoMontoProv monto);
	public Map<String, String> validarCodigoMontoFormatoB(DatoMonto datoMonto);
}
