package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.HashMap;
import java.util.Map;

public interface GeneraRespuestaService {
	
	public HashMap<String, String> validacionGeneraRespuestaEnvio(Integer nroErroresNegocio, Map<String, Object> variablesIngreso);
	
	public void generaRespuestaEnvio (Integer nroErroresNegocio, Map<String, Object> variablesIngreso);

}