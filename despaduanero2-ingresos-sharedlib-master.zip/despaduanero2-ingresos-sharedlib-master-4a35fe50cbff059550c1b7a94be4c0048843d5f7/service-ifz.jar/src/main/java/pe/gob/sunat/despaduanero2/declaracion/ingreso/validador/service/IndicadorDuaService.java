package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.List;//P46-PAS20155E410000032
import java.util.Map; // P46

import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface IndicadorDuaService {

	boolean esDuaRegularizable(Long numCorreDoc);

	// P46
	public Map<String, Object> obtenerIndicadoresDonacion(Long numCorreDoc);

	public boolean tieneIndicadorManifiesto(Declaracion declaracion, String codTransaccion);
	
	public DatoIndicadores obtenerIndicadorDeclaracion(String numCorreDoc, String codIndicador);


	public void insertarIndicadorDeclaracion(String numCorreDoc, String codIndicador, String codTipoRegistro);
	
	//ini P46-PAS20155E410000032
	/**
	 * Metodo que permite obtener el listado de indicadores a partir del mapa
	 * que contiene los datos de la declaracion que se encuentra en sesion
	 * 
	 * @param mapCabDeclaraActual
	 * @return
	 */
	public List<Map<String, Object>> obtenerListadoIndicadoresEnSesion(Map<String, Object> mapCabDeclaraActual);
	//fin P46-PAS20155E410000032
	
	/**
	 * Inserta el indicador de acuerdo a los parametros, en caso de existir lo activa.
	 * @param params
	 */
	public void insertaActualizaIndicador(Map<String, Object> params);
	
	/**
	 * Actualiza el indicador de acuerdo a parametros
	 * @param params
	 */
	public void actualizaIndicador(Map<String, Object> params);

	//ggranados legajo
	Integer existeIndicadorByParams(DatoIndicadores indicador);
}
