package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Map;

public interface ValAdidua {
	
	public Map<String, String> codidcertorigen(String codidcertorigen);
	
	public Map<String, String> codidfactura(String codidfactura);

	public Map<String, String> codidocsoporte(String codidocsoporte);
	
	public Map<String, String> numiddocsoporte(Integer numiddocsoporte);	
	
	public Map<String, String> codtipodocsoporte(String codtipodocsoporte);
}
