package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarGeneralService {
//	public List<Map<String,Object>> registrarDesdatado(Declaracion declaracion,String codTransaccion) throws Exception;
	public List<Map<String, Object>> registrarDesdatado(Declaracion declaracion,String codTransaccion, Map<String, Object> variablesIngreso) throws Exception;

	
	public Map<String, String> Grabacabydetsolicitud(Declaracion declaracion
			, SolicitudRectificacionBean solicitudRectificacion,String tipoSolicitud,String estadoSolicitud) throws Exception;
	
	public Map<String, String> Grabatablanegocio( Declaracion declaracion,
			 SolicitudRectificacionBean solicitudRectificacion) throws Exception;	
	
	//public Map<String, Object> Grabadocadeudo( Declaracion declaracion ,Map deudadiferencial,Map<String, Object> variablesIngreso  )throws Exception;
	
//	public Map<String, Object> registrarDatado(Declaracion declaracion,String tipoDatada, String codTransaccion) ;
	public Map<String, Object> registrarDatado(Declaracion declaracion,String tipoDatada, String codTransaccion, Map<String, Object> variablesIngreso)throws Exception;;
	
	public  void afectaGarantia (Declaracion declaracion, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String numOrden,
			String codUsuario, String cTrans, String tipoDesp, Date fechaConclusionDespa, Map<String, Object> variablesIngreso);
	public void asignaCanal(Declaracion declaracion, String tipoDesp,String codTransaccion);
	public  void actualizaCupoLibe (Declaracion declaracion);
	public void grabarTabImpDU(Declaracion declaracion);
	public void grabarProductoRemate(Declaracion declaracion);
	public void grabaCupoTPI (Map<String, Object> variablesIngreso);
	public String invocarAfectarGarantia(Declaracion declaracion,BigDecimal montoAcumuladoDolares, String cda,Integer fechaConclusionDespacho, 
			String numeroDocumentoIdentidadSender, 
			String modulo, String ctrans,String numref,String numero);
	public void grabaCtaCtePerNat (Declaracion declaracion, String codTransaccion);
//	public void realizarEnvioCorreoDocAutoriz(Declaracion declaracion);
	public void grabarBeneficiario(Declaracion declaracion) ;

	/**
	 * Graba la fecha de regularizacion de la DUA para despachos urgentes o anticipados de corresponder 
	 * @param dua
	 */
	public void grabaFechaVencRegularizacion (DUA dua);
	
	public void actualizaRUCResolucionLiberatoria(Declaracion declaracion);

	// RIN15
	public String desafectaGarantiaDocumento(String RUCImport, String tipoExtincion ,String numRef,BigDecimal nTipoCamnio, DUA dua,  String cda, 
			BigDecimal monto, String moneda, String tipoDeuda,Map<String, Object> variablesIngreso);
}

