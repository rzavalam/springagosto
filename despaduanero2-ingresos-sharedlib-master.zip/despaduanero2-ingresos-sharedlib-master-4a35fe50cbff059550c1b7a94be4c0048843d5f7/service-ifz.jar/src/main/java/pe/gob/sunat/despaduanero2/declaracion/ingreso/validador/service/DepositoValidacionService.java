package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
 
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public interface DepositoValidacionService {

	
	public abstract List<Map<String, String>> validarVigenciaFechaExpiracion(Declaracion declaracion);
	public abstract List<Map<String, String>> validarDepositoUrgente(Declaracion declaracion);
	public abstract List<Map<String, String>> validarRegimenPrecedencia(Declaracion declaracion);
	public abstract List<Map<String, String>> validarCodigoUltraActividad(Declaracion declaracion);
	public abstract List<Map<String, String>> validarPais(Declaracion declaracion);
	public abstract List<Map<String, String>> validarMoneda(Declaracion declaracion);
	public abstract List<Map<String, String>> validarFleteSeguro(Declaracion declaracion);
	public abstract List<Map<String, String>> validarValorAduanas(Declaracion declaracion);
	public abstract List<Map<String, String>> validarNandtasa(Declaracion declaracion);
	public abstract List<Map<String, String>> validaRegimenProcedencia(Declaracion declaracion);
	public abstract List<Map<String, String>> validarFeriaRegimen(Declaracion declaracion);
	public abstract List<Map<String, String>> validarViaTransporteDeposito(Declaracion declaracion);
	public abstract List<Map<String, String>> validarDeposito(Declaracion declaracion);
	public abstract List<Map<String, String>> validarPlazoPresentado(Declaracion declaracion);
	public abstract List<Map<String, String>> validarMontoTotales(Declaracion declaracion);
	public abstract List<Map<String, String>> validarAlmacenAduanero(Declaracion declaracion);
//	public abstract List<Map<String, String>> validarTipoDeDeposito(Declaracion declaracion);
	public abstract List<Map<String, String>> validarVigenciaDocumento(Declaracion declaracion);
	public abstract List<Map<String, String>> validarPlazoMaximoDeposito(Declaracion declaracion);
}
