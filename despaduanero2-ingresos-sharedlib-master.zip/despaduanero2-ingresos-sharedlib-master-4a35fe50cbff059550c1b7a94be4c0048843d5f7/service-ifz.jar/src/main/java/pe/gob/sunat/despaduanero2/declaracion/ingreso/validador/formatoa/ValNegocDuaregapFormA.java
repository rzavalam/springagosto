/*
 * Clase que define el servicio de validaciones complejas sobre los regimenes precedentes
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValNegocDuaregapFormA. Clase que define el servicio de validaciones complejas sobre los regimenes precedentes.
 */
public interface ValNegocDuaregapFormA {
	
	public List<Map<String,String>> duaRegap(Declaracion declaracion, Date fechaReferencia, String codTransaccion);
	
	//glazaror... mejoras
	public List<Map<String,String>> duaRegap(Declaracion declaracion, Date fechaReferencia, String codTransaccion, Declaracion declaracionBD);
	
	public void obtenerSaldoDisponibleAdicionalXItemCrmf(Declaracion declaracion, Map<String, Object> mSaldDispAdiItemCrmf,List<Map<String, Object>> datosCrmfPorSerie);//P28-PAS20155E410000032-[jlunah]
}
