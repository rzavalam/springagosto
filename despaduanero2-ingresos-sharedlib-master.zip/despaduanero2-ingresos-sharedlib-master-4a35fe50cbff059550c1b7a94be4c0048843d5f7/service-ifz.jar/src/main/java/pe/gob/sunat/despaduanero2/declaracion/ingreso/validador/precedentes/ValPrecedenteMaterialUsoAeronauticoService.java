package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ValPrecedenteMaterialUsoAeronauticoService {

	public List<Map<String, String>> validaMaterialUsoAeronautico(Declaracion declaracion, String puntoDeLlegada, List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia);

}
