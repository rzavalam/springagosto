package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

import java.util.Date;

public interface ValidadorPuntoLlegadaMercancia {

	/**
	 * Valida el punto de llegada de una dua
	 */
	public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException;

}
