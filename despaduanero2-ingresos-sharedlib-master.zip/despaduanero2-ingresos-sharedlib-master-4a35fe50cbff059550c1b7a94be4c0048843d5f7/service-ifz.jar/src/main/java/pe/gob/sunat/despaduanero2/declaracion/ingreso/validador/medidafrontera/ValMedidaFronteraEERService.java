package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.medidafrontera;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValMedidaFronteraEERService {
	public List<Map<String,String>> valIndicador(Declaracion declaracion, String codCategoria);
}
