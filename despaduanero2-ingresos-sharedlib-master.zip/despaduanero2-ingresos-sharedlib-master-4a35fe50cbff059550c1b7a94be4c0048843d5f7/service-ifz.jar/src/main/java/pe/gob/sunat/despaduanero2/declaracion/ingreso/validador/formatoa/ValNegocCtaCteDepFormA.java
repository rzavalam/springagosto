package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

public interface ValNegocCtaCteDepFormA {
	
	public List<Map<String,String>> ctaCteDeposito(Map<String,Object> datosDepocCta);
		
}
