package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public interface PackageTD {

	

	/**
	 * Ref PKTD_TD.cambiovigente
	 * Se verifica en la tabla TABLNEW si el proceso se encuentra vigente,
	 * para ello se realiza la consulta con el Tipo=�AJ� y Codigo= PCodigo y
	 * PFecha entre Finicio y Ffin. Si se cumple esta condici�n significa
	 * que el proceso est� vigente y retorna 1 sino es as� significa que no
	 * est� vigente y retorna 0.
	 */
	public Integer getCambioVigente(String codigoProceso, Integer fecha);

	/**
	 * Ref PKTD_TD.fnAgemar
	 * @param codAgenciaNaviera
	 * @param codAduana
	 * @param fecValidacion
	 * @return
	 */
	public Integer getCountInAgeMar(String codAgenciaNaviera, String codAduana, Date fecValidacion);
	
	
	/**
	 * @param codAgenciaNaviera
	 * @param codAduana
	 * @return
	 */
	public Integer getCountInEmpreDTN(String codAgenciaNaviera, String codAduana);

	

	public Integer getCountInPuertos(String codPuerto);
	
	//glazaror... metodo optimizado
	public Map<String, Integer> getCountInPuertos(List<String> codigosPuerto);

		
	/**
	 * 
	 * @param tipoPrefArancelaria
	 * @param codPrefArancelaria
	 * @return
	 */
	public Integer getCountInTabLibe(String tipoPrefArancelaria, String codPrefArancelaria);
	
	
	
	public String functionDeclaVig(String codigo, String tipoBusq, String tipoDocumento);
	public boolean validaNumLetCar(String arg) ;	
}

