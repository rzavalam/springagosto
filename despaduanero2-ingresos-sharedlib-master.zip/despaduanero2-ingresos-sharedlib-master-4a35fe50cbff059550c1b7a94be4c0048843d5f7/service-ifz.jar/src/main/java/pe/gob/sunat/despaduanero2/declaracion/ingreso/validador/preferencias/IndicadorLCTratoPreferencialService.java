package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface IndicadorLCTratoPreferencialService {
	
	public Map<String,String> valIndicadorLCTipoMargen(DUA dua, Date fechaReferencia);
	
	public Map<String,String> valIndicadorLCTipoMargenSinDatosCO(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public Map<String, String> valIndicadorLCTipoMargenTPI(DatoSerie serie, Date fechaReferencia , Map<String, Object> variablesIngreso) ;
}
