/*
 * Clase que define el servicio de validaciones de Equipamiento
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValEquipa. Clase que define el servicio de validaciones de Equipamiento.
 */
public interface ValEquipa {
	
	public Map<String, String> numequipo(String numequipo);

	public Map<String, String> codtamequip(String codtamequip);
	
	public Map<String, String> codcondequip(String codcondequip);
	
	public Map<String, String> numContenedor(String arg) ;
	
	public List<Map<String, String>> valEquipamientoDeclaracion(Declaracion declaracion);
	
	public List<Map<String, String>> valEquipamientoDeclaracion(Declaracion declaracion, String codTransaccion);
}
