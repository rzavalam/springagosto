package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean;

import java.util.Date;
import java.util.List;


public class SolicitudRectificacionBean {
  private Long numcorredoc;
  private String desmotivrecti;
  private String codestarecti;
  private String codtransaccion;
  
  private List<DetSolicitudRectificacionBean> listaCambios;
  
  //Adicionado TLC 2016-006 Fecha de la Solicitud
  private Date fec_solicitud;
  
public Long getNumcorredoc() {
	return numcorredoc;
}
public void setNumcorredoc(Long numcorredoc) {
	this.numcorredoc = numcorredoc;
}
public String getDesmotivrecti() {
	return desmotivrecti;
}
public void setDesmotivrecti(String desmotivrecti) {
	this.desmotivrecti = desmotivrecti;
}
public String getCodestarecti() {
	return codestarecti;
}
public void setCodestarecti(String codestarecti) {
	this.codestarecti = codestarecti;
}
public List<DetSolicitudRectificacionBean> getListaCambios() {
	return listaCambios;
}
public void setListaCambios(List<DetSolicitudRectificacionBean> listaCambios) {
	this.listaCambios = listaCambios;
}
public String getCodtransaccion() {
	return codtransaccion;
}
public void setCodtransaccion(String codtransaccion) {
	this.codtransaccion = codtransaccion;
}
//TLC 2016-006
public Date getFec_solicitud() {
	return fec_solicitud;
}
public void setFec_solicitud(Date fec_solicitud) {
	this.fec_solicitud = fec_solicitud;
}
  
  
  
}
