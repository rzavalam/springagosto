package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Creador por amancillaa
 * fecha: 14/01/2015.
 */
public interface ValidadorValorProvisionalService
{

//mol pase24
    public List validarValorProvisionalParaRectificacionProcedente(Declaracion declaracion,Declaracion declaracionBD, String tieneIncTrib) throws Exception;
//mol pase24
    public List validarValorProvisionalParaRectificacionProcedenteEnParte(Declaracion declaracion,Declaracion declaracionBD, String tieneIncTrib) throws Exception;

    public Map grabarValorProvisional(Declaracion declaracion,Declaracion declaracionBD) throws Exception;
    
    public void rechazarSolicitudElectronicaConValorProvisional(String codAduana, String codRegimen, Integer ano, Integer numDeclaracion, Long numCorreDocSol);

    public void improcedenteSolicitudElectronicaConValorProvisional(String codAduana, String codRegimen, Integer ano, Integer numDeclaracion, Long numCorreDocSol);

    /** Inicio mpoblete RIN10 [metodo para habilitar funcionalidad rin10]**/
    public boolean estaVigenteValorProvisional()throws Exception;
    /** Fin mpoblete RIN10**/
    //mol para bug//
    public BigDecimal obtenerSaldoPorCubrir(Declaracion declaracion);
    public BigDecimal obtenerMontoLCGeneradaVP(Declaracion declaracion);
    //fin mol
    
    public List validarValorProvisionalParaDiligencia(Declaracion declaracion) throws Exception;
}
