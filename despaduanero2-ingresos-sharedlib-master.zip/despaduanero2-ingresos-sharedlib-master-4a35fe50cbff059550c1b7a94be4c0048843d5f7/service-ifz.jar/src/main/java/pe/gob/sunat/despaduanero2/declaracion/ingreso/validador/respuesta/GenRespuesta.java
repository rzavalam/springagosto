package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.respuesta;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_RECTIFICACION;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.model.Cambio1;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabDeuda;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeudaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Cambio1DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.MovCabliqdiligDAO;
import pe.gob.sunat.recauda2.genadeudo.service.FuncionesLiquidacionService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.vuce.pago.model.CabDocpago;
import pe.gob.sunat.vuce.pago.model.dao.CabDocpagoDAO;


public class GenRespuesta {
	
	private static final String MSG_REGULARIZACION_RECEPCIONADA = "TRANSMISION DE LOS DATOS DE REGULARIZACION ACEPTADA";

	private static final String MSG_REGULARIZACION_RECEPCIONADA_FUERA_DEL_PLAZO = "TRANSMISION DE LOS DATOS DE REGULARIZACION ACEPTADA FUERA DEL PLAZO";

	private static final String MSG_REGULARIZACION_RECEPCIONADA_CON_SUSPENSI�N_DE_PLAZO = "TRANSMISION DE LOS DATOS DE REGULARIZACION ACEPTADA CON SUSPENSION DE PLAZO";

	private static final String MSG_REGULARIZACION_ACEPTADA_AUTOM�TICAMENTE = "REGULARIZACION ACEPTADA AUTOMATICAMENTE";

	private static final String MSG_REGULARIZACION_ACEPTADA_FUERA_DE_PLAZO = "REGULARIZACION ACEPTADA FUERA DE PLAZO";

	private static final String MSG_REGULARIZACION_ACEPTADA_CON_SUSPENSION_DE_PLAZO = "REGULARIZACION ACEPTADA CON SUSPENSION DE PLAZO";

	private static final String MSG_REGUL_SUFIJO=" - SE ACTUALIZAN SOLO LOS DATOS INDICADOS EN EL PROCEDIMIENTO INTA PG.01 VIGENTE"; 

	protected final Log log = LogFactory.getLog(getClass());
	
	private CabDeclaraDAO cabDeclaraDAO; 
	private CabDeudaDAO cabDeudaDAO;
	private DeudaDocumDAO deudaDocumDAO;
	private MovCabliqdiligDAO movCabliqdiligDAO;
	private LiquidaDAO liquidaDAO;
	private Cambio1DAO cambio1DAO;
	private CabDocpagoDAO cabDocpagoDAO;
	private SolicitudDAO solicitudDAO;	
	private AyudaService ayudaService;
	private LiquidaDeclaracionService liquidaDeclaracionService;
	private FabricaDeServicios fabricaDeServicios;
	
	public Map<String, Object> respuesta1001(Map<String, Object> mapRespuesta) {
		//String msgNotif = " ";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2001(Map<String, Object> mapRespuesta) {
		//String msgNotif = " ";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2101(Map<String, Object> mapRespuesta) {
		//String msgNotif = " ";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta7001(Map<String, Object> mapRespuesta) {
		//String msgNotif = " ";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta1002(Map<String, Object> mapRespuesta) {
		//String msgNotif = "<por definir>";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2002(Map<String, Object> mapRespuesta) {
		//String msgNotif = "<por definir>";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2102(Map<String, Object> mapRespuesta) {
		//String msgNotif = "<por definir>";
		//mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta1003(Map<String, Object> mapRespuesta) {
		/*hosorio inicio 13/06/2011*/
		/*
		String msgNotif = "Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada");
		mapRespuesta.put("msgNotif", msgNotif);
		*/
		/*hosorio fin 13/06/2011*/
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2003(Map<String, Object> mapRespuesta) {
		/*hosorio inicio 13/06/2011*/
		/*
		String msgNotif = "Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada");
		mapRespuesta.put("msgNotif", msgNotif);
		*/
		/*hosorio fin 13/06/2011*/
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta2103(Map<String, Object> mapRespuesta) {
		/*hosorio inicio 13/06/2011*/
		/*
		String msgNotif = "Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada");
		mapRespuesta.put("msgNotif", msgNotif);
		*/
		/*hosorio fin 13/06/2011*/
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta7003(Map<String, Object> mapRespuesta) {
		/*hosorio inicio 13/06/2011*/
		/*
		String msgNotif = "Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada");
		mapRespuesta.put("msgNotif", msgNotif);
		*/
		/*hosorio fin 13/06/2011*/
		return mapRespuesta;
	}
	
	private Map<String, Object> respuestaTrx04(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		String msgNotif ="";
		Date fechaVencRegularizacion = (Date)variablesIngreso .get("fechVencRegul");
		Boolean tieneExpediente = (Boolean)variablesIngreso.get("tieneExpediente");
		String codTransaccion=(String)variablesIngreso.get("codTransaccion");
		String lcTipoTrans = "";
		Date fechaActual = new Date();
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		// Setear la variable que almacena el mensaja a mostrar en el XMl de respuesta
		if (lcTipoTrans.equals(TRANSACCION_REGULARIZACION_ANT)){ // XX04
			if (SunatDateUtils.getIntegerFromDate(fechaActual) >SunatDateUtils.getIntegerFromDate(fechaVencRegularizacion)) {
				if (tieneExpediente)
					msgNotif=MSG_REGULARIZACION_ACEPTADA_CON_SUSPENSION_DE_PLAZO + MSG_REGUL_SUFIJO;
				else
					msgNotif=MSG_REGULARIZACION_ACEPTADA_FUERA_DE_PLAZO + MSG_REGUL_SUFIJO;
			}else{
				msgNotif=MSG_REGULARIZACION_ACEPTADA_AUTOM�TICAMENTE + MSG_REGUL_SUFIJO;
			}
		}
		
		mapRespuesta.put("msgNotif", msgNotif);
		
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta1004(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx04(mapRespuesta, variablesIngreso);
	}
	
	public Map<String, Object> respuesta2004(Map<String, Object> mapRespuesta, Map<String, Object> variablesIngreso) {
		return respuestaTrx04(mapRespuesta, variablesIngreso);
	}

	public Map<String, Object> respuesta2104(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx04(mapRespuesta, variablesIngreso);
	}
	
	public Map<String, Object> respuesta7004(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx04(mapRespuesta, variablesIngreso);
	}
	
	private Map<String, Object> respuestaTrx05(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		String msgNotif ="";
		Date fechaVencRegularizacion = (Date)variablesIngreso .get("fechVencRegul");
		Boolean tieneExpediente = (Boolean)variablesIngreso.get("tieneExpediente");
		String codTransaccion=(String)variablesIngreso.get("codTransaccion");
		String lcTipoTrans = "";
		Date fechaActual = new Date();
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		if (lcTipoTrans.equals(TRANSACCION_REGULARIZACION_URG)){ // XX05
			if (SunatDateUtils.getIntegerFromDate(fechaActual) >SunatDateUtils.getIntegerFromDate(fechaVencRegularizacion)) {
				if (tieneExpediente)
					msgNotif=MSG_REGULARIZACION_RECEPCIONADA_CON_SUSPENSI�N_DE_PLAZO;
				else
					msgNotif=MSG_REGULARIZACION_RECEPCIONADA_FUERA_DEL_PLAZO;
			}else{
				msgNotif=MSG_REGULARIZACION_RECEPCIONADA;
			}
		}
		mapRespuesta.put("msgNotif", msgNotif);
		return mapRespuesta;
	}
	
	public Map<String, Object> respuesta1005(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx05(mapRespuesta, variablesIngreso);
	}
	
	public Map<String, Object> respuesta2005(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx05(mapRespuesta, variablesIngreso);
	}
	
	public Map<String, Object> respuesta2105(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx05(mapRespuesta, variablesIngreso);
	}
	
	public Map<String, Object> respuesta7005(Map<String, Object> mapRespuesta,Map<String, Object> variablesIngreso) {
		return respuestaTrx05(mapRespuesta, variablesIngreso);
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> obtenerDatosPrincipalesNumeracion (Map<String, Object> variablesIngreso) {
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyyMMdd");
		Map<String, Object> mapRespuesta = new HashMap();
		Declaracion declaracion = (Declaracion)variablesIngreso .get("declaracion");
		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		String numOrden 		= (String) variablesIngreso.get("numOrden");
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		}
		
		String msgNotif = SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif")))?" ":SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif"));
		
		Long numCorredoc = declaracion.getNumeroCorrelativo();
		List<CabDeuda> lstCabDeuda = new ArrayList();
		List<HashMap> lstLiquida = new ArrayList(); 
		List<CabDocpago> lstCabDocpago = new ArrayList();
		String lccodTipLiqui = TIPO_LIQUI_NUMERACION;
		BigDecimal tipoCambio = new BigDecimal("0");
		
		mapRespuesta.put("encontro", "NO");

		Map<String, Object> params = new HashMap();
		params.put("numeroCorrelativo", numCorredoc);
		DUA dua = cabDeclaraDAO.selectByNumCorredoc(params);
		if (dua!=null) {
			String lcNumDUA = Cadena.padLeft(dua.getNumdocumento().trim(), 6, '0');
			String lcDigiVeri = liquidaDeclaracionService.digiVeri(Cadena.padLeft(dua.getCodaduanaorden(), 3, '0'), 
					dua.getAnnpresen().toString().substring(2,4), 
					dua.getCodregimen(), 
					lcNumDUA, 
					"01");
			mapRespuesta.put("encontro", "SI");
			mapRespuesta.put("codTransaccion", codTransaccion);
			mapRespuesta.put("dua", dua);
			mapRespuesta.put("nroDua", lcNumDUA);
			mapRespuesta.put("tipoDocum", "01");
			mapRespuesta.put("digiVeri", lcDigiVeri);
			mapRespuesta.put("tipoAforo", dua.getCodCanal());
			mapRespuesta.put("tipoManif", " ");
			mapRespuesta.put("msgNotif", msgNotif.toUpperCase());
			mapRespuesta.put("funResumen", " ");
			mapRespuesta.put("fecCance", (new FechaBean("00010101","yyyyMMdd")).getSQLDate());
			mapRespuesta.put("bancCance", " ");
			mapRespuesta.put("montoCance", new BigDecimal("0"));
			mapRespuesta.put("totpDolar", new BigDecimal("0"));
			mapRespuesta.put("tipoCambio", new BigDecimal("0"));
			mapRespuesta.put("slibPecos", "N");
			mapRespuesta.put("sufijo", " ");
			mapRespuesta.put("lstCabDeuda", lstCabDeuda);
			mapRespuesta.put("lstLiquida", lstLiquida);
			mapRespuesta.put("lstCabDocpago", lstCabDocpago);
			mapRespuesta.put("fecUltDiaPago", (new FechaBean("00010101","yyyyMMdd")).getSQLDate());
			mapRespuesta.put("codregimen", dua.getCodregimen());
			mapRespuesta.put("codaduana", Cadena.padLeft(dua.getCodaduanaorden(), 3, '0'));
			
			Map<String,Object> mapCambio1 = new HashMap<String,Object>();
			mapCambio1.put("fingreso", formatoDelTexto.format(dua.getFecdeclaracion()));
			mapCambio1.put("cmoneda", "USD");
//			Cambio1 cambio1 = cambio1DAO.findByPK(mapCambio1);
			mapCambio1.put("ayudaID", "Cambio1");
			Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(mapCambio1);
			if (cambio1!=null) {
				tipoCambio = cambio1.getPventa();
				mapRespuesta.put("tipoCambio", tipoCambio);
			}

			// Verificando la Deuda
			DeudaDocum tmpDeudaDocum = new DeudaDocum();
			DeudaDocum deudaDocum = null;
			tmpDeudaDocum.setNumCorredoc(numCorredoc);
			List<DeudaDocum> tmpListDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
			for (DeudaDocum xDeudaDocum:tmpListDeudaDocum) { // Para obtener el ultimo y que no est� pagado.
				if (xDeudaDocum.getMtoPagado().compareTo(new BigDecimal("0"))==0 && xDeudaDocum.getCodTipdeuda().equals("01")) {
					deudaDocum = xDeudaDocum; 
				}
			}
			if (deudaDocum!=null) {
				Integer numIdentdeuda = deudaDocum.getNumIdentdeuda();
				mapRespuesta.put("totpDolar", deudaDocum.getMtoDeuda());
				mapRespuesta.put("sufijo", Cadena.padLeft(deudaDocum.getNumReliq().toString().trim(), 2, '0'));
				MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
				tmpMovCabliqdilig.setCodAduDocliq(Cadena.padLeft(dua.getCodaduanaorden(), 3, '0'));
				tmpMovCabliqdilig.setCodRegDocliq(dua.getCodregimen());
				tmpMovCabliqdilig.setCodTipLiqui(lccodTipLiqui);
				tmpMovCabliqdilig.setCodTipdiligencia(" ");
				tmpMovCabliqdilig.setNumReliq(deudaDocum.getNumReliq());
				tmpMovCabliqdilig.setAnnDocliq(dua.getAnnpresen().toString());
				tmpMovCabliqdilig.setNumDocliq(lcNumDUA);
				tmpMovCabliqdilig.setAnnOrden(lcAnn_orden);
				tmpMovCabliqdilig.setNumOrden(lcNume_orden);
				tmpMovCabliqdilig.setCodAgente(numeroDocumentoIdentidadSender);
				
				FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
				MovCabliqdilig movCabliqdilig = funcionesLiquidacionService.obtenerCabeceraPreliquidacionPorPK(tmpMovCabliqdilig);
				//MovCabliqdilig movCabliqdilig = movCabliqdiligDAO.selectByPrimaryKey(tmpMovCabliqdilig);
				
				if (movCabliqdilig!=null) {
					if (movCabliqdilig.getIndPoliLiber().equals("2") || movCabliqdilig.getIndPoliLiber().equals("3") || movCabliqdilig.getIndPoliLiber().equals("6")) {
						mapRespuesta.put("slibPecos", "S");
					} 
				}
				mapRespuesta.put("fecUltDiaPago", deudaDocum.getFecVenc());
				CabDeuda tmpCabDeuda = new CabDeuda();
				tmpCabDeuda.setNumCorredoc(numCorredoc);
				tmpCabDeuda.setNumIdentdeuda(numIdentdeuda);
				lstCabDeuda = cabDeudaDAO.selectByDeuda(tmpCabDeuda);
				mapRespuesta.put("lstCabDeuda", lstCabDeuda);
				
				// Se obtiene lista de LCs
				Liquida tmpLiquida = new Liquida();					
				tmpLiquida.setRladuaso(Cadena.padLeft(dua.getCodaduanaorden(), 3, '0'));
				tmpLiquida.setRlanoaso(dua.getAnnpresen().toString().trim().substring(2, 4));
				tmpLiquida.setRlnumaso(lcNumDUA);
				List<Liquida> lstLiquidaAux = liquidaDAO.selectSelectivo(tmpLiquida);
				if (lstLiquidaAux!=null && lstLiquidaAux.size()>0) {
					for (Liquida liquida: lstLiquidaAux) {
						Integer lnFechActual;
						try {
							lnFechActual = Integer.valueOf(DateUtil.dateToString(new FechaBean().getSQLDate(), "yyyyMMdd"));
						} catch (NumberFormatException e) {
							lnFechActual = 00010101;
						} catch (ParseException e) {
							lnFechActual = 00010101;
						}
						if (liquida.getRlfeccan().equals(0) && liquida.getRlfecliq().equals(lnFechActual)) {
							HashMap mapLiquida = new HashMap();
							mapLiquida.put("moneda", liquida.getRlcodmon().equals("S")?"PEN":"USD");
							mapLiquida.put("nroLC", liquida.getRladuana().concat("-").concat(liquida.getRlano()).concat("-").concat(liquida.getRlnroliq()));
							mapLiquida.put("monto", liquida.getRlcodmon().equals("S")?liquida.getRlsmontot():liquida.getRldmontot());
							mapLiquida.put("cda", liquida.getRladuaso().
									concat(liquida.getRlanoaso()).
									concat(liquida.getRlregimen()).
									concat(liquida.getRlnumaso()).
									concat(liquida.getRltdocum()).
									concat(liquida.getRldigver()).
									concat(liquida.getRlsufijo()));
							if (liquida.getRltipliq().equals("0038") && liquida.getRltdocum().equals("25")) {
								mapLiquida.put("tipoLiqui", "01");
							} else if (liquida.getRltipliq().equals("0022")) {
								mapLiquida.put("tipoLiqui", "02");
							} else {
								mapLiquida.put("tipoLiqui", "03");
							}
							lstLiquida.add(mapLiquida);
						}
					}
				}
				
				// Verificando si tiene pago en otras entidades
				CabDocpago tmpCabDocpago = new CabDocpago();
				tmpCabDocpago.setCodAduaaso(Cadena.padLeft(dua.getCodaduanaorden(), 3, '0'));
				tmpCabDocpago.setAnnDeclaso(dua.getAnnpresen());
				tmpCabDocpago.setNumDeclaso(Integer.valueOf(lcNumDUA));
				tmpCabDocpago.setCodRegiaso(dua.getCodregimen());
				tmpCabDocpago.setIndSufijo("00");
				lstCabDocpago = cabDocpagoDAO.selectBySelective(tmpCabDocpago);
				if (lstCabDocpago.size()>0) {
					mapRespuesta.put("lstCabDocpago", lstCabDocpago);
				}
				mapRespuesta.put("lstLiquida", lstLiquida);
			} 
			
			/* Inicio erodriguezb RIN10 */
			List<HashMap> listaWarnings = new ArrayList();
			if(variablesIngreso.containsKey("listaWarnings")){
				listaWarnings = (List<HashMap>) variablesIngreso.get("listaWarnings");
			}
			
			mapRespuesta.put("listaWarnings", listaWarnings);
			/* Fin erodriguezb RIN10 */
			
		}
		return mapRespuesta;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> obtenerDatosSolicitudRetiRegul (Declaracion declaracion, String codTransaccion, Long numCorreSol,Map<String, Object> variablesIngreso) {
		Map<String, Object> mapRespuesta = new HashMap();
		mapRespuesta.put("encontro", "NO");
		List<CabDeuda> lstCabDeuda = new ArrayList();
		List<HashMap> lstLiquida = new ArrayList(); 
		List<CabDocpago> lstCabDocpago = new ArrayList();
		String lcTipoTrans = "";
		String lccodTipLiqui = "";
		Long numCorredoc = 0L;
		
		String numOrden 		= (String) variablesIngreso.get("numOrden");
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		}
		String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		
		if (numCorreSol==null) {
			return mapRespuesta;
		}
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		if (lcTipoTrans.equals(TRANSACCION_RECTIFICACION)) {
			lccodTipLiqui = TIPO_LIQUI_RECTIFICACION;
		} else if (lcTipoTrans.equals(TRANSACCION_REGULARIZACION_ANT) || lcTipoTrans.equals(TRANSACCION_REGULARIZACION_URG)) {
			lccodTipLiqui = TIPO_LIQUI_REGULARIZACION;
		}
		
		String msgNotif = SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif")))?" ":SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif"));
		
		Map<String, Object> params = new HashMap();
		//params.put("NUM_CORREDOC_PRE", numCorreSol);
		params.put("NUM_CORREDOC", numCorreSol);
		Map<String, Object> mapSolicitud = solicitudDAO.findByPk(params);
		if (mapSolicitud==null) {
			return mapRespuesta;
		}
		String lcNumDUA = Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre(), 6, '0');
		params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
		params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
		params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
		params.put("numeroDeclaracion", lcNumDUA);
		DUA dua = cabDeclaraDAO.findDUAByMap(params);
		if (dua!=null) {
			numCorredoc = dua.getNumcorredoc();
			
			mapRespuesta.put("encontro", "SI");
			mapRespuesta.put("numCorreSol", Cadena.padLeft(mapSolicitud.get("NUM_SOL").toString(), 6, '0'));
			mapRespuesta.put("declaracion", declaracion.getNumdeclRef().getCodaduana().concat("-").
					concat(declaracion.getNumdeclRef().getAnnprese()).concat("-").
					//Inicio - RIN 10 - BUG 21930 - Percy HM - Se agrega el codigo de regimen de la declaracion
					concat(declaracion.getNumdeclRef().getCodregimen()).concat("-").
					//Fin - RIN 10 - BUG 21930
					concat(lcNumDUA));
			mapRespuesta.put("anoPrese", mapSolicitud.get("ANN_SOL"));
			mapRespuesta.put("codiAduan", mapSolicitud.get("COD_ADUANA"));
			mapRespuesta.put("codTransaccion", codTransaccion);
			mapRespuesta.put("dua", dua);
			mapRespuesta.put("tipoDocum", " ");
			mapRespuesta.put("digiVeri", " ");
			mapRespuesta.put("tipoAforo", " ");
			mapRespuesta.put("tipoManif", " ");
			mapRespuesta.put("msgNotif", msgNotif);
			mapRespuesta.put("funResumen", " ");
			mapRespuesta.put("sufijo", " ");
			mapRespuesta.put("fecCance", (new FechaBean("00010101","yyyyMMdd")).getSQLDate());
			mapRespuesta.put("bancCance", " ");
			mapRespuesta.put("montoCance", new BigDecimal("0"));
			mapRespuesta.put("totpDolar", new BigDecimal("0"));
			mapRespuesta.put("tipoCambio", new BigDecimal("0"));
			mapRespuesta.put("slibPecos", "N");
			mapRespuesta.put("lstCabDeuda", lstCabDeuda);
			mapRespuesta.put("lstLiquida", lstLiquida);
			mapRespuesta.put("lstCabDocpago", lstCabDocpago);
			mapRespuesta.put("tipoCambio", " ");
			mapRespuesta.put("fIngreso", mapSolicitud.get("FEC_SOLICITUD").toString());
			mapRespuesta.put("fecUltDiaPago", (new FechaBean("00010101","yyyyMMdd")).getSQLDate());
			
			//Se a�ade el mensaje de Notificacion de Mandato
			if (lcTipoTrans.equals(TRANSACCION_RECTIFICACION)) {
				msgNotif = "Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ").concat(msgNotif).concat(" ha sido recepcionada y Aceptada.");
				// si es Rectificacion no es definitiva
				if(SunatStringUtils.isEqualTo("02", (String)variablesIngreso.get("codEstadoRecti"))){
					Boolean blTieneManifiestoMedidaPreve=(Boolean)variablesIngreso.get("blTieneMedPreveManif");
					Boolean blTieneDuaMedidaPreve=(Boolean)variablesIngreso.get("blDuaTieneMedPreveDua");
					Boolean blTieneAvisoInspencion=(Boolean)variablesIngreso.get("blTieneAvisoInspencion");
		      		if( (blTieneDuaMedidaPreve!=null && blTieneDuaMedidaPreve.booleanValue()) 
		      				|| (blTieneManifiestoMedidaPreve!=null && blTieneManifiestoMedidaPreve.booleanValue())
		      				|| (blTieneAvisoInspencion!=null && blTieneAvisoInspencion.booleanValue())
		      			){
		      			
						msgNotif="Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada. ").concat("La mercanc�a por contar con una medida preventiva ser� evaluada por un funcionario aduanero");
		      		}
		      		else{
		      			msgNotif="Solicitud de rectificacion de la Declaracion ".concat(mapRespuesta.get("declaracion").toString()).concat(" ha sido recepcionada y se encuentra como Pendiente de Evaluaci�n para ser evaluada por un Funcionario Aduanero.");
		      		}
				}
				mapRespuesta.put("msgNotif", msgNotif);
			}
			SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyyMMdd");
			BigDecimal tipoCambio = new BigDecimal("0");
			Map<String,Object> mapCambio1 = new HashMap<String,Object>();
			mapCambio1.put("fingreso", formatoDelTexto.format(dua.getFecdeclaracion()));
			mapCambio1.put("cmoneda", "USD");
//			Cambio1 cambio1 = cambio1DAO.findByPK(mapCambio1);
			mapCambio1.put("ayudaID", "Cambio1");
			Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(mapCambio1);
			if (cambio1!=null) {
				tipoCambio = cambio1.getPventa();
				mapRespuesta.put("tipoCambio", tipoCambio);
			}
			
			/*branch ingreso-2011-009 hosorio inicio 13/06/2011*/
						

			// Verificando la Deuda
			DeudaDocum tmpDeudaDocum = new DeudaDocum();
			DeudaDocum deudaDocum = null;
			tmpDeudaDocum.setNumCorredoc(numCorredoc);
			/*branch ingreso-2011-009 hosorio inicio 16/05/2011*/
			tmpDeudaDocum.setCodTipdeuda("01");
			/*branch ingreso-2011-009 hosorio fin 16/05/2011*/
			List<DeudaDocum> tmpListDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
			for (DeudaDocum xDeudaDocum:tmpListDeudaDocum) { // Para obtener el ultimo y que no est� pagado.
				if (xDeudaDocum.getMtoPagado().compareTo(new BigDecimal("0"))==0) {
					deudaDocum = xDeudaDocum; 
				}
			}
			params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
			params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
			params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
			params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
			if (deudaDocum!=null) {
				Integer numIdentdeuda = deudaDocum.getNumIdentdeuda();
				mapRespuesta.put("totpDolar", deudaDocum.getMtoDeuda());
				mapRespuesta.put("sufijo", Cadena.padLeft(deudaDocum.getNumReliq().toString().trim(), 2, '0'));
				MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
				tmpMovCabliqdilig.setCodAduDocliq(Cadena.padLeft(declaracion.getNumdeclRef().getCodaduana(), 3, '0'));
				tmpMovCabliqdilig.setCodRegDocliq(declaracion.getNumdeclRef().getCodregimen());
				tmpMovCabliqdilig.setCodTipLiqui(lccodTipLiqui);
				tmpMovCabliqdilig.setCodTipdiligencia(" ");
				tmpMovCabliqdilig.setNumReliq(deudaDocum.getNumReliq());
				tmpMovCabliqdilig.setAnnDocliq(declaracion.getNumdeclRef().getAnnprese());
				tmpMovCabliqdilig.setNumDocliq(lcNumDUA);
				tmpMovCabliqdilig.setAnnOrden(lcAnn_orden);
				tmpMovCabliqdilig.setNumOrden(lcNume_orden);
				tmpMovCabliqdilig.setCodAgente(numeroDocumentoIdentidadSender);
				//MovCabliqdilig movCabliqdilig = movCabliqdiligDAO.selectByPrimaryKey(tmpMovCabliqdilig);
				FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
				MovCabliqdilig movCabliqdilig = funcionesLiquidacionService.obtenerCabeceraPreliquidacionPorPK(tmpMovCabliqdilig);

				if (movCabliqdilig!=null) {
					if (movCabliqdilig.getIndPoliLiber().equals("2") || movCabliqdilig.getIndPoliLiber().equals("3") || movCabliqdilig.getIndPoliLiber().equals("6")) {
						mapRespuesta.put("slibPecos", "S");
					} 
				}
				mapRespuesta.put("fecUltDiaPago", deudaDocum.getFecVenc());
				CabDeuda tmpCabDeuda = new CabDeuda();
				tmpCabDeuda.setNumCorredoc(numCorredoc);
				tmpCabDeuda.setNumIdentdeuda(numIdentdeuda);
				lstCabDeuda = cabDeudaDAO.selectByDeuda(tmpCabDeuda);
				mapRespuesta.put("lstCabDeuda", lstCabDeuda);
				
				// Se obtiene lista de LCs
				Liquida tmpLiquida = new Liquida();					
				tmpLiquida.setRladuaso(Cadena.padLeft(declaracion.getNumdeclRef().getCodaduana(), 3, '0'));
				tmpLiquida.setRlanoaso(declaracion.getNumdeclRef().getAnnprese().substring(2, 4));
				tmpLiquida.setRlnumaso(lcNumDUA);
				List<Liquida> lstLiquidaAux = liquidaDAO.selectSelectivo(tmpLiquida);
				if (lstLiquidaAux!=null && lstLiquidaAux.size()>0) {
					for (Liquida liquida: lstLiquidaAux) {
						Integer lnFechActual;
						try {
							lnFechActual = Integer.valueOf(DateUtil.dateToString(new FechaBean().getSQLDate(), "yyyyMMdd"));
						} catch (NumberFormatException e) {
							lnFechActual = 00010101;
						} catch (ParseException e) {
							lnFechActual = 00010101;
						}
						/*branch ingreso-2011-009 hosorio inicio 16/05/2011*/
						//if (liquida.getRlfeccan().equals(0) && liquida.getRlfecliq().equals(lnFechActual)) {
						if (liquida.getRlfeccan().equals(0) && liquida.getRlfecliq().equals(lnFechActual) 
								&& liquida.getRlfeceli().equals(0) ) 
						{
						/*branch ingreso-2011-009 hosorio fin 16/05/2011*/
							HashMap mapLiquida = new HashMap();
							/*branch ingreso-2011-009 hosorio inicio 16/05/2011*/	
							//mapLiquida.put("moneda", liquida.getRlcodmon());
							mapLiquida.put("moneda", liquida.getRlcodmon().equals("S")?"PEN":"USD");
							/*branch ingreso-2011-009 hosorio fin 16/05/2011*/
							mapLiquida.put("nroLC", liquida.getRladuana().concat("-").
									concat(liquida.getRlano()).concat("-").concat(liquida.getRlnroliq()));//erodriguezb RIN10 bug 21774
							mapLiquida.put("monto", liquida.getRlcodmon().equals("S")?liquida.getRlsmontot():liquida.getRldmontot());
							mapLiquida.put("cda", liquida.getRladuaso().
									/*branch ingreso-2011-009 hosorio inicio 16/05/2011*/
									concat(liquida.getRlanoaso()).
									/*branch ingreso-2011-009 hosorio fin 16/05/2011*/
									concat(liquida.getRlregimen()).
									concat(liquida.getRlnumaso()).
									concat(liquida.getRltdocum()).
									concat(liquida.getRldigver()).
									concat(liquida.getRlsufijo()));
							if (liquida.getRltipliq().equals("0038") && liquida.getRltdocum().equals("25")) {
								mapLiquida.put("tipoLiqui", "01");
							} else if (liquida.getRltipliq().equals("0022")) {
								mapLiquida.put("tipoLiqui", "02");
							} else {
								mapLiquida.put("tipoLiqui", "03");
							}
							lstLiquida.add(mapLiquida);
						}
					}
					mapRespuesta.put("lstLiquida", lstLiquida);
				}
				
			} 
			/* Inicio erodriguezb RIN10 */
			List<HashMap> listaWarnings = new ArrayList();
			if(variablesIngreso.containsKey("listaWarnings")){
				listaWarnings = (List<HashMap>) variablesIngreso.get("listaWarnings");
			}
			
			mapRespuesta.put("listaWarnings", listaWarnings);
			/* Fin erodriguezb RIN10 */
		}
		
		return mapRespuesta;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public CabDeudaDAO getCabDeudaDAO() {
		return cabDeudaDAO;
	}

	public void setCabDeudaDAO(CabDeudaDAO cabDeudaDAO) {
		this.cabDeudaDAO = cabDeudaDAO;
	}

	public DeudaDocumDAO getDeudaDocumDAO() {
		return deudaDocumDAO;
	}

	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}

	public MovCabliqdiligDAO getMovCabliqdiligDAO() {
		return movCabliqdiligDAO;
	}

	public void setMovCabliqdiligDAO(MovCabliqdiligDAO movCabliqdiligDAO) {
		this.movCabliqdiligDAO = movCabliqdiligDAO;
	}

	public LiquidaDeclaracionService getLiquidaDeclaracionService() {
		return liquidaDeclaracionService;
	}

	public void setLiquidaDeclaracionService(
			LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}

	public Cambio1DAO getCambio1DAO() {
		return cambio1DAO;
	}

	public void setCambio1DAO(Cambio1DAO cambio1dao) {
		cambio1DAO = cambio1dao;
	}

	public LiquidaDAO getLiquidaDAO() {
		return liquidaDAO;
	}

	public void setLiquidaDAO(LiquidaDAO liquidaDAO) {
		this.liquidaDAO = liquidaDAO;
	}

	public CabDocpagoDAO getCabDocpagoDAO() {
		return cabDocpagoDAO;
	}

	public void setCabDocpagoDAO(CabDocpagoDAO cabDocpagoDAO) {
		this.cabDocpagoDAO = cabDocpagoDAO;
	}

	public SolicitudDAO getSolicitudDAO() {
		return solicitudDAO;
	}

	public void setSolicitudDAO(SolicitudDAO solicitudDAO) {
		this.solicitudDAO = solicitudDAO;
	}

	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

}