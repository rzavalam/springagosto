/*
 * Clase que define el servicio de validaciones de la Informacion de Costeo de adecuaciones a vehiculos
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Map;

/**
 * The Class ValVehiculo. Clase que define el servicio de validaciones de la Informacion de Costeo de adecuaciones a vehiculos.
 */
public interface ValVehiculo {
	
	public Map<String, String> numitemb(String numitemb);
	
	public Map<String, String> nomlibro(String nomlibro);
	
	public Map<String, String> codejempl(String codejempl);
	
	public Map<String, String> annmespubli(String annmespubli);
	
	public Map<String, String> numpagin(Integer numpagin);
	
	public Map<String, String> numfactconve(BigDecimal numfactconve);

}
