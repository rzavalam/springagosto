package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.SecuenciaPerdida;

/**
 * 
 * @author rcalla
 * Interfaz del servicio de manejo de secuencias de negocio para la numeracion de la DUA
 */
public interface SecuenciaDeclaracionService {

	/**
	 * Establece la secuencia que se usara para la declaraci�n.  
	 * @return Secuencia creada, en caso no este registrada en BD tiene el campo fechaRegistro == null
	 */
	SecuenciaPerdida generaSecuenciaDeclaracion( Declaracion declaracion );
	
	/**
	 * Actualiza la secuencia perdida en base de datos.
	 * @param secuenciaPerdida
	 */
	void actualizarSecuencia(SecuenciaPerdida secuenciaPerdida);
	void tomarSecuencia(SecuenciaPerdida secuenciaPerdida);	
	
	/**
	 * Crea la secuencia perdida en BD. 
	 * @param secuenciaPerdida
	 */
	void registrarSecuencia(SecuenciaPerdida secuenciaPerdida);
	
	void actualizarSecException(SecuenciaPerdida secuenciaPerdida);
	
	/**
	 * M�todo que devuelve el numero de correlativo seg�n el secuencial
	 * 
	 * @author lrodriguezc - RIN15
	 * @param nombreSecuencia
	 * @return
	 */
	public Long obtenerCorrelativo(String aduana, String tipoSolicitud);
	
	public SecuenciaPerdida consultarSecuencia(SecuenciaPerdida secuenciaTmp);
	
	/**
	 * Dado un nombre de secuencia retorna su secuencial
	 * @param nomSecuencia
	 * @return
	 */
	public Long obtenerSecuencia(String nomSecuencia);
}
