/*
 * Clase que define el servicio de validaciones de los participantes del formato A de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;

/**
 * The Class ValParticipante. Clase que define el servicio de validaciones de los participantes del formato A de la DUA.
 */
public interface ValParticipante {

	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante, String codError);
	
	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante,String codTipPartOblig, String codError);
	
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad, String codError);
	
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad, 
			String codTipoDocOblig, String codError);
	
	public Map<String, String> numeroDocumentoIdentidad(String numeroDocumentoIdentidad, String codError, DataCatalogo tipoDocumentoIdentidad);
	
	public Map<String, String> pais(DataCatalogo pais, String codError);
	
	public Map<String, String> nombreRazonSocial(String nombreRazonSocial, String codError);
	
	public Map<String, String> direccion(String direccion, String codError);
	
	public Map<String, String> ciudad(String ciudad, String codError);
	
	public Map<String, String> telefono(String telefono, String codError);
	
	public Map<String, String> fax(String fax, String codError);
	
	public Map<String, String> email(String email, String codError);
	
	public Map<String, String> paginaWeb(String paginaWeb, String codError);
}
