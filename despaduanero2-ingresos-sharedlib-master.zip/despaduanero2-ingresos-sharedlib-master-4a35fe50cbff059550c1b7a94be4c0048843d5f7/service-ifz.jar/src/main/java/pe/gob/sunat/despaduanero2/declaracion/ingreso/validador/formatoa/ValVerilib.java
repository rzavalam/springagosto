/*
 * Clase que define el servicio de validaciones de codigos liberatorios.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

/**
 * The Class ValVerilib. Clase que define el servicio de validaciones de codigos liberatorios.
 */
public interface ValVerilib {
	
	public Map<String,Object> verilib(String tipo_lib,String codi_libe,String codi_part, String codi_pais, String mcnaladisa,String mtmargen, String mpide_naladisa,String mcnabandina,boolean tienenalad, DUA dua, DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) throws Exception;
	
}
