package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TabLibe;
import pe.gob.sunat.despaduanero2.declaracion.model.Triblibe;
import pe.gob.sunat.servicio2.registro.model.bean.T1179Bean;

public interface PreferenciaArancelariaService {

	public List<CodiLibe> obtenerPreferenciaArancelariaVigente(String tipoliber, Integer codConvenio, Date fechaReferencia);
	
	public T1179Bean consultarImportadorAltoAndino(String tipodocum, String numedocum);
	
	public String consultarUbigeoImportadorPreferenciaArancelaria(String tipodocum, String numedocum);
	
	public TabLibe obtenerPreferenciaArancelaria(String tipoliber, Integer codConvenio);
	
	// DZC: SAU20143N002000372 se coloca parametro Integer fecha_nume valida con la fecha de numeraci�n.
	public List<Triblibe> obtenerImporConPreferenciaArancelaria(String tipoliber, Integer codConvenio, String tipodocum, String numedocum,Integer fecha_nume);
	
	public Boolean existExoneracionPreferenciaArancelaria(String tipoliber, Integer codConvenio, Long numpartnandi, Date fechaReferencia);

	//P46
	public boolean tienePreferencuaArancelaria (Integer codigoTPN, Integer codigoTPI);
}
