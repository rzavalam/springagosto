/*
 * Clase que define el servicio de validaciones generales sobre la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValNegocAduahdr1FormA. Clase que define el servicio de validaciones generales sobre la DUA.
 */
public interface ValNegocAduahdr1FormA {
	
	public List<Map<String, String>> valAduahdr1(Declaracion declaracion, String tipoSender, String codTransaccion, String numOrden, String annEnvio);
	
	public Map<String,Object> valDeclarante(List<Map<String,String>> listError, Integer vfechingsi, Participante declarante);
	
	public boolean existeRegPrecedencia(Elementos<DatoSerie> series);
	
}
