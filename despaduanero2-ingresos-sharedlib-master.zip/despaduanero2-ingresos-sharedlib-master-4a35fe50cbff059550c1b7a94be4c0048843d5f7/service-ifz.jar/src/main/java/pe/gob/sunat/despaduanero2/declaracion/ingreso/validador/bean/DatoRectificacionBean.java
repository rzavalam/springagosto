package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean;

public class DatoRectificacionBean {
  private Object datoAntiguo;
  private Object datoNuevo;
  private String objectPath;
  private String xmlPath;
  private String flagBloqueo;
  private String tipoRectificacion;
  private Object objetoPadre;

public void setDatoNuevo(String datoNuevo) {
	this.datoNuevo = datoNuevo;
}

public Object getDatoAntiguo() {
	return datoAntiguo;
}
public void setDatoAntiguo(Object datoAntiguo) {
	this.datoAntiguo = datoAntiguo;
}
public Object getDatoNuevo() {
	return datoNuevo;
}
public void setDatoNuevo(Object datoNuevo) {
	this.datoNuevo = datoNuevo;
}
public DatoRectificacionBean(Object datoNuevo, Object datoAntiguo) {
	super();
	this.datoAntiguo = datoAntiguo;
	this.datoNuevo = datoNuevo;
}
public DatoRectificacionBean(Object datoNuevo) {
	super();
	this.datoNuevo = datoNuevo;
}

public String getObjectPath() {
	return objectPath;
}

public void setObjectPath(String objectPath) {
	this.objectPath = objectPath;
}

public String getXmlPath() {
	return xmlPath;
}

public void setXmlPath(String xmlPath) {
	this.xmlPath = xmlPath;
}

public String getFlagBloqueo() {
	return flagBloqueo;
}

public void setFlagBloqueo(String flagBloqueo) {
	this.flagBloqueo = flagBloqueo;
}

public String getTipoRectificacion() {
	return tipoRectificacion;
}

public void setTipoRectificacion(String tipoRectificacion) {
	this.tipoRectificacion = tipoRectificacion;
}

public Object getObjetoPadre() {
	return objetoPadre;
}

public void setObjetoPadre(Object objetoPadre) {
	this.objetoPadre = objetoPadre;
}



  
}
