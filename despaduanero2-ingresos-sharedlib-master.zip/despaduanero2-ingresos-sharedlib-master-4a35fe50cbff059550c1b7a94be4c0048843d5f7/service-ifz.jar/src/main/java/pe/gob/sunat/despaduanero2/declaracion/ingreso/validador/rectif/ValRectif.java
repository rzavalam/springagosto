/*
 * Clase que define el servicio de validaciones de la rectificacion/regularizacion
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
//import pe.gob.sunat.despaduanero2.declaracion.model.Depocta;

/**
 * @author hosorio
 *
 */
public interface ValRectif{
	
	public Map<String, Object> setupDeclaracion(Declaracion declaracion, String numOrden, String codUsuario, Integer annEnvio, Long numEnvio,
			String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String codTransaccion) ;
	
	public Map<String, Object> setupManifiesto(Declaracion declaracion, Map<String, Object> variablesIngreso);
	
	public Map<String, ?> obtfecvalidacion(String codTransaccion, Declaracion declaracion);
	
	public Map<String, Object> formobjval(Declaracion declaracion);
	
	public Map<String, String> transaccion(String codTransaccion);
	
	public Map<String, String> existedua(Declaracion declaracion);
	
	public Map<String, String> transmitioregul(Declaracion declaracion, Declaracion declaracionBD) throws Exception;
	
	public Map<String, String> Solrectieneval(Declaracion declaracion);
	
	public Map<String, Object> CamposRectiOficio(Declaracion declaracion);
	
	
	public Map<String, Object> Compobjvalobjnum(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception ;

	public List<Map<String, String>> Complistaconrectioficio(SolicitudRectificacionBean solicitudRectificacion,List<DetSolicitudRectificacionBean> rectificacionesOficio) throws Exception;
	
	public Map<String, String> Tienedudaraz(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion) throws Exception ;
	

	public Map<String, String> Tieneformatob(Declaracion declaracionBD) throws Exception ;
	
	public Map<String, String> Afectaart15lga(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception;
	
	public Map<String, String> Valtpnvehiculo(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception ;
	
	public Map<String, String> MarcaAfectaDesafectaCuentaAutoUsado(Declaracion declaracion, Declaracion declaracionBD,Map<String, Object> variablesIngreso) throws Exception; 
	
	public List<Map<String, ?>> Infoparadatado(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception; 
	
	public List<Map<String, ?>> Marcadesdatadodatado(Declaracion declaracion, Map<String, Object> variablesIngreso, Declaracion declaracionBD)
			throws Exception;
	
	public Map<String, String> Estadoruc(Declaracion declaracion) throws Exception ;
	
	public Map<String, String> Cambiomodalidad(Declaracion declaracion) throws Exception;
	
	public Map<String, String> Sustento(Declaracion declaracion) throws Exception;
	
	public Map<String, Boolean> Afectaart150(Declaracion declaracion) throws Exception;
	
	public Map<String, String> Afectaart15lgaAnticipado(Declaracion declaracionBD) throws Exception;
	
	public Map<String, Boolean> Solirectiprevia(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception;
	
	public List<Map<String, String>> validarAgente(Declaracion declaracion, Declaracion declaracionBD, String numOrden,
			String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String codigoAduanaOrden, String codTransaccion) throws Exception;
	
	public List<Map<String, String>> validaEstadoDUA(Declaracion declaracionBD);
	
	//public List<Map<String, String>> valCtCteDeposito(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
	//		throws Exception;
	
	public List<Map<String, ?>> existeCambios(SolicitudRectificacionBean solicitudRectificacion);
	
	public boolean esDatoRectificado(SolicitudRectificacionBean solicitudRectificacion, String nombreCampo);
	
	public List<Map<String, ?>> validarSoloCambioAnticipadoAExcepcional(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion);
	
	public List<Map<String, ?>> validarSoloCambioIndicadorRegularizacion(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion);
	
	public List<Map<String, ?>> validarSoloCambioPuntoLlegadaDepositoTemporal(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion);
	
	public List<Map<String, ?>> validarOtrasCondicionesParaRectificacionAutomatica(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion, Declaracion declaracionBD);
	
	
	public List<Map<String, String>> afectaArticulo199(Declaracion declaracion);
	
	public List<Map<String, ?>> afectaArticulo200(Declaracion declaracion);
	
	public List<Map<String, String>> validarGarantia(Declaracion declaracion,Declaracion declaracionBD);
	
	public Map<String, String> Norectifiagente(Declaracion declaracion , Declaracion declaracionBD) throws Exception;
	
	public Map<String, String> validaDespachoRectificacion(Declaracion declaracion) throws Exception;

	public List<Map<String, String>> validaActaInmovilizacion(Declaracion declaracion,Map<String, Object> variablesIngreso);

	public List<Map<String,Object>> obtenerMedidasPreventivaDocTransporte(Declaracion declaracion ,DatoDocTransporte docTrans, String[] tiposActas);
	
	public  List<Map<String,String>>  validarDescargosRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception;
	//mordonezl pase70
	public Map<String, Object> cargarManifiestoBD(Declaracion declaracion, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarAgenteAduana(Declaracion declaracion, Declaracion declaracionBD, String numOrden,
			String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String codigoAduanaOrden,String codTransaccion) throws Exception; 
	
	
	//fin mordonezl
	

	/*RIN10-INICIO-AFMA*/
	public boolean validaIndicadorVP(Declaracion declaracionBD)  throws Exception;
	public boolean validaIndicadorLCVP(Declaracion declaracionBD) throws Exception;
	public List<Map<String,String>> validarTransmisionValorProvisional(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception;
	/*RIN10-FIN-AFMA*/
	
	/**
     * Se encarga de cargar por unica vez declaracionBD en variablesIngreso. Se carga declaracionBD con el key "declaracionBDParaValidacionTLC"
     * Proyecto msnade236_1
     * @author glazaror
     * @param declaracion declaracion transmitida
     * @param declaracionBD declaracion en base datos
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return errores de validacion
     **/
	public Map<String, Object> cargarDatosDeclaracionBD(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso);
	
	//TLC 2016-66
	public Map<String, Object> cargarDatosSolicitud(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception;
	
	/**
	 * @author rtineo 
	 * M_SNADE278, Numeracion, Rectificacion DAM sin ICA
	 */
	public Map<String,Object> validarDAMRegistradoEsDiferidaSinICA(Declaracion declaracionBD, Map<String, Object> variablesIngreso);
	public Map<String, String> validarRectiPuntoLlegadaDAMDiferidaSinICA(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso);
	public Map<String,String> validarCambioPuntoLlegadaDTaTP(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso);
	/**fin M_SNADE278 **/
}

