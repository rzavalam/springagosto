/*
 * Clase que define el servicio de validaciones de Certificado de Origen
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValAutocer.
 * Clase que define el servicio de validaciones de Certificado de Origen
 */
public interface ValAutocer {
	
	public Map<String, String> codidcertorigen(String codidcertorigen);
	public Map<String, String> codtipoCO(String codtipoCO);
	public Map<String, String> codtipoemisorCO(String codtipoemisorCO);
	public Map<String, String> nomemisorCO(String nomemisorCO);
	public Map<String, String> nomemisorCO(String nomemisorCO, String numserie, String codTipoCO, String codError);
	public Map<String, String> numdocumento(String numdocumento);
	public Map<String, String> numdocumento (String numdocumento, String numserie, String codTipoCO);
	public Map<String, String> fecemision(Date fecemision);
	public Map<String, String> fecemision (Date fecemision, String numserie, String codTipoCO);
	public Map<String, String> valfecemisionPlazoAnios (Date fecemision, Date fecreferencia, Integer anios, String numserie, String codErr1, String codErr2);
	public Map<String, String> valfecemisionPlazoDias (Date fecemision, Date fecreferencia, Integer dias, String numserie, String codErr1, String codErr2);
	public Map<String, String> valfecemisionPlazoMeses (Date fecemision, Date fecreferencia, Integer meses, String numserie, String codErr1, String codErr2);
	public Map<String, String> feciniembarque(Date feciniembarque);
	public Map<String, String> fecfinembarque(Date fecfinembarque);
	public Map<String, String> fecfinembarque(Date fecfinembarque, Date feciniembarque);
	public List<Map<String,String>>  fecinifinembarque(Date fecfinembarque, Date feciniembarque, String numserie);
	
	/**
     * Se encarga de validar que la fehca de inicio y fin de embarque sean correctos (distintos de null y fecha default 01/01/0001).
     * Proyecto msnade236_1
     * @author glazaror
     * @param fechaFinEmbarque fecha de fin de embarque
     * @param fechaInicioEmbarque fecha de inicio de embarque
     * @param numeroSerie numero de la serie evaluada
     * @return errores de validacion
     **/
	public List<Map<String,String>> validarFechaInicioFinEmbarque(Date fechaFinEmbarque, Date fechaInicioEmbarque, String numeroSerie);
	//TLC Corea - SIGESI
	public Map<String, String> valfecemisionPlazoMesesSinRestriccion (Date fecemision, Date fecreferencia, Integer meses, String numserie, String codErr);
	public Map<String, String> valfecemisionPlazoDiasSinRestriccion (Date fecemision, Date fecreferencia, Integer dias, String numserie, String codErr);
	public Map<String, String> valfecemisionPlazoAniosSinRestriccion (Date fecemision, Date fecreferencia, Integer anios, String numserie, String codErr);
	//fin TLC Corea
	
	
	public Map<String, String> fecembarque(Date feciniembarque, Date fecfinembarque, Date fecembarque, String numserie);
	public Map<String, String> fecembarque(Date fecembarque, Date fecemision, String numserie);
	public Map<String, String> desmercancia(String desmercancia);
	public Map<String, String> nomproduc(String nomproduc, String codTipoCO, String numserie );
	public Map<String, String> codcriterioCO(String codcriterioCO);
	public Map<String, String> indtrans(String indtrans);
	public Map<String, String> codffco(String codffco);
	public Map<String, String> valcodffco(String numserie, String codffco);
	public Map<String, String> numautoexp (String numautoexp,  String numserie);
	public Map<String,String> numsecCO(Integer numsecCO);
	public Map<String, String> numdocumentoSN (String numdocumento, String numserie);
	public Map<String, String> combinarNumCOFechaFuncionario(String numdocumento, Date fecemision, String codffco, String numserie, String codTipoCO);
	public Map<String, String> sinCombinarNumCOFechaFuncionario(String numdocumento, Date fecemision, String codffco, String numserie, String codTipoCO);
	public List<Map<String, String>> sinEnviarNumCOEmisorFecha(String numdocumento, Date fecemision, String codtipoemisorCO, String nomemisorCO, String numserie, String codTipoCO);
	public Map<String, String> codmoneda (String codmoneda, String numserie, Map<String,Object> variablesIngreso);
	public Map<String, String> codmoneda (String codmoneda, String numserie);
	public Map<String, String> mtofobmon (BigDecimal mtofobmon, String numserie);
	public List<Map<String, String>> valDatosFactura(String codmoneda, BigDecimal mtofobmon, String numserie, Map<String,Object> variablesIngreso);
	public List<Map<String, String>> valDatosFactura(String codmoneda, BigDecimal mtofobmon, String numserie);
	public List<Map<String, String>> valDatosFacturaCondicional(String codmoneda, BigDecimal mtofobmon, String numserie, Map<String,Object> variablesIngreso);
	public List<Map<String, String>> valDatosFacturaCondicional(String codmoneda, BigDecimal mtofobmon, String numserie);
}
