package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;

public interface ControlVigenciaService {
	public boolean esVigenteRIN05(Date fechaReferencia);
	public boolean esVigenteRIN05PrimeraParte(Date fechaReferencia);
	public boolean esVigenteRIN05SegundaParte(Date fechaReferencia);
    public boolean esVigentePecoAmazoniaSegundaParte(Date fechaReferencia);
    public boolean esVigenteRIN31(Date fechaReferencia);//PAS20181U220200054
	public boolean esVigenteRIN05SegundaParteII(Date fechaReferencia);
}
