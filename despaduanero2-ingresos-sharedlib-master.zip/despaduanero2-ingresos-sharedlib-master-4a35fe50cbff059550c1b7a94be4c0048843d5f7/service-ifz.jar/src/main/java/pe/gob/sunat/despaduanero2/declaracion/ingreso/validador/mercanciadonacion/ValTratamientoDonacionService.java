package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;//P46-PAS20155E410000032

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
public interface ValTratamientoDonacionService {

	
	public List<Map<String, String>> validarDeclaracionTipoDonacion(Declaracion declaracion);
		
	
	//EJHM P46

	public String validarCodigoLiberatorioDonacion(HttpServletRequest request);//P46-PAS20155E410000032
	public List<Map<String,String>> validarSinCodigoLiberatorio (Declaracion declaracion);
	public List<Map<String, String>> validarDeclaracionTipoDonacionDiligencia(Declaracion declaracion ,Declaracion declaracionBD);
	
	public List<Map<String,String>> validarTipodeDocumentoAsociadoDoconacion(Declaracion declaracion,boolean flagTratamientoDoncion,boolean flagDiligencia );
	//public List<Map<String,String>> validarTieneDocumentoAutorizante (Declaracion declaracion);
	//EJHM
	public String validarTieneDocumentoAutorizante(Declaracion declaracion, boolean tieneIndicadorImpugnacion,boolean flagDiligencia);
//	public List<Map<String,String>> validarTieneDocumentoDonacion(Declaracion declaracion,boolean flagTratamientoDoncion,boolean flagDiligencia );
   // FIN EJHM
	/** inicio mpoblete P46_F23013_CUS02.06**/
	public boolean esTipoTratamientoMercanciaDonacion(DUA dua);
	public boolean tieneRegimenImportacionConsumo(DUA dua);
	public boolean tieneIndicadorImpugnacionParcial(DUA dua);
	public boolean duaTieneIndicadorImpugnacionParcialOTotal(List<DatoIndicadores> listIndicadores);
	/** fin mpoblete P46_F23013_CUS02.06**/
	/** inicio mpoblete P46_F23013_CUS02.04**/
	public boolean esTipoDonacionConTipoCancelmpugnacionSinGarantia(DUA dua);
	public boolean tieneIndicadorImpugnacionParcialOTotal(DUA dua);	
	/** fin mpoblete P46_F23013_CUS02.04**/
	/** inicio mpoblete P46_F23013_CUS02.05**/
	public boolean esDonacionTipoCancelmpugnacionSinGarantiaLevanteElectronico(DUA dua);
	public boolean tieneCodigoLiberatorioDonacion(DUA dua);
	public void notificarRegularizacionDonacion(DUA dua);
	/** inicio mpoblete P46_F23013_CUS02.05**/
	/** inicio mpoblete P46_F23013_CUS02.02 **/
	public boolean esDonacionTipoCancelmpugnacionSinGarantiaAsignacionCanal(DUA dua);
	/** inicio mpoblete P46_F23013_CUS02.02 **/
	// Ini P46 3006
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion
	 */
	List<Map<String,String>> validarDocAutorizanteDonacionDiligencia(Declaracion declaracion);
	// Fin P46 3006
	/*INICIO - P46 - 3003*/
	public List<Map<String, String>> validarRegimenDeclaracion (Declaracion declaracion);
	public List<Map<String, String>> validarRegimenDeclaracion (Declaracion declaracion, String codError);
	public boolean validarTieneTratamientoDonacion (Declaracion declaracion);
	/*FIN - P46 - 3003*/
	//Inicio PAS20145E220000365 - mtorralba 20150323 - Atencion Bug 21231
	public boolean validarEsAyudaHumanitaria (List<DatoSerie> lstSeries);
	//Fin PAS20145E220000365 - mtorralba 20150323 - Atencion Bug 21231
	
	/*Inicio P46 - KAH*/
	public void validarIndicadorDuaenDonacion( Map<String, Object> declaracion);
	/*Fin P46 - KAH*/
	
	/*P46*/
	public List<Map<String,String>> validarEnvioFormatoB (Declaracion declaracion);
	/*FIN P46*/
	//P46-PAS20155E410000032
	public boolean declaTieneTipoCancelacion(Declaracion declaracion);
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25055*/
	public boolean habilitarIngresoDeIndicadorDonacion(Map<String,Object> params);
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25055*/
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25276*/
	List<Map<String,String>> validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(Declaracion declaracion);
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25276*/
	
	public boolean declaracionEstaCancelada(Declaracion declaracion);//P46-PAS20155E410000032-[jlunah]
}
//P46 30003 JMCV FIN
