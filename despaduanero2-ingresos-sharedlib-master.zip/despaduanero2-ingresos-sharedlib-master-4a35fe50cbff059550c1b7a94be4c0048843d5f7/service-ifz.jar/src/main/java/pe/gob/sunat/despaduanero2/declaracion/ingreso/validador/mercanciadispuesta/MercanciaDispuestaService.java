package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadispuesta;
/**
 * 
 */


import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercanciaDispuesta;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
/**
 * @author rpumacayo
 *
 */
public interface MercanciaDispuestaService {

	//Pase105 - Se comenta porque se probara en la rin 07 - parte II
	
	/**
	  * Servicio usado para validar si una serie tiene mercancia dispuesta. Invocado desde orquestador de servicios.
	  * @param  declaracion : Objeto que representa los datos de la declaracion
	  * @param  serie : Objeto que representa a una serie
	  * @return Map<String, ?> Mapa de Errores encontrado
	*/		
	/*public List<Map<String, String>> validarMercanciaDispuesta(
			Declaracion declaracion
    );*/
	
	/**
	  * Servicio usado para validar si una serie tiene mercancia dispuesta.
	  * @param  declaracion : Objeto que representa los datos de la declaracion
	  * @return boolean : Devuelve true, si la serie tiene mercancia dispuesta 
	*/
	public boolean tieneMercanciaDispuesta(
			Map declaracion	
	);
	
	/**
	  * Servicio usado para obtener el listado de mercancias dispuestas de una serie.
	  * @param  declaracion : Objeto que representa los datos de la declaracion
	  * @return boolean : Devuelve true, si la serie tiene mercancia dispuesta 
	*/	
	public List<DatoMercanciaDispuesta> listarMercanciaDispuesta(
			Map declaracion			
	);
}
