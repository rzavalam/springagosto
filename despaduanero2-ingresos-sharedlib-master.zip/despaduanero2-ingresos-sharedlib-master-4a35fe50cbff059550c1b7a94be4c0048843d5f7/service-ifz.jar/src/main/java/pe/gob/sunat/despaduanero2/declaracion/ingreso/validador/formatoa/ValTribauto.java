/*
 * Clase que define el servicio de validaciones de Relaci�n de  derechos.impuestos, recargos, tasas, e intereses autoliquidados.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Map;

/**
 * The Class ValTribauto. Clase que define el servicio de validaciones de Relaci�n de  derechos.impuestos, recargos, tasas, e intereses autoliquidados.
 */
public interface ValTribauto {
		
	public Map<String, String> codtributo(String codtributo);
	
	public Map<String, String> codmoneda(String codmoneda);
	
	public Map<String, String> mtovalortrib(BigDecimal mtovalortrib);
	
}
