package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarRectificacionService {

	
	public Map<String, String> grabarRectificacion(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion,
			Map<String, Object> deudadiferencial,
			Map<String, Object> variablesIngreso,Declaracion declaracionBD )  throws Exception;
	public Map<String, String> Grabacabydetsolicitud(Declaracion declaracion
			, SolicitudRectificacionBean solicitudRectificacion,String tipoSolicitud,String estadoSolicitud)  throws Exception;
	public Map<String, String> grabaTablaNegocio( Declaracion declaracion,
			 SolicitudRectificacionBean solicitudRectificacion, String codTransaccion) throws Exception;
	public Map<String, Object> Grabadocadeudo( Declaracion declaracion ,Map deudadiferencial,Map<String, Object> variablesIngreso) throws Exception;
	public String invocarAfectarGarantia(Declaracion declaracion,BigDecimal montoAcumuladoDolares, String cda,Integer fechaConclusionDespacho, 
			String numeroDocumentoIdentidadSender, String modulo, String ctrans,String numref,String numero);
	public Map<Object, Object> obtenerManifiesto(Declaracion declaracion);
	public void actualizaFechaVencimientoDocumentosDeuda(Declaracion declaracion,
			Declaracion declaracionBD, Map<Object, Object> mapManifiesto,
			List<HashMap> lstDeudas);
	
	public void actualizaFechaVencimientoDocumentosDeudaSinIndicencia(Declaracion declaracion,Declaracion declaracionBD,Map<Object,Object> mapManifiesto);
	
    /*rin10 fsw AFMA*/
	public String desafectarGarantia(DUA dua, HashMap<String, String> datosLiquidacion, Map<String, Object> variablesIngreso)
			throws Exception;

	public void grabarNotificacionesVP(Declaracion declaracion, Map<String, String> variablesIngreso);
}
