package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface ValPrecedenteActaEquipajeService {

	public List<Map<String, String>> validaActaIncautacionEquipaje (String puntoDeLlegada,List<DatoSerie> listSeries,String codAduanaOrden,Date fechaReferencia);
	public Date getFechaVencimiento(DatoRegPrecedencia regPrec, Date fechaReferencia, Date fechaNotificacion);
}