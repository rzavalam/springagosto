/*
 * Clase que define el servicio de validaciones de contingentes arancelarios
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValidaContingentesService {

	/**
	 * Procesamiento del env�o electr�nico de los datos de la declaraci�n de importaci�n acogi�ndose a contingente arancelario.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @param nroErroresNegocio Integer
	 * @return el list
	 * @author rcalla
	 */
	List<Map<String, String>> procesarOrdenEnvio(Declaracion declaracion, Map<String, Object> variablesIngreso, Integer nroErroresNegocio); 
	/*branch ingreso 2011-029 hosorio inicio 12/07/2011*/
//	public List<Map<String, String>> procesarDiligencia(Declaracion declaracion);
	/*branch ingreso 2011-029 hosorio fin 12/07/2011*/
	public List<Map<String, String>> procesarDiligencia(Declaracion declaracion, Map<String, Object> variablesIngreso, Integer nroErroresNegocio);
	/*DZC ISC Licores*/
    public boolean EsPartidaLicores(String part_nandi,Date  Fdeclaracion, String regimen); 
    
	/*INICIO GDLR*/
  //  public List<Map<String, String>> procesarDiligencia(Declaracion declaracion, List<Map<String, Object>> seriesEnBD);
    /*FIN GDLR*/
    
    public List<Map<String, String>> procesarRectiOficio(Declaracion declaracion, Map<String, Object> variablesIngreso, Integer nroErroresNegocio);

    public boolean tieneContingentes(Map<String, Object> parametros);

//	RSERRANOV
    public List<Map<String, String>> procesarDilRectif(Declaracion declaracion, Map<String, Object> variablesIngreso, Integer nroErroresNegocio);
	

}
