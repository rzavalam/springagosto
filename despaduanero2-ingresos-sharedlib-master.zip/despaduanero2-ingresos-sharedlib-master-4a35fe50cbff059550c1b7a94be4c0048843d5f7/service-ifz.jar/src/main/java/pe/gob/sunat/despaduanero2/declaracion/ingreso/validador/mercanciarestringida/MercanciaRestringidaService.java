package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface MercanciaRestringidaService {


/**
	 Valida la mercancia restringida para todas las series
 * @param  declaracion : Objeto que representa los datos de la declaracion
 * @return Map<String, ?> Mapa de Errores encontrado
*/
public List<Map<String, String>> validarMercanciaRestringida(
			Declaracion declaracion, String codTransaccion		);

	
/**
	 Valida la mercancia restringida de la serie
   * @param  declaracion : Objeto que representa los datos de la declaracion
   * @param  serie : Obj                            eto que representa a una serie
   * @return Map<String, ?> Mapa de Errores encontrado
 */		
public List<Map<String, String>> validarMercanciaRestringida(
			Declaracion declaracion,
			DatoSerie serie, String codTransaccion
);


public List<Map<String,String>>  validarMercanciaProhibida(Declaracion declaracion
		,String codTransaccion);

public int countDetCtrl(Map<String,Object> params);
}
