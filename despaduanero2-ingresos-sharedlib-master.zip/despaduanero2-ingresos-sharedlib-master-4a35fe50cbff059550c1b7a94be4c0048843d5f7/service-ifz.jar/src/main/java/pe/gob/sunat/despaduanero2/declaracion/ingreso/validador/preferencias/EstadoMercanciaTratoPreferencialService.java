package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface EstadoMercanciaTratoPreferencialService {
	/**
	 * Valida que el estado de mercanc�a sea nuevo con excepcion de los remanufacturados 
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> validarEstadoNuevoMercancia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Valida que el estado de mercanc�a sea nuevo con excepcion de los remanufacturados y de ciertas subpartidas nacionales
	 * @param numSerie
	 * @param codEstmerca
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> validarEstadoNuevoMercanciaSubPartida(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	
	/**
	 * Valida si el estado de la mercanc�a es usado.
	 * @param numSerie
	 * @param codEstmerca
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> validarEstadoUsadoMercancia(String numSerie, String codEstmerca, Date fechaReferencia);
	
	//glazaror... metodo optimizado
	public Map<String, String> validarEstadoUsadoMercancia(String numSerie, String codEstmerca, Date fechaReferencia, Map<String, Object> variablesIngreso);

	
	/**
	 * Valida el estado de la mercancia.
	 * Si es que el tipo de margen es remanufacturado (4) se valida de la forma antigua (servicio 3338), de lo contrario se valida que el estado
	 * de la mercancia exista en el grupo de catalogo 710.
	 * Creado para el proyecto MSNADE236-6
	 * @param serie Serie que esta siendo evaluada
	 * @param variablesIngreso Variables usadas en el procesamiento
	 * @param fechaReferencia fecha de numeracion
	 * @return errores de validacion (en caso de que el estado de mercancia no sea valido)
	 * @author glazaror
	 */
	public Map<String, String> validarEstadoMercancia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Valida el estado de la mercancia.
	 * Si tipo de margen es remanufacturado(4) se valida de la forma antigua (servicio 3453).
	 * Si numero de subpartida esta en el rango 8703100000-8703900090 se valida que el estado de mercancia exista en el grupo catalogo 710,
	 * de lo contrario se valida que el estado de mercancia exista en el catalogo general de estados de mercancia 25.
	 * Creado para el proyecto MSNADE236-6
	 * @param serie Serie que esta siendo evaluada
	 * @param variablesIngreso Variables usadas en el procesamiento
	 * @param fechaReferencia fecha de numeracion
	 * @return errores de validacion (en caso de que el estado de mercancia no sea valido)
	 * @author glazaror
	 */
	public Map<String, String> validarEstadoMercanciaConEvaluacionRangoSubpartida(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
}
