package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;

public interface ValConTransFB {

	public List<Map<String, String>> codindcondtra(DAV dav);
	public List<Map<String, String>> indcondtra(DAV dav);
	
	
}
