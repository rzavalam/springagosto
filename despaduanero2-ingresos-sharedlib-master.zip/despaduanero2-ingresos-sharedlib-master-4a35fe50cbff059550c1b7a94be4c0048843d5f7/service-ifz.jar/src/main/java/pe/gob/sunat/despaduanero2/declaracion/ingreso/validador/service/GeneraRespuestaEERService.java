package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.HashMap;
import java.util.Map;

public interface GeneraRespuestaEERService {
	
	public HashMap<String, String> validacionGeneraRespuestaEnvio(Integer nroErroresNegocio, Map<String, Object> variablesIngreso);

}