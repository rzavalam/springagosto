package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.ArchivoAnexoDocControlMR;
import pe.gob.sunat.estrategico2.aduanero.vuce.model.acuerdo.DocCertificadoOrigen;

public interface CertiOrigenElectronicoService {
	public List<Map<String,String>> validarCertificadoOrigenElectronico(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	public DocCertificadoOrigen traerCertificadoOrigen(String numCertificado);
	public boolean esValidoCambiosDiligVUCECO(Date fechaReferencia);

	public ArchivoAnexoDocControlMR obtenerCertificadoOrigenPDF(String numCertificadoOrigen, String codigoPaisOrigen);
	public DocCertificadoOrigen consultarCertificadoElectronico (String numSerie, String numCertificado);
}
