package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.donacion;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValidadorDonacionService {
	
	/**
	 * Ejecuta las validaciones y reglas de negocio que 
	 * se deben cumplir sobre el registro de donaciones 
	 * */
	public List<Map<String,String>> validarDonaciones(Declaracion declaracion, Declaracion declaracionBD);
	
	/**
	 * Valida que se cumpla con los requisitos para donaci�n
	 * */
	public boolean cumpleRequisitosParaDonar(Declaracion declaracion, List<Map<String,String>> lstErrores, DatoOtroDocSoporte resolucion);
	
	/**
	 * Obtiene la resoluci�n de donaci�n
	 * */
	public DatoOtroDocSoporte obtenerDocumentosDonacion(Declaracion declaracion);
	
	/**
	 * Valida la incorporaci�n de tipo tratamiento 4 en la rectificaci�n
	 * */	
	public List<Map<String,String>> validarIncorporacionTipoTratamiento4(Declaracion declaracion, Declaracion declaracionBD);
	
	/**
	 * Valida que el tipo de documento asociado a la declaraci�n sea de tipo donaci�n
	 * */
	public List<Map<String, String>> validarDocumentosAsociadosDeclaracion(Declaracion declaracion);
	
	/**
	 * Valida que de enviar documento autorizante de la donaci�n, se consigne los datos obligatorios
	 * */
	public List<Map<String, String>> validarDocumentoDonacionAutorizante(Declaracion declaracion);
	
	/**
	 * Valida se consigne los datos obligatorios de la resoluci�n
	 * */
	public List<Map<String, String>> validarDatosObligatoriosResolucion(DatoOtroDocSoporte resolucion, DatoSerie datoSerie);
	
	/**
	 * Valida se consigne a la serie los documentos de soporte necesarios para la donaci�n
	 * */
	public List<Map<String,String>> validarDocumentosAsociadosSeries(Declaracion declaracion, DatoSerie serie, DatoOtroDocSoporte resolucion);
	
	/**
	 * Valida se consigne los c�digos liberatorios correctos para donaci�n
	 * */
	public List<Map<String,String>> validarCodigoLiberatorioHabilitadoParaDonacion(DatoSerie serie, Declaracion declaracion, Declaracion declaracionBD);

}
