package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Map;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

/**
 * <p>Title: LogRegiService</p>
 * <p>Description: Registro de logs en la tabla LOGREGI para Afectaci�n y desafectaci�n de PAGARANTIA </p>
 * <p>Copyright: Copyright (c) 2013</p>
 * <p>Company: SUNAT - INSI</p>
 * @author Daniel Zavaleta
 * @version 1.0 
 */

public interface LogRegiService {

  /**
   * Registro de logs en la tabla LOGREGI y actualiza segun sea el caso correspondiente. 
   * @param String Map
   * @return boolean
   * @throws ServiceException
   */
  
  @SuppressWarnings("unchecked")
  public boolean grabaLogGarantia(Map<String,Object> params,Map<String, Object> variables);

  @SuppressWarnings("unchecked")
  public boolean grabaLogGeneral(Map<String,Object> params);
}   

