/*
 * Clase que define el servicio de validaciones de los regimenes de precedencias declarados en la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.SumDatoSeriePrec;


/**
 * The Class ValRegprec. Clase que define el servicio de validaciones de los regimenes de precedencias declarados en la DUA.
 */
public interface ValRegprec {
	
	public Map<String, String> codtipoprece(String codtipoprece);
	
	public Map<String, String> codaduapre(String codaduapre);
	
	public Map<String, String> codregipre(String codregipre);
	
	public Map<String, String> anndeclpre(String anndeclpre, String codregipre);
	
	public Map<String, String> numdeclpre(String numdeclpre, String codregipre);
	
	public Map<String, String> numserpre(Integer numserpre);
	
	public Map<String, String> fecvencpre(Date fecvencpre);
	
	public Map<String, String> codtipoprodad(String codtipoprodad);
	
	public Map<String, String> numitem(Integer numitem);
	
	public Map<String, String> cntunidfiqty(BigDecimal cntunidfiqty);
	
	
	//msancheza
	/**
	 * Validaciones generales a los datos generales del regimen de precedencia de Importaci�n para el consumo
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> valCabRegPreTPN21ImpoConsumo(Declaracion declaracion, boolean esTPN21, Date fechaReferencia, String codTransaccion);
	public List<Map<String, String>> valSerieTPN21RegPrecImpoConsumo(Declaracion declaracion, DatoSerie serie, DatoRegPrecedencia precedente, Date fechaReferencia, String codTransaccion, SumDatoSeriePrec sumaSeriePrec);	
	
	//p29 gmontoya
	public boolean existeDUAPrecedente(DatoRegPrecedencia precedente);
}
