package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certireposicion;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Repocer;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Reposce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface ValRegPrecedenciaReposicionService {

	/** Validar la existencia del n�mero de certificado consignado en la serie de declaraci�n */
	public List<Map<String,String>> validaExistenciaCRMF(List<Repocer> certificadoReposicion,Map<String,Object> params);
	
	/** Validar que el certificado de reposici�n no se encuentre en estado Anulado */
	public List<Map<String,String>> validaEstadoCRMF(List<Repocer> certificadoReposicion,Map<String,Object> params);
	
	/** Validar que el RUC de la declaraci�n corresponda al beneficiario */
	public List<Map<String,String>> validaRUCBeneficiario(List<Repocer> certificadoReposicion,Map<String,Object> params);
	
	/** Validar que el item consignado para la serie de la declaraci�n exista */
	public List<Map<String,String>> validaExistenciaItem(List<Reposce> listSeriesCertificado,Map<String,Object> params);
	
	/** Validar la fecha de vencimiento consignada en la serie de la declaraci�n */
	public List<Map<String,String>> validaFechaVencimiento(List<Repocer> certificadoReposicion,Map<String,Object> params);
	
	/** Validar la fecha fin de vigencia del certificado de reposici�n sea mayor o igual a fecha de numeraci�n */
	public List<Map<String,String>> validaFechaVigencia(List<Repocer> certificadoReposicion,Map<String,Object> params);
	
	/** Validar que solo se puede hacer referencia a un solo item del certificado de reposici�n */
	public List<Map<String,String>> validaUnicoCertificado(DatoSerie datoSerie,Map<String,Object> params);
	
	/** Validar que el item consignado en la serie de la declaraci�n no se encuentre anulado */
	public List<Map<String,String>> validaEstadoItem(List<Reposce> listSeriesCertificado,Map<String,Object> params);
	
	/** Validar que las unidades fisicas y equivalentes consignadas en la serie coincidan con la CRMF */
	public List<Map<String,String>> validaUndFisicaEquiva(List<Reposce> listSeriesCertificado,Map<String,Object> params);
	
	/** Validar que las cantidades fisicas no excedan a la cantidad disponible por item del CRMF */
	public List<Map<String,String>> validaCntFisicaEquiva(List<Reposce> listSeriesCertificado, Map<String,Object> params);
	
	/** Validar que al consignar el mismo n�mero de certificado e item para diferentes series de la declaraci�n, estas no excedan el saldo disponible por el item del certificado */
	public List<Map<String,String>> validaCntAgrupadaFisicaEquiva(List<Reposce> listSeriesCertificado, Map<String,BigDecimal> cantidadAcumuladaCertificado, Map<String,Object> params);
	
	/*Ini P28*/
	/**
	  * Permite validar datos del Certificado de Reposici�n 
	  * @param numeroCertificado
	  * @param codigoAduana
	  * @param anioCertificado
	  * @param numeroItem
	  * @return 
	*/
	public List<Map<String,String>> procesarDatosCertificadoReposicion(Map<String,Object> params);
	/*Fin P28*/
	
}
