package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValItemFB {
	
	public Map<String, String> numsecitem(Declaracion declaracion);
	public Map<String, String> codpaisorige(DatoItem datoItem);
	public Map<String, String> mtofobunita(DatoItem datoItem);
	public Map<String, String> mtoajusunita(DatoItem item);
	public Map<String, String> cntcantcomer(DatoItem item);
	public List<Map<String, String>> codunidcomer(DatoItem item);
	public Map<String, String> codpaisadqui(DatoItem item);
	public Map<String, String> descomercial(DatoItem item);
	public Map<String, String> desmarca(DatoItem item);
	public Map<String, String> annfabrica(DatoItem item);
	public Map<String, String> codestamer(DatoItem item);
	public Map<String, String> validarUnidadComercial (DatoItem item);
	public Map<String, String> indvarios(DatoItem item);
	public List<Map<String, String>> mtofobitem(DatoItem datoItem);
	public Map<String, String> numpartnandi(DatoItem item, Date fechaReferencia);
	public Map<String, String> inddeducdisti(DatoItem item);
	public Map<String, String> descaracteristicas(DatoItem item);
	public Map<String, String> desclasevari(DatoItem item);
	public Map<String, String> valgralitemfb1(DAV dav) ;
	public  List<Map<String, String>>  valgralitemfb3(DAV dav, Declaracion declaracion);
	public Map<String, String> valgralitemfb4(DAV dav, Declaracion declaracion);
    public List<Map<String, String>> valPaisAdqui (DAV dav, Declaracion declaracion); 
	public List<Map<String, String>> valgralitemfb6(DAV dav, Declaracion declaracion);
    public List<Map<String, String>> indsoftware(DatoItem item);
	public  DatoSerie getSerieCorrespondiente(DatoItem item, Declaracion declaracion);
	public  DatoItem getItemCorrespondiente(DatoSerie serie, Declaracion declaracion);
	public List<Map<String, String>> validarDatosItemXSerieItem(DatoItem item);
	public Map<String, String> validarAjusteDudaPorItem (DatoItem item, Declaracion declaracion);
	Map<String, String> codEstaMerOtros(DatoItem item);	
	
}
