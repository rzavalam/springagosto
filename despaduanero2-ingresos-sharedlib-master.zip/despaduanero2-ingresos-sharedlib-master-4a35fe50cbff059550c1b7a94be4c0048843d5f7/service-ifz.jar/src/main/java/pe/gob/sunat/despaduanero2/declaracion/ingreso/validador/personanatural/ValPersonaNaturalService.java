package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.personanatural;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValPersonaNaturalService {
	
	public List<Map<String,String>> valCantidadDeclaracionAnual(Declaracion declaracion, Date fechaReferencia);
	
	public List<Map<String,String>> valUnicidadDeclaracionAnual(Declaracion declaracion);
	
	public List<Map<String,String>> valMontoImpoPorEnfermedades(Declaracion declaracion);

	List<Map<String, String>> valCantidadDeclaracionAnualMdeer(Declaracion declaracion, Date fechaReferencia);
}
