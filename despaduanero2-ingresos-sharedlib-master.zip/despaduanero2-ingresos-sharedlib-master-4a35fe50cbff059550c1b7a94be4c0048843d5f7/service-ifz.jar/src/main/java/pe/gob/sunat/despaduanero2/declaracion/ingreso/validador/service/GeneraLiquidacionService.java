package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * Clase que permite obtener la liquidacion de tributos de la Declaraci�n.
 * @author Juan Canchucaja - Oct 2009
 *
 */
public interface GeneraLiquidacionService {

	@SuppressWarnings("unchecked")
	public Map obtenerLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String codUsuario, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender);
	
	@SuppressWarnings("unchecked")
	public Map obtenerDiferenciaTributaria(Declaracion declaracion, String codTransaccion, String numOrden, String codUsuario, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender);
	
	@SuppressWarnings("unchecked")
	public Map grabaLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender);
		
	@SuppressWarnings("unchecked")
	/*INICIO RIN08*/
	public Map grabaLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender, Map montosTPI100, Map montosLC0006); //RIN 08 Se adiciona parametro montosLC0006
	/*FIN RIN08*/
	
	@SuppressWarnings("unchecked")
	public Map grabaDUAEnPreliq(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender);
	
	public void grabaTrama (Map<String, Object> variablesIngreso);
	
//	@SuppressWarnings("unchecked")
//	public void blanqueaDUAEnPreliq(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender);
}
