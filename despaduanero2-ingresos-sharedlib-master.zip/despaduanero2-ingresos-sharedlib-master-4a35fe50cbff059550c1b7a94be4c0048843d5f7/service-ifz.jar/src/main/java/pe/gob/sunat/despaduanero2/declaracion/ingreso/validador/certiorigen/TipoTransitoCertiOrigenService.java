package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface TipoTransitoCertiOrigenService  {

	/**
	 * validacion de envio de indicador de tr�nsito
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> validarIndicadorTransito(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);

	/**
	 * validacion de envio de indicador de tr�nsito, que se envie la fecha y puerto en origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valIndicadorFechaPuertoOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * validacion de envio de indicador de tr�nsito, que el puerto de embarque en origen sea el del pais de origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valIndicadorPaisConPuertoEmbarque(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * validacion de envio de indicador de tr�nsito, que el puerto de embarque en origen sea el de cualquier pais de origen del acuerdo
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valIndicadorPaisesConPuertoEmbarque(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * validacion de envio de indicador de tr�nsito 1 y 3, que el puerto de embarque en origen sea el de cualquier pais de origen del acuerdo
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valIndicadorPaisesConPuertoEmbarqueOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public List<Map<String, String>>  valIndicadorPaisesConPuertoEmbarqueYOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> valIndicadorPuertoEmbarqueDistintoPaisOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public List<Map<String, String>> valIndicadorPaisConPuertoEmbarqueYOrigenOpcional(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
}
