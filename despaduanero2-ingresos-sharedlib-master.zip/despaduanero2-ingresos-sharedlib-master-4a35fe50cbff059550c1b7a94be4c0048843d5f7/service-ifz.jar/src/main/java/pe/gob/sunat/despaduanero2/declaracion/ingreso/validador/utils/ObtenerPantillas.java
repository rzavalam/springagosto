package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils;

public class ObtenerPantillas {
	
	private String directorioPlantillasRespuesta;
	private String directorioTmpGenArchivos;
	private String nombrePlantillaRespuestaNumeracion;
	private String nombrePlantillaRespuestaRectiRegul;
	
	
	public String getNombrePlantillaRespuestaRectiRegul() {
		return nombrePlantillaRespuestaRectiRegul;
	}
	public void setNombrePlantillaRespuestaRectiRegul(
			String nombrePlantillaRespuestaRectiRegul) {
		this.nombrePlantillaRespuestaRectiRegul = nombrePlantillaRespuestaRectiRegul;
	}
	public String getDirectorioPlantillasRespuesta() {
		return directorioPlantillasRespuesta;
	}
	public void setDirectorioPlantillasRespuesta(
			String directorioPlantillasRespuesta) {
		this.directorioPlantillasRespuesta = directorioPlantillasRespuesta;
	}
	public String getDirectorioTmpGenArchivos() {
		return directorioTmpGenArchivos;
	}
	public void setDirectorioTmpGenArchivos(String directorioTmpGenArchivos) {
		this.directorioTmpGenArchivos = directorioTmpGenArchivos;
	}
	public String getNombrePlantillaRespuestaNumeracion() {
		return nombrePlantillaRespuestaNumeracion;
	}
	public void setNombrePlantillaRespuestaNumeracion(
			String nombrePlantillaRespuestaNumeracion) {
		this.nombrePlantillaRespuestaNumeracion = nombrePlantillaRespuestaNumeracion;
	}

}
