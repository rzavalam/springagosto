
package pe.gob.sunat.despaduanero2.declaracion.ingreso.wsclient;


public class Asignar {

    protected String aduana;
    protected String regimen;
    protected String momento;
    protected String codunisel;
    protected String anio;
    protected String numunisel;

    /**
     * Gets the value of the aduana property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAduana() {
        return aduana;
    }

    /**
     * Sets the value of the aduana property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAduana(String value) {
        this.aduana = value;
    }

    /**
     * Gets the value of the regimen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegimen() {
        return regimen;
    }

    /**
     * Sets the value of the regimen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegimen(String value) {
        this.regimen = value;
    }

    /**
     * Gets the value of the momento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMomento() {
        return momento;
    }

    /**
     * Sets the value of the momento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMomento(String value) {
        this.momento = value;
    }

    /**
     * Gets the value of the codunisel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodunisel() {
        return codunisel;
    }

    /**
     * Sets the value of the codunisel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodunisel(String value) {
        this.codunisel = value;
    }

    /**
     * Gets the value of the anio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnio() {
        return anio;
    }

    /**
     * Sets the value of the anio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnio(String value) {
        this.anio = value;
    }

    /**
     * Gets the value of the numunisel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumunisel() {
        return numunisel;
    }

    /**
     * Sets the value of the numunisel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumunisel(String value) {
        this.numunisel = value;
    }

}
