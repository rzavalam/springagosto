package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;

/**
 * Pase: PAS20181U220200016
 * @param declaracion
 * @return
 */


public interface ValOperadorOeaService {
	public List<Map<String, String>> validarEnviodeProveedorOeayPaisOea(Declaracion declaracion);
	public void evaluacionCodriesgoOea(String codigoArm, Declaracion declaracion);
	//public List<Map<String, String>> validarCodEmpresaOea(Declaracion declaracion, DeclaracionBD declaracionBD);
}