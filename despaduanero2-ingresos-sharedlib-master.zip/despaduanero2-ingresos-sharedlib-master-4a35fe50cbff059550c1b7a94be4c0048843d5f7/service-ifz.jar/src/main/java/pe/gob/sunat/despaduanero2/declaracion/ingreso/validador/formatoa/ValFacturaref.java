/*
 * Clase que define el servicio de validaciones de las referencias de las facturas
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValFacturaref. Clase que define el servicio de validaciones de las referencias de las facturas.
 */
public interface ValFacturaref {
		
	public Map<String, String> codidfactura(String codidfactura);
	
	public Map<String, String> numfactura(String numfactura);
	
	public Map<String, String> fecfactura(Date fecfactura);
	
	public Map<String,String> codtipofact(String codtipofact);

        public Map<String, String> validacionFecFactura(Declaracion declaracion,DatoSerie serie); 
	
}
