package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * Clase que permite realizar la grabacion del formato A 
 * @author gmeza
 *
 */
public interface GrabarFormatoAService {

	public Map<String,String> grabaFA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion) throws Exception;

	/**
     * @author hsaenz
     * @since 08/09/2014
     * Grabar. 
     */	
	public Map<String,String> grabaFormatoA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion, Date fechaVencimientoConclusion) throws Exception;
	
	//PAS20165E220200025 - Inicio
	Map<String,String> grabaFormatoA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion, Date fechaVencimientoConclusion, List<DatoDocAutorizante> listaVUCE) throws Exception;
	
	public void grabarParticipanteSEIDA(String codUsuario, String tipoSender, Long numCorreDoc);
	
	//PAS20181U220200022 - Inicio
	public void grabarIndicadorImportadorFrecuente(Declaracion declaracion, String codTransaccion);

	public boolean esImportadorFrecuenteNuevasCondiciones(String codregimen, String tipoDocum, String numeDocum, String codModalidad, Elementos<DatoSerie>listSeries);
		
	public boolean esImportadorFrecuenteNuevasCondiciones(String codregimen, String tipoDocum, String numeDocum, String codModalidad, Elementos<DatoSerie>listSeries, boolean tieneMargenYTpi);
	public void actualizarIndicadorImportadorFrecuente(Long numCorreDoc, boolean vaIndicadorImpFrecuente);
	
}
