package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
 

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public interface AdmisionTemporalValidacionService {

	
	public abstract Map<String, String> validarUsuariosCeticos(DUA dua);
	public abstract List<Map<String, String>> validarPlazoMaximo(DUA dua, String numeroDocumentoIdentidadSender,Map<String, Object> variablesIngreso);
    public abstract Map<String, String> validarZofraTacna(DUA dua);
	public abstract List<Map<String, String>> validarExistaCantEquivalente(DUA dua ); 
	public abstract List<Map<String, String>> validarExistaTipoUnidadEquivalente(DUA dua ); 
	public abstract List<Map<String, String>> validarItemInsumoDeclarado(DUA dua) ;
	public abstract List<Map<String,String>> validarCantEquivalente(DUA dua ) ;
	public abstract List<Map<String, String>> validarCantEquivalenteFis(DUA dua ); 
	public abstract Map<String, ?> Validarplazoferia(DUA dua ) 	;
	//public abstract List<Map<String, String>> validarMerma(DUA dua ) ;
	public abstract List<Map<String, String>> validarRegimenPrecedente(DUA dua ); 
	public abstract List<Map<String, String>>ValidarOperacionPartida(DUA dua);									
	public abstract Map<String, String> ValidarModalidadSocorro(DUA dua);	
	public abstract Map<String, String> ValidarUbicacionOperacion(DUA dua);
	public abstract Map<String, String> ValidarModalidadFechaNumeracionTermino(DUA dua,Date fechaReferencia);
	public abstract Map<String, String> ValidarAcoRegimenNumeracion(DUA dua,Date fechaReferencia);
	public abstract Map<String, String> ValidarTipoOperacionPlazos(DUA dua,Date fechaReferencia);
	public abstract Map<String, String> validarFechaVencimientoRegimen(DUA dua,Date fechaReferencia);
	
}