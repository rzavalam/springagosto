package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;//adicionado PAS20155E220000396
//RIN16
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;


import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.util.ConstantesManifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class GeneralUtils {

	/**Constante para acumular con esta clave cuando no transmite numero de detalle**/
	public final static Integer SIN_NUMDETALLE=-1;


	public static Map<String,Object> fillDataDuaDocTransp(Declaracion declaracion,
			DatoDocTransporte  docTrans,String codTransaccion ){
		return fillDataDuaDocTransp(declaracion,docTrans,null,codTransaccion);

	}

	public static DatoDocTransporte getDocTransporte(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		String numDocTransporte="";
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if ("3".equals(serieDoc.getCodtipodocsoporte()))
				numDocTransporte=String.valueOf(serieDoc.getNumiddocsoporte());
		}
		for(DatoDocTransporte docTransp:dua.getListDocTransporte()){
			if (numDocTransporte!=null){
				if (numDocTransporte.equals(String.valueOf(docTransp.getNumsecdoctrans())))
					return docTransp;
			}
		}
		return null;
	}

	/**
	 * Devuelve un Map de 3 niveles Map&lt;String, Map&lt;Integer, Map&lt;String, BigDecimal&gt;&gt;&gt;
	 * En el mapa del 1er Nivel la clave es el documento de transpote
	 * En el segundo nivel es la Serie, si el dt no tiene serie entonces es -1
	 * En el tercer nivel contiene los pesos y bulto, claves  "totalPesoBruto" y "totalBulto"
	 * @param declaracion
	 */
	public static Map<String, Map<Integer, Map<String, BigDecimal>>> totalesParaDatadoPorDocTra(Declaracion declaracion){
		/** NSR: Para evitar recorrer todas las series por cada DocTransporte, primero acumulamos los totales y luego
		 * recien validamos. el numero del documento de transporte esta en la lista de docSoporte
		 */
		Map<String, BigDecimal> mapTotal = new HashMap<String, BigDecimal>();
		Map<Integer, Map<String, BigDecimal>> mapDatosTotalesXDetalle = new HashMap<Integer,Map<String, BigDecimal>>();
		Map<String, Map<Integer, Map<String, BigDecimal>>> mapDetallesXDocuTrans = new HashMap<String, Map<Integer, Map<String, BigDecimal>>>();
		String numDocTransporte;
		Integer numDetalle;

		for(DatoSerie serie:declaracion.getDua().getListSeries()){
			numDocTransporte = "";
			//Obtenemos el numero del documento de Transporte de la lista de doc soporte tipo 3
			DatoDocTransporte docTransporteSerie=getDocTransporte(declaracion.getDua(), serie);
			//Si aqui devuelve null es por que la Serie no esta correctamente asociada a un documento de transporte
			//Esto no lo validamos ya que hay un servicio que se encarga de realizar esa validaci�n y que rechazar� la tranmision
			//ValNegocNumeracFormA.valDetalleSeries 17792 en orquesta despa
			if(docTransporteSerie != null){
				numDocTransporte = docTransporteSerie.getNumdoctransporte();
				//Verificamos si tiene numDetalle, si no asignamos -1 solo para efectos de acumular pesos y bultos
				numDetalle = SunatNumberUtils.isGreaterThanZero(docTransporteSerie.getNumdetalle())?docTransporteSerie.getNumdetalle():SIN_NUMDETALLE;
				//Buscamos por numero de documento todos sus detalles
				mapDatosTotalesXDetalle = mapDetallesXDocuTrans.containsKey(numDocTransporte)?mapDetallesXDocuTrans.get(numDocTransporte):new HashMap<Integer,Map<String, BigDecimal>>();
				//Buscamos por numDetalle el total acumulado
				mapTotal = mapDatosTotalesXDetalle.containsKey(numDetalle)?mapDatosTotalesXDetalle.get(numDetalle):new HashMap<String, BigDecimal>();
				//Si el mapa no contiene las claves devuelve null, y la funcion sum los convierte a cero
				BigDecimal totalPesoBruto = mapTotal.get("totalPesoBruto");
				BigDecimal totalBulto = mapTotal.get("totalBulto");
				totalPesoBruto=SunatNumberUtils.sum(totalPesoBruto,serie.getCntpesobruto());
				totalBulto=SunatNumberUtils.sum(totalBulto,serie.getCntbultos());
				//almacenamos los nuevos totales
				mapTotal.put("totalPesoBruto", totalPesoBruto);
				mapTotal.put("totalBulto", totalBulto);
				//almacenamos el mapa de Totales para el detalle que le corresponde
				mapDatosTotalesXDetalle.put(numDetalle, mapTotal);
				//almacenamos el detalle para el Documento de transporte correspondiente
				mapDetallesXDocuTrans.put(numDocTransporte, mapDatosTotalesXDetalle);
			}
		}
		return mapDetallesXDocuTrans;
	}

	public static String defineModalidadDatado(Declaracion declaracion, String codTransaccion){
		return null;
	}

	/**
	 * Este metodo devuelve un mapa con los datos que seran fijos para enviar a datar cada
	 * documento de transporte de la declaraci�n.
	 * OJO: no colocar aqui ninguna validaci�n de negocio, esta clase es solo un utilitario para
	 * llenar el mapa.<p>
	 * Las validaciones de plazos, integridad, etc, deben hacerse en el servicio de validacion
	 * correspondiente.<p>
	 * Si algun dato no existe se colocara null para la clave correspondiente.<p>
	 * Datos fijos para el Datado:<p>
	 *
	 * tipoDespacho	String, (01,02,03,04)<p>
	 *
	 * codigoViaTransporte	String<p>
	 * numeroManifiesto	String<p>
	 * anioManifiesto	Integer<p>
	 * codigoTipoManifiesto	String<p>
	 * codigoAduana	String<p>
	 * codigoEmpresaTransportista	String<p>
	 *
	 * regimenDua	String<p>
	 * numeroDua	String<p>
	 * annoDua	Integer<p>
	 * aduanaDua	String<p>
	 *
	 * @param declaracion
	 * @param codTransaccion
	 * @return
	 */
	public static Map<String,Object> getDatosFijosDatadoValidacion(Declaracion declaracion, String codTransaccion, Map<String,Object> mapOtrosDatos){
		Map<String,Object> dataDua=new HashMap<String, Object>();
		DUA dua = declaracion.getDua();
		String CODIGO_PUNTO_LLEGADA_ZOFRATACNA = "16";//pase 64
		String CODIGO_PUNTO_LLEGADA_CENTROATENCIONFRONTERIZA = "14";//pase 64
		String TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA = "96";//pase 64
		//M_SNADE278 rtineo
		Boolean esDirefidaSinICA  = mapOtrosDatos.get("isDAMDiferidaSinIca")!=null?(Boolean)mapOtrosDatos.get("isDAMDiferidaSinIca"):false;
		Boolean esVigenteRIN05PrimeraParte  = mapOtrosDatos.get("esVigenteRIN05PrimeraParte")!=null?(Boolean)mapOtrosDatos.get("esVigenteRIN05PrimeraParte"):false;
		
		//M_SNADE278 end
		
		//Variables para Verificaci�n
		boolean esUrgente = "01".equals(dua.getCodmodalidad())?true:false;
		boolean esAnticipado = "10".equals(dua.getCodmodalidad())?true:false;
		boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;
		//RIN16
//		boolean esPosteriorFechaDeDescarga = false;
		boolean esNumeracion=codTransaccion.endsWith("01");

/*RIN13INSI*/
		boolean esRectificacion=codTransaccion.endsWith("03")
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIA_OFICIO)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIARECTI)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA_VALIDACION)
		                        /*inicio P21-P22*/
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION_VALIDACION)
		                        /*fin P21-P22*/
		/*INICIO-P34 FSW AFMA*/
				|| codTransaccion.endsWith(Constants.COD_TRANSAC_OFICIO_VALIDACION
		/*FIN-P34 FSW AFMA*/
		) ;


		boolean esRegularizacion=codTransaccion.endsWith("04") || codTransaccion.endsWith("05") || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIAREGUL) || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIA_REGU_OFICIO);

		//RIN16
//		boolean esDiligenciaDespacho = codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA);

		//******************************//
		DatoManifiesto manif = dua.getManifiesto();
		Participante partic=manif!=null?dua.getManifiesto().getEmpTransporte():null;
	    String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
	    String codaduamanif=manif!=null?manif.getCodaduamanif():null;
	    String annmanif=manif!=null?manif.getAnnmanif():null;
	    String nummanif=manif!=null?manif.getNummanif():null;
	    String codmodtransp=manif!=null?manif.getCodmodtransp():null;

	    dataDua.put("codigoViaTransporte", codmodtransp);
	    dataDua.put("numeroManifiesto", SunatStringUtils.lpad(nummanif,6,' '));
	    dataDua.put("anioManifiesto",  SunatStringUtils.length(annmanif)>3?Integer.parseInt(annmanif.substring(0,4)):null);
	    dataDua.put("codigoTipoManifiesto", manif.getCodtipomanif());
	    dataDua.put("codigoAduana", codaduamanif);
	    dataDua.put("codigoEmpresaTransportista", numeroDocumentoIdentidad);
	    dataDua.put("codModalidad", dua.getCodmodalidad() );//lmvr - pase105

	    /*LMVR- Inicio*/
		String cod_tippartic = "";
		String cod_tipo_punto_llegada = declaracion.getDua().getCodlugarecepcion();
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL;	
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO;		
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_POSTAL;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO)) cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_AEROPORTUARIO;
		//if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_TERMINAL_CARGA_AEREO; //verificar si es cambio del pase 13
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) || cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO) ||cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO; //PAS20191U220200019
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) && esDirefidaSinICA)	cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_PORTUARIO;
		if(cod_tipo_punto_llegada.equals(CODIGO_PUNTO_LLEGADA_ZOFRATACNA)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_ZONA_FRANCA;	//pase 64
		if(cod_tipo_punto_llegada.equals(CODIGO_PUNTO_LLEGADA_CENTROATENCIONFRONTERIZA)) cod_tippartic = TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA; //pase64
		//Para diligencias
		if(cod_tippartic.isEmpty() || cod_tippartic==null){
			String codTipoLlegada=""; 
			if(declaracion.getDua()!=null){
			codTipoLlegada = declaracion.getDua().getCodtiplugarrecep()!=null?declaracion.getDua().getCodtiplugarrecep():" ";
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO;
			if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER;
			if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_POSTAL;
			if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO)) cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_AEROPORTUARIO;
			//if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_TERMINAL_CARGA_AEREO; // verificar si es cambio del 13
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) || codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS) || cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO;//PAS20191U220200019
			}
		}
		/*LMVR - Fin*/
	    
		if(declaracion.getNumeroDeclaracion()!=null)
			dataDua.put("numeroDua", declaracion.getNumeroDeclaracion().toString() );

		//El a�o de de la DUA en el caso de la Numeraci�n es el a�o Presente
		//Para los demas casos (Rectificacion y Regularizacion) es el a�o de la Declaracion ua de Referencia
		if(!esNumeracion)
			dataDua.put("annoDua", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getAnnprese()) );
		else{
			FechaBean fbCurrent=new FechaBean();
			Integer anho=new Integer(fbCurrent.getAnho());
			dataDua.put("annoDua", anho);
		}
		dataDua.put("aduanaDua", declaracion.getDua().getCodaduanaorden());
		dataDua.put("regimenDua", declaracion.getDua().getCodregimen());

	    /**
		  * NSR: Se realizan los cambios necesarios para datar con lo manifestado o lo recibido, seg�n
		  * la modalidad,
		  * ojo, aqui no colocar validaciones de negocio, esto solo es un utilitario, se supone que las
		  * validaciones de negocio se deben hacer en el servicio de validaci�n
		  */
		Boolean esUrgenteAnticipada  = mapOtrosDatos.get("esUrgenteAnticipada")!=null?(Boolean)mapOtrosDatos.get("esUrgenteAnticipada"):false;
		Boolean esUrgenteExcepcional = mapOtrosDatos.get("esUrgenteExcepcional")!=null?(Boolean)mapOtrosDatos.get("esUrgenteExcepcional"):false;

		if(esUrgente){
			dataDua.put("esUrgenteAnticipada", esUrgenteAnticipada);
			dataDua.put("esUrgenteExcepcional", esUrgenteExcepcional);
		}

		if(esNumeracion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				//PAS20181U220200064
				if(esVigenteRIN05PrimeraParte){
					
					if(esDirefidaSinICA){
						dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
						dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
					}
				}else{
				//M_SNADE278 rtineo, si es DAM DIFERIDA SIN ICA se data contra el manifiesto como una anticipada
				if(cod_tipo_punto_llegada.equals("2") && esDirefidaSinICA){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
					dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
				}
				}
				//M_SNADE278 rtineo fin
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				//PAS20181U220200064
//				if(cod_tippartic.equals(TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA) && esVigenteRIN05PrimeraParte){
//					dataDua.put("tipoDocumentoOperador","19");// no es ruc
//				}else{
//				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
//				}
				//fin PAS20181U220200064
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				
				
				//lmvr - Fin
			}else if (esAnticipado){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
			} else if (esUrgente){
				/*
				MATC 20130515 - PAS20134E610000077 - Las numeracion de urgentes se data sobre lo manifestado
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				}else if (esUrgenteAnticipada){ //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
				}
				*/
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
			}
		} else if (esRectificacion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				//PAS20181U220200064
				// CAMBIO PARA RECTIFICACION MOL
				if(esVigenteRIN05PrimeraParte){
					
					if(esDirefidaSinICA){
						dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
						dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
					}
				}else{ 
					//M_SNADE278 rtineo, si es DAM DIFERIDA SIN ICA se data contra el manifiesto como una anticipada
					if(cod_tipo_punto_llegada.equals("2") && esDirefidaSinICA){
						dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
						dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
					}
				}
				//M_SNADE278 rtineo fin
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				//lmvr - Fin
			} else if (esUrgente || esAnticipado){
				/*
				 * MATC 20130515 - PAS20134E610000077 - Las urgentes se datan sobre lo manifestado
				 * Antes del datado, se verifica si para la DUA ya existe datado sobre lo recibido
				 * Si antes ya fue datada sobre lo recibido -->  Data sobre lo RECIBIDO
				 * Si no existe el registro indicado        -->  Data sobre lo MANIFESTADO
				 */
				if((mapOtrosDatos.get("tieneDatadoSobreRecibido")!= null && mapOtrosDatos.get("tieneDatadoSobreRecibido").equals("S")) ){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
					//lmvr - Incio
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}
					//lmvr - Fin
				}
				else{
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
				}
			}
		} else if (esRegularizacion){
			if (esAnticipado){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_ANTICIPADO);
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				//lmvr - Fin
			} else if (esUrgente){
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_URGENTE_EXCEPCIONAL);
				//lmvr - Inicio					
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}

				//lmvr - Fin

				}else  if (esUrgenteAnticipada){ //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_ANTICIPADO);
					//lmvr - Incio
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}
					//lmvr - Fin
				}
			}
		}
		return dataDua;
	}

	public static Map<String,Object> actualizaDatosFijosDesdatadoRegistro(Declaracion declaracion, String codTransaccion, Map<String, Object> dataDua){
		DUA dua = declaracion.getDua();
		//Variables para Verificaci�n
		boolean esUrgente = "01".equals(dua.getCodmodalidad())?true:false;
		boolean esAnticipado = "10".equals(dua.getCodmodalidad())?true:false;
		boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;
//		boolean esNumeracion=SunatStringUtils.isEqualTo(codTransaccion.substring(2,4), "01");
		//boolean esRectificacion=codTransaccion.endsWith("03") || codTransaccion.equals(tipoTransaccionDilig);
/*RIN13INSI*/
		boolean esRectificacion=codTransaccion.endsWith("03")
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIA_OFICIO)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIARECTI)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA_VALIDACION)
		                        /*inicio P21-P22*/
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION_VALIDACION)
		                        /*fin P21-P22*/
				/*INICIO-P34 FSW AFMA*/
				|| codTransaccion.endsWith(Constants.COD_TRANSAC_OFICIO_VALIDACION)
				/*FIN-P34 FSW AFMA*/
				;


		boolean esRegularizacion=codTransaccion.endsWith("04") || codTransaccion.endsWith("05") || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIAREGUL);
		//******************************//
		//En el caso del urgente se verifica si es Urgente Anticipado o Urgente Excepcional
		Boolean esUrgenteAnticipada = (Boolean)dataDua.get("esUrgenteAnticipada");
		Boolean esUrgenteExcepcional = (Boolean)dataDua.get("esUrgenteExcepcional");

		Long numCorredoc=declaracion.getDua().getNumcorredoc();
		dataDua.put("detalleNumeroCorrelativo", numCorredoc); // me pide el pk

		//M_SNADE278 rtineo
		String cod_tipo_punto_llegada = declaracion.getDua().getCodlugarecepcion();
		Boolean esDirefidaSinICA  = dataDua.get("isDAMDiferidaSinIca")!=null?(Boolean)dataDua.get("isDAMDiferidaSinIca"):false;
		Boolean isDAMRegistradaDiferidaSinIca = dataDua.get("isDAMRegistradaDiferidaSinIca")!=null?(Boolean)dataDua.get("isDAMRegistradaDiferidaSinIca"):false;
		//M_SNADE278 end

		if (esRectificacion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
				//M_SNADE278 rtineo, si es DAM DIFERIDA SIN ICA se desdata como una anticipada
				if(cod_tipo_punto_llegada.equals("2") && esDirefidaSinICA){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
					dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
				}else if(cod_tipo_punto_llegada.equals("1") && isDAMRegistradaDiferidaSinIca){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
				}				
				//
			} else if (esUrgente || esAnticipado){
				//MATC 20130515 - PAS20134E610000077 - Las urgentes se datan sobre lo manifestado
				/*
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
				}else if (esUrgenteAnticipada){ //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
				}
				*/
				if( dataDua.get("tieneDatadoSobreRecibido")!= null && dataDua.get("tieneDatadoSobreRecibido").equals("S") )
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
				else
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
			}
		} else if (esRegularizacion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
			}else if (esAnticipado){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
			} else if (esUrgente){
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_EXCEPCIONAL);
				}else if (esUrgenteAnticipada) { //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DESDATADO_ANTICIPADO);
				}
			}
		}

		return dataDua;
	}

	public static Map<String,Object> actualizaDatosFijosDatadoRegistro(Declaracion declaracion, String codTransaccion, Map<String, Object> dataDua){
		DUA dua = declaracion.getDua();
		//Variables para Verificaci�n
		boolean esUrgente = "01".equals(dua.getCodmodalidad())?true:false;
		boolean esAnticipado = "10".equals(dua.getCodmodalidad())?true:false;
		boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;
		boolean esNumeracion=codTransaccion.endsWith("01");
		String CODIGO_PUNTO_LLEGADA_ZOFRATACNA = "16";//pase 64
		String CODIGO_PUNTO_LLEGADA_CENTROATENCIONFRONTERIZA = "14";//pase 64
		String TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA = "96";//pase 64
/*RIN13INSI*/
		boolean esRectificacion=codTransaccion.endsWith("03")
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIA_OFICIO)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIARECTI)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA_VALIDACION)
		                        /*inicio P21-P22*/
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION)
		                        || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIACONCLUSION_VALIDACION)
		                        /*fin P21-P22*/
				/*INICIO-P34 FSW AFMA*/
				|| codTransaccion.endsWith(Constants.COD_TRANSAC_OFICIO_VALIDACION)
				/*FIN-P34 FSW AFMA*/
				;


		boolean esRegularizacion=codTransaccion.endsWith("04") || codTransaccion.endsWith("05") || codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIAREGUL);
		//******************************//

		//M_SNADE278 rtineo
		Boolean esDirefidaSinICA  = dataDua.get("isDAMDiferidaSinIca")!=null?(Boolean)dataDua.get("isDAMDiferidaSinIca"):false;
		//M_SNADE278 end
		Boolean esVigenteRIN05PrimeraParte  = dataDua.get("esVigenteRIN05PrimeraParte")!=null?(Boolean)dataDua.get("esVigenteRIN05PrimeraParte"):false;
		
		Long numCorredoc=declaracion.getDua().getNumcorredoc();
	    /*LMVR- Inicio*/
		String cod_tippartic = "";
		String cod_tipo_punto_llegada = declaracion.getDua().getCodlugarecepcion();
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)){
			cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO;
			//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuaci�n a la destinaci�n con punto de llegada deposito aduanero sin transmitir regimen precedente 70
			//La variable "tipoOperador_puntollegada3_sin_reg_precedencia" es seteado solo si esta abierta la vigencia catalogo 380-023, transmici�n con punto de llegada 3 sin envio de regimen de precedencia 
			if(dataDua.get("tipoOperador_puntollegada3_sin_reg_precedencia") != null && !dataDua.get("tipoOperador_puntollegada3_sin_reg_precedencia").toString().equals("")){
				cod_tippartic = dataDua.get("tipoOperador_puntollegada3_sin_reg_precedencia").toString();
			}
			//Fin M_SNADE255-2 - PercyHM 2016/07/14
		}		
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR))    cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_POSTAL;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO))               cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_AEROPORTUARIO;		
		//if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_TERMINAL_CARGA_AEREO;
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) || cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO) ||cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO; //PAS20191U220200019
		//M_SNADE278 rtineo, esto en duda
		if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) && esDirefidaSinICA) cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_PORTUARIO;
		if(cod_tipo_punto_llegada.equals(CODIGO_PUNTO_LLEGADA_ZOFRATACNA)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_ZONA_FRANCA; //pase 64
		if(cod_tipo_punto_llegada.equals(CODIGO_PUNTO_LLEGADA_CENTROATENCIONFRONTERIZA)) cod_tippartic = TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA; //pase 64	
 
		
		//Para diligencias
		if(cod_tippartic.isEmpty() || cod_tippartic==null){			
			String codTipoLlegada = "";
			if(declaracion.getDua()!=null){ 
			codTipoLlegada = declaracion.getDua().getCodtiplugarrecep()!=null?declaracion.getDua().getCodtiplugarrecep():"";	
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL)) 	    cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO))	    cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR))    cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_POSTAL;
			//if(cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_TERMINAL_CARGA_AEREO;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO))               cod_tippartic = ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_AEROPORTUARIO;
			if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) || codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS) || cod_tipo_punto_llegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_AEREO)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO;//PAS20191U220200019
			//if(codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO) || codTipoLlegada.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS)) cod_tippartic = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO;
		}
		}
		/*LMVR - Fin*/

		dataDua.put("detalleNumeroCorrelativo", numCorredoc); // me pide el pk
		dataDua.put("fechaNumeracionDua",SunatDateUtils.getCurrentDate()); //Date
		//Datos de la Dua

		if(declaracion.getNumeroDeclaracion()!=null)
			dataDua.put("numeroDua", declaracion.getNumeroDeclaracion().toString() );

		dataDua.put("codModalidad", dua.getCodmodalidad() );
		Boolean esUrgenteAnticipada = (Boolean)dataDua.get("esUrgenteAnticipada");
		//Boolean esUrgenteExcepcional = (Boolean)dataDua.get("esUrgenteExcepcional");
		Boolean esUrgenteExcepcional = dataDua.get("esUrgenteExcepcional")!=null?(Boolean)dataDua.get("esUrgenteExcepcional"):false;
		//Determinaci�n del tipo de Indicador de Datado para el Registro
		if(esNumeracion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				//PAS20181U220200064
				if(esVigenteRIN05PrimeraParte){
					
					if(esDirefidaSinICA){
						dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
						dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
					}
				}else{
				//M_SNADE278 rtineo, si es DAM DIFERIDA SIN ICA se data contra el manifiesto como una anticipada
				if(cod_tipo_punto_llegada.equals("2") && esDirefidaSinICA){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
					dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
				}
				}
			
				//M_SNADE278 rtineo fin
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				//PAS20181U220200064
//				if(cod_tippartic.equals(TIPO_OPERADOR_CENTRO_ATENCION_FRONTERIZA) && esVigenteRIN05PrimeraParte){
//					dataDua.put("tipoDocumentoOperador","19");// no es ruc
//				}else{
//				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
//				}
				//fin PAS20181U220200064
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				//lmvr - Fin
			}else if (esAnticipado){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
			} else if (esUrgente){
				/*
				MATC 20130515 - PAS20134E610000077 - Las urgentes se datan sobre lo manifestado
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				}else if (esUrgenteAnticipada){ //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
				}
				*/
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
			}
		} else if (esRectificacion){
			if (esExcepcional){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
				//M_SNADE278 rtineo, si es DAM DIFERIDA SIN ICA se data contra el manifiesto como una anticipada
				if(cod_tipo_punto_llegada.equals("2") && esDirefidaSinICA){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
					dataDua.put("isDAMDiferidaSinIca",esDirefidaSinICA);
				}
				//M_SNADE278 rtineo fin
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				//lmvr - Fin
			} else if (esUrgente || esAnticipado){
				/*
				 * MATC 20130515 - PAS20134E610000077 - Las urgentes se datan sobre lo manifestado
				 * Antes del datado, se verifica si para la DUA ya existe datado sobre lo recibido
				 * Si antes ya fue datada sobre lo recibido -->  Data sobre lo RECIBIDO
				 * Si no existe el registro indicado        -->  Data sobre lo MANIFESTADO
				 */
				if( dataDua.get("tieneDatadoSobreRecibido")!= null && dataDua.get("tieneDatadoSobreRecibido").equals("S") ){
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_EXCEPCIONAL);
					//lmvr - Incio
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}
					//lmvr - Fin	
				}
				else{
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_ANTICIPADO);
				}
			}
		} else if (esRegularizacion){
			if (esAnticipado){
				dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_ANTICIPADO);
				//lmvr - Incio
				dataDua.put("tipoOperador", cod_tippartic);
				dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
				if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				}else{
					dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
				}
				//lmvr - Fin
			} else if (esUrgente){
				if(esUrgenteExcepcional){ //Urgente Excepcional
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_URGENTE_EXCEPCIONAL);
					//lmvr - Incio
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}
					//lmvr - Fin

				}else if (esUrgenteAnticipada){ //No esPosteriorFechaDeDescarga - Urgente Anticipado
					dataDua.put("tipoDespacho", ConstantesManifiesto.INDICADOR_DATADO_REGULARIZACION_ANTICIPADO);
					//lmvr - Incio
					dataDua.put("tipoOperador", cod_tippartic);
					dataDua.put("tipoDocumentoOperador", declaracion.getDua().getCodtipooper());
					if(cod_tippartic.equals(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					}else{
						dataDua.put("numeroDocumentoOperador", declaracion.getDua().getNumruclugarecep());
					}
					//lmvr - Fin
				}
			}
		}
		return dataDua;
	}

	/**
	 * Este metodo devuelve un mapa con los datos que son variables por cada documento de transporte a datar
	 *  de la declaraci�n.<p>
	 * OJO: no colocar aqui ninguna validaci�n de negocio, esta clase es solo un utilitario para
	 * llenar el mapa.<p>
	 * Las validaciones de plazos, integridad, etc, deben hacerse en el servicio de validacion
	 * correspondiente.<p>
	 * Si algun dato no existe se colocara null para la clave correspondiente.<p>
	 * Datos Variables para el datado por documento de Transporte :<p>
	 *
	 * numeroDocumentoTransporte	String
	 * puertoEmbarque	String
	 * numeroDeDetalle	Integer(Opcional)
	 *
	 * @param declaracion
	 * @param docTrans
	 * @return
	 */
	public static Map<String,Object> getDatosVariablesDatado(Declaracion declaracion, DatoDocTransporte docTransporte){
		Map<String,Object> dataDua=new HashMap<String, Object>();
		dataDua.put("numeroDocumentoTransporte", docTransporte.getNumdoctransporte());
		dataDua.put("puertoEmbarque", docTransporte.getCodpuerto());
		if( SunatNumberUtils.isGreaterThanZero(docTransporte.getNumdetalle()) )
			dataDua.put("numeroDeDetalle", docTransporte.getNumdetalle());

		return dataDua;
	}

	/**
	 *
	 * @param declaracion La declaracion
	 * @param docTransporte el Documento de transporte del que queremos sus pesos y bultos
	 * @param mapDetallesXDocuTrans Mapa conteniendo los datos de pesos y bultos de todos los documentos de transporte,
	 * 		  este se obtiene con el metodo <code>totalesParaDatadoPorDocTra</code>
	 * @return
	 */
	public static Map<String,Object> getDatosCalculados(Declaracion declaracion, DatoDocTransporte docTransporte, Map<String, Map<Integer, Map<String, BigDecimal>>> mapDetallesXDocuTrans){
		Map<String,Object> dataDua=new HashMap<String, Object>();
		Map<String, BigDecimal> mapTotal = new HashMap<String, BigDecimal>();
		Map<Integer, Map<String, BigDecimal>> mapDatosTotalesXDetalle = new HashMap<Integer,Map<String, BigDecimal>>();
		Integer numDetalle;
		//Extraemos el peso y bulto total para este documento de transporte de nuestro mapa de totales
		if(mapDetallesXDocuTrans.containsKey(docTransporte.getNumdoctransporte())){
			mapDatosTotalesXDetalle = mapDetallesXDocuTrans.get(docTransporte.getNumdoctransporte());
			numDetalle = SunatNumberUtils.isGreaterThanZero(docTransporte.getNumdetalle())?docTransporte.getNumdetalle():SIN_NUMDETALLE;
			mapTotal = mapDatosTotalesXDetalle.get(numDetalle);
			//totalPesoBruto = mapTotal.get("totalPesoBruto");
			//totalBulto = mapTotal.get("totalBulto");
			//NSR: El mapTotal tiene los pesos y los bultos para este documento de transporte
			dataDua.putAll(mapTotal);
		} else {
			//Este documento de trasnporte no esta en el mapa, significa que no existe ninguna serie que le haga referencia
			return null;
		}
		return dataDua;
	}


	public static Map<String,Object> fillDataDuaDocTransp(Declaracion declaracion,
			DatoDocTransporte  docTrans, String tipoDatada, String codTransaccion) {
		Map<String,Object> dataDua=new HashMap<String, Object>();

		if(declaracion.getDua().getManifiesto()!=null){
			//Long numCorredoc=declaracion.getNumeroCorrelativo();
			Long numCorredoc=declaracion.getDua().getNumcorredoc();
			//RIN16
//			Date fecDeclara=declaracion.getDua().getFecdeclaracion();

			String codviatrades=declaracion.getDua().getManifiesto()!=null?
					declaracion.getDua().getManifiesto().getCodmodtransp():null;

					Participante partic=declaracion.getDua().getManifiesto().getEmpTransporte();
					String codigoBasc=partic!=null?partic.getNumeroDocumentoIdentidad():null;
					/**Datos adicionales segun correo de Lucho Salazar 15/02/2010
					 * (numeroDua, fechaNumeracionDua, annoDua, regimenDua)
					 */

					FechaBean fbCurrent=new FechaBean();
					Integer anho=new Integer(fbCurrent.getAnho());
					String tipoTrans=codTransaccion.substring(2);

					if(declaracion.getNumeroDeclaracion()!=null)
						dataDua.put("numeroDua", declaracion.getNumeroDeclaracion().toString() );

					if(!SunatStringUtils.isEqualTo(tipoTrans, "01")){
						dataDua.put("annoDua", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getAnnprese()) );
					}
					else
						dataDua.put("annoDua", anho);



					dataDua.put("aduanaDua", declaracion.getDua().getCodaduanaorden());
					dataDua.put("regimenDua", declaracion.getDua().getCodregimen());

					dataDua.put("detalleNumeroCorrelativo", numCorredoc); // me pide el pk
					dataDua.put("fechaNumeracionDua",SunatDateUtils.getCurrentDate()); //Date
					//NSR: Para el datod el tipoDespacho no es la modalidad: dataDua.put("tipoDespacho", declaracion.getDua().getCodmodalidad());
					dataDua.put("codigoAduana", declaracion.getDua().getManifiesto().getCodaduamanif()); // String
					dataDua.put("anioManifiesto", SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif())>3?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"); //Integer
					dataDua.put("numeroManifiesto", declaracion.getDua().getManifiesto().getNummanif()); // String
					dataDua.put("codigoTipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif()); // String
					dataDua.put("codigoViaTransporte", codviatrades);	//String
					dataDua.put("codigoEmpresaTransportista",codigoBasc); //String
					dataDua.put("numeroViaje", declaracion.getDua().getManifiesto().getNumviaje()); // via aerea o maritima  // string
					dataDua.put("fechaTerminoDeDescarga",declaracion.getDua().getManifiesto().getFectermino());	// Date
//revisar revisar
					dataDua.put("fechaLlegada",declaracion.getDua().getManifiesto().getFectermino()); // fecha de llegada

					dataDua.put("numeroDocumentoTransporte", docTrans.getNumdoctransporte());
					dataDua.put("fechaDeEmbarque", docTrans.getFecembarque());  //fecha de embarque
					dataDua.put("puertoEmbarque", docTrans.getCodpuerto()); // String

		}
		return dataDua;
	}

	/**
	 * Devuelve el nombre del metodo de la clase validadora, esto para posteriormente obtener la Anotaci�n
	 * @param o
	 * @return
	 */
    public static final Method getCurrentMethod(Object o) {
        String s = Thread.currentThread().getStackTrace()[3].getMethodName();
        Method cm = null;
        for(Method m : o.getClass().getMethods()){
            if(m.getName().equals(s)){
                cm = m; break;
            }
        }
        return cm;
    }
    
    //rtineo mejoras PAS20155E220000397
    public static final List<String> obtenerListCadenas(String cadena, int tamano){
    	List<String> listCadenas = new ArrayList<String>();
    	String cadenaTmp = cadena;
    	String cadenaNormal = "";
		int posicionFinal = 0;
		while (cadenaTmp.length() > tamano){
			cadenaNormal = cadenaTmp.substring(0, tamano);
			posicionFinal = cadenaNormal.lastIndexOf(",");
			cadenaNormal = cadenaNormal.substring(0, posicionFinal);
			listCadenas.add(cadenaNormal);
			cadenaTmp = cadenaTmp.substring(posicionFinal+1);
		}
		if(cadenaTmp.endsWith(",")){
			cadenaTmp = cadenaTmp.substring(0, cadenaTmp.length()-1);			
		}
		listCadenas.add(cadenaTmp);
    	return listCadenas;
    }
    
	//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuaci�n a la destinaci�n con punto de llegada deposito aduanero sin transmitir regimen precedente 70
	public static boolean esEnvioDepositoAduaneroSinPrecendencia(Declaracion declaracion, DUA dua, Elementos<DatoSerie> listSeries){
		boolean rpta = false;
		try{
			String codigoPuntoLLegadaMercancia = dua.getCodlugarecepcion();
			int cnt_series_con_precedencia = 0;
			if(codigoPuntoLLegadaMercancia.equals(Constants.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)){
				//Verifica que en todas las series no se transmitio ningun regimen de precedencia
				for (DatoSerie serie : listSeries) {
					if(serie.getListRegPrecedencia() != null && serie.getListRegPrecedencia().size() > 0){
						cnt_series_con_precedencia++;
					}
				}				
			}
			
			if(cnt_series_con_precedencia == 0){
				rpta = true;
			}

		}catch(Exception e){
			//log.error("ValCabduaServiceImpl.esEnvioDepositoAduaneroSinPrecendencia",e);
		}
		
		return rpta;
	}
	//Fin M_SNADE255-2
	
	//I - YKVR 19/04/2018
	public static boolean esMayorDeEdad(Date fechaNacimientopActual) {
		boolean esMayorDeEdad = false;
		Date fechaActual = new Date();
		// hsaenz PAS20181U220400008: Correccion de bug - se comenta codigo anterior
		/*long diferencia = Math.abs(fechaActual.getTime() - fechaNacimientopActual.getTime());
		long annios = diferencia / (24 * 60 * 60 * 1000);
		if(annios >= 18) {
			esMayorDeEdad = true;
		}*/
		fechaActual = SunatDateUtils.addYear(fechaActual, -18);
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaActual, fechaNacimientopActual, SunatDateUtils.COMPARA_SOLO_FECHA)) {
			esMayorDeEdad = true;
		}
		// Fin hsaenz PAS20181U220400008
		return esMayorDeEdad;
	}
	//F - YKVR 19/04/2018
}
