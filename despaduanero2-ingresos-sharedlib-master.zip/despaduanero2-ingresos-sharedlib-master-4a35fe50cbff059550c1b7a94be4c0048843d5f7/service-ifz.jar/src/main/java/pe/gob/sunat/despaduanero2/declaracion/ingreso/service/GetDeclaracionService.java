package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.model.Participante;

public interface GetDeclaracionService {

	public Declaracion getDeclaracion(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen);
	
	//RMC RIN-P47
	public Declaracion getDeclaracion(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen, String codTipoTransaccion);
	
	public DUA getDUA(Map<String, Object> params);
	
	//public DocuPreceDuaDAO getDocuPreceDuaDAO();
	
	public int countDeclaraciones(Map<String, Object> params);
	
	/*branch ingreso 2011-029 hosorio inicio 14/07/2011*/
	public List<DatoSerie> getLstDatoSerie(Map<String,Object> params);
	/*branch ingreso 2011-029 hosorio fin 14/07/2011*/
	
	/* olunar - 309 */
	/**
	 * Obtiene los datos principales de la DUA (cabDeclara)
	 * 
	 * @author olunar
	 * 
	 * @param codigoAduana
	 * @param numeroDeclaracion
	 * @param annoPresentacion
	 * @param codigoRegimen
	 * @return DUA
	 */
	public DUA getCabDUA(String codigoAduana, String numeroDeclaracion, String annoPresentacion, String codigoRegimen);
	
	/**
	 * Obtiene los datos principales de la DUA (cabDeclara) por el numero correlativo
	 * 
	 * @param numcorredoc
	 * @return DUA
	 */
	public DUA getCabDUA(Long numcorredoc);
	/* fin */
	
	public List<Declaracion> getDeclaracionPendienteRegularizar(Participante importador, Integer plazo, String modalidad, String indRegul);
	
	//ggranados formb
	DUA getDUAResumida(Map<String, Object> params);
	Declaracion getDeclaracionResumida(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen);
	
	// FIXME RIN16 : lpalominom [inicio]
	/**
	 * Permite verificar si una declaracion tuvo asignado en algun momento el estado consultado
	 * @param declaracion
	 * @return boolean
     * 	<br>[<strong>true</strong>]  : Si <u>SE LE ASIGNO</u> en algun momento el estado consultado.
     * 	<br>[<strong>false</strong>] : Si <u>NO SE LE ASIGNO</u> en algun momento el estado consultado.
	 */
	public boolean existeEstadoHistorico(Declaracion declaracion);
	// FIXME RIN16 : lpalominom [fin]
	
	/**Inicio de cambios PAS20165E220200032***/
	
	/**
	 * Permite verificar si una declaracion fue numerada despues de la vigencia de la NLGA 
	 * @param paramPendienteReg
	 * @return
	 */
	public boolean esVigenteNuevaLGA(Declaracion declaracion); 
	
	/**
	 * Permite verificar si una declaracion fue numerada despues de la vigencia de la NLGA 
	 * @param paramPendienteReg
	 * @return
	 */
	public boolean esVigenteNuevaLGAPorFecha(Date fechaNumeracion);
	
	/**Fin de cambios PAS20165E220200032***/
	
	/**
	 * Obtiene las declaraciones pendientes de regularizar en base a parametros 
	 * @param paramPendienteReg
	 * @return
	 */
	public List<Declaracion> getDeclaracionPendienteRegularizar(Map<String,Object> paramPendienteReg);
	
	/**
	 * Retorna series de una declaracion
	 * @param paramsDetDeclaracion
	 * @return
	 */
	public List<Map<String, Object>> getDetDUA (Map<String,String> paramsDetDeclaracion);
	/**
	 * Retorna los datos de la Dua EER
	 */
	public DUA getDUAEER(Map<String, Object> params); 
}
