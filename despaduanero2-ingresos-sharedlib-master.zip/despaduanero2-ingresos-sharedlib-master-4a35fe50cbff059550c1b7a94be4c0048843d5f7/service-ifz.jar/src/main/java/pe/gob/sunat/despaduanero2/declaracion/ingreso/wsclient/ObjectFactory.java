
package pe.gob.sunat.despaduanero2.declaracion.ingreso.wsclient;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;




/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the pe.gob.sunat.despaduanero2.seleccion.service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Asignar_QNAME = new QName("http://service.seleccion.despaduanero2.sunat.gob.pe/", "asignar");
    private final static QName _AsignarResponse_QNAME = new QName("http://service.seleccion.despaduanero2.sunat.gob.pe/", "asignarResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: pe.gob.sunat.despaduanero2.seleccion.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AsignarResponse }
     * 
     */
    public AsignarResponse createAsignarResponse() {
        return new AsignarResponse();
    }

    /**
     * Create an instance of {@link Asignar }
     * 
     */
    public Asignar createAsignar() {
        return new Asignar();
    }

    /**
     * Create an instance of {@link ResponseSeleccion }
     * 
     */
    public ResponseSeleccion createResponseSeleccion() {
        return new ResponseSeleccion();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Asignar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.seleccion.despaduanero2.sunat.gob.pe/", name = "asignar")
    public JAXBElement<Asignar> createAsignar(Asignar value) {
        return new JAXBElement<Asignar>(_Asignar_QNAME, Asignar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AsignarResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.seleccion.despaduanero2.sunat.gob.pe/", name = "asignarResponse")
    public JAXBElement<AsignarResponse> createAsignarResponse(AsignarResponse value) {
        return new JAXBElement<AsignarResponse>(_AsignarResponse_QNAME, AsignarResponse.class, null, value);
    }

}
