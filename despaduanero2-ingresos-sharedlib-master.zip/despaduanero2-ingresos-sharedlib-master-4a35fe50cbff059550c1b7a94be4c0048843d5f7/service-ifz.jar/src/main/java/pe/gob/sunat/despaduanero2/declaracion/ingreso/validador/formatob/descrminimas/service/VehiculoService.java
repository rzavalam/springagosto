package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import java.math.BigDecimal;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * Created by amancillaa on 20/06/14.
 */
public interface VehiculoService
{

    /**
     * Obtiene el objeto VEHICULO poblada con los datos enviados en la transmision
     * para cargar dicha informacion se tiene que enviar la informacion con la nueva estructura.
     *
     * @param item
     * @param declaracion
     * @return Vehiculo
     */
    public Vehiculo obtenerVehiculo(DatoItem item, Declaracion declaracion) throws Exception;

    public String obtenerMarca(DatoItem item,Declaracion declaracion) throws Exception;

    public String obtenerModelo(DatoItem item,Declaracion declaracion) throws Exception;

    public String obtenerChasis(DatoItem item,Declaracion declaracion) throws Exception;

    public String obtenerRevisa1(DatoItem item,Declaracion declaracion) throws Exception;

    public String obtenerGastosReparacion(DatoItem item,Declaracion declaracion) throws Exception;
   
    /*Validacion antiguedad vehiculos -arey*/   
    public String obtenerIndicadorSNTT(DatoItem item, Declaracion declaracion) throws Exception;
    
    public String obtenerTipoEncendido(DatoItem item, Declaracion declaracion) throws Exception;
    
    public String obtenerCategoria(DatoItem item, Declaracion declaracion) throws Exception;
    
    public BigDecimal obtenerKilometraje(DatoItem item, Declaracion declaracion) throws Exception;
    
    public int obtenerPesoBrutoKG(DatoItem item, Declaracion declaracion) throws Exception;
    /*Fin Validacion antiguedad vehiculos*/
    
    /**Adicionado por PAS20155E220000260 por errores en validacion de CETICOS en minimas AREY**/
    public String obtenerVIN(DatoItem item, Declaracion declaracion) throws Exception;
     
    /**Adicionado por PAS20175E220200059**/
    public String obtenerCarroceria(DatoItem item, Declaracion declaracion) throws Exception;
    
    /**Adicionado por PAS20191U220500021**/
    public String obtenerAnoModelo(DatoItem item, Declaracion declaracion) throws Exception;
     
}
