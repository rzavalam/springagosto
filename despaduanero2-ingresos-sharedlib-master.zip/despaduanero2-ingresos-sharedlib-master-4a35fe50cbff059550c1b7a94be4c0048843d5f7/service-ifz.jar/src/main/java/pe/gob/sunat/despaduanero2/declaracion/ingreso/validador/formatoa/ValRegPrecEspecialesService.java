package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValRegPrecEspecialesService {

	/**
	 * Validaciones de regimen de precedencia especial
	 * @param declaracion
	 * @param fechaReferencia
	 * @param codRegimenEspecial
	 * @return
	 */
	public List<Map<String, String>>  validarDatosGenerales(Declaracion declaracion, Date fechaReferencia, String codRegimenEspecial);
	public Map<String, String>  valEnvioManifiesto(DatoManifiesto manifiesto, String codRegimenEspecial);
	public Map<String, String>  valModalidad(String codModalidad, String codRegimenEspecial);
	public Map<String, String>  valTipoPrecedenteUnico(DUA dua, String codRegimenEspecial);
	public List<Map<String, String>> valSeriesConPrecedencia (List<DatoSerie> listSeries, String codRegimenEspecial);
	public List<Map<String, String>> valSeriesUnicoItemPrecedencia (List<DatoSerie> listSeries, String codRegimenEspecial, String codAduanaOrden);
	public boolean valRegimenPrecedenteEspecial(String codRegimenEspecial);
}