package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * The Class ValContrat.
 * Clase sin funcion relacionada.
 * @deprecated Clase sin funcion relacionada.
 */
public interface ValContrat {
	
	public Map<String, String> numfactu(String numfactu);
	
	public Map<String, String> fecfactu(Date fecfactu);
	
	public Map<String, String> mtotfobfact(BigDecimal mtofobfact);
	
	public Map<String, String> codtipodocexpo(String codtipodocexpo);
	
	public Map<String, String> numrucdocexpo(String numrucdocexpo);
	
	public Map<String, String> porparti(BigDecimal porparti);
}
