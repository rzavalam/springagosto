/*
 * Clase que define el servicio de validaciones de Relaci�n de indicadores no comunes  para ciertos regimenes
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValIndicad. Clase que define el servicio de validaciones de Relaci�n de indicadores no comunes  para ciertos regimenes.
 */
public interface ValIndicad {
	
	public Map<String, ?> codtipoindica(String codtipoindica);
	
	public Map<String, ?> valindicador(String valindicador);
    
        public Map<String, String> valIndicadorRegularizable(Declaracion declaracion, Date fechaReferencia,  String codTransaccion);
        
	
        public Map<String, String> valTipoIndicadorRegularizable(Declaracion declaracion);

        public boolean tieneUnidfis(String codigoUnidfis);

        public List<Map<String, String>> valIndicadorManifiesto(Declaracion declaracion, Map<String, Object> variablesIngreso,  String codTransaccion, Date fechaReferencia);

        
}
