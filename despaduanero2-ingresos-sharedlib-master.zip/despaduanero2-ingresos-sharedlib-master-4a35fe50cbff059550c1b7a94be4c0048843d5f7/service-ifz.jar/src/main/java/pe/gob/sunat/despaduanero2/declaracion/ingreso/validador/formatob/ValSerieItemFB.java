package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValSerieItemFB {
	
	public Map<String, String> numserie(DatoSerieItem serieItem, Declaracion declaracion);
        public Map<String, String> verificarSerieFormatoAEstaEnFormatoB(DatoSerie serie);
        public boolean serieFormatoAEncuentraEnFormatoB(DatoSerie serie);
	public Map<String, String> mtofobitser(DatoSerie serie);
	public Map<String, String> mtoajuitser(DatoSerie serie, Declaracion declaracion);
	public List<DatoSerieItem> getSeriesItemCorrespondiente(DatoSerie serie, Declaracion declaracion);
        public Map<String, String> validarCantUniComerSerieXSerieItem(DatoSerie serie);
        public List<Map<String, String>> validarDatosSerieXSerieItem(DatoSerie serie);
        public Map<String, String> validarExisteItemFBEnCorrelacionSerieFA(DatoItem item);
        public Map<String, String> validarExisteItemFAEnCorrelacionSerieFB(DatoSerieItem serieItem);  
}
