package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.depositotemporal;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValDepositoTemporalService {
	
	public List<Map<String, String>> valEstadoRegistroDTEERGral(String numRuc);
	
	public List<Map<String, String>> valEstadoRegistroDTEER(Declaracion declaracion);
	
	public List<Map<String, String>> valEstadoHabilitacionDTEERGral(String numRuc);
	
	public List<Map<String, String>> valEstadoHabilitacionDTEER(Declaracion declaracion);
	
	public List<Map<String, String>> valEstadoNumeroRucDTEERGral(String numRuc);
	
	public List<Map<String, String>> valEstadoNumeroRucDTEER(Declaracion declaracion);
	
	public List<Map<String, String>> valCondicionNumeroRucDTEERGral(String numRuc);
	
	public List<Map<String, String>> valCondicionNumeroRucDTEER(Declaracion declaracion);
	
	public List<Map<String, String>> valCircunscripcionDTEERGral(String numRuc, String codAduana);
	
	public List<Map<String, String>> valCircunscripcionDTEER(Declaracion declaracion);
}
