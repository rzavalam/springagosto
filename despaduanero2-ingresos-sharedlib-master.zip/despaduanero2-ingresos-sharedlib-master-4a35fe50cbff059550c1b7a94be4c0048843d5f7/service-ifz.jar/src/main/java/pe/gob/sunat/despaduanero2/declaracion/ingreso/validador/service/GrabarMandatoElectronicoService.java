package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;

public interface GrabarMandatoElectronicoService {

	/**
	 * Si la declaracion cuenta con mandato electronico, procede a grabar el indicador y la asociacion con la solicitud de mandato
	 * @param dua
	 * @param fechaReferencia
	 * @param codTransaccion
	 */
	public String grabarMandatoElectronico(DUA dua, Date fechaReferencia, String codTransaccion);
}
