package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.pesos;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface ValPesoEERService {
	public List<Map<String,String>> valPesoCategoria0203(DatoSerie serie, String codCategoria);
}
