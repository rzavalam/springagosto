package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetSolicitudRectificacionBean {
	
	/*amancillla*/
	private Long numCorreDoc;
	private String codUsuarioRegistro;
	private String codtabla;
	private String desclave;
	private String desdata1;
	private String desantdata1;
	private String tipoCambio;
	//branch ingreso 2011-009 gmontoya 16 inicio
	private String tipodiligencia;
	//branch ingreso 2011-009 fin
	private Map<String,Object> Key;
	private Map<String,DatoRectificacionBean> datosRectificados;
	private List<RecordBean> listaReferencias;

	public String getCodtabla() {
		return codtabla;
	}

	public void setCodtabla(String codTabla) {
		this.codtabla = codTabla;
	}

	public Map<String, Object> getKey() {
		return Key;
	}

	public void setKey(Map<String, Object> key) {
		Key = key;
	}

	public DetSolicitudRectificacionBean(String codTabla, Map<String, Object> key) {
		super();
		this.codtabla = codTabla;
		this.Key = key;
		
		this.datosRectificados=new HashMap<String, DatoRectificacionBean>();
	}
	
	//branch ingreso 2011-009 gmontoya 16 inicio
	public DetSolicitudRectificacionBean(String codTabla, Map<String, Object> key,String tipoDiligencia) {
		super();
		this.codtabla = codTabla;
		this.Key = key;
		this.tipodiligencia = tipoDiligencia;
		
		this.datosRectificados=new HashMap<String, DatoRectificacionBean>();
	}
	/*amancilla*/
	public DetSolicitudRectificacionBean(Long numCorreDoc, String usuario, String codTabla, Map<String, Object> key,String tipoDiligencia) {
		super();
		this.numCorreDoc = numCorreDoc;
		this.codUsuarioRegistro = usuario;
		this.codtabla = codTabla;
		this.Key = key;
		this.tipodiligencia = tipoDiligencia;
		
		this.datosRectificados=new HashMap<String, DatoRectificacionBean>();
	}
	
	//branch ingreso 2011-009  fin
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Key == null) ? 0 : Key.hashCode());
		result = prime * result
				+ ((codtabla == null) ? 0 : codtabla.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final DetSolicitudRectificacionBean other = (DetSolicitudRectificacionBean) obj;
		if (Key == null) {
			if (other.Key != null)
				return false;
		} else{
			/*branch ingreso 2011-033 hosorio inicio*/
			if (codtabla == null) {
				if (other.codtabla != null)
					return false;
			} else {if (!codtabla.equals(other.codtabla))
				return false;
			}
			/*branch ingreso 2011-033 hosorio fin*/
		   for(String k:Key.keySet()){
			   if(other.Key.containsKey(k)){
				   //si son numericos compara a nivel de valor. esto es por que el Json te devuelve integer
				   if(Key.get(k) instanceof Number && other.Key.get(k) instanceof Number ){
					   if(!Key.get(k).toString().equals(other.Key.get(k).toString())){
						   return false;
					   }
				   }
				   else{
					   if(!Key.get(k).equals(other.Key.get(k))){
						   return false;
					   }
				   }
			   }
			   else return false;
		   } 
		   return true;
		} 
			
		/*branch ingreso 2011-033 hosorio inicio*/
		/*
		if (codtabla == null) {
			if (other.codtabla != null)
				return false;
		} else if (!codtabla.equals(other.codtabla))
			return false;
		*/
		/*branch ingreso 2011-033 hosorio fin*/
		return true;
	}

//	public Map<String, Object> getDatosRectificados() {
//		return datosRectificados;
//	}
//
//	public void setDatosRectificados(Map<String, Object> datosRectificados) {
//		this.datosRectificados = datosRectificados;
//	}

	public String getDesclave() {
		return desclave;
	}

	public void setDesclave(String desclave) {
		this.desclave = desclave;
	}

	public String getDesdata1() {
		return desdata1;
	}

	public void setDesdata1(String desdata1) {
		this.desdata1 = desdata1;
	}

	public String getDesantdata1() {
		return desantdata1;
	}

	public void setDesantdata1(String desantdata1) {
		this.desantdata1 = desantdata1;
	}

	public String getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(String tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public List<RecordBean> getListaReferencias() {
		return listaReferencias;
	}

	public void setListaReferencias(List<RecordBean> listaReferencias) {
		this.listaReferencias = listaReferencias;
	}

	public Map<String, DatoRectificacionBean> getDatosRectificados() {
		return datosRectificados;
	}

	public void setDatosRectificados(
			Map<String, DatoRectificacionBean> datosRectificados) {
		this.datosRectificados = datosRectificados;
	}

	public String getTipodiligencia() {
		return tipodiligencia;
	}

	public void setTipodiligencia(String tipodiligencia) {
		this.tipodiligencia = tipodiligencia;
	}

	public String getCodUsuarioRegistro() {
		return codUsuarioRegistro;
	}

	public void setCodUsuarioRegistro(String codUsuarioRegistro) {
		this.codUsuarioRegistro = codUsuarioRegistro;
	}

	public Long getNumCorreDoc() {
		return numCorreDoc;
	}

	public void setNumCorreDoc(Long numCorreDoc) {
		this.numCorreDoc = numCorreDoc;
	}

	
}
