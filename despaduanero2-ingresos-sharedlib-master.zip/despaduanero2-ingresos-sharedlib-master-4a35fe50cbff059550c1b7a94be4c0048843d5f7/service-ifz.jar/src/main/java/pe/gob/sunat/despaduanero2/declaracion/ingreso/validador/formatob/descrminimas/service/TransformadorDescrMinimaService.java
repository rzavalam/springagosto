package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;

/**
 * La Interface TransformadorDescrMinimaService.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public interface TransformadorDescrMinimaService {



  /**
   * llena los datos enviados lstDatosXML al tipo especifico de descripcion
   * minima tipoDescrMinima
   *
   * @param tipoDescrMinima
   * @param lstDatosXML
   * @return Objeto descripcion minima con sus respectivos datos.
   */
  public ModelAbstract
  poblarObjetoDescrMinima(Enum tipoDescrMinima, DatoItem item, Declaracion dua) throws Exception;

  public ModelAbstract
  poblarObjetoDescrMinima(Enum tipoDescrMinima, DatoItem item, Declaracion dua, String tipoDiligencia) throws Exception;

  /**
   * verifica si el item registrado en la BD es un tipo de descripcion minima si
   * es un tipo registrador lo llena con los datos registrados en la BD
   *
   * @param tipoDescrMinima
   * @param numCorreDoc
   * @param numSecItem
   * @return Objeto descripcion minima con sus respectivos datos. NULL en caso
   *         sea item sin descripcion minima
   */
  public ModelAbstract poblarObjetoDescrMinima(String numCorreDoc, String numSecItem);

  /**
   * el item registrado en la BD debe ser una descripcion minima de vehiculo
   *
   * @param numCorreDoc
   * @param numSecItem
   * @return Vehiculo o NULL
   */
  public ModelAbstract obtenerDescrMinima(String numCorreDoc, String numSecItem, Enum<?> tipo);

  /**
   * item debe tener List<DatoDescrMinima> con la estructura de vehiculo
   *
   * @param item
   * @return Vehiculo o NULL
   */
  public ModelAbstract obtenerDescrMinima(DatoItem item, Enum<?> tipo);


  /**
   * muestra los datos consultados de bd con el tipo especifico de descripcion
   * minima tipoDescrMinima
   *
   * @param tipoDescrMinima
   * @param numCorreDoc
   * @param numSecItem
   * @return Objeto descripcion minima con sus respectivos datos.
   */
  public ModelAbstract obtenerObjetoDescrMinima(long numCorreDoc, int numSecItem, String tipoDescrMinima);


  public ModelAbstract obtenerObjetoDescrMinima(long numCorreDoc, int numSecItem,String tipoDescrMinima, String tipoDiligencia);

}
