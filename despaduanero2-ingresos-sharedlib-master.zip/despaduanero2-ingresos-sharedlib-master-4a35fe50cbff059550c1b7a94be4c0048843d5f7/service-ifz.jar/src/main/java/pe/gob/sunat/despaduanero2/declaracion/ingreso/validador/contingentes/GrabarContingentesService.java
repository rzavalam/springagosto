package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarContingentesService {

	List<Map<String, String>> procesaContingente(Map<String, Object> variablesIngreso, Declaracion declaracion, List<Map<String, String>> listaErrores);
	
	List<Map<String, String>> procesaContingenteNumeracion(Map<String, Object> variablesIngreso, Declaracion declaracion);
	
	/*brach ingreso 2011-029 hosorio inicio 15/07/2011*/
public List<Map<String, String>> procesarContingenteDiligencia(Declaracion declaracion,Map<String,Object> parametros, Boolean blGrabaRectiDefinitivo);
	/*brach ingreso 2011-029 hosorio fin 15/07/2011*/

	//List<Map<String, String>> procesaContingenteRectificacion(Map<String, Object> variablesIngreso, Declaracion declaracion);

//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
	//RMC RIN-P47
  public void procesarContingenteRectificacionElectronica(Map<String, Object> prmContingente, List<Map<String, Object>> lstSeries) throws ServiceException;

	//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
		//RMC RIN-P47
// public void procesarContingenteRectificacionElectAnterior(Map<String, Object> prmContingente ) throws ServiceException;
	
//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
	//RMC RIN-P47
//	public void recuperaContingenteDiligRectificacion(Map<String, Object> prmContingente) throws ServiceException;

}
