/*
 * Clase que define el servicio de validaciones de los montos de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Map;

/**
 * The Class ValMGastos. Clase que define el servicio de validaciones de los montos de la DUA
 */
public interface ValMGastos {
	
	public Map<String, String> tipmonto(String tipmonto);
	
	public Map<String, String> valmonto(BigDecimal valmonto);
	
}
