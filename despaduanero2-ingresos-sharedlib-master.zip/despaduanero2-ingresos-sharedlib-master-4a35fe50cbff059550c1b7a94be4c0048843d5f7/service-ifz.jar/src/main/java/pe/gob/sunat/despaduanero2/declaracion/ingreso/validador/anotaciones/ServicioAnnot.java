package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ServicioAnnot {
	String tipo() default "V";
	int codServicio();
	String descServicio() default "";
}


