package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValFactura {
	
	public Map<String, String> numsecfactu(Declaracion declaracion);
	public List<Map<String, String>> numfactura(DatoFactura datoFactura);
        public Map<String, String> existeFacturaFAenFB(DatoFacturaref facturaRef);
	public Map<String, String> indtipodecl(DatoFactura factura);
	public Map<String, String> cnttotitems(DatoFactura factura);
	public Map<String, String> codincoterm(DatoFactura factura);
	public Map<String, String> deslugtrans(DatoFactura factura);	
	public Map<String, String> codpaisembar(DatoFactura factura) ;
	public Map<String, String> codmoneda(DatoFactura factura);
	public Map<String, String> valgralfactfb1(DatoFactura factura);
	public Map<String, String> validarDiferenciaFobFacturaItems(DatoFactura factura);	
        public List<Map<String, String>> valPaisAdquiFactura (DAV dav, Declaracion declaracion);
        public Map<String, String> fecfactura (Date fecfactura) ;
        public Map<String, String> validarNumeroFacturaNoSeRepite(DAV dav);
        public List<Map<String, String>> validarFechaFactura(DatoFactura factura, Date fechaReferencia);
        public Map<String, String> mtofactufob(DatoFactura factura);
        public List<Map<String, String>> validarFechaFacturaRecti(DatoFactura factura, Date fechaReferencia, Map<String,Object> variablesIngreso, Declaracion declaracionBD); //adicionado pase 56 arey  
         
}
