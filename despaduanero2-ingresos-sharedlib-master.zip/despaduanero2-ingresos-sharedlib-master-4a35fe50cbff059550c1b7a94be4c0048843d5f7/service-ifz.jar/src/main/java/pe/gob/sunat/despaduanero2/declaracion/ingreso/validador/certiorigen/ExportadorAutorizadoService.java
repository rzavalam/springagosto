package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface ExportadorAutorizadoService  {

	/**
	 * Para tipo de certificado de origen igual a 5 valida que la autorizacion de exportador se envia y corresponda al registrado en el modulo de firmas
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valExportadorAutorizadoHabilitado (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 si se transmitio el numero de la autorizacion de exportador se verifica que este registrado en el modulo de firmas
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valExportadorAutorizadoHabilitadoCondicional (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar el nombre del emisor
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valExportadorAutorizado (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar como documento de soporte la identificacion del documento comercial
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valExportadorAutorizadoDocComercial (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);

	/**
	 * Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar el valor y monto de la factura
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valExportadorAutorizadoDatoFactura (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
}
