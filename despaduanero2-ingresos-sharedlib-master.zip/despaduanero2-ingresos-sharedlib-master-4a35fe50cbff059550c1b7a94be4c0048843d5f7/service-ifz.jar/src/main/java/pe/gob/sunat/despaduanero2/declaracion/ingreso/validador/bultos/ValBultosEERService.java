package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bultos;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValBultosEERService {
	public List<Map<String,String>> valBultos0203(Declaracion declaracion, String codCategoria);
}
