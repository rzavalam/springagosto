package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.donacion;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ImpugnacionTributosParaDonacionService {
	
	/**
	 * Valida todo lo relacionado a donaci�n sin documento autorizante
	 * */
	public List<Map<String,String>> validarImpugnacionDeTributos(Declaracion declaracion, Declaracion declaracionBD);
	
	/**
	 * Valida requisitos para impugnar tributos de donaci�n
	 * */
	public boolean cumpleRequisitosParaImpugnarTributos(Declaracion declaracion);
	
	/**
	 * Valida el envio de expediente solo para el tipo de donaci�n con impugnaci�n parcial 06
	 * */
	public List<Map<String,String>> validarExpediente(Declaracion declaracion);
	
	/**
	 * Valida si cuenta con garantia 160
	 * */
	public List<Map<String,String>> validarGarantia160(Declaracion declaracion);
	
	/**
	 * Valida que la declaraci�n con Impugnaci�n de Tributos por Donaci�n, 
	 * no consigne Tratamiento Preferencial Arancelario
	 * */
	public List<Map<String,String>> validarTratamientoPreferencial(Declaracion declaracion, DatoSerie serie);
	
	/**
	 * Valida que la LC tipo 0006 este cancelada
	 * */
	public List<Map<String,String>> validarCancelacionLC006(Declaracion declaracion);
	
	/**
	 * 
	 * */
	public boolean estaImpugnadaDeuda(Declaracion declaracion);
	
	
	public boolean noEstaCanceladaImpugnacionDeDonacion(Map declaracion);


}
