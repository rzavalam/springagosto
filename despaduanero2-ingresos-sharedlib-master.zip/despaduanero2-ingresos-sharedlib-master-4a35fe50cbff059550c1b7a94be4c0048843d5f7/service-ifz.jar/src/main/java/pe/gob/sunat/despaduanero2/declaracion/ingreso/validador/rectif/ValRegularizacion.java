/*
 * Clase que define el servicio de validaciones de las Regularizaciones
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
//import pe.gob.sunat.despaduanero2.declaracion.model.Depocta;

public interface ValRegularizacion {
		
	public Map<String, Object> setupDeclaracion(Declaracion declaracion, 
		String numOrden,
		String codUsuario, 
		Integer annEnvio, 
		Long numEnvio,
		String tipoSender,
		String numeroDocumentoIdentidadSender,
		String tipoDocumentoIdentidadSender, String codTransaccion) throws Exception;
	
	
	public Map<String, String> validarDuaEnvieFormatoB(String codTransaccion,Declaracion declaracion);
		
	public List<java.util.Map<String, String>> validarTipoModalidad(Declaracion declaracion,Declaracion declaracionBD,String codTransaccion) throws Exception;
	
	public Map<String, String> validarEstadoLevanteDua(Declaracion declaracion,Declaracion declaracionBD) throws Exception;
	
	public Map<String, String>  validarDocumentosTransporte(Map<String, Object> variablesIngreso);
    
	public List<java.util.Map<String, String>> validarDuaRegularizada(Declaracion declaracion, Declaracion declaracionBD) throws Exception;
	
	public List<java.util.Map<String, String>> validarCambioFob(Declaracion declaracion,Declaracion declaracionBD) throws Exception;
	
	public List<java.util.Map<String, String>> validarSeriesDuaAnticipada(Map<String, Object> variablesIngreso) throws Exception;
	
	public List<java.util.Map<String, String>> validarTx05(Map<String, Object> variablesIngreso,String codTransaccion) throws Exception;
	
	public  Map<String, String>  validarDescargos(Declaracion declaracion) throws Exception;
	// RIN16
	public HashMap<String, Object> asignarVariableRegularizacion(Declaracion declaracion,Declaracion declaracionBD,Map<String,Object> variablesIngreso) throws Exception;

	public List<Map<String, String>> validaPuertoEmbarque(Declaracion declaracion, String codTransaccion);

	
	public Map<String,String> validarCodigoPorProceso(Declaracion declaracion, Map<String, Object> variablesIngreso);
	
	public Map<String,String> validarExpediente(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception; 
	
	public List<Map<String, String>> validaAutoLiquidacion(Declaracion declaracion, Map<String, Object> variablesIngreso);	
	
	public List<Map<String, String>> validaDocumentosDeTransporte(Declaracion declaracion, Map<String, Object> variablesIngreso);
	// RIN16
	public List<Map<String, String>> validarPendienteDeRegularizar(Declaracion declaracion, Declaracion declaracionBD) throws Exception;
	
	public List<Map<String, String>> validarFecLlegaAnticipado(Declaracion declaracion);
	
	public List<Map<String, String>> validarPlazoRegularizacion(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception;
	
	public Map<String,String> validarSolicitudDeContinuacion(Declaracion declaracion); //Registrado como servicio 3465
}
