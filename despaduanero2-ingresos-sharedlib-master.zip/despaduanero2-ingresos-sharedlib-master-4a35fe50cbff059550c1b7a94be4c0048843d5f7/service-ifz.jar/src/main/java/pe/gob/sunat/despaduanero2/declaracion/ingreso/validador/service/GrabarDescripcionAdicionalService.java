package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarDescripcionAdicionalService {
	
	void grabaDescripcionOtros(Declaracion declaracion);

}
