package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;


import java.util.Date;
import java.util.Map;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;


public interface ValDeclaranteFB {
	
	
	public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante);

	public Map<String, String> codtipdocparticipante(DAV dav) ;	
	public Map<String, String> numdocparticipante(DAV dav) ;
	public Map<String, String> nomparticipante(DAV dav) ;
        public Map<String, String> validarCargoDeclarante(DAV dav);
        public Map<String, String> vigenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad,Date fecha_referencia);
        public Map<String, String> existenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad);
        public Map<String, String> formatoTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad);
        public Map<String, String> edadPersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,Date fecha_referencia);
        public Map<String, String> codTipDocParticipanteDecl(String tipoDocumentoIdentidad);
        public Map<String, String> validarNombrePersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,String nombreDeclaranteTransmitido);
        
        //glazaror... nuevos metodos codtipparticipante, numdocparticipante
        public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante, Map<String, Object> variablesIngreso);
        //public Map<String, String> numdocparticipante(DAV dav, Map<String, Object> variablesIngreso);
        public Map<String, String> codtipdocparticipante(DAV dav, Map<String, Object> variablesIngreso);
}
