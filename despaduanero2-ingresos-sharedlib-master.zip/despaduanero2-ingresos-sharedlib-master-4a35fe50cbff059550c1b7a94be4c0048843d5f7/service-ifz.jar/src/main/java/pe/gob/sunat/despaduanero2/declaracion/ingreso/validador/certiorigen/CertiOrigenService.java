package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.catalogo.tg.model.AutExportador;
import pe.gob.sunat.despaduanero.catalogo.tg.model.EquivMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface CertiOrigenService {
	
	public List<Map<String, String>> valUnicoCOSerie(DatoSerie serie);
	
	public List<Map<String,Object>> consultarRegistroFuncionario(String codffco, String codpais, Date fechaReferencia);
	
	public AutExportador consultarAutorizacionExportador(String numAutorizExp, String codPaisorigen, String codConvenio, Date fechaReferencia);
	
	public EquivMonto consultarMontoEquivalente(String codmoneda, Date fechaReferencia);
	
	//rtineo: optimizacion
	public Map<String, EquivMonto> consultarMontosEquivalente(String codigosMoneda, Date fechaReferencia);
	public List<AutExportador> getListadoAutorizacionExportador(String numDocumento);
	//fin optimziacion

}
