package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;//RIN10

import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.DipolizaiDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.pa.model.dao.Ratcc3DAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitCcDAO;
import pe.gob.sunat.despaduanero.despacho.model.dao.NotiDudaCabDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabdua;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeudaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabNacioTempoDAO;

//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DatadoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovDuasActasDAO;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovManifiestosActasDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.DetaliqDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.MovCabliqdiligDAO;
import pe.gob.sunat.recauda2.genadeudo.service.ImputacionService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
//import pe.gob.sunat.despaduanero2.ayudas.model.dao.CantmaxlibeDAO;
/* Inicio RIN10 3007 erodriguezb */
import pe.gob.sunat.recauda2.garantia.model.dao.CabCtaCteGarDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.PadUsuGaraDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
/* Fin RIN10 3007 erodriguezb */
//P34 3007 JMCV INICIO
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
//P34 3007 JMCV FIN

@Deprecated
public class RectificacionServiceImpl implements RectificacionService {
  private RectiOficioDAO rectioficioDAO;
  private CabDiligenciaDAO cabdiligenciaDAO;
  private CabManifiestoDAO manifiestoDAO;
//  private 	CantmaxlibeDAO cantMaxLibeDAO;
  private DatadoDAO datadoDAO;
  //private DatadoService datadoservice;
//  private DdpDAO ddpDAO;
  private LiquidaDAO liquidaDAO;
  private DetaliqDAO detaliqDAO;
  private IndicadorDUADAO indicadorDUADAO;
  private SequenceDAO sequenceDAO;
  private DocumentoDAO documentoDAO;
  private SolicitudDAO solicitudDAO;
  private RelacionDocDAO relaciondocDAO;
  private CabSolrectiDAO solirectificaDAO;
  private DetSolRectiDAO detsolrectiDAO;
  private CabDeclaraDAO cabdeclaraDAO;
  private DeudaDocumDAO deudaDocumDAO;
  private ValidacionGeneralService validaciongeneralservice;  
  private CatalogoHelperImpl catalogoHelper;
  private GeneraLiquidacionService generaLiquidacionService;
  private GetDeclaracionService declaracionService;
  private static RectificacionServiceImpl instance;
  private ProveedorFuncionesService funcionesService;
  private LiquidaDeclaracionService liquidaDeclaracionService;
  private CatalogoAyudaService catalogoayudaservice;
  private ValCabdua valcabdua;
  private ImputacionService imputacionService;
  private DetPagoDuaDAO detPagoDuaDAO;
  private GetValidacionesService validacionesService;
  private Ratcc3DAO ratcc3DAO;	
  private RitCcDAO ritccDAO;	
  private DepoctaDAO depoctaDAO;
  private MovNGarantiaDAO  movNGarantiaDAO;
  /*hosorio inicio 06/04/2011*/
  private MovCabliqdiligDAO movCabliqdiligDAO;
  private CabDeudaDAO cabDeudaDAO;
  private NotiDudaCabDAO notiDudaCabDAO;
  /*hosorio fin 06/04/2011*/
  
  /*hosorio inicio 28/04/2011*/
   private MovDuasActasDAO movDuasActasDAO;
   private MovManifiestosActasDAO movManifActasDAO;
   private DipolizaiDAO diPolizaDAO;
  /*hosorio fin 28/04/2011*/
  
	private CabNacioTempoDAO cabNacioTempoDAO; 
	
//P34 3007 JMCV INICIO
	private RectificacionOficioService rectificacionOficioService;	
	
	public RectificacionOficioService getRectificacionOficioService() {
		return rectificacionOficioService;
	}
	public void setRectificacionOficioService(
			RectificacionOficioService rectificacionOficioService) {
		this.rectificacionOficioService = rectificacionOficioService;
	}	
//P34 3007 JMCV FIN

	
	/*fduartej ini 15.08.2011 branch-ingreso-sharedlib*/
	private SoporteService soporteService;
	private DetDeclaraDAO detDeclaraDAO;
    
	//INICIO pase 2012-945
	private ManifiestoService manifiestoService;
	private ManifiestoSigadService manifiestoSigadService;
	
	/* Inicio RIN10 3007 erodriguezb */
	private PadUsuGaraDAO padUsuGaraDAO;
	private CabCtaCteGarDAO cabCtaCteGarDAO;
	/* Fin RIN10 3007 erodriguezb */
	
	/* inicio oneyraj rin10  */
	private DataCatalogoDAO dataCatalogoDAO;
	
	public PadUsuGaraDAO getPadUsuGaraDAO() {
		return padUsuGaraDAO;
	}

	public void setPadUsuGaraDAO(PadUsuGaraDAO padUsuGaraDAO) {
		this.padUsuGaraDAO = padUsuGaraDAO;
	}

	public CabCtaCteGarDAO getCabCtaCteGarDAO() {
		return cabCtaCteGarDAO;
	}

	public void setCabCtaCteGarDAO(CabCtaCteGarDAO cabCtaCteGarDAO) {
		this.cabCtaCteGarDAO = cabCtaCteGarDAO;
	}

	public DataCatalogoDAO getDataCatalogoDAO() {
		return dataCatalogoDAO;
	}

	public void setDataCatalogoDAO(DataCatalogoDAO dataCatalogoDAO) {
		this.dataCatalogoDAO = dataCatalogoDAO;
	}
	/* fin oneyraj rin10 */

	public ManifiestoService getManifiestoService() {
		return manifiestoService;
	}

	public ManifiestoSigadService getManifiestoSigadService() {
		return manifiestoSigadService;
	}
    
	public void setManifiestoService(ManifiestoService manifiestoService) {
		this.manifiestoService = manifiestoService;
	}

	public void setManifiestoSigadService(
			ManifiestoSigadService manifiestoSigadService) {
		this.manifiestoSigadService = manifiestoSigadService;
	}
	//FIN pase 2012-945

	public DetDeclaraDAO getDetDeclaraDAO() {
		return detDeclaraDAO;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public SoporteService getSoporteService() {
		return soporteService;
	}

	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}
	/*fduartej fin 15.08.2011 branch-ingreso-sharedlib*/
	

  //private TabImpDUDAO tabImpDUDAO;
	private RectificacionServiceImpl() {
	}
	
	public static RectificacionServiceImpl getInstance() {
		if (instance == null) {
			instance = new RectificacionServiceImpl();

		}
		
		return instance;
	}  
  
public RectiOficioDAO getRectioficioDAO() {
	return rectioficioDAO;
}

public void setRectioficioDAO(RectiOficioDAO rectioficioDAO) {
	this.rectioficioDAO = rectioficioDAO;
}

public CabDiligenciaDAO getCabdiligenciaDAO() {
	return cabdiligenciaDAO;
}

public void setCabdiligenciaDAO(CabDiligenciaDAO cabdiligenciaDAO) {
	this.cabdiligenciaDAO = cabdiligenciaDAO;
}

public static void setInstance(RectificacionServiceImpl instance) {
	RectificacionServiceImpl.instance = instance;
}

public CabManifiestoDAO getManifiestoDAO() {
	return manifiestoDAO;
}

public void setManifiestoDAO(CabManifiestoDAO manifiestoDAO) {
	this.manifiestoDAO = manifiestoDAO;
}
// INICIO RIN 10
@Override
public Map<String, Object> findByNumRucExiste(String numeroDocumentoIdentidad) {

	return padUsuGaraDAO.findByNumRucExiste(numeroDocumentoIdentidad);
}

@Override
public void insertPadUsuGara(Map<String, Object> params) {
	padUsuGaraDAO.insertPadUsuGara(params);

}
// FIN RIN 10

//public CantmaxlibeDAO getCantMaxLibeDAO() {
//	return cantMaxLibeDAO;
//}
//
//public void setCantMaxLibeDAO(CantmaxlibeDAO cantMaxLibeDAO) {
//	this.cantMaxLibeDAO = cantMaxLibeDAO;
//}

public DatadoDAO getDatadoDAO() {
	return datadoDAO;
}

public void setDatadoDAO(DatadoDAO datadoDAO) {
	this.datadoDAO = datadoDAO;
}

/*public DatadoService getDatadoservice() {
	return datadoservice;
}

public void setDatadoservice(DatadoService datadoservice) {
	this.datadoservice = datadoservice;
}*/

//public DdpDAO getDdpDAO() {
//	return ddpDAO;
//}

//public void setDdpDAO(DdpDAO ddpDAO) {
//	this.ddpDAO = ddpDAO;
//}

public LiquidaDAO getLiquidaDAO() {
	return liquidaDAO;
}

public void setLiquidaDAO(LiquidaDAO liquidaDAO) {
	this.liquidaDAO = liquidaDAO;
}

public DetaliqDAO getDetaliqDAO() {
	return detaliqDAO;
}

public void setDetaliqDAO(DetaliqDAO detaliqDAO) {
	this.detaliqDAO = detaliqDAO;
}

public SequenceDAO getSequenceDAO() {
	return sequenceDAO;
}

public void setSequenceDAO(SequenceDAO sequenceDAO) {
	this.sequenceDAO = sequenceDAO;
}

public DocumentoDAO getDocumentoDAO() {
	return documentoDAO;
}

public void setDocumentoDAO(DocumentoDAO documentoDAO) {
	this.documentoDAO = documentoDAO;
}

public SolicitudDAO getSolicitudDAO() {
	return solicitudDAO;
}

public void setSolicitudDAO(SolicitudDAO solicitudDAO) {
	this.solicitudDAO = solicitudDAO;
}

public RelacionDocDAO getRelaciondocDAO() {
	return relaciondocDAO;
}

public void setRelaciondocDAO(RelacionDocDAO relaciondocDAO) {
	this.relaciondocDAO = relaciondocDAO;
}

public CabSolrectiDAO getSolirectificaDAO() {
	return solirectificaDAO;
}

public void setSolirectificaDAO(CabSolrectiDAO solirectificaDAO) {
	this.solirectificaDAO = solirectificaDAO;
}

public DetSolRectiDAO getDetsolrectiDAO() {
	return detsolrectiDAO;
}

public void setDetsolrectiDAO(DetSolRectiDAO detsolrectiDAO) {
	this.detsolrectiDAO = detsolrectiDAO;
}

public CabDeclaraDAO getCabdeclaraDAO() {
	return cabdeclaraDAO;
}

public void setCabdeclaraDAO(CabDeclaraDAO cabdeclaraDAO) {
	this.cabdeclaraDAO = cabdeclaraDAO;
}

public IndicadorDUADAO getIndicadorDUADAO() {
	return indicadorDUADAO;
}

public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
	this.indicadorDUADAO = indicadorDUADAO;
}

public DeudaDocumDAO getDeudaDocumDAO() {
	return deudaDocumDAO;
}

public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
	this.deudaDocumDAO = deudaDocumDAO;
}

public ValidacionGeneralService getValidaciongeneralservice() {
	return validaciongeneralservice;
}

	public void setValidaciongeneralservice(ValidacionGeneralService validaciongeneralservice) {
	this.validaciongeneralservice = validaciongeneralservice;
}

public CatalogoHelperImpl getCatalogoHelper() {
	return catalogoHelper;
}

public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
	this.catalogoHelper = catalogoHelper;
}

public GeneraLiquidacionService getCalculoAdeudoService() {
	return generaLiquidacionService;
}

public void setCalculoAdeudoService(GeneraLiquidacionService generaLiquidacionService) {
	this.generaLiquidacionService = generaLiquidacionService;
}

public GetDeclaracionService getDeclaracionService() {
	return declaracionService;
}

public void setDeclaracionService(GetDeclaracionService declaracionService) {
	this.declaracionService = declaracionService;
}

public ProveedorFuncionesService getFuncionesService() {
	return funcionesService;
}

public void setFuncionesService(ProveedorFuncionesService funcionesService) {
	this.funcionesService = funcionesService;
}

public LiquidaDeclaracionService getLiquidaDeclaracionService() {
	return liquidaDeclaracionService;
}

	public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
	this.liquidaDeclaracionService = liquidaDeclaracionService;
}

public CatalogoAyudaService getCatalogoayudaservice() {
	return catalogoayudaservice;
}

public void setCatalogoayudaservice(CatalogoAyudaService catalogoayudaservice) {
	this.catalogoayudaservice = catalogoayudaservice;
}

public ValCabdua getValcabdua() {
	return valcabdua;
}

public void setValcabdua(ValCabdua valcabdua) {
	this.valcabdua = valcabdua;
}
/*
public TabImpDUDAO getTabImpDUDAO() {
	return tabImpDUDAO;
}*/
/*
public void setTabImpDUDAO(TabImpDUDAO tabImpDUDAO) {
	this.tabImpDUDAO = tabImpDUDAO;
}

*/

public ImputacionService getImputacionService() {
	return imputacionService;
}

public void setImputacionService(ImputacionService imputacionService) {
	this.imputacionService = imputacionService;
}

public GetValidacionesService getValidacionesService() {
	return validacionesService;
}

public void setValidacionesService(GetValidacionesService validacionesService) {
	this.validacionesService = validacionesService;
}

public Ratcc3DAO getRatcc3DAO() {
	return ratcc3DAO;
}

public void setRatcc3DAO(Ratcc3DAO ratcc3dao) {
	ratcc3DAO = ratcc3dao;
}

public RitCcDAO getRitccDAO() {
	return ritccDAO;
}

public void setRitccDAO(RitCcDAO ritccDAO) {
	this.ritccDAO = ritccDAO;
}

public DepoctaDAO getDepoctaDAO() {
	return depoctaDAO;
}

public void setDepoctaDAO(DepoctaDAO depoctaDAO) {
	this.depoctaDAO = depoctaDAO;
}

public MovNGarantiaDAO getMovNGarantiaDAO() {
	return movNGarantiaDAO;
}

public void setMovNGarantiaDAO(MovNGarantiaDAO movNGarantiaDAO) {
	this.movNGarantiaDAO = movNGarantiaDAO;
}

	public CabNacioTempoDAO getCabNacioTempoDAO() {
		return cabNacioTempoDAO;
	}

	public void setCabNacioTempoDAO(CabNacioTempoDAO cabNacioTempoDAO) {
		this.cabNacioTempoDAO = cabNacioTempoDAO;
	}
	public DetPagoDuaDAO getDetPagoDuaDAO() {
		return detPagoDuaDAO;
	}

	public void setDetPagoDuaDAO(DetPagoDuaDAO detpagoduaDAO) {
		this.detPagoDuaDAO = detpagoduaDAO;
	}
	


	/*branch ingreso-2011-009 hosorio inicio 08/04/2011*/
	public MovCabliqdiligDAO getMovCabliqdiligDAO() {
		return movCabliqdiligDAO;
	}

	public void setMovCabliqdiligDAO(MovCabliqdiligDAO movCabliqdiligDAO) {
		this.movCabliqdiligDAO = movCabliqdiligDAO;
	}

	public CabDeudaDAO getCabDeudaDAO() {
		return cabDeudaDAO;
	}

	public void setCabDeudaDAO(CabDeudaDAO cabDeudaDAO) {
		this.cabDeudaDAO = cabDeudaDAO;
	}

	public NotiDudaCabDAO getNotiDudaCabDAO() {
		return notiDudaCabDAO;
	}

	public void setNotiDudaCabDAO(NotiDudaCabDAO notiDudaCabDAO) {
		this.notiDudaCabDAO = notiDudaCabDAO;
	}

	
	public MovDuasActasDAO getMovDuasActasDAO() {
		return movDuasActasDAO;
	}

	public void setMovDuasActasDAO(MovDuasActasDAO movDuasActasDAO) {
		this.movDuasActasDAO = movDuasActasDAO;
	}

	public MovManifiestosActasDAO getMovManifActasDAO() {
		return movManifActasDAO;
	}

	public void setMovManifActasDAO(MovManifiestosActasDAO movManifActasDAO) {
		this.movManifActasDAO = movManifActasDAO;
	}

	public DipolizaiDAO getDiPolizaDAO() {
		return diPolizaDAO;
	}

	public void setDiPolizaDAO(DipolizaiDAO diPolizaDAO) {
		this.diPolizaDAO = diPolizaDAO;
	}

	/*branch ingreso-2011-009 hosorio fin 08/04/2011*/
}
