package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.envioparcial;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;

public interface ValEnvioParcialEERService {
	public List<Map<String, ?>> valIndicadorEnvioParcial(DUA dua);
}
