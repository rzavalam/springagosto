package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValRegPrecDepositoService {

	/**
	 * Validacion de la cta cte del deposito
	 * @param declaracion
	 * @param variablesIngreso
	 * @return
	 */
	public List<Map<String,String>> validarCtaCteDeposito(Declaracion declaracion, Map<String, Object> variablesIngreso);
	
	/**
	 * Validaciones generales a los datos generales del regimen de precedencia
	 * de Deposito
	 * @param declaracion
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valCabRegPreDeposito(Declaracion declaracion, Date fechaReferencia);
	/**
	 * Validar el regimen de precedencia 70 - Deposito Aduanero.
	 * @param regimenPrec
	 * @param numeroSerie
	 * @return
	 */
	public List<Map<String, String>> valDetRegPreDeposito(Declaracion declaracion, DatoSerie serie,
			DatoRegPrecedencia precedente, Date fechaReferencia,
			String codTransaccion, String codCanal,Map<String,Object> listDuaCache, Map<String,Object> listSeriesCache);
	
	/* INICIO - PAS20165E220300041 - RF02 - JHINOSTROZAN */
	/**
	 * Validar la equivalencia de los c�digos de dep�sito aduaneros de los
	 * regimenes precedentes y de la dam a numerar
	 * 
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> validarCodDepoPrecedentesIgualCodDepoDam(
			Declaracion declaracion);
	/* FIN - PAS20165E220300041 - RF02 - JHINOSTROZAN */
}
