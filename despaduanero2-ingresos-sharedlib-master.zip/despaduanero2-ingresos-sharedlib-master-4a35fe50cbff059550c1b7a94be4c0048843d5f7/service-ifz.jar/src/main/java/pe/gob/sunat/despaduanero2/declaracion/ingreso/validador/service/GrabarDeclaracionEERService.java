package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface GrabarDeclaracionEERService {
	public Map<String, String> grabarNumeracionEER(Declaracion declaracion, 
			  String numOrden, 
			  String codTransaccion, 
			  String tipoSender,
			  String numeroDocumentoIdentidadSender,
			  String tipoDocumentoIdentidadSender,
			  Integer annEnvio,
			  Long numEnvio) throws Exception;
}
