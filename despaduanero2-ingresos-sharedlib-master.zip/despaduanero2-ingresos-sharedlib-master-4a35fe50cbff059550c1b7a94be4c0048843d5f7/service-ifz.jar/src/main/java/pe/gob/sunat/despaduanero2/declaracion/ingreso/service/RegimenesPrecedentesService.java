package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;


public interface RegimenesPrecedentesService {

	public Map<String, ?> verificarDeclacionPrecente(Map declaracion);
	
	public String validaDeclacionPrecente(Map declaracion);
	
	public Map<String, ?> verificarSaldo(Map declaracion);

	/**
	 * En base al objeto DUA se obtienen los regimenes de precedencia de la declaracion y se obtiene su informacion de la base de datos
	 * Se retorna una lista de objetos que pueden ser declaraciones SDA o SIGAD
	 * @param dua
	 * @return
	 */
	public List<Object> obtenerDeclaracionPrecedenteDeposito(DUA dua);
	
	public  Date fecemisionPrecedencia(List<Object> listObject);
}
