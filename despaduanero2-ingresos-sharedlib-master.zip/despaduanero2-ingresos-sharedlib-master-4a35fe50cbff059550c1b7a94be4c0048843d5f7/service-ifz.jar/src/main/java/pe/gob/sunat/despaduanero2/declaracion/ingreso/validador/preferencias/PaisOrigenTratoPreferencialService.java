package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;

public interface PaisOrigenTratoPreferencialService {

	public Map<String, String> validarPaisOrigenPreferencia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);	
	
	public Boolean existsOrilibe(String tipoliber, String codConvenio, String codPais);
}
