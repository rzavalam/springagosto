/*
 * Clase que define el servicio de validaciones de Documentos de soporte
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValDocSop. Clase que define el servicio de validaciones de Documentos de soporte.
 */
public interface ValDocSop {
	
	public Map<String, String> numsecdocum(Elementos<DatoOtroDocSoporte> listDocSoporte);
	
	public Map<String, String> codtipoproceso(String codtipoproceso);
	
	public Map<String, String> codtipodocasoc(String codtipodocasoc);
	
	public Map<String, String> anndocasoc(String anndocasoc);
	
	public Map<String, String> numdocasoc(String numdocasoc);
	// P46 INSI
	public Map<String, String> fecdocasoc(Date fecdocasoc, Date fechaReferencia, String codtipoproceso);
	
	public Map<String, String> fecvencimiento(Date fecvencimiento, Date fechaReferencia, String codtipoproceso);
	
	public Map<String, String> codtipoentidad(String codtipoentidad);
	
	public Map<String, String> codtipodocentidad(String codtipodocentidad);
	
	public Map<String, String> codentidademisora(Long codentidademisora);
	
	public Map<String, String> desentidad(String desentidad, String codtipoproceso);
	
	Map<String, String> desentidad(String desentidad,String codtipodocum, String codtipoproceso);
	
	public Map<String, String> codentidad(String codentidad);
	
	public Map<String, String> indcustodia(String indcustodia);
	
	public Map<String,String> codtipodocum(String codtipodocum);
	
	public Map<String,String> numdocum(String numdocum);
	
	public Map<String,String> fecemision(Date fecemision);
	
        public	Map<String, String> valCantFacturas(Declaracion declaracion);

	public List<Map<String, String>> correlacionResolIMSerie(Declaracion declaracion);//gmontoya Pase 153
}

