/*
 * Clase que define el servicio de validaciones de la relacion de precintos
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValPrecinto. Clase que define el servicio de validaciones de la relacion de precintos.
 */
public interface ValPrecinto {
	
	public Map<String, String> numprecinto(String numprecinto);
	
	public List<Map<String, String>> validarUnicidadPrecinto(Declaracion declaracion);//gmontoya Pase 451 - 2015
	
}
