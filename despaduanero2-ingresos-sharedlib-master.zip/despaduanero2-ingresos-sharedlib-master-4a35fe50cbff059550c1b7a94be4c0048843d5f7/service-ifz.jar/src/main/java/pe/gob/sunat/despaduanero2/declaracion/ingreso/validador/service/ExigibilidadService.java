/*
 * Clase que define el servicio de validaciones de Exigibilidad
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
// RIN16
import pe.gob.sunat.despaduanero2.model.Participante;

public interface ExigibilidadService {
	
	/**
	 * Actualizar ultimo dia pago dua.
	 * 
	 * @param manifiesto Manifiesto
	 * @param fechaDescarga Date
	 */
	void actualizarUltimoDiaPagoDUA(Manifiesto manifiesto, Date fechaDescarga );
	
	/**
	 * Actualizar ultimo dia pago dua.
	 * 
	 * @param declaracion Declaracion
	 */
	void actualizarUltimoDiaPagoDUA(DUA dua);
        // RIN16
	void actualizarFecRegularizacionDUA(DUA dua);

	void actualizarFecRegularizacion(Manifiesto manifiesto, Date fechaDescarga);
	
	Participante findRucParticipante(Long numCorreDoc, String codTipoParticipante);//RIN16_Pase400
	
}
