package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface TipoDeclaraCertiOrigenService {
	
	/**
	 * validacion de tipo de certificado de origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public  Map<String, String> valTipoCertificadoOrigenGrupo(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);

	/**
	 * Para tipo de certificado de origen igual a 1,2 o 3 debe enviar Numero de Certificado y Fecha del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioNumFechaParaTipoEmbarquesTextiles (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 o 2 debe enviar Numero de Certificado y Fecha del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioNumFechaParaTipoEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado pero no S/N y Fecha del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioNumSinSNFechaParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado y Fecha del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioNumFechaParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado, Fecha del CO y Registro de Funcionario que emite el CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioNumFechaFuncionarioParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 debe enviar Numero de Certificado y Fecha del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public  List<Map<String, String>> valEnvioNumFechaParaTipoDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	

	/**
	 * Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen sin regimen de precedencia
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaUnEmbarqueSinPrecedencia (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1,2 o 3 se valida los plazos para el acogimiento del Certificado de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaEmbarquesTextiles (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 o 2, se valida los plazos para el acogimiento del Certificado de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 se valida los plazos para el acogimiento del Certificado de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 o 5 se valida los plazos para el acogimiento del Certificado de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 se valida el criterio de origen asociado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valCriterioOrigenParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 y 2 se valida el criterio de origen asociado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valCriterioOrigenParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 se valida el criterio de origen asociado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valCriterioOrigenParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 y 5 se valida el criterio de origen asociado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valCriterioOrigenParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 2 valida que la fecha de embarque est� comprendido entre la fecha de inicio de embarque y fin de embarque del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valFechaEmbarqueParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5, valida que la  Fecha de Emisi�n de la Declaraci�n sea menor o igual a la fecha de embarque
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valFechaEmbarqueParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 2 valida que las fecha de periodos de embarques con respecto a la fecha de emision del CO
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valPeriodoEmbarquesParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 2 valida que la diferencia entre las fechas de periodos de embarques esten dentro del plazo
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valDiferenciaPeriodoEmbarquesParaMultipleEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 valida que se consigne el nombre del productor
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valNombreProductorParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1,2 o 6 valida que se consigne el nombre del productor
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valNombreProductorParaEmbarquesConocimiento (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 y 2 valida que se consigne el nombre del productor
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valNombreProductorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 es necesario que se haya transmitido el N�mero de registro del funcionario autorizado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valRegistroFuncionarioParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1, el N�mero de registro del funcionario autorizado debe existir en modulo de registro de firmas
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valExisteRegistroFuncionarioParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 y 2 se valida que se envie correctamente el Tipo de emisor del certificado de origen asociado al TLC respectivo
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valTipoEmisorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 se valida que se envie correctamente el Tipo de emisor del certificado de origen asociado al TLC respectivo
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valTipoEmisorParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 1 y 2 valida que se consigne el nombre del emisor del certificado
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valNombreEmisorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 5 valida que se consigne el nombre del emisor de la Declaracion de Origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valNombreEmisorParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Para tipo de certificado de origen igual a 6, se verifica que no se envie los datos del certificado de origen
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> valEnvioCertificadoParaConocimientoImportador(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);	
	/**
	 * Valida que se evie el nombre del emisor del Certificado de origen
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	public Map<String, String> valNombreEmisor(DatoSerie serie, String[] arrayTipoCertificado, String codError);
	
	public  Map<String, String> valTipoCertificadoOrigenGrupoSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public List<Map<String, String>> valEnvioNumSinSNFechaParaTipoUnEmbarqueSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) ;
	
	public List<Map<String, String>> valEnvioNumFechaFuncionarioParaTipoUnEmbSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) ;
	
	public Map<String, String> valPlazoParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> valCriterioOrigenParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public List<Map<String, String>> valRegistroFuncionarioParaUnEmbarqueSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> valExisteRegistroFuncionarioParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	

	/**Pase548 II 
	 * Permite realizar la validacion del plazo de la rectificacion del TPI acorde a si es primera vez o no
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @param declaracionBD
	 * @return
	 */
	public Map<String, String> validarPlazoRectificacionTPI(DatoSerie serie, Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracionBD );
	
	
	/**Pase548 II
	 * Permite validar que el TPI no sea posterior a la fecha de pago de tributos
	 * @param serie
	 * @param variablesIngreso
	 * @param declaracionBD
	 * @return
	 * Bugs  17783 y 17889 arey (habilitar para TPI 229 - TPI 100)
	 */ 
	public Map<String, String> validarTPIPosteriorPagoTributos(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) throws Exception;
		
	/**Pase548 II
	 * Permite validar que el TPI no sea posterior a la fecha de levante
	 * @param serie
	 * @param variablesIngreso
	 * @param declaracionBD
	 * @return
	 * @throws Exception 
	 * Bug  17745 arey (habilitar para TPI 808)
	 */ 
	public Map<String, String> validarTPIPosteriorLevante(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) throws Exception;
	
	/**Pase548 II
	 * Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */	
	public Map<String, String> valPlazoParaUnEmbarqueRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) ;
	
	/**Pase548 II
	 * Para tipo de certificado de origen igual a 1,2 o 3 se valida los plazos para el acogimiento del Certificado de Origen en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaEmbarquesTextilesRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);
		
	/**Pase548 II
	 * Para tipo de certificado de origen igual a 1 o 2, se valida los plazos para el acogimiento del Certificado de Origen en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaEmbarquesRecti(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);
		
	/**Pase548 II
	 * Para tipo de certificado de origen igual a 5 se valida los plazos para el acogimiento del Certificado de Origen en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaDeclaracionRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);

	/**Pase548 II
	 * Para tipo de certificado de origen igual a 1 o 5 se valida los plazos para el acogimiento del Certificado de Origen en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaUnEmbarqueDeclaracionRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);

	/**Pase548 II
	 * Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen sin regimen de precedencia en los casos de Recti
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @return
	 */
	public Map<String, String> valPlazoParaUnEmbarqueSinPrecedenciaRecti(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);
	
	/**
	 * Se valida el criterio de origen para el tipo de certificado de origen igual a 2. Este servicio esta basado en el 3358.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	public Map<String, String> valCriterioOrigenParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Se valida que la fecha de inicio y fin de periodo de embarque sean validos, solo se aplica cuando el tipo de certificado es igual a 2. Este servicio esta basado en el 3358.
	 * Proyecto msnade236_1
	 * @author glazaror
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	public List<Map<String, String>> validarFechasPeriodoEmbarquesParaMultipleEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Se validan las fechas de periodos de embarques con respecto a la fecha de emision del CO, se aplica solo al tipo de certificado 2
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	public List<Map<String, String>> valPeriodoEmbarques(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Se valida la vigencia del tipo de certificado de origen. Se aplica solo a los tipos de certificado 1, 2 y 5.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	public List<Map<String, String>> valVigenciaTipoCertificado(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) throws Exception;
	
	/**
	 * Se validan los plazos para el acogimiento del certificado de origen. Se aplica solo al tipo de certificado 2.
	 * Basado en el servicio 3348.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	public Map<String, String> valPlazoParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia);
	
	/**
	 * Se validan los plazos para el acogimiento del certificado de origen. Se aplica solo a los tipos de certificado 1 y 5.
	 * Basado en el servicio 3448.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @param declaracionBD declaracion de base datos
	 * @return errores de validacion
	 */
	public Map<String, String> validarPlazoParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD);
}
