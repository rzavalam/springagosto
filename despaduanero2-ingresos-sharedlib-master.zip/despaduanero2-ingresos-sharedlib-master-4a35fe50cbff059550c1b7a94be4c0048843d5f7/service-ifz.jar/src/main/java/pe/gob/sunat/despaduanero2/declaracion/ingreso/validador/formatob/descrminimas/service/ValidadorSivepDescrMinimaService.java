package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

/**
 * La Interface ValidadorSivepDescrMinimaService.
 */
public interface ValidadorSivepDescrMinimaService {

}
