package pe.gob.sunat.despaduanero2.declaracion.ingreso.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	public static Integer getStringtoNumberEight (String str) {
        String converStr = null;
        String strtrim = str.trim();
        converStr = strtrim.substring(6,10).concat(strtrim.substring(3,5)).concat(strtrim.substring(0,2));
        Integer convInteger = Integer.valueOf(converStr);
        return convInteger;
		}
	
	
	public static Date stringToDate(String dateAsString) throws ParseException{
		String format="dd/MM/yyyy";
		return stringToDate(dateAsString, format);
	}
	
	public static Date getNumbertoDateyyyMMdd(Integer numbertoString) throws ParseException{
		String format="yyyyMMdd";
		String converStr=null;
		String valor=null;
		
		valor = String.valueOf(numbertoString).trim();
		if (valor== null || valor.length() !=8){
			converStr="00010101";
		}else{
			converStr=valor;
		}
		
		return stringToDate(converStr, format);
	}
	
	
	
	public static Date stringToDate(String dateAsString, String format) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date date = sdf.parse(dateAsString);
		return date;
	}
	
	
	public static Date dateToDateDDMMYYYYHHmmss(Date fecha) {
		       String temp = dateToStringDDMMYYYYHHmmss(fecha);
		       return stringDDMMYYYYHHmmssToDate(temp);
		            }
    public static String dateToStringDDMMYYYYHHmmss(Date fecha) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return formato.format(fecha);
      }
    
    public static Date stringDDMMYYYYHHmmssToDate(String fecha) {
        Date resultado = null;
        if (fecha != null || !fecha.equals("") ) {
            try {
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                resultado = formato.parse(fecha);
            }
            catch (Exception exception) { }
        }
        return resultado;
    }
}
