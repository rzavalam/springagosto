package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public interface ValObsFB {
	public Map<String, String> numsecuencia(Declaracion declaracion);
	public List<Map<String, String>>  codtipobserva(Elementos<Observacion> listObservaciones) ;
	public Map<String, String> obsdeclaracion(Elementos<Observacion> listObservaciones) ;
	public List<Map<String, String>>  numsecuencia(Declaracion declaracion, String codTransaccion);
	
}
