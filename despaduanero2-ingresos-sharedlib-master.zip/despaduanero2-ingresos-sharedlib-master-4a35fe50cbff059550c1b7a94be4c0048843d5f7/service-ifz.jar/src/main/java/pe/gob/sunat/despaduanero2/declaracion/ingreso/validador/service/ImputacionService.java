package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ImputacionService {
	
	public Map<String,Object> Spgenimputacion(Declaracion declaracion,Map<String,Object> deudaCalculada) throws Exception;
	
	public List<Map<String,String>> verificarSaldo(Map<String,BigDecimal> matrizTribxPagar);
	
	public BigDecimal sumarSaldoImpuestos(Map<String,BigDecimal> matrizxpagar );
	
	public BigDecimal sumarTotalImputadoxTributo(Map<Long,Map<String,BigDecimal>> detalleImputacion, String nomTributo );
}
