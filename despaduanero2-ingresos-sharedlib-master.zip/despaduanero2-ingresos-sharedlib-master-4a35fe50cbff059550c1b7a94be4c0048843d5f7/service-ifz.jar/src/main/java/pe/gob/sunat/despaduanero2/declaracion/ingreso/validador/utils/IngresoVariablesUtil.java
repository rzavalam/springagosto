package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.model.Nandina;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class IngresoVariablesUtil {
	
	public static boolean isElementoCatalogoValido(FabricaDeServicios fabricaDeServicios, String codigoCatalogo, String codigoElementoCatalogo, Map<String, Object> variablesIngreso) {
		if (variablesIngreso != null) {
			//la logica del metodo validarElementoCat... retorna vacio si es que el elemento a validar es vacio... aplicamos la misma logica
			if((codigoCatalogo == null) || (codigoElementoCatalogo == null) || (codigoElementoCatalogo.trim().equals(""))) {
				return true;
			}
			//si es que se reciben parametros correctos entonces validamos
			String identificadorCatalogo = "catalogo-" + codigoCatalogo;
			Map<String, String> elementosCatalogoAsMap = (Map<String, String>) variablesIngreso.get(identificadorCatalogo);
			if (elementosCatalogoAsMap == null) {
				elementosCatalogoAsMap = new HashMap<String, String>();
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				List<Map<String, String>> elementosCatalogo = catalogoAyudaService.getElementosCat(codigoCatalogo);
				for (Map<String, String> elementoCatalogo : elementosCatalogo) {
					elementosCatalogoAsMap.put(elementoCatalogo.get("cod_datacat"), elementoCatalogo.get("cod_datacat"));
				}
				variablesIngreso.put(identificadorCatalogo, elementosCatalogoAsMap);
			}
			return elementosCatalogoAsMap.containsKey(codigoElementoCatalogo);
		} else {
			//logica antigua
			return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(codigoCatalogo, codigoElementoCatalogo));
		}
	}
	
	public static boolean isElementoGrupoValido(FabricaDeServicios fabricaDeServicios, String codigoGrupo, String codigoElemento, Map<String, Object> variablesIngreso) {
		if (variablesIngreso != null) {
			String identificador = "grupo-" + codigoGrupo;
			Map<String, String> elementosGrupoAsMap = (Map<String, String>) variablesIngreso.get(identificador);
			if (elementosGrupoAsMap == null) {
				elementosGrupoAsMap = new HashMap<String, String>();
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				List<Map<String, String>> elementosGrupo = catalogoAyudaService.getListaElementosGrupo(codigoGrupo);
				for (Map<String, String> elementoCatalogo : elementosGrupo) {
					elementosGrupoAsMap.put(elementoCatalogo.get("cod_datacat"), elementoCatalogo.get("cod_datacat"));
				}
				variablesIngreso.put(identificador, elementosGrupoAsMap);
			}
			return elementosGrupoAsMap.containsKey(codigoElemento);
		} else {
			//logica antigua
			return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(codigoGrupo, codigoElemento));
		}
	}
	
	public static Map getElementoCat(FabricaDeServicios fabricaDeServicios, String catalogoEstructuraDescrminima, String codtipdescr, Map<String, Object> variablesIngreso) {
		// TODO Auto-generated method stub
		Map map = new HashMap();
		if(variablesIngreso != null){
			String identificador = "descripcionesMinimas-" + catalogoEstructuraDescrminima +"-" + codtipdescr;
			map = (Map)variablesIngreso.get(identificador);
			if(map == null){
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				map = catalogoAyudaService.getElementoCat(catalogoEstructuraDescrminima, codtipdescr);
				variablesIngreso.put(identificador, map);
			}
		}
		return map;
	}

	public static List<Map<String, String>> getListaElementosAsoc(FabricaDeServicios fabricaDeServicios,String catalogoAsociacion, 
			String tipo, String partida, Date fecha,Map<String, Object> variablesIngreso) {
		// TODO Auto-generated method stub
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		if(variablesIngreso != null){
			String identificador = "descripcionesMinimas-".concat(catalogoAsociacion).concat("-").concat(tipo).concat("-").concat(partida);
			list = (List<Map<String, String>>)variablesIngreso.get(identificador);
			if(list == null){
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				list = catalogoAyudaService.getListaElementosAsoc(catalogoAsociacion, tipo,partida,fecha);
				variablesIngreso.put(identificador, list);
			}
		}
		return list;
	}
	
	public static boolean validarElementoCatalogo(FabricaDeServicios fabricaDeServicios, String codTipo, String codElemento, Map<String, Object> variablesIngreso){
		Boolean isValid = false;
		if(variablesIngreso != null){
			String identificador = "validarCatalogo-".concat(codElemento).concat("-").concat(codTipo);
			isValid = (Boolean)variablesIngreso.get(identificador);
			if(isValid == null){
				CatalogoValidaService catalogoValidaService = (CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService");
				List result = catalogoValidaService.validarElementoCat(codElemento, codTipo, SunatDateUtils.getCurrentDate());
				isValid = (Boolean)CollectionUtils.isEmpty(result);
				variablesIngreso.put(identificador, isValid);
			}
		}
		return isValid.booleanValue();
	}
	
/*
 * Para la atencion REQ 2016-117779 PAS20171U220200016
 * Se reemplaza los caracteres raros en el valor de minimas a ser
 * cotejado en bd por el rest :
 * wssunat:8080/ol-ad-catalogorest/catalogoayuda/{codTipoCat}/{codElemento}/{fecha}/getDataCatalogo1 
 */
	  public static String convertirParaRest(Object valor){
		  String valorConvertido = "";
		  
		  	if (valor == null) {
				return valorConvertido = "rest[valor]";
			}
			if ("".equals(valor.toString())) {
				return valorConvertido =  "rest[vacio]";
			}
			
			valorConvertido = valor.toString();
			if (StringUtils.isBlank( valor.toString())) {
				return valorConvertido = "rest[blanco]";
			}
			
			if ((valor instanceof String) ){
				if(valorConvertido.contains("/")) {
					valorConvertido = valorConvertido.replace("/", "rest[slash]");
				}
				if(valorConvertido.contains(":")) {
					valorConvertido = valorConvertido.replace(":", "rest[dospuntos]");
				}
				if(valorConvertido.contains(".")) {
					valorConvertido = valorConvertido.replace(".", "rest[punto]");
				}
				if(valorConvertido.contains("%")) {
					valorConvertido = valorConvertido.replace("%", "rest[porcentaje]");
				}
				if(valorConvertido.contains("\\")) {
					valorConvertido = valorConvertido.replace("\\", "rest[backslash]");
				}
				if(valorConvertido.contains("?")) {
					valorConvertido = valorConvertido.replace("?", "rest[interrogacion]");
				}
				if(valorConvertido.contains("~")) {
					valorConvertido = valorConvertido.replace("~", "rest[guino]");
				}
				
			}
			
		return valorConvertido;
		  
	  }
	  
	
	//rtineo mejoras, valida que un elemento esta en catalogo
//adicionado por pase PAS20165E220200137-DESCRMIN
		public static DataCatalogo obtenerCatalogo(FabricaDeServicios fabricaDeServicios, String codigoCatalogo, String codigoABuscar, Map<String, Object> variablesIngreso,Date fechaVigencia){
			DataCatalogo dataCatalogo=null;
			if(variablesIngreso != null){
				String identificador = "obtenerCatalogo-".concat(codigoCatalogo).concat("-").concat(codigoABuscar);
				if(variablesIngreso.containsKey(identificador)){
					dataCatalogo = (DataCatalogo)variablesIngreso.get(identificador);
				}else{
					codigoABuscar = convertirParaRest(codigoABuscar);////atencion REQ 2016-117779 PAS20171U220200016
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar, fechaVigencia);
					variablesIngreso.put(identificador, dataCatalogo);
				}
			}else{
				//continua con el metodo anterior
				codigoABuscar = convertirParaRest(codigoABuscar);////atencion REQ 2016-117779  PAS20171U220200016
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar, fechaVigencia);
			}
			return dataCatalogo;
		}
	//rtineo mejoras, valida que un elemento esta en catalogo
	public static DataCatalogo obtenerCatalogo(FabricaDeServicios fabricaDeServicios, String codigoCatalogo, String codigoABuscar, Map<String, Object> variablesIngreso){
		DataCatalogo dataCatalogo=null;
		if(variablesIngreso != null){
			String identificador = "obtenerCatalogo-".concat(codigoCatalogo).concat("-").concat(codigoABuscar);
			if(variablesIngreso.containsKey(identificador)){
				dataCatalogo = (DataCatalogo)variablesIngreso.get(identificador);
			}else{
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar);
				variablesIngreso.put(identificador, dataCatalogo);
			}
		}else{
			//continua con el metodo anterior
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar);
		}
		return dataCatalogo;
	}
	
	public static boolean estaEnDescripcionCatalogo(FabricaDeServicios fabricaDeServicios, String codigoCatalogo, String cadenaBuscar, Map<String, Object> variablesIngreso){
		
	return estaEnDescripcionCatalogo( fabricaDeServicios,  codigoCatalogo,  cadenaBuscar, variablesIngreso, new Date());
	}
	
	//rtineo mejoras, valida que un elemento esta en catalogo
	public static boolean estaEnDescripcionCatalogo(FabricaDeServicios fabricaDeServicios, String codigoCatalogo, String cadenaBuscar, Map<String, Object> variablesIngreso, Date fechaVigencia){
		Boolean retorno = false;
		if(variablesIngreso != null){
			String identificadorCadena = "estaDescripcionCatalogoCache-".concat(codigoCatalogo).concat("-").concat(cadenaBuscar);
			if(variablesIngreso.containsKey(identificadorCadena)){
				return (Boolean)variablesIngreso.get(identificadorCadena);
			}else{
				String identificador = "mapCatalogoCache".concat(codigoCatalogo);
				Map<String, String> elementosCatalogoAsMap;
				if (variablesIngreso.containsKey(identificador)) {
					elementosCatalogoAsMap = (Map<String, String>) variablesIngreso.get(identificador);
				}else{
					elementosCatalogoAsMap = new HashMap<String, String>();
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					//List<Map<String, String>> elementosCatalogo = catalogoAyudaService.getElementosDesDatacat(codigoCatalogo);
					List<Map<String, String>> elementosCatalogo = catalogoAyudaService.getElementosCat(codigoCatalogo,null,  null, fechaVigencia, null);
 
					for (Map<String, String> elementoCatalogo : elementosCatalogo) {
						//elementosCatalogoAsMap.put(elementoCatalogo.get("cod_datacat"), elementoCatalogo.get("des_datacat"));
						elementosCatalogoAsMap.put(elementoCatalogo.get("cod_datacat"), elementoCatalogo.get("des_corta"));
					}
					variablesIngreso.put(identificador, elementosCatalogoAsMap);					
				}
				for(String value : elementosCatalogoAsMap.values()){
					if(value.trim().toUpperCase().equals(cadenaBuscar.trim().toUpperCase())){
						retorno = true;
						break;
					}
				}
				variablesIngreso.put(identificadorCadena, retorno);
			}
		}
		return retorno;
	}
	
	//rtineo mejoras, valida que un elemento esta en en subgrupo
	public static DataGrupoCat estaEnSubGrupoCatalogo(FabricaDeServicios fabricaDeServicios, String codigoGrupo, String codigoABuscar, Map<String, Object> variablesIngreso){
			DataGrupoCat grupo = null;
			if(variablesIngreso != null){
				String identificadorCadena = "estaEnSubGrupoCatalogoCache-".concat(codigoGrupo).concat("-").concat(codigoABuscar);
				if(variablesIngreso.containsKey(identificadorCadena)){
					grupo =  (DataGrupoCat)variablesIngreso.get(identificadorCadena);
				}else{
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					grupo = catalogoAyudaService.getDataGrupoCat(codigoGrupo, codigoABuscar);
					variablesIngreso.put(identificadorCadena, grupo);
				}
			}else{
				//continua con el metodo anterior
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				grupo = catalogoAyudaService.getDataGrupoCat(codigoGrupo, codigoABuscar);
			}
			return grupo;
	}
	
	//rtineo mejoras
	public static Nandina getPartidaObject(FabricaDeServicios fabricaDeServicios, String numPartida, Map<String, Object> variablesIngreso){
		Nandina nandina = null;
		if(variablesIngreso != null){
			String identificadorCadena = "estaEnPartidaCache-".concat(numPartida);
			if(variablesIngreso.containsKey(identificadorCadena)){
				nandina =  (Nandina)variablesIngreso.get(identificadorCadena);
			}else{
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				nandina = catalogoAyudaService.getPartidaObject(numPartida);
				variablesIngreso.put(identificadorCadena, nandina);
			}
		}else{
			//continua con el metodo anterior
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			nandina = catalogoAyudaService.getPartidaObject(numPartida);
		}
		return nandina;
	}
	
	/**
     * Utilitario que se encarga de cargar en "variablesIngreso" los codigos asociados (DATACATASOC) de un determinado catalogo.
     * Proyecto: msnade236_1
     * @param fabricaDeServicios Fabrica de servicios
     * @param codigoAsociacion Codigo de asociacion a buscar
     * @param fechaReferencia Fecha de referencia en validaciones TLC
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return mapa cuyo key (codigos del catalogo consultado) tiene asociada una lista de codigos asociados. 
     **/
	public static Map<String, List<String>> obtenerCodigosAsociadosCatalogo(FabricaDeServicios fabricaDeServicios, String codigoAsociacion, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		String identificadorCatalogoAsociado = "codigosAsociados" + codigoAsociacion;
		
		Map<String, List<String>> codigosAsociadosCatalogo = (Map<String, List<String>>) variablesIngreso.get(identificadorCatalogoAsociado);
		
		if (codigosAsociadosCatalogo == null) {
			codigosAsociadosCatalogo = new HashMap<String, List<String>>();
			//si es que no existe cargamos la variable
			List<Map<String, String>> registrosAsociadosCatalogo =  ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaAsociado(codigoAsociacion, fechaReferencia);
			for (Map<String, String> registroAsociado : registrosAsociadosCatalogo) {
				String codigo = registroAsociado.get("cod_datacat");
				String codigoAsociado = registroAsociado.get("cod_datacatasoc");
				
				List<String> codigosAsociados = codigosAsociadosCatalogo.get(codigo);
				//si es que no existe una lista para el codigo entonces la inicializamos
				if (codigosAsociados == null) {
					codigosAsociados = new ArrayList<String>();
					codigosAsociadosCatalogo.put(codigo, codigosAsociados);
				}
				//adicionamos el codigo asociado en la lista
				codigosAsociados.add(codigoAsociado);
			}
			variablesIngreso.put(identificadorCatalogoAsociado, codigosAsociadosCatalogo);
		}
		return codigosAsociadosCatalogo;
	}
	
	/**
     * Utilitario que se encarga de obtener el valor del atributo asociados al atributo, grupo, catalogo y elemento especificados, 
     * si es que se especifica "variablesIngreso" entonces se carga ahi el resultado de la consulta de atributo, grupo y catalogo (recomendable).
     * Proyecto: msnade236_1
     * @param fabricaDeServicios Fabrica de servicios
     * @param codigoAtributo Codigo del atributo a buscar
     * @param codigoGrupo Codigo del grupo a buscar
     * @param codigoCatalogo Codigo del catalogo a buscar
     * @param codigoElemento Codigo del elemento a buscar
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return mapa cuyo key (codigos del catalogo consultado) tiene asociada una lista de codigos asociados. 
     **/
	public static String obtenerAtributoPorGrupoCatalogo(FabricaDeServicios fabricaDeServicios, String codigoAtributo, String codigoGrupo, String codigoCatalogo, String codigoElemento, Map<String, Object> variablesIngreso){
		if (variablesIngreso != null) {
			//verificamos si ya fue cargado anteriormente el grupo de montos tope de factura
			String identificadorGrupo = "grupoAtributo" + codigoAtributo;
			Map<String, String> grupoAtributos = (Map<String, String>) variablesIngreso.get(identificadorGrupo);
			if (grupoAtributos == null) {
				grupoAtributos = cargarGrupoAtributos(fabricaDeServicios, codigoAtributo, codigoGrupo, codigoCatalogo, variablesIngreso);
			}
			return grupoAtributos.get(codigoElemento);
		}else{
			Map<String, Object> ayudaAtributoGrupo = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataAtributo(
					codigoAtributo, codigoGrupo, codigoCatalogo, codigoElemento);
			String val_atributo = ayudaAtributoGrupo.get("val_atributo") == null ? null:ayudaAtributoGrupo.get("val_atributo").toString();
			return val_atributo;
		}
	}
	
	/**
     * Utilitario que se encarga de cargar en "variablesIngreso" los atributos asociados al atributo, grupo y catalogo especificados.
     * Proyecto: msnade236_1
     * @param fabricaDeServicios Fabrica de servicios
     * @param codigoAtributo Codigo del atributo a buscar
     * @param codigoGrupo Codigo del grupo a buscar
     * @param codigoCatalogo Codigo del catalogo a buscar
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return mapa cuyo key (codigos del catalogo consultado) tiene asociada una lista de codigos asociados. 
     **/
	public static Map<String, String> cargarGrupoAtributos(FabricaDeServicios fabricaDeServicios, String codigoAtributo, String codigoGrupo, String codigoCatalogo, Map<String, Object> variablesIngreso) {
		//entonces cargamos los atributos
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, Object>> dataAtributos = catalogoAyudaService.getDataAtributos(codigoAtributo, codigoGrupo, codigoCatalogo, null, null);
		Map<String, String> grupo = new HashMap<String, String>();
		for (Map<String, Object> dataAtributo : dataAtributos) {
			String valorAtributo = dataAtributo.get("val_atributo") == null ? null : dataAtributo.get("val_atributo").toString();
			grupo.put(dataAtributo.get("cod_datacat").toString(), valorAtributo);
		}
		variablesIngreso.put("grupoAtributo" + codigoAtributo, grupo);
		return grupo;
	}
	
}
