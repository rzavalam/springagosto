package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
public interface ValRegPrecZofratacnaService {

	/* R1911
		El sistema acepta que en la declaraci�n se transmita m�s de una Declaraci�n de Ingreso ZOFRATACNA o m�s de un 
		Certificado de Manufactura como documento precedente; no obstante en cada  serie solo se puede consignar una 
		Declaraci�n de Ingreso o un Certificado de Manufactura 
	 */
	public List<Map<String,String>> validarCantDocuPrecePorSerie(List<DatoSerie> listSeries, DUA dua);
	
	/* R1907
	 * En la numeraci�n de la declaraci�n, cuando el tipo de Punto de Llegada / Almac�n Aduanero corresponda a 
	 * ZOFRATACNA aplica la regla R1907 y se verifica lo siguiente:
		Que el RUC y el c�digo del local principal o anexo correspondan a ZOFRATACNA, caso contrario se rechaza 
		la transmisi�n y se env�a el mensaje de error: �RUC y/o Local principal o anexo no corresponden a ZOFRATACNA�
		Que la modalidad de despacho sea diferido, caso contrario se rechaza la transmisi�n y 
		se env�a el mensaje de error: �La modalidad de despacho para ZOFRATACNA solo es DIFERIDO�
		Que la aduana de numeraci�n corresponda a la Aduana de Tacna, caso contrario se env�a el mensaje de 
		error: �Para el punto de llegada/almac�n aduanero ZOFRATACNA solo corresponde Aduana de Tacna�. 
		Que como documento precedente se haya transmitido una Declaraci�n de Ingreso ZOFRATACNA o un Certificado de 
		Manufactura ZOFRATACNA y en todas las series se verifica que haya consignado solo uno de estos documentos 
		precedentes, caso contrario el sistema rechaza la transmisi�n y env�a los mensajes de error seg�n corresponda: 
		�Para el tipo punto de llegada/almac�n aduanero ZOFRATACNA se requiere transmitir como documento precedente 
		la Declaraci�n de Ingreso ZOFRATACNA o el Certificado de Manufactura ZOFRATACNA�, o
		�Solo puede transmitir un tipo de documento ZOFRATACNA precedente por declaraci�n�. 
	 */
	public List<Map<String,String>> validarEnPuntodeLLegada();
	
	/* R1909
	 *  El sistema verifica que cuando se haya registrado en cada serie como documento precedente la Declaraci�n
	 *  de Ingreso o el Certificado de Manufactura, el tipo de punto de llegada corresponda a �ZOFRATACNA�. 
	 *  Caso contrario, rechaza la transmisi�n y env�a el mensaje de error: �Si consigna como precedente un 
	 *  documento de ZOFRATACNA, el punto de llegada/almac�n aduanero debe ser �ZOFRATACNA�. 
	 */
	public List<Map<String,String>> validarPuntoLlegada();
	
	/* R1908
	 *  Para las declaraciones que tienen como Punto de Llegada / Almac�n Aduanero ZOFRATACNA, no se valida 
	 *  el manifiesto de carga.
	 */
	public List<Map<String,String>> validarManifiesto();
	
	public List<Map<String, String>> validarRegimenZofratacna(DatoSerie serie, DatoRegPrecedencia precedente);
	
}
