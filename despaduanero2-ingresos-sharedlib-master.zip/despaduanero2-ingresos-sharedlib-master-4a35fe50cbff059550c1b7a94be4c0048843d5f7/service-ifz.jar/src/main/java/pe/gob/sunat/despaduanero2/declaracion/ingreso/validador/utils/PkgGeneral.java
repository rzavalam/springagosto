package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils;

import java.math.BigDecimal;
import java.util.Date;

import pe.gob.sunat.despaduanero2.util.SunatStringUtils;



public class PkgGeneral {

	//fn_getjurisdicc
	public static String getJurisdicc(String codAduana){
		if (SunatStringUtils.include(codAduana, new String[]{"118", "235", "244" }))
			return "992";
		else if ("028".equals(codAduana))
			return "046";
		else if("136".equals(codAduana))
			return "127";
		else if("262".equals(codAduana))
			return "181";
		return codAduana; 
	}
	
	//fngetvigenciacambio
	public static Integer getVigenciaCambio(String pAduana, String pRegimen, String pModulo, String pCodCambio, Date pFecha){
		String pSecuencia="1";
		return null;
	}
	
	//fnesruc
	public static boolean esRuc(String pRuc){
		return true;
	}
	
	//fnGetFactor
	public static BigDecimal getFactor(String pUniOrigen, String pUniDestin, BigDecimal pCantidad){
		return null;
	}
	
}
