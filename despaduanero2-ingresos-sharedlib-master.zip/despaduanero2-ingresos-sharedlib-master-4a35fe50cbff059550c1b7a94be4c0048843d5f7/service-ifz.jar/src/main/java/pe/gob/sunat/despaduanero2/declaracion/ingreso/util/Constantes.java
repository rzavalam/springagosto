package pe.gob.sunat.despaduanero2.declaracion.ingreso.util;

public class Constantes {
	
	// PAS20191U220500021
	public static final String CATALOGO_VIGENCIA_NUEVA_VALIDACION_ANTIGUEDAD = "0056"; 
	public static final String CATALOGO_VIGENCIA_MODIF_DL_843 = "0057"; 
	public static final String CATALOGO_CONTROL_CAMBIO = "380";
	public static final String CATALOGO_SUBGR_MERC_USADA = "531";
	public static final String CATALOGO_SUBGR_MERC_NUEVA = "710";  
	public static final String CATALOGO_ANNO_SEGUN_VIN = "AMV";
	public static final String TABLA_DESCRIP_OTROS = "T9833"; // JCV


}
