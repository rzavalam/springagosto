package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/* Inicio RIN10 3007 erodriguezb */
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
/* Fin RIN10 3007 erodriguezb */
public class FormatoBUtils {

	public static DatoMonto getMontoDAV(DAV dav, String codigoMont){
		if(dav!=null && !CollectionUtils.isEmpty(dav.getListMontos())){
			for(DatoMonto monto: dav.getListMontos())
			{
				if( SunatStringUtils.isEqualTo(monto.getCodmonto(), codigoMont) )
					return monto;
			}
		}
		return new DatoMonto();
	}
	
	public static DatoDescrMinima getDescrMinima(List<DatoDescrMinima> listDescrMinima, String tipo){
		for(DatoDescrMinima descrMinima:listDescrMinima){
			if (descrMinima.getCodtipdescr().equals(tipo))
				return descrMinima;
		}
		return null;
	}
	
	public static List<DatoItem> getItemsSeries(List<DAV> listDavs, DatoSerie serie){
		List<DatoItem> listItems=new ArrayList<DatoItem>();
		for(DAV dav:listDavs){
			for(DatoFactura factura:dav.getListFacturas()){
				for(DatoItem item:factura.getListItems()){
					List<DatoSerieItem> listSerieItem=item.getListSerieItems();
					for(DatoSerieItem serieItem:listSerieItem){
						if (serieItem.getNumserie().intValue()==serie.getNumserie()){
							if (((DatoItem)serieItem.getPadre()) != null) {    
							if(!containsItem(listItems,((DatoItem)serieItem.getPadre()).getNumsecitem())){
								listItems.add(item);
								break;
							}
							} else {
								listItems.add(item);
								break;
							}
						}
					}
				}
			}
		}
		return listItems;
	}
	
    public static BigDecimal obtenerFOBTotalFormatoB(DAV dav){
        
        BigDecimal prec_factu = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();
        BigDecimal masdscto =   getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MASDSCTO).getMtologistico();
        BigDecimal monvtasuce = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MONVTASUCE).getMtologistico();
        BigDecimal vint_deven = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VINT_DEVEN).getMtologistico();
        BigDecimal votr_gasto = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VOTR_GASTO).getMtologistico();
        BigDecimal vgas_trimp = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_TRIMP).getMtologistico();
        BigDecimal vgas_segur = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_SEGUR).getMtologistico();
        BigDecimal vgas_carde = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_CARDE).getMtologistico();
        BigDecimal vtot_deduc = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VTOT_DEDUC).getMtologistico();
        BigDecimal vgas_tremb = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_TREMB).getMtologistico();
        BigDecimal vgas_eposi = getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_EPOSI).getMtologistico();
        
        String codincoterm = dav.getListFacturas().size() > 0 ? dav.getListFacturas().get(0).getCodincoterm() : "";

        BigDecimal tfob = BigDecimal.ZERO;

        if (SunatStringUtils.isEqualTo(codincoterm, "EXW")) {
            tfob = SunatNumberUtils.sum(prec_factu, vgas_tremb, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vint_deven, votr_gasto);
        }
        else if (SunatStringUtils.isStringInList(codincoterm, "FAS,FCA,FOB")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vint_deven, votr_gasto);
        }
        else if (SunatStringUtils.isStringInList(codincoterm, "CFR,CPT,DAF,DES")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vgas_trimp, vint_deven, votr_gasto);
        }
        else if (SunatStringUtils.isStringInList(codincoterm, "CIF,CIP")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vgas_trimp, vgas_segur, vint_deven, votr_gasto);
        }
        else if (SunatStringUtils.isEqualTo(codincoterm, "DEQ")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vgas_trimp, vgas_carde, vint_deven, votr_gasto);
        }
        else if (SunatStringUtils.isStringInList(codincoterm, "DDU,DDP")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vgas_trimp, vgas_carde, vtot_deduc);
        }
        else if (SunatStringUtils.isStringInList(codincoterm, "DAT,DAP")) {
            tfob = SunatNumberUtils.sum(prec_factu, masdscto, monvtasuce);
            tfob = SunatNumberUtils.diference(tfob, vgas_trimp, vgas_carde, vgas_eposi, vint_deven, votr_gasto);
        }        
        
        return tfob;
    }
    
    public static BigDecimal obtenerAjusteTotalFormatoB(DAV dav){
        BigDecimal totalAjustes = BigDecimal.ZERO; 
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PAGO_INDIR).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_DESCRETRO).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_OTRODSCTO).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VCOM_CORRE).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VENV_EMBAL).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MATECOMP).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_HERRUTIL).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MATCONSU).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_TRABINGE).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VDER_LICEN).getMtologistico());
        totalAjustes = SunatNumberUtils.sum(totalAjustes, getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PROD_REVEN).getMtologistico());
        return totalAjustes;
    }
	
	private static boolean containsItem(List<DatoItem> listItems, Integer numItem){
		for(DatoItem item:listItems){
			if (item.getNumsecitem().intValue()==numItem)
				return true;
		}
		return false;
	}
	
	/* Inicio RIN10 3007 erodriguezb */
	/**
	 * Resumen: Verifica si transmiti� fecha fin de VP o transmiti� el valor �2� en el campo tipo valor 
	 * o transmiti� valor en los �tems del formato B
	 * @param declaracion  Dua por rectificar
	 * @return
	 * @throws Exception
	 */
	public static boolean validaTransmisionValorFormatoB(Declaracion declaracion) throws Exception{

		boolean result = false; 

		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			for(DAV dav : declaracion.getListDAVs()){
				for(DatoFactura datoFactura : dav.getListFacturas()){
					for(DatoItem datoItem : datoFactura.getListItems()){
						if(datoItem.getMontoProv().getFecvalestima()!= null || 
								(datoItem.getMontoProv().getValmonto()!=null && datoItem.getMontoProv().getValmonto().compareTo(BigDecimal.ZERO) > 0) || //PAS20155E220000404
							Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){ 
							return true;
						}
					}
				}
			}

		}

		return result;
	}
	

	/*INICIO-RIN10 FSW AFMA*/


	public static boolean tieneAlMenos1ItemVP(Declaracion declaracion) throws Exception{

		return validaItemTransmisionVP(declaracion);
	}
/*FIN-RIN10 FSW AFMA*/

	/** RIN10
	 * Resumen: Verifica si transmiti� valor estimado en las series
	 * @param declaracion  Dua por rectificar
	 * @return
	 * @throws Exception
	 */
	public static boolean validaTransmisionValorSeries(Declaracion declaracion) throws Exception{

		boolean result = false; 
		for(DatoSerie serie : declaracion.getDua().getListSeries()){
			if(serie.getValestimado() != null){ 
				return true;
			}

		}	
		return result;
	}	
	
	/** RIN10
	 * Resumen: Verifica si transmiti� al menos un �tem con el valor �2-Valor Provisional�
	 * @param declaracion Dua por rectificar
	 * @return true o false
	 * @throws Exception
	 */
	public static boolean validaItemTransmisionVP(Declaracion declaracion) throws Exception{

		boolean result = false; 

		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			for(DAV dav : declaracion.getListDAVs()){
				for(DatoFactura datoFactura : dav.getListFacturas()){
					for(DatoItem datoItem : datoFactura.getListItems()){
						if(datoItem.getMontoProv()!=null && Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){ 
							result = true;
							break;
						}
					}
				}
			}
		}	
		return result;
	}
	

	/**
	 * Resumen: Verifique que no cambie el Tipo de Valor al �2- Valor Provisional� en el formato B
	 * @param declaracion  Dua por rectificar
	 * @return
	 * @throws Exception
	 */
//	public static boolean validarCambioItemRegularizado(DatoSerie serieBD, Declaracion declaracion, Declaracion declaracionBD){
//		DatoSerie serieT=null;
//		boolean result = false;
//		for(DatoSerie serieComp:declaracion.getDua().getListSeries()){
//			if(serieBD.getNumserie().equals(serieComp.getNumserie())){
//				serieT = serieComp;
//				break;
//			}			
//		}
//		
//		if(serieT!=null){
//			List<DatoItem> itemsBD = FormatoBUtils.getItemsSeries(declaracionBD.getListDAVs(), serieBD);
//			List<DatoItem> itemsT = FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serieT);
//			for(DatoItem itemBD : itemsBD) {
//				if(Constantes.IND_VALOR_DEFINITIVO.equals(itemBD.getMontoProv().getIndtipovalor())){
//					for(DatoItem itemT : itemsT) {
//						if(itemBD.getNumsecitem() == itemT.getNumsecitem()){
//							if(Constantes.TIENE_VALOR_PROVISIONAL.equals(itemT.getMontoProv().getIndtipovalor())){
//								result = true;
//								break;
//							}
//						}
//					}	
//				}
//			}
//		}
//		
//		return result;
//	}
	
	/** RIN10
	 * Resumen: Verifica que todos los items se modifiquen a valor definitivo
	 * @param declaracion  Dua por rectificar
	 * @return result boolean, true si todos los items tienen valor definitivo, sino false
	 * @throws Exception
	 */
	public static boolean validaTodosItemsValorDefinitivo(Declaracion declaracion) throws Exception{

		boolean result = false; 

		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			result = true;
			for(DAV dav : declaracion.getListDAVs()){
				for(DatoFactura datoFactura : dav.getListFacturas()){
					for(DatoItem datoItem : datoFactura.getListItems()){
						if(datoItem.getMontoProv()!=null && !Constantes.IND_VALOR_DEFINITIVO.equals(datoItem.getMontoProv().getIndtipovalor()) && datoItem.getMontoProv().getIndtipovalor() != null){ //PAS20175E220200050
							return false;
						}
					}
				}
			}
		}

		return result;
	}

	/** RIN10
	 * Resumen: Verifica que se transmita en blanco la �Fecha fin del valor provisional� de todos los �tems 
	 * @param declaracion  Dua por rectificar
	 * @return result boolean, true si alg�n �tem tiene fecha, sino false
	 * @throws Exception
	 */
	public static boolean validaTransmisionFechaFinVP(Declaracion declaracion) throws Exception{

		boolean result = false; 

		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			for(DAV dav : declaracion.getListDAVs()){
				for(DatoFactura datoFactura : dav.getListFacturas()){
					for(DatoItem datoItem : datoFactura.getListItems()){
						if(datoItem.getMontoProv().getFecvalestima()!= null){ 
							return true;
						}
					}
				}
			}

		}

		return result;
	}
	
	/** RIN10
	 * Resumen: Verifica si transmiti� valor en los �tems del formato B
	 * @param declaracion  Dua por rectificar
	 * @return boolean true si transmiti� valor
	 * @throws Exception
	 */
	public static boolean validaTransmisionValorEstimadoFormatoB(Declaracion declaracion) throws Exception{

		boolean result = false; 

		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			for(DAV dav : declaracion.getListDAVs()){
				for(DatoFactura datoFactura : dav.getListFacturas()){
					for(DatoItem datoItem : datoFactura.getListItems()){
						if(datoItem.getMontoProv().getValmonto()!=null){ 
							return true;
						}
					}
				}
			}

		}

		return result;
	}
	/* Fin RIN10 3007 erodriguezb */
}
