package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero.despacho.comun.impo.model.TabImpDU;
import pe.gob.sunat.despaduanero2.model.Participante;

public interface GetDeclaracionSIGADService {

	/**
	 * Obtiene las declaraciones anticipadas y urgentes pendientes de regularizar
	 * @param importador
	 * @param fechareferencia
	 * @return
	 */
	public List<TabImpDU> getDeclaracionPendienteRegularizarSIGAD(Participante importador, String codiAduan, Date fechareferencia, String tipoDespa);
		
	/**
	 * Obtiene la fecha de segunda recepcion dependiendo del regimen
	 * @param codaduana
	 * @param anoprese
	 * @param codiregi
	 * @param numecorre
	 * @return
	 */
	public Date getFechaSegundaRecepcionSIGAD(String codaduana, String anoprese, String codiregi, String numecorre);
}
