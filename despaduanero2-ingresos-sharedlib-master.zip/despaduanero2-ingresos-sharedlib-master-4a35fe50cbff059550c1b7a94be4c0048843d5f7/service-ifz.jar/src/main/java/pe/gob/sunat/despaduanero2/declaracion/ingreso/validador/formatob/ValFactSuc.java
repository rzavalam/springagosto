package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;

public interface ValFactSuc {
	public Map<String, String> validarFechaFacturaSucesiva(DatoFactSuce facturaSucesiva);
	public Map<String, String> numfactsuc(DatoFactSuce facturaSucesiva);
	public Map<String, String> mtofactsuc(DatoFactSuce facturaSucesiva);
	
	

}
