package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.ArchivoAnexoDocControlMR;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.DocControlMercRestringidaVuce;

public interface MercanciaRestringidaEntidadService {
	
	/*Validar Mercancia Restringida y Prohibida*/
	//rtineo optimizacion
	public Map<String, Object> setupMercanciaRestringida (Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public Map<String, Object> setupDocumentoAutorizadoSubTipoDocumento(Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso);
	//fin optimizacion
	
	public List<Map<String, String>> validarSubEntidadCodExoneracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarTipDocExoneracionInfo (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarTipDocExoneracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarTipDocSinExoneracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
		
	public List<Map<String, String>> validarTipDocExoneracionInfoOtros (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarTipDocExoneracionOtros (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarTipDocSinExoneracionOtros (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutImportadorVigente (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutPrimeraDeclaracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutFecVenciRegPrece (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarInterconexionSenasa (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutDiasUsoDeclara (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarInterconexionDigesa (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecVencimiento (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecNumeracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecVencimientoAnio (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecVencimientoDosAnio (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecNumeracionDias (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarFecModalidadDeclara (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarSubTipoDocumento (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarSubTipoDocDifinitivo (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarSubTipoDocTemporal (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutAnioUsoDeclara (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutCodExoDescripcion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutNoCodExoneracion (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutRegPrecede (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	public List<Map<String, String>> validarDocAutFecNumDeclara (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	/*Validar IQBF*/
	
	/**Realiza la consulta para validar si la DUA a rectificar tiene fecha de regularizaci�n y 
	 * adem�s si existe diferencias en la serie del XML con las series declaradas anteriormente, 
	 * asimismo verifica las diferencias para cada documento autorizante
	 * @param declaracion
	 * @param declaracionBD
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> valDiferenciaSerieDocAutDuaConLevante (Declaracion declaracion,
			Declaracion	declaracionBD, Date	fechaReferencia, Map<String, Object> variablesIngreso);

	/**Realizar validaciones para que el documento autorizante sea igual para todas las series de la declaraci�n y 
	 * que no se consigne un mismo �tem para m�s de una serie
	 * @param declaracion
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarItemDocAutoriza (Declaracion declaracion, Date fechaReferencia, Map<String, Object>	variablesIngreso);	
	
	/** Verificar que la declaracion de deposito precedente tenga registrada el documento IQBF y que se encuentre concluida 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarPrecedenteDepositoDocAut (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/** Validar que se haya declarado los documentos autorizantes necesarios para validar las mercanc�as restringidas de los documento IQBF
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarDocAutPermitidosIQBF (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);		
	
	/** Verifica que el documento cumpla con las reglas de negocio para modalidad anticipada, reutilizaci�n de un documento autorizante y 
	 * validaciones entre la fecha de emisi�n del documento contra la fecha de llegada y la fecha de numeraci�n de la declaraci�n
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> valIndicadorRegularizaFecEmisionDocAut (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);		
	
	/**Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto al RUC del beneficiario/Importador, aduana de la declaracion, numero y item del documento autorizante 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarCabDocAutorizaEntidad (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/**Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto a la partida arancelaria y unidad comercial, control de las cantidades y pesos del documento autorizante
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarDetDocAutorizaEntidad (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/** Validar si el documento autorizante se encuentra vencido 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public List<Map<String, String>> validarVencimientoDocAut (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/** Validar si el documento autorizante se encuentra en estado otorgada o destinada
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public List<Map<String, String>> validarEstadoDocAutoriza (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/**  Validar que se haya declarado los documentos autorizantes requeridos para validar las mercanc�as restringidas en el proceso de diligencia
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public List<Map<String, String>> validarDocAutorizaRequerido (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);	
	
	/** Validar que se haya declarado los documentos autorizantes no requeridos para validar las mercanc�as restringidas en el proceso de diligencia
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public List<Map<String, String>> validarDocAutorizaNoRequerido (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	// Rin 14  - INI -  JYC
	public Map<String, Object> validarDocAutorizaLevanteDUA(Long numCorreDoc, String codAduana, String codRegi, Integer annPrese, Integer numDeclara );
	// Rin 14  - FIN -  JYC	
	
	/** Realizar las verificaciones aplicadas a las mercanc�as IQBF en el proceso de diligencia de la declaraci�n
	 * @param lstDocAutoriza
	 * @param mapValoresSerie
	 * @return
	 */
	public Map<String, Object> validarMRestriSPNDiligencia (List<DatoDocAutorizante> lstDocAutoriza, Map<String, Object> mapValoresSerie);

	/** Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto a la partida arancelaria y unidad comercial, el control de las cantidades y pesos del documento autorizante
	 * @param lstDocAutorizaMRestri
	 * @param mapValoresSerie
	 * @param codServicio
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarSpnUnidadCantidadPesoDocAut(List<DatoDocAutorizante> lstDocAutorizaMRestri,
			Map<String, Object>	mapValoresSerie, String	codServicio,Date fechaReferencia, Map<String, Object> variablesIngreso);
	
	// Rin 14  - INI -  JCR
	public void actualizarEstadoDocAutorizaIQBF(Long numCorreDoc);
	// Rin 14  - FIN -  JCR	
	
	public String validarLevanteNoAutorizadoIQBF(Long numCorreDoc,String codAduana,String codRegi,Integer annPrese,Integer numDeclara,String codModalidad);
	
	//RIN 14 mpoblete CUS14.04.01
	/** Verifica que el RUC del documento declarado sea el mismo que del Declarante de la DUA
	 * @param docAutoriza
	 * @param codAduana
	 * @param codRegimen
	 * @param cabMrDocAutoriz
	 * @param rucImportador
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarRucDocAutoriza(DatoDocAutorizante docAutoriza, String codAduana,
			String codRegimen, CabMrDocAutoriz cabMrDocAutoriz, String rucImportador,String numSerie);
	//RIN 14 mpoblete CUS14.04.01
	public String validaRucDocAutorizaIQBF(Map declaracionActual);
	//RIN 14 jcrespo CUS 01.17
	/** Actualizar el estado, cantidad y peso en las tablas  CAB_MR_DOCAUTORIZ y DET_MR_DOCAUTORIZ
	 * @param declaracion Declaracion 
	 */
	 public void actualizarDocAutorizaIQBF(Declaracion declaracion, String codEstado);
	 
	 public void actualizarDocAutRectificacion(String codTabla,Map<String,Object> key,Map<String,Object> datos,String tipoMod);
	//RIN 14 jcrespo CUS 01.17
	
	/** Metodo para actualizar la tablas CAB_MR_DOCAUTORIZ y DET_MR_DOCAUTORIZ
	 * @param indRegistro
	 * @param estadoDoc
	 * @param docAutoriza
	 * @param codAduana
	 * @param codRegimen
	 * @param numCorreDoc //numeCorre
	 * @param annPrese
	 * @param numeSerie
	 * @param codModalidad
	 * @param codUniComer
	 * @param cntUniComer
	 * @param cntPesoNeto
	 */
	 @Deprecated
	public void actualizarDocAutorizanteIQBF(String indRegistro, String estadoDoc ,DatoDocAutorizante docAutoriza,String codAduana,
	    		String codRegimen, String numCorreDoc, String annPrese, String numeSerie, String codModalidad,String codUniComer, BigDecimal cntUniComer,BigDecimal cntPesoNeto);
	
	public void actualizarDocAutorizanteIQBF(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana, Declaracion declaracion, DatoSerie serie);
	
	@Deprecated
	public void actualizarDocAutorizanteIQBFBatch(String indRegistro, String estadoDoc ,DatoDocAutorizante docAutoriza,String codAduana,
    		String codRegimen, String numCorreDoc, String annPrese, String numeSerie, String codModalidad,String codUniComer, BigDecimal cntUniComer,BigDecimal cntPesoNeto);
	
	public void actualizarDocAutorizanteIQBFBatch(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana, Declaracion declaracion, DatoSerie serie);
	
	public void iniciaBatchAutorizante();
	
	public void procesarBatchAutorizante() throws Exception;
	
	public void actualizarConclusionDocAutorizaIQBF(Declaracion declaracion);
	
	public List<Map<String, Object>> copiarRestanteDetDeclaraActual(List<Map<String, Object>> lstDetDeclara, List<Map<String, Object>> lstDetDeclaraActual);

	//gg vuce	 
	DocControlMercRestringidaVuce obtenerDocumentoVuce(Long numDoc, String tipoDoc);
	   DocControlMercRestringidaVuce obtenerDocumentoVuce(Long numDoc, String tipoDoc,String usuario);
	    
	  //endregion amancillaa

//PAS20165E220200079
	public List<Map<String, String>> validarMercanciaRestringidaPorSerie(DatoSerie serie, Map<String, Object> variablesIngreso); 
	
	public List<Map<String,String>> validarGeneralVuce(String codtipDocControl,String numeroSerie, Map<String, Object> map);
	
	//control de cambios vuce
	public List<Map<String,String>>  validarMercanciaRestringidaVuceMtcOtrosDocs(String codDocAutorizante,  String mercanciaSpn, String numeroSerie, String codigoEntidad,String codigoSubEntidad);

	List<String> obtenerRegistrosPorBusquedaMrestri(String numeroPartida , Date fechaReferencia, String regimen, List<MRestri> lstMrestri);
	//String obtenerRegistroPorCut(String cutVuce, Date fechaReferencia,  List<String> lstRegistrosMrestri);
	String obtenerRegistroPorCut(List<String> listSuEntidadesCut,  List<String> lstRegistrosMrestri);
	 public List<String> obtenerSubentidadesPorCut(String cutVuce, Date fechaReferencia);
	 public void obtenerArchivoPDF(ArchivoAnexoDocControlMR archivo, String numeroDocumentoControl, String usuario);
	 //PAS20181U220200049
	 public Map<String, String> validaSinICAIqbfDAMDiferida (Declaracion declaracion, Map<String, Object> variablesIngreso);
}
