package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

public class PuntoLLegadaValidadorException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5531371648894244139L;
	
	private String codigoError = null;
	
	private String[] argumentos = {""};
	
	
	public PuntoLLegadaValidadorException(){
		super();
	}
	
	public PuntoLLegadaValidadorException(String codigoError){
		super(codigoError);
		this.codigoError = codigoError;
	}
	
	public PuntoLLegadaValidadorException(String codigoError, String message) {
		super(codigoError + ":" + message);
		this.codigoError = codigoError;
	}
	
	public PuntoLLegadaValidadorException(String codigoError, String[] argumentos, String message) {
		super(codigoError +": "+ message);
		this.codigoError = codigoError;
		this.argumentos = argumentos;
	}

	public PuntoLLegadaValidadorException(String codigoError, Throwable paramThrowable) {
		super(paramThrowable);
		this.codigoError = codigoError;
	}

	public PuntoLLegadaValidadorException(Throwable paramThrowable) {
		super(paramThrowable);
	}

	public String getCodigoError() {
		return codigoError;
	}
	
	public String[] getArgumentos() {
		return argumentos;
	}
	

}
