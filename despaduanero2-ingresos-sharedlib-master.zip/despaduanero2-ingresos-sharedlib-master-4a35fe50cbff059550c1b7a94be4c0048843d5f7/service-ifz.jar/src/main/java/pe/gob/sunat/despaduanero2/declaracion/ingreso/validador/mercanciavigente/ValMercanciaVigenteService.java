package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public interface ValMercanciaVigenteService {

	public List<Map<String, String>> validaIndicadorMercanciaVigente(DUA dua);	

	public Map<String,Object> obtenerDAMPrecedenteMercanciaVigente( String aduanaPrecedente, String anoPrecedente, String regimenPrecedente, String numeroPrecedente);

	public boolean tieneIndicadorMercanciaVigente( Elementos<DatoIndicadores> indicadores );

	public Integer obtenerSecuenciaEnvioPorDeclaracion( Declaracion declaracion ) ;
	
	public Integer obtenerSecuenciaEnvio( String codAduana, String anoPresen, String codRegimen, String numDeclara );
	
	public Integer obtenerEnviosRegistrados(String codAduana, String anoPresen, String codRegimen, String numDeclara );
	
	public Integer obtenerEnviosRegistrados(Long numcorredoc);
		
	public Integer obtenerNumTotalEnvios( Elementos<DatoIndicadores> indicadores );

	public Integer obtenerNumTotalEnvios(Long numcorredoc);
 
	public Long obtenerNumcorredocPrimigeniaPorVigente(Long numcorredoc, Integer numSecSerie);
	
	public Map<String, String> obtenerNumcorredocComprobanteCustodia(Long numcorredoc, Integer numSecSerie);

	public Map<String, String> actualizarDocuprecedua(Long numcorredoc, Integer numSecSerie);
	
	public void actualizarComprobanteCustodia(String anoPrese, String codiAduan, String numeCorre, String codaduanaConex,String cantSerie,String codPautoriza);

	public Map<String,Object> obtenerIndicadorMercanciaVigente( Elementos<DatoIndicadores> indicadores );
	
	public void grabaTelelog(List<Map<String,String>>listError, String codigo, Object[] params);

	public DatoIndicadores obtenerIndicadorLlaveManoDespachoParcial (List<DatoIndicadores>  listaIndicadores);		
	
	public boolean estaAcogidoLlaveManoDespachoParcial (String numcorredocDam) ;
 	
	public List<Map<String, String>> validaIndicadorDAMVigente(Integer numSerie, String DAMPrecedente, String indicadorVigente, String indicadorPrecedente);

	public String indicadorLlaveMaquinariaPrevio(long numecorredoc, String[] listaIndicadores);
	
	public boolean esDeclaracionPrimigenia(Long numcorredoc, String indicador);

	public List<Map<String,String>> filtraErroresDuplicados (List<Map<String,String>> listaErrores);
	
	public List<Map<String,String>> valTipoPrecedente(DatoSerie serie);
	
	public List<Map<String,String>> valPrecedentexSerie(Declaracion declaracion);
	
	public List<Map<String,String>> valConsignatarioPrecDeclaracion(Declaracion declaracion);
	
	public List<Map<String,String>> valLevantePrecDeclaracion(Declaracion declaracion) throws ParseException;
	
	public List<Map<String,String>> valCanalSolRecoDeclaracion(Declaracion declaracion);
	
	public List<Map<String,String>> valIncideciaDeclaracion(Declaracion declaracion);
	
	public List<Map<String,String>> valFechaPrecedente(Declaracion declaracion);

	//PAS20191U220200002 - mtorralba 20190611
	public List<Map<String, String>> obtenerNumcorredocComprobanteCustodia(Long numcorredoc);
}

