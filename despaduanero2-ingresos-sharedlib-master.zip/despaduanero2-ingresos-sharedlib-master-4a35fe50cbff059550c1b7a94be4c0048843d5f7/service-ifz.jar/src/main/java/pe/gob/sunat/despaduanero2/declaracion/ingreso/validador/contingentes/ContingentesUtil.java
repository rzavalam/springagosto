/*
 * Clase que define el servicio de validaciones de las validaciones utilitarias de los contingentes arancelarios
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes;

import static pe.gob.sunat.despaduanero2.manifiesto.util.Constantes.IND_REGISTRO_ACTIVO;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PaisOrigenTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.ContCtaCte;
import pe.gob.sunat.despaduanero2.declaracion.model.ContPeriodo;
import pe.gob.sunat.despaduanero2.declaracion.model.Contplazo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.OperaCarga;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContCtaCteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContingenteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContPeriodoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OperaCargaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PrupersoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContValidDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.ContCtaCteCriteria;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.ContPeriodoCriteria;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.OperaCargaCriteria;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoOABL;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdage;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.orquestador.bean.EnvErrorCabBean;
import pe.gob.sunat.tecnologia.orquestador.model.dao.EnvErrorCabDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;//PAS20165E220200022

// TODO: Auto-generated Javadoc
/**
 * Clase utilitaria para la validacion de contingentes
 * @author rcalla
 *
 */
public class ContingentesUtil {
	private static final String MSG_08808 = "V�A DE TRANSPORTE NO PERMITIDA PARA ACOGERSE A CONTINGENTE ARANCELARIO";
	private static final String MSG_00121 = "CONTINGENTE SOLICITADO NO PERMITIDO, EL MANIFIESTO NO SE ENCUENTRA REGISTRADO";
	private static final String MSG_08225 = "CONTINGENTE SOLICITADO NO PERMITIDO, EL MANIFIESTO DEBE CONTAR CON NOTA DE TARJA EFECTUADA POR EL TRANSPORTISTA";
	private static final String MSG_08066 = "CONTINGENTE SOLICITADO NO PERMITIDO, EL MANIFIESTO DEBE CONTAR CON FECHA DE LLEGADA";
	private static final String MSG_08809 = "CONTINGENTE SOLICITADO NO PUEDE SER ANTERIOR A LA TRANSMISI�N DE LA NOTA DE TARJA, DEBE RETIRAR EL TPI Y TM";
	private static final String MSG_30774 = "PARA ACOGERSE A CONTINGENTE EN UN DESPACHO URGENTE, DEBE NUMERARSE CUANDO EXISTA FECHA Y HORA DE LLEGADA";
	private static final String COD_TRX_RECT_OFI_VAL = "09"; //RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_GRA = "10"; //RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_D_VAL = "19"; //RMC RIN-P47
	private static final String COD_TRX_RECTIFICACION = "03"; //RMC RIN-P47
	private static final String COD_TRX_REGULARIZA_ANT = "04"; //RMC RIN-P47
	private static final String COD_TRX_DILIG_RECTIF = "07"; //RMC RIN-P47

	private final Log log = LogFactory.getLog(getClass());
	
	private EnvErrorCabDAO envErrorCabDAO;
	private DetDeclaraDAO detDeclaraDAO;
	private PrupersoDAO prupersoDAO;
	private ContCtaCteDAO contCtaCteDAO;
	private ContingenteDAO contingenteDAO;
	private DetPagoDuaDAO detPagoDuaDAO;
	private DeudaDocumDAO deudaDocumDAO;
	
//	private CatalogoHelperImpl catalogoHelper;
	private ManifiestoValidacionService manifiestoValidacionService;
	private ManifiestoService manifiestoService;
	private DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService;
	
	private GetDeclaracionService getDeclaracionService;
	private OperaCargaDAO operaCargaDAO;

	// Inicio: PAS20145E220000337 - rcontreras
	private FabricaDeServicios fabricaDeServicios;
	private ContValidDAO contValidDAO;
	// Fin: PAS20145E220000337 - rcontreras
    //amancilla no se como funiona en produccion parche de pirata
	private HotSwappableTargetSource swapperDatasource;
	
	public HotSwappableTargetSource getSwapperDatasource()
	{
		return this.swapperDatasource;
	}
	

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource)
	{
		this.swapperDatasource = swapperDatasource;
	}
	//fin amancilla

	/**
	 * Establece un valor a envErrorCabDAO.
	 * 
	 * @param envErrorCabDAO EnvErrorCabDAO
	 */
	public void setEnvErrorCabDAO(EnvErrorCabDAO envErrorCabDAO) {
		this.envErrorCabDAO = envErrorCabDAO;
	}

	/**
	 * Establece un valor a detDeclaraDAO.
	 * 
	 * @param detDeclaraDAO DetDeclaraDAO
	 */
	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	/**
	 * Establece un valor a getDeclaracionService.
	 * 
	 * @param getDeclaracionService GetDeclaracionService
	 */
	public void setGetDeclaracionService(GetDeclaracionService getDeclaracionService) {
		this.getDeclaracionService = getDeclaracionService;
	}

	/**
	 * Establece un valor a prupersoDAO.
	 * 
	 * @param prupersoDAO PrupersoDAO
	 */
	public void setPrupersoDAO(PrupersoDAO prupersoDAO) {
		this.prupersoDAO = prupersoDAO;
	}

	/**
	 * Establece un valor a contCtaCteDAO.
	 * 
	 * @param contCtaCteDAO ContCtaCteDAO
	 */
	public void setContCtaCteDAO(ContCtaCteDAO contCtaCteDAO) {
		this.contCtaCteDAO = contCtaCteDAO;
	}

	/**
	 * Establece un valor a contingenteDAO.
	 * 
	 * @param contingenteDAO ContingenteDAO
	 */
	public void setContingenteDAO(ContingenteDAO contingenteDAO) {
		this.contingenteDAO = contingenteDAO;
	}

	/**
	 * Establece un valor a detPagoDuaDAO.
	 * 
	 * @param detPagoDuaDAO DetPagoDuaDAO
	 */
	public void setDetPagoDuaDAO(DetPagoDuaDAO detPagoDuaDAO) {
		this.detPagoDuaDAO = detPagoDuaDAO;
	}

	
	/**
	 * Establece un valor a deudaDocumDAO.
	 * 
	 * @param deudaDocumDAO DeudaDocumDAO
	 */
	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}
	
	/**
	 * Establece un valor a catalogoHelper.
	 * 
	 * @param catalogoHelper CatalogoHelperImpl
	 */
//	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
//		this.catalogoHelper = catalogoHelper;
//	}

	/**
	 * Establece un valor a manifiestoValidacionService.
	 * 
	 * @param manifiestoValidacionService ManifiestoValidacionService
	 */
	public void setManifiestoValidacionService(ManifiestoValidacionService manifiestoValidacionService) {
		this.manifiestoValidacionService = manifiestoValidacionService;
	}

	/**
	 * Establece un valor a manifiestoService.
	 * 
	 * @param manifiestoService ManifiestoService
	 */
	public void setManifiestoService(ManifiestoService manifiestoService) {
		this.manifiestoService = manifiestoService;
	}

	/**
	 * Establece un valor a documentoOAManifiestoValidacionService.
	 * 
	 * @param documentoOAManifiestoValidacionService DocumentoOAManifiestoValidacionService
	 */
	public void setDocumentoOAManifiestoValidacionService(DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService) {
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
	}

 
	/**
	 * Retorna el valor de list join contingente a la fecha de numeracion.
	 * 
	 * @param serie DatoSerie
	 * @return  list join contingente
	 * @return
	 */
	public List<Map<String, Object>> getListJoinContingente(DatoSerie serie, Declaracion declaracion) {
		Map<String, Object> paramsJoinContingente = new HashMap<String, Object>();
		paramsJoinContingente.put("numSubPartida", SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
		paramsJoinContingente.put("codTPI", String.valueOf(serie.getCodconvinter()));
		paramsJoinContingente.put("codPaisOrigen", serie.getCodpaisorige());
		if (!SunatStringUtils.isEmptyTrim(serie.getCodtipomarge()))
			paramsJoinContingente.put("CodTipoMargen", SunatStringUtils.lpad(serie.getCodtipomarge(), 2, '0'));
		if (  declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) 
			paramsJoinContingente.put("fechIngsi", SunatDateUtils.getDate(SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")));//gmontoya Pase 24
		else
			paramsJoinContingente.put("fechIngsi", declaracion.getDua().getFecdeclaracion());
		if (!SunatStringUtils.isEmptyTrim(serie.getNumpartnalad())){
			if(serie.getNumpartnalad().trim().equals("0") ) {
				paramsJoinContingente.put("numNaladisa", " ");
			} else {
				paramsJoinContingente.put("numNaladisa", serie.getNumpartnalad().trim());	
			}
		}
		
		List<Map<String, Object>> listJoinContingente = contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(paramsJoinContingente);
		return listJoinContingente;

	}

	 
	
	//Para este metodo se verifica cual de todos los casos cumple que tiene la cantidad solicitada para afectarlo.
	public Map<String,Object> getMapRectifOficio(DatoSerie serie, Declaracion declaracion) {
		
		 Map<String,Object>  mapDatosCont=new HashMap<String, Object>();
	List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		BigDecimal cantSolCont = BigDecimal.ZERO;
		List<Map<String,Object>> listContRectifi = listContingenteRecOficio(serie,  declaracion);
		
			
			if( !CollectionUtils.isEmpty(listContRectifi)){
				mapDatosCont = listContRectifi.get(0);
				for (Map<String,Object> mapDatosContPeriodo  : listContRectifi) {
						BigDecimal cntSaldoContPerRecti = SunatNumberUtils.toBigDecimal(mapDatosContPeriodo.get("cntSaldoCont"));
						if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPerRecti)){
							listValidPorAlcohol= getListFactEquiAlcohol(declaracion, mapDatosContPeriodo);
							cantSolCont = getCantContingenteSolicitado(serie, mapDatosContPeriodo, listValidPorAlcohol);
							if( SunatNumberUtils.isLessOrEqualsThanParam(cantSolCont,cntSaldoContPerRecti) ){
								mapDatosCont = mapDatosContPeriodo;
								break;
							}
						}
					}
				
			}
					
	 
					
	return mapDatosCont;
}		
	 
	public List<Map<String, Object>>listContingenteRecOficio(DatoSerie serie, Declaracion declaracion) {
		Map<String, Object> paramsJoinContingente = new HashMap<String, Object>();
		paramsJoinContingente.put("numSubPartida", SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
		paramsJoinContingente.put("codTPI", String.valueOf(serie.getCodconvinter()));
		paramsJoinContingente.put("codPaisOrigen", serie.getCodpaisorige());
		if (!SunatStringUtils.isEmptyTrim(serie.getCodtipomarge()))
			paramsJoinContingente.put("CodTipoMargen", SunatStringUtils.lpad(serie.getCodtipomarge(), 2, '0'));
		if (  declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) 
			paramsJoinContingente.put("fechRectOficio", SunatDateUtils.getDate(SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")));//gmontoya Pase 24
		else
			paramsJoinContingente.put("fechRectOficio", declaracion.getDua().getFecdeclaracion());
		
		if (!SunatStringUtils.isEmptyTrim(serie.getNumpartnalad())){
			if(serie.getNumpartnalad().trim().equals("0") ) {
				paramsJoinContingente.put("numNaladisa", " ");
			} else {
				paramsJoinContingente.put("numNaladisa", serie.getNumpartnalad().trim());	
			}
		}
		
		List<Map<String, Object>> listJoinContingente = contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(paramsJoinContingente);
		return listJoinContingente;

	}
	
	
	
	
	/**
	 * Retorna el valor de list join contingente a la fecha de numeracion.
	 * 
	 * @param serie DatoSerie
	 * @return  list join contingente
	 * @return
	 */
	//glazaror... optimizacion
	public List<Map<String, Object>> getListJoinContingente(DatoSerie serie, Declaracion declaracion, Map<String, Object> variablesIngreso) {
		//verificamos si la data ya fue cargada anteriormente
		Map<String, List<Map<String, Object>>> contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCache");
		//pase PAS20155E220200016
		boolean vacio =true;
		if (contingentesCache!=null)
			if (!contingentesCache.isEmpty())
				vacio=false; 
		
		
		if (contingentesCache == null || vacio) {
			//entonces ejecutamos una unica consulta en BD
			StringBuilder consultaBuilder = new StringBuilder();
			List<String> adicionados = new ArrayList<String>();
			for (DatoSerie serieVerificada : declaracion.getDua().getListSeries()) {
				//formateado a 10 caracteres
				String numeroPartida = SunatStringUtils.lpad( serieVerificada.getNumpartnandi().toString(), 10, '0');
				//formateado a 4 caracteres
				String codigoTPI = SunatStringUtils.lpad( String.valueOf(serieVerificada.getCodconvinter()), 4, ' ');
				String codigoPaisOrigen = serieVerificada.getCodpaisorige();
				String clave = numeroPartida + codigoTPI + codigoPaisOrigen;
				if (!adicionados.contains(clave)) {
					consultaBuilder.append(numeroPartida).append(codigoTPI).append(codigoPaisOrigen).append(",");
					adicionados.add(clave);
				}
			}
			if (consultaBuilder.length() > 0) {
				consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
				Map<String, Object> parametros = new HashMap<String, Object>();
				if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
					parametros.put("fechIngsi", SunatDateUtils.getCurrentDate());
				} else {
					parametros.put("fechIngsi", declaracion.getDua().getFecdeclaracion());
				}
				//amancilla SAU20153D211000699
				// amancilla parametros.put("DOCUMENTO_LIST", consultaBuilder.toString());
				// amancilla List<Map<String, Object>> listJoinContingente = contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(parametros);

				List<String> listConsultaBuilder = GeneralUtils.obtenerListCadenas(consultaBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				List<Map<String, Object>> listJoinContingente = new ArrayList<Map<String, Object>>();
				for(String cadenaConsulta : listConsultaBuilder){
					parametros.put("DOCUMENTO_LIST", cadenaConsulta.toString());
					listJoinContingente.addAll(contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(parametros));
				}
				//fin amancilla

				//agrupamos
				contingentesCache = new HashMap<String, List<Map<String, Object>>>();
				for (Map<String, Object> contingente : listJoinContingente) {
					//C.COD_TPI, C.COD_TIPO_MARGEN, C.COD_PAIS_ORIGEN, C.NUM_GRUPO_CONT, D.NUM_SUBPARTIDA
					String numeroPartida = SunatStringUtils.lpad((String) contingente.get("numSubpartida"), 10, '0');
					String codigoTPI = SunatStringUtils.lpad((String) contingente.get("codTpi"), 4, ' ');
					String codigoPaisOrigen = (String) contingente.get("codPaisOrigen");
					
					String clave = numeroPartida + "-" + codigoTPI + "-" + codigoPaisOrigen;
					List<Map<String, Object>> contingentes = contingentesCache.get(clave);
					if (contingentes == null) {
						contingentes = new ArrayList<Map<String, Object>>();
						contingentesCache.put(clave, contingentes);
					}
					contingentes.add(contingente);
				}
			}
			if (!CollectionUtils.isEmpty(contingentesCache)) {//RMC RIN-P47
				/// OJOOOO RSERRANOV ..... OJO
			variablesIngreso.put("contingentesCache", contingentesCache);
		}
		}
		//formateado a 10 caracteres
		String numeroPartida = SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0');
		//formateado a 4 caracteres
		String codigoTPI = SunatStringUtils.lpad( String.valueOf(serie.getCodconvinter()), 4, ' ');
		String codigoPaisOrigen = serie.getCodpaisorige();
		
		String clave = numeroPartida + "-" + codigoTPI + "-" + codigoPaisOrigen;
		List<Map<String, Object>> listJoinContingenteFromCache = contingentesCache.get(clave);
		
		//ahora buscamos dentro de listJoinContingenteFromCache
		List<Map<String, Object>> listJoinContingente = new ArrayList<Map<String, Object>>();
		if (listJoinContingenteFromCache != null) {
			for (Map<String, Object> contingente : listJoinContingenteFromCache) {
				boolean adicionarEnLista = true;
				String codigoTipoMargen = null;
				String numeroPartidaNalad = null;
				
				if (!SunatStringUtils.isEmptyTrim(serie.getCodtipomarge())) {
					codigoTipoMargen = SunatStringUtils.lpad(serie.getCodtipomarge(), 2, '0');
				}
				if (!SunatStringUtils.isEmptyTrim(serie.getNumpartnalad())){
					if(serie.getNumpartnalad().trim().equals("0") ) {
						numeroPartidaNalad = " ";
					} else {
						numeroPartidaNalad = serie.getNumpartnalad().trim();	
					}
				}
				
				//validamos
				if (codigoTipoMargen != null && !codigoTipoMargen.equals(contingente.get("cotTipoMargen"))) {
					adicionarEnLista = false;
				}
				if (numeroPartidaNalad != null && !numeroPartidaNalad.equals(contingente.get("numNaladisa"))) {
					adicionarEnLista = false;
				}
				if (adicionarEnLista) {
					listJoinContingente.add(contingente);
				}
			}
		}
		return listJoinContingente;
	}

	
/*	public Map<Integer, Object> getContingentellAsMap( Declaracion declaracion, Map<String, Object> variablesIngreso) {
		Map<Integer, Object> cuentasCorrientesMap = new HashMap<Integer, Object>();
		List<Map<String, Object>> cuentasCorrientesAll = getListContingenteDeclaracion( declaracion, variablesIngreso);
		//agrupamos por serie
		for (Map<String, Object> mapaContingente : cuentasCorrientesAll) {
			if (!cuentasCorrientesMap.containsKey(mapaContingente.get("Serie"))) {
				cuentasCorrientesMap.put(Integer.valueOf( mapaContingente.get("Serie").toString()) , mapaContingente);
			}
		}
		return cuentasCorrientesMap;
	}
	*/
	
	/**
	 * Retorna el valor de list join contingente a la fecha de numeracion.
	 * 
	 * @param serie DatoSerie
	 * @return  list join contingente
	 * @return
	 */
	//RSERRANOV OPTIMIZACION
	public List<Map<String, Object>> getListContingenteSerie( List<Map<String, Object>> lstSeries) {
		List<Map<String, Object>> listJoinContingente = new ArrayList<Map<String, Object>>();
		boolean vacio =true;
			//entonces ejecutamos una unica consulta en BD
			StringBuilder consultaBuilder = new StringBuilder();
			List<String> adicionados = new ArrayList<String>();
			for (Map<String, Object> serieVerificada : lstSeries) {
				//Solo si solicita tipo de margen se considera sino no
				if (solcitaContingente( Integer.valueOf( serieVerificada.get("COD_CONVENIO").toString()), serieVerificada.get("COD_TIPMARGEN").toString().trim() )  ) {
					//formateado a 10 caracteres
					String numeroPartida = SunatStringUtils.lpad( serieVerificada.get("NUM_PARTNANDI").toString().trim(), 10, '0');
					//formateado a 4 caracteres
					String codigoTPI = SunatStringUtils.lpad( serieVerificada.get("COD_CONVENIO").toString().trim(), 4, ' ');
					String codigoPaisOrigen = serieVerificada.get("COD_PAISORIGEN").toString().trim();
					if (codigoTPI.trim().equals("812") ) {
						codigoPaisOrigen = serieVerificada.get("COD_PAISORIGEN812") ==null ? serieVerificada.get("COD_PAISORIGEN").toString().trim() : serieVerificada.get("COD_PAISORIGEN812").toString().trim();
					}
					String clave = numeroPartida + codigoTPI + codigoPaisOrigen;
					if (!adicionados.contains(clave)) {
						consultaBuilder.append(numeroPartida).append(codigoTPI).append(codigoPaisOrigen).append(",");
						adicionados.add(clave);
					}
				}
			}
			
			
			if (consultaBuilder.length() > 0) {
				consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("fechIngsi", SunatDateUtils.getCurrentDate());
				parametros.put("CodTipoMargen",  "05");
				List<String> listConsultaBuilder = GeneralUtils.obtenerListCadenas(consultaBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaConsulta : listConsultaBuilder){
					parametros.put("DOCUMENTO_LIST", cadenaConsulta.toString());
					listJoinContingente.addAll(contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(parametros));
				}
			}

		return listJoinContingente;
	}
	
	/**
	 * Retorna el valor de list join contingente a la fecha de numeracion.
	 * 
	 * @param serie DatoSerie
	 * @return  list join contingente
	 * @return
	 */
	//RSERRANOV OPTIMIZACION
	public Map<String, Object> getListContingenteDeclaracion(  Declaracion declaracion, Map<String, Object> variablesIngreso) {
		//verificamos si la data ya fue cargada anteriormente
		Map<String, List<Map<String, Object>>> contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCache");
		List<Map<String, Object>> listJoinContingente = new ArrayList<Map<String, Object>>();
//		Map<String, List<Map<String, Object>>>  contingentesCache = new HashMap<String, List<Map<String, Object>>>();
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		List<Map<String,Object>> listValidCampos=new ArrayList<Map<String, Object>>();
		Map<String, Object> mapRespuesta = new HashMap<String, Object>();
		Map<String, List<Map<String, Object>>> ListValidCamposCache = new HashMap<String, List<Map<String, Object>>>();
		Map<String, List<Map<String, Object>>>  listFactEquiAlcoholCache = new HashMap<String, List<Map<String, Object>>>();

		String codTransaccion = variablesIngreso.get("codTransaccion") == null ? "": (String)variablesIngreso.get("codTransaccion");
		if ( codTransaccion.trim().length() == 0 )
			codTransaccion =  declaracion.getCodtipotrans() == null ? "": declaracion.getCodtipotrans();

		
		//pase PAS20155E220200016
		boolean vacio =true;
			//entonces ejecutamos una unica consulta en BD
			StringBuilder consultaBuilder = new StringBuilder();
			List<String> adicionados = new ArrayList<String>();
			for (DatoSerie serieVerificada : declaracion.getDua().getListSeries()) {
				//Solo si solicita tipo de margen se considera sino no
				if (solcitaContingente(serieVerificada.getCodconvinter(), serieVerificada.getCodtipomarge() )  ) {
					//formateado a 10 caracteres
					String numeroPartida = SunatStringUtils.lpad( serieVerificada.getNumpartnandi().toString(), 10, '0');
					//formateado a 4 caracteres
					String codigoTPI = SunatStringUtils.lpad( String.valueOf(serieVerificada.getCodconvinter()), 4, ' ');
					String codigoPaisOrigen = serieVerificada.getCodpaisorige();
					if (codigoTPI.trim().equals("812") ) {
						PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
						boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codigoTPI, codigoPaisOrigen);
						if (existePuerto){
							codigoPaisOrigen = "UE";
						} 

					}
					String clave = numeroPartida + codigoTPI + codigoPaisOrigen;
					if (!adicionados.contains(clave)) {
						consultaBuilder.append(numeroPartida).append(codigoTPI).append(codigoPaisOrigen).append(",");
						adicionados.add(clave);
					}
				}
			}
			if (consultaBuilder.length() > 0) {
				consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
				Map<String, Object> parametros = new HashMap<String, Object>();
				if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ) {
					if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
						parametros.put("fechRectOficio", SunatDateUtils.getCurrentDate());
					}
					else {
						parametros.put("fechRectOficio", declaracion.getDua().getFecdeclaracion());
					}

				} else {


					if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
						parametros.put("fechIngsi", SunatDateUtils.getCurrentDate());
					} else {
						parametros.put("fechIngsi", declaracion.getDua().getFecdeclaracion());
					}	

				}
				
				parametros.put("CodTipoMargen",  "05");
				List<String> listConsultaBuilder = GeneralUtils.obtenerListCadenas(consultaBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaConsulta : listConsultaBuilder){
					parametros.put("DOCUMENTO_LIST", cadenaConsulta.toString());
					listJoinContingente.addAll(contingenteDAO.joinContSubPartiAndContPeriodoFindByMap(parametros));
				}
				contingentesCache = new HashMap<String, List<Map<String, Object>>>();
				//agrupamos
				for (Map<String, Object> contingente : listJoinContingente) {
					//C.COD_TPI, C.COD_TIPO_MARGEN, C.COD_PAIS_ORIGEN, C.NUM_GRUPO_CONT, D.NUM_SUBPARTIDA
					String numeroPartida = SunatStringUtils.lpad((String) contingente.get("numSubpartida"), 10, '0');
					String codigoTPI = SunatStringUtils.lpad((String) contingente.get("codTpi"), 4, ' ');
					String codigoPaisOrigen = (String) contingente.get("codPaisOrigen");
					if (codigoTPI.trim().equals("812") ) {
						PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
						boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codigoTPI, codigoPaisOrigen);
						if (existePuerto){
							codigoPaisOrigen = "UE";
						} 

					}
					String clave = numeroPartida + "-" + codigoTPI + "-" + codigoPaisOrigen;
					List<Map<String, Object>> contingentes = contingentesCache.get(clave);
					if (contingentes == null) {
						contingentes = new ArrayList<Map<String, Object>>();
						contingentesCache.put(clave, contingentes);
					}
					contingentes.add(contingente);
				}
			}
			if (!CollectionUtils.isEmpty(contingentesCache)) {//RMC RIN-P47
				/// OJOOOO RSERRANOV ..... OJO
			    variablesIngreso.put("contingentesCache", contingentesCache);
		    }
	
			if (!CollectionUtils.isEmpty(contingentesCache)){
			 
				Iterator it = contingentesCache.entrySet().iterator();
				consultaBuilder = new StringBuilder();
				adicionados = new ArrayList<String>();
				while (it.hasNext()) {
					Map.Entry e = (Map.Entry)it.next();
					Map<String,Object> mapTmp =  ((List<Map<String, Object>>) e.getValue()).get(0);
					String codTpi = SunatStringUtils.lpad((String) mapTmp.get("codTpi"), 4, ' ');
					String codPaisOrigen = (String) mapTmp.get("codPaisOrigen");
					if (codTpi.trim().equals("812") ) {
						PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
						boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codTpi, codPaisOrigen);
						if (existePuerto){
							codPaisOrigen = "UE";
						} 
					}
					
					String numGrupoCont = SunatStringUtils.lpad(mapTmp.get("numGrupoCont").toString(),4,' ');//ES BIGDECIMAL
					String clave = codTpi + codPaisOrigen + numGrupoCont;
					if(!adicionados.contains(clave)){
						consultaBuilder.append(clave).append(",");
						adicionados.add(clave);
					}
				}
				if(adicionados.size()>0){
					//consultamos a base de datos
					consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
					Map<String,Object> paramsContValid=new HashMap<String,Object>();
					
					if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
						paramsContValid.put("fechIngsi", SunatDateUtils.getCurrentDate());
					} else {
						paramsContValid.put("fechIngsi", declaracion.getDua().getFecdeclaracion());
					}
					paramsContValid.put("DOCUMENTO_LIST", consultaBuilder.toString());
					List<Map<String,Object>> listContValidFacts=contValidDAO.joinContCampoFindByMapFull(paramsContValid);
					for (Map<String, Object> ContFact : listContValidFacts) {
						String codigoTPI = SunatStringUtils.lpad((String) ContFact.get("codTpi"), 4, ' ');
						String codigoPaisOrigen = (String) ContFact.get("codPaisOrigen");
						if (codigoTPI.trim().equals("812") ) {
							PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
							boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codigoTPI, codigoPaisOrigen);
							if (existePuerto){
								codigoPaisOrigen = "UE";
							} 
						}
						String numGrupoCont = SunatStringUtils.lpad(ContFact.get("numGrupoCont").toString(),4,' ');
						String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
						List<Map<String, Object>> contvalids = null;
							contvalids = ListValidCamposCache.get(clave);
							if (contvalids == null) {
								contvalids = new ArrayList<Map<String, Object>>();
									ListValidCamposCache.put(clave, contvalids);
									listValidCampos.add(ContFact);
							}
						contvalids.add(ContFact);
					}
					
					//Para el alcohol
					paramsContValid=new HashMap<String,Object>();
					if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
						paramsContValid.put("fechIngsi", SunatDateUtils.getCurrentDate());
					} else {
						paramsContValid.put("fechIngsi", declaracion.getDua().getFecdeclaracion());
					}
					paramsContValid.put("codCampo", "20");
					
					paramsContValid.put("DOCUMENTO_LIST", consultaBuilder.toString());
					listContValidFacts=contValidDAO.joinContCampoFindByMapFull(paramsContValid);
					for (Map<String, Object> ContFact : listContValidFacts) {
						String codigoTPI = SunatStringUtils.lpad((String) ContFact.get("codTpi"), 4, ' ');
						String codigoPaisOrigen = (String) ContFact.get("codPaisOrigen");
						if (codigoTPI.trim().equals("812") ) {
							PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
							boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codigoTPI, codigoPaisOrigen);
							if (existePuerto){
								codigoPaisOrigen = "UE";
							} 
						}
						String numGrupoCont = SunatStringUtils.lpad(ContFact.get("numGrupoCont").toString(),4,' ');
						String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
						List<Map<String, Object>> contvalids = null;
							contvalids = listFactEquiAlcoholCache.get(clave);
							if (contvalids == null) {
								contvalids = new ArrayList<Map<String, Object>>();
								listFactEquiAlcoholCache.put(clave, contvalids);
								listValidPorAlcohol.add(ContFact);
							}
						contvalids.add(ContFact);
					}
					
					
					
				} 
				if (!CollectionUtils.isEmpty(ListValidCamposCache)) {//RMC RIN-P47
					/// OJOOOO RSERRANOV ..... OJO
					variablesIngreso.put("ListValidCamposCache", ListValidCamposCache);
			    }
				if (!CollectionUtils.isEmpty(listFactEquiAlcoholCache)) {//RMC RIN-P47
					/// OJOOOO RSERRANOV ..... OJO
					variablesIngreso.put("listFactEquiAlcoholCache", listFactEquiAlcoholCache);
			    }
								
			}
			
			// vERIFICAR SI QUEREMOS RETORNAR TODOS LOS DATOS.
			mapRespuesta.put("listJoinContingente", listJoinContingente);
			mapRespuesta.put("listValidPorAlcohol", listValidPorAlcohol);
			mapRespuesta.put("listValidCampos", listValidCampos);

		return mapRespuesta;
	}
 

	/**
 * Realiza la validacion del manifiesto para la realizacion de los contingentes, en el proceso de diligencia de despacho
 * 
 * @author olunar - 2012-05-10
 * 
 * @param declaracion
 * @param tipoDiligencia
 * 
 * @return List<Map<String, String>>
 */
	public List<Map<String, String>> validarManifiestoDilig(Declaracion declaracion, String tipoDiligencia) {

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

		/*
		 * 1. Que la mercanc�a ya se encuentre en territorio peruano. Por lo tanto se validar� el manifiesto seg�n lo siguiente : - El
		 * Manifiesto se encuentra registrado:
		 */
		String annManif = SunatStringUtils.substringFox(declaracion.getDua().getManifiesto().getAnnmanif(), 1, 4);
		/*Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio("01", declaracion.getDua().getManifiesto().getCodmodtransp(),
				declaracion.getDua().getCodaduanaorden(), SunatNumberUtils.toInteger(annManif), declaracion.getDua().getManifiesto().getNummanif(),
				true);*/
		
		Manifiesto manifiesto = ((ManifiestoService)this.fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio("01", declaracion.getDua().getManifiesto().getCodmodtransp(),
				declaracion.getDua().getCodaduanaorden(), SunatNumberUtils.toInteger(annManif), declaracion.getDua().getManifiesto().getNummanif(),
				true);

		/*
		 * Si el manifiesto no se encuentra registrado, se registrar� el siguiente error : 00121
		 */
		if (manifiesto == null) {
			// CONTINGENTE SOLICITADO NO PERMITIDO, EL MANIFIESTO NO SE ENCUENTRA REGISTRADO
			listError.add(ResponseMapManager.getErrorResponseMap("00121", MSG_00121));
		} else {

			/*
			 * Si es de la v�a de transporte a�rea o mar�tima, el manifiesto declarado debe contar con nota de tarja registrada
			 */
			String codViaTrans = declaracion.getDua().getManifiesto().getCodmodtransp();

			if (Constants.COD_VIA_TRANSPORTE_AEREA.equals(codViaTrans) || Constants.COD_VIA_TRANSPORTE_MARITIMO.equals(codViaTrans)) {

				Integer contadorTarja = 0;
				boolean esTransmitidoNSIGAD = !(manifiesto instanceof Mcdage);

				if (esTransmitidoNSIGAD && Constants.COD_VIA_TRANSPORTE_MARITIMO.equals(codViaTrans)) {
					/*
					 * Si es v�a mar�tima y el manifiesto fue transmitido con el NSIGAD, se busca que exista al menos un registro en la
					 * tabla CAB_MANIFIESTO filtrando por las columnas COD_ADUANA, ANN_MANIFIESTO, NUM_MANIFIESTO, COD_VIA y relacionandose
					 * con la tabla OPERASOCMANIF, filtrando por las columnas COD_TIPENVIO (constante '2') y IND_DEL (constante '0').
					 */
					Map<String, Object> paramsMap = new HashMap<String, Object>();
					paramsMap.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
					paramsMap.put("tipoEnvio", "2");
					paramsMap.put("indicadorEliminacion", IND_REGISTRO_ACTIVO);
					//paramsMap.put("orderByClause", "FEC_INI_OPERA desc");
					
					// Inicio: PAS20145E220000337 - rcontreras
					/* se comenta para usar fabrica de servicios */
					//List<DocumentoOABL> lista = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(paramsMap);
					List<DocumentoOABL> lista = ((DocumentoOAManifiestoValidacionService )this.fabricaDeServicios.
													getService("manifiesto.documentoOAManifiestoValidacionService")).
													obtenerOperacionAsociadaManifiestoByParameterMap(paramsMap);
					// Fin: PAS20145E220000337 - rcontreras 
					
					
					contadorTarja = lista.size();
					/*
					if (contadorTarja > 0) {
						DocumentoOABL docOabl = (DocumentoOABL)lista.get(0);
						if(docOabl.getFechaDeInicioDeOperacion().after(declaracion.getDua().getFecdeclaracion()))
							listError.add(ResponseMapManager.getErrorResponseMap("08809", MSG_08809));
					}
					*/
				} else if (!esTransmitidoNSIGAD) {
					/*
					 * Si es v�a mar�tima o a�rea y el manifiesto fue transmitido con el actual SIGAD, se busca que exista al menos un
					 * registro en la tabla OPERACARGA filtrando por las columnas ANNO, NUME_MC, VIA_TRANS, CODI_ADUAN y COD_TIPOPERAC
					 * (constante '2')
					 */
					OperaCargaCriteria cargaCriteria = new OperaCargaCriteria();
					OperaCargaCriteria.Criteria criteria = cargaCriteria.createCriteria();
					criteria.andAnnoEqualTo(manifiesto.getAnioManifiesto().toString().substring(2, 4));
					criteria.andNumeMcEqualTo(manifiesto.getNumeroManifiesto());
					//amancilla que raro que funcione en produccion criteria.andViaTransEqualTo(manifiesto.getViaTransporte().toString());
					criteria.andViaTransEqualTo(manifiesto.getViaTransporte().getCodDatacat().toString());

					criteria.andCodiAduanEqualTo(manifiesto.getAduana().getCodDatacat());
					criteria.andCodTipoperacEqualTo("2");
					//contadorTarja = getOperaCargaDAO().countByCriteria(cargaCriteria);
					//amancilla

					Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds."+ declaracion.getCodaduana()));
					List<OperaCarga> lista = operaCargaDAO.selectByOperaCargaCriteria(cargaCriteria);
					swapperDatasource.swap(o);
					
					contadorTarja = lista.size();
					/*
					if (contadorTarja > 0) {
						OperaCarga operaCarga = (OperaCarga)lista.get(0);						
						if(operaCarga.getFecOperac().after(declaracion.getDua().getFecdeclaracion()))
							listError.add(ResponseMapManager.getErrorResponseMap("08809", MSG_08809));
					}
					*/
				}

				if (contadorTarja == 0) {
					// CONTINGENTE SOLICITADO NO PERMITIDO, EL MANIFIESTO DEBE CONTAR CON NOTA DE TARJA EFECTUADA POR EL TRANSPORTISTA
					listError.add(ResponseMapManager.getErrorResponseMap("08225", MSG_08225));
				}
				// VIA_TRANSPORTE_CARRETERA = VIA_TRANSPORTE_TERRESTRE
			} else if (Constants.COD_VIA_TRANSPORTE_CARRETERA.equals(codViaTrans)) {

				//Map<String, ?> mapResponse = validaManifiestoConFechaLlegada(declaracion);
				Map<String, Object> mapResponse = new HashMap<String, Object>();
				if (!CollectionUtils.isEmpty(mapResponse)) {
					/*
					 * Si el manifiesto no tiene registrada la fecha de llegada, se registra el error 08066
					 */
					listError.add(ResponseMapManager.getErrorResponseMap("08066", MSG_08066));
				}
			} else {
				/*
				 * Para otra v�a distinta a la a�rea, mar�tima o terrestre, no se permite declarar acogi�ndose a contingente arancelario, se
				 * registrar� el error : 8808
				 */
				// V�A DE TRANSPORTE NO PERMITIDA PARA ACOGERSE A CONTINGENTE ARANCELARIO
				listError.add(ResponseMapManager.getErrorResponseMap("08808", MSG_08808));
			}
		}

		return listError;
	}
	
	/**
	 * Val dato contingente.
	 * 
	 * @param mapCampValid Map<String,Object>
	 * @param numpartnalad String
	 * @param cntsolcont BigDecimal
	 * @param fecEmision Date
	 * @param nroCertOrig String
	 * @param codFFCO String
	 * @param codPaisOrigen String
	 * @return cadena obteniendo Error o OK
	 */
	public String valDatoContingente(Map<String, Object> mapCampValid, String numpartnalad, BigDecimal cntsolcont, Date fecEmision,
			String nroCertOrig, String codFFCO, String codPaisOrigen, BigDecimal cntporalcohol ) {
		String result = "OK";
		@SuppressWarnings("unused")
		boolean opcional = false;
		String tipoMsg = "E";
		String codCampo = (String) mapCampValid.get("codCampo");
		
		log.info(" valDatoContingente listErr codCampo "+codCampo);
		
		if ("02".equals((String) mapCampValid.get("codTipoValid"))) {
			opcional = true;
			tipoMsg = "W";
		}
		if ("01".equals(codCampo)) {
			if (!SunatStringUtils.isEmptyTrim(numpartnalad)) {
				Integer longitud = SunatNumberUtils.toInteger(mapCampValid.get("numLongitud"));
				if (numpartnalad.length() == longitud) {
					result = "OK";
				} else {
					result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + numpartnalad;
				}
			} else {
				result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + numpartnalad;
			}
		} else if (SunatStringUtils.include(codCampo, new String[] { "02", "03", "04" })) {
			if (SunatNumberUtils.isGreaterThanZero(cntsolcont)) {
				result = "OK";
			} else {
				result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + cntsolcont.setScale(3).doubleValue();
			}
		} else if ("05".equals(codCampo)) {
			if (!SunatStringUtils.isEmptyTrim(nroCertOrig)) {
				result = "OK";
			} else {
				result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + nroCertOrig;
			}
		} else if ("06".equals(codCampo)) {
			if (fecEmision != null) {
				result = "OK";
			} else {
				result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + fecEmision;
			}
		} else if ("07".equals(codCampo)) {
			Map<String, Object> paramsPruperso = new HashMap<String, Object>();
			
			paramsPruperso.put("regis", (codFFCO == null ? " " : SunatStringUtils.lpad(codFFCO, 5, ' ')));
			paramsPruperso.put("codPais", codPaisOrigen);
			paramsPruperso.put("fechCertiOrigen", SunatDateUtils.getIntegerFromDate(fecEmision));
			List<Map<String, Object>> listJoinPruperso = prupersoDAO.joinPrupersoAndPrufunciFindByMap(paramsPruperso);

			if (listJoinPruperso != null && !listJoinPruperso.isEmpty()) {
				result = "OK";
			} else {
				FechaBean fb = new FechaBean();
				fb.setFecha(fecEmision);
				result = tipoMsg + "- DATO ENVIADO: " + (String) mapCampValid.get("desNomcampo") + " = " + codFFCO
						+ " NO VIGENTE EN LA FECHA DE EMISION DEL CERT. ORIGEN " + fb.getFormatDate("dd/MM/yyyy");
			}
		} else if ("20".equals(codCampo)) {
			
			log.info(" valDatoContingente listErr codCampo "+codCampo);
			
			log.info(" valDatoContingente listErr cntporalcohol "+cntporalcohol);
			
			if (SunatNumberUtils.isGreaterThanZero(cntporalcohol)) {
				result = "OK";
			} else {
				// Se adiciona el tipo de error para el mensaje
				result = tipoMsg + "35426";
			}
		}
		return result;
	}

	/**
	 * Val plazo contingente.
	 * 
	 * @param contplazo Contplazo
	 * @param fechaNumeracion Date
	 * @param fechaCertiOri Date
	 * @param fechaFactura Date
	 * @param numSerie Integer
	 * @return el string
	 */
	public String valPlazoContingente(Contplazo contplazo, Date fechaNumeracion, Date fechaCertiOri, Date fechaFactura, Integer numSerie) {
		Date doc_ref = null;
		Date doc_numero = null;
		String ctplazo = contplazo.getCodTipoPlazo();// (String)mapCPlazoValid.get("cod_tipo_plazo");
		String cuplazo = contplazo.getCodUndPlazo();// (String)mapCPlazoValid.get("cod_und_plazo");

		if(fechaCertiOri == null)
			fechaCertiOri = SunatDateUtils.getDefaultDate();

		if(fechaFactura == null)
			fechaFactura = SunatDateUtils.getDefaultDate();
		
		Date fd1 = fechaNumeracion;
		Date fd2 = fechaCertiOri;
		Date fd3 = fechaFactura;
		Date fd4 = SunatDateUtils.getCurrentDate();

		int plazo = contplazo.getCntPlazo().intValue();// (Integer)mapCPlazoValid.get("cnt_plazo");

		if ("D1".equals(contplazo.getCodDocRefe())) {
			doc_ref = fd1;
		} else if ("D2".equals(contplazo.getCodDocRefe())) {
			if (SunatDateUtils.isDefaultDate(fd2)) {
				return "NO HA ENVIADO DATOS DEL CERTIFICADO DE ORIGEN DE LA SERIE " + numSerie;
			} else {
				doc_ref = fd2;
			}
		} else if ("D3".equals(contplazo.getCodDocRefe())) {
			if (SunatDateUtils.isDefaultDate(fd3)) {
				return "0903-NO HA ENVIADO DATOS DE LA FACTURA COMERCIAL PARA LA SERIE " + numSerie;
			} else {
				doc_ref = fd3;
			}
		} else if ("D4".equals(contplazo.getCodDocRefe())) {
			doc_ref = fd4;
		}

		if ("D1".equals(contplazo.getCodDocVali())) {
			doc_numero = fd1;
		} else if ("D2".equals(contplazo.getCodDocVali())) {
			if (SunatDateUtils.isDefaultDate(fd2)) {
				return "NO HA ENVIADO DATOS DEL CERTIFICADO DE ORIGEN DE LA SERIE " + numSerie;
			} else {
				doc_numero = fd2;
			}
		} else if ("D3".equals(contplazo.getCodDocVali())) {
			if (SunatDateUtils.isDefaultDate(fd3)) {
				return "0903-NO HA ENVIADO DATOS DE LA FACTURA COMERCIAL PARA LA SERIE " + numSerie;
			} else {
				doc_numero = fd3;
			}
		} else if ("D4".equals(contplazo.getCodDocVali())) {
			doc_numero = fd4;
		}

		int numDiasDif = 0;
		String result = "OK";
		if ("01".equals(cuplazo)) {
			if ("D01".equals(ctplazo)) {
				numDiasDif = SunatDateUtils.isDefaultDate(doc_numero) || SunatDateUtils.isDefaultDate(doc_ref) ? 0 : SunatDateUtils.getDifference(
						doc_numero, doc_ref, Calendar.DATE).intValue();

			} else if ("D02".equals(ctplazo)) {
				int numDias = SunatDateUtils.isDefaultDate(doc_numero) || SunatDateUtils.isDefaultDate(doc_ref) ? 0 : SunatDateUtils.getDifference(
						doc_numero, doc_ref, Calendar.DATE).intValue();

				if (SunatDateUtils.compareDate(doc_numero, doc_ref) >= 0) {
					List<String> feriados = new ArrayList<String>();
					Date dateUtil = SunatDateUtils.addUtilDay(doc_ref, numDias, feriados);
					int diasARestar = SunatDateUtils.isDefaultDate(dateUtil) || SunatDateUtils.isDefaultDate(doc_ref) ? 0 : (SunatDateUtils
							.getDifference(dateUtil, doc_ref, Calendar.DATE).intValue() - numDias);

					numDiasDif = numDias - diasARestar;
				} else {
					List<String> feriados = new ArrayList<String>();
					Date dateUtil = SunatDateUtils.addUtilDay(doc_numero, numDias, feriados);
					int diasARestar = SunatDateUtils.isDefaultDate(dateUtil) || SunatDateUtils.isDefaultDate(doc_numero) ? 0 : (SunatDateUtils
							.getDifference(dateUtil, doc_numero, Calendar.DATE).intValue() - numDias);

					numDiasDif = numDias - diasARestar;
				}
			} else
				return "TIPO DE PLAZO A VALIDAR DE CONTINGENTE NO DEFINIDO";
			if (numDiasDif > plazo) {
				return contplazo.getMsjInvPlazo();// (String)mapCPlazoValid.get("msj_inv_plazo");
			}
		} else if ("02".equals(cuplazo)) {
			Date fcalcproc;
			if ("A01".equals(ctplazo)) {
				Calendar cRef = Calendar.getInstance();
				cRef.setTime(doc_ref);
				cRef.add(Calendar.YEAR, 1 + plazo);
				cRef.set(Calendar.MONTH, Calendar.JANUARY);
				cRef.set(Calendar.DATE, 1);
				fcalcproc = cRef.getTime();
			} else if ("A02".equals(ctplazo)) {
				Calendar cRef = Calendar.getInstance();
				cRef.setTime(doc_ref);
				cRef.add(Calendar.YEAR, plazo);
				fcalcproc = cRef.getTime();
			} else
				return "TIPO DE PLAZO A VALIDAR DE CONTINGENTE NO DEFINIDO";
			if (SunatDateUtils.compareDate(fcalcproc, doc_numero) < 0)
				return contplazo.getMsjInvPlazo();// (String)mapCPlazoValid.get("msj_inv_plazo");
		} else
			return "UNIDAD DE PLAZO DE CONTINGENTE NO DEFINIDO";
		return result;
	}

	/**
	 * Determina si el codigo 08805 es el unico error en la lista.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param numEnvio Long
	 * @return true si 08805 es el unico codigo de error o esta vacio.
	 */
	public boolean is8805UnicoError(List<Map<String, String>> listError, Long numEnvio) {

		if (listError != null) {
			if (CollectionUtils.isEmpty(listError))
			{	return false;
			}

			boolean result=false;
			for (Map<String, String> map : listError) {
				
				if ( map != null || !map.isEmpty() ) {
					String errorCode = map.get("codError") == null ? "": map.get("codError").toString();
					if ("08805".equals(errorCode))
					{result=true;}
					else if(!errorCode.startsWith("09"))
					{result=false;break;}
				} 
			}
			return result;
		} else {
			try {
				Map<String, Object> paramsMap = new HashMap<String, Object>();
				paramsMap.put("numeroTicket", numEnvio);
				paramsMap.put("anhoEnvio", SunatNumberUtils.getCurrentYear());
				List<EnvErrorCabBean> listErrores = envErrorCabDAO.listErrorCabByParameterMap(paramsMap);

				if (CollectionUtils.isEmpty(listErrores))
					return false;

				for (EnvErrorCabBean error : listErrores) {
					if (!"08805".equals(error.getCodError()) && "E".equals(error.getCodTipalerta()))
						return false;
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return false;
	}

	/**
	 * Para las series de las declaraciones de importaci�n urgentes o excepcionales (normales), se verificar� los datos enviados en la
	 * orden, para determinar si se esta solicitando el acogimiento a contingente arancelario. El Tipo de Margen necesariamente debe tener
	 * el valor �5�, caso contrario no se trata de una solicitud de contingente arancelario.
	 * 
	 * @param codTpi Integer
	 * @param codtipomargen String
	 * @return true, Si codTpi contiene valor diferente de 0 y codtipomargen es igual a 5
	 */
	public boolean solcitaContingente(Integer codTpi, String codtipomargen) {
		boolean rpta = false;
		codtipomargen =  (codtipomargen != null && !codtipomargen.equals("")) ? codtipomargen.trim() : "";
		rpta = ((codTpi != null && codTpi != 0) && "5".equals(codtipomargen));
		return rpta;
	}

	/**
	 * Validar si solicita rectificar alg�n dato del contingente (TPI, partida, pa�s de origen, peso neto, unidades f�sicas o valor FOB).
	 * 
	 * @param serieNew DatoSerie
	 * @param serieOld DatoSerie
	 * @return true, if successful
	 * @return
	 */
	public boolean solicitaRectificarContingente(DatoSerie serieNew, DatoSerie serieOld , List<Map<String,Object>> listValidPorAlcohol) {


		if (!SunatStringUtils.isEqualTo(  (serieNew.getCodtipomarge() == null?"": serieNew.getCodtipomarge().trim()), ( serieOld.getCodtipomarge() == null?"": serieOld.getCodtipomarge().trim())) )
			return true;
		
		if (!SunatNumberUtils.isEqual(serieNew.getCodconvinter(), serieOld.getCodconvinter()))
			return true;

		if (!SunatNumberUtils.isEqual(serieNew.getNumpartnandi(), serieOld.getNumpartnandi()))
			return true;

		if (!serieNew.getCodconvinter().equals(812)) { //VRD bug 20851
			if (!SunatStringUtils.isEqualTo(serieNew.getCodpaisorige(), (serieOld.getCodpaisorige() == null?"": serieOld.getCodpaisorige() )))
				return true;
		}
		if (!SunatNumberUtils.isEqual(serieNew.getCntpesoneto(), serieOld.getCntpesoneto()))
			return true;

		if (!SunatStringUtils.isEqualTo(serieNew.getCodunifis(),(serieOld.getCodunifis() == null?"": serieOld.getCodunifis())))
			return true;

		if (!SunatNumberUtils.isEqual(serieNew.getCntunifis() , serieOld.getCntunifis()))
			return true;
		//PAS20165E220200022
        BigDecimal margenMonto = new BigDecimal(1);
        BigDecimal difMonto = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(serieNew.getMtofobdol()), serieOld.getMtofobdol());
        if (!SunatNumberUtils.isLessThanParam(difMonto, margenMonto))           
               return true;

		if ((!SunatNumberUtils.isEqual(serieNew.getPoralcohol(), serieOld.getPoralcohol()) &&( ! CollectionUtils.isEmpty(listValidPorAlcohol) )))
			return true;

		return false;
	}

	/**
	 * Determina si se esta rectificando las cantidades de los contingentes.
	 * 
	 * @param serieNew DatoSerie
	 * @param serieOld DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @return true, if is rectifica cant contingentes
	 */
	public boolean isRectificaCantContingentes(DatoSerie serieNew, DatoSerie serieOld, Map<String, Object> mapDatosCont, List<Map<String,Object>> listValidPorAlcohol) {

		String cundcont = (String) mapDatosCont.get("codUndCont");

		if (Constants.COD_UND_UND.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return true;

		if (Constants.COD_UND_KGS.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntpesoneto(), serieOld.getCntpesoneto()))
			return true;

		//if (Constants.COD_UND_USD.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getMtofobdol(), serieOld.getMtofobdol()))
			//return true;
		
		 BigDecimal margenMonto = new BigDecimal(1);
	        BigDecimal difMonto = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(serieNew.getMtofobdol()), serieOld.getMtofobdol());
	        if (Constants.COD_UND_USD.equals(cundcont) &&!SunatNumberUtils.isLessThanParam(difMonto, margenMonto))           
	               return true;
		
		if (Constants.COD_UND_TON.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntpesoneto(), serieOld.getCntpesoneto()))
			return true;

		
		if (Constants.COD_UND_PAR.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return true;

		
		if (Constants.COD_UND_LIT.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return true;
		
		//RSV Se agrega modificacion de unidades porq cambian cantidades y debe validarser el monto total
		if (Constants.COD_UND_UND.equals(cundcont) && !SunatStringUtils.isEqualTo(serieNew.getCodunifis(), serieOld.getCodunifis()))
			return true;

		if (Constants.COD_UND_PAR.equals(cundcont) && !SunatStringUtils.isEqualTo(serieNew.getCodunifis(), serieOld.getCodunifis()))
			return true;

		if (Constants.COD_UND_TON.equals(cundcont) && !SunatStringUtils.isEqualTo(serieNew.getCodunifis(), serieOld.getCodunifis()))
			return true;

		if (Constants.COD_UND_LIT.equals(cundcont) && !SunatStringUtils.isEqualTo(serieNew.getCodunifis(), serieOld.getCodunifis()))
			return true;
		//RSV
		//INICIO BUG 20851
		if ((!SunatNumberUtils.isEqual(serieNew.getPoralcohol(), serieOld.getPoralcohol()) &&( ! CollectionUtils.isEmpty(listValidPorAlcohol) )) || serieOld.getPoralcohol().compareTo(java.math.BigDecimal.ZERO)==0)
			return true;
		//FIN BUG 20851
		return false;
	}

	/**
	 * Obtiene la cantidad de contingente registrado en la numeracion.
	 * 
	 * @param serieNew DatoSerie
	 * @param serieOld DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @return  rectifica cant contingentes
	 */
	public BigDecimal getRectificaCantContingentes(DatoSerie serieNew, DatoSerie serieOld, Map<String, Object> mapDatosCont) {

		String cundcont = (String) mapDatosCont.get("codUndCont");
		//RMC RIN-P47
		if (!serieNew.getCodconvinter().equals(serieOld.getCodconvinter()) || !serieNew.getCodtipomarge().equals(serieOld.getCodtipomarge())) {
			//Si la serie recien solicita contingente, la cantidad solicitada anteriormente debe ser cero
			return new BigDecimal(0);
		}

		if (Constants.COD_UND_UND.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return serieOld.getCntunifis();

		if (Constants.COD_UND_KGS.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntpesoneto(), serieOld.getCntpesoneto()))
			return serieOld.getCntpesoneto();

		if (Constants.COD_UND_USD.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getMtofobdol(), serieOld.getMtofobdol()))
			return serieOld.getMtofobdol();

		if (Constants.COD_UND_TON.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntpesoneto(), serieOld.getCntpesoneto()))
			return serieOld.getCntpesoneto();

		
		if (Constants.COD_UND_PAR.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return serieOld.getCntunifis();

		if (Constants.COD_UND_LIT.equals(cundcont) && !SunatNumberUtils.isEqual(serieNew.getCntunifis(), serieOld.getCntunifis()))
			return serieOld.getCntunifis();		
		
		return null;
	}

	/**
	 * Obtiene la cantidad de contingente registrado en la numeracion.
	 * 
	 * @param serieNew DatoSerie
	 * @param serieOld DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @return  rectifica cant contingentes
	 */
	public BigDecimal getRectificaCantContMapa(Map<String, Object> mapDesDataAnt , Map<String, Object> mapaSerieRectifica) {

		String cundcont = (String) mapaSerieRectifica.get("codUndCont");

		/*BigDecimal margenMonto = new BigDecimal(1);
	    BigDecimal difMonto = SunatNumberUtils.absoluteDiference(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_UNIFIS"))),
	        		SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS")));
*/
		if (Constants.COD_UND_UND.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_UNIFIS"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS"));

		if (Constants.COD_UND_KGS.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_PESO_NETO"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO"));
 
		if (Constants.COD_UND_UND.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_PESO_NETO"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO"));

		if (Constants.COD_UND_USD.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_PESO_NETO"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("getMtofobdol")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("getMtofobdol"));

		if (Constants.COD_UND_TON.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_PESO_NETO"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_PESO_NETO"));

		if (Constants.COD_UND_PAR.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_UNIFIS"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS"));
		
		if (Constants.COD_UND_LIT.equals(cundcont) && SunatNumberUtils.isGreaterThanParam(Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapDesDataAnt.get("CNT_UNIFIS"))),
	    		Utilidades.validaVacioRetornaBigDecimal(SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS")))))
			return SunatNumberUtils.toBigDecimal( mapaSerieRectifica.get("CNT_UNIFIS"));
		
		return SunatNumberUtils.toBigDecimal( 0);
	}
	/**
	 * Obtiene la cantidad de contingente registrado en la numeracion.
	 * 
	 * @param serie DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @return  cant contingente solicitado
	 */
	public BigDecimal getCantContingenteSolicitado(DatoSerie serie, Map<String, Object> mapDatosCont , List<Map<String,Object>> listValidPorAlcohol) {

		String codUnidadMedida = (String) mapDatosCont.get("codUndCont");
		BigDecimal factConv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactConv"));
		BigDecimal factEquiv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactEqui"));
		BigDecimal cantSolCont = BigDecimal.ZERO;
		
		if (Constants.COD_UND_KGS.equals(codUnidadMedida)) {
			cantSolCont = serie.getCntpesoneto();
		} else if (Constants.COD_UND_UND.equals(codUnidadMedida)) {			
				
				if ( serie.getCodunifis().equals("U") ) {
					cantSolCont = serie.getCntunifis();
				} else if ( serie.getCodunifis().equals("12U") ) {
					cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("12"));
				} else if ( serie.getCodunifis().equals("U2") ) {
					cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("100"));
				} else if ( serie.getCodunifis().equals("U3") ) {
					cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("1000"));
				} else if ( serie.getCodunifis().equals("U6") ) {
					cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("1000000"));
				} else {
					//Que sucede cuando no esta registrado
					cantSolCont = serie.getCntunifis();
				}
			
		} else if (Constants.COD_UND_USD.equals(codUnidadMedida)) {
			cantSolCont = serie.getMtofobdol();
		} else if (Constants.COD_UND_TON.equals(codUnidadMedida)) {
			cantSolCont = serie.getCntpesoneto().divide(SunatNumberUtils.toBigDecimal("1000.00"));
		} else if (Constants.COD_UND_PAR.equals(codUnidadMedida)) {
			
			if ( serie.getCodunifis().equals("2U") ) {
				cantSolCont = serie.getCntunifis();
			} else if (serie.getCodunifis().equals("2U6") ) {
				cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("1000000.00"));
			} else {
				cantSolCont = serie.getCntunifis();
			}
			
		} else if (Constants.COD_UND_LIT.equals(codUnidadMedida)) {
			
			if ( serie.getCodunifis().equals("L") ) {
				cantSolCont = serie.getCntunifis();
			} else if (serie.getCodunifis().equals("L6") || serie.getCodunifis().equals("L 6")) {
				cantSolCont = serie.getCntunifis().multiply(SunatNumberUtils.toBigDecimal("1000000.00"));
			} else {
				cantSolCont = serie.getCntunifis();
			}
		}
		//INICIO PAS20155E220200016
		//factEquiv=SunatNumberUtils.toBigDecimal(0);
		if (factEquiv==null|| factEquiv.equals(0))
			factEquiv=SunatNumberUtils.toBigDecimal(1);
		if (factConv==null|| factConv.equals(0))
			factConv=SunatNumberUtils.toBigDecimal(1);
		
			
    	cantSolCont = (cantSolCont.multiply(factConv)).multiply(factEquiv);		
        // Se valida si se considera el factoequivalente de porcentaje de alcohol
		if ( ! CollectionUtils.isEmpty(listValidPorAlcohol) ){
			boolean seIndicaPorcAlcohol = ( serie.getPoralcohol() != null && serie.getPoralcohol().compareTo(java.math.BigDecimal.ZERO) > 0 ) ; 
            if ( seIndicaPorcAlcohol  ) {
           	 	factEquiv =  serie.getPoralcohol().divide(SunatNumberUtils.toBigDecimal("100.00"));
           	 	cantSolCont = (cantSolCont.multiply(factConv)).multiply(factEquiv);
            }  
        
		}
		
			

		return cantSolCont;
		// Fin: PAS20145E220000337 - rcontreras
	}

	/**
	 * Obtiene la fecha de la factura de la serie dada por numSerie.
	 * 
	 * @param numSerie int
	 * @param declaracion Declaracion
	 * @return  fecha factura
	 */
	public Date getFechaFactura(int numSerie, Declaracion declaracion) {
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (serieItem.getNumserie() == numSerie)
							return factura.getFecfactura();
					}
				}
			}
		}
		return null;
	}

	/**
	 * Valida si la CTA CTE tiene formato con la Garantia 160.
	 * 
	 * @param codGarantia String
	 * @return true, if successful
	 */
	public boolean tieneGarantia160(String codGarantia) {

		if (!SunatStringUtils.isEmptyTrim(codGarantia) && SunatStringUtils.length(codGarantia) == 18) {
			return true;
		}

		return false;
	}


	/**
	 * Valida si se realizo la cancelacion del pago de la DUA (Validando garantia).
	 * 
	 * @param declaracionBD Declaracion
	 * @param tipoCance String
	 * @return true, if is efectuado pago
	 */
	public boolean isEfectuadoPago(Declaracion declaracionBD, String tipoCance) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numCorredoc", declaracionBD.getDua().getNumcorredoc());
		DeudaDocum deuda = new DeudaDocum();
		deuda.setNumCorredoc(declaracionBD.getDua().getNumcorredoc());
	//	List<DetPagodua> listPagoDua = detPagoDuaDAO.selectPagoByParams(params);
		List<DeudaDocum> listDeudaDua = deudaDocumDAO.selectByDocumento(deuda); // . .findPendientePago(numCorreDoc)
		boolean result = false;

		if (CollectionUtils.isEmpty(listDeudaDua))
			return result;

		for (DeudaDocum deudadocum : listDeudaDua) {

			//Date fecPago = deudadocum. .getFecPago();
			//PAS20165E220200124 RSERRANOV SE MODIFICA CUANDO SE COBRAN INTERESE EL MONTO PAGADO ES MAYOR A LA DEUDA
			if(deudadocum.getCodEstpago().equals("P") &&  SunatNumberUtils.isGreaterOrEqualsThanParam(deudadocum.getMtoPagado(), deudadocum.getMtoDeuda()) ) {
				result = true;
			} else {
				// Si alguno no cumple con la condicion de pago
				return false;
			}
		}

		return result;
	}

	/**
	 * Valida si se ha efectuado el pago de la declaraci�n. (DET_PAGODUA.FEC_PAGO sin valor y DET_PAGODUA.COD_TIPCANCE igual a 74).
	 * 
	 * @param declaracionBD Declaracion
	 * @param tipoCance String
	 * @return  Si no se ha realizado el pago
	 */
	public boolean isNotEfectuadoPago(Declaracion declaracionBD, String tipoCance) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numCorredoc", declaracionBD.getDua().getNumcorredoc());
		DeudaDocum deuda = new DeudaDocum();
		deuda.setNumCorredoc(declaracionBD.getDua().getNumcorredoc());
		List<DeudaDocum> listDeudaDua = deudaDocumDAO.selectByDocumento(deuda); // . .findPendientePago(numCorreDoc)
		boolean result = true;

		if (CollectionUtils.isEmpty(listDeudaDua))
			return result;

		for (DeudaDocum deudadocum : listDeudaDua) {

			//PAS20165E220200124 RSERRANOV SE MODIFICA CUANDO SE COBRAN INTERESE EL MONTO PAGADO ES MAYOR A LA DEUDA
			if ( deudadocum.getCodEstpago().equals("P") &&  SunatNumberUtils.isGreaterOrEqualsThanParam(deudadocum.getMtoPagado(), deudadocum.getMtoDeuda()) ) { 
				//result = true;
				return false;
			} else {
				// Si alguno no cumple con la condicion de pago
				result = true;
			}
		}
		

		return result;
	}

	/**
	 * Valida si se ha efectuado el pago de la declaraci�n. No se encuentre en la tabla DET_PAGODUA, o de encontrarse, no tenga valor el
	 * campo FEC_PAGO.
	 * 
	 * @param declaracionBD Declaracion
	 * @return  Si no se ha realizado el pago
	 */
	public boolean isNotEfectuadoPago(Declaracion declaracionBD) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numCorredoc", declaracionBD.getDua().getNumcorredoc());
		List<DetPagodua> listPagoDua = detPagoDuaDAO.selectPagoByParams(params);
		boolean result = true;

		if (CollectionUtils.isEmpty(listPagoDua))
			return result;
		else {
			for (DetPagodua detPagodua : listPagoDua) {

				Date fecPago = detPagodua.getFecPago();

				if (!SunatDateUtils.isDefaultDate(fecPago)) {
					return false;
				}
			}
		}

		return result;
	}


	/**
	 * Obtiene el flag que indica que se puede validar contingente para esta DUA en Rectificacion En el caso del NSIGAD, es para cualquier
	 * modalidad de despacho.
	 * 
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 * @return true, if successful
	 */
	public boolean validaContingenteRectif(Declaracion declaracion, String codTransaccion) {
		if (codTransaccion.endsWith(COD_TRX_RECTIFICACION) || codTransaccion.endsWith(COD_TRX_DILIG_RECTIF) ) {
			return true;
		}
		return false;
	}

	/**
	 * Obtiene el flag que indica que se puede validar contingente para esta DUA en regularizacion En el caso del NSIGAD, es para la
	 * modalidad de despacho urgente o anticipada.
	 * 
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 * @return true, if successful
	 */
	public boolean validaContingenteRegul(Declaracion declaracion, String codTransaccion) {
		if (codTransaccion.endsWith("04") ||  codTransaccion.endsWith("05") || codTransaccion.endsWith("1005")) {
			if ((Constants.DESPACHO_URGENTE.equals(declaracion.getDua().getCodmodalidad()) || Constants.DESPACHO_ANTICIPADO.equals(declaracion
					.getDua().getCodmodalidad())))
				return true;
		}
		return false;
	}

	
	/**
	 * Obtiene el registro de la reserva.
	 * 
	 * @param mapDatosCont Map<String,Object>
	 * @param serie DatoSerie
	 * @param declaracion Declaracion
	 * @return  cont cta cte
	 */
	@SuppressWarnings("unchecked")
	public ContCtaCte getContCtaCte(Map<String, Object> mapDatosCont, DatoSerie serie, Declaracion declaracion) {

		ContCtaCteCriteria criteriaCtaCte = new ContCtaCteCriteria();
		ContCtaCteCriteria.Criteria criteria = criteriaCtaCte.createCriteria();

		
		if (mapDatosCont.get("numDoc") == null ) {
			mapDatosCont.put("numDoc", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));

		}
		if (mapDatosCont.get("annDoc") == null ) {
			mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
		}
		criteria.andNumDocEqualTo((String) mapDatosCont.get("numDoc"));
		criteria.andAnnDocEqualTo((String) mapDatosCont.get("annDoc"));
		criteria.andCodAduanaDocEqualTo(declaracion.getDua().getCodaduanaorden());
		criteria.andCodRegimenDocEqualTo(declaracion.getDua().getCodregimen());
		criteria.andNumSerieDocEqualTo(serie.getNumserie());
		/*branch ingreso 2011-029 hosorio inicio  15/07/2011 */
		//criteria.andCodTipoDocEqualTo("03");
		if(mapDatosCont.get("codTipoDoc")!=null)
			criteria.andCodTipoDocEqualTo((String)mapDatosCont.get("codTipoDoc"));
		if(mapDatosCont.get("codEstado")!=null)
			criteria.andCodEstadoEqualTo((String)mapDatosCont.get("codEstado"));

		if(mapDatosCont.get("agente") != null)
			criteria.andCodAgenteEqualTo((String)mapDatosCont.get("agente"));
		//criteria.andCodAgenteEqualTo(mapDatosCont.get("agente") != null ? (String) mapDatosCont.get("agente") : " ");
		/*branch ingreso 2011-029 hosorio fin  15/07/2011 */
		List<ContCtaCte> list = contCtaCteDAO.selectByContCtaCteCriteria(criteriaCtaCte);

		if (!CollectionUtils.isEmpty(list))
			return list.get(0);

		return null;
	}
	
	//glazaror... optimizacion 
	@SuppressWarnings("unchecked")
	public ContCtaCte getContCtaCte(Map<String, Object> mapDatosCont, Declaracion declaracion) {

		ContCtaCteCriteria criteriaCtaCte = new ContCtaCteCriteria();
		ContCtaCteCriteria.Criteria criteria = criteriaCtaCte.createCriteria();

		
		if (mapDatosCont.get("numDoc") == null ) {
			mapDatosCont.put("numDoc", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));

		}
		if (mapDatosCont.get("annDoc") == null ) {
			mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
		}
		criteria.andNumDocEqualTo((String) mapDatosCont.get("numDoc"));
		criteria.andAnnDocEqualTo((String) mapDatosCont.get("annDoc"));
		criteria.andCodAduanaDocEqualTo(declaracion.getDua().getCodaduanaorden());
		criteria.andCodRegimenDocEqualTo(declaracion.getDua().getCodregimen());
		//criteria.andNumSerieDocEqualTo(serie.getNumserie());
		/*branch ingreso 2011-029 hosorio inicio  15/07/2011 */
		//criteria.andCodTipoDocEqualTo("03");
		if(mapDatosCont.get("codTipoDoc")!=null)
			criteria.andCodTipoDocEqualTo((String)mapDatosCont.get("codTipoDoc"));
		if(mapDatosCont.get("codEstado")!=null)
			criteria.andCodEstadoEqualTo((String)mapDatosCont.get("codEstado"));

		if(mapDatosCont.get("agente") != null)
			criteria.andCodAgenteEqualTo((String)mapDatosCont.get("agente"));
		//criteria.andCodAgenteEqualTo(mapDatosCont.get("agente") != null ? (String) mapDatosCont.get("agente") : " ");
		/*branch ingreso 2011-029 hosorio fin  15/07/2011 */
		List<ContCtaCte> list = contCtaCteDAO.selectByContCtaCteCriteria(criteriaCtaCte);

		if (!CollectionUtils.isEmpty(list))
			return list.get(0);

		return null;
	}

	/**
	 * Obtiene la declaracion registrada en base de datos.
	 * 
	 * @param declaracionXml Declaracion
	 * @return  declaracion bd
	 */
	public Declaracion getDeclaracionBD(Declaracion declaracionXml) {
		NumdeclRef numdeclRef = declaracionXml.getNumdeclRef();
		return getDeclaracionService.getDeclaracion(numdeclRef.getCodaduana(), SunatNumberUtils.toInteger(numdeclRef.getNumcorre()), SunatNumberUtils
				.toInteger(numdeclRef.getAnnprese()), numdeclRef.getCodregimen());

	}
	
	public Declaracion getDeclaracionBD(Map<String, Object> params) {
//		NumdeclRef numdeclRef = declaracionXml.getNumdeclRef();
		return getDeclaracionService.getDeclaracion(params.get("COD_ADUANA").toString(), SunatNumberUtils.toInteger(params.get("NUM_DECLARACION").toString()),
				SunatNumberUtils.toInteger(params.get("ANN_PRESEN").toString()), params.get("COD_REGIMEN").toString());

	}

	/**
	 * Si es rectificacion/regularizacion verificamos si ya tiene asignado contingente.
	 * 
	 * @param declaracion Declaracion
	 * @param serie DatoSerie
	 * @return  contingente asignado
	 */
	public DatoSerie getContingenteAsignado(Declaracion declaracion, DatoSerie serie) {
		DatoSerie seriebd = new DatoSerie();
		for(DatoSerie serieRecti:declaracion.getDua().getListSeries()){
			if(serie.getNumserie().equals(serieRecti.getNumserie())){
				seriebd=serieRecti;
				break;
			}			
		}
		return seriebd;
	}

	/**
	 * Retorna el valor de opera carga dao.
	 * 
	 * @return  opera carga dao
	 */
	public OperaCargaDAO getOperaCargaDAO() {
		return operaCargaDAO;
	}

	/**
	 * Establece un valor a operaCargaDAO.
	 * 
	 * @param operaCargaDAO OperaCargaDAO
	 */
	public void setOperaCargaDAO(OperaCargaDAO operaCargaDAO) {
		this.operaCargaDAO = operaCargaDAO;
	}


	/*branch ingreso 2011-009 hosorio inicio 14/07/2011*/  
  public void crearSerie(DatoSerie serie, String numSerie) {
    try {
      Map params = new HashMap();
      if (serie.getNumcorredoc() != null) params.put("num_corredoc", serie.getNumcorredoc().toString());
      if (serie.getNumserie() != null) params.put("num_secserie", numSerie);
      Map serieMap = this.detDeclaraDAO.findBySerie(params);
      serieMap.put("NUM_SECSERIE", serie.getNumserie());
      if (serieMap.containsKey("COD_TIPMARGEN")) {
        serieMap.put("COD_TIPMARGEN", null);
      }
      serieMap.put("CNT_PESO_NETO", serie.getCntpesoneto());
      serieMap.put("CNT_UNIFIS", serie.getCntunifis());
      serieMap.put("MTO_FOBDOL", serie.getMtofobdol());
      this.detDeclaraDAO.insertSelective(serieMap);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void actualizarSerie(DatoSerie serie) {
    try {
      Map params = new HashMap();
      params.put("CNT_PESO_NETO", serie.getCntpesoneto());
      params.put("CNT_UNIFIS", serie.getCntunifis());
      params.put("MTO_FOBDOL", serie.getMtofobdol());
      params.put("NUM_CORREDOC", serie.getNumcorredoc());
      params.put("NUM_SECSERIE", serie.getNumserie());
      this.detDeclaraDAO.update(params);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
   
	public List<DatoSerie> getSeriesBD(Long numCorredoc) {
		Map<String,Object> params =new HashMap<String, Object>();
		params.put("numcorredoc", numCorredoc);
		return getDeclaracionService.getLstDatoSerie(params);
	}
	/*branch ingreso 2011-009 hosorio fin 14/07/2011*/

	/**
	 * @return the fabricaDeServicios
	 */
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	/**
	 * @param fabricaDeServicios the fabricaDeServicios to set
	 */
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public ContValidDAO getContValidDAO() {
		return contValidDAO;
	}

	public void setContValidDAO(ContValidDAO contValidDAO) {
		this.contValidDAO = contValidDAO;
	}

	/*INICIO GDLR*/
	@SuppressWarnings("unchecked")
	public List<ContCtaCte> getContCtaCteAll(List<DatoSerie> lstSeriesBd, Declaracion declaracion  ) {

		boolean tieneTM = false;
		//tipo "cuentacte"
		/*inicio gdlr*/
	    //gdlr: aqui ejecutamos un unico query en la tabla CONTCTACTE... para esto primero formamos una cadena con los numeros de serie concatenados
		//Aqui debe ser pero de la base de datos porque son los que tienen cuenta corriente, los nuevos no tienen cuenta corriente
		List<Integer> seriesInList = new ArrayList<Integer>();
		StringBuilder series = new StringBuilder();
		for (DatoSerie serie :lstSeriesBd) {
	    	Integer numeroSerie = serie.getNumserie();
	    	// Solo se considera las que tienen tipo de margen 5, porque tienen cuenta corriente
	    	//if ( serie.getCodtipomarge().trim().equals("5") ){
	    		tieneTM = true;
		    	if (!seriesInList.contains(numeroSerie)) {
		    		series.append(serie.getNumserie()).append(",");
		    		seriesInList.add(numeroSerie);
		    		//temporalmente... maxima longitud 4000... luego modificar el query para recibir mas cadenas 
		    		if (series.length() > 3500) {
		    			break;
		    		}
		    	}
	    	//}
		}
		
		List<ContCtaCte> list = new ArrayList<ContCtaCte>();
		if (tieneTM) {
			seriesInList = null;
			series.deleteCharAt(series.length() - 1);
		    /*fin gdlr*/
			String codAduana = "";

			if ( declaracion.getNumdeclRef().getCodaduana() == null ) {
				codAduana = declaracion.getCodaduana();
      		} else {
      			codAduana = declaracion.getNumdeclRef().getCodaduana();
      		}
			
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("NUM_DOC", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
			parametros.put("ANN_DOC", declaracion.getNumdeclRef().getAnnprese());
			parametros.put("COD_ADUANA_DOC", codAduana );
			parametros.put("COD_TIPO_DOC", "02");
			parametros.put("COD_ESTADO", "03");
			parametros.put("NUM_SERIES", series.toString());
			list = contCtaCteDAO.getContCtaCteAll(parametros);
		}
		return list;
	} 
	/*FIN GDLR*/
	
	
	//glazaror... metodo para agrupar las cuentas corrientes por serie
	public Map<Integer, ContCtaCte> getContCtaCteAllAsMap(List<DatoSerie> lstSeriesBd , Declaracion declaracion) {
		Map<Integer, ContCtaCte> cuentasCorrientesMap = new HashMap<Integer, ContCtaCte>();
		List<ContCtaCte> cuentasCorrientesAll = getContCtaCteAll(lstSeriesBd, declaracion);
		//agrupamos por serie
		
		for (ContCtaCte cuentaCorriente : cuentasCorrientesAll) {
			if (!cuentasCorrientesMap.containsKey(cuentaCorriente.getNumSerieDoc())) {
				cuentasCorrientesMap.put(cuentaCorriente.getNumSerieDoc(), cuentaCorriente);
			}
		}
		return cuentasCorrientesMap;
	}


public List<Map<String,Object>> getListFactEquiAlcohol(Declaracion declaracion, Map<String,Object> mapDatosCont) {
	
	//verificamos si hubo cambios en el campo porcentaje de alcohol	
//	if (!SunatNumberUtils.isEqual(declaracion.getDua().getListSeries().get(1)., serieOld.getPoralcohol())	
	
	// Verificamos si le corresponde multiplica por el factor del alcohol
			// RSV se agrega para calcula el porcentaje de alcohol 
			Map<String,Object> paramsContValid=new HashMap<String,Object>();
			paramsContValid.put("codTPI", mapDatosCont.get("codTpi"));
			paramsContValid.put("codPaisOrigen", mapDatosCont.get("codPaisOrigen"));
			paramsContValid.put("numGrupoCont", mapDatosCont.get("numGrupoCont"));
			paramsContValid.put("fechIngsi",  SunatDateUtils.getCurrentDate());
			if (  declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) 
			     paramsContValid.put("fechIngsi",  SunatDateUtils.getCurrentDate());
			else
			     paramsContValid.put("fechIngsi",  declaracion.getDua().getFecdeclaracion());
			
			paramsContValid.put("codCampo", "20");
			List<Map<String,Object>> listValidPorAlcohol=contValidDAO.joinContCampoFindByMap(paramsContValid);
			
			return listValidPorAlcohol;
 }

//rtineo optimizacion
public List<Map<String,Object>> getListFactEquiAlcohol(Declaracion declaracion, Map<String,Object> mapDatosCont,Map<String,Object> variablesIngreso, String codTransaccion) {

	
	List<Map<String, Object>> listFactEquiAlcoholFromCache = new ArrayList<Map<String, Object>>();
	
	try {
		
		Map<String, List<Map<String, Object>>> listFactEquiAlcoholCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("listFactEquiAlcoholCache");
			//verificamos primero si se encuentra precargado 
			
			if (listFactEquiAlcoholCache == null) {
				//antes de consultar obtenemos todos los contingentes
				Map<String, List<Map<String, Object>>> contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCache");
				if (CollectionUtils.isEmpty(contingentesCache)) {
					if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) {
						contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCacheRecOfi");	
					}
					
				}
				Iterator it = contingentesCache.entrySet().iterator();
				StringBuilder consultaBuilder = new StringBuilder();
				List<String> adicionados = new ArrayList<String>();
				while (it.hasNext()) {
					Map.Entry e = (Map.Entry)it.next();
					Map<String,Object> mapTmp =  ((List<Map<String, Object>>) e.getValue()).get(0);
					String codTpi = SunatStringUtils.lpad((String) mapTmp.get("codTpi"), 4, ' ');
					String codPaisOrigen = (String) mapTmp.get("codPaisOrigen");
					String numGrupoCont = SunatStringUtils.lpad(mapTmp.get("numGrupoCont").toString(),4,' ');//ES BIGDECIMAL
					String clave = codTpi + codPaisOrigen + numGrupoCont;
					if(!adicionados.contains(clave)){
						consultaBuilder.append(clave).append(",");
						adicionados.add(clave);
					}
				}
				if(adicionados.size()>0){
					//consultamos a base de datos
					consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
					Map<String,Object> paramsContValid=new HashMap<String,Object>();
					paramsContValid.put("fechIngsi",  SunatDateUtils.getCurrentDate());
					if (  declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) 
					     paramsContValid.put("fechIngsi",  SunatDateUtils.getCurrentDate());
					else
					     paramsContValid.put("fechIngsi",  declaracion.getDua().getFecdeclaracion());
					
					paramsContValid.put("codCampo", "20");
					paramsContValid.put("DOCUMENTO_LIST", consultaBuilder.toString());
					List<Map<String,Object>> listContValidFacts=contValidDAO.joinContCampoFindByMapFull(paramsContValid);
					
					listFactEquiAlcoholCache = new HashMap<String, List<Map<String, Object>>>();
					for (Map<String, Object> ContFact : listContValidFacts) {
						String codigoTPI = SunatStringUtils.lpad((String) ContFact.get("codTpi"), 4, ' ');
						String codigoPaisOrigen = (String) ContFact.get("codPaisOrigen");
						String numGrupoCont = SunatStringUtils.lpad(ContFact.get("numGrupoCont").toString(),4,' ');
						
						String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
						List<Map<String, Object>> contvalids = listFactEquiAlcoholCache.get(clave);
						if (contvalids == null) {
							contvalids = new ArrayList<Map<String, Object>>();
							listFactEquiAlcoholCache.put(clave, contvalids);
						}
						contvalids.add(ContFact);
					}
				}
				variablesIngreso.put("listFactEquiAlcoholCache", listFactEquiAlcoholCache);
			}
			//obtenemos de cache
			String codigoTPI = SunatStringUtils.lpad((String)mapDatosCont.get("codTpi"), 4, ' ');
			String codigoPaisOrigen = (String) mapDatosCont.get("codPaisOrigen");
			String numGrupoCont = SunatStringUtils.lpad(mapDatosCont.get("numGrupoCont").toString(), 4, ' ');
			
			String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
			listFactEquiAlcoholFromCache = listFactEquiAlcoholCache.get(clave);
		
	} catch (Exception e)
	     {
			      e.printStackTrace();
		  			log.info(" ContingentesUtil getListFactEquiAlcohol 1 "+ e.getMessage() );
		  			log.debug(" ContingentesUtil getListFactEquiAlcohol 1 "+e.getMessage());
	}
	
	return listFactEquiAlcoholFromCache;
 }

public List<Map<String,Object>> getListValidCampos(DUA dua, Map<String,Object> mapDatosCont,Map<String,Object> variablesIngreso,String codTransaccion) {
	//verificamos primero si se encuentra precargado
	Map<String, List<Map<String, Object>>> contingentesCache = null;
	List<Map<String,Object>> listCampValid = new ArrayList<Map<String,Object>>();
	Map<String, List<Map<String, Object>>> ListValidCamposCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("ListValidCamposCache");
	if (CollectionUtils.isEmpty(ListValidCamposCache))
    {
		//antes de consultar obtenemos todos los contingentes de cache
		 contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCache");
		
		if (CollectionUtils.isEmpty(contingentesCache)) {
			if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) {
				contingentesCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("contingentesCacheRecOfi");	
			}
			
		}
    }
	
	if (!CollectionUtils.isEmpty(contingentesCache))
       { 
		Iterator it = contingentesCache.entrySet().iterator();
		StringBuilder consultaBuilder = new StringBuilder();
		List<String> adicionados = new ArrayList<String>();
		while (it.hasNext()) {
			Map.Entry e = (Map.Entry)it.next();
			Map<String,Object> mapTmp =  ((List<Map<String, Object>>) e.getValue()).get(0);
			String codTpi = SunatStringUtils.lpad((String) mapTmp.get("codTpi"), 4, ' ');
			String codPaisOrigen = (String) mapTmp.get("codPaisOrigen");
			String numGrupoCont = SunatStringUtils.lpad(mapTmp.get("numGrupoCont").toString(),4,' ');//ES BIGDECIMAL
			String clave = codTpi + codPaisOrigen + numGrupoCont;
			if(!adicionados.contains(clave)){
				consultaBuilder.append(clave).append(",");
				adicionados.add(clave);
			}
		}
		if(adicionados.size()>0){
			//consultamos a base de datos
			consultaBuilder.deleteCharAt(consultaBuilder.length() - 1);
			Map<String,Object> paramsContValid=new HashMap<String,Object>();
			if (  dua.getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(dua.getFecdeclaracion()) ) 
				paramsContValid.put("fechIngsi", SunatDateUtils.getDate(SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")));
			else
				paramsContValid.put("fechIngsi", dua.getFecdeclaracion());
			
			paramsContValid.put("DOCUMENTO_LIST", consultaBuilder.toString());
			
			List<Map<String,Object>> listContValidFacts=contValidDAO.joinContCampoFindByMapFull(paramsContValid);
			
			ListValidCamposCache = new HashMap<String, List<Map<String, Object>>>();
			for (Map<String, Object> ContFact : listContValidFacts) {
				String codigoTPI = SunatStringUtils.lpad((String) ContFact.get("codTpi"), 4, ' ');
				String codigoPaisOrigen = (String) ContFact.get("codPaisOrigen");
				String numGrupoCont = SunatStringUtils.lpad(ContFact.get("numGrupoCont").toString(),4,' ');
				String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
				List<Map<String, Object>> contvalids = ListValidCamposCache.get(clave);
				if (contvalids == null) {
					contvalids = new ArrayList<Map<String, Object>>();
					ListValidCamposCache.put(clave, contvalids);
				}
				contvalids.add(ContFact);
			}
		}
		variablesIngreso.put("ListValidCamposCache", ListValidCamposCache);
	} 
	
	if ( CollectionUtils.isEmpty(ListValidCamposCache))
    { 
		
		//se continua con metodo pesado
		Map<String,Object> paramsContValid=new HashMap<String,Object>();
		paramsContValid.put("codTPI", mapDatosCont.get("codTpi"));
		paramsContValid.put("codPaisOrigen", mapDatosCont.get("codPaisOrigen"));
		paramsContValid.put("numGrupoCont", mapDatosCont.get("numGrupoCont"));
		if (  dua.getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(dua.getFecdeclaracion()) ) 
			paramsContValid.put("fechIngsi", SunatDateUtils.getDate(SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")));
		else
			paramsContValid.put("fechIngsi", dua.getFecdeclaracion());
		listCampValid=contValidDAO.joinContCampoFindByMap(paramsContValid);
		String clave = SunatStringUtils.lpad((String)mapDatosCont.get("codTpi"), 4, ' ') + "-" + (String) mapDatosCont.get("codPaisOrigen") + 
				"-" + SunatStringUtils.lpad(mapDatosCont.get("numGrupoCont").toString(), 4, ' ');
		for (Map<String, Object> ContFact : listCampValid) {
			List<Map<String, Object>>  contvalids = new ArrayList<Map<String, Object>>();
			contvalids.add(ContFact);
			ListValidCamposCache.put(clave, contvalids);
			
		}
		variablesIngreso.put("ListValidCamposCache", ListValidCamposCache);
		 
		
	}
	//obtenemos de cache
	String codigoTPI = SunatStringUtils.lpad((String)mapDatosCont.get("codTpi"), 4, ' ');
	String codigoPaisOrigen = (String) mapDatosCont.get("codPaisOrigen");
	String numGrupoCont = SunatStringUtils.lpad(mapDatosCont.get("numGrupoCont").toString(), 4, ' ');
	String clave = codigoTPI + "-" + codigoPaisOrigen + "-" + numGrupoCont;
	List<Map<String, Object>> ListValidCamposFromCache = ListValidCamposCache.get(clave);
	return ListValidCamposFromCache;
}
//fin rtineo optimizaciones


/**
 * Se valida que la fecha de  numeraci&oacute;n debe ser mayor o igual a la fecha de llegada del medio de transporte.
 * @author rcontreras
 * @param declaracion - Declaracion
 * @return
 * <p>Si la fecha de  numeraci&oacute;n es mayor o igual a la fecha de llegada del medio de transporte, 
 * entonces se retorna una lista sin errores. </p>
 * <p>Si la fecha de numeraci&oacute;n no es mayor o igual a la fecha de llegada del medio de transporte, 
 * entonces se retorna una lista con el siguiente mensaje de error: </p>
 * <ul>
 * <li>Para acogerse al  contingente arancelario se deber&aacute; numerar la declaraci&oacute;n 
 * despu&eacute;s del arribo del  medio de transporte.</li></ul>
 */
public List<Map<String, String>> validarFechaNumeracionFechaLlegada(Declaracion declaracion) {
	List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
	
	//amancilla PAS20155E220200173 puede que venag ann manifiesto cero o el numero INC 2015-024872
	boolean datosCompletos = ( declaracion.getDua().getManifiesto() != null && 
			(declaracion.getDua().getManifiesto().getAnnmanif() != null && !"0".equals(declaracion.getDua().getManifiesto().getAnnmanif().trim())) &&
			(declaracion.getDua().getManifiesto().getCodaduamanif() != null && StringUtils.isNotEmpty(declaracion.getDua().getManifiesto().getCodaduamanif().trim())) &&
			(declaracion.getDua().getManifiesto().getCodmodtransp() != null && StringUtils.isNotEmpty(declaracion.getDua().getManifiesto().getCodmodtransp().trim())) &&
			(declaracion.getDua().getManifiesto().getNummanif() != null && !"0".equals(declaracion.getDua().getManifiesto().getNummanif().trim())) );
	
	 if ( !datosCompletos ) //se agrega mensaje de ERROR cuando falta envio de datos inc - 2016-011726
     {
		 listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35419"));
    	 return 	listErr;
     }
      
	
	  Integer anioManifiesto = Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4));
	  String codigoTipoManifiesto = declaracion.getDua().getManifiesto().getCodtipomanif();
	  String codigoAduana = declaracion.getDua().getManifiesto().getCodaduamanif();
	  String codigoViaTransporte = declaracion.getDua().getManifiesto().getCodmodtransp();
	  String numeroManifiesto = declaracion.getDua().getManifiesto().getNummanif();
	  
	  
	  boolean buscarManifiestoSigadActual = ("4".equals(codigoViaTransporte) || "7".equals(codigoViaTransporte));
	  ManifiestoService manifService = (ManifiestoService)fabricaDeServicios.getService("manifiesto.manifiestoService");
	  Manifiesto manifiestoBD = manifService.findManifiestoByClaveDeNegocio(codigoTipoManifiesto, codigoViaTransporte, codigoAduana, anioManifiesto,
			  numeroManifiesto, buscarManifiestoSigadActual);
	  
	  Date fechaReferencia = SunatDateUtils.getCurrentDate();
	  if (declaracion.getDua().getFecdeclaracion() == null || SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion()) ) { 
		  fechaReferencia = SunatDateUtils.getCurrentDate();
		} else {
			fechaReferencia = declaracion.getDua().getFecdeclaracion();
		}
	  
	  if ( manifiestoBD == null || manifiestoBD.getFechaEfectivaDeLlegada() == null || 
			  				SunatDateUtils.isDefaultDate(manifiestoBD.getFechaEfectivaDeLlegada())) {
		  listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35419"));
	  } else if ( manifiestoBD.getFechaEfectivaDeLlegada().compareTo(new java.util.Date()) >= 0) {
		  listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35420"));
	  }
	  
	return listErr ;
}

}
