/*
 * Clase que define el servicio de validaciones de los documentos de transporte.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.Map;


/**
 * The Class ValDoctrans. Clase que define el servicio de validaciones de los documentos de transporte.
 */
public interface ValDoctrans {
	
	public Map<String, String> codpuerto(String codpuerto);
	
	public Map<String, String> fecembarque(Date fecembarque);
	
	public Map<String, String> codtipodoctrans(String codtipodoctrans);
	
	public Map<String, String> numdoctransporte(String numdoctransporte);
	
	public Map<String, String> numdocmaster(String numdocmaster);
	
	public Map<String, String> fecembarqueorg(Date fecembarqueorg);
	
	public Map<String,String> numsecdoctrans(Integer numsecdoctrans);
        
        public Map<String, String> codpuertoorg(String codpuertoorg); 

}
