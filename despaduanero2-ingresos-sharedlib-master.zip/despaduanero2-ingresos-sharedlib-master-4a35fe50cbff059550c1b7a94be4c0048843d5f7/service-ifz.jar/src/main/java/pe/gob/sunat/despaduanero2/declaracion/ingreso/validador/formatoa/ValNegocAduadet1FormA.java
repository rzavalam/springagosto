/*
 * Clase que define el servicio de validaciones complejas de las series de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * The Class ValNegocAduadet1FormA. Clase que define el servicio de validaciones complejas de las series de la DUA.
 */
public interface ValNegocAduadet1FormA {
	
	public List<Map<String,String>> valAduadet(Declaracion declaracion);
	
}
