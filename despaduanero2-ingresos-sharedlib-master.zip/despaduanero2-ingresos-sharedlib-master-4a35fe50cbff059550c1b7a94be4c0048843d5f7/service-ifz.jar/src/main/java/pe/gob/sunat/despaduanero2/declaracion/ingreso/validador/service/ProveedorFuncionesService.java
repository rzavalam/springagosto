package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPosicion;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.servicio2.registro.model.bean.UsuarioSOLBean;

public interface ProveedorFuncionesService {
	
	boolean isExonerado(String ptipo_docum, String pnume_doc, Integer gc_fech_ingsi);
	boolean isImportadorFrecuente(String pRegimen, String pTipoDoc, String pNumeroDoc);

	//region amancillaa SDA2-RIN18-PAS20171U220200035
	public boolean isOEA(String numRuc, Date fecVigencia);
	//endregion amancillaa

	/**
	 * 
		Si env�a solo los par�metros PCodigo, PFecha
			Se verifica en la tabla TABLNEW si el proceso se encuentra vigente, para ello se realiza la consulta con el Tipo=�AJ� y Codigo= PCodigo y PFecha entre Finicio y Ffin. Si se cumple esta condici�n significa que el proceso est� vigente sino es as� significa que no est� vigente.
		Si env�a los 4 par�metros
			Se ejecuta la funci�n PL/SQL
			PKTG_GRAL.FnGetVigenciaCambio (PAduana, PRegimen, �TD000�, PCodigo, PFecha)
			Si devuelve mayor a 0 significa que est� vigente, si es 0 significa que no est� vigente.
	 * @param pCodCambio. C�digo de Proceso
	 * @param pFecha. Fecha con la cual evaluar la vigencia del proceso.
	 * @param pAduana. C�digo de aduana. (Opcional)
	 * @param pRegimen. C�digo de R�gimen. (Opcional)
	 * @return boolean
	 */
	boolean hasVigenciaCriterio (String pCodCambio, Integer pFecha, String pAduana, String pRegimen);
	
	boolean hasVigenciaCriterio (String pCodCambio, Integer pFecha);
	
	Integer getVigenciaCambio(String pAduana, String pRegimen, String pModulo, String pCodCambio, Date pFecha);
	
	Integer getCountFromTabDescMin(String tcTipoTabla,String tcDescOtro);

	
	String fnTipo(String pPartida, String  pNombreComercial, String pCaraTipo, Integer fechaIngSi);
	/*
	 * Formatob.fcValCondidion
	TcCampo 	: Campo donde se encuentra el Dato a validar
	pNPOSC_CODI 	: Posici�n del dato a validar
	pNLONG_CODI 	: Longitud del dato a validar
	pNOMBR_CAMP 	: Nombre del campo
	pCONDI_OPCI 	: Condici�n Opcional
	pCONDI_VALI 	: Condici�n a validar
	pTipo_obs 	: Tipo de Observaci�n
	 */
	String fcValCondidion(String tcCampo, Integer pnPoscCodi, Integer pnlongCodi, String pNombrCamp, String pcondiOpci, String pcondiVali, String pTipoObs);
	
	/**
	 *	TcTipoVal 	: Tipo de validaci�n a realizar
		TnFechIngsi 	: Fecha de proceso
		TcPartSupe 	: Material de la Parte superior del calzado
		TcPartInfe 	: Material de la Parte inferior del calzado
		TnPartida 	: Partida
		TcPoliuretano 	: C�digo del Poliuretano
		TcNomCom 	: Nombre comercial
		TcCauPla1 	: Primer componente de Caucho o pl�stico de la parte superior
		TcCauPla2 	: Segundo componente de Caucho o pl�stico de la parte superior
	 */
	
	String fcValCalzadoOtros(String tcTipoVal, Timestamp TnFechIngsi, String tcPartSupe, String tcPartInfe,Long tnPartida, String tcPoliuretano, String tcNomCom, String tcCauPla1, String tcCauPla2);
	
	
	/**
	 * 	3.	Se validan los datos enviados seg�n posiciones. Para ello se consulta la tabla DET_POSICION:
	 */
	public List<DetPosicion> getListaPosiciones(String pTipoRela, String codigoAduana);
	
	
	/**
	 * Se obtiene el tama�o m�ximo del dato a validar.
	 * 
	 * @return
	 */
	public Integer getLongitudMaxima(String tipoRela, String cnombCamp, String codigoAduana);
	
	/**
	 * select 1 from dual where #condicion#
	 * @param condicion
	 * @return
	 */
	boolean isCondicionValida(String condicion);
	
	
	/**
	 * 
	 * @return
	 */
	boolean existsInTabDescMinByTipoAndCodigoOrDescripAndFVig(String ctipo, String codigo);

	/**
	 * @param ctipo
	 * @param codigo
	 * @return
	 */
	boolean existsInTabDescMinByTipoAndCodigo(String ctipo, String codigo);
	
    /**amancilla descr minimas */
    boolean existsInTabDescMinByTipoAndCodigo(String ctipo, String codigo, Integer fechaVigencia);
	
	/**
	 * 
	 * @param cgrupo
	 * @param ctipo
	 * @return
	 */
	List<DatoDescrMinima>  getCodigosInTabDescMinByGrupoAndTipo(String cgrupo, String ctipo);
	
	/**
	 *  
	 * @param ctipo
	 * @param codigo
	 * @return
	 */
	public List<DatoDescrMinima> getDescripcionTabDescMin(String ctipo, String codigo);
	
	/**
	 *  
	 * @param ctipo
	 * @param tdescri
	 * @return
	 */
	String getCodigoInTabDescMinByTipoAndDescri(String ctipo, String tdescri);
	
	Integer cambioVigente(String codigo, Integer fecha);
	
	boolean existsInResSPIMByTipoDocAndNumDoc(String tipoDoc, String numDoc);
	
	/**
	 * 2.	Sql = " SELECT CDOCUMEN FROM PUBLICAS WHERE CTIPODOC='" +xTipo_Docum + "' AND CDOCUMEN='" + xNume_Docum + "' "
	 * @param tipoDoc
	 * @param numDoc
	 * @return
	 */
	boolean existsInEmpresasPublicas(String tipoDoc, String numDoc);
	
	/**
	 * @param codigoReg
	 * @param tipoDoc
	 * @param numeroPartida
	 * @param fechaEmbarque
	 * @return
	 */
	boolean existsInMRestri(String codigoReg, String numeroPartida, Integer fechaEmbarque);

	/**
	 * 
	 * @param dua
	 * @return
	 */
	boolean isAutoUsa(DUA dua);
	
	//lmvr	
	Integer obtenerSerieAutoUsa(DatoSerie serie);	
	Integer obtenerSeriesValorProvisional(DatoSerie serie);	
	Integer obtenerSerieValorProvisional(DUA dua); 
	
	boolean existsInRefPartidaByTipoUsoAndCN(Long numpartnandi);
	
	Integer getCountPartidaSoftware(Long partidaSoftware, Timestamp fecha);
	
	boolean existsVehiculo(String mCate, String mSubCat, String mMarcComer, String mModeMercd, String mCaraTipo,Integer vFechIngsi);
	
	boolean isCategoriaVehiculoValido(String mCate, String mSubCat, String wclase);
	
	boolean existsInCatRefPartidas(String tipoUso, String mPartNandi, String mNombComer);
	
	List<CatRefpartidas> getPartidaVehiculo(String tipoUso, String codiregi, String aduana);
	
	boolean existsInRefPartidasByTipoUsoAndPartNandiAndRef(String tipoUso, String partNandi);
	
	List<CatRefpartidas> existsInRefPartidasByTipoUsoAndPartNandiAndCapitulo(String tipoUso, String partNandi, String capitulo);
	
	CatRefpartidas existsInRefPartidasByTipoUsoAndPartidaAndFechVig(String tipoUso, String partNandi, Integer fechaVigencia);
	
	CatRefpartidas getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(String tipoUso, String partida, Integer fecha, String tipoEnce, String tipoCate);
	
	CatRefpartidas getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib(String tipoUso, String partida, Integer fecha, String codCLib);
	
	CatRefpartidas getRefPartidasByTipoUsoAndAduanaAndPaisOrigenAndClib(String tipoUso, String aduana, String paisOrigen,
			String codCLib, Long cnan);
	
	boolean existsInCatRefRuc(String[] tipoUso, String clib, String tipoDoc, String numDoc,String aduana);
	
	Integer getRefPartidasByTipoUsoAndPartida(String tipoUso, String partida);
	
	Map<String, Object> getCantMaxLibeByClibAndAduanaAndRegimenAndMarcaAndChasisAndAnnFabrica(String clib, String aduana, String regimen, String marca, String chasis, Integer annFabrica);
	//ggranados formb
	DUA getDeclaracionReferenciaResumida(String codAduana,String codRegimen,Long numDeclaracion, Integer annDeclaracion);
	DUA getDeclaracionReferencia(String codAduana,String codRegimen,Long numDeclaracion, Integer annDeclaracion);
	
	List<DatoSerie>  getSeriesReferencia(Map<String, Object> params);
	
	List<DatoFactura>  getListComprobPago(Map<String, Object> params);
	
	List<DatoItem>  getListItemFactura(Map<String, Object> params);
	
	List<DatoSerieItem>  getListSeriesItem(Map<String, Object> params);
	
	List<Participante>  getListParticipante(Map<String, Object> params);
	
	 boolean isAutoliquidado(DUA dua);
	 
	 public Map<String,BigDecimal> obtenerTributosAutoliquidacion(Declaracion declaracion,Map<String,Object> variablesIngreso);
	 
	 public List<Map<String,String>> verificarTributosAutoliquidacion(Declaracion declaracion,Map<String,Object> variablesIngreso);
	 /*branch ingreso 2011-009 hosorio 03/08/2011 inicio*/
	 public Date getFechaVencimientoPagoDespacho(Declaracion declaracion,Map<Object,Object> mapManifiesto);
	 public Date getFechaLlegadaIngreso(Declaracion declaracion,Map<Object,Object> mapManifiesto);
	 public Map<Object, Object> getManifiestoMap(Declaracion declaracion);
	/*branch ingreso 2011-009 hosorio 03/08/2011 fin*/
	 public boolean existsAutoliquidacionesPagadas (Declaracion duaBD);
	 /**
	  * Obtiene el manifiesto en el NSIGAD, de no encontrarlo busca en el ASIGAD
	  * @param declaracion
	  * @return
	  */
	 public Manifiesto getManifiestoNASigad(Declaracion declaracion);
	 
	 /**
	  * Verifica si el tipo de transaccion corresponde a alguna establecida para la diligencia
	  * @param codigoTransaccion
	  * @return
	  */
	 public boolean isTransaccionDiligencia(String codigoTransaccion);
	 
	 /**
	  * Determina la fecha de regularizaci�n para los despachos anticipados urgentes
	  * @param dua
	  * @return
	  */
	 public Date getFechaRegularizacion(DUA dua, Date fechaReferencia);
	 

	 /**
	  * Obtiene la partida correlacionada
	  * @param partNandi
	  * @param partCorrelacion
	  * @param fechaReferencia
	  * @return
	  */
	 public Long getCorrelPartida(Long partNandi, Long partCorrelacion, Integer fechaReferencia);


	 /**
	  * Consulta multiple de partidas referenciales
	  * @param tipoUso
	  * @param aduana
	  * @param paisOrigen
	  * @param codCLib
	  * @param partNandi
	  * @param capitulo
	  * @param tlib
	  * @param fecha
	  * @param codiregi
	  * @return
	  */
	 public CatRefpartidas getRefPartidas(String tipoUso, String tipoUsoIn, String aduana, String paisOrigen,String codCLib, String partNandi, String capitulo,String tlib, Integer fecha, String codiregi);
	 
	 /**Buscar manifiesto asociado a la declaracion. 
	 * @TRANSACCION 1003,2003,21003 FORMATO B
	 * @return map*/	 
  	 public boolean tieneTransmisionDeRegularizacion (Long numCorreDoc, String codTransaccion, String codEstaRecti);
  	 
 	 /**Verificar si es una DUA regularizable 
 	 * @param Long  
 	 * @TRANSACCION 1003,2003,21003 FORMATO B */
  	 public  boolean esDuaRegularizable(Long numCorreDoc);
  	 public boolean  validaIndicadorAbandonoVoluntario(String numCorreDoc);//BUG14:44-Se traslado el metodo de ValRectiServiceImpl
  	 public List<DatoIndicadores>  getIndicadorDUA(Long numCorredoc, String codindicador, String codtipregistro, String indActivo );
	 /**Buscar manifiesto asociado a la declaracion.	
	 * @params codigoTipoManifiesto, codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto)
	 * @TRANSACCION 1003,2003,21003 FORMATO B  */
  	 public Manifiesto obtenerManifiestoDeDua(Declaracion declaracion);


	 /**
	  * Servicio para saber si la fecha remitida por el usuario
	  * corresponde a la fecha de llegada o a la fecha de t�rmino 
	  * de descarga 
	  * @param DUA
	  * @param fechaReferencia
	  * @return
	  */
	 public boolean esFechaLlegada(DUA dua, Date fechaReferencia, String codTransaccion );	
	 public List<Map<String, Object>> buscarExpedienteSuspension(String codaduana, String annpresen, String codregimen, String numdeclaracion, Date fechaVencimiento);
	 	/* P14 - 3007 - Inicio - dhernandezv */
		/* CUS: 3007-01.10 - Inicio - dhernandezv */
		
		/**
		 * Metodo que valida los estados e indicadores de la declaracion que este con un proceso de rectificacion
		 * 
		 * @param declaracion Declaracion 
		 * @return HashMap
		 * @author dhernandez
		 */
		public Map<String, String> validarDeclaEstadosIndicadores(Declaracion declaracion);
		/* CUS: 3007-01.10 - Fin - dhernandezv */
		/* P14 - 3007 - Fin - dhernandezv */
	/**
	 * Obtiene el Representante de un OCE a partir de los datos de usuario SOL 
	 * @param codUsuario
	 * @param tipoSender
	 * @return
	 */
	public Map<String, Object> obtenerPersonalOCE(String codUsuario, String tipoSender);


	/**
	 * Obtiene el representante legal de la clave SOL
	 * @param codUsuario
	 * @param tipoSender
	 * @return
	 */
	public  UsuarioSOLBean obtenerUsuariosSOL (String codUsuario, String tipoSender );
	
	/***
	 * PAS20181U220200064 busca los manif de via aerea para definir si son eer de sda o sigad
	 * @param declaracion
	 * @return
	 */
	public Manifiesto buscarManifiestosEER(Declaracion declaracion) ;

	/***
	 * PAS20181U220200064 retorna true si el manifiesto es de via 5 del sigad
	 * @param declaracion
	 * @return
	 */
	public boolean esManifiestoEerSigad(Declaracion declaracion) ;

	/***
	 * PAS20181U220200049 retorna true si el manifiesto es de via 4, del sda y ademas tiene operador eser, 
	 * siendo asi identificado como manifiesto con desconsolidado EER del sda
	 * @param declaracion
	 * @return
	 */
	public boolean esManifiestoEerSda(Declaracion declaracion) ;
	
	/**
	 * PAS20181U220200049 retorna true si el manifiesto es de via 4, del sda y ademas tiene operador eser, 
	 * siendo asi identificado como manifiesto con desconsolidado EER del sda
	 * @param manifiesto
	 * @param docsDeclaracion
	 * @return
	 */
	public boolean esManifiestoEerSda(Manifiesto manifiesto, Elementos<DatoDocTransporte> docsDeclaracion);
	

	/***
	 * PAS20181U220200049 transformarOma es true, cambia el catalogo 227 al catalogo 10
	 * transformarOma es false, cambia el catalogo 10 al cat�logo 227
	 * si tiene true evaluarEer, se cambia de via 4 a 5 o viceversa
	 * @param codigoViaTransporte
	 * @param transformarUnece
	 * @param fechaDeclaracion
	 * @param considerarEER
	 * @return
	 */
	public String transformarViaTransporteDeOma(String codigoViaTransporte, boolean transformarUnece, Date fechaDeclaracion, boolean considerarEER);

	public List<Map<String, Object>> buscarExpedienteSuspensionPrece(String codaduana, String annpresen, String codregimen, String numdeclaracion, Date fechaVencimiento, String[] codProcedimSuspencion );

}