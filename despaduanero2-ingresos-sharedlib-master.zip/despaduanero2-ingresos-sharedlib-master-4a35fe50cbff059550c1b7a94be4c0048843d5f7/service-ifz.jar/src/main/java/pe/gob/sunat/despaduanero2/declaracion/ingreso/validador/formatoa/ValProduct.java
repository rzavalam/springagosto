/*
 * Clase que define el servicio de validaciones de la Relaci�n de insumos de la declarados en la dua.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Map;

/**
 * The Class ValProduct. Clase que define el servicio de validaciones de la Relaci�n de insumos de la declarados en la dua.
 */
public interface ValProduct {
	
	public Map<String, String> numitem(String numitem);

	public Map<String, String> codtipoequi(String codtipoequi);
	
	public Map<String, String> cntunimedidaequi(BigDecimal cntunimedidaequi);
	
	public Map<String, String> pormerma(BigDecimal pormerma);
	
	public Map<String, String> codexpantidum(String codexpantidum);
	
	public Map<String, String> codpantidum(String codpantidum);
	
	public Map<String, String> mtofobfactu(BigDecimal mtofobfactu);
}
