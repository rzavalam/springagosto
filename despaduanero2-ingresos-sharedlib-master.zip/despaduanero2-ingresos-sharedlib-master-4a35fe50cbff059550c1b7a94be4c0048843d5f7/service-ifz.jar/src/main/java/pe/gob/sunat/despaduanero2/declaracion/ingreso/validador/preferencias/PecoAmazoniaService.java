package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;

public interface PecoAmazoniaService {
	//RIN08
	public Map<Integer,Object> esPECOAmazonia(Declaracion declaracion);
	public List<Map<String,?>> validacionesPECOAmazonia(Declaracion declaracion, Map<String,Object> variablesIngreso, Declaracion declaracionBD);
	public List<Map<String,?>> validacionesNumeracion(Declaracion declaracion, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesRegularizacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validacionesDiligenciaDespacho(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA);
	public List<Map<String,?>> validarRegimen(String codRegimen, Map<Integer,Object> mapa, Declaracion declaracion);
	public List<Map<String,?>> validarAduanaIngreso(Declaracion declaracion);
	public List<Map<String,?>> validarAduanaDestinoPECO(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarSubpartidaArancelaria(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarAduanaDestinoCodLiberatorio(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarCorrelacionNandinaNabandina(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarInformacionComplementaria(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarPartidaConvenioPECOAmazonia(Declaracion declaracion, Map<Integer,Object> mapa);
	public List<Map<String,?>> validarUbigeo(Declaracion declaracion, Map<Integer,Object> mapaSerieDUA);	
	//public boolean tieneDiligenciaDespacho(Declaracion declaracionBD);
	public List<Map<String,?>> acogimientoPosteriorNumeracion(Declaracion declaracion, Declaracion declaracionBD, Map<Integer,Object> mapa, String codTransaccion);
	public List<Map<String,?>> modificacionPosteriorNumeracion(Declaracion declaracion, Declaracion declaracionBD, Map<Integer,Object> mapa, String codTransaccion);
	public String validarSeriePecoAmazoniaModificada(Map<String, Object> requestParameterMap);
	//public void procesarAnulacionLC0006PecoAmazonia();
	public String procesarAnulacionLC0006PecoAmazonia(Liquida liquidacionPeco, Map<String, Object> mapLiquida);
	public String validaAduanaDestinoDiligenciaRectificacion(String codAduanaDestino,List<Map<String,Object>> lstSerie, String numCorreDoc);
	public boolean excedePlazoSolicitudRectificacion ( Declaracion declaracion, Date fecha ) ; //PasePecoPAS20181U220200069
	//PAS201830001100016 - mtorralba 20190201
	public String esPecoAmazonia(Long numcorredoc);
	//PasePecoPAS20181U220200069
		public boolean excedePlazoDiligenciaAduanaDestino( Declaracion declaracion,Date fechaDiligencia) ;
}
