package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValRegPrecCeticosService {

	public List<Map<String,String>> valDetRegPreCeticos(Declaracion  declaracion,DatoSerie serie, DatoRegPrecedencia regPrec, Date fechaReferencia, String  codTransaccion);
}
