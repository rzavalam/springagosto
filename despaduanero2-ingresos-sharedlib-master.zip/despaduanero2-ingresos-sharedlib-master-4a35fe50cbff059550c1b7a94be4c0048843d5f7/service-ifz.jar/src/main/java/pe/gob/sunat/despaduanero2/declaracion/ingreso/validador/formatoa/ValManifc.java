/*
 * Clase que define el servicio de validaciones de la seccion del Manifiesto.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;


/**
 * The Class ValManifc. Clase que define el servicio de validaciones de la seccion del Manifiesto.
 */
public interface ValManifc {
	
	public Map<String, String> codmodtransp(String codmodtransp, Date fechaReferencia, String codaduamanif); //VERIFICARMOL
	
	public Map<String, String> codpuermanif(String codpuermanif);
	
	public Map<String, String> codaduamanif(String codaduamanif);
	
	public Map<String, String> codtipomanif(String codtipomanif);
	
	public Map<String, String> annmanif(String annmanif);
	
	public Map<String, String> nummanif(String nummanif);
	
	public Map<String, String> fectermino(Date fectermino, Map<String,Object> variablesIngreso, Date fechaReferencia);
	
	public Map<String, String> numviaje(String numviaje, Declaracion declaracion);
	
	public Map<String, String> feciniembarque(Date feciniembarque);
	
	public List<Map<String,String>> empTransporte(Participante empTransporte, String codTransaccion, Map<String,Object> variablesIngreso);
	
	public Map<String,String> codpuerto(String codpuerto);
	
	public List<Map<String, ?>> validarTransportistaoRepresentanteEER(String tipoParticipante, String numeroDocumentoParticipante, String viaTransporte);
	
}
