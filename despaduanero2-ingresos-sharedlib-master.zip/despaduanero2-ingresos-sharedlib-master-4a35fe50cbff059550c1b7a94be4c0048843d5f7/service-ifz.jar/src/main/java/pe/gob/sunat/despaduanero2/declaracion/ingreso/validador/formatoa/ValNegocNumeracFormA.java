/*
 * Clase que define el servicio de validaciones de complejas para el formato A de la declaracion.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;


/**
 * The Class ValNegocNumeracFormA. Clase que define el servicio de validaciones de complejas para el formato A de la declaracion.
 */
public interface ValNegocNumeracFormA {
 
	public DatoFactura getFacturaCorrespondiente(DatoSerie serie, Declaracion declaracion);
	
	public DAV getDAVCorrespondiente(DatoSerie serie, Declaracion declaracion) ;
	
	public List<Map<String,String>> validarEnvioFormatoB(Declaracion declaracion);
	
	public List<Map<String,String>> val29077(Declaracion declaracion);
	
	public List<Map<String,String>> validacionesPreviasFormatoA(Declaracion declaracion, String numOrden, Map<String,Object> variablesIngreso);
	
	public List<Map<String,String>> valRegimenPrecedenteRepetido(Declaracion declaracion);
	
	public List<Map<String,String>> valCtaCtePerNat(Declaracion declaracion);
	
	public List<Map<String,String>> valIncMigrat(Declaracion declaracion,String codTransaccion); //gmontoya Pase 153
	
	public List<Map<String,String>> valAutoliquidacion(Declaracion declaracion, String codTransaccion);
	
	public List<Map<String,String>> valExpAprobDonac(Declaracion declaracion);
	
	public List<Map<String,String>> valInfoPagoElect(Declaracion declaracion);
	
	public List<Map<String,String>> valSada(Declaracion declaracion);
	
	public List<Map<String,String>> valPreviasDatosSeries(Declaracion declaracion);
	
	public List<Map<String,String>> valEstadoMercancia(Declaracion declaracion);
	
	public List<Map<String,String>> valTPN212TPN208(Declaracion declaracion);

	public List<Map<String,String>> valUltractividad(Declaracion declaracion);

	public List<Map<String,String>> valDetalleSeries(Declaracion declaracion);
	
	public List<Map<String,String>> valCodigoLiberatorio(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) throws Exception;
	
	public List<Map<String,String>> valAduanaDestino(Declaracion declaracion, Date fechaReferencia);
	
	public Map<String,String> validarEnvioSeries(Declaracion declaracion);
	
	public List<Map<String,String>> pValidaMaster(Declaracion declaracion);
	
	public List<Map<String,String>> validarNumerarConRUC(Declaracion declaracion);
	
	//public List<Map<String,Object>> getRegPrecedenciaAcumulado (Declaracion declaracion);
	
	//public List<Map<String,String>> validarCtaCteDeposito(Declaracion declaracion, Map<String, Object> variablesIngreso);
	
	public List<Map<String,String>> validarCupoTPN(Declaracion declaracion);
	
	public List<Map<String,String>> validarConsistencias(Declaracion declaracion );
	
	public List<Map<String,String>> validarTotalesCabvsSer(Declaracion declaracion );
	
	public List<Map<String,String>> validarFechaTerDescDuasUrgentes(Declaracion declaracion);
	
	public List<Map<String,String>> validarManifiestoCarga(Declaracion declaracion,Map<String, Object> variablesIngreso, Date fechaReferencia, String codTransaccion) throws Exception;
	
	public List<Map<String,String>> validarManifiestoCargaB(Declaracion declaracion);
	
	public List<Map<String,String>> PrcvalidaTPI( Declaracion declaracion,Date fechaReferencia, DatoSerie datoSerieActual, String codTransaccion);
	
	public List<Map<String,String>>  validarRegimenPrecedencia(DatoRegPrecedencia regimenPrec);
	
	public Map<String,?> validarAnticipadoManifiesto (Map<String,Object> dataDua,Manifiesto manifiesto) ;
	
	public Map<String,?> validarExcepcionalManifiesto  (Map<String,Object> dataDua,Manifiesto manifiesto);

        public Map<String, String> procesaLstSeriesItemActual(List<Map<String, Object>> lstSeriesItemActual);
	
        public Map<String,Object> listaPartidasSensibles(Declaracion declaracion, List<Map<String, Object>> lstSeriesItemActual) throws Exception;


    /**INICIO-RIN13**/
  public List<Map<String,String>> validarPlazoDespachoUrgente(Date fechaTerminoDescargaManifiesto, Date fechaLlegada, Date fechaDeclaracion);
    public List<Map<String,String>> validarPlazoDespachoAnticipado(Declaracion declaracion, Date fechaLlegada, Date fechaDeclaracion, boolean esFecEfectiva);  //verificar solo para fecha de llegada efectiva SAU201510002000209   
  
	//mordonezl pase 70
	public List<Map<String,String>> validarPlazoDuaAnticipadoYUrgenteAnticipado(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)throws Exception;
	public List<Map<String,String>> validacionesParaDespachoExcepcional(Declaracion declaracion,Declaracion declaracionBD) throws Exception;
//fin mordonezl
	
	//lmvr
	public List<Map<String, String>> validaDocumentoAutorizante(Declaracion declaracion,DatoSerie serie);
	
    // inicio oneyraj rin10
    public List<Map<String, String>> validarIngresoValorProvisional(Declaracion declaracion, Declaracion declaracionBD, Date fechaReferencia, Map<String,Object> variablesIngreso)  throws Exception; //PAS20155E220300034(SAU201510002000221) - se agrega declaracionBD
    // fin oneyraj rin10	

    /**
     * PAS20181U220200022 ya no va aca 
     * se movio a su propia clase ValidacionOEAServiceImpl
     */
    public List<Map<String,String>> validarGarantiaNominal(Declaracion declaracion, Date fechaReferencia);
    
   
    	
}
