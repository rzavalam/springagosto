package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;

/**
 * Clase que realiza las validaciones propias de la regularizaci�n de la DUA. 
 * @author jcanchucaja
 *
 */
public interface RegularizacionService {


}
