
package pe.gob.sunat.despaduanero2.declaracion.ingreso.wsclient;



public class ResponseSeleccion {

    protected String aforo;
    protected String codigoError;
    protected String mensajeError;
    protected String motaforo;

    /**
     * Gets the value of the aforo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAforo() {
        return aforo;
    }

    /**
     * Sets the value of the aforo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAforo(String value) {
        this.aforo = value;
    }

    /**
     * Gets the value of the codigoError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoError() {
        return codigoError;
    }

    /**
     * Sets the value of the codigoError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoError(String value) {
        this.codigoError = value;
    }

    /**
     * Gets the value of the mensajeError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeError() {
        return mensajeError;
    }

    /**
     * Sets the value of the mensajeError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeError(String value) {
        this.mensajeError = value;
    }

    /**
     * Gets the value of the motaforo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotaforo() {
        return motaforo;
    }

    /**
     * Sets the value of the motaforo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotaforo(String value) {
        this.motaforo = value;
    }

}
