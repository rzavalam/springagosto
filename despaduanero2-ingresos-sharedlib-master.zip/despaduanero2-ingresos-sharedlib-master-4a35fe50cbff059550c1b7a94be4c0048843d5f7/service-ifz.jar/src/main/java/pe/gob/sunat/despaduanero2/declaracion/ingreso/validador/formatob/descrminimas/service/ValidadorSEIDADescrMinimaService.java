package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import java.util.Date;	//Pase548
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * La Interface ValidadorSEIDADescrMinimaService.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public interface ValidadorSEIDADescrMinimaService
{



  /**
   * Aplica todas las validaciones de negocio que le corresponde. los catalogos
   * de errores estan registrados con codigo F09
   * 
   * @param item
   * @param declaracion
   * @return list de errores
   * @author amancillaa
   * @version 1.0
   */
   	//Pase548
  public List<Map<String, String>> validarDescripcionMinima(DatoItem item, Declaracion dua) throws Exception;
  
  /** Pase548
   * Aplica todas las validaciones de negocio que sean transparentes a la vigencia del datacatalogo 507
   * 
   * @param item
   * @param declaracion
   * @param declaracionBD
   * @return list de errores
   * @author arey
   * @version 1.0
   */
  public List<Map<String, String>> validarDescripcionMinimaSinVigencia(DatoItem item, Declaracion dua, Declaracion declaracionBD) throws Exception;

}
