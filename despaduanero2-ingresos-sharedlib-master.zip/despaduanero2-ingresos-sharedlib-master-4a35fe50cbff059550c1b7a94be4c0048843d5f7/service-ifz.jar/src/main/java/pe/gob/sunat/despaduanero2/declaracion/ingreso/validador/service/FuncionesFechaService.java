package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import org.springframework.aop.target.HotSwappableTargetSource;

import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.CalculaDiaDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.service.CalculaDiaDAOService;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;


public class FuncionesFechaService {
	private static final String DESPADUANERO2_DS = "despaduanero2.ds.";
	private HotSwappableTargetSource swapperDatasource;
	private FabricaDeServicios fabricaDeServicios;
//	private CalculaDiaDAO calculaDiaDAO;
	private CalculaDiaDAOService calculaDiaDAOService;

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

//	public void setCalculaDiaDAO(CalculaDiaDAO calculaDiaDAO) {
//		this.calculaDiaDAO = calculaDiaDAO;
//	}

	public synchronized String obtenerSgteDiaUtil(Map<String, Object> params) throws ServiceException {
	     Object o = swapperDatasource.swap(fabricaDeServicios.getService(DESPADUANERO2_DS + params.get("COD_ADUANA")));
//	     String ultimoDia = this.calculaDiaDAO.getFnCalculaDias(params);
	     String ultimoDia = this.calculaDiaDAOService.getFnCalculaDias(params);
	     swapperDatasource.swap(o);
        return ultimoDia;
    }

	public CalculaDiaDAOService getCalculaDiaDAOService() {
		return calculaDiaDAOService;
	}

	public void setCalculaDiaDAOService(CalculaDiaDAOService calculaDiaDAOService) {
		this.calculaDiaDAOService = calculaDiaDAOService;
	}
}