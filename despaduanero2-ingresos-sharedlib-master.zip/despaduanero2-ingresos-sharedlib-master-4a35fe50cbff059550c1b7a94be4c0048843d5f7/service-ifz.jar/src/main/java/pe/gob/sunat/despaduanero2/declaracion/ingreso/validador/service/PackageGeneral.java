package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.CatConversion;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCatConversion;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaService;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;



public class PackageGeneral {
	private static AyudaService ayudaService;
	private static AyudaServiceCatConversion ayudaServiceCatConversion;
	private static MercanciaRestringidaService mercanciaRestringidaService;
	//fn_getjurisdicc
	public static String getJurisdicc(String codAduana){
		if (SunatStringUtils.include(codAduana, new String[]{"118", "235", "244" }))
			return "992";
		else if ("028".equals(codAduana))
			return "046";
		else if("136".equals(codAduana))
			return "127";
		else if("262".equals(codAduana))
			return "181";
		return codAduana; 
	}
	
	//fngetvigenciacambio
	public static Integer getVigenciaCambio(String pAduana, String pRegimen, String pModulo, String pCodCambio, Date pFecha){
		Integer pSecuencia=1;
		Map<String,Object> params=new HashMap<String,Object>();
		params.put("codAduana", pAduana);
		params.put("codRegimen", pRegimen);
		params.put("codModulo", pModulo);
		params.put("codCambio", pCodCambio);
		params.put("numSecItem", pSecuencia);
		params.put("indEstado", "1");
		params.put("fechaVigencia", pFecha);
		return mercanciaRestringidaService.countDetCtrl(params);
		
		/*Se consulta la tabla DET_CTRLCAM:
			SELECT COUNT(*) INTO xRETORNO FROM DET_CTRLCAM
				WHERE COD_ADUANA = pAduana
				AND COD_REGIMEN  = pRegimen
				AND COD_MODULO   = pModulo
				AND COD_CAMBIO   = pCodCambio
				AND NUM_SEC_ITEM = pSecuencia
				AND TO_FECHA(pFECHA, 'YYYYMMDD')  BETWEEN FEC_INICIO AND FEC_CIERRE
				AND IND_ESTADO='1'
				AND ROWNUM=1

			RETORNA xRETORNO*/
//		return 0;
	}
	
	//fnesruc
	public static boolean esRuc(String pRuc){
		if (SunatStringUtils.length(pRuc)!=8 && SunatStringUtils.length(pRuc)!=11)
			return false;
		if (SunatStringUtils.isNumeric(pRuc)){
			Declaran paramsDeclaran=new Declaran();
			paramsDeclaran.setCtipodoc("4");
			paramsDeclaran.setCdocumen(pRuc);
			//List<Declaran> listDeclaran=FormatoAServiceImpl.getInstance().getDeclaranDAO().selectByMap(paramsDeclaran);
			
			List<Declaran> listDeclaran= (List<Declaran>)ayudaService.selectByMapDeclaran(paramsDeclaran);
			
			if (listDeclaran==null || listDeclaran.isEmpty()){
				Map<String,Object> mapDdp=PackageRucDni.getDatosPrinRUC(pRuc);
				return mapDdp!=null;
			}
			//SELECT LPAD(cdocumen,11,' ') INTO vRuc FROM declaran WHERE ctipodoc='4' AND cdocumen=vDocum
			/*Si no encuentra el RUC entonces:
				Se valida el RUC en el PRAD1 con: 
			VRUC  = pktg_rucdni.getDatosPrinRUC(vDocum)
			Si VRUC = '*' entonces: 
				RETORNA '0' 
			FinSi
			FinSi*/

		}else
			return false;
		return true;
	}
	
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	//fnGetFactor
	public static BigDecimal getFactor(String pUniOrigen, String pUniDestin, BigDecimal pCantidad){
		if (pUniOrigen.equals(pUniDestin))
			return pCantidad;
		else{
			Map<String, Object> params = new HashMap<String,Object>();
			params.put("cuniorigen", pUniOrigen);
			params.put("cunidestino", pUniDestin);
			CatConversion catConversion = (CatConversion)ayudaServiceCatConversion.buscarObject(params);
			BigDecimal valfactor = SunatNumberUtils.toBigDecimal(catConversion.getValfactor());
			return SunatNumberUtils.multiply(pCantidad, valfactor);
			/*SELECT val_factor INTO vMonto FROM cat_conversion 
			WHERE cuni_origen = puniOrigen AND cuni_destin = puniDestin  */
			//RETORNA A_NUMERO(vmonto)*pCantidad
		}
		//return null;
	}

	public MercanciaRestringidaService getMercanciaRestringidaService() {
		return mercanciaRestringidaService;
	}

	public void setMercanciaRestringidaService(
			MercanciaRestringidaService mercanciaRestringidaService) {
		this.mercanciaRestringidaService = mercanciaRestringidaService;
	}
	
	public static AyudaServiceCatConversion getAyudaServiceCatConversion() {
		return ayudaServiceCatConversion;
	}

	public static void setAyudaServiceCatConversion(
			AyudaServiceCatConversion ayudaServiceCatConversion) {
		PackageGeneral.ayudaServiceCatConversion = ayudaServiceCatConversion;
	}
	
}
