package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;

public interface ValProveFB {
	public Map<String, String> codtipparticipante(DAV dav);
	public Map<String,String> codtipdocparticipante(DAV dav);
	public Map<String, String> numdocparticipante(String arg);
	public Map<String, String> codpaisparticipante(DAV dav) ;
	public Map<String, String> dirparticipante(DAV dav);
	public Map<String, String> desubigparticipante(DAV dav) ;
	public Map<String, String> numtelefono(DAV dav) ;
	public Map<String, String> numfax(DAV dav);
	public Map<String, String> dirmailweb(DAV dav);
	public Map<String, String> dirpagweb(DAV dav);
	public Map<String, String> nomparticipante(DAV dav);
	
	//glazaror... metodos optimizados haciendo uso de variablesIngreso
	public Map<String, String> codtipparticipante(DAV dav, Map<String, Object> variablesIngreso);
	public Map<String, String> codtipdocparticipante(DAV dav, Map<String, Object> variablesIngreso);
	public Map<String, String> codpaisparticipante(DAV dav, Map<String, Object> variablesIngreso) ;
	
}
