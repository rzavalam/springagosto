/*
 * Clase que define el servicio de validaciones de las observaciones de la DUA del formato A
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoObserv;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValObserv. Clase que define el servicio de validaciones de las observaciones de la DUA del formato A.
 */
public interface ValObserv {
	
	public Map<String, String> numsecuencia(Elementos<DatoObserv> listObservaciones);
	
	public List<Map<String, String>> codtipobserva(Elementos<DatoObserv> listObservaciones);
	
	public Map<String, String> codtipobserva(String codtipobserva);
	
	public Map<String, String> obsdeclaracion(String obsdeclaracion);
	
}
