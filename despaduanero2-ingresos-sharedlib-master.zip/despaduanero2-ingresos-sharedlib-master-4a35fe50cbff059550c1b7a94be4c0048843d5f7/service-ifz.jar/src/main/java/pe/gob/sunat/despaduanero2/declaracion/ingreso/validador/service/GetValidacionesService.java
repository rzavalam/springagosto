package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAdidua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAutocer;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValContrat;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDeclaran;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDetdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDocSop;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDoctrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValEmptrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValEquipa;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValIndicad;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMGastos;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMTrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValManifc;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMcia;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocDuaregapFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValObserv;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValProduct;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValRegprec;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValRucAnexoUbic;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValTribauto;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValCabdav;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValConTransFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDeclaranteFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDescMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValFactSuc;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValFactura;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValIntermediarioFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValLibFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValObsFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValProveFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValProveLocFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValSerieItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValmontoFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif.ValRectif;

public interface GetValidacionesService {

/*	ValCabdua getValCabdua() ;

	ValAdidua getValAdidua() ;

	ValAutocer getValAutocer() ;

	ValContrat getValContrat() ;

	ValDeclaran getValDeclaran() ;

	ValDetdua getValDetdua() ;

	ValDocSop getValDocSop() ;

	ValDoctrans getValDoctrans() ;

	ValEmptrans getValEmptrans() ;

	ValEquipa getValEquipa() ;

	ValFacturaref getValFacturaref() ;

	ValIndicad getValIndicad() ;

	ValManifc getValManifc() ;

	ValMcia getValMcia() ;

	ValMGastos getValMGastos() ;

	ValMTrans getValMTrans() ;

	ValObserv getValObserv() ;

	ValPrecinto getValPrecinto() ;

	ValProduct getValProduct() ;

	ValRucAnexoUbic getValRucAnexoUbic() ;

	ValRegprec getValRegprec() ;

	ValTribauto getValTribauto() ;

	ValVehiculo getValVehiculo() ;

	ValNegocNumeracFormA getValNegocNumeracFormA() ;

	ValCabdav getValCabdav() ;

	ValConTransFB getValConTransFB() ;

	ValDeclaranteFB getValDeclaranteFB() ;

	ValLibFB getValLibFB() ;

	ValDescMin getValDescMin() ;

	ValFactSuc getValFactSuc() ;

	ValFactura getValFactura() ;

	ValIntermediarioFB getValIntermediarioFB() ;

	ValItemFB getValItemFB() ;

	ValmontoFB getValMontoFB() ;

	ValObsFB getValObsFB() ;

	ValProveFB getValProveFB() ;

	ValProveLocFB getValProveLocFB() ;

	ValSerieItemFB getValSerieItem() ;

	ValidaAnexoDeclaracionService getValidaAnexoDeclaracion() ;

//	ValidacionGeneralService getValidaciongeneralservice() ;

	ValRectif getValRectif() ;

//	ValidacionGeneralService getValidacionGeneralService() ;

	AdmisionTemporalValidacionService getAdmisionTemporalValidacioneService() ;
	
	ValNegocDuaregapFormA getValNegocDuaregapFormA();*/
}
