package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public interface ValPrecedenteEERService {
	public Boolean esReimportacionEER(String codiRegi, String codiAduan, String anoPrese, String numeCorre, String numeSerie);
	public List<Map<String, String>> validarReimportacionMercancias(String codigoAduana, String numeroDeclaracion, String anioPresentacion, String numSerie);
	public void setDatosRegimenPrecedente(DUA dua, Map<String, Object> datosDSEER);
	public List<Map<String, ?>> validarSeriesMismaDSEER(DatoSerie serie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarSeriesMismoRegimenPrecedente(String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarLevanteAutorizado(DUA dua,Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);  
	public List<Map<String, ?>> validarCanalSolicitudReconocimiento(DUA dua,Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarConsignatarioDSEERPrecedente(DUA dua,Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarIncidencia(Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarFechaNumeracion(DUA dua,Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER, Date fechaReferencia); 
	public List<Map<String, ?>> validarDatosFactura(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarPesoBrutoCntBultosUniComerciales(DatoSerie serie, Map<Integer,DUA> duasPrecedentesPorSerie,  String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	public List<Map<String, ?>> validarFOBSeguroAjusteValorAduana(DatoSerie serie, Map<Integer,DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	/**
	 * Setea datos adicionales de las series que tienen regimen precedente
	 * @param serie
	 * @param tipoRegimenSeries
	 * @param duasPrecedentesPorSerie
	 * @return
	 * @author hsaenz
	 * @version 1.0
	 * @since 01/08/2018
	 */
	public List<Map<String, String>> setDatosAdicionalRegimenPrecedente (Declaracion declaracion, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie);
	//inicio lalberti	
	public List<Map<String,String>> esRegimenPrecedenteValido(DatoSerie serie);
	public List<Map<String,String>> validarDeclaracionPrecedente(DatoSerie serie,  String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie);
	public List<Map<String,String>> validarSeriePrecedente(DatoSerie serie,  String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie);
	public List<Map<String,String>> esDUAPrecedenteLegajada(DatoSerie serie, String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie);	
	public List<Map<String,String>> esDUAPrecedenteVencida(DatoSerie serie, String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie, Date fechaReferencia);
	public void setPartidaNandinaPrecedente(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentes, List<Map<String, String>> lstWarnings);
	public void setUnidadesFisicasPrecedente(DatoSerie serie,String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie, List<Map<String, String>> lstWarnings);
	public List<Map<String,String>> validarCantidadUnidadesFisicasReimportadas(DatoSerie serie, String tipoRegimenSeries, Map<Integer,DUA> duasPrecedentesPorSerie);
	//pase correccion MDEER
	public List<Map<String, String>> validarCantidadUnidadesFisicasReimportadasEnMdeer(DatoSerie serie,String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie);
	List<Map<String, ?>> validarPesoBrutoCntBultosUniComercialesEnMDEER(DatoSerie serie, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER);
	//fin lalberti
}
