package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public interface ValGeneralEERService {
	public List<Map<String, ?>> validarCategoriaDSEER (String codCategoria);
	public List<Map<String, String>> validarConsistenciaFacturaGeneral(Declaracion dseer);
	public List<Map<String, ?>> validarConsistenciaFactura(Declaracion dseer);
	public List<Map<String, ?>> validarFechaFactura(DatoFacturaref factura, Date fechaReferencia);
	public List<Map<String, ?>> validarCodigoUnidad(Integer numserie, String codigoUnidad, String tipoUnidad);
	public List<Map<String, ?>> validarIndicadoresDSEER(Elementos<DatoIndicadores> listIndicadores, String codGrupo);
	public List<Map<String, ?>> validarIndicadoresSerie(DatoSerie serie);
	public List<Map<String, String>> validarPaisEmbarcador(DUA dua);
	public List<Map<String, ?>> validarTipoyNumeroDeDocumentoDeParticipantes(Participante participante);
	public List<Map<String, String>> validarCntUnidadesComerciales(BigDecimal cntunicomer);
	public List<Map<String,?>> validarIndicadorGarantia(Declaracion declaracion);
	public List<Map<String, String>> validarPaisOrigenSerie(String codpaisorige);//mlaura PAS20181U220400008-IZV-085.
	public List<Map<String, String>> validarVigenciaPartida(DatoSerie serie);//lfloresr PAS20181U220400008
	public List<Map<String, String>> validarVigenciaTipoUnidFisicas(DatoSerie serie);//lfloresr PAS20181U220400008
	public List<Map<String, ?>> validarTNAN(Declaracion declaracion);
	public List<Map<String, ?>> validarFlete(DatoSerie serie);
	public List<Map<String, ?>> validarDatosCancelacion(DUA dua);
		
}