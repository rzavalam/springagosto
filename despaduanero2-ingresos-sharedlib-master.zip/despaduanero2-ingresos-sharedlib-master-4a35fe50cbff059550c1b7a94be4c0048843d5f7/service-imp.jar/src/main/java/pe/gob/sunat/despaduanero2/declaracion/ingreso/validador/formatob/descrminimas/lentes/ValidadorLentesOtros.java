package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/**
 * 
 * @author lalberti
 *
 */

public class ValidadorLentesOtros extends ValidadorLentesAbstract
{

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

    //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item = obtenerItem(objeto, dua);
          //lstErrores.addAll(validarNombreComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
        //AMANCILA SE COMENTA en piloto sale null este campo ya no se manda para monturas
          //lstErrores.addAll(validarSeriesDeMedida(objeto));
          lstErrores.addAll(validarMaterial(objeto));
//          lstErrores.addAll(validarTipoLente(objeto));
//          lstErrores.addAll(validarNroFocos(objeto));
//          lstErrores.addAll(validarColor(objeto));
//          lstErrores.addAll(validarTratamiento(objeto));
//          lstErrores.addAll(validarAcabado(objeto));
      }

    return lstErrores;
  }
  
  @Override
  public List<ErrorDescrMinima> validarMaterial(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesOtros otros = (LentesOtros) object;
    String nombreComercial = otros.getNombreComercial().getValtipdescri();
    String datoAValidar = otros.getMaterialLente().getValtipdescri();
    if(SunatStringUtils.isEqualTo(MONTURAS,nombreComercial)){
      if(!(SunatStringUtils.isEqualTo(PLASTICO,datoAValidar) || 
    		  SunatStringUtils.isEqualTo(TITANIO,datoAValidar) || 
    		  SunatStringUtils.isEqualTo(METAL,datoAValidar)   ||
    		  SunatStringUtils.isEqualTo(COD_ZZZ,otros.getMaterialLente().getCodtipvalor()))){
    	String[] args = new String[]{nombreComercial};
        lst.add(obtenerError("31449",otros.getMaterialLente(),args)); //error F4
      }
    }else if(SunatStringUtils.isEqualTo(LEN_CORRECT,nombreComercial)){
      if(!(SunatStringUtils.isEqualTo(CRISTAL,datoAValidar) || 
    		  SunatStringUtils.isEqualTo(RESINA,datoAValidar) || 
    		  SunatStringUtils.isEqualTo(POLICARBONATO,datoAValidar))){
    	  String[] args = new String[]{nombreComercial};
    	  lst.add(obtenerError("31449",otros.getMaterialLente(),args));//error F4
    }
    }
    return lst;
  }

}
