/*
 * Clase que define el servicio de validaciones complejas sobre los regimenes precedentes
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialNacionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
//import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValTratoPreferencialNacional. Clase que define el servicio de validaciones TratoPreferencialNacional
 */
public class TratoPreferencialNacionalServiceImpl extends ValDuaAbstract implements TratoPreferencialNacionalService {
	
	//private FabricaDeServicios fabricaDeServicios;

	/**
	 * Realiza las validaciones sobre el TPN 93.<br> 
	 * @param declaracion Declaracion
	 * @return Lista de errorres
	 */
	public List<Map<String,String>> validarTratoPreferencialNacional93(DatoSerie datoSerie){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();

			int numSerieDUA = datoSerie.getNumserie();

			if (datoSerie.getCodtratprefe() == ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93){
				int cantidadRegimen = 0;
				for (DatoRegPrecedencia datoTemp : datoSerie.getListRegPrecedencia()){
					if (ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION.equals(datoTemp.getCodregipre())){
						cantidadRegimen++;
						// RTINEO OPTIMIZACION
						break;
					}
				}
				if(datoSerie.getListRegPrecedencia().isEmpty()){
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35014", new String[]{String.valueOf(numSerieDUA)}));
				}else{
					if (cantidadRegimen == 0){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35010", new String[]{String.valueOf(numSerieDUA)}));					
					}
				}
												
			}
			
			Map<String, Object> datosConsignadosCRMF=new HashMap<String, Object>();
			boolean indicador = false;
			for(DatoRegPrecedencia datoRegPrecedencia:datoSerie.getListRegPrecedencia()){
				String mregi_proce=datoRegPrecedencia.getCodregipre();
				String numCertificadoXML = datoRegPrecedencia.getNumdeclpre();
				String codAduanaXML = datoRegPrecedencia.getCodaduapre();
				String anioCertificadoXML = SunatStringUtils.substringFox(datoRegPrecedencia.getAnndeclpre(), 1,4);
				int numItemXML = datoRegPrecedencia.getNumserpre();
				Integer fecVencimientoXML = SunatDateUtils.getIntegerFromDate(datoRegPrecedencia.getFecvencpre());
//OMA PAS20181U220200004
				//String undEquivalentesXML = datoSerie.getDatoProductoTmp().getCodtipoequi();
				
				/** Validar si se transmiten tanto los datos del certificado dentro de las serie de la declaraci�n, asi como el valor del TPN */
				if (mregi_proce.equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){
					indicador = true;
					datosConsignadosCRMF.put("codAduanaXML", codAduanaXML);
					datosConsignadosCRMF.put("numCertificadoXML", numCertificadoXML);
					datosConsignadosCRMF.put("anioCertificadoXML", anioCertificadoXML);
					datosConsignadosCRMF.put("numItemXML", numItemXML);
					datosConsignadosCRMF.put("fecVencimientoXML", fecVencimientoXML);
					// RTINEO OPTIMIZACION
					break;
				}
			}
			
			if (indicador){
//				if(datoSerie.getCodtratprefe()==ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93 && datosConsignadosCRMF.containsValue(null)==true){
//					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35014", new String[]{String.valueOf(numSerieDUA)}));					
//				}
				
				if(datoSerie.getCodtratprefe()!=ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93 && datosConsignadosCRMF.containsValue(null)==false){
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35015", new String[]{String.valueOf(numSerieDUA)}));					
				}
			}
		return result;
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/
	

	
}
