package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtraAduana;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class ComparadorDeclaracionDeposito extends ComparadorDeclaracion {
	
	public ComparadorDeclaracionDeposito(FabricaDeServicios fabricaDeServicios){
		super(fabricaDeServicios);
	}
	/**
	 * Comparacion cab declara.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacion(Object rectificado, Object anterior) throws Exception {
		Declaracion declaraRecti=(Declaracion)rectificado;
		Declaracion declaraOld=(Declaracion)anterior;
		
		DUA duaRectificado = declaraRecti.getDua();
		DUA duaActual = declaraOld.getDua();
		
        super.comparacion(rectificado, anterior)    ;
        comparacionRucDeposito(declaraRecti.getDua(), declaraOld.getDua());
		// similar a numeracion si no tiene ruc anexo no se toma encuenta
		if (duaActual.getNumrucdeposito() != null || duaRectificado.getNumrucdeposito() != null)
			comparacionFinUbicacion(duaRectificado, duaActual);
	}
	
	public void comparacionCabDeclara(DUA duaRecti, DUA duaOld) throws Exception {

		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		String codTabla = ConstantesDataCatalogo.TABLA_CAB_DECLARA;
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codregimen"), datos, "COD_REGIMEN", "dua.codregimen",
				"./userram:AssociatedCrossBorderCustomsProcedure/ram:TypeCode");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codaduanaorden"), datos, "COD_ADUANA", "dua.codaduanaorden",
				"./userram:AssociatedCrossBorderCustomsProcedure/ram:DeclarationLodgementLogisticsLocation/ram:ID");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codmodalidad"), datos, "COD_MODALIDAD", "dua.codmodalidad",
				"./userram:AssociatedCrossBorderCustomsProcedure/ram:TransactionNatureCode");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codlugarecepcion"), datos, "COD_LUGARRECEP", "dua.codlugarecepcion",
				"./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:TypeCode");
		
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtiplugarrecep"), datos, "COD_TIPLUGARRECEP", "dua.codtiplugarrecep",
				"./userram:ExaminationTransportEvent/ram:Occur)renceLogisticsLocation/ram:TypeCode");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codanexo"), datos, "COD_LOCALANEXO", "dua.codanexo",
				"./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:SubordinateSubordinateLocation/ram:ID");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttpesobruto"), datos, "CNT_PESOBRUTO_TOTAL", "dua.cnttpesobruto",
				"./userram:GrossWeightMeasure");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttpesoneto"), datos, "CNT_PESONETO_TOTAL", "dua.cnttpesoneto",
				"./userram:NetWeightMeasure");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotfobclvta"), datos, "MTO_TOTFOBDOL", "dua.mtotfobclvta", "./userram:FOBAmount");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotflecomex"), datos, "MTO_TOTFLETEDOL", "dua.mtotflecomex", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotsegotros"), datos, "MTO_TOTSEGDOL", "dua.mtotsegotros",
				"./userram:InsuranceValueAmount");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtovaladuana"), datos, "MTO_TOTVALORADU", "dua.mtovaladuana",
				"./userram:DeclaredValueForCustomsAmount");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotajustes"), datos, "MTO_TOTAJUSTESDOL", "dua.mtotajustes", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cntnumseries"), datos, "CNT_TOTSERIES", "dua.cntnumseries",
				"./userram:ConsignmentItemQuantity");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttcantbulto"), datos, "CNT_TOTBULTOS", "dua.cnttcantbulto",
				"./userram:PackageQuantity");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numruclugarecep"), datos, "COD_RUCLUGRECEP", "dua.numruclugarecep",
				"./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:ID");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtototautoliq"), datos, "MTO_TOTAUTOLIQ", "dua.mtototautoliq",
				"./userram:AssociatedCrossBorderCustomsProcedure/ram:TotalPayableAmount");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttqunifis"), datos, "CNT_TQUNIFIS", "dua.cnttqunifis",
				"./userram:AssociatedCrossBorderCustomsProcedure/ram:TariffQuantity");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codpropiedad"), datos, "COD_PROPIEDAD", "dua.codpropiedad", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipoplazo"), datos, "COD_TIPOPLAZO", "dua.codtipoplazo", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttqunicom"), datos, "CNT_TQUNICOM", "dua.cnttqunicom", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numplazosol"), datos, "NUM_PLAZOSOL", "dua.numplazosol", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipotratamiento"), datos, "COD_TIPTRATMERC", "dua.codtipotratamiento", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codprodurgente"), datos, "COD_PRODURGENTE", "dua.codprodurgente", null);

		Date fecfinprovsionalRecti = duaRecti.getFecfinprovsional();
		Date fecfinprovsionalActu = duaOld.getFecfinprovsional();
		if (fecfinprovsionalRecti == null)
			fecfinprovsionalRecti = SunatDateUtils.getDateFromInteger(99991231); // valor por defaul 99991231

		if (fecfinprovsionalActu == null)
			fecfinprovsionalActu = SunatDateUtils.getDateFromInteger(99991231); // valor por defaul 99991231

		agregarCambioAtributo(comparaAtributo(fecfinprovsionalRecti, fecfinprovsionalActu), datos, "FEC_FINPROVSIONAL", "dua.fecfinprovsional", null);

		// para la regularizacion - Se comento por INC 2017-021105 - Pase PAS20175E220200024
		//agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "fecregulariza"), datos, "FEC_REGULARIZA", "dua.fecregulariza", null);
		//agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "fecvencregula"), datos, "FEC_VENCREGULA", "dua.fecvencregula", null);

		// dato pago Declaracion
		// dato pago transaccion
		DatoPago pagoRec = duaRecti.getPago();
		DatoPago pagoOrig = duaOld.getPago();

		if (pagoRec == null)
			pagoRec = new DatoPago();
		if (pagoOrig == null)
			pagoOrig = new DatoPago();

		DatoPagoDecla datPagoDecRec = pagoRec.getPagoDeclaracion();
		DatoPagoDecla datoPagoDecOrig = pagoOrig.getPagoDeclaracion();

		DatoPagoTrans datPagoTraRec = pagoRec.getPagoTransaccion();
		DatoPagoTrans datoPagoTraOrig = pagoOrig.getPagoTransaccion();

		agregarCambioAtributo(comparaAtributo(datPagoDecRec, datoPagoDecOrig, "codgarantia"), datos, "NUM_CTACTE","dua.pago.pagoDeclaracion.codgarantia", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "codmodpago"), datos, "COD_MODPAGO","dua.pago.pagoTransaccion.codmodpago", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "codentipago"), datos, "COD_ENTIPAGO","dua.pago.pagoTransaccion.codentipago", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "numplazcredito"), datos, "CNT_PLZCREDITO","dua.pago.pagoTransaccion.numplazcredito", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "feccarcr"), datos, "FEC_CARCR","dua.pago.pagoTransaccion.feccarcr", null);

		// Dato Otra Aduana
		DatoOtraAduana datOtrAduaRect = duaRecti.getOtraAduana();
		DatoOtraAduana datOtrAduOrig = duaOld.getOtraAduana();

		// comentado no se conoce la ubicacion real del atributo 17/12/2009 revisar
		/*
		 * addDiferencia(datOtrAduaRect, datOtrAduOrig,"codviatrades", datos, "COD_TIPADUDEST" , "dua.otraAduana.codviatrades", null);
		 */

		agregarCambioAtributo(comparaAtributo(datOtrAduaRect, datOtrAduOrig, "codopadusal"), datos, "COD_ADUDEST", "dua.otraAduana.codopadusal", null);
		// Dato manifiesto
		DatoManifiesto manifRecti = duaRecti.getManifiesto();
		DatoManifiesto manigOrig = duaOld.getManifiesto();

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "codaduamanif"), datos, "COD_ADUAMANIFIESTO", "dua.manifiesto.codaduamanif",
				null);

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "codtipomanif"), datos, "COD_TIPMANIFIESTO", "dua.manifiesto.codtipomanif", null);

		// comparacion especial
		String annmanifrecti = null;
		String annmaniforig = null;
		/*branch 2011-009 hosorio*/
		annmanifrecti="0";
		annmaniforig="0";
		/*branch 2011-009 hosorio fin*/
		if (manifRecti != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(manifRecti.getAnnmanif(), 4))
			annmanifrecti = manifRecti.getAnnmanif().substring(0, 4);
		if (manigOrig != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(manigOrig.getAnnmanif(), 4))
			annmaniforig = manigOrig.getAnnmanif().substring(0, 4);

		agregarCambioAtributo(comparaAtributo(annmanifrecti, annmaniforig), datos, "ANN_MANIFIESTO", "dua.manifiesto.annmanif", null);

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "nummanif"), datos, "NUM_MANIFIESTO", "dua.manifiesto.nummanif", null);

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "feciniembarque"), datos, "FEC_INIEMBARQUE", "dua.manifiesto.feciniembarque",
				null);

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "numviaje"), datos, "NUM_VIAJE", "dua.manifiesto.numviaje", null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "indSocorro"), datos, "IND_SOCORRO", null, null);

		// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

	}

	public void comparacionRucDeposito(DUA rectificado, DUA actual) throws Exception {

		if (rectificado != null && tipoComparacion.equals("N")) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC; // T0089 PARTICIPANTEDOC
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO);			
			clave.put("NUM_SECPARTIC", obtieneParticipante(ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO).getSecuenciaDeParticipantes());

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)) clave.put("NUM_SECPARTIC", Long.parseLong("0"));
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numrucdeposito"), datos, "NUM_DOCIDENT", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}
	
	public void comparacionFinUbicacion(DUA duaRecti, DUA duaOld) throws Exception {
		String codTabla = ConstantesDataCatalogo.TABLA_FINYUBICACION;
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);
		String tipoCambio = evaluarCambioRegistro(duaRecti.getNumrucdeposito(), duaOld.getNumrucdeposito());
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		//agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "desfinalidad"), datos, "DES_FINALIDAD" );

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codlocalanexo"), datos, "COD_LOCALANEXO");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numrucdeposito"), datos, "NUM_DOC_LOCMERC");
		
		// agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "rucAnexoUbicacion.tipoDocumentoIdentidad.codDatacat"), datos, "COD_TIPDOCLOCMERC");
		
		// agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

		agregarCambioRegistro(codTabla, clave, datos, tipoCambio);		
	}

}
