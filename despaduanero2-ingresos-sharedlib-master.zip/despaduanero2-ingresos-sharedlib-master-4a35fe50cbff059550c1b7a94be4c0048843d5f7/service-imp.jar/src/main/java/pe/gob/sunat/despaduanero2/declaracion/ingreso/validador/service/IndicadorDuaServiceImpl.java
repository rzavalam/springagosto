package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.ArrayList;//P46-PAS20155E410000032
import java.util.HashMap;
import java.util.List; // P46
import java.util.Map;

import org.springframework.util.CollectionUtils; // P46

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class IndicadorDuaServiceImpl extends ValDuaAbstract implements IndicadorDuaService  {
	//private IndicadorDUADAO indicaDuaDao;

	@Override
	public boolean esDuaRegularizable(Long numCorreDoc) {
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", numCorreDoc);
		params.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION);
		params.put("ind_activo", ConstantesDataCatalogo.IND_ACTIVO);
		int existeIndicador = ((BigDecimal) indicaDuaDao.existsIndicadorByDocumentoAndCodigo(params).get("CANT")).intValue();

		if (existeIndicador > 0) {
			return true;
		}

		return false;

	}
	//P46 EJHM INICIO
	public Map<String, Object> obtenerIndicadoresDonacion(Long numCorreDoc) 
	{
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object>  mapaIndicador=null;


		Map<String, Object> paramsInd=new HashMap<String, Object>();
		paramsInd.put("listaTipoIndica",new String[] { ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL});
		paramsInd.put("NUM_CORREDOC",numCorreDoc);
		List<Map<String, Object>> lista = indicaDuaDao.findByDocumentoAndTipo(paramsInd);

		if(!CollectionUtils.isEmpty(lista)){
			mapaIndicador=lista.get(0);
		}
		return mapaIndicador;
	}
	//P46 EJHM FIN

	/**
	 * Verifica si transmitio el indicador de despacho anticipado sin validaci�n de los datos del manifiesto de carga (ISVM) 
	 */
	public boolean tieneIndicadorManifiesto(Declaracion declaracion, String codTransaccion) {
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		boolean existeIndManif = false;

		//Si tiene canal o registra el indicador de que ya se realiz� el Datado se devuelve false y procede a realizar validaciones 
		if (declaracion.getDua().getNumcorredoc() != null) {
			Map<String, Object> paramsInd=new HashMap<String, Object>();
			paramsInd.put("listaTipoIndica",new String[] { ConstantesDataCatalogo.INDICADOR_DECLARACION_DATADA});
			paramsInd.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			paramsInd.put("COD_TIPOREGISTRO", Constants.COD_TIPOREGISTRO);
			List<Map<String, Object>> lista = indicaDuaDao.findByDocumentoAndTipo(paramsInd);

			if(!CollectionUtils.isEmpty(lista) || !SunatStringUtils.isEmptyTrim(declaracion.getDua().getCodCanal()))
				return existeIndManif;
		}
		
		//Si cuenta con indicador de ISVM 
		if (!CollectionUtils.isEmpty(getListIndicadorByTipo(declaracion.getDua(),ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO))) {
			//Si es invocado por Procesos Automaticos
			if (codTransaccion == ConstantesDataCatalogo.TRANS_PROCESO_AUTOMATICO_DUMMY){
				existeIndManif = false;
			} else{
				existeIndManif = true;
			}			
		}
		return existeIndManif;
	}
	
	public DatoIndicadores obtenerIndicadorDeclaracion(String numCorreDoc, String codIndicador) { 
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object> parametros = new HashMap<String, Object>();
		DatoIndicadores indicadorDeclaracion = null;
		parametros.put("num_corredoc", numCorreDoc);
		parametros.put("cod_indicador", codIndicador);
		indicadorDeclaracion = indicaDuaDao.obtenerIndicadorDeclaracion(parametros);
		return indicadorDeclaracion;
	}
	
	public void insertarIndicadorDeclaracion(String numCorreDoc, String codIndicador, String codTipoRegistro) { 
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		DatoIndicadores indicador = new DatoIndicadores();
		indicador.setNumeroCorrelativo(SunatNumberUtils.toLong(numCorreDoc));
		indicador.setCodigoIndicador(codIndicador);
		indicador.setCodigoTipoRegistro(codTipoRegistro);
		//si no tiene indicador 28 registralo
		if(indicaDuaDao.existeIndicadorByParams(indicador).compareTo(0) == 0){
			indicaDuaDao.insert(indicador);
		}
	}

	//ini P46-PAS20155E410000032
	/**
	 * Metodo que permite obtener el listado de indicadores a partir del mapa
	 * que contiene los datos de la declaracion que se encuentra en sesion
	 * 
	 * @param mapCabDeclaraActual
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> obtenerListadoIndicadoresEnSesion(Map<String, Object> mapCabDeclaraActual) {
		List<Map<String, Object>> lIndicadorDua = new ArrayList<Map<String, Object>>();
		
		if(mapCabDeclaraActual.get("lstIndicadorDuaActual") != null) {        	
			lIndicadorDua = (List<Map<String,Object>>)mapCabDeclaraActual.get("lstIndicadorDuaActual");
		} else if(mapCabDeclaraActual.get("LIST_INDICADORES_DUA") != null) {
			lIndicadorDua = (List<Map<String,Object>>)mapCabDeclaraActual.get("LIST_INDICADORES_DUA");
		}
		
		return lIndicadorDua;
	}
	//fin P46-PAS20155E410000032
	

	
	/**
	 * Inserta el indicador de acuerdo a los parametros, en caso de existir lo activa.
	 */
	public void insertaActualizaIndicador(Map<String, Object> params){
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		DatoIndicadores indicador = new DatoIndicadores();
		indicador.setNumeroCorrelativo(SunatNumberUtils.toLong(params.get("numCorredoc")));
		indicador.setCodigoIndicador(SunatStringUtils.toStringObj(params.get("codIndicador")));		
		indicador.setCodigoTipoRegistro(SunatStringUtils.toStringObj(params.get("codTiporegistro")));
		if(indicaDuaDao.existeIndicadorByParams(indicador).compareTo(0) == 0){			
			indicaDuaDao.insert(indicador);
		} else{
			this.actualizaIndicador(params);	
		}		
	}
	
	public void actualizaIndicador(Map<String, Object> params){
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		indicaDuaDao.update(params);	
	}

	//ggranados legajo
	public Integer existeIndicadorByParams(DatoIndicadores indicador){
		IndicadorDUADAO indicaDuaDao = (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");
		return indicaDuaDao.existeIndicadorByParams(indicador);
	}
	
	/*
	public IndicadorDUADAO getIndicaDuaDao() {
		return indicaDuaDao;
	}

	public void setIndicaDuaDao(IndicadorDUADAO indicaDuaDao) {
		this.indicaDuaDao = indicaDuaDao;
	}*/

}
