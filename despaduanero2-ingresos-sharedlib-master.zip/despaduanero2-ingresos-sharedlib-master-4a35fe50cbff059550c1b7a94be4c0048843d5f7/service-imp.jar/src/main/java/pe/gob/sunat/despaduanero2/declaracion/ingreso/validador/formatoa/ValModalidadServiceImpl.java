package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;

public class ValModalidadServiceImpl extends ValDuaAbstract implements ValModalidadService {
	
	//private CatalogoAyudaService catalogoAyudaService;

	@Override
	public boolean correspondeModalidadAnticipada(Date fechaNumeracion, Date fechaLlegada) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean correspondeModalidadAnticipada = true;
		DataCatalogo catPlazoModalidadAnticipada = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA, fechaNumeracion);
		Integer plazoModalidadAnticipada = SunatNumberUtils.toInteger(catPlazoModalidadAnticipada.getDesCorta());
		Date fecMaxPlazoModalidadAnticipada = SunatDateUtils.addDay(fechaNumeracion, plazoModalidadAnticipada);
		
		if(SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracion, fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ||
				SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoModalidadAnticipada, SunatDateUtils.COMPARA_SOLO_FECHA)){
			correspondeModalidadAnticipada = false;
		}
		
		return correspondeModalidadAnticipada;
	}

	@Override
	public boolean correspondeModalidadDiferida(Date fechaNumeracion, Date fechaDescarga) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean correspondeModalidadDiferida = true;
		DataCatalogo catPlazoModalidadDiferida = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_DIFERIDA, fechaNumeracion);
		Integer plazoModalidadDiferida = SunatNumberUtils.toInteger(catPlazoModalidadDiferida.getDesCorta());
		Date fecMaxPlazoModalidadDiferida = SunatDateUtils.addDay(fechaDescarga, plazoModalidadDiferida); 
		
		if(SunatDateUtils.esFecha1MayorQueFecha2(fechaDescarga, fechaNumeracion, SunatDateUtils.COMPARA_SOLO_FECHA) ||
				SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracion, fecMaxPlazoModalidadDiferida, SunatDateUtils.COMPARA_SOLO_FECHA)){
			correspondeModalidadDiferida = false;
		}

		return correspondeModalidadDiferida;
	}

	@Override
	public boolean correspondeModalidadUrgente(Date fechaNumeracion, Date fechaLlegada, Date fechaDescarga) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean correspondeModalidadUrgente = true;
		DataCatalogo catPlazoModalidadUrgenteDescarga = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_URGENTE_FECHA_DESCARGA, fechaNumeracion);
		Integer plazoModalidadUrgenteDescarga = SunatNumberUtils.toInteger(catPlazoModalidadUrgenteDescarga.getDesCorta());
		
		//PAS20165E220200127
		if(fechaDescarga != null && !SunatDateUtils.isDefaultDate(fechaDescarga)){	
			Date fecMaxPlazoModalidadUrgenteDescarga = SunatDateUtils.addDay(fechaDescarga, plazoModalidadUrgenteDescarga);
			//if(SunatDateUtils.esFecha1MayorQueFecha2(fechaDescarga, fechaNumeracion, SunatDateUtils.COMPARA_SOLO_FECHA) ||
			if(SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracion, fecMaxPlazoModalidadUrgenteDescarga, SunatDateUtils.COMPARA_SOLO_FECHA)){
				correspondeModalidadUrgente = false;
				return correspondeModalidadUrgente;
			}		
		}

		DataCatalogo catPlazoModalidadUrgenteLlegada = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_URGENTE_FECHA_LLEGADA, fechaNumeracion);
		Integer plazoModalidadUrgenteLlegada = SunatNumberUtils.toInteger(catPlazoModalidadUrgenteLlegada.getDesCorta());
		Date fecMaxPlazoModalidadUrgenteLlegada = SunatDateUtils.addDay(fechaNumeracion, plazoModalidadUrgenteLlegada);
		
		//if(SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracion, fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ||
		if(SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoModalidadUrgenteLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)){
			correspondeModalidadUrgente = false;
		}

		return correspondeModalidadUrgente;
	}

	/*
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}*/


}
