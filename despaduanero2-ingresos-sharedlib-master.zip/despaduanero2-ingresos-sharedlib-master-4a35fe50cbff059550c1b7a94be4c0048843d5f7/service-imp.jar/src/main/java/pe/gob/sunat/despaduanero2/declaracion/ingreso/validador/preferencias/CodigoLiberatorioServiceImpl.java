package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils; //P46

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService; //P46
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils; //P46
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.model.bean.T1179Bean;

/**
 * Validaciones cetralizadas correspondiente a Codigos Liberatorios 
 * @author rbegazo
 *
 */
public class CodigoLiberatorioServiceImpl extends IngresoAbstractServiceImpl implements CodigoLiberatorioService {

	//private FabricaDeServicios	fabricaDeServicios;
	//private CatalogoHelperImpl catalogoHelper;
	
	@ServicioAnnot(tipo="V",codServicio=3389, descServicio="Validar si corresponde el acogimiento al c�digo liberatorio de acuerdo a La Ley N� 29482 - Ley de Promoci�n para el desarrollo de Actividades Productivas en Zonas Alto Andinas.")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"dua","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3389,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>> valZonasAltoAndinas(DUA dua, Date fechaReferencia){
		CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		List<DatoSerie> listseries = dua.getListSeries();
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Integer contZona2500M = 0;
		Integer contZona3200M = 0;
		Integer contOtros = 0;
		for(DatoSerie serie:listseries){
			Integer codliberatorio = serie.getCodliberatorio();
			if (codliberatorio > 0) { 
				if (codliberatorio.equals(ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_2500M)){
					contZona2500M++;				
				}
				if (codliberatorio.equals(ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_3200M)){
					contZona3200M++;
				}
				if (!codliberatorio.equals(ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_3200M) && !codliberatorio.equals(ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_2500M)){
					contOtros++;
				}				
				if (contZona2500M > 0  && contOtros > 0){
					//Esta consignando en las series el codigo liberatorio 4464, por lo que solo  deber�a consignar unicamente codigos liberatorios de Zona Altoandinas
					listError.add(catalogoAyudaService.getError("30729", new String[] {serie.getNumserie().toString(),codliberatorio.toString(),ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_2500M.toString()}));
				}
				if (contZona3200M > 0  && contOtros > 0){
					//Esta consignando en las series el codigo liberatorio 4465, por lo que solo  deber�a consignar unicamente codigos liberatorios de Zona Altoandinas
					listError.add(catalogoAyudaService.getError("30729", new String[] {serie.getNumserie().toString(),codliberatorio.toString(),ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_3200M.toString()}));					
				}
				if (contZona2500M > 0  && contZona3200M  > 0){
					//Esta consignando simultaneament el codigo 4464 y 4465 en varias series, por lo que solo  deber�a consignar uno de ellos
					listError.add(catalogoAyudaService.getError("30730", new String[] {serie.getNumserie().toString(),codliberatorio.toString()}));
				}
			}
		}
		if (contZona2500M > 0 || contZona3200M > 0 ){
			listError.add(valImportadorZonaAltoAndina(dua.getDeclarante()));
			if (contZona2500M > 0){
				listError.add(this.valUbigeoZonaAltoAndina(dua.getDeclarante(), ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_2500M, fechaReferencia));
			}
			if (contZona3200M > 0){
				listError.add(this.valUbigeoZonaAltoAndina(dua.getDeclarante(), ConstantesDataCatalogo.CODILIBER_ZONALTOANDINA_3200M, fechaReferencia));
			}
		}
		return listError;
	}
	
	/**
	 * Verifica si un importador puede acogerse a liberacion de Zonas AltoAndinas
	 * @param declarante
	 * @return
	 */
	private Map<String, String> valImportadorZonaAltoAndina(Participante declarante){
		CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
		Map<String, String> listError = new HashMap<String, String>();
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		String tipodocum = declarante.getTipoDocumentoIdentidad().getCodDatacat();
		String numedocum = declarante.getNumeroDocumentoIdentidad();
		T1179Bean ageret = preferenciaArancelariaService.consultarImportadorAltoAndino(tipodocum, numedocum);
		if (ageret == null || ageret.getInd_est().equals(ConstantesDataCatalogo.ESTADO_AGENTE_BAJA)){
			//Importador no se corresponde a zona altoandina
			listError = catalogoAyudaService.getError("30727", new String[] {tipodocum.concat("-").concat(numedocum) });
		}
		return listError;
	}
	
	/**
	 * Verifica si la ubicacion geografica del importador corresponde a una zona AltoAndina
	 * @param declarante
	 * @param codConvenio
	 * @param fechaReferencia
	 * @return
	 */
	private Map<String, String> valUbigeoZonaAltoAndina(Participante declarante, Integer codConvenio, Date fechaReferencia){
		CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
		Map<String, String> listError = new HashMap<String, String>();
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String tipodocum = declarante.getTipoDocumentoIdentidad().getCodDatacat();
		String numedocum = declarante.getNumeroDocumentoIdentidad();
		String codUbigeo = preferenciaArancelariaService.consultarUbigeoImportadorPreferenciaArancelaria(tipodocum, numedocum);
		if (funcionesService.getRefPartidas(
				ConstantesDataCatalogo.PARTIDAS_ZONA_ALTOANDINA, null, null, null, codConvenio.toString(), codUbigeo, null, null, SunatDateUtils.getIntegerFromDate(fechaReferencia), null) == null){
			listError = catalogoAyudaService.getError("30728", new String[] {codUbigeo });
		}
		return listError;
	}

	//P46 INICIO
	public boolean serieTieneCodLiberatorioDonacion (Integer codLiberatorio){
		
//		String[] arrayCodLibeDonacion = new String[] {
//                ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
//                ConstantesDataCatalogo.COD_LIBE_DONA_IMPO_FINANCIACION,
//                ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
//                ConstantesDataCatalogo.COD_LIBE_DONA_SECTOR_PUBLICO,
//                ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_POR_CONVENIO,
//                ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS,
//                ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_SECTOR_PUBLICO }; 
		CatalogoValidaService catalogoValidaService = this.fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		//List<Map<String, String>> resultado = catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_ESTADOS_PARA_ACTUALIZAR_LEVANTE, codLiberatorio);
		List<Map<String, String>> resultado = catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_COD_LIBERATORIOS_PARA_DONACION, codLiberatorio.toString());
		boolean EsCodLibeDonacion = (resultado.isEmpty() ? true : false );
		
		//return (SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion));
		return (EsCodLibeDonacion);//PAS20171U220200003
	}
	public boolean   serieTieneCodLiberatorioDonacion20012002(Integer codLiberatorio, Integer numSerieDUA){
			
		String[] arrayCodLibeDonacion20012002 = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS,
		};	

		return SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion20012002);

	}

	public List<Map<String, String>> duaTieneCodigoLiberatorio (DUA dua){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		List<DatoSerie> lstSerie = dua.getListSeries();
		
		for (DatoSerie datoSerie : lstSerie) {
			int numSerieDUA = datoSerie.getNumserie();
			Integer codLiberatorio = datoSerie.getCodliberatorio();

			if (codLiberatorio != 0){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35430", new String[]{String.valueOf(numSerieDUA)}));
			}
		}
		return result;
	}
	public List<Map<String, String>> validarCodigoLiberatorioporSerieDonacion(DUA dua){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		List<DatoSerie> 		 lstSeries 		 	 	 = dua.getListSeries();
		if(!CollectionUtils.isEmpty(lstSeries)){
			for (DatoSerie datoSerieDocSoporteTemp : lstSeries) {
			 if (datoSerieDocSoporteTemp.getCodliberatorio()!=0){
				
				if(!serieTieneCodLiberatorioDonacion( datoSerieDocSoporteTemp.getCodliberatorio())){
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35447",new String[] {datoSerieDocSoporteTemp.getNumserie().toString(),datoSerieDocSoporteTemp.getCodliberatorio().toString()}));
				   }
			 }	
			}		
		}			   
		return result;
	}
	
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
