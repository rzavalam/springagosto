package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * @author lalberti
 * @version 1.0
 */

public class ValidadorCalzadoCueroNatural extends ValidadorCalzadoAbstract
{
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    // TODO Auto-generated method stub
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErrores))
      {
          DatoItem item = obtenerItem(objeto,dua);
		  lstErrores.addAll(validarUnidadComercial(objeto, item));
		  lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
		  lstErrores.addAll(validarModelo(objeto));
		//lstErrores.addAll(validarTallaCalzado(objeto));
//		  lstErrores.addAll(validarPorcentajeOrigenCuero(objeto));//arey se comenta por cierre vig del CA0105
		  lstErrores.addAll(validarConstruccion(objeto));
//		  lstErrores.addAll(validarPorcentajeAcabadoCuero(objeto));//arey se comenta por cierre vig del CA0107
      }
    return lstErrores;
  }
  
  public List<ErrorDescrMinima> validarOrigenCuero(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
    
  public List<ErrorDescrMinima> validarPorcentajeOrigenCuero(ModelAbstract object){
	List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	CalzadoCueroNatural calzado = (CalzadoCueroNatural) object;
	String datoAValidar  = calzado.getPorcentajeOrigenCuero().getValtipdescri();
	if(!SunatStringUtils.isEmptyTrim(datoAValidar)){
		lst.add(obtenerError("31383", calzado.getPorcentajeOrigenCuero()));
	}
    return lst;
  }
  
  public List<ErrorDescrMinima> validarAcabadosCuero(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarPorcentajeAcabadoCuero(ModelAbstract object){
	List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	CalzadoCueroNatural calzado = (CalzadoCueroNatural) object;
	String datoAValidar  = calzado.getPorcentajeAcabadoCuero().getValtipdescri();
	if(!SunatStringUtils.isEmptyTrim(datoAValidar)){
		lst.add(obtenerError("31386", calzado.getPorcentajeAcabadoCuero()));
	}
	return lst;
  }

}
