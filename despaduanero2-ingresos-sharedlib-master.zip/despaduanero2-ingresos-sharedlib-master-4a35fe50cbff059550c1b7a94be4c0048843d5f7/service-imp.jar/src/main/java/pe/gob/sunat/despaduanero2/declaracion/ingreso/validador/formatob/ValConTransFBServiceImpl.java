package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValConTransFBServiceImpl  extends ValDuaAbstract implements ValConTransFB{

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos. En esta secci�n pueden enviar m�s de un c�digo de
	 * condici�n de la transacci�n, validar que se envie los 15 c�digos del
	 * cat�logo y que no se repitan
	 * 
	 * @param codindcondtra
	 * @return
	 */
	
	public List<Map<String, String>> codindcondtra(DAV dav) {

		List<Map<String, String>> result = new ArrayList<Map<String,String>>(); 
		
        if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
            return result;
        }
		
		if( dav.getListCondTransacciones() != null )
		{
			if(dav.getListCondTransacciones().size() > 0)
			{
				if(dav.getListCondTransacciones().size() == 1)	{
					boolean existsInCatalog = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("301", dav.getListCondTransacciones().get(0).getCodindcondtra()));					
					//boolean existsInCatalog = catalogoHelper.isValid(dav.getListCondTransacciones().get(0).getCodindcondtra(), "301");					
					if(! existsInCatalog )
						result.add( getErrorMap("30118", new Object[]{dav.getNumsecuprov(),dav.getListCondTransacciones().get(0).getCodindcondtra()}));
					
				}else if(dav.getListCondTransacciones().size() == 15){
					
				 	for(DatoCondTransaccion condTransaccion:dav.getListCondTransacciones())	{
				 		boolean existsInCatalog = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("301", condTransaccion.getCodindcondtra()));
						//boolean existsInCatalog = catalogoHelper.isValid(condTransaccion.getCodindcondtra(), "301");
						
						if(! existsInCatalog )
							result.add( getErrorMap("30118" , new Object[]{dav.getNumsecuprov(),condTransaccion.getCodindcondtra()}));
				 	}
					
				}else{
					//TODO set errorCode hay mas de un codigo y no son 15
					result.add( getErrorMap("30118" , new Object[]{dav.getNumsecuprov(),dav.getListCondTransacciones().get(0).getCodindcondtra()}));
				}
			}			
		}
		
		return result;
	}

	/**
	 * Validar que se envie este dato, los valores v�lidos para el indicador del
	 * tipo de condicion de la transacci�n son "1":Afirmativo. "2":Negativo, de
	 * no ser asi se generan errores por cada uno de los 15 c�digos de la
	 * condici�n de la transacci�n. Solo si el codindcondtra es '02' � '03' el
	 * indcontra puede enviarse en blanco siempre y cuando para el codindcontra
	 * '01' el indcontra enviado es '2'
	 * 
	 * @param indcondtra
	 * @return
	 */
	public List<Map<String, String>> indcondtra(DAV dav) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>(); 
		
        if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
            return listErr;
        }
		
		if(dav.getListCondTransacciones() == null || dav.getListCondTransacciones().size() == 0){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			//listErr.add( getCatalogoHelper().getErrorMap("30119") );
			//glazaror... hacemos uso de catalogoAyudaService.getError
			listErr.add( catalogoAyudaService.getError("30119") );
			return listErr; 
		}
		
		String vinc_proex = "";
		String infl_preci = "";
		String pvatr12b = "";
		String prece1 = "";
		String pconmcia = "";
		String pdecond = "";
		String spag_indir = "";
		String pdesret = "";
		String sder_licen = "";
		String vent_condi = "";
		String contmcia = "";
		String contsumi = "";
		String claurevi = "";
		String intimpcli = "";
		String difvalasi = "";
		
		for(DatoCondTransaccion condTrans: dav.getListCondTransacciones()){
			if(condTrans.getCodindcondtra().equals("01")) vinc_proex = condTrans.getIndcondtra();				
			if(condTrans.getCodindcondtra().equals("02")) infl_preci = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("03")) pvatr12b = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("04")) prece1 = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("05")) pconmcia = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("06")) pdecond = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("07")) spag_indir = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("08")) pdesret = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("09")) sder_licen = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("10")) vent_condi = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("11")) contmcia = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("12")) contsumi = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("13")) claurevi = condTrans.getIndcondtra();			
			if(condTrans.getCodindcondtra().equals("14")) intimpcli = condTrans.getIndcondtra();
			if(condTrans.getCodindcondtra().equals("15")) difvalasi = condTrans.getIndcondtra();				
		}
		//glazaror... evitamos el uso de catalogoHelper.getErrorMap en su lugar hacemos uso de catalogoAyudaService.getError
		String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
		if(!SunatStringUtils.isStringInList(vinc_proex, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05530", new Object[]{dav.getNumsecuprov(), vinc_proex,  "01" ,"VINCULACION CON PROVEEDOR EXTRANJERO"} ) );
			listErr.add(catalogoAyudaService.getError("05530", new String[] { numeroSecuenciaProveedor, vinc_proex, "01", "VINCULACION CON PROVEEDOR EXTRANJERO"}));
		
		if(!SunatStringUtils.isStringInList(infl_preci, "1,2, "))
			//listErr.add(getCatalogoHelper().getErrorMap("05531", new Object[]{dav.getNumsecuprov(),  infl_preci, "02","INFLUENCIA DE LA VINCULACION EN PRECIO"} ) );
			listErr.add(catalogoAyudaService.getError("05531", new String[] { numeroSecuenciaProveedor, infl_preci, "02", "INFLUENCIA DE LA VINCULACION EN PRECIO"}));
				
		if(!SunatStringUtils.isStringInList(pvatr12b, "1,2, "))
			//listErr.add(getCatalogoHelper().getErrorMap("05532", new Object[]{dav.getNumsecuprov(),  pvatr12b,	  "03" ,"APROXIMACION VALOR TRANSACCION A ART 1.2 B) OMC"} ) );
			listErr.add(catalogoAyudaService.getError("05532", new String[] { numeroSecuenciaProveedor, pvatr12b, "03", "APROXIMACION VALOR TRANSACCION A ART 1.2 B) OMC"}));
					
		if(SunatStringUtils.isEqualTo(vinc_proex,"1") &&  SunatStringUtils.isEqualTo(infl_preci," "))
			//listErr.add(getCatalogoHelper().getErrorMap("05531", new Object[]{dav.getNumsecuprov(),  infl_preci, "02","INFLUENCIA DE LA VINCULACION EN PRECIO" } ) );
			listErr.add(catalogoAyudaService.getError("05531", new String[]{numeroSecuenciaProveedor,  infl_preci, "02","INFLUENCIA DE LA VINCULACION EN PRECIO" } ) );

		if(SunatStringUtils.isEqualTo(vinc_proex,"1") &&  SunatStringUtils.isEqualTo(pvatr12b," "))
			//listErr.add(getCatalogoHelper().getErrorMap("05532", new Object[]{dav.getNumsecuprov(), pvatr12b,  "03","APROXIMACION VALOR TRANSACCION A ART 1.2 B) OMC" } ) );
			listErr.add(catalogoAyudaService.getError("05532", new String[]{numeroSecuenciaProveedor,  pvatr12b, "03","APROXIMACION VALOR TRANSACCION A ART 1.2 B) OMC" } ) );

		if(!SunatStringUtils.isStringInList(prece1, "1,2"))		
			//listErr.add(getCatalogoHelper().getErrorMap("05533", new Object[]{dav.getNumsecuprov(), prece1, "04","RESTRICCIONES CESION/UTILIZACION ART 1 OMC"} ) );
			listErr.add(catalogoAyudaService.getError("05533", new String[]{numeroSecuenciaProveedor,  prece1, "04","RESTRICCIONES CESION/UTILIZACION ART 1 OMC" } ) );

		if(!SunatStringUtils.isStringInList(pconmcia, "1,2"))		
			//listErr.add(getCatalogoHelper().getErrorMap("05534", new Object[]{dav.getNumsecuprov(), pconmcia ,"05","DEPENDE VENTA O PRECIO CON MERCANCIAS A VALORAR"} ) );
			listErr.add(catalogoAyudaService.getError("05534", new String[]{numeroSecuenciaProveedor,  pconmcia, "05","DEPENDE VENTA O PRECIO CON MERCANCIAS A VALORAR" } ) );

		if(!SunatStringUtils.isStringInList(pdecond, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05535", new Object[]{dav.getNumsecuprov(),  pdecond ,"06","PUEDE DETERMINARSE VALOR CONDICIONES"} ) );
			listErr.add(catalogoAyudaService.getError("05535", new String[]{numeroSecuenciaProveedor,  pdecond, "06","PUEDE DETERMINARSE VALOR CONDICIONES" } ) );

		if(!SunatStringUtils.isStringInList(spag_indir, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05536", new Object[]{dav.getNumsecuprov(), spag_indir ,"07" , "PAGOS INDIRECTOS DE LAS MERCANCIAS" } ) );
			listErr.add(catalogoAyudaService.getError("05536", new String[]{numeroSecuenciaProveedor,  spag_indir, "07","PAGOS INDIRECTOS DE LAS MERCANCIAS" } ) );

		if(!SunatStringUtils.isStringInList(pdesret, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05537", new Object[]{dav.getNumsecuprov(),  pdesret ,"08" ,"DESCUENTOS RETROACTIVOS" } ) );
			listErr.add(catalogoAyudaService.getError("05537", new String[]{numeroSecuenciaProveedor,  pdesret, "08","DESCUENTOS RETROACTIVOS" } ) );

		if(!SunatStringUtils.isStringInList(sder_licen, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05538", new Object[]{dav.getNumsecuprov(), sder_licen ,"09","CANONES Y DERECHO DE LICENCIA DE LAS MERCANCIAS" } ) );
			listErr.add(catalogoAyudaService.getError("05538", new String[]{numeroSecuenciaProveedor,  sder_licen, "09","CANONES Y DERECHO DE LICENCIA DE LAS MERCANCIAS" } ) );
		
		if(!SunatStringUtils.isStringInList(vent_condi, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05539", new Object[]{dav.getNumsecuprov(), vent_condi,"10","VENTA CONDICIONADA POR UN ACUERDO" } ) );
			listErr.add(catalogoAyudaService.getError("05539", new String[]{numeroSecuenciaProveedor,  vent_condi, "10","VENTA CONDICIONADA POR UN ACUERDO" } ) );
			
		if(!SunatStringUtils.isStringInList(contmcia, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05540", new Object[]{dav.getNumsecuprov(),contmcia,"11","CONTRATO RELATIVO A LAS MERCANCIAS" } ) );
			listErr.add(catalogoAyudaService.getError("05540", new String[]{numeroSecuenciaProveedor,  contmcia, "11","CONTRATO RELATIVO A LAS MERCANCIAS" } ) );
			//
		if(!SunatStringUtils.isStringInList(contsumi, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05541", new Object[]{dav.getNumsecuprov(), contsumi, "12" , "CONTRATO GLOBAL DE SUMINISTROS LARGA DURACION" } ) );
			listErr.add(catalogoAyudaService.getError("05541", new String[]{numeroSecuenciaProveedor,  contsumi, "12","CONTRATO GLOBAL DE SUMINISTROS LARGA DURACION" } ) );
			
		if(!SunatStringUtils.isStringInList(claurevi, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05542", new Object[]{dav.getNumsecuprov(), claurevi, "13" , "CLAUSULA DE REVISION DE PRECIO" } ) );
			listErr.add(catalogoAyudaService.getError("05542", new String[]{numeroSecuenciaProveedor,  claurevi, "13","CLAUSULA DE REVISION DE PRECIO" } ) );

		if(!SunatStringUtils.isStringInList(intimpcli, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05543", new Object[]{dav.getNumsecuprov(), intimpcli,"14","INTERMEDIARIO IMPORTADOR A SOLICITUD CLIENTE" } ) );
			listErr.add(catalogoAyudaService.getError("05543", new String[]{numeroSecuenciaProveedor,  intimpcli, "14","INTERMEDIARIO IMPORTADOR A SOLICITUD CLIENTE" } ) );
		
		if(!SunatStringUtils.isStringInList(difvalasi, "1,2"))
			//listErr.add(getCatalogoHelper().getErrorMap("05544",  new Object[]{dav.getNumsecuprov(), difvalasi,"15","DIFERENTE VALOR ASIGNADO EMPRESA VERIFICADORA" } ) );
			listErr.add(catalogoAyudaService.getError("05544", new String[]{numeroSecuenciaProveedor,  difvalasi, "15","DIFERENTE VALOR ASIGNADO EMPRESA VERIFICADORA" } ) );
		
		return listErr;
	}
}
