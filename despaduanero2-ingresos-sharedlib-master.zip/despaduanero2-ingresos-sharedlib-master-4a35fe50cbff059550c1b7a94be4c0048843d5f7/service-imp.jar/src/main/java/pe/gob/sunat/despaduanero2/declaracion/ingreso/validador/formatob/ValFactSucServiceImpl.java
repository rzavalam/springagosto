package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValFactSucServiceImpl extends ValDuaAbstract implements ValFactSuc{
	
/**
	 * Validar que transmita obligatoriamente los datos de la factura 
	 * por venta sucesiva (como m�nimo debe transmitir una factura, la �ltima).
	 * Validar que se envie la fecha
	 * @param facturaSucesiva
	 * @return
	 */
	public Map<String, String> validarFechaFacturaSucesiva(DatoFactSuce facturaSucesiva) {
		Map<String, String> result = new HashMap<String, String>();
		
		if (facturaSucesiva == null){
			return getErrorMap("30626",  new Object[] { 
					" ",
					" ", 
					" "});
		}
		
		if (facturaSucesiva.getFecfactsuc() == null){
			result = getErrorMap("30626",  new Object[] { 
					((DAV)facturaSucesiva.getPadre().getPadre()).getNumsecuprov(),
					((DatoFactura)facturaSucesiva.getPadre()).getNumsecfactu(), 
					facturaSucesiva.getFecfactsuc()!=null?facturaSucesiva.getFecfactsuc():" "});
		}

		return result;
	}	

	/**
	 * Validar que se envie un dato alfanumerico 
	 * @param facturaSucesiva
	 * @return
	 */
    public Map<String, String> numfactsuc(DatoFactSuce facturaSucesiva){
        Map<String, String> result = new HashMap<String, String>();
        
        if(facturaSucesiva == null){
        	return getErrorMap("30145", new Object[] {
                    " ",
                    " ",
                    " "});
        }
        
        if(facturaSucesiva.getNumfactsuc() == null){
        	return getErrorMap("30145", new Object[] {
        			((DAV) facturaSucesiva.getPadre().getPadre()).getNumsecuprov(),
        			((DatoFactura)facturaSucesiva.getPadre()).getNumsecfactu(),
                    " "});
        }

        String arg = SunatStringUtils.replace(facturaSucesiva.getNumfactsuc(), "-", "");
		arg=SunatStringUtils.replace(arg, " ", "");

        if (!SunatStringUtils.isAlphanumeric(arg)) {
            result = getErrorMap("30145", new Object[] {
                    ((DAV) facturaSucesiva.getPadre().getPadre()).getNumsecuprov(),
                    ((DatoFactura)facturaSucesiva.getPadre()).getNumsecfactu(),
                    facturaSucesiva.getNumfactsuc()});
        }
		return result;
	}

	/**
	 * Validar que sea un dato num�rico mayor a cero 
	 * @param facturaSucesiva
	 * @return
	 */
	public Map<String, String> mtofactsuc(DatoFactSuce facturaSucesiva) {

		Map<String, String> result = new HashMap<String, String>();

		if(facturaSucesiva == null){
        	return getErrorMap("30146", new Object[] {
                    " ",
                    " ",
                    " "});			
		}

		if (!SunatNumberUtils.isGreaterThanZero(facturaSucesiva.getMtofactsuc()))
			result = getErrorMap("30146",new Object[] {			        
					((DAV)facturaSucesiva.getPadre().getPadre()).getNumsecuprov(),
					((DatoFactura)facturaSucesiva.getPadre()).getNumsecfactu(), 
					facturaSucesiva.getMtofactsuc()});

		return result;
	}

	
	

	
	
	
}
