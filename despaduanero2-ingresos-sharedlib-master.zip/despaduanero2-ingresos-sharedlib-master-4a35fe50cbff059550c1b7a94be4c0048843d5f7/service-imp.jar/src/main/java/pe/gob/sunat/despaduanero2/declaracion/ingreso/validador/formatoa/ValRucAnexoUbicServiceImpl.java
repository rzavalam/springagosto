/*
 * Clase que define el servicio de validaciones de los Datos de ubicaci�n de la mercanc�a.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValRucAnexoUbic. Clase que define el servicio de validaciones de los Datos de ubicaci�n de la mercanc�a.
 */
public class ValRucAnexoUbicServiceImpl extends ValDuaAbstract implements ValRucAnexoUbic {

	//private FabricaDeServicios fabricaDeServicios;

	/**
	 * Valida el Tipo participante.
	 * 
	 * @param tipoParticipante DataCatalogo
	 * @return el mapa de errores
	 */
	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante){
		String codtipparticipante=tipoParticipante.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("316", codtipparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("316", codtipparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("","Error catalogo codtipparticipante");	
	}

	/**
	 * Valida el Tipo documento identidad.
	 * 
	 * @param tipoDocumentoIdentidad DataCatalogo. Tipo documento identidad.
	 * @return el mapa de errores
	 */
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad){
		String codtipdocparticipante=tipoDocumentoIdentidad.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipdocparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipdocparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("","Error catalogo codtipdocparticipante");	
	}

	/**
	 * Valida el Numero documento identidad.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numeroDocumentoIdentidad String. Numero documento identidad.
	 * @return Map
	 */
	public Map<String, String> numeroDocumentoIdentidad(String numeroDocumentoIdentidad){
		return !SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad)?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valida el Codigo de Pais del participante.
	 * 
	 * @param pais DataCatalogo. Datos del pais
	 * @return el mapa de errores
	 */
	public Map<String, String> pais(DataCatalogo pais){
		String codpaisparticipante=pais.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("","Error catalogo codpaisparticipante");	
	}

	/**
	 * Valida el nombre de la razon social del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nombreRazonSocial String. Nombre de la razon social.
	 * @return Map
	 */
	public Map<String, String> nombreRazonSocial(String nombreRazonSocial){
		return (!SunatStringUtils.isEmptyTrim(nombreRazonSocial) && nombreRazonSocial.trim().length()>=5)?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valida la direccion del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 10 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param direccion String
	 * @return Map
	 */
	public Map<String, String> direccion(String direccion){
		return (!SunatStringUtils.isEmptyTrim(direccion) && direccion.trim().length()>=10)?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valida la ciudad del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param ciudad String. Ciudad del participante.
	 * @return Map
	 */
	public Map<String, String> ciudad(String ciudad){
		return (!SunatStringUtils.isEmptyTrim(ciudad) && ciudad.trim().length()>=5)?new HashMap<String,String>():getDUAError("","");
	}

/*	*//**
	 * @param String numficha 
	 * @return Map<String, String>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 *//*
	public Map<String, String> numficha(String numficha){
		return !SunatStringUtils.isEmptyTrim(numficha)?new HashMap<String,String>():getDUAError("","");
	}*/

	/**
	 * Valida el numero de telefono del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param telefono String. Telefono del participante.
	 * @return Map
	 */
	public Map<String, String> telefono(String telefono){
		return (!SunatStringUtils.isEmptyTrim(telefono) && telefono.trim().length()>=5)?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valida el numero de fax del participante.<br>
	 * 
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fax String. N�mero de fax.
	 * @return Map
	 */
	public Map<String, String> fax(String fax){
		return (!SunatStringUtils.isEmptyTrim(fax) && fax.trim().length()>=5)?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valida la direcci�n de email del participante.<br>
	 * 
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de correo electr&oacute;nico.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param email String. Direcci�n de email del participante.
	 * @return Map
	 */
	public Map<String, String> email(String email){
		return (!SunatStringUtils.isEmptyTrim(email) && SunatStringUtils.isValidEmailAddress(email))?new HashMap<String,String>():getDUAError("","");
	}

	/**
	 * Valia la direccion de la pagina web del participante.<br>
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de p&aacute;gina web.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param paginaWeb String
	 * @return Map
	 */
	public Map<String, String> paginaWeb(String paginaWeb){
		return (!SunatStringUtils.isEmptyTrim(paginaWeb) && SunatStringUtils.isValidURLAddress(paginaWeb))?new HashMap<String,String>():getDUAError("","");
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
