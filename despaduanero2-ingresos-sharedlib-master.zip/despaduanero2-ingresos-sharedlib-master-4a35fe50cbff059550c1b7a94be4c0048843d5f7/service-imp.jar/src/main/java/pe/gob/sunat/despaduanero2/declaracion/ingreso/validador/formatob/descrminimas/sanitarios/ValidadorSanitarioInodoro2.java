package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima.tipoHEAD;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima.tipoValidacion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioOtros;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValidadorSanitarioInodoro2 extends ValidadorSanitarioAbstract{
	public static final String COD_INODORO = "INO"; 
	public static final String COD_CAT_CONS_AGUA_INOD = "472";
	public static final String COD_CAT_VALVULA = "430";
	public static final String COD_CAT_TIPO_INOD = "468";
	
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{

      List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);


	  //lstErroresDescrMin.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErroresDescrMin)){    	  
      	  //lstErroresDescrMin.addAll(validarEstructura(objeto));//duplicado
          lstErroresDescrMin.addAll(super.validarNombreComercial(objeto,dua));
          lstErroresDescrMin.addAll(super.validarMarcaComercial(objeto));
          lstErroresDescrMin.addAll(super.validarModeloComercial(objeto));
          lstErroresDescrMin.addAll(super.validarCalidad(objeto));
          lstErroresDescrMin.addAll(super.validarColor(objeto));
          lstErroresDescrMin.addAll(super.validarMaterial(objeto));
          lstErroresDescrMin.addAll(validarAroInodoro(objeto));
          lstErroresDescrMin.addAll(validarUsuario(objeto));
          lstErroresDescrMin.addAll(validarAccionamiento(objeto));
          lstErroresDescrMin.addAll(validarAsiento(objeto));
          lstErroresDescrMin.addAll(validarMaterialAsiento(objeto));
          lstErroresDescrMin.addAll(validartipo(objeto));
          lstErroresDescrMin.addAll(validarConsumoAgua(objeto));
          lstErroresDescrMin.addAll(validarValvula(objeto));
          lstErroresDescrMin.addAll(validarTipoLongitudAro(objeto));
          lstErroresDescrMin.addAll(validarTipoFuncionamiento(objeto));
      }

 	    return lstErroresDescrMin;
  }
  
  public List<ErrorDescrMinima> validarAroInodoro(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarUsuario(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validarAccionamiento(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validarAsiento(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validarMaterialAsiento(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validartipo(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioInodoro sanitarioInodoro = (SanitarioInodoro) objeto;
		String NombreComercialSanitario = sanitarioInodoro.getNombreComercial().getValtipdescri().trim(); 
		String datoAValidar = sanitarioInodoro.getTipo().getValtipdescri().trim();
		if(COD_INODORO.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.isEmpty()||datoAValidar==null){
				ErrorDescrMinima error = obtenerError("31725", sanitarioInodoro.getTipo());
				lstErroresDescrMin.add(error);
			}
		}		
		return lstErroresDescrMin;
	}
  
  public List<ErrorDescrMinima> validarConsumoAgua(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioInodoro sanitarioInodoro = (SanitarioInodoro) objeto;
		String NombreComercialSanitario = sanitarioInodoro.getNombreComercial().getValtipdescri().trim();
		if(COD_INODORO.equals(NombreComercialSanitario)){
			String datoAValidar = sanitarioInodoro.getConsumoAgua().getValtipdescri().trim();
			if(SunatStringUtils.isEmpty(datoAValidar)){
				ErrorDescrMinima error = obtenerError("31727",sanitarioInodoro.getConsumoAgua());
			    lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}

  //variacion: casilla admite texto y valores de catalogo
  public List<ErrorDescrMinima> validarValvula(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioInodoro sanitarioInodoro = (SanitarioInodoro) objeto;		
		String NombreComercialSanitario = sanitarioInodoro.getNombreComercial().getValtipdescri().trim();
		if(COD_INODORO.equals(NombreComercialSanitario)){
			String datoAValidar = sanitarioInodoro.getValvula().getValtipdescri().trim();
			if(SunatStringUtils.isEmpty(datoAValidar)){
				ErrorDescrMinima error = obtenerError("31073",sanitarioInodoro.getValvula());
			    lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;	
	}
  
//casilla nueva
  public List<ErrorDescrMinima> validarTipoLongitudAro(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioInodoro sanitarioInodoro = (SanitarioInodoro) objeto;
		String NombreComercialSanitario = sanitarioInodoro.getNombreComercial().getValtipdescri().trim(); 
		String datoAValidar = sanitarioInodoro.getTipoLongitudAro()!=null?sanitarioInodoro.getTipoLongitudAro().getValtipdescri().trim():null;
		if(COD_INODORO.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.isEmpty()||datoAValidar==null){
				ErrorDescrMinima error = obtenerError("33012", sanitarioInodoro.getTipoLongitudAro());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}
  
//casilla nueva
  public List<ErrorDescrMinima> validarTipoFuncionamiento(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioInodoro sanitarioInodoro = (SanitarioInodoro) objeto;
		String NombreComercialSanitario = sanitarioInodoro.getNombreComercial().getValtipdescri().trim(); 
		String datoAValidar = sanitarioInodoro.getTipoFuncionamiento()!=null?sanitarioInodoro.getTipoFuncionamiento().getValtipdescri().trim():null;
		if(COD_INODORO.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.isEmpty()||datoAValidar==null){
				ErrorDescrMinima error = obtenerError("33013", sanitarioInodoro.getTipoFuncionamiento());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}
}