package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.domesticos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.anillos.model.Anillo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.domesticos.model.ArticuloDomestico;

public class ValidadorArticuloDomestico extends ValidadorAbstract{
	
	private static final String CATALOGO_UNID_COMER_DOM = "563";
	public static final String COD_ASOC_CATA = "020";
	public static final String COD_CON_CATALOGO = "0";
	private static final String CATALOGO_SUBGR_UNID_PESO_VOL  = "585";

	
	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception {
		List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
        if (CollectionUtils.isEmpty(lstErrores)){
            lstErrores.addAll(validarUnidadComercial(objeto, dua));
            lstErrores.addAll(validarNombreComercial(objeto, dua));
            lstErrores.addAll(validarMarcaComercial(objeto));
            lstErrores.addAll(validarModeloComercial(objeto));
            lstErrores.addAll(validarComposicion(objeto));
            lstErrores.addAll(validarAcabado(objeto));
            lstErrores.addAll(validarColor(objeto));
            lstErrores.addAll(validarAccesorios(objeto));
            lstErrores.addAll(validarPresentacionCantidadPiezas(objeto, dua));
            lstErrores.addAll(validarPesoVolumen(objeto));
            lstErrores.addAll(validarUnidadMedidaPesoVolumen(objeto));
        }

   	    return lstErrores;
	}

	 public List<ErrorDescrMinima>  validarUnidadComercial (ModelAbstract objeto, Declaracion dua){
		  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		  ArticuloDomestico domestico = (ArticuloDomestico) objeto;
		  String datoAValidar = obtenerItem(objeto,dua).getCodunidcomer().trim();
		  //rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
		  Map<String,Object> variablesIngreso = objeto.getMapCatalogos();		  
		  if(noestaEnSubGrupoCatalogo(CATALOGO_UNID_COMER_DOM,datoAValidar,variablesIngreso)){
			  Object[] demasArgumentosMSJError = new Object[] { domestico.getNumsecprove(),domestico.getNumsecfact(),
			  domestico.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
			  ErrorDescrMinima error = obtenerError("31086",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);	   	  
			  lstErroresDescrMin.add(error); 	    	  
		  }
		  return lstErroresDescrMin;
	 }
	 
	 
	 public List<ErrorDescrMinima>  validarNombreComercial (ModelAbstract objeto, Declaracion dua){

			List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
			ArticuloDomestico domestico = (ArticuloDomestico) objeto;
			DatoItem item = obtenerItem(objeto, dua);	
			String datoAValidar = domestico.getNombreComercial().getValtipdescri().trim();
			String subPartida = item.getNumpartnandi().toString();
			
			if( domestico.getNombreComercial().getCodtipvalor().equals(COD_CON_CATALOGO))
			{	
				//if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA)){
				if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA, dua.getDua().getFecdeclaracion())){
		        	Object[] argumentos = new Object[]{subPartida};
					ErrorDescrMinima error = obtenerError("31225", domestico.getNombreComercial(),argumentos);
					lstErroresDescrMin.add(error);
				}
			}
			
	        return lstErroresDescrMin;
	}
	public List<ErrorDescrMinima>  validarMarcaComercial(ModelAbstract objeto) {
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarModeloComercial (ModelAbstract objeto){
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarComposicion (ModelAbstract objeto){
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarAcabado(ModelAbstract objeto){
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarColor(ModelAbstract objeto){
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarAccesorios(ModelAbstract objeto){
		  return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarPresentacionCantidadPiezas(ModelAbstract objeto, Declaracion dua){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		ArticuloDomestico domestico = (ArticuloDomestico) objeto;
		String UnidadComercialArticuloDomestico = obtenerItem(objeto,dua).getCodunidcomer();
		if("SET".equalsIgnoreCase(UnidadComercialArticuloDomestico)){
			String datoAValidar = domestico.getModoPresentacion().getValtipdescri(); 
			if(datoAValidar.isEmpty()||datoAValidar==null){
				ErrorDescrMinima error = obtenerError("31090", objeto.getMarcaComercial());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}
	public List<ErrorDescrMinima>  validarPesoVolumen(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima>  validarUnidadMedidaPesoVolumen(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();  
		ArticuloDomestico domestico = (ArticuloDomestico) objeto;
		String datoAValidar = domestico.getUnidadMedidaPesoVolumen().getValtipdescri().trim();
		//rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
		Map<String,Object> variablesIngreso = objeto.getMapCatalogos();
	    if(noestaEnSubGrupoCatalogo(CATALOGO_SUBGR_UNID_PESO_VOL,datoAValidar,variablesIngreso))
	    	{
	    	 ErrorDescrMinima error = obtenerError("31867",domestico.getUnidadMedidaPesoVolumen());
	    	 lstErroresDescrMin.add(error);
	      }
	     return lstErroresDescrMin;		
	}	
}
