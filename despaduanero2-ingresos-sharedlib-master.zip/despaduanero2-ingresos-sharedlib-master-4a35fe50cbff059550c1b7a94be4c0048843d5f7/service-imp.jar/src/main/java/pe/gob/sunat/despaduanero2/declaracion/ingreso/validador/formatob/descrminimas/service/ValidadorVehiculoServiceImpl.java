package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.vehiculos.ValidadorVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.REG_IMPO_CONSUMO;

/**
 * La Class ValidadorVehiculoServiceImpl.
 *
 * @author arey
 * @version 1.0
 * @since 28/05/2014
 */
public class ValidadorVehiculoServiceImpl extends IngresoAbstractServiceImpl implements ValidadorVehiculoService {
	
	//private FabricaDeServicios fabricaDeServicios;  
	
	public static final String CUATRIMOTO ="CMT";//PAS20175E220200059
	private static final String INDICADOR_SNTT_1 = "1";
    private static final String INDICADOR_SNTT_0 = "0";
	private static final Integer ANNMAXIMO_VEHICULO_COLECCION = 35;
	private static final Integer RESTRICCION_ANTIG_2A�OS=2;
	private static final Integer RESTRICCION_ANTIG_5A�OS=5;
	private static final Integer RESTRICCION_PESOBRUTO_5TN_KG=5000;
	private static final Integer RESTRICCION_PESOBRUTO_12TN_KG=12000;
	private static final String TRATAMIENTO_MERCA_DONACION="4"; 
	private static final String SPN_87032="8703210010";	
	private static final String SPN_87039="8703900090";
	private static final String SPN_87051="8705100000";
	private static final String SPN_87059="8705909000";
	private static final String CODIGO_LIB_RESTRICCION="3302";
	private static final String CODIGO_MERCA_SINIESTRADA="25";
	
	private static final String TIPO_ENCENDIDO_COMPRESION="COM";
	private static final String TIPO_ENCENDIDO_CHISPA="CHI";	
	private static final String TIPO_USO_VEHESPECIAL_VIA="VIA";
	private static final String TIPO_USO_VA1="VA1"; 
	private static final String TIPO_USO_VAL="VAL";  
	private static final String TIPO_USO_VA7="VA7";
	private static final String TIPO_USO_PROHIBICION_PRO="PRO";	
	private static final String TIPO_DOCASOCIADO_RESOLUC_IMPO_EXPO="02";	
	private static final String TIPO_DOCUMENTO_RUC="4";
	private static final String CAMPO_ZZZ_OLD = "ZZZ";
	
	private static final String CATALOGO_SUBGR_PUBLICO="569";
	private static final String CATALOGO_SUBGR_DIPLOMATICO="570";
	private static final String CATALOGO_SUBGR_EXTRANJERO="571"; 
	private static final String CATALOGO_SUBGR_MERC_USADA="531";//incluida siniestrada
	private static final String CATALOGO_SUBGR_CATEG_CHI="575";
	private static final String CATALOGO_SUBGR_CATEG_COM="576";
	
	private static final String CATALOGO_TIPO_ENCENDIDO_VEH="VG";
	private static final String CATALOGO_ERRORES = "F09";
	private static final String CATALOGO_CODLIBE_EXONERADOS="435";
	
	private static final String CATALOGO_SPN_RESTRICCION_5ANIOS="436";
	private static final String CATALOGO_SPN_RESTRICCION_2ANIOS="437";	
	private static final String CATALOGO_CATEGORIAS_VEH_2ANIOS="440";
	private static final String CATALOGO_CATEGORIAS_VEH_5ANIOS="441";
	private static final String CATALOGO_CATEGORIAS_VEH_PBRUTO_5TN="512";
	private static final String CATALOGO_CATEGORIAS_VEH_PBRUTO_12TN="513";
	private static final String CATALOGO_SPN_VEH_PBRUTO_5TN="514";
	private static final String CATALOGO_SPN_VEH_PBRUTO_12TN="515";
	
	private static final String CATALOGO_ATRIB_KM_CATEG_VEH_CHI="067";
	private static final String CATALOGO_ATRIB_KM_CATEG_VEH_COM="068";	
	private static final String ASOCIACION_PARTIDA_VS_DESCRMINIMA   = "015";
//	private String[] lstPartidasExcluidas2009_5A = new String[] { "8704100000"};//PAS20155E220000451 arey//ya no se requiere porque no corresponde al anexo 1 ni 2
	
	private static final String CATALOGO_VIN_EXON_TMP="520";//PAS20155E220000451 arey
	private static final String TIPO_DOCASOCIADO_SOPORTE="S";//PAS20155E220000451 arey
	 
	/*Adicionados PAS20155E220000469 para anexo 1 y 2 arey*/
	private static final String CATALOGO_SPN_ANEXO1_2ANIOS = "521";
	private static final String CATALOGO_SUBGR_ANEXO1_CATEG_N3 = "580";
	private static final String CATALOGO_SUBGR_ANEXO1_CATEG_M3 = "581";

	private static final String CATALOGO_SPN_ANEXO2_5ANIOS = "522";
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_M1 = "587";
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_M2 = "588"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_M3 = "589"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_N1 = "591"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_N2 = "592"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_N3 = "593"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_L1 = "594"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_L2 = "595";
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_L3 = "596"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_L4 = "597"; 
	private static final String CATALOGO_SUBGR_ANEXO2_CATEG_L5 = "598";
	
	public  List<Map<String, String>> validarAntiguedadVehiculo(DatoItem item, Declaracion declaracion)  {

		List<ErrorDescrMinima>  listError = new  ArrayList<ErrorDescrMinima>();
		List<Map<String, String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		try {
		       	
			String subPartida = item.getNumpartnandi().toString();
			Date fechaVigencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():SunatDateUtils.getCurrentDate();
		   	List<Map<String, String>> lista = catalogoAyudaService.getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA, "C", subPartida,fechaVigencia);
			if (CollectionUtils.isEmpty(lista)){
				lista = catalogoAyudaService.getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA,"C", subPartida.substring(0, 4), fechaVigencia);
			}
			if (lista.size()>0){
			   if(!lista.get(0).get("cod_datacat").equals("01")){
				   return listErrores;//SPN no vehiculos				
			   }
			                	
			}else{			        	
			  	return listErrores;//SPN no minimas			
			} 
			
			
			if( item.getListDecrMinima().isEmpty()){
				return listErrores;//TerminaVal
			}
			
	   
	    	VehiculoService vehiculo = fabricaDeServicios.getService("descripcionMinima.VehiculoService");
			
	    	String indicadorSNTT = vehiculo.obtenerIndicadorSNTT(item, declaracion);
	    	String numeroVIN = vehiculo.obtenerVIN(item, declaracion);//arey Pase 451 - 2015
	    	String carroceria = vehiculo.obtenerCarroceria(item, declaracion);//arey Pase 451 - 2015  //PAS20175E220200059
	    	
		    List<Map<String, Object>> lstDatoSerie = obtenerDatosSeriesItem(item, declaracion);
		    
		    Map<String, Object> mapDatosVehiculo = new HashMap<String,Object>();
			 
			// PAS20191U220500021 - Datos necesarios para implementar las modificaciones en Antiguedad del vehiculo
			Date fecCtrlCam1 = (Date) catalogoAyudaService.getElementoCat(Constantes.CATALOGO_CONTROL_CAMBIO, Constantes.CATALOGO_VIGENCIA_NUEVA_VALIDACION_ANTIGUEDAD).get("fec_inidatcat");
 
			if (fecCtrlCam1!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaVigencia, fecCtrlCam1, SunatDateUtils.COMPARA_SOLO_FECHA)){
				mapDatosVehiculo.put("vigCamAnt1","VIGENTE");
			} else {
				mapDatosVehiculo.put("vigCamAnt1","NO_VIGENTE");
				if(item.getAnnfabrica()==null){
					return listErrores;//TerminaVal 
				}
			}
			Date fecCtrlCam2Num = (Date) catalogoAyudaService.getElementoCat(Constantes.CATALOGO_CONTROL_CAMBIO, Constantes.CATALOGO_VIGENCIA_MODIF_DL_843).get("fec_inidatcat");
 
			if (fecCtrlCam2Num!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaVigencia, fecCtrlCam2Num, SunatDateUtils.COMPARA_SOLO_FECHA)){
				mapDatosVehiculo.put("vigCamAnt2Num","VIGENTE");
			} else {
				mapDatosVehiculo.put("vigCamAnt2Num","NO_VIGENTE");
			}
			Date fec_embarque = lstDatoSerie.get(0).get("fechaEmbarque")!=null?(Date)(lstDatoSerie.get(0).get("fechaEmbarque")):null;
			Date fec_cartaCredito = declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr();
			Date fec_verificacionVigCam = fec_cartaCredito==null?fec_embarque:fec_cartaCredito;
			Date fecCtrlCam2 = (Date) catalogoAyudaService.getElementoCat(Constantes.CATALOGO_CONTROL_CAMBIO, Constantes.CATALOGO_VIGENCIA_MODIF_DL_843).get("fec_inidatcat");
			if (fecCtrlCam2!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fec_verificacionVigCam, fecCtrlCam2, SunatDateUtils.COMPARA_SOLO_FECHA)){
				 mapDatosVehiculo.put("vigCamAnt2","VIGENTE");
			} else {
				 mapDatosVehiculo.put("vigCamAnt2","NO_VIGENTE");
			}
			mapDatosVehiculo.put("fecValida",fec_verificacionVigCam);
			
			if (catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA, item.getCodestamer(),null)!=null) {
				mapDatosVehiculo.put("estadoMerca","USADA");
			} else {
				mapDatosVehiculo.put("estadoMerca","NUEVA");
			}
		     
			ValidadorAbstract validador = (ValidadorVehiculo) fabricaDeServicios.getService("ValidadorVehiculo");
			
			String categoria = vehiculo.obtenerCategoria(item, declaracion);
			String tipoEncendido = vehiculo.obtenerTipoEncendido(item, declaracion);
			int pesoBrutoKg = vehiculo.obtenerPesoBrutoKG(item, declaracion);
			BigDecimal kilometraje = vehiculo.obtenerKilometraje(item, declaracion);
			  
			mapDatosVehiculo.put("categoria",categoria);
			mapDatosVehiculo.put("tipoEncendido",tipoEncendido);
			mapDatosVehiculo.put("indicadorSNTT",indicadorSNTT);
			mapDatosVehiculo.put("pesoBrutoKg",pesoBrutoKg);
			mapDatosVehiculo.put("kilometraje",kilometraje);
			mapDatosVehiculo.put("numSecProve",lstDatoSerie.get(0).get("numSecProve"));
			mapDatosVehiculo.put("numSecFactura",lstDatoSerie.get(0).get("numSecFactura"));
			mapDatosVehiculo.put("numSecItem",lstDatoSerie.get(0).get("numSecItem"));
			mapDatosVehiculo.put("annModelo",vehiculo.obtenerAnoModelo(item, declaracion));
			 
    		if(esExceptuadoReqMinimosCalidad(item, declaracion,indicadorSNTT, lstDatoSerie, numeroVIN, carroceria, mapDatosVehiculo)){//arey Pase 451 - 2015 //PAS20175E220200059
				 return listErrores;//TerminaVal
			}
		
			listError.addAll(validarRestriccionFuncExtranjeros(item, declaracion, mapDatosVehiculo, lstDatoSerie));		
 	        listError.addAll(validarVehiculoSiniestrado(item, declaracion, mapDatosVehiculo, lstDatoSerie));	
    		listError.addAll(validarAntiguedadPorFechas(item, declaracion, mapDatosVehiculo, lstDatoSerie));		
			listError.addAll(validarProhibicionImpoConsumo(item, declaracion, mapDatosVehiculo, lstDatoSerie));
			
			
			listErrores.addAll(validador.convertirErrores(listError));
		}catch(Exception e){
			  e.printStackTrace();
		}
		return listErrores;
	}
	
 
	/**
	 * Obtiene:
	 * las series asociadas al item, los c�digos liberatorios,
	 * el documento de transporte y la fecha de embarque de la serie 
	 * @param item DatoItem, declaracion Declaracion
	 * @return lstDatoSerie List<Map<String, Object>>
	 */	
	public List<Map<String, Object>> obtenerDatosSeriesItem(DatoItem item, Declaracion declaracion){
 
		List<Map<String, Object>> lstDatoSerie = new ArrayList<Map<String, Object>>();
		Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
		Map<String, Object> mapDocAutorizante = new HashMap<String, Object>();
		
		int numSerie;   
		int numItem;
		
		for(DatoSerieItem datoSerieItem : item.getListSerieItems()){
			numItem = item.getNumsecitem();
			numSerie = datoSerieItem.getNumserie();
			mapDatoSerie.put("numSerie", numSerie);
			//	Obteniendo el c�digo liberatorio de la serie
			
			Integer num_detDocTransp = 0;
			Integer num_secdocumAut = 0;
			
			for(DatoSerie datosSerie : declaracion.getDua().getListSeries()){
				if(datosSerie.getNumserie()==numSerie){ 
					mapDatoSerie.put("codLiberatorio", datosSerie.getCodliberatorio());
					mapDatoSerie.put("pesoBrutoSerie",datosSerie.getCntpesobruto());//peso bruto serie 
					for(DatoSerieDocSoporte datosSerieDocSop : datosSerie.getListSerieDocSoporte()){
						if(datosSerie.getNumserie()==numSerie){							
							if(datosSerieDocSop.getCodtipodocsoporte().equals("3")){//es doc de transporte
								num_detDocTransp = datosSerieDocSop.getNumiddocsoporte();
								//Obteniendo el documento de transporte de la serie (tipo 3) 
								for (DatoDocTransporte datosDocTransp : declaracion.getDua().getListDocTransporte()) {	
									if(datosDocTransp.getNumsecdoctrans().equals(num_detDocTransp)){
										mapDatoSerie.put("docTranspId", datosDocTransp.getNumsecdoctrans()!=null?datosDocTransp.getNumsecdoctrans():"");
										mapDatoSerie.put("fechaEmbarque", datosDocTransp.getFecembarque());
									}				
								}
							} 
							//Obteniendo el documento de autorizaci�n tipo resoluci�n de la serie  
							/*if(datosSerieDocSop.getCodtipodocsoporte().equals("4")){// es doc autorizacion
								num_secdocumAut = datosSerieDocSop.getNumiddocsoporte();
								for(DatoDocAutorizante datoDocAutorizante : declaracion.getDua().getListDocAutorizantes()){
									if(datoDocAutorizante.getNumsecdocum().equals(num_secdocumAut)
										//&& datoDocAutorizante.getCodTipoOper().equals(TIPO_PROCESO_DOCASOCIADO_AUTORIZACION)
										&& datoDocAutorizante.getCodtipodocum().equals(TIPO_DOCASOCIADO_RESOLUC_IMPO_EXPO)
										&& datoDocAutorizante.getAnndocum()!=null
										&& datoDocAutorizante.getNumdocum()!=null
										&& datoDocAutorizante.getFecemision()!=null
										&& SunatDateUtils.esFecha1MayorQueFecha2(datoDocAutorizante.getFecvencimiento(),new Date(),"COMPARA_TODO")){
										mapDatoSerie.put("docAutorizaId", datoDocAutorizante.getNumsecdocum());
									}
								}	
							}*/
							//se cambia por conflictos con validaciones de restringidas en el mismo tag govern:
							if(datosSerieDocSop.getCodtipodocsoporte().equals("1")){// es doc soporte
								num_secdocumAut = datosSerieDocSop.getNumiddocsoporte();
								for(DatoOtroDocSoporte datoDocSoporte : declaracion.getDua().getListOtrosDocSoporte()){
									if(datoDocSoporte.getNumsecdocum().equals(num_secdocumAut)
										//&& datoDocSoporte.getCodtipoproceso().equals(TIPO_PROCESO_DOCASOCIADO_AUTORIZACION)//P
										&& datoDocSoporte.getCodtipodocasoc().equals(TIPO_DOCASOCIADO_RESOLUC_IMPO_EXPO)//02
										&& datoDocSoporte.getAnndocasoc()!=null
										&& datoDocSoporte.getNumdocasoc()!=null
										&& datoDocSoporte.getFecdocasoc()!=null
										&& SunatDateUtils.esFecha1MayorQueFecha2(datoDocSoporte.getFecvencimiento(),new Date(),"COMPARA_TODO")){
										mapDatoSerie.put("docAutorizaId", datoDocSoporte.getNumsecdocum());
									}
									/**Adicionado por casuistica especial arey Pase 451 - 2015*/
									if(datoDocSoporte.getNumsecdocum().equals(num_secdocumAut)
											&& datoDocSoporte.getCodtipoproceso().equals(TIPO_DOCASOCIADO_SOPORTE)//proceso S PASE469-2015 arey
											&& datoDocSoporte.getAnndocasoc()!=null
											&& datoDocSoporte.getNumdocasoc()!=null
											&& datoDocSoporte.getFecdocasoc()!=null
											&& SunatDateUtils.esFecha1MenorIgualQueFecha2(datoDocSoporte.getFecdocasoc(),new Date(),"COMPARA_TODO")){//PASE469-2015 arey
											mapDatoSerie.put("docSoporteId", datoDocSoporte.getNumsecdocum());
									}/**Adicionado por casuistica especial*/
								}	
							}
						}					
					}
					for(DAV davs : declaracion.getListDAVs()){
							for(DatoFactura factura : davs.getListFacturas()){
								for(DatoItem datoItem : factura.getListItems()){
									if(datoItem.getNumsecitem()==numItem){
										mapDatoSerie.put("numSecProve",davs.getNumsecuprov()!=null?davs.getNumsecuprov():"");
										mapDatoSerie.put("numSecFactura",factura.getNumsecfactu()!=null?factura.getNumsecfactu():"");
										mapDatoSerie.put("numSecItem",datoItem.getNumsecitem()!=null?datoItem.getNumsecitem():"");	
										break;
									}
								}
							}		
					}
					lstDatoSerie.add(mapDatoSerie);							
					}					
				}
			}
		
		return lstDatoSerie;	
	}

	
	/**
	 * Obtiene el tiempo de antiguedad del vehiculo en base a la diferencia de 
	 * la fecha de fabrica y la fecha de embarque. 
	 * @return antiguedad int
	 */	
	public int	obtenerAntiguedadVeh�culo(Integer nAnio1, Integer nAnio2){
	
		int antiguedad=0;
		antiguedad = nAnio2-nAnio1;
		
		return antiguedad;
	}

	
	/**
	 * Valida si la SPN correlacionada pertenece a un rango establecido 
	 * @param correlSPN Long, partida1 Long, partida2 Long
	 * @return boolean
	 */	
	public boolean buscarSPNCorrel(List<Long> lstPartidas, Long partida1, Long partida2){
		
		for(int i=0; lstPartidas.size()>i; i++){
			
			if(partida2==0){
				if(lstPartidas.get(i)==partida1){
					return true;
				}
			}
			if(partida2>0){
				if(lstPartidas.get(i)>=partida1 && lstPartidas.get(i)<=partida2){
					return true;
				}
			}			
		}
		return false;
	}
	
	
	/**
	 * Valida y retorna true si se exceptua de los requisitos m�nimos de calidad respecto a la antiguedad, kilometraje o siniestro 
	 * @param item DatoItem, declaracion Declaracion, indicadorSNTT String, lstDatoSerie  List<Map<String, Object>>
	 * @return boolean
	 */
	public boolean esExceptuadoReqMinimosCalidad(DatoItem item, Declaracion declaracion,String indicadorSNTT, List<Map<String, Object>> lstDatoSerie, String numeroVIN,String carroceria, Map<String, Object> mapDatosVehiculo){ //PAS20175E220200059
		
		ProveedorFuncionesService proveedorFuncionesService = fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		Long numPartida= item.getNumpartnandi(); 
		
		int anioEmbarque = SunatNumberUtils.getAnioFromDate(SunatDateUtils.getIntegerFromDate(lstDatoSerie.get(0).get("fechaEmbarque")!=null?lstDatoSerie.get(0).get("fechaEmbarque"):0));
		int antiguedadVehiculo = 0;
		
		// PAS20191U220500021 - En base al a�o modelo
		if ((mapDatosVehiculo.get("vigCamAnt1").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("NUEVA")) 
				|| (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("USADA")))
			antiguedadVehiculo = obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString()), anioEmbarque);
		else
			antiguedadVehiculo = obtenerAntiguedadVeh�culo(new Integer(item.getAnnfabrica()), anioEmbarque);
		
		Integer fechaNumeracion=0;
		
		 if (declaracion.getNumdeclRef() != null) {
			 fechaNumeracion = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		 } else {
		     fechaNumeracion = SunatNumberUtils.getTodayAsInteger();
		 }
		
		Long correlSPN = proveedorFuncionesService.getCorrelPartida(item.getNumpartnandi(), new Long("0"),fechaNumeracion);
			
		List<Long> lstPartidas = new ArrayList<Long>();
		lstPartidas.add(item.getNumpartnandi());
		if(lstPartidas.size()>0){
			lstPartidas.add(correlSPN);
		}
		
		//es donaci�n, o es impo de diplomaticos nacionales, o es usado de colecci�n, o es para funcionarios extranjeros o es cuatrimoto  //PAS20175E220200059
		if(declaracion.getDua().getCodtipotratamiento().equals(TRATAMIENTO_MERCA_DONACION) 
			&& proveedorFuncionesService.existsInEmpresasPublicas(TIPO_DOCUMENTO_RUC,declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().toString())==true
			&& catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_PUBLICO, (lstDatoSerie.get(0).get("codLiberatorio")).toString(),null)!=null
			|| ( buscarSPNCorrel(lstPartidas,new Long(SPN_87032),new Long(SPN_87039))==true && antiguedadVehiculo>=ANNMAXIMO_VEHICULO_COLECCION ) 
			
			|| ( //declaracion.getDua().getCodtipotratamiento().equals(TRATAMIENTO_MERCA_DIPLOMATICO) && 
				catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_DIPLOMATICO, (lstDatoSerie.get(0).get("codLiberatorio")).toString(),null)!=null
				&& lstDatoSerie.get(0).get("docAutorizaId")!=null)				
			
			|| ( catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_EXTRANJERO, (lstDatoSerie.get(0).get("codLiberatorio")).toString(),null)!=null
				&& lstDatoSerie.get(0).get("docAutorizaId")!=null) //){//c�digo de uso oficial dipl. extr. requiere Resoluci�n Liberatoria
					
			|| (indicadorSNTT.equals(INDICADOR_SNTT_1) && carroceria.equals(CUATRIMOTO))){ //PAS20175E220200059
					
			return true;//TerminaVal
		}
			
		String cod_vin = (numeroVIN!=null && numeroVIN.length()>=9)? numeroVIN.substring(0,9):"";//Adicionado para exonerar VINs de PAS20155E220000451 que no circulen en SNTT //botaba error 24 arey PAS20145E220000164
		String serie_vin = (numeroVIN!=null && numeroVIN.length()>=9)? numeroVIN.substring(9):"";//Adicionado para exonerar VINs de PAS20155E220000451 que no circulen en SNTT //botaba error 24 arey PAS20145E220000164
		//es veh�culo especial
		if((proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VEHESPECIAL_VIA,numPartida.toString(),fechaNumeracion)!=null 
				&& !SunatStringUtils.isEmpty(indicadorSNTT) && indicadorSNTT.equals(INDICADOR_SNTT_1)) 
				|| 	( !SunatStringUtils.isEmpty(cod_vin) && (lstDatoSerie.get(0).get("docSoporteId")!=null && catalogoAyudaService.getDataCatalogo(CATALOGO_VIN_EXON_TMP, cod_vin,null)!=null  
					&& (catalogoAyudaService.getDataCatalogo(CATALOGO_VIN_EXON_TMP, cod_vin,null).getDesDatacat()).equals(serie_vin)
					&& indicadorSNTT.equals(INDICADOR_SNTT_1)//PASE469-2015 arey
					 ))
				){ //Adicionado para exonerar VINs de PAS20155E220000451 que no circulen en SNTT
			
			return true;//TerminaVal
		}
		
		return false;
	}
	
	
	/**
	 * @param item DatoItem, declaracion Declaracion , lstDatoSerie List<Map<String, Object>> 
	 * @return listError List<ErrorDescrMinima>
	 */
	public List<ErrorDescrMinima> validarVehiculoSiniestrado(DatoItem item,Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie){
		
		List<ErrorDescrMinima> listError = new  ArrayList<ErrorDescrMinima>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ProveedorFuncionesService proveedorFuncionesService = fabricaDeServicios.getService("funcionesService");
		 
		int anioEmbarque = SunatNumberUtils.getAnioFromDate(SunatDateUtils.getIntegerFromDate(lstDatoSerie.get(0).get("fechaEmbarque")!=null?lstDatoSerie.get(0).get("fechaEmbarque"):0));
		int antiguedadVehiculo = 0;
		if ((mapDatosVehiculo.get("vigCamAnt1").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("NUEVA")) 
				|| (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("USADA"))) 
			antiguedadVehiculo = obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString()), anioEmbarque);
		else
			antiguedadVehiculo = obtenerAntiguedadVeh�culo(new Integer(item.getAnnfabrica()), anioEmbarque);
		
		Integer fechaNumeracion=0;
		
		 if (declaracion.getNumdeclRef() != null) {
			 fechaNumeracion = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		 } else {
		     fechaNumeracion = SunatNumberUtils.getTodayAsInteger();
		 }
		
		Long correlSPN = proveedorFuncionesService.getCorrelPartida(item.getNumpartnandi(), new Long("0"),fechaNumeracion);

		List<Long> lstPartidas = new ArrayList<Long>();
		lstPartidas.add(item.getNumpartnandi());
		if(lstPartidas.size()>0){
			lstPartidas.add(correlSPN);
		}
		
		if(declaracion.getDua().getCodregimen().equals(REG_IMPO_CONSUMO) &&  item.getCodestamer().equals(CODIGO_MERCA_SINIESTRADA)
				&& ( catalogoAyudaService.getDataCatalogo(CATALOGO_CODLIBE_EXONERADOS,lstDatoSerie.get(0).get("codLiberatorio").toString()) == null
				|| (buscarSPNCorrel(lstPartidas, new Long(SPN_87032), new Long(SPN_87039)) == false && antiguedadVehiculo<ANNMAXIMO_VEHICULO_COLECCION)) ){
				
				Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
						lstDatoSerie.get(0).get("numSecItem"),"ESTADO DE LA MERCANCIA",item.getCodestamer()};
					
				ErrorDescrMinima error = new ErrorDescrMinima("", "31813", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31813").getDesDatacat(),
											ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
				listError.add(error);		
		}
		return listError;
	}
	
	
	/**
	 * Obtiene el atributoKM del catalogo de atributos  
	 * @param codAtributo String, codGrupo String, codTipoCat String, categoria_veh String
	 * @return km int
	 */	
	public BigDecimal obtenerAtributoKM(String codAtributo, String codGrupo, String codTipoCat, String categoria_veh, Date fecValCalalogo){
		BigDecimal km= new BigDecimal(0);
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		Map<String, Object> mapkm = 
		catalogoAyudaService.getDataAtributo(codAtributo, codGrupo, codTipoCat, categoria_veh, fecValCalalogo);
		if(mapkm!=null && mapkm.size()>0){
			km = new BigDecimal(mapkm.get("val_atributo").toString());
		}			
		return km;
	}
	
	
	/**
	 * Valida los KM respecto a los Tipos de Uso. 
	 * @param vehiculo Vehiculo, item DatoItem, declaracion Declaracion, tipo int
	 * @return  listError List<Map<String,Object>>
	 */	
	public List<ErrorDescrMinima> validarKmVehiculo(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, int tipo){
		
		List<ErrorDescrMinima> listError = new ArrayList<ErrorDescrMinima>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		Date fec_llegada;
		if(SunatDateUtils.getIntegerFromDate(declaracion.getDua().getManifiesto().getFectermino())!=10101){
		    fec_llegada = declaracion.getDua().getManifiesto().getFectermino();
		}else{		
			fec_llegada = declaracion.getDua().getFecLlegada();
		}		
		
		Date fec_valLlegada = SunatDateUtils.getDateFromInteger(20070224);

		String tipoEncendido = mapDatosVehiculo.get("tipoEncendido").toString();
		String categoria =  mapDatosVehiculo.get("categoria").toString();
		String indicadorSNTT = mapDatosVehiculo.get("indicadorSNTT").toString();
		BigDecimal kilometraje = mapDatosVehiculo.get("kilometraje").toString()!=null?new BigDecimal(mapDatosVehiculo.get("kilometraje").toString()):new BigDecimal(0);
		BigDecimal km_limite=new BigDecimal(0);		
		Date fec_validaCatalogo = (Date)mapDatosVehiculo.get("fecValida");

		if(tipo==1){
			
			if(SunatDateUtils.esFecha1MayorQueFecha2(fec_llegada, fec_valLlegada,SunatDateUtils.COMPARA_SOLO_FECHA)
					&& tipoEncendido!=null && (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoEncendido.equals(TIPO_ENCENDIDO_CHISPA))
					&& !indicadorSNTT.equals(INDICADOR_SNTT_1)){
				
				if(tipoEncendido.equals(TIPO_ENCENDIDO_CHISPA) && catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_CATEG_CHI, categoria.substring(0,2), fec_validaCatalogo)!=null){
					
					BigDecimal km_limiteCHI1=obtenerAtributoKM(CATALOGO_ATRIB_KM_CATEG_VEH_CHI, CATALOGO_SUBGR_CATEG_CHI,CATALOGO_CATEGORIAS_VEH_2ANIOS,categoria.substring(0,2),fec_validaCatalogo);
					// PAS20191U220500021 - Ahora solo hay hasta 2 a�os
					if (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE")) {
						km_limite = km_limiteCHI1;
					} else {
						BigDecimal km_limiteCHI2=obtenerAtributoKM(CATALOGO_ATRIB_KM_CATEG_VEH_CHI, CATALOGO_SUBGR_CATEG_CHI,CATALOGO_CATEGORIAS_VEH_5ANIOS,categoria.substring(0,2),fec_validaCatalogo);
						if(km_limiteCHI1.compareTo(new BigDecimal(0))==1){ //km_limite>0
							km_limite = km_limiteCHI1;
						}else{
							km_limite = km_limiteCHI2;
						}
					}
						
					if(kilometraje.compareTo(km_limite) == 1){//kilometraje > km_limite
						Object[] demasArgumentosMSJError = new Object[] {mapDatosVehiculo.get("numSecProve"),mapDatosVehiculo.get("numSecFactura"),
													mapDatosVehiculo.get("numSecItem"), "KILOMETRAJE", kilometraje, 
													SunatStringUtils.toStringObj(km_limite),categoria, tipoEncendido};
											
						ErrorDescrMinima error = new ErrorDescrMinima("", "31816", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31816").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
						listError.add(error);		
					}										
				}
				
				if(tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) && catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_CATEG_COM, categoria.substring(0,2), fec_validaCatalogo)!=null){

					BigDecimal km_limiteCOM1=obtenerAtributoKM(CATALOGO_ATRIB_KM_CATEG_VEH_COM, CATALOGO_SUBGR_CATEG_COM,CATALOGO_CATEGORIAS_VEH_2ANIOS,categoria.substring(0,2),fec_validaCatalogo);
					// PAS20191U220500021 - Ahora solo hay hasta 2 a�os
					if (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE")) {
						km_limite = km_limiteCOM1;
					} else {
						BigDecimal km_limiteCOM2=obtenerAtributoKM(CATALOGO_ATRIB_KM_CATEG_VEH_COM, CATALOGO_SUBGR_CATEG_COM,CATALOGO_CATEGORIAS_VEH_5ANIOS,categoria.substring(0,2),fec_validaCatalogo);
						if(km_limiteCOM1.compareTo(new BigDecimal(0))==1){ //km_limite>0
							km_limite = km_limiteCOM1;
						}else{
							km_limite = km_limiteCOM2;
						}
					}
					
					if(kilometraje.compareTo(km_limite) == 1){//kilometraje > km_limite
						Object[] demasArgumentosMSJError2 = new Object[] {mapDatosVehiculo.get("numSecProve"),mapDatosVehiculo.get("numSecFactura"),
												mapDatosVehiculo.get("numSecItem"),"KILOMETRAJE", kilometraje, 
												SunatStringUtils.toStringObj(km_limite),categoria, tipoEncendido};
	
						ErrorDescrMinima error = new ErrorDescrMinima("", "31816", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31816").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError2);
						listError.add(error);							 
					}
				}		
			}
		}
		
		if(tipo==2){

			String tipoValorEncendido=" ";		
			if( (tipoEncendido!="" && tipoEncendido.length()>2 && tipoEncendido.substring(0,2).equals(CAMPO_ZZZ_OLD)) || (tipoEncendido.length()>0 && catalogoAyudaService.getDataCatalogo(CATALOGO_TIPO_ENCENDIDO_VEH,tipoEncendido)==null)){
				tipoValorEncendido="ZZZ";	// es valor Otros "ZZZ" en antig estructura u Otros "1" en nueva estructura		
			}
			if(SunatDateUtils.esFecha1MayorQueFecha2(fec_llegada, fec_valLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)
					&& (tipoEncendido!=null && tipoValorEncendido.equals(CAMPO_ZZZ_OLD))
					&& !indicadorSNTT.equals(INDICADOR_SNTT_1)
					&&  (kilometraje.compareTo(new BigDecimal(0)) == -1 || kilometraje.compareTo(new BigDecimal(0)) == 0)) {//kilometraje<=0
							
				Object[] demasArgumentosMSJError = new Object[] {mapDatosVehiculo.get("numSecProve"),mapDatosVehiculo.get("numSecFactura"),
						mapDatosVehiculo.get("numSecItem"),"KILOMETRAJE", kilometraje ,categoria, "ZZZ"};

				ErrorDescrMinima error = new ErrorDescrMinima("", "31817", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31817").getDesDatacat(), 
												ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
				listError.add(error);		
			}
		}
		return listError;
	}
	
	
	
	/**
	 * Valida la Antig�edad de Veh�culos por fechas:
	 * Antig�edad <=18/12/2008
	 * 19/12/2008 <= Antig�edad <= 31/12/2008
	 * Antig�edad >= 01/01/2009
	 * @param item DatoItem, declaracion Declaracion, mapDatosVehiculo Map<String, Object>
	 * @return listError List<ErrorDescrMinima> 
	 */
	public List<ErrorDescrMinima> validarAntiguedadPorFechas(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie){

		List<ErrorDescrMinima> listError = new ArrayList<ErrorDescrMinima>();
		ProveedorFuncionesService proveedorFuncionesService = fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				
		String tipoEncendido = mapDatosVehiculo.get("tipoEncendido").toString();
		String categoria = mapDatosVehiculo.get("categoria").toString();
		int pesoBrutoKg = new Integer (mapDatosVehiculo.get("pesoBrutoKg").toString());
		BigDecimal pesoBrutoSerie = new BigDecimal(lstDatoSerie.get(0).get("pesoBrutoSerie").toString()); 
		String indicadorSNTT = mapDatosVehiculo.get("indicadorSNTT").toString();
		
		Long numPartida = item.getNumpartnandi();
		
		int anioEmbarque = SunatNumberUtils.getAnioFromDate(SunatDateUtils.getIntegerFromDate(lstDatoSerie.get(0).get("fechaEmbarque")!=null?lstDatoSerie.get(0).get("fechaEmbarque"):0));
		int antiguedadVehiculo1 = 0; 
		int antiguedadVehiculo2 = 0; 
		
		// PAS20191U220500021 - En base al a�o modelo
		if ((mapDatosVehiculo.get("vigCamAnt1").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("NUEVA")) 
				|| (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("USADA"))) {
			antiguedadVehiculo1 = obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString())+1, anioEmbarque);
			antiguedadVehiculo2 = obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString()), anioEmbarque);
		} else {
			antiguedadVehiculo1 = obtenerAntiguedadVeh�culo(new Integer(item.getAnnfabrica())+1, anioEmbarque);
			antiguedadVehiculo2 = obtenerAntiguedadVeh�culo(new Integer(item.getAnnfabrica()), anioEmbarque);
		}
		
		String tipoValorEncendido=" ";		
		if( (tipoEncendido!="" && tipoEncendido.length()>2 && tipoEncendido.substring(0,2).equals(CAMPO_ZZZ_OLD)) || (tipoEncendido.length()>0 && catalogoAyudaService.getDataCatalogo(CATALOGO_TIPO_ENCENDIDO_VEH,tipoEncendido)==null)){
			tipoValorEncendido="ZZZ";// es valor Otros "ZZZ" en antig estructura u Otros "1" en nueva estructura		
		}
		
		Integer fechaNumeracion=0;
		
		if (declaracion.getNumdeclRef() != null) {
			 fechaNumeracion = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		} else {
		     fechaNumeracion = SunatNumberUtils.getTodayAsInteger();
		}
		
		if(declaracion.getDua().getCodregimen().equals(REG_IMPO_CONSUMO) && (!item.getCodestamer().equals(CODIGO_MERCA_SINIESTRADA) && catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA, item.getCodestamer(),null)!=null)
				 && catalogoAyudaService.getDataCatalogo(CATALOGO_CODLIBE_EXONERADOS,lstDatoSerie.get(0).get("codLiberatorio").toString()) == null){
			
			Date fec_embarque = lstDatoSerie.get(0).get("fechaEmbarque")!=null?(Date)(lstDatoSerie.get(0).get("fechaEmbarque")):null;
			Date fec_cartaCredito = declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr()!=null?declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr():null; 
			Date fec_validaCatalogo = (Date)mapDatosVehiculo.get("fecValida");
					
			//a. valAntiguedad <= 18/12/2008
			Date fec_valAntiguedad1 = SunatDateUtils.getDateFromInteger(20081218);
			if( (SunatDateUtils.esFecha1MenorIgualQueFecha2(fec_embarque, fec_valAntiguedad1,SunatDateUtils.COMPARA_SOLO_FECHA)
				|| fec_cartaCredito!=null && SunatDateUtils.esFecha1MenorIgualQueFecha2(fec_cartaCredito, fec_valAntiguedad1, SunatDateUtils.COMPARA_SOLO_FECHA) )
				&& ( proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA1,numPartida.toString(),fechaNumeracion)!=null
				||  proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL,numPartida.toString(),fechaNumeracion)!=null) ){
				
				Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
						lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo1};
				
				//if((proveedorFuncionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(TIPO_USO_VA1,numPartida.toString(),fechaNumeracion,TIPO_ENCENDIDO_COMPRESION,categoria.substring(0,2)))!=null
				if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA1, numPartida.toString(),fechaNumeracion)!=null
						 && (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoValorEncendido.equals(CAMPO_ZZZ_OLD))  
						 && ( catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_2ANIOS, categoria.substring(0,2))!=null)){
					
					if(antiguedadVehiculo1>RESTRICCION_ANTIG_2A�OS){						
						
						ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
						listError.add(error);	
					}
				}
				
				  if( (proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null )
						 &&  ( (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoValorEncendido.equals(CAMPO_ZZZ_OLD)) && (catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_5ANIOS, categoria.substring(0,2))!=null)  ) 
						 || tipoEncendido.equals(TIPO_ENCENDIDO_CHISPA) ){
										
					if(antiguedadVehiculo1>RESTRICCION_ANTIG_5A�OS){
																
						ErrorDescrMinima error = new ErrorDescrMinima("", "31815", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31815").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
						listError.add(error);							
					}
				}	
			
				mapDatosVehiculo.put("numSecProve",lstDatoSerie.get(0).get("numSecProve"));
				mapDatosVehiculo.put("numSecFactura",lstDatoSerie.get(0).get("numSecFactura"));
				mapDatosVehiculo.put("numSecItem",lstDatoSerie.get(0).get("numSecItem"));
				
				//valKM			
				listError.addAll(validarKmVehiculo(item, declaracion, mapDatosVehiculo, 1));
				listError.addAll(validarKmVehiculo(item, declaracion, mapDatosVehiculo, 2));
						
			}
			

			//b. 19/12/2008 <= valAntiguedad <= 31/12/2008
			Date fec_valAntiguedad2Ini = SunatDateUtils.getDateFromInteger(20081219);
			Date fec_valAntiguedad2Fin = SunatDateUtils.getDateFromInteger(20081231);
			if(( (SunatDateUtils.esFecha1MayorIgualQueFecha2(fec_embarque, fec_valAntiguedad2Ini, SunatDateUtils.COMPARA_SOLO_FECHA) &&
					SunatDateUtils.esFecha1MenorIgualQueFecha2(fec_embarque, fec_valAntiguedad2Fin, SunatDateUtils.COMPARA_SOLO_FECHA))
					|| (fec_cartaCredito!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fec_cartaCredito, fec_valAntiguedad2Ini, SunatDateUtils.COMPARA_SOLO_FECHA) &&
					SunatDateUtils.esFecha1MenorIgualQueFecha2(fec_cartaCredito, fec_valAntiguedad2Fin, SunatDateUtils.COMPARA_SOLO_FECHA)) )
				&& ( proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA7, numPartida.toString(),fechaNumeracion)!=null
					|| proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null) ){		
				
				Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
						lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo2};

				if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA7, numPartida.toString(),fechaNumeracion)!=null
						&& (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoValorEncendido.equals(CAMPO_ZZZ_OLD))  ){
					
					if(antiguedadVehiculo2>RESTRICCION_ANTIG_2A�OS){
						
						ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
						listError.add(error);						
					}
				}
				
				if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null
						&& (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) && !tipoValorEncendido.equals(CAMPO_ZZZ_OLD)) )){
				
					if(antiguedadVehiculo2>RESTRICCION_ANTIG_5A�OS){
						
						ErrorDescrMinima error = new ErrorDescrMinima("", "31815", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31815").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
						listError.add(error);		
					}
				}
				
				mapDatosVehiculo.put("numSecProve",lstDatoSerie.get(0).get("numSecProve"));
				mapDatosVehiculo.put("numSecFactura",lstDatoSerie.get(0).get("numSecFactura"));
				mapDatosVehiculo.put("numSecItem",lstDatoSerie.get(0).get("numSecItem"));		
				//valKM					
				listError.addAll(validarKmVehiculo(item, declaracion,mapDatosVehiculo,  1));
				listError.addAll(validarKmVehiculo(item, declaracion,mapDatosVehiculo,  2));
					
			}
			
	
			//c. valAntiguedad >= 01/01/2009
			Date fec_valAntiguedad3 = SunatDateUtils.getDateFromInteger(20090101);
			if(fec_embarque!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fec_embarque, fec_valAntiguedad3, SunatDateUtils.COMPARA_SOLO_FECHA)
					|| (fec_cartaCredito !=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fec_cartaCredito, fec_valAntiguedad3, SunatDateUtils.COMPARA_SOLO_FECHA)) ){
				
				Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
						lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo2};
				
				
	 			String val_caracter01 = categoria.substring(0, 2);//ajustado a los anexos 1 y 2 x corresponder PAS20155E220000469 arey				
	 			
				/*Se retira por SAU201510002000131 en PAS20155E220000407*/
				//se corrigue debia buscar las partidas en VAL, estaba pasando para las partidas de tipo no val: PAS20155E220000396
//				if( !tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) &&  
//					(proveedorFuncionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(TIPO_USO_VAL,numPartida.toString(),fechaNumeracion,(!tipoValorEncendido.equals(CAMPO_ZZZ_OLD)?tipoEncendido:CAMPO_ZZZ_OLD),categoria.substring(0,2)))==null){
//				//if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)==null){						
//					Object[] demasArgumentosMSJError2 = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
//							lstDatoSerie.get(0).get("numSecItem"),	"SPN", numPartida.toString(), categoria, tipoEncendido};
//					ErrorDescrMinima error = new ErrorDescrMinima("", "31828", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31828").getDesDatacat(), 
//													ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError2);
//					listError.add(error);							
//				}
				
				Long correlSPN = proveedorFuncionesService.getCorrelPartida(item.getNumpartnandi(),new Long("0"),fechaNumeracion);
				
//				if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null
//						|| proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA7, numPartida.toString(),fechaNumeracion)!=null){
				
				// PAS20191U220500021 - Si est� vigente vigCamAnt2 se hace lo siguiente
				if (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE")) {
					DataCatalogo datosPartida = catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO1_2ANIOS, numPartida.toString());
					if(datosPartida!=null) {
						boolean validaAnnos = false; 
			 			// Para los que tienen tipo de encendido Compresion
						if ( ( catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO1_CATEG_N3, numPartida.toString())!=null && val_caracter01.equals("N3") 
			 					|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO1_CATEG_M3, numPartida.toString())!=null && val_caracter01.equals("M3") )  		 					
							&&  tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) && indicadorSNTT.equals(INDICADOR_SNTT_0) ) {						
			 				
			 				if ((catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_PBRUTO_5TN, categoria.substring(0,2))!=null &&
									catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_VEH_PBRUTO_5TN, numPartida.toString())!=null &&
									(pesoBrutoKg > RESTRICCION_PESOBRUTO_5TN_KG || pesoBrutoSerie.compareTo(new BigDecimal(RESTRICCION_PESOBRUTO_5TN_KG))==1)) //pesoBrutoSerie>5TN
									|| (catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_PBRUTO_12TN, categoria.substring(0,2))!=null &&
									catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_VEH_PBRUTO_12TN, numPartida.toString())!=null &&
									(pesoBrutoKg > RESTRICCION_PESOBRUTO_12TN_KG || pesoBrutoSerie.compareTo(new BigDecimal(RESTRICCION_PESOBRUTO_12TN_KG))==1)) ) { //pesoBrutoSerie>12TN 
			 					validaAnnos = true;
			 				} else {
			 					ErrorDescrMinima error = new ErrorDescrMinima("", "31496", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31496").getDesDatacat(), 
										ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
								listError.add(error);
			 				}
						}
						// Para los que tienen tipo de encendido Chispa
						if (tipoEncendido.equals(TIPO_ENCENDIDO_CHISPA) && datosPartida.getDesAcronimo().indexOf("CH")>-1 && datosPartida.getDesCorta().indexOf(val_caracter01)>-1) {
							validaAnnos = true;
						}
			 			
			 			if(validaAnnos && antiguedadVehiculo2>RESTRICCION_ANTIG_2A�OS){
							ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
									ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
							listError.add(error);
						}	
						
					}
					
		 			String val_caracter02 = categoria.substring(0, 1);//ajustado a los anexos 1 y 2 x corresponder PAS20155E220000469 arey				
		 			
//				 	if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null
			 			if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO2_5ANIOS, numPartida.toString(),fec_validaCatalogo)!=null 
		 					&& ( (val_caracter02.equals("M") && ( 
		 							catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M1, numPartida.toString())!=null 
		 							|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M2, numPartida.toString())!=null 
		 							|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M3, numPartida.toString())!=null ))
		 					  || (val_caracter02.equals("N") && (
		 							 catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N1, numPartida.toString())!=null 
			 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N2, numPartida.toString())!=null 
			 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N3, numPartida.toString())!=null ))
			 				  || (val_caracter02.equals("L") && (
		 							 catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L1, numPartida.toString())!=null 
			 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L2, numPartida.toString())!=null 
			 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L3, numPartida.toString())!=null 
			 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L4, numPartida.toString())!=null )) )//ajustado al anexo 2 x corresponder PAS20155E220000469 arey
		 							
							&& (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) && !tipoValorEncendido.equals(CAMPO_ZZZ_OLD))) ){
		 				//se comenta la lista de exclusion, porque ya se incluyo los catalogos de SPN de anexo 2 PAS20155E220000469 arey
						if(antiguedadVehiculo2>RESTRICCION_ANTIG_5A�OS){ //&& !SunatStringUtils.isStringInList(numPartida.toString(),lstPartidasExcluidas2009_5A)){//exonerada por no corresponder PAS20155E220000451 arey
							
							ErrorDescrMinima error = new ErrorDescrMinima("", "31815", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31815").getDesDatacat(), 
															ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
							listError.add(error);		

						}
						
					}
				} else {
					if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO1_2ANIOS, numPartida.toString(),fec_validaCatalogo)!=null
			 				|| catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO2_5ANIOS, numPartida.toString(),fec_validaCatalogo)!=null){//ajustado al anexo 1 x corresponder PAS20155E220000469 arey
						
//						if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VA7, numPartida.toString(),fechaNumeracion)!=null
						
			 			if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO1_2ANIOS,numPartida.toString(),fec_validaCatalogo)!=null 
			 				&& ( catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO1_CATEG_N3, numPartida.toString(),fec_validaCatalogo)!=null && val_caracter01.equals("N3") 
			 					|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO1_CATEG_M3, numPartida.toString(),fec_validaCatalogo)!=null && val_caracter01.equals("M3") ) //ajustado a los anexos 1 y 2 x corresponder PAS20155E220000469 arey 		 					
							&& ( tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoValorEncendido.equals(CAMPO_ZZZ_OLD))
							&& (								
								(catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_PBRUTO_5TN, categoria.substring(0,2),fec_validaCatalogo)!=null &&
								catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_VEH_PBRUTO_5TN, numPartida.toString(),fec_validaCatalogo)!=null &&
								(pesoBrutoKg > RESTRICCION_PESOBRUTO_5TN_KG || pesoBrutoSerie.compareTo(new BigDecimal(RESTRICCION_PESOBRUTO_5TN_KG))==1)) //pesoBrutoSerie>5TN
								|| (catalogoAyudaService.getDataCatalogo(CATALOGO_CATEGORIAS_VEH_PBRUTO_12TN, categoria.substring(0,2),fec_validaCatalogo)!=null &&
								catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_VEH_PBRUTO_12TN, numPartida.toString(),fec_validaCatalogo)!=null &&
								(pesoBrutoKg > RESTRICCION_PESOBRUTO_12TN_KG || pesoBrutoSerie.compareTo(new BigDecimal(RESTRICCION_PESOBRUTO_12TN_KG))==1)) )//pesoBrutoSerie>12TN
								
								&& ( (!numPartida.toString().equals(SPN_87051) && !numPartida.toString().equals(SPN_87059) && !correlSPN.toString().equals(SPN_87051) && !correlSPN.toString().equals(SPN_87059))
								|| ( (numPartida.toString().equals(SPN_87051) || correlSPN.toString().equals(SPN_87051)) && indicadorSNTT.equals(INDICADOR_SNTT_0) )
								 || ((numPartida.toString().equals(SPN_87059) || correlSPN.toString().equals(SPN_87059)) && indicadorSNTT.equals(INDICADOR_SNTT_0) ) ) ){						
	 
							if(antiguedadVehiculo2>RESTRICCION_ANTIG_2A�OS){
								ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
										ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
								listError.add(error);
							}	
							
						}
						
			 			String val_caracter02 = categoria.substring(0, 1);//ajustado a los anexos 1 y 2 x corresponder PAS20155E220000469 arey				
			 			
//					 	if(proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_VAL, numPartida.toString(),fechaNumeracion)!=null
			 			if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_ANEXO2_5ANIOS, numPartida.toString(),fec_validaCatalogo)!=null 
			 					&& ( (val_caracter02.equals("M") && ( 
			 							catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M1, numPartida.toString())!=null 
			 							|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M2, numPartida.toString())!=null 
			 							|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_M3, numPartida.toString())!=null ))
			 					  || (val_caracter02.equals("N") && (
			 							 catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N1, numPartida.toString())!=null 
				 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N2, numPartida.toString())!=null 
				 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_N3, numPartida.toString())!=null ))
				 				  || (val_caracter02.equals("L") && (
			 							 catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L1, numPartida.toString())!=null 
				 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L2, numPartida.toString())!=null 
				 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L3, numPartida.toString())!=null 
				 						|| catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_ANEXO2_CATEG_L4, numPartida.toString())!=null )) )//ajustado al anexo 2 x corresponder PAS20155E220000469 arey
			 							
								&& (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || (!tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) && !tipoValorEncendido.equals(CAMPO_ZZZ_OLD))) ){
			 				//se comenta la lista de exclusion, porque ya se incluyo los catalogos de SPN de anexo 2 PAS20155E220000469 arey
							if(antiguedadVehiculo2>RESTRICCION_ANTIG_5A�OS){ //&& !SunatStringUtils.isStringInList(numPartida.toString(),lstPartidasExcluidas2009_5A)){//exonerada por no corresponder PAS20155E220000451 arey
								
								ErrorDescrMinima error = new ErrorDescrMinima("", "31815", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31815").getDesDatacat(), 
																ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError); 
								listError.add(error);		
							}
						}				 
					}

				}
		 		
				mapDatosVehiculo.put("numSecProve",lstDatoSerie.get(0).get("numSecProve"));
				mapDatosVehiculo.put("numSecFactura",lstDatoSerie.get(0).get("numSecFactura"));
				mapDatosVehiculo.put("numSecItem",lstDatoSerie.get(0).get("numSecItem"));
				//valKM 
				listError.addAll(validarKmVehiculo(item, declaracion,mapDatosVehiculo, 1));
				listError.addAll(validarKmVehiculo(item, declaracion,mapDatosVehiculo, 2));
								  		
			}			
		}
		return listError;
	}
	
	
	/**
	 * Valida la prohibici�n de Importaci�n para Consumo.
	 * @param   item DatoItem, declaracion Declaracion, mapDatosVehiculo Map<String, Object>, lstDatoSerie List<Map<String, Object>> 
	 * @return listError List<ErrorDescrMinima>
	 */
	public List<ErrorDescrMinima> validarProhibicionImpoConsumo(DatoItem item, Declaracion declaracion,  Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie){
	
		List<ErrorDescrMinima> listError = new ArrayList<ErrorDescrMinima>();
		ProveedorFuncionesService proveedorFuncionesService = fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Long numPartida= item.getNumpartnandi();
		
		Integer fechaNumeracion=0;
		Integer fec_embarque = 0;
		Integer fec_cartaCredito = 0;
	 	Integer fec_valAntiguedad4 = 20090101;
	 	String tipoEncendido = (String) mapDatosVehiculo.get("tipoEncendido");
	 	String categoria = (String) mapDatosVehiculo.get("categoria");
	 	
		if (declaracion.getNumdeclRef() != null) {
			 fechaNumeracion = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		} else {
		     fechaNumeracion = SunatNumberUtils.getTodayAsInteger();
		}
		  
		String tipoValorEncendido=" ";		
		if( (tipoEncendido!="" && tipoEncendido.length()>2 && tipoEncendido.substring(0,2).equals(CAMPO_ZZZ_OLD)) || (tipoEncendido.length()>0 &&  catalogoAyudaService.getDataCatalogo(CATALOGO_TIPO_ENCENDIDO_VEH,tipoEncendido)==null)){
			tipoValorEncendido="ZZZ";	// es valor Otros "ZZZ" en antig estructura u Otros "1" en nueva estructura		
		}
			
		fec_embarque = lstDatoSerie.get(0).get("fechaEmbarque")!=null? SunatDateUtils.getIntegerFromDate(lstDatoSerie.get(0).get("fechaEmbarque")):0;
		fec_cartaCredito = declaracion.getDua().getPago().getPagoTransaccion()!=null?SunatDateUtils.getIntegerFromDate(declaracion.getDua().getPago().getPagoTransaccion().getFeccarcr()):0; 
		
		// PAS20191U220500021 - Se pone vigCamAnt2
		if (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE")) {
			if(declaracion.getDua().getCodregimen().equals(REG_IMPO_CONSUMO) && (!item.getCodestamer().equals(CODIGO_MERCA_SINIESTRADA) && catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA, item.getCodestamer(),null)!=null) ){
				if (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) 
					&& (proveedorFuncionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(TIPO_USO_PROHIBICION_PRO, 
							numPartida.toString(),fechaNumeracion,tipoEncendido,categoria.substring(0,2))!=null)){
					
					Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
							lstDatoSerie.get(0).get("numSecItem"),"SPN", numPartida.toString()};
					ErrorDescrMinima error = new ErrorDescrMinima("", "31495", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31495").getDesDatacat(), 
							ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
					listError.add(error);				
				}
			}
		} else {
			Integer fecValida = fechaNumeracion;
			if (mapDatosVehiculo.get("vigCamAnt2Num").equals("VIGENTE")) 
				fecValida = fec_cartaCredito==0?fec_embarque:fec_cartaCredito;
			if(declaracion.getDua().getCodregimen().equals(REG_IMPO_CONSUMO) && (!item.getCodestamer().equals(CODIGO_MERCA_SINIESTRADA) && catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA, item.getCodestamer(),null)!=null) ){
				if( (tipoEncendido.equals(TIPO_ENCENDIDO_COMPRESION) || tipoValorEncendido.equals(CAMPO_ZZZ_OLD)) 
					&& fechaNumeracion >= fec_valAntiguedad4 
					//&& (proveedorFuncionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig(TIPO_USO_PROHIBICION_SPNVIG_PRO, numPartida.toString(), fechaNumeracion)!=null)
					&& (proveedorFuncionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(TIPO_USO_PROHIBICION_PRO, 
							numPartida.toString(),fecValida,(tipoEncendido!=TIPO_ENCENDIDO_COMPRESION && tipoEncendido!=TIPO_ENCENDIDO_CHISPA? "ZZZ":tipoEncendido),categoria.substring(0,2))!=null)
					&& fecValida >= fec_valAntiguedad4 ){
					
					Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
							lstDatoSerie.get(0).get("numSecItem"),"SPN", numPartida.toString()};
					ErrorDescrMinima error = new ErrorDescrMinima("", "31822", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31822").getDesDatacat(), 
							ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
					listError.add(error);				
				}

			}
		}

		return listError;
	}
	
	
	/**
	 * Valida las restricciones para el ingreso de veh�culos liberados por Diplom�ticos y Funcionarios Extranjeros.
	 * @param item DatoItem, Declaracion declaracion, lstDatoSerie List<Map<String, Object>> 
	 * @return listError List<ErrorDescrMinima>
	 */
	public List<ErrorDescrMinima> validarRestriccionFuncExtranjeros(DatoItem item, Declaracion declaracion, Map<String, Object> mapDatosVehiculo, List<Map<String, Object>> lstDatoSerie){
		
		List<ErrorDescrMinima> listError = new ArrayList<ErrorDescrMinima>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ProveedorFuncionesService proveedorFuncionesService = fabricaDeServicios.getService("funcionesService");
		
		Integer fechaNumeracion=0;
		
		 if (declaracion.getNumdeclRef() != null) {
			 fechaNumeracion = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		 } else {
		     fechaNumeracion = SunatNumberUtils.getTodayAsInteger();
		 }
		 
		Long numPartida= item.getNumpartnandi();	

		int anioEmbarque = SunatNumberUtils.getAnioFromDate(SunatDateUtils.getIntegerFromDate(lstDatoSerie.get(0).get("fechaEmbarque")!=null?lstDatoSerie.get(0).get("fechaEmbarque"):0));
		int antiguedadVehiculo = 0;
		if ((mapDatosVehiculo.get("vigCamAnt1").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("NUEVA")) 
				|| (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE") && mapDatosVehiculo.get("estadoMerca").equals("USADA")))
			antiguedadVehiculo=obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString()), anioEmbarque);
		else
			antiguedadVehiculo=obtenerAntiguedadVeh�culo(new Integer(item.getAnnfabrica()), anioEmbarque);
		Long correlSPN = proveedorFuncionesService.getCorrelPartida(item.getNumpartnandi(),new Long("0"),fechaNumeracion);
		
		
		if(( //declaracion.getDua().getCodtipotratamiento().equals(TRATAMIENTO_MERCA_DIPLOMATICO) && 
				catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_DIPLOMATICO, (lstDatoSerie.get(0).get("codLiberatorio")).toString(),null)!=null
				&& lstDatoSerie.get(0).get("docAutorizaId")==null)				
		|| ( catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_EXTRANJERO, (lstDatoSerie.get(0).get("codLiberatorio")).toString(),null)!=null
				&& lstDatoSerie.get(0).get("docAutorizaId")==null)){//c�digo de uso oficial dipl. extr. requiere Resoluci�n Liberatoria

			Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
					lstDatoSerie.get(0).get("numSecItem"),"DOCUMENTO AUTORIZACION", ""};
			ErrorDescrMinima error = new ErrorDescrMinima("", "31827",catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31827").getDesDatacat(), 
											ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
			listError.add(error);					
		}

		
		if(declaracion.getDua().getCodregimen().equals(REG_IMPO_CONSUMO) && (catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA, item.getCodestamer(),null)!=null)){
			if(SunatStringUtils.isStringInList(lstDatoSerie.get(0).get("codLiberatorio").toString(),CODIGO_LIB_RESTRICCION)){
		
				// PAS20191U220500021 - Cambio en validaci�n 
				Date fec_verificacionVigCam = (Date)mapDatosVehiculo.get("fecValida");
				if (mapDatosVehiculo.get("vigCamAnt2").equals("VIGENTE")){
					// La antiguedad es en base al a�o modelo
					antiguedadVehiculo = obtenerAntiguedadVeh�culo(new Integer(mapDatosVehiculo.get("annModelo").toString()), anioEmbarque);
					if( catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, numPartida.toString(), fec_verificacionVigCam)==null 
							&& catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, correlSPN.toString(), fec_verificacionVigCam)==null){

							Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
									lstDatoSerie.get(0).get("numSecItem"),"SPN", numPartida.toString()};					
							ErrorDescrMinima error = new ErrorDescrMinima("", "31826", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31826").getDesDatacat(), 
															ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
							listError.add(error);	
					} else {
						if(antiguedadVehiculo > RESTRICCION_ANTIG_2A�OS){
							
							Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
									lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo};
							ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
									ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
							listError.add(error);
						}
					}
					
					if(lstDatoSerie.get(0).get("docAutorizaId") == null){		
						Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
								lstDatoSerie.get(0).get("numSecItem"),"DOCUMENTO AUTORIZACION", ""};
						ErrorDescrMinima error = new ErrorDescrMinima("", "31827",catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31827").getDesDatacat(), 
														ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
						listError.add(error);						
					}
					
				} else {
					if( catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_5ANIOS, numPartida.toString(),fec_verificacionVigCam)==null 
							&& catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_5ANIOS, correlSPN.toString(),fec_verificacionVigCam)==null
							&& catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, numPartida.toString(),fec_verificacionVigCam)==null 
							&& catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, correlSPN.toString(),fec_verificacionVigCam)==null){

							Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
									lstDatoSerie.get(0).get("numSecItem"),"SPN", numPartida.toString()};					
							ErrorDescrMinima error = new ErrorDescrMinima("", "31826", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31826").getDesDatacat(), 
															ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
							listError.add(error);	
						} 
						 
						if(lstDatoSerie.get(0).get("docAutorizaId") == null){		
							
							Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
									lstDatoSerie.get(0).get("numSecItem"),"DOCUMENTO AUTORIZACION", ""};
							ErrorDescrMinima error = new ErrorDescrMinima("", "31827",catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31827").getDesDatacat(), 
															ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
							listError.add(error);						
						}
										
						if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_5ANIOS, numPartida.toString(),fec_verificacionVigCam)!=null
								|| catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_5ANIOS, correlSPN.toString(),fec_verificacionVigCam)!=null){					
							
							if(antiguedadVehiculo>RESTRICCION_ANTIG_5A�OS){
								
								Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
										lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo};
								ErrorDescrMinima error = new ErrorDescrMinima("", "31815", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31815").getDesDatacat(), 
										ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
								listError.add(error);		
							}
						}
						
						if(catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, numPartida.toString(),fec_verificacionVigCam)!=null
								|| catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_RESTRICCION_2ANIOS, correlSPN.toString(),fec_verificacionVigCam)!=null){					
							if(antiguedadVehiculo>RESTRICCION_ANTIG_2A�OS){
									
								Object[] demasArgumentosMSJError = new Object[] {lstDatoSerie.get(0).get("numSecProve"),lstDatoSerie.get(0).get("numSecFactura"),
										lstDatoSerie.get(0).get("numSecItem"),"ANTIGUEDAD VEHICULO", antiguedadVehiculo};
								ErrorDescrMinima error = new ErrorDescrMinima("", "31814", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "31814").getDesDatacat(), 
										ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
								listError.add(error);
							}
						}
				}
				}
	
		}
		return listError;
	}

/*
    public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	*/
}
