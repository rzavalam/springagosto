package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.aop.target.HotSwappableTargetSource;
import pe.gob.sunat.despaduanero.despacho.comun.impo.model.TabImpDU;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Estabnoapto;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.CircunoceDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionSIGADService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.AutorizacionZonaPrimariaService;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.SolicitudAutorizacionZonaPrimaria;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.service.ConsultaLiquidacionService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionPerfecService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionReexpService;


//import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;


/**
 * @author fjonislla
 * 
 *         Clase que sirve para validar el punto de llegada de la mercancia para
 *         los despachos anticipados
 * @param <Date>
 * 
 */
public class ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado extends ValidarPuntoLlegadaMercaderiaAbstract implements ValidadorPuntoLlegadaMercancia {

	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO = { "1", "2", "3" }; //Bug P_SNAA0004-9943
//RIN05  PAS20181U220200004 MORDONEZL
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_MANIFIESTOFLUVIALYTERRESTRE = { "1","2","3","14"}; //Bug P_SNAA0004-9943
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO  = { "1", "2", "3", "4"};
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO_EER  = { "1", "2", "3", "4",ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};//PAS20181U220200049
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_EER  = {ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_ZONA_PRIMARIA_DESPACHO_ANTICIPADO = { "9" };

	// estos valores se tiene que llenar en el contructor de la clase
	private String codigoLugarDescarga = null;
	private String codigoPuntoLLegadaMercancia = null;
	private String regimen = null;
	private String codigoAduanaTransmision = null;
	//numero de ruc del deposito
	private String numeroRUCdeposito = null;
	//numero de ruc del punto de llegada
	private String numeroRUCpuntoLlegada = null;
	//numero de ruc del due�o consignatario importador
	private String numeroRUCduenioConsignatario = null;
	private Elementos<DatoSerie> listSeries;
	private String annManifiesto = null;
	private String codModTranspo= null;
	private String numManifiesto= null;
	private List<DatoDocTransporte> lstdocumentostrans = null;
	//private McdetaDAO mcdetaDAO=null;
	
	
	//LMVR - Complemento de la Dua Parte II
	//private CatalogoHelperImpl catalogoHelper;

	//private GetDeclaracionService getDeclaracionService;
	private ConsultaLiquidacionService consultaLiquidacionService;
	//private FabricaDeServicios fabricaDeServicios;	
	private HotSwappableTargetSource swapperDatasource;
	//private CabDeclaraDAO cabDeclaraDAO;
	private String codLocalAnexo = null;
	private String codTipoDocIdent = null;
	private BigDecimal montoFobDolares = null;
	private ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService;
	private ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService;
	private ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService;
	private ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService;
	
	private AutorizacionZonaPrimariaService autorizacionZonaPrimariaService ;
	private String codigoTransaccion = null;
	private boolean esManifiestoEerSda;//PAS20181U220200049
	private boolean esManifiestoEerSigad;//PAS20181U220200064
	
	/**
	 * Constructor 
	 * @param codigoAduanaTransmision codigo de la aduana de transmision
	 * @param regimen regimen de la dua
	 * @param codigoLugarDescarga codigo del lugar del tipo de lugar de descarga
	 * @param codigoPuntoLLegadaMercancia codigo del tipo de punto de llegada
	 * @param numeroRUCpuntoLlegada numero de ruc del punto de llegada
	 * @param numeroRUCdeposito numero de ruc del deposito
	 * @param numeroRUCduenioConsignatario numero de ruc del due�o o consignatario
	 * @param dataCatAsocDAO Dao para verificar las asociaciones de catalogos
	 * @param catalogoHelper utilitario para validar operadores de comercio
	 */
	ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado(){
		super();
	}
	
	public ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado(
			//codigo de la aduana
			String codigoAduanaTransmision,
			//codigo del regimen
			String regimen,
			//lista de series para poder obtener los regimenes de precedencia
			Elementos<DatoSerie> listSeries,
			// codigo del lugar de recpcion
			String codigoLugarDescarga,
			//codigo del punto de llegada
			String codigoPuntoLLegadaMercancia,
			//numero de ruc del lugar de descarga
			String numeroRUCpuntoLlegada,
			//numero de ruc del deposito			
			String numeroRUCdeposito,			
			//numero de ruc del due�o consignatario importador
			String numeroRUCduenioConsignatario,
			//CatalogoHelperImpl catalogoHelper,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO  mcdetaDAO,
			String codLocalAnexo,
			String codTipoDocIdent,
			BigDecimal montoFobDolares,
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService,
			ConsultaLiquidacionService consultaLiquidacionService,
			GetDeclaracionService getDeclaracionService,
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService,
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService,
			ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService,
			ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			CabDeclaraDAO cabDeclaraDAO,
			ManifiestoSigadService manifiestoSigadService,String codigoTransaccion,
			CircunoceDAO circunoceDAO) //RIN 13-619
	
	{
		
		//codigo de la aduana
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		//codigo del regimen
		this.regimen =regimen;
		//regimen precedente
		this.listSeries = listSeries;
		// codigo del lugar de recpcion
		this.codigoLugarDescarga = codigoLugarDescarga;
		//codigo del punto de llegada
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		//numero de ruc del lugar de descarga
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
		//numero de ruc del deposito			
		this.numeroRUCdeposito = numeroRUCdeposito;
		//numero de ruc del due�o consignatario importador
		this.numeroRUCduenioConsignatario = numeroRUCduenioConsignatario;
		//this.catalogoHelper = catalogoHelper;
		this.fechaReferencia = fechaReferencia;
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		
		this.codLocalAnexo = codLocalAnexo;
		this.codTipoDocIdent = codTipoDocIdent;
		this.autorizacionZonaPrimariaService =autorizacionZonaPrimariaService;
		this.montoFobDolares =montoFobDolares;
		this.consultaLiquidacionService =consultaLiquidacionService;
		//this.getDeclaracionService =getDeclaracionService;
		this.consultaDeclaracionImpoConsumoService =consultaDeclaracionImpoConsumoService;
		this.consultaDeclaracionDepositoAduaneroService =consultaDeclaracionDepositoAduaneroService;
		this.consultaDeclaracionImportacionAdmisionReexpService =consultaDeclaracionImportacionAdmisionReexpService;
		this.consultaDeclaracionImportacionAdmisionPerfecService =consultaDeclaracionImportacionAdmisionPerfecService;
		this.fabricaDeServicios =fabricaDeServicios;
		this.swapperDatasource =swapperDatasource;
		//this.cabDeclaraDAO =cabDeclaraDAO;
		this.codigoTransaccion =codigoTransaccion;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		
	}
	
	//PAS20181U220200049
	public ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado(
			//codigo de la aduana
			String codigoAduanaTransmision,
			//codigo del regimen
			String regimen,
			//lista de series para poder obtener los regimenes de precedencia
			Elementos<DatoSerie> listSeries,
			// codigo del lugar de recpcion
			String codigoLugarDescarga,
			//codigo del punto de llegada
			String codigoPuntoLLegadaMercancia,
			//numero de ruc del lugar de descarga
			String numeroRUCpuntoLlegada,
			//numero de ruc del deposito			
			String numeroRUCdeposito,			
			//numero de ruc del due�o consignatario importador
			String numeroRUCduenioConsignatario,
			//CatalogoHelperImpl catalogoHelper,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO  mcdetaDAO,
			String codLocalAnexo,
			String codTipoDocIdent,
			BigDecimal montoFobDolares,
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService,
			ConsultaLiquidacionService consultaLiquidacionService,
			GetDeclaracionService getDeclaracionService,
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService,
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService,
			ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService,
			ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			CabDeclaraDAO cabDeclaraDAO,
			ManifiestoSigadService manifiestoSigadService,String codigoTransaccion,
			CircunoceDAO circunoceDAO,
			boolean esManifiestoEerSda,
			boolean esManifiestoEerSigad) //RIN 13-619
	
	{
		
		//codigo de la aduana
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		//codigo del regimen
		this.regimen =regimen;
		//regimen precedente
		this.listSeries = listSeries;
		// codigo del lugar de recpcion
		this.codigoLugarDescarga = codigoLugarDescarga;
		//codigo del punto de llegada
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		//numero de ruc del lugar de descarga
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
		//numero de ruc del deposito			
		this.numeroRUCdeposito = numeroRUCdeposito;
		//numero de ruc del due�o consignatario importador
		this.numeroRUCduenioConsignatario = numeroRUCduenioConsignatario;
		//this.catalogoHelper = catalogoHelper;
		this.fechaReferencia = fechaReferencia;
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		
		this.codLocalAnexo = codLocalAnexo;
		this.codTipoDocIdent = codTipoDocIdent;
		this.autorizacionZonaPrimariaService =autorizacionZonaPrimariaService;
		this.montoFobDolares =montoFobDolares;
		this.consultaLiquidacionService =consultaLiquidacionService;
		//this.getDeclaracionService =getDeclaracionService;
		this.consultaDeclaracionImpoConsumoService =consultaDeclaracionImpoConsumoService;
		this.consultaDeclaracionDepositoAduaneroService =consultaDeclaracionDepositoAduaneroService;
		this.consultaDeclaracionImportacionAdmisionReexpService =consultaDeclaracionImportacionAdmisionReexpService;
		this.consultaDeclaracionImportacionAdmisionPerfecService =consultaDeclaracionImportacionAdmisionPerfecService;
		this.fabricaDeServicios =fabricaDeServicios;
		this.swapperDatasource =swapperDatasource;
		//this.cabDeclaraDAO =cabDeclaraDAO;
		this.codigoTransaccion =codigoTransaccion;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		this.esManifiestoEerSda = esManifiestoEerSda; //PAS20181U220200049
		this.esManifiestoEerSigad = esManifiestoEerSigad;//PAS20181U220200064
	}	
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidarPuntoLlegadaMercancia#validar()
	 */
	public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
  		validarTipoLugarDescarga(fechaReferencia, regimen, codModTranspo);
		validarTipoLugarDescargaPorRegimen(regimen, numeroRUCdeposito, fechaReferencia, codAduana);		
		validarRegimenPrecedente(regimen);		
		/*RIN13INSI*/ 
		/*SE A�ADIO TRANSACCION 1012*/ 
		if(codigoLugarDescarga.equals("04") && (codigoTransaccion.endsWith("01") || codigoTransaccion.endsWith("03") || codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) || codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)
		|| codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION))){
		 validarAutorizacionEspecialZonaPrimaria();
		 validarRequisitosZonaPrimaria();
		}

	
	}	
	
	
	//LMVR - Complemento de la Dua Parte II
	public void validarAutorizacionEspecialZonaPrimaria() throws PuntoLLegadaValidadorException {

		String codTipoOper = "45";
		DataCatalogo tipPartic = new DataCatalogo();
		tipPartic.setCodDatacat(codTipoOper);
		
		SimpleDateFormat formato = new 	SimpleDateFormat("dd/MM/yyyy");  
		String resultado = formato.format(fechaReferencia);  
		Date fechaReferenciaNew = SunatDateUtils.getDate(resultado, "dd/MM/yyyy")   ;
		Date fechaHoy =SunatDateUtils.getCurrentDate() ;
		String resultadoHoy = formato.format(fechaHoy); 
		//Date fechaReferenciaHoy = SunatDateUtils.getDate(resultadoHoy, "dd/MM/yyyy")   ;
		/*PAS20155E220000501*/ 
		/*amancilla por defecto toma la fecha de la numeracion por tal motivo se comenta esto se puso en la rin13 pero no deberia tomar la fecha sysdate*/
		/*
		if(codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)|| codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)
                || codigoTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)){
			fechaReferenciaNew=SunatDateUtils.getDate(resultadoHoy, "dd/MM/yyyy")   ;
		}else{
			fechaReferenciaNew = SunatDateUtils.getDate(resultado, "dd/MM/yyyy")   ;
		}*/
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
	    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaHoy):false;
		//RN 145 - Obetner la autorizacion de zona Especial
		SolicitudAutorizacionZonaPrimaria conRuc = new SolicitudAutorizacionZonaPrimaria();
		conRuc.setParticipante(new Participante());
		conRuc.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
		conRuc.getParticipante().setCiudad(codLocalAnexo);
		conRuc.getParticipante().setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
		conRuc.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(codigoAduanaTransmision);
		conRuc.getDatoOtroDocSoporte().setCodtipodocasoc(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS); // PAS20181U220200004
		
		List<SolicitudAutorizacionZonaPrimaria> listRUc = autorizacionZonaPrimariaService.consultarAutorizacionZonaPrimaria(conRuc);
		
		if(listRUc == null || listRUc.isEmpty()){
			if(!esVigenteRIN05SegundaParte){
				throw new PuntoLLegadaValidadorException("30670",
						new String[] { codTipoOper,numeroRUCduenioConsignatario,codLocalAnexo,codTipoDocIdent}, "IMPORTADOR [{3}-{1}] NO CUENTA CON AUTORIZACI�N ESPECIAL PARA DESPACHO EN ZONA PRIMARIA PARA EL LOCAL ANEXO [{2}]");
			}else{
			//String fechaSinHora = SunatDateUtils.getFormatDate(fechaHoy, "dd/MM/yyyy");	
			//Date fecha = SunatDateUtils.getDate(fechaSinHora);							
			List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,null, null, null, numeroRUCduenioConsignatario, null);
				if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
					throw new PuntoLLegadaValidadorException("30670",
							new String[] { codTipoOper,numeroRUCduenioConsignatario,codLocalAnexo,codTipoDocIdent}, "IMPORTADOR [{3}-{1}] NO CUENTA CON AUTORIZACI�N ESPECIAL PARA DESPACHO EN ZONA PRIMARIA PARA EL LOCAL ANEXO [{2}]");
					
				}
			}
			
			
				
		}
		
		
		//RN 146 - Se verifica la vigencia con respecto a las autorizaciones asociadas al importador 
		SolicitudAutorizacionZonaPrimaria conVigencia = new SolicitudAutorizacionZonaPrimaria();
		conVigencia.setParticipante(new Participante());
		conVigencia.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
		conVigencia.getParticipante().setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
		conVigencia.setFechaVigencia(fechaReferenciaNew);
		conVigencia.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(codigoAduanaTransmision);
		conRuc.getDatoOtroDocSoporte().setCodtipodocasoc(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS); //PAS20181U220200004
		List<SolicitudAutorizacionZonaPrimaria> listVigencia = autorizacionZonaPrimariaService.consultarAutorizacionZonaPrimaria(conVigencia);
	
	
		
		if(listVigencia == null || listVigencia.isEmpty() ){
			if(!esVigenteRIN05SegundaParte){
			throw new PuntoLLegadaValidadorException("30671",
					new String[] {}, "AUTORIZACI�N DE ZONA PRIMARIA ESPECIAL CON PLAZO NO VIGENTE");
			}else{
				String fechaSinHora = SunatDateUtils.getFormatDate(fechaHoy, "dd/MM/yyyy");	
			    Date fecha = SunatDateUtils.getDate(fechaSinHora);						
				List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,null, null, null, numeroRUCduenioConsignatario, fecha);
				if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
					throw new PuntoLLegadaValidadorException("30671",
							new String[] {}, "AUTORIZACI�N DE ZONA PRIMARIA ESPECIAL CON PLAZO NO VIGENTE");
				}
			}
		}else{
			
		SolicitudAutorizacionZonaPrimaria conLocal = new SolicitudAutorizacionZonaPrimaria();
		conLocal.setParticipante(new Participante());
		conLocal.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
		conLocal.getParticipante().setCiudad(codLocalAnexo);
		conLocal.getParticipante().setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
		conLocal.setFechaVigencia(fechaReferenciaNew);
		conLocal.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(codigoAduanaTransmision);
		conRuc.getDatoOtroDocSoporte().setCodtipodocasoc(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS); //PAS20181U220200004
		// RN 144 - Se verifica la vigencia con respecto a las autorizaciones asociadas al importador
		List<SolicitudAutorizacionZonaPrimaria> listLocal = autorizacionZonaPrimariaService.consultarAutorizacionZonaPrimaria(conLocal);
		if(listLocal == null || listLocal.isEmpty()){
			throw new PuntoLLegadaValidadorException("30672",
					new String[] {codLocalAnexo}, "LOCAL DECLARADO [{0}] NO SE ENCUENTRA HABILITADO PARA REALIZAR DESPACHO EN ZONA PRIMARIA CON AUTORIZACION ESPECIAL");	
		}

		//INICIO RIN13- Solo para SEIDA
		//Buscar que el local no se encuentre como no apto 
		Estabnoapto localNoApto=  autorizacionZonaPrimariaService.buscarEstablecimientosNoApto(this.numeroRUCduenioConsignatario, Short.valueOf(codLocalAnexo), SunatDateUtils.getIntegerFromDate(fechaReferencia));
		//Local encontrado
		if (localNoApto != null ){
			throw new PuntoLLegadaValidadorException("35273",
					new String[] {codLocalAnexo}, "LOCAL NO APTO PARA RECONOCIMIENTO FISICO EN ZPAE");	
		}
		//FIN RIN13
	  }
	}
		
	
		
		
		
	
	
	//RN 148 - LMVR -Validar los requisitos que debe cumplir el importador a pesar de tener autorizaci�n de zona Primaria
	public void  validarRequisitosZonaPrimaria() throws PuntoLLegadaValidadorException {
		
		Date fechaHoy =SunatDateUtils.getCurrentDate() ;
		Date fechaDesde = SunatDateUtils.addMonth(fechaHoy, -12);
		
		//148-5.1
		Integer count = 0;
		count = consultaLiquidacionService.consultarResFirmePerdidaFraccionamiento(codTipoDocIdent,numeroRUCduenioConsignatario,fechaHoy,fechaDesde,codigoAduanaTransmision);
		
		if(count>0){
			throw new PuntoLLegadaValidadorException("30673",
					new String[] {numeroRUCduenioConsignatario}, "EL IMPORTADOR CON RUC [{0}] TIENE PERDIDA DE FRACCIONAMIENTO. NO PUEDE ACOGERSE A DESPACHO EN ZONA PRIMARIA ESPECIAL");
	}	
	
		//148-5.2 
		if(!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)){
			Map<String,Object> paramRegDeposito=new HashMap<String,Object>();
			paramRegDeposito.put("COD_TIPDOC", codTipoDocIdent);
			paramRegDeposito.put("NUM_DOCIDENT", numeroRUCduenioConsignatario);
			paramRegDeposito.put("FEC_FIN", fechaHoy);
			paramRegDeposito.put("FEC_INI", fechaDesde);

			paramRegDeposito.put("FEC_DECLARACION", fechaHoy);
			paramRegDeposito.put("COD_TIPPARTIC", "45");
			paramRegDeposito.put("COD_ESTDUA", "'08'");
			paramRegDeposito.put("COD_ESTADMIN", "'A'");
			paramRegDeposito.put("COD_TIPDEUDA", "01");
			paramRegDeposito.put("COD_ESTPAGO", "P");
						
			boolean tiene10Duas = false;
			tiene10Duas = this.obtenerCantidadDeclaraciones(paramRegDeposito);
			if(!tiene10Duas){
				throw new PuntoLLegadaValidadorException("30674",
						new String[] {numeroRUCduenioConsignatario}, "EL IMPORTADOR CON IDENTIFICACION [{0}] NO TIENE 10 DECLARACIONES COMO MINIMO PARA DESPACHO ANTICIPADO EN ZONA PRIMARIA CON AUTORIZACION ESPECIAL");	
			}
		}
		

		//148-5.3
		Integer contMultas = 0;
		String codAduanCentra = "000";
		Map<String,Object> paramMultas=new HashMap<String,Object>();
		
		paramMultas.put("rltipdoc", codTipoDocIdent);
		paramMultas.put("rllibtri", numeroRUCduenioConsignatario);
		paramMultas.put("fechaFin", fechaHoy);
		paramMultas.put("fechaInicio", fechaDesde);
		paramMultas.put("rltipliq", "'0003'");//Se quito 0027
		paramMultas.put("rlcodco1", "'A31','A32','C9'");
		
		contMultas = this.countLiquidaSelective(paramMultas,codAduanCentra);
		if(contMultas>0){
			throw new PuntoLLegadaValidadorException("30675",
					new String[] {numeroRUCduenioConsignatario}, "IMPORTADOR INHABILITADO PARA USO DEL SISTEMA ANTICIPADO, TIENE MULTA POR INFRACCI�N NU. 2 O 3 INC.A; NU. 9 INC. C");	
			
		}
		
		//RN 148-5.4
		
		Map<String,Object> paramPendienteReg=new HashMap<String,Object>();
	        
			paramPendienteReg.put("COD_TIPDOC_IMP", codTipoDocIdent);
			paramPendienteReg.put("NUM_DOCIDENT_IMP", numeroRUCduenioConsignatario);
			paramPendienteReg.put("COD_MODALIDAD", ConstantesDataCatalogo.MODA_ANTICIPADA);
			paramPendienteReg.put("PLAZO", ConstantesDataCatalogo.PLAZO_REGULARIZACION);
			paramPendienteReg.put("INDICADOR_REGUL", "true");
			paramPendienteReg.put("ENVIO_REGUL", "trueAnticipada");
		paramPendienteReg.put("COD_TIPLUGARRECEP",ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION);
		paramPendienteReg.put("CON_LEVANTE",true);
			
//		List<Declaracion> tieneDespPorRegularizarAnticipadas =  cabDeclaraDAO.findDeclaraPendienteRegularizacion(paramPendienteReg);
		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		List<Declaracion> tieneDespPorRegularizarAnticipadas =  getDeclaracionService.getDeclaracionPendienteRegularizar(paramPendienteReg);
		
	
	//	if((tieneDespPorRegularizarAnticipadas.size()>0 && !tieneDespPorRegularizarAnticipadas.isEmpty())){
			ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");			
			String strdeclaracion = " ";
			for(Declaracion declaracionPendiente:tieneDespPorRegularizarAnticipadas){
				Long numCorredoc = declaracionPendiente.getDua().getNumcorredoc();
				String codaduana = declaracionPendiente.getCodaduana();
				String annpresen = declaracionPendiente.getDua().getAnnpresen().toString();
				String codregimen= declaracionPendiente.getCodregimen();
				String numdeclaracion = SunatStringUtils.toStringObj(declaracionPendiente.getNumeroDeclaracion());
				Date fechaVencimiento = declaracionPendiente.getDua().getFecvencregula();
				List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspension(codaduana, annpresen, codregimen, numdeclaracion,fechaVencimiento);
				if (CollectionUtils.isEmpty(expedienteSuspension) ) {
					List<DatoIndicadores> listIndicadorAbandonoVol = 
							funcionesService.getIndicadorDUA(numCorredoc, ConstantesDataCatalogo.INDICADOR_ABANDONO_VOLUNTARIO, null, ConstantesDataCatalogo.IND_ACTIVO);
					if (CollectionUtils.isEmpty(listIndicadorAbandonoVol)){
						String CDApendiente = "(".concat(codaduana).concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion).concat(")");
						strdeclaracion = strdeclaracion.concat(CDApendiente).concat(" ");
					}
				}
			}
			GetDeclaracionSIGADService getDeclaracionSIGADService = fabricaDeServicios.getService("declaracionSIGADService");	
			Participante importador = new Participante();
			importador.getTipoDocumentoIdentidad().setCodDatacat(codTipoDocIdent);
	        importador.setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
			List<TabImpDU> listdeclaracionPendienteSIGAD = getDeclaracionSIGADService.getDeclaracionPendienteRegularizarSIGAD(importador, codigoAduanaTransmision,fechaReferencia, ConstantesDataCatalogo.TIPO_DESPACHO_ANTICIPADO);
			for(TabImpDU declaracionPendiente:listdeclaracionPendienteSIGAD){
				String codaduana = declaracionPendiente.getCodiAduan();
				String annpresen = declaracionPendiente.getAnoPrese();
				String codregimen= declaracionPendiente.getCodiRegi();
				String numdeclaracion = declaracionPendiente.getNumeCorre();
				Date fechaVencimiento = SunatDateUtils.getDateFromInteger(declaracionPendiente.getFechVenci());
				Date fechaSegundaGED = getDeclaracionSIGADService.getFechaSegundaRecepcionSIGAD(codaduana, annpresen, codregimen, numdeclaracion);
				String CDApendiente = codaduana.concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion);
				List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspension(codaduana, annpresen, codregimen, numdeclaracion,fechaVencimiento);					
				if (CollectionUtils.isEmpty(expedienteSuspension)  ) {
					if (fechaSegundaGED == null || SunatDateUtils.isDefaultDate(fechaSegundaGED )){
						CDApendiente = "(".concat(codaduana).concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion).concat(")");
						strdeclaracion = strdeclaracion.concat(CDApendiente).concat(" ");
					} else { //puede estar observada
						if (SunatStringUtils.include(declaracionPendiente.getFlagAnul(), 
								new String[]{ConstantesDataCatalogo.ESTADO_OBSERVADO_PLAZO_VENCIDO, ConstantesDataCatalogo.ESTADO_OBSERVADO_NOTIFICADO, ConstantesDataCatalogo.ESTADO_OBSERVADO_NOREGULARIZADA_FIE})) {								
							CDApendiente = "(".concat(codaduana).concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion).concat(")");
							strdeclaracion = strdeclaracion.concat(CDApendiente).concat(" ");
						}
					}
				}					
			}
			if (!SunatStringUtils.isEmptyTrim(strdeclaracion)) {
				throw new PuntoLLegadaValidadorException("30676",
						new String[] {numeroRUCduenioConsignatario, strdeclaracion}, "EL IMPORTADOR CON IDENTIFICACION [{0}] REGISTRA DESPACHOS ANTICIPADOS PENDIENTES POR REGULARIZAR, VERIFIQUE EN LA PAGINA WEB O EN LAS INTENDENCIAS OPERATIVAS");
							
			}


		
		//RN 148-5.5
	
		double c=2000;
        BigDecimal b = new BigDecimal(c);
		BigDecimal diferencia = SunatNumberUtils.diference(b, montoFobDolares);
			 
		 if(diferencia.doubleValue()>0){
			 throw new PuntoLLegadaValidadorException("30677",
						new String[] {numeroRUCduenioConsignatario}, "PARA ACOGERSE A DESPACHO ANTICIPADO EN ZONA PRIMARIA CON AUTORIZACION ESPECIAL EL VALOR FOB DE LA MERCANCIA DEBE SER MAYOR A DOS MIL DOLARES DE LOS ESTADOS UNIDOS DE AMERICA");			
		 }
	}
	
	/*public Integer countLiquidaSelective (Map<String,Object> params, String codaduanaConex){
		ConsultaLiquidacionService consultaLiquidacionService = fabricaDeServicios.getService("declaracion.ingreso.consultaLiquidacionService");
		DataSourceContextHolder.setKeyDataSource(codaduanaConex);
		Integer countMultas = consultaLiquidacionService.consultarMultasFirmes(params);
	    return countMultas;
	}*/
		
	public synchronized Integer countLiquidaSelective (Map<String,Object> params, String codaduanaConex){
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds."+ codaduanaConex)); 
		Integer countMultas = consultaLiquidacionService.consultarMultasFirmes(params);
	    swapperDatasource.swap(o);
	    return countMultas;
	}
	
	//LMVR - Permite obtener las declaraciones numeradas ya sea del ASIGAD como del NSIGAD
	private boolean obtenerCantidadDeclaraciones(Map<String,Object> params){
		
				
		boolean res = false;                         
			//Integer cantidad = getDeclaracionService.countDeclaraciones(params);
				//	if(cantidad<10){
				    Integer  cantidad = consultaDeclaracionImpoConsumoService.countDeclaracionImportacionConsumo(params);
						if(cantidad<10){
							cantidad+=consultaDeclaracionImportacionAdmisionPerfecService.countDeclaracionImportacionAdmisionPerfec(params);
							//cantidad+=consultaDeclaracionDepositoAduaneroService.countDeclaracionDepositoAduanero(params);
							if(cantidad<10){
								cantidad+=consultaDeclaracionImportacionAdmisionReexpService.countDeclaracionImportacionAdmisionReexp(params);
								if(cantidad<10){
									//cantidad+=consultaDeclaracionImportacionAdmisionPerfecService.countDeclaracionImportacionAdmisionPerfec(params);
									cantidad+=consultaDeclaracionDepositoAduaneroService.countDeclaracionDepositoAduanero(params);
									if(cantidad<10){
										res =false;
									}else{
										res =true;
									}
								}else{
									res =true;
								}
							}else{
								res =true;
							}
						}else{
							res =true;
						}
					//}else{
					//	res =true;
				//}

	 return res;
 }
	
	
	
	/**
	 * Valida el regimen d precedencia de las series
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(String regimen) throws PuntoLLegadaValidadorException{

		if (!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)) {
			for (DatoSerie serie : listSeries) {
				validarRegimenPrecedente(serie);

			}
		}	
	}

	/**
	 * Valida el regimen precedente de la serie
	 * @param serie
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(DatoSerie serie) throws PuntoLLegadaValidadorException {
		Elementos<DatoRegPrecedencia> listRegPrecedencia = serie.getListRegPrecedencia();
		String codigoRegimenPrecedente = buscarPrimerRegimenPrecedente(listRegPrecedencia);
		//Bug 17751 
		if(codigoRegimenPrecedente.length()>0){
		validarRegimenPrecedente(serie.getNumserie(), codigoRegimenPrecedente);
		}
	}

	/**
	 * Busca el tipo del primer regimen precedente de la serie
	 * @param listRegPrecedencia
	 * @return
	 */
	private String buscarPrimerRegimenPrecedente(Elementos<DatoRegPrecedencia> listRegPrecedencia) {
		String codigoRegimenPrecedente = "";
		
		if(CollectionUtils.isNotEmpty(listRegPrecedencia)){
			//buscamos por tipo de regimen
			codigoRegimenPrecedente = listRegPrecedencia.get(0).getCodregipre();
			DatoRegPrecedencia datoRegPrecedencia = (DatoRegPrecedencia)CollectionUtils.find(listRegPrecedencia, new Predicate() {
				
				@Override
				public boolean evaluate(Object arg0) {
					String codigoRegimenPrecedente = ((DatoRegPrecedencia)arg0).getCodregipre();
					return CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente);
				}
			});
			
			if(datoRegPrecedencia != null){
				codigoRegimenPrecedente = datoRegPrecedencia.getCodregipre();
			} 
		}
		return codigoRegimenPrecedente;
	}

	/**
	 * Valida el codigo de regimen precedente
	 * @param numeroSerie numero de serie a mostrar en la excepcion
	 * @param codigoRegimenPrecedente
	 * @throws PuntoLLegadaValidadorException si no es valido lanza una excepcion
	 */
	private void validarRegimenPrecedente(Integer numeroSerie, String codigoRegimenPrecedente)
			throws PuntoLLegadaValidadorException {
		
		if(CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
			if(!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
				throw new PuntoLLegadaValidadorException("30554",
						new String[] { codigoRegimenPrecedente, numeroSerie.toString() }, "REGIMEN PRECEDENTE INVALIDO PARA LA SERIE");
			}
		}
		
		if(CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
			if(!CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
				throw new PuntoLLegadaValidadorException("30546",
						new String[] { codigoRegimenPrecedente, codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "REGIMEN PRECEDENTE DE DEPOSITO: TIPO DE PUNTO DE LLEGADA INVALIDO PARA LA SERIE");
			}
		}
	}
	
	/**
	 * Valida el lugar de descarga
	 * R1778 Por la via de transporte se validada los puntos de llegada autorizados. 
	 */
	private void validarTipoLugarDescarga(Date fechaReferencia, String regimen, String codModTranspo) throws PuntoLLegadaValidadorException {

		LugarDescargaValidador lugarDescargaValidador = tipoLugarDescargaValidadorBuilder(codigoLugarDescarga, codModTranspo, fechaReferencia); //PAS20181U220200004
		lugarDescargaValidador.validar(fechaReferencia, codigoAduanaTransmision);
	}
	
	
	/**
	 * V�lido solo para despachos Anticipados y de via de transporte Aereo (Activar solo para el regimen 10)
	 * el tipo de punto de llegada/almac�n aduanero �Dep�sito Aduanero� no es aplicable al r�gimen 10 - Importaci�n para el consumo
	 * R1777  del RIN22
	 * @param declaracion
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2536)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=9999,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado")	
	public  Map<String, String> validarTipoLugarDescargaImpoConsumo(Declaracion declaracion) {
		Map<String, String> listError = new HashMap<String, String>();
		String codModTransp = declaracion.getDua().getManifiesto().getCodmodtransp();
		String codModalidad = declaracion.getDua().getCodmodalidad();
		String codigoLugarDescarga = declaracion.getDua().getCodtiplugarrecep();
		if (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)){ //PAS20181U220200004
			
			if (CODIGO_LUGAR_DESCARGA_DESCARGA_PUNTO_LLEGADA.equals(codigoLugarDescarga)) {
				String codigoPuntoLLegadaMercancia =declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion().toString():"";
				if (SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37045", new String[] {});
				}
			}			
		}
		return listError;
	}
	
	
	
	/**
	 * builder para lugar de descarga
	 * @param codigoLugarDescarga
	 * @return
	 */
	private LugarDescargaValidador tipoLugarDescargaValidadorBuilder(String codigoLugarDescarga, String codModTransp, Date fechaReferencia) {

		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
	    boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;
	    //PAS20181U220200049
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);
	    //PAS20181U220200064
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		boolean considerarValoresCat227 = false;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			considerarValoresCat227 = true;
		}
	//PAS20181U220200064	
		if (CODIGO_LUGAR_DESCARGA_DESCARGA_PUNTO_LLEGADA.equals(codigoLugarDescarga)) {
			if (SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){
				if (!MapaValManNum.isEmpty()){//PAS20181U220200049
					if(esManifiestoEerSda){ //Si es el EER-SDA y mando manifiesto
						return new PuntoLlegadaDepositoEER(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_EER, true); 
					}
					else {
						if(numManifiesto == null)//si no hay numero de manifiesto
							return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO_EER);	
						else
							if(esManifiestoEerSigad) {//PAS20181U220200064
								 return new PuntoLlegadaDepositoEER(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO_EER, true);
							}else {								
						  //return new PuntoLlegadaDepositoEER(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO, false);	
						  return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO);
					}
						 						
					}
				}
				else {
					return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_AEREO);
				}
			} else if (SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_EER)){//Para el sigad - EER
				return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_EER); 
			}else  if (/*MapaValManNum.isEmpty() */ esVigenteRIN05 && 
					//(SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL) ||  SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO)  ||SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE))){
					( (!considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL,
							 ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE}, codModTranspo)))
						|| 	
					  (considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE,
							ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE}, codModTranspo) )) )){
				return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_MANIFIESTOFLUVIALYTERRESTRE); 
			/*}else  if (!MapaValManNum.isEmpty() && esVigenteRIN05 && (SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE) ||  SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE)  ||SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE))){
				return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO_MANIFIESTOFLUVIALYTERRESTRE); 
			*/} 			
			else{
				
				return new LugarDescargaEnPuntoLlegadaValidador(codigoPuntoLLegadaMercancia, PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_ANTICIPADO);
			}
			

		} else if (!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)) {

			if (CODIGO_LUGAR_DESCARGA_DESCARGA_ZONA_PRIMARIA.equals(codigoLugarDescarga)) {

				return new LugarDescargaEnZonaPrimariaValidador(codigoPuntoLLegadaMercancia, numeroRUCpuntoLlegada,
						numeroRUCduenioConsignatario,
						PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_ZONA_PRIMARIA_DESPACHO_ANTICIPADO);

			} else {
				// lanza un error con el codigo de error
				return new LugarDescargaNoContempladosValidador("30548");
			}
		}
		return new LugarDescargaRegimenDeposito("30559");
	}

	/**
	 * Builder para punto de llegada
	 * @param codigoPuntoLlegada
	 * @return
	 */
	PuntoLlegadaValidador tipoPuntoLlegadaValidadorBuilder(String codigoPuntoLlegada) {

		if (CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans, fabricaDeServicios, manifiestoSigadService,
					circunoceDAO, ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
		} else if (CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaTerminalPortuario(numeroRUCpuntoLlegada, codigoAduanaTransmision);
		} else if (CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoAduanero(numeroRUCpuntoLlegada,  (java.util.Date) fechaReferencia);
		} else if (CODIGO_PUNTO_LLEGADA_TERMNINAL_AEREO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaTerminalAereo(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,fabricaDeServicios, manifiestoSigadService,
					circunoceDAO, ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		} 
//		else if (CODIGO_PUNTO_LLEGADA_TERMINAL_FLUVIAL.equals(codigoPuntoLlegada)) {
//			return new PuntoLlegadaTerminalFluvial(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
//		} 
		else if (CODIGO_PUNTO_LLEGADA_CENTRO_ATENCION_FRONTERIZA.equals(codigoPuntoLlegada)) { //PAS20181U220200004
			return new PuntoLlegadaCentroAtencionFronteriza(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
		} else {	
			throw new RuntimeException(
					"Error de Aplicacion. El tipo de punto de llegada no es valido, para la validacion del punto de llegada");
		}
	}

	/*
	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}

	public AutorizacionZonaPrimariaService getAutorizacionZonaPrimariaService() {
		return autorizacionZonaPrimariaService;
	}

	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}

	public void setAutorizacionZonaPrimariaService(
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService) {
		this.autorizacionZonaPrimariaService = autorizacionZonaPrimariaService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public ConsultaDeclaracionDepositoAduaneroService getConsultaDeclaracionDepositoAduaneroService() {
		return consultaDeclaracionDepositoAduaneroService;
	}

	public ConsultaDeclaracionImpoConsumoService getConsultaDeclaracionImpoConsumoService() {
		return consultaDeclaracionImpoConsumoService;
	}

	public ConsultaDeclaracionImportacionAdmisionReexpService getConsultaDeclaracionImportacionAdmisionReexpService() {
		return consultaDeclaracionImportacionAdmisionReexpService;
	}

	public ConsultaDeclaracionImportacionAdmisionPerfecService getConsultaDeclaracionImportacionAdmisionPerfecService() {
		return consultaDeclaracionImportacionAdmisionPerfecService;
	}

	public void setConsultaDeclaracionDepositoAduaneroService(
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService) {
		this.consultaDeclaracionDepositoAduaneroService = consultaDeclaracionDepositoAduaneroService;
	}

	public void setConsultaDeclaracionImpoConsumoService(
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService) {
		this.consultaDeclaracionImpoConsumoService = consultaDeclaracionImpoConsumoService;
	}

	public void setConsultaDeclaracionImportacionAdmisionReexpService(
			ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService) {
		this.consultaDeclaracionImportacionAdmisionReexpService = consultaDeclaracionImportacionAdmisionReexpService;
	}

	public void setConsultaDeclaracionImportacionAdmisionPerfecService(
			ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService) {
		this.consultaDeclaracionImportacionAdmisionPerfecService = consultaDeclaracionImportacionAdmisionPerfecService;
	}

	public GetDeclaracionService getGetDeclaracionService() {
		return getDeclaracionService;
	}

	public void setGetDeclaracionService(GetDeclaracionService getDeclaracionService) {
		this.getDeclaracionService = getDeclaracionService;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public String getCodModTranspo() {
		return codModTranspo;
	}

	public void setCodModTranspo(String codModTranspo) {
		this.codModTranspo = codModTranspo;
	}*/
}