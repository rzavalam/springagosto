package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

//Descripcion de cada metodo en la interfaz - ValRegPrecZofratacnaService

public class ValRegPrecZofratacnaServiceImpl extends ValDuaAbstract implements ValRegPrecZofratacnaService {

	@Override
	public List<Map<String, String>> validarCantDocuPrecePorSerie(List<DatoSerie> listSeries, DUA dua) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Declaracion declaracion = (Declaracion) dua.getPadre();
		for(DatoSerie serie:listSeries) {
			if (serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0){
		for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) {
			String mregi_proce = precedente.getCodregipre();
			if(SunatStringUtils.include(mregi_proce, new String[]{Constants.REGIMEN_ZOFRATACNA_CZ, Constants.REGIMEN_ZOFRATACNA_DZ}))
				if(!dua.getCodlugarecepcion().equals("16")){
					listError.add(getDUAError("50220", //00124
							new Object[] { dua.getCodlugarecepcion()}));
				}
			if(!dua.getCodaduanaorden().equals(precedente.getCodaduapre())){
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				String strPrecedencia = precedente.getCodaduapre()+'-'+SunatStringUtils.substring(precedente.getAnndeclpre(),0,4)+'-'+precedente.getCodregipre()+'-'+SunatStringUtils.lpad(precedente.getNumdeclpre(),6,'0');				
				String desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, precedente.getCodregipre());	
			listError.add(getDUAError("37209",new Object[] {serie.getNumserie(),precedente.getCodaduapre(), desRegimenEspecial,strPrecedencia,dua.getCodaduanaorden()})); // csantillan bug P_SNAA0004-16604
				}
			//validacion de codigo de almacen zofratacna
			//if(!precedente.getCodregipre().equals(Constants.REGIMEN_ZOFRATACNA_DZ)&&(!precedente.getCodAlmZofra().trim().isEmpty())){
			if(!Constants.REGIMEN_ZOFRATACNA_DZ.equals(precedente.getCodregipre()) && (precedente.getCodAlmZofra() != null && !precedente.getCodAlmZofra().trim().isEmpty())){	
				listError.add(getDUAError("50221", new Object[] { serie.getNumserie().toString(),precedente.getCodregipre()}));//00124
				}			
			else if(!declaracion.getCodtipotrans().equals("1007") &&Constants.REGIMEN_ZOFRATACNA_DZ.equals(precedente.getCodregipre()) && (precedente.getCodAlmZofra() == null || precedente.getCodAlmZofra().trim().isEmpty())){
				listError.add(getDUAError("50222", new Object[] { serie.getNumserie().toString()})); //00124
				}
			}
		
			if (!listError.isEmpty()){
				break;
			}
		  }
		}
		
		return listError;
	}
/*
	@Override
	public List<Map<String, String>> validarTPN332() {
		// TODO Auto-generated method stub
		return null;
	}
*/
	@Override
	public List<Map<String, String>> validarEnPuntodeLLegada() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> validarPuntoLlegada() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> validarManifiesto() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> validarRegimenZofratacna(DatoSerie serie, DatoRegPrecedencia precedente) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		listError.addAll(validarCantDocuPrecePorSerie((List<DatoSerie>) serie, null));
		return listError;
	}

	
}
