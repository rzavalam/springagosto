package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;


public class ComparatorFactoy extends ValDuaAbstract{

//private FabricaDeServicios fabricaDeServicios;
	
	public DocumentComparator getComparador(String transaccion) {
//		ThreadLocal<ComparadorDeclaracion> c = null;
		if (transaccion.startsWith("21")) {
			 return new ComparadorDeclaracionAdmisionTemporal(fabricaDeServicios);
//			c = (ComparadorDeclaracionAdmisionTemporal) fabricaDeServicios
//					.getService("ingresos.comparadorDeclaracionAdmisionTemporal");

		} else if (transaccion.startsWith("70")) {
			 return new ComparadorDeclaracionDeposito(fabricaDeServicios);
//			c = (ComparadorDeclaracionDeposito) fabricaDeServicios
//					.getService("ingresos.comparadorDeclaracionDeposito");

		} else if (transaccion.startsWith("20")) {
			 return new ComparadorDeclaracionAdmTemporReexp(fabricaDeServicios);
//			c = (ComparadorDeclaracionAdmTemporReexp) fabricaDeServicios
//					.getService("ingresos.comparadorDeclaracionAdmTemporReexp");
		} else {
			 return new ComparadorDeclaracion(fabricaDeServicios);
//			c = (ComparadorDeclaracion) fabricaDeServicios
//					.getService("ingresos.comparadorDeclaracion");
		}
//		c.clean();
//		return c;

	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
