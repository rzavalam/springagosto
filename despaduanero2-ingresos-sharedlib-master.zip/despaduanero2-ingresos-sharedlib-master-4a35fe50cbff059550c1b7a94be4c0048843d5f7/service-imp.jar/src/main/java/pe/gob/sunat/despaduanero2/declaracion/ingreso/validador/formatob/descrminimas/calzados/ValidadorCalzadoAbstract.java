package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */

public class ValidadorCalzadoAbstract extends ValidadorAbstract
{
	private final static String PARES         = "2U";
	private final static String DOCENAS       = "12U";
	private final static String NUMERIC_PATTERN = "\\d+";
	protected final static String CUERO_NATURAL   = "CUN";
	private final static String ACOPLADO      = "ACO";
	private final static String CHALAS        = "CHA";
	private final static String SANDALIAS     = "SAN";
	private final static String BOTA_ALTA     = "BAS";
	private final static String BOTA_IMPERMEABLE = "BIM";
	private final static String PARTIDA_6401  = "6401";
	private final static String PARTIDA_6402  = "6402";
	private final static String PARTIDA_6403  = "6403";
	private final static String PARTIDA_6404  = "6404";
	private final static String TEXTIL        = "TEX";
	private final static String CUERO_REGENERADO = "CUR";
	private final static String CALZADO_DEPORTE = "CDP";
	private final static String CUERO         = "CUE";
	//private final static String CAUCHO        = "CAU";///se gestiona por grupo 615
	//private final static String CUERO_SINTETICO = "CUS";//se gestiona por grupo 615
	//private final static String PLASTICO      = "PLA";//se gestiona por grupo 615
	//  private final static String TALLA_FORMATO = "\\d{5}-\\d{5}";


	private final static String GRUPO_MATERIAL_PARTSUP = "615";
	private final static String GRUPO_MATERIAL_SUELA_PLA = "616";
	private final static String GRUPO_MATERIAL_SUELA_TEX = "617";

	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
	{
		// TODO Auto-generated method stub
		return null;
	}

	public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract object, DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		String datoAValidar        = item.getCodunidcomer().toString();
		Object[] demasArgumentosMSJError = new Object[] { 
				object.getNumsecprove(),
				object.getNumsecfact(),
				object.getNumsecitem(),
				"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
		if(!(SunatStringUtils.isEqualTo(datoAValidar, PARES) ||
				SunatStringUtils.isEqualTo(datoAValidar, DOCENAS))){
			ErrorDescrMinima err = obtenerError("31380",
					ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
			lst.add(err); 
		}
		return lst;
	}

	private List<ErrorDescrMinima> validarMaterialYSuelas(CalzadoAbstract calzado, String partida, Date fechaVigencia)
	{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		String material = calzado.getMaterialParteSuperior().getValtipdescri();
		String suela = calzado.getComposicionDeLaSuela().getValtipdescri();
		/*List<String> materialSuperior = new ArrayList<String>();
    materialSuperior.add(CAUCHO);
    materialSuperior.add(CUERO_SINTETICO);
    materialSuperior.add(PLASTICO);*/ //se cambia por el grupo 615

		/* List<String> materialSuela = new ArrayList<String>();
    materialSuela.add(CAUCHO);
    materialSuela.add("EVA");
    materialSuela.add("POL");// es POL!! AREY
    materialSuela.add("PVC");
	//materialSuela.add("PUR");//adicionado AREY*/ //se cambia por el grupo 616

		/**Inicio de cambios PAS20155E220000384**/
		String nombreComercial = calzado.getNombreComercial().getValtipdescri();
		List<String> listExclusion = new ArrayList<String>();
		listExclusion.add(BOTA_ALTA);
		listExclusion.add(BOTA_IMPERMEABLE);

		//SI el calzado no es BAS - Bota de alta seg. industrial o BIM - Bota impermeable validar con la partida 6402
		if(!listExclusion.contains(nombreComercial)){    	
			//if(materialSuperior.contains(material) && materialSuela.contains(suela) &&
			if(catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_PARTSUP, material, fechaVigencia)!=null &&
					catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_PLA, suela, fechaVigencia)!=null &&
					!SunatStringUtils.isEqualTo(PARTIDA_6402,partida)){
				lst.add(obtenerError("31419",calzado.getMaterialParteSuperior()));
			}

			/*Si el material de la parte superior no es 'CAU' | 'CUS' | 'PLA'  y
			 *  no ha transmitido para la composici�n de la suela ninguno de los siguientes 'CAU' | 'EVA' | 'PUR' | 'PVC' 
			 *   la partida declarada no corresponda a la 6402.*/
			if(SunatStringUtils.isEqualTo(PARTIDA_6402,partida) &&
					//	(!materialSuperior.contains(material) || !materialSuela.contains(suela))){//debe ser Y PAS20165E220200137
					(catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_PARTSUP, material, fechaVigencia)==null && 
					catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_PLA, suela, fechaVigencia)==null)){
				lst.add(obtenerError("31420", calzado.getMaterialParteSuperior()));
			}
			//materialSuela.add("CUE");//se gestiona en grupo 617

			//   SI material IN (CUN) Y compSuela IN(CAU,EVA,PUR,PVC,CUE) Y partida <>6403
			if(SunatStringUtils.isEqualTo(CUERO_NATURAL,material) && //materialSuela.contains(suela) 
					catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_TEX, suela, fechaVigencia)!=null 
					&& !SunatStringUtils.isEqualTo(PARTIDA_6403,partida)){
				lst.add(obtenerError("31421",calzado.getMaterialParteSuperior()));
			}

			//   SI material NOT IN (CUN) Y compSuela NOT IN(CAU,EVA,PUR,PVC,CUE) Y partida == 6403
			//correccion amancilla se puso el parentsesis
			if(SunatStringUtils.isEqualTo(PARTIDA_6403,partida)
					&& (!SunatStringUtils.isEqualTo(CUERO_NATURAL,material) && //||!materialSuela.contains(suela))){// debe ser Y PAS20165E220200137
							catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_TEX, suela, fechaVigencia)==null )){
				lst.add(obtenerError("31422", calzado.getMaterialParteSuperior()));
			}

			if(SunatStringUtils.isEqualTo(TEXTIL,material) && //materialSuela.contains(suela) &&
					catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_TEX, suela, fechaVigencia)!=null && 
					!SunatStringUtils.isEqualTo(PARTIDA_6404,partida)){
				lst.add(obtenerError("31423", calzado.getMaterialParteSuperior()));
			}

			if(SunatStringUtils.isEqualTo(PARTIDA_6404,partida) &&
					(!SunatStringUtils.isEqualTo(TEXTIL,material) && //||!materialSuela.contains(suela))){//debe ser Y
							catalogoAyudaService.getDataGrupoCat(GRUPO_MATERIAL_SUELA_TEX, suela, fechaVigencia)==null )){
				lst.add(obtenerError("31424", calzado.getMaterialParteSuperior()));
			}
		}/**Fin de cambios PAS20155E220000384**/
		return lst;
	}

	private List<ErrorDescrMinima> validarDenominacionPorPartida(CalzadoAbstract calzado, 
			String subpartida){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		List<String> partidasDeporte = new ArrayList<String>();
		List<String> partidasCuero = new ArrayList<String>();
		String nombreComercial       = calzado.getNombreComercial().getValtipdescri();
		String materialSuperior = calzado.getMaterialParteSuperior().getValtipdescri();
		String suela = calzado.getComposicionDeLaSuela().getValtipdescri();
		partidasDeporte.add("6402120000");
		partidasDeporte.add("6402190000");
		partidasDeporte.add("6403120000");
		partidasDeporte.add("6403190000");
		partidasDeporte.add("6404111000");

		partidasCuero.add("6403200000");
		partidasCuero.add("6403510000");
		partidasCuero.add("6403590000");
		partidasCuero.add("6404200000");
		partidasCuero.add("6405900000");

		if(SunatStringUtils.isEqualTo(CALZADO_DEPORTE,nombreComercial) &&
				!partidasDeporte.contains(subpartida)){
			lst.add(obtenerError("31426", calzado.getNombreComercial(), new String[]{subpartida}));
		}else if(!SunatStringUtils.isEqualTo(CALZADO_DEPORTE,nombreComercial) &&
				partidasDeporte.contains(subpartida)){
			lst.add(obtenerError("31427",calzado.getNombreComercial(), new String[]{subpartida}));
		}
		if(SunatStringUtils.isEqualTo(CUERO,suela) && !partidasCuero.contains(subpartida)){
			lst.add(obtenerError("31428", calzado.getComposicionDeLaSuela(), new String[]{subpartida}));
		}else if(!SunatStringUtils.isEqualTo(CUERO,suela) && partidasCuero.contains(subpartida)){
			lst.add(obtenerError("31429", calzado.getComposicionDeLaSuela(), new String[]{subpartida}));
		}    
		if(SunatStringUtils.isEqualTo(CUERO_REGENERADO,materialSuperior) &&
				!SunatStringUtils.isEqualTo("6405", subpartida.substring(0,4)) ){
			lst.add(obtenerError("31425",calzado.getMaterialParteSuperior()));
		}
		if(!(SunatStringUtils.isEqualTo(CUERO_NATURAL,materialSuperior) || 
				SunatStringUtils.isEqualTo(CUERO_REGENERADO,materialSuperior)) && 
				SunatStringUtils.isEqualTo("6405100000", subpartida)){
			lst.add(obtenerError("31430",calzado.getMaterialParteSuperior()));
		}
		if(!SunatStringUtils.isEqualTo(TEXTIL,materialSuperior) && 
				SunatStringUtils.isEqualTo("6405200000", subpartida)){
			lst.add(obtenerError("31431", calzado.getMaterialParteSuperior()));
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarMaterialParteSuperior(ModelAbstract object, DatoItem item){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object,DatoItem item, Date fechaVigencia){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		CalzadoAbstract calzado = (CalzadoAbstract) object;
		String subpartida = item.getNumpartnandi().toString();
		String partida  = subpartida.substring(0, 4);
		String nombreComercial  = object.getNombreComercial().getValtipdescri();
		if( (SunatStringUtils.isEqualTo(BOTA_ALTA,nombreComercial) || 
				SunatStringUtils.isEqualTo(BOTA_IMPERMEABLE,nombreComercial) ) &&
				!SunatStringUtils.isEqualTo(PARTIDA_6401,partida)){//parentesis por SAU201510002000199 arey
			lst.add(obtenerError("31435", calzado.getNombreComercial(), new String[]{subpartida}));
		}
		else{
			lst.addAll(validarMaterialYSuelas(calzado,partida,fechaVigencia));
			lst.addAll(validarDenominacionPorPartida(calzado,subpartida));
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
		//arey observacion del piloto coordinaco con wilmer ramirez
		//List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		//CalzadoAbstract calzado    = (CalzadoAbstract) object;
		//String datoAValidar        = calzado.getModelo().getValtipdescri();
		//if(cumpleExpresionRegular(datoAValidar, NUMERIC_PATTERN) || 
		// datoAValidar.length()<=2 ){
		//lst.add(obtenerError("31382", calzado.getModelo()));
		//}
		//return lst;

		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarTallaCalzado(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarConstruccion(ModelAbstract object){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		CalzadoAbstract calzado = (CalzadoAbstract) object;
		String construccion = calzado.getConstruccionCalzado().getValtipdescri();
		String nombre = calzado.getNombreComercial().getValtipdescri();
		if(SunatStringUtils.isEqualTo(ACOPLADO,construccion)){
			if(!(SunatStringUtils.isEqualTo(CHALAS,nombre) || 
					SunatStringUtils.isEqualTo(SANDALIAS,nombre))){
				lst.add(obtenerError("31418",calzado.getConstruccionCalzado()));
			}
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarUsarioCalzado(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarComposicionDeLaSuela(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarComposicionForro(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

}
