/*
 * Clase que define el servicio de validaciones de Exigibilidad
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;
// RIN16
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
// RIN16
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//nuevo
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
// RIN16
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
// RIN16
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
// RIN16
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;//Agregado RIN16
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
// RIN16
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.ctrlpago.model.dao.Ebd1cduiDAO;
import pe.gob.sunat.recauda2.ctrlpago.model.dao.Ebd1gduiDAO;
import pe.gob.sunat.recauda2.ctrlpago.model.dao.Ebd1prov1DAO;
import pe.gob.sunat.recauda2.ctrlpago.model.dao.Ebd1provDAO;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
// RIN16
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService; //Agregado RIN16

/**
 * The Class ExigibilidadServiceImpl.
 * 
 * <pre>
 * Actualiza la fecha de �ltimo d�a de pago de las DUAs, la cual se calcula en base a la fecha de t�rmino de descarga del manifiesto asociado a
 * las mismas.
 * </pre>
 */
public class ExigibilidadServiceImpl extends IngresoAbstractServiceImpl implements ExigibilidadService {
	// RIN16
	/*yzr*/
	private static final Integer CODIGO_PLANTILLA_VENCIMIENTO_REGULARIZACION = 216;	
	private static final String CODIGO_TIPO_NOTIFICACION_SE_PUEDE_BORRAR = "2";
	//	private static final Integer PLAZO_VENCIMIENTO_REGULARIZACION = 15;

	/*yzr*/

	//private CabDeclaraDAO cabDeclaraDAO;

	//private DeudaDocumDAO deudaDocumDAO;

	//private PagarantiaDAO pagarantiaDAO;

	//private Ebd1provDAO ebd1ProvDAO;

	//private Ebd1prov1DAO ebd1Prov1DAO;

	//private Ebd1cduiDAO ebd1CduiDAO;

	//private Ebd1gduiDAO ebd1GduiDAO;

	//private LiquidaDAO liquidaDAO;

	//private ParticipanteDocDAO participanteDocDAO;

	//private FabricaDeServicios fabricaDeServicios;

	//private HotSwappableTargetSource swapperDatasource;

	// RIN16	
	//	private CatalogoAyudaService catalogoAyudaService;//yzr

	//private PublicacionAvisoService publicacionAvisoService;//agregado Rin 16

	protected boolean enableSwapperDataSource = true;

	/*
	 * (non-Javadoc)
	 * 
	 * @seepe.gob.sunat.despaduanero2.service.ExigibilidadService#actualizarUltimoDiaPagoDUA(pe.gob.sunat.despaduanero2.declaracion.model.
	 * Declaracion)
	 */
	@Override
	public void actualizarUltimoDiaPagoDUA(DUA dua) {
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("exigibilidad.cabDeclaraDAO");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd"); 
		if( !sdf.format(dua.getManifiesto().getFectermino()).equals("00010101") ){


			if(dua.getCodmodalidad().equals("10")	 ) { 
				actualizaDiaPago(dua, dua.getManifiesto().getFectermino());
			}
			//pase105 lmv
			if( dua.getCodmodalidad().equals("01")){

				Map<String,Object> params = new HashMap<String,Object>();
				params.put("NUM_CORREDOC", dua.getNumcorredoc());
				List<DUA> listDUAs = cabDeclaraDAO.findDuasPorManifiesto(params);

				Date getFecdeclaracion= listDUAs.get(0).getFecdeclaracion();
				actualizaDiaPago(dua, getFecdeclaracion);
			}


		}

		//pase105 lmv fin

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * pe.gob.sunat.despaduanero2.service.ExigibilidadService#actualizarUltimoDiaPagoDUA(pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto
	 * , java.util.Date)
	 */
	@Override
	public void actualizarUltimoDiaPagoDUA(Manifiesto manifiesto, Date fechaDescarga) {
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("exigibilidad.cabDeclaraDAO");
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("COD_ADUAMANIFIESTO", manifiesto.getAduana().getCodDatacat() );
		params.put("COD_VIATRANS", manifiesto.getViaTransporte().getCodDatacat());
		params.put("COD_TIPMANIFIESTO", manifiesto.getTipoManifiesto().getCodDatacat());
		params.put("ANN_MANIFIESTO", manifiesto.getAnioManifiesto());
		params.put("NUM_MANIFIESTO", manifiesto.getNumeroManifiesto().trim());
		/*ealvino*/
		// el codigo de regimen estaba en duro en el query  findDuasPorManifiesto
		params.put("COD_REGIMEN",new String[]{"10"});
		/*ealvino*/
		List<DUA> listDUAs = cabDeclaraDAO.findDuasPorManifiesto(params);
		for (DUA dua : listDUAs) {
			actualizaDiaPago(dua, fechaDescarga);	
		}

	}

	/**
	 * Actualiza dia pago.
	 * 
	 * @param dua DUA
	 * @param fechaTerminoDescarga Date
	 */
	@SuppressWarnings("unchecked")
	private void actualizaDiaPago(DUA dua, Date fechaTerminoDescarga) {
		DeudaDocumDAO deudaDocumDAO = (DeudaDocumDAO) fabricaDeServicios.getService("exigibilidad.deudaDocumDAO");
		Date fechaUltimoDiaDePago = null;
		boolean indicadorGarantia = false;
		DeudaDocum deudatmp = new DeudaDocum();
		deudatmp.setNumCorredoc( dua.getNumcorredoc() );

		List<DeudaDocum> listaDeuda = obtenerDeudaDUA(dua);

		for (DeudaDocum deudaDocum : listaDeuda) {

			//and substr(num_cda,14,2) != '25'
			String cda = SunatStringUtils.substringFox(deudaDocum.getNumCda(), 14, 2);
			if(!"25".equals(cda) && !"97".equals(cda))  
			{

				if( fechaUltimoDiaDePago == null ) {
					indicadorGarantia =  (deudaDocum.getMtoGarant().intValue() > 0 );    
					fechaUltimoDiaDePago = calculaFechaUltimoDiaDePago(indicadorGarantia, fechaTerminoDescarga);
				}

				deudatmp.setFecVenc(fechaUltimoDiaDePago);
				deudatmp.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());
				deudaDocumDAO.updateByPrimaryKeySelective(deudatmp);
				registroEnBancos(deudaDocum, fechaUltimoDiaDePago);
				//Actualiza fecha de ultimo d�a de pago en tabla LIQUIDA, s�lo para registros de L/C
				if( deudaDocum.getCodTipdeuda().equals("02") ) { 
					registroEnLiquida(deudaDocum, fechaUltimoDiaDePago);
				}
				if(indicadorGarantia){
					registroFechaTermino(dua, fechaUltimoDiaDePago);					
				}				
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seepe.gob.sunat.despaduanero2.service.ExigibilidadService#actualizarUltimoDiaPagoDUA(pe.gob.sunat.despaduanero2.declaracion.model.
	 * Declaracion)
	 */
	/*METODO NUEVO RIN16*/
	public void actualizarFecRegularizacionDUA(DUA dua)  {
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("exigibilidad.cabDeclaraDAO");
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		HashMap<String, Object> params = new HashMap<String, Object>();
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		// FechaBean fechaIniProc = new FechaBean();
		// FechaBean fechaFinProc = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		boolean actualizaFecha = false;


		if (dua.getManifiesto().getFectermino() != null 
				&& !SunatDateUtils.getFormatDate(dua.getManifiesto().getFectermino(), "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD)
				&& !SunatDateUtils.sonIguales(dua.getFecTerm(), dua
						.getManifiesto().getFectermino(),
						SunatDateUtils.COMPARA_SOLO_FECHA)) {
			params.clear();
			params.put("NUM_CORREDOC", dua.getNumcorredoc());
			params.put("FEC_TERM", dua.getManifiesto().getFectermino());
			cabDeclaraDAO.update(params);
			actualizaFecha = true;
		}

		if (actualizaFecha){


			// ValNegocNumeracFormAServiceImpl valNegocNumeracFormA =
			// (ValNegocNumeracFormAServiceImpl)
			IndicadorDuaService indicadorDuaService = (IndicadorDuaService) fabricaDeServicios
					.getService("validacion.ingreso.IndicadorDuaService");
			Declaracion declaracion = new Declaracion();
			declaracion.setDua(dua);
			// Boolean esRegularizable =
			// valNegocNumeracFormA.estadoRegularizable(declaracion);//falta
			// preguntar de donde sale la entidad declaracion
			boolean esRegularizable = indicadorDuaService.esDuaRegularizable(dua
					.getNumcorredoc());

			Map<String, Object> paramDias = new HashMap<String, Object>();
			Date fecDeclaracionNueva=SunatDateUtils.addDay(dua.getManifiesto().getFectermino(), 
					Constantes.PLAZO_VENCIMIENTO_REGULARIZACION);//
			Integer fecDeclaracionAsInteger=SunatDateUtils.getIntegerFromDate(fecDeclaracionNueva);
			paramDias.put("FECHADESDE", fecDeclaracionAsInteger);
			paramDias.put("FECHAHASTA", 0);
			paramDias.put("TIPO", 2);
			paramDias.put("INCLUYE", "S");
			paramDias.put("SUSPENDE", "S");

			DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
			DataSourceContextHolder.setKeyDataSource(dua.getCodaduanaorden());
			String fecVencRegula = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias); // yyyyMMdd

			if (dua.getCodmodalidad().equals(ConstantesDataCatalogo.MODA_URGENTE)
					|| (dua.getCodmodalidad().equals(ConstantesDataCatalogo.MODA_ANTICIPADA) && esRegularizable)) {
				params.clear();
				params.put("NUM_CORREDOC", dua.getNumcorredoc());
				params.put("FEC_VENCREGULA", SunatDateUtils.getDate(fecVencRegula, "yyyyMMdd"));
				cabDeclaraDAO.update(params);

				//Los datos no tienen alguna de las llaves fijas cod_usuario, des_asunto o tip_usuario

				// logica para envio de mensajes
				Map<String, Object> mapMensaje = new HashMap<String, Object>();
				//cod_usuario, des_asunto o tip_usuario
				mapMensaje.put("tip_usuario", "1");
				StringBuffer descAsuntoMensaje = new StringBuffer(
						"Fecha de Vencimiento de la Regularizaci&oacute;n: N&deg; ");
				String elaboradorPor = dua.getCodaduanaorden().equals(
						ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO) ? "Divisi&oacute;n de Importaci�n de la IAMC"
								: "Departamento de T&eacute;cnica Aduanera";
				String descModalidad = dua.getCodmodalidad().equals(
						ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) ? "Anticipado"
								: "Urgente";

				//"";,
				Participante agencia = findRucParticipante(dua.getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);
				Participante beneficiario = findRucParticipante(dua.getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
				//			String rucAgencia = findRucParticipante(dua.getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);
				//			String rucBeneficiario = findRucParticipante(dua.getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);

				descAsuntoMensaje.append(dua.getAnnpresen());
				descAsuntoMensaje.append("-");
				descAsuntoMensaje.append(dua.getCodaduanaorden());
				descAsuntoMensaje.append("-");
				descAsuntoMensaje.append(dua.getCodregimen());
				descAsuntoMensaje.append("-");
				descAsuntoMensaje.append(dua.getNumdocumento());
				mapMensaje.put("des_asunto", descAsuntoMensaje.toString());
				//			mapMensaje.put("cod_usuario", new String[] { rucAgencia, rucBeneficiario});
				mapMensaje.put("cod_usuario", new String[] {agencia.getNumeroDocumentoIdentidad()});
				mapMensaje.put("ruc", agencia.getNumeroDocumentoIdentidad());
				mapMensaje.put("razonsocial", agencia.getNombreRazonSocial());
				mapMensaje.put("cod_aduana", dua.getCodaduanaorden());
				mapMensaje.put("ann_presen", String.valueOf(dua.getAnnpresen()));
				mapMensaje.put("cod_regimen", dua.getCodregimen());
				mapMensaje.put("num_declaracion", dua.getNumdocumento());
				mapMensaje.put("modalidad", descModalidad);
				mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
				mapMensaje.put("fechaVencimiento", SunatDateUtils.getFormatDate(SunatDateUtils.getDate(fecVencRegula, "yyyyMMdd"), "dd/MM/yyyy"));
				mapMensaje.put("elaboradopor", elaboradorPor);

				StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
				publicacionAvisoService.insert(
						CODIGO_PLANTILLA_VENCIMIENTO_REGULARIZACION, data,
						CODIGO_TIPO_NOTIFICACION_SE_PUEDE_BORRAR, fechaActual.getTimestamp(),
						fechaVigencia.getTimestamp());

				mapMensaje.put("cod_usuario", new String[] {beneficiario.getNumeroDocumentoIdentidad()});
				mapMensaje.put("ruc", beneficiario.getNumeroDocumentoIdentidad());
				mapMensaje.put("razonsocial", beneficiario.getNombreRazonSocial());

				data = new StringBuffer(SojoUtil.toJson(mapMensaje));
				publicacionAvisoService.insert(
						CODIGO_PLANTILLA_VENCIMIENTO_REGULARIZACION, data,
						CODIGO_TIPO_NOTIFICACION_SE_PUEDE_BORRAR, fechaActual.getTimestamp(),
						fechaVigencia.getTimestamp());
			}
		}
	}

	/*
	 * NUEVO METODO RIN16 
	 * 
	 * */
	@Override
	public void actualizarFecRegularizacion(Manifiesto manifiesto, Date fechaDescarga)  { 
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("exigibilidad.cabDeclaraDAO");
		//Para cada una de las DUAs anticipadas y urgentes ( cod_modalidad 10, 01) y reg�menes 10, 20, 21 y 70,  
		//asociadas al Manifiesto que est� transmitiendo la Fecha de Termino de Descarga

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("COD_ADUAMANIFIESTO", manifiesto.getAduana().getCodDatacat() );
		params.put("COD_VIATRANS", manifiesto.getViaTransporte().getCodDatacat());
		params.put("COD_TIPMANIFIESTO", manifiesto.getTipoManifiesto().getCodDatacat());
		params.put("ANN_MANIFIESTO", manifiesto.getAnioManifiesto());
		params.put("NUM_MANIFIESTO", manifiesto.getNumeroManifiesto().trim());
		params.put("COD_REGIMEN",new String[]{"10","20", "21", "70"});

		List<DUA> listDUAs = cabDeclaraDAO.findDuasPorManifiesto(params);
		for (DUA dua : listDUAs) { 

			if(dua.getCodmodalidad().equals(Constantes.MODALIDAD_URGENTE) || dua.getCodmodalidad().equals(Constantes.MODALIDAD_ANTICIPADO)){ // POR RESTRICCION EN EL F2 SE ACTUALIZA SOLO PARA LAS URGENTES Y ANTICIPADAS				
				//				dua.setFecTerm();
				if(!SunatDateUtils.sonIguales(fechaDescarga, dua.getManifiesto().getFectermino(), SunatDateUtils.COMPARA_SOLO_FECHA)){
					dua.getManifiesto().setFectermino(fechaDescarga);
					//				if (manifiesto.getFechaTerminoDeDescarga() != dua.getManifiesto().getFectermino()){
					try {
						actualizarFecRegularizacionDUA(dua);
					} catch (Exception e) {
						// TODO Auto-generated catch block						
					}//solo envia un parametro, en el f2 se indica que son dos
					//				} 
				}
			}
		}

	}	


	/**
	 * Calcula fecha ultimo dia de pago.
	 * 
	 * <pre>
	 * 6. Se calcula le fecha de ultimo d�a de pago que corresponda a la DUA, de acuerdo a las siguientes consideraciones:
	 * 6.1. Si la Dua NO esta garantizada, la fecha de �ltimo d�a de pago es igual a la fecha de t�rmino de descarga. 
	 * 6.2. Si la Dua esta garantizada, la fecha de �ltimo d�a de pago es igual al d�a 20 del mes siguiente de la fecha de t�rmino de descarga.
	 * </pre>
	 * 
	 * @param indicadorGarantia boolean
	 * @param fechaTerminoDescarga Date
	 * @return el date
	 */
	private Date calculaFechaUltimoDiaDePago(boolean indicadorGarantia, Date fechaTerminoDescarga) {

		Date fechaVencimiento = fechaTerminoDescarga;
		if(indicadorGarantia)
		{
			fechaVencimiento=SunatDateUtils.addMonth(fechaVencimiento, 1);
			fechaVencimiento=SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(SunatStringUtils.substring(SunatDateUtils.getIntegerFromDate(fechaVencimiento).toString(), 0, 6).concat("20")));			
		}

		return fechaVencimiento;
	}

	private List<DeudaDocum> obtenerDeudaDUA(DUA dua){
		DeudaDocumDAO deudaDocumDAO = (DeudaDocumDAO) fabricaDeServicios.getService("exigibilidad.deudaDocumDAO");
		DeudaDocum key = new DeudaDocum();
		key.setNumCorredoc( dua.getNumcorredoc() );

		key.setCodTipdeuda("01");
		List<DeudaDocum> listaDeuda = deudaDocumDAO.selectByDocumento(key);

		key.setCodTipdeuda("02");
		List<DeudaDocum> listaDeuda2 = deudaDocumDAO.selectByDocumento(key);

		//cod_tipdeuda in ('01','02')
		listaDeuda.addAll(listaDeuda2);

		return listaDeuda;
	} 

	/**
	 * Establece un valor a cabDeclaraDAO.
	 * 
	 * @param cabDeclaraDAO CabDeclaraDAO
	 */
	/*
	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}


	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}
	 */	

	private void registroFechaTermino(DUA dua, Date fechaLlegada) {
		PagarantiaDAO pagarantiaDAO = (PagarantiaDAO) fabricaDeServicios.getService("exigibilidad.pagarantiaDAO");
		Map<String, Object> mapParam = new HashMap<String, Object>();
		mapParam.put("cADUAFECTA", dua.getCodaduanaorden());
		mapParam.put("cANNAFECTA", dua.getAnnpresen().toString());
		mapParam.put("cNUMAFECTA", SunatStringUtils.lpad(dua.getNumdocumento(), 6, '0'));
		mapParam.put("cREGIAFECTA", dua.getCodregimen());
		mapParam.put("cFECHAFECTA", SunatDateUtils.getIntegerFromDate(fechaLlegada));
		mapParam.put("cTRANS", "1");
		pagarantiaDAO.registroFechaTermino(mapParam);
	}
	// RIN16
	public Participante findRucParticipante(Long numCorreDoc, String codTipoParticipante){//RIN16_Pase400
		ParticipanteDocDAO participanteDocDAO =  (ParticipanteDocDAO) fabricaDeServicios.getService("exigibilidad.participanteDocDAO");
		Map<String, Object> mapPart = new HashMap<String, Object>();
		//		String rucParticipante = "";
		mapPart.put("numeroCorrelativo", numCorreDoc);
		mapPart.put("codTipoParticipante", codTipoParticipante);

		List<Participante> lista = participanteDocDAO.listByParameterMap(mapPart);

		if(!CollectionUtils.isEmpty(lista)){
			//			rucParticipante = lista.get(0).getNumeroDocumentoIdentidad();
			return lista.get(0);
		}
		return null;
		//		return rucParticipante;
	}// RIN16
	/*RIN13FSW-INICIO*/
	private String findRucAgente(DUA dua){
		ParticipanteDocDAO participanteDocDAO =  (ParticipanteDocDAO) fabricaDeServicios.getService("exigibilidad.participanteDocDAO");
		Map<String, Object> mapPart = new HashMap<String, Object>();
		mapPart.put("numeroCorrelativo", dua.getNumcorredoc());
		mapPart.put("codTipoParticipante", "41");

		List<Participante> lista = participanteDocDAO.listByParameterMap(mapPart);

		if(CollectionUtils.isEmpty(lista))
			return " ";

		else return lista.get(0).getNumeroDocumentoIdentidad();
	}
	/*RIN13FSW-FIN*/

	private void registroEnBancos(DeudaDocum deuda, Date ultimoDiaPago ) {
		Ebd1prov1DAO ebd1Prov1DAO = (Ebd1prov1DAO) fabricaDeServicios.getService("exigibilidad.ebd1prov1DAO");
		Ebd1provDAO ebd1ProvDAO = (Ebd1provDAO) fabricaDeServicios.getService("exigibilidad.ebd1provDAO");
		Ebd1cduiDAO ebd1CduiDAO = (Ebd1cduiDAO) fabricaDeServicios.getService("exigibilidad.ebd1cduiDAO");
		Ebd1gduiDAO ebd1GduiDAO = (Ebd1gduiDAO) fabricaDeServicios.getService("exigibilidad.ebd1GduiDAO");
		Map<String,String> params = new HashMap<String,String>();
		params.put("NUMCDA", deuda.getNumCda());

		Map<String,Object> resultado = null; 

		boolean esAduanaLima = ("*118*235*244*000*".indexOf(deuda.getNumCda().substring(0,3)) > 0 );

		Map<String,Object> paramGDUI = new HashMap<String,Object>();
		paramGDUI.put("ffeultpg", ultimoDiaPago);
		paramGDUI.put("fnupoliz", deuda.getNumCda().substring(0,16));
		paramGDUI.put("fnusufij", deuda.getNumCda().substring(16));

		//Para el caso de DUAs
		if("01".equals(deuda.getCodTipdeuda())){  

			if(esAduanaLima)  { 
				resultado = ebd1GduiDAO.findPK(params);
				if( resultado!=null && resultado.get("FCO_CONDP").equals("0") ) 
					ebd1GduiDAO.updateByPrimaryKeySelective(paramGDUI);
			}
			else {
				resultado = ebd1ProvDAO.findPK(params);
				if( resultado!=null && resultado.get("FCO_CONDP").equals("0") ) 
					ebd1ProvDAO.updateByPrimaryKeySelective(paramGDUI);
			}

		} else  if("02".equals(deuda.getCodTipdeuda())){  //Para el caso de L/Cs

			if(esAduanaLima) {   
				resultado = ebd1CduiDAO.findPK(params);
				if( resultado!=null && resultado.get("FCO_CONDP").equals("0") ) 
					ebd1CduiDAO.updateByPrimaryKeySelective(paramGDUI);
			}
			else {
				resultado = ebd1Prov1DAO.findPK(params);
				if( resultado!=null && resultado.get("FCO_CONDP").equals("0") ) 
					ebd1Prov1DAO.updateByPrimaryKeySelective(paramGDUI);
			}

		}


	}

	private void registroEnLiquida(DeudaDocum deudaLC, Date FechaTD ) {

		LiquidaDAO liquidaDAO = (LiquidaDAO) fabricaDeServicios.getService("exigibilidad.liquidaDAO");
		if( enableSwapperDataSource ){
			HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("exigibilidad.swapper.dx.prpp1");
			swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen." + deudaLC.getNumCda().substring(0,3) ));
		}

		Liquida tmpLiqu=new Liquida();
		tmpLiqu.setRladuana(deudaLC.getCodAduliquida());
		tmpLiqu.setRlano(String.valueOf(deudaLC.getAnnLiquida()).substring(2));
		tmpLiqu.setRlnroliq(deudaLC.getNumLiquida());
		tmpLiqu.setRlultdia(SunatDateUtils.getIntegerFromDate(FechaTD));
		tmpLiqu.setRlultdiac(SunatDateUtils.getIntegerFromDate(FechaTD));
		tmpLiqu.setRlvencim(SunatDateUtils.getIntegerFromDate(FechaTD));
		liquidaDAO.updateByPrimaryKeySelective(tmpLiqu);

	}

	/*
	public void setPagarantiaDAO(PagarantiaDAO pagarantiaDAO) {
		this.pagarantiaDAO = pagarantiaDAO;
	}
	 
	public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO) {
		this.participanteDocDAO = participanteDocDAO;
	}

	public void setEbd1ProvDAO(Ebd1provDAO ebd1ProvDAO) {
		this.ebd1ProvDAO = ebd1ProvDAO;
	}

	public void setEbd1Prov1DAO(Ebd1prov1DAO ebd1Prov1DAO) {
		this.ebd1Prov1DAO = ebd1Prov1DAO;
	}

	public void setEbd1CduiDAO(Ebd1cduiDAO ebd1CduiDAO) {
		this.ebd1CduiDAO = ebd1CduiDAO;
	}

	public void setEbd1GduiDAO(Ebd1gduiDAO ebd1GduiDAO) {
		this.ebd1GduiDAO = ebd1GduiDAO;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public void setLiquidaDAO(LiquidaDAO liquidaDAO) {
		this.liquidaDAO = liquidaDAO;
	}

	public void setPublicacionAvisoService(
			PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}
    */

}
