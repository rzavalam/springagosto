package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;

import java.util.Calendar;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Triblibe;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TriblibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.sigad.ingreso.service.ConsultaComprobanteCustodiaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.bean.Consulta;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetIncidenciaDAO;
import static pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes.COD_TIPO_DILIGENCIA_REVISION;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.ConsultaService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
/**
 *  The Class ValNegocNumeracFormA. Clase que define el servicio de validaciones de complejas para el formato A de la declaracion.
 *  PAS20171U220200005 - mtorralba 20170808 
 */
public class ValMercanciaVigenteServiceImpl extends ValDuaAbstract implements ValMercanciaVigenteService {
 
	//private FabricaDeServicios fabricaDeServicios;
	
	//private Log log = LogFactory.getLog(ValMercanciaVigenteServiceImpl.class);
	
	/**
	 * Servicio de Validaci�n que verifica que se cumplan con los criterios minimos para consignar mercancias vigentes
	 * @param declaracion
	 * @return
	 */
	
	@ServicioAnnot(tipo="V",codServicio=3481, descServicio="Servicio para validacion de Mercancias Vigentes")
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"dua"})
	@OrquestaDespaAnnot(codServInstancia=3481,numSecEjec=2,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, String>> validaIndicadorMercanciaVigente(DUA dua){
	
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		List<DatoIndicadores> listaIndicadores = dua.getListIndicadores();
		String desIndicador = "0";
		String codIndicador = "";
		 
		DatoIndicadores indicador  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadores);
		if( indicador != null ) {
			codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
			//desIndicador = (indicador.getDestipoindica()==null || indicador.getDestipoindica().equals("0")) ? "0": indicador.getDestipoindica();
			desIndicador = indicador.getDestipoindica();
		}
		
		boolean tiene_levante= dua.getFecAutlevante()!=null && !SunatDateUtils.isDefaultDate(dua.getFecAutlevante());
		String indicadorAsociado = "";
		boolean existeIndicadorPrevio = false;
		if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) ) {
			
			if(tiene_levante){
				if(esDeclaracionPrimigenia((Declaracion)dua.getPadre())){
					
					if(dua.getNumcorredoc()!=null){ 
						//buscamos si tenia el indicador						
						String evaluacionIndicadorPrevio = indicadorLlaveMaquinariaPrevio(dua.getNumcorredoc(),new String[]{ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO});
						existeIndicadorPrevio = evaluacionIndicadorPrevio!=null	&& !StringUtils.isEmpty(evaluacionIndicadorPrevio)?true:false;
						if(!existeIndicadorPrevio){ 
							indicadorAsociado="CONTRATO LLAVE EN MANO";
							grabaTelelog(listError, "32053", new Object[]{indicadorAsociado});//Declaraci�n cuenta con levante no procede acogerse
							return listError;
						}
					}
					
				}
			}
			
			List<DatoSerie> listaSeries = dua.getListSeries();
			boolean esPrimerEnvio = false;
			boolean tieneTPN = false;
			boolean diferenteCodigoLiberatorio = false;
			Integer codigoLiberatorio = 0;
			int contador = 0;
			for(DatoSerie serie : listaSeries) { 
				if( SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN20 ) || 
					SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN21 ) ) {
					tieneTPN = true;
					if( SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN20) ) esPrimerEnvio = true;
				}
				
				Integer serieCodLibe = serie.getCodliberatorio()==null ? 0 : serie.getCodliberatorio();
				if( contador==0 ) { 
					codigoLiberatorio = serieCodLibe;
					if( esPrimerEnvio && serieCodLibe==0 ) {
						grabaTelelog(listError, "32047", new Object[]{serie.getNumserie().toString()});//R1762
					}
				}
				else if( serieCodLibe==0 || !SunatNumberUtils.isEqual(serieCodLibe, codigoLiberatorio) ) { 
					diferenteCodigoLiberatorio = true;
					if( esPrimerEnvio ) {
						grabaTelelog(listError, "32043", new Object[]{serie.getNumserie().toString()});//R1762
						if( SunatNumberUtils.isEqual(codigoLiberatorio, 0) ) { 
							grabaTelelog(listError, "32047", new Object[]{serie.getNumserie().toString()});
						}
					}
				}
				contador++;
			} //Final FOR Lista Series
			
			if ( !tieneTPN )
				grabaTelelog(listError, "32041", new Object[]{""});//R1759
			else 
				if( esPrimerEnvio ) {
					//if( diferenteCodigoLiberatorio ) {
						//grabaTelelog(listError, "32043", new Object[]{""});//R1762
					//}else {
					if(!diferenteCodigoLiberatorio) {
						//if( SunatNumberUtils.isEqual(codigoLiberatorio, 0) ) { 
							//grabaTelelog(listError, "32047", new Object[]{""});
						//}else {
						if(!SunatNumberUtils.isEqual(codigoLiberatorio, 0) ) {
							//Debe buscar el RUC asociado al Codigo Liberatorio
							Map<String, Object> params=new HashMap<String, Object>();
							TriblibeDAO triblibeDAO = fabricaDeServicios.getService("triblibeDAO");
							params.put("tlib", "C");
							params.put("clib", codigoLiberatorio);
							params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
							List<Triblibe> listaCodLibera = triblibeDAO.findTriblibeByParams(params);
							
							if( listaCodLibera.size()>0) {
								String rucTribLibe = listaCodLibera.get(0).getClibtri();
								if( !rucTribLibe.equals(dua.getDeclarante().getNumeroDocumentoIdentidad()) ) {
									grabaTelelog(listError, "32044", new Object[]{rucTribLibe, dua.getDeclarante().getNumeroDocumentoIdentidad() });//R1763	
								}
							}
							else
								grabaTelelog(listError, "32052", new Object[]{codigoLiberatorio});

						}
					
						if(CollectionUtils.isEmpty(listError)) {
							if(!existeIndicadorPrevio)//alerta �Considere que este es su primer env�o de Mercanc�as Vigentes � Contrato Llave en Mano�
							grabaTelelog(listError, "32048", new Object[]{"CONTRATO LLAVE EN MANO"});
						}

					}
					
					desIndicador = desIndicador==null ? "0" : desIndicador;
					if( Integer.valueOf(desIndicador).intValue() == 0 )
						grabaTelelog(listError, "32042", new Object[]{"CONTRATO LLAVE EN MANO"});//R1761
				}
				
				/**
				 * Verificando que las dams con mercancia vigente TPN21 con indicador �Mercanc�as Vigentes Contrato Llave en Mano 
				 * y �Mercanc�as Vigentes - Maquinaria y Equipo en Despachos Parciales� presenten la misma declaraci�n precedente en todas sus series 
				 */
				else {//es vigente 
					
					boolean diferentesPrecedentes = false;
					
					if(!CollectionUtils.isEmpty(listaSeries)) {
						
						diferentesPrecedentes = esDiferentesDamsPrecedentes(listaSeries) ;
						if(diferentesPrecedentes) {
							indicadorAsociado="MERCANCIAS VIGENTES CONTRATO LLAVE EN MANO";
							grabaTelelog(listError, "32058", new Object[] {indicadorAsociado});
						}
					}
				}//fin else vigente

		}//Final Si es LlaveEnMano
		
		
		if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES ) ) {
			
			if(tiene_levante){
				if(esDeclaracionPrimigenia((Declaracion)dua.getPadre())){
					//buscamos si tenia el indicador					
					String evaluacionIndicadorPrevio = indicadorLlaveMaquinariaPrevio(dua.getNumcorredoc(),new String[]{ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES});
					existeIndicadorPrevio = evaluacionIndicadorPrevio!=null	&& !StringUtils.isEmpty(evaluacionIndicadorPrevio)?true:false;					
					//existeIndicadorPrevio = indicadorLlaveMaquinariaPrevio(dua.getNumcorredoc(),new String[]{ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES})!=null?true:false;
					if(!existeIndicadorPrevio){				
						indicadorAsociado="MERCANCIA VIGENTE: MAQUINARIA O EQUIPO ARRIBADO A DESPACHOS PARCIALES";
						grabaTelelog(listError, "32053", new Object[]{indicadorAsociado});//Declaraci�n cuenta con levante no procede acogerse
						return listError;
					}
				}
			}
			
			if( !dua.getCodtipotratamiento().equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DESPACHO_PARCIAL) ) 
				grabaTelelog(listError, "32045", new Object[]{""});

			List<DatoSerie> listaSeries = dua.getListSeries();
			boolean tieneTotalEnvios = false;
			boolean tieneTPN21 = false;
			for(DatoSerie serie : listaSeries) {
				if( SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN21) )
					tieneTPN21 = true;
				
			} //Final FOR Lista Series
			
			//desIndicador = desIndicador==null || desIndicador.equals("0") ? "0" : desIndicador;
			//tieneTotalEnvios = Integer.valueOf(desIndicador).intValue() == 0 ? false : true;
			tieneTotalEnvios = desIndicador==null ? false : true;
				
			if( !tieneTPN21 && !tieneTotalEnvios ) 	
				grabaTelelog(listError, "32046", new Object[]{""});
			else if( tieneTotalEnvios && !tieneTPN21) {
				if( Integer.valueOf(desIndicador).intValue() == 0 ) grabaTelelog(listError, "32042", new Object[]{"MAQUINARIA O EQUIPO ARRIBADO EN DESPACHOS PARCIALES"});//R1761
				if(!existeIndicadorPrevio) grabaTelelog(listError, "32048", new Object[]{"MAQUINARIA O EQUIPO ARRIBADO EN DESPACHOS PARCIALES"});
			}
			
			/**
			 * Verificando que las dams con mercancia vigente TPN21 con indicador �Mercanc�as Vigentes Contrato Llave en Mano 
			 * y �Mercanc�as Vigentes - Maquinaria y Equipo en Despachos Parciales� presenten la misma declaraci�n precedente en todas sus series 
			 */
			
			if(tieneTPN21) {				
					boolean diferentesPrecedentes = false;
					
					if(!CollectionUtils.isEmpty(listaSeries)) {
						
						diferentesPrecedentes = esDiferentesDamsPrecedentes(listaSeries) ;
						if(diferentesPrecedentes) { 
							indicadorAsociado="MERCANCIA VIGENTE: MAQUINARIA O EQUIPO ARRIBADO A DESPACHOS PARCIALES";
							grabaTelelog(listError, "32058", new Object[] {indicadorAsociado});
						}
					}
			}
				
		}//Final Si es Despachos Parciales

		return listError;
	}
	
	public DatoIndicadores obtenerIndicadorLlaveManoDespachoParcial (List<DatoIndicadores>  listaIndicadores){
		
		DatoIndicadores indicadorUtilizado = null;
		String codIndicador = "";
		if (!CollectionUtils.isEmpty(listaIndicadores)) {
			for(DatoIndicadores indicador : listaIndicadores ) {
				codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO )
									|| codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
					indicadorUtilizado = indicador;
					break;
				}
			}
		}
		return indicadorUtilizado;
	}  
	
	public boolean estaAcogidoLlaveManoDespachoParcial (String numcorredocDam) {
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
	    boolean estaAcogido = false;     
	    DatoIndicadores indicadorLlave = indicadorDuaService.obtenerIndicadorDeclaracion(numcorredocDam, ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO);
	    DatoIndicadores indicadorDespacho = indicadorDuaService.obtenerIndicadorDeclaracion(numcorredocDam, ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES);
	    if(indicadorLlave!=null && indicadorLlave.getIndicadorActivo().equals(ConstantesDataCatalogo.IND_ACTIVO) 
	   		 || indicadorDespacho!=null && indicadorDespacho.getIndicadorActivo().equals(ConstantesDataCatalogo.IND_ACTIVO)){
	   	 estaAcogido = true;
	    }
	    
	    return estaAcogido;
	}
	
	
	
	public Map<String,Object> obtenerDAMPrecedenteMercanciaVigente( String aduanaPrecedente, String anoPrecedente, String regimenPrecedente, String numeroPrecedente) {

		boolean esSIGAD = false;
		Map<String,Object> resultado = new HashMap<String,Object>();
		Map<String, Object> paramsDeclaracion = new HashMap<String, Object>();
		paramsDeclaracion.put("codigoRegimen", regimenPrecedente);
		paramsDeclaracion.put("codigoAduana", aduanaPrecedente);
		paramsDeclaracion.put("annoPresentacion", new Integer(anoPrecedente.substring(0, 4)));
		paramsDeclaracion.put("numeroDeclaracion", new Integer(numeroPrecedente));
		
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		DUA duaPrecedente = cabDeclaraDAO.findDUAByKeyMap(paramsDeclaracion);
	
		if (duaPrecedente == null) {
			esSIGAD = true;
			DAMOperativaConsultaService damOperativaConsultaService = fabricaDeServicios.getService("declaracion.DAMOperativaConsultaService");
			duaPrecedente = damOperativaConsultaService.ObtenerDAMOperativa(aduanaPrecedente, regimenPrecedente, new Integer(anoPrecedente), numeroPrecedente);
			
		} 
		else {
			esSIGAD = false;
			//PAS20171U220200005 - mtorralba 20170808 - Inicio - Incluye en indicador 33 y 34 el valor almacenado en CAB_ADI_IMPOCONSU.NUM_TOTALENVIOS
			IndicadorDUADAO indicadorDAO = fabricaDeServicios.getService("indicadorDUADAO");
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("numcorredoc", duaPrecedente.getNumcorredoc());
			params.put("codtiporegistro", "T");
			params.put("indactivo", Constants.INDICADOR_ACTIVO);
			
			Elementos<DatoIndicadores> nuevosIndicadores = new Elementos<DatoIndicadores>();
			Elementos<DatoIndicadores> indicadores = new Elementos<DatoIndicadores>();
			indicadores.addAll(indicadorDAO.findIndicadoresByMap(params));

			if(!indicadores.isEmpty()) {
				for(DatoIndicadores indicador:indicadores){
					String codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
					if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO ) || codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
											
						Integer totalEnvios = obtenerNumTotalEnvios(duaPrecedente.getNumcorredoc());//consultaBD refactorizada
						if(totalEnvios>0){
							indicador.setDestipoindica(totalEnvios.toString());
						}
					}
					nuevosIndicadores.add(indicador);
				} //final FOR indicadores
				duaPrecedente.setListIndicadores(indicadores);
			}
		} //final duaPrecedente != null
		resultado.put("duaPrecedente", duaPrecedente);
		resultado.put("esSIGAD",esSIGAD);
		return resultado;
	}


	public boolean tieneIndicadorMercanciaVigente( Elementos<DatoIndicadores> indicadores ) {

		boolean tieneIndicadorMV = false;
		if(!indicadores.isEmpty()) {
			for(DatoIndicadores indicador:indicadores){
				String codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO ) || codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
					tieneIndicadorMV = true;
					break;
				}
			} //final FOR indicadores
		}

		return tieneIndicadorMV;
	}
	
	public Integer obtenerSecuenciaEnvioPorDeclaracion( Declaracion declaracion ) {

		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();
		Integer secuencia = new Integer(0);
		if(series!=null){
			for(DatoSerie datoSerie : series){
				if(datoSerie.getListRegPrecedencia()!=null){
					for(DatoRegPrecedencia precedente : datoSerie.getListRegPrecedencia()){														 				
						String codregipre  = precedente.getCodregipre();
						String pcaduregpre = precedente.getCodaduapre();
						String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
						String pndclregpre = precedente.getNumdeclpre();
						secuencia = obtenerSecuenciaEnvio(pcaduregpre, pfanoregpre, codregipre, pndclregpre);
						break;
					}
					if(secuencia>0){
						break;
					}
				}
			}
		}
		return Integer.valueOf(secuencia);
	}
	
	
	public Integer obtenerSecuenciaEnvio( String codAduana, String anoPresen, String codRegimen, String numDeclara ) {

		int contador = 0;
		contador = obtenerEnviosRegistrados(codAduana, anoPresen, codRegimen, numDeclara);//devuelve los registrados + primigenia
		contador++;//toma la sgte secuencia
		
		return Integer.valueOf(contador);
	}
	
	/**
	 * Obtener envios registrados consultando por datos de la Primigenia
	 */
	public Integer obtenerEnviosRegistrados(String codAduana, String anoPresen, String codRegimen, String numDeclara ){
		Map<String,Object> paramPrece = new HashMap<String,Object>();
		paramPrece.put("COD_ADUANAPRE", codAduana);
		paramPrece.put("ANN_PRESENPRE", anoPresen);
		paramPrece.put("COD_REGIMENPRE", codRegimen);
		paramPrece.put("NUM_DECLARACIONPRE", numDeclara);
		paramPrece.put("IND_DEL", Constantes.PRECEDENTES_ACTIVOS);
		paramPrece.put("AGRUPADO", "1");
		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		List<DatoRegPrecedencia> listaPrecedentes = docuPreceDuaDAO.findOnlyRegPrecedenciaByMap(paramPrece); 
		int totalEnvios = 1; 
		
		if(listaPrecedentes!=null && !CollectionUtils.isEmpty(listaPrecedentes)){
			totalEnvios = listaPrecedentes.size()+1; // lo que encuentra en docuprece_dua + el primigenio
		}
		
		return  Integer.valueOf(totalEnvios);
	}

	/**
	 * Obtener envios registrados consultando por el numcorredoc de la primigenia
	 * 
	 */
	public Integer obtenerEnviosRegistrados(Long numcorredoc){
		
		int totalEnvios = 1; 
		Map<String,Object> params = new HashMap<String,Object>();

		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		params.put("NUM_CORREDOC",numcorredoc);

		List<Map<String,Object>>  mapaDam = cabDeclaraDAO.select(params);

		if(!CollectionUtils.isEmpty(mapaDam)){
			Map<String,Object> mapDatos = mapaDam.get(0);
			totalEnvios = obtenerEnviosRegistrados(mapDatos.get("COD_ADUANA").toString(), mapDatos.get("ANN_PRESEN").toString(),
					mapDatos.get("COD_REGIMEN").toString(), SunatStringUtils.lpad(mapDatos.get("NUM_DECLARACION").toString(),6,' '));
		} 
		return  Integer.valueOf(totalEnvios);
	}
	
	
	/***
	 * obtener el numcorredoc de la primigenia
	 * @param numcorredoc
	 * @return
	 */
	public Long obtenerNumcorredocPrimigeniaPorVigente(Long numcorredoc, Integer numSecSerie){
		
		Long numCorredocPrimigenia = new Long(0);
		
		Map<String,Object> paramPrece = new HashMap<String,Object>();
		paramPrece.put("NUM_CORREDOC", numcorredoc); 		
		paramPrece.put("IND_DEL", Constantes.PRECEDENTES_ACTIVOS);
		if(numSecSerie!=null && numSecSerie>0){
			paramPrece.put("NUM_SECSERIE", numSecSerie);
		}
		
		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		List<Map<String,Object>> listaPrecedentes = docuPreceDuaDAO.select(paramPrece); 
		if(!CollectionUtils.isEmpty(listaPrecedentes)){
			Map<String, Object> mapPrimigenia = listaPrecedentes.get(0);//toma la primera

			CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");

			Map<String,Object> params = new HashMap<String,Object>();
			params.put("NUM_DECLARACION", mapPrimigenia.get("NUM_DECLARACIONPRE").toString());
			params.put("COD_ADUANA", mapPrimigenia.get("COD_ADUANAPRE").toString());
			params.put("ANN_PRESEN", mapPrimigenia.get("ANN_PRESENPRE").toString());
			params.put("COD_REGIMEN", mapPrimigenia.get("COD_REGIMENPRE").toString());
		      
			String numCorredocEncontrado = cabDeclaraDAO.findNumCorreDocByDeclaracion(params);
			if(numCorredocEncontrado!=null && !StringUtils.isEmpty(numCorredocEncontrado)){
				numCorredocPrimigenia = new Long(numCorredocEncontrado);
			}
		}
		
		return numCorredocPrimigenia;
	}
	
	
		public Map<String, String> obtenerNumcorredocComprobanteCustodia(Long numcorredoc, Integer numSecSerie){

		//	List<Map<String, String>> param = new ArrayList<Map<String, String>>();
			Map<String, String> params = new HashMap<String,String>();
		//Long numCorredocPrimigenia = new Long(0);

		Map<String,Object> paramPrece = new HashMap<String,Object>();
		paramPrece.put("NUM_CORREDOC", numcorredoc);
		paramPrece.put("IND_DEL", Constantes.PRECEDENTES_ACTIVOS);
		paramPrece.put("COD_REGIMENPRE", ConstantesDataCatalogo.COMPROBANTE_CUSTODIA);
		if(numSecSerie!=null && numSecSerie>0){
			paramPrece.put("NUM_SECSERIE", numSecSerie);
		}

		/*DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		List<Map<String,Object>> listaPrecedentes = docuPreceDuaDAO.select(paramPrece);*/
			paramPrece.put("numcorredoc", numcorredoc);
			if (!numSecSerie.equals("")) {
				paramPrece.put("numserie", numSecSerie);
			}
			paramPrece.put("inddel", "0");
			DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
			List<DatoRegPrecedencia> listaPreced = docuPreceDuaDAO.findRegPrecedenciaByMap(paramPrece);
			//return listaPreced;

		if(!CollectionUtils.isEmpty(listaPreced)){
			for (DatoRegPrecedencia datoprece : listaPreced) {
				Long numCorreDoc = datoprece.getNumcorredoc();
				Map<String, Object> parametroConsultarRestring = new HashMap<String, Object>();
				params.put("NUM_CORREDOC", SunatStringUtils.toStringObj(numcorredoc));
				params.put("COD_ADUANA", datoprece.getCodaduapre());
				params.put("NUM_DECLARACION", SunatStringUtils.lpad(datoprece.getNumdeclpre(),6,'0'));
				params.put("COD_REGIMENPRE", ConstantesDataCatalogo.COMPROBANTE_CUSTODIA);
				params.put("ANN_PRESEN", datoprece.getAnndeclpre());
			}

		}

		return params;
	}


	public List<Map<String, String>> obtenerNumcorredocComprobanteCustodia(Long numcorredoc){

		List<Map<String, String>> listaResult = new ArrayList<Map<String,String>>();

		Map<String,Object> paramPrece = new HashMap<String,Object>();
		paramPrece.put("numcorredoc", numcorredoc);
		paramPrece.put("inddel", "0");
		//ConstantesDataCatalogo.COMPROBANTE_CUSTODIA
		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		List<Map<String,Object>> listaPreced = docuPreceDuaDAO.obtenerPrecedentesPorDAM(paramPrece);

		if(!CollectionUtils.isEmpty(listaPreced)){
			for (Map<String,Object> datoprece : listaPreced) {
				Map<String, String> params = new HashMap<String,String>();
				params.put("NUM_CORREDOC", SunatStringUtils.toStringObj(numcorredoc));
				params.put("COD_ADUANA", datoprece.get("COD_ADUANAPRE").toString());
				params.put("NUM_DECLARACION", SunatStringUtils.lpad(datoprece.get("NUM_DECLARACIONPRE").toString(),6,'0'));
				params.put("COD_REGIMENPRE", datoprece.get("COD_REGIMENPRE").toString());
				params.put("ANN_PRESEN", datoprece.get("ANN_PRESENPRE").toString());
				listaResult.add(params);
			}
		}

		return listaResult;
	}

		
	public Map<String, String> actualizarDocuprecedua(Long numcorredoc, Integer numSecSeriePre){

		//	List<Map<String, String>> param = new ArrayList<Map<String, String>>();
		Map<String, String> params = new HashMap<String,String>();
		//Long numCorredocPrimigenia = new Long(0);

		Map<String,Object> paramPrece = new HashMap<String,Object>();
		paramPrece.put("NUM_CORREDOC", numcorredoc);
		paramPrece.put("IND_DEL", Constantes.PRECEDENTES_ACTIVOS);
		//paramPrece.put("COD_REGIMENPRE", ConstantesDataCatalogo.COMPROBANTE_CUSTODIA);
		if(numSecSeriePre!=null && numSecSeriePre>0){
			paramPrece.put("NUM_SECSERIEPRE", numSecSeriePre);
		}

		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		docuPreceDuaDAO.updateRegPrecedenciaByMap(paramPrece);
		return params;
	}

		public void actualizarComprobanteCustodia(String anoPrese, String codiAduan, String numeCorre, String codaduanaConex,String cantSerie,String codPautoriza){

	ConsultaComprobanteCustodiaService consultaComprobanteCustodiaService = (ConsultaComprobanteCustodiaService)fabricaDeServicios.getService("sigad.ingreso.ConsultaComprobanteCustodiaService");

	consultaComprobanteCustodiaService.actualizarComprobanteCustodia(anoPrese, codiAduan, numeCorre, codaduanaConex,cantSerie,codPautoriza,null,null);

	return;
	}


	public Integer obtenerNumTotalEnvios( Elementos<DatoIndicadores> indicadores ) {

		Integer resul = Integer.valueOf(0);
		if(!indicadores.isEmpty()) {
			for(DatoIndicadores indicador:indicadores){
				String codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO ) || codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
					resul = Integer.valueOf(indicador.getDestipoindica());
					break;
				}
			} //final FOR indicadores
		}

		return resul;
	}
	
	/**
	 * Obtener total de envios por numcorredoc de la primigenia
	 */
	public Integer obtenerNumTotalEnvios(Long numcorredoc){
		
		Integer resul = Integer.valueOf(0);
		CabAdjImpoconsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");
		
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("NUM_CORREDOC", numcorredoc);
		List<Map<String, Object>> listaAdiImpo = cabAdiImpoconsuDAO.select(params);
		if( listaAdiImpo.size() > 0 ) {
			Map<String,Object> mapaAdiImpoConsu = listaAdiImpo.get(0);
			String numTotalEnvios = mapaAdiImpoConsu.get("NUM_TOTALENVIOS")==null ? "0" : mapaAdiImpoConsu.get("NUM_TOTALENVIOS").toString();
			resul = new Integer (numTotalEnvios);
		}		
		
		return resul;
	}
	 
	
	public Map<String,Object> obtenerIndicadorMercanciaVigente( Elementos<DatoIndicadores> indicadores ) {

		Map<String,Object> mapaResul = new HashMap<String,Object>();
		if(!indicadores.isEmpty()) {
			for(DatoIndicadores indicador:indicadores){
				String codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO ) || codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
					mapaResul.put("codIndicador", codIndicador);
					mapaResul.put("desIndicador", indicador.getDestipoindica());
					mapaResul.put("nomIndicador", codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) ? "CONTRATO LLAVE EN MANO" : "MAQUINARIA O EQUIPO ARRIBADO EN DESPACHOS PARCIALES");
					break;
				}
			} //final FOR indicadores
		}

		return mapaResul;
	}
	
	 
	
	/**
	 * Servicio de Validaci�n que verifica el retiro de los indicadores de mercancia vigente
	 * para declaraciones primigenias
	 * @param declaracion
	 * @return
	 */
	
	@ServicioAnnot(tipo="V",codServicio=3482, descServicio="Servicio para validacion del retiro indicador de Mercancias Vigentes")
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"Declaracion","DeclaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3482,numSecEjec=64,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public List<Map<String, String>> validaRetiroIndicadorMercanciaVigente(Declaracion declaracion, Declaracion declaracionBD){
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		List<DatoIndicadores> listaIndicadoresEnvio = declaracion.getDua().getListIndicadores();
		List<DatoIndicadores> listaIndicadoresBD = declaracionBD.getDua().getListIndicadores();
		DatoIndicadores indicador  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresEnvio);
		DatoIndicadores indicadorBD  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresBD);
		
		boolean esRetiroIndicador = false;
		boolean esCambioIndicador = false;
 
		boolean esPrimigenia = esDeclaracionPrimigenia(declaracionBD);
		
		 if(esPrimigenia){
			 
			 if(indicador == null && indicadorBD!=null){
				 String descripcion  = "";  
						 
				 if(indicadorBD.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO)) 
					 descripcion ="MERCANCIA LLAVE EN MANO";
					 
				 if(indicadorBD.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES)) 
					 descripcion = "MERCANCIA VIGENTE DESPACHOS PARCIALES";
					 
				//int totalEnviosVigente = obtenerTotalEnviosRegistradosVigentes(declaracionBD);
				 int totalEnviosVigente =  obtenerEnviosRegistrados(declaracion.getCodAduana(), declaracion.getAnnorden(), declaracion.getCodregimen(), declaracion.getNumeroDeclaracion().toString());
				if(totalEnviosVigente>1){//solo existe la primigenia
					grabaTelelog(listError, "32055", new Object[]{indicadorBD.getCodtipoindica().concat("-").concat(descripcion)});//NO SE PUEDE RETIRAR EL INDICADOR {0} PORQUE ESTA DECLARACION HA SIDO CONSIGNADA COMO PRECEDENTE
				}
			 }
		 }
					
		return listError;
	}
	
	
	public boolean esDeclaracionPrimigenia(Declaracion declaracion){
	
		boolean esPrimigenia = false;
		List<DatoIndicadores> listaIndicadoresEnvio = declaracion.getDua().getListIndicadores(); 
		DatoIndicadores indicador  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresEnvio);
		
		List<DatoSerie> listaSeries = declaracion.getDua().getListSeries();
	 	
		if(indicador!=null){
			for(DatoSerie serie : listaSeries) {
				String codIndicador =  indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if(codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO)){
					if( SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN20) ){//tpn20 debe ser enviado
						esPrimigenia = true;
						break;
					}
				}
				if(codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES)){
					//if( SunatNumberUtils.isEqual(serie.getCodtratprefe(), ConstantesDataCatalogo.TPN20) ){
					if(indicador.getDestipoindica()!=null && new Integer(indicador.getDestipoindica())>0){//total debe ser mayor a 0
						esPrimigenia = true;
						break;
					}
				}
			}
		}
			 
		return esPrimigenia;
	}
	
	public boolean esDeclaracionPrimigenia(Long numcorredoc, String indicador){
		
		//si es llave en mano la primigenia es con el indicador y el tpn20
		//si es despachos parciales es con el indicador y el total de envios
		boolean esPrimigenia = false;

		if(indicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO)){
			ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("convenioSerieDAO");
			
			Map<String, Object> paramConvSerie = new HashMap<String, Object>();
			paramConvSerie.put("NUM_CORREDOC", numcorredoc);
			paramConvSerie.put("COD_TIPCONVENIO", "T");
			paramConvSerie.put("COD_CONVENIO", SunatStringUtils.lpad(ConstantesDataCatalogo.TPN20.toString(),4,' '));
			paramConvSerie.put("IND_DEL", "0");
			
			List<Map<String, Object>> lstConv = convenioSerieDAO.select(paramConvSerie);
			
			if(lstConv!=null && !CollectionUtils.isEmpty(lstConv)){
				esPrimigenia = true;
			}
		}else if(indicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES)){
			if(obtenerNumTotalEnvios(numcorredoc)>0){
				esPrimigenia = true;
			}
		}
		
		return esPrimigenia;
		
	}
	
	/**
	 * Servicio de Validaci�n que verifica dams con mercancia vigente TPN21
	 * con indicador �Mercanc�as Vigentes Contrato Llave en Mano 
	 * y �Mercanc�as Vigentes - Maquinaria y Equipo en Despachos Parciales� 
	 * presenten la misma declaraci�n precedente en todas sus series 
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=3483, descServicio="Servicio para validacion de precedente igual en todas las series")
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"Declaracion","DeclaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3483,numSecEjec=64,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public List<Map<String, String>> validarDeclaracionMismaPrecedenteEnSeries(Declaracion declaracion){
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		List<DatoIndicadores> listaIndicadores = declaracion.getDua().getListIndicadores();
		String desIndicador = "0";
		String codIndicador = "";
		 
		DatoIndicadores indicador  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadores);
		if( indicador != null ) {
			codIndicador = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
			desIndicador = indicador.getDestipoindica();
		}
		if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) 
				||  codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES)  ) {
			
			
			
		}
		return listError;
		
	/*	Solo en los casos de Declaraciones con mercanc�a vigente TPN 21 con indicador  
		�Mercanc�as Vigentes Contrato Llave en Mano y �Mercanc�as Vigentes - Maquinaria y Equipo en Despachos Parciales� 
		el mensaje  de rechazo seria el siguiente: �Declaraci�n con Indicador [�Mercanc�as Vigentes Contrato Llave en Mano�] o 
		[�Mercanc�as Vigentes - Maquinaria y Equipo en Despachos Parciales�] debe declarar la misma declaraci�n precedente en todas su series�.*/
	}
	
	/**
	 * Servicio de Validaci�n que verifica el cambio en el total de envios de mercancia vigente
	 * para declaraciones primigenias
	 * @param declaracion
	 * @return
	 */
	
	@ServicioAnnot(tipo="V",codServicio=3483, descServicio="Servicio para validacion del cambio del total del Mercancias Vigentes")
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"Declaracion","DeclaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3483,numSecEjec=64,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public List<Map<String, String>> validaTotalEnviosMercanciaVigente(Declaracion declaracion, Declaracion declaracionBD){
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		boolean esPrimigenia = esDeclaracionPrimigenia(declaracionBD);
		
		if(esPrimigenia){
			
			DUA duaBD =declaracionBD.getDua(); 
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC",duaBD.getNumcorredoc());
			CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
			
			Date Fec_levante=cabDeclaraDAO.findFecAutLevante(params); 
			boolean tiene_levante= !SunatDateUtils.isDefaultDate(Fec_levante);
				 
			if(tiene_levante){
		
				List<DatoIndicadores> listaIndicadoresEnvio = declaracion.getDua().getListIndicadores();
				List<DatoIndicadores> listaIndicadoresBD = declaracionBD.getDua().getListIndicadores();
				DatoIndicadores indicador  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresEnvio);
				DatoIndicadores indicadorBD  = obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresBD);
			 
				Integer totalEnvios = (indicador==null 
						|| indicador!=null && (indicador.getDestipoindica()==null || indicador.getDestipoindica().equals("0")) )? new Integer("0"): new Integer(indicador.getDestipoindica());
				Integer totalEnviosBD = (indicadorBD==null 
						|| indicadorBD!=null && (indicadorBD.getDestipoindica()==null || indicadorBD.getDestipoindica().equals("0")) )? new Integer("0"): new Integer(indicadorBD.getDestipoindica());
				
				boolean esRectiTotalEnvios = false;		
				if(totalEnvios.compareTo(totalEnviosBD)>0 || totalEnvios.compareTo(totalEnviosBD)<0){ 
					esRectiTotalEnvios = true;	
				}
				
				if( indicador!=null && esRectiTotalEnvios){

					int totalEnviosRegistrados = 0;				
				 	//totalEnviosRegistrados = obtenerTotalEnviosRegistradosVigentes(declaracion);
					totalEnviosRegistrados = obtenerEnviosRegistrados(declaracion.getDua().getCodaduanaorden(), declaracion.getDua().getAnnorden().toString(), declaracion.getDua().getCodregimen(), declaracion.getNumeroDeclaracion().toString());
					if(totalEnvios.compareTo(totalEnviosRegistrados)<0 || totalEnvios.compareTo(totalEnviosRegistrados)==0){ 
						grabaTelelog(listError, "32054", new Object[]{totalEnvios, totalEnviosRegistrados});//TOTAL DE ENVIOS {0} ES MENOR AL NUMERO DE ENVIOS {1} QUE YA SE HAN EFECTUADO
					}				
				}		
			}
		}
		
		return listError;
	}
	
	public String indicadorLlaveMaquinariaPrevio(long numecorredoc, String[] listaIndicadores){
		String existeIndicador = "";
		List<DatoIndicadores> indicadorRegistrado = null;
		Map<String, Object> params = new HashMap<String, Object>();
		IndicadorDUADAO indicadorDAO = fabricaDeServicios.getService("indicadorDUADAO");
		params.put("numcorredoc",numecorredoc);
		params.put("codtiporegistro", "T");
		params.put("indactivo", Constants.INDICADOR_ACTIVO);
		params.put("listaTipoIndica", listaIndicadores);
		indicadorRegistrado = indicadorDAO.findIndicadoresByMap(params);  
		
		if(indicadorRegistrado!=null && !CollectionUtils.isEmpty(indicadorRegistrado)){
			existeIndicador = indicadorRegistrado.get(0).getCodtipoindica();
		}
		
		return existeIndicador;		
	} 
	
	public List<Map<String, String>> validaIndicadorDAMVigente(Integer numSerie, String DAMPrecedente, String indicadorVigente, String indicadorPrecedente ){
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if( numSerie == 1 ) {
			if( indicadorVigente.trim().equals("")) {
				if( !indicadorPrecedente.trim().equals("") ) {
					//SERIE {0}: LA DAM {1} PRECEDENTE CONSIGNADA TIENE EL INDICADOR {2}, DEBE TRANSMITIR EL INDICADOR CORRESPONDIENTE.
					String detalle = indicadorPrecedente.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) 
							? "MERCANCIA VIGENTE - CONTRATO LLAVE EN MANO" : "MERCANCIA VIGENTE - MAQUINARIA ARRIBADA EN DESPACHOS PARCIALES";
					//grabaTelelog(listError, "32056", new Object[]{numSerie, DAMPrecedente, detalle });
					grabaTelelog(listError, "32056", new Object[]{DAMPrecedente, detalle });
				}
				
			}
			else {
				//SERIE {0}: EL INDICADOR {1} TRANSMITIDO NO CORRESPONDE CON {2} CONSIGNADO EN LA DAM PRECEDENTE {3}
				if( !indicadorPrecedente.equals(indicadorVigente)) {
					String detalleVigente = indicadorVigente.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) ? "MERCANCIA VIGENTE - CONTRATO LLAVE EN MANO" : "MERCANCIA VIGENTE - MAQUINARIA ARRIBADA EN DESPACHOS PARCIALES";
					String detallePrecedente = "";
					if( indicadorPrecedente.trim().equals("") )
						detallePrecedente = "LO"; 
					else 
						detallePrecedente = "EL INDICADOR " + 
								(indicadorPrecedente.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO) ? "MERCANCIA VIGENTE - CONTRATO LLAVE EN MANO" : "MERCANCIA VIGENTE - MAQUINARIA ARRIBADA EN DESPACHOS PARCIALES");
				
					//grabaTelelog(listError, "32057", new Object[]{numSerie, detalleVigente, detallePrecedente, DAMPrecedente });
					grabaTelelog(listError, "32057", new Object[]{detalleVigente, detallePrecedente, DAMPrecedente });
				}
			}
		} //Final numSerie=1
		
		return listError;
	}
	
	
	
	public void grabaTelelog(List<Map<String,String>>listError, String codigo, Object[] params){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		listError.add(getDUAError(codigo, params));
	}
	

	/*

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	

	public List<Map<String,String>> filtraErroresDuplicados (List<Map<String,String>> listaErrores) {
		List<Map<String,String>> listaResultado = new ArrayList<Map<String,String>>();
		boolean incluirEnLista = true;
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String FiltroError = catalogoAyudaService.getStringElementosGrupo("080");
		for( Map<String,String> mapaError : listaErrores ) {
			incluirEnLista = true;
			String codigo = mapaError.get("codError").toString();
			if( FiltroError.indexOf(codigo) > 0 ) {
				for(Map<String,String> mapaResul : listaResultado) {
					if( codigo.equals(mapaResul.get("codError").toString()) ) {
						incluirEnLista = false;
						break;
					}
				}
			}
			if( incluirEnLista ) listaResultado.add(mapaError);	
		}
		
		 
		return listaResultado;
	}

	public boolean esDiferentesDamsPrecedentes(List<DatoSerie> listaSeries) {
		
		boolean diferentesPrecedentes = false;
		List<String> listDamPrecedentes = new ArrayList<String>();
		
		for(DatoSerie datoSerie : listaSeries){						
			if(datoSerie.getListRegPrecedencia()!=null){
				
				for(DatoRegPrecedencia precedente : datoSerie.getListRegPrecedencia()){	
					 
					String codregipre  = precedente.getCodregipre();
					String pcaduregpre = precedente.getCodaduapre();
					String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
					String pndclregpre = precedente.getNumdeclpre();
					
					String damPrecedente = codregipre.concat("-").concat(pcaduregpre).concat("-").concat(pfanoregpre).concat("-").concat(pndclregpre);
					if(listDamPrecedentes.isEmpty()){
						listDamPrecedentes.add(damPrecedente);
					}
					if(!listDamPrecedentes.contains(damPrecedente)) {
						diferentesPrecedentes = true;
					}								
				}
				
			}
		}
		return diferentesPrecedentes;
	}

	public List<Map<String,String>> valTipoPrecedente(DatoSerie serie) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if (serie.getListRegPrecedencia() != null) {
			for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) {	
				if (Constantes.COD_REGIMEN_10.equals(precedente.getCodregipre())) {
					
				}
			}
		}
		
		
		/*Ya existe declaraci�n precedente y se debe verficar que sea una DSEER de Ingreso
		   
	     */
		return listError;
	}
	
	public List<Map<String,String>> valPrecedentexSerie(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		Elementos<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
		
		if (!CollectionUtils.isEmpty(lstSeries)) {
			if (!CollectionUtils.isEmpty(lstSeries.get(0).getListRegPrecedencia())) {
				DatoRegPrecedencia precedente = lstSeries.get(0).getListRegPrecedencia().get(0);
				String codRegimen = precedente.getCodregipre();
				if ("28".equals(codRegimen)) {
					for (DatoSerie serie : lstSeries) {
						Elementos<DatoRegPrecedencia> lstPrecedente = serie.getListRegPrecedencia();
						if (!CollectionUtils.isEmpty(lstPrecedente)) {
							for (DatoRegPrecedencia prece : lstPrecedente) {
								if (!(prece.getCodaduapre().equals(precedente.getCodaduapre()) &&
									  prece.getCodregipre().equals(precedente.getCodregipre()) &&
									  prece.getAnndeclpre().equals(precedente.getAnndeclpre()) &&
									  prece.getNumdeclpre().equals(precedente.getNumdeclpre()))) {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70127",
											new String[] { prece.getCodaduapre(),
													       prece.getAnndeclpre(),
													       prece.getCodregipre(),
													       prece.getNumdeclpre()
									}));
								}
							}
						}
					}
				}
			}
		}
		
		/*Se verifica que todas las series se encuentren relacionadas a las misma 
        DSEER de Ingreso precedente :
          Si serie(n).precdeclaracion = serie(n+1).precdeclaracion
          sino muestra mensaje de error E54. (70077)
        */
		return listError;
	}
	
	public List<Map<String,String>> valConsignatarioPrecDeclaracion(Declaracion declaracion) {

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		/*ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
		
		List<DatoSerie> series = declaracion.getDua().getListSeries();
		Map<String, Object> parametrosParticipante = new HashMap();
		parametrosParticipante.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		parametrosParticipante.put("COD_TIPPARTIC_LIST", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		
		List<Participante> participantesAll = participanteDAO.findParticipantesByMap(parametrosParticipante);
		//Con los datos del reg precedente buscar la dua precedente en bd
		//de los participantes de la dseer en memoria comprar
		Participante consignatario = declaracion.getDua().getConsignatario();
		*/
		/*
			
			for(DatoSerie serie: series){				
				DatoRegPrecedencia regPrecedente = serie.getListRegPrecedencia().get(0);
				if (serie.getListRegPrecedencia() != null) {
						if (!CollectionUtils.isEmpty(participantesAll)) {
							for (Participante participante : participantesAll) {
								if (!(participante.getTipoParticipante().getCodDatacat().
										equals(declaracion.getDua().getDeclarante().getRolParticipante().getCodDatacat()) &&
										participante.getTipoDocumentoIdentidad().getCodDatacat().
											equals(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()) &&
										participante.getNumeroDocumentoIdentidad().
											equals(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad())
										)) {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70126"));
								}
							}
						}
					}
		}*/

		/*Validar que el consignatario de la declaraci�n precedente 
	       sea igual al consignatario de la DSEER  a numerar:
	         declaracion.tipodoc = precdeclaracion.tipodoc and declarac�on.numdoc = precdeclarac�on.numdoc
	         sino mensaje de error E57 (70076)
	      
	      */
		return listError;
	}
	
	public List<Map<String,String>> valLevantePrecDeclaracion(Declaracion declaracion) throws ParseException {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		/*String fechaDefault = "";
		
		if (declaracion.getDua().getFecAutlevante() != null) {
			fechaDefault = DateUtil.dateToString(declaracion.getDua().getFecAutlevante(), "dd/MM/yyyy");
			if (Constantes.DEFAULT_FECHA_BD.equals(fechaDefault)) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70125"));
			}
			
		} else {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70125"));
		}*/
	      /*Se valida que la declaraci�n precedente tenga levante registrado
	         precDeclaracion.fecLevante>0 sino mensaje de error E58
	      */
	    return listError;
	}
	
	public List<Map<String,String>> valCanalSolRecoDeclaracion(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		/*Long numeroCorreDUAPre = declaracion.getDua().getNumcorredoc();
		
		ConsultaService consultaService = fabricaDeServicios.getService("diligencia.ingreso.consultaService");
		
		if (declaracion.getDua().getCodCanal().equals("V")) {
			Consulta filtroConsulta = new Consulta();
			filtroConsulta.setNumcorredoc(numeroCorreDUAPre);
			filtroConsulta.setTipoDiligencia(COD_TIPO_DILIGENCIA_REVISION);
			filtroConsulta.setIndicadorRespuesta("1");
			List<Consulta> listaSolReconFisico = (ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta);
			if (CollectionUtils.isEmpty(listaSolReconFisico)) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70124"));
			}
		} else if (!declaracion.getDua().getCodCanal().equals("F")) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70124"));
		}
		*/
	      /*
	      Se valida si el canal de la declaracion precedente es de canal rojo o verde
	      con solicitud de reconocimeinto fisico procedente 
	      
	      if(precDeclaracion.canal = "F")
	         ok
	      ifelse (precDeclaracion.canal = "V")
	        Consulta filtroConsulta = new Consulta();
	   	  filtroConsulta.setNumcorredoc(new Long(PkDocu.get("NUM_CORREDOC").toString()));
	   	  filtroConsulta.setTipoDiligencia(Constantes.COD_TIPO_DILIGENCIA_REVISION);
	   	  // Consultas aprobadas
	   	  filtroConsulta.setIndicadorRespuesta("1");
	   	  ArrayList<Consulta> listaSolReconFisico = (ArrayList<Consulta>)consultaService.buscarConsultaSimple(filtroConsulta);
	        if(!CollectionUtils.isEmpty(listaSolReconFisico))
	   	      tieneSolReconFisico = true;	
	        else
	            mensaje de error E59
	      else
	         mensaje de error E59
	      endif
	      */
	    return listError;
	}
	
	public List<Map<String,String>> valIncideciaDeclaracion(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		/*DetIncidenciaDAO incidenciaDAO = fabricaDeServicios.getService("diligencia.detIncidenciaDAO");
		
		Long numeroCorreDUAPre = declaracion.getDua().getNumcorredoc();
		
		Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
		paramsIncidencia.put("NUM_CORREDOC", numeroCorreDUAPre);
		paramsIncidencia.put("COD_INCIDENCIA", new String[]{
												ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30"});//CONSIDERAR 30 Bultos vigentes?

		List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
		
		if (incidencia == null || CollectionUtils.isEmpty(incidencia)) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70123"));
		}*/
		
	      /*Se valida que la declaraci�n precedente tenga registra la incidencia F121 (Mercancia Vigente)
	   	Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
	   	paramsIncidencia.put("NUM_CORREDOC", numeroCorreDUAPre.toString());
	   	paramsIncidencia.put("COD_INCIDENCIA", new String[]{ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30"});//CONSIDERAR 30 Bultos vigentes?
	   	 List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
	   	 if(incidencia == null || CollectionUtils.isEmpty(incidencia)){
	   		 mensaje de error E62.
	   	 }
	   
	      */ 
	    return listError;
	}
	
	public List<Map<String,String>> valFechaPrecedente(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		/*Date fechaActual = new Date();
		Date fecNumeracion = declaracion.getDua().getFecNumeracion();

		if (validarFechaMenor(fechaActual, fecNumeracion)) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70122"));
		}*/

		/*Se valida que la fecha de numeraci�n de la DSEER precedente
		        sea menor a 4 a�os a la fecha de numeraci�n de la DSEER
		        declaracion.fechanume + 40000 < fechactual
		        sino mensaje E64
		*/
		return listError;
	}
	
	public Boolean validarFechaMenor(Date fechaNumeracion, Date fechaActual) {
		
		Boolean esMenor = false;
		
		Calendar fecNumeracion = Calendar.getInstance(Locale.US);
		fecNumeracion.setTime(fechaNumeracion);
		
		Calendar fecActual = Calendar.getInstance(Locale.US);
		fecActual.setTime(fechaActual);

		int diferenciaAnnios = fecActual.get(Calendar.YEAR) - fecNumeracion.get(Calendar.YEAR);
		
		if (fecNumeracion.get(Calendar.MONTH) > fecActual.get(Calendar.MONTH) || 
		   (fecNumeracion.get(Calendar.MONTH) == fecActual.get(Calendar.MONTH) && 
		   fecNumeracion.get(Calendar.DATE) > fecActual.get(Calendar.DATE))) {
			diferenciaAnnios--;
		}
		
		if (diferenciaAnnios < 4) esMenor = true;
		
		return esMenor;
		
	}
}