/*
 * Clase que define el servicio de validaciones de la Relaci�n de insumos de la declarados en la dua.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValProduct. Clase que define el servicio de validaciones de la Relaci�n de insumos de la declarados en la dua.
 */
public class ValProductServiceImpl extends ValDuaAbstract implements ValProduct {
	
	/*private FabricaDeServicios fabricaDeServicios;
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

	/**
	 * Valida el C�digo del insumo otorgado por el importador / exportador.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numitem String. C�digo del insumo otorgado por el importador / exportador.
	 * @return Map
	 */
	public Map<String, String> numitem(String numitem){
//		return !SunatStringUtils.isEmptyTrim(numitem)?new HashMap<String,String>():getDUAError("30086","");
		return new HashMap<String,String>();
	}

	/**
	 * Valida el codigo de tipo de unidad de medida equivalente.<br>
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoequi String. C�digo del tipo de unidad de medida equivalente (Ad.Temporal).
	 * @return Map
	 */
	public Map<String, String> codtipoequi(String codtipoequi){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("78", codtipoequi))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("78", codtipoequi, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("05042","Error catalogo codtipoequi");
	}

	/**
	 * Valida la cantidad de unidades de equivalente (Ad.Termporal).<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntunimedidaequi BigDecimal. Cantidad de unidades de equivalente (Ad.Termporal).
	 * @return Map
	 */
	public Map<String, String> cntunimedidaequi(BigDecimal cntunimedidaequi){
		if (cntunimedidaequi!=null)
			return (SunatNumberUtils.isGreaterThanZero(cntunimedidaequi))?new HashMap<String,String>():getDUAError("05002","");
		else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el Porcentaje de la merma.<br>
	 * Valida que el par&aacute;metro sea un dato num&eacute;rico de porcentaje.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param pormerma BigDecimal. Porcentaje de la merma.
	 * @return Map
	 */
	public Map<String, String> pormerma(BigDecimal pormerma){
		
		if(pormerma == null)
			return new HashMap<String,String>();
		
		//return (SunatNumberUtils.isGreaterThanZero(pormerma) && SunatNumberUtils.isLessOrEqualsThanZero(pormerma))?new HashMap<String,String>():getDUAError("30089","");
		return (SunatNumberUtils.isGreaterThanZero(pormerma) && SunatNumberUtils.isLessOrEqualsThanParam(pormerma,99.9999))?new HashMap<String,String>():getDUAError("30089","");
	}

	/**
	 * Valida el C�digo del exportador para aplicaci�n del antidumping.<br>
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No implementado
	 * @param codexpantidum String. C�digo del exportador para aplicaci�n del antidumping.
	 * @return Map
	 */
	public Map<String, String> codexpantidum(String codexpantidum){
		//TODO
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo de producto antidumping.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No implementado
	 * @param codpantidum String. C�digo de producto antidumping.
	 * @return Map
	 */
	public Map<String, String> codpantidum(String codpantidum){
		//TODO
		return new HashMap<String,String>();
	}

	/**
	 * Valida el Valor fob de la factura para el calculo del antidumping.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofobfactu BigDecimal.Valor fob de la factura para el calculo del antidumping.
	 * @return Map
	 */
	public Map<String, String> mtofobfactu(BigDecimal mtofobfactu){
		if (mtofobfactu!=null)
			return SunatNumberUtils.isGreaterOrEqualsThanZero(mtofobfactu)?new HashMap<String,String>():getDUAError("30092","");
		return new HashMap<String,String>();
	}


}
