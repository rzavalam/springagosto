/*
 * Clase que define el servicio de validaciones de codigos liberatorios.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_LIBERATORIO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_TRATO_PREF_INTERNACIONAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_TRATO_PREF_NACIONAL;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TabLibe;
//import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PaisOrigenTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PreferenciaArancelariaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.SubPartidaNacionalTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.model.Adualib;
import pe.gob.sunat.despaduanero2.declaracion.model.Adulibe;
import pe.gob.sunat.despaduanero2.declaracion.model.AladLibe;
import pe.gob.sunat.despaduanero2.declaracion.model.Aladi504;

import pe.gob.sunat.despaduanero2.declaracion.model.CupoTpi;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.ExCodLib;
import pe.gob.sunat.despaduanero2.declaracion.model.ExNanLib;
import pe.gob.sunat.despaduanero2.declaracion.model.NandLibe;
import pe.gob.sunat.despaduanero2.declaracion.model.Nandi110;

import pe.gob.sunat.despaduanero2.declaracion.model.Triblibe;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdualibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdulibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AladlibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Aladi504DAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupolibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupotpiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExCodLibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExNanLibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Nandi110DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandlibeDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.OrilibeDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.TriblibeDAO;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValVerilib. Clase que define el servicio de validaciones de codigos liberatorios.
 */
public class ValVerilibServiceImpl extends ValDuaAbstract implements ValVerilib{
	
	//private CodiLibeDAOService codiLibeDAOService;
	//private TabLibeDAOService tabLibeDAOService;
	// rpumacayo pase70
	//private CatalogoAyudaService catalogoAyudaService;
	//private FabricaDeServicios fabricaDeServicios;
	// rpumacayo pase70
	/**
	 * La funcion verilib esta basado en la Ingenieria Inversa descrito en el siguiente documento
	 * ING_REV_TELEDESPACHO IMPORTACION DEFINITIVA NUMERACION V1.doc
	 * 
	 * @param tipo_lib 	Tipo de Preferencia arancelaria (C: C�digo Liberatorio, T: TPN, I: TPI)
	 * @param codi_libe C�digo de la Preferencia arancelaria
	 * @param codi_part Partida
	 * @param codi_pais C�digo de Pa�s
	 * @param mcnaladisa Fecha de numeraci�n
	 * @param mtmargen Naladisa Tipo de Margen
	 * @param mpide_naladisa Si requiere naladisa
	 * @param mcnabandina Nabandina
	 * @param tienenalad Si tiene naladisa
	 * @param listError Lista de errores enviados por referencia
	 * @param dua objeto conteniendo los datos de cabecera de la dua
	 * @param serie objeto conteniendo los datos de una serie
	 * @param variablesIngreso Map<String,Object>
	 * @return boolean
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public Map<String,Object> verilib(String tipo_lib,String codi_libe,String codi_part,
				String codi_pais, String mcnaladisa,String mtmargen,
				String mpide_naladisa,String mcnabandina,boolean tienenalad,
				DUA dua, DatoSerie serie, 
			Map<String, Object> variablesIngreso, Date fechaReferencia
		         ) throws Exception 
		{
		/**if (mtmargen==null)*/
		/*RIN13-INSI*/	
		if (mtmargen==null || (mtmargen!=null && mtmargen.isEmpty())) { 
				mtmargen=" ";
			}
		/*RIN13-INSI*/		
			List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
			Boolean valido=true;
			boolean haycupo=false;
			Map<String, Object> params=new HashMap<String, Object>();
			// JCV 20091221 Para la grabaci�n posterior de los Cupos
			variablesIngreso.put("haycupo", false);
			List<HashMap> lstCupoTPI = new ArrayList();
			if (variablesIngreso.get("lstCupoTPI")!=null) {
				lstCupoTPI = (List<HashMap>)variablesIngreso.get("lstCupoTPI");
			}else{
				variablesIngreso.put("lstCupoTPI", lstCupoTPI);
			}
		
			HashMap mapCupoTPI = new HashMap();
			
			//fecha_nume
		Integer fecha_nume=SunatDateUtils.getIntegerFromDate(fechaReferencia)  ;
	        
			//gc_fech_ingsi: Fecha de numeraci�n de la Orden a procesar. (En este caso es la fecha de proceso)
		Integer gc_fech_ingsi=SunatDateUtils.getIntegerFromDate(fechaReferencia);

			//mfech_carc: fecha de Carta de cr�dito.
			DatoPago pago=dua.getPago();
			DatoPagoTrans trans=pago!=null?pago.getPagoTransaccion():null;
			Date feccarcr=trans!=null?trans.getFeccarcr():null;
			Integer mfech_carc =SunatDateUtils.getIntegerFromDate(feccarcr);
			
			//mfech_emba: fecha de embarque
			Integer mfech_emba= getDocTransporte(dua,serie)!=null?SunatDateUtils.getIntegerFromDate(getDocTransporte(dua,serie).getFecembarque()):0;
			
			//mfech_fact: es la m�xima fecha de factura que declara en la Informaci�n de Facturas
			int mfech_fact=0; 
			if(!CollectionUtils.isEmpty(dua.getListFacturaRef())){
				for(DatoFacturaref facRef:  dua.getListFacturaRef()){
				   int fecFactura=SunatDateUtils.getIntegerFromDate(facRef.getFecfactura());
				   if(fecFactura>mfech_fact) mfech_fact=fecFactura;
				}
			}
			
			//CONSISTENCIA EL CODIGO LIBERATORIO O TRATO PREFERENCIAL
			if( SunatStringUtils.include(codi_libe,new String[]{"057","058"}) 
					&& tipo_lib.equals(COD_TRATO_PREF_INTERNACIONAL) ){
				return respuesta(valido,listError);
			}
			
			if( SunatStringUtils.include(codi_libe,new String[]{"10","11","13","14"})    
				&& fecha_nume<19940519
				&& tipo_lib.equals(COD_TRATO_PREF_INTERNACIONAL)
				){
				return respuesta(valido,listError);
			}

			//Se consulta la vigencia de codi_libe y tipo_lib por fecha de numeracion, fecha de embarque y fecha de carta de credito
			Map<String,Object> rptaCodiLibe=consultarVigenciaCodiLibe(dua, serie, tipo_lib, codi_libe, fecha_nume, mfech_carc, mfech_emba, mfech_fact, codi_part, listError);
			if (rptaCodiLibe.get("respuesta")!=null)
				return (Map<String,Object>)rptaCodiLibe.get("respuesta");
	    	List<CodiLibe> lstCodlib=(List<CodiLibe>)rptaCodiLibe.get("lstCodlib");
	    	
			//De lo datos obtenidos de la tabla Codilibe se cargan las variables:
	    	Integer fini_lib=null;
	    	String ctra_lib=null;
	    	String torilib=null;
	    	CodiLibe ocodilibe=null;
		    if(!CollectionUtils.isEmpty(lstCodlib)){	
		    	 ocodilibe=(CodiLibe)lstCodlib.get(0);// deberia retornar 1 solo elemento
		    	 fini_lib=ocodilibe.getFinilib();
		    	 ctra_lib=ocodilibe.getCtralib();
		    	 torilib=ocodilibe.getTorilib();
		    }
			
			// *---  VERIFICA LA EXISTENCIA DEL DOC. DEL IMPORTADOR ---*		
			String[] arrCtratLi=null;
			arrCtratLi=new String[]{"3", "4", "C", "D"};
	    	if(StringUtils.hasText(ctra_lib) &&  Arrays.binarySearch(arrCtratLi, ctra_lib.trim())>=0){
	    		Map<String,Object> rptaTriblibe=consultarAsociacionTriblibe(dua,serie,tipo_lib,codi_libe,fecha_nume,codi_part,listError);
				if (rptaTriblibe.get("respuesta")!=null)
					return (Map<String,Object>)rptaTriblibe.get("respuesta");
		    	List<Triblibe> lstTriblibe=(List<Triblibe>)rptaTriblibe.get("lstTriblibe");	    		
	    	} // fin Si ctra_lib es alguna de las siguientes: "3", "4", "C", "D" 
	    	
	    	
	    	if(StringUtils.hasText(torilib) && torilib.trim().equals("P")){
//revisar
	  	consultarPaisOrigenOrilibe(tipo_lib,codi_libe,fecha_nume,codi_pais,listError);
			// captura error en listerror y continua validando
			//if (rptaOrilibe.get("respuesta")!=null)
			//	return (Map<String,Object>)rptaOrilibe.get("respuesta");
	    	}
	    	
	    	if(StringUtils.hasText(ctra_lib) &&  ctra_lib.trim().equals("B")){
	    		// 	*--- PRIMERO SE VERIFICA SI ESTA EN LA LISTA DE EXCEPCIONES ---*
	    		Map<String,Object> rptaExcodlib=consultarExcepcionExcodlib(tipo_lib,codi_libe,fecha_nume,codi_part,ctra_lib,serie,listError);
	    		if (rptaExcodlib.get("respuesta")!=null)
					return (Map<String,Object>)rptaExcodlib.get("respuesta");
	    	}
        	// rpumacayo pase70
	    	//catalogoAyudaService = fabricaDeServicios.getService( "Ayuda.catalogoAyudaServicePrincipal");
        	// rpumacayo pase70
	    	// * VERIFICACION CONTRATOS DE EST.TRIBUTARIA
	    	arrCtratLi=new String[]{"2", "4", "8", "D", "E"};
	    	
	    	// Si ctra_lib es alguno de estos "2", "4", "8", "D", "E"  entonces:
	    	if(StringUtils.hasText(ctra_lib) && Arrays.binarySearch(arrCtratLi, ctra_lib.trim())>=0){
	    		// Si ctra_lib<>"E" entonces:
	    		List<Map<String,Object>> onandlibe=null;
	    		onandlibe=findOnandlibe(ctra_lib,tipo_lib,codi_libe,serie,mtmargen,fecha_nume);
	    		String Coderr = null;
	    		if(CollectionUtils.isEmpty(onandlibe)){
		            	 if(!ctra_lib.trim().equals("8") && !ctra_lib.trim().equals("D") 
		            			 && !ctra_lib.trim().equals("E") 
		            			 && !ctra_lib.trim().equals("C") ){
		            		if(tipo_lib.equals(COD_LIBERATORIO)){
		            			if("4459".equals(serie.getCodliberatorio().toString())){
		        					if(!"9806000000".equals(serie.getNumpartnandi().toString())) {
		        						//grabaTelelog(listError,"30656",new Object[]{serie.getNumserie()});
		        						Coderr = "30656";
		        					}		
		        				}
		            			else{
		            			Coderr = "00106";}
		            			}
		                	else 
		                		if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {Coderr = "00110";}
		                	else{
		                		Coderr = "00114"; 
		                		}


		    				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Coderr, new String[]{serie.getNumserie().toString(), codi_part.toString(), codi_libe.toString()}));
		    				return respuesta(false,listError);
		            	 }  // fin Si ctra_lib <>"8"  AND  ctra_lib <>"D" AND ctra_lib <>"E" ;
				           else {
				            		 // Si ctra_lib es  "D" o "E" entonces:
				        	    if(ctra_lib.trim().equals("D") || ctra_lib.trim().equals("E") ){	
				            		 //*--- SE BUSCA EXCEPCIONES ---*
				            		 // Se verifica en la tabla EXCODLIB:
				            		 // Sql = "Select texc from excodlib where clib ='"+codi_libe+"' and  finilib ="+fini_lib
				            		params=new HashMap<String, Object>();
				      				params.put("clib", codi_libe);
				      				params.put("finilib",fini_lib);	
				            		//List<ExCodLib> lstCod= FormatoAServiceImpl.getInstance().getExcodlibDAO().findExcepCodLibeByParams(params);
				            		List<ExCodLib> lstCod= ((ExCodLibDAO)fabricaDeServicios.getService("excodlibDAO")).findExcepCodLibeByParams(params);
				            		 // 					Si encuentra informaci�n entonces se rechaza:
				            		if(!CollectionUtils.isEmpty(lstCod)){
				                         ExCodLib excodlib=lstCod.get(0);
				                         String texc=excodlib.getTexc();
				                		params=new HashMap<String, Object>();
				          				params.put("texc", texc);
				          				params.put("cnan",codi_part);	
				                		//List<ExNanLib> lstNanLib= FormatoAServiceImpl.getInstance().getExnanlibDAO().findExNanLibByParams(params);
				                		List<ExNanLib> lstNanLib= ((ExNanLibDAO)fabricaDeServicios.getService("exnanlibDAO")).findExNanLibByParams(params);
				                        
				                		// Si encuentra informaci�n entonces se rechaza:
				                		if(!CollectionUtils.isEmpty(lstNanLib)){
				                			 grabaTelelog(listError, Coderr, new Object[] { serie.getNumserie(), codi_part, codi_libe });			            				
				            				return respuesta(false,listError);                			
				                		}
				            		}// fin encuentra excodlib
				        	    } // Si ctra_lib es  "D" o "E" entonces:
				        	    
		
				            	 // Si ctra_lib es diferente a "E" entonces
				            	 if(!ctra_lib.trim().equals("E")){
				            		 // Se verifica en la tabla NANDLIBE:
				             		params=new HashMap<String, Object>();
				      				params.put("tlib", tipo_lib);
				      				params.put("clib",codi_libe);
				      				params.put("finilib",fecha_nume);
				      				params.put("cnan",0);
				            		 //List<NandLibe> lstNandLibe= FormatoAServiceImpl.getInstance().getNandlibeDAO().findNandLibeByParams(params);
				            		 List<NandLibe> lstNandLibe= ((NandlibeDAO)fabricaDeServicios.getService("nandlibeDAO")).findNandLibeByParams(params);
				            		 if(!CollectionUtils.isEmpty(lstNandLibe)){
											// Se ejecuta Sql y se almacena en una Tabla Temporal onandlibe
											onandlibe=new ArrayList<Map<String,Object>>();
											for(NandLibe nlib:lstNandLibe){
												Map<String,Object> mp=new HashMap<String, Object>();
												mp.put("tlib", nlib.getTlib());
												mp.put("ffinlib", nlib.getFfinlib());
												mp.put("fnummax", nlib.getFnummax());
												mp.put("tmargen", nlib.getTmargen());
												onandlibe.add(mp);
											}
				            		 }
				            	 }
				            	 else{
				              		params=new HashMap<String, Object>();
				      				params.put("tlib", tipo_lib);
				      				params.put("clib",codi_libe);
				      				params.put("finilib",fecha_nume);
				      				params.put("cnan",0);
				            		//List<Nandi110> lstNand110=  FormatoAServiceImpl.getInstance().getNandi110DAO().findNandi110ByParams(params);
				      				List<Nandi110> lstNand110= ((Nandi110DAO)fabricaDeServicios.getService("nandi110DAO")).findNandi110ByParams(params);
				            		
									if(!CollectionUtils.isEmpty(lstNand110)) 
									 {// Se ejecuta Sql y se almacena en una Tabla Temporal onandlibe
										onandlibe=new ArrayList<Map<String,Object>>();
										for(Nandi110 n110:lstNand110){
											Map<String,Object> mp=new HashMap<String, Object>();
											mp.put("tlib", n110.getTlib());
											onandlibe.add(mp);
										}
									 }
				            	 }
				            	 // Se ejecuta Sql y se almacena en una Tabla Temporal onandlibe
				            	 // si no encuentra se rechza
				            	 if(CollectionUtils.isEmpty(onandlibe)){
				                   Coderr =null;
				                	if(tipo_lib.equals(COD_LIBERATORIO)){Coderr = "00106";}
				                	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
				                		Coderr = "00110";	}
				                	else{Coderr = "00114";}
				    				
				    				//grabaTelelog(listError,"30376",new Object[]{"**",codi_part,codi_libe,ctra_lib," "});
				                	// rpumacayo pase70
				    				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Coderr, new String[]{serie.getNumserie().toString(), codi_part, codi_libe.toString()}));
				    				// rpumacayo pase70
				    				return respuesta(false,listError);                			
				            	 }		        	    
				           } // fin else // fin Si ctra_lib <>"8"  AND  ctra_lib <>"D" AND ctra_lib <>"E" ;
		             } // fin onandlibe esta vacio

	             String[] arrCtrl=new String[]{"8","C", "D", "E" };
	         	 //Si ctra_lib no es ninguno de estos: "8", "D", "E", "C" 
	             if(Arrays.binarySearch(arrCtrl, ctra_lib.trim())<0 ){
	            	// Por cada registro de la tabla temporal onandlibe se realiza lo siguiente:
	            	 boolean salido=false;
	            	 if(!CollectionUtils.isEmpty(onandlibe)){
		            	 for(Map<String, Object> onandl:onandlibe ){
		            		 if( ((Integer)onandl.get("ffinlib"))>= gc_fech_ingsi 
		            				 && SunatStringUtils.isEqualTo((String)onandl.get("tmargen"),mtmargen) ){
		            			 salido=true;
		            			 break;
		            		 }
		            		 int fechTmp=0;
		            		 if (mfech_carc==null || "0".equals(mfech_carc.toString()) ){
		            			 fechTmp=mfech_emba;
		            		 }else{
		            			 fechTmp=mfech_carc;
		            		 }
		            		 if( ((Integer)onandl.get("fnummax" ) )>=gc_fech_ingsi  
		            			  && ((Integer)onandl.get("ffinlib"))>= Collections.min(Arrays.asList(new Integer[]{fechTmp, mfech_emba,mfech_fact}) )
		            			  && onandl.get("tmargen").equals(mtmargen)
		            		    ){
		            			 salido=true;
		            			 break;
		            		 }
		            	 }
	            	 }	 
	            	 // Si llega al fin de la tabla temporal onandlibe sin haber salido del barrido entonces se rechaza:
	            	 if(!salido){
		                  	Coderr =null;
		                	if(tipo_lib.equals(COD_LIBERATORIO))
		                		Coderr = "00106";
		                	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) 
		                		Coderr = "00110";
		                	else
		                		Coderr = "00114";
		                	grabaTelelog(listError,Coderr,new Object[]{serie.getNumserie(), codi_part, codi_libe });
		                	//grabaTelelog(listError,"30376",new Object[]{"***",codi_part,codi_libe,ctra_lib," "});
		    				return respuesta(false,listError);                			
	            	 }
	             }
	    	} // Si ctra_lib es alguno de estos "2", "4", "8", "D", "E"  entonces:	
	    	

	    	
	    	// Si codi_libe= " 504" entonces:
	    	if(StringUtils.hasText(codi_libe) &&  codi_libe.trim().equals("504")){
	    		Map<String,Object> mp=null;
	    		//Si tienenalad entonces:
	    		if( mcnaladisa!=null && tienenalad){
	    			mp=new HashMap<String, Object>();
					mp.put("tlib", tipo_lib);
					mp.put("clib", codi_libe);
					mp.put("tmargen", mtmargen);
					mp.put("cnaladisa", mcnaladisa );
					mp.put("cnan", codi_part );
					mp.put("fecvigencia", fecha_nume );
	    		}
	    		else{
	    			mp=new HashMap<String, Object>();
					mp.put("tlib", tipo_lib);
					mp.put("clib", codi_libe);
					mp.put("cnan", codi_part );
					mp.put("fecvigencia", fecha_nume );
	    		}
				//List<Aladi504> lstAlad504= FormatoAServiceImpl.getInstance().getAladi504DAO().findAladi504ByParams(mp);
				List<Aladi504> lstAlad504= ((Aladi504DAO)fabricaDeServicios.getService("aladi504DAO")).findAladi504ByParams(mp);

				
				/*Se ejecuta Sql y se almacena en una Tabla temporal oaladi504.	Si no encontr� informaci�n entonces:*/
				
				if(CollectionUtils.isEmpty(lstAlad504)){
					//jenciso R441.c Si subpartida no vigente en tabla de TPI y no envia tipo de margen se acepta envio
					if(!SunatStringUtils.isEmptyTrim(mtmargen)){
				 if(!tienenalad){
					// A solicitud de normativa se debe validar tambien con el tipo de margen si lo envio
		    			mp=new HashMap<String, Object>();
						mp.put("tlib", tipo_lib);
						mp.put("clib", codi_libe);
						mp.put("cpaiorige", codi_pais);
						mp.put("cnaladisa", 0 );
						mp.put("cnan", 0 );
						mp.put("fecvigencia", gc_fech_ingsi );
					        mp.put("tmargen", mtmargen);
					 
					 	//int cntAladile= FormatoAServiceImpl.getInstance().getAladlibeDAO().count(mp);
					 	int cntAladile= ((AladlibeDAO)fabricaDeServicios.getService("aladlibeDAO")).count(mp);
					 	// Si no encuentra regsitros entonces rechaza:
					 	if(cntAladile==0){
						//grabaTelelog(listError,"30377",new Object[]{codi_part,tipo_lib,codi_libe,codi_pais}	);
						grabaTelelog(listError,"30401",new Object[]{SunatStringUtils.toNotNull(mcnaladisa),codi_libe,codi_pais,mtmargen, codi_part, serie.getNumserie()});
		    				return respuesta(false,listError);
					 	}
					 	return respuesta(false,listError);
				 }	
				 else{
					//grabaTelelog(listError,"30377",new Object[]{codi_part,tipo_lib,codi_libe,codi_pais}	);
					grabaTelelog(listError,"30401",new Object[]{SunatStringUtils.toNotNull(mcnaladisa),codi_libe,codi_pais,mtmargen, codi_part, serie.getNumserie()});
			 		return respuesta(false,listError);
				 }
			}
				}
			else{
					//jenciso R441.a Si encontro registros y tipo de margen no se envio o es vacio se rechaza
					if(SunatStringUtils.isEmptyTrim(mtmargen)){
						grabaTelelog(listError,"30401",new Object[]{SunatStringUtils.toNotNull(mcnaladisa),codi_libe,codi_pais,mtmargen, codi_part, serie.getNumserie()});
				 		return respuesta(false,listError);
					}
				// Si !tienenalad entonces:
				if(!tienenalad ){
					/*Se busca en la tabla temporal oaladi504 si alguno cumple la condici�n tmargen= mtmargen */
					//String tmargen=null;
					boolean encontrado=false;
					if(!CollectionUtils.isEmpty(lstAlad504)){
						for(Aladi504 alad504 : lstAlad504){
							if(alad504.getTmargen().equals(mtmargen )){
								encontrado=true;
								//tmargen=alad504.getTmargen();
								break;
							}
						}
					}
					// Si encuentra y  tmargen<>'2' o no encuntra entonces rechaza:
					// esto solo debe quedar como si no encontro
					//if( (encontrado && !tmargen.equals("2"))
					//		|| !encontrado
					//		){
						//grabaTelelog(listError,"30377",new Object[]{codi_part,tipo_lib,codi_libe,codi_pais}	);
					if (!encontrado){
						grabaTelelog(listError,"30401",new Object[]{SunatStringUtils.toNotNull(mcnaladisa),codi_libe,codi_pais,mtmargen, codi_part, serie.getNumserie()});
				 		return respuesta(false,listError);
					}
				}
			   }	
				return respuesta(true,listError);
	    	} // fin si Si codi_libe= " 504" entonces:


	    	
	    	
	// Si ctra_lib es alguno de estos:  "5", "6", "7", "G" entonces:
	    	String[] arrLib=new String[]{"5", "6", "7", "G"};
	    	if(StringUtils.hasText(ctra_lib) && Arrays.binarySearch(arrLib, ctra_lib.trim())>=0){
	    		// Si !(tipo_lib = 'I' AND codi_libe = '802')
	           //if(!(tipo_lib.equals("I") && codi_libe.trim().equals("802") )){
	    		// No se exige Naladisa para los TPI 802,803,804,805 (catalogo 1L)
                        
                        //if (!codi_libe.trim().equals("229")) //DZC
                        //PAS20134E610000337: Se incluyo TPI 229 en L1

	    		//if(!(tipo_lib.equals("I") && FormatoAServiceImpl.getInstance().isValidCatalogo("1L", codi_libe.trim()))){
	    		boolean validaCatalogo= CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_TPI_SINNALADISA, codi_libe.toString(),SunatDateUtils.getCurrentDate())); 
	    		if(!(tipo_lib.equals("I") && validaCatalogo)){
	        	   // * Se debe pedir la partida naladisa y el tipo de producto
	        	   // Si ES_VACIO(mcnaladisa) entonces se rechaza:
	        	   if(!StringUtils.hasText(mcnaladisa)){
	        		   grabaTelelog(listError,"0047",
	        				   "No env�o Naladisa");
	        		   return respuesta(false,listError);
	        	   }
	           }
	           // 	Si ctra_lib = "7" entonces:
	           if(ctra_lib.trim().equals("7")){
	        	   codi_part = " ";
	           }
	           // 	clave = tipo_lib + codi_libe + codi_pais + mtmargen
	           
	           // 	Si codi_pais es alguno de estos:  "CO", "VE", "EC" AND codi_libe=' 120' entonces: 
	           String[] arrPais=new String[]{"CO", "VE", "EC"};
	  			Map<String,Object> mp=new HashMap<String, Object>();
				mp.put("tlib", tipo_lib);
				mp.put("clib", codi_libe);
				mp.put("cpai", codi_pais);
				mp.put("tmargen", mtmargen );
				mp.put("cnaladisa", mcnaladisa );
				mp.put("cnan", codi_part );
				mp.put("fecvigencia", gc_fech_ingsi );
				List<Map<String, Object>> oaladlibe=null;
	           if(Arrays.binarySearch(arrPais, codi_pais)>=0
			        		   && codi_libe.trim().equals("120")){
			        	   /*Sql = "select b.tlib, b.tienecup from orilibe a, Aladlibe b 
			        	    * where a.tlib='"+tipo_lib+"' and a.clib='"+ codi_libe+ "' 
			        	    * and a.cpai='"+ codi_pais+"' and b.tlib = a.tlib 
			        	    * and b.clib = a.clib and b.tmargen= '"+ mtmargen+"' 
			        	    * and b.cnaladisa="+ mcnaladisa+ " and b.cnan="+codi_part+" 
			        	    * and b.finilib <= "+ gc_fech_ingsi + " and b.ffinlib >= "+ gc_fech_ingsi*/
		            //List<Map<String,Object>> lstTlibCupo=  FormatoAServiceImpl.getInstance().getAladlibeDAO().findCupoTratoLibByParams(mp);
		            List<Map<String,Object>> lstTlibCupo=  ((AladlibeDAO)fabricaDeServicios.getService("aladlibeDAO")).findCupoTratoLibByParams(mp);
		            if(!CollectionUtils.isEmpty(lstTlibCupo)){
		            	oaladlibe=lstTlibCupo;
		            }
			       }
	           else{
	        	   // para resolver el bug  Bug 3518 - PAS20112A600000459 - Numeracion con tpi 338 y pais colombia ..
	        	   mp.put("cpaiorige", codi_pais);
	        	   /*branch ingreso 2011-009 hosorio 05/07/2011 fin */
	        	    //List<AladLibe> lstAladl =FormatoAServiceImpl.getInstance().getAladlibeDAO().findAladLibeByParams(mp);
	        	    List<AladLibe> lstAladl =((AladlibeDAO)fabricaDeServicios.getService("aladlibeDAO")).findAladLibeByParams(mp);
	        	    if(!CollectionUtils.isEmpty(lstAladl)){
	        	    	oaladlibe=new ArrayList<Map<String,Object>>();
		        	    for(AladLibe ald:lstAladl){
		        	    	Map<String,Object> mAlLib=new HashMap<String, Object>();
		        	    	mAlLib.put("tlib", ald.getTlib());
		        	    	mAlLib.put("tienecup", ald.getTienecup());
		        	    	oaladlibe.add(mAlLib);
		        	    }
	        	    }
	           }
	    		/*Se ejecuta Sql y se almacena en una Tabla temporal oaladlibe.	Si no encuentra informaci�n entonces se rechaza:*/
	           
	           if(CollectionUtils.isEmpty(oaladlibe)){
				// Se verifica si todo el arancel esta negociado
				SubPartidaNacionalTratoPreferencialService subPartidaNacionalTratoPreferencialService = fabricaDeServicios.getService("subPartidaNacionalTratoPreferencialService");
				List<AladLibe> lstAladl = subPartidaNacionalTratoPreferencialService.validaVigenciaSubPartidaTodoArancel(serie, fechaReferencia);
				if (CollectionUtils.isEmpty(lstAladl)){
	        	   //jenciso R482 subpartida no vigente en tabla de TPI 100, no debe enviar tipo de margen
	        	   if(tipo_lib.equals("I") && SunatStringUtils.trim(codi_libe).equals("100") ){
	        		   
	        		   if(!SunatStringUtils.isEmptyTrim(mtmargen) && existePartidaVigenteNandTasa(serie.getNumpartnandi(),fechaReferencia,serie.getCodtnan())){
	        			   grabaTelelog(listError,"30901",new Object[]{serie.getNumserie(), codi_part,codi_libe });
	        			   return respuesta(false,listError);
	        		   }
	        	   }else{
	        	   String cerror = null;  
	        	   
	        	   //DZC ini TPI 229 Error: PARTIDA NO SE ENCUENTRA NEGOCIADA
	        	   if(tipo_lib.equals("I") && SunatStringUtils.trim(codi_libe).equals("229") ){
	        		   cerror="30401";//8813
	        	   }
	        	   //DZC fin
	        	   
	        	   if(tipo_lib.equals("I") && SunatStringUtils.trim(codi_libe).equals("802") ){
	        		   cerror="30401";//8813
	        	   }
	        	   else{
	        		   cerror="30401";//0047
	        	   }
				mcnaladisa = mcnaladisa== null?"0000.00.00":mcnaladisa;
	    		   //grabaTelelog(listError,cerror,new Object[]{mcnaladisa,tipo_lib,codi_libe,codi_pais,mtmargen});
	    		   listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(cerror, new String[]{
                                             mcnaladisa, codi_libe.toString(),codi_pais,mtmargen,codi_part,serie.getNumserie().toString()}));
	    		   
	    		   //mtmargen   = " ";
	    		   return respuesta(false,listError);
	        	   }
	        	   
				} else {
					oaladlibe=new ArrayList<Map<String,Object>>();
					for(AladLibe ald:lstAladl){
						Map<String,Object> mAlLib=new HashMap<String, Object>();
						mAlLib.put("tlib", ald.getTlib());
						mAlLib.put("tienecup", ald.getTienecup());
						oaladlibe.add(mAlLib);
					}
				}
	    		   	
	           }
	           
	           //*--- verificamos cupo ---*
	           //	Si oaladlibe.tienecup = "S" entonces:
	           Map<String,Object> mpAlad= CollectionUtils.isEmpty(oaladlibe)? null : oaladlibe.get(0);// jenciso RIN05, para TPI 100 no tiene aladlibe no se evalua
	           
	           if(mpAlad !=null && "S".equals(mpAlad.get("tienecup"))){		
	        	   
	        	   // Revisar
	        	    String mtribut = dua.getDeclarante().getNumeroDocumentoIdentidad();
	     			mp=new HashMap<String, Object>();
	    			mp.put("tlib", tipo_lib);
	    			mp.put("clib", codi_libe);
	    			mp.put("cnaladisa", mcnaladisa );
	    			mp.put("cnan", codi_part );
	    			mp.put("cnumdoc", mtribut );
	    			mp.put("fecvigencia", gc_fech_ingsi );
	    			//List<CupoTpi> lstCupo= FormatoAServiceImpl.getInstance().getCupoTpiDAO().findCupoTpiByParams(mp);
	    			List<CupoTpi> lstCupo= ((CupotpiDAO)fabricaDeServicios.getService("cupoTpiDAO")).findCupoTpiByParams(mp);
	    			if(CollectionUtils.isEmpty(lstCupo)){
	    				// Sql = "select * from cupotpi where tlib='"+tipo_lib+"' and clib='"+ codi_libe+ "' and cnan="+ codi_part+" and naladisa="+mcnaladisa+" and finicup<="+gc_fech_ingsi +" and ffincup>="+ gc_fech_ingsi
	         			mp=new HashMap<String, Object>();
	        			mp.put("tlib", tipo_lib);
	        			mp.put("clib", codi_libe);
	        			mp.put("cnaladisa", mcnaladisa );
	        			mp.put("cnan", codi_part );
	        			mp.put("fecvigencia", gc_fech_ingsi ); 
	        			//lstCupo= FormatoAServiceImpl.getInstance().getCupoTpiDAO().findCupoTpiByParams(mp);
	        			lstCupo= ((CupotpiDAO)fabricaDeServicios.getService("cupoTpiDAO")).findCupoTpiByParams(mp);
	        			if(CollectionUtils.isEmpty(lstCupo)){
	        				
	    	 				grabaTelelog(listError,"1003",
	    	 						mcnaladisa+", T.Lib: "+tipo_lib+", C.Lib: "+codi_libe+", Pais: "+codi_pais+", Margen: "+mtmargen);
	    	 				return respuesta(false,listError);
	        				
	        			}
	    				
	    			}
	    		  CupoTpi cupTpi = lstCupo.get(0);
	    		  if (SunatStringUtils.isEmpty(cupTpi.getCnumdoc().trim())) {
	    			  mtribut = "";
	    		  }
	    			//Si codcupo = "01" entonces:
	    		  BigDecimal variable = null;
	    		  if(cupTpi.getCodcupo().equals("01")){
	    			  // variable = SERIES.peso_neto
	    			   variable = serie.getCntpesoneto();
	    		  }
	    		  else if(cupTpi.getCodcupo().equals("02")){
	    			  // variable = SERIES.fob_dolpol
	    			  variable = serie.getMtofobdol();
	    		  }
	    		  
	    		  mapCupoTPI.put("tipo_lib", tipo_lib);
	    		  mapCupoTPI.put("codi_libe", codi_libe);
	    		  mapCupoTPI.put("codi_part", codi_part);
	    		  mapCupoTPI.put("mcnaladisa", mcnaladisa);
	    		  mapCupoTPI.put("mtribut", mtribut);
	    		  mapCupoTPI.put("variable", variable);
	    		  lstCupoTPI.add(mapCupoTPI);
	    		  variablesIngreso.put("lstCupoTPI", lstCupoTPI);
	    		  
	    		  
	    		  
	    		  // En base a la informaci�n optenida de la tabla cupotpi se verifica que:
	    		  //Si cupo=cant_uti  OR  cupo < cant_uti + variable entonces se rechaza:
	    		 BigDecimal total=SunatNumberUtils.sum(cupTpi.getCantUti(), variable);
	    		 
	    		  if( SunatNumberUtils.isEqual(cupTpi.getCupo(), cupTpi.getCantUti())  
	    			 ||  SunatNumberUtils.isLessThanParam(cupTpi.getCupo(), total))
	    		  {
	    			  
		 				grabaTelelog(listError,"1004",
		 						"Cupo Tot: "+cupTpi.getCupo()+", Cupo Sol: "+cupTpi.getCantUti()+", Cupo Dec: "+variable);
		 				return respuesta(false,listError);
	    		  }  
	    		  haycupo = true;
	    		  variablesIngreso.put("haycupo", haycupo);
	           }
	    		    		
	    		return respuesta(true,listError);
	    	} // Fin // Si ctra_lib es alguno de estos:  "5", "6", "7", "G" entonces:

	    	
	    	String maduana =dua.getCodaduanaorden();
	    	if(StringUtils.hasText(ctra_lib) && (ctra_lib.trim().equals("9") || ctra_lib.trim().equals("F"))){
	    		// *--- verificamos naladisa y tipo margen ---*
	    		//Si ES_VACIO(mcnabandina) entonces se rechaza:
	    		if(mcnabandina==null){
	    			
//	        			listError.add(ResponseMapManager.getErrorResponseMap("0047",
//	 						"No envi� Nabandina "));
	    			
	    			
	 				grabaTelelog(listError,"0047",
	 						"No envi� Nabandina ");
	 				return respuesta(false,listError);
	    		}
	    		// Si codi_libe es uno de estos: "  34", "  35", "  36"  entonces:
	    		String[] arraCodLib=new String[]{"34", "35", "36"};
	    		if(Arrays.binarySearch(arraCodLib, codi_libe.trim())>=0){
	    			//Si maduana no es ninguna de estas: "046", "118", "235" entonces:
	    			String[] arraAdua=new String[]{"046", "118", "235"};
	    			
	    			if(Arrays.binarySearch(arraAdua, maduana)<0){
	    				grabaTelelog(listError,"30378",new Object[]{codi_libe});

	    				return respuesta(false,listError);
	    			}
	    		}
	    		
	    		//mcnabandina = SERIES.part_naban
	    		String codopadutra=dua.getOtraAduana()!=null?dua.getOtraAduana().getCodopadutra():null;
	    		String xcodi_libe=null;
	    		//Si codi_libe es uno de estos: "  34", "  35", "  36"  OR  (codi_libe='  33' AND tipo_lib='I') entonces:
	    		if(Arrays.binarySearch(arraCodLib, codi_libe.trim())>=0
	    				|| (codi_libe.trim().equals("33") && tipo_lib.equals("I") )
	    		){
	    			xcodi_libe = "32";
	    		}
	    		else{
	    			xcodi_libe = codi_libe;
	    		}
	    		String xaduana= null;
	    		xaduana= maduana;
	    		
	    		if(codi_libe.trim().equals("34")){
	    			xaduana="226";
	    		}
	    		else if(codi_libe.trim().equals("35")){	
	    			xaduana="217";	
	    		}
	    		else if(codi_libe.trim().equals("36")){	
	    			xaduana="271";	
	    		}
	    		else if(codi_libe.equals("4438")){
	    			// Revisar
	    			//xaduana=CABECERA.cadutrasal
	    			xaduana=codopadutra;
	    		}
	    		
	    		boolean lsPecoOld = false; 
	    		
	    		
	    		params=new HashMap<String, Object>();
	    		params.put("tlib", tipo_lib);
	    		params.put("clib", xcodi_libe);
	    		params.put("cadu", xaduana);
	    		params.put("cnab", mcnabandina);
	    		params.put("fecvigencia", gc_fech_ingsi);
	    		//List<Adulibe> lstAud= FormatoAServiceImpl.getInstance().getAdulibeDAO().findAdulibeByParams(params);
	    		List<Adulibe> lstAud= ((AdulibeDAO)fabricaDeServicios.getService("adulibeDAO")).findAdulibeByParams(params);
	    		// Si no encuentra informaci�n y lsPecoOld entonces:
	    		
	    		if(CollectionUtils.isEmpty(lstAud) && lsPecoOld ){
	        		params.put("fecvigencia", mfech_carc);

	        		//lstAud= FormatoAServiceImpl.getInstance().getAdulibeDAO().findAdulibeByParams(params);
	        		lstAud= ((AdulibeDAO)fabricaDeServicios.getService("adulibeDAO")).findAdulibeByParams(params);
	        		
	        		if(CollectionUtils.isEmpty(lstAud)){
	            		params.put("fecvigencia", mfech_emba);
	            		//lstAud= FormatoAServiceImpl.getInstance().getAdulibeDAO().findAdulibeByParams(params);
	            		lstAud= ((AdulibeDAO)fabricaDeServicios.getService("adulibeDAO")).findAdulibeByParams(params);
	        		}
	    		}
	    		
	    		// Si no ha encontrado informaci�n en estas consultas sobre la tabla ADULIBE entonces:
	    		if(CollectionUtils.isEmpty(lstAud)){
	        		params=new HashMap<String, Object>();
	        		params.put("tlib", tipo_lib);
	        		params.put("clib", xcodi_libe);
	        		params.put("cadu", xaduana);
	        		params.put("cnab", mcnabandina);
	        		params.put("fecvigencia", gc_fech_ingsi);
	    			//List<Adualib> lstAdua=  FormatoAServiceImpl.getInstance().getAdualibDAO().findAdualibByParams(params);
	    			List<Adualib> lstAdua=  ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).findAdualibByParams(params);
	    			/*Sql = "select vigv from Adualib where tlib='"+ tipo_lib+"' 
	    			 * and clib='"+ xcodi_libe+ "' and cadu='"+ xaduana+ "' 
	    			 * and cnab="+ mcnabandina+ " 
	    			 * and finilib <= "+ gc_fech_ingsi + " and ffinlib >= "+ gc_fech_ingsi*/
	    			if(CollectionUtils.isEmpty(lstAdua) && 	lsPecoOld  ){
	    				params.put("fecvigencia", mfech_carc);
	    				//lstAdua=  FormatoAServiceImpl.getInstance().getAdualibDAO().findAdualibByParams(params);
	    				lstAdua=  ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).findAdualibByParams(params);
	    				
	    				if(CollectionUtils.isEmpty(lstAdua)){
	    					params.put("fecvigencia", mfech_emba);
	    					//lstAdua=  FormatoAServiceImpl.getInstance().getAdualibDAO().findAdualibByParams(params);
	    					lstAdua=  ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).findAdualibByParams(params);
	    				}
	    			}
	    			
	    			if(!CollectionUtils.isEmpty(lstAdua)){
	    				// Si vigv es diferente a 0  AND  codi_libe="  33" entonces:
	    				Adualib aduali= lstAdua.get(0);
	    				 if(!aduali.getVigv().equals("0") && codi_libe.trim().equals("33")){
	    					 return respuesta(false,listError);
	    				 }
	    			}
	    			else{
	    			
	                 	String Coderr =null;
	                	if(tipo_lib.equals(COD_LIBERATORIO))
	                		Coderr = "00106";
	                	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) 
	                		Coderr = "00110";	
	                	else 
	                		Coderr = "00114";
	                	/* MATC 20131030
	                	 * Se construye el array para pasar como tercer par�metro a grabaTelelog()
	                	 */
	                	grabaTelelog(listError, Coderr, new Object[]{serie.getNumserie(), serie.getNumpartnandi().toString(), codi_libe });
	    				return respuesta(false,listError);                			
	    			}
	    		}
	    		else{
	    			// En base al Query que se ejecuta antes de estos se verifica que:
	    		   Adulibe adualibe=lstAud.get(0);
	    		   // 		Si vigv es diferente de 0  y  codi_libe="  33" entonces:
	    		   if(!adualibe.getVigv().equals("0") && codi_libe.trim().equals("33")){
	    			   mcnabandina = "0000.00.00.00";
						return respuesta(false,listError);
	    		   }
	    		}
	    		return respuesta(true,listError);
	    	}
			return respuesta(true,listError);
		}	

	/**
	 * Consultar vigencia codi libe.
	 * 
	 * @param dua DUA
	 * @param serie DatoSerie
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param fecha_nume Integer
	 * @param mfech_carc Integer
	 * @param mfech_emba Integer
	 * @param mfech_fact Integer
	 * @param codi_part String
	 * @param listError List<Map<String,String>>
	 * @return el mapa de errores
	 */
	private Map<String,Object> consultarVigenciaCodiLibe(DUA dua, DatoSerie serie, String tipo_lib, String codi_libe, Integer fecha_nume, Integer mfech_carc, Integer mfech_emba, Integer mfech_fact, String codi_part, List<Map<String,String>> listError){
        CodiLibe ocodilibe=null;
        Map<String,Object> respuesta=null;

		//Sql = "select finilib, ffinlib, ctralib, torilib from codilibe where tlib='"+ tipo_lib+ "' and clib= '"+;
		//codi_libe+ "' and finilib <= "+ A_CADENA(fecha_nume,8)+" and ffinlib >= "+ A_CADENA(fecha_nume,8)+ " order by finilib"
		//List<CodiLibe> lstCodlib= findCodilibe(tipo_lib,codi_libe,fecha_nume);
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		List<CodiLibe> lstCodlib =  preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipo_lib, SunatNumberUtils.toInteger(codi_libe), SunatDateUtils.getDateFromInteger(fecha_nume));
        // si no encuentra codilibe
    	if(CollectionUtils.isEmpty(lstCodlib) ){
			//TabLibe otablibe=findTabLibe(tipo_lib,codi_libe);
			TabLibe otablibe=preferenciaArancelariaService.obtenerPreferenciaArancelaria(tipo_lib, SunatNumberUtils.toInteger(codi_libe));    		
			// rpumacayo pase70
    		//catalogoAyudaService = fabricaDeServicios.getService( "Ayuda.catalogoAyudaServicePrincipal");
    		// rpumacayo pase70
    		if(otablibe!=null){
				//String tviglib=otablibe.getTviglib();
		    	// 		Si otablibe.tviglib= "1"
		    	if(otablibe.getTviglib().equals("1")){
		    		// Se verifica nuevamente en la Tabla CODILIBE:
		    		//mfech_emba: fecha de embarque
					//lstCodlib= findCodilibe(tipo_lib,codi_libe,mfech_emba);
					lstCodlib= preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipo_lib, SunatNumberUtils.toInteger(codi_libe), SunatDateUtils.getDateFromInteger(mfech_emba));
		            if(!CollectionUtils.isEmpty(lstCodlib)){ 
		            	 ocodilibe=lstCodlib.get(0);
		            }
		            if(ocodilibe!=null){
		            	fecha_nume=ocodilibe.getFfinlib();
		            }
		            else{
		            	//mfech_fact: es la m�xima fecha de factura que declara en la Informaci�n de Facturas
						//lstCodlib= findCodilibe(tipo_lib,codi_libe,mfech_fact);
						lstCodlib= preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipo_lib, SunatNumberUtils.toInteger(codi_libe), SunatDateUtils.getDateFromInteger(mfech_fact));
			            if(!CollectionUtils.isEmpty(lstCodlib)){ 
			            	 ocodilibe=lstCodlib.get(0);
			            }
			            if(ocodilibe!=null){
			            	fecha_nume=ocodilibe.getFfinlib();
			            }
			            else{
			            	//mfech_carc: fecha de Carta de cr�dito.
							//lstCodlib= findCodilibe(tipo_lib,codi_libe,mfech_carc);
							lstCodlib= preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipo_lib, SunatNumberUtils.toInteger(codi_libe), SunatDateUtils.getDateFromInteger(mfech_carc));
				            if(!CollectionUtils.isEmpty(lstCodlib)){ 
				            	 ocodilibe=lstCodlib.get(0);
				            }
				            if(ocodilibe!=null){
				            	fecha_nume=ocodilibe.getFfinlib();
				            }
				            else{
				            	String Coderr =null;
				            	if(tipo_lib.equals(COD_LIBERATORIO)){
				            		Coderr="00104";
				            	}
				            	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
				            		Coderr="00108";
				            	}
				            	else Coderr="00112";
				            	//grabaTelelog(listError,Coderr,new Object[]{codi_part,serie.getNumserie()});
				            	// rpumacayo pase70
				        		listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Coderr, new String[]{serie.getNumserie().toString(), codi_libe.toString()}));
				        		// rpumacayo pase70
				            }
			            }
		            }
		    	} // fin Si otablibe.tviglib= "1"
		    	else{
		            	String Coderr =null;
		            	if(tipo_lib.equals(COD_LIBERATORIO)){
		            		Coderr="00104";
		            	}
		            	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
		            		Coderr="00108";
		            	}
		            	else Coderr="00112";
		            	
				        //grabaTelelog(listError,Coderr,new Object[]{codi_part,serie.getNumserie()});
		            	// rpumacayo pase70
				        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Coderr, new String[]{serie.getNumserie().toString(), codi_libe.toString()}));
				        // rpumacayo pase70
				        respuesta= respuesta(false,listError);
		    	}// fin else si  otablibe.tviglib != "1"
		    }// fin si encuentra informacion en el tablib
		    else{ //si no encuentra informacion en el tablibe
	            	String Coderr =null;
	            	if(tipo_lib.equals(COD_LIBERATORIO)){
	            		Coderr="00104";
	            	}
	            	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
	            		Coderr="00108";
	            	}
	            	else Coderr="00112";
	            	/*if ("00112".equals(Coderr)){
		            	grabaTelelog(listError,Coderr,new Object[]{codi_part,serie.getNumserie()});					            		
	            	}else{
		            	grabaTelelog(listError,Coderr,new Object[]{codi_part,serie.getNumserie()});					            		
	            	} */
	            	// rpumacayo pase70
	            	listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Coderr, new String[]{serie.getNumserie().toString(), codi_libe.toString()}));
	            	// rpumacayo pase70
	            respuesta= respuesta(false,listError);
		    }
		}// fin si no encuentra info en el primera consulta a codilibe
    	Map<String,Object> rptaCodiLibe=new HashMap<String,Object>();
    	rptaCodiLibe.put("respuesta", respuesta);
    	rptaCodiLibe.put("lstCodlib", lstCodlib);
    	return rptaCodiLibe;
	}
	
	/**
	 * Consultar asociacion triblibe.
	 * 
	 * @param dua DUA
	 * @param serie DatoSerie
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param fecha_nume Integer
	 * @param codi_part String
	 * @param listError List<Map<String,String>>
	 * @return el mapa de errores
	 */
	private Map<String,Object> consultarAsociacionTriblibe(DUA dua,DatoSerie serie,String tipo_lib, String codi_libe,Integer fecha_nume,String codi_part,List<Map<String,String>> listError){
        Map<String,Object> respuesta=null;
        String pTipoDoc = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		//List<Triblibe> lstTriblibe = findTriblibe(tipo_lib,codi_libe,dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(),dua.getDeclarante().getNumeroDocumentoIdentidad());
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		// DZC: SAU20143N002000372 se pasa el parametro fecha_nume
		List<Triblibe> lstTriblibe = preferenciaArancelariaService.obtenerImporConPreferenciaArancelaria(tipo_lib, SunatNumberUtils.toInteger(codi_libe),
				dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(),dua.getDeclarante().getNumeroDocumentoIdentidad(),fecha_nume);
		if(CollectionUtils.isEmpty(lstTriblibe)){
			String Coderr =null;
			if(tipo_lib.equals(COD_LIBERATORIO)){
				Coderr = "0105";
			}
			else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)){
				Coderr = "0109";
			}
			else{
				Coderr = "0113";
			}
			Map<String,Object> mapTipoDoc =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat("27", pTipoDoc); 
            pTipoDoc = ( mapTipoDoc.get("des_corta") == null || mapTipoDoc.get("des_corta").equals("") ? "RUC" : mapTipoDoc.get("des_corta").toString() );
			
			//grabaTelelog(listError,Coderr,	codi_libe+" F.Num: "+fecha_nume+ ": No existe Trato Preferencial");
			// rpumacayo pase70
		//	catalogoAyudaService = fabricaDeServicios.getService( "Ayuda.catalogoAyudaServicePrincipal");
//			listError.add(catalogoAyudaService.getError(Coderr, new String[]{serie.getNumserie().toString(), codi_libe.toString(),dua.getDeclarante().getNumeroDocumentoIdentidad()}));
	                grabaTelelog( listError, Coderr, new Object[]{serie.getNumserie(), codi_libe,pTipoDoc, dua.getDeclarante().getNumeroDocumentoIdentidad()});
			// rpumacayo pase70
			respuesta= respuesta(false,listError);
		}
    	Map<String,Object> rptaTriblibe=new HashMap<String,Object>();
    	rptaTriblibe.put("respuesta", respuesta);
    	rptaTriblibe.put("lstTriblibe", lstTriblibe);
    	return rptaTriblibe;
	}
	
	/**
	 * Consultar pais origen orilibe.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param fecha_nume Integer
	 * @param codi_pais String
	 * @param listError List<Map<String,String>>
	 * @return el mapa de errores
	 */
	private Map<String,Object> consultarPaisOrigenOrilibe(String tipo_lib, String codi_libe,Integer fecha_nume,String codi_pais,List<Map<String,String>> listError){
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		boolean existsOrilibe = paisOrigenTratoPreferencialService.existsOrilibe(tipo_lib,codi_libe,codi_pais);
        // Si no encuentra registros entonces se rechaza:
        Map<String,Object> respuesta=null;
        if(!existsOrilibe){
        	String Coderr =null;
        	if(tipo_lib.equals(COD_LIBERATORIO)){
        		Coderr = "0107";
        	}
        	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
        		Coderr = "0111";
        	}
        	else{
        		Coderr = "0115";
        	}

			grabaTelelog(listError,Coderr, codi_libe+" Pais: "+codi_pais);
        	//grabaTelelog(listError, Coderr, new Object[]{serie.getNumserie().toString(), codi_libe});
			respuesta= respuesta(false,listError);
        }
    	Map<String,Object> rptaOrilibe=new HashMap<String,Object>();
    	rptaOrilibe.put("respuesta", respuesta);
    	return rptaOrilibe;
	}
	
	/**
	 * Consultar excepcion excodlib.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param fecha_nume Integer
	 * @param codi_part String
	 * @param ctra_lib String
	 * @param serie DatoSerie
	 * @param listError List<Map<String,String>>
	 * @return el mapa de errores
	 */
	private Map<String,Object> consultarExcepcionExcodlib(String tipo_lib, String codi_libe,Integer fecha_nume,String codi_part, String ctra_lib,DatoSerie serie,List<Map<String,String>> listError){
		//Boolean existsExcodlib=existsExcodlib(tipo_lib, codi_libe, serie.getNumpartnandi(),fecha_nume);
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		Boolean existsExcodlib=preferenciaArancelariaService.existExoneracionPreferenciaArancelaria(tipo_lib, SunatNumberUtils.toInteger(codi_libe), serie.getNumpartnandi(),SunatDateUtils.getDateFromInteger(fecha_nume));
        Map<String,Object> respuesta=null;
        if(existsExcodlib){
        	String Coderr =null;
        	if(tipo_lib.equals(COD_LIBERATORIO)){
        		Coderr = "00106";
        	}
        	else if(tipo_lib.equals(COD_TRATO_PREF_NACIONAL)) {
        		Coderr = "00110";
        	}
        	else{
        		Coderr = "00114";
        	}
        	
			//grabaTelelog(listError,Coderr, codi_part+" C.Lib: "+codi_libe+" CTra.Lib : "+ctra_lib);
			grabaTelelog(listError, Coderr, new Object[]{serie.getNumserie(), codi_part, codi_libe});
			respuesta=  respuesta(false,listError);
        }
        Map<String,Object> rptaExcodlib=new HashMap<String,Object>();
        rptaExcodlib.put("respuesta", respuesta);
        return rptaExcodlib;
	}
	
	/**
	 * Respuesta.
	 * 
	 * @param valido Boolean
	 * @param listError List<Map<String,String>>
	 * @return el map
	 */
	private Map<String,Object> respuesta(Boolean valido, List<Map<String,String>> listError){
		Map<String,Object> respuesta=new HashMap<String,Object>();
		respuesta.put("valido", valido);
		respuesta.put("listError", listError);
		respuesta.put("existeErrorCodilib", existeErrorCodilib(listError));
		return respuesta;
	}

	/**
	 * Find onandlibe.
	 * 
	 * @param ctra_lib String
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param serie DatoSerie
	 * @param mtmargen String
	 * @param fecha_nume Integer
	 * @return el list
	 */
	private List<Map<String,Object>> findOnandlibe(String ctra_lib, String tipo_lib, String codi_libe, DatoSerie serie, String mtmargen, Integer fecha_nume){
		Map<String, Object> params=new HashMap<String, Object>();
		List<Map<String,Object>> onandlibe=null;
        if(!ctra_lib.equals("E")){			
			params=new HashMap<String, Object>();
			params.put("tlib", tipo_lib);
			params.put("clib", codi_libe);
			params.put("cnan",serie.getNumpartnandi() );
			params.put("tmargen",mtmargen);
			params.put("finilib",fecha_nume);
			//List<NandLibe> lstNandLibe= FormatoAServiceImpl.getInstance().getNandlibeDAO().findNandLibeByParams(params);
			List<NandLibe> lstNandLibe= ((NandlibeDAO)fabricaDeServicios.getService("nandlibeDAO")).findNandLibeByParams(params);
			if(!CollectionUtils.isEmpty(lstNandLibe)){
				onandlibe=new ArrayList<Map<String,Object>>();
				for(NandLibe nlib:lstNandLibe){
					Map<String,Object> mp=new HashMap<String, Object>();
					mp.put("tlib", nlib.getTlib());
					mp.put("ffinlib", nlib.getFfinlib());
					mp.put("fnummax", nlib.getFnummax());
					mp.put("tmargen", nlib.getTmargen());
					onandlibe.add(mp);
				}
			}
         }
         else{
			params=new HashMap<String, Object>();
			params.put("tlib", tipo_lib);
			params.put("clib", codi_libe);
			params.put("cnan",serie.getNumpartnandi() );
			params.put("finilib",fecha_nume);
			//List<Nandi110> lstNand110= FormatoAServiceImpl.getInstance().getNandi110DAO().findNandi110ByParams(params);
			List<Nandi110> lstNand110= ((Nandi110DAO)fabricaDeServicios.getService("Nandi110DAO")).findNandi110ByParams(params);
			if(!CollectionUtils.isEmpty(lstNand110)){ 
				onandlibe=new ArrayList<Map<String,Object>>();
				for(Nandi110 n110:lstNand110){
					Map<String,Object> mp=new HashMap<String, Object>();
					mp.put("tlib", n110.getTlib());
					onandlibe.add(mp);
				}
			}
		}
        return onandlibe;
	}
	
	/**
	 * Find codilibe.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param fecha_nume Integer
	 * @return el list
	 */
	/* private List<CodiLibe> findCodilibe(String tipo_lib, String codi_libe, Integer fecha_nume){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("tlib", tipo_lib);
		params.put("clib", codi_libe);
		params.put("fecvigencia", fecha_nume);
		return FormatoAServiceImpl.getInstance().getCodilibeDAO().findCodiLibeByParams(params);
	}
	*/
	
	/**
	 * Find tab libe.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @return el tab libe
	 */
	/*private TabLibe findTabLibe(String tipo_lib,String codi_libe){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("tlib", tipo_lib);
		params.put("clib", codi_libe);
		// deberia retornar uno , pero se esta usando una lista por si acaso
		List<TabLibe> lsTabLibe=FormatoAServiceImpl.getInstance().getTablibeDAO().findTabLibeByParams(params);
	    TabLibe otablibe=null;
	    
	    if(!CollectionUtils.isEmpty(lsTabLibe))
	    	 otablibe=lsTabLibe.get(0);// deberia retornar 1 x eso se toam el primero
	    // 	Si encuentra informaci�n entonces:
	    return otablibe;
	}*/
	
	/**
	 * Busca un registro en la tabla Triblibe que coincida con los parametros enviados.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param tdoc String
	 * @param numdoc String
	 * @return Lista de valores de Triblibe
	 */
	/*private List<Triblibe> findTriblibe(String tipo_lib, String codi_libe, String tdoc, String numdoc){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("tlib", tipo_lib);
		params.put("clib", codi_libe);
		params.put("tdoc", tdoc);
		params.put("clibtri", numdoc);
		params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
		return FormatoAServiceImpl.getInstance().getTriblibeDAO().findTriblibeByParams(params);
	}*/
	
	/**
	 * Verifica si existe un registro en la tabla Orilibe que coincida con los parametros enviados.
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param codi_pais String. Codigo de pais.
	 * @return el boolean
	 */
	/*
	private Boolean existsOrilibe(String tipo_lib, String codi_libe, String codi_pais){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("tlib", tipo_lib);
		params.put("clib", codi_libe);
		params.put("cpai",codi_pais );
        return FormatoAServiceImpl.getInstance().getOrilibeDAO().count(params)>0;
	}
	*/
	
	/**
	 * Verifica si existe codigo de exoneracion para el codigo liberatorio
	 * 
	 * @param tipo_lib String
	 * @param codi_libe String
	 * @param numpartnandi Long
	 * @param fecha_nume Integer
	 * @return true. Si existe la exoneracion.
	 */
	/*private Boolean existsExcodlib(String tipo_lib, String codi_libe, Long numpartnandi, Integer fecha_nume){
		Map<String, Object> params=new HashMap<String, Object>();
		params=new HashMap<String, Object>();
		params.put("tlib", tipo_lib);
		params.put("clib", codi_libe);
		params.put("cnan",numpartnandi );
		params.put("fecvigencia",fecha_nume);
        List<Map<String, Object>> mpExcepciones =FormatoAServiceImpl.getInstance().getExcodlibDAO().findExcepcionCodLibeByParam(params);
        return !CollectionUtils.isEmpty(mpExcepciones);
	}*/
	
	/**
	 * Verifica si existe error de codigo liberatorio 00104, 00108, 00112 en la lista de errores
	 * 
	 * @param listError List<Map<String,String>>. Lista de errores de validacion.
	 * @return true, si algun error tiene como codigo 00104, 00108, 00112.
	 */
	private Boolean existeErrorCodilib(List<Map<String,String>> listError){
		for(Map<String,String> mapError: listError){
			String codError=mapError.get(ResponseMapManager.KEY_CODIGO);
			if (SunatStringUtils.include(codError, new String[]{"00104","00108","00112"}))
				return true;
		}
		return false;
	}
	
	/**
	 * Adiciona un nuevo error a la lista de errores de validacion
	 * 
	 * @param listError List<Map<String,String>>. Lista de errores al que se agrega el nuevo error
	 * @param codigo String. Codigo de error
	 * @param mensaje String. Argumentos del mensaje
	 */
	private void grabaTelelog(List<Map<String,String>>listError, String codigo, String mensaje){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		//listError.add(FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMapWithDescription(codigo, mensaje));
		listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codigo,new String[]{mensaje}));
	}
	
	/**
	 * Adiciona un nuevo error a la lista de errores de validacion
	 * 
	 * @param listError List<Map<String,String>>. Lista de errores al que se agrega el nuevo error
	 * @param codigo String. Codigo de error
	 * @param params Object[]. Argumentos del mensaje
	 */
	private void grabaTelelog(List<Map<String,String>>listError, String codigo, Object[] params){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		listError.add(getDUAError(codigo, params));
	}
	
	private void grabaWarningTelelog(List<Map<String,String>>listError, String codigo, String mensaje){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		//listError.add(FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMapWithDescription(codigo, mensaje));
		listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codigo,new String[]{mensaje}));
	}

	/**
	 * verifica si un subpartida esta vigente en la tabla nandtasa a una fecha determinada y un tnan.
	 * @param cnan
	 * @param fechaReferencia
	 * @param tnan
	 * @return
	 */
	private boolean existePartidaVigenteNandTasa(Long cnan, Date fechaReferencia, String tnan){
		boolean existePartidaVigente = false;
		
		HashMap<String,Object> paramsNandtasa=new HashMap<String,Object>();
		if (tnan==null)
			tnan="";
		Integer fechaIngreso = fechaReferencia !=null? SunatDateUtils.getIntegerFromDate(fechaReferencia): SunatDateUtils.getCurrentIntegerDate();
		paramsNandtasa.put("tnan", tnan);
		paramsNandtasa.put("cnan", cnan);
		paramsNandtasa.put("finitas", fechaIngreso);
		paramsNandtasa.put("ffintas", fechaIngreso);
		//NandTasaDAO nandtasaDAO=FormatoAServiceImpl.getInstance().getNandtasaDAO();
//		if (nandtasaDAO.count(paramsNandtasa)==0 || ((VigenciaLicores==true && tieneNandTasa998==false)) )
		int contNandTasa=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count(paramsNandtasa);
		if (contNandTasa>0){
			existePartidaVigente = true;
		}
		return existePartidaVigente ;
	}

	/*
	public CodiLibeDAOService getCodiLibeDAOService() {
		return codiLibeDAOService;
	}

	public void setCodiLibeDAOService(CodiLibeDAOService codiLibeDAOService) {
		this.codiLibeDAOService = codiLibeDAOService;
	}

	public TabLibeDAOService getTabLibeDAOService() {
		return tabLibeDAOService;
	}

	public void setTabLibeDAOService(TabLibeDAOService tabLibeDAOService) {
		this.tabLibeDAOService = tabLibeDAOService;
	}
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}
		
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
