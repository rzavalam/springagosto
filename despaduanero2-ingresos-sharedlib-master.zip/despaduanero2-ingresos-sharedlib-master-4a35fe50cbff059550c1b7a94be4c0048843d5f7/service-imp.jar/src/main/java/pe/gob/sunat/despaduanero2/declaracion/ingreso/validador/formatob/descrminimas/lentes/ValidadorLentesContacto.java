package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesContacto;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLentesContacto extends ValidadorLentesAbstract
{
  private static final String POLIMETILMETACRILATO = "PMM";
  private static final String HIDROXIETILMETACRILATO = "HEM";
  private static final String FLUOR            = "FLU";
  private static final String SILICONA = "SIL";
  
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {

	  List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

	  //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item = obtenerItem(objeto, dua);
          //lstErrores.addAll(validarNombreComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarMaterial(objeto));
          lstErrores.addAll(validarSeriesDeMedida(objeto));
          lstErrores.addAll(validarTipoLente(objeto));
          lstErrores.addAll(validarNroFocos(objeto));
          lstErrores.addAll(validarColor(objeto));
          lstErrores.addAll(validarTratamiento(objeto));
          lstErrores.addAll(validarAcabado(objeto));
      }

	  return lstErrores;
  }
  
  @Override
  public List<ErrorDescrMinima> validarMaterial(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesContacto contacto = (LentesContacto) object;
    String nombreComercial = contacto.getNombreComercial().getValtipdescri();
    String datoAValidar= contacto.getMaterialLente().getValtipdescri();
    
    if(SunatStringUtils.isEqualTo(LENT_CONT_CORREC,nombreComercial) || 
       SunatStringUtils.isEqualTo(LENT_CON_COSMET,nombreComercial)){
        if(!(SunatStringUtils.isEqualTo(POLIMETILMETACRILATO,datoAValidar) ||
        		SunatStringUtils.isEqualTo(HIDROXIETILMETACRILATO,datoAValidar) ||
        		SunatStringUtils.isEqualTo(FLUOR,datoAValidar) ||
        		SunatStringUtils.isEqualTo(SILICONA,datoAValidar) ||
        		SunatStringUtils.isEqualTo(COD_ZZZ,contacto.getMaterialLente().getCodtipvalor()))){
        	String[] args = new String[]{nombreComercial};
          lst.add(obtenerError("31449",contacto.getMaterialLente(),args));
        }
    }
    return lst;
  }
  private Boolean esMedidasValido(String medida){
    Boolean result = false;
    try{
      if(medida.indexOf("-") !=-1){
        String[] vals = medida.split("-");
        result = ((Float.parseFloat(vals[0])%0.25)==0?true:false)&&
                 ((Float.parseFloat(vals[1])%0.25)==0?true:false);
      }else
          result = (Float.parseFloat(medida)%0.25)!= 0?true:false;
    }catch(NumberFormatException e){
      return false;
    }
    return result;
  }

  
  public List<ErrorDescrMinima> validarSeriesDeMedida(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesContacto contacto = (LentesContacto) object;
    String nombreComercial = contacto.getNombreComercial().getValtipdescri();
    String medida = contacto.getSeriesDeMedida().getValtipdescri();
    String rango = contacto.getRangoDeMedida().getValtipdescri();
    lst.addAll(super.validarSeriesDeMedida(object));
    if(SunatStringUtils.isEqualTo(LENT_CONT_CORREC,nombreComercial)){
      if(SunatStringUtils.isEmptyTrim(medida) && SunatStringUtils.isEmpty(rango)){
    	  String[] args = new String[]{nombreComercial}; 
    	  lst.add(obtenerError("31446",contacto.getSeriesDeMedida(),args));
      }else if(!SunatStringUtils.isEmpty(rango) && !esMedidasValido(rango)){
          lst.add(obtenerError("31448",contacto.getRangoDeMedida()));
      }
    }
    return lst;
  }
}
