package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.donacion;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;/*P46-PAS20155E410000032*/
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PreferenciaArancelariaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;/*P46-PAS20155E410000032*/
import pe.gob.sunat.despaduanero2.declaracion.util.Constants; //PAS20165E220200127
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;/*P46-PAS20155E410000032*/
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;/*P46-PAS20155E410000032*/
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;

public class ValidadorDonacionServiceImpl extends ValDuaAbstract implements ValidadorDonacionService {
	
	//private FabricaDeServicios fabricaDeServicios;
	
	/**validarDonaciones**/
	public List<Map<String,String>> validarDonaciones(Declaracion declaracion, Declaracion declaracionBD){
		
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		DatoOtroDocSoporte resolucion = obtenerDocumentosDonacion(declaracion);
		boolean esDonacion = false;
		List<DatoSerie> listSeries = declaracion.getDua().getListSeries();
		
		esDonacion = cumpleRequisitosParaDonar(declaracion, lstErrores, resolucion);
		
		//Inicio PAS20145E220000365 - mtorralba 20150323 - Atenci�n bug 21231
		ValTratamientoDonacionService valTratamientoDonacionService = fabricaDeServicios.getService("ValTratamientoDonacion");
		boolean tieneAyudaHumanitaria = valTratamientoDonacionService.validarEsAyudaHumanitaria(declaracion.getDua().getListSeries());
		//Fin PAS20145E220000365 - mtorralba 20150323 - Atenci�n bug 21231

		if(esDonacion && !tieneAyudaHumanitaria){ //PAS20145E220000365 - mtorralba 20150323 - Atenci�n bug 21231
			lstErrores.addAll(validarIncorporacionTipoTratamiento4(declaracion, declaracionBD));
			lstErrores.addAll(validarDocumentosAsociadosDeclaracion(declaracion));
			lstErrores.addAll(validarDocumentoDonacionAutorizante(declaracion));
			
			ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
			boolean cumpleRequisitosParaImpugnarTributos = impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion);			
			
			if(!listSeries.isEmpty()){
				for(DatoSerie datoSerie: listSeries){
					if(!cumpleRequisitosParaImpugnarTributos && resolucion!=null){				
						lstErrores.addAll(validarDatosObligatoriosResolucion(resolucion, datoSerie));
					}
					lstErrores.addAll(validarDocumentosAsociadosSeries(declaracion, datoSerie, resolucion));
					lstErrores.addAll(validarCodigoLiberatorioHabilitadoParaDonacion(datoSerie, declaracion, declaracionBD));
				}
			}
			lstErrores.addAll(impugnacionTributosParaDonacionService.validarImpugnacionDeTributos(declaracion, declaracionBD));
			//Se agrego para el Warning de FormatoB
			lstErrores.addAll(valTratamientoDonacionService.validarEnvioFormatoB(declaracion));
			
			//Ini P46 - PAS20155E220000329 - bug 22379
			if(cumpleRequisitosParaImpugnarTributos) {//Si tiene indicador de impugnacion de donacion
				lstErrores.addAll(validarIndImpugDonacionAct(declaracion));
			}
			//Fin P46 - PAS20155E220000329 - bug 22379
		}
		
		return lstErrores;
	}
	
	//Ini P46 - PAS20155E220000329 - bug 22379
	/**
	 * Metodo que permite que validar que una declaracion no tenga mas de un 
	 * indicador de impugnacion de donacion activo
	 * 
	 * @param declaracion
	 * @return
	 */
	private List<Map<String,String>> validarIndImpugDonacionAct(Declaracion declaracion) {
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		
		String[] arrayTipIndicador = new String[] {
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL };
		
		List<DatoIndicadores> listIndicadores = declaracion != null && declaracion.getDua() != null 
				&& declaracion.getDua().getListIndicadores() != null? declaracion.getDua().getListIndicadores() : new ArrayList<DatoIndicadores>();

		int cont = 0;
		
		String indImpugnacionNuevo = "";
		String indImpugnacionAntiguo = "";
		
		for(DatoIndicadores datoIndicador : listIndicadores) {
			String indicador = datoIndicador.getCodtipoindica();
			if(SunatStringUtils.include(indicador, arrayTipIndicador) && !"0".equals(datoIndicador.getIndicadorActivo())) {
				if(datoIndicador.getIndicadorActivo() == null) {
					indImpugnacionNuevo = indicador;
				} else {
					indImpugnacionAntiguo = indicador;
				}
				cont++;
			}
		}
		
		if(cont > 1) {
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
					.getError("35582", new String[]{ indImpugnacionNuevo, indImpugnacionAntiguo }));
		}
		
		return lstErrores;
	}
	//Fin P46 - PAS20155E220000329 - bug 22379
	
	/**cumpleRequisitosParaDonar**/
	public boolean cumpleRequisitosParaDonar(Declaracion declaracion, List<Map<String, String>> lstErrores, DatoOtroDocSoporte resolucion){
		
		//List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		boolean esDonacion=false;		
		//c�digo liberatorio habilitados para donaciones
		String[] arrayCodLibeDonacion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
				ConstantesDataCatalogo.COD_LIBE_DONA_IMPO_FINANCIACION,
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_SECTOR_PUBLICO,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_POR_CONVENIO,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_SECTOR_PUBLICO };
		List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
		String tipoTratamiento = declaracion.getDua().getCodtipotratamiento()!=null?declaracion.getDua().getCodtipotratamiento():"";
		boolean esAyudaHumanitaria9805=false; //PAS20165E220200127
		
		if(SunatStringUtils.isEqualTo(tipoTratamiento, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
			esDonacion=true;
			ValTratamientoDonacionService valTratamientoDonacionService = fabricaDeServicios.getService("ValTratamientoDonacion");
			List<Map<String,String>> valRegDec = valTratamientoDonacionService.validarRegimenDeclaracion(declaracion, "35568");
			if(CollectionUtils.isEmpty(valRegDec)){
				if(!lstSeries.isEmpty()){
					ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
					boolean cumpleRequisitosParaImpugnarTributos = impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion);
					for(DatoSerie serie: lstSeries){
						Integer numSerieDUA = serie.getNumserie();
						Integer codLiberatorio = serie.getCodliberatorio()!=null?serie.getCodliberatorio():0;									
						String partida = String.valueOf(serie.getNumpartnandi()); //PAS20165E220200127
						//PAS20165E220200127
						if( Constants.PARTIDA_AYUDA_HUMANITARIA_GENERAL.equals(partida)) {
							esAyudaHumanitaria9805=true;
						} else 
							esAyudaHumanitaria9805=false;
						//Fin PAS20165E220200127
						if(resolucion!=null && SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion) && cumpleRequisitosParaImpugnarTributos){
							//error Nro. 22
							lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35458", new String[]{String.valueOf(numSerieDUA)}));
						}else if(resolucion==null && codLiberatorio!=0 && cumpleRequisitosParaImpugnarTributos){
							//error Nro. 25
							lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35452"));
						}
						if(!SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion) && !cumpleRequisitosParaImpugnarTributos){
							//error Nro. 24
							//PAS20165E220200127
							if( !esAyudaHumanitaria9805 ) {
								lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35459", new String[]{String.valueOf(numSerieDUA)}));	
							}
						}
					}
				}
			}else{
				esDonacion=false;
				lstErrores.addAll(valRegDec);
			}				
			return esDonacion;
		}else{
			//resolucion = obtenerDocumentosDonacion(declaracion);
			
			if(resolucion!=null){
				//error Nro. 01
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35433"));
			}
			
			if(!lstSeries.isEmpty()){
				for(DatoSerie serie: lstSeries){
					Integer numSerieDUA = serie.getNumserie();
					Integer codLiberatorio = serie.getCodliberatorio()!=null?serie.getCodliberatorio():0;
					if(SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion)){
						//error Nro. 02
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35430", new String[]{String.valueOf(numSerieDUA)}));
					}
				}
			}
			
			ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
			if(impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)){
				//error Nro. 03
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35434"));
			}
		}
				
		return esDonacion;
	}
	
	/**obtenerDocumentosDonacion**/
	public DatoOtroDocSoporte obtenerDocumentosDonacion(Declaracion declaracion){
		
		DatoOtroDocSoporte resoluc = null;
		List<DatoOtroDocSoporte> listDocumentoAsoc = declaracion.getDua().getListOtrosDocSoporte()!=null?declaracion.getDua().getListOtrosDocSoporte():new ArrayList<DatoOtroDocSoporte>();
		
		if(!listDocumentoAsoc.isEmpty()){
			for(DatoOtroDocSoporte resolucion: listDocumentoAsoc){
				String tipoDocumentoAsoc = resolucion.getCodtipodocasoc();
				String tipoProcesoAsoc = resolucion.getCodtipoproceso();//P46 - PAS20155E220000329 - INSI
				if(declaracion.getCodtipotrans().trim().equalsIgnoreCase("1003")){//Cuando viene del servicio validarDonaciones que esta inscrito solo para la 1003 - PAS20165E220200022
					if((SunatStringUtils.isEqualTo(tipoDocumentoAsoc, ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION))//Se adiciono cod "22" - PAS20165E220200022
							&& SunatStringUtils.isEqualTo(tipoProcesoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){//P46 - PAS20155E220000329 - INSI
						return resolucion;					
					}					
				}
				else{
					if((SunatStringUtils.isEqualTo(tipoDocumentoAsoc, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION)||SunatStringUtils.isEqualTo(tipoDocumentoAsoc, ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION))//Se adiciono cod "22" - PAS20165E220200022
							&& SunatStringUtils.isEqualTo(tipoProcesoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){//P46 - PAS20155E220000329 - INSI
						return resolucion;					
					}
				}
			}
		}		
		
		return resoluc;
	}
	
	/**validarIncorporacionTipoTratamiento4**/
	public List<Map<String,String>> validarIncorporacionTipoTratamiento4(Declaracion declaracion, Declaracion declaracionBD){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		
		String tipoTratamientoNEW = declaracion.getDua().getCodtipotratamiento()!=null?declaracion.getDua().getCodtipotratamiento():"";
		String tipoTratamientoBD = declaracionBD.getDua().getCodtipotratamiento()!=null?declaracion.getDua().getCodtipotratamiento():"";
		
		if(SunatStringUtils.isEqualTo(tipoTratamientoNEW, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION) && !SunatStringUtils.isEqualTo(tipoTratamientoBD, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
			DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
			boolean estcanceladoDUA = deudaDeclaracionService.estaCanceladoFormatoC(declaracion);
			if(estcanceladoDUA){
				//error Nro. 04
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35453"));
			}
		}
		
		return lstErrores;
	}
	
	/**validarDocumentosAsociadosDeclaracion**/
	public List<Map<String, String>> validarDocumentosAsociadosDeclaracion(Declaracion declaracion){
		List<Map<String, String>> lstErrores = new ArrayList<Map<String,String>>();
		List<DatoOtroDocSoporte> listDocumentoAsoc = declaracion.getDua().getListOtrosDocSoporte()!=null?declaracion.getDua().getListOtrosDocSoporte():new ArrayList<DatoOtroDocSoporte>();
		List<DatoSerie> listSeries = declaracion.getDua()!=null?declaracion.getDua().getListSeries()!=null?declaracion.getDua().getListSeries():new ArrayList<DatoSerie>():new ArrayList<DatoSerie>();		
		//c�digos liberatorio que no requieren consignar resoluci�n para donaci�n
		String[] arrayCodLibeSinResolucion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS};
		
		ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
		if(impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)){
			return lstErrores;
		}
		
		boolean consignaCodDocDonacion = false;		
		if(!listDocumentoAsoc.isEmpty()){			
			for(DatoOtroDocSoporte documentoAsoc: listDocumentoAsoc){				
				String tipoProcesoDelDocumentoAsoc = documentoAsoc.getCodtipoproceso()!=null?documentoAsoc.getCodtipoproceso():"";
				if(SunatStringUtils.isEqualTo(tipoProcesoDelDocumentoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
					consignaCodDocDonacion = true;
					break;
				}
			}			
		}
		
		boolean tieneCodLiber20012002 = false;
		for(DatoSerie datoSerie: listSeries){
			Integer codLibe = datoSerie.getCodliberatorio()!=null?datoSerie.getCodliberatorio():0;
			if(SunatStringUtils.include(SunatStringUtils.toStringObj(codLibe), arrayCodLibeSinResolucion)){
				tieneCodLiber20012002=true;
				break;
			}		
		}
		
		if(!consignaCodDocDonacion && !tieneCodLiber20012002){
			//error Nro. 05
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35450"));
		}
		
		return lstErrores;
	}
	
	/**validarDocumentoDonacionAutorizante**/
	public List<Map<String, String>> validarDocumentoDonacionAutorizante(Declaracion declaracion){
		List<Map<String, String>> lstErrores = new ArrayList<Map<String,String>>();
		DatoOtroDocSoporte resolucion = new DatoOtroDocSoporte();
		//c�digos liberatorio que no requieren consignar resoluci�n para donaci�n
		String[] arrayCodLibeSinResolucion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS};

		List<DatoSerie> listSeries = declaracion.getDua()!=null?declaracion.getDua().getListSeries():new ArrayList<DatoSerie>();
		resolucion = obtenerDocumentosDonacion(declaracion);
		ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
		boolean cumpleRequisitosParaImpugnarTributos = impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion);
		
		boolean tieneCodLiber20012002 = false;
		for(DatoSerie datoSerie: listSeries){
			Integer codLibe = datoSerie.getCodliberatorio()!=null?datoSerie.getCodliberatorio():0;
			if(SunatStringUtils.include(SunatStringUtils.toStringObj(codLibe), arrayCodLibeSinResolucion)){
				tieneCodLiber20012002=true;
				break;
			}		
		}
		
		if(resolucion==null && !cumpleRequisitosParaImpugnarTributos && !tieneCodLiber20012002){
			//error Nro. 06
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35464"));
		}else if(resolucion!=null && cumpleRequisitosParaImpugnarTributos){
			//error Nro. 07
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35428"));
		}else{
			if(resolucion!=null){
				for(DatoSerie datoSerie: listSeries){
					lstErrores = validarDatosObligatoriosResolucion(resolucion, datoSerie);
				}											
			}else{
				List<DatoOtroDocSoporte> listDocumentoAsoc = declaracion.getDua().getListOtrosDocSoporte()!=null?declaracion.getDua().getListOtrosDocSoporte():new ArrayList<DatoOtroDocSoporte>();
				
				if(!listDocumentoAsoc.isEmpty()){
					for(DatoOtroDocSoporte TmpResolucion: listDocumentoAsoc){
						String tipoDocumentoAsoc = TmpResolucion.getCodtipodocasoc();
						String codTipoProceso = TmpResolucion.getCodtipoproceso();
						if(SunatStringUtils.isEqualTo(codTipoProceso, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
							if(!SunatStringUtils.isEqualTo(tipoDocumentoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE)){
								//error Nro. 23
								lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35454"));
							}
						}						
					}
				}	
			}		
		}		
		
		return lstErrores;
	}
	
	/**validarDatosObligatoriosResolucion**/
	public List<Map<String, String>> validarDatosObligatoriosResolucion(DatoOtroDocSoporte resolucion, DatoSerie datoSerie){
		List<Map<String, String>> lstErrores = new ArrayList<Map<String,String>>();
		String mensaje = "";
		Integer numSerie = datoSerie.getNumserie();
		Integer Numsecdocum = resolucion.getNumsecdocum();
		String nomEntidadEmisora = resolucion!=null?resolucion.getDesentidad()!=null?resolucion.getDesentidad():"":"";
		String codTipEntidadEmisora = resolucion!=null?resolucion.getCodtipoentidad()!=null?resolucion.getCodtipoentidad():"":"";
		Long numDocEntidadEmisora = resolucion!=null?resolucion.getCodentidademisora()!=null?resolucion.getCodentidademisora():0:0;
		Date fecEmisionDoc = resolucion!=null?resolucion.getFecdocasoc()!=null?resolucion.getFecdocasoc():SunatDateUtils.getDefaultDate():SunatDateUtils.getDefaultDate();
		String tipDocEntidadEmisora = "";
		String numDocumento = resolucion!=null?resolucion.getNumdocasoc()!=null?resolucion.getNumdocasoc():"":"";
		
		if(SunatStringUtils.isEqualTo(codTipEntidadEmisora, ConstantesDataCatalogo.TIPO_ENTIDAD_ADUANA)){
			tipDocEntidadEmisora = numDocEntidadEmisora!=0?numDocEntidadEmisora.toString():"";
		}
		if(SunatStringUtils.isEqualTo(codTipEntidadEmisora, ConstantesDataCatalogo.TIPO_ENTIDAD_EXTERNA)){
			tipDocEntidadEmisora = numDocEntidadEmisora!=0?numDocEntidadEmisora.toString():"";
		}
		if(SunatStringUtils.isEqualTo(codTipEntidadEmisora, ConstantesDataCatalogo.TIPO_ENTIDAD_X_DOCIDENTIDAD)){
			tipDocEntidadEmisora = resolucion!=null?resolucion.getCodtipodocentidad()!=null?resolucion.getCodtipodocentidad():"":"";
		}
		
		if(nomEntidadEmisora.equalsIgnoreCase("")){
			mensaje = ConstantesDataCatalogo.DATOS_NOMBRE_ENTIDAD_EMISORA+", ";
		}
		if(codTipEntidadEmisora.equalsIgnoreCase("")){
			mensaje = mensaje.concat(ConstantesDataCatalogo.DATOS_CODIGO_TIPO_ENTIDAD_EMISORA+", ");
		}
		if(numDocEntidadEmisora==0){
			mensaje = mensaje.concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTODE_ENTIDAD_EMISORA+", ");
		}
		if(SunatDateUtils.isEqualTo(fecEmisionDoc, SunatDateUtils.getDefaultDate())){
			mensaje = mensaje.concat(ConstantesDataCatalogo.DATOS_FECHA_ENTIDAD_EMISORA+", ");
		}
		if(tipDocEntidadEmisora.equalsIgnoreCase("")){
			mensaje = mensaje.concat(ConstantesDataCatalogo.DATOS_TIPO_DOCUMENTO_ENTIDAD_EMISORA+", ");
		}
		if(numDocumento.equalsIgnoreCase("")){
			mensaje = mensaje.concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTO+", ");
		}
		
		if(!mensaje.equalsIgnoreCase("")){
			//error Nro. 08
			String camposOmitidos = mensaje.trim().substring(0, mensaje.length()-1);
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35449",new String[]{String.valueOf(numSerie),String.valueOf(Numsecdocum),camposOmitidos}));
		}
		
//		Date fechaRecepcionResolucion = resolucion!=null?resolucion.getFecdocasoc()!=null?resolucion.getFecdocasoc():SunatDateUtils.getDefaultDate():SunatDateUtils.getDefaultDate();
//		Date fecActual = new Date();
//		if(SunatDateUtils.esFecha1MayorQueFecha2(fechaRecepcionResolucion, fecActual, SunatDateUtils.COMPARA_TODO)){
//			//error Nro. 09
//			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35446"));
//		}		
		
		return lstErrores;
	}
	
	/**validarDocumentosAsociadosSeries**/
	public List<Map<String,String>> validarDocumentosAsociadosSeries(Declaracion declaracion, DatoSerie serie, DatoOtroDocSoporte resolucion){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		//c�digos liberatorio que no requieren consignar resoluci�n para donaci�n
		String[] arrayCodLibeSinResolucion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS};
		
		boolean tieneCodLiber20012002 = false;
		Integer codLibe = serie.getCodliberatorio()!=null?serie.getCodliberatorio():0;
		if(SunatStringUtils.include(SunatStringUtils.toStringObj(codLibe), arrayCodLibeSinResolucion)){
			tieneCodLiber20012002=true;
		}
		
		ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
//		if(!impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)){//P46 - PAS20155E220000329 - bug 22386 - se comenta esta linea
			//Documento de Soporte			
			List<DatoSerieDocSoporte> listSerieDocSoporte = serie.getListSerieDocSoporte()!=null?serie.getListSerieDocSoporte():new ArrayList<DatoSerieDocSoporte>();
			if(!listSerieDocSoporte.isEmpty()){
				boolean tieneDocumSoport = false;
				for(DatoSerieDocSoporte datoSerieDocSoporte: listSerieDocSoporte){
					String codtipodocsoporte = datoSerieDocSoporte.getCodtipodocsoporte()!=null?datoSerieDocSoporte.getCodtipodocsoporte():"";
					Integer numiddocsoporte = datoSerieDocSoporte.getNumiddocsoporte()!=null?datoSerieDocSoporte.getNumiddocsoporte():0;
					if(SunatStringUtils.isEqualTo(codtipodocsoporte, ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE) && numiddocsoporte!=0){
						tieneDocumSoport=true;
						break;
					}
				}
				if(!tieneDocumSoport && !tieneCodLiber20012002){
					//error Nro. 10
					//Ini P46 - PAS20155E220000329 - bug 22386
					if(impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)) {//tiene indicador de impugnacion de donacion
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35484",new String[] {serie.getNumserie().toString()}));
					} else {
					lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35451",new String[] {serie.getNumserie().toString()}));
					}
					//Fin P46 - PAS20155E220000329 - bug 22386
//					lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35444",new String[] {serie.getNumserie().toString()}));
				}
			}				
			
		if(!impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)){//P46 - PAS20155E220000329 - bug 22386
			//Asociado a documento de donaci�n			
			String codtipoproceso = resolucion!=null?resolucion.getCodtipoproceso()!=null?resolucion.getCodtipoproceso():"":"";
			if(!SunatStringUtils.isEqualTo(codtipoproceso, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION) && !tieneCodLiber20012002){
				//error Nro. 11
				/*inicio P46-PAS20155E410000032-[jlunah] BUG 24777*/
				String regimenDiligencia = ConstantesDataCatalogo.REG_IMPO_CONSUMO + ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION;
				if(regimenDiligencia.equals(declaracion.getCodtipotrans())){
					
					boolean declaracionEstaCancelada =  declaracionEstaCancelada(declaracion);
					 if(!declaracionEstaCancelada){//SI NO ESTA CANCELADA
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35444",new String[] {serie.getNumserie().toString()}));
			}
				}else{
				/*fin P46-PAS20155E410000032-[jlunah] BUG 24777*/	
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35444",new String[] {serie.getNumserie().toString()}));
			}
			}
			
		}
		
		return lstErrores;
	}
	
	/**validarCodigoLiberatorioHabilitadoParaDonacion**/
	public List<Map<String,String>> validarCodigoLiberatorioHabilitadoParaDonacion(DatoSerie serie, Declaracion declaracion, Declaracion declaracionBD){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		//c�digo liberatorio habilitados para donaciones
		String[] arrayCodLibeDonacion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
				ConstantesDataCatalogo.COD_LIBE_DONA_IMPO_FINANCIACION,
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_SECTOR_PUBLICO,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_POR_CONVENIO,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_SECTOR_PUBLICO };
		//c�digos liberatorio que no requieren consignar resoluci�n para donaci�n
		String[] arrayCodLibeSinResolucion = new String[] {
				ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
				ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS};
		//Tipo de indicador
		String[] arrayTipIndicador = new String[] {
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL };
		
		ImpugnacionTributosParaDonacionService impugnacionTributosParaDonacionService = fabricaDeServicios.getService("impugnacionTributosParaDonacionService");
		if(!impugnacionTributosParaDonacionService.cumpleRequisitosParaImpugnarTributos(declaracion)){
			Integer codLiberatorio = serie.getCodliberatorio();
			Date fechaReferencia = declaracionBD.getDua().getFecdeclaracion();
			String tipoLiber = ConstantesDataCatalogo.CODIGO_LIBERATORIO;
			
			if(!SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeDonacion)){
				//error Nro. 12
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35436",new String[] {serie.getNumserie().toString()}));
			}else{
				//validar Vigencia
				PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
				List<CodiLibe> listPrefArancelaria = preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipoLiber, codLiberatorio, fechaReferencia);
				if(CollectionUtils.isEmpty(listPrefArancelaria)){
					//error Nro. 13
					lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35439",new String[] {serie.getNumserie().toString(),String.valueOf(codLiberatorio)}));
				}else{
					DatoOtroDocSoporte resolucion = obtenerDocumentosDonacion(declaracion);
					if(resolucion!=null && SunatStringUtils.include(SunatStringUtils.toStringObj(codLiberatorio), arrayCodLibeSinResolucion)){
						//error Nro. 14
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35441"));
					}
					
		            //si ha pasado todas las validaciones anteriores
			        //verifica que se haya eliminado el indicador 06 o 07
					if(lstErrores.isEmpty()){
						List<DatoIndicadores> listIndicadoresNEW = declaracion.getDua().getListIndicadores();
						List<DatoIndicadores> listIndicadoresBD = declaracionBD.getDua().getListIndicadores();
						if(!listIndicadoresBD.isEmpty()){
							int i = 0;
							for(DatoIndicadores datoIndicadorBD: listIndicadoresBD){
								String indicadorBD = datoIndicadorBD.getCodtipoindica();
								String indicadorNEW = !CollectionUtils.isEmpty(listIndicadoresNEW)?listIndicadoresNEW.get(i)!=null?listIndicadoresNEW.get(i).getCodtipoindica():"":"";
								if(SunatStringUtils.include(indicadorBD, arrayTipIndicador) && !SunatStringUtils.include(indicadorNEW, arrayTipIndicador)){
									Map<String,Object> params = new HashMap<String, Object>();
									params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
									DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
									//String TipoDiligenciaDespacho = diligenciaService.obtenerTipoDiligencia(params);
									//if(!TipoDiligenciaDespacho.isEmpty()){
									// se cambio verficacion en cab_diligencia por la de si tiene levante - PAS20155E410000032
									Date fechLevante = declaracionBD.getDua().getFecAutlevante();
									if(fechLevante.compareTo(SunatDateUtils.getDefaultDate())>0){
										//error Nro. 15
										lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35455"));
									}
								}
//								i++;
							}
						}
					}				
				}
			}
			
		}
		return lstErrores;		
	}
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25049*/
	private boolean declaracionEstaCancelada(Declaracion declaracion){
		
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("documentoAduanero", "DUA");
        params.put("cod_aduana", declaracion.getCodaduana());
        params.put("ann_presen", declaracion.getDua().getAnnpresen());
        params.put("cod_regimen", declaracion.getDua().getCodregimen());
        params.put("num_declaracion", declaracion.getNumeroDeclaracion());

		Map<String, Object> decla = new HashMap<String, Object>();
		
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
    	DeudaService deudaService = fabricaDeServicios.getService("diligencia.ingreso.deudaService");
    	
    	decla = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
	
		String msgDeudas = deudaService.tieneDeudaPendiente(decla);
		if (!StringUtils.isEmpty(msgDeudas) 
				&& (!declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_VERDE)
						|| !declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)
						 || !declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_ROJO) )){
			return false;
	}
	
		return true;
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25049*/
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}