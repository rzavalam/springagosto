package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.laminas;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.laminas.model.Lamina;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLamina extends ValidadorAbstract
{

  private final static String METRO = "M";
  private final static String METRO_CUADRADO = "M2";
  private final static String YARDA = "YD";
  private final static String YARDA_CUADRADA = "YD2";
  private final static String CON_SOPORTE    = "CSP";
  private final static String SIN_SOPORTE    = "SSP";
  private final static String PARTIDA_SIN_SOPORTE = "3920";
  private final static String POLICLORURO_CODIGO = "20";
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract object, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lst = validarEstructura(object);

   // lst.addAll(validarEstructura(object));
      if (CollectionUtils.isEmpty(lst)){
          DatoItem item = obtenerItem(object,dua);
          lst.addAll(validarUnidadComercial(object, item));
          lst.addAll(validadorGradoElaboracionProducto(object, item));
          lst.addAll(validarComponenteTejidoNoTejido(object, item));
          lst.addAll(validarComponentesPlasticos(object, item));
          lst.addAll(validarGradoElaboracionSoporte(object));
          lst.addAll(validarPlastificante(object, item));   
          
      }

    return lst;
  }
  
  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Lamina lamina = (Lamina) object;
    String datoAValidar = item.getCodunidcomer();
    Object[] demasArgumentosMSJError = new Object[] { 
    		object.getNumsecprove(),
    		object.getNumsecfact(),
    		object.getNumsecitem(),
    		"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar,datoAValidar};
    if(!SunatStringUtils.isEmpty(lamina.getTipoSoporte().getValtipdescri())){
    	String tipoSoporte = lamina.getTipoSoporte().getValtipdescri();
    	Boolean esObligatorio = ArrayUtils.contains(new String[]{"01","02","04","05","06"}, tipoSoporte)?true:false;
    	if(esObligatorio){
    		if(!ArrayUtils.contains(new String[]{METRO, METRO_CUADRADO, YARDA, YARDA_CUADRADA}, datoAValidar)){
    			ErrorDescrMinima err = obtenerError("31437",
   	  				 ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
    			lst.add(err);
    		}
    	}
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
    public List<ErrorDescrMinima> validarComponentesPlasticos(ModelAbstract object, DatoItem item ){
	List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	Lamina lamina = (Lamina) object;
	String primerComponente = lamina.getPrimerComponentePlastico().getValtipdescri();
	String segundoComponente = lamina.getSegundoComponentePlastico().getValtipdescri();
	String tipoSoporte = lamina.getTipoSoporte().getValtipdescri();
	Boolean esObligatorio = false;
		if(ArrayUtils.contains(new String[]{"01", "02", "04", "05", "06"},tipoSoporte)){
			esObligatorio = true;
		}
	if(esObligatorio && (SunatStringUtils.isEmptyTrim(primerComponente) && SunatStringUtils.isEmptyTrim(segundoComponente))){
		lst.add(obtenerError("31876",lamina.getPrimerComponentePlastico(),new String[]{tipoSoporte}));
	}
	return lst;
  }
  
  public List<ErrorDescrMinima> validarGradoElaboracionSoporte(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		Lamina lamina = (Lamina) object;
		String tipoSoporte = lamina.getTipoSoporte().getValtipdescri();
		String gradoElaboracionSoporte = lamina.getGradoElaboracion().getValtipdescri();
		Boolean esObligatorio = false;
			if(ArrayUtils.contains(new String[]{"01", "02", "04", "05", "06"},tipoSoporte)){
				esObligatorio = true;
			}
		if(esObligatorio && (SunatStringUtils.isEmptyTrim(gradoElaboracionSoporte))){
			lst.add(obtenerError("31877",lamina.getGradoElaboracion(),new String[]{tipoSoporte}));
		}
		return lst;
  }
  public List<ErrorDescrMinima> validadorGradoElaboracionProducto(ModelAbstract object, DatoItem item){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  Lamina lamina = (Lamina) object;
	  String partida =  item.getNumpartnandi().toString().substring(0,4);
	  String primerGradoElaboracion = lamina.getPrimerGradoElaboracionProducto().getValtipdescri();
	  String tipoSoporte = lamina.getTipoSoporte().getValtipdescri();
	  
	  if( !SunatStringUtils.isEmpty(primerGradoElaboracion) &&
		  !ArrayUtils.contains(new String[]{CON_SOPORTE,  SIN_SOPORTE}, primerGradoElaboracion)){
		  String[]args = {lamina.getPrimerGradoElaboracionProducto().getValtipdescri()};
		  lst.add(obtenerError("31438",lamina.getPrimerGradoElaboracionProducto(),args));
	  }
	  if(PARTIDA_SIN_SOPORTE.equals(partida)){
		  if(!SunatStringUtils.isEqualTo(SIN_SOPORTE,primerGradoElaboracion)){
			    lst.add(obtenerError("31786", lamina.getPrimerGradoElaboracionProducto()));  
		  }else if(!SunatStringUtils.isEmptyTrim(tipoSoporte)){
				  lst.add(obtenerError("31879", lamina.getPrimerGradoElaboracionProducto()));
			  }
	  }
	  else{
		  if(SunatStringUtils.isEqualTo(CON_SOPORTE,primerGradoElaboracion)){			  
			  if(SunatStringUtils.isEmptyTrim(tipoSoporte)){
				  lst.add(obtenerError("31785", lamina.getPrimerGradoElaboracionProducto()));
			  }
		  }

	  }	  
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarComponenteTejidoNoTejido(ModelAbstract object, DatoItem item){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  Lamina lamina = (Lamina) object;
	  String primerCompoTejido  = lamina.getPrimerCompoTejidoYNoTejido().getValtipdescri();
	  String segundoCompoTejido = lamina.getSegundoCompoTejidoYNoTejido().getValtipdescri();
	  String tipoSoporte = lamina.getTipoSoporte().getValtipdescri();
	  Boolean esObligatorio = false;
			if(ArrayUtils.contains(new String[]{"01", "02", "04", "05", "06"},tipoSoporte)){
				esObligatorio = true;
			}
		if(esObligatorio && (SunatStringUtils.isEmptyTrim(primerCompoTejido) && SunatStringUtils.isEmptyTrim(segundoCompoTejido))){
			lst.add(obtenerError("31876", lamina.getPrimerCompoTejidoYNoTejido(),new String[]{tipoSoporte}));
		}
		return lst;
  } 
  
 
  public List<ErrorDescrMinima> validarPrimerComponenteTejido(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  

  
  public List<ErrorDescrMinima> validarSegundoComponenteTejido(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  

  public List<ErrorDescrMinima> validarColor(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarAcabado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarEspeso1eraMedida(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();    
  }
  
  public List<ErrorDescrMinima> validarEspeso2daMedida(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();    
  }
  
  public List<ErrorDescrMinima> validarGramaje(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarAncho(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarUnidadMedidaAncho(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPlastificante(ModelAbstract object, DatoItem item){
	 List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	 Lamina lamina = (Lamina) object;
	 String partida = item.getNumpartnandi().toString().substring(0,4);
	 String compPlastico1 = lamina.getPrimerComponentePlastico().getValtipdescri();
	 String compPlastico2 = lamina.getSegundoComponentePlastico()!=null?
			 lamina.getSegundoComponentePlastico().getValtipdescri():"";	 
	 Boolean esObligatorio = (SunatStringUtils.isEqualTo(PARTIDA_SIN_SOPORTE,partida) && 
			 				 (SunatStringUtils.isEqualTo(POLICLORURO_CODIGO,compPlastico1)) || 
			 				SunatStringUtils.isEqualTo(POLICLORURO_CODIGO,compPlastico2));
	 if(esObligatorio){
		 if(SunatStringUtils.isEmpty(lamina.getPlastificante().getValtipdescri()))
			 lst.add(obtenerError("31782",lamina.getPlastificante()));
	 }else if(!SunatStringUtils.isEmpty(lamina.getPlastificante().getValtipdescri())){
		 lst.add(obtenerError("31783",lamina.getPlastificante()));
	 }
		 
	 return lst;
  }
}
