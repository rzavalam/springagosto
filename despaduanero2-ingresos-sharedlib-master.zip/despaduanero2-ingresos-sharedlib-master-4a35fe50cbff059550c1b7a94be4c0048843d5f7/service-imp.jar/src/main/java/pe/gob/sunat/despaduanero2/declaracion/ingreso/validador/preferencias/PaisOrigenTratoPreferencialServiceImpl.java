package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OrilibeDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Clase que contiene los metodos de validaci�n de Pa�s de origen asociado a las preferencias arancelarias
 * @author rbegazo
 *
 */

public class PaisOrigenTratoPreferencialServiceImpl extends IngresoAbstractServiceImpl implements PaisOrigenTratoPreferencialService {
	
	//private FabricaDeServicios	fabricaDeServicios;

	
	@ServicioAnnot(tipo="V",codServicio=3332, descServicio="validacion de pais de origen por TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3332,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarPaisOrigenPreferencia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		String codPaisOrige = serie.getCodpaisorige();
		Integer codConvenio = serie.getCodconvinter();
		if (!existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL,SunatStringUtils.lpad(codConvenio.toString(), 4, ' '),codPaisOrige)){
//			listError = catalogoHelper.getErrorMap("30679", new String[] {serie.getNumserie().toString(),codPaisOrige,codConvenio.toString()});
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30679", new String[] {serie.getNumserie().toString(),codPaisOrige,codConvenio.toString()});
		}		
		return listError;
	}
	
	/**
	 * Conecta a la tabla del SIGAD PRAD1 para verificar los pa�ses asociados a un determinado Convenio
	 */
	public Boolean existsOrilibe(String tipoliber, String codConvenio, String codPais){
		Map<String, Object> params=new HashMap<String, Object>();
		OrilibeDAO orilibeDAO = fabricaDeServicios.getService("orilibeDAO");
		params.put("tlib", tipoliber);
		params.put("clib", codConvenio);
		params.put("cpai",codPais );
	    return orilibeDAO.count(params)>0;
	}

/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	*/
	
}
