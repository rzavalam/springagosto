package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Representa una implementacion del servicio de control de vigencias realizadas a un determinado tratado preferencial internacional (tpi).
 * Creado para el proyecto msnade236_1.
 * @author Gerardo David L�zaro Ramos
 * @email glazaror@sunat.gob.pe
 */
public class ControlVigenciaTPIServiceImpl extends ValDuaAbstract implements ControlVigenciaTPIService {
	
	private static final String SERVICIO_ACTUAL = "SERVICIO_ACTUAL";
	private static final String SERVICIO_NUEVO = "SERVICIO_NUEVO";
	private static final String COD_ASOCIACION_SERVICIOSACTUALES_CON_CONTROLVIGENCIA= "383";
	private static final String COD_ASOCIACION_SERVICIOS_EXCEPTUADOS_CONTROLVIGENCIA= "384";
	
	//private FabricaDeServicios	fabricaDeServicios;
	
	//solo para pruebas... no se puede usar mockito para metodos static... sugerir que se adicione powermock
	private Date fechaSistemaTest;

	/**
     * Se encarga de obtener el valor de la variable de control de vigencia requerida. Se sugiere tener inializado "variablesIngreso" para ejecutar
     * de manera optima las validaciones.
     * @param codigoConvenio Codigo del convenio
     * @param tipoCertificado Codigo del tipo de certificado de origen
     * @param codigoVariable Codigo de variable de control de vigencia
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return fecha variable de control de vigencia transformado en java.util.Date
     **/
	@Override
	public Date getVariableDate(String codigoConvenio, String tipoCertificado, String codigoVariable, Map<String, Object> variablesIngreso) {
		String variableDateVigenciaAsString = getVariableVigencia(codigoConvenio, tipoCertificado, codigoVariable, variablesIngreso);
		//si es que se encontro variable fecha entonces convertimos la fecha a Date
		if (variableDateVigenciaAsString != null && !"-".equals(variableDateVigenciaAsString)) {
			return DateUtil.stringToDateSilent(variableDateVigenciaAsString, "dd/MM/yyyy");
		}
		return null;
	}
	
	/**
     * Se encarga de verificar si se debe aplicar la validacion de vigencia del tipo de certificado
     * @param serie serie que se esta evaluando
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que se debe aplicar la validacion de vigencia, false de lo contrario
     **/
	@Override
	public boolean isValidacionVigenciaAplicable(DatoSerie serie, Map<String, Object> variablesIngreso) {
		Declaracion declaracionBD = getDeclaracionBD(variablesIngreso);
		if (declaracionBD == null) {
			//si es que declaracionBD es null entonces significa que se esta numerando... por lo tanto si aplica la validacion de vigencia del tipo de certificado transmitido
			return true;
		}
		//si es que declaracionBD es distinto de null entonces se debe verificar si se esta modificando algun dato... delegamos la verificacion al metodo isRectificacionTPI(serie, variablesIngreso)
		return isRectificacionTPI(serie, variablesIngreso);
	}
	
	/**
     * Se encarga de determinar si es que se esta rectificando el tpi de la serie especificada.
     * @param serie Serie que se esta adicionando o rectificando
     * @param variablesIngreso Variables de validacion de un determinado proceso. Aqui debe existir la variable "declaracionBDParaValidacionTLC", caso contario no se realiza la evaluacion y se retorna false
     * @return true si es que se trata de una nueva serie o se esta rectificando tpi o fecha de certificado de origen, false de lo contrario
     **/
	@Override
	public boolean isRectificacionTPI (DatoSerie serie, Map<String, Object> variablesIngreso) {
		Declaracion declaracionBD = getDeclaracionBD(variablesIngreso);
		if (declaracionBD == null) {
			//si es que declaracionBDParaValidacionTLC no ha sido cargado entonces no es una validacion TLC, retornamos false
			return false;
		}
		return isRectificacionTPI(serie, declaracionBD);
	}
	
	/**
     * Se encarga de determinar si es que se esta rectificando el tpi de la serie especificada.
     * @param serie Serie que se esta adicionando o rectificando
     * @param declaracionBD declaracion de base de datos
     * @return true si es que se trata de una nueva serie o se esta rectificando tpi o fecha de certificado de origen, false de lo contrario
     **/
	@Override
	public boolean isRectificacionTPI (DatoSerie serie, Declaracion declaracionBD) {
		//si es que ya se verifico anteriormente retornamos lo evaluado
		if (serie.isTpiRectificadoComprobado()) {
			return serie.isTpiRectificado();
		}
		//sino entonces ejecutamos la logica para comprobar si se trata de una rectificacion tpi
		boolean tpiRectificado = verificarRectificacionTPI(serie, declaracionBD);
		serie.setTpiRectificado(tpiRectificado);
		serie.setTpiRectificadoComprobado(true);
		return tpiRectificado;
	}
	
	/**
     * Se encarga de verificar si es que el tpi y tipo de certificado especificados tienen configurado el control de vigencias
     * @param serie Serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el tpi/tipo certificado tienen configurado el nuevo control de vigencias, false de lo contrario.
     **/
	@Override
	public boolean hasConfiguracionControlVigencia(DatoSerie serie, Map<String, Object> variablesIngreso) {
		String codigoTPINew = serie.getCodconvinter().toString();
		DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
		String tipoCertificadoNew = certificadoOrigen.getCodtipoCO();
		return (hasVariableConfigurada(codigoTPINew, tipoCertificadoNew, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL, variablesIngreso));
	}
	
	/**
     * Se encarga de verificar si es que el tpi y tipo de certificado especificados tienen configurado el control de vigencias
     * @param codigoConvenio Codigo de convenio asociado a la serie evaluada
     * @param tipoCertificado Tipo de certificado asociado a la serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el tpi/tipo certificado tienen configurado el nuevo control de vigencias, false de lo contrario.
     **/
	private boolean hasConfiguracionControlVigencia(String codigoConvenio, String tipoCertificado, Map<String, Object> variablesIngreso) {
		return (hasVariableConfigurada(codigoConvenio, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL, variablesIngreso));
	}
	
	/**
     * Se encarga de ejecutar el control de vigencias en base al tipo de certificado y tpi.
     * El control de vigencia se realiza sobre la fecha del certificado de origen y la fecha actual.  
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @param serie Serie que se esta adicionando o rectificando
     * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
     * @param codigoServicio codigo del servicio de validacion de negocio que actualmente se esta ejecutando y el cual es sometido al control de vigencia
     * @return true si es que el servicio identificado por codigoServicio debe continuar su ejecucion, false de lo contrario
     **/
	@Override
	public boolean isServicioVigente(Map<String, Object> variablesIngreso, DatoSerie serie, Date fechaReferencia, String codigoServicio) {
		//si es que no tiene convenio (es decir un tpi) entonces no ejecutamos la validacion... retornamos true para que el servicio que se esta ejecutando continue su flujo normal
		if (serie.getCodconvinter() == null || serie.getCodconvinter().intValue() == 0 || variablesIngreso.get("indValidaTLC") == null) {
			return true;
		}
		DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
		if (certificadoOrigen != null) {
			String codigoTPI = serie.getCodconvinter().toString();
			String tipoCertificado = certificadoOrigen.getCodtipoCO();
			Date fechaEmisionCertificado = certificadoOrigen.getFecemision();
			
			//si la fecha emision del certificado es null/default o el tpi/tipo certificado no tienen configuracion de control de vigencias: entonces permitimos que el servicio actual continue su ejecucion
			if (fechaEmisionCertificado == null || SunatDateUtils.isDefaultDate(fechaEmisionCertificado) || !hasConfiguracionControlVigencia(codigoTPI, tipoCertificado, variablesIngreso)) {
				return true;
			}
			
			//luego verificamos si el servicio actual/nuevo esta exceptuado del control de vigencias
			if (isServicioEnCatalogoAsociacion(codigoTPI, fechaReferencia, variablesIngreso, COD_ASOCIACION_SERVICIOS_EXCEPTUADOS_CONTROLVIGENCIA, codigoServicio)) {
				return true;
			}
			
			
			//verificamos si la fecha de referencia debe ser la fecha actual (fecha rectificacion) si es que se esta modificando el tpi o fecha certificado
			fechaReferencia = getFechaReferenciaControl(codigoTPI, serie, fechaReferencia, variablesIngreso);
			
			//ejecutamos la evaluacion del servicio... para saber si se tiene configurado el control de vigencias, y de ser el caso entonces verificar si se trata de un servicio actual o nuevo
			String resultado = evaluarServicio(fechaReferencia, codigoServicio, codigoTPI, tipoCertificado, variablesIngreso);
			
			//obtenemos la fecha limite del sistema para el tpi/tipo de certificado...
			Date fechaLimiteAsDate = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL, variablesIngreso);
			
			//verificamos si es que el servicio es actual o nuevo
			if (SERVICIO_ACTUAL.equals(resultado)) {
				//si se trata de un servicio actual entonces
				return evaluarServicioActual(fechaReferencia, fechaLimiteAsDate, fechaEmisionCertificado, codigoTPI, tipoCertificado, variablesIngreso);
				
			} else if (SERVICIO_NUEVO.equals(resultado)) {
				//de lo contrario si se trata de un servicio nuevo entonces
				return evaluarServicioNuevo(fechaReferencia, fechaLimiteAsDate, fechaEmisionCertificado, codigoTPI, tipoCertificado, variablesIngreso);
			}
			//si es que no se presento ninguno de los casos anteriores entonces retornamos true (es decir permitimos que el servicio con logica de negocio actual pueda ejecutarse)
			return true;
		}
		return true;
	}
	
	/**
     * Obtiene la fecha de referencia para determinar la vigencia del servicio ejecutado actualmente.
     * @param codigoTPI Codigo de convenio asociado a la serie evaluada
     * @param serie serie que se esta evaluando
     * @param fechaReferencia fecha de referencia usado en las validaciones TLC
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return fecha actual: si es que se esta modificando TPI o tipo de certificado o fecha de certificado, de lo contrario se retorna la fecha de numeracion.
     **/
	@Override
	public Date getFechaReferenciaControl(String codigoTPI, DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBDParaValidacionTLC");
		if (declaracionBD != null) {
			if (isRectificacionTPI(serie, declaracionBD)) {
				//si es que se esta rectificando TPI o fecha certificado entonces retornamos la fecha actual
				if (fechaSistemaTest == null) {
					return SunatDateUtils.getCurrentDate();
				} else {
					return fechaSistemaTest;
				}
			} else {
				//Esta fecha es importante para determinar la vigencia de una validacion. Ya no sera usada la fecha de numeracion porque es posible que se presenten 
				//inconsistencias en las validaciones ejecutadas en caso de que existan varias operaciones en el tiempo (por ejemplo NUMERACION, RECTIFICACION1, ..., RECTIFICACIONN, DILIGENCIA). 
				//return declaracionBD.getDua().getFecdeclaracion();
				//Se utilizara la misma fecha de certificado para determinar la vigencia de las validaciones.
				DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
				if (certificadoOrigen != null) {
					return certificadoOrigen.getFecemision();
				}
				return null;
			}
		}
		//en cualquier otro caso retornamos la fecha de referencia usada en las validaciones TLC (que en su mayoria deberian usar la fecha de numeracion, segun se reviso hay algunos casos en que usan new Date())
		return fechaReferencia;
	}
	
	/**
     * Se encarga de obtener la declaracion de base datos para las validaciones TLC
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return declaracion de base datos para validaciones TLC
     **/
	private Declaracion getDeclaracionBD(Map<String, Object> variablesIngreso) {
		return (Declaracion) variablesIngreso.get("declaracionBDParaValidacionTLC");
	}
	
	/**
     * Se encarga de evaluar si es que el servicio actual debe continuar su ejecucion normal.
     * @param fechaReferencia fecha de referencia usado en las validaciones TLC
     * @param fechaLimiteAsDate fecha de sistema limite de validacion
     * @param fechaEmisionCertificado fecha de emision del certificado asociado a la serie que se esta validando
     * @param codigoTPI codigo de convenio asociado a la serie que se esta validando
     * @param tipoCertificado Tipo de certificado asociado a la serie que se esta validando
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el servicio actual debe completar su ejecucion normalmente, false de lo contrario
     **/
	private boolean evaluarServicioActual(Date fechaReferencia, Date fechaLimiteAsDate, Date fechaEmisionCertificado, String codigoTPI, String tipoCertificado, Map<String, Object> variablesIngreso) {
		//si es que la fecha actual es menor o igual a la fecha limite entonces evaluamos el indicador ejecucion desde fecha limite (V1)
		if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fechaLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA)) {
			//verificamos si es que el servicio actual debe ejecutarse solo desde la fecha limite V1
			String indicadorEjecucionDesdeV1 = getVariableVigencia(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_EJECUCION_DESDE_FECHALIMITE_VALIDACION_ACTUAL_V1, variablesIngreso);
			
			//si es que NO se tiene configurada la variable V5 o se tiene configurada con el valor "NO" entonces retornamos true (es decir el servicio con logica de negocio actual debe ejecutarse)
			if (indicadorEjecucionDesdeV1 == null || "NO".equals(indicadorEjecucionDesdeV1)) {
				return true;
			}
			//de lo contrario asumimos que el valor de indicadorEjecucionDesdeV1 es "SI" por lo tanto retornamos false (es decir el servicio con logica de negocio actual NO debe ejecutarse)
			return false;
			
		} else {
			//de lo contrario:
			
			//msnade236-6... obtenemos v3
			Date fechaInicioVigenciaCertificado  = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
			//obtenemos la fecha limite excepcional para el tpi/tipo de certificado...
			Date fechaExcepcionalLimiteAsDate = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL, variablesIngreso);
			
			//msnade236-6... falta probar
			if (fechaInicioVigenciaCertificado != null && fechaExcepcionalLimiteAsDate == null ) {
				if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaEmisionCertificado, fechaInicioVigenciaCertificado, SunatDateUtils.COMPARA_SOLO_FECHA)) {
					return false;
				} else {
					return true;
				}
			} else {
				//si es que no tiene fecha limite de emision de certificado entonces el tpi/tipoCertificado debe ejecutar siempre el servicio actual (caso: tpi 806, tipo certificado: 2)
				if (fechaExcepcionalLimiteAsDate == null) {
					return true;
				}
				//obtenemos la fecha limite de emision de certificado para el tpi/tipo de certificado...
				Date fechaEmisionCertificadoLimiteAsDate = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
				
				//si es que la fecha actual es menor o igual a la fecha limite excepcional y a su vez la fecha del certificado de origen es menor o igual a la fecha limite de emision de certificado entonces
				//retornamos true (es decir el servicio con logica de negocio actual debe ejecutarse)
				if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fechaExcepcionalLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA) &&
						SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaEmisionCertificado, fechaEmisionCertificadoLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA)) {
					return true;
				} else if (SunatDateUtils.esFecha1MayorQueFecha2(fechaEmisionCertificado, fechaLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA)) {
					//de lo contrario
					return isRechazadoPorSobrepasarFechaCertificadoLimite(codigoTPI, tipoCertificado, variablesIngreso);
				} else {
					return false;
				}
			}
		}
	}
	
	/**
     * Se encarga de evaluar si es que el servicio nuevo debe continuar su ejecucion normal.
     * @param fechaReferencia fecha de referencia usado en las validaciones TLC
     * @param fechaLimiteAsDate fecha de sistema limite de validacion
     * @param fechaEmisionCertificado fecha de emision del certificado asociado a la serie que se esta validando
     * @param codigoTPI codigo de convenio asociado a la serie que se esta validando
     * @param tipoCertificado Tipo de certificado asociado a la serie que se esta validando
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el servicio nuevo debe completar su ejecucion normalmente, false de lo contrario
     **/
	private boolean evaluarServicioNuevo(Date fechaReferencia, Date fechaLimiteAsDate, Date fechaEmisionCertificado, String codigoTPI, String tipoCertificado, Map<String, Object> variablesIngreso) {
		//si es que la fecha actual es menor o igual a la fecha limite retornamos false (cortamos la ejecucion del servicio nuevo)
		if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fechaLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA)) {
			return false;
		}
		
		//msnade236-6
		Date fechaFinExcepcionalCertificado = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL, variablesIngreso);
		Date fechaInicioVigenciaCertificado = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
		
		//msnade236-6
		if (fechaInicioVigenciaCertificado != null && fechaFinExcepcionalCertificado == null ) {
			if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaEmisionCertificado, fechaInicioVigenciaCertificado, SunatDateUtils.COMPARA_SOLO_FECHA)) {
				return false;
			} else {
				return true;
			}
		}
		
		//si es que el tpi / tipo certificado no tienen configurada la variable fecha excepcional limite (por el momento solo aplica al certificado 2) entonces permitimos que el servicio nuevo continue su ejecucion
		if (!hasVariableConfigurada(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL, variablesIngreso)) {
			return true;
		}
		//obtenemos la fecha limite de emision de certificado para el tpi/tipo de certificado...
		Date fechaEmisionCertificadoLimiteAsDate = getVariableDate(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
		
		//si es que la fecha emision del certificado es menor o igual a la fecha de emision limite del certificado entonces evitamos que el servicio nuevo continue su ejecucion
		if ( SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaEmisionCertificado, fechaEmisionCertificadoLimiteAsDate, SunatDateUtils.COMPARA_SOLO_FECHA)) {
			return false;
		} else {
			//de lo contrario
			return isRechazadoPorSobrepasarFechaCertificadoLimite(codigoTPI, tipoCertificado, variablesIngreso);
		}
	}
	
	/**
     * Se encarga de determinar si es que la serie esta sufriendo cambios en tpi, tipo certificado o fecha de certificado de origen, o si es que se trata de una nueva serie
     * @param serie serie que se esta evaluando
     * @param declaracionBD declaracion cargada de base datos
     * @return true si es que se trata de una nueva serie o se le esta modificando el tpi, tipo certificado o certificado de origen a una serie existente, false de lo contrario.
     **/
	private boolean verificarRectificacionTPI (DatoSerie serie, Declaracion declaracionBD) {
		int serieXML = serie.getNumserie();
		int tpiXML = serie.getCodconvinter();
		List<DatoSerie> seriesBD = declaracionBD.getDua().getListSeries(); 
		
		for (DatoSerie serieBD : seriesBD) {
			if (serieXML == serieBD.getNumserie()) {
				if ( (serieBD.getCodconvinter() == null || serieBD.getCodconvinter() == 0) && tpiXML !=0) {
					return true;//acogido por primera vez (TPIBD=0,  TPIXML!=0)
				}
				if (serieBD.getCodconvinter() != null && serieBD.getCodconvinter() != 0 && tpiXML !=0  && tpiXML != serieBD.getCodconvinter()) {
					return true;//acogido por primera vez (TPIBD!=0 , TPIXML!=0, TPIBD != TPIXML)
				}
				// Si es el mismo TPI y estan cambiando la Fecha del Certificado de Origen o tipo de certificado, tambien se considera una rectificacion
				if (serieBD.getCodconvinter() != null && serieBD.getCodconvinter() != 0 && tpiXML !=0  && tpiXML == serieBD.getCodconvinter() && 
						(isDatoCriticoCertificadoModificado(serie, declaracionBD.getDua(), serieBD)) ) {
					return true;//fecha de CO diferente o tipo de certificado diferente (TPIBD!=0 , TPIXML!=0, TPIBD == TPIXML)
				}
				return false;//si es que se llego hasta aqui significa que la serie ya existe en base datos y no se le esta rectificando tpi
			}
		}
		//glazaror msnade236_1... si es que se llego hasta aqui significa que la serie que se esta evaluando es nueva (no existe aun en base datos)
		//por lo tanto consideramos que se trata de una rectificacion de tpi
		return true;
	}	
	
	/**
     * Se encarga de verificar si es que se esta rectificando fecha de certificado o tipo de certificado del certificado de origen 
     * @param serie Serie que se esta evaluando
     * @param serieBD Serie con datos actuales en base datos
     * @return true si es que se esta modificando tipo certificado o fecha de cer
     **/
	private boolean isDatoCriticoCertificadoModificado(DatoSerie serie, DUA dua, DatoSerie serieBD) {
		//verificamos si s esta modificando la fecha de certificado de origen
		if (esRectificacionFechaCertiOrigen(fabricaDeServicios, serie, dua, serieBD)) {
			return true;
		}
		//luego verificamos si es que se esta modificando el tipo de certificado de origen
		DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
		DatoAutocertificacion certificadoOrigenBD = getCertificadoOrigen(serieBD);
		
		String tipoCertificadoNew = certificadoOrigen.getCodtipoCO();
		String tipoCertificadoBD = (certificadoOrigenBD != null) ? certificadoOrigenBD.getCodtipoCO() : "";
		
		return !tipoCertificadoBD.equals(tipoCertificadoNew);
	}
	
	/**
     * Se encarga de verificar si es que se debe rechazar la ejecucion del servicio por sobrepasar la fecha de certificado limite
     * @param codigoTPI Codigo de convenio asociado a la serie evaluada
     * @param tipoCertificado Tipo de certificado asociado a la serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que se debe rechazar la ejecucion del servicio por sobrepasar la fecha de certificado limite, false de lo contrario.
     **/
	private boolean isRechazadoPorSobrepasarFechaCertificadoLimite(String codigoTPI, String tipoCertificado, Map<String, Object> variablesIngreso) {
		//obtenemos el indicador de rechazo para el tpi/tipo de certificado (por el momento solo el tipo certificado 5 lo tiene configurado como "SI", los tipos certificado 1 y 5 tienen "NO")
		String indicadorRechazo = getVariableVigencia(codigoTPI, tipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE, variablesIngreso);
		//si es que el indicador de rechazo es "NO" entonces permitimos que el servicio se ejecute normalmente
		//si es que el indicador de rechazo es "SI" entonces debemos rechazar la ejecucion del servicio
		return ("NO".equals(indicadorRechazo));
	}
	
	/**
     * Se encarga de verificar si es que el servicio de validacion esta exceptuado del control de vigencias
     * @param codigoTPI Codigo de convenio asociado a la serie evaluada
     * @param fechaReferencia Tipo de certificado asociado a la serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @param catalogoAsociacion Codigo de asociacion donde verificar existencia del servicio (por ejemplo COD_ASOCIACION_SERVICIOS_EXCEPTUADOS_CONTROLVIGENCIA, COD_ASOCIACION_SERVICIOS_CONTROLVIGENCIA_VARIABLE)
     * @param codigoServicio codigo de servicio de validacion ejecutado actualmente
     * @return true si es que el servicio de validacion esta existe en la asociacion, false de lo contrario.
     **/
	private boolean isServicioEnCatalogoAsociacion(String codigoTPI, Date fechaReferencia, Map<String, Object> variablesIngreso, String catalogoAsociacion, String codigoServicio) {
		//primero verificamos si el servicio actual esta exceptuado del control de vigencias
		Map<String, List<String>> codigosServiciosFechaReferenciaVariableAll = IngresoVariablesUtil.obtenerCodigosAsociadosCatalogo(fabricaDeServicios, catalogoAsociacion, fechaReferencia, variablesIngreso);
		List<String> serviciosFechaReferenciaVariablePorTPI = codigosServiciosFechaReferenciaVariableAll.get(codigoTPI);
		return (serviciosFechaReferenciaVariablePorTPI.contains(codigoServicio));
	}
	
	/**
     * Se encarga de determinar si es que el servicio de validacion tiene control de vigencias.
     * @param fechaReferencia fecha de referencia usada en las validaciones TLC
     * @param codigoServicio codigo de servicio de validacion ejecutado actualmente
     * @param codigoConvenio Codigo de convenio asociado a la serie evaluada
     * @param tipoCertificado Tipo de certificado asociado a la serie evaluada
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return SIN_CONFIGURACION_CONTROL_VIGENCIA si es que el tpi/tipo certificado no tienen control de vigencia, de lo contrario si es que si tiene control de vigencias
     * entonces se retorna SERVICIO_ACTUAL en caso de que codigoServicio sea regla actual, y retorna SERVICIO_NUEVO en caso de que codigoServicio sea regla nueva. 
     **/
	private String evaluarServicio(Date fechaReferencia, String codigoServicio, String codigoConvenio, String tipoCertificado, Map<String, Object> variablesIngreso) {
		//verificamos si el servicio es nuevo o actual... para considerar un servicio como actual se deben existir en la lista de servicios actuales (codigosServicios) del tpi especificado
		Map<String, List<String>> codigosServiciosActualesTodos = IngresoVariablesUtil.obtenerCodigosAsociadosCatalogo(fabricaDeServicios, COD_ASOCIACION_SERVICIOSACTUALES_CON_CONTROLVIGENCIA, fechaReferencia, variablesIngreso);
		List<String> codigosServiciosActualesPorTPI = codigosServiciosActualesTodos.get(codigoConvenio);
		
		if (codigosServiciosActualesPorTPI != null && codigosServiciosActualesPorTPI.contains(codigoServicio)) {
			//si es que el tpi y tipo de certificado tienen configurado el control de vigencias y el codigo de servicio se encuentra en la
			//lista de servicios actuales entonces retornamos "SERVICIO_ACTUAL"
			return SERVICIO_ACTUAL;
		} else {
			//de lo contrario el codigo de servicio se trata de un nuevo servicio
			return SERVICIO_NUEVO;
		}
	}
	
	/**
     * Se encarga de obtener el valor de la variable de control de vigencia requerida.
     * @param codigoConvenio Codigo de convenio asociado a la serie evaluada
     * @param tipoCertificado Tipo de certificado asociado a la serie evaluada
     * @param codigoVariable Codigo de la variable requerida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return valor de la variable de control de vigencia requerida
     **/
	private String getVariableVigencia(String codigoConvenio, String tipoCertificado, String codigoVariable, Map<String, Object> variablesIngreso) {
		//obtenemos el identificador de tipos de certificado para el codigo de convenio (tpi) especificado... inicialmente solo para el tpi 806
		String codigoAtributoTipoCertificado = IngresoVariablesUtil.obtenerAtributoPorGrupoCatalogo(fabricaDeServicios, ConstantesAtributo.CODIGO_ATRIBUTO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codigoConvenio, variablesIngreso);
		if (codigoAtributoTipoCertificado == null) {
			return null;
		}
		//ahora obtenemos el identificador de variables para el tipo de certificado especificado
		String codigoAtributoVariablesVigencia = IngresoVariablesUtil.obtenerAtributoPorGrupoCatalogo(fabricaDeServicios, codigoAtributoTipoCertificado, ConstantesGrupoCatalogo.COD_GRUPO_TIPO_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_TIPO_CERTIFICADO, tipoCertificado, variablesIngreso);
		if (codigoAtributoVariablesVigencia == null) {
			return null;
		}
		//ahora obtenemos el valor configurado para la variable especificada
		String variable = IngresoVariablesUtil.obtenerAtributoPorGrupoCatalogo(fabricaDeServicios, codigoAtributoVariablesVigencia, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, codigoVariable, variablesIngreso);
		//simplemente retornamos la variable encontrada
		return variable;
	}
	
	/**
     * Se encarga de verificar si es que el tpi y tipo de certificado especificados tienen configurado el control de vigencias
     * @param codigoConvenio Codigo de convenio asociado a la serie evaluada
     * @param tipoCertificado Tipo de certificado asociado a la serie evaluada
     * @param codigoVariable Codigo de la variable requerida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return true si es que el tpi y tipo de certificado tienen configurado el control de vigencia, false de lo contrario
     **/
	private boolean hasVariableConfigurada(String codigoConvenio, String tipoCertificado, String codigoVariable, Map<String, Object> variablesIngreso) {
		String variableVigenciaAsString = getVariableVigencia(codigoConvenio, tipoCertificado, codigoVariable, variablesIngreso);
		return (variableVigenciaAsString != null && !"-".equals(variableVigenciaAsString));
	}
	
	/**
	 * @param fabricaDeServicios the fabricaDeServicios to set
	 */
	/*
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/
	/**
	 * Solo para fines de test... hasta poder utilizar powermock
	 * @param fechaSistemaTest the fechaSistemaTest to set
	 */
	public void setFechaSistemaTest(Date fechaSistemaTest) {
		this.fechaSistemaTest = fechaSistemaTest;
	}
}
