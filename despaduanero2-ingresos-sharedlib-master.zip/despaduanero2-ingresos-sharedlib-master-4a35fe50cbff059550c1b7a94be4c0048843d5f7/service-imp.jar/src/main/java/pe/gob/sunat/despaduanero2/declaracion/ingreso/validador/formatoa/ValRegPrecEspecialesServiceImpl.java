package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;
import java.util.ArrayList;
import org.apache.commons.lang.ArrayUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
//import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
//import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteActaEquipajeService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteComprobanteCustodiaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteDutyFreeService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteMaterialUsoAeronauticoService;

public class ValRegPrecEspecialesServiceImpl extends ValDuaAbstract implements ValRegPrecEspecialesService {
//private ValPrecedenteComprobanteCustodiaService valPrecedenteComprobanteCustodiaService;


	
	
	String codTipoTrans = "";
	public List<Map<String, String>>  validarDatosGenerales(Declaracion declaracion, Date fechaReferencia, String codRegimenEspecial){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();

		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;
		
		if(esVigenteRIN31){
		codTipoTrans = 	declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans().toString():"";
		//RIN22 R1775
//		listError.add(this.valEnvioManifiesto (declaracion.getDua().getManifiesto(), codRegimenEspecial));
//		listError.add(this.valModalidad(declaracion.getDua().getCodmodalidad(),codRegimenEspecial));
//		listError.add(this.valTipoPrecedenteUnico(declaracion.getDua(),codRegimenEspecial));
		
		Long numcorredoc =declaracion.getDua().getNumcorredoc();
		DocuPreceDuaDAO docuPreceDuaDAO= fabricaDeServicios.getService("docuPreceDuaDAO");
			HashMap<String,Object> paramPrece = new HashMap<String,Object>();
			paramPrece.put("numcorredoc",numcorredoc);
			paramPrece.put("numserie",1);
			List<DatoRegPrecedencia> listaPrece = new ArrayList<>();
			if(numcorredoc!=null){
			listaPrece = docuPreceDuaDAO.findRegPrecedenciaByMap(paramPrece);
			}
		String codTipotrans = 	declaracion.getCodtipotrans() != null ? declaracion.getCodtipotrans().toString():"0";
		if(listaPrece.isEmpty()||codTipotrans.equals("1007")||codTipotrans.equals("1003")){
		listError.addAll(this.valSeriesConPrecedencia(declaracion.getDua().getListSeries(), codRegimenEspecial));
		listError.addAll(this.valSeriesUnicoItemPrecedencia(declaracion.getDua().getListSeries(), codRegimenEspecial, declaracion.getDua().getCodaduanaorden()));
		}else {
			String codRegPreBD =listaPrece.get(0).getCodregipre() ;
			if (!codRegimenEspecial.equals(codRegPreBD)&&declaracion.getDua().getListSeries().size()>1){
				List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				String desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, codRegPreBD);   
				if (!ConstantesDataCatalogo.REG_DUTY_FREE.equals(codRegPreBD)){
					listMapError.add(catalogoAyudaService.getError("37203",new String[] {desRegimenEspecial}));
					}else {
						listMapError.add(catalogoAyudaService.getError("37234",new String[] {desRegimenEspecial}));
					}
				listError.addAll(listMapError);
			}
			listError.addAll(this.valSeriesConPrecedencia(declaracion.getDua().getListSeries(), codRegPreBD));
			listError.addAll(this.valSeriesUnicoItemPrecedencia(declaracion.getDua().getListSeries(), codRegPreBD, declaracion.getDua().getCodaduanaorden()));	
		}
		
		listError.removeIf(p -> p.isEmpty());

		if (CollectionUtils.isEmpty(listError)) {
			if (SunatStringUtils.isEqualTo(codRegimenEspecial, ConstantesDataCatalogo.ACTA_INCAUTACION)) {
				ValPrecedenteActaEquipajeService valPrecedenteActaEquipajeService = (ValPrecedenteActaEquipajeService)fabricaDeServicios.getService("ingreso.validador.precedenteActaEquipajeService");
				listError.addAll(valPrecedenteActaEquipajeService.validaActaIncautacionEquipaje(declaracion.getDua().getCodlugarecepcion(), declaracion.getDua().getListSeries(), declaracion.getDua().getCodaduanaorden(), fechaReferencia));
			}
			if (SunatStringUtils.isEqualTo(codRegimenEspecial, ConstantesDataCatalogo.COMPROBANTE_CUSTODIA)) {
				ValPrecedenteComprobanteCustodiaService valPrecedenteComprobanteCustodiaService = fabricaDeServicios.getService("ingreso.validador.precedentesCC");
				listError.addAll(valPrecedenteComprobanteCustodiaService.validaComprobanteCustodia(declaracion,declaracion.getDua().getCodlugarecepcion(),declaracion.getDua().getListSeries(), declaracion.getDua().getCodaduanaorden(),fechaReferencia));
			}
			if (SunatStringUtils.isEqualTo(codRegimenEspecial, ConstantesDataCatalogo.REG_DUTY_FREE)) {
				ValPrecedenteDutyFreeService valPrecedenteDutyFreeService = fabricaDeServicios.getService("ingreso.validador.precedentesDF");
				listError.addAll(valPrecedenteDutyFreeService.validaDutyFree(declaracion,declaracion.getDua().getCodlugarecepcion(),declaracion.getDua().getListSeries(), declaracion.getDua().getCodaduanaorden(),fechaReferencia));
			}
			if (SunatStringUtils.isEqualTo(codRegimenEspecial, ConstantesDataCatalogo.REG_DMUA)) {
				ValPrecedenteMaterialUsoAeronauticoService valPrecedenteMaterialUsoAeronauticoService = fabricaDeServicios.getService("ingreso.validador.precedentesMUA");
				listError.addAll(valPrecedenteMaterialUsoAeronauticoService.validaMaterialUsoAeronautico(declaracion,declaracion.getDua().getCodlugarecepcion(),declaracion.getDua().getListSeries(), declaracion.getDua().getCodaduanaorden(),fechaReferencia));
			}
			if (SunatStringUtils.include(codRegimenEspecial, new String[]{Constants.REGIMEN_ZOFRATACNA_CZ, Constants.REGIMEN_ZOFRATACNA_DZ})){
				ValRegPrecZofratacnaService valRegPrecZofratacnaService = fabricaDeServicios.getService("ingreso.validador.precedentesZT");
				listError.addAll(valRegPrecZofratacnaService.validarCantDocuPrecePorSerie(declaracion.getDua().getListSeries(),declaracion.getDua()));							
			}
			
			listError.removeIf(p -> p.isEmpty());
		}
	  }else{
		  listError.add(valEnvioManifiesto (declaracion.getDua().getManifiesto(), codRegimenEspecial)); 
	  }
		
		return listError;
	}
	
	
	public boolean valRegimenPrecedenteEspecial(String codRegimenEspecial) {
		boolean tieneRegimenPreEspecial = false;
		if(SunatStringUtils.include(codRegimenEspecial, new String[] {ConstantesDataCatalogo.REG_DMUA, ConstantesDataCatalogo.REG_DUTY_FREE,
                ConstantesDataCatalogo.COMPROBANTE_CUSTODIA,ConstantesDataCatalogo.ACTA_RETENCION, ConstantesDataCatalogo.ACTA_INCAUTACION,
				ConstantesDataCatalogo.MUA
				,Constants.REGIMEN_ZOFRATACNA_DZ,Constants.REGIMEN_ZOFRATACNA_CZ})){
			tieneRegimenPreEspecial = true;
		}
		return tieneRegimenPreEspecial;
	}
	

	/**
	 * Las declaraciones que tiene como r�gimen precedente Material de Uso Aeron�utico, Duty Free, Comprobante de Custodia, Acta de Incautaci�n
	 * no consignan el n�mero del manifiesto de carga conforme se se�ala en la RIN22 - R1775
	 * @param manifiesto
	 * @param codRegimenEspecial
	 * @return
	 */
	public Map<String, String>  valEnvioManifiesto(DatoManifiesto manifiesto, String codRegimenEspecial){
		Map<String,String> mapError=new HashMap<String,String>();
		if (!SunatStringUtils.isEmptyTrim(manifiesto.getNummanif()) && !SunatStringUtils.isEqualTo(manifiesto.getNummanif(), "0")) {
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			//La declaraci�n tiene como r�gimen precedente {0} no debe consignar el n�mero de manifiesto de carga
			String desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, codRegimenEspecial);
			String manifiestoAnno = SunatStringUtils.length(manifiesto.getAnnmanif()) > 3 ? manifiesto.getAnnmanif().substring(0, 4) : " ";
			String numeroManifiesto = manifiesto.getCodtipomanif().concat("-").concat(manifiesto.getCodmodtransp()).concat("-").concat(manifiesto.getCodaduamanif()).concat("-").concat(manifiestoAnno).concat("-").concat(manifiesto.getNummanif());
			mapError = catalogoAyudaService.getError("37064",new String[] {desRegimenEspecial, numeroManifiesto}); //Se completo numero de manifiesto - PAS20181U220200049
			//mapError = catalogoAyudaService.getError("37064",new String[] {desRegimenEspecial, manifiesto.getNummanif()});
		}
		return mapError;
	}

	/**
	 * La modalidad debe ser diferido
	 * @param codModalidad
	 * @param codRegimenEspecial
	 * @return
	 */
	public Map<String, String>  valModalidad(String codModalidad, String codRegimenEspecial){
		Map<String,String> mapError=new HashMap<String,String>();
		if (!SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)) {
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, codRegimenEspecial);
			//Modalidad de Despacho :0 no corresponde por tener documento precedente 01
			if(codRegimenEspecial.equals(ConstantesDataCatalogo.REG_DUTY_FREE)){
				mapError = catalogoAyudaService.getError("37232",new String[] {desRegimenEspecial});
			}else if (codRegimenEspecial.equals(ConstantesDataCatalogo.REG_DMUA)){
				mapError = catalogoAyudaService.getError("37236",new String[] {desRegimenEspecial});
			}else if(SunatStringUtils.include(codRegimenEspecial, new String[]{Constants.REGIMEN_ZOFRATACNA_CZ, Constants.REGIMEN_ZOFRATACNA_DZ})){	
			mapError = catalogoAyudaService.getError("50227",new String[] {desRegimenEspecial});
		}else {
			mapError = catalogoAyudaService.getError("37201",new String[] {desRegimenEspecial});
			}
		}
		return mapError;
	}

	/**
	 * Validad regimenes de precedencia unico
	 * @param dua
	 * @param codRegimenEspecial
	 * @return
	 */
	public Map<String, String>  valTipoPrecedenteUnico(DUA dua, String codRegimenEspecial){
		Map<String,String> mapError=new HashMap<String,String>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean encontroOtroRegimen = false;
		if(!CollectionUtils.isEmpty(dua.getListSeries())){
		  	for(DatoSerie serie:dua.getListSeries()){
		  		if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
		  			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
		  				if(!codRegimenEspecial.equals("12")){
		  				if(!SunatStringUtils.isEqualTo(regPrec.getCodregipre(), codRegimenEspecial)&&!regPrec.getCodregipre().equals("12")) {
		  					// S�lo se debe transmitir un Tipo de Documento precedente en la declaraci�n. Regimenes encontrados :0, :1
		  					//mapError = catalogoAyudaService.getError("37202",new String[] {regPrec.getCodregipre(), codRegimenEspecial});
							mapError = catalogoAyudaService.getError("37202");
		  					encontroOtroRegimen = true;
		  					break;
		  				}
		  			  }	
		  			}
		  		}
		  		if (encontroOtroRegimen) {
		  			break;
		  		}
		  	}
		}
		return mapError;
	}

	/**
	 * Todas las series deben consignar un unico regimen de precedencia
	 * @param listSeries
	 * @param codRegimenEspecial
	 * @return
	 */
	public List<Map<String, String>> valSeriesConPrecedencia (List<DatoSerie> listSeries, String codRegimenEspecial){
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String desRegimenEspecial="";
		String codRegPre="";
		for(DatoSerie serie:listSeries) {
            if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
                for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
                	 codRegPre =regPrec.getCodregipre();
                     desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, codRegPre);  
                     
     				//csantillan PAS20181U220200054 Validacion TPN 332 // bug P_SNAA0004-16488
     				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 332)&&!serie.getListRegPrecedencia().get(0).getCodregipre().equals(Constants.REGIMEN_ZOFRATACNA_CZ) ) {
     					listMapError.add( getErrorMap("50223", new Object[]{serie.getNumserie()}) );		
     				}                     
                     
                }
            }
        }
		for(DatoSerie serie:listSeries){
			if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())&&listSeries.size()>1){
				for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
					 desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, regPrec.getCodregipre());//DECLARACION DE DUTY FREE
					if(SunatStringUtils.isEmptyTrim(regPrec.getCodregipre())){
						//Ha consignado documento precedente :0 en alguna serie :1 . Todas las series deben consignar este tipo de documento precedente				
						
						if (!ConstantesDataCatalogo.REG_DUTY_FREE.equals(codRegPre)){//csantillan bug P_SNAA0004-15592
						listMapError.add(catalogoAyudaService.getError("37203",new String[] {desRegimenEspecial}));
						}else {
							listMapError.add(catalogoAyudaService.getError("37234",new String[] {desRegimenEspecial}));
						}
						
					}
				}
			} else if (CollectionUtils.isEmpty(serie.getListRegPrecedencia())&&!codTipoTrans.isEmpty()){//csantillan bug P_SNAA0004-15592
				if(ConstantesDataCatalogo.REG_DUTY_FREE.equals(codRegPre)){
					listMapError.add(catalogoAyudaService.getError("37234",new String[] {desRegimenEspecial}));
					break;
				}	else if (ConstantesDataCatalogo.REG_DMUA.equals(codRegPre)){
					listMapError.add(catalogoAyudaService.getError("37203",new String[] {"DECLARACION DE MATERIAL DE USO AERONAUTICO"}));
				}	else if(ConstantesDataCatalogo.ACTA_INCAUTACION.equals(codRegPre)){					
					listMapError.add(catalogoAyudaService.getError("37203",new String[] {"ACTA DE INCAUTACION DE EQUIPAJE"}));
				}	else {					
					listMapError.add(catalogoAyudaService.getError("37203",new String[] {desRegimenEspecial}));
				}
			}
		}
		return listMapError;

	}

	/**
	 * Un �tem del precedencia puede consignarse en varias series, pero en una serie s�lo se puede consignar un �tem.
	 * @param listSeries
	 * @param codRegimenEspecial
	 * @return
	 */
	public List<Map<String, String>> valSeriesUnicoItemPrecedencia (List<DatoSerie> listSeries, String codRegimenEspecial, String codAduanaOrden){
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//LinkedList<String> seriesPrecedentes = new LinkedList<>(); //PAS20191U220200026 - Variable no se usa
		//String strPrecedencia="";  //PAS20191U220200026 - Variable no se usa
		for(DatoSerie serie:listSeries){
			//csantillan PAS20181U220200054 bug P_SNAA0004-15766
			//if(serie.getListRegPrecedencia().size()>1){
			int conteo =0;
			if(serie.getListRegPrecedencia()!=null){
				for(DatoRegPrecedencia precedente:serie.getListRegPrecedencia()){
				if(precedente.getCodregipre().equals("12")){
					conteo++;
						}
				}
			}
			
			
			if (serie.getListRegPrecedencia()!=null && (serie.getListRegPrecedencia().size()-conteo)>1){

				//Serie [:0]: No se puede transmitir m�s de una serie/�tem asociado a la serie enviada
					if(SunatStringUtils.include(codRegimenEspecial, new String[] {ConstantesDataCatalogo.ACTA_INCAUTACION})){
		                listMapError.add(catalogoAyudaService.getError("37204",new String[] {serie.getNumserie().toString()}));
		            }else if(SunatStringUtils.include(codRegimenEspecial, new String[] {Constants.REGIMEN_ZOFRATACNA_CZ, Constants.REGIMEN_ZOFRATACNA_DZ}) ){
		            	listMapError.add(catalogoAyudaService.getError("50228",new String[] {serie.getNumserie().toString()}));
		            }else{
		                listMapError.add(catalogoAyudaService.getError("37231",new String[] {serie.getNumserie().toString()}));
		            }					
			}
			if(!codTipoTrans.isEmpty()){
			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
			listMapError.addAll(this.valDatosCompletos(regPrec, SunatStringUtils.toStringObj(serie.getNumserie()), codAduanaOrden,codRegimenEspecial));
				}
			}
		}

		return listMapError;
	}


	/**
	 * Validad los campos del precedente incluido la aduana del precedente con el de la declaracion
	 * @param regPrec
	 * @param numeSerie
	 * @return
	 */
	private List<Map<String, String>> valDatosCompletos(DatoRegPrecedencia regPrec, String numeSerie, String codAduanaOrden, String codRegimenEspecial) {
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String strPrecedencia = regPrec.getCodaduapre()+'-'+SunatStringUtils.substring(regPrec.getAnndeclpre(),0,4)+'-'+regPrec.getCodregipre()+'-'+'-'+SunatStringUtils.lpad(regPrec.getNumdeclpre(),6,'0');
		// Serie [�]: No ha enviado la Aduana del documento precedente
		if (SunatStringUtils.isEmptyTrim(regPrec.getCodaduapre())) {
			listMapError.add(catalogoAyudaService.getError("37205",new String[] {numeSerie}));
		} else {
			//Serie [:0]: Aduana de <:1> N�  :2 no corresponde a la Aduana [:3] de la declaraci�n
			String desRegimenEspecial = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, regPrec.getCodregipre());
			if (!SunatStringUtils.isEqualTo(regPrec.getCodaduapre(), codAduanaOrden)) {
				if(codRegimenEspecial.equals(ConstantesDataCatalogo.REG_DUTY_FREE)){
					listMapError.add(catalogoAyudaService.getError("37233",new String[] {numeSerie, regPrec.getCodaduapre(), strPrecedencia, codAduanaOrden}));
				}else if(codRegimenEspecial.equals(ConstantesDataCatalogo.REG_DMUA)){
					listMapError.add(catalogoAyudaService.getError("37235",new String[] {numeSerie, regPrec.getCodaduapre(), strPrecedencia, codAduanaOrden}));					
				}else{
				listMapError.add(catalogoAyudaService.getError("37209",new String[] {numeSerie, regPrec.getCodaduapre(),desRegimenEspecial, strPrecedencia, codAduanaOrden}));
			}

			}
		}
		// Serie [�]: No ha enviado el r�gimen/documento precedente
		if (SunatStringUtils.isEmptyTrim(regPrec.getCodregipre())) {
			listMapError.add(catalogoAyudaService.getError("37207",new String[] {numeSerie}));
		}
		//Serie [�]: No ha enviado el a�o del documento precedente
		if (SunatStringUtils.isEmptyTrim(regPrec.getAnndeclpre())) {
			listMapError.add(catalogoAyudaService.getError("37206",new String[] {numeSerie}));
		}
		//Serie [�]: No ha enviado la serie/�tem del documento precedente
		if (SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(regPrec.getNumserpre()))) {
			listMapError.add(catalogoAyudaService.getError("37208",new String[] {numeSerie}));
		}
		return listMapError;
	}
}