package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.personanatural;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.CtaCtePerNat;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPersonaDeclaracionEER;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CtaCtePerNatDAO;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.manifiesto.model.eer.ManifiestoDesconsolidadoEER;

public class ValPersonaNaturalServiceImpl extends IngresoAbstractServiceImpl implements ValPersonaNaturalService {
	
	protected final Log logPersonaNatural = LogFactory.getLog(getClass());
	
	public List<Map<String, String>> valCantidadDeclaracionAnual(Declaracion declaracion, Date fechaReferencia) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CtaCtePerNatDAO ctaCtePerNatDao = fabricaDeServicios.getService("ctaCtePerNatDAO");
		
		Boolean tienePartida40 = false;
		String tipoDocumento = declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad();

		//validamos si tiene al menos una partida 40
		for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){
			// hsaenz PAS20181U220400008: Se cambia porque partida ya no es obligatorio
			Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
			if(partida40.equals(datoSerie.getNumpartnandi())){
				tienePartida40=true;
				break;
			}
		}
		
		if (!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumento) && !tienePartida40){
			Map<String, Object> params = new HashMap<String, Object>();
//			params.put("anoPrese", declaracion.getAnnorden());
			//Se coloca como parametro el a�o del proceso
			SimpleDateFormat formatoAnio = new SimpleDateFormat("yyyy");
			String anio = formatoAnio.format(fechaReferencia);
			
			params.put("anoPrese", anio);
			params.put("tipoDocum", tipoDocumento);
			params.put("librTribu", numeroDocumento);
			params.put("codiRegi", declaracion.getCodregimen());
			int contadorDAM = ctaCtePerNatDao.cantidad(params);
			
			params.put("codiRegi", ConstantesDataCatalogo.REG_IMPO_CONSUMO);//contar regimen 10
			int contadorDAM10 = ctaCtePerNatDao.cantidad(params);
			
			contadorDAM = contadorDAM + contadorDAM10;
			if (contadorDAM >= 3) {
				//MENSAJE E11
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
			}else if(contadorDAM>0 && contadorDAM<3){
				//OBTENER FOB
				BigDecimal mayorFob = declaracion.getDua().getMtotfobclvta();
				BigDecimal fob1000 = new BigDecimal("1000.00");
				
				CtaCtePerNat ctaCtePerNat = new CtaCtePerNat();
				//Se coloca como parametro el a�o del proceso
//				ctaCtePerNat.setAnoPrese(declaracion.getAnnorden());
				ctaCtePerNat.setAnoPrese(anio);
				ctaCtePerNat.setCodiRegi(declaracion.getCodregimen());
				ctaCtePerNat.setTipoDocum(tipoDocumento);
				ctaCtePerNat.setLibrTribu(numeroDocumento);
				List<CtaCtePerNat> lstctaCtePerNat = ctaCtePerNatDao.selectBySelective(ctaCtePerNat);
				
				ctaCtePerNat.setCodiRegi(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
				List<CtaCtePerNat> lstctaCtePerNat10 = ctaCtePerNatDao.selectBySelective(ctaCtePerNat);
				
				lstctaCtePerNat.addAll(lstctaCtePerNat10);

				BigDecimal mayorFobBD = BigDecimal.valueOf(0);
				
				if (!CollectionUtils.isEmpty(lstctaCtePerNat)) {
					for (CtaCtePerNat ctaCtePerNatObj : lstctaCtePerNat) {
						BigDecimal valorFob = ctaCtePerNatObj.getTfobDolpo();
						
						if (valorFob.compareTo(mayorFobBD) > 0) {
							mayorFobBD = valorFob;
						}
					}
				}
				if (mayorFobBD.compareTo(fob1000) > 0) {
					//MENSAJE E11
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
				}else if (mayorFob.compareTo(fob1000) > 0) {
					//MENSAJE E11
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
				}
			}else if(contadorDAM==0){
				BigDecimal fob3000 = new BigDecimal("3000.00");
				BigDecimal fob = declaracion.getDua().getMtotfobclvta() == null ? new BigDecimal(0) : declaracion.getDua().getMtotfobclvta();
				if (fob.compareTo(fob3000) > 0) {
					//MENSAJE E12
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70153"));
				}
			}
		}
	     /*Si el tipo de documento es diferente de RUC ("4"); tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad()
	       y si la partida es diferente de 9809000040; partida = declaracion.getDua().getListSeries()[n].getNumpartnandi()
	          contar cuantas DAM se encutran en BD en la tabla; ctaCtePerNatDAO.cantidad enviar parametro a�o, tipo documento, numero documento, regimen
	          si cantidad > 3 mensaje E11
	          si cantidad > 0 
	             Obtener fob mayor declarado anteriormente ctaCtePerNat.mto_fobdol
	             si fobMayorEnBD > 1000 mensaje E11
	             si fob > 1000 mensaje E11
	      */
		
	    return listError;
	}
	
	@Deprecated
	public List<Map<String, String>> valUnicidadDeclaracionAnual(Declaracion declaracion) {
		   
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		CtaCtePerNatDAO ctaCtePerNatDao = fabricaDeServicios.getService("ctaCtePerNatDAO");
		
		String tipoDocumento = "";
		
		if (!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(declaracion.getTipoDocumento()) &&
			declaracion.getTipoDocumento() != null) {
			
			tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("anoPrese", declaracion.getAnnorden());
		params.put("tipoDocum", tipoDocumento);
		params.put("librTribu", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		params.put("cRegimen", declaracion.getCodregimen());
		   
		int contadorDAM = ctaCtePerNatDao.cantidad(params);
		   
		if (contadorDAM == 0) {
			BigDecimal fob3000 = new BigDecimal("3000.00");
			BigDecimal mayorFob = declaracion.getDua().getMtotfobclvta();
			if (mayorFob.compareTo(fob3000) > 0) {
				//MENSAJE E11
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
			}
		}
		  
		  /*Si el tipo de documento es diferente de RUC ("4"); tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad()
	       y si la partida es diferente de 9809000040; partida = declaracion.getDua().getListSeries()[n].getNumpartnandi()
	          contar cuantas DAM se encuetran en BD en la tabla; ctaCtePerNatDAO.cantidad enviar parametro a�o, tipo documento, numero documento, regimen
	          si cantidad == 0
	               si fob > 3000 mensaje E11
	      */
	    return listError;
	}
	   
	public List<Map<String,String>> valMontoImpoPorEnfermedades(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String tipoDocumento = "";
		tipoDocumento = declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat();
		
		if (!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumento)) {
			DatoSerie serie = declaracion.getDua().getListSeries().get(0);
			Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
			if (!partida40.equals(serie.getNumpartnandi())) {
				BigDecimal mayorFob = declaracion.getDua().getMtotfobclvta() == null ? new BigDecimal(0) : declaracion.getDua().getMtotfobclvta();
				BigDecimal restriccion = new BigDecimal("10000.00");
				if (mayorFob.compareTo(restriccion) > 0) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70106"));
				}
			}
		}
		  /*
	         Si el tipo de documento es diferente de RUC ("4"); tipoDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad()
	         y si la partida es igual a 9809000040; partida = declaracion.getDua().getListSeries()[n].getNumpartnandi()
	         si fob > 10000 mensaje E13; fob = declaracion.getDua().getMtofobfactu()
	      */
		   
		return listError;
	}

	@ServicioAnnot(tipo = "V", codServicio = 101169, descServicio = "Valida que la no se supere el maximo de declaraciones anuales por importador")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 101169, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DEclaracion")
	public List<Map<String, String>> valCantidadDeclaracionAnualMdeer(Declaracion declaracion, Date fechaReferencia){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		BigDecimal fob1000 = new BigDecimal("1000.00");

		Boolean tienePartida40 = false;
		String tipoDocumento = declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad();

		//validamos si tiene al menos una partida 40
		for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){
			// hsaenz PAS20181U220400008: Se cambia porque partida ya no es obligatorio
			Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
			if(partida40.equals(datoSerie.getNumpartnandi())){
				tienePartida40=true;
				break;
			}
		}

		if (!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(tipoDocumento) && !tienePartida40){
			ManifiestoDesconsolidadoEER mdeer =  (ManifiestoDesconsolidadoEER) declaracion.getPadre();
			Map<String, DatoPersonaDeclaracionEER> datosPersonaDeclaracionEER = mdeer.getDatosDeclaracionPersona();
			Integer cantidadDeclaracionAnualPersona = new Integer(0);
			BigDecimal fobAnualPersona;

			DatoPersonaDeclaracionEER datosPersona = datosPersonaDeclaracionEER!=null?datosPersonaDeclaracionEER.get(tipoDocumento+numeroDocumento):null;
			if(datosPersona!=null){
				cantidadDeclaracionAnualPersona = datosPersona.getCantidadDeclaracionAnual();
				fobAnualPersona = datosPersona.getMontoFobAnual();
			}else{
				if(datosPersonaDeclaracionEER==null)
					datosPersonaDeclaracionEER = new HashMap<String,DatoPersonaDeclaracionEER>();
				datosPersona = new DatoPersonaDeclaracionEER();
				int contadorDAM = obtenerDeclaracionesPersonaPorAnio(tipoDocumento,numeroDocumento,declaracion.getCodregimen(),fechaReferencia);
				int contadorDAM10 = obtenerDeclaracionesPersonaPorAnio(tipoDocumento,numeroDocumento, ConstantesDataCatalogo.REG_IMPO_CONSUMO,fechaReferencia);
				cantidadDeclaracionAnualPersona=contadorDAM10 + contadorDAM;
				fobAnualPersona = obtenerFOBAnualPorPersona(fechaReferencia,declaracion.getCodregimen(),tipoDocumento,numeroDocumento);
				datosPersona.setCantidadDeclaracionAnual(cantidadDeclaracionAnualPersona);
				datosPersona.setMontoFobAnual(fobAnualPersona.add(fobAnualPersona));
				datosPersona.setNumeroDocumento(numeroDocumento);
				datosPersona.setCodTipoDocumento(tipoDocumento);

			}
			BigDecimal fob = declaracion.getDua().getMtotfobclvta() == null ? new BigDecimal(0) : declaracion.getDua().getMtotfobclvta();
			if (cantidadDeclaracionAnualPersona >= 3) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
			}else if(cantidadDeclaracionAnualPersona>0 && cantidadDeclaracionAnualPersona<3){
				if (fobAnualPersona.compareTo(fob1000) > 0)
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70105"));
				else {
					datosPersona.setCantidadDeclaracionAnual(cantidadDeclaracionAnualPersona+1);
					datosPersona.setMontoFobAnual(fobAnualPersona.add(fob));
				}

			}else if(cantidadDeclaracionAnualPersona==0){
				BigDecimal fob3000 = new BigDecimal("3000.00");
				if (fob.compareTo(fob3000) > 0)
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70153"));
				else {
					datosPersona.setCantidadDeclaracionAnual(cantidadDeclaracionAnualPersona+1);
					datosPersona.setMontoFobAnual(fobAnualPersona.add(fob));
				}
			}
			datosPersonaDeclaracionEER.put(tipoDocumento+numeroDocumento,datosPersona);
			mdeer.setDatosDeclaracionPersona(datosPersonaDeclaracionEER);
		}

		return listError;
	}

	private Integer obtenerDeclaracionesPersonaPorAnio(String tipoDocumento, String numeroDocumento, String codRegimen, Date fechaReferencia){
		Map<String, Object> params = new HashMap<String, Object>();
		CtaCtePerNatDAO ctaCtePerNatDao = fabricaDeServicios.getService("ctaCtePerNatDAO");
		SimpleDateFormat formatoAnio = new SimpleDateFormat("yyyy");
		String anio = formatoAnio.format(fechaReferencia);

		params.put("anoPrese", anio);
		params.put("tipoDocum", tipoDocumento);
		params.put("librTribu", numeroDocumento);
		params.put("codiRegi", codRegimen);
		int contadorDAM = ctaCtePerNatDao.cantidad(params);

		params.put("codiRegi", ConstantesDataCatalogo.REG_IMPO_CONSUMO);//contar regimen 10
		int contadorDAM10 = ctaCtePerNatDao.cantidad(params);

		return (contadorDAM + contadorDAM10);

	}

	private BigDecimal obtenerFOBAnualPorPersona(Date fechaReferencia, String codRegimen,String tipoDocumento, String numeroDocumento){
		CtaCtePerNatDAO ctaCtePerNatDao = fabricaDeServicios.getService("ctaCtePerNatDAO");
		SimpleDateFormat formatoAnio = new SimpleDateFormat("yyyy");
		String anio = formatoAnio.format(fechaReferencia);

		CtaCtePerNat ctaCtePerNat = new CtaCtePerNat();
		ctaCtePerNat.setAnoPrese(anio);
		ctaCtePerNat.setCodiRegi(codRegimen);
		ctaCtePerNat.setTipoDocum(tipoDocumento);
		ctaCtePerNat.setLibrTribu(numeroDocumento);
		List<CtaCtePerNat> lstctaCtePerNat = ctaCtePerNatDao.selectBySelective(ctaCtePerNat);

		ctaCtePerNat.setCodiRegi(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
		List<CtaCtePerNat> lstctaCtePerNat10 = ctaCtePerNatDao.selectBySelective(ctaCtePerNat);

		lstctaCtePerNat.addAll(lstctaCtePerNat10);

		BigDecimal mayorFobBD = BigDecimal.valueOf(0);

		if (!CollectionUtils.isEmpty(lstctaCtePerNat)) {
			for (CtaCtePerNat ctaCtePerNatObj : lstctaCtePerNat) {
				BigDecimal valorFob = ctaCtePerNatObj.getTfobDolpo();

				if (valorFob.compareTo(mayorFobBD) > 0) {
					mayorFobBD = valorFob;
				}
			}
		}
		return mayorFobBD;
	}

}
