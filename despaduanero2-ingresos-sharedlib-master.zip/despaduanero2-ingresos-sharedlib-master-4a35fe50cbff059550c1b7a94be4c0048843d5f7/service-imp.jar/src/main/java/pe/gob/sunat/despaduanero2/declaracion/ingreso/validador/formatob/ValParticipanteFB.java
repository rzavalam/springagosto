/*
 * Clase que define el servicio de validaciones del participante del formato b.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/**
 * The Class ValParticipanteFB. Clase que define el servicio de validaciones del participante del formato B de la declaracion.
 */
public class ValParticipanteFB extends ValDuaAbstract {

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos 123.
	 * 
	 * @param tipoParticipante DataCatalogo
	 * @return el map
	 */
	@Deprecated
	public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante) {

		String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;

		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("123", codParticipante));
		//if (!catalogoHelper.isValid(codParticipante, "123")) {
		if (!validaCatalogo) {
			return new HashMap<String, String>();

		}
		return null;
	}

	//glazaror.. metodo optimizado
	public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante, Map<String, Object> variablesIngreso) {
		String codParticipante = (tipoParticipante != null) ? tipoParticipante.getCodDatacat() : null;
		//glazaror... para validar catalogos a nivel de detalles evitar consultas rest. Usamos el utilitario IngresoVariablesUtil
		if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, "123", codParticipante, variablesIngreso)) {
			return new HashMap<String, String>();
		}
		return null;
	}

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos 27.
	 * 
	 * @param tipoDocumentoIdentidad DataCatalogo
	 * @return el map
	 */
	@Deprecated
	public Map<String, String> codtipdocparticipante(DataCatalogo tipoDocumentoIdentidad) {

		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codTipoDocumento));
		//if (!catalogoHelper.isValid(codTipoDocumento, "27")) {
		if (!validaCatalogo) {		
			return new HashMap<String, String>(); 
		}

		return null;
	}

	//glazaror... metodo optimizado
	public Map<String, String> codtipdocparticipante(DataCatalogo tipoDocumentoIdentidad, Map<String, Object> variablesIngreso) {
		String codTipoDocumento = (tipoDocumentoIdentidad != null) ? tipoDocumentoIdentidad.getCodDatacat() : null;
		//glazaror... evitamos invocaciones a catalogorest a nivel de detalles...
		//if (!catalogoHelper.isValid(codTipoDocumento, "27")) {
		if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, "27", codTipoDocumento, variablesIngreso)) {
			return new HashMap<String, String>(); 
		}

		return null;
	}

	/**
	 * Validar que sea un dato n�merico.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> numdocparticipante(String arg) {

		if(! SunatStringUtils.isAlphanumeric(arg))
		{
			return new HashMap<String, String>();	
		}

		return null;
	}

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos J2.
	 * 
	 * @param pais DataCatalogo
	 * @return el map
	 */
	@Deprecated
	public Map<String, String> codpaisparticipante(DataCatalogo pais) {
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", pais.getCodDatacat()));
		//if (!catalogoHelper.isValid(pais.getCodDatacat(), "J2")) {
		if (!validaCatalogo) {

			return new HashMap<String, String>(); 
		}
		return null;
	}

	//glazaror... metodo optimizado
	public Map<String, String> codpaisparticipante(DataCatalogo pais, Map<String, Object> variablesIngreso) {
		//glazaror... a nivel de detalles evitamos el uso de catalogo-rest
		//if (!catalogoHelper.isValid(pais.getCodDatacat(), "J2")) {
		if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, "J2", pais.getCodDatacat(), variablesIngreso)) {
			return new HashMap<String, String>(); 
		}
		return null;
	}

	/**
	 * Nomparticipante.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> nomparticipante(String arg)
	{
		java.util.Map<String, String> result = new HashMap<String, String>();
		return result;
	}

	/**
	 * Validar que se envie un dato alfan�merico de longitud mayor a 10
	 * caracteres, sino generar el mensaje de error.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> dirparticipante(String arg) {

		if( ! SunatStringUtils.isLengthGreaterThanNumber(arg, 9) )
		{
			return new HashMap<String, String>();	
		}

		return null;
	}

	/**
	 * Validar que se envie un dato alfan�merico de longitud mayor a 2
	 * caracteres, sino generar el mensaje de error.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> desubigparticipante(String arg) {

		if( !SunatStringUtils.isLengthGreaterThanNumber(arg, 1) )
		{
			return new HashMap<String, String>();	
		}
		return null;
	}

	/**
	 * Validar que sea un dato n�merico.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> numficha(String arg) {

		if(! SunatStringUtils.isNumeric(arg))
		{
			return new HashMap<String, String>();	
		}
		return null;
	}

	/**
	 * Validar que sea un digito al menos.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> numtelefono(String arg) {
		//		String tlf="";
		//		if (!SunatStringUtils.isEmptyTrim(arg)){
		//			for(int i=0;i<arg.length();i++)
		//				if(arg.charAt(i)!='(' && arg.charAt(i)!=')' && arg.charAt(i)!='-' && arg.charAt(i)!=' ')
		//					tlf+=arg.substring(i, i+1);
		//		}
		boolean containsDigit=true;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1), "0,1,2,3,4,5,6,7,8,9,(,),+,-, ")){
				containsDigit=false;
				break;
			}
		}
		if(/*! SunatStringUtils.isNumeric(arg) &&*/ !containsDigit)
		{
			return new HashMap<String, String>();	
		}

		return null;
	}

	/**
	 * Validar que contenga un digito al menos.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> numfax(String arg) {

		if( SunatStringUtils.isEmpty(arg)) return null;
		boolean containsDigit=true;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1), "0,1,2,3,4,5,6,7,8,9,(,),+,-, ")){
				containsDigit=false;
				break;
			}
		}	
		if(/*! SunatStringUtils.isNumeric(arg)*/ !containsDigit)
		{
			return new HashMap<String, String>();
		}

		return null;
	}

	/**
	 * Validar que corresponda a una direcci�n de correo electr�nico (que
	 * contenga @, ., etc), sino generar el mensaje de error
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> dirmailweb(String arg) {

		if( SunatStringUtils.isEmpty(arg)) return null;

		if( !SunatStringUtils.isLengthGreaterThanNumber(arg,4) || (!SunatStringUtils.isValidEmailAddress(arg))){	
			return new HashMap<String, String>();
		}

		return null;
	}

	/**
	 * Validar que corresponda a una direcci�n web (que contenga www,., etc)
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> dirpagweb(String arg) {

		if( SunatStringUtils.isEmpty(arg)) return null;

		if( !SunatStringUtils.isLengthGreaterThanNumber(arg,4) || !SunatStringUtils.isValidURLAddress(arg))
			return new HashMap<String, String>();

		return null;
	}
	public Map<String, String> vigenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad,Date fecha_referencia) {
		SoporteService soporteService =   fabricaDeServicios.getService("soporteServiceDef");
		Map<String,Object>map=soporteService.obtenerPerNatJur(tipoDocumentoIdentidad,numeroDocumentoIdentidad);
		Date fecnac_vigencia=null;
		Date fecha_default=null;
		Date fecfall_pernat=null;
		try { 
			if(map!=null){  	    	 
				fecnac_vigencia = (Date)map.get("fecVigencia");
				fecha_default   = DateUtil.getDefaultDate();
				fecfall_pernat  = (Date)map.get("fecFallecimiento");

				if(!(fecfall_pernat.compareTo(fecha_default)==0)){
					return new HashMap<String, String>(); 
				}else if(!(fecnac_vigencia.compareTo(fecha_default)==0)){
					if(SunatDateUtils.esFecha1MayorQueFecha2(fecha_referencia,fecnac_vigencia,"COMPARA_TODO")){
						return new HashMap<String, String>(); 	 
					} 
				}

			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		return null;
	}
	public Map<String, String> existenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad) {
		SoporteService soporteService =   fabricaDeServicios.getService("soporteServiceDef");
		Map<String,Object>map=soporteService.obtenerPerNatJur(tipoDocumentoIdentidad,numeroDocumentoIdentidad);  	    
		String numerodni="";  	    
		if(map!=null){  	    	 	  
			numerodni=(String)map.get("codigo");
			if(numerodni.equals("")){  	    	    	 
				return new HashMap<String, String>();
			}	  
		}         
		return null;
	}

	public Map<String, String> formatoTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad) {
		SoporteService soporteService =   fabricaDeServicios.getService("soporteServiceDef");
		Map<String,Object>map=soporteService.obtenerPerNatJur(tipoDocumentoIdentidad,numeroDocumentoIdentidad);
		if(map!=null){
			if(SunatStringUtils.length(numeroDocumentoIdentidad)!=8){
				return new HashMap<String, String>(); 
			}else if(numerodocumentoDNI(numeroDocumentoIdentidad)!=null){
				return new HashMap<String, String>();
			}	  
		}         
		return null;
	}
	public Map<String, String> edadPersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,Date fecha_referencia) {
		SoporteService soporteService =   fabricaDeServicios.getService("soporteServiceDef");
		Map<String,Object>map=soporteService.obtenerPerNatJur(tipoDocumentoIdentidad,numeroDocumentoIdentidad);
		Date fecnac_pernat=null;

		if(map!=null){
			fecnac_pernat =   (Date)map.get("fechNac");
			long time = SunatDateUtils.getDifference(fecha_referencia,fecnac_pernat,Calendar.YEAR).longValue();                   
			if (time < 18L) {
				return new HashMap<String, String>(); 
			}  		  
		}

		return null;
	}
	public Map<String, String> codTipDocParticipanteDecl(String tipoDocumentoIdentidad) {
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad:null;
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("492", codTipoDocumento));
		//if (!catalogoHelper.isValid(codTipoDocumento, "492")) {
		if (!validaCatalogo) {
			return new HashMap<String, String>(); 
		}
		return null;
	}
	public Map<String, String> validarNombrePersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,String nombreDeclaranteTransmitido) {
		SoporteService soporteService =   fabricaDeServicios.getService("soporteServiceDef");
		Map<String,Object>map=soporteService.obtenerPerNatJur(tipoDocumentoIdentidad,numeroDocumentoIdentidad);

		Map<String,String> resp=new HashMap <String,String>();
		String nombreDeclarante=null;
		if(map!=null){
			nombreDeclarante= map.get("nombreDeclarante").toString();
			if (!nombreDeclarante.equals(nombreDeclaranteTransmitido))  {
				resp.put("nombreDeclarante", nombreDeclarante);
				return resp;
			} 
		} 
		return null;
	}
	/**
	 * Validar que sea un digito al menos.
	 * 
	 * @param arg String
	 * @return el map
	 */
	public Map<String, String> numerodocumentoDNI(String arg) {   
		boolean containsDigit=true;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1), "0,1,2,3,4,5,6,7,8,9")){
				containsDigit=false;
				break;
			}
		}
		if(!containsDigit)
		{
			return new HashMap<String, String>();	
		}

		return null;
	}

}
