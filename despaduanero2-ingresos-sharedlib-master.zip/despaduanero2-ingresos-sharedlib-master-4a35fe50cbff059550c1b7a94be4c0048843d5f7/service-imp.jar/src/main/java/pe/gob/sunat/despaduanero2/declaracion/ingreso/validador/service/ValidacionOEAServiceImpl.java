package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.ContingentesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.recauda2.garantia.service.GestionCtaCteGarNominalService;

public class ValidacionOEAServiceImpl extends IngresoAbstractServiceImpl implements ValidacionOEAService{

	 
	public boolean esOperadorCertificado(String numRucOperador, String tipoOperador, Date fechaReferencia){
		
		boolean esCertificado = false; 
		Map<String, Object> MapOperadoroea = null;
		//se cambia esta por query porque el rest no esta ubicando este valor
		/*MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(
				numRucOperador, tipoOperador,ConstantesDataCatalogo.ESTADO_CERITIFICADO_OEA,fechaReferencia); */
		//no rest:
		MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaServicePrincipal")).getOperadoroea(
				numRucOperador, tipoOperador,ConstantesDataCatalogo.ESTADO_CERITIFICADO_OEA,fechaReferencia); 
		if (!CollectionUtils.isEmpty(MapOperadoroea)){
			esCertificado = true;
		}
		
		return esCertificado;
	}
	
	
	//verifica si existe mas no si esta certificado o no
	public boolean existeOperador(String numRucOperador, String tipoOperador){
		
		boolean existeOperador = false;
		Map<String, Object> MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(
				numRucOperador, tipoOperador);
		if (!CollectionUtils.isEmpty(MapOperadoroea)){
			existeOperador = true;
		}
		
		return existeOperador;
	}
	
	 /**
	  * Si se le manda null por fecha de referencia verifica si existe registrado 
	  * Si se le manda la fecha de referencia verifica si existe vigente
	  * @param numRucInvitado
	  * @param fechaReferencia
	  * @return
	  */
	public boolean esInvitadoOEARegistradoOVigente(String numRucInvitado, Date fechaReferencia){
		
		boolean esInvitado = false;
		
		Map<String, Object> MapaInvitadoOEA = new HashMap<String, Object>();
		if(fechaReferencia!=null){			
			MapaInvitadoOEA = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat( ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numRucInvitado,fechaReferencia);
		}else{
			MapaInvitadoOEA = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCatExiste( ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numRucInvitado, true);
		}
		
		if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
			esInvitado = true;
		}
		
		return esInvitado;
	
	}
	
	/**
	 * Valida que cumpla con las condiciones minimas para acogerse a contingentes:
	 * la mercancia ha arribado
	 * la dam consigna tpi
	 * la dam consigna margen 5
	 * @param declaracion
	 * @return
	 */
	public boolean damTieneContingente(Declaracion declaracion){
		boolean tieneContingente = false;
		
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");		    			
		//la verificacion de los datos de contingente respecto al TPI y saldos lo hace el servicio ValidaContingentesServiceImpl
    	//List<Map<String, String>>  lstErrores = contingentesUtil.validarFechaNumeracionFechaLlegada(declaracion);
		for (DatoSerie serie : declaracion.getDua().getListSeries()){ 
				String tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
				if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen )) {
					tieneContingente = true;
					break;
				}
			}		
		return tieneContingente;
	}
	  
	public String obtenerNumRuc(Declaracion declaracion, String tipoOPerador){

		String nume_docum = "";
		
		if(declaracion!=null){
			DUA dua = declaracion.getDua(); 
			
			if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(), tipoOPerador)) {
				 nume_docum = dua.getDeclarante().getNumeroDocumentoIdentidad();
			}	
		}
		return nume_docum;
	}
	

	/**
	 * Realiza las validacion de la garantia Nominal
	 * para las entidades garantes 10-Invitado OEA y 11-Empresa OEA 
	 * PAS20181U220200022 se hicieron multiples adecuaciones de la norma
	 * desde incluir permitir anticipados para 20 y 21 
	 * y para reg 10 permitir aceptar gar si tiene contingentes
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2543)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2543,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarGarantiaNominal(Declaracion declaracion, Date fechaReferencia){
		DUA dua = declaracion.getDua(); 
		String cadError = ""; 
		boolean esGarNominal = false;
		boolean esOEA = false; 
		boolean esGarEmpresaOea = false;//PAS20181U220200022 		
		boolean esImportadorCertificado = false;
		boolean esExportadorCertificado = false;
		
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		
		String regimen = dua.getCodregimen();
		String modalidad = dua.getCodmodalidad();
		String nume_docum = obtenerNumRuc(declaracion, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		String tieneGarantia = declaracion.getDua().getPago()!=null?declaracion.getDua().getPago().getPagoDeclaracion()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():"":"":"";
		
		GestionCtaCteGarNominalService gestionCtaCteGarNominalService =  (GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService");
				
		//verifica si es gar nominal
		if(!nume_docum.isEmpty() && !tieneGarantia.equalsIgnoreCase("")){			
			String[] entidadGarante =   {ConstantesDataCatalogo.ENTIDAD_GARANTE_EMPRESA_OEA,ConstantesDataCatalogo.ENTIDAD_GARANTE_IMP_FRECUENTE_SOL_OEA};
			esGarNominal = gestionCtaCteGarNominalService.esGarantiaNominal(nume_docum, declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia(), entidadGarante);			 
		}
		
		
		if ( esGarNominal ) {			 
		
			//si no tiene deuda ignorar cambios
			boolean tieneDeudaAsociadaPdte = true;   
			if(declaracion.getDua().getNumcorredoc()!=null && declaracion.getDua().getNumcorredoc().compareTo(new Long(0))>0){
				tieneDeudaAsociadaPdte = gestionCtaCteGarNominalService.esGarantiaNominalNoPagado(declaracion.getDua().getNumcorredoc(),  declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia(), nume_docum, fechaReferencia);			
			}
			//Valida al Importador OEA certificado			
			esImportadorCertificado = esOperadorCertificado(nume_docum,  ConstantesDataCatalogo.IMPORTADOR_OEA,  fechaReferencia);
			esExportadorCertificado = esOperadorCertificado(nume_docum,  ConstantesDataCatalogo.EXPORTADOR_OEA,  fechaReferencia);
			
			if(gestionCtaCteGarNominalService.esGarantiaNominal(nume_docum, declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia(), new String[] {ConstantesDataCatalogo.ENTIDAD_GARANTE_EMPRESA_OEA})){
				esGarEmpresaOea = true;
			} 
			
			if(regimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO) && esGarEmpresaOea){
				
				if(!esImportadorCertificado && esExportadorCertificado){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13209", new String[]{nume_docum,dua.getCodregimen()}));
					return listError;
				}
				
				if(!esImportadorCertificado){
					if (existeOperador(nume_docum,  ConstantesDataCatalogo.IMPORTADOR_OEA)){
						  cadError = "13204";//oea impo no vigente en numeracion
					}
				}
				
				if(esImportadorCertificado){
					// Para regimen 10 valida el uso solo para ANTICIPADO Y URGENTE
					if ((modalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)) && tieneDeudaAsociadaPdte ) {
						cadError = "13203";
					}else{
						esOEA = true;
					}
				}
				
				if(cadError.isEmpty() && !esOEA){
					  cadError = "13210";//no existe como oea y es garnominal de oea 
				}
			}
			
			
			
			if(esGarEmpresaOea && (regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA))){
				
				if(esImportadorCertificado || esExportadorCertificado) esOEA = true;
				
				if(!esOEA){
					 if (existeOperador(nume_docum,  ConstantesDataCatalogo.EXPORTADOR_OEA)){
						  cadError = "13208";//oea expo no vigente en numeracion
					 }else{
						  cadError = "13210";//no existe como oea y es garnominal de oea
					 }
				}
			}
			
			 

			if ( !esGarEmpresaOea && !esOEA ) {
				//SE VALIDA SI ES INVITADO OEA		
				cadError = validarCondicionesInvitado(nume_docum,declaracion, fechaReferencia, esGarEmpresaOea, tieneDeudaAsociadaPdte); 
			}
			 
			//Para el regimen 20 y 21 no puede enviar OEA//PAS20181U220200022 ahora se permite si es anticipado solamente
			//if (esInvitadoOEA && (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA) ) ) {
			//		cadError = "13207";
			//}			
			if (cadError.trim().length()>0 ) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(cadError, new String[]{nume_docum,dua.getCodregimen()}));
			}
			
			NumdeclRef numdeclRef = declaracion.getNumdeclRef();
			// PAS20181U220200027
			DUA duaBD = null;
			if (numdeclRef != null) {
				CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("codigoAduana", numdeclRef.getCodaduana());
				params.put("numeroDeclaracion", 	new Integer(numdeclRef.getNumcorre()));
				params.put("annoPresentacion", new Integer(numdeclRef.getAnnprese()));
				params.put("codigoRegimen", numdeclRef.getCodregimen());
				//params.put("codTipoTransaccion", NULL); //RMC RIN-P47
				
				duaBD = cabDeclaraDAO.findDUAByMap(params);				

			}

			if( duaBD != null && listError.size()>0 ){
				String codModalidadBD =  duaBD.getCodmodalidad();
				String codModalida = declaracion.getDua().getCodmodalidad();
				if(!codModalida.equals(codModalidadBD)){
					if(regimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13217", new String[]{nume_docum,dua.getCodregimen()}));
					}
					if(regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13218", new String[]{nume_docum,dua.getCodregimen()}));
					}
				
				}
				
				if( "13212".equals(cadError) && regimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13219", new String[]{nume_docum,dua.getCodregimen()}));
				}
				
			}
			//PAS20181U220200027 fin
		}
		return listError;
	}	

	
	public String validarCondicionesInvitado(String nume_docum, Declaracion declaracion, Date fechaReferencia, boolean esGarEmpresaOea, boolean tieneDeudaAsociadaPdte){
		
		String error = "";
		
		String regimen = declaracion.getDua().getCodregimen();
		String modalidad = declaracion.getDua().getCodmodalidad();
		
		if (esInvitadoOEARegistradoOVigente(nume_docum, fechaReferencia)){
			 
			if (regimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)   ) {
				if ( !(modalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO))) {
					//cadError = "13205";
					
					if(!damTieneContingente(declaracion) && tieneDeudaAsociadaPdte){
						error ="13212";//"Garant�a nominal en modalidad urgente/diferido debe estar sujeta a contingente arancelario�
					}							
				} 
			}
			
			if(regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  
					|| regimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)  ){

				if ( !(modalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) && tieneDeudaAsociadaPdte) {
					error = "13213";	//�El uso de garant�a nominal solo procede en el despacho anticipado� 
				}
			}
		} else {
			//VALIDA SI AL MENOS EXISTE EL INVITADO OEA

			if( esInvitadoOEARegistradoOVigente( nume_docum, null) && error.trim().length()==0) { 
			 		error = "13206";
			}else{
				//La garant�a nominal no est� garantizada por una entidad Importador Frecuente entidad OEA

				if(!esGarEmpresaOea){
					error = "13211";
				}
			}	
		}
		
		return error;
	}
	
	/**PAS20181U220200022
	 * Realiza las validacion de la garantia Nominal con uso restringido
	 * para las entidades garantes 10-Invitado OEA y 11-Empresa OEA y 04-Empresa Publica
	 * se gestiona por orquestador (x trx y regimen)
	 * se gestiona las vigencias por datagrupocat 620 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2544)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2544,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarGarNominalIncumplimiento(Declaracion declaracion, Date fechaReferencia){
		
		DUA dua = declaracion.getDua(); 
		boolean esOEA = false; 
		boolean esEntGarParaValidar = false;
		boolean aceptarEntidadesGarTotal = true;
		String ctacte = "";  
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		
				 
		String numRucBeneficiario = obtenerNumRuc(declaracion, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		String tieneGarantia = declaracion.getDua().getPago()!=null?declaracion.getDua().getPago().getPagoDeclaracion()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():"":"":"";
				
		if(!tieneGarantia.equalsIgnoreCase("") && !numRucBeneficiario.isEmpty()){
			ctacte = tieneGarantia;
			
			String[] entidades = entidadesGarantesAceptadas (fechaReferencia, aceptarEntidadesGarTotal);
			
			if(entidades!=null)
			esEntGarParaValidar = esEntidadGaranteAutorizada (numRucBeneficiario, ctacte, fechaReferencia, entidades);
		}
		
		if(esEntGarParaValidar){
			 
			boolean tieneRestriccion = false;
			tieneRestriccion = ((GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService")).ctacteTieneUsoRestringido(ctacte);
			if(tieneRestriccion){				
				//Valida al OEA certificado		
				esOEA = esOperadorCertificado(numRucBeneficiario,  ConstantesDataCatalogo.IMPORTADOR_OEA,  fechaReferencia)
						|| esOperadorCertificado(numRucBeneficiario,  ConstantesDataCatalogo.EXPORTADOR_OEA,  fechaReferencia)? true: false;
				
				if(esOEA || (!esOEA && esInvitadoOEARegistradoOVigente(numRucBeneficiario, fechaReferencia)) || (aceptarEntidadesGarTotal && !esOEA)){//oeas, invitados, empresas publicas					
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13214", new String[]{""}));
					return listError;
				} 
			}			
		}
		return listError;
		
	}
	
	public String[] entidadesGarantesAceptadas ( Date fechaReferencia, boolean recienSeAcogeGarantia){
		
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String codGrupo = "";
		String[] entidadGarante = null;
		ArrayList<String> entidades = new ArrayList<String>();
		
		if(recienSeAcogeGarantia){
			codGrupo = ConstantesGrupoCatalogo.COD_GRUPO_ENTIDADES_GAR_CTACTE_USORESTRINGIDO_ACOGIMIENTO;
		}else{
			codGrupo =  ConstantesGrupoCatalogo.COD_GRUPO_ENTIDADES_GAR_CTACTE_USORESTRINGIDO_OTROS;
		}
		
		List<Map<String, String>>  listEntidadGarantesConsulta = catalogoAyudaService.getListaElementosGrupo(codGrupo, fechaReferencia);
				
		if(!CollectionUtils.isEmpty(listEntidadGarantesConsulta)){
		for(Map<String,String> listEntidades : listEntidadGarantesConsulta){
			entidades.add(listEntidades.get("cod_datacat").toString());
		}
		entidadGarante = entidades.toArray(new String[0]); 
		}
		return entidadGarante;
	}
	  
 
	public boolean esEntidadGaranteAutorizada (String numRucBeneficiario, String numctacte, Date fechaReferencia, String[] entidadGarante){
		
		boolean esAutorizada = false;   
		String entidadGaranteDetectada = ""; 
		
		List<Map<String, Object>> listGarantia =  new ArrayList<Map<String,Object>>();

		GestionCtaCteGarNominalService gestionCtaCteGarNominalService =  (GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService");
		listGarantia = gestionCtaCteGarNominalService.listarCtaCteGarNominal(numRucBeneficiario, numctacte, entidadGarante);			 
	
		if(!CollectionUtils.isEmpty(listGarantia)){ 
			for(Map<String, Object> gar : listGarantia){
				entidadGaranteDetectada = gar.get("CTIPO_ENTIDAD").toString();
				 for(int i=0; i<entidadGarante.length; i++){
					 if(entidadGarante[i].equals(entidadGaranteDetectada)){

							esAutorizada = true;
							break;
						}
				 }	
				 if(esAutorizada) break;
			}
		}	
		
		return esAutorizada;
	}
	
	public String obtenerEntidadGarante (String numRucBeneficiario, String numctacte, Date fechaReferencia,String[] entidadGarante){
		 
		String entidadUtilizada = "";
		 
		ArrayList<String> entidades = new ArrayList<String>();
		String entidadGaranteDetectada = ""; 
		List<Map<String, Object>> listGarantia =  new ArrayList<Map<String,Object>>();
		GestionCtaCteGarNominalService gestionCtaCteGarNominalService =  (GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService");
		listGarantia = gestionCtaCteGarNominalService.listarCtaCteGarNominal(numRucBeneficiario, numctacte, entidadGarante);			 
	
		if(!CollectionUtils.isEmpty(listGarantia)){ 
			for(Map<String, Object> gar : listGarantia){
				entidadGaranteDetectada = gar.get("CTIPO_ENTIDAD").toString();
				if(entidades.contains(entidadGaranteDetectada)){
					entidadUtilizada = entidadGaranteDetectada;
					break;
				}
			}
		}	
		
		return entidadUtilizada;
	}
	
	@ServicioAnnot(tipo="V",codServicio=2545)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2545,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarGarNominalIncumplimientoRecti(Declaracion declaracion, Declaracion declaracionBD, Date fechaReferencia, String codTransaccion){
		
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		
		String numctacteXML = declaracion!=null && declaracion.getDua().getPago()!=null && declaracion.getDua().getPago().getPagoDeclaracion()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():null;
		String numctacteBD = declaracionBD!=null && declaracionBD.getDua().getPago()!=null && declaracionBD.getDua().getPago().getPagoDeclaracion()!=null?declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia():null;
		String numRucBeneficiarioBD = obtenerNumRuc(declaracionBD, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		String numRucBeneficiarioXML = obtenerNumRuc(declaracionBD, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		
		boolean tieneGarantia = !(SunatStringUtils.isEmptyTrim(numctacteXML) && SunatStringUtils.isEmptyTrim(numctacteBD));
		boolean recienSeAcogeGarantia = (!SunatStringUtils.isEmptyTrim(numctacteXML) && SunatStringUtils.isEmptyTrim(numctacteBD));
		
		//boolean tieneRestriccion = false;
		//boolean esGarNominal = false;
		
		String numCtacteEval = numctacteBD;
		String numRucBeneficiarioEval = numRucBeneficiarioBD;
		
		if(tieneGarantia){
			
			if(recienSeAcogeGarantia){			 
				numCtacteEval = numctacteXML;
				numRucBeneficiarioEval = numRucBeneficiarioXML; 
			}  

			listError = validarGarNominalIncumplimientoPorParametros(fechaReferencia, recienSeAcogeGarantia, numRucBeneficiarioEval, numCtacteEval, 
					codTransaccion , declaracionBD.getDua().getNumcorredoc(),  declaracion.getDua().getCodregimen());
		}
		 
		return listError;
		
	}
	
	
	/*
	 * para poder invocarse por recti oficio y cualquier otro servicio
	 */
	
	public List<Map<String, String>> validarGarNominalIncumplimientoPorParametros(Date fechaReferencia, boolean recienSeAcogeGarantia, String numRucBeneficiarioEval, String numCtacteEval, 
																					String codTransaccion , Long numcorredoc, String codregimen){
		
		boolean esGarNominal = false;
		boolean tieneRestriccion = false;
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();

		//segun grupo 620-si se acoge o 621-si es recti u otros
		String[] entidades = entidadesGarantesAceptadas (fechaReferencia, recienSeAcogeGarantia);
		
		if(entidades!=null)

		esGarNominal =  esEntidadGaranteAutorizada (numRucBeneficiarioEval, numCtacteEval,fechaReferencia, entidades);
		GestionCtaCteGarNominalService gestionCtaCteGarNominalService =  (GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService");
		
		if(esGarNominal){
			tieneRestriccion = gestionCtaCteGarNominalService.ctacteTieneUsoRestringido(numCtacteEval);
		}
	
		if(tieneRestriccion){
			
			if(recienSeAcogeGarantia && codTransaccion.substring(2,4).equals("03") ){					
				
				String entidadUtilizada = obtenerEntidadGarante (numRucBeneficiarioEval, numCtacteEval, fechaReferencia, entidades);
				String msjAdicional = "";
				
				if(entidadUtilizada.equals(ConstantesDataCatalogo.ENTIDAD_GARANTE_EMPRESA_OEA) 
						|| entidadUtilizada.equals(ConstantesDataCatalogo.ENTIDAD_GARANTE_IMP_FRECUENTE_SOL_OEA) ){
					msjAdicional = "OEA";						
				}else if(entidadUtilizada.equals(ConstantesDataCatalogo.ENTIDAD_GARANTE_EMPRESA_PUBLICA)){
					msjAdicional = "DE EMPRESA PUBLICA";
				}
				
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13214", new String[]{msjAdicional}));
				return listError;
			}
			if(codTransaccion.substring(2,4).equals("03") || codTransaccion.substring(2,4).equals("07") 
					||  codTransaccion.substring(2,4).equals("16")  || codTransaccion.substring(2,4).equals("18")){

				boolean tieneDeudaAsociadaPdte = false;   
				tieneDeudaAsociadaPdte = gestionCtaCteGarNominalService.esGarantiaNominalNoPagado(numcorredoc, numCtacteEval, numRucBeneficiarioEval, fechaReferencia);
				
				if(tieneDeudaAsociadaPdte){
					
					if( codTransaccion.substring(2,4).equals("18") 
							&& (codregimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO) 
									|| codregimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME) 
									|| codregimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)) ){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13220"));
						return listError;
					}else{	
						String codError="";
						if(codregimen.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
							codError ="13215";
						}else if(codregimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME) 
								|| codregimen.equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)){
							codError = "13216";
						}							
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codError));
						return listError;		
					}
				}
			}	 
		} 
		return listError;
	}
}
