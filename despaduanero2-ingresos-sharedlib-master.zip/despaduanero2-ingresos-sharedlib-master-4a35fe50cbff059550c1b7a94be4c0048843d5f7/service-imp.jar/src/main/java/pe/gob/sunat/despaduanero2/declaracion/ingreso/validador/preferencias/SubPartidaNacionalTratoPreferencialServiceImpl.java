package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.AladLibe;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AladlibeDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Clase que contiene todas aquellas validaciones referentes a la subpartida nacional asociadas a Preferencias Arancelarias 
 * @author rbegazo
 *
 */
public class SubPartidaNacionalTratoPreferencialServiceImpl extends ValDuaAbstract implements SubPartidaNacionalTratoPreferencialService {

	private final static String SUFIJO_PARTIDA = "01";
	private final static String DESC_MANTECA = "MANTECA";
	
	//private FabricaDeServicios	fabricaDeServicios;
	
	@ServicioAnnot(tipo="V",codServicio=3334, descServicio="validacion de la subpartida nacional asociado al TPI, pais de origen y Tipo de Margen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3334,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarSubPartidaPaisOrigenTipoMargen (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		Integer codConvenio = serie.getCodconvinter();
		String codPaisOrige = serie.getCodpaisorige();
		String tipoMargen   = serie.getCodtipomarge();
		List<CodiLibe> listCodilibe =  preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio, fechaReferencia);

		return listError;
	}

	
	@ServicioAnnot(tipo="V",codServicio=3335, descServicio="validacion de la subpartida nacional asociado al TPI, pais de origen y Tipo de Magen diferente de 2")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3335,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarSubPartidaPaisOrigenTipoMargenDiferente (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}

		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3336, descServicio="validacion de la subpartida nacional asociado al TPI, Partida Naladisa, pais de origen y Tipo de Margen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3336,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarSubPartidaNaladisaPaisOrigenTipoMargen (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}

		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3337, descServicio="validacion de la subpartida nacional asociado al TPI, pais de origen y Tipo de Margen opcional")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3337,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarSubPartidaPaisOrigenTipoMargenOpcional (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}

		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3388, descServicio="validacion de Derecho Correctivo Provisional, para subpartida nacional relacionadas con Mantecas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3388,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarSubPartidaManteca (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		String codConvenio = serie.getCodconvinter().toString();
		if (!SunatStringUtils.include(codConvenio,new String[] {ConstantesDataCatalogo.TPI_COMUNIDAD_ANDINA_100.toString(), ConstantesDataCatalogo.TPI_VENEZUELA_14.toString(), 
				ConstantesDataCatalogo.TPI_VENEZUELA_229.toString()})) {		
		Long numpartnandi = serie.getNumpartnandi();
//		boolean indPartida = catalogoHelper.isValid(SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MANTECAS);
		//boolean indPartida = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MANTECAS, SunatStringUtils.lpad(numpartnandi.toString(),10,'0')));
		
		//glazaror... hacer uso de utilitario IngresoVariablesUtil para validar elementos de catalogo
		boolean indPartida = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MANTECAS, SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), variablesIngreso);
		
			if (indPartida){
				DUA dua = (DUA) serie.getPadre();
				String tnan=serie.getCodtnan()!=null?serie.getCodtnan():"";			
			String codpaisorige = serie.getCodpaisorige();
				DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
				String codpaisproced  = documentoTransporte==null? "": SunatStringUtils.substring(documentoTransporte.getCodpuerto(), 0, 2); 
				if (!tnan.equals(SUFIJO_PARTIDA) && (
						SunatStringUtils.include(codpaisorige, new String[] {ConstantesDataCatalogo.PAIS_COLOMBIA, ConstantesDataCatalogo.PAIS_VENEZUELA}) ||
						SunatStringUtils.include(codpaisproced, new String[] {ConstantesDataCatalogo.PAIS_COLOMBIA, ConstantesDataCatalogo.PAIS_VENEZUELA})
						)
					) {
				boolean indDescomercial = SunatStringUtils.contains(serie.getDescomercial(), DESC_MANTECA);
				boolean indDesformapres = SunatStringUtils.contains(serie.getDesformapres(), DESC_MANTECA);
				boolean indDesmatecomp  = SunatStringUtils.contains(serie.getDesmatecomp(), DESC_MANTECA);
				boolean indDesotros     = SunatStringUtils.contains(serie.getDesotros(), DESC_MANTECA);
				boolean indDesusoaplica = SunatStringUtils.contains(serie.getDesusoaplica(), DESC_MANTECA);
				if (indDescomercial || indDesformapres || indDesmatecomp || indDesotros || indDesusoaplica) {
						//glazaror... evitamos el uso de catalogoHelper.getErrorMap
//						listError = catalogoHelper.getErrorMap("30726", new String[] {serie.getNumserie().toString(),numpartnandi.toString(), codpaisorige, tnan, codpaisproced});
						//glazaror... hacemos uso de catalogoAyudaService.getError
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30726", new String[] {serie.getNumserie().toString(),numpartnandi.toString(), codpaisorige, tnan, codpaisproced});
					}
				}
			}
		}
		return listError;
	}
	
	
	public List<AladLibe> validaVigenciaSubPartidaTodoArancel(DatoSerie serie,  Date fechaReferencia){		
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		AladlibeDAO aladlibeDAO = fabricaDeServicios.getService("aladlibeDAO");
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("tlib", ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL);
		params.put("clib", serie.getCodconvinter());
		params.put("cpaiorige", serie.getCodpaisorige());
		/*RIN 13*/
		 
		if (serie.getCodtipomarge()==null || (serie.getCodtipomarge()!=null && serie.getCodtipomarge().isEmpty())) {
			params.put("tmargen", " ");
		}
		else 
		{
			params.put("tmargen", serie.getCodtipomarge() );
		}
		/*RIN 13*/
		params.put("cnaladisa", "0" );
		params.put("cnan", "0" );
		params.put("fecvigencia", SunatDateUtils.getIntegerFromDate(fechaReferencia) );
		 
	
		List<AladLibe> listAladlibe =  aladlibeDAO.findAladLibeByParams(params);
			
			
		return listAladlibe;
	}
	

	/**
	 * Verifica si la partida es de grupo de Motores y piezas
	 * @param serie
	 * @param fechaReferencia
	 * @return Mapa vacio si encontro la partida, caso contrario retorna el error
	 */
	public Map<String, String> validarSubPartidaMotoresPiezasUsados(DatoSerie serie, Date fechaReferencia){
		//glazaror... se invoca al nuevo metodo para mantener la logica en un solo metodo pasandole null como parametro variablesIngreso
		return validarSubPartidaMotoresPiezasUsados(serie, fechaReferencia, null);
		/*Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		Long numpartnandi = serie.getNumpartnandi();
//		boolean indPartida = catalogoHelper.isValid(SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS);
		boolean indPartida = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS,SunatStringUtils.lpad(numpartnandi.toString(),10,'0')));
		if (!indPartida){
//			listError = catalogoHelper.getErrorMap("XXXX", new String[] {serie.getNumserie().toString(),numpartnandi.toString()});
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31879",new String[] { serie.getNumserie().toString(),numpartnandi.toString()});
		}
		return listError;*/
		
	}
	
	//glazaror... metodo optimizado...se trabaja con variablesIngreso
	@Override
	public Map<String, String> validarSubPartidaMotoresPiezasUsados(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		Long numpartnandi = serie.getNumpartnandi();
//		boolean indPartida = catalogoHelper.isValid(SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS);
		
		//glazaror... cuando se hacen validaciones a nivel de detalles (series, facturas, proveedores, etc) se debe usar el IngresoVariablesUtil
		//boolean indPartida = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS,SunatStringUtils.lpad(numpartnandi.toString(),10,'0')));
		boolean indPartida = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS, SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), variablesIngreso);
		if (!indPartida){
//			listError = catalogoHelper.getErrorMap("XXXX", new String[] {serie.getNumserie().toString(),numpartnandi.toString()});
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31879",new String[] { serie.getNumserie().toString(),numpartnandi.toString()});
		}
		return listError;
		
	}
	
	/**
	 * Verifica si la partida esta en el grupo de Motores y piezas
	 * @param serie
	 * @param fechaReferencia
	 * @return Mapa vacio si encontro la partida, caso contrario retorna el error
	 */
	public Map<String, String> validarSubPartidaMotoresPiezas(DatoSerie serie, Date fechaReferencia){
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		Long numpartnandi = serie.getNumpartnandi();
//		boolean indPartida = catalogoHelper.isValid(SunatStringUtils.lpad(numpartnandi.toString(),10,'0'), ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS);
		boolean indPartida = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBPARTIDA_MOTORESPIEZAS,SunatStringUtils.lpad(numpartnandi.toString(),10,'0')));
		if (!indPartida){
//			listError = catalogoHelper.getErrorMap("XXXX", new String[] {serie.getNumserie().toString(),numpartnandi.toString()});
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("XXXX",new String[] { serie.getNumserie().toString(),numpartnandi.toString()});   
		}
		return listError;
		
	}
	
	
	public Map<String, String> validarSubPartidaMotoresPiezasExoneradas(String numSerie, String numpartnandi, Date fechaReferencia) {
		Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		String subPartidaMotores = SunatStringUtils.lpad(numpartnandi.toString(),10,'0');
//		if (!CollectionUtils.isEmpty(catalogoHelper.getCatalogoValidacionService().validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_SUBPARTIDA_MOTORES_EXONERADOS, SunatStringUtils.toNotNull(subPartidaMotores)))){
		if (!CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_SUBPARTIDA_MOTORES_EXONERADOS, SunatStringUtils.toNotNull(subPartidaMotores)))){
//				listError = catalogoHelper.getErrorMap("XXXX", new String[] {numSerie, subPartidaMotores});		
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31880",new String[] { numSerie,numpartnandi.toString()});   
		}
		return listError;
	}
	
	//glazaror... metodo optimizado
	@Override
	public Map<String, String> validarSubPartidaMotoresPiezasExoneradas(String numSerie, String numpartnandi, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Map<String, String> listError=new HashMap<String, String>();
		String subPartidaMotores = SunatStringUtils.lpad(numpartnandi.toString(),10,'0');
		//glazaror... para validar a nivel de detalles se debe usar el utilitario IngresoVariablesUtil
		//if (!CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_SUBPARTIDA_MOTORES_EXONERADOS, SunatStringUtils.toNotNull(subPartidaMotores)))){
		
		if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, ConstantesGrupoCatalogo.GRUPO_SUBPARTIDA_MOTORES_EXONERADOS, SunatStringUtils.toNotNull(subPartidaMotores), variablesIngreso)) {
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31880",new String[] { numSerie,numpartnandi.toString()});
		}
		return listError;
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

*/
}
