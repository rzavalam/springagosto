/*
 * Clase que define el servicio de validaciones de las series
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
//import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService; //P427
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;



/**
 * The Class ValDetdua. Clase que define el servicio de validaciones de las series
 */
public class ValDetduaServiceImpl extends ValDuaAbstract implements ValDetdua{
        // private CatalogoHelperImpl catalogoHelper;
	//private FabricaDeServicios fabricaDeServicios; 
	private DisposicionMercanciaService disposicionMercanciaService; //P427
	/**
	 * Valida que el campo numserie de los elementos de la lista sean secuenciales de 1 a n.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param listSeries Elementos<DatoSerie>
	 * @return Map
	 */
	public Map<String, String> numserie(Elementos<DatoSerie> listSeries){
		Iterator<DatoSerie> it=listSeries.iterator();
		int i=1;
		boolean secuencial=false;
		while (it.hasNext()){
			secuencial= (i==it.next().getNumserie().intValue());
			i++;
			if (!secuencial)
				break;
		}
		return secuencial?new HashMap<String,String>():getDUAError("00042","Error secuencia series");
	}

	/**
	 * Valida el C�digo de aplicaci�n de ultractividad. Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codaplultra String, C�digo de aplicaci�n de ultractividad
	 * @return Map
	 */
	/*public Map<String, String> codaplultra(String codaplultra){
		if (FormatoAServiceImpl.getInstance().isValidCatalogo("I1", codaplultra))
			return new HashMap<String,String>();
		else
			return getDUAError("05040","Error catalogo codaplultra: "+codaplultra);
	}*/
	
	//LMVR RN 191
	 public Map<String, String> codaplultra(DatoSerie serie) {
			 	
				if(!SunatStringUtils.isEmptyTrim(serie.getCodaplultra()) ){		
					//if (FormatoAServiceImpl.getInstance().isValidCatalogo("I1", serie.getCodaplultra())){
					boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("I1", serie.getCodaplultra(),SunatDateUtils.getCurrentDate()));
					if (validaCatalogo){
						return new HashMap<String,String>();
					}else{
						return getDUAError("05040", new Object[]{serie.getNumserie(),serie.getCodaplultra()});
					}
	 			}else{
	 				return new HashMap<String,String>();
	}	
	}
	

	/**
	 * Valida el C�digo de unidades comerciales.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codunicomer String, C�digo de unidades comerciales
	 * @return Map
	 */
	public Map<String, String> codunicomer(String codunicomer){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("29", codunicomer))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("29", codunicomer,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00062","Error catalogo codunicomer");
	}	
		
	/**
	 * Valida el Cantidad de unidades comerciales.<br> 
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntunicomer BigDecimal, Cantidad de unidades comerciales
	 * @return Map
	 */
	public Map<String, String> cntunicomer(BigDecimal cntunicomer){
		if (cntunicomer!=null)
			return cntunicomer.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("00038","");
		else
			return getDUAError("00038","");
	}
	
	/**
	 * Valida el C�digo de clase de bultos.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codclasbul String,C�digo de clase de bultos
	 * @return Map
	 */
	public Map<String, String> codclasbul(String codclasbul){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("16", codclasbul))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("16", codclasbul ,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30298","Error catalogo codclasbul");	
	}	
	
	/**
	 * Valida la Cantidad de bultos.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntbultos BigDecimal, cantidad de bultos
	 * @return Map
	 */
	public Map<String, String> cntbultos(BigDecimal cntbultos){
		if (cntbultos!=null)
			return cntbultos.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("00030","");
		else
			return getDUAError("00030","");
	}
	
	/**
	 * Valida Cantidad de peso neto en Kg.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntpesoneto BigDecimal, Cantidad de peso neto en Kg
	 * @return Map
	 */
	public Map<String, String> cntpesoneto(BigDecimal cntpesoneto, Integer numserie){
		//SPTD_ADUADET 55-58
		if (cntpesoneto!=null){
			if (cntpesoneto.scale()>3)
//				return getDUAError("00028","PESO_NETO - "+cntpesoneto);
				return getDUAError("30353",new Object[]{numserie,cntpesoneto.doubleValue()});
			if (cntpesoneto.precision()>14)
//				return getDUAError("00028","PESO_NETO - "+cntpesoneto);
				return getDUAError("30353",new Object[]{numserie,cntpesoneto.doubleValue()});
			
//			return cntpesoneto.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("00028","PESO_NETO - ENVIADO:"+cntpesoneto.doubleValue());
			//MATC Riesgos tiene que ser mayor a cero
			return cntpesoneto.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("30353",new Object[]{numserie,cntpesoneto.doubleValue()});
		}else
//			return getDUAError("00028","PESO_NETO - ENVIADO:"+cntpesoneto);
			return getDUAError("30353",new Object[]{numserie,"null"});
	}
	 
	/**
	 * Valida la Cantidad de peso Bruto en Kg.<br>
	 * Valida que el par&aacute;metro cntpesobruto no sea menor a cntpesoneto.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntpesobruto BigDecimal, Cantidad de peso Bruto
	 * @param cntpesoneto BigDecimal,Cantidad de peso Neto
	 * @return Map
	 */
	public Map<String, String> cntpesobruto(BigDecimal cntpesobruto, BigDecimal cntpesoneto, Integer numserie){
		//SPTD_ADUADET 59-62
		if (cntpesobruto!=null){
			if (cntpesobruto.scale()>3)
//				return getDUAError("0029","PESO_BRUTO - "+cntpesobruto);
				return getDUAError("30354",new Object[]{numserie,cntpesobruto.doubleValue()});
			if (cntpesobruto.precision()>14)
//				return getDUAError("0029","PESO_BRUTO - "+cntpesobruto);
				return getDUAError("30354",new Object[]{numserie,cntpesobruto.doubleValue()});
//			return cntpesobruto.compareTo(cntpesoneto)>=0?new HashMap<String,String>():getDUAError("0029","PESO_BRUTO - ENVIADO:"+cntpesobruto.doubleValue());
			return cntpesobruto.compareTo(cntpesoneto)>=0?new HashMap<String,String>():getDUAError("30816",new Object[]{numserie,cntpesobruto.doubleValue(),cntpesoneto.doubleValue()});
		}else
//			return getDUAError("0029","PESO_BRUTO - ENVIADO:"+cntpesobruto);
			return getDUAError("30354",new Object[]{numserie,"null"});
	}	
	
	
	/**
	 * Valida el Peso bruto de veh�culos usados.<br>
	 * Valida que el par&acute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntpesovehic BigDecimal, Peso bruto de veh�culos usados
	 * @return Map
	 */
	public Map<String, String> cntpesovehic(BigDecimal cntpesovehic){
		if (cntpesovehic!=null)
			return cntpesovehic.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30046","");
		else
			return new HashMap<String,String>();
	}

	
	/**
	 * Valida el C�digo de Unidades F�sicas.
	 * 
	 * @param codunifis String, C�digo de Unidades F�sicas
	 * @return el mapa de errores
	 */
	public Map<String, String> codunifis(String codunifis){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("29", codunifis))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("29", codunifis,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30299","Error catalogo codunifis");	
	}

	/**
	 * Valida la Cantidad de unidades f�sicas.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntunifis BigDecimal,Cantidad de unidades f�sicas
	 * @return Map
	 */
	public Map<String, String> cntunifis(BigDecimal cntunifis){
		//SPTD_ADUADET1 63-66
		if (cntunifis!=null)
			return cntunifis.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00031","UNID_FIQTY - ENVIADO:"+cntunifis.doubleValue());
		else
			return getDUAError("00031","UNID_FIQTY - ENVIADO:"+cntunifis);
	}

	/**
	 * Valida el C�digo de unidades comerciales para el c�lculo del ISC
	 * 
	 * @param codunicomisc String, C�digo de unidades comerciales para el c�lculo del ISC.
	 * @return el mapa de errores
	 */
	public Map<String, String> codunicomisc(String codunicomisc){
		if (codunicomisc!=null)
		return !SunatStringUtils.isEmptyTrim(codunicomisc)?new HashMap<String,String>():getDUAError("30313","");
		else
			return new HashMap<String,String>();
	}

	/**
	 * Valida la cantidad de unidades comerciales para el c�lculo del ISC.<br>
	 * Valida que el par&aacute;metro sea mayor o igual a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param cntunicomisc BigDecimal, cantidad de unidades comerciales para el c�lculo del ISC
	 * @return Map
	 */
	public Map<String, String> cntunicomisc(BigDecimal cntunicomisc){
		if (cntunicomisc!=null)
			return cntunicomisc.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("01087","");
		else
			return new HashMap<String,String>();
	}

	
	/**
	 * Valida el N�mero de partida nandina.<br>
	 * 
	 * @param numpartnandi Long, N�mero de partida nandina 
	 * @return el mapa de errores
	 */
	public Map<String, String> numpartnandi(Long numpartnandi){
		return SunatNumberUtils.isGreaterThanZero(numpartnandi)?new HashMap<String,String>():getDUAError("00045","");
	}

	/**
	 * Valida el N�mero de partida naladisa
	 * 
	 * @param numpartnalad String, N�mero de partida naladisa
	 * @return el mapa de errores
	 */
	public Map<String, String> numpartnalad(String numpartnalad){
		if (numpartnalad!=null && !"0".equals(numpartnalad))
			return SunatNumberUtils.isGreaterThanZero(new Long(numpartnalad))?new HashMap<String,String>():getDUAError("00047","");
		return new HashMap<String,String>();
	}
	
	/**
	 * Validar N�mero de partida naladisa.
	 * @deprecated No aplica
	 * @param numpartnalad String
	 * @param codTransaccion String
	 * @return el mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2469, descServicio="valida la partida naladisa en la base de datos")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"numpartnalad","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=2469,numSecEjec=322,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public Map<String, String> validarNumPartNalad(String numpartnalad,String codTransaccion){
		Map<String,String> error=   new HashMap<String,String>();
		//Se ha cerrado la vigencia en el orquestador por que ya no aplica
		
		/*if (numpartnalad!=null && !"0".equals(numpartnalad)){
			Map<String,Object> params=new HashMap<String, Object>();
			params.put("tlib", "I");
			params.put("cnan", numpartnalad);
			params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
			int count=FormatoAServiceImpl.getInstance().getNandlibeDAO().count(params);
			if(count==0)
				error=getDUAError("00047","");
	    }*/
		return error;
	}
	
	//lmvr RN 163 - II
	
	@ServicioAnnot(tipo="V",codServicio=2490, descServicio="valida valCantDocuTrans")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie"})
	@OrquestaDespaAnnot(codServInstancia=2490,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
 public Map<String, String> valCantDocuTrans(DatoSerie serie) {
		
		// List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		// Map<String,String> error=   new HashMap<String,String>();
		 
			int cantidadDocTransporte =  getCantidadDocTransporte(serie); 

			if(cantidadDocTransporte>1){
 				//lstErrores.add(catalogoHelper.getErrorMap("30578",new Object[]{serie.getNumserie()}));
 				//SERIE[{0}]: EL DOCUMENTO DE TRANSPORTE DEBE SER EL MISMO PARA TODA LA SERIE
 				return getDUAError("30578", new Object[]{serie.getNumserie()});
 				//return lstErrores;
 			}
			return new HashMap<String,String>();
	}
	
	
	
	//lmvr RN 176
	@ServicioAnnot(tipo="V",codServicio=2491, descServicio="valida valCodTipoFleteDocutrans")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2491,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
 public Map<String, String> valCodTipoFleteDocutrans(Declaracion declaracion) {
		
		DUA dua=declaracion.getDua();
		
		Elementos<DatoSerie>  listSeries =declaracion.getDua().getListSeries();
		Elementos<DatoSerie>  listSeries2 =declaracion.getDua().getListSeries();
		
		//List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		
		Integer numeserie  = 0;
		String codtipoflete ="";
		String numdocutrans="";
		
		Integer numeserie2  = 0;
		String codtipoflete2 ="";
		String numdocutrans2="";
		
		if(!CollectionUtils.isEmpty(listSeries) ){
			for(DatoSerie serie:listSeries){
				
				numeserie  = serie.getNumserie();
				codtipoflete = serie.getCodtipoflete();
				List<DatoFacturaref> listnumfactura = getFacturaRef(dua,serie);
				//numdocutrans = getDocTransporte(dua,serie).toString();
				DatoDocTransporte numdocutransTrans = getDocTransporte(dua, serie);
				if(numdocutransTrans==null){
					return new HashMap<String,String>();
				}
				numdocutrans = numdocutransTrans.getNumdoctransporte().toString();
				for(DatoSerie serie2:listSeries2) {
					numeserie2  = serie2.getNumserie();
					if(!numeserie.equals(numeserie2)){
						codtipoflete2 = serie2.getCodtipoflete();
						//numdocutrans2 = getDocTransporte(dua,serie2).toString();
						//PAS20155E220200035 esta mal envaidose el parametro serie debe ser seri2 para que no afecta solo para ofico
						DatoDocTransporte numdocutransTrans2 = new DatoDocTransporte();
						if("1019".equals(declaracion.getCodtipotrans())){
							numdocutransTrans2 = getDocTransporte(dua, serie2);
						}else{
							numdocutransTrans2 = getDocTransporte(dua, serie);	
						}
						
						if(numdocutransTrans2==null){
							return new HashMap<String,String>();
						}
						numdocutrans2 = numdocutransTrans2.getNumdoctransporte().toString();

						List<DatoFacturaref> listnumfactura2 = getFacturaRef(dua,serie2);
						if((numdocutrans.equals(numdocutrans2)) && (compararFacturas(listnumfactura, listnumfactura2)) && !codtipoflete.equals(codtipoflete2) ){
							//lstErrores.add(catalogoHelper.getErrorMap("30579",new Object[]{numeserie,numeserie2,codtipoflete,codtipoflete2 }));
							//glazaror... evitamos el uso del metodo getDUAError
							//return getDUAError("30579", new Object[]{numeserie,numeserie2,codtipoflete,codtipoflete2 });
							//SERIES[{0}-{1}] QUE TIENEN EL MISMO DOCUMENTO DE TRANSPORTE Y MISMA FACTURA NO PUEDEN TENER TIPO DE PRORRATEO DE FLETE DISTINTO [{2}�{3}]
							// return lstErrores;
							
							//glazaror... se usa el servicio CatalogoAyudaService.getError
							CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
							return catalogoAyudaService.getError("30579", new String[] {numeserie.toString(), numeserie2.toString(), codtipoflete, codtipoflete2});
						}
						
					}

				}
			}
				
		 }
		return new HashMap<String,String>();
		//return lstErrores;
	}
		
		
	    //lmvr RN 210
		@ServicioAnnot(tipo="V",codServicio=2492, descServicio="valida valPartidaEER")
		@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie"})
		@OrquestaDespaAnnot(codServInstancia=2492,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	 public Map<String, String> valPartidaEER(DatoSerie serie) {
			//glazaror... se invoca al metodo optimizado solo para mantener la logica en un solo metodo 
			return valPartidaEER(serie, null);
		}
		
		//glazaror: optimizacion del metodo valPartidaEER
		@ServicioAnnot(tipo="V",codServicio=2492, descServicio="valida valPartidaEER")
		@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie", "variablesIngreso"})
		@OrquestaDespaAnnot(codServInstancia=9145,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> valPartidaEER(DatoSerie serie, Map<String, Object> variablesIngreso) {
					
			String numpartnandi = serie.getNumpartnandi().toString();
			
			//List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
			
			//if(!FormatoAServiceImpl.getInstance().isValidCatalogo(ConstantesDataCatalogo.PARTIDA_ERR, numpartnandi)) {
			//boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesDataCatalogo.PARTIDA_ERR, numpartnandi,SunatDateUtils.getCurrentDate()));
			//glazaror... se invoca al utilitario manejador de catalogos IngresoVariablesUtil
			boolean validaCatalogo = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesDataCatalogo.PARTIDA_ERR, numpartnandi, variablesIngreso);
			
			if (!validaCatalogo){
				return new HashMap<String,String>();
				//return lstErrores;
			}else{
				//glazaror... se usa el servicio CatalogoAyudaService.getError
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				return catalogoAyudaService.getError("30582", new String[] {serie.getNumserie().toString(), numpartnandi});
				
				//lstErrores.add(catalogoHelper.getErrorMap("30582",new Object[]{serie.getNumserie(),numpartnandi}));
				//return getDUAError("30582", new Object[]{serie.getNumserie(),numpartnandi});
				//SERIE[{0}]: SPN [{1}] SE ENCUENTRA ASOCIADA A ENVIOS DE ENTREGA RAPIDA VIA AEREA
			//return lstErrores;
			}
	}
		
	//glazaror: optimizacion del metodo valCodiLiberEER
	@ServicioAnnot(tipo="V",codServicio=2493, descServicio="valida valCodiLiberEER (optimizado)")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie", "variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9143,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> valCodiLiberEER (DatoSerie serie, Map<String, Object> variablesIngreso) {
			
		String codiliber = serie.getCodliberatorio().toString();
		
		//List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
	
		//if(!FormatoAServiceImpl.getInstance().isValidCatalogo(ConstantesDataCatalogo.CODILIBER_EER, codiliber)) {
		//boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesDataCatalogo.CODILIBER_EER, codiliber,SunatDateUtils.getCurrentDate()));
		//glazaror... se invoca al utilitario manejador de catalogos IngresoVariablesUtil
		boolean validaCatalogo = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesDataCatalogo.CODILIBER_EER, codiliber, variablesIngreso);
		if (!validaCatalogo){
			//return lstErrores;
			return new HashMap<String,String>();
		} else{
			//glazaror... se usa el servicio CatalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			return catalogoAyudaService.getError("30583", new String[] {serie.getNumserie().toString(), codiliber});
			//lstErrores.add(catalogoHelper.getErrorMap("30583",new Object[]{serie.getNumserie(),codiliber}));
			//return getDUAError("30583", new Object[]{serie.getNumserie(),codiliber});
			//SERIE[{0}]: C�DIGO LIBERATORIO [{1}] SE ENCUENTRA ASOCIADO A ENVIOS DE ENTREGA R�PIDA VIA A�REA
			//catalogoHelper.getCatalogoAyudaService().
		//return lstErrores;
		}
	}
		
		
		//lmvr RN 211
		@ServicioAnnot(tipo="V",codServicio=2493, descServicio="valida valCodiLiberEER")
		@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie"})
		@OrquestaDespaAnnot(codServInstancia=2493,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	 public Map<String, String> valCodiLiberEER (DatoSerie serie) {
			//glazaror: optimizacion del metodo valCodiLiberEER... se invoca al metodo optimizado... en este caso solo para mantener la logica de validacion en un solo metodo
			return valCodiLiberEER(serie, null);
		}
				
		
		@ServicioAnnot(tipo="V",codServicio=2494, descServicio="valida valCodiLiberPostal")
		@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie"})
		@OrquestaDespaAnnot(codServInstancia=2494,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	 public Map<String, String> valCodiLiberPostal (DatoSerie serie) {
			//glazaror: optimizacion del metodo valCodiLiberPostal... se invoca al metodo optimizado... en este caso solo para mantener la logica de validacion en un solo metodo
			return valCodiLiberPostal(serie, null);
		}
		
	//glazaror: optimizacion del metodo valCodiLiberPostal
	@ServicioAnnot(tipo="V",codServicio=2494, descServicio="valida valCodiLiberPostal")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie", "variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9144,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> valCodiLiberPostal (DatoSerie serie, Map<String, Object> variablesIngreso) {
		String codiliber = serie.getCodliberatorio().toString();
		
		//List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		
		//if(!FormatoAServiceImpl.getInstance().isValidCatalogo(ConstantesDataCatalogo.CODILIBER_POSTAL, codiliber)) {
		//boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesDataCatalogo.CODILIBER_POSTAL, codiliber,SunatDateUtils.getCurrentDate()));
		//glazaror... se invoca al utilitario manejador de catalogos IngresoVariablesUtil
		boolean validaCatalogo = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesDataCatalogo.CODILIBER_POSTAL, codiliber, variablesIngreso);
		if (!validaCatalogo) {
			return new HashMap<String,String>();
			//return lstErrores;
		} else {
			//glazaror... se usa el servicio CatalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			return catalogoAyudaService.getError("30584", new String[] {serie.getNumserie().toString(), codiliber});
			//lstErrores.add(catalogoHelper.getErrorMap("30584",new Object[]{serie.getNumserie(),codiliber}));
			//return getDUAError("30584", new Object[]{serie.getNumserie(),codiliber});
			//SERIE[{0}]. CODIGO LIBERATORIO [{1}] SE ENCUENTRA ASOCIADO A ENVIOS DE ENTREGA RAPIDA VIA POSTAL
		//return lstErrores;
		}
	}
			
	// pruizcr P427. Abandono Legal -Rectificacion de la Declaracion
		 public Map<String, String> validarDisposicionTotalPorSerie(Declaracion declaracionBD,DatoSerie datoSerie) {
				if(!SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal()) ){		
					String numeroSerie=datoSerie.getNumserie().toString();
					int cntUniComerTransmitidas = SunatNumberUtils.toInteger(datoSerie.getCntunicomer());
					//para la serie buscamos si tiene disposicion de mercancias
					String numCorredoc=datoSerie.getNumcorredoc().toString();
					String numsecSerie=datoSerie.getNumserie().toString();
					
					int cntUniComerDispuestas =  disposicionMercanciaService.validarTotalUnidadesComerDispuestas(numeroSerie, numCorredoc);
					if(cntUniComerDispuestas>0){//verifica que aun haya saldo
						List<DatoSerie> lstSeriesBD = declaracionBD.getDua().getListSeries();
						int cntUniComerdeclaradas= 0;
						for(DatoSerie  datoSerieBD: lstSeriesBD){
							if(numeroSerie==datoSerieBD.getNumserie().toString()){
								cntUniComerdeclaradas = SunatNumberUtils.toInteger(datoSerieBD.getCntunicomer());  
								int cntUniComerSaldo = cntUniComerdeclaradas-cntUniComerDispuestas; 
								
								if (cntUniComerSaldo ==0 || (cntUniComerTransmitidas> cntUniComerSaldo) ){
									 // ya no hay mercanc�a para disponer
									 //El sistema bloquea y muestra el mensaje
									List<Map<String,Object>> lstMercDispuestas =null;
									lstMercDispuestas=disposicionMercanciaService.consultarDatosMercanciaDispuestaBySerie(numsecSerie,numCorredoc);
									if(lstMercDispuestas.size()>0){

										String numCorreDocRecti=declaracionBD.getDua().getNumcorredoc().toString(); 
										
									//	for (DatoSerie datoSerieBDXML : declaracionBD.getDua().getListSeries()) {
											 //String serieBD= datoSerieBDXML.getNumserie().toString();
											 //String numSerieRecti=serieBD;
											 //lstMercDispuestas= disposicionMercanciaService.consultarDatosMercanciaDispuestaBySerie(numCorreDocRecti,numSerieRecti);
									    	  int varMerDis=lstMercDispuestas.size();
									  			for(int i=0;i<=varMerDis-1;i++){
									  				String mensajeBloqueo =" ";
									  			//lstResultadoMercancia1.addAll(lstMercDispuestas);
									  				 String item= (String) lstMercDispuestas.get(i).get("NUM_SECITEM").toString();
												     String seriemd= (String) lstMercDispuestas.get(i).get("NUM_SECSERIE").toString();
												     String docDispo= (String) lstMercDispuestas.get(i).get("NUM_DOCDISPOSICION").toString();
												     String fecDocDispo= (String) lstMercDispuestas.get(i).get("FEC_DOCDISPOSICION").toString();
												     String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
												     mensajeBloqueo="�tem ["+item+"] de la serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
										                     +docDispo+"] de fecha ["+fecDoc1+"]";	     
												     return getDUAError("31885",new Object[]{item,seriemd,docDispo,fecDoc1});//se debe mostrar como warning 
												   
									  			}	
										// }
										
										
										
										
										
										
										
									}
								}
							}
						}
						
					}
		
				
				}
				return new HashMap<String,String>();
		 }
	//fin P427
	
	
	

	/**
	 * Valida N�mero de partidad nabandina
	 * 
	 * @param numpartnaban String, N�mero de partidad nabandina
	 * @return el mapa de errores
	 */
	public Map<String, String> numpartnaban(String numpartnaban){
		if (numpartnaban!=null && !"0".equals(numpartnaban))
			return SunatNumberUtils.isGreaterThanZero(new Long(numpartnaban))?new HashMap<String,String>():getDUAError("00047","");
		return new HashMap<String,String>();
	}

	/**
	 * Valida el N�mero de partida correlacionada para estabilidad tributaria.
	 * Valida que el par&&acute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numpartcorre String, N�mero de partida correlacionada para estabilidad tributaria
	 * @return Map
	 */
	public Map<String, String> numpartcorre(String numpartcorre){
		if (numpartcorre!=null && !"0".equals(numpartcorre))
			return new Long(numpartcorre).longValue()>0?new HashMap<String,String>():getDUAError("00199","");
		else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo del trato preferencial internacional
	 * 
	 * @param codconvinter Integer, C�digo del trato preferencial internacional
	 * @return el mapa de errores
	 */
	public Map<String, String> codconvinter(Integer codconvinter){
//		if (FormatoAServiceImpl.getInstance().isValidCatalogo("351", String.valueOf(codconvinter)))
			return new HashMap<String,String>();
//		else
//			return getDUAError("00053","Error catalogo codconvinter");	
	}

	/**
	 * Valida el C�digo del trato preferencial nacional
	 * 
	 * @param codtratprefe Integer, C�digo del trato preferencial nacional
	 * @return el mapa de errores
	 */
	public Map<String, String> codtratprefe(Integer codtratprefe){
//		if (FormatoAServiceImpl.getInstance().isValidCatalogo("353", String.valueOf(codtratprefe)))
			return new HashMap<String,String>();
//		else
//			return getDUAError("00053","Error catalogo codtratprefe");	
	}

	/**
	 * Valida el c�digo de pa�s de origen
	 * 
	 * @param codpaisorige String, c�digo de pa�s de origen
	 * @return el mapa de errores
	 */
	public Map<String, String> codpaisorige(String codpaisorige){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisorige))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisorige,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("05565","Error catalogo codpaisorige");	
	}

	/**
	 * Valida el c�digo de pa�s de adquisici�n
	 * 
	 * @param codpaisadqui String, C�digo de pa�s de adquisici�n
	 * @return el mapa de errores
	 */
	public Map<String, String> codpaisadqui(String codpaisadqui){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisadqui))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisadqui,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00050","Error catalogo codpaisadqui");	
	}

	/**
	 * Valida el codigo de pais de destino.
	 * 
	 * @param codpaisdestino String
	 * @return el mapa de errores
	 */
	public Map<String, String> codpaisdestino(String codpaisdestino){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisdestino))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisdestino,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00219","Error catalogo codpaisdestino");	
	}

	/**
	 * Valida el C�digo de moneda de transacci�n
	 * 
	 * @param codmoneda String, C�digo de moneda de transacci�n
	 * @return el mapa de errores
	 */
	public Map<String, String> codmoneda(String codmoneda){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J1", codmoneda))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J1", codmoneda,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30047","Error catalogo codmoneda Serie Envio: "+codmoneda);
	}

	/**
	 * Valida el Monto de fob en moneda de transacci�n.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofobmon BigDecimal. Monto de fob en moneda de transacci�n
	 * @return Map
	 */
	public Map<String, String> mtofobmon(BigDecimal mtofobmon){
		if (mtofobmon!=null)
			return mtofobmon.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30048","");
		else
			return getDUAError("30048","");
	}

	/**
	 * Valida el Monto de FOB en d�lares.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofobdol BigDecimal. Monto de FOB en d�lares
	 * @return Map
	 */
	public Map<String, String> mtofobdol(BigDecimal mtofobdol){
		if (mtofobdol!=null)
			return mtofobdol.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("30349","");
		else
			return getDUAError("30349","");
	}

	/**
	 * Valida el Monto de Flete en d�lares.<br>
	 * Valida que el par&aacute;metro sea mayor a cero
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofledol BigDecimal, Monto de Flete en d�lares
	 * @return Map
	 */
	public Map<String, String> mtofledol(BigDecimal mtofledol){
		if (mtofledol!=null)
			return mtofledol.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00034","");
		else
			return getDUAError("00034","");
	}

	/**
	 * Valida el Monto de Seguro en d�lares.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtosegdol BigDecimal. Monto de Seguro en d�lares
	 * @return Map
	 */
	public Map<String, String> mtosegdol(BigDecimal mtosegdol){
		if (mtosegdol!=null)
			return mtosegdol.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00035","");
		else
			return getDUAError("00035","");
	}

	/**
	 * Valida el Monto de Ajuste.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtoajuste BigDecimal. Monto de ajuste.
	 * @return Map
	 */
	public Map<String, String> mtoajuste(BigDecimal mtoajuste){
		if (mtoajuste!=null)
			return mtoajuste.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30049","");
		else
			//return getDUAError("30049","");
			return new HashMap<String,String>();
	}

	/**
	 * Valida el Monto de Valor en Aduanas.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtovaladuana BigDecimal. Monto de Valor en Aduanas
	 * @return Map
	 */
	public Map<String, String> mtovaladuana(BigDecimal mtovaladuana){
		if (mtovaladuana!=null)
			return mtovaladuana.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30050","");
		else
			return getDUAError("30050","");
	}

	/**
	 * Valida el C�digo de Tipo de Seguro 
	 * 
	 * @param codtiposeg String. C�digo de Tipo de Seguro
	 * @return el mapa de errores
	 */
	public Map<String, String> codtiposeg(String codtiposeg){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("62", codtiposeg))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("62", codtiposeg,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00082","Error catalogo codtiposeg "+codtiposeg);
	}

	/**
	 * Valida el C�digo de Tipo de prorrateo de flete.
	 * 
	 * @param codtipoflete String, C�digo de Tipo de prorrateo de flete 
	 * @return el mapa de errores
	 */
	public Map<String, String> codtipoflete(String codtipoflete){
		if (!SunatStringUtils.isEmptyTrim(codtipoflete)){
			if (codtipoflete.length()==1){
				//if (FormatoAServiceImpl.getInstance().isValidCatalogo("368", codtipoflete))
				boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("368", codtipoflete,SunatDateUtils.getCurrentDate()));
				if (validaCatalogo)
					return new HashMap<String,String>();
				else
					return getDUAError("08232","Error catalogo codtipoflete");	
			}else
				return getDUAError("08232","");
		}else
			return getDUAError("08232","");
	}

	/**
	 * Valida la Descripci�n comercial.
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea mayor a 200 caracteres.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param descomercial String. Descripci�n comercial 
	 * @return Map
	 */	
	public Map<String, String> descomercial(String descomercial){
		//SPTD_ADUADET1 67-70
		return (!SunatStringUtils.isEmptyTrim(descomercial) && descomercial.trim().length()<=200)?new HashMap<String,String>():getDUAError("30051","DESC_COMER - ENVIADO:"+descomercial);
	}

	/**
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea mayor a 200 caracteres.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desformapres String
	 * @return Map
	 */	
	public Map<String, String> desformapres(String desformapres){
		
		if(SunatStringUtils.isEmptyTrim(desformapres))
			return new HashMap<String, String>();
		
		return (!SunatStringUtils.isEmptyTrim(desformapres) && desformapres.trim().length()<=200)?new HashMap<String,String>():getDUAError("30052","");
	}

	/**
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea mayor a 200 caracteres.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desmatecomp String
	 * @return Map
	 */	
	public Map<String, String> desmatecomp(String desmatecomp){
		if (!SunatStringUtils.isEmptyTrim(desmatecomp))
			return (desmatecomp.trim().length()<=200)?new HashMap<String,String>():getDUAError("30053","");
		return new HashMap<String,String>();
	}

	/**
	 * Valida la Descripci�n de uso y aplicaci�n.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea mayor a 200 caracteres.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desusoaplica String
	 * @return Map
	 */	
	public Map<String, String> desusoaplica(String desusoaplica){
		if(!SunatStringUtils.isEmptyTrim(desusoaplica) )
		{
			return desusoaplica.trim().length()<=200 ? new HashMap<String,String>():getDUAError("30054","");
		}
		return new HashMap<String,String>(); 
	}

	/**
	 * Valida la Descripci�n de Otras caracteristicas.   
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea mayor a 200 caracteres.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desotros String. Descripci�n de Otras caracteristicas.
	 * @return Map
	 */	
	public Map<String, String> desotros(String desotros){
		if (!SunatStringUtils.isEmptyTrim(desotros))
			return (desotros.trim().length()<=200)?new HashMap<String,String>():getDUAError("30055","");
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo de estado de la mercanc�a.
	 * 
	 * @param codestamerca String. C�digo de estado de la mercanc�a.
	 * @return el mapa de errores
	 */
	public Map<String, String> codestamerca(String codestamerca){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("25", codestamerca))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("25", codestamerca,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00081","Error catalogo codestamerca: "+codestamerca);	
	}

	/**
	 * Valida que el par&aacute;metro tenga un valor
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codcuota String
	 * @return Map
	 */
	public Map<String, String> codcuota(String codcuota){
		return !SunatStringUtils.isEmptyTrim(codcuota)?new HashMap<String,String>():getDUAError("30056","");
	}

	/**
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codubigeo String
	 * @return Map
	 */
	public Map<String, String> codubigeo(String codubigeo){
		if (!SunatStringUtils.isEmptyTrim(codubigeo)){
			//validar contra tabla ubigeo
			return new HashMap<String,String>();
		}else
			return getDUAError("30057","");
	}

	/**
	 * Valida la Fecha de expiracion de la mercancia perecible.
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated Ya no se realiza validacion.
	 * @param fecexpiracion Date. Fecha de expiracion de la mercancia perecible.
	 * @return Map
	 */
	public Map<String, String> fecexpiracion(Date fecexpiracion){
//		return fecexpiracion!=null?new HashMap<String,String>():getDUAError("30058","");
		return new HashMap<String,String>();
	}

	/**
	 * Validar C�digo de tipo de tasa a aplicar.<br>
	 * @deprecated Validar el metodo, no realiza validacion alguna.
	 * @param codtnan String
	 * @return el mapa de errores
	 */
	public Map<String, String> codtnan(String codtnan){
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo del tipo de margen.<br>
	 * Valida que el par&aacute;metro sea numerico.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipomarge String. C�digo del tipo de margen.
	 * @return Map
	 */
	public Map<String, String> codtipomarge(String codtipomarge){
		//SPTD_ADUADET1 101-104
		if (!SunatStringUtils.isEmptyTrim(codtipomarge))
			return SunatStringUtils.isNumeric(codtipomarge)?new HashMap<String,String>():getDUAError("30060","TIPO_MARGE - ENVIADO:"+codtipomarge);//FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMap("0048","TIPO_MARGE - ENVIADO:"+codtipomarge);
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo liberatorio.
	 * @deprecated Ya no se valida.
	 * @param codliberatorio Integer. C�digo liberatorio.
	 * @return el mapa de errores
	 */
	public Map<String, String> codliberatorio(Integer codliberatorio){
		
//		if(codliberatorio == null || codliberatorio == 0 )
			return new HashMap<String,String>();
		
//		if (FormatoAServiceImpl.getInstance().isValidCatalogo("352", String.valueOf(codliberatorio)))
//			return new HashMap<String,String>();
//		else
//			return getDUAError("00052","Error catalogo codliberatorio");	
	}

	/**
	 * Valida Indicador de acogimiento a documento cancelatorio para cod. lib 4201 o 4202
	 * @deprecated Ya no se valida
	 * @param valindcodlib String. Indicador de acogimiento
	 * @return el mapa de errores
	 */
	public Map<String, String> valindcodlib(String valindcodlib){
		return new HashMap<String,String>();
	}

	/**
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param deslugar String
	 * @return Map
	 */
	public Map<String, String> deslugar(String deslugar){
		return !SunatStringUtils.isEmptyTrim(deslugar)?new HashMap<String,String>():getDUAError("30062","");
	}

	/**
	 * Valida el Precio de venta al publico en moneda nacional.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param valpreciovta BigDecimal. Precio de venta al publico en moneda nacional.
	 * @return Map
	 */
	public Map<String, String> valpreciovta(BigDecimal valpreciovta){
		if (valpreciovta!=null)
			return valpreciovta.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30063","");
		else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el valor estimado.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param valestimado BigDecimal
	 * @return Map
	 */
	public Map<String, String> valestimado(BigDecimal valestimado){
		if (valestimado!=null)
			return valestimado.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30064","");
		else
			return new HashMap<String,String>();
	}
	
	/**
	 * Valida el Valor FOB por peso neto.
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofobnet BigDecimal. Valor FOB por peso neto.
	 * @return Map
	 */
	public Map<String, String> mtofobnet(BigDecimal mtofobnet){
		if (mtofobnet!=null)
			return mtofobnet.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30319","");
		else
			return getDUAError("30319","");
	}
	
	/**
	 * Valida el C�digo del valor de ajuste.
	 * 
	 * @param codvalajuste String. C�digo del valor de ajuste.
	 * @return el mapa de errores
	 */
	public Map<String, String> codvalajuste(String codvalajuste){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("79", codvalajuste))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("79", codvalajuste,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30065","Error catalogo codvalajuste");
	}	

	/**
	 * Valida el indicador de la zona franca.
	 * 
	 * @param indzonafranca String
	 * @return el mapa de errores
	 */
	public Map<String, String> indzonafranca(String indzonafranca){
		return !SunatStringUtils.isEmptyTrim(indzonafranca)?new HashMap<String,String>():getDUAError("00193","");
	}

	/**
	 * Valida la Descripci�n de zona franca.<br>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param deszonafranca String. Descripci�n de zona franca.
	 * @return el mapa de errores
	 */	
	public Map<String, String> deszonafranca(String deszonafranca){
//		return !SunatStringUtils.isEmptyTrim(deszonafranca)?new HashMap<String,String>():getDUAError("00194","");
		//TODO Definifir que se va a validar, Es condicional y en otros casos no aplica.
		return new HashMap<String,String>();
	}	

	@ServicioAnnot(tipo = "V", codServicio = 3507, descServicio = "Valida el c�digo de la regi�n origen/destino de la serie")
	@Override
	public Map<String, String> codRegion(DatoSerie serie, Date fechaReferencia){
		Map<String,String> result = new HashMap<String,String>();
		if(!SunatStringUtils.isEmptyTrim(serie.getCodRegion())) {
			boolean esCodigoRegionValido = CollectionUtils.isEmpty(((CatalogoValidaService)
					fabricaDeServicios.getService("Ayuda.catalogoValidaService")).
					validarElementoCat("145", serie.getCodRegion(), fechaReferencia));
			if(!esCodigoRegionValido) {
				result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
	        			"37104", new String[] {serie.getNumserie().toString(), serie.getCodRegion()});
			}
		}
		return result;
		
	}
	
//	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
//		this.catalogoHelper = catalogoHelper;
//	}	
	
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
