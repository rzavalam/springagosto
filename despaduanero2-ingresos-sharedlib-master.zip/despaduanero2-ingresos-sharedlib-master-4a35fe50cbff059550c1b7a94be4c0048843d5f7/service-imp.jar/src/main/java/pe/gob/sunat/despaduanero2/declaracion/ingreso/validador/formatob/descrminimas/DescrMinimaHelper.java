package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

import java.util.List;

/**
 * Created by amancillaa on 19/06/14.
 */
public class DescrMinimaHelper
{
    public static boolean tieneNuevaEstructura(List<DatoDescrMinima> listDecrMinima)
    {

        boolean nuevaEstructura = false;

        if (!CollectionUtils.isEmpty(listDecrMinima))
            for (DatoDescrMinima descrMinima: listDecrMinima)
            {
                if (noTieneNuevaEstructura(descrMinima))
                {
                    nuevaEstructura = false;
                    break;
                }
                else
                {
                    nuevaEstructura = true;
                }
            }

        return nuevaEstructura;
    }

    public static boolean noTieneNuevaEstructura(DatoDescrMinima descrMinima)
    {
        String codigoEstructura = descrMinima != null?descrMinima.getCodtipdescr().trim():"";

        return codigoEstructura.length()==6 ? false : true;//se cambia de 4 a 6 14-08-2014 arey los campos de nueva estructura tiene 6
    }

    public static DatoDescrMinima getDescripcionMinimaItemByTipo(DatoItem item,String codigoTipoDesc) {

        //pase de descr miniimas

        for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
            if (SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), codigoTipoDesc)) {
                return descrMinima;
            }
        }
        return null;
    }
}
