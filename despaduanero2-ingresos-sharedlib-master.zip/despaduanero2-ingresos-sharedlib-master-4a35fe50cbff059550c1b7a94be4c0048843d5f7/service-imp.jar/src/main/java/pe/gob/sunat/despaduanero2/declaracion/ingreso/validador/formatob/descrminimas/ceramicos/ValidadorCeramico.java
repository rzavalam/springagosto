package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ceramicos;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap; 
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract; 
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem; 
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion; 
//solo se quitaron imports que estaban de mas PAS20175E220200079
public class ValidadorCeramico extends ValidadorAbstract{
  public static final String UNIDAD_COMERCIAL = "M2";  
  public static final String COD_ASOC_CATA    = "017";    
  public static final String CATALOGO_COMPONENTE = "450";

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception {
    List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErroresDescrMin)){
          lstErroresDescrMin.addAll(validarUnidadComercialCeramicos(objeto, dua));
          lstErroresDescrMin.addAll(validarNombreProductoCeramico(objeto,dua));
          lstErroresDescrMin.addAll(validarMarcaComercialCeramicos(objeto));
          lstErroresDescrMin.addAll(validarModeloComercialCeramicos(objeto));
          lstErroresDescrMin.addAll(validarAcabadoProductoCeramico(objeto));
          lstErroresDescrMin.addAll(validarMateriaPrimaCeramicos(objeto));
          lstErroresDescrMin.addAll(validarMoldeoCeramico(objeto));
          lstErroresDescrMin.addAll(validarCoccionCeramico(objeto));
          lstErroresDescrMin.addAll(validarUsoCeramico(objeto));
          lstErroresDescrMin.addAll(validarColorCeramico(objeto));
          lstErroresDescrMin.addAll(validarDimensionesCeramicos(objeto));
          lstErroresDescrMin.addAll(validarCapacidadAbsorcionCeramico(objeto));
      }

    return lstErroresDescrMin;
  }

  public List<ErrorDescrMinima>  validarUnidadComercialCeramicos (ModelAbstract objeto, Declaracion dua){
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);
    Ceramico ceramicos = (Ceramico) objeto;
    String datoAValidar = item.getCodunidcomer().trim();
    if(!UNIDAD_COMERCIAL.equals(datoAValidar))


    {
        Object[] demasArgumentosMSJError = new Object[] { ceramicos.getNumsecprove(),ceramicos.getNumsecfact(),
        ceramicos.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
        ErrorDescrMinima error = obtenerError("31038",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
        errorLst.add(error);
    }
    return errorLst;
  }



  public List<ErrorDescrMinima>  validarNombreProductoCeramico (ModelAbstract objeto, Declaracion dua){
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);
    Ceramico ceramicos = (Ceramico) objeto;
    String datoAValidar = ceramicos.getNombreComercial().getValtipdescri().trim();
    String subPartida = item.getNumpartnandi().toString();

    /*if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA))    
            errorLst.add(obtenerError("31039", ceramicos.getNombreComercial()));*/
    
    if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA, dua.getDua().getFecdeclaracion()))    
            errorLst.add(obtenerError("31039", ceramicos.getNombreComercial()));//considerar la fecha de la dam
    
    
    
    
    return errorLst;
  }

  public List<ErrorDescrMinima>  validarMarcaComercialCeramicos (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarModeloComercialCeramicos (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarAcabadoProductoCeramico (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarMateriaPrimaCeramicos(ModelAbstract objeto){
	  List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
        
  Map<Integer, DatoDescrMinima> lstMateriaPrima = listaMateriaPrima(objeto);

  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
  
  int ultimoMateriaPrima=ultimoMP(lstMateriaPrima);
 
  for ( int mP=1; mP < 5 ; mP++){        	
        	
        	DatoDescrMinima maP01=lstMateriaPrima.get(mP);
        	DatoDescrMinima maP02=lstMateriaPrima.get(mP+1);
        	
        	if (maP02!=null && maP01!=null) 
    		{
        		boolean establaMateriaPrima01= maP01.getCodtipvalor().equals("0")?true:false;
	    		boolean noEstaEnCatalogoMateriaPrima1 = noEstaEnCatalogo(maP01.getValtipdescri().trim(), CATALOGO_COMPONENTE, fechaVigencia);
	    		
	        	if ((noEstaEnCatalogoMateriaPrima1 && establaMateriaPrima01) || !establaMateriaPrima01 )
			        	{String nombreDescrMinima = obtenerDescripcionDelCalogo("393",maP01.getCodmercancia());	
			        		Object[] demasArgumentosMSJError = new Object[] {nombreDescrMinima};	
			        		errorLst.add(obtenerError("31846",maP01,demasArgumentosMSJError ));
			        	}
			     }
    		else {
    			 if ( (maP01!=null && maP02==null) && ultimoMateriaPrima==mP) {break;}
    			 else {    				
    				 if (maP02!=null && maP01==null) { 
    					 String descDelCampo = obtenerDescripcionDelCalogo("500",maP02.getCodtipdescr());
    					 
    					 errorLst.add(obtenerError("31851",maP02,new Object[] {descDelCampo}));}    				 
    				 if (maP02==null && maP01==null && ultimoMateriaPrima==mP){break;}
    			 	}
    			}
        }
        
         return errorLst;
	}
	
  

  public List<ErrorDescrMinima>  validarMoldeoCeramico (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarCoccionCeramico (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarUsoCeramico (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarColorCeramico (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarDimensionesCeramicos (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarCapacidadAbsorcionCeramico (ModelAbstract objeto) {    
    return new ArrayList<ErrorDescrMinima>();
  }
  
  
  
  public Map<Integer, DatoDescrMinima> listaMateriaPrima(ModelAbstract objeto)
  {
	  Map<Integer,DatoDescrMinima> listaMateriaPrima = new HashMap<Integer,DatoDescrMinima>();	 
      int key=0;      
	    
	  for(DatoDescrMinima materia: objeto.getLstDatos())
		  { 
		   if (key>=4 && key<=8) {		 
			elementoMP (materia, listaMateriaPrima, "CE0004", 1);
			elementoMP (materia, listaMateriaPrima, "CE0005", 2);
			elementoMP (materia, listaMateriaPrima, "CE0006", 3);
			elementoMP (materia, listaMateriaPrima, "CE0007", 4);
			elementoMP (materia, listaMateriaPrima, "CE0008", 5);
		   }
			key++;
			if (key==9) {break;}			
		  }
	  return listaMateriaPrima;
  }  
  
  public  void elementoMP (DatoDescrMinima materia, Map<Integer,DatoDescrMinima> listaMateriaPrima, String elem, int c)
  {  
	if (materia.getCodtipdescr().equals(elem)) 
	  	{	listaMateriaPrima.put(c, materia);	  	   
	    }
	else
	{if (listaMateriaPrima.get(c)==null) { listaMateriaPrima.put(c, null);}}	  	
	  
  }
			
  private int ultimoMP(Map<Integer, DatoDescrMinima> lstMateriaPrima){
	  int total=1;
	  for ( int m=1; m <= 5 ; m++)
	  { if (lstMateriaPrima.get(m) !=null ){
		  total=m;
	  	}
	  }
	  return total;
  }
  
}
