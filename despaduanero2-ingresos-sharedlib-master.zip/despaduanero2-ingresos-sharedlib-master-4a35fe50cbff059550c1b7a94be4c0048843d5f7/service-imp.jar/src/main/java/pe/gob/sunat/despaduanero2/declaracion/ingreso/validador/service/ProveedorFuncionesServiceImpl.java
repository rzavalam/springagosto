package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.beans.factory.annotation.Autowired;//P34
import org.springframework.beans.factory.annotation.Qualifier;//P34
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import org.springframework.web.client.RestTemplate;
import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.despaduanero.catalogo.tg.service.MrestriDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPosicion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Correl9298DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPosicionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabImportFrecDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CategVehiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabDescMinDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PublicasDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FuncionesFechaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;//P34
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
//import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.model.Detaliq;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.dao.DetaliqDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.registro.model.bean.UsuarioSOLBean;
import pe.gob.sunat.servicio2.registro.service.UsuarioService;

public class ProveedorFuncionesServiceImpl extends IngresoAbstractServiceImpl implements ProveedorFuncionesService {

	//region amancillaa SDA2-RIN18-PAS20171U220200035
	//http://api.sunat.peru/v1/controladuanero/oea/e/operadoreseconomicosautorizados?nroRuc=#RucImportador#&fecVigencia=#fechaDeclaracion#
	private static final String URL_REST_OEA = "http://api.sunat.peru/v1/controladuanero/oea/e/operadoreseconomicosautorizados?nroRuc=";
	//private static final String URL_REST_OEA = "http://localhost:7001/cl-at-iaoeaconsulta-ws/operadoreseconomicosautorizados?nroRuc=";

	Logger log = Logger.getLogger(ProveedorFuncionesServiceImpl.class);
	//endregion amancillaa

	//private CatalogoAyudaService catalogoAyudaService;
	//private FuncionesFechaService funcionesFechaService;
	//private HotSwappableTargetSource swapperDatasource;
	//private FabricaDeServicios fabricaDeServicios;
	//private DetPosicionDAO detPosicionDAO;
	//private AyudaService ayudaService;
	//private MrestriDAOService mrestriDAOService;
	//private PackageTD packageTD;

	//@Autowired //P34
	//@Qualifier("diligencia.rectificacionOficio.rectificacionOficioService")//P34
	//private RectificacionOficioService rectificacionOficioService;//P34

	@Override
	public boolean isImportadorFrecuente(String regimen, String tipodoc, String numeroDoc) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_regimen", regimen);
		params.put("cod_tipodoc", tipodoc);
		params.put("nro_documen", numeroDoc);
		params.put("est_impfrec", new Integer(0) );

		//Integer count = FormatoBServiceImpl.getInstance().getCabImportFrecDAO().getCount(params);
		Integer count = ((CabImportFrecDAO)fabricaDeServicios.getService("cabImportFrecDAO")).getCount(params);
		return count != 0;
	}


	//region amancillaa SDA2-RIN18-PAS20171U220200035
	public boolean isOEA(String numRuc, Date fecVigencia) {

		//amancilla para el regimen 20 y 21
		fecVigencia = fecVigencia!=null?fecVigencia:new Date();

		boolean esOEA = false;
		RestTemplate restTemplate = new RestTemplate();
		String sFecVigencia = SunatDateUtils.getFormatDate(fecVigencia,"yyyy-MM-dd");
		String URL= URL_REST_OEA + numRuc + "&fecVigencia=" + sFecVigencia;
		try {

			List listaOEABean = restTemplate.getForObject(URL, ArrayList.class);
			if(listaOEABean != null && !CollectionUtils.isEmpty(listaOEABean)){

				Map operadorEconomicoAutorizado = (HashMap)listaOEABean.get(0);
				if( operadorEconomicoAutorizado!=null && CollectionUtils.isEmpty((ArrayList)operadorEconomicoAutorizado.get("lstErrores"))){
					esOEA = true;
				}
			}
		} catch (Exception e) {
			log.error("error Servicio REST OEA: "+URL,e);
		}

		return esOEA;
	}

	//endregion amancillaa
	
	@Override
	public boolean isExonerado(String ptipo_docum, String pnume_doc, Integer gc_fech_ingsi) {
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		// Se Verifica en la tabla RES_SPIM si est� exonerado de la transmisi�n
		// de Formato B.
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_docum", ptipo_docum);
		params.put("nume_docum", pnume_doc);
		params.put("fechaVigencia", gc_fech_ingsi);
		params.put("tipo_uso", "TD");

		//		return FormatoBServiceImpl.getInstance().getResSpimDAO().getCount(params) != 0;
		return ayudaService.getCountResSpim(params) != 0;
	}


	@Override
	public String fnTipo(String partida, String nombreComercial, String caraTipo, Integer fechaIngSi) {

		String cTipoMerc = "**"; 
		String cTipoEspe = "";
		String cCapitulo = SunatStringUtils.substringFox(SunatStringUtils.lpad( SunatStringUtils.trim(partida) , 10, '0'), 1, 4);

		if( SunatStringUtils.isEmpty(partida) )
			return cTipoMerc;		

		List<CatRefpartidas> list = existsInRefPartidasByTipoUsoAndPartNandiAndCapitulo("DVA", partida, cCapitulo);

		if(list == null || list.size() == 0  )
		{
			return cTipoMerc;
		}

		//CatRefPartida resp = list.get(0);

		CatRefpartidas resp = list.get(0);

		cTipoMerc = resp.getRef();
		cTipoEspe = resp.getObservaciones();

		if( SunatStringUtils.isEqualTo(cTipoMerc, "CI") ){

			String subNombComer = SunatStringUtils.substringFox(nombreComercial, 1, 3);
			if( SunatStringUtils.isEqualTo(subNombComer, "CRE") ){
				cTipoMerc = "KB";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "LLA") ){
				cTipoMerc = "KC";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "TIR") ){
				cTipoMerc = "AA";
			}else{
				cTipoMerc = "99";
			}

		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "CA") ){

			String subCaraTipo = SunatStringUtils.substringFox(caraTipo, 1, 3);

			if( SunatStringUtils.isStringInList(subCaraTipo , "CUN,CUR") ){

				if( cambioVigente("DM03", fechaIngSi) == 1 
						&& SunatStringUtils.isEqualTo(subCaraTipo, "CUR"))
					cTipoMerc = "KD";
				else
					cTipoMerc = "KE";

			}else if( SunatStringUtils.isStringInList(subCaraTipo , "CAU,PLA") ){
				cTipoMerc = "KF";
			}else if( SunatStringUtils.isEqualTo(subCaraTipo , "CUS")
					&& cambioVigente("DM07", fechaIngSi) == 1  ){
				cTipoMerc = "KF";
			}else if( SunatStringUtils.isEqualTo(subCaraTipo , "TEX") ){
				cTipoMerc = "KG";
			}else{
				cTipoMerc = "KD";
			}
		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "LE") ){

			String subNombComer = SunatStringUtils.substringFox(nombreComercial, 1, 3);
			if( SunatStringUtils.isEqualTo(subNombComer, "LCC")
					&& SunatStringUtils.isEqualTo(partida, "9001300000")){
				cTipoMerc = "KL";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "LCM") 
					&& SunatStringUtils.isEqualTo(partida, "9001300000")){
				cTipoMerc = "KM";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "LCR")
					&& SunatStringUtils.isStringInList(partida, "9001400000,9001500000")){
				cTipoMerc = "KI";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "MNT")
					&& SunatStringUtils.isStringInList(partida, "9003110000,9003191000,9003199000")){
				cTipoMerc = "KH";
			}else if( SunatStringUtils.isEqualTo(subNombComer, "GFS") 
					&& SunatStringUtils.isEqualTo(partida, "9004100000")){
				cTipoMerc = "KO";				
			}else if( SunatStringUtils.isEqualTo(subNombComer, "GCC") 
					&& SunatStringUtils.isEqualTo(partida, "9004909000")){
				cTipoMerc = "KN";
			}else{
				cTipoMerc = "99";
			}
		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "KU") ){

			if( cambioVigente("DM01", fechaIngSi) == 1){
				if( SunatStringUtils.isEqualTo(partida, "8506900000") )
					cTipoMerc = "**";
			}else
				cTipoMerc = "**";
		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "KV") ){
			String nombComerc = nombreComercial.toUpperCase();
			if( cambioVigente("DM02", fechaIngSi) == 1){
				if( SunatStringUtils.isStringInList(partida, "8308100090,8308101900,8308109000") 
						&& !(nombComerc.indexOf("OJET") != -1 || nombComerc.indexOf("OJAL") !=-1 ) )
					cTipoMerc = "**";
			}else
				cTipoMerc = "**";
		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "CM") ){

			String upNombComerc = nombreComercial.toUpperCase();
			if( cambioVigente("DM04", fechaIngSi) == 1){

				if( SunatStringUtils.isEqualTo(upNombComerc, "COM") )
					cTipoMerc = "C1";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "CPU") )
					cTipoMerc = "C2";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "DDR") )
					cTipoMerc = "C3";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "DIS") )
					cTipoMerc = "C4";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "IMP") )
					cTipoMerc = "C5";
				else if( SunatStringUtils.isStringInList(upNombComerc, "LCD,LCW,LCR,LDV,LDW,LRW") )
					cTipoMerc = "C6";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "MEM") )
					cTipoMerc = "C7";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "MOM") )
					cTipoMerc = "C8";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "MOU") )
					cTipoMerc = "C9";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "PRO") )
					cTipoMerc = "CA";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "SCA") )
					cTipoMerc = "CB";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TSN") )
					cTipoMerc = "CC";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TGV") )
					cTipoMerc = "CD";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TRD") )
					cTipoMerc = "CE";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TMD") )
					cTipoMerc = "CF";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TEC") )
					cTipoMerc = "CG";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "VEN") )
					cTipoMerc = "CH";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "ZIP") )
					cTipoMerc = "CI";
				else if( SunatStringUtils.isStringInList(upNombComerc, "CAS,TFM") )
					cTipoMerc = "CZ";
				else 
					cTipoMerc = "**";
			}else
				cTipoMerc = "**";

		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "CC") ){

			String upNombComerc = nombreComercial.toUpperCase();
			if( cambioVigente("DM05", fechaIngSi) == 1){

				if( SunatStringUtils.isEqualTo(upNombComerc, "DIS") )
					cTipoMerc = "D1";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "CAU") )
					cTipoMerc = "D2";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "CVI") )
					cTipoMerc = "D3";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "EST") )
					cTipoMerc = "D4";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "CNT") )
					cTipoMerc = "D5";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "TRR") )
					cTipoMerc = "D6";
				else if( SunatStringUtils.isEqualTo(upNombComerc, "DUC") )
					cTipoMerc = "D7";
				else 
					cTipoMerc = "**";
			}else
				cTipoMerc = "**";


		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "TX") ){
			if( cambioVigente("DM06", fechaIngSi) == 1){
				cTipoMerc = cTipoEspe;
			}else
				cTipoMerc = "**";

		}else if(SunatStringUtils.isEqualTo(cTipoMerc, "ME") ){
			if( cambioVigente("DM08", fechaIngSi) == 0)
				cTipoMerc = "**";
		}

		return cTipoMerc;
	}

	@Override
	public boolean existsInEmpresasPublicas(String tipoDoc, String numDoc) {
		//Map response = FormatoBServiceImpl.getInstance().getPublicasDAO().findEmpresaByTipoDocAndNumDoc(tipoDoc, numDoc);
		Map response = ((PublicasDAO)fabricaDeServicios.getService("publicasDAO")).findEmpresaByTipoDocAndNumDoc(tipoDoc, numDoc);
		return response.size() > 0;
	}

	@Override
	public boolean existsInMRestri(String codigoReg, String numeroPartida, Integer fechaEmbarque) {
		MrestriDAOService mrestriDAOService = fabricaDeServicios.getService("Ayuda.mrestriService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codi_regi", codigoReg);
		params.put("cnan", numeroPartida);
		params.put("tipodoc_in", " '1','4' ");
		//params.put("fechaVigencia", FechaUtil.getDateFromInteger(fechaEmbarque));
		params.put("fechaVigencia", fechaEmbarque);

		//		return FormatoBServiceImpl.getInstance().getMrestriDAO().count(params) != 0;
		return mrestriDAOService.count(params) != 0;
	}

	@Override
	public boolean existsInResSPIMByTipoDocAndNumDoc(String tipoDoc, String numDoc) {
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_docum", tipoDoc);
		params.put("nume_docum", numDoc);
		//		return FormatoBServiceImpl.getInstance().getResSpimDAO().getCount(params) !=0;
		return ayudaService.getCountResSpim(params) !=0;
	}

	@Override
	public boolean existsInTabDescMinByTipoAndCodigo(String ctipo, String codigo) {		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ctipo", ctipo);
		params.put("codigo", codigo);

		//Integer count = FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCount(params);((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO"))
		Integer count = ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);

		return count != 0;
	}

	/*amancilla descr minimas */
	public boolean existsInTabDescMinByTipoAndCodigo(String ctipo, String codigo, Integer fechaVigencia) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ctipo", ctipo);
		params.put("codigo", codigo);
		params.put("fechaVigencia", fechaVigencia);

		//AMANCILLA CAMBIO PARA QUE CONSULTE A PRAD1
		//Integer count = ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);
		Integer count = ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAOPRAD1")).getCount(params);


		return count != 0;
	}


	@Override
	public boolean existsInTabDescMinByTipoAndCodigoOrDescripAndFVig(String ctipo, String codigo) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ctipo", ctipo);
		//params.put("fechaVigencia", new Date());
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());
		params.put("codigo", codigo);
		//Integer count1 = FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCount(params);
		Integer count1 = ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);
		params.put("tdescri", codigo);
		//count1 = count1 + FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCount(params);
		count1 = count1 + ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);
		return count1 != 0;
	}

	@Override
	public String fcValCalzadoOtros(String tcTipoVal, Timestamp TnFechIngsi, String tcPartSupe, String tcPartInfe, Long tnPartida, String tcPoliuretano,
			String tcNomCom, String tcCauPla1, String tcCauPla2) {
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		String lcRetorno = "";
		//SUBSTR(LPAD(A_CADENA(TnPartida),10,'0'),1,4)
		String lcCapitulo  = SunatStringUtils.substringFox(SunatStringUtils.lpad(tnPartida.toString(), 10, '0'), 1, 4);
		Integer lnNewVal2 = packageTD.getCambioVigente("DM07", SunatDateUtils.getIntegerFromDate( TnFechIngsi ));

		if( SunatStringUtils.isEqualTo(tcTipoVal, "1") )
		{
			//(Primer tipo de validaci�n)
			if( SunatStringUtils.isStringInList(tcPartSupe, "CAU,CUS,PLA") 
					&& SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC") 
					&& ! SunatStringUtils.isEqualTo(lcCapitulo, "6402"))
			{
				lcRetorno= " Parte Sup:"+tcPartSupe+", Planta:"+tcPartInfe +" solo en Capitulo 6402"; 
			}else if( SunatStringUtils.isEqualTo(lcCapitulo, "6402") 
					&& ! SunatStringUtils.isStringInList(tcPartSupe, "CAU,CUS,PLA") 
					&& SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC") ){

				lcRetorno= " Capitulo 6402, Solo puede declarar: Parte Sup." +"CAU,CUS,PLA y Planta CAU,EVA,"+tcPoliuretano+",PVC"; 
			}else if( SunatStringUtils.isEqualTo(tcPartSupe, "CUN")
					&& SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC,CUE")
					&& ! SunatStringUtils.isEqualTo(lcCapitulo, "6403") ){
				lcRetorno= " Par.Sup:"+tcPartSupe+", Planta:"+tcPartInfe +" solo en Capitulo 6403";
			}else if( SunatStringUtils.isEqualTo(lcCapitulo, "6403")
					&& ! SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC,CUE") ){

				lcRetorno= " Capitulo 6403, Solo puede declarar: Parte Sup.CUN y Planta CAU,EVA,"+tcPoliuretano+",PVC,CUE"; 
			}else if( SunatStringUtils.isEqualTo(tcPartSupe, "TEX")
					&& SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC,CUE")
					&& ! SunatStringUtils.isEqualTo(lcCapitulo, "6404") ){
				lcRetorno= " Par.Sup:"+tcPartSupe+", Planta:"+tcPartInfe +" solo en Capitulo 6404";

			}else if( SunatStringUtils.isEqualTo(lcCapitulo, "6404")
					&& ! SunatStringUtils.isEqualTo(tcPartSupe, "TEX")
					&& SunatStringUtils.isStringInList(tcPartInfe, "CAU,EVA,"+tcPoliuretano+",PVC,CUE")){
				lcRetorno= " Capitulo 6404, Solo puede declarar: Parte Sup. TEX y Planta CAU,EVA,"+tcPoliuretano+",PVC,CUE"; 
			}else if( SunatStringUtils.isEqualTo(tcPartSupe, "CUR") 
					&& ! SunatStringUtils.isEqualTo(lcCapitulo, "6405") ){
				lcRetorno= " Solo declarar CUR para Capitulo 6405"; 
			}
		}else if( SunatStringUtils.isEqualTo(tcTipoVal, "2") ){ //(Segundo tipo de validaci�n)

			if( SunatStringUtils.isEqualTo(tcNomCom, "CDP")
					&& ! SunatStringUtils.isStringInList(tnPartida.toString(), "6402120000,6402190000,6403120000,6403190000,6404111000")){
				lcRetorno= "Partida: "+tnPartida.toString()+" no corresponde a Calzado de Deporte CDP "; 
			}else if( ! SunatStringUtils.isEqualTo(tcNomCom, "CDP")
					&& SunatStringUtils.isStringInList(tnPartida.toString(), "6402120000,6402190000,6403120000,6403190000,6404111000")){
				lcRetorno= "Partida: "+tnPartida+" solo corresponde a Calzado de Deporte CDP"; 
			}else if( SunatStringUtils.isEqualTo(tcNomCom, "CUE")
					&& ! SunatStringUtils.isStringInList(tnPartida.toString(), "6403200000,6403510000,6403590000,6404200000,6405900000")){
				lcRetorno= "Partida: "+tnPartida+" no corresponde a Calzado con Planta de Cuero"; 
			}else if( ! SunatStringUtils.isEqualTo(tcNomCom, "CUE")
					&& SunatStringUtils.isStringInList(tnPartida.toString(), "6403200000,6403510000,6403590000,6404200000,6405900000")){
				lcRetorno= "Partida: "+tnPartida+" solo corresponde a Calzado con Planta de Cuero";
			}else if( SunatStringUtils.isEqualTo(tnPartida.toString(), "6405100000")
					&& ! SunatStringUtils.isStringInList(tcPartSupe, "CUN,CUR")){
				lcRetorno= "Partida: "+tnPartida+" solo corresponde a Calzado con Parte Superior de Cuero (CUN o CUR)"; 
			}else if( SunatStringUtils.isEqualTo(tnPartida.toString(), "6405200000")
					&& ! SunatStringUtils.isStringInList(tcPartSupe, "TEX")){
				lcRetorno= "Partida: "+tnPartida+" solo corresponde a Calzado con Parte Superior Textil (TEX)"; 
			}else if( SunatStringUtils.isStringInList(tcPartSupe, "CAU")
					&& ! 
					(SunatStringUtils.isStringInList(tcCauPla1, "CAN,CAS")
							&&  SunatStringUtils.isStringInList(tcCauPla2, "CAN,CAS")) ){
				lcRetorno= "Part.Supe. de Caucho, solo puede declarar los codigos CAN o CAS (Tabla 5)";

			}else if( SunatStringUtils.isStringInList(tcPartSupe, "PLA")
					&& ! 
					(SunatStringUtils.isStringInList(tcCauPla1, "EVA,PES,"+tcPoliuretano+",PVC,ZZZ")
							&&  SunatStringUtils.isStringInList(tcCauPla2, "EVA,PES,"+tcPoliuretano+",PVC,ZZZ"))){
				lcRetorno= "Part.Supe. de Plastico, solo puede declarar los codigos EVA,PES,"+tcPoliuretano +",PVC o ZZZ (Tabla 5)";
			}

			if( lnNewVal2 == 1 && SunatStringUtils.isEqualTo(tcPartSupe, "CUS") 
					&& !  (SunatStringUtils.isStringInList(tcCauPla1, "PES,"+tcPoliuretano+",PVC,ZZZ")
							&&  SunatStringUtils.isStringInList(tcCauPla2, "PES,"+tcPoliuretano+",PVC,ZZZ")))
			{
				lcRetorno= "Declaro Part.Supe. de Plastico, solo puede declarar los codigos PES, "+ tcPoliuretano+", PVC o ZZZ (Tabla 5)"; 
			}
		}
		return lcRetorno;
	}

	@Override
	public String fcValCondidion(String tcCampo, Integer pnPoscCodi, Integer pnlongCodi, 
			String nombrCamp, String pcondiOpci, String pcondiVali, String tipoObs) {

		String condicion = "";
		String tMensaje = "Posicion "+ pnPoscCodi +"-"+ ( pnlongCodi+pnPoscCodi-1 );
		String cmsg = "ITEM_FB."+nombrCamp+" Envio: "+tcCampo+tMensaje;
		boolean lbValida = false;
		String lcRetorno = "";

		if( SunatStringUtils.isEqualTo(tipoObs, "M")
				|| SunatStringUtils.isEmpty(tcCampo)
				|| ! SunatStringUtils.isEmpty(pcondiOpci)
				)
		{
			if( ! SunatStringUtils.isEmpty(pcondiOpci) )
			{
				condicion = pcondiOpci;
				if(! isCondicionValida(condicion) )
				{
					lbValida = false;
				}
			}

			if(lbValida && ! SunatStringUtils.isEmpty(pcondiVali)  )
			{
				condicion = pcondiVali;
				if(! isCondicionValida(condicion) )
				{
					lcRetorno= cmsg+" No Cumple: "+condicion; 
				}
			}
		}
		return lcRetorno;
	}

	@Override
	public String getCodigoInTabDescMinByTipoAndDescri(String ctipo, String tdescri) {
		// SELECT codigo INTO lcCodigoComp FROM TAB_DESC_MIN WHERE ctipo=CcVDM.codigo AND MAYUSCULA(tdescri)=MAYUSCULA(mNOMB_COMER)
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ctipo", ctipo);
		params.put("tdescri", tdescri);

		//return FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCodigoInTabDescMinByTipoAndDescri(params);
		return ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCodigoInTabDescMinByTipoAndDescri(params);
	}

	@Override
	public List<DatoDescrMinima> getCodigosInTabDescMinByGrupoAndTipo(String cgrupo, String ctipo) {
		// SELECT codigo FROM tab_desc_min WHERE cgrupo='YY' AND ctipo='01'
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cgrupo", cgrupo);
		params.put("ctipo", ctipo);

		//return FormatoBServiceImpl.getInstance().getTabDescMinDAO().getDescripcionesMinimas(params);
		return ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getDescripcionesMinimas(params);
	}

	@Override
	public List<DatoDescrMinima> getDescripcionTabDescMin(String ctipo, String codigo) {
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("ctipo", ctipo);
		params.put("codigo", codigo);
		return ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getDescripcionesMinimas(params);
	}

	@Override
	public Integer getCountFromTabDescMin(String tcTipoTabla, String tcDescOtro) {
		// 2.	SELECT COUNT(*) INTO lnCnt FROM TAB_DESC_MIN 
		// 3.	WHERE ctipo=TcTipoTabla AND (codigo=TcDesc_otro OR tdescri=TcDesc_otro) 
		// 4.	AND vFechIngsi BETWEEN FINICIO y FFIN 
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ctipo", tcTipoTabla);
		params.put("codigo", tcDescOtro);
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger() );

		//Integer count = FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCount(params);
		Integer count = ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);

		params.put("tdescri", tcDescOtro);

		//count = count + FormatoBServiceImpl.getInstance().getTabDescMinDAO().getCount(params);
		count = count + ((TabDescMinDAO)fabricaDeServicios.getService("tabDescMinDAO")).getCount(params);

		return count;
	}

	@Override
	public synchronized  List<DetPosicion> getListaPosiciones(String tipoRela, String codigoAduana) {	
		DetPosicionDAO detPosicionDAO = fabricaDeServicios.getService("detPosicionDAO");
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + codigoAduana)); 
		List<DetPosicion> listDetposicion = detPosicionDAO.getDetPosicionByTipoMerc(tipoRela);
		swapperDatasource.swap(o);
		return listDetposicion;
	}

	@Override
	public synchronized Integer getLongitudMaxima(String tipoRela, String cnombCamp, String codigoAduana) {
		DetPosicionDAO detPosicionDAO = fabricaDeServicios.getService("detPosicionDAO");
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + codigoAduana));
		Integer longitud = detPosicionDAO.getLongitudMaxima(tipoRela, cnombCamp);
		swapperDatasource.swap(o);
		return longitud;
	}

	@Override
	/**
	 * Invocar a PKTG_GRAL.FnGetVigenciaCambio de Gustavo
	 */
	public Integer getVigenciaCambio(String aduana, String regimen, String modulo, String codCambio, Date fecha) {
		return PackageGeneral.getVigenciaCambio(aduana, regimen, modulo, codCambio, fecha);
	}

	@Override
	/**
	 * PKTG_GRAL.FnGetVigenciaCambio (PAduana, PRegimen, �TD000�, PCodigo, PFecha) de Gustavo
	 */
	public boolean hasVigenciaCriterio(String codCambio, Integer fecha, String aduana, String regimen) {

		return getVigenciaCambio(aduana, regimen, "TD000", codCambio, SunatDateUtils.getDateFromInteger(fecha) ) != 0;
	}

	@Override
	public boolean hasVigenciaCriterio(String codCambio, Integer fecha) {
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		return packageTD.getCambioVigente(codCambio, fecha) != 0;
	}

	@Override
	public Integer cambioVigente(String codigo, Integer fecha) {
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		return packageTD.getCambioVigente(codigo, fecha);
	}

	@Override
	public boolean isCondicionValida(String condicion) {	
		DetPosicionDAO detPosicionDAO = fabricaDeServicios.getService("detPosicionDAO");
		return detPosicionDAO.isCondicionValida(condicion);
	}

	@Override
	public boolean isAutoUsa(DUA dua) {

		for ( DatoSerie serie: dua.getListSeries() )
		{
			if( SunatStringUtils.isStringInList(serie.getCodestamerca(), "20,21,22,23,24,25,26,27,28") 
					&& SunatStringUtils.isStringInList(serie.getCodtnan(), "01,02,03,04")
					&& serie.getNumpartnandi().toString().startsWith("87"))
			{
				return true;
			}
		}

		return false;
	}




	//RN 139 - LMVR
	@Override
	public Integer obtenerSeriesValorProvisional(DatoSerie serie)
	{
		//for ( DatoSerie serie: dua.getListSeries() ){	


		if(serie.getValestimado() != null  && serie.getValestimado().doubleValue() > 0)
		{
			return serie.getNumserie();
		}
		//}

		return null;
	}

	//RN 139 - LMVR 


	@Override
	public Integer obtenerSerieAutoUsa(DatoSerie serie) {

		//for ( DatoSerie serie: dua.getListSeries()){
		/*Se quita la valdiacion del tnan
		 * if( SunatStringUtils.isStringInList(serie.getCodestamerca(), "20,21,22,23,24,25,26,27,28") 
					&& SunatStringUtils.isStringInList(serie.getCodtnan(), "01,02,03,04")
					&& serie.getNumpartnandi().toString().startsWith("87"))
			{*/

		if( SunatStringUtils.isStringInList(serie.getCodestamerca(), "20,21,22,23,24,25,26,27,28") 
				&& serie.getNumpartnandi().toString().startsWith("87"))
		{


			return serie.getNumserie();
		}
		//}

		return null;
	}

	//RN 139 - LMVR
	@Override
	public Integer obtenerSerieValorProvisional(DUA dua)
	{
		for ( DatoSerie serie: dua.getListSeries() )
		{ 


			if(serie.getValestimado() != null  && serie.getValestimado().doubleValue() > 0)
			{
				return serie.getNumserie();
			}
		}

		return null;
	}

	public boolean SpUniMer_CasoEsp(DatoItem item){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipoUso", "DVA");
		params.put("capitulo", SunatStringUtils.substringFox(item.getNumpartnandi().toString(), 1, 4));
		params.put("finivig", SunatNumberUtils.getTodayAsInteger());
		params.put("ffinvig", SunatNumberUtils.getTodayAsInteger());

		List<CatRefpartidas> catRefPartidas = new ArrayList<CatRefpartidas>(); 


		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> listCatRefPart =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);

		//catRefPartidas.addAll( FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params) );

		catRefPartidas.addAll( listCatRefPart );



		params.remove("capitulo");
		params.put("cnan", item.getNumpartnandi());
		//		catRefPartidas.addAll( FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params) );
		catRefPartidas.addAll(ayudaService.getCatRefPartidas(params) );

		for (CatRefpartidas catRefPartida : catRefPartidas) {
			if( SunatStringUtils.isEqualTo(catRefPartida.getRef(), "KV") ) //(si corresponde a Anillos para ojetes)
			{
				if(! SunatStringUtils.isStringInList(item.getCodunidcomer(), "12U,GRU,MLL,ZZZ"))
				{

				}
			}
		}

		return false;
	}

	//desde CatalogoHelper

	/**
	 * En la tabla CAT_REFPARTIDAS se verifica lo siguiente:
		Sql = " SELECT cnan FROM cat_refpartidas where tipo_uso='DVA' AND (CNAN="+A_CADENA(Part_Nandi)+" OR CAPITULO = SUBSTR("+ A_CADENA(Part_Nandi) +",1,4)) AND TO_NUMBER(TO_CHAR( SYSDATE,'YYYYMMDD')) BETWEEN FINIVIG AND FFINVIG "
	 * @param numpartnandi
	 * @return
	 */
	public boolean existsInRefPartidaByTipoUsoAndCN(Long numpartnandi)
	{
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso","DVA");
		params.put("cnan",numpartnandi);
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());

		//Integer count = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);

		params.put("ayudaID", "CatRefpartidas");
		Integer count = (Integer)ayudaService.countCatRefParidas(params);


		params.remove("cnan");
		params.put("capitulo",numpartnandi); //capitulo es VARCHAR2(4)

		//		count = count + FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);

		return count != 0;
	}

	/**
	 * c.	SELECT COUNT(*) INTO lPartidaSoftware FROM CAT_REFPARTIDAS 
		d.	WHERE TIPO_USO = 'MP1' 
		e.	AND CNAN=A_NUMERO(mPart_Nandi) 
		f.	AND vFechIngsi BETWEEN FINIVIG AND FFINVIG 

	 * @param partidaSoftware
	 * @param fecha
	 * @return
	 */
	public Integer getCountPartidaSoftware(Long partidaSoftware, Timestamp fecha)
	{
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso","MP1");
		params.put("cnan",partidaSoftware);
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());

		//Integer count = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);

		params.put("ayudaID", "CatRefpartidas");
		Integer count = (Integer)ayudaService.countCatRefParidas(params);

		return count;
	}

	/**
	 * definir el servicio
	 * 	1.	SELECT COUNT(*) INTO vEXISTE FROM cat_modvehi 
		2.	WHERE codi_categ=mCate AND csub_categ=SUBSTR(mSubCat,2,1) AND
		3.	cmar_vehi=SUBSTR(mMARC_COMER,1,3) AND vFechIngsi BETWEEN fini_vige AND ffin_vige 
	 * @return
	 */
	public boolean existsVehiculo(String mCate, String mSubCat, String mMarcComer, String mModeMercd, String mCaraTipo, Integer vFechIngsi){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codi_categ",mCate);
		params.put("csub_categ", SunatStringUtils.substringFox(mSubCat, 2, 1));		
		if (!mMarcComer.isEmpty()) params.put("cmar_vehi",SunatStringUtils.substringFox(mMarcComer, 1, 3));;
		if (!mModeMercd.isEmpty()) params.put("cmode_vehi",SunatStringUtils.substringFox(mModeMercd, 1, 3));
		if (!mCaraTipo.isEmpty())  params.put("ccarr_vehi",SunatStringUtils.substringFox(mCaraTipo, 1, 3));
		params.put("fechaVigencia",vFechIngsi);		
		//	Integer count = FormatoBServiceImpl.getInstance().getCatModVehiDAO().count(params) ;		

		params.put("ayudaID", "CatModvehi");
		Integer count = (Integer)ayudaService.count(params);

		return count!=0;
	}

	/**
	 * iv. SELECT COUNT(*) INTO vEXISTE FROM categvehi WHERE codi_categ=mCate
	 * AND csub_categ=SUBSTR(mSubCat,2,1) AND cclas_espec=wClase AND
	 * tipo_uso='0'
	 * 
	 * @return
	 */
	public boolean isCategoriaVehiculoValido(String mCate, String mSubCat, String wclase)
	{
		Map<String, Object> params = new HashMap<String, Object>();
		wclase = wclase==null || SunatStringUtils.isEmptyTrim(wclase)?" ":wclase; 
		params.put("codi_categ",mCate);
		params.put("csub_categ", SunatStringUtils.substringFox(mSubCat, 2, 1));
		params.put("cclas_espec", wclase);
		params.put("tipo_uso", "0");

		//Integer count = FormatoBServiceImpl.getInstance().getCategVehiDAO().count(params) ;
		Integer count = ((CategVehiDAO)fabricaDeServicios.getService("categVehiDAO")).count(params);
		return count != 0;
	}

	/**
	 *
	 *	2.	SELECT COUNT(*) INTO lnCnt FROM CAT_REFPARTIDAS WHERE tipo_uso='DMD' AND cnan=mPART_NANDI AND INSTR(OBSERV,mNOMB_COMER)>0  
	 * @param tipoUso
	 * @param mPartNandi
	 * @param mNombComer
	 * @return
	 */
	public boolean existsInCatRefPartidas(String tipoUso, String mPartNandi, String mNombComer){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",tipoUso);
		params.put("cnan",mPartNandi);
		params.put("observ_instr", mNombComer);

		//Integer count = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);

		params.put("ayudaID", "CatRefpartidas");
		Integer count = (Integer)ayudaService.countCatRefParidas(params);

		return count != 0;
	}

	/**
	 * b.	Sql = " SELECT tipo_uso, capitulo, cnan, cnaladisa, pais_orige, codi_regi, codi_aduan FROM CAT_REFPARTIDAS WHERE TIPO_USO = 'CET' AND CODI_REGI = '"+ mcodi_regi + "' AND " + gc_fech_ingsi + " BETWEEN FINIVIG AND FFINVIG AND CODI_ADUAN= '"+ maduana + "'"
	 * @return
	 */
	//public List<CatRefPartida> getPartidaVehiculo(String tipoUso, String codiregi, String aduana){

	public List<CatRefpartidas> getPartidaVehiculo(String tipoUso, String codiregi, String aduana){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("codi_regi",	codiregi);
		params.put("codi_aduan", aduana);
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> listCatRefPart =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);


		//return FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		return listCatRefPart;
	}

	/**
	 * 	6.	SELECT COUNT(*) INTO GnCnt FROM cat_refpartidas WHERE tipo_uso='DVA' AND REF IN ('CC','CM') y cnan=mPart_Nandi 
	 */
	public boolean existsInRefPartidasByTipoUsoAndPartNandiAndRef(String tipoUso, String partNandi){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",tipoUso);
		params.put("cnan",partNandi);
		params.put("ref_in", "'CC','CM'");

		//Integer count = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);


		params.put("ayudaID", "CatRefpartidas");
		Integer count = (Integer)ayudaService.countCatRefParidas(params);

		return count != 0;
	}


	/**
	 * 	4.	SELECT REF, OBSERV INTO cTipo_Merc, cTipo_Espe FROM CAT_REFPARTIDAS WHERE TIPO_USO = 'DVA' y ( CAPITULO = cCapitulo OR CNAN = A_NUMERO(pPartida ) ) AND pFecha BETWEEN FINIVIG AND FFINVIG 
	 * @param partNandi
	 * @param tipoUso
	 * @param capitulo
	 * @return
	 */
	//ublic List<CatRefPartida> existsInRefPartidasByTipoUsoAndPartNandiAndCapitulo(String tipoUso, String partNandi, String capitulo){


	public List<CatRefpartidas> existsInRefPartidasByTipoUsoAndPartNandiAndCapitulo(String tipoUso, String partNandi, String capitulo){

		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		List<CatRefpartidas> result =  new ArrayList<CatRefpartidas>();

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("cnan",	partNandi);		
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());

		//List<CatRefPartida> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);


		params.remove("cnan");
		params.put("capitulo", capitulo);

		//List<CatRefPartida> result2 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result2 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);

		if(result1 != null && result1.size() > 0 )
			result.addAll(result1);

		if(result2 != null && result2.size() > 0 )
			result.addAll(result2);

		return result;
	}

	/**
	 * a.	Sql = "SELECT * FROM cat_refpartidas WHERE tipo_uso='VIA' AND cnan="+A_CADENA(Tempo2.part_nandi,10)+" AND "+A_CADENA(Tempo2.fech_embar,8)+" BETWEEN finivig AND ffinvig"
	 * 
	 * @param tipoUso
	 * @param partNandi
	 * @param fechaVigencia
	 * @return
	 */
	public CatRefpartidas existsInRefPartidasByTipoUsoAndPartidaAndFechVig(String tipoUso, String partNandi, Integer fechaVigencia){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("cnan",	partNandi);		
		//params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger());
		params.put("fechaVigencia", fechaVigencia);

		//st<CatRefPartida> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);


		if( result1 != null && result1.size() > 0 )
			return result1.get(0);

		return null;

	}

	/**
	 * "SELECT * FROM cat_refpartidas WHERE tipo_uso='PRO' AND cnan="+A_CADENA (Tempo2.part_nandi,10)+" AND "+A_CADENA(Tempo2.fech_embar,8)+ BETWEEN finivig AND ffinvig AND ALLTRIM(COD_TIPOENCE) like '%"+ mEncend+"%' AND ALLTRIM(COD_TIPOCATE) like '%"+ Catego+"%'
	 * Considerar si tipoEnce es nulo no incluir en el query , si tipoCate no incluir en el query
	 * @return
	 */
	//public CatRefPartida getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(String tipoUso, String partida, Integer fecha, String tipoEnce, String tipoCate){
	public CatRefpartidas getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate(String tipoUso, String partida, Integer fecha, String tipoEnce, String tipoCate){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("cnan",	partida);		
		params.put("fechaVigencia", fecha);

		if(tipoEnce != null)
			params.put("all_trim_cod_tipoence_like", tipoEnce);

		if(tipoCate != null)
			params.put("all_trim_cod_tipocate_like", tipoCate);

		//List<CatRefPartida> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);

		if( result1 != null && result1.size() > 0 )
			return result1.get(0);

		return null;
	}

	/**
	 * b.	Sql = "SELECT NUM_ANN_ANTIG ANNOS FROM cat_refpartidas WHERE tipo_uso='VA3' AND cnan="+ A_CADENA(Tempo2.part_nandi,10)+" AND "+A_CADENA(Tempo2.fech_embar,8)+ " BETWEEN finivig AND ffinvig and cod_tlib='T' and cod_clib='"+A_CADENA(Tempo2.trat_prefe,4)+"'" 
	 * @param tipoUso
	 * @param partida
	 * @param fecha
	 * @param codCLib
	 * @return
	 */
	//public CatRefPartida getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib(String tipoUso, String partida, Integer fecha, String codCLib){
	public CatRefpartidas getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib(String tipoUso, String partida, Integer fecha, String codCLib){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("cnan",	partida);		
		params.put("fechaVigencia", fecha);
		params.put("cod_tlib", "T");
		params.put("cod_clib", codCLib);

		//List<CatRefPartida> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);


		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);

		if( result1 != null && result1.size() > 0 )
			return result1.get(0);

		return null;
	}

	/**
	 *j.	Sql = "SELECT TASA_REF ANO_CONT, NUM_ANN_ANTIG ANNOS FROM cat_refpartidas "+ " WHERE tipo_uso='VA6' AND CODI_ADUAN='"+maduana+"' AND pais_orige='"+Tempo2.pais_orige+ "' and cod_tlib='T' and cod_clib='"+A_CADENA(Tempo2.trat_prefe,4)+ "' AND cnan="+A_CADENA(Tempo2.part_nandi,10)+" AND "+gc_fech_ingsi+" BETWEEN finivig AND ffinvig" 
	 * @param tipoUso
	 * @param aduana
	 * @param paisOrigen
	 * @param codCLib
	 * @return
	 */
	//public CatRefPartida getRefPartidasByTipoUsoAndAduanaAndPaisOrigenAndClib(String tipoUso, String aduana, String paisOrigen,String codCLib, Long cnan){

	public CatRefpartidas getRefPartidasByTipoUsoAndAduanaAndPaisOrigenAndClib(String tipoUso, String aduana, String paisOrigen,
			String codCLib, Long cnan){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipo_uso",	tipoUso);
		params.put("codi_aduan",	aduana);		
		params.put("pais_orige", paisOrigen);
		params.put("cod_tlib", "T");
		params.put("cod_clib", codCLib);
		params.put("cnan", cnan);
		params.put("fechaVigencia", SunatNumberUtils.getTodayAsInteger() );


		//	List<CatRefPartida> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);
		if( result1 != null && result1.size() > 0 )
			return result1.get(0);

		return null;
	}
	public CatRefpartidas getRefPartidas(
			String tipoUso, String tipoUsoIn, String aduana, String paisOrigen,
			String codCLib, String partNandi, String capitulo,
			String tlib, Integer fecha, String codiregi){
		Map<String, Object> paramsRefPartida = new HashMap<String, Object>();
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		paramsRefPartida.put("tipo_uso", tipoUso);
		paramsRefPartida.put("tipo_uso_in", tipoUsoIn);		
		paramsRefPartida.put("codi_aduan", aduana);
		paramsRefPartida.put("pais_orige", paisOrigen);
		paramsRefPartida.put("cod_clib", codCLib);
		paramsRefPartida.put("cod_tlib", tlib);
		paramsRefPartida.put("cnan",	partNandi);
		paramsRefPartida.put("capitulo", capitulo);
		paramsRefPartida.put("fechaVigencia", fecha);
		paramsRefPartida.put("codi_regi",	codiregi);

		//		List<CatRefpartidas> result1 = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(paramsRefPartida);
		paramsRefPartida.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> result1 =  (List<CatRefpartidas>)ayudaService.getCatRefPartidas(paramsRefPartida);
		if( result1 != null && result1.size() > 0 )
			return result1.get(0);

		return null;
	}

	/**
	 *Buscar manifiesto asociado a la declaracion.	
	 * @param Long 
	 * @TRANSACCION 1003,2003,21003 FORMATO B
	 * @return map
	 */
	public boolean tieneTransmisionDeRegularizacion (Long numCorreDoc, String codTransaccion, String codEstaRecti){		
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("numCorreDoc", numCorreDoc);
		params.put("codTransaccion", codTransaccion);
		params.put("codEstaRecti", codEstaRecti);

		List<Map<String, Object>> lstTransmisiones = ((CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO")).obtenerTransmisionDUA(params);
		//tiene transmisiones
		return !CollectionUtils.isEmpty(lstTransmisiones);
	}


	/**
    Verificar si es una DUA regularizable 
	 * @param Long  
	 * @TRANSACCION 1003,2003,21003 FORMATO B
	 * @return boolean
	 */

	public boolean esDuaRegularizable(Long numCorreDoc) {
		IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("num_corredoc", numCorreDoc);
		params.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION);
		params.put("ind_activo", ConstantesDataCatalogo.IND_ACTIVO);
		int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(params).get("CANT")).intValue();

		if(existeIndicador > 0){
			return true;
		}

		return false;


	}


	/**
	 *Buscar manifiesto asociado a la declaracion.	
	 * @params codigoTipoManifiesto, codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto)
	 * @TRANSACCION 1003,2003,21003 FORMATO B
	 * @return map
	 */

	public Manifiesto obtenerManifiestoDeDua(Declaracion declaracion){
		ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
		/*return manifiestoService.findManifiestoByClaveDeNegocio(
						declaracion.getDua().getManifiesto().getCodtipomanif(),
						declaracion.getDua().getManifiesto().getCodmodtransp(),
						declaracion.getDua().getManifiesto().getCodaduamanif(),
						Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
						declaracion.getDua().getManifiesto().getNummanif());*/
		
		/**PAS20181U220200049 inicio***/
		Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
	 		boolean evaluarEER = declaracion.getDua()!=null && declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
	 		return ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(
	 				declaracion.getDua().getManifiesto().getCodtipomanif(),
					declaracion.getDua().getManifiesto().getCodmodtransp(),
					declaracion.getDua().getManifiesto().getCodaduamanif(),
					Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
					declaracion.getDua().getManifiesto().getNummanif(),true, fechaReferencia,evaluarEER);		
	 				 
	 	}else{
	 		return ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(
	 				declaracion.getDua().getManifiesto().getCodtipomanif(),
					declaracion.getDua().getManifiesto().getCodmodtransp(),
					declaracion.getDua().getManifiesto().getCodaduamanif(),
					Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
					declaracion.getDua().getManifiesto().getNummanif());
	 	}/**PAS20181U220200049 fin***/
	}



	/**
	 *  select cdocumen from cat_refruc where ctipo_uso='CAU' and ctipodoc='"+xTipo_Docum+"' and cdocumen='"+xNume_Docum+"'  and TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) BETWEEN finivig and ffinvig and tlib='T' and clib='"+str(Tempo2->trat_prefe,4)+"'"
	 * 33.	Sql = "SELECT * FROM cat_refruc WHERE ctipo_uso='VH1'			 AND tlib='T' AND clib='"+A_CADENA(Tempo2.trat_prefe,4)+"' AND ctipodoc='"+xTipo_Docum+"' AND cdocumen='"+xNume_Docum+"' AND TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')) BETWEEN finivig AND ffinvig "
	 * 4.	Sql = "SELECT * FROM cat_refruc WHERE ctipo_uso IN ('VH2','VKM') AND tlib='T' AND clib='"+A_CADENA(Tempo2.trat_prefe,4)+"' AND ctipodoc='"+xTipo_Docum+"' AND cdocumen='"+xNume_Docum+"' AND clib=' 227' AND TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')) BETWEEN finivig AND ffinvig "
	 * i.	Sql = "SELECT * FROM cat_refruc WHERE ctipo_uso IN ('VH2','VKM') AND tlib='T' AND clib='"+A_CADENA(Tempo2.trat_prefe,4)+"' AND ctipodoc='"+xTipo_Docum+"' AND cdocumen='"+xNume_Docum+"' AND clib=' 227' AND TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')) BETWEEN finivig AND ffinvig "
	 * @param tipoUso
	 * @param clib
	 * @param tipoDoc
	 * @param numDoc
	 * @return
	 */
	public boolean existsInCatRefRuc(String[] tipoUso, String clib, String tipoDoc, String numDoc,String aduana){
		Map<String , String> params = new HashMap<String, String>();


		if(tipoUso.length == 1)
			params.put("ctipoUso", tipoUso[0]);
		else
			params.put("ctipoUso_in", "'"+tipoUso[0]+"','"+ tipoUso[1]+"'");

		params.put("clib", clib);
		params.put("ctipodoc", tipoDoc);
		params.put("cdocumento", numDoc);
		params.put("tlib", "T");//KIB
		if (!aduana.equals(""))
			params.put("codaduana", aduana);

		params.put("fechaVigencia",SunatNumberUtils.getTodayAsInteger().toString()); //KIB
		if(tipoUso.length > 1) // verificar si se cumplen las querys de arriba
			params.put("clib", "227");

		//List result = FormatoBServiceImpl.getInstance().getCatRefRucDAO().findByMap(params);
		List result = ((CatRefRucDAO)fabricaDeServicios.getService("catRefRucDAO")).findByMap(params);

		return (result != null && result.size() > 0);
	}


	/**
	 * ii.	Sql = "SELECT * FROM cat_refpartidas WHERE tipo_uso='843' AND cnan="+A_CADENA(Tempo2.part_nandi)
	 * @param tipoUso
	 * @param partida
	 * @return
	 */
	public Integer getRefPartidasByTipoUsoAndPartida(String tipoUso, String partida){
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		//params.put("tipo_uso","DVA");
		params.put("tipo_uso",tipoUso);
		params.put("cnan",partida);

		//Integer count = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().count(params);

		params.put("ayudaID", "CatRefpartidas");
		Integer count = (Integer)ayudaService.countCatRefParidas(params);

		return count;
	}

	/**
	 * c. Sql =
	 * "select ann_fabr from cantmaxlibe where tlib='T' and clib='"+A_CADENA
	 * (Tempo2.Trat_Prefe,4)+
	 * "' and caduana = '000' and cregimen = '"+mcodi_regi
	 * +"' and cod_marca ='"+Tempo2
	 * .marc_comer+"' and cod_chasis_vehi ='"+SUBSTR(
	 * Tempo2.Clas_Vari,7,20)+"' and ann_fabr='"+Tempo2.aro_ano+
	 * "' and TO_NUMBER(TO_CHAR(sysdate, 'YYYYMMDD')) between finilib and ffinlib "
	 * 
	 * @param clib
	 * @param aduana
	 * @param regimen
	 * @param marca
	 * @param chasis
	 * @param annFabrica
	 * @return
	 */
	public Map<String, Object> getCantMaxLibeByClibAndAduanaAndRegimenAndMarcaAndChasisAndAnnFabrica(String clib, String aduana, String regimen, String marca, String chasis, Integer annFabrica){		
		//KIB implementar acceso a la tabla
		/*"select ann_fabr from cantmaxlibe@prad1 "+;
                  " where tlib='T' and clib='"+STR(Tempo2.Trat_Prefe,4)+;
               "' and caduana = '000' and cregimen = '10' and cod_marca ='"+ALLT(Tempo2.marc_comer)+;
                        "' and cod_chasis_vehi ='"+ALLTRIM(SUBSTR(Tempo2.Clas_Vari,7,20))+"' and ann_fabr='"+Tempo2.aro_ano+"' "+;
               " and TO_NUMBER(TO_CHAR(sysdate,'YYYYMMDD')) between finilib and ffinlib "

		 * */
		AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tlib","T");
		params.put("clib",clib);
		params.put("caduana",aduana);
		params.put("cregimen",regimen);
		params.put("codmarca",marca);
		params.put("codchasisvehi",chasis);
		params.put("annfabr",annFabrica);
		params.put("fecvigencia",SunatNumberUtils.getTodayAsInteger().toString());

		List<Map<String,Object>>  listCnatMaxLibe= new ArrayList();
		//listCnatMaxLibe = FormatoBServiceImpl.getInstance().getCantMaxLibeDAO().findCantMaxLibeByParams(params);

		params.put("ayudaID", "CantMaxLibe");
		listCnatMaxLibe= (List<Map<String,Object>>)ayudaService.findCantMaxLibeByParams(params);

		if (!listCnatMaxLibe.isEmpty()){
			return listCnatMaxLibe.get(0);
		}

		return new HashMap<String, Object>();
	}
	/**
	 * Validacion para envio complementario formato B
	 * Verifica que exista la dua de referencia en la tabla Cab_declara
	 * @param codAduana
	 * @param codRegimen
	 * @param numDeclaracion
	 * @param annDeclaracion
	 * @return declaracionRef
	 */

	public DUA getDeclaracionReferencia(String codAduana,String codRegimen,Long numDeclaracion, Integer annDeclaracion){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana",codAduana);
		params.put("annoPresentacion",annDeclaracion);
		params.put("codigoRegimen",codRegimen);
		params.put("numeroDeclaracion",numDeclaracion);

		//FormatoBServiceImpl.getInstance().getCabDeclaraDAO().findDUAByMap(params);
		//		DUA declaracionRef = FormatoBServiceImpl.getInstance().getDeclaracionService().getDUA(params);
		DUA declaracionRef = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDUA(params);

		return declaracionRef;
	}

	public DUA getDeclaracionReferenciaResumida(String codAduana,String codRegimen,Long numDeclaracion, Integer annDeclaracion){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana",codAduana);
		params.put("annoPresentacion",annDeclaracion);
		params.put("codigoRegimen",codRegimen);
		params.put("numeroDeclaracion",numDeclaracion);
		//DUA declaracionRef = FormatoBServiceImpl.getInstance().getDeclaracionService().getDUAResumida(params);
		DUA declaracionRef = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDUAResumida(params);
		return declaracionRef;
	}

	public List<DatoSerie>  getSeriesReferencia(Map<String, Object> params){

		//List<DatoSerie> seriesRef = FormatoBServiceImpl.getInstance().getDetDeclaraDAO().findSerieByMap(params);
		List<DatoSerie> seriesRef = ((DetDeclaraDAO)fabricaDeServicios.getService("detDeclaraDAO")).findSerieByMap(params);

		return seriesRef;
	}

	public List<DatoFactura>  getListComprobPago(Map<String, Object> params){

		//List<DatoFactura> listFactura = FormatoBServiceImpl.getInstance().getComprobPagoDAO().findFacturaByMap(params);
		List<DatoFactura> listFactura = ((ComprobPagoDAO)fabricaDeServicios.getService("comprobPagoDAO")).findFacturaByMap(params);
		return listFactura;
	}
	public List<DatoItem>  getListItemFactura(Map<String, Object> params){

		//List<DatoItem> listDatoItem = FormatoBServiceImpl.getInstance().getItemFacturaDAO().findItemByMap(params);
		List<DatoItem> listDatoItem = ((ItemFacturaDAO)fabricaDeServicios.getService("itemFacturaDAO")).findItemByMap(params);
		return listDatoItem;
	}
	public List<DatoSerieItem>  getListSeriesItem(Map<String, Object> params){

		//List<DatoSerieItem> listDatoSerieItem = FormatoBServiceImpl.getInstance().getSerieItemDAO().findSerieItemByMap(params);
		List<DatoSerieItem> listDatoSerieItem =((SeriesItemDAO)fabricaDeServicios.getService("serieItemDAO")).findSerieItemByMap(params);
		return listDatoSerieItem;
	}
	public List<Participante>  getListParticipante(Map<String, Object> params){

		//List<Participante> listParticipante = FormatoBServiceImpl.getInstance().getParticipanteDocDAO().findParticipantesByMap(params);
		List<Participante> listParticipante = ((ParticipanteDocDAO)fabricaDeServicios.getService("participanteDAO")).findParticipantesByMap(params);
		return listParticipante;
	}

	//r2bz Solo considerar la autoliquidaciones de tributos PASE459
	public boolean isAutoliquidado(DUA dua)
	{
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if((StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(ConstantesDataCatalogo.TIPO_DOC_AUTOLIQUIDACION) 
						)&&(StringUtils.hasText(soporte.getCodtipodocasoc()) && soporte.getCodtipodocasoc()
								.equals(Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS) 
								) 
						){
					return true;
				}
			}
		}
		return false;
	}

	public boolean existsAutoliquidacionesPagadas (Declaracion duaBD)
	{
		Liquida mapLiquida = new Liquida();

		mapLiquida.setRladuaso(duaBD.getDua().getCodaduanaorden());
		mapLiquida.setRlanoaso(duaBD.getDua().getAnnpresen().toString().substring(2, 4));
		mapLiquida.setRlnumaso(Cadena.padLeft(duaBD.getNumeroDeclaracion().toString().trim(), 6, '0'));
		mapLiquida.setRlregimen(duaBD.getDua().getCodregimen());

		List lstAutoliquidaciones = new ArrayList();
		//lstAutoliquidaciones = RectificacionServiceImpl.getInstance().getLiquidaDeclaracionService().obtenerAutoliquidacionesPagadas(mapLiquida);
		lstAutoliquidaciones = ((LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService")).obtenerAutoliquidacionesPagadas(mapLiquida);

		if (lstAutoliquidaciones !=null && !lstAutoliquidaciones.isEmpty())
			return true;
		else
			return false;		
	}



	public Map<String,BigDecimal> obtenerTributosAutoliquidacion(Declaracion declaracion, Map<String,Object> variablesIngreso){

		Map<String,BigDecimal> mpTributos=new HashMap<String, BigDecimal>();
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte =declaracion.getDua().getListOtrosDocSoporte();
		String codMoneda="";
		/*  se genera un map del tipo 
		 * [(Tributo1, Monto1), (Tributo2,Monto2).....]
		 * */

		List<Liquida>  lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");


		if(!CollectionUtils.isEmpty(lstAutoliquidacion)){          	  
			// verificamos es error
			for(Liquida lc:lstAutoliquidacion){
				/*se consulta la tabla Detaliq  para obtener los tributos 
	                    		y generar  un mapa de tributos*/

				codMoneda=lc.getRlcodmon()!=null?lc.getRlcodmon():"";

				Map<String,Object> params= new HashMap<String, Object>();
				params.put("rdaduana", lc.getRladuana());
				params.put("rdano", lc.getRlano());
				params.put("rdnroliq", lc.getRlnroliq());
				//List<Detaliq> lstTributos= RectificacionServiceImpl.getInstance().getDetaliqDAO().listByParameterMap(params); 
				//List<Detaliq> lstTributos= ((DetaliqDAO)fabricaDeServicios.getService("detaliqDAO")).listByParameterMap(params);
				//inicio gmontoya PAS20165E220200106
				DataSourceContextHolder.setKeyDataSource(lc.getRladuana());
				DetaliqDAO detaliqDAOTemp = (DetaliqDAO)fabricaDeServicios.getService("recaudacion2.detaliqDS");
				if(detaliqDAOTemp==null){
					detaliqDAOTemp = (DetaliqDAO) fabricaDeServicios.getService("detaliqDAO");
					HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
					swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds."+lc.getRladuana()));
				}
				List<Detaliq> lstTributos= detaliqDAOTemp.listByParameterMap(params);
				//fin gmontoya PAS20165E220200106
				//la descripci�n de los tributos esta en el catalogo Datacatalogo TRI (catalogo de tributos de juancito) 
				// se ha creado el catalogo TRI por que aun no existen la tablas en la base de datos que soporte la union de 2 catalogos
				if(!CollectionUtils.isEmpty(lstTributos)){
					for(Detaliq tributo:lstTributos){
						if(mpTributos.containsKey(tributo.getRdcodrub().concat(codMoneda))){// por ejemplo 0002D
							BigDecimal acumTributo=mpTributos.get(tributo.getRdcodrub().concat(codMoneda)).add(tributo.getRdmondet());
							mpTributos.put(tributo.getRdcodrub().concat(codMoneda),acumTributo);
						}
						else{
							mpTributos.put(tributo.getRdcodrub().concat(codMoneda), tributo.getRdmondet());
						}
					}
				}                           		
			}
		}



		// fin generacion del map

		return mpTributos;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService#verificarTributosAutoliquidacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map)
	 */
	public List<Map<String,String>> verificarTributosAutoliquidacion(Declaracion declaracion, Map<String,Object> variablesIngreso){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		String numeroDUA = declaracion.getCodaduana() + "-" + declaracion.getNumeroDeclaracion() + "-" + declaracion.getDua().getAnnpresen();
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte =declaracion.getDua().getListOtrosDocSoporte();
		List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();

		List<Liquida>  lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");

		if(!CollectionUtils.isEmpty(lstAutoliquidacion)){
			/*
			 * 2.- Luego de la secci�n docasociados Sacar los documentos asociados con Tipo de procedencia =9
			 */ 
			for(Liquida liq:lstAutoliquidacion){
				//por cada documento de autoliquidacion
				if ("ERROR".equals(liq.getFlag())){ // las autoliquidaciones tienen error
					resultadoError.add(
							//RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("01235",new String[] { liq.getRlnroliq(), numeroDUA }));
							catalogoAyudaService.getError("01235",new String[] { liq.getRlnroliq(), numeroDUA }));
				}
			}
		}

		return resultadoError;
	}

	/*branch ingreso 2011-009 hosorio inicio 03/08/2011*/

	public Date getFechaVencimientoPagoDespacho(Declaracion declaracion,Map<Object,Object> mapManifiesto){

		Date dtFecVencimientoDespacho=null;
		String codGarantia =null;

		Date dtFecNumeracion=declaracion.getDua().getFecdeclaracion();
		Date dtFecLlegadaAux=null;
		Date dtFecLlegada=null;
		Date dtFecPrLlegada=null;
		Date dtFecTerminoDescarga=null;
		String codModalidad= declaracion.getDua().getCodmodalidad();

		// SI tien cab Manifiesto
		if (mapManifiesto!=null){
			dtFecLlegada=(Date)mapManifiesto.get("fechaEfectivaDeLlegada");
			dtFecPrLlegada=(Date)mapManifiesto.get("fechaProgramadaLlegada");
			dtFecTerminoDescarga=(Date)mapManifiesto.get("fechaTerminoDeDescarga");
			if(SunatDateUtils.sonIguales(dtFecLlegada, SunatDateUtils.getDefaultDate(), "COMPARA_SOLO_FECHA"))
				dtFecLlegadaAux=dtFecPrLlegada;
			else 
				dtFecLlegadaAux=dtFecLlegada;
		}
		else{
			dtFecLlegadaAux=declaracion.getDua().getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( dtFecLlegadaAux!=null && SunatDateUtils.sonIguales(dtFecLlegadaAux, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				dtFecLlegadaAux = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
		}

		try {
			codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {
			// TODO: handle exception
		}
		// Exceptcional sin garantia
		if (SunatStringUtils.isEmpty(codGarantia) &&
				SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){
			dtFecVencimientoDespacho=dtFecNumeracion;
		}
		// Excpecional con garantai
		if (!SunatStringUtils.isEmpty(codGarantia) &&
				SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}

		//la fecha de vencimiento de pago en el despacho anticipado y urgente antes de la llegada, para la DUA que no cuenta con la garant�a 160� es la fecha del t�rmino de la descarga
		if(SunatStringUtils.isEmpty(codGarantia)
				&& 		(  SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
						||
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
								&&  SunatDateUtils.esFecha1MayorIgualQueFecha2(dtFecLlegadaAux, dtFecNumeracion, "COMPARA_SOLO_FECHA")  // antes o igual que la fecha de la llegada
								)
						)

				){

			if(dtFecTerminoDescarga!=null && 
					!SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)){
				dtFecVencimientoDespacho=dtFecTerminoDescarga;	
			}
			else{
				//(si no se tiene la fecha del t�rmino de la descarga a la fecha de la rectificaci�n, se consignar� el 31.12.2999).
				dtFecVencimientoDespacho=SunatDateUtils.getDateFromInteger(29991231);
			}

		}

		//y para la DUA que cuenta con garant�a 160� es el d�a 20 calendario del mes siguiente a la fecha del t�rmino de la descarga.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 		(  	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
						|| 
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
								&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecLlegadaAux, dtFecNumeracion, "COMPARA_SOLO_FECHA")  // antes de la llegada
								)
						)

				){


			if(dtFecTerminoDescarga!=null && 
					!SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)){
				Date result=SunatDateUtils.addMonth(dtFecTerminoDescarga, 1);
				Calendar c=Calendar.getInstance();
				c.setTime(result);
				c.set(Calendar.DAY_OF_MONTH, 20);
				dtFecVencimientoDespacho =c.getTime();

			}
			else{
				//(si no se tiene la fecha del t�rmino de la descarga a la fecha de la rectificaci�n, se consignar� el 31.12.3999).
				dtFecVencimientoDespacho=SunatDateUtils.getDateFromInteger(39991231);
			}


		}	



		//Tener en cuenta que la fecha de vencimiento de pago en el despacho urgente despu�s de la llegada, 
		//para la DUA que no cuenta con la garant�a 160� es la fecha de numeraci�n de la DUA 


		if(SunatStringUtils.isEmpty(codGarantia)
				&& 	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) 
				&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // antes de la llegada
				){
			dtFecVencimientoDespacho=dtFecNumeracion; 
		}
		//y para la DUA que cuenta con garant�a 160� es el d�a 20 calendario del mes siguiente a la fecha de numeraci�n de la DUA.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) 
				&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // antes de la llegada
				){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}	


		//6.3.2. En excepcional y urgente despu�s de la llegada: El vencimiento de pago es el d�a 20 calendario del mes siguiente a la fecha de numeraci�n de la DUA.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 	(SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) //PAS20165E220200066
						||
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) //PAS20165E220200066
								&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // despues de la llegada						 
								)
						) 

				){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}	

		//9.0 tener en cuenta que la fecha de vencimiento de pago en el despacho urgente despu�s de la llegada, 
		//para la DUA que no cuenta con la garant�a 160� es la fecha de numeraci�n de la DUA 
		if(SunatStringUtils.isEmpty(codGarantia)
				&& 	 SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
				&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // despues de la llegada
				){
			dtFecVencimientoDespacho=dtFecNumeracion;
		}	


		return dtFecVencimientoDespacho;

	}


	public Date getFechaLlegadaIngreso(Declaracion declaracion,Map<Object,Object> mapManifiesto){
		Date dtFecLlegadaAux=null;
		Date dtFecLlegada=null;
		Date dtFecPrLlegada=null;

		if (mapManifiesto!=null){
			dtFecLlegada=(Date)mapManifiesto.get("fechaEfectivaDeLlegada");
			dtFecPrLlegada=(Date)mapManifiesto.get("fechaProgramadaLlegada");
			if(SunatDateUtils.sonIguales(dtFecLlegada, SunatDateUtils.getDefaultDate(), "COMPARA_SOLO_FECHA"))
				dtFecLlegadaAux=dtFecPrLlegada;
			else 
				dtFecLlegadaAux=dtFecLlegada;
		}
		else{
			dtFecLlegadaAux=declaracion.getDua().getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( dtFecLlegadaAux!=null && SunatDateUtils.sonIguales(dtFecLlegadaAux, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				dtFecLlegadaAux = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
		}


		return dtFecLlegadaAux;
	}


	public Map<Object, Object> getManifiestoMap(Declaracion declaracion) {

		Map<Object, Object> manifiestoMap=null;
		if (declaracion.getDua().getManifiesto() != null) {
			Map<String, Object> paramsMap = new HashMap<String, Object>();
			String annManif = "0";
			if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3)
				annManif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
			paramsMap.put("anioManifiesto", annManif);
			paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 6, ' '));
			paramsMap.put("aduana", declaracion.getDua().getManifiesto().getCodaduamanif());
			paramsMap.put("tipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif());
			paramsMap.put("viaTransporte", declaracion.getDua().getManifiesto().getCodmodtransp());

			//	    		 manifiestoMap = RectificacionServiceImpl.getInstance().getManifiestoDAO().getByNumeroAnioAduanaTipoManifTipoVia(
			//	    				paramsMap);
			manifiestoMap = ((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).getByNumeroAnioAduanaTipoManifTipoVia(
					paramsMap);
		}

		return manifiestoMap;
	}

	/**
	 * Obtiene el manifiesto en el NSIGAD, de no encontrarlo busca en el ASIGAD
	 * 
	 * @param declaracion
	 * @return
	 */
	public Manifiesto getManifiestoNASigad(Declaracion declaracion) {
		Manifiesto manifiesto = null;
		//busca en el nuevo
		// rpumacayo pase70, si no viene el a�o y nro d manif..genera error
		if (declaracion.getDua().getManifiesto().getNummanif() !=null && declaracion.getDua().getManifiesto().getAnnmanif() != null) {
			
			/***
			// rpumacayo pase70
			//		manifiesto = RectificacionServiceImpl.getInstance().getManifiestoService()
			manifiesto = ((ManifiestoService)fabricaDeServicios.getService("manifiesto.manifiestoService"))
					.findManifiestoByClaveDeNegocio(
							declaracion.getDua().getManifiesto().getCodtipomanif(),
							declaracion.getDua().getManifiesto().getCodmodtransp(),
							declaracion.getDua().getManifiesto().getCodaduamanif(),
							Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
							declaracion.getDua().getManifiesto().getNummanif());
			//si no encontro, busca en el antiguo
			if (manifiesto == null) {
				//manifiesto = RectificacionServiceImpl.getInstance().getManifiestoSigadService()
				manifiesto = ((ManifiestoSigadService)fabricaDeServicios.getService("manifiesto.manifiestoSigadService"))
						.getManifiestoByClaveDeNegocio(
								declaracion.getDua().getManifiesto().getCodmodtransp(),
								declaracion.getDua().getManifiesto().getCodaduamanif(),
								Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
								SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 5, ' '));
			}
			// rpumacayo pase70
			***/// Lo siento este codigo ya no es pr�ctico
			
			/**PAS20181U220200049 inicio***/
			Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
			List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
			if(!ResponseListManager.responseListHasErrors(listaOMA)){
		 		boolean evaluarEER = declaracion.getDua()!=null && declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
		 		manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(
		 				declaracion.getDua().getManifiesto().getCodtipomanif(),
						declaracion.getDua().getManifiesto().getCodmodtransp(),
						declaracion.getDua().getManifiesto().getCodaduamanif(),
						Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
						declaracion.getDua().getManifiesto().getNummanif(),true, fechaReferencia,evaluarEER);		
		 				 
		 	}else{
				manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(
						declaracion.getDua().getManifiesto().getCodtipomanif(),
						declaracion.getDua().getManifiesto().getCodmodtransp(),
						declaracion.getDua().getManifiesto().getCodaduamanif(),
						Integer.parseInt(declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)),
						declaracion.getDua().getManifiesto().getNummanif(), true);//dentro del metodo se hace el parseo del nro del manif
		 	}/**PAS20181U220200049 fin***/
		}
		return manifiesto;
	}

	public boolean isTransaccionDiligencia(String codigoTransaccion){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DataGrupoCat txGrupoDilig = catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_TXDILIGENCIA, codigoTransaccion);
		boolean isTxDilig = txGrupoDilig != null;
		return isTxDilig ;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Date getFechaRegularizacion(DUA dua, Date fechaReferencia){
		Date fechVencimientoRegu = SunatDateUtils.addDay(fechaReferencia, 
				Constantes.PLAZO_VENCIMIENTO_REGULARIZACION);    		

		Map<String, Object> paramDias = new HashMap<String, Object>();
		paramDias.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechVencimientoRegu));
		paramDias.put("FECHAHASTA", 0);
		paramDias.put("TIPO", pe.gob.sunat.despaduanero2.ayudas.util.Constantes.SUMAR_DIAS);
		paramDias.put("INCLUYE", "S");
		paramDias.put("SUSPENDE", "S");	    		
		DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(dua.getCodaduanaorden());
		String resultadoDiaUtil = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias); // yyyyMMdd
		Date fecVencRegula = SunatDateUtils.getDateFromInteger(Integer.parseInt(resultadoDiaUtil));				
		return fecVencRegula;
	}

	private boolean esVigentePartida (Long partNandi, Integer fechReferencia){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cnan", partNandi);
		params.put("ffintas", fechReferencia);
		params.put("finitas", fechReferencia);
		//int contNandtasa=FormatoAServiceImpl.getInstance().getNandtasaDAO().count(params);
		int contNandtasa=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count(params);
		if (contNandtasa == 0){
			return false;
		} else {
			return true;
		}
	}

	@SuppressWarnings("unchecked")
	private Long correlAdelante (Map<String, Object> paramsCorrel){
		Map<String, Object> params = new HashMap<String, Object>();
		Long lpartNandi   = new Long(0);
		Long lpartRetorna = new Long(0);
		Long partNandi          = SunatNumberUtils.toLong(paramsCorrel.get("partNandi"));             //(*)
		Long partCorrelacion    = SunatNumberUtils.toLong(paramsCorrel.get("partCorrelacion"));
		Integer fechReferencia  = SunatNumberUtils.toInteger(paramsCorrel.get("fechReferencia"));
		Integer fechVigencia    = SunatNumberUtils.toInteger(paramsCorrel.get("fechVigencia"));       //(*)
		List<Long> partRelacion = (List<Long>) paramsCorrel.get("partRelacion");


		if (SunatNumberUtils.isGreaterThanZero(fechVigencia)){
			params.put("nandina92", partNandi);
			params.put("fingresomayor", fechVigencia);	    		
			params.put("notnandi9298", "true");	    		
			//List<Map<String, Object>> correl98B = FormatoAServiceImpl.getInstance().getCorrel9298DAO().selectCorrel(params);
			List<Map<String, Object>> correl98B = ((Correl9298DAO)fabricaDeServicios.getService("correl9298DAO")).selectCorrel(params);
			for (int i = 0; i < correl98B.size(); i++){
				lpartNandi = SunatNumberUtils.toLong(correl98B.get(i).get("NANDINA98"));
				if (SunatNumberUtils.isEqualToZero(partCorrelacion)){
					if (esVigentePartida(lpartNandi, fechReferencia) && SunatNumberUtils.isEqualToZero(lpartRetorna)) {
						lpartRetorna = lpartNandi;
					}
				} else{
					if (SunatNumberUtils.isEqual(partCorrelacion, lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
				if (SunatNumberUtils.isEqualToZero(lpartRetorna)){
					if (!partRelacion.contains(lpartNandi)){
						partRelacion.add(lpartNandi);
						paramsCorrel.put("partNandi", lpartNandi);
						paramsCorrel.put("fechVigencia", SunatNumberUtils.toInteger(correl98B.get(i).get("FFIN"))+1);
						paramsCorrel.put("partRelacion",partRelacion);
						lpartNandi = correlAdelante(paramsCorrel);
					} else{
						lpartNandi = new Long(0);
					}
					if (SunatNumberUtils.isGreaterThanZero(lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
			}
		}else {
			params.put("nandina92", partNandi);  		
			params.put("notnandi9298", "true");   		
			//List<Map<String, Object>> correl98A = FormatoAServiceImpl.getInstance().getCorrel9298DAO().selectCorrel(params);
			List<Map<String, Object>> correl98A = ((Correl9298DAO)fabricaDeServicios.getService("correl9298DAO")).selectCorrel(params);
			for (int i = 0; i < correl98A.size(); i++){
				lpartNandi = SunatNumberUtils.toLong(correl98A.get(i).get("NANDINA98"));
				if (SunatNumberUtils.isEqualToZero(partCorrelacion)){
					if (esVigentePartida(lpartNandi, fechReferencia) && SunatNumberUtils.isEqualToZero(lpartRetorna)) {
						lpartRetorna = lpartNandi;
					}
				} else{
					if (SunatNumberUtils.isEqual(partCorrelacion, lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
				if (SunatNumberUtils.isEqualToZero(lpartRetorna)){
					if (!partRelacion.contains(lpartNandi)){
						partRelacion.add(lpartNandi);
						paramsCorrel.put("partRelacion",partRelacion);
						paramsCorrel.put("partNandi", lpartNandi);
						if (SunatNumberUtils.isEqual(SunatNumberUtils.toInteger(correl98A.get(i).get("FFIN")), new Integer(20020203))){	    						
							paramsCorrel.put("fechVigencia", new Integer(0));
						} else{
							paramsCorrel.put("fechVigencia", SunatNumberUtils.toInteger(correl98A.get(i).get("FFIN"))+1);
						}
						lpartNandi = correlAdelante(paramsCorrel);
					}else{
						lpartNandi = new Long(0);
					}
					if (SunatNumberUtils.isGreaterThanZero(lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
			}
		}
		return lpartRetorna;
	}

	@SuppressWarnings("unchecked")
	private Long correlAtras (Map<String, Object> paramsCorrel){
		Map<String, Object> params = new HashMap<String, Object>();
		Long lpartNandi   = new Long(0);
		Long lpartRetorna = new Long(0);

		Long partNandi         = SunatNumberUtils.toLong(paramsCorrel.get("partNandi"));           //(*)
		Long partCorrelacion   = SunatNumberUtils.toLong(paramsCorrel.get("partCorrelacion"));
		Integer fechReferencia = SunatNumberUtils.toInteger(paramsCorrel.get("fechReferencia"));
		Integer fechVigencia   = SunatNumberUtils.toInteger(paramsCorrel.get("fechVigencia"));    //(*)
		List<Long> partRelacion   = (List<Long>) paramsCorrel.get("partRelacion");
		if (SunatNumberUtils.isGreaterThanParam(fechVigencia, new Integer(20020203))){
			params.put("nandina98", partNandi);
			params.put("ffinmenor", fechVigencia);	    		
			params.put("notnandi9298", "true");
			//List<Map<String, Object>> correl92B = FormatoAServiceImpl.getInstance().getCorrel9298DAO().selectCorrel(params);
			List<Map<String, Object>> correl92B = ((Correl9298DAO)fabricaDeServicios.getService("correl9298DAO")).selectCorrel(params);
			for (int i = 0; i < correl92B.size(); i++){
				lpartNandi = SunatNumberUtils.toLong(correl92B.get(i).get("NANDINA92"));
				if (SunatNumberUtils.isEqualToZero(partCorrelacion)){
					if (esVigentePartida(lpartNandi, fechReferencia) && SunatNumberUtils.isEqualToZero(lpartRetorna)) {
						lpartRetorna = lpartNandi;
					}
				} else{
					if (SunatNumberUtils.isEqual(partCorrelacion, lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
				if (SunatNumberUtils.isEqualToZero(lpartRetorna)){
					if (!partRelacion.contains(lpartNandi)){
						partRelacion.add(lpartNandi);
						paramsCorrel.put("partNandi", lpartNandi);
						paramsCorrel.put("fechVigencia", SunatNumberUtils.toInteger(correl92B.get(i).get("FINGRESO"))-1);
						paramsCorrel.put("partRelacion",partRelacion);
						lpartNandi = correlAtras(paramsCorrel);
					} else{
						lpartNandi = new Long(0);
					}
					if (SunatNumberUtils.isGreaterThanZero(lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
			}
		} else{
			params.put("nandina98", partNandi);
			params.put("ffin", new Integer(20020203));	    		
			params.put("notnandi9298", "true");
			params.put("orderByClause", "nandina92");	    		
			//List<Map<String, Object>> correl92A = FormatoAServiceImpl.getInstance().getCorrel9298DAO().selectCorrel(params);
			List<Map<String, Object>> correl92A = ((Correl9298DAO)fabricaDeServicios.getService("correl9298DAO")).selectCorrel(params);
			for (int i = 0; i < correl92A.size(); i++){
				lpartNandi = SunatNumberUtils.toLong(correl92A.get(i).get("NANDINA92"));
				if (SunatNumberUtils.isEqualToZero(partCorrelacion)){
					if (esVigentePartida(lpartNandi, fechReferencia) && SunatNumberUtils.isEqualToZero(lpartRetorna)) {
						lpartRetorna = lpartNandi;
					}
				} else{
					if (SunatNumberUtils.isEqual(partCorrelacion, lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
				if (SunatNumberUtils.isEqualToZero(lpartRetorna)){
					if (!partRelacion.contains(lpartNandi)){
						partRelacion.add(lpartNandi);
						paramsCorrel.put("partNandi", lpartNandi);
						paramsCorrel.put("fechVigencia", new Integer(0));
						paramsCorrel.put("partRelacion",partRelacion);
						lpartNandi = correlAtras(paramsCorrel);
					}else{
						lpartNandi = new Long(0);
					}
					if (SunatNumberUtils.isGreaterThanZero(lpartNandi) && SunatNumberUtils.isEqualToZero(lpartRetorna)){
						lpartRetorna = lpartNandi;
					}
				}
			}	    		
		}
		return lpartRetorna;
	}

	/**
	 * Migracion de USAMTG00.Fntg_Correlpartida
	 * 1.- Para determinar si dos partidas estan correlacionadas:
	 *     Se envia partCorrelacion y fechaReferencia=0.
	 * 2.- Para hallar la primera partida correlacionada a una fecha dada.
	 *     Se envia fechaReferencia y partCorrelacion=0.
	 * @param partNandi
	 * @param partCorrelacion
	 * @param fechaReferencia
	 * @return
	 */
	public Long getCorrelPartida(Long partNandi, Long partCorrelacion, Integer fechaReferencia){
		Map<String, Object> paramsCorrel = new HashMap<String, Object>();
		Long partResul = new Long(0);
		if (SunatNumberUtils.isEqualToZero(partCorrelacion)){
			if (esVigentePartida((Long)partNandi, fechaReferencia)){
				return partNandi;
			}
		} else {
			if (SunatNumberUtils.isEqual(partNandi, partCorrelacion)){
				return partNandi;
			}
		}
		paramsCorrel.put("partNandi", partNandi);  //(*)
		paramsCorrel.put("partCorrelacion", partCorrelacion);
		paramsCorrel.put("fechReferencia", fechaReferencia);//jenciso 
		paramsCorrel.put("fechVigencia", new Integer(99999999)); //(*)
		paramsCorrel.put("partRelacion", new ArrayList<BigDecimal>());


		partResul = correlAtras(paramsCorrel);
		if (SunatNumberUtils.isGreaterThanZero(partResul)){
			return partResul;
		} else {
			paramsCorrel.put("partNandi", partNandi);
			paramsCorrel.put("partRelacion", new ArrayList<BigDecimal>());
			paramsCorrel.put("fechVigencia", new Integer(0));
			partResul = correlAdelante(paramsCorrel);
		}	    	
		return partResul;
	}



	/**
	 * Servicio para saber si la fecha remitida por el usuario corresponde
	 * a la fecha de llegada o a la fecha de t�rmino de descarga 
	 * @param DUA
	 * @param fechaReferencia
	 * @param codTransaccion
	 * @return
	 */
	public boolean esFechaLlegada(DUA dua, Date fechaReferencia, String codTransaccion ){
		boolean rpta = false;
		boolean requiereEvaluacion = true;

		String codModalidad = dua.getCodmodalidad(); 

		/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		/***fin PAS20181U220200049***/
		
		if( codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) ) requiereEvaluacion = false;
		if( codTransaccion.endsWith("04") || codTransaccion.endsWith("05") ) requiereEvaluacion = false;

		if( requiereEvaluacion ) {

			boolean tieneRegularizacion = false;

			if( !codTransaccion.endsWith("01") ) {
				GetDeclaracionService declaracionService = fabricaDeServicios.getService("declaracionService");
				DUA duaBD = declaracionService.getCabDUA(dua.getNumcorredoc());
				if( duaBD != null ) 
					tieneRegularizacion = !SunatDateUtils.sonIguales(duaBD.getFecregulariza(), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA);
			}

			if( !tieneRegularizacion ) {

				//if( !codTransaccion.endsWith("04") && !codTransaccion.endsWith("05") ) { 
				if( codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO))
					rpta = true;
				else  if( codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE )) {
					DatoManifiesto manifDUA =dua.getManifiesto();
					String codaduamanif=manifDUA.getCodaduamanif();
					String annmanif=SunatStringUtils.length(manifDUA.getAnnmanif())>3?manifDUA.getAnnmanif().substring(0,4):null;
					String nummanif=manifDUA.getNummanif();
					String codmodtransp=manifDUA.getCodmodtransp();
					String codtipmanif  = manifDUA.getCodtipomanif();

					ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
					//Manifiesto manif =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
					/***PAS20181U220200049 inicio***/
					Manifiesto manif = null;
					boolean considerarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
					if(!ResponseListManager.responseListHasErrors(listaOMA)){
						manif =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true, fechaReferencia, considerarEER);
					}else{
						manif =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
						
					}
					/***PAS20181U220200049 fin***/
					//Manifiesto manif =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
						

					if( manif == null ) {
						rpta = SunatDateUtils.esFecha1MayorIgualQueFecha2(manifDUA.getFectermino(), fechaReferencia, SunatDateUtils.COMPARA_SOLO_FECHA);  
					}
					else {
						Date fecProgramadaLlegada = manif.getFechaEfectivaDeLlegada();
						Date fecTerminoDeDescarga = manif.getFechaTerminoDeDescarga();
						//En caso no tenga o sea igual a la fecha default usamos la fecha Programada
						if(fecProgramadaLlegada == null || SunatDateUtils.sonIguales(fecProgramadaLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
							fecProgramadaLlegada = manif.getFechaProgramadaLlegada();
						}
						if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fecProgramadaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){
							rpta = true;
						} else {
							if (SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
								rpta = true;
							}					
						}

					}
				} //modalidad urgente
			} //Fin NoTieneRegularizacion
		} // FecAutLevante = 01/01/0001
		return rpta;
	}

	/**
	 * Retorna la lista de indicadores asociados a una declaracion
	 * @param numCorredoc
	 * @param codindicador
	 * @param codtipregistro
	 * @param indActivo
	 * @return
	 */
	public List<DatoIndicadores>  getIndicadorDUA(Long numCorredoc, String codindicador, String codtipregistro, String indActivo ){
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		Map<String,Object> params=new HashMap<String,Object>();
		params.put("numcorredoc",numCorredoc);
		params.put("codtipoindica",codindicador); 
		params.put("indactivo", indActivo);
		params.put("codtiporegistro",codtipregistro);
		List<DatoIndicadores> listindicadores = indicadorDUADAO.findIndicadoresByMap(params);
		return listindicadores;		
	}

	/* P14 - 3007 - Inicio - dhernandezv */
	/* CUS: 3007-01.10 - Inicio - dhernandezv */

	public boolean  validaIndicadorAbandonoVoluntario(String numCorreDoc){
		IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object> paramDeclaracion = new HashMap<String, Object>();
		paramDeclaracion.put("num_corredoc", numCorreDoc);
		paramDeclaracion.put("cod_indicador", Constants.IND_ABANDONO_VOLUNTARIO);
		paramDeclaracion.put("ind_activo", Constants.INDICADOR_ACTIVO);

		Map<String, Object> indicadorAbandonoVoluntario = indicadorDUADAO.findByDocumentoAndValor(paramDeclaracion);

		if(indicadorAbandonoVoluntario!=null && !indicadorAbandonoVoluntario.isEmpty()) {
			return true;
		}else {
			return false;
		}

	}

	/* CUS: 3007-01.10 - Fin - dhernandezv */
	/* P14 - 3007 - Fin - dhernandezv */
	public List<Map<String, Object>> buscarExpedienteSuspension(String codaduana, String annpresen, String codregimen, String numdeclaracion, Date fechaVencimiento){
		ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		Map<String, Object> paramsExpedi = new HashMap<String, Object>();
		paramsExpedi.put("PROCEDIM", Constants.CODIGO_TUPA_SUSPENSION_PLAZO);
		paramsExpedi.put("ANN_PRESEN", annpresen);
		paramsExpedi.put("NUM_DECLARACION", numdeclaracion);
		paramsExpedi.put("COD_ADUANA", codaduana);
		paramsExpedi.put("COD_REGIMEN", codregimen);
		paramsExpedi.put("TIPO_CONC", Constants.CODIGO_EXPEDIENTE_CONCLUIDO);
		List<Map<String,Object>> listExpedi =  expedienteService.findByDocumentoOrigen(paramsExpedi);
		ListIterator<Map<String,Object>>  itexpediSuspension = listExpedi.listIterator(); 
		while (itexpediSuspension.hasNext()) {
			Map<String,Object> expediSuspension = itexpediSuspension.next();
			Date fechExpediente = SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(expediSuspension.get("FECEXP")));
			if (fechaVencimiento!= null && SunatDateUtils.esFecha1MayorQueFecha2(fechExpediente, fechaVencimiento, SunatDateUtils.COMPARA_SOLO_FECHA)){
				itexpediSuspension.remove();
			}
		}
		return listExpedi;
	}

	//csantillan bug
	public List<Map<String, Object>> buscarExpedienteSuspensionPrece(String codaduana, String annpresen, String codregimen, String numdeclaracion, Date fechaVencimiento, String[] codProcedimSuspencion ){
		ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		Map<String, Object> paramsExpedi = new HashMap<String, Object>();
		//paramsExpedi.put("PROCEDIM", Constants.CODIGO_TUPA_SUSPENSION_PLAZO);
		paramsExpedi.put("CODPROCEDIM", codProcedimSuspencion);
		paramsExpedi.put("ANN_PRESEN", annpresen);
		paramsExpedi.put("NUM_DECLARACION", numdeclaracion);
		paramsExpedi.put("COD_ADUANA", codaduana);
		paramsExpedi.put("COD_REGIMEN", codregimen);
		paramsExpedi.put("TIPO_CONC", Constants.CODIGO_EXPEDIENTE_CONCLUIDO);
		//paramsExpedi.put("O_TIPO", Constants.CODIGO_EXPEDIENTE_CONCLUIDO);//bug PAS20191U220200002
		List<Map<String,Object>> listExpedi =  expedienteService.findByDocumentoOrigen(paramsExpedi);
		ListIterator<Map<String,Object>>  itexpediSuspension = listExpedi.listIterator();
		while (itexpediSuspension.hasNext()) {
			Map<String,Object> expediSuspension = itexpediSuspension.next();
			Date fechExpediente = SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(expediSuspension.get("FECEXP")));
			if (fechaVencimiento!= null && SunatDateUtils.esFecha1MayorQueFecha2(fechExpediente, fechaVencimiento, SunatDateUtils.COMPARA_SOLO_FECHA)){
				itexpediSuspension.remove();
			}
		}
		return listExpedi;
	}
	/* P14 - 3007 - Inicio - dhernandezv */
	/* CUS: 3007-01.10 - Inicio - dhernandezv */
	public Map<String,String> validarDeclaEstadosIndicadores(Declaracion declaracion) {
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String,  String> resultadoError = new HashMap<String, String>();

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
		params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
		params.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
		params.put("NUM_DECLARACION", declaracion.getNumdeclRef().getNumcorre());

		Map<String, Object> mapCabDeclara = cabDeclaraDAO.findByDeclaracion(params);

		//inicio p21-p22
		/*if(mapCabDeclara.get("COD_ESTDUA").toString().equals(Constants.COD_ESTADO_EN_PROC_DILIG_CONCL)){
		//BUGP14:43-Refactorizacion			
			 resultadoError.put("codigoError", Constants.COD_ERROR_EST_EN_PROC_DILIG_DESPACHO);
		}else{*/
		//fin p21-p22			
		//BUGP14:43-44-Refactorizacion
		boolean indicadorAbandonoVoluntario = this.validaIndicadorAbandonoVoluntario(String.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));			
		if(indicadorAbandonoVoluntario){
			resultadoError.put("codigoError", Constants.COD_ERROR_IND_ABANDONO_VOLUNTARIO_RECTIF);
		}
		//}

		/*INICIO-P34 FSW AFMA*/
		//amancilla si debe ejecutar para otras tarnsaacciones
		//debe cambiar el mensaje de error ay esta tomado esto solo funciona para la tranacciones del SEIDA para las TX de diligencia estaria bloqueandolos
		// TODO: analizar mejor en las pruebas podria ser un error bloqueante

		/*P34 Inicio - F2 3007*/
		// 1.1.12.	El sistema verifica que la Declaraci�n NO cuente con una Diligencia de Rectificaci�n de Oficio marcada �En Proceso�. En caso contrario se ejecuta la excepci�n 3
		if(declaracion.getCodtipotrans() != null){
			if(!declaracion.getCodtipotrans().endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)
					&& !declaracion.getCodtipotrans().endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_OFICIO))
			{   
				RectificacionOficioService rectificacionOficioService = (RectificacionOficioService)fabricaDeServicios.getService("diligencia.rectificacionOficio.rectificacionOficioService");
				
				boolean tieneRectificacionOficioPendiente = rectificacionOficioService.tieneRectificacionOficioEnProceso(String.valueOf(mapCabDeclara.get("NUM_CORREDOC").toString()));
				if (tieneRectificacionOficioPendiente)
				{
					resultadoError.put("codigoError", Constantes.CODIGO_ERROR_SOLICITUD_RECTIFICACION_OFICIO);//CAMBIO DILIGENICIA
				}
				/*P34 Fin - F2 3007*/
			}
		}
		/*FIN-P34 FSW AFMA*/
		return resultadoError;
	}


	/**
	 * Permite obtener la identificaci�n asociado al usuario SOL, sea principal o secundario  
	 * @param codUsuario
	 * @param tipoSender
	 * @return
	 */
	public  UsuarioSOLBean obtenerUsuariosSOL (String codUsuario, String tipoSender ) {
		UsuarioSOLBean paramClass = new UsuarioSOLBean();
		paramClass.setCodUsuario(codUsuario);
		paramClass.setIndActivo(ConstantesDataCatalogo.IND_ACTIVO);
		UsuarioService usuarioService = (UsuarioService)fabricaDeServicios.getService("Ayuda.usuarioSOLService");
		List<UsuarioSOLBean> listUsuariosSOL = usuarioService.obtenerUsuariosSOL(paramClass);

		if (!CollectionUtils.isEmpty(listUsuariosSOL)){
			UsuarioSOLBean usuarioSOL =  new UsuarioSOLBean(listUsuariosSOL.get(0));
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			List<Map<String, String>> listServiciosCatalogo =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPO_DOCUMENTO_AD_TI, "C",usuarioSOL.getCodDocrepleg());			
			// Si no existe equivalencia se asume DNI (no deber�a suceder)
			if (!CollectionUtils.isEmpty(listServiciosCatalogo)){
				usuarioSOL.setCodDocrepleg(listServiciosCatalogo.get(0).get("cod_datacat"));
			} else {
				usuarioSOL.setCodDocrepleg(ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI);
			}
			return usuarioSOL; 
		}
		return null;
	}


	/**
	 * Obtiene al Personal OCE asociado al usuario principal o secundario SOL
	 */
	public  Map<String, Object> obtenerPersonalOCE(String codUsuario, String tipoSender) {
		UsuarioSOLBean usuarioSOL = obtenerUsuariosSOL(codUsuario, tipoSender);
		String numRUC = codUsuario.substring(0, 11);
		String codTipDoc = usuarioSOL.getCodDocrepleg();
		String numDoc = usuarioSOL.getNumDocrepleg();
		OperadorAyudaService operadorAyudaService = (OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService");
		Map<String, Object> personalOCE = new HashMap<String, Object>();
		if (SunatStringUtils.include(tipoSender, new String []{ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA,ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO})){
			personalOCE = operadorAyudaService.getPersonalOCEsinCircunscripcion(numRUC, tipoSender, codTipDoc, numDoc, ConstantesDataCatalogo.COD_CARGO_REPRE_LEGAL, null);
		}
		if (SunatStringUtils.include(tipoSender, new String []{ConstantesDataCatalogo.TIPO_OPERADOR_DESPACHADOR_OFICIAL})){
			personalOCE = operadorAyudaService.getPersonalOCEsinCircunscripcion(numRUC, tipoSender, codTipDoc, numDoc, ConstantesDataCatalogo.COD_CARGO_DESPA_OFICIAL, null);
		}
		return 	personalOCE;
	}


	public Manifiesto buscarManifiestosEER(Declaracion declaracion) {
		//Identificar si es un EER, dado que en el SIGAD se identifica si es via = 5 pero en el sda es via = 4 y puede ser EEr o no.
		//Cargamos los datos del manifiesto de la dua en la variable manif
		Boolean isManifiestoEerSda = false;
		DUA dua=declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();//cambio pase 64
		boolean considerarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion()
				.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
		if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(codmodtransp)){//4
			return  ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).
					findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true,fechaDeclaracion, considerarEER);
 
		}else {
			return null;
		}
	}


	public boolean esManifiestoEerSigad(Declaracion declaracion) {
		Boolean isManifiestoEerSigad = false;
		Manifiesto manifiesto = buscarManifiestosEER(declaracion);
		if(manifiesto!=null) {
			isManifiestoEerSigad = manifiesto.isEsSigad() && manifiesto.isEsEERSigad();
		}
		return isManifiestoEerSigad; 
	}

	public boolean esManifiestoEerSda(Declaracion declaracion) {
		//Identificar si es un EER, dado que en el SIGAD se identifica si es via = 5 pero en el sda es via = 4 y puede ser EEr o no.
		//Cargamos los datos del manifiesto de la dua en la variable manif
		Boolean isManifiestoEerSda = false;
		/*DUA dua=declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(codmodtransp)){//4
			Manifiesto manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true);
			isManifiestoEerSda = esManifiestoEerSda(manifiesto, declaracion.getDua().getListDocTransporte());
 
		}	*/
		Manifiesto manifiesto = buscarManifiestosEER(declaracion);
		if(manifiesto!=null) {
			isManifiestoEerSda = esManifiestoEerSda(manifiesto, declaracion.getDua().getListDocTransporte());
		} 
		return isManifiestoEerSda;
	} 
	
	public boolean esManifiestoEerSda(Manifiesto manifiesto, Elementos<DatoDocTransporte> docsDeclaracion){
		boolean isManifiestoEerSda = false;
		if(manifiesto != null ){//Si es del sda se continua:
			if(!manifiesto.isEsSigad()){
			DocuTransDAO docuTransDAO = fabricaDeServicios.getService("manifiesto.gralDocTranporteDAO");
			Map<String, Object> parameterMap = new HashMap<String, Object>();
	    	parameterMap.put("viaTransporte", manifiesto.getViaTransporte().getCodDatacat());
	    	parameterMap.put("aduana", manifiesto.getAduana().getCodDatacat());
	    	parameterMap.put("anioManifiesto", manifiesto.getAnioManifiesto());
	    	parameterMap.put("numeroManifiesto", SunatStringUtils.lpad(manifiesto.getNumeroManifiesto(), 6, ' '));
			List<DocumentoDeTransporte> docsTransporte = docuTransDAO.getByManifDocu(parameterMap);
			
			//Consultar al docutrans con los datos del manifiesto para traer dicho dato.
			for(DatoDocTransporte docTranspXML : docsDeclaracion){
				for(DocumentoDeTransporte docTransp : docsTransporte){
					//se verifica que exista en el docutrans y que el participante sea del tipo 50 -EER
					if(docTranspXML.getNumdoctransporte().equalsIgnoreCase(docTransp.getNumeroDocumentoTransporte()) 
							&& ConstantesDataCatalogo.COD_OPERADOR_ESER.equalsIgnoreCase(docTransp.getEmpresaDeTransporte().getTipoParticipante().getCodDatacat())) {
						isManifiestoEerSda = true;
					}
				}
			}
		    }
		}
		return isManifiestoEerSda;
	}
	
	
	//PAS20181U220200049 transformarOma es true, cambia el catalogo 227(unece) al catalogo 10
	public String transformarViaTransporteDeOma(String codigoViaTransporte, boolean transformarUnece, Date fechaDeclaracion, boolean considerarEER){
		
		List<Map<String, String>> lista = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		
		if(transformarUnece){//trae el codigo de v�a de transporte del catalogo 227 respecto al cat�logo 10
			lista = catalogoAyudaService.getListaElementosAsoc(ConstantesDataCatalogo.ASOCIACION_VIAMANIFIESTO_SDA_UNECE, "C", codigoViaTransporte, fechaDeclaracion);	
			if(!CollectionUtils.isEmpty(lista)){
				codigoViaTransporte = lista.get(0).get("cod_datacat")!=null?lista.get(0).get("cod_datacat"):null;
				if(considerarEER && codigoViaTransporte.equals(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){//si es 4 la via y el puntollegada es deposito eer cambiar a 5
					codigoViaTransporte = ConstantesDataCatalogo.VIA_TRANSPORTE_EER;
				}
			}
		}else{//trae el codigo de v�a de transporte del catalogo 10 respecto al cat�logo unece 227
			lista = catalogoAyudaService.getListaElementosAsoc(ConstantesDataCatalogo.ASOCIACION_VIAMANIFIESTO_SDA_UNECE, "A", codigoViaTransporte, fechaDeclaracion);
			if(!CollectionUtils.isEmpty(lista)){
				codigoViaTransporte = lista.get(0).get("cod_datacat")!=null?lista.get(0).get("cod_datacat"):null;
			}else if(considerarEER && codigoViaTransporte.equals(ConstantesDataCatalogo.VIA_TRANSPORTE_EER)){//si es 5 la via y el puntollegada es deposito eer cambiar a 4
				codigoViaTransporte = ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA;
			}
		}
				
		return codigoViaTransporte;
	}
/*
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}


	public void setFuncionesFechaService(FuncionesFechaService funcionesFechaService) {
		this.funcionesFechaService = funcionesFechaService;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setDetPosicionDAO(DetPosicionDAO detPosicionDAO) {
		this.detPosicionDAO = detPosicionDAO;
	} 
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public MrestriDAOService getMrestriDAOService() {
		return mrestriDAOService;
	}

	public void setMrestriDAOService(MrestriDAOService mrestriDAOService) {
		this.mrestriDAOService = mrestriDAOService;
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}
	*/
	/*
	public CatalogoAyudaService getCatalogoAyudaService() {
		return catalogoAyudaService;
	}
	//Inicio P34
	
	public RectificacionOficioService getRectificacionOficioService() {
		return rectificacionOficioService;
	}
	public void setRectificacionOficioService(RectificacionOficioService rectificacionOficioService) {
		this.rectificacionOficioService = rectificacionOficioService;
	}
	//Fin P34
*/

}
