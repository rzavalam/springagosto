package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.juguetes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//import java.util.Map;

import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.juguetes.model.Juguete;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima.tipoValidacion;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class ValidadorJuguete extends ValidadorAbstract{

  public static final String SET="005";
  public static final String JUGUETE_RUEDAS="001";
  public static final String MUNECO="002";
  public static final String JUGUETE_PARA_ARMAR="003";
  public static final String JUEGO_COMPUESTO_DISTINTOS_ELEMENTOS="010";
  public static final String ARMAS="008";
  public static final String CATALOGO_COMPONENTE = "458";  
  public static final String CATALOGO_UNID_COMER_DOM = "563";
  public static final String PIEZAS_FORMATO = "(?=.*[1-9])\\d{1,}";



  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception {
    List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);
    //lstErroresDescrMin.addAll(validarEstructura(objeto));

      if (CollectionUtils.isEmpty(lstErroresDescrMin)){
          lstErroresDescrMin.addAll(validarUnidadComercialJuguetes(objeto, dua));
          lstErroresDescrMin.addAll(validarNombreJuguete(objeto));
          lstErroresDescrMin.addAll(validarMarcaComercialJuguete(objeto));
          lstErroresDescrMin.addAll(validarModeloComercialJuguetes(objeto));
          lstErroresDescrMin.addAll(validarCodigoMercanciaJuguetes(objeto));
          lstErroresDescrMin.addAll(validarComposicionMercanciaJuguetes(objeto));
          lstErroresDescrMin.addAll(validarDimensionesJuguetes(objeto));
          lstErroresDescrMin.addAll(validarTiposSubTiposJuguetes(objeto));
          lstErroresDescrMin.addAll(validarAccesoriosJuguetes(objeto));
          lstErroresDescrMin.addAll(validarFuenteMovimientoJuguete(objeto));
          lstErroresDescrMin.addAll(validarUsuarioJuguete(objeto));
          lstErroresDescrMin.addAll(validarPresentacionJuguete(objeto));
      }

    return lstErroresDescrMin;
  }

  public List<ErrorDescrMinima>  validarUnidadComercialJuguetes (ModelAbstract objeto, Declaracion dua){
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);
    Juguete juguete = (Juguete) objeto;
    String datoAValidar = item.getCodunidcomer().trim();
    
	//rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
	Map<String,Object> variablesIngreso = objeto.getMapCatalogos();
     if(noestaEnSubGrupoCatalogo(CATALOGO_UNID_COMER_DOM,datoAValidar,variablesIngreso))
    {
      Object[] demasArgumentosMSJError = new Object[] { juguete.getNumsecprove(),juguete.getNumsecfact(),
      juguete.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
      ErrorDescrMinima error = obtenerError("31049",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
      errorLst.add(error);
    }
    return errorLst;

  }

  public List<ErrorDescrMinima>  validarNombreJuguete(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarMarcaComercialJuguete(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarModeloComercialJuguetes (ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarCodigoMercanciaJuguetes (ModelAbstract objeto){
	return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarComposicionMercanciaJuguetes (ModelAbstract objeto){
	  
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
    Juguete juguete = (Juguete) objeto;       
	boolean noEstaEnCatalogoSegundoComponente = noEstaEnCatalogo(juguete.getSegundoComponente().getValtipdescri().trim(), CATALOGO_COMPONENTE, fechaVigencia);
	boolean establaSegundoComponente=juguete.getSegundoComponente().getCodtipvalor().trim().equals("0")?true:false;
	if(!SunatStringUtils.isEmpty(juguete.getTercerComponente().getValtipdescri()) &&
			(SunatStringUtils.isEmpty(juguete.getSegundoComponente().getValtipdescri().trim()) || 
					(noEstaEnCatalogoSegundoComponente && establaSegundoComponente)))	
    	   errorLst.add(obtenerError("31053", juguete.getTercerComponente()));
    return errorLst;        
  }



  public List<ErrorDescrMinima>  validarDimensionesJuguetes (ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  }



  public List<ErrorDescrMinima>  validarTiposSubTiposJuguetes (ModelAbstract objeto){

	    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
	    Juguete juguete = (Juguete) objeto;
	    String nomProductoJuguete = juguete.getNombreComercial().getValtipdescri().trim();
	    String cantidadJugueteParaArmar = juguete.getCantidadJugueteParaArmar().getValtipdescri().trim();
	    boolean envioJugueteparaArmar= false;
	    boolean envioArmas= false;
	    

	    if(nomProductoJuguete.equals(JUGUETE_RUEDAS)) 
	    	errorLst.addAll(perteneceTipo( juguete.getTipoJugueteRuedas().getValtipdescri().trim(), "31055",juguete.getTipoJugueteRuedas())) ;
	    else   if(nomProductoJuguete.equals(MUNECO)){
	    	errorLst.addAll(perteneceTipo( juguete.getActividadJuguete().getValtipdescri().trim(), "31057",juguete.getActividadJuguete() )) ;
	    	if (!SunatStringUtils.isEmpty(juguete.getTipoJugueteRuedas().getValtipdescri().trim())){
	            String regla="es mu�eca(o)";
	            String campo= obtenerDescripcionDelCalogo("500", juguete.getTipoJugueteRuedas().getCodtipdescr());
	            Object[] argumentos = new Object[] { regla,campo };
	            ErrorDescrMinima error = obtenerError("30897",juguete.getNombreComercial(), argumentos);
	            errorLst.add(error);    		
	    	}
	    }
	    else   if(nomProductoJuguete.equals(JUEGO_COMPUESTO_DISTINTOS_ELEMENTOS)) 
	    	   errorLst.addAll(perteneceTipo( juguete.getTipoJugueteCompuesto().getValtipdescri().trim(), "31063",juguete.getTipoJugueteCompuesto()) ) ;
	    		 
	    else 	if( nomProductoJuguete.equals(JUGUETE_PARA_ARMAR)) 
				{	errorLst.addAll(perteneceTipo( juguete.getTipoJugueteParaArmar().getValtipdescri().trim(), "31844",juguete.getTipoJugueteParaArmar())) ;
				    errorLst.addAll(cantidadPiezas(  cantidadJugueteParaArmar, "31059","31773",  juguete.getCantidadJugueteParaArmar()));
				    envioJugueteparaArmar=true;
	 			}
	    
	   else    if(nomProductoJuguete.equals(ARMAS))			
				{	errorLst.addAll(perteneceTipo( juguete.getTipoArmas().getValtipdescri().trim(), "31065",juguete.getTipoArmas() )) ;
					errorLst.addAll(perteneceTipo( juguete.getTipoProyectilesArmas().getValtipdescri().trim(), "31067",juguete.getTipoProyectilesArmas() )) ;
				     envioArmas=true;
				}

	    
	    
		if (!envioJugueteparaArmar && !SunatStringUtils.isEmpty(cantidadJugueteParaArmar))
			errorLst.add(obtenerError("31842", juguete.getCantidadJugueteParaArmar()));
		if (!envioArmas && !SunatStringUtils.isEmpty(juguete.getTipoProyectilesArmas().getValtipdescri()))
			errorLst.add(obtenerError("31843", juguete.getTipoProyectilesArmas()));
	   
	    
	 	return errorLst; 
	}


  public List<ErrorDescrMinima>  validarAccesoriosJuguetes (ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarFuenteMovimientoJuguete(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarUsuarioJuguete(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();

  }

  public List<ErrorDescrMinima>  validarPresentacionJuguete(ModelAbstract objeto)
  {		List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
	  	Juguete juguete = (Juguete) objeto;
	  	String datoAValidarModoPres = juguete.getModoPresentacion().getValtipdescri().trim();
	  	String datoAValidarCantidadPiezas =juguete.getCantidadPiezasSet().getValtipdescri().trim();
  
		if(datoAValidarModoPres.equals(SET))
			errorLst.addAll(cantidadPiezas( datoAValidarCantidadPiezas, "31070","31773",  juguete.getCantidadPiezasSet()));
		else 
			{ if (!SunatStringUtils.isEmpty(juguete.getCantidadPiezasSet().getValtipdescri()))  
				errorLst.add(obtenerError("31841", juguete.getCantidadPiezasSet()));
			}
  return errorLst;
  }
  
  
  private  List<ErrorDescrMinima> cantidadPiezas( String datoAValidar, String errorVacio,String errorExReg, DatoDescrMinima jugueteDato1 ) 
  {
	  List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
	  	 
	  if (SunatStringUtils.isEmpty(datoAValidar)) 
	  		{  errorLst.add(obtenerError(errorVacio, jugueteDato1));}
	  else {  
		  if (noCumpleExpresionRegular(datoAValidar, PIEZAS_FORMATO))   errorLst.add(obtenerError(errorExReg, jugueteDato1 ));}
	   	
		return errorLst;
  }
  
  private List<ErrorDescrMinima> perteneceTipo( String datoTipo, String errorVacio, DatoDescrMinima jugueteDato ) 
  {
	  List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
	  if (SunatStringUtils.isEmpty(datoTipo))	errorLst.add(obtenerError(errorVacio,  jugueteDato));   
	
	  return errorLst;		
  }

  
  
  
  
  
}