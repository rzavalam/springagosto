/*
 * Clase que define el servicio de validaciones de la Informacion de Costeo de adecuaciones a vehiculos
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValVehiculo. Clase que define el servicio de validaciones de la Informacion de Costeo de adecuaciones a vehiculos.
 */
public class ValVehiculoServiceImpl extends ValDuaAbstract implements ValVehiculo {
	
	/**
	 * Valida el Numero de item.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numitemb String. Numero Item.
	 * @return Map
	 */
	public Map<String, String> numitemb(String numitemb){
		return !SunatStringUtils.isEmptyTrim(numitemb)?new HashMap<String,String>():getDUAError("30096","");
	}

	/**
	 * Valida el Nombre De La De Publicaci�n.
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nomlibro String. Nombre De La De Publicaci�n.
	 * @return Map
	 */
	public Map<String, String> nomlibro(String nomlibro){
		if (SunatStringUtils.isEmptyTrim(nomlibro))
			return getDUAError("01501","");
		else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el codigo de ejemplar De La Publicaci�n.
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codejempl String. Ejemplar De La Publicaci�n.
	 * @return Map
	 */
	public Map<String, String> codejempl(String codejempl){
		return !SunatStringUtils.isEmptyTrim(codejempl)?new HashMap<String,String>():getDUAError("01502","");
	}

	/**
	 * Valida la Fecha De Publicacion.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param annmespubli String. Fecha De Publicacion.
	 * @return Map
	 */
	public Map<String, String> annmespubli(String annmespubli){
		return !SunatStringUtils.isEmptyTrim(annmespubli)?new HashMap<String,String>():getDUAError("01503","");
	}

	/**
	 * Valida el n�mero de p�gina.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numpagin Short. N�mero de p�gina.
	 * @return Map
	 */
	public Map<String, String> numpagin(Integer numpagin){
		return SunatNumberUtils.isGreaterThanZero(numpagin)?new HashMap<String,String>():getDUAError("01505","");
	}

	/**
	 * Valida el Factor De Conversi�n.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numfactconve BigDecimal. Factor De Conversi�n.
	 * @return Map
	 */
	public Map<String, String> numfactconve(BigDecimal numfactconve){
		return SunatNumberUtils.isGreaterOrEqualsThanZero(numfactconve)?new HashMap<String,String>():getDUAError("01506","");
	}

}
