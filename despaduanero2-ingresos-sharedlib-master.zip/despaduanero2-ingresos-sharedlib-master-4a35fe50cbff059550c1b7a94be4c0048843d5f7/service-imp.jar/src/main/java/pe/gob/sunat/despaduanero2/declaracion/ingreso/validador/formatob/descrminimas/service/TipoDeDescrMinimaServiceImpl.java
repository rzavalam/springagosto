package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima.TIPO_LENTE;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima.TIPO_TEXTIL;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoValidacionDescrMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValidacionFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.exception.DescrMinimaException;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.vehiculos.ValidadorVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.util.ReflectionUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * La Class TipoDeDescrMinimaServiceImpl.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class TipoDeDescrMinimaServiceImpl extends ValidacionFormatoB implements TipoDeDescrMinimaService
{


	private static final String CASE = "CAS";
	private static final String COMPUTADORA = "COM";
	private static final String CAT393_COMPUTADORA = "24";
	private static final String CPU = "CPU";
	private static final String CAT393_CPU = "25";
	private static final String DISCO_DURO = "DDR";
	private static final String CAT393_DISCO_DURO = "26";
	private static final String DISQUETERA = "DIS";
	private static final String CAT393_DISQUETERA = "27";
	private static final String IMPRESORA = "IMP";
	private static final String CAT393_IMPRESORA = "28";
	// private static final String[] LST_CDROM = {"LCD", "LCW","LCR","LDV","LDW","LRW","BLU"};
	private static final String CAT393_CDROM = "29";
	private static final String MEMORIA = "MEM";
	private static final String CAT393_MEMORIA = "30";
	private static final String MONITOR = "MON";
	private static final String CAT393_MONITOR = "31";
	private static final String MOUSE = "MOU";
	private static final String CAT393_MOUSE = "32";
	private static final String PROCESADOR = "PRO";
	private static final String CAT393_PROCESADOR = "33";
	private static final String SCANNER = "SCA";
	private static final String CAT393_SCANNER = "34";
	private static final String TARJETA_SONIDO = "TSN";
	private static final String CAT393_TARJETA_SONIDO = "35";
	private static final String TARJETA_VIDEO = "TGV";
	private static final String CAT393_TARJERA_VIDEO = "36";
	private static final String TARJETA_RED = "TRD";
	private static final String CAT393_TARJETA_RED = "37";
	private static final String TARJETA_MADRE = "TMD";
	private static final String CAT393_TARJETA_MADRE_ = "38";
	private static final String TECLADO = "TEC";
	private static final String CAT393_TECLADO = "39";
	private static final String VENTILADOR_COOLER = "VEN";
	private static final String CAT393_VENTILADOR = "40";
	private static final String ZIP_DRIVE = "ZIP";
	private static final String CAT393_ZIP_DRIVE = "41";

	protected final Log            log = LogFactory.getLog(getClass());

	//private static final String[] NOMBRE_COMERCIAL_SANITARIOS_OTROS = {"CTK", "LAV","LAV","FGD","PDL","SPL","BDT","URI","B�A"};
	//private static final String[] COMPOSICION_PARTE_SUPERIOR_PLASTICO_SINTETICO = {"CAU", "PLA","CUS"};
	private static final String CAT_NOMBRCOMERCIAL_CERAMICOS = "509";//adicionado por Arey PAS20155E220000384

	//Tipificacion Dinamica - PAS20165E220200137
	private static final String CAT_GRUPO_DETERMINACION_DM_SANITARIOS_OTROS = "612";
	private static final String CAT_GRUPO_DETERMINACION_DM_CALZADOPLASTICO = "613";
	private static final String CAT_GRUPO_DETERMINACION_DM_CDROM ="614";

	@Autowired
	private FabricaDeServicios fabricaDeServicios;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String obtenerTipoDeDescrMinima(long numCorreDoc, int numSecItem)
	{
		/*Inicio Descripciones Minimas - AREY*/
		String tipoDescrMin = "";
		Map<String, Object> mapBusqueda=  new HashMap<String, Object>();
		mapBusqueda.put("NUM_CORREDOC",numCorreDoc);	  
		mapBusqueda.put("NUM_SECITEM", numSecItem);
		Map<String, Object> tipoDescr;

		ItemFacturaDAO itemFactura = fabricaDeServicios.getService("itemFacturaDAO");

		List<Map<String, Object>> lstTipo = itemFactura.getCodTipDescrMin(mapBusqueda);
		if(lstTipo!=null && lstTipo.size()>0){
			tipoDescr=lstTipo.get(0);
			if(tipoDescr.get("cod_tipdescrmin").toString().trim().length()>0){

				tipoDescrMin=tipoDescr.get("cod_tipdescrmin").toString();

			}
		}

		/*Fin Descripciones Minimas*/
		return tipoDescrMin;
	}

	//rtineo mejoras, sobrecargamos el metodo
	@Override
	public Enum<?> obtenerTipoDeDescrMinima(DatoItem item) throws Exception{
		return obtenerTipoDeDescrMinima(item,null,null);//ajuste para considerar
	}
	//rtineo fin

	public Enum<?> obtenerTipoDeDescrMinima(DatoItem item, Date fechaVigencia ) throws Exception{
		return obtenerTipoDeDescrMinima(item,fechaVigencia, null);
	}
	/**
	 * {@inheritDoc}
	 * 
	 **/
	@Override
	public Enum<?> obtenerTipoDeDescrMinima(DatoItem item,Date fechaVigencia, Map<String, Object> variablesIngreso) throws Exception
	{

		String partida = item.getNumpartnandi().toString();
		//rtineo mejoras, se consulta a variablesIngreso
		Enum<?> tipo;

		if(fechaVigencia == null){//si es numeracion llega null y aca se coloca la del dia PASE137 DESCRMIN
			fechaVigencia = SunatDateUtils.getCurrentDate();
		}

		if(variablesIngreso != null){
			tipo = obtenerAsociacionDeLaPartidaATipoDescrMin(partida,fechaVigencia, variablesIngreso);
		}else{
			//continua metodo anterior
			tipo = obtenerAsociacionDeLaPartidaATipoDescrMin(partida, fechaVigencia);
		}
		//rtineo mejoras fin

		if (tipo != null)
		{
			//amancilla se agrega ceramico segun sau de wilmer
			if (ArrayUtils.contains(new String[] { "SANITARIO", "COMPUTO", "REPRO","CERAMICO"},tipo.name()))
			{
				//rtineo mejoras, se llama a variablesIngreso
				if(variablesIngreso != null){
					tipo = obtenerTipoDesrMinimaPorNombreComercial(item, tipo, fechaVigencia, variablesIngreso);        		
				}else{
					tipo = obtenerTipoDesrMinimaPorNombreComercial(item, tipo, fechaVigencia);
				}
			}
			else if ("CALZADO".equals(tipo.name()))
			{
				if(variablesIngreso != null){
					tipo = obtenerTipoDesrMinimaPorMaterialparteSuperior(item, partida, fechaVigencia, variablesIngreso);
				}else{
					tipo = obtenerTipoDesrMinimaPorMaterialparteSuperior(item, partida, fechaVigencia);
				}
			}

			// implementacion de la descr minima textiles sub tipo prendas
			// SPN 9404900000 solo cuando se declara como nombre comercial los
			// c�digos EDR (Edred�n) o COJ (Coj�n),

			if ("9404900000".equals(partida))
			{
				String nombreComercial = obtenerNombreComercial(item.getListDecrMinima(), tipo);
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				Date fechaControlVersionValidador = (Date) catalogoAyudaService.getElementoCat("380", "0025").get("fec_inidatcat");

				if (fechaControlVersionValidador!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaVigencia, fechaControlVersionValidador, SunatDateUtils.COMPARA_SOLO_FECHA)){
					if (!nombreComercial.equals("EDR"))//ajuste R737 por PAS20165E220200137
					{
						tipo = null; // no es una descr minimas
					}
				}else{

					if (!ArrayUtils.contains(new String[] { "EDR", "COJ" }, nombreComercial))
					{
						tipo = null; // no es una descr minimas
					}
				}
			}
			//excepciones para pilas
			if ("8506900000".equals(partida)){tipo = null;}

			//Excepciones para Reproductores RIN13 SWF
			if ("8521909000".equals(partida)){tipo = null;}

			//Excepciones para Utiles de escritorio RIN13 SWF
			//if ("9608200000".equals(partida)){tipo = null;}//se comenta por SAU201510002000106 -si requiere cerrar vigencia desde catasoc 015

			//implementacion de la descr minima lentes subtipo Gafas 9004.90.90.00 cuando no sea "Gafas (anteojos) correctoras" (GCC) no debe ser minimas SAU20153D211200262 
			if("9004909000".equals(partida))
			{
				String nombreComercial = obtenerNombreComercial(item.getListDecrMinima(), tipo);
				if (!ArrayUtils.contains(new String[] { "GCC" }, nombreComercial))
				{
					tipo = null;
				}
			}

		}

		//casos excepcionales que no van hacer considerados como descr minimas no deben enviar la nueva estructura
		//si no al antigua
		//rtineo mejoras, llamamos al metodo con variablesIngreso
		boolean tieneNuevaEstructura=false;
		if(variablesIngreso != null){
			tieneNuevaEstructura = tieneNuevaEstructura(item,variablesIngreso);
		}else{
			tieneNuevaEstructura = tieneNuevaEstructura(item);
		}
		//rtineo mejoras, fin
		if (tipo == null && tieneNuevaEstructura)
		{

			Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
					item.getNumsecitem(),partida};

			ErrorDescrMinima error = new ErrorDescrMinima("31847","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: partida {3} no registrada para el envi� de la nueva estructura de descripciones m�nimas.");

			error.setParametros(parametros);

			throw new DescrMinimaException(this, error);
		}

		return tipo;
	}

	//rtineo mejoras, sobrecargamos el metodo
	private Enum<?> obtenerTipoDesrMinimaPorNombreComercial(DatoItem item, Enum<?> tipo) throws Exception {
		return obtenerTipoDesrMinimaPorNombreComercial(item,tipo,null, null);
	}

	//Adicionado para que considere la fecha de declaracion de la dam
	private Enum<?> obtenerTipoDesrMinimaPorNombreComercial(DatoItem item, Enum<?> tipo, Date fechaVigencia) throws Exception {
		return obtenerTipoDesrMinimaPorNombreComercial(item,tipo,fechaVigencia, null);
	}

	private Enum<?> obtenerTipoDesrMinimaPorNombreComercial(DatoItem item, Enum<?> tipo, Date fechaVigencia,  Map<String,Object> variablesIngreso) throws Exception {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<DatoDescrMinima> listDecrMinima = item.getListDecrMinima();

		Enum<?> subTipo = null;
		String codigoBusqueda = "";
		//amancilla se comenta para validar tanto nueva como antigua estructura
		// if (tieneNuevaEstructura(listDecrMinima))
		// {
		if ("SANITARIO".equals(tipo.name()))
		{
			//amancilla String nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "SA0100");
			String nombreComercial = obtenerNombreComercial(listDecrMinima, "SA0100");

			if("".equals(nombreComercial))
			{
				//amancilla nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "SA0200");
				nombreComercial = obtenerNombreComercial(listDecrMinima, "SA0200");
			}

			if (!SunatStringUtils.isEmpty(nombreComercial))
			{
				if ("INO".equals(nombreComercial))
				{
					subTipo = TipoDescrMinima.get("48");
				}
				/*else if (ArrayUtils.contains(NOMBRE_COMERCIAL_SANITARIOS_OTROS, nombreComercial)
                            || esZZZ(listDecrMinima,"SA0200"))*/
				else if (catalogoAyudaService.getDataGrupoCat(CAT_GRUPO_DETERMINACION_DM_SANITARIOS_OTROS, nombreComercial, fechaVigencia)!=null || esZZZ(listDecrMinima,"SA0200"))
				{
					subTipo = TipoDescrMinima.get("49");
				}
				else
				{
					//rtineo, mejoras se verifica variablesIngreso
					boolean tieneNuevaEstructura = false;
					if(variablesIngreso != null){
						tieneNuevaEstructura = tieneNuevaEstructura(listDecrMinima,variablesIngreso);
					}else{
						tieneNuevaEstructura = tieneNuevaEstructura(listDecrMinima);
					}
					//rtineo, fin mejoras
					if(tieneNuevaEstructura)
					{
						Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
								item.getNumsecitem()};

						ErrorDescrMinima error = new ErrorDescrMinima("30795","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: Nombre Comercial, no corresponde al catalogo <467> en la descripci�n m�nima de Sanitarios en el formato B");

						error.setParametros(parametros);

						throw new DescrMinimaException(this, error);
					}


				}
			}
			else
			{
				Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
						item.getNumsecitem()};

				ErrorDescrMinima error = new ErrorDescrMinima("30796","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: No ha consignado Nombre Comercial de la descripci�n m�nima Sanitarios en el formato B.");
				error.setParametros(parametros);

				throw new DescrMinimaException(this, error);
			}
		}
		else if ("COMPUTO".equals(tipo.name()))
		{

			String nombreComercial = "";

			for ( int subgrupo = 1; subgrupo <= 18; subgrupo ++ ) {

				String codCampo="CO"+ StringUtils.leftPad(""+subgrupo,2,"0")+"00";
				//amancilla nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, codCampo);
				nombreComercial = obtenerNombreComercial(listDecrMinima, codCampo);
				if(!"".equals(nombreComercial)){
					break;
				}
			}

			//amancilla podria ser que envien con la antigua estructura
			/*if("".equals(nombreComercial))
                {
                    nombreComercial = obtenerNombreComercial(listDecrMinima,tipo);
                }*/

			if (!SunatStringUtils.isEmpty(nombreComercial))
			{
				// amancilla se quita segun w ramirez if (CASE.equals(nombreComercial)){subTipo = TipoDescrMinima.get("XYZ");}
				if (COMPUTADORA.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_COMPUTADORA);}
				else if (CPU.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_CPU);}
				else if (DISCO_DURO.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_DISCO_DURO);}
				else if (DISQUETERA.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_DISQUETERA);}
				else if (IMPRESORA.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_IMPRESORA);}
				// else if (ArrayUtils.contains(LST_CDROM, nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_CDROM);}//ahora con vigencia PAS20165E220200137
				else if (catalogoAyudaService.getDataGrupoCat(CAT_GRUPO_DETERMINACION_DM_CDROM, nombreComercial, fechaVigencia)!=null){subTipo = TipoDescrMinima.get(CAT393_CDROM);}                     
				else if (MEMORIA.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_MEMORIA);}
				else if (MONITOR.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_MONITOR);}
				else if (MOUSE.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_MOUSE);}
				else if (PROCESADOR.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_PROCESADOR);}
				else if (SCANNER.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_SCANNER);}
				else if (TARJETA_SONIDO.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_TARJETA_SONIDO);}
				else if (TARJETA_VIDEO.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_TARJERA_VIDEO);}
				// amancilla se quita segun w ramirez else if ("TFM".equals(nombreComercial)){subTipo = TipoDescrMinima.get("XYZ");}
				else if (TARJETA_RED.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_TARJETA_RED);}
				else if (TARJETA_MADRE.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_TARJETA_MADRE_);}
				else if (TECLADO.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_TECLADO);}
				else if (VENTILADOR_COOLER.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_VENTILADOR);}
				else if (ZIP_DRIVE.equals(nombreComercial)){subTipo = TipoDescrMinima.get(CAT393_ZIP_DRIVE);}
				else
				{
					if(tieneNuevaEstructura(listDecrMinima))
					{
						//amancilla se coordino con wilmer ramirez los que no estan en este catalogo no seran considerados como descr minimas
						tipo = null; // no es una descr minimas
						Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
								item.getNumsecitem()};

						ErrorDescrMinima error = new ErrorDescrMinima("31030","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: Nombre Comercial, no corresponde el envio de descripci�n m�nima de computadoras en el formato B");

						error.setParametros(parametros);

						throw new DescrMinimaException(this, error);
					}
				}
			}
			else
			{
				Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
						item.getNumsecitem()};

				ErrorDescrMinima error = new ErrorDescrMinima("31031","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: No ha consignado Nombre Comercial de la descripci�n m�nima computadoras en el formato B.");
				error.setParametros(parametros);
				throw new DescrMinimaException(this, error);
			}
		}
		else if ("REPRO".equals(tipo.name()))
		{

			String nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0100");
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0200");}
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0300");}
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0400");}
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0500");}
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0600");}
			if("".equals(nombreComercial)) {nombreComercial = obtenerNombreComercial(listDecrMinima, "RE0700");}

			if (!SunatStringUtils.isEmpty(nombreComercial))
			{

				//amancilla parche de pirata
				if ("DIS".equals(nombreComercial)){subTipo = TipoDescrMinima.get("07");}
				else if ("CAU".equals(nombreComercial)){subTipo = TipoDescrMinima.get("08");}
				else if ("CVI".equals(nombreComercial)){subTipo = TipoDescrMinima.get("09");}
				else if ("EST".equals(nombreComercial)){subTipo = TipoDescrMinima.get("10");}
				else if ("CNT".equals(nombreComercial)) {subTipo = TipoDescrMinima.get("11");}
				else if ("TRR".equals(nombreComercial)) {subTipo = TipoDescrMinima.get("12");}
				else if ("DUC".equals(nombreComercial)) {subTipo = TipoDescrMinima.get("13");}
				else
				{
					if(tieneNuevaEstructura(listDecrMinima))
					{
						Object[] parametros = new Object[]{item.getNumsecprove(), item.getNumsecfact(),
								item.getNumsecitem()};

						//amancilla ErrorDescrMinima error = new ErrorDescrMinima("31854", "Secuencia de Proveedor:<{0}>,Secuencia de Factura:<{1}>,Secuencia del Item:<{2}>, Mensaje: Nombre Comercial, no corresponde al catalogo <1O> en la descripci�n m�nima de Reproduccion en el formato B.");
						ErrorDescrMinima error = new ErrorDescrMinima("31854", "Secuencia de Proveedor:<{0}>,Secuencia de Factura:<{1}>,Secuencia del Item:<{2}>, Mensaje: Nombre Comercial, no corresponde el envio de descripci�n m�nima de Reproduccion en el formato B.");
						error.setParametros(parametros);

						throw new DescrMinimaException(this, error);
					}
				}
			}
			else
			{
				Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
						item.getNumsecitem()};

				ErrorDescrMinima error = new ErrorDescrMinima("31855","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: No ha consignado Nombre Comercial de la descripci�n m�nima Reproduccion en el formato B.");
				error.setParametros(parametros);

				throw new DescrMinimaException(this, error);
			}
		}
		else if ("CERAMICO".equals(tipo.name()))
		{
			String nombreComercial = obtenerNombreComercial(listDecrMinima, "CE0000");
			if (!SunatStringUtils.isEmpty(nombreComercial))
			{
				DataCatalogo dataCatalogo=null;
				//Inicio de cambios por PAS20165E220200137, en version2 el campo de nombre comercial del cer�mico es texto, ya no cat�logo:
				Date fechaControlVersionValidador = (Date) catalogoAyudaService.getElementoCat("380", "0025").get("fec_inidatcat");

				if (fechaControlVersionValidador!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaVigencia, fechaControlVersionValidador, SunatDateUtils.COMPARA_SOLO_FECHA)){

					dataCatalogo = catalogoAyudaService.getDataCatalogo("532", item.getNumpartnandi().toString(), fechaVigencia);
					if(dataCatalogo!=null){
						subTipo = TipoDescrMinima.get("46");//para que considere las vigentes en el catalogo de partidas asociadas a MINIMAS.
					} else{
						dataCatalogo = catalogoAyudaService.getDataCatalogo("532", item.getNumpartnandi().toString().substring(0, 4), fechaVigencia);
						if(dataCatalogo!=null){
							subTipo = TipoDescrMinima.get("46");//para que considere las vigentes en el catalogo de partidas asociadas a MINIMAS.
						}
					}

				}else{
					//Fin de cambios por PAS20165E220200137

					/**ajuste no consideraba el cat�logoo! se busca en cat�logo recien por Arey PAS20155E220000384**/
					List<Map<String, String>> lista =catalogoAyudaService.getElementosCat(CAT_NOMBRCOMERCIAL_CERAMICOS, nombreComercial, " ");
					if (!CollectionUtils.isEmpty(lista)){
						/**Fin de ajuste Arey PAS20155E220000384**/
						//                    if (ArrayUtils.contains(new String[] { "BSE", "BES","LST","INT","TOC","PPL","PCR","ZCL","MRT" }, nombreComercial)){
						subTipo = TipoDescrMinima.get("46");
					} else {
						if(tieneNuevaEstructura(listDecrMinima))
						{
							Object[] parametros = new Object[]{item.getNumsecprove(), item.getNumsecfact(),
									item.getNumsecitem()};

							ErrorDescrMinima error = new ErrorDescrMinima("31924", "Secuencia de Proveedor:<{0}>,Secuencia de Factura:<{1}>,Secuencia del Item:<{2}>, Mensaje: Nombre Comercial, no corresponde el envio de descripcion minima de productos ceramicos en el formato B.");
							error.setParametros(parametros);

							throw new DescrMinimaException(this, error);
						}
					}
				}//adicionado por cambios por PAS20165E220200137
			}
			else
			{
				Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
						item.getNumsecitem()};

				ErrorDescrMinima error = new ErrorDescrMinima("31925","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: No ha consignado Nombre Comercial de la descripcion minima productos ceramicos en el formato B.");
				error.setParametros(parametros);

				throw new DescrMinimaException(this, error);
			}
		}

		return subTipo;
	}

	//rtineo mejoras, sobrecargamos el metodo
	private Enum<?> obtenerTipoDesrMinimaPorMaterialparteSuperior(DatoItem item, String partida) throws Exception {
		return obtenerTipoDesrMinimaPorMaterialparteSuperior(item, partida, null, null);
	}

	//adicionado para que considere la fecha de declaracion de la dua
	private Enum<?> obtenerTipoDesrMinimaPorMaterialparteSuperior(DatoItem item, String partida, Date fechaVigencia) throws Exception {
		return obtenerTipoDesrMinimaPorMaterialparteSuperior(item, partida, fechaVigencia, null);
	}

	private Enum<?> obtenerTipoDesrMinimaPorMaterialparteSuperior(DatoItem item, String partida, Date fechaVigencia, Map<String,Object> variablesIngreso) throws Exception {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<DatoDescrMinima> listDecrMinima = item.getListDecrMinima();

		Enum<?> tipo = null;

		String codigoBusqueda = "";
		//rtineo mejoras, variablesIngreso
		boolean tieneNuevaEstructura = false;
		if(variablesIngreso != null){
			tieneNuevaEstructura = tieneNuevaEstructura(listDecrMinima, variablesIngreso);
		}else{
			tieneNuevaEstructura = tieneNuevaEstructura(listDecrMinima);
		}
		//rtineo fin
		if (tieneNuevaEstructura)
		{
			String nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "CA0103");

			if("".equals(nombreComercial)){
				nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "CA0203");
			}
			if("".equals(nombreComercial)){
				nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "CA0303");
			}
			if("".equals(nombreComercial)){
				nombreComercial = obtenerValorTAGValtipdescriPorCodigo(listDecrMinima, "CA0403");//aca llega el txto
			}

			if (!SunatStringUtils.isEmpty(nombreComercial))
			{
				nombreComercial = IngresoVariablesUtil.convertirParaRest(nombreComercial);//INC 2017-148207 caso marciano de minimas mandan cualquier nombre marciano
				if ("CUN".equals(nombreComercial))
				{
					tipo = TipoDescrMinima.get("15");
				}
				//else if (ArrayUtils.contains(COMPOSICION_PARTE_SUPERIOR_PLASTICO_SINTETICO, nombreComercial))//ahora con vigencia PAS20165E220200137
				else if (catalogoAyudaService.getDataGrupoCat(CAT_GRUPO_DETERMINACION_DM_CALZADOPLASTICO, nombreComercial, fechaVigencia)!=null) 
				{
					tipo = TipoDescrMinima.get("16");
				}
				else if ("TEX".equals(nombreComercial))
				{
					tipo = TipoDescrMinima.get("17");
				}
				else
				{
					tipo = TipoDescrMinima.get("18");
				}
			}
			else
			{
				Object[] parametros = new Object[]{item.getNumsecprove(),item.getNumsecfact(),
						item.getNumsecitem()};

				ErrorDescrMinima error = new ErrorDescrMinima("31032","Secuencia de Proveedor : <{0}>,Secuencia de Factura : <{1}>,Secuencia del Item : <{2}>, Mensaje: No ha consignado material de la parte superior de la descripci�n m�nima calzado en el formato B.");

				error.setParametros(parametros);

				throw new DescrMinimaException(this, error);
			}
		}
		else
		{
			ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
			String tipoMerc = funcionesService.fnTipo(partida,obtenerValorTAGValtipdescriPorCodigo(listDecrMinima,"00"),obtenerValorTAGValtipdescriPorCodigo(listDecrMinima,"03"), SunatNumberUtils.getTodayAsInteger());

			if ("KE".equals(tipoMerc))
			{
				tipo = TipoDescrMinima.get("15");
			}
			else if ("KF".equals(tipoMerc))
			{
				tipo = TipoDescrMinima.get("16");
			}
			else if ("KG".equals(tipoMerc))
			{
				tipo = TipoDescrMinima.get("17");
			}
			else if ("KD".equals(tipoMerc))
			{
				tipo = TipoDescrMinima.get("18");
			}
		}

		return tipo;
	}

	private String obtenerValorTAGValtipdescriPorCodigo(List<DatoDescrMinima> listDecrMinima, String codigoBusqueda) throws Exception {

		String nombreComercial = "";

		if(!StringUtils.isEmpty(codigoBusqueda) && !CollectionUtils.isEmpty(listDecrMinima)){
			List<DatoDescrMinima> lstNombreComercial =
					ReflectionUtil.getObjectFromList(listDecrMinima,
							DatoDescrMinima.class, "codtipdescr",
							codigoBusqueda);

			if(!CollectionUtils.isEmpty(lstNombreComercial)){
				nombreComercial = lstNombreComercial.get(0).getValtipdescri();
			}
		}


		return nombreComercial;
	}


	private boolean  esZZZ(List<DatoDescrMinima> listDecrMinima, String codigoBusqueda) throws Exception {

		boolean esZZZ = false;

		List<DatoDescrMinima> lstNombreComercial =
				ReflectionUtil.getObjectFromList(listDecrMinima,
						DatoDescrMinima.class, "codtipdescr",
						codigoBusqueda);

		if(!CollectionUtils.isEmpty(lstNombreComercial)){
			esZZZ = "1".equals(lstNombreComercial.get(0).getCodtipvalor())?true:false;
		}

		return esZZZ;
	}

	//rtineo mejoras, se sobrecarga la funcion
	private Enum<?> obtenerAsociacionDeLaPartidaATipoDescrMin(String partida) throws Exception{
		return obtenerAsociacionDeLaPartidaATipoDescrMin(partida,null);
	}
	//rtineo mejoras, fin

	//adicionado para que considere la fecha de declaracion de la dam
	private Enum<?> obtenerAsociacionDeLaPartidaATipoDescrMin(String partida, Date fechaVigencia) throws Exception{
		return obtenerAsociacionDeLaPartidaATipoDescrMin(partida,fechaVigencia, null);
	}

	private Enum<?> obtenerAsociacionDeLaPartidaATipoDescrMin(String partida,Date fechaVigencia, Map<String, Object> variablesIngreso) throws Exception
	{
		CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Enum<?> tipo = null;
		if(StringUtils.isNotEmpty(partida))
		{
			// prueba con la partida de 10 caracteres
			//rtineo mejoras, se consulta a las variabesIngreso
			List<Map<String, String>> lista = new ArrayList<Map<String, String>>();
			if(variablesIngreso != null){
				//lista = IngresoVariablesUtil.getListaElementosAsoc(fabricaDeServicios,ASOCIACION_PARTIDA_VS_DESCRMINIMA,"C",partida,null,variablesIngreso);
				lista = IngresoVariablesUtil.getListaElementosAsoc(fabricaDeServicios,ASOCIACION_PARTIDA_VS_DESCRMINIMA,"C",partida,fechaVigencia,variablesIngreso);
			}else{
				//continua con metodo anterior
				/*lista =
                    getCatalogoHelper().getCatalogoAyudaService()
                            .getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA,
                                    "C", partida, null);*///considerando la fecha de la dam        		 
				lista = catalogoAyudaService.getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA, "C",partida,fechaVigencia);

			}
			//rtineo mejoras, fin
			// debe retornar 1 solo 1 partida pertence a un tipo de descr minima en
			// teoria

			// segunda prueba con partida 4 caractere
			if (CollectionUtils.isEmpty(lista))
			{
				//rtineo mejoras, se consulta a las variabesIngreso
				if(variablesIngreso != null){
					//lista = IngresoVariablesUtil.getListaElementosAsoc(fabricaDeServicios,ASOCIACION_PARTIDA_VS_DESCRMINIMA,"C",partida.substring(0, 4),null,variablesIngreso);
					lista = IngresoVariablesUtil.getListaElementosAsoc(fabricaDeServicios,ASOCIACION_PARTIDA_VS_DESCRMINIMA,"C",partida.substring(0, 4),fechaVigencia,variablesIngreso);
				}else{
					/*lista = getCatalogoHelper().getCatalogoAyudaService()
                        .getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA,
                                "C", partida.substring(0, 4), null);*///considerando la fecha de la dam
					lista = catalogoAyudaService.getListaElementosAsoc(ASOCIACION_PARTIDA_VS_DESCRMINIMA, "C",partida.substring(0, 4),fechaVigencia); 

				}
				//rtineo mejoras, fin
			}

			// caso en la que 1 partida esta asociada a un tipo de descr minima
			if (lista.size() == 1)
			{
				String codigoNEW = lista.get(0).get("cod_datacat");
				tipo = TipoDescrMinima.get(codigoNEW);
			}
			//amancilla
			/*else
            {
				// RTINEO OPTIMIZACION
                //se quita optimizacion jajaj
            	//if(log.isDebugEnabled())
            		log.warn("Nueva Estructura de Descripciones Minimas, Mensaje: Inconsistencia entre partidas:"+partida+" asociadas con la descr minima, multiple resultados"+lista);
            }*/
		}

		return tipo;
	}




	private String obtenerNombreComercial(List<DatoDescrMinima> listDecrMinima, String codigoBusqueda) throws Exception {

		//si no tiene nueva estructura jala la antigua
		if (!tieneNuevaEstructura(listDecrMinima))
		{
			codigoBusqueda = "00";
		}
		return obtenerValorTAGValtipdescriPorCodigo(listDecrMinima,codigoBusqueda);
	}

	private String obtenerNombreComercial(List<DatoDescrMinima> listDecrMinima, Enum<?> tipo) throws Exception {
		// String nombreComercial = ""; // tanto para la nueva con la antigua
		// estructura



		String codigoBusqueda = "";
		if (tieneNuevaEstructura(listDecrMinima))
		{

			if (TIPO_TEXTIL.PRENDAS.name().equals(tipo.name()))
			{
				codigoBusqueda = "TE0400";
			}
			/**PARA QUE RECONOZCA GAFAS**/
			if (TIPO_LENTE.GAFAS.name().equals(tipo.name()))
			{
				codigoBusqueda = "LE0200";
			}
			/**PARA QUE RECONOZCA GAFAS**/
		}
		else
		{
			codigoBusqueda = "00";
		}

		//amancilla se refactoriza
		/*
      List<DatoDescrMinima> lstNombreComercial =
          ReflectionUtil.getObjectFromList(listDecrMinima,
                                           DatoDescrMinima.class, "codtipdescr",
                                           codigoBusqueda);

            nombreComercial = lstNombreComercial.get(0).getValtipdescri();*/


		return obtenerValorTAGValtipdescriPorCodigo(listDecrMinima,codigoBusqueda);
	}

	/**
	 * {@inheritDoc}
	 **/
	@Override
	public TipoValidacionDescrMin determinarTipoValidacionAplicar(DatoItem item)
	{

		TipoValidacionDescrMin tipo = determinarValidacionAplicarProduccion(item);


		return tipo;
	}

	private TipoValidacionDescrMin determinarValidacionAplicarPruebas(DatoItem item)
	{
		TipoValidacionDescrMin tipo;
		if (noTieneNuevaEstructura(item))
		{
			CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Date fecVigencia =
					SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(CATALOGO_FECHA_VIGENCIA, "FEC_INIVIG").get("des_datacat").toString());

			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
				tipo = TipoValidacionDescrMin.ERROR_ESTRUCTURA_DEVIO_ENVIAR_NEW_ESTRUCTTURA;
			}
			else
			{
				tipo = TipoValidacionDescrMin.OLD_VALIDACIONES;
			}
		}
		else
		{
			tipo = TipoValidacionDescrMin.NEW_VALIDACIONES;
		}
		return tipo;
	}


	private TipoValidacionDescrMin determinarValidacionAplicarProduccion(DatoItem item)
	{
		TipoValidacionDescrMin tipo;
		CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Date fecVigencia =
				SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(CATALOGO_FECHA_VIGENCIA, "FEC_INIVIG").get("des_datacat").toString());

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			tipo = TipoValidacionDescrMin.NEW_VALIDACIONES;

			if (noTieneNuevaEstructura(item))
			{
				tipo = TipoValidacionDescrMin.ERROR_ESTRUCTURA_DEVIO_ENVIAR_NEW_ESTRUCTTURA;
			}

		}
		else
		{
			tipo = TipoValidacionDescrMin.OLD_VALIDACIONES;

			if (tieneNuevaEstructura(item))
			{
				tipo = TipoValidacionDescrMin.ERROR_ESTRUCTURA_DEVIO_ENVIAR_OLD_ESTRUCTTURA;
			}
		}

		return tipo;
	}

	//rtineo mejoras, sobrecargamos el metodo
	@Override
	public boolean tieneNuevaEstructura(DatoItem item){
		return tieneNuevaEstructura(item,null);
	}
	//rtineo mejoras, fin
	/**
	 * {@inheritDoc}
	 **/
	@Override
	public boolean tieneNuevaEstructura(DatoItem item,Map<String, Object> variablesIngreso)
	{
		//rtineo mejoras, se utiliza variablesIngreso
		if(variablesIngreso != null){
			return tieneNuevaEstructura(item.getListDecrMinima(),variablesIngreso);
		}else{
			//se continua con metodo anterior
			return tieneNuevaEstructura(item.getListDecrMinima());
		}

	}

	public TipoValidacionDescrMin determinarTipoValidacionPorTipoDescrMinima(DatoItem item){
		return determinarTipoValidacionPorTipoDescrMinima(item,null);
	}

	/**INICIO pase399*/
	public TipoValidacionDescrMin determinarTipoValidacionPorTipoDescrMinima(DatoItem item,Map<String, Object> variablesIngreso)
	{
		TipoValidacionDescrMin tipo;
		//rtineo mejoras, se consulta a variablesIngreso
		boolean noTieneNuevaEstructura = false;
		if(variablesIngreso != null){
			noTieneNuevaEstructura = noTieneNuevaEstructura(item,variablesIngreso);
		}else{
			//sigue ejecutando metodo anterior
			noTieneNuevaEstructura = noTieneNuevaEstructura(item);
		}
		//rtineo mejoras, fin
		if (noTieneNuevaEstructura)
		{
			tipo =  TipoValidacionDescrMin.OLD_VALIDACIONES;
		}
		else
		{
			tipo = TipoValidacionDescrMin.NEW_VALIDACIONES;

		}

		return tipo;
	}
	/**FIN pase399*/
	/*********************** METODOS PIRVADOS ******************************/
	private boolean noTieneNuevaEstructura(DatoItem item){
		return noTieneNuevaEstructura(item, null);
	}

	private boolean noTieneNuevaEstructura(DatoItem item,Map<String, Object> variablesIngreso)
	{
		//rtineo mejoras, se consulta a variablesIngreso
		if(variablesIngreso != null){
			return !tieneNuevaEstructura(item.getListDecrMinima(),variablesIngreso);
		}else{
			return !tieneNuevaEstructura(item.getListDecrMinima());
		}
		//rtineo fin
	}

	//rtineo mejoras, sobrecargamos el metodo
	private boolean tieneNuevaEstructura(List<DatoDescrMinima> lstDatosXML){
		return tieneNuevaEstructura(lstDatosXML,null);
	}
	//rtineo mejoras, fin

	private boolean tieneNuevaEstructura(List<DatoDescrMinima> lstDatosXML,Map<String, Object> variablesIngreso)
	{
		boolean nuevaEstructura = false;

		if (!CollectionUtils.isEmpty(lstDatosXML))
			for (DatoDescrMinima descrMinima: lstDatosXML)
			{
				//rtineo mejoras, utilizamos variablesIngreso para evitar llamadas rest repetitivos
				boolean noTieneNuevaEstructura = false;
				if(variablesIngreso != null){
					noTieneNuevaEstructura  = noTieneNuevaEstructura(descrMinima,variablesIngreso);
				}else{
					//se continua ejecutando metodo anterior
					noTieneNuevaEstructura  = noTieneNuevaEstructura(descrMinima);
				}
				//rtineo mejoras, fin

				if (noTieneNuevaEstructura)
				{
					nuevaEstructura = false;
					break;
				}
				else
				{
					nuevaEstructura = true;
				}
			}

		return nuevaEstructura;
	}

	//rtineo mejoras, sobrecargamos el metodo
	private boolean tieneNuevaEstructura(DatoDescrMinima descrMinima){
		return tieneNuevaEstructura(descrMinima,null);
	}

	private boolean tieneNuevaEstructura(DatoDescrMinima descrMinima,Map<String, Object> variablesIngreso)
	{
		Map catalogoNEW = new HashMap();
		Map catalogoOLD = new HashMap();
		if (descrMinima != null)
		{
			CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			// rtineo mejoras, se llama a variablesIngreso
			if(variablesIngreso != null){
				//catalogoOLD =  IngresoVariablesUtil.getElementoCat(fabricaDeServicios,CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA,descrMinima.getCodtipdescr(),variablesIngreso);
				Map<String,Object> mapOld =  (Map<String,Object>)variablesIngreso.get("MapTipoDescrOldCache");
				catalogoOLD = (Map)mapOld.get(descrMinima.getCodtipdescr());
				//catalogoNEW =  IngresoVariablesUtil.getElementoCat(fabricaDeServicios,CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA,descrMinima.getCodtipdescr(),variablesIngreso);
				Map<String,Object> mapNew =  (Map<String,Object>)variablesIngreso.get("MapTipoDescrNewCache");
				catalogoNEW = (Map)mapNew.get(descrMinima.getCodtipdescr());
			}else{
				//continua con el metodo anterior
				catalogoOLD =
						catalogoAyudaService.getElementoCat(CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA,
								descrMinima.getCodtipdescr());
				catalogoNEW =
						catalogoAyudaService.getElementoCat(CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA,
								descrMinima.getCodtipdescr());
			}
		}

		return !CollectionUtils.isEmpty(catalogoNEW) && CollectionUtils.isEmpty(catalogoOLD) ? true : false;
	}

	//rtineo mejoras sobrecargamos el metodo
	private boolean noTieneNuevaEstructura(DatoDescrMinima descrMinima){
		return noTieneNuevaEstructura(descrMinima,null);
	}

	private boolean noTieneNuevaEstructura(DatoDescrMinima descrMinima,Map<String, Object> variablesIngreso)
	{
		//rtineo mejoras, se utiliza variableIngreso
		if(variablesIngreso != null){
			return !tieneNuevaEstructura(descrMinima,variablesIngreso);
		}else{
			return !tieneNuevaEstructura(descrMinima);
		}
	}


}