package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDetdua;
import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandUniDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandinaDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.servicio2.registro.model.dao.T733DAO;

public class ValGeneralEERServiceImpl extends IngresoAbstractServiceImpl implements ValGeneralEERService  {
	protected final Log logGeneralEER = LogFactory.getLog(getClass());
	
	public List<Map<String, ?>> validarCategoriaDSEER (String codCategoria) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ResponseListManager responseListManager = new ResponseListManager();
		
		if (!ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_02.equals(codCategoria) &&
			!ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			responseListManager.addResponseMap(catalogoAyudaService.getError("70141"));
		}
		
		return responseListManager.getResponseList();
	}
	
	
	public List<Map<String, String>> validarConsistenciaFacturaGeneral(Declaracion dseer) {
		List<Map<String, String>> listaErrores = new ArrayList<Map<String, String>>();
		Map<String, String> error;
		boolean repetido = false;
		boolean existeAsociacion = false;
		int i;
		i=1;
		for (DatoSerie serie : dseer.getDua().getListSeries()) {
			//Inicio SRODRIGUEZ
//			if (serie.getListSerieDocSoporte().isEmpty()) {
			if (serie.getListSerieDocSoporte() == null || 
					serie.getListSerieDocSoporte().isEmpty()) {
			//Fin SRODRIGUEZL
				//Item no tiene facturas asociadas
				error = new HashMap<String, String>();
				error.put("codigoError", "2");
				error.put("item", serie.getNumserie() + "");
				listaErrores.add(error);
			}else {
				boolean existenFacturas = false;
				for (DatoSerieDocSoporte factura : serie.getListSerieDocSoporte()) {
					//Para MDEER la factura se identifica por Codigo de tipo de proceso, para DSEER se identifica por codigo de tipo de documento de soporte
					if(ConstantesDataCatalogo.CODIGO_OMA_DOCUMENTO_ORDEN_PAGO.equals(factura.getCodtipoproceso()) ||
							ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(factura.getCodtipodocsoporte())) {
						existenFacturas = true;
						if (factura.getNumiddocsoporte() == null) {
							//Secuencia de factura de Item no asociada a una factura valida
							error = new HashMap<String, String>();
							error.put("codigoError", "1");
							error.put("item", serie.getNumserie() + "");
							error.put("factura", factura.getNumiddocsoporte() + "");
							listaErrores.add(error);
						}else{
							repetido = false;
							for (DatoSerieDocSoporte factura2 : serie.getListSerieDocSoporte())
								//Para MDEER la factura se identifica por Codigo de tipo de proceso, para DSEER se identifica por codigo de tipo de documento de soporte
								if((ConstantesDataCatalogo.CODIGO_OMA_DOCUMENTO_ORDEN_PAGO.equals(factura2.getCodtipoproceso()) ||
										ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(factura2.getCodtipodocsoporte()))
										&& factura.getNumiddocsoporte().intValue() == factura2.getNumiddocsoporte().intValue()) {
									if(repetido) {
										//Secuencia de factura repetida en item
										error = new HashMap<String, String>();
										error.put("codigoError", "5");
										error.put("item", serie.getNumserie() + "");
										error.put("factura", factura.getNumiddocsoporte() + "");
										listaErrores.add(error);
										break;
									}
									repetido = true;
								}
						}
						existeAsociacion = false;
						for(DatoFacturaref factura2 : dseer.getDua().getListFacturaRef()) {
							if(factura2.getNumsecfactu().intValue() == factura.getNumiddocsoporte().intValue())
								existeAsociacion = true;
						}
						if(!existeAsociacion) {
							//Secuencia de factura de Item no asociada a una factura valida
							error = new HashMap<String, String>();
							error.put("codigoError", "1");
							error.put("item", serie.getNumserie() + "");
							error.put("factura", factura.getNumiddocsoporte() + "");
							listaErrores.add(error);
						}
					}
				}
				if(!existenFacturas) {
					//Item no tiene facturas asociadas
					error = new HashMap<String, String>();
					error.put("codigoError", "2");
					error.put("item", serie.getNumserie() + "");
					listaErrores.add(error);
				}
			}
		}
		//Inicio SRODRIGUEZ
//		if(dseer.getDua().getListFacturaRef().isEmpty()) {
		if(dseer.getDua().getListFacturaRef()==null||
			dseer.getDua().getListFacturaRef().isEmpty()) {
		//Fin SRODRIGUEZ
			//No se envio factura en la guia XX
			error = new HashMap<String, String>();
			error.put("codigoError", "6");
			listaErrores.add(error);
		}else
			for(DatoFacturaref factura : dseer.getDua().getListFacturaRef()) {
				if (factura.getNumsecfactu().intValue() != i) {
					//Secuencia de facturas incorrecta
					error = new HashMap<String, String>();
					error.put("codigoError", "4");
					error.put("secObtenida", factura.getNumsecfactu() + "");
					error.put("secEsperada", i + "");
					listaErrores.add(error);
				}
				i++;
				repetido = false;
				for (DatoFacturaref factura2 : dseer.getDua().getListFacturaRef())
					if(factura.getNumsecfactu().intValue() == factura2.getNumsecfactu().intValue()) {
						if(repetido) {
							//Secuencia de factura repetida en guia
							error = new HashMap<String, String>();
							error.put("codigoError", "7");
							error.put("factura", factura.getNumsecfactu() + "");
							listaErrores.add(error);
							break;
						}
						repetido = true;
					}
				repetido = false;
				for (DatoSerie serie : dseer.getDua().getListSeries()) {
					//Inicio SRODRIGUEZ
					if(serie.getListSerieDocSoporte()!=null&&!serie.getListSerieDocSoporte().isEmpty()){
					//Fin SRODRIGUEZ
					for (DatoSerieDocSoporte factura2 : serie.getListSerieDocSoporte())
						//Para MDEER la factura se identifica por Codigo de tipo de proceso, para DSEER se identifica por codigo de tipo de documento de soporte
						if((ConstantesDataCatalogo.CODIGO_OMA_DOCUMENTO_ORDEN_PAGO.equals(factura2.getCodtipoproceso()) ||
								ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(factura2.getCodtipodocsoporte()))
								&& factura.getNumsecfactu().intValue() == factura2.getNumiddocsoporte().intValue()) {
							repetido = true;
							break;
						}
					if(repetido)
						break;
					//Inicio SRODRIGUEZ
					}
					//Fin SRODRIGUEZ
				}
				if(!repetido) {
					//La factura no esta asociada a ningun item
					error = new HashMap<String, String>();
					error.put("codigoError", "3");
					error.put("factura", factura.getNumsecfactu() + "");
					listaErrores.add(error);
				}
			}
		return listaErrores;
	}
	
	public List<Map<String, ?>> validarConsistenciaFactura(Declaracion dseer) {
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listaErrores = validarConsistenciaFacturaGeneral(dseer);
		if(listaErrores != null && !listaErrores.isEmpty()) {
			Map<String, String> mapaCordigoError = new HashMap<String, String>();
			mapaCordigoError.put("1", "70158");
			mapaCordigoError.put("2", "70159");
			mapaCordigoError.put("3", "70160");
			mapaCordigoError.put("4", "70161");
			mapaCordigoError.put("5", "70162");
			mapaCordigoError.put("6", "70163");
			mapaCordigoError.put("7", "70164");
			for(Map<String, String> error : listaErrores) {
				responseListManager.addResponseMap(catalogoAyudaService.getError(mapaCordigoError.get(error.get("codigoError")), obtenerArregloParametros(mapaCordigoError.get(error.get("codigoError")), error)));
			}
		}
		if (responseListManager != null && responseListManager.hasErrors())
			responseListManager.addErrorFinalizarProceso();
		return responseListManager.getResponseList();
	}
	
	private String[] obtenerArregloParametros(String codigoError, Map<String, String> error) {
		if("70158".equals(codigoError)) {
			return new String[] {error.get("factura"), error.get("item")};
		}else if("70159".equals(codigoError)) {
			return new String[] {error.get("item")};
		}else if("70160".equals(codigoError)) {
			return new String[] {error.get("factura")};
		}else if("70161".equals(codigoError)) {
			return new String[] {error.get("secObtenida"), error.get("secEsperada")};
		}else if("70162".equals(codigoError)) {
			return new String[] {error.get("factura"), error.get("item")};
		}else if("70163".equals(codigoError)) {
			return new String[] {};
		}else if("70164".equals(codigoError)) {
			return new String[] {error.get("factura")};
		}
		return new String[] {};
	}

	public List<Map<String, ?>> validarIndicadoresDSEER(Elementos<DatoIndicadores> listIndicadores, String codGrupo) {
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<String> listaValidaPorGrupo = validarIndicadorPorGrupo(listIndicadores, codGrupo);
		if (!listaValidaPorGrupo.isEmpty()) {
			for (String indicador : listaValidaPorGrupo) {
				responseListManager.addResponseMap(catalogoAyudaService.getError("70168", new String[] { indicador }));
			}
		}
		return responseListManager.getResponseList();
	}

	public List<Map<String, ?>> validarIndicadoresSerie(DatoSerie serie) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ResponseListManager responseListManager = new ResponseListManager();
		List<DatoIndicadores> listaIndicadores = serie.getListIndicadores();
		List<String> listaValidaPorGrupo = validarIndicadorPorGrupo(listaIndicadores, ConstantesGrupoCatalogo.COD_GRUPO_EER_INDICADORES_ITEM);
		if (!listaValidaPorGrupo.isEmpty()) {
			for (String indicador : listaValidaPorGrupo) {
				responseListManager.addResponseMap(catalogoAyudaService.getError("70169", new String[] { indicador, serie.getNumserie() + "" }));
			}
		}
		return responseListManager.getResponseList();
	}

	private List<String> validarIndicadorPorGrupo(List<DatoIndicadores> listaIndicadores, String codGrupo) {
		List<String> listaParametros = new ArrayList<String>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listaPorGrupo = catalogoAyudaService.getListaElementosGrupo(codGrupo);
		boolean esCorrecto = false;
		for (DatoIndicadores indicador : listaIndicadores) {
			esCorrecto = false;
			for (Map<String, String> elemento : listaPorGrupo) {
				if (elemento.get("cod_datacat").equals(indicador.getCodigoIndicador())) {
					esCorrecto = true;
					break;
				}
			}
			if (!esCorrecto) {
				listaParametros.add(indicador.getCodigoIndicador());
			}
		}
		return listaParametros;
	}
	
	public List<Map<String, ?>> validarFechaFactura(DatoFacturaref factura, Date fechaReferencia){
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(factura.getFecfactura().compareTo(fechaReferencia) > 0)
			responseListManager.addResponseMap(catalogoAyudaService.getError("70165", new String[] { factura.getNumsecfactu() + "" }));
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarSecueciaSerie(Declaracion declaracion){
		ResponseListManager responseListManager = new ResponseListManager();
		ValDetdua valDetDuaService = fabricaDeServicios.getService("ValDetdua");
		Map<String,String> map = valDetDuaService.numserie(declaracion.getDua().getListSeries());
		if (!map.isEmpty()) 
			responseListManager.addResponseMap(map);
		return responseListManager.getResponseList();
	}

	public List<Map<String, ?>> validarCodigoUnidad(Integer numserie, String codigoUnidad, String tipoUnidad){
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("29", codigoUnidad, SunatDateUtils.getCurrentDate()));
		if (!validaCatalogo)
			responseListManager.addResponseMap(catalogoAyudaService.getError("70167", new String[] { numserie + "", tipoUnidad, codigoUnidad }));
		return responseListManager.getResponseList(); 
	}
	
	public List<Map<String, ?>> validarTipoyNumeroDeDocumentoDeParticipantes(Participante participante){
		ResponseListManager responseList = new ResponseListManager();
		CatalogoValidaService catalogoValidaService = fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DdpDAO ddpDAO = fabricaDeServicios.getService("servicio.registro.model.ddpDAO");
		T733DAO t733DAO = fabricaDeServicios.getService("servicio.registro.model.t733DAO");
		String codigoTipoParticipante = participante.getTipoParticipante().getCodDatacat();
		String codigoTipoDocumentoIdentidad = participante.getTipoDocumentoIdentidad() != null ? participante.getTipoDocumentoIdentidad().getCodDatacat() : null;
		String numeroDocumentoIdentidad = participante.getNumeroDocumentoIdentidad();
		DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_PARTICIPANTE, codigoTipoParticipante);
		String desTipoParticipante = "";
		boolean tieneTipoDocumento = StringUtils.hasText(codigoTipoDocumentoIdentidad);
		boolean tieneNumeroDocumento = StringUtils.hasText(numeroDocumentoIdentidad);

		if (dataCatalogo != null) {
			desTipoParticipante = dataCatalogo.getDesDatacat();
		}
		if (!tieneNumeroDocumento) {
			responseList.addResponseMap(catalogoAyudaService.getError("70176", new String[] { desTipoParticipante, codigoTipoDocumentoIdentidad }));
		} else if (!tieneTipoDocumento) {
			responseList.addResponseMap(catalogoAyudaService.getError("70177", new String[] { desTipoParticipante, numeroDocumentoIdentidad }));
		}

		// Se valida que el tipo de documento se encuentre en el grupo 529
		if (tieneTipoDocumento && ConstantesDataCatalogo.CONSIGNATARIO.equals(participante.getTipoDocumentoIdentidad().getCodDatacat())) {
			List<Map<String, String>> lista = catalogoValidaService.validarElementoGrupo(pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo.GRUPO_TIPO_DOCUMENTO_PARTICIPANTE, participante.getTipoDocumentoIdentidad().getCodDatacat());
			if (ResponseListManager.responseListHasErrors(lista)) {
				responseList.addResponseMap(catalogoAyudaService.getError("70178", new String[] { participante.getTipoDocumentoIdentidad().getCodDatacat(), desTipoParticipante }));
			}
		}
		boolean tipoDocumentoEsRuc = ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(codigoTipoDocumentoIdentidad);
		boolean tipoDocumentoEsDni = ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(codigoTipoDocumentoIdentidad);
		boolean tipoDocumentoEsOrganismoInternacional = ConstantesDataCatalogo.TIPO_DOCUMENTO_ORGANISMO_INTERNACIONAL.equals(codigoTipoDocumentoIdentidad);
		if (tipoDocumentoEsRuc) {
			String numruc = numeroDocumentoIdentidad;
			Map<?,?> map = ddpDAO.findByPK(numruc);
			if (CollectionUtils.isEmpty(map)) {
				responseList.addResponseMap(catalogoAyudaService.getError("70171", new String[] { numruc, desTipoParticipante }));
			}
		} else if (tipoDocumentoEsDni) {
			String numDoc = numeroDocumentoIdentidad;
			String tipDoc = "01";
			Map<?,?> map = t733DAO.findByPK(numDoc, tipDoc);
			if (CollectionUtils.isEmpty(map)) {
				responseList.addResponseMap(catalogoAyudaService.getError("70172", new String[] { numDoc, desTipoParticipante }));
			}
		} else if (tipoDocumentoEsOrganismoInternacional) {
			String numDoc = numeroDocumentoIdentidad;
			AyudaService serviceFactory = this.fabricaDeServicios.getService("Ayuda.ayudaServiceDeclaran");
			Declaran declaran = serviceFactory.selectByPrimaryKeyDeclaran(numDoc, codigoTipoDocumentoIdentidad);
			if (declaran == null) {
				responseList.addResponseMap(catalogoAyudaService.getError("70175", new String[] { numDoc, desTipoParticipante }));
			}
		}
		if (!tieneTipoDocumento && !tieneNumeroDocumento && !StringUtils.hasText(participante.getNombreRazonSocial())) {
			responseList.addResponseMap(catalogoAyudaService.getError("70179", new String[] {desTipoParticipante}));
		} else {
			if (tieneTipoDocumento && !tieneNumeroDocumento) {
				responseList.addResponseMap(catalogoAyudaService.getError("70173", new String[] { desTipoParticipante, codigoTipoDocumentoIdentidad }));
			} else {
				if (tieneNumeroDocumento && !tieneTipoDocumento) {
					responseList.addResponseMap(catalogoAyudaService.getError("70174", new String[] { desTipoParticipante, numeroDocumentoIdentidad }));
				}
			}
			dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_PARTICIPANTE, codigoTipoDocumentoIdentidad);
			String desTipoDocumentoIdentidad = "";
			if (dataCatalogo != null) {
				desTipoDocumentoIdentidad = dataCatalogo.getDesDatacat();
			}
			// Si el tipo de documento es ruc, dni u organismos internacionales, el n�mero de documento debe estar en el cat�logo
//			if ((tipoDocumentoEsRuc || tipoDocumentoEsDni || tipoDocumentoEsOrganismoInternacional) && StringUtils.hasText(participante.getNombreRazonSocial())) {
			if ((tipoDocumentoEsRuc || tipoDocumentoEsDni) && StringUtils.hasText(participante.getNombreRazonSocial())) {
				responseList.addResponseMap(catalogoAyudaService.getError("70176", new String[] { desTipoDocumentoIdentidad, desTipoParticipante }));
			}
			// Se valida que se env�e el nombre cuando es Pasaporte, Carnet de Extranjer�a o Salvoconducto... o el resto, el nombre es obligatorio
//			if (!(tipoDocumentoEsRuc || tipoDocumentoEsDni || tipoDocumentoEsOrganismoInternacional) && !StringUtils.hasText(participante.getNombreRazonSocial())) {
			if (!(tipoDocumentoEsRuc || tipoDocumentoEsDni) && !StringUtils.hasText(participante.getNombreRazonSocial())) {
				responseList.addResponseMap(catalogoAyudaService.getError("70177", new String[] { desTipoParticipante, desTipoDocumentoIdentidad }));
			}
		}
		return responseList.getResponseList();
	}
	
	@ServicioAnnot(tipo="V",codServicio=6558)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=6567, numSecEjec=68, nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, String>> validarPaisEmbarcador(DUA dua){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");		
		Participante embarcador = dua.getEmbarcador();
		String codPaisEmbarcador = embarcador.getPais().getCodDatacat();
		if(ConstantesDataCatalogo.PAIS_PERU.equals(codPaisEmbarcador)) {
			listError.add(catalogoAyudaService.getError("70180"));
		} else {
			// hsaenz PAS20181U220400008 - P_SNAA0004-9537: Se corrige bug para que valide el pais del embarcador 
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codPaisEmbarcador));
			if (!validaCatalogo) {
				listError.add(catalogoAyudaService.getError("70183"));
			}
		}
		return listError;
	}
	
	//inicio mlaura PAS20181U220400008-IZV-085.- No est� validando que el Pa�s de Origen sea diferente a Per�.
	public List<Map<String, String>> validarPaisOrigenSerie(String codpaisorige) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (ConstantesDataCatalogo.PAIS_PERU.equals(codpaisorige)) {
			listError.add(catalogoAyudaService.getError("70192"));
		}
		return listError;
	}//fin mlaura PAS20181U220400008-IZV-085.
	
	@ServicioAnnot(tipo="V",codServicio=6551)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=6551, numSecEjec=72, nomClase="")
	public List<Map<String, String>> validarCntUnidadesComerciales(BigDecimal cntunicomer){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (cntunicomer != null) {
			if (cntunicomer.compareTo(BigDecimal.ZERO) <= 0) {
				listError.add(catalogoAyudaService.getError("00038"));
			}
		} else {
			listError.add(catalogoAyudaService.getError("00038"));
		}
		return listError;
	}

    /**
     * Deprecated: se ha cambiado el indicador de garantia en EER
     * @param declaracion
     * @return
     */
	@Deprecated()
	public List<Map<String,?>> validarIndicadorGarantia(Declaracion declaracion) {
		ResponseListManager responseListManager = new ResponseListManager();
		/*CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		for (DatoIndicadores datoIndicadores : declaracion.getListIndicadores()) {

			if (datoIndicadores.getCodigoIndicador().equals(Constantes.COD_INDICADOR_GARANTE)) {		
				if (declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia() == null){
				// Se rechaza la transmision
					responseListManager.addResponseMap(catalogoAyudaService.getError("70187"));					
				}
			}

		}*/

		return responseListManager.getResponseList();
	}


	@Override
	public List<Map<String, String>> validarVigenciaPartida(DatoSerie serie) {
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
		swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + ConstantesDataCatalogo.ADUANA_CENTRALIZADA)); 
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
	    CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		NandinaDAO nandinaDAO = fabricaDeServicios.getService("nandinaDAO");
		List<Map<String, Object>> list = nandinaDAO.consultarPartidaDetalle(serie.getNumpartnandi());
		if (list!=null){
			if (list.isEmpty()){
				listError.add(catalogoAyudaService.getError("70194",new String[]{ serie.getNumserie() + "", serie.getNumpartnandi() + ""}));				
			}			
		}	
		return listError;
		
		/*
		 * indica que si el codigo de la partida no esta con vigencia actual
		 * aparece error 
		 * E91	�SERIE {n�mero de serie}: PARTIDA ENVIADA {n�mero de partida} DEBE ENCONTRARSE VIGENTE�.
		 */
	}
	
	@Override
	public List<Map<String, String>> validarVigenciaTipoUnidFisicas(DatoSerie serie) {
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
		swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + ConstantesDataCatalogo.ADUANA_CENTRALIZADA)); 
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>(); 
	    CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		NandUniDAO nanduniDAO = (NandUniDAO)fabricaDeServicios.getService("nanduniDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cnan", serie.getNumpartnandi());
		params.put("uni", serie.getCodunifis());		
		params.put("fechavigencia",SunatDateUtils.getIntegerFromDate(new java.util.Date()));	/*fecha de referencia del orquestador*/	
		List<Map<String, Object>> list = nanduniDAO.findByMap(params);
		if (list!=null){
			if (list.isEmpty()){

				listError.add(catalogoAyudaService.getError("70195",new String[]{ serie.getNumserie() + "", serie.getNumpartnandi() + ""}));				
			}			
		}
		return listError;
		
		/*
		 * indica que si el codigo del tipo de unidades fisicas, que corresponda a una partida,no esta con vigencia actual
		 * aparece error 
		 * E92	�SERIE {n�mero de serie}: TIPO DE UNIDAD FISICA NO VIGENTE EN LA PARTIDA ENVIADA {n�mero de partida}�.
		 */
	}
    @Override
    public List<Map<String, ?>> validarTNAN(Declaracion declaracion){
        ResponseListManager responseListManager = new ResponseListManager();
        CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        NandTasaDAO nandTasaDAO = (NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO");
        //si tiene mas de una tnan vigente es obligatorio la transmision del tnan
        Integer fechaIngreso = SunatDateUtils.getCurrentIntegerDate();
        DUA dua= declaracion.getDua();
        for(DatoSerie serie : dua.getListSeries()){
            Map<String,Object> paramsNandtasa = new HashMap<String,Object>();
            paramsNandtasa.put("cnan", serie.getNumpartnandi());
            paramsNandtasa.put("finitas", fechaIngreso);
            paramsNandtasa.put("ffintas", fechaIngreso);
            int contNandTasa=nandTasaDAO.count2(paramsNandtasa);

            if (contNandTasa > 1 && serie.getCodtnan() == null){
                //enviamos mensaje de error
                responseListManager.addResponseMap(catalogoAyudaService.getError("70300",new String[]{serie.getNumserie().toString(),serie.getNumpartnandi().toString()}));
            }else{
                String codtnan = (serie.getCodtnan()!=null)?serie.getCodtnan():" ";
                paramsNandtasa.put("tnan", codtnan);
                paramsNandtasa.put("fechavigencia", fechaIngreso);
                List<Map<String,Object>> listMapNandtasa=nandTasaDAO.findByMap(paramsNandtasa);
                if(listMapNandtasa.size()==0)
                    responseListManager.addResponseMap(catalogoAyudaService.getError("05038",new String[]{serie.getNumserie().toString(),serie.getNumpartnandi().toString()}));
            }
        }
        return responseListManager.getResponseList();
    }

    /**
     * �	El flete a nivel de series debe ser mayor a cero, caso contrario E103.
     * @param serie
     * @return
     */
    public List<Map<String,?>> validarFlete(DatoSerie serie){
        ResponseListManager responseListManager = new ResponseListManager();
        CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        if(serie.getMtofledoltmp().compareTo(BigDecimal.ZERO)<=0){
            responseListManager.addResponseMap(catalogoAyudaService.getError("70301", new String[] { serie.getNumserie().toString() }));
        }
        return responseListManager.getResponseList();
	}

    /**
     * Realiza la validacion de los datos de cancelacion
     * @param dua
     * @return
     */
	public List<Map<String,?>> validarDatosCancelacion(DUA dua){
        ResponseListManager responseListManager = new ResponseListManager();
        CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        DatoPago pago=dua.getPago();
        if(pago != null){
            DatoPagoDecla decla=pago.getPagoDeclaracion();
            //String codigoGarantia = dua.getPago().getPagoDeclaracion().getCodgarantia();
            String codTipoPago=decla!=null?decla.getCodtipopago():null;
            if(ConstantesDataCatalogo.DEUDA_GARANTIZADA.equals(codTipoPago) && decla.getCodbcopagoelec() != null){
                responseListManager.addResponseMap(catalogoAyudaService.getError("70002", new String[] { "C�digo del Banco" }));
                decla.setCodbcopagoelec(null);
            }
            if(ConstantesDataCatalogo.DEUDA_GARANTIZADA.equals(codTipoPago) && decla.getNumctapagoelec() != null){
                responseListManager.addResponseMap(catalogoAyudaService.getError("70002", new String[] { "N�mero de cuenta para el pago electr�nico" }));
                decla.setNumctapagoelec(null);
            }
            if (ConstantesDataCatalogo.DEUDA_GARANTIZADA.equals(codTipoPago) && SunatStringUtils.isEmpty(decla.getCodgarantia())){
                // �	Si env�a el indicador de Pago de la Declaraci�n con valor �R� (Garant�a 160)  �DSEER CON INDICADOR DE GARANT�A PREVIA DEBE CONSIGNAR N�MERO DE CUENTA CORRIENTE�
                responseListManager.addResponseMap(catalogoAyudaService.getError("37158"));
            }

            if(ConstantesDataCatalogo.DEUDA_PAGO_ELECTRONICO.equals(codTipoPago) && decla.getCodgarantia() != null){
                responseListManager.addResponseMap(catalogoAyudaService.getError("70002", new String[] { "N�mero de Garant�a" }));
                decla.setCodgarantia(null);
            }
            if(ConstantesDataCatalogo.DEUDA_PAGO_ELECTRONICO.equals(codTipoPago) && decla.getNumctapagoelec() == null){
                responseListManager.addResponseMap(catalogoAyudaService.getError("09068"));
            }
            if(ConstantesDataCatalogo.DEUDA_PAGO_ELECTRONICO.equals(codTipoPago) && decla.getCodbcopagoelec() == null){
                responseListManager.addResponseMap(catalogoAyudaService.getError("09067"));
            }


            //enviar el indicador de Pago de la Declaraci�n y categoria.
            if (codTipoPago != null && !ConstantesDataCatalogo.DEUDA_GARANTIZADA.equals(codTipoPago) && !ConstantesDataCatalogo.DEUDA_PAGO_ELECTRONICO.equals(codTipoPago)){
                responseListManager.addResponseMap(catalogoAyudaService.getError("30080", new String[]{codTipoPago}));
            }

            //rtineo solo temporal, porque no hay logica de grabado cuando es Pago electronico, se setea null todos los datos de pago electronico
            if(ConstantesDataCatalogo.DEUDA_PAGO_ELECTRONICO.equals(codTipoPago)){
                pago.setPagoDeclaracion(null);
            }
        }
        return responseListManager.getResponseList();
    }
}