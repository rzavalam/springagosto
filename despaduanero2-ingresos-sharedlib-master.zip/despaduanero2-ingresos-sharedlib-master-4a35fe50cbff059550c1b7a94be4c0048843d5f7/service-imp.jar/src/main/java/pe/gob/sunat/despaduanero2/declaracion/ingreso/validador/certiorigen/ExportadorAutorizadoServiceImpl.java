package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.AutExportador;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAutocer;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Contempla todas las validaciones referidas al Exportador Autorizado
 * @author rbegazo
 *
 */
public class ExportadorAutorizadoServiceImpl extends ValDuaAbstract implements ExportadorAutorizadoService {
	
	//private FabricaDeServicios	fabricaDeServicios;
	private static final String[] ARRAY_TIPO_CERTIFICADO = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
	
	//rtineo optimizacion
	/**
	 * Carga informacion de Exportador Autorizado de los certificados de origen de la dua
	 **/
	@ServicioAnnot(tipo = "V", codServicio = 9150, descServicio = "Carga informacion de Exportador Autorizado de los certificados de origen de la dua")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion","fechaReferencia" ,"variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 9150, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, Object> cargarInformacionExportadorAutorizado(Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Map<String, AutExportador> grupoExportadoresAutorizados = new HashMap<String, AutExportador>();
		if (declaracion.getDua() != null) {
			DUA dua = declaracion.getDua();
			StringBuilder filtro = new StringBuilder();
			//region    [amancillaa] PAS20165E220200026
			List<String>  lstFiltro = new ArrayList<String>();
			//endregion [amancillaa] PAS20165E220200026

			for (DatoSerie serie : dua.getListSeries()) {
				List<DatoAutocertificacion> certificadosOrigen = getCertiOrigen(dua, serie);
				//de lo revisado solo se utiliza el primer registro de certificado de origen
				if (certificadosOrigen != null && !certificadosOrigen.isEmpty()) {
					//se copiaron variables de consulta con los mismos nombres...
					DatoAutocertificacion certificadoOrigen = certificadosOrigen.get(0);
					
					if (SunatStringUtils.include(certificadoOrigen.getCodtipoCO(), ARRAY_TIPO_CERTIFICADO)) {
						String numautoexp = certificadoOrigen.getNumautoexp();
						if (numautoexp != null && !numautoexp.trim().isEmpty()) {
							//entonces adicionamos el filtro en la consulta
							String codConvenio  = StringUtils.leftPad(serie.getCodconvinter() + "", 3, " ");
							String codPaisorigen = StringUtils.leftPad(serie.getCodpaisorige(), 2, " ");
							numautoexp = StringUtils.leftPad(certificadoOrigen.getNumautoexp(), 20, " ");
							
							//este dato fecemision no lo usaron en la logica original... por lo tanto tampoco se usa en la optimizacion...
							//Date fecemision = certificadoOrigen.getFecemision();

						//region    [amancillaa] PAS20165E220200026 INC 2016-081599 se cae por cadena > 2000, concatena varios numero expedientes repetidos por las puras se mejora la mejora jeje
							StringBuilder sbPK = new StringBuilder(codConvenio).append(codPaisorigen).append(numautoexp);
							if(!lstFiltro.contains(sbPK.toString())){
								lstFiltro.add(sbPK.toString());
							filtro.append(codConvenio).append(codPaisorigen).append(numautoexp).append(",");
						}
						//endregion [amancillaa] PAS20165E220200026

						}
					}
				}
			}
			if (filtro.length() > 0) {
				filtro.deleteCharAt(filtro.length() - 1);
				CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
				List<AutExportador> exportadoresAutorizados = certiOrigenService.getListadoAutorizacionExportador(filtro.toString());
				//agrupamos por datos de consulta
				for (AutExportador exportadorAutorizado : exportadoresAutorizados) {
					String codigoConvenio = exportadorAutorizado.getCodTpi();
					String codigoPaisOrigen = exportadorAutorizado.getCodPaisorigen();
					String numeroExportadorAutorizado = exportadorAutorizado.getNumAutorizExp();
					grupoExportadoresAutorizados.put(codigoConvenio + "#" + codigoPaisOrigen + "#" + numeroExportadorAutorizado, exportadorAutorizado);
					
				}
			}
		}
		variablesIngreso.put("grupoExportadoresAutorizados", grupoExportadoresAutorizados);
		return new HashMap<String, Object>();
	}
	// fin optimizacion

	@ServicioAnnot(tipo="V",codServicio=3372, descServicio="Para tipo de certificado de origen igual a 5 valida que la autorizacion de exportador se envia y corresponda al registrado en el modulo de firmas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3372,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valExportadorAutorizadoHabilitado (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
			String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
			listError.add(valAutocer.numautoexp(numautoexp, serie.getNumserie().toString()));
			//amancilla if (numautoexp != null) {
			if (numautoexp != null && StringUtils.isNotEmpty(numautoexp)) {
				String codPaisorigen = serie.getCodpaisorige();
				Integer codConvenio  = serie.getCodconvinter();
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				//rtineo optimizacion
				Map<String, AutExportador> grupoExportadoresAutorizados = (Map<String, AutExportador>) variablesIngreso.get("grupoExportadoresAutorizados");
				AutExportador autExportadorAutorizado = null;
				if (grupoExportadoresAutorizados != null) {
					//si es que previamente se cargo informacion de exportadores autorizados entonces evitamos consultar a 
					//la base de datos por cada certificado de origen
					//santana correccion
					//String identificador = codConvenio + "#" + codPaisorigen + "# " + numautoexp;
					String identificador = codConvenio + "#" + codPaisorigen + "#" + numautoexp;
					autExportadorAutorizado = grupoExportadoresAutorizados.get(identificador);
				}else{
					//se ejecuta metodo pesado
					autExportadorAutorizado = certiOrigenService.consultarAutorizacionExportador(numautoexp, codPaisorigen, codConvenio.toString(), fecemision);
				}
				//fin optimizacion

				//Si no existe o no esta vigente
				if (autExportadorAutorizado == null || !(SunatDateUtils.esFecha1MayorIgualQueFecha2(fecemision, autExportadorAutorizado.getFecInivig(), SunatDateUtils.COMPARA_SOLO_FECHA) &&
					SunatDateUtils.esFecha1MenorIgualQueFecha2(fecemision, autExportadorAutorizado.getFecFinvig(), SunatDateUtils.COMPARA_SOLO_FECHA))) {				
//					listError.add(catalogoHelper.getErrorMap("30711", new String[] {serie.getNumserie().toString(),numautoexp, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30711",new String[] {serie.getNumserie().toString(),numautoexp, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
				}
			}
		}		
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3382, descServicio="Para tipo de certificado de origen igual a 5 si se transmitio el numero de la autorizacion de exportador se verifica que este registrado en el modulo de firmas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3382,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valExportadorAutorizadoHabilitadoCondicional (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
			//amancilla PAS20155E220200035 if (numautoexp != null) {
			if (numautoexp != null && StringUtils.isNotBlank(numautoexp.trim())) {
				String codPaisorigen = serie.getCodpaisorige();
				Integer codConvenio  = serie.getCodconvinter();
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				//rtineo optimizacion
				Map<String, AutExportador> grupoExportadoresAutorizados = (Map<String, AutExportador>) variablesIngreso.get("grupoExportadoresAutorizados");
				AutExportador autExportadorAutorizado = null;
				if (grupoExportadoresAutorizados != null) {
					//si es que previamente se cargo informacion de exportadores autorizados entonces evitamos consultar a la base de datos por cada certificado de origen
					String identificador = codConvenio + "#" + codPaisorigen + "# " + numautoexp;
					autExportadorAutorizado = grupoExportadoresAutorizados.get(identificador);
				} else{
					//seguimos con la logica pesada
					autExportadorAutorizado = certiOrigenService.consultarAutorizacionExportador(numautoexp, codPaisorigen, codConvenio.toString(), fecemision);
				}
				//fin optimizacion
				
				//Si no existe o no esta vigente
				if (autExportadorAutorizado == null || !(SunatDateUtils.esFecha1MayorIgualQueFecha2(fecemision, autExportadorAutorizado.getFecInivig(), SunatDateUtils.COMPARA_SOLO_FECHA) &&
					SunatDateUtils.esFecha1MenorIgualQueFecha2(fecemision, autExportadorAutorizado.getFecFinvig(), SunatDateUtils.COMPARA_SOLO_FECHA))) {
//					listError.add(catalogoHelper.getErrorMap("30722", new String[] {serie.getNumserie().toString(), numautoexp, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30722",new String[] {serie.getNumserie().toString(), numautoexp, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
				}
			}			
		}		
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3373, descServicio="Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar el nombre del emisor")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3373,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valExportadorAutorizado (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		TipoDeclaraCertiOrigenService tipoDeclaraCertiOrigenService = fabricaDeServicios.getService("tipoDeclaraCertiOrigenService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
		String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
		//ggranados 15 pase xxx certi origen
		if (StringUtils.isBlank(numautoexp)) {				
			listError = tipoDeclaraCertiOrigenService.valNombreEmisor(serie, arrayTipoCertificado,"30892");
		}	
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3380, descServicio="Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar como documento de soporte la identificacion del documento comercial")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3380,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valExportadorAutorizadoDocComercial (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
		String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
		//ggranados 15 pase xxx certi origen
		if (StringUtils.isBlank(numautoexp)) {		
			String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
			if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
				DatoOtroDocSoporte docSoporte = getDocSoportePorTipo(dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);				
				if (docSoporte == null || docSoporte.getFecdocasoc() == null || docSoporte.getNumdocasoc() == null){
//					listError.add(catalogoHelper.getErrorMap("30719", new String[] {serie.getNumserie().toString()}));
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30719",new String[] {serie.getNumserie().toString()}));
				} else{
					if (!SunatStringUtils.isEqualTo(docSoporte.getCodtipoproceso(),ConstantesDataCatalogo.CODIGO_PROCESO_SOPORTE)){
//						listError.add(catalogoHelper.getErrorMap("30807", new String[] {serie.getNumserie().toString(),ConstantesDataCatalogo.CODIGO_PROCESO_SOPORTE,docSoporte.getCodtipoproceso()}));
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30807",new String[] {serie.getNumserie().toString(),ConstantesDataCatalogo.CODIGO_PROCESO_SOPORTE,docSoporte.getCodtipoproceso()}));
					}					
					if (SunatDateUtils.esFecha1MayorQueFecha2(docSoporte.getFecdocasoc(), SunatDateUtils.getCurrentDate(), SunatDateUtils.COMPARA_SOLO_FECHA)) {
//						listError.add(catalogoHelper.getErrorMap("30805", new String[] {serie.getNumserie().toString(),SunatDateUtils.getFormatDate(docSoporte.getFecdocasoc(), "dd/MM/yyyy")}));
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30805",new String[] {serie.getNumserie().toString(),SunatDateUtils.getFormatDate(docSoporte.getFecdocasoc(), "dd/MM/yyyy")}));
					}
				}
			}
		}	
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3381, descServicio="Para tipo de certificado de origen igual a 5 si no envi� Autorizacion del exportador, deber� consigar el valor y monto de la factura")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3381,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valExportadorAutorizadoDatoFactura (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		//amancilla PAS20155E220200035 String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
		String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			//amancilla PAS20155E220200035  String codmoneda = listCertificadoOrigen.get(0).getCodmoneda();
			String codmoneda = listCertificadoOrigen.get(0).getCodmoneda()!=null?listCertificadoOrigen.get(0).getCodmoneda().trim():"";
			BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();
			//Si NO transmitio Numero de Exportador Autorizado se obliga que envie datos factura
				//rtineo optimizacion, se adiciona variableIngreso
			if (StringUtils.isBlank(numautoexp)) {		
				listError = valAutocer.valDatosFactura(codmoneda, mtofobmon, serie.getNumserie().toString(),variablesIngreso);
			}
			//Si transmitio Numero de Exportador Autorizado es opcional datos de factura
			else{
				//rtineo optimizacion, se adiciona variableIngreso
				listError = valAutocer.valDatosFacturaCondicional(codmoneda, mtofobmon, serie.getNumserie().toString(),variablesIngreso);				
			}
		}			
		return listError;
	}
	
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/
}
