package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

//import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValIntermediarioFBServiceImpl extends ValParticipanteFB implements ValIntermediarioFB{


	/**
	 * Valida codigo del tipo de participante
	 * 
	 * @param dav
	 * @return
	 */
	public Map<String, String> codtipparticipante(DAV dav){


		if (SunatStringUtils.isEmpty(dav.getIntermediario().getTipoParticipante().getCodDatacat()) 
				|| !"90".equals(dav.getIntermediario().getTipoParticipante().getCodDatacat()))

			return getErrorMap("30115",
					new Object[] {	dav.getNumsecuprov(), 
							dav.getIntermediario().getTipoParticipante().getCodDatacat()!=null?dav.getIntermediario().getTipoParticipante().getCodDatacat():" " });        

		Map<String, String> result = super.codtipparticipante(dav.getIntermediario().getTipoParticipante());

		if (result != null)
			return getErrorMap("30115",
					new Object[] { dav.getNumsecuprov(), dav.getIntermediario().getTipoParticipante().getCodDatacat() });



		return new HashMap<String, String>();


	}	


	/**
	 * Valida el numero de documento del intermediario
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> numdocparticipante(DAV dav){

		List<Map<String, String>> resulterrors = new ArrayList<Map<String, String>>();

		Map<String, String> result = super.numdocparticipante(dav.getIntermediario().getNumeroDocumentoIdentidad());

		//        if (SunatStringUtils.isEmpty(dav.getIntermediario().getNumeroDocumentoIdentidad()) || SunatStringUtils.isLengthGreaterThanNumber(dav.getIntermediario().getNumeroDocumentoIdentidad(), 11) || result != null) 
		String codPais = dav.getIntermediario().getPais() != null ? dav.getIntermediario().getPais().getCodDatacat() : "";//adicionado por PAS20155E220000451 arey

		//        if ((codPais !=null && SunatStringUtils.isEmpty(dav.getIntermediario().getNumeroDocumentoIdentidad()) && codPais.equals(Constants.CODIGO_PAIS_PERU) )  //|| //////Pase 433 gmontoya Intermediario adicionado para que exija si es PE PAS20155E220000451
		//        		SunatStringUtils.isLengthGreaterThanNumber(dav.getIntermediario().getNumeroDocumentoIdentidad(), 11) ||
		//        		(dav.getIntermediario().getNumeroDocumentoIdentidad()!=null && result != null)) //debe haber valor PAS20155E220000451 arey
		//	        {        	
		//	        	resulterrors.add(getCatalogoHelper().getErrorMap("30133",   
		//	        			new Object[] {	dav.getNumsecuprov(),  dav.getIntermediario().getNumeroDocumentoIdentidad() != null ? dav.getIntermediario().getNumeroDocumentoIdentidad() : " " }));
		//	        }


		//        if (!SunatStringUtils.isEmpty(dav.getIntermediario().getPais().getCodDatacat()) &&        		
		//        			dav.getIntermediario().getPais().getCodDatacat().equals(Constants.CODIGO_PAIS_PERU)){
		if(codPais !=null && codPais.equals(Constants.CODIGO_PAIS_PERU)){//resumido por PAS20155E220000443////Pase 433 arey ajuste al Intermediario
			if (SunatStringUtils.isEmpty(dav.getIntermediario().getNumeroDocumentoIdentidad())){
				resulterrors.add( getErrorMap("30605", new Object[] { dav.getNumsecuprov() }));
			}
			else{
				if(SunatStringUtils.isLengthGreaterThanNumber(dav.getIntermediario().getNumeroDocumentoIdentidad(), 11) || result != null)
					resulterrors.add( getErrorMap("30133", new Object[] { dav.getNumsecuprov() }));
			}
		}

		return resulterrors;
	}


	/**
	 * Valida el codigo del tipo de documento del intermediario
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> codtipdocparticipante(DAV dav){

		List<Map<String, String>> resulterrors = new ArrayList<Map<String, String>>();

		//    	  if (!SunatStringUtils.isEmpty(dav.getIntermediario().getPais().getCodDatacat()) && dav.getIntermediario().getPais().getCodDatacat().equals(Constants.CODIGO_PAIS_PERU)) {
		String codPais = dav.getIntermediario().getPais() != null ? dav.getIntermediario().getPais().getCodDatacat() : "";//adicionado por PAS20155E220000443 arey
		if(Constants.CODIGO_PAIS_PERU.equals(codPais)){ //resumido por PAS20155E220000451 arey ajuste por nullpointer
			if (SunatStringUtils.isEmpty(dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat())) {
				resulterrors.add(getErrorMap("30604", new Object[] { dav.getNumsecuprov() }));
			}
		}

		Map<String, String> result = super.codtipdocparticipante(dav.getIntermediario().getTipoDocumentoIdentidad());
		if (dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat()!=null){
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat()));
			//if(result != null || !catalogoHelper.isValid(dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat(), "27")){ //debe haber valor PAS20155E220000451 arey
			if(result != null || !validaCatalogo){ //debe haber valor PAS20155E220000451 arey

				resulterrors.add( getErrorMap("30132",
						new Object[] { dav.getNumsecuprov(), dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat()}));
			}
		}
		return resulterrors;
	}



	@Deprecated
	public Map<String, String> nomparticipante(String arg) {
		Map<String, String> result = super.nomparticipante(arg);
		if(result != null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("05525");
		}

		return new HashMap<String, String>();
	}

	/**
	 * Valida el codigo del pais del intermediario
	 * @param dav
	 * @return
	 */
	public Map<String, String> codpaisparticipante(DAV dav){

		Map<String, String> result = new HashMap<String, String>();

		String codPais = dav.getIntermediario().getPais() != null ? dav.getIntermediario().getPais().getCodDatacat() : null;
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codPais));
		//if ( SunatStringUtils.isEmpty(dav.getIntermediario().getPais().getCodDatacat()) || !catalogoHelper.isValid(codPais, "J2"))
		if ( SunatStringUtils.isEmpty(dav.getIntermediario().getPais().getCodDatacat()) || !validaCatalogo)			
			result = getErrorMap("05527", 
					new Object[] { dav.getNumsecuprov(),
							dav.getIntermediario().getPais().getCodDatacat() != null ? dav.getIntermediario().getPais().getCodDatacat() : " " });

		return result;
	}

	/**
	 * 	Valida el nombre o razon social del intermediario
	 * @param dav
	 * @return
	 */
	public Map<String, String> nomparticipante(DAV dav){

		Map<String, String> result = new HashMap<String, String>();

		if (SunatStringUtils.isEmpty(dav.getIntermediario().getNombreRazonSocial()) || dav.getIntermediario().getNombreRazonSocial().length() < 5) {
			return getErrorMap("30607", new Object[] { dav.getNumsecuprov(),
					dav.getIntermediario().getNombreRazonSocial()!=null?dav.getIntermediario().getNombreRazonSocial():" "});

		}

		//se retira la valdiaci�n del F2 del formato B RIN 06 03/04/2014 RZM

		//        if (!SunatStringUtils.isEmpty(dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat()) &&
		//        	   	 (dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat().equals(Constants.COD_DATA_CATALOG_TIPO_DOC_RUC))) {
		//
		//	            Map<String, Object> response = catalogoHelper.getOperadorAyudaService().getDeclarante(
		//	                    dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat(),
		//	                    dav.getIntermediario().getNumeroDocumentoIdentidad());
		//	
		//	            if (CollectionUtils.isEmpty(response)
		//	                    || !((String) response.get("nombre")).trim().equals(dav.getIntermediario().getNombreRazonSocial().trim())) {
		//	                return catalogoHelper.getErrorMap("30606", new Object[] { dav.getNumsecuprov(),
		//	                        dav.getIntermediario().getNombreRazonSocial()!=null?dav.getIntermediario().getNombreRazonSocial():" "});
		//	            }
		//	
		//	        }



		return result;
	}

	/**
	 * valida la direccion del intermediario
	 * @param dav
	 * @return
	 */
	public Map<String, String> dirparticipante(DAV dav){
		Map<String, String> result = new HashMap<String, String>();

		if (SunatStringUtils.isEmpty(dav.getIntermediario().getDireccion()) || dav.getIntermediario().getDireccion().length() < 10) {
			result =  getErrorMap("30609", new Object[] { dav.getNumsecuprov(),
					dav.getIntermediario().getDireccion()!=null?dav.getIntermediario().getDireccion():" "});
		}
		//se retira la valdiaci�n del F2 del formato B RIN 06

		//        if (!SunatStringUtils.isEmpty(dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat()) &&         				        		 
		//		        (dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat().equals(Constants.COD_DATA_CATALOG_TIPO_DOC_RUC))) 
		//		        {
		//		            Map<String, Object> response = 	catalogoHelper.getOperadorAyudaService().getDeclarante(
		//		                    						dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat(),
		//		                    						dav.getIntermediario().getNumeroDocumentoIdentidad());
		//		            if(CollectionUtils.isEmpty(response) || !((String)response.get("direccion")).trim().equals(dav.getIntermediario().getDireccion().trim()))
		//		            {
		//		                return catalogoHelper.getErrorMap("30608", new Object[] {
		//		                		dav.getNumsecuprov(),		                		
		//		                        dav.getIntermediario().getDireccion()!=null?dav.getIntermediario().getDireccion():" "});
		//		            }
		//		        }     
		//		else {
		//		                if (SunatStringUtils.isEmpty(dav.getIntermediario().getDireccion()) || dav.getIntermediario().getDireccion().length() < 10) {
		//		                    return catalogoHelper.getErrorMap("30609", new Object[] { dav.getNumsecuprov(),
		//		                        dav.getIntermediario().getDireccion()!=null?dav.getIntermediario().getDireccion():" "});
		//		                }
		//		       }

		return result;
	}

	/**
	 * Valida la ciudad del intermediario
	 * @param dav
	 * @return
	 */
	public Map<String, String> desubigparticipante(DAV dav){

		Map<String, String> result = new HashMap<String, String>();

		if (SunatStringUtils.isEmpty(dav.getIntermediario().getCiudad()) || dav.getIntermediario().getCiudad().length() < 3)

			result = getErrorMap("30610", new Object[] { dav.getNumsecuprov(),
					dav.getIntermediario().getCiudad()!=null?dav.getIntermediario().getCiudad():" " });

		return result;

	}

	/**
	 * 	Valida la direccion de correo del intermediario
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> dirmailweb(DAV dav){


		List<Map<String, String>> resulterrors = new ArrayList<Map<String, String>>();

		if (SunatStringUtils.isEmpty(dav.getIntermediario().getEmail()) || dav.getIntermediario().getEmail().length() < 4) {
			resulterrors.add(getErrorMap("30612", new Object[] {
					dav.getNumsecuprov(),
					dav.getIntermediario().getEmail()!=null?dav.getIntermediario().getEmail():" "}));
		}

		if (super.dirmailweb(dav.getIntermediario().getEmail()) != null) {
			resulterrors.add(getErrorMap("30611", new Object[] {
					dav.getNumsecuprov(),
					dav.getIntermediario().getEmail()}));
		}

		return resulterrors;
	}

	/**
	 *  Validar C�digo Tipo de Intermediario
	 * @param dav
	 * @return
	 * @pase PAS20134E610000270  FORMATO B 
	 */
	public Map<String, String> codtipinter(DAV dav) {

		Map<String, String> result = new HashMap<String, String>();
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("87", dav.getCodtipinter()));
		//if (SunatStringUtils.isEmpty(dav.getCodtipinter()) || !catalogoHelper.isValid(dav.getCodtipinter(), "87")) {
		if (SunatStringUtils.isEmpty(dav.getCodtipinter()) || !validaCatalogo) {
			result = getErrorMap("05528", new Object[] {
					dav.getNumsecuprov(), 
					dav.getCodtipinter()!=null?dav.getCodtipinter():"  "});
		}

		return result;	
	}

}
