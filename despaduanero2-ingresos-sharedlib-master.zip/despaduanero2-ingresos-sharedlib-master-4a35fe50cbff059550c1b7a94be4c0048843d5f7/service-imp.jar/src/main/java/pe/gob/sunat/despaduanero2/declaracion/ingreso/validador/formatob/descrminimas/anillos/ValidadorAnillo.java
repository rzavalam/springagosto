package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.anillos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.anillos.model.Anillo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;


/**
 * La Class ValidadorDescrMinimaAnillos.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorAnillo extends ValidadorAbstract 
{
	private static final String CATALOGO_UNID_COMER_DOM = "558";
	public static final String CAT_VEH_M2 = "M2";
	public static final String MAT_FAB_HIE = "HIE";
	public static final String MAT_FAB_ALU = "ALU";
	public static final String PART_8308101100 = "8308101100";
	public static final String PART_8308101200 = "8308101200";
	public static final String PART_8308101900 = "8308101900";

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErroresDescrMin))
      {
          lstErroresDescrMin.addAll(validarUnidadComercial(objeto, dua));
          lstErroresDescrMin.addAll(validarNombreComercial(objeto));
          lstErroresDescrMin.addAll(validarMarcaComercial(objeto));
          lstErroresDescrMin.addAll(validarModelo(objeto));
          lstErroresDescrMin.addAll(validarTipoAnillos(objeto));
          lstErroresDescrMin.addAll(validarMaterialFabricacion(objeto, dua));
          lstErroresDescrMin.addAll(validarAcabado(objeto));
          lstErroresDescrMin.addAll(validarUso(objeto));
          lstErroresDescrMin.addAll(validarDimension(objeto));
      }

    return lstErroresDescrMin;

  }


  public List<ErrorDescrMinima>  validarUnidadComercial (ModelAbstract  objeto, Declaracion dua){
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);

    Anillo anillo = (Anillo) objeto;
    String datoAValidar = item.getCodunidcomer().trim();
    //rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
    Map<String,Object> variablesIngreso = objeto.getMapCatalogos();
    if(noestaEnSubGrupoCatalogo(CATALOGO_UNID_COMER_DOM,datoAValidar,variablesIngreso))
    {
      Object[] demasArgumentosMSJError = new Object[] { anillo.getNumsecprove(),anillo.getNumsecfact(),
    		  anillo.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
    	        ErrorDescrMinima error = obtenerError("31708",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
    	        errorLst.add(error);
    }
    
    return errorLst;
  }

  public List<ErrorDescrMinima>  validarNombreComercial (ModelAbstract  objeto){
	    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarMarcaComercial (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarModelo (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarTipoAnillos (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarMaterialFabricacion (ModelAbstract  objeto, Declaracion dua){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		String datoAValidar;		
		DatoItem item = obtenerItem(objeto, dua);
		Anillo anillo = (Anillo) objeto;
		String subPartida = item.getNumpartnandi().toString();
		if(anillo.getMaterialFabricacion() == null)
			datoAValidar = "";
		else
			datoAValidar = anillo.getMaterialFabricacion().getValtipdescri().trim();
		if(PART_8308101900.equalsIgnoreCase(subPartida) && (MAT_FAB_ALU.equalsIgnoreCase(datoAValidar)||MAT_FAB_HIE.equalsIgnoreCase(datoAValidar))){
			Object[] argumentos = new Object[] { subPartida };
			ErrorDescrMinima error = obtenerError("31853",anillo.getMaterialFabricacion(),argumentos);
			lstErroresDescrMin.add(error);		
		}
		if((MAT_FAB_HIE.equalsIgnoreCase(datoAValidar) && !PART_8308101100.equalsIgnoreCase(subPartida))
			||	(!MAT_FAB_HIE.equalsIgnoreCase(datoAValidar) && PART_8308101100.equalsIgnoreCase(subPartida))){
			Object[] argumentos = new Object[] { PART_8308101100 };			
			ErrorDescrMinima error = obtenerError("31820",anillo.getMaterialFabricacion(),argumentos);
			lstErroresDescrMin.add(error);						
		}
		if((MAT_FAB_ALU.equalsIgnoreCase(datoAValidar) && !PART_8308101200.equalsIgnoreCase(subPartida))
				|| (!MAT_FAB_ALU.equalsIgnoreCase(datoAValidar) && PART_8308101200.equalsIgnoreCase(subPartida))){
			Object[] argumentos = new Object[] { PART_8308101200 };			
			ErrorDescrMinima error = obtenerError("31852",anillo.getMaterialFabricacion(),argumentos);
			lstErroresDescrMin.add(error);						
		}
		return lstErroresDescrMin;
  }

  public List<ErrorDescrMinima>  validarAcabado (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarUso (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarDimension (ModelAbstract  objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }
  
}
