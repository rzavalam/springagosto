/*
 * Clase que define el servicio de validaciones de 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import org.apache.log4j.Logger;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;

import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Seriecupo;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.SeriecupoDAO;
import pe.gob.sunat.despaduanero2.asignacion.util.Constantes;
import pe.gob.sunat.despaduanero2.ayudas.model.Cambio1;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.bean.CriteriaBean;
import pe.gob.sunat.despaduanero2.bean.DynamicSentenceBean;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.LogRegiService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.CtaCtePerNat;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CtaCtePerNatDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupolibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupotpiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeclaranDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SPGeneralDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabImpDUDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.DUACriteria;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.Datado;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2Service;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.seleccion.bean.ResponseSeleccion;
import pe.gob.sunat.despaduanero2.seleccion.service.SeleccionService;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;

public class GrabarGeneralServiceImpl extends ValDuaAbstract implements GrabarGeneralService {
	//private CatalogoAyudaService catalogoayudaservice;
	//private LiquidaDeclaracionService liquidaDeclaracionService;
	//	private DatadoService datadoService;
	//private Datado2Service datado2Service;
	//private GeneraLiquidacionService generaLiquidacionService;
	//private SeleccionService seleccionservice;
	//CupolibeDAO cupoLibeDAO;
	//CupotpiDAO cupotpiDAO;
	//SeriecupoDAO seriecupoDAO;
	//CabDeclaraDAO cabdeclaraDAO;
	//CatRefRucDAO catRefRucDAO;
	//	private ComunicacionService comunicacionService;
	//protected CatalogoHelperImpl catalogoHelper;
	//private ProveedorFuncionesService funcionesService;
	//LogRegiService logRegiService;

	//private AyudaService ayudaService;

	//private DdpDAOService ddpDAOService;

	//private FabricaDeServicios fabricaDeServicios; 

	//private Logger logger = Logger.getLogger(GrabarGeneralServiceImpl.class);


	/*
	 * invoca al servicio de registro de desdatado , con datos de la dua
	 * rectificada
	 */
	@Override
	public List<Map<String, Object>> registrarDesdatado(Declaracion declaracion,String codTransaccion, Map<String, Object> variablesIngreso) throws Exception {
		List<Map<String, Object>> lstErrors = new ArrayList<Map<String, Object>>();
		//Este Metodo ya no se usa, si se desea desdatar algo invocar al servicio de manifiesto

		/*		Map<String, Object> mperrores = null;

		for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte()) {
			Map<String, Object> dataDua = new HashMap<String, Object>();
			dataDua = GeneralUtils.fillDataDuaDocTransp(declaracion, docTrans,codTransaccion);
			dataDua.put("tipoDatado", Constants.DESDATADO_TX_ELECTRONICA);  
			datadoService.registrarDesDatado(dataDua);
			if (!CollectionUtils.isEmpty(mperrores))
				lstErrors.add(mperrores);
		}
		 */		
		return lstErrors;
	}
	/*
	public CabDeclaraDAO getCabdeclaraDAO() {
		return cabdeclaraDAO;
	}

	public void setCabdeclaraDAO(CabDeclaraDAO cabdeclaraDAO) {
		this.cabdeclaraDAO = cabdeclaraDAO;
	}

	public CatalogoAyudaService getCatalogoayudaservice() {
		return catalogoayudaservice;
	}

	public void setCatalogoayudaservice(CatalogoAyudaService catalogoayudaservice) {
		this.catalogoayudaservice = catalogoayudaservice;
	}

	public LiquidaDeclaracionService getLiquidaDeclaracionService() {
		return liquidaDeclaracionService;
	}

	public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}*/

	//	public DatadoService getDatadoService() {
	//		return datadoService;
	//	}
	//
	//	public void setDatadoService(DatadoService datadoService) {
	//		this.datadoService = datadoService;
	//	}
	/*
	public GeneraLiquidacionService getGeneraLiquidacionService() {
		return generaLiquidacionService;
	}

	public void setGeneraLiquidacionService(GeneraLiquidacionService generaLiquidacionService) {
		this.generaLiquidacionService = generaLiquidacionService;
	}

	public SeleccionService getSeleccionservice() {
		return seleccionservice;
	}

	public void setSeleccionservice(SeleccionService seleccionservice) {
		this.seleccionservice = seleccionservice;
	}

	public CupolibeDAO getCupoLibeDAO() {
		return cupoLibeDAO;
	}

	public void setCupoLibeDAO(CupolibeDAO cupoLibeDAO) {
		this.cupoLibeDAO = cupoLibeDAO;
	}
	 */
	public Map<String, String> Grabacabydetsolicitud(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion,
			String tipoSolicitud, String estadoSolicitud) throws Exception {

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		List<DetSolicitudRectificacionBean> detalleSolicitud = solicitudRectificacion.getListaCambios();

		Long numcorredoc = declaracion.getDua().getNumcorredoc();
		// grabar el documento

		//		Long numCorreDocSolicitud = RectificacionServiceImpl.getInstance().getSequenceDAO().getNextSequence(
		Long numCorreDocSolicitud = ((SequenceDAO)fabricaDeServicios.getService("sequenceDAO")).getNextSequence(
				ConstanteSecuencia.SECUENCIA_CORRELATIVODOCUMENTO);

		Documento documento = new Documento();
		documento.setNumeroCorrelativo(numCorreDocSolicitud);
		documento.setEstado("00");
		documento.setTipoDocumento(Constants.COD_TIPO_DOC_SOLICITUD_ELECTRONICA); // 3:
		// solicitudes
		// electronicas
		documento.setCodAduana(declaracion.getDua().getCodaduanaorden());
		//RectificacionServiceImpl.getInstance().getDocumentoDAO().insertSelective(documento);
		((DocumentoDAO)fabricaDeServicios.getService("documentoDAO")).insertSelective(documento);

		// grabar solicitud

		// generar el sequencial de solicitud campo NUMSOL
		// nombre de sequencia ha sido definido de la sgte manera
		// SESOLICITUD<codaduana><tiposolicitud>
		// 24/11/2009 a la fecha falta crear ese secuencial
		String nombreseq = "SESOLICITUD" + declaracion.getNumdeclRef().getCodaduana().concat(tipoSolicitud); // 01
		// =rectificacion,
		// 11=Regularizacion
		//Long sequenceNumSolicitud = RectificacionServiceImpl.getInstance().getSequenceDAO().getNextSequence(nombreseq);
		Long sequenceNumSolicitud = ((SequenceDAO)fabricaDeServicios.getService("sequenceDAO")).getNextSequence(nombreseq);

		String secNumSolicitud = sequenceNumSolicitud.toString();

		FechaBean fechaBean = new FechaBean();
		Map<String, Object> paramsInsert = new HashMap<String, Object>();
		paramsInsert.put("NUMCORREDOC", numCorreDocSolicitud);
		paramsInsert.put("ANNSOL", fechaBean.getAnho());
		paramsInsert.put("NUMSOL", secNumSolicitud);
		paramsInsert.put("CODREGIMEN", declaracion.getDua().getCodregimen());
		paramsInsert.put("CODTIPSOL", tipoSolicitud);// 01: Rectificacion, 11:
		// Regularizacion
		paramsInsert.put("CODESTSOL", estadoSolicitud); // 00:Rectificacion
		// Tipos de estados de
		// la solicitud
		paramsInsert.put("CODADUANA", declaracion.getDua().getCodaduanaorden());
		//RectificacionServiceImpl.getInstance().getSolicitudDAO().insertSelectivoSolicitud(paramsInsert);
		((SolicitudDAO)fabricaDeServicios.getService("solicitudDAO")).insertSelectivoSolicitud(paramsInsert);

		solicitudRectificacion.setNumcorredoc(numCorreDocSolicitud);

		// grabar relacion doc

		Map<String, Object> maprelaciondoc = new HashMap<String, Object>();
		maprelaciondoc.put("numCorredoc", numCorreDocSolicitud);
		maprelaciondoc.put("numCorredocPre", numcorredoc);
		maprelaciondoc.put("annPresen", declaracion.getNumdeclRef().getAnnprese());
		maprelaciondoc.put("codRegimen", declaracion.getNumdeclRef().getCodregimen());
		maprelaciondoc.put("numDeclaracion", declaracion.getNumdeclRef().getNumcorre());
		maprelaciondoc.put("codAduana", declaracion.getDua().getCodaduanaorden());
		//RectificacionServiceImpl.getInstance().getRelaciondocDAO().insertMapSelective(maprelaciondoc);
		((RelacionDocDAO)fabricaDeServicios.getService("relaciondocDAO")).insertMapSelective(maprelaciondoc);

		// grabar solirectifica
		Map<String, Object> mapsolirectifica = new HashMap<String, Object>();
		mapsolirectifica.put("numCorredoc", numCorreDocSolicitud);
		// se obtiene el motivo de la rectificacion , de la seccion de
		// observaciones de la declaracion
		Observacion obsrecti = getObservacionbyTipo(declaracion.getDua(), Constants.COD_TIP_OBSERV_RECTIFICACION);
		String motivoRectificacion = null;
		if (obsrecti != null)
			motivoRectificacion = obsrecti.getObsdeclaracion();

		mapsolirectifica.put("desMotivrecti", motivoRectificacion);
		mapsolirectifica.put("codEstarecti", solicitudRectificacion.getCodestarecti()); // 02
		// PARA
		// ASIGNAR
		// A
		// ESPECIALISTA
		// por ser automatico , la fecha de evaluacion es la fecha actual
		mapsolirectifica.put("fecEvaluacion", SunatDateUtils.getCurrentDate());
		mapsolirectifica.put("fecSolicitud", SunatDateUtils.getCurrentDate());
		mapsolirectifica.put("codTransaccion", solicitudRectificacion.getCodtransaccion()); // C�digo
		// de
		// transacci�n
		// 03:
		// Rectificaci�n
		// 04:
		// Regularizaci�n
		// Cat�logo
		// 305
		//RectificacionServiceImpl.getInstance().getSolirectificaDAO().insertMapSelective(mapsolirectifica);
		((CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO")).insertMapSelective(mapsolirectifica);

		// grabar detsolrectifica

		if (!CollectionUtils.isEmpty(detalleSolicitud)) {
			int secCambio = 0;
			// por cada registro(cambio)
			for (DetSolicitudRectificacionBean detalle : detalleSolicitud) {
				secCambio++;
				Map<String, Object> mapDetSolRecti = new HashMap<String, Object>();
				mapDetSolRecti.put("numCorredoc", numCorreDocSolicitud);
				mapDetSolRecti.put("numSeccambio", secCambio);
				mapDetSolRecti.put("codTabla", detalle.getCodtabla());
				Map<String, Object> mpClave = new HashMap<String, Object>();
				Map<String, Object> mpDatos = new HashMap<String, Object>();
				Map<String, Object> mpDatosAnterior = new HashMap<String, Object>();

				mpClave.putAll(detalle.getKey());
				mapDetSolRecti.put("desClave", SojoUtil.toJson(mpDatos));
				// generando el json del desdata1 y desAntdata1
				for (String campo : detalle.getDatosRectificados().keySet()) {
					// no considerar los datos bloqueados
					DatoRectificacionBean drRec = (DatoRectificacionBean) detalle.getDatosRectificados().get(campo);
					if (StringUtils.hasText(drRec.getFlagBloqueo())) {
						continue;
					} else {
						Object datoNuevo = formatearObjeto(drRec.getDatoNuevo());
						Object datoAntiguo = formatearObjeto(drRec.getDatoAntiguo());
						mpDatos.put(campo, datoNuevo);
						mpDatosAnterior.put(campo, datoAntiguo);
					}
				}

				if (!mpDatos.isEmpty())
					mapDetSolRecti.put("desData1", SojoUtil.toJson(mpDatos));
				if (!mpDatosAnterior.isEmpty())
					mapDetSolRecti.put("desAntdata1", SojoUtil.toJson(mpDatosAnterior));
				mapDetSolRecti.put("fecIngreso", SunatDateUtils.getCurrentDate());
				// Codigo de el estado del Cambio 00 registrado, 01 aceptado 02
				// aceptado parcialmenet 03 aceptado totalmente
				mapDetSolRecti.put("codEstcambio", Constants.COD_ESTADO_CAMBIO_REGISTRADO);
				mapDetSolRecti.put("indRectifica", detalle.getTipoCambio());

				//				RectificacionServiceImpl.getInstance().getDetsolrectiDAO().insertMapSelective(mapDetSolRecti);
				((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).insertMapSelective(mapDetSolRecti);

			}
		}

		return resultadoError;
	}

	public Map<String, String> Grabatablanegocio(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion) throws Exception {
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> resultadoError = new HashMap<String, String>();
		List<DetSolicitudRectificacionBean> detalleSolicitud = solicitudRectificacion.getListaCambios();
		/*- Grabar informaci�n rectificada a las tablas Definitivas*/
		if (!CollectionUtils.isEmpty(detalleSolicitud)) {
			for (DetSolicitudRectificacionBean soli : detalleSolicitud) {

				DynamicSentenceBean dynamic = new DynamicSentenceBean();
				String tablenameSinonimo = null;
				DataCatalogo datacat = catalogoayudaservice.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_CODIFICACION_TABLAS, soli.getCodtabla());
				tablenameSinonimo = datacat.getDesDatacat().trim();

				dynamic.setTablename(tablenameSinonimo);
				dynamic.setWhereCriteria(new CriteriaBean());
				dynamic.getWhereCriteria().addColumValueCriterion(soli.getKey());
				//int countRegAfectado = RectificacionServiceImpl.getInstance().getDetsolrectiDAO().countByDinamicBean(dynamic);
				int countRegAfectado = ((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).countByDinamicBean(dynamic);
				if (countRegAfectado == 1) {
					// realizar update
					Map<String, Object> mapDatos = new HashMap<String, Object>();
					for (String campo : soli.getDatosRectificados().keySet()) {
						DatoRectificacionBean dato = (DatoRectificacionBean) soli.getDatosRectificados().get(campo);
						mapDatos.put(campo, dato.getDatoNuevo());
					}
					dynamic.setDataCriteria(new CriteriaBean());
					dynamic.getDataCriteria().addColumValueCriterion(mapDatos);

					//int rowupdated = RectificacionServiceImpl.getInstance().getDetsolrectiDAO().updateByDynamicBean(dynamic);
					int rowupdated = ((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).updateByDynamicBean(dynamic);
				}

			}
		}

		// Actualiza el estado de la rectificacion como atendido 05
		Map<String, Object> paramer = new HashMap<String, Object>();
		paramer.put("numCorredoc", solicitudRectificacion.getNumcorredoc());
		paramer.put("codEstarecti", "05");
		//RectificacionServiceImpl.getInstance().getSolirectificaDAO().updateByPrimaryKeySelectiveParameterMap(paramer);
		((CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO")).updateByPrimaryKeySelectiveParameterMap(paramer);

		return resultadoError;
	}

	/*
	 * Se debe invocara a las funciones de Grabado de adeudo para grabar
	 */
	/*
	 * public Map<String, Object> Grabadocadeudo( Declaracion declaracion ,Map
	 * deudadiferencial, String indTipoLiquidacion ) throws Exception{
	 * 
	 * 
	 * java.util.Map<String, String> resultadoError = new HashMap<String,
	 * String>(); Map<String,Object> mapRetorno=null; /*HashMap paramDocLiq=new
	 * HashMap();
	 * 
	 * if(!CollectionUtils.isEmpty(deudadiferencial)){
	 * 
	 * HashMap paramDocLiq=new HashMap(); paramDocLiq.put("indTipLiqui",
	 * indTipoLiquidacion); // Para la numeraci�n en L, para la Rectificaci�n
	 * es: E, para la regularizaci�n es G paramDocLiq.put("codAduDocliq",
	 * declaracion.getNumdeclRef().getCodaduana()); paramDocLiq.put("annDocliq",
	 * declaracion.getNumdeclRef().getAnnprese());
	 * paramDocLiq.put("codRegDocliq",
	 * declaracion.getNumdeclRef().getCodregimen());
	 * paramDocLiq.put("numDocliq", declaracion.getNumdeclRef().getNumcorre());
	 * paramDocLiq.put("numReliq", "0"); // para rectificacion es ustedes es "0"
	 * (cero)
	 * 
	 * HashMap mapCabDeclaraActual=new HashMap();
	 * mapCabDeclaraActual.put("diferenciaTributos", deudadiferencial);
	 * 
	 * Map mapaDeclara= new HashMap(); mapaDeclara.put("COD_ADUANA",
	 * declaracion.getNumdeclRef().getCodaduana());
	 * mapaDeclara.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
	 * mapaDeclara.put("NUM_DECLARACION",
	 * declaracion.getNumdeclRef().getNumcorre()); mapaDeclara.put("caduana",
	 * declaracion.getNumdeclRef().getCodaduana());
	 * mapaDeclara.put("COD_REGIMEN",
	 * declaracion.getNumdeclRef().getCodregimen());
	 * mapaDeclara.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
	 * List
	 * listaAutoliquidaciones=liquidaDeclaracionService.obtenerAutoliquidaciones
	 * (mapCabDeclaraActual); mapCabDeclaraActual.put("listaAutoliquidaciones",
	 * listaAutoliquidaciones);
	 * paramDocLiq.put("mapCabDeclaraActual",mapCabDeclaraActual);
	 * 
	 * // funcion de grabacion de adeudo Map<String,Object> mapRetorno=
	 * liquidaDeclaracionService.grabaLiquidacion(paramDocLiq);
	 * 
	 * 
	 * /* la impugnacion por ley de emergencia es validado en el servicio de
	 * grabaLiquidacion
	 */

	/*
	 * La generacion del LC, segun correspinda ,es generado por el servicio de
	 * grabaLiquidacion
	 */

	// return mapRetorno;

	// }

	private Object formatearObjeto(Object input) throws Exception {
		if (input instanceof BigDecimal) {
			return new Double(((BigDecimal) input).doubleValue() * 1000 / 1000);
		} else if (input instanceof java.util.Date) {
			return DateUtil.dateToString((Date) input, "dd/MM/yyyy");
		} else
			return input;

	}

	/*
	 * invoca al servicio de registro de datado del grupo manifiesto , con datos
	 * de la dua
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> registrarDatado(Declaracion declaracion, String tipoDatada,String codTransaccion, Map<String,Object> variablesIngreso) throws Exception {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, Object> mperrores = null;

		boolean isTxDilig = funcionesService.isTransaccionDiligencia(codTransaccion);


		// por cada doc. de transporte se invoca al servicio de validacion de
		// datado
		/** NSR: Reemplazado por el nuevo Datado 22/09/2010
		for (DatoDocTransporte docTrans : declaracion.getDua().getListDocTransporte()) {
			Map<String, Object> dataDua = new HashMap<String, Object>();
			dataDua = GeneralUtils.fillDataDuaDocTransp(declaracion, docTrans, tipoDatada,codTransaccion);
			try {
				logger.debug("Inicia RegistrarDatado:" + dataDua);
				//Map resultado = datadoService.registrarDatado(dataDua);
				Map resultado = datado2Service.registrarDatado(dataDua);
				logger.debug("Fin RegistrarDatado�, resultado=" + resultado);
			} catch (Exception e) {
				logger.debug("", e);
				throw new ServiceException("", e);
			}
		}
		 **/
		//NSR: Los datos para el datado ya fueron calculados por el servicio de validacion correspondiente
		//y almacenados en el mapa variablesIngreso
		//por lo que solo queda grabar, esto reemplaza al codigo comentado arriba.
		List<Map<String,Object>> listaParaDatado= (List<Map<String,Object>>)variablesIngreso.get("Datado.listaParaDatado");

		//Se realiza el desdatado de aquellas series que0 cambiaron numero de detalle o numero de documento de transporte
		if(codTransaccion.endsWith("03") || isTxDilig){
			registrarDesdatadoPorDocumentoTransporte(variablesIngreso, listaParaDatado, declaracion, codTransaccion);
		}
		//En el caso de la Rectificaci�n desdatamos todo lo anterior y volvemos a datar con lo transmitido
		//		if(codTransaccion.endsWith("03")){
		//			mperrores datado2Service.
		//		}	
		//de todas maneras verificamos

		Datado2Service datado2Service = (Datado2Service) fabricaDeServicios.getService("manifiesto.datado2Service");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaReferencia = new Date();		
	    boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
		if(listaParaDatado!=null){ 
			for(Map<String,Object> dataDua: listaParaDatado){
				//En caso de Rectificaci�n Verificamos si tiene datado previo 
				dataDua.put("esVigenteRIN05PrimeraParte", esVigenteRIN05PrimeraParte);
				dataDua.put("tieneDatadoSobreRecibido", variablesIngreso.get("tieneDatadoSobreRecibido") );
				if(codTransaccion.endsWith("03") || isTxDilig){

					//para la rectificacion de oficio cambio de mdoaliad
					if(codTransaccion.endsWith("09") || isTxDilig){

						Declaracion decla=(Declaracion)variablesIngreso.get("declaracion");
						Map<String,Object> params= new HashMap<String, Object>();
						params.put("codigoAduana", decla.getNumdeclRef().getCodaduana());
						params.put("annoPresentacion", decla.getNumdeclRef().getAnnprese());
						params.put("codigoRegimen", decla.getNumdeclRef().getCodregimen());
						params.put("numeroDeclaracion", decla.getNumdeclRef().getNumcorre());

						//List<Map<String,Object>> lstdua= FormatoAServiceImpl.getInstance().getCabDeclaraDAO().listCabDeclaraMapByParameterMap(params);
						List<Map<String,Object>> lstdua= ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).listCabDeclaraMapByParameterMap(params);

						Map<String, Object> declaracionMap = null;
						if (!CollectionUtils.isEmpty(lstdua)){
							declaracionMap = lstdua.get(0);
						}
						String modalidadBd = (String) declaracionMap.get("codmodalidad");

						DUA dua = declaracion.getDua();
						boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;

						boolean esUrgenteBD    = "01".equals(modalidadBd)?true:false;
						boolean esAnticipadoBD = "10".equals(modalidadBd)?true:false;

						boolean existeCambioModalidadAExcepcional = (esExcepcional && (esUrgenteBD || esAnticipadoBD));
						if(existeCambioModalidadAExcepcional)
						{
							declaracion.getDua().setCodmodalidad(modalidadBd);
							dataDua = GeneralUtils.actualizaDatosFijosDatadoRegistro(declaracion, codTransaccion, dataDua);
							mperrores = (Map)datado2Service.validarExistenciaDatado(dataDua);
							if(mperrores.isEmpty()){
								dataDua = GeneralUtils.actualizaDatosFijosDesdatadoRegistro(declaracion, codTransaccion, dataDua);
								Map resultado = datado2Service.registrarDesDatado(dataDua);
								if(!resultado.isEmpty()) //Si el mapa no esta vacio entonces ocurrio un error
									return resultado;
							}
							declaracion.getDua().setCodmodalidad("00");//regreso a su modalidad definitiva excepcional
						}
					}

					dataDua = GeneralUtils.actualizaDatosFijosDatadoRegistro(declaracion, codTransaccion, dataDua);
					mperrores = (Map)datado2Service.validarExistenciaDatado(dataDua);
					//String descripcion = (String)mperrores.get(ResponseMapManager.KEY_DESCRIPCION);
					//Si devuelve un mapa vacio es que tiene datado previo
					if(mperrores.isEmpty()){
						dataDua = GeneralUtils.actualizaDatosFijosDesdatadoRegistro(declaracion, codTransaccion, dataDua);						
						Map resultado = datado2Service.registrarDesDatado(dataDua);
						if(!resultado.isEmpty()) //Si el mapa no esta vacio entonces ocurrio un error
							return resultado;
					}
				}
				/*Inicio PAS20181U220200064  se adiciona al datado para que lo considere en la busqueda interna que realiza de bd*/
				List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
				if(!ResponseListManager.responseListHasErrors(listaOMA)){
					boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
					dataDua.put("fechaReferencia", fechaReferencia);
					dataDua.put("considerarEER", considerarEER?"1":"0");
					dataDua.put("esOMA", "1");
				}
				/*Fin*/	
				
				//Procedemos a datar
				dataDua = GeneralUtils.actualizaDatosFijosDatadoRegistro(declaracion, codTransaccion, dataDua);
				dataDua.put("codTransaccion", codTransaccion);
				Map resultado = datado2Service.registrarDatado(dataDua);
				String descripcion = (String)resultado.get(ResponseMapManager.KEY_DESCRIPCION);
				if(!resultado.isEmpty() && !descripcion.endsWith(" se encuentra datado")) //Si el mapa no esta vacio entonces ocurrio un error
					return resultado;
			}
		}
		return mperrores;
	}

	/**
	 * Registrar desdatado por documento transporte.
	 * 
	 * @param variablesIngreso Map<String,Object>
	 * @param listaParaDatado List<Map<String,Object>> 
	 */
	private void registrarDesdatadoPorDocumentoTransporte(Map<String, Object> variablesIngreso, List<Map<String,Object>> listaParaDatado, Declaracion declaracion, String codTransaccion){
		Datado2Service datado2Service = (Datado2Service) fabricaDeServicios.getService("manifiesto.datado2Service");
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("detalleNumeroCorrelativo", declaracion.getNumeroCorrelativo()); 
		List<Datado> listDatado = datado2Service.obtenerDatadoByParameterMap(paramsMap);
		if(! CollectionUtils.isEmpty(listDatado) ){

			String numeroManifiesto = listDatado.get(0).getDocumentoDeTransporte().getManifiesto().getNumeroManifiesto();
			Integer anioManifiesto = listDatado.get(0).getDocumentoDeTransporte().getManifiesto().getAnioManifiesto();
			/*branch ingreso 2011-009 hosorio inicio*/
			String viaManifiesto = listDatado.get(0).getDocumentoDeTransporte().getManifiesto().getViaTransporte().getCodDatacat();
			/*branch ingreso 2011-009 hosorio fin*/

			String numManif = SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 6, ' ');
			Integer annManif = SunatNumberUtils.toInteger( SunatStringUtils.substring(declaracion.getDua().getManifiesto().getAnnmanif(),0, 4) );
			/*branch ingreso 2011-009 hosorio inicio*/
			String viaManif = declaracion.getDua().getManifiesto().getCodmodtransp();
			/*branch ingreso 2011-009 hosorio fin*/
			// Si cambia de manifiesto desdatar todo
			if(! numeroManifiesto.trim().equals(numManif.trim())
					|| annManif.intValue() != anioManifiesto.intValue()
					/*branch ingreso 2011-009 hosorio inicio*/
					||(viaManifiesto.equals("1") && !viaManif.equals("1"))	
					/*branch ingreso 2011-009 hosorio fin*/
					)
			{
				registrarDesdatadoPorCambioManifiesto(variablesIngreso, declaracion, codTransaccion);
				return; 
			}

			for (Datado datado : listDatado) { 

				if(!datado.getTipo().getCodDatacat().equals("B")){

					boolean existeEnMapa = false;
					String numeroDocumentoTransporte = datado.getDocumentoDeTransporte().getNumeroDocumentoTransporte();
					Integer numeroDeDetalle = datado.getDocumentoDeTransporte().getNumeroDeDetalle();
					numeroDeDetalle = numeroDeDetalle != null ? numeroDeDetalle : -1;
					/*branch ingreso 2011-009 hosorio inicio*/
					if(!CollectionUtils.isEmpty(listaParaDatado)){
						/*branch ingreso 2011-009 hosorio fin*/
						for(Map<String,Object> datadoMap:listaParaDatado){
							Integer numeroDeDetalleMap = datadoMap.get("numeroDeDetalle") != null ? (Integer)datadoMap.get("numeroDeDetalle") : -1;
							String numeroDocumentoTransporteMap = datadoMap.get("numeroDocumentoTransporte")!= null ? (String)datadoMap.get("numeroDocumentoTransporte"): "";

							if(numeroDocumentoTransporte.equals(numeroDocumentoTransporteMap)
									&& numeroDeDetalle.equals(numeroDeDetalleMap))
							{
								existeEnMapa = true;
							}
						}
						/*branch ingreso 2011-009 hosorio inico*/
					}
					/*branch ingreso 2011-009 hosorio fin*/

					if(!existeEnMapa){
						Map<String,Object> datadoMap = new HashMap<String, Object>();
						datadoMap.putAll(listaParaDatado.get(0)); // solo copia el contenido
						datadoMap.put("numeroDeDetalle", numeroDeDetalle);
						datadoMap.put("numeroDocumentoTransporte", numeroDocumentoTransporte);
						datadoMap.put("tieneDatadoSobreRecibido", variablesIngreso.get("tieneDatadoSobreRecibido") );
						//rtineo dam diferida sin ica y registrada sin ica
						datadoMap.put("isDAMDiferidaSinIca",variablesIngreso.get("isDAMDiferidaSinIca")!=null?variablesIngreso.get("isDAMDiferidaSinIca"):false);
						datadoMap.put("isDAMRegistradaDiferidaSinIca",variablesIngreso.get("isDAMRegistradaDiferidaSinIca")!=null?variablesIngreso.get("isDAMRegistradaDiferidaSinIca"):false);
						//dam diferida sin ica fin
						datadoMap = GeneralUtils.actualizaDatosFijosDesdatadoRegistro(declaracion, codTransaccion, datadoMap);						
						Map resultado = datado2Service.registrarDesDatado(datadoMap);
					}
				}
			}
		}
	}

	/**
	 * Registrar desdatado por cambio manifiesto.
	 * 
	 * @param variablesIngreso Map<String,Object>
	 * @param listaParaDatado List<Map<String,Object>>
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 */
	private void registrarDesdatadoPorCambioManifiesto(Map<String, Object> variablesIngreso, Declaracion declaracion, String codTransaccion){

		Datado2Service datado2Service = (Datado2Service) fabricaDeServicios.getService("manifiesto.datado2Service");
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("detalleNumeroCorrelativo", declaracion.getNumeroCorrelativo()); 
		List<Datado> listDatado = datado2Service.obtenerDatadoByParameterMap(paramsMap);

		Boolean esUrgenteAnticipada = (Boolean)variablesIngreso.get("esUrgenteAnticipada");
		Boolean esUrgenteExcepcional = (Boolean)variablesIngreso.get("esUrgenteExcepcional");

		Map<String,Object> otrosDatos = new HashMap<String, Object>();
		boolean esUrgente = "01".equals(declaracion.getDua().getCodmodalidad())?true:false;
		if (esUrgente){
			otrosDatos.put("esUrgenteAnticipada", esUrgenteAnticipada);
			otrosDatos.put("esUrgenteExcepcional", esUrgenteExcepcional);
		}

		Map<String,Object> dataDua = GeneralUtils.getDatosFijosDatadoValidacion(declaracion, codTransaccion, otrosDatos);

		for (Datado datado : listDatado) {

			String numeroDocumentoTransporte = datado.getDocumentoDeTransporte().getNumeroDocumentoTransporte();
			Integer numeroDeDetalle = datado.getDocumentoDeTransporte().getNumeroDeDetalle();
			dataDua.put("numeroManifiesto", datado.getDocumentoDeTransporte().getManifiesto().getNumeroManifiesto());
			dataDua.put("anioManifiesto", datado.getDocumentoDeTransporte().getManifiesto().getAnioManifiesto());
			dataDua.put("codigoTipoManifiesto", datado.getDocumentoDeTransporte().getManifiesto().getTipoManifiesto().getCodDatacat());
			/*branch ingreso 2011-009 hosorio inicio*/
			// bug 4525
			dataDua.put("codigoViaTransporte", datado.getDocumentoDeTransporte().getManifiesto().getViaTransporte().getCodDatacat());
			/*branch ingreso 2011-009 hosorio fin*/

			dataDua.put("numeroDeDetalle", numeroDeDetalle);
			dataDua.put("numeroDocumentoTransporte", numeroDocumentoTransporte);
			//rtineo dam diferida sin ica y registrada sin ica
			dataDua.put("isDAMDiferidaSinIca",variablesIngreso.get("isDAMDiferidaSinIca")!=null?variablesIngreso.get("isDAMDiferidaSinIca"):false);
			dataDua.put("isDAMRegistradaDiferidaSinIca",variablesIngreso.get("isDAMRegistradaDiferidaSinIca")!=null?variablesIngreso.get("isDAMRegistradaDiferidaSinIca"):false);
			//dam diferida sin ica fin
			dataDua = GeneralUtils.actualizaDatosFijosDesdatadoRegistro(declaracion, codTransaccion, dataDua);						
			Map resultado = datado2Service.registrarDesDatado(dataDua);
		} 
	}	


	@SuppressWarnings("unchecked")
	public void afectaGarantia(Declaracion declaracion, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String numOrden,
			String codUsuario, String cTrans, String tipoDesp, Date fechaConclusionDespa, Map<String, Object> variablesIngreso) {

		List<HashMap> lstDeudasAAfectar = new ArrayList(); // Para la afectaci�n de la garant�a.
		List<HashMap> lstDeudasLCs = new ArrayList();
		HashMap deudaDUA = new HashMap();
		BigDecimal deudaDUALC = new BigDecimal(0);
		Map<String, Object> param = new HashMap();
		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;
		String codgarantia = decla != null ? decla.getCodgarantia() : null;
		String codTipoPago = decla != null ? decla.getCodtipopago() : null;
		String RUCImport = "";
		//rtineo garantia para dseer obtiene el ruc desde otro atributo
        if(ConstantesDataCatalogo.REGIMEN_EER.equals(declaracion.getDua().getCodregimen()))
            RUCImport = declaracion.getDua().getRucCtaCorriente();
        else
            RUCImport = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
        //rtineo fin

		String resultado = "";
		String codTransaccion=(String)variablesIngreso.get("codTransaccion");
		String Transaccion=codTransaccion.substring(2, 4);
		//pase24 mordonezl
		boolean esGarantiaRenovada = (Boolean) (variablesIngreso.get("esGarantiaRenovada")!=null?variablesIngreso.get("esGarantiaRenovada"):false); // garantia renovada solo para valor provicional
		boolean esCuentaCorrienteRectificada =  (Boolean) (variablesIngreso.get("esCuentaCorrienteRectificada")!=null?variablesIngreso.get("esCuentaCorrienteRectificada"):false);
		String ctacteAnterior = (String)(variablesIngreso.get("ctacteAnterior")!=null? variablesIngreso.get("ctacteAnterior"):"");
		//PAS20165E220200127
		if(!esGarantiaRenovada){
			Map<String, Object> reliquida = (Map<String, Object>) variablesIngreso.get("RESULTADO_LIQ");
			if(reliquida!=null){
				esGarantiaRenovada =  (Boolean) (reliquida.get("GARANTIA_RENOVADA")!=null?reliquida.get("GARANTIA_RENOVADA"):false); 
			}
		}

		/** RSV PAS20155E220200172 el tipo TPI 100 ES REEEMPLAZADO POR EL TPILC15_9 **/
		boolean mtoTPILC15S9 = variablesIngreso.get("montoTPILC15_SI_9")!=null?true:false;

		//RIN10-AFMA - Inicio - bug - Sincronizacion
		Map mapVP = (HashMap)variablesIngreso.get("mapVP");
		if(mapVP == null){   
			mapVP = new HashMap();
		}
		//RIN10 FIN- bug - Sincronizacion
		//Inicio RIN10
		List lstDeudasAAfectarVP =  mapVP.get("lstDeudasAAfectarVP")!=null?(ArrayList)mapVP.get("lstDeudasAAfectarVP"):new ArrayList();
		Map   mpDeudasADesafectarVP = mapVP.get("mpDeudasADesafectarVP")!=null?(HashMap)mapVP.get("mpDeudasADesafectarVP"):new HashMap();

		//if ((!SunatStringUtils.isEmpty(codgarantia) ||  "G".equals(codTipoPago)) && variablesIngreso.get("RESULTADO_LIQ")!=null) {// tiene una garantia 160
		if ((!SunatStringUtils.isEmpty(codgarantia) || "G".equals(codTipoPago)) && variablesIngreso.get("RESULTADO_LIQ")!=null) {// tiene una garantia 160 // RIN 16
			//Fin RIN10
			Map mapResultLiq = (Map) variablesIngreso.get("RESULTADO_LIQ");
			/*branch ingreso 2011-009 hosorio inicio 09/08/2011*/
			//lstDeudasAAfectar = (List<HashMap>) mapResultLiq.get("LISTADEUDAS");
			//Inicio RIN10
			//lstDeudasAAfectar = (List<HashMap>) mapResultLiq.get("LISTADEUDASAFECTAR");
			lstDeudasAAfectar = mapResultLiq.get("LISTADEUDASAFECTAR")!=null?(List<HashMap>) mapResultLiq.get("LISTADEUDASAFECTAR"):new ArrayList();
			boolean desafectaPercepcion = mapResultLiq.get("DESAFECTAPERCEPCION_AMAZONIA_ACOGPOST")==null ? true: (mapResultLiq.get("DESAFECTAPERCEPCION_AMAZONIA_ACOGPOST").toString().equals("SI") ? true : false);

			if(!CollectionUtils.isEmpty(lstDeudasAAfectarVP)){
				lstDeudasAAfectar.addAll(lstDeudasAAfectarVP);
			}

			//Map<String,HashMap> mpDeudasADesafectar=(Map<String,HashMap>) mapResultLiq.get("LISTADEUDASDESAFECTAR");
			Map<String,HashMap> mpDeudasADesafectar=mapResultLiq.get("LISTADEUDASDESAFECTAR")!=null?(Map<String,HashMap>) mapResultLiq.get("LISTADEUDASDESAFECTAR"):new HashMap();

			if(!CollectionUtils.isEmpty(mpDeudasADesafectarVP)){
				mpDeudasADesafectar.putAll(mpDeudasADesafectarVP);
			}
			//Fin RIN10
			/*branch ingreso 2011-009 hosorio FIN 09/08/2011*/
			param.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
			//DUA duaTmp = NumeracionServiceImpl.getInstance().getCabDeclaraDAO().selectByNumCorredoc(param);
			DUA duaTmp = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).selectByNumCorredoc(param);
			boolean incluyeDUA = false;
			boolean DUAMontoCero = false;

			//INICIO RIN 08 - PECO-Amazonia - Variables para identificar si declaracion corresponde al acogimeinto			
			String esPecoAmazonia = variablesIngreso.get("esPecoAmazonia")!=null?variablesIngreso.get("esPecoAmazonia").toString():ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO; 
			String resultadoDiligenciaAduanaDestino = mapResultLiq.get("resultadoDiligenciaAduanaDestino")!=null?mapResultLiq.get("resultadoDiligenciaAduanaDestino").toString():"00"; 
			BigDecimal mtoLiberadoPECOAmazonia = mapResultLiq.get("mtoLiberadoPECOAmazonia")!=null?(BigDecimal)mapResultLiq.get("mtoLiberadoPECOAmazonia"):new BigDecimal(0);
			String regularizaPecoAmazonia = mapResultLiq.get("regularizaPecoAmazonia")!=null?mapResultLiq.get("regularizaPecoAmazonia").toString():"NO";
			String revertirImpugnacion = mapResultLiq.get("revertirImpugnacion")!=null?mapResultLiq.get("revertirImpugnacion").toString():"NO";

			if(ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_CONFORME.equals(resultadoDiligenciaAduanaDestino) || "SI".equals(regularizaPecoAmazonia) || "SI".equals(revertirImpugnacion)){				
				for(HashMap deudaDesaf: mpDeudasADesafectar.values()){
					if("SI".equals(deudaDesaf.get("ANULADA")) || "DUA".equals(deudaDesaf.get("TIPO").toString())){
						resultado = desafectaGarantiaDocumento(RUCImport, "16", deudaDesaf.get("LC").toString(), BigDecimal.ZERO, duaTmp, deudaDesaf.get("CDA").toString(), 
								(BigDecimal)deudaDesaf.get("MONTO"), deudaDesaf.get("MONEDA").toString(), deudaDesaf.get("TIPO").toString(), variablesIngreso);
					}
					else{
						// Cambiamos el Indicador de Reclamo de la LC Percepcion					
						Map params = new HashMap();
						params.put("respuesta", " "); 
						params.put("cADUAFECTA", deudaDesaf.get("COD_ADULIQUIDA").toString());
						params.put("cANNAFECTA", deudaDesaf.get("ANN_LIQUIDA").toString());
						params.put("cNUMAFECTA", deudaDesaf.get("NUM_LIQUIDA").toString());
						params.put("cREGIAFECTA", "96");	
						params.put("cMODULO", tipoDesp);
						params.put("cIND", "2");
						params.put("cRPTA", " ");
						String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
					}
				}
				return;
			}
			//Fin RIN 08			

			for (HashMap deuda:lstDeudasAAfectar) {
				if ("DUA".equals(deuda.get("TIPO"))) { // Para ver si incluye la deuda de la DUA.
					deudaDUA = deuda;
					DUAMontoCero = ( ((BigDecimal)deudaDUA.get("MONTO")).compareTo(BigDecimal.ZERO) == 0 );  //MATC 20130114 - Solo afecta DUA si monto es mayor que cero 	
					incluyeDUA = true;
				}
			}

			if (lstDeudasAAfectar.size()==1) {

				if (incluyeDUA) {
					deudaDUA = (HashMap)lstDeudasAAfectar.get(0);

					if ("01".equals(Transaccion)) { // solo para numeracion
						resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
								deudaDUA.get("CDA").toString(), (BigDecimal)deudaDUA.get("MONTO"), "002", deudaDUA.get("MONEDA").toString(),variablesIngreso);

						//20150228 - Inicio RIN 08 
						if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazonia) && 
								!ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(resultadoDiligenciaAduanaDestino)){
							Map params = new HashMap();
							params.put("respuesta", " "); 
							params.put("cADUAFECTA", duaTmp.getCodaduanaorden());
							params.put("cANNAFECTA", duaTmp.getAnnpresen().toString());
							params.put("cNUMAFECTA", Cadena.padLeft(duaTmp.getNumdocumento().trim(), 6, '0'));
							params.put("cREGIAFECTA", duaTmp.getCodregimen());	
							params.put("cMODULO", tipoDesp);
							params.put("cIND", "1");
							params.put("cRPTA", "");
							String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
						}
						//Fin RIN 08
					}
					else { // regularizacion y rectificacion
						if( !DUAMontoCero ) {
							
							if(esCuentaCorrienteRectificada){
								// setea la nueva cuenta anterior, porque se pierde por el orden a veces.
								if(!ctacteAnterior.isEmpty()){
									duaTmp.getPago().getPagoDeclaracion().setCodgarantia(ctacteAnterior);
								}
								String codDesafectacion = "16";
																
								// Desafectar  
								for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
									
									if(duaTmp.getCodregimen().equals(Constantes.REGIMEN_ADM_ADM_TEMPORAL_PA) || duaTmp.getCodregimen().equals(Constantes.REGIMEN_ADM_TEMPORAL_REEX) ){
										codDesafectacion = "10";
//										if(mpLcDesaf.get("Tipo").toString().equals("LC") && codDesafectacion.equals("10")){
//											codDesafectacion = "06";
//										}
	}
																		
									resultado =desafectaGarantiaDocumento(RUCImport,codDesafectacion,mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
											(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), mpLcDesaf.get("TIPO").toString(),variablesIngreso );	   
								}
								
								
								// setea la nueva cuenta a rectificar
								duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
								

								// afectar la garantia en el nueva cuenta
								//PAS20181U220200069 - mtorralba 20190306 - Se incluye variable desafectaPercepcion
								resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaDUA.get("CDA").toString(), (BigDecimal)deudaDUA.get("MONTO"), "003", deudaDUA.get("MONEDA").toString(),variablesIngreso, desafectaPercepcion);

								
							}else{
								//PAS20181U220200069 - mtorralba 20190306 - Se incluye variable desafectaPercepcion

								resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 

										deudaDUA.get("CDA").toString(), (BigDecimal)deudaDUA.get("MONTO"), "003", deudaDUA.get("MONEDA").toString(),variablesIngreso, desafectaPercepcion);

								//20150228 - Inicio RIN 08 
								if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazonia) && 
										!ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(resultadoDiligenciaAduanaDestino)){
									Map params = new HashMap();
									params.put("respuesta", " "); 
									params.put("cADUAFECTA", duaTmp.getCodaduanaorden());
									params.put("cANNAFECTA", duaTmp.getAnnpresen().toString());
									params.put("cNUMAFECTA", Cadena.padLeft(duaTmp.getNumdocumento().trim(), 6, '0'));
									params.put("cREGIAFECTA", duaTmp.getCodregimen());	
									params.put("cMODULO", tipoDesp);
									params.put("cIND", "1");
									params.put("cRPTA", "");
									String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
								}
								//Fin RIN 08
							}
						}
						else {
							for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
								resultado =desafectaGarantiaDocumento(RUCImport,"16",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
										(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), mpLcDesaf.get("TIPO").toString(),variablesIngreso );	   
							}
						}

					}
				} 
				else {

					/*branch ingreso 2011-009 hosorio inicio 09/08/2011*/
					/*INICIO-RIN10 FSW AFMA*/
					//if("03".equals(Transaccion) || "05".equals(Transaccion)){//cambio del 280
					if("03".equals(Transaccion) || "05".equals(Transaccion) || "06".equals(Transaccion)){
						/*FIN-RIN10 FSW AFMA*/
						// cuando no hay dua en la rectificacion - todas son lc 010-022-038
						// elproceso implica : =>desafectar - afectar ()
						if(!CollectionUtils.isEmpty(mpDeudasADesafectar)) {
							for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
								resultado =desafectaGarantiaDocumento(RUCImport,"06",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
										(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(),"LC",variablesIngreso);	   
							}
						}
						
						if(esCuentaCorrienteRectificada){
							// setea la nueva cuenta corriente para su posterior afectacion con los nuevos montos
							duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
						}
						
						
						//pase24 mordonezl
						if(esGarantiaRenovada){
							for (HashMap deudaLC: lstDeudasAAfectar) {
								if(!CollectionUtils.isEmpty(lstDeudasAAfectarVP)){
									for (int j= 0;j<lstDeudasAAfectarVP.size();j++) {
										HashMap deudaLCVP = (HashMap) lstDeudasAAfectarVP.get(j);
										if(deudaLCVP.get("CDA").equals(deudaLC.get("CDA"))){
											//A�adimos el CDA de la deuda para poner el tipo de extinsi�n
											variablesIngreso.put("VALORPROVISIONALCDA", deudaLCVP.get("CDA"));	

										}
									}

								}
								tipoDesp = "L"; // Con esto se afecta la LC con garantia renovada son para garantia renovada
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}	

						}else{//fin pase24	   
							for (HashMap deudaLC: lstDeudasAAfectar) {
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}		
						}
					}
					else {
						if(esCuentaCorrienteRectificada){
							if(!CollectionUtils.isEmpty(mpDeudasADesafectar)) {
								for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
									resultado =desafectaGarantiaDocumento(RUCImport,"06",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
											(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(),"LC",variablesIngreso);	   
								}
							}
							duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
							for (HashMap deudaLC: lstDeudasLCs) {
							resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
									deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(),deudaLC.get("TIPOLC").toString(),variablesIngreso);
							
							}
							
						}else{
						/*branch ingreso 2011-009 hosorio fin 09/08/2011*/
						for (HashMap deudaLC: lstDeudasLCs) {
							if ("01".equals(Transaccion)) { //solo para numeracion
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(),deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}
							else { //regularizacion y rectificacion
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "002", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
								/*xxx:=Pagarantia.Fnafectactacte(<RUC Beneficiario>,<AduanaDUA>,<A�oDUA>,<RegimenDUA>, <NroDUA>,<NroLC>, <CDA de LC>,<codAgente>,<NroOrden>,<Monto deLC>,<Moneda>, <FechaConclusion>, �L� , '002',0,0, <TipoLC> );*/
							}
						}
						/*branch ingreso 2011-009 hosorio inicio 09/08/2011*/
					}
					}
					/*branch ingreso 2011-009 hosorio fin 09/08/2011*/
				}
			} 
			else { //Para lstDeudasAAfectar.size() > 1 
				if (incluyeDUA) {  
					for (HashMap deuda:lstDeudasAAfectar) {
						BigDecimal dolares=BigDecimal.ZERO;
						if (deuda.get("TIPO").equals("DUA")) {
							deudaDUA = deuda;
						} else {
							HashMap mapDeudaLc = deuda;
							lstDeudasLCs.add(mapDeudaLc);
						}
						if ("S".equals(deuda.get("MONEDA"))){// cambiar a dolares
							Map<String,Object> params=new HashMap<String,Object>();
							if("05".equals(Transaccion) || "03".equals(Transaccion)){ //pase 280 mordonezl
								Date fechaActual= new Date();
								params.put("fingreso", SunatDateUtils.getIntegerFromDate(fechaActual));// fecha actual	
							}else {
								params.put("fingreso", SunatDateUtils.getIntegerFromDate(duaTmp.getFecdeclaracion()));// fecha de numeracion
							}
							params.put("cmoneda", "USD");	//		
							//							Cambio1 cambio1 = FormatoAServiceImpl.getInstance().getCambio1DAO().findByPK(params);
							params.put("ayudaID", "Cambio1");
							Cambio1 cambio1 = (Cambio1)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscarObject(params);
							BigDecimal dolarVenta=cambio1.getPventa();
							dolares=((BigDecimal)deuda.get("MONTO")).divide(cambio1.getPventa(), 0, BigDecimal.ROUND_HALF_DOWN);
						} else {
							dolares=(BigDecimal)deuda.get("MONTO");
						}
						deudaDUALC=SunatNumberUtils.sum(deudaDUALC,dolares);
					}
					
					
					// Proceso de afectaci�n.
					if( !DUAMontoCero ) { //MATC 20130114 - Solo afecta cuando la DUA tiene monto mayor a cero
						if ("01".equals(Transaccion)) { //solo para numeracion
							resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
									deudaDUA.get("CDA").toString(), BigDecimal.ZERO, "008", deudaDUA.get("MONEDA").toString(),variablesIngreso); // Primero se env�a la DUA con 0 (cero)
						}else { 
							if(esCuentaCorrienteRectificada){
								//nos aseguramos que tome la ctacte anterior:
								if(!ctacteAnterior.isEmpty()){
									duaTmp.getPago().getPagoDeclaracion().setCodgarantia(ctacteAnterior);
								}
								String codDesafectacion="16";
								
								for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
									if(duaTmp.getCodregimen().equals(Constantes.REGIMEN_ADM_ADM_TEMPORAL_PA) || duaTmp.getCodregimen().equals(Constantes.REGIMEN_ADM_TEMPORAL_REEX) ){
										codDesafectacion = "10";
										if(mpLcDesaf.get("TIPO").toString().equals("LC") && codDesafectacion.equals("10")){
											codDesafectacion = "06";
										}
									}
									resultado =desafectaGarantiaDocumento(RUCImport,codDesafectacion,mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
											(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), mpLcDesaf.get("TIPO").toString(),variablesIngreso );	   
								}
								duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
													
								resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaDUA.get("CDA").toString(),deudaDUALC, "003", deudaDUA.get("MONEDA").toString(),variablesIngreso, desafectaPercepcion);
							}else{
								//MOL PASE280
								//
								//if("05".equals(Transaccion)){
								//	 resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
								// 	deudaDUA.get("CDA").toString(), (BigDecimal)deudaDUA.get("MONTO"), "003", deudaDUA.get("MONEDA").toString(),variablesIngreso);
	
								//FIN MOL
								//}else {//solo para rectificacion y regularizacion
								resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaDUA.get("CDA").toString(),deudaDUALC, "003", deudaDUA.get("MONEDA").toString(),variablesIngreso, desafectaPercepcion);
								/*    xxx:=Pagarantia.Fnafectactacte(<RUC Beneficiario>,<AduanaDUA>,<A�oDUA>,<RegimenDUA>, <NroDUA>,<NroCtaCte>, <CDA>,<codAgente>,<NroOrden>,<SumaMontosDUA_LCs>,<Moneda>,<FechaConclusion>,<Modulo >, '003',   <FechaNumeraci�nDUA>, <FechaRectificacionDUA>);	 * */
								//}
						}
						}

						for (HashMap deudaLC: lstDeudasLCs) {
							resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
									deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "008", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);

							//INICIO RIN08						
							//Solo para la LC de percepcion se actualiza el indicador de reclamo cual la declaracion se acoge a Ley Amazonia-PECO
							/** RSV PAS20155E220200172 el tipo TPI 100 ES REEEMPLAZADO POR EL TPILC15_9   **/
							if( ( (ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(esPecoAmazonia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(esPecoAmazonia)) && 
									"0038".equals(deudaLC.get("TIPOLC").toString()) && !ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(resultadoDiligenciaAduanaDestino) ) || 
									(  mtoTPILC15S9 &&  "0010".equals(deudaLC.get("TIPOLC").toString() )  )) {

								Map params = new HashMap();
								params.put("respuesta", " "); 
								params.put("cADUAFECTA", deudaLC.get("COD_ADULIQUIDA").toString());
								params.put("cANNAFECTA", deudaLC.get("ANN_LIQUIDA").toString());
								params.put("cNUMAFECTA", deudaLC.get("NUM_LIQUIDA").toString());
								params.put("cREGIAFECTA", "96");	
								params.put("cMODULO", tipoDesp);
								params.put("cIND", "1");
								params.put("cRPTA", "");
								String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
							}
							//FIN RIN08							
						}

						//RIN 08 - PECO-Amazonia - Afectamos la garantia solo por el monto liberado y no por el total de la declaracion. Actualizamos indicador de Reclamo
						resultado = afectaGarantiaDocumento(RUCImport, codgarantia, duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
								deudaDUA.get("CDA").toString(), (BigDecimal)deudaDUA.get("MONTO"), "009", deudaDUA.get("MONEDA").toString(),variablesIngreso); // Se vuelve a enviar la DUA pero con su verdadero monto.

						if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazonia) && 
								!ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(resultadoDiligenciaAduanaDestino)){
							Map params = new HashMap();
							params.put("respuesta", " "); 
							params.put("cADUAFECTA", duaTmp.getCodaduanaorden());
							params.put("cANNAFECTA", duaTmp.getAnnpresen().toString());
							params.put("cNUMAFECTA", Cadena.padLeft(duaTmp.getNumdocumento().trim(), 6, '0'));
							params.put("cREGIAFECTA", duaTmp.getCodregimen());	
							params.put("cMODULO", tipoDesp);
							params.put("cIND", "1");
							params.put("cRPTA", "");
							String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
						}
						//Fin RIN 08
					}
					else { //MATC 20130114 - Cuando monto de DUA es cero, desafecta DUAs y L/Cs y afecta con nuevas L/Cs
						if(!CollectionUtils.isEmpty(mpDeudasADesafectar)) {
							for(HashMap mpLcDesaf: mpDeudasADesafectar.values()) {
								resultado =desafectaGarantiaDocumento(RUCImport,"16",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
										(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), mpLcDesaf.get("TIPO").toString(),variablesIngreso );	   
							}
						}

						if(esCuentaCorrienteRectificada){
							// setea la nueva cuenta corriente para su posterior afectacion con los nuevos montos
							duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
						}
						
						// pase24 mordonezl
						if(esGarantiaRenovada){
							for (HashMap deudaLC: lstDeudasLCs) {
								if(!CollectionUtils.isEmpty(lstDeudasAAfectarVP)){
									for (int j= 0;j<lstDeudasAAfectarVP.size();j++) {
										HashMap deudaLCVP = (HashMap) lstDeudasAAfectarVP.get(j);
										if(deudaLCVP.get("CDA").equals(deudaLC.get("CDA"))){
											//A�adimos el CDA de la deuda para poner el tipo de extinsi�n
											variablesIngreso.put("VALORPROVISIONALCDA", deudaLCVP.get("CDA"));	

										}
									}

								}
								tipoDesp = "L"; // Con esto se afecta la LC con garantia renovada son para garantia renovada
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}	

						}else{	   
							for (HashMap deudaLC: lstDeudasLCs) {
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}	
						}

					}//fin pase24
				} 
				else { //No incluye DUA
					/*branch ingreso 2011-009 hosorio inicio 09/08/2011*/
					//RIN10 AFMA
					if("03".equals(Transaccion) || "05".equals(Transaccion) || "06".equals(Transaccion)){
						// cuando no hay dua en la rectificacion - todas son lc 010-022-038
						// elproceso implica : =>desafectar - afectar ()
						if(!CollectionUtils.isEmpty(mpDeudasADesafectar)){
							for(HashMap mpLcDesaf: mpDeudasADesafectar.values()){
								resultado =desafectaGarantiaDocumento(RUCImport,"06",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
										(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), "LC",variablesIngreso);	   
							}
						}
						if(esCuentaCorrienteRectificada){
							// setea la nueva cuenta corriente para su posterior afectacion con los nuevos montos
							duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
						}
						//pase24 mordonezl
						if(esGarantiaRenovada){
							for (HashMap deudaLC: lstDeudasAAfectar) {
								if(!CollectionUtils.isEmpty(lstDeudasAAfectarVP)){
									for (int j= 0;j<lstDeudasAAfectarVP.size();j++) {
										HashMap deudaLCVP = (HashMap) lstDeudasAAfectarVP.get(j);
										if(deudaLCVP.get("CDA").equals(deudaLC.get("CDA"))){
											//A�adimos el CDA de la deuda para poner el tipo de extinsi�n
											variablesIngreso.put("VALORPROVISIONALCDA", deudaLCVP.get("CDA"));	

										}
									}

								}
								tipoDesp = "L"; // Con esto se afecta la LC con garantia renovada son para garantia renovada
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							}	

						}else{	   
							for (HashMap deudaLC: lstDeudasAAfectar) {
								resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
										deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "004", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);			
							}		
						}
						//fin pase24

					}
					else {
						if(esCuentaCorrienteRectificada){
							if(!CollectionUtils.isEmpty(mpDeudasADesafectar)){
								for(HashMap mpLcDesaf: mpDeudasADesafectar.values()){
									resultado =desafectaGarantiaDocumento(RUCImport,"06",mpLcDesaf.get("LC").toString(),BigDecimal.ZERO,duaTmp,mpLcDesaf.get("CDA").toString(), 
											(BigDecimal)mpLcDesaf.get("MONTO"), mpLcDesaf.get("MONEDA").toString(), "LC",variablesIngreso);	   
								}
							}
							duaTmp.getPago().getPagoDeclaracion().setCodgarantia(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
							
						}
						/*branch ingreso 2011-009 hosorio fin 09/08/2011*/
						for (HashMap deudaLC: lstDeudasLCs) {
							resultado = afectaGarantiaDocumento(RUCImport, deudaLC.get("LC").toString(), duaTmp, numeroDocumentoIdentidadSender, numOrden, codUsuario, tipoDesp, fechaConclusionDespa, 
									deudaLC.get("CDA").toString(), (BigDecimal)deudaLC.get("MONTO"), "002", deudaLC.get("MONEDA").toString(), deudaLC.get("TIPOLC").toString(),variablesIngreso);
							//INICIO RIN08							
							//20150218 - Se actualiza el indicador de Reclamo para los casos de PECO-Amazonia
							//Solo para la LC de percepcion se actualiza el indicador de reclamo cual la declaracion se acoge a Ley Amazonia-PECO
							if((ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(esPecoAmazonia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(esPecoAmazonia)) && 
									"0038".equals(deudaLC.get("TIPOLC").toString()) && !ConstantesDataCatalogo.RESULT_DILIG_ADU_DEST_PARCIAL.equals(resultadoDiligenciaAduanaDestino)){

								Map params = new HashMap();
								params.put("respuesta", " "); 
								params.put("cADUAFECTA", deudaLC.get("COD_ADULIQUIDA").toString());
								params.put("cANNAFECTA", deudaLC.get("ANN_LIQUIDA").toString());
								params.put("cNUMAFECTA", deudaLC.get("NUM_LIQUIDA").toString());
								params.put("cREGIAFECTA", "96");	
								params.put("cMODULO", tipoDesp);
								params.put("cIND", "1");
								params.put("cRPTA", "");
								String resultadoReclamo = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).actulizarIndicarReclamo(params);
							}
							//FIN RIN08	
						}
						
					
						/*branch ingreso 2011-009 hosorio fin 09/08/2011*/
					}
					/*branch ingreso 2011-009 hosorio fin 09/08/2011*/
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private String afectaGarantiaDocumento(String RUCImport, String numRef, DUA dua, String numeroDocumentoIdentidadSender, String numOrden,
			String codUsuario, String modulo, Date fechaConclusionDespa, String cda, BigDecimal monto, String cTrans, String moneda,Map<String, Object> variablesIngreso ) {
		return afectaGarantiaDocumento(RUCImport, numRef, dua, numeroDocumentoIdentidadSender, numOrden, codUsuario, modulo, fechaConclusionDespa, 
				cda, monto, cTrans, moneda, "" ,variablesIngreso, true);
	}

	//PAS201830001100016 - mtorralba 20181030 - INICIO
	@SuppressWarnings("unchecked")
	private String afectaGarantiaDocumento(String RUCImport, String numRef, DUA dua, String numeroDocumentoIdentidadSender, String numOrden,
			String codUsuario, String modulo, Date fechaConclusionDespa, String cda, BigDecimal monto, String cTrans, String moneda, String tipoLC ,Map<String, Object> variablesIngreso) {
		return afectaGarantiaDocumento(RUCImport, numRef, dua, numeroDocumentoIdentidadSender, numOrden, codUsuario, modulo, fechaConclusionDespa, 
				cda, monto, cTrans, moneda, tipoLC ,variablesIngreso, true);
	}

	@SuppressWarnings("unchecked")
	private String afectaGarantiaDocumento(String RUCImport, String numRef, DUA dua, String numeroDocumentoIdentidadSender, String numOrden,
			String codUsuario, String modulo, Date fechaConclusionDespa, String cda, BigDecimal monto, String cTrans, String moneda,Map<String, Object> variablesIngreso, 
			boolean desafectaPercepcion ) {
		return afectaGarantiaDocumento(RUCImport, numRef, dua, numeroDocumentoIdentidadSender, numOrden, codUsuario, modulo, fechaConclusionDespa, 
				cda, monto, cTrans, moneda, "" ,variablesIngreso, desafectaPercepcion);
	}
	//PAS201830001100016 - mtorralba 20181030 - FIN

	
	@SuppressWarnings("unchecked")
	private String afectaGarantiaDocumento(String RUCImport, String numRef, DUA dua, String numeroDocumentoIdentidadSender, String numOrden,
			String codUsuario, String modulo, Date fechaConclusionDespa, String cda, BigDecimal monto, String cTrans, String moneda, String tipoLC ,Map<String, Object> variablesIngreso,
			boolean desafectaPercepcion) {
		Date fechaActual= new Date();
		Map params = new HashMap();
		params.put("cRUC", RUCImport); // RUC del beneficiario
		params.put("cADUANA", dua.getCodaduanaorden());
		params.put("cANO", dua.getAnnpresen().toString().substring(2, 4));
		params.put("cREGIMEN", dua.getCodregimen());
		params.put("cNUMERO", Cadena.padLeft(dua.getNumdocumento().trim(), 6, '0'));
		params.put("cNUMREF", numRef);
		params.put("cCDA", cda);
		params.put("cRUCAGENTE", numeroDocumentoIdentidadSender); // RUC del agente
		params.put("cORDEN", numOrden); // variable del orquestador viene a�o y numero de orden
		params.put("nMONTOA", monto); 
		params.put("cMONEDAA", moneda);
		if (dua.getCodregimen().equals("20") || dua.getCodregimen().equals("21")) {
			// Si son las admisiones es la fecha de fin de regimen
			if (dua.getFecfinacoregimen() == null) {
				return "";
			} else {
				params.put("nFECHA1", SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen()));
			}

		} else {// Si es importacion definitiva
			//lvila pase 42
			//Inicio Se comento temporalmente RIN10 (Se comenta deacuerdo lo coordinado con Mariela Ordonez)
			//			if ("008".equals(cTrans)){//cuando es diferente a una lc no se grabe la fecha de conclusion jreynoso
			//				//params.put("nFECHA1",SunatDateUtils.getIntegerFromDate(new FechaBean("00010101", "yyyyMMdd").getSQLDate()));
			//				params.put("nFECHA1",0);
			//			}else{
			//				params.put("nFECHA1", SunatDateUtils.getIntegerFromDate(fechaConclusionDespa));
			//			}
			//Fin Se comento temporalmente RIN10
			//fin lvila pase 42
			params.put("nFECHA1", SunatDateUtils.getIntegerFromDate(fechaConclusionDespa));
		}
		params.put("cMODULO", modulo);
		params.put("cTRANS", cTrans);

		/*hosorio inicio 24/05/2011*/
		//params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion())));
		params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion()));
		/*hosorio fin 24/05/2011*/
		if (!"002".equals(cTrans)){// puede ser rectificacion y regularizacion
			params.put("nFECRECTI", SunatDateUtils.getIntegerFromDate(fechaActual));
		}else{
			params.put("nFECRECTI", 0);
		}
		params.put("cTIPOLIQ", tipoLC );
		params.put("cDESAFECTAPERCEP", desafectaPercepcion ? "SI" : "NO" );
		
		/* Inicio RIN10 3003 erodriguezb */
		String cdaValorProvisional = variablesIngreso.containsKey("VALORPROVISIONALCDA") ? (String) variablesIngreso.get("VALORPROVISIONALCDA"):null;
		if(cdaValorProvisional!=null && cda.equals(cdaValorProvisional)){
			params.put("cTIPOEXTIN", "20");	
		}
		/* Fin RIN10 3003 erodriguezb */

		//String resultado=(String) NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);  
		String resultado=(String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);

		//DZC - Graba en LogRegi  
		Map LogRegiparams = new HashMap();
		LogRegiparams.put("regimen",dua.getCodregimen());
		LogRegiparams.put("codi_aduan",dua.getCodaduanaorden());
		LogRegiparams.put("nume_corre",dua.getNumdocumento().trim()); 
		LogRegiparams.put("fech_error",SunatDateUtils.getCurrentIntegerDate());
		LogRegiparams.put("cod_usumodif",numeroDocumentoIdentidadSender);
		LogRegiparams.put("respuesta",resultado);
		LogRegiparams.put("funcion","PAGARANTIA.fnafectactacte");
		LogRegiparams.put("modulo","GrabarGeneralServiceImpl#afectaGarantiaDocumento()");
		LogRegiparams.put("tipo",(String)variablesIngreso.get("codTransaccion"));
		LogRegiparams.put("ano_prese", (String)SunatStringUtils.toStringObj((Integer) variablesIngreso.get("annEnvio")));
		LogRegiparams.put("nume_orden",(String)SunatStringUtils.toStringObj((Long) variablesIngreso.get("numEnvio")));
		//	     logRegiService.grabaLogGarantia(LogRegiparams,params);  
		// DZC -Fin

		return resultado;

	}

	@SuppressWarnings("unchecked")
	public void asignaCanal(Declaracion declaracion, String tipoDesp, String codTransaccion) {
		SeleccionService seleccionservice = (SeleccionService) fabricaDeServicios.getService("seleccion.SeleccionService");
		if (log.isInfoEnabled())
			log.info("Entry asignaCanal");

		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;
		String codgarantia = decla != null ? decla.getCodgarantia() : null;

		if (!SunatStringUtils.isEmpty(codgarantia) && "10".equals( declaracion.getDua().getCodregimen())){
			//				||( SunatStringUtils.isStringInList(declaracion.getDua().getCodregimen(), "20,21,70") ) ) {

			if (declaracion.getDua().getCodmodalidad().equals("00") || (tipoDesp.equals("TE"))) {
				// invocar a asignar canal
				// Invoca al proceso de revalidaci�n del canal (servicio a
				// proporcionar por grupo de asignaci�n del canal ) (webservice)
				ResponseSeleccion respuesta = seleccionservice.asignar(declaracion.getDua().getCodaduanaorden(),
						declaracion.getDua().getCodregimen(), "1011", Constants.COD_UNISEL_PARAM_WS_SELECION_CANAL, declaracion.getAnnorden(),
						declaracion.getNumeroDeclaracion().toString());

				if (log.isDebugEnabled()) {
					log.debug("respuesta.getMensajeError() = " + respuesta.getMensajeError());
					log.debug("respuesta.getAforo() = " + respuesta.getAforo());
				}

				// si no hay error se asigna el canal y hay aforo
				if (!SunatStringUtils.isEmpty(respuesta.getAforo()) && !SunatStringUtils.isEmpty(respuesta.getMotaforo())) {

					Map<String, Object> param = new HashMap<String, Object>();
					param.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
					param.put("AFORO", respuesta.getAforo());
					param.put("MOTAFORO", respuesta.getMotaforo());
					//NumeracionServiceImpl.getInstance().getCabDeclaraDAO().actualizarCanal(param);
					((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).actualizarCanal(param);
					//RTINEO PAS20145E220000587 INICIO Actualizamos en la tabla riesgo el momento en que se actualiza el canal en la declaracion
					Long num_corredoc = Long.parseLong( declaracion.getDua().getNumcorredoc().toString());
					int rF = seleccionservice.grabarFechaActualizacionCanalAforo(num_corredoc,0);
					if(rF >= 1){
						if(log.isDebugEnabled()) log.debug("EXITO ACTUALIZAR FECHA EN TABLA DE RIESGO: "+rF+" REGISTRO(S) ACTUALIZADOS");
					}
					// PAS20145E220000587 FIN
				}
			}
		}

		if (log.isInfoEnabled())
			log.info("Exit asignaCanal");
	}

	public void actualizaCupoLibe(Declaracion declaracion) {
		CupolibeDAO cupoLibeDAO = (CupolibeDAO) fabricaDeServicios.getService("cupoLibeDAO");
		DUA dua = declaracion.getDua();
		boolean declaracionTieneDatoSeries = !CollectionUtils.isEmpty(dua.getListSeries());
		BigDecimal pesoNetoAcumulado = new BigDecimal(0);
		BigDecimal divisor = new BigDecimal(1000);

		Map<String, Object> tmp = new HashMap();
		List resultado = new ArrayList();
		if (declaracionTieneDatoSeries == true) {

			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getCodtratprefe() != null) {
					if (datoSerieActual.getCodtratprefe().equals(164)) {
						pesoNetoAcumulado = pesoNetoAcumulado.ZERO;
						pesoNetoAcumulado = pesoNetoAcumulado.add(datoSerieActual.getCntpesoneto().divide(divisor));
						Map<String, Object> param = new HashMap();
						param.put("tlib", "T");
						param.put("clib", "164");
						param.put("cadu", declaracion.getCodaduana());
						param.put("tdoc", declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
						param.put("cnumdoc", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
						param.put("cnan", datoSerieActual.getNumpartnandi());
						resultado = cupoLibeDAO.findByKey(param);

						if (SunatNumberUtils.isGreaterThanZero(pesoNetoAcumulado) && resultado.size() > 0) {// actualizamos
							// los
							// pesos
							pesoNetoAcumulado = pesoNetoAcumulado.add(BigDecimal.valueOf(Double.parseDouble(tmp.get("pesosol").toString())));
							// Se actualiza el cupolibe.

							param.put("pesosol", pesoNetoAcumulado);
							cupoLibeDAO.actualizarPesos(param);

						}

					}
				}
			}
		}

	}

	@SuppressWarnings("unchecked")
	// ///grabarTabImpDU(declaracion); Elsa dijo que ya no se tenia que invoccar
	// en la grabacion de la DUA
	public void grabarTabImpDU(Declaracion declaracion) {
		Map params = new HashMap();
		boolean esRegularizable = false;

		// Para las anticipadas regularizables y para todas las urgentes
		// insertar en tabimpdu
		for (DatoIndicadores indicador : declaracion.getDua().getListIndicadores()) {
			if (indicador.getCodtipoindica().equals("02")) { // es regularizable
				esRegularizable = true;
			}
		}

		if ((declaracion.getDua().getCodmodalidad().equals("10") && esRegularizable) || declaracion.getDua().getCodmodalidad().equals("01")) {

			params.put("maduana", declaracion.getCodaduana());
			params.put("manoprese", declaracion.getDua().getAnnpresen());
			params.put("mpoliza", declaracion.getNumdeclRef().getNumcorre());
			params.put("mdocu", declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			params.put("mtribu", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params.put("mregi", declaracion.getDua().getCodregimen());
			params.put("mfech", 0);
			params.put("mVENCI", 0);
			params.put("MDESPA", declaracion.getDua().getCodmodalidad().equals("10") ? "A" : "U");
			params.put("MOPCI", 1);
			//NumeracionServiceImpl.getInstance().getTabImpDUDAO().procesarTabImpDU(params);
			((TabImpDUDAO)fabricaDeServicios.getService("tabImpDUDAO")).procesarTabImpDU(params);

		}

	}

	@SuppressWarnings("unchecked")
	public void grabarProductoRemate(Declaracion declaracion) {
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		String digVerificador = "";
		// CabDocliq record=new CabDocliq();
		// CabDocliq recordBD=new CabDocliq();
		FechaBean fbCurrent = new FechaBean();
		Integer anho = new Integer(fbCurrent.getAnho());
		// record.setAnnDocliq(anho.toString());
		// record.setNumDocliq(declaracion.getNumdeclRef().getNumcorre());
		// record.setCodAduDocliq(declaracion.getCodaduana());
		// record.setCodRegDocliq(declaracion.getDua().getCodregimen());
		// record.setCodTipLiqui("01");
		String lcNumDUA = Cadena.padLeft(declaracion.getNumeroDeclaracion().toString(), 6, '0');

		digVerificador = liquidaDeclaracionService.digiVeri(declaracion.getCodaduana(), fbCurrent.getAnho(), declaracion.getDua().getCodregimen(),
				lcNumDUA, "01");

		// recordBD=NumeracionServiceImpl.getInstance().getCabDocliqDAO().selectByPrimaryKey(record);

		//		String mcodi_alma = FormatoAServiceImpl.getInstance().getOpecomextDAO().getCodAlmacenAnt(declaracion.getDua().getNumruclugarecep(),
		//				SunatDateUtils.getCurrentDate(), declaracion.getDua().getCodtipooper());

		String mcodi_alma = ((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCodAlmacenAnt(declaracion.getDua().getNumruclugarecep(),
				SunatDateUtils.getCurrentDate(), declaracion.getDua().getCodtipooper());

		if (mcodi_alma == null) {
			mcodi_alma = "";
		}
		// if (recordBD==null){
		// digVerificador="";
		// }else{
		// digVerificador=recordBD.getCodDigiver();
		// }

		DatoManifiesto manif = declaracion.getDua().getManifiesto();
		String codaduamanif = manif != null ? manif.getCodaduamanif() : null;
		String annmanif = manif != null ? manif.getAnnmanif() : null;
		String nummanif = manif != null ? manif.getNummanif() : null;
		String codmodtransp = manif != null ? manif.getCodmodtransp() : null;
		for (DatoDocTransporte DatoDocTransporteTmp : declaracion.getDua().getListDocTransporte()) {
			HashMap params = new HashMap();
			params.put("Tpuer_embar", DatoDocTransporteTmp.getCodpuerto());
			params.put("Tcono_embar", DatoDocTransporteTmp.getNumdoctransporte());
			params.put("Tnumdet", DatoDocTransporteTmp.getNumsecdoctrans().toString());

			params.put("Tcodi_alma", mcodi_alma);
			params.put("Tcodi_aduan", declaracion.getCodaduana());
			params.put("Tcodi_regi", declaracion.getDua().getCodregimen());
			params.put("Tano_prese", anho.toString());
			params.put("Tnume_corre", declaracion.getNumeroDeclaracion().toString());
			params.put("TTipo_docum", "01");
			params.put("TDig_Verificador", digVerificador);
			params.put("TSufijo", "00");
			params.put("Tcadu_manif", codaduamanif);
			if (declaracion.getDua().getManifiesto() != null && declaracion.getDua().getManifiesto().getAnnmanif() != null)
				params.put("Tanno_manif", SunatStringUtils.length(annmanif) > 3 ? annmanif.substring(0, 4) : null);
			params.put("Tnume_manif", nummanif);
			params.put("Tvia_transp", codmodtransp);
			params.put("Tcusuario", "163AR01");

			//Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + declaracion.getCodaduana())); //el datasource que quieren
			// invocar al sp de usamtg00.sptg_grab_producto
			//NumeracionServiceImpl.getInstance().getSpGeneralDAO().sptg_grab_producto(params);
			DataSourceContextHolder.setKeyDataSource(declaracion.getCodaduana());//gmontoya Pase PAS20175E220200075
			((SPGeneralDAO)fabricaDeServicios.getService("spGeneralDAORouting")).sptg_grab_producto(params);
			//swapperDatasource.swap(o);
		}

	}

	@SuppressWarnings("unchecked")
	public void grabaCupoTPI(Map<String, Object> variablesIngreso) {
		if (variablesIngreso.get("haycupo") == null ? false : (Boolean) variablesIngreso.get("haycupo")) {
			List<HashMap> lstCupoTPI = (List<HashMap>) variablesIngreso.get("lstCupoTPI");
			Declaracion declaracion = (Declaracion) variablesIngreso.get("declaracion");
			DUA dua = declaracion.getDua();
			Long numCorredoc = declaracion.getNumeroCorrelativo();
			Map<String, Object> params = new HashMap();
			params.put("numeroCorrelativo", numCorredoc);
			//DUA duaBD = NumeracionServiceImpl.getInstance().getCabDeclaraDAO().selectByNumCorredoc(params);
			DUA duaBD = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).selectByNumCorredoc(params);
			if (duaBD == null) {
				return;
			}
			CupotpiDAO cupotpiDAO = (CupotpiDAO)fabricaDeServicios.getService("cupoTpiDAO");
			SeriecupoDAO seriecupoDAO = (SeriecupoDAO)fabricaDeServicios.getService("seriecupoDAO");
			for (HashMap mapCupoTPI : lstCupoTPI) {
				String tipo_lib = mapCupoTPI.get("tipo_lib").toString();
				String codi_libe = mapCupoTPI.get("codi_libe").toString();
				String codi_part = mapCupoTPI.get("codi_part").toString();
				String mcnaladisa = mapCupoTPI.get("mcnaladisa").toString();
				String mtribut = mapCupoTPI.get("mtribut").toString();
				BigDecimal variable = (BigDecimal) mapCupoTPI.get("variable");
				HashMap param = new HashMap();
				param.put("cant_uti", variable);
				param.put("tlib", tipo_lib);
				param.put("clib", Cadena.padLeft(codi_libe.trim(), 4, ' '));
				param.put("cnan", codi_part);
				param.put("naladisa", mcnaladisa);
				if (!SunatStringUtils.isEmpty(mtribut.trim())) {
					param.put("cnumdoc", mtribut);
				}
				cupotpiDAO.updateCantidad(param);
				for (DatoSerie serie : dua.getListSeries()) {
					if (serie.getCodconvinter().equals(Integer.valueOf(codi_libe))) {
						Seriecupo seriecupo = new Seriecupo();
						seriecupo.setcAdua(duaBD.getCodaduanaorden());
						seriecupo.setaPrese(duaBD.getAnnpresen().toString());
						seriecupo.setcReg(duaBD.getCodregimen());
						seriecupo.setnCorre(Cadena.padLeft(duaBD.getNumdocumento().trim(), 6, '0'));
						seriecupo.setnSerie(Cadena.padLeft(serie.getNumserie().toString().trim(), 4, ' '));
						seriecupo.settLib("I");
						seriecupo.setcLib(Cadena.padLeft(codi_libe.trim(), 4, ' '));
						seriecupo.setnDoc(mtribut);
						if (!SunatStringUtils.isEmpty(mtribut.trim())) {
							seriecupo.settDoc("4");
						} else {
							seriecupo.settDoc(" ");
						}
						seriecupo.setpNaladisa(Long.valueOf(mcnaladisa).longValue());
						seriecupo.setpNandina(Long.valueOf(codi_part).longValue());
						seriecupo.setpNeto(serie.getCntpesoneto());
						seriecupo.setvFob(serie.getMtofobdol());
						seriecupo.settIndica(Integer.valueOf("1"));
						seriecupoDAO.insert(seriecupo);
					}
				}
			}
		}
	}
	/*
	public CupotpiDAO getCupotpiDAO() {
		return cupotpiDAO;
	}

	public void setCupotpiDAO(CupotpiDAO cupotpiDAO) {
		this.cupotpiDAO = cupotpiDAO;
	}

	public SeriecupoDAO getSeriecupoDAO() {
		return seriecupoDAO;
	}

	public void setSeriecupoDAO(SeriecupoDAO seriecupoDAO) {
		this.seriecupoDAO = seriecupoDAO;
	}*/

	@SuppressWarnings("unchecked")
	public void grabaCtaCtePerNat(Declaracion declaracion, String codTransaccion) {
		DUA dua = declaracion.getDua();
		String tipo_docum = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		boolean gbTieneIncMig = false;
		String lcTipoTrans = "01"; // Por defecto.
		if (codTransaccion != null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		for (DatoSerie serie : dua.getListSeries()) {
			gbTieneIncMig = SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()), new String[] { "4442", "4443", "4444" });
			if (gbTieneIncMig)
				break;
		}
		/*	if (!lcTipoTrans.equals("03") && !gbTieneIncMig && SunatStringUtils.include(tipo_docum, new String[] { "2", "3", "5", "6","7","9" })
				&& !(SunatStringUtils.include(tipo_docum,new String[]{"6","7"}) && "7".equals(dua.getCodtipotratamiento()))) {*/

		if (!lcTipoTrans.equals("03") && !gbTieneIncMig && SunatStringUtils.include(tipo_docum, new String[] { "2", "3", "5","6","7","9" })
				//&& (SunatStringUtils.include(tipo_docum,new String[]{"6","7"}) && !"7".equals(dua.getCodtipotratamiento()))) {
				&& (!"7".equals(dua.getCodtipotratamiento()))) {

			String xCodiExcep = " ";
			String xTipoDocum = tipo_docum;
			Integer lnSecuencia = 0;
			for (DatoSerie serie : dua.getListSeries()) {
				if ((SunatStringUtils.include(xTipoDocum, new String[] { "3", "5", "7" }) && 4202 == serie.getCodliberatorio())
						|| (SunatStringUtils.include(xTipoDocum, new String[] { "6", "7" }) && SunatStringUtils.include(String.valueOf(serie
								.getCodliberatorio()), new String[] { "3302", "3309" }))
						|| (SunatStringUtils.include(xTipoDocum, new String[] { "5", "6" }) && serie.getCodliberatorio() == 3312)
						|| (SunatStringUtils.include(xTipoDocum, new String[] { "4", "5", "6", "7", "8" }) && serie.getNumpartnandi() == 9804000000L)
						|| (SunatStringUtils.include(xTipoDocum, new String[] { "3", "6" }) && SunatStringUtils.include(String.valueOf(serie
								.getNumpartnandi()), new String[] { "9801000010", "9801000020" }))) {
					return;
				} else if (SunatStringUtils.include(xTipoDocum, new String[] { "3", "5", "7" }) && 4201 == serie.getCodliberatorio()) {
					xCodiExcep = "01";
				}
			}
			Long numCorredoc = dua.getNumcorredoc();
			Map<String, Object> params = new HashMap();
			params.put("numeroCorrelativo", numCorredoc);
			CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
			DUA dua2 = cabdeclaraDAO.selectByNumCorredoc(params);
			if (dua2 == null) {
				return;
			}
			BigDecimal lnSumaFOB = new BigDecimal("0");
			CtaCtePerNat tmpCtaCtePerNat = new CtaCtePerNat();
			tmpCtaCtePerNat.setAnoPrese(dua2.getAnnpresen().toString());
			tmpCtaCtePerNat.setCodiRegi(dua2.getCodregimen());
			tmpCtaCtePerNat.setLibrTribu(dua.getDeclarante().getNumeroDocumentoIdentidad());
			tmpCtaCtePerNat.setTipoDocum(tipo_docum);
			//List<CtaCtePerNat> lstCtaCtePerNat = FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().selectBySelective(tmpCtaCtePerNat);
			List<CtaCtePerNat> lstCtaCtePerNat = ((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(tmpCtaCtePerNat);
			if (lstCtaCtePerNat != null && lstCtaCtePerNat.size() > 0) {
				lnSecuencia = lstCtaCtePerNat.size();
			}
			tmpCtaCtePerNat.setCodiAduan(dua.getCodaduanaorden());
			tmpCtaCtePerNat.setNumeCorre(dua2.getNumdocumento());
			tmpCtaCtePerNat.setFechAnula(Integer.valueOf("0"));
			tmpCtaCtePerNat.setFlagAnula("0");
			//lstCtaCtePerNat = FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().selectBySelective(tmpCtaCtePerNat);
			lstCtaCtePerNat = ((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(tmpCtaCtePerNat);

			for (CtaCtePerNat ctaCtaPerNat : lstCtaCtePerNat) {
				lnSumaFOB = lnSumaFOB.add(ctaCtaPerNat.getTfobDolpo());
			}
			if(!codTransaccion.equals("1001")){
				if (dua.getMtotfobclvta().compareTo(lnSumaFOB) != 0) {
					//FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().anula(tmpCtaCtePerNat);
					//pase42 mol

					((CtaCtePerNatDAO)fabricaDeServicios.getService("declaracion.ctaCtePerNatDAO.dx")).anula(tmpCtaCtePerNat);
				}
			}
			lnSecuencia++;
			tmpCtaCtePerNat.setNumeSecue(lnSecuencia);
			tmpCtaCtePerNat.setCodiExcep(xCodiExcep);
			tmpCtaCtePerNat.setTfobDolpo(dua.getMtotfobclvta());
			tmpCtaCtePerNat.setcRegimen(dua2.getCodregimen());
			//FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().insert(tmpCtaCtePerNat);
			//pase42 mol
			((CtaCtePerNatDAO)fabricaDeServicios.getService("declaracion.ctaCtePerNatDAO.dx")).insert(tmpCtaCtePerNat); //pase 42 para solucionar bug 19644
		}
	}

	public String invocarAfectarGarantia(Declaracion declaracion, BigDecimal montoAcumuladoDolares, String cda, Integer fechaConclusionDespacho,
			String numeroDocumentoIdentidadSender, String modulo, String ctrans, String numref, String numero) {

		Map params = new HashMap();
		Map<String, Object> param = new HashMap();
		List<Map<String, String>> lstErrores = null;

		params.put("cRUC", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC
		// del
		// beneficiario
		params.put("cADUANA", declaracion.getNumdeclRef().getCodaduana());
		params.put("cANO", declaracion.getNumdeclRef().getAnnprese());
		params.put("cREGIMEN", declaracion.getNumdeclRef().getCodregimen());
		params.put("cNUMERO", Cadena.padLeft(numero.trim(), 6, '0')); // numero
		// de la
		// DUA
		params.put("cNUMREF", numref);
		params.put("cCDA", " ");
		params.put("cRUCAGENTE", numeroDocumentoIdentidadSender); // RUC del
		// agente
		params.put("cORDEN", declaracion.getAnnorden().toString().concat(declaracion.getNumorden().toString()));
		params.put("nMONTOA", montoAcumuladoDolares); // soles + dolares
		params.put("cMONEDAA", "D");
		params.put("nFECHA1", fechaConclusionDespacho);
		params.put("cMODULO", modulo);
		params.put("cTRANS", ctrans);

		//String resultado = (String) NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);
		//String resultado = (String) ((PagarantiaDAO)fabricaDeServicios.getService("parantiaDAO")).procesarAfectaCtaCte(params);
		// RIN15 se cambia "parantiaDAO" por "pagarantiaDAO"
		String resultado=(String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);

		return resultado;

	}

	//	public void realizarEnvioCorreoDocAutoriz(Declaracion declaracion) {
	//		FechaBean fbCurrent = new FechaBean();
	//		Integer anho = new Integer(fbCurrent.getAnho());
	//		for (DatoSerie datoSerie : declaracion.getDua().getListSeries()) {
	//			List<DatoDocAutorizante> listaDocAutoriz = getDocAutorizante(declaracion.getDua(), datoSerie);
	//			for (DatoDocAutorizante docAutoriz : listaDocAutoriz) {
	//				// Realizar envio de correo
	//				Map<String, Object> params = new HashMap<String, Object>();
	//				String rucEntidadEmisora = new String();
	//				params.put("cod_Servicio", "60");
	//				params.put("cod_Plantilla", "100020");
	//				params.put("tip_Servicio", ComunicacionService.TIPO_SERVICIO_AVISO_ELECTRONICO);
	//				params.put("num_Corredoc", Integer.valueOf(declaracion.getNumeroCorrelativo().toString()));
	//				Map<String, Object> datosEspecificosPlantilla = new HashMap<String, Object>();
	//				datosEspecificosPlantilla.put("codAduana", declaracion.getCodaduana());
	//				datosEspecificosPlantilla.put("anho", anho);
	//				datosEspecificosPlantilla.put("regimen", declaracion.getDua().getCodregimen());
	//				datosEspecificosPlantilla.put("nroDua", declaracion.getDua().getNumdocumento());
	//				String codEntidad = "";
	//				codEntidad = docAutoriz.getCodentidad();
	//				if ("03".equals(docAutoriz.getCodentidad()) || "04".equals(docAutoriz.getCodentidad())) {
	//					codEntidad = "0403";
	//				}
	//
	//				List<Map<String, Object>> operadores = catalogoHelper.getOperadorAyudaService().getOperadorPorCodAduanero(
	//						Constants.COD_DATA_CATALOG_ENTIDAD_AUTORIZ, codEntidad);
	//				for (Map<String, Object> operador : operadores) {
	//					rucEntidadEmisora = (String) operador.get("NUM_RUC");
	//				}
	//				datosEspecificosPlantilla.put("rucEntidadEmisora", rucEntidadEmisora);
	//				datosEspecificosPlantilla.put("nroDocAutoriz", docAutoriz.getNumdocum());
	//				comunicacionService.enviarAvisoElectronicoEntidad(params, datosEspecificosPlantilla);
	//			}
	//		}
	//	}

	public List<DatoDocAutorizante> getDocAutorizante(DUA dua, DatoSerie serie) {
		List<DatoSerieDocSoporte> serieDocs = serie.getListSerieDocSoporte();
		Integer numsecdocum = 0;
		List<DatoDocAutorizante> list = new ArrayList<DatoDocAutorizante>();
		for (DatoSerieDocSoporte serieDoc : serieDocs) {
			if (Constants.COD_DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte()))
				numsecdocum = serieDoc.getNumiddocsoporte();
			if (numsecdocum != 0) {
				for (DatoDocAutorizante docAutorizante : dua.getListDocAutorizantes()) {
					if (numsecdocum.equals(docAutorizante.getNumsecdocum()))
						list.add(docAutorizante);
				}
			}
		}

		return list;
	}

	public void grabarBeneficiario(Declaracion declaracion) {
		if (declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals("4")) {// es
			// RUC
			// verificar que no existe en la tabla declaran antes de insertar
			// consulta ala tabla declaran

			if (!SunatStringUtils.isEmpty(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad())) {

				Declaran paramsDeclaran = new Declaran();
				paramsDeclaran.setCdocumen(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				paramsDeclaran.setCtipodoc("4");
				//List<Declaran> listDeclaran = FormatoAServiceImpl.getInstance().getDeclaranDAO().selectByMap(paramsDeclaran);

				List<Declaran> listDeclaran= (List<Declaran>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).selectByMapDeclaran(paramsDeclaran);

				boolean existeDeclarante = !CollectionUtils.isEmpty(listDeclaran);
				if (!existeDeclarante) {// se debe de insertar en la tabla
					DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
					// declaran el declarante
					pe.gob.sunat.despaduanero2.declaracion.model.Declaran record = new pe.gob.sunat.despaduanero2.declaracion.model.Declaran();

					//					Map mapDdp = FormatoBServiceImpl.getInstance().getDdpDAO().findByPK(
					//							declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					//					String Direccion = FormatoBServiceImpl.getInstance().getDdpDAO().getDomicilioLegal(
					//							declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());

					Map mapDdp = ddpDAOService.findByPK(
							declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
					String Direccion = ddpDAOService.getDomicilioLegal(
							declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());

					if (mapDdp != null) {

						record.setCdocumen(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
						record.setCtipodoc("4");
						record.setDnombre((String) mapDdp.get("ddp_estado"));
						record.setDdirecc(Direccion);
						record.setCusuario("SEIDA");
						record.setCadu(declaracion.getDua().getCodaduanaorden());
						record.setFing(SunatDateUtils.getCurrentIntegerDate());
						record.setFfin(99991231);
						// record.setFlag((String)mapDdp.get("ddp_flag22").toString().substring(0,
						// 1));
						record.setCregimen(declaracion.getDua().getCodregimen());

						//FormatoBServiceImpl.getInstance().getDeclaranDAO().insert(record);
						((DeclaranDAO)fabricaDeServicios.getService("declaranDAO")).insert(record);
					}
				}

			}
		}

	}

	//	public ComunicacionService getComunicacionService() {
	//		return comunicacionService;
	//	}
	//
	//	public void setComunicacionService(ComunicacionService comunicacionService) {
	//		this.comunicacionService = comunicacionService;
	//	}
	/*
	public Datado2Service getDatado2Service() {
		return datado2Service;
	}

	public void setDatado2Service(Datado2Service datado2Service) {
		this.datado2Service = datado2Service;
	}*/

	/*branch ingreso 2011-009 hosorio 09/08/2011 inicio */
	//MATC 20130114 - Se aument� el par�metro tipoDeuda, para identificar si se desafecta una DUA o una LC
	// RIN15 - se publico el servicio
	public String desafectaGarantiaDocumento(String RUCImport, String tipoExtincion ,String numRef,BigDecimal nTipoCamnio, DUA dua,  String cda, 
			BigDecimal monto, String moneda, String tipoDeuda,Map<String, Object> variablesIngreso) {


		Date fechaActual= new Date();
		Map params = new HashMap();
		params.put("cRUC", RUCImport); // RUC del beneficiario
		//MATC 20130327 - Cuando es L/C y tipo de extincion autocancelacion, se debe cambiar por legajamiento de L/C
		params.put("cTIPOEXTIN", (tipoDeuda.equals("LC") && tipoExtincion.equals("16") ? "06": tipoExtincion)); 
		params.put("cADUANA", dua.getCodaduanaorden());
		params.put("cANO", dua.getAnnpresen().toString().substring(2, 4));
		params.put("cREGIMEN", (tipoDeuda.equals("LC")?"96": dua.getCodregimen()));
		if( tipoDeuda.equals("LC") ) {
			params.put("cNUMERO", ( numRef.length()>7 ? numRef.substring(7) : " "));
		}
		else {
			params.put("cNUMERO", Cadena.padLeft(dua.getNumdocumento().trim(), 6, '0'));
		}
		params.put("cCDA", cda);
		params.put("nMONTOA", monto); 
		params.put("cMONEDAA", moneda);
		params.put("nTIPOCAM", nTipoCamnio);
		params.put("nFECHA", SunatDateUtils.getCurrentIntegerDate());
		params.put("cDOCUMENTO",numRef);
		params.put("cTRANS", " ");
		//String resultado=(String) NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarDesafectarGarantia(params);
		//String resultado=(String) ((PagarantiaDAO)fabricaDeServicios.getService("parantiaDAO")).procesarDesafectarGarantia(params);
		// RIN15 se cambia "parantiaDAO" por "pagarantiaDAO"
		String resultado=(String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarDesafectarGarantia(params);

		// RIN15 Se comenta el registro en LogRegiParams
		//DZC - Graba en LogRegi  
		Map LogRegiparams = new HashMap();
		LogRegiparams.put("regimen",dua.getCodregimen());
		LogRegiparams.put("codi_aduan",dua.getCodaduanaorden());
		LogRegiparams.put("nume_corre",dua.getNumdocumento().trim()); 
		LogRegiparams.put("fech_error",SunatDateUtils.getCurrentIntegerDate());
		LogRegiparams.put("cod_usumodif","");
		LogRegiparams.put("respuesta",resultado);
		LogRegiparams.put("funcion","PAGARANTIA.fnDesafectactacte");
		LogRegiparams.put("modulo","GrabarGeneralServiceImpl#desafectaGarantiaDocumento()");
		LogRegiparams.put("tipo",(String)variablesIngreso.get("codTransaccion"));
		LogRegiparams.put("ano_prese", (String)SunatStringUtils.toStringObj((Integer) variablesIngreso.get("annEnvio")));
		LogRegiparams.put("nume_orden",(String)SunatStringUtils.toStringObj((Long) variablesIngreso.get("numEnvio")));

		params.put("nMONTO", params.get("nMONTOA")); 
		params.put("cMONEDA", params.get("cMONEDAA"));
		// RIN 10-En la afectacion fue comentado por inconvenientes metodo
		// logRegiService.grabaLogGarantia(LogRegiparams,params);  
		// DZC -Fin
		return resultado;
	}


	/**
	 * Actualizamos fecha de regularizacion de corresponder
	 */
	public void grabaFechaVencRegularizacion (DUA dua) {
		CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
		Date fecVencRegula = null;
		boolean requiereRegularizacion = !CollectionUtils.isEmpty(getListIndicadorByTipo(dua, ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION));
		// si presenta el indicador 03 del art 199
		if (dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) ||
				(dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) &&  requiereRegularizacion)) {
			Date fechaReferencia =  dua.getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( fechaReferencia!=null && !SunatDateUtils.sonIguales(fechaReferencia, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) {
				ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
				//fechaReferencia = dua.getFecLlegada(); RIN 16 NO SE TOMA FECHA DE LLEGADA PARA CALCULAR FEC_VENCEREGUL SOLO FEC_DESCARGA
				//PAS20145E220000090 - MATC 20140617  FINAL
				fecVencRegula = funcionesService.getFechaRegularizacion(dua, fechaReferencia);
				DUA duatmp = new DUA();
				DUACriteria duaCriteria = new DUACriteria();				
				duatmp.setFecvencregula(fecVencRegula);
				duaCriteria.createCriteria().andNumCorredocEqualTo(dua.getNumcorredoc());
				cabdeclaraDAO.updateByCriteriaSelective(duatmp, duaCriteria);
			}
		} 
	}

	/**
	 * 296 Actualizamos Ruc de resolucion liberatoria inicio
	 */

	public void actualizaRUCResolucionLiberatoria(Declaracion declaracion) {
		CatRefRucDAO catRefRucDAO = (CatRefRucDAO)fabricaDeServicios.getService("grabar.catRefRucCentralizadaDAO");
		DUA dua=declaracion.getDua();

		boolean tieneIncentivosMigratorios=false;
		List<DatoSerie> series = declaracion.getDua().getListSeries();
		for(DatoSerie serie:dua.getListSeries()){
			if (serie.getCodliberatorio() != null) {
				if (SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()), new String[] { "4442", "4443", "4444" }))
				{
					tieneIncentivosMigratorios=true;
				}
			}

		}
		if (tieneIncentivosMigratorios==true) {
			String AnioResolucionLiberatoria="";
			String NumeroResolucionLiberatoria="";
			if (dua.getListOtrosDocSoporte() != null && !dua.getListOtrosDocSoporte().isEmpty()) {
				for(DatoOtroDocSoporte doc : dua.getListOtrosDocSoporte()){
					if("I".equals(doc.getCodtipoproceso())&& "02".equals(doc.getCodtipodocasoc())){
						AnioResolucionLiberatoria=doc.getAnndocasoc().substring(0,4);
						NumeroResolucionLiberatoria=SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0');
					}
				}
			}

			if( !NumeroResolucionLiberatoria.isEmpty()) {
				Participante partic=dua.getDeclarante();
				DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
				String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
				String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
				String baseLegal="";
				String baseLegalcad="";

				Map<String,String> mapaDatos=new HashMap<String,String>();
				mapaDatos.put("ctipoUso", "IM");  
				mapaDatos.put("tbaseLegal_like", AnioResolucionLiberatoria + "-" + NumeroResolucionLiberatoria);	
				List<Map<String, Object>> ListaCatRefRuc = catRefRucDAO.findByMap(mapaDatos);  
				if( ListaCatRefRuc.size()>0 ) { 
					Map<String, Object> MapaCatRefRuc = ListaCatRefRuc.get(0); 
					baseLegal = MapaCatRefRuc.get("tbaseLegal").toString();
					baseLegalcad = MapaCatRefRuc.get("tbaseLegal").toString().substring(23,34);
					//tbaseLegal=catRefRuc.getTbaseLegal("tbase_legal");	
				}
				if (baseLegalcad.equals("00000000000")) {	
					String ruc=dua.getDeclarante().getNumeroDocumentoIdentidad();
					String tipoDoc=dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
					if("4".equals(tipoDoc)){//Pase 153
						baseLegal=baseLegal.replace(baseLegalcad, ruc); 
						mapaDatos.put("tipoUso", "IM");
						mapaDatos.put("baselegal_like", AnioResolucionLiberatoria.concat("-").concat(NumeroResolucionLiberatoria) );
						mapaDatos.put("tbaseLegal",baseLegal);
						int res = catRefRucDAO.update(mapaDatos);
					}

				}
			}
			//Bloque Csantillan
			Map<String,Object> mapUsoMaxpl=new HashMap<String, Object>();
			Integer fechaNueva = SunatDateUtils.getCurrentIntegerDate();
			mapUsoMaxpl.put("codTipoDoc", declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			mapUsoMaxpl.put("numDocumen", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			mapUsoMaxpl.put("fecPrimerReg", fechaNueva);
			mapUsoMaxpl.put("fecUltimoReg", fechaNueva);
			for(DatoSerie serie:dua.getListSeries()){
				if (SunatStringUtils.isEqualTo(String.valueOf(serie.getCodliberatorio()),"4444")){
					if (dua.getCodIndicaUsoMaxpl()=="I"){
						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4444());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_insert(mapUsoMaxpl);						
						}					
					if (dua.getCodIndicaUsoMaxpl()=="U"){
						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4444());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_update(mapUsoMaxpl);						
						}	
				}
				
				if (SunatStringUtils.isEqualTo(String.valueOf(serie.getCodliberatorio()),"4442")){
					if (dua.getCodIndicaUsoMaxpl()=="I"){

						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4442());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_insert(mapUsoMaxpl);						
						}
					if (dua.getCodIndicaUsoMaxpl()=="U"){
						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4442());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_update(mapUsoMaxpl);
						}	
				}

				if (SunatStringUtils.isEqualTo(String.valueOf(serie.getCodliberatorio()),"4443")){
					mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4443());
					if (dua.getCodIndicaUsoMaxpl()=="I"){

						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4443());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_insert(mapUsoMaxpl);						
						}
					
					if (dua.getCodIndicaUsoMaxpl()=="U"){
						mapUsoMaxpl.put("codLibera", declaracion.getDua().getListSeries().get(0).getCodliberatorio()
								.toString());
						mapUsoMaxpl.put("mtoTotalDecla",declaracion.getDua().getMontoAcumulado4443());
						//indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
						catRefRucDAO.usomaxpl_update(mapUsoMaxpl);						
						}
				}				
			}


			
			//Bloque Csantillan FIN	
		}//Fin tieneIncentivosMigratorios==true

	}
	/**
	 * 296 Actualizamos Ruc de resolucion liberatoria fin
	 */
	/*
	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}


	public LogRegiService getLogRegiService() {
		return logRegiService;
	}

	public void setLogRegiService(LogRegiService logRegiService) {
		this.logRegiService = logRegiService;
	}

	public CatRefRucDAO getCatRefRucDAO() {
		return catRefRucDAO;
	}

	public void setCatRefRucDAO(CatRefRucDAO catRefRucDAO) {
		this.catRefRucDAO = catRefRucDAO;
	}

	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}