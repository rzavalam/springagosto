/*
 * Clase que define el servicio de validaciones de 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMedioTransporte;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * @deprecated Esta clase invoca a validacion de atributos de DatoMedioTransporte que no se cargan de informacion
 * The Class ValMTrans. 
 */
public class ValMTransServiceImpl extends ValDuaAbstract implements ValMTrans {
	
	//private FabricaDeServicios fabricaDeServicios;
	
	/**
	 * Valida que el campo numsecuTransporte de los elementos de la lista sean secuenciales de 1 a n.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param listDatoMedioTransporte Elementos<DatoMedioTransporte>
	 * @return Map
	 */
	public Map<String, String> numsecuTransporte(Elementos<DatoMedioTransporte> listDatoMedioTransporte){
		int i=1;
		boolean secuencial=false;
		for(DatoMedioTransporte medio:listDatoMedioTransporte){
			secuencial= (i==medio.getNumsecuTransporte().intValue());
			i++;
			if (!secuencial)
				break;
		}
		return secuencial?null:getDUAError("30018","");
	}

	/**
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nommedtransp String
	 * @return Map
	 */
	public Map<String, String> nommedtransp(String nommedtransp){
		return (!SunatStringUtils.isEmptyTrim(nommedtransp) && nommedtransp.trim().length()>=5)?null:getDUAError("30311","");
	}

	/**
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codnactransp String
	 * @return Map
	 */
	public Map<String, String> codnactransp(String codnactransp){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codnactransp))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codnactransp, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30312","Error catalogo codnactransp");
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
