package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas;


import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.anillos.model.Anillo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoPlasticoSintetico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoTextil;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreCremallera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoCDRom;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoCPU;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoComputadora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoDiscoDuro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoDisquetera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoImpresora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMemoria;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMonitor;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMouse;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoProcesador;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoScanner;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoTarjetaMadre;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoTarjetaRed;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoTarjetaSonido;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoTarjetaVideo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoTeclado;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoVentilador;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoZipDriver;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.domesticos.model.ArticuloDomestico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.juguetes.model.Juguete;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.laminas.model.Lamina;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesContacto;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesGafa;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.maletas.model.Maleta;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.neumaticos.model.Neumatico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.pilas.model.Pila;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproCasetteAudio;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproCasetteVHS;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproControlador;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproDiscoOptico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproDuplicadora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproEstucheDisco;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproTorre;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilFibra;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilHilado;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilPrenda;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilTela;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesEscritorio;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils; 
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

import java.util.Date;

public class ValidadorFactory extends IngresoAbstractServiceImpl
{

  //private FabricaDeServicios fabricaDeServicios;

  public ValidadorAbstract crearValidadorDescrMinima(ModelAbstract objeto)
  {


    CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");


    Date fechaControlVersionValidador = (Date) catalogoAyudaService.getElementoCat("380", "0025").get("fec_inidatcat");

    //PAS20175E220200079 solo ceramicos y laminas
    Date fechaControlCambiosVersionValidador = (Date) catalogoAyudaService.getElementoCat("380", "0032").get("fec_inidatcat");
    
    // PAS20191U220500021 S�lo para veh�culos
    Date fechaControlCambiosVehiculos = (Date) catalogoAyudaService.getElementoCat("380", "0058").get("fec_inidatcat");
    
    String versionServicio = "";

    if (fechaControlVersionValidador!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(objeto.getFechaIniVigenciaValidador(), fechaControlVersionValidador, SunatDateUtils.COMPARA_SOLO_FECHA)){
      versionServicio = "2";
    }

    //PAS20175E220200079 solo ceramicos y laminas
    //si hubieran futuros Control de Cambios, considerar un catalogoasoc adicional
    if (fechaControlCambiosVersionValidador!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(objeto.getFechaIniVigenciaValidador(), fechaControlCambiosVersionValidador, SunatDateUtils.COMPARA_SOLO_FECHA)){
        if(objeto instanceof Lamina || objeto instanceof Ceramico){
        	versionServicio = "3";	
        }     	
    }
    
    // PAS20191U220500021 S�lo para veh�culos
    if (fechaControlCambiosVehiculos!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(objeto.getFechaIniVigenciaValidador(), fechaControlCambiosVehiculos, SunatDateUtils.COMPARA_SOLO_FECHA)){
        if(objeto instanceof Vehiculo){
        	versionServicio = "3";	
        }     	
    }
    
    ValidadorAbstract validador = null;


    if (objeto instanceof Vehiculo)
    {    	
    	validador = fabricaDeServicios.getService("ValidadorVehiculo"+versionServicio);    	 
    }
    else if (objeto instanceof Anillo)
    {
    	validador = fabricaDeServicios.getService("ValidadorAnillo"+versionServicio);
    }
    else if (objeto instanceof CalzadoCueroNatural)
    {
    	//no aplica versiones de validador PAS2016137 RF12
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorCalzadoCueroNatural"+versionServicio);
    }
    else if (objeto instanceof CalzadoOtros)
    {
    	//no aplica versiones de validador PAS2016137 RF12
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorCalzadoOtros"+versionServicio);
    }
    else if (objeto instanceof CalzadoPlasticoSintetico)
    {
      validador = fabricaDeServicios.getService("ValidadorCalzadoPlasticoSintetico"+versionServicio);
    }
    else if (objeto instanceof CalzadoTextil)
    {
    	//no aplica versiones de validador PAS2016137 RF12
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorCalzadoTextil"+versionServicio);
    }
    else if (objeto instanceof Ceramico)
    {
      validador =  fabricaDeServicios.getService("ValidadorCeramico"+versionServicio);
    }
    else if (objeto instanceof CierreCremallera)
    {
      validador =  fabricaDeServicios.getService("ValidadorCierreCremallera"+versionServicio);
    }
    else if (objeto instanceof CierreOtros)
    {
      validador =  fabricaDeServicios.getService("ValidadorCierreOtros"+versionServicio);
    }
    else if (objeto instanceof ComputoCDRom)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador = fabricaDeServicios.getService("ValidadorComputoCDRom"+versionServicio);
    }
    else if (objeto instanceof ComputoComputadora)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoComputadora"+versionServicio);
    }
    else if (objeto instanceof ComputoCPU)
    {    	
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoCPU"+versionServicio);
    }
    else if (objeto instanceof ComputoDiscoDuro)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoDiscoDuro"+versionServicio);
    }
    else if (objeto instanceof ComputoDisquetera)
    {
      validador =  fabricaDeServicios.getService("ValidadorComputoDisquetera"+versionServicio);
    }
    else if (objeto instanceof ComputoImpresora)
    {
    	validador =  fabricaDeServicios.getService("ValidadorComputoImpresora"+versionServicio);
    }
    else if (objeto instanceof ComputoMemoria)
    {
      validador =  fabricaDeServicios.getService("ValidadorComputoMemoria"+versionServicio);
    }
    else if (objeto instanceof ComputoMonitor)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoMonitor"+versionServicio);
    }
    else if (objeto instanceof ComputoMouse)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoMouse"+versionServicio);
    }
    else if (objeto instanceof ComputoProcesador)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoProcesador"+versionServicio);
    }
    else if (objeto instanceof ComputoScanner)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoScanner"+versionServicio);
    }
    else if (objeto instanceof ComputoTarjetaMadre)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoTarjetaMadre"+versionServicio);
    }
    else if (objeto instanceof ComputoTarjetaRed)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoTarjetaRed"+versionServicio);
    }
    else if (objeto instanceof ComputoTarjetaSonido)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoTarjetaSonido"+versionServicio);
    }
    else if (objeto instanceof ComputoTarjetaVideo)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoTarjetaVideo"+versionServicio);
    }
    else if (objeto instanceof ComputoTeclado)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoTeclado"+versionServicio);
    }
    else if (objeto instanceof ComputoVentilador)
    {
    	//no aplica versiones de validador PAS2016137 RF5
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorComputoVentilador"+versionServicio);
    }
    else if (objeto instanceof ComputoZipDriver)
    {
      validador =  fabricaDeServicios.getService("ValidadorComputoZipDriver"+versionServicio);
    }
    else if (objeto instanceof ArticuloDomestico)
    {
      validador =  fabricaDeServicios.getService("ValidadorArticuloDomestico"+versionServicio);
    }
    else if (objeto instanceof Juguete)
    {
      validador =  fabricaDeServicios.getService("ValidadorJuguete"+versionServicio);
    }
    else if (objeto instanceof Lamina)
    {
      validador = fabricaDeServicios.getService("ValidadorLamina"+versionServicio);
    }
    else if (objeto instanceof LentesContacto)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
      versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorLentesContacto"+versionServicio); 
    }
    else if (objeto instanceof LentesGafa)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
        versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorLentesGafa"+versionServicio);
    }
    else if (objeto instanceof LentesOtros)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
        versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorLentesOtros"+versionServicio);
    }
    else if (objeto instanceof Maleta)
    {
      validador =  fabricaDeServicios.getService("ValidadorMaleta"+versionServicio);
    }
    else if (objeto instanceof Neumatico)
    {
      validador =  fabricaDeServicios.getService("ValidadorNeumatico"+versionServicio);
    }
    else if (objeto instanceof Pila)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorPila"+versionServicio);
    }
    else if (objeto instanceof ReproCasetteAudio)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorReproCasetteAudio"+versionServicio);
    }
    else if (objeto instanceof ReproCasetteVHS)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador = fabricaDeServicios.getService("ValidadorReproCasetteVHS"+versionServicio);
    }
    else if (objeto instanceof ReproControlador)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorReproControlador"+versionServicio);
    }
    else if (objeto instanceof ReproDiscoOptico)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorReproDiscoOptico"+versionServicio);
    }
    else if (objeto instanceof ReproDuplicadora)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorReproDuplicadora"+versionServicio);
    }
    else if (objeto instanceof ReproEstucheDisco)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador = fabricaDeServicios.getService("ValidadorReproEstucheDisco"+versionServicio);
    }
    else if (objeto instanceof ReproTorre)
    {
    	//no aplica versiones de validador PAS2016137 RF4
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorReproTorre"+versionServicio);
    }
    else if (objeto instanceof TextilFibra)
    {
    	//no aplica versiones de validador PAS2016137 RF3
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorTextilFibra"+versionServicio);
    }
    else if (objeto instanceof TextilHilado)
    {
    	//no aplica versiones de validador PAS2016137 RF3
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorTextilHilado"+versionServicio);
    }
    else if (objeto instanceof TextilOtros)
    {
    	//no aplica versiones de validador PAS2016137 RF3
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorTextilOtros"+versionServicio);
    }
    else if (objeto instanceof TextilPrenda)
    {
      validador =  fabricaDeServicios.getService("ValidadorTextilPrenda"+versionServicio);
    }
    else if (objeto instanceof TextilTela)
    {
    	//no aplica versiones de validador PAS2016137 RF3
    	versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorTextilTela"+versionServicio);
    }
    else if (objeto instanceof SanitarioInodoro)
    {
      validador =  fabricaDeServicios.getService("ValidadorSanitarioInodoro"+versionServicio);
    }
    else if (objeto instanceof SanitarioOtros)
    {
      validador =  fabricaDeServicios.getService("ValidadorSanitarioOtros"+versionServicio);
    }
    else if (objeto instanceof UtilesEscritorio)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
        versionServicio="";
      validador =  fabricaDeServicios.getService("ValidadorUtilesEscritorio"+versionServicio);
    }
    else if (objeto instanceof UtilesOtros)
    {
    	//no aplica versiones de validador PAS2016137 no es parte del alcance
        versionServicio="";
        validador =  fabricaDeServicios.getService("ValidadorUtilesOtros"+versionServicio);
    }

    //amancilla sirve para las plantillas

    objeto.setVersionEstructuraDM(versionServicio);

    return validador;
  }

/*
  public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
    this.fabricaDeServicios = fabricaDeServicios;
  }
*/

}
