/*
 * Clase que define el servicio de validaciones generales sobre la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import com.sun.org.apache.xml.internal.serializer.utils.SystemIDResolver;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoContrato;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoTributosAutocalc;
import pe.gob.sunat.despaduanero2.declaracion.model.Decanti;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Tdmalcon;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DecantiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TdmalconDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

/**
 * The Class ValNegocAduahdr1FormA. Clase que define el servicio de validaciones generales sobre la DUA.
 */
public class ValNegocAduahdr1FormAServiceImpl extends ValDuaAbstract implements ValNegocAduahdr1FormA{
	private final static String TSOLAFO="tsolafo";
	private final static String SINDI_PAEL="05";
	//protected final Log log = LogFactory.getLog(getClass());
	
	//private AyudaService ayudaService;
	//private DdpDAOService ddpDAOService;
	//private PackageTD packageTD;
	
	//private SoporteService soporteService;
	//private TdmalconDAO tdmalconDAO;
	//private DecantiDAO decantiDAO;
	//private FabricaDeServicios fabricaDeServicios;
	
	//private final static String MODALIDAD="modalidad";
	//private boolean gblfce;
	//private int gntiporeci;
	//private String xjurisdicc;	
	
	/**
	 * Valiaciones generales sobre la DUA.
	 * 
	 * @param declaracion Declaracion
	 * @param tipoSender String
	 * @param codTransaccion String
	 * @param numOrden String
	 * @param annEnvio String
	 * @return el list
	 */
	public List<Map<String, String>> valAduahdr1(Declaracion declaracion, String tipoSender, String codTransaccion, String numOrden, String annEnvio){
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		String[] tipoDespaNoMandatorio={"1002","2002","2102"};
		DUA dua=declaracion.getDua();
		
		String pcodiagent=tipoSender;

		String xcodi_aduan=dua.getCodaduanaorden();
		String caduana=dua.getCodaduanaorden();
		String xcodi_regi=dua.getCodregimen();
		String xano_prese=annEnvio;
		String xtipo_despa=dua.getCodmodalidad();		
		String xcdurge=dua.getCodprodurgente();
		Date vfechingsi=SunatDateUtils.getCurrentDate(); 
		int resulVal=0;

		boolean gblfce=false;
		//SPTD_ADUAHDR1 1-3
		if ("10".equals(xcodi_regi) && "10".equals(xtipo_despa)){
			gblfce=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000007", SunatDateUtils.getCurrentDate())>0;
		}
		//SPTD_ADUAHDR1 16	
		Participante declarante=dua.getDeclarante();
		veriError(listError,"27",declarante.getTipoDocumentoIdentidad().getCodDatacat(),"0009"," ","TIPO_DOCUM");
		valDeclarante(listError, SunatDateUtils.getCurrentIntegerDate(), declarante);
		//SPTD_ADUAHDR1 19
		if (!SunatStringUtils.include(codTransaccion, tipoDespaNoMandatorio)){
			if (!"00".equals(xtipo_despa) && !"01".equals(xtipo_despa) && !"10".equals(xtipo_despa) && !"11".equals(xtipo_despa)){
				if (!"02".equals(xtipo_despa) && !"05".equals(xtipo_despa)){
					listError.add(getDUAError("0041","TIPO_DESPA - TRANSMITIO :"+xtipo_despa));
				}
			}
		}
		/*
		 * SPTD_ADUAHDR1
		 */
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		Integer cambioVigente=packageTD.getCambioVigente("DI02",new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		if ("01".equals(xtipo_despa) && cambioVigente==1){
			DatoManifiesto manifiesto=dua.getManifiesto();
			//DatoManifiesto manif=declaracion.getDua().getManifiesto();
			Date xfech_termi=manifiesto!=null?manifiesto.getFectermino():null;
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( xfech_termi!=null && SunatDateUtils.sonIguales(xfech_termi, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				xfech_termi = dua.getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
			
			if (SunatDateUtils.addDay(xfech_termi,7).compareTo(vfechingsi)<0){
				listError.add(getDUAError("1234","El DESPACHO URGENTE SOLO PUEDE NUMERAR HASTA 7 DIAS DEPUES DEL ARRIBO DE LA MERCANCIA"));
			}
		}
			
		//SPTD_ADUAHDR1 23
		if (//"0".equals(pEmergencia) && 
			!("02".equals(xtipo_despa) || ("01".equals(xtipo_despa) && 
							("01".equals(xcdurge) || "A".equals(xcdurge) || "08".equals(xcdurge) || "G".equals(xcdurge))))){
			//24.	Se ejecuta el proceso sphaveau SPTD_ADUAHDR1
			this.valHaveau(listError);
		}
		//SPTD_ADUAHDR1 25 
		//SPTD_ADUAHDR1 25a
//		if ("10".equals(xcodi_regi) && "11".equals(xtipo_despa)){
			//verificar triblibe
			Elementos<DatoSerie> series=dua.getListSeries();
			for (DatoSerie serie:series){
				for(DatoContrato contrato:serie.getListContrato()){
					String xtipo_docum=contrato.getCodtipodocexpo();
					String xnume_docum=contrato.getNumrucdocexpo();
					//SPTD_ADUAHDR1 21
					if (("10".equals(xtipo_despa) && !gblfce) || (gblfce && "04".equals(dua.getCodlugarecepcion())/*"01".equals(xcdurge)*/)){
						//ejecutar spanticipado Tablas 
						valProcesoAnticipado(listError, xtipo_docum, xnume_docum, xtipo_despa);
					}					
				}
			}
			Elementos<DatoIndicadores> indicadores=dua.getListIndicadores();
			String xsindi_pael="";
			for (DatoIndicadores indicador:indicadores){
				if (SINDI_PAEL.equals(indicador.getCodtipoindica())){
					xsindi_pael=indicador.getValindicador();
				}
			}	
			DatoPago pago=dua.getPago();
			DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
			String xcbco_pael=decla!=null?decla.getCodbcopagoelec():null;
			String xccta_pael=decla!=null?decla.getNumctapagoelec():null;
			valVerictabco(listError, "15", xcbco_pael, xccta_pael, xsindi_pael, pcodiagent);
			//i.	Se ejecuta el proceso spverictabco ('15', xcbco_pael, xccta_pael)					
			
//		}
		String laduregpre="N";
		//Se verifica que exista un regimen precedente distinto de 12 o 13
		/*Elementos<DatoSerie>*/ series=dua.getListSeries();
		for(DatoSerie serie:series){
			Elementos<DatoRegPrecedencia> regimenes=serie.getListRegPrecedencia();
			for(DatoRegPrecedencia regimen:regimenes){
				if (SunatStringUtils.include(regimen.getCodregipre(), new String[]{"12","13"})){
					laduregpre="S";
					break;
				}
			}
			if ("S".equals(laduregpre))
				break;
		}
		DatoManifiesto manifiesto=dua.getManifiesto();
		//SPTD_ADUAHDR1 31 
		
		
		String xvia_transp=manifiesto!=null?manifiesto.getCodmodtransp():null;
		String xcadu_manif=manifiesto!=null?manifiesto.getCodaduamanif():null;
		veriError(listError,"10",xvia_transp,"0013"," ","VIA_TRANS");
		//SPTD_ADUAHDR1 33
		if (validaViaTrans(xvia_transp, xcadu_manif, SunatDateUtils.getCurrentFormatDate("yyyyMMdd"))!='C'){
			listError.add(getDUAError("0013","VIA_TRANSP - EN LA ADUANA MANIFIESTO "+xcadu_manif+" NO EXISTE VIA DE TRANSPORTE "+xvia_transp));
		}
		//SPTD_ADUAHDR1 35-36
		if ("5".equals(xvia_transp) && "10".equals(xcodi_regi) && "235".equals(xcodi_aduan)){
			listError.add(getDUAError("0013","VIA_TRANSP - TRANSMITIO "+xvia_transp));
		}
		//SPTD_ADUAHDR1 38-42
		Elementos<DatoEquipamiento> equipamientos=null;
		if(manifiesto!=null) 
			equipamientos=manifiesto.getListEquipamientos();
		Participante empresa=manifiesto!=null?manifiesto.getEmpTransporte():null;
		
		String numeroDocumentoIdentidad=empresa!=null?empresa.getNumeroDocumentoIdentidad():null;
		
		String xempr_trans=numeroDocumentoIdentidad;
		if (existeRegPrecedencia(dua.getListSeries())){
			if ("4".equals(xvia_transp)){
				veriError(listError,"47",xempr_trans,"0012"," ","EMPR_TRANS");
			}
			if (gblfce && "ZZ".equals(xempr_trans)){
				listError.add(getDUAError("0012","EMPR_TRANS: ZZ. SOLO SE ACEPTA TRANSPORTISTAS REGULARES PARA SADA"));
			}
		}else{
			if ("1".equals(xvia_transp)){
				//DatoManifiesto manif=declaracion.getDua().getManifiesto();
				Date nfech_termi=manifiesto!=null?manifiesto.getFectermino():null;
				//PAS20145E220000090 - MATC 20140617  INICIO
				if( nfech_termi!=null && SunatDateUtils.sonIguales(nfech_termi, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
					nfech_termi = declaracion.getDua().getFecLlegada();
				}
				//PAS20145E220000090 - MATC 20140617  FINAL
				
				if ("S".equals(laduregpre)){
					resulVal=packageTD.getCountInAgeMar(xempr_trans, xcadu_manif, nfech_termi);
				}else{
					resulVal=packageTD.getCountInAgeMar(xempr_trans, caduana, nfech_termi);
				}
				if (resulVal==0)
					listError.add(getDUAError("0012","EMPR_TRANS - TRANSMITIO... "+xempr_trans));
			}
		}
		//SPTD_ADUAHDR1 43
		if (!"S".equals(laduregpre) && "7".equals(xvia_transp)){
			if (packageTD.getCountInEmpreDTN(xempr_trans, caduana)==0)
				listError.add(getDUAError("0012","EMPR_TRANS - TRANSMITIO..."+xempr_trans));
		}
		

		//SPTD_ADUAHDR1 55
		if (!SunatDateUtils.getCurrentFormatDate("yyyy").equals(xano_prese)){
			listError.add(getDUAError("0006","ANO_PRESE - ANHO DE PRESENTACION DIFIERE DEL ANHO ACTUAL "+xano_prese));
		}
		/*DatoPago*/ pago=dua.getPago();	
		DatoPagoTrans trans=pago!=null?pago.getPagoTransaccion():null;	
		String xform_pagox=trans!=null?trans.getCodmodpago():null;
		String xcodi_enfin=trans!=null?trans.getCodentipago():null; 
		Integer xplaz_credi= trans!=null?trans.getNumplazcredito():null;
		Date xfech_carcr= trans!=null?trans.getFeccarcr():null;
		if ("1".equals(xform_pagox) && !SunatStringUtils.isEmptyTrim(xcodi_enfin)){
			listError.add(getDUAError("0134","FORM_PAGOX, CODI_ENFIN - NO HAY CONGRUENCIA TRANSMITIO : "+ xform_pagox + "-"+ xcodi_enfin));
		}else{
			
		}
		//SPTD_ADUAHDR1 57
		veriError(listError,"11",xform_pagox,"0022"," ","FORM_PAGOX");
		//SPTD_ADUAHDR1 60
		if ((xplaz_credi<0 || xplaz_credi>999) && xfech_carcr!=null)
			listError.add(getDUAError("0024","PLAZ_CREDI - TRANSMITIO "+xplaz_credi.intValue()));
		/*Elementos<DatoIndicadores>*/ indicadores=dua.getListIndicadores();
		
		List<Map<String,String>> listIndicadores=new ArrayList<Map<String,String>>();
		String codTsolafo="";
		for (Map<String,String> map:listIndicadores){
			if (TSOLAFO.equals(map.get("des_datacat")))
				codTsolafo=map.get("cod_datacat");
		}
		for (DatoIndicadores indicador:indicadores){
			if(indicador.getCodtipoindica().equals(codTsolafo)){
				if (!SunatStringUtils.include(indicador.getValindicador(),new String[]{"","0"}))
					listError.add(getDUAError("0197","TSOLAFO - '+ 'SOLICITUD DE AFORO PUEDE SER: 0 TRANSMITIO : "+indicador.getValindicador()));
			}
		}
		
		//SPTD_ADUAHDR1 79-80
		if (xcdurge!=null && !SunatStringUtils.include(xtipo_despa, new String[]{"01","02"})){
			if (!"10".equals(xtipo_despa) || !SunatStringUtils.include(xcdurge, new String[]{"01","02","03"}))
				listError.add(getDUAError("0041","CDURGE = "+ xcdurge.trim() + " NO ES VALIDO PARA TIPO DE DESPACHO= "+ xtipo_despa));
		}
		//SPTD_ADUAHDR1 81-92
		Elementos<DatoTributosAutocalc> tributados=dua.getListTributosAutocalculados();
		String[] codError=new String[]{"5007", "5008", "5009", "5010", "5011", "5012", "5013", "5014", "5016", "5017", "5018"};
		List<Map<String, String>> tributos=new ArrayList<Map<String,String>>();
		for (DatoTributosAutocalc tributado:tributados){
			String codtributo=tributado.getCodtributo();
			BigDecimal monto=tributado.getMtovalortrib();
			int i=0;
			for(Map<String,String> tributo:tributos){
				if (((String)tributo.get("cod")).equals(codtributo)){
					if ( SunatNumberUtils.isLessThanZero(monto)){
						listError.add(getDUAError(codError[i++],(String)tributo.get("msje")));
						break;
					}
				}
			}
		}
		return listError;
	}

	//spanticipado
	/**
	 * Valida proceso anticipado.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param xtipo_docum String
	 * @param xnume_docum String
	 * @param xtipo_despa String
	 */
	private void valProcesoAnticipado(List<Map<String, String>> listError, String xtipo_docum, String xnume_docum, String xtipo_despa){
		//String rladuana;
		//String rlano;
		//String rlnroliq;
		//Integer rlfecliq;
		Map<String,Object> paramsTdmalcon=new HashMap<String,Object>();
		paramsTdmalcon.put("rltipdoc", xtipo_docum);
		paramsTdmalcon.put("rlibtri", xnume_docum);
		paramsTdmalcon.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
		paramsTdmalcon.put("frecla", 0);
		paramsTdmalcon.put("fanul", 0);
		paramsTdmalcon.put("fapel_resol", 0);
//		List<Tdmalcon> listTdmalcon=FormatoAServiceImpl.getInstance().getTdmalconDAO().findByMap(paramsTdmalcon);
		TdmalconDAO tdmalconDAO=  fabricaDeServicios.getService("TdmalconDAO");
		List<Tdmalcon> listTdmalcon=tdmalconDAO.findByMap(paramsTdmalcon);//gmontoya IoC
		/* HECHO
		 * 2.	SELECT rladuana, rlano, rlnroliq, rlfecliq FROM tdmalcon 
			3.	WHERE rltipdoc = xtipo_docum
			4.	AND rllibtri = xnume_docum
			5.	AND ndate BETWEEN fini y ffin
			6.	AND frecla = 0
			7.	AND fanul = 0
			8.	AND fapel_resol = 0
		 */
		if (listTdmalcon==null && !listTdmalcon.isEmpty()){
			for (Tdmalcon tdmalcon:listTdmalcon){
				listError.add(getDUAError("0151","TIPO_DESPA - LIQUIDACION : "+tdmalcon.getRladuana()+"-"+tdmalcon.getRlano()+"-"+tdmalcon.getRlnroliq()+"-"+tdmalcon.getRlfecliq()));
			}
		}else{
			listError.add(getDUAError("0142","IMPORTADOR NO PUEDE ACOGERSE A DESPACHO ANTICIPADO:  "+xtipo_docum));
		}
		if ("4".equals(xtipo_docum) && "20379822887".equals(xnume_docum)){
			listError.add(getDUAError("0142","IMPORTADOR NO PUEDE ACOGERSE A DESPACHO ANTICIPADO:  "+xtipo_docum+"-"+xnume_docum));
		}
		Map<String,Object> paramsDecanti=new HashMap<String, Object>();
		paramsDecanti.put("ctipodoc", xtipo_docum);
		paramsDecanti.put("cdocumen", xnume_docum);
		paramsDecanti.put("fechPride_>", 0);
		/* HECHO
		 * SELECT fech_pride, fusion  INTO xfechpride, xfusion  FROM decanti
			WHERE ctipodoc = xtipo_docum AND cdocumen = xnume_docum  AND  fech_pride>0
		 */
//		List<Decanti> listDecanti=FormatoAServiceImpl.getInstance().getDecantiDAO().findByMap(paramsDecanti);
		
		DecantiDAO decantiDAO=  fabricaDeServicios.getService("decantiDAO");
		List<Decanti> listDecanti=decantiDAO.findByMap(paramsDecanti);
		if(listDecanti!=null && !listDecanti.isEmpty()){
			Decanti decanti=listDecanti.get(0);
			String xfusion=decanti.getFusion();
			Integer xfechpride=decanti.getFechPride();
			FechaBean fb=new FechaBean(String.valueOf(xfechpride),"yyyyMMdd");
			Calendar cal = fb.getCalendar();
			cal.add(Calendar.YEAR, 1);
			if ("F".equals(xfusion) && Calendar.getInstance().compareTo(cal)<0){
				listError.add(getDUAError("0142","TIPO_DESPA, TIPO_DOCUM, NUME_DOCUM - FECHA "+ xfechpride.intValue() + " TRANSMITIO : "+ xtipo_despa+ ", "  + xtipo_docum + ", "  + xnume_docum ));
			}
		}
	}
	
	//sphaveau
	/**
	 * Val haveau.
	 * @deprecated Falta implementar consulta a tablas
	 * @param listError List<Map<String,String>>
	 */
	private void valHaveau(List<Map<String,String>> listError){
		List<Map<String,?>> listTabimpdu=new ArrayList<Map<String, ?>>();
		for(Map<String,?> mapTabimpdu:listTabimpdu){
			String error="";
			if ("T".equals(mapTabimpdu.get("flag_anul"))&& SunatStringUtils.include((String)mapTabimpdu.get("tipo_despa"),new String[]{"U","A"})){
				Map<String,?> mapDeclaracion=new HashMap<String,Object>();
				/*
				 * 		Se busca la Declaraci�n en base a los datos: rtab.codi_aduan, rtab.ano_prese, rtab.nume_corre y 
				 * 	se obtienen los siguientes datos: fech_ingsi, codi_agent, nume_orden y se almacena en las variables lnfechingsi, 
				 * 	lccodiagent, lcnumeorden.
				 */
				if (mapDeclaracion==null){
					error="No presento documentos";
				}else{
					Map<String,?> mapDirecep=new HashMap<String,Object>();
					/*
					 * SELECT fech_ingsi INTO lnfech FROM direcep
						WHERE fech_ingsi >= lnfechingsi  AND c_agente = lccodiagent AND n_orden = lcnumeorden AND tipo_trami IN ('42', '25')
					 */
					if (mapDirecep==null){
						error="No presento documentos";
					}
				}
				if (!"".equals(error)){
					int lnexpsusp=0;
					/*
					 * SELECT COUNT (*) INTO lnexpsusp FROM mov_estado
						WHERE codi_aduan = rtab.codi_aduan
						AND ano_prese = rtab.ano_prese
						AND codi_regi = '10'
						AND nume_corre = rtab.nume_corre
						AND cestado = 'S'
					 */
					if (lnexpsusp>0){
						/*
						 * SELECT COUNT (*) INTO lnexpsusp FROM expedi
							WHERE o_tipo = 17
							 AND o_anno = rtab.ano_prese
							 AND o_nro = rtab.nume_corre
							 AND codi_adua = rtab.codi_aduan
							 AND procedim = '1606'
						 */
						if (lnexpsusp>0){
							/*
							 * SELECT COUNT (*) INTO lnexpsusp FROM expedi
								WHERE o_tipo = 17
								 AND o_anno = rtab.ano_prese
								 	AND o_nro = rtab.nume_corre
								 	AND codi_adua = rtab.codi_aduan
								AND procedim = '1606'
								AND fech_conc > 0
								AND tipo_conc <> 5
							 */
							error=lnexpsusp>0?"Suspension no procede":"";
						}else{
							error="";
						}
					}
				}
			}else{
				if ("S".equals(mapTabimpdu.get("flag_anul"))&& SunatStringUtils.include((String)mapTabimpdu.get("tipo_despa"),new String[]{"U","A"})){
					int lnexpsusp=0;
					/*
					 * SELECT COUNT (*) INTO lnexpsusp FROM expedi
						WHERE o_tipo = 17
						 AND o_anno = rtab.ano_prese
						 AND o_nro = rtab.nume_corre
						 AND codi_adua = rtab.codi_aduan
						 AND procedim = '1606'
					 */
					if (lnexpsusp>0){
						/*
						 * SELECT COUNT (*) INTO lnexpsusp FROM expedi
							WHERE o_tipo = 17
							 AND o_anno = rtab.ano_prese
							 	AND o_nro = rtab.nume_corre
							 	AND codi_adua = rtab.codi_aduan
							AND procedim = '1606'
							AND fech_conc > 0
							AND tipo_conc <> 5
						 */
						if (lnexpsusp>0){
							error="Suspension no procede";
						}else{
							error="";
						}
					}else{
						error="..";
					}
				}else{
					Map<String,?> mapPolnoti=new HashMap<String,Object>();
					/*
					 * 	SELECT nume_corre INTO cnume_corre FROM polnoti
	                   WHERE nume_corre = rtab.nume_corre
	                     AND ano_prese = SUBSTR (rtab.ano_prese, 3, 2)
	                     AND codi_aduan = rtab.codi_aduan
	                     AND codi_regi = rtab.codi_regi
	                     AND tipo_docad = '02'
					 */
					if (mapPolnoti==null){
						error=".";
					}
				}
			}
			if (!"".equals(error)){
				char tipodespa=((String)mapTabimpdu.get("tipo_despa")).charAt(0);
				switch(tipodespa){
					case 'U':   listError.add(getDUAError("9031","TIPO_DESPA - DUA : "+mapTabimpdu.get("cdua")+"-"+error));	
								break;
					case 'A':   listError.add(getDUAError("9032","TIPO_DESPA - DUA : "+mapTabimpdu.get("cdua")+"-"+error));
								break;
					case 'P':	listError.add(getDUAError("4041","TIPO_DESPA - DUA : "+mapTabimpdu.get("cdua")+"-"+error));
								break;
				}
			}
			
		}
	}
	
	//spverictabco
	/**
	 * Val verictabco.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param ptipo String
	 * @param pcbco_pael String
	 * @param pccta_pael String
	 * @param xsindi_pael String
	 * @param pcodiagent String
	 */
	private void valVerictabco(List<Map<String,String>> listError, String ptipo, String pcbco_pael, String pccta_pael, String xsindi_pael, String pcodiagent){//String tabla, String codBanco, String ctaPago){
		
		if ("1".equals(xsindi_pael)){
			//-	fnverierror (Ptipo, pcbco_pael, '1911', ' ', 'CBCO_PAEL')
			veriError(listError,ptipo,pcbco_pael,"1911"," ","CBCO_PAEL");
			if (!SunatStringUtils.isNumeric(pccta_pael))
				listError.add(getDUAError("1900","CCTA_PAEL - NRO DE CUENTA INVALIDA. TRANSMITIO: " + pccta_pael ));
			Map<String,?> mapEbd1ctas=new HashMap<String,Object>();
			/*
			 * SELECT fco_nocta, ffe_invig, ffe_fivig, fco_usuar, fti_usuar
              INTO nrocta, dfinicio, dffin, codagen, tipusuar
              FROM ebd1ctas
             WHERE fco_nocta = SIN_ESPACIOS (pccta_pael) AND fco_banco = pcbco_pael
			 */
			if (mapEbd1ctas==null)
				listError.add(getDUAError("1900","CBCO_PAEL-CCTAPAEL - CODIGO DE BANCO Y NRO DE CUENTA NO EXISTE. TRANSMITIO: " + pcbco_pael + '-'+ pccta_pael ));
			else{
				FechaBean fbctas=new FechaBean();
				fbctas.setFecha((Date)mapEbd1ctas.get("ffe_fivig"));
				if (Calendar.getInstance().compareTo(fbctas.getCalendar())>0){
					listError.add(getDUAError("1905","CODIGO DE BANCO Y NRO DE CUENTA NO VIGENTE."));
				}
				if (!"01".equals(mapEbd1ctas.get("fti_usuar"))){
					if ("06".equals(mapEbd1ctas.get("fti_usuar"))){
						Map<String,?> mapEbd1agmp=new HashMap<String,Object>();
						/*
						 * SELECT ffe_invig, ffe_fivig  INTO dfinicio, dffin
                       FROM ebd1agmp
                      WHERE fco_nocta = SIN_ESPACIOS (pccta_pael)
                        AND fco_banco = pcbco_pael
                        AND fco_agent = pcodiagent
                        AND fco_impor = SIN_ESPACIOS (xnume_docum)
						 */
						if (mapEbd1agmp==null){
							listError.add(getDUAError("1902","CODIGO DE BANCO Y NRO DE CUENTA NO AUTORIZADA PARA LA AGENCIA POR EL IMPORTADOR"));
						}
						FechaBean fbagmp=new FechaBean();
						fbagmp.setFecha((Date)mapEbd1agmp.get("ffe_fivig"));
						if (Calendar.getInstance().compareTo(fbagmp.getCalendar())>0){
							listError.add(getDUAError("1905","CODIGO DE BANCO Y NRO DE CUENTA NO VIGENTE. : FIN DE VIGENCIA"+fbagmp.getFormatDate("dd/MM/yyyy")));
						}						
					}else{
						listError.add(getDUAError("1901","CODIGO DE BANCO Y NRO DE CUENTA NO CORRESPONDE AL AGENTE."));
					}
				}
				if (!pcodiagent.equals(mapEbd1ctas.get("fco_usuar"))){
					listError.add(getDUAError("1901","CODIGO DE BANCO Y NRO DE CUENTA NO CORRESPONDE AL AGENTE."));
				}
			}
			Map<String,?> mapCatHorban=new HashMap<String, Object>();
			/*
			 * 	Nrodia se carga con el n�mero de d�a de la semana (1: Domingo, 2: Lunes, etc)
				Se consulta en la tabla CAT_HORBAN:
					SELECT ndia_inicio INTO diaini
                 	FROM cat_horban
                	WHERE cbanco_pael = pcbco_pael
                  	AND nrodia BETWEEN ndia_inicio AND ndia_final
                  	AND nhora BETWEEN thora_inicio AND thora_final
			 */
			if (mapCatHorban==null){
				listError.add(getDUAError("1905","FUERA DE HORARIO DEL BANCO "+ pcbco_pael+ " PARA PAGO ELECTRONICO DE SAP"));	
			}
		}else{
			if ("0".equals(xsindi_pael)){
				if (!SunatStringUtils.isEmptyTrim(pcbco_pael)){
					listError.add(getDUAError("1911","CBCO_PAEL - CODIGO DE BANCO DEBE ENVIARSE VACIO. TRANSMITIO: "+pcbco_pael));
				}
				if (!SunatStringUtils.isEmptyTrim(pccta_pael)){
					listError.add(getDUAError("1900","CCTA_PAEL - NRO DE CUENTA DEBE ENVIARSE VACIA. TRANSMITIO: "+pccta_pael));
				}
			}else{
				listError.add(getDUAError("5020","SINDI_PAEL - INDICADOR DE PAGO ELECTRONICO INVALIDO. TRANSMITIO: "+xsindi_pael));
			}
		}
	}
	
	/**
	 * Valida los datos del declarante de la DUA
	 * 
	 * @param listError List<Map<String,String>>
	 * @param vfechingsi Integer
	 * @param declarante Participante
	 * @return el mapa de errores
	 */
	public Map<String,Object> valDeclarante(List<Map<String,String>> listError, Integer vfechingsi, Participante declarante){
		DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		Participante partic=declarante;
		DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
		//DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
		//String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;
		Map<String,Object> mapDdp=null;
		String nomb_ddp = null;
		String dir_ddp = null;
		Date fecnac_pernat = null;
		String dni_pernat = null;
		boolean grabarDeclaran=false;
		boolean actualizarDeclaran = false;
		boolean condicionValida=true;
		Map<String,Object> mapRpta=new HashMap<String,Object>();
		String xtipo_docum=codTipoDocumento;
		String xnume_docum=numeroDocumentoIdentidad;
		String lcerror="";
		String derror="";
		if (packageTD.getCambioVigente("TD02",vfechingsi)!=0){
			lcerror="1098";
		}else{
			lcerror="9098";
		}
		
//		Map<String,Object> mapDeclaran=new HashMap<String,Object>();
//		mapDeclaran.put("cdocumen", xnume_docum);
//		mapDeclaran.put("ctipodoc", xtipo_docum);
		Declaran paramsDeclaran=new Declaran();
		paramsDeclaran.setCdocumen(xnume_docum);
		paramsDeclaran.setCtipodoc(xtipo_docum);
		
		//List<Declaran> listDeclaran=FormatoAServiceImpl.getInstance().getDeclaranDAO().selectByMap(paramsDeclaran);
		
		List<Declaran> listDeclaran= new ArrayList();
		listDeclaran= (List<Declaran>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).selectByMapDeclaran(paramsDeclaran);
		
		/*
		 * SELECT DNOMBRE INTO xdnombre FROM DECLARAN WHERE CTIPODOC = xtipo_docum AND CDOCUMEN = xnume_docum
		 */
		if (listDeclaran==null || listDeclaran.isEmpty()){
			if (SunatStringUtils.isEmptyTrim(declarante.getNombreRazonSocial()) /*|| declarante.getNombre().trim().length()<4*/){
				derror="NOMB_IMPOR -  LONGITUD DEL NOMBRE/RAZON SOCIAL DE IMPORTADOR/EXP/PERSONA NATURAL NO VALIDA :"+declarante.getNombreRazonSocial();
				
				//lmvr : RN 136
				if (!"4".equals(xtipo_docum)) {
					
					if("8".equals(xtipo_docum)){
						//lmvr -RN 134
						listError.add(getDUAError("30570",new Object[]{declarante.getNombreRazonSocial()}));
					}else{
						listError.add(getDUAError("30567",new Object[]{declarante.getNombreRazonSocial()}));
					}
				
				}else{
				listError.add(getDUAError("30433","NUEVO DECLARANTE DEBE TRANSMITIR NOMBRE"));
			}
				
			}
			if (SunatStringUtils.isEmptyTrim(declarante.getDireccion()) /*|| declarante.getDireccion().trim().length()<6*/){
				derror="DIRE_IMPO -  LONGITUD DE LA DIRECCION DE IMPORTADOR/EXP/PERSONA NATURAL NO VALIDA :"+declarante.getDireccion();
				
				//lmvr : RN 136
				if (!"4".equals(xtipo_docum)) {
				listError.add(getDUAError("30569",new Object[]{declarante.getDireccion()}));
				}else{
				listError.add(getDUAError("30434","NUEVO DECLARANTE DEBE TRANSMITIR DIRECCION"));
			}
						
				
			}
			if ("4".equals(xtipo_docum) && "".equals(derror)){				
				if (SunatStringUtils.isEmptyTrim(xnume_docum))
					derror="NUME_DOCUM - LONGITUD DE RUC INVALIDO";
				if (!PackageGeneral.esRuc(xnume_docum))
					derror="NUME_DOCUM - DOCUMENTO NO VERIFICADO COMO RUC "+ xtipo_docum+ "-"+ xnume_docum;
				String lcvigconruc=packageTD.functionDeclaVig(xnume_docum, "2", "4");
				if (!SunatStringUtils.isEmpty(lcvigconruc)){
					if (!SunatStringUtils.include(lcvigconruc.substring(0, 2),new String[]{"00","21"})){
						listError.add(getDUAError("0716","TIPO_DOCUM-NUME_DOCUM-VIGENCIA "+ xtipo_docum+ '-' + xnume_docum+ "-"+0));
						condicionValida=false;
					}
					if(lcvigconruc.length()>2 && !(lcvigconruc.length()<4)){
						if ("12".equals(lcvigconruc.substring(2, 4))){
							//listError.add(getDUAError("0716","LIBR_TRIBU.Condicion del domicilio: " + lcvigconruc.substring(2,4) + " "));
							listError.add(getDUAError("30742",new Object[]{xnume_docum}));
							condicionValida=false;
						}
					}
//					mapDdp=FormatoAServiceImpl.getInstance().getDdpDAO().findByPKDirecc(xnume_docum);
					mapDdp=ddpDAOService.findByPKDirecc(xnume_docum);
					
					if (mapDdp!=null){
//						mapDdp.put("direccion", FormatoAServiceImpl.getInstance().getDdpDAO().getDomicilioLegal(numeroDocumentoIdentidad));
						mapDdp.put("direccion", ddpDAOService.getDomicilioLegal(numeroDocumentoIdentidad));
						
						if ("".equals(derror) && condicionValida){
							String direccion=(String)mapDdp.get("direccion");
							String nombre=(String)mapDdp.get("ddp_nombre");
							if (SunatStringUtils.length(nombre)>100)
								nombre=nombre.substring(0, 100);
							if (!SunatStringUtils.isEmptyTrim(nombre))
								nombre=nombre.trim();
							if (!SunatStringUtils.isEmptyTrim(direccion))
								direccion=direccion.trim();
							if (SunatStringUtils.length(direccion)>60)
								direccion=direccion.substring(0, 60);							
							
							//PAS20175E220200006 INC 2017-003474 se retiran los caracteres especiales para la validaci�n de la raz�n social
							if (!SunatStringUtils.isEqualTo(SunatStringUtils.quitarCaracteresEspeciales(declarante.getNombreRazonSocial().trim()), 
									SunatStringUtils.quitarCaracteresEspeciales(nombre.trim()))){
								listError.add(getDUAError("30430",new Object[]{declarante.getNombreRazonSocial(),nombre}));
							}
							//PAS20175E220200006 INC 2017-003474 se retiran los caracteres especiales para la validaci�n de la raz�n social
							
							if (!SunatStringUtils.isEqualTo(declarante.getDireccion().trim(), direccion.trim())){
								listError.add(getDUAError("30431",new Object[]{declarante.getDireccion(),direccion}));
							}
						}
					}
					grabarDeclaran=true;
				}else{
					derror="RUC NO SE ENCUENTRA EN DDP";
					//lmvr : RN 132
					listError.add(getDUAError("30568",new Object[]{declarante.getNumeroDocumentoIdentidad(),xnume_docum}));					
				}
				
			}else{
				if (SunatStringUtils.include(xtipo_docum,new String[]{"2","3"})){
					//lmvr-RN 133
					if (SunatStringUtils.isEmptyTrim(xnume_docum) || xnume_docum.length()<8 || !SunatStringUtils.isNumeric(xnume_docum)){
						derror="NUME_DOCUM - LONGITUD DE LE/DNI INVALIDO :"+ xtipo_docum+ "-" + xnume_docum;
						//Map<String, Object> declaranpernat = RectificacionServiceImpl.getInstance().getSoporteService().obtenerPerNatJur(xtipo_docum, xnume_docum);
						Map<String, Object> declaranpernat = ((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur(xtipo_docum, xnume_docum);
						//if(declaranpernat==null || declaranpernat.isEmpty()){
							dni_pernat = declaranpernat.get("codigo").toString().trim();
							fecnac_pernat =(Date) declaranpernat.get("fechNac");
							if(dni_pernat==null || "".equals(dni_pernat) || fecnac_pernat == null ){
								//derror="NO EXISTE DNI: "+dni_pernat+"FECHA NACIMIENTO:: "+fecnac_pernat +"INPUT"+ xtipo_docum+ "-" + xnume_docum;
								listError.add(getDUAError("30572",new Object[]{declarante.getNumeroDocumentoIdentidad(),xnume_docum}));	
							}
						//}
					
					}else{
					//Map<String, Object> declaranpernat = RectificacionServiceImpl.getInstance().getSoporteService().obtenerPerNatJur(xtipo_docum, xnume_docum);
					Map<String, Object> declaranpernat = ((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur(xtipo_docum, xnume_docum);
					//if(declaranpernat==null || declaranpernat.isEmpty()){
						dni_pernat = declaranpernat.get("codigo").toString().trim();
						fecnac_pernat =(Date) declaranpernat.get("fechNac");				
						if(dni_pernat==null || "".equals(dni_pernat) || fecnac_pernat == null ){
							//derror="NO EXISTE DNI: "+dni_pernat+"FECHA NACIMIENTO:: "+fecnac_pernat +"INPUT"+ xtipo_docum+ "-" + xnume_docum;
							listError.add(getDUAError("30572",new Object[]{declarante.getNumeroDocumentoIdentidad(),xnume_docum}));	
				
						}else{
							Date fechaActual = new Date();
							long time = SunatDateUtils.getDifference(fechaActual, fecnac_pernat, Calendar.YEAR);
							if( time < 18){
								listError.add(getDUAError("30571",new Object[]{declarante.getNumeroDocumentoIdentidad(),xnume_docum}));	
							}
						}				
				 }
				}else if(SunatStringUtils.include(xtipo_docum,new String[]{"6","7"})){
					if (SunatStringUtils.isEmptyTrim(xnume_docum) || xnume_docum.length()<4 || xnume_docum.length()>11 || packageTD.validaNumLetCar(xnume_docum))
						derror="NUME_DOCUM - LONGITUD DE PASAPORTE/CARNET DE EXT. INVALIDO:"+ xtipo_docum+ "-" + xnume_docum;
				}else if(SunatStringUtils.include(xtipo_docum,new String[]{"5","8"})){
					if ("8".equals(xtipo_docum))
						derror="NUME_DOCUM - DOC. ORG.INTERNACIONAL NO VALIDO: "+ xtipo_docum+ "-"+ xnume_docum;
					if (SunatStringUtils.isEmptyTrim(xnume_docum) || xnume_docum.length()<4 || xnume_docum.length()>11)
						derror="NUME_DOCUM - LONGITUD DE PASAPORTE/CARNET DE EXT. INVALIDO: "+ xtipo_docum+ "-" + xnume_docum;
					
				}else
					derror="TIPO DE DOCUMENTO DE IDENTIDAD INVALIDO:  "+ xtipo_docum+ "-" + xnume_docum;
				if ("".equals(derror))
					grabarDeclaran=true;
			}
		}else{
			/**
			 * R2BZ El declaran podria estar desactualizado por lo cual deber�a validarse la razon social y direccion con respecto a la tabla ddp
			 * Lo que si hay que hacer es, verificar si realmente el declaran esta desactualizado.
			 */
			
//			Map<String, Object> declaranddp = RectificacionServiceImpl.getInstance().getSoporteService().obtenerPerNatJur(xtipo_docum, xnume_docum);
//			Map<String, Object> declaranddp = soporteService.obtenerPerNatJur(xtipo_docum, xnume_docum);
			Map<String, Object> declaranddp =((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur(xtipo_docum, xnume_docum);
			
			nomb_ddp = declaranddp.get("nombre").toString().trim();
			dir_ddp = declaranddp.get("direccion").toString().trim();
			
			Declaran declaran=listDeclaran.get(0);
			String nomb_impor=declarante.getNombreRazonSocial();
			String dir_impor=declarante.getDireccion();
			
			String nomb_decl=declaran.getDnombre()==null?" ":declaran.getDnombre().toString();
			String dir_decl=declaran.getDdirecc()==null?" ":declaran.getDdirecc().toString();
			
//			if (SunatStringUtils.isEmptyTrim(nomb_impor) || !SunatStringUtils.isEqualTo(nomb_impor,nomb_decl)){
//				listError.add(getDUAError("9002",nomb_decl));
//				if ("4".equals(xtipo_docum))
//					derror="NOMB_IMPOR ENVIADO:"+ nomb_impor+ "- ADUANAS:"+nomb_decl;
//				if ("8".equals(xtipo_docum))
//					listError.add(getDUAError("6095","NOMBRE DE CONSIGNATARIO NO COINCIDE CON SUNAT: "+nomb_decl));
				if (SunatStringUtils.length(nomb_ddp)>100) nomb_ddp=nomb_ddp.substring(0, 100);
				if (SunatStringUtils.length(nomb_decl)>100) nomb_decl=nomb_decl.substring(0, 100);
				if (SunatStringUtils.length(nomb_impor)>100) nomb_impor=nomb_impor.substring(0, 100);
				if (SunatStringUtils.length(dir_ddp)>60) dir_ddp=dir_ddp.substring(0, 60);
				if (SunatStringUtils.length(dir_decl)>60) dir_decl=dir_decl.substring(0, 60);
				if (SunatStringUtils.length(dir_impor)>60) dir_impor=dir_impor.substring(0, 60);
			
				if (!SunatStringUtils.isEmpty(nomb_impor) || nomb_impor != null){
					
					//PAS20175E220200006 INC 2017-003474 se retiran los caracteres especiales para la validaci�n de la raz�n social
					// Se verifica nuemvanente la actulizacion para ver que suceder.
					if (!SunatStringUtils.isEqualTo(SunatStringUtils.quitarCaracteresEspeciales(nomb_impor.trim()), 
							SunatStringUtils.quitarCaracteresEspeciales(nomb_ddp.trim()))){
					//if (!SunatStringUtils.isEqualTo(nomb_impor.trim(),nomb_ddp.trim())){
							if ("8".equals(xtipo_docum)){
								//lmvr -RN 134
								listError.add(getDUAError("30570",new Object[]{nomb_impor,nomb_ddp}));
							}else{
								
								if("3".equals(xtipo_docum)){
									listError.add(getDUAError("35263",new Object[]{nomb_impor,nomb_ddp}));
								}else{
									listError.add(getDUAError("30430",new Object[]{nomb_impor,nomb_ddp}));
								}
								
								
							}
	
						}
					}
				if (!SunatStringUtils.isEmpty(dir_impor) || dir_impor!=null ){
					if (!SunatStringUtils.isEqualTo(dir_impor.trim(),dir_ddp.trim()))
						listError.add(getDUAError("30431",new Object[]{dir_impor,dir_ddp}));
				}
				if ("4".equals(xtipo_docum)){
					String lcvigconruc=packageTD.functionDeclaVig(xnume_docum,"2","4");
					if (!SunatStringUtils.isEmpty(lcvigconruc)){
						if (!SunatStringUtils.include(lcvigconruc.substring(0,2),new String[]{"00","21"})){
							listError.add(getDUAError("0716","TIPO_DOCUM-NUME_DOCUM-VIGENCIA "+ xtipo_docum+ "-" + xnume_docum+ "- 0"));
						}
						if(lcvigconruc.length()>2 && !(lcvigconruc.length()<4)){
							//if (!"00".equals(lcvigconruc.substring(2,4))){
							if ("12".equals(lcvigconruc.substring(2,4))){
								listError.add(getDUAError(lcerror,"LIBR_TRIBU.Condicion del domicilio: " + lcvigconruc.substring(2,4)));
				
							}
						}
					}else{
						derror="RUC NO SE ENCUENTRA EN DDP";
					}
				}
				if ("8".equals(xtipo_docum)){
					/*
					 * SELECT A_CADENA(FFIN) INTO xFFin FROM DECLARAN WHERE CTIPODOC = xtipo_docum AND CDOCUMEN = xnume_docum
					 */
					if (declaran.getFfin().compareTo(vfechingsi)<0)
						listError.add(getDUAError("30797","TIPO_DOCUM-NUME_DOCUM-VIGENCIA " + xtipo_docum  + "-"+ xnume_docum + "-"  + declaran.getFfin().intValue()));
				}else{
					if ("7".equals(xtipo_docum) || "6".equals(xtipo_docum) ){
						if(SunatStringUtils.isEmptyTrim(nomb_impor)){
							listError.add(getDUAError("30567",new Object[]{declarante.getNombreRazonSocial()}));
						}
						
						
						if(SunatStringUtils.isEmptyTrim(dir_impor)){
							listError.add(getDUAError("30569",new Object[]{declarante.getDireccion()}));
						}
						
						
					}
				}
				
				if (!nomb_decl.trim().equals(nomb_ddp.trim()) || !dir_decl.trim().equals(dir_ddp.trim())){
					actualizarDeclaran = true;
				}
//			}
		}
		
		if (!"".equals(derror)){
			String param=xnume_docum;
			if(SunatStringUtils.isEmptyTrim(xnume_docum))
				param=Constants.MENSAJE_VACIO_NULO;
			//listError.add(getDUAError("0010",new Object[]{param}));
		}
		mapRpta.put("grabarDeclaran", grabarDeclaran);
		mapRpta.put("actualizarDeclaran", actualizarDeclaran);
		if (mapDdp!=null){
			mapDdp.put("tipoDocumento", "4");
			if (mapDdp.get("direccion")==null)
//				mapDdp.put("direccion", FormatoAServiceImpl.getInstance().getDdpDAO().getDomicilioLegal(numeroDocumentoIdentidad));				
				mapDdp.put("direccion", ddpDAOService.getDomicilioLegal(numeroDocumentoIdentidad));
			mapDdp.put("nombre", mapDdp.get("ddp_nombre"));
			mapDdp.put("numDocumento", mapDdp.get("ddp_numruc"));
			
		}else if(grabarDeclaran || actualizarDeclaran){
			mapDdp=new HashMap<String,Object>();
			mapDdp.put("numDocumento", xnume_docum);
			mapDdp.put("tipoDocumento", xtipo_docum);
			mapDdp.put("nombre", declarante.getNombreRazonSocial()==null?nomb_ddp:declarante.getNombreRazonSocial());
			mapDdp.put("direccion", declarante.getDireccion()==null?dir_ddp:declarante.getDireccion());
		}
		mapRpta.put("mapDeclaran", mapDdp);
		return mapRpta;
	}	
	
	// getmanif.fnvalidavia_trans 
	private char validaViaTrans(String via, String aduanaManifiesto , String fecha){
		return 'C';
	}
	
	public boolean existeRegPrecedencia(Elementos<DatoSerie> series){
		for(DatoSerie serie:series){
			if (serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0)
				return true;
		}
		return false;
	}
/*
	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}

	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}*/

//	public SoporteService getSoporteService() {
//		return soporteService;
//	}
//
//	public void setSoporteService(SoporteService soporteService) {
//		this.soporteService = soporteService;
//	}
/*
	public TdmalconDAO getTdmalconDAO() {
		return tdmalconDAO;
	}

	public void setTdmalconDAO(TdmalconDAO tdmalconDAO) {
		this.tdmalconDAO = tdmalconDAO;
	}

	public DecantiDAO getDecantiDAO() {
		return decantiDAO;
	}

	public void setDecantiDAO(DecantiDAO decantiDAO) {
		this.decantiDAO = decantiDAO;
	}

   public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
   }


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
