/*
 * Clase que define el servicio de validaciones de 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes;

import java.math.BigDecimal;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;

import net.sf.sojo.interchange.json.JsonSerializer;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PaisOrigenTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.model.ContCtaCte;
import pe.gob.sunat.despaduanero2.declaracion.model.ContPeriodo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContCtaCteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContPeriodoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.ContCtaCteCriteria;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.ContPeriodoCriteria;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.rrhh2.service.ConsultaService;

/**
 * Posee los metodos de afectacion a las tablas de Contingentes
 * 
 * @author rcalla
 *
 */
public class GrabarContingentesServiceImpl extends IngresoAbstractServiceImpl implements GrabarContingentesService {
	/* olunar 2011-39 */
	//protected final Log log = LogFactory.getLog(getClass());
	/* fin */
	private static final String COD_TRX_NUMERACION = "01";
	//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
	private static final String COD_TRX_RECTIFICACION = "03";
	private static final String COD_TRX_REGULARIZA_URG = "05";
	private static final String COD_ESTADO_RESERVA = "04";

	private static final String COD_TRX_DILIG_RECTI = "03";//RMC RIN-P47
	private static final String COD_TRX_REGULARIZA_ANTIC = "04";//RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_VAL = "09";//RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_GRA = "10";//RMC RIN-P47
	private static final String DILIG_DESPACHO_GRA = "16";//RMC RIN-P47

	// PASE 166 SE AGREGA PARA VALIDACION EN DILGENCIA REGU
	private static final String COD_TIPO_DILIG_REGU_RECT = "07";

	//private ContingentesUtil contingentesUtil;
	//private SequenceDAO sequenceDAO;
	//private ContCtaCteDAO contCtaCteDAO;
	//private ContPeriodoDAO contPeriodoDAO;
	//private CatalogoHelperImpl catalogoHelper;
	//private PublicacionAvisoService publicacionAvisoService;
	//private FabricaDeServicios fabricaDeServicios;
	//private ConsultaService 				consultaService;
	//private CatalogoAyudaService       catalogoAyudaService;

	/**
	 * 
	 * @param contingentesUtil
	 */
	/*
	public void setContingentesUtil(ContingentesUtil contingentesUtil) {
		this.contingentesUtil = contingentesUtil;
	}

	
	public void setContPeriodoDAO(ContPeriodoDAO contPeriodoDAO) {
		this.contPeriodoDAO = contPeriodoDAO;
	}


	public void setSequenceDAO(SequenceDAO sequenceDAO) {
		this.sequenceDAO = sequenceDAO;
	}

	
	public void setContCtaCteDAO(ContCtaCteDAO contCtaCteDAO) {
		this.contCtaCteDAO = contCtaCteDAO;
	}
*/
	/**
	 * 
	 * @param catalogoHelper
	 */
	//	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
	//		this.catalogoHelper = catalogoHelper;
	//	}

	/**
	 * 
	 * @param variablesIngreso
	 * @param declaracion
	 * @param listaErrores
	 * @return
	 */
	public List<Map<String, String>> procesaContingente(Map<String, Object> variablesIngreso, Declaracion declaracion, List<Map<String, String>> listaErrores) {

		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		String codTransaccion = (String) variablesIngreso.get("codTransaccion");
		String numeroDeReferencia = (String)variablesIngreso.get("numOrden");
		Long numEnvio = SunatNumberUtils.toLong(variablesIngreso.get("numEnvio"));
		Boolean is8805UnicoError = variablesIngreso.get("is8805UnicoError")== null ? Boolean.FALSE : (Boolean)variablesIngreso.get("is8805UnicoError");

		//String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender");

		List<Map<String, String>> listError = new ArrayList<Map<String,String>>();
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();

		if(is8805UnicoError)
		{
			String annOrden = codTransaccion.endsWith(COD_TRX_NUMERACION) ? numeroDeReferencia.substring(0, 4) : declaracion.getNumdeclRef().getAnnprese();
			String numeOrden = codTransaccion.endsWith(COD_TRX_NUMERACION) ? numeroDeReferencia.substring(4, numeroDeReferencia.length()) : SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0');

			String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE
			//Map<String, Object> operador = catalogoHelper.getOperadorAyudaService().getOperador(numeroDocumentoIdentidadSender, "41");
			Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
			String agente = (String)operador.get("cod_antadu");		

			for(DatoSerie serie:declaracion.getDua().getListSeries()){


				//DZC Valida que el pais pertenezca al Grupo de Union Europea
				String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
				String codpais =serie.getCodpaisorige();
				listValidPorAlcohol=new ArrayList<Map<String, Object>>();
				if(codtpi.equals("812"))
				{										
					PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
					//Map<String,Object> mpDataAsoc =FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getElementoAsoc("003",SunatStringUtils.toStringObj(codtpi), codpais);
					boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);
					//if (!CollectionUtils.isEmpty(mpDataAsoc)){
					if (existePuerto){
						serie.setCodpaisorige("UE");
					}

				} 
				//FIN DZC    

				if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) ){

					List<Map<String,Object>> listJoinContingente=contingentesUtil.getListJoinContingente(serie , declaracion);
					Map<String,Object> mapDatosCont=listJoinContingente.get(0);

					mapDatosCont.put("numDoc",numeOrden);
					mapDatosCont.put("annDoc", annOrden);
					mapDatosCont.put("agente", agente);
					/*branch ingreso 2011-029 hosorio inicio 15/07/2011*/
					mapDatosCont.put("codTipoDoc", "03");
					/*branch ingreso 2011-029 hosorio fin 15/07/2011*/


					listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont);

					BigDecimal cantSaldoCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
					BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);//SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));//
					mapDatosCont.put("cntSolCont", cntSolicCont);

					BigDecimal cntContingente = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));//contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont);
					//PAS20175E220200045 - Solo cuando es rectificaci�n y tiene canal por lo tanto es pendiente de evaluar
					actualizarContingente("RT", cntSolicCont, mapDatosCont, serie, declaracion,   new HashMap<String,Object>(),codTransaccion);

					// colocamos para que obtenga el de la reserva
					mapDatosCont.put("codEstado", COD_ESTADO_RESERVA);

					ContCtaCte contCtaCte  = contingentesUtil.getContCtaCte(mapDatosCont, serie, declaracion); 
					if( contCtaCte != null )
					{ 
						// SE HA REALIZADO LA RESERVA DEL CONTINGENTE A LAS HH:MM:SS HORAS DEL DD/MM/YYYY. TIENE UN PLAZO DE X HORAS PARA
						// VOLVER A ENVIAR SU SOLICITUD
						//	Date date = SunatDateUtils.getCurrentDate();
						Date date2 = pe.gob.sunat.despaduanero2.util.DateUtil.addHour(contCtaCte.getFecRegistro(), 6);
						BigDecimal bgNumero = (SunatNumberUtils.isGreaterThanParam(cntSolicCont,cantSaldoCont)?cantSaldoCont:cntSolicCont);

						if(SunatNumberUtils.isGreaterThanZero(bgNumero))
						{

							String etiqueta = codTransaccion.endsWith(COD_TRX_NUMERACION) ? "ORDEN:"  : "DECLARACION:"; 

							String mensaje1 =  etiqueta+ declaracion.getCodaduana() + "-" + annOrden + "-" + numeOrden + " SERIE:" + serie.getNumserie() +
									" CANT.RESERVADA " + bgNumero + " " + mapDatosCont.get("codUndCont") + " FEC.REG.RESERVA:" + SunatDateUtils.getFormatDate(contCtaCte.getFecRegistro(), "dd/MM/yyyy HH:mm:ss");

							String mensaje2 = etiqueta + declaracion.getCodaduana() + "-" + annOrden + "-" + numeOrden + " SERIE:" + serie.getNumserie() + " FEC.VENCIM.RESERVA:" + SunatDateUtils.getFormatDate(date2, "dd/MM/yyyy HH:mm:ss");

							listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("09802", new String[]{serie.getNumserie().toString(),
									SunatDateUtils.getFormatDate(contCtaCte.getFecRegistro(), "dd/MM/yyyy HH:mm:ss")}));

							listError.add(ResponseMapManager.getWarningResponseMap("09802", mensaje1));

							listError.add(ResponseMapManager.getWarningResponseMap("09802", mensaje2));
						}
					}else{
						//LA ORDEN XXXXX NO TIENE RESERVA DE CONTINGENTE REGISTRADA
						String message = "LA ORDEN  "+declaracion.getCodaduana() + "-" + annOrden + "-" + numeOrden+ " SERIE: " +serie.getNumserie() + " NO TIENE RESERVA DE CONTINGENTE REGISTRADA";
						listError.add(ResponseMapManager.getErrorResponseMap("08806", message));
					}
				}
				serie.setCodpaisorige(codpais); 
			}			
		}

		return listError;
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService#procesaContingenteNumeracion(java.util.Map, pe.gob.sunat.despaduanero2.declaracion.model.Declaracion)
	 */
	public List<Map<String, String>>  procesaContingenteNumeracion(Map<String, Object> variablesIngreso, Declaracion declaracion) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		String codTransaccion = (String) variablesIngreso.get("codTransaccion");

		if(! codTransaccion.startsWith(Constants.REGIMEN_IMPORTACION_CONSUMO.toString()) )
			return null; 
		/* olunar - 2012-039 */
		String annPresen = declaracion.getDua().getAnnpresen().toString();
		/* fin */
		String numeOrden = declaracion.getNumeroDeclaracion().toString();
		numeOrden = SunatStringUtils.lpad(numeOrden, 6, '0');

		String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE
		//Map<String, Object> operador = catalogoHelper.getOperadorAyudaService().getOperador(numeroDocumentoIdentidadSender, "41");
		Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
		String agente = (String)operador.get("cod_antadu");		

		String numeroDeReferencia = (String)variablesIngreso.get("numOrden");
		String annOrdenTmp = numeroDeReferencia.substring(0, 4) ;
		String numeOrdenTmp = numeroDeReferencia.substring(4, numeroDeReferencia.length()) ;
		String partida = "";

		Boolean actualizaCtaCteContingente = variablesIngreso.get("actualizaCtaCteContingente") == null ? Boolean.FALSE :  (Boolean)variablesIngreso.get("actualizaCtaCteContingente");
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();

		if(actualizaCtaCteContingente)
		{
			BigDecimal saldo = BigDecimal.ZERO;
			Map<String,Object> mapDatosContTmp = new HashMap<String, Object>();

			for(DatoSerie serie:declaracion.getDua().getListSeries()){

				//DZC Valida que el pais pertenezca al Grupo de Union Europea
				String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
				String codpais =serie.getCodpaisorige();
				listValidPorAlcohol=new ArrayList<Map<String, Object>>();
				if(codtpi.equals("812"))
				{										
					//Map<String,Object> mpDataAsoc =FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getElementoAsoc("003",SunatStringUtils.toStringObj(codtpi), codpais);
					PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
					boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);
					//if (!CollectionUtils.isEmpty(mpDataAsoc)){
					if (existePuerto){
						serie.setCodpaisorige("UE");
					}

				} 
				//FIN DZC

				if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) ){

					List<Map<String,Object>> listJoinContingente=contingentesUtil.getListJoinContingente(serie , declaracion );
					if(!CollectionUtils.isEmpty(listJoinContingente))
					{
						Map<String,Object> mapDatosCont = listJoinContingente.get(0);

						mapDatosCont.put("numDoc",numeOrden); 
						/* olunar 2012-039 */
						mapDatosCont.put("annDoc", annPresen);
						/* fin */
						mapDatosCont.put("numDocTmp",numeOrdenTmp); 
						mapDatosCont.put("annDocTmp", annOrdenTmp);

						mapDatosCont.put("agente", agente);


						listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont);
						BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);
						mapDatosCont.put("cntSolCont", cntSolicCont);

						//BigDecimal cntContingente = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont);
						BigDecimal cntContingente = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntContingente"));

						//PAS20175E220200045 - Solo cuando es rectificaci�n y tiene canal por lo tanto es pendiente de evaluar -NUmeracion
						saldo = actualizarContingente("A", cntSolicCont, mapDatosCont, serie, declaracion , new HashMap<String,Object>(), "01");

						if(SunatNumberUtils.isLessOrEqualsThanZero(saldo))
						{
							mapDatosContTmp.putAll(mapDatosCont);
							partida = SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0') ;
							mapDatosContTmp.put("saldo",saldo);
							mapDatosContTmp.put("partida",partida);
							mapDatosContTmp.put("codAduana",declaracion.getCodaduana() );
						}
					}
				}
				serie.setCodpaisorige(codpais); 
			}

			if(SunatNumberUtils.isLessOrEqualsThanZero(saldo) &&  !CollectionUtils.isEmpty(mapDatosContTmp)  )
			{
				notificaSaldoCero(mapDatosContTmp);
			}

		}

		return null;
	}


	private BigDecimal actualizarContingente(String accion, BigDecimal cntSolicCont, Map<String, Object> mapDatosCont, DatoSerie serie, Declaracion declaracion, Map<String, Object> mapCntSolAntSeries, String codTransaccion ) {

		BigDecimal saldoFinalContingente = BigDecimal.ZERO;

		//PAS20175E220200045 - Solo cuando es rectificaci�n y tiene canal por lo tanto es pendiente de evaluar
		if("A".equals(accion)){ //Asignar
			saldoFinalContingente = actualizaSaldoCont(accion, cntSolicCont, mapDatosCont,mapCntSolAntSeries, codTransaccion,declaracion);
			actualizaContCtaCte("L", serie, mapDatosCont, declaracion);
			ingresaCtaCte(accion, serie, mapDatosCont, declaracion, cntSolicCont);
		}else if (SunatStringUtils.isStringInList(accion, "RT,RT,RS")) { //Reservar
			saldoFinalContingente = actualizaSaldoCont(accion, cntSolicCont, mapDatosCont , mapCntSolAntSeries, codTransaccion,declaracion);
			ingresaCtaCte(accion, serie, mapDatosCont, declaracion, cntSolicCont);
		}else if ("L".equals(accion)) { //Liberar
			saldoFinalContingente = actualizaSaldoCont(accion, cntSolicCont, mapDatosCont, mapCntSolAntSeries, codTransaccion,declaracion);			
		}

		return saldoFinalContingente;
	}

	/**
	 * Actualizar saldo de contingente
	 * 
	 * @param action
	 * @param cntContingente La cantidad que se va a descontar del contperiodo
	 * @param mapDatosCont   
	 */
	@SuppressWarnings("unchecked")
	private BigDecimal actualizaSaldoCont(String action, BigDecimal cntContingente, Map<String, Object> mapDatosCont, Map<String, Object> mapCntSolAntSeries, String codTransaccion , Declaracion declaracion ){
		ContPeriodoDAO contPeriodoDAO = fabricaDeServicios.getService("contPeriodoDAO");
		BigDecimal cantSaldoCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));	
		BigDecimal cntTotalContingente = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntContingente"));
		BigDecimal cntSolicCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSolCont"));

		ContPeriodoCriteria contPeriodoCriteria = new ContPeriodoCriteria();
		ContPeriodoCriteria.Criteria criteria= contPeriodoCriteria.createCriteria();
		criteria.andPerContingenteEqualTo( (String)mapDatosCont.get("perContingente") );
		criteria.andCodTpiEqualTo( (String)mapDatosCont.get("codTpi") );
		criteria.andCodPaisOrigenEqualTo(  (String)mapDatosCont.get("codPaisOrigen") );
		criteria.andNumGrupoContEqualTo(  SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")) );

		List<ContPeriodo> contPeriodoList = contPeriodoDAO.selectByContPeriodoCriteria(contPeriodoCriteria);
		ContPeriodo contPeriodo = new ContPeriodo();

		if( ! CollectionUtils.isEmpty(contPeriodoList) ){
			ContPeriodo contPeriodo2 = contPeriodoList.get(0);
			//	cantSaldoCont = contPeriodo2.getCntSaldoCont();

			if("L".equals(action))
				//&& Cuando se libera contingente 
				contPeriodo.setCntSaldoCont( SunatNumberUtils.sum(cantSaldoCont, cntSolicCont)  );

			else if( SunatStringUtils.isStringInList(action, "A,RT,RD,RS"))
			{
				//PAS20175E220200045 - Solo cuando es rectificaci�n y tiene canal por lo tanto es pendiente de evaluar
				if("A".equals(action) && codTransaccion.endsWith(COD_TRX_DILIG_RECTI) && !"".equals(declaracion.getDua().getCodCanal().trim()) ){ //Asignar

					BigDecimal cntCantDevAntSeries=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
					BigDecimal cntSaldoContPeriodo=cantSaldoCont.add(cntCantDevAntSeries);
					if(SunatNumberUtils.isGreaterThanParam(cntSolicCont,cantSaldoCont))
					{
						if (SunatNumberUtils.isGreaterOrEqualsThanParam(cntCantDevAntSeries , cntSolicCont)) {
							return cantSaldoCont;
						}
					}
				}



				if(SunatNumberUtils.isEqual(cantSaldoCont, cntTotalContingente))
					contPeriodo.setFecIniVig(SunatDateUtils.getCurrentDate());


				if(SunatNumberUtils.isLessOrEqualsThanZero(SunatNumberUtils.diference(cantSaldoCont, cntSolicCont)))
					contPeriodo.setFecFinVig(SunatDateUtils.getCurrentDate());


				//Para la reserva temporal se considera solo el monto cero mas no el negativo
				//if (SunatStringUtils.isStringInList(action, "RT,RD,RS")) {
				//JPL Si lo solicitado es mayor al Saldo se coloca Cero como saldo y se envia los restante a CTACTE.
				if(SunatNumberUtils.isGreaterThanParam(cntSolicCont,cantSaldoCont))
				{
					contPeriodo.setCntSaldoCont( BigDecimal.ZERO );
				}
				else{
					contPeriodo.setCntSaldoCont( SunatNumberUtils.diference(cantSaldoCont, cntSolicCont)  );
				}

				/*} else {
					//Para los demas casos que registre monto cero
						contPeriodo.setCntSaldoCont( SunatNumberUtils.diference(cantSaldoCont, cntSolicCont)  );
				}
				 */
			}
			contPeriodoDAO.updateByCriteriaSelective(contPeriodo, contPeriodoCriteria);			
		}

		return contPeriodo.getCntSaldoCont();
	}

	public void  ingresaCtaCte(String action, DatoSerie serie, Map<String,Object> mapDatosCont, Declaracion declaracion, BigDecimal cntContingente){
		
		SequenceDAO sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef.Sigad.Centralizado");
		Long numCtaCte =sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_CONTINGENTE_CTA_CTE);

		BigDecimal cantSaldoCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont")); 
		BigDecimal cntSolicCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSolCont"));  

		//RMC RIN-P47
		//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION DE OFICIO
		Integer perContingente = SunatNumberUtils.getIntegerFromString(mapDatosCont.get("perContingente").toString().trim());
		String codTipoTrans = mapDatosCont.get("codTipoTrans") != null ? mapDatosCont.get("codTipoTrans").toString().trim() : "";

		Integer annio = SunatDateUtils.getAnho( SunatDateUtils.getCurrentDate() );
		ContCtaCte contCtaCte = new ContCtaCte();
		/* olunar 581 */
		if(mapDatosCont.get("annCtaCte")!=null)contCtaCte.setAnnCtaCte(mapDatosCont.get("annCtaCte").toString());
		else
			/* fin */
			contCtaCte.setAnnCtaCte( codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA) ? mapDatosCont.get("perContingente").toString().trim() : annio.toString());
		contCtaCte.setAnnCtaCte( annio.toString() );
		contCtaCte.setNumCtaCte(numCtaCte.intValue());
		contCtaCte.setCodTpi(serie.getCodconvinter().toString());
		contCtaCte.setCodPaisOrigen(serie.getCodpaisorige());
		contCtaCte.setNumGrupoCont( SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")) );
		contCtaCte.setPerContingente((String)mapDatosCont.get("perContingente") );
		contCtaCte.setFecRegistro( SunatDateUtils.getCurrentDate() );

		if("A".equals(action))
			contCtaCte.setCodTipoDoc("02");
		else
			contCtaCte.setCodTipoDoc("03");

		contCtaCte.setCodAduanaDoc(declaracion.getCodaduana());

		contCtaCte.setAnnDoc( mapDatosCont.get("annDoc").toString());
		contCtaCte.setNumDoc( mapDatosCont.get("numDoc").toString());

		contCtaCte.setCodRegimenDoc(declaracion.getDua().getCodregimen());
		contCtaCte.setCodDocAduanero(" ");
		contCtaCte.setNumSerieDoc(serie.getNumserie());
		//JPL Si el Saldo es menor a lo solicitado se actualiza CTACTE con lo solicitado y se envia u mensaje por la diferencia.
		if(SunatNumberUtils.isLessOrEqualsThanParam(cantSaldoCont, cntSolicCont) && SunatStringUtils.isStringInList(action, "RT,RT,RS"))
		{contCtaCte.setCntContiSol( cantSaldoCont );}
		else
		{contCtaCte.setCntContiSol(cntSolicCont);}


		contCtaCte.setCodUndCont((String)mapDatosCont.get("codUndCont"));

		contCtaCte.setCodAgente( (String)mapDatosCont.get("agente") );

		if("A".equals(action))
			contCtaCte.setCodEstado("03");	//Contingente Asignado
		else if("RT".equals(action)) 
			contCtaCte.setCodEstado("04"); //Contingente Reservado por Teledespacho
		else if("RD".equals(action)) 
			contCtaCte.setCodEstado("05"); //Contingente Reservado por Imp. Definitiva
		else if("RS".equals(action)) 
			contCtaCte.setCodEstado("06"); //Contingente Reservado por Imp. Simplificada		


		if(SunatNumberUtils.isGreaterThanZero(contCtaCte.getCntContiSol())){
			ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
			contCtaCteDAO.insertSelective(contCtaCte);
		}

	}


	/**
	 * Cuando hay alguna accion sobre la ctacte del contingente se actualiza la tabla CONTCTACTE
	 * 
	 * @param action
	 */
	private void actualizaContCtaCte(String action, DatoSerie serie, Map<String,Object> mapDatosCont, Declaracion declaracion){
		ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		ContCtaCte contCtaCte = new ContCtaCte();
		String tmpPrefix = "";

		if("L".equals(action)){
			contCtaCte.setCodEstado("02"); //Libera Contingente 
			tmpPrefix = "Tmp";
		}else if("A".equals(action))
			contCtaCte.setCodEstado("03");	//Contingente Asignado
		else if("RT".equals(action)) 
			contCtaCte.setCodEstado("04"); //Contingente Reservado por Teledespacho
		else if("RD".equals(action)) 
			contCtaCte.setCodEstado("05"); //Contingente Reservado por Imp. Definitiva
		else if("RS".equals(action)) 
			contCtaCte.setCodEstado("06"); //Contingente Reservado por Imp. Simplificada

		ContCtaCteCriteria criteriaCtaCte = new ContCtaCteCriteria();
		ContCtaCteCriteria.Criteria criteria = criteriaCtaCte.createCriteria();

		criteria.andNumDocEqualTo((String)mapDatosCont.get("numDoc" + tmpPrefix));
		criteria.andAnnDocEqualTo((String)mapDatosCont.get("annDoc"+ tmpPrefix ));
		criteria.andCodAduanaDocEqualTo(declaracion.getCodaduana());
		criteria.andCodRegimenDocEqualTo(declaracion.getDua().getCodregimen());
		criteria.andNumSerieDocEqualTo(serie.getNumserie());
		criteria.andCodTipoDocEqualTo("03");
		criteria.andCodAgenteEqualTo(mapDatosCont.get("agente") != null ? (String) mapDatosCont.get("agente") : " ");
		contCtaCteDAO.updateByCriteriaSelective(contCtaCte, criteriaCtaCte);
	}	


	/**
	 * En caso el saldo del contingente tenga valor negativo se debe remitir un correo electr�nico al Gerente de Tratados Internacionales y
	 * Valoraci�n. Asunto del correo: Saldo Negativo para el Contingente XXX Contenido del mensaje: Se ha producido a las HH MM SS (horas,
	 * minutos y segundos) del d�a D un saldo negativo para el contingente del grupo de mercanc�as XX bajo el TPI YY. Las 5 �ltimas DUA
	 * enviadas son: Aduana-A�o-Nro, �.
	 */
	private void notificaSaldoCero(Map<String,Object> mapDatosCont){
		ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		
		FechaBean fechaBean = new FechaBean();
		// Divisi�n de Tratados Internacionales ponerlo en tablas
		String codigoAreaFuncionario = "5F3100";
		ConsultaService consultaService = fabricaDeServicios.getService("rrhh2.service.consultaService");
		Map<String,Object> mapUnidadOrganizacional = consultaService.obtenerUnidadesOrganizacionalesPk(codigoAreaFuncionario);
		String codPersonalJefeArea  = mapUnidadOrganizacional!=null?(mapUnidadOrganizacional.get("t12cod_jefat")!=null?(String) mapUnidadOrganizacional.get("t12cod_jefat"):""):"0000";

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");


		String codAduana = mapDatosCont.get("codAduana") == null ? "000":(String) mapDatosCont.get("codAduana");

		String desAduana = catalogoAyudaService.getDescripcionDataCatalogo("00", codAduana) ;

		Map<String, Object> mapParams = new LinkedHashMap<String, Object>();
		mapParams.put("cod_usuario", new String[]{codPersonalJefeArea}); 
		mapParams.put("des_asunto", "SALDO NEGATIVO CONTINGENTES"); 
		mapParams.put("tip_usuario", "3");
		mapParams.put("fecha_emision", fechaBean.getTimestamp());

		mapParams.put("comunicado.cod_convenio", (String)mapDatosCont.get("codTpi"));
		mapParams.put("comunicado.cod_paisorigen", (String)mapDatosCont.get("codPaisOrigen"));
		mapParams.put("comunicado.fecha_emision", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")); //(fecha de emisi�n del aviso formato dd/mm/yyyy)
		mapParams.put("comunicado.hora_registro", SunatDateUtils.getCurrentFormatDate("HH:mm:ss")); //(hora de registro del saldo negativo formato hh:mm: ss)
		mapParams.put("comunicado.fec_registro", SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy")); //(fecha de registro del saldo negativo formato dd/mm/yyyy)
		mapParams.put("comunicado.num_grupo_cont", mapDatosCont.get("numGrupoCont").toString() );//(es el grupo de contingente que se registra en la tabla contperiodo y contctacte)
		mapParams.put("comunicado.partida", mapDatosCont.get("partida").toString() ); 
		mapParams.put("comunicado.saldo", mapDatosCont.get("saldo").toString() ); 
		mapParams.put("comunicado.intendencia", desAduana);

		ContCtaCte param = new ContCtaCte();
		param.setCodTpi((String)mapDatosCont.get("codTpi"));
		param.setCodPaisOrigen((String)mapDatosCont.get("codPaisOrigen"));
		param.setNumGrupoCont(SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
		param.setPerContingente((String)mapDatosCont.get("perContingente")); 	    

		List<ContCtaCte> listaContCtaCte = contCtaCteDAO.findUltimosRegistrosNumerados(param);

		int contador = 1;

		for (ContCtaCte contCtaCte : listaContCtaCte) {
			mapParams.put("comunicado.cod_aduana"+contador, contCtaCte.getCodAduanaDoc());
			mapParams.put("comunicado.ann_presen"+contador, contCtaCte.getAnnDoc());
			mapParams.put("comunicado.cod_regimen"+contador, contCtaCte.getCodRegimenDoc());
			mapParams.put("comunicado.num_declaracion"+contador, contCtaCte.getNumDoc());
			mapParams.put("comunicado.nroDeclaracion","Nro: "+contCtaCte.getCodAduanaDoc()+" - "+ contCtaCte.getAnnDoc()+" - "+contCtaCte.getCodRegimenDoc()+" - "+ contCtaCte.getNumDoc()+" <BR>");
			contador++;
		}	

		//Conversion de Map a JSON
		JsonSerializer json = new JsonSerializer();
		StringBuffer data =  new StringBuffer(json.serialize(mapParams).toString());
		publicacionAvisoService.insert(100045, data, "0", fechaBean.getTimestamp(), fechaBean.getTimestamp());		
	}


	/*branch  ingreso 2011-029 diligencia despacho inicio */
	public List<Map<String, String>> procesarContingenteDiligencia(Declaracion declaracion,Map<String, Object> variablesIngreso, Boolean blGrabaRectiDefinitivo)
	{
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List listError = new ArrayList();
		boolean noRegistraElimina = false;
		boolean saldoCero = false;

		Map<String,Object> mapCntSolAntSeries = new HashMap<String,Object>();

		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		if(log.isDebugEnabled())log.debug("Inicio metodo procesarContingenteDiligencia");
		try
		{
			Map<String, Object> mapDatosContTmp = new HashMap<String, Object>();
			List<Map<String,Object>> listMensaje=new ArrayList<Map<String, Object>>();


			String msg ="";
			int nroErrores = variablesIngreso.get("nroErrores")== null ? 0 : (Integer)variablesIngreso.get("nroErrores");

			String  codTransaccion = variablesIngreso.get("codTransaccion") == null ? "": (String)variablesIngreso.get("codTransaccion");
			if ( codTransaccion.trim().length() == 0 )
				codTransaccion =  declaracion.getCodtipotrans() == null ? "": declaracion.getCodtipotrans();

			String codTipoTrans = (declaracion != null && declaracion.getCodtipotrans() != null) ? declaracion.getCodtipotrans() : "";

			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
			if ( codTransaccion.endsWith(COD_TRX_RECTIFICACION) &&  !blGrabaRectiDefinitivo) 
				noRegistraElimina = true;

			//String numeroDocumentoIdentidadSender = //(String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE
			String 	numeroDocumentoIdentidadSender = variablesIngreso.get("numeroDocumentoIdentidadSender") == null ? "": (String)variablesIngreso.get("numeroDocumentoIdentidadSender");
			String agente = "";
			Map<String, Object> operador = new HashMap<String, Object>(); 

			if ( !SunatStringUtils.isEmpty(numeroDocumentoIdentidadSender) ) {
				operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
				agente = (String)operador.get("cod_antadu");		
			}

			// Si no encuentra valores se muestra el error	
			if(nroErrores == 0)
			{

				// modulo de contingentes activo	
				boolean gbcontingente = PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", new Date()).intValue() > 0;
				boolean blSerieNueva = false;
				boolean blNuevoContingente = false;
				boolean blCambioGrupo=false;
				boolean blCambioTpiPartida=false;
				String tipoMargen = "";
				if (gbcontingente) {
					List<DatoSerie> lstSeriesBd= contingentesUtil.getSeriesBD(declaracion.getNumeroCorrelativo());


					//Por cada series de  la Dua Actual 
					for (DatoSerie serie : declaracion.getDua().getListSeries())
					{
						blSerieNueva = false;
						blNuevoContingente = false;
						blCambioGrupo=false;
						blCambioTpiPartida=false;
						tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
						listValidPorAlcohol=new ArrayList<Map<String, Object>>();

						// serie de Base de datos correspondiente
						DatoSerie serieOld = null;
						for(DatoSerie serieBD:lstSeriesBd){
							if (SunatNumberUtils.isEqual(serieBD.getNumserie(), serie.getNumserie())) {
								serieOld=serieBD;
								if ( !SunatNumberUtils.isEqual(serieOld.getCodconvinter(), serie.getCodconvinter()) ||
										!SunatNumberUtils.isEqual(serieOld.getNumpartnandi(), serie.getNumpartnandi())) {
									blCambioTpiPartida = true;
								}
								break;
							}
						}


						// datos de Cuenta Corriente de Contingencia para la serie
						Map<String,Object> mapDatosCont = new HashMap<String, Object>();
						mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
						mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
						mapDatosCont.put("codTipoDoc", "02");
						mapDatosCont.put("codEstado", "03");

						ContCtaCte serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serie,declaracion);

						/* olunar 581 - Cuando la serie es nueva */
						if(serieOld==null)
						{
							/*for (DatoSerie serieAux : declaracion.getDua().getListSeries())
		        	{ // Tomando el contingente de la serie que tiene el mismo grupo de contingente
		        	  if(serie.getCodpaisorige().equals(serieAux.getCodpaisorige()) && serie.getCodconvinter().intValue()==serieAux.getCodconvinter().intValue())
		        	  {
		        		  serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serieAux,declaracion);
		        		  if(serieCtaCte!=null)serieCtaCte.setNumSerieDoc(serie.getNumserie());
		        		  break;  
		        	  }
		        	}
							 */
							blSerieNueva = true;
							// Que sucede si no existe ninguna que tenga el mismo grupo
							// COmo adicionar a un nuevo contingente
							/*
//		        	if(serieCtaCte!=null)
	//	        	{
			          // se obtiene el grupo de contingente al que pertenece la serie diligenciada
			          List listJoinContingente = this.contingentesUtil.getListJoinContingente(serie, declaracion );
				        if(!CollectionUtils.isEmpty(listJoinContingente)){
			        	        mapDatosCont = (Map)listJoinContingente.get(0);
				        }
			          	mapDatosCont.put("annCtaCte", declaracion.getNumdeclRef().getAnnprese());
			          	mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese() ); 
			          	mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
			            mapDatosCont.put("codTipoDoc", "02");
			            mapDatosCont.put("codEstado", "03");
			            mapDatosCont.put("agente", agente);
			            listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont);
			        	BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont,listValidPorAlcohol);
			        	mapDatosCont.put("cntSolCont", cntSolicCont);

			        	 mapDatosCont.put("perContingente", serieCtaCte.getPerContingente());
			      	      mapDatosCont.put("codTpi", serieCtaCte.getCodTpi());
			      	      mapDatosCont.put("codPaisOrigen", serieCtaCte.getCodPaisOrigen());
			      	      mapDatosCont.put("numGrupoCont", serieCtaCte.getNumGrupoCont());

			      	      ContPeriodo periodo = obtenerContPeriodo(mapDatosCont);
			      	      BigDecimal saldo = periodo.getCntSaldoCont();
			      	    BigDecimal saldoFinalPeriodo = saldo.subtract(cntSolicCont);

			      	  if(SunatNumberUtils.isLessThanZero(saldoFinalPeriodo)) {
			      		saldoCero = true;
			      		mapDatosContTmp.putAll(mapDatosCont);
						mapDatosContTmp.put("saldo",saldoFinalPeriodo);
						mapDatosContTmp.put("partida",SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
						mapDatosContTmp.put("codAduana",declaracion.getCodaduana() );
			      	  }

			  	    if (!CollectionUtils.isEmpty(variablesIngreso)){
                        if (variablesIngreso.get("COD_USUMODIF") == null) {
                        	mapDatosCont.put("COD_USUMODIF", agente);
			     		}
				   } else {
				   	   mapDatosCont.put("COD_USUMODIF", agente);
				   	   mapDatosCont.put("COD_USUMODIF", agente);
				   }
			  	  mapDatosCont.put("COD_USUMODIF", agente);
		      	    mapDatosCont.put("FEC_MODIF", (new FechaBean()).getTimestamp());


			        	ingresaCtaCte("A", serie, mapDatosCont, declaracion, cntSolicCont);
			        	actualizarCantContPeriodo(mapDatosCont, saldoFinalPeriodo);
		//        	}
							 */
							serieOld=new DatoSerie();
							serieOld.setCntunifis(new BigDecimal(0));
							serieOld.setCntpesoneto(new BigDecimal(0));
							serieOld.setMtofobdol(new BigDecimal(0));

						}
						/* fin */	          

						//se valida si es una serie que ya esta con contingente 
						//gbcontCtaCte  true: tiene contingente false: no tiene contigente 
						boolean gbcontCtaCte = !(serieCtaCte==null);

						// Se valida si solicita contingente nuevo
						if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) ){
							// PASE 166 se agrega porque no sete el pais correcto de UE para TPI 812
							String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
							if(codtpi.equals("812"))  {
								PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
								boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), serie.getCodpaisorige());
								if (existePuerto){
									serie.setCodpaisorige("UE");
								} 
							}				   
							// FIN PASE 166

							// se obtiene el grupo de contingente al que pertenece la serie diligenciada se adiciona para los que son por Rectificacion de oficio
							List listJoinContingente = contingentesUtil.getListJoinContingente(serie, declaracion );
							if(!CollectionUtils.isEmpty(listJoinContingente))
								mapDatosCont = (Map)listJoinContingente.get(0);
						}


						// se obtiene el grupo de contingente al que pertenece la serie diligenciada
						List listJoinContingente = null;

						//Se valida si es Rectificacion de oficio
						if(codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA) ){
							listJoinContingente = contingentesUtil.listContingenteRecOficio(serie, declaracion );
						} else {
							listJoinContingente = contingentesUtil.getListJoinContingente(serie, declaracion );
						}
						if(!CollectionUtils.isEmpty(listJoinContingente)) {
							mapDatosCont = (Map)listJoinContingente.get(0);
							if (serieCtaCte != null) {
								for ( int i = 0; i < listJoinContingente.size(); i++) {
									mapDatosCont = (Map)listJoinContingente.get(i);
									if(SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont")))
											&& SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) )
											&& SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi")) )
											){
										mapDatosCont = (Map)listJoinContingente.get(i);
										break;
									}
								}
							}
						}


						listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont);   
						if (serieCtaCte != null) {
							if(!SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont")))
									|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) )
									|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi")) )
									// || !SunatNumberUtils.isEqual(serie.getNumpartnandi(), serieCtaCte. serieOld.getNumpartnandi()) //olunar - 581 
									){
								blCambioGrupo=true;
								// Se agrega por por cambio de grupo varia los contingentes.
								blNuevoContingente = true;
							}

							// En este caso se verifica si hubo cambio de partida y convenios 
							if (blCambioTpiPartida) {
								if(!CollectionUtils.isEmpty(listJoinContingente)) {
									blNuevoContingente = true;
									blCambioGrupo=true;
								}
							}

						} else {
							// No tiene cuenta corriente previa y no tiene contingente para acogerse
							if(!CollectionUtils.isEmpty(listJoinContingente)) {
								blNuevoContingente = true;
								blCambioGrupo=true;
							}
						}

						// PASE 166 se agrega para que en la diligencia de regu si no hay cambios no haga nada
						if(codTransaccion.endsWith(COD_TIPO_DILIG_REGU_RECT ) || codTransaccion.endsWith(COD_TRX_DILIG_RECTI) || 
								codTransaccion.endsWith(COD_TRX_REGULARIZA_ANTIC) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) 
								|| codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA) || codTipoTrans.endsWith(DILIG_DESPACHO_GRA) ){//RMC RIN-P47 Se agrega la rectificacion y regularizacion de anticipadas

							if (serieCtaCte != null && !CollectionUtils.isEmpty(listJoinContingente) ) {

								BigDecimal cntSolicContComp = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont , listValidPorAlcohol);//SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));//

								if(SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont")))
										&& SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) )
										&& SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi")))
										&& SunatStringUtils.isEqualTo(serieCtaCte.getPerContingente(), SunatStringUtils.toStringObj(mapDatosCont.get("perContingente"))			)		        					
										&&  serieCtaCte.getCntContiSol().compareTo(cntSolicContComp)==0){

									//break; 
									//RMC RIN-P47 Se cambia el break por el continue para que no salga del bucle y siga con la serie posterior
									continue; 
								}
							}
						}
						//fin  PASE 166 

						if ( (serieCtaCte != null) && blCambioGrupo ) {
							mapDatosCont.put("perContingente", serieCtaCte.getPerContingente());
							mapDatosCont.put("codTpi", serieCtaCte.getCodTpi());
							mapDatosCont.put("codPaisOrigen", serieCtaCte.getCodPaisOrigen());
							mapDatosCont.put("numGrupoCont", serieCtaCte.getNumGrupoCont());

							ContPeriodo periodo = obtenerContPeriodo(mapDatosCont);

							BigDecimal saldo = periodo.getCntSaldoCont();

							if (!CollectionUtils.isEmpty(variablesIngreso)){
								if (variablesIngreso.get("COD_USUMODIF") == null) {
									variablesIngreso.put("COD_USUMODIF", agente);
								}
							} else {
								variablesIngreso = new HashMap<String, Object>();
								variablesIngreso.put("COD_USUMODIF", agente);
							}
							variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());

							mapDatosCont.putAll(variablesIngreso);		
							//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
							if ( !noRegistraElimina  ) {
								actualizaContCtaCteDespacho("L", serie, mapDatosCont, declaracion);
								actualizarCantContPeriodo(mapDatosCont, saldo.add(serieCtaCte.getCntContiSol()));
							}
						}
						if ( blNuevoContingente || blSerieNueva  ) {
							if (contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) && !CollectionUtils.isEmpty(listJoinContingente)) {

								listJoinContingente = contingentesUtil.getListJoinContingente(serie,  declaracion);
								if(!CollectionUtils.isEmpty(listJoinContingente)) {
									mapDatosCont = (Map)listJoinContingente.get(0);
								}

								char pindproce = '0';
								// Por ser una nueva afectaci�n se setea con los datos de la Serie

								//RMC RIN-P47 Inicio
								BigDecimal cntSoliContingente = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);  

								ContPeriodo periodo = null;
								if (codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA) ) {
									Map<String,Object> mapDatosContPeriodo= contingentesUtil.getMapRectifOficio(serie,  declaracion);
									if (!CollectionUtils.isEmpty(mapDatosContPeriodo)){
										periodo = obtenerContPeriodo(mapDatosContPeriodo);
										mapDatosCont = mapDatosContPeriodo;
									}


								} else {
									periodo = obtenerContPeriodo(mapDatosCont);
								}
								//RMC RIN-P47 Fin
								BigDecimal saldo = new BigDecimal(0);	
								if ( periodo != null ){
									saldo = periodo.getCntSaldoCont();
								}


								if (!CollectionUtils.isEmpty(variablesIngreso)){
									if (variablesIngreso.get("COD_USUMODIF") == null) {
										variablesIngreso.put("COD_USUMODIF", agente);
									}
								} else {
									variablesIngreso = new HashMap<String, Object>();
									variablesIngreso.put("COD_USUMODIF", agente);
								}

								variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());
								mapDatosCont.putAll(variablesIngreso); 	


								//      BigDecimal cntSoliContingente = this.contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);  
								BigDecimal cantSaldoCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
								BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont , listValidPorAlcohol);//SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));//
								mapDatosCont.put("cntSolCont", cntSolicCont);

								BigDecimal cntContingente = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));//contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont);
								mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
								mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
								mapDatosCont.put("codTipoDoc", "02");
								mapDatosCont.put("codEstado", "03");
								mapDatosCont.put("agente", agente);
								mapDatosCont.put("cntSolCont", cntSolicCont);

								if (codTransaccion.endsWith(COD_TRX_REGULARIZA_URG) || codTransaccion.endsWith(COD_TRX_DILIG_RECTI) || codTransaccion.endsWith(COD_TRX_REGULARIZA_ANTIC)) { //RMC RIN-P47 Se agrega la rectificacion y la regularizaci�n de anticipado
									// Para poder devolver la reserva
									mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
									mapDatosCont.put("annDoc",declaracion.getNumdeclRef().getAnnprese());
									mapDatosCont.put("numDocTmp",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
									mapDatosCont.put("annDocTmp",declaracion.getNumdeclRef().getAnnprese());
									mapDatosCont.put("agente",agente);


									BigDecimal cantSolContNuev=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
									//cantSolContNuev = cantSolContNuev.add(difMonto.abs());

									//PAS20175E220200045 RSV PARA CONSIDERAR LOS SALDOS DE SERIES ANTERIORES ESPECIALMENTE EN LA RECTIFICACI�N Y ES PENDIENTE DE CANAL Y ES AMENOS
									BigDecimal saldoPeriodMensaje =  actualizarContingente("A", cntSolicCont, mapDatosCont, serie, declaracion, mapCntSolAntSeries, codTransaccion );
									if(SunatNumberUtils.isLessThanZero(saldoPeriodMensaje)) {
										mapDatosContTmp = new HashMap<String, Object>();
										mapDatosContTmp.putAll(mapDatosCont);
										mapDatosContTmp.put("saldo",saldoPeriodMensaje);
										mapDatosContTmp.put("partida",SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
										mapDatosContTmp.put("codAduana",declaracion.getCodaduana() );
										listMensaje.add(mapDatosContTmp);
									}

								} else {

									if (codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA)){
										mapDatosCont.put("codTipoTrans", codTipoTrans); 
										if ( periodo != null ){
											mapDatosCont.put("perContingente", periodo.getPerContingente());
										}
										String yConj = msg.trim().length() > 0  ? " Y ":" ";
										msg =msg+" "+yConj+" SE AFECT� EL SALDO DE CONTINGENTE DEL TPI " +periodo.getCodTpi().toString() + " Y LA SUBPARTIDA " + 
												serie.getNumpartnandi().toString()+ " DEL PERIODO " + periodo.getPerContingente().toString(); 
									} else {
										mapDatosCont.put("codTipoTrans", null); 
									}

									if (!CollectionUtils.isEmpty(variablesIngreso)){
										if (variablesIngreso.get("COD_USUMODIF") == null) {
											variablesIngreso.put("COD_USUMODIF", agente);
										}
									} else {
										variablesIngreso = new HashMap<String, Object>();
										variablesIngreso.put("COD_USUMODIF", agente);
									}
									variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());

									BigDecimal saldoPeriodMensaje = saldo.subtract(cntSolicCont);	
									mapDatosCont.putAll(variablesIngreso);
									ingresaCtaCte("A", serie, mapDatosCont, declaracion, cntSolicCont);
									actualizarCantContPeriodo(mapDatosCont, saldoPeriodMensaje );

									if(SunatNumberUtils.isLessThanZero(saldoPeriodMensaje)) {
										mapDatosContTmp = new HashMap<String, Object>();
										mapDatosContTmp.putAll(mapDatosCont);
										mapDatosContTmp.put("saldo",saldoPeriodMensaje);
										mapDatosContTmp.put("partida",SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
										mapDatosContTmp.put("codAduana",declaracion.getCodaduana() );
										listMensaje.add(mapDatosContTmp);
									}

								}

							}
						}
						if ( (serieCtaCte != null) && !blCambioGrupo ) {
							if ( !"5".equals(tipoMargen) ) {
								if (serieCtaCte != null) {
									mapDatosCont.put("perContingente", serieCtaCte.getPerContingente());
									mapDatosCont.put("codTpi", serieCtaCte.getCodTpi());
									mapDatosCont.put("codPaisOrigen", serieCtaCte.getCodPaisOrigen());
									mapDatosCont.put("numGrupoCont", serieCtaCte.getNumGrupoCont());

									ContPeriodo periodo = obtenerContPeriodo(mapDatosCont);

									BigDecimal saldo = periodo.getCntSaldoCont();

									if (!CollectionUtils.isEmpty(variablesIngreso)){
										if (variablesIngreso.get("COD_USUMODIF") == null) {
											variablesIngreso.put("COD_USUMODIF", agente);
										}
									} else {
										variablesIngreso = new HashMap<String, Object>();
										variablesIngreso.put("COD_USUMODIF", agente);
									}

									variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());
									mapDatosCont.putAll(variablesIngreso);		   

									//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
									if ( !noRegistraElimina  ) {
										actualizaContCtaCteDespacho("L", serie, mapDatosCont, declaracion);
										actualizarCantContPeriodo(mapDatosCont, saldo.add(serieCtaCte.getCntContiSol()));
									}

								}
							} else {
								//En este caso se mantiene el tipo de margen 5 y tiene contingente entonces se actualiza el contingente
								if (contingentesUtil.isRectificaCantContingentes(serie, serieOld, mapDatosCont, listValidPorAlcohol)) {
									BigDecimal cntSoliContingente = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont , listValidPorAlcohol);
									BigDecimal cantContingente = contingentesUtil.getCantContingenteSolicitado(serieOld, mapDatosCont, listValidPorAlcohol);
									//Regularizacion no tiene los valores finales...

									if (codTransaccion.endsWith("07") ) {
										cantContingente = serieCtaCte.getCntContiSol() ;
									}

									mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
									mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));

									char pindproce = '0';
									try {
										ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
										contCtaCteDAO.spAJobContCabSol(Character.valueOf(pindproce));
									} catch (Exception e) {
										e.printStackTrace();
									}

									if (!CollectionUtils.isEmpty(variablesIngreso)){
										if (variablesIngreso.get("COD_USUMODIF") == null) {
											variablesIngreso.put("COD_USUMODIF", agente);
										}
									} else {
										variablesIngreso = new HashMap<String, Object>();
										variablesIngreso.put("COD_USUMODIF", agente);
									}

									variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());
									mapDatosCont.putAll(variablesIngreso);
									BigDecimal saldoPeriodo = new BigDecimal(0);
									//cuando se solicita dis
									if (codTransaccion.endsWith(COD_TRX_RECTIFICACION) ) {
										cantContingente = serieCtaCte.getCntContiSol() ;
										BigDecimal margenMonto = new BigDecimal(1);
										BigDecimal difMonto = SunatNumberUtils.diference(cntSoliContingente,serieCtaCte.getCntContiSol());
										if (SunatNumberUtils.isGreaterThanParam(difMonto, margenMonto)) {
											saldoPeriodo = actualizaSaldoContDespacho(cntSoliContingente, cantContingente, mapDatosCont, serie, declaracion, listError);
										} else {
											//PAS20175E220200043 Actualiza definitivamente cuando no tienen canal y es rectificaci�n
											if ( "".equals(declaracion.getDua().getCodCanal().trim() ) )  {
												saldoPeriodo = actualizaSaldoContDespacho(cntSoliContingente, cantContingente, mapDatosCont, serie, declaracion, listError);
											} else {
												//PAS20175E220200045 RSV PARA CONSIDERAR LOS SALDOS DE SERIES ANTERIORES ESPECIALMENTE EN LA RECTIFICACI�N Y ES PENDIENTE DE CANAL Y ES AMENOS
												BigDecimal cantSolContNuev = BigDecimal.ZERO;
												if(SunatNumberUtils.isGreaterThanZero(difMonto)){
													cantSolContNuev=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolAntSeries"));
													cantSolContNuev = cantSolContNuev.add(difMonto);
													mapCntSolAntSeries.put("cntSolAntSeries",cantSolContNuev);	
												}
												if(SunatNumberUtils.isLessThanZero(difMonto)){
													cantSolContNuev=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
													cantSolContNuev = cantSolContNuev.add(difMonto.abs());
													mapCntSolAntSeries.put("cntSolDevSeries",cantSolContNuev);	
												}
												//Indicador si se debe reservar aun si se ha agotado el saldo en una serie distinta a la primera serie.
												mapCntSolAntSeries.put("indSaldoAgoPriSer","0");
											}
										}
									} else {
										saldoPeriodo = actualizaSaldoContDespacho(cntSoliContingente, cantContingente, mapDatosCont, serie, declaracion, listError);
										if (codTipoTrans.endsWith(COD_TRX_RECT_OFI_VAL) || codTipoTrans.endsWith(COD_TRX_RECT_OFI_GRA)){
											String periodo =mapDatosCont.get("perContingente") == null ? " ":  mapDatosCont.get("perContingente").toString().trim(); 
											String yConj = msg.trim().length() > 0  ? " Y ":" ";
											msg =msg+" "+yConj+" SE AFECT� EL SALDO DE CONTINGENTE DEL TPI " +serie.getCodconvinter().toString() + " Y LA SUBPARTIDA " + serie.getNumpartnandi().toString()+
													" DEL PERIODO " + periodo; 
										}
									}

									if(SunatNumberUtils.isLessThanZero(saldoPeriodo)) {
										mapDatosContTmp = new HashMap<String, Object>();
										mapDatosContTmp.putAll(mapDatosCont);
										mapDatosContTmp.put("saldo",saldoPeriodo);
										mapDatosContTmp.put("partida",SunatStringUtils.lpad( serie.getNumpartnandi().toString(), 10, '0'));
										mapDatosContTmp.put("codAduana",declaracion.getCodaduana() );
										listMensaje.add(mapDatosContTmp);
									}



								}	      		    		
							}
						}


					}

					if ( msg.trim().length() > 0 ) {
						listError.add(ResponseMapManager.getWarningResponseMap("XXXX", msg));	 
					}

					// Aqui realizamos la transacci�n para las declaraciones eliminadas.
					//String codTransaccion = (String)variablesIngreso.get("codTransaccion");
					if (!CollectionUtils.isEmpty((List) variablesIngreso.get("lstDetDeclaraEliminada")))
					{
						List<Map<String, Object>> lstDetDeclaraEliminada = (List<Map<String, Object>>) variablesIngreso.get("lstDetDeclaraEliminada");
						DatoSerie serieOld = null;
						for (int i = 0; i < lstDetDeclaraEliminada.size(); i++)
						{
							HashMap SerieEliminada = (HashMap) lstDetDeclaraEliminada.get(i);
							tipoMargen = SerieEliminada.get("COD_TIPMARGEN") == null ? "":SerieEliminada.get("COD_TIPMARGEN").toString();              

							if ( "5".equals(tipoMargen) ) {

								for(DatoSerie serieBD:lstSeriesBd){
									if (SunatNumberUtils.isEqual(serieBD.getNumserie(), Integer.valueOf( SerieEliminada.get("NUM_SECSERIE").toString()) )) {
										serieOld =serieBD;
										break;
									}
								}

								if ( serieOld != null) {
									// datos de Cuenta Corriente de Contingencia para la serie
									Map<String,Object> mapDatosCont = new HashMap<String, Object>();
									mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
									mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
									mapDatosCont.put("codTipoDoc", "02");
									mapDatosCont.put("codEstado", "03");

									ContCtaCte serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serieOld,declaracion);


									if (serieCtaCte != null) {
										mapDatosCont.put("perContingente", serieCtaCte.getPerContingente());
										mapDatosCont.put("codTpi", serieCtaCte.getCodTpi());
										mapDatosCont.put("codPaisOrigen", serieCtaCte.getCodPaisOrigen());
										mapDatosCont.put("numGrupoCont", serieCtaCte.getNumGrupoCont());

										ContPeriodo periodo = obtenerContPeriodo(mapDatosCont);

										BigDecimal saldo = periodo.getCntSaldoCont();

										if (!CollectionUtils.isEmpty(variablesIngreso)){
											if (variablesIngreso.get("COD_USUMODIF") == null) {
												variablesIngreso.put("COD_USUMODIF", agente);
											}
										} else {
											variablesIngreso = new HashMap<String, Object>();
											variablesIngreso.put("COD_USUMODIF", agente);
										}

										variablesIngreso.put("FEC_MODIF", (new FechaBean()).getTimestamp());
										mapDatosCont.putAll(variablesIngreso);	
										//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA RECTIFICACION ELECTRONICA
										if ( !noRegistraElimina  ) {
											actualizaContCtaCteDespacho("L", serieOld, mapDatosCont, declaracion);
											actualizarCantContPeriodo(mapDatosCont, saldo.add(serieCtaCte.getCntContiSol()));
										}

									}
								}


							}		
						}
					}
					// parametros.put("lstDetDeclaraEliminada",lstDetDeclaraEliminada);	        

				}
			} else {
				// Si encuetra errores verifica si le toca reservar y lo reserva
				//procesaContingente
				List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
				listaErrores = procesaContingente(variablesIngreso, declaracion, listaErrores);
			}


			if (!CollectionUtils.isEmpty(listMensaje))
			{
				for (Map<String, Object> mapDatosEnvio :listMensaje) {
					if (!CollectionUtils.isEmpty(mapDatosEnvio)) {
						notificaSaldoCero(mapDatosEnvio);
					}
				}
			}


		}
		catch (Exception e)
		{
			e.printStackTrace();
			String message = "OCURRIO UN ERROR GRAVE";
			listError.add(getEmptyErrorMap(message));
		}



		/*if( saldoCero )
		{
	    	if (mapDatosContTmp != null ) {
	    		notificaSaldoCero(mapDatosContTmp);	
	    	}

		} */

		return listError;
	}	  


	private BigDecimal actualizaSaldoContDespacho(BigDecimal cntSoliContingente, BigDecimal cntContingente, Map<String, Object> mapDatosCont, DatoSerie serie, Declaracion declaracion, List<Map<String, String>> listError)
	{
		ContPeriodo contPeriodoActual = obtenerContPeriodo(mapDatosCont);
		BigDecimal cndDifAdicional=SunatNumberUtils.diference(cntSoliContingente, cntContingente);
		BigDecimal cntSaldoContPeriodo=contPeriodoActual.getCntSaldoCont();

		if (SunatNumberUtils.isLessThanZero(cndDifAdicional)) {
			actualizaContCtaCteDespachoCant(cntSoliContingente, serie, mapDatosCont, declaracion);
			BigDecimal cant = SunatNumberUtils.sum(cntSaldoContPeriodo, SunatNumberUtils.diference(cntContingente, cntSoliContingente));
			actualizarCantContPeriodo(mapDatosCont, cant);
			cntSaldoContPeriodo = cant;

		}

		if (SunatNumberUtils.isGreaterThanZero(cndDifAdicional))
		{
			if (SunatNumberUtils.isGreaterOrEqualsThanParam(cntSaldoContPeriodo, cndDifAdicional)) {
				actualizaContCtaCteDespachoCant(cntSoliContingente, serie, mapDatosCont, declaracion);
				BigDecimal cant = SunatNumberUtils.diference(cntSaldoContPeriodo, SunatNumberUtils.diference(cntSoliContingente, cntContingente));
				actualizarCantContPeriodo(mapDatosCont, cant);
				cntSaldoContPeriodo = cant;
			}
			else if (SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo)) {

				BigDecimal cantTransmitirEnSerie=SunatNumberUtils.sum(cntContingente, cntSaldoContPeriodo);
				String mensaje1 = "CANTIDAD DE CONTINGENTE SOLICITADO EXCEDE EL SALDO DISPONIBLE. DEBER� DESDOBLAR LA SERIE "+serie.getNumserie();
				String mensaje2 = "DECLARAR SERIE "+serie.getNumserie()+" CON "+cantTransmitirEnSerie+" CANTIDAD DE CONTINGENTE, TPI "+serie.getCodconvinter()+" Y TIPO DE MARGEN "+serie.getCodtipomarge();
				String mensaje3 = "DECLARAR NUEVA SERIE CON ("+ SunatNumberUtils.diference(cndDifAdicional,cntSaldoContPeriodo) +") SIN CONSIGNAR TPI "+serie.getCodconvinter()+" NI TIPO DE MARGEN "+serie.getCodtipomarge();
				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje1));
				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));
				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje3));
			}
			else
			{

				String mensaje1 = "CANTIDAD DE CONTINGENTE SOLICITADO PARA LA SERIE "+serie.getNumserie()+" EXCEDE EL SALDO DISPONIBLE";
				String mensaje2 ="LA SERIE "+serie.getNumserie()+" NO DEBER� SER MODIFICADA. AGREGAR NUEVA SERIE CON "+cndDifAdicional+" SIN CONSIGNAR TIPO DE MARGEN 5 ";
				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje1));
				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));


			}


		}

		return cntSaldoContPeriodo;
	}

	private void actualizaContCtaCteDespacho(String action, DatoSerie serie, Map<String, Object> mapDatosCont, Declaracion declaracion){
		ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		Map params = new HashMap();

		// Se cambia porque es un tipo 02 y es una declaraci�n con DUA
		params.put("ANN_DOC", declaracion.getNumdeclRef().getAnnprese());
		params.put("NUM_DOC",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));

		//    params.put("NUM_DOC", (String)mapDatosCont.get("numDoc"));
		//	    params.put("ANN_DOC", (String)mapDatosCont.get("annDoc"));
		params.put("COD_ADUANA_DOC", declaracion.getNumdeclRef().getCodaduana());
		params.put("COD_REGIMEN_DOC", declaracion.getNumdeclRef().getCodregimen());
		params.put("NUM_SERIE_DOC", serie.getNumserie());
		params.put("COD_TIPO_DOC", "02");
		/*branch hosorio ingreso 2011-029 hosorio*/
		params.put("COD_USUMODIF", (String)mapDatosCont.get("COD_USUMODIF"));
		params.put("FEC_MODIF", SunatDateUtils.getCurrentDate());
		/*branch hosorio ingreso 2011-029 hosorio fin*/

		if ("L".equals(action))
			params.put("COD_ESTADO", "02");
		else if ("A".equals(action))
			params.put("COD_ESTADO", "03");
		else if ("RT".equals(action))
			params.put("COD_ESTADO", "04");
		else if ("RD".equals(action))
			params.put("COD_ESTADO", "05");
		else if ("RS".equals(action)) {
			params.put("COD_ESTADO", "06");
		}
		contCtaCteDAO.updateByMap(params);
	}

	private void actualizaContCtaCteDespachoCant(BigDecimal cant, DatoSerie serie, Map<String, Object> mapDatosCont, Declaracion declaracion)
	{
		ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		Map params = new HashMap();
		params.put("CNT_CONTI_SOL", cant);
		params.put("ANN_DOC", declaracion.getNumdeclRef().getAnnprese());
		params.put("NUM_DOC",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
		//	    params.put("NUM_DOC", (String)mapDatosCont.get("numDoc"));
		//    params.put("ANN_DOC", (String)mapDatosCont.get("annDoc"));
		params.put("COD_ADUANA_DOC", declaracion.getNumdeclRef().getCodaduana());
		params.put("COD_REGIMEN_DOC", declaracion.getNumdeclRef().getCodregimen());
		params.put("NUM_SERIE_DOC", serie.getNumserie());
		params.put("COD_TIPO_DOC", "02");
		/*branch ingreso 2011-029 hosorio */
		params.put("COD_USUMODIF", (String)mapDatosCont.get("COD_USUMODIF"));
		params.put("FEC_MODIF", SunatDateUtils.getCurrentDate());
		/*branch ingreso 2011-029 fin */

		contCtaCteDAO.updateByMap(params);
	}

	private ContPeriodo obtenerContPeriodo(Map<String, Object> mapDatosCont)
	{
		ContPeriodoDAO contPeriodoDAO = fabricaDeServicios.getService("contPeriodoDAO");
		ContPeriodoCriteria contPeriodoCriteria = new ContPeriodoCriteria();
		ContPeriodoCriteria.Criteria criteria = contPeriodoCriteria.createCriteria();
		criteria.andPerContingenteEqualTo((String)mapDatosCont.get("perContingente"));
		//criteria.andCodTpiEqualTo((String)mapDatosCont.get("codTpi"));
		criteria.andCodTpiEqualTo(SunatStringUtils.toStringObj(mapDatosCont.get("codTpi"))  );
		criteria.andCodPaisOrigenEqualTo((String)mapDatosCont.get("codPaisOrigen"));
		criteria.andNumGrupoContEqualTo(SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
		List contPeriodoList = contPeriodoDAO.selectByContPeriodoCriteria(contPeriodoCriteria);

		if (!CollectionUtils.isEmpty(contPeriodoList)) {
			return (ContPeriodo)contPeriodoList.get(0);
		}
		return null;
	}

	private ContPeriodo obtenerContPeriodoFecha(Map<String, Object> mapDatosCont)
	{
		ContPeriodoDAO contPeriodoDAO = fabricaDeServicios.getService("contPeriodoDAO");
		ContPeriodoCriteria contPeriodoCriteria = new ContPeriodoCriteria();
		ContPeriodoCriteria.Criteria criteria = contPeriodoCriteria.createCriteria();

		criteria.andFecFinPerGreaterThanOrEqualTo((Date)mapDatosCont.get("fechaNumeracion"));
		criteria.andFecIniPerLessThanOrEqualTo((Date)mapDatosCont.get("fechaNumeracion"));
		//criteria.andPerContingenteEqualTo((String)mapDatosCont.get("perContingente"));
		//criteria.andCodTpiEqualTo((String)mapDatosCont.get("codTpi"));
		criteria.andCodTpiEqualTo(SunatStringUtils.toStringObj(mapDatosCont.get("codTpi"))  );
		criteria.andCodPaisOrigenEqualTo((String)mapDatosCont.get("codPaisOrigen"));
		criteria.andNumGrupoContEqualTo(SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
		List contPeriodoList = contPeriodoDAO.selectByContPeriodoCriteria(contPeriodoCriteria);

		if (!CollectionUtils.isEmpty(contPeriodoList)) {
			return (ContPeriodo)contPeriodoList.get(0);
		}
		return null;
	}

	private void actualizarCantContPeriodo(Map<String, Object> mapDatosCont, BigDecimal cant)
	{
		ContPeriodoDAO contPeriodoDAO = fabricaDeServicios.getService("contPeriodoDAO");
		Map params = new HashMap();
		params.put("CNT_SALDO_CONT", cant);
		params.put("PER_CONTINGENTE", mapDatosCont.get("perContingente").toString().trim());
		params.put("COD_TPI", mapDatosCont.get("codTpi").toString().trim());
		params.put("COD_PAIS_ORIGEN", mapDatosCont.get("codPaisOrigen").toString().trim());
		params.put("NUM_GRUPO_CONT", SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
		params.put("COD_USUMODIF", mapDatosCont.get("COD_USUMODIF").toString().trim());
		params.put("FEC_MODIF", SunatDateUtils.getCurrentDate());
		/* olunar - 581 Cuando el saldo final del periodo es cero */
		if(SunatNumberUtils.isEqualToZero(cant)) params.put("FEC_FINVIG", SunatDateUtils.getCurrentDate());
		/* fin */
		contPeriodoDAO.updateByMap(params);
	}

	private Map<String, String> getEmptyErrorMap(String mensaje) {
		Map map = new HashMap();

		map.put("codError", "XXXXX");
		map.put("desError", mensaje);
		map.put("codTipAlerta", "W");
		return map;
	}	
	/*branch  ingreso 2011-029 diligencia despacho fin */


	/**
	 * Para la atencion del contingente cuando se rechaza la solicitud de rectificacion
	 * 
	 * @param prmContingente
	 * @return
	 */
	public void procesarContingenteRectificacionElectronica(Map<String, Object> prmContingente, List<Map<String, Object>> lstSeries) throws ServiceException{
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map> listError = new ArrayList();
		boolean indImProcedente = prmContingente.get("improcedente").toString().trim().equals("T")? false : true;
		if ( !indImProcedente) {
			Declaracion declaracionBD = contingentesUtil.getDeclaracionBD(prmContingente);  
			prmContingente.put("declaracionNue", declaracionBD );
			prmContingente.put("declaracionBD", declaracionBD );
		}
		Declaracion declaracionBD = prmContingente.get("declaracionBD") == null ? null: (Declaracion) prmContingente.get("declaracionBD");
		Declaracion declaracion = (Declaracion) prmContingente.get("declaracionNue")== null ? null: (Declaracion) prmContingente.get("declaracionNue") ;
		if (declaracion == null) {
			declaracion = declaracionBD;
		}

		log.debug(" INICIO ERROR ANULACION DE RECTIFICACION DE CONTINGENTE  ERROR - procesarContingenteRectificacionElectronica ");

		try {
			Map<String, Object> mapDeclaracion = (HashMap<String, Object>) prmContingente.get("declaracion");
			HashMap<String, Object> params = new HashMap(); 
			Map<String, Object> prmContCtaCte = new HashMap();
			String indRectifica = "";

			Map<String, Object>  mapRespuesta = contingentesUtil.getListContingenteDeclaracion(declaracion,prmContingente );
			List<Map<String, Object>> listContingenteDeclaracion = (List<Map<String, Object>>) mapRespuesta.get("listJoinContingente");
			List<Map<String,Object>> listValidPorAlcohol=(List<Map<String, Object>>) mapRespuesta.get("listValidPorAlcohol");
			List<ContCtaCte> lstContCtaCte = contingentesUtil.getContCtaCteAll(declaracionBD.getDua().getListSeries(), declaracion);

			if (!CollectionUtils.isEmpty(declaracionBD.getDua().getListSeries())) {

				String strLstSeries = "";
				//Seteamos los parametros de actualizacion
				params.put("ANN_DOC", mapDeclaracion.get("ANN_PRESEN"));
				params.put("NUM_DOC", SunatStringUtils.lpad(mapDeclaracion.get("NUM_DECLARACION").toString().trim(),6,'0'));
				params.put("COD_ADUANA_DOC", prmContingente.get("COD_ADUANA"));
				params.put("COD_REGIMEN_DOC", mapDeclaracion.get("COD_REGIMEN"));
				params.put("COD_TIPO_DOC", "02");
				params.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
				params.put("FEC_MODIF", mapDeclaracion.get("FEC_MODIF"));
				params.put("perContingente", mapDeclaracion.get("ANN_PRESEN"));

				BigDecimal cantSolicitado = new BigDecimal("0"); 
				BigDecimal cantDevuelto = new BigDecimal("0");
				int newCodConvInter = 0;
				int codConvInter = 0;

				List<ContPeriodo> lstGContActualizados = new ArrayList<ContPeriodo>();
				String codTpi = "";
				for (DatoSerie serie :declaracion.getDua().getListSeries()) {
					newCodConvInter = 0;
					codConvInter = 0;
					String tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
					if ( tipoMargen.trim().equals("5") ) {

						if (!CollectionUtils.isEmpty((List) prmContingente.get("listConvenioSerie")))
						{
							List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) prmContingente.get("listConvenioSerie");
							for (int i = 0; i < lstConvenioSerie.size(); i++)
							{
								HashMap Convenio = (HashMap) lstConvenioSerie.get(i);
								if (Convenio.get("NUM_SECSERIE").toString().trim().equals(serie.getNumserie().toString().trim())) {
									if (Convenio.get("COD_TIPCONVENIO").toString().equals("I")) {
										if(!"1".equals((String)Convenio.get("IND_DEL"))){
											if(Convenio.get("COD_CONVENIO")!=null){
												newCodConvInter = Integer.parseInt( Convenio.get("COD_CONVENIO").toString().trim());
											}
										} else if("1".equals((String)Convenio.get("IND_DEL"))){
											newCodConvInter = 0;
										}
									} 
								} 
							}

							if ( newCodConvInter != codConvInter) {
								serie.setCodconvinter(newCodConvInter);	
							}
						} 
						if(serie.getCodconvinter().toString().trim().equals("812"))
						{										
							PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
							boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, 
									serie.getCodconvinter().toString().trim(),serie.getCodpaisorige());
							if (existePuerto){
								serie.setCodpaisorige("UE");
							}
						} 

						for ( Map<String, Object> mapContingente: listContingenteDeclaracion ) {
							boolean valorCont1 = SunatStringUtils.lpad( mapContingente.get("numSubpartida").toString().trim(), 10, '0').equals(													  
									SunatStringUtils.lpad( serie.getNumpartnandi().toString()  , 10, '0'));
							boolean valorCont2 = mapContingente.get("codTpi").toString().trim().equals( serie.getCodconvinter().toString().trim() ) ;
							boolean valorCont3 = mapContingente.get("codPaisOrigen").toString().trim().equals( serie.getCodpaisorige().toString().trim());
							if ( valorCont1 && valorCont2  && valorCont3 ) {

								for (ContCtaCte cont : lstContCtaCte) {
									//Tiene cuenta de contingente
									if (cont.getNumSerieDoc().toString().trim().equals(serie.getNumserie().toString().trim())) {

										boolean valorContx1 =   mapContingente.get("codTpi").toString().trim().equals(cont.getCodTpi().toString().trim() ) ;
										boolean valorContx2 =   mapContingente.get("codPaisOrigen").toString().trim().equals(cont.getCodPaisOrigen().toString().trim()) ;
										boolean valorContx3 =   mapContingente.get("perContingente").toString().trim().equals(cont.getPerContingente().toString().trim() );
										boolean valorContx4 =  mapContingente.get("numGrupoCont").toString().trim().equals(cont.getNumGrupoCont().toString().trim());


										boolean valorCont = valorContx1 && valorContx2 && valorContx3 && valorContx4;	 

										if ( !valorCont   ) {
											//Se procede a liberar 

											params.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
											params.put("NUM_CTACTE",cont.getNumCtaCte());
											params.put("ANN_CTACTE", cont.getAnnCtaCte());
											params.put("codTpi", cont.getCodTpi());

											Map<String, Object> mapContActualizar =  new HashMap(); 
											mapContActualizar.put("ANN_PRESEN", declaracion.getDua().getAnnpresen().toString());
											mapContActualizar.put("PERCONTINGENTE",  cont.getPerContingente() );
											mapContActualizar.put("COD_CONVENIO", cont.getCodTpi());
											mapContActualizar.put("NUM_SECSERIE", serie.getNumserie().toString().trim());
											mapContActualizar.put("COD_PAISORIGEN",cont.getCodPaisOrigen());
											mapContActualizar.put("CNT_CONTI_SOL", cont.getCntContiSol());
											mapContActualizar.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
											mapContActualizar.put("IND_RECTIFICA", "R");
											mapContActualizar.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
											mapContActualizar.put("FEC_MODIF", mapDeclaracion.get("FEC_MODIF"));
											mapContActualizar.put("FEC_NUMERACION", declaracionBD.getDua().getFecNumeracion());
											calcularSaldoGrpContActualizados(lstGContActualizados, listError,mapContActualizar,"ACTU");
											params.put("NUM_SERIE_DOC", serie.getNumserie().toString().trim());
											params.put("action", "L");
											actualizaContCtaCteDespachoRecti(params);	
											break;
										} else {
											// Se verifica si hubo cambios entre la serie y el 

											BigDecimal cntSolicCont =  contingentesUtil.getCantContingenteSolicitado(serie, mapContingente, listValidPorAlcohol);
											BigDecimal margenMonto = new BigDecimal(-1);
											BigDecimal difMonto = SunatNumberUtils.diference(cntSolicCont,cont.getCntContiSol());
											BigDecimal saldoFinalContingente = new BigDecimal(0);

											if (SunatNumberUtils.isLessThanParam(difMonto, margenMonto)) {
												//cambia monto a menos entonces se resta el monto asignado inicialmente y se resta del contingentes a liberar entonces se suma al mto final 
												saldoFinalContingente = SunatNumberUtils.diference(cont.getCntContiSol() , cntSolicCont);
												params.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
												params.put("NUM_CTACTE",cont.getNumCtaCte());
												params.put("ANN_CTACTE", cont.getAnnCtaCte());
												params.put("codTpi", cont.getCodTpi());

												Map<String, Object> mapContActualizar =  new HashMap(); 
												mapContActualizar.put("ANN_PRESEN", declaracion.getDua().getAnnpresen().toString());
												// mapContActualizar.put("COD_CONVENIO", mapPkDetSolRecti.get("COD_CONVENIO").toString().trim());
												mapContActualizar.put("PERCONTINGENTE",  cont.getPerContingente() );
												mapContActualizar.put("COD_CONVENIO", cont.getCodTpi());
												mapContActualizar.put("NUM_SECSERIE", serie.getNumserie().toString().trim());
												mapContActualizar.put("COD_PAISORIGEN",cont.getCodPaisOrigen());
												//CNT_CONTI_SOL
												mapContActualizar.put("CNT_CONTI_SOL", saldoFinalContingente);
												mapContActualizar.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
												mapContActualizar.put("IND_RECTIFICA", "R"	);
												mapContActualizar.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
												mapContActualizar.put("FEC_MODIF", mapDeclaracion.get("FEC_MODIF"));
												mapContActualizar.put("FEC_NUMERACION", declaracionBD.getDua().getFecNumeracion());
												calcularSaldoGrpContActualizados(lstGContActualizados, listError,mapContActualizar,"ACTU");
												params.put("NUM_SERIE_DOC", serie.getNumserie().toString().trim());

												mapContingente.put("numDoc", SunatStringUtils.lpad(mapDeclaracion.get("NUM_DECLARACION").toString().trim(),6,'0'));
												mapContingente.put("annDoc", mapDeclaracion.get("ANN_PRESEN"));
												params.put("action", "A");
												params.put("NUM_SERIE_DOC", serie.getNumserie().toString().trim());
												params.put("CNT_CONTI_SOL", cntSolicCont);
												mapContingente.put("codTipoTrans", COD_TIPO_DILIG_REGU_RECT);
												actualizaContCtaCteDespachoRecti(params);	

											}


										}
									} 
								}
								break;
							}
						} 
					} else {
						//Aqui se libera porque no hay TipoMargen 5 pero si la cuenta corriente
						for (ContCtaCte cont : lstContCtaCte) {
							//Tiene cuenta de contingente
							if (cont.getNumSerieDoc().toString().trim().equals(serie.getNumserie().toString().trim())) {
								params.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
								params.put("NUM_CTACTE",cont.getNumCtaCte());
								params.put("ANN_CTACTE", cont.getAnnCtaCte());
								params.put("codTpi", cont.getCodTpi());
								Map<String, Object> mapContActualizar =  new HashMap(); 
								mapContActualizar.put("ANN_PRESEN",  declaracion.getDua().getAnnpresen().toString());
								mapContActualizar.put("PERCONTINGENTE",  cont.getPerContingente() );
								mapContActualizar.put("COD_CONVENIO", cont.getCodTpi());
								mapContActualizar.put("NUM_SECSERIE",serie.getNumserie().toString().trim());
								mapContActualizar.put("COD_PAISORIGEN",cont.getCodPaisOrigen());
								mapContActualizar.put("CNT_CONTI_SOL", cont.getCntContiSol());
								mapContActualizar.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
								mapContActualizar.put("IND_RECTIFICA", "R"	);
								mapContActualizar.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
								mapContActualizar.put("FEC_MODIF", mapDeclaracion.get("FEC_MODIF"));
								mapContActualizar.put("FEC_NUMERACION", declaracionBD.getDua().getFecNumeracion());
								calcularSaldoGrpContActualizados(lstGContActualizados, listError,mapContActualizar,"ACTU");
								params.put("NUM_SERIE_DOC", serie.getNumserie().toString().trim());
								params.put("action", "L");
								actualizaContCtaCteDespachoRecti(params);
								break;
							}
						}
					}
				} 


				//Para aquellos casos que se elimina la serie y no existe pero si esta en la ctacte 

				lstContCtaCte = contingentesUtil.getContCtaCteAll(declaracionBD.getDua().getListSeries(), declaracion);
				boolean encuentra = false;
				if (!CollectionUtils.isEmpty(lstContCtaCte) ) {
					for (ContCtaCte cont : lstContCtaCte) {
						encuentra = false;
						for (DatoSerie serie :declaracion.getDua().getListSeries()) {
							if (cont.getNumSerieDoc().toString().trim().equals(serie.getNumserie().toString().trim())) {
								encuentra = true;
								break;
							}
						}

						if( !encuentra ) {
							params.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
							params.put("NUM_CTACTE",cont.getNumCtaCte());
							params.put("ANN_CTACTE", cont.getAnnCtaCte());
							params.put("codTpi", cont.getCodTpi());
							Map<String, Object> mapContActualizar =  new HashMap(); 
							mapContActualizar.put("ANN_PRESEN",  declaracion.getDua().getAnnpresen().toString());
							mapContActualizar.put("PERCONTINGENTE",  cont.getPerContingente() );
							mapContActualizar.put("COD_CONVENIO", cont.getCodTpi());
							mapContActualizar.put("NUM_SECSERIE", cont.getNumSerieDoc() );
							mapContActualizar.put("COD_PAISORIGEN",cont.getCodPaisOrigen());
							mapContActualizar.put("CNT_CONTI_SOL", cont.getCntContiSol());
							mapContActualizar.put("NUM_GRUPO_CONT", cont.getNumGrupoCont());
							mapContActualizar.put("IND_RECTIFICA", "R"	);
							mapContActualizar.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
							mapContActualizar.put("FEC_MODIF", mapDeclaracion.get("FEC_MODIF"));
							mapContActualizar.put("FEC_NUMERACION", declaracionBD.getDua().getFecNumeracion());
							calcularSaldoGrpContActualizados(lstGContActualizados, listError,mapContActualizar,"ACTU");
							params.put("NUM_SERIE_DOC", cont.getNumSerieDoc());
							params.put("action", "L");
							actualizaContCtaCteDespachoRecti(params);
						}
					}
				}

				HashMap<String, Object> prmDevCont = new HashMap<String, Object>();

				prmDevCont.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
				prmDevCont.put("FEC_MODIF", SunatDateUtils.getCurrentDate());

				//Si no existen errores actualizamos los saldos de los contingentes afectados
				if (!CollectionUtils.isEmpty(lstGContActualizados) && CollectionUtils.isEmpty(listError)){

					params.put("COD_USUMODIF", prmContingente.get("COD_USUMODIF"));
					params.put("FEC_MODIF", SunatDateUtils.getCurrentDate());

					for (ContPeriodo contPeriodo : lstGContActualizados) {
						params.put("perContingente", contPeriodo.getPerContingente());
						params.put("codTpi", contPeriodo.getCodTpi());
						params.put("codPaisOrigen", contPeriodo.getCodPaisOrigen());
						params.put("numGrupoCont", new Integer(contPeriodo.getNumGrupoCont().intValue()));

						actualizarCantContPeriodo(params, contPeriodo.getCntSaldoCont());
					}
				}

			}

			log.debug(" FIN ERROR ANULACION DE RECTIFICACION DE CONTINGENTE  ERROR - procesarContingenteRectificacionElectronica ");
		} catch (Exception e) {
			log.error(this.toString() + " ERRRRROR ANULACION DE RECTIFICACION DE CONTINGENTE  procesarContingenteRectificacionElectronica  - ERROR: " + e);
			throw new ServiceException(this, e);
		}

		//BigDecimal saldo = new BigDecimal(0);	
		//Map<String, Object> mapDatosContTmp = new HashMap<String, Object>();
		/*    if(SunatNumberUtils.isLessOrEqualsThanZero(saldo))
		{
			notificaSaldoCero(mapDatosContTmp);
		}
		 */
		return;
	}




	private void calcularSaldoGrpContActualizados(List<ContPeriodo> lstGAcum, List<Map> listError, Map<String, Object> prmDatos, String tipoRegistro ){

		String perContingente = SunatStringUtils.toStringObj(prmDatos.get("PERCONTINGENTE"));
		String codTpi = SunatStringUtils.toStringObj(prmDatos.get("COD_CONVENIO"));
		String codPaisOrigen = SunatStringUtils.toStringObj(prmDatos.get("COD_PAISORIGEN"));
		Integer numGrupoCont = SunatNumberUtils.toInteger( prmDatos.get("NUM_GRUPO_CONT"));
		String numSerie = SunatStringUtils.toStringObj(prmDatos.get("NUM_SECSERIE"));
		BigDecimal cantidad =  SunatNumberUtils.toBigDecimal(  prmDatos.get("CNT_CONTI_SOL"));
		// String indRectifica = SunatStringUtils.toStringObj(prmDatos.get("IND_RECTIFICA"));



		Map<String, Object> prmSaldo = new HashMap<String, Object>(); 
		boolean encontrado = false;
		boolean saldoNegativo = false;
		for (ContPeriodo contPeriodo : lstGAcum) {
			if (contPeriodo.getPerContingente().trim().equals(perContingente.trim()) && 
					contPeriodo.getCodTpi().trim().equals(codTpi.trim()) &&
					contPeriodo.getCodPaisOrigen().trim().equals(codPaisOrigen.trim()) &&
					contPeriodo.getNumGrupoCont().intValue() == numGrupoCont.intValue()) {

				if ( tipoRegistro.trim().equals("RECU")){
					// Cuando es anulado no hace nada porque en la rectificaci�n electr�nica no hizo nada
					if ( !prmDatos.get("IND_RECTIFICA").toString().trim().equals(Constantes.COD_RECTI_ANULADO)){
						contPeriodo.setCntSaldoCont(contPeriodo.getCntSaldoCont().subtract(cantidad));
						saldoNegativo = SunatNumberUtils.isLessThanZero(contPeriodo.getCntSaldoCont());
					}

				} else {
					// Cuando es anulado no hace nada porque en la rectificaci�n electr�nica no hizo nada
					if ( !prmDatos.get("IND_RECTIFICA").toString().trim().equals(Constantes.COD_RECTI_ANULADO)){
						contPeriodo.setCntSaldoCont(contPeriodo.getCntSaldoCont().add(cantidad));
						saldoNegativo = SunatNumberUtils.isLessThanZero(contPeriodo.getCntSaldoCont());
					}
				}
				encontrado = true;
				break;
			} 
		}

		if (!encontrado) {
			prmSaldo.put("perContingente", perContingente);
			prmSaldo.put("codTpi", codTpi);
			prmSaldo.put("codPaisOrigen", codPaisOrigen);
			prmSaldo.put("numGrupoCont", numGrupoCont);
			prmSaldo.put("numGrupoCont", numGrupoCont);
			ContPeriodo nvoCont = obtenerContPeriodo(prmSaldo);

			if (nvoCont == null    ) {
				perContingente = SunatStringUtils.toStringObj(prmDatos.get("ANN_PRESEN"));
				prmSaldo.put("perContingente", perContingente);
				prmSaldo.put("codTpi", codTpi);
				prmSaldo.put("codPaisOrigen", codPaisOrigen);
				prmSaldo.put("numGrupoCont", numGrupoCont);
				prmSaldo.put("numGrupoCont", numGrupoCont);
				nvoCont = obtenerContPeriodo(prmSaldo);
			}



			if (nvoCont != null    ) {
				if ( tipoRegistro.trim().equals("RECU")){
					// Cuando es anulado no hace nada porque en la rectificaci�n electr�nica no hizo nada
					if ( !prmDatos.get("IND_RECTIFICA").toString().trim().equals(Constantes.COD_RECTI_ANULADO)){
						nvoCont.setCntSaldoCont(nvoCont.getCntSaldoCont().subtract(cantidad));
						saldoNegativo = SunatNumberUtils.isLessThanZero(nvoCont.getCntSaldoCont());
						lstGAcum.add(nvoCont);
					}

				} else {
					// Cuando es anulado no hace nada porque en la rectificaci�n electr�nica no hizo nada
					if ( !prmDatos.get("IND_RECTIFICA").toString().trim().equals(Constantes.COD_RECTI_ANULADO)){
						nvoCont.setCntSaldoCont(nvoCont.getCntSaldoCont().add(cantidad));
						saldoNegativo = SunatNumberUtils.isLessThanZero(nvoCont.getCntSaldoCont());
						lstGAcum.add(nvoCont);
					}

				}

			}
		}

		if (saldoNegativo) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08805", 
					new String[]{numSerie, String.valueOf( cantidad ) }));
		}

	}



	private void actualizaContCtaCteDespachoRecti(HashMap params){
		ContCtaCteDAO contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		if ("L".equals(params.get("action").toString().trim())){
			params.put("COD_ESTADO", "02");
		} else if ("A".equals(params.get("action").toString().trim())) {
			params.put("COD_ESTADO", "03");
		} else if ("RT".equals(params.get("action").toString().trim())) {
			params.put("COD_ESTADO", "04");
		} else if ("RD".equals(params.get("action").toString().trim())) {
			params.put("COD_ESTADO", "05");
		} else if ("RS".equals(params.get("action").toString().trim())) {
			params.put("COD_ESTADO", "06");
		}

		params.put("FEC_MODIF", SunatDateUtils.getCurrentDate());
		contCtaCteDAO.updateByMap(params);
	}
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}  */

	private List<ContPeriodo> obtenerLstContPeriodo(Map<String, Object> mapDatosCont)
	{
		ContPeriodoDAO contPeriodoDAO = fabricaDeServicios.getService("contPeriodoDAO");
		ContPeriodoCriteria contPeriodoCriteria = new ContPeriodoCriteria();
		ContPeriodoCriteria.Criteria criteria = contPeriodoCriteria.createCriteria();
		criteria.andPerContingenteGreaterThanOrEqualTo((String)mapDatosCont.get("perContingente"));
		//criteria.andCodTpiEqualTo((String)mapDatosCont.get("codTpi"));
		criteria.andCodTpiEqualTo(SunatStringUtils.toStringObj(mapDatosCont.get("codTpi"))  );
		criteria.andCodPaisOrigenEqualTo((String)mapDatosCont.get("codPaisOrigen"));
		criteria.andNumGrupoContEqualTo(SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
		contPeriodoCriteria.setOrderByClause("PER_CONTINGENTE");
		return contPeriodoDAO.selectByContPeriodoCriteria(contPeriodoCriteria);
	}
/*
	public void setCatalogoAyudaService(
			CatalogoAyudaService catalogoAyudaService)
	{
		this.catalogoAyudaService = catalogoAyudaService;
	}
*/
}