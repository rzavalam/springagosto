package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.medidafrontera;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;

public class ValMedidaFronteraEERServiceImpl  extends IngresoAbstractServiceImpl implements ValMedidaFronteraEERService {
	
	protected final Log logMedidaFronteraEER = LogFactory.getLog(getClass());
	
	public List<Map<String,String>> valIndicador(Declaracion declaracion, String codCategoria) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			for(DatoSerie serie : declaracion.getDua().getListSeries()) {
				if(serie.getListIndicadores() != null && !serie.getListIndicadores().isEmpty()) {
					for (DatoIndicadores indicador : serie.getListIndicadores()) {
						if (ConstantesDataCatalogo.CODIGO_INDICADOR_EER_MEDIDA_FRONTERA.equals(indicador.getCodigoIndicador())) {
							listError.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70116"));
							return listError;
						}
					}
				}
			}
		}
		/*
	      RN 1951
	      https://www.unece.org/trade/untdid/d17b/tred/tred4451.htm
	      R1951
	      si codCategoria es diferente a "03"
	      Obtenemos los indicadores de la primera serie
	      serie = declaracion.getDUA().getListSeries().get(0)
	      Obtenemos los indicadores de medidas de frontera
	      listIndicadores = serie.getListIndicadores();
	      Si listIndicadores contiene 45 (cod_catalogo = '302' , cod_datacat = '45' )
	         Entonces se emite el E31
	      
	   */
		return listError;
	}
}