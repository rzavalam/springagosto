package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


public class ValidadorCierreOtros2 extends ValidadorCierreAbstract{

  private static final String CATALOGO_UNID_COMER_CIERRES_OTROS = "568";
  private static final String COD_LLAVE = "LLA";
  private static final String COD_CINTA_CREMALLERA = "CRE";
  private static final String TIPO_VALOR_CATALOGO = "0";
  private static final String SPN_METRO = "9607200000";
  private static final String UNIDAD_METRO = "M";
  private static final String SPN_LLAVE = "9607200000";
  private static final String FORMATO ="[\\d]{1,2}";
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{
	List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	
	/*se agreg� el if de condicion vacio errores de estructura debido a que los metodos son los mismos
	 * que en caso de cremalleras, y se detecta que la casilla de composicion de la cinta CI0203 al ser
	 * campo condicionado presenta evaluacion de estructura previa de pertenencia del valor de la casilla
	 * con el cat�logo asociado, y luego conteja la relacion con la condicional en la regla de negocio
	 * PAS20165E220200137 -M_SNADE257-798
	 */
	lstErroresDescrMin.addAll(validarEstructura(objeto));
	   if (CollectionUtils.isEmpty(lstErroresDescrMin)){ 
			//lstErroresDescrMin.addAll(validarEstructura(objeto));
			lstErroresDescrMin.addAll(validarUnidadComercial(objeto,dua));
			lstErroresDescrMin.addAll(validarNombreComercial(objeto));
			lstErroresDescrMin.addAll(validarMarcaComercial(objeto));
			lstErroresDescrMin.addAll(validarModelo(objeto));
			lstErroresDescrMin.addAll(validarComposicionCinta(objeto));
			lstErroresDescrMin.addAll(validarPresentacionCinta(objeto));
			lstErroresDescrMin.addAll(validarMaterialDientes(objeto));
			lstErroresDescrMin.addAll(validarTamanoDientes(objeto));
			lstErroresDescrMin.addAll(validarTipoLlave(objeto));
			lstErroresDescrMin.addAll(validarMaterialLlave(objeto));
			lstErroresDescrMin.addAll(validarTamanoLlave(objeto, dua));
	   }
 	return lstErroresDescrMin;
  }
  
  //R850: variacion si es nombre comrcial CRE, y la partida es 960720000 la unidad debe ser el metro
  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract objeto, Declaracion dua){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

	  DatoItem item = obtenerItem(objeto, dua); 
	  CierreOtros cierreOtros = (CierreOtros) objeto; 
	  String datoAValidar = item.getCodunidcomer().trim();
	  String subPartida = item.getNumpartnandi().toString();
	  String nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  
	  Object[] demasArgumentosMSJError = new Object[] { cierreOtros.getNumsecprove(),cierreOtros.getNumsecfact(),
			  cierreOtros.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
	  
	 if(subPartida.equals(SPN_METRO) && !UNIDAD_METRO.equals(datoAValidar) && nombrecomercial.equals(COD_CINTA_CREMALLERA)){
		  ErrorDescrMinima error = obtenerError("33009",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);//se corrige mensaje	   	  
		  lstErroresDescrMin.add(error); //33009 - Mensaje: Unidad de medida debe ser en metro
	 }
	 
	 if(subPartida.equals(SPN_METRO) && UNIDAD_METRO.equals(datoAValidar) && !nombrecomercial.equals(COD_CINTA_CREMALLERA)){
		  ErrorDescrMinima error = obtenerError("33010",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);//se corrige mensaje	   	  
		  lstErroresDescrMin.add(error); //33010 - Mensaje: Unidad de medida NO debe ser en metro
	 }	 
	  return lstErroresDescrMin;	  
	}
  
  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarModelo(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarComposicionCinta(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

	  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String nombrecomercial, datoAValidar,material;	  
	  if(cierreOtros.getComposicionCinta() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreOtros.getComposicionCinta().getValtipdescri().trim();  
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  if(cierreOtros.getMaterialDientes() == null)
		  material = "";
	  else
		  material = cierreOtros.getMaterialDientes().getValtipdescri().trim();
	  if (COD_CINTA_CREMALLERA.equalsIgnoreCase(nombrecomercial)){
		  if(noEstaEnCatalogo(datoAValidar,"M1",fechaVigencia)){
		   	  ErrorDescrMinima error = obtenerError("31792",cierreOtros.getComposicionCinta());
		   	  lstErroresDescrMin.add(error);			  
		  }
	  }
	  else{
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
			  ErrorDescrMinima error = obtenerError("31873",cierreOtros.getComposicionCinta());
			  lstErroresDescrMin.add(error);			  
		  }			  
	  }
	  if (COD_LLAVE.equalsIgnoreCase(nombrecomercial)){
		  if (TIPO_VALOR_CATALOGO.equals(cierreOtros.getMaterialDientes().getCodtipvalor())){
			  if(noEstaEnCatalogo(material,"CB",fechaVigencia)){
			   	  ErrorDescrMinima error = obtenerError("31875",cierreOtros.getComposicionCinta());
			   	  lstErroresDescrMin.add(error);			  
			  }
		  }
	  }
	  return lstErroresDescrMin;
	}
  
  //R845: variacion casilla de presentacion de la cinta es valor texto solamente.
  public List<ErrorDescrMinima> validarPresentacionCinta(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	 /* Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String nombrecomercial,datoAValidar,tipoLlave;	  
	  if(cierreOtros.getPresentacionCinta() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreOtros.getPresentacionCinta().getValtipdescri().trim();  
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  if(cierreOtros.getTipoLlave() == null)
		  tipoLlave = "";
	  else
		  tipoLlave = cierreOtros.getTipoLlave().getValtipdescri().trim();

	  if (COD_CINTA_CREMALLERA.equalsIgnoreCase(nombrecomercial)){
		  if(noEstaEnCatalogo(datoAValidar,"M3", fechaVigencia)){
		   	  ErrorDescrMinima error = obtenerError("31794",cierreOtros.getPresentacionCinta());
		   	  lstErroresDescrMin.add(error);			  
		  }
	  }
	  else{
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
			  ErrorDescrMinima error = obtenerError("31874",cierreOtros.getPresentacionCinta());
			  lstErroresDescrMin.add(error);			  
		  }			  
	  }
	  if (COD_LLAVE.equalsIgnoreCase(nombrecomercial)){
		  if(noEstaEnCatalogo(tipoLlave,"CC", fechaVigencia)){
		   	  ErrorDescrMinima error = obtenerError("31793",cierreOtros.getPresentacionCinta());
		   	  lstErroresDescrMin.add(error);			  
		  }
	  }*/
	  return lstErroresDescrMin;	  
	}
  
  public List<ErrorDescrMinima> validarMaterialDientes(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String nombrecomercial,datoAValidar;	  
	  if(cierreOtros.getMaterialDientes() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreOtros.getMaterialDientes().getValtipdescri().trim();  
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  if (COD_CINTA_CREMALLERA.equalsIgnoreCase(nombrecomercial)){
	      if (SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31872",cierreOtros.getMaterialDientes());
		   	  lstErroresDescrMin.add(error);			  
	      	 }
	      else{
		      if (TIPO_VALOR_CATALOGO.equals(cierreOtros.getMaterialDientes().getCodtipvalor())){
				  if(noEstaEnCatalogo(datoAValidar,"CB", fechaVigencia)){
				   	  ErrorDescrMinima error = obtenerError("31797",cierreOtros.getMaterialDientes());
				   	  lstErroresDescrMin.add(error);			  
				  }
	          }
	      }			  
	  }
	  else {
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31798",cierreOtros.getMaterialDientes());
		   	  lstErroresDescrMin.add(error);			  
		  }		  
	  }
	  return lstErroresDescrMin;		  
	}
  
  public List<ErrorDescrMinima> validarTamanoDientes(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String datoAValidar, nombrecomercial;
	  Float datoAValidarN;
	  Float arreglo[] = {2F,3F,4.5F,5F,7F,8F};
	  if(cierreOtros.getTamanoDientes() == null){
	      datoAValidar = "";
	  	  datoAValidarN = 0F;
	  }
	  else{
		  datoAValidar = cierreOtros.getTamanoDientes().getValtipdescri().trim();
		  if(!SunatStringUtils.isEmpty(datoAValidar))
			  datoAValidarN = Float.valueOf(datoAValidar);
		  else
			  datoAValidarN = 0F;
	  }
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  if (COD_CINTA_CREMALLERA.equalsIgnoreCase(nombrecomercial)){
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
			  if(datoAValidarN < 8 && !SeEncuentra(arreglo,datoAValidarN)){
			   	  ErrorDescrMinima error = obtenerError("31799",cierreOtros.getTamanoDientes());
			   	  lstErroresDescrMin.add(error);			  
			  }
		  }
		  else{
		   	  ErrorDescrMinima error = obtenerError("31871",cierreOtros.getTamanoDientes());
		   	  lstErroresDescrMin.add(error);				  
		  }
	  }
	  else {
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31800",cierreOtros.getTamanoDientes());
		   	  lstErroresDescrMin.add(error);			  
		  }		  
	  }
	  return lstErroresDescrMin;
	}
  
  private boolean SeEncuentra(Float[] arreglo, Float elemento) {
	  int valores = arreglo.length;    
	  boolean encontrado=false;       
	  for ( int posicion = 0; posicion < valores; posicion++ )  
			  if ( arreglo[posicion].equals(elemento))      
				  encontrado=true;    
	  return encontrado;
	  }
  
  //R845: variacion casilla tipo de llave es solamente texto
  public List<ErrorDescrMinima> validarTipoLlave(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  /*Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String nombrecomercial,datoAValidar;	  
	  if(cierreOtros.getTipoLlave() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreOtros.getTipoLlave().getValtipdescri().trim();  
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();	  
	  if (COD_LLAVE.equalsIgnoreCase(nombrecomercial)){
		  if(noEstaEnCatalogo(datoAValidar,"CC",fechaVigencia)){
		   	  ErrorDescrMinima error = obtenerError("31801",cierreOtros.getTipoLlave());
		   	  lstErroresDescrMin.add(error);			  
		  }
	  }
	  else {
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31802",cierreOtros.getTipoLlave());
		   	  lstErroresDescrMin.add(error);			  
		  }		  
	  }*/
	  return lstErroresDescrMin;
	}
  
  public List<ErrorDescrMinima> validarMaterialLlave(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreOtros cierreOtros = (CierreOtros) objeto;
	  String nombrecomercial,datoAValidar;	  
	  if(cierreOtros.getMaterialLlave() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreOtros.getMaterialLlave().getValtipdescri().trim();  
	  if(cierreOtros.getNombreComercial() == null)
		  nombrecomercial = "";
	  else
		  nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();	  
	  if (COD_LLAVE.equalsIgnoreCase(nombrecomercial)){
		  if (TIPO_VALOR_CATALOGO.equals(cierreOtros.getMaterialLlave().getCodtipvalor())){
			  if(noEstaEnCatalogo(datoAValidar,"CB",fechaVigencia)){
			   	  ErrorDescrMinima error = obtenerError("31795",cierreOtros.getMaterialLlave());
			   	  lstErroresDescrMin.add(error);			  
			  }			  
		  }
		  /* INC 2016-090582 - R846*/
		  if(SunatStringUtils.isEmpty(datoAValidar)){
			  ErrorDescrMinima error = obtenerError("31795",cierreOtros.getMaterialLlave());
		   	  lstErroresDescrMin.add(error);	
		  }
		  /* INC 2016-090582*/
	  }
	  else {
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31796",cierreOtros.getMaterialLlave());
		   	  lstErroresDescrMin.add(error);			  
		  }		  
	  }
	  return lstErroresDescrMin;
	}

  
  public List<ErrorDescrMinima> validarTamanoLlave(ModelAbstract objeto, Declaracion dua){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		 
	  DatoItem item = obtenerItem(objeto, dua); 
	  CierreOtros cierreOtros = (CierreOtros) objeto;	 	 
	  String datoAValidar = cierreOtros.getTamanoLlave()!=null && cierreOtros.getTamanoLlave().getValtipdescri()!=null?
			  cierreOtros.getTamanoLlave().getValtipdescri().trim():"";
	  String subPartida = item.getNumpartnandi().toString();
	  String nombrecomercial = cierreOtros.getNombreComercial().getValtipdescri().trim();
	  
	  if(!datoAValidar.isEmpty()){//es condicionado a la existencia del campo		  
		  int tamano = !datoAValidar.isEmpty() && cumpleExpresionRegular(datoAValidar, FORMATO)?new Integer(datoAValidar):0;
		  if(!(tamano>0 && tamano<=99)){
			  ErrorDescrMinima error = obtenerError("33015",cierreOtros.getTamanoLlave());
		   	  lstErroresDescrMin.add(error);	
		  }
	  }
	  
	  if(SPN_LLAVE.equals(subPartida) && COD_LLAVE.equalsIgnoreCase(nombrecomercial)){		
		  if(SunatStringUtils.isEmpty(datoAValidar)){
			  ErrorDescrMinima error = obtenerError("33011",cierreOtros.getTamanoLlave());
		   	  lstErroresDescrMin.add(error);		
		  }
	  }
	 
	  return lstErroresDescrMin;
  }
  
}
