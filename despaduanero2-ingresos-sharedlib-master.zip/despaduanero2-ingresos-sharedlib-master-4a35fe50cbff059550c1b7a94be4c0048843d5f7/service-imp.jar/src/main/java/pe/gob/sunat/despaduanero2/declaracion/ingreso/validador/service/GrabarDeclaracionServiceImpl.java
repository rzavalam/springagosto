/*
 * Clase que define el servicio de validaciones de 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COD_CATALOGO_TIPO_PLAZO;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.IND_ACTIVO;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Depocta;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.SecuenciaDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.VehiculoService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.wsclient.SeleccionService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante; //PAS20165E220200025
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.PlazosProceso;
import pe.gob.sunat.despaduanero2.declaracion.model.SecuenciaPerdida;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CantMaxLibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.declaracion.webservice.service.DeclaracionWebService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.sigad.ingreso.service.ControlarSaldoReposicionService;
import pe.gob.sunat.tecnologia.orquestador.exception.OrquestadorRechazoException;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionService;

@Transactional
public class GrabarDeclaracionServiceImpl extends ValDuaAbstract implements GrabarDeclaracionService {

	private static final String CODIGO_TIPO_AVISO_MENSAJE_SIMPLE = "2";//gmontoya 

	//protected final Log log = LogFactory.getLog(getClass());

	//GrabarFormatoAService grabarFormatoAService;	
	//GrabarFormatoBService grabarFormatoBService;	
	//GrabarRectificacionService grabarRectificacionService;  	
	//GeneraLiquidacionService generaLiquidacionService; 	
	//GrabarTablasAntiguasService grabarTablasAntiguasService;
	//SeleccionService  seleccionservice;	
	//GeneraRespuestaService generaRespuestaService;	
	//GrabarGeneralService grabarGeneralService;	
	//ExigibilidadService exigibilidadService;	
	//EnvioDAO envioDAO;
	String origen="";
	//CantMaxLibeDAO cantMaxLibeDAO;
	//DepoctaDAO depoctaDAO;
	//CabDeclaraDAO cabdeclaraDAO;
	//OperadorAyudaService operadorAyudaService;	
	//SecuenciaDeclaracionService secuenciaDeclaracionService; 
	//GrabarContingentesService grabarContingentesService; 

	//private ValidacionGeneralService validacionGeneral; 
	//private PlazosProcesoDAO plazosprocesodao; 
	//private PublicacionAvisoService publicacionAvisoService;
	//private CatalogoAyudaService catalogoAyudaService;
	//private DdpDAOService ddpDAOService;
	//private LiquidaDeclaracionService liquidaDeclaracionService;	
	//private PlazosProcesoDAO plazosProcesoDAO;
	//private IndicadorDUADAO indicadorDuaDAO;
	//private VFOBProvisionalDAO fobProvisionalDAO;
	//private String CATALOGO_DE_FECHA_HABILITACION_LGA = "380";//PAS20165E220200032
	private HashMap<String, String> resultadoLCVP = null;
	//private FabricaDeServicios fabricaDeServicios; 
	//private HotSwappableTargetSource swapperDatasource;




	public Map<String, String> grabarNumeracion( Map<String, Object> variablesIngreso ) throws Exception {
		SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
		Declaracion declaracion = (Declaracion) variablesIngreso .get("declaracion");
		SecuenciaPerdida secuencia = secuenciaDeclaracionService.generaSecuenciaDeclaracion(declaracion);
		try{
			String transmisionValorProvisional = variablesIngreso.containsKey("transmisionValorProvisional")?
					(String) variablesIngreso.get("transmisionValorProvisional"):null;
					grabarDeclaracion( variablesIngreso, declaracion, secuencia );
					HashMap mapaNotificaLC = new HashMap(); //RIN10
					if("SI".equals(transmisionValorProvisional)){				
						grabarIndicadorPlazoNumeracion(declaracion, declaracion.getDua().getNumcorredoc().longValue());
						if(!CollectionUtils.isEmpty(resultadoLCVP)) {
							mapaNotificaLC.put("generarLCVP", "SI");
							mapaNotificaLC.put("LiqCobranzaVP", resultadoLCVP.get("lc").toString());
							mapaNotificaLC.put("monto_lc", resultadoLCVP.get("monto_lc").toString());
							mapaNotificaLC.put("numero_lc", resultadoLCVP.get("numero_lc").toString());
							mapaNotificaLC.put("bivp", resultadoLCVP.get("bivp").toString());
							mapaNotificaLC.put("tieneGarantia160", resultadoLCVP.get("tieneGarantia160").toString());
						}
					}
					mapaNotificaLC.put("generaLC", "NO");
		}catch(Exception e){
			enviarException(secuencia, variablesIngreso, declaracion);
			throw e ;
		}catch(Error e){
			enviarException(secuencia, variablesIngreso, declaracion);
			log.error(e.getStackTrace());
			throw e ;
		}
		return new HashMap<String, String>();
	}

	/**
	 * Grabar notificaciones desp�es de la grabaci�n de la declaraci�n
	 * 
	 * @author olunar - 2012-06-25
	 * @param declaracion
	 */
	private void grabarNotificaciones(Declaracion declaracion, HashMap mapaNotificaLC, Map<String,Object> mapNotificaLC15N9, Map<String,Object> mapNotificaLC15S9,Map<String, Object> variablesIngreso ) {
		PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService) fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		Map<String, Object> mapMensajeVU = new HashMap<String, Object>();
		Map<String, Object> mapMensajeVA = new HashMap<String, Object>();
		boolean blIndRegula = false;
		String descAduana = "";
		String strNumeroDeclaracion="";
		descAduana = catalogoAyudaService.getDescripcionDataCatalogo(Constants.COD_CATALOG_ADUANA, declaracion.getDua().getCodaduanaorden());
		for(DatoIndicadores indicador:declaracion.getDua().getListIndicadores())
		{
			if(indicador.getCodtipoindica()!=null && indicador.getCodtipoindica().equals(Constants.IND_REGULARIZABLE))
			{
				blIndRegula = true;
				break;
			}
		}

		strNumeroDeclaracion=declaracion.getNumeroDeclaracion().toString().trim();
		int j=strNumeroDeclaracion.length();
		for(int i=0; i<6-j ;i++)
		{
			strNumeroDeclaracion="0"+strNumeroDeclaracion;
		}
		String linkDua = "http://www.aduanet.gob.pe/servlet/SgCDUI2?codaduana=".concat(declaracion.getDua().getCodaduanaorden()).concat("&anoprese=")
				.concat(declaracion.getDua().getAnnpresen().toString()).concat("&numecorre=").concat(strNumeroDeclaracion).concat("&n=").concat(declaracion.getDua().getCodregimen().toString());

		// Notificaci�n al Despachador de Aduana por Aceptaci�n Dua
		String strDeclaracion = declaracion.getDua().getCodaduanaorden().concat("-").concat(declaracion.getDua().getAnnpresen().toString()).concat("-").concat(declaracion.getDua().getCodregimen().toString()).
				concat("-").concat(strNumeroDeclaracion);
		mapMensaje.put("tip_usuario", "1");
		mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
		mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIFICACION_NUMERACION_DUA+" ("+strDeclaracion+")");
		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
		mapMensaje.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
		mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
		mapMensaje.put("num_declaracion", strNumeroDeclaracion);
		mapMensaje.put("numruc_consig", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		mapMensaje.put("des_intendencia", descAduana);
		mapMensaje.put("lnk_consultaDua", linkDua);
		mapMensaje.put("des_mandato", SunatStringUtils.isEmptyTrim(SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif")))?" ":SunatStringUtils.toStringObj(variablesIngreso.get("msgNotif")));
		DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
		Map params=new HashMap();
		params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		if (params!=null) mapMensaje.put("nombre_consig", params.get("ddp_nombre").toString().trim());
		else mapMensaje.put("nombre_consig", " ");
		mapMensaje.put("fechahoy", fechaActual.getFormatDate("dd/MM/yyyy"));
		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		publicacionAvisoService.insert(Constants.COD_NOTIFICACION_NUMERACION_DUA, data,  CODIGO_TIPO_AVISO_MENSAJE_SIMPLE,
				fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

		// Notificaci�n al Despachador de Aduana por Plazo de regularizaci�n de despacho Urgente
		if(declaracion.getDua().getCodmodalidad().equals(Constants.DESPACHO_URGENTE))
		{
			mapMensajeVU.put("tip_usuario", "1");
			mapMensajeVU.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMensajeVU.put("des_asunto", Constants.ASUNTO_NOTIF_REGULA_DESPACHO_URGENTE+" ("+strDeclaracion+")");
			mapMensajeVU.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMensajeVU.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
			mapMensajeVU.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
			mapMensajeVU.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
			mapMensajeVU.put("num_declaracion", strNumeroDeclaracion);
			mapMensajeVU.put("des_intendencia", descAduana);
			data = new StringBuffer(SojoUtil.toJson(mapMensajeVU));
			publicacionAvisoService.insert(Constants.COD_NOTIF_REGULA_DESPACHO_URGENTE, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
		} else if(declaracion.getDua().getCodmodalidad().equals(Constants.DESPACHO_ANTICIPADO) && blIndRegula)
		{
			//Notificaci�n al Despachador de Aduana por Plazo de regularizaci�n de despacho Anticipado
			mapMensajeVA.put("tip_usuario", "1");
			mapMensajeVA.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMensajeVA.put("des_asunto", Constants.ASUNTO_NOTIF_REGULA_DESPACHO_ANTICIPADO+" ("+strDeclaracion+")");
			mapMensajeVA.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMensajeVA.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
			mapMensajeVA.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
			mapMensajeVA.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
			mapMensajeVA.put("num_declaracion", strNumeroDeclaracion);
			mapMensajeVA.put("des_intendencia", descAduana);
			data = new StringBuffer(SojoUtil.toJson(mapMensajeVA));
			publicacionAvisoService.insert(Constants.COD_NOTIF_REGULA_DESPACHO_ANTICIPADO, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
		}

		// Notificaci�n al Due�o o Consignatario por Aceptaci�n dua
		if(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals(Constants.COD_DATA_CATALOG_TIPO_DOC_RUC))
		{
			mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
			mapMensaje.put("numruc_consig", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=new HashMap();
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMensaje.put("nombre_consig", params.get("ddp_nombre").toString().trim());
			else mapMensaje.put("nombre_consig", " ");
			data = new StringBuffer(SojoUtil.toJson(mapMensaje));
			publicacionAvisoService.insert(Constants.COD_NOTIFICACION_NUMERACION_DUA, data,  CODIGO_TIPO_AVISO_MENSAJE_SIMPLE,
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

			// Notificaci�n al Due�o o Consignatario por Plazo regularizaci�n Urgente
			if(declaracion.getDua().getCodmodalidad().equals(Constants.DESPACHO_URGENTE))
			{
				mapMensajeVU.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
				data = new StringBuffer(SojoUtil.toJson(mapMensajeVU));
				publicacionAvisoService.insert(Constants.COD_NOTIF_REGULA_DESPACHO_URGENTE, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}else if(declaracion.getDua().getCodmodalidad().equals(Constants.DESPACHO_ANTICIPADO) && blIndRegula)
			{
				//Notificaci�n al Due�o o consignatario por Plazo de regularizaci�n de despacho Anticipado
				mapMensajeVA.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
				data = new StringBuffer(SojoUtil.toJson(mapMensajeVA));
				publicacionAvisoService.insert(Constants.COD_NOTIF_REGULA_DESPACHO_ANTICIPADO, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}

		}

		if( mapaNotificaLC.get("generaLC").toString().equals("SI") ) {
			//Notifica a Agente de Aduana
			Map<String, Object> mapMsgLCTPI100 = new HashMap<String, Object>();
			mapMsgLCTPI100.put("tip_usuario", "1");
			mapMsgLCTPI100.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMsgLCTPI100.put("des_asunto", Constants.ASUNTO_NOTIF_LC_TPI100 );
			mapMsgLCTPI100.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLCTPI100.put("tpi", mapaNotificaLC.get("codigoTPI").toString());
			mapMsgLCTPI100.put("numruc", declaracion.getDua().getNumdocumento());
			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null) mapMsgLCTPI100.put("nombre", params.get("ddp_nombre").toString().trim());
			else mapMsgLCTPI100.put("nombre", " ");

			String dua = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion;
			String lc  = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + mapaNotificaLC.get("NumeroLC").toString(); 
			mapMsgLCTPI100.put("dua", dua);
			mapMsgLCTPI100.put("lc", lc);
			data = new StringBuffer(SojoUtil.toJson(mapMsgLCTPI100));
			publicacionAvisoService.insert(Constants.COD_NOTIF_LC_TPI100, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

			//Notifica a consignatario .
			mapMsgLCTPI100.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
			mapMsgLCTPI100.put("numruc", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMsgLCTPI100.put("nombre", params.get("ddp_nombre").toString().trim());
			else mapMsgLCTPI100.put("nombre", " ");
			data = new StringBuffer(SojoUtil.toJson(mapMsgLCTPI100));
			publicacionAvisoService.insert(Constants.COD_NOTIF_LC_TPI100, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
					fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

			// Notificaci�n al Jefe del Area de Despacho
			if( !mapaNotificaLC.get("CodJefe").toString().equals("") ) {
				mapMsgLCTPI100.put("tip_usuario", "3");
				mapMsgLCTPI100.put("cod_usuario", new String[]{mapaNotificaLC.get("CodJefe").toString()});
				mapMsgLCTPI100.put("des_asunto",Constants.ASUNTO_AVISO_LC_TPI100);
				data = new StringBuffer(SojoUtil.toJson(mapMsgLCTPI100));
				publicacionAvisoService.insert(Constants.COD_AVISO_LC_TPI100, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}
		}

		if(mapNotificaLC15N9.get("generaLC15_NO_9")!=null && mapNotificaLC15N9.get("generaLC15_NO_9").toString().equals("SI")){
			//Notifica a Agente de Aduana
			Map<String, Object> mapMsgLC15_NO_9 = new HashMap<String, Object>();
			mapMsgLC15_NO_9.put("tip_usuario", "1");
			mapMsgLC15_NO_9.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMsgLC15_NO_9.put("des_asunto", Constants.ASUNTO_NOTIF_LC_15 );
			mapMsgLC15_NO_9.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLC15_NO_9.put("tpi", mapNotificaLC15N9.get("codigoTPI").toString());
			mapMsgLC15_NO_9.put("numruc_agente", declaracion.getDua().getNumdocumento());
			mapMsgLC15_NO_9.put("dias", mapNotificaLC15N9.get("avisoDias").toString());
			mapMsgLC15_NO_9.put("sustento", mapNotificaLC15N9.get("avisoSustento").toString());
			//params=ddpDAO.findByPK(declaracion.getDua().getNumdocumento());
			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null) mapMsgLC15_NO_9.put("nombre_agente", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_NO_9.put("nombre_agente", " ");

			String dua = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion;
			String lc  = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + mapNotificaLC15N9.get("NumeroLC").toString(); 
			mapMsgLC15_NO_9.put("dua", dua);
			mapMsgLC15_NO_9.put("lc", lc);

			//Notifica a consignatario y agente de aduana.
			mapMsgLC15_NO_9.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(),declaracion.getDua().getNumdocumento()});
			mapMsgLC15_NO_9.put("numruc_consigna", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMsgLC15_NO_9.put("nombre_consigna", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_NO_9.put("nombre_consigna", " ");
			data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_NO_9));

			if (mapNotificaLC15N9.get("indicadorGarantia").toString().equals("G")){
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_N_9_G, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}else{
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_N_9, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}

			// Notificaci�n al Jefe del Area de Despacho
			if( !mapNotificaLC15N9.get("CodJefe").toString().equals("") ) {
				mapMsgLC15_NO_9.put("tip_usuario", "3");
				mapMsgLC15_NO_9.put("cod_usuario", new String[]{mapNotificaLC15N9.get("CodJefe").toString()});
				mapMsgLC15_NO_9.put("des_asunto",Constants.ASUNTO_AVISO_LC_15);
				data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_NO_9));
				if (mapNotificaLC15N9.get("indicadorGarantia").toString().equals("G")){
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_N_9_G, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}else{
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_N_9, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}

			}

		}

		if(mapNotificaLC15S9.get("generaLC15_SI_9")!=null && mapNotificaLC15S9.get("generaLC15_SI_9").toString().equals("SI")){
			//Notifica a Agente de Aduana
			Map<String, Object> mapMsgLC15_SI_9 = new HashMap<String, Object>();
			mapMsgLC15_SI_9.put("tip_usuario", "1");
			//mapMsgLC15_SI_9.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMsgLC15_SI_9.put("des_asunto", Constants.ASUNTO_NOTIF_LC_15 );
			mapMsgLC15_SI_9.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLC15_SI_9.put("tpi", mapNotificaLC15S9.get("codigoTPI").toString());
			mapMsgLC15_SI_9.put("numruc_agente", declaracion.getDua().getNumdocumento());
			mapMsgLC15_SI_9.put("desTpi", StringEscapeUtils.escapeHtml(mapNotificaLC15S9.get("desTpi").toString()));
			mapMsgLC15_SI_9.put("certiOrigen", mapNotificaLC15S9.get("certiOrigen").toString());

			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null) mapMsgLC15_SI_9.put("nombre_agente", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_SI_9.put("nombre_agente", " ");

			String dua = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion;
			String lc  = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + mapNotificaLC15S9.get("NumeroLC").toString(); 
			mapMsgLC15_SI_9.put("dua", dua);
			mapMsgLC15_SI_9.put("lc", lc);

			//Notifica a consignatario y agente
			mapMsgLC15_SI_9.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(),declaracion.getDua().getNumdocumento()});
			mapMsgLC15_SI_9.put("numruc_consigna", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMsgLC15_SI_9.put("nombre_consigna", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_SI_9.put("nombre_consigna", " ");			
			data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_SI_9));

			if (mapNotificaLC15S9.get("indicadorGarantia").toString().equals("G")){
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_S_9_G, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}else{
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_S_9, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}


			// Notificaci�n al Jefe del Area de Despacho
			if( !mapNotificaLC15S9.get("CodJefe").toString().equals("") ) {
				mapMsgLC15_SI_9.put("tip_usuario", "3");
				mapMsgLC15_SI_9.put("cod_usuario", new String[]{mapNotificaLC15S9.get("CodJefe").toString()});
				mapMsgLC15_SI_9.put("des_asunto",Constants.ASUNTO_AVISO_LC_15);
				data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_SI_9));
				if (mapNotificaLC15S9.get("indicadorGarantia").toString().equals("G")){
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_S_9_G, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}else{
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_S_9, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}

			}

		}

		if(mapaNotificaLC.get("generarLCVP") != null && "SI".equals(mapaNotificaLC.get("generarLCVP").toString())) {

			//Notifica al contribuyente (importador)
			Map<String, Object> mapMsgLCVP = new HashMap<String, Object>();
			mapMsgLCVP.put("tip_usuario", "1"); //tipo usuario contribuyente
			mapMsgLCVP.put("cod_usuario",  new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
			mapMsgLCVP.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLCVP.put("numruc_consig", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
			String razonSocial = "RAZON SOCIAL NO UBICADO EN LA TABLA PARTICIPANTE_DOC";
			razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE);
			mapMsgLCVP.put("des_ruc_razon_social", StringEscapeUtils.escapeHtml(razonSocial));
			String dua = declaracion.getDua().getCodaduanaorden() + "-" + declaracion.getDua().getAnnpresen().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion; 

			mapMsgLCVP.put("dua", dua);
			mapMsgLCVP.put("lc", mapaNotificaLC.get("LiqCobranzaVP").toString());
			mapMsgLCVP.put("numero_lc", mapaNotificaLC.get("numero_lc").toString());
			mapMsgLCVP.put("bivp", mapaNotificaLC.get("bivp").toString());
			mapMsgLCVP.put("monto_lc", mapaNotificaLC.get("monto_lc").toString());			

			Integer codigoNotifLCVP;
			if(mapaNotificaLC.get("tieneGarantia160").toString().equals("NO")){
				codigoNotifLCVP = Constants.COD_NOTIF_GENERACION_LCVP_SINGARANTIA;
				mapMsgLCVP.put("des_asunto", Constants.ASUNTO_NOTIF_LCVP_SINGARANTIA160); 
			}
			else {	
				codigoNotifLCVP = Constants.COD_NOTIF_GENERACION_LCVP_CONGARANTIA;
				mapMsgLCVP.put("des_asunto", Constants.ASUNTO_NOTIF_LCVP_GARANTIA160); 
			}

			String unidadRemitente = "118".equals(declaracion.getDua().getCodaduanaorden())?
					"LA DIVISION DE IMPORTACION DE LA IAMC":"EL DEPARTAMENTO DE TECNICA ADUANERA";
			mapMsgLCVP.put("des_unidad_organica", unidadRemitente);

			data = new StringBuffer(SojoUtil.toJson(mapMsgLCVP));
			publicacionAvisoService.insert(codigoNotifLCVP, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,fechaActual.getTimestamp(), fechaVigencia.getTimestamp());						

			mapMsgLCVP.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMsgLCVP.put("numruc_consig", declaracion.getDua().getNumdocumento());

			razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
			mapMsgLCVP.put("des_ruc_razon_social",StringEscapeUtils.escapeHtml(razonSocial));
			data = new StringBuffer(SojoUtil.toJson(mapMsgLCVP));

			publicacionAvisoService.insert(codigoNotifLCVP, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			HashMap<String, Object> paramEstados = new HashMap<String, Object>();

			paramEstados.put("XRLADUANA", resultadoLCVP.get("aduana_lc"));
			paramEstados.put("XRLANO", resultadoLCVP.get("anno_lc"));
			paramEstados.put("XRLNROLIQ", resultadoLCVP.get("numero_lc"));
			paramEstados.put("XTIPO", "T");
			paramEstados.put("XRLESTADO", "NOTI");
			paramEstados.put("XRLFECEST", SunatDateUtils.getCurrentIntegerDate());
			paramEstados.put("XRLSTATUS", "V");
			paramEstados.put("XRLFECESTC", SunatDateUtils.getCurrentIntegerDate());
			LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
			liquidaDeclaracionService.cambiarEstadoLiquidacion(paramEstados);
		}		
		//fin oneyraj rin10	

	}

	private void enviarException(SecuenciaPerdida secuencia, Map<String, Object> variablesIngreso, Declaracion declaracion){
		SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
		pintaMensaje("ENTRO AL EXCEPTION DE LA GRABACION");
		secuencia.setIndicadorRecuperacion(" ");
		if(secuencia.getFechaRegistro() == null) {
			origen="secuenciaDeclaracionService.registrarSecuencia";
			secuenciaDeclaracionService.registrarSecuencia(secuencia);
			pintaMensaje(origen);
		} else {
			origen="secuenciaDeclaracionService.actualizarSecuencia";
			secuenciaDeclaracionService.actualizarSecException(secuencia);
			pintaMensaje(origen);
		}
		if (variablesIngreso.get("mapGarantia")!=null) {
			desafectaGarantia (declaracion, variablesIngreso);
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, String> grabarDeclaracion( Map<String, Object> variablesIngreso, Declaracion declaracion, SecuenciaPerdida secuencia  ) throws Exception{

		if(UserNameHolder.get()==null) 
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);

		String tipoSender 		= (String) variablesIngreso.get("tipoSender");
		String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		String tipoDocumentoIdentidadSender = (String) variablesIngreso .get("tipoDocumentoIdentidadSender");
		String numOrden 		= (String) variablesIngreso.get("numOrden");
		String codUsuario 		= (String) variablesIngreso.get("codUsuario");
		String tipoDesp 		= (String) variablesIngreso.get("tipoDesp");
		Date fechaConclusionDespa = null;
		Integer annEnvio 		= (Integer) variablesIngreso.get("annEnvio");
		Long numEnvio 			= (Long) variablesIngreso.get("numEnvio");
		String afectaCtaCteVehicUsa = (String) variablesIngreso.get("IndAfectaDesafecta");
		String afectaDesafectaRegPreDepo = (String) variablesIngreso.get("indAfectaDesafectaRegPreDepo");
		String codTransaccion   =(String) variablesIngreso.get("codTransaccion");
		Boolean validar = (Boolean) variablesIngreso.get("validarManifiesto");

		List<Map<String, String>> listaWarnings = new ArrayList<Map<String, String>>();
		String transmisionValorProvisional = variablesIngreso.containsKey("transmisionValorProvisional")?(String) variablesIngreso.get("transmisionValorProvisional"):null;
		origen="GrabarDeclaracionServiceImpl";

		Date fechaVencimientoConclusion = null;
		Map <String, Object> parametros = new HashMap<String, Object>();
		FechaBean fechaActual = new FechaBean();
		long diferenciaFechas;

		Date fechaReferencia = declaracion.getDua().getFecdeclaracion();
		if(fechaReferencia == null && codTransaccion!=null && codTransaccion.substring(2, 4).equals("01")){
			fechaReferencia=new Date();
		}
		GetDeclaracionService getDeclaracionService = (GetDeclaracionService) fabricaDeServicios.getService("declaracionService");
		if(!getDeclaracionService.esVigenteNuevaLGAPorFecha(fechaReferencia)){
			ValidacionGeneralService validacionGeneral = (ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice");
			parametros = validacionGeneral.obtFechaConclusionDespacho(variablesIngreso, SunatDateUtils.getCurrentDate(), 3);
		}

		if (parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
			fechaVencimientoConclusion = (Date) parametros.get("fechaConclusionDespa"); 
		}
		pintaMensaje("INICIA PROCESO DE GRABACION");
		List<DatoDocAutorizante> listaDocumentosVUCE = null;
		if( variablesIngreso.get("lstDocAutorizaVUCE") != null ) {
			listaDocumentosVUCE = (List<DatoDocAutorizante>)variablesIngreso.get("lstDocAutorizaVUCE");
		}

		
		origen="grabarFormatoAService.grabaFormatoA";
		GrabarFormatoAService grabarFormatoAService = (GrabarFormatoAService)fabricaDeServicios.getService("grabarFormatoAService");
		grabarFormatoAService.grabaFormatoA(declaracion, tipoSender, numeroDocumentoIdentidadSender,
				tipoDocumentoIdentidadSender,fechaConclusionDespa, numOrden, codTransaccion, 
				fechaVencimientoConclusion, listaDocumentosVUCE);
		grabarFormatoAService.grabarParticipanteSEIDA( codUsuario,  tipoSender,  declaracion.getNumeroCorrelativo());
		pintaMensaje(origen);

		
		//RIN25- ATRG201802 PAS20181U220200022
		//Boolean actualizaCtaCteContingente = variablesIngreso.get("actualizaCtaCteContingente") == null ? Boolean.FALSE :  (Boolean)variablesIngreso.get("actualizaCtaCteContingente");
		grabarFormatoAService.grabarIndicadorImportadorFrecuente(declaracion, ConstantesDataCatalogo.TRANSACCION_NUMERACION);
		
		
		/* P28 */
		if (declaracion.getDua().getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)) {
			origen="ControlarSaldoReposicionService.actualizarCtaCte";
			ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
			controlarSaldoReposicionService.actualizarCtaCte(declaracion);
			pintaMensaje(origen);
		}
		if (!declaracion.getDua().getCodregimen().equals("70")) {
			origen="grabarFormatoBService.grabaFB";
			GrabarFormatoBService grabarFormatoBService = (GrabarFormatoBService) fabricaDeServicios.getService("grabarFormatoBService");
			grabarFormatoBService.grabaFB(declaracion);
			pintaMensaje(origen);
		}
		
		// gg7 dua can - grabado de descripci�n de cat�logos
		// PAS20191U220500009 20190318 GTP: Se agrega para regimen 20 y 21 para medio de pago de formato B
		if (declaracion.getDua().getCodregimen().equals("10") || declaracion.getDua().getCodregimen().equals("20") || declaracion.getDua().getCodregimen().equals("21")) {
			GrabarDescripcionAdicionalService grabarDescripcionAdicionalService = (GrabarDescripcionAdicionalService) fabricaDeServicios.getService("grabarDescripcionAdicionalService");		
			origen="grabarDescripcionAdicionalService.grabaDescripcionOtros";
			grabarDescripcionAdicionalService.grabaDescripcionOtros(declaracion);
			pintaMensaje(origen);
		}

		GrabarGeneralService grabarGeneralService = (GrabarGeneralService) fabricaDeServicios.getService("GrabarGeneralService");
		if (validar) { 
			origen="grabarGeneralService.registrarDatado";
			grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_NUMERACION,codTransaccion, variablesIngreso);
			pintaMensaje(origen);
		}
		origen="afectarCtaCteVehiculosUsados";
		if (!declaracion.getDua().getCodregimen().equals("70")) {
			if(afectaCtaCteVehicUsa!=null)
				this.afectarCtaCteVehiculosUsados(declaracion, afectaCtaCteVehicUsa);
			pintaMensaje(origen);
		}
		origen="afectarCtaCteRegPrecedeDeposito";
		if (!declaracion.getDua().getCodregimen().equals("70")) {
		this.afectarCtaCteRegPrecedeDeposito(declaracion, afectaDesafectaRegPreDepo, numeroDocumentoIdentidadSender);
		pintaMensaje(origen);
		}

		if (!declaracion.getDua().getCodregimen().equals("70")) {
			origen="grabarGeneralService.actualizaCupoLibe";
			grabarGeneralService.actualizaCupoLibe(declaracion);
			pintaMensaje(origen);
		}
		origen="actualizarEnvio";
		actualizarEnvio(annEnvio, numEnvio, declaracion.getNumeroCorrelativo());
		pintaMensaje(origen);

		if (!declaracion.getDua().getCodregimen().equals("70")) {
			origen="grabarGeneralService.grabaCtaCtePerNat";
			grabarGeneralService.grabaCtaCtePerNat(declaracion, codTransaccion);
			pintaMensaje(origen);
		}
//		if (declaracion.getDua().getCodregimen().equals("21")) {// PAS20171U220200048 - La grabacion en Declaran es general
//			origen="grabarGeneralService.grabarBeneficiario";
//			grabarGeneralService.grabarBeneficiario(declaracion);
//			pintaMensaje(origen);
//		}
		if (!declaracion.getDua().getCodregimen().equals("70")) {
			origen="grabarGeneralService.grabaCupoTPI";
			grabarGeneralService.grabaCupoTPI (variablesIngreso);
			pintaMensaje(origen);
		}

		if (declaracion.getDua().getCodregimen().equals("10")) {
			origen="grabarGeneralService.actualizaRUCResolucionLiberatoria";
			grabarGeneralService.actualizaRUCResolucionLiberatoria(declaracion); 
			pintaMensaje(origen);
		}

		origen="grabarTablasAntiguasService.grabarTablasAntiguas";// PAS20171U220200048 - Se mueve grabado de tablas antiguas
		//property name="grabarTablasAntiguasService" ref="grabarTablasAntiguasService
		GrabarTablasAntiguasService grabarTablasAntiguasService = (GrabarTablasAntiguasService) fabricaDeServicios.getService("grabarTablasAntiguasService");		
		grabarTablasAntiguasService.grabarTablasAntiguas(declaracion, variablesIngreso);
		pintaMensaje(origen);

		//pintaMensaje(origen);
		origen="grabarGeneralService.grabarProductoRemate";
		grabarGeneralService.grabarProductoRemate(declaracion);// PAS20171U220200048 - grabado en producto
		pintaMensaje(origen);

		origen="generaLiquidacionService.grabaLiquidacion";
		Map montoTPI100 = (Map)variablesIngreso.get("MontoTPI100");
		Map<String,Object> montoLC15N9 = (Map<String,Object>) variablesIngreso.get("montoTPILC15_NO_9");//jenciso RIN05
		Map<String,Object> montoLC15S9 = (Map<String,Object>) variablesIngreso.get("montoTPILC15_SI_9");
		Map<String,Object> mapMontos = new HashMap<String, Object>();
		mapMontos.put("montoTPI100", montoTPI100);
		mapMontos.put("montoLC15N9", montoLC15N9);
		mapMontos.put("montoLC15S9", montoLC15S9);

		Map montoLC0006 = (Map)variablesIngreso.get("MontoLC0006");
		if(montoLC0006 != null && variablesIngreso.get("esPecoAmazonia")!=null){
			montoLC0006.put("esPecoAmazonia",variablesIngreso.get("esPecoAmazonia").toString());
		}

		GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService) fabricaDeServicios.getService("generaLiquidacionService");
		Map mapResulLiqui = generaLiquidacionService.grabaLiquidacion(declaracion,codTransaccion ,numOrden, numeroDocumentoIdentidadSender, mapMontos, montoLC0006);// RIN08 agreg� montoLC0006 - jenciso RIN05

		/**
		 * Para regimen distinto de deposito (70) si es que no se inserto en el DEUDA_DOCUM no debe numerar.
		 */
		if (!ConstantesDataCatalogo.REG_DEPOSITO.equals(declaracion.getDua().getCodregimen())) {
			if (!verificaDeudaDeclaracion(declaracion)) {
				log.info("DECLARACION SIN DEUDA_DOCUM :"+SunatStringUtils.toStringObj(declaracion.getNumeroCorrelativo())+" -  Detalle:"+mapResulLiqui); 
				throw new OrquestadorRechazoException("91109");
			}
		}

		pintaMensaje(origen);
		if ("OK".equals(mapResulLiqui.get("GRABACION"))) {
			variablesIngreso.put("RESULTADO_LIQ", mapResulLiqui);
			if ("10".equals(declaracion.getDua().getCodregimen())) {
				origen="generaLiquidacionService.grabaTrama";
				generaLiquidacionService.grabaTrama(variablesIngreso);
				pintaMensaje(origen);
			}
		}
		if("SI".equals(transmisionValorProvisional)){
			LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
			resultadoLCVP = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);

			if(!CollectionUtils.isEmpty(resultadoLCVP)){
				HashMap deudaDUA = new HashMap();
				deudaDUA.put("TIPO", "LC");
				deudaDUA.put("CDA", resultadoLCVP.get("cda"));
				deudaDUA.put("MONEDA", "D");
				BigDecimal monto = new BigDecimal(resultadoLCVP.get("monto_lc").toString());
				deudaDUA.put("MONTO", monto.setScale( 0, BigDecimal.ROUND_HALF_UP ));
				deudaDUA.put("LC", resultadoLCVP.get("aduana_lc").concat(resultadoLCVP.get("anno_lc")).concat("96").concat(resultadoLCVP.get("numero_lc")));
				deudaDUA.put("TIPOLC", "0010");
				deudaDUA.put("COD_ADULIQUIDA", resultadoLCVP.get("aduana_lc"));
				deudaDUA.put("ANN_LIQUIDA", resultadoLCVP.get("anno_lc"));
				deudaDUA.put("NUM_LIQUIDA", resultadoLCVP.get("numero_lc"));

				List<HashMap> lstDeudas = new ArrayList();
				if (!CollectionUtils.isEmpty(mapResulLiqui)) {
					lstDeudas = (List<HashMap>) mapResulLiqui.get("LISTADEUDASAFECTAR");
					lstDeudas.add(deudaDUA);

					//A�adimos la LC a la lista de LCs para afectar
					mapResulLiqui.put("LISTADEUDASAFECTAR", lstDeudas);
					variablesIngreso.put("RESULTADO_LIQ", mapResulLiqui);
					//A�adimos el CDA de la deuda para poner el tipo de extinsi�n
					variablesIngreso.put("VALORPROVISIONALCDA", resultadoLCVP.get("cda"));
				}	
			}
		}
		if (!declaracion.getDua().getCodregimen().equals("70")) {
			origen="grabarGeneralService.afectaGarantia";
			grabarGeneralService.afectaGarantia(declaracion, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, numOrden, codUsuario,  Constants.COD_TRANS_FINAL_NUMERACION, tipoDesp, fechaVencimientoConclusion, variablesIngreso);
			pintaMensaje(origen);
		}
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(variablesIngreso.containsKey("cambiarFechaFinValorProvisional"))
			listaWarnings.add(catalogoAyudaService.getError(Constants.COD_NOTIF_SEIDA_CAMB_FEC, 
					new String[] {SunatDateUtils.getFormatDate((Date) variablesIngreso.get("cambiarFechaFinValorProvisional"),"dd/MM/yyyy")}));//RIN10
		if("SI".equals(transmisionValorProvisional) && !CollectionUtils.isEmpty(resultadoLCVP)) {
			listaWarnings.add(catalogoAyudaService.getError(Constants.COD_NOTIF_SEIDA_GEN_LC));//RIN10
		}
		variablesIngreso.put("listaWarnings", listaWarnings);
		/* PAS201830001100004 - mtorralba - 20180523 - No se invoca a Seleccion de Canal. Lo tomar� el proceso autom�tico
		try { 
			origen="grabarGeneralService.asignaCanal";
			grabarGeneralService.asignaCanal(declaracion, tipoDesp, codTransaccion);
			pintaMensaje(origen);
		}catch(Exception e)
		{
			log.error(e.getStackTrace()); //Si existe error en asinacion del canal
		}
		*/
		GrabarContingentesService grabarContingentesService = (GrabarContingentesService) fabricaDeServicios.getService("declaracion.grabarContingentesService");
		grabarContingentesService.procesaContingenteNumeracion(variablesIngreso, declaracion);

		
		//Verifica si le corresponde mandato electronico y de ser asi registra el indicador del mismo.
		GrabarMandatoElectronicoService grabarMandatoElectronicoService = fabricaDeServicios.getService("despaduanero2.ingreso.grabarMandatoElectronicoService");		
		String tipoMandatoElectronico = grabarMandatoElectronicoService.grabarMandatoElectronico(declaracion.getDua(), fechaReferencia, ConstantesDataCatalogo.TRANSACCION_NUMERACION);
		variablesIngreso.put("tipoMandatoElectronico", tipoMandatoElectronico);
		if (SunatStringUtils.isEqualTo(tipoMandatoElectronico, ConstantesDataCatalogo.TIENE_MANDATO_ELECTRONICO)){
			DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_MENSAJES_AVISOS_TEXTO, ConstantesDataCatalogo.MSG_MANDATO_ELECTRONICO);
			variablesIngreso.put("msgNotif", datacatalogo.getDesDatacat());
		}
		
		
		GeneraRespuestaService generaRespuestaService = (GeneraRespuestaService)fabricaDeServicios.getService("GenRespuestaServiceImpl");
		origen="generaRespuestaService.generaRespuestaEnvio";
		generaRespuestaService.generaRespuestaEnvio(0, variablesIngreso);
		pintaMensaje(origen);

		//actualiza la secuencia exitosamente
		if(secuencia.getFechaRegistro() != null) {
			SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
			origen="secuenciaDeclaracionService.actualizarSecuencia";
			secuencia.setIndicadorRecuperacion("X");
			secuenciaDeclaracionService.tomarSecuencia(secuencia);	
			pintaMensaje(origen);
		}


		HashMap mapaNotificaLC = new HashMap(); //RIN10
		mapaNotificaLC.put("generaLC", "NO");
		Map<String,Object> mapNotificaLC15N9 = new HashMap<String, Object>(); 
		mapNotificaLC15N9.put("generaLC15_NO_9", "NO");
		if(variablesIngreso.get("montoTPILC15_NO_9")!=null){
			Map<String,Object>  mapLC15N9 = (Map<String,Object>)variablesIngreso.get("montoTPILC15_NO_9");
			Map<String,Object>  mapLC = (Map<String,Object>)variablesIngreso.get("RESULTADO_LIQ");//VERIFICAR LOS DATOS QUE RETORNA PARA LOS TPIS CORRESPONDIENTES
			if(mapLC.get("numeroLC15N9")!=null){
				String numelc = mapLC.get("numeroLC15N9").toString();
				mapNotificaLC15N9.put("generaLC15_NO_9", "SI");
				mapNotificaLC15N9.put("NumeroLC", numelc);
				mapNotificaLC15N9.put("codigoTPI", mapLC15N9.get("codigoTPI").toString());
				mapNotificaLC15N9.put("CodJefe", mapLC15N9.get("CodJefe").toString());
				mapNotificaLC15N9.put("avisoDias", mapLC15N9.get("avisoDias").toString());
				mapNotificaLC15N9.put("avisoSustento", mapLC15N9.get("avisoSustento").toString());
				mapNotificaLC15N9.put("indicadorGarantia", mapLC15N9.get("indicadorGarantia"));
			}
		}

		Map<String,Object> mapNotificaLC15S9 = new HashMap<String, Object>();
		mapNotificaLC15S9.put("generaLC15_SI_9", "NO");
		if(variablesIngreso.get("montoTPILC15_SI_9")!=null){
			Map<String,Object> mapLC15S9 = (Map<String,Object>)variablesIngreso.get("montoTPILC15_SI_9");
			Map<String,Object> mapLC = (Map<String,Object>)variablesIngreso.get("RESULTADO_LIQ");//VERIFICAR LOS DATOS QUE RETORNA PARA LOS TPIS CORRESPONDIENTES
			if(mapLC.get("numeroLC15S9")!=null){
				String numelc = mapLC.get("numeroLC15S9").toString();
				mapNotificaLC15S9.put("generaLC15_SI_9", "SI");
				mapNotificaLC15S9.put("NumeroLC", numelc);
				mapNotificaLC15S9.put("codigoTPI", mapLC15S9.get("codigoTPI").toString());
				mapNotificaLC15S9.put("CodJefe", mapLC15S9.get("CodJefe").toString());
				mapNotificaLC15S9.put("desTpi", catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, mapLC15S9.get("codigoTPI").toString()));
				mapNotificaLC15S9.put("indicadorGarantia", mapLC15S9.get("indicadorGarantia"));
				mapNotificaLC15S9.put("certiOrigen", mapLC15S9.get("certiOrigen"));
			}
		}

		try{
			grabarNotificaciones (declaracion, mapaNotificaLC,mapNotificaLC15N9, mapNotificaLC15S9, variablesIngreso);
		}catch(Exception e)
		{
			log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir numeraci�n
		}

		if(fechaVencimientoConclusion != null) {
			parametros.clear();
			parametros = new HashMap<String, Object>();
			diferenciaFechas = 0;
			origen="grabarFormatoAService.grabaFormatoA";
			parametros.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo());
			parametros.put("COD_TIPPLZ", "06");
			parametros.put("FEC_INICIO", SunatDateUtils.getCurrentDate());
			parametros.put("FEC_FIN", fechaVencimientoConclusion);
			parametros.put("CNT_DURACION", diferenciaFechas);
			parametros.put("COD_UNIMED", "2");
			parametros.put("COD_ESTPLZ", "1");

			((PlazosProcesoDAO)fabricaDeServicios.getService("plazosprocesoDAO")).insert(parametros);
		}

		try {
			this.generarDeclaracionWebServiceVUCE(declaracion);
		} catch(Exception e){
			e.printStackTrace(); //Si existe error en envio a VUCE no debe impedir la numeracion
			log.error("Error al momento de Generar Declaracion para VUCE:"+e.getMessage());
		}

		return new HashMap<String, String>();
	}


	/**
	 * Genera la declaracion para VUCE
	 * @param declaracion
	 * @throws Exception
	 */
	private void generarDeclaracionWebServiceVUCE(Declaracion declaracion) throws Exception{
		Map<String, Object> params = new  HashMap<String, Object>(); 
		FechaBean fbCurrent=new FechaBean();
		Integer anho=new Integer(fbCurrent.getAnho());

		params.put("codigoAduana", declaracion.getDua().getCodaduanaorden());
		params.put("annoPresentacion", anho);
		params.put("codigoRegimen", declaracion.getDua().getCodregimen());
		params.put("numeroDeclaracion", declaracion.getNumeroDeclaracion());
		params.put("fechaEventoTransaccion", SunatDateUtils.getCurrentDate());
		params.put("codtipotrans", ConstantesDataCatalogo.COD_TRANSACCION_NUMERACION);
		DeclaracionWebService declaracionWebService= (DeclaracionWebService)fabricaDeServicios.getService("declaracionws.declaracionWebService");
		declaracionWebService.generarDeclaracionWebServiceVUCE(params);
		return;
	}



	public void afectarCtaCteVehiculosUsados(Declaracion declaracion, String IndAfectaDesafecta) {
		try {

			if(IndAfectaDesafecta!=null) {
				DatoSerie datoSerie = declaracion.getDua().getListSeries().get(0);
				DAV dav = declaracion.getListDAVs().get(0);
				DatoFactura factura = dav.getListFacturas().get(0);
				DatoItem item = factura.getListItems().get(0);
				Integer tpnSerie = datoSerie.getCodtratprefe();
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("CLIB", tpnSerie.toString());
				params.put("ADUANA", declaracion.getDua().getCodaduanaorden());
				if(IndAfectaDesafecta.equals(Constants.IND_AFECTA_CUENTA_CTE))
					params.put("CANT_AFECTA", 1);
				else{
					params.put("CANT_AFECTA", -1);
				}
				if(Integer.valueOf(244).equals(tpnSerie)) {				
					generarMapAfectaCtaCteVehUsado244(params, item, declaracion);								
				} else if(Integer.valueOf(227).equals(tpnSerie)) {
					generarMapAfectaCtaCteVehUsado227(params, item, declaracion);				
				}else if(Integer.valueOf(308).equals(tpnSerie)) {
					generarMapAfectaCtaCteVehUsado308(params, item, declaracion);	 
				}else {
					generarMapAfectaCtaCteVehUsadoGeneral(params, item, declaracion);								
				}
			}
		} catch (Exception e) {
			try {
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
	}

	/*indAfectaDesafectaRegPreDepo A: Afecta , D:Desafecta*/
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarDeclaracionService#afectarCtaCteRegPrecedeDeposito(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.lang.String, java.lang.String)
	 */
	public void afectarCtaCteRegPrecedeDeposito(Declaracion declaracion, String indAfectaDesafectaRegPreDepo, String numeroDocumentoIdentidadSender) {
		DepoctaDAO depoctaDAO = (DepoctaDAO) fabricaDeServicios.getService("depoctaDAO");
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen." +declaracion.getCodaduana()));

		if(indAfectaDesafectaRegPreDepo!=null) {
			Map<String,Object> updSerPoliz = new HashMap<String,Object>();
			updSerPoliz.putAll(completarMapUpdateSerPoliz(declaracion));
			depoctaDAO.update(updSerPoliz);		    
			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
				Elementos<DatoRegPrecedencia> precedencias=serie.getListRegPrecedencia();
				for(DatoRegPrecedencia precedencia:precedencias){
					if (Constants.REGI_DEPOSITO.equals(precedencia.getCodregipre())) {
						Map<String, Object> serPrece = generarClaveBusquedaDepocta(declaracion, serie, precedencia);
						List<Depocta> lstDepocta = depoctaDAO.findByMap(serPrece);
						if(lstDepocta == null || lstDepocta.size() == 0) {
							Map<String, Object> insPrece = new HashMap<String, Object>();
							insPrece.putAll(completarMapParaInsercionDepocta(declaracion, numeroDocumentoIdentidadSender, serie, precedencia));
							insPrece.putAll(serPrece);
							depoctaDAO.insert(insPrece);
						} else {
							Map<String, Object> updPrece = new HashMap<String, Object>();
							updPrece.putAll(completarMapParaActualizacionDepocta(serie));
							updPrece.putAll(serPrece);
							depoctaDAO.update(updPrece);
						}
					}
				}
			}
		}
		swapperDatasource.swap(o);  
	}

	private Map<String,Object> completarMapUpdateSerPoliz(Declaracion declaracion) {
		Map<String,Object> updSerPoliz = new HashMap<String,Object>();
		updSerPoliz.put("regiPoliz", declaracion.getDua().getCodregimen());
		updSerPoliz.put("numePoliz", Cadena.padLeft(declaracion.getNumeroDeclaracion().toString(), 6, '0'));//declaracion.getNumeroCorrelativo().toString());		
		updSerPoliz.put("sdel", "S");
		if (declaracion.getDua().getFecdeclaracion() != null && !SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion() )){
			updSerPoliz.put("fechIngpo", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
		}  else{
			FechaBean fechaIngpo = new FechaBean();
			updSerPoliz.put("fechIngpo", fechaIngpo.getFormatDate("yyyyMMdd"));			
		}
		return updSerPoliz;
	}

	private Map<String,Object> generarClaveBusquedaDepocta(Declaracion declaracion, DatoSerie serie, DatoRegPrecedencia precedencia) {
		Map<String,Object> serPrece = new HashMap<String,Object>();
		serPrece.put("codiAduan", precedencia.getCodaduapre());
		serPrece.put("anoPrese", precedencia.getAnndeclpre().toString().substring(2, 4));
		serPrece.put("numeCorre", Cadena.padLeft(precedencia.getNumdeclpre().toString(), 6, '0'));
		serPrece.put("numeSerpr", Cadena.padLeft(precedencia.getNumserpre().toString().trim(), 4, ' '));
		serPrece.put("regiPoliz", declaracion.getDua().getCodregimen());
		serPrece.put("numePoliz", Cadena.padLeft(declaracion.getNumeroDeclaracion().toString(), 6, '0'));//declaracion.getNumeroCorrelativo().toString());
		serPrece.put("numeSerie", Cadena.padLeft(serie.getNumserie().toString().trim(), 4, ' '));
		if (declaracion.getDua().getFecdeclaracion() != null && !SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion() )){
			serPrece.put("fechIngpo", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
		}  else{
			FechaBean fechaIngpo = new FechaBean();
			serPrece.put("fechIngpo", fechaIngpo.getFormatDate("yyyyMMdd"));			
		}
		//serPrece.put("difSdel", "S");
		return serPrece;
	}

	@SuppressWarnings("unchecked")
	private Map<String,Object> completarMapParaInsercionDepocta(Declaracion declaracion, String numeroDocumentoIdentidadSender, DatoSerie serie, DatoRegPrecedencia precedencia ) {
		CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaService");
		
		Map<String,Object> insPrece = new HashMap<String,Object>();	
		insPrece.put("codiAduan", precedencia.getCodaduapre());
		insPrece.put("anoPrese", precedencia.getAnndeclpre().toString().substring(2, 4));
		insPrece.put("numeCorre", Cadena.padLeft(precedencia.getNumdeclpre().toString(), 6, '0'));
		insPrece.put("numeSerpr", Cadena.padLeft(precedencia.getNumserpre().toString().trim(), 4, ' '));
		insPrece.put("regiPoliz", declaracion.getDua().getCodregimen());
		insPrece.put("numePoliz", Cadena.padLeft(declaracion.getNumeroDeclaracion().toString(), 6, '0')); ;
		insPrece.put("numeSerie", Cadena.padLeft(serie.getNumserie().toString().trim(), 4, ' '));
		Map<String, Object> operador = operadorAyudaService.getOperador(declaracion.getDua().getNumrucdeposito(), Constants.COD_DATA_CATALOG_DEPOSITO_ADUANERO);
		insPrece.put("codiDepo", (String)operador.get("cod_antadu"));
		insPrece.put("librTribu", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		Map<String, Object> operadorAgente = operadorAyudaService.getOperador(declaracion.getDua().getNumrucdeposito(), Constants.COD_DATA_CATALOG_AGENTE_ADUANA);

		insPrece.put("agenPoliz", (String)operadorAgente.get("cod_antadu"));
		String codCanal = cabdeclaraDAO.findCanalDua(declaracion.getDua().getNumcorredoc().toString());

		if( codCanal != null ) {
			insPrece.put("aforoPoli", codCanal);
		}
		if (declaracion.getDua().getFecdeclaracion() != null && !SunatDateUtils.isDefaultDate(declaracion.getDua().getFecdeclaracion() )){
			insPrece.put("fechIngpo", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
		} else{
			FechaBean fechaIngpo = new FechaBean();
			insPrece.put("fechIngpo", fechaIngpo.getFormatDate("yyyyMMdd"));			
		}

		insPrece.put("partNandi", serie.getNumpartnandi());
		insPrece.put("pesoNeto", serie.getCntpesoneto());
		insPrece.put("pesoBruto", serie.getCntpesobruto());
		insPrece.put("fobDolpol", serie.getMtofobdol());
		insPrece.put("fleDolar", serie.getMtofledol());
		insPrece.put("segDolar", serie.getMtosegdol());
		insPrece.put("cantBulto", serie.getCntbultos());
		insPrece.put("clase", serie.getCodclasbul());
		insPrece.put("descComer", SunatStringUtils.substring(serie.getDescomercial(), 0, 100));
		insPrece.put("unidFiqty", serie.getCntunifis());
		insPrece.put("unidFides", serie.getCodunifis());		
		return insPrece;
	}

	private Map<String,Object> completarMapParaActualizacionDepocta(DatoSerie serie) {
		Map<String,Object> updPrece = new HashMap<String,Object>();
		updPrece.put("partNandi", serie.getNumpartnandi());
		updPrece.put("descComer", SunatStringUtils.substring(serie.getDescomercial(), 0, 100));//PAS20165E220200152    
		updPrece.put("pesoNeto", serie.getCntpesoneto());
		updPrece.put("pesoBruto", serie.getCntpesobruto());
		updPrece.put("fobDolpol", serie.getMtofobdol());
		updPrece.put("fleDolar", serie.getMtofledol());
		updPrece.put("segDolar", serie.getMtosegdol());
		updPrece.put("cantBulto", serie.getCntbultos());
		updPrece.put("clase", serie.getCodclasbul());
		updPrece.put("unidFiqty", serie.getCntunifis());
		updPrece.put("unidFides", serie.getCodunifis());	
		updPrece.put("sdel", " ");
		return updPrece;
	}

	private void generarMapAfectaCtaCteVehUsado244(Map<String,Object> params, DatoItem item, Declaracion declaracion) throws Exception{
		VehiculoService vehiculoService = (VehiculoService)fabricaDeServicios.getService("ValidadorVehiculoService");	
		CantMaxLibeDAO cantMaxLibeDAO = (CantMaxLibeDAO)fabricaDeServicios.getService("cantMaxLibeDAO");
		params.put("ANN_FABR", item.getAnnfabrica());
		params.put("NUM_PARTIDA", item.getNumpartnandi());
		String codMarca = vehiculoService.obtenerMarca(item,declaracion);
		if( codMarca != null ) {
			params.put("COD_MARCA", codMarca);	
		}
		String codModelo = vehiculoService.obtenerModelo(item, declaracion);
		if( codModelo != null ) {
			params.put("COD_MODELO", codModelo);	
		}
		cantMaxLibeDAO.updateCtaCteVehicUsadosTratoPref244(params);
	}

	private void generarMapAfectaCtaCteVehUsado227(Map<String,Object> params, DatoItem item,  Declaracion declaracion) throws Exception {

		VehiculoService vehiculoService = (VehiculoService)fabricaDeServicios.getService("ValidadorVehiculoService");		
		CantMaxLibeDAO cantMaxLibeDAO = (CantMaxLibeDAO)fabricaDeServicios.getService("cantMaxLibeDAO");
		params.put("ANN_FABR", item.getAnnfabrica());
		//String codMarca = obtenerValComer(item, "01");
		String codMarca = vehiculoService.obtenerMarca(item,declaracion);
		if( codMarca != null ) {
			params.put("COD_MARCA", codMarca);	
		}				
		//String codChasis = obtenerCodChasis(item);
		String codChasis = vehiculoService.obtenerChasis(item, declaracion);
		if( codChasis != null ) {
			params.put("COD_CHASIS_VEHI", codChasis);
		}
		cantMaxLibeDAO.updateCtaCteVehicUsadosTratoPref227(params);	
	}

	private void generarMapAfectaCtaCteVehUsado308(Map<String,Object> params, DatoItem item,  Declaracion declaracion) throws Exception {
		VehiculoService vehiculoService = (VehiculoService)fabricaDeServicios.getService("ValidadorVehiculoService");
		CantMaxLibeDAO cantMaxLibeDAO = (CantMaxLibeDAO)fabricaDeServicios.getService("cantMaxLibeDAO");
		params.put("ANN_FABR", item.getAnnfabrica());
		String codMarca = vehiculoService.obtenerMarca(item,declaracion);
		if( codMarca != null ) {
			params.put("COD_MARCA", codMarca);	
		}				
		String codChasis = vehiculoService.obtenerChasis(item, declaracion);
		if( codChasis != null ) {
			params.put("COD_CHASIS_VEHI", codChasis);
			params.put("SERIE_DEC", codChasis.length()>16?SunatStringUtils.substringFox(codChasis,11,7):codChasis.substring(codChasis.indexOf('-')+1));
		}
		cantMaxLibeDAO.updateCtaCteVehicUsadosTratoPref308(params);	
	}

	private void generarMapAfectaCtaCteVehUsadoGeneral(Map<String,Object> params, DatoItem item,  Declaracion declaracion) throws Exception {
		VehiculoService vehiculoService = (VehiculoService)fabricaDeServicios.getService("ValidadorVehiculoService");
		CantMaxLibeDAO cantMaxLibeDAO = (CantMaxLibeDAO)fabricaDeServicios.getService("cantMaxLibeDAO");
		params.put("CPAIS_ORIGEN", item.getCodpaisorige());
		String codChasis = vehiculoService.obtenerChasis(item, declaracion);
		if( codChasis != null ) {
			params.put("COD_CHASIS_VEHI", codChasis);
			params.put("SERIE_DEC", codChasis.substring(codChasis.indexOf('-')+1));
			params.put("ANHO_DEC", item.getAnnfabrica());
		}
		cantMaxLibeDAO.updateCtaCteVehicUsadosGeneral(params);
	}


	protected void actualizarEnvio(Integer annEnvio, Long numEnvio, Long num_corredoc)
	{
		EnvioDAO envioDAO =  (EnvioDAO)fabricaDeServicios.getService("manifiesto.envioDAO");
		EnvioBean envio = new EnvioBean();
		envio.setAnioEnvio(annEnvio);
		envio.setNumeroEnvio(numEnvio);
		envio.setNumeroCorrelativo(num_corredoc);

		try {
			envioDAO.actualizarEnvio(envio);	
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}



	@Override
	/**
	 * Graba el envio complementario del Formato B. 
	 * @param declaracion. Declaracion con el Formato A y B
	 */
	public Map<String, String> grabarEnvioComplementario(Map<String, Object> variablesIngreso) {
		GrabarFormatoBService grabarFormatoBService = (GrabarFormatoBService) fabricaDeServicios.getService("grabarFormatoBService");
		GeneraRespuestaService generaRespuestaService = (GeneraRespuestaService)fabricaDeServicios.getService("GenRespuestaServiceImpl");
		if(UserNameHolder.get()==null) 
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);

		Declaracion declaracion = (Declaracion) variablesIngreso .get("declaracion");
		declaracion.setNumeroCorrelativo( declaracion.getDua().getNumcorredoc() );
		grabarFormatoBService.grabaFB(declaracion);
		generaRespuestaService.generaRespuestaEnvio(0, variablesIngreso);
		return new HashMap<String, String>();
	}

/*	public void setGrabarRectificacionService(
			GrabarRectificacionService grabarRectificacionService) {
		this.grabarRectificacionService = grabarRectificacionService;
	}*/

	public void desafectarCtaCteRegPrecedeDeposito(Map<String,Object> params){
		DepoctaDAO depoctaDAO = (DepoctaDAO) fabricaDeServicios.getService("depoctaDAO");
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen." + params.get("codiAduan")));
		depoctaDAO.update(params);
		swapperDatasource.swap(o);
	}	


	@SuppressWarnings("unchecked")
	public void desafectaGarantia (Declaracion declaracion,	Map<String, Object> variablesIngreso) {
		String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		String numOrden 		= (String) variablesIngreso.get("numOrden");
		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;

		HashMap mapGarantia = (HashMap)variablesIngreso.get("mapGarantia");
		BigDecimal montoAcumuladoDolares = BigDecimal.ZERO;

		if ("OK".equals(mapGarantia.get("resultado"))) {
			montoAcumuladoDolares = (BigDecimal)mapGarantia.get("mtoAfectado");
			Map params = new HashMap();
			params.put("cRUC",declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del beneficiario
			params.put("cADUANA",null);
			params.put("cANO",null);
			params.put("cREGIMEN",null);
			params.put("cNUMERO"," ");
			params.put("cNUMREF",codGarantia);
			params.put("cCDA"," ");
			params.put("cRUCAGENTE",numeroDocumentoIdentidadSender); // RUC del agente
			params.put("cORDEN",numOrden); // viene a�o y numero
			params.put("nMONTOA",montoAcumuladoDolares); // soles  + dolares
			params.put("cMONEDAA","D");
			params.put("nFECHA1",SunatDateUtils.getCurrentIntegerDate());
			params.put("cMODULO","ET");
			params.put("cTRANS","010");
			((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
		}

	}

	public void grabarIndicadorPlazoNumeracion(Declaracion declaracion, long numcorredoc){
		grabarIndicadorPlazoNumeracion(declaracion,numcorredoc,"");
	}


	/**
	 * Resumen: graba en la tabla indicadorDUA y plazos CUS 01.12.02
	 * @param declaracion
	 * @param numcorredoc
	 * @throws Exception
	 * @autor oneyraj
	 */
	public void grabarIndicadorPlazoNumeracion(Declaracion declaracion, long numcorredoc, String codTransacion){
		IndicadorDUADAO indicadorDuaDAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		Map<String, Object> mapaIndicadorDUA = new HashMap<String, Object>();
		mapaIndicadorDUA.put("num_corredoc", numcorredoc);
		mapaIndicadorDUA.put("cod_indicador", COD_INDICADOR_VP);

		//amancilla PAS20155E220200167 se necesita saber en que proceso se genera la LC T - numeracion 1001, A automatico 1003 rectificacion automatica, P portal diligencias inclutendo Diligencia Rectificacion
		String lugarDondeGeneraLCVP = "A"; //PAS20181U220200014
//		if("1001".equals(codTransacion) || SunatStringUtils.isEmptyTrim(codTransacion)){
//			lugarDondeGeneraLCVP="T";
//		}else if("1003".equals(codTransacion)){
//			lugarDondeGeneraLCVP="A";
//		}else {
//			lugarDondeGeneraLCVP="P";
//		}

		int existeIndicador = ((BigDecimal) indicadorDuaDAO.existsIndicadorByDocumentoAndCodigo(mapaIndicadorDUA).get("CANT")).intValue();

		if(existeIndicador == 0){
			mapaIndicadorDUA.clear();
			mapaIndicadorDUA.put("NUM_CORREDOC", numcorredoc);
			mapaIndicadorDUA.put("COD_INDICADOR", COD_INDICADOR_VP);
			mapaIndicadorDUA.put("COD_TIPOREGISTRO", lugarDondeGeneraLCVP);
			try {
				indicadorDuaDAO.insert(mapaIndicadorDUA);
			} catch (Exception e) {

				throw new ServiceException(this, e.getMessage());
			}	
		}else{
			mapaIndicadorDUA.clear();
			mapaIndicadorDUA.put("numCorredoc", numcorredoc);
			mapaIndicadorDUA.put("codIndicador", COD_INDICADOR_VP);
			mapaIndicadorDUA.put("indActivo", IND_ACTIVO);
			indicadorDuaDAO.update(mapaIndicadorDUA);
		}

		// Insertando plazos de proceso
		PlazosProceso plazoProceso = new PlazosProceso();
		plazoProceso.setNumeroCorrelativo(numcorredoc);
		plazoProceso.setTipoPlazo(COD_CATALOGO_TIPO_PLAZO);
		plazoProceso.setFechaFin(declaracion.getDua().getFecfinprovsional());
		PlazosProcesoDAO plazosProcesoDAO = (PlazosProcesoDAO) fabricaDeServicios.getService("plazosprocesoDAO");
		List<PlazosProceso> listPlazos = plazosProcesoDAO.selectSelective(plazoProceso);
		if(CollectionUtils.isEmpty(listPlazos)){
			try {
				plazoProceso.setFechaInicio(new Date());
				plazosProcesoDAO.insertSelective(plazoProceso);
			} catch (Exception e) {

				throw new ServiceException(this, e.getMessage());
			}	
		}else{
			plazosProcesoDAO.update(plazoProceso);

		}

		if(!"1007".equals(codTransacion))
		{
			VFOBProvisionalDAO fobProvisionalDAO = (VFOBProvisionalDAO) fabricaDeServicios.getService("fobProvisionalDAO");
			if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
				for(DAV dav : declaracion.getListDAVs()){
					for(DatoFactura datoFactura : dav.getListFacturas()){
						for(DatoItem datoItem : datoFactura.getListItems()){
							if(datoItem.getMontoProv().getValmonto()!=null){
								BigDecimal mtoValorProvisionalItem = datoItem.getMontoProv().getValmonto();
								Map<String, Object> datos = new HashMap<String, Object>();
								datos.put("NUM_CORREDOC", numcorredoc);
								datos.put("NUM_SECITEM", datoItem.getNumsecitem());								
								datos.put("MTO_MONTO", mtoValorProvisionalItem);
								datos.put("MTO_DEFINITIVO", BigDecimal.ZERO); //Conforme indica alternativa de sol. al bug 21103
								fobProvisionalDAO.updateMapSelective(datos);
							}

						}
					}
				}
			}
		}
	}

	private Map<String,String>  getWarningMap(String errorCode, String errorDescription){
		Map<String,String> map = new HashMap<String, String>();
		map.put(ResponseMapManager.KEY_CODIGO, SunatStringUtils.isEmpty(errorCode) ? "-": errorCode );
		map.put(ResponseMapManager.KEY_DESCRIPCION, SunatStringUtils.isEmpty(errorDescription) ? "-": errorDescription);
		return map;
	}	

	/**
	 * Verificamos la existencia del deuda_docum
	 * @param declaracion
	 * @return
	 */
	private boolean verificaDeudaDeclaracion(Declaracion declaracion){
		DeudaDocum tmpDeudaDocumDon = new DeudaDocum();
		tmpDeudaDocumDon.setNumCorredoc(declaracion.getNumeroCorrelativo());
		tmpDeudaDocumDon.setCodTipdeuda("01");
		DeudaDocumDAO documDAO = fabricaDeServicios.getService("deudaDocumDef");
		List<DeudaDocum> lstDeudaDocum = documDAO.selectByDocumento(tmpDeudaDocumDon);
		if(CollectionUtils.isEmpty(lstDeudaDocum)){
			return false;
		}
		return true;
	}
	
	//Inicio HAcostaR P_SNAA0001- FAST - Procesos de Salida - Regimen Especial  de Material de Guerra
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> grabarNumeracionMaterialGuerra(Map<String, Object> mapCabDeclara){

		if(UserNameHolder.get()==null)
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);
		
		FechaBean fbCurrent=new FechaBean();		
		Map<String, Object> mapRpta = new HashMap<String, Object>();
		
		//Obtener Secuencia del NUM_CORREDOC
		Declaracion declaracion = new Declaracion();
		DUA dua = new DUA();
		dua.setCodregimen((String)mapCabDeclara.get("codRegimen"));
		dua.setCodaduanaorden((String)mapCabDeclara.get("codAduana"));
		declaracion.setDua(dua);
		declaracion.setCodaduana((String)mapCabDeclara.get("codAduana"));
		SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
		SecuenciaPerdida secuencia = secuenciaDeclaracionService.generaSecuenciaDeclaracion(declaracion);
		
		//Registrar Documento
		Documento documento=new Documento();
		DocumentoDAO documentoDAO = (DocumentoDAO)fabricaDeServicios.getService("documentoDAO");
		documento.setNumeroCorrelativo(secuencia.getNumeroCorrelativo());
		documento.setEstado("00");
		documento.setTipoDocumento("929");		
		documento.setCodAduana(declaracion.getCodaduana());
		documento.setFechaGeneracion( SunatDateUtils.getCurrentDate() );
		documentoDAO.insertSelective(documento);
		
		//Registrar CAB_DECLARA
		mapCabDeclara.put("annPresen", fbCurrent.getAnho());
		//mapCabDeclara.put("annOrden", fbCurrent.getAnho());
		mapCabDeclara.put("numcorredoc", secuencia.getNumeroCorrelativo());
		mapCabDeclara.put("numDeclaracion", declaracion.getNumeroDeclaracion());
		CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");		
		cabdeclaraDAO.insertMapSelective(mapCabDeclara);
		
		//Registrar DET_DECLARA
		
		String numDeclaracion = dua.getCodaduanaorden().concat("-").concat(fbCurrent.getAnho()).concat("-").concat(dua.getCodregimen()).concat("-").concat(declaracion.getNumeroDeclaracion().toString());
		mapRpta.put("numDeclaracion", numDeclaracion);
		mapRpta.put("numcorredoc", declaracion.getNumeroCorrelativo());
		mapRpta.put("numDAM", declaracion.getNumeroDeclaracion());
		
		//Registrar Datado
		//DatadoService datadoService = (DatadoService) fabricaDeServicios.getService("manifiesto.datado2Service");
		/*
		Map<String, Object> parameterCountMap = new HashMap<String, Object>();
		parameterCountMap.put("detalleNumeroCorrelativo", datado.getDua().getNumcorredoc());
		parameterCountMap.put("numeroCorrelativo", datado.getDocumentoDeTransporte().getManifiesto().getNumeroCorrelativo());
		parameterCountMap.put("numeroDeDetalle", datado.getDocumentoDeTransporte().getNumeroDeDetalle());
		
    	datado.setSecuencia(Integer.valueOf(datadoDAO.findCountByParameterMap(parameterCountMap)));
    	
    	datadoDAO.insertSelective(datado);*/
		/*Datado datado = new Datado();
		datado.getDua().setNumcorredoc(declaracion.getNumeroCorrelativo());
		Manifiesto manifiesto = new Manifiesto();
		manifiesto.setAnioManifiesto(Integer.parseInt(mapCabDeclara.get("annManifiesto").toString()));
		DataCatalogo datacatalogo = new DataCatalogo();
		datacatalogo.setCodDatacat(mapCabDeclara.get("codAduamanifiesto").toString());
		manifiesto.setAduana(datacatalogo);
		datacatalogo = new DataCatalogo();
		datacatalogo.setCodDatacat(mapCabDeclara.get("codTipmanifiesto").toString());
		manifiesto.setTipoManifiesto(datacatalogo);
		datacatalogo = new DataCatalogo();
		datacatalogo.setCodDatacat(mapCabDeclara.get("codViatrans").toString());
		manifiesto.setViaTransporte(datacatalogo);
		manifiesto.setNumeroManifiesto( ManifiestoUtil.formatearNumeroManifiestoSigad(mapCabDeclara.get("numManifiesto").toString()) );
		manifiesto.setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
		datado.getDocumentoDeTransporte().setManifiesto(manifiesto);
		datado.getDua().setCodregimen(mapCabDeclara.get("codRegimen").toString());
		datado.getDua().setNumdocumento(declaracion.getNumeroCorrelativo().toString());
		datado.getDua().setCodaduanaorden(mapCabDeclara.get("codAduana").toString());
		datado.getDua().setAnnpresen(Integer.parseInt(fbCurrent.getAnho()));
		datado.setTotalPesoBruto((BigDecimal)mapCabDeclara.get("cntPesobrutoTotal"));
		datado.setTotalBulto((BigDecimal)mapCabDeclara.get("cntTotbultos"));*/
	
		//datado.getDocumentoDeTransporte().setNumeroDeDetalle(Integer.parseInt());
		//datado.getDocumentoDeTransporte().setNumeroDeDetalleAsString(ManifiestoUtil.getformatearNumeroDeDetalleAsAntiguoSigad());
		
		//<isNotNull prepend="," property="documentoDeTransporte.manifiesto.numeroCorrelativo" >        NUM_CORREDOC
			      //<isNotNull prepend="," property="documentoDeTransporte.numeroDeDetalle" >        NUM_DETALLE
			      //<isNotNull prepend="," property="documentoDeTransporte.numeroDeDetalleAsString" >        NUM_DETALLE
		/*
		
      <isNotNull prepend="," property="fechaDeclaracionAsInteger" >        fech_reg
      <isNotNull prepend="," property="secuencia" >        NUM_SECUENCIA
      <isNotNull prepend="," property="fechaDatado" >        FEC_DATADA
      <isNotNull prepend="," property="fechaVincula" >        FEC_VINCULA
      <isNotNull prepend="," property="totalPesoBruto" >        CNT_PESO_DATADO
      <isNotNull prepend="," property="totalBulto" >        CNT_BULTO
      <isNotNull prepend="," property="descripcionObservacion" >        DES_OBSERVACION
      <isNotNull prepend="," property="fechaRegulariza" >       FEC_REGULARIZA      
      <isNotNull prepend="," property="tipo.codDatacat" >        TIPO
      <isNotNull prepend="," property="regularizado" >        SREGUL
      <isNotNull prepend="," property="documentoDeTransporte.numeroDocumentoTransporte" >        NUMCON
       <isNotNull prepend="," property="codageadu" >        CODAGEADU
      <isNotNull prepend="," property="documentoDeTransporte.numeroDeDetalleAsString" >        NUMDET
      <isNotNull prepend="," property="operador.tipoParticipante.codDatacat" >        COD_TIPO_OPERADOR
      <isNotNull prepend="," property="operador.tipoDocumentoIdentidad.codDatacat" >        COD_TIPO_DOCUM
      <isNotNull prepend="," property="operador.numeroDocumentoIdentidad" >        NUM_DOCUM
      <isNotNull prepend="," property="tipoOperacion" >			COD_TIPO_OPERACION      */
		
		//datadoService.insertarDatado(datado); 

//		origen="grabarFormatoAService.grabaFormatoA";
//		grabarFormatoAService.grabaFormatoA(declaracion, tipoSender, numeroDocumentoIdentidadSender,
//				tipoDocumentoIdentidadSender,fechaConclusionDespa, numOrden, codTransaccion, 
//				fechaVencimientoConclusion, listaDocumentosVUCE);
//		grabarFormatoAService.grabarParticipanteSEIDA( codUsuario,  tipoSender,  declaracion.getNumeroCorrelativo());
//		pintaMensaje(origen);
//		origen="grabarTablasAntiguasService.grabarTablasAntiguas";
//		grabarTablasAntiguasService.grabarTablasAntiguas(declaracion, variablesIngreso);
//		pintaMensaje(origen);


//		if (validar) { 
//			origen="grabarGeneralService.registrarDatado";
//			grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_NUMERACION,codTransaccion, variablesIngreso);
//			pintaMensaje(origen);
//		}

//		try{
//			grabarNotificaciones (declaracion, mapaNotificaLC,mapNotificaLC15N9, mapNotificaLC15S9, variablesIngreso);
//		}catch(Exception e)
//		{
//			log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir numeraci�n
//		}
		
		return mapRpta;
	}
	//Fin HAcostaR P_SNAA0001- FAST - Procesos de Salida - Regimen Especial  de Material de Guerra
	
	/*
	public GrabarFormatoAService getGrabarFormatoAService() {
		return grabarFormatoAService;
	}

	public GrabarFormatoBService getGrabarFormatoBService() {
		return grabarFormatoBService;
	}

	public void setGrabarFormatoAService(GrabarFormatoAService grabarFormatoAService) {
		this.grabarFormatoAService = grabarFormatoAService;
	}

	public void setGrabarFormatoBService(GrabarFormatoBService grabarFormatoBService) {
		this.grabarFormatoBService = grabarFormatoBService;
	}
	
	public void setGeneraLiquidacionService(GeneraLiquidacionService generaLiquidacionService) {
		this.generaLiquidacionService = generaLiquidacionService;
	}	

	public void setEnvioDAO(EnvioDAO envioDAO) {
		this.envioDAO = envioDAO;
	}
	*/
/*
	public void setCantMaxLibeDAO(CantMaxLibeDAO cantMaxLibeDAO) {
		this.cantMaxLibeDAO = cantMaxLibeDAO;
	}


	public SeleccionService getSeleccionservice() {
		return seleccionservice;
	}

	public void setSeleccionservice(SeleccionService seleccionservice) {
		this.seleccionservice = seleccionservice;
	}

	public GeneraRespuestaService getGeneraRespuestaService() {
		return generaRespuestaService;
	}

	public void setGeneraRespuestaService(
			GeneraRespuestaService generaRespuestaService) {
		this.generaRespuestaService = generaRespuestaService;
	}

	public GrabarGeneralService getGrabarGeneralService() {
		return grabarGeneralService;
	}

	public void setGrabarGeneralService(GrabarGeneralService grabarGeneralService) {
		this.grabarGeneralService = grabarGeneralService;
	}

	public GrabarRectificacionService getGrabarRectificacionService() {
		return grabarRectificacionService;
	}

	public GeneraLiquidacionService getGeneraLiquidacionService() {
		return generaLiquidacionService;
	}

	public EnvioDAO getEnvioDAO() {
		return envioDAO;
	}

	public CantMaxLibeDAO getCantMaxLibeDAO() {
		return cantMaxLibeDAO;
	}

	public DepoctaDAO getDepoctaDAO() {
		return depoctaDAO;
	}

	public CabDeclaraDAO getCabdeclaraDAO() {
		return cabdeclaraDAO;
	}

	public OperadorAyudaService getOperadorAyudaService() {
		return operadorAyudaService;
	}

	public void setDepoctaDAO(DepoctaDAO depoctaDAO) {
		this.depoctaDAO = depoctaDAO;
	}

	public void setCabdeclaraDAO(CabDeclaraDAO cabdeclaraDAO) {
		this.cabdeclaraDAO = cabdeclaraDAO;
	}

	public void setOperadorAyudaService(OperadorAyudaService operadorAyudaService) {
		this.operadorAyudaService = operadorAyudaService;
	}


	public GeneraRespuestaService getGenRespuestaService() {
		return generaRespuestaService;
	}

	public void setGenRespuestaService(GeneraRespuestaService generaRespuestaService) {
		this.generaRespuestaService = generaRespuestaService;
	}

	public void setSecuenciaDeclaracionService(
			SecuenciaDeclaracionService secuenciaDeclaracionService) {
		this.secuenciaDeclaracionService = secuenciaDeclaracionService;
	}
	public void setGrabarTablasAntiguasService(
			GrabarTablasAntiguasService grabarTablasAntiguasService) {
		this.grabarTablasAntiguasService = grabarTablasAntiguasService;
	}

	public GrabarTablasAntiguasService getGrabarTablasAntiguasService() {
		return grabarTablasAntiguasService;
	}
*/
	private void pintaMensaje(String mensaje) {
		Long tiempo = System.currentTimeMillis();
		if (log.isDebugEnabled()) {
			log.debug(mensaje.concat(" - Hora: ").concat(tiempo.toString()));
		}
	}
/*
	public void setExigibilidadService(ExigibilidadService exigibilidadService) {
		this.exigibilidadService = exigibilidadService;
	}*/
	/**
	 * 
	 * @param grabarContingentesService
	 */
	/*
	public void setGrabarContingentesService(GrabarContingentesService grabarContingentesService) {
		this.grabarContingentesService = grabarContingentesService;
	}

	public void setPublicacionAvisoService(
			PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}

	public void setCatalogoAyudaService(
			CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	
	public ValidacionGeneralService getValidacionGeneral() {
		return validacionGeneral;
	}

	
	public void setValidacionGeneral(ValidacionGeneralService validacionGeneral) {
		this.validacionGeneral = validacionGeneral;
	}

	public PlazosProcesoDAO getPlazosprocesodao() {
		return plazosprocesodao;
	}

	public void setPlazosprocesodao(PlazosProcesoDAO plazosprocesodao) {
		this.plazosprocesodao = plazosprocesodao;
	}
	public void setFobProvisionalDAO(VFOBProvisionalDAO fobProvisionalDAO) {
		this.fobProvisionalDAO = fobProvisionalDAO;
	}

	public void setPlazosProcesoDAO(PlazosProcesoDAO plazosProcesoDAO) {
		this.plazosProcesoDAO = plazosProcesoDAO;
	}

	public void setIndicadorDuaDAO(IndicadorDUADAO indicadorDuaDAO) {
		this.indicadorDuaDAO = indicadorDuaDAO;
	}

	public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}*/
	// Inicio ptorres Fast - Regimenes Especiales 
	@Override
	public Map<String, Object> grabarNumeracionRegimenesEspeciales(Declaracion declaracionRegEsp) {
		// TODO Auto-generated method stub
		Map<String, Object> mapRpta = new HashMap<String, Object>();
		try {
			SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
			SecuenciaPerdida secuencia = secuenciaDeclaracionService.generaSecuenciaDeclaracion(declaracionRegEsp);
			/*DUA dua = new DUA();
			dua.setCodregimen((String)mapCabDeclara.get("codRegimen"));
			dua.setCodaduanaorden((String)mapCabDeclara.get("codAduana"));
			declaracion.setDua(dua);*/
			//Registrar Documento
				Documento documento=new Documento();
				DocumentoDAO documentoDAO = (DocumentoDAO)fabricaDeServicios.getService("documentoDAO");
				documento.setNumeroCorrelativo(secuencia.getNumeroCorrelativo());
				documento.setEstado("00");
				documento.setTipoDocumento("929");		
				documento.setCodAduana(declaracionRegEsp.getCodaduana());
				documento.setFechaGeneracion(SunatDateUtils.getCurrentDate() );
				documentoDAO.insertSelective(documento);
				
				FechaBean fbCurrent=new FechaBean();
				Map<String, Object> mapCabDeclara = new HashMap<String, Object>();
				mapCabDeclara.put("annpresen", fbCurrent.getAnho());
				fomatearMapDeclara(mapCabDeclara, declaracionRegEsp);
				
				//Registrar CAB_DECLARA
				CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
				cabdeclaraDAO.insertMapSelective(mapCabDeclara);
				DUA dua = declaracionRegEsp.getDua();
				dua.setNumcorredoc(Long.valueOf((mapCabDeclara.get("numcorredoc").toString())));
				dua.setNumorden(mapCabDeclara.get("numDeclaracion").toString());
				//Registrar Series DET_DECLARA
				Elementos<DatoSerie> lstElementSerie = dua.getListSeries();
				if (!CollectionUtils.isEmpty(lstElementSerie)){
					DeclaracionService declaracionService = fabricaDeServicios.getService("declaracion.DeclaracionService");		
					for (DatoSerie serie : lstElementSerie){
						Map<String, Object> mapDetDeclara = new HashMap<String, Object>();
						formatearDetDeclara(mapDetDeclara, serie, dua);
						declaracionService.registraDetDeclara(mapDetDeclara);						
					}												
				}				
				//Registrar Participantes:
				//Registrar Participante Declarante - Beneficiario
				Participante declarante = dua.getDeclarante();
				SequenceDAO sequenceDAO = fabricaDeServicios.getService("sequenceDAO");
				Long numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
				declarante.setSecuenciaDeParticipantes(numSecParticipante);
				declarante.getDocumento().setNumeroCorrelativo(dua.getNumcorredoc());
				ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
				participanteDAO.insertSelective(declarante);
				//Registrar Participante Transportista
				if (null!=dua.getManifiesto().getEmpTransporte()){
					Participante transportista = dua.getManifiesto().getEmpTransporte();
					numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
					transportista.setSecuenciaDeParticipantes(numSecParticipante);
					transportista.getDocumento().setNumeroCorrelativo(dua.getNumcorredoc());
					participanteDAO.insertSelective(transportista);
				}
			
				//Registrar Participante - Punto de Llegada
				Participante puntoLlegada = dua.getDepositoTemporal();
				if (puntoLlegada!=null){
					numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
					puntoLlegada.setSecuenciaDeParticipantes(numSecParticipante);
					puntoLlegada.getDocumento().setNumeroCorrelativo(declaracionRegEsp.getNumeroCorrelativo());
					participanteDAO.insertSelective(puntoLlegada);
				}
				
				//Registrar Participante - Agente de Aduanas
				Participante agenteAduanas = dua.getAgenteAduanas();
				if (agenteAduanas!=null){
					numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
					agenteAduanas.setSecuenciaDeParticipantes(numSecParticipante);
					agenteAduanas.getDocumento().setNumeroCorrelativo(declaracionRegEsp.getNumeroCorrelativo());
					participanteDAO.insertSelective(agenteAduanas);
				}
				
				String numDeclaracion = dua.getCodaduanaorden().concat("-").concat(fbCurrent.getAnho()).concat("-").concat(dua.getCodregimen()).concat("-").concat(declaracionRegEsp.getNumeroDeclaracion().toString());
				mapRpta.put("numDeclaracion", numDeclaracion);
				mapRpta.put("numcorredoc", declaracionRegEsp.getNumeroCorrelativo());
				mapRpta.put("fechaDAM", mapCabDeclara.get("fecDeclaracion"));//HAcostaR - RN SALIDA REINGRESO
				if ( null!=dua.getCodregimen() && (dua.getCodregimen().equals("82")|| dua.getCodregimen().equals("86"))){
					mapRpta.put("fechaVencimientoDAM", mapCabDeclara.get("fecVenregimen"));//HAcostaR - RN SALIDA REINGRESO
				}
							
	}catch(Exception e){
		  e.printStackTrace();
          log.error("Error en metodo grabarNumeracionRegimenesEspeciales : "+e.getMessage());
		}
		return mapRpta;
	}
	
		private void fomatearMapDeclara(Map<String, Object> mapCabDeclara, Declaracion declaracionRegEsp){
			DUA dua = declaracionRegEsp.getDua();
			mapCabDeclara.put("codRegimen", dua.getCodregimen());
			mapCabDeclara.put("numcorredoc", declaracionRegEsp.getNumeroCorrelativo());
			mapCabDeclara.put("codAduana", dua.getCodaduanaorden());
			mapCabDeclara.put("numDeclaracion", declaracionRegEsp.getNumeroDeclaracion());
			mapCabDeclara.put("codModalidad", dua.getCodmodalidad());
			mapCabDeclara.put("codTipdesp", dua.getCodtipoperacion());
			//mapCabDeclara.put("codAdudest", dua.getOtraAduana().getCodopadusal());
			//HAcostaR Inicio - FAST SALIDA - RANCHO DE NAVE - SALIDA REINGRESO
			mapCabDeclara.put("mtoTotfobdol",dua.getMtotfobclvta()!=null?dua.getMtotfobclvta() : new BigDecimal("0.0"));//VALOR TOTAL FOB DE LA MERCANCIA USD
			//HAcostaR Fin - FAST SALIDA - RANCHO DE NAVE - SALIDA REINGRESO
			mapCabDeclara.put("cntPesobrutoTotal", dua.getCnttpesobruto());
			mapCabDeclara.put("cntPesonetoTotal", dua.getCnttpesoneto());
			mapCabDeclara.put("cntTotbultos", dua.getCnttcantbulto());
			mapCabDeclara.put("cntTotseries", dua.getCntnumseries());
			mapCabDeclara.put("codEstdua", dua.getCodEstdua());
			//mapCabDeclara.put("codTiptratmerc", dua.getCodtipotratamiento());
			if (null!=dua.getCnttqunifis())				
			mapCabDeclara.put("cntTqunifis", dua.getCnttqunifis());
			mapCabDeclara.put("fecDeclaracion", SunatDateUtils.getCurrentDate());
			mapCabDeclara.put("codTipoplazo", dua.getCodtipoplazo());
			mapCabDeclara.put("numPlazosol", dua.getNumplazosol());
			if ( null!=dua.getCodregimen() && (dua.getCodregimen().equals("82")|| dua.getCodregimen().equals("86"))){				
				mapCabDeclara.put("fecVenregimen", SunatDateUtils.addDay(SunatDateUtils.getCurrentDate(), 30));
			}			
			mapCabDeclara.put("codTiplugarrecep", dua.getCodlugarecepcion()!=null?dua.getCodlugarecepcion():" ");
			mapCabDeclara.put("codLugarrecep", dua.getCodtiplugarrecep()!=null? dua.getCodtiplugarrecep():" ");
			mapCabDeclara.put("codRuclugrecep", dua.getNumruclugarecep()!=null? dua.getNumruclugarecep(): " ");//TODO numrucdeposito
			mapCabDeclara.put("codTipgrabado", declaracionRegEsp.getCodtipotrans());
			mapCabDeclara.put("annPresen", SunatDateUtils.getAnho(SunatDateUtils.getCurrentDate()));			
			//Datos del Manifiesto
			//mapCabDeclara.put("fecLlegada",dua.getManifiesto().getFectermino());
			DatoManifiesto datoMan = dua.getManifiesto();
			if (null!=datoMan){
				mapCabDeclara.put("codViatrans", datoMan.getCodmodtransp());
				mapCabDeclara.put("codTipmanifiesto", datoMan.getCodtipomanif());
				mapCabDeclara.put("codAduamanifiesto", datoMan.getCodaduamanif());
				mapCabDeclara.put("annManifiesto", datoMan.getAnnmanif());
				mapCabDeclara.put("numManifiesto", datoMan.getNummanif());
				mapCabDeclara.put("numViaje", datoMan.getNumviaje());	
				//mapCabDeclara.put("fecLlegada",datoMan.getFectermino());
			}	
			//se agrega mua ingreso
			if (null!=dua.getAnnorden())	
			mapCabDeclara.put("annOrden", dua.getAnnorden());	
			if (null!= dua.getNumorden())
			mapCabDeclara.put("numOrden", dua.getNumorden());
		}
		
		private void formatearDetDeclara(Map<String, Object> mapDetDeclara, DatoSerie serie, DUA dua){
			mapDetDeclara.put("numCorredoc",dua.getNumcorredoc());
			mapDetDeclara.put("numSecserie",serie.getNumserie());
			mapDetDeclara.put("cntBulto",serie.getCntbultos()!=null?serie.getCntbultos():0);
			mapDetDeclara.put("cntPesoBruto",serie.getCntpesobruto()!=null?serie.getCntpesobruto():0);
			mapDetDeclara.put("codMonetrans",serie.getCodmoneda()!=null?serie.getCodmoneda():" ");
			//HAcostaR Inicio - FAST SALIDA - RANCHO DE NAVE - SALIDA REINGRESO
			mapDetDeclara.put("mtoFobdol",serie.getMtofobdol()!=null?serie.getMtofobdol() : new BigDecimal("0.0"));//VALOR DE LA MERCANCIA USD
			mapDetDeclara.put("desComer",serie.getDescomercial()!=null?serie.getDescomercial():" ");//DESCRIPCION DE LA MERCANCIA
			mapDetDeclara.put("desFormapresen",serie.getDesformapres()!=null?serie.getDesformapres():" ");//MARCA DE LA MERCANCIA
			mapDetDeclara.put("desUsoaplic",serie.getDesusoaplica()!=null?serie.getDesusoaplica():" ");//MODELO DE LA MERCANCIA
			mapDetDeclara.put("desOtroscarac",serie.getDesotros()!=null?serie.getDesotros():" ");//SERIE DE LA MERCANCIA
			//HAcostaR Fin - FAST SALIDA - RANCHO DE NAVE - SALIDA REINGRESO
			if ( null!=dua.getCodregimen() && dua.getCodregimen().equals("82")){
				mapDetDeclara.put("indDel", "1");
			}
			
			if (null!= serie.getDocumentoTransporte()){
				mapDetDeclara.put("numDoctransp",serie.getDocumentoTransporte().getNumdoctransporte());
				mapDetDeclara.put("numDetalle",serie.getDocumentoTransporte().getNumdetalle());
				//mapDetDeclara.put("codTipdoctransp",serie.getDocumentoTransporte().getCodtipodoctrans());
				//mapDetDeclara.put("fecEmbarque", SunatDateUtils.getDate(SunatDateUtils.getFormatDate(serie.getDocumentoTransporte().getFecembarque(), "dd/MM/yyyy")));
				//mapDetDeclara.put("codPuerEmbar", serie.getDocumentoTransporte().getCodpuerto()!=null?serie.getDocumentoTransporte().getCodpuerto():" ");
				//mapDetDeclara.put("numDoctranspmaster",serie.getDocumentoTransporte().getNumdocmaster()!=null? serie.getDocumentoTransporte().getNumdocmaster() : " " );
				//mapDetDeclara.put("fecEmborigen",serie.getDocumentoTransporte().getFecembarqueorg()!=null? SunatDateUtils.getDate(SunatDateUtils.getFormatDate(serie.getDocumentoTransporte().getFecembarqueorg(), "dd/MM/yyyy")): SunatDateUtils.getDate(SunatDateUtils.getFormatDate(SunatDateUtils.getDate("01/01/0001", "dd/MM/yyyy"), "dd/MM/yyyy")));
			}			
		}
		// Fin ptorres Fast - Regimenes Especiales 
}
