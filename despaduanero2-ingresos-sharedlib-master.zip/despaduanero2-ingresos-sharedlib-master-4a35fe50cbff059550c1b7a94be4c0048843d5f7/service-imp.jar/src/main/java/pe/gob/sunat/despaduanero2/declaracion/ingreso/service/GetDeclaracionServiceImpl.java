package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService; //PAS20165E220200032
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieAtreexp;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieImpoConsumo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMovEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtreexDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FinUbicacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorSERIEDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.PrecintoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.servicio2.avisos.util.Constantes;

public class GetDeclaracionServiceImpl extends IngresoAbstractServiceImpl implements GetDeclaracionService   {

	private static final String CATALOGO_DE_FECHA_HABILITACION_LGA = "380";
	//private CabDeclaraDAO cabDeclaraDAO;
	//private DetDeclaraDAO detDeclaraDAO;
	//private VehiCeticoDAO vehiCeticoDAO;
	//private DocuPreceDuaDAO docuPreceDuaDAO;
	//private PrecintoDAO precintoDAO;
	//private IndicadorDUADAO indicadorDUADAO;
	//private EquipamientoDAO equipamientoDAO;
	//private DocAutAsociadoDAO docAutAsociadoDAO;
	//private CabCertiOrigenDAO cabCertiOrigenDAO;
	//private VehConceptoGastoDAO vehConceptoGastoDAO;
	//private MontoGastoDAO montoGastoDAO;
	//private FormaFactuDAO formaFactuDAO;
	//private FacturaSerieDAO facturaSerieDAO;

	//private FormBProveedorDAO formBProveedorDAO;
	//private FormBMontoDAO formBMontoDAO;
	//private ParticipanteDocDAO participanteDAO;
	//private CondicionTransaDAO condicionTransaDAO;
	//private ComprobPagoDAO comprobPagoDAO;
	//private FactuSuceDAO factuSuceDAO;
	//private ItemFacturaDAO itemFacturaDAO;
	//private SeriesItemDAO seriesItemDAO;
	//private VFOBProvisionalDAO fobProvisionalDAO;
	//private FormBItemDescriDAO formBItemDescriDAO;
	//private ObservacionDAO observacionDAO;
	//private ConvenioSerieDAO convenioSerieDAO;
	/*branch ingreso 2011-009 hosorio inicio*/
	//private FinUbicacionDAO finUbicacionDAO;
	/*branch ingreso 2011-009 hosorio fin*/

	//private DetAdiImpoconsuDAO detAdiImpoconsuDAO;
	//private DetAdiAtreexDAO detAdiAtreexDAO;
	//private CabAdjImpoconsuDAO cabAdjImpoconsuDAO;

	//private FabricaDeServicios fabricaDeServicios;


	public Declaracion getDeclaracion() {

		return null;
	}


	public Declaracion getDeclaracionResumida(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen) {
		Declaracion declaracion = null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana", codigoAduana);
		params.put("numeroDeclaracion", numeroDeclaracion);
		params.put("annoPresentacion", annoPresentacion);
		params.put("codigoRegimen", codigoRegimen);

		DUA dua = getDUAResumida(params);

		if(dua!=null){
			declaracion = new Declaracion();
			declaracion.setDua(dua);
			declaracion.setCodaduana(codigoAduana);
			NumdeclRef numdeclRef=new NumdeclRef();
			numdeclRef.setNumcorre(numeroDeclaracion.toString());
			numdeclRef.setAnnprese(annoPresentacion.toString());
			declaracion.setNumdeclRef(numdeclRef);            
			declaracion.setNumeroDeclaracion( SunatNumberUtils.toLong(numeroDeclaracion));

			params.clear();
			//obtener formato B
			Elementos<DAV> listaDAV = new Elementos<DAV>();
			params.put("numeroCorrelativo", dua.getNumcorredoc());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			FormBProveedorDAO formBProveedorDAO = fabricaDeServicios.getService("formBProveedorDAO");
			listaDAV.addAll(formBProveedorDAO.findDAVByParams(params));
			declaracion.setListDAVs(listaDAV);
		}
		return declaracion;
	}

	@Override
	//RMC RIN-P47
	public Declaracion getDeclaracion(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen) {
		return getDeclaracion(codigoAduana, numeroDeclaracion, annoPresentacion, codigoRegimen, null); 
	}

	@Override
	//RMC RIN-P47 Se agrega par�metro codTipoTransaccion al m�todo
	public Declaracion getDeclaracion(String codigoAduana, Integer numeroDeclaracion, Integer annoPresentacion, String codigoRegimen, String codTipoTransaccion) {
		Declaracion declaracion = null;
		Map<String, Object> params = new HashMap<String, Object>();

		/**
		 * Seccion de DUA
		 */
		params.put("codigoAduana", codigoAduana);
		params.put("numeroDeclaracion", numeroDeclaracion);
		params.put("annoPresentacion", annoPresentacion);
		params.put("codigoRegimen", codigoRegimen);
		params.put("codTipoTransaccion", codTipoTransaccion); //RMC RIN-P47

		DUA dua = getDUA(params);

		if(dua!=null){	
			FormBProveedorDAO formBProveedorDAO = fabricaDeServicios.getService("formBProveedorDAO");
			ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
			CondicionTransaDAO condicionTransaDAO = fabricaDeServicios.getService("condicionTransaDAO");
			ComprobPagoDAO comprobPagoDAO = fabricaDeServicios.getService("comprobPagoDAO");
			FactuSuceDAO factuSuceDAO = fabricaDeServicios.getService("factuSuceDAO");
			ItemFacturaDAO itemFacturaDAO = fabricaDeServicios.getService("itemFacturaDAO");
			SeriesItemDAO seriesItemDAO = fabricaDeServicios.getService("seriesItemDAO");
			VFOBProvisionalDAO fobProvisionalDAO = fabricaDeServicios.getService("fobProvisionalDAO");
			FormBItemDescriDAO formBItemDescriDAO = fabricaDeServicios.getService("formBItemDescriDAO");
			ObservacionDAO observacionDAO = fabricaDeServicios.getService("observacionDAO");
			
			
			
			
			
			
			
			
			
			declaracion = new Declaracion();
			declaracion.setDua(dua);

			///***///
			declaracion.setCodaduana(codigoAduana);

			NumdeclRef numdeclRef=new NumdeclRef();
			numdeclRef.setNumcorre(numeroDeclaracion.toString());
			numdeclRef.setAnnprese(annoPresentacion.toString());
			declaracion.setNumdeclRef(numdeclRef);
			declaracion.setNumeroDeclaracion( SunatNumberUtils.toLong(numeroDeclaracion));


			/**
			 * Seccion de DAVs
			 */
			params.clear();

			Elementos<DAV> listaDAV = new Elementos<DAV>();
			params.put("numeroCorrelativo", dua.getNumcorredoc());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			
			listaDAV.addAll(formBProveedorDAO.findDAVByParams(params));
			declaracion.setListDAVs(listaDAV);

			//glazaror... inicio carga participantes de la dua
			Map<String, Object> parametrosParticipante = new HashMap<String, Object>();
			String tiposParticipanteConsulta = ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR + "," + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL + 
					"," + ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO + ",92";//PAse 436 - 2015 faltaba coma antes del 92

			//ejecutamos la unica consulta en participantedoc
			parametrosParticipante.put("numeroCorrelativo", dua.getNumcorredoc());
			parametrosParticipante.put("COD_TIPPARTIC_LIST", tiposParticipanteConsulta);
			List<Participante> participantesAll = participanteDAO.findParticipantesByMap(parametrosParticipante);
			//agrupamos por num_secpartic-tipoparticipante (TIPO_OPERADOR_PROVEEDOR, TIPO_OPERADOR_INTERMEDIARIO, 92) y otro grupo por numeroDocumentoIdentidad (TIPO_OPERADOR_PROVEEDOR_LOCAL)
			Map<String, Participante> participantes1Map = new HashMap<String, Participante>();
			Map<String, Participante> participantes2Map = new HashMap<String, Participante>();
			for (Participante participante : participantesAll) {
				if (ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR.equals(participante.getTipoParticipante().getCodDatacat()) ||
						ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO.equals(participante.getTipoParticipante().getCodDatacat()) ||
						"92".equals(participante.getTipoParticipante().getCodDatacat())) {
					String key = participante.getSecuenciaDeParticipantes() + "-" + participante.getTipoParticipante().getCodDatacat();
					Participante participanteFound = participantes1Map.get(key);
					if (participanteFound == null) {
						participantes1Map.put(key, participante);
					}
				} else if (ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL.equals(participante.getTipoParticipante().getCodDatacat())) {
					String key = participante.getNumeroDocumentoIdentidad() + "-" + participante.getTipoParticipante().getCodDatacat();
					Participante participanteFound = participantes2Map.get(key);
					if (participanteFound == null) {
						participantes2Map.put(key, participante);
					}
				}
			}
			//glazaror... fin carga participantes de la dua

			//glazaror... inicio carga montos por proveedor
			params.clear();
			params.put("numcorredoc", dua.getNumcorredoc());
			FormBMontoDAO formBMontoDAO = fabricaDeServicios.getService("formBMontoDAO");
			List<DatoMonto> montosAll = formBMontoDAO.findMontoByMap(params);
			//agrupamos por proveedor
			Map<Integer, Elementos<DatoMonto>> montosProveedorMap = new HashMap<Integer, Elementos<DatoMonto>>();
			for (DatoMonto datoMonto : montosAll) {
				Elementos<DatoMonto> montosByProveedor = montosProveedorMap.get(datoMonto.getNumsecprove());
				if (montosByProveedor == null) {
					montosByProveedor = new Elementos<DatoMonto>();
					montosProveedorMap.put(datoMonto.getNumsecprove(), montosByProveedor);
				}
				montosByProveedor.add(datoMonto);
			}
			//glazaror... fin carga montos por proveedor

			//glazaror... inicio carga condiciones transaccion....
			List<DatoCondTransaccion> condicionesAll = condicionTransaDAO.findCondTransaccionByMap(params);
			//agrupamos por numero de secuencia de proveedor
			Map<Integer, Elementos<DatoCondTransaccion>> condicionesTransaccionMap = new HashMap<Integer, Elementos<DatoCondTransaccion>>();
			for (DatoCondTransaccion condicionTransaccion : condicionesAll) {
				Elementos<DatoCondTransaccion> condicionesByProveedor = condicionesTransaccionMap.get(condicionTransaccion.getNumsecprove());
				if (condicionesByProveedor == null) {
					condicionesByProveedor = new Elementos<DatoCondTransaccion>();
					condicionesTransaccionMap.put(condicionTransaccion.getNumsecprove(), condicionesByProveedor);
				}
				condicionesByProveedor.add(condicionTransaccion);
			}
			//glazaror... fin carga condiciones transaccion


			//glazaror... inicio carga facturas....
			params.clear();
			params.put("numcorredoc", dua.getNumcorredoc());
			params.put("codtipocomprobante", "01");
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			List<DatoFactura> facturasAll = comprobPagoDAO.findFacturaByMap(params);
			//agrupamos por numero de secuencia de proveedor
			Map<Integer, Elementos<DatoFactura>> facturasMap = new HashMap<Integer, Elementos<DatoFactura>>();
			for (DatoFactura factura : facturasAll) {
				Elementos<DatoFactura> facturasByProveedor = facturasMap.get(factura.getNumsecprove());
				if (facturasByProveedor == null) {
					facturasByProveedor = new Elementos<DatoFactura>();
					facturasMap.put(factura.getNumsecprove(), facturasByProveedor);
				}
				facturasByProveedor.add(factura);
			}
			//glazaror... fin carga facturas....


			//glazaror... inicio carga facturas sucesivas.... clave: numero secuencia proveedor - numero factura - numero secuencia factura
			Map<String, Object> paramfact = new HashMap<String, Object>();
			paramfact.put("numcorredoc", dua.getNumcorredoc());
			/*paramfact.put("numsecuprov", dav.getNumsecuprov());
		paramfact.put("numfact", factura.getNumfactura());
		paramfact.put("numsecfact", factura.getNumsecfactu());*/
			paramfact.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			List<DatoFactSuce> facturasSucesivasAll = factuSuceDAO.findFacturaSuceByMap(paramfact);
			//agrupamos por factura: numero secuencia proveedor - numero factura - numero secuencia factura
			Map<String, Elementos<DatoFactSuce>> facturasSucesivasMap = new HashMap<String, Elementos<DatoFactSuce>>();
			for (DatoFactSuce facturaSucesiva : facturasSucesivasAll) {
				//glazaror... no se requiere buscar por numero factura (numFact)
				//String key = facturaSucesiva.getNumsecprove() + "-" + facturaSucesiva.getNumfact() + "-" + facturaSucesiva.getNumsecfact();
				String key = facturaSucesiva.getNumsecprove() + "-" + facturaSucesiva.getNumsecfact();
				Elementos<DatoFactSuce> facturasSucesivasByFactura = facturasSucesivasMap.get(key);
				if (facturasSucesivasByFactura == null) {
					facturasSucesivasByFactura = new Elementos<DatoFactSuce>();
					facturasSucesivasMap.put(key, facturasSucesivasByFactura);
				}
				facturasSucesivasByFactura.add(facturaSucesiva);
			}
			//glazaror... fin carga facturas sucesivas....

			//glazaror... inicio carga items factura....
			List<DatoItem> itemsFacturaAll = itemFacturaDAO.findItemByMap(paramfact);
			//agrupamos por factura: numero secuencia proveedor - numero factura - numero secuencia factura
			Map<String, Elementos<DatoItem>> itemsFacturaMap = new HashMap<String, Elementos<DatoItem>>();
			for (DatoItem itemFactura : itemsFacturaAll) {
				//glazaror... no se requiere buscar por numero factura (numFact)
				//String key = itemFactura.getNumsecprove() + "-" + itemFactura.getNumfact() + "-" + itemFactura.getNumsecfact();
				String key = itemFactura.getNumsecprove() + "-" + itemFactura.getNumsecfact();
				Elementos<DatoItem> itemsByFactura = itemsFacturaMap.get(key);
				if (itemsByFactura == null) {
					itemsByFactura = new Elementos<DatoItem>();
					itemsFacturaMap.put(key, itemsByFactura);
				}
				itemsByFactura.add(itemFactura);
			}
			//glazaror... fin carga items factura....

			//glazaror... inicio carga series items por item factura
			List<DatoSerieItem> seriesItemAll = seriesItemDAO.findSerieItemByMap(paramfact);
			//agrupamos por item factura: numero secuencia proveedor - numero factura - numero secuencia factura - numero secuencia item
			Map<String, Elementos<DatoSerieItem>> seriesItemMap = new HashMap<String, Elementos<DatoSerieItem>>();
			for (DatoSerieItem datoSerie : seriesItemAll) {
				//glazaror... no se requiere buscar por numero factura (numFact)
				//String key = datoSerie.getNumsecprove() + "-" + datoSerie.getNumfact() + "-" + datoSerie.getNumsecfact() + "-" + datoSerie.getNumsecitem();
				String key = datoSerie.getNumsecprove() + "-" + datoSerie.getNumsecfact() + "-" + datoSerie.getNumsecitem();
				Elementos<DatoSerieItem> seriesItemByItem = seriesItemMap.get(key);
				if (seriesItemByItem == null) {
					seriesItemByItem = new Elementos<DatoSerieItem>();
					seriesItemMap.put(key, seriesItemByItem);
				}
				seriesItemByItem.add(datoSerie);
			}
			//glazaror... fin carga series items por item factura


			//glazaror... inicio carga fob provisional...
			//Elementos<DatoMontoProv> montosProv = new Elementos<DatoMontoProv>();
			List<DatoMontoProv> montosFobAll = fobProvisionalDAO.findMontoProvByMap(paramfact);
			//agrupamos por item factura: numero secuencia proveedor - numero factura - numero secuencia factura - numero secuencia item
			Map<String, Elementos<DatoMontoProv>> montosFobMap = new HashMap<String, Elementos<DatoMontoProv>>();
			for (DatoMontoProv montoFob : montosFobAll) {
				//glazaror... no se requiere buscar por numero factura (numFact)
				//String key = montoFob.getNumsecprove() + "-" + montoFob.getNumfact() + "-" + montoFob.getNumsecfact() + "-" + montoFob.getNumsecitem();
				String key = montoFob.getNumsecprove() + "-" + montoFob.getNumsecfact() + "-" + montoFob.getNumsecitem();
				Elementos<DatoMontoProv> montosFobByItem = montosFobMap.get(key);
				if (montosFobByItem == null) {
					montosFobByItem = new Elementos<DatoMontoProv>();
					montosFobMap.put(key, montosFobByItem);
				}
				montosFobByItem.add(montoFob);
			}
			//glazaror... fin carga fob provisional...


			//glazaror... inicio carga descripciones minimas
			List<DatoDescrMinima> descripcionesMinimasAll = formBItemDescriDAO.findDescrMinimaByMap(paramfact);
			//agrupamos por item factura: numero secuencia proveedor - numero factura - numero secuencia factura - numero secuencia item
			Map<String, Elementos<DatoDescrMinima>> descripcionesMinimasMap = new HashMap<String, Elementos<DatoDescrMinima>>();
			for (DatoDescrMinima descripcionMinima : descripcionesMinimasAll) {
				//glazaror... no se requiere buscar por numero factura (numFact)
				//String key = descripcionMinima.getNumsecprove() + "-" + descripcionMinima.getNumfact() + "-" + descripcionMinima.getNumsecfact() + "-" + descripcionMinima.getNumsecitem();
				String key = descripcionMinima.getNumsecprove() + "-" + descripcionMinima.getNumsecfact() + "-" + descripcionMinima.getNumsecitem();
				Elementos<DatoDescrMinima> descripcionesMinimasByItem = descripcionesMinimasMap.get(key);
				if (descripcionesMinimasByItem == null) {
					descripcionesMinimasByItem = new Elementos<DatoDescrMinima>();
					descripcionesMinimasMap.put(key, descripcionesMinimasByItem);
				}
				descripcionesMinimasByItem.add(descripcionMinima);
			}
			//glazaror... fin carga descripciones minimas


			//glazaror... inicio carga observaciones
			paramfact.put("numsecitemDistinct", 0);
			List<Observacion> observacionesAll = observacionDAO.findObservcionByMap(paramfact);
			//agrupamos por item factura: numero secuencia proveedor - numero factura - numero secuencia factura - numero secuencia item
			Map<Integer, Elementos<Observacion>> observacionesMap = new HashMap<Integer, Elementos<Observacion>>();
			for (Observacion observacion : observacionesAll) {
				Elementos<Observacion> observacionesByItem = observacionesMap.get(observacion.getNumsecitem());
				if (observacionesByItem == null) {
					observacionesByItem = new Elementos<Observacion>();
					observacionesMap.put(observacion.getNumsecitem(), observacionesByItem);
				}
				observacionesByItem.add(observacion);
			}
			//glazaror... fin carga observaciones


			for (DAV dav : declaracion.getListDAVs()) {


				//glazaror... ya no es necesario ejecutar este query para obtener el IND_FLAG... el mismo query formBProveedorDAO.findDAVByParams(params) lo obtiene
				// Parametros 
				/*Map<String,Object> paramDavPr=new HashMap<String, Object>();
			paramDavPr.put("NUM_CORREDOC", dua.getNumcorredoc());
			paramDavPr.put("NUM_SECPROVE", dav.getNumsecuprov());
			List<Map<String,Object>> lstDav = this.formBProveedorDAO.select(paramDavPr);
			Map<String,Object> mapDav=lstDav.get(0);
			//pase 105 mordonezl
			//seteamos el flag del proveedor de la DAV
			if(mapDav.get("IND_FLAG")!=null){
			dav.setFlag(mapDav.get("IND_FLAG").toString());
			}*/

				//glazaror... evitamos query adicional sobre FORMB_MONTO
				// Parametros de montos
				//params.put("numcorredoc", dav.getNumcorredoc());
				//params.put("numsecuprov", dav.getNumsecuprov());

				//glazaror... obtenemos los montos del proveedor del mapa cargado anteriormente
				//Elementos<DatoMonto> montosDav = new Elementos<DatoMonto>();
				Elementos<DatoMonto> montosDav = montosProveedorMap.get(dav.getNumsecuprov());
				if (montosDav == null) {
					montosDav = new Elementos<DatoMonto>();
				}
				dav.setListMontos(montosDav);

				params.clear();

				//params.put("numcorredoc", dav.getNumcorredoc());
				//params.put("numsecuprov", dav.getNumsecuprov());


				// Parametros de Proveedores
				//Map<String, Object> paramProv = new HashMap<String, Object>( params );
				//glazaror... evitamos consultar nuevamente en base datos
				//paramProv.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR);
				//paramProv.put("numsecpartic", mapDav.get("NUM_CODSECPROVE"));
				//Elementos<Participante> proveedores = new Elementos<Participante>();
				//proveedores.addAll(participanteDAO.findParticipantesByMap(paramProv));
				/*if(proveedores != null && proveedores.size() > 0)
				dav.setProveedor(proveedores.get(0));*/

				//glazaror...buscamos del map 
				//Participante proveedor =  participantes1Map.get(dav.getNumcodsecprove() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR);
				//glazaror... en getNumcodsecprove han metido logica... se reemplaza la busqueda por la nueva propiedad secuenciaParticipanteProveedor
				Participante proveedor =  participantes1Map.get(dav.getSecuenciaParticipanteProveedor() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR);
				if (proveedor != null) {
					dav.setProveedor(proveedor);
				}

				//glazaror... evitamos consultar nuevamente en base datos
				// Parametros de Proveedores Locales
				/*Map<String, Object> paramProveedorLocal = new HashMap<String, Object>( params );
			paramProveedorLocal.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL);
			/*branch ingreso 2011-009 hosorio inicio 25/07/2011*/
				//paramProveedorLocal.put("numsecpartic", mapDav.get("NUM_CODSECPROVE"));
				//paramProveedorLocal.put("numeroDocumentoIdentidad", mapDav.get("COD_DOCIDENTPROVLOC"));
				//paramProveedorLocal.put("numeroCorrelativo", dav.getNumcorredoc());*/
				/*branch ingreso 2011-009 hosorio inicio 25/07/2011*/
				//Elementos<Participante> proveedoresLocales = new Elementos<Participante>();
				//proveedoresLocales.addAll(participanteDAO.findParticipantesByMap(paramProveedorLocal));
				/*if(proveedoresLocales != null && proveedoresLocales.size() > 0)
				dav.setProveedorLocal(proveedoresLocales.get(0));*/

				//glazaror...buscamos del map 
				//Participante proveedorLocal =  participantes2Map.get(dav.getCoddocidentprovloc() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL);
				//glazaror... en getCoddocidentprovloc han metido logica... se reemplaza la busqueda por la nueva propiedad numeroDocumentoIdentidadProveedorLocal
				Participante proveedorLocal =  participantes2Map.get(dav.getNumeroDocumentoIdentidadProveedorLocal() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL);
				if (proveedorLocal != null) {
					dav.setProveedorLocal(proveedorLocal);
				}

				params.clear();			

				//glazaror... evitamos consultar nuevamente en base datos
				// Parametros de Intermediarios
				/*Map<String, Object> paramIntermediario = new HashMap<String, Object>( params );
			paramIntermediario.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO);
			paramIntermediario.put("numeroCorrelativo", dav.getNumcorredoc());
			paramIntermediario.put("numsecpartic", mapDav.get("NUM_SECINTERMEDIARIO"));
			Elementos<Participante> intermediarios = new Elementos<Participante>();
			intermediarios.addAll(participanteDAO.findParticipantesByMap(paramIntermediario)); 
			if(intermediarios != null && intermediarios.size() > 0)
				dav.setIntermediario(intermediarios.get(0));*/

				//glazaror...buscamos del map
				//glazaror... en getNumsecintermediario han metido logica... se reemplaza la busqueda por la nueva propiedad secuenciaParticipanteIntermediario
				//Participante intermediario =  participantes1Map.get(dav.getNumsecintermediario() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO);
				Participante intermediario =  participantes1Map.get(dav.getSecuenciaParticipanteIntermediario() + "-" + ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO);
				if (proveedorLocal != null) {
					dav.setIntermediario(intermediario);
				}


				//glazaror... evitamos consultar nuevamente en base datos
				// Parametros de Declarantes
				/*Map<String, Object> paramDeclarante = new HashMap<String, Object>( params );
			/*branch ingreso 2011-009 hosorio inicio 26/07/2011*/
				//paramDeclarante.put("numeroCorrelativo", dav.getNumcorredoc());
				//paramDeclarante.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_PERSON_DECLA_FORMATO_B);
				//paramDeclarante.put("codTipoParticipante", "92");
				/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
				//paramDeclarante.put("numsecpartic", mapDav.get("NUM_SECDECLARANTE"));
				//Elementos<Participante> declarantes = new Elementos<Participante>();
				/*branch ingreso 2011-009 hosorio inicio 26/07/2011*/
				//declarantes.addAll(participanteDAO.findParticipantesByMap(paramProv));
				//declarantes.addAll(participanteDAO.findParticipantesByMap(paramDeclarante));
				/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
				/*if(declarantes != null && declarantes.size() > 0)
				dav.setPersonaDecl(declarantes.get(0));*/

				params.clear();

				//glazaror...buscamos del map 
				//glazaror... en getNumsecdeclarante han metido logica... se reemplaza la busqueda por la nueva propiedad secuenciaParticipanteDeclarante
				//Participante personaDeclarante =  participantes1Map.get(dav.getNumsecdeclarante() + "-92");
				Participante personaDeclarante =  participantes1Map.get(dav.getSecuenciaParticipanteDeclarante() + "-92");
				if (personaDeclarante != null) {
					dav.setPersonaDecl(personaDeclarante);
				}



				// Parametros de Condiciones de transaccion
				//params.put("numcorredoc", dav.getNumcorredoc());
				//params.put("numsecuprov", dav.getNumsecuprov());

				//glazaror... evitamos query adicionar por cada proveedor
				/*Elementos<DatoCondTransaccion> condiciones = new Elementos<DatoCondTransaccion>();
			condiciones.addAll(condicionTransaDAO.findCondTransaccionByMap(params));*/

				//glazaror... y obtenemos las condiciones del mapa cargado al inicio
				Elementos<DatoCondTransaccion> condiciones = condicionesTransaccionMap.get(dav.getNumsecuprov());
				if (condiciones == null) {
					condiciones = new Elementos<DatoCondTransaccion>();
				}
				dav.setListCondTransacciones(condiciones);

				params.clear();

				//glazaror... evitamos ejecutar query adicional sobre COMPROB_PAGO
				// Parametros de Facturas
				/*params.put("numcorredoc", dav.getNumcorredoc());
			params.put("numsecuprov", dav.getNumsecuprov());
			params.put("codtipocomprobante", "01");
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			Elementos<DatoFactura> facturas = new Elementos<DatoFactura>();
			facturas.addAll(comprobPagoDAO.findFacturaByMap(params));
			dav.setListFacturas(facturas);*/

				//glazaror... obtenemos facturas del mapa cargado anteriormente
				Elementos<DatoFactura> facturas = facturasMap.get(dav.getNumsecuprov());
				if (facturas == null) {
					facturas = new Elementos<DatoFactura>();
				}
				dav.setListFacturas(facturas);


				for (DatoFactura factura : dav.getListFacturas()) {

					//glazaror... evitamos query adicional sobre tabla FACTUSUCE 
					/*Map<String, Object> paramfact = new HashMap<String, Object>();
				paramfact.put("numcorredoc", dav.getNumcorredoc());
				paramfact.put("numsecuprov", dav.getNumsecuprov());
				//paramfact.put("codmoneda", Constants.CODIGO_MONEDA_DOLAR);
				paramfact.put("numfact", factura.getNumfactura());
				paramfact.put("numsecfact", factura.getNumsecfactu());
				paramfact.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

				Elementos<DatoFactSuce> factSucesivas = new Elementos<DatoFactSuce>();
				factSucesivas.addAll(factuSuceDAO.findFacturaSuceByMap(paramfact));*/

					//glazaror... obtenemos las facturas sucesivas del mapa cargado anteriormente
					//glazaror... no se requiere buscar por numero de factura (numFact)
					//String key = factura.getNumsecprove() + "-" + factura.getNumfactura() + "-" + factura.getNumsecfactu();
					String key = factura.getNumsecprove() + "-" + factura.getNumsecfactu();
					Elementos<DatoFactSuce> factSucesivas = facturasSucesivasMap.get(key);
					if (factSucesivas == null) {
						factSucesivas = new Elementos<DatoFactSuce>();
					}
					factura.setListFactSucesivas(factSucesivas);

					//glazaror... evitamos ejecutar query adicional para obtener items por cada factura
					/*Elementos<DatoItem> items = new Elementos<DatoItem>();
				items.addAll(itemFacturaDAO.findItemByMap(paramfact));*/

					//glazaror... obtenemos los items del mapa cargado anteriormente
					Elementos<DatoItem> items = itemsFacturaMap.get(key);
					if (items == null) {
						items = new Elementos<DatoItem>();
					}
					factura.setListItems(items);

					for (DatoItem item : factura.getListItems()) {

						//glazaror... evitamos ejecutar query adicional para obtener series item por cada item factura
						/*paramfact.put("numsecitem", item.getNumsecitem());

					Elementos<DatoSerieItem> serieItems = new Elementos<DatoSerieItem>();
					serieItems.addAll((seriesItemDAO.findSerieItemByMap(paramfact)));
					item.setListSerieItems(serieItems);*/

						//glazaror... obtenemos los series item del mapa cargado anteriormente
						//glazaror... no se requiere buscar por numero de factura (numFact)
						//key = item.getNumsecprove() + "-" + item.getNumfact() + "-" + item.getNumsecfact() + "-" + item.getNumsecitem();
						key = item.getNumsecprove() + "-" + item.getNumsecfact() + "-" + item.getNumsecitem();
						Elementos<DatoSerieItem> serieItems = seriesItemMap.get(key);
						if (serieItems == null) {
							serieItems = new Elementos<DatoSerieItem>();
						}
						item.setListSerieItems(serieItems);


						//glazaror... evitamos ejecutar query adicional para obtener montos prov por cada item factura
						/*Elementos<DatoMontoProv> montosProv = new Elementos<DatoMontoProv>();
					montosProv.addAll(fobProvisionalDAO.findMontoProvByMap(paramfact));*/

						//glazaror... obtenemos los montos del mapa cargado anteriormente
						Elementos<DatoMontoProv> montosProv = montosFobMap.get(key);
						if (montosProv == null) {
							montosProv = new Elementos<DatoMontoProv>();
						}

						if( montosProv != null && montosProv.size() > 0 )
							item.setMontoProv(montosProv.get(0));


						//glazaror... evitamos ejecutar query adicional para obtener descripciones minimas por cada item factura
						/*Elementos<DatoDescrMinima> descripcionesMin = new Elementos<DatoDescrMinima>();
					descripcionesMin.addAll(formBItemDescriDAO.findDescrMinimaByMap(paramfact));
					item.setListDecrMinima(descripcionesMin);*/

						//glazaror... obtenemos las descripciones minimas del mapa cargado anteriomente
						Elementos<DatoDescrMinima> descripcionesMin = descripcionesMinimasMap.get(key);
						if (descripcionesMin == null) {
							descripcionesMin = new Elementos<DatoDescrMinima>();
						}
						item.setListDecrMinima(descripcionesMin);


						//glazaror... evitamos ejecutar query adicional para obtener observaciones por cada item factura
						/*Elementos<Observacion> observaciones = new Elementos<Observacion>();
					observaciones.addAll(observacionDAO.findObservcionByMap(paramfact));*/

						//glazaror...
						Elementos<Observacion> observaciones = observacionesMap.get(item.getNumsecitem());
						if (observaciones == null) {
							observaciones = new Elementos<Observacion>();
						}
						item.setListObservaciones(observaciones);
					}
				}
			}
		}
		return declaracion;
	}
	/* PAS20145E220000399 INICIO GGRANADOS */
	public DUA getDUAResumida(Map<String, Object> params) {
		ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("convenioSerieDAO");
		
		
		
		DUA dua = cabDeclaraDAO.findDUAByMap(params);
		if (dua == null) {
			return null;
		}
		// Obtener datos del declarante
		params.put("numeroCorrelativo", dua.getNumcorredoc());
		params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		List<Participante> lstDeclarante = participanteDAO.findParticipantesByMap(params);
		if (!CollectionUtils.isEmpty(lstDeclarante)) {
			Participante declarante = lstDeclarante.get(0); // debe haber uno solo
			dua.setDeclarante(declarante);
		}
		params.clear();

		// OBTENER EL AGENTE
		params.put("numeroCorrelativo", dua.getNumcorredoc());
		params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA);

		List<Participante> lstAgentes= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstAgentes)){
			Participante agente=lstAgentes.get(0); // debe haber uno solo
			dua.setNumdocumento(agente.getNumeroDocumentoIdentidad());
			dua.setCodtipooper(agente.getTipoDocumentoIdentidad().getCodDatacat());
			// INICIO RIN15
			dua.setAgenteAduanas(agente);
			// FIN RIN15
		}		
		params.clear();		

		params.put("numCorreDoc", dua.getNumcorredoc());
		params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
		Elementos<DatoSerie> series = new Elementos<DatoSerie>();
		series.addAll(detDeclaraDAO.findSerie(params));
		dua.setListSeries(series);
		/* Codigo Liberatorio FormatoB */
		Map<String, Object> paramConvSerie = new HashMap<String, Object>();
		paramConvSerie.put("NUM_CORREDOC", dua.getNumcorredoc());
		paramConvSerie.put("COD_TIPCONVENIO", "C");
		paramConvSerie.put("IND_DEL", "0");
		List<Map<String, Object>> lstConv = convenioSerieDAO.select(paramConvSerie);
		for (DatoSerie serie : dua.getListSeries()) {
			//			Integer codliberatorio = null;
			//			Map<String, Object> mapConv = null;
			// Map<String,Object> paramConvSerie=new HashMap<String, Object>();
			// paramConvSerie.put("NUM_CORREDOC", dua.getNumcorredoc());
			// paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());
			// paramConvSerie.put("COD_TIPCONVENIO", "C");
			//
			// List<Map<String,Object>> lstConv= convenioSerieDAO.select(paramConvSerie);
			//			if (!CollectionUtils.isEmpty(lstConv)) {				
			//				mapConv = lstConv.get(0);
			//				codliberatorio = Integer.valueOf(((String) mapConv.get("COD_CONVENIO")).trim());
			//			}
			//			serie.setCodliberatorio(codliberatorio);

			////			Arrays.binarySearch(lstConv, serie.getNumserie());
			Map<String, Object> mapSearch = new HashMap<String, Object>();
			mapSearch.put("NUM_SECSERIE", serie.getNumserie());
			Collections.binarySearch(lstConv, mapSearch, new Comparator<Map<String, Object>>() {

				@Override
				public int compare(Map<String, Object> o1, Map<String, Object> o2) {
					return o1.get("NUM_SECSERIE").toString().compareTo(o2.get("NUM_SECSERIE").toString());
				}

			});
			//PAS20155E220000094 RBEGAZO INICIO
			for (Map<String, Object> map : emptyIfNull(lstConv)) {
				if(serie.getNumserie().compareTo(SunatNumberUtils.toInteger(map.get("NUM_SECSERIE"))) == 0){
					serie.setCodliberatorio(SunatNumberUtils.toInteger(map.get("COD_CONVENIO")));
					break;
				}
			}
			//PAS20155E220000094 RBEGAZO FIN


		}
		return dua;
	}

	public static <T> Iterable<T> emptyIfNull(Iterable<T> iterable) {
		return iterable == null ? Collections.<T>emptyList() : iterable;
	}
	/* PAS20145E220000399 FIN GGRANADOS */


	//lmvr-Complemento de la dua parte II
	public int countDeclaraciones(Map<String, Object> params){
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		Integer count1 = 0;
		Integer count2 = 0;
		Integer count3 = 0;
		params.put("COD_REGIMEN_IN", "'10'");
		count1 = cabDeclaraDAO.countDeclaraciones(params);
		params.put("COD_REGIMEN_IN", "'20','21'");
		count2 = cabDeclaraDAO.countDeclaracionesAdmisiones(params);
		params.put("COD_TIPDILIGENCIA_IN", "'02','03'");
		params.put("COD_REGIMEN_IN", "'70'");
		Integer count =  count1 + count2 + count3;
		return count;
	}


	//inicio numeracion DSEER
	public DUA getDUAEER(Map<String, Object> params) {
		IndicadorSERIEDAO indicadorSERIEDAO = fabricaDeServicios.getService("indicadorSERIEDAO");
		DUA duaEER = this.getDUA(params);
		if(duaEER == null)
			return duaEER;
		//Seteo del participante Consignatario
		duaEER.setConsignatario(duaEER.getDeclarante());

		//Seteo del tipo de indicador en el campo codigoIndicador
		for(DatoIndicadores indicadorDUA: duaEER.getListIndicadores()) {
			indicadorDUA.setCodigoIndicador(indicadorDUA.getCodtipoindica());
		}
		params.clear();
		params.put("num_corredoc", duaEER.getNumcorredoc());
		params.put("inddel", Constantes.COD_ESTADO_ACTIVO);
		
		Elementos<DatoIndicadores> indicadoresSerie = new Elementos<DatoIndicadores>();
		indicadoresSerie.addAll(indicadorSERIEDAO.findIndicadoresSerieByMap(params));
		
		//Traer el indicador serie
		for(DatoSerie serie: duaEER.getListSeries()) {
			Elementos<DatoIndicadores> indicadorSerieLst = new Elementos<DatoIndicadores>();
			for(DatoIndicadores indicadorSerie:indicadoresSerie) {
				if(indicadorSerie.getNumeroSerie().equals(serie.getNumserie())) {
					indicadorSerieLst.add(indicadorSerie);
				}
			}
			serie.setListIndicadores(indicadorSerieLst);
		}
		
		return duaEER;
	}
	//fin numeracion DSEER

	public DUA getDUA(Map<String, Object> params)
	{
		ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
		ObservacionDAO observacionDAO = fabricaDeServicios.getService("observacionDAO");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		VehiCeticoDAO vehiCeticoDAO = fabricaDeServicios.getService("vehiCeticoDAO");
		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		EquipamientoDAO equipamientoDAO = fabricaDeServicios.getService("manifiesto.equipamientoDAO");
		DocAutAsociadoDAO docAutAsociadoDAO = fabricaDeServicios.getService("docAutAsociadoDAO");
		CabCertiOrigenDAO cabCertiOrigenDAO = fabricaDeServicios.getService("cabCertiOrigenDAO");
		MontoGastoDAO montoGastoDAO = fabricaDeServicios.getService("montoGastoDAO");
		FormaFactuDAO formaFactuDAO = fabricaDeServicios.getService("formaFactuDAO");
		FacturaSerieDAO facturaSerieDAO = fabricaDeServicios.getService("facturaSerieDAO");
		FinUbicacionDAO finUbicacionDAO = fabricaDeServicios.getService("finUbicacionDAO");
		CabAdjImpoconsuDAO cabAdjImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");

		DUA dua = cabDeclaraDAO.findDUAByMap(params);

		if( dua == null )
			return null; 

		//glazaror... inicio mejoras
		//cantidad de querys a ejecutar: 1:PARTICIPANTE_DOC, 2:FIN_UBICACION (SI ES QUE REGIMEN ES 20), 3:OBSERVACION, 4:CAB_ADI_IMPOCONSU (PUEDE SER REEMPLAZADO POR UN SUBQUERY EN CAB_DECLARA),
		//5:DOCAUT_ASOCIADO (1), 6:DOCAUT_ASOCIADO (2), 7:DOCAUT_ASOCIADO (3), 8:INDICADOR_DUA(PUEDE SER REEMPLAZADO POR UN SUBQUERY EN CAB_DECLARA)
		//9:CAB_CERTIORIGEN, 10:DET_DECLARA (1), 11:DET_DECLARA (2-documentos transporte), 12:FORMA_FACTU, 13:DOCUPRECE_DUA(OPTIMIZADO), 14:CONVENIO_SERIE(SE REEMPLAZO POR SUBQUERYS EN DET_DECLARA),
		//15:FACTURA_SERIE (POR OPTIMIZAR), 16:VEHICULO (POR OPTIMIZAR), 17:MONTOGASTO (POR OPTIMIZAR), 18:DET_ADIIMPOCONSU (POR OPTIMIZAR), 19:DET_ADI_ATREEX (POR OPTIMIZAR)
		//1. Ejecutamos un solo query para obtener participantes de la dua:
		//1.1 TIPO_OPERADOR_AGENTE_DE_ADUANA
		//1.2 TIPO_OPERADOR_DUENO_CONSIGNATARIO
		//1.3 TIPO_OPERADOR_ANEXO_UBICACION
		//1.4 TIPO_OPERADOR_DEPOSITO_ADUANERO
		//1.5 TIPO_OPERADOR_TRANSPORTISTA o TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA

		Map<String, Object> parametrosParticipante = new HashMap<String, Object>();
		String tiposParticipanteConsulta = ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA + "," + ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO + 
				"," + ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION;

		//si es que regimen es 70 entonces tambien consultamos operador tipo deposito aduanero
		if("70".equals(dua.getCodregimen())){
			tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO;
		}
		
		if(ConstantesDataCatalogo.REGIMEN_EER.equals(dua.getCodregimen())) {
			tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR;
		}

		if (dua.getManifiesto() != null) {
			/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
			Date fechaReferencia = dua.getFecNumeracion()!=null?dua.getFecNumeracion():new Date();
			List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
			/***fin PAS20181U220200049***/
			
			String viaTransporte=dua.getManifiesto().getCodmodtransp();
			if (ConstantesDataCatalogo.VIA_TRANSPORTE_MARITIMA.equals(viaTransporte)) {
				tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
			}else if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte)){
				tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			} 
			/*else if (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte) || ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(viaTransporte)){ //INC 2017-115387 
				tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			}*/
			/***Inicio PAS20181U220200049***/
			if(!ResponseListManager.responseListHasErrors(listaOMA)){
				if(ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE.equals(viaTransporte)){ //cat 227
					tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
				}				
			}else{
				if(ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(viaTransporte)){ //INC 2017-115387 //cat 10 
					tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
				}
			}/***fin PAS20181U220200049***/
			//pase 64 mol
			if(ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE.equals(viaTransporte)){ //INC 2017-115387 //cat 10 
				tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
				tiposParticipanteConsulta += "," + ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
			}
			// fin mol
		}
		//ejecutamos la unica consulta en participantedoc
		parametrosParticipante.put("numeroCorrelativo", dua.getNumcorredoc());
		parametrosParticipante.put("COD_TIPPARTIC_LIST", tiposParticipanteConsulta);
		List<Participante> participantesAll = participanteDAO.findParticipantesByMap(parametrosParticipante);

		//generamos las listas de participantes requeridas mas abajo... con los mismos nombres de variable
		//List<Participante> lstAgentes, lstDeclarante, lstAnexoUbi, lstPartDepos, lstEmpTransporte
		List<Participante> lstAgentes = new ArrayList<Participante>();
		List<Participante> lstDeclarante = new ArrayList<Participante>();
		List<Participante> lstAnexoUbi = new ArrayList<Participante>();
		List<Participante> lstPartDepos = new ArrayList<Participante>();
		List<Participante> lstEmpTransporte = new ArrayList<Participante>();
		List<Participante> lstRemitente = new ArrayList<Participante>();		

		for (Participante participante : participantesAll) {
			if (ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstAgentes.add(participante);
			} else if (ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstDeclarante.add(participante);
			} else if (ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstAnexoUbi.add(participante);
			} else if (ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstPartDepos.add(participante);
			} else if (ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA.equals(participante.getTipoParticipante().getCodDatacat()) ||
					ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstEmpTransporte.add(participante);
			}else if(ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR.equals(participante.getTipoParticipante().getCodDatacat())) {
				lstRemitente.add(participante);
			}
		}

		//glazaror... fin mejoras


		// OBTENER EL AGENTE
		//params.put("numeroCorrelativo", dua.getNumcorredoc());
		//params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA);

		//glazar
		//List<Participante> lstAgentes= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstAgentes)){
			Participante agente=lstAgentes.get(0); // debe haber uno solo
			dua.setNumdocumento(agente.getNumeroDocumentoIdentidad());
			dua.setCodtipooper(agente.getTipoDocumentoIdentidad().getCodDatacat());
			// INICIO RIN15
			dua.setAgenteAduanas(agente);
			// FIN RIN15
		}

		//RMC RIN-P47
		String codTipoTransaccion = params.get("codTipoTransaccion") != null ? (String) params.get("codTipoTransaccion") : "";

		params.clear();


		// OBTENER AL DECLARANTE
		//params.put("numeroCorrelativo", dua.getNumcorredoc());
		//params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);

		//List<Participante> lstDeclarante= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstDeclarante)){
			Participante declarante=lstDeclarante.get(0); // debe haber uno solo
			dua.setDeclarante(declarante);
		}
		
		//inicio Numeracion de la DSEER
		if(!CollectionUtils.isEmpty(lstRemitente)){
			Participante remitente=lstRemitente.get(0); // debe haber uno solo
			dua.setRemitente(remitente);;
		}
		
		
		//fin Numeracion de la DSEER
		params.clear();		


		// OBTENER AL RUC ANEXO UBICACION
		//params.put("numeroCorrelativo", dua.getNumcorredoc());
		//params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION);

		//List<Participante> lstAnexoUbi= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstAnexoUbi)){
			Participante rucAnexoUbicacion=lstAnexoUbi.get(0); // debe haber uno solo
			dua.setRucAnexoUbicacion(rucAnexoUbicacion);
		}

		/*branch ingreso 2011-009 hosorio inicio*/
		if("20".equals(dua.getCodregimen())){
			Map<String,Object> paramFinUbi=new HashMap<String, Object>();
			paramFinUbi.put("NUM_CORREDOC", dua.getNumcorredoc());
			List<Map<String,Object>> lstFinUbi= finUbicacionDAO.select(paramFinUbi);
			if(lstFinUbi!=null && lstFinUbi.size()>0){
				// si no exite ruc de fin d ubicacion , no existe participante ruc anexo
				if(SunatStringUtils.isEmptyTrim((String)lstFinUbi.get(0).get("NUM_DOC_LOCMERC"))){
					dua.setRucAnexoUbicacion(null);
				}
			}
		}
		if("70".equals(dua.getCodregimen())){
			/*Map<String,Object> paramPartDepo=new HashMap<String, Object>();
			paramPartDepo.put("numeroCorrelativo", dua.getNumcorredoc());
			paramPartDepo.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO);*/
			//List<Participante> lstPartDepos= participanteDAO.findParticipantesByMap(paramPartDepo);
			if(!CollectionUtils.isEmpty(lstPartDepos)){
				Participante pDepo=lstPartDepos.get(0);
				if(pDepo!=null)
					dua.setNumrucdeposito(pDepo.getNumeroDocumentoIdentidad());
			}
		}



		/*branch ingreso 2011-009 hosorio fin*/

		params.clear();		


		params.put("numcorredoc", dua.getNumcorredoc());
		params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
		// OBTENIENDO OBSERVACIONES
		Elementos<Observacion> observaciones_dua = new Elementos<Observacion>();
		observaciones_dua.addAll(observacionDAO.findObservcionByMap(params));
		if (!CollectionUtils.isEmpty(observaciones_dua)){
			Iterator<Observacion> it = observaciones_dua.iterator();
			while(it.hasNext()){
				Observacion mObsDua = (Observacion)it.next();
				if (mObsDua.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_ITEMSFORMB)){
					it.remove();
				}				
			}
		}
		dua.setListObservaciones(observaciones_dua);

		//glazaror... este dato debe consultarse en el mismo query usado para obtener la declaracion CAB_DECLARA
		DatoPagoDecla pagoElectronico = new DatoPagoDecla();
		pagoElectronico = cabAdjImpoconsuDAO.selectByPK(params);
		dua.setPagoElectronico(pagoElectronico);


		/*obteniendo doc de soporte tabla doc asociado*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();


		listOtrosDocSoporte.addAll(docAutAsociadoDAO.findDocSoporteByParameterMap(params) );
		dua.setListOtrosDocSoporte(listOtrosDocSoporte);


		/*r2bz obteniendo doc de soporte tabla doc asociado pero de CO*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporteCO=new Elementos<DatoOtroDocSoporte>();


		listOtrosDocSoporteCO.addAll(docAutAsociadoDAO.findDocSoporteCertiOrigenByParameterMap(params) );
		dua.setListOtrosDocSoporteCO(listOtrosDocSoporteCO);


		/*obteniendo doc autorizante*/
		Elementos<DatoDocAutorizante> listDocAutorizantes=new Elementos<DatoDocAutorizante>();
		listDocAutorizantes.addAll(docAutAsociadoDAO.findDocAutorizanteByParameterMap(params) );
		dua.setListDocAutorizantes(listDocAutorizantes);		


		Elementos<DatoIndicadores> indicadores = new Elementos<DatoIndicadores>();
		//r2bz solo obtener indicadores de transmision 	PAS20110001128	
		params.put("codtiporegistro", "T");
		params.put("indactivo", Constants.INDICADOR_ACTIVO);

		//RMC RIN-P47 Se retira indicador 16 para la regularizaci�n 
		if (codTipoTransaccion.trim().equals(ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA)) {
			params.put("listaExcluyeTipoIndica", new String[] {"16"});
		}
		
		//PAS20171U220200005 - mtorralba 20170808 - Inicio - Incluye en indicador 33 y 34 el valor almacenado en CAB_ADI_IMPOCONSU.NUM_TOTALENVIOS
		Elementos<DatoIndicadores> nuevosIndicadores = new Elementos<DatoIndicadores>();
		indicadores.addAll(indicadorDUADAO.findIndicadoresByMap(params));
		//Se elimina indicador  20 no deberia estar grabado como tipo "T" Inicio - PAS20165E220200021
		if(!indicadores.isEmpty()){
			for(DatoIndicadores indicador:indicadores){
				String codIndicador = indicador.getCodtipoindica();
				if( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO ) || codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) ) {
					CabAdjImpoconsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");
					Map<String,Object> paramCabAdi = new HashMap<String,Object>();
					paramCabAdi.put("NUM_CORREDOC", dua.getNumcorredoc());
					List<Map<String, Object>> listaAdiImpo = cabAdiImpoconsuDAO.select(paramCabAdi);
					if( listaAdiImpo.size() > 0 ) {
						Map<String,Object> mapaAdiImpoConsu = listaAdiImpo.get(0);
						String numTotalEnvios = mapaAdiImpoConsu.get("NUM_TOTALENVIOS")==null ? "0" : mapaAdiImpoConsu.get("NUM_TOTALENVIOS").toString();
						indicador.setDestipoindica(numTotalEnvios);
					}
				}
				if(!codIndicador.equalsIgnoreCase("20"))
					if(indicador.getNumeroCorrelativo()==null)
						indicador.setNumeroCorrelativo(dua.getNumcorredoc());
					nuevosIndicadores.add(indicador);
			} //final FOR indicadores
		
		}
		//Fin - PAS20165E220200021
		dua.setListIndicadores(nuevosIndicadores);
		//PAS20171U220200005 - mtorralba 20170808 - Fin
		params.remove("indactivo");
		params.remove("listaExcluyeTipoIndica");//RMC RIN-P47

		Elementos<DatoAutocertificacion> autocertificaciones = new Elementos<DatoAutocertificacion>();
		autocertificaciones.addAll(cabCertiOrigenDAO.findAutocertificacionByMap(params));
		dua.getDatoCertificadoOrigen().setListAutocertificacion(autocertificaciones);

		Elementos<DatoSerie> series = new Elementos<DatoSerie>();
		series.addAll(detDeclaraDAO.findSerieByMap(params));
		dua.setListSeries(series);

		Elementos<DatoDocTransporte> docsTransporte = new Elementos<DatoDocTransporte>();
		docsTransporte.addAll(detDeclaraDAO.findDocTransporteByMap(params));
		dua.setListDocTransporte(docsTransporte);

		if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
			int i=1;
			for(DatoDocTransporte docTrans:dua.getListDocTransporte()){
				docTrans.setNumsecdoctrans(i++);
			}
		}

		Elementos<DatoFacturaref> facturas = new Elementos<DatoFacturaref>();
		facturas.addAll( formaFactuDAO.findFacturarefByMap(params) );
		for (DatoFacturaref factura :facturas ){
			factura.setPadre(dua);
		}
		dua.setListFacturaRef(facturas);

		if(dua.getManifiesto() != null)
		{

			// OBTENER AL TRANSPORTISTA
			//params.put("numeroCorrelativo", dua.getNumcorredoc());
			String viaTransporte=dua.getManifiesto().getCodmodtransp();
			String codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			if ("1".equals(viaTransporte)){
				codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
			}else if ("4".equals(viaTransporte) || "7".equals(viaTransporte)){ // INC 2017-115387 
				codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			}					
			//params.put("codTipoParticipante", codTipoOper);

			//List<Participante> lstEmpTransporte= participanteDAO.findParticipantesByMap(params);
			if(!CollectionUtils.isEmpty(lstEmpTransporte)){
				Participante datoEmpTransporte=lstEmpTransporte.get(0); // debe haber uno solo
				datoEmpTransporte.getTipoParticipante().setCodDatacat(codTipoOper);
				dua.getManifiesto().setEmpTransporte(datoEmpTransporte);
				//inicio numeracion de la DSEER
				dua.setEmbarcador(datoEmpTransporte);
			}

			params.clear();	
			params.put("numcorredoc", dua.getNumcorredoc());
			//glazaror para obtener los precintos en cadena concatenada
			params.put("getPrecintosAsociados", "1");
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			Elementos<DatoEquipamiento> equipamientos = new Elementos<DatoEquipamiento>();			
			equipamientos.addAll( equipamientoDAO.findEquipamientoByMap(params) );
			dua.getManifiesto().setListEquipamientos(equipamientos);

			//glazaror... ejecutamos la carga de precintos de forma optimizada... evitamos querys por cada contenedor
			cargarPrecintos(equipamientos, dua.getDeclarante());
			/*if(equipamientos != null && equipamientos.size()  > 0)
			{
				for (DatoEquipamiento datoEquipamiento : equipamientos) {
					params.put("numequipo", datoEquipamiento.getNumequipo());

					Elementos<DatoPrecinto> precintos = new Elementos<DatoPrecinto>();
					precintos.addAll(precintoDAO.findDatoPrecintoByMap(params));
					datoEquipamiento.setListPrecintos(precintos );
				}
			}*/
		}

		params.clear();

		//glazaror... inicio carga regimenes precedentes
		params.put("numcorredoc", dua.getNumcorredoc());
		params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
		List<DatoRegPrecedencia> precedentesAll = docuPreceDuaDAO.findRegPrecedenciaByMap(params);
		//agrupamiento precedentes por serie
		Map<Integer, Elementos<DatoRegPrecedencia>> precedentesMap = new HashMap<Integer, Elementos<DatoRegPrecedencia>>();
		for (DatoRegPrecedencia precedente : precedentesAll) {
			Integer numeroSerie = precedente.getNumserie();
			Elementos<DatoRegPrecedencia> precedentesBySerie = precedentesMap.get(numeroSerie);
			if (precedentesBySerie == null) {
				precedentesBySerie = new Elementos<DatoRegPrecedencia>();
				precedentesMap.put(numeroSerie, precedentesBySerie);
			}
			precedentesBySerie.add(precedente);
		}
		//glazaror... fin carga regimenes precedentes

		//glazaror... inicio carga documentos de soporte para las series... un solo query
		List<DatoSerieDocSoporte> documentosSoporteSerieAll = docAutAsociadoDAO.findSerieDocSoporteByMap(params);
		//agrupamos los documentos de soporte por serie
		Map<Integer, Elementos<DatoSerieDocSoporte>> documentosSoporteSerieMap = new HashMap<Integer, Elementos<DatoSerieDocSoporte>>();
		for (DatoSerieDocSoporte documentoSoporte : documentosSoporteSerieAll) {
			Integer numeroSerie = documentoSoporte.getNumserie();
			Elementos<DatoSerieDocSoporte> documentosSoporteBySerie = documentosSoporteSerieMap.get(numeroSerie);
			if (documentosSoporteBySerie == null) {
				documentosSoporteBySerie = new Elementos<DatoSerieDocSoporte>();
				documentosSoporteSerieMap.put(numeroSerie, documentosSoporteBySerie);
			}
			documentosSoporteBySerie.add(documentoSoporte);
		}
		//glazaror... fin carga documentos de soporte para las series... un solo query

		//glazaror... inicio carga documentos certificados origen... se debe evaluar si es que es posible ejecutar un solo query para los documentos de soporte y certificados de origen... pendiente
		List<DatoSerieDocSoporte> documentosCertificadoOrigenAll = docAutAsociadoDAO.findSerieDocCertiOrigenByMap(params);
		//agrupamos los certificados origen por serie
		Map<Integer, Elementos<DatoSerieDocSoporte>> certificadosOrigenSerieMap = new HashMap<Integer, Elementos<DatoSerieDocSoporte>>();
		for (DatoSerieDocSoporte certificadoOrigen : documentosCertificadoOrigenAll) {
			Integer numeroSerie = certificadoOrigen.getNumserie();
			Elementos<DatoSerieDocSoporte> certificadosOrigenBySerie = certificadosOrigenSerieMap.get(numeroSerie);
			if (certificadosOrigenBySerie == null) {
				certificadosOrigenBySerie = new Elementos<DatoSerieDocSoporte>();
				certificadosOrigenSerieMap.put(numeroSerie, certificadosOrigenBySerie);
			}
			certificadosOrigenBySerie.add(certificadoOrigen);
		}
		//glazaror... fin carga documentos certificados origen 

		//glazaror.. inicio carga de facturas por serie
		List<DatoSerieDocSoporte> facturasSerieAll = facturaSerieDAO.findSerieFacturaDocSoporteByMap(params);
		Map<Integer, Elementos<DatoSerieDocSoporte>> facturasSerieMap = new HashMap<Integer, Elementos<DatoSerieDocSoporte>>();
		for (DatoSerieDocSoporte facturaSerie : facturasSerieAll) {
			Integer numeroSerie = facturaSerie.getNumserie();
			Elementos<DatoSerieDocSoporte> facturasBySerie = facturasSerieMap.get(numeroSerie);
			if (facturasBySerie == null) {
				facturasBySerie = new Elementos<DatoSerieDocSoporte>();
				facturasSerieMap.put(numeroSerie, facturasBySerie);
			}
			facturasBySerie.add(facturaSerie);
		}
		//glazaror.. fin carga de facturas por serie

		//glazaror... inicio carga de vehiculos por serie... segun vila una serie puede tener asociada solo un vehiculo (en ceticos)
		List<DatoVehiculo> vehiculosAll = vehiCeticoDAO.findVehiculoByMap(params);
		//agrupamos los vehiculos por serie
		Map<Integer, Elementos<DatoVehiculo>> vehiculosSerieMap = new HashMap<Integer, Elementos<DatoVehiculo>>();
		for (DatoVehiculo vehiculo : vehiculosAll) {
			Integer numeroSerie = vehiculo.getNumserie();
			Elementos<DatoVehiculo> vehiculosBySerie = vehiculosSerieMap.get(numeroSerie);
			if (vehiculosBySerie == null) {
				vehiculosBySerie = new Elementos<DatoVehiculo>();
				vehiculosSerieMap.put(numeroSerie, vehiculosBySerie);
			}
			vehiculosBySerie.add(vehiculo);
		}
		//glazaror... fin carga de vehiculos por serie

		//glazaror... inicio carga de montos por serie y vehiculo
		List<DatoMontoGasto> montosGastoAll = montoGastoDAO.findMontoGastoByMap(params);
		//agrupamos los montos por serie
		Map<Integer, Elementos<DatoMontoGasto>> montosGastoSerieMap = new HashMap<Integer, Elementos<DatoMontoGasto>>();
		for (DatoMontoGasto montoGasto : montosGastoAll) {
			Integer numeroSerie = montoGasto.getNumserie();
			Elementos<DatoMontoGasto> montosGastoBySerie = montosGastoSerieMap.get(numeroSerie);
			if (montosGastoBySerie == null) {
				montosGastoBySerie = new Elementos<DatoMontoGasto>();
				montosGastoSerieMap.put(numeroSerie, montosGastoBySerie);
			}
			montosGastoBySerie.add(montoGasto);
		}
		//glazaror... fin carga de montos por serie y vehiculo


		for (DatoSerie serie : dua.getListSeries()) {
			params.put("numcorredoc", dua.getNumcorredoc());
			params.put("numserie", serie.getNumserie());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			//ggranados formb
			serie.setPadre(dua);

			//glazaror... reemplazamos el query por busqueda en precedentesMap
			/*Elementos<DatoRegPrecedencia> regprecedencias = new Elementos<DatoRegPrecedencia>();
			regprecedencias.addAll(docuPreceDuaDAO.findRegPrecedenciaByMap(params));*/
			Elementos<DatoRegPrecedencia> regprecedencias = precedentesMap.get(serie.getNumserie());
			serie.setListRegPrecedencia(regprecedencias);

			// serie.setListContrato(listContrato)

			//glazaror... ya no es necesario consultar el codtratprefe con otro query el convenio serie (este dato se consulta mediante subquery al consultar las series)
			/*Map<String,Object> paramConvSerie=new HashMap<String, Object>();
			paramConvSerie.put("NUM_CORREDOC", dua.getNumcorredoc());
			paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());

			Map<String,Object> mapConv=null;
			Integer codtratprefe=null;
			paramConvSerie.put("COD_TIPCONVENIO", "T");*/
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			//paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			/*List<Map<String,Object>> lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codtratprefe=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodtratprefe(codtratprefe);*/

			//glazaror... ya no es necesario consultar el codconvinter con otro query el convenio serie (este dato se consulta mediante subquery al consultar las series)
			/*Integer codconvinter=null;
			paramConvSerie.put("COD_TIPCONVENIO", "I");*/
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			//paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			/*lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codconvinter=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodconvinter(codconvinter);*/

			//glazaror... ya no es necesario consultar el codliberatorio con otro query el convenio serie (este dato se consulta mediante subquery al consultar las series)
			/*Integer codliberatorio=null;
			paramConvSerie.put("COD_TIPCONVENIO", "C");*/
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			//paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			/*lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codliberatorio=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodliberatorio(codliberatorio)	;		
			paramConvSerie.clear();*/

			Elementos<DatoSerieDocSoporte> docs = new Elementos<DatoSerieDocSoporte>();

			// doc soporte serie y doc autoriza serie
			//glazaror... evitamos un query adicional de documentos de soporte por cada serie
			//docs.addAll(docAutAsociadoDAO.findSerieDocSoporteByMap(params));
			//glazaror... obtenemos los documentos de soporte del mapa donde se agrupo los documentos de soporte por serie
			Elementos<DatoSerieDocSoporte> documentosSoporteBySerie = documentosSoporteSerieMap.get(serie.getNumserie());
			if (documentosSoporteBySerie != null && !documentosSoporteBySerie.isEmpty()) {
				docs.addAll(documentosSoporteBySerie);
			}


			// doc  certiorigen
			//glazaror... evitamos un query adicional de certificados de origen por cada serie
			//docs.addAll(docAutAsociadoDAO.findSerieDocCertiOrigenByMap(params));
			//glazaror... obtenemos los certificados de origen del mapa donde se agrupo los certificados de origen por serie

			Elementos<DatoSerieDocSoporte> certificadosOrigenBySerie = certificadosOrigenSerieMap.get(serie.getNumserie());
			if (certificadosOrigenBySerie != null && !certificadosOrigenBySerie.isEmpty()) {
				docs.addAll(certificadosOrigenBySerie);
			}


			// factura serie
			//glazaror... evitamos un query adicional de facturas por cada serie
			//docs.addAll(facturaSerieDAO.findSerieFacturaDocSoporteByMap(params));
			//glazaror... en su lugar obtenemos las facturas del mapa donde se agrupo las facturas por serie
			Elementos<DatoSerieDocSoporte> facturasBySerie = facturasSerieMap.get(serie.getNumserie());
			if (facturasBySerie != null && !facturasBySerie.isEmpty()) {
				docs.addAll(facturasBySerie);
			}
			// doc soporte Transporte

			if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
				for(DatoDocTransporte docTrans:dua.getListDocTransporte()){
					if(docTrans.getNumdoctransporte().equals(serie.getNumdoctransporte()) 
							&& docTrans.getNumdetalle().equals(serie.getNumdetalle()) ){
						DatoSerieDocSoporte serieDocSopTrans=new DatoSerieDocSoporte();
						serieDocSopTrans.setNumcorredoc(dua.getNumcorredoc());
						serieDocSopTrans.setNumserie(serie.getNumserie());
						serieDocSopTrans.setNumiddocsoporte(docTrans.getNumsecdoctrans());
						serieDocSopTrans.setCodtipodocsoporte("3");
						docs.add(serieDocSopTrans);
						break;
					}
				}

			}

			serie.setListSerieDocSoporte(docs);

			//Elementos<DatoVehiculo> vehiculos = new Elementos<DatoVehiculo>();
			//glazaror... evitamos un query adicional de vehiculos por cada serie
			//vehiculos.addAll(vehiCeticoDAO.findVehiculoByMap(params));

			//glazaror... en su lugar obtenemos los vehiculos del mapa donde se agrupo los vehiculos por serie
			Elementos<DatoVehiculo> vehiculos = vehiculosSerieMap.get(serie.getNumserie());
			if (vehiculos == null) {
				vehiculos = new Elementos<DatoVehiculo>();
			}
			serie.setListVehiculos(vehiculos);

			for (DatoVehiculo vehiculo : serie.getListVehiculos()) {
				// params.put("numcorredoc", vehiculo.get());
				//TODO falta where
				//glazaror... evitamos un query adicional de montos gasto por cada serie
				//Elementos<DatoMontoGasto> montos = new Elementos<DatoMontoGasto>();
				//params.put("inddel", "0");
				//montos.addAll(montoGastoDAO.findMontoGastoByMap(params));

				//glazaror... en su lugar obtenemos los montos gasto del mapa donde se agrupo los montos por serie
				Elementos<DatoMontoGasto> montos = montosGastoSerieMap.get(vehiculo.getNumserie());
				if (montos == null) {
					montos = new Elementos<DatoMontoGasto>();
				}
				vehiculo.setListMontoGastos(montos);
			}

			//glazaror... evitamos un query adicional de det_adiimpoconsu por cada serie... el mismo query sobre detdeclara carga este dato 
			//DatoAdiSerieImpoConsumo datoAdiSerieImpoConsumo = new DatoAdiSerieImpoConsumo();
			//datoAdiSerieImpoConsumo = detAdiImpoconsuDAO.selectByPK(params);
			//serie.setDatoAdiSerieImpoConsumo(datoAdiSerieImpoConsumo);

			//glazaror... evitamos un query adicional de det_adiatreex por cada serie... el mismo query sobre detdeclara carga este dato
			//DatoAdiSerieAtreexp datoAdiSerieAtreexp = new DatoAdiSerieAtreexp ();
			//datoAdiSerieAtreexp  = detAdiAtreexDAO.selectByPK(params);
			//serie.setDatoAdiSerieAtreexp(datoAdiSerieAtreexp);

			params.clear();
		}		

		return dua;
	}

	//glazaror inicio metodo cargarPrecintos
	private void cargarPrecintos(Elementos<DatoEquipamiento> equipamientos, Participante declarante) {
		if(equipamientos != null && equipamientos.size()  > 0) {
			//glazaror... ya no es necesario realizar un bucle sobre la lista de contenedores para buscar precintos...
			//el dato precintos ya se consulta en el mismo query de contenedores
			for (DatoEquipamiento datoEquipamiento : equipamientos) {
				String precintosAsString = datoEquipamiento.getPrecintosAsString()!=null?datoEquipamiento.getPrecintosAsString().trim():"";//gmontoya PAS20155E220000425
				if (!precintosAsString.isEmpty()) {
					// r2bz Se carga la tabla de movimientos FK con precintos y Equipamiento
					cargarMovEquipamiento(datoEquipamiento, declarante);									
					//glazaror... entonces el contenedor tiene una lista precintos concatenados... hay q generar una lista con esta data
					String[] precintosAsArray = precintosAsString.split(",");
					//inicializamos la lista de precintos
					Elementos<DatoPrecinto> precintos = new Elementos<DatoPrecinto>();
					//adicionamos en la lista de precintos los objeto DatoPrecinto
					for (String precintoAsStringFromArray : precintosAsArray) {
						DatoPrecinto precinto = new DatoPrecinto();
						precinto.setNumprecinto(precintoAsStringFromArray);
						precintos.add(precinto);
					}
					//por ultimo seteamos la lista de precintos en el objeto DatoEquipamiento
					datoEquipamiento.setListPrecintos(precintos);
				}
			}
		}
	}
	//glazaror fin metodo cargarPrecintos

	private void cargarMovEquipamiento(DatoEquipamiento datoEquipamiento, Participante declarante){
		Elementos<DatoMovEquipamiento> listDatoMovEquipamiento= new Elementos<DatoMovEquipamiento>();					
		if (datoEquipamiento.getListmovEquipamiento() ==null){
			datoEquipamiento.setListmovEquipamiento(new Elementos<DatoMovEquipamiento>());
		}	
		DatoMovEquipamiento datoMovEquipamiento = new DatoMovEquipamiento();
		datoMovEquipamiento.setOperadorCarga(declarante);
		datoMovEquipamiento.setNumcorredoc(datoEquipamiento.getNumcorredoc());
		datoMovEquipamiento.setNumequipo(datoEquipamiento.getNumequipo());
		datoMovEquipamiento.setCodtipmov("99");
		listDatoMovEquipamiento.add(datoMovEquipamiento);				
		datoEquipamiento.setListmovEquipamiento(listDatoMovEquipamiento);
	}

	public DUA getDUAOld(Map<String, Object> params)
	{
		ParticipanteDocDAO participanteDAO = fabricaDeServicios.getService("participanteDAO");
		ObservacionDAO observacionDAO = fabricaDeServicios.getService("observacionDAO");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		VehiCeticoDAO vehiCeticoDAO = fabricaDeServicios.getService("vehiCeticoDAO");
		DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
		PrecintoDAO precintoDAO = fabricaDeServicios.getService("manifiesto.precintoDAO");
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		EquipamientoDAO equipamientoDAO = fabricaDeServicios.getService("manifiesto.equipamientoDAO");
		DocAutAsociadoDAO docAutAsociadoDAO = fabricaDeServicios.getService("docAutAsociadoDAO");
		CabCertiOrigenDAO cabCertiOrigenDAO = fabricaDeServicios.getService("cabCertiOrigenDAO");
		MontoGastoDAO montoGastoDAO = fabricaDeServicios.getService("montoGastoDAO");
		FormaFactuDAO formaFactuDAO = fabricaDeServicios.getService("formaFactuDAO");
		ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("convenioSerieDAO");
		FacturaSerieDAO facturaSerieDAO = fabricaDeServicios.getService("facturaSerieDAO");
		FinUbicacionDAO finUbicacionDAO = fabricaDeServicios.getService("finUbicacionDAO");
		DetAdiImpoconsuDAO detAdiImpoconsuDAO = fabricaDeServicios.getService("detAdiImpoconsuDAO");
		DetAdiAtreexDAO detAdiAtreexDAO = fabricaDeServicios.getService("detAdiAtreexDAO");
		CabAdjImpoconsuDAO cabAdjImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");
		
		
		
		DUA dua = cabDeclaraDAO.findDUAByMap(params);

		if( dua == null )
			return null; 

		// OBTENER EL AGENTE
		params.put("numeroCorrelativo", dua.getNumcorredoc());
		params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA);

		List<Participante> lstAgentes= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstAgentes)){
			Participante agente=lstAgentes.get(0); // debe haber uno solo
			dua.setNumdocumento(agente.getNumeroDocumentoIdentidad());
			dua.setCodtipooper(agente.getTipoDocumentoIdentidad().getCodDatacat());
			// INICIO RIN15
			dua.setAgenteAduanas(agente);
			// FIN RIN15
		}

		params.clear();


		// OBTENER AL DECLARANTE
		params.put("numeroCorrelativo", dua.getNumcorredoc());
		params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);

		List<Participante> lstDeclarante= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstDeclarante)){
			Participante declarante=lstDeclarante.get(0); // debe haber uno solo
			dua.setDeclarante(declarante);
		}

		params.clear();		


		// OBTENER AL RUC ANEXO UBICACION
		params.put("numeroCorrelativo", dua.getNumcorredoc());
		params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION);

		List<Participante> lstAnexoUbi= participanteDAO.findParticipantesByMap(params);
		if(!CollectionUtils.isEmpty(lstAnexoUbi)){
			Participante rucAnexoUbicacion=lstAnexoUbi.get(0); // debe haber uno solo
			dua.setRucAnexoUbicacion(rucAnexoUbicacion);
		}

		/*branch ingreso 2011-009 hosorio inicio*/
		if("20".equals(dua.getCodregimen())){
			Map<String,Object> paramFinUbi=new HashMap<String, Object>();
			paramFinUbi.put("NUM_CORREDOC", dua.getNumcorredoc());
			List<Map<String,Object>> lstFinUbi= finUbicacionDAO.select(paramFinUbi);
			if(lstFinUbi!=null && lstFinUbi.size()>0){
				// si no exite ruc de fin d ubicacion , no existe participante ruc anexo
				if(SunatStringUtils.isEmptyTrim((String)lstFinUbi.get(0).get("NUM_DOC_LOCMERC"))){
					dua.setRucAnexoUbicacion(null);
				}
			}
		}
		if("70".equals(dua.getCodregimen())){
			Map<String,Object> paramPartDepo=new HashMap<String, Object>();
			paramPartDepo.put("numeroCorrelativo", dua.getNumcorredoc());
			paramPartDepo.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO);
			List<Participante> lstPartDepos= participanteDAO.findParticipantesByMap(paramPartDepo);
			if(!CollectionUtils.isEmpty(lstPartDepos)){
				Participante pDepo=lstPartDepos.get(0);
				if(pDepo!=null)
					dua.setNumrucdeposito(pDepo.getNumeroDocumentoIdentidad());
			}
		}



		/*branch ingreso 2011-009 hosorio fin*/

		params.clear();		


		params.put("numcorredoc", dua.getNumcorredoc());
		params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
		// OBTENIENDO OBSERVACIONES
		Elementos<Observacion> observaciones_dua = new Elementos<Observacion>();
		observaciones_dua.addAll(observacionDAO.findObservcionByMap(params));
		if (!CollectionUtils.isEmpty(observaciones_dua)){
			Iterator<Observacion> it = observaciones_dua.iterator();
			while(it.hasNext()){
				Observacion mObsDua = (Observacion)it.next();
				if (mObsDua.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_ITEMSFORMB)){
					it.remove();
				}				
			}
		}
		dua.setListObservaciones(observaciones_dua);

		DatoPagoDecla pagoElectronico = new DatoPagoDecla();
		pagoElectronico = cabAdjImpoconsuDAO.selectByPK(params);
		dua.setPagoElectronico(pagoElectronico);


		/*obteniendo doc de soporte tabla doc asociado*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();


		listOtrosDocSoporte.addAll(docAutAsociadoDAO.findDocSoporteByParameterMap(params) );
		dua.setListOtrosDocSoporte(listOtrosDocSoporte);


		/*r2bz obteniendo doc de soporte tabla doc asociado pero de CO*/
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporteCO=new Elementos<DatoOtroDocSoporte>();


		listOtrosDocSoporteCO.addAll(docAutAsociadoDAO.findDocSoporteCertiOrigenByParameterMap(params) );
		dua.setListOtrosDocSoporteCO(listOtrosDocSoporteCO);


		/*obteniendo doc autorizante*/
		Elementos<DatoDocAutorizante> listDocAutorizantes=new Elementos<DatoDocAutorizante>();
		listDocAutorizantes.addAll(docAutAsociadoDAO.findDocAutorizanteByParameterMap(params) );
		dua.setListDocAutorizantes(listDocAutorizantes);		


		Elementos<DatoIndicadores> indicadores = new Elementos<DatoIndicadores>();
		//r2bz solo obtener indicadores de transmision 	PAS20110001128	
		params.put("codtiporegistro", "T");
		params.put("indactivo", Constants.INDICADOR_ACTIVO);
		indicadores.addAll(indicadorDUADAO.findIndicadoresByMap(params));
		//Se elimina indicador  20 no deberia estar grabado como tipo "T" Inicio - PAS20165E220200021
		if(!indicadores.isEmpty()){
			for(DatoIndicadores indicador:indicadores){
				if(indicador.getCodtipoindica().equalsIgnoreCase("20")){
					indicadores.remove(indicador);
					break;
				}
			}
		}
		//Fin - PAS20165E220200021		
		dua.setListIndicadores(indicadores);
		params.remove("indactivo");

		Elementos<DatoAutocertificacion> autocertificaciones = new Elementos<DatoAutocertificacion>();
		autocertificaciones.addAll(cabCertiOrigenDAO.findAutocertificacionByMap(params));
		dua.getDatoCertificadoOrigen().setListAutocertificacion(autocertificaciones);

		Elementos<DatoSerie> series = new Elementos<DatoSerie>();
		series.addAll(detDeclaraDAO.findSerieByMap(params));
		dua.setListSeries(series);

		Elementos<DatoDocTransporte> docsTransporte = new Elementos<DatoDocTransporte>();
		docsTransporte.addAll(detDeclaraDAO.findDocTransporteByMap(params));
		dua.setListDocTransporte(docsTransporte);

		if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
			int i=1;
			for(DatoDocTransporte docTrans:dua.getListDocTransporte()){
				docTrans.setNumsecdoctrans(i++);
			}
		}

		Elementos<DatoFacturaref> facturas = new Elementos<DatoFacturaref>();
		facturas.addAll( formaFactuDAO.findFacturarefByMap(params) );
		for (DatoFacturaref factura :facturas ){
			factura.setPadre(dua);
		}
		dua.setListFacturaRef(facturas);

		if(dua.getManifiesto() != null)
		{

			// OBTENER AL TRANSPORTISTA
			params.put("numeroCorrelativo", dua.getNumcorredoc());
			String viaTransporte=dua.getManifiesto().getCodmodtransp();
			String codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			if ("1".equals(viaTransporte)){
				codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
			}else if ("4".equals(viaTransporte)){
				codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			}					
			params.put("codTipoParticipante", codTipoOper);

			List<Participante> lstEmpTransporte= participanteDAO.findParticipantesByMap(params);
			if(!CollectionUtils.isEmpty(lstEmpTransporte)){
				Participante datoEmpTransporte=lstEmpTransporte.get(0); // debe haber uno solo
				datoEmpTransporte.getTipoParticipante().setCodDatacat(codTipoOper);
				dua.getManifiesto().setEmpTransporte(datoEmpTransporte);
			}

			params.clear();	
			params.put("numcorredoc", dua.getNumcorredoc());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);			

			Elementos<DatoEquipamiento> equipamientos = new Elementos<DatoEquipamiento>();			
			equipamientos.addAll( equipamientoDAO.findEquipamientoByMap(params) );
			dua.getManifiesto().setListEquipamientos(equipamientos);

			if(equipamientos != null && equipamientos.size()  > 0)
			{
				for (DatoEquipamiento datoEquipamiento : equipamientos) {
					params.put("numequipo", datoEquipamiento.getNumequipo());

					Elementos<DatoPrecinto> precintos = new Elementos<DatoPrecinto>();
					precintos.addAll(precintoDAO.findDatoPrecintoByMap(params));
					datoEquipamiento.setListPrecintos(precintos );
				}
			}
		}

		params.clear();

		for (DatoSerie serie : dua.getListSeries()) {
			params.put("numcorredoc", dua.getNumcorredoc());
			params.put("numserie", serie.getNumserie());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);

			//ggranados formb
			serie.setPadre(dua);

			Elementos<DatoRegPrecedencia> regprecedencias = new Elementos<DatoRegPrecedencia>();
			regprecedencias.addAll(docuPreceDuaDAO.findRegPrecedenciaByMap(params));
			serie.setListRegPrecedencia(regprecedencias);

			// serie.setListContrato(listContrato)

			Map<String,Object> paramConvSerie=new HashMap<String, Object>();
			paramConvSerie.put("NUM_CORREDOC", dua.getNumcorredoc());
			paramConvSerie.put("NUM_SECSERIE", serie.getNumserie());

			Map<String,Object> mapConv=null;
			Integer codtratprefe=null;
			paramConvSerie.put("COD_TIPCONVENIO", "T");
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			List<Map<String,Object>> lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codtratprefe=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodtratprefe(codtratprefe);

			Integer codconvinter=null;
			paramConvSerie.put("COD_TIPCONVENIO", "I");
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codconvinter=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodconvinter(codconvinter);


			Integer codliberatorio=null;
			paramConvSerie.put("COD_TIPCONVENIO", "C");
			/*branch ingreso 2011-009 hosorio inicio 06/07/2011*/
			paramConvSerie.put("IND_DEL", "0");
			/*branch ingreso 2011-009 hosorio fin 06/07/2011*/
			lstConv=  convenioSerieDAO.select(paramConvSerie);
			if(!CollectionUtils.isEmpty(lstConv)){
				mapConv=lstConv.get(0);
				codliberatorio=Integer.valueOf( ((String)mapConv.get("COD_CONVENIO")).trim());
			}
			serie.setCodliberatorio(codliberatorio)	;		
			paramConvSerie.clear();

			Elementos<DatoSerieDocSoporte> docs = new Elementos<DatoSerieDocSoporte>();

			// doc soporte serie y doc autoriza serie
			docs.addAll(docAutAsociadoDAO.findSerieDocSoporteByMap(params));

			// doc  certiorigen
			docs.addAll(docAutAsociadoDAO.findSerieDocCertiOrigenByMap(params));


			// factura serie
			docs.addAll(facturaSerieDAO.findSerieFacturaDocSoporteByMap(params));
			// doc soporte Transporte

			if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
				for(DatoDocTransporte docTrans:dua.getListDocTransporte()){
					if(docTrans.getNumdoctransporte().equals(serie.getNumdoctransporte()) 
							&& docTrans.getNumdetalle().equals(serie.getNumdetalle()) ){
						DatoSerieDocSoporte serieDocSopTrans=new DatoSerieDocSoporte();
						serieDocSopTrans.setNumcorredoc(dua.getNumcorredoc());
						serieDocSopTrans.setNumserie(serie.getNumserie());
						serieDocSopTrans.setNumiddocsoporte(docTrans.getNumsecdoctrans());
						serieDocSopTrans.setCodtipodocsoporte("3");
						docs.add(serieDocSopTrans);
						break;
					}
				}

			}

			serie.setListSerieDocSoporte(docs);

			Elementos<DatoVehiculo> vehiculos = new Elementos<DatoVehiculo>();
			vehiculos.addAll(vehiCeticoDAO.findVehiculoByMap(params));
			serie.setListVehiculos(vehiculos);

			for (DatoVehiculo vehiculo : serie.getListVehiculos()) {
				// params.put("numcorredoc", vehiculo.get());
				//TODO falta where
				Elementos<DatoMontoGasto> montos = new Elementos<DatoMontoGasto>();
				params.put("inddel", "0");
				montos.addAll(montoGastoDAO.findMontoGastoByMap(params));
				vehiculo.setListMontoGastos(montos);
			}

			DatoAdiSerieImpoConsumo datoAdiSerieImpoConsumo = new DatoAdiSerieImpoConsumo();
			datoAdiSerieImpoConsumo = detAdiImpoconsuDAO.selectByPK(params);
			serie.setDatoAdiSerieImpoConsumo(datoAdiSerieImpoConsumo);

			DatoAdiSerieAtreexp datoAdiSerieAtreexp = new DatoAdiSerieAtreexp ();
			datoAdiSerieAtreexp  = detAdiAtreexDAO.selectByPK(params);
			serie.setDatoAdiSerieAtreexp(datoAdiSerieAtreexp);

			params.clear();
		}		

		return dua;
	}

	/* olunar 309 */
	@Override
	public DUA getCabDUA(String codigoAduana, String numeroDeclaracion, String annoPresentacion, String codigoRegimen)
	{
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana", codigoAduana);
		params.put("numeroDeclaracion", numeroDeclaracion);
		params.put("annoPresentacion", annoPresentacion);
		params.put("codigoRegimen", codigoRegimen);
		DUA dua = cabDeclaraDAO.findDUAByKeyMap(params);
		return dua;
	}

	@Override
	public DUA getCabDUA(Long numcorredoc) {
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("numeroCorrelativo", numcorredoc);
		DUA dua = cabDeclaraDAO.findDUAByKeyMap(params);
		return dua;
	}
	/* fin */

	/**
	 * Retorna series de la declaracion
	 * @param paramsDetDeclaracion
	 * @return
	 */
	public List<Map<String, Object>> getDetDUA (Map<String,String> paramsDetDeclaracion){
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		List<Map<String, Object>> listDuaSerie = detDeclaraDAO.findSeriesByDocumento(paramsDetDeclaracion);
		return listDuaSerie;
	}


	/*
	public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
		this.formBProveedorDAO = formBProveedorDAO;
	}
	 
	public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO) {
		this.formBMontoDAO = formBMontoDAO;
	}

	public void setParticipanteDAO(ParticipanteDocDAO participanteDAO) {
		this.participanteDAO = participanteDAO;
	}
	public void setCondicionTransaDAO(CondicionTransaDAO condicionTransaDAO) {
		this.condicionTransaDAO = condicionTransaDAO;
	}

	public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO) {
		this.comprobPagoDAO = comprobPagoDAO;
	}

	public void setFactuSuceDAO(FactuSuceDAO factuSuceDAO) {
		this.factuSuceDAO = factuSuceDAO;
	}

	public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO) {
		this.itemFacturaDAO = itemFacturaDAO;
	}

	public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO) {
		this.seriesItemDAO = seriesItemDAO;
	}

	public void setFobProvisionalDAO(VFOBProvisionalDAO fobProvisionalDAO) {
		this.fobProvisionalDAO = fobProvisionalDAO;
	}

	public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO) {
		this.formBItemDescriDAO = formBItemDescriDAO;
	}

	public void setObservacionDAO(ObservacionDAO observacionDAO) {
		this.observacionDAO = observacionDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public void setVehiCeticoDAO(VehiCeticoDAO vehiCeticoDAO) {
		this.vehiCeticoDAO = vehiCeticoDAO;
	}

	public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO) {
		this.docuPreceDuaDAO = docuPreceDuaDAO;
	}

	public DocuPreceDuaDAO getDocuPreceDuaDAO()
	{
		return this.docuPreceDuaDAO;
	}

	public void setPrecintoDAO(PrecintoDAO precintoDAO) {
		this.precintoDAO = precintoDAO;
	}

	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
		this.indicadorDUADAO = indicadorDUADAO;
	}

	public void setEquipamientoDAO(EquipamientoDAO equipamientoDAO) {
		this.equipamientoDAO = equipamientoDAO;
	}

	public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO) {
		this.docAutAsociadoDAO = docAutAsociadoDAO;
	}

	public void setCabCertiOrigenDAO(CabCertiOrigenDAO cabCertiOrigenDAO) {
		this.cabCertiOrigenDAO = cabCertiOrigenDAO;
	}


	public void setFormaFactuDAO(FormaFactuDAO formaFactuDAO) {
		this.formaFactuDAO = formaFactuDAO;
	}

	public ConvenioSerieDAO getConvenioSerieDAO() {
		return convenioSerieDAO;
	}

	public void setConvenioSerieDAO(ConvenioSerieDAO convenioSerieDAO) {
		this.convenioSerieDAO = convenioSerieDAO;
	}

	public FacturaSerieDAO getFacturaSerieDAO() {
		return facturaSerieDAO;
	}

	public void setFacturaSerieDAO(FacturaSerieDAO facturaSerieDAO) {
		this.facturaSerieDAO = facturaSerieDAO;
	}

	public MontoGastoDAO getMontoGastoDAO() {
		return montoGastoDAO;
	}

	public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO) {
		this.montoGastoDAO = montoGastoDAO;
	}

	
		public FinUbicacionDAO getFinUbicacionDAO() {
		return finUbicacionDAO;
	}

	public void setFinUbicacionDAO(FinUbicacionDAO finUbicacionDAO) {
		this.finUbicacionDAO = finUbicacionDAO;
	}
	
	

	public DetAdiImpoconsuDAO getDetAdiImpoconsuDAO() {
		return detAdiImpoconsuDAO;
	}

	public void setDetAdiImpoconsuDAO(DetAdiImpoconsuDAO detAdiImpoconsuDAO) {
		this.detAdiImpoconsuDAO = detAdiImpoconsuDAO;
	}

	public DetAdiAtreexDAO getDetAdiAtreexDAO() {
		return detAdiAtreexDAO;
	}

	public void setDetAdiAtreexDAO(DetAdiAtreexDAO detAdiAtreexDAO) {
		this.detAdiAtreexDAO = detAdiAtreexDAO;
	}

	public CabAdjImpoconsuDAO getCabAdjImpoconsuDAO() {
		return cabAdjImpoconsuDAO;
	}

	public void setCabAdjImpoconsuDAO(CabAdjImpoconsuDAO cabAdjImpoconsuDAO) {
		this.cabAdjImpoconsuDAO = cabAdjImpoconsuDAO;
	}
*/
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	/*branch ingreso 2011-029 hosorio inicio 14/07/2011*/
	public List<DatoSerie> getLstDatoSerie(Map<String,Object> params){
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		Elementos<DatoSerie> series = new Elementos<DatoSerie>();
		series.addAll(detDeclaraDAO.findSerieByMap(params));		
		return series;
	}

	/**
	 * Determina las declaraciones anticipadas o urgentes pendientes de regularizar y con plazo vencido
	 * @param importador
	 * @param plazo
	 * @param modalidad
	 * @return
	 */
	public List<Declaracion> getDeclaracionPendienteRegularizar(Participante importador, Integer plazo, String modalidad, String indRegul){
		Map<String,Object> paramPendienteReg=new HashMap<String,Object>();
		if (importador != null) {
			paramPendienteReg.put("COD_TIPDOC_IMP", importador.getTipoDocumentoIdentidad().getCodDatacat());
			paramPendienteReg.put("NUM_DOCIDENT_IMP", importador.getNumeroDocumentoIdentidad());
		}
		paramPendienteReg.put("COD_MODALIDAD", modalidad);
		paramPendienteReg.put("PLAZO", plazo);
		paramPendienteReg.put("ENVIO_REGUL", indRegul);
		paramPendienteReg.put("CON_LEVANTE",true);
		//Se agrega para excluir a las declaraciones numeradasd antes de  02/05/2011
		paramPendienteReg.put("SIN_DECLARACION",true);

		List<Declaracion> declaracionesPorRegularizar = getDeclaracionPendienteRegularizar(paramPendienteReg);
		return declaracionesPorRegularizar;
	}


	public List<Declaracion> getDeclaracionPendienteRegularizar(Map<String,Object> paramPendienteReg){
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		Integer plazo = SunatNumberUtils.toInteger(paramPendienteReg.get("PLAZO"));
		List<Declaracion> declaracionesPorRegularizar =  cabDeclaraDAO.findDeclaraPendienteRegularizacion(paramPendienteReg);
		List<Declaracion> declaracionesPorRegularizarTemp =  new ArrayList<Declaracion>(); 
		for(Declaracion declaracionPendiente:declaracionesPorRegularizar){		
			ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
			Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracionPendiente.getDua().getManifiesto().getCodtipomanif(), 
					declaracionPendiente.getDua().getManifiesto().getCodmodtransp(), declaracionPendiente.getDua().getManifiesto().getCodaduamanif(), 
					SunatNumberUtils.toInteger(declaracionPendiente.getDua().getManifiesto().getAnnmanif()), declaracionPendiente.getDua().getManifiesto().getNummanif(), true);
			//AND M.FEC_DESCARGA + #PLAZO:NUMBER# <![CDATA[< ]]> SYSDATE
			if (manifiesto!= null){
				Date fechaDescarga = manifiesto.getFechaTerminoDeDescarga();
				if (!SunatDateUtils.isDefaultDate(fechaDescarga)){
					if (SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(fechaDescarga, plazo), new Date(),SunatDateUtils.COMPARA_SOLO_FECHA)){	            		
						declaracionesPorRegularizarTemp.add(declaracionPendiente);  		
					}
				}
			}
		}
		return declaracionesPorRegularizarTemp;
	}

	// FIXME RIN16 : lpalominom [inicio]
	/**
	 * {@inheritDoc}
	 */
	public boolean existeEstadoHistorico(Declaracion declaracion){
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		boolean existe = false;
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codaduana", declaracion.getCodaduana());
		parametros.put("annpresen", declaracion.getDua().getAnnpresen());
		parametros.put("numeroDeclaracion", declaracion.getNumeroDeclaracion());
		parametros.put("codregimen", declaracion.getCodregimen());
		parametros.put("codEstdua", declaracion.getDua().getCodEstdua());

		List<Map<String,?>> lista = cabDeclaraDAO.buscarEstadoEnHistorico(parametros);
		if (lista != null && lista.size() > 0){
			existe = true;
		}
		return existe;
	}
	// FIXME RIN16 : lpalominom [fin]

	/**Inicio de cambios PAS20165E220200032***/

	public boolean esVigenteNuevaLGA(Declaracion declaracion) {
		boolean esVigente = false;

		Date fechaReferencia = declaracion.getDua().getFecdeclaracion();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> fechaHabilitacion = catalogoAyudaService.getElementoCat(CATALOGO_DE_FECHA_HABILITACION_LGA,"0021", "01", new Date());//cambio por PAS20165E220200087 de 0015 a 0021 vigencia post levante
		Date fechaHabil = fechaHabilitacion != null && !fechaHabilitacion.isEmpty()? SunatDateUtils.getDateFromUnknownFormat(fechaHabilitacion.get("fec_inidatcat").toString()) : null;

		if (fechaHabil != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaHabil,SunatDateUtils.COMPARA_SOLO_FECHA)) {
			esVigente = true;
		}
		return esVigente;
	} 

	public boolean esVigenteNuevaLGAPorFecha(Date fechaDeclaracion) {
		boolean esVigente = false;

		Date fechaReferencia = fechaDeclaracion;
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> fechaHabilitacion = catalogoAyudaService.getElementoCat(CATALOGO_DE_FECHA_HABILITACION_LGA,"0021", "01", new Date());//cambio por PAS20165E220200087 de 0015 a 0021 vigencia post levante
		Date fechaHabil = fechaHabilitacion != null && !fechaHabilitacion.isEmpty()? SunatDateUtils.getDateFromUnknownFormat(fechaHabilitacion.get("fec_inidatcat").toString()) : null;

		if (fechaHabil != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaHabil,SunatDateUtils.COMPARA_SOLO_FECHA)) {
			esVigente = true;
		}
		return esVigente;
	} 


	

}