package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.SecuenciaPerdida;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SecPerdidoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.util.SequenceName;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;

/**
 * 
 * @author rcalla
 * 
 * Implementaci�n del servicio de manejo de secuencias de negocio para la numeracion de la DUA
 */
public class SecuenciaDeclaracionServiceImpl extends IngresoAbstractServiceImpl implements SecuenciaDeclaracionService {

	//SecPerdidoDAO secPerdidoDAO;
	//SequenceDAO sequenceDAO;
	//FabricaDeServicios fabricaDeServicios;
	//private CatalogoHelperImpl catalogoHelper;

	@Override
	public void registrarSecuencia(SecuenciaPerdida secuenciaPerdida) {
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		secPerdidoDAO.insert(secuenciaPerdida);
	}

	/*
	 * (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.service.SecuenciaDeclaracionService#setupSecuenciaDeclaracion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion)
	 * PAra el caso de la aduana maritima con el ingreso del anticipado la secuencia ser� unica y exclusiva del SDA
	 */
	@Override
	public SecuenciaPerdida generaSecuenciaDeclaracion(Declaracion declaracion) {

		SequenceDAO  sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef");
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		
		String secuenciaDeclaracion = "SEDECLARA"+declaracion.getCodaduana()+declaracion.getDua().getCodregimen();
		Long numDeclaracion= null;
		Long numeroCorrelativo = null;

		FechaBean fbCurrent=new FechaBean();
		Integer anho=new Integer(fbCurrent.getAnho());


		SecuenciaPerdida secuenciaTmp = new SecuenciaPerdida();
		secuenciaTmp.setAnnoPresentacion( anho );
		secuenciaTmp.setCodigoAduana( declaracion.getDua().getCodaduanaorden() );
		secuenciaTmp.setCodRegimen( declaracion.getDua().getCodregimen() );
		secuenciaTmp.setIndicadorRecuperacion(" ");
		secuenciaTmp.setCodTipoDocumento("929");
		SecuenciaPerdida secuencia = null;

		List<SecuenciaPerdida> secuencias = secPerdidoDAO.find(secuenciaTmp);
		if(! CollectionUtils.isEmpty(secuencias)){
			secuencia = secuencias.get(0);
		}
		numeroCorrelativo =sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_CORRELATIVODOCUMENTO);			

		// Si no se encontro la secuencia establecer los valores
		if(secuencia == null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");			
			Date fecIniVigencia =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FEC_INIVIG").get("des_datacat").toString());
			Date fecFinVigencia =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FEC_FINVIG").get("des_datacat").toString());
			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecIniVigencia, SunatDateUtils.COMPARA_SOLO_FECHA) && 
					declaracion.getDua().getCodaduanaorden().equals(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO)){
				//Si aun no estamos en la fecha fin de vigencia entonces se toma secuencia de operativa				
				Date fechaHoy = SunatDateUtils.getCurrentDate();
				if (SunatDateUtils.esFecha1MenorQueFecha2(fechaHoy, fecFinVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
					secuenciaDeclaracion = 	"SEDINUMERO";//Secuencia SIGAD - Regimen 10
					numDeclaracion = this.secuenciaSIGAD(declaracion.getDua().getCodaduanaorden(),secuenciaDeclaracion);	
				} else {
					//Si estamos justo en la fecha fin de vigencia entonces se toma secuencia de operativa y se actualiza el catalogo con dicha fecha y se actualiza la secuencia del oracle
					if (SunatDateUtils.sonIguales(fechaHoy, fecFinVigencia,SunatDateUtils.COMPARA_SOLO_FECHA)){
						numDeclaracion = this.transitoriedadSecuencia(declaracion.getDua().getCodaduanaorden(), declaracion.getDua().getCodregimen());
					} else { 						
						numDeclaracion=sequenceDAO.getNextSequence(secuenciaDeclaracion);						
					}
				}
			}else{
				numDeclaracion=sequenceDAO.getNextSequence(secuenciaDeclaracion);			
			}
			secuencia = secuenciaTmp;
			secuencia.setNumeroDeclaracion( numDeclaracion.intValue() );
			secuencia.setNumeroCorrelativo(numeroCorrelativo);
		}else{
			numDeclaracion = secuencia.getNumeroDeclaracion().longValue();			
			secuencia.setIndicadorRecuperacion("T");
			secuencia.setNumeroCorrelativo(numeroCorrelativo);
			actualizarSecuencia(secuencia);
		}

		declaracion.setNumeroDeclaracion(numDeclaracion);
		declaracion.setNumeroCorrelativo(numeroCorrelativo);

		return secuencia;
	}




	/* Pase308
	 * Metodo para sacar la secuencia de la aduana operativa.
	 * 
	 */
	public Long secuenciaSIGAD(String aduana, String secuencia){
		Long seq;
		SequenceDAO daoSIGAD = fabricaDeServicios.getService("despaduanero2.sda.sequenceDef");
		if (aduana.equals(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO)){
			DataSourceContextHolder.setKeyDataSource(aduana);
			seq = daoSIGAD.getNextSequence(secuencia);
		} else {
			DataSourceContextHolder.setKeyDataSource("dcbdseq");
			seq = daoSIGAD.getNextSequence(secuencia);
		}
		return seq;
	}


	/*
	 * RIN15
	 */
	//@Override
	public Long obtenerCorrelativo(String aduana, String tipoSolicitud) {
		SequenceDAO  sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef");
		String seqName = SequenceName.getSequenceNameSolicitudRectificacion(aduana, tipoSolicitud);
		Long sequence = sequenceDAO.getNextSequence(seqName);
		return sequence;
	}
	
	
	private Long transitoriedadSecuencia(String  codaduanaorden, String codRegimen){
		SequenceDAO  sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef");
		Long numDeclaracionSDA= null;
		AyudaServiceDataCatalogo ayudaServiceDataCatalogo = (AyudaServiceDataCatalogo)fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo");
		pe.gob.sunat.despaduanero2.ayudas.model.min.DataCatalogo dataCatalogoMin = new pe.gob.sunat.despaduanero2.ayudas.model.min.DataCatalogo();
		
		dataCatalogoMin.setCodDatacat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA);
		dataCatalogoMin.setDesDatacat("DES_DATACAT");
	
		//Verificamos si ya se actualizo la secuencia del SIGAD en el SDA
		pe.gob.sunat.despaduanero2.ayudas.model.min.DataCatalogo dataCatalogoMinResult = ayudaServiceDataCatalogo.buscarDataCatalogoMinExacto(dataCatalogoMin);
		String secuenciaCatalogo = SunatStringUtils.replace(dataCatalogoMinResult.getDesDatacat(),"DES_DATACAT - ","");
		
		
		if (SunatStringUtils.isEmptyTrim(secuenciaCatalogo)){
			AyudaServiceDataCatalogo ayudaServiceDataCatalogoTx = (AyudaServiceDataCatalogo)fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogoDX");
			//Obtenemos secuencia SIGAD
			String secuenciaDeclaracion = 	"SEDINUMERO";
			Long numDeclaracionSIGAD = this.secuenciaSIGAD(codaduanaorden,secuenciaDeclaracion);
			//Actualizamos catalogo
			DataCatalogo dataCatalogo = new DataCatalogo();
			dataCatalogo.setCodCatalogo(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA);
			dataCatalogo.setCodDatacat("DES_DATACAT");
			dataCatalogo.setDesDatacat(SunatStringUtils.toStringObj(numDeclaracionSIGAD));
			ayudaServiceDataCatalogoTx.actualizarDatacatalogo(dataCatalogo);
			//Actualizamos Secuencia del SDA			
			secuenciaDeclaracion = "SEDECLARA"+codaduanaorden+codRegimen;
			numDeclaracionSDA=sequenceDAO.getNextSequence(secuenciaDeclaracion);
			if (SunatNumberUtils.isGreaterThanParam(numDeclaracionSIGAD, numDeclaracionSDA)){
				BigDecimal secuenciaSIGADBigDecimal = SunatNumberUtils.toBigDecimal(numDeclaracionSIGAD);
				BigDecimal secuenciaSDABigDecimal = SunatNumberUtils.toBigDecimal(numDeclaracionSDA);				
				for (BigDecimal secDeclaracion=secuenciaSDABigDecimal;  secDeclaracion.compareTo(secuenciaSIGADBigDecimal) < 0; secDeclaracion=secDeclaracion.add(BigDecimal.ONE) ){
					//Obtenemos secuencia hasta hacerla igual al del SIGAD
					Long numDeclaracion=sequenceDAO.getNextSequence(secuenciaDeclaracion);
				}
				numDeclaracionSDA = numDeclaracionSIGAD;
			}
		} else{
			String secuenciaDeclaracion = "SEDECLARA"+codaduanaorden+codRegimen;
			numDeclaracionSDA=sequenceDAO.getNextSequence(secuenciaDeclaracion);
		}
		
		return numDeclaracionSDA;
	}
	

	public Long obtenerSecuencia(String nomSecuencia){
		Long numSecuencia= null;
		SequenceDAO sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef");
		numSecuencia = sequenceDAO.getNextSequence(nomSecuencia);	
		return numSecuencia;
	}

	/*
	 * (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.service.SecuenciaDeclaracionService#updateSecuencia(pe.gob.sunat.despaduanero2.declaracion.model.SecuenciaPerdida)
	 */
	@Override
	public void actualizarSecuencia(SecuenciaPerdida secuenciaPerdida) {
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		secPerdidoDAO.update(secuenciaPerdida);

	}

	@Override
	public void actualizarSecException(SecuenciaPerdida secuenciaPerdida) {
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		secPerdidoDAO.updateException(secuenciaPerdida);

	}	

	@Override
	public void tomarSecuencia(SecuenciaPerdida secuenciaPerdida) {
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		secPerdidoDAO.updateTomado(secuenciaPerdida);

	}
	
	@Override
	public SecuenciaPerdida consultarSecuencia(SecuenciaPerdida secuenciaTmp){
		SecPerdidoDAO  secPerdidoDAO = fabricaDeServicios.getService("secPerdidoDAO");
		SecuenciaPerdida secuencia = null;
		List<SecuenciaPerdida> secuencias = secPerdidoDAO.find(secuenciaTmp);
		if(! CollectionUtils.isEmpty(secuencias)){
			secuencia = secuencias.get(0);
		}
		return secuencia;
	}

	/*
	public void setSecPerdidoDAO(SecPerdidoDAO secPerdidoDAO) {		
		this.secPerdidoDAO = secPerdidoDAO;
	}

	
	public void setSequenceDAO(SequenceDAO sequenceDAO) {
		this.sequenceDAO = sequenceDAO;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	
	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}

	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}
*/
}
