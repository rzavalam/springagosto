package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TabLibe;
import pe.gob.sunat.despaduanero.catalogo.tg.service.CodiLibeDAOService;
import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.Triblibe;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CodilibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExCodLibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TriblibeDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.model.bean.T1179Bean;
import pe.gob.sunat.servicio2.registro.model.dao.T1179DAO;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

/**
 * Clase que contiene los metodos comunes para cualquier tipo de preferencia arancelaria
 * incluye los Tratos Preferenciales Nacionales, Tratos Preferenciales Internacionales y
 * Codigos Liberatorios
 * @author rbegazo
 *
 */
public class PreferenciaArancelariaServiceImpl extends IngresoAbstractServiceImpl implements PreferenciaArancelariaService {
	//private FabricaDeServicios	fabricaDeServicios;


	/**
	 * Obtiene las preferencias arancelarias 
	 */
	public TabLibe obtenerPreferenciaArancelaria(String tipoliber, Integer codConvenio){		
		Map<String, Object> params=new HashMap<String, Object>();
//		TabLibeDAO tablibeDAO = fabricaDeServicios.getService("tablibeDAO");
		params.put("tlib", tipoliber);
		params.put("clib", codConvenio);
//		List<TabLibe> lsTabLibe = tablibeDAO.findTabLibeByParams(params);
		
		TabLibeDAOService tabLibeDAOService = fabricaDeServicios.getService("Ayuda.tabLibeService");
		List<TabLibe> lsTabLibe = tabLibeDAOService.findTabLibeByParams(params);
		
		TabLibe otablibe=null;
		if(!CollectionUtils.isEmpty(lsTabLibe))
			otablibe=lsTabLibe.get(0);
		return otablibe;
	}
	
	/**
	 * Obtiene la informaci�n de una determinada preferencia arancelaria, considerando una determinada fecha de vigencia
	 */
	public List<CodiLibe> obtenerPreferenciaArancelariaVigente(String tipoliber, Integer codConvenio, Date fechaReferencia){
		Map<String, Object> params = new HashMap<String, Object>();
//		CodilibeDAO codilibeDAO = fabricaDeServicios.getService("codilibeDAO");
		Integer fecvigencia = SunatDateUtils.getIntegerFromDate(fechaReferencia); 
		params.put("tlib", tipoliber);
		params.put("clib", codConvenio);
		params.put("fecvigencia", fecvigencia);
//    	List<CodiLibe> listcodilibe = codilibeDAO.findCodiLibeByParams(params);
    	
    	CodiLibeDAOService codiLibeDAOService = fabricaDeServicios.getService("Ayuda.codiLibeService");
		List<CodiLibe> listcodilibe = codiLibeDAOService.findCodiLibeByParams(params);
    	
    	return listcodilibe;
    }

	
	/**
	 * Permite obtener a los importadores que cuentan con preferencia arancelaria
	 * @param tipoliber
	 * @param codConvenio
	 * @param tipodocum
	 * @param numedocum
	 * @return
	 */
	public List<Triblibe> obtenerImporConPreferenciaArancelaria(String tipoliber, Integer codConvenio, String tipodocum, String numedocum,Integer fecha_nume){
		Map<String, Object> params=new HashMap<String, Object>();
		TriblibeDAO triblibeDAO = fabricaDeServicios.getService("triblibeDAO");
		params.put("tlib", tipoliber);
		params.put("clib", codConvenio);
		params.put("tdoc", tipodocum);
		params.put("clibtri", numedocum);
		// DZC: SAU20143N002000372 se valida con la fecha de numeraci�n.
		//params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
		params.put("fecvigencia", fecha_nume);
		return triblibeDAO.findTriblibeByParams(params);
	}
	
	/**
	 * Consulta si el importador corresponde a una zona altoandina, debe tener RUC
	 * teniendo los siguientes estados
	 * 00 : Definitiva
	 * 01 : Preliminar
	 * 02 : No Habido
	 * 03 : Baja
	 * 04 : Retienen y les retienen desde una fecha diferente
	 * @param tipodocum
	 * @param numedocum
	 * @return
	 */
	public T1179Bean consultarImportadorAltoAndino(String tipodocum, String numedocum){
		T1179DAO t1179DAO = fabricaDeServicios.getService("servicio.registro.model.t1179DAO");
		T1179Bean paramageret = new T1179Bean();		
		if (!tipodocum.equals(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC)){
			return null;
		}
		paramageret.setInd_proced("B");
		paramageret.setNum_ruc(numedocum);
		T1179Bean ageret = t1179DAO.findByPK(paramageret);
		return ageret;		
	}
	
	/**
	 * Verifica si tiene exoneraciones a las preferencias arancelarias
	 */
	public Boolean existExoneracionPreferenciaArancelaria(String tipoliber, Integer codConvenio, Long numpartnandi, Date fechaReferencia){
		Map<String, Object> params=new HashMap<String, Object>();
		ExCodLibDAO excodlibDAO = fabricaDeServicios.getService("excodlibDAO");
		Integer fecvigencia = SunatDateUtils.getIntegerFromDate(fechaReferencia); 
		params.put("tlib", tipoliber);
		params.put("clib", codConvenio);
		params.put("cnan",numpartnandi );
		params.put("fecvigencia",fecvigencia);
		List<Map<String, Object>> mpExcepciones = excodlibDAO.findExcepcionCodLibeByParam(params);
		return !CollectionUtils.isEmpty(mpExcepciones);
	}


	/**
	 * Obtiene el ubigeo de la direccion del Importador o consignatario del padron RUC
	 * @param tipodocum
	 * @param numedocum
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String consultarUbigeoImportadorPreferenciaArancelaria(String tipodocum, String numedocum){
		String ubigeoDuenoConsignatario = new String();
//		DdpDAO ddpDAO = fabricaDeServicios.getService("servicio.registro.model.ddpDAO");
		DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
		if (!tipodocum.equals(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC)){
			return ubigeoDuenoConsignatario;
		} 
		
		if(numedocum!=null && !numedocum.isEmpty()){			
//			Map ddpruc = ddpDAO.findByPK(numedocum);
			Map ddpruc = ddpDAOService.findByPK(numedocum);
			ubigeoDuenoConsignatario=ddpruc!=null?(String)ddpruc.get("ddp_ubigeo"):"";
		}
		return ubigeoDuenoConsignatario;
	}
	

	//Inicio - P46
	public boolean tienePreferencuaArancelaria (Integer codigoTPN, Integer codigoTPI){
		
		boolean tienePreferencia = false;
		
		if(codigoTPN != 0 || codigoTPI != 0){
			tienePreferencia = true;
		}
		
		return tienePreferencia;
	}

	/*
	//Fin - P46
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/

}
