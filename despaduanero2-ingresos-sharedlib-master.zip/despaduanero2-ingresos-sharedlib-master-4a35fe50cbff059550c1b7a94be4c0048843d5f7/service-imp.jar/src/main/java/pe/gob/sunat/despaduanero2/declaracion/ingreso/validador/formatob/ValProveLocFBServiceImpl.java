package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;




public class ValProveLocFBServiceImpl extends ValParticipanteFB implements ValProveLocFB{
	
		

	/**
	 * Valida obligatoriamente que haya transmitido el tipo de participante, que el dato declarado sea 91 de acuerdo al cat�logo 123.
	 * @param dav
	 * @return map
	 */
	public Map<String, String> codtipparticipante (DAV dav) {		
		if( SunatStringUtils.isEmpty(dav.getProveedorLocal().getTipoParticipante().getCodDatacat()) ||			
				(! "91".equals( dav.getProveedorLocal().getTipoParticipante().getCodDatacat())))
			return getErrorMap("30114", 
			        new Object[]{
			        dav.getNumsecuprov(), 
			        dav.getProveedorLocal().getTipoParticipante().getCodDatacat()!=null?dav.getProveedorLocal().getTipoParticipante().getCodDatacat():" "});
	
		Map<String, String> result = super.codtipparticipante(dav.getProveedorLocal().getTipoParticipante());
		
		if(result != null) 
		   result = getErrorMap("30114", new Object[]{
				   dav.getNumsecuprov(), 
				   dav.getProveedorLocal().getTipoParticipante().getCodDatacat()});
		
		return new HashMap<String, String>();
	}
	
	
	
	@Override
	public Map<String, String> codtipdocparticipante( DataCatalogo tipoDocumentoIdentidad)
	{
		Map<String, String> result = super.codtipdocparticipante(tipoDocumentoIdentidad);
		if(result != null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30129");
		}
		
		return result;
		 
	}
	
	/**
	 * Si envio en el segmento DUAs el campo codpropiedad con valor '02',
	 * validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos.
	 * Valida obligatoriamente que haya transmitido el tipo de documento del comprador inicial, el valor declarado corresponda al valor 4 (RUC) del cat�logo 27.
	 * @param dav
	 * @return map
	 */
	public Map<String, String> codtipdocparticipante(DAV dav){

        if ((dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat() == null)
                || !(dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat()
                        .equals(Constants.COD_DATA_CATALOG_TIPO_DOC_RUC)))

            return getErrorMap("05510", new Object[] { dav.getNumsecuprov(),
                    dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat()!=null?dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat():" "});

        
        Map<String, String> result = super.codtipdocparticipante(dav.getProveedorLocal().getTipoParticipante());
        if (result != null)
            result = getErrorMap("05510", new Object[] { dav.getNumsecuprov(),
                    dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat() });

        return new HashMap<String, String>();
    }

	/**
	 * Si envio en el segmento DUAs el campo codpropiedad con valor '02',
	 * validar que sea un dato n�merico de 11 d�gitos, adem�s si en
	 * 	se envio el valor '4' validar que exista en la
	 * tabla DECLARAN o de no estar en la tabla DDP
	 * 
	 * Valida obligatoriamente que haya transmitido el n�mero del documento del comprador inicial, 
	 * el valor declarado debe ser n�merico y de 11 d�gitos y que corresponda a un RUC registrado
	 * en el padr�n SUNAT. 
	 * @param dav
	 * @return map
	 */
	
	public List<Map<String, String>> numdocparticipante(DAV dav){

        List<Map<String, String>> result = new ArrayList<Map<String, String>>();

        if (dav.getProveedorLocal() == null || dav.getProveedorLocal().getNumeroDocumentoIdentidad() == null
                || !SunatStringUtils.isLengthEqualsToNumber(dav.getProveedorLocal().getNumeroDocumentoIdentidad(), 11)) {
            result.add(getErrorMap("30130", new Object[] { 
            		dav.getNumsecuprov(),
                    dav.getProveedorLocal().getNumeroDocumentoIdentidad()!=null?dav.getProveedorLocal().getNumeroDocumentoIdentidad():" " }));
        }

        if (SunatStringUtils.isEqualTo(dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat(), "4")) {
        	OperadorAyudaService operadorAyudaService = (OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService");
            //Map<String, Object> response = catalogoHelper.getOperadorAyudaService().getDeclarante(
        	Map<String, Object> response = operadorAyudaService.getDeclarante(
                    dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat(),
                    dav.getProveedorLocal().getNumeroDocumentoIdentidad());
            if (CollectionUtils.isEmpty(response))
                result.add(getErrorMap("30130", new Object[] { dav.getNumsecuprov(),
                        dav.getProveedorLocal().getNumeroDocumentoIdentidad()!=null?dav.getProveedorLocal().getNumeroDocumentoIdentidad():" " }));
        }

        return result;
    }

	/**
	 * Si envio en el segmento DUAs el campo codpropiedad con valor '02',
	 * validar que se un dato car�cter de longitud mayor a 5
	 * 
	 * Valida obligatoriamente que haya transmitido la raz�n social del comprador inicial,
	 * el dato declarado debe estar registrado en el padr�n SUNAT y corresponder al n�mero de RUC declarado. 
	 * @param dav
	 * @return map
	 */
		
    public List<Map<String, String>> nomparticipante(DAV dav){

        List<Map<String, String>> result = new ArrayList<Map<String,String>>();

        if (dav.getProveedorLocal() == null || StringUtils.isEmpty(dav.getProveedorLocal().getNombreRazonSocial())
        		|| SunatStringUtils.isLengthLessThanNumber(dav.getProveedorLocal().getNombreRazonSocial(), 5)) {
            result.add(getErrorMap("30131",	new Object[]	{ dav.getNumsecuprov(),
                    				dav.getProveedorLocal().getNombreRazonSocial()!=null?dav.getProveedorLocal().getNombreRazonSocial():" "}));
            return result;
        }        
        OperadorAyudaService operadorAyudaService = (OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService");
        //Map<String, Object> response = catalogoHelper.getOperadorAyudaService().getDeclarante(
        Map<String, Object> response = operadorAyudaService.getDeclarante(
                dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat(),
                dav.getProveedorLocal().getNumeroDocumentoIdentidad());

        if (CollectionUtils.isEmpty(response)
                || 
                !SunatStringUtils.isEqualTo(SunatStringUtils.substring((String)response.get("nombre"),0,60).trim(), 
                		dav.getProveedorLocal().getNombreRazonSocial().trim()))                
                //gmontoya 2015 Pase 425// PASE451 arey

		{
            result.add(getErrorMap("30131", new Object[] { dav.getNumsecuprov(),
                    dav.getProveedorLocal().getNombreRazonSocial().trim()!=null?dav.getProveedorLocal().getNombreRazonSocial().trim():" "}));
		}
		return result;

	}
}