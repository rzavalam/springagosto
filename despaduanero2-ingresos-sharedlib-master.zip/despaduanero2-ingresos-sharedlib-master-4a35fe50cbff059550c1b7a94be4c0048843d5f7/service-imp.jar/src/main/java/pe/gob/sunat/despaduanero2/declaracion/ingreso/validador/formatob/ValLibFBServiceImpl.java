package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPosicion;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValLibFBServiceImpl extends  ValDuaAbstract implements ValLibFB{

	private static Integer fechIngSi = SunatNumberUtils.getTodayAsInteger();
	//protected final Log log = LogFactory.getLog(getClass());
	
	String vProcesar = "S";
	String swCetico = "N";
	String codigoAduana = "";
	String mUnidMercd = "";
	String mNombComer = "";
	String mMarcComer = "";
	String mModeComer = "";	
	String mModeMercd = "";
	String mCaraTipo = "";
	String mClasVari = "";
	String mUsoAplic = "";
	String mMatCompo = "";
	String mDescCom1 = "";
	String mDescCom2 = "";
	String mDescCom3 = "";
	String mAroAno = "";
	String mTobsItem = "";
	String mPartNandi = "";
	String mEstaMercd = "";
	String mPaisOrigen = "";
	String mCate = "";
	String mSubCat = "";
	String wClase = "";
	String mSN = "";
	String nAS = "";
	String nPB = "";
	String nPN = "";
	String mCH = "";
	String mVI = "";
	String mEX = "";
	String mEncend = "";
	String mCarro = "";
	String vTipo = "";
	String vTipFi = "";
	
	Integer pFechEmbar = 0;		
	String pCodRegPre ="";
	Integer pFechLlega = 0;
	Integer gnCnt=0;
	String gcCuero = "CUR";
	String wruc = "";
	String wclib = "";
	
	String mCodiRegi = "";
	Integer nyear = SunatNumberUtils.getCurrentYear();
	// SUBSTR(LPAD(A_CADENA(mPART_NANDI),10,'0'),1,4)
	String gcCapitulo = SunatStringUtils.substringFox(SunatStringUtils.lpad(mPartNandi.toString(), 10, '0') , 1, 4);
	
	Integer vFechIngsi = SunatNumberUtils.getTodayAsInteger();
	String vRevisa1 = " ";
	String tipoTrat ;
	Integer gnNewVal1 = 0;
	Integer gnNewVal2 = 0;
	Integer gnVecesVal = 0;
	String lcCodigoComp="";
	Integer lPartidaSoftware = 0;
	Integer xRespuesta=0;
	String marchivo="XML";	

	String vNomCo = "";
	String gTipoDescMin = "**";
	/**
  		String pTipo, 	//	: Tipo de tabla en el TABLNEW
		String pCodigo, //	: C�digo a validar
		String pError, 	//	: C�digo de rechazo
		String pTable, 	//	: Tabla en la cual validar
		String pArchivo, //	: Informaci�n que se est� validando
		String pColumn, 	//	: Nombre del campo a validar
		String tMensaje 	//	: Mensaje de error
	 */	
	public List<Map<String, String>> valDescMin(
		String pTipoRela) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
	    List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

	    String lcValorCampo = "";
	    String lcValorCampoRel = "";
	    String lcDato = "";
	    Integer lcLongMinima = 2;
	    //String lcValidTabla = "0";
	    Integer lnLongMax;	

	    if(gnNewVal1 == 1)
		gcCuero = "CUN";

	    List<DetPosicion> listaPos = funcionesService.getListaPosiciones(pTipoRela,codigoAduana);

	    for (DetPosicion c : listaPos) {


	    if(log.isDebugEnabled())log.debug("==> Descripcion Minima<==");
	    if(log.isDebugEnabled())log.debug("==> pTipoRela<==" + pTipoRela);
	    if(log.isDebugEnabled())log.debug("==> c.getCnombCamp()<==" + c.getCnombCamp());


		if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "UNID_MERCD") )
		    lcValorCampo = mUnidMercd;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "NOMB_COMER") )
		    lcValorCampo  = mNombComer;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "MODE_MERCD") )
		{
		    lcValorCampo  = mModeMercd;
		    lcLongMinima = 2;
		}
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "MARC_COMER") )
		{
		    lcValorCampo  = mMarcComer;
		    lcLongMinima = 2;
		}
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "CARA_TIPO") )
		    lcValorCampo  = mCaraTipo;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "CLAS_VARI") )
		    lcValorCampo  = mClasVari;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "MAT_COMPO") )
		    lcValorCampo  = mMatCompo;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "USO_APLIC") )
		    lcValorCampo  = mUsoAplic;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "ARO_ANO") )
		    lcValorCampo  = mAroAno;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "TOBS_ITEM") )
		    lcValorCampo  = mTobsItem;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "DESC_COM1") )
		    lcValorCampo  = mDescCom1;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "DESC_COM2") )
		    lcValorCampo  = mDescCom2;
		else if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "DESC_COM3") )
		    lcValorCampo  = mDescCom3;

		lcDato = SunatStringUtils.substringFox(lcValorCampo,  c.getNposcCodi(), c.getNlongCodi() );

		if( SunatStringUtils.isEqualTo(pTipoRela, "K9") )
		{

		    if ( SunatStringUtils.isEmpty(mAroAno) )
			mAroAno = "0";

		    if ( SunatStringUtils.isEmpty(mSN) )
			mSN = "2";

		    if ( SunatStringUtils.isEmpty(nAS) )
			nAS = "0";

		    if ( SunatStringUtils.isEmpty(nPB) )
			nPB = "0";

		    if ( SunatStringUtils.isEmpty(nPN) )
			nPB = "0";

		    /**
		     * SpVal_Vehiculos (SIN_ESPACIOS(LcDato), C.CTIPO_DESC,
		     * C.CTIPO_FORM, C.NPOSC_CODI, C.NLONG_CODI,
		     * C.CNOMB_CAMP+':'+C.CDESC_MERC, C.CTIPO_ERROR, C.CTIPO_DATO,
		     * C.CTIPO_OBS, C.NPOSC_DECI, C.NPOSC_ENTE, C.CONDI_OPCI,
		     * C.CONDI_VALI, lcValor_Campo, c.nPosc_Otro, c.nLong_Otro
		     * ,c.cCod_Otros, pTipoRela )
		     */
		    listErr.addAll( 				
			    valVehiculo(SunatStringUtils.trim(lcDato), c.getCtipoDesc(), c.getCtipoForm(), c.getNposcCodi(), 
				    c.getNlongCodi(), c.getCnombCamp()+":"+c.getCdescMerc(), c.getCtipoError(), c.getCtipoDato(), 
				    c.getCtipoObs(), c.getNposcDeci(), c.getNposcEnte(), c.getCondiOpci(), c.getCondiVali(), 
				    lcValorCampo, c.getNposcOtro(), c.getNlongOtro(), c.getCodOtros(), pTipoRela)
			    );


		}else{

		    //invoke SpValTipoDato
		    ParamValTipoDato param = new ParamValTipoDato();
		    param.setTcValCampo(lcDato);
		    param.setTcTipoDato(c.getCtipoDato());
		    param.setTcTipoObs( c.getCtipoObs() );
		    param.setTcCodiError( c.getCtipoError());
		    param.setTcNombCampo( c.getCnombCamp()+":"+c.getCdescMerc() );
		    param.setTcTipoForm(c.getCtipoForm());
		    param.setTTipoRela(pTipoRela);
		    param.setTnPoscDec( c.getNposcDeci() );
		    param.setTnPoscEnte(c.getNposcEnte());
		    param.setTMensaje(" EN LAS "+ c.getNlongCodi() +" POSICIONES A PARTIR DE "+ c.getNposcCodi());

		    listErr.addAll( valTipoDato(param) );

		    /**
		     * 2. SpValTabla( lcValor_Campo, c.nPosc_Otro, c.nLong_Otro,
		     * c.cTipo_error, C.CNOMB_CAMP+':'+C.CDESC_MERC, c.cTipo_Desc,
		     * LcDato, c.cTipo_obs, c.cCod_Otros, C.cTipo_Dato, ' EN LAS '+
		     * A_CADENA(c.nLong_Codi) +' POSICIONES A PARTIR DE '+ A_CADENA(
		     * c.nPosc_Codi ), pTipoRela )
		     */
		    ParamValTabla param2 = new ParamValTabla();

		    param2.setTcValCampo( lcValorCampo );
		    param2.setTnPosResto( c.getNposcOtro() );
		    param2.setTnCantResto( c.getNlongOtro() );
		    param2.setTcCodiError( c.getCtipoError() );
		    param2.setTcNombCampo( c.getCnombCamp()+":"+ c.getCdescMerc());
		    param2.setTcTipoTabl( c.getCtipoDesc() );
		    param2.setTcValCampo(lcDato);
		    param2.setTcTipoObs(c.getCtipoObs());
		    param2.setTcCodOtros( c.getCodOtros() );
		    param2.setTcTipoDato( c.getCtipoDato() );
		    param2.setTMensaje( " EN LAS " + c.getNlongCodi() +" POSICIONES A PARTIR DE "+ c.getNposcCodi() );
		    param2.setTcTipoMerc(pTipoRela);

		    listErr.addAll( valTabla(param2) );

		    lnLongMax = funcionesService.getLongitudMaxima( pTipoRela,c.getCnombCamp(), codigoAduana );

		    if( SunatNumberUtils.isGreaterThanZero(lnLongMax) 
			    && c.getNposcOtro() + c.getNlongOtro() == lnLongMax )
		    {
			if( ! SunatStringUtils.isEmptyTrim( SunatStringUtils.substring(lcValorCampo, lnLongMax)  ) )
			{
			    if ( c.getNlongCodi() > 0 )
				listErr.add( getErrorMap("5719", new Object[]{c.getCnombCamp(), lnLongMax, SunatStringUtils.substring(lcValorCampo, lnLongMax) }) );
			    else
				listErr.add( getErrorMap("5740", new Object[]{c.getCnombCamp(), lnLongMax, SunatStringUtils.substring(lcValorCampo, lnLongMax) }) );

			}
		    }

		    //10.	Otras validaciones por tipo de Producto 
		    if( SunatStringUtils.isStringInList(pTipoRela, "KA, KB, KC") ) //(Desc.  Min. de Cierres)
		    {
			ParamValCierre paramValCierre = new ParamValCierre();

			paramValCierre.setTcValor(lcDato);
			paramValCierre.setTnPosInicial(c.getNposcCodi());
			paramValCierre.setTnCantDig(c.getNlongCodi());
			paramValCierre.setTcNombCampo(c.getCnombCamp()+":"+c.getCdescMerc());
			paramValCierre.setTcCodiError(c.getCtipoError());
			paramValCierre.setTcNomTabla(c.getCtipoDesc());
			paramValCierre.setTcLongMinima(lcLongMinima);
			paramValCierre.setTcValorCampo( lcValorCampo);
			paramValCierre.setTcCampo(  c.getCnombCamp() );
			paramValCierre.setTtipoRela(pTipoRela);
			paramValCierre.setTcValorCampoRel( lcValorCampoRel );					

			valCierre(paramValCierre);

		    }else if( SunatStringUtils.isStringInList(pTipoRela, "KD, KE, KF, KG") ){ //(Desc.  Min. de Calzado)

			//Invoke SPVal_Calzado					
			ParamValCalzado paramValCalzado = new ParamValCalzado();
			paramValCalzado.setTcValor(lcDato);
			paramValCalzado.setTnPosInicial(c.getNposcCodi());
			paramValCalzado.setTcNombCampo(c.getCnombCamp()+":"+c.getCdescMerc());
			paramValCalzado.setTcCodiError(c.getCtipoError());
			paramValCalzado.setTcLongMinima( lcLongMinima );
			paramValCalzado.setTcValorCampo(lcValorCampo);
			paramValCalzado.setTcCampo(c.getCnombCamp());
			paramValCalzado.setTtipoRela(pTipoRela);
			paramValCalzado.setTcValorCampoRel(lcValorCampoRel);
			paramValCalzado.setTcCondOpci(c.getCondiOpci());
			paramValCalzado.setTcCondVali(c.getCondiVali());
			paramValCalzado.setTcTipoObs(c.getCtipoObs());

			listErr.addAll(  valCalzado(paramValCalzado) );

			Integer indexSbstr = SunatStringUtils.length(lcValorCampo) >=  56? 56: SunatStringUtils.length(lcValorCampo) ; //52+4

			if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "CARA_TIPO") 
				&& SunatStringUtils.isStringInList( SunatStringUtils.substringFox(lcValorCampo, 1, 3), "CUN,"+gcCuero+",CAU,PLA,TEX") 
				&& SunatStringUtils.isEmpty( SunatStringUtils.substringFox(lcValorCampo, 4, indexSbstr) ))
			{
			    listErr.add( getErrorMap("5721", new Object[]{SunatStringUtils.substringFox(lcValorCampo, 1, 3)}) );
			}

		    }else if( SunatStringUtils.isStringInList(pTipoRela, "KH, KI, KL,KM, KN, KO ") ){ //(Desc.  Min. de Lentes)
			if(SunatStringUtils.isEqualTo(pTipoRela, "KI")
				&& SunatStringUtils.isEqualTo(c.getCnombCamp(), "CLAS_VARI"))
			    lcValorCampoRel = mMatCompo;

			// c. SPVal_Lentes (LcDato, C.NPOSC_CODI, C.NLONG_CODI,
			// C.CNOMB_CAMP +':'+ C.CDESC_MERC, c.ctipo_error,
			// c.cTipo_Desc , LcLong_Minima, LcValor_Campo,
			// C.CNOMB_CAMP, pTipoRela, LcValor_campoRel )
			listErr.addAll( 
				valLentes(lcDato, c.getNposcCodi(), c.getNlongCodi(), c.getCnombCamp()+":"+c.getCdescMerc(), 
					c.getCtipoError(), c.getCtipoDesc(), lcLongMinima.toString(), lcValorCampo, c.getCnombCamp(), 
					pTipoRela, lcValorCampoRel)
				);

		    }else if( SunatStringUtils.isStringInList(pTipoRela, "KP, KR") ){ //(Desc.  Min. de Telas Pl�sticas)
			if(SunatStringUtils.isEqualTo(pTipoRela, "KP")
				&& SunatStringUtils.isEqualTo(c.getCnombCamp(), "CLAS_VARI"))
			    lcValorCampoRel = mCaraTipo;
			else if(SunatStringUtils.isEqualTo(pTipoRela, "KR")
				&& SunatStringUtils.isEqualTo(c.getCnombCamp(), "MAT_COMPO"))
			    lcValorCampoRel = mCaraTipo;
			else lcValorCampoRel = "";

			// e. SpVal_TelasPlastificadas (LcDato,C.NPOSC_CODI,
			// C.CNOMB_CAMP +':'+ C.CDESC_MERC, c.ctipo_error,
			// LcValor_Campo, C.CNOMB_CAMP, pTipoRela, LcValor_campoRel
			// )
			listErr.addAll(
				valTelasPlast(lcDato, c.getNposcCodi(), c.getCnombCamp()+":"+c.getCdescMerc(), c.getCtipoError(), 
					lcValorCampo, c.getCnombCamp(), pTipoRela, lcValorCampoRel)
				);

		    }else if( SunatStringUtils.isEqualTo(pTipoRela, "KQ") ){ //(Desc.  Min. de Neum�ticos)
			if( SunatStringUtils.isEqualTo(c.getCtipoError(), "5761")
				&& SunatStringUtils.isEqualTo(c.getCnombCamp(), "CARA_TIPO"))
			    lcValorCampoRel = lcDato;
			//c.	SPVal_Neumatico(LcDato, C.NPOSC_CODI, C.NLONG_CODI, C.CNOMB_CAMP +':'+ C.CDESC_MERC, c.ctipo_error,  LcValor_campoRel )

			listErr.addAll(					
				valNeumatico(lcDato, c.getNposcCodi(), c.getNlongCodi(),  c.getCnombCamp()+":"+c.getCdescMerc(), 
					c.getCtipoError(), lcValorCampoRel) 
				);

		    }else if( SunatStringUtils.isEqualTo(pTipoRela, "KV") ){ //(Desc.  Min. de Ojalillos)

			//a. SpVal_Ojalillos (LcDato, C.NPOSC_CODI, C.NLONG_CODI, C.CNOMB_CAMP +':'+ C.CDESC_MERC, c.ctipo_error)
			valOjalillos(lcDato, c.getNposcCodi(), c.getNlongCodi(),  c.getCnombCamp()+":"+c.getCdescMerc(), c.getCtipoError());

		    }else if( SunatStringUtils.isEqualTo(gTipoDescMin, "CC") ){ //(Des. Min. de CDs y DVDs. )
			//SpVal_CDs (LcDato, C.NPOSC_CODI, C.NLONG_CODI, C.CNOMB_CAMP +':'+ C.CDESC_MERC, C.CTIPO_ERROR, C.CTIPO_DATO, C.CTIPO_OBS, C.CONDI_OPCI, C.CONDI_VALI)
			listErr.addAll(
				valCds(lcDato, c.getNposcCodi(), c.getNlongCodi(),  c.getCnombCamp()+":"+c.getCdescMerc(), c.getCtipoError(), 
					c.getCtipoDato(), c.getCtipoObs(), c.getCondiOpci(), c.getCondiVali())
				);
		    }else if( SunatStringUtils.isEqualTo(gTipoDescMin, "TX") ){ //(Des. Min. de Textiles - Nuevas Validaciones)
			//a.	SpVal_Textil_Condicion (LcDato, C.CTIPO_DESC, C.NPOSC_CODI, C.NLONG_CODI, 
			//b.	C.CNOMB_CAMP +':'+ C.CDESC_MERC, C.CTIPO_ERROR, C.CONDI_OPCI, C.CONDI_VALI)
			listErr.addAll(
				valTextil(lcDato, c.getCtipoDesc(), c.getNposcCodi(), c.getNlongCodi(), c.getCnombCamp() + ":" + c.getCdescMerc(), c
					.getCtipoError(), c.getCondiOpci(), c.getCondiVali())
				);
		    }else if( SunatStringUtils.isEqualTo(gTipoDescMin, "ME") ){ //(Des. Min. de Medicamentos)
			if( SunatStringUtils.isEqualTo(c.getCnombCamp(), "MODE_MERCD") ) //(Para que se ejecute una solo vez)
			{
			    //SPVeriError( '1M', mUNID_MERCD, '1173', 'TAB_DESC_MIN', marchivo, 'UNID_MERCD ENVIADO ', ' EN LAS '+ A_CADENA(c.nLong_Codi) +' POSICIONES A PARTIR DE '+ A_CADENA( c.nPosc_Codi ) )
			    listErr.addAll(
				    valError("1M", mUnidMercd, "1173", "TAB_DESC_MIN", marchivo, "UNID_MERCD ENVIADO ", " EN LAS " + c.getNlongCodi()
					    + " POSICIONES A PARTIR DE " + c.getNposcCodi())
				    );
			}
			//c.	SPVal_Medicamento (LcDato, C.NPOSC_CODI, C.NLONG_CODI, C.CNOMB_CAMP +':'+ C.CDESC_MERC, c.ctipo_error, 
			// 		LcLong_Minima, LcValor_Campo, C.CNOMB_CAMP, pTipoRela, LcValor_campoRel, 	c.condi_opci, c.condi_vali, c.cTipo_obs)
			listErr.add(
				valMedicamento(lcDato,c.getNposcCodi(), c.getNlongCodi(), c.getCnombCamp() + ":" + c.getCdescMerc(), c
					.getCtipoError(), lcLongMinima.toString(), lcValorCampo, c.getCnombCamp(), pTipoRela, lcValorCampoRel, c.getCondiOpci(), c.getCondiVali(), c.getCtipoObs())
				);
		    }			
		}
	    }

	    if( SunatStringUtils.isStringInList(pTipoRela, "KA,KB,KC") ) //(Desc. M�nimas de Cierres y sus partes)
		//SpDesCierre (pTipoRela)
		listErr.addAll( valDesCierre(pTipoRela) ) ;
	    else if( SunatStringUtils.isStringInList(pTipoRela, "KU,KV") ){
		if( SunatStringUtils.isEqualTo(pTipoRela, "KU	") ) //(Desc.  Min. de Pilas y bater�as de pilas.)

		    listErr.addAll( valPilas() );

		else{
		    if( SunatStringUtils.isStringInList(mPartNandi, "8308100010, 8308101100") 
			    && ! SunatStringUtils.isEqualTo(mClasVari, "HIE"))
			listErr.add( getErrorMap("1161", new Object[]{ mPartNandi }) );

		    if( SunatStringUtils.isStringInList(mPartNandi, "8308100020, 8308101200") 
			    && ! SunatStringUtils.isEqualTo(mClasVari, "ALU"))
			listErr.add( getErrorMap("1161", new Object[]{ mPartNandi }) );				

		    if( SunatStringUtils.isStringInList(mPartNandi, "8308100090, 8308101900, 8308109000") 
			    && ! SunatStringUtils.isStringInList(mClasVari, "HIE, ALU"))
			listErr.add( getErrorMap("1161", new Object[]{ mPartNandi }) );

		}
	    }else if( SunatStringUtils.isEqualTo(gTipoDescMin, "CM") ){ // (Desc.  Min. de Computadoras)
		//SpVal_Computadoras			
		listErr.addAll( valComputadoras() ) ;
	    }else if( SunatStringUtils.isEqualTo(gTipoDescMin, "TX") ){ // (Desc.  Min. de Textiles � �ltimas validaciones)
		//SpVal_Textil_Final (pTipoRela)
		listErr.addAll( valTextilFinal(pTipoRela) );

	    }else if( SunatStringUtils.isEqualTo(pTipoRela, "K9") ){ // (Validaciones cruzadas)
		//i.	Se valida correcta correlaci�n entre Categor�a, Marca, Modelo y Carrocer�a 
		if( fechIngSi > 20040128 ){ //(fecha real de vigencia de las descripciones m�nimas para veh�culos)
		    //TODO Validar esto
		    if( !funcionesService.existsVehiculo(mCate, mSubCat, mMarcComer,"","",fechIngSi) ) {
			listErr.add( getErrorMap("1274", new Object[]{ mSubCat, mMarcComer }) );
		    }else{
			if( !funcionesService.existsVehiculo(mCate, mSubCat, mMarcComer, mModeMercd, "", fechIngSi) ) {
			    listErr.add( getErrorMap("1275", new Object[]{ mCate, mSubCat, mMarcComer, mModeMercd }) );
			}else {
			    if( !funcionesService.existsVehiculo(mCate, mSubCat, mMarcComer, mModeMercd, mCaraTipo, fechIngSi) ) {
				listErr.add( getErrorMap("1240", new Object[]{ mCate, mSubCat, mMarcComer, mModeMercd, mCaraTipo }) );
			    }
			}
		    }
		}

		if( ! SunatStringUtils.isEmptyTrim(mEX)){
		    if (mEX.equals("01") && pFechEmbar > 20021122 )					
			listErr.add( getErrorMap("5772", "CLAS_VARI 01 solo puede enviarse para mercancias embarcadas hasta el 22/11/2002") );
		    else if (mEX.equals("01") && pCodRegPre.equals("91"))
			listErr.add( getErrorMap("5772", "CLAS_VARI Envio 01 cuando le corresponde 02") );
		    else if (mEX.equals("02") && !pCodRegPre.equals("91"))
			listErr.add( getErrorMap("5772", "CLAS_VARI NO COINCIDE CON REGIMEN DE PRECEDENCIA(solo REG 91)") );
		}

		//iv.	Se valida C�d. Exoneraci�n VIN
		if( ! SunatStringUtils.isEmptyTrim(mEX)  && ! SunatStringUtils.isEmptyTrim(mVI))
		    listErr.add( catalogoAyudaService.getError("1261") );
		else if( ! SunatStringUtils.isEmptyTrim(mCH) && SunatStringUtils.isEmptyTrim(mVI) && SunatStringUtils.isEmptyTrim(mEX) )
		    listErr.add( catalogoAyudaService.getError("5772") ); 
		else if( SunatStringUtils.isEmptyTrim(mCH)  && SunatStringUtils.isEmptyTrim(mVI) )
		    listErr.add( catalogoAyudaService.getError("1260") );
	    }

	    return listErr;
	}
	

	
	public List<Map<String, String>> valNombCom() {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		List<DatoDescrMinima> lisdescmin = funcionesService.getCodigosInTabDescMinByGrupoAndTipo("YY","01");
		for (DatoDescrMinima descminima : lisdescmin) {
			
			String lcCodigoComp = funcionesService.getCodigoInTabDescMinByTipoAndDescri(descminima.getCodtipdescr(), mNombComer);
			if(! SunatStringUtils.isEmpty(lcCodigoComp) )
			{
				String cTipoMerc = funcionesService.fnTipo(mPartNandi, lcCodigoComp, mCaraTipo, fechIngSi);
				if( SunatStringUtils.isEqualTo(cTipoMerc, "**") )
				{
					//a.	InsTelelog('1189',marchivo+'NOMB_COMER'+' VALOR ENVIADO: '+mNomb_Comer+' DEBIO ENVIAR CODIGO: '+lcCodigoComp)
					listErr.add( getErrorMap("1189", new Object[]{marchivo,mNombComer, lcCodigoComp }) );
				}
			}
		}
		
		if( funcionesService.existsInRefPartidasByTipoUsoAndPartNandiAndRef("DVA", mPartNandi) 
				&& SunatStringUtils.hasMismosCaracteres(mNombComer) ){
			//i.	InsTelelog('5741',marchivo+'NOMB_COMER'+' VALOR ENVIADO: '+mNomb_Comer) 
			listErr.add( getErrorMap("5741", new Object[]{marchivo,mNombComer}) );
		}
		
		return listErr;
	}

	class ParamValTabla{
		String tcValCampo; 	//: Valor del campos de d�nde obtener el dato a validar
		Integer tnPosResto; 	// Posici�n del dato �Otro�
		Integer tnCantResto; 	// Longitud del dato �Otro�
		String tcCodiError; 	// C�digo de error
		String tcNombCampo; 	// Nombre del campo
		String tcTipoTabl; 	// Tipo de tabla en donde validar el dato
		String tcDato; 	// Dato
		String tcTipoObs; 	// Tipo de observaci�n
		String tcCodOtros; 	// C�digo que indica que es �Otro�
		String tcTipoDato; 	// Tipo de dato
		String tMensaje; 	// Mensaje de error
		String tcTipoMerc; 	// Tipo de descripciones m�nimas
		public String getTcValCampo() {
			return tcValCampo;
		}
		public void setTcValCampo(String tcValCampo) {
			this.tcValCampo = tcValCampo;
		}
		public Integer getTnPosResto() {
			return tnPosResto;
		}
		public void setTnPosResto(Integer tnPosResto) {
			this.tnPosResto = tnPosResto;
		}
		public Integer getTnCantResto() {
			return tnCantResto;
		}
		public void setTnCantResto(Integer tnCantResto) {
			this.tnCantResto = tnCantResto;
		}
		public String getTcCodiError() {
			return tcCodiError;
		}
		public void setTcCodiError(String tcCodiError) {
			this.tcCodiError = tcCodiError;
		}
		public String getTcNombCampo() {
			return tcNombCampo;
		}
		public void setTcNombCampo(String tcNombCampo) {
			this.tcNombCampo = tcNombCampo;
		}
		public String getTcTipoTabl() {
			return tcTipoTabl;
		}
		public void setTcTipoTabl(String tcTipoTabl) {
			this.tcTipoTabl = tcTipoTabl;
		}
		public String getTcDato() {
			return tcDato;
		}
		public void setTcDato(String tcDato) {
			this.tcDato = tcDato;
		}
		public String getTcTipoObs() {
			return tcTipoObs;
		}
		public void setTcTipoObs(String tcTipoObs) {
			this.tcTipoObs = tcTipoObs;
		}
		public String getTcCodOtros() {
			return tcCodOtros;
		}
		public void setTcCodOtros(String tcCodOtros) {
			this.tcCodOtros = tcCodOtros;
		}
		public String getTcTipoDato() {
			return tcTipoDato;
		}
		public void setTcTipoDato(String tcTipoDato) {
			this.tcTipoDato = tcTipoDato;
		}
		public String getTMensaje() {
			return tMensaje;
		}
		public void setTMensaje(String mensaje) {
			tMensaje = mensaje;
		}
		public String getTcTipoMerc() {
			return tcTipoMerc;
		}
		public void setTcTipoMerc(String tcTipoMerc) {
			this.tcTipoMerc = tcTipoMerc;
		}
		
	}
	
	private List<Map<String, String>>  valTabla(ParamValTabla param) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();		
		
		String lcDescZZZ = "";
		
		if( SunatNumberUtils.isEqual(param.getTnPosResto(), new Integer(0)) )
		{
			lcDescZZZ = SunatStringUtils.substringFox(param.getTcValCampo(), param.getTnPosResto(), param.getTnCantResto() );
		}
		
		if( ! SunatStringUtils.isEmpty(param.getTcTipoTabl()) )
		{
			if( SunatStringUtils.isEqualTo(param.getTcTipoObs(), "M")
					|| ( SunatStringUtils.isEqualTo(param.getTcTipoObs(), "C")
							&& ! SunatStringUtils.isEmpty(param.getTcDato())) )
			{
				if( SunatStringUtils.isEqualTo(param.getTcTipoMerc(), "K9") )
					//Busca en la tabla TABLNEW
					//SPVeriError( TcTipo_Tabl,SIN_ESPACIOS(TcDato),TcCodi_error,'TABLNEW',marchivo, TcNomb_Campo+' Enviado ', tMensaje )
					listErr.addAll(
							valError(param.getTcTipoTabl(), param.getTcDato(), param.getTcCodiError(), "TABLNEW", marchivo, param.getTcNombCampo()+" Enviado ", param.getTMensaje())
					);
				else
					//a.	Busca en la tabla TAB_DESC_MIN
					//b.	SPVeriError( TcTipo_Tabl,SIN_ESPACIOS(TcDato),TcCodi_error,'TAB_DESC_MIN',marchivo, TcNomb_Campo+' ENVIADO ', tMensaje )
					listErr.addAll(
							valError(param.getTcTipoTabl(), param.getTcDato(), param.getTcCodiError(), "TAB_DESC_MIN", marchivo, param.getTcNombCampo()+" Enviado ", param.getTMensaje())
					);

			}
			
			if( SunatStringUtils.isEqualTo(param.getTcDato(), param.getTcCodOtros()) )
			{
				if( SunatStringUtils.isEmpty(lcDescZZZ) )
					listErr.add( catalogoAyudaService.getError("5681") );
				
				else{
					//a.	Se valida que no declaren un c�digo existente u cualquier cosa. 
					//b.	SpVeriOtros(TcTipo_Tabl, LcDesc_ZZZ, TcCodi_error, TcNomb_Campo)
					ParamValOtros paramValOtros = new ParamValOtros();
					paramValOtros.setTcTipoTabla( param.getTcTipoTabl() );
					paramValOtros.setTcDescOtro(lcDescZZZ);
					paramValOtros.setTcError( param.getTcCodiError() );
					paramValOtros.setTcNomCampo( param.getTcNombCampo() );
					
					listErr.addAll( valOtros( paramValOtros ) );
				}

			}else if( ! SunatStringUtils.isEqualTo(SunatStringUtils.trim(param.getTcDato()), param.getTcCodOtros())
						&& ! SunatStringUtils.isEmpty(lcDescZZZ)) {				
				listErr.add( catalogoAyudaService.getError("5689") );
			}
		}else{
			
			if( SunatStringUtils.isEqualTo(param.getTcTipoObs(), "M")
					&& SunatStringUtils.trim(param.getTcDato()) == null
					&& SunatStringUtils.isEqualTo(param.getTcTipoDato(), "NUMBER") )
				listErr.add( catalogoAyudaService.getError( param.getTcCodiError() ) );
		}
		
		return listErr;
	}

	class ParamValOtros{
		String tcTipoTabla; // 	: Tipos de tabla donde verificar la informaci�n
		String tcDescOtro; // 	: Descripci�n de �Otro�
		String tcError; // 	: C�digo de error
		String tcNomCampo; // 	: Nombre del campo
		
		public String getTcTipoTabla() {
			return tcTipoTabla;
		}
		public void setTcTipoTabla(String tcTipoTabla) {
			this.tcTipoTabla = tcTipoTabla;
		}
		public String getTcDescOtro() {
			return tcDescOtro;
		}
		public void setTcDescOtro(String tcDescOtro) {
			this.tcDescOtro = tcDescOtro;
		}
		public String getTcError() {
			return tcError;
		}
		public void setTcError(String tcError) {
			this.tcError = tcError;
		}
		public String getTcNomCampo() {
			return tcNomCampo;
		}
		public void setTcNomCampo(String tcNomCampo) {
			this.tcNomCampo = tcNomCampo;
		}
		
	}
	
	private List<Map<String, String>> valOtros(ParamValOtros param) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();

		Integer inCant = funcionesService.getCountFromTabDescMin(param.getTcTipoTabla(), param.getTcDescOtro());
		
		if(inCant >= 0 )		
			listErr.add( catalogoAyudaService.getError( param.getTcError() ) );
		
		String listaPosibleOtro = "OTRO, OTROS, N.A, NA";
		
		if( listaPosibleOtro.indexOf(param.getTcDescOtro()) != -1
				|| SunatStringUtils.length(param.getTcDescOtro()) < 3 
				|| SunatStringUtils.hasMismosCaracteres(param.getTcDescOtro()))
		{
			listErr.add( catalogoAyudaService.getError( "5681" ) );
		}
		
		if( SunatStringUtils.isEqualTo(param.getTcTipoTabla(), "Z5")
				|| SunatStringUtils.isEqualTo(param.getTcTipoTabla(), "Z6") )
		{
			if(SunatStringUtils.isEqualTo(param.getTcTipoTabla(), "Z5")
					&&  (SunatStringUtils.isEqualTo(param.getTcDescOtro(), "PLASTICO") || SunatStringUtils.isEqualTo(param.getTcDescOtro(), "CAUCHO")
							) )
				listErr.add( catalogoAyudaService.getError( param.getTcError() ) );

			if(SunatStringUtils.isEqualTo(param.getTcTipoTabla(), "Z6")
					&&  SunatStringUtils.isEqualTo(param.getTcDescOtro(), "TEXTIL") 
							 )
				listErr.add( catalogoAyudaService.getError( param.getTcError() ) );
		}
		
		return listErr;
	}
	
	private List<Map<String, String>> valAros(String pCadena , String pMsg) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();
		
		Integer nSlash;
		String cDiame;
		String cAncho;
		
		pCadena = SunatStringUtils.trim(pCadena);
		nSlash =  SunatStringUtils.indexOf(pCadena, "/");
		if(nSlash > 0)
		{
			//cDiame = SunatStringUtils.substringFox(pCadena, 1, nSlash -1);
			//cAncho = SunatStringUtils.substringFox(pCadena, nSlash +1, pCadena.length() );
			cDiame = SunatStringUtils.substring(pCadena.trim(),0,nSlash);
			cAncho = SunatStringUtils.substring(pCadena.trim(),nSlash+1, pCadena.trim().length() );
			
			//if(SunatStringUtils.length(cDiame) != 2 
			//		&& ! SunatStringUtils.isNumeric(cDiame))
			if (!SunatStringUtils.isFormatNumeric(cDiame,2,0)){
				listErr.add( catalogoAyudaService.getError( "1254" ) );
			}

			//if(SunatStringUtils.length(cAncho) != 2 
			//		&& ! SunatStringUtils.isNumeric(cAncho))
			if (!SunatStringUtils.isFormatNumeric(cAncho,2,0)){
				listErr.add( catalogoAyudaService.getError( "1254" ) );
			}
		}else
			listErr.add( catalogoAyudaService.getError( "1255" ) );
		
		return listErr;
	}
	
	/**
	 * 
	 * @param pCadena
	 * @param pMsg
	 */
	private List<Map<String, String>>  valNeumaticoOtro(String pCadena , String pMsg) {
		
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();
		
		Integer nSlash = 0;
		String cDiame = "";
		String cAncho = "";
		String cSerie = "";
		String cRadial = "";
		String cResto = "";

		pCadena = SunatStringUtils.trim(pCadena);
		nSlash = pCadena.indexOf("/");
		if(nSlash != -1)
		{
			if(nSlash < 3 || nSlash > 6)
				//
				listErr.add( getErrorMap( "1256", pMsg ) );
			else{
				cAncho = SunatStringUtils.substring(pCadena, 0, nSlash);				
				cResto = SunatStringUtils.substring(pCadena, nSlash + 1, pCadena.length());				
				cSerie = SunatStringUtils.substring(cResto, 0, 2);				
				cRadial = SunatStringUtils.substring(cResto, 2, 3);
				cDiame = SunatStringUtils.substring(cResto, 3, 5);
				
				if( SunatStringUtils.length(cAncho.trim()) < 2 )
					//1.	InsTelelog('1256',pMsg+'.AnchoSec. de 2 a 5 caracteres' ) 
					listErr.add(  getErrorMap( "1256", pMsg ) );
				else
					if( ! SunatStringUtils.isAlphanumeric(cAncho.trim()) )
						//a.	InsTelelog('1256',pMsg+'. Ancho de Secci�n invalido') 
						listErr.add( getErrorMap( "1256", pMsg ) );

				if (!SunatStringUtils.isFormatNumeric(cSerie,2,0)){
				//if(SunatStringUtils.length(cSerie) != 2 
				//		&& ! SunatStringUtils.isNumeric(cSerie))
					//1.	InsTelelog('1257',pMsg+'. Serie o perfil invalida') 
					listErr.add( getErrorMap( "1257" , pMsg) );
				}
				
				if( !SunatStringUtils.isEmpty(cRadial) && !SunatStringUtils.isStringInList(cRadial, "R, X, -"))
					//1.	InsTelelog('1258',pMsg+'. Construccion Radial invalida') 
					listErr.add( getErrorMap( "1258", pMsg  ) );
			
				//if(SunatStringUtils.length(cDiame) != 2 
				//		&& ! SunatStringUtils.isNumeric(cDiame))
				if (!SunatStringUtils.isFormatNumeric(cDiame,2,0)){
					//1.	InsTelelog('1259',pMsg+'. Diametro no Valido') 
					listErr.add( getErrorMap( "1259", pMsg  ) );				
			}
			}
		}else
			//i.	InsTelelog('1256',pMsg+'. Falta enviar /' )
			listErr.add( getErrorMap( "1255", pMsg ) );
		
		return listErr;
	}

	private List<Map<String, String>> valPoteMotor(String pCadena , String pMsg) {
		
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();
		Integer nArroba = -1;
		String cPot = "";
		String cRpm = "";
		
		Integer lengthCadena = SunatStringUtils.length(pCadena.trim());
		
		if(lengthCadena > 0)
			nArroba = pCadena.trim().indexOf("@");
		
		if(nArroba != -1)
		{
			//cPot = pCadena.substring(0, nArroba - 1);
			//cRpm = pCadena.substring(nArroba, lengthCadena);
			cPot = SunatStringUtils.substring(pCadena.trim(), 0, nArroba);
			cRpm = SunatStringUtils.substring(pCadena.trim(), nArroba+1, lengthCadena);
			
			//if( SunatStringUtils.hasFormatDecimal(cPot, 4, 2) )
			if (!SunatStringUtils.isFormatNumeric(cPot, 4, 2))
				listErr.add( getErrorMap( "1279", pMsg  ) );
			
			//if(SunatStringUtils.length(cRpm) != 5 
			//		&& ! SunatStringUtils.isNumeric(cRpm))
			if (!SunatStringUtils.isFormatNumeric(cRpm, 5, 0))
				listErr.add( getErrorMap( "1280", pMsg  ) );
		}else
			listErr.add( getErrorMap( "1279", pMsg ) );
		
		return listErr;
	}

	
	class ParamValTipoDato{
		String tcValCampo = ""; 	// 	: Valor del campo a validar
		String tcTipoDato = ""; 	// 	: Tipo de dato
		String tcTipoObs  = ""; 	//	: Tipo de observaci�n
		String tcCodiError = ""; 	// 	: C�digo de error
		String tcNombCampo = ""; 	// 	: Nombre del campo
		String tcTipoForm = ""; 	// 	: Tipo especial de validaci�n
		String tTipoRela = ""; 		// 	: Tipo de descripci�n m�nima
		Integer tnPoscDec = 0; 		// 	: Posici�n de la parte decimal
		Integer tnPoscEnte = 0; 	// 	: Posici�n de la parte entera
		String tMensaje = ""; 		// 	: Mensaje de error
		public String getTcValCampo() {
			return tcValCampo;
		}
		public void setTcValCampo(String tcValCampo) {
			this.tcValCampo = tcValCampo;
		}
		public String getTcTipoDato() {
			return tcTipoDato;
		}
		public void setTcTipoDato(String tcTipoDato) {
			this.tcTipoDato = tcTipoDato;
		}
		public String getTcTipoObs() {
			return tcTipoObs;
		}
		public void setTcTipoObs(String tcTipoObs) {
			this.tcTipoObs = tcTipoObs;
		}
		public String getTcCodiError() {
			return tcCodiError;
		}
		public void setTcCodiError(String tcCodiError) {
			this.tcCodiError = tcCodiError;
		}
		public String getTcNombCampo() {
			return tcNombCampo;
		}
		public void setTcNombCampo(String tcNombCampo) {
			this.tcNombCampo = tcNombCampo;
		}
		public String getTcTipoForm() {
			return tcTipoForm;
		}
		public void setTcTipoForm(String tcTipoForm) {
			this.tcTipoForm = tcTipoForm;
		}
		public String getTTipoRela() {
			return tTipoRela;
		}
		public void setTTipoRela(String tipoRela) {
			tTipoRela = tipoRela;
		}
		public Integer getTnPoscDec() {
			return tnPoscDec;
		}
		public void setTnPoscDec(Integer tnPoscDec) {
			this.tnPoscDec = tnPoscDec;
		}
		public Integer getTnPoscEnte() {
			return tnPoscEnte;
		}
		public void setTnPoscEnte(Integer tnPoscEnte) {
			this.tnPoscEnte = tnPoscEnte;
		}
		public String getTMensaje() {
			return tMensaje;
		}
		public void setTMensaje(String mensaje) {
			tMensaje = mensaje;
		}
	}
	
	private List<Map<String, String>> valTipoDato(ParamValTipoDato param) {
		
		List<Map<String, String>>  listErr = new ArrayList<Map<String, String>>();
		
		BigDecimal number = new BigDecimal(0);
		
		if( SunatStringUtils.isEqualTo(param.getTcTipoDato(), "NUMBER") )
		{

			//convierte a n�mero TcValCampo con tnposc_ente enteros y  tnposc_deci decimales
			if (!SunatStringUtils.isEmptyTrim(param.getTcValCampo()) && SunatStringUtils.isNumeric(param.getTcValCampo()))
				number =  new BigDecimal(param.getTcValCampo());
			else
				number = new BigDecimal(0);
			
			if( SunatNumberUtils.isLessOrEqualsThanParam(number, new BigDecimal(-1) ))			

				if( SunatStringUtils.isEqualTo(param.getTcTipoObs(), "C") 
						&& SunatNumberUtils.isEqual(number, new BigDecimal("-3") ))
					listErr.add( getErrorMap( param.getTcCodiError(), 
							new Object[]{param.getTcNombCampo(), param.getTcValCampo(), param.getTMensaje()}) );
			
			else if( SunatNumberUtils.isEqual(number, new BigDecimal(0)) 
					&&  SunatStringUtils.isEqualTo(param.getTcTipoObs(), "M"))
				
				listErr.add( getErrorMap( param.getTcCodiError(), 
						new Object[]{param.getTcNombCampo(), param.getTcValCampo(), param.getTMensaje()}) );
			else if( SunatStringUtils.isEqualTo(param.getTTipoRela(), "K9") )
			{
				if( SunatStringUtils.isEqualTo( param.getTcNombCampo(), "ARO_ANO") 
						&& SunatNumberUtils.isLessThanParam(number, new BigDecimal(1900) ) )
				{
					listErr.add( getErrorMap( param.getTcCodiError(), 
							new Object[]{param.getTcNombCampo(), param.getTcValCampo(), param.getTMensaje()}) );					
				}else if( SunatStringUtils.isEqualTo(param.getTcTipoForm(), "EJE") 
							&& SunatNumberUtils.isLessOrEqualsThanParam(number, new BigDecimal(1) ))

					listErr.add( getErrorMap( param.getTcCodiError(), 
							new Object[]{param.getTcNombCampo(), param.getTcValCampo(), param.getTMensaje()}) );					
			}
		}
		
		return listErr;
	}
	
	class ParamValCierre{
		String tcValor = ""; 			//	: Dato a validar
		Integer tnPosInicial  = -1; 	//	: Posici�n inicial
		Integer tnCantDig 	 = 0; 		//	: Longitud de la condici�n
		String tcNombCampo  = ""; 		//	: Nombre del Campo
		String tcCodiError  = ""; 		//	: C�digo de error
		String tcNomTabla  = ""; 		//	: Tipo de tabla en la cual validar
		Integer tcLongMinima  = 0; 	//	: Longitud m�nima
		String tcValorCampo  = ""; 	//	: Valor del campo de donde se obtiene el dato a validar
		String tcCampo  = ""; 			//	: Nombre del Campo
		String ttipoRela  = ""; 		//	: Tipo de descripci�n m�nima
		String tcValorCampoRel = ""; 	//	: Valor del campo relacionado
		public String getTcValor() {
			return tcValor;
		}
		public void setTcValor(String tcValor) {
			this.tcValor = tcValor;
		}
		public Integer getTnPosInicial() {
			return tnPosInicial;
		}
		public void setTnPosInicial(Integer tnPosInicial) {
			this.tnPosInicial = tnPosInicial;
		}
		public Integer getTnCantDig() {
			return tnCantDig;
		}
		public void setTnCantDig(Integer tnCantDig) {
			this.tnCantDig = tnCantDig;
		}
		public String getTcNombCampo() {
			return tcNombCampo;
		}
		public void setTcNombCampo(String tcNombCampo) {
			this.tcNombCampo = tcNombCampo;
		}
		public String getTcCodiError() {
			return tcCodiError;
		}
		public void setTcCodiError(String tcCodiError) {
			this.tcCodiError = tcCodiError;
		}
		public String getTcNomTabla() {
			return tcNomTabla;
		}
		public void setTcNomTabla(String tcNomTabla) {
			this.tcNomTabla = tcNomTabla;
		}
		public Integer getTcLongMinima() {
			return tcLongMinima;
		}
		public void setTcLongMinima(Integer tcLongMinima) {
			this.tcLongMinima = tcLongMinima;
		}
		public String getTcValorCampo() {
			return tcValorCampo;
		}
		public void setTcValorCampo(String tcValorCampo) {
			this.tcValorCampo = tcValorCampo;
		}
		public String getTcCampo() {
			return tcCampo;
		}
		public void setTcCampo(String tcCampo) {
			this.tcCampo = tcCampo;
		}
		public String getTtipoRela() {
			return ttipoRela;
		}
		public void setTtipoRela(String ttipoRela) {
			this.ttipoRela = ttipoRela;
		}
		public String getTcValorCampoRel() {
			return tcValorCampoRel;
		}
		public void setTcValorCampoRel(String tcValorCampoRel) {
			this.tcValorCampoRel = tcValorCampoRel;
		}
	}
	
	private List<Map<String, String>> valCierre(ParamValCierre param) {
		BigDecimal number = new  BigDecimal(0);
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		if( SunatStringUtils.isEqualTo(param.getTcCampo(), "MARC_COMER")
				&& SunatStringUtils.length(param.getTcValor()) < param.getTcLongMinima())
		{
			listErr.add( getErrorMap( param.getTcCodiError(), 
					new Object[]{param.getTcNombCampo(), param.getTcLongMinima(), param.getTcValor()}) );					
		}

		if( SunatStringUtils.isEqualTo(param.getTcCampo(), "MODE_MERCD")
				&& SunatStringUtils.length(param.getTcValor()) < param.getTcLongMinima())
		{
			listErr.add( getErrorMap( param.getTcCodiError(), 
					new Object[]{param.getTcNombCampo(), param.getTcLongMinima(), param.getTcValor()} ));					
		}

		if( SunatStringUtils.isEqualTo(param.getTcValor(), "07")
				&& SunatStringUtils.isEqualTo(param.getTcNombCampo(), "CLAS_VARI") )
		{
			listErr.add( getErrorMap( param.getTcCodiError(), 
					new Object[]{param.getTcNombCampo(), "CODIGO 07:OTROS NO PERMITIDO"}) );			
		}else if( SunatStringUtils.isEqualTo(param.getTcCodiError(), "5696") )
		{
			number = new BigDecimal( param.getTcValor() );
			
			if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) )
			{
				listErr.add( getErrorMap( param.getTcCodiError(), 
						new Object[]{param.getTcNombCampo(), " EN LAS ", param.getTnCantDig(), param.getTnPosInicial(), param.getTcValor()}) );
			}else if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(65))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(8))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(10))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(12))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(15))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(18))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(20))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(25))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(40))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(45))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(50))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(55))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(60))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(65))  )
			{
				listErr.add( getErrorMap( param.getTcCodiError(), 
						new Object[]{param.getTcNombCampo(), " TAMA�O PERMITIDO 8, 10, 12, 15, 18, 20, 25, 40, 45, 50, 55, 60, 65. ENVIO ", param.getTcValor()}) );
			}
		}else if( SunatStringUtils.isEqualTo(param.getTcCodiError(), "5698") ){
			
			number = new BigDecimal( param.getTcValor() );
			
			if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) )
			{
				listErr.add( getErrorMap( param.getTcCodiError(), 
						new Object[]{param.getTcNombCampo(), " EN LAS ", param.getTnCantDig(), param.getTnPosInicial(), param.getTcValor()}) );
			}else if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(8))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(2))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(3))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(4))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(5))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(7))
						&& ! SunatNumberUtils.isEqual(number, new BigDecimal(8))  )
			{
				listErr.add( getErrorMap( param.getTcCodiError(), 
						new Object[]{param.getTcNombCampo(), " CODIGOS AUTORIZADO PARA CIERRES: 16, 15, 07, 24. ENVIO ", param.getTcValor()}) );
			}
		}
		
		return listErr;
	}
	
	class ParamValCalzado{
		String tcValor = ""; 		// 	: Dato a validar
		Integer tnPosInicial = -1; 	// 	: Posici�n inicial
		Integer tnCantDig = 0; 		// 	: Longitud de la condici�n
		String tcNombCampo = ""; 	// 	: Nombre del Campo
		String tcCodiError = ""; 	// 	: C�digo de error
		Integer tcLongMinima = 0; 	// 	: Longitud m�nima
		String tcValorCampo = ""; 	// 	: Valor del campo de donde se obtiene el dato a validar
		String tcCampo  = ""; 		//	: Nombre del Campo
		String ttipoRela = ""; 		// 	: Tipo de descripci�n m�nima
		String tcValorCampoRel = ""; //	: Valor del campo relacionado
		String tcCondOpci = ""; 	// 	: Condici�n opcional
		String tcCondVali = ""; 	// 	: Condici�n de validaci�n
		String tcTipoObs = ""; 		// 	: Tipo de observaci�n

		public String getTcValor() {
			return tcValor;
		}
		public void setTcValor(String tcValor) {
			this.tcValor = tcValor;
		}
		public Integer getTnPosInicial() {
			return tnPosInicial;
		}
		public void setTnPosInicial(Integer tnPosInicial) {
			this.tnPosInicial = tnPosInicial;
		}
		public Integer getTnCantDig() {
			return tnCantDig;
		}
		public void setTnCantDig(Integer tnCantDig) {
			this.tnCantDig = tnCantDig;
		}
		public String getTcNombCampo() {
			return tcNombCampo;
		}
		public void setTcNombCampo(String tcNombCampo) {
			this.tcNombCampo = tcNombCampo;
		}
		public String getTcCodiError() {
			return tcCodiError;
		}
		public void setTcCodiError(String tcCodiError) {
			this.tcCodiError = tcCodiError;
		}
		public Integer getTcLongMinima() {
			return tcLongMinima;
		}
		public void setTcLongMinima(Integer tcLongMinima) {
			this.tcLongMinima = tcLongMinima;
		}
		public String getTcValorCampo() {
			return tcValorCampo;
		}
		public void setTcValorCampo(String tcValorCampo) {
			this.tcValorCampo = tcValorCampo;
		}
		public String getTcCampo() {
			return tcCampo;
		}
		public void setTcCampo(String tcCampo) {
			this.tcCampo = tcCampo;
		}
		public String getTtipoRela() {
			return ttipoRela;
		}
		public void setTtipoRela(String ttipoRela) {
			this.ttipoRela = ttipoRela;
		}
		public String getTcValorCampoRel() {
			return tcValorCampoRel;
		}
		public void setTcValorCampoRel(String tcValorCampoRel) {
			this.tcValorCampoRel = tcValorCampoRel;
		}
		public String getTcCondOpci() {
			return tcCondOpci;
		}
		public void setTcCondOpci(String tcCondOpci) {
			this.tcCondOpci = tcCondOpci;
		}
		public String getTcCondVali() {
			return tcCondVali;
		}
		public void setTcCondVali(String tcCondVali) {
			this.tcCondVali = tcCondVali;
		}
		public String getTcTipoObs() {
			return tcTipoObs;
		}
		public void setTcTipoObs(String tcTipoObs) {
			this.tcTipoObs = tcTipoObs;
		}
	}
	
	private List<Map<String, String>> valCalzado(ParamValCalzado param) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		//String lcCadValores = "";
		//String lcDatoPri = "";
		//String lcDatoAux = "";
		String lcPoliuretano = "POL";
		String lcCondOpci = param.getTcCondOpci();
		String lcCondVali = param.getTcCondVali();
		String lcRechazo = "";
		String lcPartSup = SunatStringUtils.substringFox(param.getTcValorCampo(), 1, 3);

		if( gnNewVal2 == 1 )
			lcPoliuretano="PUR";
		
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "vCampo", SunatStringUtils.trim(param.getTcValor()));
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "vParSup", lcPartSup);
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "vCuero", gcCuero);
	
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vCampo", SunatStringUtils.trim(param.getTcValor()));
		lcCondVali = SunatStringUtils.replace(lcCondVali, "v1erPor",  SunatStringUtils.substringFox(param.getTcValorCampo(), 27, 3) );
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vCapi",  gcCapitulo );
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vConst", SunatStringUtils.substringFox(mMatCompo, 15, 3) );
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vNomCo", SunatStringUtils.substringFox(mNombComer, 1, 3) );
		
		lcRechazo = funcionesService.fcValCondidion(param.getTcValor(), param.getTnPosInicial(), param.getTnCantDig(), 
				param.getTcNombCampo(), lcCondOpci, lcCondVali, param.getTcTipoObs());
		
		if( ! SunatStringUtils.isEmpty(lcRechazo) )
			listErr.add( getErrorMap( param.getTcCodiError(), lcRechazo) );
		
		if(SunatNumberUtils.isEqual(gnNewVal1, 1)
				||  SunatNumberUtils.isEqual(gnNewVal2, 1) )
		{
			if( ! SunatStringUtils.isStringInList( SunatStringUtils.substringFox(mNombComer, 1, 3), "BAS, BIM") )
			{
				Timestamp today = new  Timestamp( System.currentTimeMillis() );
				if( SunatStringUtils.isEqualTo(param.getTcCampo(), "CARA_TIPO") 
						&& SunatNumberUtils.isEqual(gnVecesVal, 0))
				{
					lcRechazo = funcionesService.
					fcValCalzadoOtros("1", today, 
								SunatStringUtils.substringFox(param.getTcValorCampo(), 1, 3) ,
								SunatStringUtils.substringFox(mClasVari, 1, 3),
								new Long(mPartNandi), lcPoliuretano, "", "", "");
					
					if( ! SunatStringUtils.isEmpty(lcRechazo) )
						listErr.add( getErrorMap( "1162", lcRechazo) );			

					lcRechazo = funcionesService.
					fcValCalzadoOtros("1", today, 
								SunatStringUtils.substringFox(param.getTcValorCampo(), 1, 3), 
								SunatStringUtils.substringFox(mClasVari, 1, 3),
								new Long(mPartNandi), 
								lcPoliuretano, 
								SunatStringUtils.substringFox(mNombComer, 1, 3),
								SunatStringUtils.substringFox(mCaraTipo, 4, 3),
								SunatStringUtils.substringFox(mCaraTipo, 30, 3));
					
					if( ! SunatStringUtils.isEmpty(lcRechazo) )
						listErr.add( getErrorMap( "1162",  lcRechazo) );	
				}
			}
		}
		
		return listErr ;
	}
	
	private List<Map<String, String>>  valVehiculo(
			String vCampo,  		//	: Dato a validar
			String pcTipoDesc,  	//	: Tipo para validar en la tabla TAB_DESC_MIN
			String pcTipoForm,  	//	: Para identificar algunos tipos de validaaci�n
			Integer pnPoscCodi,  	//  :Posici�n 
			Integer pnLongCodi,  	//	: Longitud
			String pNombrCamp,  	// 	: Nombre del Campo de donde se saca la informaci�n
			String pcTipoError,  	// 	: Tipo de error
			String pcTipoDato,  	// 	: Tipo de dato
			String pcTipoObs,  		//	: Tipo de Observaci�n
			Integer pnPoscDeci,  	//	: Posiciones decimales
			Integer pnPoscEnte,  	// 	: Posici�n entera
			String pCondiOpci,  	//	: Condici�n opcional a validar
			String pCondiVali,  	//	: Condici�n a validar
			String pcValorCampo ,  //	: Valor del dato de donde se saca la informaci�n
			Integer pnPoscOtro,  	//	: Posici�n del dato �Otros�
			Integer pnLongOtro,  	//	: Longitud del dato �Otros�
			String pcCodOtros,  	//	: C�digo que indica si es �Otros�
			String pcTipoMerc  	//	: Tipo de Descripciones m�nimas			
			) 
	{
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>(); 

		String condicion = "";
		Integer nlong;
		String tMensaje = " Posicion "+pnPoscCodi+"-"+(pnLongCodi+pnPoscCodi-1);
		String cmsg = marchivo+pNombrCamp+" Envio: "+vCampo+tMensaje;
		//String nreg; declarada pero no usada
		String condiNume;
		Integer nPosIni;
		Integer nPosFin;
		String cdecode;
		
		// No deber�a blanquearse el valor x q viene cargado de ValDescMin
		//String mCate = ""; 

		if(vCampo == null 
				|| SunatStringUtils.isEqualTo(vCampo, "/")
				|| SunatStringUtils.isEqualTo(vCampo, "0")
				|| SunatStringUtils.isEqualTo(vCampo, "0.00")  )
		{
			nlong =0;
		}else{
			nlong = SunatStringUtils.length( vCampo );
		}
		
		if( ! SunatStringUtils.isEmpty(pCondiOpci) )
		{
			condicion = SunatStringUtils.trim(pCondiOpci);
			condicion = SunatStringUtils.replace(condicion, "mCate", mCate);
			condicion = SunatStringUtils.replace(condicion, "mSubCat", mSubCat);
			condicion = SunatStringUtils.replace(condicion, "mSN", mSN);
			condicion = SunatStringUtils.replace(condicion, "nlong", nlong.toString());
			condicion = SunatStringUtils.replace(condicion, "swCetico", swCetico);
			condicion = SunatStringUtils.replace(condicion, "mEstMer", mEstaMercd);
			condicion = SunatStringUtils.replace(condicion, "pFEmb", pFechEmbar.toString());
			condicion = SunatStringUtils.replace(condicion, "pFLleg", pFechLlega.toString());
			condicion = SunatStringUtils.replace(condicion, "wruc", wruc);
			condicion = SunatStringUtils.replace(condicion, "wclib", wclib);
			condicion = SunatStringUtils.replace(condicion, "wregi", mCodiRegi);
		}
		
		if( SunatStringUtils.isEqualTo(pcTipoObs, "M")
				|| (nlong > 0  && !pNombrCamp.equals("USO_APLIC:KILOMETRAJE")))
			/*Se filtra kilometraje para que no valide por aqui el l�mite arey 20140818*/
		{
			condicion = SunatStringUtils.trim(pCondiVali);
			condicion = SunatStringUtils.replace(condicion, "mCate", mCate);
			condicion = SunatStringUtils.replace(condicion, "mSubCat", mSubCat);
			condicion = SunatStringUtils.replace(condicion, "nYear", nyear.toString());
			condicion = SunatStringUtils.replace(condicion, "mAro_Ano", mAroAno);
			condiNume = condicion;
			condicion = SunatStringUtils.replace(condicion, "nlong", nlong.toString());
			condicion = SunatStringUtils.replace(condicion, "swCetico", swCetico);
			condicion = SunatStringUtils.replace(condicion, "mEstMer", mEstaMercd);
			condicion = SunatStringUtils.replace(condicion, "mEnc", mEncend);
			condicion = SunatStringUtils.replace(condicion, "vRev1", vRevisa1);
			condicion = SunatStringUtils.replace(condicion, "wregi", mCodiRegi);
			
			//xiii.	Si el dato es num�rico
			if( SunatStringUtils.isEqualTo(pcTipoDato, "NUMBER") )
			{
				//if( SunatStringUtils.hasFormatDecimal(vCampo, pnPoscEnte, pnPoscDeci))
				if( SunatStringUtils.isFormatNumeric(vCampo, pnPoscEnte, pnPoscDeci))
				{
					if( SunatStringUtils.isEqualTo(pcTipoForm, "AS") ){
						nAS = vCampo;
						if( SunatStringUtils.isEqualTo(mCarro, "CHM") )
							condicion = "1=1";
//							2.	Si es de Chasis Motorizado se acepta cualquier n�mero de asientos.
//							3.	Esa condici�n siempre ser� verdadera. 
					}else if( SunatStringUtils.isEqualTo(pcTipoForm, "PB") ){
						nPB = vCampo;
					}else if( SunatStringUtils.isEqualTo(pcTipoForm, "PN") ){
						nPN = vCampo;
					}
						
					condicion = SunatStringUtils.replace(condicion, "nAS", nAS);
					condicion = SunatStringUtils.replace(condicion, "nPB", nPB);
					condicion = SunatStringUtils.replace(condicion, "nPN", nPN);
					condiNume = SunatStringUtils.replace(condicion, "vCampo", "DATO");
					condicion = SunatStringUtils.replace(condicion, "vCampo", vCampo);
					
					if( SunatStringUtils.isEmpty(condicion) )
						condicion="1=1";
					
					//Si condicion es una condici�n FALSA entonces: (una forma de verificar la condici�n es coloc�ndola en el WHERE de una sentencia SQL)
					if( ! funcionesService.isCondicionValida(condicion) )
					{
						if( (nPosIni = condiNume.indexOf("DECODE"))  != -1 )
						{
							nPosFin = condiNume.indexOf(")");
							cdecode = SunatStringUtils.substringFox(condiNume, nPosIni, nPosFin);
							//TODO valor obtenido de evaluar el DECODE
							condiNume = SunatStringUtils.replace(condiNume, cdecode, "");
							nPosIni = condiNume.indexOf("DECODE");
							if(nPosIni != -1)
							{
								nPosFin = condiNume.indexOf(")");
								cdecode = SunatStringUtils.substringFox(condiNume, nPosIni, nPosFin);
								//TODO valor obtenido de evaluar el DECODE
								condiNume = SunatStringUtils.replace(condiNume, cdecode, "");
							}
						}
						listErr.add( getErrorMap( pcTipoError,condiNume) );	
					}	
					
				}else{
					
					//a.	InsTelelog(pctipo_error,cmsg+' DATO NO NUMERICO '+A_CADENA(pNPOSC_ENTE) Ent '+A_CADENA(pNPOSC_DECI)+' DEC') 
					listErr.add( getErrorMap( pcTipoError, new Object[]{pnPoscEnte, pnPoscDeci}) );
				}
			}else{

				//1.	Si el dato no es n�merico
				condicion = SunatStringUtils.replace(condicion, "vCampo", vCampo);
				if( ! SunatStringUtils.isEmptyTrim(pcTipoDesc) )
				{
					if( !SunatStringUtils.isEqualTo(pcTipoDesc, "==" ) )
					{
						// i. SpValTabla( pcValor_Campo, pnPosc_Otro, pnLong_Otro,
						// pcTipo_error, pNombr_camp, pcTipo_Desc, vCampo,
						// pcTipo_obs, pcCod_Otros, pcTipo_Dato,' EN LAS '+
						// A_CADENA(pnLong_Codi) + ' POSICIONES A PARTIR DE '+
						// A_CADENA( pnPosc_Codi ), pctipo_merc )
						ParamValTabla paramValTabla = new ParamValTabla();
						paramValTabla.setTcValCampo(pcValorCampo);
						paramValTabla.setTnPosResto(pnPoscOtro);
						paramValTabla.setTnCantResto(pnLongOtro);
						paramValTabla.setTcCodiError(pcTipoError);
						paramValTabla.setTcNombCampo(pNombrCamp);
						paramValTabla.setTcTipoTabl(pcTipoDesc);
						paramValTabla.setTcDato(vCampo);
						paramValTabla.setTcTipoObs(pcTipoObs);
						paramValTabla.setTcCodOtros(pcCodOtros);
						paramValTabla.setTcTipoDato(pcTipoDato);
						paramValTabla.setTMensaje(" EN LAS "+ pnLongCodi + " POSICIONES A PARTIR DE "+ pnPoscCodi );
						paramValTabla.setTcTipoMerc(pcTipoMerc);
						
						listErr.addAll( valTabla(paramValTabla) );
					}
					else
						if( ! funcionesService.isCategoriaVehiculoValido(mCate, mSubCat, wClase) )
						{
							// cmsg + ' CATEGORIA INVALIDA o TIPO USO = 1'
							listErr.add( getErrorMap( pcTipoError, new Object[]{mCate, mSubCat,wClase}) );
						}
				}else{
					//a.	Se usa la condici�n de validaci�n 
					if( SunatStringUtils.isEqualTo(pcTipoForm, "AR") ) { //entonces: (AROS)
						//i.	SpAros(vCampo,cMsg)
						listErr.addAll( valAros(vCampo, cmsg) );
					}else if( SunatStringUtils.isStringInList(pcTipoForm, "N1, N2") ) { //entonces: (NEUMATICOS)
						//i.	SpNeumatico(vCampo,cMsg)
						//valNeumaticoOtro
						listErr.addAll( valNeumaticoOtro(vCampo, cmsg) );
					}else if( SunatStringUtils.isEqualTo(pcTipoForm, "PM") ) { //entonces: (AROS)
						// i.	SpPoteMotor(vCampo,cMsg)
						listErr.addAll( valPoteMotor(vCampo,cmsg) );
					}else{
						
						//Si condicion es una condici�n FALSA entonces: (una forma de verificar la condici�n es coloc�ndola en el WHERE de una sentencia SQL)
						if( ! SunatStringUtils.isEmptyTrim(condicion) && ! funcionesService.isCondicionValida(condicion) ) {
							if( condiNume.indexOf("nlong") == -1 )
								if( condiNume.indexOf("numerico") != -1 )
									condiNume = "NO ES ALFANUMERICO";
								else
									condiNume = "REVISA NO REGISTRADO";
						//3.	InsTelelog(pctipo_error,cmsg+' No Cumple: '+CondiNume) 
						listErr.add( getErrorMap( pcTipoError, condiNume) );
					}				
				}				
			}
			}
		}else{
			if(  !(SunatStringUtils.isStringInList(pcTipoForm, "AS, PA") && SunatStringUtils.isEqualTo(mCarro, "CHM"))) //Es chasis Motorizado no necesita enviar ni Asientos ni Pasajeros
			{
				//Validar solo aquellos que tengan condicion
				if( ! SunatStringUtils.isEmpty(pCondiOpci) && !pNombrCamp.equals("USO_APLIC:KILOMETRAJE"))//se quita las limitaciones de kilometraje
				{
					//Si condicion es una condici�n FALSA entonces: (una forma de verificar la condici�n es coloc�ndola en el WHERE de una sentencia SQL)
					if( funcionesService.isCondicionValida(condicion) )
					{	
						if( ! (SunatStringUtils.isEqualTo(tipoTrat, "4") && SunatStringUtils.isEqualTo(pcTipoForm, "R1")) )
							//1.	InsTelelog(pctipo_error,cmsg+' FALTA DATO')							
							listErr.add( catalogoAyudaService.getError( pcTipoError) );
					}
				}
			}
		}
		
		return listErr;
	}
	
	
	private List<Map<String, String>> valLentes(
			String tcValor, // 	: Dato a validar
			Integer tnPosInicial, // 	: Posici�n inicial
			Integer tnCantDig, // 	: Longitud de la condici�n
			String tcNombCampo, // 	: Nombre del Campo
			String tcCodiError, // 	: C�digo de error
			String tcNomTabla, //	: Tipo de tabla donde validar el dato
			String tcLongMinima, // 	: Longitud m�nima
			String tcValorCampo, // 	: Valor del campo de donde se obtiene el dato a validar
			String tcCampo, // 	: Nombre del Campo
			String ttipoRela, // 	: Tipo de descripci�n m�nima
			String tcValorCampoRel//	: Valor del campo relacionado			
			) {
		BigDecimal number = new BigDecimal(0);
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		if(  SunatStringUtils.isEqualTo(ttipoRela, "KH")){
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "PLA,TTN,MET,ZZZ"))
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos PLA,TTN,MET,ZZZ.ENVIO '+ TcValor ) 
				listErr.add( getErrorMap( tcCodiError, tcValor) );
			}
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KI")){
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "CRT,RSN,PCB"))
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos CRT,RSN,PCB .ENVIO '+ TcValor )  
				listErr.add( getErrorMap( tcCodiError, tcValor) );
			}

			if( SunatStringUtils.isEqualTo(tcCampo, "USO_APLIC")
					&& SunatStringUtils.isEqualTo(tcValor.substring(7,10), "MFC") 
					&& ( ! SunatStringUtils.isStringInList(tcValor.substring(10,13), "ESF,CIL,COM") 
							|| (SunatStringUtils.isEmpty(tcValor.substring(10,13)) &&  tnPosInicial == 4) ) )
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos ESF,CIL,COM .ENVIO '+ TcValor ) 
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
			if( SunatStringUtils.isEqualTo(tcCampo, "MAT_COMPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "ARF,ATR,SIT")
					&& tnPosInicial == 4)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos ESF,CIL,COM .ENVIO '+ TcValor ) 
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}

			if( SunatStringUtils.isEqualTo(tcCampo, "CLAS_VARI")
					&& ! SunatStringUtils.isEmpty(tcValor)
					&& tnPosInicial == 1
					&& SunatStringUtils.isEqualTo(tcValorCampoRel.substring(7, 10), "TRM"))
			{
				//1.	1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' No envio dato .ENVIO '+ TcValor )  
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KL")){
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "PMM,HEM,FLU,SIL,ZZZ")
					&& tnPosInicial == 4)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos PMM,HEM,FLU,SIL,ZZZ.ENVIO '+ TcValor )  
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
			if( SunatStringUtils.isEqualTo(tcCampo, "USO_APLIC")
					&& SunatStringUtils.isEqualTo(tcValorCampo.substring(0,3), "BLD") 
					&& ( ! SunatStringUtils.isStringInList(tcValorCampo.substring(4,7), "CON,DES") 
							|| (SunatStringUtils.isEmpty(tcValorCampo.substring(4,7)) &&  tnPosInicial == 4) ) )
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos CON,DES .ENVIO '+ TcValor )  
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CLAS_VARI") ){
				number = new BigDecimal( tcValor.substring(0,3));
				
				if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) )
				{
					//a.	InsTelelog(TcCodi_error,marchivo+TcCampo+' MEDIDA DEL LENTE INCORRECTA, FORMATO (X.XX-Y.YY). ENVIO:'+SIN_ESPACIOS(TcValor)) 
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor}) );
				}
				
				if( ! SunatStringUtils.isEmpty(tcValor.substring(5, 10)) )
				{
					if(  ! SunatStringUtils.isEqualTo(tcValor.substring(5, 6), "-") )
					{
						//i.	InsTelelog(TcCodi_error,marchivo+TcCampo+' SIGNO - PARA SEPARAR LAS MEDIDAS NO ENVIADO, FORMATO (X.XX-Y.YY). ENVIO:'+ TcValor) 
						listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor}) );
					}
					number = new BigDecimal( tcValor.substring(6, 10) );
					
					if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) )
					{
						//i.	InsTelelog(TcCodi_error,marchivo+TcCampo+' 2DA. MEDIDA DEL LENTE 	INCORRECTA, FORMATO (X.XX-Y.YY). ENVIO:'+ TcValor)  
						listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor}) );
					}	
				}
			}
			
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KM")){
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "PMM,HEM,FLU,SIL,ZZZ"))
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos PMM,HEM,FLU,SIL,ZZZ .ENVIO '+ TcValor )   
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KN")){

			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "PLA,TTN,MET,ZZZ")
					&& tnPosInicial == 1)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos PLA,TTN,MET,ZZZ.ENVIO '+ TcValor )    
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}

			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "CRT,RSN,PCB")
					&& tnPosInicial == 34)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos CRT, RSN, PCB . ENVIO'+ TcValor )    
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}

			if( SunatStringUtils.isEqualTo(tcCampo, "USO_APLIC")
					&& SunatStringUtils.isEqualTo(tcValor.substring(7,10), "MFC") 
					&& ( ! SunatStringUtils.isStringInList(tcValor.substring(10,13), "ESF,CIL,COM") 
							|| (SunatStringUtils.isEmpty(tcValor.substring(10,13)) &&  tnPosInicial == 10) ) )
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos ESF,CIL,COM . ENVIO '+ TcValor )  
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KO")){

			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "PLA,TTN,MET,ZZZ")
					&& tnPosInicial == 1)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos PLA,TTN,MET,ZZZ.ENVIO '+ TcValor )     
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}

			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "CRT,RSN,PCB")
					&& tnPosInicial == 34)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos CRT,RSN,PCB . ENVIO '+ TcValor )      
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
		}
		return listErr;
	}
	
	private List<Map<String, String>> valTelasPlast(
			String tcValor, 		// 	: Dato a validar
			Integer tnPosInicial, 	// 	: Posici�n inicial
			String tcNombCampo, 	// 	: Nombre del Campo
			String tcCodiError,		// 	: C�digo de error
			String tcValorCampo, 	// 	: Valor del campo de donde se obtiene el dato a validar
			String tcCampo, 		// 	: Nombre del Campo
			String ttipoRela, 		// 	: Tipo de descripci�n m�nima
			String tcValorCampoRel 	//	: Valor del campo relacionado
			) {
	
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		if(  SunatStringUtils.isEqualTo(ttipoRela, "KP")){
			
			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isStringInList(tcValor, "SSP,CSP")
					&& tnPosInicial == 1)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' Valores permitidos SSP,CSP.ENVIO: '+ TcValor )      
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
			if(SunatStringUtils.length(tcValorCampo)>=3 
					&& SunatStringUtils.isEqualTo(tcValorCampo.substring(0, 3), "CSP") )
			{
				if( SunatStringUtils.isEqualTo(tcCampo, "CLAS_VARI")
						&& SunatStringUtils.isEmpty(tcValor)
						
						&& tnPosInicial == 1)
				{
					//a.	InsTelelog(TcCodi_error,marchivo+TcCampo+' DEBE ENVIAR EL TIPO DE SOPORTE. ENVIO:'+SIN_ESPACIOS(TcValor)+' EN LA POSICION: '+A_CADENA(TnPos_Inicial))       
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor, tnPosInicial}) );
				}
				
				if( SunatStringUtils.length(tcValorCampo)>=2 
						&& SunatStringUtils.isStringInList(tcValorCampo.substring(0, 2), "01,02,04,05") 
						&& SunatStringUtils.isEqualTo(tcCampo, "CLAS_VARI"))
				{
					if(tnPosInicial == 28 && SunatStringUtils.isEmptyTrim(tcValor)){
						//i.	InsTelelog(TcCodi_error,marchivo+TcCampo+' DEBE COMPONENTE DE TEJIDO Y NO TEJIDO. ENVIO:'+SIN_ESPACIOS(TcValor)+' EN LA POSICION: '+A_CADENA(TnPos_Inicial))
						listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor, tnPosInicial}) );
					}

					if(tnPosInicial == 86 && SunatStringUtils.isEmptyTrim(tcValor)){
						//i.	InsTelelog(TcCodi_error,marchivo+TcCampo+' DEBE ENVIAR EL GRADO DE ELABORACION. ENVIO:'+SIN_ESPACIOS(TcValor)+' EN LA POSICION: '+A_CADENA(TnPos_Inicial)) 
						listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor, tnPosInicial}) );
					}
					
				}
			}
			
		}else if(  SunatStringUtils.isEqualTo(ttipoRela, "KR")){

			if( SunatStringUtils.isEqualTo(tcCampo, "CARA_TIPO")
					&& ! SunatStringUtils.isEqualTo(tcValor, "SSP")
					&& tnPosInicial == 1)
			{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' VALOR PERMITIDO: SSP.ENVIO: '+ TcValor )      
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
			}
			
			if( SunatStringUtils.isEqualTo(tcCampo, "MAT_COMPO")
					&& tnPosInicial == 30)
			{
				if( (SunatStringUtils.isEqualTo(tcValorCampoRel.substring(10, 12), "20")
						|| SunatStringUtils.isEqualTo(tcValorCampoRel.substring(41, 43), "20") ) 
						&& SunatStringUtils.isEmptyTrim(tcValor))
				{
					//b.	InsTelelog(TcCodi_error,marchivo+TcCampo+' DEBE ENVIAR EL TIPO DE PLASTIFICANTE. ENVIO:'+SIN_ESPACIOS(TcValor)+' EN LA POSICION: '+A_CADENA(TnPos_Inicial))
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor, tnPosInicial}) );
				}

				if( ! SunatStringUtils.isEqualTo(tcValorCampoRel.substring(10, 12), "20")
						&& ! SunatStringUtils.isEqualTo(tcValorCampoRel.substring(41, 43), "20") 
						&& ! SunatStringUtils.isEmptyTrim(tcValor))
				{
					//b.	InsTelelog(TcCodi_error,marchivo+TcCampo+' NO DEBE ENVIAR EL TIPO DE PLASTIFICANTE. ENVIO:'+SIN_ESPACIOS(TcValor)+' EN LA POSICION: '+A_CADENA(TnPos_Inicial)) 
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor, tnPosInicial}) );
				}
			}			
		}
		
		if( SunatStringUtils.isEqualTo(tcCampo, "MAT_COMPO") 
				&& tnPosInicial == 27
				&& ! SunatStringUtils.isEmptyTrim(tcValor)
				&& ! SunatStringUtils.isStringInList(tcValor, "M,PUL") )
		{
			//ii.	InsTelelog(TcCodi_error,marchivo+TcCampo+' UNIDAD DE MEDIDA,INCORRECTO. ENVIO:'+SIN_ESPACIOS(TcValor)+' DEBE ENVIAR M o PUL ')
			listErr.add( getErrorMap( tcCodiError, new Object[]{tcCampo, tcValor}) );
		}
		return listErr;
	}
	
	private List<Map<String, String>> valNeumatico(
			String tcValor, 		//	: Dato a validar
			Integer tnPos_Inicial, 	// 	: Posici�n inicial
			Integer tnCantDig, 		// 	: Longitud de la condici�n
			String tcNombCampo, 	// 	: Nombre del Campo
			String tcCodiError, 	// 	: C�digo de error
			String tcValorCampoRel 	//	: Valor del campo relacionado			
			) {
		
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
 		BigDecimal number = new BigDecimal(0);
		
		if(SunatStringUtils.isEqualTo(tcCodiError, "5762") )
		{
			if(SunatStringUtils.isEqualTo(tcValorCampoRel, "01") ){
				number = new BigDecimal(tcValor.trim());
				if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) ){
					//a.	InsTelelog( TcCodi_error,marchivo+TcNomb_Campo+' EN LAS '+A_CADENA(TnCant_Dig,'9')+ 	' ENVIAR NUMERO(9999.99)DESDE LA POSICION ' +A_CADENA(TnPos_Inicial,'9') + ' ENVIO '+ TcValor ) 
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tnCantDig,tnPos_Inicial,tcValor}) );
				}
			}else if(SunatStringUtils.isEqualTo(tcValorCampoRel, "02") ){
				if( SunatStringUtils.isCharBetween(tcValor, 'A', 'Z') )
				{
					//a.	InsTelelog( TcCodi_error, marchivo+TcNomb_Campo+' EN LA PRIMERA POSICION '+ 	' ENVIAR A, B, ... Z. ENVIO '+ TcValor )
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor}) );
				}
				
			}else if(SunatStringUtils.isEqualTo(tcValorCampoRel, "03") ){
				number = new BigDecimal(tcValor);
				if( SunatNumberUtils.isLessThanParam(number, new BigDecimal(0)) ){
					//a.	InsTelelog( TcCodi_error,marchivo+TcNomb_Campo+' EN LAS '+A_CADENA(TnCant_Dig,'9')+ 	' ENVIAR NUMERO(99999.99)DESDE LA POSICION ' +A_CADENA(TnPos_Inicial,'9') + ' ENVIO '+ TcValor ) 
					listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tnCantDig,tnPos_Inicial,tcValor}) );
				}				
			}else{
				//1.	InsTelelog(TcCodi_error,marchivo+TcNomb_Campo+' NO SE PUEDE DETERMINAR POR TIPO DE NOMENCLATURA INCORRECTA:'+TcValor_CampoRel )
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tcValor, tcValorCampoRel}) );
			}
		}else if( SunatStringUtils.isEqualTo(tcCodiError, "5763") ) {
			if(  SunatStringUtils.isEqualTo(tcValorCampoRel, "01") 
					&& ! SunatStringUtils.isEmpty(SunatStringUtils.trimNotNull(tcValor)))
			{
				// DZC PAS20155E220000178  tcValorCampoRel=01 es valor numerico
				//1.	InsTelelog( TcCodi_error,marchivo+TcNomb_Campo+' EN LAS '+A_CADENA(TnCant_Dig,'9')+ ' NO ENVIAR DESDE POSICION ' +A_CADENA(TnPos_Inicial,'99') + ' ENVIO '+ TcValor ) 
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tnCantDig,tnPos_Inicial, tcValor}) );
			}else if( SunatNumberUtils.toInteger(tcValorCampoRel) > 1
					&& SunatStringUtils.isEmpty(tcValor) ){
				//1.	InsTelelog( TcCodi_error,marchivo+TcNomb_Campo+' EN LAS '+A_CADENA(TnCant_Dig,'9')+ ' ENVIAR DESDE POSICION ' +A_CADENA(TnPos_Inicial,'99') + ' ENVIO '+ TcValor )
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo, tnCantDig,tnPos_Inicial, tcValor}) );
			}
		}
		return listErr;
	}
	
	private List<Map<String, String>> valOjalillos(
			String tcValor, 		// 	: Dato a validar
			Integer tnPosInicial, 	// 	: Posici�n inicial
			Integer tnCantDig, 		// 	: Longitud de la condici�n
			String tcNombCampo, 	// 	: Nombre del Campo
			String tcCodiError		// 	: C�digo de error
			) {
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		String lcValor = SunatStringUtils.replace(tcValor, " ", "0");
		if( SunatStringUtils.isEqualTo(tcCodiError, "1160") ) {
			//i.	Debe declarar Dimensi�n en el formato: 999.9x999.9x999.9
			String concatenatedSymbol =
				SunatStringUtils.substringFox(lcValor, 4, 1) + 
				SunatStringUtils.substringFox(lcValor, 6, 1) +
				SunatStringUtils.substringFox(lcValor, 10, 1) +
				SunatStringUtils.substringFox(lcValor, 12, 1) ;
			
			String concatenatedNumbers =
				SunatStringUtils.substringFox(lcValor, 1, 3) + 
				SunatStringUtils.substringFox(lcValor, 5, 1) +
				SunatStringUtils.substringFox(lcValor, 7, 3) +
				SunatStringUtils.substringFox(lcValor, 11, 1) +
				SunatStringUtils.substringFox(lcValor, 17, 1);
			
			if( SunatStringUtils.isEmpty(lcValor) 
					|| ! SunatStringUtils.isEqualTo(concatenatedSymbol, ".X.X.") 
					|| ! SunatStringUtils.isNumeric(concatenatedNumbers) )
			{
				//1.	InsTelelog( TcCodi_error,marchivo+TcNomb_Campo+': Posic.'+A_CADENA(TnPos_Inicial,'99')+' al'+ 	A_CADENA(TnPos_Inicial+TnCant_Dig-1,'99')+' Declarar Dimension, formato: 999.9x999.9x999.9') 
				listErr.add( getErrorMap( tcCodiError, new Object[]{tcNombCampo,tnPosInicial, tnCantDig}) );				
			}
		}
		
		return listErr;
	}
	
	private List<Map<String, String>> valCds(
			String vCampo, 			//	: Dato a validar
			Integer pnPoscCodi, 	//: Posici�n inicial
			Integer pnLongCodi, 	//	: Longitud de la condici�n
			String pNombrCamp, 		//	: Nombre del Campo
			String pcTipoError, 	//	: C�digo de error
			String pcTipoDato, 		//	: Tipo de dato
			String pcTipoObs, 		//	: Tipo de observaci�n
			String pCondiOpci, 		//	: Condici�n Opcional
			String pCondiVali 		//	: Condici�n a Validar			
			) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		String condicion  = "";
		String tMensaje  = " Posicion "+ pnPoscCodi+"-"+( pnLongCodi + pnPoscCodi - 1 );
		String cmsg = marchivo+pNombrCamp+" Envio: "+vCampo+tMensaje;
		//Integer lnCnt = 0; No se usa
		boolean lbValida = true;
		
		if( ! funcionesService.existsInCatRefPartidas("DMD", mPartNandi, mNombComer) )
		{
			//i.	InsTelelog('1174',marchivo+'NOMB_COMER='+mNOMB_COMER+', DECLARO PART_NANDI:'+A_CADENA(mPART_NANDI)) 
			listErr.add( getErrorMap( "1174", new Object[]{marchivo,mNombComer, mPartNandi} ) );			
		}else{
			if ( ! SunatStringUtils.isEmpty(pCondiOpci) )
			{
				condicion = pCondiOpci;
				condicion = SunatStringUtils.replace(condicion, "vTipo", vTipo);
				//3.	Si la condici�n condicion es FALSA entonces: (Una forma de verificar condicion es coloc�ndolo en el WHERE de una sentencia SQL)
				if( ! funcionesService.isCondicionValida(condicion) )
				{
					lbValida = false;
				}
			}
			
			if( lbValida 
					&& ( ! SunatStringUtils.isEmpty(pCondiVali) ) )
			{
				condicion = pCondiVali;
				condicion = SunatStringUtils.replace(condicion, "vCampo", vCampo);
				if( ! funcionesService.isCondicionValida(condicion) ){
					//a.	InsTelelog(pctipo_error,cmsg+' No Cumple: '+condicion) 
					listErr.add( getErrorMap( "1174", new Object[]{cmsg,condicion} ) );
				}
			}
		}
		
		return listErr;
	}
	
	private List<Map<String, String>> valTextil(
			String vCampo, 			//	: Dato a validar
			String pcTipoDesc, 		//	: Tipo de Tabla con la cual validar
			Integer pnPoscCodi, 	//	: Posici�n inicial
			Integer pnLongCodi, 	//	: Longitud de la condici�n
			String pNombrCamp, 		//	: Nombre del Campo
			String pcTipoError, 	//	: C�digo de error
			String pCondiOpci, 		//	: Condici�n Opcional
			String pCondiVali 		//	: Condici�n a Validar
			) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		String condicion  = "";
		String tMensaje  = " Posicion "+ pnPoscCodi+"-"+( pnLongCodi + pnPoscCodi - 1 );
		String cmsg = marchivo+pNombrCamp+" Envio: "+vCampo+tMensaje;
		//Integer lnCnt = 0;
		boolean lbValida = true;

		if ( ! SunatStringUtils.isEmpty(pCondiOpci) )
		{
			condicion = pCondiOpci;
			condicion = SunatStringUtils.replace(condicion, "vCampo", vCampo);
			//3.	Si la condici�n condicion es FALSA entonces: (Una forma de verificar condicion es coloc�ndolo en el WHERE de una sentencia SQL)
			if( ! funcionesService.isCondicionValida(condicion) )
			{
				lbValida = false;
			}
		}
		
		if( lbValida 
				&& ( ! SunatStringUtils.isEmpty(pCondiVali) ) )
		{
			condicion = pCondiVali;
			condicion = SunatStringUtils.replace(condicion, "vCampo", vCampo);
			condicion = SunatStringUtils.replace(condicion, "vNomCo", vNomCo);
			condicion = SunatStringUtils.replace(condicion, "vTipFi", vTipFi);
			
			if( ! funcionesService.isCondicionValida(condicion) ){
				if( SunatStringUtils.isEqualTo(pcTipoDesc, "3T") )
					//a.	InsTelelog('1292', cmsg) 
					listErr.add( getErrorMap( "1292", new Object[]{cmsg} ) );
				else
					//a.	InsTelelog(pctipo_error, cmsg+' No Cumple: '+condicion) 
					listErr.add( getErrorMap( pcTipoError, new Object[]{cmsg, condicion} ) );
			}
		}
		
		return listErr;
	}
	
	private List<Map<String, String>> valError(
			String pTipo, 		//	: Tipo de tabla en el TABLNEW
			String pCodigo, 	//	: C�digo a validar
			String pError, 		//	: C�digo de rechazo
			String pTable, 		//	: Tabla en la cual validar
			String pArchivo, 	//	: Informaci�n que se est� validando
			String pColumn, 	//	: Nombre del campo a validar
			String tMensaje		//: Mensaje de error			
			) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		String mDescError = ""; //new Integer ( SunatStringUtils.substringFox(pTexto, 1, 4) );
		//Integer lnCnt = 0;
		//mDescError = pColumn + "-" + pCodigo + " DEL TIPO :" + pTipo;
		
		if( SunatStringUtils.isEqualTo(pTable, "TAB_DESC_MIN") ){
			if( ! funcionesService.existsInTabDescMinByTipoAndCodigo(pTipo, pCodigo) )
			{
				mDescError = pArchivo + pColumn +": "+pCodigo +tMensaje;
			}			
		}else{
			if( ! SunatStringUtils.isEqualTo(pTipo, "==") ){
				//i.	Valida en la tabla TABLNEW.
				//TODO Invocar a catalogo.
				//Integer fechaFin = 20090801;
				boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(pTipo, pCodigo));
				//if (!catalogoHelper.isValid(pCodigo, pTipo)){
				if (!validaCatalogo){
					veriError(listErr, pTipo, pCodigo, pError, pTable, pColumn);					
					//mDescError = pColumn + " - NO VIGENTE "+ pCodigo+ " DEL TIPO :" + pTipo;
				}
				
				//if(fechaFin >= fechIngSi)
				//{
				//	mDescError = "";
				//}else{
				//	mDescError = pColumn + " - NO VIGENTE "+ pCodigo+ " DEL TIPO :" + pTipo;
				//}
			}
		}
		
		if(!  SunatStringUtils.isEmpty(mDescError) )
		{
			listErr.add( getErrorMap(pError, mDescError) );
		}
		return listErr;
	}
	
	private Map<String, String>  valMedicamento(
			String tcValor, 		// 	: Dato a validar
			Integer tnPosInicial, 	// 	: Posici�n inicial
			Integer tnCantDig, 		// 	: Longitud de la condici�n
			String tcNombCampo, 	// 	: Nombre del Campo
			String tcCodiError, 	// 	: C�digo de error
			String tcLongMinima, 	// 	: Longitud m�nima
			String tcValorCampo, 	// 	: Valor del campo de donde se obtiene el dato a validar
			String tcCampo, 		// 	: Nombre del Campo
			String ttipoRela, 		// 	: Tipo de descripci�n m�nima
			String tcValorCampoRel, //	: Valor del campo relacionado
			String tcCondOpci, 		//	: Condici�n Opcional
			String tcCondVali, 		//	: Condici�n de Validaci�n
			String tcTipoObs 		//	: Tipo de Observaci�n
			) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, String> result = new HashMap<String, String>();
		
		//String lcCadValores = "";
		//String lcDatoPri = "";
		//String lcDatoAux = "";
		String lcCondOpci = tcCondOpci;
		String lcCondVali = tcCondVali;
		String lcRechazo = "";
		String lc2PriAc = SunatStringUtils.substringFox(mClasVari, 19, 4);
		String lc3PriAc = SunatStringUtils.substringFox(mClasVari, 37, 4);
		String lc4PriAc = SunatStringUtils.substringFox(mClasVari, 55, 4);
		
		
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "vCampo", tcValor);
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "2doPriAc",  lc2PriAc);
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "3erPriAc", lc3PriAc);
		lcCondOpci = SunatStringUtils.replace(lcCondOpci, "4toPriAc", lc4PriAc);
		//6.	Condici�n de Validaci�n. 
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vCampo", tcValor);
		lcCondVali = SunatStringUtils.replace(lcCondVali, "vPartida", mPartNandi);
		lcRechazo = funcionesService.fcValCondidion(tcCampo, tnPosInicial, tnCantDig, tcNombCampo, lcCondOpci, lcCondVali, tcTipoObs); 
		
		if(SunatStringUtils.isEmpty(lcRechazo))
		{
			// i.	InsTelelog(TcCodi_error, LcRechazo) 
			result = getErrorMap( tcCodiError , new Object[]{lcRechazo} );
		}
		return result;
	}
	
	private List<Map<String, String>> valDesCierre(
			String pTipoRela	//: Tipo de descripci�n m�nima			
			) {
	
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		if(  (SunatStringUtils.isEqualTo(pTipoRela, "KB")  && ! SunatStringUtils.isStringInList(mUnidMercd, "YD,M")) 
				|| SunatStringUtils.isStringInList(pTipoRela, "KA,KC") && ! SunatStringUtils.isStringInList(mUnidMercd, "U,12U,GRU,MLL")){
			//ii.	InsTelelog('5699',marchivo+'UNID_MERCD TIPO DE UNIDAD DE MEDIDA NO AUTORIZADO. ENVIO '+mUNID_MERCD)
			listErr.add( getErrorMap( "5699" , new Object[]{marchivo, mUnidMercd} ) );
		}

		if( SunatStringUtils.isEqualTo(pTipoRela, "KA")  && ! SunatStringUtils.isEqualTo(mNombComer, "CIERRES DE CREMALLERA") ){
			//i.	InsTelelog('5700',marchivo+'NOMB_COMER, DEBE TRANSMITIR: CIERRES DE CREMALLERA. ENVIO '+mNOMB_COMER) 
			listErr.add( getErrorMap( "5700" , new Object[]{marchivo, mNombComer} ) );			
		}
		
		if( ! SunatStringUtils.isEqualTo(pTipoRela, "KA")  ){
			if( ! SunatStringUtils.isEmptyTrim(mCaraTipo) ){
				//1.	InsTelelog('5719',marchivo+'CARA_TIPO, NO DEBE TRANSMITIR TIPO DE CIERRE CUANDO SE TRATA DE PARTES. ENVIO '+mCARA_TIPO) 
				listErr.add( getErrorMap( "5719" , new Object[]{marchivo, mCaraTipo} ) );
			}
			
			if( SunatStringUtils.isEqualTo(pTipoRela, "AA")  ){
				if( ! SunatStringUtils.isEmptyTrim(mClasVari) ){
					//a.	InsTelelog('5719',marchivo+'CLAS_VARI, NO TRANSMITIR CUANDO SE TRATE DE TIRADOR.ENVIO '+ SIN_ESPACIOS( mCLAS_VARI ) ) 
					listErr.add( getErrorMap( "5719" , new Object[]{marchivo, mClasVari} ) );
				}
				
				if( ! SunatStringUtils.isEmptyTrim(mUsoAplic) ){
					//a.	InsTelelog('5719',marchivo+'USO_APLIC, NO TRANSMITIR CUANDO SE TRATE DE TIRADOR.ENVIO '+ SIN_ESPACIOS( mUSO_APLIC ) )  
					listErr.add( getErrorMap( "5719" , new Object[]{marchivo, mUsoAplic} ) );
				}

				if( ! SunatStringUtils.isEmptyTrim(mMatCompo) ){
					//a.	InsTelelog('5719',marchivo+'MAT_COMPO, NO TRANSMITIR CUANDO SE TRATE DE TIRADOR.ENVIO '+ SIN_ESPACIOS( mMAT_COMPO ) )  
					listErr.add( getErrorMap( "5719" , new Object[]{marchivo, mMatCompo} ) );
				}

			}else if(! SunatStringUtils.isEmptyTrim(SunatStringUtils.substringFox(mMatCompo, 1, 3)) ) {
				//1.	InsTelelog('5719',marchivo+'MAT_COMPO, NO TRANSMITIR EN LAS TRES PRIMERAS POSICIONES, DESTINADO PARA TAMA?O DEL CIERRE.ENVIO '+ SUBSTR( mMAT_COMPO, 1, 3 ) )
				listErr.add( getErrorMap( "5719" , new Object[]{marchivo, SunatStringUtils.substringFox(mMatCompo, 1, 3)} ) );
			}
		}
		return listErr;
	}

	private List<Map<String, String>> valPilas() {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		//BigDecimal nNumber;
		String lcMatCompo = mMatCompo;
		String lcCadValores = "";

		if( SunatStringUtils.isStringInList(mUnidMercd, "U,12U,GRU,MLL") ){
			//i.	InsTelelog('0062',marchivo+'UNID_MERCD: SOLO ESTA PERMITIDO: U, 12U, GRU, MLL') 
			listErr.add( getErrorMap( "0062" , new Object[]{marchivo} ) );			
		}else if( SunatStringUtils.isEmpty(lcMatCompo) ){
			//i.	InsTelelog('1156',marchivo+'MAT_COMPO: DEBE DECLARAR EL VOLTAJE DE LA PILA') 
			listErr.add( getErrorMap( "1156" , new Object[]{marchivo} ) );
		}else if( ! SunatStringUtils.isEmpty(lcMatCompo) ){
			
			String s = SunatStringUtils.substringFox(lcMatCompo, 1, 2) + SunatStringUtils.substringFox(lcMatCompo, 4, 2);
			s = SunatStringUtils.replace(s, " ", "0");
			if( ! SunatStringUtils.isEqualTo(SunatStringUtils.substringFox(lcMatCompo, 3, 1), ".")  
					|| ! SunatStringUtils.isNumeric(s)){
				//1.	InsTelelog('1156',marchivo+'MAT_COMPO DEBE DECLARAR EL VOLTAJE DE FORMA 99.99 DECLARO:'+lcMat_compo) 
				listErr.add( getErrorMap( "1156" , new Object[]{marchivo, lcMatCompo} ) );
			}
		}
		
		if( mTobsItem.length() < 5 ){
			//i.	InsTelelog('1150',marchivo+'TOBS_ITEM: DEBE ENVIAR INFORMACION ADICIONAL') 
			listErr.add( getErrorMap( "1150" , new Object[]{marchivo, lcMatCompo} ) );
		}
		
		//7.	Validaciones Cruzadas.
		if( funcionesService.existsInCatRefPartidas("VCR", mPartNandi, null) )
		{
			//10.	Si encuentra informaci�n entonces:
			//	i.	Verifica Tipo.
			if( SunatStringUtils.substringFox(lcCadValores, 1, 15)
					.indexOf( SunatStringUtils.substringFox(mCaraTipo, 1, 3) ) == -1 )
			{
				//1.	InsTelelog('1153',marchivo+'CARA_TIPO: TIPO '+SUBSTR(mCARA_TIPO,1,3)+ 
				//2.	' NO CORRESPONDE A PARTIDA '+A_CADENA(mPART_NANDI)) 
				listErr.add( getErrorMap( "1153" , new Object[]{marchivo, mCaraTipo, mPartNandi} ) );
			}

			//iv.	Verifica Forma. 
			if( SunatStringUtils.substringFox(lcCadValores, 16, 15)
					.indexOf( SunatStringUtils.substringFox(mClasVari, 1, 3) ) == -1 )
			{
				//1.	InsTelelog('1154',marchivo+'CLAS_VARI: FORMA '+SUBSTR(mCLAS_VARI,1,3)+ 
				//2.	' NO CORRESPONDE A PARTIDA '+A_CADENA(mPART_NANDI)) 
				listErr.add( getErrorMap( "1154" , new Object[]{marchivo, mClasVari, mPartNandi} ) );
			}			
		}
		
		return listErr; 
	}
	
	private List<Map<String, String>> valComputadoras( ) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		//Integer lnCnt = 0;
		
		if( ! SunatStringUtils.isEqualTo(mUnidMercd, "U") )
		{
			//i.	InsTelelog('0062',marchivo+'UNID_MERCD: SOLO ESTA PERMITIDO: U') 
			listErr.add( getErrorMap( "0062" , new Object[]{marchivo} ) );
		}
		
		if(! funcionesService.existsInCatRefPartidas("DMD", mPartNandi, mNombComer) )
		{
			//i.	InsTelelog('1174',marchivo+'NOMB_COMER='+mNOMB_COMER+', DECLARO PART_NANDI:'+A_CADENA(mPART_NANDI))
			listErr.add( getErrorMap( "1174" , new Object[]{marchivo, mNombComer, mPartNandi} ) );
		}
		
		if( SunatStringUtils.isEqualTo(mNombComer, "IMP") ){ //entonces: (Impresoras)
			if( SunatStringUtils.isStringInList( SunatStringUtils.substringFox(mCaraTipo, 1, 3) , "INY,LAS,PLO") ){
				//1.	VELOCIDAD DE IMPRESION
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 1, 3) ) ){
					//a.	InsTelelog('1175',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' NO DECLARO VELOC.DE IMP.NEGRO') 
					listErr.add( getErrorMap( "1175" , new Object[]{marchivo, mCaraTipo} ) );
					
				}else if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 24, 3) ) ){
					//a.	InsTelelog('1175',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' NO DECLARO VELOC.DE IMP.COLOR') 
					listErr.add( getErrorMap( "1175" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				if( ! SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 47, 3) ) ){
					//a.	InsTelelog('1176',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' VELOCIDAD DEBE SER EN PPM') 
					listErr.add( getErrorMap( "1176" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				//7.	CAPACIDAD DE MEMORIA. 
				if( ! SunatStringUtils.isEqualTo( SunatStringUtils.substringFox(mCaraTipo, 1, 3),"LAS" ) ){
					
					if(  SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mUsoAplic, 1, 3) ) ){
						//i.	InsTelelog('1177',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)) 
						listErr.add( getErrorMap( "1177" , new Object[]{marchivo, mCaraTipo} ) );
					}
					
					if(  ! SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mUsoAplic, 24, 3) ) ){
						//i.	InsTelelog('1176',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' DECLARO ANCHO DE COLUMNA')  
						listErr.add( getErrorMap( "1176" , new Object[]{marchivo, mCaraTipo} ) );
					}
					
				}
			}else if( SunatStringUtils.isEqualTo( SunatStringUtils.substringFox(mCaraTipo, 1, 3) , "MAT") ){
				
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 47, 3) ) ){
					//a.	InsTelelog('1175',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' NO DECLARO VELOC.DE IMP.')
					listErr.add( getErrorMap( "1175" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				if( ! SunatStringUtils.isEmpty(
						SunatStringUtils.substringFox(mClasVari, 1, 3)  + 
						SunatStringUtils.substringFox(mClasVari, 24, 3) ) )
				{
					//a.	InsTelelog('1176',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' VELOCIDAD DEBE SER SOLO EN CPS')
					listErr.add( getErrorMap( "1176" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				//6.	ANCHO DE COLUMNA. 
				
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mUsoAplic, 24, 3) ) ){
					//a.	InsTelelog('1178',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3))
					listErr.add( getErrorMap( "1178" , new Object[]{marchivo, mCaraTipo} ) );
				}

				if( ! SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mUsoAplic, 1, 3) ) ){
					//a.	InsTelelog('1176',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3)+' DECLARO CAPACIDAD DE MEMORIA')
					listErr.add( getErrorMap( "1176" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				//11.	CODIGO DE PINES. 
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mMatCompo, 1, 3) ) ){
					//a.	InsTelelog('1179',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3))   
					listErr.add( getErrorMap( "1179" , new Object[]{marchivo, mCaraTipo} ) );
				}
			}
		}else if( SunatStringUtils.isEqualTo(mNombComer, "MEM") ){ //entonces: (Memorias)
			
			if( SunatStringUtils.isEqualTo( SunatStringUtils.substringFox(mCaraTipo, 1, 3) , "RAM") ){
				//1.	TIPO DE MEMORIA RAM. 
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mCaraTipo, 24, 3) ) ){
					//a.	InsTelelog('1180',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3))
					listErr.add( getErrorMap( "1180" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				//4.	VELOCIDAD DE BUS. 
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 1, 3) ) ){
					//a.	InsTelelog('1181',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3))
					listErr.add( getErrorMap( "1181" , new Object[]{marchivo, mCaraTipo} ) );
				}
				
				//7.	CODIGO DE MODULO DE MEMORIA
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mMatCompo, 1, 3) ) ){
					//a.	InsTelelog('1182',marchivo+'PARA CARA_TIPO='+SUBSTR(mCARA_TIPO,1,3))
					listErr.add( getErrorMap( "1182" , new Object[]{marchivo, mCaraTipo} ) );
				}
			}
		}else if( SunatStringUtils.isEqualTo(mNombComer, "VEN") ){ //entonces: (Memorias)
			if( SunatStringUtils.isStringInList( SunatStringUtils.substringFox(mCaraTipo, 1, 3) , "PRO,DDR") ){
				
				if( SunatStringUtils.isEqualTo( SunatStringUtils.substringFox(mCaraTipo, 1, 3) , "PRO") ){
					
					if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mCaraTipo, 4, 3) )){
						//i.	InsTelelog('1184',marchivo+' ES VENTILADOR DE PROCESADOR') 
						listErr.add( getErrorMap( "1184" , new Object[]{marchivo} ) );
					}
					
					if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mCaraTipo, 27, 3) )){
						//i.	InsTelelog('1176',marchivo+' ES VENTILADOR DE PROCESADOR')
						listErr.add( getErrorMap( "1176" , new Object[]{marchivo} ) );
					}
				}else{
					if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mCaraTipo, 27, 3) )){
						//i.	InsTelelog('1185',marchivo+' ES VENTILADOR DE DISCO DURO')
						listErr.add( getErrorMap( "1185" , new Object[]{marchivo} ) );
					}
					
					if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mCaraTipo, 4, 3) )){
						//i.	InsTelelog('1176',marchivo+' ES VENTILADOR DE DISCO DURO')
						listErr.add( getErrorMap( "1176" , new Object[]{marchivo} ) );
					}					
				}
			}else{
				//1.	InsTelelog('1183',marchivo+'NOMB_COMER=VEN => FINALIDAD DEBE SER PRO o DDR')
				listErr.add( getErrorMap( "1183" , new Object[]{marchivo} ) );
			}
		}
		
		return listErr;
	}
	
	private List<Map<String, String>>  valTextilFinal(String tcTipoRela) {
		
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		
		Integer compo1 = 0;
		Integer compo2 = 0;
		Integer compo3 = 0;
		Integer compo4 = 0;
		String lcPaSA = SunatStringUtils.substringFox(mPartNandi, 1, 4);
		String lcCapt = SunatStringUtils.substringFox(mPartNandi, 1, 2);
		
		if( SunatStringUtils.isEqualTo(tcTipoRela, "T1")){ //(Fibras)
			compo1 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 27, 3) );
			if( compo1 < 0 )
			{
				compo1 = 0;
			}
			
			compo2 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 53, 3) );
			if( compo2 < 0 )
			{
				compo2 = 0;
			}
			
			if ( (compo1+compo2) != 100 )
			{
				//InsTelelog('1197','Suma de componentes de la Fibra = '+A_CADENA(Compo1+Compo2)+' %')
				listErr.add( getErrorMap( "1197" , new Object[]{(compo1 + compo2)} ) );
			}
			
			if( mUsoAplic.length() < 10 
					|| SunatStringUtils.hasMismosCaracteres(mUsoAplic))
			{
				//InsTelelog('1293','USO_APLIC: HA DECLARADO: '+SIN_ESPACIOS(mUSO_APLIC))
				listErr.add( getErrorMap( "1293" , new Object[]{mUsoAplic} ) );
			}
			
			if( mMatCompo.length() < 10 
					|| SunatStringUtils.hasMismosCaracteres(mMatCompo))
			{
				//InsTelelog('1294','MAT_COMPO: HA DECLARADO: '+SIN_ESPACIOS(mMAT_COMPO)) 
				listErr.add( getErrorMap( "1294" , new Object[]{mMatCompo} ) );
			}	
		}else if( SunatStringUtils.isEqualTo(tcTipoRela, "T2")){ //(Hilados)

			compo1 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 50, 3) );
			if( compo1 < 0 )
				compo1 = 0;
			
			compo2 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 24, 3) );
			if( compo2 < 0 )
				compo2 = 0;

			compo3 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 50, 3) );
			if( compo3 < 0 )
				compo3 = 0;

			compo4 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 76, 3) );
			if( compo4 < 0 )
				compo4 = 0;

			
			if( (compo1 + compo2 + compo3 + compo4) != 100 )
			{
				//InsTelelog('1197','Suma de componentes del Hilado = ' +A_CADENA(Compo1+Compo2+Compo3+Compo4)+' %')
				listErr.add( getErrorMap( "1197" , new Object[]{ (compo1+compo2+compo3+compo4) } ) );
			}
			
			if( mMatCompo.length() < 10 
					|| SunatStringUtils.hasMismosCaracteres(mMatCompo))
			{
				//InsTelelog('1198','MAT_COMPO: HA DECLARADO: '+SIN_ESPACIOS(mMAT_COMPO))
				listErr.add( getErrorMap( "1198" , new Object[]{mMatCompo} ) );
			}
			
		}else if( SunatStringUtils.isEqualTo(tcTipoRela, "T3")){ //(Telas)
			
			compo1 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 47, 3) );
			if( compo1 < 0 )
				compo1 = 0;
			
			compo2 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 73, 3) );
			if( compo2 < 0 )
				compo2 = 0;

			compo3 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 24, 3) );
			if( compo3 < 0 )
				compo3 = 0;

			compo4 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 50, 3) );
			if( compo4 < 0 )
				compo4 = 0;
			
			if( (compo1 + compo2 + compo3 + compo4) != 100 )
			{
				//InsTelelog('1197','Suma de componentes de la Tela = '+A_CADENA(Compo1+Compo2+Compo3+Compo4)+' %') 
				listErr.add( getErrorMap( "1197" , new Object[]{ (compo1+compo2+compo3+compo4) } ) );
			}
			
			if( SunatStringUtils.isStringInList(lcPaSA, "5903,5907,6001") ){
				if( SunatStringUtils.isStringInList(lcPaSA, "5903,5907") 
						|| SunatStringUtils.isEmpty(SunatStringUtils.substringFox(mUsoAplic, 1, 3)) )
				{
					//InsTelelog('1199','USO_APLIC: NO DECLARO COMPOSICION, PARA LA PARTIDA DEL SIST. ARM.: '+lcPaSA)
					listErr.add( getErrorMap( "1199" , new Object[]{ lcPaSA } ) );
				}
				
				if( SunatStringUtils.isStringInList(lcPaSA, "5903,5907") 
						|| SunatStringUtils.isEmpty(SunatStringUtils.substringFox(mUsoAplic, 24, 4)) )
				{
					//InsTelelog('1199','USO_APLIC: NO DECLARO ESPESOR, PARA LA PARTIDA SIST. ARM.:' + lcPaSA)
					listErr.add( getErrorMap( "1199" , new Object[]{ lcPaSA } ) );
				}
				
			}else{
				
				if( ! SunatStringUtils.isEmpty
						( SunatStringUtils.substringFox(mUsoAplic, 1, 3) + 
								SunatStringUtils.substringFox(mUsoAplic, 24, 4) ) )
				{
					//InsTelelog('1287','USO_APLIC: PARA LA PARTIDA DEL SIST. ARM.: '+lcPaSA) 	
					listErr.add( getErrorMap( "1287" , new Object[]{ lcPaSA } ) );
				}	
			}
			
		}else if( SunatStringUtils.isEqualTo(tcTipoRela, "T4")){ //(Confecciones)

			compo1 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 47, 3) );
			if( compo1 < 0 )
				compo1 = 0;
			
			compo2 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mCaraTipo, 73, 3) );
			if( compo2 < 0 )
				compo2 = 0;

			compo3 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 24, 3) );
			if( compo3 < 0 )
				compo3 = 0;

			compo4 = SunatNumberUtils.toInteger ( SunatStringUtils.substringFox(mDescCom1, 50, 3) );
			if( compo4 < 0 )
				compo4 = 0;

			if( (compo1 + compo2 + compo3 + compo4) != 100 ){
				//InsTelelog('1197','Suma de componentes de la Confeccion = ' +A_CADENA(Compo1+Compo2+Compo3+Compo4)+' %')
				listErr.add( getErrorMap( "1197" , new Object[]{ (compo1+compo2+compo3+compo4) } ) );
			}
			
			//ACABADOS. 
			if( SunatStringUtils.isStringInList(lcCapt , "61,62") ){
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 24, 3) ) ){
					//InsTelelog('1288','CLAS_VARI: PARA EL CAPITULO: '+lcCapt) 
					listErr.add( getErrorMap( "1288" , new Object[]{ lcCapt } ) );
				}
			}else{
				if( ! SunatStringUtils.isEmpty
						( SunatStringUtils.substringFox(mClasVari, 24, 3) + 
								SunatStringUtils.substringFox(mClasVari, 47, 3) ) )
				{
					//InsTelelog('1289','CLAS_VARI: PARA EL CAPITULO: '+lcCapt)  	
					listErr.add( getErrorMap( "1289" , new Object[]{ lcCapt } ) );
				}
			}
			
			//GRAMAJE. 
			if( SunatStringUtils.isEqualTo(lcPaSA, "6302")
					&& SunatStringUtils.isEmpty( SunatStringUtils.substringFox(mClasVari, 70, 4) )){
				// InsTelelog('1290','CLAS_VARI: NO DECLARO EL GRAMAJE, PARA PARTIDA SIST. ARM.: '+lcPaSA)
				listErr.add( getErrorMap( "1290" , new Object[]{ lcPaSA } ) );
			}
			
			if( mUsoAplic.length() < 10 
					|| SunatStringUtils.hasMismosCaracteres(mUsoAplic)){
				// InsTelelog('1295','USO_APLIC: HA DECLARADO: '+SIN_ESPACIOS(mUSO_APLIC))
				listErr.add( getErrorMap( "1295" , new Object[]{ mUsoAplic } ) );
			}
			
			if( mMatCompo.length() < 10 
					|| SunatStringUtils.hasMismosCaracteres(mMatCompo)){
				// InsTelelog('1291','MAT_COMPO: HA DECLARADO: '+SIN_ESPACIOS(mMAT_COMPO))
				listErr.add( getErrorMap( "1291" , new Object[]{ mMatCompo } ) );
			}
		}
		
		return listErr;
	}
	
}
