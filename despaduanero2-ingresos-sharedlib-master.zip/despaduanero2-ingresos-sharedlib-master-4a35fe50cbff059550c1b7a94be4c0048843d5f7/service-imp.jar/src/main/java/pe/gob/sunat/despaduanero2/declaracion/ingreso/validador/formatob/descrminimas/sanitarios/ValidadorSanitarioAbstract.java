package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public class ValidadorSanitarioAbstract extends ValidadorAbstract{

	public static final String COD_ASOC_CATA = "019";
	public static final String COD_OTROS = "OTR";
	public static final String COD_SIN_CATALOGO = "1";

	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception {
		return null;
	}	  

	public List<ErrorDescrMinima>  validarNombreComercial(ModelAbstract objeto, Declaracion dua){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioAbstract sanitarioAbstract = (SanitarioAbstract) objeto;		
		DatoItem item = obtenerItem(objeto, dua);	
		String codTipValorTipo = sanitarioAbstract.getNombreComercial().getCodtipvalor().toString();
		String datoAValidar = sanitarioAbstract.getNombreComercial().getValtipdescri().trim();
		String subPartida = item.getNumpartnandi().toString();
		if(COD_SIN_CATALOGO.equals(codTipValorTipo))
			datoAValidar = COD_OTROS;
        if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA,  dua.getDua().getFecdeclaracion())){
			ErrorDescrMinima error = obtenerError("31072", sanitarioAbstract.getNombreComercial());
			lstErroresDescrMin.add(error);
		}
        return lstErroresDescrMin;
	}
	public List<ErrorDescrMinima>  validarMarcaComercial(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarModeloComercial(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarCalidad(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarColor(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima>  validarMaterial(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
}
