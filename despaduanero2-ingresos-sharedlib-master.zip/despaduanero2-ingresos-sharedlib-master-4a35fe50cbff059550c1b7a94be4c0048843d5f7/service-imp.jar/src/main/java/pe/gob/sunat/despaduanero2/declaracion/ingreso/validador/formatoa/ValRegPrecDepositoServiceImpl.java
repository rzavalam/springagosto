package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.text.SimpleDateFormat;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Polizad;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Seriesd;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.service.SolicitudRectificaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.model.Participante;


public class ValRegPrecDepositoServiceImpl extends ValDuaAbstract implements ValRegPrecDepositoService {

	//private FabricaDeServicios	fabricaDeServicios;
	
	
	/**
	 * Regla 128 del TDDI
	 * Se valida la cuenta corriente del deposito (91.K )
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return Lista de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2366)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2366,numSecEjec=20,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarCtaCteDeposito(Declaracion declaracion, Map<String, Object> variablesIngreso){
		DUA dua=declaracion.getDua();
		boolean reg70=false;
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();

		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		boolean tieneRegPreEspeciales =false;
		//Lista donde se acumulara los totales si hubiera regimen precedente 70
		List<Map<String,Object>> listDpocCta = new ArrayList<Map<String,Object>>();

		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;

		
		//csantillan PAS20191U220200002
		ValRegPrecEspecialesService  valRegPrecEspecialesSevice = fabricaDeServicios.getService("ingreso.ValRegPrecEspeciales");
		if(esVigenteRIN31){
			for(DatoSerie serie:dua.getListSeries()){
				if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
					for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
						if(valRegPrecEspecialesSevice.valRegimenPrecedenteEspecial(regPrec.getCodregipre())){
							tieneRegPreEspeciales =true;
							break;
						}
					}
				}
			}
		}

		if(declaracionTieneDatoSeries&&!tieneRegPreEspeciales){
			listDpocCta = this.getRegPrecedenciaAcumulado(declaracion);
			reg70 = !listDpocCta.isEmpty();
			for(Map<String,Object> mapCta:  listDpocCta){
				ValNegocCtaCteDepFormA valNegocCtaCteDepFormA = fabricaDeServicios.getService("ValNegocCtaCteDepFormA");
				mapCta.put("fechaVigenciaRegimenBD", (Date)variablesIngreso.get("fechaVigenciaRegimenBD"));
				mapCta.put("numeroDeclaracion", variablesIngreso.get("numeroDeclaracion"));
				listError.addAll(valNegocCtaCteDepFormA.ctaCteDeposito(mapCta));
			}
		}
		/**NSR Si no hay errores con esta variable indicamos que en el metodo de grabaci�n se debe actualizar la cta cte */
		if (listError.isEmpty() &&  reg70){
			variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
		}
		return listError;
	}
	
	
	/**
	 * Metodo que permite consolidar los distintos regimenes de precedencia en un solo Map, acumulando sus pesos y unidades
	 * @param declaracion
	 * @return
	 */
	private List<Map<String,Object>> getRegPrecedenciaAcumulado (Declaracion declaracion){
		DUA dua=declaracion.getDua();
		List<Map<String,Object>> listDpocCta = new ArrayList<Map<String,Object>>();
		for (DatoSerie datoSerieActual : dua.getListSeries()) {
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
					if (datoRegPreActual.getCodregipre().equals("70")){
						Map<String,Object> dPocCta = new HashMap<String, Object>();
						dPocCta.put("codregipre", datoRegPreActual.getCodregipre());
						dPocCta.put("caduregpre", datoRegPreActual.getCodaduapre());
						dPocCta.put("fanoregpre", datoRegPreActual.getAnndeclpre());
						dPocCta.put("ndclregpre", datoRegPreActual.getNumdeclpre());
						dPocCta.put("numserpre", datoRegPreActual.getNumserpre());
						
						dPocCta.put("sumPesoBruto", datoSerieActual.getCntpesobruto());
						dPocCta.put("sumCntunifis", datoSerieActual.getCntunifis());
						//el metodo agrega los datos de esta serie a una Lista
						//Si ya existe un referencia a la misma dua y serie precedente entonce solo sumara
						//los valores sumPesoBruto y sumCntunifis
						/*branch ingreso 2011-009 hosorio inicio*/
						if(declaracion.getNumdeclRef()!=null 
								&& !SunatStringUtils.isEmptyTrim(declaracion.getNumdeclRef().getNumcorre()) )
						{
							NumdeclRef numdeclRef=declaracion.getNumdeclRef();
							dPocCta.put("codregiActual", numdeclRef.getCodregimen());
							dPocCta.put("caduActual", numdeclRef.getCodaduana());
							dPocCta.put("fanoActual", numdeclRef.getAnnprese());
							dPocCta.put("ndclActual", SunatStringUtils.lpad(numdeclRef.getNumcorre(), 6, '0') );
							dPocCta.put("numserActual", datoSerieActual.getNumserie().toString());									
						}
						/*branch ingreso 2011-009 hosorio fin*/
						listDpocCta = AddEnListaDepocCta(listDpocCta,dPocCta);
						break;
					}
				}
			}   
		}
		return listDpocCta;
	}
	
	
	/**
	 * Adds the en lista depoc cta.
	 * 
	 * @param lista List<Map<String,Object>>
	 * @param datos Map<String,Object>
	 * @return Lista de erores
	 */
	private List<Map<String,Object>> AddEnListaDepocCta(List<Map<String,Object>> lista,Map<String,Object> datos){

		boolean datosExisten = false;
		for(Map<String,Object> m: lista){
			if(m.get("caduregpre").toString().equalsIgnoreCase(datos.get("caduregpre").toString()) &&
			   m.get("fanoregpre").toString().equalsIgnoreCase(datos.get("fanoregpre").toString()) &&
			   m.get("ndclregpre").toString().equalsIgnoreCase(datos.get("ndclregpre").toString()) &&
			   m.get("numserpre").toString().trim().equalsIgnoreCase(datos.get("numserpre").toString().trim())
					){
				BigDecimal sumPesoBruto = SunatNumberUtils.sum((BigDecimal)m.get("sumPesoBruto"),(BigDecimal)datos.get("sumPesoBruto"));	
				BigDecimal sumCntunifis = SunatNumberUtils.sum((BigDecimal)m.get("sumCntunifis"),(BigDecimal)datos.get("sumCntunifis"));
				
				m.put("sumPesoBruto", sumPesoBruto);
				m.put("sumCntunifis", sumCntunifis);
				
				datosExisten = true;
			}
		}
		if (!datosExisten){
			lista.add(datos);
		}
		return lista;
	}

	
	/**
	 * Validaciones generales a los datos generales del regimen de precedencia
	 * de Deposito
	 * 
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> valCabRegPreDeposito(Declaracion declaracion, Date fechaReferencia) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> listRegPreDepo = new ArrayList<Map<String, Object>>();
		Map<String, Object> paramsDeclaracion = new HashMap<String, Object>();
		DUA dua = declaracion.getDua();
		/**
		 * 1.1. La modalidad debe corresponder a Excepcional
		 */
		String codModalidad = dua.getCodmodalidad();
		if (!codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL)) {		
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30527",new String[] {codModalidad, Constants.REGIMEN_DEPOSITO.toString()}));
		}
		
		if (SunatStringUtils.isEmpty(dua.getNumruclugarecep())){
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30765",new String[] {}));
		}
			
		/**
		 * 1.2. La declaracion precedente debe existir, para lo cual se verifica
		 * primero en el NSIGAD y luego en el ASIGAD
		 */
		Date fecAutLevante = null;
		boolean tieneDespPorRegularizar = false;
		boolean tieneRegularizacion = false;
		String caduManifPrece = new String();
		String fanoManifPrece = new String();
		String tipoManifPrece = new String();
		String numeManifPrece = new String();
		Date fecVenRegimen = null;
		if (!CollectionUtils.isEmpty(dua.getListSeries())) {
			listRegPreDepo = this.getRegPrecedenciaAcumulado(declaracion);//gmontoya IoC
			
			for (Map<String, Object> mapRegPreDepo : listRegPreDepo) {
				String codregipre = (String) mapRegPreDepo.get("codregipre");
				String pcaduregpre = mapRegPreDepo.get("caduregpre").toString();
				String pfanoregpre = mapRegPreDepo.get("fanoregpre").toString().substring(0, 4);
				String pndclregpre = mapRegPreDepo.get("ndclregpre").toString();
				String pnume_serpr = mapRegPreDepo.get("numserpre").toString();
				String CDAprece = pcaduregpre + "-" + pfanoregpre + "-" + codregipre + "-" + pndclregpre + "-" + pnume_serpr;

				//paramsDeclaracion.put("codigoRegimen", codregipre);
				//paramsDeclaracion.put("codigoAduana", pcaduregpre);
				//paramsDeclaracion.put("annoPresentacion", new Integer(pfanoregpre.substring(0, 4)));
				//paramsDeclaracion.put("numeroDeclaracion", new Integer(pndclregpre.toString()));
				GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
				DUA duaPrecedente = getDeclaracionService.getCabDUA(pcaduregpre, pndclregpre, pfanoregpre, codregipre);
				
				// Si no esta en el NSIGAD se busca en ASIGAD polizad
				if (duaPrecedente == null) {
					Map<String, Object> paramsPolizad = new HashMap<String, Object>();
					paramsPolizad.put("anoPrese", pfanoregpre.substring(2, 4));
					paramsPolizad.put("codiAduan", pcaduregpre);
					paramsPolizad.put("numeCorre", SunatStringUtils.lpad(pndclregpre, 6, '0'));

					ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduanero = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
					List<Polizad> lstPolizad =  consultaDeclaracionDepositoAduanero.consultarDeclaracionDeposito(paramsPolizad,pcaduregpre );
					
					if (CollectionUtils.isEmpty(lstPolizad)) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30528",new String[] {CDAprece}));			
						continue;
					} else {
						// Obtenemos todos los datos necesarios del ASIGAD para
						// la validaci�n correspondiente
						fecAutLevante = SunatDateUtils.getDateFromInteger(lstPolizad.get(0).getFecLevante());
						tieneDespPorRegularizar = lstPolizad.get(0).getTipoDespa().equals("1")|| lstPolizad.get(0).getDespUrge().equals("1") ? true: false;
						tieneRegularizacion = lstPolizad.get(0).getFechRegul() > 0 ? true : false;
						caduManifPrece = lstPolizad.get(0).getCaduManif();
						fanoManifPrece = lstPolizad.get(0).getFechManif();
						tipoManifPrece = SunatStringUtils.lpad(lstPolizad.get(0).getTipoManif().trim(), 2, '0');
						numeManifPrece = lstPolizad.get(0).getNumeManif().toString();
						fecVenRegimen = SunatDateUtils.getDateFromInteger(lstPolizad.get(0).getFechTerec());
					}
				} else {
					// Obtenemos todos los datos necesarios del NSIGAD para la
					// validaci�n correspondiente
					fecAutLevante = duaPrecedente.getFecAutlevante();
					String codModalidadDepo = duaPrecedente.getCodmodalidad();
					tieneDespPorRegularizar = codModalidadDepo.equals(Constants.DESPACHO_URGENTE) ? true : false;
					if (codModalidadDepo.equals(Constants.DESPACHO_ANTICIPADO)) {
						Map<String, Object> paramsIndicador = new HashMap<String, Object>();
						paramsIndicador.put("numcorredoc",   duaPrecedente.getNumcorredoc());
						paramsIndicador.put("codtipoindica", ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION);
						paramsIndicador.put("indactivo",     Constants.INDICADOR_ACTIVO);
						IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("declaracion.indicadorDuaService");						
						List<DatoIndicadores> lista = indicadorDuaService.buscarIndicadores(paramsIndicador);					
						if (!CollectionUtils.isEmpty(lista)) {
							tieneDespPorRegularizar = true;
						}
					}
					if (tieneDespPorRegularizar) {
						Map<String, Object> paramsCabSolrecti = new HashMap<String, Object>();
						paramsCabSolrecti.put("numcorredocpre", duaPrecedente.getNumcorredoc());
						paramsCabSolrecti.put("estadosrecti",  new String[] {ConstantesDataCatalogo.COD_EST_REGULA_ACEPTADA,ConstantesDataCatalogo.COD_EST_REGULA_ACEPTADA_AUTOMATIC });
						paramsCabSolrecti.put("codtransaccion",new String[] {ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO,
												SunatStringUtils.toNotNull(duaPrecedente.getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO),
												ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE,
												SunatStringUtils.toNotNull(duaPrecedente.getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE) });
						SolicitudRectificaService solicitudRectificaService = fabricaDeServicios.getService("despaduanero2.solicitudRectificaService");
						List<Map<String, Object>> lstSolEvalu = solicitudRectificaService.listByDocumentoByParameterMap(paramsCabSolrecti);
						tieneRegularizacion = CollectionUtils.isEmpty(lstSolEvalu) ? false : true;
					}
					caduManifPrece = duaPrecedente.getManifiesto().getCodaduamanif();
					fanoManifPrece = duaPrecedente.getManifiesto().getAnnmanif();
					tipoManifPrece = duaPrecedente.getManifiesto().getCodtipomanif();
					numeManifPrece = duaPrecedente.getManifiesto().getNummanif();
					fecVenRegimen = duaPrecedente.getFecfinacoregimen();
				}
				/**
				 * 1.3. el precedente debe tener levante autorizado
				 */
				if (fecAutLevante == null	|| 
					(fecAutLevante != null && SunatDateUtils.isDefaultDate(fecAutLevante))) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30529",new String[] {CDAprece}));			
				}
				/**
				 * 1.4. Si el regimen anticipado o urgente del deposito fue
				 * regularizado
				 */
			
				if (tieneDespPorRegularizar && !tieneRegularizacion) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30530",new String[] {CDAprece}));
				}
				/**
				 * 1.5. El manifiesto registrado en la DUa debe ser el mismo de
				 * la precedencia
				 */
				// Ya no se debe validar, ya que impide que en una misma declaracion se utilice varios precedentes de deposito con distinto manifiesto
//				if (!manifiestovalido(dua, caduManifPrece, tipoManifPrece, fanoManifPrece, numeManifPrece)){
//                        String annManifiesto = dua.getManifiesto().getAnnmanif() == null ? null: SunatStringUtils.substring(dua.getManifiesto().getAnnmanif().toString(),0,4);
//                        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30531",new String[] {dua.getManifiesto().getCodaduamanif()+
//                        		"-"+ annManifiesto+ "-"+ dua.getManifiesto().getCodtipomanif()+ "-" + dua.getManifiesto().getNummanif(),caduManifPrece + "-"+fanoManifPrece + "-"+ tipoManifPrece + "-"+ numeManifPrece}));
//				}
				/**
				 * 1.8. La fecha de fin de vigencia de la declaracion debe ser
				 * menor o igual a la fecha de fin de vigencia de la DUA
				 */
				if (fecVenRegimen == null || 
						(fecVenRegimen != null && SunatDateUtils.isDefaultDate(fecVenRegimen))) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30534",new String[] {CDAprece}));
					
				} else {
					if (SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia,
							fecVenRegimen, "COMPARA_SOLO_FECHA")) {
						if (!dua.getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)) {
							//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Permitira la destinaci�n tambien a los regimenes 20 y 21 cuando la dua de deposito se encuente vencido
							DataCatalogo catVigenciaValidacion_0024 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN, "0024", new java.util.Date());
							boolean flagVigencia_0024 = catVigenciaValidacion_0024 != null ? true : false;
							
							if(flagVigencia_0024 && (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME) || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA))){
								//Permitira la destinacion a los regimenes 20 y 21 si la dua de deposito se encuente vencido
							}else{
							//Fin M_SNADE255-2
							listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30535",new String[] {pcaduregpre + "-70-"+ pfanoregpre + "-"+ pndclregpre }));
							//Inicio M_SNADE255-2 - PercyHM 2016/07/14
							}
							//Fin M_SNADE255-2 - PercyHM 2016/07/14 
						}
					}

				}

			}

		}
		return listError;
	}

	/**
	 * Validaciones de Series del Precedente
	 */
	public List<Map<String, String>> valDetRegPreDeposito(
			Declaracion declaracion, DatoSerie serie,
			DatoRegPrecedencia precedente, Date fechaReferencia,
			String codTransaccion, String codCanal,Map<String,Object> listDuaCache, Map<String,Object> listSeriesCache) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Map<String, String> paramsDetDeclaracion = new HashMap<String, String>();

		String codregipre = precedente.getCodregipre();
		String pcaduregpre = precedente.getCodaduapre();
		String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
		String pndclregpre = precedente.getNumdeclpre();
		Integer pnume_serpr = precedente.getNumserpre();

		/**
		 * 1.6. La Serie del precedente deber� de existir, se busca inicialmente
		 * en el NSIGAD y luego en el ASIGAD
		 */
		paramsDetDeclaracion.put("cod_aduana", pcaduregpre);
		paramsDetDeclaracion.put("ann_presen", pfanoregpre);
		paramsDetDeclaracion.put("cod_regimen", codregipre);
		paramsDetDeclaracion.put("num_declaracion", pndclregpre);
		paramsDetDeclaracion.put("num_secserie", pnume_serpr.toString());
		String numDocTransp = new String();
		String codPuerEmbar = new String();
		String num_detalle = new String();
		Long numPartNandi = new Long(0);
		Date fecExpiraMerca = null;
		String codunifides = new String();

		//RTINEO OPTIMIZACION INICIO
		List<Map<String, Object>> duaPrecedente = getCacheDua(paramsDetDeclaracion,listDuaCache);
		//RTINEO OPTIMIZACION FINN
		if (CollectionUtils.isEmpty(duaPrecedente)) {
			//RTINEO OPTIMIZACION INICIO
			Seriesd seriesd =  getCacheSerieAsigad(paramsDetDeclaracion,listSeriesCache);
			//RTINEO OPTIMIZACION FIN
			if (seriesd == null) {
				/*INICIO-P34 PAS20165E220200126 AFMA*/
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30532",new String[] {serie.getNumserie().toString() ,pcaduregpre + "-" + pfanoregpre+ "-" +
								codregipre + "-" + pndclregpre + "-" + pnume_serpr}));

				/*FIN-P34 PAS20165E220200126 AFMA*/
				return listError;
			} else {
				// Obtenemos variables necesarias para la validacion de las reglas del ASIGAD
				numDocTransp = seriesd.getConoEmbar().trim();
				codPuerEmbar = seriesd.getPuerEmbar();
				numPartNandi = seriesd.getPartNandi();
				fecExpiraMerca = seriesd.getFecExpiraMerca();
				codunifides = seriesd.getUnidFides();
				num_detalle = ( seriesd.getNumdet()==null ? "0" : (SunatStringUtils.isNumeric(seriesd.getNumdet().trim()) ? seriesd.getNumdet().trim() : "0")); 
			}
		} else {
			// Obtenemos variables necesarias para la validacion de las reglas
			// del NSIGAD
			numDocTransp = duaPrecedente.get(0).get("NUM_DOCTRANSP").toString();
			codPuerEmbar = duaPrecedente.get(0).get("COD_PUER_EMBAR").toString();
			num_detalle = duaPrecedente.get(0).get("NUM_DETALLE").toString();
			numPartNandi = SunatNumberUtils.toLong(duaPrecedente.get(0).get("NUM_PARTNANDI"));
			fecExpiraMerca = (Date) duaPrecedente.get(0).get("FEC_EXPIRACION");
			codunifides = duaPrecedente.get(0).get("COD_UNIFISICA").toString();
		}

		/**
		 * 1.7 El documentro de transporte debe ser el mimsmo que se encuentra
		 * registrado en la serie de la DUA
		 */
		if (!documentotransportevalido(declaracion, serie, numDocTransp, codPuerEmbar, num_detalle)) {
			DatoDocTransporte docTransporteSerie=getDocTransporte(declaracion.getDua(), serie);
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30533",new String[] {serie.getNumserie().toString(),
						docTransporteSerie.getNumdoctransporte().toString() + "-" + docTransporteSerie.getCodpuerto().toString() + 
						" (DETALLE=" + SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(docTransporteSerie.getNumdetalle()))+ ") ",
						pnume_serpr.toString(),numDocTransp + "-" + codPuerEmbar+ " (DETALLE=" + num_detalle + ")"}));
			
		}
		/**
		 * 1.9 Valida la subpartida nacional si es diferente verificar la
		 * correlacion
		 */
		String substrCodTransaccion = codTransaccion.substring(2, 4);
		//Solo debe realizarse la validacion de la subpartida en la numeraci�n o la recti autom�tica, cuando no tiene canal, en ninguna diligencia debe realizarse.
		if (substrCodTransaccion.equals(ConstantesDataCatalogo.TRANSACCION_NUMERACION) 	|| !StringUtils.hasText(codCanal)) {			
			if (!SunatNumberUtils.isEqual(serie.getNumpartnandi(), numPartNandi)) {
				ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService"); 
				Long correl = funcionesService.getCorrelPartida(serie.getNumpartnandi(),numPartNandi, 0);
				if (SunatNumberUtils.isEqualToZero(correl)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30536",new String[] {serie.getNumpartnandi().toString(),
							serie.getNumserie().toString(), pnume_serpr.toString(),numPartNandi.toString()}));
				}
			}
		}
		/**
		 * 1.10 Valida la fecha de vencimiento de mercancia perecible con
		 * respecto a la fecha de numeraci�n o diligencia de la dua OJO Esta
		 * regla ya no va hasta que se genere la obligatoriedad
		 */
		//no se usa
		/*		if (!fecExpiraMerca.equals(null)
				&& !SunatDateUtils.isDefaultDate(fecExpiraMerca)) {
			if (SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia,
					fecExpiraMerca, "COMPARA_SOLO_FECHA")) {
				// listError.add(FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMap("30537",
				// new String[]
				// {serie.getNumserie().toString(),fecExpiraMerca.toString()}));
			}
		}*/

		/**
		 * 1.13 El tipo de unidad de medida de la serie de la DUA, debe ser el
		 * mismo de la serie del precedencte
		 */
		if (!serie.getCodunifis().trim().equals(codunifides.trim())) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30538",new String[] {serie.getCodunifis(),
					serie.getNumserie().toString(),codunifides, pnume_serpr.toString()}));
		}

		return listError;
	}
	
	
	/**
	 * Compara manifiesto de la dua con el del precedente
	 * @param dua
	 * @param caduManifPrece
	 * @param tipoManifPrece
	 * @param fanoManifPrece
	 * @param numeManifPrece
	 * @return
	 */
	/** Ya no va, restringe al uso de precedentes de embarques diferentes
	 *  obligando al usuario que realice n-duas por cada deposito
	 */
//	private boolean manifiestovalido(DUA dua, String caduManifPrece, String tipoManifPrece, String fanoManifPrece, String numeManifPrece){
//		String annManifiesto = dua.getManifiesto().getAnnmanif() == null ? null: SunatStringUtils.substring(dua.getManifiesto().getAnnmanif().toString(),0,4);
//		//Para casos de depositos numerados en SIGAD en el cual no contempla tipo de manifiesto, no se valida o se iguala al SDA
//		if (SunatStringUtils.isEqualTo(tipoManifPrece,"0") || SunatStringUtils.isEqualTo(tipoManifPrece,"00") ) {
//			tipoManifPrece = dua.getManifiesto().getCodtipomanif(); 
//		}
//		if (!SunatStringUtils.isEqualTo(dua.getManifiesto().getCodaduamanif(), caduManifPrece) || !SunatStringUtils.isEqualTo(annManifiesto, fanoManifPrece) ||
//				!SunatStringUtils.isEqualTo(dua.getManifiesto().getNummanif(),numeManifPrece)){
//				return false;
//		}
//		return true;
//	}
//	
	
   	/**
	 * Compara documento de transporte con el del precedente
	 * @param declaracion
	 * @param serie
	 * @param numDocTransp
	 * @param codPuerEmbar
	 * @param num_detalle
	 * @return
	 */
	private boolean documentotransportevalido(Declaracion declaracion, DatoSerie serie, String numDocTransp, String codPuerEmbar, String num_detalle){
		DatoDocTransporte docTransporteSerie = new DatoDocTransporte ();
		DUA dua = declaracion.getDua();
		if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
			docTransporteSerie=getDocTransporte(declaracion.getDua(), serie);
			if (docTransporteSerie != null) {
				if (!SunatStringUtils.isEqualTo(docTransporteSerie.getNumdoctransporte().trim(),numDocTransp.trim()) || !SunatStringUtils.isEqualTo(docTransporteSerie.getCodpuerto(),codPuerEmbar)){
						return false;
				}
			} 
		}
		return true;
	}

		
	////////////////////Optimizacion //////////////////////////////////
	
	private Seriesd addToCacheAsigad(Map<String,String> paramsDetDeclaracion,Map<String,Object> listSeriesCache,String keyCache){
		String pcaduregpre = paramsDetDeclaracion.get("cod_aduana");
		String pfanoregpre = paramsDetDeclaracion.get("ann_presen");
		String pndclregpre = paramsDetDeclaracion.get("num_declaracion");
		Integer pnume_serpr = Integer.parseInt(paramsDetDeclaracion.get("num_secserie"));
		ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduanero = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
		Seriesd seriesdtemp = consultaDeclaracionDepositoAduanero.consultarSerieDeposito(pfanoregpre.substring(2, 4),pcaduregpre, SunatStringUtils.lpad(pndclregpre, 6, '0'), SunatStringUtils.lpad(String.valueOf(pnume_serpr.intValue()),4,' '));
		if(seriesdtemp != null){
			listSeriesCache.put(keyCache,seriesdtemp);
		}else{
			listSeriesCache.put(keyCache,null);
		}
		return seriesdtemp;
	}
	
	private Map<String,Object> findSerieOnCacheAsigad(Map<String,Object> listSeriesCache,String keyCache){
		Map<String,Object> mapSerie = new HashMap<String,Object>();
		if(listSeriesCache.containsKey(keyCache)){
			Seriesd seriesdTemp = (Seriesd)listSeriesCache.get(keyCache);
			if(seriesdTemp != null){
				mapSerie.put(keyCache, seriesdTemp);
				return mapSerie;
			}else return Collections.emptyMap();
		}
		//quiere decir que no ha consultado a la BD
		return null;
	}

	
	private Seriesd getCacheSerieAsigad(Map<String,String> paramsDetDeclaracion,Map<String, Object> listSeriesCache){
		String keyCache = paramsDetDeclaracion.get("cod_aduana").concat("-")
				.concat(paramsDetDeclaracion.get("ann_presen")).concat("-")
				.concat(paramsDetDeclaracion.get("cod_regimen")).concat("-")
				.concat(paramsDetDeclaracion.get("num_declaracion")).concat("-")
				.concat(paramsDetDeclaracion.get("num_secserie"));
		Map<String,Object> mapSerie = findSerieOnCacheAsigad(listSeriesCache,keyCache);
		if(mapSerie != null ){
			//validar si no es vacio el mapSerie
			if(!mapSerie.isEmpty()){
				return (Seriesd) mapSerie.get(keyCache);
			}
		}else{
			//se lee de la base de datos y se almacena en cache
			return (Seriesd)addToCacheAsigad(paramsDetDeclaracion,listSeriesCache,keyCache);
		}
		return null;
	}
	

	
	private List<Map<String, Object>> addToCache(Map<String,String> paramsDetDeclaracion,
			Map<String,Object> listDuaCache,String keyCache){
		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		List<Map<String, Object>> duaPrecedente = getDeclaracionService.getDetDUA(paramsDetDeclaracion);
		if(duaPrecedente != null){
			listDuaCache.put(keyCache,duaPrecedente);
		}else{
			listDuaCache.put(keyCache,null);
		}
		return duaPrecedente;
	}

	
	private List<Map<String,Object>> findDuaOnCache(Map<String,String> paramsDetDeclaracion,
			Map<String,Object> listDuaCache,String keyCache){
		if(listDuaCache.containsKey(keyCache)){
			List<Map<String,Object>> listTemp = (List<Map<String,Object>>)listDuaCache.get(keyCache);
			if(listTemp != null) return listTemp;
			else Collections.emptyList();
		}
		return null;
	}

	private List<Map<String, Object>> getCacheDua(Map<String,String> paramsDetDeclaracion,Map<String,Object> listDuaCache){
		String keyCache = paramsDetDeclaracion.get("cod_aduana").concat("-")
				.concat(paramsDetDeclaracion.get("ann_presen")).concat("-")
				.concat(paramsDetDeclaracion.get("cod_regimen")).concat("-")
				.concat(paramsDetDeclaracion.get("num_declaracion")).concat("-")
				.concat(paramsDetDeclaracion.get("num_secserie"));
		List<Map<String, Object>> duas = findDuaOnCache(paramsDetDeclaracion,listDuaCache,keyCache);
		if(duas == null ){
			duas = addToCache(paramsDetDeclaracion,listDuaCache,keyCache);
		}
		return duas;
	}

	/////// fin optimizacion ///////////
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

	/* INICIO - PAS20165E220300041 - RF02 - JHINOSTROZAN */
	/**
	 * Recibe un r�gimen de precedencia, busca y devuelve el codigo de dep�sito
	 * aduanero asociado
	 * 
	 * @param regPrecedente
	 *            Objeto que representa un regimen de precedencia
	 * @return Mapa que contiene el regimen de precedencia y el c�digo de
	 *         dep�sito aduanero
	 * @author jhinostrozan
	 */
	private Map<String, Map<String, Object>> getRUCDepositoAduaneroDeRegimenPrecedente(
			DatoRegPrecedencia regPrecedente) {
		Map<String, Map<String, Object>> respuesta = new HashMap<String, Map<String, Object>>();
		try {
			String rucDepositoAduanero = null;
			String codAduaPre = regPrecedente.getCodaduapre();
			String annDeclPre = regPrecedente.getAnndeclpre().toString()
					.substring(0, 4);
			String codRegiPre = regPrecedente.getCodregipre();
			String numDeclPre = regPrecedente.getNumdeclpre();
			Map<String, Object> parametros = new HashMap<String, Object>();
			// Buscamos el precedente en NSIGAD
			GetDeclaracionService getDeclaracionService = fabricaDeServicios
					.getService("declaracionService");
			DUA duaPrecedente = getDeclaracionService.getCabDUA(codAduaPre,
					numDeclPre, annDeclPre, codRegiPre);
			if (duaPrecedente == null) {
				// Si el precedente no se encuentra en NSIGAD, lo buscamos en
				// ASIGAD
				parametros.put("anoPrese", annDeclPre.substring(2, 4));
				parametros.put("numeCorre", numDeclPre);
				parametros.put("codiAduan", codAduaPre);
				ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduanero = fabricaDeServicios
						.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
				List<Polizad> listaPrecedentes = consultaDeclaracionDepositoAduanero
						.consultarDeclaracionDeposito(parametros, codAduaPre);
				if (!CollectionUtils.isEmpty(listaPrecedentes)) {
					// Si el precedente se encuentra en ASIGAD, buscamos el
					// n�mero
					// de documento de identidad del dep�sito aduanero
					Polizad precedente = listaPrecedentes.get(0);
					String codAntDepositoAduanero = precedente.getCodiDepo();
					OpecomextDAO opecomextDao = fabricaDeServicios
							.getService("Ayuda.opecomextDef");
					parametros = new HashMap<String, Object>();
					parametros
							.put("codTipOpera",
									ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO);
					parametros.put("codAduanero", codAntDepositoAduanero);
					Date fechaHoy = SunatDateUtils.getCurrentDate();
					SimpleDateFormat formato = new SimpleDateFormat(
							"dd/MM/yyyy");
					String resultadoHoy = formato.format(fechaHoy);
					Date fechaReferenciaNew = SunatDateUtils.getDate(
							resultadoHoy, "dd/MM/yyyy");
					parametros.put("fechaVigencia", fechaReferenciaNew);
					List<Map<String, Object>> listaOperadoresComercio = opecomextDao
							.findByMap(parametros);
					if (!CollectionUtils.isEmpty(listaOperadoresComercio)) {
						Map<String, Object> operadorComercio = listaOperadoresComercio
								.get(0);
						rucDepositoAduanero = (String) operadorComercio
								.get("num_ruc");
					}
				}
			} else {
				// Si el precedente se encuentra en NSIGAD, buscamos el n�mero
				// de
				// documento de identidad del dep�sito aduanero
				Long numCorreDoc = duaPrecedente.getNumcorredoc();
				ParticipanteService participanteService = fabricaDeServicios
						.getService("despaduanero2.participanteService");
				parametros = new HashMap<String, Object>();
				parametros.put("numeroCorrelativo", numCorreDoc);
				parametros
						.put("codTippartic",
								new String[] { ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_ADUANERO });
				List<Participante> listaParticipantes = participanteService
						.obtenerTipoParticipanteAutorizadoByCriterios(parametros);
				if (!CollectionUtils.isEmpty(listaParticipantes)) {
					// Si se encuentra el n�mero de documento de identidad
					Participante participante = listaParticipantes.get(0);
					rucDepositoAduanero = participante
							.getNumeroDocumentoIdentidad();
				}
			}
			Map<String, Object> resp = new HashMap<String, Object>();
			resp.put("regPrecedente", regPrecedente);
			resp.put("rucDepositoAduanero", rucDepositoAduanero);
			respuesta.put("precedenteConRucDepositoAduanero", resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respuesta;
	}

	/**
	 * Servicio que valida que cada serie de la DAM a destinar tenga como
	 * referencia una serie de una DAM de r�gimen precedente 70 y de ser asi,
	 * valida la equivalencia del c�digo de dep�sito aduanero de la DAM a
	 * destinar y los c�digos de dep�sito aduanero de los regimenes precedentes
	 * 
	 * @param declaracion
	 *            Objeto que representa una declaraci�n
	 * @return Lista de mapas que contienen los errores encontrados en la
	 *         validaci�n
	 * @author jhinostrozan
	 */
	public List<Map<String, String>> validarCodDepoPrecedentesIgualCodDepoDam(
			Declaracion declaracion) {
		List<Map<String, String>> respuesta = new ArrayList<Map<String, String>>();
		try {
			boolean esVigente971 = CollectionUtils
					.isEmpty(((CatalogoValidaService) fabricaDeServicios
							.getService("Ayuda.catalogoValidaService"))
							.validarElementoCat("380", "0023",
									SunatDateUtils.getCurrentDate()));
			if (esVigente971) {
				DUA dua = declaracion.getDua();
				String numRucLugarRecep = dua.getNumruclugarecep();
				if (!StringUtils.isEmpty(numRucLugarRecep)) {
					boolean declaracionTieneSeries = !CollectionUtils
							.isEmpty(dua.getListSeries());
					if (declaracionTieneSeries) {
						for (DatoSerie serie : dua.getListSeries()) {
							for (DatoRegPrecedencia regPrecedencia : serie
									.getListRegPrecedencia()) {
								if ("70".equals(regPrecedencia.getCodregipre())) {
									Map<String, Map<String, Object>> mapPrecedenteConRucDepositoAduanero = getRUCDepositoAduaneroDeRegimenPrecedente(regPrecedencia);
									if (!CollectionUtils
											.isEmpty(mapPrecedenteConRucDepositoAduanero)) {
										Map<String, Object> precedenteConRucDepositoAduanero = mapPrecedenteConRucDepositoAduanero
												.get("precedenteConRucDepositoAduanero");
										String rucDepositoAduanero = (String) precedenteConRucDepositoAduanero
												.get("rucDepositoAduanero");
										if (!StringUtils
												.isEmpty(rucDepositoAduanero)) {
											if (!numRucLugarRecep
													.equalsIgnoreCase(rucDepositoAduanero)) {
												// Flujo Alternativo
												// Se verifica que la serie de
												// la
												// DAM a destinar tiene como
												// referencia una serie de una
												// DAM
												// de r�gimen precedente 70 con
												// c�digo de dep�sito aduanero
												// distinto
												String CDAprecedente = regPrecedencia
														.getCodaduapre()
														.toString()
														+ "-"
														+ regPrecedencia
																.getAnndeclpre()
																.toString()
																.substring(0, 4)
														+ "-"
														+ regPrecedencia
																.getCodregipre()
																.toString()
														+ "-"
														+ regPrecedencia
																.getNumdeclpre()
																.toString();
												respuesta
														.add(((CatalogoAyudaService) fabricaDeServicios
																.getService("Ayuda.catalogoAyudaService"))
																.getError(
																		"35763",
																		new String[] {
																				serie.getNumserie()
																						.toString(),
																				rucDepositoAduanero,
																				CDAprecedente,
																				numRucLugarRecep }));
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respuesta;
	}
	/* FIN - PAS20165E220300041 - RF02 - JHINOSTROZAN */
}
