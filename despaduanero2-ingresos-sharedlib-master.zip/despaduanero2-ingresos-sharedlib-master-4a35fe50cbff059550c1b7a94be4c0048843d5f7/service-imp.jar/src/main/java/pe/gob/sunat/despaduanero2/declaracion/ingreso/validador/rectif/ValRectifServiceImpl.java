/*
 * Clase que define el servicio de validaciones de la rectificacion/regularizacion
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import net.sf.sojo.interchange.json.JsonSerializer;

//import com.saxonica.functions.map.MapCollation;



import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.despaduanero.despacho.entrada.pa.model.dao.Ratcc3DAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Depocta;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitCcDAO;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.CatEmpleadoDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabduaServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValModalidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidacionGeneralService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidacionOEAService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
//**P34 JMCV 3007 FIN**
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
//import pe.gob.sunat.despaduanero2.declaracion.model.Depocta;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.RectiOficioDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
//**P34 JMCV 3007 INICIO**
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.manifiesto.model.Datado;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DatadoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.MovManifiestosActasDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.CabCtaCteGarDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.PadUsuGaraDAO;
import pe.gob.sunat.recauda2.garantia.service.CuentaCorrienteGarantiaService;  //PAS20165E220200001 - 20160106 mtorralba
import pe.gob.sunat.recauda2.garantia.service.GestionCtaCteGarNominalService;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;

/* Fin RIN10 3007 erodriguezb */
/**
 * @author hosorio
 *
 */
public class ValRectifServiceImpl extends ValDuaAbstract implements ValRectif{

	//private ProveedorFuncionesService funcionesService;
	//private DdpDAOService ddpDAOService;
	//private ValCabdua valCabdua;
	//private ValNegocNumeracFormA valNegocNumeracFormA;
	//private ComparatorFactoy comparatorFactoy;


	//mordonezl pase 70
	//private CatalogoAyudaService catalogoAyudaService;
	//private FabricaDeServicios fabricaDeServicios;
	//private ManifiestoService manifiestoService;
	//fin mordonezl
	/**
	 * Establece la dua como variable global de las validaciones.
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param codUsuario String
	 * @param annEnvio Integer
	 * @param numEnvio Long
	 * @param tipoSender String
	 * @param numeroDocumentoIdentidadSender String
	 * @param tipoDocumentoIdentidadSender String
	 * @param codTransaccion String
	 * @return el map
	 * @author hosorio
	 * @return
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3000, descServicio = "Almacenamiento de la variable declaracion")
	@ServInstDetAnnot(tipoRpta = { 0, 1, 1, 1, 1, 1, 1, 1, 1 }, nomAtr = { "this", "numOrden", "codUsuario", "annEnvio", "numEnvio", "tipoSender",
			"numeroDocumentoIdentidadSender", "tipoDocumentoIdentidadSender", "codTransaccion" })
	@OrquestaDespaAnnot(codServInstancia = 3000, numSecEjec = 330, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, Object> setupDeclaracion(Declaracion declaracion, String numOrden, String codUsuario, Integer annEnvio, Long numEnvio,
			String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String codTransaccion) {
		HashMap<String, Object> response = new HashMap<String, Object>();
		// NSR BUG:2760 20101222: A pedido de Cecilia Jauregui se completo ceros a la izquierda hasta 6 digitos para liquidaciones tipo 26
		for (DatoOtroDocSoporte doc : declaracion.getDua().getListOtrosDocSoporte()) {
			if (Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS.equals(doc.getCodtipodocasoc()) 
					&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())) {
				doc.setNumdocasoc(SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0'));
			}
		}
		ValCabdua valcabdua = (ValCabdua) fabricaDeServicios.getService("ValCabdua"); 
		response.putAll(valcabdua.setupDeclaracion(declaracion, numOrden, codUsuario, annEnvio, numEnvio,
				tipoSender, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, codTransaccion));
		Map<String, Object> variablesIngreso = (Map<String, Object>) response.get("variablesIngreso");
		// variablesIngreso.put("codTransaccion", codTransaccion);
		//pase105
		if(codTransaccion.equals("1003")){
			setupformobjvalproveedor(declaracion);
		}
		variablesIngreso.put("declaracion", declaracion);

		return response;
	}

	/**
	 * Setup manifiesto.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el map
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3001, descServicio = "Almacena el map del manifiesto")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3001, numSecEjec = 331, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, Object> setupManifiesto(Declaracion declaracion, Map<String, Object> variablesIngreso) {

		if (declaracion.getDua().getManifiesto() != null) {
			Map<String, Object> paramsMap = new HashMap<String, Object>();
			String annManif = "0";
			if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3)
				annManif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
			paramsMap.put("anioManifiesto", annManif);
			paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 6, ' '));
			paramsMap.put("aduana", declaracion.getDua().getManifiesto().getCodaduamanif());
			paramsMap.put("tipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif());
			paramsMap.put("viaTransporte", declaracion.getDua().getManifiesto().getCodmodtransp());
			CabManifiestoDAO manifiestoDAO = (CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO");
			Map<Object, Object> manifiestoMap = manifiestoDAO.getByNumeroAnioAduanaTipoManifTipoVia(paramsMap);
			variablesIngreso.put("manifiestomap", manifiestoMap);
		}

		return new HashMap<String, Object>();
	}


	//mordonezl pase70
	/**
	 * Setup manifiesto.
	 * 
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 * @return el map
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3001, descServicio = "Almacena el Manifiesto de base de datos")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3001, numSecEjec = 331, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, Object> cargarManifiestoBD(Declaracion declaracion, Map<String, Object> variablesIngreso) {

		if (declaracion.getDua().getManifiesto() != null && declaracion.getDua().getManifiesto().getNummanif()!=null && 
				declaracion.getDua().getManifiesto().getCodaduamanif()!=null && declaracion.getDua().getManifiesto().getAnnmanif()!=null && 
				declaracion.getDua().getManifiesto().getCodtipomanif()!=null && declaracion.getDua().getManifiesto().getCodmodtransp()!=null) {			

			if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3){
				DatoManifiesto manif=declaracion.getDua().getManifiesto();
				String codaduamanif = manif.getCodaduamanif();
				String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
				String nummanif = manif.getNummanif();
				String codmodtransp = manif.getCodmodtransp();
				String codtipmanif = manif.getCodtipomanif();

				boolean buscarManifiestoSigadActual = false;
				//buscarManifiestoSigadActual = ("4".equals(declaracion.getDua().getManifiesto().getCodmodtransp()) || "7".equals(declaracion.getDua().getManifiesto().getCodmodtransp()));
				buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(declaracion.getDua().getManifiesto().getCodmodtransp()) 
						|| ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(declaracion.getDua().getManifiesto().getCodmodtransp()));
				
				ManifiestoService manifiestoService =  fabricaDeServicios.getService("manifiesto.manifiestoService"); 
				//Manifiesto manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,buscarManifiestoSigadActual);

				/**PAS20181U220200049 inicio***/
				Manifiesto manifiestoBD = null;
				Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
				List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
				if(!ResponseListManager.responseListHasErrors(listaOMA)){
			 		boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
					buscarManifiestoSigadActual = true;//que busque en bdsigad y en sigad
					manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,buscarManifiestoSigadActual, 
							fechaReferencia,evaluarEER);			
			 	}else{/**PAS20181U220200049 fin***/
			 		manifiestoBD =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,buscarManifiestoSigadActual);
			 	}
				
				variablesIngreso.put("manifiestoBD", manifiestoBD);
			}		
		}		

		return new HashMap<String, Object>();
	}
	//fin mordonezl
	/**
	 * Establece la fecha de procesamiento para las reglas de negocio , para lass transacciones 1001,2001,2101,7001.
	 * 
	 * @param codTransaccion String
	 * @param declaracion Declaracion
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "F", codServicio = 3002, descServicio = "obtiene la fecha de procesamiento para  las reglas de negocio")
	@ServInstDetAnnot(tipoRpta = { 1, 0 }, nomAtr = { "codTransaccion", "documento" })
	@OrquestaDespaAnnot(codServInstancia = 3002, numSecEjec = 332, nomClase = "pe.gob.sunat.tecnologia.receptor.model.Mensaje")
	public Map<String, ?> obtfecvalidacion(String codTransaccion, Declaracion declaracion) {
		/*
		 * El sistema obtiene la fecha de procesamiento para las reglas de negocio. Desarrollar el algoritmo en base al c�digo de
		 * transacci�n en curso Transacciones : 1001 , 2001, 2101, 7001 -> fecha Actual Resto de transacciones aplicar �Si aun no existe
		 * declaraci�n en la tabla Cab_declara la Fecha a devolver es la Fecha Actual de lo contrario obtiene la fecha de la tabla
		 * Cab_declara campo FEC_DECLARACION �
		 */
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, Date> response = new HashMap<String, Date>();

        //Estructura OMA por transaccion y aduana
		CatalogoValidaService catalogoValidaService = fabricaDeServicios.getService("Ayuda.catalogoValidaService");
        String codigoAduana = "";
        if( declaracion.getPadre() != null)
        	codigoAduana = ((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden()!=null?((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden().toString():declaracion.getCodaduana().toString();
        else
        	codigoAduana = declaracion.getCodaduana();
        
        List<Map<String, String>> vigenciaOMA = catalogoValidaService.validarAsociacion("135", codigoAduana, codTransaccion, SunatDateUtils.getCurrentDate());
        if(vigenciaOMA ==null || vigenciaOMA.isEmpty()){
            if (declaracion.getNumdeclRef() != null) {
                            declaracion.getNumdeclRef().setCodregimen(declaracion.getDua().getCodregimen());
                            declaracion.getNumdeclRef().setCodaduana(codigoAduana);
            }
        }
		Map<String, String> resultado = existedua(declaracion);

		/* P14 - 3007 - Inicio - dhernandezv */
		/* CUS: 3007-01.10 - Inicio - dhernandezv */
		/*BUGP14:42-Refactorizacion*/
		if(CollectionUtils.isEmpty(resultado)){
			resultado = funcionesService.validarDeclaEstadosIndicadores(declaracion);
			if(!CollectionUtils.isEmpty(resultado)){
				return getDUAError(resultado.get("codigoError"), 
						new Object[] { SunatStringUtils.toNotNull(declaracion.getNumdeclRef().getNumcorre()), SunatStringUtils.toNotNull(declaracion.getNumdeclRef().getAnnprese()),
								SunatStringUtils.toNotNull(declaracion.getNumdeclRef().getCodregimen()), SunatStringUtils.toNotNull(declaracion.getNumdeclRef().getCodaduana()), });
			}
		}
		/* CUS: 3007-01.10 - Fin - dhernandezv */
		/* P14 - 3007 - Fin - dhernandezv */

		Date fechaValidacion = DateUtil.getToday();
		if (CollectionUtils.isEmpty(resultado)) {

			if (!SunatStringUtils.isStringInList(codTransaccion, "1001,2001,2101,7001")) {
				if (declaracion.getNumdeclRef() != null && declaracion.getNumdeclRef().getCodaduana() != null) {
					DUA dua = obtenerDuaBD(declaracion);
					if (dua != null) {
						fechaValidacion = dua.getFecdeclaracion();
					}
				}
			}
			response.put("fechaReferencia", fechaValidacion);
			return response;
		} else {
			return resultado;

		}
	}

	/**
	 * Servicio que almacena en el orquestador la declaracion obtenida de base de datos.
	 * 
	 * @param declaracion Declaracion
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3003, descServicio = "Almacena la declaracion obtenida de BD")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3003, numSecEjec = 333, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, Object> formobjval(Declaracion declaracion) {

		Map<String, Object> orquestadormap = new HashMap<String, Object>();
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		Declaracion declaracionBD = null;
		if (numdeclRef != null) {
			GetDeclaracionService declaracionService =  fabricaDeServicios.getService("declaracionService"); 
			declaracionBD = declaracionService.getDeclaracion(numdeclRef.getCodaduana(),
					new Integer(numdeclRef.getNumcorre()), new Integer(numdeclRef.getAnnprese()), numdeclRef.getCodregimen());
		}

		if (declaracionBD != null) {
			/* seteo al objeto transmitido el numero de correlativo (num_corredoc) pk (dato que no se compara en rectificacion) */
			declaracion.getDua().setNumcorredoc(declaracionBD.getDua().getNumcorredoc());
			// se setea el valor numcorrelatiovo , para el servicio de calculo de adeudo
			declaracion.setNumeroCorrelativo(declaracionBD.getDua().getNumcorredoc());
			declaracion.setNumeroDeclaracion(SunatNumberUtils.toLong(numdeclRef.getNumcorre()));
			/* seteo la fecha de declaracion obtenida (dato que no se compara en rectificacion) */
			declaracion.getDua().setFecdeclaracion(declaracionBD.getDua().getFecdeclaracion());
			declaracion.getDua().setAnnorden(declaracionBD.getDua().getAnnorden());
			/* seteo la fecha de recepcion obtenida*/
			declaracion.getDua().setFecRecep(declaracionBD.getDua().getFecRecep());
			/* seteo del Canal*/
			declaracion.getDua().setCodCanal(declaracionBD.getDua().getCodCanal());	
			/* seteo de la fecha de autorizacion de levante pase 2015- 51 arey*/
			declaracion.getDua().setFecAutlevante(declaracionBD.getDua().getFecAutlevante());
			/*seteo del codigo riesgo oea pase 16*/
			//declaracion.getDua().setCodRiesgoOea(declaracionBD.getDua().getCodRiesgoOea());	
			orquestadormap.put("declaracionBD", declaracionBD);
			
		}
		return orquestadormap;
	}

	public void setupformobjvalproveedor(Declaracion declaracion) {

		for (DAV dav : declaracion.getListDAVs()){
			if (!StringUtils.isEmpty(dav.getCodproveedor())) {
				//
				OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaService");
				Map<String, Object> proveedor = operadorAyudaService.getCatprovee(dav.getCodproveedor());
				if (!CollectionUtils.isEmpty(proveedor)){
					dav.setFlag("1");
					dav.getProveedor().setNumeroDocumentoIdentidad(dav.getCodproveedor());     		
				}

			}else{
				OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaService");
				Map<String, Object> proveedor = operadorAyudaService.getCatprovee(
						dav.getProveedor().getPais().getCodDatacat(),
						dav.getProveedor().getNombreRazonSocial());

				if(!CollectionUtils.isEmpty(proveedor)){
					dav.setFlag("2");
					dav.setCodproveedor(proveedor.get("ccodi_prov").toString());
					dav.getProveedor().setNumeroDocumentoIdentidad(proveedor.get("ccodi_prov").toString());

				}else{
					dav.setFlag("3");                
				}

			}

		}
	}

	/**
	 * Servicio que verifica que la Transacci�n sea la numero (1003, 2003, 2103, 7003).
	 * 
	 * @param codTransaccion String
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3004, descServicio = "verifica que la Transaccion sea de rectificacion")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "codTransaccion" })
	@OrquestaDespaAnnot(codServInstancia = 3004, numSecEjec = 334, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, String> transaccion(String codTransaccion) {
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		// String transaccion = declaracion.getCodtipotrans();
		if (!SunatStringUtils.isStringInList(codTransaccion, "1003,2003,2103,7003")) {
			resultadoError = getErrorMap("30251", "TRANSACCIONES NO PERMITIDAS");
		}
		return resultadoError;
	}

	/**
	 * Servicio que Valida que la declaraci�n Exista , Toma los Datos de la secci�n NumdeclRef.
	 * 
	 * @param declaracion Declaracion
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3005, descServicio = "Valida que la declaracion Exista")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3005, numSecEjec = 335, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, String> existedua(Declaracion declaracion) {

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();

		String codaduanaRef = numdeclRef != null ? numdeclRef.getCodaduana() : null;
		String annpreseRef = numdeclRef != null ? numdeclRef.getAnnprese() : null;
		String codregimenRef = numdeclRef != null ? numdeclRef.getCodregimen() : null;
		String numcorreRef = numdeclRef != null ? numdeclRef.getNumcorre() : null;

		if (SunatStringUtils.isEmptyTrim(codaduanaRef) || SunatStringUtils.isEmptyTrim(annpreseRef) || SunatStringUtils.isEmptyTrim(codregimenRef)
				|| SunatStringUtils.isEmptyTrim(numcorreRef)) {
			// LA DUA NO EXISTE : NUMERO {0} - A�O {1} - REGIMEN {2} - ADUANA {3}
			return getDUAError("30395", new Object[] { SunatStringUtils.toNotNull(numcorreRef), SunatStringUtils.toNotNull(annpreseRef),
					SunatStringUtils.toNotNull(codregimenRef), SunatStringUtils.toNotNull(codaduanaRef), });
		} else {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("codaduana", numdeclRef.getCodaduana());
			params.put("annpresen", numdeclRef.getAnnprese());
			params.put("codregimen", numdeclRef.getCodregimen());
			params.put("numdeclaracion", numdeclRef.getNumcorre());
			CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO"); 
			Integer cantDua = cabdeclaraDAO.countByParameterMap(params);

			if (cantDua != 1) {
				return getDUAError("30395", new Object[] { SunatStringUtils.toNotNull(numcorreRef), SunatStringUtils.toNotNull(annpreseRef),
						SunatStringUtils.toNotNull(codregimenRef), SunatStringUtils.toNotNull(codaduanaRef), });

			}
		}

		return resultadoError;
	}


	/**
	 * Servicio que Valida que se pueda rectificar los declarantes no habidos
	 *  para luego calcular percepci�n - BUG 17764
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param variablesIngreso Map<String,Object>  
	 * @return List
	 * @author arey
	 */
	public List<Map<String,String>> valEstadoDeclarante(Declaracion declaracion, String numOrden, Map<String,Object> variablesIngreso) {
		ValNegocNumeracFormA valNegocNumeracFormA =  (ValNegocNumeracFormA)fabricaDeServicios.getService("ValNegocNumeracFormA");
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		String numDocConsigAnterior=null;
		String numDocConsigActual=null;
		Boolean existeNoHabido = false;

		Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBD");
		if(declaracionBD!=null)
			numDocConsigAnterior=declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad(); 
		if(declaracion!=null) 
			numDocConsigActual=declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();

		List<Map<String,String>> listErrores = valNegocNumeracFormA.validacionesPreviasFormatoA( declaracion,numOrden,variablesIngreso);
		if(listErrores!=null && listErrores.size()>0){
			for(int i=0; i<listErrores.size() ; i++){
				Map mapErrores = (Map) listErrores.get(i);
				if(mapErrores.get("codError").equals("00716") || mapErrores.get("codError").equals("30742") 
						|| mapErrores.get("codError").equals("01098") || mapErrores.get("codError").equals("09098")){
					existeNoHabido=true;
				}
			}			 
		}
		if(SunatStringUtils.isEqualTo(numDocConsigActual, numDocConsigAnterior) && existeNoHabido){ //si son el mismo Ruc pero el estado cambi�
			Participante partic=declaracion.getDua().getDeclarante();
			String numeroDocumento = partic.getNumeroDocumentoIdentidad();
			DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
			Map mapDdp = ddpDAOService.findByPK(numeroDocumento);
			String estado = mapDdp!=null?(String)mapDdp.get("ddp_estado"):" ";	
			String flag22 = mapDdp!=null?(String)mapDdp.get("ddp_flag22"):" ";
			if(SunatStringUtils.include(estado, new String[]{"01","02","03","10", "11","12"}) || flag22.equals("12")){
				//dejar pasar quitando los errores de no habido
				for(int i=0; i<listErrores.size() ; i++){
					Map mapErrores = (Map) listErrores.get(i);
					if(!mapErrores.get("codError").equals("00716") && !mapErrores.get("codError").equals("30742") 
							&& !mapErrores.get("codError").equals("01098") && !mapErrores.get("codError").equals("09098")){
						listErr.add(mapErrores);						
					}
				}			 
			}	 
		}else{
			listErr.addAll(listErrores);//sino se muestra todos los errores incluido si es NoHabido por cambio de ruc.
		}


		return listErr;
	}

	/**
	 * Servicio que Valida si la rectificacion se puede hacer al trasmitir la regularizacion.
	 * 
	 * @param declaracion objeto transmitido
	 * @param declaracionBD objeto que contiene la informacion obtenida de la base de datos
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3006, descServicio = "Valida si la rectificacion se puede hacer al trasmitir la regularizacion")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3006, numSecEjec = 336, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> transmitioregul(Declaracion declaracion, Declaracion declaracionBD) throws Exception {
		/*
		 * Validar Si es necesario transmitir la regularizaci�n y si esta Rectificacion puede hacerse al realizar la Regularizaci�n. El
		 * sistema identifica la modalidad de la declaraci�n CAB_DECLARA.COD_MODALIDAD=03 (dATAcATALOGO TIPO 306), si esta es urgente,
		 * 
		 * se verifica si la declaraci�n fue diligenciada dILIGENCIA .FEC_DILIGENCIA <> 01/01/1901. Si la declaraci�n ha sido diligenciada
		 * se verifica si la declaraci�n esta regularizada (cab_declara.fec_regularizacion es diferente de 01/01/1901) En el caso no este
		 * regularizada se emite una error indicando al usuario que rectifique al transmitir la regularizaci�n de la Dua
		 */
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if (declaracionBD != null) {
			boolean tieneDiligencia = false;
			if (SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)) {

				Map<String, String> PkDocu = new HashMap<String, String>();
				PkDocu.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc().toString());
				// No obtener las que estan en revisi�n
				PkDocu.put("viewRevision","false");
				CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
				List<Map<String, Object>> lstdiligencias = cabdiligenciaDAO.findByDocumento(PkDocu);

				/* si tiene diligencias: basta que una tenga fecha diferente de default para que se considere como diligenciada */
				if (!CollectionUtils.isEmpty(lstdiligencias)) {

					for (Map<String, Object> diligencia : lstdiligencias) {
						//inicio gmontoya diligencia 2012
						if(!diligencia.get("COD_TIPDILIGENCIA").equals("06")){
							/*branch ingreso 2011-009 hosorio inicio 26/07/2011*/
							//String strFecDiligencia = (String) diligencia.get("FEC_DILIGENCIA");
							//Date fechaDiligencia = null;
							Date fechaDiligencia = (Date) diligencia.get("FEC_DILIGENCIA");
							/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
							/*
						if (StringUtils.hasText(strFecDiligencia)) {
							fechaDiligencia = DateUtil.stringToDate(strFecDiligencia);
							 */
							/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
							if (fechaDiligencia != null && !DateUtil.isDefaultDate(fechaDiligencia)) {
								tieneDiligencia = true;
								break;
							}
							/*branch ingreso 2011-009 hosorio inicio 26/07/2011*/
							//}
							/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
						}
						//fin gmontoya diligencia 2012
					}

					// si tiene diligencia se verifica que este regularizada
					if (tieneDiligencia) {
						DUA dua = declaracionBD.getDua();
						// si no esta regularizada se emite un error
						if (dua.getFecregulariza() == null || DateUtil.isDefaultDate(dua.getFecregulariza())) {
							resultadoError = getErrorMap("30253","RECTIFICAR AL TRANSMITIR LA REGULARIZACION");
						}
					}
				}
			}
		}
		return resultadoError;
	}
	//P34  EJHM
	/*
	 * Validar Si la declaraci�n se encuentra en rectificacion de oficio no permite la transmion de regulacion ni rectificacion electronica
	 */
	//	public Map<String, String> validarDeclaracionProcesoRectiOficio(Declaracion declaracion) throws Exception {
	//		
	//		
	//		String DescMensaje="RECTIFICACION";
	//		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
	//		if (declaracion != null) {
	//			
	//			RectificacionOficioService	 oficioService  =fabricaDeServicios.getService("diligencia.rectificacionOficio.rectificacionOficioService"); 
	//						boolean tieneRectificacionOficioEnProceso = oficioService.tieneRectificacionOficioEnProceso(declaracion.getDua().getNumcorredoc().toString());
	//						
	//						if (tieneRectificacionOficioEnProceso){
	//							resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("35291", new String[]{DescMensaje});
	//						}
	//		}
	//		return resultadoError;
	//	}
	//	

	//P34  EJHM

	/**
	 * Servicio que validar que no haya una rectificacion que en ese momento este en Evaluacion.
	 * Si 
	 * 03-Rectificacion Catalogo de Estado -363 Estados que no puede rectificar (02,03,04)
	 * 04-Regularizacion Ant Catalogo de Estado 329 Estados que no puede rectificar (01,03)
	 * 05-Regularizacion Urg Catalogo de Estado 329 Estados que no puede rectificar (01,03)
	 * @param declaracion objeto transmitido
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3007, descServicio = "Validar que no existe solicitudes de rectificacion en evaluacion")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3007, numSecEjec = 337, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Solrectieneval(Declaracion declaracion) {
		Map<String, String> resultadoError = new HashMap<String, String>();
		Map<String, Object> params = new HashMap<String, Object>();
		CabSolrectiDAO solirectificaDAO = (CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO");

		if (declaracion.getDua().getNumcorredoc() != null) {
			params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
			params.put("estadosrecti", new String[] { ConstantesDataCatalogo.COD_EST_RECTIFIC_EN_PROCESO_EVALUACION 
					/*hosorio inicio 04/04/2011*/
					,ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA
					,ConstantesDataCatalogo.COD_EST_RECTIFIC_ASIGNADA_ESPECIALISTA
					/*hosorio fin 04/04/2011*/
			}); // 04 en evaluacion ,02 y 03			
			params.put("codtransaccion",new String[] {ConstantesDataCatalogo.TRANSACCION_SOLICITUD_RECTIFICACION,
					SunatStringUtils.toNotNull(declaracion.getDua().getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_RECTIFICACION)});
			List<Map<String, Object>> lstSolEvalu = solirectificaDAO.listByDocumentoByParameterMap(params);
			if (!CollectionUtils.isEmpty(lstSolEvalu)) {
				// existe solicitudes en evaluacion
				//				resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30254",
				//						"EXISTE SOLICITUDES DE RECTIFICACION EN EVALUACION PARA LA DUA");
				//mordonezl pase 70
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				NumdeclRef numdeclRef= declaracion.getNumdeclRef();
				String codaduanaref=numdeclRef!=null?numdeclRef.getCodaduana():null;
				String codregimenref=numdeclRef!=null?numdeclRef.getCodregimen():null;
				String numcorreref=numdeclRef!=null?numdeclRef.getNumcorre():null;
				String annprese=numdeclRef!=null?numdeclRef.getAnnprese():null;

				resultadoError = catalogoAyudaService.getError( "30254", new String[] {
						codaduanaref,
						annprese,
						codregimenref,
						numcorreref} );
				//fin mordonezl

			}

		}

		// r2bz Lo mismo pero para solicitudes de Regularizacion, ya q maneja estados de la solicitud diferentes que las de rectificacion --- PAS20171U220200004 se agregan estados
		if (declaracion.getDua().getNumcorredoc() != null) {
			params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
			params.put("estadosrecti", new String[] { ConstantesDataCatalogo.COD_EST_REGULA_EN_PROCESO,ConstantesDataCatalogo.COD_EST_REGULA_RECEPCIONADA, ConstantesDataCatalogo.COD_EST_REGULA_ASIGNADA_ESPEC,
					ConstantesDataCatalogo.COD_EST_REGULA_EN_REVISION}); 
			params.put("codtransaccion",new String[] {ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO,
					SunatStringUtils.toNotNull(declaracion.getDua().getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_ANTICIPADO),
					ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE,
					SunatStringUtils.toNotNull(declaracion.getDua().getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE)});
			List<Map<String, Object>> lstSolEvalu = solirectificaDAO.listByDocumentoByParameterMap(params);
			if (!CollectionUtils.isEmpty(lstSolEvalu)) {
				// existe solicitudes en evaluacion
				//				resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30254",
				//						"EXISTE SOLICITUDES DE REGULARIZACION EN EVALUACION PARA LA DUA");
				//mordonezl pase 70
				//inicio gmontoya bug 17944
				NumdeclRef numdeclRef= declaracion.getNumdeclRef();
				String codaduanaref=numdeclRef!=null?numdeclRef.getCodaduana():null;
				String codregimenref=numdeclRef!=null?numdeclRef.getCodregimen():null;
				String numcorreref=numdeclRef!=null?numdeclRef.getNumcorre():null;
				String annprese=numdeclRef!=null?numdeclRef.getAnnprese():null;
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				resultadoError = catalogoAyudaService.getError( "30255", new String[] { // se actualiza mensaje de error si la Regularizacion se encuentra en Proceso
						codaduanaref,
						annprese,
						codregimenref,
						numcorreref} );

				//fin gmontoya bug 17944
				//fin mordonezl
			}

		}

		/*hosorio inicio 11/04/2011*/
		// No tiene canal es automatica
		// Si es una rectificaci�n de aprobaci�n autom�tica, se valida que no exceda de 5 rectificaciones al d�a por DUA.			
		DUA duaBD = obtenerDuaBD(declaracion);
		int nroMaximoRectificaAutom=5;
		if(SunatStringUtils.isEmptyTrim(duaBD.getCodCanal())){
			params = new HashMap<String, Object>();
			params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
			params.put("estadosrecti", new String[] { ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE}); // 01
			List<Map<String, Object>> lstSolRectifAuto = solirectificaDAO.listByDocumentoByParameterMap(params);
			int nroRectificacionesHoy=0;
			if(!CollectionUtils.isEmpty(lstSolRectifAuto)){
				for(Map<String,Object> mpSolRecti:lstSolRectifAuto){
					if (SunatDateUtils.sonIguales( (Date)mpSolRecti.get("fecSolicitud"), 
							SunatDateUtils.getCurrentDate(),SunatDateUtils.COMPARA_SOLO_FECHA)){
						nroRectificacionesHoy++;
						// si ya existen cinco rectificaciones automaticas
						if(nroRectificacionesHoy==nroMaximoRectificaAutom){
							resultadoError = getErrorMap("07207", "HA SUPERADO EL NUMERO DE SOLICITUDES DE RECTIFICACIONES POR DIA");
							break;
						}
					}
				}
			}


		}		
		/*hosorio fin 11/04/2011*/

		return resultadoError;
	}

	/**
	 * Servicio que obtiene las rectificaciones de oficio por parte de los especialistas.
	 * 
	 * @param declaracion objeto transmitido
	 * @return HashMap
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3008, descServicio = "Almacenamiento de las rectificaciones de oficio")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3008, numSecEjec = 338, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, Object> CamposRectiOficio(Declaracion declaracion) {
		/*
		 * Se identifica los campos que han sido modificados de oficio por parte de los especialistas TABLA DET_OFIRECTI y carga esta
		 * informacion en un MAP para ser usado con la validacion de los datos enviados a rectificar por parte del usuario*
		 */
		Map<String, Object> responsemap = new HashMap<String, Object>();
		// branch ingreso 2011-009 gmontoya 16 obtencion del canal
		if (declaracion.getDua().getNumcorredoc() != null) {
			CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
			Map<String, Object> par =new HashMap<String, Object>();
			par.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			Map<String,Object> mapDua=   cabdeclaraDAO.findDuaByNumCorreDoc(par);
			String codcanal=(String)mapDua.get("COD_CANAL");

			Boolean SiVerificar=false;

			//si tiene canal  se verifica que no el especialista no haya rectificado algun dato que se est� modificando en la rectificaci�n
			if(StringUtils.hasText(codcanal)){
				SiVerificar=true;
			}

			if(SiVerificar){
				RectiOficioDAO rectioficioDAO = (RectiOficioDAO)fabricaDeServicios.getService("rectioficioDAO");
				List<DetSolicitudRectificacionBean> lstRecOficio = null;
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("numcorredoc", declaracion.getDua().getNumcorredoc());
				// Codigo de el estado del Cambio 00 registrado, 01 aceptado 02 aceptado parcialmenet 03 aceptado totalmente
				//branch ingreso 2011-009  gmontoya 16
				//params.put("estadoscambio", new String[] { Constants.COD_ESTADO_CAMBIO_ACEPTADO_PARCIAL, Constants.COD_ESTADO_CAMBIO_ACEPTADO_TOTAL });
				//branch ingreso 2011-009  gmontoya 16
				params.put("tipoDiligencia", new String[] { "02","03","05","06","10" });
				//branch ingreso 2011-009 fin
				List<Map<String, Object>> lstRectOficioBd = rectioficioDAO.findRectiOficioByParams(params);
				if (!CollectionUtils.isEmpty(lstRectOficioBd)) {
					lstRecOficio = new ArrayList<DetSolicitudRectificacionBean>();
					JsonSerializer serializer = new JsonSerializer();
					for (Map<String, Object> recti : lstRectOficioBd) {
						Map<String, Object> key = new HashMap<String, Object>();
						Map<String, Object> datosRectiOficio = new HashMap<String, Object>();
						Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

						/**amancilla*/
						Long numCorreDoc = new Long(recti.get("numcorredoc").toString());
						String usuario =   recti.get("codusuregis").toString();

						String desclave = (String) recti.get("desclave");
						String desdata1 = (String) recti.get("desdata1");
						key = (Map<String, Object>) serializer.deserialize(desclave);
						//ini P28-part2 - bug 24001
						if(ConstantesDataCatalogo.TABLA_CONVENIOSERIE.equals(recti.get("codtabla"))) {
							datosRectiOficio = (Map<String, Object>) serializer.deserialize(desclave);
						} else {
							datosRectiOficio = (Map<String, Object>) serializer.deserialize(desdata1);
						}
						//fin P28-part2 - bug 24001
						if (!CollectionUtils.isEmpty(datosRectiOficio)) {
							for (String campo : datosRectiOficio.keySet()) {
								datos.put(campo.toUpperCase(), new DatoRectificacionBean(datosRectiOficio.get(campo)));
							}
						}
						//branch ingreso 2011-009 gmontoya 16
						DetSolicitudRectificacionBean solic = new DetSolicitudRectificacionBean(numCorreDoc,usuario,(String) recti.get("codtabla"), key,(String) recti.get("codtipdiligencia"));
						//branch ingreso 2011-009 fin
						DetSolicitudRectificacionBean tmpSolic = null;
						if (lstRecOficio.contains(solic)) {
							tmpSolic = lstRecOficio.get(lstRecOficio.indexOf(solic));
						} else {
							tmpSolic = solic;
						}

						tmpSolic.getDatosRectificados().putAll(datos);
						lstRecOficio.add(tmpSolic);
					}
					responsemap.put("rectificacionesOficio", lstRecOficio);
				}
			}
		}
		return responsemap;
	}

	/**
	 * Servicio que compara el objeto transmitido y el objeto de base de datos ,y genera una lista de cambios.
	 * 
	 * @param declaracion objeto transmitido
	 * @param declaracionBD objeto obtenido de Base de datos
	 * @param variablesIngreso Map<String,Object>
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3009, descServicio = "Comparacion de la Declaraciones")
	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3009, numSecEjec = 339, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, Object> Compobjvalobjnum(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception {
		/*
		 * El sistema Valida Campo Por Campo los objetos �ObjetoDUABD� y �ObjetoDUAXML� ( Comparaci�n de Campos transmitidos en la
		 * rectificaci�n vs. los datos que se encuentran en el sistema BBDD) Por Cada Campo en el que se detecten diferentes valores el
		 * sistema Grabara En memoria una lista con los Datos - Valor del Campo Antiguo - Valor del Campo Nuevo - Tag de Acceso al Campo
		 * (Como llegar al dato) - Nombre del campo de bbdd(referencia el Excel) - Nombre de la tabla de bbdd (referencia el excel ) los 2
		 * ultimos campos se usaran para grabar en la tabla DETSOLRECTI )
		 */
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, Object> orquestadormap = new HashMap<String, Object>();
		if (declaracionBD != null) {
			/*branch ingreso 2011-009 hosorio inicio*/
			//ComparadorDeclaracion rectificacionDua = new ComparadorDeclaracion();
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			//			ComparatorFactoy c = new ComparatorFactoy();
			ComparatorFactoy comparatorFactoy = fabricaDeServicios.getService("ingresos.comparatorFactoy"); 
			ComparadorDeclaracion rectificacionDua = (ComparadorDeclaracion)comparatorFactoy.getComparador(codTransaccion);
			/*branch ingreso 2011-009 hosorio fin*/
			rectificacionDua.setObjnuevo(declaracion);
			rectificacionDua.setObjanterior(declaracionBD);
			//PAS20145E220000090 - MATC 20140614 INICIO
			rectificacionDua.setEnviaFechaLlegada(funcionesService.esFechaLlegada(declaracion.getDua(), declaracionBD.getDua().getFecdeclaracion(),codTransaccion));
			//PAS20145E220000090 - MATC 20140614 FINAL
			// inicia el proceso de comparacion
			rectificacionDua.comparacion();
			SolicitudRectificacionBean solicitudRectificacion = new SolicitudRectificacionBean();
			solicitudRectificacion.setListaCambios(rectificacionDua.getListaCambios());
			orquestadormap.put("solicitudRectificacion", solicitudRectificacion);
			variablesIngreso.put("solicitudRectificacion", solicitudRectificacion);
			/*hosorio inicio 15/08/2011*/
			variablesIngreso.put("declaracionBD", declaracionBD);
			/*hosorio fin 15/08/2011*/
		}
		return orquestadormap;
	}

	/**
	 * Servicio que valida si se esta rectificando un dato con retificacion de oficio, bloqueando este dato para no ser parte de la
	 * solicitud.
	 * 
	 * @param solicitudRectificacion objeto que reprensenta la solicitud de cambios
	 * @param rectificacionesOficio objeto que representa las rectificaciones de oficio
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3010, descServicio = "Comparacion rectificaciones de la declaracion y las de oficio")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "solicitudRectificacion", "rectificacionesOficio" })
	@OrquestaDespaAnnot(codServInstancia = 3010, numSecEjec = 340, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> Complistaconrectioficio(SolicitudRectificacionBean solicitudRectificacion,
			List<DetSolicitudRectificacionBean> rectificacionesOficio) throws Exception {
		/*
		 * El sistema Tomara la Lista Anterior y la Comparara con el map obtenido de la regla VALRECTI.CamposRectiOficio Agregando a la
		 * lista un atributo - Indicador de campo bloqueado de rectificar por parte de la Aduana Por cada campo Bloqueado el sistema
		 * generara un error al usuario ( se indicara el codigo de error , valor enviado por el usuario , valor registrado en bbdd ,Seccion
		 * de la Dua donde esta el Dato )
		 */

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		List<Map<String, String>> listaError = new ArrayList<Map<String, String>>();
		if (solicitudRectificacion != null) {
			List<DetSolicitudRectificacionBean> detSolRecti = solicitudRectificacion.getListaCambios();
			if (!CollectionUtils.isEmpty(rectificacionesOficio) && !CollectionUtils.isEmpty(detSolRecti)) {

				for (DetSolicitudRectificacionBean ro : rectificacionesOficio) {
					// el metodo contains usa lo metodos equals y hashcode sobreescritos en la clase DetSolicitudRectificacionBean
					if (detSolRecti.contains(ro)) {
						// el registro ha sufido rectificaciones de oficio
						int index = detSolRecti.indexOf(ro);
						/*branch ingreso 2011-009 hosorio inicio*/
						DetSolicitudRectificacionBean dsr=detSolRecti.get(index);

						/*branch ingreso 2011-009 hosorio fin*/
						for (String columnaRectOfi : ro.getDatosRectificados().keySet()) {
							/*branch ingreso 2011-009 hosorio inicio*/
							/*DatoRectificacionBean datoRectificado = (DatoRectificacionBean) detSolRecti.get(index).getDatosRectificados().get(
									columnaRectOfi);*/
							if (columnaRectOfi.equals(Constants.CAMPO_ELIMINACION_LOGICA) || columnaRectOfi.equals(Constants.CAMPO_REGISTRO_INACTIVO)) {
								continue;
							}
							DatoRectificacionBean datoRectificado = (DatoRectificacionBean) dsr.getDatosRectificados().get(
									columnaRectOfi);
							/*branch ingreso 2011-009 hosorio fin*/
							if (datoRectificado != null) {
								// la columna tiene rectificacion de oficio"
								//datoRectificado.setFlagBloqueo(Constants.IND_CAMPO_BLOQ_RECTIFI_ADUANA); /lmvr -  Se comenta porque afecta a la transaccion 1003
								// catalogoHelper
								//branch ingreso 2011-009 gmontoya 16
								String datonuevo="";
								if(datoRectificado.getDatoNuevo()!=null){
									datonuevo=datoRectificado.getDatoNuevo().toString();
									if(datoRectificado.getDatoNuevo() instanceof java.util.Date)
										datonuevo=SunatDateUtils.getFormatDate((Date)datoRectificado.getDatoNuevo(), "dd/MM/yyyy");

								}
								String datoantiguo="";
								if(datoRectificado.getDatoAntiguo()!=null){
									datoantiguo=datoRectificado.getDatoAntiguo().toString();
									if(datoRectificado.getDatoAntiguo() instanceof java.util.Date)
										datoantiguo=SunatDateUtils.getFormatDate((Date)datoRectificado.getDatoAntiguo(), "dd/MM/yyyy");

								}

								//amancilla
								//EL CAMPO {0}, CON VALOR {1} TRANSMITIDO FUE RECTIFICADO POR EL FUNCIONARIO ADUANERO {2} EN LA {3}.
								resultadoError = getErrorMap(
										"30256",new String[] { columnaRectOfi,datonuevo,getFuncionarioByDiligencia(ro.getCodUsuarioRegistro()),
												tipoDiligencia(ro.getTipodiligencia()), dsr.getKey().get("COD_TIPDESC")!=null?dsr.getKey().get("COD_TIPDESC").toString().concat("-"):"",
														dsr.getKey().get("NUM_SECITEM")!=null?(" EN LA SERIE: ").concat(dsr.getKey().get("NUM_SECITEM").toString()):""});//bug 20023
								/*columnaRectOfi + ": VALOR ENVIADO: " + datoRectificado.getDatoNuevo()
												+ " TIENE RECTIFICACION DE OFICIO. VALOR REGISTRADO EN BD: "
												+ ro.getDatosRectificados().get(columnaRectOfi).toString() + ", SECCION DE LA DUA: "
												+ datoRectificado.getXmlPath());*/
								//branch ingreso 2011-009 fin
								listaError.add(resultadoError);
							}
							/*branch ingreso 2011-009 hosorio inicio*/
							else if (SunatStringUtils.isEqualTo(dsr.getTipoCambio(), "A")){
								resultadoError = getErrorMap(
										"30489",new String[] { columnaRectOfi,tipoDiligencia(ro.getTipodiligencia()), ro.getDatosRectificados().get(columnaRectOfi).getDatoAntiguo()!=null?ro.getDatosRectificados().get(columnaRectOfi).getDatoAntiguo().toString():""});//bug 20023

								listaError.add(resultadoError);

							}
							/*branch ingreso 2011-009 hosorio fin*/


						}

					}
				}
			}
		}
		return listaError;

	}

	//amancilla 
	public String getFuncionarioByDiligencia(String codigoRegistroTrabajador)
	{

		FiltroCatEmpleado filtroCatEmpleado = new FiltroCatEmpleado();
		filtroCatEmpleado.setCodPers(codigoRegistroTrabajador);

		CatEmpleadoDAO catEmpleadoDAO =  fabricaDeServicios.getService("asignacion.catEmpleadoDAO"); 
		CatEmpleado empleado = catEmpleadoDAO.consultarCatEmpleado(filtroCatEmpleado);

		StringBuilder sb = new StringBuilder(); 
		sb.append(empleado.getNombres());
		sb.append(" ");
		sb.append(empleado.getApPate());
		sb.append(" ");
		sb.append(empleado.getApMate());

		return sb.toString();  		
	}

	//branch ingreso 2011-009 gmontoya 16
	private String tipoDiligencia(String codigo){
		if(codigo.equals("02")||codigo.equals("03")){
			return "DILIGENCIA DE DESPACHO";
		}
		if(codigo.equals("05")){
			return "DILIGENCIA CONCLUSI�N DE DESPACHO";
		}
		if(codigo.equals("06")){
			return "DILIGENCIA DE RECTIFICACI�N";
		}
		if(codigo.equals("10")){
			return "RECTIFICACI�N DE OFICIO";
		}		
		return "";
	}
	//branch ingreso 2011-009 fin
	/**
	 * Servicio que valida si tiene diligencia por duda razonable , y bloquea la rectificacion de los campos FOB, Flete, Partida,
	 * Indicadores antidumping.
	 * 
	 * @param declaracion objeto que representa la declaracion
	 * @param solicitudRectificacion objeto que reprensenta la solicitud de cambios
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3011, descServicio = "Bloquea campos de rectificacion por duda razonable")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "solicitudRectificacion" })
	@OrquestaDespaAnnot(codServInstancia = 3011, numSecEjec = 341, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Tienedudaraz(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion) throws Exception {
		/*
		 * Se valida la declaraci�n para ver si esta tiene diligencia por Duda Razonable En la tabla diligencia.cod_tipdiligencia ='08' de
		 * ser as� El sistema Tomara la Lista anterior y Bloqueara la rectificaci�n de los Datos de FOB, Flete, Partida, Indicadores
		 * antidumping , entre otros (Adecuar el codigo para que seha facilavgregar mas campos ) , que incidan en la liquidaci�n
		 */
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();

		if (declaracion.getDua().getNumcorredoc() != null) {
			List<DetSolicitudRectificacionBean> detalleSolicitud = solicitudRectificacion.getListaCambios();
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numcorredoc", declaracion.getDua().getNumcorredoc());
			params.put("codtipdiligencia", Constants.COD_TIP_DILIG_DUDA_RAZONABLE);
			CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
			int cont = cabdiligenciaDAO.count(params);
			// tiene diligencias por duda razonable
			if (cont > 0) {
				resultadoError = getErrorMap("30259",
						"LA DECLARACION TIENE DUDA RAZONABLE");
				// FOB T0054 DET_DECLARA.MTO_FOBDOL
				bloquearCampo(ConstantesDataCatalogo.TABLA_DET_DECLARA, "MTO_FOBDOL", detalleSolicitud);
				// Flete T0054 MTO_FLETEDOL
				bloquearCampo(ConstantesDataCatalogo.TABLA_DET_DECLARA, "MTO_FLETEDOL", detalleSolicitud);
				// Partida T0054 NUM_PARTNANDI
				bloquearCampo(ConstantesDataCatalogo.TABLA_DET_DECLARA, "NUM_PARTNANDI", detalleSolicitud);
				// Indicadores antidumping "T0054" COD_PRODANTID
				bloquearCampo(ConstantesDataCatalogo.TABLA_DET_DECLARA, "COD_PRODANTID", detalleSolicitud);
			}
		}
		return resultadoError;

	}

	/**
	 * Servicio que valida que no se rectifique el agente.
	 * Validar que no se este intentando rectificar el Agente Tabla ParticipanteDUA tipo operador '41' El sistema en funci�n de la lista
	 * anterior verificara que no se intente Cambiar los campos del Agente que numera la declaraci�n numdocumento y codtipooper de la
	 * clase DUA del objeto de validaci�n
	 * 
	 * @param solicitudRectificacion objeto que reprensenta la solicitud de cambios
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	/*
	@ServicioAnnot(tipo = "V", codServicio = 3012, descServicio = "Valida que no se rectifica el agente")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "solicitudRectificacion" })
	@OrquestaDespaAnnot(codServInstancia = 3012, numSecEjec = 342, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Norectifiagente(SolicitudRectificacionBean solicitudRectificacion) throws Exception {
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if (solicitudRectificacion != null) {
			List<DetSolicitudRectificacionBean> detalleSolicitud = solicitudRectificacion.getListaCambios();
			// busca en las rectificaciones los object path de numdocumento y codtipooper
			if (!CollectionUtils.isEmpty(getDatoRectByObjectPath("dua.numdocumento", detalleSolicitud))
					|| !CollectionUtils.isEmpty(getDatoRectByObjectPath("dua.codtipooper", detalleSolicitud))) {
				resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30260", "DATOS DEL AGENTE RECTIFICADOS");
			}
		}

		return resultadoError;
	}

	 */
	@ServicioAnnot(tipo = "V", codServicio = 3013, descServicio = "valida transmision formato B , antes de rectificacion")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3013, numSecEjec = 343, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Tieneformatob(Declaracion declaracionBD) throws Exception {

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if (declaracionBD != null) {
			if (CollectionUtils.isEmpty(declaracionBD.getListDAVs())) {
				resultadoError = getErrorMap("30261",
						"NO TIENE FORMATO B. TRANSMITIR VIA LA TRANSACCION DE ENVIO COMPLEMENTARIO DE FORMATO B");
			}
		}
		return resultadoError;

	}

	/**
	 * Servicio que valida que en caso de ser afecta a la ley de exigibilidad ,la fecha de termino declarada en rectificacion sea igual a la
	 * fecha de descarga declarada en el manifiesto.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3014, descServicio = "valida afectacion de exigibilidad Art 15 LGA")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3014, numSecEjec = 344, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Afectaart15lga(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception {
		/*
		 * El sistema identifica si la declaraci�n es afecta al Art 15 de la LGA (Exigibilidad) , Se verifica si la fecha de la dua es mayor
		 * a el 26/08/2008 fec_declaracion - Si esta afecta, se obtiene la fecha de descarga de la tabla de manifiestos
		 * (MANIFIESTO.FEC_DESCARGA ) y valida que la fecha de descarga declarada en el manifiesto coincida con la fecha de termino de la
		 * descarga transmitido en la rectificaci�n (CAB_DECLARA.FEC_TERM) o Si ambas fechas no coinciden Emite una alerta indicando esta
		 * diferencia y setea los objetos ObjetoDUABD y ObjetoDUAXML para trabajar con la Fecha del manifiesto de manera que esta fecha sea
		 * la usada en el resto de validaciones - De no ser as� emite una alerta �Fecha de descarga del manifiesto declarado en la DUA no
		 * coincide con la informaci�n registrada en manifiestos , se tomara informaci�n de manifiesto�
		 */
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		boolean exigibilidad = false;
		if (declaracion.getDua().getNumcorredoc() != null) {
			if (declaracion.getDua().getFecdeclaracion() != null
					&& declaracion.getDua().getFecdeclaracion().after(DateUtil.stringToDate("26/08/2008"))) {
				exigibilidad = true;
			}
		}

		if (exigibilidad) {

			Map<Object, Object> manifiestoMap = (Map<Object, Object>) variablesIngreso.get("manifiestomap");
			if (!CollectionUtils.isEmpty(manifiestoMap)) {
				Date dtFecDescarga = (Date) manifiestoMap.get("fechaTerminoDeDescarga");

				DatoManifiesto manif = declaracion.getDua().getManifiesto();
				Date dtFecTermino = manif != null ? manif.getFectermino() : null;
				// Si ambas fechas no coinciden Emite una alerta indicando esta diferencia y setea los
				// objetos ObjetoDUABD y ObjetoDUAXML para trabajar con la Fecha del manifiesto de manera
				// que esta fecha sea la usada en el resto de validaciones

				int intFecDescarga = SunatDateUtils.getIntegerFromDate(dtFecDescarga);
				int intFecTermino = SunatDateUtils.getIntegerFromDate(dtFecTermino);

				//PAS20145E220000090 - MATC 20140707  INICIO
				if( dtFecTermino!=null && SunatDateUtils.sonIguales(dtFecTermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
					intFecTermino = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecLlegada());
				}
				//PAS20145E220000090 - MATC 20140707  FINAL

				if ( intFecTermino != intFecDescarga ) {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					// declaracionBD.getDua().getManifiesto().setFectermino(dtFecDescarga);
					declaracion.getDua().getManifiesto().setFectermino(dtFecDescarga);
					// warning
					//resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30262");
					String FecTermino = Integer.toString(intFecTermino);
					String FecDescarga = Integer.toString(intFecDescarga);					
					resultadoError = catalogoAyudaService.getError("30262", new String[] {FecTermino, FecDescarga});					
					variablesIngreso.put("fecterminoRectificado", true);
				}
				else {
					//PAS20145E220000090 - MATC 20140707  INICIO
					if( dtFecTermino!=null && SunatDateUtils.sonIguales(dtFecTermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
						declaracion.getDua().getManifiesto().setFectermino(dtFecDescarga);
					}
					//PAS20145E220000090 - MATC 20140707  FINAL
				}
			}
			/*
			 * else{ resultadoError=RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30262"); }
			 */
		}
		return resultadoError;
	}

	/**
	 * Servicio que valida la cuenta corriente para importar vehiculos usados.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @param declaracionBD Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3015, descServicio = "valida cuenta corriente tpn vehiculos usados")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3015, numSecEjec = 345, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Valtpnvehiculo(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception {
		/*
		 * Si agrega TPN para importar veh�culos (listado de comparaci�n) se verifica si dicho tpn puede ser usado para importar veh�culos
		 * verificando la cuenta corriente de la tabla (tabla CANTMAXLIBE ) , Se compara lo registrado en la tabla CONVENIOSERIE con
		 * CANTMAXLIBE para ver si los tpn coinciden , si es asi aplica esta validacion , sino no si valida
		 */
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, String> resultadoError = new HashMap<String, String>();
		if (declaracionBD != null) {
			// si en la rectificacion declara autos usado
			if (funcionesService.isAutoUsa(declaracion.getDua())) {
				// y si en la base de datos no esta declarado como autos usado
				if (!funcionesService.isAutoUsa(declaracionBD.getDua())) {
					ValidacionGeneralService validaciongeneralservice = fabricaDeServicios.getService("validaciongeneralservice");
					// si es vehiculo usado , declaracion.getDua().getListSeries()se valida la cta corriente de vehiculos usados
					resultadoError = validaciongeneralservice.verificaCtaCteVehiUsado(declaracion,variablesIngreso);

				}
			}
		}

		return resultadoError;

	}

	/**
	 * Marca afecta desafecta cuenta auto usado.
	 * 
	 * @param declaracion Declaracion
	 * @param declaracionBD Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el map
	 * @throws Exception excepci�n exception
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3017, descServicio = "Identifica si la declaracion afecta o desafecta la cta cte de vehiculos usados")
	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3017, numSecEjec = 347, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> MarcaAfectaDesafectaCuentaAutoUsado(Declaracion declaracion, Declaracion declaracionBD,
			Map<String, Object> variablesIngreso) throws Exception {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, String> response = new HashMap<String, String>();

		if (declaracionBD != null) {
			// si en la rectificacion declara autos usado
			if (funcionesService.isAutoUsa(declaracion.getDua())) {
				// y si en la base de datos no esta declarado como autos usado => afecta
				if (!funcionesService.isAutoUsa(declaracionBD.getDua())) {

					// si es vehiculo usado , declaracion.getDua().getListSeries()se valida la cta corriente de vehiculos usados
					ValidacionGeneralService validaciongeneralservice = fabricaDeServicios.getService("validaciongeneralservice");
					Map<String, String> resultadoError = validaciongeneralservice.verificaCtaCteVehiUsado(declaracion, variablesIngreso);

					if (CollectionUtils.isEmpty(resultadoError)) {
						// afecta
						response.put("IndAfectaDesafectaCtaCteVehiUsado", Constants.IND_AFECTA_CUENTA_CTE);
						variablesIngreso.put("IndAfectaDesafectaCtaCteVehiUsado", Constants.IND_AFECTA_CUENTA_CTE);

					}

				}
			} else { // si en la rectificacion no declara autos usado

				if (funcionesService.isAutoUsa(declaracionBD.getDua())) {
					// y sin en la base de datos esta declarado autos usados=> desafecta
					response.put("IndAfectaDesafectaCtaCteVehiUsado", Constants.IND_DESAFECTA_CUENTA_CTE);
					variablesIngreso.put("IndAfectaDesafectaCtaCteVehiUsado", Constants.IND_DESAFECTA_CUENTA_CTE);
				}

			}
		}
		return response;
	}

	/**
	 * Servicio que valida que si la declaracion tiene canal , esta ya haya sido datada ,de lo contrario no es obligatorio el datado.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	//NSR: 28/12/2010: Deshabilitamos este servicio que no permite rectificar, ya que puede darse el caso de duas con canal y que no daten
	//ademas posterior al canal todas las rectificaciones se hacen con diligencia de rectificaci�n.
	//@ServicioAnnot(tipo="V",codServicio=3018, descServicio="valida si declaracion fue datada")
	//@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	//@OrquestaDespaAnnot(codServInstancia=3018,numSecEjec=348,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	//public Map<String, String> Estadodatado(Declaracion declaracion) throws Exception{
	//
	//	/*Validar que la declaraci�n ya haya sido datada si tuviese canal */
	//	java.util.Map<String, String> resultadoError = new HashMap<String, String>();
	//	if(declaracion.getDua().getNumcorredoc()!=null){
	//
	//		String codCanal=RectificacionServiceImpl.getInstance().getCabdeclaraDAO().findCanalDua(declaracion.getDua().getNumcorredoc().toString());
	//
	//		// Si tiene canal ya debio ser datado
	//		if(!SunatStringUtils.isEmptyTrim(codCanal)){
	//			Map<String,Object> paramsMap=new HashMap<String, Object>();
	//			paramsMap.put("detalleNumeroCorrelativo", declaracion.getDua().getNumcorredoc());
	//			List<Datado> lstDatado= RectificacionServiceImpl.getInstance().getDatadoDAO().listByParameterMap(paramsMap);
	//			if(!CollectionUtils.isEmpty(lstDatado)){
	//				// cojo el primero por que , lo unico que se desea saber es si tiene fecha de datado
	//				Datado datado=lstDatado.get(0);
	//				// si la fecha de datado no es vacio ni es diferente al valor por defecto
	//				// entonces es un datado valido
	//				if( datado.getFechaDatado()== null ||
	//						DateUtil.isDefaultDate(datado.getFechaDatado()) ){
	//					resultadoError= RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30264", "LA DUA NO HA SIDO AUN DATADA");
	//				}
	//
	//			}
	//			else resultadoError= RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30264", "LA DUA NO HA SIDO AUN DATADA");
	//
	//		}
	//	}
	//	return resultadoError;
	//}

	/**
	 * Servicio que valida en los despachos anticipado o urgente que la declaracion pueda ser datada , en caso no lo este.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @param variablesIngreso Map<String,Object>
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3019, descServicio = "valida si se puede datar")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3019, numSecEjec = 349, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	// public Map<String, Object> Infoparadatado(Declaracion declaracion,Map<String, Object> variablesIngreso) throws Exception{
	//NSR: Este servicio solo aplica para regularizaci�n, no asociar a transacciones de Rectificaci�n
	public List<Map<String, ?>> Infoparadatado(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception {
		/*
		 * En el caso sea declaraci�n de modalidad Anticipado o urgente CAB_DECLARA.COD_MODALIDAD = 02 � 03 Se verifica el estado del
		 * despacho y en el caso que la declaraci�n aun no haya sido datada (DATADO. FEC_DATADO ) , Se valida que esta se puede datar con
		 * los datos enviados en la rectificaci�n Si las validaciones son Exitosas se deja una marca par que se realice el datado al momento
		 * de grabar la rectificaci�n
		 */
		// Map<String, Object> orquestadormap = new HashMap<String, Object>();
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		String codTransaccion = variablesIngreso.get("codTransaccion").toString();
		boolean isTxDilig = funcionesService.isTransaccionDiligencia(codTransaccion);


		List<Map<String, ?>> resultadoError = new ArrayList<Map<String, ?>>();
		if (declaracion.getDua().getNumcorredoc() != null) {
			/* caso sea declaraci�n de modalidad Anticipado o urgente CAB_DECLARA.COD_MODALIDAD = 02 � 03 */
			if (declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)
					|| declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)) {
				{
					boolean tienedatado = false;					
					if (codTransaccion.endsWith("03") || isTxDilig){//Solo para rectificaci�n
						Map<String, Object> paramsMap = new HashMap<String, Object>();
						paramsMap.put("detalleNumeroCorrelativo", declaracion.getDua().getNumcorredoc());
						DatadoDAO datadoDAO = fabricaDeServicios.getService("datadoDAO");
						List<Datado> lstDatado = datadoDAO.listByParameterMap(paramsMap);
						if (!CollectionUtils.isEmpty(lstDatado)) {
							tienedatado = true;
						}
					}
					// si fecha datado es nula , entonces no tiene datado
					if (!tienedatado) {
						/*
						 * y en el caso que la declaraci�n aun no haya sido datada (DATADO. FEC_DATADO ), Se valida que esta se puede datar
						 * con los datos enviados en la rectificaci�n
						 */

						// las validaciones para ver si se puede datar ser�n un servicio del grupo de manifiestos
						DatoManifiesto manif = declaracion.getDua().getManifiesto();
						if (manif != null && manif.getCodaduamanif() != null && manif.getAnnmanif() != null && manif.getNummanif() != null
								&& manif.getCodmodtransp() != null) {

							//							Date fecProgramadaLlegada = manif.getFectermino();
							//							Date fechaReferencia = (Date)variablesIngreso.get("fechaReferencia");
							//							if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fecProgramadaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){
							//								variablesIngreso.put("esUrgenteAnticipada", true);
							//								variablesIngreso.put("esUrgenteExcepcional", false);
							//							} else {
							//								variablesIngreso.put("esUrgenteAnticipada", true);
							//								variablesIngreso.put("esUrgenteExcepcional", false);
							//							}
							ValidacionGeneralService validaciongeneralservice = fabricaDeServicios.getService("validaciongeneralservice");
							resultadoError = validaciongeneralservice.validarDatado(declaracion, variablesIngreso);
							if (CollectionUtils.isEmpty(resultadoError)) {
								// si no tiene erroes
								// orquestadormap.put("marcaRealizarDatado", true);
								variablesIngreso.put("marcaRealizarDatado", true);

							} else
								return resultadoError;
						} else {

						}

					}
				}
			}
		}
		return resultadoError;
	}

	/**
	 * Servicio que valida si requiere desdatado datado ,producto de un cambio en los bultos y pesos, en dicho caso deja un marca para
	 * desdatar y datar.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @param declaracionBD Declaracion
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3020, descServicio = "valida si requiere desdatado datado")
	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion", "variablesIngreso", "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3020, numSecEjec = 350, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, ?>> Marcadesdatadodatado(Declaracion declaracion, Map<String, Object> variablesIngreso, Declaracion declaracionBD)
			throws Exception {
		/*
		 * Si la rectificaci�n incide en alg�n dato asociado al manifiesto (bultos y pesos) debe modificar la informaci�n grabada en tabla
		 * datado , Se debe dejar una marca en memoria para que al grabar se realice el proceso de desdatado y datado de manera que se
		 * actualicen los montos en el registro de datado
		 */
		List<Map<String, ?>> lsterrores = new ArrayList<Map<String, ?>>();

		if (declaracion.getDua().getNumcorredoc() != null) {
			SolicitudRectificacionBean solicitudRectificacion = (SolicitudRectificacionBean) variablesIngreso.get("solicitudRectificacion");
			List<DetSolicitudRectificacionBean> detalleSolicitud = solicitudRectificacion.getListaCambios();
			String ObjectPath = "cnttcantbulto";
			boolean pesoybultorectificado = false;
			// verificando si se ha rectificado cantidad de bultos
			List<DatoRectificacionBean> lstDatosRec = getDatoRectByObjectPath(ObjectPath, detalleSolicitud);
			if (CollectionUtils.isEmpty(lstDatosRec)) {
				ObjectPath = "cnttpesobruto";
				// verificando si se ha rectificado peso neto
				lstDatosRec = getDatoRectByObjectPath(ObjectPath, detalleSolicitud);
				if (!CollectionUtils.isEmpty(lstDatosRec))
					pesoybultorectificado = true;
			} else
				pesoybultorectificado = true;

			if (pesoybultorectificado) {

				// NSR: Ya no se valida desdatado, el servicio de grabado del datado verificar� si es necesario desdatar
				// antes de volver a datar

				//				lsterrores = RectificacionServiceImpl.getInstance().getValidaciongeneralservice().validarDatado(declaracion, variablesIngreso);
				//				if (CollectionUtils.isEmpty(lsterrores)) {
				//					variablesIngreso.put("marcaDesdatadoDatado", true);
				//				}
			}
		}

		DatoManifiesto manif = declaracion.getDua().getManifiesto();
		DatoManifiesto manifBD = declaracionBD.getDua().getManifiesto();

		// Si existe manifiesto registrado y no hay manifiesto en el envio, enviar error.
		if (manifBD != null && manifBD.getNummanif()!=null && manifBD.getNummanif().trim().length()>0
				&& !"0".equals(manifBD.getNummanif())) {//se cambia el isEmptyTrim Bug 17897 //se cambia por SAU201510002900150
			if (manif == null 
					|| SunatStringUtils.isEmptyTrim( manif.getCodaduamanif() ) 
					|| SunatStringUtils.isEmptyTrim( manif.getAnnmanif()  ) 
					|| SunatStringUtils.isEmptyTrim( manif.getNummanif()  )
					|| SunatStringUtils.isEmptyTrim( manif.getCodmodtransp() ) ) {

				String numManifiestoBD =  manifBD.getCodtipomanif()+"-"+manifBD.getCodaduamanif()+"-"+manifBD.getCodmodtransp()+"-"+manifBD.getAnnmanif()+"-"+manifBD.getNummanif();

				//CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

				//result = catalogoAyudaService.getError("30148", new String[] {numeroSecuenciaItem, montoFobUnitario});
// OMA PASE PAS20181U220200004
				lsterrores.add(ResponseMapManager.getErrorResponseMap("11515", "MANIFIESTO CONSIGNADO EN LA DECLARACI�N NO COINCIDE CON EL EXISTENTE: " +numManifiestoBD));
			}
		}

		return lsterrores;
	}

	/**
	 * Servicio que valida el estado del RUC del importado , debe estar vigente y la condicion de domicilio habido.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3021, descServicio = "valida el estado de ruc del importado")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3021, numSecEjec = 351, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Estadoruc(Declaracion declaracion) throws Exception {
		/*
		 * Se valida el estado del RUC del importador , este debe estar vigente y la condici�n de domicilio debe ser habido (RUC vigente y
		 * la condici�n del domicilio diferente a 00) a la fecha de la rectificaci�n
		 */
		DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
		Map<String, String> resultadoError = new HashMap<String, String>();
		if (declaracion.getDua().getNumcorredoc() != null) {
			// revisar si existe un servicio de data catalogo para realizar esta tarea
			//             Map<String, Object> mdpImportador = RectificacionServiceImpl.getInstance().getDdpDAO().findByPK(
			//                           declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().equals("4")){
				Map<String, Object> mdpImportador = ddpDAOService.findByPK(
						declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
				if (!CollectionUtils.isEmpty(mdpImportador)) {
					String vigenciaRuc = (String) mdpImportador.get("ddp_estado");
					String estadoDomicilio = (String) mdpImportador.get("ddp_flag22");
					// (RUC vigente (00,21) y la condici�n del domicilio diferente a 00)

					if (!vigenciaRuc.equals("00") && !vigenciaRuc.equals("21")) {
						resultadoError = getErrorMap("30267","ESTADO DE RUC DECLARANTE NO VIGENTE");
					}
					if (!estadoDomicilio.equals("00")) {
						resultadoError = getErrorMap("30267", "DOMICILIO DECLARANTE NO HABIDO");
					}
				} else {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					resultadoError = catalogoAyudaService.getError("30267");
				}
			}

		}
		return resultadoError;
	}


	/**
	 * Servicio que valida el cambio de modalidad.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3022, descServicio = "valida rectificacion de la modalidad")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3022, numSecEjec = 352, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Cambiomodalidad(Declaracion declaracion) throws Exception {
		Map<String, String> resultadoError = new HashMap<String, String>();

		/*
		 * El sistema valida la modalidad de manera que se pueda rectificar de: 
		 * CAB_DECLARA.COD_modalidad Anticipado ->Excepcional 02- >01
		 * Urgente ->Excepcional. 03 - 01 
		 * Excepcional -> urgente 
		 * y no se pueda rectificar de: Excepcional -> anticipado 
		 * Anticipado ->urgente 
		 * Urgente ->anticipado
		 */

		Map<String, Object> mapDuaBD = obtenerMapDua(declaracion);
		if (!CollectionUtils.isEmpty(mapDuaBD)) {
			String modalidadRecti = declaracion.getDua().getCodmodalidad();
			String modalidadBd = (String) mapDuaBD.get("codmodalidad");
			// si son distintos
			if (!modalidadRecti.equals(modalidadBd)) {
				/*
				 * Anticipado ->Normal 02- >01 Urgente ->normal. 03 - 01 Normal -> urgente
				 */
				if ((modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL))
						|| (modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL))
						) {
				} else {
					if ((modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO))) {
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						resultadoError = catalogoAyudaService.getError("30802");			
					} else {
						if ((modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)) ||
								(modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) ||
								(modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)))  {
						}else	{					
							resultadoError = getErrorMap("30268", "CAMBIO DE MODALIDAD NO PERMITIDA");
						}
					}
				}
			}
		}
		return resultadoError;
	}

	/**
	 * Servicio que valida si se ha enviado el sustento de rectificacion 
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3025, descServicio = "valida si se ha enviado el sustento de rectificacion")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3025, numSecEjec = 355, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Sustento(Declaracion declaracion) throws Exception {
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		boolean existeSustentoRectif = false;
		/*
		 * Validar que el usuario transmita el sustento de la rectificaci�n en la secci�n observaciones de la transmisi�n
		 * (codtipobserva='05' )
		 */

		Elementos<Observacion> listObservaciones = declaracion.getDua().getListObservaciones();
		if (!CollectionUtils.isEmpty(listObservaciones)) {
			for (Observacion obs : listObservaciones) {
				if (obs.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_RECTIFICACION)) {
					/*inicio hosorio 05/04/2011*/
					if (!SunatStringUtils.isEmpty(obs.getObsdeclaracion())){
						/*fin hosorio 05/04/2011*/
						existeSustentoRectif = true;
						break;
					}
				}
			}
		}

		if (!existeSustentoRectif) {
			resultadoError = getErrorMap("30272", "NO EXISTE SUSTENTO DE RECTIFICACION");
		}

		return resultadoError;
	}

	/**
	 * Servicio que identifica si la declaracion es afecta a ley de mergencia.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3026, descServicio = "valida si declaraci�n corresponde a la Ley de Emergencia ")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3026, numSecEjec = 356, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, Boolean> Afectaart150(Declaracion declaracion) throws Exception {
		/*
		 * Es ley de emergencia Si tipo tratamiento de la Dua es 4 codtipotratamiento de la clase DUA Si en alguna serie se encuentra el
		 * valor de la partida 9805000000 *
		 */
		boolean leyemergencia = false;
		Map<String, Boolean> mpresponse = new HashMap<String, Boolean>();
		String tipotratamiento = declaracion.getDua().getCodtipotratamiento();
		if (StringUtils.hasText(tipotratamiento) && tipotratamiento.equals("4")) {
			if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
				for (DatoSerie serie : declaracion.getDua().getListSeries()) {
					if (serie.getNumpartnandi().compareTo(9805000000L) == 0) {
						leyemergencia = true;
						break;
					}
				}
			}
		}
		mpresponse.put("leyemergencia", leyemergencia);
		return mpresponse;
	}

	/*
	 * Identificar que la declaraci�n esta dentro de los alcances de del articulo 15 de la LGA (Exigibilidad). la declaraci�n se debe haber
	 * numerado como anticipado despu�s de la vigencia de la norma (a partir del 26/08/2008 )
	 */
	/**
	 * Afectaart15lga anticipado.
	 * 
	 * @param declaracionBD Declaracion
	 * @return el map
	 * @throws Exception excepci�n exception
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3027, descServicio = "valida art. 15 de LGA exigibilidad")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3027, numSecEjec = 357, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> Afectaart15lgaAnticipado(Declaracion declaracionBD) throws Exception {

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if (declaracionBD != null) {
			Date dtFechaLeyEmergencia = DateUtil.stringToDate("26/08/2008");
			// se numero como anticipado
			if (declaracionBD.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) {
				// pero si se numero antes de la vigencia de la norma es error
				if (declaracionBD.getDua().getFecdeclaracion().before(dtFechaLeyEmergencia)) {
					resultadoError = getErrorMap("30275","LA DECLARACION NO SE ENCUENTRA DENTRO DEL ALCANCE DEL ARTICULO 15 LGA (EXIGIBILIDAD)");
				}
			}
		}
		return resultadoError;
	}

	/**
	 * Servicio que identifica si la existe una solicitud de rectificacion previa.
	 * 
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @param variablesIngreso Map<String,Object>
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	@ServicioAnnot(tipo = "A", codServicio = 3028, descServicio = "valida si existe solicitud de rectificacion previa no atendida")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3028, numSecEjec = 358, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, Boolean> Solirectiprevia(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception {
		Map<String, Boolean> orquestadormap = new HashMap<String, Boolean>();
		Map<String, Object> params = new HashMap<String, Object>();
		boolean tieneSoliRecNoatendida = false;
		/*
		 * Se identifica si existe una solicitud de rectificaci�n previa que no este Atendida de ser as� se marca esta al grabar la
		 * solicitud nueva , maraca la anterior con el Estado 08 anulada *
		 */

		if (declaracion.getDua().getNumcorredoc() != null) {
			RelacionDocDAO relaciondocDAO = (RelacionDocDAO)fabricaDeServicios.getService("relaciondocDAO");
			params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
			params.put("estadosrecti", new String[] { ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA,
					ConstantesDataCatalogo.COD_EST_RECTIFIC_ASIGNADA_ESPECIALISTA, ConstantesDataCatalogo.COD_EST_RECTIFIC_EN_PROCESO_EVALUACION });
			Integer countSolNoAtendidas = relaciondocDAO.countSolRectificacionByParameterMap(params);
			if (countSolNoAtendidas > 0) {
				tieneSoliRecNoatendida = true;
			}
			orquestadormap.put("tieneSoliRecNoatendida", tieneSoliRecNoatendida);
			variablesIngreso.put("tieneSoliRecNoatendida", tieneSoliRecNoatendida);




		}
		return orquestadormap;
	}

	/**
	 * Servicio que valida el Agente de envio de la Rectificacion/Regularizacion sea el mismo que numero.
	 * 
	 * @param declaracion Declaracion
	 * @param declaracionBD Declaracion
	 * @param numOrden , numero de referencia de la cabecera del mensaje.
	 * @param tipoDocumentoIdentidadSender , tipo de documento del Agente Aduanero que transmite la Solicitud de Rectificacion/Regularizacion.
	 * @param numeroDocumentoIdentidadSender , numero de documento del Agente Aduanero que transmite la Solicitud de Rectificacion/Regularizacion.
	 * @param codigoAduanaOrden , codigo de la aduana de la cual se transmite la Solicitud de Rectificacion/Regularizacion.
	 * @return List
	 * @throws Exception excepci�n exception
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3038, descServicio = "Valida el agente de la solicitud.")
	@ServInstDetAnnot(tipoRpta = { 0, 1, 1, 1, 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "numOrden", "tipoDocumentoIdentidadSender",
			"numeroDocumentoIdentidadSender", "codigoAduanaOrden", "codTransaccion" })
	@OrquestaDespaAnnot(codServInstancia = 3038, numSecEjec = 420, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> validarAgente(Declaracion declaracion, Declaracion declaracionBD, String numOrden,
			String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String codigoAduanaOrden, String codTransaccion) throws Exception {
		/*
		 * El tema aqui es que no existe una validaci�n para el caso de la Regularizaci�n y la Rectificaci�n que verifique que la dua que se
		 * quiere Rectificar/Regularizar le corresponda al Agente y sea la misma que se numer�.
		 * 
		 * Para ello crear un Servicio que Valide 3 cosas: 1.- El numero y a�o de orden del Agente (ram:TraderAssignedID) 2.- El Agente que
		 * transmite la Rectificaci�n debe ser el Mismo que n�mero la Dua (ram:SenderTradeParty) 3.- La aduana de donde se transmite la
		 * Rectificaci�n sea la misma de la dua que se desea rectificar. ram:LodgementLogisticsLocation
		 */
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Map<String, String> resultadoError = new HashMap<String, String>();
		// 1.- El numero y a�o de orden del Agente (ram:TraderAssignedID)
		if ( ! SunatStringUtils.isEqualTo(numOrden.substring(0, 4), declaracionBD.getDua().getAnnorden().toString())  
				|| ! SunatStringUtils.isEqualTo(numOrden.substring(4), declaracionBD.getDua().getNumorden())) {
			resultadoError = ResponseMapManager.getErrorResponseMap("30452", "EL A�O Y NUMERO DE ORDEN NO SON LOS MISMOS DE LA NUMERACION.");
		} else if (!tipoDocumentoIdentidadSender.equals(declaracionBD.getDua().getCodtipooper())
				|| !numeroDocumentoIdentidadSender.equals(declaracionBD.getDua().getNumdocumento())) {
			// 2.- El Agente que transmite la Rectificaci�n debe ser el Mismo que n�mero la Dua (ram:SenderTradeParty)

			if (codTransaccion.endsWith("03"))
				resultadoError = ResponseMapManager.getErrorResponseMap("30453", 
						"LOS DATOS DEL AGENTE DE LA SOLICITUD DE RECTIFICACION NO SON LOS MISMOS DEL AGENTE DE NUMERACION" );

			resultadoError = ResponseMapManager.getErrorResponseMap("30453", 
					"NO SE ENCUENTRA AUTORIZADO PARA LA TRANSMISION DE REGULARIZACION" );	

		} else if (!(codigoAduanaOrden.equals(declaracionBD.getDua().getCodaduanaorden()) &&
				(codigoAduanaOrden.equals(declaracion.getDua().getCodaduanaorden())))) {
			// 3.- La aduana de donde se transmite la Rectificaci�n sea la misma de la dua que se desea rectificar. -
			// ram:LodgementLogisticsLocation
			if (codTransaccion.endsWith("03"))
				resultadoError = ResponseMapManager.getErrorResponseMap("30454",
						"LA ADUANA QUE TRASMITE LA SOLICITUD DE RECTIFICACION NO ES LA MISMA DE LA NUMERACION.");

			resultadoError = ResponseMapManager.getErrorResponseMap("30454",
					"LA ADUANA QUE TRASMITE LA SOLICITUD DE REGULARIZACION NO ES LA MISMA DE LA NUMERACION.");			
		} else if ( declaracion.getDua().getManifiesto() != null){
			DatoManifiesto manif=declaracion.getDua().getManifiesto();
			String codaduamanif=manif.getCodaduamanif();
			String annmanif=manif.getAnnmanif();
			String nummanif=manif.getNummanif();
			boolean tieneprecedencia =  false;
			if(codaduamanif != null && nummanif != null && annmanif!=null){
				// r2bz Siempre y cuando no tenga regimen de precedencia
				if(!SunatStringUtils.isEqualTo(codaduamanif, declaracion.getDua().getCodaduanaorden())){
					for(DatoSerie serie:declaracion.getDua().getListSeries()){
						if (serie.getListRegPrecedencia()!=null && !serie.getListRegPrecedencia().isEmpty()) {
							tieneprecedencia = true;
							break;
						}
					}
					if (!tieneprecedencia){
						resultadoError = ResponseMapManager.getErrorResponseMap("30454",
								"LA ADUANA QUE TRASMITE LA SOLICITUD DE REGULARIZACION/RECTIFICACION " + codigoAduanaOrden +
								" NO ES LA MISMA QUE LA ADUANA DEL MANIFIESTO CONSIGNADO "+codaduamanif+".");						
					}
				}
			}
		}

		if (resultadoError != null && resultadoError.size() > 0) {
			listError.add(resultadoError);
			listError.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		}

		return listError; 
	}


	@ServicioAnnot(tipo = "V", codServicio = 3406, descServicio = "Valida el agente de la solicitud.")
	@ServInstDetAnnot(tipoRpta = { 0, 1, 1, 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "numOrden", "tipoDocumentoIdentidadSender",
			"numeroDocumentoIdentidadSender", "codigoAduanaOrden" })
	@OrquestaDespaAnnot(codServInstancia = 3406, numSecEjec = 420, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> validarAgenteAduana(Declaracion declaracion, Declaracion declaracionBD, String numOrden,
			String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String codigoAduanaOrden, String codTransaccion) throws Exception {
		/*
		 * El tema aqui es que no existe una validaci�n para el caso de la Regularizaci�n y la Rectificaci�n que verifique que la dua que se
		 * quiere Rectificar/Regularizar le corresponda al Agente y sea la misma que se numer�.
		 * 
		 * Para ello crear un Servicio que Valide 3 cosas: 1.- El numero y a�o de orden del Agente (ram:TraderAssignedID) 2.- El Agente que
		 * transmite la Rectificaci�n debe ser el Mismo que n�mero la Dua (ram:SenderTradeParty) 3.- La aduana de donde se transmite la
		 * Rectificaci�n sea la misma de la dua que se desea rectificar. ram:LodgementLogisticsLocation
		 */
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Map<String, String> resultadoError = new HashMap<String, String>();
		// 1.- El numero y a�o de orden del Agente (ram:TraderAssignedID)
		if ( ! SunatStringUtils.isEqualTo(numOrden.substring(0, 4), declaracionBD.getDua().getAnnorden().toString())  
				|| ! SunatStringUtils.isEqualTo(numOrden.substring(4), declaracionBD.getDua().getNumorden())) {
			resultadoError = ResponseMapManager.getErrorResponseMap("30452", "EL A�O Y NUMERO DE ORDEN NO SON LOS MISMOS DE LA NUMERACION.");
		} else if (!tipoDocumentoIdentidadSender.equals(declaracionBD.getDua().getCodtipooper())
				|| !numeroDocumentoIdentidadSender.equals(declaracionBD.getDua().getNumdocumento())) {
			// 2.- El Agente que transmite la Rectificaci�n debe ser el Mismo que n�mero la Dua (ram:SenderTradeParty)
			Map<String, String> mapError=  existeExpedienteEndoseDeAgenciaAduana(declaracion,codTransaccion,numeroDocumentoIdentidadSender);
			if(!CollectionUtils.isEmpty(mapError)){

				listError.add(mapError);
				/*
				if(codTransaccion.endsWith("03")){
					resultadoError = ResponseMapManager.getErrorResponseMap("35264","DECLARACION A RECTIFICAR NO HA SIDO NUMERADA POR SU REPRESENTADA.");
				}else{
					resultadoError = ResponseMapManager.getErrorResponseMap("30453",
							"LOS DATOS DEL AGENTE DE LA SOLICITUD DE REGULARIZACION/RECTIFICACION NO SON LOS MISMOS DEL AGENTE DE NUMERACION.");
				}
				 */

			}
		} else if (!(codigoAduanaOrden.equals(declaracionBD.getDua().getCodaduanaorden()) &&
				(codigoAduanaOrden.equals(declaracion.getDua().getCodaduanaorden())))) {
			// 3.- La aduana de donde se transmite la Rectificaci�n sea la misma de la dua que se desea rectificar. -
			// ram:LodgementLogisticsLocation
			resultadoError = ResponseMapManager.getErrorResponseMap("30454",
					"LA ADUANA QUE TRASMITE LA SOLICITUD DE REGULARIZACION/RECTIFICACION NO ES LA MISMA DE LA NUMERACION.");
		} else if ( declaracion.getDua().getManifiesto() != null){
			DatoManifiesto manif=declaracion.getDua().getManifiesto();
			String codaduamanif=manif.getCodaduamanif();
			String annmanif=manif.getAnnmanif();
			String nummanif=manif.getNummanif();
			boolean tieneprecedencia =  false;
			if(codaduamanif != null && nummanif != null && annmanif!=null){
				// r2bz Siempre y cuando no tenga regimen de precedencia
				if(!SunatStringUtils.isEqualTo(codaduamanif, declaracion.getDua().getCodaduanaorden())){
					for(DatoSerie serie:declaracion.getDua().getListSeries()){
						if (serie.getListRegPrecedencia()!=null && !serie.getListRegPrecedencia().isEmpty()) {
							tieneprecedencia = true;
							break;
						}
					}
					if (!tieneprecedencia){
						resultadoError = ResponseMapManager.getErrorResponseMap("30454",
								"LA ADUANA QUE TRASMITE LA SOLICITUD DE REGULARIZACION/RECTIFICACION " + codigoAduanaOrden +
								" NO ES LA MISMA QUE LA ADUANA DEL MANIFIESTO CONSIGNADO "+codaduamanif+".");						
					}
				}
			}
		}

		if (resultadoError != null && resultadoError.size() > 0) {
			listError.add(resultadoError);
			listError.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		}

		return listError; 
	}

	private Map<String, String> existeExpedienteEndoseDeAgenciaAduana(Declaracion declaracion, String codTransaccion, String numeroDocumentoIdentidadSender){

		boolean tieneExpedienteProcedente =false;
		Map<String, String> resultadoError = new HashMap<String, String>();
		ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		Map<String,Object> params= new HashMap<String, Object>();	   
		params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
		params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
		params.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
		params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
		params.put("procedim", "3032");
		//params.put("actestado", "8");		
		params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
		List<Map<String,Object>> expediente = expedienteService.findExpedientesAsociadoDeclaracion(params); 
		if (expediente.size()>0) {



			Map<String,Object> exp = expediente.get(0);
			BigDecimal tipoconc = new BigDecimal(5);


			params.put("tipoConc", tipoconc); 
			List<Map<String,Object>> expedienteProcedente = expedienteService.findExpedientesAsociadoDeclaracion(params); 
			if (expedienteProcedente.size()>0) {
				//return resultadoError;

				String aduanaExpediente=expedienteProcedente.get(0).get("CODI_ADUA")!=null?expedienteProcedente.get(0).get("CODI_ADUA").toString():null;
				String areaExpediente=expedienteProcedente.get(0).get("OFIC_REC")!=null?expedienteProcedente.get(0).get("OFIC_REC").toString():null;
				String anioExpediente=expedienteProcedente.get(0).get("ANOEXPEDI")!=null?expedienteProcedente.get(0).get("ANOEXPEDI").toString():null;
				String numeroExpediente=expedienteProcedente.get(0).get("NROEXPEDI")!=null?expedienteProcedente.get(0).get("NROEXPEDI").toString():null;

				if(!expedienteProcedente.get(0).get("COMIT_NRO").equals(numeroDocumentoIdentidadSender)){
					resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35270", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente,numeroDocumentoIdentidadSender}));	  	
				}
				return resultadoError;

			}




			BigDecimal tipoconsr = new BigDecimal(0);
			String aduanaExpediente=exp.get("CODI_ADUA")!=null?exp.get("CODI_ADUA").toString():null;
			String areaExpediente=exp.get("OFIC_REC")!=null?exp.get("OFIC_REC").toString():null;
			String anioExpediente=exp.get("ANOEXPEDI")!=null?exp.get("ANOEXPEDI").toString():null;
			String numeroExpediente=exp.get("NROEXPEDI")!=null?exp.get("NROEXPEDI").toString():null;
			if(exp.get("TIPO_CONC")==null ||  SunatNumberUtils.isEqual(tipoconsr, (BigDecimal) exp.get("TIPO_CONC"))  || "".equals(exp.get("TIPO_CONC"))  || " ".equals(exp.get("TIPO_CONC")))
			{  //SI no tiene expediente PROCEDENTE, se rechaza	


				resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35260", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente}));
			}else{
				if(exp.get("TIPO_CONC")!=null &&  !SunatNumberUtils.isEqual(tipoconc, (BigDecimal) exp.get("TIPO_CONC"))){

					resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35264"));	  
				}else
					if(!exp.get("COMIT_NRO").equals(numeroDocumentoIdentidadSender)){
						resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35270", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente,numeroDocumentoIdentidadSender}));	  	
					}					

			}


		}else{


			if(codTransaccion.endsWith("03")){
				//resultadoError = ResponseMapManager.getErrorResponseMap("35264","DECLARACION A RECTIFICAR NO HA SIDO NUMERADA POR SU REPRESENTADA.");
				resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35264"));
			}else{
				//resultadoError = ResponseMapManager.getErrorResponseMap("30453","LOS DATOS DEL AGENTE DE LA SOLICITUD DE REGULARIZACION/RECTIFICACION NO SON LOS MISMOS DEL AGENTE DE NUMERACION.");
				resultadoError.putAll(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30453"));
			}

		}					


		return resultadoError;
	}

	/**
	 * <pre>
	 * Valida el estado de la dua para la rectificacion, en este caso.
	 * - La dua no debe tener canal 
	 * </pre>
	 * 
	 * @param declaracionBD Declaracion
	 * @return lista de mapa de errores
	 */
	public List<Map<String, String>> validaEstadoDUA(Declaracion declaracionBD){
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();

		if(! SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal()) )
		{
			/*branch ingreso 2011-009 hosorio inicio 07/05/2011 */
			/* FJP: se comenta para que funcione el pase 580
			listErr.add( ResponseMapManager.getErrorResponseMap("30454", "LA SOLICITUD DE RECTIFICACI�N ELECTR�NICA CON POSTERIORIDAD A LA SELECCI�N DEL CANAL ES EVALUADA POR LA ADMINISTRACI�N ADUANERA") );
			listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() );*/
			/*branch ingreso 2011-009  hosorio fin 07/05/2011 */
		}

		//mordonezl pase70
		if( Constants.COD_ESTADO_DECLARACION_MERCANCIA_DISPUESTA_TOTALMENTE.equals( declaracionBD.getDua().getCodEstdua()) ) {
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			listErr.add( catalogoAyudaService.getError("30731", new String[] {
					declaracionBD.getDua().getCodaduanaorden(),
					declaracionBD.getDua().getAnnpresen().toString(),
					declaracionBD.getDua().getCodregimen(),
					declaracionBD.getNumeroDeclaracion().toString()}) 
					);
			listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		}

		//fin mordonezl

		return  listErr;
	}

	/**
	 * Bloquear campo.
	 * 
	 * @param codTabla
	 *            String
	 * @param nombreCampo
	 *            String
	 * @param solRectiDeclaracion
	 *            List<DetSolicitudRectificacionBean>
	 */
	private void bloquearCampo(String codTabla, String nombreCampo, List<DetSolicitudRectificacionBean> solRectiDeclaracion) {

		if (!CollectionUtils.isEmpty(solRectiDeclaracion)) {
			for (DetSolicitudRectificacionBean solic : solRectiDeclaracion) {
				if (codTabla.equals(solic.getCodtabla())) {
					DatoRectificacionBean columnaRect = solic.getDatosRectificados().get(nombreCampo);
					if (columnaRect != null) {
						columnaRect.setFlagBloqueo(Constants.IND_CAMPO_BLOQ_RECTIFI_ADUANA);
					}
				}
			}
		}
	}

	/**
	 * Retorna el valor de dato rect by object path.
	 * 
	 * @param ObjectPath
	 *            String
	 * @param solicitudRectificacion
	 *            List<DetSolicitudRectificacionBean>
	 * @return dato rect by object path
	 */
	private List<DatoRectificacionBean> getDatoRectByObjectPath(String ObjectPath, List<DetSolicitudRectificacionBean> solicitudRectificacion) {
		List<DatoRectificacionBean> datosRect = null;
		if (!CollectionUtils.isEmpty(solicitudRectificacion)) {
			datosRect = new ArrayList<DatoRectificacionBean>();
			for (DetSolicitudRectificacionBean srRec : solicitudRectificacion) {
				for (DatoRectificacionBean drb : srRec.getDatosRectificados().values()) {
					if (StringUtils.hasText(drb.getObjectPath()) && drb.getObjectPath().indexOf(ObjectPath) >= 0) {
						datosRect.add(drb);
					}
				}
			}
		}
		return datosRect;
	}



	/**
	 * Obtener dua bd.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el dUA
	 */
	private DUA obtenerDuaBD(Declaracion declaracion) {
		CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana", numdeclRef.getCodaduana());
		params.put("annoPresentacion", numdeclRef.getAnnprese());
		params.put("codigoRegimen", numdeclRef.getCodregimen());
		params.put("numeroDeclaracion", numdeclRef.getNumcorre());
		DUA dua = cabdeclaraDAO.findDUAByKeyMap(params);

		return dua;
	}

	/**
	 * Obtener map dua.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el map
	 */
	private Map<String, Object> obtenerMapDua(Declaracion declaracion) {
		CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		/* estos datos son clabes de la dua */
		params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
		params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
		params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
		params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
		List<Map<String, Object>> lstdua = cabdeclaraDAO.listCabDeclaraMapByParameterMap(params);

		if (!CollectionUtils.isEmpty(lstdua))
			return lstdua.get(0);

		return null;

	}
	//gmontoya
	//verifica si se debe realizar valdaci�n por modificaci�n en las cantidades originales de la serie
	private boolean validarSeriePorCambios(DatoSerie serie,Declaracion declaracionBD,String regimen){
		DatoSerie seriebd=null;
		for(DatoSerie serieComp:declaracionBD.getDua().getListSeries()){
			if(serie.getNumserie().equals(serieComp.getNumserie())){
				seriebd=serieComp;
				break;
			}			
		}
		if(seriebd!=null){
			if(regimen.equals("70") && SunatNumberUtils.isLessThanParam(serie.getCntpesoneto(),seriebd.getCntpesoneto()) ){
				return true;
			}
			if(regimen.equals("70") && SunatNumberUtils.isLessThanParam(serie.getCntpesobruto(),seriebd.getCntpesobruto())){
				return true;
			}
			if(SunatNumberUtils.isLessThanParam(serie.getCntunifis(),seriebd.getCntunifis())){
				return true;
			}
			return false;
		}else{
			return false;
		}
	}

	private Map<String,Object> SumValoresDepocta(List<Depocta> listDepocta){
		Map<String,Object> mapDepocta=new HashMap<String,Object>();
		BigDecimal p_peso_neto = BigDecimal.ZERO;
		BigDecimal p_peso_bruto = BigDecimal.ZERO;
		BigDecimal p_unid_fiqty = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(listDepocta)){			
			for(Depocta depocta:listDepocta){
				p_peso_neto = SunatNumberUtils.sum(p_peso_neto,depocta.getPesoNeto()); 
				p_peso_bruto = SunatNumberUtils.sum(p_peso_bruto,depocta.getPesoBruto()); 
				p_unid_fiqty = SunatNumberUtils.sum(p_unid_fiqty,depocta.getUnidFiqty());				
			}
		}
		mapDepocta.put("p_peso_neto", p_peso_neto);
		mapDepocta.put("p_peso_bruto", p_peso_bruto);
		mapDepocta.put("p_unid_fiqty", p_unid_fiqty);		
		return mapDepocta;
	}

	/**
	 * Val ct cte deposito.
	 * 
	 * @param declaracion Declaracion
	 * @param declaracionBD Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el list
	 * @throws Exception excepci�n exception
	 */
	//Por Refactoring pasa a clase ValNegocCtaCteDepFormA

	//	@ServicioAnnot(tipo = "V", codServicio = 3032, descServicio = "valida cuenta corriente de deposito")
	//	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "variablesIngreso" })
	//	@OrquestaDespaAnnot(codServInstancia = 3032, numSecEjec = 424, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	//	public List<Map<String, String>> valCtCteDeposito(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
	//			throws Exception {
	//		//branch ingreso 2011-009 gmontoya 15	
	//		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();
	//		 
	//
	//
	//		
	//		// si no ha declarado reg. precedencia en la numeracion ,pero si en la rectificacion
	//		if (!isRegimenDeposito(declaracionBD) && isRegimenDeposito(declaracion)) {
	//			// validar cuenta corriente componente de gustavo
	//			//branch ingreso 2011-009 gmontoya 15
	//			variablesIngreso.put("fechaVigenciaRegimenBD", declaracionBD.getDua().getFecdeclaracion());
	//			variablesIngreso.put("numeroDeclaracion", declaracionBD.getNumdeclRef().getNumcorre());
	////			resultadoError = RectificacionServiceImpl.getInstance().getValidacionesService().getValNegocNumeracFormA().validarCtaCteDeposito(
	//			resultadoError = valNegocNumeracFormA.validarCtaCteDeposito(
	//					declaracion, variablesIngreso);
	//			variablesIngreso.remove("fechaVigenciaRegimenBD");
	//			variablesIngreso.remove("numeroDeclaracion");
	//			// si existe saldo suficiente . Es decir no hay errores
	//
	//			if (resultadoError.isEmpty())
	//				variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
	//		} else if (isRegimenDeposito(declaracionBD) && isRegimenDeposito(declaracion))
	//		// si ha declarado el regimen precedente en la numeracion y rectificacion pero cambia los montos
	//		{
	//			// si cambia el total de unidades fisicas
	//			BigDecimal totalUnidFisDeclarado = obtenerTotalUnidadesFisicaDeposito(declaracionBD);
	//			BigDecimal totalUnidFisRectificado = obtenerTotalUnidadesFisicaDeposito(declaracion);
	//			
	//			//branch ingreso 2011-009 gmontoya 15
	//			// si cambia el total de pesos brutos
	//			BigDecimal totalPesoBrutoDeclarado = obtenerTotalPesosBrutosDeposito(declaracionBD);
	//			BigDecimal totalPesoBrutoRectificado = obtenerTotalPesosBrutosDeposito(declaracion);
	//
	//			// si rectificado > a declarado se debe validar la cta cte de deposito
	//			//if ((totalUnidFisRectificado.compareTo(totalUnidFisDeclarado) != 0)|| (totalPesoBrutoRectificado.compareTo(totalPesoBrutoDeclarado) != 0)){
	//				// validar cuenta corriente componente de gustavo
	//				// si existe saldo suficiente
	//				//branch ingreso 2011-009 gmontoya 15
	//				variablesIngreso.put("fechaVigenciaRegimenBD", declaracionBD.getDua().getFecdeclaracion());
	//				variablesIngreso.put("numeroDeclaracion", declaracionBD.getNumdeclRef().getNumcorre());
	////				resultadoError = RectificacionServiceImpl.getInstance().getValidacionesService().getValNegocNumeracFormA().validarCtaCteDeposito(
	//				resultadoError = valNegocNumeracFormA.validarCtaCteDeposito(
	//						declaracion, variablesIngreso);
	//				variablesIngreso.remove("fechaVigenciaRegimenBD");
	//				variablesIngreso.remove("numeroDeclaracion");
	//				if (resultadoError.isEmpty())
	//					variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
	//				else {
	//					// se desafecta
	//					variablesIngreso.put("indAfectaDesafectaRegPreDepo", "D");
	//				}
	//			//}
	//			//fin
	//
	//		}
	//		// si se ha declarado en la numeracion , pero no en la rectificacion=> se desafecta
	//		else if (isRegimenDeposito(declaracionBD) && !isRegimenDeposito(declaracion)) {
	//			// se desafecta
	//			variablesIngreso.put("indAfectaDesafectaRegPreDepo", "D");
	//
	//		}		
	//		return resultadoError;
	//	}

	/**
	 * Obtener total unidades fisica deposito.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el big decimal
	 */
	//Por Refactoring pasa a clase ValNegocCtaCteDepFormA
	//	private BigDecimal obtenerTotalUnidadesFisicaDeposito(Declaracion declaracion) {
	//
	//		BigDecimal totalUnidFisicas = BigDecimal.ZERO;
	//		if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
	//			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
	//				if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
	//					for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
	//						if ("70".equals(regPrec.getCodregipre()))
	//							totalUnidFisicas = SunatNumberUtils.sum(totalUnidFisicas, serie.getCntunifis());
	//					}
	//				}
	//			}
	//		}
	//
	//		return totalUnidFisicas;
	//	}	
	/**
	 * Obtener total pesos brutos deposito.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el big decimal
	 */
	//Por Refactoring pasa a clase ValNegocCtaCteDepFormA
	//	private BigDecimal obtenerTotalPesosBrutosDeposito(Declaracion declaracion) {
	//
	//		BigDecimal totalPesosBrutos = BigDecimal.ZERO;
	//		if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
	//			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
	//				if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
	//					for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
	//						if ("70".equals(regPrec.getCodregipre()))
	//							totalPesosBrutos = SunatNumberUtils.sum(totalPesosBrutos, serie.getCntpesobruto());
	//					}
	//				}
	//			}
	//		}
	//
	//		return totalPesosBrutos;
	//	}	
	/**
	 * Existe cambios.
	 * 
	 * @param solicitudRectificacion SolicitudRectificacionBean
	 * @return el list
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3031, descServicio = "Valida si existe cambios en la rectificacion")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "solicitudRectificacion" })
	@OrquestaDespaAnnot(codServInstancia = 3031, numSecEjec = 423, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, ?>> existeCambios(SolicitudRectificacionBean solicitudRectificacion) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//ResponseListManager responseList = new ResponseListManager();
		//mordonezl
		List<Map<String, ?>> listError=new ArrayList<Map<String, ?>>();
		// si tiene sustento

		// si existe cambios
		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {

			// si solo hay un cambio verificar que no sea el de el sustento
			if (solicitudRectificacion.getListaCambios().size() == 1) {

				// verificando si se ha rectificado el sustento
				List<DatoRectificacionBean> lstDatosRec = getDatoRectByObjectPath("obsdeclaracion", solicitudRectificacion.getListaCambios());
				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					DatoRectificacionBean dato = lstDatosRec.get(0);
					Observacion obs = (Observacion) dato.getObjetoPadre();
					if (obs.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_RECTIFICACION)) {
						//responseList.addError("30341", "LA DECLARACION DE RECTIFICACION NO PRESENTA CAMBIOS");
						//mordonezl
						listError.add(catalogoAyudaService.getError("30341"));
					}
				}
			}
		} else {
			//			responseList.addError("30341", "LA DECLARACION DE RECTIFICACION NO PRESENTA CAMBIOS");
			//mordonezl
			listError.add(catalogoAyudaService.getError("30341"));
		}
		//mordonezl
		return listError;
	}

	public boolean esDatoRectificado(SolicitudRectificacionBean solicitudRectificacion, String nombreCampo) {

		boolean datoRectificado = false;

		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			List<DatoRectificacionBean> lstDatosRec = getDatoRectByObjectPath(nombreCampo, solicitudRectificacion.getListaCambios());
			if (!CollectionUtils.isEmpty(lstDatosRec)) {
				datoRectificado = true;
			}
		} 

		return datoRectificado;		
	}

	public List<Map<String, ?>> validarOtrasCondicionesParaRectificacionAutomatica(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion, Declaracion declaracionBD) {
		ResponseListManager responseList = new ResponseListManager();
		Boolean esRectificacionAutomatica=false;
		List<DatoRectificacionBean> lstDatosRec = null;
		DUA dua=declaracion.getDua();
		//Date fecLlegada = dua.getFecLlegada();

		DUA duaBD=declaracionBD.getDua();
		boolean tieneCanal = true;
		// Si no tiene canal es automatica por defecto
		if (!SunatStringUtils.include(dua.getCodCanal(), new String[]{"F","D","V"})) {
			tieneCanal = false;
			return responseList.getResponseList();
		}

		Map manifiestomap = (Map) variablesIngreso.get("manifiestomap");

		if(manifiestomap==null){
			return responseList.getResponseList();
		}
		Date fechaLlegada = (Date) manifiestomap.get("fechaEfectivaDeLlegada");
		Date fechaTermDescarga = (Date) manifiestomap.get("fechaTerminoDeDescarga");
		Date fechaAutSalRetiro = duaBD.getFecAutSalRetiro();
		boolean existeCambioAnticipadoAExcepcional = false;
		//validar esCambioAnticipadoAExcepcional
		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() <= 10) {
				lstDatosRec = getDatoRectByObjectPath("codmodalidad", solicitudRectificacion.getListaCambios());
				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica=true;
					DatoRectificacionBean dato = lstDatosRec.get(0);

					if(Constants.DESPACHO_EXCEPCIONAL.equals(dato.getDatoNuevo()) && Constants.DESPACHO_ANTICIPADO.equals(dato.getDatoAntiguo())){
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						existeCambioAnticipadoAExcepcional = true;
						// esta validacion esta en validacionesParaDespachoExcepcional
						DataCatalogo catPlazoModalidadAnticipada = catalogoAyudaService.getDataCatalogo(
								ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
								ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA, fechaReferencia);
						Integer plazoModalidadAnticipada = SunatNumberUtils.toInteger(catPlazoModalidadAnticipada.getDesCorta());
						Long diferencia = SunatDateUtils.getDiferenciaDiasCalendarios(fechaLlegada, fechaReferencia);
						if (diferencia <= plazoModalidadAnticipada){
							esRectificacionAutomatica = false;		

						}else{
							BigDecimal tipoconc = new BigDecimal(5);
							ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
							Map<String,Object> params= new HashMap<String, Object>();	   
							params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
							params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
							params.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
							params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
							params.put("procedim", "3126");
							//params.put("actestado", "8");
							params.put("tipoConc", tipoconc);
							params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
							List<Map<String,Object>> expediente = expedienteService.findExpedientesAsociadoDeclaracion(params); 
							if (expediente.size()>0) {
								esRectificacionAutomatica = false;		

							}
						}


						if (existeCambioAnticipadoAExcepcional &&  declaracionBD.getDua().getFecAutlevante().compareTo(SunatDateUtils.getDefaultDate())>0 ){
							//PARA DECLARACIONES CON MODALIDAD EXCEPCIONAL LA RECTIFICACIÿN SÿLO ES PERMITIDA ANTES DEL LEVANTE AUTORIZADO
							esRectificacionAutomatica = false;		
						}	



					}else{

						esRectificacionAutomatica = false;		

					}



				}
			}
		}

		variablesIngreso.put("esCambioAnticipadoAExcepcional", esRectificacionAutomatica);

		//validar esIndicadorRegularizacion
		DatoManifiesto manif=dua.getManifiesto();
		Date fecTermDescarga = manif!=null?manif.getFectermino():null;
		esRectificacionAutomatica=false; // Por defecto es false
		Boolean soloRectificaIndicador=true;
		boolean tieneIndicadorRegularizacion = false;
		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() <= 10) {
				lstDatosRec = getDatoRectByObjectPath("codtipoindica", solicitudRectificacion.getListaCambios());


				if (!CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
					List<DatoRectificacionBean> datosRect = null;
					String[] datosRectificables =  new String[]{ "dua.manifiesto.fectermino","dua.fecLlegada","obsdeclaracion"};
					datosRect = new ArrayList<DatoRectificacionBean>();
					for (DetSolicitudRectificacionBean srRec : solicitudRectificacion.getListaCambios()) {
						Map<String,Object> datoKey = srRec.getKey(); 
						if(datoKey.containsKey("COD_INDICADOR") && "02".equals(datoKey.get("COD_INDICADOR"))){
							tieneIndicadorRegularizacion = true;

						}

						for (DatoRectificacionBean drb : srRec.getDatosRectificados().values()) {
							String name = drb.getObjectPath();
							if (StringUtils.hasText(drb.getObjectPath()) && !SunatStringUtils.include(drb.getObjectPath(),datosRectificables)) {
								soloRectificaIndicador = false;
								break;
							}
						}
					}
				}

				//				if (!CollectionUtils.isEmpty(lstDatosRec)) {
				//					DatoRectificacionBean dato = lstDatosRec.get(0);
				//					DUA duaRecti = (DUA) dato.getObjetoPadre();
				//					List<DatoIndicadores> listaIndicador = duaRecti.getListIndicadores();					
				//					for (DatoIndicadores indicador : listaIndicador) {
				//						if (Constants.INDICADOR_REQUIERE_REGULARIZACION.equals(indicador.getCodtipoindica())) {
				//							tieneIndicadorRegularizacion = true;
				//							break;
				//						}
				//					}
				//				}
				if (tieneIndicadorRegularizacion && soloRectificaIndicador) {

					//if(fechaTermDescarga.compareTo(SunatDateUtils.getDefaultDate())>0 && fechaReferencia.compareTo(fechaTermDescarga)>0 ){
					if(fechaTermDescarga.compareTo(SunatDateUtils.getDefaultDate()) > 0) {//PAS20145E220000399

						Map<String, Object> paramDias = new HashMap<String, Object>();
						Date fecVencRegulNueva=SunatDateUtils.addDay(fechaTermDescarga,Constantes.PLAZO_VENCIMIENTO_REGULARIZACION);
						Integer fecVencRegulAsInteger = SunatDateUtils.getIntegerFromDate(fecVencRegulNueva);
						paramDias.put("FECHADESDE", fecVencRegulAsInteger);
						paramDias.put("FECHAHASTA", 0);
						paramDias.put("TIPO", 2);
						paramDias.put("INCLUYE", "S");
						paramDias.put("SUSPENDE", "S");
						DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
						DataSourceContextHolder.setKeyDataSource(declaracion.getCodAduana());
						String fecVencRegul = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias);
						Date fechaHoy = SunatDateUtils.getCurrentDate();
						if(SunatDateUtils.esFecha1MayorQueFecha2(fechaHoy, SunatDateUtils.getDate(fecVencRegul, "yyyyMMdd"), SunatDateUtils.COMPARA_SOLO_FECHA)){
							responseList.addWarning("30761", ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDescripcionDataCatalogo("F09","30761"));//BUG 18590 arey
						} else {
							esRectificacionAutomatica = true;
						}
					}else{
						if(SunatDateUtils.sonIguales(fechaTermDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
							esRectificacionAutomatica = true;
						}
					}

				}			
			}
		}

		variablesIngreso.put("esIndicadorRegularizacion", tieneIndicadorRegularizacion);
		variablesIngreso.put("soloRectificaIndicador", esRectificacionAutomatica);
		// se actualiza por bug 18307
		//validar esPuntoLlegadaDepositoTemporal

		esRectificacionAutomatica=false; // Por defecto es true

		Boolean esDepositoTemporal=false;
		//Boolean esDepositoTemporal=false;

		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() <= 10) {

				lstDatosRec = getDatoRectByObjectPath("codlugarecepcion", solicitudRectificacion.getListaCambios());

				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					DatoRectificacionBean dato = lstDatosRec.get(0);
					if (!Constants.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(dato.getDatoNuevo())) {
						esRectificacionAutomatica = false;		
					}else{
						esDepositoTemporal = true;

					}
				}
				//Se verifica que no haya salido del Deposito Temporal
				//		 		if (SunatDateUtils.esFecha1MayorQueFecha2(fechaAutSalRetiro, FECHA_DEFAULT.getTimestamp(), SunatDateUtils.COMPARA_SOLO_FECHA)) {
				//		 			esRectificacionAutomatica = false;
				//		 		}

				if(esDepositoTemporal){				
					esRectificacionAutomatica = true;
					if (!CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
						List<DatoRectificacionBean> datosRect = null;
						String[] datosRectificables = null;
						if(existeCambioAnticipadoAExcepcional){
							datosRectificables =  new String[]{"dua.codmodalidad","dua.codlugarecepcion","dua.numruclugarecep","dua.codtiplugarrecep", "dua.codanexo","dua.fecLlegada","dua.manifiesto.fectermino", "obsdeclaracion"};
						}else{
							datosRectificables =  new String[]{"dua.codlugarecepcion","dua.numruclugarecep","dua.codtiplugarrecep", "dua.codanexo","dua.fecLlegada","dua.manifiesto.fectermino", "obsdeclaracion"};
						}
						datosRect = new ArrayList<DatoRectificacionBean>();
						for (DetSolicitudRectificacionBean srRec : solicitudRectificacion.getListaCambios()) {
							for (DatoRectificacionBean drb : srRec.getDatosRectificados().values()) {
								String name = drb.getObjectPath();
								if (StringUtils.hasText(drb.getObjectPath()) && !SunatStringUtils.include(drb.getObjectPath(),datosRectificables)) {
									esRectificacionAutomatica = false;
									break;
								}
							}
						}
					}

				}

			}
		}

		variablesIngreso.put("esPuntoLlegadaDepositoTemporal", esRectificacionAutomatica);

		return responseList.getResponseList();
	}

	public boolean exiteIndicadorRegularizacion(SolicitudRectificacionBean solicitudRectificacion){
		List<DatoRectificacionBean> lstDatosRec = null;
		lstDatosRec = getDatoRectByObjectPath("codtipoindica", solicitudRectificacion.getListaCambios());
		boolean tieneIndicadorRegularizacion = false;

		if (!CollectionUtils.isEmpty(lstDatosRec)) {
			DatoRectificacionBean dato = lstDatosRec.get(0);
			DUA duaRecti = (DUA) dato.getObjetoPadre();
			List<DatoIndicadores> listaIndicador = duaRecti.getListIndicadores();					
			for (DatoIndicadores indicador : listaIndicador) {
				if (Constants.INDICADOR_REQUIERE_REGULARIZACION.equals(indicador.getCodtipoindica())) {
					tieneIndicadorRegularizacion = true;
					break;
				}
			}
		}

		return tieneIndicadorRegularizacion;
	}	
	public List<Map<String, ?>> validarSoloCambioAnticipadoAExcepcional(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion) {
		ResponseListManager responseList = new ResponseListManager();
		Boolean esRectificacionAutomatica=true;
		List<DatoRectificacionBean> lstDatosRec = null;
		DUA dua=declaracion.getDua();
		Date fecLlegada = dua.getFecLlegada();

		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() == 5) {
				lstDatosRec = getDatoRectByObjectPath("codmodalidad", solicitudRectificacion.getListaCambios());
				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					DatoRectificacionBean dato = lstDatosRec.get(0);
					DUA duaRecti = (DUA) dato.getObjetoPadre();
					if (!Constants.DESPACHO_EXCEPCIONAL.equals(duaRecti.getCodmodalidad())) {
						esRectificacionAutomatica = false;		
					}

					Long diferencia = SunatDateUtils.getDiferenciaDiasCalendarios(fecLlegada, fechaReferencia);
					if (diferencia <= 15){
						esRectificacionAutomatica = false;						
					}
				}				

				lstDatosRec = getDatoRectByObjectPath("codlugarecepcion", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("numruclugarecep", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("codtiplugarrecep", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("codanexo", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}
			}
		} else {
			esRectificacionAutomatica = false;
		}

		variablesIngreso.put("esCambioAnticipadoAExcepcional", esRectificacionAutomatica);

		return responseList.getResponseList();
	}

	public List<Map<String, ?>> validarSoloCambioIndicadorRegularizacion(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion) {
		ResponseListManager responseList = new ResponseListManager();
		Boolean esRectificacionAutomatica=true;
		List<DatoRectificacionBean> lstDatosRec = null;
		DUA dua=declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();
		Date fecTermDescarga = manif!=null?manif.getFectermino():null;

		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() == 1) {
				lstDatosRec = getDatoRectByObjectPath("codtipoindica", solicitudRectificacion.getListaCambios());
				boolean tieneIndicadorRegularizacion = false;

				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					DatoRectificacionBean dato = lstDatosRec.get(0);
					DUA duaRecti = (DUA) dato.getObjetoPadre();
					List<DatoIndicadores> listaIndicador = duaRecti.getListIndicadores();					
					for (DatoIndicadores indicador : listaIndicador) {
						if (Constants.INDICADOR_REQUIERE_REGULARIZACION.equals(indicador.getCodtipoindica())) {
							tieneIndicadorRegularizacion = true;
							break;
						}
					}
				}
				if (tieneIndicadorRegularizacion) {
					Long diferencia = SunatDateUtils.getDiferenciaDiasCalendarios(new Date(),fecTermDescarga);
					if (diferencia <= 15) {
						esRectificacionAutomatica = false;		
						responseList.addWarning("30761",((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDescripcionDataCatalogo("F09","30761"));
						//responseList.addWarning("30761", catalogoAyudaService.getDescripcionCatalogo("30761"));
					}						
				} else {
					esRectificacionAutomatica = false;
				}			
			}
		} else {
			esRectificacionAutomatica = false;
		}

		variablesIngreso.put("esIndicadorRegularizacion", esRectificacionAutomatica);

		return responseList.getResponseList();		
	}

	public List<Map<String, ?>> validarSoloCambioPuntoLlegadaDepositoTemporal(SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracion) {
		ResponseListManager responseList = new ResponseListManager();
		Boolean esRectificacionAutomatica=true;
		List<DatoRectificacionBean> lstDatosRec = null;
		DUA dua=declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();
		Date fecLlegada = dua.getFecLlegada();

		if (solicitudRectificacion != null && !CollectionUtils.isEmpty(solicitudRectificacion.getListaCambios())) {
			if (solicitudRectificacion.getListaCambios().size() == 5) {

				lstDatosRec = getDatoRectByObjectPath("codtipoindica", solicitudRectificacion.getListaCambios());

				if (!CollectionUtils.isEmpty(lstDatosRec)) {
					DatoRectificacionBean dato = lstDatosRec.get(0);
					DUA duaRecti = (DUA) dato.getObjetoPadre();
					if (!Constants.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(duaRecti.getCodlugarecepcion())) {
						esRectificacionAutomatica = false;		
					}
				}
				//Se verifica que no haya salido del Deposito Temporal
				if (dua.getFecAutlevante().toString()!="01/01/0001") {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("codlugarecepcion", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("numruclugarecep", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("codtiplugarrecep", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

				lstDatosRec = getDatoRectByObjectPath("codanexo", solicitudRectificacion.getListaCambios());				
				if (CollectionUtils.isEmpty(lstDatosRec)) {
					esRectificacionAutomatica = false;
				}

			}
		} else {
			esRectificacionAutomatica = false;
		}

		variablesIngreso.put("esPuntoLlegadaDepositoTemporal", esRectificacionAutomatica);

		return responseList.getResponseList();
	}

	/**
	 * Afecta articulo199.
	 * 
	 * @param declaracion Declaracion
	 * @return el list
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3035, descServicio = "valida los indicadores segun el articulo 199.")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3035, numSecEjec = 425, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> afectaArticulo199(Declaracion declaracion) {
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();
		/*
		 * 2. Cuando el usuario transmita el indicador de acogimiento al art�culo 199 validar Que la declaraci�n ya tenga canal y tenga
		 * fecha de levante (si no cumple alguno de estas validaciones emitir rechazo ) 30342 Si pasa esta validaci�n verificar que la fecha
		 * de la rectificaci�n este dentro de las fechas de levante mas 3 meses (incluye la fecha de levante ) de no ser as� error 30343
		 */
		List<DatoIndicadores> lista = getListIndicadorByTipo(declaracion.getDua(), ConstantesDataCatalogo.INDICADOR_RECTIFICACION_ART_199);
		// si presenta el indicador 03 del art 199
		if (!CollectionUtils.isEmpty(lista)) {
			CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			Map<String, Object> dua = cabdeclaraDAO.findDuaByNumCorreDoc(param);

			String codCanal = (String) dua.get("COD_CANAL");
			Date fecLevante = (Date) dua.get("FEC_AUTLEVANTE");

			if (!StringUtils.hasText(codCanal) || fecLevante == null || DateUtil.isDefaultDate(fecLevante)) {
				resultadoError.add(getErrorMap("30342",	"USO DE ARTICULO 199 INVALIDO (DUA SIN LEVANTE)"));
			} else {
				Date fecRectificacion = SunatDateUtils.getCurrentDate();
				Date fecLimite = SunatDateUtils.addMonth(fecLevante, 3);

				if (fecLimite.compareTo(fecRectificacion) >= 0 && fecRectificacion.compareTo(fecLevante) >= 0) {
					// System.out.println("OK DENTRO");
				} else {
					resultadoError.add(getErrorMap("30343","USO DE ARTICULO 199 - PLAZO DE USO DE ART YA VENCIO"));
				}

			}

		}

		return resultadoError;
	}

	/**
	 * Afecta articulo200.
	 * 
	 * @param declaracion Declaracion
	 * @return el list
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3036, descServicio = "valida los indicadores segun el articulo 200.")
	@ServInstDetAnnot(tipoRpta = { 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3036, numSecEjec = 426, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, ?>> afectaArticulo200(Declaracion declaracion) {
		// List<Map<String, String>> resultadoError = new ArrayList<Map<String,String>>();
		ResponseListManager resultadoError = new ResponseListManager();
		/*
		 * 3. (TIPO WARINIG ) Cuando el usuario transmita el indicador de acogimiento al art�culo 200 validar En la secci�n otros documentos
		 * asociados validar envi� una declaraci�n , sino env�a nada ignorar (no emitir error) , luego si env�a una o varias d�as validar
		 * que dichas d�as Existan Si no existen emitir error por cada d�a (30344) Adicional a esto emitir el error (30345)
		 */

		List<DatoIndicadores> lista = getListIndicadorByTipo(declaracion.getDua(), ConstantesDataCatalogo.INDICADOR_RECTIFICACION_ART_200);
		// si presenta el indicador 04 del art 200
		if (!CollectionUtils.isEmpty(lista)) {

			List<DatoOtroDocSoporte> duasAsociadas = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
					ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_OTROS);
			if (!CollectionUtils.isEmpty(duasAsociadas)) {
				for (DatoOtroDocSoporte duaSoporte : duasAsociadas) {
					CabDeclaraDAO cabdeclaraDAO =  (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("codaduana", duaSoporte.getCodentidademisora());
					params.put("annpresen", duaSoporte.getAnndocasoc().substring(0, 4));
					// con el indicador 200 , el regimen es 10
					params.put("codregimen", Constants.REGIMEN_IMPORTACION_CONSUMO);
					params.put("numdeclaracion", duaSoporte.getNumdocasoc());
					Integer cantDua = cabdeclaraDAO.countByParameterMap(params);

					if (cantDua != 1) {
						// resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30344","XXXXXX"));
						resultadoError.addWarning("30344", "ART 200. DUA NO EXISTE . NRO: " + duaSoporte.getNumdocasoc() + " A�O: "
								+ duaSoporte.getAnndocasoc() + " ADUANA: " + duaSoporte.getCodentidademisora() + " REGIMEN : 10");
					}

				}

			}

		}

		return resultadoError.getResponseList();
	}

	/**
	 * Validar garantia.
	 * 
	 * @param declaracion Declaracion representa a la DUA por Numerar
	 * @param declaracion declaracionBD  representa a al Dua Numerada 
	 * @return el list
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3036, descServicio = "valida el codigo de garantia")
	@ServInstDetAnnot(tipoRpta = { 1,1 }, nomAtr = { "declaracion","declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3037, numSecEjec = 427, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> validarGarantia(Declaracion declaracion,Declaracion declaracionBD) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;
		String codgarantia = decla != null ? decla.getCodgarantia() : null;
		String codTipoPago = decla != null ? decla.getCodtipopago() : null;
		String regimen = declaracion.getDua().getCodregimen();
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();

		if (SunatStringUtils.include(regimen, new String[] { "20", "21" })) {
			/*
			 * 2.- Para las transacciones 2001 , 2003, 2101, 2103 considera ademas que si envian ese dato el valor enviado necesariamente
			 * seha G Sino emitir rechazo 30355
			 */
			if ("P".equals(codTipoPago)) {
				// Error 30355
				resultadoError.add(getErrorMap("30355", ""));
			}
		}
		if (!SunatStringUtils.isEmpty(codgarantia)) {
			if (!"G".equals(codTipoPago)) {
				// error 30359
				resultadoError.add(getErrorMap("30359", ""));
			}
		}
		if ("G".equals(codTipoPago) && SunatStringUtils.isEmpty(codgarantia)) {
			// error 30359
			resultadoError.add(getErrorMap("30359", ""));
		}

		/*hosorio inicio 11/04/2011*/
		// Si envia garantia en la Rectificacion
		String codgarantiaBD=null;
		try {
			codgarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {
			// TODO: handle exception
		}
		// Si envia en la rectificacion
		if(!SunatStringUtils.isEmptyTrim(codgarantia)){
			//branch ingreso 2011-009 gmontoya 13
			if(SunatStringUtils.isEmptyTrim(codgarantiaBD)){
				if(funcionesService.isAutoliquidado(declaracion.getDua())){
					resultadoError.add(getErrorMap("30485","AL SOLICITAR ACOGERSE A UNA GARANT�A, NO SE DEBE ENVIAR AUTOLIQUIDACIONES."));
				}
				// r2bz Verificamos si existe Liquidaciones 0026 , 0010 y 0029 Pagadas
				if(funcionesService.existsAutoliquidacionesPagadas(declaracionBD)){
					resultadoError.add(getErrorMap("30485","AL SOLICITAR ACOGERSE A UNA GARANT�A, NO DEBE EXISTIR AUTOLIQUIDACIONES CANCELADAS"));
				}


			}
			//branch ingreso 2011-009 fin
			// Si se ha cambiado el nro de cuenta corriente 
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> MapVigenciaCambioNroCtaCteOEA =catalogoAyudaService.getElementoCat("380", "0042",declaracionBD.getDua().getFecNumeracion());
			
			if(!SunatStringUtils.isEqualTo(codgarantia, codgarantiaBD) && !SunatStringUtils.isEmptyTrim(codgarantiaBD)){
				if ( CollectionUtils.isEmpty(MapVigenciaCambioNroCtaCteOEA)){ 
				resultadoError.add(getErrorMap("07203", "NO SE PERMITE MODIFICAR EL NRO DE CTA DE LA GARANTIA EN LA RECTIFICACION"));	
				
				}else{// PAS20181U220200027 inicio
					boolean esGarNominalDuaBD = false;
					boolean esGarNuevaOEA = false;
					boolean mostrarError = false;
					
					String rucImportador = "";				
					if (SunatStringUtils.isEqualTo( declaracionBD.getDua().getDeclarante().getTipoParticipante().getCodDatacat(), ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)) {
						rucImportador = declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad();
					}
					String[] entidadGarante =   {ConstantesDataCatalogo.ENTIDAD_GARANTE_EMPRESA_OEA,ConstantesDataCatalogo.ENTIDAD_GARANTE_IMP_FRECUENTE_SOL_OEA};
					GestionCtaCteGarNominalService gestionCtaCteGarNominalService =  (GestionCtaCteGarNominalService) fabricaDeServicios.getService("recauda2.garantia.GestionCtaCteGarNominalService");
					esGarNominalDuaBD = gestionCtaCteGarNominalService.esGarantiaNominal(rucImportador, declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia(), entidadGarante);		
					
					if(codgarantia!=null){
						esGarNuevaOEA = gestionCtaCteGarNominalService.esGarantiaNominal(rucImportador, declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia(), entidadGarante);
					}
					
					if(!esGarNominalDuaBD){//si la gar de numeracion no es nominal oea
						mostrarError = true;
					}
					
					else if(esGarNominalDuaBD && esGarNuevaOEA){//si se est� cambiando por otra garantia nominal oea
						mostrarError = true;
					}
					
					//casos explicitos:
					else if(esGarNominalDuaBD && !esGarNuevaOEA){
						
						String codModalidadBD =  declaracionBD.getDua().getCodmodalidad();
						String codModalidad = declaracion.getDua().getCodmodalidad();
						String regimenBD = declaracionBD.getDua().getCodregimen();
						boolean esCambioModalidad = !codModalidad.equals(codModalidadBD)?true:false;
												
						boolean teniaContingente = ((ValidacionOEAService)fabricaDeServicios.getService("ValidacionOEAService")).damTieneContingente(declaracionBD);
						boolean tieneContingente = ((ValidacionOEAService)fabricaDeServicios.getService("ValidacionOEAService")).damTieneContingente(declaracion);
						boolean esCambioContingente = (teniaContingente && !tieneContingente) || (!teniaContingente && tieneContingente)?true: false;
						
						boolean esInvitadoOEA = ((ValidacionOEAService)fabricaDeServicios.getService("ValidacionOEAService")).
								esInvitadoOEARegistradoOVigente( rucImportador, declaracionBD.getDua().getFecNumeracion());
						boolean esImportadorOEA = ((ValidacionOEAService)fabricaDeServicios.getService("ValidacionOEAService")).
								esOperadorCertificado(rucImportador, ConstantesDataCatalogo.IMPORTADOR_OEA, declaracionBD.getDua().getFecNumeracion());
						boolean esExportadorOEA = ((ValidacionOEAService)fabricaDeServicios.getService("ValidacionOEAService")).
								esOperadorCertificado(rucImportador, ConstantesDataCatalogo.EXPORTADOR_OEA, declaracionBD.getDua().getFecNumeracion());
						
						if(esExportadorOEA && !esImportadorOEA){
							mostrarError = true;
							
						}else if(esImportadorOEA){
							//si es reg 10 los gar oea admite solo dams anticipadas o urgentes, si no cumple se puede rectificar
							if(regimenBD.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){							
								if( (codModalidadBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && !esCambioModalidad)
										|| (esCambioModalidad && codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)) 
										|| (codModalidadBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) && !esCambioModalidad) ){
									mostrarError = true;
								}
							}else{
							//si es reg 20 o 21 los gar oea admite en cualquier modalidad urgente, excepcional o anticipado, no se permite rectificar
								mostrarError = true;
							}
						 
							
						}else if(esInvitadoOEA){
							
							//si es reg 10 los gar oea son anticipadas o (urgente o excepcional con contingente), si no cumple se puede rectificar
							if(regimenBD.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){								
								if(codModalidadBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && !esCambioModalidad && !teniaContingente && esCambioContingente){
									mostrarError = true;
								}
								if((codModalidadBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) || codModalidadBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE))
									&& teniaContingente && !esCambioContingente){
									mostrarError = true;
								}								
							}else{
							//si es reg 20 o 21 los gar oea se admiten solo anticipados, si no cumple se puede rectificar
								if(regimenBD.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && !esCambioModalidad){
									mostrarError = true;
								} 
							}
						}
						
						if(!esCambioModalidad && !esCambioContingente){
							mostrarError = true;
						}
					}  
					if(mostrarError){
						resultadoError.add(getErrorMap("07203", "NO SE PERMITE MODIFICAR EL NRO DE CTA DE LA GARANTIA EN LA RECTIFICACION"));
					}
				}// fin PAS20181U220200027
				 	
			}

			// Si ha rectificado datos del Importador
			if( !SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(),declaracionBD.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()) 
					||
					!SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(),declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad())
					){
				resultadoError.add(getErrorMap("07204", "NO SE PERMITE MODIFICAR DATOS DEL IMPORTADOR"));
			}
		}
		// Si no se ha enviado en la rectificacion
		else{
			//Si se ha enviado en la numeracion
			if(!SunatStringUtils.isEmptyTrim(codgarantiaBD)){
				resultadoError.add(getErrorMap("07203", "NO SE PERMITE MODIFICAR EL NRO DE CTA DE LA GARANTIA EN LA RECTIFICACION"));
			}
		}
		/*branch ingreso 2011-009 hosorio fin 11/04/2011*/

		//branch ingreso 2011-009 gmontoya 27/04/2011 13
		// Si en la Numeracion no tiene garantia y en la rectificacion si declara garantia
		if(SunatStringUtils.isEmptyTrim(codgarantiaBD) && !SunatStringUtils.isEmptyTrim(codgarantia))
		{
			DeudaDocumDAO deudaDocumDAO = fabricaDeServicios.getService("deudaDocumDAO");
			DeudaDocum tmpDeudaDocum = new DeudaDocum();
			tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			tmpDeudaDocum.setCodTipdeuda("01");

			List<DeudaDocum> lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
			for (DeudaDocum deudaDocum:lstDeudaDocum) {
				BigDecimal suma = SunatNumberUtils.sum(deudaDocum.getMtoPagado(),deudaDocum.getMtoImpugna()); 
				suma = SunatNumberUtils.sum(suma,deudaDocum.getMtoGarant());
				if (suma.compareTo(deudaDocum.getMtoDeuda())>=0 && deudaDocum.getCodEstpago().toUpperCase().equals("P")) {
					resultadoError.add(getErrorMap("30484","FORMATO C"));
					break;
				}
			}

			tmpDeudaDocum.setCodTipdeuda("02");

			lstDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
			for (DeudaDocum deudaDocum:lstDeudaDocum) {
				BigDecimal suma = SunatNumberUtils.sum(deudaDocum.getMtoPagado(),deudaDocum.getMtoImpugna()); 
				suma = SunatNumberUtils.sum(suma,deudaDocum.getMtoGarant());
				if (suma.compareTo(deudaDocum.getMtoDeuda())>=0 && deudaDocum.getCodEstpago().toUpperCase().equals("P")) {
					String strliquida = deudaDocum.getCodAduliquida().concat("-".concat(deudaDocum.getAnnLiquida().toString().concat("-".concat(deudaDocum.getNumLiquida()))));
					resultadoError.add(getErrorMap("30484","LC COMPLEMENTARIA:"+strliquida));
					break;
				}
			}
		}		
		//branch ingreso 2011-009 gmontoya 27/04/2011 13
		return resultadoError;
	}

	/*hosorio */
	/*hosorio inicio 04/04/2011*/
	/**
	 * Servicio que valida que no se rectifique el agente.
	 * 
	 * @param declaracion objeto que reprensenta la declaracion de rectificacion
	 * @param declaracionBD objeto que reprensenta la declaracion de  BD
	 * @return HashMap
	 * @throws Exception excepci�n exception
	 * @author hosorio
	 */
	public Map<String, String> Norectifiagente(Declaracion declaracion , Declaracion declaracionBD) throws Exception {
		/*
		 * Validar que no se este intentando rectificar el Agente Tabla ParticipanteDUA tipo operador '41' El sistema en funci�n de la lista
		 * anterior verificara que no se intente Cambiar los campos del Agente que numera la declaraci�n numdocumento y codtipooper de la
		 * clase DUA del objeto de validaci�n
		 */

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if(!SunatStringUtils.isEqualTo(declaracion.getDua().getCodtipooper(), declaracionBD.getDua().getCodtipooper())
				|| !SunatStringUtils.isEqualTo(declaracion.getDua().getNumdocumento() , declaracionBD.getDua().getNumdocumento())	 ){
			resultadoError = getErrorMap("30260", "DATOS DEL AGENTE RECTIFICADOS");
		}
		return resultadoError;
	}


	//1.4. Cuando en el despacho urgente, la rectificaci�n se transmita despu�s del levante y antes de la regularizaci�n.

	/**
	 * @param declaracion  Dua por rectificar
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> validaDespachoRectificacion(Declaracion declaracion) throws Exception{
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		DUA duaBD = obtenerDuaBD(declaracion);

		//if(SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) ){
		/*
			 Una DUA tiene Levante (Levante Autorizado) si el campo FEC_AUTLEVANTE  est� lleno (un valor diferente al valor por defecto del campo 01/01/01).
			 Una DUA esta regularizada si el campo FEC_REGULARIZA  est� lleno (un valor diferente al valor por defecto del campo 01/01/01).
		 */
		//Una DUA tiene Levante (Levante Autorizado) si el campo FEC_AUTLEVANTE  est� lleno (un valor diferente al valor por defecto del campo 01/01/01).

		/*     if(!SunatNumberUtils.isEqual(SunatDateUtils.getIntegerFromDate(duaBD.getFecAutlevante()), SunatDateUtils.getIntegerFromDate(SunatDateUtils.getDefaultDate()))
		    	&& 	 SunatNumberUtils.isEqual( SunatDateUtils.getIntegerFromDate(duaBD.getFecregulariza()),SunatDateUtils.getIntegerFromDate(SunatDateUtils.getDefaultDate()))
		       ){
		    	 resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("07205", "RECTIFICACION NO PERMITIDA DESPUES DE LEVANTE Y ANTES DE LA REGULARIZACION");
		     }
		 } Se SOLICITA EN RIN 07 DESBLOQUEO DE TRANSMISION DE RECTIFICACION ELECTRONICA POSTERIOR AL LEVANTE Y ANTERIOR A LA REGULARIZACION 



		/*
		1.5. Cuando la diligencia de despacho, diligencia de conclusi�n o diligencia de regularizaci�n, se encuentren en estado �En Proceso�. 
		 */
		String codEstadoDua=duaBD.getCodEstdua();

		//04 EN PROCESO DE DILIGENCIA//gmontoya restricciones
		if(SunatStringUtils.isEqualTo(codEstadoDua, "04")){
			resultadoError = getErrorMap("07206", "DESPACHO");
		}
		//12 EN PROCESO DE DILIGENCIA CONCLUSI�N
		else if(SunatStringUtils.isEqualTo(codEstadoDua, "12")){
			resultadoError = getErrorMap("07206", "CONCLUSI�N");
		}

		/*PAS20144E610000040 - La Diligencia de Regularizacion tambien va a contar con un estado en proceso
	    Map<String,Object>params = new HashMap<String, Object>();
		params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
		params.put("tipoSolicitud", ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION);
		params.put("estadosrecti", new String[] { ConstantesDataCatalogo.COD_EST_REGULA_ASIGNADA_ESPEC}); 


		//diligencia de regularizaci�n
		List<Map<String, Object>> lstSolRegulari = RectificacionServiceImpl.getInstance().getSolirectificaDAO()
				.listByDocumentoByParameterMap(params);

		if(!CollectionUtils.isEmpty(lstSolRegulari)){
			resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("07206", "REGULARIZACI�N");
		}*/

		//P34 3007 JMCV INICIO  		
		RectificacionOficioService	 oficioService  =fabricaDeServicios.getService("diligencia.rectificacionOficio.rectificacionOficioService"); 
		boolean tieneRectificacionOficioEnProceso = oficioService.tieneRectificacionOficioEnProceso(declaracion.getDua().getNumcorredoc().toString());

		if (tieneRectificacionOficioEnProceso){
			resultadoError = getErrorMap("35291", "RECTIFICACI�N OFICIO");
		}
		//P34 3007 JMCV FIN
		return resultadoError;
	}

	public List<Map<String, String>> validaActaInmovilizacion(Declaracion declaracion,Map<String, Object> variablesIngreso){
		SoporteService soporteService = (SoporteService)fabricaDeServicios.getService("soporteServiceDef");
		DetDeclaraDAO detDeclaraDAO = (DetDeclaraDAO)fabricaDeServicios.getService("detDeclaraDAO");
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();

		Map<String,Object> parametros = new HashMap<String,Object>();
		parametros.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
		parametros.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
		parametros.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
		parametros.put("NUM_DECLARACION", declaracion.getNumdeclRef().getNumcorre());
		parametros.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo().toString());
		parametros.put("COD_ADUAMANIFIESTO", declaracion.getDua().getManifiesto().getCodaduamanif());
		//parametros.put("ANN_MANIFIESTO",  Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4)));
		String annManif = "0";
		if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3)
			annManif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
		parametros.put("ANN_MANIFIESTO",  Integer.valueOf(annManif));		
		parametros.put("NUM_MANIFIESTO", declaracion.getDua().getManifiesto().getNummanif());
		parametros.put("COD_VIATRANS", declaracion.getDua().getManifiesto().getCodmodtransp());		

		List<Map<String,Object>> detailRows = detDeclaraDAO.select(parametros);
		parametros.put("LIST_SERIES", detailRows);

		//Acciones de Control Extraordinario(Actas de Inmovilizacion de Duas y Manifiestos y Avisos de Inspencion )
		Map<String,Object> aces=soporteService.obtenerAccionesDeControlExtraordinario(parametros);
		List<Map> duaactas =(List<Map>)aces.get("soloActasDua");
		//PAS20165E220200127
		List<Map> duaactasPF =(List<Map>)aces.get("soloActasDuaPF");
		List<Map> manifiestoactas =(List<Map>)aces.get("manifiestoactas");
		List<Map> avisosinspeccion =(List<Map>)aces.get("avisosinspeccion");

		Boolean blTieneMedPreveDua=false;
		Boolean blTieneMedPreveManif=false;
		Boolean blTieneAvisoInspencion=false;
		String mensaje =null;

		if(!CollectionUtils.isEmpty(duaactas)){
			for(Map item : duaactas){
				mensaje="LA DUA TIENE "+item.get("DESCRIPCION")+" : "+item.get("NROFULL");
				resultadoError.add( getErrorMap("30490", mensaje));
			}
			blTieneMedPreveDua=true;
		}
		//PAS20165E220200127
		if(!CollectionUtils.isEmpty(duaactasPF)){
			for(Map item : duaactasPF){

				mensaje="LA DUA TIENE ACE "+item.get("CTDOC_PRECO")+" - "+item.get("CADUA_DUA") +" - "+item.get("CPTOC_PRECO")+" - "+item.get("FANNO_PRECO")+" - "+item.get("NCORR_PRECO");
				resultadoError.add( getErrorMap("30490", mensaje));

			}
			blTieneMedPreveDua=true;
		}
		//Fin PAS20165E220200127
		if(!CollectionUtils.isEmpty(avisosinspeccion)){
			for(Map item : avisosinspeccion){
				mensaje="LA DUA TIENE "+item.get("DESCRIPCION")+" : "+item.get("NROFULL");
				resultadoError.add( getErrorMap("30490", mensaje));
			}
			blTieneAvisoInspencion=true;
		}

		if(!CollectionUtils.isEmpty(manifiestoactas)){
			for(Map item : manifiestoactas){
				mensaje="MANIFIESTO TIENE "+item.get("DESCRIPCION")+" : "+item.get("NROFULL");
				resultadoError.add( getErrorMap("30490", mensaje));
			}
			blTieneMedPreveManif=true;
		}

		variablesIngreso.put("blDuaTieneMedPreveDua", blTieneMedPreveDua); 
		variablesIngreso.put("blTieneMedPreveManif", blTieneMedPreveManif);
		variablesIngreso.put("blTieneAvisoInspencion", blTieneAvisoInspencion);


		return resultadoError;
	}
	/*hosorio fin 04/04/2011*/

	public List<Map<String,Object>> obtenerMedidasPreventivaDocTransporte(Declaracion declaracion ,DatoDocTransporte docTrans, String[] tiposActas){
		MovManifiestosActasDAO movManifActasDAO = (MovManifiestosActasDAO)fabricaDeServicios.getService("movManifiestosActasDAORef");
		Map<String,Object> params= new HashMap<String, Object>();

		params.put("cod_aduana_manif", declaracion.getDua().getManifiesto().getCodaduamanif()) ;
		params.put("nume_manif", declaracion.getDua().getManifiesto().getNummanif());
		params.put("anno_manif", Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4)));
		params.put("cod_via_transp", declaracion.getDua().getManifiesto().getCodmodtransp());
		params.put("codTiposActas", tiposActas);
		params.put("num_conocim", docTrans.getNumdoctransporte());

		List<Map<String,Object>> mapDocTransMedidaPreventiva=movManifActasDAO.findActasManifiestoByParams(params);
		return mapDocTransMedidaPreventiva;

	}
	public  List<Map<String,String>>  validarDescargosRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception{
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> listDescargos=null;
		NumdeclRef numdeclRef = declaracion.getNumdeclRef(); 
		Map<String,Object> params=new HashMap<String,Object>();		
		// Para el reg 20 y 21
		params.put("codaduana", numdeclRef.getCodaduana());
		params.put("annpresen", numdeclRef.getAnnprese());
		params.put("numdeclaracion", numdeclRef.getNumcorre());

		if ("21".equals(numdeclRef.getCodregimen())){			
			Ratcc3DAO ratcc3DAO = (Ratcc3DAO)fabricaDeServicios.getService("ratcc3DAO");
			for(DatoSerie serie:declaracion.getDua().getListSeries()){
				if(validarSeriePorCambios(serie, declaracionBD,"21")){
					params.put("seriei", serie.getNumserie());
					listDescargos=ratcc3DAO.getListaRatcc3(params);
					BigDecimal p_unid_fiqty=BigDecimal.ZERO;
					for(Map<String, Object> ritcc:listDescargos){				
						p_unid_fiqty = SunatNumberUtils.sum(p_unid_fiqty,new BigDecimal(ritcc.get("CANTIDAD").toString()));				
					}

					if(SunatNumberUtils.isLessThanParam(serie.getCntunifis(),p_unid_fiqty)){
						resultadoError.add(getErrorMap("30491",new Object[] {serie.getNumserie().toString(),serie.getCntunifis(),p_unid_fiqty}));
					}

				}
			}
		}


		if ("20".equals(numdeclRef.getCodregimen())){				
			RitCcDAO ritccDAO = (RitCcDAO)fabricaDeServicios.getService("ritccDAO");
			for(DatoSerie serie:declaracion.getDua().getListSeries()){
				if(validarSeriePorCambios(serie, declaracionBD,"20")){					
					params.put("nserpit", serie.getNumserie());
					listDescargos=ritccDAO.getListaRitcc(params);
					// Si a�n no existen registros en la cta cte entonces no existen descargos ni se ha efectuado la diligencia, por lo que podria ser rectificado
					if (listDescargos.size()> 0) {
						BigDecimal p_unid_fiqty=BigDecimal.ZERO;
						for(Map<String, Object> ritcc:listDescargos){				
							p_unid_fiqty = SunatNumberUtils.sum(p_unid_fiqty,new BigDecimal(ritcc.get("VUNIFISTRA").toString()));				
						}
						//Se atiende BUG 5659
						//if(SunatNumberUtils.isLessThanParam(serie.getCntunifis(),p_unid_fiqty)){
						if(SunatNumberUtils.isGreaterThanParam(serie.getCntunifis(),p_unid_fiqty)){
							resultadoError.add(getErrorMap("30491",new Object[] {serie.getNumserie().toString(),serie.getCntunifis(),p_unid_fiqty}));
						}
					}
				}					
			}
		}

		// Para el reg 70
		params.put("anoPrese", numdeclRef.getAnnprese().substring(2, 4));
		params.put("codiAduan", numdeclRef.getCodaduana());
		params.put("numeCorre", SunatStringUtils.lpad(numdeclRef.getNumcorre(),6,'0'));
		params.put("notSdel", "S");

		if ("70".equals(numdeclRef.getCodregimen())){
			DepoctaDAO depoctaDAO = (DepoctaDAO)fabricaDeServicios.getService("depoctaDAO");
			for(DatoSerie serie:declaracion.getDua().getListSeries()){
				if(validarSeriePorCambios(serie, declaracionBD,"70")){

					params.put("numeSerpr", SunatStringUtils.lpad(serie.getNumserie().toString(),4,' '));
					List<Depocta>  listDepocta = depoctaDAO.findByMap(params);
					Map<String,Object> cantidadesDepocta = SumValoresDepocta(listDepocta);
					if(SunatNumberUtils.isLessThanParam(serie.getCntpesoneto(),(BigDecimal)cantidadesDepocta.get("p_peso_neto"))){
						resultadoError.add(getErrorMap("30491",new Object[] {serie.getNumserie().toString().concat(" PESO NETO "),serie.getCntpesoneto(),(BigDecimal)cantidadesDepocta.get("p_peso_neto")}));
					}
					if(SunatNumberUtils.isLessThanParam(serie.getCntpesobruto(),(BigDecimal)cantidadesDepocta.get("p_peso_bruto"))){
						resultadoError.add(getErrorMap("30491",new Object[] {serie.getNumserie().toString().concat(" PESO BRUTO "),serie.getCntpesobruto(),(BigDecimal)cantidadesDepocta.get("p_peso_bruto")}));
					}
					if(SunatNumberUtils.isLessThanParam(serie.getCntunifis(),(BigDecimal)cantidadesDepocta.get("p_unid_fiqty"))){
						resultadoError.add(getErrorMap("30491",new Object[] {serie.getNumserie().toString().concat(" UNID. FISICAS "),serie.getCntunifis(),(BigDecimal)cantidadesDepocta.get("p_unid_fiqty")}));
					}

				}					
			}
		}

		return resultadoError;
	}
	/*hosorio fin 04/04/2011*/
	/***** GGRANADOS RIN16PASE3 INI *****/	
	/**
	 * 1.3.7.	Para el caso que se est� transmitiendo una declaraci�n de despacho urgente 
	 * el sistema valida que la Declaraci�n no cuente con una Solicitud de Regularizaci�n 
	 * en estado �En Proceso�.
	 * @param declaracion
	 * @return
	 * @throws Exception
	 */	
	public Map<String, String> validarDeclaracionTieneReguPendiente(Declaracion declaracionBD) throws Exception{
		// TODO: Verificar que estado es regularizacion estado en proceso
		if(declaracionBD.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)){

			Map<String, Object> paramRecti = new HashMap<String, Object>();
			paramRecti.put("numcorredocpre", declaracionBD.getDua().getNumcorredoc());
			paramRecti.put("codTransaccion", ConstantesDataCatalogo.TRANSACCION_SOLICITUD_REGULARIZACION_URGENTE);
			paramRecti.put("estadosrecti",new String[] {ConstantesDataCatalogo.COD_EST_REGULA_EN_PROCESO});
			CabSolrectiDAO cabSolRectiDAO = (CabSolrectiDAO )fabricaDeServicios.getService("despaduanero2.cabSolrectiDAO");
			List<Map<String, Object>> listaRecti = cabSolRectiDAO.listByDocumentoByParameterMap(paramRecti);

			if(!CollectionUtils.isEmpty(listaRecti)){
				return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35254");
			}

			//			if(declaracion.getDua().getCodEstdua().equals(ConstantesDataCatalogo.COD_DUA_REGULARIZACION_PROCESO)){						
			//				return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35254");
			//			}
		}

		return new HashMap<String, String>();
	}
	/***** GGRANADOS RIN16PASE3 FIN *****/	

	/* Inicio RIN10 3007 erodriguezb */


	/**
	 * Resumen: Valida si la declaraci�n transmite datos relacionados al Valor Provisional
	 * @param declaracion  Dua por rectificar
	 * @return
	 * @throws Exception
	 */
	public List<Map<String,String>> validarTransmisionValorProvisional(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception{
		DataCatalogoDAO dataCatalogoDAO = (DataCatalogoDAO)fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
		CabCtaCteGarDAO cabCtaCteGarDAO = (CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef");
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();
		String transmiteVP = "NO"; 
		boolean tieneIndicadorVP = validaIndicadorVP(declaracionBD);

		// Valida si transmiti� fecha fin de VP en Datos Generales
		if((declaracion.getDua().getFecfinprovsional()!=null || tieneIndicadorVP ||
				FormatoBUtils.validaTransmisionValorFormatoB(declaracion) /* RIN10 mpoblete BUG 21517 || FormatoBUtils.validaTransmisionValorSeries(declaracion)*/)
				&& SunatStringUtils.isStringInList(declaracion.getDua().getCodregimen(), pe.gob.sunat.despaduanero2.ayudas.util.Constantes.REGIMENES_VALOR_PROVISIONAL)){
			transmiteVP = "SI";
		}

		variablesIngreso.put("transmisionValorProvisional", transmiteVP);

		if("SI".equals(transmiteVP))
		{
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			List<Map<String, String>> resultadoErrorTmp = new ArrayList<Map<String, String>>();
			BigDecimal sumaBaseImponibleSeries = new BigDecimal(0); 
			Map<String,Object> mapParam = new HashMap<String,Object>();
			Map<String,Object> mapCabCtaCteGar = new HashMap<String,Object>();
			String codGarantia = null;
			String codGarantiaBD = null;
			Map<String, Object> DuaDiligenciada = null;
			// Comunes a 1 y 2
			// Porcentaje de Base Imponible
			
			DataCatalogo dataCatalogo =	dataCatalogoDAO.buscarDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP, 
							ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP);
			BigDecimal porcentajeBaseImponible = new BigDecimal(dataCatalogo.getDesCorta());

			codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia(); 
			codGarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();

			boolean transmiteItemVP = FormatoBUtils.validaItemTransmisionVP(declaracion);
			boolean todosItemsValorDefinitivo = FormatoBUtils.validaTodosItemsValorDefinitivo(declaracion);

			variablesIngreso.put("tieneIndicadorVP", tieneIndicadorVP);
			variablesIngreso.put("transmiteItemVP", transmiteItemVP);
			variablesIngreso.put("todosItemsValorDefinitivo", todosItemsValorDefinitivo);
			variablesIngreso.put("tieneGarantia160", !SunatStringUtils.isEmptyTrim(codGarantiaBD));
			variablesIngreso.put("acogerGarantia160", !SunatStringUtils.isEmptyTrim(codGarantia));


			//amancilla PAS20155E220200167
			boolean tieneIndicadorVPRegularizado = tieneIndicadorVPRegularizado(declaracionBD);
			// DUA regularizada: no cambie el Tipo de Valor al �2- Valor Provisional� en el formato B
			if(tieneIndicadorVPRegularizado){
				if(!todosItemsValorDefinitivo && FormatoBUtils.validaTodosItemsValorDefinitivo(declaracionBD)){
					//Encontr� cambio de tipo de valor de 1 a 2
					resultadoError.add(catalogoAyudaService.getError("35486"));
				}
			}

			// 1. DUA SIN Valor Provisional
			if(!tieneIndicadorVP)
			{			
				// Valida que declaraci�n no est� con estado "DESPACHO CONCLUIDO"
				if(ConstantesDataCatalogo.COD_DUA_DESPACHO_CONCLUIDO.equals(declaracionBD.getDua().getCodEstdua())){

					resultadoError.add(catalogoAyudaService.getError("35485"));//RIN10-KAH

				}
				ValNegocNumeracFormA valNegocNumeracFormA =  (ValNegocNumeracFormA)fabricaDeServicios.getService("ValNegocNumeracFormA");
				// ==> CUS 01.03.01 Validar numeraci�n de DUA de Importaci�n para el consumo con Valor Provisional
				resultadoErrorTmp = valNegocNumeracFormA.validarIngresoValorProvisional(declaracion, declaracionBD, DateUtil.getToday(), variablesIngreso); //PAS20155E220300034(SAU201510002000221)

				resultadoError.addAll(resultadoErrorTmp);
				//amancilla PAS20155E220200167 inicio
				if(ConstantesDataCatalogo.COD_CANAL_VERDE.equals(declaracion.getDua().getCodCanal())){
					resultadoError.add(catalogoAyudaService.getError("35578"));
				}

				if(ConstantesDataCatalogo.COD_CANAL_ROJO .equals(declaracion.getDua().getCodCanal())
						|| ConstantesDataCatalogo.COD_CANAL_NARANJA .equals(declaracion.getDua().getCodCanal())){
					CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
					Map mapDiligencia = cabdiligenciaDAO.findDuaDiligenciada(declaracion.getDua().getNumcorredoc().toString());

					if(!CollectionUtils.isEmpty(mapDiligencia)){
						resultadoError.add(catalogoAyudaService.getError("35579"));
					}
				}

				//amancilla PAS20155E220200167 fin

				// 1.1.	DUA(s) SIN Garant�a del Art�culo 160� de la LGA 
				if(SunatStringUtils.isEmptyTrim(codGarantiaBD)){
					//Se acoja a la garant�a art160, Incluya por lo menos 1 item con el valor �2-Valor Provisional�, 
					//y que cuente con el indicador de generaci�n de LC(VP)
					if(!SunatStringUtils.isEmptyTrim(codGarantia) && transmiteItemVP && validaIndicadorLCVP(declaracionBD)){

						//Obteniendo valor de base imponible
						sumaBaseImponibleSeries = BigDecimal.ZERO;
						for(DatoSerie serie : declaracion.getDua().getListSeries()){
							if(serie.getValestimado() != null){ 
								//mtosegdol + mtoajuste + mtofledol + mtofobdol
								sumaBaseImponibleSeries = sumaBaseImponibleSeries.add(
										serie.getMtoajuste()!=null?serie.getMtoajuste():BigDecimal.ZERO).add(
												serie.getMtosegdol()!=null?serie.getMtosegdol():BigDecimal.ZERO).add(
														serie.getMtofledol()!=null?serie.getMtofledol():BigDecimal.ZERO).add(
																serie.getMtofobdol()!=null?serie.getMtofobdol():BigDecimal.ZERO);
							}

						}						
						mapParam.put("NUMCTACTE", codGarantia.trim());
						mapParam.put("FECHAPROCESO", DateUtil.getToday());
						mapParam.put("IND_ACTIVO", Constantes.IND_ACTIVO);
						mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);

						//Si no trajo datos, no est� activa
						if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {
							resultadoError.add(catalogoAyudaService.getError("35499"));//RIN10-KAH

						}else{
							BigDecimal saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null? 
									new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;
									// Si garant�a no cubre...
									if (saldoOperativo.compareTo(sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal("100")))) < 0){

										resultadoError.add(catalogoAyudaService.getError("35498")); //RIN10-KAH  	
									}									
						}			
					}
				}						
			}
			// 2 DUA CON Valor Provisional
			else
			{
				//amancilla PAS20155E220200167 se determina que esto esta mal implementado se comenta y selleva arriba
				// DUA regularizada: no cambie el Tipo de Valor al �2- Valor Provisional� en el formato B
				/*
				if(!DateUtil.isNullOrDefaultFormatoSunat(declaracionBD.getDua().getFecregulariza())){
					if(!todosItemsValorDefinitivo && FormatoBUtils.validaTodosItemsValorDefinitivo(declaracionBD)){
						//Encontr� cambio de tipo de valor de 1 a 2
						resultadoError.add(catalogoAyudaService.getError("35486"));//RIN10-KAH

					}
				}*/

				//2.1.	Rectificaci�n Electr�nica que modifica a Valor Definitivo todos los �tems
				if(todosItemsValorDefinitivo){
					//Verifico si tiene diligencia de despacho
					CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
					DuaDiligenciada = cabdiligenciaDAO.findDuaDiligenciada(declaracionBD.getDua().getNumcorredoc().toString());

					//2.1.1.	Antes de la Diligencia de Despacho
					boolean duaNoTieneDiligenciaDespacho = CollectionUtils.isEmpty(DuaDiligenciada); 
					if (duaNoTieneDiligenciaDespacho) {
						//Validar que se transmita en blanco la �Fecha fin del valor provisional� (datos generales del formato A e �tem del formato B)
						if(declaracion.getDua().getFecfinprovsional() != null || FormatoBUtils.validaTransmisionFechaFinVP(declaracion)){

							resultadoError.add(catalogoAyudaService.getError("35487"));//RIN10-KAH
						}
						// erodriguezb 999 consultar. Validar tambi�n mtofobunita? que se env�e en blanco?
						//Validar que se transmita en blanco el �Valor Estimado� (�tem del formato B como de las series correlacionadas del formato A)
						//Inicio RIN10 BUG 21903
						//						if(FormatoBUtils.validaTransmisionValorSeries(declaracion) || FormatoBUtils.validaTransmisionValorEstimadoFormatoB(declaracion)){
						//							resultadoError.add(catalogoAyudaService.getError("35488"));//RIN10-KAH
						//
						//						}
						//Inicio RIN10 mpoblete BUG 22115
						//boolean tieneTransmitidoValorEstimadoFormatoB = FormatoBUtils.validaTransmisionValorEstimadoFormatoB(declaracion);
						//Fin RIN10 mpoblete BUG 22115
						for(DatoSerie serie : declaracion.getDua().getListSeries()){
							//Inicio RIN10 mpoblete BUG 22115
							//if(serie.getValestimado() != null || tieneTransmitidoValorEstimadoFormatoB){
							if(serie.getValestimado() != null){
								//Fin RIN10 mpoblete BUG 22115	
								resultadoError.add(catalogoAyudaService.getError("35488", new String[] {serie.getNumserie().toString()}));//RIN10-KAH								
							}
						}
						//Fin RIN10 BUG 21903

					}
					//2.1.2.	Despu�s de la Diligencia de Despacho  - CON y SIN Garant�a del Art�culo 160� LGA
					else{
						//Valor Estimado nivel del formato A debe ser mayor a cero y menor/igual al FOB D�lares
						for(DatoSerie serie : declaracion.getDua().getListSeries()){
							if(serie.getValestimado() != null){ 
								//AMANCILLA PAS20155E220200167
								//if( SunatNumberUtils.isLessOrEqualsThanZero(serie.getValestimado()) || SunatNumberUtils.isGreaterThanParam(serie.getValestimado(), serie.getMtofobdol())) {
								if( SunatNumberUtils.isLessOrEqualsThanZero(serie.getValestimado())) {
									resultadoError.add(catalogoAyudaService.getError("35492", new String[] {serie.getNumserie().toString(),serie.getNumserie().toString()}));//RIN10-KAH
								}
							}

						}

						BigDecimal tmpValorEstimadoPorCantidad = BigDecimal.ZERO;
						BigDecimal sumaValorEstimadoPorCantidad = BigDecimal.ZERO;
						BigDecimal sumaValestimadoSerie = BigDecimal.ZERO;
						BigDecimal tmpValMonto;
						BigDecimal tmpValEstimado = BigDecimal.ZERO;

						//Valor Estimado (Unitario) a nivel de �tems debe ser mayor a cero y menor/igual al FOB Unitario US$ declarado por �tem del formato B
						//Inicio RIN10 Bug 22036 (Se coloc� validacion en el segmento en caso se haya enviado al menos 1 item con valor provisional)
						//						if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
						//							for(DAV dav : declaracion.getListDAVs()){
						//								for(DatoFactura datoFactura : dav.getListFacturas()){
						//									for(DatoItem datoItem : datoFactura.getListItems()){
						//										tmpValMonto = datoItem.getMontoProv().getValmonto()!=null? datoItem.getMontoProv().getValmonto() : BigDecimal.ZERO;
						//										if( !(SunatNumberUtils.isGreaterThanZero(tmpValMonto) && SunatNumberUtils.isLessOrEqualsThanParam(tmpValMonto, datoItem.getMtofobunita()))){
						//
						//											resultadoError.add(catalogoAyudaService.getError("35493", new String[] {datoItem.getNumsecitem().toString()}));//RIN10-KAH
						//											
						//										}
						//									}
						//								}
						//							}
						//						}
						//Fin RIN10 Bug 22036

						boolean exception10 = false;
						//Sumatoria(Valor Estimado Unitario del �tem * Cantidad del �tem) = Valor Estimado de la Serie
						for(DatoSerie serie : declaracion.getDua().getListSeries()){
							for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(),serie)){
								tmpValMonto = datoItem.getMontoProv().getValmonto()!=null? datoItem.getMontoProv().getValmonto() : BigDecimal.ZERO;
								tmpValorEstimadoPorCantidad = tmpValorEstimadoPorCantidad.add(tmpValMonto.multiply(datoItem.getCntcantcomer()));							
							}
							tmpValEstimado = serie.getValestimado()!=null?serie.getValestimado():BigDecimal.ZERO;
							if(!exception10 && SunatNumberUtils.isGreaterThanParam(
									(tmpValEstimado.subtract(tmpValorEstimadoPorCantidad)).abs(),pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TOLERANCIA_USS)){
								resultadoError.add(catalogoAyudaService.getError("35494", new String[] {tmpValEstimado.toString(),serie.getNumserie().toString(),tmpValorEstimadoPorCantidad.toString()}));//RIN10-KAH
							}

							sumaValestimadoSerie = sumaValestimadoSerie.add(tmpValEstimado);						
							sumaValorEstimadoPorCantidad = sumaValorEstimadoPorCantidad.add(tmpValorEstimadoPorCantidad);
							tmpValorEstimadoPorCantidad = BigDecimal.ZERO;

						}


						if(SunatNumberUtils.isGreaterThanParam(
								(sumaValestimadoSerie.subtract(sumaValorEstimadoPorCantidad)).abs(),pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TOLERANCIA_USS)){

							resultadoError.add(catalogoAyudaService.getError("35495", new String[] {sumaValestimadoSerie.toString(),sumaValorEstimadoPorCantidad.toString()}));//RIN10-KAH
						}

						if(!SunatDateUtils.sonIguales(declaracion.getDua().getFecfinprovsional(), declaracionBD.getDua().getFecfinprovsional(), 
								SunatDateUtils.COMPARA_SOLO_FECHA) ){

							resultadoError.add(catalogoAyudaService.getError("35515", new String[] {
									SunatDateUtils.getFormatDate(declaracion.getDua().getFecfinprovsional(),"dd/MM/yyyy"),
									SunatDateUtils.getFormatDate(declaracionBD.getDua().getFecfinprovsional(),"dd/MM/yyyy")
							}));//erodriguezb bug 21740
						}
					}
				} else if(transmiteItemVP){ //---2.2.	Rectificaci�n que conserva por lo menos 1 �tem con Valor Provisional:---

					if(!SunatDateUtils.sonIguales(declaracion.getDua().getFecfinprovsional(), declaracionBD.getDua().getFecfinprovsional(), 
							SunatDateUtils.COMPARA_SOLO_FECHA) ){

						//Inicio RIN10 mpoblete BUG 21739
						//resultadoError.add(catalogoAyudaService.getError("35490"));//RIN10-KAH Se borro temporalmente
						String fechaFinProvRecti = SunatDateUtils.getFormatDate(declaracion.getDua().getFecfinprovsional(), FechaBean.FORMATO_DEFAULT);
						String fechaFinProvNumer = SunatDateUtils.getFormatDate(declaracionBD.getDua().getFecfinprovsional(), FechaBean.FORMATO_DEFAULT);						
						resultadoError.add(catalogoAyudaService.getError("35490", new String[] {fechaFinProvRecti,fechaFinProvNumer}));
						//Fin RIN10 mpoblete BUG 21739
					}
					ValNegocNumeracFormA valNegocNumeracFormA =  (ValNegocNumeracFormA)fabricaDeServicios.getService("ValNegocNumeracFormA");

					// Invocar CUS 01.03.01 valIngVpFA;
					resultadoErrorTmp.clear();
					resultadoErrorTmp = valNegocNumeracFormA.validarIngresoValorProvisional(declaracion, declaracionBD, DateUtil.getToday(), variablesIngreso); //PAS20155E220300034(SAU201510002000221)
					resultadoError.addAll(resultadoErrorTmp);

					//Inicio RIN10 Bug 22036
					boolean tieneErrorDuplicado = Boolean.FALSE;
					if(!CollectionUtils.isEmpty(resultadoErrorTmp)){
						for(Map<String,String> mapError:resultadoErrorTmp){
							if(Constants.COD_ERROR_TRANS_RECTI_RIN10_01.equals(mapError.get("codError"))){
								tieneErrorDuplicado = Boolean.TRUE;
								break;
							}
						}
					}
					String TIENE_VALOR_PROVISIONAL = "2";
					BigDecimal tmpValMonto = BigDecimal.ZERO;
					if(!tieneErrorDuplicado && !CollectionUtils.isEmpty(declaracion.getListDAVs())){
						for(DAV dav : declaracion.getListDAVs()){
							for(DatoFactura datoFactura : dav.getListFacturas()){
								for(DatoItem datoItem : datoFactura.getListItems()){
									tmpValMonto = datoItem.getMontoProv().getValmonto()!=null? datoItem.getMontoProv().getValmonto() : BigDecimal.ZERO;

									//AMANCILLA PAS20155E220200167
									//if(TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor()) && !(SunatNumberUtils.isGreaterThanZero(tmpValMonto) && SunatNumberUtils.isLessOrEqualsThanParam(tmpValMonto, datoItem.getMtofobunita()))){
									if(TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor()) && SunatNumberUtils.isLessOrEqualsThanZero(tmpValMonto)){

										resultadoError.add(catalogoAyudaService.getError("35493", new String[] {datoItem.getNumsecitem().toString()}));//RIN10-KAH

									}
								}
							}
						}
					}
					//Fin RIN10 Bug 22036

					//Comunes 2.2.1 y 2.2.2 -- Obteniendo valor de base imponible
					sumaBaseImponibleSeries = BigDecimal.ZERO;
					for(DatoSerie serie : declaracion.getDua().getListSeries()){
						if(serie.getValestimado() != null){ 
							//mtosegdol + mtoajuste + mtofledol + mtofobdol
							sumaBaseImponibleSeries = sumaBaseImponibleSeries.add(
									serie.getMtoajuste()!=null?serie.getMtoajuste():BigDecimal.ZERO).add(
											serie.getMtosegdol()!=null?serie.getMtosegdol():BigDecimal.ZERO).add(
													serie.getMtofledol()!=null?serie.getMtofledol():BigDecimal.ZERO).add(
															serie.getMtofobdol()!=null?serie.getMtofobdol():BigDecimal.ZERO);
						}

					}

					//2.2.1.	Rectificaci�n CON Garant�a 160� y cuente con indicador de generaci�n de LC(VP)
					if(!SunatStringUtils.isEmptyTrim(codGarantiaBD) && validaIndicadorLCVP(declaracionBD)){


						//PAS20165E220200001 - mtorralba 20160105 - Inicio
						CuentaCorrienteGarantiaService cuentaCorrienteGarantiaService = fabricaDeServicios.getService("cuentaCorrienteGarantiaService");
						String nroCuentaCorriente = cuentaCorrienteGarantiaService.obtenerCuentaCorrientePadre(codGarantiaBD.trim());
						if( nroCuentaCorriente==null || nroCuentaCorriente.equals("") )
							nroCuentaCorriente = codGarantiaBD.trim();

						//Obtengo saldo de cta.
						mapParam = new HashMap<String,Object>();
						mapParam.put("NUMCTACTE", nroCuentaCorriente);
						mapParam.put("FECHAPROCESO", DateUtil.getToday());

						List<String> listaGrupoActivo = new ArrayList<String>();  		
						listaGrupoActivo.add("1");
						listaGrupoActivo.add("2");
						mapParam.put("GRUPO_IND_ACTIVO", listaGrupoActivo);
						//PAS20165E220200001 - mtorralba 20160105 - Fin
					
						mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);
						BigDecimal saldoOperativo = BigDecimal.ZERO;

						if (!CollectionUtils.isEmpty(mapCabCtaCteGar)) {
							saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null? 
									new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;
						}

						// Obtener n�mero de liquidaci�n
						DeudaDocum tmpDeudaDocum = new DeudaDocum();
						tmpDeudaDocum.setNumCorredoc(declaracionBD.getDua().getNumcorredoc());
						tmpDeudaDocum.setCodTipdeuda(ConstantesDataCatalogo.DEUDA_TIPO_LIQ_COBR);
						tmpDeudaDocum.setMtoGarant(BigDecimal.ZERO);

						//List<DeudaDocum> result = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().obtenerLiquidacion(tmpDeudaDocum);
						List<DeudaDocum> result = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).obtenerLiquidacion(tmpDeudaDocum);

						BigDecimal montoLC = BigDecimal.ZERO;
						if (!CollectionUtils.isEmpty(result)){
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("rlarea", declaracionBD.getDua().getCodregimen());
							params.put("rladuaso", declaracionBD.getCodaduana());
							params.put("rlanoaso", declaracionBD.getDua().getAnnpresen().toString().substring(2));
							String numAso = declaracionBD.getNumeroDeclaracion().toString();
							numAso = SunatStringUtils.lpad(numAso, 6, '0');
							params.put("rlnumaso", numAso);
							params.put("LIST_RLNROLIQ", result);
							params.put("indValprov", TIENE_VALOR_PROVISIONAL);
							params.put("rlfeceli","0");

							//Liquida record = RectificacionServiceImpl.getInstance().getLiquidaDAO().getLCbyDeclaAndNumLiquida(params);
							Liquida record = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).getLCbyDeclaAndNumLiquida(params);
							montoLC = "S".equals(record.getRlcodmon())?record.getRlsmontot():record.getRldmontot();
							montoLC = montoLC != null? montoLC : BigDecimal.ZERO;

						}

						BigDecimal prodTmp = sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal(100)));

						//sigesi INC 2016-022453
						//variablesIngreso.put("modificarLC", montoLC.compareTo(prodTmp) != 0);
						//amancilla parche
						BigDecimal diferenciaAjuste = SunatNumberUtils.absoluteDiference(montoLC, prodTmp);
						BigDecimal tolerancia = new BigDecimal(1);  //1 dolar
						variablesIngreso.put("modificarLC", diferenciaAjuste.compareTo(tolerancia) == 1);
						//fin mancilla

						if(montoLC.compareTo(prodTmp) < 0){
							//que la garant�a cubra la diferencia
							if(saldoOperativo.compareTo(prodTmp.subtract(montoLC)) < 0){

								resultadoError.add(catalogoAyudaService.getError("35491"));//RIN10-KAH
							}
						}

					} //2.2.2.	Rectificaci�n de DUA(s) SIN Garant�a del Art�culo 160� de la LGA para acogerse a la Garant�a Art�culo 160� LGA
					else if(SunatStringUtils.isEmptyTrim(codGarantiaBD) && !SunatStringUtils.isEmptyTrim(codGarantia)){

						//Obtengo saldo de cta.
						mapParam = new HashMap<String,Object>();
						mapParam.put("NUMCTACTE", codGarantia.trim());
						mapParam.put("FECHAPROCESO", DateUtil.getToday());
						mapParam.put("IND_ACTIVO", Constantes.IND_ACTIVO);
						
						mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);

						//Si no trajo datos, no est� activa
						if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {

							resultadoError.add(catalogoAyudaService.getError("35499"));//RIN10-KAH

						}else{
							BigDecimal saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null? 
									new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;

									BigDecimal prodTmp = sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal(100)));

									if(saldoOperativo.compareTo(prodTmp) < 0){

										resultadoError.add(catalogoAyudaService.getError("35498"));//RIN10-KAH
									}
						}
					} //2.2.3 CUS 01.18.01
					else if(SunatStringUtils.isEmptyTrim(codGarantiaBD) && SunatStringUtils.isEmptyTrim(codGarantia)){

						BigDecimal prodTmp = sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal(100)));

						// Obtener n�mero de liquidaci�n
						DeudaDocum tmpDeudaDocum = new DeudaDocum();
						tmpDeudaDocum.setNumCorredoc(declaracionBD.getDua().getNumcorredoc());
						tmpDeudaDocum.setCodTipdeuda(ConstantesDataCatalogo.DEUDA_TIPO_LIQ_COBR);

						//List<DeudaDocum> result = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().obtenerLiquidacion(tmpDeudaDocum);
						List<DeudaDocum> result = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).obtenerLiquidacion(tmpDeudaDocum);

						BigDecimal montoLC = BigDecimal.ZERO;
						if (!CollectionUtils.isEmpty(result)){
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("rlarea", declaracionBD.getDua().getCodregimen());
							params.put("rladuaso", declaracionBD.getCodaduana());
							params.put("rlanoaso", declaracionBD.getDua().getAnnpresen().toString().substring(2));
							String numAso = declaracionBD.getNumeroDeclaracion().toString();
							numAso = SunatStringUtils.lpad(numAso, 6, '0');
							params.put("rlnumaso", numAso);
							params.put("LIST_RLNROLIQ", result);
							params.put("indValprov", TIENE_VALOR_PROVISIONAL);
							params.put("rlfeceli","0");

							//Liquida record = RectificacionServiceImpl.getInstance().getLiquidaDAO().getLCbyDeclaAndNumLiquida(params);
							Liquida record = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).getLCbyDeclaAndNumLiquida(params);
							montoLC = "S".equals(record.getRlcodmon())?record.getRlsmontot():record.getRldmontot();
							montoLC = montoLC != null? montoLC : BigDecimal.ZERO;
						}

						//sigesi INC 2016-022453
						//variablesIngreso.put("modificarLC", montoLC.compareTo(prodTmp) != 0);
						//amancilla parche
						BigDecimal diferenciaAjuste = SunatNumberUtils.absoluteDiference(montoLC, prodTmp);
						BigDecimal tolerancia = new BigDecimal(1);  //1 dolar
						variablesIngreso.put("modificarLC", diferenciaAjuste.compareTo(tolerancia) == 1);
						//fin mancilla
					}
				}					
			}
			variablesIngreso.put("declaracionDiligenciada", !CollectionUtils.isEmpty(DuaDiligenciada));

			//Compara objeto transmitido para grabar cambios propios de Valor Provisional
			SolicitudRectificacionBean solicitudRectificacion = comparaDeclaracionValorProvisional(declaracion, declaracionBD, variablesIngreso);
			//orquestadormap.put("solicitudRectificacion", solicitudRectificacion);
			variablesIngreso.put("solicitudRectificacion", solicitudRectificacion);
		}

		return resultadoError;
	}


	/**
	 * Resumen: Verifica si una declaraci�n tiene indicador de Valor Provisional
	 * @param declaracion Dua anterior
	 * @return
	 * @throws Exception
	 */
	public boolean validaIndicadorVP(Declaracion declaracionBD) throws Exception{
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		boolean result = false;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", declaracionBD.getDua().getNumcorredoc().toString());
		params.put("cod_indicador", Constantes.COD_INDICADOR_VP);
		params.put("ind_activo", Constantes.IND_ACTIVO);
		Map<String, Object>  indicadorVP = 	indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(params);
		if (Integer.parseInt(indicadorVP.get("CANT").toString()) > 0) {
			result = true;
		}

		return result;
	}


	//amancilla PAS20155E220200167
	public boolean tieneIndicadorVPRegularizado(Declaracion declaracion) throws Exception{
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		boolean result = false;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("num_corredoc", declaracion.getDua().getNumcorredoc().toString());
		params.put("cod_indicador", Constantes.COD_INDICADOR_VP);
		params.put("ind_activo", Constantes.INDICADOR_DUA_INACTIVO);
		Map<String, Object>  indicadorVP = 	indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(params);
		if (Integer.parseInt(indicadorVP.get("CANT").toString()) > 0) {
			result = true;
		}

		return result;
	}


	/**
	 * Resumen: Verifica si una declaraci�n cuenta con el indicador de generaci�n de LC(VP) 
	 * @param declaracion Dua anterior
	 * @return
	 * @throws Exception
	 */
	public boolean validaIndicadorLCVP(Declaracion declaracionBD) throws Exception{
		PadUsuGaraDAO padUsuGaraDAO = fabricaDeServicios.getService("padusugaraDef");
		boolean result = false;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_RUC", declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		params.put("IND_USUACTIVO",Constantes.IND_ACTIVO);
		params.put("PER_PROCESO", DateUtil.dateToString(new Date(), "yyyyMM"));

		String  indicadorLCVP = padUsuGaraDAO.obtenerIndicadorLCVP(params);

		if (Constantes.INDICADOR_GENERACION_LCVP.equals(indicadorLCVP)) {
			result=true;
		}

		return result;
	}

	private SolicitudRectificacionBean comparaDeclaracionValorProvisional(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, Object> orquestadormap = new HashMap<String, Object>();
		SolicitudRectificacionBean solicitudRectificacion = new SolicitudRectificacionBean();

		if (declaracionBD != null) {
			ComparatorFactoy comparatorFactoy = fabricaDeServicios.getService("ingresos.comparatorFactoy");
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			ComparadorDeclaracion rectificacionDua = (ComparadorDeclaracion)comparatorFactoy.getComparador(codTransaccion);
			rectificacionDua.setObjnuevo(declaracion);
			rectificacionDua.setObjanterior(declaracionBD);
			rectificacionDua.setEnviaFechaLlegada(funcionesService.esFechaLlegada(declaracion.getDua(), declaracionBD.getDua().getFecdeclaracion(),codTransaccion));

			solicitudRectificacion = (SolicitudRectificacionBean) variablesIngreso.get("solicitudRectificacion");

			rectificacionDua.setListaCambios(solicitudRectificacion.getListaCambios());
			rectificacionDua.comparacionValorProvisional(variablesIngreso);		

			//solicitudRectificacion.setListaCambios(rectificacionDua.getListaCambios());


		}

		return solicitudRectificacion;
	}

	/* Fin RIN10 3007 erodriguezb */

	/**
	 * Se encarga de cargar por unica vez declaracionBD en variablesIngreso. Se carga declaracionBD con el key "declaracionBDParaValidacionTLC"
	 * Proyecto msnade236_1
	 * @author glazaror
	 * @param declaracion declaracion transmitida
	 * @param declaracionBD declaracion en base datos
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @return errores de validacion
	 **/
	@ServicioAnnot(tipo = "V", codServicio = 3471, descServicio = "Almacena la declaracion obtenida de BD en variablesIngreso")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3471, numSecEjec = 333, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override
	public Map<String, Object> cargarDatosDeclaracionBD(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) {
		Map<String, Object> orquestadormap = new HashMap<String, Object>();
		if (declaracionBD != null) {
			variablesIngreso.put("declaracionBDParaValidacionTLC", declaracionBD);
		}
		return orquestadormap;
	}


	/**
	 * Se encarga de cargar por unica vez la cabecera de la solicitud en variablesIngreso. 
	 * Se carga cabecera de la solicitud con el key "cabSolicitudParaValidacionTLC"
	 * Proyecto msnade236_7
	 * @param declaracion declaracion transmitida
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @return errores de validacion
	 **/
	@ServicioAnnot(tipo = "V", codServicio = 3480, descServicio = "Almacena la cabecera de la solicitud obtenida en variablesIngreso")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3480, numSecEjec = 334, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override
	public Map<String, Object> cargarDatosSolicitud(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception{
		Map<String, Object> orquestadormap = new HashMap<String, Object>();
		if (declaracion != null) {
			variablesIngreso.put("cabSolicitudParaValidacionTLC", 
					obtenerDatosSolicitud(declaracion.getNumeroCorrelativo(), ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION)); 
		}
		return orquestadormap;
	}

	private SolicitudRectificacionBean obtenerDatosSolicitud(Long numCorredoc, String tipoSolicitud){
		CabSolrectiDAO  cabSolRectiDAO = (CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO");		
		Map<String, Object> paramsBusq = new HashMap<String,Object>();
		paramsBusq.put("numcorredocpre", numCorredoc);
		paramsBusq.put("codTipoSolicitud",tipoSolicitud );
		List<Map<String,Object>> solicitudMap = cabSolRectiDAO.listByDocumentoByParameterMap(paramsBusq);		
		SolicitudRectificacionBean solicitud = new SolicitudRectificacionBean();		
		if(solicitudMap!=null){
			solicitud.setNumcorredoc(Long.parseLong(solicitudMap.get(0).get("numCorredoc").toString()));
			solicitud.setFec_solicitud(SunatDateUtils.getDateFromUnknownFormat(solicitudMap.get(0).get("fecSolicitud").toString()));
		}
		return solicitud;
	}
	//Fin TLC 2016-66
	public List<Map<String,String>> validarPlazoDespachoAnticipado(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception{
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		

		boolean esAnticipado = ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(declaracion.getDua().getCodmodalidad()) ? true : false;

		if(!esAnticipado){
			return listError;
		}

		ManifiestoService manifiestoService =  fabricaDeServicios.getService("manifiesto.manifiestoService");

		DatoManifiesto manifiesto = declaracion.getDua().getManifiesto();
		String manifiestoYear = SunatStringUtils.length(manifiesto.getAnnmanif()) > 3 ? manifiesto.getAnnmanif().substring(0, 4) : null;

		boolean buscarManifiestoSigadActual = false;
		//buscarManifiestoSigadActual = SunatStringUtils.isStringInList(declaracion.getDua().getManifiesto().getCodmodtransp(), "0,4,7");
		buscarManifiestoSigadActual = SunatStringUtils.isStringInList(declaracion.getDua().getManifiesto().getCodmodtransp(),
				new String[]{ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA, ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO});
		
		/*Manifiesto manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
				manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual);*/
		
		/**PAS20181U220200049 inicio***/
		Manifiesto manifiestoBD = null;
		Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
	 		boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			buscarManifiestoSigadActual = true;//que busque en bdsigad y en sigad
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
					manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual, fechaReferencia,evaluarEER);			
	 	}else{/**PAS20181U220200049 fin***/
	 		manifiestoBD =  manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
					manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual);
	 	}
		
		
		if(manifiestoBD == null){
			return listError;
		}

		boolean esFecEfectiva = true;		
		Date fechaLlegada = null;
		if (manifiestoBD != null && (manifiestoBD.getFechaProgramadaLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaProgramadaLlegada())
				|| manifiestoBD.getFechaEfectivaDeLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaEfectivaDeLlegada()))) {
			if (manifiestoBD.getFechaEfectivaDeLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaEfectivaDeLlegada())) {
				fechaLlegada = manifiestoBD.getFechaEfectivaDeLlegada();
			} else {
				esFecEfectiva = false; 						
				fechaLlegada = manifiestoBD.getFechaProgramadaLlegada();
			}
		}		

		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");
		boolean correspondeModalidadAnticipada = valModalidadService.correspondeModalidadAnticipada(declaracion.getDua().getFecdeclaracion(), fechaLlegada);
		if(!correspondeModalidadAnticipada && esFecEfectiva){
			DataCatalogo catPlazoModalidadAnticipadaCasoFortuito = ((CatalogoAyudaService) fabricaDeServicios
					.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
							ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
							ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA_CASO_FORTUITO, declaracion.getDua().getFecdeclaracion());

			Integer plazoModalidadAnticipadaCasoFortuito = SunatNumberUtils.toInteger(catPlazoModalidadAnticipadaCasoFortuito.getDesCorta());
			Date fecMaxPlazoCasoFortuito = SunatDateUtils.addDay(declaracion.getDua().getFecdeclaracion(), plazoModalidadAnticipadaCasoFortuito);
			if (SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoCasoFortuito, SunatDateUtils.COMPARA_SOLO_FECHA)){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30733"));	
			} else {					        
				ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
				String  regimenDeclaracion= declaracion.getNumdeclRef().getCodregimen();
				Map<String,Object> params= new HashMap<String, Object>();				

				if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "17");
				} else if (ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "32");
				} else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "7");
				} else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "40");
				}

				params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
				params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
				params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
				params.put("procedim", "3126");
				params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
				List<Map<String,Object>> expedientes = expedienteService.findExpedientesAsociadoDeclaracion(params);
				if (CollectionUtils.isEmpty(expedientes)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35271"));
				} else {
					for (int i = 0; i < expedientes.size(); i++) {
						BigDecimal tipoconc = new BigDecimal(5);
						params.put("tipoConc", tipoconc);
						List<Map<String,Object>> expedienteProcedente = expedienteService.findExpedientesAsociadoDeclaracion(params);
						if (!CollectionUtils.isEmpty(expedienteProcedente)) {
							return listError;
						}
					}
				}		

				if (!CollectionUtils.isEmpty(expedientes)) {
					Map<String,Object> exp = expedientes.get(0);
					String aduanaExpediente=exp.get("CODI_ADUA")!=null?exp.get("CODI_ADUA").toString():null;
					String areaExpediente=exp.get("OFIC_REC")!=null?exp.get("OFIC_REC").toString():null;
					String anioExpediente=exp.get("ANOEXPEDI")!=null?exp.get("ANOEXPEDI").toString():null;
					String numeroExpediente=exp.get("NROEXPEDI")!=null?exp.get("NROEXPEDI").toString():null;
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35272", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente})); 
				}
			}
		}
		return listError;
	}

	/**
     * @author rtineo M_SNADE278_1: valida si la dam registrada ha sido numerada con la condicion de una diferida sin ICA
     * @param declaracion declaracion transmitida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return errores de validacion
     **/
	@ServicioAnnot(tipo = "V", codServicio = 3485, descServicio = "valida si la dam registrada correponde o ha sido numerada con la condicion de una diferida sin ICA")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3485, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override
	public Map<String,Object> validarDAMRegistradoEsDiferidaSinICA(Declaracion declaracionBD, Map<String, Object> variablesIngreso){
		Map<String,Object> mapErrores = new HashMap<String,Object>();
		DUA duaBD = declaracionBD.getDua();
		Boolean isDAMRegistradaDiferidaSinIca=false;
		ValCabdua valCabduaService =  (ValCabdua)fabricaDeServicios.getService("ValCabdua");
		Map<String,Object> mapResultado = valCabduaService.isDAMDiferidaSinICA(duaBD);
		
		if((Boolean)mapResultado.get("flag")){
			//guardamos en variablesIngreso 
			variablesIngreso.put("isDAMRegistradaDiferidaSinIca", true);
		}
		return mapErrores;
	}
	
	/**
     * @author rtineo M_SNADE278_1: valida si corresponde con la rectificacion del punto de llegada de TP a DT
     * @param declaracion declaracion transmitida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return errores de validacion
     **/
	@ServicioAnnot(tipo = "V", codServicio = 3486, descServicio = "valida si corresponde con la rectificacion del punto de llegada de TP a DT")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3486, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override
	public Map<String, String> validarRectiPuntoLlegadaDAMDiferidaSinICA(Declaracion declaracion,Declaracion declaracionBD, Map<String,Object> variablesIngreso){
		Map<String, String> mapErrores = new HashMap<String,String>();
		Boolean bool;
		DUA dua = declaracion.getDua();
		String codLugarRecepcion = dua.getCodlugarecepcion();
		Boolean isDAMRegistradaDiferidaSinIca = variablesIngreso.get("isDAMRegistradaDiferidaSinIca")!=null? (Boolean)variablesIngreso.get("isDAMRegistradaDiferidaSinIca"):false;
		Boolean isRectiPermitidoAnticipadoADiferido = false;
		Boolean isDAMDiferidaSinIca = false;
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");	
		Date fechaDeclaracion = dua.getFecdeclaracion()!=null?dua.getFecdeclaracion():new Date();
		boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
		// PASE PARA RECTIFICACION MOL
		if(isDAMRegistradaDiferidaSinIca && !esVigenteRIN05SegundaParte){
			//no ha habido cambio de modalidad para DAM Diferida sin ICA
			if(!ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codLugarRecepcion) && 
					!ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(codLugarRecepcion)){
					//Se obliga a rectificar, de terminal portuario a deposito temporal
					return getDUAError("37036","ESTA RECTIFICANDO UNA DAM DIFERIDA NUMERADA SIN ICA, SOLO PUEDE TRANSMITIR COMO PUNTO DE LLEGADA UN DEPOSITO TEMPORAL.");
				
			}
		}else{
			//validamos si proviene de una anticipada
			DUA duaBD = declaracionBD.getDua();
			if(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(duaBD.getCodmodalidad()) && ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL.equals(dua.getCodmodalidad())){
				//las mismas validaciones de numeracion
				isRectiPermitidoAnticipadoADiferido = true;
			}
			
		}
		variablesIngreso.put("isRectiPermitidoAnticipadoADiferido", isRectiPermitidoAnticipadoADiferido);
		return mapErrores;
	}
	
	/**
     * @author rtineo M_SNADE278_1: valida si se pretende cambiar el punto de llegada para una modalidad diferida del DT a TP
     * @param declaracion declaracion transmitida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @return errores de validacion
     **/
	@ServicioAnnot(tipo = "V", codServicio = 3487, descServicio = "valida si se pretende cambiar el punto de llegada para una modalidad diferida del DT a TP")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3487, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override
	public Map<String,String> validarCambioPuntoLlegadaDTaTP(Declaracion declaracion, Declaracion declaracionBD,Map<String,Object> variablesIngreso){
		//no se valida vigencia porque este cambio no deberia estar permitido en ningun momento
		Map<String, String> mapErrores = new HashMap<String,String>();
		DUA duaBD = declaracionBD.getDua();
		DUA dua = declaracion.getDua();
		if(!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(duaBD.getCodregimen())){
			return mapErrores;
		}
		if(!ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL.equals(duaBD.getCodmodalidad())){
			return mapErrores;
		}
		//validamos el catalogo ya que si esta cerrado deberia regresar.
		
		if(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(duaBD.getCodlugarecepcion()) && ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(dua.getCodlugarecepcion())){
			//se emite mensaje de error
			variablesIngreso.put("isRectiDiferidaNormal", true);
			return getDUAError("37037","NO ESTA PERMITIDO LA RECTIFICACION ELECTRONICA DEL PUNTO DE LLEGADA DE DEP�SITO TEMPORAL A TERMINAL PORTUARIO.");
		}
		return mapErrores;
	}
/*
	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}

	public ValCabdua getValCabdua() {
		return valCabdua;
	}

	public void setValCabdua(ValCabdua valCabdua) {
		this.valCabdua = valCabdua;
	}

	public ValNegocNumeracFormA getValNegocNumeracFormA() {
		return valNegocNumeracFormA;
	}

	public void setValNegocNumeracFormA(ValNegocNumeracFormA valNegocNumeracFormA) {
		this.valNegocNumeracFormA = valNegocNumeracFormA;
	}

	public ComparatorFactoy getComparatorFactoy() {
		return comparatorFactoy;
	}

	public void setComparatorFactoy(ComparatorFactoy comparatorFactoy) {
		this.comparatorFactoy = comparatorFactoy;
	}
*/
	/*mordonezl Pase70*/
	/*
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/






	//fin mordonezl
}
