package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DescripcionOtroCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescripOtrosDAO;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class GrabarDescripcionAdicionalServiceImpl extends ValDuaAbstract implements GrabarDescripcionAdicionalService {
	
	//private DescripOtrosDAO descripOtrosDAO;

	@Override
	public void grabaDescripcionOtros(Declaracion declaracion) {
		
		List<DescripcionOtroCatalogo> lstDescripOtroCat = new ArrayList<DescripcionOtroCatalogo>();
		DescripcionOtroCatalogo descrip;
		
		//Modalidad de pago    CAB_DECLARA.COD_MODPAGO  - 11 - codigo 7	DUA.DatoPago.DatoPagoTrans.codmodpago M
		if(declaracion.getDua().getPago().getPagoTransaccion().getCodmodpago().equals("7")) {
			descrip = new DescripcionOtroCatalogo(
					declaracion.getDua().getNumcorredoc(), 0, "T0051", "COD_MODPAGO", "11", "7", 
					declaracion.getDua().getPago().getPagoTransaccion().getDesModoPago());
			lstDescripOtroCat.add(descrip);
		}

        //Unidad de carga      CAB_ADI_IMPOCONSU.COD_UNIDAD_CARGA - 144	- c�digo 08 DUA.UnidadCarga.codCarga C
		if(declaracion.getDua().getUnidadCarga() != null && declaracion.getDua().getUnidadCarga().getCodCarga() != null &&
				declaracion.getDua().getUnidadCarga().getCodCarga().equals("08")) {
			descrip = new DescripcionOtroCatalogo(
					declaracion.getDua().getNumcorredoc(), 0, "T0048", "COD_UNIDAD_CARGA", "144", "08", 
					declaracion.getDua().getUnidadCarga().getDesCarga());
			lstDescripOtroCat.add(descrip);
		}
		//Proveedor
		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
			for (DAV dav : declaracion.getListDAVs()) {
				//Nivel comercial del importador FORMBPROVEEDOR.COD_NIVELCOMER - 85	- c�digo 5	DAV.codnivcomer M
				if(!SunatStringUtils.isEmpty(dav.getCodnivcomer()) && dav.getCodnivcomer().equals("5")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_NIVELCOMER", "85", "5", 
							dav.getDesNivComer());
					lstDescripOtroCat.add(descrip);
				}
				//Condici�n del proveedor   FORMBPROVEEDOR.COD_CONDPROVE - 86	- c�digo 4	DAV.codcondprov M
				if(!SunatStringUtils.isEmpty(dav.getCodcondprov()) && dav.getCodcondprov().equals("4")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_CONDPROVE", "86", "4", 
							dav.getDesCondProv());
					lstDescripOtroCat.add(descrip);
				}
				//Tipo de intermediario  FORMBPROVEEDOR.COD_TIPINTERM - 87	- c�digo 5	DAV.codtipinter C
				if(!SunatStringUtils.isEmpty(dav.getCodtipinter()) && dav.getCodtipinter().equals("5")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_TIPINTERM", "87", "5", 
							dav.getDesTipInter());
					lstDescripOtroCat.add(descrip);
				}
				//Naturaleza de la transacci�n FORMBPROVEEDOR.COD_NATUTRANS - 81	- c�digo 28	DAV.codnatutrans M
				if(!SunatStringUtils.isEmpty(dav.getCodnatutrans()) && dav.getCodnatutrans().equals("28")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_NATUTRANS", "81", "28", 
							dav.getDesNatuTrans());
					lstDescripOtroCat.add(descrip);
				}
				//Medio de pago FORMBPROVEEDOR.COD_MEDIO_PAGO - 147	- c�digo 14	DAV.DocumentoSoporteFormatoB.codMedioPago M
				if(!SunatStringUtils.isEmpty(dav.getCodMedioPago()) && dav.getCodMedioPago().equals("14")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_MEDIO_PAGO", "147", "14",
							dav.getDesMedioPago());
					lstDescripOtroCat.add(descrip);
				}
				//Entidad financiera FORMBPROVEEDOR.COD_ENTI_FINANC - 148	- c�digo 99	DAV.DocumentoSoporteFormatoB.codEntidadFinanciera C
				if(!SunatStringUtils.isEmpty(dav.getCodEntidadFinanciera()) && dav.getCodEntidadFinanciera().equals("99")) {
					descrip = new DescripcionOtroCatalogo(
							declaracion.getDua().getNumcorredoc(), dav.getNumsecuprov(), "T0070", "COD_ENTI_FINANC", "148", "99",
							dav.getDesEntidadFinanciera());
					lstDescripOtroCat.add(descrip);
				}
				
				//Formato B - item	
		        //ITems estado de la mercanc�a ITEMFACTURA.COD_ESTMERC - 25	- c�digo 99	DAV.DatoFactura.DatoItem.codestamer M
				if(!CollectionUtils.isEmpty(dav.getListFacturas())) {
					for(DatoFactura factura : dav.getListFacturas()) {
						if(!CollectionUtils.isEmpty(factura.getListItems())) {
							for(DatoItem item : factura.getListItems()) {
								if(!SunatStringUtils.isEmpty(item.getCodestamer()) && item.getCodestamer().equals("99")) {
									descrip = new DescripcionOtroCatalogo(
											declaracion.getDua().getNumcorredoc(), item.getNumsecitem(), "T0078", "COD_ESTMERC", "25", "99", 
											item.getDesEstMer());
									lstDescripOtroCat.add(descrip);
								}
							}
						}						
					}					
				}
			}
		}
		
		if(!CollectionUtils.isEmpty(lstDescripOtroCat)) {
			DescripOtrosDAO descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("declaracion.descripOtrosDAO");
			for (DescripcionOtroCatalogo descripOtroCat : lstDescripOtroCat) {
				descripOtrosDAO.insert(descripOtroCat);
			}
		}

	}
	
	
	//public void setDescripOtrosDAO(DescripOtrosDAO descripOtrosDAO) {
	//	this.descripOtrosDAO = descripOtrosDAO;
	//}

}
