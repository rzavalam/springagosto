/*
 * Clase que define el servicio de validaciones de complejas para el formato A de la declaracion.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import static pe.gob.sunat.despaduanero2.manifiesto.util.Constantes.IND_REGISTRO_ACTIVO;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TIENE_VALOR_PROVISIONAL;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.NO_TIENE_VALOR_PROVISIONAL;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TOLERANCIA_USS; //erodriguezb
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima.TIPO_VEHICULO;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FuncionesFechaService;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import org.springframework.util.StringUtils;

import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.despaduanero.catalogo.tg.model.MRestri;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.OperadorComexDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.service.MrestriDAOService;
import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.DipolizaiDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService; 
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.TipoDeDescrMinimaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PreferenciaArancelariaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.EstadoMercanciaTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.SubPartidaNacionalTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.Contplazo;
import pe.gob.sunat.despaduanero2.declaracion.model.CtaCtePerNat;
import pe.gob.sunat.despaduanero2.declaracion.model.Cupolibe;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoTributosAutocalc;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Maxapl;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefRucDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatparSenasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CtaCtePerNatDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CupolibeDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExpediDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MaxaplDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PrupersoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TasadumpDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.manifiesto.model.Datado;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoOABL;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdage;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2Service;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoDeTransporteService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos; 
import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionSIGADService;


/**
 * The Class ValNegocNumeracFormA. Clase que define el servicio de validaciones de complejas para el formato A de la declaracion.
 */
public class ValNegocNumeracFormAServiceImpl extends ValDuaAbstract implements ValNegocNumeracFormA{
	
	//private DetDeclaraDAO detDeclaraDAO;

	//private ValNegocCtaCteDepFormA SPTD_CTACTEDEPOSITO;
	//private ValNegocAduadet1FormA SPTD_ADUADET1;
	//private FabricaDeServicios fabricaDeServicios;

	//private AyudaService ayudaService; 
	//private DdpDAOService ddpDAOService;
	//private MrestriDAOService mrestriDAOService;
	//private TabLibeDAOService tabLibeDAOService;
	//private ValVerilib valVerilib;
	//private ValNegocAduahdr1FormA valNegocAduahdr1FormA;
	//private PackageTD packageTD;
	//private ValItemFB valItemFB;
	protected static final String CODIGO_PUNTO_LLEGADA_ZOFRATACNA = "16";
	//private Log log = LogFactory.getLog(ValNegocNumeracFormAServiceImpl.class);

	/**
	 * Permite obtener el documento de transporte del manifiesto de carga
	 * @param manifiesto
	 * @param serie
	 * @return
	 */
	private List<DocumentoDeTransporte> obtenerDocumentosDeTransporte(Manifiesto manifiesto, Map<String, Object> serie){
		Map<String, Object> paramManif = new HashMap<String, Object>();
		Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
		DocumentoDeTransporteService documentoDeTransporteService = fabricaDeServicios.getService("manifiesto.documentoDeTransporteService");
		paramManif.put("numeroCorrelativo",manifiesto.getNumeroCorrelativo());
		paramManif.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP"));
		if (SunatNumberUtils.toInteger(serie.get("NUM_DETALLE")) > 0){
			paramManif.put("numeroDeDetalle", serie.get("NUM_DETALLE"));
		} else{
			Map<String, Object> paramDatado = new HashMap<String, Object>();
			//mordonezl pase70
			if(serie.get("NUM_CORREDOC")!=null){
				paramDatado.put("detalleNumeroCorrelativo", serie.get("NUM_CORREDOC"));
			}
			//fin mordonezl
			paramDatado.put("codigoAduana", manifiesto.getAduana().getCodDatacat());
			paramDatado.put("anioManifiesto", manifiesto.getAnioManifiesto());
			paramDatado.put("numeroManifiesto",manifiesto.getNumeroManifiesto());
			paramDatado.put("codigoTipoManifiesto", manifiesto.getTipoManifiesto().getCodDatacat());
			paramDatado.put("numeroDocumentoTransporte", serie.get("NUM_DOCTRANSP"));
			List<Datado> listdatado = datado2Service.obtenerDatadoByParameterMap(paramDatado);
			if (listdatado.size() > 0){
				paramManif.put("numeroDeDetalle",listdatado.get(0).getDocumentoDeTransporte().getNumeroDeDetalle());
			}
		}
		List<DocumentoDeTransporte> listDocTransporte = documentoDeTransporteService.obtenerDocumentosDeTransporteByParameterMap(paramManif);
		return listDocTransporte;
	}

	private boolean tieneVentasSucecivas(DatoSerie serie,Declaracion declaracion)
	{   boolean result = false;
	DatoFactura factura = getFacturaCorrespondiente(serie,declaracion);
	if(factura!=null)
	{   if(!CollectionUtils.isEmpty(factura.getListFactSucesivas()))						
	{result = true;}
	}					
	return result;
	}

	public DatoFactura getFacturaCorrespondiente(DatoSerie serie, Declaracion declaracion) {
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							return factura;
						}
					}
				}
			}
		}

		return null;
	}

	public DAV getDAVCorrespondiente(DatoSerie serie, Declaracion declaracion) {
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							return dav;
						}
					}
				}
			}
		}

		return null;
	}	

	//No se usa
	//	private DatoMontoGastoUtil ConvertirListaAMontoGastoUtil(Elementos<DatoMontoGasto> montosGasto)
	//	{
	//		DatoMontoGastoUtil monGastoUtil = new DatoMontoGastoUtil();
	//		for(DatoMontoGasto tmpMongasto:montosGasto)
	//		{
	//			if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MPUBLICA))
	//			{monGastoUtil.setMpublica(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANS))
	//			{monGastoUtil.setMtrans(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOPCPU))
	//			{monGastoUtil.setMopcpu(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MROOF))
	//			{monGastoUtil.setMroof(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MEQUICD))
	//			{monGastoUtil.setMequicd(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVCD))
	//			{monGastoUtil.setMnvcd(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVD))
	//			{monGastoUtil.setMnvdvd(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTPUB))
	//			{monGastoUtil.setMotpub(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MPUAJU))
	//			{monGastoUtil.setMpuaju(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFOBFACT))
	//			{monGastoUtil.setMfobfact(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MREPARA))
	//			{monGastoUtil.setMrepara(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MBUECO))
	//			{monGastoUtil.setMbueco(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MMAXIM))
	//			{monGastoUtil.setMmaxim(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCTIMON))
	//			{monGastoUtil.setMctimon(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFLETE))
	//			{monGastoUtil.setMflete(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MSEGURO))
	//			{monGastoUtil.setMseguro(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTASA))
	//			{monGastoUtil.setMtasa(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANEX))
	//			{monGastoUtil.setMtranex(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANIN))
	//			{monGastoUtil.setMtranin(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRASLA))
	//			{monGastoUtil.setMtrasla(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MUVENTA))
	//			{monGastoUtil.setMuventa(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTROST))
	//			{monGastoUtil.setMotrost(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVTV))
	//			{monGastoUtil.setMnvtv(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVDTV))
	//			{monGastoUtil.setMnvdvdtv(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MAIRE))
	//			{monGastoUtil.setMaire(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTAPIZ))
	//			{monGastoUtil.setMtapiz(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCCOLOR))
	//			{monGastoUtil.setMccolor(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MARO))
	//			{monGastoUtil.setMaro(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCTRANS))
	//			{monGastoUtil.setMctrans(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MADAPTA))
	//			{monGastoUtil.setMadapta(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTROS))
	//			{monGastoUtil.setMotros(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MROOFA))
	//			{monGastoUtil.setMroofa(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MEQUICDA))
	//			{monGastoUtil.setMequicda(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVCDA))
	//			{monGastoUtil.setMnvcda(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVDA))
	//			{monGastoUtil.setMnvdvda(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFOBCALC))
	//			{monGastoUtil.setMfobcalc(tmpMongasto);}
	//			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MVADUAN))
	//			{monGastoUtil.setMvaduan(tmpMongasto);}			 
	//		}	
	//		return monGastoUtil;
	//	}
	//Fin JPL 17/04/2011


	/**
	 * Validar envio formato b.
	 * @deprecated Validar su uso por duplicidad de funcionalidad valgralfb4 del ValCabdAV
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	public List<Map<String,String>> validarEnvioFormatoB(Declaracion declaracion){
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		Participante datodeclarante = declaracion.getDua().getDeclarante(); 
		boolean exoneradoFB=funcionesService.isExonerado(datodeclarante.getTipoDocumentoIdentidad().getCodDatacat(), datodeclarante.getNumeroDocumentoIdentidad(),
				SunatDateUtils.getCurrentIntegerDate());

		//		boolean esImpFrecYDuaAnticipada = 
		//			SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), "10") &&
		//			SunatStringUtils.isEqualTo(declaracion.getDua().getCodlugarecepcion(), "03") &&
		//			FormatoAServiceImpl.getInstance().getFuncionesService().isImportadorFrecuente(
		//					declaracion.getDua().getCodregimen(), datodeclarante.getTipoDocumentoIdentidad().getCodDatacat(), datodeclarante.getNumeroDocumentoIdentidad());

		if (!exoneradoFB){
			List<DAV> listDav=declaracion.getListDAVs();
			if (listDav==null || listDav.isEmpty()){
				grabaTelelog(listError,"30396","No envia Formato B y declarante no se encuentra exonerado de hacerlo.");
			}
		}
		return listError;
	}

	/**
	 * Realiza las validacion segun la ley 29077.<br>
	 * Cuando el codigo de tipo de tratamiento es 4 todas las partidas deben ser 9805000000. 
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2347)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2347,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> val29077(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		Elementos<DatoSerie> series=declaracion.getDua().getListSeries();
		//TDDI 41-47 Ley 29077 Regla 11
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		Map<String,Object> paramsCatRefPartidas=new HashMap<String,Object>();
		paramsCatRefPartidas.put("tipo_uso", "DNA");
		paramsCatRefPartidas.put("finivig", SunatDateUtils.getCurrentIntegerDate());
		paramsCatRefPartidas.put("ffinvig", SunatDateUtils.getCurrentIntegerDate());
		//int contCatRefPartidas=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefPartidas);

		paramsCatRefPartidas.put("ayudaID", "CatRefpartidas");
		Integer contCatRefPartidas = (Integer)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRefPartidas);


		if (contCatRefPartidas>0){
			boolean partNandi9805000000=true;
			for(DatoSerie serie:series){
				Long partNandi=serie.getNumpartnandi();
				if (partNandi==9805000000L){
					if (!"4".equals(dua.getCodtipotratamiento())){
						grabaWarningTelelog(listError,"00008","PARA PART_NANDI 9805000000 DEBE ENVIAR TIPO_TRAT=4");
					}
				}else{
					partNandi9805000000=false;
				}
			}
			if (!partNandi9805000000){
				grabaWarningTelelog(listError,"06134","Todas las partidas deben ser 9805000000");
			}
		}
		return listError;
	}

	/**
	 * Validaciones previas formato a.
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param variablesIngreso Map<String,Object>
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2348)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2348,numSecEjec=2,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validacionesPreviasFormatoA(Declaracion declaracion, String numOrden, Map<String,Object> variablesIngreso){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();

		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		//boolean gblfce=(Boolean)mapVariables.get("gblfce");
		String tipo_despa=(String)mapVariables.get("tipo_despa");
		String mcodi_regi=(String)mapVariables.get("mcodi_regi");
		String mtesoc=(String)mapVariables.get("mtesoc");
		String mtipo_trans=(String)mapVariables.get("mtipo_trans");
		//String mcodi_alma=(String)mapVariables.get("mcodi_alma");
		//String mcjurisdicc=(String)mapVariables.get("mcjurisdicc");
		String maduana=(String)mapVariables.get("maduana");
		String codTransaccion   =(String) variablesIngreso.get("codTransaccion");
		Participante partic=dua.getDeclarante();
		DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
		//DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
		//String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;

		codTransaccion=codTransaccion.substring(2, 4);
		String anhoOrden=numOrden.substring(0,4);
		Integer anhoOrdenInt=new Integer(anhoOrden);
		Integer anho=new Integer(SunatDateUtils.getCurrentFormatDate("yyyy"));
		if (anhoOrdenInt>anho)
			grabaWarningTelelog(listError,"05001","ANHO DE LA ORDEN INTERNA INCORRECTO");

		//		ValNegocAduahdr1FormA valAduahdr1=new ValNegocAduahdr1FormA(); 
		if (declaracion.getDua().getDeclarante()!=null && !"05".equals(codTransaccion)){
			ValNegocAduahdr1FormA valNegocAduahdr1FormA =  fabricaDeServicios.getService("ValNegocAduahdr1FormA");
			Map<String,Object> mapValDeclarante=valNegocAduahdr1FormA.valDeclarante(listError, SunatDateUtils.getCurrentIntegerDate(), declaracion.getDua().getDeclarante());
			variablesIngreso.putAll(mapValDeclarante);
		}

		if (("02".equals(tipo_despa) && "N".equals(mtesoc))||("02".equals(tipo_despa) && "A".equals(mtesoc))){
			grabaWarningTelelog(listError,"00041","TIPO_DESPA: D.URGE : "+tipo_despa);
		}

		//if (!"21".equals(mcodi_regi)){ Se elimino la restriccion del regimen 21 - Betty y Karina
		if ("S".equals(declaracion.getDua().getIndSocorro()) && !"01".equals(tipo_despa)){
			grabaTelelog(listError,"30436","DECLARO INDICADOR DE SOCORRO Y NO ES DESPACHO URGENTE");
		}
		//}
		//if ("10".equals(mcodi_regi) && '2'==tipo_despa.charAt(tipo_despa.length()-1)){
		if (ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(mcodi_regi) && '2'==tipo_despa.charAt(tipo_despa.length()-1)){
			if ("S".equals(mtesoc)){
				Map<String,Object> mapParamsCatRefRuc=new HashMap<String,Object>();
				mapParamsCatRefRuc.put("ctipoUso", "URG");
				mapParamsCatRefRuc.put("ctipodoc", codTipoDocumento);
				mapParamsCatRefRuc.put("cdocumen", numeroDocumentoIdentidad);
				mapParamsCatRefRuc.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
				//HECHO SELECT * FROM cat_refruc WHERE ctipo_uso='URG' AND CTIPODOC = CABECERA.tipo_docum 
				//AND CDOCUMEN = CABECERA.Nume_Docum AND gc_fech_ingsi BETWEEN finivig AND ffinvig
				//int contCatRefRuc=FormatoAServiceImpl.getInstance().getCatRefRucDAO().count(mapParamsCatRefRuc);
				int contCatRefRuc=((CatRefRucDAO)fabricaDeServicios.getService("catRefRucDAO")).count(mapParamsCatRefRuc);
				if (contCatRefRuc==0 && (!"8".equals(dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()) || !"00000851".equals(dua.getDeclarante().getNumeroDocumentoIdentidad())))
					grabaWarningTelelog(listError,"00041","TIPO DESPA "+tipo_despa);
			}else
				grabaWarningTelelog(listError,"00041","TIPO DESPA: D. Urge "+tipo_despa);
		}
		//TDDI 50D-XV Regla 13
		if (("01".equals(dua.getCodmodalidad()) && SunatStringUtils.include(dua.getCodprodurgente(), new String[]{"12","N"}))||("02".equals(dua.getCodmodalidad()) && "07".equals(dua.getCodprodurgente()))){
			//if (dua.getListOtrosDocSoporte()==null || dua.getListOtrosDocSoporte().isEmpty()){ PAS201830001100005 - Solo el Inciso N O 12 requiere de Documento Autorizante - se retira incisos "A","G"
			if (dua.getListOtrosDocSoporte()!=null && !dua.getListOtrosDocSoporte().isEmpty()){
				for(DatoOtroDocSoporte doc:dua.getListOtrosDocSoporte()){
					if ("2".equals(doc.getCodtipoproceso())){
						if (!"01".equals(doc.getCodtipodocasoc().toString())){
							grabaTelelog(listError,"05045","DUADOCAS.TIPO_DOCAS - TIPO DOCUMENTO NO ES UN EXPEDIENTE (1):"+doc.getCodtipodocasoc());
						}
						if (SunatStringUtils.isEmptyTrim(doc.getAnndocasoc()) || doc.getAnndocasoc().compareTo(String.valueOf((new Integer(SunatDateUtils.getCurrentFormatDate("yyyy")))-1))<0 ){
							grabaTelelog(listError,"05046","DUADOCAS.ANNO_DOCAS - AO EXPEDIENTE CALIFICACION INCORRECTO :"+doc.getAnndocasoc());
						}
						if (SunatStringUtils.isEmptyTrim(doc.getNumdocasoc())){
							grabaTelelog(listError,"05047","DUADOCAS.NUME_DOCAS - NUMERO DE EXPEDIENTE DE CALIFICACION INCORRECTO :"+doc.getNumdocasoc());
						}
						if (doc.getFecdocasoc()==null){
							grabaTelelog(listError,"05048","DUADOCAS.FECH_DOCAS - FECHA DEL EXPEDIENTE INCORRECTO :"+doc.getFecdocasoc());
						}
						if (!SunatStringUtils.isNumeric(doc.getNumdocasoc())){
							grabaTelelog(listError,"05110","DUADOCAS.NUME_DOCAS - NUMERO DE EXPEDIENTE DE CALIFICACION INCORRECTO :"+doc.getNumdocasoc());
						}else{
							Map<String,Object> mapParamsExpedi=new HashMap<String,Object>();
							mapParamsExpedi.put("codiAdua", maduana);
							mapParamsExpedi.put("anoexpedi", doc.getAnndocasoc().substring(0, 4));
							mapParamsExpedi.put("nroexpedi", doc.getNumdocasoc());
							mapParamsExpedi.put("procedim", "2100");
							mapParamsExpedi.put("tipoConc", 5);

							/*Se verifica en la tabla EXPEDI lo siguiente:
								Hecho Select Asunto, Ofic_Rec From Expedi Where Codi_Adua = '" + maduana + "' 
								And AnoExpedi = '" + DOC_ASOC.Anno_Docas + "' And NroExpedi =  " + DOC_ASOC.Nume_Docas + " 
								And  Procedim  = '2100' And Tipo_Conc = 5 And Fech_Conc > 0*/
							//int contExpedi=FormatoAServiceImpl.getInstance().getExpediDAO().count(mapParamsExpedi);
							int contExpedi=((ExpediDAO)fabricaDeServicios.getService("expediDAO")).count(mapParamsExpedi);
							if (contExpedi==0){
								//grabaTelelog(listError,"00198","D.URGE : " + dua.getCodmodalidad() + " ||COD.: " + dua.getCodprodurgente()+" ||A�O DOC. : " + doc.getAnndocasoc() + " ||NRO DOC.: " + doc.getNumdocasoc());
								grabaTelelog(listError,"05049", new Object[]{doc.getNumserie(), dua.getCodprodurgente()});
							}
						}
					}
				}
			}else{
				//if (!"10".equals(mcodi_regi) || !"03".equals(mtipo_trans))
				if (!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(mcodi_regi) || !ConstantesDataCatalogo.TRANSACCION_SOLICITUD_RECTIFICACION.equals(mtipo_trans))
					grabaTelelog(listError,"05049","NO HA TRANSMITIDO ARCHIVO DUADOCAS.TXT PARA EL DESPACHO "+tipo_despa);
			}
		}

		// PAS20124E600000024 LSG 20120419 Via postal no se acepta para regimen 70-depsito
		//if ("0".equals(dua.getManifiesto().getCodmodtransp()) && "70".equals(mcodi_regi)){
		if (ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL.equals(dua.getManifiesto().getCodmodtransp()) && ConstantesDataCatalogo.REG_DEPOSITO.equals(mcodi_regi)){
			grabaTelelog(listError,"30520","NO SE PERMITE NUMERAR REGIMEN DEPOSITO CON VIA DE TRANSPORTE POSTAL");
		}



		return listError;
	}

	/**
	 * Valida regimen precedente repetido.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2349)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2349,numSecEjec=3,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valRegimenPrecedenteRepetido(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		//TDDI 50E Regla 14
		for(DatoSerie serie:dua.getListSeries()){
			Elementos<DatoRegPrecedencia> listRegPrec=serie.getListRegPrecedencia();
			boolean repetido=false;
			List<Integer> listNumSerPre=new ArrayList<Integer>();			
			for(DatoRegPrecedencia regPrec:listRegPrec){
				Integer numSerPre=regPrec.getNumserpre();
				for(Integer i:listNumSerPre){
					if (i==numSerPre){
						repetido=true;
						break;
					}
				}
				if(!repetido){
					listNumSerPre.add(numSerPre);
				}else{
					grabaTelelog(listError,"30098","LA SERIE "+ numSerPre + " DEL REG DE PRECEDENCIA ESTA REPETIDA");
					break;
				}
			}
		}
		return listError;
	}

	/**
	 * Valida cuenta corriente pernat.
	 * @deprecated Posible modificacion por ajustes de query en CTA_CTE_PER_NAT
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2350)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2350,numSecEjec=4,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valCtaCtePerNat(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		Map<String,Object> mapVariables=this.getVariablesIniciales(declaracion);
		Participante partic=dua.getDeclarante();
		DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
		//DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
		//String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;
		Declaracion declaracionBD =null;
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		if (numdeclRef != null) {//declaracionService
			//Declaracion declaracionBD = RectificacionServiceImpl.getInstance().getDeclaracionService().getDeclaracion(numdeclRef.getCodaduana(),
			//	new Integer(numdeclRef.getNumcorre()), new Integer(numdeclRef.getAnnprese()), numdeclRef.getCodregimen());

			GetDeclaracionService getDeclaracionService  = (GetDeclaracionService) fabricaDeServicios.getService("declaracionService");
			declaracionBD  = getDeclaracionService.getDeclaracion(numdeclRef.getCodaduana(),
					new Integer(numdeclRef.getNumcorre()), new Integer(numdeclRef.getAnnprese()), numdeclRef.getCodregimen());
		}

		String mcodi_regi=(String)mapVariables.get("mcodi_regi");
		//TDDI 50F-62 Regla 15
		String tipo_docum=codTipoDocumento;
		/*if (SunatStringUtils.include(tipo_docum,new String[]{"2","3","5","9"}) 
				&& !tipo_docum.equals("4") && !(SunatStringUtils.include(tipo_docum,new String[]{"6","7"}) && "7".equals(dua.getCodtipotratamiento()))){
		 */	
		if (/*!esApec && */SunatStringUtils.include(tipo_docum,new String[]{"2","3","5","6","7","9"}) 
				//&& !tipo_docum.equals("4") && (SunatStringUtils.include(tipo_docum,new String[]{"6","7"}) && !"7".equals(dua.getCodtipotratamiento()))){
				&& !tipo_docum.equals("4") && (!"7".equals(dua.getCodtipotratamiento()))){

			//String xPoliza="00000";
			String xCodiExcep="";
			String xTipoDocum=tipo_docum;
			for(DatoSerie serie:dua.getListSeries()){
				if ((SunatStringUtils.include(xTipoDocum, new String[]{"3","5","7"}) && 4202==serie.getCodliberatorio()) ||
						(SunatStringUtils.include(xTipoDocum, new String[]{"6","7"}) && SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()),new String[]{"3302","3309"})) ||
						(SunatStringUtils.include(xTipoDocum, new String[]{"5","6"}) && serie.getCodliberatorio()==3312) ||
						(SunatStringUtils.include(xTipoDocum, new String[]{"4","5","6","7","8"}) && serie.getNumpartnandi()==9804000000L) ||
						(SunatStringUtils.include(xTipoDocum, new String[]{"3","6"}) && SunatStringUtils.include(String.valueOf(serie.getNumpartnandi()), new String[]{"9801000010","9801000020"}))
						){
					return listError;//break;
				}else if (SunatStringUtils.include(xTipoDocum, new String[]{"3","5","7"}) && 4201==serie.getCodliberatorio()){
					xCodiExcep="01";
				}
			}
			//TDDI 63-65XIII Regla 16
			if ("".equals(xCodiExcep)){
				if (  SunatNumberUtils.isLessOrEqualsThanParam( dua.getMtotfobclvta(), new BigDecimal(1000))){
					List<CtaCtePerNat> lista= new ArrayList<CtaCtePerNat>();
					Map<String,Object> paramsCtaCtePerNat=new HashMap<String,Object>();

					paramsCtaCtePerNat.put("librTribu", numeroDocumentoIdentidad);
					paramsCtaCtePerNat.put("tipoDocum", codTipoDocumento);
					paramsCtaCtePerNat.put("anoPrese", (new FechaBean()).getAnho());
					//paramsCtaCtePerNat.put("flagAnula", "0");
					paramsCtaCtePerNat.put("fechAnula", "0");
					paramsCtaCtePerNat.put("cRegimen", mcodi_regi);
					//paramsCtaCtePerNat.put("codiRegi", mcodi_regi);
					//paramsCtaCtePerNat.put("tfobDolpoMen=", new BigDecimal(1000));
					paramsCtaCtePerNat.put("codiExcep", " ");

					if(dua.getAnnorden()!=null  && declaracion.getNumeroDeclaracion()!=null){
						//Para Recti
						String codiAduan =  dua.getCodaduanaorden();
						String anoPrese = (String) dua.getAnnorden().toString();
						String codiRegi =  dua.getCodregimen();
						String numeCorre =  (String) declaracion.getNumeroDeclaracion().toString();

						CtaCtePerNat datosDua = new CtaCtePerNat();
						datosDua.setCodiAduan(codiAduan);
						datosDua.setAnoPrese(anoPrese);
						datosDua.setCodiRegi(codiRegi);
						datosDua.setNumeCorre(numeCorre);
						datosDua.setLibrTribu(numeroDocumentoIdentidad);
						//List<CtaCtePerNat> lista =  ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(datosDua);
						lista =  ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(datosDua);
						if (!CollectionUtils.isEmpty(lista)) {
							BigDecimal montoDua = lista.get(0).getTfobDolpo();
							BigDecimal montoRecti = dua.getMtotfobclvta();

							Integer sumaTotalFob = 0;
							sumaTotalFob = ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).suma(paramsCtaCtePerNat);
							if(sumaTotalFob==null){
								sumaTotalFob = 0;
							}
							BigDecimal montoFinalFob = BigDecimal.valueOf(sumaTotalFob.doubleValue()).add(montoRecti).subtract(montoDua);
							if (SunatNumberUtils.isLessThanParam(new BigDecimal(3000),montoFinalFob)) {
								grabaTelelog(listError, "30573",
										"LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
							}

						}else{
							Integer sumaTotalFob = 0;
							BigDecimal montoRecti = dua.getMtotfobclvta();
							sumaTotalFob = ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).suma(paramsCtaCtePerNat);
							if(sumaTotalFob==null){
								sumaTotalFob = 0;
							}
							BigDecimal montoFinalFob = BigDecimal.valueOf(sumaTotalFob.doubleValue()).add(montoRecti);
							if (SunatNumberUtils.isLessThanParam(new BigDecimal(3000),montoFinalFob)) {
								grabaTelelog(listError, "30573",
										"LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
							}

						}
					}	
					paramsCtaCtePerNat.put("tfobDolpoMen", new BigDecimal(1000));
					//paramsCtaCtePerNat.put("condicXTran", "not (ano_prese="+(new FechaBean()).getAnho()+" AND nume_corre='')");
					//int countCuentaDuas=FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().cantidad(paramsCtaCtePerNat);
					int countCuentaDuas = 0;
					countCuentaDuas=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).cantidad(paramsCtaCtePerNat);


					//paramsCtaCtePerNat.put("tfobDolpoMen", new BigDecimal(1000));
					//paramsCtaCtePerNat.put("tfobDolpoMay", new BigDecimal(3000));
					//int countCuentaDuas2 = 0;
					//countCuentaDuas2=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).count(paramsCtaCtePerNat);
					//int countCuentaDuasTotal =  countCuentaDuas + countCuentaDuas2;
					if (countCuentaDuas>=3  && declaracionBD==null){
						grabaTelelog(listError,"30099","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");
					}else{
						if(declaracionBD!=null && countCuentaDuas>=3 && CollectionUtils.isEmpty(lista)){
							grabaTelelog(listError,"30099","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");
						}
						if((declaracionBD!=null && countCuentaDuas>=4)){
							grabaTelelog(listError,"30099","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");
						}
					}


				}else if ( SunatNumberUtils.isLessThanParam(new BigDecimal(1000), dua.getMtotfobclvta())
						&& SunatNumberUtils.isLessOrEqualsThanParam(dua.getMtotfobclvta(), new BigDecimal(3000))){

					Map<String,Object> paramsCtaCtePerNat=new HashMap<String,Object>();
					paramsCtaCtePerNat.put("librTribu", numeroDocumentoIdentidad);
					paramsCtaCtePerNat.put("tipoDocum", codTipoDocumento);
					paramsCtaCtePerNat.put("anoPrese", (new FechaBean()).getAnho());
					//paramsCtaCtePerNat.put("flagAnula", "0");
					paramsCtaCtePerNat.put("fechAnula", "0");
					paramsCtaCtePerNat.put("cRegimen", mcodi_regi);
					//paramsCtaCtePerNat.put("codiRegi", mcodi_regi);
					paramsCtaCtePerNat.put("codiExcep", " ");




					if(dua.getAnnorden()!=null && declaracion.getNumeroDeclaracion()!=null){

						//Para Recti
						String codiAduan =  dua.getCodaduanaorden();
						String anoPrese = (String) dua.getAnnorden().toString();
						String codiRegi =  dua.getCodregimen();
						String numeCorre =  (String) declaracion.getNumeroDeclaracion().toString();

						CtaCtePerNat datosDua = new CtaCtePerNat();
						datosDua.setCodiAduan(codiAduan);
						datosDua.setAnoPrese(anoPrese);
						datosDua.setCodiRegi(codiRegi);
						datosDua.setNumeCorre(numeCorre);
						datosDua.setLibrTribu(numeroDocumentoIdentidad);

						List<CtaCtePerNat> lista =  ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(datosDua);
						if (!CollectionUtils.isEmpty(lista)) {
							BigDecimal montoDua = lista.get(0).getTfobDolpo();
							BigDecimal montoRecti = dua.getMtotfobclvta();

							Integer sumaTotalFob = 0;
							sumaTotalFob = ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).suma(paramsCtaCtePerNat);
							if(sumaTotalFob==null){
								sumaTotalFob = 0;
							}
							BigDecimal montoFinalFob = BigDecimal.valueOf(sumaTotalFob.doubleValue()).add(montoRecti).subtract(montoDua);
							if (SunatNumberUtils.isLessThanParam(new BigDecimal(3000),montoFinalFob)) {
								grabaTelelog(listError, "30573",
										"LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
							}

							BigDecimal montoFobDua = BigDecimal.valueOf(sumaTotalFob.doubleValue()).subtract(montoDua);
							int countCuentaDuasRect=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).cantidad(paramsCtaCtePerNat);
							if (countCuentaDuasRect>=3  &&  SunatNumberUtils.isLessThanParam(montoFobDua, new BigDecimal(2000))  ){
								grabaTelelog(listError,"30902","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");
							}

						}else{
							Integer sumaTotalFob = 0;
							BigDecimal montoRecti = dua.getMtotfobclvta();
							sumaTotalFob = ((CtaCtePerNatDAO) fabricaDeServicios.getService("ctaCtePerNatDAO")).suma(paramsCtaCtePerNat);
							if(sumaTotalFob==null){
								sumaTotalFob = 0;
							}
							BigDecimal montoFinalFob = BigDecimal.valueOf(sumaTotalFob.doubleValue()).add(montoRecti);
							if (SunatNumberUtils.isLessThanParam(new BigDecimal(3000),montoFinalFob)) {
								grabaTelelog(listError, "30573",
										"LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
							}


						}
					}else{/// PAS20175E220200021

						//amancilla esta parte no esta especificada para las diligencias segun se verifica parace que solo funciona para la numeracion
						String codTransaccion=declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans():"";
						boolean isTxDilig = ((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isTransaccionDiligencia(codTransaccion);

						if(!isTxDilig) {
							//fin amancilla

							//paramsCtaCtePerNat.put("tfobDolpoMen", new BigDecimal(1000));/// PAS20175E220200021
							//paramsCtaCtePerNat.put("tfobDolpoMay", new BigDecimal(3000));	/// PAS20175E220200021				

							//paramsCtaCtePerNat.put("condicXTran", "not (ano_prese="+(new FechaBean()).getAnho()+" AND nume_corre='')");
							//int countCuentaDuas=FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().count(paramsCtaCtePerNat);					

							int countCuentaDuas=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).count(paramsCtaCtePerNat);

							if (countCuentaDuas>0){
								paramsCtaCtePerNat.put("tfobDolpoMen", new BigDecimal(1000));
								//int countCuentaDuasCta=FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().cantidad(paramsCtaCtePerNat);
								int countCuentaDuasCta=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).cantidad(paramsCtaCtePerNat);
								if (countCuentaDuasCta>=3 && declaracionBD==null){

									grabaTelelog(listError,"30099","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");

								}else{
									if(declaracionBD!=null && countCuentaDuas>=4){
										grabaTelelog(listError,"30099","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-G");
									}else{
										//grabaTelelog(listError,"00846","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
										grabaTelelog(listError,"30573","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-H");
									}	
								}
							}

						}//amancilla
					}/// PAS20175E220200021	
				}else{
					grabaTelelog(listError,"30573","LIBR-TRIBU, DEBE NUMERAR CON RUC, FOB DUA >US$.3000,RS-210-2004 ART 3-H");
				}
			}else{
				Map<String,Object> paramsCtaCtePerNat=new HashMap<String,Object>();
				paramsCtaCtePerNat.put("librTribu", numeroDocumentoIdentidad);
				paramsCtaCtePerNat.put("tipoDocum", codTipoDocumento);
				paramsCtaCtePerNat.put("anoPrese", (new FechaBean()).getAnho());
				//paramsCtaCtePerNat.put("flagAnula", "0");
				paramsCtaCtePerNat.put("fechAnula", "0");
				paramsCtaCtePerNat.put("cRegimen", mcodi_regi);
				//paramsCtaCtePerNat.put("codiRegi", mcodi_regi);
				paramsCtaCtePerNat.put("codiExcep", "01");
				//paramsCtaCtePerNat.put("condicXTran", "not (ano_prese="+(new FechaBean()).getAnho()+" AND nume_corre='')");
				//int countCuentaDuas=FormatoAServiceImpl.getInstance().getCtaCtePerNatDAO().count(paramsCtaCtePerNat);					
				int countCuentaDuas=((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).count(paramsCtaCtePerNat);
				if (countCuentaDuas>0){
					grabaTelelog(listError,"30573","LIBR-TRIBU, DEBE NUMERAR CON RUC, RS-210-2004 ART 3-M");
				}
			}
		}
		return listError;
	}

	/**
	 * Val inc migrat.
	 * @deprecated Validar por uso de TAG_TODO
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2351)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2351,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valIncMigrat(Declaracion declaracion,String codTransaccion){
		//csantillan pase 4
		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		//ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		//Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
	   // boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaReferencia):false;
		
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		String tipo_docum=dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		//amancilla Map<String,Object> mapVariables=this.getVariablesIniciales(declaracion);
		//amancilla String mcodi_alma=(String)mapVariables.get("mcodi_alma");
		//TDDI 65B-66ii Regla 17
		boolean gbTieneIncMig=false;
		for(DatoSerie serie:dua.getListSeries()){
			if( SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()), new String[]{"4442","4443","4444"})) {
				gbTieneIncMig = true;
				// SE ADICIONA REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
				// SE COMENTA POR QUE CAMBIO LA REGLA SE MANTIENE LO DE ANTES
//				if (esVigenteRIN05SegundaParte){
//				//INICIO PAS20181U220200004 R1513 
//				//if (!"3".equals(tipo_docum) && !"4".equals(tipo_docum)) {//gmontoya Pase 153
//				if (!"3".equals(tipo_docum)) {
//				//FIN PAS20181U220200004	
//					grabaTelelog(listError, "40431", new Object[]{serie.getNumserie(),serie.getCodliberatorio().toString()});
//					}
//				}
//				else 
//				{
				if (!"3".equals(tipo_docum) && !"4".equals(tipo_docum)) {//gmontoya Pase 153
					grabaTelelog(listError, "01171", new Object[]{serie.getNumserie(),serie.getCodliberatorio().toString()});
				}
			  //}
				// FIN REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN	
			}
		} //Final FOR
		// SE AGREGA REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
		// SE COMENTA EL CODIGO POR QUE YA NO VA ESTA REGLA DE NEGOCIO
//		if (esVigenteRIN05SegundaParte){
//			if (gbTieneIncMig) {
//			
//								// Bloque csantillan
//								Integer fechaDeclaracion = Integer.valueOf(0);
//								if (codTransaccion.equals("1001"))
//									fechaDeclaracion = SunatDateUtils.getCurrentIntegerDate();
//								else {
//									if (dua.getFecdeclaracion() == null)
//										fechaDeclaracion = SunatDateUtils.getCurrentIntegerDate();
//									else
//										fechaDeclaracion = SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion());
//								}
//
//								String grabarTabla = "";
//								String tipoDocIden = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad()
//										.getCodDatacat();
//								String numdocIden = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
//								String codLiber = declaracion.getDua().getListSeries().get(0).getCodliberatorio()
//										.toString();
//
//								CatRefRucDAO USOMAXAPLDAO = fabricaDeServicios.getService("catRefRucCentralizadaDAO");
//								Map<String, Object> filtro = new HashMap<String, Object>();
//								filtro.put("cTipoDoc", tipoDocIden);
//								filtro.put("nDocumen", numdocIden);
//								filtro.put("cLibera", codLiber);
//								List<Map<String, Object>> USOMAXAPL = USOMAXAPLDAO.findByMap1(filtro);		
//								
//
//								// Indicador para Grabar / Actualziar segun
//								// corresponda
//								if (USOMAXAPL != null && USOMAXAPL.size() > 0) {
//									grabarTabla = "U"; // Insert
//								} else {
//									grabarTabla = "I"; // Update
//								}
//								dua.setCodIndicaUsoMaxpl(grabarTabla);
//								// Indicador para Grabar / Actualziar segun
//								// corresponda
//
//								// CatRefRucDAO USOMAXAPLDAO2 =
//								// fabricaDeServicios.getService("catRefRucCentralizadaDAO");
//								BigDecimal USOMAXAPLDAO2 = BigDecimal.ZERO;
////								Map<String, Object> filtro2 = new HashMap<String, Object>();
////								filtro2.put("nDocumen", numdocIden);
////								filtro2.put("cLibera", codLiber);
//								USOMAXAPLDAO2 = USOMAXAPLDAO.getCalcularmonto(filtro);
//
//								valMontosIM2(listError, declaracion, fechaDeclaracion, USOMAXAPL, USOMAXAPLDAO2);
//
//								// Fin del bloque csantillan
//							
//			}	
//		}else {
		if (gbTieneIncMig){
			//TDDI 66.III.1-66.III.5 Regla 18
			boolean b_tipoProce_I_tipoDocas_2=false;
			List<String> resolucionesREvisadas = new ArrayList<String>();//gmontoya Pase 153 2015
			for(DatoOtroDocSoporte doc:dua.getListOtrosDocSoporte()){
				if (("I".equals(doc.getCodtipoproceso()) && "02".equals(doc.getCodtipodocasoc()))||("P".equals(doc.getCodtipoproceso()) && "02".equals(doc.getCodtipodocasoc()))){
					if (SunatStringUtils.isEmptyTrim(doc.getCodtipodocasoc()) || doc.getAnndocasoc().compareTo(String.valueOf((new Integer(SunatDateUtils.getCurrentFormatDate("yyyy")))-1))<0){
						grabaTelelog(listError,"01163","DUADOCAS.ANNO_DOCAS - A�o de Resoluci�n Inv�lido: "+doc.getAnndocasoc());
						//grabaTelelog(listError, "01163", new Object[] { getNumeroDocumentoIdentidad().toString() });
					}else if (SunatStringUtils.isEmptyTrim(doc.getNumdocasoc())){
						grabaTelelog(listError,"01164","DUADOCAS.NUME_DOCAS - Nro de Resoluci�n Inv�lido: "+doc.getAnndocasoc());
					}else{
						//TDDI 66.III.6-66.IV Regla 19
						List<Map<String,Object>> listCatRefRuc=new ArrayList<Map<String,Object>>();
						Map<String,String> paramsCatRefRuc=new HashMap<String,String>();
						paramsCatRefRuc.put("ctipoUso", "IM");
						String numdoc=doc.getNumdocasoc().trim();
						numdoc = SunatStringUtils.lpad(numdoc, 6, '0');
						//						for(int i=numdoc.length();i<=6;i++)
						//							numdoc="0"+numdoc;
						paramsCatRefRuc.put("tbaseLegal_like", doc.getAnndocasoc().substring(0, 4) +"-"+numdoc);
						//inicio gmontoya Pase 153 2015
						if(resolucionesREvisadas.contains(doc.getAnndocasoc().substring(0, 4) +"-"+numdoc)){
							continue;
						}else{
							resolucionesREvisadas.add(doc.getAnndocasoc().substring(0, 4) +"-"+numdoc);
						}
						//fin gmontoya Pase 153 2015
						//listCatRefRuc=FormatoAServiceImpl.getInstance().getCatRefRucCentralizadaDAO().findByMap(paramsCatRefRuc);
						listCatRefRuc=((CatRefRucDAO)fabricaDeServicios.getService("catRefRucCentralizadaDAO")).findByMap(paramsCatRefRuc);
						/*
						 * HECHO SELECT tbase_legal, finivig, ffinvig FROM
						 * cat_refruc WHERE ctipo_uso='IM' AND tbase_legal LIKE
						 * '"+DOC_ASOC.anno_docas+"-"+PADL(A_CADENA(A_NUMERO(DOC_ASOC.nume_docas)),6,"0")+"%'
						 */
						if (listCatRefRuc==null || listCatRefRuc.isEmpty()){
							grabaTelelog(listError, "01167", new Object[] { doc.getAnndocasoc().substring(0, 4), doc.getNumdocasoc().toString() }); //pase 64
							//grabaTelelog(listError, "01170", new Object[] { tbase_legal.substring(23,34), tipo_docum, dua.getDeclarante().getNumeroDocumentoIdentidad().toString() });
						}else{
							String numerodoc= doc.getAnndocasoc().substring(0, 4) + "-" + doc.getNumdocasoc().toString(); //pase 64
							for(Map<String,Object> mapCatRefRuc:listCatRefRuc){
								String tbase_legal=(String)mapCatRefRuc.get("tbaseLegal");//SunatDateUtils.getCurrentFormatDate("yyyyMMdd")

								/*RIN-13*/
								String tbase_legal19 = ""; //YYYY
								boolean isFechaNotificada = false;

								if(doc.getAnndocasoc().length() != 4){
									//String tbase_legal19=doc.getAnndocasoc().substring(0, 4);
									tbase_legal19=doc.getAnndocasoc().substring(0, 4);
									String tbase_legal20=doc.getAnndocasoc().substring(5, 7);
									String tbase_legal21=doc.getAnndocasoc().substring(8, 10);
									//String tbase_Legal22= tbase_legal19+tbase_legal20+tbase_legal21;
									String tbase_Legal22= tbase_legal19+tbase_legal20+tbase_legal21;
									mapCatRefRuc.put("ruc", tbase_legal.substring(23, 34));
									//									if(tbase_legal.length() > 21 && (new Integer(tbase_legal.substring(13, 21))) > 0 && tbase_Legal22.equals(tbase_legal.substring(13, 21))){
									if(tbase_legal.length() > 21 && (new Integer(tbase_legal.substring(13, 21))) > 0 
											&& SunatDateUtils.esFecha1MayorIgualQueFecha2(SunatDateUtils.getDateyyyMMdd(tbase_legal.substring(13, 21)),SunatDateUtils.getDateyyyMMdd(tbase_Legal22),
													SunatDateUtils.COMPARA_SOLO_FECHA) ){//cambio por SAU201510002000161 - PAS20155E220000490
										isFechaNotificada = true;
									}

								}else{
									//RIN13
									tbase_legal19 = doc.getAnndocasoc();
									if(tbase_legal.length() > 21){
										String sFechaNotificacion = tbase_legal.substring(13, 21); //YYYYMMDD
										if(new Integer(sFechaNotificacion) > 0 && new Integer(sFechaNotificacion.substring(0, 4)) > 1900){
											isFechaNotificada = true;
										}
									}
								}

								//if (tbase_legal.length() > 21 && (new Integer(tbase_legal.substring(13, 21))) > 0 && tbase_Legal22.equals(tbase_legal.substring(13, 21))) {
								if (isFechaNotificada) {
									/*RIN-13*/
									//PAS20165E220200119 - mtorralba 20160815 
									//Valida vigencia de Resoluci�n con la Fecha de numeraci�n de DAM 
									Integer fechaDeclaracion = Integer.valueOf(0);
									if( codTransaccion.equals("1001"))
										fechaDeclaracion = SunatDateUtils.getCurrentIntegerDate();
									else {
										if( dua.getFecdeclaracion() == null )
											fechaDeclaracion = SunatDateUtils.getCurrentIntegerDate();
										else
											fechaDeclaracion = SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion());
									}

									//if (tbase_legal.length() > 21 && (new Integer(tbase_legal.substring(13, 21))) > 0 ) {
									if (fechaDeclaracion >= ((BigDecimal) mapCatRefRuc.get("finivig")).intValue() && 
											fechaDeclaracion <= ((BigDecimal) mapCatRefRuc.get("ffinvig")).intValue()) {
										//inicio gmontoya Pase 153 - 2015

										Participante declarante = declaracion.getListDAVs()!=null?(declaracion.getListDAVs().get(0)!=null?declaracion.getListDAVs().get(0).getPersonaDecl():null):null;
										String tipoDocumento = dua.getDeclarante()!=null?dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat():"";
										String numDocIdentidad = dua.getDeclarante()!=null?dua.getDeclarante().getNumeroDocumentoIdentidad():"";
										String tipoDocumento2 = declarante!=null?declarante.getTipoDocumentoIdentidad().getCodDatacat():"";	;
										String numDocIdentidad2 = declarante!=null?declarante.getNumeroDocumentoIdentidad():"";										
										boolean sinErroresRelacion=false;
										if(numDocIdentidad.equals(numDocIdentidad2) || (numDocIdentidad.length()>=10?numDocIdentidad.substring(2, 10).equals(numDocIdentidad2):false) ||
												(numDocIdentidad2.length()>=10?numDocIdentidad2.substring(2, 10).equals(numDocIdentidad):false)){											
											sinErroresRelacion = true;
										}										
										mapCatRefRuc.put("rucDeclarante", numDocIdentidad);
										mapCatRefRuc.put("tipoDocumDeclarante", tipoDocumento);										
										mapCatRefRuc.put("rucDeclarante2", numDocIdentidad2);
										mapCatRefRuc.put("tipoDocumDeclarante2", tipoDocumento2);

										if(
												((tbase_legal.substring(23,34).equals("00000000000") && 
														(numDocIdentidad.equals(String.valueOf(mapCatRefRuc.get("cdocumen"))) || numDocIdentidad2.equals(String.valueOf(mapCatRefRuc.get("cdocumen"))))) ||
														((numDocIdentidad.equals(tbase_legal.substring(23,34)) || numDocIdentidad2.equals(tbase_legal.substring(23,34))) ||
																(numDocIdentidad.equals(tbase_legal.substring(23,31)) || numDocIdentidad2.equals(tbase_legal.substring(23,31))) ||
																(numDocIdentidad.equals(tbase_legal.substring(25,33)) || numDocIdentidad2.equals(tbase_legal.substring(25,33))) 
																)) && sinErroresRelacion
												){//gmontoya Pase 153
											//										if ((tbase_legal.length() >= 35 && "00000000000".equals(tbase_legal.substring(23, 34))) || 
											//										    dua.getDeclarante().getNumeroDocumentoIdentidad().equals(tbase_legal.substring(23,34)) ||
											//										    dua.getDeclarante().getNumeroDocumentoIdentidad().equals(tbase_legal.substring(25,33)) ||//gmontoya Pase 153
											//										    dua.getDeclarante().getNumeroDocumentoIdentidad().equals(mapCatRefRuc.get("cdocumen"))) {//gmontoya Pase 153										
											//inicio gmontoya Pase 153
											if(SunatStringUtils.include(codTransaccion, new String[]{"1003","1006","1016","1007","1010","1018","1012"})){
												mapCatRefRuc.put("quitarDeclaracion", true);
											}else{
												mapCatRefRuc.put("quitarDeclaracion", false);
											}
											//fin gmontoya Pase 153
											valMontosIM(listError, declaracion, mapCatRefRuc,fechaDeclaracion);
										}else{
											// grabaTelelog(listError,"01170","En Resoluci�n: 4-"+tbase_legal+" En Datos de Cabecera: "+tipo_docum+"-"+dua.getDeclarante().getNumeroDocumentoIdentidad());
											//grabaTelelog(listError, "01170", new Object[] {mapCatRefRuc.get("ctipodoc").toString(), String.valueOf(mapCatRefRuc.get("cdocumen")), tipo_docum, numeroDocIdentidad});//gmontoya Pase 153
											String cadenaRuc = tbase_legal.replace("**","/").split("/")[2];
											String mensajeBD = "";
											String mensajeEnvio = "";
											if(cadenaRuc.equals(mapCatRefRuc.get("cdocumen"))){
												mensajeBD = mapCatRefRuc.get("ctipodoc").toString()+"-"+mapCatRefRuc.get("cdocumen").toString();
											}else{
												mensajeBD = (cadenaRuc.length()>8?"4":"3") + "-" + cadenaRuc + "," + mapCatRefRuc.get("ctipodoc").toString()+"-"+mapCatRefRuc.get("cdocumen").toString();
											}
											if(numDocIdentidad.equals(numDocIdentidad2)){
												mensajeEnvio = tipoDocumento+"-"+numDocIdentidad;
											}else{
												mensajeEnvio = tipoDocumento+"-"+numDocIdentidad +","+ tipoDocumento2+"-"+numDocIdentidad2;
											}

											//grabaTelelog(listError, "01170", new Object[] {mensajeBD ,mensajeEnvio});//pruizcr Pase 153 bug 22654
											grabaTelelog(listError, "01170", new Object[] {numerodoc,mensajeEnvio});//pruizcr Pase 153 bug 22654
										}
									}else{
										// grabaTelelog(listError,"01169","Resolucion tuvo fecha de vencimiento: "+((BigDecimal)mapCatRefRuc.get("finivig")));
										grabaTelelog(listError,	"01169",new Object[] { mapCatRefRuc.get("ffinvig").toString() });
										//grabaTelelog(listError,	"01169",new Object[] { fecha });
									}
								}else{
									// grabaTelelog(listError,"01168","Resoluci�n "+doc.getAnndocasoc()+"-"+doc.getNumdocasoc()+" no notificada");
									grabaTelelog(listError, "01168", new Object[] {tbase_legal19, numdoc});
								}
							}
						}

					}
					b_tipoProce_I_tipoDocas_2=true;
				}
			}
			if (!b_tipoProce_I_tipoDocas_2)// && dua.getListOtrosDocSoporte()!=null && !dua.getListOtrosDocSoporte().isEmpty())//se quita por errores PAS20155E220000396
				grabaWarningTelelog(listError,"30400","DEBE DECLARAR RESOLUCION LIBERATORIA");
			/*
			int countRADIREC=1;
			if (countRADIREC==0)
				grabaWarningTelelog(listError,"00025","Declaro "+mcodi_alma);*/
		}
	//  }
	 // FIN REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN	
		return listError;
	}

	/**
	 * Realiza la validacion de los montos de tributos autocalculados y el monto autoliquidado de la DUA.
	 * 
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2352)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2352,numSecEjec=6,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valAutoliquidacion(Declaracion declaracion, String codTransaccion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		//Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		//String tipo_despa=(String)mapVariables.get("tipo_despa");
		//boolean gblfce=(Boolean)mapVariables.get("gblfce");
		//boolean gbsadac2=(Boolean)mapVariables.get("gbsadac2");
		//TDDI 70a-84 Regla 21
		BigDecimal wautoliqui=BigDecimal.ZERO;
		for (DatoTributosAutocalc tributo:dua.getListTributosAutocalculados()){
			wautoliqui=SunatNumberUtils.sum(wautoliqui,tributo.getMtovalortrib());
		}
		if ( ! SunatNumberUtils.isEqual(wautoliqui, dua.getMtototautoliq()) ){
			grabaWarningTelelog(listError,"01005","MAUTOLIQUI - TOT.AUTOL. :"+dua.getMtototautoliq()+ " TOT.PARCIAL "+wautoliqui );
		}

		return listError;
	}

	/**
	 * Realiza validaciones de Expediente Aprobacion Donacion
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2353)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2353,numSecEjec=7,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valExpAprobDonac(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		//TDDI 85.E   Regla 23-Regla 27
		if ("4".equals(dua.getCodtipotratamiento())){
			if (dua.getListOtrosDocSoporte()!=null && !dua.getListOtrosDocSoporte().isEmpty()){
				for(DatoOtroDocSoporte doc:dua.getListOtrosDocSoporte()){
					if ("01".equals(doc.getCodtipodocasoc()) && "1".equals(doc.getCodtipoproceso())){
						if (SunatStringUtils.isEmptyTrim(doc.getAnndocasoc()) || doc.getAnndocasoc().compareTo(String.valueOf((new Integer(SunatDateUtils.getCurrentFormatDate("yyyy")))-1))<0){
							grabaTelelog(listError,"01030","DUADOCAS.NUME_DOCAS - Nro Expediente Aprobacion Donacion: "+doc.getNumdocasoc());
						}
						if (SunatStringUtils.isEmptyTrim(doc.getNumdocasoc()))
							grabaTelelog(listError,"01031","DUADOCAS.NUME_DOCAS - Nro Expediente Aprobacion Donacion: "+doc.getNumdocasoc());
						if (doc.getFecdocasoc()==null)
							grabaTelelog(listError,"01030","DUADOCAS.FECHA DOCAS - Fecha Expediente Aprobacion Donacion null");
						if (doc.getCodentidademisora()==null || doc.getCodentidademisora()==0)
							grabaTelelog(listError,"01029","DUADOCAS.ENTI_EMISO - Nombre Entidad Autoriza Donacion "+doc.getCodentidademisora());
					}
				}
			}else{
				grabaWarningTelelog(listError,"30399","NO HA TRANSMITIDO DOCUMENTOS ASOCIADOS");
			}
		}else{
			if (dua.getListOtrosDocSoporte()!=null && !dua.getListOtrosDocSoporte().isEmpty()){
				for(DatoOtroDocSoporte doc:dua.getListOtrosDocSoporte()){
					if ("1".equals(doc.getCodtipodocasoc()) && "1".equals(doc.getCodtipoproceso())){
						grabaTelelog(listError,"01100","DUADOCAS.ANNO-NRO-FECHA: "+doc.getAnndocasoc()+"-"+doc.getNumdocasoc());
					}
				}
			}
		}
		return listError;
	}

	/**
	 * Realiza la validacion de la informacion de los pagos de la declaracion
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2354)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2354,numSecEjec=8,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valInfoPagoElect(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		//TDDI 85.F Regla 28
		boolean indicapagoelec=false;
		String valIndPagoElec="";
		for(DatoIndicadores indicador:dua.getListIndicadores()){
			if ("05".equals(indicador.getCodtipoindica())){
				indicapagoelec=true;
				valIndPagoElec=indicador.getValindicador();
				break;
			}
		}

		String gc_sindi_pael="";
		String gc_cbco_pael="";
		String gc_ccta_pael="";
		DatoPago pago=dua.getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		gc_cbco_pael=decla!=null?decla.getCodbcopagoelec():"";
		gc_ccta_pael=decla!=null?decla.getNumctapagoelec():"";

		// r2bz 04/2013, Hay que verificar, nunca estaria validando la cta de pago electronico indicapagoelec siempre false
		if (indicapagoelec){
			if ("1".equals(valIndPagoElec)){
				gc_sindi_pael=valIndPagoElec;
				/*HECHO SQLSTR= " SELECT CODIGO FROM TABLNEW WHERE TIPO='15' "+
				" AND CODIGO='" + CABECERA.cbco_pael + "' AND REF='01'  AND TTRA='1' "*/
				//boolean val=FormatoAServiceImpl.getInstance().isValidCatalogo("15", gc_cbco_pael);
				boolean val=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("15", gc_cbco_pael,SunatDateUtils.getCurrentDate()));
				if (!val){
					gc_sindi_pael="0";
					grabaTelelog(listError, "09067","CBCO_PAEL - TRANSMITIO "+gc_cbco_pael);
				}
				gc_cbco_pael=("000"+gc_cbco_pael).substring(gc_cbco_pael.length(), gc_cbco_pael.length()+3);
				if (SunatStringUtils.isEmptyTrim(gc_ccta_pael)){
					gc_sindi_pael="0";
					grabaTelelog(listError,"09068","CCTA_PAEL - TRANSMITIO-"+gc_ccta_pael+ ":CUENTA CON CARACTERES INVALIDOS");
				}
				//else gc_ccta_pael=gc_ccta_pael;
			}
		}else
			gc_sindi_pael="0";

		/*branch ingreso 2011-009 hosorio inicio 01/07/2011*/
		// para corregir el bug bug 3552
		String codTipoPago=decla!=null?decla.getCodtipopago():null;
		if(SunatStringUtils.isEqualTo(codTipoPago, "G")){
			if(!SunatStringUtils.isEmpty(gc_cbco_pael)){
				listError.add(getDUAError("01911","CODIGO DE BANCO INVALIDO"));

			}
		}
		else if(SunatStringUtils.isEqualTo(codTipoPago, "P")){
			if(SunatStringUtils.isEmpty(gc_ccta_pael)){
				listError.add(getDUAError("09068","NUMERO DE CUENTA DE PAGO ELECTRONICO VACIO"));
			}
		}
		/*branch ingreso 2011-009 hosorio fin 01/07/2011*/


		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=2355)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2355,numSecEjec=9,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valSada(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		boolean gbsadac2=(Boolean)mapVariables.get("gbsadac2");
		boolean gblfce=(Boolean)mapVariables.get("gblfce");
		String maduana=(String)mapVariables.get("maduana");
		String mcodi_alma=(String)mapVariables.get("mcodi_alma");
		DUA dua=declaracion.getDua();
		//TDDI 85.H Regla 30
		if (gbsadac2 && !gblfce){
			//			if (!SunatStringUtils.include(dua.getCodprodurgente(),new String[]{"1","2"}))
			//				grabaTelelog(listError,"08292","CDURGE ENVIADO:" + dua.getCodprodurgente() + ". ENVIAR 01:DESCARGA DIRECTA � 02:DESCARGA A TERMINAL");
			//			if ("118".equals(maduana) && "01".equals(dua.getCodprodurgente()) && !"9998".equals(mcodi_alma))
			//				grabaWarningTelelog(listError,"00025","PARA MODALIDAD 01 SOLO PUEDE SER 9998");
			//			if (!SunatStringUtils.isEmpty(dua.getCodtipooper()) && !"1".equals(dua.getCodtipooper()))
			//				grabaTelelog(listError,"08272","TDESTINO enviado " + dua.getCodtipooper() + ". S�LO PUEDE SER 1 � NO ENVIAR");
		}
		//		if (gblfce){
		//			if (!SunatStringUtils.include(dua.getCodprodurgente(), new String[]{"01","03"}))
		//				grabaTelelog(listError,"08292","CDURGE ENVIADO:" + dua.getCodprodurgente() + ". ENVIAR 01:DESCARGA DIRECTA � 03:DESCARGA A PUNTO DE LLEGADA");
		//			if (!"235".equals(maduana)){
		//				for(DatoSerie serie:dua.getListSeries()){
		//					if ("2".equals(getDocTransporte(dua,serie).getCodtipodoctrans()) && "1".equals(dua.getCodprodurgente()))
		//						grabaTelelog(listError,"08292","CDURGE ENVIADO:" + dua.getCodprodurgente() + ". NO DEBE DE TENER CARGA CONSOLIDADA TIPO_CONO=2");
		//				}
		//			}
		//		}
		return listError;
	}

	/**
	 * Realiza validaciones iniciales sobre los detalles de la declaracion.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2356)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2356,numSecEjec=10,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valPreviasDatosSeries(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		String maduana=(String)mapVariables.get("maduana");
		String mcodi_regi=(String)mapVariables.get("mcodi_regi");
		//TDDI 86.A Regla 31
		//ADUAHDR1
		//		ValNegocAduahdr1FormA valAduahdr1=new ValNegocAduahdr1FormA();
		//		listError.add(valAduahdr1.valAduahdr1(declaracion, tipoSender));
		String plataforma="";
		String calplata="";
		//boolean vigenciaSupervisoras=vigenciaCriterio("TD26",SunatDateUtils.getCurrentIntegerDate())>0;

		for(DatoSerie serie:dua.getListSeries()){
			//TDDI 88.A Regla 32
			//			Date mfech_emba=getDocTransporte(dua,serie).getFecembarque();
			//TDDI 89.A - 89.B Regla 33
			//Estan en el formato B
			//TDDI 89.C-89.D - 89.F.XIII Regla 34 - Regla 38
			boolean exoneradaRegiProceIDV=false;
			boolean tieneprece=false;
			List<DatoRegPrecedencia> listReg=serie.getListRegPrecedencia();
			if (listReg!=null && !listReg.isEmpty()){
				if (!exoneradaRegiProceIDV)
					exoneradaRegiProceIDV=true;
				for(DatoRegPrecedencia regPrec:listReg){
					if (!"12".equals(regPrec.getCodregipre()))
						if (!tieneprece)
							tieneprece=true;
				}
			}
			if (SunatStringUtils.include(dua.getCodaduanaorden(),new String[]{"118","235"})){
				boolean vigenciaPP2008=vigenciaCriterio("000015",SunatDateUtils.getCurrentDate(),maduana,mcodi_regi)>0;
				if (vigenciaPP2008 && "10".equals(mcodi_regi)){
					boolean declTipDoc09=false;
					for(DatoOtroDocSoporte doc:dua.getListOtrosDocSoporte())
						if ("09".equals(doc.getCodtipodocasoc())){
							declTipDoc09=true;
							break;
						}					
					if (declTipDoc09){
						/*HECHO SELECT cnan FROM MRESTRI WHERE CODI_REGI='10' AND CNAN="+ SERIES.part_nandi+" 
						AND ENTIDAD='05'  AND REGISTRO='0501' AND gc_fech_ingsi BETWEEN FINI AND FFIN*/
						Map<String,Object> mapParamsRestri=new HashMap<String,Object>();
						mapParamsRestri.put("codi_regi", "10");
						mapParamsRestri.put("cnan", serie.getNumpartnandi());
						mapParamsRestri.put("entidad", "05");
						mapParamsRestri.put("registro", "0501");
						mapParamsRestri.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
						//						int contMrestri=FormatoAServiceImpl.getInstance().getMrestriDAO().count(mapParamsRestri);
						MrestriDAOService mrestriDAOService = fabricaDeServicios.getService("Ayuda.mrestriService");
						int contMrestri = mrestriDAOService.count(mapParamsRestri);
						if (contMrestri>0){
							DatoMercancia mercan=serie.getMercancia();
							String riesgosan=mercan!=null?mercan.getCodriesgosanitario():null;
							Long part_nandi=serie.getNumpartnandi();
							Map<String,Object> mapCatParSenasa=new HashMap<String,Object>();
							mapCatParSenasa.put("numPartida", part_nandi);
							mapCatParSenasa.put("cotCatRiesgoSanit", riesgosan);
							mapCatParSenasa.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
							/*HECHO SELECT num_partida, cod_catriesgosanit, cod_escala, A_NUMERO_tasa, A_NUMERO_tasamin, cod_grupo, cod_unimed 
							 * FROM CATPAR_SENASA WHERE NUM_PARTIDA = SERIES.part_nandi AND COD_CATRIESGOSANIT = SERIES.riesgosan
							AND SYSDATE between  fec_ini and fec_fin*/
							//int contCatparSenasa=FormatoAServiceImpl.getInstance().getCatparSenasaDAO().count(mapCatParSenasa);
							int contCatparSenasa=((CatparSenasaDAO)fabricaDeServicios.getService("catparSenasaDAO")).count(mapCatParSenasa);
							if (contCatparSenasa>0){
								plataforma="1";
								calplata="1";
							}else{
								String cadError="SERIE: "+serie.getNumserie()+" PARTIDA "+serie.getNumpartnandi()+" RIESGO SANIT "+riesgosan +" NO CALCULABA AUTOMATICAMENTE MONTO CDA EXTERNO SENASA";
								grabaTelelog(listError,"09864",cadError);
							}
						}else{
							String riesgosan=serie.getMercancia().getCodriesgosanitario();
							String caderror="SERIE:"+serie.getNumserie()+" PARTIDA:"+serie.getNumpartnandi()+" RIESGOSANIT:"+(riesgosan!=null?riesgosan:"")+" NO CALCULARA AUTOMATICAMENTE MONTO CDA EXTERNO SENASA";
							grabaTelelog(listError,"09864",caderror);
						}
					}
				}
			}
		}
		return listError;
	}


	/**
	 * Realiza la validacion documento autorizante para vehiculos usados.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=3509)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3509,numSecEjec=11,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valVehiculosUsados(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		List<DatoSerie> lstSeries=declaracion.getDua().getListSeries();
		boolean esMercaUsa=true;
		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
	    boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
	    boolean serieRelacionada = false;
	    boolean enviaAutorizacionVHUsado =  false;
	    boolean enviarficha = false;
	    boolean enviarReporte = false;
	    boolean enviarTipoDocAutorizanteVHUsado = true;
		if(esVigenteRIN05PrimeraParte && "10".equals(dua.getCodregimen())){
		Integer numsecdocum=0;
    	for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){

			String inddel = docSoporte.getIndicadorEliminado()!=null?docSoporte.getIndicadorEliminado().toString():"0";
			
			boolean  noEsRegistroEliminado = "0".equals(inddel)?true:false;
			
			
			if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado){
				if(!SunatStringUtils.include((String.valueOf(docSoporte.getCodtipodocasoc())), new String[]{ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_FICHA_VEHICULO_USADOS,ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_REPORTE_VEHICULO_USADOS}))
				{
					enviarTipoDocAutorizanteVHUsado = false;
					break;
				}		
				
			}
			if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
					&& ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_FICHA_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
				enviarficha = true;
				break;
			}
			
			if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
					&& 	ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_REPORTE_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
				enviarReporte = true;
				break;
			}
		}
    	if (!enviarTipoDocAutorizanteVHUsado){
    		grabaTelelog(listError,"50135","");
    	}
    	if (enviarficha||enviarReporte){
    		enviaAutorizacionVHUsado =  true;
    	}

    	 if(!CollectionUtils.isEmpty(lstSeries)){
    	for (DatoSerie serie : lstSeries) {
    	
    		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
    		numsecdocum=0;    		
    			if (SunatStringUtils.include(serie.getCodestamerca(), new String[]{ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO,ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_ARMADO,
    					ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_DESARMADO,ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_SEMIDESARMADO,
    					ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_SEMI_ARMADO,ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_AVERIADO_O_DETERIORADO,
    					ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_RECONSTRUIDO,ConstantesDataCatalogo.CODIGO_ESTADO_MERCANCIA_USADO_REMANUFACTURADO})) {
    				serieRelacionada = false;
    	    		enviaAutorizacionVHUsado =  false;
    	    		enviarficha = false;
    	    		enviarReporte = false;
    				
    				 
			    		for(DatoSerieDocSoporte serieDoc:serieDocs){
			    			if (ConstantesDataCatalogo.DOC_DE_SOPORTE.equals(serieDoc.getCodtipodocsoporte()) ){
			    				numsecdocum=serieDoc.getNumiddocsoporte();
			    			if (numsecdocum!=null && numsecdocum!=0){
			    				for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){
			    					String inddel = docSoporte.getIndicadorEliminado()!=null?docSoporte.getIndicadorEliminado().toString():"0";
			    					
			    					boolean  noEsRegistroEliminado = "0".equals(inddel)?true:false;
			    					if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
			    							&& ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_FICHA_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
			    						enviarficha = true;
			    						
			    					}
			    					
			    					if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
			    							&& 	ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_REPORTE_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
			    						enviarReporte = true;
			    						
			    					}
			    					
			    					
			    					
			    					if (numsecdocum.intValue()==docSoporte.getNumsecdocum() && docSoporte.getCodtipoproceso().equals(ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS)){
			    						serieRelacionada = true;
			    						
			    					}			
			    					
			    					
			    					
			    				}
			    				if (enviarficha && enviarReporte){
		    			    		enviaAutorizacionVHUsado = true;
		    			    		
		    			    	}
			    			}
			    			if(!serieRelacionada){
			    				break;
			    			}
			    			if(!enviaAutorizacionVHUsado){
			    				break;
			    			}
			    			
			    		 }
			    		}
			    		if(!serieRelacionada){
			    			
			    			grabaTelelog(listError,"50116","" + serie.getNumserie());
			    		}
			    		if(!enviaAutorizacionVHUsado){
			    			
			    			if(!enviarficha){
			    				grabaTelelog(listError,"50134","" + serie.getNumserie());
			    			}
			    			
			    			if(!enviarReporte){
			    				grabaTelelog(listError,"50115","" + serie.getNumserie());
			    			}		    			
		    			}
    			
    			}else{
    				String numeroFicha="";
					String numeroReporte="";
					 if(!CollectionUtils.isEmpty(serieDocs)){
    				for(DatoSerieDocSoporte serieDoc:serieDocs){
    				
		    			if (ConstantesDataCatalogo.DOC_DE_SOPORTE.equals(serieDoc.getCodtipodocsoporte()) ){
		    				numsecdocum=serieDoc.getNumiddocsoporte();
		    			if (numsecdocum!=null && numsecdocum!=0){
		    				for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){
		    					String inddel = docSoporte.getIndicadorEliminado()!=null?docSoporte.getIndicadorEliminado().toString():"0";
		    					
		    					boolean  noEsRegistroEliminado = "0".equals(inddel)?true:false;
		    					
		    					if (numsecdocum.intValue()==docSoporte.getNumsecdocum()){
		    						serieRelacionada = true;
		    					
		    					}
		    					
		    					if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
		    							&& ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_FICHA_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
		    						enviarficha = true;
		    						numeroFicha = docSoporte.getNumdocasoc();
		    						
		    					}
		    					
		    					if ( ConstantesDataCatalogo.DOC_AUTORIZACION_VEHICULOS_USADOS.equals(docSoporte.getCodtipoproceso()) && noEsRegistroEliminado 
		    							&& 	ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_REPORTE_VEHICULO_USADOS.equals(String.valueOf(docSoporte.getCodtipodocasoc()))){
		    						enviarReporte = true;
		    						numeroReporte =docSoporte.getNumdocasoc();
		    						
		    					}
		    					
		    				 					
		    					
		    				}
		    				if (enviarficha && enviarReporte){
	    			    		enviaAutorizacionVHUsado = true;
	    			    		
	    			    	}
		    			}
		    			if(!serieRelacionada){
		    				break;
		    			}
		    			if(enviaAutorizacionVHUsado){
		    				break;
		    			}
		    			
		    			if(enviarficha){
		    				break;
		    			}
		    			if(enviarReporte){
		    				break;
		    			}
		    			
		    		 }
		    		}
		    		if(!serieRelacionada && enviaAutorizacionVHUsado){
		    			
		    			grabaTelelog(listError,"35614",new Object[]{numsecdocum,serie.getNumserie()});
		    			
		    		}
		    		if(enviaAutorizacionVHUsado){	    			
		    			grabaTelelog(listError,"50136",new Object[]{serie.getNumserie(),numeroFicha,numeroReporte});
	    			}else{
	    				if(enviarficha){
		    				grabaTelelog(listError,"50137",new Object[]{serie.getNumserie(),numeroFicha});
		    			}
		    			
		    			if(enviarReporte){
		    				grabaTelelog(listError,"50138",new Object[]{serie.getNumserie(),numeroReporte});
		    			}
	    			}
    				
    			}
    		
    		 }


    	  }
		}
		}
//  FIN \PAS20181U220200004\   
	    

		
		return listError;
	}
	/**
	 * Realiza la validacion del estado de la mercancia.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2357)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2357,numSecEjec=11,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valEstadoMercancia(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		//Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		boolean esNuevo=true;
		boolean esMercaUsa=true;
		boolean btnan=true;
		for(DatoSerie serie:dua.getListSeries()){
			if (!SunatStringUtils.include(serie.getCodestamerca(), new String[]{"10","11","12","13","14","15","16"}))
				esNuevo=false;
			if (!SunatStringUtils.include(serie.getCodestamerca(), new String[]{"20","21","22","23","24","25","26","27","28"}))
				esMercaUsa=false;
			if (!SunatStringUtils.include(serie.getCodtnan(), new String[]{"20","21","22","23","24","25","26","27","28"}))
				btnan=false;
			if (!esNuevo && !esMercaUsa && !btnan)
				break;
		}
		//boolean esAutoUsa=esMercaUsa && btnan;
		//TDDI 89.X.III - 89.Z.VIII Regla 50
		boolean valEstim=false;
		if (vigenciaCriterio("1027",SunatDateUtils.getCurrentIntegerDate())>0){
			for(DatoSerie serie:dua.getListSeries()){
				if (serie.getValestimado()!=null && serie.getValestimado().compareTo(BigDecimal.ZERO)>0){
					if (!valEstim)
						valEstim=true;
				}
			}
			if (valEstim && dua.getFecfinprovsional()==null)
				//grabaTelelog(listError,  "30101", "EXISTE VALOR ESTIMADO EN SERIES, ENVIE FECHA VENCIMIENTO DEL VALOR PROVISIONAL");
				listError.add(ResponseMapManager.getErrorResponseMap("05791", "EXISTE VALOR ESTIMADO EN SERIES, ENVIE FECHA VENCIMIENTO DEL VALOR PROVISIONAL"));
			if (dua.getFecfinprovsional()!=null){
				if (!valEstim)
				{listError.add(ResponseMapManager.getErrorResponseMap("05792", "ENVIO FECHA VENCIMIENTO DE VALOR PROVISIONAL, PERO NO HAY VALOR ESTIMADO EN SERIES"));}
				//grabaTelelog(listError,"30101","ENVIO FECHA VENCIMIENTO DE VALOR PROVISIONAL, PERO NO HAY VALOR ESTIMADO EN SERIES");
				Calendar calMin=Calendar.getInstance();
				Calendar calMax=Calendar.getInstance();
				calMin.add(Calendar.MONTH, 3);
				calMax.add(Calendar.MONTH, 24);
				if (SunatDateUtils.compareDate(dua.getFecfinprovsional(),calMin.getTime())<0 || SunatDateUtils.compareDate(dua.getFecfinprovsional(), calMax.getTime())>0){
					FechaBean fbMin=new FechaBean();
					FechaBean fbMax=new FechaBean();
					fbMin.setFecha(calMin.getTime());
					fbMax.setFecha(calMax.getTime());
					listError.add(ResponseMapManager.getErrorResponseMap("05793", "FECHA VENCIMIENTO VALOR PROVISIONAL DEBE ESTAR ENTRE "+fbMin.getFormatDate("yyyyMMdd")+" y "+fbMax.getFormatDate("yyyyMMdd")));					
					//grabaTelelog(listError,"30101","FECHA VENCIMIENTO VALOR PROVISIONAL DEBE ESTAR ENTRE "+fbMin.getFormatDate("yyyyMMdd")+" y "+fbMax.getFormatDate("yyyyMMdd"));
				}
			}
		}
		boolean usarCodigoNuevo = false;
		Date fecVigencia = SunatDateUtils.getDate(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
				.getElementoCat("517", "FEC_INIVIG")
				.get("des_datacat").toString());

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			usarCodigoNuevo = true;
		}
		if(!usarCodigoNuevo){
			for(DatoSerie serie:dua.getListSeries()){

				if(! SunatStringUtils.isStringInList((serie.getMercancia()==null?"":serie.getMercancia().getCodexoneracion()), "98,80") )
				{
					Map<String,Object> params=new HashMap<String,Object>();
					params.put("cnan", serie.getNumpartnandi());
					params.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
					if (SunatStringUtils.include(dua.getCodregimen(),new String[]{"10","70"})){
						params.put("orCodiRegi", "98");
						params.put("orTipodoc", "5");
					}else{
						params.put("codiRegi", dua.getCodregimen());
					}


					//				List<MRestri> listMrestriTablNew=FormatoAServiceImpl.getInstance().getMrestriDAO().listadoMercRestringida(params);
					MrestriDAOService mrestriDAOService = fabricaDeServicios.getService("Ayuda.mrestriService");
					List<MRestri> listMrestriTablNew = mrestriDAOService.listadoMercRestringida(params);
					if (listMrestriTablNew!=null && !listMrestriTablNew.isEmpty()){
						boolean tieneDocAutoriz=!getDocAutorizante(dua,serie).isEmpty();
						for(MRestri mRestri:listMrestriTablNew){
							String cprod=mRestri.getCprod();
							String entidad=mRestri.getEntidad();
							String registro=mRestri.getRegistro();
							if ("00".equals(cprod)){
								if (!tieneDocAutoriz){
									grabaTelelog(listError,"30382",new Object[]{serie.getNumserie(),serie.getNumpartnandi()});
								}
							}
							if ("05".equals(entidad) && "0501".equals(registro)){
								if (!tieneDocAutoriz){
									grabaTelelog(listError,"30383",new Object[]{serie.getNumserie(),serie.getNumpartnandi()});
								}
							}
							if ("17".equals(entidad) && "1701".equals(registro)){
								if (!tieneDocAutoriz){
									grabaTelelog(listError,"30384",new Object[]{serie.getNumserie(),serie.getNumpartnandi()});
								}
							}					
						}
					}								
				}
			}
		}

		return listError;
	}

	/**
	 * Val tp n212 tp n208.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2358)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2358,numSecEjec=12,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valTPN212TPN208(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		String maduana=(String)mapVariables.get("maduana");
		if ("4".equals(dua.getDeclarante().getTipoDocumentoIdentidad().getDesDatacat()) 
				&& SunatStringUtils.include(dua.getDeclarante().getNumeroDocumentoIdentidad(), new String[]{"20267616541","20325753821"})){
			for(DatoSerie serie:dua.getListSeries()){
				//TDDI Regla 56 TPN 212
				boolean tpn212=false;
				if ("20267616541".equals(dua.getDeclarante().getNumeroDocumentoIdentidad()) && SunatStringUtils.include(maduana,new String[]{"145","163","172"}) && "JP".equals(serie.getCodpaisorige())){
					tpn212=true;
				}else{
					if (!"JP".equals(serie.getCodpaisorige()))
						grabaTelelog(listError,"00111","TPN 212: Habilitado solo para pais de origen JAPON");
					else
						grabaTelelog(listError,"00111","TPN 212: No Habilitado para aduana "+maduana);
				}
				//TDDI Regla 57
				//En ValAutocer
				//TDDI Regla 58
				boolean tpn208=false;
				if ("20325753821".equals(dua.getDeclarante().getNumeroDocumentoIdentidad()) && SunatStringUtils.include(maduana,new String[]{"145","163","172"}) && "JP".equals(serie.getCodpaisorige())){
					tpn208=true;
				}else{
					if (!"JP".equals(serie.getCodpaisorige()))
						grabaTelelog(listError,"00111","TPN 208: Habilitado solo para pais de origen JAPON");
					else
						grabaTelelog(listError,"00111","TPN 208: No Habilitado para aduana "+maduana);
				}
			}
		}
		return listError;
	}

	/**
	 * Realiza la validacion de ultractividad.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2359)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2359,numSecEjec=13,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valUltractividad(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		//Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		//TDDI Regla 67
		DatoPago pago=dua.getPago();
		DatoPagoTrans trans=pago!=null?pago.getPagoTransaccion():null;
		Date feccarcr=trans!=null?trans.getFeccarcr():null;
		for(DatoSerie serie:dua.getListSeries()){
			//PAS20134E610000296 - Dar a la fecha por defecto 01/01/0001 el tratamiento de Valor Nulo
			if ("01".equals(serie.getCodaplultra()) && DateUtil.isNullOrDefaultFormatoSunat(feccarcr) ) {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");  
				String prueba = (feccarcr==null?"null":sdf.format(feccarcr)); 
				grabaTelelog(listError,"30102","APL_ULTRA: 01, FECH_CARCR: "+ prueba);
			}
			if (SunatStringUtils.include(serie.getCodaplultra(), new String[]{"01","02","03"})){
				for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
					if (SunatStringUtils.include(regPrec.getCodregipre(), new String[]{"20","21","70","80","89"}))
						grabaTelelog(listError,"30102","APL_ULTRA:"+serie.getCodaplultra()+", REG.PRECEDENTE:"+regPrec.getCodregipre()+'-'+ regPrec.getAnndeclpre()+'-'+ regPrec.getCodregipre()+'-'+ regPrec.getNumdeclpre()+'-'+regPrec.getNumserpre());
				}
			}
		}
		return listError;
	}

	/**
	 * Realiza validaciones de los detalles de las series.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2360)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2360,numSecEjec=14,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valDetalleSeries(Declaracion declaracion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		//String maduana=(String)mapVariables.get("maduana");
		String tipo_despa=(String)mapVariables.get("tipo_despa");
		//TDDI Regla 70
		BigDecimal mfobser=BigDecimal.ZERO;
		BigDecimal maxfob=BigDecimal.ZERO;
		BigDecimal mtiptran=BigDecimal.ONE;

		//amancilla
		String transaccion = declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans().toString():"";

		/*		-	Se verifica si est� actualizado el Tipo de Cambio.
				�	Se obtiene el tipo de cambio de la tabla CAMBIO1 usando este query:
				Sql = "select pventa from cambio1 where fingreso="+ gc_fech_ingsi + " and cmoneda='"+SERIES.cod_moneda+ "'"
				o	Si Encuentra informaci�n entonces:
				mtiptran= ocam.pventa
				o	Sino:
				SE ABORTA EL PROCESO.*/

		//glazaror... generamos cadena para consultar los distintos tipo de cambio que aparecen en las series de la dua
		StringBuilder monedasConsulta = new StringBuilder();
		List<String> monedasAdicionadas = new ArrayList<String>();
		for(DatoSerie serie : dua.getListSeries()) {
			if (serie.getCodmoneda() != null && !serie.getCodmoneda().trim().isEmpty()) {
				//verificamos si la moneda y fecha ya fue adicionada en la busqueda
				Integer fechaIngreso = null;
				//Si fec declaraci�n es null es numeraci�n
				if(dua.getFecdeclaracion() == null) {
					fechaIngreso = SunatDateUtils.getCurrentIntegerDate();
				} else {//Es Recti o Regu
					fechaIngreso = SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion());
				}
				String monedaFecha = serie.getCodmoneda() + fechaIngreso;
				if (!monedasAdicionadas.contains(monedaFecha)) {
					monedasConsulta.append(serie.getCodmoneda().toUpperCase()).append(fechaIngreso).append(",");
					monedasAdicionadas.add(monedaFecha);
				}
			}
		}
		Map<String, BigDecimal> monedasMap = new HashMap<String, BigDecimal>();
		if (monedasConsulta.length() > 0) {
			monedasConsulta.deleteCharAt(monedasConsulta.length() - 1);
			Map<String,Object> mapCambio1 = new HashMap<String,Object>();
			mapCambio1.put("codMonedas", monedasConsulta.toString());
			mapCambio1.put("ayudaID", "Cambio1");
			//Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(mapCambio1);
			List<Map<String, Object>> monedas = ((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscar(mapCambio1);
			//agrupamos por moneda y fecha... solo se requiere el dato PVENTA
			for (Map<String, Object> moneda : monedas) {
				String identificador = moneda.get("cmoneda").toString() + moneda.get("fingreso");
				BigDecimal pVenta = monedasMap.get(identificador);
				if (pVenta == null) {
					pVenta = SunatNumberUtils.toBigDecimal(moneda.get("pventa"));
					monedasMap.put(identificador, pVenta);
				}
			}
		}
		//glazaror... 


		for(DatoSerie serie:dua.getListSeries()) {
			//NSR: 24/05/2011
			//La fecha de cambio debe ser el de la numeraci�n
			Integer fecIngreso=null;
			//Si fec declaraci�n es null es numeraci�n
			if(dua.getFecdeclaracion()==null){
				fecIngreso = SunatDateUtils.getCurrentIntegerDate();
			} else {//Es Recti o Regu
				fecIngreso = SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion());
			}


			//glazaror... buscamos el pventa del mapa de monedas
			BigDecimal pVenta = monedasMap.get(serie.getCodmoneda() + fecIngreso);

			//glazaror... reemplazamos la verificacion de cambio1 por pVenta
			//if (cambio1==null){
			if (pVenta == null){
				grabaTelelog(listError,"30391",new Object []{serie.getCodmoneda()});
			}else{
				//glazaror... reemplazamos la asignacion del pventa
				//mtiptran=cambio1.getPventa();
				mtiptran = pVenta;
			}
			//			BigDecimal pventa=valTipoCambio(listError,serie);
			if(serie.getProducto() == null)
				serie.setProducto( new DatoProducto() );

			DatoProducto product=serie.getProducto();
			String codpantidum=product!=null?product.getCodpantidum():null;

			if (SunatStringUtils.isEmptyTrim(codpantidum))
				serie.getProducto().setCodpantidum("0");
			if (SunatStringUtils.isEmptyTrim(serie.getIndzonafranca()))
				serie.setIndzonafranca("0");
			if ("USD".equals(serie.getCodmoneda())){
				mfobser=SunatNumberUtils.sum(mfobser,serie.getMtofobdol());
			}else{
				BigDecimal motfobmon=(serie.getMtofobmon()==null?new BigDecimal(0):serie.getMtofobmon()).multiply(mtiptran);
				mfobser=SunatNumberUtils.sum(mfobser,motfobmon);
				BigDecimal mfobcal=(motfobmon).setScale(3, BigDecimal.ROUND_HALF_UP);
				if (SunatNumberUtils.diference(serie.getMtofobdol(),mfobcal).compareTo(new BigDecimal(0.001))>0)

					if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)
							&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)
							&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)){
						grabaWarningTelelog(listError,"01083","FOB_DOLPOL: ENVIADO "+(serie.getMtofobdol().doubleValue())+" CALCULO AL CAMBIO "+(mfobcal.doubleValue()));
					}
				//TDDI Regla 74
				if (  SunatNumberUtils.isLessThanParam(maxfob, serie.getMtofobdol())){
					maxfob=serie.getMtofobdol();
				}
			}
			//TDDI Regla 76- Regla 79
			DatoManifiesto manif=declaracion.getDua().getManifiesto();
			Date fectermino=manif!=null?manif.getFectermino():null;

			if (SunatStringUtils.include(tipo_despa, new String[]{"00","10"}) && (getDocTransporte(dua,serie)==null || SunatStringUtils.isEmptyTrim(getDocTransporte(dua,serie).getNumdoctransporte()))){
				// R1780 Cuando el tipo de llegada es de equipajes no se consigna documento de transporte
				String codigoPuntoLLegadaMercancia = dua.getCodlugarecepcion()!=null?dua.getCodlugarecepcion().toString():"";
				if (!SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia, ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL)) {
					grabaTelelog(listError,"30322","CONO_EMBAR: ENVIADO ");
				}
			}
			if (getDocTransporte(dua,serie)!=null){
				Date fecEmbarque=getDocTransporte(dua,serie).getFecembarque();
				boolean FechaTerminoDiferenteDefault = !SunatDateUtils.sonIguales(fectermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA);  
				if (fecEmbarque==null || (fectermino.compareTo(fecEmbarque)<0 && FechaTerminoDiferenteDefault )){
					String fechEmbar;
					if (getDocTransporte(dua,serie).getFecembarque()==null)
						fechEmbar=null;
					else{
						FechaBean fb=new FechaBean();
						fb.setFecha(getDocTransporte(dua,serie).getFecembarque());
						fechEmbar=fb.getFormatDate("yyyyMMdd");
					}
					grabaTelelog(listError,"00065","FECH_EMBAR: ENVIADO "+fechEmbar);
				}
			}
			//NO SE ENCUENTRAN EN LA INGENIERIA REVERSA
			//VALIDACIONES AGREGADAS POR OBSERVACIONES DE CALIDAD

			if (!CollectionUtils.isEmpty(listError)) {
				String codigoError = null;
				codigoError = listError.get(0).get("codError");
				if (!"30322".equals(codigoError) && codigoError != null) {
					if (tieneDocTransporte(serie)
							&& getDocTransporte(dua, serie) == null)
						grabaTelelog(listError, "30322", "");
				}
			}
			boolean tieneCertiOrigen=tieneCertiOrigen(serie);
			List<DatoAutocertificacion> listCertiOrigen=getCertiOrigen(dua,serie);
			if (tieneCertiOrigen && listCertiOrigen.isEmpty())
				grabaTelelog(listError,"30326","");
			if (tieneCertiOrigen && listCertiOrigen.size()!=getCantidadCertiOrigen(serie))
				grabaTelelog(listError,"30327","");
			boolean tieneFactura=tieneFacturaRef(serie);
			List<DatoFacturaref> listFactura=getFacturaRef(dua,serie);
			if (tieneFactura && listFactura.isEmpty())
				grabaTelelog(listError,"30328","");
			if (tieneFactura && getCantidadFacturaRef(serie)!=listFactura.size())
				grabaTelelog(listError,"30350","");
			/** INICIO cambios por verificacion de LC asociada a la serie por el PAS20155E220000508**/
			if(declaracion.getNumdeclRef()!=null && !SunatStringUtils.isEmptyTrim(declaracion.getNumdeclRef().getNumcorre())){
				boolean tieneLC=tieneLC(serie);
				List<DatoOtroDocSoporte> listLC=getLC(dua,serie);
				//amancilla esta regla solo aplica a recti
				if (!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)
						&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)
						&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)
						&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION)) { //Se adiciono TRANSACCION_REGULARIZACION por INC 2016-029595  

					if (tieneLC && !listLC.isEmpty()){
						String rlano = SunatDateUtils.getAnho(listLC.get(0).getFecdocasoc()).toString().substring(0, 4);
						String numeroLiq = rlano + "-" + listLC.get(0).getNumdocasoc();
						grabaTelelog(listError,"35604", "" + numeroLiq);
					}
				}
			}
		}
		List<DatoFacturaref> listFacturaDUA=dua.getListFacturaRef();
		for(DatoFacturaref factura:listFacturaDUA){
			boolean encontrado=false;
			for(DatoSerie serie:dua.getListSeries()){
				List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
				Integer numSecFactu=0;
				for(DatoSerieDocSoporte serieDoc:serieDocs){
					if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
						numSecFactu=serieDoc.getNumiddocsoporte();
					if (numSecFactu!=null && numSecFactu!=0){
						if (numSecFactu.intValue()==factura.getNumsecfactu()){
							encontrado=true;
							break;
						}
					}
				}
				if (encontrado)
					break;
			}
			if (!encontrado)
				grabaTelelog(listError,"30357",new Object[]{factura.getNumfactura()});
		}
		List<DatoDocAutorizante> listDocAutorizanteDUA=dua.getListDocAutorizantes();
		for(DatoDocAutorizante docAutorizante:listDocAutorizanteDUA){
			boolean encontrado=false;
			for(DatoSerie serie:dua.getListSeries()){
				List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
				Integer numSecAutorizante=0;
				for(DatoSerieDocSoporte serieDoc:serieDocs){
					if (DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte()))
						numSecAutorizante=serieDoc.getNumiddocsoporte();
					if (numSecAutorizante!=null && numSecAutorizante!=0){
						if (numSecAutorizante.intValue()==docAutorizante.getNumsecdocum()){
							encontrado=true;
							break;
						}
					}
				}
				if (encontrado)
					break;
			}
			if (!encontrado)
				grabaTelelog(listError,"30358",new Object[]{docAutorizante.getNumdocum()});
		}	
		List<DatoAutocertificacion> listCertOrigenDUA=dua.getDatoCertificadoOrigen().getListAutocertificacion();
		for(DatoAutocertificacion docCertOrigen:listCertOrigenDUA){
			boolean encontrado=false;
			for(DatoSerie serie:dua.getListSeries()){
				List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
				Integer numSecCO=0;
				for(DatoSerieDocSoporte serieDoc:serieDocs){
					if (CERTI_ORIGEN.equals(serieDoc.getCodtipodocsoporte()))
						numSecCO=serieDoc.getNumiddocsoporte();
					if (numSecCO!=null && numSecCO!=0){
						if (SunatNumberUtils.isEqual(numSecCO, docCertOrigen.getNumsecCO())){
							encontrado=true;
							break;
						}
					}
				}
				if (encontrado)
					break;
			}
			if (!encontrado)
				grabaTelelog(listError,"30402",new Object[]{docCertOrigen.getNumdocumento()});
		}
		ValNegocAduadet1FormA SPTD_ADUADET1 =  fabricaDeServicios.getService("ingresos.valNegocAduadet1FormA");
		listError.addAll(SPTD_ADUADET1.valAduadet(declaracion));
		return listError;
	}


	/*Pertenece  la seccion del TDDI que valida los TPI 802,803,804,805 , que son los TLC
	 * con EEUU, Canada, Singapur y China 
	 * */
	/**
	 * Val tp i_ tlc.
	 * 
	 * @param declaracion Declaracion
	 * @param serie DatoSerie
	 * @param mapVariables Map<String,Object>
	 * @param codTransaccion String
	 * @return Lista de erores
	 * @deprecated
	 * @return
	 */
	private List<Map<String,String>> valTPI_TLC(Declaracion declaracion, DatoSerie serie
			, Map<String,Object> mapVariables  ,String codTransaccion ){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		String convInter= SunatStringUtils.toStringObj(serie.getCodconvinter());

		// estas variables se obtiene del metodo getVariablesIniciales ej . gbTPI802
		Boolean flagActivacion=(Boolean)mapVariables.get("gbTPI"+convInter);
		DUA dua=declaracion.getDua();
		String tipoTransc=codTransaccion.substring(2);
		//boolean isTlcValido= FormatoAServiceImpl.getInstance().getCatalogoValidacionService().isValid(convInter, ConstantesDataCatalogo.CATALOG_CONTINGENTE_ARANCELARIO);
		boolean isTlcValido= CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesDataCatalogo.CATALOG_CONTINGENTE_ARANCELARIO, convInter,SunatDateUtils.getCurrentDate()));
		boolean isTlcVigente=false;
		if (isTlcValido) 
			isTlcVigente=flagActivacion==null?false:flagActivacion;


		if("10".equals(declaracion.getDua().getCodregimen()) && isTlcValido
				&& ("802".equals(convInter) || "803".equals(convInter) || "804".equals(convInter) || "805".equals(convInter) || "806".equals(convInter) || "807".equals(convInter)|| "808".equals(convInter) || "812".equals(convInter))){
			if(isTlcVigente){  		

				// validamos que se transmitan datos del certidicado
				// obteniendo el certificado de origen , deberia haber 1 por serie
				List<DatoAutocertificacion> lstCerti=   getCertiOrigen(dua, serie);
				if(CollectionUtils.isEmpty(lstCerti)){
					// 342 DEBE DE ENVIAR CERTIFICADO DE ORIGEN
					listError.add(getDUAError("30432",new Object[]{serie.getNumserie()}));
					return listError;
				}					

				// obtenemos la fecha

				Integer fechaProc= tipoTransc.equals("01")?SunatDateUtils.getCurrentIntegerDate():SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());  

				// Obtenemos el Nombre del Proveedor

				//String nomProvedor=obtenerProveedor(declaracion);

				//Participante declarante=declaracion.getDua().getDeclarante();
				//DataCatalogo tipoDocDecla=declarante!=null?declarante.getTipoDocumentoIdentidad():null;
				//String tipodocum=tipoDocDecla!=null?tipoDocDecla.getCodDatacat():null;
				//String numDocumento=declarante!=null?declarante.getNumeroDocumentoIdentidad():null;


				//Obtenemos el nro. y fecha de factura
				List<DatoFacturaref> lstFacturas=getFacturaRef(dua, serie);
				DatoFacturaref facturaRef=new DatoFacturaref();
				if(!CollectionUtils.isEmpty(lstFacturas))
					facturaRef=lstFacturas.get(0);

				String numFactura=facturaRef.getNumfactura();
				//Integer fecFactura= SunatDateUtils.getIntegerFromDate(facturaRef.getFecfactura()); 

				DatoAutocertificacion certificadoOri=new DatoAutocertificacion();
				if(!CollectionUtils.isEmpty(lstCerti))
					certificadoOri=lstCerti.get(0);

				String nomEmisor=  certificadoOri.getNomemisorCO();
				Integer fecCertiOrigen= SunatDateUtils.getIntegerFromDate(certificadoOri.getFecemision());

				// obteniendo el monto cif
				//mto_cif     WITH duadet.val_aduana

				BigDecimal mtoCif=serie.getMtovaladuana();


				mapVariables.put("GbSolTPI"+convInter, true);
				listError.addAll(PrcvalidaTPI(declaracion, SunatDateUtils.getDateFromInteger(fechaProc),serie,codTransaccion ));



				if("804".equals(convInter)){
					//if (!FormatoAServiceImpl.getInstance().isValidCatalogo("804", serie.getCodestamerca())){
					boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("804", serie.getCodestamerca(),SunatDateUtils.getCurrentDate()));
					if (!validaCatalogo){
						// ERROR:  MERCANCIA NO NEGOCIADA : {0}
						listError.add(getDUAError("30406",new Object[]{serie.getCodestamerca()}));
					}

				}

				if("805".equals(convInter)){
					/* &&& Valido que cada Serie no supere los 600 dolares
						 IF ctipcert="5" and mto_cif > 600
						    =graba_telelog(  RIGHT( wAnoOrden,2), " ",;
							allt(str(cTPI805SerSol.nume_serie)), "8811" , "Importacion supera los $ 600. Requiere certificado de origen "," ", " " )
						 ENDIF*/

					BigDecimal mtoLimite=new BigDecimal(600.00);

					if("5".equals(certificadoOri.getCodtipoCO()) && SunatNumberUtils.isGreaterThanParam(mtoCif, mtoLimite) ){

						// ERROR:  IMPORTACION SUPERA LOS $ 600 . REQUIERE CERTIFICADO DE ORIGEN
						listError.add(getDUAError("30405", new Object[]{mtoLimite}));
					}

					Map<String,Object> params=new HashMap<String, Object>();
					params.put("feccertificado", fecCertiOrigen);
					params.put("tipCertificado", "5");
					params.put("emisorcertificado", SunatStringUtils.trim(nomEmisor));
					params.put("tpi","805");
					params.put("numfactura",numFactura);

					//List<Map<String,Object>> lstCertiBD=FormatoAServiceImpl.getInstance().getDetAutorizacionDAO().findSerieCertificadoFacturaTpi(params);
					List<Map<String,Object>> lstCertiBD=((DetAutorizacionDAO)fabricaDeServicios.getService("detAutorizacionDAO")).findSerieCertificadoFacturaTpi(params);

					// &&& Valido que no exista una serie con igual fecha certificado, numero factura, emisor certificado
					// si es numeracion
					if(!CollectionUtils.isEmpty(lstCertiBD) && "01".equals(tipoTransc) ){
						/*=graba_telelog(  RIGHT( wAnoOrden,2), " ",;
							allt(str(cTPI805SerSol.nume_serie)), "8811" , " La declaracion de origen ya fue utilizada en otra importacion. "," ", " " )*/
						listError.add(getDUAError("30407", new Object[]{certificadoOri.getNumdocumento()}));
					}

					//		 &&& Valido estado de la mercancia 
					//if (!FormatoAServiceImpl.getInstance().isValidCatalogo("805", serie.getCodestamerca())){
					boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("805", serie.getCodestamerca(),SunatDateUtils.getCurrentDate()));
					if (!validaCatalogo){
						// ERROR:  MERCANCIA NO NEGOCIADA
						listError.add(getDUAError("30406",new Object[]{serie.getCodestamerca()}));
					}


					//Valido que no exista una serie con igual fecha certificado, numero factura, emisor certificado y tenga suma de cif mayor a 600
					BigDecimal totalCif=obtenerTotalCifCertificadosTPI805(dua,fecCertiOrigen,nomEmisor,numFactura);

					/*
						  SELECT FCERTORI,NOM_EMISOR,NRO_FACTU,SUM(MTO_CIF)  MTO_CIF 
						    FROM CTPI805SERSOL 
						    WHERE CTIPCERT='5' GROUP BY FCERTORI,NOM_EMISOR,NRO_FACTU ;

    	                   IF VALTLCCIF.MTO_CIF > 600
							           =graba_telelog(  RIGHT( wAnoOrden,2), " ",;
								       " ", "8811" , "Importacion de mercancias con declaracion de origen supera los $ 600. Requiere certificado de origen."," ", " " )
							        ENDIF
					 * */						  

					if(SunatNumberUtils.isGreaterThanParam(totalCif, mtoLimite)){
						// "IMPORTACION DE MERCANCIAS CON DECLARACION DE ORIGEN SUPERA LOS $600. REQUIERE CERTIFICADO ORIGEN"));							  
						listError.add(getDUAError("30405", new Object[]{mtoLimite}));
					}
				}										




			}
			else{
				// TPI {0} NO ESTA VIGENTE
				listError.add(getDUAError("30403", new Object[]{serie.getCodconvinter(),"NO ESTA VIGENTE"}));
				/*  =graba_telelog(RIGHT(duadet.Ano_Orden,2)," ",STR(duadet.nume_serie,4),;
		                 "8812","TPI:" + ALLTRIM(STR(duadet.conv_inter,4)) + " NO ESTA VIGENTE"," "," ")           
				 */	
			}
		}


		return listError;
	}

	/*
	 * @deprecated
	 */
	// DZC INI, Valida TPI 229 u otras funcionalidades que deseen validar certificado de origen
	private List<Map<String,String>> val_SoloTPI(Declaracion declaracion, DatoSerie serie
			, Map<String,Object> mapVariables  ,String codTransaccion ){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		String convInter= SunatStringUtils.toStringObj(serie.getCodconvinter());

		// estas variables se obtiene del metodo getVariablesIniciales ej . gbTPI802
		Boolean flagActivacion=(Boolean)mapVariables.get("gbTPI"+convInter);
		DUA dua=declaracion.getDua();
		String tipoTransc=codTransaccion.substring(2);
		// si es importaci�n y TPI 229, aca entraran todos los TPI que no son TLC para que pueda entrar al PrcvalidaTPI
		if("229".equals(convInter)){  		

			// validamos que se transmitan datos del certidicado
			// obteniendo el certificado de origen , deberia haber 1 por serie
			List<DatoAutocertificacion> lstCerti=   getCertiOrigen(dua, serie);
			if(CollectionUtils.isEmpty(lstCerti)){
				// 342 DEBE DE ENVIAR CERTIFICADO DE ORIGEN
				listError.add(getDUAError("30432",new Object[]{serie.getNumserie()}));
				return listError;
			}					

			Integer fechaProc= tipoTransc.equals("01")?SunatDateUtils.getCurrentIntegerDate():SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());  

			//Obtenemos el nro. y fecha de factura
			List<DatoFacturaref> lstFacturas=getFacturaRef(dua, serie);
			DatoFacturaref facturaRef=new DatoFacturaref();
			if(!CollectionUtils.isEmpty(lstFacturas))
				facturaRef=lstFacturas.get(0);

			String numFactura=facturaRef.getNumfactura();
			//Integer fecFactura= SunatDateUtils.getIntegerFromDate(facturaRef.getFecfactura()); 

			DatoAutocertificacion certificadoOri=new DatoAutocertificacion();
			if(!CollectionUtils.isEmpty(lstCerti))
				certificadoOri=lstCerti.get(0);

			String nomEmisor=  certificadoOri.getNomemisorCO();
			Integer fecCertiOrigen= SunatDateUtils.getIntegerFromDate(certificadoOri.getFecemision());

			// obteniendo el monto cif
			//mto_cif     WITH duadet.val_aduana

			BigDecimal mtoCif=serie.getMtovaladuana();

			mapVariables.put("GbSolTPI"+convInter, true);
			listError.addAll(PrcvalidaTPI(declaracion, SunatDateUtils.getDateFromInteger(fechaProc),serie,codTransaccion ));
		}

		return listError;
	}	
	// DZC FIN



	/**
	 * Obteniene el total certificados cif con el TPI 805.
	 * 
	 * @param dua DUA
	 * @param fecCertiOrigen Integer
	 * @param nomEmisor String
	 * @param numFactura String
	 * @return cantidad de certificados
	 */
	private BigDecimal obtenerTotalCifCertificadosTPI805(DUA dua,Integer fecCertiOrigen, String nomEmisor,String numFactura){
		BigDecimal total=BigDecimal.ZERO;


		if(!CollectionUtils.isEmpty(dua.getListSeries())){
			for(DatoSerie serie:dua.getListSeries()){

				//Obtenemos el nro. y fecha de factura
				List<DatoFacturaref> lstFacturas=getFacturaRef(dua, serie);
				DatoFacturaref facturaRef=new DatoFacturaref();
				if(!CollectionUtils.isEmpty(lstFacturas))
					facturaRef=lstFacturas.get(0);

				String numFacturaRef=facturaRef.getNumfactura();

				// obteniendo el certificado de origen , deberia haber 1 por serie
				List<DatoAutocertificacion> lstCerti=   getCertiOrigen(dua, serie);
				DatoAutocertificacion certificadoOri=new DatoAutocertificacion();
				if(!CollectionUtils.isEmpty(lstCerti))
					certificadoOri=lstCerti.get(0);

				String nomEmisorRef=  certificadoOri.getNomemisorCO();
				Integer fecCertiOrigenRef= SunatDateUtils.getIntegerFromDate(certificadoOri.getFecemision());

				// obteniendo el monto cif

				BigDecimal mtoCif=serie.getMtovaladuana();

				if("5".equals(certificadoOri.getCodtipoCO())){
					if(SunatStringUtils.isEqualTo(numFactura, numFacturaRef)
							&& SunatStringUtils.isEqualTo(nomEmisor, nomEmisorRef)
							&& SunatNumberUtils.isEqual(fecCertiOrigen, fecCertiOrigenRef)
							){
						total=SunatNumberUtils.sum(total, mtoCif);	
					}

				}

			}

		}

		return total;
	}


	@ServicioAnnot(tipo="V",codServicio=2361)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2361,numSecEjec=15,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valCodigoLiberatorio(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) throws Exception{
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();

		// Inicio P46 - 3003 - INSI
		// Se agrego esta condicion para solucionar el bug 21288.
		// Desarrollo INSI se comprometio a reubicar / modificar esta condicion
		// para no afectar a la RIN8 (PECO)
		if(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION.equals(declaracion.getDua().getCodtipotratamiento())) {
			return new ArrayList<Map<String,String>>();
		}
		// Fin P46 - 3003 - INSI

		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		String Coderr =null;
		boolean gbcontingente=(Boolean)mapVariables.get("gbcontingente");
		//boolean gbTPI802=(Boolean)mapVariables.get("gbTPI802");
		boolean gbContTipDespa=(Boolean)mapVariables.get("gbContTipDespa");
		String tipo_despa=(String)mapVariables.get("tipo_despa");
		//boolean slibotros=(Boolean)mapVariables.get("slibotros");
		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		//TDDI Regla 82 - Regla 96
		boolean vigenciaLGA2004=vigenciaCriterio("TD26",SunatDateUtils.getCurrentIntegerDate())>0;


		// rpumacayo pase70
		//PASE 105 - Se comenta porque va en la parte II del RIN07
		boolean tiene_INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI = false;
		Elementos<DatoIndicadores> listIndicador = dua.getListIndicadores();
		for (DatoIndicadores indicador: listIndicador) {
			if (ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI.equals(indicador.getCodtipoindica())) {
				tiene_INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI = true;
			}
		}
		// rpumacayo pase70

		for(DatoSerie serie:dua.getListSeries()){
			String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
			String codpais =serie.getCodpaisorige();
			//TDDI Regla 82 - Regla 85
			boolean tiene31o32=false;
			boolean tienePeco=false;
			boolean slibpecos=false;
			//slibotros=false;
			if (SunatStringUtils.include(String.valueOf(serie.getCodconvinter()==null?0:serie.getCodconvinter()),new String[]{"31","32","33"}) || (serie.getCodtratprefe()!=null && 33==serie.getCodtratprefe()))
				tiene31o32=true;
			if (SunatStringUtils.include(String.valueOf(serie.getCodconvinter()==null?0:serie.getCodconvinter()),new String[]{"31","32","33","34","35","36"}) || (serie.getCodtratprefe()!=null && 33==serie.getCodtratprefe())){
				tienePeco=true;
				slibpecos=true;
			}
			if (((serie.getCodliberatorio()!=null && serie.getCodliberatorio()!=0)|| 
					(serie.getCodconvinter()!=null && serie.getCodconvinter()!=0)|| 
					(serie.getCodtratprefe()!=null) && serie.getCodtratprefe()!=0) 
					&& !tienePeco)
				//slibotros=true;
				//
				if( SunatStringUtils.isEmpty(serie.getNumpartnalad()) ) {

				}
				else if (  ! SunatStringUtils.isNumeric(serie.getNumpartnalad()) || SunatStringUtils.length(serie.getNumpartnalad() ) > 8 ) {
					grabaTelelog(listError,"01328","Serie ".concat( SunatStringUtils.toStringObj(serie.getNumserie()) ).concat(" - NALADISA: ").concat(serie.getNumpartnalad() != null ?serie.getNumpartnalad() : "nulo" ));

					/*INICIO RIN13*/
					//return listError; //pruizcr rin13
					/*FIN RIN13*/
				}
			// rpumacayo pase70
			if (tiene_INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI && !(serie.getCodconvinter()==100 || serie.getCodconvinter()==229)) {
				if (ConstantesDataCatalogo.TIPO_MARGEN_9.equals(serie.getCodtipomarge())){
					//jenciso se comenta a solicitud de mordo�ez, se difiere la validacion
					//grabaTelelog(listError,"30670", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString()});
				}
			}
			// rpumacayo pase70
			Integer xcnaladisa=serie.getNumpartnaladAsInteger();
			Long xcnabandina= serie.getNumpartnabanAsLong();
			String xtmargen=serie.getCodtipomarge();
			if (serie.getCodconvinter()!=null && serie.getCodconvinter()>0){
				TabLibeDAOService tabLibeDAOService = (TabLibeDAOService)fabricaDeServicios.getService("Ayuda.tabLibeService");
				Map<String,Object> paramsTablibe=new HashMap<String,Object>();
				paramsTablibe.put("tlib", "I");
				paramsTablibe.put("clib", serie.getCodconvinter());
				int countTablibe=tabLibeDAOService.count(paramsTablibe);
				if (countTablibe==0)
					grabaTelelog(listError,"00054", new Object[]{serie.getNumserie(), serie.getCodconvinter()});
			}
			boolean tienenalad=false;
			if (serie.getNumpartnalad()!=null && xcnaladisa>0)
				tienenalad=true;			

			
			ValVerilib valVerilib = fabricaDeServicios.getService("ValVerilib");
			//INICIO 20150207 - RIN08 - Si es de PECO-Amazonia ya no validamos porque esta en el servicio
			if (serie.getCodconvinter()!=null && serie.getCodconvinter()!=0 && (!tienePeco || tiene31o32)){ //Rin08
				Map<String,Object> mapRptaVerilib=valVerilib.verilib("I",String.valueOf(serie.getCodconvinter()),serie.getNumpartnandi()==null?null:String.valueOf(serie.getNumpartnandi()),serie.getCodpaisorige(),xcnaladisa==null?null:String.valueOf(xcnaladisa),xtmargen,"",xcnabandina==null?null:String.valueOf(xcnabandina),tienenalad,dua,serie,variablesIngreso, fechaReferencia);
				Boolean bVeriLib=(Boolean)mapRptaVerilib.get("valido");
				Boolean bExisteErrorCodilib=(Boolean)mapRptaVerilib.get("existeErrorCodilib");
				List<Map<String,String>> listErrorCodilib=(ArrayList<Map<String,String>>)mapRptaVerilib.get("listError");
				listError.addAll(listErrorCodilib);
				if (!bVeriLib && !bExisteErrorCodilib){
				}
			}



			//TDDI Regla 90 - Regla 92
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()>0){
				TabLibeDAOService tabLibeDAOService = (TabLibeDAOService)fabricaDeServicios.getService("Ayuda.tabLibeService");
				xcnaladisa=serie.getNumpartnaladAsInteger();//pruizcr rin13
				if (serie.getCodtratprefe()>0){
					Map<String,Object> paramsTablibe=new HashMap<String,Object>();
					paramsTablibe.put("tlib", "T");
					paramsTablibe.put("clib", serie.getCodtratprefe().toString());
					//HECHO SELECT * FROM tablibe where tlib='T' and clib= A_CADENA(SERIES.trat_prefe,4)
					//					int contTablibe=FormatoAServiceImpl.getInstance().getTablibeDAO().count(paramsTablibe);
					int contTablibe=tabLibeDAOService.count(paramsTablibe);
					// rpumacayo pase70					
					if  (contTablibe==0)
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("00053", new String[]{serie.getNumserie().toString(), serie.getCodtratprefe().toString()}));

				}
				if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
					Map<String,Object> mapRptaVerilib=valVerilib.verilib("T",String.valueOf(serie.getCodtratprefe()),serie.getNumpartnandi()==null?null:String.valueOf(serie.getNumpartnandi()),serie.getCodpaisorige(),xcnaladisa==null?null:String.valueOf(xcnaladisa),xtmargen,"",xcnabandina==null?null:String.valueOf(xcnabandina),tienenalad,dua,serie,variablesIngreso, fechaReferencia);
					Boolean verilibTPN=(Boolean)mapRptaVerilib.get("valido");
					Boolean bExisteErrorCodilib=(Boolean)mapRptaVerilib.get("existeErrorCodilib");
					List<Map<String,String>> listErrorCodilib=(ArrayList<Map<String,String>>)mapRptaVerilib.get("listError");
					listError.addAll(listErrorCodilib);
					if (!verilibTPN && !bExisteErrorCodilib){
					}
				}
				if (vigenciaLGA2004 && SunatStringUtils.include(String.valueOf(serie.getCodtratprefe()),new String[]{"  20","  21"}) && "10".equals(tipo_despa))
					grabaWarningTelelog(listError,"00380","TRAT_PREFE: ENVIADO "+serie.getCodtratprefe()+" DUA CONTIENE BULTOS VIGENTES NO PUEDE NUMERAR DESPACHO ANTICIPADO");
			}
			//INICIO RIN08 20150207 - RIN 08 - Si es de Amazonia no debe validar porque ya esta validado en el servicio
			if (serie.getCodliberatorio()!=null && serie.getCodliberatorio()>0 && !ConstantesDataCatalogo.COD_LIBERATORIO_AMAZONIA.equals(serie.getCodliberatorio().toString())){ //Rin08
				TabLibeDAOService tabLibeDAOService = (TabLibeDAOService)fabricaDeServicios.getService("Ayuda.tabLibeService");
				xcnaladisa=serie.getNumpartnaladAsInteger();//pruizcr rin13
				xcnabandina=serie.getNumpartnabanAsLong();
				Map<String,Object> paramsTablibe=new HashMap<String,Object>();
				paramsTablibe.put("tlib", "C");
				paramsTablibe.put("clib", serie.getCodliberatorio());				
				int contTablibe=tabLibeDAOService.count(paramsTablibe);
				if (contTablibe==0){
					grabaTelelog(listError,"00052",new Object[]{serie.getNumserie(),serie.getCodliberatorio().toString()});	
				}
				else if (serie.getCodliberatorio()!=null && serie.getCodliberatorio()!=0){
					Map<String,Object> mapRptaVerilib=valVerilib.verilib("C",String.valueOf(serie.getCodliberatorio()),serie.getNumpartnandi()==null?null:String.valueOf(serie.getNumpartnandi()),serie.getCodpaisorige(),xcnaladisa==null?null:String.valueOf(xcnaladisa),xtmargen,"",xcnabandina==null?null:String.valueOf(xcnabandina),tienenalad,dua,serie,variablesIngreso,fechaReferencia);
					Boolean verilibCodiliber=(Boolean)mapRptaVerilib.get("valido");
					Boolean bExisteErrorCodilib=(Boolean)mapRptaVerilib.get("existeErrorCodilib");
					List<Map<String,String>> listErrorCodilib=(ArrayList<Map<String,String>>)mapRptaVerilib.get("listError");
					listError.addAll(listErrorCodilib);
					if (!verilibCodiliber && !bExisteErrorCodilib){
					}
				}
				String mcdocigv;
				if (SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()),new String[]{"4201","4202"})){
					boolean tieneResolucionCONADIS = false;
					if (dua.getListOtrosDocSoporte() != null || !dua.getListOtrosDocSoporte().isEmpty()) {
						for(DatoOtroDocSoporte doc : dua.getListOtrosDocSoporte()) {
							if("S".equals(doc.getCodtipoproceso())&& "02".equals(doc.getCodtipodocasoc())){
								if(SunatStringUtils.isEmptyTrim(doc.getAnndocasoc().substring(0, 4))|| (doc.getAnndocasoc().substring(0, 4)).equals("0001")){
									grabaTelelog(listError,	"30653", "DUADOCAS.ANNO_RESOL - A�O DE RESOLUCION CONADIS NO HA SIDO ENVIADO :" );
								}
								if(SunatStringUtils.isEmptyTrim(doc.getNumdocasoc().toString())){
									grabaTelelog(listError, "30654", "DUADOCAS.NUME_RESOL -  NUMERO DE RESOLUCION CONADIS NO HA SIDO ENVIADO:");
									//	listError.add(grabaTelelog(listError,"30654"))) ;
								}
								tieneResolucionCONADIS = true;
							}	
						}
					}  

					if(tieneResolucionCONADIS==false){
						grabaTelelog(listError, "30652", "DUADOCAS.NUME_RESOL -  RESOLUCION CONADIS NO HA SIDO ENVIADA:");
						//listError.add(grabaTelelog(listError,"30652"));
					}

					if ("4201".equals(serie.getCodliberatorio().toString())) {
						for (DatoRegPrecedencia reg:serie.getListRegPrecedencia()){
							if("91".equals(reg.getCodregipre())){
								Participante partic=dua.getDeclarante();
								DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
								String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
								String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
								Map<String,Object> paramsCatRefruc=new HashMap<String,Object>();
								paramsCatRefruc.put("ctipoUso", "VIC");
								paramsCatRefruc.put("ctipodoc", codTipoDocumento);
								paramsCatRefruc.put("cdocumen", numeroDocumentoIdentidad);
								paramsCatRefruc.put("tlib", "C");
								paramsCatRefruc.put("clib", String.valueOf(serie.getCodliberatorio()));
								paramsCatRefruc.put("codiRegi", "10");
								paramsCatRefruc.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());

								CatRefRucDAO catRefRucCentralizadaDAO = fabricaDeServicios.getService("catRefRucCentralizadaDAO");
								int contCatRef=catRefRucCentralizadaDAO.count(paramsCatRefruc);
								if (contCatRef==0){
									grabaTelelog(listError,"30655",new Object[]{serie.getNumserie()});
								}
							}
						}
					}
				}		
				//TDDI Regla 96
				if (serie.getCodliberatorio()!=null && (serie.getCodliberatorio()>=2000 && serie.getCodliberatorio()<2007)|| (serie.getCodliberatorio()>=3806 && serie.getCodliberatorio()<=3810)
						|| (serie.getCodliberatorio()==3814) || (serie.getCodliberatorio()>4423 && serie.getCodliberatorio()<=4426)){
					DatoOtroDocSoporte doc=getDatoDocAsoc(dua.getListOtrosDocSoporte(), serie);
					if (doc!=null){
						if ("1".equals(doc.getCodtipoproceso()) && "2".equals(doc.getCodtipodocasoc())){
							if (doc.getAnndocasoc().compareTo((new FechaBean()).getAnho())<0)
								grabaWarningTelelog(listError,"01026","ANNO_DOCAS: A�o Resoluci�n Donaci�n � Envi�: "+doc.getAnndocasoc());
							if (doc.getFecdocasoc()==null)
								grabaWarningTelelog(listError, "1028", "NUME_DOCAS: Fecha de Resoluci�n Donaci�n � Envi�: "+doc.getFecdocasoc());
							if (doc.getCodentidademisora()==null || doc.getCodentidademisora()==0)
								grabaWarningTelelog(listError,"1029","ENTI_EMISO: Entidad Autoriza Donacion � Envi�: "+doc.getCodentidademisora());
						}
					}
				}
			}
			serie.setCodpaisorige(codpais); 
		}
		return listError;
	}

	/**
	 * Valida la aduana de destino.
	 * @deprecated Validar por uso de TAG_TODO
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@ServicioAnnot(tipo="V",codServicio=2362)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2362,numSecEjec=16,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> valAduanaDestino(Declaracion declaracion, Date fechaReferencia){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		String maduana=(String)mapVariables.get("maduana");
		String mtdepos=(String)mapVariables.get("mtdepos");
		String mcodi_alma=(String)mapVariables.get("mcodi_alma");
		String tipo_despa=(String)mapVariables.get("tipo_despa");
		String mcodi_regi=(String)mapVariables.get("mcodi_regi");
		String codadutrasal=dua.getOtraAduana()!=null?dua.getOtraAduana().getCodopadusal():null;


		//INI - FDJ 17.01.2011 - Modificacion de la validacion de la ley del amazonia, faltaba verificacion con ubigeo
		String nroRUCDuenoConsignatario="";
		PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
		String ubigeoDuenoConsignatario= preferenciaArancelariaService.consultarUbigeoImportadorPreferenciaArancelaria(
				dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), dua.getDeclarante().getNumeroDocumentoIdentidad());
		/*
		if("4".equals(dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat())){
			nroRUCDuenoConsignatario=dua.getDeclarante().getNumeroDocumentoIdentidad();
			if(nroRUCDuenoConsignatario!=null && !nroRUCDuenoConsignatario.isEmpty()){
//				DdpDAO ddpDAO =FormatoAServiceImpl.getInstance().getDdpDAO();
//				Map ddpruc = ddpDAO.findByPK(nroRUCDuenoConsignatario);
				Map ddpruc = ddpDAOService.findByPK(nroRUCDuenoConsignatario);
				ubigeoDuenoConsignatario=ddpruc!=null?(String)ddpruc.get("ddp_ubigeo"):"";
			}
		}
		 */

		/*RIN 08 - INICIO PECO-AMAZONIA Las validaciones asociadas a este beneficio estan en el servicio: pecoAmazoniaService*/
		//INI - ESM 30.06.2011 - validacion de aduana de destino PECO
		//		boolean tpi34=false;
		//		boolean tpi35=false;
		//		boolean tpi36=false;
		//		Integer cons34 = 34;
		//		Integer cons35 = 35;
		//		Integer cons36 = 36;
		//
		//		for(DatoSerie serie:dua.getListSeries()){
		//			if (cons34.equals(serie.getCodconvinter())){
		//				tpi34=true;
		//				break;
		//			}
		//		}
		//		for(DatoSerie serie:dua.getListSeries()){
		//			if (cons35.equals(serie.getCodconvinter())){
		//				tpi35=true;
		//				break;
		//			}
		//		}
		//		for(DatoSerie serie:dua.getListSeries()){
		//			if (cons36.equals(serie.getCodconvinter())){
		//				tpi36=true;
		//				break;
		//			}
		//		}
		//		
		//		if (tpi34){
		//			if (SunatStringUtils.isEmptyTrim(codadutrasal))
		//				grabaWarningTelelog(listError,"1076","CADUTRASAL No valido: Envio Aduana destino Ley Amazonia "+codadutrasal);
		//			else{if (!SunatStringUtils.include(codadutrasal, new String[]{"226"}))
		//				grabaWarningTelelog(listError,"30478","CODIGO DE ADUANA DE DESTINO INVALIDO PARA TPI DECLARADO");
		//				}
		//		}
		//		if (tpi35){
		//				if (SunatStringUtils.isEmptyTrim(codadutrasal))
		//					grabaWarningTelelog(listError,"1076","CADUTRASAL No valido: Envio Aduana destino Ley Amazonia "+codadutrasal);
		//				else{if (!SunatStringUtils.include(codadutrasal, new String[]{"217"}))
		//					grabaWarningTelelog(listError,"30478","CODIGO DE ADUANA DE DESTINO INVALIDO PARA TPI DECLARADO");
		//				}
		//		}
		//		if (tpi36){
		//					if (SunatStringUtils.isEmptyTrim(codadutrasal))
		//						grabaWarningTelelog(listError,"1076","CADUTRASAL No valido: Envio Aduana destino Ley Amazonia "+codadutrasal);
		//					else{if (!SunatStringUtils.include(codadutrasal, new String[]{"271"}))
		//						grabaWarningTelelog(listError,"30478","CODIGO DE ADUANA DE DESTINO INVALIDO PARA TPI DECLARADO");
		//				}
		//		}
		//					
		//		if(log.isDebugEnabled())log.debug("*********** LEY AMAZONIA RUC="+nroRUCDuenoConsignatario+", UBIGEO="+ubigeoDuenoConsignatario);
		//		//FIN
		/*RIN 08 - FIN*/

		for (DatoSerie serie: dua.getListSeries()){

			if (serie.getCodliberatorio() != null && serie.getCodliberatorio().intValue() == 4437 && "046".equals(maduana)) {

				grabaWarningTelelog(listError, "30480", "CODIGO LIBERATORIO NO PERMITIDO PARA ESTA ADUANA");

			}

		}


		/*RIN 08 - INICIO - PECO-AMAZONIA Las validaciones asociadas a este beneficio estan en el servicio: pecoAmazoniaService*/
		//TDDI Regla 100
		//		boolean codilibe4438=false;
		//		Integer cons4438 = 4438;
		//
		//		for(DatoSerie serie:dua.getListSeries()){
		//			if (cons4438.equals(serie.getCodliberatorio())){
		//				codilibe4438=true;
		//				HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
		//				paramsAdualib.put("cnab", serie.getNumpartnaban());
		//				paramsAdualib.put("clib", serie.getCodliberatorio());
		//				paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
		//				paramsAdualib.put("cadu", maduana);
		//				//Integer existeNabandin = FormatoAServiceImpl.getInstance().getAdualibDAO().count(paramsAdualib);
		//				Integer existeNabandin = ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).count(paramsAdualib);
		//				if (existeNabandin==0){
		//				//grabaWarningTelelog(listError, "30479", "NABANDINA NO SE ENCUENTRA EN ARANCEL - CONVENIO PERUANO COLOMBIANO, SERIE: "+serie.getNumserie());
		//					listError.add(getDUAError("30479",new Object []{serie.getNumserie()}));
		//
		//				}				
		//			}
		//		}
		//		//TDDI Regla 100 - Regla 101
		//		if (codilibe4438){
		//			if (!SunatStringUtils.include(maduana, new String[]{"118","235","046"}))
		//				grabaWarningTelelog(listError,"1077","CODI_ADUAN No Valido Aduana Ingreso "+maduana);
		//			//boolean bcadutrasal=false;
		//			if (SunatStringUtils.isEmptyTrim(codadutrasal))
		//				grabaWarningTelelog(listError,"1076","CADUTRASAL No valido: Envio Aduana destino Ley Amazonia "+codadutrasal);
		//			else{
		//				//if (!FormatoAServiceImpl.getInstance().isValidCatalogo("00", codadutrasal))
		//				boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codadutrasal,SunatDateUtils.getCurrentDate()));
		//				if (!validaCatalogo)
		//					grabaWarningTelelog(listError,"1075","CADUTRASAL No valido : Envi� Aduana destino Ley Amazonia-"+codadutrasal);
		//				if (vigenciaCriterio("1017",SunatDateUtils.getCurrentIntegerDate())>0){
		//					Map<String,Object> paramsCatRefpartidas=new HashMap<String,Object>();
		//					paramsCatRefpartidas.put("tipo_uso", "ULA");
		//					paramsCatRefpartidas.put("codi_aduan", codadutrasal);
		//					paramsCatRefpartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
		//					/*	HECHO Se verifica en la tabla CAT_REFPARTIDAS lo siguiente:
		//						Sql = "SELECT codi_Aduan FROM CAT_REFPARTIDASS WHERE TIPO_USO='ULA' AND CODI_ADUAN='"+ 
		//						CABECERA.cadutrasal+"' AND TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')) BETWEEN finivig AND ffinvig "*/
		//					//int countCatRefPartidas=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefpartidas);
		//					
		//					paramsCatRefpartidas.put("ayudaID", "CatRefpartidas");
		//					Integer countCatRefPartidas = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);
		//					
		//					
		//					if (countCatRefPartidas==0)
		//						grabaWarningTelelog(listError,"1076","CADUTRASAL No valido : Aduana destino Ley Amazonia-");
		//					else{
		//						/*TODO Se verifica en la tabla CAT_REFPARTIDAS lo siguiente:
		//							Sql = "SELECT codi_Aduan FROM CAT_REFPARTIDAS WHERE TIPO_USO='ULA' AND CODI_ADUAN='"+ CABECERA.cadutrasal+"' 
		//							AND "+ CABECERA.ubigeo+ " BETWEEN CNAN AND CNALADISA 
		//							AND TO_NUMBER( TO_CHAR (SYSDATE, 'YYYYMMDD')) BETWEEN finivig AND ffinvig "
		//*/						//dua.getDeclarante()
		//						//TODO Falta desubigeo en declarante
		//            //INI - FDJ 17.01.2011 - Modificacion de la validacion de la ley del amazonia, faltaba verificacion con ubigeo
		//						paramsCatRefpartidas=new HashMap<String,Object>();
		//						paramsCatRefpartidas.put("tipo_uso", "ULA");
		//						paramsCatRefpartidas.put("codi_aduan", codadutrasal);
		//						paramsCatRefpartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
		//						paramsCatRefpartidas.put("codUbigeo", ubigeoDuenoConsignatario);
		//						//countCatRefPartidas=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefpartidas);
		//						
		//						paramsCatRefpartidas.put("ayudaID", "CatRefpartidas");
		//						Integer countCatRefParts = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);
		//						
		//						
		//						if(countCatRefParts==0){
		//							grabaWarningTelelog(listError,"30057","UBIGEO NO VALIDO: Ubigeo Destino Ley Amazonia-"+ubigeoDuenoConsignatario);				
		//						}
		//					
		//						//FIN						
		//					}
		//				}else{
		//					if (!SunatStringUtils.include(codadutrasal, new String[]{"226", "217", "271", "280", "299", "181", "118", "055", "082", "190", "127"}))
		//						grabaWarningTelelog(listError,"1076","CADUTRASAL No valido: Aduana destino Ley Amazonia ");
		//				}
		//			}
		//		}

		//TDDO Regla 102
		/*RIN 08 - FIN */
		for(DatoSerie serie:dua.getListSeries()){
			if (serie.getCodliberatorio()!=null && serie.getCodliberatorio()==4437 && vigenciaCriterio("1033",SunatDateUtils.getCurrentIntegerDate())>0){
				Map<String,Object> paramsCatRefPartidas=new HashMap<String,Object>();
				paramsCatRefPartidas.put("tipo_uso", "ULA");
				paramsCatRefPartidas.put("codi_aduan", maduana);
				paramsCatRefPartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
				/* HECHO Sql = "SELECT codi_Aduan " +
					  "FROM CAT_REFPARTIDAS " +
					  "WHERE TIPO_USO='ULA' AND CODI_ADUAN='"+ maduana+"' " +
					  "AND TO_NUMBER (TO_CHAR (SYSDATE, 'YYYYMMDD')) BETWEEN finivig AND ffinvig"*/
				//int contCatRefPartidas=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefPartidas);

				paramsCatRefPartidas.put("ayudaID", "CatRefpartidas");
				Integer contCatRefPartidas = (Integer)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRefPartidas);


				if (contCatRefPartidas==0){
					grabaWarningTelelog(listError,"1077","CODI_ADUAN No valido: Aduana Ingreso "+maduana);
				}else{
					paramsCatRefPartidas=new HashMap<String,Object>();
					paramsCatRefPartidas.put("tipo_uso", "ULA");
					paramsCatRefPartidas.put("codi_aduan", maduana);
					//TODO CABECERA.ubigeo+ " BETWEEN CNAN AND CNALADISA " +
					paramsCatRefPartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
					//INI - FDJ 17.01.2011 - Modificacion de la validacion de la ley del amazonia, faltaba verificacion con ubigeo
					paramsCatRefPartidas.put("codUbigeo", ubigeoDuenoConsignatario);
					//FIN					
					/*HECHO Sql = "SELECT codi_Aduan " +
								"FROM CAT_REFPARTIDAS " +
								"WHERE TIPO_USO='ULA' AND CODI_ADUAN='"+ maduana +"' " +
								"AND "+ CABECERA.ubigeo+ " BETWEEN CNAN AND CNALADISA " +
							"AND TO_NUMBER (TO_CHAR (SYSDATE, 'YYYYMMDD')) BETWEEN finivig AND ffinvig"*/

					//contCatRefPartidas=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefPartidas);


					paramsCatRefPartidas.put("ayudaID", "CatRefpartidas");
					Integer contCatRefPartid = (Integer)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRefPartidas);

					if (contCatRefPartid==0){
						//TODO ubigeo en declarante
						grabaWarningTelelog(listError,"1076","UBIGEO NO VALIDO: Ubigeo Ley Amazonia");
					}
				}
			}
		}
		//TDDI Regla 103
		for(DatoSerie serie:dua.getListSeries()){

			DatoProducto product=serie.getProducto();
			String codpantidum=product!=null?product.getCodpantidum():null;
			BigDecimal cntunimedidaequi=product!=null?product.getCntunimedidaequi():null;
			String numitem=product!=null?product.getNumitem():null;

			String cprod=codpantidum;
			Map<String,Object> paramsTasadump=new HashMap<String,Object>();
			paramsTasadump.put("cnan", serie.getNumpartnandi());
			paramsTasadump.put("cpaiorige", serie.getCodpaisorige());
			paramsTasadump.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
			/*Hecho Sql = "select cprod " +
					"from TasaDump " +
					"where cnan = "+A_CADENA(SERIES.Part_Nandi,10)+" " +
					"and cpaiorige='"+ SERIES.Pais_Orige+"' and finitas<="+gc_fech_ingsi +" and ffintas>="+gc_fech_ingsi*/
			//int contTasadump=FormatoAServiceImpl.getInstance().getTasadumpDAO().count(paramsTasadump);
			int contTasadump=((TasadumpDAO)fabricaDeServicios.getService("tasadumpDAO")).count(paramsTasadump);
			if (contTasadump==1 && SunatStringUtils.isEmptyTrim(cprod))
				serie.getProducto().setCodpantidum("1");
		}
		//TDDI Regla 104
		for(DatoSerie serie:dua.getListSeries()){
			//verificar105
			if (serie.getCodtratprefe()!=null && 21==serie.getCodtratprefe() && (serie.getListRegPrecedencia()==null || serie.getListRegPrecedencia().isEmpty())){
				String numeSerie = serie.getNumserie().toString();
				grabaWarningTelelog(listError,"31914", numeSerie);
			}
			/*boolean bregiProce10=false;
			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
				String mregi_proce=regPrec.getCodregipre();

				if ("10".equals(mregi_proce)){
					bregiProce10=true;
					break;
				}
			}
			if (serie.getCodtratprefe()!=null && 21==serie.getCodtratprefe() &&  !bregiProce10){
				grabaWarningTelelog(listError,"0055","");
			}*/
		}

		/**
		 * r2bz Esta secci�n de regimenes de precedencia deber�a estar en ValNegocDuaregap y descentralizar esta clase que es demasiado grande
		 */

		for(DatoSerie serie:dua.getListSeries()){
			boolean tieneRepos=false;
			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
				if ("12".equals(regPrec.getCodregipre())){
					tieneRepos=true;
					break;
				}
			}
			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){

				/**
				 * r2bz Se pasa a la clase ValNegocDuaregapFormA.valDetRegPreImpoConsumo para centralizar las validaciones de Regimen de Precedencia 
				 * listError.addAll(validarRegimenPrecedencia(regPrec));
				 */

				if ("10".equals(regPrec.getCodregipre()) && !SunatStringUtils.include(String.valueOf(serie.getCodtratprefe()==null?0:serie.getCodtratprefe()),new String[]{"21","222"})){
					grabaWarningTelelog(listError,"5036","DUAREGAP.REGI_PROCE: ENVIADO "+regPrec.getCodregipre());
				}
				//jenciso pase 2014-039 se centraliza las validaciones del regimen de precedencia de CETICOS a la clase ValNegocDuaregapForm
				//				//JPL - ESM (RIN CETICOS)
				//				//RIN 1.1 Si el Regimen precendente es 91 y la modalidad es distinto de excepcional
				//				
				//				if ("91".equals(regPrec.getCodregipre()) &&
				//						(!"00".equals(declaracion.getDua().getCodmodalidad())))
				//				{
				//					grabaTelelog(listError,"30455","MODALIDAD DE DESPACHO NO CORRESPONDE PARA ACOGIMIENTO CON SOLICITUD DE TRASLADO CETICOS");	
				//				}
				//				//RIN 1.2 Se valida Aduana de Transmision
				//				//NSR: se agrega la comprobacion del Regimen Precedente 91
				//				if("91".equals(regPrec.getCodregipre()) && !SunatStringUtils.include(maduana, new String[]{"046","145","163"})){
				//					grabaTelelog(listError,"30497","ADUANA INCORRECTA PARA CETICOS");
				//				}
				//				
				//				//JPL: Si el Regimen Precedente de una serie es 91 de CETICOS 
				//				// y el Regimen actual es 10,20 o 21
				//				// y la modalidad es Excepcional 00
				//				//if ("91".equals(regPrec.getCodregipre()) && "10".equals(declaracion.getDua().getCodregimen())){
				//				if ("91".equals(regPrec.getCodregipre()) && 
				//						(("10".equals(declaracion.getDua().getCodregimen())) ||
				//								("20".equals(declaracion.getDua().getCodregimen())) ||
				//								("21".equals(declaracion.getDua().getCodregimen()))) &&
				//								"00".equals(declaracion.getDua().getCodmodalidad())    
				//				){
				//
				//					//JPL 20110216 
				//					//RIN 1.3  Valida Solicitud de Traslado
				//					//RIN 1.4 1.5 Si se realiza la declaracion con RUC y no tiene ventas Sucecivas
				//					//Se valida que el RUC declarado corresponda con el usuario de CETICO que realizo la solicitud
				//					//RIN 1.6 Se valida Manifiesto registrado en la DUA igual a la S/T
				//					//RIN 1.7 Se valida Fecha de Recepcion de la S/T
				//					String annmanif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
				//TrasladoCetico trasladoCetico = FormatoAServiceImpl.getInstance().getTrasladoCeticoDAO().selectByPrimaryKey(regPrec.getCodaduapre(),regPrec.getAnndeclpre() != null ? regPrec.getAnndeclpre().substring(0, 4) : "",regPrec.getNumdeclpre());
				//					if (trasladoCetico != null) {
				//						if((!trasladoCetico.getNumeManif().trim().equals(declaracion.getDua().getManifiesto().getNummanif())) ||
				//								((!trasladoCetico.getCaduManif().equals(declaracion.getDua().getManifiesto().getCodaduamanif())) ||
				//								((!trasladoCetico.getAnnoManif().equals(annmanif))))){
				//									grabaTelelog(listError, "30499","MANIFIESTO CONSIGNADO EN LA DUA NO CORRESPONDE AL MANIFIESTO DE LA SOLICITUD DE TRASLADO");
				//								}
				//						
				//						if(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals("4") && !this.tieneVentasSucecivas(serie,declaracion)){
				//							if (!declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(trasladoCetico.getNroDocumento())) {
				//								grabaTelelog(listError, "30456","RUC DECLARADO NO CORRESPONDE AL RUC DEL USUARIO DE CETICOS");
				//							}
				//						}
				//						
				//						if (trasladoCetico.getFrecepOfad()==0){
				//							grabaTelelog(listError,"5769","REG. PREC : SOLICITUD DE TRASLADO NO RECEPCIONADA EN CETICOS");
				//						}
				//					} else {
				//						grabaTelelog(listError,"5768","REG. PREC : SOLICITUD DE TRASLADO NO EXISTE");
				//						break;
				//					}
				//
				//					//RIN 1.8 Se valida por serie el registro del regimen precedente de la serie. 
				//					//RIN 1.9 Se valida documento de transporte declarado igual a la S/T
				//TrasladoSeriesCetico trasladoSeriesCetico=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().selectByPrimaryKey(regPrec.getCodaduapre(),regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"",Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '),regPrec.getNumdeclpre());
				//					if(trasladoSeriesCetico!=null)
				//					{
				//						if(trasladoSeriesCetico.getAduana()==null ||
				//								trasladoSeriesCetico.getAno()==null ||
				//								trasladoSeriesCetico.getCetico()==null ||
				//								trasladoSeriesCetico.getNumero()==null ||
				//								trasladoSeriesCetico.getNserie()==null)
				//						{
				//							grabaTelelog(listError,"30457","FALTA UN DATO DE LA SOLICITUD DE SERIE CETICO");		
				//						}
				//						
				//						DatoDocTransporte docTransporteSerie=getDocTransporte(declaracion.getDua(), serie);
				//						String numDocTransporte;
				//						numDocTransporte = "";
				//						if(docTransporteSerie != null){
				//							numDocTransporte = docTransporteSerie.getNumdoctransporte();
				//						if (!numDocTransporte.equals(trasladoSeriesCetico.getConoEmbar())) {
				//							grabaTelelog(listError, "30511","DOCUMENTO DE TRANSPORTE DECLARADO PARA LA SERIE NO CORRESPONDE CON EL REGISTRADO EN LA SERIE DE LA S/T");
				//						}
				//						}
				//						
				//						//RIN 1.10 Para los regimenes 20,21 valida que la fecha de numeracion,
				//						//sea anterior o igual a la fecha de fin de vigencia de la solic de traslado a CETICOS
				//						if(SunatDateUtils.getIntegerFromDate(fechaReferencia)>trasladoSeriesCetico.getFvencPlazo() &&
				//								(	    ("20".equals(declaracion.getDua().getCodregimen())) ||
				//										("21".equals(declaracion.getDua().getCodregimen()))))
				//						{
				//							grabaTelelog(listError,"30458","SOLICITUD DE TRASLADO A CETICOS VENCIDA");	
				//						}
				//					}else{
				//						grabaTelelog(listError,"30459","SERIE DE LA SOLICITUD DE TRASLADO A CETICOS NO EXISTE");
				//						break;
				//					}	
				//					
				//						//RIN 2.1 Implica que se ejecutaran las demas 8.2 en adelante.....
				//						if( serie.getNumpartnandi() == 8701200000L || SunatStringUtils.isStringInList ( SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4) , "8702,8703,8704,8705"))
				//						{														
				//							//RIN 2.2 Se valida clase de bulto VEI
				//							if (!"VEI".equals(serie.getCodclasbul())){
				//								grabaTelelog(listError,"30498","NO HA DECLARADO LA CLASE VEI PARA VEHICULOS CETICOS");
				//							}	
				//							DatoItem itemFB = ValItemFB.getItemCorrespondiente(serie, declaracion);
				//									
				//							//RIN 2.3 Se valida estado de la mercancia
				//							if(!SunatStringUtils.isStringInList(itemFB.getCodestamer(), "20,21,22,23,24,25,27,28") ){
				//								grabaTelelog(listError,"30477","ESTADO DE LA MERCANC�A NO ES USADA, NO CORRESPONDE A CETICOS");
				//							}
				//										//RIN 2.4 Regimen Precedente Nacionalizado Anteriormente con otra DUA.
				//										Map<String, String> mapParametros = new HashMap<String, String>();
				//										mapParametros.put("NUM_DECLARACIONPRE", regPrec.getNumdeclpre());
				//										mapParametros.put("ANN_PRESENPRE", regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"");
				//										mapParametros.put("COD_ADUANAPRE", regPrec.getCodaduapre());
				//										mapParametros.put("COD_REGIMENPRE", regPrec.getCodregipre());
				//										mapParametros.put("NUM_SECSERIEPRE", Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '));
				//
				//										List<Map<String, Object>> lstSeriesPrecedentes = FormatoBServiceImpl.getInstance().getDeclaracionService().getDocuPreceDuaDAO().select(new HashMap<String, Object>(mapParametros));
				//										if(!CollectionUtils.isEmpty(lstSeriesPrecedentes))
				//										{
				//											for(Map<String, Object> mapPrec:lstSeriesPrecedentes)
				//											{
				//												String strNumCorreDocAnt = ((BigDecimal)mapPrec.get("NUM_CORREDOC")).toString();
				//												String strNumSerieDocAnt = ((BigDecimal)mapPrec.get("NUM_SECSERIEPRE")).toString();
				//												String strIndel = SunatNumberUtils.toBigDecimal(mapPrec.get("IND_DEL")).toString();
				//												if(Integer.parseInt(strNumSerieDocAnt)==(regPrec.getNumserpre()!=null?regPrec.getNumserpre():0) && !strIndel.equals("1"))
				//												{
				//													Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
				//													paramsCabDeclara.put("numeroCorrelativo", strNumCorreDocAnt);
				//DUA numdeclaracion = (DUA) FormatoAServiceImpl.getInstance().getCabDeclaraDAO().findDUAByKeyMap(paramsCabDeclara);
				//
				//													String num_declaracion = SunatStringUtils.lpad(numdeclaracion.getNumdocumento(), 6, '0');
				//													Number annpresen = numdeclaracion.getAnnpresen();
				//													String codaduanaorden = numdeclaracion.getCodaduanaorden();
				//													
				//													if(declaracion.getNumdeclRef() != null){
				//														String num_declaref =SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0');
				//														if ((num_declaracion.equals(num_declaref)) && 
				//														    (codaduanaorden.equals(declaracion.getNumdeclRef().getCodaduana()) )&&
				//														    (annpresen.toString().equals(declaracion.getNumdeclRef().getAnnprese()))){
				//															break;
				//															}else {
				//																grabaTelelog(listError,"30460",new Object[]{strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion});
				//																break;													
				//															}															
				//													} else {
				//														grabaTelelog(listError,"30460",new Object[]{strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion});
				//														break;													
				//													}
				//											    }
				//										   }
				//										} else {
				//
				//											Map<String, Object> mapDuaRegPre=new HashMap<String,Object>();
				//											mapDuaRegPre.put("caduregpre", trasladoSeriesCetico.getAduana());
				//											mapDuaRegPre.put("fanoregpre", trasladoSeriesCetico.getAno());
				//											mapDuaRegPre.put("ndclregpre", trasladoSeriesCetico.getNumero());
				//											mapDuaRegPre.put("nserregpre", trasladoSeriesCetico.getNserie()); 
				//											mapDuaRegPre.put("codiregpre", regPrec.getCodregipre());
				//											
				//List<DuaRegPre> lsDuaRegPre=FormatoAServiceImpl.getInstance().getDuaRegPreDAO().findDuaRegPreByParams(mapDuaRegPre);
				//											
				//											if(!CollectionUtils.isEmpty(lsDuaRegPre)){						        				
				//												DuaRegPre duaregpre= lsDuaRegPre.get(0); 
				//						    	 				grabaTelelog(listError,"30460", new Object[]{trasladoSeriesCetico.getNserie(), duaregpre.getCodiAduan()+ "-" + duaregpre.getAnoPrese()+ "-" +duaregpre.getNumeCorre()});
				//						    					break;
				//											}	
				//										}
				//										
				//
				//										/*for (DatoRegPrecedencia regPrec1:serie.getListRegPrecedencia()){
				//									if (REGIMEN_PRECEDENTE.equals(regPrec.getCodregipre())){*/
				//										/* Duaregpre Si este ya ha sido declarado anteriormente en otra DUA, entonces se rechaza el env�o. 
				//										Esto se verifica en la tabla DUAREGPRE consultando por los campos: 
				//											codi_aduan,  codi_regi,  caduregpre,  fanoregpre, codiregpre, ndclregpre, nserregpre.*/ 
				//										/*	Map<String, Object> mapDuaRegPre=new HashMap<String,Object>();
				//										if (mapDuaRegPre!=null){
				//											String pcodi_aduan=(String)mapDuaRegPre.get("codi_aduan");
				//											String pcodi_regi=(String)mapDuaRegPre.get("codi_regi");
				//
				//											grabaTelelog(listError,"0724","En el marco del Apec, el CIT "+
				//																				regPrec.getCodaduapre()+"-"+regPrec.getAnndeclpre()+"-"+regPrec.getCodregipre()+"-"+regPrec.getNumdeclpre()+
				//																				" ya fue nacionalizado con Dua: "+pcodi_aduan+"-"+pcodi_regi+"-");	
				//										}
				//									}
				//								}*/
				//
				//
				//										/***************************************************************************
				//									  JPL - Estas Validaciones ya estaban programadas solo se reubican de acuerdo a lo dispuesto en el RIN
				//										 ***************************************************************************/
				//
				//					//HECHO Sql = "Select * from MRESTRI where codi_Regi='98' and tipodoc in ('1','4') and cnan = "+A_CADENA(SERIES.Part_Nandi,10)
				//					Map<String,Object> paramsMrestri=new HashMap<String,Object>();
				//					paramsMrestri.put("codi_regi", "98");
				//					paramsMrestri.put("tipodoc_in", " '1','4' ");
				//					paramsMrestri.put("cnan", serie.getNumpartnandi());
				//					/*KIB:cambiado con Elsa del catrefpartidas al Mrestri 24/02/2010
				//					 * int contMrestri=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsMrestri);
				//					*/
				//
				//					int contMrestri=FormatoAServiceImpl.getInstance().getMrestriDAO().count(paramsMrestri);
				//										//contMrestri = 1; System.err.println("Mas datos de regimen de precedencia: " + serie.getCodclasbul() + " " + contMrestri); //OJO RETIRAR LUEGO
				//					if (contMrestri>0 && "VEI".equals(serie.getCodclasbul()) ){
				//						
				//TrasladoSeriesCetico trasladoSeriesCetico1=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().selectByPrimaryKey(regPrec.getCodaduapre(),regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"",Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '),regPrec.getNumdeclpre());
				//						/* HECHO Sql = "Select freci_Ceti, chasis, mercancia,revisa1 " +
				//								"from TRASLADO_SERIES_CETICO where aduana='"+mcadurp+"' " +
				//										"and ano='"+mfanorp+"' and numero='" + PADL(ALLT(mndclrp),6,'0') + "' " +
				//												"and nserie = '"+PADL(ALLT(A_CADENA(mserirp)),4,' ')+"'"*/
				//											//System.err.println("Traslado ceticos serie: " + trasladoSeriesCetico);
				//											//trasladoSeriesCetico = new TrasladoSeriesCetico(); //OJO RETIRAR LUEGO
				//											//trasladoSeriesCetico.setFreciCeti(1); trasladoSeriesCetico.setChasis(" "); trasladoSeriesCetico.setMercancia(" ");//OJO RETIRAR LUEGO
				//											//if (trasladoSeriesCetico1==null){
				//											//grabaTelelog(listError,"5768","REG. PREC : SOLICITUD DE TRASLADO NO EXISTE");
				//											//}else{
				//											//RIN 2.5 Valida Fecha de Recepcion Cetico
				//											//if (trasladoSeriesCetico1.getFreciCeti()==0)
				//											//	grabaTelelog(listError,"5769","REG. PREC : SOLICITUD DE TRASLADO NO RECEPCIONADA EN CETICOS");
				//							//TODO TDDI Regla 107 
				//							List<DatoItem> listItemsSerie=FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie);
				//							for(DatoItem item:listItemsSerie){
				//								DatoDescrMinima descrMinimaClasVari=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "04");
				//												if (descrMinimaClasVari!=null){
				//								String clasVari=descrMinimaClasVari.getValtipdescri();
				//								String chasis="";
				//								//validar que sea diferente de nullo y mayor de 6 clasVari
				//								//error 1260
				//									if (!SunatStringUtils.isEmpty(clasVari) && clasVari.length()>6){
				//										int end=clasVari.length()>=27?26:clasVari.length();
				//										chasis=clasVari.substring(6,end).trim();
				//}else{
				//										grabaTelelog(listError,"01260","");
				//									}
				//								if (!SunatStringUtils.isEmptyTrim(chasis)){
				//									String matco=serie.getDesmatecomp()==null?"":serie.getDesmatecomp();
				//									String fopre=serie.getDesformapres()==null?"":serie.getDesformapres();
				//														//RIN 2.8 Se valida chasis del vehiculo
				//									if (matco.indexOf(chasis)==-1 && fopre.indexOf(chasis)==-1)
				//										grabaTelelog(listError,"30371",new Object[]{chasis,serie.getNumserie()});//"CHASIS NO COINCIDE ENTRE FORMATO B Y EN SERIE DE DUA");//30371-05777
				//									else{
				//															String ceticoChasis=trasladoSeriesCetico1.getChasis();
				//															String ceticoMercancia=trasladoSeriesCetico1.getMercancia();
				//										if ((SunatStringUtils.isEmpty(ceticoChasis) || ceticoChasis.indexOf(chasis)==-1) && (SunatStringUtils.isEmpty(ceticoMercancia) || ceticoMercancia.indexOf(chasis)==-1)){
				//											String nsoli="";
				//											Map<String,Object> paramsChasis=new HashMap<String,Object>();
				//											paramsChasis.put("chasis", chasis.toUpperCase());
				//List<TrasladoSeriesCetico> listExistect=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().findByParams(paramsChasis);
				//											if (listExistect==null || listExistect.isEmpty()){
				//												paramsChasis=new HashMap<String,Object>();
				//												paramsChasis.put("mercanciaLike", chasis.toUpperCase());
				//listExistect=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().findByParams(paramsChasis);
				//												
				//												if (listExistect!=null && !listExistect.isEmpty()){
				//													TrasladoSeriesCetico existect=listExistect.get(0);
				//													nsoli=" , CHASIS ES DE S/T: "+existect.getAduana()+" - "+existect.getAno()+" - "+existect.getNumero()+" - "+existect.getNserie();
				//												}
				//											}
				//																
				//											grabaTelelog(listError,"30372",new Object[]{chasis,nsoli});//05780-30372 cambiarlo
				//										}
				//									}
				//								}
				//													//RIN 2.7 Se valida Revisa1
				//								if (vigenciaCriterio("1021",SunatDateUtils.getCurrentIntegerDate())>0){
				//									DatoDescrMinima descrMinimaDesCom3=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "09");
				//									if (descrMinimaDesCom3!=null){
				//										String descCom3=descrMinimaDesCom3.getValtipdescri();
				//										String revisa1="";
				//										if (!SunatStringUtils.isEmpty(descCom3) && descCom3.length()>25){
				//											int end=descCom3.length()>=41?40:descCom3.length();
				//											revisa1=descCom3.substring(24,end);
				//										}
				//
				//															//System.err.println("CODIGO COMPARACION CETICO ALCANZADO"); // OJO RETIRAR LUEGO
				////										if (!trasladoSeriesCetico.getRevisa1().equals(revisa1)){
				//															// Inicio Cambio JMCR 27-12-2010
				//															//RIN 8.4
				//															if (revisa1 != null && trasladoSeriesCetico1.getRevisa1() != null && 
				//																	!revisa1.trim().equals(trasladoSeriesCetico1.getRevisa1().trim())){
				//																//if (!revisa1.equals(trasladoSeriesCetico.getRevisa1())){
				//																// Fin Cambio JMCR 27-12-2010	
				//											grabaTelelog(listError,"30373",new Object[]{revisa1});//05787-30373
				//										}
				//									}
				//								}
				////										item
				//												}else{
				//													grabaTelelog(listError,"01260","");
				//												}
				//											}
				//										}
				//										
				//										//RIN 2.7 Se valida pesos y bultos declarados contra los de la S/T
				//										BigDecimal absoluteDiferenceBultoserie = SunatNumberUtils.absoluteDiference(new BigDecimal (trasladoSeriesCetico.getBulto()), serie.getCntbultos());
				//										if(!SunatNumberUtils.isEqualToZero(absoluteDiferenceBultoserie))
				//										{
				//											grabaTelelog(listError,"30469","CANTIDAD DE BULTOS DE LA SERIE DE LA S/T NO COINCIDE CON CANTIDAD DE BULTOS DE LA SERIE");
				//										}
				//										
				//										BigDecimal absoluteDiferencePesoserie = SunatNumberUtils.absoluteDiference(trasladoSeriesCetico.getPeso(), serie.getCntpesobruto());
				//										if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferencePesoserie, new BigDecimal(0.5)))
				//										{
				//											grabaTelelog(listError,"30470","PESO DE LA SERIE DE LA S/T NO COINCIDE CON PESO DE LA SERIE");
				//										}
				//										
				//										//Validaciones Hoja de Gastos
				//										//RIN 2.9.1
				//										List<DatoVehiculo> listVeh=serie.getListVehiculos();
				//										if (listVeh!=null && !listVeh.isEmpty()){
				//										for (DatoVehiculo vehiculo : serie.getListVehiculos()) {
				//											boolean booTienePublicacion = false;
				//											if(vehiculo.getNomlibro()!=null){
				//												
				//												if (vehiculo.getNomlibro().equals("SIN PUBLICACION") &&
				//														(vehiculo.getCodejempl())==null &&
				//														(vehiculo.getNumpagin())==null &&
				//														(vehiculo.getNumitemb())==null &&
				//														(vehiculo.getAnnmespubli())==null &&
				//														(vehiculo.getNumfactconve())==null) {
				//														booTienePublicacion = false;
				//												} else {
				//													if ((vehiculo.getNomlibro()) != null && (vehiculo.getAnnmespubli()) != null	&& !vehiculo.getNomlibro().equals("SIN PUBLICACION")) {
				//														booTienePublicacion = true;
				//													} else {// Validacion RIN 2.9.2
				//														grabaTelelog(listError, "30500","DATOS DE LA PUBLICACION IMCOMPLETOS - EJEMPLAR Y FECHA DE LA PUBLICACION");
				//														booTienePublicacion = true;
				//													}
				//							}
				//											//Validacion RIN 2.9.3 2.9.4
				//											//if((vehiculo.getNomlibro())!=null)
				//											//{booTienePublicacion = true;}
				//											
				//											}else { 
				//												grabaTelelog(listError,"30514","SI NO DISPONE DE PUBLICACION DEBERA CONSIGNAR: SIN PUBLICACION,  EN LA CASILLA 2.1");
				//											}
				//											
				//											DatoMontoGastoUtil monGastoUtil = ConvertirListaAMontoGastoUtil(vehiculo.getListMontoGastos());
				//											DAV dav = getDAVCorrespondiente(serie,declaracion);
				//											DatoFactura factura = getFacturaCorrespondiente(serie,declaracion);
				//
				//											if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobfact().getValmonto()) &&
				//													SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMflete().getValmonto()) &&
				//													SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMseguro().getValmonto())  &&
				//													SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtasa().getValmonto()) &&
				//													SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobcalc().getValmonto()) &&
				//													SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMvaduan().getValmonto()))
				//											{
				//												//Si Tiene una publicacion de gastos
				//												if(booTienePublicacion)
				//												{													
				//													//RIN 2.9.5
				//													if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpublica().getValmonto()))!=true)
				//													{
				//														grabaTelelog(listError,"30461","NO HA INGRESADO MONTO CONSIGNADO EN LA PUBLICACION");	
				//													}											
				//													//RIN 2.9.6
				//													if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto()))!=true)
				//													{
				//														grabaTelelog(listError,"30501","NO HA INGRESADO MONTO POR PUBLICACION MAS AJUSTES");	
				//													}
				//													//RIN 2.9.7
				//													BigDecimal bgSumatoriaOpcionales = new BigDecimal(0);
				//													bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMroof().getValmonto());
				//													bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMequicd().getValmonto());
				//													bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMnvcd().getValmonto());
				//													bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMnvdvd().getValmonto());
				//													bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMotpub().getValmonto());
				//
				//													BigDecimal bgAbsoluteDiffOpcionales = SunatNumberUtils.absoluteDiference(monGastoUtil.getMopcpu().getValmonto(), bgSumatoriaOpcionales);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(bgAbsoluteDiffOpcionales, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30462","MONTO US$ AJUSTE POR OPCIONALES SEG�N PUBLICACI�N NO COINCIDE.");	
				//													}
				//													//RIN 2.9.8
				//													BigDecimal bgSumatoriaOpcAjustes = new BigDecimal(0);
				//													bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMpublica().getValmonto());
				//													bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMtrans().getValmonto());
				//													bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMopcpu().getValmonto());
				//
				//													BigDecimal bgAbsoluteDiffOpcAjustes = SunatNumberUtils.absoluteDiference(monGastoUtil.getMpuaju().getValmonto(), bgSumatoriaOpcAjustes);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(bgAbsoluteDiffOpcAjustes, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30463","MONTO US$ RESULTANTE DE LA PUBLICACI�N INCLUIDO AJUSTES NO COINCIDE");	
				//													}
				//													//RIN 2.9.9										
				//													BigDecimal absoluteDiferenceFOB = SunatNumberUtils.absoluteDiference(monGastoUtil.getMpuaju().getValmonto(), FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico());
				//
				//													if(     SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto()) &&
				//															!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceFOB, new BigDecimal(1)) )		
				//													{	grabaTelelog(listError,"30464","MONTO EN US$ RESULTANTE DE LA PUBLICACI�N INCLUIDO AJUSTES NO COINCIDE CON EL FORMATO B");}
				//
				//													//RIN 2.9.10
				//													BigDecimal bgSumatoriaFobParciales = new BigDecimal(0);
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMpuaju().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtasa().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtranex().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtranin().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtrasla().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMuventa().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMotrost().getValmonto());
				//													//Campos de la Casilla 5
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvtv().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvdvdtv().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMaire().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtapiz().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMccolor().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMaro().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMctrans().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMadapta().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMotros().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMroofa().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMequicda().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvcda().getValmonto());
				//													bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvdvda().getValmonto());
				//
				//													BigDecimal absoluteDiferenceSumFOBPar = SunatNumberUtils.absoluteDiference(monGastoUtil.getMfobcalc().getValmonto(), bgSumatoriaFobParciales);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumFOBPar, new BigDecimal(1)))
				//													{grabaTelelog(listError,"30465","TOTAL US$ VALOR FOB CALCULADO NO COINCIDE");}
				//
				//													//RIN 2.9.11
				//													BigDecimal bgMontoTotalAdicional = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MASDSCTO).getMtologistico();
				//
				//													BigDecimal bgSumatoriaGastoCetico = new BigDecimal(0);
				//													//Campos de la Casilla 4
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtasa().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtranex().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtranin().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtrasla().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMuventa().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMotrost().getValmonto());
				//													//Campos de la Casilla 5
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvtv().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvdvdtv().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMaire().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtapiz().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMccolor().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMaro().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMctrans().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMadapta().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMotros().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMroofa().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMequicda().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvcda().getValmonto());
				//													bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvdvda().getValmonto());
				//
				//													BigDecimal absoluteDiferenceSumGasCetico = SunatNumberUtils.absoluteDiference(bgMontoTotalAdicional, bgSumatoriaGastoCetico);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumGasCetico, new BigDecimal(1)))
				//													{grabaTelelog(listError,"30466","GASTOS DE CETICOS NO COINCIDE CON FORMATO B");}
				//
				//												}
				//												//Si no tiene una publicacion de gastos
				//												else
				//												{ //RIN 2.9.12
				//													if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpublica().getValmonto()) ||
				//															SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtrans().getValmonto()) ||
				//															SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMopcpu().getValmonto()) ||
				//															SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto()))
				//													{
				//														grabaTelelog(listError,"30502","SI NO CUENTA CON LA PUBLICACION NO DEBE CONSIGNAR INFORMACION EN LAS CASILLAS DATOS DE LA PUBLICACION NI EN LAS CASILLAS 3.1 a 3.4.");
				//													}else  
				//													{											
				//														//RIN 2.9.13
				//														List<DatoItem> listItemsSerie=FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie);
				//														for(DatoItem item:listItemsSerie){
				//														DatoDescrMinima descrMinimaDesCom3=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "09");
				//														BigDecimal bgRepB = new BigDecimal(0);
				//														if (descrMinimaDesCom3!=null){
				//															String descCom3=descrMinimaDesCom3.getValtipdescri();
				//															String repB="";
				//															if (!SunatStringUtils.isEmpty(descCom3) && descCom3.length()>47){
				//																int end=descCom3.length()>=53?52:descCom3.length();
				//																repB=descCom3.substring(46,end).trim();																
				//																try{
				//																	bgRepB = new BigDecimal (repB);
				//																}catch(NumberFormatException e){
				//																	grabaTelelog(listError,"30512","REGISTRAR GASTOS POR REPARACION Pos:47-52 DESCOM3");
				//																}
				//															}else{
				//																grabaTelelog(listError,"30512","REGISTRAR GASTOS POR REPARACION Pos:47-52 DESCOM3");
				//															}
				//														}
				//														BigDecimal bgPrecioRepB = new BigDecimal(0);
				//														BigDecimal bgPreciofactB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();
				//														bgPrecioRepB = SunatNumberUtils.sum(bgPreciofactB, bgRepB);
				//														BigDecimal bgPrecioGastHoja = new BigDecimal(0);
				//														bgPrecioGastHoja = SunatNumberUtils.sum(bgPrecioGastHoja, monGastoUtil.getMfobfact().getValmonto());
				//														bgPrecioGastHoja = SunatNumberUtils.sum(bgPrecioGastHoja, monGastoUtil.getMrepara().getValmonto());
				//
				//														BigDecimal absoluteDiferenceSumPrecFact = SunatNumberUtils.absoluteDiference(bgPrecioRepB, bgPrecioGastHoja);
				//
				//														if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumPrecFact, new BigDecimal(1)))
				//														{grabaTelelog(listError,"30467","VALOR DE FACTURA + GASTOS DE REPARACI�N NO COINCIDE CON EL MONTO DEL FORMATO B (BDUADET2 O ARCHIVO EQUIVALENTE");}
				//														}
				//														//RIN 2.9.14
				//														BigDecimal bgMontoFOBFactcom = monGastoUtil.getMfobfact().getValmonto();
				//														BigDecimal bgPreciofactB2 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();
				//
				//														if(SunatNumberUtils.isGreaterOrEqualsThanZero(bgMontoFOBFactcom) &&
				//																!SunatNumberUtils.isEqual(bgMontoFOBFactcom, bgPreciofactB2))
				//														{
				//															grabaTelelog(listError,"30468","MONTO US$ EN FACTURA DE EXPORTACI�N NO COINCIDE CON EL DEL FORMATO B");
				//														}
				//														//RIN 2.9.15
				//														BigDecimal bgFobCalculado = monGastoUtil.getMfobcalc().getValmonto();
				//														BigDecimal bgFobParciales = new BigDecimal(0);
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMfobfact().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMrepara().getValmonto());
				//														//Casillas 4.1 - 4.7
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMctimon().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtasa().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtranex().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtranin().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtrasla().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMuventa().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMotrost().getValmonto());
				//														//Casillas 5
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvtv().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvdvdtv().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMaire().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtapiz().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMccolor().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMaro().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMctrans().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMadapta().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMotros().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMroofa().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMequicda().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvcda().getValmonto());
				//														bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvdvda().getValmonto());
				//
				//														BigDecimal absoluteDiferenceParcCalc = SunatNumberUtils.absoluteDiference(bgFobCalculado, bgFobParciales);
				//
				//														if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceParcCalc, new BigDecimal(1)))
				//														{
				//															grabaTelelog(listError,"30465","TOTAL US$ VALOR FOB CALCULADO NO COINCIDE");
				//														}
				//														//RIN 2.9.16
				//														BigDecimal bgOtrasAdic = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MASDSCTO).getMtologistico();
				//														BigDecimal bgFobParciales2 = new BigDecimal(0);
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMrepara().getValmonto());
				//														//Casillas 4.1 - 4.7
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMctimon().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtasa().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtranex().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtranin().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtrasla().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMuventa().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMotrost().getValmonto());
				//														//Casillas 5
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvtv().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvdvdtv().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMaire().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtapiz().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMccolor().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMaro().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMctrans().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMadapta().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMotros().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMroofa().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMequicda().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvcda().getValmonto());
				//														bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvdvda().getValmonto());
				//
				//														BigDecimal absoluteDiferenceParcCalc2 = SunatNumberUtils.absoluteDiference(bgOtrasAdic, bgFobParciales2);
				//
				//														if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceParcCalc2, new BigDecimal(1)))
				//														{
				//															grabaTelelog(listError,"30466","GASTOS DE CETICOS NO COINCIDEN CON FORMATO B");
				//							}
				//						}
				//					}
				//												//Si tiene o no publicacion de gastos
				//												//RIN 2.9.17
				//												if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMrepara().getValmonto()) ||
				//														SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMctimon().getValmonto()))
				//												{
				//													//RIN 2.9.19
				//													BigDecimal absoluteDiferenceFOBFA = SunatNumberUtils.absoluteDiference(monGastoUtil.getMfobcalc().getValmonto(), serie.getMtofobdol());
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceFOBFA, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30471","FOB CALCULADO NO COINCIDE CON EL DEL FORMATO A");
				//													}
				//													//RIN 2.9.20
				//													BigDecimal bgValorAduana = monGastoUtil.getMvaduan().getValmonto();
				//													BigDecimal bgFobFletSeg = new BigDecimal(0); 
				//													bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMfobcalc().getValmonto());
				//													bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMflete().getValmonto());
				//													bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMseguro().getValmonto());
				//
				//													BigDecimal absoluteDiferencevalAduana = SunatNumberUtils.absoluteDiference(bgValorAduana, bgFobFletSeg);
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferencevalAduana, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30472","TOTAL US$ VALOR EN ADUANA NO COINCIDE");
				//						}
				//													//RIN 2.9.21 - RIN 2.10.22
				//													BigDecimal bgSegHojaGastos = monGastoUtil.getMseguro().getValmonto();
				//													BigDecimal bgSegFormatoB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_SEGUR).getMtologistico();
				//													BigDecimal bgSegFormatoA = serie.getMtosegdol();
				//
				//													BigDecimal absoluteDiferHGB =  SunatNumberUtils.absoluteDiference(bgSegHojaGastos, bgSegFormatoB);
				//													BigDecimal absoluteDiferHGA =  SunatNumberUtils.absoluteDiference(bgSegHojaGastos, bgSegFormatoA);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferHGB, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30473","SEGURO DE HOJA DE GASTOS NO COINCIDE CON EL FORMATO B");
				//													}
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferHGA, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30474","SEGURO DE HOJA DE GASTOS NO COINCIDE CON SERIE FORMATO A");
				//				}
				//													//RIN 2.9.23 2.9.24
				//													BigDecimal bgFleteHojaGastos = monGastoUtil.getMflete().getValmonto();
				//													BigDecimal bgFleteFormatoB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_TOTGASTRAN).getMtologistico();
				//													BigDecimal bgFleteFormatoA = serie.getMtofledol();
				//
				//													BigDecimal absoluteDiferFleteHGB =  SunatNumberUtils.absoluteDiference(bgFleteHojaGastos, bgFleteFormatoB);
				//													BigDecimal absoluteDiferFleteHGA =  SunatNumberUtils.absoluteDiference(bgFleteHojaGastos, bgFleteFormatoA);
				//
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferFleteHGB, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30475","FLETE DE HOJA DE GASTOS NO COINCIDE CON EL FORMATO B");
				//													}
				//													//RIN 2.9.25
				//													if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferFleteHGA, new BigDecimal(1)))
				//													{
				//														grabaTelelog(listError,"30476","FLETE DE HOJA DE GASTOS NO COINCIDE CON SERIE FORMATO A");
				//													}
				//												}
				//												else 
				//												{
				//													grabaTelelog(listError,"30504","NO HA ENVIADO MONTO POR REPARACION O MONTO POR CAMBIO DE TIMON");
				//												}
				//
				//											}else{
				//												//RIN 2.9.16
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobfact().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30505","NO HA INGRESADO MONTO EN US$ CONSIGNADO EN LA FACTURA COMERCIAL");	
				//												}											
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMflete().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30506","NO HA INGRESADO MONTO EN US$ POR TRANSPORTE INTERNACIONAL");	
				//												}
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMseguro().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30507","NO HA INGRESADO MONTO EN US$ POR SEGURO");	
				//					}
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtasa().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30508","NO HA INGRESADO MONTO EN US$ POR TASA");	
				//												}
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobcalc().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30509","NO HA INGRESADO MONTO FOB EN US$ CALCULADO");	
				//												}
				//												if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMvaduan().getValmonto()))!=true)
				//												{
				//													grabaTelelog(listError,"30510","NO HA INGRESADO MONTO DE VALOR EN ADUANA");	
				//												}
				//											}
				//				}
				//									}else
				//								{
				//									grabaTelelog(listError,"30513","NO HA TRANSMITIDO LA HOJA DE GASTOS DE VEHICULOS USADOS");	
				//							}
				//						}					
				//					//FIN JPL 20110216
				//				}


				if ("S5".equals(regPrec.getCodregipre()) && !SunatStringUtils.include(mcodi_alma, new String[]{"3124","3139","9008","9012","3143","9998"}))
					grabaTelelog(listError,"30362",new Object[]{regPrec.getCodregipre(),mcodi_alma});


				if ((declaracion.getDua().getCodregimen().equals("10") && SunatStringUtils.include(regPrec.getCodregipre(),new String[]{"20","21","50"}) )//gmontoya Pase 490
						|| (declaracion.getDua().getCodregimen().equals("70") &&  SunatStringUtils.include(regPrec.getCodregipre(),new String[]{"20","21"}) )){{
							grabaWarningTelelog(listError,"0055","REGI_PROCE invalido");
						}                 

				}

				//TODO: NSR: Se comenta por estar mal implementado
				//				if (SunatStringUtils.include(tipo_despa, new String[]{"10","01","02","11"}) 
				//				&& SunatStringUtils.include(regPrec.getCodregipre(), new String[]{"10","12","50","51"}))
				//				grabaWarningTelelog(listError,"0041","TIPO DESPA DUAREGAP "+tipo_despa);
				//Se cambia por el siguiente codigo
				if ("10".equals(mcodi_regi) && 
						SunatStringUtils.include(tipo_despa, new String[]{"10","01","02","11"}) &&
						!SunatStringUtils.include(regPrec.getCodregipre(), new String[]{"10","12","50","51"})){
					grabaWarningTelelog(listError,"0041","TIPO DESPA DUAREGAP "+tipo_despa);
				}
				if ("S".equals(mtdepos) && "70".equals(regPrec.getCodregipre()) && "10".equals(mcodi_regi)){
					if (!"8".equals(dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()) && serie.getNumpartnandi()==9804000000L){
						if (maduana.equals(regPrec.getCodaduapre())){
							Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
							paramsCabDeclara.put("codigoAduana", regPrec.getCodaduapre());
							paramsCabDeclara.put("annoPresentacion", regPrec.getAnndeclpre());
							paramsCabDeclara.put("codigoRegimen", regPrec.getCodregipre());
							paramsCabDeclara.put("numeroDeclaracion", regPrec.getNumdeclpre());
							//Hecho Sql = "select nume_corre from POLIZAD where codi_aduan='"+ REG_PRE.caduregpre + "' 
							//and ano_prese='"+ DERECHA(REG_PRE.fanoregpre,2)+"' AND nume_corre='"+ REG_PRE.ndclregpre + "'"
							//boolean esTraslado=FormatoAServiceImpl.getInstance().getCabDeclaraDAO().findDUAByKeyMap(paramsCabDeclara)!=null;
							boolean esTraslado=((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDUAByKeyMap(paramsCabDeclara)!=null;
							if (regPrec.getAnndeclpre().compareTo("1993")>=0 || esTraslado){
								//Sql = "select part_nandi from SERIESD where codi_aduan='"+ REG_PRE.caduregpre + 
								//"' and ano_prese='"+ DERECHA(REG_PRE.fanoregpre,2)+"' AND nume_corre='"+ REG_PRE.ndclregpre + 
								//"' and nume_serie='"+ A_CADENA(REG_PRE.nume_serpr,4)+ "' and seri_elim <>'S'"
								Map<String,Object> mapSeriesD=new HashMap<String,Object>();
								if (mapSeriesD==null){
									grabaWarningTelelog(listError,"0126","PART NANDI ENVIADO: "+mapSeriesD.get("part_nandi"));
								}else{
									//TODO consultar proc almacenado Fntg_CorrelPartida
								}
							}
						}
					}
				}
				//verificar105
				//				if("10".equals(mcodi_regi)){ 
				//					if ("10".equals(regPrec.getCodregipre()) 
				//							&& SunatNumberUtils.isLessThanParam(SunatNumberUtils.toInteger(mcodi_alma), new Integer(3000))   ){
				//						
				//							grabaWarningTelelog(listError, "0025", "CODI_ALMA DUAREGAP : ENVIADO-"+mcodi_alma);
				//					}
				//					
				//					if ("70".equals(regPrec.getCodregipre()) 
				//							&& SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.toInteger(mcodi_alma), new Integer(3000)) 
				//							&& SunatNumberUtils.isLessThanParam(SunatNumberUtils.toInteger(mcodi_alma), new Integer(3999))
				//							&& !"3124".equals(mcodi_alma)){	
				//							
				//						grabaWarningTelelog(listError, "0025", "CODI_ALMA DUAREGAP : ENVIADO-"+mcodi_alma);
				//					}				
				//				}
				//				
				//				 // corregido por el bug 1073 HOSORIO -INICIO
				//				if("10".equals(mcodi_regi)){ // solo aplica para reg 10 bug 1026 Kib
				//					if (("12".equals(regPrec.getCodregipre()) && !SunatStringUtils.include(String.valueOf(serie.getCodtratprefe()), new String[]{"93","183"}))|| 
				//						(!"12".equals(regPrec.getCodregipre()) && SunatStringUtils.include(String.valueOf(serie.getCodtratprefe()), new String[]{"93","183"}) && !tieneRepos)){
				//						grabaWarningTelelog(listError, "0171","REGI_PROCE - TRAT_PREFE DE LA SERIE ENVIADOS:"+regPrec.getCodregipre()+"-"+serie.getCodtratprefe());
				//					}
				//				}

				// corregido por el bug 1073 HOSORIO -FIN
				Date mFechAbaLeg;
				String mabanLegal="";
				if (SunatStringUtils.include(regPrec.getCodregipre(), new String[]{"18","70","80","24"})){
					List<String> listFeriados=new ArrayList<String>();
					mFechAbaLeg=SunatDateUtils.addUtilDay(regPrec.getFecvencpre(), 1, listFeriados);
				}else{
					if (!SunatStringUtils.include(regPrec.getCodregipre(), new String[]{"90","91"})){
						List<String> listFeriados=new ArrayList<String>();
						mFechAbaLeg=SunatDateUtils.addUtilDay(regPrec.getFecvencpre(), 30,listFeriados);
					}else
						mFechAbaLeg=regPrec.getFecvencpre();
				}
				if (SunatDateUtils.compareDate(SunatDateUtils.getCurrentDate(), mFechAbaLeg)>0)
					mabanLegal="1";
				//Se verifica Tipo y Unidades Comerciales para DUA De Admision Temporal

				//DatoProducto product=serie.getProducto();
				//String codtipoequi=product!=null?product.getCodtipoequi():null;
				//BigDecimal cntunimedidaequi=product!=null?product.getCntunimedidaequi():null;

				/*
				 * Viernes 12 de Febrero 2010
				 * Se coordino con Elsa, comentar este fragmento de codigo por que no aplica
				if ("21".equals(regPrec.getCodregipre())){
					if (SunatStringUtils.isEmptyTrim(codtipoequi))
						grabaWarningTelelog(listError,"5042","REGI_PROCE=21 - TIPO_EQUIU : ENVIADO: "+serie.getProducto().getCodtipoequi());
					else{
						//TODO se verifica en la tabla TABLNEW Tipo=�78�
						//si no est� se rechaza:
						//grabaWarningTelelog (" ", " ", "5042",  "REGI_PROCE=21 - TIPO_EQUIU : ENVIADO: "+ SERIES.tipo_equiu)
					}
					if (cntunimedidaequi==null ||  SunatNumberUtils.isLessOrEqualsThanParam(cntunimedidaequi, BigDecimal.ZERO)){
						grabaWarningTelelog(listError,"5002","REGI_PROCE=21 - CANT_EQUIU ENVIADO:"+cntunimedidaequi);
					}

					BigDecimal cntNetoKg3= serie.getCntpesoneto().divide(new BigDecimal(1000));
					BigDecimal cntNetoKg6= serie.getCntpesoneto().divide(new BigDecimal(1000000));

					if (SunatStringUtils.include(codtipoequi, new String[]{"KG","KG3","KG6"})){
						if("KG".equals(codtipoequi)&& !SunatNumberUtils.isEqual(serie.getCntpesoneto(), cntunimedidaequi))
							grabaWarningTelelog(listError,"0528","U.COMER: "+cntunimedidaequi+" "+codtipoequi+" P. Neto "+serie.getCntpesoneto());
						else if("KG3".equals(codtipoequi)&&  !SunatNumberUtils.isEqual(cntNetoKg3, cntunimedidaequi)){
							grabaWarningTelelog(listError,"0529","U.COMER: "+cntunimedidaequi+" "+codtipoequi+" P. Neto "+serie.getCntpesoneto());
						}else if("KG6".equals(codtipoequi)&&  !SunatNumberUtils.isEqual(cntNetoKg6, cntunimedidaequi) ){
							grabaWarningTelelog(listError,"0530","U.COMER: "+cntunimedidaequi+" "+codtipoequi+" P. Neto "+serie.getCntpesoneto());

						}
					}
					if (serie.getCodunifis().equals(codtipoequi) 
							&& !SunatNumberUtils.isEqual(serie.getCntunifis().setScale(3), cntunimedidaequi.setScale(3))){
						grabaWarningTelelog(listError, "0526","U.COMER: "+cntunimedidaequi+" "+codtipoequi+" P. Neto "+serie.getCntpesoneto());
					}
				}

				 */
			}// fin reg prec
		}//fin series
		listError.addAll(validarMaster(declaracion,"1"));
		return listError;
	}


	/**
	 * Retorna el valor de variables iniciales.
	 * 
	 * @param declaracion Declaracion
	 * @return  variables iniciales
	 */
	private Map<String,Object> getVariablesIniciales(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		String tipo_despa=dua.getCodmodalidad();
		String mcodi_regi=dua.getCodregimen();	
		String mtipo_trans=declaracion.getCodtipotrans();
		String maduana=declaracion.getCodaduana();
		//String magente=tran.getCodcontrolador();
		String mcodi_depo=dua.getNumrucdeposito();
		//		String mcodi_alma=FormatoAServiceImpl.getInstance().getOpecomextDAO().getCodAlmacenAnt(dua.getNumruclugarecep(), SunatDateUtils.getCurrentDate(),"31");
		String mcodi_alma=((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCodAlmacenAnt(dua.getNumruclugarecep(), SunatDateUtils.getCurrentDate(),"31");		
		String mcjurisdicc="";
		if (SunatStringUtils.include(maduana,new String[]{"118","235","244","999"}))
			mcjurisdicc="992";
		if ("028".equals(maduana))
			mcjurisdicc="046";
		if ("136".equals(maduana))
			mcjurisdicc="127";
		if ("253".equals(maduana))
			mcjurisdicc="217";
		if ("262".equals(maduana))
			mcjurisdicc="181";
		if ("".equals(mcjurisdicc))
			mcjurisdicc=maduana;
		//TDDI 10-12
		/*		-	Se obtienen datos de la tabla DITABLTAS:
			SELECT tesoc, tdepos FROM DITABLTAS*/
		//Ditabltas ditabltas=FormatoAServiceImpl.getInstance().getDitabltasDAO().get();
		//Ditabltas ditabltas=((DitabltasDAO)fabricaDeServicios.getService("ditabltasDAO")).get();
		String mtesoc  = "S"; //ditabltas.getTesoc();
		String mtdepos = "S"; //ditabltas.getTdepos();
		boolean	gbTieneIncMig = false;
		boolean	tienepeco = false;
		boolean	slibotros = false;
		
		//TDDI 67-70 Regla 20
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		if (SunatStringUtils.isEmptyTrim(mcodi_alma) && !SunatStringUtils.isEmptyTrim(mcodi_depo))
			mcodi_alma=mcodi_depo;
		boolean gbsadac;
		if ("10".equals(tipo_despa) && "10".equals(mcodi_regi)){

			String codpuertoref=declaracion.getNumdeclRef()!=null?declaracion.getNumdeclRef().getCodaduana():null;			
			String codpuerto=codpuertoref;
			if (!"PECLL".equals(codpuerto)){
				gbsadac=false;
			}else{
				gbsadac=packageTD.getCambioVigente("1017", SunatDateUtils.getCurrentIntegerDate())>0;
			}

		}else
			gbsadac=false;
		
		boolean gbAsigAfoPost=gbsadac || (packageTD.getCambioVigente("1017", SunatDateUtils.getCurrentIntegerDate())>0);
		boolean gbsadac2;		
		boolean gblfce;
		boolean gblexig;
		if ("10".equals(tipo_despa) && "10".equals(mcodi_regi)){
			gbsadac2=packageTD.getCambioVigente("1015", SunatDateUtils.getCurrentIntegerDate())>0;
			gblfce=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000007", SunatDateUtils.getCurrentDate())>0;
			gblexig=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000016", SunatDateUtils.getCurrentDate())>0;
		}else{
			gbsadac2=false;
			gblfce=false;
			gblexig=false;
		}
		gbsadac2=gbsadac2 && gbsadac;
		gbAsigAfoPost=gbAsigAfoPost || gblfce;
		boolean gbcontingente=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", SunatDateUtils.getCurrentDate())>0;
		boolean gbTPI802=gbcontingente;
		boolean gbContTipDespa= (gbcontingente && 
				SunatStringUtils.include(tipo_despa,new String[]{"00","01"}) && 
				(SunatStringUtils.isEmptyTrim(mtipo_trans) || SunatStringUtils.include(mtipo_trans,new String[]{"00","03","05"})));


		Map<String,Object> map=new HashMap<String,Object>();
		map.put("tipo_despa", tipo_despa);
		map.put("mcodi_regi", mcodi_regi);
		map.put("mtipo_trans", mtipo_trans);
		map.put("gbsadac", gbsadac);
		map.put("gbAsigAfoPost", gbAsigAfoPost);
		map.put("gbsadac2", gbsadac2);
		map.put("gblfce", gblfce);
		map.put("gblexig", gblexig);
		map.put("gbcontingente", gbcontingente);
		map.put("gbTPI802", gbTPI802);
		map.put("gbContTipDespa", gbContTipDespa);
		map.put("maduana", maduana);
		map.put("mcodi_depo", mcodi_depo);
		map.put("mcodi_alma", mcodi_alma);
		map.put("mcjurisdicc", mcjurisdicc);
		map.put("mtesoc", mtesoc);
		map.put("mtdepos", mtdepos);
		map.put("gbTieneIncMig", gbTieneIncMig);
		map.put("tienepeco",tienepeco );
		map.put("slibotros", slibotros);


		boolean GbSolTPI802 = false; //	Identifica si la dua tiene series con solicitud de TPI 802.
		boolean GbSolTPI803 = false; // Identifica si la dua tiene series con solicitud de TPI 803.
		boolean GbSolTPI804 = false; // Identifica si la dua tiene series con solicitud de TPI 804.
		boolean GbSolTPI805 = false; // Identifica si la dua tiene series con solicitud de TPI 805.

		/*
		 *** TDDI 
		GbTPI803 = IIF(mcodi_regi='10',NewVigenciaCriterio('983','10','000036',STR(fechhoy,8)),.F.)
		GbTPI804 = IIF(mcodi_regi='10',NewVigenciaCriterio('983','10','000037',STR(fechhoy,8)),.F.)
		GbTPI805 = IIF(mcodi_regi='10',NewVigenciaCriterio('983','10','000046',STR(fechhoy,8)),.F.)
		 **** */
		boolean gbTPI803=false;
		boolean gbTPI804=false;
		boolean gbTPI805=false;
		boolean gbTPI812=false;// jyauyo


		if("10".equals(mcodi_regi)){
			gbTPI803=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000036", SunatDateUtils.getCurrentDate())>0;
			gbTPI804=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000037", SunatDateUtils.getCurrentDate())>0;
			gbTPI805=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000046", SunatDateUtils.getCurrentDate())>0;
			gbTPI812=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000348", SunatDateUtils.getCurrentDate())>0;// jyauyo
		}

		map.put("gbTPI803", gbTPI803);
		map.put("gbTPI804", gbTPI804);
		map.put("gbTPI805", gbTPI805);
		map.put("gbTPI812", gbTPI812);// jyauyo

		map.put("GbSolTPI802", GbSolTPI802);
		map.put("GbSolTPI803", GbSolTPI803);
		map.put("GbSolTPI804", GbSolTPI804);
		map.put("GbSolTPI805", GbSolTPI805);


		return map;
	}

	/**
	 * Vigencia criterio.
	 * 
	 * @param codigoProceso String
	 * @param fecha Integer
	 * @return el integer
	 */
	private Integer vigenciaCriterio(String codigoProceso, Integer fecha){
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		return packageTD.getCambioVigente(codigoProceso, fecha);
	}

	/**
	 * Valida el envio de series.
	 * 
	 * @param declaracion Declaracion
	 * @return el mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2363)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2363,numSecEjec=17,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String,String> validarEnvioSeries(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		//TDDI 89.X.II Regla 49
		if (dua.getListSeries()==null || dua.getListSeries().isEmpty())
			return ResponseMapManager.getErrorResponseMap("", "ERROR NO ENVIO SERIE");
		return new HashMap<String,String>();
	}

	/**
	 * Vigencia criterio.
	 * 
	 * @param pCodCambio String
	 * @param pFecha Date
	 * @param pAduana String
	 * @param pRegimen String
	 * @return el integer
	 */
	private Integer vigenciaCriterio(String pCodCambio, Date pFecha, String pAduana, String pRegimen){
		return PackageGeneral.getVigenciaCambio(pAduana, pRegimen, "TD000", pCodCambio, pFecha);
	}

	private String valPlazoContingente(Contplazo contplazo,Date fechaNumeracion, Date fechaCertiOri, Date fechaFactura, Integer numSerie){
		Date doc_ref=null;
		Date doc_numero=null;
		String ctplazo=contplazo.getCodTipoPlazo();//(String)mapCPlazoValid.get("cod_tipo_plazo");
		String cuplazo=contplazo.getCodUndPlazo();//(String)mapCPlazoValid.get("cod_und_plazo");

		Date fd1=fechaNumeracion;
		Date fd2=fechaCertiOri;
		Date fd3=fechaFactura;
		Date fd4=fechaNumeracion;

		int plazo=contplazo.getCntPlazo().intValue();//(Integer)mapCPlazoValid.get("cnt_plazo");

		if ("D1".equals(contplazo.getCodDocRefe())){
			doc_ref=fd1;
		}else if("D2".equals(contplazo.getCodDocRefe())){
			if (fd2==null){
				return "NO HA ENVIADO DATOS DEL CERTIFICADO DE ORIGEN DE LA SERIE "+numSerie;
			}else{
				doc_ref=fd2;
			}
		}else if("D3".equals(contplazo.getCodDocRefe())){
			if (fd3==null){
				return "0903-NO HA ENVIADO DATOS DE LA FACTURA COMERCIAL PARA LA SERIE "+numSerie;
			}else{
				doc_ref=fd3;
			}
		}else if ("D4".equals(contplazo.getCodDocRefe())){
			doc_ref=fd4;
		}

		if ("D1".equals(contplazo.getCodDocVali())){
			doc_numero=fd1;
		}else if("D2".equals(contplazo.getCodDocVali())){
			if (fd2==null){
				return "NO HA ENVIADO DATOS DEL CERTIFICADO DE ORIGEN DE LA SERIE "+numSerie;
			}else{
				doc_numero=fd2;
			}
		}else if("D3".equals(contplazo.getCodDocVali())){
			if (fd3==null){
				return "0903-NO HA ENVIADO DATOS DE LA FACTURA COMERCIAL PARA LA SERIE "+numSerie;
			}else{
				doc_numero=fd3;
			}
		}else if ("D4".equals(contplazo.getCodDocVali())){
			doc_numero=fd4;
		}

		int numDiasDif=0;
		String result="OK";
		if ("01".equals(cuplazo)){
			if ("D01".equals(ctplazo)){
				numDiasDif=SunatDateUtils.getDifference(doc_numero, doc_ref, Calendar.DATE).intValue();
			}else if("D02".equals(ctplazo)){
				int numDias=SunatDateUtils.getDifference(doc_numero, doc_ref, Calendar.DATE).intValue();
				if (SunatDateUtils.compareDate(doc_numero, doc_ref)>=0){
					List<String> feriados=new ArrayList<String>();
					Date dateUtil=SunatDateUtils.addUtilDay(doc_ref, numDias, feriados);
					numDiasDif=numDias-(SunatDateUtils.getDifference(dateUtil, doc_ref, Calendar.DATE).intValue()-numDias);
				}else{
					List<String> feriados=new ArrayList<String>();
					Date dateUtil=SunatDateUtils.addUtilDay(doc_numero, numDias, feriados);
					numDiasDif=numDias-(SunatDateUtils.getDifference(dateUtil, doc_numero, Calendar.DATE).intValue()-numDias);
				}
			}else
				return "TIPO DE PLAZO A VALIDAR DE CONTINGENTE NO DEFINIDO";
			if (numDiasDif>plazo){
				return contplazo.getMsjInvPlazo();//(String)mapCPlazoValid.get("msj_inv_plazo");
			}
		}else if ("02".equals(cuplazo)){
			Date fcalcproc;
			if ("A01".equals(ctplazo)){
				Calendar cRef=Calendar.getInstance();
				cRef.setTime(doc_ref);
				cRef.add(Calendar.YEAR, 1+plazo);
				cRef.set(Calendar.MONTH, Calendar.JANUARY);
				cRef.set(Calendar.DATE, 1);
				fcalcproc=cRef.getTime();
			}else if ("A02".equals(ctplazo)){
				Calendar cRef=Calendar.getInstance();
				cRef.setTime(doc_ref);
				cRef.add(Calendar.YEAR, plazo);
				fcalcproc=cRef.getTime();
			}else
				return "TIPO DE PLAZO A VALIDAR DE CONTINGENTE NO DEFINIDO";
			if (SunatDateUtils.compareDate(fcalcproc, doc_numero)<0)
				return contplazo.getMsjInvPlazo();//(String)mapCPlazoValid.get("msj_inv_plazo");
		}else
			return "UNIDAD DE PLAZO DE CONTINGENTE NO DEFINIDO";
		return result;
	}


	private String valDatoContingente(Map<String,Object> mapCampValid,String numpartnalad,BigDecimal cntsolcont,Date fecEmision,String nroCertOrig,String codFFCO, String codPaisOrigen){
		String result="OK";
		boolean opcional=false;
		String tipoMsg="E";
		String codCampo = (String)mapCampValid.get("codCampo");
		if ("02".equals((String)mapCampValid.get("codTipoValid"))){
			opcional=true;
			tipoMsg="W";
		}
		if ("01".equals(codCampo)){
			if (!SunatStringUtils.isEmptyTrim(numpartnalad)){
				Integer longitud = SunatNumberUtils.toInteger( mapCampValid.get("numLongitud") );
				if (numpartnalad.length()==longitud){
					result="OK";
				}else{
					result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+numpartnalad;
				}
			}else{
				result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+numpartnalad;
			}
		}else if(SunatStringUtils.include(codCampo, new String[]{"02","03","04"})){
			if ( SunatNumberUtils.isGreaterThanZero(cntsolcont)){
				result="OK";
			}else{
				result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+cntsolcont.setScale(3).doubleValue();
			}
		}else if("05".equals(codCampo)){
			if (!SunatStringUtils.isEmptyTrim(nroCertOrig)){
				result="OK";
			}else{
				result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+nroCertOrig;
			}
		}else if ("06".equals(codCampo)){
			if (fecEmision!=null){
				result="OK";
			}else{
				result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+fecEmision;
			}
		}else if ("07".equals(codCampo)){
			Map<String,Object> paramsPruperso=new HashMap<String,Object>();
			paramsPruperso.put("regis", codFFCO);
			paramsPruperso.put("codPais", codPaisOrigen);
			paramsPruperso.put("fechCertiOrigen", SunatDateUtils.getIntegerFromDate(fecEmision));
			//List<Map<String,Object>> listJoinPruperso=FormatoAServiceImpl.getInstance().getPrupersoDAO().joinPrupersoAndPrufunciFindByMap(paramsPruperso);
			List<Map<String,Object>> listJoinPruperso=((PrupersoDAO)fabricaDeServicios.getService("prupersoDAO")).joinPrupersoAndPrufunciFindByMap(paramsPruperso);

			if (listJoinPruperso!=null && !listJoinPruperso.isEmpty()){
				result="OK";
			}else{
				FechaBean fb=new FechaBean();
				fb.setFecha(fecEmision);
				result=tipoMsg+"- DATO ENVIADO: "+(String)mapCampValid.get("desNomcampo")+" = "+codFFCO+" NO VIGENTE EN LA FECHA DE EMISION DEL CERT. ORIGEN "+fb.getFormatDate("dd/MM/yyyy");
			}
		}
		return result;
	}


	private Date getFechaFactura(int numSerie, Declaracion declaracion){
		for(DAV dav:declaracion.getListDAVs()){
			for(DatoFactura factura:dav.getListFacturas()){
				for(DatoItem item:factura.getListItems()){
					for(DatoSerieItem serieItem:item.getListSerieItems()){
						if (serieItem.getNumserie()==numSerie)
							return factura.getFecfactura();
					}
				}
			}
		}
		return null;
	}



	private DatoOtroDocSoporte getDatoDocAsoc(Elementos<DatoOtroDocSoporte> docs, DatoSerie serie){
		DatoSerieDocSoporte serieDoc=null;
		for(DatoSerieDocSoporte doc:serie.getListSerieDocSoporte()){
			if ("2".equals(doc.getCodtipodocsoporte())){
				serieDoc=doc;
				break;
			}
		}
		if (serieDoc==null)
			return null;
		for(DatoOtroDocSoporte doc:docs){
			if ("2".equals(doc.getCodtipodocasoc()) && doc.getNumdocasoc().equals(String.valueOf(serieDoc.getNumiddocsoporte())))
				return doc;
		}
		return null;
	}

	/**
	 * Graba telelog.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param codigo String
	 * @param mensaje String
	 */
	private void grabaTelelog(List<Map<String,String>>listError, String codigo, String mensaje){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		//listError.add(FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMapWithDescription(codigo, mensaje));
		listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codigo, new String[]{mensaje}));
	}

	/**
	 * Graba telelog.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param codigo String
	 * @param params Object[]
	 */
	private void grabaTelelog(List<Map<String,String>>listError, String codigo, Object[] params){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		listError.add(getDUAError(codigo, params));
	}

	/**
	 * Graba warning telelog.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param codigo String
	 * @param mensaje String
	 */
	private void grabaWarningTelelog(List<Map<String,String>>listError, String codigo, String mensaje){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		//listError.add(FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMapWithDescription(codigo, mensaje));
		listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codigo, new String[]{mensaje}));
	}


	@ServicioAnnot(tipo="V",codServicio=2364)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2364,numSecEjec=18,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> pValidaMaster(Declaracion declaracion){
		return validarMaster(declaracion,"2");
	}

	/**
	 * Regla 124 y 125 TDDI
	 * Metodo para validar el manifeisto master.
	 * @deprecated Validar metodo probable uso de valores nulos. 
	 * @param declaracion Declaracion
	 * @param tipoValidacion String
	 * @return List de errores
	 */
	private List<Map<String,String>> validarMaster(Declaracion declaracion, String tipoValidacion){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		List<DatoDocTransporte> listDocTransporteTmp;
		List<DatoDocTransporte> listDocTransporte;
		DUA dua=declaracion.getDua();
		listDocTransporteTmp=null;
		listDocTransporte=new ArrayList<DatoDocTransporte>();
		DatoDocTransporte documentoTransporte= new DatoDocTransporte();
		boolean encontroCodTipoDoc3=false; 
		boolean encontroDocTrans=false; 

		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if (tipoValidacion.equals("2")){
			if(declaracionTieneDatoSeries){
				for (DatoSerie datoSerieActual : dua.getListSeries()) {
					for (DatoSerieDocSoporte datoSerieDocSoporteActual : datoSerieActual.getListSerieDocSoporte()) {
						if (datoSerieDocSoporteActual.getCodtipodocsoporte().equals("3")){// Documento de Transporte
							documentoTransporte=getDocTransporte(dua,datoSerieActual);
							listDocTransporte.add(documentoTransporte);
						}
					}
					for (DatoDocTransporte docTransporteActual : listDocTransporte) {
						encontroDocTrans=false;    				
						if (listDocTransporteTmp.size()>0){
							for (DatoDocTransporte docTransporteActualTmp : listDocTransporteTmp) {
								if (docTransporteActual.getNumdoctransporte().equals(docTransporteActualTmp.getNumdoctransporte())){
									encontroDocTrans=true;
									if(!docTransporteActual.getNumdocmaster().equals(docTransporteActualTmp.getNumdocmaster()))
										grabaTelelog (listError, "8001", "CONO_EMBAR: " + docTransporteActual.getNumdoctransporte() + " ESTA ENVIANDO MAS DE 1 MASTER");
									if(!docTransporteActual.getCodtipodoctrans().equals(docTransporteActualTmp.getCodtipodoctrans()))	   
										grabaTelelog (listError, "8001", "CONO_MASTER: " + docTransporteActual.getNumdocmaster() + " SOLO PUEDE SER DE UN TIPO. ENVIADO");
									if(docTransporteActual.getCodtipodoctrans().equals("3")){
										encontroCodTipoDoc3=true;
										grabaTelelog (listError, "8001", "CONO_EMBAR: " + docTransporteActual.getNumdocmaster() + " ESTA ENVIANDO MAS DE 1 HIJO");
									}

								}
							}
						}
						if (!encontroDocTrans){// se agregara a la lista de tmp el nuevo doc

							DatoDocTransporte docTransTmp= new DatoDocTransporte();
							docTransTmp.setCodtipodoctrans(docTransporteActual.getCodtipodoctrans());
							docTransTmp.setNumdoctransporte(docTransporteActual.getNumdoctransporte());
							docTransTmp.setNumdocmaster(docTransporteActual.getNumdocmaster());
							listDocTransporteTmp.add(docTransTmp);
						}
					}
				}
				if (encontroCodTipoDoc3 && listDocTransporteTmp.size()>1){
					grabaTelelog (listError, "8001", " ");
				}


			}
		}

		return listError;		
	}
	/**
	 * Regla 126 del TDDI
	 * Validar numerar con RUC.
	 * 
	 * @param declaracion Declaracion
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2365)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2365,numSecEjec=19,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarNumerarConRUC(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		String tipoDoc="";
		String nroDoc="";
		BigDecimal sumaFob= new BigDecimal(0);
		BigDecimal tmp= new BigDecimal(1000);
		int codLiberatorio=0;

		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				codLiberatorio=datoSerieActual.getCodliberatorio()!=null?datoSerieActual.getCodliberatorio():0;
				if (codLiberatorio!=3302 && codLiberatorio!=3312 && codLiberatorio!=4201 && codLiberatorio!=4442 && codLiberatorio!=4443 && codLiberatorio!=4444){
					sumaFob=SunatNumberUtils.sum(sumaFob,datoSerieActual.getMtofobdol());	
				}
			}
		}

		tipoDoc=dua.getDeclarante().getDocumento().getTipoDocumento();
		nroDoc=dua.getDeclarante().getNumeroDocumentoIdentidad();
		//sumaFob>1000
		if (  !SunatNumberUtils.isEqual(sumaFob, new BigDecimal(1000)) 
				&& SunatStringUtils.include(tipoDoc,new String[]{"1","2","3","5","6","7","9"})&& !(SunatStringUtils.include(tipoDoc,new String[]{"6","7"}) && "7".equals(dua.getCodtipotratamiento()))){
			// consultar a DECLARAN
			//DeclaranDAO declaranDAO=FormatoAServiceImpl.getInstance().getDeclaranDAO();
			Declaran decTmp= new Declaran();
			List<Declaran> listDeclaran=new ArrayList<Declaran>();
			decTmp.setCdocumen(nroDoc);
			decTmp.setCtipodoc(tipoDoc);


			//listDeclaran=declaranDAO.selectByMap(decTmp);
			listDeclaran= (List<Declaran>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).selectByMapDeclaran(decTmp);

			// si existe elemento se rechaza
			if (listDeclaran!=null && listDeclaran.size()>0){
				grabaTelelog (listError, "1109", "SEGUN RESOLUCION DE SUPERINTENDENCIA 1356 TIENE QUE NUMERAR CON RUC");
			}
		}
		return listError;	
	}

	// Pase a clase ValRegPrecDepostio	
	//	/**
	//	 * Metodo que permite consolidar los distintos regimenes de precedencia en un solo Map, acumulando sus pesos y unidades
	//	 * @param declaracion
	//	 * @return
	//	 */
	//	public List<Map<String,Object>> getRegPrecedenciaAcumulado (Declaracion declaracion){
	//		DUA dua=declaracion.getDua();
	//		List<Map<String,Object>> listDpocCta = new ArrayList<Map<String,Object>>();
	//		for (DatoSerie datoSerieActual : dua.getListSeries()) {
	//			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
	//				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
	//					if (datoRegPreActual.getCodregipre().equals("70")){
	//						Map<String,Object> dPocCta = new HashMap<String, Object>();
	//						dPocCta.put("codregipre", datoRegPreActual.getCodregipre());
	//						dPocCta.put("caduregpre", datoRegPreActual.getCodaduapre());
	//						dPocCta.put("fanoregpre", datoRegPreActual.getAnndeclpre());
	//						dPocCta.put("ndclregpre", datoRegPreActual.getNumdeclpre());
	//						dPocCta.put("numserpre", datoRegPreActual.getNumserpre());
	//						
	//						dPocCta.put("sumPesoBruto", datoSerieActual.getCntpesobruto());
	//						dPocCta.put("sumCntunifis", datoSerieActual.getCntunifis());
	//						//el metodo agrega los datos de esta serie a una Lista
	//						//Si ya existe un referencia a la misma dua y serie precedente entonce solo sumara
	//						//los valores sumPesoBruto y sumCntunifis
	//						/*branch ingreso 2011-009 hosorio inicio*/
	//						if(declaracion.getNumdeclRef()!=null 
	//								&& !SunatStringUtils.isEmptyTrim(declaracion.getNumdeclRef().getNumcorre()) )
	//						{
	//							NumdeclRef numdeclRef=declaracion.getNumdeclRef();
	//							dPocCta.put("codregiActual", numdeclRef.getCodregimen());
	//							dPocCta.put("caduActual", numdeclRef.getCodaduana());
	//							dPocCta.put("fanoActual", numdeclRef.getAnnprese());
	//							dPocCta.put("ndclActual", SunatStringUtils.lpad(numdeclRef.getNumcorre(), 6, '0') );
	//							dPocCta.put("numserActual", datoSerieActual.getNumserie().toString());									
	//						}
	//						/*branch ingreso 2011-009 hosorio fin*/
	//						listDpocCta = AddEnListaDepocCta(listDpocCta,dPocCta);
	//						break;
	//					}
	//				}
	//			}   
	//		}
	//		return listDpocCta;
	//	}

	/**
	 * Regla 128 del TDDI
	 * Se valida la cuenta corriente del deposito (91.K )
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return Lista de errores
	 */
	//Pasa a clase ValRegPrecDeposito
	//	@ServicioAnnot(tipo="V",codServicio=2366)
	//	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	//	@OrquestaDespaAnnot(codServInstancia=2366,numSecEjec=20,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	//	public List<Map<String,String>> validarCtaCteDeposito(Declaracion declaracion, Map<String, Object> variablesIngreso){
	//		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
	//		String mtdepos=(String)mapVariables.get("mtdepos"); 
	//		DUA dua=declaracion.getDua();
	//		boolean reg70=false;
	//		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
	//
	//		if ("S".equals(mtdepos)){
	//			boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
	//			//Lista donde se acumulara los totales si hubiera regimen precedente 70
	//			List<Map<String,Object>> listDpocCta = new ArrayList<Map<String,Object>>();
	//
	//			if(declaracionTieneDatoSeries){
	//				listDpocCta = getRegPrecedenciaAcumulado(declaracion);
	//				reg70 = !listDpocCta.isEmpty();
	//				for(Map<String,Object> mapCta:  listDpocCta){
	//					mapCta.put("fechaVigenciaRegimenBD", (Date)variablesIngreso.get("fechaVigenciaRegimenBD"));
	//					mapCta.put("numeroDeclaracion", variablesIngreso.get("numeroDeclaracion"));
	//					listError.addAll(SPTD_CTACTEDEPOSITO.ctaCteDeposito(mapCta));
	//				}
	//			}
	//			/**NSR Si no hay errores con esta variable indicamos que en el metodo de grabaci�n se debe actualizar la cta cte */
	//			if (listError.isEmpty() &&  reg70){
	//				variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
	//			}
	//		}
	//
	//		return listError;
	//	}

	/**
	 * Adds the en lista depoc cta.
	 * 
	 * @param lista List<Map<String,Object>>
	 * @param datos Map<String,Object>
	 * @return Lista de erores
	 */
	/*private List<Map<String,Object>> AddEnListaDepocCta(List<Map<String,Object>> lista,Map<String,Object> datos){

		boolean datosExisten = false;
		for(Map<String,Object> m: lista){
			if(m.get("caduregpre").toString().equalsIgnoreCase(datos.get("caduregpre").toString()) &&
			   m.get("fanoregpre").toString().equalsIgnoreCase(datos.get("fanoregpre").toString()) &&
			   m.get("ndclregpre").toString().equalsIgnoreCase(datos.get("ndclregpre").toString()) &&
			   m.get("numserpre").toString().trim().equalsIgnoreCase(datos.get("numserpre").toString().trim())
					){
				BigDecimal sumPesoBruto = SunatNumberUtils.sum((BigDecimal)m.get("sumPesoBruto"),(BigDecimal)datos.get("sumPesoBruto"));	
				BigDecimal sumCntunifis = SunatNumberUtils.sum((BigDecimal)m.get("sumCntunifis"),(BigDecimal)datos.get("sumCntunifis"));

				m.put("sumPesoBruto", sumPesoBruto);
				m.put("sumCntunifis", sumCntunifis);

				datosExisten = true;
			}
		}
		if (!datosExisten){
			lista.add(datos);
		}
		return lista;
	}
	/**
	 * Regla 129 del TDDI
	 * Se valida cupo del TPN 164 (91.M)
	 * 
	 * @param declaracion Declaracion
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2367)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2367,numSecEjec=21,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarCupoTPN(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		BigDecimal tonel= new BigDecimal(1000);
		BigDecimal pesoToneladas= new BigDecimal(0);
		Cupolibe cLibe= new Cupolibe();
		List<Cupolibe> listCupolibe=new ArrayList<Cupolibe>();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();

		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {

				if (datoSerieActual.getCodtratprefe()!=null && datoSerieActual.getCodtratprefe()==164){
					pesoToneladas=SunatNumberUtils.sum(pesoToneladas,datoSerieActual.getCntpesoneto().divide(tonel));
				}  
			}
			if (SunatNumberUtils.isGreaterThanZero(pesoToneladas)){
				//Busca cupolibe
				Map params= new HashMap();

				//CupolibeDAO cupolibeDAO=FormatoAServiceImpl.getInstance().getCupolibeDAO();
				//bug 17902
				CupolibeDAO cupolibeDAO=((CupolibeDAO)fabricaDeServicios.getService("cupoLibeDAO"));
				listCupolibe=cupolibeDAO.findByParams(params);



				//cupoLibeDao.XXX
				if (listCupolibe.size()==0){
					grabaTelelog (listError, "0196",  "TRAT_PREFE: 164");
				}else{
					cLibe=listCupolibe.get(0);
					BigDecimal diference=SunatNumberUtils.diference(cLibe.getPesomax(), cLibe.getPesosol());

					if ( SunatNumberUtils.isGreaterThanParam(pesoToneladas, diference) ){
						grabaTelelog (listError, "0196",  "TRAT_PREFE: 164, Saldo TM: "+ diference +", Solicita TM: "+pesoToneladas);
					}
				}


			}	
		}	

		return listError;
	}
	/**
	 * Regla 130 del TDDI
	 * Se realizan algunas consistencias con la informacion procesada (91.N )
	 * 
	 * @param declaracion Declaracion
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2368)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2368,numSecEjec=22,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarConsistencias(Declaracion declaracion ){
		DUA dua=declaracion.getDua();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			if (!dua.getCntnumseries().equals(dua.getListSeries().size())){
				grabaTelelog(listError, "0039",  "  ");
			}
		}
		return listError;
	}
	/**
	 * Regla 131-132 del TDDI
	 * Se validan totales (cabecera Vs Series) (91.O )
	 * 
	 * @param declaracion Declaracion
	 * @return List de erroeres
	 */
	@ServicioAnnot(tipo="V",codServicio=2369)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2369,numSecEjec=23,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarTotalesCabvsSer(Declaracion declaracion ){

		DUA dua=declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		BigDecimal mfobser= new BigDecimal(0);
		BigDecimal mpesobrut= new BigDecimal(0);
		BigDecimal mpesoneto= new BigDecimal(0);
		BigDecimal mbulserie= new BigDecimal(0);
		BigDecimal mqunicom= new BigDecimal(0);
		BigDecimal mqunifis= new BigDecimal(0);
		BigDecimal majuste= new BigDecimal(0);
		BigDecimal mseg_tot= new BigDecimal(0);
		BigDecimal mflete= new BigDecimal(0);
		BigDecimal mfobdolser=new BigDecimal(0);
		BigDecimal mfobcomp=new BigDecimal(0);
		mfobcomp=dua.getMtotfobclvta();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		String Moneda="";
		//Sumar los valores fob por serie para luego comparar
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				mfobdolser=SunatNumberUtils.sum(mfobdolser,datoSerieActual.getMtofobdol());
			}
		}

		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				mfobser=SunatNumberUtils.sum(mfobser,datoSerieActual.getMtofobdol());
				mpesobrut=SunatNumberUtils.sum(mpesobrut, datoSerieActual.getCntpesobruto());
				mpesoneto=SunatNumberUtils.sum(mpesoneto,datoSerieActual.getCntpesoneto());
				mbulserie=SunatNumberUtils.sum(mbulserie,datoSerieActual.getCntbultos());
				mqunicom=SunatNumberUtils.sum(mqunicom,datoSerieActual.getCntunicomer());
				mqunifis=SunatNumberUtils.sum(mqunifis,datoSerieActual.getCntunifis());
				majuste=SunatNumberUtils.sum(majuste,datoSerieActual.getMtoajuste());
				mseg_tot=SunatNumberUtils.sum(mseg_tot,datoSerieActual.getMtosegdol());
				mflete=SunatNumberUtils.sum(mflete,datoSerieActual.getMtofledol());
				if (SunatNumberUtils.absoluteDiference(mfobcomp,mfobdolser).doubleValue()>1){
					if (!datoSerieActual.getCodmoneda().equals("USD")){
						grabaTelelog (listError, "0097",  "SUMATORIA DE FOB EN LAS SERIES ES: "+mfobser+", TOTAL FOB ENVIADO EN LA CABECERA ES: "+datoSerieActual.getCodmoneda());
					}
				}
				if (!datoSerieActual.getCodmoneda().equals("USD") && dua.getMtotfobclvta()!=mfobdolser && dua.getMtotfobclvta().doubleValue()-mfobdolser.doubleValue()>1){
					BigDecimal bd=SunatNumberUtils.sum(datoSerieActual.getMtofobdol(), dua.getMtotfobclvta());
					bd=SunatNumberUtils.diference(bd, mfobdolser);
					datoSerieActual.setMtofobdol(bd);
					//					datoSerieActual.setMtofobdol(new BigDecimal(datoSerieActual.getMtofobdol().add(dua.getMtotfobclvta()).doubleValue()-mfobdolser.doubleValue()));
				}
				Moneda=datoSerieActual.getCodmoneda();
			}

		}

		if ( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getMtotfobclvta(),mfobser), Constants.BIGDECIMAL_ONE))
			grabaWarningTelelog (listError, "0096",  "SUMATORIA DE FOB EN LAS SERIES ES: "+ mfobser+", TOTAL FOB ENVIADO EN LA CABECERA ES: "+ dua.getMtotfobclvta());
		if( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getCnttpesobruto(),mpesobrut), Constants.BIGDECIMAL_ONE))	
			grabaWarningTelelog (listError, "0099",  "SUMATORIA DE PESO BRUTO EN LAS SERIES ES: "+mpesobrut+", TOTAL PESO BRUTO ENVIADO EN LA CABECERA ES: "+dua.getCnttpesobruto());
		if( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getCnttpesoneto(),mpesoneto), Constants.BIGDECIMAL_ONE))	
			grabaTelelog (listError, "0098", new Object[]{ mpesoneto,  dua.getCnttpesoneto()});	
		if (  SunatNumberUtils.absoluteDiference(dua .getCnttcantbulto(), mbulserie).doubleValue()>0)
			grabaWarningTelelog (listError, "0100",  "SUMATORIA DE BULTOS EN LAS SERIES ES: "+mbulserie+", TOTAL BULTOS ENVIADO EN LA CABECERA ES: "+dua.getCnttcantbulto())	;
		if ( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getCnttqunicom(),mqunicom), BigDecimal.ZERO))
			grabaWarningTelelog (listError, "0102",  "SUMATORIA DE UNIDADES COMERCIALES EN LAS SERIES ES: "+mqunicom+", TOTAL UNIDADES COMERCIALES ENVIADAS EN LA CABECERA ES: "+dua.getCnttqunicom());
		if ( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getCnttqunifis(),mqunifis), BigDecimal.ZERO))
			grabaWarningTelelog (listError, "0101",  "SUMATORIA DE UNIDADES FISICAS EN LAS SERIES ES: "+mqunifis+", TOTAL UNIDADES FISICAS ENVIADAS EN LA CABECERA ES: "+dua.getCnttqunifis())	;
		if (dua.getMtotajustes()==null)
			dua.setMtotajustes(BigDecimal.ZERO);
		if ( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getMtotajustes(),majuste), Constants.BIGDECIMAL_ONE))
			grabaWarningTelelog (listError, "1082",  "SUMATORIA DE AJUSTE EN LAS SERIES ES: "+majuste+", TOTAL AJUSTE ENVIADO EN LA CABECERA ES: "+dua.getMtotajustes())	;
		if ( SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(dua.getMtotsegotros(),mseg_tot), Constants.BIGDECIMAL_ONE))
			//grabaWarningTelelog (listError, "0035",  "SUMATORIA DE SEGURO EN LAS SERIES ES: "+mseg_tot+", TOTAL SEGURO ENVIADO EN LA CABECERA ES: "+dua.getMtotsegotros())	;
			grabaTelelog(listError,"00034",new Object[]{mseg_tot,dua.getMtotsegotros() });
		if (dua.getMtotflecomex()==null)
			dua.setMtotflecomex(BigDecimal.ZERO);
		if ( SunatNumberUtils.absoluteDiference(dua.getMtotflecomex(), mflete).doubleValue()>1) {	
			//grabaWarningTelelog (listError, "0034",  "SUMATORIA DE FLETE EN LAS SERIES ES: "+mflete+", TOTAL FLETE ENVIADO EN LA CABECERA ES: "+dua.getMtotflecomex())	;
			grabaTelelog(listError,"00035",new Object[]{mflete, dua.getMtotflecomex()});
		}




		return listError;
	}
	/**
	 * Regla 133 del TDDI
	 * Se validan  la fecha de termino de descarga del manifiesto para las duas urgentes (93.A-93.D)
	 * 
	 * @param declaracion Declaracion
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2370)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2370,numSecEjec=24,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarFechaTerDescDuasUrgentes(Declaracion declaracion){

		DUA dua=declaracion.getDua();
		DatoManifiesto datoManif= new DatoManifiesto();
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		datoManif= declaracion.getDua().getManifiesto();
		Manifiesto manif= new Manifiesto();
		Map<String,Object> paramsMap= new HashMap<String,Object>();
		boolean gbSolicitaCont=false;
		Map<String,Object> mapVariables=getVariablesIniciales(declaracion);
		boolean gbcontingente=(Boolean)mapVariables.get("gbcontingente");
		boolean gbContTipDespa=(Boolean)mapVariables.get("gbContTipDespa");
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		// validacion para encontrar gbcontingente
		if (declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (gbcontingente){
					if (datoSerieActual.getCodconvinter()!=null && "5".equals(datoSerieActual.getCodtipomarge())){
						if (gbContTipDespa){
							Map<String,Object> mapDatosCont=new HashMap<String,Object>();
							if (mapDatosCont!=null){
								gbSolicitaCont=true;
							}
						}
					}
				}
			}
		}
		// fin validacion para encontrar gbcontingente

		if (gbcontingente && gbSolicitaCont && dua.getCodmodalidad().equals("01") ){
			// se obtiene fecha de llegada del manifiesto MANIFIESTODAO

			if(datoManif!=null){
				//CabManifiestoDAO manifiestoDAO=FormatoAServiceImpl.getInstance().getManifiestoDAO();
				String codtipomanif=datoManif!=null?datoManif.getCodtipomanif():null;
				String codmodtransp=datoManif!=null?datoManif.getCodmodtransp():null;

				//inicio gmontoya bug 18128
				String annio = datoManif.getAnnmanif()!=null?datoManif.getAnnmanif():"1000";
				if(annio.length()>4){
					annio = annio.substring(0, 4);
				}
				//fin gmontoya bug 18128
				manif= new Manifiesto();
				paramsMap.put("codigoTipoManifiesto", codtipomanif);
				paramsMap.put("codigoViaTransporte",codmodtransp);
				paramsMap.put("anioManifiesto",Integer.valueOf(annio));
				paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(datoManif.getNummanif(), 6, ' '));//gmontoya bug 18128
				paramsMap.put("codigoAduana", datoManif.getCodaduamanif());

				//manif=manifiestoDAO.getByPrimaryKey(paramsMap);
				//				manif=((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).getByPrimaryKey(paramsMap);
				//inicio gmontoya bug 18128
				List<Manifiesto> listaManifiesto=((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).listByParameterMap(paramsMap);
				if(!CollectionUtils.isEmpty(listaManifiesto)){
					manif = listaManifiesto.get(0);
					if (manif.getFechaTerminoDeDescarga().getTime()==0){
						grabaTelelog (listError, "8066",  "EL MANIFIESTO: " + datoManif.getCodaduamanif() + "-" +annio + "-" + datoManif.getNummanif() + "-" + datoManif.getCodmodtransp()+" NO TIENE REGISTRADA LA FECHA DE TERMINO DE DESCARGA");
					} //pase 105 por bug 17983 
					//						else{
					//						grabaTelelog (listError, "8068",  "EL MANIFIESTO: " + datoManif.getCodaduamanif()+ "-" +annio + "-" + datoManif.getNummanif() + "-" + datoManif.getCodmodtransp() +	" NO SE ENCUENTRA EN ESTADO DEFINITIVO");
					//					}
				}
				//fin gmontoya bug 18128				
			}
		}
		return listError;	
	}
	/**
	 * Regla 134 del TDDI
	 * Validacio del manifiesto de carga (94-95 ).
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @param fechaReferencia Date
	 * @param codTransaccion String
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2371)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2371,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarManifiestoCarga(Declaracion declaracion,Map<String, Object> variablesIngreso, Date fechaReferencia, String codTransaccion) throws Exception{

		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;	
		
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		/***PAS20181U220200049 inicio***/
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		/***PAS20181U220200049 fin***/
		
		DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
		boolean tieneprece=false;
		//boolean siHayData =true;
		boolean tieneDatar = true;
		/*RIN13FSW esta parte no debe de ir al TRUNK dado que no se porbara para esta 2do paquete*/
		/*marcaDesdatadoDatado se ah extraido para  en una logia aparte sea considerado false: para anular el proceso de registro del datado y desdatado*/
		//RIN 13 INICIO
		boolean marcaDesdatadoDatado = true;		
		//RIN13 FIN
		DUA dua=declaracion.getDua();
		boolean isTxDilig = funcionesService.isTransaccionDiligencia(codTransaccion);

		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());

		Map<String, Object> declaracionBDMap = null;
		Date fechaDeclaracion = null;
		Date fechaTerminoDescarga = null;
		Date fechaTerminoDescargaXML = null;
		if(codTransaccion.endsWith("03") || isTxDilig ){
			Map<String,Object> params= new HashMap<String, Object>();	   
			params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
			params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
			params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
			params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
			//List<Map<String,Object>> lstdua= FormatoAServiceImpl.getInstance().getCabDeclaraDAO().listCabDeclaraMapByParameterMap(params);
			//TLC Corea se cambia a dao de lectura por problemas de conexiones cerradas en WL
			//			List<Map<String,Object>> lstdua= ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).listCabDeclaraMapByParameterMap(params);
			List<Map<String,Object>> lstdua= ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraLecturaDAO")).listCabDeclaraMapByParameterMap(params);

			if (!CollectionUtils.isEmpty(lstdua)){
				declaracionBDMap = lstdua.get(0);
				fechaDeclaracion = (Date)declaracionBDMap.get("fecdeclaracion");
				fechaTerminoDescarga = (Date)declaracionBDMap.get("fectermino");
				fechaTerminoDescargaXML = dua.getFecLlegada();  
			}
		}

		if(declaracionTieneDatoSeries){
			tieneprece = this.existeRegPrecedencia(dua.getListSeries());
			//siHayData  = !this.existeRegPrecedenciaReposicion(dua.getListSeries());
			tieneDatar = this.datarPrecedencia(dua.getListSeries());


			variablesIngreso.put("validarManifiesto",false);
			boolean esUrgente = "01".equals(dua.getCodmodalidad())?true:false;
			boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;
			boolean esAnticipado = "10".equals(dua.getCodmodalidad())?true:false;
			boolean esUrgenteExcepcional = false;
			boolean esUrgenteAnticipada = false;
			boolean esExcepcionalSinTD = false;
			boolean esExcepcionalConTD = false;

			//Cargamos los datos del manifiesto de la dua en la variable manif
			DatoManifiesto manif=dua.getManifiesto();		    

			//Valida que cuando Aduana de manifiesto es diferente de Aduana de DUA, debe tener Regimen precedente
			if( !dua.getCodaduanaorden().equals(manif.getCodaduamanif()) && !tieneprece) {
				Map<String, String> mapError = ResponseMapManager.getErrorResponseMap("30496", "MANIFIESTO ASOCIADO ES DE OTRA ADUANA Y NO DECLARA REGIMEN DE PRECEDENCIA");
				listError.add(mapError);
				return listError;
			}

			//branch ingreso 2011-009 gmontoya 28/04/2011 14
			//Se comenta porque esta validaci�n se traslada al servicio creado en la RIN 07 validarPlazoDuaAnticipadoYUrgenteAnticipado
			//INICIO - RIN13
			/*if(codTransaccion.endsWith("03")  || isTxDilig)
		    {
			    //CabManifiestoDAO manifiestoDAO=FormatoAServiceImpl.getInstance().getManifiestoDAO();
				String codtipomanif=manif!=null?manif.getCodtipomanif():null;
				String codmodtrans=manif!=null?manif.getCodmodtransp():null;


				Map<String,Object> paramsMap= new HashMap<String,Object>();
				paramsMap.put("tipoManifiesto", codtipomanif);
				paramsMap.put("viaTransporte",codmodtrans);
				String annio = manif.getAnnmanif()!=null?manif.getAnnmanif():"1000";
				if(annio.length()>4){
					annio = annio.substring(0, 4);
				}
				paramsMap.put("anioManifiesto", annio);
				paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(manif.getNummanif(), 6, ' '));
				paramsMap.put("aduana", manif.getCodaduamanif());

//				Map<Object,Object> manifiestodao=manifiestoDAO.getByNumeroAnioAduanaTipoManifTipoVia(paramsMap);	
				Map<Object,Object> manifiestodao=((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).getByNumeroAnioAduanaTipoManifTipoVia(paramsMap);
				Date fechaLlegada = null;
				if(manifiestodao!=null && 
						       ( manifiestodao.get("fechaProgramadaLlegada")!=null && !SunatDateUtils.isDefaultDate((Date)manifiestodao.get("fechaProgramadaLlegada"))	 
								|| manifiestodao.get("fechaEfectivaDeLlegada")!=null && !SunatDateUtils.isDefaultDate((Date)manifiestodao.get("fechaEfectivaDeLlegada"))
								)

				      ){					
					if(manifiestodao.get("fechaEfectivaDeLlegada")!=null && 
							!SunatDateUtils.isDefaultDate((Date)manifiestodao.get("fechaEfectivaDeLlegada"))	
					    ){
						fechaLlegada = (Date)manifiestodao.get("fechaEfectivaDeLlegada");
					}else{
						fechaLlegada = (Date)manifiestodao.get("fechaProgramadaLlegada");
					}
				}else{
					fechaLlegada = fechaTerminoDescarga;
				}

				/* ONEYRAJ PAS20144E610000245 INICIO */								

			/*if(esAnticipado){
					Date fechaInferior = SunatDateUtils.addDay(fechaLlegada, -15);
					if (SunatDateUtils.esFecha1MenorQueFecha2(fechaDeclaracion, fechaInferior, SunatDateUtils.COMPARA_SOLO_FECHA) ){		    
			    		grabaTelelog(listError,"35004","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
			    		return listError;
			    	}
				}

				if(esUrgente) {
					if(manifiestodao!=null){
						Date fechaTerminoDescargaManifiesto = (Date)manifiestodao.get("fechaTerminoDeDescarga");
						if(fechaTerminoDescargaManifiesto != null && !SunatDateUtils.isDefaultDate(fechaTerminoDescargaManifiesto)) {							
							if(SunatDateUtils.esFecha1MenorQueFecha2(fechaTerminoDescargaManifiesto, SunatDateUtils.addDay(fechaDeclaracion, -7), SunatDateUtils.COMPARA_SOLO_FECHA)){
								grabaTelelog(listError,"35007","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
								return listError;
							}
						}
						else{
							if(fechaLlegada != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaLlegada, fechaDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
								if(SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(fechaDeclaracion, 15), fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)){
									grabaTelelog(listError,"35007","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
									return listError;
								}
							}
						}
					}
				}*/
			/* ONEYRAJ PAS20144E610000245 FIN */

			/*if(esAnticipado){
			    	if (SunatDateUtils.esFecha1MayorQueFecha2(fechaDeclaracion, fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){		    
			    		grabaTelelog(listError,"30486","DESPACHO ANTICIPADO INVALIDO, NUMERACI�N REALIZADA DESPUES DE LLEGADA DE LA NAVE.");
			    	}
			    }
			    if(esAnticipado || esUrgente){
			    	Date fechaInferior = SunatDateUtils.addDay(fechaLlegada, -15);
			    	if (SunatDateUtils.esFecha1MenorQueFecha2(fechaDeclaracion, fechaInferior, SunatDateUtils.COMPARA_SOLO_FECHA) ){		    
			    		grabaTelelog(listError,"30487","DESPACHO ANTICIPADO INVALIDO, NUMERACI�N REALIZADA ANTES DEL INICIO DEL PLAZO PARA LA NUMERACI�N.");
			    	}
			    }*/
			//}
			//FIN - RIN13
			// ESM - INICIO 
			// Validacion de fecha de tarja en Diligencia de Despacho en al menos un documento de transporte tipo directo declarado para despachos urgentes anticipados, canal rojo 
			//if ((codTransaccion.endsWith(Constants.COD_TRANSAC_DILIGENCIADESPA) && (esUrgente || esAnticipado) && SunatStringUtils.isEqualTo((String) declaracionBDMap.get("codcanal"), "F"))
			/*RIN13INSI*/
			if (((codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)
					|| codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)) 
					/*INICIO-P34 FSW AFMA*/
					|| codTransaccion.equals(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION))
					/*FIN-P34 FSW AFMA*/
					&& (esUrgente || esAnticipado) && SunatStringUtils.isEqualTo((String) declaracionBDMap.get("codcanal"), "F")
					){// se agrega por el bug  Bug 17733 gmontoya

				Map<String, Object> param = new HashMap<String, Object>();
				param.put("NUM_CORREDOC", declaracionBDMap.get("numcorredoc"));

				// Se verifica que el doc. de transporte sea tipo directo 
				int cant = detDeclaraDAO.findCantDetDeclaraTipoCargaConsolidadoConsolidado1a1(param);
				if (cant == 0) {
					/****
					boolean buscarManifiestoSigadActual = false;

					//buscarManifiestoSigadActual = ("4".equals(dua.getManifiesto().getCodmodtransp()) || "7".equals(dua.getManifiesto().getCodmodtransp()));
					buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(dua.getManifiesto().getCodmodtransp()) || ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(dua.getManifiesto().getCodmodtransp()));
					
					Map<String, Object> dataManif = new HashMap<String, Object>();

					String codaduamanif = manif.getCodaduamanif();
					String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
					String nummanif = manif.getNummanif();
					String codmodtransp = manif.getCodmodtransp();
					String codtipmanif = manif.getCodtipomanif();

					dataManif.put("numeroManifiesto",SunatStringUtils.lpad(nummanif, 6, ' '));
					dataManif.put("anioManifiesto", annmanif);
					dataManif.put("codigoAduana", codaduamanif);
					dataManif.put("codigoTipoManifiesto", codtipmanif);
					dataManif.put("codigoViaTransporte", codmodtransp);
					****/
					/***PAS20181U220200049 inicio***/
					/****Manifiesto manifiesto = null;
					if(!ResponseListManager.responseListHasErrors(listaOMA)){
						boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
						manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true,fechaReferencia,considerarEER);
					}else{
						 manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, buscarManifiestoSigadActual); 
					}****//***PAS20181U220200049 fin***/
					Manifiesto manifiesto = null;//pase64 para reutilizar
					manifiesto = obtenerManifiesto( manif,  declaracion, listaOMA, fechaReferencia);
					
					if (manifiesto != null) {

						//if (buscarManifiestoSigadActual) { // Para manifiestos de via terrestre busca fecha de tarja en ASIGAD
						if(manifiesto.isEsSigad()){
							String codigoViaTransporte = manifiesto.getViaTransporte().getCodDatacat();
							Integer anioManifiesto = manifiesto.getAnioManifiesto();
							String numeroManifiesto = manifiesto.getNumeroManifiesto();
							String codigoAduana = manifiesto.getAduana().getCodDatacat();

							List<Map<String, Object>> listSerieMap = detDeclaraDAO.select(param);
							int contador = 0;
							boolean tieneTarja = false;
							String mcdetabase = ""; 
							for (Map<String, Object> serieMap : listSerieMap) {
								ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
								List<Mcdeta> listMcdeta = manifiestoSigadService.getListMcdetaByNumeroBL( codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, serieMap.get("NUM_DOCTRANSP") .toString());
								if (listMcdeta.size() > 0) {

									Mcdeta mcdeta = listMcdeta.get(0);
									if (SunatStringUtils.isEqualTo(mcdeta.getDocumentoDeTransporte().getNumeroDocumentoTransporte().toString(),mcdetabase))
										continue;

									if (!mcdeta.getDocumentoOABL().getStrFechaInicioOperacion().equals("0")) {
										tieneTarja = true;
										break;
									} else {
										contador++;
									} 
									mcdetabase = mcdeta.getDocumentoDeTransporte().getNumeroDocumentoTransporte().toString();
								} else {
									grabaTelelog(listError, "00122", "DOCUMENTO DE TRANSPORTE NO REGISTRADO EN MANIFIESTO ENVIADO");
								}
							}
							if (contador >= 1 && !tieneTarja) {
								grabaTelelog(listError, "11508", "NO SE HA REALIZADO EL PROCESO DE TARJA PARA EL DOCUMENTO DE TRANSPORTE");
							}
						} else { // Para manifiestos NSIGAD 

							List<Map<String, Object>> listSerieMap = detDeclaraDAO.select(param);
							int contador = 0;
							boolean tieneTarja = false;
							String DocTransportebase = ""; 
							for (Map<String, Object> serieMap : listSerieMap) {

								List<DocumentoDeTransporte> listDocTransporte = obtenerDocumentosDeTransporte(manifiesto, serieMap);
								// Verifica si existen registros para el B/L
								if (listDocTransporte.size() == 0) {
									grabaTelelog(listError, "00122", "DOCUMENTO DE TRANSPORTE NO REGISTRADO EN MANIFIESTO ENVIADO");
								}

								DocumentoDeTransporte docTransporte = listDocTransporte.get(0);
								if (SunatStringUtils.isEqualTo(docTransporte.getNumeroDocumentoTransporte().toString(), DocTransportebase))
									continue;

								Map<String, Object> paramsMap = new HashMap<String, Object>();
								paramsMap.put("numeroCorrelativo",	manifiesto.getNumeroCorrelativo());
								paramsMap.put("numeroDeDetalle", docTransporte.getNumeroDeDetalle());
								paramsMap.put("tipoEnvio",	ConstantesDataCatalogo.TIPO_ENVIO_NOTATARJA);
								paramsMap.put("indicadorEliminacion", IND_REGISTRO_ACTIVO);
								DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
								List<DocumentoOABL> listTarja = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(paramsMap);
								if (listTarja.size() > 0) {
									tieneTarja = true;
									break;								
								} else {
									contador++;
								}
								DocTransportebase = docTransporte.getNumeroDocumentoTransporte().toString();
							}
							if (contador >= 1 && !tieneTarja) {
								grabaTelelog(listError, "11508", "NO SE HA REALIZADO EL PROCESO DE TARJA PARA EL DOCUMENTO DE TRANSPORTE");
							}
						}

					} else {
						grabaTelelog(listError, "09017", "NUMERO DE MANIFIESTO INVALIDO");
						return listError;
					}
				}
			}// ESM - FIN

			//Si es Numeracion ��o Rectificacion???
			if ( (codTransaccion.endsWith("01")||codTransaccion.endsWith("03")  || isTxDilig)  &&
					((esExcepcional && tieneDatar)||
							esUrgente || esAnticipado)
					){

				Map<String,Object> dataManif = new HashMap<String,Object>();
				Manifiesto listManifiesto = null;
				//Verificamos que este presente el manifiesto y todos los datos de la PK del manifiesto
				//antes de buscar para evitar fullscans a la BD

				String codaduamanif=manif.getCodaduamanif();
				String annmanif=SunatStringUtils.length(manif.getAnnmanif())>3?manif.getAnnmanif().substring(0,4):null;
				String nummanif=manif.getNummanif();
				String codmodtransp=manif.getCodmodtransp();
				String codtipmanif  = manif.getCodtipomanif();

				//P34 AMANCILLA CORRECCION NUM_MANIFIESTO BIENE CON CERO
				if(isTxDilig && esAnticipado && "0".equals(nummanif)){
					manif.setNummanif(null);
				}
				//fin

				dataManif.put("numeroManifiesto", SunatStringUtils.lpad(nummanif,6,' '));
				dataManif.put("anioManifiesto",  annmanif);
				dataManif.put("codigoAduana", codaduamanif);
				dataManif.put("codigoTipoManifiesto", codtipmanif);
				dataManif.put("codigoViaTransporte", codmodtransp);
				
				//PAS20181U220200049 se considera desde aqui:
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);
				
				//Pase PAS20181U220200049 - Inicio
				Boolean exonerarEvalEmpTransporte = false;
				if (!CollectionUtils.isEmpty(MapaValManNum)){
					//if(codTransaccion.endsWith("01") && esExcepcional){
					//CAMBIOS PARA LA RECTIFICACION MOL
					if(ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) || ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {	// Pase 19
						if( manif!=null && manif.getEmpTransporte()!=null && manif.getEmpTransporte().getNumeroDocumentoIdentidad()==null){
							exonerarEvalEmpTransporte = true;
					    }else{
					    	boolean seEnvioEmpTransporteEnXML = variablesIngreso.get("seEnvioEmpTransporteEnXML")!=null?(Boolean)variablesIngreso.get("seEnvioEmpTransporteEnXML"):false;
					    	
					    	/**se limit� que en los casos de sda si se va a cargar por sistema la empresa de transporte
					    	 * por lo tanto solo SDA va a tener el codigo de warning
					    	 * 70147 - LOS DATOS DEL TRANSPORTISTA SE OBTIENEN DE LA INFORMACION REGISTRADA PARA EL MANIFIESTO {0}
					    	 */
					    	Manifiesto manifiesto = null;//pase64 para reutilizar
							manifiesto = obtenerManifiesto( manif,  declaracion, listaOMA, fechaReferencia); 
					    	
					    	if(seEnvioEmpTransporteEnXML && manifiesto!=null  ) {//Numero de manifiesto (Tipo - Via - Aduana - Anio - Numero)
						    	if(!manifiesto.isEsSigad()){	
						    		if(manif!=null && manif.getEmpTransporte()!=null) {
						    			if(manif.getNummanif()==null)manif.getEmpTransporte().setNumeroDocumentoIdentidad(null);
						    		}
						    			
							    	grabaTelelog(listError,"70147", new Object[]{
							    			(manif.getCodtipomanif()!=null?manif.getCodtipomanif():"").concat("-").concat(manif.getCodmodtransp()!=null?manif.getCodmodtransp():"").concat("-")
									    	.concat(manif.getCodaduamanif()!=null?manif.getCodaduamanif():"").concat("-").concat(manif.getAnnmanif()!=null?manif.getAnnmanif().substring(0,4):"").concat("-")
									    	.concat(SunatStringUtils.lpad(manif.getNummanif()!=null?manif.getNummanif():"",6,' '))});
						    	}
					    	}
					    }
					}						
				}
				  	//Pase PAS20181U220200049 - Fin
				
				
				
				if(manif!=null && manif.getCodaduamanif()!=null && manif.getAnnmanif()!=null &&
						manif.getNummanif()!=null && manif.getCodmodtransp()!=null){
					if(esExcepcional && codmodtransp.equals("0") || esExcepcional && codmodtransp.equals("4") || codmodtransp.equals("7")){
						//variablesIngreso.put("validarManifiesto",false);
						if(codTransaccion.endsWith("03")  || isTxDilig){
							if(declaracionBDMap!=null && 
									SunatStringUtils.isEqualTo((String)declaracionBDMap.get("codviatrades"), "1")  )
							{
								variablesIngreso.put("marcaDesdatadoDatado", marcaDesdatadoDatado);//RIN13 SWF
							}
						}					 
					}
					/*RIN13FSW-INICIO esta parte no se va probar en este pase ojo hay que deshabilitaro antes de ir a produccion */
					//					<EHR>
					//vila
					//					if(codmodtransp.equals("1")){
					//						    Elementos<DatoIndicadores> listIndicadores = declaracion.getDua().getListIndicadores();
					//						    for (DatoIndicadores datoIndicadores : listIndicadores) {
					//								if(datoIndicadores.getCodtipoindica().equals("933") && datoIndicadores.getNombre().equals("NO")){
					//									marcaDesdatadoDatado = false;
					//						   }
					//					   }					 
					//						    variablesIngreso.put("marcaDesdatadoDatado",marcaDesdatadoDatado);
					//					}
					//					</EHR>
					/*RIN13FSW-FIN*/
					

					//listManifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
					
					/***PAS20181U220200049 inicio***/
					if(!ResponseListManager.responseListHasErrors(listaOMA)){
						boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
						listManifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true, fechaReferencia,considerarEER);
					}else{/***PAS20181U220200049 fin***/
						listManifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
					}
					
				}else{
					if(esUrgente || esAnticipado){
						variablesIngreso.put("validarManifiesto",false);//Indicador para que que no date
						return listError; //retornamos sin datar en caso de Urgentes y Anticipados sin Manifiesto
					}
				}

				//verificamos si la Declaracion cuenta con Indicador de Manifiesto
				IndicadorDuaService indicadorDuaService = (IndicadorDuaService)fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
				boolean tieneIndicadorManifiesto = indicadorDuaService.tieneIndicadorManifiesto(declaracion, codTransaccion);

				/*
				 * se revis� el RIN19 de indicador 29, si la dam tiene el indicador de exoneracion de manifiesto, 
				 * el sistema debe validar que como m�nimo tenga
				 * transmitido el nro de manifiesto y esta cabecera exista.
				 * corresponde a parchada de produccion, no est� relacionado directamente al pase 4-49, 
				 * pero se detect� en dichos pases, es soluci�n definitiva.
				 * en el valIndicadorManifiesto propio del indicador 29 se considera la modalidad
				 * los plazos se validan con el servicio valmanifCServiceImpl.fectermino
				 */
				if(listManifiesto!=null && tieneIndicadorManifiesto){
				 	return listError;
				}

				//Verificamos si con los datos transmitidos se encontr un manifiesto
				if (listManifiesto!=null ){ //Si existe el manifiesto
					Map<String,Object> paramsParticipante=new HashMap<String,Object>();
					paramsParticipante.put("numeroCorrelativo", listManifiesto.getNumeroCorrelativo());
					paramsParticipante.put("codTipoParticipante", "31");
					//List<Participante> listParticipante=FormatoAServiceImpl.getInstance().getParticipanteDAO().findParticipantesByMap(paramsParticipante);
					List<Participante> listParticipante=((ParticipanteDocDAO)fabricaDeServicios.getService("participanteDAO")).findParticipantesByMap(paramsParticipante);
					//ggranados 15-252 puede tener mas de 1 participante tipo 31
					boolean tieneParticipante31 = false;
					if (listParticipante!=null && !listParticipante.isEmpty()){
						for (Participante participante31 : listParticipante) {
							String numrucParticipante=participante31.getNumeroDocumentoIdentidad();
							if (numrucParticipante.equals(dua.getNumruclugarecep())){
								tieneParticipante31 = true;
								break;								
							}
						}
						/*	if(!tieneParticipante31){
							grabaTelelog(listError,"30333", new Object[]{dua.getNumruclugarecep(),SunatStringUtils.lpad(manif.getNummanif(),6,' ')});
						}*/
						/*Participante participante=listParticipante.get(0);
						String numrucParticipante=participante.getNumeroDocumentoIdentidad();
						//se comenta a pedido de normativo
						/*if (!numrucParticipante.equals(dua.getNumruclugarecep()))
							grabaTelelog(listError,"30333", new Object[]{dua.getNumruclugarecep(),SunatStringUtils.lpad(manif.getNummanif(),6,' ')});*/
					}//

					//se reubica codigo mas arriba pase49
					
					//r2bz validamos al transportista, que debe coincidir con el del manifiesto, solo para el NSIGAD - solo aplica cuando no esta la vigencia del OMA - PAS20181U220200049
					//if(ResponseListManager.responseListHasErrors(listaOMA)){/***PAS20181U220200049 inicio***/
					// se cambia a vigencia de la rin, esta regla de negocio no condiciona si sale o no oma
					if(esVigenteRIN05PrimeraParte){/***PAS20181U220200064 inicio***/
						if ( listManifiesto.getClass() == Manifiesto.class && (!listManifiesto.isEsSigad())) {
							Participante empTransporteMAN = listManifiesto.getTransportista();
							Participante empTransporteDUA = manif.getEmpTransporte();
							if (!empTransporteMAN.getNumeroDocumentoIdentidad().equals(empTransporteDUA.getNumeroDocumentoIdentidad()) ||
									!empTransporteMAN.getTipoDocumentoIdentidad().getCodDatacat().equals(empTransporteDUA.getTipoDocumentoIdentidad().getCodDatacat())) {

								//LMVR - 140
								//grabaTelelog(listError,"30032", new Object[]{dua.getNumruclugarecep(),SunatStringUtils.lpad(manif.getNummanif(),6,' ')});
								grabaTelelog(listError,"30032", new Object[]{empTransporteDUA.getNumeroDocumentoIdentidad(),manif.getCodmodtransp(),manif.getCodtipomanif(),manif.getCodaduamanif(), manif.getAnnmanif().substring(0,4), SunatStringUtils.lpad(manif.getNummanif(),6,' '),empTransporteDUA.getTipoDocumentoIdentidad().getCodDatacat()});
								//EMPRESA DE TRANSPORTE "{6}-{0}" ASOCIADO AL MANIFIESTO "{1}-{2}-{3}-{4}-{5}" INVALIDO 
							}
//							else{
//
//								String numeroRUCempresaTrans = empTransporteDUA.getNumeroDocumentoIdentidad();
//								SoporteService soporteService = fabricaDeServicios.getService("soporteServiceDef");
//								Map<String, Object> rptaRuc = soporteService.obtenerPerNatJur("4",numeroRUCempresaTrans);
//								String estadoRUC = (String) rptaRuc.get("estadoRUC");
//								if(!"00".equals(estadoRUC) && !codTransaccion.endsWith("03")){
//									grabaTelelog(listError,"30741", new Object[]{numeroRUCempresaTrans});		
//									return listError;
//								}
//							}
						}
					}//esto siempre va a validar igual no debe salir error, xq se setea en valcabduaServiceImpl.setupDeclaracion
					else{
						if (codmodtransp.equals(ConstantesDataCatalogo.VIA_TRANSPORTE_MARITIMA) && listManifiesto.getClass() == Manifiesto.class) {
							Participante empTransporteMAN = listManifiesto.getTransportista();
							Participante empTransporteDUA = manif.getEmpTransporte();
							if (!empTransporteMAN.getNumeroDocumentoIdentidad().equals(empTransporteDUA.getNumeroDocumentoIdentidad()) ||
									!empTransporteMAN.getTipoDocumentoIdentidad().getCodDatacat().equals(empTransporteDUA.getTipoDocumentoIdentidad().getCodDatacat())) {

								//LMVR - 140
								//grabaTelelog(listError,"30032", new Object[]{dua.getNumruclugarecep(),SunatStringUtils.lpad(manif.getNummanif(),6,' ')});
								grabaTelelog(listError,"30032", new Object[]{empTransporteDUA.getNumeroDocumentoIdentidad(),manif.getCodmodtransp(),manif.getCodtipomanif(),manif.getCodaduamanif(), manif.getAnnmanif().substring(0,4), SunatStringUtils.lpad(manif.getNummanif(),6,' '),empTransporteDUA.getTipoDocumentoIdentidad().getCodDatacat()});
								//EMPRESA DE TRANSPORTE "{6}-{0}" ASOCIADO AL MANIFIESTO "{1}-{2}-{3}-{4}-{5}" INVALIDO 
							}else{

								String numeroRUCempresaTrans = empTransporteDUA.getNumeroDocumentoIdentidad();
								SoporteService soporteService = fabricaDeServicios.getService("soporteServiceDef");
								Map<String, Object> rptaRuc = soporteService.obtenerPerNatJur("4",numeroRUCempresaTrans);
								String estadoRUC = (String) rptaRuc.get("estadoRUC");
								if(!"00".equals(estadoRUC) && !codTransaccion.endsWith("03")){
									grabaTelelog(listError,"30741", new Object[]{numeroRUCempresaTrans});		
									return listError;
								}
							}
						}
						
					}
					
					
					
					

					//Obtenemos la Fecha Programada de Llegada del Manifiesto de la Base de Datos,
					//Para en el caso de las urgentes verificar si es anticipada o excepcional
					//NSR: A partir del 17/02/2011 se verifica primero si es que tiene ya fecha de Llegada Definitiva
					Date fecProgramadaLlegada = listManifiesto.getFechaEfectivaDeLlegada();
					Date fecTerminoDeDescarga = listManifiesto.getFechaTerminoDeDescarga();
					//En caso no tenga o sea igual a la fecha default usamos la fecha Programada
					if(fecProgramadaLlegada == null || SunatDateUtils.sonIguales(fecProgramadaLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
						fecProgramadaLlegada = listManifiesto.getFechaProgramadaLlegada();
					}
					if(esUrgente){
						if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaDeclaracion!=null?fechaDeclaracion:fechaReferencia, fecProgramadaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){//se adiciona la condicion de fechaReferencia por TRX1001(toma la current bug 18790)
							esUrgenteAnticipada = true;
							variablesIngreso.put("esUrgenteAnticipada", esUrgenteAnticipada);
							variablesIngreso.put("esUrgenteExcepcional", esUrgenteExcepcional);
						} else {
							esUrgenteExcepcional = true;
							variablesIngreso.put("esUrgenteAnticipada", esUrgenteAnticipada);
							variablesIngreso.put("esUrgenteExcepcional", esUrgenteExcepcional);
							if (SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
								esUrgenteAnticipada = true;
								esUrgenteExcepcional = false;
								variablesIngreso.put("esUrgenteAnticipada", esUrgenteAnticipada);
								variablesIngreso.put("esUrgenteExcepcional", esUrgenteExcepcional);						
							}					
						}
					}
					if(esExcepcional){
						Date fecLlegada = null;
						if (listManifiesto instanceof Mcdage){
							fecLlegada = listManifiesto.getFechaProgramadaLlegada();						
						} else {
							fecLlegada = listManifiesto.getFechaEfectivaDeLlegada();													
						}

						//se verifica que tenga fecha de llegada real 
						if(fecLlegada == null || SunatDateUtils.sonIguales(fecLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
							grabaTelelog(listError,"08066","MANIFIESTO NO HA REGISTRADO LA FECHA DE LLEGADA");
							return listError;
						}						
						esExcepcionalConTD = true;
						if (fecTerminoDeDescarga == null  || SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
							esExcepcionalSinTD = true;
							esExcepcionalConTD = false;														
						}
					}

					//Agregamos las validaciones que se quitaron del servicio de Datado
					Map<String,Object> mapParam = new HashMap<String,Object>();
					mapParam.put("regimenDua", dua.getCodregimen());
					Map<String,?> mapResult=new HashMap<String,Object>();
					//r2bz por lo pronto para diligencias no validar las fecha de llegada y termino de la descarga
					//hasta que salga los pases de fecha de llegada donde se agrega nueva columna y actualice automaticamente la dua
					if (!isTxDilig){

						if(!SunatDateUtils.sonIguales(fechaTerminoDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) && codTransaccion.endsWith("03") ){//bug 18790
							esUrgenteAnticipada= false;
						}

						if (esAnticipado || esUrgenteAnticipada || esExcepcionalSinTD){
							//Bug 17690 - PAS20145E220000105-LVP NUMERACION DE ANTICIPADA CON FECHA DE LLEGADA

							/*cambios por bug blocker arey pase 105*/
							//if(variablesIngreso.get("fechaProgramadaLlegada")!=null){
							//mapParam.put("fechaLlegada",variablesIngreso.get("fechaProgramadaLlegada"));
							//	Map<Object,Object>  varIngresoManif= (Map<Object, Object>) variablesIngreso.get("manifiestomap");
							//Manifiesto varIngresoManif= (Manifiesto) variablesIngreso.get("manifiestomap");//variable es una lista								
							//	if(varIngresoManif!=null && varIngresoManif.get("fechaProgramadaLlegada")!=null){
							//			mapParam.put("fechaLlegada",varIngresoManif.get("fechaProgramadaLlegada"));
							/*fin de cambios por bug blocker arey pase 105*/

							//		}else{ 
							Date fechaTerm = manif!=null?manif.getFectermino():null;
							if(SunatDateUtils.sonIguales(fechaTerm, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
								mapParam.put("fechaLlegada", fechaTerminoDescargaXML);
							}else{
								mapParam.put("fechaLlegada", fechaTerm);
							}

							/* ONEYRAJ PAS20144E610000245 INICIO */
							mapParam.put("codModalidad", dua.getCodmodalidad());
							mapParam.put("codTransaccion", codTransaccion);
							mapParam.put("numManif", manif.getNummanif());
							/* ONEYRAJ PAS20144E610000245 FIN */
							//	}
							//mordonezl pase70
							//
							// PAra que no valida la fecha de llegad para las acogidas a ISVM
							if (!codTransaccion.startsWith("99")){
								mapResult=validarFechaLlegadaManifiesto(mapParam,listManifiesto);
							}
							//fin
						} else if (esExcepcionalConTD || esUrgenteExcepcional){
							//bug 18506
							//if(fechaTerminoDescargaXML!=null){
							//	mapParam.put("fechaTerminoDeDescarga", fechaTerminoDescargaXML);
							//}else {
							mapParam.put("fechaTerminoDeDescarga", manif!=null?manif.getFectermino():null);
							//}
							mapParam.put("fechaNumeracionDua",fechaReferencia);

							//mordonezl pase70
							mapResult=validarFechaTerminoDescargaManifiesto(mapParam,listManifiesto);
							//fin
						}
					}
					if (mapResult.containsKey(ResponseMapManager.KEY_CODIGO)){

						Map<String, String> mapError = new HashMap<String, String>();
						mapError.put(ResponseMapManager.KEY_CODIGO, (String)mapResult.get(ResponseMapManager.KEY_CODIGO));		
						mapError.put(ResponseMapManager.KEY_DESCRIPCION, (String)mapResult.get(ResponseMapManager.KEY_DESCRIPCION));
						listError.add(mapError);
						return listError;
					}
					//if (esUrgente &&( !codTransaccion.endsWith("03") || !isTxDilig  )){ //se retira esta validacion por el servicio de plazos para recti arey
					if (esUrgente &&(!(codTransaccion.endsWith("03")||codTransaccion.endsWith("08")) || !isTxDilig  )){ //se retiro para la regularizacion - INC 2016-010440
						Date fecTermDescarga = manif!=null?manif.getFectermino():null;
						//Verificamos que la fecha de Termino de la Descarga sea Menor a la fecha Actual
						if(esUrgenteExcepcional){
							Long diferencia = SunatDateUtils.getDiferenciaDiasCalendarios(fechaReferencia, fecTerminoDeDescarga) ;//se cambia SunatDateUtils.getCurrentDate() por fecha de referencia arey

							if (diferencia > 7){
								//								rango7dias = false;
								//grabaTelelog(listError,"30334","DESPACHO URGENTE INVALIDO, ES MAYOR A 7 DIAS CALENDARIO SIGUIENTES A LA FECHA DE TERMINO DE DESCARGA ENVIADA");
								//mordonezl pase70
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30334"));
								//fin
								return listError;
							}
						}else if (esUrgenteAnticipada){
							//PAS20155E220200024 - MATC 20150702 - Inicio
							//Si el Manifiesto no tiene Fecha de T�rmino de Descarga, no debe validar la diferencia de d�as
							boolean ValidarDiferenciaDias = false;
							ValidarDiferenciaDias = !SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA);
							if( ValidarDiferenciaDias ) {
								Long diferencia = SunatDateUtils.getDiferenciaDiasCalendarios( fecProgramadaLlegada,fechaReferencia);//se cambia SunatDateUtils.getCurrentDate() por fecha referencia arey
								if (Math.abs(diferencia) > 15){
									//								rango7dias = false;
									//grabaTelelog(listError,"30561","DESPACHO URGENTE INVALIDO, ES MAYOR A 15 DIAS CALENDARIO ANTES DE LA FECHA DE LLEGADA");
									//mordonezl pase70
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30561"));

									//fin
									return listError;
								}
								//PAS20155E220200024 - MATC 20150702 - Fin
							}
							/*Se adiciona por caso de fechRef mayor a la fecha prog llegada del manif es la inversa de la eval anterior bug 18844 arey*/
							//							if(SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia, fecProgramadaLlegada,SunatDateUtils.COMPARA_SOLO_FECHA)){
							//									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30561"));//bug 18844 
							//									return listError;
							//							}
						}
					}

				} else {//No encontro Manifiesto
					/**
					 * Ahora ya se valida inicialmente el manifiesto tanto el N como en el A, de no encontrarse en ninguno defrente mandamos el error
					 */
					//mordonezl pase70
					//					Map<String, String> mapError = ResponseMapManager.getErrorResponseMap("11000", "El manifiesto no existe "+
					//																	dataManif.get("codigoTipoManifiesto")+"-"+
					//																	dataManif.get("codigoViaTransporte") +"-"+
					//																	dataManif.get("codigoAduana")+"-"+
					//																	dataManif.get("anioManifiesto")+"-"+
					//																	dataManif.get("numeroManifiesto") );
					if(dataManif.get("numeroManifiesto")!=null && dataManif.get("codigoTipoManifiesto")!= null && dataManif.get("codigoViaTransporte") != null && dataManif.get("codigoAduana") != null && dataManif.get("anioManifiesto")  != null 
							&&	!SunatStringUtils.isEmptyTrim(dataManif.get("numeroManifiesto").toString()) &&	!SunatStringUtils.isEmptyTrim(dataManif.get("codigoTipoManifiesto").toString()) 
							&&	!SunatStringUtils.isEmptyTrim(dataManif.get("codigoViaTransporte").toString()) &&	!SunatStringUtils.isEmptyTrim(dataManif.get("codigoAduana").toString())
							&&	!SunatStringUtils.isEmptyTrim(dataManif.get("anioManifiesto").toString()) ){
						String numeroManifiesto =  dataManif.get("codigoTipoManifiesto")+"-"+ dataManif.get("codigoViaTransporte") +"-"+ 
								dataManif.get("codigoAduana")+"-"+	dataManif.get("anioManifiesto")+"-"+ dataManif.get("numeroManifiesto");
						Map<String, String> mapError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("12098",new String[]{numeroManifiesto});
						listError.add(mapError);
						
					}else{
						Map<String, String> mapError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37068");
						listError.add(mapError);
					}
					//fin mordonezl
					
					return listError;
				}

				/** NSR: Para evitar recorrer todas las series por cada DocTransporte, primero acumulamos los totales y luego
				 * recien validamos. el numero del documento de transporte esta en la lista de docSoporte
				 */
				Map<String, Map<Integer, Map<String, BigDecimal>>> mapTotalesParaDatadoXDocuTrans = new HashMap<String, Map<Integer, Map<String, BigDecimal>>>(); 

				//Llenamos los datos comunes
				//Si es Urgente agregamos el indicador de Excepcional o Anticipado
				Map<String,Object> otrosDatos = new HashMap<String, Object>();

				//MATC 20130520 - Verifica si la DUA ya tiene datado sobre lo recibido
				variablesIngreso.put("tieneDatadoSobreRecibido", existeRegistroDatadoSobreRecibido(declaracion));

				if (esUrgente){
					otrosDatos.put("esUrgenteAnticipada", esUrgenteAnticipada);
					otrosDatos.put("esUrgenteExcepcional", esUrgenteExcepcional);
				}

				if (esUrgente || esAnticipado) {
					if( codTransaccion.endsWith("03") || isTxDilig  ) {  
						otrosDatos.put("tieneDatadoSobreRecibido", variablesIngreso.get("tieneDatadoSobreRecibido") );
					}
				}

				otrosDatos.put("fechaReferencia", fechaReferencia);
				//M_SNADE278 rtineo
				Boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
				otrosDatos.put("isDAMDiferidaSinIca", isDAMDiferidaSinIca);
				otrosDatos.put("esVigenteRIN05PrimeraParte", esVigenteRIN05PrimeraParte);
				
				//M_SNADE278 end
				Map<String,Object> datosComunes = GeneralUtils.getDatosFijosDatadoValidacion(declaracion, codTransaccion, otrosDatos);
				//LLenamos el mapa con los datos de pesos y bultos por cada Documento de Transporte
				//El metodo totalesParaDatadoPorDocTra se encarga de realizar las sumatorias para todas las series
				mapTotalesParaDatadoXDocuTrans = GeneralUtils.totalesParaDatadoPorDocTra(declaracion);
				//Declaramos una Lista para almacenar los datos que seran reutilizados al momento de grabar
				List<Map<String,Object>> listaParaDatado = new ArrayList<Map<String,Object>>();
				Boolean hayErroresDatado = false;

				//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuaci�n a la destinaci�n con punto de llegada deposito aduanero sin transmitir regimen precedente 70 
				DataCatalogo catVigenciaValidacion_0023 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN, "0023", new java.util.Date());
				boolean flagVigencia_0023 = catVigenciaValidacion_0023 != null ? true : false;
				//Fin M_SNADE255-2

				//Por cada documento de transporte de la declaracion Validamos el Datado
				for(DatoDocTransporte docTransporte:declaracion.getDua().getListDocTransporte()){
					Map<String,Object> dataDua=new HashMap<String, Object>();
					//Buscamos el docTransporte en el mapa, si est� entonces extraemos los datos calculados
					//Pesos y Bultos
					if(mapTotalesParaDatadoXDocuTrans.containsKey(docTransporte.getNumdoctransporte())){
						/*branch ingreso 2011-009 hosorio inicio 17/08/2011*/
						// si es rectificacion solo se agrega si una ve por detalle
						if( (codTransaccion.endsWith("03")  || isTxDilig )&& SunatNumberUtils.isGreaterThanZero(docTransporte.getNumdetalle())){
							boolean existeDetalle=false;
							for(Map<String,Object> data:listaParaDatado){
								if(  
										SunatStringUtils.isEqualTo((String)data.get("numeroDocumentoTransporte"), 
												docTransporte.getNumdoctransporte())
										&&
										SunatNumberUtils.isEqual((Integer)data.get("numeroDeDetalle"), 
												docTransporte.getNumdetalle())										
										){
									existeDetalle=true;
									break;
								}
							}
							if(!existeDetalle)
								dataDua.putAll(GeneralUtils.getDatosCalculados(declaracion, docTransporte, mapTotalesParaDatadoXDocuTrans));
							else
								continue;

						}else{						
							dataDua.putAll(GeneralUtils.getDatosCalculados(declaracion, docTransporte, mapTotalesParaDatadoXDocuTrans));
						}
					} else {
						continue;
					}
					//Agregamos los datos fijos
					dataDua.putAll(datosComunes);
					//Agregamos los datos correspondientes al Documento de Transporte
					dataDua.putAll(GeneralUtils.getDatosVariablesDatado(declaracion, docTransporte));

					/*Inicio PAS20181U220200049 se adiciona al datado para que lo considere en la busqueda interna que realiza de bd*/
					if(!ResponseListManager.responseListHasErrors(listaOMA)){
						boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
						dataDua.put("fechaReferencia", fechaReferencia);
						dataDua.put("considerarEER", considerarEER?"1":"0");
						dataDua.put("esOMA", "1");
					}
					/*Fin*/
					
					Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
					Map<String,?> mapDatado=datado2Service.validarDatado(dataDua);
					// se agrega por el bug  Bug 17419 
					/*if(mapDatado!= null && mapDatado.size()>0){
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("NUM_CORREDOC", listManifiesto.getNumeroCorrelativo());
						param.put("NUM_DOCTRANSP", dataDua.get("numeroDocumentoTransporte"));
						param.put("puertoEmbarque", dataDua.get("puertoEmbarque"));
						Map<String, String> mapError =  validarPuertoEmbarqueDocTransporte(listManifiesto,param);
						if(mapError.get("desError")!=null && !"".equals(mapError.get("desError").toString()))
						{	listError.add(mapError);
							return listError;
						}	
					}*/

					//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuaci�n a la destinaci�n con punto de llegada deposito aduanero sin transmitir regimen precedente 70
					if(flagVigencia_0023 && dua.getCodlugarecepcion().equals(Constants.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO)){
						boolean esEnvioDepositoAduaneroSinPrecendencia = GeneralUtils.esEnvioDepositoAduaneroSinPrecendencia(declaracion, dua, dua.getListSeries());

						if(esEnvioDepositoAduaneroSinPrecendencia){
							if(mapDatado.containsKey(ResponseMapManager.KEY_CODIGO) && mapDatado.get(ResponseMapManager.KEY_CODIGO).toString().equals(Constantes.COD_ERROR_MANIFIESTO_DATADO_11583)){
								Map<String,Object> dataDuaTmp = new HashMap<String, Object>();
								dataDuaTmp.putAll(dataDua);
								dataDuaTmp.put("tipoOperador", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);

								mapDatado = datado2Service.validarDatado(dataDuaTmp);

								if(!mapDatado.containsKey(ResponseMapManager.KEY_CODIGO)){
									dataDua.put("tipoOperador", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
									dataDua.put("tipoOperador_puntollegada3_sin_reg_precedencia", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
								}
							}
						}
					}
					//Fin M_SNADE255-2					

					if (mapDatado.containsKey(ResponseMapManager.KEY_CODIGO)){
						Map<String, String> mapError = new HashMap<String, String>();
						mapError.put(ResponseMapManager.KEY_CODIGO, (String)mapDatado.get(ResponseMapManager.KEY_CODIGO));		
						mapError.put(ResponseMapManager.KEY_DESCRIPCION, (String)mapDatado.get(ResponseMapManager.KEY_DESCRIPCION));
						listError.add(mapError);
						hayErroresDatado = true;
					}
					/* PAS20145E220000399 INICIO GGRANADOS */
					if (codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)){
						if (mapDatado.containsKey(ResponseMapManager.KEY_CODIGO)){
							if(mapDatado.get(ResponseMapManager.KEY_CODIGO).equals(Constantes.COD_ERROR_MANIFIESTO_DATADO_11512) ||
									mapDatado.get(ResponseMapManager.KEY_CODIGO).equals(Constantes.COD_ERROR_MANIFIESTO_DATADO_11511)){
								Map<String, String> mapError = new HashMap<String, String>();
								mapError.put(ResponseMapManager.KEY_CODIGO, "35274");
								mapError.put(ResponseMapManager.KEY_DESCRIPCION, 
										((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35274").get(ResponseMapManager.KEY_DESCRIPCION));								
								listError.add(mapError);
							}
						}
					}
					/* PAS20145E220000399 FIN GGRANADOS */

					/*Para evitar volver a Calcular todos estos datos en caso de que se decida Numerar la Dua
					 *almacenamos estos resultados en una lista, y solo en el caso de que no haya errores, 
					 */
					if ( ! hayErroresDatado){ //Si no hay errores guardamos
						listaParaDatado.add(dataDua);
						variablesIngreso.put("validarManifiesto",true);//Para indicar que grabe datado
					} else { //Si hubiera errores, liberamos la memoria y ya no grabaremos nada
						listaParaDatado.clear();
						variablesIngreso.put("validarManifiesto",false);//Para que quite el flag
					}

				}		
				//Una vez pasado todas las validaciones y si no hay errores de datado
				//Almacenamos los TotalesParaDatado en el mapa variablesIngreso para evitar volver a calcularlo en el servicio de Grabaci�n
				if (( ! hayErroresDatado)){
					variablesIngreso.put("marcaDesdatadoDatado", marcaDesdatadoDatado);//RIN13 SWF
					variablesIngreso.put("Datado.listaParaDatado",listaParaDatado);				
				}

			}
		}

		return listError;
	}


	private Manifiesto obtenerManifiesto(DatoManifiesto manif, Declaracion declaracion, List<Map<String,String>> listaOMA, Date fechaReferencia) {
		Map<String, Object> dataManif = new HashMap<String, Object>();
		ManifiestoService manifiestoService =  fabricaDeServicios.getService("manifiesto.manifiestoService");

		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();

		dataManif.put("numeroManifiesto",SunatStringUtils.lpad(nummanif, 6, ' '));
		dataManif.put("anioManifiesto", annmanif);
		dataManif.put("codigoAduana", codaduamanif);
		dataManif.put("codigoTipoManifiesto", codtipmanif);
		dataManif.put("codigoViaTransporte", codmodtransp);
		
		boolean buscarManifiestoSigadActual = false;

		//buscarManifiestoSigadActual = ("4".equals(dua.getManifiesto().getCodmodtransp()) || "7".equals(dua.getManifiesto().getCodmodtransp()));
		buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(declaracion.getDua().getManifiesto().getCodmodtransp()) 
				|| ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(declaracion.getDua().getManifiesto().getCodmodtransp()));
		
		/***PAS20181U220200049 inicio***/
		Manifiesto manifiesto = null;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true,fechaReferencia,considerarEER);
		}else{
			 manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, buscarManifiestoSigadActual); 
		}/***PAS20181U220200049 fin***/
		
		return manifiesto;
	}
	
	private String existeRegistroDatadoSobreRecibido(Declaracion decla) {
		Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
		String existeDatado = "N";
		if( decla.getNumeroDeclaracion() != null ) {

			List<String> listaDistintoTipoDatado = new ArrayList<String>();
			listaDistintoTipoDatado.add("1");
			listaDistintoTipoDatado.add("8");
			listaDistintoTipoDatado.add("B"); 
			listaDistintoTipoDatado.add("C");
			listaDistintoTipoDatado.add("M");

			DatoManifiesto manif = 	decla.getDua().getManifiesto();
			String codaduamanif=manif.getCodaduamanif();
			String annmanif=SunatStringUtils.length(manif.getAnnmanif())>3?manif.getAnnmanif().substring(0,4):null;
			String nummanif=manif.getNummanif();
			String codmodtransp=manif.getCodmodtransp();
			String codtipmanif  = manif.getCodtipomanif();

			String  adudua = decla.getDua().getCodaduanaorden();
			String  regdua = decla.getDua().getCodregimen();
			//Integer anodua = decla.getDua().getAnnorden();//PAS20175E220200063 REQ 2017-056815
			Integer anodua = decla.getDua().getFecdeclaracion()!=null?SunatDateUtils.getIntegerFromDate(decla.getDua().getFecdeclaracion()):SunatDateUtils.getIntegerFromDate(new Date()); //PAS20175E220200063
			anodua = SunatNumberUtils.getAnioFromDate(anodua); //PAS20175E220200063
			String  numdua = SunatStringUtils.lpad(decla.getNumeroDeclaracion().toString(),6,'0');
			Map<String, ?> mapErrors = datado2Service.existeRegistroDUADatada( regdua, numdua, anodua, adudua, codaduamanif, codtipmanif, codmodtransp, 
					Integer.valueOf(annmanif), SunatStringUtils.lpad(nummanif,6,' '), listaDistintoTipoDatado);  

			existeDatado = mapErrors.isEmpty() ? "S" : "N";
		}
		return existeDatado;
	}

	//glazaror... metodo optimizado
	@ServicioAnnot(tipo="V",codServicio=3391, descServicio="Validaciones referentes a indicadores de motores, partes y piezas usadas (optimizado)")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=9148,numSecEjec=503,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> valEstadoPiezasVehiculosTerrestres(Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA dua = declaracion.getDua();

		//glazaror... preferible obtener solo una vez los servicios de la fabrica 
		SubPartidaNacionalTratoPreferencialService subPartidaNacionalTratoPreferencialService = fabricaDeServicios.getService("subPartidaNacionalTratoPreferencialService");
		EstadoMercanciaTratoPreferencialService estadoMercanciaTratoPreferencialService = fabricaDeServicios.getService("estadoMercanciaTratoPreferencialService");
		for (DatoSerie serie : dua.getListSeries()) {
			//Map<String, String> result = subPartidaNacionalTratoPreferencialService.validarSubPartidaMotoresPiezasUsados(serie, fechaReferencia) ;
			//glazaror... hacemos uso del nuevo metodo que trabaja con variablesIngreso
			Map<String, String> result = subPartidaNacionalTratoPreferencialService.validarSubPartidaMotoresPiezasUsados(serie, fechaReferencia, variablesIngreso);
			//result es vac�o cuando la partida est� incluida en el DS 053-2010-MTC  
			if (result.isEmpty()) {
				//				String indmotores= serie.getIndParteVehiculo()==null?"0":serie.getIndParteVehiculo();
				String indmotores= serie.getIndParteVehiculo()!=null?serie.getIndParteVehiculo():" ";//ajuste por SAU20153D211400039
				boolean NoValidaEstado = false;
				//glazaror... hacemos uso del nuevo metodo que trabaja con variablesIngreso
				Map<String,String> resultAnexo3 = subPartidaNacionalTratoPreferencialService.validarSubPartidaMotoresPiezasExoneradas(serie.getNumserie().toString(), serie.getNumpartnandi().toString(), fechaReferencia, variablesIngreso); 
				NoValidaEstado =  ( resultAnexo3.isEmpty() && (("1").equals(indmotores) || ("0").equals(indmotores)) );//ajuste por SAU20153D211400039 

				if( !NoValidaEstado ) {
					//glazaror... hacemos uso del nuevo metodo que trabaja con variablesIngreso
					Map<String,String> resultEstado = estadoMercanciaTratoPreferencialService.validarEstadoUsadoMercancia(serie.getNumserie().toString(),serie.getCodestamerca(),fechaReferencia, variablesIngreso); 
					if (!resultEstado.isEmpty()) {
						grabaTelelog(listError,"30662",new Object[]{serie.getNumserie()});
					}
				}
			}
			else {
				if( serie.getIndParteVehiculo()!=null && !serie.getIndParteVehiculo().isEmpty() && !"0".equals(serie.getIndParteVehiculo())) /*PAS20155E220000501*/ // por defecto es 0 no tiene indicador
					grabaTelelog(listError,"30790",new Object[]{serie.getNumserie(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(),10,'0')});
			}
		}
		return listError;
	}

	//pvrc valEstadoPiezasVehiculosTerrestres 
	@ServicioAnnot(tipo="V",codServicio=3391, descServicio="Validaciones referentes a indicadores de motores, partes y piezas usadas")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=3391,numSecEjec=503,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")

	public List<Map<String, String>> valEstadoPiezasVehiculosTerrestres(Declaracion declaracion, Date fechaReferencia ) {

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA dua = declaracion.getDua();
		for (DatoSerie serie : dua.getListSeries()) {
			SubPartidaNacionalTratoPreferencialService subPartidaNacionalTratoPreferencialService = fabricaDeServicios.getService("subPartidaNacionalTratoPreferencialService");
			Map<String, String> result = subPartidaNacionalTratoPreferencialService.validarSubPartidaMotoresPiezasUsados(serie, fechaReferencia) ;
			//result es vac�o cuando la partida est� incluida en el DS 053-2010-MTC  
			if (result.isEmpty()) {
				//				String indmotores= serie.getIndParteVehiculo()==null?"0":serie.getIndParteVehiculo();
				String indmotores= serie.getIndParteVehiculo()!=null?serie.getIndParteVehiculo():" ";//ajuste por SAU20153D211400039
				boolean NoValidaEstado = false;
				Map<String,String> resultAnexo3 = subPartidaNacionalTratoPreferencialService.validarSubPartidaMotoresPiezasExoneradas(serie.getNumserie().toString(), serie.getNumpartnandi().toString(), fechaReferencia); 
				NoValidaEstado =  ( resultAnexo3.isEmpty() && (("1").equals(indmotores) || ("0").equals(indmotores)) );//ajuste por SAU20153D211400039 

				if( !NoValidaEstado ) {
					EstadoMercanciaTratoPreferencialService estadoMercanciaTratoPreferencialService = fabricaDeServicios.getService("estadoMercanciaTratoPreferencialService");
					Map<String,String> resultEstado = estadoMercanciaTratoPreferencialService.validarEstadoUsadoMercancia(serie.getNumserie().toString(),serie.getCodestamerca(),fechaReferencia); 
					if (!resultEstado.isEmpty()) {
						grabaTelelog(listError,"30662",new Object[]{serie.getNumserie()});
					}
				}
			}
			else {
				if( serie.getIndParteVehiculo()!=null && !StringUtils.isEmpty(serie.getIndParteVehiculo()) ) /*PAS20155E220200035*/
					grabaTelelog(listError,"30790",new Object[]{serie.getNumserie(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(),10,'0')});
			}
		}
		return listError;
	}


	
	//296
	@ServicioAnnot(tipo = "V", codServicio = 3390)
	@ServInstDetAnnot(tipoRpta = {0}, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 3390, numSecEjec = 502, nomClase = "pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA")

	public List<Map<String, String>> valAyudaHumanitaria(Declaracion declaracion) {
		DUA dua = declaracion.getDua();
		String indSocorro=dua.getIndSocorro();
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String modal=dua.getCodmodalidad();
		String tipoTratamiento=dua.getCodtipotratamiento();
		String codprodurgente = declaracion.getDua().getCodprodurgente();
		//PAS20165E220200127 //PAS20175E220200059 validacion de incisos se realiza mas adelante
		//if(SunatStringUtils.isEqualTo(modal, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) && !"S".equals(dua.getIndSocorro())){
		//		if (!SunatStringUtils.include(codprodurgente, new String[]{ConstantesDataCatalogo.DESP_URG_ORGANOSYSANGRE, 
		//				ConstantesDataCatalogo.DESP_URG_MEDICAYVACUNAS,ConstantesDataCatalogo.DESP_URG_PRODINTENDENTE })){
		//	grabaTelelog(listError,"30657","AYUDA HUMANITARIA DEBE CORRESPONDER A UNA DECLARACION DE ENVIO URGENTE INCISOS A, G, o N, O DE ENVIO DE SOCORRO"); //PAS20175E220200055
		//			return listError;
		//		}
		//}
		boolean esAyudaHumanitaria9805=false;
		boolean todaSerieEsAyudaHumanitaria=true;

		for (DatoSerie serie : dua.getListSeries()) {
			String partida = String.valueOf(serie.getNumpartnandi());
			String codlibe = String.valueOf(serie.getCodliberatorio());

			if( Constants.PARTIDA_AYUDA_HUMANITARIA_GENERAL.equals(partida)) {
				esAyudaHumanitaria9805=true;
			}
			if(!Constants.PARTIDA_AYUDA_HUMANITARIA_GENERAL.equals(partida)) {  
				todaSerieEsAyudaHumanitaria=false;
				//PAS20165E220200127
				if(esAyudaHumanitaria9805==true){
					grabaTelelog(listError, "31915", new Object[] { serie.getNumserie(),partida });
				}
			}
			if( Constants.PARTIDA_AYUDA_HUMANITARIA_DIPLOMATICOS.equals(partida) && !"4459".equals(codlibe)) {
				grabaTelelog(listError,"30661",new Object[]{serie.getNumserie()});	
			}
		}//Final FOR

		if (esAyudaHumanitaria9805==true) {
			if (todaSerieEsAyudaHumanitaria==false) {
				grabaTelelog(listError,"30660","TODAS LAS SERIES DE LA DECLARACION DEBEN CORRESPONDER A LA SPN DE AYUDA HUMANITARIA 9805000000");
			}
			//PAS20165E220200127
			if ("S".equals(dua.getIndSocorro())&& "01".equals(dua.getCodmodalidad())
					|| !"S".equals(dua.getIndSocorro()) && SunatStringUtils.include(codprodurgente, new String[]{ConstantesDataCatalogo.DESP_URG_ORGANOSYSANGRE, 
							ConstantesDataCatalogo.DESP_URG_MEDICAYVACUNAS,ConstantesDataCatalogo.DESP_URG_PRODINTENDENTE }) //PAS20175E220200055
					|| SunatStringUtils.isEqualTo(modal, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) || SunatStringUtils.isEqualTo(modal, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)) {   

				if ("4".equals(dua.getCodtipotratamiento())) {
					Map<String, Object> paramsCatRefPartidas = new HashMap<String, Object>();
					paramsCatRefPartidas.put("tipo_uso", "DNA");
					paramsCatRefPartidas.put("cnan", Constants.PARTIDA_AYUDA_HUMANITARIA_GENERAL);
					paramsCatRefPartidas.put("finivig",SunatDateUtils.getCurrentIntegerDate()); //VERIFICAR
					paramsCatRefPartidas.put("ffinvig",SunatDateUtils.getCurrentIntegerDate());
					//					int contCatRefPartidas = FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsCatRefPartidas);
					paramsCatRefPartidas.put("ayudaID", "CatRefpartidas");
					int contCatRefPartidas = ((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRefPartidas);
					if (contCatRefPartidas == 0){
						grabaTelelog(listError,"30659","SPN 9805000000 PARA AYUDA HUMANITARIA TRANSMITIDA NO SE ENCUENTRA VIGENTE");
					}

				}
				else{
					grabaTelelog(listError, "30658","PARA LA PARTIDA 9805000000 DEBE DECLARARSE EL TIPO DE TRATAMIENTO 4 (DONACION)");
				}

			}

			else{
				grabaTelelog(listError,"30657","AYUDA HUMANITARIA DEBE CORRESPONDER A UNA DECLARACION URGENTE DE ENVIO DE SOCORRO");
			}
		}


		return listError;

	}
	/**
	 * Regla 135 del TDDI
	 * VALIDACI�N DEL FORMATO B DE LA DECLARACI�N (96-100 ).
	 * @deprecated  Validar su uso por duplicidad de funcionalidad, posible NullPointerException
	 * @param declaracion Declaracion
	 * @return List de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2372)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2372,numSecEjec=26,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>> validarManifiestoCargaB(Declaracion declaracion){
		boolean Exonerado =false;
		DUA dua=declaracion.getDua();
		Map respim= new HashMap();
		boolean TieneDatosFB=true;
		String ACTSADA ="0";
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		//List<ResSpim> listResSpim=new ArrayList<ResSpim>();
		//List<CabImportFrec> listCabImportFrec=new ArrayList<CabImportFrec>();
		//List<CatRefPartida> listCatRefPartidas=new ArrayList<CatRefPartida>();
		boolean esNuevo=true;
		boolean esMercaUsa=true;
		boolean btnan=true;
		for(DatoSerie serie:dua.getListSeries()){
			if (!SunatStringUtils.include(serie.getCodestamerca(), new String[]{"10","11","12","13","14","15","16"}))
				esNuevo=false;
			if (!SunatStringUtils.include(serie.getCodestamerca(), new String[]{"20","21","22","23","24","25","26","27","28"}))
				esMercaUsa=false;
			if (!SunatStringUtils.include(serie.getCodtnan(), new String[]{"20","21","22","23","24","25","26","27","28"}))
				btnan=false;
			if (!esNuevo && !esMercaUsa && !btnan)
				break;
		}
		boolean esautousa=esMercaUsa && btnan;

		//-	Se Verifica en la tabla RES_SPIM
		//		ResSpimDAO resspimDAO=FormatoAServiceImpl.getInstance().getResspimDAO();
		Map params= new HashMap();

		//		listResSpim=resspimDAO.findByParams(params);

		//if (listResSpim!=null && !listResSpim.isEmpty()){
		//	Exonerado=true;
		//} else {

			if (CollectionUtils.isEmpty(declaracion.getListDAVs())) {
				if (dua.getCodmodalidad().equals("10") && SunatStringUtils.isEqualTo(dua.getCodlugarecepcion(), "03")) {
					boolean vigencia = vigenciaCriterio("000021", SunatDateUtils.getCurrentDate(), "983", "10") > 0;
					if (vigencia) {
						// verificar en CAB_IMPORT_FREC

						//CabImportFrecDAO cabimportfrecDAO = FormatoAServiceImpl.getInstance().getCabimportfrecDAO();
						Map param = new HashMap();
						/*branch ingreso 2011-029 hosorio inicio 20/07/2011*/
						// las condiciones deben ser igual al servicio valcabdav.valgralfb4
						String tipo_docum = "";
						String nume_docum = "";
						if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(), "45")) {
							tipo_docum = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
							nume_docum = dua.getDeclarante().getNumeroDocumentoIdentidad();
						}						
						ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
						boolean importadorFrecuente = funcionesService.isImportadorFrecuente(declaracion.getDua().getCodregimen(),tipo_docum, nume_docum);

						//listCabImportFrec = cabimportfrecDAO.findByParams(param);

						//if (listCabImportFrec == null || listCabImportFrec.size() == 0) {
						if (!importadorFrecuente) {
							/*branch ingreso 2011-029 hosorio inicio 20/07/2011*/
							grabaTelelog(listError, "5653", "DUA NO tiene Formato B.");
						} else {
							if (esautousa) {
								grabaTelelog(listError, "5653", "DUA NO tiene Formato B.");
							} else {
								ACTSADA = "0";
								boolean declaracionTieneDatoSeries = !CollectionUtils.isEmpty(dua.getListSeries());
								if (declaracionTieneDatoSeries) {
									for (DatoSerie datoSerieActual : dua.getListSeries()) {
										// SE consulta CAT_REFPARTIDAS por cada
										// serie
										//	CatRefPartidasDAO catrefpartidasDAO = FormatoAServiceImpl.getInstance().getCatrefpartidasDAO();
										Map parametro = new HashMap();
										/*branch ingreso 2011-029 hosorio inicio 20/07/2011*/
										// las condiciones deben ser igual al servicio valcabdav.valgralfb4
										parametro.put("tipo_uso","DVA");
										parametro.put("cnan",datoSerieActual.getNumpartnandi());
										parametro.put("ffinvig", SunatNumberUtils.getTodayAsInteger());
										/*branch ingreso 2011-029 hosorio fin 20/07/2011*/


										//listCatRefPartidas = catrefpartidasDAO.getCatRefPartidas(parametro);
										parametro.put("ayudaID", "CatRefpartidas");
										List<CatRefpartidas> listCatRefPart =  (List<CatRefpartidas>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCatRefPartidas(parametro);


										/*branch ingreso 2011-029 hosorio inicio 20-07-2011*/
										// para corregir el bug 3655
										//if (listCatRefPartidas != null || listCatRefPartidas.size() > 0) {
										//if (!CollectionUtils.isEmpty(listCatRefPartidas)) {

										if (!CollectionUtils.isEmpty(listCatRefPart)) {
											/*branch ingreso 2011-029 hosorio fin 20-07-2011*/
											ACTSADA = "1";
										}
										if (ACTSADA.equals("1")) {
											// grabaTelelog (listError, "09015",
											// "No envio Formato B. Enviarlo en envio complementario.Transaccion 02.");
											grabaTelelog(listError, "09015", new Object[] { datoSerieActual.getNumpartnandi() });
										} else {
											grabaTelelog(listError, "5653", "DUA NO tiene Formato B.");
										}
									}
								}
							}
						}
					} else {
						grabaTelelog(listError, "5653", "DUA NO tiene Formato B.");
					}
				}

			} else {// tiene formato B validar que exista informacion
				if (declaracion.getListDAVs().size() > 0 && declaracion.getListDAVs() != null && !declaracion.getListDAVs().isEmpty()) {
					boolean declaracionTieneDAV = !CollectionUtils.isEmpty(declaracion.getListDAVs());
					if (!declaracionTieneDAV) {
						grabaTelelog(listError, "5502", "No ha envido toda la Informaci�n del Formato B.");
					}
				}

			}
		//}
		return listError;
	}	

	public Map<String, String> procesaLstSeriesItemActual(List<Map<String, Object>> lstSeriesItemActual)
	{
		Map<String, String> mapProcesa= new HashMap<String, String>();

		for (Map mapaAux:lstSeriesItemActual)
			mapProcesa.put("serie" + mapaAux.get("NUM_SECSERIE").toString(), mapaAux.get("IND_DEL").toString());

		return mapProcesa;
	}

	/**
	 * Lista series y subpartidas sensibles de una dua - operaci�n: diligencia
	 * PAS20144E620000103 - cpuente 050314
	 * 
	 * @param declaracion Declaracion
	 * @return List de Series
	 */
	public Map<String,Object> listaPartidasSensibles(Declaracion declaracion, List<Map<String, Object>> lstSeriesItemActual) throws Exception{
		DUA dua=declaracion.getDua();

		Participante declarante=dua.getDeclarante();
		Elementos<DatoSerie> series=dua.getListSeries();
		List<Map<String, String>> listSeries=new ArrayList<Map<String, String>>();
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		Map<String, Object> mapPartSensibles=new HashMap<String, Object>();

		int numSeriesSensibles= 0;
		int algunasSeriesSens= 0;
		int numSeriesTotal= series.size();
		//si existen elementos en lstSeriesItemActual significa q se han revisado las series de alguna forma
		boolean fueEditado= (lstSeriesItemActual != null && lstSeriesItemActual.size() > 0)?true:false;
		Map<String, String> mapProcesa= new HashMap<String, String>();
		if (fueEditado)
			mapProcesa= procesaLstSeriesItemActual(lstSeriesItemActual);

		for(DatoSerie serie:series){
			Long part_nandi=serie.getNumpartnandi();
			String pais_orige=serie.getCodpaisorige();
			BigDecimal quniisc=serie.getCntunicomisc();
			String tuniisc=serie.getCodunicomisc();
			String tipo_marge=serie.getCodtipomarge();
			Integer conv_inter=serie.getCodconvinter();
			Integer trat_prefe=serie.getCodtratprefe();
			Integer codi_liber=serie.getCodliberatorio();
			String pais_adqui=serie.getCodpaisadqui();
			String cod_moneda=serie.getCodmoneda();
			Integer numserie=serie.getNumserie();
			Integer ind_del= 0;
			if (fueEditado)
				ind_del= Integer.parseInt(mapProcesa.get("serie" + numserie).toString());

			// Traemos el objeto para el tipo de uso PSF de la tabla catrefpartidas
			Map<String,Object> paramsCatRef=new HashMap<String,Object>();
			paramsCatRef.put("tipo_uso", "PSF");
			paramsCatRef.put("cnan", part_nandi);
			paramsCatRef.put("fechaVigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));

			//			CatRefPartidasDAO catrefpartidasDAO=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO();
			// Se cuenta si el objeto se encuentra en cat_refpartidas
			//			int contCatRef=catrefpartidasDAO.count(paramsCatRef);
			paramsCatRef.put("ayudaID", "CatRefpartidas");
			Integer contCatRef = (Integer)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRef);

			// Valida que se encuentre en Cafrepartidas y que sea para DUA con garantia 160
			if ((contCatRef>0) && !SunatStringUtils.isEmptyTrim(dua.getPago().getPagoDeclaracion().getCodgarantia()))
			{
				// Inicializamos El DAO del operador de comercio exterior
				//OperadorComexDAO operadorComexDAO= FormatoAServiceImpl.getInstance().getOperadorComexDAO();
				OperadorComexDAO operadorComexDAO= ((OperadorComexDAO)fabricaDeServicios.getService("operadorComexDAO"));

				String rucImportador=declarante.getNumeroDocumentoIdentidad();
				// Obtenemos documento si es Importador Frecuente u Operador Autorizado
				String docImportadorFrecuente= operadorComexDAO.getImportadorFrecuenteRuc(rucImportador);
				String docOperadorEconAutorizado= operadorComexDAO.getOperadorEcoAutorizadoRuc(rucImportador);
				//Validamos si es un importador autorizado
				boolean importadorAutorizado= false;
				if (docImportadorFrecuente!=null || docOperadorEconAutorizado!= null )
					importadorAutorizado= true;
				// si no es importador autorizado, incrementar la cantidad de partidas sensibles
				if (!importadorAutorizado) 
				{ 
					numSeriesSensibles++;
					if (ind_del!=1)
					{
						algunasSeriesSens++;
						Map<String,String> mapserie = new HashMap<String, String>();
						mapserie.put(ResponseMapManager.KEY_CODIGO, numserie + "" );
						mapserie.put(ResponseMapManager.KEY_DESCRIPCION, part_nandi + "");
						listSeries.add(mapserie);
					}
				}
			}
		}

		// Si todas las series son sensibles al fraude 
		if (numSeriesSensibles == numSeriesTotal)
		{
			Map<String,String> maperror = new HashMap<String, String>();
			maperror.put(ResponseMapManager.KEY_CODIGO,"50125" );
			maperror.put(ResponseMapManager.KEY_DESCRIPCION, 
					"La DAM debe ser legajada por aplicaci�n del Art�culo 201 inciso m) del RLGA " + 
					"porque todas las series contienen subpartidas sensibles") ;
			listError.add(maperror);
			// Si todas las series son sensibles al fraude la dam ha debido ser legajada
			// y no se envia la lista de series sensibles
			listSeries.clear();
		}
		else if (algunasSeriesSens>0)// Alguna(s) de las series es(son) sensible(s) 
		{
			Map<String,String> maperror = new HashMap<String, String>();
			maperror.put(ResponseMapManager.KEY_CODIGO,"50126" );
			maperror.put(ResponseMapManager.KEY_DESCRIPCION,
					"El importador no es OEA ni es Frecuente, y se ha acogido a la Garant�a art�culo 160, " + 
					"proceder a eliminar las series que contengan subpartidas sensibles por aplicaci�n del art�culo 195 del RLGA") ;
			listError.add(maperror);
		}
		mapPartSensibles.put("lstErrorPS", listError);
		mapPartSensibles.put("lstSeries", listSeries);

		return mapPartSensibles;
	}


	/**
	 * Valida el PrcvalidaTPI.
	 * @deprecated
	 * @param declaracion Declaracion
	 * @param fechaReferencia Date
	 * @param datoSerieActual DatoSerie
	 * @return Lista de erores
	 */
	public List<Map<String,String>> PrcvalidaTPI( Declaracion declaracion,Date fechaReferencia, DatoSerie datoSerieActual, String codTransaccion){
		DUA dua = declaracion.getDua();
		Date nfcorigen=new Date();
		Date nfembarque=new Date(); 
		String  dfembar="";    
		DatoDocTransporte documentoTransporte= new DatoDocTransporte();
		String codtpi=" ";
		String codpais=" ";
		String nompais=" ";
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		Elementos<DatoAutocertificacion>  listAutocertificacion=dua.getDatoCertificadoOrigen()!=null?dua.getDatoCertificadoOrigen().getListAutocertificacion():null;
		boolean declaracionTieneAutoCertificacion=!CollectionUtils.isEmpty(listAutocertificacion);
		Date fcorigen=new Date();
		Date fingsi=fechaReferencia;
		Date xfec_iembce=new Date();
		Participante datodeclarante = declaracion.getDua().getDeclarante(); 
		BigDecimal Sumtmp=new BigDecimal(0);
		codTransaccion=codTransaccion.substring(2, 4);//DZC

		codtpi=SunatStringUtils.toStringObj(datoSerieActual.getCodconvinter());
		codpais =datoSerieActual.getCodpaisorige();

		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(declaracion.getDua(),datoSerieActual);
		//DataGrupoCat tempo=FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getDataGrupoCat("1L", codtpi.toString());

		//Map<String,Object> mpDataAsoc =FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getElementoAsoc("003",SunatStringUtils.toStringObj(codtpi), codpais);
		Map<String,Object> mpDataAsoc =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoAsoc("003",SunatStringUtils.toStringObj(codtpi), codpais);

		// DZC: Validaciones para regimen de Precedentes:
		boolean tiene_precedente= false;
		Date fingsiNumeracion= new Date();


		// DZC Obtenemos si tiene regimen de precedencia:
		if ("229".equals(codtpi))  
		{
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){	
				for(DatoRegPrecedencia regPrec:datoSerieActual.getListRegPrecedencia()){     
					// Si tiene Regimen de precedente 70
					if (regPrec.getCodregipre().equals("70")){

						Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
						paramsCabDeclara.put("codigoAduana", regPrec.getCodaduapre());
						paramsCabDeclara.put("annoPresentacion",  regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"");
						paramsCabDeclara.put("codigoRegimen", regPrec.getCodregipre());
						paramsCabDeclara.put("numeroDeclaracion", regPrec.getNumdeclpre());
						// obtenemos la DUA
						//DUA numdeclaracionBD = (DUA) FormatoAServiceImpl.getInstance().getCabDeclaraDAO().findDUAByKeyMap(paramsCabDeclara);
						DUA numdeclaracionBD = (DUA) ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDUAByKeyMap(paramsCabDeclara);

						//Datos de la DUA:
						if(numdeclaracionBD!=null)
						{	
							String num_declaracion = SunatStringUtils.lpad(numdeclaracionBD.getNumdocumento(), 6, '0');
							Number annpresen = numdeclaracionBD.getAnnpresen();
							String codaduanaorden = numdeclaracionBD.getCodaduanaorden();
							fingsiNumeracion=numdeclaracionBD.getFecdeclaracion();// Fecha que se utilizara para establecer la vigencia del CO
							tiene_precedente= true;
						}
					}
				}
			}
		}

		for(DatoAutocertificacion certificadoOrigenActual:listCertificadoOrigen){
			documentoTransporte=getDocTransporte(declaracion.getDua(),datoSerieActual);

			//if (!SunatStringUtils.isEmpty(tempo.getCodDatacatasoc())){

			// DZC REGLAS PARA TPI 229 : 
			if ("229".equals(codtpi))
			{
				fcorigen = certificadoOrigenActual.getFecemision();
				String codFFCO=certificadoOrigenActual.getCodffco();
				String numCO=certificadoOrigenActual.getNumdocumento();
				numCO=numCO.toUpperCase();

				// Validamos tipo certificado de Origen: si no es del tipo 1 emite error
				if (!SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1"}))
				{
					grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CERTIFICADO DE ORIGEN TRANSMITIDO NO CORRESPONDE AL TPI, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .CERT_ORIGE : ").concat(certificadoOrigenActual.getNumdocumento()))});
				}
				else
				{  	 
					// valida la existencia del certificado de origen
					if (SunatStringUtils.isEmpty(numCO) || "S/N".equals(numCO.trim()) ||
							"SN".equals(numCO.trim()) ){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CERTIFICADO 1 REQUIERE EL ENVO DEL NMERO DE CERTIFICADO DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_CERTOR : ").concat(certificadoOrigenActual.getCodtipoCO()))});
					}
					// valida la declaracion de la fecha de emision del certificado de origen, debe de tener fecha de emision
					if (SunatDateUtils.isDefaultDate(fcorigen) || fcorigen==null ){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CERTIFICADO 1 REQUIERE EL ENVO DE LA FECHA DEL CERTIFICADO DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy")))});
					} 
				} 
				//fecha de numeracion dentro de Certificado de origen + un a�o

				nfcorigen= SunatDateUtils.addMonth(fcorigen, 12) ; // suma 1 a�o
				if (tiene_precedente==false){ //regimen presedente diferente a 70

					if  (!(SunatDateUtils.getIntegerFromDate(fingsi) >= SunatDateUtils.getIntegerFromDate(fcorigen) && 
							SunatDateUtils.getIntegerFromDate(fingsi) <= SunatDateUtils.getIntegerFromDate(nfcorigen))){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CERT.DE ORIGEN PRESENTADO FUERA DE SU PLAZO DE VIGENCIA .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy" )))});
					}
				}else // tiene regimen precedente 70
				{   
					//La fecha del certificado de origen es anterior a la fecha de la declaraci�n
					fingsi=fingsiNumeracion;
					if  (!(SunatDateUtils.getIntegerFromDate(fcorigen) >= SunatDateUtils.getIntegerFromDate(fingsi)))
					{

						//fecha de numeracion dentro de Certificado de origen + un a�o 
						if  (!(SunatDateUtils.getIntegerFromDate(fingsi) >= SunatDateUtils.getIntegerFromDate(fcorigen) && 
								SunatDateUtils.getIntegerFromDate(fingsi) <= SunatDateUtils.getIntegerFromDate(nfcorigen))){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CERT.DE ORIGEN PRESENTADO FUERA DE SU PLAZO DE VIGENCIA .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy" ).concat(" FNUM_PRECE : ").concat(SunatDateUtils.getFormatDate(fingsi, "dd/MM/yyyy" ))))});
						}
					} 
				}


				// si no se manda el criterio de origen
				if (certificadoOrigenActual.getCodcriterioO()==null && SunatStringUtils.isEmpty(certificadoOrigenActual.getCodcriterioO())){
					grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" SE REQUIERE EL ENVO DEL TIPO DE CRITERIO DE ORIGEN 1, 2, 3 o 4 ")});
				}
				else
				{
					if (!SunatStringUtils.include(certificadoOrigenActual.getCodcriterioO(),new String[]{"1","2","3","4"})){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CRITERIO DE ORIGEN TRANSMITIDO NO CORRESPONDE AL TPI".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .CRI_ORIGEN : ").concat(certificadoOrigenActual.getCodcriterioO()))});
					}
				}

				// Validamos indicador de transito no es vacio y debe ser 1, 2, 3
				String[] arrayIndTrans229 = new String []{"1", "2", "3"};

				if (SunatStringUtils.isEmpty(certificadoOrigenActual.getIndtrans())) {
					grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR SI REALIZO TRANSITO/TRANSBORDO EN UN 3ER.PAIS ")});

				}
				else

				{
					if (!SunatStringUtils.include(certificadoOrigenActual.getIndtrans(), arrayIndTrans229)){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .IND_TRANS: ").concat(certificadoOrigenActual.getIndtrans()).concat(" TIPO DE TRNSITO, TRANSBORDO O ALMACENAMIENTO EN UN TERCER PAS TRANSMITIDO NO CORRESPONDE AL TPI ")});

					}
					else
					{


						if ("1".equals(certificadoOrigenActual.getIndtrans()) || "3".equals(certificadoOrigenActual.getIndtrans())){

							//validamos que la fecha de embarque no sea vacia
							if (SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg())==0){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE CONSIGNAR FECHA DE EMBARQUE EN EL PAS DE ORIGEN ")});
							}

							//validamos que puerto de embarque no sea vacio y que sea el mismo del pais de origen VE
							if (SunatStringUtils.isEmpty(documentoTransporte.getCodpuerto())|| documentoTransporte.getCodpuerto()==null){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE CONSIGNAR PUERTO DE EMBARQUE EN EL PAS DE ORIGEN ").concat(nompais)});
							}
							else
							{   // puert de embarque mismo que el pais de origen
								if (!codpais.equals(SunatStringUtils.substringFox(documentoTransporte.getCodpuerto(), 1, 2))){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .PUER_EMBAR: ").concat(documentoTransporte.getCodpuerto()).concat(" MERCANCA NO PROCEDE DIRECTAMENTE DEL PAS DE ORIGEN ").concat(nompais)});
								}		                				 
							}

							//*** Fecha de embarque desde pas de origen debe ser menor o igual a la fecha de embarque del tercer pas
							if (!(SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg()) <=
									SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarque()))){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .FEC_EMBPTR: ").concat(SunatDateUtils.getFormatDate(documentoTransporte.getFecembarqueorg(), "dd/MM/yyyy")).concat(" FEC.EMB PAIS ORIGEN DEBE SER MENOR O IGUAL A FEC.EMB TERCER PAIS ")});

							}
						}

						if ("2".equals(certificadoOrigenActual.getIndtrans())){

							//validamos que puerto de embarque no sea vacio y que sea el mismo del pais de origen
							if (SunatStringUtils.isEmpty(documentoTransporte.getCodpuerto())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .PUER_EMBAR: ").concat(documentoTransporte.getCodpuerto()).concat(" DEBE CONSIGNAR PUERTO DE EMBARQUE EN EL PAS DE ORIGEN ").concat(nompais)});
							}
							else
							{
								if (!codpais.equals(SunatStringUtils.substringFox(documentoTransporte.getCodpuerto(), 1, 2))){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .PUER_EMBAR: ").concat(documentoTransporte.getCodpuerto()).concat(" MERCANCA NO PROCEDE DIRECTAMENTE DEL PAS DE ORIGEN ").concat(nompais)});
								}		                				 
							}
						}


					}
				}  

				// Valida registro del funcionario autorizado
				if (SunatStringUtils.isEmpty(certificadoOrigenActual.getCodffco())) {
					grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" SE REQUIERE QUE ENVE EL NMERO DE REGISTRO DEL FUNCIONARIO AUTORIZADO ")});

				}
				else
				{  // si existe funcionario validar en la tabla Pruperso
					Map<String,Object> paramsPruperso=new HashMap<String,Object>();
					paramsPruperso.put("regis", codFFCO);
					paramsPruperso.put("codPais", codpais);
					paramsPruperso.put("fechCertiOrigen", SunatDateUtils.getIntegerFromDate(fcorigen));
					//List<Map<String,Object>> listJoinPruperso=FormatoAServiceImpl.getInstance().getPrupersoDAO().joinPrupersoAndPrufunciFindByMap(paramsPruperso);
					List<Map<String,Object>> listJoinPruperso=((PrupersoDAO)fabricaDeServicios.getService("prupersoDAO")).joinPrupersoAndPrufunciFindByMap(paramsPruperso);
					if (listJoinPruperso==null || listJoinPruperso.isEmpty()){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .NUME_FFCO: ").concat(certificadoOrigenActual.getCodffco().toString()).concat(" FUNCIONARIO NO HABILITADO A LA FECHA DE EMISION  DEL CERTIFICADO DE ORIGEN ")});
					}

				}      

			}
			// DZC FIN  TPI 229    
			if (!CollectionUtils.isEmpty(mpDataAsoc)){
				//DataCatalogo nombreP=FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getDataCatalogo("J2", tempo.getCodDatacatasoc()) ;// catalogo de paises
				//DataCatalogo nombreP=FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getDataCatalogo("J2", codpais) ;// catalogo de paises
				DataCatalogo nombreP= (DataCatalogo)(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpais));
				nompais=nombreP.getDesDatacat()!=null?nombreP.getDesDatacat():"";
				// if (codpais.equals(tempo.getCodDatacatasoc())){
				//*!* Validamos el Tipo de Certificado
				if ( ("802".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","2","3","4"})) ||
						("803".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","2","4"}))||
						("804".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","4"}))||
						("805".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","5"}))||
						("812".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","5"}))){

					if("812".equals(codtpi)){
						mpDataAsoc.put("cod_datacatasoc", codpais);
					}

					//*!* Validamos si el TM = 6, el unico posible Tipo de Certificado de Origen = 3
					if ("6".equals(datoSerieActual.getCodtipomarge()) && !certificadoOrigenActual.getCodtipoCO().equals("3") && "802".equals(codtpi) ){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" REQUIERE CERT.DE IDENTIF.DE MERC.TEXTILES ARTESANALES: TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .TIPO_MARGE : ").concat(datoSerieActual.getCodtipomarge()))});
					}


					// *** HCT TPI805 20100217
					if ( "805".equals(codtpi) && "1".equals(certificadoOrigenActual.getCodtipoCO())){
						//*!* Validamos que envie el Nro del Certificado de Origen
						if (SunatStringUtils.isEmpty(certificadoOrigenActual.getNumdocumento()) || "S/N".equals(certificadoOrigenActual.getNumdocumento().trim()) ||
								"SN".equals(certificadoOrigenActual.getNumdocumento().trim()) ){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE ENVIAR EL NRO. DEL CERT.DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_CERTOR : ").concat(certificadoOrigenActual.getCodtipoCO()))});
						}
					}

					if ("812".equals(codtpi)){
						//*!* Validamos que envie el Nro del Certificado de Origen
						if (SunatStringUtils.isEmpty(certificadoOrigenActual.getNumdocumento())){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE ENVIAR EL NRO. DEL CERT.DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_CERTOR : ").concat(certificadoOrigenActual.getCodtipoCO()))});
						}
					}

					//*!* TPI802 Si el Tipo de Certificado es 1 o 2 o 3
					//*!* TPI803 Si el Tipo de Certificado es 1 o 2
					//*!* TPI804 Si el Tipo de Certificado es 1 
					//*!* TPI812 Si el Tipo de Certificado es 1 o 5 
					if (!"4".equals(certificadoOrigenActual.getCodtipoCO())){
						// *!* Variable para validar plazo de nuemracion y renago del periodo de embarque
						fcorigen = certificadoOrigenActual.getFecemision();
						//*!* Validamos la Fecha del Certificado de Origen
						if (SunatDateUtils.isDefaultDate(fcorigen)){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR LA FECHA DE EMISION DEL CERT.DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy")))});
						}else{
							//*!* Validamos plazo de numeraci�n
							//*!* TPI 802 y 803 Obtenemos la fecha maxima : 4 anos de emitido el cert. origen
							//*!* TPI 804 Obtenemos la fecha maxima : 1 ano de emitido el cert. origen
							if (SunatStringUtils.include(codtpi,new String[]{"802","803"})){

								nfcorigen= SunatDateUtils.addMonth(fcorigen, 12*4) ; // suma 4 aos
							}else if ("804".equals(codtpi) || "805".equals(codtpi)){
								//&&& TPI804
								//&&& TPI805 Tambien aplica
								nfcorigen= SunatDateUtils.addMonth(fcorigen, 12) ; // suma 1 ao
							}
							if(!"812".equals(codtpi)){
								if  (!(SunatDateUtils.getIntegerFromDate(fingsi) >= SunatDateUtils.getIntegerFromDate(fcorigen) && 
										SunatDateUtils.getIntegerFromDate(fingsi) <= SunatDateUtils.getIntegerFromDate(nfcorigen))){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CERT.DE ORIGEN PRESENTADO FUERA DE SU PLAZO DE VIGENCIA .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy" )))});
								}
							}
						}
						//*!* Validamos el Tipo de Emisor del Certificado de Origen
						if (!"804".equals(codtpi)){
							if (("802".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","2","3"}))||
									("803".equals(codtpi) && SunatStringUtils.include(certificadoOrigenActual.getCodtipoCO(),new String[]{"1","2"}))){
								//*!* Si es TM = 6 el dato es opcional
								//*!* Si el Tipo de Cerificado es 3 el dato es opcional
								if (!("6".equals(datoSerieActual.getCodtipomarge()) || "3".equals(certificadoOrigenActual.getCodtipoCO())) &&
										SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoemisorCO()) && "802".equals(codtpi) ){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL TIPO DE EMISOR DEL CERT.DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_EMICER : ").concat(certificadoOrigenActual.getCodtipoemisorCO()!=null?certificadoOrigenActual.getCodtipoemisorCO():""))});
								}
							}else if (!"812".equals(codtpi)){
								//&&& TPI805
								if (!("805".equals(codtpi) && (("5".equals(certificadoOrigenActual.getCodtipoCO()) &&
										SunatStringUtils.include(certificadoOrigenActual.getCodtipoemisorCO(),new String[]{"1","2"})) ||
										("1".equals(certificadoOrigenActual.getCodtipoCO()) && SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoemisorCO())) ))){

									if ("805".equals(codtpi) && "1".equals(certificadoOrigenActual.getCodtipoCO()) && !SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoemisorCO())){
										grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR TIPO DE EMISOR DE CERT.DE ORIGEN .CERT_ORIGE :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_EMICER : ").concat(certificadoOrigenActual.getCodtipoemisorCO()!=null?certificadoOrigenActual.getCodtipoemisorCO():""))});
									}else{
										grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE EMISOR DE CERT.DE ORIGEN NO DEFINIDO PARA ACOGIMIENTO A TPI :".concat(codtpi).concat(" .TIP_EMICER : ").concat(certificadoOrigenActual.getCodtipoemisorCO()!=null?certificadoOrigenActual.getCodtipoemisorCO():""))});
									}
								}
							}
						}else{
							//&&& TPI 804 
							//&&& No debe enviar tipo de emisor de certificado de origen
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoemisorCO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR TIPO DE EMISOR DE CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .TIP_EMICER : ").concat(certificadoOrigenActual.getCodtipoemisorCO()!=null?certificadoOrigenActual.getCodtipoemisorCO():""))});

							}

						}
						//*!* Validamos el Nombre del Emisor del Certificado de Origen
						//*!* Si es TM = 6 el dato es opcional
						//*!* Si el Tipo de Cerificado es 3 el dato es opcional
						if (!("6".equals(datoSerieActual.getCodtipomarge()) || "3".equals(certificadoOrigenActual.getCodtipoCO())) &&
								SunatStringUtils.isEmpty(certificadoOrigenActual.getNomemisorCO()) && "802".equals(codtpi) ){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL NOMBRE DEL EMISOR DEL CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .NOM_EMICER  : "))});
						}
						if (SunatStringUtils.isEmpty(certificadoOrigenActual.getNomemisorCO()) && "803".equals(codtpi)){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL NOMBRE DEL EMISOR DEL CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .NOM_EMICER  : "))});

						}
						//&&& TPI805 TPI812
						if ("805".equals(codtpi) || "812".equals(codtpi)){
							if ("5".equals(certificadoOrigenActual.getCodtipoCO()) && SunatStringUtils.isEmpty(certificadoOrigenActual.getNomemisorCO()) ){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL NOMBRE DEL EMISOR DEL CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .NOM_EMICER  : ").concat(certificadoOrigenActual.getNomemisorCO()))});

							}
							if ("1".equals(certificadoOrigenActual.getCodtipoCO()) && !SunatStringUtils.isEmpty(certificadoOrigenActual.getNomemisorCO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE DECLARAR EL NOMBRE DEL EMISOR DEL CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()).concat(" .NOM_EMICER  : ").concat(certificadoOrigenActual.getNomemisorCO()))});
							}
						}

						if (SunatStringUtils.isEmpty(certificadoOrigenActual.getNomproduc()) && "803".equals(codtpi)){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL NOMBRE DEL PRODUCTOR DE LA MERCANCIA, CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()))});
						}
						//*!* Validamos el Nombre del Productor de la Mercancia
						//*!* Si es TM = 6 el dato es opcional
						//*!* Si el Tipo de Cerificado es 3 el dato es opcional
						if ( !("6".equals(datoSerieActual.getCodtipomarge()) || "3".equals(certificadoOrigenActual.getCodtipoCO())) &&
								SunatStringUtils.isEmpty(certificadoOrigenActual.getNomproduc()) && "802".equals(codtpi) ){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL NOMBRE DEL PRODUCTOR DE LA MERCANCIA, CERT.DE ORIGEN :".concat(certificadoOrigenActual.getNumdocumento()))});
						}
						// *!* Validamos el Criterio de Origen 1 2 o 3 
						if("805".equals(codtpi)){
							if ("1".equals(certificadoOrigenActual.getCodtipoCO()) && !SunatStringUtils.include(certificadoOrigenActual.getCodcriterioO(),new String[]{"1","2","3"}) ){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CRITERIO DE ORIGEN NO DEFINIDO PARA ACOGIMIENTO A TPI :".concat(codtpi).concat(" .CRI_ORIGEN  : ").concat(certificadoOrigenActual.getCodcriterioO()))});
							}
							if("5".equals(certificadoOrigenActual.getCodtipoCO()) && !SunatStringUtils.isEmpty(certificadoOrigenActual.getCodcriterioO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CRITERIO DE ORIGEN NO DEFINIDO PARA ACOGIMIENTO A TPI :".concat(codtpi).concat(" .CRI_ORIGEN  : ").concat(certificadoOrigenActual.getCodcriterioO()))});
							}
						}else if(!"812".equals(codtpi)){
							if (SunatStringUtils.include(certificadoOrigenActual.getCodcriterioO(),new String[]{"1","2","3","4"})){
								//*!* Si es TM = 6 el dato es opcional
								//*!* Si el Tipo de Cerificado es 3 el dato es opcional
								if (!("6".equals(datoSerieActual.getCodtipomarge()) || "3".equals(certificadoOrigenActual.getCodtipoCO()) )  
										&& SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoCO()) && "802".equals(codtpi)){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR EL CRITERIO DE ORIGEN :".concat(" .CRI_ORIGEN  : ").concat(certificadoOrigenActual.getCodcriterioO()))});
								}
							}else{
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" CRITERIO DE ORIGEN NO DEFINIDO PARA ACOGIMIENTO A TPI")});
							}
						}
						//*!* Validamos que envie las fechas de periodo de embarque para el tipo 2
						if ( "2".equals(certificadoOrigenActual.getCodtipoCO())){
							if (!SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFeciniembarque()).equals(0) &&
									!SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque()).equals(0)){
								if ("802".equals(codtpi)){
									// *!* Validamos el rango de fechas del inicio y fin del periodo de embarque         
									//  *!* Obtenemos la fecha maxima : 12 meses de emitido el cert. origen
									nfcorigen=SunatDateUtils.addMonth(fcorigen, 12) ; // suma 1 ao
									if (SunatDateUtils.getIntegerFromDate(nfcorigen)<SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFeciniembarque()) ||
											SunatDateUtils.getIntegerFromDate(nfcorigen)< SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque())){
										grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" PER.EXCEDE 12MESES DE EMISION CERT.DE ORIGEN .FEC_IEMBCE:".concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFeciniembarque(), "dd/MM/yyyy")).concat(" .FEC_FEMBCE : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecfinembarque(), "dd/MM/yyyy")))});
									}
								}
								if ("803".equals(codtpi)){
									//*** Fecha Fin periodo Embarque no puede ser mayor en 12 meses respecto a Fecha Inicio Periodo Embarque
									xfec_iembce = SunatDateUtils.addMonth(certificadoOrigenActual.getFeciniembarque(), 12); // 12 meses
									if (SunatDateUtils.getIntegerFromDate(xfec_iembce)<SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque())){
										grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" PERIODO DE EMBARQUE NO DEBE EXCEDER LOS 12 MESES .FEC_IEMBCE:".concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFeciniembarque(), "dd/MM/yyyy")).concat(" .FEC_FEMBCE : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecfinembarque(), "dd/MM/yyyy")))});

									}
								}
								//*!* Validamos que la fecha de embarque  este dentro del rango del periodo de embarque
								if ("1".equals(certificadoOrigenActual.getIndtrans())){
									nfembarque=documentoTransporte.getFecembarqueorg();
									dfembar="FEC_EMBPTR";
								}else{
									nfembarque=documentoTransporte.getFecembarque();
									dfembar="FECH_EMBAR";
								}
								if (!(SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFeciniembarque())<=SunatDateUtils.getIntegerFromDate(nfembarque) &&
										SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque())>=SunatDateUtils.getIntegerFromDate(nfembarque))){
									grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" IMPORTACION FUERA DE PERIODO EMBARQUE .FEC_IEMBCE:".concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFeciniembarque(), "dd/MM/yyyy")).concat(" .FEC_FEMBCE : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecfinembarque(), "dd/MM/yyyy")).concat(" ".concat(dfembar)).concat(SunatDateUtils.getFormatDate(nfembarque, "dd/MM/yyyy")))});

								}
								//*!* Validamos que el Certificado no haya sido usado por otro importador
								HashMap tmp= new HashMap();
								tmp.put("codTipoPartic", "45");// para los importadores
								tmp.put("numCertificado",certificadoOrigenActual.getNumdocumento() );
								tmp.put("fecCertificado", SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecemision()));
								tmp.put("codEmisCert", certificadoOrigenActual.getCodtipoemisorCO());
								tmp.put("codCriterioO", certificadoOrigenActual.getCodcriterioO());
								tmp.put("numPartNandi", datoSerieActual.getNumpartnandi());
								tmp.put("codTipMargen", datoSerieActual.getCodtipomarge());
								tmp.put("fecIniPeriodEmb", SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFeciniembarque()));
								tmp.put("fecFinPeriodEmb", SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque()));
								tmp.put("codTipDoc", datodeclarante.getTipoDocumentoIdentidad().getCodDatacat());
								tmp.put("numDocIdent", datodeclarante.getNumeroDocumentoIdentidad());
								tmp.put("codConvenio", datoSerieActual.getCodconvinter());

								//List<Map<String,Object>> lstExisteCertiMulti=FormatoAServiceImpl.getInstance().getDetAutorizacionDAO().existeCertOrigenMultiple(tmp);
								List<Map<String,Object>> lstExisteCertiMulti=((DetAutorizacionDAO)fabricaDeServicios.getService("detAutorizacionDAO")).existeCertOrigenMultiple(tmp);
								if (!CollectionUtils.isEmpty(lstExisteCertiMulti)){
									if (lstExisteCertiMulti.size()>0){
										grabaTelelog(listError,"30404", new Object[]{"TIP.DOC : ".concat(datodeclarante.getTipoDocumentoIdentidad().getCodDatacat()).concat(" NUM.DOC:".concat(datodeclarante.getNumeroDocumentoIdentidad()))});

									}      
								}
							}else{
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR RANGO DE FECHAS DE EMBARQUE CORRECTAMENTE: FEC_IEMBCE - FEC_FEMBCE :dd/MM/yyyy")});
							}

						}else{
							//**** &&& Tipo de Certificado distinto a 2 
							//*!* Validamos que no nos envien data innecesaria
							if (certificadoOrigenActual.getFeciniembarque()!=null ||
									certificadoOrigenActual.getFecfinembarque() != null)	{
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO ENVIAR RANGO DE FECHAS DE PERIODO DE EMBARQUE CON TIPO CERT.".concat(certificadoOrigenActual.getCodtipoCO()).concat(".FEC_IEMBCE:").concat( SunatDateUtils.getFormatDate(certificadoOrigenActual.getFeciniembarque(), "dd/MM/yyyy") ).concat(" .FEC_FEMBCE : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecfinembarque(), "dd/MM/yyyy")))});

							}
						}
					}else{
						// **** &&& Tipo de Certificado igual a 4
						//*!* Validamos que sea una dua de Imp. Simplificada
						//*!* LSR 20090320 - El tipo de Cert. 4 ahora es permitido para las Imp. Definitivas y Simplificadas.
						if (!SunatStringUtils.include(dua.getCodregimen(), new String[]{"10","18"})){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CERTIFICADO NO VALIDO PARA EL REG. DECLARADO, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .CODI_REGI : ").concat(dua.getCodregimen()))});

						}else{
							// *!* Validamos que la mercanc�a no exceda los $1500 cuando no hay Certificado de Origen
							if ("18".equals(dua.getCodregimen())){
								//&&& Solo para 802 y 804  
								Sumtmp=new BigDecimal(0);
								Sumtmp=SunatNumberUtils.sum(datoSerieActual.getMtofobdol(), SunatNumberUtils.sum(datoSerieActual.getMtofledol(),datoSerieActual.getMtosegdol()));
								if (SunatNumberUtils.isGreaterThanParam(Sumtmp, 1500) && SunatStringUtils.include(codtpi, new String[]{"802","804"}) ){
									grabaTelelog(listError,"30405",  new Object[]{"1500"});
									/*graba_telelog(RIGHT(annodoc,2)," ",STR(numserdoc,4),;
                   	                             "8815","FOB : " + ALLTRIM(STR(&nomcur..fob_dolpol,15,3)) + " " +;
                   	    	                      "FLETE : " + ALLTRIM(STR(&nomcur..fle_dolar,15,3)) + " " +;
                   	    	                      "SEGURO : " + ALLTRIM(STR(&nomcur..seg_dolar,15,3)) + " " +;
                   		     	                  "REQUIERE CERT.DE ORIGEN"," "," ")
									 * */
								}
								//&&& Solo para 803
								if (SunatNumberUtils.isGreaterThanParam(Sumtmp, 1000) && "803".equals(codtpi) ){
									grabaTelelog(listError,"30405",  new Object[]{"1000"});
									/*graba_telelog(RIGHT(annodoc,2)," ",STR(numserdoc,4),;
                   	                             "8815","FOB : " + ALLTRIM(STR(&nomcur..fob_dolpol,15,3)) + " " +;
                   	    	                      "FLETE : " + ALLTRIM(STR(&nomcur..fle_dolar,15,3)) + " " +;
                   	    	                      "SEGURO : " + ALLTRIM(STR(&nomcur..seg_dolar,15,3)) + " " +;
                   		     	                  "REQUIERE CERT.DE ORIGEN"," "," ")
									 * */
								}
								//*!* Para Simplificada y tipo certificado 4 Validamos el Nombre del Proveedor
								/* if (EMPTY(&nomcur..nom_provee)  
                                          =graba_telelog(RIGHT(annodoc,2)," ",STR(numserdoc,4),;
                                             "30403",nomfile + ".NOM_PROVEE : " + &nomcur..nom_provee + " " +;
                        	 	             "DEBE DECLARAR EL NOMBRE DEL PROVEEDOR DE LA MERCANCIA"," "," ") 
                                       ENDIF*/

							}else{
								//&&& Solo para 802 y 804 
								if (SunatNumberUtils.isGreaterThanParam(datoSerieActual.getMtovaladuana(),1500) && 
										SunatStringUtils.include(codtpi, new String[]{"802","804"})){
									grabaTelelog(listError,"30405", new Object[]{"1500"});
									/*graba_telelog(RIGHT(annodoc,2)," ",STR(numserdoc,4),;
                     	                             "8815","MERCANCIA SUPERA LOS $ 1500. REQUIERE CERT.DE ORIGEN - VALOR EN ADUANA (FOB+FLETE+SEGURO+AJUSTE) : " +;
                     	                             ALLTRIM(STR(&nomcur..val_aduana,15,3))," "," ")
									 * */
								}
								//&&& Solo para 803
								if (SunatNumberUtils.isGreaterThanParam(datoSerieActual.getMtovaladuana(),1000) && 
										"803".equals(codtpi)){
									grabaTelelog(listError,"30405", new Object[]{"1000"});
									/*graba_telelog(RIGHT(annodoc,2)," ",STR(numserdoc,4),;
                     	                             "8815","MERCANCIA SUPERA LOS $ 1000. REQUIERE CERT.DE ORIGEN - VALOR EN ADUANA (FOB+FLETE+SEGURO+AJUSTE) : " +;
                     	                             ALLTRIM(STR(&nomcur..val_aduana,15,3))," "," ")
									 * */
								}
							}
							// *!* Validamos que no envie la Fecha del Certificado de Origen
							if (SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecemision())>0){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR LA FECHA DEL CERT.DE ORIGEN, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .FCERT_ORI : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecemision(), "dd/MM/yyyy")))});
							}
							// *!* Validamos que no envie el Tipo de Emisor del Certificado de Origen
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getCodtipoemisorCO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR EL TIPO DE EMISOR DEL CERT.DE ORIGEN, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .TIP_EMICER : ").concat(certificadoOrigenActual.getCodtipoemisorCO()!=null?certificadoOrigenActual.getCodtipoemisorCO():""))});

							}
							//*!* Validamos que no envie el Nombre del Emisor del Certificado de Origen
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getNomemisorCO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR EL NOMBRE DEL EMISOR DEL CERT.DE ORIGEN, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .NOM_EMICER : ").concat(certificadoOrigenActual.getNomemisorCO()))});
							}
							// *!* Validamos que no envie el Nro del Certificado de Origen
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getNumdocumento())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR EL NRO. DEL CERT.DE ORIGEN, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .CERT_ORIGE : ").concat(certificadoOrigenActual.getNumdocumento()))});
							}
							//*!* Validamos el Criterio de Origen
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getCodcriterioO())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR EL CRITERIO DE ORIGEN, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .CRI_ORIGEN : ").concat(certificadoOrigenActual.getCodcriterioO()))});

							}
							//*!* Validamos que no nos envien los periodos de embarque
							if (SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFeciniembarque())!=0 ||
									SunatDateUtils.getIntegerFromDate(certificadoOrigenActual.getFecfinembarque())!=0)	{
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO ENVIAR CON TIPO CERT.".concat(certificadoOrigenActual.getCodtipoCO()).concat(".FEC_IEMBCE:").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFeciniembarque(), "dd/MM/yyyy")).concat(" .FEC_FEMBCE : ").concat(SunatDateUtils.getFormatDate(certificadoOrigenActual.getFecfinembarque(), "dd/MM/yyyy")))});

							}

							//*!* Validamos el Nombre del Productor de la Mercancia
							if (!SunatStringUtils.isEmpty(certificadoOrigenActual.getNomproduc())){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" NO DEBE ENVIAR EL NOM.DEL PRODUCTOR DE LA MERC, TIP_CERTOR ".concat(certificadoOrigenActual.getCodtipoCO()).concat(" .NOM_PRODUC : ").concat(certificadoOrigenActual.getNomproduc()))});

							}
						}//10,18
					}

				}else{
					grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" TIPO DE CERT.DE ORIGEN NO DEFINIDO PARA ACOGIMIENTO A TPI")});

				}
				//*!* Validamos si realiza Transito/Transbordo en un tercer pais
				String[] arrayIndTrans = new String []{"1", "2", "2"};

				if("812".equals(codtpi)){
					arrayIndTrans[2]="3";
				} 

				if (SunatStringUtils.include(certificadoOrigenActual.getIndtrans(), arrayIndTrans)){
					if ("2".equals(certificadoOrigenActual.getIndtrans())){
						//*!* Validamos que no envie fecha de embarque desde pais de origen
						if (SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg())>0){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .FEC_EMBPTR: ").concat(SunatDateUtils.getFormatDate(documentoTransporte.getFecembarqueorg(), "dd/MM/yyyy")).concat(" NO DEBE ENVIAR LA FECHA DE EMBARQUE DESDE PAIS DE ORIGEN ")});

						}
						//*!* Validamos que el puerto de embarque pertenezca al Pais respectivo
						if (!SunatStringUtils.isEmpty(documentoTransporte.getCodpuerto())){
							if (!codpais.equals(SunatStringUtils.substringFox(documentoTransporte.getCodpuerto(), 1, 2))){
								grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .PUER_EMBAR: ").concat(documentoTransporte.getCodpuerto()).concat(" MERCANCIA NO PROCEDE DE ").concat(nompais)});
							}
						}
					}else{
						// **** &&& indicador de transito es 1 ( o 3 para TPI 812 )
						if (SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg())==0){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .FEC_EMBPTR: ").concat(SunatDateUtils.getFormatDate(documentoTransporte.getFecembarqueorg(), "dd/MM/yyyy")).concat(" DEBE ENVIAR LA FECHA DE EMBARQUE EN EL PAIS DE ORIGEN ")});

						}
						//*!* Validamos la fecha de embarque
						//*** HCT TPI805 20100217
						//*** Fecha de embarque desde pa�s de origen debe ser menor o igual a la fecha de embarque del tercer pa�s
						if (SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg()) >
						SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarque())){
							grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .FEC_EMBPTR: ").concat(SunatDateUtils.getFormatDate(documentoTransporte.getFecembarqueorg(), "dd/MM/yyyy")).concat(" FEC.EMB PAIS ORIGEN DEBE SER MENOR O IGUAL A FEC.EMB TERCER PAIS ")});

						}

					}

				}else{
					if (SunatStringUtils.isEmpty(certificadoOrigenActual.getIndtrans())){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" DEBE DECLARAR SI REALIZO TRANSITO/TRANSBORDO EN UN 3ER.PAIS ")});

					}else{
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .IND_TRANS: ").concat(certificadoOrigenActual.getIndtrans()).concat(" VALOR NO DEFINIDO PARA INDICAR SI REALIZO TRANSITO/TRANSBORDO EN UN 3ER.PAIS ")});

					}

				}
				//*!* Validaciones solo para Importacion Simplificada
				//&&& TPI805
				if ("18".equals(dua.getCodregimen()) && !"805".equals(codtpi)){
					//*!* Validamos el Tipo de documento del Consignatario
					if (SunatStringUtils.isEmpty( datodeclarante.getTipoDocumentoIdentidad().getCodDatacat())){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .TIP_DOCCON: ").concat(datodeclarante.getTipoDocumentoIdentidad().getCodDatacat()).concat(" DEBE DECLARAR EL TIPO DOC.DEL CONSIGNATARIO ")});

					}
					//*!* Validamos el N�mero del documento del Consignatario
					if (SunatStringUtils.isEmpty(datodeclarante.getNumeroDocumentoIdentidad())){
						grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .NUM_DOCCON: ").concat(datodeclarante.getNumeroDocumentoIdentidad()).concat(" DEBE DECLARAR EL NRO.DOC.DEL CONSIGNATARIO ")});

					}
				}
			}else{
				if (!("229".equals(codtpi))) grabaTelelog(listError,"30403", new Object[]{codtpi,"SERIE: ".concat(datoSerieActual.getNumserie().toString()).concat(" .PAIS_ORIGE: ").concat(datoSerieActual.getCodpaisorige()).concat(" NO PUEDE ACOGERSE AL TPI ")});

			}
		}
		return listError;		
	}  

	/**
	 * Val montos im.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param declaracion Declaracion
	 * @param listCatRefRuc List<Map<String,Object>>
	 */

	// PAS20181U220200004 CSANTILLAN
		private void valMontosIM2(List<Map<String, String>> listError, Declaracion declaracion, Integer fechaDeclaracion,
				List<Map<String, Object>> USOMAXAPL, BigDecimal USOMAXAPLDAO2) {
			BigDecimal montoUsado4442 = BigDecimal.ZERO;
			BigDecimal montoUsado4443 = BigDecimal.ZERO;
			BigDecimal montoUsado4444 = BigDecimal.ZERO;
			BigDecimal saldo4442 = BigDecimal.ZERO;
			BigDecimal saldo4443 = BigDecimal.ZERO;
			BigDecimal saldo4444 = BigDecimal.ZERO;
			// inicio gmontoya Pase 153
			BigDecimal tope4442 = BigDecimal.ZERO;
			BigDecimal tope4443 = BigDecimal.ZERO;
			BigDecimal tope4444 = BigDecimal.ZERO;
			// fin gmontoya Pase 153
			Map<String, Object> mapaDatos = new HashMap<String, Object>();
			List<DatoSerie> series = declaracion.getDua().getListSeries();
			// inicio gmontoya
			BigDecimal saldoReal4442 = BigDecimal.ZERO;
			BigDecimal saldoReal4443 = BigDecimal.ZERO;
			BigDecimal saldoReal4444 = BigDecimal.ZERO;

			BigDecimal montoAcumulado4442 = BigDecimal.ZERO;
			BigDecimal montoAcumulado4443 = BigDecimal.ZERO;
			BigDecimal montoAcumulado4444 = BigDecimal.ZERO;
			
			BigDecimal quitarDecla4442 = BigDecimal.ZERO;
			BigDecimal quitarDecla4443 = BigDecimal.ZERO;
			BigDecimal quitarDecla4444 = BigDecimal.ZERO;
			String tablaA1 ="di" + SunatDateUtils.getCurrentFormatDate("YYYY").toString().substring(2, 4) + "seriesi";
			String tablaA2 ="di" + SunatDateUtils.getCurrentFormatDate("YYYY").toString().substring(2, 4) + "polizai";
			String tablaB1 ="di" + SunatDateUtils.getFormatDate(SunatDateUtils.addYear(SunatDateUtils.getCurrentDate(), -1),"YYYY").toString().substring(2, 4) + "seriesi";
			String tablaB2 ="di" + SunatDateUtils.getFormatDate(SunatDateUtils.addYear(SunatDateUtils.getCurrentDate(), -1),"YYYY").toString().substring(2, 4) + "polizai";							
			CatRefRucDAO USOMAXAPLDAO = fabricaDeServicios.getService("catRefRucCentralizadaDAO");
			Map<String, Object> filtro = new HashMap<String, Object>();		
			// fin gmontoya
			// ConsultaDeclaracionSIGADService consultaDeclaracionSIGADService =
			// fabricaDeServicios.getService("sigad.ingreso.service.ConsultaDeclaracionSIGADService");//gmontoya
			// Pase 153
			TipoDeDescrMinimaService tipoDeDescrMinimaService = fabricaDeServicios
					.getService("descripcionMinima.TipoDeDescrMinimaService");// gmontoya
																				// Pase
																				// 153
			Enum<?> tipoDescrMinima = null;// gmontoya Pase 153
			int cantidaVehiculos4443 = 0;// gmontoya Pase 153

			for (DatoSerie serie : series) {
				if (serie.getCodliberatorio() != null) {
					if (SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()),
							new String[] { "4442", "4443", "4444" })) {
						// ConsultaDeclaracionSIGADService
						// consultaDeclaracionSIGADService =
						// fabricaDeServicios.getService("sigad.ingreso.service.ConsultaDeclaracionSIGADService");
						// gmontoya Pase 153
						mapaDatos.put("CodigoLiberatorio", serie.getCodliberatorio().toString());
						if (serie.getCodliberatorio() == 4442) {
							if ("0".equals(saldo4442.toString())) {
								// inicio gmontoya Pase 153
								Map<String, Object> mapaCodLib = new HashMap<String, Object>();
								MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
								mapaCodLib.put("tlib", "C");
								mapaCodLib.put("clib", serie.getCodliberatorio().toString());
								mapaCodLib.put("fechaVigencia", fechaDeclaracion);
								List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
								if (lstmaxapl.size() > 0) {
									Maxapl maxapl = lstmaxapl.get(0);
									tope4442 = lstmaxapl.get(0).getMmaxapl();
								}
								// mapaDatos.put("TopeCodLib", tope4442);

								// fin gmontoya Pase 153
								// saldo4442 =
								// consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								//saldo4442 = SunatNumberUtils.diference(tope4442, USOMAXAPLDAO2);
								if (USOMAXAPL != null && USOMAXAPL.size() > 0) {
									BigDecimal mtoUsado = (BigDecimal) USOMAXAPL.get(0).get("mtoTotalDecla");
									saldo4442 = SunatNumberUtils.diference(tope4442, mtoUsado);
								} else {
									saldo4442 = SunatNumberUtils.diference(tope4442, USOMAXAPLDAO2);
								}
								
							}
							
							if(SunatStringUtils.include(declaracion.getCodtipotrans(), new String[]{"1003","1006","1016","1007","1010","1018","1012"})){
							filtro.put("tablaA1", tablaA1);
							filtro.put("tablaA2", tablaA2);
							filtro.put("tablaB1", tablaB1);
							filtro.put("tablaB2", tablaB2);
							filtro.put("codAduana", declaracion.getNumdeclRef().getCodaduana());
							filtro.put("anoPrese",declaracion.getNumdeclRef().getAnnprese().substring(2));
							filtro.put("numeCorre", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
							filtro.put("codiLiber", serie.getCodliberatorio());								
							quitarDecla4442 = USOMAXAPLDAO.getquitardecla(filtro);
							}
							montoUsado4442 = SunatNumberUtils.diference(SunatNumberUtils.sum(montoUsado4442, serie.getMtofobdol()),quitarDecla4442);
							
							//Csantillan: Calculo para actualizar la tabla
							montoAcumulado4442= SunatNumberUtils.sum(SunatNumberUtils.diference(montoUsado4442,saldo4442),tope4442);
							
						    declaracion.getDua().setMontoAcumulado4442(montoAcumulado4442);
							
							if (SunatNumberUtils.isGreaterThanParam(montoUsado4442, saldo4442)) {
								grabaTelelog(listError, "30663", new Object[] { // gmontoya
																				// Pase
																				// 153
										serie.getNumserie(), serie.getCodliberatorio().toString(), saldo4442 });
							}
						}
						if (serie.getCodliberatorio() == 4443) {
							if ("0".equals(saldo4443.toString())) {
								// inicio gmontoya Pase 153
								Map<String, Object> mapaCodLib = new HashMap<String, Object>();
								MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
								mapaCodLib.put("tlib", "C");
								mapaCodLib.put("clib", serie.getCodliberatorio().toString());
								mapaCodLib.put("fechaVigencia", fechaDeclaracion);
								List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
								if (lstmaxapl.size() > 0) {
									Maxapl maxapl = lstmaxapl.get(0);
									tope4443 = lstmaxapl.get(0).getMmaxapl();
								}
								// mapaDatos.put("TopeCodLib", tope4443);

								// fin gmontoya Pase 153
								// saldo4443 =
								// consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								//saldo4443 = SunatNumberUtils.diference(tope4443, USOMAXAPLDAO2);
								if (USOMAXAPL != null && USOMAXAPL.size() > 0) {
									BigDecimal mtoUsado = (BigDecimal) USOMAXAPL.get(0).get("mtoTotalDecla");
									saldo4443 = SunatNumberUtils.diference(tope4443, mtoUsado);
								} else {
									saldo4443 = SunatNumberUtils.diference(tope4443, USOMAXAPLDAO2);
								}

							}
							for (DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie)) {
								try {
									tipoDescrMinima = tipoDeDescrMinimaService.obtenerTipoDeDescrMinima(datoItem);
									if (tipoDescrMinima.equals(TIPO_VEHICULO.VEHICULO)) {
										cantidaVehiculos4443++;
									}
								} catch (Exception e) {
									if (log.isDebugEnabled()) {
										log.debug(e.getStackTrace());
									}
								} // gmontoya Pase 153
							}
							if (cantidaVehiculos4443 > 1) {
								grabaTelelog(listError, "30915", new Object[] { // gmontoya
																				// Pase
																				// 153
										serie.getNumserie(), serie.getCodliberatorio().toString() });
							}
							
							if(SunatStringUtils.include(declaracion.getCodtipotrans(), new String[]{"1003","1006","1016","1007","1010","1018","1012"})){
								filtro.put("tablaA1", tablaA1);
								filtro.put("tablaA2", tablaA2);
								filtro.put("tablaB1", tablaB1);
								filtro.put("tablaB2", tablaB2);
								filtro.put("codAduana", declaracion.getNumdeclRef().getCodaduana());
								filtro.put("anoPrese",declaracion.getNumdeclRef().getAnnprese().substring(2));
								filtro.put("numeCorre", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
								filtro.put("codiLiber", serie.getCodliberatorio());								
								quitarDecla4443 = USOMAXAPLDAO.getquitardecla(filtro);
								}
							
							montoUsado4443 = SunatNumberUtils.diference(SunatNumberUtils.sum(montoUsado4443, serie.getMtofobdol()),quitarDecla4443);
							
							//Csantillan: Calculo para actualizar la tabla
							montoAcumulado4443= SunatNumberUtils.sum(SunatNumberUtils.diference(montoUsado4443,saldo4443),tope4443);
							
						    declaracion.getDua().setMontoAcumulado4443(montoAcumulado4443);
							
							if (SunatNumberUtils.isGreaterThanParam(montoUsado4443, saldo4443)) {
								grabaTelelog(listError, "30663", new Object[] { // gmontoya
																				// Pase
																				// 153
										serie.getNumserie(), serie.getCodliberatorio().toString(), saldo4443 });
							}
						}
						if (serie.getCodliberatorio() == 4444) {
							if ("0".equals(saldo4444.toString())) {
								// fin gmontoya Pase 153
								Map<String, Object> mapaCodLib = new HashMap<String, Object>();
								MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
								mapaCodLib.put("tlib", "C");
								mapaCodLib.put("clib", serie.getCodliberatorio().toString());
								mapaCodLib.put("fechaVigencia", fechaDeclaracion);
								List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
								if (lstmaxapl.size() > 0) {
									Maxapl maxapl = lstmaxapl.get(0);
									tope4444 = lstmaxapl.get(0).getMmaxapl();
								}
								// mapaDatos.put("TopeCodLib", tope4444);

								// fin gmontoya Pase 153
								// saldo4444 =
								// consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								if (USOMAXAPL != null && USOMAXAPL.size() > 0) {
									BigDecimal mtoUsado = (BigDecimal) USOMAXAPL.get(0).get("mtoTotalDecla");
									saldo4444 = SunatNumberUtils.diference(tope4444, mtoUsado);
								} else {
									saldo4444 = SunatNumberUtils.diference(tope4444, USOMAXAPLDAO2);
								}

							}
							
							if(SunatStringUtils.include(declaracion.getCodtipotrans(), new String[]{"1003","1006","1016","1007","1010","1018","1012"})){
								filtro.put("tablaA1", tablaA1);
								filtro.put("tablaA2", tablaA2);
								filtro.put("tablaB1", tablaB1);
								filtro.put("tablaB2", tablaB2);
								filtro.put("codAduana", declaracion.getNumdeclRef().getCodaduana());
								filtro.put("anoPrese",declaracion.getNumdeclRef().getAnnprese().substring(2));
								filtro.put("numeCorre", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
								filtro.put("codiLiber", serie.getCodliberatorio());								
								quitarDecla4444 =  USOMAXAPLDAO.getquitardecla(filtro);
								}
							
							montoUsado4444 = SunatNumberUtils.diference(SunatNumberUtils.sum(montoUsado4444, serie.getMtofobdol()),quitarDecla4444);
							
							//Csantillan: Calculo para actualizar la tabla
							montoAcumulado4444= SunatNumberUtils.sum(SunatNumberUtils.diference(montoUsado4444,saldo4444),tope4444);
							
						    declaracion.getDua().setMontoAcumulado4444(montoAcumulado4444);
							
							if (SunatNumberUtils.isGreaterThanParam(montoUsado4444, saldo4444)) {
								grabaTelelog(listError, "30663", new Object[] { // gmontoya
																				// Pase
																				// 153
										serie.getNumserie(), serie.getCodliberatorio().toString(), saldo4444 });
							}
						}
					}
				}
			}
		}
		// PAS20181U220200004 CSANTILLAN FIN

	private void valMontosIM(List<Map<String, String>> listError, Declaracion declaracion,Map<String, Object> mapCatRefRuc, Integer fechaDeclaracion){ 
		BigDecimal montoUsado4442  = BigDecimal.ZERO;
		BigDecimal montoUsado4443  = BigDecimal.ZERO;
		BigDecimal montoUsado4444 = BigDecimal.ZERO;
		BigDecimal saldo4442 = BigDecimal.ZERO;
		BigDecimal saldo4443 = BigDecimal.ZERO;
		BigDecimal saldo4444 = BigDecimal.ZERO;	
		//inicio gmontoya Pase 153
		Integer tope4442 = 0;
		Integer tope4443 = 0;
		Integer tope4444 = 0;	
		//fin gmontoya Pase 153
		Map<String, Object> mapaDatos = new HashMap<String, Object>();
		mapaDatos.put("anioResolucionLiberatoria",mapCatRefRuc.get("tbaseLegal").toString().substring(0, 4));
		mapaDatos.put("numeroResolucionLiberatoria", mapCatRefRuc.get("tbaseLegal").toString().substring(5,11));
		mapaDatos.put("rucDeclarante", mapCatRefRuc.get("rucDeclarante").toString());//gmontoya Pase 153
		mapaDatos.put("rucDeclarante2", mapCatRefRuc.get("rucDeclarante2").toString());//gmontoya Pase 153
		mapaDatos.put("fechaInicioVigenciaResolLiberatoria",mapCatRefRuc.get("finivig").toString());
		mapaDatos.put("fechaFinVigenciaResolLiberatoria", mapCatRefRuc.get("ffinvig").toString());
		mapaDatos.put("TipoDocumDeclarante", mapCatRefRuc.get("tipoDocumDeclarante").toString());//gmontoya Pase 153	 
		mapaDatos.put("TipoDocumDeclarante2", mapCatRefRuc.get("tipoDocumDeclarante2")!=null?mapCatRefRuc.get("tipoDocumDeclarante2").toString():"");//gmontoya Pase 153	
		boolean quitarDeclaracion =  mapCatRefRuc.get("quitarDeclaracion")!=null?(Boolean)mapCatRefRuc.get("quitarDeclaracion"):false;//gmontoya Pase 153
		List<DatoSerie> series=declaracion.getDua().getListSeries();		
		//inicio gmontoya		
		BigDecimal saldoReal4442 = BigDecimal.ZERO;
		BigDecimal saldoReal4443 = BigDecimal.ZERO;
		BigDecimal saldoReal4444 = BigDecimal.ZERO;
		//fin gmontoya
		ConsultaDeclaracionSIGADService consultaDeclaracionSIGADService = fabricaDeServicios.getService("sigad.ingreso.service.ConsultaDeclaracionSIGADService");//gmontoya Pase 153
		TipoDeDescrMinimaService tipoDeDescrMinimaService   = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");//gmontoya Pase 153
		Enum<?> tipoDescrMinima = null;//gmontoya Pase 153
		int cantidaVehiculos4443 = 0;//gmontoya Pase 153

		for(DatoSerie serie:series){
			if (serie.getCodliberatorio()!=null){
				if (SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()), new String[]{"4442","4443","4444"})){
					//					ConsultaDeclaracionSIGADService consultaDeclaracionSIGADService = fabricaDeServicios.getService("sigad.ingreso.service.ConsultaDeclaracionSIGADService"); gmontoya Pase 153
					mapaDatos.put("CodigoLiberatorio",serie.getCodliberatorio().toString());
					if (serie.getCodliberatorio()==4442){
						if ("0".equals(saldo4442.toString())) {
							//inicio gmontoya Pase 153
							Map<String, Object> mapaCodLib = new HashMap<String, Object>();							
							MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
							mapaCodLib.put("tlib", "C");
							mapaCodLib.put("clib", serie.getCodliberatorio().toString());
							mapaCodLib.put("fechaVigencia", fechaDeclaracion);
							List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
							if (lstmaxapl.size() > 0) {
								Maxapl maxapl = lstmaxapl.get(0);
								tope4442 = Integer.parseInt(lstmaxapl.get(0).getMmaxapl().toString());	
							}
							mapaDatos.put("TopeCodLib", tope4442);
							if(quitarDeclaracion){
								saldoReal4442 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								mapaDatos.put("quitarDeclaracion", true);
								mapaDatos.put("aduana", declaracion.getNumdeclRef().getCodaduana());
								mapaDatos.put("anho", declaracion.getNumdeclRef().getAnnprese().substring(2));
								mapaDatos.put("numDeclaracion", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0') );
							}
							//fin gmontoya Pase 153
							saldo4442 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
							//saldo4442 = BigDecimal.valueOf(30000); 
							//inicio gmontoya Pase 153
							//							if (SunatNumberUtils.isLessOrEqualsThanParam(saldo4442, BigDecimal.ZERO)) {
							//								grabaTelelog(listError, "30663", new Object[] {
							//										serie.getNumserie(),
							//										serie.getCodliberatorio().toString() });
							//							}
							//fin gmontoya Pase 153
						}
						montoUsado4442 = SunatNumberUtils.sum(montoUsado4442,serie.getMtofobdol());//gmontoya Pase 153
						if(SunatNumberUtils.isGreaterThanParam(montoUsado4442, saldo4442)){
							grabaTelelog(listError, "30663", new Object[] {//gmontoya Pase 153
									serie.getNumserie(),
									serie.getCodliberatorio().toString(),
									quitarDeclaracion?saldoReal4442.toString():saldo4442.toString() });
						}
					}
					if (serie.getCodliberatorio()==4443){
						if ("0".equals(saldo4443.toString())) {
							//inicio gmontoya Pase 153
							Map<String, Object> mapaCodLib = new HashMap<String, Object>();
							MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
							mapaCodLib.put("tlib", "C");
							mapaCodLib.put("clib", serie.getCodliberatorio().toString());
							mapaCodLib.put("fechaVigencia", fechaDeclaracion);
							List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
							if (lstmaxapl.size() > 0) {
								Maxapl maxapl = lstmaxapl.get(0);
								tope4443 = Integer.parseInt(lstmaxapl.get(0).getMmaxapl().toString());	
							}										
							mapaDatos.put("TopeCodLib", tope4443);
							if(quitarDeclaracion){
								saldoReal4443 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								mapaDatos.put("quitarDeclaracion", true);
								mapaDatos.put("aduana", declaracion.getNumdeclRef().getCodaduana());
								mapaDatos.put("anho", declaracion.getNumdeclRef().getAnnprese().substring(2));
								mapaDatos.put("numDeclaracion", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0') );
							}
							//fin gmontoya Pase 153
							saldo4443 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
							//inicio gmontoya Pase 153
							if (SunatNumberUtils.isLessThanParam(saldo4443, tope4443)) {
								grabaTelelog(listError, "30664", new Object[] {
										serie.getNumserie(),mapaDatos.get("anioResolucionLiberatoria").toString().concat("-").concat(mapaDatos.get("numeroResolucionLiberatoria").toString())});
								break;
							}

							//saldo4443 = BigDecimal.valueOf(30000);
							//							if (SunatNumberUtils.isLessOrEqualsThanParam(saldo4443, BigDecimal.ZERO)) {
							//								grabaTelelog(listError, "30663", new Object[] {
							//										serie.getNumserie(),
							//										serie.getCodliberatorio().toString() });
							//							}
							//fin gmontoya Pase 153
						}
						for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie)){
							try {
								tipoDescrMinima = tipoDeDescrMinimaService.obtenerTipoDeDescrMinima(datoItem);
								if(tipoDescrMinima.equals(TIPO_VEHICULO.VEHICULO)){
									cantidaVehiculos4443++;
								}
							} catch (Exception e) {
								if(log.isDebugEnabled()){
									log.debug(e.getStackTrace());
								}
							}//gmontoya Pase 153
						}
						if(cantidaVehiculos4443>1){
							grabaTelelog(listError, "30915", new Object[] {//gmontoya Pase 153
									serie.getNumserie(),
									serie.getCodliberatorio().toString()});
						}
						montoUsado4443 = SunatNumberUtils.sum(montoUsado4443,serie.getMtofobdol());//gmontoya Pase 153
						if(SunatNumberUtils.isGreaterThanParam(montoUsado4443, saldo4443)){
							grabaTelelog(listError, "30663", new Object[] {//gmontoya Pase 153
									serie.getNumserie(),
									serie.getCodliberatorio().toString(),
									quitarDeclaracion?saldoReal4443.toString():saldo4443.toString() });
						}
					}
					if (serie.getCodliberatorio()==4444){
						if ("0".equals(saldo4444.toString())) {
							//fin gmontoya Pase 153
							Map<String, Object> mapaCodLib = new HashMap<String, Object>();
							MaxaplDAO maxaplDAO = fabricaDeServicios.getService("maxaplDAO");
							mapaCodLib.put("tlib", "C");
							mapaCodLib.put("clib", serie.getCodliberatorio().toString());
							mapaCodLib.put("fechaVigencia", fechaDeclaracion);
							List<Maxapl> lstmaxapl = maxaplDAO.findByMap(mapaCodLib);
							if (lstmaxapl.size() > 0) {
								Maxapl maxapl = lstmaxapl.get(0);
								tope4444 = Integer.parseInt(lstmaxapl.get(0).getMmaxapl().toString());	
							}
							mapaDatos.put("TopeCodLib", tope4444);
							if(quitarDeclaracion){
								saldoReal4444 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
								mapaDatos.put("quitarDeclaracion", true);
								mapaDatos.put("aduana", declaracion.getNumdeclRef().getCodaduana());
								mapaDatos.put("anho", declaracion.getNumdeclRef().getAnnprese().substring(2));
								mapaDatos.put("numDeclaracion", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0') );
							}
							//fin gmontoya Pase 153
							saldo4444 = consultaDeclaracionSIGADService.obtenerSaldoPorCodLib(mapaDatos);
							//saldo4444 = BigDecimal.valueOf(100000);
							//inicio gmontoya
							//							if (SunatNumberUtils.isLessOrEqualsThanParam(saldo4444, BigDecimal.ZERO)) {
							//								grabaTelelog(listError, "30663", new Object[] {
							//										serie.getNumserie(),
							//										serie.getCodliberatorio().toString() });
							//							}
							//fin gmontoya Pase 153
						}
						montoUsado4444 = SunatNumberUtils.sum(montoUsado4444,serie.getMtofobdol());//gmontoya Pase 153
						if(SunatNumberUtils.isGreaterThanParam(montoUsado4444, saldo4444)){
							grabaTelelog(listError, "30663", new Object[] {//gmontoya Pase 153
									serie.getNumserie(),
									serie.getCodliberatorio().toString(),
									quitarDeclaracion?saldoReal4444.toString():saldo4444.toString() });
						}
					}
				}
			}
		}
	}

	/**
	 * Establece un valor a datado2Service.
	 * 
	 * @param datado2Service Datado2Service
	 */
	//public void setDatado2Service(Datado2Service datado2Service) {
	//	this.datado2Service = datado2Service;
	//}

	/**
	 * Validar regimen precedencia.
	 * @deprecated r2bz Se pasa el metododo a {@link ValNegocDuaregapFormA} para centralizar validaciones de regimen de Precedencia
	 * @param regimenPrec DatoRegPrecedencia
	 * @return Lista de erores
	 */
	public List<Map<String,String>>  validarRegimenPrecedencia(DatoRegPrecedencia regimenPrec){

		List<Map<String,String>> listError = new ArrayList<Map<String,String>>();

		if("10".equals(regimenPrec.getCodregipre()))
		{
			String regimenPrecedencia = 
					(new StringBuffer()).append(regimenPrec.getCodaduapre()).append("-").append(SunatStringUtils.substringFox(regimenPrec.getAnndeclpre(), 1,4)).append("-").append(regimenPrec.getCodregipre()).append("-").append(regimenPrec.getNumdeclpre()).toString();

			Map<String, Object> params = new HashMap<String, Object>();
			params.put("codigoAduana", regimenPrec.getCodaduapre());
			params.put("annoPresentacion", SunatNumberUtils.toInteger(SunatStringUtils.substringFox(regimenPrec.getAnndeclpre(), 1,4)));
			params.put("codigoRegimen", regimenPrec.getCodregipre());
			params.put("numeroDeclaracion", SunatNumberUtils.toLong(regimenPrec.getNumdeclpre()));

			//DUA dua = FormatoAServiceImpl.getInstance().getCabDeclaraDAO().findDUAByMap(params);
			DUA dua = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDUAByMap(params);

			if(dua != null)
			{
				if( "08".equals(dua.getCodEstdua()) )
				{
					listError.add(getDUAError("0124",new Object []{regimenPrecedencia}));
				}

			}else{
				params.clear();

				String anio = SunatStringUtils.substring(regimenPrec.getAnndeclpre(), 2, 4);

				params.put("TABLA", "DI"+anio+"POLIZAI");

				params.put("codigoAduana", regimenPrec.getCodaduapre());
				params.put("annoPresentacion", anio);
				params.put("numeroDeclaracion", regimenPrec.getNumdeclpre());

				//Integer count = FormatoAServiceImpl.getInstance().getDipolizaiDAO().getCountNoLgajadas(params);
				Integer count = ((DipolizaiDAO)fabricaDeServicios.getService("dipolizaiDAO")).getCountNoLgajadas(params);
				if(count == 0)
				{
					listError.add(getDUAError("0124",new Object []{regimenPrecedencia}));
				}
			}

		}

		return listError;
	}

	public Map<String,?> validarAnticipadoManifiesto (Map<String,Object> dataDua,Manifiesto manifiesto) {

		ResponseMapManager responseMapManager=new ResponseMapManager();

		if(!dataDua.containsKey("fechaLlegada") || dataDua.get("fechaLlegada")==null ){

			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11500, "No se envio fecha de llegada del manifiesto de carga");
			return responseMapManager.getResponseMap();
		}

		Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaLlegada");
		String codTransaccion = (String) dataDua.get("codTransaccion");
		//Se verifica si ya tiene registrado la fecha de LLegada Real
		Date fechaLLegadaManif = manifiesto.getFechaEfectivaDeLlegada();

		if(fechaLLegadaManif == null || SunatDateUtils.sonIguales(fechaLLegadaManif, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
			//Si no tiene usaremos la fecha Programada de Llegada
			fechaLLegadaManif = manifiesto.getFechaProgramadaLlegada();
		}

		boolean isValidFechaLlegada = SunatDateUtils.sonIguales(fechaLLegadaManif,fechaTerminoDeDescarga,SunatDateUtils.COMPARA_SOLO_FECHA);
		boolean esUrgente = "01".equals(dataDua.get("codModalidad"))?true:false;
		boolean esAnticipado = "10".equals(dataDua.get("codModalidad"))?true:false;

		if(codTransaccion.endsWith("01")) {		
			if(esAnticipado) {
				if(!SunatStringUtils.isEmpty((String) dataDua.get("numManif"))){
					if(!isValidFechaLlegada ){
						/* comentado porque ahora los mensajes seran dinamicos */
						/*responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11501, "La fecha de llegada enviada "+DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy") +" es diferente a la almacenado en el manifiesto de carga "+DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy"));
						return responseMapManager.getResponseMap();*/				
						return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");					
					}

					/* ONEYRAJ PAS20144E610000245 INICIO */
					if(manifiesto.getFechaTerminoDeDescarga() != null && !SunatDateUtils.isDefaultDate(manifiesto.getFechaTerminoDeDescarga())) {							
						return getDUAError("35003","Mercanc�as ya se encuentran arribadas, la modalidad de despacho anticipado se numera antes del arribo del medio de transporte");							
					}

					if(SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(Calendar.getInstance().getTime(), 15), fechaLLegadaManif, SunatDateUtils.COMPARA_SOLO_FECHA)) {
						return getDUAError("35004","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
					}
					/* ONEYRAJ PAS20144E610000245 FIN */
				}
			}
			if(esUrgente) {
				/* ONEYRAJ PAS20144E610000245 INICIO */
				if(!SunatStringUtils.isEmpty((String) dataDua.get("numManif"))) {

					//isValidFechaLlegada

					if(manifiesto.getFechaTerminoDeDescarga() != null && !SunatDateUtils.isDefaultDate(manifiesto.getFechaTerminoDeDescarga())){
						if(! SunatDateUtils.sonIguales(manifiesto.getFechaTerminoDeDescarga(),fechaTerminoDeDescarga,SunatDateUtils.COMPARA_SOLO_FECHA) ){
							return getDUAError("35006","Fecha del t�rmino de la descarga consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
						}
					}
					else {					
						if(!isValidFechaLlegada){
							return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
						}
					}
				}
				/* ONEYRAJ PAS20144E610000245 FIN */
			}
		}

		/*if(!documentoDeTransporte.getPuertoEmbarque().getCodigo().equals(dataDua.get("puertoEmbarque"))){
			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11503, "El puerto de embarque enviado "+dataDua.get("puertoEmbarque")+ " es diferente a la almacenado en el documento de transporte "+documentoDeTransporte.getPuertoEmbarque().getCodigo());
			return responseMapManager.getResponseMap();
		}*/
		return responseMapManager.getResponseMap();
	}
	//mordonezl pase70
	public Map<String,?> validarFechaLlegadaManifiesto (Map<String,Object> dataDua,Manifiesto manifiestoBD ) {

		Map<String, String> error=new HashMap<String, String>();

		if(!dataDua.containsKey("fechaLlegada") || dataDua.get("fechaLlegada")==null ){

			//			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11500, "No se envio fecha de llegada del manifiesto de carga");
			error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("11500");
			return error;
		}
		Date fechaActual=new Date();
		Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaLlegada");
		String codTransaccion = (String) dataDua.get("codTransaccion");
		//Se verifica si ya tiene registrado la fecha de LLegada Real
		Date fechaLLegadaManif = manifiestoBD.getFechaEfectivaDeLlegada();
		boolean esFecEfectiva = true;//PAS20155E220200056
		if(fechaLLegadaManif == null || SunatDateUtils.sonIguales(fechaLLegadaManif, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
			//Si no tiene usaremos la fecha Programada de Llegada
			fechaLLegadaManif = manifiestoBD.getFechaProgramadaLlegada();
			esFecEfectiva = false;//PAS20155E220200056
		}

		boolean isValidFechaLlegada = SunatDateUtils.sonIguales(fechaLLegadaManif,fechaTerminoDeDescarga,SunatDateUtils.COMPARA_SOLO_FECHA);
		boolean esUrgente = "01".equals(dataDua.get("codModalidad"))?true:false;
		boolean esAnticipado = "10".equals(dataDua.get("codModalidad"))?true:false;
		boolean esExcepcional = "00".equals(dataDua.get("codModalidad"))?true:false;
		if(codTransaccion.endsWith("01") || codTransaccion.endsWith("03")) {		
			if(esAnticipado) { //se descomenta por bug en la numeracion 18777
				// Se comenta porque existe la misma validacion en la clase la ValManifc
				if(!SunatStringUtils.isEmpty((String) dataDua.get("numManif"))){
					if(esFecEfectiva && !isValidFechaLlegada ){	//verificar solo para fecha de llegada efectiva SAU201510002000209 
						//return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
						error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35002",new String[]{DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy"),DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy")});			
						return error;
					}
					if(codTransaccion.endsWith("01") && esFecEfectiva){//PAS20155E220200056 //gmontoya P29 pase 15 2015
						if(SunatDateUtils.esFecha1MayorQueFecha2(fechaActual,fechaLLegadaManif,SunatDateUtils.COMPARA_TODO)){ //PAS201930001100006
							error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35618",new String[]{DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy hh:mm:ss"),DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy HH:mm:ss")});//PAS20165E220200152
							return error;
						}
					}

				}
			}
			if(esUrgente) {
				if(!SunatStringUtils.isEmpty((String) dataDua.get("numManif"))) {
					if(manifiestoBD.getFechaTerminoDeDescarga() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaTerminoDeDescarga())){
						if(! SunatDateUtils.sonIguales(fechaLLegadaManif,fechaTerminoDeDescarga,SunatDateUtils.COMPARA_SOLO_FECHA) ){
							//			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11501, "La fecha de llegada enviada "+DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy") +" es diferente a la almacenado en el manifiesto de carga "+DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy"));
							error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30800",new String[]{DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy"),DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy")});			
							return error;
						}
					}//se comenta porque existe doble mensaje: Bug 18559- 18566 : Pase 105
					else {		//se descomenta por bug en la numeracion 18777 			
						if(esFecEfectiva && !isValidFechaLlegada){ //verificar solo para fecha de llegada efectiva SAU201510002000209
							//return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
							error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35002",new String[]{DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy"),DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy")});			
							return error;
						}
					}
				}
			}
			if(esExcepcional){

				// se adiciona por bug 18767
				if(manifiestoBD.getFechaTerminoDeDescarga() != null && SunatDateUtils.isDefaultDate(manifiestoBD.getFechaTerminoDeDescarga())){
					if(! SunatDateUtils.sonIguales(fechaLLegadaManif,fechaTerminoDeDescarga,SunatDateUtils.COMPARA_SOLO_FECHA) ){
						error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30800",new String[]{DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy"),DateUtil.dateToStringSilent(fechaLLegadaManif, "dd/MM/yyyy")});			
						return error;
					}
				}

			}
		}



		return error;
	}
	//fin mordonezl
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.manifiesto.service.DatadaValidaciones#ValidarExcepcionalConManifiesto(java.util.Map)
	 */
	@Deprecated
	//usar validarFechaTerminDescargaManifiesto
	public Map<String,?> validarExcepcionalManifiesto  (Map<String,Object> dataDua,Manifiesto manifiesto) {

		ResponseMapManager responseMapManager=new ResponseMapManager();

		String codTransaccion = (String) dataDua.get("codTransaccion");
		if(codTransaccion.endsWith("01")) {		
			if(!dataDua.containsKey("fechaTerminoDeDescarga") || dataDua.get("fechaTerminoDeDescarga")==null){

				responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11504, "No se envio fecha de termino de descarga");
				return responseMapManager.getResponseMap();
			}

			Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaTerminoDeDescarga");

			boolean isValidFechaTerminoDescarga = false;
			try {
				isValidFechaTerminoDescarga = DateUtil.equalsDate(manifiesto.getFechaTerminoDeDescarga(),fechaTerminoDeDescarga);
			} catch (Exception e) {}

			if(!isValidFechaTerminoDescarga){
				//responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11505, "La fecha de termino de descarga enviada "+DateUtil.dateToStringSilent(fechaTerminoDeDescarga , "dd/MM/yyyy") +" es diferente a la almacenada en el manifiesto de carga "+DateUtil.dateToStringSilent(manifiesto.getFechaTerminoDeDescarga(), "dd/MM/yyyy"));
				//return responseMapManager.getResponseMap();
				return getDUAError("35006","Fecha del t�rmino de la descarga consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
			}

			Map<String,?> mapErrors  = validarFechaNumeracionDua(manifiesto, dataDua);
			if(!mapErrors.isEmpty())return mapErrors;
		}
		return responseMapManager.getResponseMap();

	}
	//mordonezl pase70
	public Map<String,?> validarFechaTerminoDescargaManifiesto  (Map<String,Object> dataDua,Manifiesto manifiestoBD) {

		Map<String, String> error=new HashMap<String, String>();

		if(!dataDua.containsKey("fechaTerminoDeDescarga") || dataDua.get("fechaTerminoDeDescarga")==null){
			error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("11504");
			return error;
		}

		Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaTerminoDeDescarga");

		boolean isValidFechaTerminoDescarga = false;
		try {
			isValidFechaTerminoDescarga = DateUtil.equalsDate(manifiestoBD.getFechaTerminoDeDescarga(),fechaTerminoDeDescarga);
		} catch (Exception e) {}
		//Se comenta porque existe duplicado de mensaje(Error: 35006)//se descomenta por bug 18310 por no validar arey
		if(!isValidFechaTerminoDescarga){
			error = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30734", new String[] {DateUtil.dateToStringSilent(fechaTerminoDeDescarga , "dd/MM/yyyy"),DateUtil.dateToStringSilent(manifiestoBD.getFechaTerminoDeDescarga(), "dd/MM/yyyy")});
			return error;
		}	
		return error;

	}
	//mordonezl fin

	@SuppressWarnings("unused")
	private  Map<String,?> validarFechaNumeracionDua(Manifiesto manifiesto,Map<String,Object> dataDua) {

		ResponseMapManager responseMapManager=new ResponseMapManager();
		return responseMapManager.getResponseMap();
	}


	/*
	public void setManifiestoService(ManifiestoService manifiestoService) {
		this.manifiestoService = manifiestoService;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public void setDocumentoDeTransporteService(
			DocumentoDeTransporteService documentoDeTransporteService) {
		this.documentoDeTransporteService = documentoDeTransporteService;
	}

	public void setDocumentoOAManifiestoValidacionService(DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService) {
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
	}

	public void setManifiestoSigadService(ManifiestoSigadService manifiestoSigadService) {
		this.manifiestoSigadService = manifiestoSigadService;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}
	 
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public ValVerilib getValVerilib() {
		return valVerilib;
	}

	public void setValVerilib(ValVerilib valVerilib) {
		this.valVerilib = valVerilib;
	}
	
	public MrestriDAOService getMrestriDAOService() {
		return mrestriDAOService;
	}

	public void setMrestriDAOService(MrestriDAOService mrestriDAOService) {
		this.mrestriDAOService = mrestriDAOService;
	}
	
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public TabLibeDAOService getTabLibeDAOService() {
		return tabLibeDAOService;
	}

	public void setTabLibeDAOService(TabLibeDAOService tabLibeDAOService) {
		this.tabLibeDAOService = tabLibeDAOService;
	}

	public ValNegocAduahdr1FormA getValNegocAduahdr1FormA() {
		return valNegocAduahdr1FormA;
	}

	public void setValNegocAduahdr1FormA(ValNegocAduahdr1FormA valNegocAduahdr1FormA) {
		this.valNegocAduahdr1FormA = valNegocAduahdr1FormA;
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}

	public ValItemFB getValItemFB() {
		return valItemFB;
	}

	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}*/

	//mordonezl pase70
	//	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
	//		this.catalogoAyudaService = catalogoAyudaService;
	//	}
	//fin

	//mordonezl pase70

	//fin

	//INICIO - MARGE PASE 105 VS RIN13		
	//mordonezl pase 70
	public List<Map<String,String>> validarPlazoDespachoAnticipado(Declaracion declaracion, Date fechaLlegada, Date fechaDeclaracion, boolean esFecEfectiva){
		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");		
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		//ggranados correcion notificacion
		if (!SunatDateUtils.isDefaultDate(fechaLlegada) && esFecEfectiva &&
				SunatDateUtils.esFecha1MayorQueFecha2(fechaDeclaracion, fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){	//verificar solo para fecha de llegada efectiva SAU201510002000209 	    
			//error: LA DECLARACI�N SE ENCUENTRA NUMERADA POSTERIORMENTE AL ARRIBO DEL MEDIO DE TRANSPORTE, NO CORRESPONDE ACOGERSE A LA MODALIDAD DE DESPACHO ANTICIPADO.
			String fechadeclaracionDUA = SunatDateUtils.getFormatDate(fechaDeclaracion, "dd-MM-yyyy");//cambiado pase 399
			String fechaLlegadaManifiesto = SunatDateUtils.getFormatDate(fechaLlegada, "dd-MM-yyyy");//cambiado pase 399

			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30486",new String[] {fechadeclaracionDUA,fechaLlegadaManifiesto}));	    		
		}		
		boolean correspondeModalidadAnticipada = valModalidadService.correspondeModalidadAnticipada(fechaDeclaracion, fechaLlegada);
		if(!SunatDateUtils.isDefaultDate(fechaLlegada) && !correspondeModalidadAnticipada && esFecEfectiva){//PAS201930001100006 valida siempre que fecha de llegada no sea 01/01/0001
			DataCatalogo catPlazoModalidadAnticipadaCasoFortuito = ((CatalogoAyudaService) fabricaDeServicios
					.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
							ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
							ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA_CASO_FORTUITO, fechaDeclaracion);

			Integer plazoModalidadAnticipadaCasoFortuito = SunatNumberUtils.toInteger(catPlazoModalidadAnticipadaCasoFortuito.getDesCorta());
			Date fecMaxPlazoCasoFortuito = SunatDateUtils.addDay(fechaDeclaracion, plazoModalidadAnticipadaCasoFortuito);
			boolean tieneExpedienteProcedente = true;
			if (SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoCasoFortuito, SunatDateUtils.COMPARA_SOLO_FECHA)){
				//DECLARACI�N EXCEDE EL PLAZO PARA LA MODALIDAD DE DESPACHO ANTICIPADO.
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30733")); // Excede el plazo mas de 30 dias antes	
			} else {					        
				//la fecha de llegada no supera los 30 dias
				ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");

				String  regimenDeclaracion= declaracion.getNumdeclRef().getCodregimen();



				Map<String,Object> params= new HashMap<String, Object>();


				if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "17");
				}else if(ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(regimenDeclaracion)){
					//paramExpedi.setoTipo(32);
					params.put("COD_REGIMEN", "32");
				}else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(regimenDeclaracion)){
					//paramExpedi.setoTipo(7);
					params.put("COD_REGIMEN", "7");
				}else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(regimenDeclaracion)){
					//paramExpedi.setoTipo(40);
					params.put("COD_REGIMEN", "40");
				}

				params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
				params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
				//params.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
				params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
				params.put("procedim", "3126");
				//params.put("actestado", "8");
				//params.put("tipoConc", "05");
				params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
				List<Map<String,Object>> expedientes = expedienteService.findExpedientesAsociadoDeclaracion(params);
				if (CollectionUtils.isEmpty(expedientes)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35271"));
				} else {
					for (int i = 0; i < expedientes.size(); i++) {
						Map<String,Object> exp = expedientes.get(i);
						BigDecimal tipoconc = new BigDecimal(5);
						//Agregado en caso que exista dos expedientes, se busca que uno de ellos tenga estado procedente
						params.put("tipoConc", tipoconc); 
						List<Map<String,Object>> expedienteProcedente = expedienteService.findExpedientesAsociadoDeclaracion(params); 
						if (!CollectionUtils.isEmpty(expedienteProcedente)) {
							return listError;
						}
					}
				}		

				if (!CollectionUtils.isEmpty(expedientes)) {
					//Si no tiene expediente, se rechaza	
					Map<String,Object> exp = expedientes.get(0);
					String aduanaExpediente=exp.get("CODI_ADUA")!=null?exp.get("CODI_ADUA").toString():null;
					String areaExpediente=exp.get("OFIC_REC")!=null?exp.get("OFIC_REC").toString():null;
					String anioExpediente=exp.get("ANOEXPEDI")!=null?exp.get("ANOEXPEDI").toString():null;
					String numeroExpediente=exp.get("NROEXPEDI")!=null?exp.get("NROEXPEDI").toString():null;
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35272", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente})); 
				}
			}

		}


		return listError;

	}

	/**INICIO-RIN13**/	
	//gbecerrav
	//METODO USADO EN LA DILIGENCIA 
	//en catalogo rest tener cuidado con el formato de fechas ya que no esta reconociendo /
	public List<Map<String,String>> validarPlazoDespachoUrgente(Date fechaDeclaracion, Date fechaLlegada,  Date fechaTerminoDescargaManifiesto){

		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();

		DataCatalogo catPlazoModalidadUrgenteDescarga = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_URGENTE_FECHA_DESCARGA, fechaDeclaracion);
		if(fechaTerminoDescargaManifiesto != null && !SunatDateUtils.isDefaultDate(fechaTerminoDescargaManifiesto)) {                                                                                               
			Integer plazoModalidadUrgenteDescarga = SunatNumberUtils.toInteger(catPlazoModalidadUrgenteDescarga.getDesCorta());
			Date fecMaxPlazoModalidadUrgenteDescarga = SunatDateUtils.addDay(fechaTerminoDescargaManifiesto, plazoModalidadUrgenteDescarga);                                                             
			if(SunatDateUtils.esFecha1MayorQueFecha2(fechaDeclaracion, fecMaxPlazoModalidadUrgenteDescarga, SunatDateUtils.COMPARA_SOLO_FECHA)){
				String fechadeclaracion = SunatDateUtils.getFormatDate(fechaDeclaracion, "dd-MM-yyyy");
				String fechadescarga =SunatDateUtils.getFormatDate(fechaTerminoDescargaManifiesto, "dd-MM-yyyy");
				Long diferenciaDiasCalendariosDescarga = SunatDateUtils.getDiferenciaDiasCalendarios(fechaDeclaracion,fechaTerminoDescargaManifiesto);
				listError.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35257", new String[] { fechadeclaracion, fechadescarga, diferenciaDiasCalendariosDescarga.toString()}));
				return listError;
			}
		}

		DataCatalogo catPlazoModalidadUrgenteLlegada = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_URGENTE_FECHA_LLEGADA, fechaDeclaracion);
		Integer plazoModalidadUrgenteLlegada = SunatNumberUtils.toInteger(catPlazoModalidadUrgenteLlegada.getDesCorta());                        
		Date fecMaxPlazoModalidadUrgenteLlegada = SunatDateUtils.addDay(fechaDeclaracion, plazoModalidadUrgenteLlegada);
		Long diferenciaDiasCalendariosLlegada = SunatDateUtils.getDiferenciaDiasCalendarios(fechaLlegada, fechaDeclaracion);
		if(fechaLlegada != null && SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fechaDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
			if(SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoModalidadUrgenteLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)){
				String fechaLlegadaString = SunatDateUtils.getFormatDate(fechaLlegada, "dd-MM-yyyy");
				listError.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35268", new String[] { fechaLlegadaString, diferenciaDiasCalendariosLlegada.toString() }));
				return listError;
			}
		}

		return listError;
	}

	/**FIN-RIN13**/

	public List<Map<String,String>> validarPlazoDuaAnticipadoYUrgenteAnticipado(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) throws Exception{
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		DUA dua=declaracion.getDua();
		//  boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		Map<String, Object> declaracionBDMap = null;
		Date fechaDeclaracion = null;
		Date fechaTerminoDescarga = null;
		DatoManifiesto manif=dua.getManifiesto();
		fechaDeclaracion = declaracionBD.getDua().getFecdeclaracion();

		if(manif!=null && manif.getFectermino()!=null){
			if( SunatDateUtils.isDefaultDate(manif.getFectermino())) {
				fechaTerminoDescarga = declaracion.getDua().getFecLlegada();
			} else {
				fechaTerminoDescarga = manif.getFectermino();
			}
		}else{


			fechaTerminoDescarga = (Date)declaracionBD.getDua().getManifiesto().getFectermino();

			//mordonezl pase70
			if(!SunatDateUtils.isDefaultDate((Date)declaracionBD.getDua().getFecLlegada())){
				fechaTerminoDescarga = declaracionBD.getDua().getFecLlegada();
			}
		}
		//fin mordonezl
		//   if(declaracionTieneDatoSeries){
		boolean esAnticipado = "10".equals(dua.getCodmodalidad()) ? true : false;
		boolean esUrgente = "01".equals(dua.getCodmodalidad()) ? true : false;
		boolean esUrgenteAnticipada = false;
		boolean esUrgenteExcepcional = false;
		boolean esFecEfectiva = true;
		Map<Object,Object>  manifiestodaoBD= (Map<Object, Object>) variablesIngreso.get("manifiestomap");
		Date fechaLlegada = null;
		if (manifiestodaoBD != null && (manifiestodaoBD.get("fechaProgramadaLlegada") != null && !SunatDateUtils.isDefaultDate((Date) manifiestodaoBD.get("fechaProgramadaLlegada"))
				|| manifiestodaoBD.get("fechaEfectivaDeLlegada") != null && !SunatDateUtils.isDefaultDate((Date) manifiestodaoBD.get("fechaEfectivaDeLlegada")))) {

			if (manifiestodaoBD.get("fechaEfectivaDeLlegada") != null && !SunatDateUtils.isDefaultDate((Date) manifiestodaoBD.get("fechaEfectivaDeLlegada"))) {
				fechaLlegada = (Date)manifiestodaoBD.get("fechaEfectivaDeLlegada");
			}else{
				esFecEfectiva = false;//verificar solo para fecha de llegada efectiva SAU201510002000209 						
				fechaLlegada = (Date)manifiestodaoBD.get("fechaProgramadaLlegada");
			}
		}else{

			if(esAnticipado||esUrgenteAnticipada){

				fechaLlegada =fechaTerminoDescarga;
			}
		}


		if (esAnticipado && !SunatDateUtils.sonIguales(fechaLlegada, SunatDateUtils.getDefaultDate(),
				SunatDateUtils.COMPARA_SOLO_FECHA)) {
			List<Map<String, String>> listErrorAux = validarPlazoDespachoAnticipado(declaracion, fechaLlegada,
					fechaDeclaracion, esFecEfectiva);

			if(listErrorAux.size()>0){
				for(int j = 0;j<listErrorAux.size();j++){
					listError.add(listErrorAux.get(j));

				}
			}		
		}

		if(esUrgente) {

			if(manifiestodaoBD!=null){
				Date fechaTerminoDescargaManifiesto = (Date) manifiestodaoBD.get("fechaTerminoDeDescarga");
				listError.addAll(
						validarPlazoDespachoUrgente(fechaDeclaracion, fechaLlegada, fechaTerminoDescargaManifiesto));
				//						
				//						if(fechaTerminoDescargaManifiesto != null && !SunatDateUtils.isDefaultDate(fechaTerminoDescargaManifiesto)) {							
				//							if(SunatDateUtils.esFecha1MayorQueFecha2(fechaDeclaracion, SunatDateUtils.addDay(fechaTerminoDescargaManifiesto, 7), SunatDateUtils.COMPARA_SOLO_FECHA)){
				//								//grabaTelelog(listError,"35007","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
				//								//Por bug
				//								String fechadeclaracion = SunatDateUtils.getFormatDate(fechaDeclaracion, "dd/MM/yyyy");
				//								String fechadescarga =SunatDateUtils.getFormatDate((Date)manifiestodaoBD.get("fechaTerminoDeDescarga"), "dd/MM/yyyy");
				//								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35257", new String[] {fechadeclaracion,fechadescarga}));
				//							
				//								return listError;
				//							}
				//						}
				//						else{
				//							if(fechaLlegada != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaLlegada, fechaDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
				//								if(SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(fechaDeclaracion, 15), fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)){
				//									//grabaTelelog(listError,"35007","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
				//									String fechaLlegadaString = SunatDateUtils.getFormatDate(fechaLlegada, "dd/MM/yyyy");
				//									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35268", new String[] {fechaLlegadaString}));
				//									return listError;
				//								}
				//							}
				//						}
			}
		}


		// }

		return listError;
	}

	/**
	 * M_SNADE278
	 * @author rtineo
	 * Sobrecarga la operacion para permitir el ingreso de variablesIngreso
	 */
	public List<Map<String,String>> validacionesParaDespachoExcepcional(Declaracion declaracion,Declaracion declaracionBD) throws Exception{
		return validacionesParaDespachoExcepcional(declaracion,declaracionBD,null);
	}
	
	public List<Map<String,String>> validacionesParaDespachoExcepcional(Declaracion declaracion,Declaracion declaracionBD, Map<String,Object> variablesIngreso) throws Exception{
	
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		DUA dua = declaracion.getDua();
		//Manifiesto manifiestoBD = (Manifiesto) variablesIngreso.get("manifiestoBD");
		DatoManifiesto manif=declaracion.getDua().getManifiesto();
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		ManifiestoService manifiestoService =  fabricaDeServicios.getService("manifiesto.manifiestoService"); 
	 // pase 64
		Boolean isDAMDiferidaSinICA=false;
		if(variablesIngreso!=null){
			isDAMDiferidaSinICA = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false; 
		}

		// DZC INI SAU20143N002000521
		boolean tieneprece=false;
		boolean siHayData =true;
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		boolean ManifiestoNoexisteNSIGAD =false;

		if(declaracionTieneDatoSeries){
			tieneprece = this.existeRegPrecedencia(dua.getListSeries());
			siHayData  = !this.existeRegPrecedenciaReposicion(dua.getListSeries());
		}

		/***PAS20181U220200049 se reemplaza esto por lo de abajo
		// Buscamos si manifiesto existe en el NSIGAD
		Manifiesto manifiestoBDNSIGAD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,false);
		Manifiesto manifiestoBDASIGAD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);

		if (manifiestoBDNSIGAD==null && manifiestoBDASIGAD!=null){ // Existe en el ASIGAD
			ManifiestoNoexisteNSIGAD=true;
		}
		// DZC FIN SAU20143N002000521

		boolean buscarManifiestoSigadActual = false;
		buscarManifiestoSigadActual = ( "0".equals(declaracion.getDua().getManifiesto().getCodmodtransp()) || "4".equals(declaracion.getDua().getManifiesto().getCodmodtransp()) || "7".equals(declaracion.getDua().getManifiesto().getCodmodtransp()));
		Manifiesto manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,buscarManifiestoSigadActual);
		***/

		//PAS20181U220200019 - mtorralba 20190410 - INICIO - Se convierte a funci�n para ser invocado desde otras clases
		Date fechaDeclaracion = declaracionBD.getDua().getFecNumeracion()==null ? declaracionBD.getDua().getFecdeclaracion() : declaracionBD.getDua().getFecNumeracion();
		Manifiesto manifiestoBD = obtenerManifiesto(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, fechaDeclaracion, declaracion.getDua().getCodlugarecepcion());

		/*
		Manifiesto manifiestoBD = null;
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		Date fechaDeclaracion = declaracionBD.getDua().getFecNumeracion()==null ? declaracionBD.getDua().getFecdeclaracion() : declaracionBD.getDua().getFecNumeracion(); //PAS20181U220200069 - mtorralba 20190410

		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
		String codigoViaTransporteSda = null; 
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			Date fechaDeclaracion = declaracionBD.getDua().getFecNumeracion()==null ? declaracionBD.getDua().getFecdeclaracion() : declaracionBD.getDua().getFecNumeracion(); //PAS20181U220200069 - mtorralba 20190410 
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true,declaracionBD.getDua().getFecNumeracion(),considerarEER);
		}else{
		//con esto busca en sda o en sigad:
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true);
		}
		*/
		//PAS20181U220200019 - mtorralba 20190410 - FIN

		boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;
		boolean esBDAnticipado = "10".equals(declaracionBD.getDua().getCodmodalidad())?true:false;
		boolean esBDUrgente = "01".equals(declaracionBD.getDua().getCodmodalidad())?true:false;

		if(esExcepcional && !tieneprece){   
			//DatoManifiesto manif=dua.getManifiesto();	
			if(manif==null && manif.getCodaduamanif()==null && manif.getAnnmanif()==null && manif.getNummanif()==null && manif.getCodmodtransp()==null){
				//				listError.add( catalogoAyudaService.getError("30735", new String[] {}));
				Map<String, String> mapError = ResponseMapManager.getErrorResponseMap("11000", "No ha enviado el Manifiesto, Por ser modalidad Excepcionar es obligatorio" );
				listError.add(mapError);
				return listError;				
			}

			/***PAS20181U220200049 con el bloque anterior se tiene cargado el manifiesto sea del sigad o del nsigad(Sda), si se desea saber si es sigad .isEsSigad())=true
			// DZC INI -- EL SISTEMA VERIFICA QUE EL MANIFIESTO SE ENCUENTRE SOLO EN EL SIGAD Y NO EN EL NSIGAD
			if(ManifiestoNoexisteNSIGAD && manifiestoBD==null) {   
				manifiestoBD=manifiestoBDASIGAD;    
			}
			// DZC FIN
			***/
			
			if(manifiestoBD==null){
				Map<String, String> mapError = ResponseMapManager.getErrorResponseMap("11000", "El manifiesto enviado no existe" );
				listError.add(mapError);
				return listError;
			}

			Date fecLlegada = manifiestoBD.getFechaEfectivaDeLlegada();	
			Date fechaDescarga=  manifiestoBD.getFechaTerminoDeDescarga();
			String numManifiesto = manifiestoBD.getNumeroCompuesto();
			if((fecLlegada == null || SunatDateUtils.sonIguales(fecLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA ))){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30801",new String[]{numManifiesto}));
				return listError;
			}

			//la fecha de numeracin de la declaracin sea menor a la fecha de llegada del medio de transporte
			//Date fechaDeclaracion = declaracionBD.getDua().getFecdeclaracion();  //PAS20181U220200019 - mtorralba 20190411 - Se inicializa la fecha m�s arriba
			if (SunatDateUtils.esFecha1MenorQueFecha2(fechaDeclaracion, fecLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){

				if(esBDAnticipado){
					DataCatalogo catPlazoModalidadAnticipadaCasoFortuito = ((CatalogoAyudaService) fabricaDeServicios
							.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
									ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
									ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA_CASO_FORTUITO, fechaDeclaracion);
					Integer plazoModalidadAnticipadaCasoFortuito = SunatNumberUtils.toInteger(catPlazoModalidadAnticipadaCasoFortuito.getDesCorta());
					Date fechaInferior = SunatDateUtils.addDay(fecLlegada, -plazoModalidadAnticipadaCasoFortuito);
					if (SunatDateUtils.esFecha1MenorQueFecha2(fechaDeclaracion, fechaInferior, SunatDateUtils.COMPARA_SOLO_FECHA) ){
						//no hay error para este caso
						return listError;		
					}else{
						DataCatalogo catPlazoModalidadAnticipada = ((CatalogoAyudaService) fabricaDeServicios
								.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
										ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
										ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA, fechaDeclaracion);

						Integer plazoModalidadAnticipada = SunatNumberUtils.toInteger(catPlazoModalidadAnticipada.getDesCorta());
						Date fechaInferiorex = SunatDateUtils.addDay(fecLlegada, -plazoModalidadAnticipada);
						if (SunatDateUtils.esFecha1MenorQueFecha2(fechaDeclaracion, fechaInferiorex, SunatDateUtils.COMPARA_SOLO_FECHA) ){
							BigDecimal tipoconc = new BigDecimal(5);
							ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
							Map<String,Object> params= new HashMap<String, Object>();	   
							params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
							params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
							params.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
							params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
							params.put("procedim", "3126");
							params.put("tipoConc", tipoconc);
							params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
							List<Map<String,Object>> expediente = expedienteService.findExpedientesAsociadoDeclaracion(params); 
							if (expediente.size()>0) {
								listError.add( ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30735", 
										new String[] {
												fechaDeclaracion.toString(),
												fecLlegada.toString()}) 
										);
								return listError;								
							}
						} else {
							listError.add( ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30735", 
									new String[] {
											fechaDeclaracion.toString(),
											fecLlegada.toString()}) 
									);
							return listError;							
						}
					}
				} else {

					if(esBDUrgente){
						List<Map<String, String>> listErrorUrgente=new ArrayList<Map<String, String>>();
						listErrorUrgente.addAll(validarPlazoDespachoUrgente(fechaDeclaracion, fecLlegada,fechaDescarga));
						if (CollectionUtils.isEmpty(listErrorUrgente)) {
							// si no cumple el plazo para un envio a urgente se puede acoger a excepcional 
							listError.add(
									((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
									.getError("30735", new String[] { fechaDeclaracion.toString(),
											fecLlegada.toString() }));
							return listError;
						}
					}
				}
			}	

			Elementos<DatoDocTransporte> listDocTrans= declaracion.getDua().getListDocTransporte();
//			//rtineo M_SNADE278, se omite la validacion de ICA o Nota de tarja si se trata de una DAM DIFERIDA SIN ICA
//			Boolean isDAMDiferidaSinICA=false;
//			if(variablesIngreso!=null){
//				isDAMDiferidaSinICA = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false; 
//			}
			//rtineo M_SNADE278 fin
			for (DatoDocTransporte mapDoc : listDocTrans) {
				Map<String,Object> param= new HashMap<String,Object>();
				param.put("NUM_CORREDOC",	manifiestoBD.getNumeroCorrelativo());
				param.put("NUM_DOCTRANSP", mapDoc.getNumdoctransporte());
				param.put("NUM_DETALLE",mapDoc.getNumdetalle());
				List<DocumentoDeTransporte> listDocTransporte = obtenerDocumentosDeTransporte(manifiestoBD, param);
				if(listDocTransporte!=null && listDocTransporte.size()>0){
					DocumentoDeTransporte docTransporte = listDocTransporte.get(0);
					Map<String,Object> paramsMap= new HashMap<String,Object>();
					paramsMap.put("numeroCorrelativo",	manifiestoBD.getNumeroCorrelativo());
					paramsMap.put("numeroDeDetalle", docTransporte.getNumeroDeDetalle());
					paramsMap.put("listaIncluirTipoEnvio",	new String[] {
							ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA.toString(),
							ConstantesDataCatalogo.TIPO_ENVIO_TARJA_AL_DETALLE.toString(), Constantes.COD_TIPO_ENVIO_IRM});
					paramsMap.put("indicadorEliminacion", IND_REGISTRO_ACTIVO);
					DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
					List<DocumentoOABL> tieneTarjaDetallaOICA = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(paramsMap);
				if (CollectionUtils.isEmpty(tieneTarjaDetallaOICA) && !isDAMDiferidaSinICA) {
						//listError.add( ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30736",new String[] {mapDoc.getNumdoctransporte(), mapDoc.getNumdetalle().toString()})	);
						listError.add( ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30736",new String[] {mapDoc.getNumdoctransporte(), docTransporte.getNumeroDeDetalle().toString()})	);
					}
				}
			}
			
			
		}
		
	
		
		return listError;
	}
	


/*
	public ValNegocAduadet1FormA getSPTD_ADUADET1() {
		return SPTD_ADUADET1;
	}

	public void setSPTD_ADUADET1(ValNegocAduadet1FormA sPTD_ADUADET1) {
		SPTD_ADUADET1 = sPTD_ADUADET1;
	}

	public ValNegocCtaCteDepFormA getSPTD_CTACTEDEPOSITO() {
		return SPTD_CTACTEDEPOSITO;
	}

	public void setSPTD_CTACTEDEPOSITO(ValNegocCtaCteDepFormA sPTD_CTACTEDEPOSITO) {
		SPTD_CTACTEDEPOSITO = sPTD_CTACTEDEPOSITO;
	}
	*/
	// lmvr
	@ServicioAnnot(tipo = "V", codServicio = 2530, descServicio = "valida Documento Autorizante")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion","serie" })
	@OrquestaDespaAnnot(codServInstancia = 2530, numSecEjec = 429, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> validaDocumentoAutorizante(
			Declaracion declaracion,DatoSerie serie) {
		// TODO Auto-generated method stub
		DUA dua = declaracion.getDua();
		List<Map<String, String>> lstErrores = new ArrayList<Map<String, String>>();
		// int cantidadCert = getCantidadCertiOrigen(serie);
		//	for (DatoSerie serie : dua.getListSeries()) {
		boolean tieneDocAutoriz = getDocAutorizante(dua, serie).isEmpty();
		boolean tieneDocAutorizante = tieneDocAutorizante(serie);

		if (tieneDocAutoriz && tieneDocAutorizante) {
			lstErrores.add(((CatalogoAyudaService) fabricaDeServicios
					.getService("Ayuda.catalogoAyudaService")).getError(
							"30814",
							new String[] { serie.getNumserie().toString() }));
			return lstErrores;
		}
		return lstErrores;
		//	}
		//return lstErrores;
	}

	//FIN - MARGE PASE 105 VS RIN13	

	public Map<String,String> validarPuertoEmbarqueDocTransporte(Manifiesto manifiesto, Map<String, Object> params) throws Exception{
		Map<String, Object> paramManif = new HashMap<String, Object>();
		Map<String, String> mapError = new HashMap<String, String>();
		Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
		DocumentoDeTransporteService documentoDeTransporteService = fabricaDeServicios.getService("manifiesto.documentoDeTransporteService");
		Map<String, Object> paramDatado = new HashMap<String, Object>();
		paramManif.put("numeroCorrelativo",manifiesto.getNumeroCorrelativo());
		paramManif.put("numeroDocumentoTransporte", params.get("NUM_DOCTRANSP"));
		//mordonezl pase70
		if(params.get("NUM_CORREDOC")!=null){
			paramDatado.put("detalleNumeroCorrelativo", params.get("NUM_CORREDOC"));
		}
		//fin mordonezl
		paramDatado.put("codigoAduana", manifiesto.getAduana().getCodDatacat());
		paramDatado.put("anioManifiesto", manifiesto.getAnioManifiesto());
		paramDatado.put("numeroManifiesto",manifiesto.getNumeroManifiesto());
		paramDatado.put("codigoTipoManifiesto", manifiesto.getTipoManifiesto().getCodDatacat());
		paramDatado.put("numeroDocumentoTransporte", params.get("NUM_DOCTRANSP"));
		List<Datado> listdatado = datado2Service.obtenerDatadoByParameterMap(paramDatado);
		if (listdatado.size() > 0){
			paramManif.put("numeroDeDetalle",listdatado.get(0).getDocumentoDeTransporte().getNumeroDeDetalle());
		}

		List<DocumentoDeTransporte> listDocTransporte = documentoDeTransporteService.obtenerDocumentosDeTransporteByParameterMap(paramManif);
		if(listDocTransporte.size()>0){
			DocumentoDeTransporte documentoDeTransporte=listDocTransporte.get(0);
			if(!documentoDeTransporte.getPuertoEmbarque().getCodigo().equals(params.get("puertoEmbarque"))){
				mapError = ResponseMapManager.getErrorResponseMap(Constantes.COD_ERROR_MANIFIESTO_DATADO_11503, "EL PUERTO DE EMBARQUE ENVIADO "+params.get("puertoEmbarque")+ " ES DIFERENTE A LA ALMACENADO EN EL DOCUMENTO DE TRANSPORTE "+documentoDeTransporte.getPuertoEmbarque().getCodigo());

			}

		}

		return mapError;
	}

	//Inicio RIN10
	/**
	 * Resumen: M�todo que valida si la declaraci�n cuenta con valor provisional
	 * @param declaracion: dua a validar 
	 * @param declaracionBD: dua BD - se agrega PAS20155E220300034(SAU201510002000221)
	 * @param fechaReferencia: fecha de transmisi�n
	 * @param variablesIngreso: esta todas las etiquetas del xml
	 * @return lista de errores
	 * @Autor oneyraj
	 */
	public List<Map<String, String>> validarIngresoValorProvisional(Declaracion declaracion, Declaracion declaracionBD, Date fechaReferencia, Map<String,Object> variablesIngreso) throws Exception{
		List<Map<String, String>> listError = new ArrayList<Map<String,String>>();

		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");//RIN10 BUG 22556
		// Verifica si transmiti� fecha fin de VP � valor estimado � tipo valor 2 en algunos de los item del formatoB
		boolean transmitioVPEnItemFormatoB = FormatoBUtils.validaTransmisionValorFormatoB(declaracion);
		boolean validarReglaNegocio = true;
		BigDecimal sumaBaseImponibleSeries = BigDecimal.ZERO;

		// Si se envi� VP se procede hacer las validaciones para la numeraci�n CUS 01.03.01 RIN10 - F23003
		if(transmitioVPEnItemFormatoB || declaracion.getDua().getFecfinprovsional() != null) {			   
			DUA dua = declaracion.getDua();			   
			Date fechaFinProvisionalFormatoA = dua.getFecfinprovsional();			   
			if(declaracionBD == null){
				Date fechaMas3Meses = SunatDateUtils.addMonth(fechaReferencia, 3);
				Date fechaMas12Meses = SunatDateUtils.addMonth(fechaReferencia, 12);

				//validacion 1		   
				if(fechaFinProvisionalFormatoA != null && (!SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaFinProvisionalFormatoA, fechaMas3Meses, SunatDateUtils.COMPARA_SOLO_FECHA) 
						|| !SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaFinProvisionalFormatoA, fechaMas12Meses, SunatDateUtils.COMPARA_SOLO_FECHA))) {			   
					//Inicio RIN10 BUG 22556
					//listError.add(ResponseMapManager.getErrorResponseMap("35518", "LA FECHA FIN DEL VALOR PROVISIONAL NO DEBE SER MENOR A 3  MESES NI MAYOR A 12 MESES DESDE LA FECHA DE NUMERACION"));
					listError.add(catalogoAyudaService.getError("35518"));
					//Fin RIN10 BUG 22556
					validarReglaNegocio = false;
				}
			}else{
				//SAU201510002000221 - para rectificaci�n debe ser la fecha de numeraci�n no fecha actual
				Date fechaMas3Meses = SunatDateUtils.addMonth(declaracionBD.getDua().getFecdeclaracion(), 3);
				Date fechaMas12Meses = SunatDateUtils.addMonth(declaracionBD.getDua().getFecdeclaracion(), 12);

				//validacion 1		   
				if(fechaFinProvisionalFormatoA != null && 
						(declaracionBD.getDua().getFecfinprovsional() == null || 
						!SunatDateUtils.sonIguales(fechaFinProvisionalFormatoA, declaracionBD.getDua().getFecfinprovsional(), SunatDateUtils.COMPARA_SOLO_FECHA)) &&  //SAU201510002000221 - si no modifica fecha de valor provisional no debe realizar la validaci�n de plazo
						(!SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaFinProvisionalFormatoA, fechaMas3Meses, SunatDateUtils.COMPARA_SOLO_FECHA) 
								|| !SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaFinProvisionalFormatoA, fechaMas12Meses, SunatDateUtils.COMPARA_SOLO_FECHA))) {			   
					//Inicio RIN10 BUG 22556
					//listError.add(ResponseMapManager.getErrorResponseMap("35518", "LA FECHA FIN DEL VALOR PROVISIONAL NO DEBE SER MENOR A 3  MESES NI MAYOR A 12 MESES DESDE LA FECHA DE NUMERACION"));
					listError.add(catalogoAyudaService.getError("35518"));
					//Fin RIN10 BUG 22556
					validarReglaNegocio = false;
				}
			}

			BigDecimal totalValorEstimadoSerie = BigDecimal.ZERO;
			BigDecimal totalValoresEstimadoTotalesItem = BigDecimal.ZERO;
			boolean tieneItemVP = false; 		   
			for(DatoSerie serie : declaracion.getDua().getListSeries()) {
				sumaBaseImponibleSeries = sumaBaseImponibleSeries.add((serie.getMtoajuste()!=null)?serie.getMtoajuste():BigDecimal.ZERO
						).add((serie.getMtosegdol()!=null)?serie.getMtosegdol():BigDecimal.ZERO
								).add((serie.getMtofledol()!=null)?serie.getMtofledol():BigDecimal.ZERO
										).add((serie.getMtofobdol()!=null)?serie.getMtofobdol():BigDecimal.ZERO);

				BigDecimal montoFobDolaresSerie = serie.getMtofobdol();
				BigDecimal valorEstimadoSerie = BigDecimal.ZERO;
				boolean tieneVPPorSerie = false; //erodriguezb 20141013			  
				if(serie.getValestimado()!=null){			   
					valorEstimadoSerie = serie.getValestimado();
					totalValorEstimadoSerie = totalValorEstimadoSerie.add(valorEstimadoSerie);
					tieneVPPorSerie = true; // erodriguezb 20141013
				}			   

				BigDecimal totalValorEstimadoUnitarioItemFormatoB = BigDecimal.ZERO;				   
				int noTieneTipoValorProvisionalXSerie = 0;

				//validacion 4
				if((fechaFinProvisionalFormatoA != null || serie.getValestimado() != null) && CollectionUtils.isEmpty(declaracion.getListDAVs())) {
					//Inicio RIN10 BUG 22556				   
					//listError.add(ResponseMapManager.getErrorResponseMap("35521", "PARA ACOGERSE AL VALOR PROVISIONAL DEBE ENVIAR EL FORMATO B"));
					listError.add(catalogoAyudaService.getError("35521"));
					//Fin RIN10 BUG 22556
					validarReglaNegocio = false;
				}
				else {
					for(DatoItem items : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie)) {				   
						//validacion 2
						Date fechaFinValorProvisionalItem = items.getMontoProv().getFecvalestima();
						if(fechaFinValorProvisionalItem != null && !SunatDateUtils.sonIguales(fechaFinValorProvisionalItem, fechaFinProvisionalFormatoA, SunatDateUtils.COMPARA_SOLO_FECHA)) {
							//Inicio RIN10 BUG 22556
							//listError.add(ResponseMapManager.getErrorResponseMap("35519", "LAS FECHAS FIN DEL VALOR PROVISIONAL A NIVEL DE ITEM "+items.getNumsecitem().toString()+" DEL FORMATO B DEBEN COINCIDIR CON LA TRANSMITIDA EN DATOS GENERALES DEL FORMATO A"));
							listError.add(catalogoAyudaService.getError("35519",new String[]{items.getNumsecitem().toString()}));
							//Fin RIN10 BUG 22556
							validarReglaNegocio = false;
						}

						//acumulamos cuantos item no tienen valor provisional por c/serie 
						//BUG 21072 correccion AFMA
						String tipoValorProvisional = items.getMontoProv().getIndtipovalor()!=null?items.getMontoProv().getIndtipovalor():"";
						//validacion 3
						if(tieneVPPorSerie && (SunatStringUtils.isEmpty(tipoValorProvisional) || !tipoValorProvisional.equals(TIENE_VALOR_PROVISIONAL))) { //erodriguezb +tieneVPPorSerie
							noTieneTipoValorProvisionalXSerie++;
						}

						//validacion 5		erodriguezb (comentado)					   
						if(TIENE_VALOR_PROVISIONAL.equals(tipoValorProvisional)) {
							tieneItemVP = true;
						}						   

						BigDecimal valorEstimadoUnitarioItemFormatoB = BigDecimal.ZERO;
						if(items.getMontoProv().getValmonto() != null) {
							valorEstimadoUnitarioItemFormatoB = items.getMontoProv().getValmonto();
						}

						//amancilla BigDecimal montoFOBUnitarioItem = items.getMtofobunita();
						BigDecimal montoFOBUnitarioItem = items.getMtofobunita().add(items.getMtoajusunita()!=null?items.getMtoajusunita():BigDecimal.ZERO);
						if(items.getMontoProv().getValmonto() != null) {
							//validacion 7 erodriguezb +tieneVPPorSerie
							//amancilla PAS20155E220200148
							// inicialemnte if(tieneVPPorSerie && (!SunatNumberUtils.isGreaterThanZero(valorEstimadoUnitarioItemFormatoB) || SunatNumberUtils.isGreaterThanParam(valorEstimadoUnitarioItemFormatoB, montoFOBUnitarioItem))) {
							if(tieneVPPorSerie && !SunatNumberUtils.isGreaterThanZero(valorEstimadoUnitarioItemFormatoB)) {
								//esto no podra ser if(tieneVPPorSerie && !SunatNumberUtils.isEqual(valorEstimadoUnitarioItemFormatoB, montoFOBUnitarioItem) ) {
								//Inicio RIN10 BUG 22556							   
								//listError.add(ResponseMapManager.getErrorResponseMap("35493", "EL VALOR ESTIMADO (unitario) DEL ITEM "+items.getNumsecitem().toString()+" DEBE SER MAYOR A CERO Y MENOR/IGUAL AL FOB UNITARIO US$ DECLARADO  EN EL ITEM"));
								//amancilla PAS20155E220200167 este metodo es invocado desde la recti se duplica codigfos de error para la mismo item
								String codTransaccion   =(String) variablesIngreso.get("codTransaccion");
								if(StringUtils.isEmpty(codTransaccion)){
									codTransaccion=declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans():"";
								}
								if(!"1003".equals(codTransaccion)){
									listError.add(catalogoAyudaService.getError("35493",new String[]{items.getNumsecitem().toString()}));
									//Fin RIN10 BUG 22556
									validarReglaNegocio = false;
								}
								//fin amancilla PAS20155E220200167
							}

							//sumamanos todos los valores estimados unitarios del item por su cantidad
							BigDecimal tmpValorEstimadoUnitario = TIENE_VALOR_PROVISIONAL.equals(tipoValorProvisional)?
									items.getMontoProv().getValmonto():BigDecimal.ZERO;
									totalValorEstimadoUnitarioItemFormatoB = totalValorEstimadoUnitarioItemFormatoB.add(tmpValorEstimadoUnitario.multiply(items.getCntcantcomer()));

						}

						//validacion 8
						if(serie.getValestimado() != null && !tipoValorProvisional.equals(TIENE_VALOR_PROVISIONAL)) {
							//Inicio RIN10 BUG 22556
							//listError.add(ResponseMapManager.getErrorResponseMap("35525", "SI TRANSMITE VALOR ESTIMADO A NIVEL DE SERIE "+serie.getNumserie().toString()+" DEBE TRANSMITIR TIPO DE VALOR 2 (PROVISIONAL) EN LOS ITEMS CORRELACIONADOS DEL FORMATO B O SI TRANSMITE TIPO DE VALOR 2 (PROVISIONAL) EN LOS ITEMS DEL FORMATO B DEBE TRANSMITIR  VALOR ESTIMADO A NIVEL DE LA SERIE "+serie.getNumserie().toString()+" CORRELACIONADA DEL FORMATO A"));
							listError.add(catalogoAyudaService.getError("35525",new String[]{serie.getNumserie().toString(),serie.getNumserie().toString()}));
							//Fin RIN10 BUG 22556
							validarReglaNegocio = false;
						}

						//validacion 9
						if(tipoValorProvisional.equals(NO_TIENE_VALOR_PROVISIONAL)) {
							if(items.getMontoProv().getValmonto() != null && valorEstimadoUnitarioItemFormatoB.compareTo(BigDecimal.ZERO) != 0) {
								//Inicio RIN10 BUG 22556
								//listError.add(ResponseMapManager.getErrorResponseMap("35526", "EL VALOR ESTIMADO (UNITARIO) DEL ITEM "+items.getNumsecitem().toString()+"DEBE SER IGUAL A CERO CUANDO SE DECLARAN VALORES DEFINITIVOS"));
								listError.add(catalogoAyudaService.getError("35526",new String[]{items.getNumsecitem().toString()}));
								//Fin RIN10 BUG 22556
								validarReglaNegocio = false;
							}
						}

						// Inicio rin10 mpoblete [Se agreg� mensaje de error que no esta especificado en la rin]
						if(tieneVPPorSerie && TIENE_VALOR_PROVISIONAL.equals(tipoValorProvisional) && fechaFinValorProvisionalItem == null) {
							//Inicio RIN10 BUG 22556
							//listError.add(ResponseMapManager.getErrorResponseMap("35511", "SI AL MENOS UNO DE LOS ITEMS TIENE VALOR PROVISIONAL, ENTONCES DEBE INDICAR LA FECHA FIN DEL VALOR PROVISIONAL"));
							listError.add(catalogoAyudaService.getError("35511"));
							//Fin RIN10 BUG 22556
							validarReglaNegocio = false;
						}

						if(tieneVPPorSerie && !TIENE_VALOR_PROVISIONAL.equals(tipoValorProvisional) && fechaFinValorProvisionalItem != null) {
							//Inicio RIN10 BUG 22556
							//listError.add(ResponseMapManager.getErrorResponseMap("35522", "SI ENVIA FECHA FIN DE VALOR PROVISIONAL "+SunatDateUtils.getFormatDate(fechaFinValorProvisionalItem, FechaBean.FORMATO_DEFAULT)+", ALGUNO DE LOS ITEMS DEBE TENER EL CODIGO DE VALOR PROVISIONAL"));
							listError.add(catalogoAyudaService.getError("35522",new String[]{SunatDateUtils.getFormatDate(fechaFinValorProvisionalItem, FechaBean.FORMATO_DEFAULT)}));
							//Fin RIN10 BUG 22556	
							validarReglaNegocio = false;
						}
						// Fin rin10 mpoblete [Se agreg� mensaje de error que no esta especificado en la rin]
					}
				}

				//validacion 3
				if(noTieneTipoValorProvisionalXSerie > 0){
					//Inicio RIN10 BUG 22556
					//listError.add(ResponseMapManager.getErrorResponseMap("35520", "TODOS LOS ITEMS ASOCIADOS A LA SERIE "+serie.getNumserie().toString()+" CON VALOR PROVISIONAL DEBEN TENER CONSIGNADO EL CODIGO 2 EN LA CASILLA 5.6 DEL FORMATO B"));
					listError.add(catalogoAyudaService.getError("35520",new String[]{serie.getNumserie().toString()}));
					//Fin RIN10 BUG 22556	
					validarReglaNegocio = false;
				}

				if(serie.getValestimado() != null) { 
					//validacion 6
					//amancilla PAS20155E220200148
					//if(SunatNumberUtils.isLessOrEqualsThanParam(valorEstimadoSerie, 0) || SunatNumberUtils.isGreaterThanParam(valorEstimadoSerie, montoFobDolaresSerie)) {
					if(SunatNumberUtils.isLessOrEqualsThanParam(valorEstimadoSerie, 0)) {
						//Inicio RIN10 BUG 22556
						//listError.add(ResponseMapManager.getErrorResponseMap("35492", "EL VALOR ESTIMADO DE LA SERIE "+serie.getNumserie().toString()+" DEBE SER MAYOR A CERO Y MENOR/IGUAL AL FOB US$ DECLARADO EN LA SERIE "+serie.getNumserie().toString()));
						//amancilla PAS20155E220200148 listError.add(catalogoAyudaService.getError("35492",new String[]{serie.getNumserie().toString(),serie.getNumserie().toString()}));
						listError.add(catalogoAyudaService.getError("35492",new String[]{serie.getNumserie().toString()}));
						//Fin RIN10 BUG 22556
						validarReglaNegocio = false;
					}

					if(SunatNumberUtils.isGreaterThanParam((valorEstimadoSerie.subtract(totalValorEstimadoUnitarioItemFormatoB)).abs(),TOLERANCIA_USS)){
						//Inicio RIN10 BUG 22556
						//listError.add(ResponseMapManager.getErrorResponseMap("35494", "EL VALOR ESTIMADO "+valorEstimadoSerie.toString()+" DE LA SERIE "+serie.getNumserie()+" DEL FORMATO A DEBE COINCIDIR CON LA SUMA DE LOS PRODUCTOS DEL VALOR ESTIMADO UNITARIO POR LA CANTIDAD A NIVEL DE ITEM DEL FORMATO B "+totalValorEstimadoUnitarioItemFormatoB.toString()+" CORRESPONDIENTES A DICHA SERIE"));
						listError.add(catalogoAyudaService.getError("35494",new String[]{valorEstimadoSerie.toString(),serie.getNumserie().toString(),totalValorEstimadoUnitarioItemFormatoB.toString()}));
						//Fin RIN10 BUG 22556
						validarReglaNegocio = false;
					}
				}

				totalValoresEstimadoTotalesItem = totalValoresEstimadoTotalesItem.add(totalValorEstimadoUnitarioItemFormatoB);

			}

			//validacion 11 (falta verificar)
			if(SunatNumberUtils.isGreaterThanParam((totalValorEstimadoSerie.subtract(totalValoresEstimadoTotalesItem)).abs(),TOLERANCIA_USS)){//erodriguezb
				//Inicio RIN10 BUG 22556
				//listError.add(ResponseMapManager.getErrorResponseMap("35495", "LA SUMATORIA DE LOS VALORES ESTIMADOS A NIVEL DE SERIES "+totalValorEstimadoSerie.toString()+" DEBERA SER IGUAL A LA SUMATORIA DE LOS VALORES ESTIMADOS UNITARIOS DE LOS ITEMS ASOCIADOS MULTIPLICADOS POR LA CANTIDAD DE DICHO ITEM "+totalValoresEstimadoTotalesItem.toString()));
				listError.add(catalogoAyudaService.getError("35495",new String[]{totalValorEstimadoSerie.toString(),totalValoresEstimadoTotalesItem.toString()}));
				//Fin RIN10 BUG 22556	
				validarReglaNegocio = false;
			}


			//Inicio mpoblete RIN10 BUG 21203		   
			if(tieneItemVP && fechaFinProvisionalFormatoA == null){
				//Inicio RIN10 BUG 22556
				//listError.add(ResponseMapManager.getErrorResponseMap("35511", "SI AL MENOS UNO DE LOS ITEMS TIENE VALOR PROVISIONAL, ENTONCES DEBE INDICAR LA FECHA FIN DEL VALOR PROVISIONAL"));
				listError.add(catalogoAyudaService.getError("35511"));
				//Fin RIN10 BUG 22556	
				validarReglaNegocio = false;
			}

			if(fechaFinProvisionalFormatoA != null && !tieneItemVP){
				//Inicio RIN10 BUG 22556
				//listError.add(ResponseMapManager.getErrorResponseMap("35522", "SI ENVIA FECHA FIN DE VALOR PROVISIONAL"+SunatDateUtils.getFormatDate(fechaFinProvisionalFormatoA, FechaBean.FORMATO_DEFAULT)+", ALGUNO DE LOS ITEMS DEBE TENER EL CODIGO DE VALOR PROVISIONAL"));
				listError.add(catalogoAyudaService.getError("35522",new String[]{SunatDateUtils.getFormatDate(fechaFinProvisionalFormatoA, FechaBean.FORMATO_DEFAULT)}));
				//Fin RIN10 BUG 22556
				validarReglaNegocio = false;
			}
			//Fin mpoblete RIN10 BUG 21203

		}else {
			validarReglaNegocio = false;
		}

		//si no hay error, se procede a validar el nro de cuenta corriente y actualizar el fob estimado del item	   
		if(validarReglaNegocio) {
			variablesIngreso.put("transmisionValorProvisional", "SI");
			//           Inicio Refactor RIN10 (Se paso fragmento de codigo al metodo validaAnexoDeclaracionService.validarSaldoOperativoDisponibleCtaCteGarantiaVP)
			//		   DatoPago pago = declaracion.getDua().getPago();
			//		   DatoPagoDecla decla = pago!=null?pago.getPagoDeclaracion():null;
			//		   String codigoTipoPago = decla.getCodtipopago() != null ? decla.getCodtipopago() : "";
			//		   //si esta acogida a la garantia160 debe enviar el tipo de pago G y el numero de la cuenta corriente 
			//		   if(codigoTipoPago.equals(TIPO_PAGO_GARANTIA) && decla.getCodgarantia() != null){				   
			//			   Map<String, Object> params = new HashMap<String, Object>();
			//			   params.put("NUMCTACTE", decla.getCodgarantia());
			//			   params.put("FECHAPROCESO", fechaReferencia);
			//			   params.put("IND_ACTIVO", "1");
			//				  
			//			   // obtenemos los datos de la cta corriente
			//			   Map<String, Object> resultado = RectificacionServiceImpl.getInstance().getCabCtaCteGarDAO().findByNumCtaCte(params);
			//			   
			//			   if(!CollectionUtils.isEmpty(resultado)){
			//				   // si esta vigente la cta corriente obtiene el porcentaje de la base impobible
			//				   DataCatalogo dataCatalogo = RectificacionServiceImpl.getInstance().getDataCatalogoDAO().buscarDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP, ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP);
			//				   BigDecimal porcentajeBaseImponible = new BigDecimal(dataCatalogo.getDesCorta());
			//				   
			//				   // obtenemos el saldo operativo de la cta corriente
			//				   BigDecimal saldoOperativoDisponible = resultado.get("MTOSALDOOPEDISP")!=null? 
			//							new BigDecimal(resultado.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;			   
			//					   
			//				   //base imponible = Monto Ajuste + Monto Flete + Monto Total de Seguros + Monto Total Fob
			//				   //el saldoOperativo debe ser mayor o igual al porcentaje de la suma de todas las series con valor provisional 
			//				   if(!SunatNumberUtils.isGreaterOrEqualsThanParam(saldoOperativoDisponible, sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal("100"))))) {			   
			//					   listError.add(ResponseMapManager.getErrorResponseMap("35194", "LA CTACTE DE LA GARANTIA NO TIENE SALDO OPERATIVO"));
			//				   }
			//			   }
			//			   
			//		   }

			ValidaAnexoDeclaracionService validaAnexoDeclaracionService = (ValidaAnexoDeclaracionService)fabricaDeServicios.getService("validaAnexoDeclaracion");
			listError.addAll(validaAnexoDeclaracionService.validarSaldoOperativoDisponibleCtaCteGarantiaVP(declaracion,fechaReferencia,sumaBaseImponibleSeries));
			//			   Fin Refactor RIN10		    

			Map<String, Object> pFecha = new HashMap<String, Object>(); //select fnCalculaDias(20111101,0,'U','2','S','N') from dual
			int operacion = 2; //2: Sumatoria de d�as
			String tipodia = "U"; //U: d�a Calendario
			String incluye = "S"; //N: Se cuenta del dia siguiente
			String alcance = "S"; //N: No cuenta las fechas suspendidas�.cat_suspende
			pFecha.put("NUMDIAS", 0);
			pFecha.put("TIPODIA", tipodia);
			pFecha.put("OPERACION", operacion);
			pFecha.put("INCLUYE", incluye);
			pFecha.put("ALCANCE", alcance);
			pFecha.put("COD_ADUANA", declaracion.getCodaduana());
			pFecha.put("FECHAINICIAL", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecfinprovsional()));

			// INICIO DE VALIDACI�N DE FECHA FIN DE VALOR PROVISIONAL
			Date fechaCalculada = declaracion.getDua().getFecfinprovsional();

			FuncionesFechaService funcionesFechaService = (FuncionesFechaService) fabricaDeServicios.getService("FuncionesFechaService");
			String fechaLaborable = funcionesFechaService.obtenerSgteDiaUtil(pFecha);

			if(fechaLaborable != null && !fechaLaborable.equals(0) & !fechaLaborable.equals("")){
				fechaCalculada = SunatDateUtils.getDateFromInteger(Integer.parseInt(fechaLaborable));	
			}


			//Si la fecha ha sido cambiada por ser d�a no laborable
			if(!SunatDateUtils.sonIguales(declaracion.getDua().getFecfinprovsional(), fechaCalculada, SunatDateUtils.COMPARA_SOLO_FECHA)){

				variablesIngreso.put("cambiarFechaFinValorProvisional", fechaCalculada);

				//Actualizamos fecha fin de VP del formato A
				declaracion.getDua().setFecfinprovsional(fechaCalculada);

				//Actualizamos fecha fin de VP de los items del formato B
				if (!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
					for (DAV dav : declaracion.getListDAVs()) {				
						for (DatoFactura factura : dav.getListFacturas()) {
							for (DatoItem item : factura.getListItems()) {
								if(item.getMontoProv().getValmonto()!=null)
									item.getMontoProv().setFecvalestima(fechaCalculada);
							}
						}
					}
				}
			}			
		}

		return listError;
	}
	//Fin RIN10	

	/**
	 * PAS20181U220200022 se movio a validacionOEAServiceImpl
	 * Esto ya no va aca
	 * Realiza las validacion de la garantia Nominal
	 *  
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	@Deprecated
	@ServicioAnnot(tipo="V",codServicio=2542)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2542,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> validarGarantiaNominal(Declaracion declaracion, Date fechaReferencia) {
		DUA dua=declaracion.getDua();
		List<Map<String, Object>> listGarantiaGlobal =  new ArrayList<Map<String,Object>>();
		boolean  esGarantiaNominal = false;
		boolean  esOEA = false;
		boolean  esInvitadoOEA = false;
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		String tipo_docum = "";
		String nume_docum = "";
		Map<String, Object> MapOperadoroea = null;
		if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(), ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)) {
			tipo_docum = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
			nume_docum = dua.getDeclarante().getNumeroDocumentoIdentidad();
		}						
		String tieneGarantia = declaracion.getDua().getPago()!=null?declaracion.getDua().getPago().getPagoDeclaracion()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():"":"":"";
		if(!tieneGarantia.equalsIgnoreCase("")){
			Map<String,Object> params=new HashMap<String,Object>();
			params.put("CTIPO_GARANT", "4");
			params.put("CESTA_OPER", "01");
			params.put("NUMEDOCBEN", nume_docum);
			params.put("NUM_CTACTE",declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
			listGarantiaGlobal=((MovNGarantiaDAO)fabricaDeServicios.getService("movNGarantiaDAO")).findGarantiasNominal(params);
			if (!listGarantiaGlobal.isEmpty() ){
				esGarantiaNominal = true;
	}
	
		}
		if ( esGarantiaNominal ) {
			String cadError = "";
			// Se valida exportador OEA para que no lance en regimen 10
			if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO )   ) {
				MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(nume_docum,
						ConstantesDataCatalogo.EXPORTADOR_OEA,ConstantesDataCatalogo.ESTADO_CERITIFICADO_OEA,fechaReferencia); 
				if ( !CollectionUtils.isEmpty(MapOperadoroea)){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("13209", new String[]{nume_docum,dua.getCodregimen()}));
					return listError;
				}
			}
	  
			//Valida al Importador OEA
			Map<String, Object> MapOperadoroeaAct = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(
					nume_docum, ConstantesDataCatalogo.IMPORTADOR_OEA,ConstantesDataCatalogo.ESTADO_CERITIFICADO_OEA,fechaReferencia);
			if (CollectionUtils.isEmpty(MapOperadoroeaAct)){
				//Valida al Exportador OEA solo para el regimen 20 y 21
				if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)  ) {
					MapOperadoroeaAct = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(nume_docum, 
							ConstantesDataCatalogo.EXPORTADOR_OEA,ConstantesDataCatalogo.ESTADO_CERITIFICADO_OEA,fechaReferencia); 
					if ( !CollectionUtils.isEmpty(MapOperadoroeaAct)){
						esOEA=true;
					}
				}
			} else {
				esOEA=true;
			}
			if ( !esOEA) {
				//Valida si existe registrado el Importador OEA
				  MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(nume_docum, ConstantesDataCatalogo.IMPORTADOR_OEA);
				  if (!CollectionUtils.isEmpty(MapOperadoroea)){
					  cadError = "13204";
				  } else {
					//Valida si existe registrado el Exportador OEA solo para el regimen 20 y 21
					if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)  ) {
						  MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(nume_docum, ConstantesDataCatalogo.EXPORTADOR_OEA);
						  if (!CollectionUtils.isEmpty(MapOperadoroea)){
							  cadError = "13208";
						  }
					}
				  }
			}
			if (esOEA) {
				esOEA=true;
				// Para regimen 10 valida el uso solo para ANTICIPADO Y URGENTE
				if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)   ) {
					if ((dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)) ) {
						cadError = "13203";
					}
				}
			}

			if ( !esOEA ) {
				//SE VALIDA SI ES INVITADO OEA
				Map<String, Object> MapaInvitadoOEA =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat( ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, nume_docum,fechaReferencia);
				if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
					esInvitadoOEA = true;
					if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)   ) {
						if ( !(dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) ) {
							cadError = "13205";
						} else {
							cadError = "";
						}
					}
				} else {
					//VALIDA SI AL MENOS EXISTE EL INVITADO OEA
					if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)   ) {
						List<Map<String,Object>> listaInvitadoOEA =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaDatacatalogo(ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, nume_docum);
						   if( !CollectionUtils.isEmpty(listaInvitadoOEA) && cadError.trim().length()==0) {
							   esInvitadoOEA = true;
							   cadError = "13206";
						   }  
					}
				}
			}
			 
			//Para el regimen 20 y 21 no puede enviar OEA
			if (esInvitadoOEA && (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME)  || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA) ) ) {
				cadError = "13207";
			}			
			if (cadError.trim().length()>0 ) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(cadError, new String[]{nume_docum,dua.getCodregimen()}));
			}
		}
		return listError;
	}	

	//PAS20181U220200019 - mtorralba 20190410 - INICIO
	public Manifiesto obtenerManifiesto(String codtipmanif, String codmodtransp, String codaduamanif, Integer annmanif, String nummanif, Date fechaDeclaracion, String codlugarRecepcion) {

		Manifiesto manifiestoBD = null;
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");

		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
		String codigoViaTransporteSda = null;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			boolean considerarEER = codlugarRecepcion!=null && codlugarRecepcion.equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR) ? true : false;
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true,fechaDeclaracion,considerarEER);
		}else{
		//con esto busca en sda o en sigad:
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif, true);
		}
		return manifiestoBD;
	}

	//PAS20181U220200019 - mtorralba 20190410 - FIN



}
