package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bultos;

import java.math.BigDecimal;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;

public class ValBultosEERServiceImpl extends IngresoAbstractServiceImpl implements ValBultosEERService  {
	
	protected final Log logBultosEER = LogFactory.getLog(getClass());
	
	public List<Map<String,String>> valBultos0203(Declaracion declaracion, String codCategoria) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_02.equals(codCategoria) || 
			ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			
			BigDecimal cantidadBultos = declaracion.getDua().getCnttcantbulto();
			if (cantidadBultos.compareTo(BigDecimal.ZERO) <= 0) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70115"));
			}
		}
	   /*
	      si codCategoria es igual a "02", "03"
	      obtenemos la cantidad de bultos declarado bultos = declaracion.getDUA().getCnttcantbulto()
	      Si bultos no es mayor que cero
	      Emitir el mensaje E37
	   */
		return listError;
	}
	
}
