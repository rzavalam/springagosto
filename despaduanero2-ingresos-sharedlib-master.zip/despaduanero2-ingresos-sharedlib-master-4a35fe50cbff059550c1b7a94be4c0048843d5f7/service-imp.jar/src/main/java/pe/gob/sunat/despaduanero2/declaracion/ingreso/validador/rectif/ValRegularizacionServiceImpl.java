/*
 * Clase que define el servicio de validaciones de las Regularizaciones
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.administracion2.tramite.util.ConstantesTramite;
import pe.gob.sunat.despaduanero.despacho.entrada.pa.model.dao.Ratcc3DAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Depocta;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitCcDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
// RIN16
//import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
// RIN16
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValModalidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.RectificacionOficioService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Expedi;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabNacioTempoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExpediDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.service.SoliAnulacionService;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
// RIN16
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.despaduanero2.service.SolicitudContinuacionTramiteService;//PAS20171U220200031
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;

public class ValRegularizacionServiceImpl extends ValDuaAbstract implements ValRegularizacion{

	private ValRectif valRectif;
	//private ValCabdua valCabdua;
	//private CatalogoAyudaService catalogoAyudaService;
	//private IndicadorDUADAO indicadorDUADAO;
	//private FabricaDeServicios fabricaDeServicios; 
	//private FormBProveedorDAO formBProveedorDAO;
	// RIN16
	private static final String CATALOGO_SUBGR_MERC_USADA="531";
	private static final String CATALOGO_SUBGR_MERC_NUEVA="532";
	private static final Integer PLAZO_VENCIMIENTO_REGULARIZACION = 15;//RIN16

	/*
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
		this.indicadorDUADAO = indicadorDUADAO;
	}*/




	/**
	 * Si es anticipado XX04 solo se enviaran los siguientes datos:
	 * a)	Puerto de embarque
	 * b)	Peso bruto total
	 * c)	Peso neto total
	 * d)	Peso bruto por serie
	 * e)	Peso neto por serie
	 * f)	Fecha del t�rmino de la descarga.
	 * g)	Cantidad de bultos
	 * h)	Valor FOB total
	 * i)	Valor FOB moneda de transacci�n 
	 * j)	Valor FOB por serie
	 * k)	Valor del seguro total
	 * l)	Valor del seguro por serie
	 * m)	Valor CIF total
	 * n)	Valor CIF por serie
	 * o)	Cantidad total de unidades f�sicas
	 * p)	Cantidad de unidades f�sicas por serie 
	 * q)	Cantidad total de unidades comerciales 
	 * r)	Cantidad de unidades comerciales por serie.
	 * Si es urgente XX05 se enviaran todos los datos.
	 * @param declaracion
	 * @param numOrden
	 * @param codUsuario
	 * @param annEnvio
	 * @param numEnvio
	 * @param tipoSender
	 * @param numeroDocumentoIdentidadSender
	 * @param tipoDocumentoIdentidadSender
	 * @param codTransaccion
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	@ServicioAnnot(tipo="A",codServicio=3000,descServicio="Almacenamiento de la variable declaracion")
	@ServInstDetAnnot(tipoRpta={0,1,1,1,1,1,1,1,1},
	nomAtr={"this","numOrden","codUsuario","annEnvio","numEnvio","tipoSender","numeroDocumentoIdentidadSender","tipoDocumentoIdentidadSender","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=3000,numSecEjec=330,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, Object> setupDeclaracion(Declaracion declaracion, 
			String numOrden,
			String codUsuario, 
			Integer annEnvio, 
			Long numEnvio,
			String tipoSender,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, String codTransaccion) throws Exception {
		HashMap<String, Object> response = new HashMap<String, Object>();
		Declaracion declacionBDXML = new Declaracion();
		Boolean encontrarDocTrans = false;
		Boolean diferenciaSeries = false;
		Boolean diferenciaDocTransporte = false;
		Boolean diferenciaTx05 = false;
		String datoModificado = "";
		// Las txs XX05 (urgentes) pueden tx todos los campos
		// Las txs XX04 (anticipada) pueden tx solo los campos del cun17
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
// cambio del pase 19 regu
		//afma parche para que funcio OMA en REGU
		ValCabdua valCabdua = (ValCabdua) fabricaDeServicios.getService("ValCabdua");
		if(codTransaccion.contains("1004")) {
			valCabdua.setupDeclaracion(declaracion, numOrden, codUsuario, annEnvio,
					numEnvio, tipoSender, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, codTransaccion);
		}
		String codigoAduana = "";
		if( declaracion.getPadre() != null){
			codigoAduana = ((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden()!=null?((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden().toString():declaracion.getCodaduana().toString();
		} else if( !StringUtils.isEmpty(numdeclRef.getCodaduana())){
			codigoAduana = numdeclRef.getCodaduana();
		}

		if (StringUtils.isEmpty(declaracion.getCodaduana())) {
			declaracion.setCodaduana(codigoAduana);
		}
		if (StringUtils.isEmpty(declaracion.getDua().getCodaduanaorden())) {
			declaracion.getDua().setCodaduanaorden(codigoAduana);
		}
		//Declaracion declaracionBD = RectificacionServiceImpl.getInstance().getDeclaracionService().getDeclaracion(numdeclRef.getCodaduana(),
		Declaracion declaracionBD;
		try{
			declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(numdeclRef.getCodaduana(),
					new Integer(numdeclRef.getNumcorre()), new Integer(numdeclRef.getAnnprese()), numdeclRef.getCodregimen(), codTransaccion);
		} catch (Exception e) {
			declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(numdeclRef.getCodaduana(),
					new Integer(numdeclRef.getNumcorre()), new Integer(numdeclRef.getAnnprese()), numdeclRef.getCodregimen());
		}
		//jreynoso inicio 
		List<DatoDocTransporte> documentosDeTransporteBD = new ArrayList<DatoDocTransporte>();
		documentosDeTransporteBD.addAll( declaracionBD.getDua().getListDocTransporte());
		//jreynoso fin
		List<DatoDocTransporte> documentosDeTransporteXml = new ArrayList<DatoDocTransporte>();
		documentosDeTransporteXml.addAll( declaracion.getDua().getListDocTransporte() );

		if (SunatStringUtils.include(codTransaccion.substring(2), new String[] { "05" })) {
			declacionBDXML = declaracion;
			// codigo del regimen
			if (declacionBDXML.getDua().getCodregimen() != null) {
				if (!declacionBDXML.getDua().getCodregimen().equals(declaracionBD.getDua().getCodregimen())) {
					diferenciaTx05 = true;
					datoModificado = "codRegimen";
				}
			}
			declacionBDXML.getDua().setCodregimen(numdeclRef.getCodregimen());
			// Se guarda el codigo y tipo de garantia por que ese dato no se puede cambiar se tomara el existe en la base de datos
			if (declacionBDXML.getDua().getPago().getPagoDeclaracion() != null) {
				if (declacionBDXML.getDua().getPago().getPagoDeclaracion().getCodgarantia() != null) {
					if (!declacionBDXML.getDua().getPago().getPagoDeclaracion().getCodgarantia().equals(
							declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia())) {
						diferenciaTx05 = true;
						datoModificado = "codGarantia";
					}
				}
			}
			if (declacionBDXML.getDua().getPago().getPagoDeclaracion() != null) {
				if (declacionBDXML.getDua().getPago().getPagoDeclaracion().getCodtipopago() != null) {
					if (!declacionBDXML.getDua().getPago().getPagoDeclaracion().getCodtipopago().equals(
							declaracionBD.getDua().getPago().getPagoDeclaracion().getCodtipopago())) {
						diferenciaTx05 = true;
						datoModificado = "Codtipopago";
					}
				}
			}
			if (declacionBDXML.getDua().getFecconclusion() != null) {
				if (!declacionBDXML.getDua().getFecconclusion().equals(declaracionBD.getDua().getFecconclusion())) {
					diferenciaTx05 = true;
					datoModificado = "Fecconclusion";
				}
			}
			if (declacionBDXML.getDua().getPago().getPagoDeclaracion() != null) {
				declacionBDXML.getDua().getPago().getPagoDeclaracion().setCodgarantia(
						declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia());
				declacionBDXML.getDua().getPago().getPagoDeclaracion().setCodtipopago(
						declaracionBD.getDua().getPago().getPagoDeclaracion().getCodtipopago());
			} else {
				declacionBDXML.getDua().getPago().setPagoDeclaracion(declaracionBD.getDua().getPago().getPagoDeclaracion());
			}
			declacionBDXML.getDua().setFecconclusion(declaracionBD.getDua().getFecconclusion());
			declacionBDXML.getDua().setFecvenconclu(declaracionBD.getDua().getFecvenconclu());//setear el valor de la fecha vencimiento conclusion jreynoso
			// Se guardara la informacion de manifiesto
			if (declacionBDXML.getDua().getManifiesto().getAnnmanif() != null) {
				if (!declacionBDXML.getDua().getManifiesto().getAnnmanif().equals(declaracionBD.getDua().getManifiesto().getAnnmanif())) {
					diferenciaTx05 = true;
					datoModificado = "Anio Manifiesto";
				}
			}
			if (declacionBDXML.getDua().getManifiesto().getNummanif() != null) {
				if (!declacionBDXML.getDua().getManifiesto().getNummanif().trim().equals(declaracionBD.getDua().getManifiesto().getNummanif().trim())) {
					diferenciaTx05 = true;
					datoModificado = "Num Manifiesto";
				}
			}
			if (declacionBDXML.getDua().getManifiesto().getCodtipomanif() != null) {
				if (!declacionBDXML.getDua().getManifiesto().getCodtipomanif().equals(declaracionBD.getDua().getManifiesto().getCodtipomanif())) {
					diferenciaTx05 = true;
					datoModificado = "Tipo  de Manifiesto";
				}
			}
			if (declacionBDXML.getDua().getManifiesto().getCodaduamanif() != null) {
				if (!declacionBDXML.getDua().getManifiesto().getCodaduamanif().equals(declaracionBD.getDua().getManifiesto().getCodaduamanif())) {
					diferenciaTx05 = true;
					datoModificado = "Aduana Manifiesto";
				}
			}
			declacionBDXML.getDua().getManifiesto().setAnnmanif(declaracionBD.getDua().getManifiesto().getAnnmanif());
			declacionBDXML.getDua().getManifiesto().setNummanif(declaracionBD.getDua().getManifiesto().getNummanif().trim());
			declacionBDXML.getDua().getManifiesto().setCodtipomanif(declaracionBD.getDua().getManifiesto().getCodtipomanif());
			declacionBDXML.getDua().getManifiesto().setCodaduamanif(declaracionBD.getDua().getManifiesto().getCodaduamanif());
			// RIN 16 - Se agrega nueva fecha de vencimiento de regularizacion otorgado por la Administracion Aduanera de existir
			declacionBDXML.getDua().setFecvencregula(declaracionBD.getDua().getFecvencregula());
			// Se adiciona porque no esta llegando a las validaciones VUCE en caso de tx1005 
			declaracion.getDua().setDeclarante(declaracionBD.getDua().getDeclarante());
			// Datos del importador
			if (declacionBDXML.getDua().getDeclarante().getNumeroDocumentoIdentidad() != null) {
				if (!declacionBDXML.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(
						declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad())) {
					diferenciaTx05 = true;
					datoModificado = "NumeroDocumentoIdentidad del importador";
				}
			}
			declacionBDXML.getDua().getDeclarante().setNumeroDocumentoIdentidad(declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (declacionBDXML.getDua().getDeclarante().getDireccion() != null) {
				if (!declacionBDXML.getDua().getDeclarante().getDireccion().equals(declaracionBD.getDua().getDeclarante().getDireccion())) {
					diferenciaTx05 = true;
					datoModificado = "Direccion del importador";
				}
			}
			declacionBDXML.getDua().getDeclarante().setDireccion(declaracionBD.getDua().getDeclarante().getDireccion());
			if (declacionBDXML.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat() != null) {
				if (!declacionBDXML.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals(
						declaracionBD.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat())) {
					diferenciaTx05 = true;
					datoModificado = "TipoDocumentoIdentidad del importador";
				}
			}
			declacionBDXML.getDua().getDeclarante().setTipoDocumentoIdentidad(declaracionBD.getDua().getDeclarante().getTipoDocumentoIdentidad());
			// Datos del agente
			if (declacionBDXML.getDua().getCodtipooper() != null) {
				if (!declacionBDXML.getDua().getCodtipooper().equals(declaracionBD.getDua().getCodtipooper())) {
					diferenciaTx05 = true;
					datoModificado = "Codtipooper del importador";
				}
			}
			declacionBDXML.getDua().setCodtipooper(declaracionBD.getDua().getCodtipooper());
			if (declacionBDXML.getDua().getNumdocumento() != null) {
				if (!declacionBDXML.getDua().getNumdocumento().equals(declaracionBD.getDua().getNumdocumento())) {
					diferenciaTx05 = true;
					datoModificado = "Numdocumento del importador";
				}
			}
			declacionBDXML.getDua().setNumdocumento(declaracionBD.getDua().getNumdocumento());
			// Datos a rescatar

			if (!SunatStringUtils.include(numdeclRef.getCodregimen(), new String[] { "20", "21" })) { // si no son ni reg 20 ni 21{
				if (declacionBDXML.getDua().getFecfinacoregimen() != null) {
					if (!declacionBDXML.getDua().getFecfinacoregimen().equals(declaracionBD.getDua().getFecfinacoregimen())) {
						diferenciaTx05 = true;
						datoModificado = "Fecfinacoregimen";
					}
				}
				declacionBDXML.getDua().setFecfinacoregimen(declaracionBD.getDua().getFecfinacoregimen());
			}
			if (declacionBDXML.getDua().getCodaduanaorden() != null) {
				if (!declacionBDXML.getDua().getCodaduanaorden().equals(declaracionBD.getDua().getCodaduanaorden())) {
					diferenciaTx05 = true;
					datoModificado = "Codaduanaorden";
				}
			}
			declacionBDXML.getDua().setCodaduanaorden(declaracionBD.getDua().getCodaduanaorden());
			if (declacionBDXML.getDua().getAnnpresen() != null) {
				if (!declacionBDXML.getDua().getAnnpresen().equals(declaracionBD.getDua().getAnnpresen())) {
					diferenciaTx05 = true;
					datoModificado = "Annpresen";
				}
			}
			declacionBDXML.getDua().setAnnpresen(declaracionBD.getDua().getAnnpresen());
			if (declacionBDXML.getDua().getFecdeclaracion() != null) {
				if (!declacionBDXML.getDua().getFecdeclaracion().equals(declaracionBD.getDua().getFecdeclaracion())) {
					diferenciaTx05 = true;
					datoModificado = "Fecdeclaracion";
				}
			}
			declacionBDXML.getDua().setFecdeclaracion(declaracionBD.getDua().getFecdeclaracion());
			// se rescatara lamodalidad y el codigo de operacion
			if (declacionBDXML.getDua().getCodmodalidad() != null) {
				if (!declacionBDXML.getDua().getCodmodalidad().equals(declaracionBD.getDua().getCodmodalidad())) {
					diferenciaTx05 = true;
					datoModificado = "Codmodalidad";

				}
			}
			declacionBDXML.getDua().setCodmodalidad(declaracionBD.getDua().getCodmodalidad());
			if (declacionBDXML.getDua().getCodtipoperacion() != null) {
				if (!declacionBDXML.getDua().getCodtipoperacion().equals(declaracionBD.getDua().getCodtipoperacion())) {
					diferenciaTx05 = true;
					datoModificado = "Codtipoperacion";
				}
			}
			/***Inicio de cambios para PASE 192 para cargar el flag del proveedor***/
			if(!CollectionUtils.isEmpty(declacionBDXML.getListDAVs())){
				for(DAV lstDav : declacionBDXML.getListDAVs()){
					if (lstDav.getCodproveedor()!=null && StringUtils.isNotEmpty(lstDav.getCodproveedor())) {
						if(lstDav.getFlag()==null || lstDav.getFlag()!=null && lstDav.getFlag().isEmpty())lstDav.setFlag("1");  
					}else{			        	
						OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaService"); 
						Map<String, Object> proveedor = operadorAyudaService.getCatprovee(
								lstDav.getProveedor().getPais().getCodDatacat(),
								lstDav.getProveedor().getNombreRazonSocial());
						if(!CollectionUtils.isEmpty(proveedor)){
							lstDav.setFlag("2");
							lstDav.setCodproveedor(proveedor.get("ccodi_prov").toString());
							lstDav.getProveedor().setNumeroDocumentoIdentidad(proveedor.get("ccodi_prov").toString());
						}else{
							if(lstDav.getFlag()==null || lstDav.getFlag().isEmpty()) lstDav.setFlag("3");                
						}

					}
				}

			}/**Fin de cambios para pase 192**/

			declacionBDXML.getDua().setCodtipoperacion(declaracionBD.getDua().getCodtipoperacion());

			/**Adicionado para regu 05 docs de xml-P_SNADE046-2128***/
			if(!CollectionUtils.isEmpty(declacionBDXML.getDua().getListDocAutorizantes())){ 
				for(DatoDocAutorizante docAutorizante : declacionBDXML.getDua().getListDocAutorizantes()){
					if(SunatStringUtils.isEmptyTrim(docAutorizante.getCodigoAduanaAut())){
						docAutorizante.setCodigoAduanaAut(declacionBDXML.getCodaduana());
					}
				}				
			}
			/**Fin cambios***/

			// actualizacion de documentos de transporte
			// lo registrado txPAS20165E220200148
			boolean declaracionNoTieneDocTransTX = CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte());

			if (declaracionNoTieneDocTransTX) 
				declaracion.getDua().setListDocTransporte( declaracionBD.getDua().getListDocTransporte());

		} else {// Las txs XX04 (anticipada) pueden tx solo los campos del cun17

			// cargamos la declaracion BD

			if (declaracionBD != null) {
				declacionBDXML = declaracionBD;
				declacionBDXML.getDua().getManifiesto().setNummanif(declacionBDXML.getDua().getManifiesto().getNummanif().trim());

				//PAS20165E220200163  
				if (declaracion.getDua().getManifiesto() != null) {
					if (!isEmpty(declaracion.getDua().getManifiesto().getEmpTransporte()) && !isEmpty(declacionBDXML.getDua().getManifiesto().getEmpTransporte())) { //cambio esantana
						declacionBDXML.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(declaracion.getDua().getManifiesto().getEmpTransporte().getNumeroDocumentoIdentidad().trim());//txPAS20165E220200148
					}
				}
				//Fin PAS20165E220200163 

				DatoPago pago = declacionBDXML.getDua().getPago();
				DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;
				String codgarantia = decla != null ? decla.getCodgarantia() : null;
				if (!codgarantia.isEmpty() || codgarantia != null) {

					declacionBDXML.getDua().getPago().getPagoDeclaracion().setCodtipopago("G");
				}
				declacionBDXML.getDua().setCodregimen(numdeclRef.getCodregimen());
				/* seteo al objeto transmitido el numero de correlativo (num_corredoc) pk (dato que no se compara en rectificacion) */
				declacionBDXML.getDua().setNumcorredoc(declaracion.getDua().getNumcorredoc());
				// se setea el valor numcorrelatiovo , para el servicio de calculo de adeudo
				declacionBDXML.setNumeroCorrelativo(declaracion.getDua().getNumcorredoc());
				/* seteo la fecha de declaracion obtenida (dato que no se compara en rectificacion) */
				declacionBDXML.getDua().setFecdeclaracion(declaracion.getDua().getFecdeclaracion());

				// /Grabamos lo tTX como Numero de Documento de referencia rectificaciones
				declacionBDXML.setNumdeclRef(declaracion.getNumdeclRef());
				declacionBDXML.setCodaduana(declaracion.getCodaduana());
				declacionBDXML.setCodregimen(declaracion.getDua().getCodregimen());
				declacionBDXML.getDua().setCodregimen(declaracion.getDua().getCodregimen());
				declacionBDXML.setCodtipotrans(declaracion.getCodtipotrans());
				// La declaracion llega sin varios de los campos en esta parte se le asignan los datos faltantes a la variable
				// declaracion

				// Actualizar Cabecera
				DatoManifiesto manif = declaracion.getDua().getManifiesto();
				Date fecTermino = manif != null ? manif.getFectermino() : null;
				declacionBDXML.getDua().setCnttpesobruto(declaracion.getDua().getCnttpesobruto());
				declacionBDXML.getDua().setCnttpesoneto(declaracion.getDua().getCnttpesoneto());
				declacionBDXML.getDua().getManifiesto().setFectermino(fecTermino);
				declacionBDXML.getDua().setCnttcantbulto(declaracion.getDua().getCnttcantbulto());
				declacionBDXML.getDua().setMtotfobclvta(declaracion.getDua().getMtotfobclvta());
				declacionBDXML.getDua().setMtotsegotros(declaracion.getDua().getMtotsegotros());
				declacionBDXML.getDua().setMtotflecomex(declaracion.getDua().getMtotflecomex());
				declacionBDXML.getDua().setCnttqunifis(declaracion.getDua().getCnttqunifis());
				declacionBDXML.getDua().setCnttqunicom(declaracion.getDua().getCnttqunicom());
				declacionBDXML.getDua().setMtovaladuana(declaracion.getDua().getMtovaladuana());
				// RIN 16 - Parte 2 - Inicio - Seteo de tipo_punto_llegada/ruc_punto_llegada/tipo_lugar_descarga
				declacionBDXML.getDua().setNumruclugarecep(declaracion.getDua().getNumruclugarecep());
				declacionBDXML.getDua().setCodtiplugarrecep( declaracion.getDua().getCodtiplugarrecep());
				declacionBDXML.getDua().setCodlugarecepcion(declaracion.getDua().getCodlugarecepcion());
				declacionBDXML.getDua().setCodanexo(declaracion.getDua().getCodanexo());
				// RIN 16 - Parte 2 - Fin - Seteo de tipo_punto_llegada/ruc_punto_llegada/tipo_lugar_descarga

				/**Inicio de cambios del PAS20155E220200192 seteo de datos desde bd para validacion a nivel nacional**/
				if(declaracion.getDua().getDeclarante()!=null && declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()==null 
						&& declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()==null 
						&& declacionBDXML.getDua().getDeclarante().getNumeroDocumentoIdentidad()!=null){
					declaracion.getDua().setDeclarante(declacionBDXML.getDua().getDeclarante());
				}		
				if(CollectionUtils.isEmpty(declaracion.getDua().getListFacturaRef()) && !CollectionUtils.isEmpty(declacionBDXML.getDua().getListFacturaRef())){
					declaracion.getDua().setListFacturaRef(declacionBDXML.getDua().getListFacturaRef());					
				}
				/***Fin de cambios del PAS20155E220200192***/

				// actualizacion de docuemntos de transporte
				// lo transmitido
				boolean declaracionTieneDocTransTX = !CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte());

				if (declaracionTieneDocTransTX) {

					for (DatoDocTransporte datoDocTransporteTX : declaracion.getDua().getListDocTransporte()) {
						boolean declXMLBDTieneDocsTransporte = !CollectionUtils.isEmpty(declacionBDXML.getDua().getListDocTransporte());
						encontrarDocTrans = false;
						if (declXMLBDTieneDocsTransporte) {
							for (DatoDocTransporte datoDocTransporteXMLBD : declacionBDXML.getDua().getListDocTransporte()) {
								if ((datoDocTransporteXMLBD.getNumdoctransporte().equals(datoDocTransporteTX.getNumdoctransporte()))) {
									// se actualiza los datos del futuro XML mas BD
									datoDocTransporteXMLBD.setCodpuerto(datoDocTransporteTX.getCodpuerto());
									encontrarDocTrans = true;
								}
							}
							if (!encontrarDocTrans) {
								diferenciaDocTransporte = true;
							}
						}
					}

				}
				// Validacion de la cantidad de series enviadas

				boolean declaracionTieneDatoSeriesTX = !CollectionUtils.isEmpty(declaracion.getDua().getListSeries()); // series Tx
				boolean declXMLBDTieneDatoSeries = !CollectionUtils.isEmpty(declacionBDXML.getDua().getListSeries()); // series BD

				if (declaracionTieneDatoSeriesTX && !declXMLBDTieneDatoSeries) { // Si tx series pero no existe series en BD
					diferenciaSeries = true;
				} else if (!declaracionTieneDatoSeriesTX && declXMLBDTieneDatoSeries) {// Si no tx series pero existe series en BD
					diferenciaSeries = true;
					// el metodo validador lo identificara
				} else if (declaracionTieneDatoSeriesTX && declXMLBDTieneDatoSeries) { // Si tx series y hay serie en BD
					// lo Tx es mayor a lo que esta en BD
					if (declaracion.getDua().getListSeries().size() > declacionBDXML.getDua().getListSeries().size()) {
						diferenciaSeries = true;
					}
					// lo Tx es menor a lo que esta en BD
					if (declaracion.getDua().getListSeries().size() < declacionBDXML.getDua().getListSeries().size()) {
						diferenciaSeries = true;
					}
				}

				// actualizacion de series siempre que no exstan diferencias
				declaracionTieneDatoSeriesTX = !CollectionUtils.isEmpty(declaracion.getDua().getListSeries());

				if (declaracionTieneDatoSeriesTX && !diferenciaSeries) {
					declXMLBDTieneDatoSeries = !CollectionUtils.isEmpty(declacionBDXML.getDua().getListSeries());
					for (DatoSerie datoSerieTX : declaracion.getDua().getListSeries()) {
						if (declXMLBDTieneDatoSeries) {

							for (DatoSerie datoSerieBDXML : declacionBDXML.getDua().getListSeries()) {
								if (datoSerieBDXML.getNumserie().equals(datoSerieTX.getNumserie())) { // son iguales los numeros de series
									// que XMLBD y de la BD
									datoSerieBDXML.setCntbultos(datoSerieTX.getCntbultos());
									datoSerieBDXML.setCntpesobruto(datoSerieTX.getCntpesobruto());
									datoSerieBDXML.setCntpesoneto(datoSerieTX.getCntpesoneto());
									datoSerieBDXML.setCntunicomer(datoSerieTX.getCntunicomer());
									datoSerieBDXML.setCntunifis(datoSerieTX.getCntunifis());
									if (datoSerieTX.getCntunicomisc() != null) {//gmontoya Pase 184 2015
										datoSerieBDXML.setCntunicomisc(datoSerieTX.getCntunicomisc());//gmontoya Pase 181 2015
									}//gmontoya Pase 184 2015
									datoSerieBDXML.setMtofobmon(datoSerieTX.getMtofobmon());

									datoSerieBDXML.setMtofobdol(datoSerieTX.getMtofobdol());
									datoSerieBDXML.setMtosegdol(datoSerieTX.getMtosegdol());
									datoSerieBDXML.setMtofledol(datoSerieTX.getMtofledol());

									datoSerieBDXML.setMtovaladuana(datoSerieTX.getMtovaladuana());

									//RIN14-SAU201510002000018
									datoSerieBDXML.setCodunicomer(datoSerieTX.getCodunicomer());

									/**RMC RIN-P47
                                                                        if(datoSerieTX.getPoralcohol()==null){
										datoSerieBDXML.setPoralcohol(datoSerieTX.getPoralcohol());
									}
                                                                        if(datoSerieTX.getCodtipomarge()==null){
										datoSerieBDXML.setCodtipomarge(datoSerieTX.getCodtipomarge());
									}Ambos campos no son modificables por el usuario, se toman de BD**/

									// datoSerieBDXML.setCodtiposeg( datoSerieTX.getCodtiposeg());

									/**Inicio de cambios del PAS20155E220200192
									 * El usuario no puede modificar el TPI, docs de soporte de las series, SPN, o pais origen en trx 1004, 
									 * el sistema valida con los FOB y CIF del usuario que no incumpla los topes CIF de tpi 814
									 * los datos son los mismos de bd**/
									if(datoSerieTX.getCodconvinter()!=null && datoSerieTX.getCodconvinter()==0)
										datoSerieTX.setCodconvinter(datoSerieBDXML.getCodconvinter());//para que lo considere en servicio 3333

									if(CollectionUtils.isEmpty(datoSerieTX.getListSerieDocSoporte()) && !CollectionUtils.isEmpty(datoSerieBDXML.getListSerieDocSoporte()))
										datoSerieTX.setListSerieDocSoporte(datoSerieBDXML.getListSerieDocSoporte());//para que lo considere en servicio 3333

									if(datoSerieTX.getNumpartnandi()==null){
										datoSerieTX.setNumpartnandi(datoSerieBDXML.getNumpartnandi());
									}
									if(datoSerieTX.getCodpaisorige()==null){
										datoSerieTX.setCodpaisorige(datoSerieBDXML.getCodpaisorige());
									}
									/**Fin de cambios del PAS20155E220200192**/

									// cargamos los datos de las DAV que son tx
									// declacionBDXML.setListDAVs(declaracion.getListDAVs());
									// barremos lo que esta en la BD y sobre eso actualizamos con lo que Tx
									for (DAV davBDXML : declacionBDXML.getListDAVs()) {
										for (DatoFactura facturaBDXML : davBDXML.getListFacturas()) {
											for (DatoItem itemBDXML : facturaBDXML.getListItems()) {
												DatoItem DatoItemTx = getItemCorrespondiente(itemBDXML, declaracion);
												if (DatoItemTx != null) {
													itemBDXML.setMtofobitem(DatoItemTx.getMtofobitem());
												//	itemBDXML.setMtofobunita(DatoItemTx.getMtofobunita()); PAS201830001100005 Fob Unitario de la BD, no del Agente
													DatoItemTx.setMtofobunita(itemBDXML.getMtofobunita());
													itemBDXML.setCntcantcomer(DatoItemTx.getCntcantcomer());//PAS20191U220200013
												}
												for (DatoSerieItem serieItemBDXML : itemBDXML.getListSerieItems()) {

													DatoSerieItem DatoSerieItemTx = getSeriesItemCorrespondiente(serieItemBDXML, declaracion);
													if (DatoSerieItemTx.getMtofobitser() != null) {
														serieItemBDXML.setMtofobitser(DatoSerieItemTx.getMtofobitser());
													}
													if (DatoSerieItemTx.getCant_mercd() != null) {
														serieItemBDXML.setCant_mercd(DatoSerieItemTx.getCant_mercd());
													}
												}
											}
										}
									}

								}

							}

						}

					}
				}

			}

			if (!CollectionUtils.isEmpty(declaracion.getDua().getListOtrosDocSoporte())
					&& CollectionUtils.isEmpty(declacionBDXML.getDua().getListOtrosDocSoporte()))
				declacionBDXML.getDua().setListOtrosDocSoporte(new Elementos<DatoOtroDocSoporte>());

			for (DatoOtroDocSoporte doc : declaracion.getDua().getListOtrosDocSoporte()) {
				if (Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS.equals(doc.getCodtipodocasoc()) || Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS.equals(doc.getCodtipodocasoc())//ECC 07032011
						&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())) {
					declacionBDXML.getDua().getListOtrosDocSoporte().add(doc); /*se agrega solo el documento de soporte autoliquidacion tipo LC 0026 y 0027*/
				}
				if (/*Constants.CAT75_12_EXPEDIENTE_EN_TRAMITE.equals(doc.getCodtipodocasoc())//ECC 07032011
						&& */Constants.CAT327_6__EXPEDIENTE_SUSPENSION.equals(doc.getCodtipoproceso())) {
					declacionBDXML.getDua().getListOtrosDocSoporte().add(doc);
				}
				//RIN 6 Parte 2 - Inicio
				if (Constants.CAT327_F_EXPEDIENTE_CASO_FORTUITO.equals(doc.getCodtipoproceso())) {
					declacionBDXML.getDua().getListOtrosDocSoporte().add(doc);
				}
				//RIN 6 Parte 2 - Final
			}

			/***Inicio de cambios por PAS20155E220200192 para validar tope CIF de TPI transmitidos solamente en TRX04***/
			//toma los Certif de Orig de la BD:
			if(!CollectionUtils.isEmpty(declacionBDXML.getDua().getListOtrosDocSoporteCO())
					&& CollectionUtils.isEmpty(declaracion.getDua().getListOtrosDocSoporteCO()))
				declaracion.getDua().setListOtrosDocSoporteCO(declacionBDXML.getDua().getListOtrosDocSoporteCO());

			//toma los datos del certificado de la BD:
			if(declaracion.getDua().getDatoCertificadoOrigen()!=null && CollectionUtils.isEmpty(declaracion.getDua().getDatoCertificadoOrigen().getListAutocertificacion())
					&& declacionBDXML.getDua().getDatoCertificadoOrigen()!=null && !CollectionUtils.isEmpty(declacionBDXML.getDua().getDatoCertificadoOrigen().getListAutocertificacion()))
				declaracion.getDua().setDatoCertificadoOrigen(declacionBDXML.getDua().getDatoCertificadoOrigen());

			//toma datos del manifiesto de la BD:
			if(declaracion.getDua().getManifiesto()!=null && declaracion.getDua().getManifiesto().getCodaduamanif()==null 
					&& declacionBDXML.getDua().getManifiesto()!=null && declacionBDXML.getDua().getManifiesto().getCodaduamanif()!=null){
				declaracion.getDua().getManifiesto().setCodaduamanif(declacionBDXML.getDua().getManifiesto().getCodaduamanif());
				declaracion.getDua().getManifiesto().setAnnmanif(declacionBDXML.getDua().getManifiesto().getAnnmanif());
				declaracion.getDua().getManifiesto().setNummanif(declacionBDXML.getDua().getManifiesto().getNummanif());
			}
			/***Fin de cambios por PAS20155E220200192 para cargar y validar CIF de TPI transmitidos***/

			// -- RIN16 (inicio)
			if (!CollectionUtils.isEmpty(declaracion.getDua().getListIndicadores())){  
				for(DatoIndicadores indicador:declaracion.getDua().getListIndicadores())
				{
					if(indicador.getCodtipoindica()!=null && indicador.getCodtipoindica().equals(Constants.IND_REGULARIZABLE))
					{
						declacionBDXML.getDua().getListIndicadores().add(indicador);
						break;
					}
				}

			}
			// -- RIN16 (fin)

		}


		Date fechVencRegul = new Date();
		DatoManifiesto manif = declaracion.getDua().getManifiesto();
		Date fectermino = manif != null && manif.getFectermino()!=null 
				&& !SunatDateUtils.isDefaultDate(manif.getFectermino())? manif.getFectermino() : SunatDateUtils.getDateFromInteger(20010101);
		
		fechVencRegul = fectermino;
		// RIN16
		Map<String, Object> paramDias = new HashMap<String, Object>();
		Date fecVencRegulNueva=SunatDateUtils.addDay(fechVencRegul,PLAZO_VENCIMIENTO_REGULARIZACION);
		Integer fecVencRegulAsInteger = SunatDateUtils.getIntegerFromDate(fecVencRegulNueva);
		paramDias.put("FECHADESDE", fecVencRegulAsInteger);
		paramDias.put("FECHAHASTA", 0);
		paramDias.put("TIPO", 2);
		paramDias.put("INCLUYE", "S");
		paramDias.put("SUSPENDE", "S");
		DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(declaracion.getCodAduana());
		String fecVencRegul = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias);

		Date fechVencRegulBD =declacionBDXML.getDua().getFecvencregula();
		Date fecVencRegulaDate = DateUtil.stringToDate(fecVencRegul,"yyyyMMdd");
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechVencRegulBD, fecVencRegulaDate,"COMPARA_SOLO_FECHA"))
			fecVencRegulaDate = fechVencRegulBD;

		String fecVencRegula = DateUtil.dateToString(fecVencRegulaDate, "yyyyMMdd");
		declacionBDXML.getDua().setFecvencregula(fecVencRegulaDate);
		declacionBDXML.getDua().setFecregulariza(new Date()); // la fecha actual

		// fin de cargado de datos de la variable declaracion

		// NSR BUG:2760 20101222: A pedido de Cecilia Jauregui se completo ceros a la izquierda hasta 6 digitos para liquidaciones tipo 26
		for (DatoOtroDocSoporte doc : declacionBDXML.getDua().getListOtrosDocSoporte()) {
			if (Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS.equals(doc.getCodtipodocasoc())
					&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())) {
				doc.setNumdocasoc(SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0'));
			}
		}

		//ValCabdua valCabdua = (ValCabdua) fabricaDeServicios.getService("ValCabdua");
		response.putAll(valCabdua.setupDeclaracion(declacionBDXML, numOrden, codUsuario, annEnvio,
				numEnvio, tipoSender, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, codTransaccion));
		Map<String, Object> variablesIngreso = (Map<String, Object>) response.get("variablesIngreso");
		variablesIngreso.put("declaracion", declacionBDXML);
		variablesIngreso.put("declaracionXML", declaracion);
		variablesIngreso.put("diferenciaSeries", diferenciaSeries);
		variablesIngreso.put("fechaConclusionDespa", declacionBDXML.getDua().getFecconclusion());
		variablesIngreso.put("fechaVenConclusion", declacionBDXML.getDua().getFecvenconclu()); 

		variablesIngreso.put("fechVencRegul", fecVencRegula);
		variablesIngreso.put("diferenciaDocTransporte", diferenciaDocTransporte);
		variablesIngreso.put("diferenciaTx05", diferenciaTx05);
		variablesIngreso.put("datoModificado", datoModificado);
		variablesIngreso.put("documentosDeTransporteXml", documentosDeTransporteXml);
		variablesIngreso.put("documentosDeTransporteBD", documentosDeTransporteBD); //jreynoso

		return response;
	}

	/**
	 * Retorna el valor de item correspondiente.
	 * 
	 * @param bditem DatoItem
	 * @param declaracion Declaracion
	 * @return  item correspondiente
	 */
	private DatoItem getItemCorrespondiente(DatoItem bditem, Declaracion declaracion) {
		DatoItem listItem = new DatoItem();
		if (declaracion.getListDAVs()!= null) {
			for (DAV dav : declaracion.getListDAVs()) {
				for (DatoFactura factura : dav.getListFacturas()) {//confirmar si se puede comprar de la factura, su numero de factura
					for (DatoItem item : factura.getListItems()) {
						if (SunatStringUtils.isEqualTo(item.getNumfact(),bditem.getNumfact()) && SunatNumberUtils.isEqual(item.getNumsecitem(),bditem.getNumsecitem())){
							listItem=item;
						}
					}
				}
			}
		}
		return listItem;
	}

	/**
	 * Retorna el valor de series item correspondiente.
	 * 
	 * @param bddatoserieitem DatoSerieItem
	 * @param declaracion Declaracion
	 * @return  series item correspondiente
	 */
	private DatoSerieItem getSeriesItemCorrespondiente(DatoSerieItem bddatoserieitem, Declaracion declaracion) {
		DatoSerieItem SerieItem = new DatoSerieItem();
		if (declaracion.getListDAVs()!= null) {
			for (DAV dav : declaracion.getListDAVs()) {
				for (DatoFactura factura : dav.getListFacturas()) {
					for (DatoItem item : factura.getListItems()) {
						for (DatoSerieItem serieItem : item.getListSerieItems()) {
							if (SunatNumberUtils.isEqual(serieItem.getNumserie(), bddatoserieitem.getNumserie()) && 
									SunatNumberUtils.isEqual(item.getNumsecitem(),bddatoserieitem.getNumsecitem())) {
								SerieItem=serieItem;
							}
						}
					}
				}
			}
		}

		return SerieItem;
	}
	/**
	 * Regla de la ingeniera inversa
	 * En los despachos anticipados regularizables y en los despachos urgentes debe validar que se haya transmitido el Formato B. Exceptuar regimen 70.
	 * 
	 * @param declaracion
	 * @return
	 */	
	@ServicioAnnot(tipo="V",codServicio=2600)
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"codTransaccion","declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2600,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")	
	public Map<String, String> validarDuaEnvieFormatoB(String codTransaccion,Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
		
		Map<String,Object> params=new HashMap<String,Object>();
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		List<DAV> listDav=null;

		// KIB Verificar que envie el formato B en la base de datos sea para anticipados o urgentes
		params.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
		//	 		listDav=RegularizacionServiceImpl.getInstance().getFormBProveedorDAO().findDAVByParams(params);
		listDav=formBProveedorDAO.findDAVByParams(params);

		//if (SunatStringUtils.include(codTransaccion.substring(2),new String[]{"03","05"}) && dua.getCodmodalidad().equals("10") && dua.getCodprodurgente().equals("03") && listIndicadorDua.size()>0 ){
		//// consulta si ha enviado formato B  FORMBPROVEEDOR
		if (listDav.size()==0 && !"70".equals(declaracion.getDua().getCodregimen())){
			//resultadoError=RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("5653", "Sin FormatoB. Envie FormatoB por Envios Complementarios. Transaccion 02" );
			resultadoError =catalogoAyudaService.getError("5653",new String[] {"Sin FormatoB. Envie FormatoB por Envios Complementarios. Transaccion 02"});

		}
		//}


		return resultadoError;
	}
	/**
	 *
	 * Si es antipado (codmodalidad=10) y se verifica que la tabla indicador_dua  por el nume_corredoc verificar que  el campo  cod_indicador sea 02
	 * Que la dua tenga la modalidad urgente (XX05) o anticipada (XX04)
	 * @param declaracion
	 * @return declaracionXML
	 */
	@ServicioAnnot(tipo="V",codServicio=2601)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2601,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")	
	public List<java.util.Map<String, String>> validarTipoModalidad(Declaracion declaracion,Declaracion declaracionBD,String codTransaccion) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA duaXml= declaracion.getDua();
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		List<DatoIndicadores> listIndicadorDua=null;
		boolean encontro =false;
		Map<String,Object> params=new HashMap<String,Object>();

		if ((declaracionBD!=null) ){  
			if (duaXml.getCodmodalidad().equals("10")){

				for(DatoIndicadores indicador:duaXml.getListIndicadores()){
					if ("02".equals(indicador.getCodtipoindica())){
						encontro=true;						
						break;
					}
				}				

				if (!encontro){
					IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
					params.put("numcorredoc", declaracionBD.getDua().getNumcorredoc());
					params.put("indactivo", Constants.INDICADOR_ACTIVO);
					//				listIndicadorDua= RegularizacionServiceImpl.getInstance().getIndicadorDUADAO().findIndicadoresByMap(params);
					listIndicadorDua= indicadorDUADAO.findIndicadoresByMap(params);
					if (listIndicadorDua.size()>0){
						for(DatoIndicadores DatoIndicadorTmp:listIndicadorDua){
							if (DatoIndicadorTmp.getCodtipoindica().equals("02")){
								encontro=true;// si esta marcada para ser regularizable
							}
						}
					}
					if (!encontro){
						//listErr.add(  RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30317","DUA NO REGULARIZABLE"));
						listErr.add(catalogoAyudaService.getError("35183",new String[] {"Declaraci�n no  se registr� como Regularizable"}));
						// Sale del orquestador
						listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
						return listErr;
					}
				}
			}
			if (duaXml.getCodmodalidad().equals("00")){ // cambio agregado 2503010 a solicitud de Betty y Edward
				//listErr.add( RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30317","DUA NO REGULARIZABLE"));
				listErr.add(catalogoAyudaService.getError("30317",new String[] {"DUA NO REGULARIZABLE"}));
				// Sale del orquestador
				listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
				return listErr;
			}
		}

		if (SunatStringUtils.include(codTransaccion.substring(2),new String[]{"05"}) ){ //Si  es tx XX05
			if (!duaXml.getCodmodalidad().equals("01")){// error, debe de ser urgente
				//listErr.add( RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30445","TRANSACCION INCORRECTA"));
				listErr.add(catalogoAyudaService.getError("30445",new String[] {"TRANSACCION INCORRECTA"}));
				// Sale del orquestador
				listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
			}
		}else{// Si es Tx XX04
			if (!duaXml.getCodmodalidad().equals("10")){//error, debe de ser anticipado
				//listErr.add( RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30445","TRANSACCION INCORRECTA"));
				listErr.add(catalogoAyudaService.getError("30445",new String[] {"TRANSACCION INCORRECTA"}));
				// Sale del orquestador
				listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
			}
		}
		/* P14 - 3008 - Inicio - erodriguezb */
		/* CUS: 3008-01.08 - Inicio - erodriguezb */

		if(declaracionBD.getDua()!=null &&  Constants.COD_ESTADO_EN_PROC_DILIG_CONCL.equals(declaracionBD.getDua().getCodEstdua())){
			listErr.add(catalogoAyudaService.getError(Constants.COD_ERROR_EST_EN_PROC_DILIG_CONCUSION,
					new String[] {"No se puede transmitir la regularizaci�n de la declaraci�n, se encuentra en estado En proceso de diligencia de conclusi�n"}));
			listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
		}

		/* CUS: 3008-01.08 - Fin - erodriguezb */
		/* P14 - 3008 - Fin - erodriguezb */

		return listErr;
	}
	/**
	 * Validar que la FEC_AUTLEVANTE  sea mayor que cero osea diferente de 01/01/0001
	 * @param declaracionXML
	 * @return
	 * @throws Exception
	 */	
	@ServicioAnnot(tipo="V",codServicio=2602)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public Map<String, String> validarEstadoLevanteDua(Declaracion declaracion,Declaracion declaracionBD) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		Map<String, Object> duaBD= new HashMap<String, Object>();
		Map<String,Object> params=new HashMap<String,Object>();

		if ((declaracionBD!=null) ){ 
			params.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());


			//duaBD= NumeracionServiceImpl.getInstance().getCabDeclaraDAO().findDuaByNumCorreDoc(params);
			duaBD= ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);

			if (!duaBD.isEmpty() || duaBD!=null){
				// RIN16
				//si la DUA se encuentra legajada, estado 08 �sta se encuentra "anulada" -- validacion temporal hasta salida de Pase de Legajo				
				if (duaBD.get("COD_ESTDUA").toString().equals("08")){
					resultadoError= catalogoAyudaService.getError("35261",new String[] {"DECLARACION SE ENCUENTRA LEGAJADA"});
				}


				if (duaBD.get("FEC_AUTLEVANTE").toString().equals("0001-01-01 00:00:00.0")){

					//resultadoError= RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("00344","NO TIENE REGISTRADO LA AUTORIZACION DE LEVANTE. VERIFIQUE");
					resultadoError= catalogoAyudaService.getError("00344",new String[] {"DECLARACION DEBE CONTAR CON LEVANTE AUTORIZADO"});
				}
			}else{
				//resultadoError= RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("00341","NUMERO DE DUA NO EXISTE EN IMPORTACIONES");
				resultadoError= catalogoAyudaService.getError("00341",new String[] {"NUMERO DE DUA NO EXISTE EN IMPORTACIONES"});
			}

		}
		return resultadoError;
	}	

	/**
	 * Validar documentos transporte.
	 * 
	 * @param variablesIngreso Map<String,Object>
	 * @return el map
	 */
	@ServicioAnnot(tipo="A",codServicio=2604,descServicio="obtiene la fecha de vencimiento de la regularizacion")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2604,numSecEjec=6,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")	
	public Map<String, String>  validarDocumentosTransporte(Map<String, Object> variablesIngreso) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> resultadoError = new HashMap<String, String>();

		Boolean diferenciaDocTransporte = (Boolean)variablesIngreso.get("diferenciaDocTransporte");
		if (diferenciaDocTransporte){
			//	    	 resultadoError=RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("01262");
			resultadoError = catalogoAyudaService.getError("01262");

		}

		return resultadoError;

	}

	/**
	 * Verificar si la dua ya est� regularizada (cuando el campo fec_regulariza de la tabla cab_declara esta lleno)
	 * primer validaci�n y se debe salir del orquestador y enviar la respuesta
	 * @param declaracionXML
	 * @return
	 * @throws Exception
	 */	
	@ServicioAnnot(tipo="V",codServicio=0000)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public List<java.util.Map<String, String>> validarDuaRegularizada(Declaracion declaracion, Declaracion declaracionBD) throws Exception {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		Map<String, Object> duaBD = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<String, Object>();
		Map<String,String> respuesta = new HashMap<String, String>(); 

		if ((declaracionBD != null) ) {
			params.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());

			//duaBD = NumeracionServiceImpl.getInstance().getCabDeclaraDAO().findDuaByNumCorreDoc(params);
			duaBD = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);
			// RIN16
			if (!duaBD.isEmpty() || duaBD != null) {
				//				P34 3008 JMCV INICIO
				// Si esta en Rectificacion de Oficio en Proceso se emitira este error
				RectificacionOficioService	 oficioService  =fabricaDeServicios.getService("diligencia.rectificacionOficio.rectificacionOficioService"); 
				boolean tieneRectificacionOficioEnProceso = oficioService.tieneRectificacionOficioEnProceso(declaracion.getDua().getNumcorredoc().toString());

				if (tieneRectificacionOficioEnProceso){
					listErr.add(getErrorMap("35291", "REGULARIZACION"));
					return listErr;
				}
				//P34 3008 JMCV FIN				
				if (!SunatDateUtils.isDefaultDate((Date)duaBD.get("FEC_REGULARIZA"))) { // esta lleno					
					listErr.add(catalogoAyudaService.getError("31903")); //jreynoso se valida datacalogo
					// Sale del orquestador
					listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso()); //jreynoso
					return listErr;
				}
			} else {
				//				listErr.add(RegularizacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("00341",
				//						"NUMERO DE DUA NO EXISTE EN IMPORTACIONES"));
				listErr.add(catalogoAyudaService.getError("00341",new String[] {"NUMERO DE DUA NO EXISTE EN IMPORTACIONES"}));

				// Sale del orquestador
				listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
				return listErr;
			}
			if (declaracionBD.getDua().getNumcorredoc() != null) {

				params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
				params.put("codTransaccion", "04");
				//				Integer countSolRegularizacion = RectificacionServiceImpl.getInstance().getRelaciondocDAO().countSolRectificacionByParameterMap(
				//						params);
				Integer countSolRegularizacion = ((RelacionDocDAO)fabricaDeServicios.getService("relaciondocDAO")).countSolRectificacionByParameterMap(params);

				params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
				params.put("codTransaccion", "05");
				countSolRegularizacion = countSolRegularizacion	+ ((RelacionDocDAO)fabricaDeServicios.getService("relaciondocDAO")).countSolRectificacionByParameterMap(params);

				if (countSolRegularizacion > 0) {					
					listErr.add(catalogoAyudaService.getError("00333"));//jreynoso se valida con catalogo
					// Sale del orquestador
					listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
					return listErr;
				}
			}
		}

		return listErr;
	}
	// RIN16
	// pruizcr
	// Dua PendientesdeRegularizar
	@ServicioAnnot(tipo = "V", codServicio = 3405)
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion",
	"declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3405, numSecEjec = 423, nomClase = "pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif.ValRegularizacion")
	public List<java.util.Map<String, String>> validarPendienteDeRegularizar(Declaracion declaracion, Declaracion declaracionBD) throws Exception {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		Map<String, Object> duaBD = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<String, Object>();
		Map<String, String> respuesta = new HashMap<String, String>();

		if ((declaracionBD != null)) {
			params.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());

			duaBD = ((CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);

			if (!duaBD.isEmpty() || duaBD != null) {

				if (org.springframework.util.StringUtils.hasText((String) duaBD.get("COD_ESTREGUL"))
						&& !(duaBD.get("COD_ESTREGUL").toString().equals("01") || duaBD.get("COD_ESTREGUL").toString().equals("02")
								|| duaBD.get("COD_ESTREGUL").toString().equals("03"))) { // esta lleno - se adicono por pase PAS20165E220200078 
					//if (!duaBD.get("COD_ESTREGUL").toString().equals("03")) { // PAS20165E220200078
					respuesta.put("codError", "31903");
					respuesta.put("desError","DECLARACION NO SE ENCUENTRA PENDIENTE DE REGULARIZAR");

					listErr.add(respuesta);
					// Sale del orquestador
					listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
					return listErr;
				}
			} else {

				listErr.add(catalogoAyudaService.getError("00341",	new String[] { "NUMERO DE DUA NO EXISTE EN IMPORTACIONES" }));
				listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
				return listErr;
			}
		}

		if (declaracionBD.getDua().getNumcorredoc() != null) {

			// para compara items

			//boolean diferenciaSeries = false;
			// Declaracion declacionBDXML = declaracionBD.getDua();
			// Validacion de la cantidad de series enviadas

			boolean declaracionTieneDatoSeriesTX = !CollectionUtils.isEmpty(declaracion.getDua().getListSeries()); // series Tx
			boolean declXMLBDTieneDatoSeries = !CollectionUtils.isEmpty(declaracionBD.getDua().getListSeries()); // series

			// INCIO RIN 16
			/*			if (declaracionTieneDatoSeriesTX && declXMLBDTieneDatoSeries) { 
				if (declaracion.getDua().getListSeries().size() > declaracionBD.getDua().getListSeries().size()) {
					diferenciaSeries = true;
					respuesta.put("codError", "31905");
					respuesta.put("desError", "EN LA TRANSMISI�N DE LA REGULARIZACI�N NO SE PUEDE ADICIONAR O ELIMINAR SERIE(S)");
					listErr.add(respuesta);
					return listErr;

				}
				// lo Tx es menor a lo que esta en BD
				if (declaracion.getDua().getListSeries().size() < declaracionBD.getDua().getListSeries().size()) {
					diferenciaSeries = true;
					respuesta.put("codError", "31905");
					respuesta.put("desError", "EN LA TRANSMISI�N DE LA REGULARIZACI�N NO SE PUEDE ADICIONAR O ELIMINAR SERIE(S)");
					listErr.add(respuesta);
					return listErr;

				}
			}*/
			// FIN RIN 16	
			// realiza la comparacion de series y item de base de datos con XML
			// de envio
			// actualizacion de series siempre que no exstan diferencias
			declaracionTieneDatoSeriesTX = !CollectionUtils.isEmpty(declaracion.getDua().getListSeries());

			if (declaracionTieneDatoSeriesTX) {// RIN 166	
				declXMLBDTieneDatoSeries = !CollectionUtils.isEmpty(declaracionBD.getDua().getListSeries());
				for (DatoSerie datoSerieTX : declaracion.getDua().getListSeries()) {
					if (declXMLBDTieneDatoSeries) {

						for (DatoSerie datoSerieBDXML : declaracionBD.getDua().getListSeries()) {
							if (datoSerieBDXML.getNumserie().equals(datoSerieTX.getNumserie())) { 
								datoSerieBDXML.setCntbultos(datoSerieTX.getCntbultos());

								String estMercBDXML = datoSerieBDXML.getCodestamerca().toString();
								String estMercTX = datoSerieTX.getCodestamerca().toString();
								/*INICIO-P28 FSW AFMA*/
								//String tpnBD = datoSerieBDXML.getCodtratprefe().toString();
								//String tpnXML = datoSerieTX.getCodtratprefe().toString();

								String tpnBD = datoSerieBDXML.getCodtratprefe().toString().trim();
								String tpnXML = datoSerieTX.getCodtratprefe().toString().trim();
								/*FIN-P28 FSW AFMA*/
								if (!(tpnBD.equals("0") && tpnXML.equals("0"))) {
									if (tpnBD.equals("20")	|| tpnXML.equals("20")) {
										if (!(tpnBD.equals("20") && tpnXML.equals("20"))) {
											respuesta.put("codError", "31904");
											respuesta.put("desError", "NO SE PUEDE INCORPORAR O ELIMINAR EL TPN 20 DURANTE LA REGULARIZACI�N DEL DESPACHO URGENTE");
											listErr.add(respuesta);
											return listErr;
										}
									}

									/*INICIO-P28 FSW AFMA*/
									//if (tpnXML.equals("93") ) {
									//solo es valida que solo se incorpore ya sea que no exista o cambie de TPN al 93
									if (tpnXML.equals("93") && !tpnBD.equals("93")) {
										respuesta.put("codError", "31909");
										respuesta.put("desError", "EN LA REGULARIZACI�N NO SE PUEDE INCORPORAR EL TPN 93");/*P28-PAS20155E410000032-[jlunah] BUG 3760 - se cambia mensaje por uno generico*/
										listErr.add(respuesta);
										return listErr;
									}
									/*FIN-P28 FSW AFMA*/
								}

								if (declaracion.getDua().getCodregimen().equals("10")) {
									if (estMercTX.equals("10")	&& SunatStringUtils.isStringInList(estMercBDXML,"20,21,22,23,24,25,26,27,28")) {
										if (SunatStringUtils.substring(	datoSerieTX.getNumpartnandi().toString(), 0, 1).equals("87")) {
											for (DatoRegPrecedencia reg : datoSerieBDXML.getListRegPrecedencia()) {
												if (!"91".equals(reg.getCodregipre())) {
													if (catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_NUEVA,	datoSerieBDXML.getCodestamerca(),null) != null
															&& (catalogoAyudaService.getDataGrupoCat(CATALOGO_SUBGR_MERC_USADA,	datoSerieTX.getCodestamerca(),null) != null)
															&& SunatStringUtils.isStringInList(datoSerieBDXML.getCodtnan(),	"02,03")) {
														return listErr;
													} else {
														respuesta.put("codError","DEBE MODIFICARSE EL TNAN QUE CORRESPONDA DE ACUERDO AL ESTADO DE LA MERCANC�A SEG�N SPN");
														respuesta.put("codError","31911");
														return listErr;
													}
												}
											}
										} else {
											respuesta.put("codError","NO SE PUEDE CAMBIAR EL ESTADO DE NUEVO A USADO PARA EL GRUPO DE PARTIDAS 87");
											listErr.add(respuesta);
											return listErr;
										}
									}
								}
								// cargamos los datos de las DAV que son tx
								// declacionBDXML.setListDAVs(declaracion.getListDAVs());
								// barremos lo que esta en la BD y sobre eso
								// actualizamos con lo que Tx
								if (declaracion.getDua().getCodmodalidad().equals("01")) {

									//ggranados caso deposito
									if (!CollectionUtils.isEmpty(declaracionBD.getListDAVs()) && !CollectionUtils.isEmpty(declaracion.getListDAVs())) {

										if (declaracionBD.getListDAVs().size() != declaracion.getListDAVs().size()) {
											respuesta.put("codError", "31907");
											respuesta.put("desError", "EN LA TRANSMISI�N DE LA REGULARIZACI�N NO SE PUEDE ADICIONAR O ELIMINAR PROVEEDOR(ES))");
											listErr.add(respuesta);
											return listErr;
										}
										Integer facturasBD = 0, itemsBD = 0;
										for (DAV davBDXML : declaracionBD.getListDAVs()) {
											facturasBD = facturasBD + davBDXML.getListFacturas().size();
											for (DatoFactura facturaBDXML : davBDXML.getListFacturas()) {
												itemsBD = itemsBD + facturaBDXML.getListItems().size();
											}
										}
										Integer facturas = 0, items = 0;
										for (DAV dav : declaracion.getListDAVs()) {
											facturas = facturas + dav.getListFacturas().size();
											for (DatoFactura factura : dav.getListFacturas()) {
												items = items + factura.getListItems().size();
											}
										}
										if (facturasBD.compareTo(facturas) != 0) {
											respuesta.put("codError", "31908");
											respuesta.put("desError", "EN LA TRANSMISI�N DE LA REGULARIZACI�N NO SE PUEDE ADICIONAR O ELIMINAR FACTURA(S))");
											listErr.add(respuesta);
											return listErr;
										}
										if (itemsBD.compareTo(items) != 0) {
											respuesta.put("codError", "31906");
											respuesta.put("desError", "EN LA TRANSMISI�N DE LA REGULARIZACI�N NO SE PUEDE ADICIONAR O ELIMINAR ITEM(S))");
											listErr.add(respuesta);
											return listErr;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return listErr;
	}
	// RIN16 FIN
	/**
	 * Validar si se cambia el monto fob de la serie numerada se debera tmabien cmabiar el monto del seguro.
	 * Sino se cambia el monto del seguro debera de generarse el error
	 * primer validaci�n y se debe salir del orquestador y enviar la respuesta
	 * @param declaracionXML
	 * @return
	 * @throws Exception
	 */	
	@ServicioAnnot(tipo="V",codServicio=0000)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public List<java.util.Map<String, String>> validarCambioFob(Declaracion declaracion,Declaracion declaracionBD) throws Exception{
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();

		boolean declaracionNueTieneDatoSeries=!CollectionUtils.isEmpty(declaracion.getDua().getListSeries());
		boolean declaracionAntTieneDatoSeries=!CollectionUtils.isEmpty(declaracionBD.getDua().getListSeries());

		if(declaracionAntTieneDatoSeries==true && declaracionNueTieneDatoSeries==true){
			for (DatoSerie datoSerieAntigua : declaracionBD.getDua().getListSeries()) {
				for (DatoSerie datoSerieNueva : declaracion.getDua().getListSeries()) {
					if (datoSerieAntigua.getNumserie().equals(datoSerieNueva.getNumserie())){
						if (!"1".equals(datoSerieAntigua.getCodtiposeg())){//solo compara que se cambien ambos montos el del FOB y el del seguro
							//if (!datoSerieAntigua.getMtofobdol().equals(datoSerieNueva.getMtofobdol()) && datoSerieAntigua.getMtosegdol().equals(datoSerieNueva.getMtosegdol())){
							if (!SunatNumberUtils.isEqual(datoSerieAntigua.getMtofobdol(), datoSerieNueva.getMtofobdol()) && SunatNumberUtils.isEqual(datoSerieAntigua.getMtosegdol(),datoSerieNueva.getMtosegdol())){
								// error de validacion por que si se cambia el fob se debe de cambiar el monto del seguro
								//									 listErr.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30374",new Object []{datoSerieAntigua.getMtofobdol(),datoSerieNueva.getMtofobdol(),datoSerieAntigua.getMtosegdol(),datoSerieNueva.getMtosegdol()}));
								//listErr.add(catalogoAyudaService.getError("30374",new String []{String.valueOf(datoSerieAntigua.getMtofobdol()),String.valueOf(datoSerieNueva.getMtofobdol()),String.valueOf(datoSerieAntigua.getMtosegdol()),String.valueOf(datoSerieNueva.getMtosegdol())}));
								listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30737",new String[] {String.valueOf(datoSerieNueva.getMtofobdol()),String.valueOf(datoSerieNueva.getMtosegdol())})); //jreynoso se valida de datacatalogo.
							}
						}else{// Si es tipo de seguro 1, entonces tendra que verificar contra la tabla de porcentajes promedios de seguro.
							// se verifica en el metodo validarMontoSeguro de la clase ValRegularizacion
						}
					}
				}

			}
		}

		return listErr;
	}
	/**
	 * 18/05/2010
	 * Validar para las duas anticipadas tx XX04, que envie el mismo numero de series que ya existen en la base de datos.
	 * @param declaracionXML
	 * @return
	 * @throws Exception
	 */	
	@ServicioAnnot(tipo="V",codServicio=0000)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public List<java.util.Map<String, String>> validarSeriesDuaAnticipada(Map<String, Object> variablesIngreso) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Boolean diferenciaSeries = (Boolean)variablesIngreso.get("diferenciaSeries");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		if (diferenciaSeries){
			//		    	 listErr.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30443"));
			listErr.add(catalogoAyudaService.getError("30443"));
			listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
		}

		return listErr;
	}
	/**
	 * 18/10/2010
	 * Validar para las duas urgentes tx XX05 , que no envien datos que no se puedan actualizar.
	 * @param declaracionXML
	 * @return
	 * @throws Exception
	 */	
	@ServicioAnnot(tipo="V",codServicio=0000)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public List<java.util.Map<String, String>> validarTx05(Map<String, Object> variablesIngreso,String codTransaccion) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Boolean diferenciaTx05 = (Boolean)variablesIngreso.get("diferenciaTx05");
		String datoModificado = (String)variablesIngreso.get("datoModificado");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		if (diferenciaTx05!=null){
			if (diferenciaTx05){
				//		    	 listErr.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30450",new Object[]{codTransaccion,datoModificado}));
				listErr.add(catalogoAyudaService.getError("30450",new String []{codTransaccion,datoModificado}));
				listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
			}

		}
		return listErr;
	}

	/**
	 * 04/06/2010
	 * Para las DUA(s) del r�gimen 20, 21 y 70, el SIGAD rechaza la transmisi�n de la regularizaci�n de existir descargos en la cuenta corriente.  
	 * 
	 * @param declaracion Declaracion
	 * @return el map
	 */	
	@ServicioAnnot(tipo="V",codServicio=0000)
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=2,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA") 
	public  Map<String, String>  validarDescargos(Declaracion declaracion) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> resultadoError = new HashMap<String, String>();
		NumdeclRef numdeclRef = declaracion.getNumdeclRef(); 
		Map<String,Object> params=new HashMap<String,Object>();
		List<Map<String, Object>> listDescargos= new ArrayList<Map<String, Object>>();
		// Para el reg 20 y 21
		params.put("codaduana", numdeclRef.getCodaduana());
		params.put("annpresen", numdeclRef.getAnnprese());
		params.put("numdeclaracion", numdeclRef.getNumcorre());
		// Para el reg 70
		params.put("anoPrese", numdeclRef.getAnnprese().substring(2, 4));
		params.put("codiAduan", numdeclRef.getCodaduana());
		params.put("numeCorre", SunatStringUtils.lpad(numdeclRef.getNumcorre(),6,'0'));
		params.put("notSdel", "S");


		if ("20".equals(numdeclRef.getCodregimen())){
			//listDescargos=RectificacionServiceImpl.getInstance().getRitccDAO().getListaRitcc(params);
			listDescargos=((RitCcDAO)fabricaDeServicios.getService("ritccDAO")).getListaRitcc(params);
		}else if ("21".equals(numdeclRef.getCodregimen())){
			//listDescargos=RectificacionServiceImpl.getInstance().getRatcc3DAO().getListaRatcc3(params);
			listDescargos=((Ratcc3DAO)fabricaDeServicios.getService("ratcc3DAO")).getListaRatcc3(params);
		}else if ("70".equals(numdeclRef.getCodregimen())){
			//List<Depocta>  listDepocta=RectificacionServiceImpl.getInstance().getDepoctaDAO().findByMap(params);
			List<Depocta>  listDepocta=((DepoctaDAO)fabricaDeServicios.getService("depoctaDAO")).findByMap(params);
			if (!listDepocta.isEmpty()){
				//				resultadoError=RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30444");
				resultadoError=catalogoAyudaService.getError("30444");
			}
		}

		if (SunatStringUtils.include(numdeclRef.getCodregimen(), new String[] { "20", "21" })) {
			if (!listDescargos.isEmpty()) {
				// Error
				//				resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30444");
				resultadoError = catalogoAyudaService.getError("30444");
			}else{
				params.put("numdeclaracion",  SunatStringUtils.lpad(numdeclRef.getNumcorre(),6,'0'));
				//listDescargos=RectificacionServiceImpl.getInstance().getCabNacioTempoDAO().getListaCabNacioTempo(params);
				listDescargos=((CabNacioTempoDAO)fabricaDeServicios.getService("cabNacioTempoDAO")).getListaCabNacioTempo(params);
				if (!listDescargos.isEmpty()) 
					//					resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30444");
					resultadoError = catalogoAyudaService.getError("30444");
			}
		}

		return resultadoError;
	}

	/**
	 * Asignar variable regularizacion.
	 * 
	 * @param declaracion Declaracion
	 * @param declaracionBD Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el hash map
	 */// RIN16
	public HashMap<String, Object> asignarVariableRegularizacion(Declaracion declaracion,Declaracion declaracionBD,Map<String,Object> variablesIngreso) throws Exception  {		

		Date fechVencRegul=new Date();
		DatoManifiesto manif=declaracion.getDua().getManifiesto();
		//Date fectermino=manif!=null?manif.getFectermino():null;
		
		Date fectermino = manif != null && manif.getFectermino()!=null 
				&& !SunatDateUtils.isDefaultDate(manif.getFectermino())? manif.getFectermino() : SunatDateUtils.getDateFromInteger(20010101);

				
		fechVencRegul=fectermino;

		Map<String, Object> paramDias = new HashMap<String, Object>();
		Date fecVencRegulNueva=SunatDateUtils.addDay(fechVencRegul,PLAZO_VENCIMIENTO_REGULARIZACION);
		Integer fecVencRegulAsInteger = SunatDateUtils.getIntegerFromDate(fecVencRegulNueva);
		paramDias.put("FECHADESDE", fecVencRegulAsInteger);
		paramDias.put("FECHAHASTA", 0);
		paramDias.put("TIPO", 2);
		paramDias.put("INCLUYE", "S");
		paramDias.put("SUSPENDE", "S");
		DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(declaracion.getCodAduana());		
		String fecVencRegula = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias);

		variablesIngreso.put("fechaConclusionDespa", declaracionBD.getDua().getFecconclusion());
		Date fecVencRegulaDate = DateUtil.stringToDate(fecVencRegula,"yyyyMMdd");
		// inicio PAS201930001100004
		Date fechVencRegulBD =declaracionBD.getDua().getFecvencregula();
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechVencRegulBD, fecVencRegulaDate,"COMPARA_SOLO_FECHA"))
			fecVencRegulaDate = fechVencRegulBD;

		declaracionBD.getDua().setFecvencregula(fecVencRegulaDate);
		// fin PAS201930001100004
		variablesIngreso.put("fechVencRegul",fecVencRegulaDate);
		// RIN16  FIN	
		return new HashMap<String, Object>();

	}
	public ValRectif getValRectif() {
		return valRectif;
	}


	public void setValRectif(ValRectif valRectif) {
		this.valRectif = valRectif;
	}


	/**
	 * Valida puerto embarque.
	 * 
	 * @param declaracion Declaracion
	 * @param codTransaccion String
	 * @return el list
	 */
	public List<Map<String, String>> validaPuertoEmbarque(Declaracion declaracion, String codTransaccion){
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		/*PAS20155E220000501*/
		if(codTransaccion.endsWith("04") || codTransaccion.endsWith("12") ){

			Map<String, Object> dataManif = new HashMap<String, Object>();
			List<Manifiesto> listManifiesto = null;
			// Verificamos que este presente el manifiesto y todos los datos de la PK del manifiesto
			// antes de buscar para evitar fullscans a la BD

			DatoManifiesto manif = declaracion.getDua().getManifiesto();
			String codaduamanif = manif.getCodaduamanif();
			String annmanif = manif.getAnnmanif();
			String nummanif = manif.getNummanif();
			String codmodtransp = manif.getCodmodtransp();

			dataManif.put("numeroManifiesto", SunatStringUtils.lpad(nummanif, 6, ' '));
			dataManif.put("anioManifiesto", SunatStringUtils.length(annmanif) > 3 ? annmanif.substring(0, 4) : null);
			dataManif.put("codigoAduana", codaduamanif);
			dataManif.put("codigoTipoManifiesto", "01");
			dataManif.put("codigoViaTransporte", codmodtransp);

			if (manif != null && manif.getCodaduamanif() != null && manif.getAnnmanif() != null && manif.getNummanif() != null
					&& manif.getCodmodtransp() != null) {

				// buscamos el manifiesto
				//listManifiesto = FormatoAServiceImpl.getInstance().getManifiestoDAO().listByParameterMap(dataManif);
				listManifiesto = ((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).listByParameterMap(dataManif);
				//Si el manifiesto de la BD (CabDeclara) no existe en el cab_manifiesto, no hacemos nada, el servicio de datado
				//se encargara de rechazar indicando que el "manifiesto no existe"
				if(CollectionUtils.isEmpty(listManifiesto)){
					return listErr;
				}
				Manifiesto manifiesto = listManifiesto.get(0);

				for(DatoSerie serie: declaracion.getDua().getListSeries() ){
					DatoDocTransporte docTransporte = GeneralUtils.getDocTransporte(declaracion.getDua(), serie);

					Map<String, Object> params = new HashMap<String, Object>();
					params.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());

					if( SunatNumberUtils.isGreaterThanZero(docTransporte.getNumdetalle()) )
						params.put("numeroDeDetalle", docTransporte.getNumdetalle());

					params.put("numeroManifiesto", manifiesto.getNumeroManifiesto());
					params.put("anioManifiesto", manifiesto.getAnioManifiesto());
					params.put("codigoAduana", manifiesto.getAduana().getCodDatacat());
					params.put("codigoTipoManifiesto", manifiesto.getTipoManifiesto().getCodDatacat());
					params.put("codigoViaTransporte", manifiesto.getViaTransporte().getCodDatacat());
					//params.put("codigoLugarEmision", manifiesto.getL);
					//params.put("fechaEmision", docTransporte.getCodpuerto());
					//params.put("tipoDocumentoTransporte", docTransporte.getCodpuerto());
					params.put("puertoEmbarque", docTransporte.getCodpuerto());

					//List<DocumentoDeTransporte> documentos = FormatoAServiceImpl.getInstance().getDocuTransDAO().listByParameterMap(params);
					List<DocumentoDeTransporte> documentos = ((DocuTransDAO)fabricaDeServicios.getService("manifiesto.gralDocTranporteDAO")).listByParameterMap(params);

					if(CollectionUtils.isEmpty(documentos))
					{
						listErr.add( ResponseMapManager.getErrorResponseMap(Constantes.COD_ERROR_MANIFIESTO_DATADO_11503, "El puerto de embarque enviado "+params.get("puertoEmbarque")+ " no se encuentra asociado al manifiesto de carga ") );
					}
				}

			}

		}
		return listErr;
	}


	public Map<String,String> validarCodigoPorProceso(Declaracion declaracion, Map<String, Object> variablesIngreso) {
		Declaracion declaracionXML = (Declaracion) variablesIngreso.get("declaracionXML");
		if(declaracionXML.getDua().getListOtrosDocSoporte()!=null){ 
			for (DatoOtroDocSoporte doc: declaracionXML.getDua().getListOtrosDocSoporte()){   

				if(Constants.CAT327_6__EXPEDIENTE_SUSPENSION.equals(doc.getCodtipoproceso())
						&& !Constants.CAT75_12_EXPEDIENTE_EN_TRAMITE.equals(doc.getCodtipodocasoc())		
						){
					return ResponseMapManager.getErrorResponseMap("30038", "SI EL TIPO DE PROCESO ES " + doc.getCodtipoproceso() +
							": EXPEDIENTE DE SUSPENSION, EL TIPO DE DOCUMENTO ASOCIADO DEBE SER: " + Constants.CAT75_12_EXPEDIENTE_EN_TRAMITE +
							" ,ESTA TRANSMITIENDO "+ doc.getCodtipodocasoc());
				} else if (Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())
						&& !(Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS.equals(doc.getCodtipodocasoc())
								|| Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS.equals(doc.getCodtipodocasoc()))

						){
					return ResponseMapManager.getErrorResponseMap("30038", "SI EL TIPO DE PROCESO ES " + doc.getCodtipoproceso() +
							": AUTOLIQUIDACION, EL TIPO DE DOCUMENTO ASOCIADO DEBE SER: " + Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS + " � " + Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS +
							" ESTA TRANSMITIENDO "+ doc.getCodtipodocasoc());
				}

			}
		}
		return  new HashMap<String, String>(); 
	}

	/**
	 * Validar expediente.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el map de errores
	 */
	public Map<String,String> validarExpediente(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception {


		List<Expedi> listExpedi = new ArrayList<Expedi>();
		Map<String,Object> params = new HashMap<String,Object>();
		// busqueda solo si esta fuera de plazo .. antes es innecesaria 
		String fech_venc_regul = (String) variablesIngreso.get("fechVencRegul"); 
		Date fecVencRegulaDate = DateUtil.stringToDate(fech_venc_regul,"yyyyMMdd");   
		Date fechaActual = new Date();
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecVencRegulaDate, fechaActual,SunatDateUtils.COMPARA_SOLO_FECHA)) {
			return  new HashMap<String, String>(); 
		}
		//Primero verificamos si esta transmitiendo expediente de Suspension de Plazo
		boolean tieneExpedienteEnXml = false;
		for (DatoOtroDocSoporte doc: declaracion.getDua().getListOtrosDocSoporte()){  
			if(Constants.CAT75_12_EXPEDIENTE_EN_TRAMITE.equals(doc.getCodtipodocasoc()) 
					&& Constants.CAT327_6__EXPEDIENTE_SUSPENSION.equals(doc.getCodtipoproceso())){
				tieneExpedienteEnXml = true;
				if ((SunatStringUtils.isNumeric(doc.getNumdocasoc()))){
					params.put("nroexpedi", doc.getNumdocasoc());
					params.put("anoexpedi", SunatDateUtils.getAnho(doc.getFecdocasoc()));
					break;
				}else {
					params.put("nroexpedi", doc.getNumdocasoc());
					return ResponseMapManager.getErrorResponseMap("30040", "NUMERO DE EXPEDIENTE DE SUSPENSION DE PLAZO INVALIDO: "+params.get("nroexpedi"));
				}
			}
		}
		//Verificamos si se encontr� el expediente
		variablesIngreso.put("tieneExpediente",false);
		if(tieneExpedienteEnXml){
			params.put("codiAdua", declaracion.getNumdeclRef().getCodaduana());
			params.put("procedim", "1606");
			//Buscamos en la BD
			//listExpedi=FormatoAServiceImpl.getInstance().getExpediDAO().findByMap(params);
			listExpedi=((ExpediDAO)fabricaDeServicios.getService("expediDAO")).findByMap(params);
			//Si no esta en la BD mandamos el Error de Expediente no Existe y retornamos
			if (listExpedi.isEmpty()){
				return ResponseMapManager.getErrorResponseMap("30040", "NO EXISTE EXPEDIENTE "+params.get("nroexpedi") + "-" +params.get("anoexpedi" )  + "-" + params.get("codiAdua"));
			}
			//Completamos los datos de la dua para verificar si el expediente encontrado esta asociado a ella
			params.put("oAnno", declaracion.getNumdeclRef().getAnnprese());
			params.put("oNro", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()));
			params.put("tipoRegi", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getCodregimen()));

			params.put("comitNro", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params.put("comitTip", declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());

			//listExpedi=FormatoAServiceImpl.getInstance().getExpediDAO().findByMap(params);
			listExpedi=((ExpediDAO)fabricaDeServicios.getService("expediDAO")).findByMap(params);

			// ???falta agregar el regimen el cual es dinamico, falta la tabla de comparacion de regimenes

			if (listExpedi.isEmpty()){
				return ResponseMapManager.getErrorResponseMap("30040", "EXPEDIENTE "+params.get("nroexpedi") + "-" +
						params.get("anoexpedi" )  + "-" +
						params.get("codiAdua") +
						" NO SE ENCUENTRA ASOCIADO A LA DUA: " +
						params.get("oAnno")+ "-" +
						params.get("oNro") + "-" + 
						params.get("tipoRegi")+ "-" +
						" PARA EL IMPORTADOR: " +	
						params.get("comitTip") + "-" +
						params.get("comitNro")
						);
			}
			//Se encontro el Expediente y esta asociado a esta dua
			variablesIngreso.put("tieneExpediente",true);
			return  new HashMap<String, String>(); 
		}
		return  new HashMap<String, String>(); 
	}


	/**
	 * Valida que los documentos de liquidacion de la DUA:
	 * 1. Se encuentren registrados en la tabla LIQUIDA
	 * 2. Se encuentren relacionados a la DUA
	 * 3. Se encuentren cancelados
	 * 
	 * @param declaracion Declaracion
	 * @return lista de errores
	 */
	public List<Map<String, String>> validaAutoLiquidacion(Declaracion declaracion, Map<String, Object> variablesIngreso) {
		Declaracion declaracionXML = (Declaracion) variablesIngreso.get("declaracionXML");

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

		String codTransaccion = (variablesIngreso.get("codTransaccion")!=null)?variablesIngreso.get("codTransaccion").toString():"";
		if(codTransaccion.endsWith("03"))
			declaracionXML = declaracion;         

		if (!CollectionUtils.isEmpty(declaracionXML.getDua().getListOtrosDocSoporte())){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			boolean encontro = false;

			for (DatoOtroDocSoporte doc : declaracionXML.getDua().getListOtrosDocSoporte()) {
				if (Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS.equals(doc.getCodtipodocasoc())
						&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso()) && codTransaccion.endsWith("03")) {

					listError.add(catalogoAyudaService.getError("32018"));
					encontro = true;
					break;
					/*se agrega solo el documento de soporte autoliquidacion tipo LC 0027*/
				}
			}
			if (encontro)
				return listError;
		}

		String numeroDUA = declaracion.getCodaduana() + "-" + declaracion.getNumeroDeclaracion() + "-" + declaracion.getDua().getAnnpresen();
		/*branch 2011-009 hosorio inicio  16/09/2011*/
		if(declaracion.getNumdeclRef()!=null && !SunatStringUtils.isEmptyTrim(declaracion.getNumdeclRef().getNumcorre())){
			NumdeclRef numdclref=declaracion.getNumdeclRef();
			numeroDUA=numdclref.getCodaduana() + "-" + numdclref.getNumcorre() + "-" + SunatStringUtils.substring(numdclref.getAnnprese(), 0,4) ;
		}
		/*branch 2011-009 hosorio fin  16/09/2011*/

		if(declaracionXML.getDua().getListOtrosDocSoporte()!=null){
			for (DatoOtroDocSoporte doc: declaracionXML.getDua().getListOtrosDocSoporte()){  
				if ( (Constants.CAT75_26_AUTOLIQUIDACIONES_TRIBUTOS.equals(doc.getCodtipodocasoc()) || Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS.equals(doc.getCodtipodocasoc()) ||
						Constants.CAT75_38_AUTOLIQUIDACIONES_PERCEPCION.equals(doc.getCodtipodocasoc()))
						&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())
						) {

					boolean encontro = false;

					String rlano = SunatDateUtils.getAnho( doc.getFecdocasoc()).toString().substring(2, 4);
					String rlnroliq = SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0');
					String numeroLiq = doc.getNumdocasoc() + "-" + declaracion.getNumdeclRef().getCodaduana() + "-" + rlano;
					//String rltipliq = SunatStringUtils.lpad(doc.getCodtipodocasoc(), 4, '0');   Se comenta por PAS20165E220200054
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("rladuana", declaracion.getNumdeclRef().getCodaduana());
					params.put("rlano", rlano);
					params.put("rlnroliq", rlnroliq);
					//params.put("rltipliq", rltipliq); //0026 || 0027 ||038  Se comenta por PAS20165E220200054

					//List<Liquida> res = RectificacionServiceImpl.getInstance().getLiquidaDAO().selectMapSelectivo(params);
					//amancilla fix INC 2016-114615 corrije error de swaper List<Liquida> res = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).selectMapSelectivo(params);

					LiquidaDAO  liquidaDAO= (LiquidaDAO)fabricaDeServicios.getService("recaudacion2.liquidaDefDxdaen");
					DataSourceContextHolder.setKeyDataSource(params.get("rladuana").toString());
					List<Liquida> res = liquidaDAO.selectMapSelectivo(params);

					if (CollectionUtils.isEmpty(res)) {
						listError.add(ResponseMapManager.getErrorResponseMap("01235", "AUTOLIQUIDACION " + numeroLiq + " NO EXISTE"));
					} else {
						for (Liquida liq : res) {
							if (liq.getRlnroliq().equals(SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0'))
									&& liq.getRlano().equals(doc.getAnndocasoc().substring(2, 4))
									&& liq.getRladuana().equals(declaracion.getDua().getCodaduanaorden())
									&& liq.getRlnumaso().equals(SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'))
									&& liq.getRlregimen().equals( declaracion.getDua().getCodregimen() )) {

								//AMANCILLA CORRECCION BUG18346 P32 se agrega tipo cancelacion 7
								if (liq.getRlfeccan() == 0 ) {

									if("7".equals(liq.getRltipcan().toString()) || "76".equals(liq.getRltipcan().toString()) || "56".equals(liq.getRltipcan().toString())){// Se adiciono "76" por PAS20171U220200007 / "56" PAS201830001100011 
										encontro = true;
									}else{
										listError.add(ResponseMapManager.getErrorResponseMap("01235", "AUTOLIQUIDACION " + numeroLiq + " ASOCIADA A LA DUA "
												+ numeroDUA + " NO SE ENCUENTRA CANCELADA"));	
									}
								}
								encontro = true;
							}
						}

						if (!encontro) {
							listError.add(ResponseMapManager.getErrorResponseMap("01235", "AUTOLIQUIDACION " + numeroLiq
									+ " NO SE ENCUENTRA ASOCIADO A LA DUA " + numeroDUA));
						}
					}
				}
			}
		}	 
		return listError;
	}



	/**
	 * Valida documentos de transporte.
	 * 
	 * @param declaracion Declaracion
	 * @param documentosDeTransporteXml List<DatoDocTransporte>
	 * @return el list
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, String>> validaDocumentosDeTransporte(Declaracion declaracion, Map<String, Object> variablesIngreso){
		Boolean encontrarDocTrans = false;
		Boolean diferenciaDocTransporte = false;
		Boolean encontrarEmbarque = false;
		Boolean diferenciaEmbarque = false;
		Boolean encontrarDocuTrans = false;
		Boolean diferenciaDocuTransporte = false;
		Boolean encontrarDocuEmbarque = false;
		Boolean diferenciaDocuEmbarque = false;
		String numeroDUA = declaracion.getCodaduana() + "-" + declaracion.getNumeroDeclaracion() + "-" + declaracion.getDua().getAnnpresen();
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		List<DatoDocTransporte> documentosDeTransporteXml = (List<DatoDocTransporte>) variablesIngreso.get("documentosDeTransporteXml");
		/*Map<String, Object> params = new HashMap<String, Object>();
		params.put("numcorredoc", declaracion.getNumeroCorrelativo());
		for (DatoDocTransporte docTransporte : documentosDeTransporteXml) {
			params.put("numdoctransporte", docTransporte.getNumdoctransporte());
			//List<DatoSerie> series = FormatoBServiceImpl.getInstance().getDetDeclaraDAO().findSerieByMap(params);
			List<DatoSerie> series = ((DetDeclaraDAO)fabricaDeServicios.getService("detDeclaraDAO")).findSerieByMap(params);
			if (CollectionUtils.isEmpty(series)) {
				listErr.add(ResponseMapManager.getErrorResponseMap("08001", "DOCUMENTO DE TRANSPORTE ENVIADO " + docTransporte.getNumdoctransporte()
						+ " NO SE ENCUENTRA REGISTRADO PARA LA DUA " + numeroDUA));
			}*/
		List<DatoDocTransporte> documentosDeTransporteBD = (List<DatoDocTransporte>) variablesIngreso.get("documentosDeTransporteBD");
		boolean declaracionTieneDocTransTX = !CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte());

		if (declaracionTieneDocTransTX) {

			for (DatoDocTransporte datoDocTransporteTX : documentosDeTransporteXml) {
				boolean declXMLBDTieneDocsTransporte = !CollectionUtils.isEmpty(documentosDeTransporteBD);
				encontrarDocTrans = false;
				encontrarEmbarque=false;
				if (declXMLBDTieneDocsTransporte) {
					for (DatoDocTransporte datoDocTransporteXMLBD : documentosDeTransporteBD) {
						if ((datoDocTransporteXMLBD.getNumdoctransporte().equals(datoDocTransporteTX.getNumdoctransporte()))) {
							datoDocTransporteXMLBD.setCodpuerto(datoDocTransporteTX.getCodpuerto());
							encontrarDocTrans = true;
						}
						if ((datoDocTransporteXMLBD.getCodpuerto().equals(datoDocTransporteTX.getCodpuerto()))) {
							encontrarEmbarque = true;
						}
					}
					if (!encontrarDocTrans) {
						diferenciaDocTransporte = true;
					}
					if (!encontrarEmbarque) {
						diferenciaEmbarque = true;
					}
				}
			}

		}
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(diferenciaDocTransporte){
			listErr.add(catalogoAyudaService.getError("01262"));
		}
		if(diferenciaEmbarque){
			listErr.add(catalogoAyudaService.getError("35418"));
		}

		if (declaracion.getDua().getManifiesto() != null) {
			Map<String, Object> paramsMap = new HashMap<String, Object>();
			Map<String, Object> params = new HashMap<String, Object>();
			String annManif = "0";
			if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3)
				annManif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
			paramsMap.put("anioManifiesto", annManif);
			paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 6, ' '));
			paramsMap.put("aduana", declaracion.getDua().getManifiesto().getCodaduamanif());
			paramsMap.put("tipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif());
			paramsMap.put("viaTransporte", declaracion.getDua().getManifiesto().getCodmodtransp());
			List<String> listnumdoc = new ArrayList<String>();
			for (DatoDocTransporte docTransporte : documentosDeTransporteXml) {
				String numdocs=docTransporte.getNumdoctransporte();
				listnumdoc.add(numdocs);
			}
			paramsMap.put("listadocutrans", listnumdoc);

			List<DocumentoDeTransporte> listaDocumentos=  ((DocuTransDAO)fabricaDeServicios.getService("manifiesto.gralDocTranporteDAO")).getByManifDocu(paramsMap);
			if (!CollectionUtils.isEmpty(listaDocumentos)) {


				///*if (declaracionTieneDocTransTX) {

				for (DatoDocTransporte datoDocTransporteTX : documentosDeTransporteXml) {
					boolean declXMLBDTieneDocsTransporte = !CollectionUtils.isEmpty(documentosDeTransporteBD);
					encontrarDocuTrans = false;
					encontrarDocuEmbarque=false;
					if (declXMLBDTieneDocsTransporte) {
						for (DocumentoDeTransporte datoDocTransporteXMLBD : listaDocumentos) {
							if ((datoDocTransporteXMLBD.getNumeroDocumentoTransporte().equals(datoDocTransporteTX.getNumdoctransporte()))) {
								encontrarDocuTrans = true;
							}
							if ((datoDocTransporteXMLBD.getPuertoEmbarque().getCodigo().equals(datoDocTransporteTX.getCodpuerto()))) {
								encontrarDocuEmbarque = true;
							}
						}
						if (!encontrarDocuTrans) {
							diferenciaDocuTransporte = true;
						}
						if (!encontrarDocuEmbarque) {
							diferenciaDocuEmbarque = true;
						}
					}
				}


				if(diferenciaDocuTransporte){
					listErr.add(catalogoAyudaService.getError("35417"));
				}
				if(diferenciaDocuEmbarque){
					listErr.add(catalogoAyudaService.getError("11583"));
				}

				//}


				//				String numcorredoc= (String) manifiestoMap.get("num_corredoc");
				//				
				//				params.put("numcorredoc", numcorredoc);
				//				for (DatoDocTransporte docTransporte : documentosDeTransporteXml) {
				//					String numdocs=docTransporte.getNumdoctransporte();
				//					listnumdoc.add(numdocs);
				//				}
				//				params.put("listnumdoc", listnumdoc);

			}
		}

		return listErr;
	}

	/**
	 * Validacion validarFecLlegaAnticipado.
	 * @param declaracion Declaracion
	 * @return el list
	 */
	public List<Map<String, String>> validarFecLlegaAnticipado(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		

		//boolean esAnticipado = "10".equals(declaracion.getDua().getCodmodalidad()) ? true : false;
		boolean esAnticipado = ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(declaracion.getDua().getCodmodalidad()) ? true : false;

		if(!esAnticipado){
			return listError;
		}

		ManifiestoService manifiestoService =  fabricaDeServicios.getService("manifiesto.manifiestoService");

		DatoManifiesto manifiesto = declaracion.getDua().getManifiesto();
		String manifiestoYear = SunatStringUtils.length(manifiesto.getAnnmanif()) > 3 ? manifiesto.getAnnmanif().substring(0, 4) : null;

		boolean buscarManifiestoSigadActual = false;
		//buscarManifiestoSigadActual = SunatStringUtils.isStringInList(declaracion.getDua().getManifiesto().getCodmodtransp(), "0,4,7");		
		buscarManifiestoSigadActual = SunatStringUtils.isStringInList(declaracion.getDua().getManifiesto().getCodmodtransp(),
				new String[]{ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA, ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO});
				
		
		/*Manifiesto manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
				manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual);*/

		/**PAS20181U220200049 inicio***/
		Manifiesto manifiestoBD = null;
		Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
	 		boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			buscarManifiestoSigadActual = true;//que busque en bdsigad y en sigad
			manifiestoBD = manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
					manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual, fechaReferencia,evaluarEER);			
	 	}else{/**PAS20181U220200049 fin***/
	 		manifiestoBD =  manifiestoService.findManifiestoByClaveDeNegocio(manifiesto.getCodtipomanif(), manifiesto.getCodmodtransp(), 
				manifiesto.getCodaduamanif(), SunatNumberUtils.toInteger(manifiestoYear), manifiesto.getNummanif(),buscarManifiestoSigadActual);
	 	}
		

		if(manifiestoBD == null){
			return listError;
		}

		boolean esFecEfectiva = true;		
		Date fechaLlegada = null;
		if (manifiestoBD != null && (manifiestoBD.getFechaProgramadaLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaProgramadaLlegada())
				|| manifiestoBD.getFechaEfectivaDeLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaEfectivaDeLlegada()))) {
			if (manifiestoBD.getFechaEfectivaDeLlegada() != null && !SunatDateUtils.isDefaultDate(manifiestoBD.getFechaEfectivaDeLlegada())) {
				fechaLlegada = manifiestoBD.getFechaEfectivaDeLlegada();
			} else {
				esFecEfectiva = false; 						
				fechaLlegada = manifiestoBD.getFechaProgramadaLlegada();
			}
		}

		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");
		boolean correspondeModalidadAnticipada = valModalidadService.correspondeModalidadAnticipada(declaracion.getDua().getFecdeclaracion(), fechaLlegada);
		if(!correspondeModalidadAnticipada && esFecEfectiva){
			DataCatalogo catPlazoModalidadAnticipadaCasoFortuito = ((CatalogoAyudaService) fabricaDeServicios
					.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
							ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
							ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_ANTICIPADA_CASO_FORTUITO, declaracion.getDua().getFecdeclaracion());

			Integer plazoModalidadAnticipadaCasoFortuito = SunatNumberUtils.toInteger(catPlazoModalidadAnticipadaCasoFortuito.getDesCorta());
			Date fecMaxPlazoCasoFortuito = SunatDateUtils.addDay(declaracion.getDua().getFecdeclaracion(), plazoModalidadAnticipadaCasoFortuito);
			if (SunatDateUtils.esFecha1MayorQueFecha2(fechaLlegada, fecMaxPlazoCasoFortuito, SunatDateUtils.COMPARA_SOLO_FECHA)){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30733"));	
			} else {					        
				ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
				String  regimenDeclaracion= declaracion.getNumdeclRef().getCodregimen();
				Map<String,Object> params= new HashMap<String, Object>();				

				if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "17");
				} else if (ConstantesDataCatalogo.REG_ADM_TEMP_RME.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "32");
				} else if(ConstantesDataCatalogo.REG_ADM_TEMP_PA.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "7");
				} else if(ConstantesDataCatalogo.REG_DEPOSITO.equals(regimenDeclaracion)){
					params.put("COD_REGIMEN", "40");
				}

				params.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
				params.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
				params.put("NUM_DECLARACION",SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()) );
				params.put("procedim", "3126");
				params.put("codi_aduan", declaracion.getNumdeclRef().getCodaduana());		    		
				List<Map<String,Object>> expedientes = expedienteService.findExpedientesAsociadoDeclaracion(params);
				if (CollectionUtils.isEmpty(expedientes)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35271"));
				} else {
					for (int i = 0; i < expedientes.size(); i++) {						
						BigDecimal tipoconc = new BigDecimal(5);
						params.put("tipoConc", tipoconc);
						List<Map<String,Object>> expedienteProcedente = expedienteService.findExpedientesAsociadoDeclaracion(params);
						if (!CollectionUtils.isEmpty(expedienteProcedente)) {
							return listError;
						}
					}
				}		

				if (!CollectionUtils.isEmpty(expedientes)) {
					Map<String,Object> exp = expedientes.get(0);
					String aduanaExpediente=exp.get("CODI_ADUA")!=null?exp.get("CODI_ADUA").toString():null;
					String areaExpediente=exp.get("OFIC_REC")!=null?exp.get("OFIC_REC").toString():null;
					String anioExpediente=exp.get("ANOEXPEDI")!=null?exp.get("ANOEXPEDI").toString():null;
					String numeroExpediente=exp.get("NROEXPEDI")!=null?exp.get("NROEXPEDI").toString():null;
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35272", new String[] {aduanaExpediente, areaExpediente, anioExpediente, numeroExpediente})); 
				}			
			}
		}
		return listError;
	}

	/**
	 * Validacion validarPlazoRegularizacion.
	 * 
	 * @param declaracion Declaracion
	 * @param documentosDeTransporteXml List<DatoDocTransporte>
	 * @return el list
	 * @throws ParseException 
	 */
	public List<Map<String, String>> validarPlazoRegularizacion(Declaracion declaracion, Map<String, Object> variablesIngreso) throws Exception{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		Date fech_trans_regul = SunatDateUtils.getCurrentDate();
		String fech_venc_regul = (String) variablesIngreso.get("fechVencRegul"); 
		Date fecVencRegulaDate = DateUtil.stringToDate(fech_venc_regul,"yyyyMMdd");        
		Boolean existe_liqui_0027 = false;
		Boolean existe_liqui_0003 = false;
		String exp_conclu = ""; 
		Integer exp_fecha = 0;
		//inicio gmontoya Pase 70 2015
		Calendar fechaInicio = Calendar.getInstance();
		fechaInicio.set(2015, 5, 30);
		Calendar fechaFin = Calendar.getInstance();
		fechaFin.set(2015, 9, 30);
		if(SunatDateUtils.esFecha1MenorQueFecha2(fecVencRegulaDate,fechaInicio.getTime(),"COMPARA_SOLO_FECHA") || 
				SunatDateUtils.esFecha1MayorQueFecha2(fecVencRegulaDate,fechaFin.getTime(),"COMPARA_SOLO_FECHA")){
			//fin gmontoya Pase 70 2015
			if(SunatDateUtils.esFecha1MayorQueFecha2(fech_trans_regul, fecVencRegulaDate,"COMPARA_SOLO_FECHA")){
				for (DatoOtroDocSoporte doc : declaracion.getDua().getListOtrosDocSoporte()) {
					if ( (Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS.equals(doc.getCodtipodocasoc()))
							&& Constants.CAT327_9_DOCUMENTO_AUTOLIQUIDACION.equals(doc.getCodtipoproceso())
							) {
						String rlano = SunatDateUtils.getAnho( doc.getFecdocasoc()).toString().substring(2, 4);
						String rlnroliq = SunatStringUtils.lpad(doc.getNumdocasoc(), 6, '0');
						String rltipliq = "00".concat(Constants.CAT75_27_AUTOLIQUIDACIONES_MULTAS);// "0027";
						Map<String, Object> paramsLiq = new HashMap<String, Object>();
						paramsLiq.put("rladuana", declaracion.getNumdeclRef().getCodaduana());
						paramsLiq.put("rlano", rlano);
						paramsLiq.put("rlnroliq", rlnroliq);
						paramsLiq.put("rltipliq", rltipliq);
						List<Liquida> res = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).selectMapSelectivo(paramsLiq);
						if(!CollectionUtils.isEmpty(res)){
							for (Liquida liq : res) {
								if (liq.getRlfeccan() != 0 && liq.getRladuana().equals(declaracion.getDua().getCodaduanaorden())
										&& liq.getRlnumaso().equals(SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'))
										&& liq.getRlregimen().equals( declaracion.getDua().getCodregimen() )) {					
									existe_liqui_0027 = true;
								}
							}		
						}
						//PAS20171U220200007 - Inicio
						if(!existe_liqui_0027){//solo si no se hallo liquidacion tipo 0027
							rltipliq = "00".concat(Constants.CAT75_03_AUTOLIQUIDACIONES_MULTAS);// "0003";
							paramsLiq.put("rltipliq", rltipliq);
							res = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).selectMapSelectivo(paramsLiq);
							if(!CollectionUtils.isEmpty(res)){
								for (Liquida liq : res) {
									if("76".equals(liq.getRltipcan().toString()) || "56".equals(liq.getRltipcan().toString())){//76 es fraes o 56 fraccionamiento PAS201830001100011
										if (liq.getRladuana().equals(declaracion.getDua().getCodaduanaorden())
												&& liq.getRlnumaso().equals(SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'))
												&& liq.getRlregimen().equals( declaracion.getDua().getCodregimen() )) {					
											existe_liqui_0003 = true;
										}			    				
									}
									else{
										if (liq.getRlfeccan() != 0 && liq.getRladuana().equals(declaracion.getDua().getCodaduanaorden())
												&& liq.getRlnumaso().equals(SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'))
												&& liq.getRlregimen().equals( declaracion.getDua().getCodregimen() )) {					
											existe_liqui_0003 = true;
										}			    				
									}
								}		
							}		    		
						}
						//PAS20171U220200007 - Fin
					}
				} 	
				if(!(existe_liqui_0027 || existe_liqui_0003)){ //PAS20171U220200007
					List<Expedi> listaExpedientes = new ArrayList<Expedi>();
					Map<String,Object> params = new HashMap<String,Object>();
					params.put("nroexpedi", "");
					params.put("anoexpedi", "");
					for (DatoOtroDocSoporte doc: declaracion.getDua().getListOtrosDocSoporte()){  
						if(Constants.CAT75_12_EXPEDIENTE_EN_TRAMITE.equals(doc.getCodtipodocasoc()) 
								&& Constants.CAT327_6__EXPEDIENTE_SUSPENSION.equals(doc.getCodtipoproceso())){
							if ((SunatStringUtils.isNumeric(doc.getNumdocasoc()))){
								params.put("nroexpedi", doc.getNumdocasoc());
								params.put("anoexpedi", SunatDateUtils.getAnho(doc.getFecdocasoc()));	    				 				
							}
						} 
						params.put("codiAdua", declaracion.getNumdeclRef().getCodaduana());
						params.put("oAnno", declaracion.getNumdeclRef().getAnnprese());
						params.put("oNro", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getNumcorre()));
						params.put("tipoRegi", SunatNumberUtils.toInteger(declaracion.getNumdeclRef().getCodregimen()));
						params.put("comitNro", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
						params.put("comitTip", declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
						listaExpedientes = ((ExpediDAO)fabricaDeServicios.getService("expediDAO")).findByMap(params);
						if (!listaExpedientes.isEmpty()){
							break;
						}
					}
					if (listaExpedientes.isEmpty()){
						listErr.add(catalogoAyudaService.getError("31918"));
					}
					else{
						Boolean ExisteExpe1606 = false;
						for (Expedi expe : listaExpedientes) {
							if(expe.getProcedim().trim().equalsIgnoreCase(ConstantesTramite.PROCEDIM_SUSPENCION_PLAZO_DESPACHO)){//1606
								exp_conclu = expe.getTipoConc().toString();
								exp_fecha = expe.getFecexp();
								ExisteExpe1606 = true;
							}
						}
						if(ExisteExpe1606){
							//Se comenta validacion por PAS20165E220200069
							/*
	    				if(SunatDateUtils.esFecha1MayorQueFecha2(SunatDateUtils.getDateFromInteger(exp_fecha),fecVencRegulaDate,"COMPARA_SOLO_FECHA")){
	    					listErr.add(catalogoAyudaService.getError("31921"));
	    				}
							 */
							//else if(exp_conclu.trim().equalsIgnoreCase("0")){ //Sin concluir - PAS20165E220200069
							if(exp_conclu.trim().equalsIgnoreCase("0")){ //Sin concluir	
								listErr.add(catalogoAyudaService.getError("31919"));
							}
							else if(!exp_conclu.trim().equalsIgnoreCase("5")){ //Otro tipo de conclusion
								listErr.add(catalogoAyudaService.getError("31920"));
							}
						}
						else{
							listErr.add(catalogoAyudaService.getError("31922"));
						}
					}
				}
			}
		}
		return listErr;
	}

	/**
	 * Validacion validarSolicitudLegajo.
	 * @param declaracion Declaracion
	 * @return listError
	 */
	public List<Map<String, String>> validarSolicitudLegajo(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();

		String anioDeclaracion = declaracion.getDua().getAnnpresen().toString();
		String codAduana = declaracion.getDua().getCodaduanaorden();
		String numDeclaracion = declaracion.getNumdeclRef().getNumcorre();
		String codigoRegimen = declaracion.getDua().getCodregimen();

		SoliAnulacionService soliAnulacionService = fabricaDeServicios.getService("despaduanero2.soliAnulacionService");

		String estadoSolicitud = soliAnulacionService.verificaSoliAnulacionConEstadoOtros(codAduana, numDeclaracion, codigoRegimen, anioDeclaracion);

		if (estadoSolicitud != null) {
			//			listErr.add("", "La declaraci�n cuenta con una solicitud de legajo en estado " + estadoSolicitud + ".");			
			listErr.add(catalogoAyudaService.getError("31923", (new String[]{estadoSolicitud})));
			listErr.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
		}

		return listErr;
	}

	/**
	 * Validacion validarMtoValorAduana.
	 * @param declaracion Declaracion
	 * @return listError
	 */
	public List<Map<String, String>> validarMtoValorAduana(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<java.util.Map<String, String>> listErr = new ArrayList<Map<String,String>>();

		BigDecimal Mtovaladuana = declaracion.getDua().getMtovaladuana();		
		BigDecimal Mtotfobclvta = declaracion.getDua().getMtotfobclvta();
		BigDecimal Mtotflecomex = declaracion.getDua().getMtotflecomex();
		BigDecimal Mtotsegotros = declaracion.getDua().getMtotsegotros();
		BigDecimal Mtotajustes = declaracion.getDua().getMtotajustes();    

		if (Mtovaladuana==null || SunatNumberUtils.isLessOrEqualsThanZero(Mtovaladuana)){
			listErr.add(catalogoAyudaService.getError("30050"));
			return listErr;
		}
		BigDecimal dif=SunatNumberUtils.diference(Mtovaladuana,SunatNumberUtils.sum(Mtotajustes, SunatNumberUtils.sum(Mtotsegotros,SunatNumberUtils.sum(Mtotfobclvta, Mtotflecomex))));
		if (dif!=null && Math.abs(dif.doubleValue())>0.02)
			listErr.add(catalogoAyudaService.getError("30050"));

		return listErr;
	}
	
	//Pase PAS20171U220200031
	@ServicioAnnot(tipo="V",codServicio=3465, descServicio="valida solicitud de Continuacion")
    @ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
    @OrquestaDespaAnnot(codServInstancia=3465,numSecEjec=575,nomClase="pe.gob.sunat.despaduanero2.service.SolicitudContinuacionTramiteServiceImpl")
    public Map<String,String> validarSolicitudDeContinuacion(Declaracion declaracion){ //Como servicio 3465
          Map<String, String> resultadoError = new HashMap<String, String>();
          String numCorredocDam = declaracion.getNumeroCorrelativo().toString();
          SolicitudContinuacionTramiteService solicitudContinuacionTramiteService = fabricaDeServicios.getService("despaduanero2.solicitudContinuacionTramiteService");
          if(solicitudContinuacionTramiteService.tieneSolicitudContinuacionEnProceso(numCorredocDam)){
                 CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");  
                 resultadoError = catalogoAyudaService.getError("37078");
          }            
          return resultadoError;
    }

	//PAS20191U220200019
	public List<Map<String, String>> valCantComercialPorAumentoPesoNeto(Declaracion declaracion, Declaracion declaracionBD) {
		List<java.util.Map<String, String>> listError = new ArrayList<Map<String,String>>();
		DUA dua=declaracion.getDua();
		List<DatoSerie> lstSeriesBD = declaracionBD.getDua().getListSeries();
		for (DatoSerie serie : dua.getListSeries()){
			DatoSerie serieBD = esSerie(lstSeriesBD, serie.getNumserie());
			if(esUnidadPesoVolumen(serie.getCodunifis()) && esUnidadPesoVolumen(serie.getCodunicomer())) { //Si unidad de medidaFisica es Peso o volumen y la unidadComercial es Peso
				if(serie.getCntpesoneto().compareTo(serieBD.getCntpesoneto()) > 0) { //Si PesoNeto es Mayor al de la BD
					if(serie.getCntunicomer().compareTo(serieBD.getCntunicomer()) <= 0) { //Si (CantidadComercial es menor o igual a BD)
		                 CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		                 listError.add(catalogoAyudaService.getError("13221",new String []{serie.getNumserie().toString(),serieBD.getCntpesoneto().toString(),serie.getCntpesoneto().toString(),serie.getCntunicomer().toString(), serie.getCodunicomer()}));
					}
				}
			}
		}
		return listError;
	}

	private DatoSerie esSerie(List<DatoSerie> lstSeriesBD, int numSerie) {
		DatoSerie datoSerie = new DatoSerie();
		for (DatoSerie serie : lstSeriesBD){
			if(serie.getNumserie() == numSerie) {
				datoSerie = serie;
				break;
			}
		}
		return datoSerie;
	}

	private boolean esUnidadPesoVolumen (String codigoUnidad){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_PESOS_VOLUMEN, codigoUnidad) != null)
			return true;
		else
			return false;
	}

	/**
	 * Checks if is empty.
	 * 
	 * @param participante Participante
	 * @return true, if is empty
	 */
	private boolean isEmpty(Participante participante) {
		if (participante != null) {
			if (SunatStringUtils.isEmptyTrim(participante.getNumeroDocumentoIdentidad()))
				return true;
		} else
			return true;
		return false;
	}
	/*
    public ValCabdua getValCabdua() {
		return valCabdua;
	}

	public void setValCabdua(ValCabdua valCabdua) {
		this.valCabdua = valCabdua;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	 
	public FormBProveedorDAO getFormBProveedorDAO() {
		return formBProveedorDAO;
	}

	public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
		this.formBProveedorDAO = formBProveedorDAO;
	}*/

}
