package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMemoria;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


public class ValidadorComputoMemoria2 extends ValidadorComputoAbstract
{
  private final static String MEMORIA_RAM = "RAM";
	
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua)throws Exception
  {

	  List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item =  obtenerItem(objeto, dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarTipoMemoriaRAM(objeto));
          lstErrores.addAll(validarModuloMemoria(objeto));
      }

	    
	    return lstErrores;
  }


  public List<ErrorDescrMinima> validarTipoMemoriaRAM(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  ComputoMemoria memoria = (ComputoMemoria) object;
	  String tipoMemoria =  memoria.getTipoMemoria().getValtipdescri();
	  if(SunatStringUtils.isEqualTo(tipoMemoria, MEMORIA_RAM)){
		  String datoAValidar =  memoria.getTipoMemoriaRAM().getValtipdescri();
		  if(SunatStringUtils.isEmptyTrim(datoAValidar)){
			  lst.add(obtenerError("31476",memoria.getTipoMemoria()));
		  }
	  }
	  
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarVelocidadBus(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCapacidadMemoria(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  

  //R832: variacion no se transmite la casilla
  public List<ErrorDescrMinima> validarModuloMemoria(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
}
