package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.fob;

import java.math.BigDecimal;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;

public class ValFobEERServiceImpl extends IngresoAbstractServiceImpl implements ValFobEERService {
	
	protected final Log logFobEER = LogFactory.getLog(getClass());
	
	//private ValPrecedenteEERServiceImpl valPrecedenteEER;
	
	public List<Map<String,String>> valMontoFobCategoria02(DUA dua, String codCategoria) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		BigDecimal totalFob = dua.getMtotfobclvta();
		BigDecimal dolares200 = new BigDecimal("200.00");
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_02.equals(codCategoria)) {
			if (!(totalFob.compareTo(BigDecimal.ZERO) > 0 && (totalFob.compareTo(dolares200) == 0 || totalFob.compareTo(dolares200) < 0))) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70112"));
			}
		}
		/*
	      obtener fot total de la declaracion fob = DUA.getMtotfobclvta().
	      si la categoria es '02' (cod_catalogo 558)
	      validar que el fob sea mayo de 0 y menor o igual a 200 dolares, caso contrario emitir el mensaje E24
	   */
		return listError;
	}
	
	public List<Map<String,String>> valMontoFobCategoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			DatoSerie serie = declaracion.getDua().getListSeries().get(0);
			
			if(serie.getListRegPrecedencia().isEmpty()){
				return listError;
			}
			
			Boolean esReimportacionEER = false;
			if(tipoRegimenPrecendeteSeries != null && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenPrecendeteSeries))
				esReimportacionEER = true;
			
			if (esReimportacionEER) {
				BigDecimal fob = declaracion.getDua().getMtotfobclvta();
				BigDecimal fob5000 = new BigDecimal("5000.00");
	
				if (fob.compareTo(fob5000) > 0) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70113"));
				}
			}
		}
		/* RN1946
	      si codCategoria es igual a "03"
	         obtenemos la primera serie = declaracion.getDUA().getListSeries().get(0)
	         de la serie obtenemos la primera precedencia, para EER la serie solo tiene una precedencia
	         precedencia = serie.getListRegPrecedencia().get(0)
	         
	         validamos que la precedencia exista y corresponde a una reimportacion, los parametros para el siguiente metodo se obtiene de la precedencia
	         Si pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteEERServiceImpl.esReimportacion(codRegimen,codiAduan,anoPrese,numeCorre,numeSerie) es verdadero
	            Si el valor fov declaracion.getDUA().getMtotfobclvta() es > 5000 dolares
	               se emite el mensaje E29
	         
	   */
	   return listError;
	}
}
