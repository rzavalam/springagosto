package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import pe.gob.sunat.despaduanero2.ayudas.model.Nandina;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DescrPosicion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoValidacionDescrMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDescMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorFactory;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.exception.DescrMinimaException;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescrPosicionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
//pase548 - inicio
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.descrminima.service.DescrMinimaService;
import org.springframework.util.CollectionUtils;
//pase548 - fin

//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;


/**
 * La Class ValidadorSEIDADescrMinimaServiceImpl.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorSEIDADescrMinimaServiceImpl extends IngresoAbstractServiceImpl implements ValidadorSEIDADescrMinimaService
{

	//private TipoDeDescrMinimaService        tipoDeDescrMinima;
	//private TransformadorDescrMinimaService transformador;
	//private CatalogoHelperImpl              catalogoHelper;
	//private FabricaDeServicios              fabricaDeServicios;
	//private ValidadorFactory              validadorFactory;


	protected final Log log = LogFactory.getLog(getClass());

	public static final String CATALOGO_FECHA_VIGENCIA   = "507";//Adicionado por PAS20155E220000469 arey

	/**
	 * {@inheritDoc}
	 *
	 * @throws Exception
	 **/
	@Override
	public List<Map<String, String>> validarDescripcionMinima(DatoItem item, Declaracion dua) throws Exception
	{
		TipoDeDescrMinimaService tipoDeDescrMinima = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");
		List<Map<String, String>> lstErroresSEIDA = new ArrayList<Map<String, String>>();
		TipoValidacionDescrMin tipoValidacion = null;
		Enum<?> tipoDescrMinima = null;

		actualizarNumerosSecuencia(item, dua);  

		try {
			tipoDescrMinima = tipoDeDescrMinima.obtenerTipoDeDescrMinima(item);

			if (tipoDescrMinima != null)
			{
				tipoValidacion = tipoDeDescrMinima.determinarTipoValidacionAplicar(item);
				switch (tipoValidacion)
				{
				case NEW_VALIDACIONES:
					lstErroresSEIDA = ejecutarNewValidaciones(tipoDescrMinima, item, dua);
					break;
				case OLD_VALIDACIONES:
					lstErroresSEIDA = ejecutarOLDValidaciones(item, dua);
					break;
				case ERROR_ESTRUCTURA_DEVIO_ENVIAR_NEW_ESTRUCTTURA:

					lstErroresSEIDA.add(generarError("30779",
							new String[] { TipoDeDescrMinimaService.CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA , item.getNumsecitem().toString()}));
					break;
				case ERROR_ESTRUCTURA_DEVIO_ENVIAR_OLD_ESTRUCTTURA:
					lstErroresSEIDA.add(generarError("30779",
							new String[] { TipoDeDescrMinimaService.CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA , item.getNumsecitem().toString()}));
					break;
				default:
					break;
				}
			}
			else
			{   //sea o no se descr minima se envia para su ejecucion igual que antes de los cambios
				// amancilla si no es descr minima se comenta ya no debe ejecutar las antiguas validaciones coordinado con wilmer ramirez
				//se ha verificado que esta data complerta informacion del cod_mercacia por tanto debe ejecutarse de todas maneras Bug 22240
				lstErroresSEIDA = ejecutarOLDValidaciones(item, dua);
			}
		}
		catch (DescrMinimaException ex)
		{
			 String parametrosEnviar[] = ex.getError().getParametros()!=null? new String[ex.getError().getParametros().length]:null;
			 if(ex.getError().getParametros()!=null){
				 for (int i=0;i<ex.getError().getParametros().length;i++) 
				 {
					 parametrosEnviar[i]=ex.getError().getParametros()[i].toString();
				 }
			 }
			//lstErroresSEIDA.add(generarError(ex.getError().getCodigo(), new String[]{SunatStringUtils.toStringObj(ex.getError().getParametros())}));
			lstErroresSEIDA.add(generarError(ex.getError().getCodigo(), parametrosEnviar));//sin este arreglo no pintaba los parametros
			 
		}

		return lstErroresSEIDA;

	}

	private List<Map<String, String>> ejecutarNewValidaciones(Enum<?> tipoDescrMinima,
			DatoItem item,
			Declaracion dua) throws Exception{
		TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
		ValidadorFactory validadorFactory = fabricaDeServicios.getService("ValidadorFactory");
		ModelAbstract objetoConDatos = transformador.poblarObjetoDescrMinima(tipoDescrMinima, item, dua);
		ValidadorAbstract validador = validadorFactory.crearValidadorDescrMinima(objetoConDatos);
		List<ErrorDescrMinima> lstErroresDescrMinima = validador.ejecutarValidaciones(objetoConDatos, dua);
		return validador.convertirErrores(lstErroresDescrMinima);
	}

	//rtineo mejoras, sobrecargamos el metodo
	private List<Map<String, String>> ejecutarOLDValidaciones(DatoItem item, Declaracion dua){
		return ejecutarOLDValidaciones(item, dua,null);
	}

	private List<Map<String, String>> ejecutarOLDValidaciones(DatoItem item, Declaracion dua,Map<String, Object> variablesIngreso)
	{

		List<Map<String, String>> lstErroresSEIDA = new ArrayList<Map<String, String>>();

		ValDescMin validadorDescrMin = fabricaDeServicios.getService("ValDescMin");

		for (DatoDescrMinima descrMinima : item.getListDecrMinima())
		{
			//rtineo mejoras, se ejecuta metodo con variablesIngreso
			if(variablesIngreso != null){
				lstErroresSEIDA.add(validadorDescrMin.codtipdescri(descrMinima,variablesIngreso));
			}else{
				//continua ejecutando el metodo anterior
				lstErroresSEIDA.add(validadorDescrMin.codtipdescri(descrMinima));
			}
		}
		//rtineo mejoras, se ejecuta metodo con variablesIngreso
		if(variablesIngreso != null){
			lstErroresSEIDA.addAll(validadorDescrMin.valtipdescr(item,variablesIngreso));
		}else{
			//continua ejecutanado el metodo anterior
			lstErroresSEIDA.addAll(validadorDescrMin.valtipdescr(item));
		}
		//rtineo fin
		lstErroresSEIDA.addAll(validadorDescrMin.valgraldescmin(item, dua));

		return lstErroresSEIDA;
	}

	//rtineo sobrecargamos el metodo
	private List poblarItemDescrMinima( Long numCorreDoc, int numSecItem){
		return poblarItemDescrMinima(numCorreDoc, numSecItem, null); 
	}
	//rtineo fin mejoras
	/**pase 548 Inicio de cambios por DESCRMINIMAS 04-12-2014**/    
	private List poblarItemDescrMinima( Long numCorreDoc, int numSecItem, Map<String, Object> variablesIngreso)
	{
		DescrMinimaService descrMinimaService= fabricaDeServicios.getService("descripcionMinima.DescrMinimaService");
		//rtineo mejoras, se utiliza la consulta precargada
		List detItem = new ArrayList();
		if(variablesIngreso != null){
			detItem =  descrMinimaService.obtenerItemDescrMinima(numCorreDoc,numSecItem,variablesIngreso);
		}else{
			//continumaos con metodo anterior
			detItem =  descrMinimaService.obtenerItemDescrMinima(numCorreDoc,numSecItem);
		}
		//rtineo fin.

		return detItem;
	}
	public boolean tieneDescripcionMinimaNuevaEstructuraEnBD(String numCorredoc, String numSecItem, Date fechaNumeracion){
		String tipoDescrMinima="";
		boolean flag = false;
		List listdetItem = poblarItemDescrMinima(new Long(numCorredoc), Integer.parseInt(numSecItem));
		if (!CollectionUtils.isEmpty(listdetItem)){
			if( ((HashMap)listdetItem.get(0)).get("tipoDescrMnima") != null ){
				tipoDescrMinima = ((HashMap)listdetItem.get(0)).get("tipoDescrMnima").toString();
				if(!SunatStringUtils.isEmpty(tipoDescrMinima)){
					Enum tipo = TipoDescrMinima.get(tipoDescrMinima);          		    
					if (tipo != null){
						flag = true;
					}
				}    		  
			}   	         	   
		}
		/***Inicio de cambios PAS20155E220000469 arey***/
		else{
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Date fecVigencia = SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(CATALOGO_FECHA_VIGENCIA, "FEC_INIVIG").get("des_datacat").toString());
			if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaNumeracion, fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){ 
				flag= true;        		 
			}    	  
		}
		/***Fin de cambios PAS20155E220000469 arey***/
		return flag;
	}

	//rtineo mejoras, sobrecargamos el metodo
	public String estadoDescripcionMinimaEnBD(String numCorredoc, String numSecItem){
		return estadoDescripcionMinimaEnBD(numCorredoc, numSecItem,null);
	}
	//rtineo mejoras, fin

	/**Adicionado por SAU201510002000160**/
	public String estadoDescripcionMinimaEnBD(String numCorredoc, String numSecItem,Map<String, Object> variablesIngreso){
		String tipoDescrMinima="";
		String estado = "esAntigua";
		//rtineo mejoras, se utiliza la consulta precargada en variableIngreso
		List listdetItem = new ArrayList();
		if(variablesIngreso != null){
			listdetItem = poblarItemDescrMinima(new Long(numCorredoc), Integer.parseInt(numSecItem),variablesIngreso);
		}else{
			//se continua con el metodo anterior
			listdetItem = poblarItemDescrMinima(new Long(numCorredoc), Integer.parseInt(numSecItem));
		}

		//rtineo mejoras, fin
		if (!CollectionUtils.isEmpty(listdetItem)){
			if( ((HashMap)listdetItem.get(0)).get("tipoDescrMnima") != null ){
				tipoDescrMinima = ((HashMap)listdetItem.get(0)).get("tipoDescrMnima").toString();
				if(!SunatStringUtils.isEmpty(tipoDescrMinima)){
					Enum tipo = TipoDescrMinima.get(tipoDescrMinima);          		    
					if (tipo != null){
						estado = "esNueva";
					}
				}    		  
			}   	         	   
		} 
		else{
			estado="noTiene";
		} 
		return estado;
	}

	//rtineo mejoras, inicializa las consultas de las validacion de descripciones minimas
	public Map<String, Object> setupDescripcionesMinimas(Declaracion dua,Declaracion declaracionBD, Map<String, Object> variablesIngreso){
		//obtenemos la consulta de item factura
		if(declaracionBD != null){

			//cargamos los Items de las facturas
			Map<Integer,List<Map<String,Object>>> mapItemFacturaCache = new HashMap<Integer,List<Map<String,Object>>>();
			ItemFacturaDAO itemFactura = fabricaDeServicios.getService("itemFacturaDAO");
			Map<String, Object> params=  new HashMap<String, Object>();
			StringBuilder stringBuilder = new StringBuilder();
			List<String> listPartidas = new ArrayList<String>();
			params.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());
			List<Map<String, Object>> listaItem=  itemFactura.getListItemByMap(params);
			for(Map<String,Object> mapTmp:listaItem){
				Integer clave = ((BigDecimal)mapTmp.get("numsecitem")).intValue();
				List<Map<String,Object>> listItemCache = mapItemFacturaCache.get(clave);
				if(listItemCache == null){
					listItemCache = new ArrayList<Map<String,Object>>();
					mapItemFacturaCache.put(clave, listItemCache);
				}
				listItemCache.add(mapTmp);
				//agrupamos las partidas
				String strPartida = mapTmp.get("numpartnandi").toString();
				if(!listPartidas.contains(strPartida)){
					listPartidas.add(strPartida);
					stringBuilder.append(strPartida).append(",");
				}

			}
			variablesIngreso.put("mapItemFacturaCache", mapItemFacturaCache);

			//cargamos el mapCabDeclara
			CabDeclaraDAO declaran = fabricaDeServicios.getService("cabDeclaraDAO");
			Map<String, Object> paramsDua= new HashMap<String, Object>();
			paramsDua.put("numeroCorrelativo",declaracionBD.getDua().getNumcorredoc());
			DUA datosDua=declaran.selectByNumCorredoc(paramsDua);
			variablesIngreso.put("duaCache", datosDua);

			//cargamos las observaciones
			Map<Integer,List<Observacion>> mapObservacionesCache = new HashMap<Integer,List<Observacion>>();
			ObservacionDAO observacion = fabricaDeServicios.getService("observacionDAO");
			Map<String, Object> mapBusqueda = new HashMap<String, Object>();
			mapBusqueda.put("numcorredoc",declaracionBD.getDua().getNumcorredoc());
			mapBusqueda.put("codtipobs","03");//catalogo 369
			List<Observacion> listObs = observacion.findObservcionByMap(mapBusqueda);
			for(Observacion obsTmp:listObs){
				Integer claveObs = obsTmp.getNumsecitem();
				List<Observacion> listObsCache = mapObservacionesCache.get(claveObs);
				if(listObsCache == null){
					listObsCache = new ArrayList<Observacion>();
					mapObservacionesCache.put(claveObs, listObsCache);
				}
				listObsCache.add(obsTmp);
			}
			variablesIngreso.put("mapObservacionesCache", mapObservacionesCache);

			//llenamos por unica llamada el catalogo para obtener la fecha de vigencia
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Date fecVigencia = SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(CATALOGO_FECHA_VIGENCIA, "FEC_INIVIG").get("des_datacat").toString());
			variablesIngreso.put("catalogoFechaVigenciaCache", fecVigencia);

			//se realiza la llamada rest para obtener las partidas
			List<Nandina> listNandinaRest = new ArrayList<Nandina>();
			if(stringBuilder.length()>0){
				stringBuilder.deleteCharAt(stringBuilder.length() - 1);
				List<String> listPartidasBuilder = GeneralUtils.obtenerListCadenas(stringBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaPartidas : listPartidasBuilder){
					List<Nandina> lstPartidas = catalogoAyudaService.getPartidasObject(cadenaPartidas);
					if(lstPartidas != null) listNandinaRest.addAll(lstPartidas);
				}
			}
			HashMap<String,Object> listNandinas = new HashMap<String,Object>();
			for(Nandina nandinaTmp : listNandinaRest){
				listNandinas.put(nandinaTmp.getPartida().toString(), nandinaTmp);
			}
			variablesIngreso.put("listPartidasRestCache", listNandinas);

			//obtenemos los catalogos para validar las descripciones minimas nuevas validaciones
			List<Map<String,String>> listCatalogo393 = catalogoAyudaService.getElementosDesDatacat("393");
			Map<String, String> mapCatalogo393Cache = new HashMap<String, String>();
			for(Map<String,String> mapCat393 : listCatalogo393){
				mapCatalogo393Cache.put(mapCat393.get("cod_datacat"), mapCat393.get("des_datacat"));
			}
			variablesIngreso.put("mapCatalogoCache393", mapCatalogo393Cache);
			List<Map<String,String>> listCatalogo500 = catalogoAyudaService.getElementosDesDatacat("500");
			Map<String, String> mapCatalogo500Cache = new HashMap<String, String>();
			for(Map<String,String> mapCat500 : listCatalogo500){
				mapCatalogo500Cache.put(mapCat500.get("cod_datacat"), mapCat500.get("des_datacat"));
			}
			variablesIngreso.put("mapCatalogoCache500", mapCatalogo500Cache);

			//recorremos los items, para obtener los tipos de descripcion minima old Validaciones
			StringBuilder stringBuilderTipoDescr = new StringBuilder();
			List<String> listTipoDescr = new ArrayList<String>();
			StringBuilder stringBuilderNumPartNandi = new StringBuilder();
			StringBuilder stringBuilderNumSubPartNandi = new StringBuilder();
			List<String> listNumPartNandi = new ArrayList<String>();
			if(!CollectionUtils.isEmpty(dua.getListDAVs())){ // si no tiene formato B no validar  mol por SAU
				for (DAV dav : dua.getListDAVs()){
					for (DatoFactura factura : dav.getListFacturas()){
						for (DatoItem item : factura.getListItems()){
							for (DatoDescrMinima descrMinima: item.getListDecrMinima()){
								String codTipDescr = descrMinima.getCodtipdescr();
								if(!listTipoDescr.contains(codTipDescr)){
									listTipoDescr.add(codTipDescr);
									stringBuilderTipoDescr.append(codTipDescr).append(",");
								}
							}
							String strNumPartNandi = item.getNumpartnandi().toString();
							if(!listNumPartNandi.contains(strNumPartNandi)){
								listNumPartNandi.add(strNumPartNandi);
								stringBuilderNumPartNandi.append(strNumPartNandi).append(",");
								stringBuilderNumSubPartNandi.append(SunatStringUtils.substring(strNumPartNandi,0,4)).append(",");
							}
							//seteamos a todos los item con el nombre de su descripcion nombreDescrMinima
							item.setMapCatalogos(variablesIngreso);
						}
					}
				}
			}
			List<Map<String,String>> listMapTipoDescrNew = new ArrayList<Map<String,String>>();
			List<Map<String,String>> listMapTipoDescrOld = new ArrayList<Map<String,String>>();
			if(stringBuilderTipoDescr.length()>0){
				stringBuilderTipoDescr.deleteCharAt(stringBuilderTipoDescr.length() - 1);
				List<String> listTipoDescrBuilder = GeneralUtils.obtenerListCadenas(stringBuilderTipoDescr.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaTipoDescr : listTipoDescrBuilder){
					List<Map<String,String>> lstNew = catalogoAyudaService.getElementosCat(TipoDeDescrMinimaService.CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA, null, null, null, null, cadenaTipoDescr);
					if(lstNew != null) listMapTipoDescrNew.addAll(lstNew);
					List<Map<String,String>> lstOld = catalogoAyudaService.getElementosCat(TipoDeDescrMinimaService.CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA, null, null, null, null, cadenaTipoDescr);
					if(lstOld != null) listMapTipoDescrOld.addAll(lstOld);
				}
			}
			Map<String,Object> mapTipoDescrNewAll = new HashMap<String,Object>();
			for(Map<String,String> mapTipoDescrNew : listMapTipoDescrNew){
				mapTipoDescrNewAll.put(mapTipoDescrNew.get("cod_datacat"), mapTipoDescrNew);
			}
			Map<String,Object> mapTipoDescrOldAll = new HashMap<String,Object>();
			for(Map<String,String> mapTipoDescrOld : listMapTipoDescrOld){
				mapTipoDescrOldAll.put(mapTipoDescrOld.get("cod_datacat"), mapTipoDescrOld);
			}
			variablesIngreso.put("MapTipoDescrNewCache", mapTipoDescrNewAll);
			variablesIngreso.put("MapTipoDescrOldCache", mapTipoDescrOldAll);

			//validacion de partidas de los item en el catalogo de validacion
			Map<String,List> mapNumPartNandiRest = new HashMap<String,List>();
			Map<String,List> mapNumSubPartNandiRest = new HashMap<String,List>();
			if(stringBuilderNumPartNandi.length()>0){
				CatalogoValidaService catalogoValidaService = (CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService");
				stringBuilderNumPartNandi.deleteCharAt(stringBuilderNumPartNandi.length() - 1);
				List<String> listPartNandiBuilder = GeneralUtils.obtenerListCadenas(stringBuilderNumPartNandi.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaPartNandi : listPartNandiBuilder){
					Map<String,List> mapPartNandi = catalogoValidaService.validarElementosCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,cadenaPartNandi);
					if(mapPartNandi != null && !mapPartNandi.containsKey("Error")) mapNumPartNandiRest.putAll(mapPartNandi);
				}
				stringBuilderNumSubPartNandi.deleteCharAt(stringBuilderNumSubPartNandi.length() - 1);
				List<String> listSubPartNandiBuilder = GeneralUtils.obtenerListCadenas(stringBuilderNumSubPartNandi.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
				for(String cadenaSubPartNandi : listSubPartNandiBuilder){
					Map<String,List> mapSubPartNandi = catalogoValidaService.validarElementosCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,cadenaSubPartNandi);
					if(mapSubPartNandi != null && !mapSubPartNandi.containsKey("Error")) mapNumSubPartNandiRest.putAll(mapSubPartNandi);
				}
			}
			Map<String,Boolean> mapPartNandiRest = new HashMap<String,Boolean>();
			for (Entry<String, List> e: mapNumPartNandiRest.entrySet()) {
				mapPartNandiRest.put(e.getKey(), CollectionUtils.isEmpty(e.getValue()));
			}
			Map<String,Boolean> mapSubPartNandiRest = new HashMap<String,Boolean>();
			for (Entry<String, List> e: mapNumSubPartNandiRest.entrySet()) {
				mapSubPartNandiRest.put(e.getKey(), CollectionUtils.isEmpty(e.getValue()));
			}
			variablesIngreso.put("mapPartNandiRestCache", mapPartNandiRest);
			variablesIngreso.put("mapSubPartNandiRestCache", mapSubPartNandiRest);

			//cargamos todos los descr_posiciones, para evitar llamar a las consultas luego
			//falta validar que unicamente cuando se trate de descripciones minimas
			DescrPosicionDAO descrPosicionDAO = (DescrPosicionDAO)fabricaDeServicios.getService("descrPosicionDAO");

			/*Inicio AREY-MIN PAS20165E220200137*/
			Map<String, Object> filtro = new HashMap<String, Object>();
			filtro.put("FEC_VIGENCIA", datosDua.getFecdeclaracion()!=null?datosDua.getFecdeclaracion():SunatDateUtils.getCurrentDate());
			/*Fin AREY-MIN*/


			//List<DescrPosicion> lstPosiciones = descrPosicionDAO.lstGetAllDescrPosicion();
			List<DescrPosicion> lstPosiciones = descrPosicionDAO.lstByCondition(filtro);
			Map<String,List<DescrPosicion>> mapDescrPosicionesCache = new HashMap<String,List<DescrPosicion>>();
			for(DescrPosicion descrPosicion : lstPosiciones){
				String identificador = descrPosicion.getCodigoTipoDescrMinima();//cod_mercancia
				List<DescrPosicion> listDescri = mapDescrPosicionesCache.get(identificador);
				if(listDescri == null){
					listDescri = new ArrayList<DescrPosicion>();
					mapDescrPosicionesCache.put(identificador,listDescri);
				}
				listDescri.add(descrPosicion);
			}
			variablesIngreso.put("mapDescrPosicionesCache", mapDescrPosicionesCache);
			//fin
		}

		return new HashMap<String,Object>();
	}
	//rtineo mejoras, sobrecargamos el metodo

	public List<Map<String, String>> validarDescripcionMinimaSinVigencia(DatoItem item, Declaracion dua, Declaracion declaracionBD) throws Exception{
		return validarDescripcionMinimaSinVigencia(item,dua,declaracionBD,null);
	}
	//rtineo mejoras fin
	/**
	 * Aplica todas las validaciones de negocio que sean transparentes a la vigencia del datacatalogo 507
	 * Si se llama desde un mapa crear el objeto Declaracion declaracionBD
	 *  y colocar el num_corredoc de la dua de BD referenciada en el envio para que coteje.
	 * 
	 * @param item
	 * @param declaracion
	 * @param declaracionBD
	 * @return list de errores
	 * @author arey
	 * @version 1.0
	 */
	public List<Map<String, String>> validarDescripcionMinimaSinVigencia(DatoItem item, Declaracion dua, Declaracion declaracionBD,Map<String, Object> variablesIngreso) throws Exception
	{
		TipoDeDescrMinimaService tipoDeDescrMinima = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");
		List<Map<String, String>> lstErroresSEIDA = new ArrayList<Map<String, String>>();
		TipoValidacionDescrMin tipoValidacionXML = null;//se cambiaron nombres para mas orden SAU201510002000160 - PASE490
		Enum<?> tipoDescrMinimaXML = null; //se cambiaron nombres para mas orden SAU201510002000160 - PASE490
		actualizarNumerosSecuencia(item, dua);

		/**Consideracion de la fecha de la DAM**/
		Date fechaVigencia = dua.getDua().getFecdeclaracion();
		if(fechaVigencia == null){
			fechaVigencia = SunatDateUtils.getCurrentDate();
		}
		/**Consideracion de la fecha de la DAM**/

		try {
			//rtineo mejoras, se utiliza variablesIngreso para almacenas las llamadas rest repetidas
			if(variablesIngreso != null){
				tipoDescrMinimaXML = tipoDeDescrMinima.obtenerTipoDeDescrMinima(item, fechaVigencia, variablesIngreso);
			}else{
				//sigue con el metodo anterior
				tipoDescrMinimaXML = tipoDeDescrMinima.obtenerTipoDeDescrMinima(item, fechaVigencia);//partida sea asociada a descripcion minima
			}
			//rtineo fin

			if(!CollectionUtils.isEmpty(item.getListDecrMinima())){//adicionado por bug 19858  pase 399    
				//rtineo mejoras, se llama con variables Utiles
				if(variablesIngreso != null){
					tipoValidacionXML = tipoDeDescrMinima.determinarTipoValidacionPorTipoDescrMinima(item,variablesIngreso);
				}else{
					tipoValidacionXML = tipoDeDescrMinima.determinarTipoValidacionPorTipoDescrMinima(item);
				}
				//rtineo mejoras, fin

				//	        	boolean esNuevaEstructuraBD = tieneDescripcionMinimaNuevaEstructuraEnBD(declaracionBD.getDua().getNumcorredoc().toString(),item.getNumsecitem().toString(), declaracionBD.getDua().getFecdeclaracion()) ;//Ajustes Pase 469 - 2015 arey
				//rtineo mejoras, se utilizara el metodo optimizado o se seugira utilizando el metodo pesado
				String estadoDescrMinBD;
				if(variablesIngreso != null){
					estadoDescrMinBD = estadoDescripcionMinimaEnBD(declaracionBD.getDua().getNumcorredoc().toString(),item.getNumsecitem().toString(),variablesIngreso);
				}else{
					//seguimos utilizando metodo anterior
					estadoDescrMinBD = estadoDescripcionMinimaEnBD(declaracionBD.getDua().getNumcorredoc().toString(),item.getNumsecitem().toString());
				}
				//rtineo mejoras fin
				//adicionado por SAU201510002000160 - PASE490

				//rtineo mejoras, se llama a la fecha ya almacenada
				Date fecVigencia;
				if(variablesIngreso != null){
					fecVigencia = (Date)variablesIngreso.get("catalogoFechaVigenciaCache");
				}else{
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					fecVigencia = SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(CATALOGO_FECHA_VIGENCIA, "FEC_INIVIG").get("des_datacat").toString());	        		 
				}
				//rtineo mejoras, fin
				boolean puedeEnviarNewDescrMin = false;		
				Date fechaNumeracion = declaracionBD.getDua().getFecdeclaracion()!=null?declaracionBD.getDua().getFecdeclaracion():new Date();
				if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaNumeracion, fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){ 
					puedeEnviarNewDescrMin= true;        		 
				}    	  

				if (tipoDescrMinimaXML != null)//es partida asociada a descr minima
				{	 /*
	        	 //cotejar lo de bd
	        	 if(tieneDescripcionMinima(declaracionBD.getDua().getNumcorredoc().toString(),item.getNumsecitem().toString())){     
	        		 lstErroresSEIDA = ejecutarNewValidaciones(tipoDescrMinima, item, dua); 
	        	 }else{
	        		 lstErroresSEIDA.add(generarError("30779",
		                            new Object[] { TipoDeDescrMinimaService.CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA, item.getNumsecitem().toString()}));
	        	 }
				 */       	 	        	 		        	      	 
					//VALIDACIONES ENTRE BD Y ENVIO:

					//		        	 if(esNuevaEstructuraBD	 && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES)){ //conforme nueva estructura ambos
					if(estadoDescrMinBD.equals("esNueva") && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES)){ //conforme nueva estructura ambos
						lstErroresSEIDA = ejecutarNewValidaciones(tipoDescrMinimaXML, item, dua); 
					}
					//		        	 else if(!esNuevaEstructuraBD && tipoValidacionXML.equals(TipoValidacionDescrMin.OLD_VALIDACIONES)){//conforme antigua estructura ambos
					else if(estadoDescrMinBD.equals("esAntigua") && tipoValidacionXML.equals(TipoValidacionDescrMin.OLD_VALIDACIONES)){//conforme antigua estructura ambos
						//rtineo mejoras, se ejecuta metodo con variablesIngreso
						if(variablesIngreso != null){
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua, variablesIngreso);
						}else{
							//continua ejecutando metodo anterior
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua);
						}
					}
					//		        	 else if(!esNuevaEstructuraBD && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES)){//valida bd vs envio debio  ser OLD


					/**Inicio de cambios de minimas por SAU201510002000160 - PASE490**/
					//valida bd vs envio y fue previo a la vigencia 
					else if(estadoDescrMinBD.equals("esAntigua") && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES) && !puedeEnviarNewDescrMin){
						lstErroresSEIDA.add(generarError("30779",
								new String[] { TipoDeDescrMinimaService.CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA, item.getNumsecitem().toString()}));
					}

					//valida bd vs envio y si fue posterior a la vigencia 
					else if(estadoDescrMinBD.equals("esAntigua") && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES) && puedeEnviarNewDescrMin){
						lstErroresSEIDA = ejecutarNewValidaciones(tipoDescrMinimaXML, item, dua); 
					}
					else if(estadoDescrMinBD.equals("esNueva")   && tipoValidacionXML.equals(TipoValidacionDescrMin.OLD_VALIDACIONES) && puedeEnviarNewDescrMin){//cambio entre estructuras
						//rtineo mejoras, se ejecuta metodo con variablesIngreso
						if(variablesIngreso != null){
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua, variablesIngreso);
						}else{
							//continua ejecutando metodo anterior
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua); 
						}
					}

					//valida bd que no hubo vs envio si fue previo a la vigencia
					else if(estadoDescrMinBD.equals("noTiene") && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES) && !puedeEnviarNewDescrMin){
						lstErroresSEIDA.add(generarError("30779",
								new String[] { TipoDeDescrMinimaService.CATALOGO_OLD_ESTRUCTURA_DESCRMINIMA, item.getNumsecitem().toString()}));
					}

					//valida bd vs envio y si fue posterior a la vigencia 
					else if(estadoDescrMinBD.equals("noTiene") && tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES) && puedeEnviarNewDescrMin){//proceso adicionando con vig
						lstErroresSEIDA = ejecutarNewValidaciones(tipoDescrMinimaXML, item, dua); 
					}
					else if(estadoDescrMinBD.equals("noTiene") && tipoValidacionXML.equals(TipoValidacionDescrMin.OLD_VALIDACIONES)){ //proceso adicionando con vig
						//rtineo mejoras, se ejecuta metodo con variablesIngreso
						if(variablesIngreso != null){
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua, variablesIngreso);
						}else{
							//continua ejecutando metodo anterior
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua); 
						}
					}
					/**Fin de cambios de minimas por SAU201510002000160 - PASE490**/

					//		        	 else if(esNuevaEstructuraBD && tipoValidacionXML.equals(TipoValidacionDescrMin.OLD_VALIDACIONES)){//valida bd vs envio debio ser NEW
					//		        		 lstErroresSEIDA.add(generarError("30779",
					//		                            new Object[] { TipoDeDescrMinimaService.CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA, item.getNumsecitem().toString()}));
					//		        	 }


				}
				else
				{   //partida NO asociada a descr minima
					if(tipoValidacionXML.equals(TipoValidacionDescrMin.NEW_VALIDACIONES)){//debio enviar como antigua porque no corresponde
						//if(tieneDescripcionMinima(declaracionBD.getDua().getNumcorredoc().toString(),item.getNumsecitem().toString())){  //coteja bd
						lstErroresSEIDA.add(generarError("35427",
								new String[] { item.getNumpartnandi().toString(), TipoDeDescrMinimaService.CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA,item.getNumsecitem().toString()}));
						//new Object[] { TipoDeDescrMinimaService.CATALOGO_NEW_ESTRUCTURA_DESCRMINIMA, item.getNumsecitem().toString()}));
					}else{
						//rtineo mejoras, se ejecuta metodo con variablesIngreso
						if(variablesIngreso != null){
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua, variablesIngreso);
						}else{
							//continua ejecutando metodo anterior
							lstErroresSEIDA = ejecutarOLDValidaciones(item, dua);
						}
					}
				}
			}
		}
		catch (DescrMinimaException ex)
		{
			
			 String parametrosEnviar[] = ex.getError().getParametros()!=null? new String[ex.getError().getParametros().length]:null;
			 if(ex.getError().getParametros()!=null){
				 for (int i=0;i<ex.getError().getParametros().length;i++) 
				 {
					 parametrosEnviar[i]=ex.getError().getParametros()[i].toString();
				 }
			 }	 
			lstErroresSEIDA.add(generarError(ex.getError().getCodigo(), parametrosEnviar));//sin este arreglo no pintaba los parametros
			//lstErroresSEIDA.add(generarError(ex.getError().getCodigo(), new String[]{SunatStringUtils.toStringObj(ex.getError().getParametros())}));
		}

		return lstErroresSEIDA;

	}
	/**pase548 Fin cambios por DESCRMINIMAS 04-12-2014**/    

	/*********************** METODOS PRIVADOS ******************************/

	private Map<String, String> generarError(String codigoError, String[] argumentos)
	{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		return catalogoAyudaService.getError(codigoError, argumentos);

	}

	private void actualizarNumerosSecuencia(DatoItem item, Declaracion dua)
	{

		Long numcorredoc = 0L;
		Integer numsecprove = 0;
		Integer numsecfact = 0;
		for (DAV dav : dua.getListDAVs())
		{
			for (DatoFactura factura : dav.getListFacturas())
			{
				for (DatoItem item1 : factura.getListItems())
				{
					if (item.getNumsecitem().toString().equals(item1.getNumsecitem().toString()))
					{
						item.setNumcorredoc(dav.getNumcorredoc());
						item.setNumsecprove(dav.getNumsecuprov());
						item.setNumsecfact(factura.getNumsecfactu());
						break;

					}
				}
			}
		}

	}

	/******************** INYECCION DE SPRING **********************/


/*
	public void setTipoDeDescrMinima(TipoDeDescrMinimaService tipoDeDescrMinima)
	{
		this.tipoDeDescrMinima = tipoDeDescrMinima;
	}

	public void setTransformador(TransformadorDescrMinimaService transformador)
	{
		this.transformador = transformador;
	}

	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper)
	{
		this.catalogoHelper = catalogoHelper;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
	{
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setValidadorFactory(ValidadorFactory validadorFactory)
	{
		this.validadorFactory = validadorFactory;
	}*/
}
