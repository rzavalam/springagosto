package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.controladuanero2.ingreso.eer.model.Asocdocudam;
import pe.gob.sunat.controladuanero2.ingreso.eer.model.dao.AsocdocudamDAO;
import pe.gob.sunat.despaduanero.despacho.salida.simplificada.model.Seriesdx;
import pe.gob.sunat.despaduanero.despacho.salida.simplificada.model.dao.PolizadxDAO;
import pe.gob.sunat.despaduanero.despacho.salida.simplificada.model.dao.SeriesdxDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero2.manifiesto.model.eer.ManifiestoDesconsolidadoEER;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import weblogic.utils.ArrayUtils;

public class ValPrecedenteEERServiceImpl extends IngresoAbstractServiceImpl implements ValPrecedenteEERService {

	protected final Log logPrecedentesEER = LogFactory.getLog(getClass());

	public final static int INTERVALO = 12;

//	@Deprecated
//	private Map<String, String> getPrecedenteEER(String codiAduan, String anoPrese, String numeCorre, String numeSerie) {
//
//		Map<String, String> resultMap = null;
//		SeriesxcDAO serieXCDAO = fabricaDeServicios.getService("despacho.salida.seriesxcDAO.ds");
//
//		Seriesxc seriexc = serieXCDAO.selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie);
//
//		if (seriexc != null) {
//
//			resultMap = new HashMap<String, String>();
//
//			resultMap.put("anoPrese", seriexc.getAnoPrese());
//			resultMap.put("codiAduan", seriexc.getCodiAduan());
//			resultMap.put("numeCorre", seriexc.getNumeCorre());
//			resultMap.put("numeSerie", seriexc.getNumeSerie());
//			resultMap.put("cantBulto", seriexc.getCantBulto().toString());
//			resultMap.put("clase", seriexc.getClase());
//			resultMap.put("pesoNeto", seriexc.getPesoNeto().toString());
//			resultMap.put("pesoBruto", seriexc.getPesoBruto().toString());
//			resultMap.put("pesoNeol", seriexc.getPesoNeol().toString());
//			resultMap.put("pesoBrol", seriexc.getPesoBrol().toString());
//			resultMap.put("partNandi", seriexc.getPartNandi().toString());
//			resultMap.put("fobDivfac", seriexc.getFobDivfac().toString());
//			resultMap.put("fobDolpol", seriexc.getFobDolpol().toString());
//			resultMap.put("fobDolold", seriexc.getFobDolold().toString());
//			resultMap.put("unidFiqty", seriexc.getUnidFiqty().toString());
//			resultMap.put("unidFides", seriexc.getUnidFides());
//			resultMap.put("derecho", seriexc.getDerecho());
//			resultMap.put("descComer", seriexc.getDescComer());
//			resultMap.put("fechIngsi", seriexc.getFechIngsi().toString());
//			resultMap.put("seriElim", seriexc.getSeriElim());
//			resultMap.put("cdigmod", seriexc.getCdigmod());
//			resultMap.put("fmod", seriexc.getFmod().toString());
//			resultMap.put("flag", seriexc.getFlag());
//			resultMap.put("regiProce", seriexc.getRegiProce());
//			resultMap.put("caduRepre", seriexc.getCaduregpre());
//
//			/*
//			 * 
//			 * <result column="ANO_REPRE" property="anoRepre" jdbcType="VARCHAR" /> <result column="NUME_REPRE" property="numeRepre" jdbcType="VARCHAR" /> <result column="FVEN_REPRE" property="fvenRepre" jdbcType="DECIMAL" /> <result column="CINCDRAW" property="cincdraw" jdbcType="VARCHAR" /> <result column="SERI_REPRE" property="seriRepre" jdbcType="VARCHAR" /> <result column="NUM_GUIA" property="numGuia" jdbcType="VARCHAR" /> <result column="IND_AUTORIZACION" property="indAutorizacion" jdbcType="VARCHAR" />
//			 */
//		}
//
//		/*
//		 * consultar si se trata de declaracion simplificada de salida, utilizar el siguiente servicio (despacho.salida.seriesxcDAO.ds).selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie)
//		 */
//		return resultMap;
//	}

//	@Deprecated
//	private Map<String, String> getPrecedenteDS(String codiAduan, String anoPrese, String numeCorre, String numeSerie) {
//
//		Map<String, String> resultMap = null;
//		SeriesdxDAO serieDXDAO = fabricaDeServicios.getService("despacho.salida.seriesdxDAO.ds");
//		Seriesdx seriedx = serieDXDAO.selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie);
//
//		if (seriedx != null) {
//			resultMap = new HashMap<String, String>();
//			resultMap.put("anoPrese", seriedx.getAnoPrese());
//			resultMap.put("codiAduan", seriedx.getCodiAduan());
//			resultMap.put("numeCorre", seriedx.getNumeCorre());
//			resultMap.put("numeSerie", seriedx.getNumeSerie());
//			resultMap.put("cantBulto", seriedx.getCantBulto().toString());
//			resultMap.put("clase", seriedx.getClase());
//			resultMap.put("pesoNeto", seriedx.getPesoNeto().toString());
//			resultMap.put("pesoBruto", seriedx.getPesoBruto().toString());
//			resultMap.put("pesoNeol", seriedx.getPesoNeol().toString());
//			resultMap.put("pesoBrol", seriedx.getPesoBrol().toString());
//			resultMap.put("partNandi", seriedx.getPartNandi().toString());
//			resultMap.put("fobDivfac", seriedx.getFobDivfac().toString());
//			resultMap.put("fobDolpol", seriedx.getFobDolpol().toString());
//			resultMap.put("fobDolold", seriedx.getFobDolold().toString());
//			resultMap.put("unidFiqty", seriedx.getUnidFiqty().toString());
//			resultMap.put("unidFides", seriedx.getUnidFides());
//			resultMap.put("derecho", seriedx.getDerecho());
//			resultMap.put("descComer", seriedx.getDescComer());
//			resultMap.put("fechIngsi", seriedx.getFechIngsi().toString());
//			resultMap.put("seriElim", seriedx.getSeriElim());
//			resultMap.put("cdigmod", seriedx.getCdigmod());
//			resultMap.put("fmod", seriedx.getFmod().toString());
//			resultMap.put("flag", seriedx.getFlag());
//			resultMap.put("regiProce", seriedx.getRegiProce());
//			resultMap.put("caduRepre", seriedx.getCaduRepre());
//			resultMap.put("anoRepre", seriedx.getAnoRepre());
//			resultMap.put("numeRepre", seriedx.getNumeRepre());
//			resultMap.put("fvenRepre", seriedx.getFvenRepre().toString());
//			resultMap.put("cincdraw", seriedx.getCincdraw());
//			resultMap.put("seriRepre", seriedx.getSeriRepre());
//			resultMap.put("numGuia", seriedx.getNumGuia());
//			resultMap.put("indAutorizacion", seriedx.getIndAutorizacion());
//		}
//
//		/*
//		 * consultar si se trata de declaracion simplificada de salida, utilizar el siguiente servicio (despacho.salida.seriesdxDAO.ds).selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie)
//		 */
//		return null;
//	}

//	@Deprecated
//	private Map<String, Object> getPrecedenteEF(String codiAduan, String anoPrese, String numeCorre, String numeSerie) {
//
//		SeriesdxDAO serieDXDAO = fabricaDeServicios.getService("despacho.salida.seriesdxDAO.ds");
//		Map<String, Object> resultMap = serieDXDAO.selectByPrimaryKey2(anoPrese, codiAduan, numeCorre, numeSerie);
//
//		/*
//		 * consultar si se trata de declaracion de exporta facil, utilizar el siguiente servicio (MAP)
//		 * 
//		 * crear un xml,dao,daoImpl para la tabla det_expfac, crear un servicio parecido a despacho.salida.seriesdxDAO.ds).selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie pero que haga referencia a la tabla mencionada.
//		 * 
//		 * 
//		 */
//		return resultMap;
//	}

	@Deprecated
	public Boolean esReimportacionEER(String codiRegi, String codiAduan, String anoPrese, String numeCorre, String numeSerie) {

		/*
		 * if ("48".equals(codiRegi)) { if (!CollectionUtils.isEmpty(getPrecedenteDS(codiAduan, anoPrese, numeCorre, numeSerie))) { return true; } }
		 * 
		 * if ("XC".equals(codiRegi)) { if (!CollectionUtils.isEmpty(getPrecedenteEER(codiAduan, anoPrese, numeCorre, numeSerie))) { return true; } }
		 * 
		 * if (!CollectionUtils.isEmpty(getPrecedenteEF(codiAduan, anoPrese, numeCorre, numeSerie))) { return true; }
		 */
		/*
		 * si codiRegi = "48" si getPrecedenteDS(codiAduan,anoPrese,numeCorre,numeSerie) tiene registros retornar true
		 * 
		 * si CodiRegi = "XC" si getPrecedenteEER(codiAduan,anoPrese,numeCorre,numeSerie) tiene registros retornar true
		 * 
		 * si getPrecedenteEF(codiAduan,anoPrese,numeCorre,numeSerie) tiene registros retornar true
		 * 
		 * retornar false
		 */
		return false;
	}

	private Map<String, Object> getDeclaracionExportacionSDA(String codigoAduana, String numeroDeclaracion, String anioPresentacion) {
		Map<String, Object> parametrosBusqueda = new HashMap<String, Object>();
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
		parametrosBusqueda.put("COD_ADUANA", codigoAduana);
		parametrosBusqueda.put("ANN_PRESEN", anioPresentacion);
		parametrosBusqueda.put("NUM_DECLARACION", numeroDeclaracion);
		parametrosBusqueda.put("COD_REGIMEN", ConstantesDataCatalogo.COD_REGIMEN_EXPORTACION_SIMPLIFICADA);
		Map<String, Object> declaracionExportacion = cabDeclaraDAO.findMapDUAByPk(parametrosBusqueda);
		return declaracionExportacion;
	}

	private Map<String, Object> getSeriePrecedenteDS(String codiAduan, String anoPrese, String numeCorre, String numeSerie) {
		Map<String, Object> resultMap = null;
		SeriesdxDAO serieDXDAO = fabricaDeServicios.getService("despacho.salida.seriesdxDAO.ds");
		Seriesdx seriedx = serieDXDAO.selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie);

		if (seriedx != null) {
			resultMap = new HashMap<String, Object>();
			resultMap.put("anoPrese", seriedx.getAnoPrese());
			resultMap.put("codiAduan", seriedx.getCodiAduan());
			resultMap.put("numeCorre", seriedx.getNumeCorre());
			resultMap.put("numeSerie", seriedx.getNumeSerie());
			resultMap.put("cantBulto", seriedx.getCantBulto());
			resultMap.put("clase", seriedx.getClase());
			resultMap.put("pesoNeto", seriedx.getPesoNeto());
			resultMap.put("pesoBruto", seriedx.getPesoBruto());
			resultMap.put("pesoNeol", seriedx.getPesoNeol());
			resultMap.put("pesoBrol", seriedx.getPesoBrol());
			resultMap.put("partNandi", seriedx.getPartNandi());
			resultMap.put("fobDivfac", seriedx.getFobDivfac());
			resultMap.put("fobDolpol", seriedx.getFobDolpol());
			resultMap.put("fobDolold", seriedx.getFobDolold());
			resultMap.put("unidFiqty", seriedx.getUnidFiqty());
			resultMap.put("unidFides", seriedx.getUnidFides());
			resultMap.put("derecho", seriedx.getDerecho());
			resultMap.put("descComer", seriedx.getDescComer());
			resultMap.put("fechIngsi", seriedx.getFechIngsi());
			resultMap.put("seriElim", seriedx.getSeriElim());
			resultMap.put("cdigmod", seriedx.getCdigmod());
			resultMap.put("fmod", seriedx.getFmod());
			resultMap.put("flag", seriedx.getFlag());
			resultMap.put("regiProce", seriedx.getRegiProce());
			resultMap.put("caduRepre", seriedx.getCaduRepre());
			resultMap.put("anoRepre", seriedx.getAnoRepre());
			resultMap.put("numeRepre", seriedx.getNumeRepre());
			resultMap.put("fvenRepre", seriedx.getFvenRepre());
			resultMap.put("cincdraw", seriedx.getCincdraw());
			resultMap.put("seriRepre", seriedx.getSeriRepre());
			resultMap.put("numGuia", seriedx.getNumGuia());
			resultMap.put("indAutorizacion", seriedx.getIndAutorizacion());
		}

		/*
		 * consultar si se trata de declaracion simplificada de salida, utilizar el siguiente servicio (despacho.salida.seriesdxDAO.ds).selectByPrimaryKey(anoPrese, codiAduan, numeCorre, numeSerie)
		 */
		return resultMap;
	}

	public Map<String, Object> getDeclaracionExportacionASIGAD(String codigoAduana, String anioPresentacion, String numeroDeclaracion) {

		PolizadxDAO polizadxDAO = this.fabricaDeServicios.getService("polizadxDef.".concat(codigoAduana));
		Map<String, Object> parametrosBusqueda = new HashMap<String, Object>();
		parametrosBusqueda.put("CODI_ADUAN", codigoAduana);
		parametrosBusqueda.put("NUME_CORRE", anioPresentacion);
		parametrosBusqueda.put("ANO_PRESEN", numeroDeclaracion);
		Map<String, Object> declaracionExportacion = polizadxDAO.selectPolizaByMap(parametrosBusqueda);
		return declaracionExportacion;
	}

	public Boolean esDSExportacionLegajada(String indicadorLegajo, Boolean esDeclaracionSDA) {
		String[] estadosLegajo = (esDeclaracionSDA ? new String[] { "A", "C", "R", "N" } : new String[] { "08" });
		if (ArrayUtils.contains(estadosLegajo, indicadorLegajo))
			return true;
		return false;

		/*
		 * String[] estadosLegajo; if(esDeclaracionSDA) estadosLegajo = new String[]{'A' , 'C' , 'R' , 'N'}; else estadosLegajo = new String[]{'08'};
		 * 
		 * if(ArrayUtils.contains(estadosLegajo,indicadorLegajo)){ return true; } return false;
		 */

	}

	public List<Map<String, String>> validarReimportacionMercancias(String codigoAduana, String numeroDeclaracion, String anioPresentacion, String numSerie) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Map<String, Object> declaracionExportacion = new HashMap<String, Object>();
		// Map<String, Object> erroresMap = new HashMap<String, Object>();
		Boolean esDeclaracionSDA = true;
		// Preguntar primero si la declaracion existe en el SDA
		declaracionExportacion = getDeclaracionExportacionSDA(codigoAduana, numeroDeclaracion, anioPresentacion);

		if (declaracionExportacion.isEmpty()) {
			esDeclaracionSDA = false;
			declaracionExportacion = getDeclaracionExportacionASIGAD(codigoAduana, numeroDeclaracion, anioPresentacion);
		}
		if (declaracionExportacion.isEmpty()) {
			listError.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70128", new String[] { numSerie, codigoAduana, anioPresentacion, ConstantesDataCatalogo.COD_REGIMEN_EXPORTACION_SIMPLIFICADA, numeroDeclaracion }));
			return listError;
		}

		listError.add(esDeclaracionSDA ? validarReimportacionMercanciasSDA(declaracionExportacion, numSerie) : validarReimportacionMercanciasASIGAD(declaracionExportacion, numSerie));
		return listError;

		/*
		 * Map<String,Object> declaracionExportacion = new HashMap<String,Object>(); Map<String,Object> erroresMap = new HashMap<String,Object>(); Boolean esDeclaracionSDA = true; //Preguntar primero si la declaracion existe en el SDA declaracionExportacion = getDeclaracionExportacionSDA(codigoAduana,numeroDeclaracion,anioPresentacion);
		 * 
		 * if(declaracionExportacion.isEmpty()){ esDeclaracionSDA = false; declaracionExportacion = getDeclaracionExportacionASIGAD(codigoAduana,numeroDeclaracion,anioPresentacion); } if(declaracionExportacion.isEmpty()){ erroresMap.add("E43",catalogoAyudaService.getError("E43")); return erroresMap; } if(esDeclaracionSDA) erroresMap.addAll(validarReimportacionMercanciasSDA(declaracionExportacion)); else erroresMap.addAll(validarReimportacionMercanciasASIGAD(declaracionExportacion));
		 * 
		 * return erroresMap;
		 * 
		 */
	}

	public Map<String, String> validarReimportacionMercanciasSDA(Map<String, Object> declaracionExportacion, String numSerie) {
		// Inicializa el mapa de retorno de errores
		Map<String, String> result = new HashMap<String, String>();

		String codigoAduana = declaracionExportacion.get("COD_ADUANA").toString(), anioPresentacion = declaracionExportacion.get("ANN_PRESEN").toString(), regimenDeclarado = declaracionExportacion.get("COD_REGIMEN").toString(), // FALTA DEFINIR
				numeroDeclaracion = declaracionExportacion.get("NUM_DECLARACION").toString();
		// Inscribir en el Catalogo F09 los mensaje de error de corresponder
		if (esDSExportacionLegajada(declaracionExportacion.get("COD_ESTDUA").toString(), true)) {
			result.put("E43", ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70128", new String[] { numSerie, codigoAduana, anioPresentacion, regimenDeclarado, numeroDeclaracion }).toString());
		}

		if (estaVencidaDSExportacion(declaracionExportacion, (Date) declaracionExportacion.get("FEC_REGIS"), INTERVALO)) {
			result.put("E47", ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70129", new String[] { numSerie, codigoAduana, anioPresentacion, regimenDeclarado, numeroDeclaracion }).toString());
		}
		return result;

		/*
		 * 
		 * //Inicializa el mapa de retorno de errores Map<String,String> result = new HashMap<String,String>(); //Inscribir en el Catalogo F09 los mensaje de error de corresponder if(esDSExportacionLegajada(declaracionExportacion.get("COD_ESTDUA"),true)){ result.add("E43",catalogoAyudaService.getError("E43")); } if(estaVencidaDSExportacion(declaracionExportacion)){ result.add("E47",catalogoAyudaService.getError("E43")); }
		 * 
		 * return result;
		 */
	}

	public Map<String, String> validarReimportacionMercanciasASIGAD(Map<String, Object> polizaDX, String numSerie) {
		// CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		// Inicializa el mapa de retorno de errores
		String codigoAduana = polizaDX.get("CODI_ADUAN").toString(), anioPresentacion = polizaDX.get("ANO_PRESE").toString(), regimenDeclarado = polizaDX.get("REGI_PROCE").toString(), numeroDeclaracion = polizaDX.get("NUME_CORRE").toString();
		Map<String, String> result = new HashMap<String, String>();
		// Obtiene la serie
		Map<String, Object> serieDX = getSeriePrecedenteDS(codigoAduana, anioPresentacion, numeroDeclaracion, numSerie);

		// Inscribir en el Catalogo F09 los mensaje de error de corresponder
		if (esDSExportacionLegajada(polizaDX.get("POLI_ANULA").toString(), false)) {
			result.put("E43", ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70128", new String[] { numSerie, codigoAduana, anioPresentacion, regimenDeclarado, numeroDeclaracion }).toString());
		}
		if (estaVencidaDSExportacion(serieDX, (Date) polizaDX.get("FEC_INGSI"), INTERVALO)) {
			result.put("E47", ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70129", new String[] { numSerie, codigoAduana, anioPresentacion, regimenDeclarado, numeroDeclaracion }).toString());
		}
		/*
		 * if(esDSExportacionLegajada(polizaDX.get("POLI_ANULA"),false)){ result.put("E43",catalogoAyudaService.getError("E43")); } if(estaVencidaDSExportacion(polizaDX)){ result.add("E47",catalogoAyudaService.getError("E43")); }
		 */

		return result;
	}

	public Boolean estaVencidaDSExportacion(Map<String, Object> declaracionExportacion, Date fechaNumeracionDSEER, int intervalo) {
		// El intervalo debe ser 12 meses
		Date fechaEmbarqueDS = (Date) declaracionExportacion.get("FECH_EMBAR");
		Date fechaMaxima = SunatDateUtils.addMonth(fechaEmbarqueDS, intervalo);

		if (SunatDateUtils.esFecha1MayorQueFecha2(fechaMaxima, fechaNumeracionDSEER, SunatDateUtils.COMPARA_SOLO_FECHA))
			return true;
		// DS Exportacion esta vencida
		return false;
	}

	public String getPartidaDSExportacion(Map<String, Object> serieExportacion, Boolean esDeclaracionSDA) {
		return (esDeclaracionSDA ? serieExportacion.get("NUM_PARTNANDI").toString() : serieExportacion.get("PART_NANDI").toString());
	}

	// I. moliveros
	/**
	 * <h1>Cargar par�metros de r�gimen precedente</h1> Se cargan 3 par�metros en sesi�n:
	 * <ul>
	 * <b>existeSerieConRegimenImpo:</b> es de tipo boolean e indica si la DSEER tiene al menos una serie con una DSEER precedente con r�gimen de importaci�n
	 * </ul>
	 * <ul>
	 * <b>existeSerieConRegimenExpo:</b> es de tipo boolean e indica si la DSEER tiene al menos una serie con una DSEER precedente con r�gimen de exportaci�n
	 * </ul>
	 * <ul>
	 * <b>tipoRegimenSeries:</b> indica el tipo de r�gimen de las DSEER precedentes asociadas a las series de la DSEER. Si es null, es porque las series tienen un tipo de reg�menes precedente diferentes, de no ser as� puede tener los siguientes valores:</br>
	 * <ol>
	 * <b>Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION = "01" :</b> Si todas las series tienen r�gimen precedente de exportaci�n
	 * </ol>
	 * <ol>
	 * <b>Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION = "02" :</b> Si todas las series tienen r�gimen precedente de importaci�n
	 * </ol>
	 * </ul>
	 *
	 * @author Miguel Oliveros
	 * @version 1.0
	 * @since 2018/06/04
	 */
	public void setDatosRegimenPrecedente(DUA dua, Map<String, Object> datosDSEER) {
		DatoRegPrecedencia datoRegPrecedente;
		Map<Integer, DUA> duasPrecedentesPorSerie = new HashMap<Integer, DUA>();
		Boolean existeSerieConRegimenImpo = false;
		Boolean existeSerieConRegimenExpo = false;
		Boolean seriesTienenMismaDSEERPrecedente = true;
		String declaracionPrecedente = null;		
		List<String> declaracionesPrecedentesLst = new ArrayList<String>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		for (DatoSerie serie : dua.getListSeries()) {
			if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
				datoRegPrecedente = serie.getListRegPrecedencia().get(0);
				declaracionPrecedente = datoRegPrecedente.getNumdeclpre() + datoRegPrecedente.getAnndeclpre() + datoRegPrecedente.getCodregipre() + datoRegPrecedente.getCodaduapre();
				if (ConstantesDataCatalogo.REGIMEN_EER.equals(datoRegPrecedente.getCodregipre())) {
					existeSerieConRegimenImpo = true;
//					if (!declaracionesPrecedentesLst.contains(declaracionPrecedente))
//						declaracionesPrecedentesLst.add(declaracionPrecedente);
//					if (declaracionesPrecedentesLst.size() > 1) {
//						seriesTienenMismaDSEERPrecedente = false;
//					}
				} else if (!catalogoAyudaService.getElementoGrupo(ConstantesGrupoCatalogo.COD_GRUPO_REGIMEN_PRECEDENTE_DSEER, datoRegPrecedente.getCodregipre()).isEmpty()) {
					existeSerieConRegimenExpo = true;
//					seriesTienenMismaDSEERPrecedente = false;
				}
				if (!declaracionesPrecedentesLst.contains(declaracionPrecedente))
					declaracionesPrecedentesLst.add(declaracionPrecedente);
				
			} else {
				seriesTienenMismaDSEERPrecedente = false;				
			}
		}
		if (declaracionesPrecedentesLst.size() > 1) {
			seriesTienenMismaDSEERPrecedente = false;
		}
		datosDSEER.put("tipoRegimenSeries", !existeSerieConRegimenImpo && !existeSerieConRegimenExpo ? null : existeSerieConRegimenImpo ? Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION : Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION);
		datosDSEER.put("seriesTienenMismaDSEER", seriesTienenMismaDSEERPrecedente);

		if (existeSerieConRegimenExpo || existeSerieConRegimenImpo) { // && !existeSerieConRegimenImpo
			// Vuelve a iterar para setear las duas precedentes
			for (DatoSerie serie : dua.getListSeries()) {
				datoRegPrecedente = (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) ? serie.getListRegPrecedencia().get(0) : null;
				DUA duaPrecedente = null;
				if (datoRegPrecedente != null) {					
					Boolean sonParametrosValidos = sonTodosParametrosPrecedenteValidos(datoRegPrecedente);
					if (sonParametrosValidos) {
						Integer numeroSerie = serie.getNumserie();
						Integer numeroSeriePrecedente = datoRegPrecedente.getNumserpre();
						duaPrecedente = obtenerDeclaracionPrecedenteGral(datoRegPrecedente.getCodregipre(), Integer.parseInt(datoRegPrecedente.getAnndeclpre()), datoRegPrecedente.getNumdeclpre(), datoRegPrecedente.getCodaduapre(), numeroSeriePrecedente);
						duasPrecedentesPorSerie.put(numeroSerie, duaPrecedente);
					}
				}
			}
			// fin lalberti
		}
		datosDSEER.put("duasPrecedentesPorSerie", duasPrecedentesPorSerie);
	}

	@SuppressWarnings("unused")
	@ServicioAnnot(tipo = "V", codServicio = 6534, descServicio = "Valida q las series de la DSEER, deben estar asociadas a la misma DSEER precedente")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100753, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, ?>> validarSeriesMismaDSEER(DatoSerie serie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if ( !seriesTienenMismaDSEER) {			
			String declaracionPrecedenteSerie;
			DatoRegPrecedencia datoRegPrecedente;
			if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
				datoRegPrecedente = serie.getListRegPrecedencia().get(0);
				responseListManager.addResponseMap(catalogoAyudaService.getError("70127", new String[] { serie.getNumserie().toString(), datoRegPrecedente.getCodaduapre() + "-" + datoRegPrecedente.getAnndeclpre() + "-" + datoRegPrecedente.getCodregipre() + "-" + datoRegPrecedente.getNumdeclpre() }));
			}
		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6535, descServicio = "Valida que todas las series deben consignar como r�gimen precedente una DSEER de importaci�n")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 6535, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public List<Map<String, ?>> validarSeriesMismoRegimenPrecedente(String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && !seriesTienenMismaDSEER) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			responseListManager.addResponseMap(catalogoAyudaService.getError("70132"));
		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6537, descServicio = "Validar levante autorizado")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100756, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarLevanteAutorizado(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(1);
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			if (SunatDateUtils.isDefaultDate(dseerPrecedente.getFecAutlevante()))
				responseListManager.addResponseMap(catalogoAyudaService.getError("70125")); // No tiene levante autorizado
		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6538, descServicio = "Validar Precedente con reconocimiento f�sico")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100755, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarCanalSolicitudReconocimiento(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		// cambio: la misma DSEER para todas las series
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(1);
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			if (!ConstantesDataCatalogo.COD_CANAL_ROJO.equals(dseerPrecedente.getCodCanal())) {
				responseListManager.addResponseMap(catalogoAyudaService.getError("70124"));
			}
		}
		return responseListManager.getResponseList();
	}

	// El tipo y n�mero de documento del consignatario de la numeracion debe ser igual que el precedente
	public List<Map<String, ?>> validarConsignatarioDSEERPrecedente(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		// Todas las series estan asociadas a la misma DSEER precedente
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(1);// Primera serie
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			if (!dua.getConsignatario().getTipoDocumentoIdentidad().getCodDatacat().equals(dseerPrecedente.getConsignatario().getTipoDocumentoIdentidad().getCodDatacat()) || !dua.getConsignatario().getNumeroDocumentoIdentidad().equals(dseerPrecedente.getConsignatario().getNumeroDocumentoIdentidad()))
				responseListManager.addResponseMap(catalogoAyudaService.getError("70126"));
		}
		return responseListManager.getResponseList();
	}

	public List<Map<String, ?>> validarIncidencia(Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER) {
			// CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			// DetIncidenciaDAO incidenciaDAO = fabricaDeServicios.getService("diligencia.detIncidenciaDAO");
			// Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
			// DUA dseerPrecedente = duasPrecedentesPorSerie.get(1);
			// paramsIncidencia.put("NUM_CORREDOC", dseerPrecedente.getNumcorredoc());
			// paramsIncidencia.put("COD_INCIDENCIA", new String[]{ ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30" });//CONSIDERAR 30 Bultos vigentes?
			// List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
			// if (incidencia == null || CollectionUtils.isEmpty(incidencia))
			// responseListManager.addResponseMap(catalogoAyudaService.getError("70123"));
		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6540, descServicio = "Validar fecha numeracion")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100757, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarFechaNumeracion(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER, Date fechaReferencia) {
		ResponseListManager responseListManager = new ResponseListManager();
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(1);
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Date fechaAumentadaNumeracionDseerPre = SunatDateUtils.addYear(dseerPrecedente.getFecdeclaracion(), 4);
			if (fechaReferencia.after(fechaAumentadaNumeracionDseerPre))
				responseListManager.addResponseMap(catalogoAyudaService.getError("70122"));
		}
		return responseListManager.getResponseList();
	}
	
	
	private Map<String,DatoFacturaref> getFacturaSerie(DatoSerie serie, List<DatoFacturaref> datoFacturaref) {
		Map<String,DatoFacturaref> facturasSerie = new HashMap<String,DatoFacturaref>();
		for(DatoFacturaref ref: datoFacturaref) {
			for(DatoSerieDocSoporte docSoporte: serie.getListSerieDocSoporte()) {
				if(ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(docSoporte.getCodtipodocsoporte()) && 
						docSoporte.getNumiddocsoporte().equals(ref.getNumsecfactu())) {
					String datosFactura = ref.getCodtipofact()+docSoporte.getNumiddocsoporte()+ref.getNumfactura(); 
					if(!facturasSerie.containsKey(datosFactura))
						facturasSerie.put(datosFactura,ref);
				}					
				
			}
		}
		return facturasSerie;
	}
	

	@ServicioAnnot(tipo = "V", codServicio = 6541, descServicio = "Validar datos de factura")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100758, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarDatosFactura(DUA dua, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {		
		ResponseListManager responseListManager = new ResponseListManager();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER) {
			Elementos<DatoFacturaref> datoFacturaref = dua.getListFacturaRef();			
			for (DatoSerie serie : dua.getListSeries()) {
				DUA dseerPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
				DatoSerie seriePrecedente = dseerPrecedente != null ? (dseerPrecedente.getListSeries() != null ? dseerPrecedente.getListSeries().get(0) : null) : null;
				//Si existe serie precedente se evalua las facturas
				if(seriePrecedente != null) {
					Elementos<DatoFacturaref> datoFacturarefPrecedente = dseerPrecedente.getListFacturaRef();
					Map<String,DatoFacturaref> facturasSerie = getFacturaSerie(serie,datoFacturaref);
					Map<String,DatoFacturaref> facturasSeriePrecedente = getFacturaSerie(seriePrecedente,datoFacturarefPrecedente);
					for(String facturaSerie:facturasSerie.keySet()) {
						DatoFacturaref facturaRef = facturasSerie.get(facturaSerie);
						if(!facturasSeriePrecedente.containsKey(facturaSerie)) {
							responseListManager.addResponseMap(catalogoAyudaService.getError("70133", new String[] { serie.getNumserie().toString(),facturaRef.getNumfactura(), seriePrecedente.getNumserie().toString() }));
						}else {
							//Si contiene la clave tipo y nro verfica la fecha							
							DatoFacturaref facturaRefPrecedente = facturasSeriePrecedente.get(facturaSerie);
							if(!SunatDateUtils.sonIguales(facturaRef.getFecfactura(),facturaRefPrecedente.getFecfactura(),SunatDateUtils.COMPARA_SOLO_FECHA)) {
								responseListManager.addResponseMap(catalogoAyudaService.getError("70188", new String[] {serie.getNumserie().toString(), 
										SunatDateUtils.getFormatDate(facturaRef.getFecfactura(), Constantes.FORMAT_DATE_SHOW), seriePrecedente.getNumserie().toString() }));
							}
							
							
						}
					}
				}
				
			}
		}
		
//		
//		
//		DUA dseerPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
//		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
//			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
////			try {
////				DUA dseerPrecedenteClone = (DUA) BeanUtils.cloneBean(dseerPrecedente);// (DUA)SerializationUtils.clone(dseerPrecedente);
//				boolean existeNro = false;
////				for (DatoSerie serie : dua.getListSeries()) {
//				DatoSerie seriePrecedente = dseerPrecedente != null ? (dseerPrecedente.getListSeries() != null ? dseerPrecedente.getListSeries().get(0) : null) : null;
//				if(seriePrecedente != null) {
////					for (DatoSerie seriePrecedente : dseerPrecedente.getListSeries()) {
////						if (serie.getNumcorredoc().equals(seriePrecedente.getNumcorredoc()) && serie.getNumserie().equals(seriePrecedente.getNumserie())) {
//						List<String> facturasPrecedentes = new ArrayList<String>();
//							for (DatoSerieDocSoporte responseListManager.addResponseMap(catalogoAyudaService.getError("70133", new String[] { facturaPrecedente.getNumdocasoc(), serie.getNumserie() + "" })); : seriePrecedente.getListSerieDocSoporte()) {
//								if(ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(documentoSoporte.getCodtipodocsoporte())) {
//									facturasPrecedentes.add(documentoSoporte.getNumdocasoc());
//								}
//							}								
//								
//							
//							
//							
//							
//								
//								existeNro = false;
//								for (DatoSerieDocSoporte factura : serie.getListSerieDocSoporte()) {
//									if (facturaPrecedente.getCodtipodocsoporte().equals(factura.getCodtipodocsoporte())) {
//										// Se debe cargar todos los datos de factura en las facturas de la serie (nro, fecha y secuencia)
//										if (facturaPrecedente.getNumdocasoc().equals(factura.getNumdocasoc())) {
//											existeNro = true;
//											if (!facturaPrecedente.getFecdocasoc().equals(factura.getFecdocasoc()))
//												responseListManager.addResponseMap(catalogoAyudaService.getError("70133", new String[] { SunatDateUtils.getFormatDate(facturaPrecedente.getFecdocasoc(), FechaBean.FORMATO_DEFAULT), serie.getNumserie() + "" }));
//											break;
//										}
//									}
//								}
//								if (!existeNro)
//									responseListManager.addResponseMap(catalogoAyudaService.getError("70133", new String[] { facturaPrecedente.getNumdocasoc(), serie.getNumserie() + "" }));
////							}
////							dseerPrecedenteClone.getListSeries().remove(seriePrecedente);
////							break;
//						}
//					}
////				}
////			} catch (Exception e) {
////
////			}
////		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6542, descServicio = "Validar peso bruto cantidad de bultos unidades comerciales")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100759, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, ?>> validarPesoBrutoCntBultosUniComerciales(DatoSerie serie, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DatoSerie seriePrecedente = dseerPrecedente != null ? (dseerPrecedente.getListSeries() != null ? dseerPrecedente.getListSeries().get(0) : null) : null;
			if (seriePrecedente != null && serie.getDocumentoTransporte().getNumdoctransporte().equals(seriePrecedente.getNumdoctransporte())) {
				if (serie.getCntbultos().doubleValue() > seriePrecedente.getCntbultos().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70134", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getCntpesobruto().doubleValue() > seriePrecedente.getCntpesobruto().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70135", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getCntunicomer().doubleValue() > seriePrecedente.getCntunicomer().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70136", new String[] { serie.getNumserie() + "" }));
				}
				/*Valida si el tipo de unidad comercial es diferente entre la que se enumera y la precedente.*/
				if (!serie.getCodunicomer().trim().equalsIgnoreCase(seriePrecedente.getCodunicomer().trim())) {
					//responseListManager.addResponseMap(catalogoAyudaService.getError("70136", new String[] { serie.getNumserie() + "" }));
				}
			}
		}
		return responseListManager.getResponseList();
	}

	@ServicioAnnot(tipo = "V", codServicio = 6542, descServicio = "Validar fob seguro ajuste valor aduana")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100760, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, ?>> validarFOBSeguroAjusteValorAduana(DatoSerie serie, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DatoSerie seriePrecedente = dseerPrecedente != null ? (dseerPrecedente.getListSeries() != null ? dseerPrecedente.getListSeries().get(0) : null) : null;
			if (seriePrecedente != null) {
				if (serie.getMtofobdol().doubleValue() > seriePrecedente.getMtofobdol().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70137", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getMtosegdol().doubleValue() > seriePrecedente.getMtosegdol().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70138", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getMtoajuste() != null && serie.getMtoajuste().doubleValue() > seriePrecedente.getMtoajuste().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70139", new String[] { serie.getNumserie() + "" }));
				}
				// Es necesario tener cargado el valor en aduanas tanto en la DSEER transmitida como en la precedente. Valor en aduanas = Mtofobdol + Mtosegdol + Mtoajuste + Mtofledol
				if (serie.getMtovaladuana().doubleValue() > seriePrecedente.getMtovaladuana().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70140", new String[] { serie.getNumserie() + "" }));
				}
			}
		}
		return responseListManager.getResponseList();
	}
	// F. moliveros

	// inicio lalberti numeracion DSEER

	// Solo pueden ser consignadas como regimen precedente los regimenes 28,XC,48,Exporta facil y salida equipaje
	@ServicioAnnot(tipo = "V", codServicio = 100747, descServicio = "Valida q el regimen precedente corresponda al grupo definido ")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100747, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")

	public List<Map<String, String>> esRegimenPrecedenteValido(DatoSerie serie) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
			DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
			if (precedente != null) {
				String codRegimenPrecedente = precedente.getCodregipre();
				Map<String, Object> elementoGrupo = catalogoAyudaService.getElementoGrupo(ConstantesGrupoCatalogo.COD_GRUPO_REGIMEN_PRECEDENTE_DSEER, codRegimenPrecedente);
				if (elementoGrupo.isEmpty())
					errores.add(catalogoAyudaService.getError("70142", new String[] { codRegimenPrecedente }));
			}
		}
		return errores;
	}

	private Boolean sonTodosParametrosPrecedenteValidos(DatoRegPrecedencia precedente) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");	
			Boolean existeAduanaPrecedente = precedente.getCodaduapre() != null ? true : false;
			Boolean existeAnioPrecedente = precedente.getAnndeclpre() != null ? true : false;
			Boolean existeNroPrecedente = precedente.getNumdeclpre() != null ? true : false; 
			Boolean existeSeriePrecedente = precedente.getNumserpre() != null ? true : false;
			String codRegimenPrecedente = precedente.getCodregipre();
			Map<String, Object> elementoGrupo =  catalogoAyudaService.getElementoGrupo(ConstantesGrupoCatalogo.COD_GRUPO_REGIMEN_PRECEDENTE_DSEER, codRegimenPrecedente);
			Boolean esRegimenPermitido = !elementoGrupo.isEmpty();
			
			Boolean[] datosPrecedentes = new Boolean[] { existeAduanaPrecedente, existeAnioPrecedente, existeNroPrecedente, existeSeriePrecedente };
			if (ArrayUtils.contains(datosPrecedentes, true) && esRegimenPermitido) {
				if (!(existeAduanaPrecedente && existeAnioPrecedente && existeNroPrecedente && existeSeriePrecedente)) {
					return false;
				} else
					return true;
			}		

		return false;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100748, descServicio = "Valida que la declaracion consignada como precedente debe de existir")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100748, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")

	public List<Map<String, String>> validarDeclaracionPrecedente(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (ArrayUtils.contains(new String[] { Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION, Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION }, tipoRegimenSeries)) {
			DUA duaPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
			if (duaPrecedente == null && serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
				DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
				String numPrecedente = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
				errores.add(catalogoAyudaService.getError("70143", new String[] { numPrecedente }));
			}
		}

		return errores;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100749, descServicio = "Valida que la serie precedente consignada debe de existir")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100749, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")

	public List<Map<String, String>> validarSeriePrecedente(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (ArrayUtils.contains(new String[] { Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION, Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION }, tipoRegimenSeries)) {
			DUA duaPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
			// Solo lleno la serie precedente por lo que siempre la longitud de la lista es a lo mas 1
			DatoSerie seriePrecedente = duaPrecedente != null ? (duaPrecedente.getListSeries() != null && !duaPrecedente.getListSeries().isEmpty() ? duaPrecedente.getListSeries().get(0) : null) : null;
			if (seriePrecedente == null && serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
				DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
				String numPrecedente = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
				errores.add(catalogoAyudaService.getError("70166", new String[] { serie.getNumserie().toString(), precedente.getNumserpre().toString(), numPrecedente }));
			}
		}

		return errores;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100750, descServicio = "Valida que la serie precedente consignada tenga r�gimen de exportacion")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100750, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")

	public List<Map<String, String>> validarSeriePrecedenteExportacion(DatoSerie serie, String tipoRegimenSeries) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
			DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
			String codRegimenPrecedente = precedente.getCodregipre();
			Map<String, Object> elementoGrupo = catalogoAyudaService.getElementoGrupo(ConstantesGrupoCatalogo.COD_GRUPO_REGIMEN_PRECEDENTE_EXPORTACION_DSEER, codRegimenPrecedente);
			// La serie tiene regimen precedente de expo pero alguna de las otras series tiene otro regimen
			if (!elementoGrupo.isEmpty() && (tipoRegimenSeries == null))
				errores.add(catalogoAyudaService.getError("70144", new String[] { serie.getNumserie().toString(), codRegimenPrecedente }));
		}
		return errores;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100767, descServicio = "Valida que la cantidad total de unidades f�sicas reimportadas no debe ser superior a la cantidad total de unidades f�sicas exportadas")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" }) 
	@OrquestaDespaAnnot(codServInstancia = 100767, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> validarCantidadUnidadesFisicasReimportadas(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA declaracionPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
		if (declaracionPrecedente != null && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
			Long numCorredoc = getNumCorredocSIGADFromSDA(serie.getListRegPrecedencia().get(0));
			DatoSerie seriePrecedente = declaracionPrecedente != null ? (declaracionPrecedente.getListSeries() != null ? declaracionPrecedente.getListSeries().get(0) : null) : null;
			if(seriePrecedente != null) {			
				DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
				String numeroDeclaracionPrecedente = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
				BigDecimal cantidadUnidadesFisicasReimportadas = serie.getCntunifis();
				// Existe la declaracion en el SDA
				if (numCorredoc != null) {
					// Busca los saldos de las unidades fisicas en la tabla ctacte_regimen
					CabCtacteRegimenDAO ctacteRegimenDAO = fabricaDeServicios.getService("declaracion.cabCtaCteRegimen");
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("numCorredoc", numCorredoc);
					params.put("numSerie", declaracionPrecedente.getListSeries().get(0).getNumserie());
					CabCtacteRegimen resultCtaCte = ctacteRegimenDAO.selectByKeyMap(params);
					if (resultCtaCte != null && resultCtaCte.getCntSaldoUnidad().compareTo(cantidadUnidadesFisicasReimportadas) < 0) {
						errores.add(catalogoAyudaService.getError("70155", new String[] { serie.getNumserie().toString(), seriePrecedente.getNumserie().toString(), numeroDeclaracionPrecedente }));
					}
				} // primera vez valida contra la poliza no existe en el SDA
				else {
					BigDecimal cantidadUnidadesFisicasPrecedente = seriePrecedente.getCntunifis();
					if (cantidadUnidadesFisicasPrecedente.compareTo(cantidadUnidadesFisicasReimportadas) < 0) {
						errores.add(catalogoAyudaService.getError("70155", new String[] { serie.getNumserie().toString(), seriePrecedente.getNumserie().toString(), numeroDeclaracionPrecedente }));
	}
				}
			}
		}
		return errores;
	}
	//Servicio solo para la 0442
	@ServicioAnnot(tipo = "V", codServicio = 101168, descServicio = "Valida que la cantidad total de unidades f�sicas reimportadas no debe ser superior a la cantidad total de unidades f�sicas exportadas en MDEER")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 101168, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> validarCantidadUnidadesFisicasReimportadasEnMdeer(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		CabCtacteRegimenDAO ctacteRegimenDAO = fabricaDeServicios.getService("declaracion.cabCtaCteRegimen");

		Map<String, DatoDeclaracionPrecedenteEER> datosDeclaracionesPrecedentes = ((ManifiestoDesconsolidadoEER)((serie.getPadre()).getPadre()).getPadre()).getDatosDeclaracionesPrecedentes();
		DUA declaracionPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());

		if (declaracionPrecedente != null && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
			DatoSerie seriePrecedente = declaracionPrecedente != null ? (declaracionPrecedente.getListSeries() != null ? declaracionPrecedente.getListSeries().get(0) : null) : null;
			if(seriePrecedente == null)
				return errores;

			Long numCorredoc = getNumCorredocSIGADFromSDA(serie.getListRegPrecedencia().get(0));
			DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
			String numeroDeclaracionPrecedente = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
			BigDecimal cantidadUnidadesFisicasReimportadas = serie.getCntunifis();
			BigDecimal saldoAConsumir;

			DatoDeclaracionPrecedenteEER datoDeclaracionPrecedenteEER = datosDeclaracionesPrecedentes!=null?datosDeclaracionesPrecedentes.get(seriePrecedente.getNumserie().toString()):null;
			if(datoDeclaracionPrecedenteEER != null){
				saldoAConsumir = datoDeclaracionPrecedenteEER.getSaldoPrecedente();
			}else {
				if(datosDeclaracionesPrecedentes==null)
					datosDeclaracionesPrecedentes = new HashMap<String, DatoDeclaracionPrecedenteEER>();
				datoDeclaracionPrecedenteEER= new DatoDeclaracionPrecedenteEER();
				if (numCorredoc != null) {
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("numCorredoc", numCorredoc);
					params.put("numSerie", declaracionPrecedente.getListSeries().get(0).getNumserie());
					CabCtacteRegimen resultCtaCte = ctacteRegimenDAO.selectByKeyMap(params);
					saldoAConsumir = resultCtaCte.getCntSaldoUnidad();

				}
				else
					saldoAConsumir = seriePrecedente.getCntunifis();
			}
			if (saldoAConsumir.compareTo(cantidadUnidadesFisicasReimportadas) < 0) {
				//No hay saldo suficiente
				errores.add(catalogoAyudaService.getError("70155", new String[] { serie.getNumserie().toString(), seriePrecedente.getNumserie().toString(), numeroDeclaracionPrecedente }));
			}else {
				datoDeclaracionPrecedenteEER.setSaldoPrecedente(saldoAConsumir.subtract(cantidadUnidadesFisicasReimportadas));
				//reemplaza el mapa original con el nuevo con el saldo actualizado
				datosDeclaracionesPrecedentes.put(seriePrecedente.getNumserie().toString(), datoDeclaracionPrecedenteEER);
				((ManifiestoDesconsolidadoEER)((serie.getPadre()).getPadre()).getPadre()).setDatosDeclaracionesPrecedentes(datosDeclaracionesPrecedentes);
			}

		}

		return errores;

	}

	@ServicioAnnot(tipo = "V", codServicio = 101170, descServicio = "Validar peso bruto cantidad de bultos unidades comerciales en mdeer")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 101170, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, ?>> validarPesoBrutoCntBultosUniComercialesEnMDEER(DatoSerie serie, Map<Integer, DUA> duasPrecedentesPorSerie, String tipoRegimenSeries, Boolean seriesTienenMismaDSEER) {
		ResponseListManager responseListManager = new ResponseListManager();
		DUA dseerPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
		String numeroGuiaMdeer = serie.getDocumentoTransporte().getNumdoctransporte();
		if (Constantes.COD_REGIMEN_PRECEDENTE_DSEER_IMPORTACION.equals(tipoRegimenSeries) && seriesTienenMismaDSEER && dseerPrecedente != null) {
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DatoSerie seriePrecedente = dseerPrecedente != null ? (dseerPrecedente.getListSeries() != null ? dseerPrecedente.getListSeries().get(0) : null) : null;
			if (seriePrecedente != null && serie.getDocumentoTransporte().getNumdoctransporte().equals(seriePrecedente.getNumdoctransporte())) {
				//Se a�ade el if porque en el F2 indica  "Cuando se trate del mismo n�mero de gu�a"
				String guiaSeriePrecedente = seriePrecedente.getDocumentoTransporte().getNumdoctransporte();
				if(!guiaSeriePrecedente.equals(numeroGuiaMdeer))
					return responseListManager.getResponseList();

				if (serie.getCntbultos().doubleValue() > seriePrecedente.getCntbultos().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70134", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getCntpesobruto().doubleValue() > seriePrecedente.getCntpesobruto().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70135", new String[] { serie.getNumserie() + "" }));
				}
				if (serie.getCntunicomer().doubleValue() > seriePrecedente.getCntunicomer().doubleValue()) {
					responseListManager.addResponseMap(catalogoAyudaService.getError("70136", new String[] { serie.getNumserie() + "" }));
				}
				/*Valida si el tipo de unidad comercial es diferente entre la que se enumera y la precedente.*/
				if (!serie.getCodunicomer().trim().equalsIgnoreCase(seriePrecedente.getCodunicomer().trim())) {
					//responseListManager.addResponseMap(catalogoAyudaService.getError("70136", new String[] { serie.getNumserie() + "" }));
				}
			}
		}
		return responseListManager.getResponseList();
	}


	private Long getNumCorredocSIGADFromSDA(DatoRegPrecedencia declaracionPrecedente) {
		AsocdocudamDAO asocDocuDamDAO = fabricaDeServicios.getService("eer.asocdocudamDAOLectura");
		Asocdocudam beanAsocDocuDam = new Asocdocudam();
		beanAsocDocuDam.setAnnPresenAsigad(SunatNumberUtils.getIntegerFromString(declaracionPrecedente.getAnndeclpre()));
		beanAsocDocuDam.setCodAduanaAsigad(declaracionPrecedente.getCodaduapre());
		beanAsocDocuDam.setCodRegimenAsigad(declaracionPrecedente.getCodregipre());
		beanAsocDocuDam.setNumDeclaracionAsigad(SunatNumberUtils.getLongFromString(declaracionPrecedente.getNumdeclpre()));
		Asocdocudam result = asocDocuDamDAO.getByDeclaracion(beanAsocDocuDam);
		if (result != null)
			return result.getNumeroCorrelativo();
		return null;

	}

	private Boolean esAduanaPrecedenteValida(String codAduana) {
		CatalogoValidaService catalogoValidaService = fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		List<Map<String, String>> result = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_ADUANAS, codAduana, new Date());
		if (!result.isEmpty())
			return false;
		return true;
	}

	private DUA obtenerDeclaracionPrecedenteGral(String regimenPrecedente, Integer anioPrecedente, String nroPrecedente, String aduanaPrecedente, Integer numeroSerie) {
		// Valida que la aduana sea correcta
		if (!esAduanaPrecedenteValida(aduanaPrecedente))
			return null;

		DUA duaPrecedente = getDeclaracionPrecedenteSDA(aduanaPrecedente, nroPrecedente, anioPrecedente, regimenPrecedente);

		if (duaPrecedente != null) {
			Elementos<DatoSerie> lstSeries = duaPrecedente.getListSeries();
			DatoSerie seriePrecedente = null;
			if(lstSeries.isEmpty()) {
				Long numCorredoc = duaPrecedente.getNumcorredoc();
				seriePrecedente = obtenerSeriePrecedenteSDA(numCorredoc, numeroSerie);				
			}else {
				for(DatoSerie serie:lstSeries) {
					if(serie.getNumserie().equals(numeroSerie)) {
						seriePrecedente = new DatoSerie();
						lstSeries = new Elementos<DatoSerie>();
						seriePrecedente = serie;
						break;
					}
				}
			}
			if (seriePrecedente != null) {					
				lstSeries.add(seriePrecedente);
				duaPrecedente.setListSeries(lstSeries);
			}else{
				duaPrecedente.setListSeries(null);
			}
		} else {
			duaPrecedente = getDeclaracionPrecedenteSIGAD(aduanaPrecedente, nroPrecedente, anioPrecedente, regimenPrecedente);
			DatoSerie seriePrecedente = obtenerSeriePrecedenteSIGAD(aduanaPrecedente, nroPrecedente, anioPrecedente, regimenPrecedente, numeroSerie);
			if (seriePrecedente != null) {
				Elementos<DatoSerie> datosSerie = new Elementos<DatoSerie>();
				datosSerie.add(seriePrecedente);
				duaPrecedente.setListSeries(datosSerie);
			}
		}

		return duaPrecedente;
	}

	private DatoSerie obtenerSeriePrecedenteSIGAD(String aduanaPrecedente, String nroPrecedente, Integer anioPrecedente, String regimenPrecedente, Integer numeroSerie) {
			DAMOperativaConsultaService damOperativaConsulta = (DAMOperativaConsultaService) fabricaDeServicios.getService("ingresos.DAMOperativaConsultaService");
		DatoSerie serie = damOperativaConsulta.ObtenerSerieFromDAMOperativa(aduanaPrecedente, regimenPrecedente, anioPrecedente, nroPrecedente, numeroSerie.toString());
		return serie;
	}

	private DatoSerie obtenerSeriePrecedenteSDA(Long numCorredoc, Integer numeroSerie) {
		DatoSerie serie = null;
		DetDeclaraDAO detDeclaraDAO = (DetDeclaraDAO) fabricaDeServicios.getService("detDeclaraDAO");
		Map<String, Object> parametrosBusqueda = new HashMap<String, Object>();
		parametrosBusqueda.put("numcorredoc", numCorredoc);
		parametrosBusqueda.put("numsecserie", numeroSerie);
		List<DatoSerie> result = detDeclaraDAO.findSerieByMap(parametrosBusqueda);
		if (!result.isEmpty())
			serie = result.get(0);
		return serie;
	}

	private DUA getDeclaracionPrecedenteSDA(String codigoAduana, String numeroDeclaracion, Integer anioPresentacion, String regimenPrecedente) {
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> parametrosBusqueda = new HashMap<String, Object>();
		parametrosBusqueda.put("codigoAduana", codigoAduana);
		parametrosBusqueda.put("annoPresentacion", anioPresentacion.toString());
		parametrosBusqueda.put("numeroDeclaracion", numeroDeclaracion);
		parametrosBusqueda.put("codigoRegimen", regimenPrecedente);
		DUA duaPrecedente = cabDeclaraDAO.findDUAByMap(parametrosBusqueda);
		if (duaPrecedente != null) {
			GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
			duaPrecedente = getDeclaracionService.getDUA(parametrosBusqueda);
			
			ParticipanteDocDAO participanteDao = fabricaDeServicios.getService("despaduanero2.participanteDocDAO");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numeroCorrelativo", duaPrecedente.getNumcorredoc());
			params.put("codTipoParticipante", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
			List<Participante> consignatario = participanteDao.findParticipantesByMap(params);
			duaPrecedente.setConsignatario(consignatario != null ? consignatario.get(0) : new Participante());
		}
		//Adiciona los datos de la factura
		return duaPrecedente;
	}

	private DUA getDeclaracionPrecedenteSIGAD(String codigoAduana, String numeroDeclaracion, Integer anioPresentacion, String regimenPrecedente) {
		DAMOperativaConsultaService damOperativaConsulta = fabricaDeServicios.getService("ingresos.DAMOperativaConsultaService");
		DUA duaPrecedente = getDeclaracionPrecedenteSDA(codigoAduana, numeroDeclaracion, anioPresentacion, regimenPrecedente);
		if (duaPrecedente == null) {
			duaPrecedente = damOperativaConsulta.ObtenerDAMOperativa(codigoAduana, regimenPrecedente, anioPresentacion, numeroDeclaracion);
		}
		return duaPrecedente;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100751, descServicio = "Valida que la declaracion precedente de exportacion no este legajada")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 100751, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> esDUAPrecedenteLegajada(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
			DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
			if (Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
				DUA duaPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
				String codEstDuaPrecedente = duaPrecedente != null ? duaPrecedente.getCodEstdua() : null;
				if (ConstantesDataCatalogo.COD_DUA_LEGAJADA.equals(codEstDuaPrecedente)) {
					String numDeclaracion = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
					errores.add(catalogoAyudaService.getError("70145", new String[] { serie.getNumserie().toString(), numDeclaracion }));
				}

			}
		}
		return errores;
	}

	@ServicioAnnot(tipo = "V", codServicio = 100752, descServicio = "Valida que la fecha de vencimiento de la " + "declaracion precedente de exportacion sea menor a la de numeracion")
	@ServInstDetAnnot(tipoRpta = { 0, 1, 1, 0 }, nomAtr = { "this,tipoRegimenSeries,duasPrecedentesPorSerie,fechaProceso" })
	@OrquestaDespaAnnot(codServInstancia = 100752, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> esDUAPrecedenteVencida(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie, Date fechaReferencia) {
		List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
			DatoRegPrecedencia precedente = serie.getListRegPrecedencia().get(0);
			if (Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
				DUA duaPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
				Date fechaEmbarqueDS = duaPrecedente != null ? duaPrecedente.getFecEmbarque() : null;
				if (fechaEmbarqueDS != null) {
					Date fechaMaxima = SunatDateUtils.addMonth(fechaEmbarqueDS, Constantes.INTERVALO_VENCIMIENTO);
					if (SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia, fechaMaxima, SunatDateUtils.COMPARA_SOLO_FECHA)) {
						String numDeclaracion = precedente.getCodaduapre() + "-" + precedente.getAnndeclpre() + "-" + precedente.getCodregipre() + "-" + precedente.getNumdeclpre();
						errores.add(catalogoAyudaService.getError("70146", new String[] { serie.getNumserie().toString(), numDeclaracion }));
					}
				}
			}
		}
		return errores;
	}

	/**
	 * {@inheritDoc}
	 */
	@Deprecated
	public List<Map<String, String>> setDatosAdicionalRegimenPrecedente (Declaracion declaracion, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie) {
		// hsaenz PAS20181U220400008 - P_SNAA0004-9559 - P_SNAA0004-9540: Obtener algunos datos adicionales del regimen precedente
		List<Map<String, String>> lstErrores = new ArrayList<Map<String, String>>();
		for (DatoSerie serie: declaracion.getDua().getListSeries()) {
			setPartidaNandinaPrecedente(serie, tipoRegimenSeries, duasPrecedentesPorSerie, lstErrores);
			setUnidadesFisicasPrecedente(serie, tipoRegimenSeries, duasPrecedentesPorSerie, lstErrores);
		}
			
		return lstErrores;
	}

	// Metodos de seteo de variables
	public void setPartidaNandinaPrecedente(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentes, List<Map<String, String>> lstErrores) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
			DUA duaPrecedente = duasPrecedentes.get(serie.getNumserie());
			if (duaPrecedente != null && (duaPrecedente.getListSeries() != null && !duaPrecedente.getListSeries().isEmpty())) {
				DatoSerie seriePrecedente = duaPrecedente.getListSeries().get(0); // Traera la serie precedente solamente
				if (seriePrecedente != null) {
					if(!serie.getNumpartnandi().equals(seriePrecedente.getNumpartnandi())){
						//serie.setNumpartnandi(seriePrecedente.getNumpartnandi()); // comparar si son iguales lanza un error. el numpartnandi.
						lstErrores.add(catalogoAyudaService.getError("70191", new String[] {serie.getNumserie().toString(), Long.toString(serie.getNumpartnandi()), Long.toString(seriePrecedente.getNumpartnandi()) }));
					}
				}
			}
				
		}
	}

	public void setUnidadesFisicasPrecedente(DatoSerie serie, String tipoRegimenSeries, Map<Integer, DUA> duasPrecedentesPorSerie, List<Map<String, String>> lstErrores) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenSeries)) {
			DUA duaPrecedente = duasPrecedentesPorSerie.get(serie.getNumserie());
			if (duaPrecedente != null && (duaPrecedente.getListSeries() != null && !duaPrecedente.getListSeries().isEmpty())) {
				if (serie.getListRegPrecedencia() != null && !serie.getListRegPrecedencia().isEmpty()) {
					DatoSerie seriePrecedente = duaPrecedente.getListSeries().get(0); // Traera la serie precedente solamente
					//serie.setCntunicomer(seriePrecedente.getCntunicomer());
					if(!serie.getCodunifis().equals(seriePrecedente.getCodunifis())){
						lstErrores.add(catalogoAyudaService.getError("70190", new String[] {serie.getNumserie().toString(), Long.toString(serie.getNumpartnandi()), Long.toString(seriePrecedente.getNumpartnandi()) }));						
					}
					//serie.setCodunifis(seriePrecedente.getCodunifis()); // comparar en entre cod de unid fisicas
				}
			}
		}
	}
	// fin lalberti
}