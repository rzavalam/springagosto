package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.envioparcial;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;

public class ValEnvioParcialEERServiceImpl extends IngresoAbstractServiceImpl implements ValEnvioParcialEERService {
	public List<Map<String, ?>> valIndicadorEnvioParcial(DUA dua){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ResponseListManager responseListManager = new ResponseListManager();
		if(!ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(dua.getCategoria().getCodDatacat()) && dua.getListIndicadores() != null && !dua.getListIndicadores().isEmpty()) {
			for(DatoIndicadores indicador : dua.getListIndicadores())
				if(indicador.getCodigoIndicador().equals(ConstantesDataCatalogo.CODIGO_INDICADOR_EER_ENVIO_PARCIAL)) {
					//70130: �SOLO SE ENVIA EL INDICADOR DE ENVIO PARCIAL PARA DSEER DE CATEGORIA 3�
					responseListManager.addResponseMap(catalogoAyudaService.getError("70130"));	
					return responseListManager.getResponseList();
				}
		}
		return responseListManager.getResponseList();
	}
}
