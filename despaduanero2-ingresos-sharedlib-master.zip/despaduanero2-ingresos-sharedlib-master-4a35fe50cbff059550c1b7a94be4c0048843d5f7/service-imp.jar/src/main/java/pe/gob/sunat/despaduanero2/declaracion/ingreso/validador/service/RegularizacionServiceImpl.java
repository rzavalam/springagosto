package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;

@Deprecated
public class RegularizacionServiceImpl extends ValDuaAbstract implements RegularizacionService {

//	protected final Log log = LogFactory.getLog(getClass());
//	private IndicadorDUADAO indicadorDUADAO;
//	private FormBProveedorDAO formBProveedorDAO;
//	private CabManifiestoDAO manifiestoDAO;
//	private CabDiligenciaDAO cabDiligenciaDAO;
//	private CabDeclaraDAO cabDeclaraDAO;
//	private LiquidaDeclaracionService  liquidaDeclaracionService;
//	private DiasUtilesDAO diasUtilesDAO;
//	private CatalogoHelperImpl catalogoHelper;  
//	private static RegularizacionServiceImpl instance;
//  
//
//		private RegularizacionServiceImpl() {
//		}
//		
//		public static RegularizacionServiceImpl getInstance() {
//			if(instance == null )
//			{
//				instance = new RegularizacionServiceImpl();
//
//			}
//			
//			return instance;
//		}  
//
//
//
//	public IndicadorDUADAO getIndicadorDUADAO() {
//		return indicadorDUADAO;
//	}
//	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
//		this.indicadorDUADAO = indicadorDUADAO;
//	}
//	
//		public LiquidaDeclaracionService getLiquidaDeclaracionService() {
//			return liquidaDeclaracionService;
//		}
//
//		public void setLiquidaDeclaracionService(
//				LiquidaDeclaracionService liquidaDeclaracionService) {
//			this.liquidaDeclaracionService = liquidaDeclaracionService;
//		}
//
//		public CatalogoHelperImpl getCatalogoHelper() {
//			return catalogoHelper;
//		}
//
//		public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
//			this.catalogoHelper = catalogoHelper;
//		}
//	public FormBProveedorDAO getFormBProveedorDAO() {
//		return formBProveedorDAO;
//	}
//	public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
//		this.formBProveedorDAO = formBProveedorDAO;
//	}
//	public CabManifiestoDAO getManifiestoDAO() {
//		return manifiestoDAO;
//	}
//	public void setManifiestoDAO(CabManifiestoDAO manifiestoDAO) {
//		this.manifiestoDAO = manifiestoDAO;
//	}
//	public CabDiligenciaDAO getCabDiligenciaDAO() {
//		return cabDiligenciaDAO;
//	}
//	public void setCabDiligenciaDAO(CabDiligenciaDAO cabDiligenciaDAO) {
//		this.cabDiligenciaDAO = cabDiligenciaDAO;
//	}
//	public CabDeclaraDAO getCabDeclaraDAO() {
//		return cabDeclaraDAO;
//	}
//	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
//		this.cabDeclaraDAO = cabDeclaraDAO;
//	}
//
//	public DiasUtilesDAO getDiasUtilesDAO() {
//		return diasUtilesDAO;
//	}
//
//	public void setDiasUtilesDAO(DiasUtilesDAO diasUtilesDAO) {
//		this.diasUtilesDAO = diasUtilesDAO;
//	}

}
