package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorComputoAbstract extends ValidadorAbstract
{

  private final static String ASOC_PARTIDA_NOMBRE  = "024";
  private final static String COD_UNIDAD_COMERCIAL = "U";
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    // TODO Auto-generated method stub
    return null;
  }
  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract object, DatoItem item){
	  List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
	  String datoAValidar = item.getCodunidcomer();
	  Object[] demasArgumentosMSJError = new Object[] { 
	    		object.getNumsecprove(),
	    		object.getNumsecfact(),
	    		object.getNumsecitem(),
	    		"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
	  if(!SunatStringUtils.isEqualTo(datoAValidar, COD_UNIDAD_COMERCIAL)){
		  ErrorDescrMinima err = obtenerError("31475",
	  				 ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
		  lst.add(err);
	  }
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object, DatoItem item, Date fechaVigencia){
	  List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
	  ComputoAbstract computo = (ComputoAbstract) object;
	  String datoAValidar = computo.getNombreComercial().getValtipdescri();
	  String partida = item.getNumpartnandi().toString();
	  /*if(noEstaCorrelacionado(partida, datoAValidar, ASOC_PARTIDA_NOMBRE)){
		  String[]args = new String[]{partida};
		  lst.add(obtenerError("31474", computo.getNombreComercial(),args));
	  }*/
	  if(noEstaCorrelacionado(partida, datoAValidar, ASOC_PARTIDA_NOMBRE, fechaVigencia)){
		  String[]args = new String[]{partida};
		  lst.add(obtenerError("31474", computo.getNombreComercial(),args));
	  }
	  
	  return lst;
  }
  
  public List<ErrorDescrMinima>  validarMarcaComercial(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }

}
