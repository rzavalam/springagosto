package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.target.HotSwappableTargetSource;

import pe.gob.sunat.despaduanero2.ayudas.model.dao.CircunoceDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;


public class ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente extends ValidarPuntoLlegadaMercaderiaAbstract implements ValidadorPuntoLlegadaMercancia {

	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE = { "1", "2", "3","9" };
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO  = { "1", "2", "3", "4", "9" };
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO_EER  = { "1", "2", "3", "4", "9",ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};//PAS20181U220200049
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO__URGENTE_EER  = {ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};
//RIN05 PAS20181U220200004 MORDONEZL
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_MANIFIESTOFLUVIALYTERRESTRE = { "1","3","2","14" ,"9"};
	// estos valores se tiene que llenar en el contructor de la clase
	private String codigoLugarDescarga = null;
	private String codigoPuntoLLegadaMercancia = null;
	private String regimen = null;
	private String codigoAduanaTransmision = null;
	//numero de ruc del deposito
	private String numeroRUCdeposito = null;
	//numero de ruc del lugar de descarga
	private String numeroRUCpuntoLlegada = null;
	private Elementos<DatoSerie> listSeries;
	private String annManifiesto = null;
	private String codModTranspo= null;
	private String numManifiesto= null;
	private List<DatoDocTransporte> lstdocumentostrans = null;
	private boolean esManifiestoEerSda;//PAS20181U220200049
	private boolean esManifiestoEerSigad;//PASE64
	//private McdetaDAO mcdetaDAO=null;
	//mordonezl 
	//private String codLocalAnexo = null;
	//numero de ruc del due�o consignatario importador
	//private String numeroRUCduenioConsignatario = null;
	//private String codTipoDocIdent = null;
	//private String codigoTransaccion = null;
	
	//private FabricaDeServicios fabricaDeServicios;	
	
	public ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente(){
		super();
	}
	
	public ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente(
			//codigo de la aduana
			String codigoAduanaTransmision,
			//codigo del regimen
			String regimen,
			//lista de series para poder obtener los regimenes de precedencia
			Elementos<DatoSerie> listSeries,
			// codigo del lugar de recpcion
			String codigoLugarDescarga,
			//codigo del punto de llegada
			String codigoPuntoLLegadaMercancia,
			//numero de ruc del lugar de descarga
			String numeroRUCpuntoLlegada,
			//numero de ruc del deposito			
			String numeroRUCdeposito,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO mcdetaDAO,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			ManifiestoSigadService manifiestoSigadService,	
			CircunoceDAO circunoceDAO,
			String codigoTransaccion) //RIN 13-619)
	{
		
		//codigo de la aduana
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		//codigo del regimen
		this.regimen =regimen;
		//regimen precedente
		this.listSeries = listSeries;
		// codigo del lugar de recpcion
		this.codigoLugarDescarga = codigoLugarDescarga;
		//codigo del punto de llegada
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		//numero de ruc del lugar de descarga
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
		//numero de ruc del deposito			
		this.numeroRUCdeposito = numeroRUCdeposito;
		this.fechaReferencia = fechaReferencia;
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		//this.codigoTransaccion=codigoTransaccion;
	}
	
	//PAS20181U220200049
	public ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente(
			//codigo de la aduana
			String codigoAduanaTransmision,
			//codigo del regimen
			String regimen,
			//lista de series para poder obtener los regimenes de precedencia
			Elementos<DatoSerie> listSeries,
			// codigo del lugar de recpcion
			String codigoLugarDescarga,
			//codigo del punto de llegada
			String codigoPuntoLLegadaMercancia,
			//numero de ruc del lugar de descarga
			String numeroRUCpuntoLlegada,
			//numero de ruc del deposito			
			String numeroRUCdeposito,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO mcdetaDAO,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			ManifiestoSigadService manifiestoSigadService,	
			CircunoceDAO circunoceDAO,
			String codigoTransaccion,
			boolean esManifiestoEerSda,
			boolean esManifiestoEerSigad) //RIN 13-619)
	{
		
		//codigo de la aduana
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		//codigo del regimen
		this.regimen =regimen;
		//regimen precedente
		this.listSeries = listSeries;
		// codigo del lugar de recpcion
		this.codigoLugarDescarga = codigoLugarDescarga;
		//codigo del punto de llegada
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		//numero de ruc del lugar de descarga
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
		//numero de ruc del deposito			
		this.numeroRUCdeposito = numeroRUCdeposito;
		this.fechaReferencia = fechaReferencia;
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		this.esManifiestoEerSda = esManifiestoEerSda;
		//this.codigoTransaccion=codigoTransaccion;
		this.esManifiestoEerSigad = esManifiestoEerSigad;
	}	
	
	public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
		validarPuntoLlegada();
	}

	private void validarPuntoLlegada() throws PuntoLLegadaValidadorException {
		/*RIN13INSI-FIN*/
		boolean esValidoCodigoLugarDescarga =  false;
		 String[] puntosLLegadaPorTipoLugarDescarga = null;
		
		//PAS20181U220200049
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);		 
		 
		if(codigoLugarDescarga != null && !SunatStringUtils.isEmpty(codigoLugarDescarga)){
			throw new PuntoLLegadaValidadorException("30551","PARA DESPACHOS URGENTES NO DEBE DECLARAR EL CAMPO TIPO DE LUGAR DE DESCARGA");
		}
		if(StringUtils.isBlank(codigoPuntoLLegadaMercancia)){
			throw new PuntoLLegadaValidadorException("30552","PARA DESPACHOS URGENTES DEBE DECLARAR EL CAMPO TIPO DE PUNTO DE LLEGADA");
		}
		
		//RIN12 RN1778

		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
//PAS20181U220200064
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		boolean considerarValoresCat227 = false;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			considerarValoresCat227 = true;
		}
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
	    boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;		
		String codigoErrorEER ="";
		if (SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){
			if (!MapaValManNum.isEmpty()){//PAS20181U220200049
				if(esManifiestoEerSda){ //Si es el EER-SDA y mando manifiesto
					puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO__URGENTE_EER;
					codigoErrorEER = "70151";
				}
				else {
					if(numManifiesto == null)//si no hay numero de manifiesto
						puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO_EER;
					else {
						puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO;
						 if(esManifiestoEerSigad) {puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO__URGENTE_EER;}
						if(!esManifiestoEerSigad && ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR.equals(codigoPuntoLLegadaMercancia)) {//PAS20181U220200064
						codigoErrorEER = "70375";
					}
				}
			}
			}
			else {
				puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO;
			}
			//esValidoCodigoLugarDescarga = ArrayUtils.contains(PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_AEREO ,codigoPuntoLLegadaMercancia)?true:false;
		} else if (SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_EER)){
		//} else if (SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_EER) || ()){ A modificar con pase PAS20181U220200049
			puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO__URGENTE_EER;
			//esValidoCodigoLugarDescarga = ArrayUtils.contains(PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO__URGENTE_EER, codigoPuntoLLegadaMercancia)?true:false;
		}  
		else if (/*MapaValManNum.isEmpty() &&*/ esVigenteRIN05 && 
				( (!considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL,
						 ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE}, codModTranspo)))
					|| 	
				  (considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE,
						ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE}, codModTranspo) )) )){
				//(SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL) ||  SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO) || SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE))){
			
			puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE_MANIFIESTOFLUVIALYTERRESTRE; 
			
		} 
		else{
			puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE;
			//esValidoCodigoLugarDescarga = ArrayUtils.contains(PUNTOS_LLEGADA_MERCANCIA_PARA_DESCARGA_PUNTO_LLEGADA_DESPACHO_URGENTE ,codigoPuntoLLegadaMercancia)?true:false;
		}
		esValidoCodigoLugarDescarga = ArrayUtils.contains(puntosLLegadaPorTipoLugarDescarga ,codigoPuntoLLegadaMercancia)?true:false;
		if(!esValidoCodigoLugarDescarga){
			if(!codigoErrorEER.isEmpty()) {
				throw new PuntoLLegadaValidadorException(codigoErrorEER,new String[]{codigoPuntoLLegadaMercancia},"");//PAS20181U220200049
			}else {
				throw new PuntoLLegadaValidadorException("30553",new String[]{codigoPuntoLLegadaMercancia, Arrays.toString(puntosLLegadaPorTipoLugarDescarga)},"PARA DESPACHOS URGENTES DEBE DECLARAR EL CAMPO TIPO DE PUNTO DE LLEGADA VALIDO");
			}
		}
		
		validarNumeroRUCpuntoLlegada();
		
		validarTipoLugarDescargaPorRegimen(regimen, numeroRUCdeposito, fechaReferencia, codigoAduanaTransmision);
		
		validarRegimenPrecedente(regimen);
	}
	
	
	private void validarNumeroRUCpuntoLlegada() throws PuntoLLegadaValidadorException {
		PuntoLlegadaValidador puntoLlegadaValidador = tipoPuntoLlegadaValidadorBuilder(codigoPuntoLLegadaMercancia);
		puntoLlegadaValidador.validar( fechaReferencia, codigoAduanaTransmision);
	}
	
	/**
	 * Valida el regimen d precedencia de las series
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(String regimen) throws PuntoLLegadaValidadorException{

		if (!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)) {
			for (DatoSerie serie : listSeries) {
				validarRegimenPrecedente(serie);

			}
		}	
	}

	/**
	 * Valida el regimen precedente de la serie
	 * @param serie
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(DatoSerie serie) throws PuntoLLegadaValidadorException {
		Elementos<DatoRegPrecedencia> listRegPrecedencia = serie.getListRegPrecedencia();
		String codigoRegimenPrecedente = buscarPrimerRegimenPrecedente(listRegPrecedencia);
		validarRegimenPrecedente(serie.getNumserie(), codigoRegimenPrecedente);
	}

	/**
	 * Busca el tipo del primer regimen precedente de la serie
	 * @param listRegPrecedencia
	 * @return
	 */
	private String buscarPrimerRegimenPrecedente(Elementos<DatoRegPrecedencia> listRegPrecedencia) {
		String codigoRegimenPrecedente = "";
		
		if(CollectionUtils.isNotEmpty(listRegPrecedencia)){
			//buscamos por tipo de regimen
			codigoRegimenPrecedente = listRegPrecedencia.get(0).getCodregipre();
			DatoRegPrecedencia datoRegPrecedencia = (DatoRegPrecedencia)CollectionUtils.find(listRegPrecedencia, new Predicate() {
				
				@Override
				public boolean evaluate(Object arg0) {
					String codigoRegimenPrecedente = ((DatoRegPrecedencia)arg0).getCodregipre();
					return CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente);
				}
			});
			
			if(datoRegPrecedencia != null){
				codigoRegimenPrecedente = datoRegPrecedencia.getCodregipre();
			} 
		}
		return codigoRegimenPrecedente;
	}

	/**
	 * Valida el codigo de regimen precedente
	 * @param numeroSerie numero de serie a mostrar en la excepcion
	 * @param codigoRegimenPrecedente
	 * @throws PuntoLLegadaValidadorException si no es valido lanza una excepcion
	 */
	private void validarRegimenPrecedente(Integer numeroSerie, String codigoRegimenPrecedente)
			throws PuntoLLegadaValidadorException {
		
		if(CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
			if(!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
				throw new PuntoLLegadaValidadorException("30554",
						new String[] { codigoRegimenPrecedente, numeroSerie.toString() }, "REGIMEN PRECEDENTE INVALIDO PARA LA SERIE");
			}
		}
		
		if(CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
			if(!CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
				throw new PuntoLLegadaValidadorException("30546",
						new String[] { codigoRegimenPrecedente, codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "REGIMEN PRECEDENTE DE DEPOSITO: TIPO DE PUNTO DE LLEGADA INVALIDO PARA LA SERIE");
			}
		}
	}

	/**
	 * Builder para punto de llegada
	 * @param codigoPuntoLlegada
	 * @return
	 */
	PuntoLlegadaValidador tipoPuntoLlegadaValidadorBuilder(String codigoPuntoLlegada) {

		if (CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans, fabricaDeServicios, manifiestoSigadService,circunoceDAO,ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
		} else if (CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaTerminalPortuario(numeroRUCpuntoLlegada, codigoAduanaTransmision);			
		} else if (CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoAduanero(numeroRUCpuntoLlegada, (java.util.Date)fechaReferencia);			
		} else if (CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS.equals(codigoPuntoLlegada)) {
			return new OtroPuntoLlegadaAutorizado(numeroRUCpuntoLlegada);		
		} else if (CODIGO_PUNTO_LLEGADA_CETICOS.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaCeticos(numeroRUCpuntoLlegada,  (java.util.Date)fechaReferencia);
		} else if (CODIGO_PUNTO_LLEGADA_TERMNINAL_AEREO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaTerminalAereo(numeroRUCpuntoLlegada,  (java.util.Date) fechaReferencia);
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR.equals(codigoPuntoLlegada)) { // RN1786
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,  fabricaDeServicios, manifiestoSigadService,
					circunoceDAO, ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		}
//		else if (CODIGO_PUNTO_LLEGADA_TERMINAL_FLUVIAL.equals(codigoPuntoLlegada)) {
//			return new PuntoLlegadaTerminalFluvial(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
//		} 
		else if (CODIGO_PUNTO_LLEGADA_CENTRO_ATENCION_FRONTERIZA.equals(codigoPuntoLlegada)) { //PAS20181U220200004
			return new PuntoLlegadaCentroAtencionFronteriza(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
		}
//		else 
//RIN05 PAS20181U220200004 MORDONEZL
// if (CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLlegada)) {
//			return new PuntoLlegadaDepositoAduanero(numeroRUCpuntoLlegada, (java.util.Date)fechaReferencia);			
//		} 
		else {
			throw new RuntimeException(
					"Error de Aplicacion. El tipo de punto de llegada no es valido, para la validacion del punto de llegada");
		}
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}	
	*/
}