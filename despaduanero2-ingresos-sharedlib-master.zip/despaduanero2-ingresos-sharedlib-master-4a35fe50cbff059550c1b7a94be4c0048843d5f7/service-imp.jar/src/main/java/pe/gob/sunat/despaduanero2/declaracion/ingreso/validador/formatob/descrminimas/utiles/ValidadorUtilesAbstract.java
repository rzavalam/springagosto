package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.utiles;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorUtilesAbstract extends ValidadorAbstract
{

  private static final String UNIDAD = "U";
  private static final String JUEGO = "SET";
  protected static final String CON_CATALOGO = "0";
  private static final String 
  DIMENSIONM_FORMATO = "(\\d{1,3}(.\\d{1,2})?m)((x|X)\\d{1,3}(.\\d{1,2})?mm){2}$";
  private static final String 
  DIMENSIONMM_FORMATO = "(\\d{1,3}(.\\d{1,2})?mm)((x|X)\\d{1,3}(.\\d{1,2})?mm){2}$";
  private static final String SP_3919 = "3919100000";
  
  
  
  public ValidadorUtilesAbstract() {
    super();
  }
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto,
      Declaracion dua) throws Exception {
    return null;
  }
  
  /**
   * 
   * @param objeto
   * @param item
   * @return Lista de Errores
   * Sustentada en reglas de negocio: (R-909)
   */
  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract objeto,
                                                       DatoItem item) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    UtilesAbstract utiles = (UtilesAbstract) objeto;
    String datoAValidar = item.getCodunidcomer();
    Object[] demasArgumentosMSJError = new Object[] { 
    		utiles.getNumsecprove(),
    		utiles.getNumsecfact(),
    		utiles.getNumsecitem(),
    		"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar,datoAValidar};
    if (!(SunatStringUtils.isEqualTo(datoAValidar, UNIDAD) || 
          SunatStringUtils.isEqualTo(datoAValidar, JUEGO))) {	
      ErrorDescrMinima err = obtenerError("31190",
  				 ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
	  lst.add(err);       
     }
    return lst;
  }
  
  /**
   * 
   * @param objeto
   * @param item
   * @return Lista de Errores
   * Sustentada en reglas de negocio: (R-915)
   */
  public List<ErrorDescrMinima> validarDimensiones(ModelAbstract objeto,
                                                   DatoItem item) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    UtilesAbstract util = (UtilesAbstract) objeto;
    String subpartida = item.getNumpartnandi().toString();
    String datoAValidar = util.getDimensiones().getValtipdescri();
    if(SP_3919.equals(subpartida)){
      if (noCumpleExpresionRegular(datoAValidar, DIMENSIONM_FORMATO)) {
        lst.add(obtenerError("31203",util.getDimensiones()));
        }
    }else{
      if (noCumpleExpresionRegular(datoAValidar, DIMENSIONMM_FORMATO)) {
        lst.add(obtenerError("31285",util.getDimensiones()));
      }
    }
    return lst;
  }
  
  /**
   * 
   * @param objeto
   * @return Lista de Errores
   * Sustentada en reglas de negocio: (R-916)
   */
  public List<ErrorDescrMinima> validarPesoVolumen(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarNombre(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarModeloComercial(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarAcabado(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarAplicacionUso(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPresentacion(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCantidadPiezas(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }
}
