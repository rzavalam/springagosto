package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NabandinDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdualibDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;

/**
 * Clase que contiene los metodos para las validaciones de una declaracion acogida a PECO-Amazonia
 * @author rbegazo
 *
 */
public class PecoAmazoniaDirectoServiceImpl extends IngresoAbstractServiceImpl implements PecoAmazoniaDirectoService {

	public final static String ERR_ADUANA_DESTINO 					= "35470"; //Error Ley PECO aduana destino
	public final static String ERR_LEY_PECO_REGIMEN 				= "35150"; //Error Ley PECO Regimen		
	public final static String ERR_LEY_PECO_ADUANA_DESTINO 			= "35152"; //Error Ley PECO aduana destino	
	public final static String ERR_LEY_ADUANA_INGRESO_AMAZONIA		= "37973"; //Error Ley AMAZONIA aduana ingreso
	public final static String ERR_LEY_ADUANA_INGRESO_PECO			= "37974"; //Error Ley PECO aduana ingreso
	public final static String ERR_LEY_PECO_SUBPARTIDA_ARANCELARIA 	= "35240"; //Error  Ley PECO por validaci�n de subpartida arancelaria	
	public final static String ERR_LEY_PECO_CORRELACION 			= "35241"; //Error Ley PECO por correlaci�n entre subpartidas	
	public final static String ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA 	= "37975"; //Error Ley PECO por correlaci�n entre subpartidas	
	public final static String ERR_LEY_PECO_INF_COMPLEMENTARIA 		= "35246"; //Error Ley PECO por informaci�n complementaria	
	public final static String ERR_LEY_PECO_UBIGEO_AMAZONIA 		= "35247"; //Error Ley Amazon�a por ubigeo incorrecto
	public final static String ERR_LEY_AMAZONIA_UBIGEO_DESTINO 		= "37976"; //Error Ley Amazon�a por ubigeo-destino incorrecto PAS201830001100015
	public final static String ERR_RECTI_LEVANTE_INCORP_TPI       	= "32020";
	public final static String ERR_REGU_INCORP_MODIF_TPI       		= "35248";
	public final static String ERR_CONCLU_INCORP_MODIF_TPI 			= "31926";
	public final static String ERR_RECTI_INCORP_TPI       			= "35474";


	public List<Map<String,?>> validacionesPECOAmazoniaDirecto(Declaracion declaracion, Map<String,Object> variablesIngreso, Declaracion declaracionBD){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("*********** validacionesPECOAmazonia ********");	

		Map<Integer,Object> mapaSerieDUA = esPECOAmazoniaDirecto(declaracion);			
		String codTransaccion = variablesIngreso.get("codTransaccion").toString();
		//String esPecoAmazonia = mapaSerieDUA.get(Integer.valueOf("0")).toString();	

		//Seteamos en variablesIngreso si la declaracion en proceso corresponde a una DUA de PECO-Amazonia.
		//variablesIngreso.put("esPecoAmazonia", esPecoAmazonia);		

		int nCodTransaccion = Integer.parseInt(codTransaccion);
		switch(nCodTransaccion){
		case 1001: //Validaciones en la Numeracion
			responseListManager.addResponseList(validacionesNumeracion(declaracion,variablesIngreso,mapaSerieDUA));
			break;
		case 1003: //Validaciones en la Rectificacion
			responseListManager.addResponseList(validacionesRectificacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1004: //Validaciones en la Regularizacion
			responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1005: //Validaciones en la Regularizacion URGENTE
			responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1007: //Validaciones en la Diligencia de Rectificacion
			responseListManager.addResponseList(validacionesRectificacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1008: //Validaciones en la Diligencia de Regularizacion
			responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;					   
		case 1016: //Validaciones en la Diligencia de Despacho
			responseListManager.addResponseList(validacionesDiligenciaDespacho(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1012: //Validaciones en la Diligencia de Conclusion
			responseListManager.addResponseList(validacionesConclusion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 1019: //Validaciones en la Diligencia de Rectificacion de Oficio
			responseListManager.addResponseList(validacionesRectificacionOficio(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			break;
		case 2001: //Validaciones en la Numeracion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;
		case 2101: //Validaciones en la Numeracion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;
		case 7001: //Validaciones en la Numeracion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;			
		case 2003: //Validaciones en la Rectificacion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;
		case 2103: //Validaciones en la Rectificacion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;
		case 7003: //Validaciones en la Rectificacion
			responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
			break;
		}

		//responseListManager.addErrorFinalizarProceso(); // Se coloca cuando quiero cortar el proceso y que no siga validando
		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validacionesNumeracion(Declaracion declaracion, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("********* validacionesNumeracion **********");

		//1. Validamos el Regimen
		responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
		//2. Validamos la Aduana de Ingreso
		//responseListManager.addResponseList(validarAduanaIngreso(declaracion));
		//3. Validamos la Aduana de Destino si es PECO
		responseListManager.addResponseList(validarAduanaIngresoPECO(declaracion,mapaSerieDUA));
		//4. Validamos la Aduana de Destino si es Ley Amazonia
		responseListManager.addResponseList(validarAduanaIngresoCodLiberatorio(declaracion,mapaSerieDUA));
		//5. Validamos la correlacion entre Nandina y Nabandina
		responseListManager.addResponseList(validarCorrelacionNandinaNabandina(declaracion,mapaSerieDUA));
		//6. Validamos Lista de Observaciones
		responseListManager.addResponseList(validarInformacionComplementaria(declaracion,mapaSerieDUA));
		//7. Validamos que transmita las partidas nandina y nabandina
		responseListManager.addResponseList(validarSubpartidaArancelaria(declaracion,mapaSerieDUA));
		//8. Validamos que la partida este dentro del convenio
		responseListManager.addResponseList(validarPartidaConvenioPECOAmazoniaDirecto(declaracion,mapaSerieDUA));
		//9. Validamos el Ubigeo
		responseListManager.addResponseList(validarUbigeo(declaracion,mapaSerieDUA));
		//10. No debe enviar la aduana de destino, no es necesario se valida en el servicio de aduana destino
		//responseListManager.addResponseList(validarNoAcogimientoPECOAmazonia(declaracion.getDua().getCodaduanaorden()));
		return responseListManager.getResponseList();		
	}	

	public List<Map<String,?>> validacionesRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();		
		if(log.isDebugEnabled()) log.debug("********* validacionesRectificacion ********** codCanal: [" + codCanal + "]");
		Date fecAutLevante = declaracionBD.getDua().getFecAutlevante()!=null?declaracionBD.getDua().getFecAutlevante():SunatDateUtils.getDefaultDate();
		//1. Validamos lo mismo que en la numeracion
		responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));		
		if( !SunatDateUtils.isDefaultDate(fecAutLevante)) {
			//2. Validamos que no se acoja en la rectificacion
			responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA));
		} 
		return responseListManager.getResponseList();		
	}

	public List<Map<String,?>> validacionesRectificacionOficio(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();		
		if(log.isDebugEnabled()) log.debug("********* validacionesRectificacion Oficio ********** codCanal: [" + codCanal + "]");
		Date fecAutLevante = declaracionBD.getDua().getFecAutlevante()!=null?declaracionBD.getDua().getFecAutlevante():SunatDateUtils.getDefaultDate();
		//1. Validamos lo mismo que en la numeracion
		responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));		
		if( !SunatDateUtils.isDefaultDate(fecAutLevante)) {
			//2. Validamos que no se acoja en la rectificacion
			responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA));
		} 
		return responseListManager.getResponseList();		
	}

	public List<Map<String,?>> validacionesRegularizacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();		
		if(log.isDebugEnabled()) log.debug("********* validacionesRegularizacion ********** codCanal: [" + codCanal + "]");
		//1. Validamos lo mismo que en la numeracion
		responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));	
		//2. Validamos que no se acoja en la regularizacion
		responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA));

		return responseListManager.getResponseList();		
	}

	public List<Map<String,?>> validacionesDiligenciaDespacho(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();

		if(log.isDebugEnabled()) log.debug("********* validacionesDiligenciaDespacho ********** codCanal: [" + codCanal + "]");

		//1. Validamos lo mismo que en la numeracion
		responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));		

		return responseListManager.getResponseList();
	}

	/** 
	 * Validaciones para la Diligencia de Conclusion 
	 */
	public List<Map<String,?>> validacionesConclusion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();

		if(log.isDebugEnabled()) log.debug("********* validacionesConclusion ********** codCanal: [" + codCanal + "]");		
		//1. Validamos lo mismo que en la numeraci�n
		responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));			
		//2. Validamos que no se acoja en la Diligencia Conclusion
		responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA, declaracion.getDua().getCodregimen().concat(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)));

		return responseListManager.getResponseList();		
	}

	/**
	 * RIN08 - Permite determinar si una declaracion corresponde a alguno de los convenios PECO y/o Amazon�a
	 * 0=Ninguno / 1=PECO / 2=AMAZONIA / 3=Ambos
	 */
	public Map<Integer,Object> esPECOAmazoniaDirecto(Declaracion declaracion){
		Map<Integer,Object> duaPECOAmazonia = new HashMap<Integer,Object>();		
		boolean esPeco = false;
		boolean esAmazonia = false;
		boolean almenosUnaPeco = false;
		boolean almenosUnaAmazonia = false;
		String convInter = "";

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			esPeco = false;
			esAmazonia = false;
			//Verificamos si la serie tiene declarado PECO
			convInter= SunatStringUtils.toStringObj(serie.getCodconvinter());

			if(ConstantesDataCatalogo.COD_TIP_32.equals(convInter) || 
					ConstantesDataCatalogo.COD_TIP_33.equals(convInter)){
				esPeco = true;
				almenosUnaPeco = true;
			}

			//Verificamos si la serie tiene declarado Ley Amazonia
			if(SunatStringUtils.isEqualTo(ConstantesDataCatalogo.COD_LIBERATORIO_AMAZONIA_DIRECTO,serie.getCodliberatorio().toString())){
				esAmazonia = true;
				almenosUnaAmazonia = true;
			}

			if(esPeco && esAmazonia) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS);
			else 
				if(esPeco) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO);
				else
					if(esAmazonia) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA);
					else
						duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}

		//Para CERO se coloca si la DUA en general se acoge a alg�n beneficio PECO/Amazonia
		if(almenosUnaPeco || almenosUnaAmazonia){
			if(almenosUnaPeco && almenosUnaAmazonia) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS);
			else 
				if(almenosUnaPeco) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO);
				else
					if(almenosUnaAmazonia) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA);
					else
						duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}
		else{
			duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}		

		return duaPECOAmazonia;
	}



	public List<Map<String,?>> validarNoAcogimientoPECOAmazonia(String aduanaDestino){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarNoAcogimientoPECOAmazonia **** ");

		if(aduanaDestino != null && !"".equals(aduanaDestino.trim())){
			Map<String, String> listError = new HashMap<String, String>();
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_ADUANA_DESTINO, new String[] {aduanaDestino});			
			responseListManager.addResponseMap(listError);			
		}

		return responseListManager.getResponseList();
	}	

	public List<Map<String,?>> validarRegimen(String codRegimen, Map<Integer,Object> mapa, Declaracion declaracion){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarRegimen ****  codRegimen: " + codRegimen);

		if(!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(codRegimen)){
			for (DatoSerie serie:declaracion.getDua().getListSeries()){
				String preferencia = mapa.get(serie.getNumserie()).toString();
				if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_REGIMEN, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}

		return responseListManager.getResponseList();
	}


	public List<Map<String,?>> validarAduanaIngresoPECO(Declaracion declaracion, Map<Integer,Object> mapa){
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		ResponseListManager responseListManager = new ResponseListManager();

		String aduanaIngreso= "";

		if(declaracion.getDua().getCodaduanaorden() != null){
			aduanaIngreso = declaracion.getDua().getCodaduanaorden() != null ? declaracion.getDua().getCodaduanaorden() : ""; 
		}


		if(log.isDebugEnabled()) log.debug("**** Inicio: validarAduanaDestinoPECO **** destino:" +aduanaIngreso);

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();

			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){
				if("".equals(aduanaIngreso) || !CollectionUtils.isEmpty(catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.COD_GRP_ADUANAS_INGRESO_PECO, aduanaIngreso))){					
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_ADUANA_INGRESO_PECO, new String[] {serie.getNumserie().toString(), aduanaIngreso});
					responseListManager.addResponseMap(listError);
					break;
				}
			}				
		}				
		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validarAduanaIngresoCodLiberatorio(Declaracion declaracion, Map<Integer,Object> mapa){
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		ResponseListManager responseListManager = new ResponseListManager();

		String aduanaIngreso = "";

		if(declaracion.getDua().getCodaduanaorden() != null){
			aduanaIngreso = declaracion.getDua().getCodaduanaorden() != null ? declaracion.getDua().getCodaduanaorden() : ""; 
		}


		if(log.isDebugEnabled()) log.debug("**** Inicio: validarAduanaDestinoCodLiberatorio **** ");

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();

			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){
				if("".equals(aduanaIngreso) || !CollectionUtils.isEmpty(catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.COD_GRP_ADUANAS_INGRESO_AMAZONIA, aduanaIngreso))){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_ADUANA_INGRESO_AMAZONIA, new String[] {serie.getNumserie().toString(),aduanaIngreso});
					responseListManager.addResponseMap(listError);
					break;
				}
			}
		}

		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validarSubpartidaArancelaria(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		Long nabandinda = 0L;

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarSubpartidaArancelaria **** ");

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				//nabandinda = serie.getNumpartnabanAsLong()==null?0L:serie.getNumpartnabanAsLong();
				nabandinda = serie.getNumpartnaban()!=null && !"".equals(serie.getNumpartnaban().trim())?serie.getNumpartnabanAsLong():0L;
				if(serie.getNumpartnandi().compareTo(0L)==0 || nabandinda.compareTo(0L)==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_SUBPARTIDA_ARANCELARIA, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}

		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validarCorrelacionNandinaNabandina(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarCorrelacionNandinaNabandina **** ");

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				HashMap<String, Object> paramsNabandin = new HashMap<String, Object>();
				paramsNabandin.put("nabandi", serie.getNumpartnaban());
				paramsNabandin.put("nandina", serie.getNumpartnandi());				

				Integer existeNabandin = ((NabandinDAO)fabricaDeServicios.getService("nabandinDAO")).count(paramsNabandin);				
				if (existeNabandin==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CORRELACION, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}

		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validarInformacionComplementaria(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		boolean existeObs = false;

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarInformacionComplementaria **** ");


		ObservacionDAO observacionDAO = fabricaDeServicios.getService("observacionDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		DUA dua=declaracion.getDua();
		if( dua.getNumcorredoc() != null ) { //PAS20191U220200026 - mtorralba 20190627 - Solucion bug 17369
			params.put("numcorredoc", dua.getNumcorredoc());
			params.put("inddel", Constants.INDICADOR_NO_ELIMINADO);
			// OBTENIENDO OBSERVACIONES
			Elementos<Observacion> observaciones_dua = new Elementos<Observacion>();
			observaciones_dua.addAll(observacionDAO.findObservcionByMap(params));
			if (!CollectionUtils.isEmpty(observaciones_dua)){
				Iterator<Observacion> it = observaciones_dua.iterator();
				while(it.hasNext()){
					Observacion mObsDua = (Observacion)it.next();
					if (mObsDua.getCodtipobserva().equals("06")){
						existeObs = true;
					}
				}
			}
			//dua.setListObservaciones(observaciones_dua);
		}


		for (Observacion obs:declaracion.getDua().getListObservaciones()){	
			//Tipo de Obervacion (cod_catalogo = '369' | 01:Formato A - 06:Series Formato A)			
			if("06".equals(obs.getCodtipobserva()) && !"".equals(obs.getObsdeclaracion())) 
				existeObs = true;
		}

		if(!existeObs){
			for (DatoSerie serie:declaracion.getDua().getListSeries()){
				String preferencia = mapa.get(serie.getNumserie()).toString();
				if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
					//No hay observaciones por serie, estan a nivel de datos generales, seria el mismo error para cada serie acogida
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_INF_COMPLEMENTARIA, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}		

		return responseListManager.getResponseList();
	}


	public List<Map<String,?>> validarPartidaConvenioPECOAmazoniaDirecto(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarPartidaConvenioPECOAmazonia **** ");


		String aduanaDestino = declaracion.getDua().getCodaduanaorden() != null ? declaracion.getDua().getCodaduanaorden() : "" ;

		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){			
				HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
				paramsAdualib.put("tlib","C");
				paramsAdualib.put("cnab", serie.getNumpartnaban());
				paramsAdualib.put("clib", serie.getCodliberatorio());
				paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				paramsAdualib.put("cadu", aduanaDestino); 

				Integer existeAdualib = ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).count(paramsAdualib);
				if (existeAdualib==0){					
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, 
							new String[] {serie.getNumserie().toString(), serie.getNumpartnaban(), aduanaDestino});
					responseListManager.addResponseMap(listError);
				}
			}

			// Se valida la vigencia de la nabandina para los TPI de PECO
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){			
				HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
				paramsAdualib.put("tlib","I");
				paramsAdualib.put("cnab", serie.getNumpartnaban());
				paramsAdualib.put("clib", ConstantesDataCatalogo.COD_TIP_32); 
				paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				paramsAdualib.put("cadu", aduanaDestino); 

				Integer existeAdulibe = ((pe.gob.sunat.despaduanero2.declaracion.model.dao.AdulibeDAO)fabricaDeServicios.getService("adulibeDAO")).count(paramsAdualib);					
				if (existeAdulibe==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, 
							new String[] {serie.getNumserie().toString(), serie.getNumpartnaban(), aduanaDestino});
					responseListManager.addResponseMap(listError);
				}
			}
		}

		return responseListManager.getResponseList();
	}	

	public List<Map<String,?>> validarUbigeo(Declaracion declaracion, Map<Integer,Object> mapaSerieDUA){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		ResponseListManager responseListManager = new ResponseListManager();

		if(log.isDebugEnabled()) log.debug("**** Inicio: validarUbigeo **** ");

		//Solo se valida el Ubigeo cuando declara en alguna serie que se acoge a Ley de Amazonia
		String esAmazonia = mapaSerieDUA.get(Integer.valueOf("0")).toString();
		if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(esAmazonia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(esAmazonia)){
			PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");

			String aduanaIngreso = declaracion.getDua().getCodaduanaorden();
			String ubigeoDuenoConsignatario = preferenciaArancelariaService.consultarUbigeoImportadorPreferenciaArancelaria(
					declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());

			if(log.isDebugEnabled()) log.debug("**** ubigeoDuenoConsignatario: " + ubigeoDuenoConsignatario);

			Map<String,Object> paramsCatRefpartidas=new HashMap<String,Object>();
			paramsCatRefpartidas.put("tipo_uso", "ULA");
			paramsCatRefpartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
			paramsCatRefpartidas.put("codUbigeo", ubigeoDuenoConsignatario);		
			paramsCatRefpartidas.put("ayudaID", "CatRefpartidas");

			Integer countCatRefParts = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);		
			if(countCatRefParts==0){
				Map<String, String> listError = new HashMap<String, String>();
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_UBIGEO_AMAZONIA, new String[] {ubigeoDuenoConsignatario});
				responseListManager.addResponseMap(listError);
			}else{//para el acogimiento al beneficio de la Ley de Amazon�a el domicilio fiscal del importador debe encontrarse dentro de la jurisdicci�n de la Aduana de destino en la zona establecida como Amazonia. 
				paramsCatRefpartidas.put("codi_aduan", aduanaIngreso);

				Integer countCatRefPartidas = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);		
				if(countCatRefPartidas==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_AMAZONIA_UBIGEO_DESTINO, new String[] {aduanaIngreso});
					responseListManager.addResponseMap(listError);
				}
			}
		}

		return responseListManager.getResponseList();
	}


	public List<Map<String,?>> acogimientoPosteriorNumeracion(Declaracion declaracion, Declaracion declaracionBD, Map<Integer,Object> mapa, String codTransaccion){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: acogimientoPosteriorNumeracion ****");
		

		//Incorporacion de datos x serie
		String TPI = "0";
	
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
			String preferencia = mapa.get(serie.getNumserie()).toString();			
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				//No consideraba que en la recti enviase mas series
				DatoSerie serieBD = new DatoSerie();
				if (SunatNumberUtils.isGreaterOrEqualsThanParam(declaracionBD.getDua().getListSeries().size(), serie.getNumserie())) {
					for(DatoSerie serieRealBD: declaracionBD.getDua().getListSeries()){
						if(serieRealBD.getNumserie().equals(serie.getNumserie())){
							serieBD = serieRealBD;
							break;
						}
					}
				} 
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				TPI = serie.getCodconvinter().toString();			
				String numeroSerie = serie.getNumserie().toString();			
				//Incorporacion de TPI
				if("0".equals(serieBD.getCodconvinter().toString()) && !"0".equals(TPI)){
					if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {
						listError.add(catalogoAyudaService.getError(ERR_RECTI_LEVANTE_INCORP_TPI, new String[] {numeroSerie}));
					} else if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {						
						listError.add(catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_TPI, new String[] {serie.getCodconvinter().toString(), numeroSerie}));
					} else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion)) {
						listError.add(catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_TPI, new String[] {numeroSerie}));
					} else { 
						listError.add(catalogoAyudaService.getError(ERR_RECTI_LEVANTE_INCORP_TPI, new String[] {numeroSerie}));
					}
				}
			}			
			//Se incluyen los errores en la lista de Errores
			for( Map<String,String> mapaError : listError ) {
				responseListManager.addResponseMap(mapaError);
			}
		} 	
		return responseListManager.getResponseList();
	}

}