package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class ValidacionFormatoB extends ValDuaAbstract {

	//private Logger logger = Logger.getLogger(this.getClass());	
	//protected CatalogoHelperImpl catalogoHelper;
	//protected ProveedorFuncionesService funcionesService = FormatoBServiceImpl.getInstance().getFuncionesService();
	//protected FormatoBServiceImpl formatoBService;
	//protected CatalogoAyudaService catalogoAyudaService;
	//protected FabricaDeServicios fabricaDeServicios; 
	//protected ProveedorFuncionesService funcionesService;
	//protected ValItemFB valItemFB;

/*
	public Logger getLogger() {
		return logger;
	}
	
	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}
	
	public ProveedorFuncionesService getFuncionesService() {
		return funcionesService;
	}
	
	public FormatoBServiceImpl getFormatoBService() {
		return formatoBService;
	}
	
	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}
	
	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}
	
	public void setFormatoBService(FormatoBServiceImpl formatoBService) {
		this.formatoBService = formatoBService;
	}

	public CatalogoAyudaService getCatalogoAyudaService() {
		return catalogoAyudaService;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}

	public ValItemFB getValItemFB() {
		return valItemFB;
	}

	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}*/
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	*/
}
