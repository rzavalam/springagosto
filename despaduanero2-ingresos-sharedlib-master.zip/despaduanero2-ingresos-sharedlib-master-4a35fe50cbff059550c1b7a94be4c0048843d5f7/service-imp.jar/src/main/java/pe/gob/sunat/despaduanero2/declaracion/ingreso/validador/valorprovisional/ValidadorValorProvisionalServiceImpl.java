package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif.ValRectif;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FuncionesFechaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarRectificacionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.CabDiligenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;

import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.garantia.model.dao.CabCtaCteGarDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.PadUsuGaraDAO;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.*;

/**
 * Creador por amancillaa
 * fecha: 14/01/2015.
 */
public class ValidadorValorProvisionalServiceImpl extends ValDuaAbstract implements ValidadorValorProvisionalService
{

    //private FabricaDeServicios fabricaDeServicios;
    //private DdpDAOService ddpDAOService;

    //protected final Log log                      = LogFactory.getLog(getClass());




    public void rechazarSolicitudElectronicaConValorProvisional(String codAduana, String codRegimen, Integer ano, Integer numDeclaracion, Long numCorreDocSol){

        Declaracion declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(codAduana,
                numDeclaracion, ano,codRegimen);


        String codGarantia = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        boolean duaSinGarantia160 = SunatStringUtils.isEmptyTrim(codGarantia);
        boolean LCVPGeneradoEnLaRectificacion = LCVPGeneradoEnLaRectificacion(declaracionBD);

        if(duaSinGarantia160 && LCVPGeneradoEnLaRectificacion){

            LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");

            Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
//usa catalogho 900031
           enviarNotificacionAnulacionLCVP(declaracionBD,resultadoTmp,Constants.COD_NOTIF_RECTIF_03,numCorreDocSol);
        }
    }

    
    /**
     * Para que una LC sea generado en la TX 1003 despues del canal no debe tener indicador 20 dado que el indicador se graba solo cuando se acepta en parte 
     * o procede la solicitud en caso se rechace no debe tener indicador 20 registrado 
     * 
     * @param declaracionBD
     * @return 
     */
     private boolean LCVPGeneradoEnLaRectificacion(Declaracion declaracionBD){
     

    	 ValRectif valRectif =  fabricaDeServicios.getService("ValRectif");

         boolean tieneIndicadorVP;
		try {
			tieneIndicadorVP = valRectif.validaIndicadorVP(declaracionBD);
		} catch (Exception e) {
			log.error("error-LCVPGeneradoEnLaRectificacion",e);
			return false;
		}
    	 
         return !tieneIndicadorVP;
    }

    public void improcedenteSolicitudElectronicaConValorProvisional(String codAduana, String codRegimen, Integer ano, Integer numDeclaracion, Long numCorreDocSol){

        Declaracion declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(codAduana,
                numDeclaracion, ano,codRegimen);


        String codGarantia = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        boolean duaSinGarantia160 = SunatStringUtils.isEmptyTrim(codGarantia);

        if(duaSinGarantia160){

            LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");

            Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
//usa catalogho 900038
            enviarNotificacionAnulacionLCVP(declaracionBD,resultadoTmp,Constants.COD_NOTIF_RECTIF_10,numCorreDocSol );
        }
    }

    private void enviarNotificacionAnulacionLCVP(Declaracion declaracionBD, Map<String, String> resultadoTmp, String plantilla,Long numCorreDocSol)
    {

        if(!CollectionUtils.isEmpty(resultadoTmp)){
            Map datosNotificacion = new HashMap<String, String>();
            datosNotificacion.putAll(resultadoTmp);
            datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_VP);
            datosNotificacion.put("codigo_plantilla", plantilla);

            CabSolrectiDAO solirectificaDAO =  fabricaDeServicios.getService("solirectificaDAO");

            Map filtro = new HashMap();
            filtro.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());
            filtro.put("COD_TIPSOL", "01"); //rectificacion
            filtro.put("NUM_CORREDOC_SOL", numCorreDocSol);
            List solicitudes = solirectificaDAO.getLstRegistrosAnuladosYAgregados(filtro);
            if(!CollectionUtils.isEmpty(solicitudes)){
                Map solicitud  =    (Map)solicitudes.get(0);
                String nroSolicitud = solicitud.get("COD_ADUANA")+"-"+solicitud.get("ANN_SOL")+"-"+solicitud.get("NUM_SOL");
                datosNotificacion.put("nroSolicitud", nroSolicitud);
            }


            enviarNotificaciones(declaracionBD, declaracionBD, datosNotificacion);
        }
    }


    private boolean cumpleRequisitosParaValidarCoberturaMontoVP(Declaracion declaracion) throws Exception
    {

        boolean cumple=false;

        ValRectif valRectif =  fabricaDeServicios.getService("ValRectif");

        boolean tieneIndicadorVP = valRectif.validaIndicadorVP(declaracion);
        boolean noHaRegularizadoVP  = !tieneRegistradaFechaValida(declaracion.getDua().getFecRegulaValProv()) && 
        		!tieneRegistradaFechaValida(declaracion.getDua().getFecRegOfiValProv()); 
        		

        // Valida si transmiti� fecha fin de VP en Datos Generales
        if ((declaracion.getDua().getFecfinprovsional() != null
        		|| (tieneIndicadorVP && noHaRegularizadoVP)
                || FormatoBUtils.validaTransmisionValorFormatoB(declaracion)
                || FormatoBUtils.validaTransmisionValorSeries(declaracion)) && SunatStringUtils.isStringInList(declaracion.getDua().getCodregimen(), Constantes.REGIMENES_VALOR_PROVISIONAL))
        {
            cumple=true;
        }

        return cumple;
    }

    @Override
    public List validarValorProvisionalParaRectificacionProcedente(Declaracion declaracion,Declaracion declaracionBD, String tieneIncTrib) throws Exception
    {

        List lstErrores = new ArrayList();

        if (!cumpleRequisitosParaValidarCoberturaMontoVP(declaracion))
        {
            return lstErrores;
        }

        ValRectif valRectif =  fabricaDeServicios.getService("ValRectif");
        boolean tieneIndicadorVP = valRectif.validaIndicadorVP(declaracionBD);
        boolean tieneAlMenos1ItemVP = FormatoBUtils.tieneAlMenos1ItemVP(declaracion);
        boolean tieneIndicadorLCVP = tieneIndicadorParaGenerarLCVPActivo(declaracion);
        String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        String codGarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        boolean duaConGarantia160 = !SunatStringUtils.isEmptyTrim(codGarantia) && !SunatStringUtils.isEmptyTrim(codGarantiaBD);
        boolean duaSinGarantia160 = SunatStringUtils.isEmptyTrim(codGarantia) && SunatStringUtils.isEmptyTrim(codGarantiaBD);


        // 1. DUA SIN Valor Provisional
        if (!tieneIndicadorVP)
        {

            // 1.1.	DUA(s) CON Garant�a del Art�culo 160� de la LGA
            if (duaConGarantia160 && tieneAlMenos1ItemVP && tieneIndicadorLCVP)
            {

                BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                //pase24 mol
                if(tieneIncTrib.equals("S")){
                	   lstErrores.addAll(validarGarantia160CubraMonto(declaracion, mtoSaldoPorCubrir));
                   }
             
            }else if(duaSinGarantia160 && tieneAlMenos1ItemVP && !tieneIndicadorVP){

                //1.2.1 Rectificaci�n sin acogerse a la garant�a Art�culo 160� LGA
                lstErrores.addAll(validarLCVPEsteGarantizadaConGarantia159(declaracion));
            }
        }//2. DUA(s) CON Valor Provisional
        else{

            //2.1 Rectificaci�n electr�nica del Valor Provisional que cambia a Valor Definitivo todos los �tems
            boolean tieneTodosItemsConValorDefinitivo = cumpleRequisitosParaValidarDUAConVPRegularizada(declaracion);
            if(tieneTodosItemsConValorDefinitivo){
                lstErrores.addAll(validarFechasDeRegularizacionVP(declaracion));
            } else if(tieneAlMenos1ItemVP){

                //2.2.1.	Rectificaci�n CON Garant�a 160� y cuente con indicador de generaci�n de LC(VP)
                if(!SunatStringUtils.isEmptyTrim(codGarantiaBD) && tieneIndicadorLCVP){

                    BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                    BigDecimal montoLC = obtenerMontoLCGeneradaVP(declaracion);
                    if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(montoLC) == 1){
                        if(tieneIncTrib.equals("S")){
                        lstErrores.addAll(validarGarantia160CubraMontoVP(declaracion, mtoSaldoPorCubrir.subtract(montoLC)));//gmontoya Pase 24
                        }
                    }
                }//2.2.2.	Rectificaci�n de DUA(s) SIN Garant�a Art�culo 160� LGA y sin acogerse a la Garant�a Art�culo 160� LGA
                else if(SunatStringUtils.isEmptyTrim(codGarantiaBD) && SunatStringUtils.isEmptyTrim(codGarantia)){

                    //Excepci�n 6 es igual que la Expecion 3 solo que el mensaje es un poco difernete
                    if( !CollectionUtils.isEmpty(validarLCVPEsteGarantizadaConGarantia159(declaracion))){
                            //Excepci�n 6
                            lstErrores.add(addError("000000", "LC DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA"));
                    }
                }

            }
       }


        return lstErrores;
    }

//PAS20155E220200167 amancilla

    public List validarValorProvisionalParaDiligencia(Declaracion declaracion) throws Exception
    {

        List lstErrores = new ArrayList();

        //si no tiene formato B como donaciones
        if(CollectionUtils.isEmpty(declaracion.getListDAVs())){
            return lstErrores;
        }

        boolean tieneAlMenos1ItemVP= false;
        boolean itemTieneFFVP= false;

        for(DatoSerie serie : declaracion.getDua().getListSeries())
        {
            boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
            boolean itemTieneVP= false;


            StringBuilder itemsDeLaSerie = new StringBuilder();
            StringBuilder itemsDeLaSerieConVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinVP = new StringBuilder();
            StringBuilder itemsDeLaSerieConFFVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinFFVP = new StringBuilder();

            for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
            {

                itemsDeLaSerie.append(datoItem.getNumsecitem());
                itemsDeLaSerie.append(", ");

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){
                    tieneAlMenos1ItemVP = true;
                    itemTieneVP=true;
                    itemsDeLaSerieConVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConVP.append(", ");
                }else{
                    itemsDeLaSerieSinVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinVP.append(", ");
                }
                if(tieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima())){
                    itemTieneFFVP=true;
                    itemsDeLaSerieConFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConFFVP.append(", ");
                }else{
                    itemsDeLaSerieSinFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinFFVP.append(", ");
                }

            }

            if(itemTieneVP && !StringUtils.isEmpty(itemsDeLaSerieSinVP.toString())){
                //Excepci�n  9
                lstErrores.add(addError("123456", "TODOS LOS ITEMS: "+ itemsDeLaSerie.toString()+ " ASOCIADOS A LA MISMA SERIE: "+ serie.getNumserie()+" CON VALOR PROVISIONAL DEBEN TENER  CONSIGNADO EL C�DIGO 2 EN LA CASILLA 5.6 DEL FORMATO B, ITEMS CON VALOR PROVISIONAL: "+itemsDeLaSerieConVP.toString()+" ITEMS SIN VALOR PROVISIONAL: "+itemsDeLaSerieSinVP.toString()));
            }
        }

        return lstErrores;
    }


    private static boolean tieneLCVPGenerado(BigDecimal montoLC) {
        return montoLC.compareTo(BigDecimal.ZERO)==1;
    }



    public Map grabarValorProvisional(Declaracion declaracion,Declaracion declaracionBD) throws Exception
    {

Map resultado = new HashMap();

List lstDeudasAAfectarVP  = new ArrayList(); 
Map mpDeudasADesafectarVP  = new HashMap();
       // HashMap<String, String> datosNotificacion = new HashMap<String, String>();

        if(cumpleRequisitosParaValidarCoberturaMontoVP(declaracion)){


            Map variablesIngreso = new HashMap();
            variablesIngreso.put("codTransaccion", "1001");//para que pase como numeracion y no afectar
            variablesIngreso.put("numOrden", declaracion.getNumorden());
            variablesIngreso.put("numeroDocumentoIdentidadSender", declaracion.getDua().getNumdocumento());
            variablesIngreso.put("fechaConclusionDespa", declaracion.getDua().getFecconclusion());
            variablesIngreso.put("tipoDesp",  declaracion.getDua().getCodtipoperacion());


        ValRectif valRectif =  fabricaDeServicios.getService("ValRectif");
        boolean tieneIndicadorVP = valRectif.validaIndicadorVP(declaracionBD);
        boolean tieneAlMenos1ItemVP = FormatoBUtils.tieneAlMenos1ItemVP(declaracion);
        boolean tieneIndicadorLCVP = tieneIndicadorParaGenerarLCVPActivo(declaracion);
        String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        String codGarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        boolean duaConGarantia160 = !SunatStringUtils.isEmptyTrim(codGarantia);
        boolean duaSinGarantia160 = SunatStringUtils.isEmptyTrim(codGarantia);

            //HashMap<String, String> resultadoTmp = new HashMap<String, String>();
            
           
        // 1. DUA SIN Valor Provisional
        if(!tieneIndicadorVP){
            if(tieneAlMenos1ItemVP) {
                verificarFechaFinVPDiaInhabil(declaracion);
               //amancilla PAS20155E220200039 SAU201510002900080
                GrabarDeclaracionService grabarDeclaracionService =  (GrabarDeclaracionService)fabricaDeServicios.getService("grabarDeclaracionService");/*<KAH>RIN10</KAH>*/
                grabarDeclaracionService.grabarIndicadorPlazoNumeracion(declaracionBD, declaracionBD.getDua().getNumcorredoc(),"1007");

                // 1.1.	DUA(s) CON Garant�a del Art�culo 160� de la LGA
                if (duaConGarantia160) {
                    /* amancilla PAS20155E220200039
                    GrabarDeclaracionService grabarDeclaracionService =  (GrabarDeclaracionService)fabricaDeServicios.getService("grabarDeclaracionService");
                    grabarDeclaracionService.grabarIndicadorPlazoNumeracion(declaracionBD, declaracionBD.getDua().getNumcorredoc(),"1007"); */
                       LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
                        
                        
                    Map datosNotificacion = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
                        lstDeudasAAfectarVP.addAll(cargarDatosAfectaGarantia160(datosNotificacion));
                        datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_GARANTIA160);
                        datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_01);
                    enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                }
            }
        }//2. DUA(s) CON Valor Provisional
        else{

            //2.1 Rectificaci�n electr�nica del Valor Provisional que cambia a Valor Definitivo todos los �tems
            boolean tieneTodosItemsConValorDefinitivo = cumpleRequisitosParaValidarDUAConVPRegularizada(declaracion);
            if(tieneTodosItemsConValorDefinitivo){
            	CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
                //Verifico si tiene diligencia de despacho
                Map mapDiligencia = cabdiligenciaDAO.findDuaDiligenciada(declaracion.getDua().getNumcorredoc().toString());
               //oswaldo dice que es despues de la diligencia de desapcho
                if (!CollectionUtils.isEmpty(mapDiligencia) || declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_VERDE)) { /// PAS20175E220200021 // PAS201830001100011 


                    Map<String, Object> paramMap = new HashMap<String, Object>();
                    paramMap.put("numcorredoc", declaracion.getDua().getNumcorredoc());

                    CabAdiDeclaraDAO cabAdiDeclaraDAO =  fabricaDeServicios.getService("cabAdiDeclara");

                    DUA cabAdiDeclara = cabAdiDeclaraDAO.getByPrimaryKey(paramMap);

                    declaracion.getDua().setFecRegulaValProv(SunatDateUtils.getCurrentDate());
                    if (cabAdiDeclara != null){
                        cabAdiDeclaraDAO.updateByPrimaryKeySelective(declaracion.getDua());
                    }else {
                        cabAdiDeclaraDAO.insertSelective(declaracion.getDua());
                    }
                }else{

                    retirarIndicadorVP(declaracion);
                }
                //TODO: antes o despues de l diligencxia es lo mismo verificar
                //2.1.1.	Antes de la Diligencia de Despacho
                //if (CollectionUtils.isEmpty(mapDiligencia)) {

                    //TODO: ?	Se borra el campo FOB Unitario Provisional de los �tems del formato B.

                    // si existe una lc asociada a la declaracion, se procede a anular
                    LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");

                    Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
                    Map datosNotificacion = new HashMap<String, String>();
                    datosNotificacion.putAll(resultadoTmp);

                    if (duaConGarantia160) {
                        declaracionBD.getDua().setNumdocumento(declaracion.getNumeroDeclaracion().toString().trim());// DUA trae dato err�neo
                        //lleva datos para desacfectar
                        mpDeudasADesafectarVP.putAll(cargarDatosParaDesafectarGarantia160(resultadoTmp));

                        datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC);
                        datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_02);
                        enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                    }else {
                    	//Inicio RIN10 BUG 22106
                        //boolean duaConGarantia159 = tieneGarantia159(declaracion);
                    	
                    	if(resultadoTmp.get("numero_lc_anul")!=null){
                        String numLiquidacionAnulada = resultadoTmp.get("numero_lc_anul").toString();                        
                        boolean duaConGarantia159 = lcVPEstaAfectadaGarantia159(declaracion,numLiquidacionAnulada);
                        //Fin RIN10 BUG 22106
                        if (duaConGarantia159) {
                            datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_GARANTIA_159);//<KAH-RIN10>Constants.ASUNTO_NOTIF_ANULACION_LC);
                            datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_25);//<KAH-RIN10>Constants.COD_NOTIF_RECTIF_03);
                            enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                        } else {
                        	//Inicio BUG 22106 RIN10
                            //datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC);
                            datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_NO_GARANTIZADA_CON_ART_159);
                            //Fin BUG 22106 RIN10
                            datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_04);
                            enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                        }
                        
                    	}
                       
                        //Fin RIN10 BUG 22106
                       
                    }
               // }
            } else if(tieneAlMenos1ItemVP){
                //2.2.1.	Rectificaci�n CON Garant�a 160�
                if(duaConGarantia160){

                    BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                    BigDecimal montoLC = obtenerMontoLCGeneradaVP(declaracion);
                    
					//sigesi 
					//mordonezl
					BigDecimal diferenciaAjuste = SunatNumberUtils.absoluteDiference(montoLC, mtoSaldoPorCubrir);
					BigDecimal tolerancia = new BigDecimal(1);  //1 dolar
                   //amancilla cambio 
					//if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(BigDecimal.ZERO) == 1 && diferenciaAjuste.compareTo(tolerancia) == 1){
                    if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(BigDecimal.ZERO) == 1   && diferenciaAjuste.compareTo(tolerancia) == 1){//pase24 mordonezl
                        // si existe una lc asociada a la declaracion, se procede a anular
                        LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");

                        Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
                        Map datosNotificacion = new HashMap<String, String>();
                        datosNotificacion.putAll(resultadoTmp);

                        declaracionBD.getDua().setNumdocumento(declaracion.getNumeroDeclaracion().toString().trim());// DUA trae dato err�neo
                        GrabarRectificacionService grabarRectificacionService =  (GrabarRectificacionService)fabricaDeServicios.getService("GrabarRectificacionServiceImpl");
                        
                        mpDeudasADesafectarVP.putAll(cargarDatosParaDesafectarGarantia160(resultadoTmp));
                        
                        //grabarRectificacionService.desafectarGarantia(declaracionBD.getDua(), resultadoTmp, variablesIngreso);
                        //Inicio RIN10 BUG 22604 
                        /*datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC);
                        datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_02);
                        enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);*/
                        

                        //datosNotificacion = new HashMap<String, String>();
                        //Fin RIN10 BUG 22604
                        resultadoTmp = new HashMap<String, String>();
                        resultadoTmp = liquidaDeclaracionService.generarLCVP(declaracion,variablesIngreso);
                        //Bug 21867 AFMA FSW
                        //lstDeudasAAfectarVP.addAll(cargarDatosAfectaGarantia160(datosNotificacion));
                        lstDeudasAAfectarVP.addAll(cargarDatosAfectaGarantia160(resultadoTmp));
                        datosNotificacion.putAll(resultadoTmp);
                        datosNotificacion.put("des_asunto", Constants.ASUNTO_NOTIF_ANULACION_EMISION_LC);
                        datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_07);
                        enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                        variablesIngreso.put("VALORPROVISIONALCDA", resultadoTmp.get("cda"));
                    }
                }//2.2.2.	Rectificaci�n de DUA(s) SIN Garant�a del Art�culo 160� de la LGA para acogerse a la Garant�a Art�culo 160� LGA
                else if(duaSinGarantia160){
                    BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                    BigDecimal montoLC = obtenerMontoLCGeneradaVP(declaracion);
					//sigesi 
					//mordonezl
					BigDecimal diferenciaAjuste = SunatNumberUtils.absoluteDiference(montoLC, mtoSaldoPorCubrir);
					BigDecimal tolerancia = new BigDecimal(1);  //1 dolar
                   //amancilla cambio 
					//if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(montoLC) == 1 && diferenciaAjuste.compareTo(tolerancia) == 1){
                    if(tieneLCVPGenerado(montoLC) &&  diferenciaAjuste.compareTo(tolerancia) == 1){//pase24 mordonezl // PAS20171U220200048 -- se ajusta comparacion 

                        LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
                        // si existe una lc asociada a la declaracion, se procede a anular
                        Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);

                        Map datosNotificacion = new HashMap<String, String>();
                        datosNotificacion.putAll(resultadoTmp);
                        resultadoTmp = new HashMap<String, String>();
                        resultadoTmp = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
                        //Bug 21867 AFMA FSW
                        //lstDeudasAAfectarVP.addAll(cargarDatosAfectaGarantia160(datosNotificacion));
                        lstDeudasAAfectarVP.addAll(cargarDatosAfectaGarantia160(resultadoTmp));
                        datosNotificacion.putAll(resultadoTmp);
                        datosNotificacion.put("des_asunto", Constants.ASUNTO_NOTIF_ANULACION_EMISION_LC);
                        datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_08);
                        enviarNotificaciones(declaracion, declaracionBD, datosNotificacion);
                    }
                }
            }
        }

        }
        
        resultado.put("lstDeudasAAfectarVP", lstDeudasAAfectarVP);
        resultado.put("mpDeudasADesafectarVP", mpDeudasADesafectarVP);

       return resultado;
    }

    private void enviarNotificaciones(Declaracion declaracion, Declaracion declaracionBD, Map<String, String> datosNotificacion)
    {
        if (datosNotificacion.containsKey("codigo_plantilla")) {
        	DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
            // Notificamos al buz�n del importador
        	Map params=new HashMap();
            datosNotificacion.put("cod_usuario", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
//          <EHR>
          params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			String razonSocial = "";
			if (params!=null){
				razonSocial= Utilidades.retirarTildeParaAsuntoNotificacion(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()+":"+params.get("ddp_nombre").toString().trim().toUpperCase());
				datosNotificacion.put("des_ruc_razon_social", razonSocial);
			}else{ 
				razonSocial= Utilidades.retirarTildeParaAsuntoNotificacion(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()+":"+declaracion.getDua().getDeclarante().getNombreRazonSocial().toUpperCase());
				datosNotificacion.put("des_ruc_razon_social", razonSocial);
			}
//          </EHR>
            //datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getDeclarante().getNombreRazonSocial());
            try{

                GrabarRectificacionService grabarRectificacionService =  (GrabarRectificacionService)fabricaDeServicios.getService("GrabarRectificacionServiceImpl");

                grabarRectificacionService.grabarNotificacionesVP(declaracionBD, datosNotificacion);
            }catch(Exception e){
                log.error("Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n",e);
            }

            // Notificamos al buz�n del agente aduanero
            String codUsuario = declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad()!=null?declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad():declaracion.getDua().getNumdocumento();
            datosNotificacion.put("cod_usuario", codUsuario);
//			<EHR>
			//mapMsgLCVP.put("numruc_consig", declaracion.getDua().getNumdocumento());
			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null){ 
				razonSocial= Utilidades.retirarTildeParaAsuntoNotificacion(declaracion.getDua().getNumdocumento()+":"+params.get("ddp_nombre").toString().trim().toUpperCase());
				datosNotificacion.put("des_ruc_razon_social", razonSocial);
			}else{ 
				razonSocial= Utilidades.retirarTildeParaAsuntoNotificacion(declaracion.getDua().getNumdocumento()+":"+declaracion.getDua().getDeclarante().getNombreRazonSocial().toUpperCase());
				datosNotificacion.put("des_ruc_razon_social", razonSocial);
			}
//			</EHR>
            //datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getAgenteAduanas().getNombreRazonSocial());
            if(codUsuario!=null){
                try{

                    GrabarRectificacionService grabarRectificacionService =  (GrabarRectificacionService)fabricaDeServicios.getService("GrabarRectificacionServiceImpl");
                    grabarRectificacionService.grabarNotificacionesVP(declaracionBD, datosNotificacion);
                }catch(Exception e){
                    log.error("Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n",e);
                }
            }
        }
    }

    private Map cargarDatosParaDesafectarGarantia160(Map<String, String> datosNotificacion) {
		
		
           Map rspta = new HashMap();
		
		    Map deudaDUA = new HashMap();
		    
		    if(!CollectionUtils.isEmpty(datosNotificacion)){
			deudaDUA.put("TIPO", "LC");
			deudaDUA.put("CDA", datosNotificacion.get("cda_lc_anul"));
			deudaDUA.put("MONEDA", "D");
			BigDecimal monto = new BigDecimal(datosNotificacion.get("monto_lc_anul").toString());
			deudaDUA.put("MONTO", monto.setScale( 0, BigDecimal.ROUND_HALF_UP ));
			deudaDUA.put("LC", datosNotificacion.get("aduana_lc_anul").concat(datosNotificacion.get("anno_lc_anul")).concat("96").concat(datosNotificacion.get("numero_lc_anul")));
			deudaDUA.put("TIPOLC", "0010");
			deudaDUA.put("COD_ADULIQUIDA", datosNotificacion.get("aduana_lc_anul"));
			deudaDUA.put("ANN_LIQUIDA", datosNotificacion.get("anno_lc_anul"));
			deudaDUA.put("NUM_LIQUIDA", datosNotificacion.get("numero_lc_anul"));
			deudaDUA.put("ANNIO", datosNotificacion.get("anno_lc_anul"));
								
			rspta.put("0010",deudaDUA);
		   }
		    
			return rspta;
	}

	private List cargarDatosAfectaGarantia160(Map<String, String> datosNotificacion) {
		
		List lstAfectar = new ArrayList();
		
		if(!CollectionUtils.isEmpty(datosNotificacion)){
			Map deudaDUA = new HashMap();		
			deudaDUA.put("TIPO", "LC");
			deudaDUA.put("CDA", datosNotificacion.get("cda"));
			deudaDUA.put("MONEDA", "D");
			BigDecimal monto =datosNotificacion.get("monto_lc")!=null? new BigDecimal(datosNotificacion.get("monto_lc").toString()):new BigDecimal(0);
			deudaDUA.put("MONTO", monto.setScale( 0, BigDecimal.ROUND_HALF_UP ));
			deudaDUA.put("LC", datosNotificacion.get("aduana_lc").concat(datosNotificacion.get("anno_lc")).concat("96").concat(datosNotificacion.get("numero_lc")));
			deudaDUA.put("TIPOLC", "0010");
			deudaDUA.put("COD_ADULIQUIDA", datosNotificacion.get("aduana_lc"));
			deudaDUA.put("ANN_LIQUIDA", datosNotificacion.get("anno_lc"));
			deudaDUA.put("NUM_LIQUIDA", datosNotificacion.get("numero_lc"));
			lstAfectar.add(deudaDUA);	
			
		}
						
		return lstAfectar;
	}

    private boolean tieneGarantia159(Declaracion declaracion) {
    	boolean lcVPEstaAfectadaGarantia159 =  false;//RIN10 Refactoring
    	//<KAH-RIN10>
    	// buscar si tiene garant�a 159
    	List<Map<String, Object>> resultGarantia159 = new ArrayList<Map<String,Object>>();
		//obtener la LC					
		Map<String, Object> paramsGetLCVP = new HashMap<String, Object>();
		paramsGetLCVP.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		paramsGetLCVP.put("COD_REGIMEN",declaracion.getDua().getCodregimen());
		paramsGetLCVP.put("COD_ADUANA", declaracion.getCodaduana());
		paramsGetLCVP.put("ANN_PRESEN", declaracion.getDua().getAnnpresen().toString().substring(2));//en liquida el a�o solo tiene dos digitos);
		paramsGetLCVP.put("NUM_DECLARACION", SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0'));//en liquida el num_decla tiene 6 digitos
		LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
		if (liquidaDeclaracionService.verificarDeclaracionConLCGenerada(paramsGetLCVP)){//Si la DUA tiene una LC(VP)
			//Inicio RIN10 Refactoring
//			Map<String, Object> paramsCtaCte159 = new HashMap<String, Object>();
//			//LC(VP) con garantia 159�
//			paramsCtaCte159.put("PADUANA", declaracion.getCodaduana());
//			paramsCtaCte159.put("PANO", declaracion.getDua().getAnnpresen());
//			paramsCtaCte159.put("PREGIMEN", " ");
//			paramsCtaCte159.put("PNUMERO", paramsGetLCVP.get("NUM_LIQUIDA_LCVP"));
//		
//			MovNGarantiaDAO movNGarantiaDAO = fabricaDeServicios.getService("movNGarantiaDefRead");
//			resultGarantia159 = movNGarantiaDAO.buscarGarantia159(paramsCtaCte159);
			lcVPEstaAfectadaGarantia159 = lcVPEstaAfectadaGarantia159(declaracion,paramsGetLCVP.get("NUM_LIQUIDA_LCVP").toString());
			//Fin RIN10 Refactoring
		}
		//Inicio RIN10 Refactoring
    	//return !CollectionUtils.isEmpty(resultGarantia159)?true:false;
		//</KAH-RIN10>
		return lcVPEstaAfectadaGarantia159;
		//Fin RIN10 Refactoring
    }
    
    //Inicio RIN10 BUG 22106
    private boolean lcVPEstaAfectadaGarantia159(Declaracion declaracion,String numLiquidacion){
			Map<String, Object> paramsCtaCte159 = new HashMap<String, Object>();
			paramsCtaCte159.put("PADUANA", declaracion.getCodaduana());
			paramsCtaCte159.put("PANO", declaracion.getDua().getAnnpresen());
			paramsCtaCte159.put("PREGIMEN", " ");
		paramsCtaCte159.put("PNUMERO", numLiquidacion);
			MovNGarantiaDAO movNGarantiaDAO = fabricaDeServicios.getService("movNGarantiaDefRead");
		List<Map<String, Object>> resultGarantia159 = new ArrayList<Map<String,Object>>();
			resultGarantia159 = movNGarantiaDAO.buscarGarantia159(paramsCtaCte159);
		return (!CollectionUtils.isEmpty(resultGarantia159));
		}
  //Fin RIN10 BUG 22106

    private void retirarIndicadorVP(Declaracion declaracion) {
        // Se retira el indicador de valor provisional
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
        params.put("COD_INDICADOR", COD_INDICADOR_VP);
        params.put("IND_ACTIVO", INACTIVO_TABLE_INDICADOR_DUA);

        IndicadorDUADAO indicadorDUADAO =  (IndicadorDUADAO)fabricaDeServicios.getService("indicadorDUADAO");

        indicadorDUADAO.updateByRectificacion(params);
    }

    private void verificarFechaFinVPDiaInhabil(Declaracion declaracion) {

        // Fin erodriguezb RIN10 3003
        Map<String, Object> pFecha = new HashMap<String, Object>(); //select fnCalculaDias(20111101,0,'U','2','S','N') from dual
        int operacion = 2; //2: Sumatoria de d�as
        String tipodia = "U"; //U: d�a Calendario
        String incluye = "S"; //N: Se cuenta del dia siguiente
        String alcance = "S"; //N: No cuenta las fechas suspendidas�.cat_suspende
        pFecha.put("NUMDIAS", 0);
        pFecha.put("TIPODIA", tipodia);
        pFecha.put("OPERACION", operacion);
        pFecha.put("INCLUYE", incluye);
        pFecha.put("ALCANCE", alcance);
        pFecha.put("COD_ADUANA", declaracion.getCodaduana());
        pFecha.put("FECHAINICIAL", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecfinprovsional()));

        // INICIO DE VALIDACI�N DE FECHA FIN DE VALOR PROVISIONAL
        Date fechaCalculada = declaracion.getDua().getFecfinprovsional();

        FuncionesFechaService funcionesFechaService = (FuncionesFechaService) fabricaDeServicios.getService("FuncionesFechaService");
        String fechaLaborable = funcionesFechaService.obtenerSgteDiaUtil(pFecha);

        if(fechaLaborable != null && !fechaLaborable.equals(0) & !fechaLaborable.equals("")){
            fechaCalculada = SunatDateUtils.getDateFromInteger(Integer.parseInt(fechaLaborable));
        }

        //Si la fecha ha sido cambiada por ser d�a no laborable
        if(!SunatDateUtils.sonIguales(declaracion.getDua().getFecfinprovsional(), fechaCalculada, SunatDateUtils.COMPARA_SOLO_FECHA)){


            //Actualizamos fecha fin de VP del formato A
            declaracion.getDua().setFecfinprovsional(fechaCalculada);

            //Actualizamos fecha fin de VP de los items del formato B
            if (!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
                for (DAV dav : declaracion.getListDAVs()) {
                    for (DatoFactura factura : dav.getListFacturas()) {
                        for (DatoItem item : factura.getListItems()) {
                            if(item.getMontoProv().getValmonto()!=null)
                                item.getMontoProv().setFecvalestima(fechaCalculada);
                        }
                    }
                }
            }

            //TODO: Y para este caso se env�a al agente de aduana y al importador una notificaci�n a sus respectivos buzones SOL: "SE CAMBIO LA FECHA FIN DEL VALOR PROVISIONAL AL SIGUIENTE DIA HABIL".
            //NO HAY PLANTILLA HAY Q CREARLA
        }
    }
//mol pase24
    public List validarValorProvisionalParaRectificacionProcedenteEnParte(Declaracion declaracion,Declaracion declaracionBD, String tieneIncTrib) throws Exception
    {

        List lstErrores = new ArrayList();

        if(!cumpleRequisitosParaValidarCoberturaMontoVP(declaracion)){
            return lstErrores;
        }

        ValRectif valRectif =  fabricaDeServicios.getService("ValRectif");
        boolean tieneIndicadorVP = valRectif.validaIndicadorVP(declaracionBD);
        //boolean tieneAlMenos1ItemVP = FormatoBUtils.validaItemTransmisionVP(declaracion);
        //afma para que entre al caso no esta entrando cuando no marca indicador de valor provisional
        //para que salga exceciopn 11
        //SE ELIMINA DADO QUE NO FILTRA BIEN CUANDO NO SE ENVIA VALOR PROVISIONA boolean tieneAlMenos1ItemVP = FormatoBUtils.validaTransmisionValorFormatoB(declaracion);
        boolean tieneAlMenos1ItemVP = FormatoBUtils.tieneAlMenos1ItemVP(declaracion);
                                     
        boolean tieneIndicadorLCVP = tieneIndicadorParaGenerarLCVPActivo(declaracion);
        String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        String codGarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        boolean duaConGarantia160 = !SunatStringUtils.isEmptyTrim(codGarantia) && !SunatStringUtils.isEmptyTrim(codGarantiaBD);
        boolean duaSinGarantia160 = SunatStringUtils.isEmptyTrim(codGarantia) && SunatStringUtils.isEmptyTrim(codGarantiaBD);


        // 1. DUA SIN Valor Provisional
        if(!tieneIndicadorVP){

            if(tieneAlMenos1ItemVP){

                lstErrores.addAll(validarCorrelacionDatosVPMarcados(declaracion));

                //deveulve para que valide datos basicos
                /* TODO: desde mi punto de vista no deberia seuir validando si hay errores
                de comenta codigo para que salgan todos los errroes
                if(!CollectionUtils.isEmpty(lstErrores)){
                    return lstErrores;
                }*/

                // 1.1.	DUA(s) CON Garant�a del Art�culo 160� de la LGA
                if(duaConGarantia160 && !tieneIndicadorVP && tieneAlMenos1ItemVP && tieneIndicadorLCVP ){
                    BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                    if(tieneIncTrib.equals("S")){
                    lstErrores.addAll(validarGarantia160CubraMonto(declaracion, mtoSaldoPorCubrir));
                    }
                }else if(duaSinGarantia160 && !tieneIndicadorVP){
                    //1.2.1 Rectificaci�n sin acogerse a la garant�a Art�culo 160� LGA
                    lstErrores.addAll(validarCorrelacionDatosVPMarcados2(declaracion));
                    if(tieneIndicadorLCVP){
                        //Excepci�n 6 es igual que la Expecion 3 solo que el mensaje es un poco difernete
                        if( !CollectionUtils.isEmpty(validarLCVPEsteGarantizadaConGarantia159(declaracion))){
                            //Excepci�n 6
                            lstErrores.add(addError("000000", "LC DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA"));
                        }
                    }
                }
            }

        }else{//2. DUA(s) CON Valor Provisional

            //2.1 Rectificaci�n electr�nica del Valor Provisional que cambia a Valor Definitivo todos los �tems
            boolean tieneTodosItemsConValorDefinitivo = cumpleRequisitosParaValidarDUAConVPRegularizada(declaracion);
            if(tieneTodosItemsConValorDefinitivo){
                lstErrores.addAll(validarRegularizacionVP(declaracion,declaracionBD));
            } else if(tieneAlMenos1ItemVP){

                lstErrores.addAll(validarCorrelacionDatosVPMarcadosCuandoConcerbaAlMenos1ItemVP(declaracion));
                //2.2.1.	Rectificaci�n CON Garant�a 160� y cuente con indicador de generaci�n de LC(VP)
                if(duaConGarantia160 && tieneIndicadorLCVP){

                    BigDecimal mtoSaldoPorCubrir = obtenerSaldoPorCubrir(declaracion);
                    BigDecimal montoLC = obtenerMontoLCGeneradaVP(declaracion);
                    if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(montoLC) == 1){
                    	if(tieneIncTrib.equals("S")){
                        lstErrores.addAll(validarGarantia160CubraMontoVP(declaracion, mtoSaldoPorCubrir.subtract(montoLC)));//gmontoya Pase 24
                    	 }
                    }
                }//2.2.2.	Rectificaci�n de DUA(s) SIN Garant�a Art�culo 160� LGA y sin acogerse a la Garant�a Art�culo 160� LGA

                else if(duaSinGarantia160 && tieneIndicadorLCVP){
                    //Excepci�n 6 es igual que la Expecion 3 solo que el mensaje es un poco difernete
                    if( !CollectionUtils.isEmpty(validarLCVPEsteGarantizadaConGarantia159(declaracion))){
                        //Excepci�n 6
                        lstErrores.add(addError("000000", "LC DE VALOR PROVISIONAL NO SE ENCUENTRA GARANTIZADA"));
                    }
                }
            }
        }

        return lstErrores;
    }

    /**
     *
     *  Valida que exista LC, si existe que este garantizada
     * @param declaracion
     * @return lstErrores VACIA si la LC no existe o esta garantizada
     */
    private List validarLCVPEsteGarantizadaConGarantia159(Declaracion declaracion)
    {

        List lstErrores = new ArrayList();

        boolean noEstaGarantizadaLC = true;
        // Obtener las LC que no estan garantizadas
        DeudaDocum tmpDeudaDocum = new DeudaDocum();
        tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
        tmpDeudaDocum.setCodTipdeuda(ConstantesDataCatalogo.DEUDA_TIPO_LIQ_COBR);
        tmpDeudaDocum.setCodEstadmin("I"); //garantia 159 pone tipon cancelacion 7 y replica como impugnado


//busca la LC aun no sabemos si esta garantizda
        List<DeudaDocum> result = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).obtenerLiquidacion(tmpDeudaDocum);

        BigDecimal montoLC = BigDecimal.ZERO;
        if (!CollectionUtils.isEmpty(result)){
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("rlarea", declaracion.getDua().getCodregimen());
            params.put("rladuaso", declaracion.getCodaduana());
            params.put("rlanoaso", declaracion.getDua().getAnnpresen().toString().substring(2));

            String numAso = declaracion.getNumeroDeclaracion().toString();
            numAso = SunatStringUtils.lpad(numAso, 6, '0');

            params.put("rlnumaso", numAso);
            params.put("LIST_RLNROLIQ", result);
            params.put("indValprov", TIENE_VALOR_PROVISIONAL);
            params.put("rlfeceli","0");

            Liquida liquida = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).getLCbyDeclaAndNumLiquida(params);

            if(liquida!=null){
            montoLC = "S".equals(liquida.getRlcodmon())?liquida.getRlsmontot():liquida.getRldmontot();
            montoLC = montoLC != null? montoLC : BigDecimal.ZERO;
                String tipoCancelacion = liquida.getRltipcan()!=null?liquida.getRltipcan().toString().trim():"";
                noEstaGarantizadaLC = "7".equals(tipoCancelacion)?false:true;
            }
        }

        //indica que si existe LC sin garantizar
        if( tieneLCVPGenerado(montoLC)){
            if(noEstaGarantizadaLC){
                //Excepci�n 3
                lstErrores.add(addError("000000", "LC DE VALOR PROVISIONAL DEBE SER GARANTIZADA"));
            }
        }

        return lstErrores;


    }

    private Map addError(String codError, String desError)
    {
        Map mapError = new HashMap();
        mapError.put("codTipAlerta","E");
        mapError.put("codError",codError);
        mapError.put("desError",desError);
        return mapError;
    }
    
    //inicio gmontoya Pase24
    private List validarGarantia160CubraMontoVP(Declaracion declaracion, BigDecimal mtoSaldoPorCubrir){
    	CabCtaCteGarDAO cabCtaCteGarDAO = (CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef");
    	List lstErrores = new ArrayList();
        if(mtoSaldoPorCubrir.compareTo(BigDecimal.ZERO)==0){return lstErrores;}
        String codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();

        Map mapParam = new HashMap();

        mapParam.put("NUMCTACTE", codGarantia.trim());
        mapParam.put("FECHAPROCESO", DateUtil.getToday());
        mapParam.put("IND_ACTIVO", Constantes.IND_ACTIVO);
        Map mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);
        
        if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {
        	mapParam.put("IND_ACTIVO", "2"); //verificamos que sea renovada
        	mapParam.put("FECHAPROCESO", declaracion.getDua().getFecdeclaracion());//verificamos que haya estado vigente en la fecha de numeraci�n
            mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);
        }

        //Si no trajo datos, no est� activa
        if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {

            //Excepci�n 1
            lstErrores.add( getErrorMap("35197", "LA CTA. CTE. DE LA GARANT�A NO EST� VIGENTE"));

        }else{
            BigDecimal saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null?
                    new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;
            // Si garant�a no cubre...
            //Excepci�n 2
            if (saldoOperativo.compareTo(mtoSaldoPorCubrir) < 0){
                lstErrores.add( getErrorMap("35196", "LA CTA. CTE. DE LA GARANT�A NO TIENE SALDO OPERATIVO"));

            }
        }

        return lstErrores;
    }
    //fin gmontoya Pase 24

    private List validarGarantia160CubraMonto(Declaracion declaracion, BigDecimal mtoSaldoPorCubrir)
    {
    	CabCtaCteGarDAO cabCtaCteGarDAO = (CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef");
        List lstErrores = new ArrayList();
        if(mtoSaldoPorCubrir.compareTo(BigDecimal.ZERO)==0){return lstErrores;}
        String codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();

        Map mapParam = new HashMap();

        mapParam.put("NUMCTACTE", codGarantia.trim());
        mapParam.put("FECHAPROCESO", DateUtil.getToday());
        mapParam.put("IND_ACTIVO", Constantes.IND_ACTIVO);
        Map mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);
        if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {
        	mapParam.put("IND_ACTIVO", "2"); //verificamos que sea renovada
        	mapParam.put("FECHAPROCESO", declaracion.getDua().getFecdeclaracion());//verificamos que haya estado vigente en la fecha de numeraci�n
        	 Map  mapCabCtaCteGarRenovada = cabCtaCteGarDAO.findByNumCtaCte(mapParam);
        	  if (!CollectionUtils.isEmpty(mapCabCtaCteGarRenovada)) {
        	       //Excepci�n 0
                  lstErrores.add( getErrorMap("30815", "NO SE PERMITE ACOTAR DEUDA A UNA GARANTIA PREVIA RENOVADA, REQUIERE AUTOLIQUIDARSE"));
                  return lstErrores;
        	  }
        }

        //Si no trajo datos, no est� activa
        if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {

            //Excepci�n 1
            lstErrores.add( getErrorMap("35197", "LA CTA. CTE. DE LA GARANT�A NO EST� VIGENTE"));

        }else{
            BigDecimal saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null?
                    new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;
            // Si garant�a no cubre...
            //Excepci�n 2
            if (saldoOperativo.compareTo(mtoSaldoPorCubrir) < 0){
                lstErrores.add( getErrorMap("35196", "LA CTA. CTE. DE LA GARANT�A NO TIENE SALDO OPERATIVO"));

            }
        }

        return lstErrores;
    }

    private List garantia159Cubre(Declaracion declaracion, BigDecimal mtoSaldoPorCubrir)
    {
    	CabCtaCteGarDAO cabCtaCteGarDAO = (CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef");
        List lstErrores = new ArrayList();
        if(mtoSaldoPorCubrir.compareTo(BigDecimal.ZERO)==0){return lstErrores;}

        String codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
        Map mapParam = new HashMap();

        mapParam.put("NUMCTACTE", codGarantia.trim());
        mapParam.put("FECHAPROCESO", DateUtil.getToday());
        mapParam.put("IND_ACTIVO", Constantes.IND_ACTIVO);
        Map mapCabCtaCteGar = cabCtaCteGarDAO.findByNumCtaCte(mapParam);

        //Si no trajo datos, no est� activa
        if (CollectionUtils.isEmpty(mapCabCtaCteGar)) {
            lstErrores.add( getErrorMap("35197", "LA CTA. CTE. DE LA GARANT�A NO EST� VIGENTE"));

        }else{
            BigDecimal saldoOperativo = mapCabCtaCteGar.get("MTOSALDOOPEDISP")!=null?
                    new BigDecimal(mapCabCtaCteGar.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;
            // Si garant�a no cubre...
            if (saldoOperativo.compareTo(mtoSaldoPorCubrir) < 0){
                lstErrores.add( getErrorMap("35196", "LA CTA. CTE. DE LA GARANT�A NO TIENE SALDO OPERATIVO"));

            }
        }

        return lstErrores;
    }

    /**
     * Obtiene el monto de la LC de VP generada para cubrir la deuda
     * @param declaracion
     * @return montoLC ZERO si no hay LC
     */
    public BigDecimal obtenerMontoLCGeneradaVP(Declaracion declaracion)
    {

        // Obtener n�mero de liquidaci�n
        DeudaDocum tmpDeudaDocum = new DeudaDocum();
        tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
        tmpDeudaDocum.setCodTipdeuda(ConstantesDataCatalogo.DEUDA_TIPO_LIQ_COBR);
        //tmpDeudaDocum.setMtoGarant(BigDecimal.ZERO);   PAS20171U220200048 - DAMS que no son 160 no tiene registrado mto_garant 


        List<DeudaDocum> result = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).obtenerLiquidacion(tmpDeudaDocum);

        BigDecimal montoLC = BigDecimal.ZERO;
        if (!CollectionUtils.isEmpty(result)){
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("rlarea", declaracion.getDua().getCodregimen());
            params.put("rladuaso", declaracion.getCodaduana());
            params.put("rlanoaso", declaracion.getDua().getAnnpresen().toString().substring(2));
            String numAso = declaracion.getNumeroDeclaracion().toString();
            numAso = SunatStringUtils.lpad(numAso, 6, '0');
            params.put("rlnumaso", numAso);
            params.put("LIST_RLNROLIQ", result);
            params.put("indValprov", TIENE_VALOR_PROVISIONAL);
            params.put("rlfeceli","0");

            Liquida record = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).getLCbyDeclaAndNumLiquida(params);
            montoLC = "S".equals(record.getRlcodmon())?record.getRlsmontot():record.getRldmontot();
            montoLC = montoLC != null? montoLC : BigDecimal.ZERO;

        }
        return montoLC;
    }



    public BigDecimal obtenerSaldoPorCubrir(Declaracion declaracion)
    {
    	DataCatalogoDAO dataCatalogoDAO = (DataCatalogoDAO)fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
        DataCatalogo dataCatalogo =	dataCatalogoDAO.buscarDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP,
                        ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP);

        BigDecimal porcentajeBaseImponible = new BigDecimal(dataCatalogo.getDesCorta());


        //Obteniendo valor de base imponible
        BigDecimal sumaBaseImponibleSeries = BigDecimal.ZERO;
        for(DatoSerie serie : declaracion.getDua().getListSeries()){
            if(tieneMtoValido(serie.getValestimado())){
                //mtosegdol + mtoajuste + mtofledol + mtofobdol
                sumaBaseImponibleSeries = sumaBaseImponibleSeries.add(
                        serie.getMtoajuste()!=null?serie.getMtoajuste():BigDecimal.ZERO).add(
                        serie.getMtosegdol()!=null?serie.getMtosegdol():BigDecimal.ZERO).add(
                        serie.getMtofledol()!=null?serie.getMtofledol():BigDecimal.ZERO).add(
                        serie.getMtofobdol()!=null?serie.getMtofobdol():BigDecimal.ZERO);
            }

        }
        return sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal("100")));
    }




    private boolean cumpleRequisitosParaValidarDUAConVPRegularizada(Declaracion declaracion) throws Exception
    {
        return FormatoBUtils.validaTodosItemsValorDefinitivo(declaracion);
    }

    /*20052015 inicio rin10*/
    private boolean itemPasaDeVPaVD(DatoSerie serieRecti,DatoItem itemSerieRecti, String tipoValorItemRecti, Declaracion declaracionBD){
    	
    	int numSerieRecti = serieRecti.getNumserie();
    	int numItemSerieRecti = itemSerieRecti.getNumsecitem();
    	
    	for(DatoSerie serieBD : declaracionBD.getDua().getListSeries()){
    		
    		if(serieBD.getNumserie() == numSerieRecti){
    			
    			for(DatoItem datoItemBD : FormatoBUtils.getItemsSeries(declaracionBD.getListDAVs(), serieBD)){
        			
    				if(datoItemBD.getNumsecitem() == numItemSerieRecti){
    					
    					return tipoValorItemRecti.equals("1") && datoItemBD.getMontoProv().getIndtipovalor().equals("2") ? true : false;
    					
    				}
    				
        		}
    		}
    	}
    	
    	return false;
    }
    /*fin rin10*/

    private List validarRegularizacionVP(Declaracion declaracion, Declaracion declaracionBD)
    {
    	CabDiligenciaDAO cabdiligenciaDAO =  (CabDiligenciaDAO)fabricaDeServicios.getService("cabdiligenciaDAO");
        List lstErrores = new ArrayList();
        lstErrores.addAll(validarFechasDeRegularizacionVP(declaracion));


        //Verifico si tiene diligencia de despacho
        Map mapDiligencia = cabdiligenciaDAO.findDuaDiligenciada(declaracion.getDua().getNumcorredoc().toString());
        boolean  duaTieneFFVP = tieneRegistradaFechaDefault(declaracion.getDua().getFecfinprovsional());
        //2.1.1.	Antes de la Diligencia de Despacho
        if (CollectionUtils.isEmpty(mapDiligencia)) {
        	
        	    /*AFMA se trasalta al final
                //excepcion 16
                if(tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional()) ){
                    lstErrores.add(addError("000000", "DEBE MARCAR LA FECHA FIN DEL VALOR PROVISONAL CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO"));
                }*/

        	    boolean itemTieneFFVP= false;
                for(DatoSerie serie : declaracion.getDua().getListSeries())
                {

                    boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
                    boolean itemTieneVE=false;
                   

                    StringBuilder itemsDeLaSerie = new StringBuilder();
                    StringBuilder itemsDeLaSerieConFFVP = new StringBuilder();
                    StringBuilder itemsDeLaSerieSinFFVP = new StringBuilder();
                    StringBuilder itemsDeLaSerieConVE = new StringBuilder();
                    StringBuilder itemsDeLaSerieSinVE = new StringBuilder();

                    for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
                    {
                        itemsDeLaSerie.append(datoItem.getNumsecitem());
                        itemsDeLaSerie.append(", ");
                        if(tieneRegistradaFechaDefault(datoItem.getMontoProv().getFecvalestima())){
                            itemTieneFFVP=true;
                            itemsDeLaSerieConFFVP.append(datoItem.getNumsecitem());
                            itemsDeLaSerieConFFVP.append(", ");
                        }else{
                        	 itemTieneFFVP=false;
                            itemsDeLaSerieSinFFVP.append(datoItem.getNumsecitem());
                            itemsDeLaSerieSinFFVP.append(", ");
                        }

                        String tipoValorRecti = datoItem.getMontoProv().getIndtipovalor(); //rin10 20052015
                        
                        //if(tieneMtoValido(datoItem.getMontoProv().getValmonto()) && !itemPasaDeVPaVD(serie,datoItem,tipoValorRecti,declaracionBD)){//rin10 20052015 agrego -> && !itemPasaDeVPaVD...
                        // r2bz no funciona cuando se realiza regularizaciones parciales
                        if(tieneMtoValido(datoItem.getMontoProv().getValmonto()) && SunatStringUtils.isEqualTo(datoItem.getMontoProv().getIndtipovalor(),Constantes.IND_VALPROV) ){
                            itemTieneVE=true;
                            itemsDeLaSerieConVE.append(datoItem.getNumsecitem());
                            itemsDeLaSerieConVE.append(", ");
                        }else{
                            itemsDeLaSerieSinVE.append(datoItem.getNumsecitem());
                            itemsDeLaSerieSinVE.append(", ");
                        }
                    }

                   
                    /*
                    if(duaTieneFFVP && itemTieneFFVP && !StringUtils.isEmpty(itemsDeLaSerieSinFFVP.toString())){
                        //Excepci�n  16
                        lstErrores.add(addError("000000", "DEBE MARCAR LA FECHA FIN DEL VALOR PROVISONAL CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO, LOS ITEMS: "+itemsDeLaSerieSinFFVP.toString()+" NO TIENEN FECHA FIN DE VALOR PROVISIONAL"));
                    }

                    if(!duaTieneFFVP && itemTieneFFVP && !StringUtils.isEmpty(itemsDeLaSerieConFFVP.toString())){
                        //Excepci�n  16
                        lstErrores.add(addError("000000", "DEBE MARCAR LA FECHA FIN DEL VALOR PROVISONAL CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO"));
                    }*/

                    if(serieTieneVE && !StringUtils.isEmpty(itemsDeLaSerieSinVE.toString())){
                        //Excepci�n  17 OK
                        lstErrores.add(addError("000000", "DEBE MARCAR TODOS LOS VALORES ESTIMADOS TANTO DE LAS SERIES: "+serie.getNumserie()  +" COMO DE LOS ITEMS DEL FORMATO B, ITEMS SIN MARCAR: "+itemsDeLaSerieSinVE.toString()));
                    }

                    if(!serieTieneVE && !StringUtils.isEmpty(itemsDeLaSerieConVE.toString())){
                        //Excepci�n  17 VICEVERSA
                        lstErrores.add(addError("000000", "DEBE MARCAR TODOS LOS VALORES ESTIMADOS TANTO DE LAS SERIES COMO DE LOS ITEMS DEL FORMATO B, SERIE SIN MARCAR: "+serie.getNumserie()));
                    }
                    //Excepci�n 13
                    /*
                    if(itemTieneVE && tieneMtoValido(serie.getValestimado())){
                        lstErrores.add(addError("000000", "DEBE MARCAR VALOR ESTIMADO CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO, DEBE MARCAR VALOR ESTIMADO DE LA SERIE: "+ serie.getNumserie() ));
                    }*/
                }
                
                if(!duaTieneFFVP || !itemTieneFFVP){
                    //Excepci�n  16
                    lstErrores.add(addError("000000", "DEBE MARCAR LA FECHA FIN DEL VALOR PROVISONAL CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO"));
                }

        }else{ //despues de la diligencia despacho

                for(DatoSerie serie : declaracion.getDua().getListSeries())
                {
                    boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
                    boolean itemTieneVE=false;
                    StringBuilder itemsDeLaSerieConVE = new StringBuilder();
                    StringBuilder itemsDeLaSerieSinVE = new StringBuilder();

                    for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
                    {

                        if(tieneMtoValido(datoItem.getMontoProv().getValmonto()) && SunatStringUtils.isEqualTo(datoItem.getMontoProv().getIndtipovalor(),Constantes.IND_VALPROV) ){
                            itemTieneVE=true;
                            itemsDeLaSerieConVE.append(datoItem.getNumsecitem());
                            itemsDeLaSerieConVE.append(", ");
                        }else{
                            itemsDeLaSerieSinVE.append(datoItem.getNumsecitem());
                            itemsDeLaSerieSinVE.append(", ");
                        }
                    }

                    if(serieTieneVE && !StringUtils.isEmpty(itemsDeLaSerieSinVE.toString())){
                        //Excepci�n  17 OK
                        lstErrores.add(addError("000000", "DEBE MARCAR TODOS LOS VALORES ESTIMADOS TANTO DE LAS SERIES: "+serie.getNumserie()  +" COMO DE LOS ITEMS DEL FORMATO B, ITEMS SIN MARCAR: "+itemsDeLaSerieSinVE.toString()));
                    }

                    if(!serieTieneVE && !StringUtils.isEmpty(itemsDeLaSerieConVE.toString())){
                        //Excepci�n  17 VICEVERSA
                        lstErrores.add(addError("000000", "DEBE MARCAR TODOS LOS VALORES ESTIMADOS TANTO DE LAS SERIES COMO DE LOS ITEMS DEL FORMATO B, SERIE SIN MARCAR: "+serie.getNumserie()));
                    }
                    /*//Excepci�n 13
                    if(itemTieneVE && tieneMtoValido(serie.getValestimado())){
                        lstErrores.add(addError("000000", "DEBE MARCAR VALOR ESTIMADO CUANDO SE RECTIFIQUE TODOS LOS ITEMS A VALOR DEFINITIVO, DEBE MARCAR VALOR ESTIMADO DE LA SERIE: "+ serie.getNumserie() ));
                    }*/
                }

           //especion 18
            if(!SunatDateUtils.sonIguales(declaracion.getDua().getFecfinprovsional(), declaracionBD.getDua().getFecfinprovsional(),
                    SunatDateUtils.COMPARA_SOLO_FECHA) ){
                lstErrores.add(addError("35213",
                        "FECHA FIN DE VALOR PROVISIONAL NO SE PUEDE RECTIFICAR"));
            }
        }

        return lstErrores;
    }

    private boolean tieneMtoValido(BigDecimal valmonto) {
		
		return valmonto!=null && valmonto.compareTo(BigDecimal.ZERO)==1?true:false;
	}

	private List validarFechasDeRegularizacionVP(Declaracion declaracion) {
        List lstErrores = new ArrayList();
        Map params = new HashMap();
        params.put("numcorredoc", declaracion.getDua().getNumcorredoc());
        CabAdiDeclaraDAO cabAdiDeclara = ((CabAdiDeclaraDAO)fabricaDeServicios.getService("cabAdiDeclara"));

        DUA dua = cabAdiDeclara.getByPrimaryKey(params);

        if (dua != null){
            if(tieneRegistradaFechaValida(dua.getFecRegOfiValProv())){
                //Excepci�n 5
                lstErrores.add(addError("000000", "DUA CUENTA CON REGULARIZACI�N DE VALOR PROVISIONAL DE OFICIO"));
            }
            if(tieneRegistradaFechaValida(dua.getFecRegulaValProv())){
                //Excepci�n 4
                lstErrores.add(addError("000000", "DUA CUENTA CON REGULARIZACI�N DE VALOR PROVISIONAL"));
            }
        }

        return lstErrores;
    }


    private List validarCorrelacionDatosVPMarcados(Declaracion declaracion)
    {
        List lstErrores = new ArrayList();

        boolean tieneAlMenos1ItemVP= false;
        boolean itemTieneFFVP= false;

        for(DatoSerie serie : declaracion.getDua().getListSeries())
        {
            boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
            boolean itemTieneVP= false;


            StringBuilder itemsDeLaSerie = new StringBuilder();
            StringBuilder itemsDeLaSerieConVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinVP = new StringBuilder();
            StringBuilder itemsDeLaSerieConFFVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinFFVP = new StringBuilder();

            for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
            {

                itemsDeLaSerie.append(datoItem.getNumsecitem());
                itemsDeLaSerie.append(", ");

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){
                    tieneAlMenos1ItemVP = true;
                    itemTieneVP=true;
                    itemsDeLaSerieConVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConVP.append(", ");
                }else{
                    itemsDeLaSerieSinVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinVP.append(", ");
                }
                if(tieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima())){
                    itemTieneFFVP=true;
                    itemsDeLaSerieConFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConFFVP.append(", ");
                }else{
                    itemsDeLaSerieSinFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinFFVP.append(", ");
                }

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){

                    if(!tieneMtoValido(datoItem.getMontoProv().getValmonto())) {
                        //Excepci�n 15
                        lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 ITEM: " +datoItem.getNumsecitem()+" DEBE MARCAR EL VALOR ESTIMADO"));
                    }

                    if(noTieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima()))
                    {
                        //Excepci�n 7
                        lstErrores.add(addError("000000", "SI AL MENOS UNO DE LOS ITEMS : " +datoItem.getNumsecitem()+ " TIENE VALOR PROVISIONAL, ENTONCES DEBE ACEPTAR LA FECHA FIN DEL VALOR PROVISIONAL"));
                    }
                }else{

                    if(tieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima()))
                    {
                        //Excepci�n 7
                        lstErrores.add(addError("000000", "SI EL ITEM: " +datoItem.getNumsecitem()+ " TIENE FECHA FIN DEL VALOR PROVISIONAL, ENTONCES DEBE ACEPTAR TIPO 2 DE VALOR PROVISIONAL"));
                    }

                    if(tieneMtoValido(datoItem.getMontoProv().getValmonto()))
                    {
                        //Excepci�n 11
                        lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO DEBE MARCAR TIPO DE VALOR 2 EN EL MISMO ITEM: " +datoItem.getNumsecitem()+" DEL FORMATO B"));
                    }
                    //viceversa
                    if(tieneMtoValido(datoItem.getMontoProv().getValmonto())) {
                        //Excepci�n 15
                        lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO ITEM: " +datoItem.getNumsecitem()+" DEBE MARCAR TIPO DE VALOR 2 EN EL MISMO ITEM DEL FORMATO B"));
                    }

                }


            }

            if(itemTieneVP && !StringUtils.isEmpty(itemsDeLaSerieSinVP.toString())){
                //Excepci�n  9
                lstErrores.add(addError("000000", "TODOS LOS ITEMS: "+ itemsDeLaSerie.toString()+ " ASOCIADOS A LA MISMA SERIE: "+ serie.getNumserie()+" CON VALOR PROVISIONAL DEBEN TENER  CONSIGNADO EL C�DIGO 2 EN LA CASILLA 5.6 DEL FORMATO B, ITEMS CON VALOR PROVISIONAL: "+itemsDeLaSerieConVP.toString()+" ITEMS SIN VALOR PROVISIONAL: "+itemsDeLaSerieSinVP.toString()));

            }

            //Excepci�n 13
            if(!serieTieneVE && itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 EN LOS ITEMS: "+ itemsDeLaSerieConVP.toString() +" DEL FORMATO B DEBE MARCAR VALOR ESTIMADO DE LA SERIE: "+ serie.getNumserie()+" CORRELACIONADA DEL FORMATO A"));
            }
            //Excepci�n 12
            if(serieTieneVE && !itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO A NIVEL DE LA SERIE: "+ serie.getNumserie()+" DEBE MARCAR TIPO DE VALOR 2 EN LOS ITEMS: "+itemsDeLaSerieSinVP.toString()+" CORRELACIONADOS DEL FORMATO B"));
            }
            //Excepci�n 20
            if(serieTieneVE==false && itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 EN LOS ITEMS : "+ itemsDeLaSerieConVP.toString()+" DEL FORMATO B DEBE MARCAR VALOR ESTIMADO A NIVEL DE LA SERIE: "+ serie.getNumserie()+" CORRELACIONADA DEL FORMATO A"));
            }
        }

        //Excepci�n 14
        if(tieneAlMenos1ItemVP && noTieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())){
                lstErrores.add(addError("000000", "SI AL MENOS UNO DE LOS ITEMS TIENE VALOR PROVISIONAL, ENTONCES DEBE INDICAR LA FECHA FIN DEL VALOR PROVISIONAL DE LA DECLARACION"));
        }

        //Excepci�n 10
        if(tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional()) && !tieneAlMenos1ItemVP){
                lstErrores.add(addError("000000", "SI MARCA FECHA FIN DEL VALOR PROVISIONAL EN LA DECLARACION, ALGUNO DE LOS �TEMS DEBE TENER EL CODIGO DE VALOR PROVISIONAL"));
        }
        //Excepci�n 19 Y Excepci�n 8 SON LO MISMO solo cambia el mensaje
        if((itemTieneFFVP && noTieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())
                ||(!itemTieneFFVP && tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())))){
            //Excepci�n  8
            lstErrores.add(addError("000000", "SI ACEPTO LA FECHA FIN DE VALOR PROVISIONAL DE AL MENOS UNO DE LOS ITEMS DEL FORMATO B, DEBE ACEPTAR TAMBIEN LA FECHA FIN DE VALOR PROVISIONAL DE LOS DATOS GENERALES DEL FORMATO A"));
        }


        return lstErrores;
    }


    private List validarCorrelacionDatosVPMarcados2(Declaracion declaracion)
    {
        List lstErrores = new ArrayList();

        boolean tieneAlMenos1ItemVP= false;
        boolean itemTieneFFVP= false;

        for(DatoSerie serie : declaracion.getDua().getListSeries())
        {
            boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
            boolean itemTieneVP= false;


            StringBuilder itemsDeLaSerie = new StringBuilder();
            StringBuilder itemsDeLaSerieConVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinVP = new StringBuilder();
            StringBuilder itemsDeLaSerieConFFVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinFFVP = new StringBuilder();

            for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
            {

                itemsDeLaSerie.append(datoItem.getNumsecitem());
                itemsDeLaSerie.append(", ");

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){
                    tieneAlMenos1ItemVP = true;
                    itemTieneVP=true;
                    itemsDeLaSerieConVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConVP.append(", ");
                }else{
                    itemsDeLaSerieSinVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinVP.append(", ");
                }
                if(tieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima())){
                    itemTieneFFVP=true;
                    itemsDeLaSerieConFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConFFVP.append(", ");
                }else{
                    itemsDeLaSerieSinFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinFFVP.append(", ");
                }

            }

            if(itemTieneVP && !StringUtils.isEmpty(itemsDeLaSerieSinVP.toString())){
                //Excepci�n  9
                lstErrores.add(addError("000000", "TODOS LOS ITEMS: "+ itemsDeLaSerie.toString()+ " ASOCIADOS A LA MISMA SERIE: "+ serie.getNumserie()+" CON VALOR PROVISIONAL DEBEN TENER  CONSIGNADO EL C�DIGO 2 EN LA CASILLA 5.6 DEL FORMATO B, ITEMS CON VALOR PROVISIONAL: "+itemsDeLaSerieConVP.toString()+" ITEMS SIN VALOR PROVISIONAL: "+itemsDeLaSerieSinVP.toString()));

            }


        }

        //Excepci�n 19 Y Excepci�n 8 SON LO MISMO solo cambia el mensaje
        if((itemTieneFFVP && noTieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())
                ||(!itemTieneFFVP && tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())))){
        //Excepci�n  8
        lstErrores.add(addError("000000", "SI ACEPTO LA FECHA FIN DE VALOR PROVISIONAL DE AL MENOS UNO DE LOS ITEMS DEL FORMATO B, DEBE ACEPTAR TAMBIEN LA FECHA FIN DE VALOR PROVISIONAL DE LOS DATOS GENERALES DEL FORMATO A"));
    }


        return lstErrores;
    }

    private List validarCorrelacionDatosVPMarcadosCuandoConcerbaAlMenos1ItemVP(Declaracion declaracion)
    {
        List lstErrores = new ArrayList();

        boolean tieneAlMenos1ItemVP= false;
        boolean itemTieneFFVP= false;

        for(DatoSerie serie : declaracion.getDua().getListSeries())
        {
            boolean serieTieneVE=tieneMtoValido(serie.getValestimado());
            boolean itemTieneVP= false;


            StringBuilder itemsDeLaSerie = new StringBuilder();
            StringBuilder itemsDeLaSerieConVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinVP = new StringBuilder();
            StringBuilder itemsDeLaSerieConFFVP = new StringBuilder();
            StringBuilder itemsDeLaSerieSinFFVP = new StringBuilder();

            for(DatoItem datoItem : FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie))
            {

                itemsDeLaSerie.append(datoItem.getNumsecitem());
                itemsDeLaSerie.append(", ");

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){
                    tieneAlMenos1ItemVP = true;
                    itemTieneVP=true;
                    itemsDeLaSerieConVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConVP.append(", ");
                }else{
                    itemsDeLaSerieSinVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinVP.append(", ");
                }
                if(tieneRegistradaFechaDefault(datoItem.getMontoProv().getFecvalestima())){
                    itemTieneFFVP=true;
                    itemsDeLaSerieConFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieConFFVP.append(", ");
                }else{
                    itemsDeLaSerieSinFFVP.append(datoItem.getNumsecitem());
                    itemsDeLaSerieSinFFVP.append(", ");
                }

                if(Constantes.TIENE_VALOR_PROVISIONAL.equals(datoItem.getMontoProv().getIndtipovalor())){

                    /*
                    if(!tieneMtoValido(datoItem.getMontoProv().getValmonto())) {
                        //Excepci�n 15
                        lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 ITEM: " +datoItem.getNumsecitem()+" DEBE MARCAR EL VALOR ESTIMADO"));
                    }*/

                    if(noTieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima()))
                    {
                        //Excepci�n 7
                        lstErrores.add(addError("000000", "SI AL MENOS UNO DE LOS ITEMS : " +datoItem.getNumsecitem()+ " TIENE VALOR PROVISIONAL, ENTONCES DEBE ACEPTAR LA FECHA FIN DEL VALOR PROVISIONAL"));
                    }
                }else{


                    /*
                    if(tieneRegistradaFechaValida(datoItem.getMontoProv().getFecvalestima()))
                    {
                        //Excepci�n 7
                        //entra
                        lstErrores.add(addError("000000", "SI EL ITEM: " +datoItem.getNumsecitem()+ " TIENE FECHA FIN DEL VALOR PROVISIONAL, ENTONCES DEBE ACEPTAR LA FECHA FIN DEL VALOR PROVISIONAL"));
                    }*/

                	//r2bz cuando se rectifica a valor definitivo, siempre se mantiene los dos montos, el provisional y el definitivo por lo que daba un falso error, se a�ade la val del otro monto
                    if(tieneMtoValido(datoItem.getMontoProv().getValmonto()) && !tieneMtoValido(datoItem.getMontoProv().getValdefinitivo()))
                    {
                        //Excepci�n 11
                        lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO DEBE MARCAR TIPO DE VALOR 2 EN EL MISMO ITEM: " +datoItem.getNumsecitem()+" DEL FORMATO B"));
                    }
                    //viceversa
                    /*
                    if(tieneMtoValido(datoItem.getMontoProv().getValmonto())) {
                        //Excepci�n 15
                        lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO ITEM: " +datoItem.getNumsecitem()+" DEBE MARCAR TIPO DE VALOR 2 EN EL MISMO ITEM DEL FORMATO B"));
                    }*/

                }


            }

            if(itemTieneVP && !StringUtils.isEmpty(itemsDeLaSerieSinVP.toString())){
                //Excepci�n  9
                lstErrores.add(addError("000000", "TODOS LOS ITEMS: "+ itemsDeLaSerie.toString()+ " ASOCIADOS A LA MISMA SERIE: "+ serie.getNumserie()+" CON VALOR PROVISIONAL DEBEN TENER  CONSIGNADO EL C�DIGO 2 EN LA CASILLA 5.6 DEL FORMATO B, ITEMS CON VALOR PROVISIONAL: "+itemsDeLaSerieConVP.toString()+" ITEMS SIN VALOR PROVISIONAL: "+itemsDeLaSerieSinVP.toString()));

            }

            /*
            //Excepci�n 13
            if(!serieTieneVE && itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 EN LOS ITEMS: "+ itemsDeLaSerieConVP.toString() +" DEL FORMATO B DEBE MARCAR VALOR ESTIMADO DE LA SERIE: "+ serie.getNumserie()+" CORRELACIONADA DEL FORMATO A"));
            }*/
            //Excepci�n 12
            if(serieTieneVE && !itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA VALOR ESTIMADO A NIVEL DE LA SERIE: "+ serie.getNumserie()+" DEBE MARCAR TIPO DE VALOR 2 EN LOS ITEMS: "+itemsDeLaSerieSinVP.toString()+" CORRELACIONADOS DEL FORMATO B"));
            }
            //Excepci�n 20
            if(serieTieneVE==false && itemTieneVP){
                lstErrores.add(addError("000000", "SI MARCA TIPO DE VALOR 2 EN LOS ITEMS : "+ itemsDeLaSerieConVP.toString()+" DEL FORMATO B DEBE MARCAR VALOR ESTIMADO A NIVEL DE LA SERIE: "+ serie.getNumserie()+" CORRELACIONADA DEL FORMATO A"));
            }
        }

        /*
        //Excepci�n 14
        if(tieneAlMenos1ItemVP && noTieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())){
            lstErrores.add(addError("000000", "SI AL MENOS UNO DE LOS ITEMS TIENE VALOR PROVISIONAL, ENTONCES DEBE INDICAR LA FECHA FIN DEL VALOR PROVISIONAL DE LA DECLARACION"));
        }

        //Excepci�n 10
        if(tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional()) && !tieneAlMenos1ItemVP){
            lstErrores.add(addError("000000", "SI MARCA FECHA FIN DEL VALOR PROVISIONAL EN LA DECLARACION, ALGUNO DE LOS �TEMS DEBE TENER EL CODIGO DE VALOR PROVISIONAL"));
        }
        */
        //Excepci�n 19 Y Excepci�n 8 SON LO MISMO solo cambia el mensaje
        /*
        if((itemTieneFFVP && noTieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())
                ||(!itemTieneFFVP && tieneRegistradaFechaValida(declaracion.getDua().getFecfinprovsional())))) {*/

        /* se comenta Coordinacion con OLwaldo no debe ser obligatorio
        if((itemTieneFFVP && !tieneRegistradaFechaDefault(declaracion.getDua().getFecfinprovsional())
                ||(!itemTieneFFVP && tieneRegistradaFechaDefault(declaracion.getDua().getFecfinprovsional())))) {
        //Excepci�n  19
        lstErrores.add(addError("000000", "LAS FECHAS FIN DEL VALOR PROVISIONAL A NIVEL DE ITEM DEL FORMATO B DEBEN COINCIDIR CON LA CONSIGNADA EN DATOS GENERALES DEL FORMATO A"));
        }*/



        return lstErrores;
    }
    
    /** Inicio mpoblete RIN10 [metodo para habilitar funcionalidad rin10]**/
    public boolean estaVigenteValorProvisional()throws Exception{
    	
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DataCatalogo catalogoVigenciaPecoAmazonia = (DataCatalogo) catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_RIN10);//.get("fec_inidatcat"); // esto tendriamos que ponerlo en constantes
		
		if(catalogoVigenciaPecoAmazonia != null){
			
			Date fecInicioVigencia = (Date) catalogoVigenciaPecoAmazonia.getFecInidatcat();
			
			Date fechaHoy = SunatDateUtils.getCurrentDate();
	
			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaHoy, fecInicioVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			   return true;
			}
		}
		
		return false;
    }
    /** Fin mpoblete RIN10 [metodo para habilitar funcionalidad rin10]**/
    /*
    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
    {
        this.fabricaDeServicios = fabricaDeServicios;
    }
*/

    private boolean tieneRegistradaFechaValida(Date date) {
        String format = "dd/MM/yyyy";

        boolean rspta= true;

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            String dateAsString = sdf.format(date);


            String sdate = dateAsString;
            if("01/01/0001".equals(sdate) || "31/12/9999".equals(sdate)) {
                return false;
            }
        }catch (Exception e){
            return false;
        }

        return rspta;
    }

    private boolean tieneRegistradaFechaDefault(Date date) {
        
        return noTieneRegistradaFechaValida(date);
    }
    private boolean noTieneRegistradaFechaValida(Date date) {

        return !tieneRegistradaFechaValida(date);
    }

    /**
     * Verifica que exista el indicador para generar LC de valor provisional
     * si no existe el RUC debe considerara por default que tiene el indicador
     * solo cuando el RUC a solicitado su baja es que el indicador estara inactivo
     * o no este registrado en el padron
     *
     * @param declaracionBD
     * @return
     * @throws Exception
     */
    private boolean tieneIndicadorParaGenerarLCVPActivo(Declaracion declaracionBD) throws Exception{
    	PadUsuGaraDAO padUsuGaraDAO = fabricaDeServicios.getService("padusugaraDef");
        boolean result = false;
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("NUM_RUC", declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad());
        params.put("IND_USUACTIVO",Constantes.IND_ACTIVO);
        params.put("PER_PROCESO", DateUtil.dateToString(new Date(), "yyyyMM"));

        String  indicadorLCVP = padUsuGaraDAO.obtenerIndicadorLCVP(params);

        if (Constantes.INDICADOR_GENERACION_LCVP.equals(indicadorLCVP) || StringUtils.isEmpty(indicadorLCVP)) {
            result=true;
        }

        return result;
    }
/*
	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}*/

    
}