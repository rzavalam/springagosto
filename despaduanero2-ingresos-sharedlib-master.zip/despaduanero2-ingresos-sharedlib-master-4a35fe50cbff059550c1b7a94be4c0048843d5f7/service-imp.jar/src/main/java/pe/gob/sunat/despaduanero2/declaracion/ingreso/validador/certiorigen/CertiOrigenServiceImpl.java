package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero.catalogo.tg.model.AutExportador;
import pe.gob.sunat.despaduanero.catalogo.tg.model.EquivMonto;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.AutExportadorDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.EquivMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PrupersoDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;




public class CertiOrigenServiceImpl extends ValDuaAbstract implements CertiOrigenService{

	//private CatalogoHelperImpl catalogoHelper;
	//private FabricaDeServicios fabricaDeServicios;


	@ServicioAnnot(tipo="V",codServicio=2486, descServicio="valida certificado origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie"})
	@OrquestaDespaAnnot(codServInstancia=2486,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
public List<Map<String, String>> valUnicoCOSerie(DatoSerie serie) {
		
		 List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
			int cantidadCert =  getCantidadCertiOrigen(serie); 
			
			if(cantidadCert>1){
 				//lstErrores.add(catalogoHelper.getErrorMap("30575",new Object[]{serie.getNumserie()}));
 				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30575",new String[]{serie.getNumserie().toString()}));
 				return lstErrores;
 			}
				return lstErrores;
	}

	/**
	 * Permite obtener el registro de los funcionarios autorizados a emitir Certificados de Origen
	 * @param codffco
	 * @param codpais
	 * @param fechaReferencia
	 * @return
	 */	
	public List<Map<String,Object>> consultarRegistroFuncionario(String codffco, String codpais, Date fechaReferencia){
		Map<String,Object> paramsPruperso=new HashMap<String,Object>();
		PrupersoDAO prupersoDAO = fabricaDeServicios.getService("prupersoDAO");
		paramsPruperso.put("regis", SunatStringUtils.lpad(codffco, 5, ' '));
		paramsPruperso.put("codPais", codpais);
		paramsPruperso.put("fechCertiOrigen", SunatDateUtils.getIntegerFromDate(fechaReferencia));	
		List<Map<String,Object>> listJoinPruperso=prupersoDAO.joinPrupersoAndPrufunciFindByMap(paramsPruperso);
		return listJoinPruperso;
	}


	/**
	 * Permite obtener el registro de la autorizacion del exportador 
	 */
	public AutExportador consultarAutorizacionExportador(String numAutorizExp, String codPaisorigen, String codConvenio, Date fechaReferencia){
		AutExportadorDAO autexportadorDAO = fabricaDeServicios.getService("tg.model.autexportadorDAODef");
		AutExportador autExportador = new AutExportador();
		autExportador.setCodPaisorigen(codPaisorigen);
		autExportador.setCodTpi(codConvenio);
		autExportador.setNumAutorizExp(numAutorizExp);
		autExportador.setFecInivig(fechaReferencia);//que utilice la fecha de ref para la vigencia - PAS20165E220200033
		autExportador.setIndDel("0");
		AutExportador resAutExportador = autexportadorDAO.selectByPrimaryKeySelective(autExportador);
		return resAutExportador;
	}

	/**
	 * Permite obtener el registro de la autorizacion del exportador 
	 */
	 //rtineo optimizacion
	public List<AutExportador> getListadoAutorizacionExportador(String numDocumento){
		AutExportadorDAO autexportadorDAO = fabricaDeServicios.getService("tg.model.autexportadorDAODef");
		AutExportador autExportador = new AutExportador();
		autExportador.setNumDocumentoList(numDocumento);
		autExportador.setIndDel("0");
		List<AutExportador> resAutExportador = autexportadorDAO.getListadoAutorizacionExportador(autExportador);
		return resAutExportador;
	}

	
	/**
	 * Permite obtener el monto equivalente en EUR para el TLC con UE 
	 * @param codmoneda
	 * @param fechaReferencia
	 * @return
	 */
	public EquivMonto consultarMontoEquivalente(String codmoneda, Date fechaReferencia){
		EquivMontoDAO equivMontoDAO = fabricaDeServicios.getService("tg.model.equivmontoDAODef");
		EquivMonto equivMonto = new EquivMonto();
		equivMonto.setCodmoneda(codmoneda);
		/*INICIO-P34 PAS20165E220200126 AFMA*/
		if(!SunatDateUtils.isDefaultDate(fechaReferencia)){
		equivMonto.setFecinicio(fechaReferencia);
		}
		/*FIN-P34 PAS20165E220200126 AFMA*/

		EquivMonto  resEquivMonto  = equivMontoDAO.selectByPrimaryKeySelective(equivMonto);
		return resEquivMonto;
	}
	
	//rtineo optimizacion
	public Map<String, EquivMonto> consultarMontosEquivalente(String codigosMoneda, Date fechaReferencia) {
		EquivMontoDAO equivMontoDAO = fabricaDeServicios.getService("tg.model.equivmontoDAODef");
		EquivMonto equivMonto = new EquivMonto();
		equivMonto.setCodigosMonedaConsulta(codigosMoneda);
		equivMonto.setFecinicio(fechaReferencia);
		return equivMontoDAO.buscarMontosEquivalencia(equivMonto);
	}
	//fin optimizacion


	/*public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}*/

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
