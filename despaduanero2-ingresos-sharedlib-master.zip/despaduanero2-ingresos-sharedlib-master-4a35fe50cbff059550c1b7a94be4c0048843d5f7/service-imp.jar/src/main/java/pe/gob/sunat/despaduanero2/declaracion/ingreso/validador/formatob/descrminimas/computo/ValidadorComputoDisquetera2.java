package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
/**
 * 
 * @author lalberti
 *
 */

public class ValidadorComputoDisquetera2 extends ValidadorComputoAbstract
{

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua)throws Exception
  {

	    List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();
        DatoItem item =  obtenerItem(objeto, dua);

        lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));//rechazo de SPN con minima
     
        if (CollectionUtils.isEmpty(lstErrores)){
        	lstErrores.addAll(validarEstructura(objeto));
        	lstErrores.addAll(validarUnidadComercial(objeto, item));
        }

	    
	    return lstErrores;
  }

  public List<ErrorDescrMinima> validarTipoInterfaz(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarTipoConexion(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCapacidadDisquetera(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
}
