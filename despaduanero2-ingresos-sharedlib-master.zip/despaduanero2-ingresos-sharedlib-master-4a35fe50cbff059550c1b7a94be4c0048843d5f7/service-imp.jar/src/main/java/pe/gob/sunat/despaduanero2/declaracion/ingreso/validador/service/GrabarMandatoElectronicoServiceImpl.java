package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.bean.MandatoElectronico;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdage;
import pe.gob.sunat.despaduanero2.model.RelacionDocumento;
import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.service.SolicitudMandatoService;
import pe.gob.sunat.despaduanero2.service.SolicitudRectificaService;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class GrabarMandatoElectronicoServiceImpl extends ValDuaAbstract implements GrabarMandatoElectronicoService {

	//private FabricaDeServicios fabricaDeServicios;
	
	
	/**
	 * Si la declaracion cuenta con mandato electronico, procede a grabar el indicador y la asociacion con la solicitud de mandato
	 * 0: No tiene Mandato Electronico
	 * 1: Tienes Mandato Electonico
	 * 2: Se le retira el mandato Electronico 
	 */
	public String grabarMandatoElectronico(DUA dua, Date fechaReferencia, String codTransaccion){
		String tipoMandatoElectronico = ConstantesDataCatalogo.NO_TIENE_MANDATO_ELECTRONICO;
		List<MandatoElectronico> listMandato = buscarMandato(dua, fechaReferencia);
		if (CollectionUtils.isNotEmpty(listMandato)){
			grabarIndicadorMandato(dua);
			actualizarEstadoMandato(listMandato);
			grabarDocumentoRelacion(dua, listMandato);
			tipoMandatoElectronico = ConstantesDataCatalogo.TIENE_MANDATO_ELECTRONICO;
		} else {  
			//Verificamos si cuenta con mandato para anularlo, solo si es una rectificacion
			if (!SunatStringUtils.isEqualTo(codTransaccion, ConstantesDataCatalogo.TRANSACCION_NUMERACION)){
				if (tieneIndicadorMandato(dua)){
					anularIndicadorMandato(dua);
					anularDocumentoRelacion(dua);
					tipoMandatoElectronico = ConstantesDataCatalogo.RETIRA_MANDATO_ELECTRONICO;
				}
			}
		}
		return tipoMandatoElectronico;
	}
	
	/**
	 * Determina si la declaracion cuenta con mandato Electronico
	 * @param dua
	 * @param fechaReferencia
	 * @return
	 */
	private List<MandatoElectronico> buscarMandato(DUA dua, Date fechaReferencia){
		Map<String, Object> paramMandato = new HashMap<String, Object>();
		List<MandatoElectronico> listMandato = new ArrayList<MandatoElectronico>();
		List<String> listDocTransporte = new ArrayList<String>(); 
		boolean tieneMandatoPorDocTransporte = false;
		boolean tieneMandatoPorPeriodo = false;
		SolicitudMandatoService solicitudMandatoService = fabricaDeServicios.getService("despaduanero2.solicitudMandatoService");

		//Si el env�o cuenta con manifiesto de carga, se procede a realizar la b�squeda de Mandatos Electronico				
		if( dua.getManifiesto().getNummanif() != null && dua.getManifiesto().getAnnmanif() !=null && dua.getManifiesto().getCodaduamanif()!=null){
			listDocTransporte = getListDocTransporte(dua);
			
			if(!CollectionUtils.isEmpty(listDocTransporte)){
			paramMandato.put("consignatarioTipoDocumentoIdentidad", dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			paramMandato.put("consignatarioNumeroDocumentoIdentidad", dua.getDeclarante().getNumeroDocumentoIdentidad());			
			paramMandato.put("despachadorTipoDocumentoIdentidad", dua.getCodtipooper());
			paramMandato.put("despachadorNumeroDocumentoIdentidad", dua.getNumdocumento());			                  
			paramMandato.put("aduanaManifiesto",dua.getManifiesto().getCodaduamanif());
			paramMandato.put("anioManifiesto",dua.getManifiesto().getAnnmanif().substring(0,4));
			paramMandato.put("viaManifiesto", dua.getManifiesto().getCodmodtransp());
			paramMandato.put("numeroManifiesto",dua.getManifiesto().getNummanif());
			paramMandato.put("tipoMandato",ConstantesDataCatalogo.TIPO_MANDATO_DOCUTRANS);
			paramMandato.put("fechatransmision",fechaReferencia);
			paramMandato.put("listnumeroDocumentoTransporteDetalle",listDocTransporte);
			listMandato = solicitudMandatoService.buscarListaMandato(paramMandato);
		}
		}
		
		//Si existe registros, la cantidad de Mandatos deber� ser igual a la cantidad de los distintos documentos de transporte declarados 
		if (CollectionUtils.isNotEmpty(listMandato)){
			if (SunatNumberUtils.isEqual(listDocTransporte.size(),listMandato.size())){
				tieneMandatoPorDocTransporte = true;
			}
		}
			
		//Si no existe registros en el punto anterior, se busca si el importador registr� un mandato por periodo
		if (!tieneMandatoPorDocTransporte){
			paramMandato.clear();
			paramMandato.put("consignatarioTipoDocumentoIdentidad", dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			paramMandato.put("consignatarioNumeroDocumentoIdentidad", dua.getDeclarante().getNumeroDocumentoIdentidad());			
			paramMandato.put("despachadorTipoDocumentoIdentidad", dua.getCodtipooper());
			paramMandato.put("despachadorNumeroDocumentoIdentidad", dua.getNumdocumento());
			paramMandato.put("fechatransmision",fechaReferencia);
			paramMandato.put("tipoMandato",ConstantesDataCatalogo.TIPO_MANDATO_PERIODO);
			paramMandato.put("codigoRegimen",dua.getCodregimen());
			paramMandato.put("codigoAduanaMandato",dua.getCodaduanaorden());
			listMandato = solicitudMandatoService.buscarListaMandato(paramMandato);
		}
		if (CollectionUtils.isNotEmpty(listMandato)){
			tieneMandatoPorPeriodo = true;
		}
		return listMandato;
	}
	
	/**
	 * Retorna el listado de los documentos de transporte
	 * Para la b�squeda se concatena: Documento de Transporte + ^ + Numero de Detalle + ^ + Des Numero de Detalle 
	 * @param dua
	 * @return
	 */
	private List<String> getListDocTransporte (DUA dua){
		SolicitudMandatoService solicitudMandatoService = fabricaDeServicios.getService("despaduanero2.solicitudMandatoService");
		Map<String, Object> params = new HashMap<String, Object>(); 
		DatoManifiesto manifiestoDAM = dua.getManifiesto();
		List<String> listnumeroDocumentoTransporte = new ArrayList<String>();
		params.put("aduanaManifiesto", manifiestoDAM.getCodaduamanif());
    	params.put("anioManifiesto", SunatStringUtils.length(manifiestoDAM.getAnnmanif()) > 3 ? manifiestoDAM.getAnnmanif().substring(0, 4) : null);
    	params.put("viaManifiesto", manifiestoDAM.getCodmodtransp());
    	params.put("numeroManifiesto", manifiestoDAM.getNummanif());		
		Manifiesto manifiesto = solicitudMandatoService.obtenerManifiesto(params);
		String anioManif = SunatStringUtils.length(manifiestoDAM.getAnnmanif()) > 3 ? manifiestoDAM.getAnnmanif().substring(0, 4) : null;
		
		if(!CollectionUtils.isEmpty(dua.getListDocTransporte())){
		for(DatoDocTransporte documentoTransporte:dua.getListDocTransporte()){
			String numeroDetalle = new String();
			if (documentoTransporte.getNumdetalle()== null || SunatNumberUtils.isEqualToZero(documentoTransporte.getNumdetalle())){				
				if((manifiesto instanceof Mcdage)){
					List<Map<String,Object>> listDocTransporte = solicitudMandatoService.obtenerDocumentosTransporteSigad(manifiestoDAM.getCodmodtransp(),manifiestoDAM.getCodaduamanif(), anioManif!=null?SunatNumberUtils.toInteger(anioManif):0, 
							manifiestoDAM.getNummanif(), documentoTransporte.getNumdoctransporte(), numeroDetalle);
						if(!CollectionUtils.isEmpty(listDocTransporte)){
					Map<String, Object> docTransporte = listDocTransporte.get(0);
					numeroDetalle = "0^".concat(SunatStringUtils.toStringObj(docTransporte.get("NUMDET")));					
						}
										
				} else {
					List<DocumentoDeTransporte> listDocTransporte = solicitudMandatoService.obtenerDocumentosTransporteSda(manifiestoDAM.getCodmodtransp(), manifiestoDAM.getCodaduamanif(), 
							anioManif, manifiestoDAM.getNummanif(), documentoTransporte.getNumdoctransporte(), numeroDetalle);
						if(!CollectionUtils.isEmpty(listDocTransporte)){
					DocumentoDeTransporte docTransporte =  listDocTransporte.get(0);
					numeroDetalle = SunatStringUtils.toStringObj(docTransporte.getNumeroDeDetalle()).concat("^ "); 
				}		
						
					}		
			} else {
				if((manifiesto instanceof Mcdage)){ 
					numeroDetalle =  "0^".concat(SunatStringUtils.lpad(SunatStringUtils.toStringObj(documentoTransporte.getNumdetalle()),3,' '));
				} else {
					numeroDetalle = SunatStringUtils.toStringObj(documentoTransporte.getNumdetalle()).concat("^ ");
				}
			}
				if(!StringUtils.isEmpty(numeroDetalle)){
			listnumeroDocumentoTransporte.add(documentoTransporte.getNumdoctransporte().concat("^").concat(numeroDetalle));
		}
			}
		}
		
		return listnumeroDocumentoTransporte;
	}


	/**
	 * Actualiza o Inserta el indicar de Mandato Electronico asociado a la declaraci�n
	 * @param dua
	 */
	private void grabarIndicadorMandato(DUA dua){
		Map<String, Object> params = new HashMap<String,Object>();
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
		params.put("numCorredoc", dua.getNumcorredoc());
		params.put("codIndicador", ConstantesDataCatalogo.INDICADOR_MANDATO_ELECTRONICO);
		params.put("indActivo", ConstantesDataCatalogo.IND_ACTIVO);
		params.put("codTiporegistro",  ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);
		indicadorDuaService.insertaActualizaIndicador(params);
	}
	
	
	/**
	 * Verifica si la declaracion cuenta con el indicador de Mandato electronico
	 * @param dua
	 * @return
	 */
	
	private boolean tieneIndicadorMandato(DUA dua){
		boolean result = false;
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
		DatoIndicadores datoIndicador = indicadorDuaService.obtenerIndicadorDeclaracion(SunatStringUtils.toStringObj(dua.getNumcorredoc()), ConstantesDataCatalogo.INDICADOR_MANDATO_ELECTRONICO);
		if (datoIndicador != null ){
			if (SunatStringUtils.isEqualTo(datoIndicador.getIndicadorActivo(), ConstantesDataCatalogo.IND_ACTIVO)){
				result = true;	
			} else {
				result = false;
			}
		}
		return result;
	}
	
	
	private void anularIndicadorMandato(DUA dua){		
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("numCorredoc", dua.getNumcorredoc());
		params.put("codIndicador", ConstantesDataCatalogo.INDICADOR_MANDATO_ELECTRONICO);
		params.put("indActivo", ConstantesDataCatalogo.IND_INACTIVO);
		params.put("codTiporegistro",  ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);
		indicadorDuaService.actualizaIndicador(params);
	}

	/**
	 * Actualiza todos los Mandatos como utilizados.
	 * @param listMandato
	 */
	private void actualizarEstadoMandato(List<MandatoElectronico> listMandato){
		for(MandatoElectronico mandatoElectronico:listMandato){			
			if (SunatStringUtils.isEqualTo(mandatoElectronico.getEstadoSolicitud(),ConstantesDataCatalogo.ESTADO_SOL_MANDATO_REGISTRADO)){				
				SolicitudRectificaService  solicitudRectificaService = fabricaDeServicios.getService("despaduanero2.solicitudRectificaService");
				Solicitud solicitud = new Solicitud();
				solicitud.setNumeroCorrelativo(mandatoElectronico.getNumeroCorrelativo());
				solicitud.setEstadoSolicitud(ConstantesDataCatalogo.ESTADO_SOL_MANDATO_UTILIZADO);
				solicitudRectificaService.actualizarSolicitud(solicitud);
			}
		}
	}
	
	
	/**
	 * Busca la existencia de relaciones entre Mandatos y Declaraciones
	 * En caso de existir se actualiza el indicador de eliminacion caso contrario se inserta
	 * @param dua
	 * @param listMandato
	 */
	private void grabarDocumentoRelacion(DUA dua, List<MandatoElectronico> listMandato){
		SolicitudRectificaService  solicitudRectificaService = fabricaDeServicios.getService("despaduanero2.solicitudRectificaService");
		Long numCorredocDeclaracion = dua.getNumcorredoc();
		for(MandatoElectronico mandatoElectronico:listMandato){	
			Map<String, Object> params = new HashMap<String, Object>();
			Long numCorredocMandato = mandatoElectronico.getNumeroCorrelativo();
			params.put("NUM_CORREDOC",numCorredocDeclaracion);
			params.put("NUM_CORREDOC_PRE",numCorredocMandato);
			List<RelacionDocumento> listRelacionMandato = solicitudRectificaService.findDocuPreceDocByParams(params);
			if (CollectionUtils.isEmpty(listRelacionMandato)){
				RelacionDocumento relacionDocumento = new RelacionDocumento();
				relacionDocumento.setAduana(mandatoElectronico.getAduana());
				relacionDocumento.setNumeroCorrelativo(numCorredocDeclaracion);
				relacionDocumento.setNumeroCorrelativoPrecedente(numCorredocMandato);
				relacionDocumento.setAnnoPresentacion(mandatoElectronico.getAnnoSolicitud());
				relacionDocumento.setNumeroDeclaracion(SunatNumberUtils.toInteger(mandatoElectronico.getNumeroSolicitud()));
				solicitudRectificaService.insertarRelacionDocumento(relacionDocumento);
			} else {
				RelacionDocumento relacionDocumento = listRelacionMandato.get(0);
				relacionDocumento.setIndicadorEliminacion(ConstantesDataCatalogo.IND_REGISTRO_ACTIVO);
				solicitudRectificaService.actualizarRelacionDocumento(relacionDocumento);
			}
			
			
		}
	}
	
	/**
	 * Anula los Mandatos Electronicos Asociados a la declaraci�n.
	 * @param dua
	 */
	private void anularDocumentoRelacion(DUA dua){
		SolicitudRectificaService  solicitudRectificaService = fabricaDeServicios.getService("despaduanero2.solicitudRectificaService");
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("NUM_CORREDOC",dua.getNumcorredoc());
		params.put("COD_TIPSOL",  ConstantesDataCatalogo.TIPO_SOLICITUD_MANDATO);
		List<RelacionDocumento> listRelacionDocumento = solicitudRectificaService.findDocuPreceDocSolicitudByParams(params);
		if (CollectionUtils.isNotEmpty(listRelacionDocumento)){
			for(RelacionDocumento relacionDocumento:listRelacionDocumento){				
				relacionDocumento.setIndicadorEliminacion(ConstantesDataCatalogo.IND_REGISTRO_INACTIVO);
				solicitudRectificaService.actualizarRelacionDocumento(relacionDocumento);
			}
		}
	}
	
	
	/**
	 * SETTERS AND GETTERS
	 * @return
	 */
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
}
