package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.vehiculos;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.*;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;
import pe.gob.sunat.despaduanero2.declaracion.model.*; 
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatModVehiDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRevisa1DAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by amancillaa on 14/10/2016.
 */
public class ValidadorVehiculo2 extends ValidadorAbstract {
	public static final SimpleDateFormat sdf = new SimpleDateFormat(
			"yyyy-MM-dd");
	public static final String CHASIS_MOTORIZADO = "CHM";
	//inicio gmotnoya Pase 436 2015
	public static final String CUATRIMOTO ="CMT";
	public static final String ARENERO ="ARE";
	public static final String TUBULAR ="TUB";
	public static final String MULTIFUNCION ="MUL";
	//fin gmotnoya Pase 436 2015
	public static final String CAT_VEH_M = "M";
	public static final String CAT_VEH_M1 = "M1";
	public static final String CAT_VEH_M2 = "M2";
	public static final String CAT_VEH_M3 = "M3";
	public static final String CAT_VEH_O1 = "O1";
	public static final String CAT_VEH_N1 = "N1";
	public static final String CAT_VEH_N2 = "N2";
	public static final String CAT_VEH_N3 = "N3";
	public static final String CATEGORIA_L = "L";
	public static final String CATEGORIA_M = "M";
	public static final String CATEGORIA_N = "N";
	public static final String CATEGORIA_O = "O";
	public static final String CATEGORIA_O1 = "O1";
	public static final String CATEGORIA_O2 = "O2";
	public static final String CATEGORIA_O3 = "O3";
	public static final String CATEGORIA_O4 = "O4";
	public static final String PAIS_ORIGEN_JP = "JP";
	public static final String CAMPO_ZZZ = "1";
	public static final String TIPO_ENCENDIDO_CHI = "CHI";
	public static final String TIPO_ENCENDIDO_COM = "COM";
	public static final String INDICADOR_SNTT_0 = "0";
	public static final String INDICADOR_SNTT_1 = "1";//PAS20165E220200137
	public static final String COD_REG_PREC_91 = "91";
	public static final String TIPO_DOC_4 = "4";
	public static final String EXP_REG = "E";
	public static final String CATALOGO = "C";
	public static final String EXP_REG_ZZZ_1 = "^[\\w\\s]{1,18}$";
	public static final String TIPO_VALOR_ZZZ = "1";

	public static final String TIPO_COMBUSTIBLE_EXONERADO_CILINDRO = "ELT"; // GMONTOYA
	// PASE
	// 436
	// 2015
	public static final String TIPO_TRANSMISION_EXONERADO_NUMERO_CAMBIOS = "CVT"; // GMONTOYA
	// PASE
	// 436
	// 2015

	public String[] codEstMerUsado = new String[] { "20", "21", "22", "23",
			"24", "25", "26", "27", "28" };


	/*traido de ValidadorAbstract*/
	//se actualizo por 137 la lista de validos por SNTT y la validacion de accesorios para LMO.
	private String[] lstCodigosValidosdIndicadorSNTT1 = new String[] { "VE0000", "VE0001", "VE0002", "VE0008", "VE0029", "VE0012", "VE0013", "VE0014", "VE0003", "VE0011"};
	private static final String CATALOGO_ERRORES = "F09";
	private String[] lstCodigosAutoExcluyentesSNTT1 = new String[] { "VE0012", "VE0013","VE0011"};//es obligatorio chasis si no se manda vin
	private String[] lstExoneradosChasisMotorizadoSNTT1 = new String[] {"VE0004","VE0060","VE0017","VE0021","VE0070","VE0071"};//PAS20155E220000407 exonerados por CHASIS MOTORIZADO
	private String[] lstExoneradosProvisionalSNTT1 = new String[] {"VE0005","VE0010","VE0017","VE0018","VE0019","VE0020"};//PAS20155E220000425 exonerados por revisar validaci�n individual
	/*traido de ValidadorAbstract*/


	//private CatModVehiDAO catModVehiDAO;
	//private CatRevisa1DAO catRevisa1DAO;
	// P46
	//private ValTratamientoDonacionService valTratamientoDonacionService;

	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto,
			Declaracion dua) throws Exception {
		ValTratamientoDonacionService valTratamientoDonacionService = fabricaDeServicios.getService("ValTratamientoDonacion");
		List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

		/*traido de ValidadorAbstract*/
		lstErrores.addAll(validarMandatoriedadSNTT1(objeto));
		/*traido de ValidadorAbstract*/

		if (CollectionUtils.isEmpty(lstErrores)) {

			lstErrores.addAll(validarCategoria(objeto));
			lstErrores.addAll(validarMarcaComercial(objeto));
			lstErrores.addAll(validarModelo(objeto));
			lstErrores.addAll(validarAnnoFabricacion(objeto, dua)); 
			boolean esRigmen10 = CollectionUtils
					.isEmpty(valTratamientoDonacionService
							.validarRegimenDeclaracion(dua)) ? true : false;
			boolean esDonacion = valTratamientoDonacionService
					.validarTieneTratamientoDonacion(dua); 
			// 1. Las declaraciones del r�gimen de importaci�n para el consumo
			// (10) con donaci�n (tipo de tratamiento �4�)
			// ***** No est�n sujetas a *******
			// ******1.1. Las validaciones del a�o de antig�edad de veh�culos
			if ((!esRigmen10 && !esDonacion) || (esRigmen10 && !esDonacion)) {
				lstErrores.addAll(validarAnnModelo(objeto, dua));
			}
			/* Fin - JMCV P46 */

			/**PAS20165E220200137 cambios a R641**/
			Vehiculo vehiculo = (Vehiculo) objeto;
			String   indicadorSNTT = vehiculo.getIndicadorSNTT() == null?"":vehiculo.getIndicadorSNTT().getValtipdescri().trim();
			/**PAS20165E220200137 cambios a R641**/


			lstErrores.addAll(validarNumeroVIN(objeto));
			lstErrores.addAll(validarCarroceria(objeto));

			if(!indicadorSNTT.equals(INDICADOR_SNTT_1)){
				lstErrores.addAll(validarNumeroMotor(objeto));
				lstErrores.addAll(validarColorPrincipal(objeto));
				lstErrores.addAll(validarTipoCombustible(objeto));
				lstErrores.addAll(validarCilindradaCC(objeto));
				lstErrores.addAll(validarNumeroAsientos(objeto));
				lstErrores.addAll(validarCantidadEjes(objeto));
				lstErrores.addAll(validarFormulaRodante(objeto));
				lstErrores.addAll(validarTipoTransmision(objeto));
			}

			lstErrores.addAll(validarColorSecundario(objeto));
			lstErrores.addAll(validarIndicadorSNTT(objeto));
			lstErrores.addAll(validarVersion(objeto));
			lstErrores.addAll(validarMoto(objeto));
			lstErrores.addAll(validarNumeroChasis(objeto));
			lstErrores.addAll(validarCodigoExoneracionVIN(objeto, dua));
			lstErrores.addAll(validarNumeroCilindros(objeto));
			lstErrores.addAll(validarTipoEncendido(objeto,dua));//gmontoya Pase 436 - 2015
			lstErrores.addAll(validarNumeroPasajeros(objeto));
			lstErrores.addAll(validarPotenciaMotorKW(objeto));
			lstErrores.addAll(validarPotenciaMotorRPM(objeto));
			lstErrores.addAll(validarPotenciaPesoBruto(objeto));
			lstErrores.addAll(validarPesoBrutoCombinado(objeto));
			lstErrores.addAll(validarPesoBrutoKG(objeto));
			lstErrores.addAll(validarPesoNetoKG(objeto));
			lstErrores.addAll(validarCargaUtilKG(objeto));
			lstErrores.addAll(validarKilometraje(objeto, dua));
			lstErrores.addAll(validarModeloDelFabricante(objeto));
			lstErrores.addAll(validarListaAccesorios(objeto));
			lstErrores.addAll(validarNumeroHomologacionMTC(objeto));
			lstErrores.addAll(validarLargoMM(objeto));
			lstErrores.addAll(validarAnchoMM(objeto));
			lstErrores.addAll(validarAlturaMM(objeto));
			lstErrores.addAll(validarNumeroCambiosDeCaja(objeto));
			lstErrores.addAll(validarNumeroPuertas(objeto));
			lstErrores.addAll(validarRefrigeracionMotor(objeto));
			lstErrores.addAll(validarSuspencionDelantera(objeto));
			lstErrores.addAll(validarSuspencionPosterior(objeto));
			lstErrores.addAll(validarTipoFrenoDelantero(objeto));
			lstErrores.addAll(validarTipoFrenoPosterior(objeto));
			lstErrores.addAll(validarNombreDelFabricante(objeto));
			lstErrores.addAll(validarNumeroRuedas(objeto));
			lstErrores.addAll(validarMedidaAros(objeto));
			lstErrores.addAll(validarMedidaNeumaticos1(objeto));
			lstErrores.addAll(validarMedidaNeumaticos2(objeto));
			lstErrores.addAll(validarDistanciaEntreEjes(objeto));
			lstErrores.addAll(validarMarcaCarroceria(objeto));
			lstErrores.addAll(validarNumeroCarroceria(objeto));
			lstErrores.addAll(validarPesoMaximoEjeDelantero(objeto));
			lstErrores.addAll(validarPesoMaximoEjePosterior1(objeto));
			lstErrores.addAll(validarPesoMaximoEjePosterior2(objeto));
			lstErrores.addAll(validarPesoMaximoEjePosterior3(objeto));
			lstErrores.addAll(validarRevisa1(objeto, dua));
			lstErrores.addAll(validarFobPaisExportacion(objeto, dua));
			lstErrores.addAll(validarGastosReparacion(objeto, dua));
			lstErrores.addAll(validarExtension(objeto, dua));
			lstErrores.addAll(validarCorrelacion(objeto));
		}
		return lstErrores;
	}

	/*
	 * R642: El SEIDA valida que se transmita el c�digo correspondiente a la
	 * categor�a del veh�culo conjuntamente con la clase o combinaci�n especial
	 * para las categor�as M, N y O, seg�n el cat�logo de datos de la Tabla V1.
	 * Los veh�culos de la Categor�a L no declaran la clase o combinaci�n
	 * especial.El sistema valida que en la declaraci�n de la carrocer�a :
	 * Chasis Motorizado (c�digo CHM) el sistema permita declarar la Categor�a
	 * del veh�culo (M2 o M3) sin asociarlo a la clase o combinaci�n especial.
	 */
	public List<ErrorDescrMinima> validarCategoria(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar = vehiculo.getCategoria().getValtipdescri().trim();
		if ((CAT_VEH_M2.equals(datoAValidar) || CAT_VEH_M3.equals(datoAValidar))
				&& !CHASIS_MOTORIZADO.equals(vehiculo.getCarroceria()
						.getValtipdescri().trim())) {
			Object[] argumentos = new Object[] { datoAValidar };
			ErrorDescrMinima error = obtenerError("31829",
					vehiculo.getCategoria(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	/*
	 * R643: El SEIDA valida que se transmita el c�digo correspondiente a la
	 * marca comercial del veh�culo, seg�n el cat�logo de datos de la Tabla V2.
	 */
	public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	/*
	 * R644: El SEIDA valida que se transmita el c�digo correspondiente al
	 * modelo del veh�culo, seg�n el cat�logo de datos de la Tabla VB
	 */
	public List<ErrorDescrMinima> validarModelo(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	/*
	 * R645: Valida que transmita un n�mero entero menor o igual al a�o de la
	 * numeraci�n y mayor a 1900.
	 */
	public List<ErrorDescrMinima> validarAnnoFabricacion(ModelAbstract objeto,
			Declaracion dua) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Integer fechaNumeracion;
		Calendar fecha = new GregorianCalendar();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (obtenerItem(objeto, dua).getAnnfabrica() == null)
			datoAValidar = "";
		else
			datoAValidar = obtenerItem(objeto, dua).getAnnfabrica().toString()
			.trim();
		if (dua.getDua().getFecNumeracion() == null)
			fechaNumeracion = fecha.get(Calendar.YEAR);
		else
			fechaNumeracion = SunatDateUtils.getAnho(dua.getDua().getFecNumeracion());//.getYear(); //se cambia porque getYear() esta deprecado AREY SAU20153D212200079
		if (!(SunatStringUtils.isEmpty(datoAValidar))) {
			if (noCumpleRango(datoAValidar, 1900, fechaNumeracion)) {
				Object[] demasArgumentosMSJError = new Object[] {
						vehiculo.getNumsecprove(), vehiculo.getNumsecfact(),
						vehiculo.getNumsecitem(),
						"A�OFABRICACION-A�O DE FABRICACION", datoAValidar };
				ErrorDescrMinima error = obtenerError("31601",
						ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,
						demasArgumentosMSJError);
				lstErroresDescrMin.add(error);
			}
		} else {
			Object[] demasArgumentosMSJError = new Object[] {
					vehiculo.getNumsecprove(), vehiculo.getNumsecfact(),
					vehiculo.getNumsecitem(),
					"A�OFABRICACION-A�O DE FABRICACION", datoAValidar };
			ErrorDescrMinima error = obtenerError("31601",
					ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,
					demasArgumentosMSJError);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	/**Adicionado por PAS20155E220000508**/
	private boolean tieneObsItem(ModelAbstract objeto, Declaracion dua) {
		Boolean result = false;
		Elementos<Observacion> lstObsItem ;
		lstObsItem = obtenerItem(objeto, dua).getListObservaciones();
		if(!CollectionUtils.isEmpty(lstObsItem)){
			for(Observacion obs:lstObsItem){
				if(obs.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_ITEMSFORMB)){
					if(!SunatStringUtils.isEmpty(obs.getObsdeclaracion())
							&& obs.getObsdeclaracion().trim().length()>=20){//que tenga sustento
						result=true;
						break;
					}
				}
			}
		} else {
			Elementos<Observacion> listObservaciones = dua.getDua().getListObservaciones();
			if (!CollectionUtils.isEmpty(listObservaciones)) {
				DatoItem item =  obtenerItem(objeto, dua);
				for (Observacion obs : listObservaciones) {
					if (obs.getCodtipobserva().equals(Constants.COD_TIP_OBSERV_ITEMSFORMB)
							&& obs.getNumsecitem()!=null && obs.getNumsecitem().equals(item.getNumsecitem())) {
						if (!SunatStringUtils.isEmpty(obs.getObsdeclaracion())
								&& obs.getObsdeclaracion().trim().length()>=20){//que tenga sustento
							result = true;
							break;

						}

					}
				}
			}
		}

		return result;
	}


	// R647: Carrocer�a: El SEIDA valida que para las categor�as L, M, N y O
	// transmita el c�digo correspondiente
	// a la carrocer�a del veh�culo, seg�n el cat�logo de datos de la Tabla V3.
	public List<ErrorDescrMinima> validarCarroceria(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R649: Color Principal: El SEIDA valida que para las categor�as L, M, N y
	// O se transmita el c�digo correspondiente
	// al color principal, seg�n el cat�logo de datos de la Tabla V4.
	public List<ErrorDescrMinima> validarColorPrincipal(ModelAbstract objeto) {

		/*
		 * Inicio de cambios PAS20155E220000407 R649: En caso se haya consignado
		 * como carrocer�a tipo Chasis Motorizado (c�digo CHM), no se debe
		 * exigir la transmisi�n de este campo. Para todos los demas es
		 * Mandatorio
		 */
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;

		String valCarroceria = vehiculo.getCarroceria().getValtipdescri()
				.trim();

		if (vehiculo.getColorPrincipal() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getColorPrincipal().getValtipdescri()
			.trim(); 

		if (!valCarroceria.equals(CHASIS_MOTORIZADO)) {
			if (SunatStringUtils.isEmpty(datoAValidar)) { 
				ErrorDescrMinima error = obtenerError("35601",
						vehiculo.getColorPrincipal());
				lstErroresDescrMin.add(error);
			}
		}/* Fin de cambios PAS20155E220000407 */ 
		return lstErroresDescrMin;
	}

	// R651: Tipo de combustible: El SEIDA valida que para las categor�as L, M y
	// N transmita el c�digo de tipo de
	// combustible, seg�n catalogo de datos de la tabla V6
	public List<ErrorDescrMinima> validarTipoCombustible(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getTipoCombustible() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getTipoCombustible().getValtipdescri()
			.trim();

		String val_caracter = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter)
				|| CATEGORIA_M.equals(val_caracter) || CATEGORIA_N
				.equals(val_caracter)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31818",
						vehiculo.getTipoCombustible(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else {
			if (!SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31602",
						vehiculo.getTipoCombustible(), argumentos);
				lstErroresDescrMin.add(error);
			}
		}

		return lstErroresDescrMin;
	}

	// R650: Color secundario: El SEIDA valida que opcionalmente para las
	// categor�as L, M, N y O se transmita el c�digo
	// correspondiente al color secundario, seg�n el cat�logo de datos de la
	// Tabla V4.
	public List<ErrorDescrMinima> validarColorSecundario(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R652: Indicador SNTT: El SEIDA valida que se transmita el c�digo
	// correspondiente al indicador SNTT, seg�n el
	// cat�logo de datos de la Tabla VC.
	public List<ErrorDescrMinima> validarIndicadorSNTT(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R653: Versi�n: El SEIDA valida que para las categor�as M y N transmita la
	// versi�n del veh�culo, S�lo se aceptan,
	// letras, n�meros y guiones hasta un m�ximo de 20 caracteres. La
	// transmisi�n de la versi�n de los veh�culos de la
	// categor�a L y O es condicional
	public List<ErrorDescrMinima> validarVersion(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getVersion() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getVersion().getValtipdescri().trim();

		String val_caracter = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		if ((CATEGORIA_M.equals(val_caracter) || CATEGORIA_N.equals(val_caracter) ||CATEGORIA_L.equals(val_caracter) || CATEGORIA_O.equals(val_caracter))//gmontoya Pase 436 - 2015
				&& SunatStringUtils.isEmpty(datoAValidar)) {
			Object[] argumentos = new Object[] { vehiculo.getCategoria()
					.getValtipdescri() };
			ErrorDescrMinima error = obtenerError("31603",
					vehiculo.getVersion(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R648: Tipo de Moto: En caso de la categor�a L, el SEIDA valida que se
	// transmita el c�digo correspondiente
	// al Tipo de Moto seg�n el cat�logo de datos de la Tabla V9.
	public List<ErrorDescrMinima> validarMoto(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar = vehiculo.getTipoMoto().getValtipdescri().trim();
		if (vehiculo.getTipoMoto() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getTipoMoto().getValtipdescri().trim();

		String val_caracter = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		boolean esObligatorio = CATEGORIA_L.equals(val_caracter) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31594",
						vehiculo.getTipoMoto(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getTipoMoto().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getTipoMoto(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R655: Cilindrada en CC: El SEIDA valida que cuando se trate de las
	// categor�as L, M y N, siempre env�e un
	// valor de la cilindrada, el valor debe ser un n�mero mayor a 30 con una
	// longitud m�ximo de 6 d�gitos.
	public List<ErrorDescrMinima> validarCilindradaCC(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getCilindradaCC() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getCilindradaCC().getValtipdescri().trim();

		String val_caracter = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter)
				|| CATEGORIA_M.equals(val_caracter) || CATEGORIA_N
				.equals(val_caracter))) ? true : false;

		// INICIO GMONTOYA 436 - 2015
		String valTipoCombustible = vehiculo.getTipoCombustible()
				.getValtipdescri().trim();
		// FIN GMONTOYA 436 - 2015

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)
					&& !valTipoCombustible
					.equals(TIPO_COMBUSTIBLE_EXONERADO_CILINDRO))// GMONTOYA
			// 436
			// -
				// 2015
			{
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31604",
						vehiculo.getCilindradaCC(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente de L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getCilindradaCC().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getCilindradaCC(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R656: N�mero de chasis: El SEIDA valida que si no transmiti� el VIN debe
	// transmitir el n�mero de chasis, aceptando
	// que se consigne n�meros, letras y guiones. Asimismo, Valida que los
	// veh�culos de la categor�a O1 transmitan
	// obligatoriamente el N�mero de Chasis. El valor enviado debe ser un dato
	// alfanum�rico con una longitud m�ximo de 20 caracteres
	public List<ErrorDescrMinima> validarNumeroChasis(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getNumeroChasis() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroChasis().getValtipdescri().trim();
		String numeroVIM = vehiculo.getNumeroVIN().getValtipdescri().trim();
		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 2);
			if (CAT_VEH_O1.equals(val_caracter)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31606",
						vehiculo.getNumeroChasis(), argumentos);
				lstErroresDescrMin.add(error);
			}
			if (SunatStringUtils.isEmpty(numeroVIM)) {
				ErrorDescrMinima error = obtenerError("31607",
						vehiculo.getNumeroChasis());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}

	// R657: N�mero de VIN: El SEIDA valida que para las categor�as L, M, N, O
	// se transmita el n�mero de VIN, excepto
	// cuando haya consignado el c�digo de exoneraci�n del VIN. El n�mero de VIN
	// debe tener 17 caracteres alfanum�ricos,
	// no debe contener espacios en blanco, no debe incluir en su composici�n
	// las letras I, O y Q ni caracteres
	// especiales. La transmisi�n del VIN de los veh�culos de la categor�a O1 es
	// condicional. El SEIDA valida que si no
	// transmiti� el n�mero de VIN ni el Chasis, no se acepta la transmisi�n.
	public List<ErrorDescrMinima> validarNumeroVIN(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String codigoExoneracionVIM,
		// numeroChasis,//GMONTOYA 436 - 2015
		datoAValidar;

		if (vehiculo.getNumeroVIN() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroVIN().getValtipdescri().trim();
		if (vehiculo.getCodigoExoneracionVIN() == null)
			codigoExoneracionVIM = "";
		else
			codigoExoneracionVIM = vehiculo.getCodigoExoneracionVIN()
			.getValtipdescri();
		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 2);
			Boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
					|| CATEGORIA_M.equals(val_caracter01)
					|| CATEGORIA_N.equals(val_caracter01)
					|| CATEGORIA_O2.equals(val_caracter02)
					|| CATEGORIA_O3.equals(val_caracter02) || CATEGORIA_O4
					.equals(val_caracter02)) && SunatStringUtils
					.isEmpty(codigoExoneracionVIM)) ? true : false;
			if (esObligatorio) {
				if (SunatStringUtils.isEmpty(codigoExoneracionVIM)) {
					ErrorDescrMinima error = obtenerError("31608",
							vehiculo.getNumeroVIN());
					lstErroresDescrMin.add(error);
				}
				if (CATEGORIA_L.equals(val_caracter01)
						|| CATEGORIA_M.equals(val_caracter01)
						|| CATEGORIA_N.equals(val_caracter01)
						|| CATEGORIA_O2.equals(val_caracter02)
						|| CATEGORIA_O3.equals(val_caracter02)
						|| CATEGORIA_O4.equals(val_caracter02)) {
					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31609",
							vehiculo.getNumeroVIN(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		}
		return lstErroresDescrMin;
	}

	// R658: "C�digo de exoneraci�n del VIN: El SEIDA valida que cuando se
	// transmita el c�digo de exoneraci�n del VIN,
	// �ste corresponda s�lo para las categor�as L, M, N, O conforme a la tabla
	// VA. Asimismo, valida que:
	// - Si el c�digo de exoneraci�n del VIN es �01� y la fecha de embarque es >
	// 22/11/2002, no se acepta la transmisi�n.
	// - Si el c�digo de exoneraci�n del VIN es �01� y el r�gimen de precedencia
	// es = 91 no se acepta la transmisi�n.
	// - Si el c�digo de exoneraci�ndel VIN es �02� y el r�gimen de precedencia
	// es <> 91 no se acepta la transmisi�n.
	// - Si se transmite el VIN y el c�digo de exoneraci�n VIN simult�neamente,
	// no se acepta la transmisi�n.
	// - Si no se transmite el VIN ni el c�digo de exoneraci�n VIN, no se acepta
	// la transmisi�n.
	// No deben estar vacios simult�neamente los campos de n�mero de VIN y
	// c�digo de exoneraci�n de VIN cuando se ha
	// declarado el n�mero de chasis."
	public List<ErrorDescrMinima> validarCodigoExoneracionVIN(
			ModelAbstract objeto, Declaracion dua) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, numeroVIN, numeroChasis;
		if (vehiculo.getCodigoExoneracionVIN() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getCodigoExoneracionVIN().getValtipdescri()
			.trim();
		if (vehiculo.getNumeroVIN() == null)
			numeroVIN = "";
		else
			numeroVIN = vehiculo.getNumeroVIN().getValtipdescri().trim();
		if (vehiculo.getNumeroChasis() == null)
			numeroChasis = "";
		else
			numeroChasis = vehiculo.getNumeroChasis().getValtipdescri().trim();
		List<DatoDocTransporte> ListDoc = dua.getDua().getListDocTransporte();
		List<DatoRegPrecedencia> ListRegPre = obtenerSerie(objeto, dua)
				.getListRegPrecedencia();
		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			if (!CATEGORIA_O1.equals(vehiculo.getCategoria().getValtipdescri()
					.trim())) {
				if ((CATEGORIA_L.equals(val_caracter01)
						|| CATEGORIA_M.equals(val_caracter01)
						|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
						.equals(val_caracter01))
						&& (SunatStringUtils.isEmpty(numeroVIN))) {
					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31612",
							vehiculo.getCodigoExoneracionVIN(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		}
		Date date1 = new Date();
		for (DatoDocTransporte doctransporte : ListDoc) {
			try {
				date1 = sdf.parse("2002-11-22");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (datoAValidar.equalsIgnoreCase("01")) {
				if (doctransporte.getFecembarque().after(date1)) {
					ErrorDescrMinima error = obtenerError("31613",
							vehiculo.getCodigoExoneracionVIN());
					lstErroresDescrMin.add(error);
				} else if (EncontradoEnLista(ListRegPre, COD_REG_PREC_91)) {
					ErrorDescrMinima error = obtenerError("31614",
							vehiculo.getCodigoExoneracionVIN());
					lstErroresDescrMin.add(error);
				}
			} else if (datoAValidar.equalsIgnoreCase("02")) {
				if (!EncontradoEnLista(ListRegPre, COD_REG_PREC_91)) {
					ErrorDescrMinima error = obtenerError("31615",
							vehiculo.getCodigoExoneracionVIN());
					lstErroresDescrMin.add(error);
				}
			}
		}

		if ((SunatStringUtils.isEmpty(numeroVIN) && SunatStringUtils
				.isEmpty(datoAValidar))
				&& !(SunatStringUtils.isEmpty(numeroChasis))) {
			ErrorDescrMinima error = obtenerError("31616",
					vehiculo.getCodigoExoneracionVIN());
			lstErroresDescrMin.add(error);
		}

		if (!SunatStringUtils.isEmpty(numeroVIN)
				&& !(SunatStringUtils.isEmpty(datoAValidar))) {
			ErrorDescrMinima error = obtenerError("31617",
					vehiculo.getCodigoExoneracionVIN());
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	private boolean EncontradoEnLista(List<DatoRegPrecedencia> list, String cod) {
		Boolean result = false;
		//PAS20165E220200137 amancilla
		if(CollectionUtils.isEmpty(list)) return result;
		for (DatoRegPrecedencia regPre : list) {
			if (regPre.getCodregipre().equalsIgnoreCase(cod)) {
				result = true;
				break;
			} else
				result = false;
		}
		return result;
	}

	// R659: N�mero de Motor: El SEIDA valida que cuando se trate de las
	// categor�as L, M, N, siempre env�e un valor para
	// el n�mero de motor. S�lo se aceptan, letras, n�meros y guiones. El valor
	// enviado debe ser un dato alfanum�rico con
	// una longitud m�xima de 20 caracteres.
	public List<ErrorDescrMinima> validarNumeroMotor(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getNumeroMotor() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroMotor().getValtipdescri().trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) ? true : false; 
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31593",
						vehiculo.getNumeroMotor(), argumentos);
				lstErroresDescrMin.add(error);
			} 

		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getNumeroMotor().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getNumeroMotor(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R654: N�mero de cilindros: El SEIDA valida que cuando se trate de las
	// categor�as L, M, N, siempre env�e un valor
	// para el n�mero de cilindros, el valor debe ser mayor a cero y con una
	// longitud m�xima de 2 d�gitos.
	public List<ErrorDescrMinima> validarNumeroCilindros(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getNumeroCilindros() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroCilindros().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) ? true : false;

		// INICIO GMONTOYA 436 - 2015
		String valTipoCombustible = vehiculo.getTipoCombustible()==null?"":vehiculo.getTipoCombustible().getValtipdescri().trim();
		// FIN GMONTOYA 436 - 2015

		if (esObligatorio) {
			if (!valTipoCombustible
					.equals(TIPO_COMBUSTIBLE_EXONERADO_CILINDRO)) {// GMONTOYA
				// 436 -
				// 2015
				if (SunatStringUtils.isEmpty(datoAValidar)) {

					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31618",
							vehiculo.getNumeroCilindros(), argumentos);
					lstErroresDescrMin.add(error);

				} else {
					int datoAValidar_int = SunatNumberUtils.toInteger(datoAValidar);
					if (!SunatNumberUtils.isGreaterThanZero(datoAValidar_int)) {
						ErrorDescrMinima error = obtenerError("31766",
								vehiculo.getNumeroCilindros());
						lstErroresDescrMin.add(error);
					}
				}
			}// GMONTOYA 436 - 2015
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente de L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getNumeroCilindros().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getNumeroCilindros(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R660: Tipo de encendido: El SEIDA valida que para las categor�as L, M y
	// N, se transmita el c�digo correspondiente
	// al Tipo de encendido, seg�n el cat�logo de datos de la Tabla VG. De
	// declarar el c�digo ZZZ (Otros) deber� indicar
	// su descripci�n. Debe ser un dato alfanum�rico con una longitud m�xima de
	// 18 caracteres, donde se acepten n�meros,
	// letras y espacio en blanco.
	public List<ErrorDescrMinima> validarTipoEncendido(ModelAbstract objeto, Declaracion dua) {//gmontoya Pase 436 - 2015
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getTipoEncendido() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getTipoEncendido().getValtipdescri().trim();

		// inicio gmontoya Pase 436 - 2015
		String estadoMercancia = obtenerSerie(objeto, dua).getCodestamerca();
		boolean esUsado = false;
		if (SunatStringUtils.include(estadoMercancia, new String[] { "20",
				"21", "22", "23", "24", "25", "26", "27", "28" })) {
			esUsado = true;
		}
		// fin gmontoya Pase 436 - 2015

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri().substring(0, 1);//gmontoya Pase 436 - 2015
		boolean esObligatorio =// esUsado;//gmontoya Pase 436 - 2015
				//				inicio gmontoya Pase 436 - 2015
				(CATEGORIA_L.equals(val_caracter01)
						|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
						.equals(val_caracter01)) ? true : false;//R660 para las categor�as L, M y N y cuando se trate de veh�culos usados PASE469 arey
		//				fin gmontoya Pase 436 - 2015

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				if(esUsado){
					Object[] argumentos = new Object[] { vehiculo.getCategoria()
							.getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31620",
							vehiculo.getTipoEncendido(), argumentos);
					lstErroresDescrMin.add(error);
				}
			} else {
				if (TIPO_VALOR_ZZZ.equals(vehiculo.getTipoEncendido()
						.getCodtipvalor())) {
					if (noCumpleExpresionRegular(datoAValidar, EXP_REG_ZZZ_1))
						lstErroresDescrMin.add(obtenerError("31739",
								vehiculo.getTipoEncendido()));
				}
			}
		} 

		return lstErroresDescrMin;
	}

	// R664: "N�mero de asientos: El SEIDA valida que siempre para las
	// categor�as L, M y N, se transmita la cantidad de
	// asientos, verificando:
	// Si la categor�a es M1 la cantidad puede ser >=1 y <= 9
	// Si la categor�a es M2 la cantidad de asientos puede ser >=10 y <=99
	// Si la categor�a es M3 la cantidad de asientos puede ser >= 10 y <=99
	// En los dem�s casos la cantidad de asientos puede ser desde 0 hasta 99.
	// El valor enviado debe ser un dato num�rico mayor o igual a cero con una
	// longitud m�xima de 2 d�gitos"
	public List<ErrorDescrMinima> validarNumeroAsientos(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getNumeroAsientos() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroAsientos().getValtipdescri()
			.trim();

		/*
		 * Inicio de cambios PAS20155E220000407 R664: En caso se haya consignado
		 * como carrocer�a tipo Chasis Motorizado (c�digo CHM), no se debe
		 * exigir la transmisi�n de este campo.
		 */
		String valCarroceria = vehiculo.getCarroceria().getValtipdescri()
				.trim();// arey
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) ? true : false;

		if (esObligatorio && !valCarroceria.equals(CHASIS_MOTORIZADO))// arey
		{
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31621",
						vehiculo.getNumeroAsientos(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				String val_caracter02 = vehiculo.getCategoria()
						.getValtipdescri().substring(0, 2);
				if (CAT_VEH_M1.equals(val_caracter02)
						&& noCumpleRango(datoAValidar, 1, 9)) {
					ErrorDescrMinima error = obtenerError("31622",
							vehiculo.getNumeroAsientos());
					lstErroresDescrMin.add(error);
				} else if ((CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
						.equals(val_caracter02))
						&& noCumpleRango(datoAValidar, 10, 99)) {
					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31623",
							vehiculo.getNumeroAsientos(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}

		} else if (!SunatStringUtils.isEmpty(datoAValidar)
				&& !valCarroceria.equals(CHASIS_MOTORIZADO))// arey
		{
			String regla = "la categoria consignada es diferente a L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getNumeroAsientos().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getNumeroAsientos(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R665: "Cantidad de ejes: El SEIDA valida que siempre se transmita para
	// las
	// categor�as M (excepto la clase M1), N
	// y O, verificando:
	// Que la cantidad de ejes sea mayor a 1, si la categor�a es O tambi�n puede
	// ser 1.
	// El valor enviado debe ser un dato num�rico mayor a 1 con una longitud
	// m�xima de 2 d�gitos por lo
	// tanto el n�mero m�ximo de ejes es 99. "
	public List<ErrorDescrMinima> validarCantidadEjes(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getCantidadEjes() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getCantidadEjes().getValtipdescri().trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);

		boolean esObligatorio = (CATEGORIA_N.equals(val_caracter01)
				|| CATEGORIA_O.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31624",
						vehiculo.getCantidadEjes(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (!CATEGORIA_O.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 2, 99)) {
					ErrorDescrMinima error = obtenerError("31625",
							vehiculo.getCantidadEjes());
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_O.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 99)) {
					ErrorDescrMinima error = obtenerError("31626",
							vehiculo.getCantidadEjes());
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M(excepto M1),N,O";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getCantidadEjes().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getCantidadEjes(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R666: Formula rodante: El SEIDA valida que siempre se debe consignar para
	// las categor�as L, M y N, se valida
	// que se consigne el valor conforme a la tabla V7
	public List<ErrorDescrMinima> validarFormulaRodante(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getTipoTraccion() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getTipoTraccion().getValtipdescri().trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31627",
						vehiculo.getTipoTraccion(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getTipoTraccion().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getTipoTraccion(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R661: Tipo de transmisi�n: El SEIDA valida que siempre para las
	// categor�as
	// L, M y N, se transmita el c�digo
	// correspondiente al Tipo de transmisi�n, seg�n el cat�logo de datos de la
	// Tabla V5.
	public List<ErrorDescrMinima> validarTipoTransmision(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getTipoTransmision() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getTipoTransmision().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		boolean esObligatorio = (CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31628",
						vehiculo.getTipoTransmision(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getTipoTransmision().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getTipoTransmision(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R667: N�mero de pasajeros: El SEIDA valida que se transmita para las
	// categor�as L, M y N siempre y cuando el
	// indicador de SNTT sea 0. Debe ser un n�mero entero mayor o igual a la
	// cantidad del N�mero de asientos. El valor
	// enviado debe ser un dato num�rico mayor o igual a la cantidad de n�mero
	// de asientos, con una longitud m�xima de
	// 3 d�gitos por lo tanto el n�mero m�ximo de pasajeros es 999
	public List<ErrorDescrMinima> validarNumeroPasajeros(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		Integer numeroAsientos;
		if (vehiculo.getNumeroPasajeros() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroPasajeros().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		/*
		 * Inicio de cambios PAS20155E220000407 R667: En caso se haya consignado
		 * como carrocer�a tipo Chasis Motorizado (c�digo CHM), no se debe
		 * exigir la transmisi�n de este campo.
		 */
		String valCarroceria = vehiculo.getCarroceria().getValtipdescri()
				.trim();

		boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio && !valCarroceria.equals(CHASIS_MOTORIZADO)) {// arey

			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31629",
						vehiculo.getNumeroPasajeros(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)
				&& !valCarroceria.equals(CHASIS_MOTORIZADO))// arey
		{
			String regla = "la categoria consignada es diferente a L,M,N o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getNumeroPasajeros().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getNumeroPasajeros(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R668: Potencia de Motor: El SEIDA valida que siempre para las categor�as
	// L,
	// M y N, se transmita la potencia y
	// revoluciones x minuto separados por el car�cter �@�. siempre y cuando el
	// indicador de SNTT sea 0
	// "Se valida que el valor de la potencia del motor sea un n�mero v�lido,
	// siendo la parte entera no mayor de cuatro
	// d�gitos y la parte decimal hasta 2 d�gitos.
	// La potencia en KW se declara en los 7 primeros caracteres, donde los 4
	// primeros corresponde a la parte entera
	// debiendo ser un n�mero entero mayor a cero, el siguiente car�cter debe
	// ser
	// para la coma y los dos siguientes
	// caracteres corresponden a la parte decimal debiendo ser un n�mero entero
	// mayor a cero.
	// El 8vo car�cter debe ser una @, que se utiliza como separador de dato."
	// Se valida que el valor de las revoluciones x minuto (RPM) sea un n�mero
	// entero v�lido no mayor de cinco d�gitos mayor a cero.
	public List<ErrorDescrMinima> validarPotenciaMotorKW(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPotenciaMotorKW() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPotenciaMotorKW().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31631",
						vehiculo.getPotenciaMotorKW(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getPotenciaMotorKW().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getPotenciaMotorKW(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R668: Idem
	public List<ErrorDescrMinima> validarPotenciaMotorRPM(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPotenciaMotorRPM() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPotenciaMotorRPM().getValtipdescri()
			.trim();

		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);

		boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01) || CATEGORIA_N
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31631",
						vehiculo.getPotenciaMotorRPM(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getPotenciaMotorRPM().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getPotenciaMotorRPM(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R669: "Relaci�n Potencia/peso bruto vehicular: El SEIDA valida que
	// siempre
	// se debe consignar para las categor�as M (excepto para la clase M1), N,
	// siempre y cuando el
	// indicador de SNTT sea 0, verificando lo siguiente:
	// Si la categor�a es M2, M3, N2 y N3 el valor debe ser >=4.85
	// En los dem�s casos debe ser >=0.1
	// El valor enviado debe tener la siguiente estructura, los 3 primeros
	// caracteres corresponde a la parte entera
	// debiendo ser un n�mero entero mayor a cero, el siguiente car�cter debe
	// ser
	// para la coma y los dos siguientes
	// caracteres corresponde a la parte decimal debiendo ser un n�mero entero
	// mayor a cero. El valor m�ximo aceptado es 999,99."

	public List<ErrorDescrMinima> validarPotenciaPesoBruto(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getRelacionPotenciaPesoBruto() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getRelacionPotenciaPesoBruto()
			.getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);

		boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31632",
						vehiculo.getRelacionPotenciaPesoBruto(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				BigDecimal datoAValidarN = new BigDecimal(
						datoAValidar.replaceAll(",", "."));
				if ((CAT_VEH_M2.equals(val_caracter02)
						|| CAT_VEH_M3.equals(val_caracter02)
						|| CAT_VEH_N2.equals(val_caracter02) || CAT_VEH_N3
						.equals(val_caracter02))
						&& SunatNumberUtils
						.isLessThanParam(datoAValidarN, 4.85)) {
					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31633",
							vehiculo.getRelacionPotenciaPesoBruto(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (SunatNumberUtils
						.isLessThanParam(datoAValidarN, 0.10)) {
					Object[] argumentos = new Object[] { vehiculo
							.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31634",
							vehiculo.getRelacionPotenciaPesoBruto(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M(excepto M1),N o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getRelacionPotenciaPesoBruto().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getRelacionPotenciaPesoBruto(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R670: "Peso bruto vehicular combinado: El SEIDA valida que siempre se
	// debe consignar para las categor�as M
	// (excepto para la clase M1), N, siempre y cuando el indicador de SNTT, el
	// valor debe ser > 0
	// El valor enviado debe tener la siguiente estructura, los 3 primeros
	// caracteres corresponde a la parte entera
	// debiendo ser un n�mero entero mayor a cero, el siguiente car�cter debe
	// ser
	// para la coma y los dos siguientes
	// caracteres corresponde a la parte decimal debiendo ser un n�mero entero
	// mayor a cero. El valor m�ximo aceptado es 999,99."
	public List<ErrorDescrMinima> validarPesoBrutoCombinado(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoBrutoCombinado() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoBrutoCombinado().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);

		boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01) || (CAT_VEH_M2
				.equals(val_caracter02) || CAT_VEH_M3.equals(val_caracter02))) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31636",
						vehiculo.getPesoBrutoCombinado(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M(excepto M1),N o  SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getPesoBrutoCombinado().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getPesoBrutoCombinado(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R671: Peso bruto vehicular en kg: El SEIDA valida que siempre debe
	// transmitir en las categor�as L, M, N, O,
	// siempre y cuando el indicador de SNTT sea 0. El valor del peso bruto
	// vehicular debe ser > 0
	public List<ErrorDescrMinima> validarPesoBrutoKG(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoBrutoKG() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoBrutoKG().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			if ((CATEGORIA_L.equals(val_caracter01)
					|| CATEGORIA_M.equals(val_caracter01)
					|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
					.equals(val_caracter01))
					&& INDICADOR_SNTT_0.equals(indicadorSNTT)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31638",
						vehiculo.getPesoBrutoKG(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else {
			if (!datoAValidar.isEmpty()) {
				int datoAValidar_int = SunatNumberUtils.toInteger(datoAValidar);
				if (!SunatNumberUtils.isGreaterThanZero(datoAValidar_int)) {
					ErrorDescrMinima error = obtenerError("31767",
							vehiculo.getPesoBrutoKG());
					lstErroresDescrMin.add(error);
				}
			}
		}
		return lstErroresDescrMin;
	}

	// R672: Peso neto vehicular en kg: El SEIDA valida que siempre debe
	// transmitir en las categor�as L, M, N, O,
	// siempre y cuando el indicador de SNTT sea 0. El valor del peso bruto
	// vehicular debe ser > 0 y < Peso bruto vehicular
	public List<ErrorDescrMinima> validarPesoNetoKG(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoNetoKG() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoNetoKG().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			if ((CATEGORIA_L.equals(val_caracter01)
					|| CATEGORIA_M.equals(val_caracter01)
					|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
					.equals(val_caracter01))
					&& INDICADOR_SNTT_0.equals(indicadorSNTT)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31640",
						vehiculo.getPesoNetoKG(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else {
			if (!vehiculo.getPesoBrutoKG().getValtipdescri().trim().isEmpty()) {
				int pesoBrutoKG = Integer.parseInt(vehiculo.getPesoBrutoKG()
						.getValtipdescri());
				int pesoNetoKG = Integer.parseInt(datoAValidar);
				if (pesoNetoKG <= 0 || pesoNetoKG >= pesoBrutoKG) {
					ErrorDescrMinima error = obtenerError("31641",
							vehiculo.getPesoNetoKG());
					lstErroresDescrMin.add(error);
				}
			}
		}
		return lstErroresDescrMin;
	}

	// R673: Carga �til en kg: El SEIDA valida que siempre debe transmitir en
	// las
	// categor�as L, M, N, O, siempre y
	// cuando el indicador de SNTT sea 0. El valor de la carga �til debe ser =
	// Peso bruto - Peso neto
	public List<ErrorDescrMinima> validarCargaUtilKG(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getCargaUtilKG() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getCargaUtilKG().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		if (SunatStringUtils.isEmpty(datoAValidar)) {
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			if ((CATEGORIA_L.equals(val_caracter01)
					|| CATEGORIA_M.equals(val_caracter01)
					|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
					.equals(val_caracter01))
					&& INDICADOR_SNTT_0.equals(indicadorSNTT)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31642",
						vehiculo.getCargaUtilKG(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else {
			if (!vehiculo.getPesoBrutoKG().getValtipdescri().trim().isEmpty()
					&& !vehiculo.getPesoNetoKG().getValtipdescri().trim()
					.isEmpty()) {
				Integer pesoBrutoKG = Integer.parseInt(vehiculo
						.getPesoBrutoKG().getValtipdescri());
				Integer pesoNetoKG = Integer.parseInt(vehiculo.getPesoNetoKG()
						.getValtipdescri());
				Integer diferenciaPeso = pesoBrutoKG - pesoNetoKG;
				if (noCumpleRango(datoAValidar, diferenciaPeso, diferenciaPeso)) {
					ErrorDescrMinima error = obtenerError("31643",
							vehiculo.getCargaUtilKG());
					lstErroresDescrMin.add(error);
				}
			}
		}
		return lstErroresDescrMin;
	}

	// R646; Valida que transmita un n�mero entero de 4 d�gitos que corresponde
	// a un a�o mayor o igual al a�o de
	// fabricaci�n y menor o igual que un a�o mas que el de la numeraci�n. (A�o
	// del modelo)
	//con excepcion de que haya sustento >20 caracteres en las obs del item PAS20155E220000508
	public List<ErrorDescrMinima> validarAnnModelo(ModelAbstract objeto,
			Declaracion dua) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Integer unAnnoMasAlDeNumeracion;
		Calendar fecha = new GregorianCalendar();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar;
		if (vehiculo.getAnnoModelo() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getAnnoModelo().getValtipdescri().trim();
		Integer annoFabricacion = obtenerItem(objeto, dua)
				.getAnnfabricaAsInteger();
		if (!SunatStringUtils.isEmpty(datoAValidar)) {
			if (dua.getDua().getFecNumeracion() == null)
				unAnnoMasAlDeNumeracion = fecha.get(Calendar.YEAR) + 1;
			else
				unAnnoMasAlDeNumeracion = SunatDateUtils.getAnho(dua.getDua().getFecNumeracion())+1;//AREY SAU20153D212200079
				//.getYear() + 1;//se cambia porque getYear() esta deprecado AREY SAU20153D212200079
			Calendar c1 = Calendar.getInstance();
			String annioActual = Integer.toString(c1.get(Calendar.YEAR));
			if (noCumpleRango(datoAValidar, annoFabricacion,
					unAnnoMasAlDeNumeracion)) {
				if(!tieneObsItem(objeto, dua)){//adicionado por pase PAS20155E220000508
					Object[] argumentos = new Object[] { datoAValidar,
							annoFabricacion, annioActual };
					ErrorDescrMinima error = obtenerError("31644",
							vehiculo.getAnnoModelo(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		}
		return lstErroresDescrMin;
	}

	// R674: "Kilometraje: El SEIDA valida que.....
	public List<ErrorDescrMinima> validarKilometraje(ModelAbstract objeto,
			Declaracion dua) {
		CatRevisa1DAO catRevisa1DAO = fabricaDeServicios.getService("catRevisa1DAO");
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		vehiculo.setNombreComercial(vehiculo.getCategoria()); // A refactorizar
		String datoAValidar;
		BigDecimal datoAValidar_bd = BigDecimal.ZERO;
		if (vehiculo.getKilometraje() == null)
			datoAValidar = "";
		else {
			datoAValidar = vehiculo.getKilometraje().getValtipdescri().trim();
			if (!SunatStringUtils.isEmpty(datoAValidar)) {
				datoAValidar = datoAValidar.replace(",", ".");
				datoAValidar_bd = new BigDecimal(datoAValidar);
			}
		}
		List<DatoDocTransporte> ListDoc = dua.getDua().getListDocTransporte();
		Date fechaTermino = dua.getDua().getManifiesto().getFectermino();
		String codigoEstadoMercancia = obtenerItem(objeto, dua).getCodestamer();
		String codigoTratoPreferencial = obtenerSerie(objeto, dua)
				.getCodtratprefe().toString();
		// inicio gmontoya Pase 436 - 2015
		boolean esUsado = false;
		if (SunatStringUtils.include(codigoEstadoMercancia, new String[] { "20",
				"21", "22", "23", "24", "25", "26", "27", "28" })) {
			esUsado = true;
		}
		// fin gmontoya Pase 436 - 2015
		// String tipoEncendido = vehiculo.getTipoEncendido().getValtipdescri();
		String tipoCampoEncendido = vehiculo.getTipoEncendido()
				.getCodtipvalor();
		DatoItem item = obtenerItem(objeto, dua);
		String subPartida = item.getNumpartnandi().toString();
		String tipoUso = obtenerTipoUso(subPartida, vehiculo);
		String numDoc = dua.getDua().getNumdocumento();
		String aduana = dua.getDua().getCodaduanaorden();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri().substring(0, 1);//gmontoya

		// Pase 436 - 2015
		// String val_caracter02 =
		// vehiculo.getCategoria().getValtipdescri().substring(0, 2);
		Boolean esObligatorio = (esUsado && (!CATEGORIA_O.equals(val_caracter01)))? true: false;//gmontoya Pase 436 -2015//R674corresponde cuando sea usado y no sea categoria O. PASE469 arey

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31645",
						vehiculo.getKilometraje(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (CumpleReglasNegocio1(ListDoc, fechaTermino,
						codigoEstadoMercancia, codigoTratoPreferencial,
						tipoUso, numDoc, aduana)
						&& datoAValidar_bd.compareTo(new BigDecimal("0")) != 1) {
					ErrorDescrMinima error = obtenerError("31646",
							vehiculo.getKilometraje());
					lstErroresDescrMin.add(error);
				} else if (CAMPO_ZZZ.equals(tipoCampoEncendido)
						&& !(SunatNumberUtils.isGreaterThanParam(
								datoAValidar_bd, 0))) {
					ErrorDescrMinima error = obtenerError("31647",
							vehiculo.getKilometraje());
					lstErroresDescrMin.add(error);
				}
				// ---------------
				// Asimismo, si envi� el n�mero de revisa 1 se verifica que se
				// encuentre registrado en el cat�logo de revisa donde el
				// kilometraje registrado
				// debe ser menor o igual al declarado.De no cumplir los l�mites
				// indicados o de ser el caso no se encontr� registrado el
				// n�mero de revisa1(Ver F70)
				String revisa1;
				if (vehiculo.getNumeroRevisa1() == null)
					revisa1 = "";
				else
					revisa1 = vehiculo.getNumeroRevisa1().getValtipdescri()
					.trim();
				if (!(SunatStringUtils.isEmpty(revisa1))) {
					Map<String, Object> paramsRevisa = new HashMap<String, Object>();
					paramsRevisa.put("nrevisa", revisa1);
					Integer Kilometraje = catRevisa1DAO
							.getExisteNkilometra(paramsRevisa);
					if (Kilometraje != null) {
						if (!SunatNumberUtils.isLessOrEqualsThanParam(
								Kilometraje, datoAValidar_bd)) {
							Object[] argumentos = new Object[] { datoAValidar,
									Kilometraje, revisa1 };
							ErrorDescrMinima error = obtenerError("31819",
									vehiculo.getKilometraje(), argumentos);
							lstErroresDescrMin.add(error);
						}
					}
				}
				// ----------------
			}
		}
		//		inicio gmontoya Pase 436 - 2015
		//		else {
		//			if (!SunatStringUtils.isEmpty(datoAValidar)) {
		//				ErrorDescrMinima error = obtenerError("31723",
		//						vehiculo.getKilometraje());
		//				lstErroresDescrMin.add(error);
		//			}
		//		}
		//		fin gmontoya Pase 436 - 2015

		return lstErroresDescrMin;
	}

	private boolean CumpleReglasNegocio1(List<DatoDocTransporte> ListadoDoc,
			Date fechaLlegada, String codigoEstadoMercancia,
			String codigoTratoPreferencial, String tipoUso, String numDoc,
			String aduana) {
		// fecha de embarque declarada debe ser mayor al 23/12/2006, la fecha de
		// llegada declarada debe ser mayor
		// al 24/02/2007, el estado de la mercanc�a es usado y de declarar Trato
		// Preferencial Nacional, el RUC
		// del importador debe est� vigente en el cat�logo de asociaciones con
		// convenios y c�digos liberatorios.
		Boolean result = false;
		Date date1, date2, fechaEmbarque;
		String[] tipoUsoC = { tipoUso };
		for (DatoDocTransporte doctrans : ListadoDoc) {
			fechaEmbarque = doctrans.getFecembarque();
			try {
				date1 = sdf.parse("2006-12-23");
				date2 = sdf.parse("2007-02-24");
				if (fechaEmbarque.after(date1)) {
					if (fechaLlegada.after(date2)) {
						if (SunatStringUtils.include(codigoEstadoMercancia,
								codEstMerUsado)) {
							if (SunatStringUtils
									.isEmpty(codigoTratoPreferencial)
									|| codigoTratoPreferencial
									.equalsIgnoreCase("0")) {
								result = true;
								break;
							} else {
								if (rucVigenteEnCatalogoConveniosCodigosLiberatorio(
										tipoUsoC, codigoTratoPreferencial,
										TIPO_DOC_4, numDoc, aduana)) {
									result = true;
									break;
								}
							}
						}
					}
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//R682: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarModeloDelFabricante(
			ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R675: "Accesorios: El SEIDA permite que para las categor...
	public List<ErrorDescrMinima> validarListaAccesorios(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		if (vehiculo.getListaAccesorios() == null) {
			pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima dato = new pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima();
			dato.setValtipdescri(" ");
			dato.setCodtipdescr("VE0032");
			dato.setNumsecprove(vehiculo.getCategoria().getNumsecprove());
			dato.setNumsecfact(vehiculo.getCategoria().getNumsecfact());
			dato.setNumsecitem(vehiculo.getCategoria().getNumsecitem());
			List<pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima> lista = new ArrayList<pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima>();
			lista.add(dato);
			vehiculo.setListaAccesorios(lista);
			ErrorDescrMinima error = obtenerError("31650", vehiculo
					.getListaAccesorios().get(0));
			lstErroresDescrMin.add(error);
		} else {
			List<pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima> lstAccesorios = vehiculo.getListaAccesorios();
			String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
					.substring(0, 1);
			if (lstAccesorios.isEmpty() || lstAccesorios.size() > 21) {
				ErrorDescrMinima error = obtenerError("31650", vehiculo
						.getListaAccesorios().get(0));
				lstErroresDescrMin.add(error);
			} 
			//Se quito la validacion de L, M, N, O en lo referente a si cuenta o no con aire acondicionado, lunas el�ctricas, lunas polarizadas, climatizador, GPS y aros de aleaci�n [R675].

		}
		return lstErroresDescrMin;
	}

	// R---
	public List<ErrorDescrMinima> validarNumeroHomologacionMTC(
			ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R676: "Largo del veh�culo mm: se debe transmitir en las categor�as L, M,
	// N,
	// O, siempre y cuando el indicador de
	// SNTT sea 0, el valor del largo del veh�culo, que debe ser > 0 y:
	// Si es Categor�a L <= 9999
	// Si es Categor�a O <= 14680
	// En los dem�s casos <= 23000"
	public List<ErrorDescrMinima> validarLargoMM(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getLargoMM() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getLargoMM().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01)
				|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31653",
						vehiculo.getLargoMM(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (CATEGORIA_L.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 9999)) {
					Object[] argumentos = new Object[] { 9999,
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31654",
							vehiculo.getLargoMM(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_O.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 14680)) {
					Object[] argumentos = new Object[] { 14680,
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31654",
							vehiculo.getLargoMM(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_M.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 23000)) {
					Object[] argumentos = new Object[] { 23000,
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31654",
							vehiculo.getLargoMM(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {

			String regla = "la categoria consignada es diferente a L,M,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getLargoMM().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getLargoMM(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R677: Ancho del veh�culo mm: se valida que siempre debe transmitir en las
	// categor�as L, M, N, O,
	// siempre y cuando el indicador de SNTT sea 0, el valor del ancho del
	// veh�culo, que debe ser > 0 <= 2600
	public List<ErrorDescrMinima> validarAnchoMM(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getAnchoMM() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getAnchoMM().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01)
				|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31655",
						vehiculo.getAnchoMM(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (noCumpleRango(datoAValidar, 1, 2600)) {
					ErrorDescrMinima error = obtenerError("31656",
							vehiculo.getAnchoMM());
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {

			String regla = "la categoria consignada es diferente a L,M,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getAnchoMM().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getAnchoMM(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R678: Altura del veh�culo mm: El SEIDA valida que siempre debe transmitir
	// en las categor�as L, M, N, O, siempre
	// y cuando el indicador de SNTT sea 0. El valor de la altura del veh�culo
	// debe ser > 0 y:
	// Si es Categor�a M <= 4300 Si es Categor�a N <= 4100 Si es Categor�a L<=
	// 2000
	// En los dem�s casos <= 4600
	public List<ErrorDescrMinima> validarAlturaMM(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getAltoMM() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getAltoMM().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01)
				|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31657",
						vehiculo.getAltoMM(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (CATEGORIA_L.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 2000)) {
					Object[] argumentos = new Object[] { "2000",
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31658",
							vehiculo.getAltoMM(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_M.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 4300)) {
					Object[] argumentos = new Object[] { "4300",
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31658",
							vehiculo.getAltoMM(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_N.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 4100)) {
					Object[] argumentos = new Object[] { "4100",
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31658",
							vehiculo.getAltoMM(), argumentos);
					lstErroresDescrMin.add(error);
				} else if (CATEGORIA_O.equals(val_caracter01)
						&& noCumpleRango(datoAValidar, 1, 4600)) {
					Object[] argumentos = new Object[] { "4600",
							vehiculo.getCategoria().getValtipdescri() };
					ErrorDescrMinima error = obtenerError("31658",
							vehiculo.getAltoMM(), argumentos);
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getAltoMM().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getAltoMM(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R662: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarNumeroCambiosDeCaja(
			ModelAbstract objeto) { return new ArrayList<ErrorDescrMinima>();
	}

	// R679: Variacion no se transmite casilla
	public List<ErrorDescrMinima> validarNumeroPuertas(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R679: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarRefrigeracionMotor(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R679: Idem...
	public List<ErrorDescrMinima> validarSuspencionDelantera(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getSuspencionDelantera() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getSuspencionDelantera().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);
		Boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01)
				|| CATEGORIA_O.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31662",
						vehiculo.getSuspencionDelantera(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {

			String regla = "la categoria consignada es diferente a M(excepto M1),N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getSuspencionDelantera().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getSuspencionDelantera(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R680: Tipo de suspensi�n posterior: El SEIDA valida que siempre debe
	// transmitir para las categor�as M (excepto
	// la clase M1), N, O, siempre y cuando el indicador de SNTT sea 0. El valor
	// enviado debe ser un alfanum�rico, con
	// una longitud m�xima de 22 caracteres, donde se acepten n�meros, letras,
	// guiones y apostrofe.
	public List<ErrorDescrMinima> validarSuspencionPosterior(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getSuspencionPorterior() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getSuspencionPorterior().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);
		Boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01)
				|| CATEGORIA_O.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31664",
						vehiculo.getSuspencionPorterior(), argumentos);
				lstErroresDescrMin.add(error);
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {

			String regla = "la categoria consignada es diferente a M(excepto M1),N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getSuspencionPorterior().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getSuspencionPorterior(), argumentos);
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R684: Variacion no se transmite casilla
	public List<ErrorDescrMinima> validarTipoFrenoDelantero(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R685: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarTipoFrenoPosterior(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();
	}

	// R681: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarNombreDelFabricante(
			ModelAbstract objeto) { 
		return new ArrayList<ErrorDescrMinima>();
	}

	// R686: N�mero de ruedas: El SEIDA valida que siempre debe transmitir para
	// las categor�as L, M, N y O, siempre
	// y cuando el indicador de SNTT sea 0. El valor debe ser:
	// Si es categor�a L >= 2 y <= 3
	// Si es Categor�a M >= 4
	// Si es Categor�a N >= 4
	// En los dem�s casos >= 2 y <= 30
	public List<ErrorDescrMinima> validarNumeroRuedas(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getNumeroRuedas() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getNumeroRuedas().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = ((CATEGORIA_L.equals(val_caracter01)
				|| CATEGORIA_M.equals(val_caracter01)
				|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31670",
						vehiculo.getNumeroRuedas(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (CATEGORIA_L.equals(val_caracter01)) {
					if (noCumpleRango(datoAValidar, 2, 3)) {
						Object[] argumentos = new Object[] { "2", "3",
								vehiculo.getCategoria().getValtipdescri() };
						ErrorDescrMinima error = obtenerError("31671",
								vehiculo.getNumeroRuedas(), argumentos);
						lstErroresDescrMin.add(error);
					}
				} else if (CATEGORIA_M.equals(val_caracter01)
						|| CATEGORIA_N.equals(val_caracter01)) {
					if (SunatNumberUtils.isLessThanParam(
							Integer.parseInt(datoAValidar), 4)) {
						Object[] argumentos = new Object[] { "4", "99",
								vehiculo.getCategoria().getValtipdescri() };
						ErrorDescrMinima error = obtenerError("31671",
								vehiculo.getNumeroRuedas(), argumentos);
						lstErroresDescrMin.add(error);
					}
				} else {
					if (noCumpleRango(datoAValidar, 2, 30)) {
						Object[] argumentos = new Object[] { "2", "30",
								vehiculo.getCategoria().getValtipdescri() };
						ErrorDescrMinima error = obtenerError("31671",
								vehiculo.getNumeroRuedas(), argumentos);
						lstErroresDescrMin.add(error);
					}
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a L,M,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getNumeroRuedas().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getNumeroRuedas(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R687: Medida de aros: El SEIDA valida que siempre debe transmitir para
	// las
	// categor�a M, siempre y cuando
	// el indicador de SNTT sea 0. El valor enviado debe tener la siguiente
	// estructura, los 2 primeros caracteres
	// corresponde al di�metro debiendo ser un n�mero entero mayor a cero y
	// menor
	// o igual a 99, luego el siguiente
	// car�cter debe ser el separador �/� y por �ltimo los dos siguientes
	// caracteres corresponde al ancho debiendo ser
	// un n�mero entero mayor a cero y menor o igual a 99. El valor m�ximo
	// aceptado es 99/99. "
	public List<ErrorDescrMinima> validarMedidaAros(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getMedidaAros() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getMedidaAros().getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = (CATEGORIA_M.equals(val_caracter01) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio && SunatStringUtils.isEmpty(datoAValidar)) {
			ErrorDescrMinima error = obtenerError("31672",
					vehiculo.getMedidaAros());
			lstErroresDescrMin.add(error);
		}
		int posSlash = datoAValidar.indexOf("/");
		if (posSlash != -1) {
			String diametro = datoAValidar.substring(0, posSlash);
			String ancho = datoAValidar.substring(posSlash + 1);
			if (noCumpleRango(diametro, 1, 99)) {
				ErrorDescrMinima error = obtenerError("31823",
						vehiculo.getMedidaAros());
				lstErroresDescrMin.add(error);
			}
			if (noCumpleRango(ancho, 1, 99)) {
				ErrorDescrMinima error = obtenerError("31824",
						vehiculo.getMedidaAros());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}

	// R688: Medida de neum�ticos: El SEIDA valida que siempre debe se
	// transmitir para la categor�a M, siempre y cuando
	// el indicador de SNTT sea 0. Se verifica que los datos de ancho secci�n y
	// serie+construcci�n radial+di�metro del
	// neum�tico se encuentren separados por el car�cter �/�, se deben enviar 2
	// medidas para neum�ticos consecutivas.
	// Para cada una de ellas se valida que el dato ancho secci�n sea una valor
	// alfanum�rico de 2 a 5 caracteres.
	// Luego del car�cter �/� se obtienen los valores de serie o perfil (dos
	// caracteres siguientes), construcci�n radial
	// (un car�cter siguiente) y el di�metro en pulgadas (�ltimos dos caracteres
	// siguientes).
	// Se valida que la serie o perfil sea un n�mero entero v�lido no mayor de
	// dos
	// d�gitos, se valida que la construcci�n
	// radial tengo uno de los siguientes valores: 'R', 'X', '-', ' ' y se
	// valida que el di�metro sea un n�mero entero v�lido
	// no mayor de dos d�gitos
	public List<ErrorDescrMinima> validarMedidaNeumaticos1(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getMedidaNeumaticos1() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getMedidaNeumaticos1().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri()
			.trim();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = (CATEGORIA_M.equals(val_caracter01) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;
		if (esObligatorio && SunatStringUtils.isEmpty(datoAValidar)) {
			ErrorDescrMinima error = obtenerError("31675",
					vehiculo.getMedidaNeumaticos1());
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	// R688: Idem
	public List<ErrorDescrMinima> validarMedidaNeumaticos2(ModelAbstract objeto) {
		return new ArrayList<ErrorDescrMinima>();// Segun modificacion del F2 ya
		// no es obligatorio
	}

	// R689: Distancia entre ejes mm: El SEIDA valida que siempre se transmita
	// un valor para las categor�as M, N, O,
	// siempre y cuando el indicador de SNTT sea 0. El valor enviado debe ser un
	// n�mero mayor a 100 y menor o igual a 99999.
	// El valor debe ser mayor a 100
	public List<ErrorDescrMinima> validarDistanciaEntreEjes(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getDistanciaEntreEjes() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getDistanciaEntreEjes().getValtipdescri()
			.trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();
		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		Boolean esObligatorio = ((CATEGORIA_M.equals(val_caracter01)
				|| CATEGORIA_N.equals(val_caracter01) || CATEGORIA_O
				.equals(val_caracter01)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31676",
						vehiculo.getDistanciaEntreEjes(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (noCumpleRango(datoAValidar, 101, 99999)) {
					ErrorDescrMinima error = obtenerError("31677",
							vehiculo.getDistanciaEntreEjes());
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getDistanciaEntreEjes().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getDistanciaEntreEjes(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R690: Marca de carrocer�a: El SEIDA valida que siempre se debe transmitir
	// para las categor�as L, M
	// (excepto para la clase M1), N, O, siempre y cuando el indicador de SNTT
	// sea
	// 0. El valor enviado debe
	// ser un alfanum�rico, con una longitud m�xima de 18 caracteres. Se aceptan
	// letras, n�meros, ap�strofe y gui�n.
	public List<ErrorDescrMinima> validarMarcaCarroceria(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

		return lstErroresDescrMin;
	}

	// R691: N�mero de serie de carrocer�a: El SEIDA valida que siempre se debe
	// transmitir para las categor�as L, M
	// (excepto para la clase M1), N, O, siempre y cuando el indicador de SNTT
	// sea 0. Se aceptan letras, n�meros y
	// guiones. La longitud m�xima del dato es de 18 caracteres.
	public List<ErrorDescrMinima> validarNumeroCarroceria(ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

		return lstErroresDescrMin;
	}

	// R692: Peso m�ximo por eje delantero: El SEIDA valida que siempre se debe
	// transmitir para las categor�as M
	// (excepto para la clase M1), N, O, siempre y cuando el indicador de SNTT
	// sea 0. El valor deber ser menor o igual a 15000.
	public List<ErrorDescrMinima> validarPesoMaximoEjeDelantero(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoMaximoEjeDelantero() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoMaximoEjeDelantero()
			.getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);
		Boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01)
				|| CATEGORIA_O.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31681",
						vehiculo.getPesoMaximoEjeDelantero(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (noCumpleRango(datoAValidar, 1, 15000)) {
					ErrorDescrMinima error = obtenerError("31682",
							vehiculo.getPesoMaximoEjeDelantero());
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M(exepto M1,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getPesoMaximoEjeDelantero().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getPesoMaximoEjeDelantero(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R693: Peso m�ximo por eje posterior 1 en kg: El SEIDA valida que siempre
	// debe transmitir para las categor�as M
	// (excepto para la clase M1), N, O, siempre y cuando el indicador de SNTT
	// sea
	// 0. El valor deber ser menor o igual a 23000.
	public List<ErrorDescrMinima> validarPesoMaximoEjePosterior1(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoMaximoEjePosterior1() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoMaximoEjePosterior1()
			.getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();

		String val_caracter01 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String val_caracter02 = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 2);
		Boolean esObligatorio = ((CATEGORIA_N.equals(val_caracter01)
				|| CATEGORIA_O.equals(val_caracter01)
				|| CAT_VEH_M2.equals(val_caracter02) || CAT_VEH_M3
				.equals(val_caracter02)) && INDICADOR_SNTT_0
				.equals(indicadorSNTT)) ? true : false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmpty(datoAValidar)) {
				Object[] argumentos = new Object[] { vehiculo.getCategoria()
						.getValtipdescri() };
				ErrorDescrMinima error = obtenerError("31683",
						vehiculo.getPesoMaximoEjePosterior1(), argumentos);
				lstErroresDescrMin.add(error);
			} else {
				if (noCumpleRango(datoAValidar, 1, 23000)) {
					ErrorDescrMinima error = obtenerError("31684",
							vehiculo.getPesoMaximoEjePosterior1());
					lstErroresDescrMin.add(error);
				}
			}
		} else if (!SunatStringUtils.isEmpty(datoAValidar)) {
			String regla = "la categoria consignada es diferente a M(exepto M1,N,O o SNTT=1";
			String campo = obtenerDescripcionDelCalogo("500", vehiculo
					.getPesoMaximoEjePosterior1().getCodtipdescr());
			Object[] argumentos = new Object[] { regla, campo };
			ErrorDescrMinima error = obtenerError("30897",
					vehiculo.getPesoMaximoEjePosterior1(), argumentos);
			lstErroresDescrMin.add(error);
		}

		return lstErroresDescrMin;
	}

	// R694: Peso m�ximo por eje posterior 2 en kg: Valida que siempre debe
	// transmitir para las categor�as M (excepto
	// para la clase M1), N, O, siempre y cuando el indicador de SNTT sea 0. El
	// valor deber ser menor o igual a 25000.
	public List<ErrorDescrMinima> validarPesoMaximoEjePosterior2(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoMaximoEjePosterior2() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoMaximoEjePosterior2()
			.getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();

		if (!(SunatStringUtils.isEmpty(datoAValidar))) {
			if (noCumpleRango(datoAValidar, 1, 25000)) {
				ErrorDescrMinima error = obtenerError("31686",
						vehiculo.getPesoMaximoEjePosterior2());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}

	// R695 Peso m�ximo por eje posterior 3 en kg: Valida que siempre debe
	// transmitir para las categor�as M (excepto
	// para la clase M1), N, O, siempre y cuando el indicador de SNTT sea 0. El
	// valor deber ser menor o igual a 22000.
	public List<ErrorDescrMinima> validarPesoMaximoEjePosterior3(
			ModelAbstract objeto) {
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String datoAValidar, indicadorSNTT;
		if (vehiculo.getPesoMaximoEjePosterior3() == null)
			datoAValidar = "";
		else
			datoAValidar = vehiculo.getPesoMaximoEjePosterior3()
			.getValtipdescri().trim();
		if (vehiculo.getIndicadorSNTT() == null)
			indicadorSNTT = "";
		else
			indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();

		if (!(SunatStringUtils.isEmpty(datoAValidar))) {
			if (noCumpleRango(datoAValidar, 1, 22000)) {
				ErrorDescrMinima error = obtenerError("31688",
						vehiculo.getPesoMaximoEjePosterior3());
				lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}

	// R696: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarRevisa1(ModelAbstract objeto,
			Declaracion dua) { 
		return new ArrayList<ErrorDescrMinima>();    
	}

	// R697: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarFobPaisExportacion(
			ModelAbstract objeto, Declaracion dua) { 
		return new ArrayList<ErrorDescrMinima>();   
	}

	// R698: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarGastosReparacion(ModelAbstract objeto,
			Declaracion dua) {
		return new ArrayList<ErrorDescrMinima>();   
	}

	// R699: variacion no se transmite casilla
	public List<ErrorDescrMinima> validarExtension(ModelAbstract objeto,
			Declaracion dua) {
		return new ArrayList<ErrorDescrMinima>();   
	}

	public List<ErrorDescrMinima> validarCorrelacion(ModelAbstract objeto) {
		CatModVehiDAO catModVehiDAO = fabricaDeServicios.getService("catModVehiDAO");
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		Vehiculo vehiculo = (Vehiculo) objeto;
		String categoria = vehiculo.getCategoria().getValtipdescri()
				.substring(0, 1);
		String subCategoria = vehiculo.getCategoria().getValtipdescri()
				.substring(1, 2);
		String marca = vehiculo.getMarcaComercial().getValtipdescri();
		String modelo = vehiculo.getModelo().getValtipdescri();
		String carroceria = vehiculo.getCarroceria().getValtipdescri();
		Map<String, Object> params = new HashMap<String, Object>();
		// Fecha actual en formato YYYYMMDD
		Date fechaActual = new Date();
		params.put("fechaVigencia",
				SunatDateUtils.getIntegerFromDate(fechaActual));
		params.put("codi_categ", categoria);
		params.put("csub_categ", subCategoria);
		params.put("cmar_vehi", marca);
		Integer x = catModVehiDAO.count(params);
		if (x != null && x > 0) {
			params.put("cmode_vehi", modelo);
			x = catModVehiDAO.count(params);
			if (x != null && x > 0) {
				params.put("ccarr_vehi", carroceria);
				x = catModVehiDAO.count(params);
				if (!(x != null && x > 0)) {
					ErrorDescrMinima error = obtenerError("31701",
							vehiculo.getCarroceria());
					lstErroresDescrMin.add(error);
				}
			} else {
				ErrorDescrMinima error = obtenerError("31700",
						vehiculo.getModelo());
				lstErroresDescrMin.add(error);
			}
		} else {
			ErrorDescrMinima error = obtenerError("31699",
					vehiculo.getMarcaComercial());
			lstErroresDescrMin.add(error);
		}
		return lstErroresDescrMin;
	}

	//se trajo del validadorAbstract
	public List<ErrorDescrMinima> validarMandatoriedadSNTT1(ModelAbstract objeto)
	{
		List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();

		Vehiculo vehiculo = (Vehiculo) objeto;
		String IndicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri().trim();
		if(INDICADOR_SNTT_1.equalsIgnoreCase(IndicadorSNTT)){ //Caso especial SNTT "1" R641

			int codigosAutoExclSNTT1 = 0;
			boolean esChasisMotorizado = false;
			for(String codigoSNTT1QueDebeEnviar: lstCodigosValidosdIndicadorSNTT1){

				boolean seEncontroCodigoObligatorio = false;
				String numSecProveedor = "";
				String numSecFactura = "";
				String numSecItem = "";

				for (DatoDescrMinima dato : objeto.getLstDatos()){
					String codigoSNTT1QueHaEnviado =dato.getCodtipdescr();

					numSecProveedor = dato.getNumsecprove().toString();
					numSecFactura = dato.getNumsecfact().toString();
					numSecItem = dato.getNumsecitem().toString();

					if(codigoSNTT1QueHaEnviado.equals(CAMPO_CARROCERIA)){
						esChasisMotorizado = dato.getValtipdescri().trim().equals(CHASIS_MOTORIZADO)?true:false;
					}

					if(codigoSNTT1QueDebeEnviar.equals(codigoSNTT1QueHaEnviado)){
						seEncontroCodigoObligatorio = true;
						break;
					}

					if(SunatStringUtils.isStringInList(codigoSNTT1QueHaEnviado,lstCodigosAutoExcluyentesSNTT1)){
						codigosAutoExclSNTT1=codigosAutoExclSNTT1+1;
					}

					/*Inicio ajustes PAS20155E220000407
					 *En relaci�n a las descripciones m�nimas de veh�culos, se requiere adecuar las validaciones a efectos que cuando se consigne 
					 *como carrocer�a tipo Chasis Motorizado (c�digo CHM), sea que haya declarado como indicador SNTT el c�digo 0 o 1., no se exija
					 * la transmisi�n de los siguientes datos:N�mero de puertas, N�mero de asientos,N�mero de pasajeros,Marca de carrocer�a,
					 * N�mero de carrocer�a,	Color principal*/
					if(esChasisMotorizado && SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstExoneradosChasisMotorizadoSNTT1)){
						seEncontroCodigoObligatorio = true;
						break;
					}
					/*Fin ajustes PAS20155E220000407*/       
					if(SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstExoneradosProvisionalSNTT1)){
						seEncontroCodigoObligatorio = true;
						break;
					}
				}






				if(!seEncontroCodigoObligatorio){ 
					StringBuilder campo = new StringBuilder(codigoSNTT1QueDebeEnviar);
					campo.append("-");
					campo.append(obtenerDescripcionDelCalogo("500", codigoSNTT1QueDebeEnviar));

					CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					Object[] parametros = new Object[]{numSecProveedor,numSecFactura, numSecItem,campo,""};
					ErrorDescrMinima error = new ErrorDescrMinima("", "35600", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "35600").getDesDatacat(), 
							ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,parametros); 

					if(!SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstCodigosAutoExcluyentesSNTT1)){

						/**ajustes de consideracion de exigibilidad por categorias de vehiculo PAS20165E220200137**/
						String val_caracter01 = vehiculo.getCategoria().getValtipdescri().substring(0, 1);
						//String val_caracter02 = vehiculo.getCategoria().getValtipdescri().substring(0, 2); no se utiliza PAS201930001100006
						if(SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, new String []{"VE0008","VE0014"})){
							if((codigoSNTT1QueDebeEnviar.equals("VE0008") && SunatStringUtils.isStringInList(val_caracter01, new String[] {CATEGORIA_L, CATEGORIA_M, CATEGORIA_N, CATEGORIA_O}))
									|| (codigoSNTT1QueDebeEnviar.equals("VE0014") && SunatStringUtils.isStringInList(val_caracter01, new String[] {CATEGORIA_L, CATEGORIA_M, CATEGORIA_N}))){
								lstErrores.add(error);
								objeto.agregarErrror(error);
							}
							/**ajustes de PAS20165E220200137**/
						}else{
							lstErrores.add(error);
							objeto.agregarErrror(error);
						}
					}else if(SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstCodigosAutoExcluyentesSNTT1) && codigosAutoExclSNTT1<1){ 
						lstErrores.add(error);
						objeto.agregarErrror(error);
					}  
				}
			}
		}
		return lstErrores;
	}

	/************************** INYECCION POR SPRING ****************************/
	/*
    public void setCatModVehiDAO(CatModVehiDAO catModVehiDAO) {
        this.catModVehiDAO = catModVehiDAO;
    }

    public void setCatRevisa1DAO(CatRevisa1DAO catRevisa1DAO) {
        this.catRevisa1DAO = catRevisa1DAO;
    }


    public void setValTratamientoDonacionService(
            ValTratamientoDonacionService valTratamientoDonacionService) {
        this.valTratamientoDonacionService = valTratamientoDonacionService;
    }
	 */
}
