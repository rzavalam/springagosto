package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;//P46-PAS20155E410000032

//import org.apache.commons.lang.ArrayUtils;//P46-PAS20155E410000032
import org.apache.commons.lang.StringUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.CodiLibe;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValCabdav;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.CodigoLiberatorioService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PreferenciaArancelariaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;//P46-PAS20155E410000032
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.StringUtil;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;//P46-PAS20155E410000032
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

public class ValTratamientoDonacionServiceImpl  extends ValDuaAbstract implements ValTratamientoDonacionService{
	/** inicio mpoblete F2_3013 P46 **/
	//protected final Log log = LogFactory.getLog(getClass());
	/** fin mpoblete F2_3013 P46 **/
	
	//private FabricaDeServicios fabricaDeServicios;
	
	private Integer codLiberatorioPrevio = 0;
	private Integer nroSeriePrevio = 0;
	private boolean todasSeriescodLib2001_2002= true;
	//P46-PAS20155E410000032 inicio
	private boolean algunaSeriescodLib2001_2002= false; 
	private String codRegularizacionPrevio="";
	private Integer nroSerieRegulPrevio = 0;
	private boolean presentaAlgunCodLibNoEsDonacion=false;
	//P46-PAS20155E410000032 fin
	//P46 EJHM  INICIO
	
	public List<Map<String, String>> validarDeclaracionTipoDonacionDiligencia(Declaracion declaracion ,Declaracion declaracionBD) {
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean tieneTratamientoDonacion = validarTieneTratamientoDonacion(declaracion);
		boolean tieneAyudaHumanitaria = validarEsAyudaHumanitaria(declaracion.getDua().getListSeries());
		boolean flagDiligencia=true;
	
		boolean tieneIndicadorImpugnacion= CollectionUtils.isEmpty(validarTipoIndicador ( declaracion,false))?true:false;
		
		List<Map<String, String>> rRegDec = validarRegimenDeclaracion(declaracion);
		if(CollectionUtils.isEmpty(rRegDec)) { //Regimen 10
			if (tieneTratamientoDonacion && !tieneAyudaHumanitaria){  //PAS20145E220000365 mtorralba 20150323 - Atencion BUG 21231sdf
				String codAutoriza=validarTieneDocumentoAutorizante(declaracion,tieneIndicadorImpugnacion,true);
				List<Map<String, String>>  resultSinDonacion=validarTipodeDocumentoAsociadoDoconacion(declaracion,tieneTratamientoDonacion,true);
				//ini P46-PAS20155E410000032
				if(CollectionUtils.isEmpty(resultSinDonacion) && !codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_RESOL_NI_EXPEDIENTE)) {
					if (declaracion.isRegistrarCodLibeDonacion() || codAutoriza.equals(ConstantesDataCatalogo.FLUJO_CON_DOC_AUTORIZANTE)){ // documento Resolucion
						result.addAll(validarDeclaracionDonacionConDocumentoAutorizanteDiligencia(declaracion));
					} else if (codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_AUTORIZANTE)){ // documento expediente
						result.addAll(validarDeclaracionDonacionSinDocumentoAutorizanteDiligencia(declaracion,flagDiligencia));
					}
				} else if (codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_RESOL_NI_EXPEDIENTE)){
					// evalua sin documento Resolucion Ni expediente
					result.addAll(validarDeclaracionSinDocumentoResolNiExp( declaracion, tieneIndicadorImpugnacion, resultSinDonacion,flagDiligencia));	
				}
				result.addAll(validacionesRectiOficio(declaracion, declaracionBD));
				//fin P46-PAS20155E410000032
			}
		} else if(tieneTratamientoDonacion){
			result.addAll(rRegDec);
		}
		
		if(!tieneTratamientoDonacion){
			//ini P46-PAS20155E410000032
			if(!validarTieneTratamientoDonacion(declaracion) && validarTieneTratamientoDonacion(declaracionBD)){
				result.addAll(validarRetiroTratamientoDonacion(declaracion, declaracionBD));
			} else {
				result.addAll(validaDeclaracionSinTipoTratamientoDonacion(declaracion,flagDiligencia));
			}
			//fin P46-PAS20155E410000032
		}
		return result;
			}
		
	//ini P46-PAS20155E410000032
	/**
	 * Metodo que permite determinar si una declaracion tiene diligencia de despacho
	 * 
	 * @param declaracion
	 * @return tipo de cancelacion de la declaracion
	 */
	private boolean declaracionTieneDiligenciaDespacho(Declaracion declaracion) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("codigoAduana", declaracion.getDua().getCodaduanaorden());
	    params.put("annoPresentacion", declaracion.getDua().getAnnpresen().toString());
	    params.put("codigoRegimen", declaracion.getDua().getCodregimen());
	    params.put("numeroDeclaracion", declaracion.getNumeroDeclaracion());
	    
	    DeclaracionService declaracionService = fabricaDeServicios.getService("diligencia.ingreso.declaracionService");
	    return declaracionService.buscarDUAconDiligenciaAsociada(params).get("FECHA_PRIMERA_DILIGENCIA") != null;
	}
	
	/**
	 * Metodo que permite determinar si la declaracion tiene cancelacion 0, 74 o 75
	 * 
	 * @param declaracion
	 * @return verdadero si la declaracion tiene tipo de cancelacion 0, 74 o 75, falso en caso contrario
	 */
	public boolean declaTieneTipoCancelacion(Declaracion declaracion) {
		DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
		String tipoCancelacion = deudaDeclaracionService.obtenerTipoCancelacion(declaracion);
		
		List<String> lTipoCancelacion = new ArrayList<String>();
		lTipoCancelacion.add(String.valueOf(ConstantesDataCatalogo.TIPO_CANCELACION_PENDIENTE_PAGO_DONACION));
		lTipoCancelacion.add(String.valueOf(ConstantesDataCatalogo.TIPO_CANCELACION_74));
		lTipoCancelacion.add(String.valueOf(ConstantesDataCatalogo.TIPO_CANCELACION_75));

		return lTipoCancelacion.contains(tipoCancelacion);
	}
	
	/**
	 * Metodo que permite determinar si la declaracion tiene indicador de impugnacion de donacion
	 * @return
	 */
	private boolean declaTieneIndImpugDonacion(Declaracion declaracion) {
		return CollectionUtils.isEmpty(validarTipoIndicador(declaracion, false));
	}
	
	/**
	 * Metodo que permite determinar si al menos una de las series de la declaracion
	 * tiene codigo liberatorio de donacion
	 * 
	 * @param declaracion
	 * @return
	 */
	private boolean declaTieneCodLibeDonacion(Declaracion declaracion) {
		CodigoLiberatorioService codigoLiberatorioService = fabricaDeServicios.getService("codigoLiberatorioService");
		for(DatoSerie datoSerie : declaracion.getDua().getListSeries()) {
			if(codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio())) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Metodo que permite determinar si se trata de una declaracion de regimen 10
	 * en la rectificacion de oficio
	 * 
	 * @param declaracion
	 * @return
	 */
	private boolean esReg10EnRectiOficio(Declaracion declaracion) {
		String regimenDiligencia = ConstantesDataCatalogo.REG_IMPO_CONSUMO + ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION;
		return regimenDiligencia.equals(declaracion.getCodtipotrans());
	}
	
	private List<Map<String, String>> validacionesRectiOficio(Declaracion declaracion, Declaracion declaracionBD) {
	List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		
	if(esReg10EnRectiOficio(declaracion)){//es rectificacion de oficio
		Date fechLevante = declaracionBD.getDua().getFecAutlevante();
		if(!declaracion.isRegistrarCodLibeDonacion() //que el usuario no haya escogido regularizar la donacion cuando tiene levante
				&& !declaTieneTipoCancelacion(declaracion) //declaracion tiene tipo de cancelacion != 0, 74, 75
				&& declaTieneCodLibeDonacion(declaracion) //declaracion cuenta con codigo liberatorio de donacion
				//&& declaracionTieneDiligenciaDespacho(declaracion)) { //declaracion tiene diligencia de despacho
				&& fechLevante.compareTo(SunatDateUtils.getDefaultDate())>0) { // se cambio verficacion en cab_diligencia por la de si tiene levante
			boolean declaSesionTieneIndImpug = declaTieneIndImpugDonacion(declaracion);
			boolean declaBdTieneIndImpug = declaTieneIndImpugDonacion(declaracionBD);
			
//			permite validar en la rectificacion de oficio que no se intente
//			regularizar una donacion en caso la declaracion tenga tipo de cancelacion
//			distinto de 0, 74 y 75, y tenga diligencia de despacho
			if(!declaSesionTieneIndImpug && declaBdTieneIndImpug) { //se quito el indicador de impugnacion de donacion
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35455"));
			}
		
			result.addAll(validarSinGarantia160(declaracion));
		/*inicio P46-PAS20155E410000032-[jlunah] BUG 25005*/	
		}else if(declaracion.getDua().getCodtipotratamiento().equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
			    
			result.addAll(validarSinGarantia160(declaracion));
			
		}
		/*fin P46-PAS20155E410000032-[jlunah] BUG 25005*/
		}
		return result;
	}
	//fin P46-PAS20155E410000032
	
	private Elementos<DatoOtroDocSoporte>  obtieneDocAutorizante( Map<String,Object> declaracionActual, String serieSeleccionada){
	    
		Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=null;
		DatoOtroDocSoporte otroDocSoporte=null;
		
		 List<Map<String, Object>> lstDetAutorizacion=null;
		 List<Map<String, Object>> lstDocAutAsociadoSerie=null;
		 List<Map<String, Object>> lstDocAutAsociado=null;
		 if (declaracionActual.containsKey("lstDetAutorizacion")){ 
			lstDetAutorizacion  = (List<Map<String, Object>>) declaracionActual.get("lstDetAutorizacion"); 
		 }
		 if (declaracionActual.containsKey("lstDocAutAsociado")){
				lstDocAutAsociado = (List<Map<String, Object>>) declaracionActual.get("lstDocAutAsociado");	
		 }
		 
		 if (!CollectionUtils.isEmpty(lstDetAutorizacion) && !CollectionUtils.isEmpty(lstDocAutAsociado)) {
			for (Map<String, Object> detAutorizacionTmp : lstDetAutorizacion) {
				if (!serieSeleccionada.equals(detAutorizacionTmp.get("NUM_SECSERIE").toString().trim())) {
					continue;
				}
					for (Map<String, Object> docAutAsociadoTmp : lstDocAutAsociado) {
						if (detAutorizacionTmp.get("NUM_SECDOC").toString().trim().equals(docAutAsociadoTmp.get("NUM_SECDOC").toString().trim())
								&& detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals(docAutAsociadoTmp.get("COD_TIPOPER").toString().trim())
								&& detAutorizacionTmp.get("COD_TIPOPER").toString().trim().equals("1") 
								&& !detAutorizacionTmp.get("IND_DEL").toString().trim().equals("1")
								&& (docAutAsociadoTmp.get("COD_TIPDOCASO").toString().trim().equals("02")||docAutAsociadoTmp.get("COD_TIPDOCASO").toString().trim().equals("22"))//Se adiciono cod "22" - PAS20165E220200022
								){
							if(lstDocAutAsociadoSerie==null){
								lstDocAutAsociadoSerie=new ArrayList<Map<String, Object>>();	
							}
							lstDocAutAsociadoSerie.add(docAutAsociadoTmp);
						}
					}
			}
		}
		 
		
			if (!CollectionUtils.isEmpty(lstDocAutAsociadoSerie)) {
			   listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();
			   for(Map<String,Object> mapDocAutAsociado:lstDocAutAsociadoSerie){
					// no considerar lo eliminado
					if(mapDocAutAsociado.get("IND_DEL")!=null && mapDocAutAsociado.get("IND_DEL").toString().equals("1")){
						continue;
					}
					 otroDocSoporte = new DatoOtroDocSoporte();
					otroDocSoporte.setCodtipoproceso((java.lang.String) mapDocAutAsociado.get("COD_TIPOPER"));
					otroDocSoporte.setCodtipodocasoc((java.lang.String) mapDocAutAsociado.get("COD_TIPDOCASO"));
					otroDocSoporte.setIndicadorEliminado(
							mapDocAutAsociado.get("IND_DEL") == null || "".equals(mapDocAutAsociado.get("IND_DEL").toString().trim())? 
									0 : Integer.parseInt(mapDocAutAsociado.get("IND_DEL").toString()));
					 
					listOtrosDocSoporte.add(otroDocSoporte);
				}
			}
			return listOtrosDocSoporte;
	}
	 
	//ini P46-PAS20155E410000032
	@SuppressWarnings("unchecked")
	public String validarCodigoLiberatorioDonacion(HttpServletRequest request) {
		String mensaje="";
		String serieSeleccionada = request.getParameter("hdn_num_secserie") != null ? (String) request.getParameter("hdn_num_secserie") : "";
		ServletWebRequest webRequest = new ServletWebRequest(request);
		Map<String, Object> declaracionActual = (HashMap<String, Object>) WebUtils.getSessionAttribute(request, "mapCabDeclaraActual");
		
		String codTipRegul = webRequest.getParameter("cod_tipregul");//tipo de regularizacion de donacion
		
		//registrarCodLibeDonacion: si es true implica que la declaracion es de regimen 10, de donacion,
		//estuvo impugnada, tiene levante, tiene cancelacion 73 y el usuario quiere regularizar la donacion
		boolean registrarCodLibeDonacion = declaracionActual.get("registrarCodLibeDonacion") != null
	    		&& (Boolean)declaracionActual.get("registrarCodLibeDonacion");
		
		if (Constantes.REGIMEN_10_IMPORTACION_CONSUMO.equals((String) declaracionActual.get("COD_REGIMEN")) 
				&& Constantes.TIPO_TRATAMIENTO_MERCANCIA_DONACION.equals((String) declaracionActual.get("COD_TIPTRATMERC"))) {
			String codLiberatorio = webRequest.getParameter("cod_tipconvenio_ind_libe");
			if(!StringUtil.esVacio(codLiberatorio,true)) {
				CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
				
				if(!codigoLiberatorioService.serieTieneCodLiberatorioDonacion(Integer.parseInt(codLiberatorio))){ 
					mensaje="EL CODIGO LIBERATORIO ["+codLiberatorio+"] CONSIGNADO NO CORRESPONDE A UNA DONACION";
				} else {
					DatoSerie datoSerie =new DatoSerie(); 
					datoSerie.setNumserie(Integer.parseInt(serieSeleccionada));
					datoSerie.setCodliberatorio(Integer.parseInt(codLiberatorio));
					boolean esCodLibe2001o2002 = !CollectionUtils.isEmpty(validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie));
					
					if(registrarCodLibeDonacion) {
						if(StringUtil.esVacio(codTipRegul, true)) {
							mensaje = "REGISTRE TIPO DE REGULARIZACION DE LA PRESENTE DECLARACION DE DONACION";
						} else {
							Elementos<DatoOtroDocSoporte> lDatoOtroDocSoporte = obtieneDocAutorizante(declaracionActual, serieSeleccionada);
							
							if(ConstantesDataCatalogo.CON_PRESENTACION_DE_DOCUMENTOS_AUTORIZANTES.equals(codTipRegul)) {
								if(!esCodLibe2001o2002) {
									if (CollectionUtils.isEmpty(lDatoOtroDocSoporte)) {
										mensaje = "REGISTRE LOS DATOS DE LA RESOLUCION DE DONACION";
									}
								}
							} else if(ConstantesDataCatalogo.CON_SILENCIO_ADMINISTRATIVO_POSITIVO.equals(codTipRegul)) {
								if (!CollectionUtils.isEmpty(lDatoOtroDocSoporte)) {
									mensaje = "PARA TIPO DE REGULARIZACION CON SILENCIO ADMINISTRATIVO POSITIVO, NO CORRESPONDE REGISTRAR RESOLUCION DE DONACION";
								}
							} else {
								mensaje = "NO ES UN TIPO DE REGULARIZACION DE DONACION VALIDO";
							}
						}
					} else {
					if(!esCodLibe2001o2002){
						Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=obtieneDocAutorizante(declaracionActual,serieSeleccionada);
						if (CollectionUtils.isEmpty(listOtrosDocSoporte)) {
								//mensaje="serie "+serieSeleccionada+ " con c�digo liberatorio de donaci�n,debe registrar documento autorizante" ;
								mensaje="SERIE ("+serieSeleccionada+"): ASOCIADA CON EL CODIGO LIBERATORIO " + codLiberatorio + ", NO SE ENCUENTRA ASOCIADA A UN DOCUMENTO DE DONACION" ;//Se cambio por Sigesi P_SNADE008-3802
							}	
					}
				}
				}
			} else {
				/*inicio P46-PAS20155E410000032-[jlunah]*/
				if(registrarCodLibeDonacion && (codLiberatorio != null || codLiberatorio.equals(""))){
					mensaje = "REGISTRE CODIGO LIBERATORIO QUE REGULARIZA LA PRESENTE DECLARACION DE DONACION";
					return mensaje;
				}
				/*fin P46-PAS20155E410000032-[jlunah]*/
				if(registrarCodLibeDonacion && !StringUtil.esVacio(codTipRegul, true)) {
					mensaje = "NO PUEDE REGISTRAR EL TIPO DE REGULARIZACION SI NO CONSIGNA UN CODIGO LIBERATORIO DE DONACION";
					return mensaje;//se agrega para que no se chanquen los mensajes [jlunah]
			} 
			else {
				Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=obtieneDocAutorizante(declaracionActual,serieSeleccionada);
					if (!CollectionUtils.isEmpty(listOtrosDocSoporte)) {
						 mensaje="SERIE "+serieSeleccionada+ " CUENTA CON DOCUMENTO AUTORIZANTE DE DONACION, DEBE REGISTRAR CODIGO LIBERATORIO" ;
						 return mensaje;//se agrega para que no se chanquen los mensajes [jlunah]
					}
						}	
				}
		}
		
		return mensaje;
	}
	//fin P46-PAS20155E410000032
	
	private List<Map<String,String>> validarDeclaracionSinDocumentoResolNiExp (Declaracion declaracion,boolean tieneIndicadorImpugnacion,List<Map<String, String>>  resultSinDonacion,boolean flagDiligencia){
//		boolean conDocumentoAutorizante=false;//P46-PAS20155E410000032
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();

		//P46-PAS20155E410000032 inicio
		 boolean flagDocAutorizante=false;
		 if(flagDiligencia){
		  algunaSeriescodLib2001_2002=false; // para las diligencias
		 }
		 else{
		   todasSeriescodLib2001_2002=true; // que todos  esto para numeracion	 
		 }
		//P46-PAS20155E410000032 fin
		  
		if(!CollectionUtils.isEmpty(resultSinDonacion)){ // no presenta donacion  
			 /*inicio P46-PAS20155E410000032-[jlunah] BUG 25003*/
			 String[] ejecutarValidaciones;
		
			 if(esReg10EnRectiOficio(declaracion)){//SI ES RECTIFICACION DE OFICIO
				 /*inicio P46-PAS20155E410000032-[jlunah] BUG 25049*/
					 boolean declaracionEstaCancelada =  declaracionEstaCancelada(declaracion);
					 if(!declaracionEstaCancelada){//SI NO ESTA CANCELADA
						 ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
								 ConstantesDataCatalogo.VALIDA_QUE_PRESENTE_CODLIB_2001_2002,
								    ConstantesDataCatalogo.VALIDA_SI_TIENE_CODLIB_DONACION,
									ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES,
									ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB};
					 }else{//SI ESTA CANCELADA
						 ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
								 ConstantesDataCatalogo.VALIDA_QUE_PRESENTE_CODLIB_2001_2002,
					    ConstantesDataCatalogo.VALIDA_SI_TIENE_CODLIB_DONACION,
						ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES};
					}
				  /*fin P46-PAS20155E410000032-[jlunah] BUG 25049*/
				 
			 }else{
				 ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_QUE_PRESENTE_CODLIB_2001_2002,
						    ConstantesDataCatalogo.VALIDA_SI_TIENE_CODLIB_DONACION,
							ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES};
			 }
			 /*fin P46-PAS20155E410000032-[jlunah] BUG 25003*/
			 
			 List<Map<String,String>>  resValCodigoLib=validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidaciones,flagDocAutorizante,flagDiligencia);
			 
			 if(!CollectionUtils.isEmpty(resValCodigoLib)){
				 result.addAll(resValCodigoLib);
			 }
			 else
			 if( tieneIndicadorImpugnacion  && todasSeriescodLib2001_2002){
				 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35466")); 
			 }
			 else if(tieneIndicadorImpugnacion  && !todasSeriescodLib2001_2002){
				 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35438"));		 
				}
			 //P46-PAS20155E410000032 inicio  se modifica flujo
			 else if(!tieneIndicadorImpugnacion  && !todasSeriescodLib2001_2002 && !flagDiligencia){ //  numeracion
				 result.addAll(resultSinDonacion);		 
			}
			 else if(!tieneIndicadorImpugnacion  && !algunaSeriescodLib2001_2002 && flagDiligencia){ //  diligencia despacho, diligencia RectiOficio
			
				 /*inicio P46-PAS20155E410000032-[jlunah]*/
				 List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
				 boolean tieneSilencioAdministrativoPositivo = false;
				 for (DatoSerie datoSerie : lstSeries) {
				 	 tieneSilencioAdministrativoPositivo = ConstantesDataCatalogo.CON_SILENCIO_ADMINISTRATIVO_POSITIVO.equals(datoSerie.getCodTipRegul())
				 						&& declaracion.isRegistrarCodLibeDonacion();
				 	if(tieneSilencioAdministrativoPositivo){
				 		break;
				 	}
				 }
				 
				 if(!tieneSilencioAdministrativoPositivo)result.addAll(resultSinDonacion);
				 
				 /*fin P46-PAS20155E410000032-[jlunah]*/
			}
			//P46-PAS20155E410000032 fin 
		 }
		 else
		 {
			 // dua con donacion pero sin documento resolucion ni documento autorizante
			 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35454"));
		 }
		
		
		
		return result;
	}
	
	private List<Map<String,String>> validarRetiroTratamientoDonacion(Declaracion declaracion,Declaracion declaracionBD){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		if( CollectionUtils.isEmpty(validarRegimenDeclaracion(declaracion))){ 
			
				String[] ejecutarValidacion = new String[] {ConstantesDataCatalogo.VALIDA_NO_TIENE_CODLIB_DONACION};
				
				boolean flagDiligencia=true;
				boolean flagDocAutorizante=false;
				boolean esDilDespaAgregarDocAut=false;
				boolean flagTratamientoDonacion=false;
				result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,flagTratamientoDonacion,flagDiligencia));
				result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidacion,esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion,flagDiligencia));
//				if( !CollectionUtils.isEmpty(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidacion,esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion))){
//					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35467"));	
//				}
			
		}
	 return result;	
	}
	
	private List<Map<String,String>> validarDeclaracionDonacionConDocumentoAutorizanteDiligencia (Declaracion declaracion){
	  
		/*inicio P46-PAS20155E410000032-[jlunah] BUG 25003*/
		String[] ejecutarValidacion4;
		String[] ejecutarValidaciones;
		
		if(esReg10EnRectiOficio(declaracion)){//SI ES RECTIFICACION DE OFICIO
				/*P46-PAS20155E410000032-[jlunah] BUG 25049 inicio*/
				boolean declaracionEstaCancelada =  declaracionEstaCancelada(declaracion);
				if (!declaracionEstaCancelada){//SI NO SE ENCUENTRA CANCELADA
					
					ejecutarValidacion4 = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002,
							ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB};

					ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							 ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002,
							 ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB,
				ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_RESOLUCION,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
							 ConstantesDataCatalogo.VALIDA_SERIE_PRESE_DOC_DONA_Y_SOPORTE_TODAS_CUENT_CODLIB_DON,
							 ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES,
							 ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOC_REGULARIZACION_DIFERENTES};
				}else{//SI SE ENCUENTRA CANCELADA
					ejecutarValidacion4 = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002};

					ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							 ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002,
							 ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_RESOLUCION,
							 ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
							 ConstantesDataCatalogo.VALIDA_SERIE_PRESE_DOC_DONA_Y_SOPORTE_TODAS_CUENT_CODLIB_DON,
							 ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES,
							 ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOC_REGULARIZACION_DIFERENTES};

				}
				/*P46-PAS20155E410000032-[jlunah] BUG 25049 fin*/
				
		}else{
					ejecutarValidacion4 = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002};
					
					ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002,
				ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_RESOLUCION,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
												         ConstantesDataCatalogo.VALIDA_SERIE_PRESE_DOC_DONA_Y_SOPORTE_TODAS_CUENT_CODLIB_DON,
												         ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES,  /* P46-PAS20155E410000032*/
												         ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOC_REGULARIZACION_DIFERENTES}; /* P46-PAS20155E410000032*/
		}
		/*fin P46-PAS20155E410000032-[jlunah] BUG 25003*/
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean flagDocAutorizante=true;
		boolean flagDiligencia=true;
		boolean flagTratamientoDoncion=true;
		// si tiene c�digo liberatorio del anexo
		
		boolean tieneCodigoLiberatorio=!CollectionUtils.isEmpty(((CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService")).duaTieneCodigoLiberatorio(declaracion.getDua()))?true:false;
		if(tieneCodigoLiberatorio){
			//12.	Que no tenga consignado el indicador de impugnaci�n 
			if(!CollectionUtils.isEmpty(validarTipoIndicador(declaracion, true))) {
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35440"));	
			}
			   //Que el Tipo de Proceso del Documento Asociado tenga el c�digo �1� 
			  	result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,flagTratamientoDoncion,flagDiligencia));
			  //Que no se registre el Documento de Autorizaci�n de la donaci�n cuando tenga c�digos liberatorios 2001, 2002 y Si el Tipo de Documento Asociado tiene el c�digo �02�, se debe haber transmitido los siguientes datos, 
				result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidaciones,flagDocAutorizante,flagDiligencia));//6
			   //que este asociado a un documento de soporte y documento de donacion y cuando el c�digo liberatorio consignado no corresponda a los definidos en el ANEXO 01
			   //  Para estandarizar se cambia  !flagDiligencia  por esTransmision
			   // result.addAll(validarSerieDocumentodeSoporte(declaracion,flagDiligencia));
			  //Que el c�digo liberatorio debe encontrarse vigente a la fecha de numeraci�n y que (Ya existe) Que la fecha de emisi�n de la resoluci�n asociada no sea posterior a la fecha actual.
				result.addAll(validarFechaEmisionDocuAsociadoResolucion(declaracion));
		}
		else
		{   /* inicio P46-PAS20155E410000032-[jlunah]*/
			if(esReg10EnRectiOficio(declaracion)){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35624"));
			}else{
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35443"));
			}
			result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidacion4,flagDocAutorizante,flagDiligencia));
			/* fin P46-PAS20155E410000032-[jlunah]*/
		}
		return result;
	}
	private List<Map<String,String>> validarDeclaracionDonacionSinDocumentoAutorizanteDiligencia (Declaracion declaracion, boolean flagDiligencia){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		/*P46-PAS20155E410000032-[jlunah] BUG 25049 inicio*/
		String[] ejecutarValidacion;
		
		if(esReg10EnRectiOficio(declaracion)){//SI ES RECTIFICACION DE OFICIO
		
				boolean declaracionEstaCancelada =  declaracionEstaCancelada(declaracion);
				if (!declaracionEstaCancelada){//SI NO SE ENCUENTRA CANCELADA
					
					ejecutarValidacion = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB,
							ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
							ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_EXPEDIENTE_TRAMITADO,
							ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_EXPEDIENTE};
					
				}else{//SI SE ENCUENTRA CANCELADA
					
					ejecutarValidacion = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
							ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
							ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_EXPEDIENTE_TRAMITADO,
							ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_EXPEDIENTE};
				}
		  
		}else{
			ejecutarValidacion = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
				ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_EXPEDIENTE_TRAMITADO,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_EXPEDIENTE};
		}
		/*P46-PAS20155E410000032-[jlunah] BUG 25049 fin*/
		
		boolean flagDocAutorizante=false;
		

		//2.	valida que la declaraci�n no se consigne Trato Preferencial Internacional (TPI) ni Trato Preferencial Nacional (TPN). 
		result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidacion,flagDocAutorizante,flagDiligencia));
		//4.	Que se haya registrado un Tipo de Indicador de Donaci�n (06 o 07)
		List<Map<String, String>>  resultIndicador = validarTipoIndicador(declaracion, flagDocAutorizante);
		if(!CollectionUtils.isEmpty(resultIndicador)) {
			result.addAll(resultIndicador);
		}
		else{
			// Que no cuente con la garant�a del art�culo 160. 
			result.addAll(validarSinGarantia160(declaracion));
			boolean tieneCodigoLiberatorio=!CollectionUtils.isEmpty(((CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService")).duaTieneCodigoLiberatorio(declaracion.getDua()))?true:false;
			if(tieneCodigoLiberatorio){
				//DECLARACI�N CON IMPUGNACI�N DE TRIBUTOS POR DONACI�N NO CORRESPONDE CONSIGNAR C�DIGO LIBERATORIO
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35452"));		
			}
			//Que el Tipo de Proceso del Documento Asociado tenga el c�digo �1� (documento de donaci�n)
			result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,true,flagDiligencia)); 
			//7.	Que se haya consignado los datos relacionados al Expediente tramitado ante el sector (Tipo de Documento Asociado igual a �12�).
			result.addAll(validarTransmisionExpediente(declaracion));
		}
		
		return result;
	}
	
	public List<Map<String,String>> validarTipodeDocumentoAsociadoDoconacion(Declaracion declaracion, 
    		boolean flagTratamientoDoncion, boolean flagDiligencia) {
		return validarTipodeDocumentoAsociadoDoconacion(declaracion, flagTratamientoDoncion, flagDiligencia, false);
	}
	
    public List<Map<String,String>> validarTipodeDocumentoAsociadoDoconacion(Declaracion declaracion, 
    		boolean flagTratamientoDoncion, boolean flagDiligencia, boolean esDilDespaAgregarDocAut) {
 		
 		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		boolean  tieneDocumentoDonacion=false;
		
		
		  DatoOtroDocSoporte datoOtroDocSoporte=  getDocSoporteByTypoProceso(dua,ConstantesDataCatalogo.COD_DOCUMENTO_DONACION, flagDiligencia);
			if (datoOtroDocSoporte!=null){
				tieneDocumentoDonacion=true;
			}
			if (!tieneDocumentoDonacion && flagTratamientoDoncion){
				if(esDilDespaAgregarDocAut) {
					DatoOtroDocSoporte datoOtroDocSoporteTmp = getDatoOtroDocSoporte(dua);
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
							.getError("35460", new String[] { datoOtroDocSoporteTmp.getNumdocasoc() }));
				} else {
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35450"));					
				}
			} else
			if (tieneDocumentoDonacion && !flagTratamientoDoncion){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35433"));
			}
		
 		return result;
 	}
	
    public List<Map<String, String>> validarDeclaracionTipoDonacion(Declaracion declaracion) {
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean tieneTratamientoDonacion = validarTieneTratamientoDonacion(declaracion);
		boolean tieneAyudaHumanitaria = validarEsAyudaHumanitaria(declaracion.getDua().getListSeries());
		boolean tieneIndicadorImpugnacion= CollectionUtils.isEmpty(validarTipoIndicador ( declaracion,false))?true:false;
		boolean flagDiligencia=false;
		List<Map<String, String>> rRegDec = validarRegimenDeclaracion(declaracion);
		
		if(CollectionUtils.isEmpty(rRegDec)) { //Regimen 10
			if (tieneTratamientoDonacion && !tieneAyudaHumanitaria){  //PAS20145E220000365 mtorralba 20150323 - Atencion BUG 21231
				List<Map<String, String>>  resultSinDonacion=validarTipodeDocumentoAsociadoDoconacion(declaracion,tieneTratamientoDonacion,false);
				String codAutoriza=validarTieneDocumentoAutorizante(declaracion,tieneIndicadorImpugnacion,false);
				if(CollectionUtils.isEmpty(resultSinDonacion) && !codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_RESOL_NI_EXPEDIENTE)) {
					if (codAutoriza.equals(ConstantesDataCatalogo.FLUJO_CON_DOC_AUTORIZANTE)){
						result.addAll(validarDeclaracionDonacionConDocumentoAutorizante(declaracion));
					} else if (codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_AUTORIZANTE)){
						result.addAll(validarDeclaracionDonacionSinDocumentoAutorizante(declaracion));
					}
				} else if (codAutoriza.equals(ConstantesDataCatalogo.FLUJO_SIN_DOC_RESOL_NI_EXPEDIENTE)){
					// evalua sin documento resolucion ni expediente
					result.addAll(validarDeclaracionSinDocumentoResolNiExp( declaracion, tieneIndicadorImpugnacion, resultSinDonacion,flagDiligencia));	
				}
			}
		} else if(tieneTratamientoDonacion){
			result.addAll(rRegDec);
		}
		
		if(!tieneTratamientoDonacion){
			result.addAll(validaDeclaracionSinTipoTratamientoDonacion(declaracion,flagDiligencia));
		}
		
		return result;
	}
	//FIN EJHM
	
//P46 3003 JMCV INICIO
	public List<Map<String,String>> validarDeclaracionDonacionConDocumentoAutorizante (Declaracion declaracion){
	    String[] ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002,
	    		ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB,
			    ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_RESOLUCION,
			    ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE, 
			    ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES,
			    ConstantesDataCatalogo.VALIDA_SERIE_PRESE_DOC_DONA_Y_SOPORTE_TODAS_CUENT_CODLIB_DON};

		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean flagDocAutorizante=true;
		boolean flagTratamientoDoncion=true; 
		boolean flagDiligencia=false;
		
		result.addAll(validarRegimenDeclaracion(declaracion));
		result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,flagTratamientoDoncion,flagDiligencia));
		//result.addAll(validarTipodeDocumentoAsociadoResolucion(declaracion, true));
		//  Para estandarizar se cambia  !flagDiligencia  por esTransmision
		//result.addAll(validarSerieDocumentodeSoporte(declaracion, flagDiligencia));
		result.addAll(validarTipoIndicador(declaracion, true));
		result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidaciones,flagDocAutorizante,flagDiligencia));
		result.addAll(validarFechaEmisionDocuAsociadoResolucion(declaracion));
		result.addAll(validarEnvioFormatoB(declaracion));
		return result;
	}
		
	 	
	 	//2.1.2	Que el Tipo de Documento Asociado tenga el c�digo �02� (resoluci�n).
	 	//Caso contrario se ejecuta la excepci�n Nro.2.
	 	//Mensaje:35419-PARA TIPO DE TRATAMIENTO 4 DEBE CONSIGNAR C�DIGO 02 � RESOLUCI�N COMO TIPO DE DOCUMENTO ASOCIADO
		public List<Map<String,String>> validarTipodeDocumentoAsociadoResolucion(Declaracion declaracion , boolean flagTieneDocumento){
			return validarTipodeDocumentoAsociadoResolucion(declaracion, flagTieneDocumento, false);
		}
		
	 	public List<Map<String,String>> validarTipodeDocumentoAsociadoResolucion(Declaracion declaracion , boolean flagTieneDocumento, boolean esDilDespaAgregarDocAut){
	 		List<Map<String, String>>  result = new ArrayList<Map<String,String>>(); 
	 		DUA dua =  declaracion.getDua();
	 		boolean tieneDocumentoReso = false;

	 		//List<DatoOtroDocSoporte> lstDatoOtroDocSoporte = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION);
	 		List<DatoOtroDocSoporte> lstDatoOtroDocSoporte = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION,ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION);//Se adiciono cod "22" - PAS20165E220200022
			if(!CollectionUtils.isEmpty(lstDatoOtroDocSoporte)){
				tieneDocumentoReso = true;					
		 	}
			
			if (!tieneDocumentoReso && flagTieneDocumento){
				if(esDilDespaAgregarDocAut) {
					DatoOtroDocSoporte datoOtroDocSoporteTmp = getDatoOtroDocSoporte(dua);
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
							.getError("35462", new String[] { datoOtroDocSoporteTmp.getNumdocasoc() }));
				} else {
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35442"));	
				}
			} else if (tieneDocumentoReso && !flagTieneDocumento){
		        result.add(((CatalogoAyudaService)this.fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35428"));
			}
			
			return result;
	 	}

		//2.1.3	Si el Tipo de Documento Asociado tiene el c�digo �02�, se debe haber transmitido los siguientes datos, 
	 	//excepto para las series que hayan consignado los c�digos liberatorios 2001, 2002:
	 	//Nombre de la Entidad Emisora
	 	//Tipo de Documento de la Entidad Emisora
	 	//N�mero de Documento de la Entidad Emisora
	 	//C�digo del Tipo de Entidad Emisora  (aduana, entidad externa):
	 	//N�mero de documento
	 	//Fecha de emisi�n del documento.
	 	//Caso contrario se ejecuta la excepci�n Nro.3.
	 	//Mensaje: DEBE TRANSMITIR UN VALOR PARA ({0} CAMPO OMITIDO):
	 	
		private List<Map<String, String>> validarDocAsociadoResolucionsinCodigoLiberatorio20012002(DatoSerie datoSerie, DUA dua, boolean esDilDespaAgregarDocAut){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			List<DatoOtroDocSoporte> lstDatoDocSoporte 	 = dua.getListOtrosDocSoporte();
			
				for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
					
					if(!ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE.equals(datoSerieDocSoporte.getCodtipodocsoporte()) && !esDilDespaAgregarDocAut){
						continue;
					}
					if (!SunatStringUtils.isEqualTo(String.valueOf(datoSerie.getCodliberatorio()),ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS) || 
					   (!SunatStringUtils.isEqualTo(String.valueOf(datoSerie.getCodliberatorio()),ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS))){
							for (DatoOtroDocSoporte datoSerie2 : lstDatoDocSoporte) {
									if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte()))  ){
											if (SunatStringUtils.isEqualTo(datoSerie2.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION)
													||SunatStringUtils.isEqualTo(datoSerie2.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION)){ //Se adiciono cod "22" - PAS20165E220200022
												String mensaje = " ";
												String nombreEntidadEmisora 			= datoSerie2.getDesentidad(); //Nombre de la Entidad Emisora
												String tipodeDocumentoEntidadEmisora 	= datoSerie2.getCodtipodocentidad();//Tipo de Documento de la Entidad Emisora
												Long numerodeDocumentoEntidadEmisora 	= datoSerie2.getCodentidademisora();//N�mero de Documento de la Entidad Emisora
												String codigoDocumentoEntidadEmisora 	= datoSerie2.getCodtipoentidad();//C�digo del Tipo de Entidad Emisora  (aduana, entidad externa):
												String numerodeDocumento			 	= datoSerie2.getNumdocasoc();//N�mero de Documento 
												Date fechadeEmisionDocumento 			= datoSerie2.getFecdocasoc();
												     String comodin="";
													if (SunatStringUtils.isEmptyTrim(nombreEntidadEmisora)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NOMBRE_ENTIDAD_EMISORA);
													}	
													if (SunatStringUtils.isEmptyTrim(tipodeDocumentoEntidadEmisora)) {
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_TIPO_DOCUMENTO_ENTIDAD_EMISORA);
													}	
													if (numerodeDocumentoEntidadEmisora==null || numerodeDocumentoEntidadEmisora==0){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTODE_ENTIDAD_EMISORA);
													}	
													if (SunatStringUtils.isEmptyTrim(codigoDocumentoEntidadEmisora)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_CODIGO_TIPO_ENTIDAD_EMISORA);
													}	
													if (SunatStringUtils.isEmptyTrim(numerodeDocumento)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTO);
													}
													if (fechadeEmisionDocumento==null){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_FECHA_ENTIDAD_EMISORA);
													}
													//    Caso contrario se ejecuta la excepci�n Nro.3.	
								  				  	//Mensaje: DEBE TRANSMITIR UN VALOR PARA ({1} CAMPO OMITIDO):
									  				if (!SunatStringUtils.isEmptyTrim(mensaje)){
									  					if(esDilDespaAgregarDocAut) {
									  						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35463",
									  								new String[] { mensaje.toString(), datoSerie2.getNumdocasoc() }));
									  					} else {
									  						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35449",new String[]{datoSerie.getNumserie().toString(),datoSerie2.getNumsecdocum().toString(),mensaje.toString()}));									  						
									  					}
													   break;
									  			    } 
											}
									}	
							}
					   }
					}
			return result;
		}
// Valida no exista dos codigos liberatorios diferentes
private List<Map<String, String>> validarnoExistaCodigosLiberatoriosDiferentes( DatoSerie datoSerie, int posicion,boolean flagDiligencia){
	List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
	Integer codLiberatorioActual = datoSerie.getCodliberatorio();
	Integer nroSerieActual = datoSerie.getNumserie();
	String codLiberatorioPrevioDesc="";
	String codLiberatorioActualDesc="";
	boolean codLibDiligenciaVacio=false;
	
	
					
	if(posicion==0){
			codLiberatorioPrevio = codLiberatorioActual;/* encuentra el primero*/
			nroSeriePrevio = nroSerieActual;
		}
	if(!codLiberatorioPrevio.equals(codLiberatorioActual)){
			if((new Integer(0)).equals(codLiberatorioPrevio)){
				if(flagDiligencia){
					codLibDiligenciaVacio=true;
				}
				codLiberatorioPrevioDesc="COD. LIBERATORIO VACIO ";
			}
			else{
				
				codLiberatorioPrevioDesc=String.valueOf(codLiberatorioPrevio);
			}
			
			if((new Integer(0)).equals(codLiberatorioActual)){
				if(flagDiligencia){
					codLibDiligenciaVacio=true;
				}
				codLiberatorioActualDesc="COD. LIBERATORIO VACIO ";
			}
			else{
				codLiberatorioActualDesc=String.valueOf(codLiberatorioActual);
			}
			
			if(!codLibDiligenciaVacio){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30526",new String[]{codLiberatorioPrevioDesc, String.valueOf(nroSeriePrevio), codLiberatorioActualDesc, String.valueOf(nroSerieActual)}));	
			}
			
		} 
	if(codLiberatorioPrevio.equals(codLiberatorioActual) || codLibDiligenciaVacio){
		
			codLiberatorioPrevio = codLiberatorioActual;/* encuentra el primero*/
			nroSeriePrevio = nroSerieActual;
		}
	
	return result;
}		
//P46-PAS20155E410000032 inicio
//Valida no exista documentos de regularaizacion diferentes
private List<Map<String, String>> validarnoExistaDocRegularizacionDiferentes( DatoSerie datoSerie,int posicion){
	List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
	String codRegularizacionActual = datoSerie.getCodTipRegul();
	Integer nroSerieActual = datoSerie.getNumserie();
	String codRegularizacionPrevioDesc="";
	String codRegularizacionActualDesc="";
	if(posicion==0){
		codRegularizacionPrevio = codRegularizacionActual;/* encuentra el primero*/
			nroSeriePrevio = nroSerieActual;
		}
	if(!codRegularizacionPrevio.equals(codRegularizacionActual)){
			codRegularizacionPrevioDesc=String.valueOf(codLiberatorioPrevio);
			codRegularizacionActualDesc=String.valueOf(codRegularizacionActual);
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30526",new String[]{codRegularizacionPrevioDesc, String.valueOf(nroSerieRegulPrevio), codRegularizacionActualDesc, String.valueOf(nroSerieActual)}));	
		} 
	if(codRegularizacionPrevio.equals(codRegularizacionActual)){
		
		codRegularizacionPrevio = codRegularizacionActual;/* encuentra el primero*/
			nroSerieRegulPrevio = nroSerieActual;
	}
	return result;
}	
//P46-PAS20155E410000032 inicio
private List<Map<String, String>> validarDocAsociadoExpedienteDatosEnviados(DatoSerie datoSerie, DUA dua){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			List<DatoOtroDocSoporte> lstDatoDocSoporte 	 = dua.getListOtrosDocSoporte();
			
				for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
					
					if(!ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE.equals(datoSerieDocSoporte.getCodtipodocsoporte()) ){
						continue;
					}
					
							for (DatoOtroDocSoporte datoSerie2 : lstDatoDocSoporte) {
									if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte()))  ){
											if (SunatStringUtils.isEqualTo(datoSerie2.getCodtipodocasoc(), ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE)){
												String mensaje = " ";
												String nombreEntidadEmisora 			= datoSerie2.getDesentidad(); //Nombre de la Entidad Emisora
												
												String tipodeDocumentoEntidadEmisora 	= datoSerie2.getCodtipodocentidad();//Tipo de Documento de la Entidad Emisora
												Long numerodeDocumentoEntidadEmisora 	= datoSerie2.getCodentidademisora();//N�mero de Documento de la Entidad Emisora
												String codigoDocumentoEntidadEmisora 	= datoSerie2.getCodtipoentidad();//C�digo del Tipo de Entidad Emisora  (aduana, entidad externa):
												
												String numerodeDocumento			 	= datoSerie2.getNumdocasoc();//N�mero de Documento 
												Date fechadeEmisionDocumento 			= datoSerie2.getFecdocasoc();
												    String comodin="";
													if (SunatStringUtils.isEmptyTrim(nombreEntidadEmisora)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NOMBRE_ENTIDAD_EMISORA);
													}
													if (SunatStringUtils.isEmptyTrim(tipodeDocumentoEntidadEmisora)) {
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_TIPO_DOCUMENTO_ENTIDAD_EMISORA);
													}
													if (numerodeDocumentoEntidadEmisora==null || numerodeDocumentoEntidadEmisora==0){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTODE_ENTIDAD_EMISORA);
													}	
													if (SunatStringUtils.isEmptyTrim(codigoDocumentoEntidadEmisora)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_CODIGO_TIPO_ENTIDAD_EMISORA);
													}
													if (SunatStringUtils.isEmptyTrim(numerodeDocumento)){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_NUMERO_DOCUMENTO);
													}
													if (fechadeEmisionDocumento==null){
														comodin=!SunatStringUtils.isEmptyTrim(mensaje)?"-":"";
														mensaje = mensaje.concat(comodin).concat(ConstantesDataCatalogo.DATOS_FECHA_ENTIDAD_EMISORA);
													}
													
									  				if (!SunatStringUtils.isEmptyTrim(mensaje)){
									  						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35468",new String[]{datoSerie.getNumserie().toString(),datoSerie2.getNumsecdocum().toString(),mensaje.toString()}));									  						
									  					}
													   break;
									  			    } 
											}
									}	
							}
					
			return result;
		}
		private List<Map<String, String>> validarEsteAsociadoDocumento(DatoSerie datoSerie, DUA dua, boolean conDocAutorizante, Declaracion declaracion){//P46-PAS20155E410000032-[jaime]
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			List<DatoOtroDocSoporte> lstDatoDocSoporte 	 = dua.getListOtrosDocSoporte();
			boolean serieSinResDonacion = false;
			String nrosecuencia = " ";
			String[] arrayCodLibeDonacion = new String[] {
					ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
					ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS}; 
			
			for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
					
					if(!ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE.equals(datoSerieDocSoporte.getCodtipodocsoporte()) ){
						continue;
					}
					
					for (DatoOtroDocSoporte datoOtroDocSoporte  : lstDatoDocSoporte) {
						if(datoOtroDocSoporte.getIndicadorEliminado()!=null && datoOtroDocSoporte.getIndicadorEliminado()==1){
							continue;
						}
									if(new Integer(datoOtroDocSoporte.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte())) && datoOtroDocSoporte.getCodtipoproceso().equals(datoSerieDocSoporte.getCodtipooper()) ){
										if(!datoOtroDocSoporte.getCodtipoproceso().equals(ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){ //no deberia pasar aca pero porsiacaso
											continue;
										}
											if (!SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipodocasoc(), ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE) && !conDocAutorizante){
												 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35465",new String[]{datoSerie.getNumserie().toString(),datoOtroDocSoporte.getNumsecdocum().toString()}));
											} 
											else
											if (!SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION) &&
												 !SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION) && conDocAutorizante){//Se adiciono cod "22" - PAS20165E220200022
												//INICIO-P46-PAS20155E410000032-[jaime] 
												 if( !ConstantesDataCatalogo.CON_SILENCIO_ADMINISTRATIVO_POSITIVO.equals(datoSerie.getCodTipRegul()) &&  esReg10EnRectiOficio(declaracion) && !SunatStringUtils.include(SunatStringUtils.toStringObj(datoSerie.getCodliberatorio()), arrayCodLibeDonacion)
													 && !SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipodocasoc(), ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE) ){//INICIO-PAS20165E220200135
													 serieSinResDonacion = true;
													 nrosecuencia = datoOtroDocSoporte.getNumsecdocum().toString();
												 }else if(!esReg10EnRectiOficio(declaracion)){
													 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35442",new String[]{datoSerie.getNumserie().toString(),datoOtroDocSoporte.getNumsecdocum().toString()}));									  						
										  	} 
												//FIN-P46-PAS20155E410000032-[jaime]								  						
										  	} 
									 }
					}	
					if (serieSinResDonacion) 
						 result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35442",new String[]{datoSerie.getNumserie().toString(),nrosecuencia}));
			 }
			return result;
		}

//		public List<Map<String,String>> validarSerieDocumentodeSoporte (Declaracion declaracion){
//			return validarSerieDocumentodeSoporte (declaracion, false);
//		}
		
		//2.1.4.1	Que tenga el c�digo �1� (Documento de Soporte) como Tipo de documento de soporte asociado,que todas tengan codLib 
		
				
//		public List<Map<String,String>> validarSerieDocumentodeSoporte (Declaracion declaracion, boolean  flagDiligencia){
//			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
//			List<DatoSerie> 				 lstSeries 		 	 = declaracion.getDua().getListSeries();//et(0).getListSerieDocSoporte();
//			List<DatoOtroDocSoporte> 		 docSoportes	 	 = declaracion.getDua().getListOtrosDocSoporte();
//		//	boolean serieTieneTipoSoporte = false;
//			
//			for(DatoSerie datoSerie:lstSeries){
//
//				//Si Cuenta con Codigo Liberatorio
//				boolean serieTieneCodLibera = datoSerie.getCodliberatorio()!=0 ? true : false;
//				boolean duaTieneTipoSoporte = false;
//				boolean serieTienedocDonacion = false;
//				boolean yaSeValidoSerieTieneCodLibera = false;
//				
//				for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
//					
//					
//					if (SunatStringUtils.isEqualTo(datoSerieDocSoporte.getCodtipodocsoporte(), ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE)){	
//						//Serie cuenta con documento de soporte
//						
//						duaTieneTipoSoporte = true;
//						for (DatoOtroDocSoporte datoSerie2 : docSoportes) {
//							// se corrige pq se confunde con los doc mercancias restringidas para la diligencia
//							if(flagDiligencia){ 
//								if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte())) && datoSerie2.getCodtipoproceso().equals(datoSerieDocSoporte.getCodtipooper())){
//									
//									if(datoSerie2.getCodtipoproceso().equalsIgnoreCase(ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
//										serieTienedocDonacion = true;
//										break;
//									}
//									
//								}
//							
//							} else {
//								 if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte()))){
//									
//									if(datoSerie2.getCodtipoproceso().equalsIgnoreCase(ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
//										serieTienedocDonacion = true;
//										break;
//									}
//									
//								}
//							}
//							
//						}
//						//Si la serie cuenta con codigo libera, este se valida
//						if (serieTieneCodLibera){
//								CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
//								if (!codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio())){
//									result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35447",new String[] {datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
//								}
//					    //Si la serie NO cuenta con codigo libera se pide ingresarlo
//						} else {
//							yaSeValidoSerieTieneCodLibera = true;
//							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35436",new String[] {datoSerie.getNumserie().toString()}));
//						}
//						
//					}
//				}
//				
//				boolean esCodLibe2001o2002 = !CollectionUtils.isEmpty(validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie));
//				
//				//Si la serie No cuenta con doc soporte  para estandariza se cambia   esTransmision por !FlagDiligencia
//				if (!flagDiligencia && !duaTieneTipoSoporte && !esCodLibe2001o2002) {
//					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35451", new String[] {datoSerie.getNumserie().toString()}));
//				}
//				
//
//				// Validar que todas las series tengan codigo liberatorio (solo en numeracion) para estandariza se cambia   esTransmision por !FlagDiligencia
//				if(!flagDiligencia && !yaSeValidoSerieTieneCodLibera && !serieTieneCodLibera) {
//					result.add((
//							(CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35436",
//									new String[] { datoSerie.getNumserie().toString() }));
//				}
//				//si tiene codigo liberatorio validar que presente documento donacion
//				//2.1.4.2	Que tenga el C�digo �1� (Documento de Donaci�n) como Tipo de Proceso del documento asociado.
//				if(!serieTienedocDonacion && serieTieneCodLibera   && !esCodLibe2001o2002){
//					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35437",new String[] {datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
//				}
//				
//		}
//		
//		 return result;
//		}
		//2.1.4.1	Que tenga el c�digo �1� (Documento de Soporte) como Tipo de documento de soporte asociado,que todas tengan codLib
		private List<Map<String,String>> validarSerieDocumentodeSoporte(DatoSerie datoSerie, Declaracion declaracion, boolean  flagDiligencia){//P46-PAS20155E410000032
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			
			List<DatoOtroDocSoporte> 		 docSoportes	 	 = declaracion.getDua().getListOtrosDocSoporte();//P46-PAS20155E410000032

				//Si Cuenta con Codigo Liberatorio
				boolean serieTieneCodLibera = datoSerie.getCodliberatorio()!=0 ? true : false;
				boolean duaTieneTipoSoporte = false;
				boolean serieTienedocDonacion = false;
				boolean yaSeValidoSerieTieneCodLibera = false;
				String codTipoDocAsoc="";//P46-PAS20155E410000032-[jaime]
				
				for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
					
					
					if (SunatStringUtils.isEqualTo(datoSerieDocSoporte.getCodtipodocsoporte(), ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE)){	
						//Serie cuenta con documento de soporte
						
						duaTieneTipoSoporte = true;
						for (DatoOtroDocSoporte datoSerie2 : docSoportes) {
							// se corrige pq se confunde con los doc mercancias restringidas para la diligencia
							if(flagDiligencia){ 
								if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte())) && datoSerie2.getCodtipoproceso().equals(datoSerieDocSoporte.getCodtipooper())){
									
									if(datoSerie2.getCodtipoproceso().equalsIgnoreCase(ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
										serieTienedocDonacion = true;
										codTipoDocAsoc=datoSerie2.getCodtipodocasoc();//P46-PAS20155E410000032-[jaime]
										break;
									}
									
								}
							
							} else {
								 if(new Integer(datoSerie2.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte()))){
									
									if(datoSerie2.getCodtipoproceso().equalsIgnoreCase(ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)){
										serieTienedocDonacion = true;
										break;
									}
									
								}
							}
							
						}
						//Si la serie cuenta con codigo libera, este se valida
						if (serieTieneCodLibera){
								CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
								if (!codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio())){
									presentaAlgunCodLibNoEsDonacion=true; //P46-PAS20155E410000032
									result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35447",new String[] {datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
								}
					    //Si la serie NO cuenta con codigo libera se pide ingresarlo
						} else {
							yaSeValidoSerieTieneCodLibera = true;
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35436",new String[] {datoSerie.getNumserie().toString()}));
						}
						
					}
				}
				
				boolean esCodLibe2001o2002 = !CollectionUtils.isEmpty(validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie));
				
				//Si la serie No cuenta con doc soporte  para estandariza se cambia   esTransmision por !FlagDiligencia
				if (!flagDiligencia && !duaTieneTipoSoporte && !esCodLibe2001o2002) {
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35451", new String[] {datoSerie.getNumserie().toString()}));
				}
				
				
				// Validar que todas las series tengan codigo liberatorio (solo en numeracion) para estandariza se cambia   esTransmision por !FlagDiligencia
				if(!flagDiligencia && !yaSeValidoSerieTieneCodLibera && !serieTieneCodLibera) {
					result.add((
							(CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35436",
									new String[] { datoSerie.getNumserie().toString() }));
				}
				//si tiene codigo liberatorio validar que presente documento donacion
				//2.1.4.2	Que tenga el C�digo �1� (Documento de Donaci�n) como Tipo de Proceso del documento asociado.
				if(!serieTienedocDonacion && serieTieneCodLibera   && !esCodLibe2001o2002 && !declaracion.isRegistrarCodLibeDonacion()){//P46-PAS20155E410000032
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35437",new String[] {datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
				}
				
				//ini P46-PAS20155E410000032
				if(declaracion.isRegistrarCodLibeDonacion()) {
					CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
					if(serieTieneCodLibera && codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio())) {
						if(ConstantesDataCatalogo.CON_PRESENTACION_DE_DOCUMENTOS_AUTORIZANTES.equals(datoSerie.getCodTipRegul())
								&& !serieTienedocDonacion) {
							if(!esCodLibe2001o2002)
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35583",
									new String[] { datoSerie.getNumserie().toString() }));
						} else if(ConstantesDataCatalogo.CON_SILENCIO_ADMINISTRATIVO_POSITIVO.equals(datoSerie.getCodTipRegul())
								&& serieTienedocDonacion){
							//INICIO-P46-PAS20155E410000032-[jaime]
							/*PAS20155E410000032-insi
							String  descDocumento="RESOLUCION DE DONACION";
							if(codTipoDocAsoc.equals(ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE)){
								descDocumento="EXPEDIENTE - EN TRAMITE";
							}
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35584",
									new String[] { datoSerie.getNumserie().toString(),descDocumento}));
							*/		
							//FIN-P46-PAS20155E410000032-[jaime]
						}
					}
				}
				//fin P46-PAS20155E410000032
		
		 return result;
		}
		// porsiacaso EJHM 21141
		private List<Map<String,String>> validarEsteAsociadoDocumentoExpediente(DatoSerie datoSerie, DUA dua){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			List<DatoOtroDocSoporte> lstOtrosDocSoporte 	 = dua.getListOtrosDocSoporte();
			
			boolean estaAsociadoDocExpediente=false;
			for ( DatoSerieDocSoporte datoSerieDocSoporte : datoSerie.getListSerieDocSoporte()) {
					
					if(!ConstantesDataCatalogo.DOCUMENTO_DE_SOPORTE.equals(datoSerieDocSoporte.getCodtipodocsoporte()) ){
						continue;
					}
					
					for (DatoOtroDocSoporte datoOtroDocSoporte : lstOtrosDocSoporte) {
						if(datoOtroDocSoporte.getIndicadorEliminado()!=null && datoOtroDocSoporte.getIndicadorEliminado()==1){
							continue;
						}
								if(new Integer(datoOtroDocSoporte.getNumsecdocum()).equals(new Integer(datoSerieDocSoporte.getNumiddocsoporte()))  ){
									if (SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipodocasoc(), ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE)  &&
											SunatStringUtils.isEqualTo(datoOtroDocSoporte.getCodtipoproceso(),ConstantesDataCatalogo.COD_DOCUMENTO_DONACION)	
											){
											 estaAsociadoDocExpediente=true;
										} 
								}
					}	
			}
			if (!estaAsociadoDocExpediente){
				result.add((
						(CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35484",
								new String[] { datoSerie.getNumserie().toString() }));
				
			}
			 return result;
		}
		
	
		
		//2.1.5	Que el C�digo Liberatorio sea uno de los definidos en el Anexo 1, caso contrario se ejecuta la excepci�n Nro. 5.
		//2000 DONACIONES DE BIENES PARA FUNDACIONES
		//2001 DONACIONES A ENTIDADES RELIGIOSAS
		//2002 VEH�CULOS DONADOS A ENTIDADES RELIGIOSAS
		//3806 DONACIONES SECTOR PUBLICO EXCEPTO EMPRESAS DEL ESTADO
		//3807 VEH�CULOS DONADOS A DEP.DEL SECT.PUBLICO NAC.
		//3808 VEH�CULOS IMPORTADOS CON FINANCIAMIENTO DE DONAC.POR CONVENIO
		//3809 BIENES DONADOS, IMPORTACI�N CON FINANCIACION DE DONACION PARA
		// Mensaje:EN LA  SERIE ({0}), EL C�DIGO LIBERATORIO DE DONACI�N, NO CORRESPONDE AL TIPO DE TRATAMIENTO CONSIGNADO EN LA DECLARACI�N� 
		public List<Map<String, String>> validarCodigoLiberatorioporSerie(DatoSerie datoSerie){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			
			 if (datoSerie.getCodliberatorio()!=0){
				 CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
					boolean tieneCodLiberatorio = codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio());
				if (!tieneCodLiberatorio){
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35447",new String[]{datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
				}
			}
			return result;
		}
		
		//2.1.6	Que el c�digo liberatorio debe encontrarse vigente a la fecha de numeraci�n y que se haya declarado como Tipo de Documento Asociado el C�digo �2� (resoluci�n).
		//Caso contrario se ejecuta la excepci�n Nro.8.
		//result.add(catalogoAyudaService.getError("35416",new String[]{codLiberatorio,datoSerieDocSoporteTemp.getNumserie().toString()}));
		
		public List<Map<String, String>> validarCodigoLiberatorioporSerieVigente(DatoSerie datoSerie, Declaracion declaracion){//P46-PAS20155E410000032-[jlunah]
			
			DUA dua = declaracion.getDua();//P46-PAS20155E410000032-[jlunah]
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
//			List<DatoOtroDocSoporte> lstDatoDocSoporte 	 = declaracion.getDua().getListOtrosDocSoporte();
//			List<DatoSerie> 		 lstSeries 		 	 = declaracion.getDua().getListSeries();
			
			CatalogoAyudaService catalogoAyudaService =fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String[] arrayCodLibeDonacion = new String[] {
					ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
					ConstantesDataCatalogo.COD_LIBE_DONA_IMPO_FINANCIACION,
					ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
					ConstantesDataCatalogo.COD_LIBE_DONA_SECTOR_PUBLICO,
					ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_POR_CONVENIO,
					ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS,
					ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_SECTOR_PUBLICO }; 

//			if(!CollectionUtils.isEmpty(lstSeries)){
//				for (DatoSerie datoSerie : lstSeries) {
					String codLiberatorio = datoSerie.getCodliberatorio().toString();
					String numeroSerie  = datoSerie.getNumserie().toString();
					if (SunatStringUtils.include(SunatStringUtils.toStringObj(datoSerie.getCodliberatorio()), arrayCodLibeDonacion)){
						String  tipo_lib 				= ConstantesDataCatalogo.CODIGO_LIBERATORIO;
						//Integer fecha_nume=dua.getFecdeclaracion()!=null?SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion()):SunatDateUtils.getIntegerFromDate(new Date());
					    Integer fecha_nume  			= SunatDateUtils.getIntegerFromDate(new Date());
						Integer codi_libe				= datoSerie.getCodliberatorio();

							PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
							List<CodiLibe> lstCodlib =  preferenciaArancelariaService.obtenerPreferenciaArancelariaVigente(tipo_lib, SunatNumberUtils.toInteger(codi_libe), SunatDateUtils.getDateFromInteger(fecha_nume));
							//rptaCodiLibe=valVerilib.validarVigenciaCodiLibe(codiLibeBean);
							if (!CollectionUtils.isEmpty(lstCodlib)){
						 		//List<DatoOtroDocSoporte> lstDatoOtroDocSoporte = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION);
								List<DatoOtroDocSoporte> lstDatoOtroDocSoporte = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION,ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION);//Se adiciono cod "22" - PAS20165E220200022
						 		if (CollectionUtils.isEmpty(lstDatoOtroDocSoporte)){
						 			/*inicio P46-PAS20155E410000032-[jlunah] BUG 25050*/
						 			boolean declaracionEstaCancelada =  declaracionEstaCancelada(declaracion);
						 			if(this.esReg10EnRectiOficio(declaracion) && !declaracionEstaCancelada){// Es recti oficio y declaracion no esta cancelada
						 				String[] arrayCodLibeDonacionNoEvaluar = new String[] {
						 						ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
						 						ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS };
						 				if (!SunatStringUtils.include(SunatStringUtils.toStringObj(datoSerie.getCodliberatorio()), arrayCodLibeDonacionNoEvaluar)){
									result.add(catalogoAyudaService.getError("35448",new String[]{numeroSerie,codLiberatorio}));
						 		}
							}else{
									result.add(catalogoAyudaService.getError("35448",new String[]{numeroSerie,codLiberatorio}));
						 		}
						 			/*fin P46-PAS20155E410000032-[jlunah] BUG 25050*/
						 		}
							}else{
								 //Mensaje:35416-SERIE ({0}): C�DIGO LIBERATORIO ({0}): SE ENCUENTRA FUERA DE VIGENCIA.
								/*inicio P46-PAS20155E410000032-[jlunah] BUG 25049*/
								if(esReg10EnRectiOficio(declaracion)){
									result.add(catalogoAyudaService.getError("35623",new String[]{datoSerie.getCodliberatorio().toString(),datoSerie.getNumserie().toString()}));
								}else{
									result.add(catalogoAyudaService.getError("35439",new String[]{datoSerie.getNumserie().toString(),datoSerie.getCodliberatorio().toString()}));
							}
								/*fin P46-PAS20155E410000032-[jlunah] BUG 25049*/
							}
					 }
//				 }		
//			  }			   
			return result;
		}		
					
		//2.1.7	Que no se transmita el Documento de Autorizaci�n de la donaci�n cuando tenga c�digos liberatorios 2001, 2002.
		//Caso contrario se ejecuta la excepci�n Nro.9.
		////Mensaje: 35422-�PARA LOS C�DIGOS LIBERATORIOS 2001, 2002, NO SE DEBE TRANSMITIR INFORMACI�N DE LOS DOCUMENTOS AUTORIZANTES�
		public List<Map<String, String>> validarDocuAutorizanteDonacionCodigoLiberatorio20012002(DatoSerie datoSerie){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			
				if (SunatStringUtils.isEqualTo(String.valueOf(datoSerie.getCodliberatorio()),ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS) || 
					(SunatStringUtils.isEqualTo(String.valueOf(datoSerie.getCodliberatorio()),ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS))){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35445",new String[] {datoSerie.getNumserie().toString()}));
				}
			return result;
		}
      	
		
		//2.1.9	Que la fecha de emisi�n de la resoluci�n asociada no sea posterior a la fecha actual. 
		//Caso contrario se ejecuta la excepci�n Nro.10.
		//Mensaje:35423-FECHA DE EMISI�N DEL DOCUMENTO ASOCIADO INV�LIDA
		//result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35423"));
		//Mensaje:35423-FECHA DE EMISI�N DEL DOCUMENTO ASOCIADO INVALIDA
		public List<Map<String,String>> validarFechaEmisionDocuAsociadoResolucion(Declaracion declaracion){
			return validarFechaEmisionDocuAsociadoResolucion(declaracion, false);
		}
		
		public List<Map<String,String>> validarFechaEmisionDocuAsociadoResolucion(Declaracion declaracion, boolean esDiligencia){
			
			List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			List<DatoOtroDocSoporte>  lstDatoOtroDocSoporte 	 	 = declaracion.getDua().getListOtrosDocSoporte();
			Integer fechaActual   = SunatDateUtils.getIntegerFromDate(new Date());
			
			for (DatoOtroDocSoporte datoDocTemp : lstDatoOtroDocSoporte) {
				Integer fechaEmision  = SunatDateUtils.getIntegerFromDate(datoDocTemp.getFecdocasoc());
				if (SunatStringUtils.isEqualTo(datoDocTemp.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION)
						|| SunatStringUtils.isEqualTo(datoDocTemp.getCodtipodocasoc(), ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION)
						|| esDiligencia){ //Se adiciono cod "22" - PAS20165E220200022
					if(fechaEmision > fechaActual){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35446"));
						break;
					}
				}
			}	
			return result;
			
			
		}					
//P46 3003 JMCV FIN
	
	

	
//P46 3003 RA INICIO	

	private List<Map<String,String>> validaDeclaracionSinTipoTratamientoDonacion (Declaracion declaracion,boolean flagDiligencia){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean flagDocAutorizante=false;
		boolean esDilDespaAgregarDocAut=false;
		boolean flagTratamientoDonacion=false;
		//result.addAll(validarRegimenDeclaracion(declaracion));
		String[] ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_TIENE_CODLIB_DONACION};//,ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002
		result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,false,false));
		//validarSeriesDuaTratamientoDonacion (Declaracion declaracion , String[] ejecutarValidacion, boolean esDilDespaAgregarDocAut,boolean flagDocAutorizante,boolean flagTratamientoDonacion)
		result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidaciones,esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion,flagDiligencia));
		result.addAll(validarTipoIndicador(declaracion, true, true));
		
		
		return result;
	}
	
 	private List<Map<String,String>> validarDeclaracionDonacionSinDocumentoAutorizante (Declaracion declaracion){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		
		String[] ejecutarValidaciones = new String[] {ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE,
				ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_EXPEDIENTE_TRAMITADO,
				ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_EXPEDIENTE,
				ConstantesDataCatalogo.VALIDA_NO_TIENE_CODLIB_DONACION
				};
		
		
		boolean flagDocAutorizante=false;
		boolean flagDiligencia=false;

		result.addAll(validarRegimenDeclaracion(declaracion));
		result.addAll(validarTipoIndicador(declaracion, false));
	//	result.addAll(validarSinCodigoLiberatorio(declaracion));
		result.addAll(validarSinGarantia160(declaracion));
		result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidaciones,flagDocAutorizante,flagDiligencia));
		result.addAll(validarEnvioFormatoB(declaracion));
		//result.addAll(validarTipodeDocumentoAsociadoResolucion(declaracion, false));
	    result.addAll(validarTransmisionExpediente(declaracion));
		return result;
	}
	/*2.1*/
 	public List<Map<String, String>> validarRegimenDeclaracion (Declaracion declaracion){
 		return validarRegimenDeclaracion (declaracion, "35435");
 	}
 	
 	public List<Map<String, String>> validarRegimenDeclaracion (Declaracion declaracion, String codError){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		String codRegimen = declaracion.getDua().getCodregimen();

		if (!SunatStringUtils.isEqualTo(codRegimen,ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codError));
		}
		
		return result;
	}

	/*2.1.2*/
 	public List<Map<String, String>> validarTransmisionExpediente (Declaracion declaracion){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean tieneExpedienteAsoc = false;
		DUA dua = declaracion.getDua();
 		List<DatoOtroDocSoporte> lstDatoOtroDocSoporteExpedi = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE);

 		if (!CollectionUtils.isEmpty(lstDatoOtroDocSoporteExpedi)){
 			tieneExpedienteAsoc = true;
 		}

	    if (!tieneExpedienteAsoc) {
	      result.add(((CatalogoAyudaService)this.fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35438"));
	    }
	    return result;
	}
 	
    /*2.1.5*/
 	public List<Map<String,String>> validarSinCodigoLiberatorio (Declaracion declaracion){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		CodigoLiberatorioService codigoLiberatorioService = fabricaDeServicios.getService("codigoLiberatorioService");
		
		result.addAll(codigoLiberatorioService.duaTieneCodigoLiberatorio(declaracion.getDua()));
		
		return result;
	}
 	
	/*2.1.4*/
 	public List<Map<String,String>> validarSinGarantia160 (Declaracion declaracion){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		
		if(!StringUtils.isEmpty(codGarantia)){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35429"));
		}
		
		return result;
	}
	/*2.1.6*/
 	
 	private List<Map<String,String>> validarSeriesDuaTratamientoDonacion (Declaracion declaracion , String[] ejecutarValidacion,boolean flagDocAutorizante,boolean flagDiligencia){
 		boolean flagTratamientoDonacion=true;
 		boolean esDilDespaAgregarDocAut=false;
 		return validarSeriesDuaTratamientoDonacion(declaracion, ejecutarValidacion, esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion,flagDiligencia);
 	}
   	
 	private List<Map<String,String>> validarSeriesDuaTratamientoDonacion (Declaracion declaracion , String[] ejecutarValidacion, boolean esDilDespaAgregarDocAut,boolean flagDocAutorizante,boolean flagTratamientoDonacion,boolean flagDiligencia){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		List<Map<String, String>>  resultCodLibDiferentes = new ArrayList<Map<String,String>>();
		List<Map<String, String>>  resultCodRegulDiferentes = new ArrayList<Map<String,String>>();//P46-PAS20155E410000032
 		List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
 		DUA dua = declaracion.getDua();
 		 codLiberatorioPrevio = 0;
 		 nroSeriePrevio = 0;
 		 int posicion=0;
 		//P46-PAS20155E410000032 inicio
 		 codRegularizacionPrevio="";
 		 nroSerieRegulPrevio=0;
 		  presentaAlgunCodLibNoEsDonacion=false;
 		 int posicionRegul=0;
 		//P46-PAS20155E410000032 fin
 		  
 		
 		for (DatoSerie datoSerie : lstSeries) {
 			
 			
 			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_NO_PRESENTA_TPN_TPI, ejecutarValidacion)){
				result.addAll(validarSinTratoPreferencial(datoSerie));
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_NO_TIENE_CODLIB_DONACION, ejecutarValidacion)){
				result.addAll(validaCodLiberatorioSinDonacion(datoSerie,flagTratamientoDonacion));	
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_SI_TIENE_CODLIB_DONACION, ejecutarValidacion)){
				result.addAll(validarCodigoLiberatorioporSerie(datoSerie));
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_NO_PRESENTE_CODLIB_2001_2002, ejecutarValidacion)){
				List<Map<String, String>>  result2=validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie);
				if(!CollectionUtils.isEmpty(result2) && flagDocAutorizante){  //4
			    	//result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35441"));
					//este mensaje 35441 solo deberia salir cuando el cod lib 2001/2002 tiene un documento tipo 02 - resolucion de donacion, 
					//asi tenga documento autorizante deberia dejar pasar, ya esa validacion se hace en el metodo "validarCodigoLiberatorioHabilitadoParaDonacion" PAS20155E410000032
			    }
				else
				if(!CollectionUtils.isEmpty(result2))
				{
				 result.addAll(result2);	
				}
				
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_VIGENCIA_CODLIB, ejecutarValidacion)){
				result.addAll(validarCodigoLiberatorioporSerieVigente(datoSerie, declaracion));//P46-PAS20155E410000032-[jlunah]
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_RESOLUCION, ejecutarValidacion)){
				// valida el envio de Datos Resolucion
				result.addAll(validarDocAsociadoResolucionsinCodigoLiberatorio20012002(datoSerie, dua, esDilDespaAgregarDocAut));
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_RESOLUCION_O_EXPEDIENTE, ejecutarValidacion)){
				//.	Que el Tipo de Documento Asociado este asociado  el c�digo �02� o el c�digo "12" 
				result.addAll(validarEsteAsociadoDocumento(datoSerie,dua,flagDocAutorizante, declaracion));//P46-PAS20155E410000032-[jaime]
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_ENVIO_DATOS_DOC_ASOC_EXPEDIENTE_TRAMITADO, ejecutarValidacion)){
				// valida el envio de Datos Expediente
				result.addAll(validarDocAsociadoExpedienteDatosEnviados(datoSerie,dua));
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOS_CODLIB_DIFERENTES, ejecutarValidacion)){
				
				resultCodLibDiferentes.addAll(validarnoExistaCodigosLiberatoriosDiferentes(datoSerie, posicion,flagDiligencia));
				
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_QUE_PRESENTE_CODLIB_2001_2002, ejecutarValidacion)){
				//ini P46-PAS20155E410000032
				boolean tieneSilencioAdministrativoPositivo = ConstantesDataCatalogo.CON_SILENCIO_ADMINISTRATIVO_POSITIVO.equals(datoSerie.getCodTipRegul())
						&& declaracion.isRegistrarCodLibeDonacion();
				if(!tieneSilencioAdministrativoPositivo) {
				CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
					boolean tiemeCodLibDonacion=codigoLiberatorioService.serieTieneCodLiberatorioDonacion20012002(datoSerie.getCodliberatorio(),datoSerie.getNumserie());
					if(!tiemeCodLibDonacion  &&  !flagDiligencia){  // PARA NUMERACION TODAS
					todasSeriescodLib2001_2002=false;
					} else
					if(tiemeCodLibDonacion  &&  flagDiligencia){  // PARA las diligencias algunas
						algunaSeriescodLib2001_2002=true;
				}
				}
				//fin P46-PAS20155E410000032
			}
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_ESTE_ASOC_DOC_EXPEDIENTE, ejecutarValidacion)){
				result.addAll(validarEsteAsociadoDocumentoExpediente( datoSerie, declaracion.getDua()));
			}
			//2.1.4.1	Que tenga el c�digo �1� (Documento de Soporte) como Tipo de documento de soporte asociado,que todas tengan codLib DONACION
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_SERIE_PRESE_DOC_DONA_Y_SOPORTE_TODAS_CUENT_CODLIB_DON, ejecutarValidacion)){
				result.addAll(validarSerieDocumentodeSoporte(datoSerie, declaracion,flagDiligencia));//P46-PAS20155E410000032
			}
			//P46-PAS20155E410000032
			if (SunatStringUtils.include(ConstantesDataCatalogo.VALIDA_NO_EXISTA_DOC_REGULARIZACION_DIFERENTES, ejecutarValidacion) && esReg10EnRectiOficio(declaracion)){
				if(declaracion.isRegistrarCodLibeDonacion() && datoSerie.getCodliberatorio()!=0 ){
					resultCodRegulDiferentes.addAll(validarnoExistaDocRegularizacionDiferentes(datoSerie, posicionRegul));
					
				}
				
			}
			
			posicion++;
			posicionRegul++;//P46-PAS20155E410000032
		}
 		if(!CollectionUtils.isEmpty(resultCodLibDiferentes)){ 
			result.clear();
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35569"));
			return result;
		}
 		//P46-PAS20155E410000032  
 		if(!CollectionUtils.isEmpty(resultCodRegulDiferentes) && !presentaAlgunCodLibNoEsDonacion){ 
			//para no confundir solo se muestra cuando pase la validacion q indica que todos los cod lib son de donacion
 			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35577"));
			return result;
		}
 		return result;
 	}
//	private boolean []  validarCodigoLibDonaciony20012002 (Declaracion declaracion ){
//		boolean [] validaCodLib = new boolean[] {false,false};
// 		List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
// 		
// 		for (DatoSerie datoSerie : lstSeries) {
// 		validarCodigoLiberatorioporSerie(datoSerie);
//		List<Map<String, String>>  result2=validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie);
//				if(!CollectionUtils.isEmpty(result2)){  
//					validaCodLib[0]=true;		
//				}
//				if(datoSerie.getCodliberatorio()!=0){
//					CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
//					validaCodLib[1] = codigoLiberatorioService.serieTieneCodLiberatorioDonacionDistinto20012002(datoSerie.getCodliberatorio());
//				}
//					
//				}
//				
// 		return validaCodLib;
// 	}
 	public List<Map<String,String>> validarSinTratoPreferencial (DatoSerie datoSerie){
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		
		
		int numSerieDUA = datoSerie.getNumserie();
		Integer codigoTPN = datoSerie.getCodtratprefe();
		Integer codigoTPI = datoSerie.getCodconvinter();
		PreferenciaArancelariaService prefeArance = (PreferenciaArancelariaService) fabricaDeServicios.getService("preferenciaArancelariaService"); 
		boolean tienePreferencia = prefeArance.tienePreferencuaArancelaria(codigoTPN, codigoTPI);

		if(tienePreferencia){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35431", new String[]{String.valueOf(numSerieDUA)}));
		}
		
		return result;
	}
	/*2.1.7*/
 	public List<Map<String,String>> validarEnvioFormatoB (Declaracion declaracion) {
	
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		ValCabdav valCabdav = (ValCabdav) fabricaDeServicios.getService("ValCabdav"); 
		if (!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			boolean tieneFormatoB = valCabdav.tieneEnvioFormatoBExonerado(dua, SunatDateUtils.getCurrentDate());
			//Warning
			if (tieneFormatoB){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35432"));
			}
		}
		return result;
 
    } 
	
	/*3.2*/
 	// EJHM se puso por siacaso
 	public List<Map<String, String>> validaCodLiberatorioSinDonacion (DatoSerie datoSerie){
 		boolean flagTratamientoDonacion=true;
 		return validaCodLiberatorioSinDonacion (datoSerie,flagTratamientoDonacion);
 		
 	}
 	private List<Map<String, String>> validaCodLiberatorioSinDonacion (DatoSerie datoSerie,boolean flagTratamientoDonacion){

 		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		CodigoLiberatorioService codigoLiberatorioService = (CodigoLiberatorioService)fabricaDeServicios.getService("codigoLiberatorioService");
		
		boolean tieneCodLiberatorio = codigoLiberatorioService.serieTieneCodLiberatorioDonacion(datoSerie.getCodliberatorio());
		int numSerieDUA = datoSerie.getNumserie();
		
		if (tieneCodLiberatorio && flagTratamientoDonacion) {
			boolean esCodLibe2001o2002 = !CollectionUtils.isEmpty(validarDocuAutorizanteDonacionCodigoLiberatorio20012002(datoSerie));
			
			if(esCodLibe2001o2002) {
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35445", new String[] {String.valueOf(numSerieDUA)}));
			} else {
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35430", new String[]{String.valueOf(numSerieDUA)}));
			}
		}
		else
		if (tieneCodLiberatorio && !flagTratamientoDonacion){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35467",new String[]{String.valueOf(numSerieDUA)}));	
		}
	
		return result;
	}

 	private List<Map<String, String>> validarTipoIndicador (Declaracion declaracion, boolean flagTieneDocumento){
 		return validarTipoIndicador (declaracion, flagTieneDocumento, false);
 	}
 	
	/*3.3*/
 	private List<Map<String, String>> validarTipoIndicador (Declaracion declaracion, boolean flagTieneDocumento,
 			boolean sinTratamientoDonacion){
		
		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
		boolean indicadorValido = false;
		DUA dua = declaracion.getDua();
		List<DatoIndicadores> lstIndicadorImpTotal = getListIndicadorByTipo(dua, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL);
		List<DatoIndicadores> lstIndicadorImpParcial = getListIndicadorByTipo(dua, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
		
		if (!CollectionUtils.isEmpty(lstIndicadorImpTotal) || !CollectionUtils.isEmpty(lstIndicadorImpParcial)){
			indicadorValido = true;
		}

		if (indicadorValido && flagTieneDocumento){
			if(sinTratamientoDonacion) {
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35434"));
			} else {
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35440"));
			}
		} else if (!indicadorValido && !flagTieneDocumento){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35483"));
		}
		
		return result;
	}
	//EJHM
//  public List<Map<String,String>> validarTieneDocumentoAutorizante (Declaracion declaracion) {
//		
//		List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
//	DUA dua = declaracion.getDua();
//	List<DatoOtroDocSoporte> datoOtroDocSoporte = getListDocSoporteByTipoDocAsociado(dua, ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION);
//		
//		if (!CollectionUtils.isEmpty(datoOtroDocSoporte)){
//			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35433"));
//		}
//	
//		return result;
//	}	
public String validarTieneDocumentoAutorizante(Declaracion declaracion, boolean tieneIndicadorImpugnacion,boolean flagDiligencia) {
 		DUA dua = declaracion.getDua();
		//String codDocAutoriza= getDocAutorizanteDonacion(dua,ConstantesDataCatalogo.COD_RESOLUCION_DE_DONACION,ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE,ConstantesDataCatalogo.COD_DOCUMENTO_DONACION,flagDiligencia);
 		String codDocAutoriza= getDocAutorizanteDonacion(dua,ConstantesDataCatalogo.COD_RESOLUCION_ACEPTACION_DONACION,ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE,ConstantesDataCatalogo.COD_DOCUMENTO_DONACION,flagDiligencia);//Se cambio por codigo "22" - PAS20165E220200022
         if(codDocAutoriza.equals("3") && tieneIndicadorImpugnacion ){
        	 codDocAutoriza="2";
         }
         else if(codDocAutoriza.equals("3") && !tieneIndicadorImpugnacion ){
        	 codDocAutoriza="1";	 
         }
		
		return codDocAutoriza;
 	}
      //EJHM
 	
 	public boolean validarTieneTratamientoDonacion (Declaracion declaracion) {
 		
		String codTipoTratamiento = declaracion.getDua().getCodtipotratamiento();
			
		boolean tieneTrataDonacion = SunatStringUtils.isEqualTo(codTipoTratamiento, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION);
		
		return tieneTrataDonacion;
 	}
 	
 	
 	public boolean validarEsAyudaHumanitaria (List<DatoSerie> lstSeries) {
 	
 	    //Inicio PAS20155E220000365 - 20150323 mtorralba - Atenci�n BUG 21231 (P46)
	 	boolean tieneAyudaHumanitaria = false;
	 	for(DatoSerie serie: lstSeries){
			String partida = serie.getNumpartnandi().toString();
			if( partida.equals(ConstantesDataCatalogo.PARTIDA_AYUDA_HUMANITARIA_GENERAL ))
				tieneAyudaHumanitaria = true;
				break;
		}
	 	return tieneAyudaHumanitaria;
		//Fin PAS20155E220000365 - 20150323 mtorralba - Atenci�n BUG 21231		
 	}

 	/*
 	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	//P46 3003 RA FIN	

	// Ini P46 3006
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion
	 */
	public List<Map<String,String>> validarDocAutorizanteDonacionDiligencia(Declaracion declaracion) {
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		boolean flagDocAutorizante=true;
		boolean flagTratamientoDonacion=true;
		boolean esDilDespaAgregarDocAut=true;
		if (validarTieneTratamientoDonacion(declaracion)) {
			result.addAll(validarRegimenDeclaracion(declaracion));
			
			result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, new String[] {"4"}, true,flagDocAutorizante));
			
			if(CollectionUtils.isEmpty(result)) {
				result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,true,true, true));
				result.addAll(validarTipodeDocumentoAsociadoResolucion(declaracion, true, true));

				result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, new String[] {"3", "6"}, esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion,flagDocAutorizante));
				result.addAll(validarFechaEmisionDocuAsociadoResolucion(declaracion, true));
			}
		} else {
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35461"));
		}
		
		return result;
	}
	
	/**
	 * Metodo que permite retornar el documento autorizante que se quiere agregar o modificar.
	 * Este metodo se usara con la finalidad de poder obtener el numero de documento en caso de existir y
	 * asi poder mostrarlo en el mensaje de validacion
	 * 
	 * @param dua
	 * @return
	 */
    private DatoOtroDocSoporte getDatoOtroDocSoporte(DUA dua) {
    	DatoOtroDocSoporte datoOtroDocSoporte = new DatoOtroDocSoporte();
    	
    	if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())) {
    		for(DatoOtroDocSoporte datoOtroDocSoporteTmp : dua.getListOtrosDocSoporte()){
   				datoOtroDocSoporte.setNumdocasoc(datoOtroDocSoporteTmp.getNumdocasoc());
   				break;
    		}
    	}
    	
    	return datoOtroDocSoporte;
    }
	// Fin P46 3006
	
/** inicio mpoblete P46_F23013_CUS02.06**/
 	
	public boolean esTipoTratamientoMercanciaDonacion(DUA dua){
		return (ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION.equals(dua.getCodtipotratamiento()));
	}
	
	public boolean tieneRegimenImportacionConsumo(DUA dua){
		return (ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(dua.getCodregimen()));
	}
	
	public boolean tieneIndicadorImpugnacionParcial(DUA dua){
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numcorredoc",dua.getNumcorredoc());
		params.put("codtipoindica",ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
		params.put("indactivo","1");
		
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		List<DatoIndicadores> listaDatoIndicadores = indicadorDUADAO.findIndicadoresByMap(params);
		return this.duaTieneIndicadorImpugnacionParcialOTotal(listaDatoIndicadores);
	}
	
	public boolean duaTieneIndicadorImpugnacionParcialOTotal(List<DatoIndicadores> listIndicadores){		
		if(!CollectionUtils.isEmpty(listIndicadores)){
			for(DatoIndicadores indicadorTemp:listIndicadores){
				if(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL.equals(indicadorTemp.getCodtipoindica()) || ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL.equals(indicadorTemp.getCodtipoindica())){
					return true;
				}
			}
		}		
		return false;
	}
	
	/** fin mpoblete P46_F23013_CUS02.06**/
	
	/** inicio mpoblete P46_F23013_CUS02.04**/
	
	public boolean esTipoDonacionConTipoCancelmpugnacionSinGarantia(DUA dua){
		boolean resultValidacion = false;
		DUA duaLocal = new DUA();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("numeroCorrelativo",dua.getNumcorredoc());
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		duaLocal = cabDeclaraDAO.findDUAByKeyMap(params);
		
		if(duaLocal!=null){
			boolean duaEsTipoTratamDonacion = false;
			boolean	duaEsRegimenImportacionConsumo = false; 
			boolean	duaTieneIndicadorImpugnacionParcialOTotalTributos = false; 
			boolean	tieneTipoCancelImpugnacionSinGarantiaDonacion = false;
			
			duaEsTipoTratamDonacion = this.esTipoTratamientoMercanciaDonacion(duaLocal);
			duaEsRegimenImportacionConsumo = this.tieneRegimenImportacionConsumo(duaLocal);
			duaTieneIndicadorImpugnacionParcialOTotalTributos = this.tieneIndicadorImpugnacionParcialOTotal(duaLocal);
			LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService"); //reemplazar con inyeccion
			tieneTipoCancelImpugnacionSinGarantiaDonacion = liquidaDeclaracionService.tieneTipoCancelImpugnacionSinGarantiaDonacion(duaLocal); 
					
			if(duaEsTipoTratamDonacion && duaEsRegimenImportacionConsumo && duaTieneIndicadorImpugnacionParcialOTotalTributos && tieneTipoCancelImpugnacionSinGarantiaDonacion){
				resultValidacion = true;
			}			
		}
		
		return resultValidacion;
	}
	
	public boolean tieneIndicadorImpugnacionParcialOTotal(DUA dua){
		
		List<String> listaTipoIndicador = new ArrayList<String>();
		listaTipoIndicador.add(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
		listaTipoIndicador.add(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL);
		
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numcorredoc",dua.getNumcorredoc());
		params.put("indactivo","1");
		params.put("listaTipoIndica",listaTipoIndicador);
		
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		
		List<DatoIndicadores> listaDatoIndicadores = indicadorDUADAO.findIndicadoresByMap(params);
		
		return duaTieneIndicadorImpugnacionParcialOTotal(listaDatoIndicadores);
	}
	
	/** fin mpoblete P46_F23013_CUS02.04**/
	
	/** inicio mpoblete P46_F23013_CUS02.05**/
	
	public boolean esDonacionTipoCancelmpugnacionSinGarantiaLevanteElectronico(DUA dua){
		boolean resultValidacion = true;
		DUA duaLocal = new DUA();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("numeroCorrelativo",dua.getNumcorredoc());
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		duaLocal = cabDeclaraDAO.findDUAByKeyMap(params);
		
		if(duaLocal!=null){
			boolean duaEsTipoTratamDonacion = false;
			boolean	duaEsRegimenImportacionConsumo = false; 
			boolean	duaTieneIndicadorImpugnacionParcialOTotalTributos = false; 
			//boolean	tieneTipoCancelImpugnacionSinGarantiaDonacion = false;
			
			duaEsTipoTratamDonacion = this.esTipoTratamientoMercanciaDonacion(duaLocal);
			duaEsRegimenImportacionConsumo = this.tieneRegimenImportacionConsumo(duaLocal);
//			LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
//			tieneTipoCancelImpugnacionSinGarantiaDonacion = liquidaDeclaracionService.tieneTipoCancelImpugnacionSinGarantiaDonacion(duaLocal);
			
			boolean notificaDUA = false;
			
			if(duaEsTipoTratamDonacion && duaEsRegimenImportacionConsumo){
				if(log.isDebugEnabled()){
	                log.debug("=== DUA ES DE DONACION Y DE REGIMEN 10 ===");
				}
				//resultValidacion = false;
				duaTieneIndicadorImpugnacionParcialOTotalTributos = this.tieneIndicadorImpugnacionParcialOTotal(duaLocal);
				if(duaTieneIndicadorImpugnacionParcialOTotalTributos/*&& tieneTipoCancelImpugnacionSinGarantiaDonacion*/){
					//resultValidacion = true;
					notificaDUA = true;
					if(log.isDebugEnabled()){
		                log.debug("=== DUA TIENE INDICADOR DUA 06 O 07 (IMPUGNACION TOTAL O PARCIAL) Y TIPO DE CANCELACION 73 (IMPUGNADA) ===");
					}
				}/*else{
					boolean duaTieneCodLibDonacion = false;
					duaTieneCodLibDonacion = this.tieneCodigoLiberatorioDonacion(duaLocal);
					if(duaTieneCodLibDonacion){
						resultValidacion = true;
						notificaDUA = true;
						if(log.isDebugEnabled()){
			                log.debug("=== DUA TIENE CODIGO LIBERATORIO DONACION===");
						}

					}
				}*/			
			}	
			
			if(notificaDUA){
				if(log.isDebugEnabled()){
	                log.debug("=== INICIO ENVIAR NOTIFICACION REGULARIZACION DONACION ===");
				}
				this.notificarRegularizacionDonacion(duaLocal);
				if(log.isDebugEnabled()){
	                log.debug("=== FIN ENVIAR NOTIFICACION REGULARIZACION DONACION ===");
				}
			}

		}
				
		return resultValidacion;
	}
	
	public boolean tieneCodigoLiberatorioDonacion(DUA dua){
		boolean result = false;
		SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
		Map<String,Object> filtroDetDeclara = new HashMap<String,Object>();
		filtroDetDeclara.put("NUM_CORREDOC",dua.getNumcorredoc());
		List<Map<String,Object>> listaDetDeclara = serieService.select(filtroDetDeclara);
		
		if(!CollectionUtils.isEmpty(listaDetDeclara)){
			String[] codigosLiberatorios = new String[]{ConstantesDataCatalogo.COD_LIBE_DONA_FUNDACIONES,
					ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS
					,ConstantesDataCatalogo.COD_LIBE_DONA_SECTOR_PUBLICO,ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_SECTOR_PUBLICO
					,ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_POR_CONVENIO,ConstantesDataCatalogo.COD_LIBE_DONA_IMPO_FINANCIACION};
			Map<String,Object> filtroConvenioSerie = new HashMap<String,Object>(); 
			List<Map<String,Object>> listaConvenioSerie = new ArrayList<Map<String,Object>>();
			for(Map<String,Object> detDeclara:listaDetDeclara){
				filtroConvenioSerie = new HashMap<String,Object>();
				filtroConvenioSerie.put("NUM_CORREDOC",detDeclara.get("NUM_CORREDOC"));
				filtroConvenioSerie.put("NUM_SECSERIE",detDeclara.get ("NUM_SECSERIE"));
				filtroConvenioSerie.put("COD_TIPCONVENIO",ConstantesDataCatalogo.CODIGO_LIBERATORIO);
				filtroConvenioSerie.put("IND_DEL","0");
				listaConvenioSerie = serieService.obtenerConvenioSerieMap(filtroConvenioSerie);
				
				for(Map<String,Object> convenioSerie : listaConvenioSerie){
					if(SunatStringUtils.include(convenioSerie.get("COD_CONVENIO").toString(), codigosLiberatorios)){  
						result = true;
						return result;
					}
				}
			}
		}
		return result;
	}
	
	
	public void notificarRegularizacionDonacion(DUA dua){
		String USUARIO_PROCESO_AUTOMATICO = "PROCESO.AUTOMAT";
		UserNameHolder.set(USUARIO_PROCESO_AUTOMATICO);
		StringBuffer data = new StringBuffer();
		
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		Map<String,Object> mapMensaje = new HashMap<String,Object>();
		FechaBean fechaEmision = new FechaBean();
		
		String numeroDeclaracion = dua.getCodaduanaorden();
		numeroDeclaracion = numeroDeclaracion.concat("-").concat(dua.getAnnpresen().toString());
		numeroDeclaracion = numeroDeclaracion.concat("-").concat(dua.getCodregimen());
		numeroDeclaracion = numeroDeclaracion.concat("-").concat(dua.getNumdocumento());
		
		mapMensaje.put("des_asunto","Regularizaci�n de la declaraci�n de donaci�n nro:"+ numeroDeclaracion);
		
		mapMensaje.put("cod_aduana", dua.getCodaduanaorden());
		mapMensaje.put("ann_presen", String.valueOf(dua.getAnnpresen()));
		mapMensaje.put("cod_regimen", dua.getCodregimen());
		mapMensaje.put("num_declaracion", dua.getNumdocumento());	
		
		if(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(dua.getCodaduanaorden())){
			mapMensaje.put("elaborado_por", "Divisi&oacute;n de Importaci&oacute;n de la Intendencia de Aduana Mar&iacute;tima del Callao");
		}else{			
			mapMensaje.put("elaborado_por", "Departamento de T&eacutecnica Aduanera");
		}
		
		Map<String,Object> filtroParticipanteDoc = new HashMap<String,Object>();
		filtroParticipanteDoc.put("numeroCorrelativo",dua.getNumcorredoc()); 
		filtroParticipanteDoc.put("codTiposParticipantes",new String[] { ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO,  ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA });
		
		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
		List<Participante> listaParticipante = participanteService.listarByParameterMap(filtroParticipanteDoc);
		
		if(!CollectionUtils.isEmpty(listaParticipante)){
			PublicacionAvisoService publicacionAvisoService = fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
			String destinatario = "";
			for(Participante participante:listaParticipante){
				if(SunatStringUtils.isEmpty(participante.getNombreRazonSocial())){
					OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaServicePrincipal"); 
					participante.setNombreRazonSocial(operadorAyudaService.getDeclarante(participante.getTipoDocumentoIdentidad().getCodDatacat(),participante.getNumeroDocumentoIdentidad()).get("nombre").toString());
					
				}
				fechaEmision = new FechaBean();
				mapMensaje.put("fecha_emision", fechaEmision.getFormatDate("dd/MM/yyyy"));
				mapMensaje.put("tip_usuario", ConstantesDataCatalogo.COD_TIPO_USUARIO_CONTRIBUYENTE);
				mapMensaje.put("cod_usuario", new String[]{participante.getNumeroDocumentoIdentidad()});
				
//				destinatario = participante.getNumeroDocumentoIdentidad();			
//				destinatario = destinatario.concat("-").concat(SunatStringUtils.convertirCaracteresEspecialesAHtml(participante.getNombreRazonSocial()));
				destinatario = SunatStringUtils.convertirCaracteresEspecialesAHtml(participante.getNombreRazonSocial());
				mapMensaje.put("razonsocial",destinatario);
				if(log.isDebugEnabled()){
	                log.debug("=== NOMBRE RAZON SOCIAL A NOTIFICAR :"+destinatario+" ===");
				}
				data = new StringBuffer(SojoUtil.toJson(mapMensaje));
				if(log.isDebugEnabled()){
	                log.debug("=== DATOS A ENVIAR EN NOTIFICACION :"+data.toString()+" ===");
				}
				publicacionAvisoService.insert(ConstantesDataCatalogo.COD_PLANTILLA_REGULARIZACION_DUA_DONACION,data,ConstantesDataCatalogo.COD_TIPO_USUARIO_CONTRIBUYENTE,fechaEmision.getTimestamp(),fechaVigencia.getTimestamp());
				if(log.isDebugEnabled()){
	                log.debug("=== NOTIFICACION DE REGULARIZACI�N DE DONACION ENVIADA ===");
				}
			}
		}		
	}
	
	/** inicio mpoblete P46_F23013_CUS02.02**/
	public boolean esDonacionTipoCancelmpugnacionSinGarantiaAsignacionCanal(DUA dua){
		boolean resultValidacion = false;
		DUA duaLocal = new DUA();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("numeroCorrelativo",dua.getNumcorredoc());
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		duaLocal = cabDeclaraDAO.findDUAByKeyMap(params);
		if(duaLocal!=null){
			boolean duaEsTipoTratamDonacion = false;
			boolean	duaEsRegimenImportacionConsumo = false; 
			boolean	duaTieneIndicadorImpugnacionParcialOTotalTributos = false; 
			boolean	tieneTipoCancelImpugnacionSinGarantiaDonacion = false;
			
			duaEsTipoTratamDonacion = this.esTipoTratamientoMercanciaDonacion(duaLocal);
			duaEsRegimenImportacionConsumo = this.tieneRegimenImportacionConsumo(duaLocal);
			
			LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
						 
			if(duaEsTipoTratamDonacion && duaEsRegimenImportacionConsumo){
				if(log.isDebugEnabled()){
					log.debug("DUA es de donacion y regimen 10");
				} 
				resultValidacion = false;
				duaTieneIndicadorImpugnacionParcialOTotalTributos = this.tieneIndicadorImpugnacionParcialOTotal(duaLocal);
				tieneTipoCancelImpugnacionSinGarantiaDonacion = liquidaDeclaracionService.tieneTipoCancelImpugnacionSinGarantiaDonacion(duaLocal);
				if(duaTieneIndicadorImpugnacionParcialOTotalTributos && tieneTipoCancelImpugnacionSinGarantiaDonacion){
					if(log.isDebugEnabled()){
						log.debug("DUA tiene indicador impugnacion Parcial o total y tiene tipo cancelacion 73");
					} 
					resultValidacion = true;
				}else{
					if(tieneCodigoLiberatorioDonacion(duaLocal)){
						if(log.isDebugEnabled()){
							log.debug("DUA tiene codigo liberatorio de donacion");
						} 
						resultValidacion = true;
					}
				}
			}
		}
		
	    return resultValidacion;
	}
	/** fin mpoblete P46_F23013_CUS02.02**/
	
	/*Inicio P46 - KAH*/
	public void validarIndicadorDuaenDonacion(Map<String, Object> declaracion) {
		  String descripcionIndicador="";
		  
		  if( declaracion.get("COD_TIPTRATMERC").toString().equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
			  List<Map<String, Object>> ListaIndicador=(List) declaracion.get("LIST_INDICADORES_DUA");
			  if (!CollectionUtils.isEmpty(ListaIndicador)){
				  for (Map<String, Object> indicador : ListaIndicador) {
					  if (indicador.get("COD_INDICADOR").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL) && indicador.get("IND_ACTIVO").toString().equalsIgnoreCase("1")){
						  descripcionIndicador=ConstantesDataCatalogo.IND_DONACION_IMPUGNACION_PARCIAL;
						  break;
					    }
					  if (indicador.get("COD_INDICADOR").toString().equals(ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL) && indicador.get("IND_ACTIVO").toString().equalsIgnoreCase("1")){
						  descripcionIndicador=ConstantesDataCatalogo.IND_DONACION_IMPUGNACION_TOTAL;
						  
						  break;
					    }
				}
			 }
		  }
		  
		  declaracion.put("INDICADOR_DONACION",  descripcionIndicador);
		  		
	}
	/*Fin P46 - KAH*/
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25055*/
    /*retornara true en caso cumpla :
     * -No tenga canal
     * -Declaracion no este cancelada
     * -Tipo de tratamiento diferente a 4
     * */
	public boolean habilitarIngresoDeIndicadorDonacion(Map<String,Object> params){
    	
    	Map<String, Object> declaracion = new HashMap<String, Object>();
    	Map<String, Object> declaracionActual = (Map<String, Object>) (params.get("MapDeclaraActual") == null ? new HashMap<String, Object>() : params.get("MapDeclaraActual"));
    	
    	String codTipTratMerc = (String) declaracionActual.get("COD_TIPTRATMERC");
    	
    	CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
    	DeudaService deudaService = fabricaDeServicios.getService("diligencia.ingreso.deudaService");
    	
    	if(!codTipTratMerc.equals(ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
	    	
    		declaracion = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
    		
    		String msgDeudas = deudaService.tieneDeudaPendiente(declaracion);
	    	if (StringUtils.isEmpty(msgDeudas)){//Si se encuentra cancelada, no debe permitir cambiar el indicador de impugnacion
	    			return false;
	        }
	    	
	    	if(declaracion.get("COD_CANAL") != null){
		    	if(declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_VERDE)
		    		|| declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)
		    		   || declaracion.get("COD_CANAL").equals(ConstantesDataCatalogo.COD_CANAL_ROJO)){
		    		return false;
		    	}
	    	}
    	
    	}else{
    		return true;
    	}
    	
    	return true;
		
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25055*/
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25049*/
	public boolean declaracionEstaCancelada(Declaracion declaracion){
		
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("documentoAduanero", "DUA");
        params.put("cod_aduana", declaracion.getCodaduana());
        params.put("ann_presen", declaracion.getDua().getAnnpresen());
        params.put("cod_regimen", declaracion.getDua().getCodregimen());
        params.put("num_declaracion", declaracion.getNumeroDeclaracion());

		Map<String, Object> decla = new HashMap<String, Object>();
		
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
    	DeudaService deudaService = fabricaDeServicios.getService("diligencia.ingreso.deudaService");
    	
    	decla = cabDeclaraDAO.findByDeclaracion(Utilidades.adaptarParametrosBD(params));
	
		String msgDeudas = deudaService.tieneDeudaPendiente(decla);
		if ((!StringUtils.isEmpty(msgDeudas) 
				&& (declaracion.getDua().getCodCanal() == null))
						 
						 || (!StringUtils.isEmpty(msgDeudas) 
				&& (!declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_VERDE)
						|| !declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)
						 || !declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_ROJO) ))){
			return false;
		}
		
		return true;
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25049*/
	
	/*inicio P46-PAS20155E410000032-[jlunah] BUG 25276*/
	/**
	 * Metodo que permite realizar las validaciones necesarias cuando se intenta
	 * agregar un documento autorizante de tipo donacion para declaraciones no canceladas
	 */
	public List<Map<String,String>> validarDocAutorizanteDonacionDiligenciaDuaSinCancelar(Declaracion declaracion) {
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		boolean flagDocAutorizante=true;
		boolean flagTratamientoDonacion=true;
		boolean esDilDespaAgregarDocAut=true;
		if (validarTieneTratamientoDonacion(declaracion)) {
			result.addAll(validarRegimenDeclaracion(declaracion));
			
			result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, new String[] {"4"}, true,flagDocAutorizante));
			
			if(CollectionUtils.isEmpty(result)) {
				result.addAll(validarTipodeDocumentoAsociadoDoconacion(declaracion,true,true, true));
				result.addAll(validarSeriesDuaTratamientoDonacion(declaracion, new String[] {"3", "6"}, esDilDespaAgregarDocAut,flagDocAutorizante,flagTratamientoDonacion,flagDocAutorizante));
				result.addAll(validarFechaEmisionDocuAsociadoResolucion(declaracion, true));
			}
		} else {
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35461"));
		}
		
		return result;
	}
	/*fin P46-PAS20155E410000032-[jlunah] BUG 25276*/
	
}
