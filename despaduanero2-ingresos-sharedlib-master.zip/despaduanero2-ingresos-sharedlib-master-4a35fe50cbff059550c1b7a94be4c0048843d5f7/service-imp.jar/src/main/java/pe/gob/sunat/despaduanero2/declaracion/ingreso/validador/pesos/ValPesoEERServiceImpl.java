package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.pesos;

import java.math.BigDecimal;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;

public class ValPesoEERServiceImpl extends IngresoAbstractServiceImpl implements ValPesoEERService {
	
	protected final Log logPesoEER = LogFactory.getLog(getClass());
	
	public List<Map<String,String>> valPesoCategoria0203(DatoSerie serie, String codCategoria) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_02.equals(codCategoria) || 
			ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			BigDecimal peso = serie.getCntpesobruto();
			if (peso.compareTo(BigDecimal.ZERO) <= 0) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70114",
						new String[] { serie.getNumserie().toString() }));
			}
		}
		   /*
	      Si la categoria es igual a "02" � igual a "03"
	      entonces el valor de: peso = serie.getCntpesoneto() tienes que ser mayor a cero "0"
	      caso contrario se emite el mensaje de rechazo E35   
	   */
	   return listError;
	}
}
