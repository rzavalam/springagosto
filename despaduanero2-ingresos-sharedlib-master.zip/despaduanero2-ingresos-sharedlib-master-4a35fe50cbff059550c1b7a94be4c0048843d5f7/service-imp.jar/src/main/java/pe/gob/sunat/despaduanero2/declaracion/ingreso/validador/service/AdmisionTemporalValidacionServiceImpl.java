/**
 * 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.service.FeriasDAOService;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.PitTipoPlazos;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.PitTipoPlazosDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValModalidadService;
import pe.gob.sunat.despaduanero2.declaracion.model.CTUsuarios;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//PAS20175E220200059
import pe.gob.sunat.despaduanero2.declaracion.model.RatIp;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CTUsuariosDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.RatIpDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;


/**
 *
 * AdmisionTemporalValidacionServiceImpl.java
 * @author Karina Iparraguirre
 * @version 1.0
 *
 */
public class AdmisionTemporalValidacionServiceImpl extends ValDuaAbstract  implements AdmisionTemporalValidacionService {

    //protected final Log log = LogFactory.getLog(getClass());
    
    //private DataCatalogoDAO dataCatalogoDao;
    //private CTUsuariosDAO ctUsuariosDao;
    //private RatIpDAO ratIpDao;
    //private PagarantiaDAO pagarantiaDao;
    //private CabDeclaraDAO cabDeclaracionDao;
	//private ParticipanteDocDAO participanteDocDao;
    //protected CatalogoHelperImpl catalogoHelper;
//    private FeriasDAO feriasDao;
    //private PitTipoPlazosDAO pitTipoPlazosDao; 
  
    //private AyudaService ayudaService;
    
    //private FeriasDAOService feriasDAOService;
    
    //private FabricaDeServicios fabricaDeServicios;	

	/** Si se trata de la modalidad de despacho maquila (modalidad = 01) y 
     * se trata de la aduana de Tacna, se valida que el tipo y el numero  de
     *  documento se encuentre en la tabla de usuarios de ZOFRATACNA (CTUSUARIOS),  
     *  caso contrario se rechaza con c�digo de error 0576 
   	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> validarUsuariosCeticos(DUA dua){
		Map<String, String> resultadoError = new HashMap<String, String>();

		
		if (( dua.getCodregimen().equals("21") && dua.getCodtipoperacion().equals(dua.getCodregimen().concat("01")) && dua.getCodaduanaorden().equals("172")) || (dua.getCodregimen().equals("20") && dua.getCodtipoperacion().equals(dua.getCodregimen().concat("10")) && dua.getCodaduanaorden().equals("172"))){
			CTUsuariosDAO ctUsuariosDao = (CTUsuariosDAO) fabricaDeServicios.getService("ctUsuariosDAO");
			 Map params = new HashMap();
		     params.put("Cetico",dua.getCodaduanaorden());
		     params.put("NroDocumento",dua.getDeclarante().getNumeroDocumentoIdentidad());
		     params.put("TipoDocumento",dua.getDeclarante().getTipoDocumentoIdentidad());
		     
				List<CTUsuarios> listaCTUsuarios =  ctUsuariosDao.listByParameterMap(params);
				boolean existeUsuarioEnBD = !CollectionUtils.isEmpty(listaCTUsuarios);
				if(!existeUsuarioEnBD){
					resultadoError= getErrorMap("30007", "PARA ESE TIPO OPERACION, DEBE SER UN USUARIO ZOFRATACNA");
				}
	
		}
		
			return resultadoError;
		
	}    
	
//    public FeriasDAO getFeriasDao() {
//		return feriasDao;
//	}
//
//	public void setFeriasDao(FeriasDAO feriasDao) {
//		this.feriasDao = feriasDao;
//	}

	/***** Solo para el codigo de regimen 20 y 21,si se acoge a garantia 160  debe de estar lleno 
     * el campo  codgarantia <>'', validar que fecfinprovsional > 0  y consultar a tabla de 
     * garantias por el codgarantia y obtener la fecha de vencimiento de la garantia, validar 
     * que el fecfinprovsional < = a la fecha de vencimiento de la garantia.Cuando no se acoge 
     * a Garant�a 160 , valida que fecfinprovsional > = a la fecha de numeraci�n.
   	 * @param dua
	 * @return List de errores
	 */
	public List<Map<String, String>> validarPlazoMaximo(DUA dua, String numeroDocumentoIdentidadSender,Map<String, Object> variablesIngreso){
//		Map<String, String> resultadoError = new HashMap<String, String>();
		List<Map<String, String>> resultadoError = new ArrayList<Map<String,String>>();
		
		String resultado="";
		String tipoDesp=""; 
		//int posFinalError=0;
		//int posInicialError=0;
		//String codErr="";
		boolean validaGarantia = false;
		//if (!dua.getPago().getPagoDeclaracion().getCodgarantia().equals("")){
		tipoDesp=(String)  variablesIngreso.get("tipoDesp");

		DatoPago pago=dua.getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String codgarantia=decla!=null?decla.getCodgarantia():null;
		String codTipoPago=decla!=null?decla.getCodtipopago():null;
		String regimen=dua.getCodregimen();
		
		if (!SunatStringUtils.isEmpty(codgarantia) && !SunatStringUtils.isEmpty(codTipoPago) && SunatStringUtils.include(regimen,new String[]{"20","21"})){ // tiene una garantia 160
	      //valida que el valor enviado en COD_TIPOPAGO para Admisiones Temporales siempre sea "G" 
	      if(  !"G".equals(codTipoPago)) {  
	  			resultadoError.add(getErrorMap("30355", ""));
	  			return resultadoError;
	      }
	    }
		//if ("P".equals(codTipoPago)){
		//	  resultadoError.add(catalogoHelper.getErrorMap("30355", ""));
		//  	return resultadoError;
		//}
	  
		if ("G".equals(codTipoPago) && SunatStringUtils.isEmpty(codgarantia)){
	    	// error 30359
	    	resultadoError.add(getErrorMap("30359", ""));
	    	return resultadoError;
	    }
		
		if (! SunatStringUtils.isEmpty( codgarantia ) ){
			
			if( dua.getCodregimen().equals("10")) {
				validaGarantia = codTipoPago.equals("G");  //Para Impo, solo valida cuando CodTipoPago='G'
			}
			
			if( dua.getCodregimen().equals("20") || dua.getCodregimen().equals("21")) { 
				if ( !dua.getFecfinacoregimen().equals(null)&& SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen())>0 ) 
					validaGarantia = true;
			}
			else {
				Date d= new Date();
				if (dua.getFecfinacoregimen() != null && SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen())<SunatDateUtils.getIntegerFromDate(d))
					resultadoError.add(getErrorMap("30000", "FECHA DE VENCIMIENTO ES MAYOR A LA GARANTIA "));
			}

			if ( validaGarantia ) {
				String numdeclaracion = " ";//PAS20175E220200059
				Integer nFECRECTI = 0;
				Declaracion declaracionDB= (Declaracion)variablesIngreso.get("declaracionDB");
				if(declaracionDB!=null){
					numdeclaracion = declaracionDB.getNumeroDeclaracion().toString();
					nFECRECTI=SunatDateUtils.getCurrentIntegerDate();
				}
				PagarantiaDAO pagarantiaDao = (PagarantiaDAO) fabricaDeServicios.getService("pagarantiaDAO");
				  
				 Map params = new HashMap();
			     params.put("cRUC",dua.getDeclarante().getNumeroDocumentoIdentidad()); // RUC del declarante
			     params.put("cADUANA",dua.getCodaduanaorden());
			     params.put("cANO",SunatDateUtils.getCurrentIntegerDate().toString().substring(2, 4)); 	//PAS20165E220200192-mtorralba 12/07/2016 - A�o a 2 d�gitos
			     params.put("cREGIMEN",dua.getCodregimen());
			     params.put("cNUMERO",codgarantia);
			     /*branch 2011-009 ingreos hosorio inicio fin 14/05/2011*/
			     params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion())); //PAS20165E220200192-mtorralba 12/07/2016 - Se pasa fecha de declaraci�n
			     params.put("nFECRECTI", nFECRECTI);
			     params.put("cNUMECORRE", numdeclaracion);//PAS20175E220200059
			     /*branch 2011-009 ingreos hosorio inicio fin 14/05/2011*/
			     //Confirmar con Elsa si el tipodesp es el mismo que en la numeracion.
			     params.put("cMODULO",tipoDesp);
			     resultado=(String)pagarantiaDao.consultarFechaVencimientoGarantia(params);
			     
				/* List<Garantia> listaGarantia = GarantiaDao.listByParameterMap(params);
					boolean existeGarantiaEnBD = !CollectionUtils.isEmpty(listaGarantia);
					if(existeGarantiaEnBD){
						Garantia tmp = listaGarantia.get(0);
						if (dua.getFecfinprovsional().getTime()>tmp.getFEC_FINVIG().getTime()){
							responseMapManager.putError("30000", "FECHA DE VENCIMIENTO ES MAYOR A LA GARANTIA ");
		 				}	
					}
					*/
 
			     if (resultado.length()>0){
			    	 if (resultado.substring(0, 1).equals("1")){//validacion correcta
			    		 //FechaBean fechGarantiaTmp=new FechaBean(resultado.substring(2));
					     //Date fechGarantia=new Date();
					     //fechGarantia=fechGarantiaTmp.getSQLDate();
			    		 Integer iFecFinRegimen=SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen());
			    		 Integer result=SunatNumberUtils.toInteger(resultado.substring(2));
			    		 if ( SunatNumberUtils.isLessThanParam(result, iFecFinRegimen)){
								resultadoError.add(getErrorMap("30000", "FECHA DE VENCIMIENTO ES MAYOR A LA GARANTIA "));
			 				} 
			    	 }else{
				    	 if (resultado.substring(0, 1).equals("0")){//validacion incorrecta
//				    		 for(int i=0; i<resultado.length(); i++){
//				    			 posInicialError=i;
//				    			 if (resultado.substring(i,i+1).equals("|")){
//				    				 for(int j=i; j<resultado.length(); j++){
//				    					 if (resultado.substring(j,j+1).equals("|")){
//				    						 posFinalError=j;
//				    						 j=resultado.length();
//				    					 }
//				    				 }
//				    				 
//				    				 if (posFinalError==1){
//				    					 codErr=resultado.substring(2);
//				    				 }else{
//				    					 codErr=resultado.substring(posInicialError, posFinalError);
//				    				 }
//				    				 
//				    				 resultadoError= catalogoHelper.getErrorMap(codErr, "");
//				    			 }
//				    		 }
				    		 //NSR: Todo lo comentado es reemplazado por esto
				    		 List<String> CodigosError = Arrays.asList(resultado.split("\\|"));
				    		 CodigosError =  CodigosError.subList(1, CodigosError.size()); //Eliminamos el "0"
				    		 for(String codErr1: CodigosError){
				    			 resultadoError.add(getErrorMap(codErr1, ""));
				    		 }
				    	 }
			    	 }
			     }else{
			    	 resultadoError.add(getErrorMap("08275", "FECHA DE VENCIMIENTO DE GARANTIA NO V�LIDA"));
			     }
			     
			} //fin validaGarantia == true
		}

		return resultadoError;
	} 	

    /**Si ctipooperacion=10 y regimen=20, se valida que sea aduana=172 sino se rechaza con 
     * cod error 0272.Si ctipooperacion=01 y regimen=21: se valida que sea aduana=172 sino 
     * se rechaza con cod error 0272, se valida que sea el codmodalidad=01 sino se rechaza 
     * con el cod error 0577.
   	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> validarZofraTacna(DUA dua){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		if (! SunatStringUtils.isEmpty( dua.getCodtipoperacion() ) ){
		if (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("10"))&& dua.getCodregimen().equals("20")){
			if (!dua.getCodaduanaorden().equals("172"))
		        resultadoError= getErrorMap("00272", "TIPOOPERACION NO VALIDO ");
			
			if (!dua.getCodmodalidad().equals("01"))
			    resultadoError= getErrorMap("00577", " MODALIDAD 10 IMPORTACION TEMPORAL 01 ADMISION TEMPORAL  SOLO PERMITIDO PARA DESPACHO NORMAL   ");
		
		}
		if (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("01"))&& dua.getCodregimen().equals("21")){
			if (!dua.getCodaduanaorden().equals("172"))
		        resultadoError= getErrorMap("30000", "FECHA DE VENCIMIENTO ES MAYOR A LA GARANTIA ");
		}

		}
		return resultadoError;
	}


    /** Valida que la cantidad equivalente en unidades de producci�n (se usa para realizar
     *  los descargos en la cuenta corriente) sea mayor que cero
     *  cntunimedidaequi > 0  (validacion por series)
     *  KIB la validacion ya existe en el valnegnumeracionFormA
  	 * @param dua
	 * @return List de errores
	 */	

	public List<Map<String, String>> validarExistaCantEquivalente(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries==true ){
			
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
				   if (datoSerieActual.getProducto().getCntunimedidaequi()!=null){
					if (datoSerieActual.getProducto().getCntunimedidaequi().compareTo(BigDecimal.ZERO)<=0){
						result.add(	getErrorMap("05002", "CANTIDAD EQUIVALENTE DEBE SER MAYOR QUE CERO " + datoSerieActual.getProducto().getCntunimedidaequi()));
					}	
				}else{
					result.add(	getErrorMap("05002", "CANTIDAD EQUIVALENTE DEBE SER MAYOR QUE CERO " + datoSerieActual.getProducto().getCntunimedidaequi()));
				}
			}
		}
		
				
	}

		return result;
	}
	
	
	
    /**
     * Viernes 12 febrero 2010
     * Se coordino con Elsa, la desactivacion del metodo y comentar el codigo.
     * por que ya esta hecho en el metodo fecvencimiento de la clase ValDocSop
     * Valida que declaren el tipo de unidad equivalente en unidades de producci�n
     *  (se usa para realizar los descargos en la cuenta corriente) (select  * 
     *  from tablnew where tipo='78')
 	 * @param dua
	 * @return List de errores
	 */

	public List<Map<String, String>> validarExistaTipoUnidadEquivalente(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		/*boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries==true){
			
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
					DatoProducto product=datoSerieActual.getProducto();
					String codtipoequi=product!=null?product.getCodtipoequi():null;
				
				if (!"".equals(codtipoequi) ){
					// verificar que exista getCodtipoequi en el catalogo 78 tablnew
					boolean verificarCatalogo=esDataCatalogo("78",codtipoequi);
					if (!verificarCatalogo){
						result.add(	catalogoHelper.getErrorMap("05002", "TIPO DE UNIDADES EQUIVALENTES INCORRECTO"));				
					}
				}else{
					result.add(	catalogoHelper.getErrorMap("05002", "TIPO DE UNIDADES EQUIVALENTES INCORRECTO"));
				}
			}
		
		}
		
	}*/
		return result;
	}
	
    /**valida que el item insumo declarado exista en el ultimo cuadro insumo producto
     *  para dicho item en la aduana donde se solicita la numeraci�n de la dua de admisi�n
     *   para el ruc del beneficiario.
     *   KIB *  
 	 * @param dua
	 * @return List de errores
	 */

	public List<Map<String, String>> validarItemInsumoDeclarado(DUA dua) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries==true){
			RatIpDAO ratIpDao = (RatIpDAO) fabricaDeServicios.getService("ratIpDAO");
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
					Map params = new HashMap();
					DatoProducto product=datoSerieActual.getProducto();
					String numitem=product!=null?product.getNumitem():null;
					String codtipoequi=product!=null?product.getCodtipoequi():null;
					
					params.put("numDocumento",dua.getDeclarante().getNumeroDocumentoIdentidad());
					params.put("codAduana",dua.getCodaduanaorden());	
					params.put("numItem",numitem);
					
					List rpta= ratIpDao.listByParameterMap(params);
					if(rpta!=null && rpta.size()>0) {
						for (int i = 0; i < rpta.size(); i++) {
                              RatIp ri = new RatIp();
                              ri=(RatIp)rpta.get(i);
                              //verificar que la unidad de medida del item insumo (codtipoequi), coincida con el unimed de la tabla rat_ip
							  if (!ri.getUNIMED().trim().equals(codtipoequi.trim())){
								  result.add(	getErrorMap("30006", "LA UNIDAD DE MEDIDA EQUIVALENTE DIFIERE DE LA UNIDAD DE MEDIDA DEL ITEM EN EL CIP"));
							  }
                              //verificar que la partida arancelaria declaradada es numpartnandi, coincida con el campo partida de la tabla rat_ip
							  if (!ri.getPARTIDA().equals(datoSerieActual.getNumpartnandi())){
								  result.add(	getErrorMap("00403", "PARTIDA NO CORRESPONDE PARA ESE ITEM A LA DECLARADA EN EL CIP"));
							  }
						}
						
					}else{
						result.add(	getErrorMap("00401", "NRO DE ITEM INVALIDO NO SE ENCUENTRA EN EL CIP"));
					}
					
				}
			}
		}
		
		return result;	
	}
		
    /**Valida que el tipo de unidad de medida del item insumo declarado coincida con el
     * tipo de unidad del item insumo registrado en el CIP (campo unimed de la tabla
     * rat_ip para el tipo_ip =1 para la partida)
 	 * @param dua
	 * @return List de errores
	 */
	public List<Map<String, String>> validarCantEquivalente(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();	
		BigDecimal tmpCntPesoNeto = new BigDecimal(0);
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
					DatoProducto product=datoSerieActual.getProducto();
					String codtipoequi=product!=null?product.getCodtipoequi():null;
					BigDecimal cntunimedidaequi=product!=null?product.getCntunimedidaequi():null;


					if ( "KG".equals(codtipoequi)){
						if (!SunatNumberUtils.isEqual(datoSerieActual.getCntpesoneto(), cntunimedidaequi) )
							result.add(	getErrorMap("30003", "LA UNIDAD COMERCIAL ES KG  LA CANTIDAD COMERCIAL DEBERIA SER IGUAL AL PESO NETO"));
						
					}else if(  "KG3".equals(codtipoequi) ){
						tmpCntPesoNeto=datoSerieActual.getCntpesoneto();
						tmpCntPesoNeto=tmpCntPesoNeto.divide(new BigDecimal(1000));
						
						if (!SunatNumberUtils.isEqual(tmpCntPesoNeto, cntunimedidaequi) )
							result.add(	getErrorMap("30004", "LA UNIDAD EQUIVALENTE ES KG3 LA CANTIDAD EQUIVALENTE DEBERIA SER IGUAL AL PESO NETO ENTRE 1000"));
						
					}else if( "KG6".equals(codtipoequi) ){
						tmpCntPesoNeto=datoSerieActual.getCntpesoneto();
						tmpCntPesoNeto=tmpCntPesoNeto.divide(new BigDecimal(1000000));
						if (!SunatNumberUtils.isEqual(tmpCntPesoNeto, cntunimedidaequi))
							result.add(	getErrorMap("30005", "LA UNIDAD EQUIVALENTE ES KG6 LA CANTIDAD EQUIVALENTE DEBERIA SER IGUAL AL PESO NETO ENTRE 1000000"));
					}
				}
			}
			
			
		}


		return result;	
	}
	
    /**Si el tipo de unidad de medida de las unidades fisicas es igual al 
     * tipo de unidad equivalente, entonces la cantidad de unidades fisicas debe ser igual
     *  a la cantidad de unidades equivalentes
     *  KIB: El emtodo se saco del orquestador porque ya exits en las valdiaciones del formato A
 	 * @param dua
	 * @return List de errores
	 */
	public List<Map<String,String>> validarCantEquivalenteFis(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();	
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
					DatoProducto product=datoSerieActual.getProducto();
					String codtipoequi=product!=null?product.getCodtipoequi():null;
					BigDecimal cntunimedidaequi=product!=null?product.getCntunimedidaequi():null;
					
					if(datoSerieActual.getCodunifis().equals(codtipoequi)){
						if (!SunatNumberUtils.isEqual(datoSerieActual.getCntunifis(), cntunimedidaequi) )
							result.add(	getErrorMap("30002", "UNIDAD DE MEDIDA EQUIVALENTE ES IGUAL A LA UNIDAD DE MEDIDA FISICA,ENTONCES LAS CANTIDADES DEBEN SER IGUALES"));
					 }
				   }
				}
		}
		
		return result;		
		
	}
	
    /*****Si se trata de la modalidad 2, se valida que entre la 
     * fecha de inicio de la feria y la fecha de numeraci�n de la dua no sea mayor a 60 d�as calendarios,
     * se valida que la fecha de numeraci�n no sea mayor a la fecha fin de la feria.
     * 
     *  Si se trata de la modalidad 7, se valida que entre la 
     *  fecha fin de la feria y la fecha de numeraci�n de la dua no sea mayor a 120 d�as calendarios
     *  Bug2370: sis e envia modalidad 2002 o 2007 se debe de obligatoriamente enviar el codferia.
 	 * @param dua
	 * @return List de errores
	 */
	   @SuppressWarnings("unchecked")
	public Map<String, String> Validarplazoferia(DUA dua ) {	
		  
		Date fechaActual = new Date();
		Date fechIniFeriSubt= new Date();
		Date fechFinFeriaAdd= new Date();
		Date fechFinFer=new Date();
		Map params = new HashMap();
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
	 

	 if (! SunatStringUtils.isEmpty( dua.getCodferia() ) ){    	// verificar que el codigo de feria llegue con algun dato
		 FeriasDAOService feriasDAOService = (FeriasDAOService) fabricaDeServicios.getService("Ayuda.feriasService"); 
	    params.put("CODIGO",dua.getCodferia());	    
//	    List list= feriasDao.findByParams(params);
	    List list= feriasDAOService.findByParams(params);
	      if(list!=null && list.size()>0){
	    	  Map dataFeria =(Map)list.get(0);
	    	
    	 
	    	  Integer fechIniFeria=Integer.valueOf(dataFeria.get("FINICIO").toString());
	    	  Integer fechFinFeria=Integer.valueOf(dataFeria.get("FFIN").toString());
	    	  	  
            if(fechIniFeria>0 && fechFinFeria>0) {	    	  
	    	  fechIniFeriSubt=SunatDateUtils.addDay(SunatDateUtils.getDateFromInteger(fechIniFeria), -60);
	    	  fechFinFeriaAdd=SunatDateUtils.addDay(SunatDateUtils.getDateFromInteger(fechFinFeria), 120);
	    	  fechFinFer=SunatDateUtils.getDateFromInteger(fechFinFeria);
	    	  
	    	  if (! SunatStringUtils.isEmpty( dua.getCodtipoperacion() ) ){
	    	  if (dua.getCodregimen().equals("20")&& dua.getCodtipoperacion().equals(dua.getCodregimen().concat("02"))){
	 	    	  if (SunatDateUtils.getIntegerFromDate(fechIniFeriSubt)>SunatDateUtils.getIntegerFromDate(fechaActual) || SunatDateUtils.getIntegerFromDate(fechaActual) >SunatDateUtils.getIntegerFromDate(fechFinFer)){
	 	    		 resultadoError=getErrorMap("00511", "CODIGO DE FERIA FUERA DE VIGENCIA" );
	 	    	 }
	 	       }
	    	  if (dua.getCodregimen().equals("20")&& dua.getCodtipoperacion().equals(dua.getCodregimen().concat("07"))){
		 	    	 if (SunatDateUtils.getIntegerFromDate(fechaActual) >SunatDateUtils.getIntegerFromDate(fechFinFeriaAdd)){
		 	    		resultadoError=getErrorMap("00512", "CODIGO DE FERIA DE LA IMPORTACION TEMPORAL PRECEDENTE NO VIGENTE" );
		 	    	 }
		 	   }
	    	  }
            }
	      }else{
	    	  resultadoError=getErrorMap("00501", "CODIGO DE FERIA NO EXISTE,  TRANSMITIO: ".concat(dua.getCodferia()) );
	      }
	 }else{
		 if (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("02")) || dua.getCodtipoperacion().equals(dua.getCodregimen().concat("07"))){
			 resultadoError=getErrorMap("00501", "CODIGO DE FERIA NO EXISTE ");
		 }
	 }
	    return resultadoError;
	}
		
    /**Se valida que el porcentaje de merma no sea mayor a 100
	 * @param dua
	 * @return List de errores
	 */
	/*public List<Map<String, String>> validarMerma(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();	
		BigDecimal maxMerma= new BigDecimal(100);
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getProducto()!=null){
					if(datoSerieActual.getProducto().getPormerma().doubleValue() >= maxMerma.doubleValue()){
						result.add(	catalogoHelper.getErrorMap("622", "PORCENTAJE DE MERMA DE MATERIAL DE EMBALAJE INVALIDO"));
					 }
				   }
				}
		}
		
		return result;		
		
	}*/
    /**Regimen de admision temporal para reexportacion en el mismo estado, para el tipo de accesorio =3,
     * partes y repuestos
	 * @param dua
	 * @return List de errores 
	 */
	 @SuppressWarnings("unchecked")
public List<Map<String, String>> validarRegimenPrecedente(DUA dua ) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		Date fechaActual= new Date();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		boolean tieneRegPre20=false;
		boolean tieneTipoOpera02=false;
		
		if(declaracionTieneDatoSeries==true){
		 if (! SunatStringUtils.isEmpty( dua.getCodtipoperacion() ) ){
			if (dua.getCodregimen().equals("20")&& (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("03")) || dua.getCodtipoperacion().equals(dua.getCodregimen().concat("07")))  ){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getListRegPrecedencia()!=null){
					   tieneRegPre20=false;
					   tieneTipoOpera02=false;
					
					for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
						tieneRegPre20=false;
						   tieneTipoOpera02=false;
					
						 Map params = new HashMap();
					     params.put("codigoAduana",datoRegPreActual.getCodaduapre());
					     if (!SunatStringUtils.isEmptyTrim(datoRegPreActual.getAnndeclpre()))
					    	 params.put("annoPresentacion",datoRegPreActual.getAnndeclpre().substring(0, 4));// catalogo de ferias
					         params.put("codigoRegimen",datoRegPreActual.getCodregipre());
					     
					     Integer numDeclPre=SunatNumberUtils.toInteger(datoRegPreActual.getNumdeclpre());
					     params.put("numeroDeclaracion",numDeclPre);
					     if ("20".equals(datoRegPreActual.getCodregipre()))
					    	 tieneRegPre20=true;
					     
					     DUA duaPrecedente=new DUA();
					     CabDeclaraDAO cabDeclaracionDao =(CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
					     duaPrecedente=cabDeclaracionDao.findDUAByKeyMap(params);
					     
					     if (duaPrecedente!=null){
					     if (tieneRegPre20 && dua.getCodregimen().concat("02").equals(duaPrecedente.getCodtipoperacion()))
					    	 tieneTipoOpera02=true;
					     //bug2353 Y BUG2339
					     if (dua.getCodregimen().equals("20")&& dua.getCodtipoperacion().equals(dua.getCodregimen().concat("07"))){
					    	 //BUG2339, si la fecha de vencimiento que tx y la fecha de vecimiento del regimen precedente en BD son difernte error
					    	 if (!SunatDateUtils.isEqualTo(datoRegPreActual.getFecvencpre(),duaPrecedente.getFecfinacoregimen())){
							    	
						    	 result.add(getErrorMap("30448", new Object[]{datoSerieActual.getNumserie(),datoRegPreActual.getAnndeclpre().substring(0, 4).concat("-").concat(datoRegPreActual.getCodregipre()).concat("-").concat(datoRegPreActual.getNumdeclpre())}));
						     }
					    	//BUG 2353LA FEHCHA DE AUTORIZACIONDE LEVANTE DEBE DE ESTAR LLENA, si es vacia error
					    	 if (datoRegPreActual.getFecvencpre().toString().equals("0001-01-01 00:00:00.0")){
					    		 result.add(getErrorMap("30449", new Object[]{datoSerieActual.getNumserie(),datoRegPreActual.getAnndeclpre().substring(0, 4).concat("-").concat(datoRegPreActual.getCodregipre()).concat("-").concat(datoRegPreActual.getNumdeclpre())}));
					    	 }
					     
					     }
					    
					     
					     
					     if (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("03"))){

					     if (duaPrecedente!=null)
					    	 params.put("numCorredoc",duaPrecedente.getNumcorredoc());
					     /*CabAdiAdmTem tmp = new CabAdiAdmTem();
					     tmp=cabAdjAtpaDao.selectByPrimaryKey(params);// precededente
					     */
					     if (duaPrecedente!=null){
					    	 //antes era >=
					     if (SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen())>SunatDateUtils.getIntegerFromDate(duaPrecedente.getFecfinacoregimen())){
					    	result.add(	getErrorMap("30009", "TIPO_OPERACION=03, FECHA VENCIM. NO DEBE SER MAYOR A FECHA VENCIM. DE DUA PRECEDENTE"));
					     }
					    //VERIFICAR> se debe de validar que sean del mismo beneficiario la dua actual con la precedente
					    // declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()//beneficiario actual
					     
					     if (SunatDateUtils.getIntegerFromDate(duaPrecedente.getFecfinacoregimen())<SunatDateUtils.getIntegerFromDate(fechaActual)){
					    	result.add(	getErrorMap("00136", "REG.PRECEDENCIA VENCIDO"));
					     }
					     
					     if (duaPrecedente.getCodtipoperacion().equals(dua.getCodregimen().concat("02")))
					    	 result.add(	getErrorMap("00510", "IMPORTACION TEMPORAL PRECEDENTE NO ES DE FERIA"));
					     }else{
					    	 result.add(	getErrorMap("00502", "DECLARACION ENVIADA, NO EXISTE"));
					     }
					     }
					   
					}
					//verificar que al menos exista un 20
					if (!tieneRegPre20)
							result.add(	getErrorMap("30385",new Object[]{datoSerieActual.getNumserie()}));
					if (tieneRegPre20 && !tieneTipoOpera02)
						result.add(	getErrorMap("30360",new Object[]{datoSerieActual.getNumserie()}));

					
				 }
			}
		  }
		 }
		}
		}
			    
		
		
		return result;
	}
	/*****
	 * Metodo para validar la Operacion de Partida
	 * @param dua
	 * @return List de errores
	 */
	public List<Map<String, String>>ValidarOperacionPartida(DUA dua){
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		Date fechaActual = new Date();
		if(declaracionTieneDatoSeries){
			if (! SunatStringUtils.isEmpty( dua.getCodtipoperacion() ) ){
			if (dua.getCodtipoperacion().equals(dua.getCodregimen().concat("08"))){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				Map params = new HashMap();
				params.put("tipo_uso","NAV" );
				params.put("cnan", datoSerieActual.getNumpartnandi());
				params.put("ffinvig",SunatDateUtils.getIntegerFromDate(fechaActual) );
				params.put("fechaVigencia",SunatDateUtils.getIntegerFromDate(fechaActual) );
//				List list=cabRefPartidasDao.getCatRefPartidas(params);
				params.put("ayudaID", "CatRefpartidas");//pase PAS20181U220200016 esantana
				List list=((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCatRefPartidas(params);
				if (list==null || list.size()==0){
					result.add(	getErrorMap("30008", "PARTIDA ARANCELARIA NO CORRESPONDE A ESE TIPO DE OPERACION"));
				}
			}
		}
		}
		}
	
		return result;
	}
	/**
	 * Metodo para validar si el codigo de modalidad es igual a 01 (urgente) y el indicador de socorro esta lleno, se rechaza con codigo de error XXX.
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> ValidarModalidadSocorro(DUA dua){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
      if (dua.getCodregimen().equals("21")){
    	  if (! SunatStringUtils.isEmpty( dua.getIndSocorro()) ) {
  			resultadoError= getErrorMap("30314", "NO APLICA LA MODALIDAD SOCORRO PARA EL REGIMEN 21");
  		}
      }
      return resultadoError;
	}	
	/**
	 * 
	 * si es tipo de operaci�n 08 o 02 no es obligatorio el dato  de ruc anexo para el fin ubicaci�n
	 * para el reg 20, si la operacion s 02 no debe de enviar cod local anexo, si la operacion es diferente 02 debe de obligadamente enviar cod local anexo
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> ValidarUbicacionOperacion(DUA dua){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
      if (dua.getCodregimen().equals("20")){
    	  if (!dua.getCodtipoperacion().equals(dua.getCodregimen().concat("02")) && !dua.getCodtipoperacion().equals(dua.getCodregimen().concat("08"))){
			// verificar que envi obligatoriamente los DatosRucAnexoUbicacion
    		 if ( SunatStringUtils.isEmpty( dua.getRucAnexoUbicacion().getNumeroDocumentoIdentidad())) {
    		  resultadoError= getErrorMap("30351", "ES OBLIGATORIO QUE SE ENVIE EL RUC DEL LOCAL ANEXO");
    		 }
    		 
		}
      }
      return resultadoError;
	}
	
	/**
	 *
	 * Nuevas Validaciones proporcinadas por Elsa.
	 * 12/02/2010
	 * Metodo para Reg 20 y 21, si la modalidad es 00 validar que la fecha de numeracion no sea mayor a la fecha de termino de descarga mas 30 dia
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> ValidarModalidadFechaNumeracionTermino(DUA dua,Date fechaReferencia){
		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");
		Map<String, String> resultadoError = new HashMap<String, String>();
		
		for (DatoSerie datoSerieActual : dua.getListSeries()) {
			if (datoSerieActual.getListRegPrecedencia().isEmpty()){
		DatoManifiesto manif=dua.getManifiesto();
		Date fectermino=manif!=null?manif.getFectermino():null;
				if (dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_RME) || dua.getCodregimen().equals(ConstantesDataCatalogo.REG_ADM_TEMP_PA)){
					if (dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) ){
						DataCatalogo catPlazoValidacionNuevaLga = ((CatalogoAyudaService) fabricaDeServicios
								.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
								ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
								ConstantesDataCatalogo.COD_PLAZO_VALIDACION_NUEVA_LGA, fechaReferencia);
						
						if(catPlazoValidacionNuevaLga == null){
							if (!valModalidadService.correspondeModalidadDiferida(fechaReferencia, fectermino)){
								DataCatalogo catPlazoModalidadDiferida = ((CatalogoAyudaService) fabricaDeServicios
										.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(
										ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
										ConstantesDataCatalogo.COD_PLAZO_MODALIDAD_DIFERIDA, fechaReferencia);
								resultadoError = getErrorMap("30365", new String [] {catPlazoModalidadDiferida.getDesCorta()});
    		 }
						}
    	  }
      }
			}
		}
      return resultadoError;
	}
	/**
	 *
	 * Nuevas Validaciones proporcinadas por Elsa.
	 * 12/02/2010
	 * Metodo para Reg 21, validar que la fechaacoregimen no deba de s mayor que 24 meses de la fecha de numeracion.
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> ValidarAcoRegimenNumeracion(DUA dua,Date fechaReferencia){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		
		Integer fechfinacoregimen=SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen());
		Date fechReferencia=new Date();
		// fecfinacoregimen mas 24 meses
		fechReferencia=SunatDateUtils.addMonth(fechaReferencia, 24);
		Integer fechNumeracion=SunatDateUtils.getIntegerFromDate(fechReferencia);
			
	      if (dua.getCodregimen().equals("21") ){
	    	  
	    		 if (fechfinacoregimen>fechNumeracion) {
	    			 resultadoError= getErrorMap("30366","LA FECHA FIN DE ACOGIMIENTO DEL REGIMEN ES MAYOR A LA FECHA DE NUMERACION MAS 24 MESES ");
	    		 }
	    	  
	      }
      return resultadoError;
	}
	/**
	 * 
	 * Nuevas Validaciones proporcinadas por Elsa.
	 * 12/02/2010
	 * Metodo para Reg 20, validar que el tipo operacion se busca en la tabla pit_tipo_plazos y verificar que el campo activo ='S'
	 * sino rechazar (creo el error) para el tipo operaci�n 5 y 10 no se valida los plazos para los demas se valida que la 
	 * fecha de vencimiento de regimen (fecacoregimen) no pase de la fecha de numeacion mas ese plazo
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> ValidarTipoOperacionPlazos(DUA dua,Date fechaReferencia){
		PitTipoPlazosDAO pitTipoPlazosDao = (PitTipoPlazosDAO) fabricaDeServicios.getService("pitTipoPlazosDAO");
		Map<String, String> resultadoError = new HashMap<String, String>();
		Integer intFechfinacoregimen=SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen());
		Date fechReferencia=new Date();
		
		
	 if ( !dua.getCodtipoperacion().equals(dua.getCodregimen().concat("05")) && !dua.getCodtipoperacion().equals(dua.getCodregimen().concat("10")) ){
		PitTipoPlazos plazo = pitTipoPlazosDao.selectAnoMesByTipoOperacionDespa((String)  dua.getCodtipoperacion());
		
			if (plazo != null) {
				short meses = 0;
				if (plazo.getAno() != 0) {
					meses = new Short("" + new Short("12").shortValue() * plazo.getAno().shortValue()).shortValue();
				} else if (plazo.getMes() != 0) {
					meses = plazo.getMes().shortValue();
				}
				fechReferencia=SunatDateUtils.addMonth(fechaReferencia, meses);
				Integer intFechReferencia=SunatDateUtils.getIntegerFromDate(fechReferencia);
				if (intFechfinacoregimen > intFechReferencia){
					resultadoError= getErrorMap("30367","LA FECHA DE ACOGIMIENTO DEL REGIMEN ES MAYOR A LA FECHA DE NUMERACION MAS EL PLAZO ESTABLECIDO PARA LA OPERACION"); 
				}
					
			}else{
				resultadoError= getErrorMap("30368","NO EXISTE LA OPERACION EN LA TABLA DE PLAZOS"); 
			}
			
		}
		
      return resultadoError;
	}
	/**
	 * 
	 * Nuevas Validaciones proporcinadas por Betty.
	 * 10/05/2010
	 * Para el regimen 20 y 21
	 * La fecha de vencimiento del regimen siempre debe ser mayor a la fecha de numeraci�n para todos los casos.
	 * @param dua
	 * @return List de errores
	 */
	public Map<String, String> validarFechaVencimientoRegimen(DUA dua,Date fechaReferencia){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
	    // Solucion del bug 1852
		if (! (SunatDateUtils.getIntegerFromDate(dua.getFecfinacoregimen())>SunatDateUtils.getIntegerFromDate(fechaReferencia))){// Si no es mayor a la fecha de numeracion
			resultadoError= getErrorMap("30442", "FECHA DE VENCIMIENTO DEL REGIMEN MAYOR A LA FECHA DE TRANSMISION ");
		 }
		
		return resultadoError;
	}
	

	/**
	 * Metodo interno para la busqueda de catalogos
	 * @param codCatalago
	 * @param codDataCatalogo
	 * @return boolean
	 */
    @SuppressWarnings("unchecked")
	private boolean esDataCatalogo(String codCatalago,String codDataCatalogo){
	     
	     Map params = new HashMap();
	      params.put("type","Ayuda");
	         params.put("catalogoID",codCatalago);
	         params.put("codElemento",codDataCatalogo);
	         params.put("fechaVigencia",new Date());
	        
	         
	     //List list= dataCatalogoDao.findByMap(params);
	     
	         List list = null;
	     params.put("ayudaID", "DataCatalogo");
	     list= (List)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findByMap(params);
	     
	     
	     
	     if(list!=null && list.size()>0)
	      return true;
	     else return false;
	    }
/*
	public DataCatalogoDAO getDataCatalogoDao() {
		return dataCatalogoDao;
	}

	public void setDataCatalogoDao(DataCatalogoDAO dataCatalogoDao) {
		this.dataCatalogoDao = dataCatalogoDao;
	}

	public CTUsuariosDAO getCtUsuariosDao() {
		return ctUsuariosDao;
	}

	public void setCtUsuariosDao(CTUsuariosDAO ctUsuariosDao) {
		this.ctUsuariosDao = ctUsuariosDao;
	}

	public RatIpDAO getRatIpDao() {
		return ratIpDao;
	}

	public void setRatIpDao(RatIpDAO ratIpDao) {
		this.ratIpDao = ratIpDao;
	}

	public PagarantiaDAO getPagarantiaDao() {
		return pagarantiaDao;
	}

	public void setPagarantiaDao(PagarantiaDAO pagarantiaDao) {
		this.pagarantiaDao = pagarantiaDao;
	}

	public CabDeclaraDAO getCabDeclaracionDao() {
		return cabDeclaracionDao;
	}

	public void setCabDeclaracionDao(CabDeclaraDAO cabDeclaracionDao) {
		this.cabDeclaracionDao = cabDeclaracionDao;
	}



	public PitTipoPlazosDAO getPitTipoPlazosDao() {
		return pitTipoPlazosDao;
	}

	public void setPitTipoPlazosDao(PitTipoPlazosDAO pitTipoPlazosDao) {
		this.pitTipoPlazosDao = pitTipoPlazosDao;
	}

	public ParticipanteDocDAO getParticipanteDocDao() {
		return participanteDocDao;
	}

	public void setParticipanteDocDao(ParticipanteDocDAO participanteDocDao) {
		this.participanteDocDao = participanteDocDao;
	}

	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}

	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}

	  public AyudaService getAyudaService() {
			return ayudaService;
		}

		public void setAyudaService(AyudaService ayudaService) {
			this.ayudaService = ayudaService;
		}

		public FeriasDAOService getFeriasDAOService() {
			return feriasDAOService;
		}

		public void setFeriasDAOService(FeriasDAOService feriasDAOService) {
			this.feriasDAOService = feriasDAOService;
		}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}	
    */
}
