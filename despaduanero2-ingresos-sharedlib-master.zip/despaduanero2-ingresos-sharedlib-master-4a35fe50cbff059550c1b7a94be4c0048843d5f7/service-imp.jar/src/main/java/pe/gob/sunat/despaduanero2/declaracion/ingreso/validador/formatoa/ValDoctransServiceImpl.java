/*
 * Clase que define el servicio de validaciones de los documentos de transporte.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;

/**
 * The Class ValDoctrans. Clase que define el servicio de validaciones de los documentos de transporte.
 */
public class ValDoctransServiceImpl extends ValDuaAbstract implements ValDoctrans{
	
	//private FabricaDeServicios fabricaDeServicios;
	/**
	 * Valida el C�digo de puerto/aeropuerto embarque.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codpuerto String. C�digo de puerto/aeropuerto embarque.
	 * @return Map
	 */
	public Map<String, String> codpuerto(String codpuerto){
             boolean tieneError = false;//PAS20155E220000396
             if (!SunatStringUtils.isEmptyTrim(codpuerto)){
                    //return FormatoAServiceImpl.getInstance().getCatalogoValidacionService().isPuertoVigente(codpuerto)?new HashMap<String,String>():getDUAError("30033", "");
            	 /*Inicio de cambios PAS20155E220000396*/
            	 	CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
                    List<Map<String, String>> listvalPto = catalogoValidaService.validarPuerto(codpuerto);
                    if (CollectionUtils.isEmpty(listvalPto)){
                           tieneError = false;
                    } else{
                           if (listvalPto.get(0).get("codError").equals(Constantes.ERR_PUERTO_NO_VIGENTE)){
                                  tieneError = false;
                           } else{
                                  tieneError = true;
                           }                                 
                    }
                    //return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarPuerto(codpuerto))?new HashMap<String,String>():getDUAError("30033", "");
             }else
                    tieneError = true;
             /*Fin de cambios PAS20155E220000396*/
             return tieneError ? getDUAError("30033", ""):new HashMap<String,String>();
       }

	/**
	 * 
	 * @param codpuerto
	 * @return
	 */
	public Map<String, String> codpuertoorg(String codpuertoorg){
		if (!SunatStringUtils.isEmptyTrim(codpuertoorg)){
			//return FormatoAServiceImpl.getInstance().getCatalogoValidacionService().isPuertoVigente(codpuertoorg)?new HashMap<String,String>():getDUAError("30891", new String[]{codpuertoorg});
                        return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarPuerto(codpuertoorg))?new HashMap<String,String>():getDUAError("30891", new String[]{codpuertoorg});  
		}
		return new HashMap<String,String>();
	}

	/**
	 * Valida la Fecha de embarque en origen.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecembarque Date. Fecha de embarque en origen
	 * @return Map
	 */
	public Map<String, String> fecembarque(Date fecembarque){
		return fecembarque!=null?new HashMap<String,String>():getDUAError("30034","");
	}

	/**
	 * Valida el C�digo del tipo de documento de transporte.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipodoctrans String. C�digo del tipo de documento de transporte.
	 * @return Map
	 */
	public Map<String, String> codtipodoctrans(String codtipodoctrans){
		boolean validaCatalogo= CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("TP", codtipodoctrans, SunatDateUtils.getCurrentDate()));
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("TP", codtipodoctrans))
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30035","Error catalogo codtipodoctrans");
			//return FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMap("","Error catalogo codtipodoctrans");
	}

	//RN 147 - lMVR -Complemento de la Dua parte II
	@ServicioAnnot(tipo="V",codServicio=2518, descServicio="validar Envio Directo Consolidado")
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2518,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> validarEnvioDirectoConsolidado(Declaracion declaracion){
		
	DUA dua=declaracion.getDua(); //codtiplugarrecep
	String modalidadDua = dua.getCodmodalidad();
	String codtiplugarrecep  = dua.getCodtiplugarrecep();
	if(MODALIDAD_ANTICIPADA.equals(modalidadDua))
		if(!SunatStringUtils.isEmpty(codtiplugarrecep)){
			if(codtiplugarrecep.equals("04")){
				for(DatoDocTransporte docTransp:dua.getListDocTransporte()){
					String Codtipodoctran= docTransp.getCodtipodoctrans();
						if (Codtipodoctran.equals("2")){
							return getDUAError("30678","DESPACHO ANTICIPADO CON ZPAE NO PROCEDE PARA CARGA CONSOLIDADA");
							}
					}
			}
		}

		return new HashMap<String,String>();
	}
		
	/**
	 * Valida el Documento de transporte.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numdoctransporte String. Numero de Documento de transporte.
	 * @return Map
	 */
	public Map<String, String> numdoctransporte(String numdoctransporte){

		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;
		if(esVigenteRIN31) {
			String numdoctransporteH = numdoctransporte != null ? numdoctransporte : "";
			if (SunatStringUtils.isEmptyTrim(numdoctransporteH)) return new HashMap<String, String>();
		}

		return !SunatStringUtils.isEmptyTrim(numdoctransporte)?new HashMap<String,String>():getDUAError("08001","");
	}

	/**
	 * Valida el Documento de transporte master.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numdocmaster String. Numero de Documento de transporte master.  
	 * @return Map
	 */
	public Map<String, String> numdocmaster(String numdocmaster){
		
		if(  SunatStringUtils.isEmptyTrim(numdocmaster) ) return new HashMap<String,String>();
	
		return !SunatStringUtils.isEmptyTrim(numdocmaster)?new HashMap<String,String>():getDUAError("08001","");
	}

	/**
	 * Valida la Fecha de embarque en origen.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No es mandatorio en ningun caso
	 * @param fecembarqueorg Date. Fecha de embarque en origen.
	 * @return Map
	 */
	public Map<String, String> fecembarqueorg(Date fecembarqueorg){
		// no es mandatorio en ningun caso
		//return fecembarqueorg!=null?new HashMap<String,String>():getDUAError("30036","");
		return new HashMap<String,String>();
	}
	
	/**
	 * Valida el Numero de secuencia de documento de transporte
	 * 
	 * @param numsecdoctrans Integer. Numero de secuencia de documento de transporte.
	 * @return el mapa de errores
	 */
	public Map<String,String> numsecdoctrans(Integer numsecdoctrans){
		return numsecdoctrans!=null && numsecdoctrans>0?new HashMap<String,String>():getDUAError("30307","Error numsecdoctrans");
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
