package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadispuesta;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercanciaDispuesta;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MercanciaDispuestaDAO;

/**
 * @author rpumacayo
 *
 */
public class MercanciaDispuestaServiceImpl extends IngresoAbstractServiceImpl implements MercanciaDispuestaService {

	public MercanciaDispuestaServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadispuesta.MercanciaDispuestaService#validarMercanciaDispuesta(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie, java.lang.String)
	 */
	//Pase105 - Se comenta porfa se probara en la parte II rin07
/*	@Override
	public List<Map<String, String>> validarMercanciaDispuesta(
			Declaracion declaracion) {

		List<Map<String, String>> listErrores = new ArrayList<Map<String,String>>();

		catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaServicePrincipal");
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo());
		
		DUA dua = declaracion.getDua();
		
		for (DatoSerie serie : dua.getListSeries()) {
			params.put("NUM_SECSERIE", serie.getNumserie());
			if (tieneMercanciaDispuesta(params)) {
				listErrores.add(catalogoAyudaService.getError("30803", new String[] {serie.getNumserie().toString()}) );
			}
		}		

		return listErrores;
	}
*/
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadispuesta.MercanciaDispuestaService#tieneMercanciaDispuesta(java.util.Map)
	 */
	@Override
	public boolean tieneMercanciaDispuesta(Map declaracion) {

		List<DatoMercanciaDispuesta> listadoMercanciaDispuesta = listarMercanciaDispuesta(declaracion);
		if (listadoMercanciaDispuesta.size()>0) {
			return true;	
		}
		return false;
	}

	/**
    * {@inheritDoc}
    */
	@Override
	public List<DatoMercanciaDispuesta> listarMercanciaDispuesta(Map params) {		
		MercanciaDispuestaDAO mercanciaDispuestaDAO = fabricaDeServicios.getService("mercanciaDispuestaDAO");
		
    	List<DatoMercanciaDispuesta> listadoMercanciaDispuesta=null;
    	listadoMercanciaDispuesta= mercanciaDispuestaDAO.select(params);
    	return listadoMercanciaDispuesta;
	     
	}
	

}
