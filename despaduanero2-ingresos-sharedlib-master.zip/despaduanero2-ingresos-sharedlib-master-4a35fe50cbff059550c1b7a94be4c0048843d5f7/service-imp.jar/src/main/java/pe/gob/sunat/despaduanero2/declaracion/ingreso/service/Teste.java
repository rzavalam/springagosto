package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Teste {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ClaseValidadoraTPI ctpi = new ClaseValidadoraTPI();
		ctpi.validar();
		
		
//		Validador obj = new Validador();
//		try {
//			Method method = obj.getClass().getMethod("validarTPI");
//			method.invoke(obj);
//			
//			obj.getClass().getMethod("validarTPI", String.class).invoke(obj, "sandro");
//		} catch (SecurityException e) {
//			e.printStackTrace();
//		} catch (NoSuchMethodException e) {
//			e.printStackTrace();
//		} catch (IllegalArgumentException e) {
//			e.printStackTrace();
//		} catch (IllegalAccessException e) {
//			e.printStackTrace();
//			
//		} catch (InvocationTargetException e) {
//			e.printStackTrace();
//		}
	}
	
	
	
	public List<String> catalogoServiciosXTpi(String tpi){
		List<String> catServices802 = new ArrayList<String>();
		catServices802.add("3332");
		catServices802.add("3333");
		catServices802.add("3334");
		
		List<String> catServices803 = new ArrayList<String>();
		catServices803.add("3332");
		catServices803.add("3335");
		catServices803.add("3336");
		if(tpi.equals("802")){
			return catServices802;
		}else if(tpi.equals("802")){
			return catServices803;			
		}
		return null;
	}
}

class ClaseValidadoraTPI{
	public void validar(){
		Teste teste = new Teste();
		List<String> catServices = teste.catalogoServiciosXTpi("802");
		for (String string : catServices) {
			System.out.println(string);
		}
	}
}

class Validador {
	//3332
	public List<Map<String, Object>> validarTPI82() {
		System.out.println("validarTPI Uinque");
		return null;
	}

	//3333
	public Map<String, Object> validarTPI82(String a, String b) {
		System.out.println("validarTPI a:" + a + " b:" + b);
		return null;
	}
}

class Validador2 {
	//3334
	public Map<String, Object> validarTPI83() {
		System.out.println("validarTPI Uinque");
		return null;
	}

	//3335
	public Map<String, Object> validarTPI83(String a, String b) {
		System.out.println("validarTPI a:" + a + " b:" + b);
		return null;
	}
	
	//3336
	public Map<String, Object> validarTPI83(String a, String b, Integer c) {
		System.out.println("validarTPI a:" + a + " b:" + b);
		return null;
	}
}


