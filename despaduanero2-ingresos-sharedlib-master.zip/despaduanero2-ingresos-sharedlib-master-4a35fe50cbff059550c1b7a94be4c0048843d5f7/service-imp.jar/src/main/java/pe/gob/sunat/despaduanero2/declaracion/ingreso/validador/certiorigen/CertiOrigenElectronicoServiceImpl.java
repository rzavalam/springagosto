package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.estrategico2.aduanero.vuce.model.acuerdo.DocCertificadoOrigen;
import pe.gob.sunat.estrategico2.aduanero.vuce.util.Constantes;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.ArchivoAnexoDocControlMR;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class CertiOrigenElectronicoServiceImpl  extends ValDuaAbstract implements CertiOrigenElectronicoService {
	
	private final String URL_VUCE_CERT_ELECT = "http://api.sunat.peru/v1/estrategico/vuce/e/certificadoorigenelectronico";
	//private final String URL_VUCE_CERT_ELECT = "http://localhost:7001/ol-ad-aduanerovucews/certificadoorigenelectronico";
	
	
	/**
     * PAS20181U220200056: retorna el error si en la validacion del certificado electronico hubiera alguno
     * @param serie serie transmitida
     * @param variablesIngreso Variables de validacion de un determinado proceso
     * @param fechaReferencia fecha de numeracion
     * @return listError errores de validacion
     **/
	@ServicioAnnot(tipo = "V", codServicio = 3476, descServicio = "Validacion de certificado de origen electronico")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia = 3476, numSecEjec = 174, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String,String>>  validarCertificadoOrigenElectronico(DatoSerie serie,	Map<String, Object> variablesIngreso, Date fechaReferencia) {
		
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		Map<String,String> error=new HashMap<String,String>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		try {
			String numSerie = serie.getNumserie().toString();
			Integer tpi = serie.getCodconvinter()!=null?serie.getCodconvinter():0;
			String paisOrigen = serie.getCodpaisorige()!=null?serie.getCodpaisorige():""; 
			DUA dua = (DUA)serie.getPadre();
			
			Declaracion declaracion = serie.getPadre()!=null && serie.getPadre().getPadre()!=null?(Declaracion)serie.getPadre().getPadre():null;
			String codTransaccion = declaracion!=null?declaracion.getCodtipotrans():"";
			if (SunatStringUtils.isEmpty(codTransaccion)) {
				codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
			}
			
			String documentoConsignatario = dua.getDeclarante() == null ? "" : dua.getDeclarante().getNumeroDocumentoIdentidad();
			Elementos<DatoAutocertificacion> documentosCO = dua.getDatoCertificadoOrigen().getListAutocertificacion();
			Elementos<DatoSerieDocSoporte> elementosSoporte = serie.getListSerieDocSoporte();
			if(elementosSoporte!=null && elementosSoporte.size()>0 && documentosCO!=null && documentosCO.size()>0) {
				for(DatoSerieDocSoporte docxSerie :  elementosSoporte) {
					if("5".equals(docxSerie.getCodtipodocsoporte()) && tpi==0) {
						for(DatoAutocertificacion certif : documentosCO) {
							if(docxSerie.getNumiddocsoporte().equals(certif.getNumsecCO())) {
								if(Constantes.INDICADOR_CERT_ELECTRONICO.equals(certif.getIndElectronico())){
									error = catalogoAyudaService.getError("37197",new String[] {numSerie});//37197
									listError.add(error);
									return listError;			
								}
							}
						}						
					}
				}
			}			
			
			List<DatoAutocertificacion> listCertificadoOrigen = serie.getCertificadosOrigen();			
			   
			if(listCertificadoOrigen != null) {
				for(DatoAutocertificacion certificadoOrigen:listCertificadoOrigen){
					if(Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(certificadoOrigen.getIndElectronico())){
			            String numCertificado = certificadoOrigen.getNumdocumento();
			            if(!"0".equalsIgnoreCase(tpi.toString().trim()) && !"".equalsIgnoreCase(tpi.toString())) {//Por bug P_SNAA0004-17379 - PAS20181U220200056
			            	error = validarCatalogoAsociacionTlcPais(numSerie, numCertificado, tpi.toString(), paisOrigen, fechaReferencia);
			            }
			            
			            
			            if(!error.isEmpty())listError.add(error);
						
			            DocCertificadoOrigen  docCertificadoOrigen = new DocCertificadoOrigen();
			            if(listError!=null && CollectionUtils.isEmpty(listError)) {
			            	
			            	//buscamos el vuceco primero:
							try {
								
								docCertificadoOrigen = consultarCertificadoElectronico (numSerie, numCertificado);
								
							}catch (HttpClientErrorException e) {
								
								error = catalogoAyudaService.getError("37184",new String[] {numSerie, numCertificado});//VUCECO NO SE PUEDE DETERMINAR EXISTENCIA
								listError.add(error);
								return listError;
							}catch (Exception e) {
								error = catalogoAyudaService.getError("37184",new String[] {numSerie, numCertificado});//VUCECO  NO SE PUEDE DETERMINAR EXISTENCIA
								listError.add(error);
								return listError;
							}
							
							if(docCertificadoOrigen == null || (docCertificadoOrigen !=null && docCertificadoOrigen.getNumeroCertificadoOrigen()==null)) {
								error = catalogoAyudaService.getError("37175",new String[] {numSerie, numCertificado});//VUCECO NO SE ENCUENTRA EN EL REPOSITORIO SUNAT
								if(!error.isEmpty())listError.add(error);
								return listError;
							}
							
							//seguimos con las evaluaciones
							 if(listError!=null && CollectionUtils.isEmpty(listError)) {
								String indicadorUsoCertificado = docCertificadoOrigen.getIndicadorUsoCertificado()!=null?
																		docCertificadoOrigen.getIndicadorUsoCertificado().trim():" "; 
								String codigoPaisEntHabilitadora = docCertificadoOrigen.getCodigoPaisEntidadHabilitadora()!=null?
																		docCertificadoOrigen.getCodigoPaisEntidadHabilitadora().trim():" ";
								String numeroRegFiscal = docCertificadoOrigen.getNumeroRegistroFiscal()!=null?
										 								docCertificadoOrigen.getNumeroRegistroFiscal().trim(): " ";
								error = validarIndicadorAnulado(numSerie, indicadorUsoCertificado, numCertificado); 
								if(!error.isEmpty())listError.add(error);
								error = validarPaisOrigen(numSerie, paisOrigen, codigoPaisEntHabilitadora);
								if(!error.isEmpty())listError.add(error);
								error = validarDocumentoImportador(numSerie, documentoConsignatario, numeroRegFiscal);
								if(!error.isEmpty())listError.add(error);
									 
								if(!codTransaccion.isEmpty() && (codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) 
												|| codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION)) ){
									//Se pone esta validacion para los casos que un mismo certificado electronico esta asociado a varias series
									if(!(certificadoOrigen.getCodffco() !=null && certificadoOrigen.getCodffco().equalsIgnoreCase(""))) {
										error = validarDatosATransmitirse(certificadoOrigen, serie);
										if(!error.isEmpty())listError.add(error);	
										
									}
								}
								 if(listError!=null && CollectionUtils.isEmpty(listError)) {
									Date fechaEmisionCO = docCertificadoOrigen.getFechaEmision();
									String nombreCO = docCertificadoOrigen.getLstProductores().get(0) == null ? "" : docCertificadoOrigen.getLstProductores().get(0).getProductor().getRazonSocial();
									//Completando datos en el objeto cab_certiorigen.
									certificadoOrigen.setFecemision(fechaEmisionCO);
									certificadoOrigen.setNomproduc(nombreCO);
									certificadoOrigen.setCodtipoCO(ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE);//Tipo de certificado
									certificadoOrigen.setCodcriterioO(" ");
									certificadoOrigen.setCodffco(" ");		
								}
							}						  
						}
					}
				}
			}
	}catch(Exception e){
		  e.printStackTrace();
			throw new ServiceException(e, "se presento un error durante la ejecucion del servicio validarCertificadoOrigenElectronico");
	}
		
	  return listError;
	}	

	private Map<String, String> validarCatalogoAsociacionTlcPais(String numSerie, String numCertificado, String tpi, String paisOrigen, Date fechaReferencia){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> listError = new HashMap<String, String>();
		Map<String, Object> lstSubEntidades = catalogoAyudaService.getElementoAsoc(Constantes.CATALOGO_ASOCIACION_TLC_PAIS,tpi,paisOrigen,fechaReferencia);
		if(lstSubEntidades.isEmpty()) {
			//SERIE {0}: CERTIFICADO DE ORIGEN ELECTRONICO {1} NO SE ENCUENTRA HABILITADO PARA SU REMISION SEG�N CATALOGO PAIS ORIGEN Y ACUERDO COMERCIAL
			listError = catalogoAyudaService.getError("37180",new String[] {numSerie, numCertificado});
		}
		return listError;
	}	
	
	public DocCertificadoOrigen consultarCertificadoElectronico (String numSerie, String numCertificado) {
		String uriCertificadoDigital = URL_VUCE_CERT_ELECT + "?numcertificado=" + numCertificado;
		RestTemplate restTemplate = new RestTemplate();
		DocCertificadoOrigen docCertificadoOrigen = new DocCertificadoOrigen();
		try {
			docCertificadoOrigen = 	restTemplate.getForObject(uriCertificadoDigital, DocCertificadoOrigen.class);
		} catch (HttpClientErrorException e) {
			log.error("Error: " + e + " - No se pudo determinar la existencia del Certificado Electronico en el repositorio SUNAT:" + numCertificado);
			
		} catch (Exception e) {
			log.error("Error: " + e + " - No se pudo determinar la existencia del Certificado Electronico en el repositorio SUNAT:" +  numCertificado);			
		}
		
		return docCertificadoOrigen;
	}
		
	private Map<String, String> validarIndicadorAnulado(String numSerie, String indicadorUsoCertificado, String numCertificado){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> listError = new HashMap<String, String>();
		if(Constantes.INDICADOR_CO_ANULADO.equalsIgnoreCase(indicadorUsoCertificado)) {
			//SERIE {0}: EL CERTIFICADO DE ORIGEN ELECTRONICO {1} SE ENCUENTRA ANULADO
			listError = catalogoAyudaService.getError("37177",new String[] {numSerie, numCertificado});
		}
		return listError;
	}
	
	private Map<String, String> validarPaisOrigen(String numSerie, String paisOrigen, String codigoPaisEntHabilitadora){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> listError = new HashMap<String, String>();
		String nompais=paisOrigen;
		if(!paisOrigen.equalsIgnoreCase(codigoPaisEntHabilitadora)) {
			//SERIE {0}: EL PAIS DE ORIGEN DEL CERTIFICADO DE ORIGEN ELECTRONICO {1} NO CORRESPONDE AL PAIS DE ORIGEN REMITIDO
			 Map<String,Object> paisLocalizado = catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.CODIGO_TABLA_CATALOGO_PAISES_NUEVA_CODIFICACION, paisOrigen);
			if( !CollectionUtils.isEmpty(paisLocalizado)){
				nompais = paisLocalizado.get("des_datacat")!=null?paisLocalizado.get("des_datacat").toString():paisOrigen;
			}
			 
			listError = catalogoAyudaService.getError("37176",new String[] {numSerie, nompais});
		}
		return listError;
	}

	private Map<String, String> validarDocumentoImportador(String numSerie, String documentoConsignatario, String numeroRegFiscal){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> listError = new HashMap<String, String>();
		if(!documentoConsignatario.equalsIgnoreCase(numeroRegFiscal)) {
			//SERIE {0}: EL NUMERO DE IDENTIFICACION DEL IMPORTADOR {1} ES DISTINTO AL CONSIGNADO EN EL CERTIFICADO DE ORIGEN ELECTRONICO
			listError = catalogoAyudaService.getError("37178",new String[] {numSerie, documentoConsignatario});
		}
		return listError;
	}	
	
	private Map<String, String> validarDatosATransmitirse(DatoAutocertificacion certificadoOrigen, DatoSerie serie){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> listError = new HashMap<String, String>();
		String error37179 = ""; 
		Date fechaEmisionCertificadoOrigen = certificadoOrigen.getFecemision();
		if(fechaEmisionCertificadoOrigen != null)
			error37179 = error37179.concat(" FechaEmision: " + SunatDateUtils.getFormatDate(fechaEmisionCertificadoOrigen, "dd/MM/yyyy"));  
		String nombreEmpresaProductora = certificadoOrigen.getNomproduc() == null ? "" : certificadoOrigen.getNomproduc().trim();
		if(!nombreEmpresaProductora.equalsIgnoreCase(""))
			error37179 = error37179.concat(" NombreEmpresaProductora: " + nombreEmpresaProductora);
		String tipoCertificadoOrigen = certificadoOrigen.getCodtipoCO() == null ? "" : certificadoOrigen.getCodtipoCO().trim();
		if(!tipoCertificadoOrigen.equalsIgnoreCase(""))
			error37179 = error37179.concat(" TipoCertificado: " + tipoCertificadoOrigen);
		String criterioOrigenCertificadoOrigen = certificadoOrigen.getCodcriterioO() == null ? "" : certificadoOrigen.getCodcriterioO().trim();
		if(!criterioOrigenCertificadoOrigen.equalsIgnoreCase(""))
			error37179 = error37179.concat(" CriterioCertificado: " + criterioOrigenCertificadoOrigen);
		String registroFuncionarioCertificadoOrigen = certificadoOrigen.getCodffco() == null ? "" : certificadoOrigen.getCodffco().trim();
		if(!registroFuncionarioCertificadoOrigen.equalsIgnoreCase(""))
			error37179 = error37179.concat(" RegistroFuncionarioCertificado: " + registroFuncionarioCertificadoOrigen);
		if(!error37179.trim().isEmpty()) {
			//DATOS DE {0} NO DEBEN TRANSMITIRSE EN UN CERTIFICADO DE ORIGEN ELECTRONICO
			listError = catalogoAyudaService.getError("37179",new String[] {serie.getNumserie().toString(),error37179});
		}
		return listError;
	}
	
	public DocCertificadoOrigen traerCertificadoOrigen(String numCertificado) {
		String uriCertificadoDigital = URL_VUCE_CERT_ELECT  + "?numcertificado=" + numCertificado;
		RestTemplate restTemplate = new RestTemplate();
		DocCertificadoOrigen docCertificadoOrigen = new DocCertificadoOrigen(); 
		docCertificadoOrigen = 	restTemplate.getForObject(uriCertificadoDigital, DocCertificadoOrigen.class);
		return docCertificadoOrigen;
	}	
	
	public boolean esValidoCambiosDiligVUCECO(Date fechaReferencia){
		boolean esValido = false;
		final String COD_DATACATALOGO_HABILITACION_VUCECO = "0052";
		//Map<String, Object> mapValVigencia =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat("380", "0052",fechaReferencia);
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,COD_DATACATALOGO_HABILITACION_VUCECO,fechaReferencia);
		/*if (!CollectionUtils.isEmpty(listaVigencia)){
			esValido = true;
		}*/
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){
			return true;
		}
		return esValido;
	} 
	

	public ArchivoAnexoDocControlMR obtenerCertificadoOrigenPDF(String numCertificadoOrigen, String codigoPaisOrigen){

		String uri= "http://api.sunat.peru/v1/estrategico/vuce/e/" +
				"certificadoorigenelectronicoPdf?numCertificadoOrigen=" + numCertificadoOrigen +
				"&codigoPaisOrigen=" + codigoPaisOrigen;


		RestTemplate restTemplate = new RestTemplate();
		ArchivoAnexoDocControlMR archivoUbicado = new ArchivoAnexoDocControlMR();
		try {
			archivoUbicado = restTemplate.getForObject(uri, ArchivoAnexoDocControlMR.class);
		} catch (Exception e) {
			log.error(e);
		}
		return archivoUbicado;
	}
}
