package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.localanexo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
//import pe.gob.sunat.despaduanero2.declaracion.model.CatRefPartida;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CatRefPartidasDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.AutorizacionZonaPrimariaService;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.servicio2.registro.service.SprDAOService;

public class ValidadorLocalAnexo extends IngresoAbstractServiceImpl{
	
	public ValidadorLocalAnexo() {
		super();
	}

	public static final String CODIGO_LOCAL_ANEXO_DEFAULT = "0000";

	private String codigoRegimen;
	private String rucPuntoLLegada;
	private String rucDepositoAduanero;
	private String codigoLocalAnexoPuntoLLegada;
	private String codigoLocalAnexoDepositoAduanero;
	
	//private SprDAOService sprDAOService;
	private String codigoModalidad;
	private String codAduana;
	private String codLugarRecep;
	private AutorizacionZonaPrimariaService autorizacionZonaPrimariaService;
	//private CatRefPartidasDAO  catRefPartidasDAO;
	
	
	public ValidadorLocalAnexo(String codigoRegimen, String rucPuntoLLegada, String rucDepositoAduanero,
			String codigoLocalAnexoPuntoLLegada, String codigoLocalAnexoDepositoAduanero,
                        String codigoModalidad,String codLugarRecep, String codAduana) {
		this.codigoRegimen = codigoRegimen;
		this.rucPuntoLLegada = rucPuntoLLegada;
		this.rucDepositoAduanero = rucDepositoAduanero;
		this.codigoLocalAnexoPuntoLLegada = codigoLocalAnexoPuntoLLegada;
		this.codigoLocalAnexoDepositoAduanero = codigoLocalAnexoDepositoAduanero;
	}
	
	public void fijarValidadorLocalAnexo(String codigoRegimen, String rucPuntoLLegada, String rucDepositoAduanero,
			String codigoLocalAnexoPuntoLLegada, String codigoLocalAnexoDepositoAduanero,
			String codigoModalidad,String codLugarRecep, String codAduana) {
		this.codigoRegimen = codigoRegimen;
		this.rucPuntoLLegada = rucPuntoLLegada;
		this.rucDepositoAduanero = rucDepositoAduanero;
		this.codigoLocalAnexoPuntoLLegada = codigoLocalAnexoPuntoLLegada;
		this.codigoLocalAnexoDepositoAduanero = codigoLocalAnexoDepositoAduanero;
		
		this.codigoModalidad = codigoModalidad;
		this.codAduana=codAduana;
		this.codLugarRecep=codLugarRecep;
	}

	/**
	 * Validaciones de local anexo
	 * @throws ValidadorLocalAnexoException
	 */
	public void validarLocalAnexoPuntoLLegada() throws ValidadorLocalAnexoException {
		validarLocalAnexo(rucPuntoLLegada, codigoLocalAnexoPuntoLLegada, "30555");
		validarLocalAnexoZPAE(rucPuntoLLegada, codigoModalidad,codigoLocalAnexoPuntoLLegada,codAduana,codLugarRecep);
	}
	
	/**
	 * Validaciones de local anexo para regimen 70
	 * @throws ValidadorLocalAnexoException
	 */
	public void validarLocalAnexoDepositoAduanero() throws ValidadorLocalAnexoException {
		if ("70".equals(codigoRegimen)){
			validarLocalAnexo(rucDepositoAduanero, codigoLocalAnexoDepositoAduanero, "30017");
		}
	}
	public void validarLocalAnexoPuntoLLegadaOMA2() throws ValidadorLocalAnexoException {
		validarLocalAnexoPuntoLLegOMA2("37181");
	}


	//LMVR - RN 148-5.6
	private void  validarLocalAnexoZPAE(final String rucPuntoLLegada, final String codigoModalidad,final String codigoLocalAnexoPuntoLLegada,
			final String codAduana,	final String codLugarRecep) throws ValidadorLocalAnexoException{

		if(codigoModalidad.equals("10")  &&  codLugarRecep.equals("04")){
			validarCircunscripcionZPAE(rucPuntoLLegada,codigoLocalAnexoPuntoLLegada,codAduana,"30669");
			//validarLocalAnexoNoapto(rucPuntoLLegada,codigoLocalAnexoPuntoLLegada); 
		}
	}
	private void  validarLocalAnexoPuntoLLegOMA2(final String  codigoError  ) throws ValidadorLocalAnexoException{

					throw new ValidadorLocalAnexoException(codigoError, new String[]{},"NO CORRESPONDE ENVIAR LOCAL ANEXO PARA EL LUGAR DE RECEPCION 14");

	}
	
	@SuppressWarnings("unchecked")
	private void  validarCircunscripcionZPAE(final String rucPuntoLLegada, final String codigoLocalAnexoPuntoLLegada,String codAduana,
			final String  codigoError  ) throws ValidadorLocalAnexoException{
		
		 List<Map<String, Object>> lstLocalesAnexos = autorizacionZonaPrimariaService.cargarLocalesAnexos(rucPuntoLLegada);	

		 if (lstLocalesAnexos != null && !lstLocalesAnexos.isEmpty()) {
	 
			 String ubigeo = lstLocalesAnexos.get(0).get("spr_ubigeo").toString();
			 String localanexo = lstLocalesAnexos.get(0).get("spr_correl").toString();
			
			 if(localanexo.equals(codigoLocalAnexoPuntoLLegada)){
			 
				  Map<String,Object> params = new HashMap<String,Object>();
				  params.put("tipo_uso", "UBI");
				  params.put("codi_aduan",codAduana);
				  params.put("rangoUbigeo",ubigeo);
				  AyudaService ayudaService = fabricaDeServicios.getService("Ayuda.ayudaService");
				  //List<CatRefPartida> jursidiccion = catRefPartidasDAO.getCatRefPartidas(params);
				  List<CatRefpartidas> jursidiccion = (List<CatRefpartidas>)ayudaService.getCatRefPartidas(params);
				
				  if(jursidiccion == null || jursidiccion.isEmpty()){
					  throw new ValidadorLocalAnexoException(codigoError, new String[]{codigoLocalAnexoPuntoLLegada},"UBICACI�N DEL LOCAL ANEXO () EXCEDE LOS L�MITES DE LA CIRCUNSCRIPCI�N TERRITORIAL DEL DEPARTAMENTO");
				  }  
			  
			 }
		  
		 }
	}
	
	
	@SuppressWarnings("unchecked")
	private void validarLocalAnexo(final String rucAvalidar, final String anexo, final String codigoError) throws ValidadorLocalAnexoException {
		
		if(StringUtils.isBlank(anexo)){
			throw new ValidadorLocalAnexoException(codigoError);
		}
		final String codigoAnexoBuscado = Cadena.padLeft(anexo, 4, '0');
		
		
		if(!CODIGO_LOCAL_ANEXO_DEFAULT.equals(codigoAnexoBuscado)){
			SprDAOService sprDAOService = fabricaDeServicios.getService("Ayuda.sprService");
			List<Map<String, Object>> localesAnexos = sprDAOService.findByListLocalesPorRuc(rucAvalidar);
			if(CollectionUtils.isNotEmpty(localesAnexos)){
				
				Object localAnexoEncontrado = CollectionUtils.find(localesAnexos, new Predicate() {
					
					@Override
					public boolean evaluate(Object objCurrentLocalAnexo) {
						Map<String, Object> mapCurrentLocalAnexo = (Map<String, Object>)objCurrentLocalAnexo;
						
						String currentLocalAnexo = " ";
						Object obj =  mapCurrentLocalAnexo.get("spr_correl");
								//Cambio por error
								if (obj instanceof Long) {			
									currentLocalAnexo = Cadena.padLeft(String.valueOf(((Long)obj).intValue()),4,'0');//RIN 13- 619
								}else if(obj instanceof Short){
									currentLocalAnexo = Cadena.padLeft(String.valueOf(((Short)obj).intValue()),4,'0');//RIN 13- 619
								}						
						return codigoAnexoBuscado.equals(currentLocalAnexo);
					}
				});
				
				if(localAnexoEncontrado == null){
					throw new ValidadorLocalAnexoException(codigoError, new String[]{anexo},"	CODIGO DEL LOCAL ANEXO NO PERTENECE AL RUC DEL PUNTO DE LLEGADA");
				}
			}else{
				throw new ValidadorLocalAnexoException(codigoError, new String[]{anexo},"	CODIGO DEL LOCAL ANEXO INVALIDO");
			}
		}
		
	}

	/*
	public SprDAOService getSprDAOService() {
		return sprDAOService;
	}

	public void setSprDAOService(SprDAOService sprDAOService) {
		this.sprDAOService = sprDAOService;
	}

	public AutorizacionZonaPrimariaService getAutorizacionZonaPrimariaService() {
		return autorizacionZonaPrimariaService;
	}

	public CatRefPartidasDAO getCatRefPartidasDAO() {
		return catRefPartidasDAO;
	}

	public void setAutorizacionZonaPrimariaService(
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService) {
		this.autorizacionZonaPrimariaService = autorizacionZonaPrimariaService;
	}

	public void setCatRefPartidasDAO(CatRefPartidasDAO catRefPartidasDAO) {
		this.catRefPartidasDAO = catRefPartidasDAO;
	}*/

	

}
