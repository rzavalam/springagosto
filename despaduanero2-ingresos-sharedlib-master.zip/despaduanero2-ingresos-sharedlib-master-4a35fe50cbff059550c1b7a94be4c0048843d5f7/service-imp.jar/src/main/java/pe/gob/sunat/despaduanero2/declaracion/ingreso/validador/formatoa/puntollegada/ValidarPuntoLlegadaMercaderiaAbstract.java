package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

import static pe.gob.sunat.despaduanero2.manifiesto.util.Constantes.IND_REGISTRO_ACTIVO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.dao.CircunoceDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoOABL;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoDeTransporteService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;


public abstract class ValidarPuntoLlegadaMercaderiaAbstract extends ValDuaAbstract{

	private static final String RUC_VIGENTE_HABIDO = "0000";
	protected ManifiestoService manifiestoService;
	protected DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService;
	protected McdetaDAO mcdetaDAO;
	//protected FabricaDeServicios fabricaDeServicios;
	protected HotSwappableTargetSource swapperDatasource;
	protected ManifiestoSigadService manifiestoSigadService;


	protected static final String CODIGO_REGIMEN_DEPOSITO_ADUANERO = "70";

	//Catalogo 123
	protected static final String CODIGO_OPERADOR_DEPOSITO_ADUANERO = "32";
	protected static final String CODIGO_OPERADOR_DEPOSITO_TEMPORAL_ADUANERO = "31";
	protected static final String CODIGO_OPERADOR_TERMINAL_AEREO = "54";

	//catalogo 402	
	protected static final String CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL = "1";
	protected static final String CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO = "2";
	protected static final String CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO = "3";
	protected static final String CODIGO_PUNTO_LLEGADA_CETICOS = "6";
	protected static final String CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS = "9";
	protected static final String CODIGO_PUNTO_LLEGADA_TERMNINAL_AEREO = "4";
	protected static final String CODIGO_PUNTO_LLEGADA_CONTROLEQUIPAJEINTERNACIONAL = "11";
	protected static final String CODIGO_PUNTO_LLEGADA_AEROPUERTO = "12"; 

	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_ANTICIPADO_AEREO= {
			CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL,
			CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO,
			CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO,
			CODIGO_PUNTO_LLEGADA_TERMNINAL_AEREO};//R1778

	protected static final String RUC_ZOFRATACNA = "20147797011";
//RIN05 PAS20181U220200004 MORDONEZL
//REVISAR PASE PAS20181U220200004
	protected static final String CODIGO_PUNTO_LLEGADA_TERMINAL_FLUVIAL = "13";
	protected static final String CODIGO_PUNTO_LLEGADA_CENTRO_ATENCION_FRONTERIZA = "14";
	protected static final String CODIGO_PUNTO_LLEGADA_ZOFRATACNA = "16";

	//catalogo UG
	protected static final String CODIGO_LUGAR_DESCARGA_DESCARGA_PUNTO_LLEGADA = "03";
	protected static final String CODIGO_LUGAR_DESCARGA_DESCARGA_ZONA_PRIMARIA = "04";

	//protected DataCatAsocDAO dataCatAsocDAO = null;
	//protected CatalogoHelperImpl catalogoHelper = null;

	protected OpecomextDAO opecomextDao = null;

	protected CircunoceDAO circunoceDAO = null;

	protected Date fechaReferencia = null;

	// iterface para validar catalogo 402 punto de llegada
	interface PuntoLlegadaValidador extends ValidadorPuntoLlegadaMercancia {
	}

	public ValidarPuntoLlegadaMercaderiaAbstract() {
		super();
	}

	/**
	 * Valida lugar de Descarga por deposito aduanero Si es deposito aduanero
	 * verificamos que se envie el RUC de deposito aduanaero y que este ruc
	 * exista y este vigente en opecomex
	 * @throws PuntoLLegadaValidadorException 
	 */
	void validarTipoLugarDescargaPorRegimen(String regimen, String numeroRUCdeposito, Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
		if (CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)) {
			if (StringUtils.isNotBlank(numeroRUCdeposito)) {
				// buscar el ruc del deposito en opecomex y verificar que este
				// vigente
				//				boolean esDepositoAduaneroValido = catalogoHelper
				//						.esOperadorValido(numeroRUCdeposito, CODIGO_OPERADOR_DEPOSITO_ADUANERO, fechaReferencia, codAduana);
				boolean esDepositoAduaneroValido= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numeroRUCdeposito, CODIGO_OPERADOR_DEPOSITO_ADUANERO, fechaReferencia, codAduana));
				if (!esDepositoAduaneroValido) {
					throw new PuntoLLegadaValidadorException("30556", 
							new String[]{numeroRUCdeposito}, "RUC DEL DEPOSITO ADUANERO ({0}) NO CUENTA CON AUTORIZACION PARA OPERAR O NO SE ENCUENTRA VIGENTE");
				}
			} else {
				throw new PuntoLLegadaValidadorException("30482", new String[]{numeroRUCdeposito}, "RUC DE DEPOSITO ADUANERO INVALIDO");
			}
		}
	}

	abstract PuntoLlegadaValidador tipoPuntoLlegadaValidadorBuilder(String codigoPuntoLlegada);
	/* clases internas para validar lugar de descarga 
	 * 
	 */
	/**
	 * @author fjonislla
	 *interface para validar lugar de descara
	 */
	interface LugarDescargaValidador extends ValidadorPuntoLlegadaMercancia {

	}

	/**
	 * @author fjonislla
	 * 
	 *         Clase interna que valida punto de llegada cuando se trata de
	 *         lugar de Descarga es descarga en el punto de llegada
	 */
	class LugarDescargaEnPuntoLlegadaValidador implements LugarDescargaValidador {

		private String codigoPuntoLLegadaMercancia;

		private String[] puntosLLegadaPorTipoLugarDescarga;

		LugarDescargaEnPuntoLlegadaValidador(String codigoPuntoLLegadaMercancia, String[] puntosLLegadaPorTipoLugarDescarga){
			this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia; 
			this.puntosLLegadaPorTipoLugarDescarga= puntosLLegadaPorTipoLugarDescarga;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			boolean esPuntoLlegadaCorrecto = ArrayUtils.contains(puntosLLegadaPorTipoLugarDescarga,
					codigoPuntoLLegadaMercancia);

			if (esPuntoLlegadaCorrecto) {
				PuntoLlegadaValidador puntoLlegadaValidador = tipoPuntoLlegadaValidadorBuilder(codigoPuntoLLegadaMercancia);
				puntoLlegadaValidador.validar(fechaReferencia, codAduana);

			} else {
				throw new PuntoLLegadaValidadorException("30549", new String[]{"03", Arrays.toString(puntosLLegadaPorTipoLugarDescarga)},
						"PARA TIPO DE LUGAR DE DESCARGA {0} DEBE CONSIGNAR UN TIPO DE PUNTO DE LLEGADA VALIDO:{1}");
			}
		}

	}

	/**
	 * @author fjonislla Clase interna que valida punto de llegada cuando se
	 *         trata de lugar de descarga es descarga en zona primaria
	 */
	class LugarDescargaEnZonaPrimariaValidador implements LugarDescargaValidador {
		private String codigoPuntoLLegadaMercancia;

		private String numeroRUCpuntoLlegada;
		private String numeroRUCduenioConsignatario;

		private String[] puntosLLegadaPorTipoLugarDescarga;

		LugarDescargaEnZonaPrimariaValidador(String codigoPuntoLLegadaMercancia, String numeroRUCpuntoLlegada,
				String numeroRUCduenioConsignatario, String[] puntosLLegadaPorTipoLugarDescarga) {
			this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
			this.numeroRUCduenioConsignatario = numeroRUCduenioConsignatario;
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			this.puntosLLegadaPorTipoLugarDescarga = puntosLLegadaPorTipoLugarDescarga;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			boolean esPuntoLlegadaCorrecto = ArrayUtils.contains(puntosLLegadaPorTipoLugarDescarga,
					codigoPuntoLLegadaMercancia);
			if (!esPuntoLlegadaCorrecto) {
				throw new PuntoLLegadaValidadorException("30549", new String[]{"04", Arrays.toString(puntosLLegadaPorTipoLugarDescarga)},
						"PARA TIPO DE LUGAR DE DESCARGA {0} DEBE CONSIGNAR UN TIPO DE PUNTO DE LLEGADA VALIDO:{1}");
			}

			if (!numeroRUCpuntoLlegada.equals(numeroRUCduenioConsignatario) || numeroRUCduenioConsignatario.equals("")) {
				throw new PuntoLLegadaValidadorException("30550", new String[]{numeroRUCpuntoLlegada, numeroRUCduenioConsignatario},
						"RUC DEL PUNTO DE LLEGADA NO CORRESPONDE AL RUC DEL DUE�O O CONSIGNATARIO DE LA MERCANCIA");
			}

		}

	}


	/**
	 * solo lanza error, puesto que trata las posibles opciones no contempladas 
	 * @author fjonislla
	 *
	 */
	class LugarDescargaNoContempladosValidador implements LugarDescargaValidador {
		private String codigoError;
		// mensaje referencial el que se muestra se encuentra en el catalogo F09
		private String mensaje = "PARA DESPACHOS ANTICIPADOS DEBE DECLARAR EL TIPO DE LUGAR DE DESCARGA 03 O 04"; 
		/**
		 * @param codigoError codigo de error a mostrar
		 */
		LugarDescargaNoContempladosValidador(String codigoError){
			this.codigoError =codigoError;
		}
		/* (non-Javadoc)
		 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidarPuntoLlegadaMercancia#validar()
		 */
		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			throw new PuntoLLegadaValidadorException(codigoError, mensaje);
		}

	}

	/**
	 * solo lanza error, puesto que trata las posibles opciones no contempladas 
	 * @author fjonislla
	 *
	 */
	class LugarDescargaRegimenDeposito implements LugarDescargaValidador {
		private String codigoError;
		// mensaje referencial el que se muestra se encuentra en el catalogo F09
		private String mensaje = "PARA REGIMEN DEPOSITO DEBE DECLARAR TIPO DE LUGAR DE DESCARGA 03"; 
		/**
		 * @param codigoError codigo de error a mostrar
		 */
		LugarDescargaRegimenDeposito(String codigoError){
			this.codigoError =codigoError;
		}
		/* (non-Javadoc)
		 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidarPuntoLlegadaMercancia#validar()
		 */
		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			throw new PuntoLLegadaValidadorException(codigoError, mensaje);
		}

	}


	class PuntoLlegadaDepositoEER implements LugarDescargaValidador{

		private String codigoError;
		private String codigoPuntoLLegadaMercancia;
		private String[] puntosLLegadaPorTipoLugarDescarga;
		private boolean considerarEER;
		
		PuntoLlegadaDepositoEER(String codigoPuntoLLegadaMercancia, String[] puntosLLegadaPorTipoLugarDescarga, boolean considerarEER){
			this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia; 
			this.puntosLLegadaPorTipoLugarDescarga= puntosLLegadaPorTipoLugarDescarga;
			this.considerarEER = considerarEER;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {

			boolean esPuntoLlegadaCorrecto = ArrayUtils.contains(puntosLLegadaPorTipoLugarDescarga,
					codigoPuntoLLegadaMercancia);

			if (esPuntoLlegadaCorrecto) {
				PuntoLlegadaValidador puntoLlegadaValidador = tipoPuntoLlegadaValidadorBuilder(codigoPuntoLLegadaMercancia);
				puntoLlegadaValidador.validar(fechaReferencia, codAduana); //valida como siempre
			}else {			
				if(considerarEER) {
					throw new PuntoLLegadaValidadorException("70151", new String[]{ ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR},
							"EL DOCUMENTO DE TRANSPORTE ES EER, EL TIPO DE PUNTO DE LLEGADA DEBE SER 5 DEPOSITO TEMPORAL EER");
				}else {
					throw new PuntoLLegadaValidadorException("70375", new String[]{codigoPuntoLLegadaMercancia},
							"EL DOCUMENTO DE TRANSPORTE NO ES EER, EL TIPO DE PUNTO DE LLEGADA "+codigoPuntoLLegadaMercancia+" NO CORRESPONDE ");
				}				
			}
		
		
		}
		
	}
	
	/* clases internas para validar punto de llegada 
	 * 
	 */

	// 1
	/**
	 * 
	 * @author fjonislla
	 *
	 */
	/*
	 	�	Cuando el tipo de punto de llegada es 1 � Deposito Temporal se validara que el RUC declarado se encuentre en  la Tabla de Operadores - Opecomext como tipo 31 y que se encuentre vigente (Fecha de Declaraci�n entre fec_inivig y fec_finvig y estado 00).
	 	Caso contrario el NSIGAD mostrara el mensaje de error: �RUC  del Punto de Llegada no se encuentra registrado como Dep�sito Temporal�

	 */
	class PuntoLlegadaDepositoTemporal  implements PuntoLlegadaValidador {

		String codigoAduanaTransmision;
		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;
		private OpecomextDAO opecomextDao;
		private ManifiestoService manifiestoService;
		private DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService;
		//private McdetaDAO  mcdetaDAO ;
		String annManifiesto;
		String codModTranspo;
		String numManifiesto;
		private List<DatoDocTransporte> lstdocumentostrans;
		private FabricaDeServicios fabricaDeServicios ;
		//private HotSwappableTargetSource swapperDatasource;
		private ManifiestoSigadService manifiestoSigadService;
		private CircunoceDAO circunoceDAO;
		//private String codigoTransaccion;
		//private String codigoPuntoLlegada;
		private String codOperadorLlegada;


		PuntoLlegadaDepositoTemporal(String codigoAduanaTransmision, String numeroRUCpuntoLlegada, 
				OpecomextDAO opecomextDao, String annManifiesto, String codModTranspo, String numManifiesto, ManifiestoService manifiestoService,
				DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,List<DatoDocTransporte> lstdocumentostrans,
				FabricaDeServicios fabricaDeServicios, 
				ManifiestoSigadService manifiestoSigadService,CircunoceDAO circunoceDAO, String codOperadorLlegada )
		{
			this.codigoAduanaTransmision = codigoAduanaTransmision;
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
			this.opecomextDao = opecomextDao;
			this.annManifiesto = annManifiesto;
			this.codModTranspo = codModTranspo;
			this.numManifiesto = numManifiesto;
			this.manifiestoService = manifiestoService;
			this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
			this.lstdocumentostrans = lstdocumentostrans;
			//this.mcdetaDAO = mcdetaDAO;
			this.fabricaDeServicios = fabricaDeServicios;
			//this.swapperDatasource = swapperDatasource;
			this.manifiestoSigadService = manifiestoSigadService;
			this.circunoceDAO=circunoceDAO;
			//this.codigoTransaccion=codigoTransaccion;
			this.codOperadorLlegada = codOperadorLlegada;

		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException{
			Map mapDatos=existeDepositoTemporalEnOperadorComercio();//arey bug 18248

			boolean existeDepositoTemporal = (Boolean) mapDatos.get("indicador");//arey bug 18248

			if (!existeDepositoTemporal) {
				if(mapDatos.get("error")!=null && mapDatos.get("tipoError")!=null && mapDatos.get("desError") !=null){
					throw new PuntoLLegadaValidadorException(mapDatos.get("error").toString().concat(mapDatos.get("tipoError").toString()),mapDatos.get("desError").toString());
				}else{
					throw new PuntoLLegadaValidadorException("35265", new String[]{numeroRUCpuntoLlegada,codigoAduanaTransmision},
							"RUC  DEL PUNTO DE LLEGADA {0} NO SE ENCUENTRA REGISTRADO COMO DEPOSITO TEMPORAL");
				}
			}

		}

		private Map<String,Object> existeDepositoTemporalEnOperadorComercio() {

			Map<String,Object> mapDatos= new HashMap<String, Object>();

			boolean esDepositoTemporalValido =false;
			if(SunatStringUtils.isEmpty(numeroRUCpuntoLlegada)){
				esDepositoTemporalValido=false;
				mapDatos.put("indicador", esDepositoTemporalValido);
				return mapDatos;
			}


			OperadorValidaService operadorValidaService = (OperadorValidaService) fabricaDeServicios.getService("Ayuda.operadorValidaService");
			/*RIN13-619*/
			String estadoCircunoce ="";
			SimpleDateFormat formato = new 	SimpleDateFormat("dd/MM/yyyy");  
			String resultado = formato.format(fechaReferencia);  //Estaba comentada - se activo por Pase PAS20165E220200095
			Date fechaHoy =SunatDateUtils.getCurrentDate() ;
			String resultadoHoy = formato.format(fechaHoy); 
			Date fechaReferenciaNew =SunatDateUtils.getDate(resultadoHoy, "dd/MM/yyyy");
			Date fechaRefe =SunatDateUtils.getDate(resultado, "dd/MM/yyyy");
			List result = operadorValidaService.validarOperador(numeroRUCpuntoLlegada, codOperadorLlegada, codigoAduanaTransmision,fechaRefe);//PAS20165E220200095
			if(CollectionUtils.isEmpty(result)){
				esDepositoTemporalValido=true;
			} else {
				Map mapError = new HashMap();
				mapError =  (Map)result.get(0);
				mapDatos.put("error", mapError.get("codError").toString());
				mapDatos.put("desError", mapError.get("desError").toString());
				mapDatos.put("tipoError", mapError.get("codTipAlerta").toString());
			}

			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numRUC", numeroRUCpuntoLlegada);
			params.put("fechaVigencia", fechaRefe);//PAS20165E220200095
			params.put("codTipOpera", codOperadorLlegada);
			params.put("type", "Seida");//PAS20165E220200095
			List<Map<String, Object>> list = opecomextDao.findByMap(params);
			Map<String, Object> paramcircunoce = new HashMap<String, Object>();
			paramcircunoce.put("numRUC", numeroRUCpuntoLlegada);
			paramcircunoce.put("fecha", fechaRefe);//PAS20165E220200095
			paramcircunoce.put("codTipOpera", codOperadorLlegada);
			paramcircunoce.put("codAduana", codigoAduanaTransmision);

			List<Map<String, Object>> listcircunoce = circunoceDAO.findByMap(paramcircunoce);

			if (listcircunoce.size() > 0 ) 
			{
				Map<String, Object> datosCircunoce = listcircunoce.get(0);
				estadoCircunoce = datosCircunoce.get("cod_estado").toString();
			}

			if (list.size() > 0 ) 
			{

				Map<String, Object> datosOpe = list.get(0);
				String estado = datosOpe.get("cod_estado").toString();
				Date fechaIniSuspension = (Date)datosOpe.get("fec_inivig");//gmontoya Pase 31
				Integer contadorIca = 0;
				if(estado.equals("00") && estadoCircunoce.equals("00")){
					mapDatos.put("indicador", esDepositoTemporalValido);
					return mapDatos;
				} 

				if (estado.equals("01") || estadoCircunoce.equals("01") ) 
				{
					//INCIO - RIN 13-619					
					String annManif = annManifiesto;
					//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio("01",codModTranspo, codigoAduanaTransmision,SunatNumberUtils.toInteger(annManif),numManifiesto, true);
					Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(ConstantesDataCatalogo.TIPO_MANIFIESTO_INGRESO,codModTranspo, codigoAduanaTransmision,SunatNumberUtils.toInteger(annManif),numManifiesto, true);
					if (manifiesto != null) {
						//if (codModTranspo.equals("1")) {
						if (codModTranspo.equals(ConstantesDataCatalogo.VIA_TRANSPORTE_MARITIMA) && !manifiesto.isEsSigad()) {//seg�n codigo esto es solo para SDA PAS20181U220200049							
							ParticipanteDocDAO participanteDocDAO = (ParticipanteDocDAO)fabricaDeServicios.getService("participanteDAO");
							//inicio gmontoya Pase 31
							DocumentoDeTransporteService documentoDeTransporteService = fabricaDeServicios.getService("manifiesto.documentoDeTransporteService");
							List listaBL = new ArrayList();
							List<DocumentoDeTransporte> listaDT = new ArrayList<DocumentoDeTransporte>();
							boolean usoNumDet = true;
							if(!CollectionUtils.isEmpty(lstdocumentostrans)){
								if(lstdocumentostrans.get(0).getNumdetalle()==null){
									usoNumDet = false;
								}							
								for (DatoDocTransporte documentoTransporte : lstdocumentostrans) {
									if(usoNumDet){
										listaBL.add(documentoTransporte.getNumdetalle());
									}else{
										listaBL.add(documentoTransporte.getNumdoctransporte());
									}
								}
								if(usoNumDet){
									listaDT = documentoDeTransporteService.findDocumentosDeTransporte(manifiesto.getNumeroCorrelativo(), (Integer[])listaBL.toArray(new Integer[listaBL.size()]));
								}else{
									listaDT = documentoDeTransporteService.findDocumentosDeTransporte(manifiesto.getNumeroCorrelativo(), (String[])listaBL.toArray(new String[listaBL.size()]));
								}
							}
							//fin gmontoya Pase 31
							String numRuc;
							for (DocumentoDeTransporte documentoTransporte : listaDT) {
								String numDetalle = documentoTransporte.getNumeroDeDetalle().toString();//gmontoya Pase 31
								if(documentoTransporte.getNumeroDetalleRaiz()!=null){
									numDetalle = documentoTransporte.getNumeroDetalleRaiz().toString();
								}

								Map<String, Object> paramsMap = new HashMap<String, Object>();
								paramsMap.put("numeroCorrelativo",manifiesto.getNumeroCorrelativo());
								paramsMap.put("tipoEnvio", "4");// Si tiene ICA
								paramsMap.put("indicadorEliminacion",IND_REGISTRO_ACTIVO);
								paramsMap.put("numeroDeDetalle", numDetalle);

								List<DocumentoOABL> lista = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(paramsMap);

								for(DocumentoOABL doc : lista){
									numRuc = participanteDocDAO.getByPrimaryKey(doc.getParticipanteDestino().getSecuenciaDeParticipantes()).getNumeroDocumentoIdentidad();
									if(!numRuc.equals(numeroRUCpuntoLlegada)){
										esDepositoTemporalValido=false;
										mapDatos.put("indicador", esDepositoTemporalValido);
										return mapDatos;
									}
									if(doc.getFechaFinalDeOperacion().compareTo(fechaIniSuspension)<0){
										esDepositoTemporalValido=true;
										mapDatos.put("indicador", esDepositoTemporalValido);
										return mapDatos;
									}
								}
								contadorIca = lista.size();
								if (contadorIca > 0) {
									contadorIca = 1;
									break;
								}

							}
						} else {

							Map<String, Object> paramdeta = new HashMap<String, Object>();
							paramdeta.put("anioManifiesto", annManifiesto);
							paramdeta.put("codigoAduana", codigoAduanaTransmision);
							paramdeta.put("codigoViaTransporte", codModTranspo);
							paramdeta.put("numeroManifiesto", numManifiesto);

							List<Mcdeta> listMcdeta = new ArrayList<Mcdeta>();
							Integer anho = new Integer(annManifiesto);

							for (DatoDocTransporte documentoTransporte : lstdocumentostrans) {

								listMcdeta = manifiestoSigadService.getListMcdetaByClaveDeNegocio(codModTranspo,codigoAduanaTransmision, anho,numManifiesto,documentoTransporte.getNumdoctransporte(),
										documentoTransporte.getCodpuerto());
								if (!listMcdeta.isEmpty() || listMcdeta.size() > 0) {									
									if (!listMcdeta.get(0).getDocumentoDeTransporte().getBultosRecibidos().equals(0) && !listMcdeta.get(0).getDocumentoDeTransporte().getPesoRecibido().equals(0)) {
										contadorIca = 1;
										break;
									}
								}
							}
						}

						if (contadorIca > 0) {
							esDepositoTemporalValido=true;
							mapDatos.put("indicador", esDepositoTemporalValido);
							return mapDatos;
						}
					}
				}
			}
			esDepositoTemporalValido=false;
			mapDatos.put("indicador", esDepositoTemporalValido);
			return mapDatos;

		}
	}

	public boolean rucTerminalPortuarioPerteneceAduanaTransmision(String numeroRUCpuntoLlegada,
			String codigoAduanaTransmision) {
		List<Map<String, Object>> puertosPorAduana = findPuertosEnJurisdiccionByCodigoAduana(codigoAduanaTransmision);
		List<Map<String, Object>> puertosPorNumeroRuc = findPuertosByRuc(numeroRUCpuntoLlegada, "113");
		List<Map<String, Object>> puertosPorNumeroRucMultiBoyas = findPuertosByRuc(numeroRUCpuntoLlegada, "123");

		for (Map<String, Object> mapPuertoAduana : puertosPorAduana) {
			final String codigoPuertoAduana = (String) mapPuertoAduana.get("cod_datacatasoc");
			Object puertoEncontrado = org.apache.commons.collections.CollectionUtils.find(puertosPorNumeroRuc, new Predicate() {

				@Override
				public boolean evaluate(Object puertoPorNumeroRuc) {
					@SuppressWarnings("unchecked")
					String codigoPuertoPorNumeroRuc = (String) ((Map<String, Object>) puertoPorNumeroRuc)
							.get("cod_datacat");
					try {
						return codigoPuertoPorNumeroRuc.equals(codigoPuertoAduana);
					} catch (NullPointerException ne) {
						return false;
					}
				}
			});
			if (puertoEncontrado != null) {				
				return true;
			} else {				
				//puertosPorNumeroRuc = findPuertosByRuc(numeroRUCpuntoLlegada, "123");
				puertoEncontrado = org.apache.commons.collections.CollectionUtils.find(puertosPorNumeroRucMultiBoyas, new Predicate() {
					@Override
					public boolean evaluate(Object puertoPorNumeroRuc) {
						@SuppressWarnings("unchecked")
						String codigoPuertoPorNumeroRuc = (String) ((Map<String, Object>) puertoPorNumeroRuc)
								.get("cod_datacat");
						try {
							return codigoPuertoPorNumeroRuc.equals(codigoPuertoAduana);
						} catch (NullPointerException ne) {
							return false;
						}
					}
				});
				if (puertoEncontrado != null) {				
					return true;
				}
			}
		}
		return false;
	}
	
	private List<Map<String, Object>> findPuertosEnJurisdiccionByCodigoAduana(String codigoAduanaTransmision) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		// retornar COD_DATACATASOC
		/* para asociacion = 109 */
		parametros.put("codAsociacion", "109");
		parametros.put("codElemento", codigoAduanaTransmision);
		parametros.put("codSelElemento", "C");

		
		List<Map<String,Object>>  listDataCatAsoc= new ArrayList();	
		parametros.put("ayudaID", "DataCatAsoc");
		listDataCatAsoc= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findByMapDataCatAsoc(parametros);
		
		//return dataCatAsocDAO.findByMap(parametros);
		
		return listDataCatAsoc;
	}
	
	/**
	 * Busca puertos asociados a un numero de ruc
	 * 
	 * @return
	 */
	private List<Map<String, Object>> findPuertosByRuc(String numeroRUCpuntoLlegada, String codAsociacion) {
		// retornar COD_DATACAT
		Map<String, Object> parametros = new HashMap<String, Object>();
		// para asociacion = 113
		//parametros.put("codAsociacion", "113");
		parametros.put("codAsociacion", codAsociacion);
		parametros.put("codElemento", numeroRUCpuntoLlegada);
		parametros.put("codSelElemento", "A");
		
		
		List<Map<String,Object>>  listDataCatAsoc= new ArrayList();	
		parametros.put("ayudaID", "DataCatAsoc");
		listDataCatAsoc= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findByMapDataCatAsoc(parametros);
		
		
		//return dataCatAsocDAO.findByMap(parametros);
		
		return listDataCatAsoc;
	}
	
	class PuntoLlegadaTerminalPortuarioDAMSinICa implements PuntoLlegadaValidador{
		String numeroRUCpuntoLlegada;
		String codigoAduanaTransmision;
		private FabricaDeServicios fabricaDeServicios;

		PuntoLlegadaTerminalPortuarioDAMSinICa(String codigoAduanaTransmision, String numeroRUCpuntoLlegada,
				FabricaDeServicios fabricaDeServicios){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			this.codigoAduanaTransmision = codigoAduanaTransmision;
			this.fabricaDeServicios = fabricaDeServicios;
		}
		
		@Override
		public void validar(Date fechaReferencia, String codAduana)
				throws PuntoLLegadaValidadorException {
			// TODO Auto-generated method stub
			Map<String,Object> mapDatos = existeTerminalPortuarioEnOperadorComercio(fechaReferencia);
			boolean existeTerminalPortuario = (Boolean) mapDatos.get("indicador");
//pruizcr pase PAS20181U220200004
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			//boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaReferencia):false;
			if (!existeTerminalPortuario ) {
				if(mapDatos.get("error")!=null && mapDatos.get("tipoError")!=null && mapDatos.get("desError") !=null){
					//throw new PuntoLLegadaValidadorException(mapDatos.get("error").toString().concat(mapDatos.get("tipoError").toString()),mapDatos.get("desError").toString());
				//}else{
					throw new PuntoLLegadaValidadorException("37031", new String[]{numeroRUCpuntoLlegada,codigoAduanaTransmision},
						"DAM DIFERIDA SIN ICA, EL RUC DEL PUNTO DE LLEGADA DEBE SER UN TERMINAL PORTUARIO.");
				}
			}
			boolean rucPerteneceTerminalPortuario = rucTerminalPortuarioPerteneceAduanaTransmision(
					numeroRUCpuntoLlegada, codigoAduanaTransmision);

			if (!rucPerteneceTerminalPortuario) {
				throw new PuntoLLegadaValidadorException("30547", new String[]{numeroRUCpuntoLlegada, codigoAduanaTransmision},
						"RUC DEL PUNTO DE LLEGADA ({0}) NO CORRESPONDE A TERMINAL PORTUARIO DE LA JURISDICCION DE ADUANA DE TRANSMISION ({1})");
			}
		}

//pruizcr pase PAS20181U220200004
		
		private Map<String,Object> existeTerminalPortuarioEnOperadorComercio(Date fechaReferencia) {
			Map<String,Object> mapDatos= new HashMap<String, Object>();
			
			boolean esTerminalPortuarioValido = false;
			if(SunatStringUtils.isEmpty(numeroRUCpuntoLlegada)){
				mapDatos.put("indicador", esTerminalPortuarioValido);
				return mapDatos;
			}
			OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaService");
			SimpleDateFormat formato = new 	SimpleDateFormat("dd/MM/yyyy");  
			String resultado = formato.format(fechaReferencia);
			Date fechaRefe =SunatDateUtils.getDate(resultado, "dd/MM/yyyy");
			List result = operadorValidaService.validarOperador(numeroRUCpuntoLlegada, ConstantesDataCatalogo.TIPO_PARTICIPANTE_OPERADOR_PORTUARIO, fechaRefe);
			if(CollectionUtils.isEmpty(result)){
				esTerminalPortuarioValido=true;
			} else {
					Map mapError = new HashMap();
					mapError =  (Map)result.get(0);
					mapDatos.put("error", mapError.get("codError").toString());
					mapDatos.put("desError", mapError.get("desError").toString());
					mapDatos.put("tipoError", mapError.get("codTipAlerta").toString());
			}
			mapDatos.put("indicador", esTerminalPortuarioValido);
			return mapDatos;
		}
	}
	
	// 2
	/**
	 * @author fjonislla
	 *
	 */
	class PuntoLlegadaTerminalPortuario implements PuntoLlegadaValidador {
		String numeroRUCpuntoLlegada;
		String codigoAduanaTransmision;
		//private CatalogoHelperImpl catalogoHelper;

		PuntoLlegadaTerminalPortuario(String numeroRUCpuntoLlegada, String codigoAduanaTransmision){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			this.codigoAduanaTransmision = codigoAduanaTransmision;
			//this.catalogoHelper = catalogoHelper;
		}
		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			boolean rucPerteneceTerminalPortuario = rucTerminalPortuarioPerteneceAduanaTransmision(
					numeroRUCpuntoLlegada, codigoAduanaTransmision);

			if (!rucPerteneceTerminalPortuario) {
				throw new PuntoLLegadaValidadorException("30547", new String[]{numeroRUCpuntoLlegada, codigoAduanaTransmision},
						"RUC DEL PUNTO DE LLEGADA ({0}) NO CORRESPONDE A TERMINAL PORTUARIO DE LA JURISDICCION DE ADUANA DE TRANSMISION ({1})");
			}

		}
	}


	/**
	 * @author fjonislla
	 * 
	 *         Validaciones para punto de llegada deposito aduanero
	 */

	/*
	 *  Cuando el tipo de punto de llegada es 3 � Deposito Aduanero se validara que el RUC declarado se encuentre en  la Tabla de Operadores - Opecomext como tipo 32 y que se encuentre vigente (Fecha de Declaraci�n entre fec_inivig y fec_finvig y estado 00).		 
	 *	Caso contrario el NSIGAD mostrara el mensaje de error: �RUC  del Punto de Llegada no se encuentra registrado como Dep�sito Aduanero�.
	 */
	class PuntoLlegadaDepositoAduanero implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		PuntoLlegadaDepositoAduanero(String numeroRUCpuntoLlegada,  Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			boolean existeDepositoAduanero = existeDepositoAduaneroEnOperadorComercio(codAduana,fechaReferencia);
			if (!existeDepositoAduanero) {
				throw new PuntoLLegadaValidadorException("30544",new String[]{numeroRUCpuntoLlegada}, "RUC  DEL PUNTO DE LLEGADA NO SE ENCUENTRA REGISTRADO COMO DEPOSITO ADUANERO");
			}

		}

		private boolean existeDepositoAduaneroEnOperadorComercio(String codAduana, Date fechaReferencia) {
			//boolean esDepositoAduaneroValido = catalogoHelper.esOperadorValido(numeroRUCpuntoLlegada, CODIGO_OPERADOR_DEPOSITO_ADUANERO, fechaReferencia, codAduana);
			boolean esDepositoAduaneroValido =CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numeroRUCpuntoLlegada, CODIGO_OPERADOR_DEPOSITO_ADUANERO, fechaReferencia, codAduana));			
			return esDepositoAduaneroValido;
		}
	}

//	/*RIN05 CSANTILLAN INICIO */
//	class PuntoLlegadaTerminalFluvial implements PuntoLlegadaValidador {
//
//		private String numeroRUCpuntoLlegada;
//
//		PuntoLlegadaTerminalFluvial(String numeroRUCpuntoLlegada,  Date fechaReferencia){
//			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
//
//		}
//
//		@Override
//		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
//			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");	
//			Map<String, Object> resultado =null;
//			DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
//			Map mapDdp=(HashMap)ddpDAOService.findByPK(numeroRUCpuntoLlegada);
//			if (mapDdp==null){
//				throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
//			}else{
//				ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
//				//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");	
//				boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;
//				if(esVigenteRIN05){
//			
//					resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
//					if(resultado!=null && resultado.isEmpty()){	
//						throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
//					}else{				
//								
//						resultado = catalogoAyudaService.getElementoAsoc("026", "13", numeroRUCpuntoLlegada ,new Date());
//						if(resultado!=null && resultado.isEmpty()){	
//							throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
//						}
//						
//					}
//			  }
//				
//			}
//		
//		}
//	}
	
	class PuntoLlegadaCentroAtencionFronteriza implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;

		PuntoLlegadaCentroAtencionFronteriza(String numeroRUCpuntoLlegada,  Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;

		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");	
			boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;
			if(esVigenteRIN05){
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> resultado =null;
						
			resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
			if(resultado!=null && resultado.isEmpty()){	
				throw new PuntoLLegadaValidadorException("50125","LUGAR DE RECEPCI�N INVALIDO");
			}else{	
				resultado = catalogoAyudaService.getElementoAsoc("026", "14", numeroRUCpuntoLlegada ,new Date());
				if(resultado!=null && resultado.isEmpty()){	
					throw new PuntoLLegadaValidadorException("50124","LUGAR DE RECEPCI�N INVALIDO");
				}
			}	
			
			
			}
			

		}
	}
	//CSANTILLAN PAS20181U220200054  Validacion de Punto de llegada ZOFRATACNA
	class PuntoLlegadaZoFraTacna implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;

		PuntoLlegadaZoFraTacna(String numeroRUCpuntoLlegada,  Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;

		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			if (!numeroRUCpuntoLlegada.equals(RUC_ZOFRATACNA)) {
				throw new PuntoLLegadaValidadorException("50218",new String[]{numeroRUCpuntoLlegada}, "RUC  DEL PUNTO DE LLEGADA NO SE ENCUENTRA REGISTRADO COMO ZOFRATACNA");
			}

	
		if (!Arrays.asList(new String[]{"172"}).contains(codAduana)){
			throw new PuntoLLegadaValidadorException("50219",new String[]{"ZOFRATACNA"," 172 "}, "PARA EL PUNTO DE LLEGADA/ALMAC�N ADUANERO {0} SOLO CORRESPONDE LA ADUANA {1}");
		}

		}


	}

	/*RIN05 CSANTILLAN FIN */
	
	/*P34 AFMA  SE VA INSCRBIENOD EL SERVICIO DE CETICOS INICIO*/

	class PuntoLlegadaCeticos implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		PuntoLlegadaCeticos(String numeroRUCpuntoLlegada, Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {

			boolean isRucValido = isRucPuntoLlegadaValido();
			if (!isRucValido) {
				throw new PuntoLLegadaValidadorException("30545",new String[]{numeroRUCpuntoLlegada},"RUC DEL PUNTO DE LLEGADA NO SE ENCUENTRA EN ESTADO ACTIVO/HABIDO");
			}
			
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
			if(esVigenteRIN05PrimeraParte){
				Map<String, Object> resultado =null;
				CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
				if(resultado!=null && resultado.isEmpty()){	
					throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
				}else{				
							
					resultado = catalogoAyudaService.getElementoAsoc("026", "6", numeroRUCpuntoLlegada ,new Date());
					if(resultado!=null && resultado.isEmpty()){	
						throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
					}
					
				}
		  }

		}

		private boolean isRucPuntoLlegadaValido() {
			boolean esDepositoAduaneroValido = RUC_VIGENTE_HABIDO.equals(((PackageTD)fabricaDeServicios.getService("PackageTD")).functionDeclaVig(numeroRUCpuntoLlegada,"2","4"));			
			//boolean esDepositoAduaneroValido = catalogoHelper.esRucValidoActivo(numeroRUCpuntoLlegada);
			return esDepositoAduaneroValido;
		}

	}

	/*FIN*/




	/*
	 * �	Cuando el tipo de punto de llegada es 9 � Otros puntos de llegada autorizados
	 * 	validar� que el RUC declarado sea v�lido (estado activo y condici�n habido).

			Caso contrario el NSIGAD mostrara el mensaje de error: �RUC del Punto de Llegada no se encuentra en estado activo/habido�.
	 */
	class OtroPuntoLlegadaAutorizado implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		OtroPuntoLlegadaAutorizado(String numeroRUCpuntoLlegada){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			boolean isRucValido = isRucPuntoLlegadaValido();
			if (!isRucValido) {
				throw new PuntoLLegadaValidadorException("30545",new String[]{numeroRUCpuntoLlegada},"RUC DEL PUNTO DE LLEGADA NO SE ENCUENTRA EN ESTADO ACTIVO/HABIDO");
			}

		}

		private boolean isRucPuntoLlegadaValido() {
			//boolean esDepositoAduaneroValido = catalogoHelper.esRucValidoActivo(numeroRUCpuntoLlegada);
			boolean esDepositoAduaneroValido = RUC_VIGENTE_HABIDO.equals(((PackageTD)fabricaDeServicios.getService("PackageTD")).functionDeclaVig(numeroRUCpuntoLlegada,"2","4"));
			return esDepositoAduaneroValido;
		}
	}



	/*
	 * pase548	Cuando el tipo de punto de llegada es 6 � Ceticos
	 * 	validar� que el RUC declarado sea v�lido (estado activo y condici�n habido).

			Caso contrario el NSIGAD mostrara el mensaje de error: �RUC del Punto de Llegada no se encuentra en estado activo/habido�.
	 */
	class ceticoPuntoLlegada implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		ceticoPuntoLlegada(String numeroRUCpuntoLlegada){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
			boolean isRucValido = isRucPuntoLlegadaValido();
			if (!isRucValido) {
				throw new PuntoLLegadaValidadorException("30545",new String[]{numeroRUCpuntoLlegada},"RUC DEL PUNTO DE LLEGADA NO SE ENCUENTRA EN ESTADO ACTIVO/HABIDO");
			}

		}

		private boolean isRucPuntoLlegadaValido() {
			//boolean esDepositoAduaneroValido = catalogoHelper.esRucValidoActivo(numeroRUCpuntoLlegada);
			boolean esDepositoAduaneroValido = RUC_VIGENTE_HABIDO.equals(((PackageTD)fabricaDeServicios.getService("PackageTD")).functionDeclaVig(numeroRUCpuntoLlegada,"2","4"));
			return esDepositoAduaneroValido;
		}
	}

	class PuntoLlegadaTerminalAereo implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		PuntoLlegadaTerminalAereo(String numeroRUCpuntoLlegada, Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			boolean existeDepositoAduanero = existeTerminalAereoOperadorComercio(codAduana,fechaReferencia);
			if (!existeDepositoAduanero) {
				throw new PuntoLLegadaValidadorException("37048",new String[]{numeroRUCpuntoLlegada},"RUC  DEL PUNTO DE LLEGADA NO SE ENCUENTRA REGISTRADO COMO DEPOSITO ADUANERO");
			}
			
			
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;
			if(esVigenteRIN05){
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> resultado =null;
			resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
			if(resultado!=null && resultado.isEmpty()){	
				throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC " + numeroRUCpuntoLlegada + " DEL LUGAR DE RECEPCI�N INVALIDO");
			}else{				
						
				resultado = catalogoAyudaService.getElementoAsoc("026", "4", numeroRUCpuntoLlegada ,new Date());
				if(resultado!=null && resultado.isEmpty()){	
					throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
				}
				
			}
			
			}
			
		}

		private boolean existeTerminalAereoOperadorComercio(String codAduana, Date fechaReferencia) {
			boolean esDepositoAduaneroValido= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numeroRUCpuntoLlegada, CODIGO_OPERADOR_TERMINAL_AEREO, fechaReferencia, codAduana));
			//boolean esDepositoAduaneroValido = catalogoHelper.esOperadorValido(numeroRUCpuntoLlegada, CODIGO_OPERADOR_TERMINAL_AEREO, fechaReferencia, codAduana);
			return esDepositoAduaneroValido;
		}
	}


	class puntoLlegadaEquipajeInternacional implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		private String codLocalAnexo;

		puntoLlegadaEquipajeInternacional(String numeroRUCpuntoLlegada, String  codLocalAnexo){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			this.codLocalAnexo= codLocalAnexo;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {			
			if(!SunatStringUtils.isEmpty(numeroRUCpuntoLlegada)|| !SunatStringUtils.isEmpty(codLocalAnexo)){

				//Ya no va tiene que enviar algo
				//throw new PuntoLLegadaValidadorException("37047",new String[]{ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL, numeroRUCpuntoLlegada, codLocalAnexo},"LA DECLARACION TIENE COMO TIPO DE PUNTO DE LLEGADA , NO DEBE CONSIGNAR LOS DATOS DEL RUC Y CODIGO DE LOCAL ANEXO DEL PUNTO DE LLEGADA");
				ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
				boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
				if(esVigenteRIN05PrimeraParte){
					Map<String, Object> resultado =null;
					CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
					if(resultado!=null && resultado.isEmpty()){
						throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
					}else{

						resultado = catalogoAyudaService.getElementoAsoc("026", CODIGO_PUNTO_LLEGADA_CONTROLEQUIPAJEINTERNACIONAL, numeroRUCpuntoLlegada ,new Date());
						if(resultado!=null && resultado.isEmpty()){
							throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
						}

					}
			  }
			}
		}
	}
	

	class puntoLlegadaDuttyFree implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		puntoLlegadaDuttyFree(String numeroRUCpuntoLlegada,  Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			boolean existeDuttyFree = existeDuttyFreeEnOperadorComercio(codAduana,fechaReferencia);
			if (!existeDuttyFree) {
				throw new PuntoLLegadaValidadorException("37062",new String[]{numeroRUCpuntoLlegada}, "RUC  DEL PUNTO DE LLEGADA NO SE ENCUENTRA REGISTRADO COMO ALMACEN DUTY FREE");
			}

		}

		private boolean existeDuttyFreeEnOperadorComercio(String codAduana, Date fechaReferencia) {
			//boolean existeDuttyFree = catalogoHelper.esOperadorValido(numeroRUCpuntoLlegada, ConstantesDataCatalogo.TIPO_OPERADOR_DUTYFREE, fechaReferencia, codAduana);
			boolean existeDuttyFree= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numeroRUCpuntoLlegada, ConstantesDataCatalogo.TIPO_OPERADOR_DUTYFREE, fechaReferencia, codAduana));
			return existeDuttyFree;
		}
	}
	
		
	class puntoLlegadaDMUA implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		//private CatalogoHelperImpl catalogoHelper;

		puntoLlegadaDMUA(String numeroRUCpuntoLlegada, Date fechaReferencia){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			//this.catalogoHelper = catalogoHelper;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {
			boolean existeDMUA = existeDMUAEnOperadorComercio(codAduana,fechaReferencia);
			if (!existeDMUA) {
				throw new PuntoLLegadaValidadorException("37057",new String[]{numeroRUCpuntoLlegada}, "RUC  DEL PUNTO DE LLEGADA NO SE ENCUENTRA REGISTRADO COMO DEPOSITO DE MATERIAL DE USO AERONAUTICO");
			}

		}

		private boolean existeDMUAEnOperadorComercio(String codAduana, Date fechaReferencia) {
			//boolean existeDMUA = catalogoHelper.esOperadorValido(numeroRUCpuntoLlegada, ConstantesDataCatalogo.TIPO_OPERADOR_DMUA, fechaReferencia, codAduana);
			boolean existeDMUA = CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numeroRUCpuntoLlegada, ConstantesDataCatalogo.TIPO_OPERADOR_DMUA, fechaReferencia, codAduana));
			return existeDMUA;
		}
	}
		
	class puntoLlegadaAeropuerto implements PuntoLlegadaValidador {

		private String numeroRUCpuntoLlegada;
		private String codLocalAnexo;

		puntoLlegadaAeropuerto(String numeroRUCpuntoLlegada, String  codLocalAnexo){
			this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;
			this.codLocalAnexo= codLocalAnexo;
		}

		@Override
		public void validar(Date fechaReferencia, String codAduana)  throws PuntoLLegadaValidadorException {			
			if(!SunatStringUtils.isEmpty(numeroRUCpuntoLlegada)|| !SunatStringUtils.isEmpty(codLocalAnexo)){
				//Ya no va tiene que enviar algo
				//throw new PuntoLLegadaValidadorException("37047",new String[]{ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO, numeroRUCpuntoLlegada, codLocalAnexo},"LA DECLARACION TIENE COMO TIPO DE PUNTO DE LLEGADA , NO DEBE CONSIGNAR LOS DATOS DEL RUC Y CODIGO DE LOCAL ANEXO DEL PUNTO DE LLEGADA");
			}

			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
			if(esVigenteRIN05PrimeraParte){
				Map<String, Object> resultado =null;
				CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				resultado = catalogoAyudaService.getElementoAsoc("027", numeroRUCpuntoLlegada, codAduana ,new Date());
				if(resultado!=null && resultado.isEmpty()){
					throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
				}else{

					resultado = catalogoAyudaService.getElementoAsoc("026", CODIGO_PUNTO_LLEGADA_AEROPUERTO, numeroRUCpuntoLlegada ,new Date());
					if(resultado!=null && resultado.isEmpty()){
						throw new PuntoLLegadaValidadorException("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
					}

				}
		  }

		}
	}
	
}	
